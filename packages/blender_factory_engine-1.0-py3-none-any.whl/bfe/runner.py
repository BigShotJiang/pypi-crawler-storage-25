import sys
import os
import re
from bfe.config import get_config

class BlenderPip:
    def __init__(self):
        self.blender_root = get_config("blender-root")
        
        if not self.blender_root:
            print("❌ 请先设置 blender-root：bfe set blender-root <路径>")
            sys.exit(1)

        # 自动查找版本目录：3.0, 4.4 等
        version_dir = None
        for d in os.listdir(self.blender_root):
            full = os.path.join(self.blender_root, d)
            if os.path.isdir(full) and re.match(r'^\d+\.\d+$', d):
                version_dir = d
                break

        if not version_dir:
            print("❌ 未找到 Blender 版本目录（如 4.4）")
            sys.exit(1)

        version_path = os.path.join(self.blender_root, version_dir)

        # 路径配置
        if sys.platform == "win32":
            self.blender_exe = os.path.join(self.blender_root, "blender.exe")
            self.python_path = os.path.join(version_path, "python", "bin", "python.exe")
            self.site_packages = os.path.join(version_path, "python", "lib", "site-packages")
        else:
            self.blender_exe = os.path.join(self.blender_root, "blender")
            bin_dir = os.path.join(version_path, "python", "bin")
            py_bin = sorted([f for f in os.listdir(bin_dir) if f.startswith("python3") and "m" not in f])[-1]
            self.python_path = os.path.join(bin_dir, py_bin)
            ver = py_bin.replace("python", "")
            self.site_packages = os.path.join(version_path, "python", "lib", ver, "site-packages")

        self.python_cmd = f'{self.python_path}'
        self.target_cmd = f'--target {self.site_packages}'

    def run_pip(self, pip_args):
        if pip_args and pip_args[0] == "install":
            cmd = f"{self.python_cmd} -m pip {' '.join(pip_args)} {self.target_cmd}"
        else:
            cmd = f"{self.python_cmd} -m pip {' '.join(pip_args)}"
        # print(f"🚀 执行：{cmd}")
        os.system(cmd)

    def exec_script(self, script_args):
        # 绝对路径 + 不加引号！
        script_path = script_args[0]
        script_abs = os.path.abspath(script_path)
        params = " ".join(script_args[1:])
        cmd = f"{self.blender_exe} -q --background --python {script_abs} -- {params}"
        # print(f"🚀 执行：{cmd}")
        os.system(cmd)