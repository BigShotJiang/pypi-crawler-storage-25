import json
import os
from pathlib import Path

CONFIG_PATH = Path.home() / ".bfe_config.json"

def load_config():
    """加载配置"""
    if not CONFIG_PATH.exists():
        return {"blender-root": "", "proj-root": ""}
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(key, value):
    """保存单个配置项"""
    config = load_config()
    config[key] = value
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)

def get_config(key):
    """获取单个配置"""
    return load_config().get(key, "")

# --------------------
# 你要的 API 级别调用
# --------------------
def set_blender_root(path):
    save_config("blender-root", path)

def set_proj_root(path):
    save_config("proj-root", path)