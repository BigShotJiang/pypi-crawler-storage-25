__version__ = "1.0.0"

import os
from bfe.config import (
    set_blender_root,
    set_proj_root,
    get_config,
    load_config,
    save_config
)
from bfe.runner import BlenderPip

_bfe = BlenderPip()

def exec(script_path, **kargs):
    """
    代码层直接传参：
    bfe.exec("demo.py", a=1, b=2, debug=True)
    """
    args_list = []
    
    # ======================
    # 完全按你给的逻辑！
    # ======================
    for arg_k, arg_v in kargs.items():
        if isinstance(arg_v, bool):
            if arg_v:
                args_list.append(f"--{arg_k}")
        else:
            args_list.append(f"--{arg_k} {arg_v}")
    
    # 拼接成命令行参数
    param_str = " ".join(args_list)
    script_abs = os.path.abspath(script_path)
    
    # 执行
    cmd = f"{_bfe.blender_exe} -q --background --python {script_abs} -- {param_str}"
    # print(f"🚀 [API] 执行：{cmd}")
    os.system(cmd)

import sys
import argparse
import sys
import os


def add_proj_root():
    """
    读取配置中的 proj-root 并加入 sys.path
    如果没配置，会自动提示
    """
    proj_root = get_config("proj-root")
    
    if not proj_root:
        print("⚠️  proj-root 未设置，请运行：")
        print("   bfe set proj-root 你的项目路径")
        return False

    # 加到 Python 扫描路径最前面
    if proj_root not in sys.path:
        sys.path.insert(0, proj_root)
        print(f"✅ 已添加项目目录到 sys.path：{proj_root}")
    return True

def args_init(dict_data):
    parser = argparse.ArgumentParser(description="Dict args converted")
    for k, v in dict_data.items():
        if isinstance(v, bool):
            parser.add_argument(f'--{k}', action='store_true', default=v)
        else:
            parser.add_argument(f'--{k}', type=type(v), default=v)
        argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
        args = parser.parse_args(argv)
        add_proj_root()
        return args
    else:
        args = parser.parse_args()
        return args
