import argparse
import sys
from bfe.config import load_config, save_config
from bfe.runner import BlenderPip

def main():
    parser = argparse.ArgumentParser(description="BFE CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # set 命令
    set_parser = subparsers.add_parser("set", help="设置配置项")
    set_parser.add_argument(
        "key",
        choices=["blender-root", "proj-root"],  # 这里改了
        help="要设置的配置项"
    )
    set_parser.add_argument("path", help="路径值")

    # info 命令（原来的 config）
    subparsers.add_parser("info", help="查看当前配置")  # 这里改了

    # pip 命令
    pip_parser = subparsers.add_parser("pip", help="Blender 内置 pip")
    pip_parser.add_argument("args", nargs=argparse.REMAINDER)

    # exec 命令
    exec_parser = subparsers.add_parser("exec", help="用 Blender Python 执行脚本")
    exec_parser.add_argument("args", nargs=argparse.REMAINDER)

    args = parser.parse_args()

    if args.command == "set":
        save_config(args.key, args.path)
        print(f"✅ 已保存 {args.key} -> {args.path}")

    elif args.command == "info":  # 这里改了
        config = load_config()
        print("\n📋 BFE 配置信息：")
        print(f"blender-root: {config['blender-root'] or '未设置'}")
        print(f"proj-root: {config['proj-root'] or '未设置'}")  # 这里改了
        print()

    elif args.command == "pip":
        BlenderPip().run_pip(args.args)

    elif args.command == "exec":
        if not args.args:
            print("用法：bfe exec script.py --arg1 val1 --flag")
            sys.exit(1)
        BlenderPip().exec_script(args.args)

if __name__ == "__main__":
    main()