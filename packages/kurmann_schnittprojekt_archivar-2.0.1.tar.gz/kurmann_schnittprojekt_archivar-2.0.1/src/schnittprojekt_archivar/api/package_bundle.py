"""Public-API-Fassade für ``package_project_bundle``."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from schnittprojekt_archivar.core import package_bundle as core_package_bundle
from schnittprojekt_archivar.models.events import ArchivarEvent
from schnittprojekt_archivar.models.requests import PackageResult
from schnittprojekt_archivar.models.runtime import RuntimeOptions


def package_project_bundle(
    project_path: Path,
    target_dir: str,
    target_filename: str,
    runtime: RuntimeOptions | None = None,
    *,
    overwrite: bool = False,
    on_event: Callable[[ArchivarEvent], None] | None = None,
) -> PackageResult:
    """Verpackt ein Schnittprojekt und legt es im Archiv-Ziel ab.

    Format-Behandlung:

    - ``.fcpxmld`` (Verzeichnis) → ZIP-Container (``ZIP_STORED`` + ``allowZip64``)
    - ``.fcpxml`` (Single-File) → 1:1-Kopie
    - ``.iMovieMobile`` (ist schon ZIP) → 1:1-Kopie ohne erneutes Zippen

    Zieltyp:

    - Lokaler Pfad → atomare Schreibung direkt
    - rclone-URI → in ``runtime.work_dir`` aufbauen, dann via rclone hochladen

    Args:
        project_path: Pfad zur Schnittprojekt-Quelle.
        target_dir: Ziel-Verzeichnis (lokal oder rclone-URI).
        target_filename: vollständiger Datei-Name im Ziel inkl. Endung.
        runtime: technische Optionen. ``None`` → Defaults.
        overwrite: bei ``False`` Fehler wenn Ziel existiert.
        on_event: Stage-Events.

    Returns:
        ``PackageResult`` mit ``success``, ``target_uri``, ``bundle_size_bytes``.
        Bei Fehler ``success=False`` und ``error_message`` gesetzt.
    """
    rt = runtime or RuntimeOptions()
    return core_package_bundle.package_project_bundle(
        project_path,
        target_dir,
        target_filename,
        rt,
        overwrite=overwrite,
        on_event=on_event,
    )
