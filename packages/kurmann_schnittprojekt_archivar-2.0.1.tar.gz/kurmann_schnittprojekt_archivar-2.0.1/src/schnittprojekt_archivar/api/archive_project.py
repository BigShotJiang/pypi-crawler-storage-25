"""Public-API-Fassade für ``archive_project`` (Convenience-Orchestrator)."""

from __future__ import annotations

from collections.abc import Callable

from schnittprojekt_archivar.core import archive as core_archive
from schnittprojekt_archivar.models.events import ArchivarEvent
from schnittprojekt_archivar.models.requests import (
    ArchiveProjectRequest,
    ArchiveProjectResult,
)
from schnittprojekt_archivar.models.runtime import RuntimeOptions


def archive_project(
    request: ArchiveProjectRequest,
    runtime: RuntimeOptions | None = None,
    *,
    on_event: Callable[[ArchivarEvent], None] | None = None,
    on_output: Callable[[str], None] | None = None,
) -> ArchiveProjectResult:
    """Orchestriert die komplette Archivierung eines Schnittprojekts.

    Schritte:
    1. Manifest lesen (delegiert an ``schnittprojekt-leser``)
    2. Bundle ins Ziel packen (ZIP / 1:1-Kopie)
    3. ``.project.toml`` schreiben
    4. ``.project.clips.jsonl`` schreiben (optional)

    Args:
        request: ``ArchiveProjectRequest`` mit Quelle, Ziel-Verzeichnis,
            Stem, Suffix-Overrides und Verhaltens-Flags.
        runtime: technische Optionen. ``None`` → Defaults.
        on_event, on_output: Callbacks.

    Returns:
        ``ArchiveProjectResult`` mit Detail-Status pro Schritt.
    """
    rt = runtime or RuntimeOptions()
    return core_archive.archive_project(
        request, rt, on_event=on_event, on_output=on_output,
    )
