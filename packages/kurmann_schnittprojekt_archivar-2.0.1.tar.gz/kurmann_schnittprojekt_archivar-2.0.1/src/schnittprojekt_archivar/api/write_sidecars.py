"""Public-API-Fassaden für die Manifest-Persistierungs-Helfer.

Konsumenten, die ihre eigene Persistierungs-Strategie umsetzen wollen
(z. B. der familienfilm-manager: Manifest in eine ``.video.toml``-Sektion
einbetten), nutzen diese Funktionen direkt mit selbst gewähltem Path/Suffix.
"""

from __future__ import annotations

from pathlib import Path

from schnittprojekt_archivar.models.manifest import ProjectManifest
from schnittprojekt_archivar.services import manifest_writer as _writer


def write_manifest_toml(manifest: ProjectManifest, target_path: Path) -> None:
    """Schreibt das aggregierte Manifest als TOML (atomar).

    Konsumenten wählen ``target_path`` vollständig — Suffix-Konstanten
    (``PROJECT_TOML_SUFFIX``) sind nur Empfehlungen.
    """
    _writer.write_manifest_toml(manifest, target_path)


def write_clips_jsonl(manifest: ProjectManifest, target_path: Path) -> None:
    """Schreibt das Clip-Inventar als JSONL (atomar).

    Erste Zeile ist Header (``_type=header``); danach pro Clip eine Zeile.
    """
    _writer.write_clips_jsonl(manifest, target_path)
