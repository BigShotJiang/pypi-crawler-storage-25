"""Public API der Bibliothek.

Externe Konsumenten importieren ausschliesslich aus diesem Paket oder
direkt aus ``schnittprojekt_archivar`` (Top-Level-Re-Exports).
"""

from schnittprojekt_archivar.api.archive_project import archive_project
from schnittprojekt_archivar.api.package_bundle import package_project_bundle
from schnittprojekt_archivar.api.read_manifest import read_project_manifest
from schnittprojekt_archivar.api.write_sidecars import (
    write_clips_jsonl,
    write_manifest_toml,
)

__all__ = [
    "archive_project",
    "package_project_bundle",
    "read_project_manifest",
    "write_manifest_toml",
    "write_clips_jsonl",
]
