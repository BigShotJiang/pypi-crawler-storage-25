"""Public-API-Fassade für ``read_project_manifest``."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from schnittprojekt_archivar.core import read_manifest as core_read_manifest
from schnittprojekt_archivar.models.errors import (
    ManifestReadError,
    SchnittprojektArchivarError,
)
from schnittprojekt_archivar.models.events import ArchivarEvent
from schnittprojekt_archivar.models.manifest import ProjectManifest
from schnittprojekt_archivar.models.runtime import RuntimeOptions


def read_project_manifest(
    project_path: Path,
    runtime: RuntimeOptions | None = None,
    *,
    include_clips: bool = True,
    timezone_assumption: str | None = None,
    on_event: Callable[[ArchivarEvent], None] | None = None,
    on_output: Callable[[str], None] | None = None,
) -> ProjectManifest:
    """Liest ein Schnittprojekt und liefert ein in-memory ``ProjectManifest``.

    Args:
        project_path: ``.fcpxmld``, ``.fcpxml`` oder ``.iMovieMobile``.
        runtime: technische Optionen. ``None`` → Defaults.
        include_clips: bei ``True`` wird das Video-Originalmedien-Inventar
            mit gelesen (zeit-intensiv).
        timezone_assumption: optionaler IANA-TZ-Name.
        on_event, on_output: Callbacks.

    Raises:
        ManifestReadError: schnittprojekt-leser konnte das Projekt nicht lesen.
        SchnittprojektArchivarError: bei sonstigen archivar-internen Fehlern.
    """
    rt = runtime or RuntimeOptions()
    try:
        return core_read_manifest.read_project_manifest(
            project_path,
            rt,
            include_clips=include_clips,
            timezone_assumption=timezone_assumption,
            on_event=on_event,
            on_output=on_output,
        )
    except SchnittprojektArchivarError:
        raise
    except Exception as exc:
        raise ManifestReadError(
            f"Unerwarteter Fehler beim Manifest-Lesen: {exc}"
        ) from exc
