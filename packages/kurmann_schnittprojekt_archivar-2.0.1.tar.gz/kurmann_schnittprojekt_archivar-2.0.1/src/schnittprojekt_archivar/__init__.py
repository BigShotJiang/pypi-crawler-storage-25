"""kurmann-schnittprojekt-archivar — Archivar für Videoschnitt-Projekte.

Public API: Re-Exports aus ``api/``-Submodul. Konsumenten importieren so:

    from schnittprojekt_archivar import (
        read_project_manifest,
        package_project_bundle,
        write_manifest_toml,
        write_clips_jsonl,
        archive_project,
    )
    from schnittprojekt_archivar import (
        PROJECT_TOML_SUFFIX,
        CLIPS_JSONL_SUFFIX,
        FCPXML_BUNDLE_ZIP_SUFFIX,
    )
    from schnittprojekt_archivar.models import (
        ArchiveProjectRequest,
        ProjectManifest,
        RuntimeOptions,
    )
"""

from schnittprojekt_archivar.api import (
    archive_project,
    package_project_bundle,
    read_project_manifest,
    write_clips_jsonl,
    write_manifest_toml,
)
from schnittprojekt_archivar.models.slug import (
    is_archive_safe_stem,
    to_archive_stem,
)
from schnittprojekt_archivar.models.suffixes import (
    CLIPS_JSONL_SUFFIX,
    FCPXML_BUNDLE_ZIP_SUFFIX,
    PROJECT_TOML_SUFFIX,
)

__version__ = "2.0.1"

__all__ = [
    "archive_project",
    "package_project_bundle",
    "read_project_manifest",
    "write_manifest_toml",
    "write_clips_jsonl",
    "PROJECT_TOML_SUFFIX",
    "CLIPS_JSONL_SUFFIX",
    "FCPXML_BUNDLE_ZIP_SUFFIX",
    "to_archive_stem",
    "is_archive_safe_stem",
]
