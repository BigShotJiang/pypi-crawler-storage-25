"""CLI-Entrypoint ``schnittprojekt-archivar``.

Dünner Adapter über der Public-API. stdout/stderr-Disziplin:

- **stdout** — nur Ergebnisdaten (JSON, Status-Übersicht). Pipeline-fähig.
- **stderr** — Events, Warnungen, Fehler, roher Subprozess-Output (nur mit ``--verbose``).
- ``--verbose`` ändert nie stdout.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path

import typer
from rich.console import Console

from schnittprojekt_archivar import __version__
from schnittprojekt_archivar.api import archive_project
from schnittprojekt_archivar.models import (
    ArchivarEvent,
    ArchiveProjectRequest,
    RuntimeOptions,
)

app = typer.Typer(
    name="schnittprojekt-archivar",
    help=(
        "Archivar für Videoschnitt-Projekte. Packt FCPXML-Bundles und "
        "iMovieMobile-Container ins Langzeit-Archiv, mit aggregiertem "
        "Projekt-Manifest und Clip-Inventar dazu.\n\n"
        "WAS WIRD ARCHIVIERT:\n"
        "  - .fcpxmld (FCP-Bundle, Verzeichnis) → ZIP-Container\n"
        "  - .fcpxml  (Flat-XML, Single-File)   → 1:1-Kopie\n"
        "  - .iMovieMobile (ist bereits ZIP)    → 1:1-Kopie (kein Re-Zip)\n\n"
        "Bei .fcpxmld und .iMovieMobile sind die Medien direkt im Bundle/Container "
        "enthalten (relative src-Pfade), also kommt das Schnittprojekt SELF-CONTAINED "
        "ins Archiv — beim Entpacken sofort wieder öffenbar. Bei der Flat .fcpxml "
        "wird nur die XML kopiert (keine Medien daneben). Das .project.clips.jsonl "
        "zusätzlich dokumentiert, woher die Clips ursprünglich stammen (ISO/Volume).\n\n"
        "QUELLE: muss lokal sein (echter Pfad oder Volume-Mount). "
        "rclone-URIs als Quelle sind NICHT erlaubt — nur als --target-dir.\n\n"
        "ARCHIVIEREN = KOPIEREN: das Original bleibt immer erhalten."
    ),
    no_args_is_help=True,
)

stdout_console = Console()
stderr_console = Console(stderr=True)


def _version_callback(value: bool) -> None:
    if value:
        stdout_console.print(__version__)
        raise typer.Exit(code=0)


@app.callback()
def _main_callback(
    version: bool = typer.Option(
        False,
        "--version",
        help="Version anzeigen und beenden.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """Archivar für Videoschnitt-Projekte (FCPXML, iMovieMobile)."""


@app.command(name="archive")
def cmd_archive(
    project_path: Path = typer.Argument(
        ...,
        exists=True,
        readable=True,
        help=(
            "Pfad zur Schnittprojekt-Quelle: .fcpxmld-Bundle (Verzeichnis), "
            ".fcpxml-File oder .iMovieMobile-ZIP. "
            "MUSS ein lokaler Pfad sein (auch ein gemounteter Netzpfad wie "
            "/Volumes/<share>/... ist OK). rclone-URIs werden hier NICHT "
            "akzeptiert — vorher z. B. via 'rclone copy' ins lokale Work-Dir holen."
        ),
    ),
    target_dir: str = typer.Option(
        ...,
        "--target-dir",
        "-d",
        help=(
            "Ziel-Verzeichnis. Lokaler Pfad (z. B. /Volumes/Archiv/...) oder "
            "rclone-URI (z. B. nas:/Archiv/2026/Projekte)."
        ),
    ),
    target_stem: str | None = typer.Option(
        None,
        "--target-stem",
        "-s",
        help=(
            "Override für den Ziel-Stem (ohne Endung). Default: aus dem "
            "Quelldateinamen abgeleitet und automatisch ASCII-slugifiziert "
            "('Fünffacher Büsi-Nachwuchs.fcpxml' → 'Fuenffacher-Buesi-Nachwuchs'). "
            "Endung leitet der Archivar aus dem Quellformat ab (.fcpxmld.zip, "
            ".fcpxml, .iMovieMobile)."
        ),
    ),
    no_clips_jsonl: bool = typer.Option(
        False,
        "--no-clips-jsonl",
        help="Keine .project.clips.jsonl schreiben (nur .project.toml + Bundle).",
    ),
    no_clip_inventory: bool = typer.Option(
        False,
        "--no-clip-inventory",
        help=(
            "Kein Clip-Inventar lesen (schneller, aber das Manifest enthält "
            "keine Detail-Metadaten pro Quellclip)."
        ),
    ),
    overwrite: bool = typer.Option(
        False, "--overwrite", help="Existierende Ziel-Dateien überschreiben."
    ),
    allow_flat_fcpxml: bool = typer.Option(
        False,
        "--allow-flat-fcpxml",
        help=(
            "Erlaubt das Archivieren einer Flat-.fcpxml, auch wenn daneben ein "
            "gleichnamiges .fcpxmld-Bundle liegt. Default: Mehrdeutigkeit → Abbruch."
        ),
    ),
    strict_stem: bool = typer.Option(
        False,
        "--strict-stem",
        help=(
            "ASCII-Slug-Disziplin abschalten: --target-stem muss bereits "
            "archivtauglich sein, sonst Abbruch. Ohne dieses Flag slugifiziert "
            "der Archivar Umlaute/Sonderzeichen still und meldet die Umformung."
        ),
    ),
    timezone_assumption: str | None = typer.Option(
        None,
        "--timezone",
        "-t",
        help="IANA-Zeitzone für Wallclock-Konvertierung der Recording-Felder.",
    ),
    exiftool_path: str = typer.Option(
        "exiftool", "--exiftool", help="Pfad zum exiftool-Binary."
    ),
    rclone_path: str = typer.Option(
        "rclone", "--rclone", help="Pfad zum rclone-Binary."
    ),
    work_dir: Path | None = typer.Option(
        None,
        "--work-dir",
        help="Arbeitsverzeichnis (für rclone-Staging). Default: System-Temp.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help=(
            "Diagnose-Output auf stderr (Event-Trace, Slug-Hinweis, Sub-"
            "Prozess-Ausgaben). Default ist Unix-Stille bei Erfolg."
        ),
    ),
    output_json: bool = typer.Option(
        False,
        "--json",
        help=(
            "Strukturiertes Result-JSON auf stdout ausgeben (für "
            "Pipeline-Konsumenten). Default: stdout bleibt leer bei Erfolg."
        ),
    ),
) -> None:
    """Archiviert ein Schnittprojekt: Bundle + .project.toml + .project.clips.jsonl ins Ziel.

    LEGT IM ZIEL AB (drei Dateien, gleicher Stem):
      <stem>.fcpxmld.zip / .fcpxml / .iMovieMobile   (das Schnittprojekt)
      <stem>.project.toml                            (aggregiertes Manifest)
      <stem>.project.clips.jsonl                     (Clip-Inventar, eine Zeile pro Quellclip)

    DEFAULT-DISZIPLIN:
      - <stem> wird aus dem Quelldateinamen abgeleitet und ASCII-slugifiziert
        (Umlaute → ae/oe/ue/ss, Sonderzeichen → '-'). Override via --target-stem.
      - Bei Mehrdeutigkeit (.fcpxml mit .fcpxmld-Geschwister) bricht der Archivar ab.
      - Existierende Ziel-Dateien werden NICHT überschrieben (siehe --overwrite).
    """
    runtime = RuntimeOptions(
        exiftool_path=exiftool_path,
        rclone_path=rclone_path,
        work_dir=work_dir,
    )

    # Default-Stem aus dem Quelldateinamen ableiten — der Archivar
    # slugifiziert ihn anschliessend ASCII-safe (siehe to_archive_stem).
    effective_target_stem = target_stem if target_stem else project_path.stem

    request = ArchiveProjectRequest(
        project_path=project_path,
        target_dir=target_dir,
        target_stem=effective_target_stem,
        write_clips_jsonl_file=not no_clips_jsonl,
        include_clips=not no_clip_inventory,
        overwrite=overwrite,
        allow_flat_fcpxml_if_bundle_sibling=allow_flat_fcpxml,
        strict_stem=strict_stem,
        timezone_assumption=timezone_assumption,
    )

    on_event, on_output = _make_callbacks(verbose)
    result = archive_project(
        request, runtime, on_event=on_event, on_output=on_output,
    )

    # Slug-Hinweis und Warnungen nur mit --verbose auf stderr.
    # Default-Verhalten ist Unix-Stille: bei Erfolg ist sowohl stdout
    # als auch stderr leer; Konsumenten erfahren das Ergebnis über
    # Exit-Code und (optional) --json.
    if verbose:
        if result.stem_was_slugified:
            stderr_console.print(
                f"[dim]ASCII-Slug:[/dim] »{result.original_stem}« → "
                f"»{result.effective_stem}«"
            )
        for warning in result.warnings:
            stderr_console.print(f"[yellow]Warnung:[/yellow] {warning}")

    if not result.success:
        # Fehler immer auf stderr, unabhängig von --verbose.
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    if output_json:
        stdout_console.print_json(
            json.dumps(
                {
                    "success": True,
                    "bundle_filename": result.bundle.bundle_filename if result.bundle else None,
                    "bundle_size_bytes": result.bundle.bundle_size_bytes if result.bundle else None,
                    "target_uri": result.bundle.target_uri if result.bundle else None,
                    "manifest_toml_written": result.manifest_toml_written,
                    "clips_jsonl_written": result.clips_jsonl_written,
                    "effective_stem": result.effective_stem,
                    "original_stem": result.original_stem,
                    "stem_was_slugified": result.stem_was_slugified,
                },
                default=str,
            )
        )


def _make_callbacks(verbose: bool) -> tuple[
    Callable[[ArchivarEvent], None], Callable[[str], None]
]:
    """Stellt on_event/on_output je nach ``--verbose`` bereit."""

    def on_event(event: ArchivarEvent) -> None:
        if verbose:
            stderr_console.print(f"[dim][{event.stage_id}][/dim] {event.message}")

    def on_output(text: str) -> None:
        if verbose:
            stderr_console.print(text, end="")

    return on_event, on_output
