"""CLI-Entrypoint des Archivars."""
