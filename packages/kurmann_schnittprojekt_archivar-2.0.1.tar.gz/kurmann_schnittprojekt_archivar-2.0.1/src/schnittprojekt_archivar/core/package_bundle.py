"""Komposition ``package_project_bundle``: verpackt das Projekt-Bundle ins Ziel.

Format-Dispatch:

- ``.fcpxmld`` (Verzeichnis) → ZIP-Pack (``ZIP_STORED`` + ``allowZip64``)
- ``.fcpxml`` (Datei) → 1:1-Kopie ohne Container
- ``.iMovieMobile`` (Datei, ist schon ZIP) → 1:1-Kopie ohne erneutes Zippen

Zieltyp-Dispatch:

- Lokaler Pfad → atomare Schreibung direkt
- rclone-URI → in ``runtime.work_dir`` aufbauen, dann ``rclone copyto`` ins Ziel
"""

from __future__ import annotations

import tempfile
from collections.abc import Callable
from pathlib import Path

from schnittprojekt_archivar.models.errors import (
    ArchiveTargetError,
    ArchiveTargetExistsError,
    BundleError,
)
from schnittprojekt_archivar.models.events import ArchivarEvent, ArchiveStage
from schnittprojekt_archivar.models.requests import PackageResult
from schnittprojekt_archivar.models.runtime import RuntimeOptions
from schnittprojekt_archivar.services.file_copier import atomic_copy_file
from schnittprojekt_archivar.services.rclone_uploader import (
    is_rclone_uri,
    remote_file_exists,
    upload_file,
)
from schnittprojekt_archivar.services.zip_builder import build_fcpxml_bundle_zip


def package_project_bundle(
    project_path: Path,
    target_dir: str,
    target_filename: str,
    runtime: RuntimeOptions,
    *,
    overwrite: bool = False,
    on_event: Callable[[ArchivarEvent], None] | None = None,
) -> PackageResult:
    """Verschiebt das Projekt-Bundle ins Archiv-Ziel.

    Args:
        project_path: Quelle (``.fcpxmld``-Verzeichnis, ``.fcpxml``- oder
            ``.iMovieMobile``-Datei).
        target_dir: Ziel-Verzeichnis (lokal oder rclone-URI).
        target_filename: vollständiger Datei-Name im Ziel inkl. Endung
            (z. B. ``"2026-05-10-Maedchen.fcpxmld.zip"``).
        runtime: technische Optionen — relevant: ``work_dir`` (für rclone-
            Staging) und ``rclone_path``/``rclone_timeout_seconds``.
        overwrite: bei ``False`` Fehler wenn Ziel existiert.
        on_event: Stage-Events während Build und Upload.

    Returns:
        ``PackageResult`` mit ``success=True`` und ``target_uri``/``bundle_size_bytes``
        bei Erfolg.
    """
    if not project_path.exists():
        return PackageResult(
            success=False,
            error_message=f"Projektpfad existiert nicht: {project_path}",
        )

    target_uri = _join_target(target_dir, target_filename)
    rclone_target = is_rclone_uri(target_dir)

    # Konflikt-Check: ZIEL-Datei darf nicht existieren (ohne overwrite)
    if not overwrite and _target_exists(target_uri, rclone_target, runtime):
        return PackageResult(
            success=False,
            target_uri=target_uri,
            error_message=(
                f"Ziel-Datei existiert bereits: {target_uri} "
                f"(mit overwrite=True erzwingen)"
            ),
        )

    # Lokales Build-Ziel: bei lokalem Target = Ziel direkt; bei rclone = work_dir
    if rclone_target:
        work_dir = runtime.work_dir or Path(tempfile.gettempdir())
        work_dir.mkdir(parents=True, exist_ok=True)
        local_build_path = work_dir / target_filename
    else:
        local_build_path = Path(target_dir) / target_filename

    # Format-Dispatch
    _emit(on_event, ArchiveStage.BUNDLE_BUILD_STARTED,
          f"Bundle aufbauen: {project_path.name} → {target_filename}")
    try:
        if project_path.is_dir() and project_path.suffix == ".fcpxmld":
            size = build_fcpxml_bundle_zip(
                project_path, local_build_path, overwrite=True,
            )
        elif project_path.is_file() and project_path.suffix in {".fcpxml", ".iMovieMobile"}:
            size = atomic_copy_file(
                project_path, local_build_path, overwrite=True,
            )
        else:
            return PackageResult(
                success=False,
                error_message=(
                    f"Unerkanntes Schnittprojekt-Format: {project_path.name}. "
                    f"Erwartet: .fcpxmld (Verzeichnis), .fcpxml oder .iMovieMobile."
                ),
            )
    except BundleError as exc:
        return PackageResult(success=False, error_message=str(exc))

    _emit(on_event, ArchiveStage.BUNDLE_BUILD_COMPLETED,
          f"Bundle aufgebaut ({size} Bytes)")

    # Optional rclone-Upload
    if rclone_target:
        _emit(on_event, ArchiveStage.BUNDLE_UPLOAD_STARTED,
              f"Upload via rclone nach {target_uri}")
        try:
            upload_file(
                local_build_path, target_uri,
                rclone_path=runtime.rclone_path,
                timeout=runtime.rclone_timeout_seconds,
            )
        except ArchiveTargetError as exc:
            return PackageResult(success=False, error_message=str(exc))
        finally:
            # Lokale Stage-Datei aufräumen (auch bei Fehler — sie liegt im work_dir,
            # nicht im Ziel; Patrick will keine Halb-Dateien im work_dir lassen).
            try:
                local_build_path.unlink(missing_ok=True)
            except OSError:
                pass
        _emit(on_event, ArchiveStage.BUNDLE_UPLOAD_COMPLETED,
              f"Upload abgeschlossen: {target_filename}")

    return PackageResult(
        success=True,
        bundle_filename=target_filename,
        bundle_size_bytes=size,
        target_uri=target_uri,
    )


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------


def _join_target(target_dir: str, filename: str) -> str:
    """Verbindet target_dir + filename. Funktioniert für lokale Pfade und rclone-URIs."""
    if is_rclone_uri(target_dir):
        sep = "/" if not target_dir.endswith(":") else ""
        return f"{target_dir.rstrip('/')}{sep}{filename}"
    return str(Path(target_dir) / filename)


def _target_exists(
    target_uri: str, is_rclone: bool, runtime: RuntimeOptions
) -> bool:
    """Prüft, ob die Ziel-Datei existiert (lokal oder via rclone)."""
    if is_rclone:
        return remote_file_exists(
            target_uri,
            rclone_path=runtime.rclone_path,
            timeout=min(runtime.rclone_timeout_seconds, 60.0),
        )
    return Path(target_uri).exists()


def _emit(
    on_event: Callable[[ArchivarEvent], None] | None,
    stage: ArchiveStage,
    message: str,
) -> None:
    if on_event is None:
        return
    on_event(ArchivarEvent(stage_id=stage.value, message=message))


__all__ = ["package_project_bundle", "ArchiveTargetExistsError"]
