"""Komposition ``archive_project``: orchestriert Bundle + Manifest + Clips.

Die High-Level-Convenience-Funktion, die der CLI-Happy-Path nutzt.
Kombiniert ``read_project_manifest`` (Daten-Schicht) mit ``package_project_bundle``
(Bundle-Schicht) und den Manifest-Schreibern (Persistierungs-Schicht).

Reihenfolge der Schritte:
1. Manifest lesen (mit optionalem Clip-Inventar)
2. Bundle packen / ins Ziel laden
3. Manifest mit Bundle-Filename + Size anreichern
4. ``.project.toml`` schreiben
5. (optional) ``.project.clips.jsonl`` schreiben
"""

from __future__ import annotations

import tempfile
from collections.abc import Callable
from pathlib import Path

from schnittprojekt_archivar.core.package_bundle import package_project_bundle
from schnittprojekt_archivar.core.read_manifest import read_project_manifest
from schnittprojekt_archivar.models.errors import ManifestReadError
from schnittprojekt_archivar.models.events import ArchivarEvent, ArchiveStage
from schnittprojekt_archivar.models.requests import (
    ArchiveProjectRequest,
    ArchiveProjectResult,
)
from schnittprojekt_archivar.models.runtime import RuntimeOptions
from schnittprojekt_archivar.models.slug import (
    is_archive_safe_stem,
    to_archive_stem,
)
from schnittprojekt_archivar.models.suffixes import (
    FCPXML_BUNDLE_ZIP_SUFFIX,
    FCPXML_SINGLE_SUFFIX,
    IMOVIE_MOBILE_SUFFIX,
)
from schnittprojekt_archivar.services.manifest_writer import (
    write_clips_jsonl,
    write_manifest_toml,
)
from schnittprojekt_archivar.services.rclone_uploader import (
    is_rclone_uri,
    upload_file,
)


def archive_project(
    request: ArchiveProjectRequest,
    runtime: RuntimeOptions,
    *,
    on_event: Callable[[ArchivarEvent], None] | None = None,
    on_output: Callable[[str], None] | None = None,
) -> ArchiveProjectResult:
    """Orchestriert die komplette Archivierung eines Schnittprojekts."""
    # 0. Slug-Disziplin: ASCII-Safe-Stem erzwingen oder slugifizieren
    original_stem = request.target_stem
    if request.strict_stem:
        if not is_archive_safe_stem(original_stem):
            return ArchiveProjectResult(
                success=False,
                effective_stem=original_stem,
                error_message=(
                    f"target_stem »{original_stem}« ist nicht archivtauglich "
                    f"(enthält Umlaute/Sonderzeichen). Erwartet wäre etwa "
                    f"»{to_archive_stem(original_stem)}«. "
                    "Ohne --strict-stem würde der Archivar das stillschweigend umformen."
                ),
            )
        effective_stem = original_stem
        stem_was_slugified = False
    else:
        effective_stem = to_archive_stem(original_stem)
        if not effective_stem:
            return ArchiveProjectResult(
                success=False,
                effective_stem=effective_stem,
                original_stem=original_stem,
                error_message=(
                    f"target_stem »{original_stem}« ergibt nach Slug-Umformung "
                    "einen leeren String."
                ),
            )
        stem_was_slugified = effective_stem != original_stem

    # Re-bind: ab hier arbeitet alles mit dem effektiven Stem
    request = _with_effective_stem(request, effective_stem)

    # Slug-Umformung ist Default-Verhalten — kein Warning, nur Event.
    # Konsumenten sehen die Umformung über result.stem_was_slugified +
    # result.effective_stem/original_stem im Result.
    warnings: list[str] = []
    if stem_was_slugified:
        _emit(
            on_event,
            ArchiveStage.STEM_SLUGIFIED,
            f"target_stem »{original_stem}« → »{effective_stem}«",
        )

    # 0.5. Mehrdeutigkeits-Check: .fcpxml vs. gleichnamiges .fcpxmld-Bundle.
    # Wer eine Flat-XML übergibt, während daneben ein FCP-Bundle liegt, hat
    # mit hoher Wahrscheinlichkeit das Bundle gemeint. Defaultmässig
    # abbrechen, statt stillschweigend die kleine Variante zu archivieren.
    if not request.allow_flat_fcpxml_if_bundle_sibling:
        ambiguity_error = _check_bundle_sibling(request.project_path)
        if ambiguity_error is not None:
            return ArchiveProjectResult(
                success=False,
                effective_stem=effective_stem,
                original_stem=original_stem if stem_was_slugified else None,
                stem_was_slugified=stem_was_slugified,
                warnings=warnings,
                error_message=ambiguity_error,
            )

    # 1. Manifest lesen
    try:
        manifest = read_project_manifest(
            request.project_path,
            runtime,
            include_clips=request.include_clips,
            timezone_assumption=request.timezone_assumption,
            on_event=on_event,
            on_output=on_output,
        )
    except ManifestReadError as exc:
        return ArchiveProjectResult(
            success=False,
            effective_stem=effective_stem,
            original_stem=original_stem if stem_was_slugified else None,
            stem_was_slugified=stem_was_slugified,
            warnings=warnings,
            error_message=str(exc),
        )

    # 2. Bundle-Filename ableiten (basierend auf Quellformat + target_stem)
    bundle_filename = _derive_bundle_filename(request.project_path, request.target_stem)

    # 3. Bundle packen / uploaden
    package_result = package_project_bundle(
        request.project_path,
        request.target_dir,
        bundle_filename,
        runtime,
        overwrite=request.overwrite,
        on_event=on_event,
    )
    if not package_result.success:
        return ArchiveProjectResult(
            success=False,
            bundle=package_result,
            effective_stem=effective_stem,
            original_stem=original_stem if stem_was_slugified else None,
            stem_was_slugified=stem_was_slugified,
            warnings=warnings,
            error_message=package_result.error_message,
        )

    # Manifest anreichern mit Bundle-Info
    manifest.bundle_filename = package_result.bundle_filename
    manifest.bundle_size_bytes = package_result.bundle_size_bytes

    # 4. Manifest-Sidecars schreiben (lokal oder via rclone)
    manifest_toml_written = False
    clips_jsonl_written = False
    try:
        _write_sidecars(
            manifest,
            request,
            runtime,
            on_event=on_event,
        )
        manifest_toml_written = True
        if request.write_clips_jsonl_file:
            clips_jsonl_written = True
    except Exception as exc:
        return ArchiveProjectResult(
            success=False,
            bundle=package_result,
            manifest_toml_written=manifest_toml_written,
            clips_jsonl_written=clips_jsonl_written,
            effective_stem=effective_stem,
            original_stem=original_stem if stem_was_slugified else None,
            stem_was_slugified=stem_was_slugified,
            warnings=warnings,
            error_message=f"Manifest-Schreiben fehlgeschlagen: {exc}",
        )

    _emit(on_event, ArchiveStage.ARCHIVE_COMPLETED,
          f"Archivierung abgeschlossen: {request.target_stem}")

    return ArchiveProjectResult(
        success=True,
        bundle=package_result,
        manifest_toml_written=manifest_toml_written,
        clips_jsonl_written=clips_jsonl_written,
        effective_stem=effective_stem,
        original_stem=original_stem if stem_was_slugified else None,
        stem_was_slugified=stem_was_slugified,
        warnings=warnings,
    )


def _with_effective_stem(
    request: ArchiveProjectRequest, effective_stem: str
) -> ArchiveProjectRequest:
    """Liefert eine Kopie des Requests mit ersetztem ``target_stem``."""
    if request.target_stem == effective_stem:
        return request
    from dataclasses import replace

    return replace(request, target_stem=effective_stem)


def _check_bundle_sibling(project_path: Path) -> str | None:
    """Wenn ``project_path`` eine Flat-``.fcpxml`` ist und daneben ein
    gleichnamiges ``.fcpxmld``-Bundle-Verzeichnis liegt: Fehlermeldung.
    Sonst ``None``.
    """
    if project_path.suffix != ".fcpxml":
        return None
    if project_path.is_dir():  # Defensive: nur regular file kann Flat-XML sein
        return None
    sibling = project_path.with_suffix(".fcpxmld")
    if sibling.is_dir():
        return (
            f"Mehrdeutige Quelle: du hast »{project_path.name}« (Flat-XML, "
            f"{project_path.stat().st_size:,} Bytes) angegeben, aber daneben "
            f"liegt »{sibling.name}« (FCP-Bundle, Verzeichnis). "
            "Mit hoher Wahrscheinlichkeit willst du das Bundle archivieren. "
            f"Korrekter Aufruf: gib »{sibling}« als Quelle an. "
            "Wenn du wirklich nur die Flat-XML willst: --allow-flat-fcpxml."
        )
    return None


def _derive_bundle_filename(project_path: Path, target_stem: str) -> str:
    """Ableitet den Archiv-Dateinamen aus Quellformat + Stem."""
    if project_path.is_dir() and project_path.suffix == ".fcpxmld":
        return f"{target_stem}{FCPXML_BUNDLE_ZIP_SUFFIX}"
    if project_path.suffix == ".fcpxml":
        return f"{target_stem}{FCPXML_SINGLE_SUFFIX}"
    if project_path.suffix == ".iMovieMobile":
        return f"{target_stem}{IMOVIE_MOBILE_SUFFIX}"
    # Fallback: Originalsuffix verwenden
    return f"{target_stem}{project_path.suffix}"


def _write_sidecars(
    manifest,
    request: ArchiveProjectRequest,
    runtime: RuntimeOptions,
    *,
    on_event: Callable[[ArchivarEvent], None] | None,
) -> None:
    """Schreibt project.toml (+ optional clips.jsonl) ans Ziel.

    Bei rclone-Zielen: erst lokal in ``work_dir`` schreiben, dann via
    ``rclone copyto`` hochladen. Bei lokalen Zielen: atomar direkt.
    """
    rclone_target = is_rclone_uri(request.target_dir)
    if rclone_target:
        work_dir = runtime.work_dir or Path(tempfile.gettempdir())
        work_dir.mkdir(parents=True, exist_ok=True)
        toml_local = work_dir / f"{request.target_stem}{request.manifest_suffix}"
        jsonl_local = work_dir / f"{request.target_stem}{request.clips_suffix}"
    else:
        target_root = Path(request.target_dir)
        toml_local = target_root / f"{request.target_stem}{request.manifest_suffix}"
        jsonl_local = target_root / f"{request.target_stem}{request.clips_suffix}"

    write_manifest_toml(manifest, toml_local)
    _emit(on_event, ArchiveStage.MANIFEST_TOML_WRITTEN,
          f"project.toml geschrieben: {toml_local.name}")

    if request.write_clips_jsonl_file:
        write_clips_jsonl(manifest, jsonl_local)
        _emit(on_event, ArchiveStage.CLIPS_JSONL_WRITTEN,
              f"clips.jsonl geschrieben: {jsonl_local.name}")

    if rclone_target:
        toml_target_uri = _rclone_join(
            request.target_dir, f"{request.target_stem}{request.manifest_suffix}"
        )
        upload_file(
            toml_local, toml_target_uri,
            rclone_path=runtime.rclone_path,
            timeout=runtime.rclone_timeout_seconds,
        )
        if request.write_clips_jsonl_file:
            jsonl_target_uri = _rclone_join(
                request.target_dir, f"{request.target_stem}{request.clips_suffix}"
            )
            upload_file(
                jsonl_local, jsonl_target_uri,
                rclone_path=runtime.rclone_path,
                timeout=runtime.rclone_timeout_seconds,
            )
        # Lokale Stage-Dateien aufräumen
        for p in (toml_local, jsonl_local):
            try:
                p.unlink(missing_ok=True)
            except OSError:
                pass


def _rclone_join(target_dir: str, filename: str) -> str:
    sep = "/" if not target_dir.endswith(":") else ""
    return f"{target_dir.rstrip('/')}{sep}{filename}"


def _emit(
    on_event: Callable[[ArchivarEvent], None] | None,
    stage: ArchiveStage,
    message: str,
) -> None:
    if on_event is None:
        return
    on_event(ArchivarEvent(stage_id=stage.value, message=message))
