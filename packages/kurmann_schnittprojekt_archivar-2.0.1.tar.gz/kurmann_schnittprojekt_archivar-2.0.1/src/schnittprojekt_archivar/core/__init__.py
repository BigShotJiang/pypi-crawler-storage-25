"""Core-Kompositionen ohne Public-API-Fassaden-Schicht."""
