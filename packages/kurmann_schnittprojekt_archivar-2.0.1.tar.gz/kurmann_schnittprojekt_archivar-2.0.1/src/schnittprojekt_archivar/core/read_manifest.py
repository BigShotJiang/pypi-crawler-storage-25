"""Komposition ``read_project_manifest``: liest Schnittprojekt via Leser, mappt aufs Manifest.

Delegiert die gesamte Schnittprojekt-Logik (Format-Detection, FCPXML-/iMovie-
Parsing, Quelldatei-Auflösung, exiftool-Auslese) an ``kurmann-schnittprojekt-
leser >= 0.5``. Wir übernehmen das Ergebnis und konstruieren daraus unser
``ProjectManifest``.
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from schnittprojekt_leser.api import read_project_summary as leser_read_project_summary
from schnittprojekt_leser.models import (
    ReadProjectSummaryRequest,
    ReadProjectSummaryResult,
)
from schnittprojekt_leser.models import (
    RuntimeOptions as LeserRuntimeOptions,
)

from schnittprojekt_archivar.models.errors import ManifestReadError
from schnittprojekt_archivar.models.events import ArchivarEvent, ArchiveStage
from schnittprojekt_archivar.models.manifest import (
    ClipEntry,
    ProjectHeader,
    ProjectManifest,
    SequenceInfo,
)
from schnittprojekt_archivar.models.runtime import RuntimeOptions


def read_project_manifest(
    project_path: Path,
    runtime: RuntimeOptions,
    *,
    include_clips: bool = True,
    timezone_assumption: str | None = None,
    on_event: Callable[[ArchivarEvent], None] | None = None,
    on_output: Callable[[str], None] | None = None,
) -> ProjectManifest:
    """Liest ein Schnittprojekt und liefert ein ``ProjectManifest``.

    Side-Effects: nur die exiftool-Aufrufe und ggf. Source-Resolver-Reads
    des schnittprojekt-leser. Schreibt nichts.

    Args:
        project_path: Pfad zum ``.fcpxmld``-Bundle, ``.fcpxml``-File oder
            ``.iMovieMobile``-ZIP.
        runtime: technische Optionen (exiftool, rclone, Search-Roots).
        include_clips: wenn ``True``, wird das Inventar aller Video-
            Originalmedien gelesen (zeit-intensiv bei vielen Clips).
        timezone_assumption: optionaler IANA-TZ-Name für die Wallclock-Konvertierung
            der Recording-Felder.
        on_event, on_output: Callbacks. ``on_event`` wird auf dem Leser-Bus
            durchgereicht; der Archivar emittiert zusätzlich eigene Stages.

    Raises:
        ManifestReadError: wenn der Leser den Aufruf nicht erfolgreich
            beendet (``ReadProjectSummaryResult.success == False``).
    """
    _emit(on_event, ArchiveStage.MANIFEST_READ_STARTED,
          f"Schnittprojekt lesen: {project_path.name}")

    leser_result = leser_read_project_summary(
        ReadProjectSummaryRequest(
            project_path=project_path,
            timezone_assumption=timezone_assumption,
            include_clips=include_clips,
        ),
        _to_leser_runtime(runtime),
        on_event=_forward_leser_event(on_event),
        on_output=on_output,
    )

    if not leser_result.success:
        raise ManifestReadError(
            f"schnittprojekt-leser konnte Projekt nicht lesen: "
            f"{leser_result.error_message}"
        )

    manifest = _build_manifest_from_leser(leser_result, project_path)
    _emit(on_event, ArchiveStage.MANIFEST_READ_COMPLETED,
          f"Manifest aufgebaut: {len(manifest.clips)} Clip(s) im Inventar")
    return manifest


# ---------------------------------------------------------------------------
# Mapping Leser-Result → ProjectManifest
# ---------------------------------------------------------------------------


def _build_manifest_from_leser(
    leser_result: ReadProjectSummaryResult,
    project_path: Path,
) -> ProjectManifest:
    """Mappt ein ``schnittprojekt-leser``-Result auf unser Manifest-Schema."""
    sequence = SequenceInfo()
    if leser_result.video_resolution:
        sequence.width, sequence.height = leser_result.video_resolution
    sequence.color_space = leser_result.color_space
    sequence.audio_layout = leser_result.audio_layout

    header = ProjectHeader(
        project_name=leser_result.project_name,
        project_format=(
            leser_result.project_format.value if leser_result.project_format else None
        ),
        schema_version=leser_result.schema_version,
        original_filename=project_path.name,
        sequence=sequence,
        clip_count_primary=leser_result.clip_count_primary,
        clip_count_total=leser_result.clip_count_total,
        project_mtime_iso=leser_result.project_mtime_iso,
    )

    if leser_result.recording is not None:
        rec = leser_result.recording
        header.first_clip_date = rec.first_clip_date
        header.first_clip_datetime = rec.first_clip_datetime
        header.first_clip_source_label = rec.first_clip_source_label
        # Confidence ist ein StrEnum — als String abspeichern
        header.first_clip_confidence = (
            rec.first_clip_confidence.value
            if rec.first_clip_confidence is not None
            else None
        )

    clips: list[ClipEntry] = []
    if leser_result.clips is not None:
        for leser_clip in leser_result.clips:
            clips.append(
                ClipEntry(
                    spine_index=leser_clip.spine_index,
                    relative_path=leser_clip.relative_path,
                    asset_id=leser_clip.asset_id,
                    clip_name=leser_clip.clip_name,
                    is_video=leser_clip.is_video,
                    resolution_status=leser_clip.resolution_status,
                    resolved_uri=leser_clip.resolved_uri,
                    media_metadata=leser_clip.media_metadata,
                )
            )

    return ProjectManifest(header=header, clips=clips)


def _to_leser_runtime(runtime: RuntimeOptions) -> LeserRuntimeOptions:
    """Mappt unsere RuntimeOptions auf die des Lesers."""
    return LeserRuntimeOptions(
        exiftool_path=runtime.exiftool_path,
        rclone_path=runtime.rclone_path,
        source_search_roots=list(runtime.source_search_roots),
        source_search_max_depth=runtime.source_search_max_depth,
    )


def _forward_leser_event(
    on_event: Callable[[ArchivarEvent], None] | None,
):
    """Wandelt schnittprojekt-leser-Events in Archivar-Events mit ``leser:``-Prefix."""
    if on_event is None:
        return None

    def forward(leser_event) -> None:
        stage_id = getattr(leser_event, "stage_id", None)
        message = getattr(leser_event, "message", None)
        if not stage_id or not message:
            return
        on_event(ArchivarEvent(
            stage_id=f"leser:{stage_id}",
            message=f"[schnittprojekt-leser] {message}",
        ))

    return forward


def _emit(
    on_event: Callable[[ArchivarEvent], None] | None,
    stage: ArchiveStage,
    message: str,
) -> None:
    if on_event is None:
        return
    on_event(ArchivarEvent(stage_id=stage.value, message=message))
