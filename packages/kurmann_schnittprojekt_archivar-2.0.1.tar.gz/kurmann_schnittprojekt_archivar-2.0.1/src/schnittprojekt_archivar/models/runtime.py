"""Runtime-Optionen — technische Konfiguration für CLI/Konsumenten.

Fachliche Parameter wie ``project_path``, ``target_dir``, ``target_stem``
gehören in den jeweiligen ``Request``; ``RuntimeOptions`` ist rein technisch
(Werkzeug-Pfade, Timeouts, Such-Verzeichnisse).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from kurmann_medien_leser import MediaFileMetadata  # noqa: F401 — Re-Import-Robustheit


@dataclass
class RuntimeOptions:
    """Technische Konfiguration für Archiv-Operationen."""

    exiftool_path: str = "exiftool"
    """Pfad zur exiftool-Binary (PATH-Auflösung wenn Default)."""
    rclone_path: str = "rclone"
    """Pfad zur rclone-Binary (nur relevant bei rclone-Zielen oder rclone-Quellen)."""
    rclone_timeout_seconds: float = 600.0
    """Timeout pro rclone-Aufruf. Bei Multi-GB-Bundle-Uploads grosszügig wählen."""
    source_search_roots: list = field(default_factory=list)
    """Zusätzliche Suchverzeichnisse, die an den ``schnittprojekt-leser``
    für die Auflösung referenzierter Quelldateien weitergereicht werden.
    Inhalt: ``Path`` (lokal) oder ``RcloneSource`` aus schnittprojekt-leser."""
    source_search_max_depth: int = 2
    """Maximale Rekursionstiefe pro Search-Root."""
    work_dir: Path | None = None
    """Arbeitsverzeichnis für Zwischen-Schritte (ZIP-Build, rclone-Stage).
    ``None`` → System-Temp."""
