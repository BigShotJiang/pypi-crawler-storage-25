"""ASCII-Safe-Slug für Archiv-Dateinamen.

Der Archivar wendet Archivierungs-Disziplin per Default an: Ziel-Stems werden
in ASCII-sichere Slugs umgeformt, damit die abgelegten Dateien auf jedem
Filesystem (HFS+, APFS, ext4, NTFS, SMB, NFS) und auf jedem Cloud-Provider
ohne Encoding-Sonderfälle lesbar sind.

**Algorithmus** (vier Schritte):

1. Unicode-Normalisierung auf NFC (kombiniert Diakritika sauber)
2. Deutsche Transliterations-Map: ``ä→ae``, ``ö→oe``, ``ü→ue``, ``ß→ss``
   (Gross-Schreibung analog). Bewusst vor NFKD, damit Umlaute nicht zu
   nackten Vokalen werden, sondern die deutsche Schreibweise behalten.
3. NFKD + ASCII-Encode mit ``errors="ignore"``: entfernt restliche
   Diakritika (z. B. französisches ``é``→``e``) und Nicht-ASCII-Zeichen.
4. Regex ``[^a-zA-Z0-9]+`` → ``-``: jede nicht-alphanumerische Sequenz
   wird zu einem Bindestrich kollabiert. Führende/abschliessende
   Bindestriche werden gestrippt.

Idempotent: ``to_archive_stem(to_archive_stem(x)) == to_archive_stem(x)``.

**Codespiegelung-Hinweis**: Diese Logik existiert 1:1 auch in
``familienfilm_manager/core/archiver.py:_to_ascii_slug``. Solange es nur zwei
Konsumenten gibt, ist Spiegelung billiger als ein gemeinsames Helper-Repo.
Sobald ein dritter Konsument hinzukommt (oder PAR2/ZIP64-Helpers gebündelt
werden sollen), lohnt sich ein ``kurmann-archiv-utils`` als gemeinsame Quelle.
"""

from __future__ import annotations

import re
import unicodedata

_GERMAN_TRANSLITERATION: dict[str, str] = {
    "ä": "ae",
    "ö": "oe",
    "ü": "ue",
    "ß": "ss",
    "Ä": "Ae",
    "Ö": "Oe",
    "Ü": "Ue",
}

_NON_ALNUM_RE = re.compile(r"[^a-zA-Z0-9]+")


def to_archive_stem(text: str) -> str:
    """Wandelt einen freien String in einen archivtauglichen ASCII-Stem um.

    Beispiele::

        to_archive_stem("Mädchen spazieren")        # "Maedchen-spazieren"
        to_archive_stem("Café crème")               # "Cafe-creme"
        to_archive_stem("2026-05-10 – Höhenflug")   # "2026-05-10-Hoehenflug"
        to_archive_stem("___bereits-clean___")      # "bereits-clean"

    Leerstring oder ein String, der vollständig aus Nicht-ASCII-Müll besteht,
    liefert ``""`` zurück — der Caller entscheidet, ob das ein Fehler ist.
    """
    text = unicodedata.normalize("NFC", text)
    for char, replacement in _GERMAN_TRANSLITERATION.items():
        text = text.replace(char, replacement)
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = _NON_ALNUM_RE.sub("-", text)
    return text.strip("-")


def is_archive_safe_stem(text: str) -> bool:
    """Prüft, ob ``text`` bereits ein archivtauglicher Stem ist.

    Wahr genau dann, wenn ``to_archive_stem(text) == text`` — also wenn die
    Slug-Funktion an dem Wert nichts mehr zu ändern hat.
    """
    return to_archive_stem(text) == text
