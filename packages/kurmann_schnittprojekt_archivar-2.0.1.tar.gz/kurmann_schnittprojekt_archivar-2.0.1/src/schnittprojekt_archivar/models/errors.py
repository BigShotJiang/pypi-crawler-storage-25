"""Exception-Hierarchie des Archivars.

Werden in den Services geworfen und in der API-Fassade gefangen, um sie
auf ``error_message`` im Result abzubilden — Konsumenten sehen keine
Stack-Traces, sondern handlungsanweisende Texte.
"""

from __future__ import annotations


class SchnittprojektArchivarError(RuntimeError):
    """Basisklasse aller Fehler dieser Bibliothek."""


class ManifestReadError(SchnittprojektArchivarError):
    """Schnittprojekt konnte nicht gelesen oder Manifest nicht aufgebaut werden."""


class BundleError(SchnittprojektArchivarError):
    """Bundle-Packaging fehlgeschlagen (ZIP-Build, Datei-Kopie, etc.)."""


class ArchiveTargetError(SchnittprojektArchivarError):
    """Probleme mit dem Archiv-Ziel (Pfad ungültig, rclone-Fehler, etc.)."""


class ArchiveTargetExistsError(ArchiveTargetError):
    """Ziel-Datei existiert bereits — Aufruf ohne ``overwrite=True``."""
