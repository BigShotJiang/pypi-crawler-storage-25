"""Manifest-Datenmodell: was im ``.project.toml`` und ``.project.clips.jsonl`` landet.

In-memory-Form: ``ProjectManifest`` als Top-Level-Container; serialisiert
sich via ``to_toml_dict`` (für ``.project.toml``) und ``to_jsonl_lines``
(für ``.project.clips.jsonl``).

Das Schema ist **bewusst flach gehalten** und kompatibel zum
``kamera-einleser``-Manifest, damit Cross-References (welche ISO-Clips
wurden in welchem Projekt verwendet?) ohne Schema-Übersetzung möglich sind.
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from kurmann_medien_leser import MediaFileMetadata

# Schema-Version des Manifest-Formats. Wird in beide Sidecar-Files geschrieben.
MANIFEST_FORMAT_VERSION = 1


def _now_iso() -> str:
    """Aktueller Zeitstempel als ISO-8601 mit lokaler TZ."""
    return datetime.now(tz=timezone.utc).astimezone().isoformat(timespec="seconds")


@dataclass
class SequenceInfo:
    """Sequenz-Metadaten (Auflösung, FPS, Farbraum, Audio-Layout)."""

    width: int | None = None
    height: int | None = None
    fps: float | None = None
    color_space: str | None = None
    audio_layout: str | None = None

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if v not in (None, "")}


@dataclass
class ProjectHeader:
    """Aggregierte Projekt-Header — alles, was sich ins ``.project.toml`` faltet.

    Das Recording-Datum kommt vom ``schnittprojekt_leser``; die Confidence-
    Klassifizierung bleibt eine konsumenten-spezifische Bewertung (HIGH/MEDIUM/
    LOW/UNKNOWN) und wird hier als String mit übernommen.
    """

    project_name: str | None = None
    project_format: str | None = None  # ``fcpxml_bundle`` | ``fcpxml_file`` | ``imovie_mobile_zip``
    schema_version: str | None = None
    original_filename: str | None = None

    # Recording (delegate von schnittprojekt_leser.ProjectRecordingInfo)
    first_clip_date: str | None = None
    first_clip_datetime: str | None = None
    first_clip_source_label: str | None = None
    first_clip_confidence: str | None = None

    # Sequenz / Counts
    sequence: SequenceInfo = field(default_factory=SequenceInfo)
    clip_count_primary: int | None = None
    clip_count_total: int | None = None

    # Original-Filesystem-mtime der Projektdatei
    project_mtime_iso: str | None = None


@dataclass
class ClipEntry:
    """Ein Eintrag im ``.project.clips.jsonl`` — eine referenzierte Video-Originaldatei.

    Spiegelt die ``ProjectClipReference``-Struktur des schnittprojekt-leser,
    plus die volle ``MediaFileMetadata`` aus dem medien-leser (wenn aufgelöst).
    """

    spine_index: int
    relative_path: str
    asset_id: str | None = None
    clip_name: str | None = None
    is_video: bool = True
    resolution_status: str = "skipped"   # ``resolved`` | ``not_found`` | ``skipped``
    resolved_uri: str | None = None
    media_metadata: "MediaFileMetadata | None" = None

    def to_dict(self) -> dict:
        d: dict = {
            "spine_index": self.spine_index,
            "relative_path": self.relative_path,
            "is_video": self.is_video,
            "resolution_status": self.resolution_status,
        }
        if self.asset_id is not None:
            d["asset_id"] = self.asset_id
        if self.clip_name is not None:
            d["clip_name"] = self.clip_name
        if self.resolved_uri is not None:
            d["resolved_uri"] = self.resolved_uri
        if self.media_metadata is not None:
            d["media_metadata"] = self.media_metadata.to_dict()
        return d


@dataclass
class ProjectManifest:
    """Top-Level-Container: Header + Clips + Bundle-Info.

    In-memory-Repräsentation, persistierbar via ``write_manifest_toml`` und
    ``write_clips_jsonl``.

    ``bundle_filename`` und ``bundle_size_bytes`` werden vom ``package_project_bundle``-
    Schritt nachträglich befüllt — ``read_project_manifest`` allein lässt sie ``None``.
    """

    header: ProjectHeader
    clips: list[ClipEntry] = field(default_factory=list)
    bundle_filename: str | None = None
    bundle_size_bytes: int | None = None
    generator: str = "Kurmann Schnittprojekt-Archivar"
    generator_version: str = "2.0.1"
    created_at: str = field(default_factory=_now_iso)
    manifest_version: int = MANIFEST_FORMAT_VERSION

    # ------------------------------------------------------------------
    # Persistierungs-Helfer
    # ------------------------------------------------------------------

    def to_toml_dict(self) -> dict:
        """Aggregierte Form für ``.project.toml``."""
        d: dict = {
            "meta": {
                "schema_version": self.manifest_version,
                "generator": f"{self.generator} {self.generator_version}",
                "created_at": self.created_at,
            },
            "project": _drop_none({
                "name": self.header.project_name,
                "format": self.header.project_format,
                "schema_version": self.header.schema_version,
                "original_filename": self.header.original_filename,
            }),
            "recording": _drop_none({
                "first_clip_date": self.header.first_clip_date,
                "first_clip_datetime": self.header.first_clip_datetime,
                "first_clip_source_label": self.header.first_clip_source_label,
                "first_clip_confidence": self.header.first_clip_confidence,
            }),
            "sequence": self.header.sequence.to_dict(),
            "counts": _drop_none({
                "clips_primary": self.header.clip_count_primary,
                "clips_total": self.header.clip_count_total,
            }),
        }
        if self.header.project_mtime_iso is not None:
            d["project"]["mtime"] = self.header.project_mtime_iso
        if self.bundle_filename is not None or self.bundle_size_bytes is not None:
            d["bundle"] = _drop_none({
                "archive_filename": self.bundle_filename,
                "archive_size_bytes": self.bundle_size_bytes,
            })
        # Leere Subsektionen weglassen, damit das TOML schlank bleibt
        return {k: v for k, v in d.items() if v}

    def to_jsonl_lines(self) -> Iterator[dict]:
        """JSONL-Repräsentation für ``.project.clips.jsonl``: Header-Zeile + n Clip-Zeilen."""
        yield {
            "_type": "header",
            "manifest_version": self.manifest_version,
            "project_name": self.header.project_name,
            "project_format": self.header.project_format,
            "clip_count": len(self.clips),
            "generator": f"{self.generator} {self.generator_version}",
            "created_at": self.created_at,
        }
        for clip in self.clips:
            yield clip.to_dict()


def _drop_none(d: dict) -> dict:
    """Entfernt None-/leere Werte aus einem Dict — für schlanke Serialisierung."""
    return {k: v for k, v in d.items() if v is not None and v != ""}
