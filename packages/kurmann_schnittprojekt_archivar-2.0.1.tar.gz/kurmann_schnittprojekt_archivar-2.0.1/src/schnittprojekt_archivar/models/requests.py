"""Request- und Result-Datentypen der Public-API."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from schnittprojekt_archivar.models.suffixes import (
    CLIPS_JSONL_SUFFIX,
    PROJECT_TOML_SUFFIX,
)


@dataclass
class ArchiveProjectRequest:
    """Anfrage: ein Schnittprojekt komplett archivieren (Bundle + Manifest)."""

    project_path: Path
    target_dir: str
    """rclone-URI (z. B. ``nas:/Archiv/...``) oder lokaler Pfad."""
    target_stem: str
    """Gewünschter Stem ohne Endung — Caller bestimmt den Wunsch-Namen.
    Bsp.: ``"2026-05-10-Maedchen-spazieren"`` oder auch ``"Mädchen spazieren"``.

    Der Archivar wendet per Default ``to_archive_stem`` an und macht daraus
    einen archivtauglichen ASCII-Slug. Über ``strict_stem=True`` lässt sich
    diese Disziplin abschalten (dann muss der Caller selbst sicherstellen,
    dass der Stem ASCII-safe ist — sonst ``ValueError``)."""
    strict_stem: bool = False
    """Wenn ``True``: ``target_stem`` wird **nicht** durch ``to_archive_stem``
    gefiltert. Stattdessen wird geprüft, dass er bereits archivtauglich ist
    (``is_archive_safe_stem``). Schlägt das fehl, wird ein ``ValueError``
    geworfen, bevor irgendetwas geschrieben wird. Default ``False``: der
    Archivar slugifiziert stillschweigend und meldet die Umformung im Result."""
    manifest_suffix: str = PROJECT_TOML_SUFFIX
    """Suffix für das aggregierte Manifest (Default ``.project.toml``)."""
    clips_suffix: str = CLIPS_JSONL_SUFFIX
    """Suffix für das Clip-Inventar (Default ``.project.clips.jsonl``)."""
    write_clips_jsonl_file: bool = True
    """Wenn ``False``: keine ``.project.clips.jsonl``-Datei schreiben (Caller bettet
    das Inventar selbst in eine andere Struktur ein)."""
    include_clips: bool = True
    """Wenn ``False``: kein Clip-Inventar lesen (auch wenn
    ``write_clips_jsonl_file=True`` — die geschriebene Datei wäre dann leer)."""
    overwrite: bool = False
    """Wenn ``False`` und Ziel-Datei(en) existieren bereits: ``ArchiveTargetExistsError``."""
    allow_flat_fcpxml_if_bundle_sibling: bool = False
    """Wenn ``False`` (Default): Mehrdeutigkeit zwischen ``.fcpxml`` und
    gleichnamigem ``.fcpxmld``-Bundle-Verzeichnis wird hart abgebrochen.
    Der Caller muss bewusst entscheiden, welches gemeint ist.

    Wenn ``True``: die ``.fcpxml`` wird auch dann archiviert, wenn ein
    Bundle-Geschwister daneben liegt. Wird in der CLI über
    ``--allow-flat-fcpxml`` gesetzt."""
    timezone_assumption: str | None = None
    """An den ``schnittprojekt-leser`` durchgereicht für Wallclock-TZ-Konvertierung."""


@dataclass
class PackageResult:
    """Ergebnis des Bundle-Packagings."""

    success: bool
    bundle_filename: str | None = None
    """Datei-Name im Ziel (mit Endung), wenn erfolgreich."""
    bundle_size_bytes: int | None = None
    """Grösse der erzeugten Bundle-Datei. Bei FCPXML-Bundle: ZIP-Größe.
    Bei iMovieMobile / FCPXML-Single: Dateigrösse 1:1."""
    target_uri: str | None = None
    """Voller URI/Pfad zur abgelegten Datei."""
    error_message: str | None = None


@dataclass
class ArchiveProjectResult:
    """Ergebnis einer ``archive_project``-Operation."""

    success: bool
    bundle: PackageResult | None = None
    manifest_toml_written: bool = False
    clips_jsonl_written: bool = False
    effective_stem: str | None = None
    """Der nach Slug-Disziplin tatsächlich verwendete Stem (entspricht
    ``target_stem``, falls dieser schon archivtauglich war)."""
    original_stem: str | None = None
    """Der ursprünglich angefragte ``target_stem``, falls vom Archivar
    umgeformt wurde. ``None``, wenn keine Umformung nötig war."""
    stem_was_slugified: bool = False
    """``True`` genau dann, wenn ``to_archive_stem`` den ``target_stem``
    verändert hat."""
    error_message: str | None = None
    warnings: list[str] = field(default_factory=list)
