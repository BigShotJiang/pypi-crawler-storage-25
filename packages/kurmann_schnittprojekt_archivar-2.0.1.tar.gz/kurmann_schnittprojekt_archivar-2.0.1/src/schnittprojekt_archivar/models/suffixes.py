"""Suffix-Konstanten für Archiv-Dateien.

Diese Strings sind **Empfehlungen**, keine Pflicht. Die High-Level-API
``archive_project`` nimmt sie als Default-Parameter; Konsumenten können
beim Aufruf andere Suffixe wählen oder die Low-Level-API
(``package_project_bundle`` + ``write_manifest_toml`` + ``write_clips_jsonl``)
nutzen, um ihre eigene Persistierungs-Strategie zu implementieren.

**Namespace-Disziplin**: alle Sidecars dieser Library leben unter ``.project.*``
— so kollidieren sie nicht mit FFM-Sidecars (``.video.*``), wenn beide
Sätze im selben Verzeichnis liegen. Cross-References über den ``<stem>``.
"""

from __future__ import annotations

# Manifest-Sidecars (immer mit `<stem>` davor)
PROJECT_TOML_SUFFIX = ".project.toml"
"""Aggregierte Projekt-Metadaten (TOML, eine Datei pro Projekt).

Konvention analog zu FFM ``.video.toml``: ``.<domäne>.toml`` ist das
Haupt-Manifest der Domäne (= „Metadaten ohne weiteren Zusatz")."""

CLIPS_JSONL_SUFFIX = ".project.clips.jsonl"
"""Inventar der referenzierten Clips des Schnittprojekts (JSONL).

``clips`` bezeichnet hier das **Schnittprojekt-Konzept** — was im FCPXML
als ``<asset-clip>`` und im iMovieMobile als ``editList[i]`` lebt. Pro
Eintrag wird die volle ``MediaFileMetadata`` aus ``kurmann-medien-leser``
mitgeführt; bei Erweiterung des medien-leser auf Audio-/Foto-Schemas
bleibt der Begriff „Clip" korrekt (auch Audio-Subspuren sind Clips
im Schnitt-Sinn).

Namespace-Präfix ``.project.*`` zeigt: dieses Inventar gehört zur
Schnittprojekt-Domäne (nicht zur Video-Export-Domäne des FFM)."""

# Bundle-Endungen je nach Quellformat
FCPXML_BUNDLE_ZIP_SUFFIX = ".fcpxmld.zip"
"""FCPXML-Bundle als ZIP-Container (ZIP_STORED + allowZip64)."""

FCPXML_SINGLE_SUFFIX = ".fcpxml"
"""FCPXML-Single-File — 1:1-Kopie ohne Container."""

IMOVIE_MOBILE_SUFFIX = ".iMovieMobile"
"""iMovieMobile-Bundle — ist schon ZIP, wird 1:1 ohne erneutes Zippen kopiert."""
