"""Drei-Kanal-Events des Archivars.

Stage-IDs sind auf Englisch (stabil für Host-Matching, gemäss Atelier ADR-0009);
``message`` ist auf Deutsch (menschenlesbar für CLI/Logs).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


@dataclass(frozen=True)
class ArchivarEvent:
    """Strukturierter Zwischenzustand während einer Archiv-Operation."""

    stage_id: str
    message: str
    current: int | None = None
    total: int | None = None


class ArchiveStage(StrEnum):
    """Stages der ``archive_project``-Operation."""

    # Slug-Disziplin
    STEM_SLUGIFIED = "stem_slugified"
    # Read-Phase (delegiert zu schnittprojekt-leser)
    MANIFEST_READ_STARTED = "manifest_read_started"
    MANIFEST_READ_COMPLETED = "manifest_read_completed"
    # Bundle-Phase
    BUNDLE_BUILD_STARTED = "bundle_build_started"
    BUNDLE_BUILD_COMPLETED = "bundle_build_completed"
    BUNDLE_UPLOAD_STARTED = "bundle_upload_started"
    BUNDLE_UPLOAD_COMPLETED = "bundle_upload_completed"
    # Manifest-Persistierung
    MANIFEST_TOML_WRITTEN = "manifest_toml_written"
    CLIPS_JSONL_WRITTEN = "clips_jsonl_written"
    # Verifikation / Cleanup
    TARGET_VERIFIED = "target_verified"
    ARCHIVE_COMPLETED = "archive_completed"
