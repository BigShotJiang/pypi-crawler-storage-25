"""Geteilte Datentypen des Archivars."""

from schnittprojekt_archivar.models.errors import (
    ArchiveTargetError,
    ArchiveTargetExistsError,
    BundleError,
    ManifestReadError,
    SchnittprojektArchivarError,
)
from schnittprojekt_archivar.models.events import ArchivarEvent, ArchiveStage
from schnittprojekt_archivar.models.manifest import (
    ClipEntry,
    ProjectHeader,
    ProjectManifest,
    SequenceInfo,
)
from schnittprojekt_archivar.models.requests import (
    ArchiveProjectRequest,
    ArchiveProjectResult,
    PackageResult,
)
from schnittprojekt_archivar.models.runtime import RuntimeOptions
from schnittprojekt_archivar.models.suffixes import (
    CLIPS_JSONL_SUFFIX,
    FCPXML_BUNDLE_ZIP_SUFFIX,
    FCPXML_SINGLE_SUFFIX,
    IMOVIE_MOBILE_SUFFIX,
    PROJECT_TOML_SUFFIX,
)

__all__ = [
    # Manifest
    "ProjectManifest",
    "ProjectHeader",
    "ClipEntry",
    "SequenceInfo",
    # Requests / Results
    "ArchiveProjectRequest",
    "ArchiveProjectResult",
    "PackageResult",
    # Runtime
    "RuntimeOptions",
    # Events
    "ArchivarEvent",
    "ArchiveStage",
    # Errors
    "SchnittprojektArchivarError",
    "BundleError",
    "ManifestReadError",
    "ArchiveTargetError",
    "ArchiveTargetExistsError",
    # Suffixes
    "PROJECT_TOML_SUFFIX",
    "CLIPS_JSONL_SUFFIX",
    "FCPXML_BUNDLE_ZIP_SUFFIX",
    "FCPXML_SINGLE_SUFFIX",
    "IMOVIE_MOBILE_SUFFIX",
]
