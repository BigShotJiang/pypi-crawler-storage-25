"""Persistierungs-Helfer: ``ProjectManifest`` → TOML / JSONL.

Beide Schreiber sind atomar (write-to-tempfile + ``os.replace``), damit
ein Crash mitten im Write keine kaputten Sidecar-Files hinterlässt.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

from schnittprojekt_archivar.models.manifest import ProjectManifest


def write_manifest_toml(manifest: ProjectManifest, target_path: Path) -> None:
    """Schreibt das aggregierte Manifest als TOML (atomar)."""
    content = _to_toml_string(manifest.to_toml_dict())
    _atomic_write_text(target_path, content)


def write_clips_jsonl(manifest: ProjectManifest, target_path: Path) -> None:
    """Schreibt das Clip-Inventar als JSONL (atomar).

    Erste Zeile ist der Header (``_type=header``); danach pro Clip eine Zeile.
    Wenn die Clip-Liste leer ist, wird trotzdem die Header-Zeile geschrieben —
    Konsumenten erkennen „keine Clips" am ``clip_count: 0``.
    """
    lines: list[str] = []
    for entry in manifest.to_jsonl_lines():
        lines.append(json.dumps(entry, ensure_ascii=False, default=str))
    _atomic_write_text(target_path, "\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# Hilfs-Funktionen
# ---------------------------------------------------------------------------


def _atomic_write_text(path: Path, content: str) -> None:
    """Atomares Schreiben über tempfile + os.replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(
        prefix=f".{path.name}.",
        suffix=".tmp",
        dir=path.parent,
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _to_toml_string(data: dict) -> str:
    """Serialisiert ein flaches Dict (mit Sub-Tabellen) zu TOML.

    Bewusst eigene minimale Implementation statt einer externen Library
    (``tomli-w`` etc.), weil unser Manifest-Schema eng kontrolliert ist
    (nur Strings, Ints, Floats, Bools, Dicts auf einer Ebene). Damit
    bleibt die Library zero-deps für TOML-Schreiben.
    """
    lines: list[str] = []
    # Top-Level-Sektionen in stabiler Reihenfolge schreiben
    section_order = ["meta", "project", "recording", "sequence", "counts", "bundle"]
    for section in section_order:
        if section not in data:
            continue
        sub = data[section]
        if not sub:
            continue
        if lines:
            lines.append("")
        lines.append(f"[{section}]")
        for key, value in sub.items():
            lines.append(f"{key} = {_format_toml_value(value)}")
    return "\n".join(lines) + "\n"


def _format_toml_value(value) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return repr(value)
    if isinstance(value, str):
        return _emit_toml_string(value)
    if isinstance(value, list):
        items = ", ".join(_format_toml_value(v) for v in value)
        return f"[{items}]"
    # Fallback: als String escapen
    return _emit_toml_string(str(value))


def _emit_toml_string(value: str) -> str:
    """TOML-Basic-String mit Escapes für Umlaute, Quotes, Newlines."""
    escaped = (
        value.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
    )
    return f'"{escaped}"'
