"""Datei-Copy-Helfer für 1:1-Kopien (iMovieMobile, FCPXML-Single-File).

Atomares Schreiben über ``<target>.tmp.<random>`` + ``os.replace`` —
dasselbe Pattern wie der ZIP-Builder. Damit ist eine teilweise gefüllte
Ziel-Datei bei Crash ausgeschlossen.

Für ZIP-Builds gibt es ``zip_builder.build_fcpxml_bundle_zip``; dieser
Helper ist nur für Format-treue Single-File-Kopien.
"""

from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path

from schnittprojekt_archivar.models.errors import BundleError


def atomic_copy_file(source: Path, target: Path, *, overwrite: bool = False) -> int:
    """Kopiert ``source`` atomar nach ``target``.

    Args:
        source: Quelldatei (muss eine Datei sein, kein Verzeichnis).
        target: Zielpfad. Bei ``overwrite=False`` Fehler wenn vorhanden.
        overwrite: Erzwinge Überschreiben.

    Returns:
        Grösse der kopierten Datei in Bytes.

    Raises:
        BundleError: bei Verzeichnis-Quelle, existierendem Ziel (ohne
            ``overwrite``) oder OS-Fehler.
    """
    if not source.exists() or not source.is_file():
        raise BundleError(f"Quelle ist keine Datei: {source}")
    if target.exists() and not overwrite:
        raise BundleError(
            f"Ziel existiert bereits: {target} "
            f"(mit overwrite=True erzwingen)"
        )

    target.parent.mkdir(parents=True, exist_ok=True)

    tmp_fd, tmp_path_str = tempfile.mkstemp(
        prefix=f".{target.name}.",
        suffix=".tmp",
        dir=str(target.parent),
    )
    os.close(tmp_fd)
    tmp_path = Path(tmp_path_str)

    try:
        shutil.copy2(source, tmp_path)  # copy2 erhält mtime
        os.replace(tmp_path, target)
    except Exception as exc:
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise BundleError(
            f"Datei-Kopie fehlgeschlagen für {source.name}: {exc}"
        ) from exc

    return target.stat().st_size
