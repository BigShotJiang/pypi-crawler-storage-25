"""Side-Effect-Implementierungen (ZIP-Bau, rclone-Upload, Manifest-Persistierung)."""
