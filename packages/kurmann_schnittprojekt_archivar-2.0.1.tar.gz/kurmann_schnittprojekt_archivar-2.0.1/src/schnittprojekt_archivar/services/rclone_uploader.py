"""rclone-Uploader für Archiv-Ziele.

Wenn ``target_dir`` ein rclone-URI ist (Format ``remote:path``), wird die
lokal aufgebaute Bundle-Datei am Ende via ``rclone copyto`` ins Ziel
übertragen. Bei lokalen Zielen entfällt rclone komplett.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from schnittprojekt_archivar.models.errors import ArchiveTargetError


def is_rclone_uri(target: str) -> bool:
    """Heuristik: rclone-Remote-Spec sieht aus wie ``remote:path``.

    Konkret: vor dem ersten ``:`` steht ein Bezeichner (keine Slashes),
    und es ist nicht ein Windows-Drive-Letter (``C:\\...``).
    """
    if ":" not in target:
        return False
    head, _, _ = target.partition(":")
    if not head or "/" in head or "\\" in head:
        return False
    # Windows-Drive-Letter (z.B. ``C:``) ist nur ein Buchstabe → unwahrscheinlich
    # für rclone-Remote-Namen, die typisch mehrstellig sind.
    if len(head) == 1 and head.isalpha():
        return False
    return True


def upload_file(
    local_path: Path,
    target_uri: str,
    *,
    rclone_path: str = "rclone",
    timeout: float = 600.0,
) -> None:
    """Lädt ``local_path`` via ``rclone copyto`` nach ``target_uri``.

    Args:
        local_path: lokal aufgebaute Datei.
        target_uri: voller rclone-URI inkl. Ziel-Filename
            (z. B. ``nas:/Archiv/2026/Projekte/<stem>.fcpxmld.zip``).
        rclone_path: Pfad zur rclone-Binary.
        timeout: Sekunden — bei Multi-GB-Uploads grosszügig wählen.

    Raises:
        ArchiveTargetError: bei rclone-Fehler oder fehlender Binary.
    """
    if not shutil.which(rclone_path):
        raise ArchiveTargetError(
            f"rclone nicht gefunden: {rclone_path}. "
            f"Installation: `brew install rclone` (macOS)."
        )
    cmd = [rclone_path, "copyto", str(local_path), target_uri]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        raise ArchiveTargetError(
            f"rclone-Timeout nach {timeout}s beim Upload von {local_path.name}"
        ) from exc

    if proc.returncode != 0:
        raise ArchiveTargetError(
            f"rclone copyto fehlgeschlagen: "
            f"{(proc.stderr or proc.stdout).strip()[:500]}"
        )


def remote_file_exists(
    target_uri: str,
    *,
    rclone_path: str = "rclone",
    timeout: float = 60.0,
) -> bool:
    """Prüft via ``rclone lsf``, ob eine Datei am Ziel existiert."""
    if not shutil.which(rclone_path):
        return False
    cmd = [rclone_path, "lsf", target_uri]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return False
    if proc.returncode != 0:
        return False
    return bool(proc.stdout.strip())
