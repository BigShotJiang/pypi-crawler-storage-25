"""ZIP-Builder für FCPXML-Bundle-Verzeichnisse.

Verwendet ``ZIP_STORED`` (keine Kompression) plus ``allowZip64=True`` —
dieselbe Strategie wie ``kamera-einleser``:

- **Streaming ohne Staging**: schreibt direkt aus den Quellpfaden in die ZIP
- **ZIP64 implizit**: Files > 4 GB und ZIPs > 4 GB total sind unterstützt
- **Atomarität**: Build geht in ``<target>.tmp.<random>``, am Ende ``os.replace``
- **mtime erhalten**: Source-mtime jedes Files wandert in den ZIP-Member-Header
  (FAT-Format, 2-Sekunden-Granularität)
- **Determinismus**: Member werden alphabetisch nach arcname sortiert

Warum ``ZIP_STORED`` und nicht ``ZIP_DEFLATED``? FCPXML-Bundles enthalten primär
bereits komprimierte Medien (HEVC, ProRes); Kompression bringt dort wenig
und kostet CPU-Zeit. Die FCPXML-XML-Datei selbst ist meist nur wenige MB,
also vernachlässigbar.
"""

from __future__ import annotations

import os
import tempfile
import zipfile
from collections.abc import Callable
from pathlib import Path

from schnittprojekt_archivar.models.errors import BundleError


def build_fcpxml_bundle_zip(
    bundle_dir: Path,
    target_zip: Path,
    *,
    overwrite: bool = False,
    on_progress: Callable[[str, int, int], None] | None = None,
) -> int:
    """Verpackt ein ``.fcpxmld``-Verzeichnis in ein ZIP-Container.

    Args:
        bundle_dir: Pfad zum ``.fcpxmld``-Verzeichnis (auf macOS ein "Package",
            für uns ein normales Verzeichnis mit Dateien drin).
        target_zip: Ziel-Pfad für das ZIP. Muss lokal sein — rclone-Upload
            kommt anschliessend in einem separaten Schritt.
        overwrite: Wenn ``False`` und das Ziel existiert: ``BundleError``.
        on_progress: optionaler Callback ``(arcname, current_index, total)``.

    Returns:
        Grösse der erzeugten ZIP-Datei in Bytes.

    Raises:
        BundleError: wenn die Quelle kein Verzeichnis ist, das Ziel existiert
            (ohne ``overwrite=True``) oder ein OS-Fehler auftritt.
    """
    if not bundle_dir.exists() or not bundle_dir.is_dir():
        raise BundleError(
            f"Bundle-Quelle ist kein Verzeichnis: {bundle_dir}"
        )
    if target_zip.exists() and not overwrite:
        raise BundleError(
            f"Ziel-ZIP existiert bereits: {target_zip} "
            f"(mit overwrite=True erzwingen)"
        )

    target_zip.parent.mkdir(parents=True, exist_ok=True)

    # Member sammeln: alle regulären Dateien rekursiv. arcname behält die
    # Bundle-Struktur ab dem .fcpxmld-Verzeichnis-Namen.
    bundle_root_name = bundle_dir.name  # z.B. "Mädchen spazieren.fcpxmld"
    members: list[tuple[Path, str]] = []
    for path in bundle_dir.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(bundle_dir)
        arcname = f"{bundle_root_name}/{rel.as_posix()}"
        members.append((path, arcname))

    if not members:
        raise BundleError(
            f"Bundle-Verzeichnis ist leer: {bundle_dir}"
        )

    # Alphabetisch sortieren für Determinismus.
    members.sort(key=lambda m: m[1])

    # In <target>.tmp.<random> schreiben, dann os.replace.
    tmp_fd, tmp_path_str = tempfile.mkstemp(
        prefix=f".{target_zip.name}.",
        suffix=".tmp",
        dir=str(target_zip.parent),
    )
    os.close(tmp_fd)
    tmp_path = Path(tmp_path_str)

    try:
        with zipfile.ZipFile(
            tmp_path,
            mode="w",
            compression=zipfile.ZIP_STORED,
            allowZip64=True,
        ) as zf:
            total = len(members)
            for idx, (source_path, arcname) in enumerate(members, start=1):
                zf.write(source_path, arcname=arcname)
                if on_progress is not None:
                    on_progress(arcname, idx, total)

        os.replace(tmp_path, target_zip)
    except Exception as exc:
        # Tempfile aufräumen
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise BundleError(
            f"ZIP-Build fehlgeschlagen für {bundle_dir.name}: {exc}"
        ) from exc

    return target_zip.stat().st_size
