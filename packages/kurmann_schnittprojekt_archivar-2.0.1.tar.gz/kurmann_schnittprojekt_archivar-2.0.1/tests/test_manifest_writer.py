"""Tests für die Manifest-Persistierungs-Helfer."""

from __future__ import annotations

import json
import tomllib
from pathlib import Path

from schnittprojekt_archivar.models.manifest import (
    ClipEntry,
    ProjectHeader,
    ProjectManifest,
    SequenceInfo,
)
from schnittprojekt_archivar.services.manifest_writer import (
    write_clips_jsonl,
    write_manifest_toml,
)


def _sample_manifest() -> ProjectManifest:
    header = ProjectHeader(
        project_name="Mädchen spazieren",
        project_format="fcpxml_bundle",
        schema_version="1.8",
        original_filename="Mädchen spazieren.fcpxmld",
        first_clip_date="2026-05-10",
        first_clip_datetime="2026-05-10T07:26:14+02:00",
        first_clip_source_label="exif:Keys:CreationDate",
        first_clip_confidence="high",
        sequence=SequenceInfo(width=3840, height=2160, fps=60.0, color_space="HDR"),
        clip_count_primary=2,
        clip_count_total=2,
    )
    clips = [
        ClipEntry(
            spine_index=0,
            relative_path="./A001.mov",
            asset_id="a1",
            clip_name="A001",
            resolution_status="resolved",
            resolved_uri="/abs/path/A001.mov",
        ),
        ClipEntry(
            spine_index=1,
            relative_path="./B002.mov",
            asset_id="b1",
            clip_name="B002",
            resolution_status="not_found",
        ),
    ]
    return ProjectManifest(
        header=header, clips=clips,
        bundle_filename="2026-05-10-Maedchen.fcpxmld.zip",
        bundle_size_bytes=12345,
    )


def test_write_manifest_toml_roundtrip(tmp_path: Path):
    target = tmp_path / "out.project.toml"
    write_manifest_toml(_sample_manifest(), target)

    assert target.exists()
    data = tomllib.loads(target.read_text(encoding="utf-8"))
    assert data["meta"]["schema_version"] == 1
    assert data["project"]["name"] == "Mädchen spazieren"
    assert data["project"]["format"] == "fcpxml_bundle"
    assert data["recording"]["first_clip_date"] == "2026-05-10"
    assert data["recording"]["first_clip_datetime"] == "2026-05-10T07:26:14+02:00"
    assert data["sequence"]["width"] == 3840
    assert data["sequence"]["height"] == 2160
    assert data["counts"]["clips_primary"] == 2
    assert data["bundle"]["archive_filename"] == "2026-05-10-Maedchen.fcpxmld.zip"
    assert data["bundle"]["archive_size_bytes"] == 12345


def test_write_manifest_toml_escapes_umlauts(tmp_path: Path):
    """Umlaute werden korrekt UTF-8-encoded geschrieben."""
    target = tmp_path / "out.project.toml"
    write_manifest_toml(_sample_manifest(), target)

    raw = target.read_text(encoding="utf-8")
    assert "Mädchen" in raw  # Direkt als Unicode, nicht escaped


def test_write_clips_jsonl_basic(tmp_path: Path):
    target = tmp_path / "out.clips.jsonl"
    write_clips_jsonl(_sample_manifest(), target)

    lines = target.read_text(encoding="utf-8").strip().split("\n")
    # Header + 2 Clip-Zeilen
    assert len(lines) == 3
    header = json.loads(lines[0])
    assert header["_type"] == "header"
    assert header["clip_count"] == 2
    assert header["project_name"] == "Mädchen spazieren"

    clip0 = json.loads(lines[1])
    assert clip0["spine_index"] == 0
    assert clip0["asset_id"] == "a1"
    assert clip0["resolution_status"] == "resolved"

    clip1 = json.loads(lines[2])
    assert clip1["resolution_status"] == "not_found"


def test_write_clips_jsonl_empty(tmp_path: Path):
    """Auch ohne Clips wird mindestens die Header-Zeile geschrieben."""
    manifest = _sample_manifest()
    manifest.clips = []
    target = tmp_path / "out.clips.jsonl"
    write_clips_jsonl(manifest, target)

    lines = target.read_text(encoding="utf-8").strip().split("\n")
    assert len(lines) == 1
    header = json.loads(lines[0])
    assert header["_type"] == "header"
    assert header["clip_count"] == 0


def test_write_manifest_toml_atomic(tmp_path: Path):
    """Kein Tempfile-Leftover nach erfolgreichem Write."""
    target = tmp_path / "out.project.toml"
    write_manifest_toml(_sample_manifest(), target)

    leftovers = [
        p for p in target.parent.iterdir()
        if p.name.startswith(f".{target.name}.") and p.name.endswith(".tmp")
    ]
    assert leftovers == []
