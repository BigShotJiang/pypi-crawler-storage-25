"""Tests für rclone-Heuristik und Upload-Logik."""

from __future__ import annotations

from schnittprojekt_archivar.services.rclone_uploader import is_rclone_uri


def test_is_rclone_uri_with_remote():
    assert is_rclone_uri("nas:/Archiv/2026") is True
    assert is_rclone_uri("nas:") is True
    assert is_rclone_uri("lyssach-nas:/Videoschnitt") is True


def test_is_rclone_uri_local_paths():
    assert is_rclone_uri("/Volumes/Archiv/2026") is False
    assert is_rclone_uri("./relative/path") is False
    assert is_rclone_uri("relative") is False
    assert is_rclone_uri("/abs/path") is False


def test_is_rclone_uri_windows_drive_letter():
    """Windows-Drive-Letter (Einzelbuchstabe + Doppelpunkt) ist KEIN rclone-URI."""
    assert is_rclone_uri("C:") is False
    assert is_rclone_uri("D:/path") is False


def test_is_rclone_uri_edge_cases():
    assert is_rclone_uri("") is False
    assert is_rclone_uri(":nothing") is False
