"""Tests für den ZIP-Builder."""

from __future__ import annotations

import zipfile

import pytest

from schnittprojekt_archivar.models.errors import BundleError
from schnittprojekt_archivar.services.zip_builder import build_fcpxml_bundle_zip


def test_build_fcpxml_bundle_zip_basic(fcpxml_bundle, tmp_path):
    target = tmp_path / "out.fcpxmld.zip"
    size = build_fcpxml_bundle_zip(fcpxml_bundle, target)

    assert target.exists()
    assert size > 0
    assert target.stat().st_size == size


def test_build_fcpxml_bundle_zip_preserves_structure(fcpxml_bundle, tmp_path):
    target = tmp_path / "out.fcpxmld.zip"
    build_fcpxml_bundle_zip(fcpxml_bundle, target)

    with zipfile.ZipFile(target, "r") as zf:
        names = zf.namelist()
    # Member-Pfade tragen den Bundle-Verzeichnisnamen als Präfix.
    bundle_name = fcpxml_bundle.name
    assert any(n.startswith(f"{bundle_name}/") for n in names)
    assert f"{bundle_name}/Info.fcpxml" in names
    assert f"{bundle_name}/test.mov" in names


def test_build_fcpxml_bundle_zip_uses_zip_stored(fcpxml_bundle, tmp_path):
    """ZIP_STORED — keine Kompression."""
    target = tmp_path / "out.fcpxmld.zip"
    build_fcpxml_bundle_zip(fcpxml_bundle, target)

    with zipfile.ZipFile(target, "r") as zf:
        for info in zf.infolist():
            assert info.compress_type == zipfile.ZIP_STORED


def test_build_fcpxml_bundle_zip_deterministic_member_order(fcpxml_bundle, tmp_path):
    """Gleicher Input → gleiche Member-Reihenfolge (alphabetisch)."""
    target1 = tmp_path / "out1.zip"
    target2 = tmp_path / "out2.zip"
    build_fcpxml_bundle_zip(fcpxml_bundle, target1)
    build_fcpxml_bundle_zip(fcpxml_bundle, target2)

    with zipfile.ZipFile(target1, "r") as zf1, zipfile.ZipFile(target2, "r") as zf2:
        assert zf1.namelist() == zf2.namelist()
        assert zf1.namelist() == sorted(zf1.namelist())


def test_build_fcpxml_bundle_zip_refuses_overwrite_by_default(fcpxml_bundle, tmp_path):
    target = tmp_path / "out.zip"
    build_fcpxml_bundle_zip(fcpxml_bundle, target)
    with pytest.raises(BundleError, match="existiert bereits"):
        build_fcpxml_bundle_zip(fcpxml_bundle, target)


def test_build_fcpxml_bundle_zip_overwrite_when_requested(fcpxml_bundle, tmp_path):
    target = tmp_path / "out.zip"
    build_fcpxml_bundle_zip(fcpxml_bundle, target)
    # Zweiter Aufruf mit overwrite=True darf nicht crashen
    build_fcpxml_bundle_zip(fcpxml_bundle, target, overwrite=True)


def test_build_fcpxml_bundle_zip_rejects_file_input(tmp_path):
    f = tmp_path / "not-a-dir.fcpxml"
    f.write_text("<fcpxml/>", encoding="utf-8")
    target = tmp_path / "out.zip"
    with pytest.raises(BundleError, match="kein Verzeichnis"):
        build_fcpxml_bundle_zip(f, target)


def test_build_fcpxml_bundle_zip_rejects_empty_dir(tmp_path):
    empty = tmp_path / "Empty.fcpxmld"
    empty.mkdir()
    target = tmp_path / "out.zip"
    with pytest.raises(BundleError, match="leer"):
        build_fcpxml_bundle_zip(empty, target)


def test_build_fcpxml_bundle_zip_no_tempfile_leftover_on_success(fcpxml_bundle, tmp_path):
    target = tmp_path / "out.zip"
    build_fcpxml_bundle_zip(fcpxml_bundle, target)
    leftovers = [
        p for p in target.parent.iterdir()
        if p.name.startswith(f".{target.name}.") and p.name.endswith(".tmp")
    ]
    assert leftovers == []
