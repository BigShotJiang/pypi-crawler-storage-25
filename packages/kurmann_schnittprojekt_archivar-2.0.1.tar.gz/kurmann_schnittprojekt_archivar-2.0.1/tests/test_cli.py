"""CLI-Smoke-Tests via Typer's CliRunner."""

from __future__ import annotations

from typer.testing import CliRunner

from schnittprojekt_archivar.cli.main import app

runner = CliRunner()


def test_version_flag():
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    # Version-String passt zu __version__
    from schnittprojekt_archivar import __version__
    assert __version__ in result.stdout


def test_archive_help_shown():
    result = runner.invoke(app, ["archive", "--help"])
    assert result.exit_code == 0
    assert "Archiviert ein Schnittprojekt" in result.stdout
    assert "--target-dir" in result.stdout
    assert "--target-stem" in result.stdout
    assert "--include-clips" in result.stdout or "--no-clip-inventory" in result.stdout


def test_archive_default_silent_on_success(fcpxml_bundle, tmp_path, monkeypatch):
    """Default-Verhalten: bei Erfolg ist stdout leer (Unix-Stille).
    Pipeline-Konsumenten orientieren sich am Exit-Code.
    """
    from tests.test_archive_project import _patch_leser

    _patch_leser(monkeypatch, format_value="fcpxml_bundle", clips_count=1)
    target_dir = tmp_path / "archiv"
    result = runner.invoke(
        app,
        [
            "archive",
            str(fcpxml_bundle),
            "--target-dir",
            str(target_dir),
            "--target-stem",
            "Test",
        ],
    )
    assert result.exit_code == 0
    assert result.stdout == ""  # Default: keine Ausgabe auf stdout


def test_archive_json_flag_emits_json(fcpxml_bundle, tmp_path, monkeypatch):
    """Mit ``--json`` kommt ein Result-JSON auf stdout."""
    import json as _json

    from tests.test_archive_project import _patch_leser

    _patch_leser(monkeypatch, format_value="fcpxml_bundle", clips_count=1)
    target_dir = tmp_path / "archiv"
    result = runner.invoke(
        app,
        [
            "archive",
            str(fcpxml_bundle),
            "--target-dir",
            str(target_dir),
            "--target-stem",
            "Test",
            "--json",
        ],
    )
    assert result.exit_code == 0
    payload = _json.loads(result.stdout)
    assert payload["success"] is True
    assert payload["bundle_filename"] == "Test.fcpxmld.zip"
