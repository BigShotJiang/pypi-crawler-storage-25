"""Tests für die ASCII-Safe-Slug-Logik (``to_archive_stem``)."""

from __future__ import annotations

import pytest

from schnittprojekt_archivar import is_archive_safe_stem, to_archive_stem


class TestToArchiveStem:
    def test_german_umlauts_transliterated(self) -> None:
        assert to_archive_stem("Mädchen spazieren") == "Maedchen-spazieren"

    def test_all_umlauts(self) -> None:
        assert to_archive_stem("ä ö ü Ä Ö Ü ß") == "ae-oe-ue-Ae-Oe-Ue-ss"

    def test_french_diacritics_stripped(self) -> None:
        assert to_archive_stem("Café crème brûlée") == "Cafe-creme-brulee"

    def test_already_clean_passes_through(self) -> None:
        assert to_archive_stem("2026-05-10-Maedchen-spazieren") == "2026-05-10-Maedchen-spazieren"

    def test_collapses_whitespace_and_punctuation(self) -> None:
        assert to_archive_stem("Hallo,   Welt!") == "Hallo-Welt"

    def test_em_dash_becomes_separator(self) -> None:
        # Em-Dash ist nicht-ASCII und nicht-alphanumerisch
        assert to_archive_stem("2026-05-10 – Höhenflug") == "2026-05-10-Hoehenflug"

    def test_strips_leading_trailing_separators(self) -> None:
        assert to_archive_stem("___bereits-clean___") == "bereits-clean"
        assert to_archive_stem("---abc---") == "abc"

    def test_idempotent(self) -> None:
        once = to_archive_stem("Mädchen spazieren — Familie Kurmann-Glück")
        twice = to_archive_stem(once)
        assert once == twice

    def test_empty_string(self) -> None:
        assert to_archive_stem("") == ""

    def test_only_garbage_yields_empty(self) -> None:
        # Reine Symbole/Whitespace
        assert to_archive_stem("   !!! ???   ") == ""

    def test_emoji_stripped(self) -> None:
        assert to_archive_stem("Urlaub 🌴 2026") == "Urlaub-2026"

    def test_preserves_digits(self) -> None:
        assert to_archive_stem("2026-05-10") == "2026-05-10"


class TestIsArchiveSafeStem:
    @pytest.mark.parametrize(
        "stem",
        [
            "2026-05-10-Maedchen-spazieren",
            "abc",
            "abc-123",
            "Familie-Kurmann-Glueck",
        ],
    )
    def test_safe_stems(self, stem: str) -> None:
        assert is_archive_safe_stem(stem)

    @pytest.mark.parametrize(
        "stem",
        [
            "Mädchen",
            "Hallo Welt",
            "café",
            "-leading",
            "trailing-",
            "double--dash",  # collapses to "double-dash"
            "Punkt.im.Namen",
        ],
    )
    def test_unsafe_stems(self, stem: str) -> None:
        assert not is_archive_safe_stem(stem)
