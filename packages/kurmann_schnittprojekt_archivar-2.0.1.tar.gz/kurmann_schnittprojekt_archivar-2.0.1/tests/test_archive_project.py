"""End-to-End-Tests für ``archive_project``.

Mock-Strategie: ``schnittprojekt_leser.read_project_summary`` wird via
``monkeypatch`` durch einen synthetischen Result-Generator ersetzt, damit
die Tests ohne echte exiftool-Binary laufen.
"""

from __future__ import annotations

import json
import tomllib

from schnittprojekt_archivar.api import archive_project
from schnittprojekt_archivar.models import (
    ArchiveProjectRequest,
    RuntimeOptions,
)


def _patch_leser(monkeypatch, *, format_value: str, clips_count: int = 1):
    """Patcht den schnittprojekt-leser auf ein Mock-Result."""
    from schnittprojekt_leser.models import (
        ClipDateConfidence,
        ProjectClipReference,
        ProjectFormat,
        ProjectRecordingInfo,
        ReadProjectSummaryResult,
    )

    def fake_read_summary(request, runtime, on_event=None, on_output=None):
        clips = []
        for i in range(clips_count):
            clips.append(
                ProjectClipReference(
                    spine_index=i,
                    asset_id=f"a{i}",
                    clip_name=f"Clip-{i}",
                    relative_path=f"./clip-{i}.mov",
                    is_video=True,
                    resolution_status="resolved",
                    resolved_uri=f"/abs/path/clip-{i}.mov",
                    media_metadata=None,
                )
            )
        return ReadProjectSummaryResult(
            success=True,
            project_name="Test-Projekt",
            project_format=ProjectFormat(format_value),
            schema_version="1.8",
            timeline_duration_seconds=10.0,
            clip_count_primary=clips_count,
            clip_count_total=clips_count,
            video_resolution=(1920, 1080),
            color_space="SDR",
            audio_layout="stereo",
            project_mtime_iso="2026-05-21T10:00:00+02:00",
            recording=ProjectRecordingInfo(
                first_clip_date="2026-05-10",
                first_clip_datetime="2026-05-10T07:26:14+02:00",
                first_clip_source_label="exif:Keys:CreationDate",
                first_clip_confidence=ClipDateConfidence.HIGH,
                first_clip_resolved_source_file=None,
            ),
            clips=clips,
            warnings=[],
        )

    import schnittprojekt_archivar.core.read_manifest as core_read_manifest

    monkeypatch.setattr(
        core_read_manifest, "leser_read_project_summary", fake_read_summary
    )


def test_archive_fcpxml_bundle_end_to_end(fcpxml_bundle, tmp_path, monkeypatch):
    """Standardfall: .fcpxmld → ZIP + project.toml + clips.jsonl."""
    _patch_leser(monkeypatch, format_value="fcpxml_bundle", clips_count=2)

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=fcpxml_bundle,
        target_dir=str(target_dir),
        target_stem="2026-05-10-Test",
    )
    result = archive_project(request, RuntimeOptions())

    assert result.success is True, result.error_message
    assert result.bundle is not None
    assert result.bundle.bundle_filename == "2026-05-10-Test.fcpxmld.zip"
    assert result.bundle.bundle_size_bytes > 0
    assert result.manifest_toml_written is True
    assert result.clips_jsonl_written is True

    # Drei Sidecars im Ziel (Namespace .project.*)
    assert (target_dir / "2026-05-10-Test.fcpxmld.zip").exists()
    assert (target_dir / "2026-05-10-Test.project.toml").exists()
    assert (target_dir / "2026-05-10-Test.project.clips.jsonl").exists()

    # TOML-Inhalt prüfen
    toml = tomllib.loads(
        (target_dir / "2026-05-10-Test.project.toml").read_text(encoding="utf-8")
    )
    assert toml["project"]["name"] == "Test-Projekt"
    assert toml["recording"]["first_clip_date"] == "2026-05-10"
    assert toml["bundle"]["archive_filename"] == "2026-05-10-Test.fcpxmld.zip"

    # JSONL-Inhalt prüfen
    lines = (target_dir / "2026-05-10-Test.project.clips.jsonl").read_text().strip().split("\n")
    header = json.loads(lines[0])
    assert header["clip_count"] == 2


def test_archive_fcpxml_single_end_to_end(fcpxml_single, tmp_path, monkeypatch):
    """``.fcpxml``-Single-File wird 1:1 kopiert (kein ZIP)."""
    _patch_leser(monkeypatch, format_value="fcpxml_file", clips_count=0)

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=fcpxml_single,
        target_dir=str(target_dir),
        target_stem="2026-05-10-Single",
    )
    result = archive_project(request, RuntimeOptions())

    assert result.success is True, result.error_message
    assert result.bundle.bundle_filename == "2026-05-10-Single.fcpxml"
    # Datei existiert und ist identisch zur Quelle (byte-Vergleich)
    target_file = target_dir / "2026-05-10-Single.fcpxml"
    assert target_file.exists()
    assert target_file.read_bytes() == fcpxml_single.read_bytes()


def test_archive_imovie_mobile_no_rezipping(imovie_mobile_bundle, tmp_path, monkeypatch):
    """iMovieMobile wird 1:1 kopiert — kein erneutes Zippen, Endung bleibt ``.iMovieMobile``."""
    _patch_leser(monkeypatch, format_value="imovie_mobile_zip", clips_count=1)

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=imovie_mobile_bundle,
        target_dir=str(target_dir),
        target_stem="2026-04-23-Mobile",
    )
    result = archive_project(request, RuntimeOptions())

    assert result.success is True, result.error_message
    assert result.bundle.bundle_filename == "2026-04-23-Mobile.iMovieMobile"
    # Byte-identisch zur Quelle (kein erneutes Zippen)
    target_file = target_dir / "2026-04-23-Mobile.iMovieMobile"
    assert target_file.exists()
    assert target_file.read_bytes() == imovie_mobile_bundle.read_bytes()


def test_archive_refuses_overwrite_by_default(fcpxml_bundle, tmp_path, monkeypatch):
    _patch_leser(monkeypatch, format_value="fcpxml_bundle")

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=fcpxml_bundle,
        target_dir=str(target_dir),
        target_stem="2026-05-10-Test",
    )
    # Erster Lauf: erfolgreich
    result1 = archive_project(request, RuntimeOptions())
    assert result1.success is True

    # Zweiter Lauf: fail
    result2 = archive_project(request, RuntimeOptions())
    assert result2.success is False
    assert "existiert bereits" in (result2.error_message or "")


def test_archive_overwrite_allowed(fcpxml_bundle, tmp_path, monkeypatch):
    _patch_leser(monkeypatch, format_value="fcpxml_bundle")

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=fcpxml_bundle,
        target_dir=str(target_dir),
        target_stem="2026-05-10-Test",
        overwrite=True,
    )
    archive_project(request, RuntimeOptions())
    result2 = archive_project(request, RuntimeOptions())
    assert result2.success is True


def test_archive_without_clips_jsonl_file(fcpxml_bundle, tmp_path, monkeypatch):
    """``write_clips_jsonl_file=False`` unterdrückt die ``.clips.jsonl``-Datei."""
    _patch_leser(monkeypatch, format_value="fcpxml_bundle", clips_count=3)

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=fcpxml_bundle,
        target_dir=str(target_dir),
        target_stem="2026-05-10-Test",
        write_clips_jsonl_file=False,
    )
    result = archive_project(request, RuntimeOptions())

    assert result.success is True
    assert result.clips_jsonl_written is False
    assert (target_dir / "2026-05-10-Test.project.toml").exists()
    assert not (target_dir / "2026-05-10-Test.project.clips.jsonl").exists()


def test_archive_leser_failure_propagates(fcpxml_bundle, tmp_path, monkeypatch):
    """Wenn schnittprojekt-leser fehlschlägt, gibt der Archivar ein Fehler-Result zurück."""
    from schnittprojekt_leser.models import ReadProjectSummaryResult

    def fail_read(request, runtime, on_event=None, on_output=None):
        return ReadProjectSummaryResult(
            success=False,
            error_message="Fake Lesefehler",
        )

    import schnittprojekt_archivar.core.read_manifest as core_read_manifest

    monkeypatch.setattr(core_read_manifest, "leser_read_project_summary", fail_read)

    request = ArchiveProjectRequest(
        project_path=fcpxml_bundle,
        target_dir=str(tmp_path / "archiv"),
        target_stem="X",
    )
    result = archive_project(request, RuntimeOptions())
    assert result.success is False
    assert "Fake Lesefehler" in (result.error_message or "")


def test_archive_slugifies_umlauts_by_default(fcpxml_bundle, tmp_path, monkeypatch):
    """Default-Verhalten: Umlaute werden still zum ASCII-Slug umgeformt."""
    _patch_leser(monkeypatch, format_value="fcpxml_bundle", clips_count=1)

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=fcpxml_bundle,
        target_dir=str(target_dir),
        target_stem="Mädchen spazieren",
    )
    result = archive_project(request, RuntimeOptions())

    assert result.success is True, result.error_message
    assert result.stem_was_slugified is True
    assert result.original_stem == "Mädchen spazieren"
    assert result.effective_stem == "Maedchen-spazieren"
    # Tatsächlich abgelegte Dateinamen tragen den Slug
    assert (target_dir / "Maedchen-spazieren.fcpxmld.zip").exists()
    assert (target_dir / "Maedchen-spazieren.project.toml").exists()
    # Result-Felder bezeugen die Umformung (warnings bleibt für echte Warnungen reserviert)
    assert result.warnings == []


def test_archive_strict_stem_rejects_umlauts(fcpxml_bundle, tmp_path, monkeypatch):
    """Mit ``strict_stem=True`` bricht der Archivar bei unsicherem Stem ab."""
    _patch_leser(monkeypatch, format_value="fcpxml_bundle", clips_count=1)

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=fcpxml_bundle,
        target_dir=str(target_dir),
        target_stem="Mädchen spazieren",
        strict_stem=True,
    )
    result = archive_project(request, RuntimeOptions())

    assert result.success is False
    assert "nicht archivtauglich" in (result.error_message or "")
    # Es wird nichts geschrieben
    assert not target_dir.exists() or not any(target_dir.iterdir())


def test_archive_strict_stem_passes_safe_stem(fcpxml_bundle, tmp_path, monkeypatch):
    """``strict_stem=True`` mit bereits sicherem Stem: kein Slug-Eingriff."""
    _patch_leser(monkeypatch, format_value="fcpxml_bundle", clips_count=1)

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=fcpxml_bundle,
        target_dir=str(target_dir),
        target_stem="2026-05-10-Test",
        strict_stem=True,
    )
    result = archive_project(request, RuntimeOptions())

    assert result.success is True, result.error_message
    assert result.stem_was_slugified is False
    assert result.original_stem is None
    assert result.effective_stem == "2026-05-10-Test"


def test_archive_aborts_on_flat_fcpxml_with_bundle_sibling(
    fcpxml_single, fcpxml_bundle, tmp_path, monkeypatch
):
    """Wenn neben einer .fcpxml ein gleichnamiges .fcpxmld liegt:
    Default-Abbruch mit Hinweis. Geschützt davor, dass der User aus
    Versehen die kleinere Flat-XML statt das ganze Bundle archiviert.
    """
    _patch_leser(monkeypatch, format_value="fcpxml_file", clips_count=0)

    # Geschwister konstruieren: gleicher Stem in tmp_path
    flat = tmp_path / "Project.fcpxml"
    flat.write_text(fcpxml_single.read_text(encoding="utf-8"), encoding="utf-8")
    bundle = tmp_path / "Project.fcpxmld"
    bundle.mkdir()
    (bundle / "Info.fcpxml").write_text(
        (fcpxml_bundle / "Info.fcpxml").read_text(encoding="utf-8"),
        encoding="utf-8",
    )

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=flat,
        target_dir=str(target_dir),
        target_stem="Project",
    )
    result = archive_project(request, RuntimeOptions())

    assert result.success is False
    assert "Mehrdeutige Quelle" in (result.error_message or "")
    assert "Project.fcpxmld" in (result.error_message or "")
    assert "--allow-flat-fcpxml" in (result.error_message or "")
    # Ziel-Dir wurde nicht angelegt
    assert not target_dir.exists()


def test_archive_allow_flat_fcpxml_overrides_sibling_check(
    fcpxml_single, fcpxml_bundle, tmp_path, monkeypatch
):
    """Mit ``allow_flat_fcpxml_if_bundle_sibling=True`` läuft die Flat-XML durch."""
    _patch_leser(monkeypatch, format_value="fcpxml_file", clips_count=0)

    flat = tmp_path / "Project.fcpxml"
    flat.write_text(fcpxml_single.read_text(encoding="utf-8"), encoding="utf-8")
    bundle = tmp_path / "Project.fcpxmld"
    bundle.mkdir()
    (bundle / "Info.fcpxml").write_text(
        (fcpxml_bundle / "Info.fcpxml").read_text(encoding="utf-8"),
        encoding="utf-8",
    )

    target_dir = tmp_path / "archiv"
    request = ArchiveProjectRequest(
        project_path=flat,
        target_dir=str(target_dir),
        target_stem="Project",
        allow_flat_fcpxml_if_bundle_sibling=True,
    )
    result = archive_project(request, RuntimeOptions())

    assert result.success is True, result.error_message
    assert result.bundle.bundle_filename == "Project.fcpxml"


def test_archive_unrecognized_format_returns_error(tmp_path, monkeypatch):
    """Unbekanntes Quellformat → success=False mit klarer Meldung."""
    _patch_leser(monkeypatch, format_value="fcpxml_file", clips_count=0)

    # .mp4 ist kein Schnittprojekt-Format
    weird = tmp_path / "video.mp4"
    weird.write_bytes(b"x")

    request = ArchiveProjectRequest(
        project_path=weird,
        target_dir=str(tmp_path / "archiv"),
        target_stem="X",
    )
    result = archive_project(request, RuntimeOptions())
    assert result.success is False
    # Format-Fehler im error_message — entweder vom Bundle-Step oder von Leser-Read
    assert result.error_message is not None
