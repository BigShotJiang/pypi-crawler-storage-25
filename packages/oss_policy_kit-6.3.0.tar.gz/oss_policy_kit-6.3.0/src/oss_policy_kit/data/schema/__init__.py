"""JSON schemas shipped as package data for runtime validation."""
