from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.post_ai_speech_body_model import PostAiSpeechBodyModel
from ..types import UNSET, Unset

T = TypeVar("T", bound="PostAiSpeechBody")


@_attrs_define
class PostAiSpeechBody:
    """
    Attributes:
        text (str): Text to convert to speech Example: Hello world.
        model (PostAiSpeechBodyModel | Unset): Model name Default: PostAiSpeechBodyModel.MELOTTS. Example: melotts.
    """

    text: str
    model: PostAiSpeechBodyModel | Unset = PostAiSpeechBodyModel.MELOTTS
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        text = self.text

        model: str | Unset = UNSET
        if not isinstance(self.model, Unset):
            model = self.model.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "text": text,
            }
        )
        if model is not UNSET:
            field_dict["model"] = model

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        text = d.pop("text")

        _model = d.pop("model", UNSET)
        model: PostAiSpeechBodyModel | Unset
        if isinstance(_model, Unset):
            model = UNSET
        else:
            model = PostAiSpeechBodyModel(_model)

        post_ai_speech_body = cls(
            text=text,
            model=model,
        )

        post_ai_speech_body.additional_properties = d
        return post_ai_speech_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
