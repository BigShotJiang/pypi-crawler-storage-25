from enum import Enum


class PostAiSpeechBodyModel(str, Enum):
    MELOTTS = "melotts"

    def __str__(self) -> str:
        return str(self.value)
