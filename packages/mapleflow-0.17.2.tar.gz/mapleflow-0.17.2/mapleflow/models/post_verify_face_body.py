from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="PostVerifyFaceBody")


@_attrs_define
class PostVerifyFaceBody:
    """
    Attributes:
        selfie_url (str): HTTPS URL of the selfie image Example: https://example.com/selfie.jpg.
        reference_url (str): HTTPS URL of the reference photo Example: https://example.com/reference.jpg.
        external_user_id (str): Your unique user identifier Example: user_123.
    """

    selfie_url: str
    reference_url: str
    external_user_id: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        selfie_url = self.selfie_url

        reference_url = self.reference_url

        external_user_id = self.external_user_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "selfie_url": selfie_url,
                "reference_url": reference_url,
                "external_user_id": external_user_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        selfie_url = d.pop("selfie_url")

        reference_url = d.pop("reference_url")

        external_user_id = d.pop("external_user_id")

        post_verify_face_body = cls(
            selfie_url=selfie_url,
            reference_url=reference_url,
            external_user_id=external_user_id,
        )

        post_verify_face_body.additional_properties = d
        return post_verify_face_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
