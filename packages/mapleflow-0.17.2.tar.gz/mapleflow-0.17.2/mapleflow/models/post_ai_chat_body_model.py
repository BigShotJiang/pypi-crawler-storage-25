from enum import Enum


class PostAiChatBodyModel(str, Enum):
    CLAUDE_3_HAIKU = "claude-3-haiku"
    CLAUDE_HAIKU_4_5 = "claude-haiku-4.5"
    CLAUDE_OPUS_4_6 = "claude-opus-4.6"
    CLAUDE_SONNET_4 = "claude-sonnet-4"
    CLAUDE_SONNET_4_6 = "claude-sonnet-4.6"
    DEEPSEEK_R1_32B = "deepseek-r1-32b"
    GEMINI_2_0_FLASH = "gemini-2.0-flash"
    GEMINI_2_5_FLASH = "gemini-2.5-flash"
    GEMINI_2_5_FLASH_LITE = "gemini-2.5-flash-lite"
    GPT_4O = "gpt-4o"
    GPT_4O_MINI = "gpt-4o-mini"
    GPT_4_1 = "gpt-4.1"
    GPT_4_1_MINI = "gpt-4.1-mini"
    GPT_4_1_NANO = "gpt-4.1-nano"
    GPT_OSS_120B = "gpt-oss-120b"
    GPT_OSS_20B = "gpt-oss-20b"
    GROK_3 = "grok-3"
    GROK_3_MINI = "grok-3-mini"
    GROK_4_1_FAST = "grok-4.1-fast"
    LLAMA_3_1_8B = "llama-3.1-8b"
    LLAMA_3_1_8BWORKERS_AI = "llama-3.1-8b@workers-ai"
    LLAMA_3_2_1B = "llama-3.2-1b"
    LLAMA_3_2_3B = "llama-3.2-3b"
    LLAMA_3_3_70B = "llama-3.3-70b"
    LLAMA_3_3_70BWORKERS_AI = "llama-3.3-70b@workers-ai"
    MISTRAL_7B = "mistral-7b"
    O3 = "o3"
    O3_MINI = "o3-mini"
    O4_MINI = "o4-mini"
    PHI_2 = "phi-2"

    def __str__(self) -> str:
        return str(self.value)
