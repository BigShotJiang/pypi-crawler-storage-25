# csrd

Meta package for the csrd API framework ecosystem.

## What it installs

- `csrd-versioning`

Additional `csrd-*` packages can be installed individually. This meta package provides a stable single-entry-point install for the canonical stack components.
