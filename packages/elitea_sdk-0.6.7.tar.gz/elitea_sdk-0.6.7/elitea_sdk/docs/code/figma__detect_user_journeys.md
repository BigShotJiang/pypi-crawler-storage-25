# figma - detect_user_journeys

**Toolkit**: `figma`
**Method**: `detect_user_journeys`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def detect_user_journeys(frames: List[Dict]) -> Dict[str, List[Dict]]:
    """
    Detect user journeys by analyzing frame names and button actions.

    Returns dict of journeys with frames in order:
    {
        'authentication': [
            {'name': 'Login', 'id': '1:100', 'actions': ['authenticate', 'reset']},
            {'name': 'Forgot Password', 'id': '1:101', 'actions': ['submit_form']},
        ],
        ...
    }
    """
    journeys = {}

    for frame in frames:
        name = frame.get('name', '')
        buttons = frame.get('buttons', [])
        frame_id = frame.get('id', '')

        # Get button destinations
        actions = []
        for btn in buttons:
            btn_text = btn if isinstance(btn, str) else btn.get('text', '')
            if btn_text:
                dest = infer_cta_destination(btn_text, frame_context=name)
                if dest and not dest.startswith('do:'):
                    actions.append(dest)

        # Determine journey category
        category = infer_journey_category(name, buttons)

        if category:
            if category not in journeys:
                journeys[category] = []
            journeys[category].append({
                'name': name,
                'id': frame_id,
                'actions': list(set(actions)),  # Dedupe actions
                'state': infer_state_from_name(name),
            })

    return journeys
```

## Helper Methods

```python
Helper: infer_journey_category
def infer_journey_category(frame_name: str, buttons: List[str]) -> Optional[str]:
    """
    Infer which user journey a frame belongs to.
    """
    name_lower = frame_name.lower()
    buttons_lower = [b.lower() for b in buttons]
    all_text = name_lower + ' ' + ' '.join(buttons_lower)

    for category, keywords in JOURNEY_CATEGORIES.items():
        if any(kw in all_text for kw in keywords):
            return category
    return None
```

```python
Helper: infer_cta_destination
def infer_cta_destination(cta_text: str, frame_context: str = '') -> str:
    """
    Infer likely destination/action from CTA/button text with context awareness.

    Args:
        cta_text: The button/CTA text
        frame_context: Optional frame name for additional context

    Returns semantic action category or descriptive action based on text.
    """
    cta_lower = cta_text.lower().strip()
    context_lower = frame_context.lower() if frame_context else ''

    # Skip very short or icon-only buttons
    if len(cta_lower) < 2 or cta_lower in ['x', '+', '-', '...', '→', '←']:
        return None  # Will be filtered out

    # Semantic destination mapping with expanded keywords
    destinations = {
        'authenticate': ['sign in', 'log in', 'login', 'authenticate', 'sign-in', 'log-in'],
        'register': ['sign up', 'register', 'create account', 'join', 'get started', 'sign-up'],
        'navigate_next': ['next', 'continue', 'proceed', 'forward', 'go', 'start'],
        'navigate_back': ['back', 'previous', 'return', 'go back'],
        'cancel': ['cancel', 'nevermind', 'not now', 'maybe later', 'skip'],
        'submit_form': ['submit', 'send', 'apply', 'confirm', 'done', 'complete', 'finish', 'ok', 'okay'],
        'save': ['save', 'save changes', 'update', 'keep'],
        'view_detail': ['view', 'details', 'more', 'see more', 'read more', 'open', 'expand', 'show'],
        'search': ['search', 'find', 'look up', 'filter'],
        'settings': ['settings', 'preferences', 'options', 'configure', 'customize'],
        'help': ['help', 'support', 'faq', 'contact', 'learn more', 'how to', 'guide'],
        'share': ['share', 'invite', 'send to', 'export', 'copy link'],
        'delete': ['delete', 'remove', 'clear', 'trash', 'discard'],
        'edit': ['edit', 'modify', 'change', 'rename'],
        'create': ['add', 'create', 'new', 'plus', 'insert'],
        'close': ['close', 'dismiss', 'exit', 'hide'],
        'reset': ['reset', 'forgot password', 'recover', 'restore'],
        'download': ['download', 'export', 'get', 'install'],
        'upload': ['upload', 'import', 'attach', 'choose file'],
        'refresh': ['refresh', 'reload', 'retry', 'try again'],
        'select': ['select', 'choose', 'pick'],
        'toggle': ['enable', 'disable', 'turn on', 'turn off', 'switch'],
        'connect': ['connect', 'link', 'integrate', 'sync'],
        'pay': ['pay', 'checkout', 'purchase', 'buy', 'order', 'subscribe'],
        'upgrade': ['upgrade', 'premium', 'pro', 'unlock'],
    }

    # Try to match known categories
    for dest, keywords in destinations.items():
        if any(kw in cta_lower for kw in keywords):
            return dest

    # Context-aware inference from frame name
    if context_lower:
        if any(ctx in context_lower for ctx in ['login', 'auth', 'sign']):
            if any(w in cta_lower for w in ['submit', 'go', 'enter']):
                return 'authenticate'
        if any(ctx in context_lower for ctx in ['modal', 'dialog', 'popup']):
            return 'dismiss_modal'
        if any(ctx in context_lower for ctx in ['form', 'input', 'settings']):
            return 'submit_form'
        if any(ctx in context_lower for ctx in ['checkout', 'payment', 'cart']):
            return 'pay'

    # Return cleaned button text as action (more informative than generic 'action')
    # Clean up the text for display
    clean_text = cta_text.strip()
    if len(clean_text) <= 20:
        return f"do:{clean_text}"  # Short enough to show as-is
    return f"do:{clean_text[:17]}..."  # Truncate long text
```
