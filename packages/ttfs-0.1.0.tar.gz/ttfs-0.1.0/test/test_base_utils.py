
import ast
import dataclasses
from typing import Annotated, Any

import numpy as np
import torch
from ttfs.aggtype import TRITON_AGG_FLATTEN_META_FIELD, TRITON_AGG_META_FIELD, constexpr_function
from ttfs.tensor import sym
from ttfs.utils import div_up
import triton.language as tl
import triton 
import traceback
from triton.experimental.gluon import language as gl
import ttfs
from ttfs.jitx import _create_agg_from_flatten_args_ast_node

@ttfs.triton_jit
def tuple_range_v2(length: tl.constexpr):
    return tl.tuple([i for i in tl.tuple(sym.tuple_range(length))])

@tl.core.builtin
def dev_kwarg(_semantic=None, **kwargs):
    print(kwargs)

@ttfs.aggregate
class Agg:
    a: tl.constexpr

    @tl.core.builtin
    def method(self, _semantic=None, **kwargs):
        print(kwargs)


@ttfs.triton_jit_kernel
def tt_named_offsets_kernel():
    noffs = ttfs.NamedOffsets()
    names_AB: tl.constexpr = sym.get_shape_names_from_sym("A,B")
    noffs = noffs.merge_replace_offsets(names_AB, (ttfs.mp.TritonConstexprField(1), ttfs.mp.TritonConstexprField(2)))

    tl.static_assert(noffs.get_offset_cw_by_name("A").value == 1, "Offset A should be 1")
    tl.static_assert(noffs.get_offset_cw_by_name("B").value == 2, "Offset B should be 2")
    names_BC: tl.constexpr = sym.get_shape_names_from_sym("B,C")

    noffs = noffs.merge_add_offsets(names_BC, (ttfs.mp.TritonConstexprField(3), ttfs.mp.TritonConstexprField(4)))

    wtf = [tl.zeros((128,), dtype=tl.float32) for _ in ttfs.mp.tuple_static_range(4)]
    agg = Agg(5)
    agg.method(A=5, B=3, C=4)

    tl.static_assert(noffs.get_offset_cw_by_name("A").value == 1, "Offset A should still be 1")
    tl.static_assert(noffs.get_offset_cw_by_name("B").value == 5, "Offset B should be updated to 5")
    tl.static_assert(noffs.get_offset_cw_by_name("C").value == 4, "Offset C should be 4")

    dev_kwarg(A=5, B=3)

def test_named_offsets():
    tt_named_offsets_kernel[(1,)]()

@ttfs.aggregate
class KernelDispatchBase:
    a: tl.constexpr

    @ttfs.triton_jit
    def kernel(self, args: "Args"):
        return 0

@ttfs.aggregate
class Args(ttfs.TensorManagerBase):
    kernel: KernelDispatchBase
    a: tl.constexpr

@ttfs.aggregate
class KernelDispatchA(KernelDispatchBase):

    @ttfs.triton_jit
    def kernel(self, args: "Args"):
        return 2 

@ttfs.aggregate
class KernelDispatchB(KernelDispatchBase):

    @ttfs.triton_jit
    def kernel(self, args: "Args"):
        return 1 

@ttfs.triton_jitx_kernel
def tt_test_kernel_cache_key(args: Args):
    args.kernel.kernel(args)

def test_kernel_host_dispatch():
    args1 = Args(kernel=KernelDispatchA(1), a=1)
    args2 = Args(kernel=KernelDispatchB(1), a=1)
    ker1 = tt_test_kernel_cache_key[(1,)](args1)
    ker2 = tt_test_kernel_cache_key[(1,)](args2)
    # breakpoint()
    assert ker1.hash != ker2.hash, "Kernels with different dispatch classes should have different cache keys"
    # breakpoint()
    # print(ker1)

if __name__ == "__main__":
    test_named_offsets()
    # test_kernel_host_dispatch()