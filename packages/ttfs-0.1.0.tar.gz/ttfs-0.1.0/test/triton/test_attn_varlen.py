
import ast
import dataclasses
from functools import partial
import math
from typing import Annotated, Any, Optional

import numpy as np
import torch
from ttfs.aggtype import TRITON_AGG_FLATTEN_META_FIELD, TRITON_AGG_META_FIELD, constexpr_function
from ttfs.utils import div_up
import triton.language as tl
import triton 
import traceback
from triton.experimental.gluon import language as gl
import ttfs


def _torch_jagged_sdpa_ref(
    qs: list[torch.Tensor],
    ks: list[torch.Tensor],
    vs: list[torch.Tensor],
) -> torch.Tensor:
    q_jagged = torch.nested.nested_tensor(
        [q[0] for q in qs],
        layout=torch.jagged,
    )
    k_jagged = torch.nested.nested_tensor(
        [k[0] for k in ks],
        layout=torch.jagged,
    )
    v_jagged = torch.nested.nested_tensor(
        [v[0] for v in vs],
        layout=torch.jagged,
    )

    o_ref_padded = torch.nn.functional.scaled_dot_product_attention(
        q_jagged.transpose(1, 2),
        k_jagged.transpose(1, 2),
        v_jagged.transpose(1, 2),
        is_causal=False,
    ).transpose(1, 2).to_padded_tensor(0.0)
    o_ref = torch.cat(
        [o_ref_padded[i, : qs[i].shape[1]] for i in range(len(qs))],
        dim=0,
    )
    return o_ref.unsqueeze(0)

@ttfs.aggregate
class AttentionManager(ttfs.TensorManagerBase):
    q: Annotated[ttfs.TensorDesc, ttfs.tensor_desc_meta("B,S,H")]
    k: Annotated[ttfs.TensorDesc, ttfs.tensor_desc_meta("B,S,H")]
    v: Annotated[ttfs.TensorDesc, ttfs.tensor_desc_meta("B,S,H")]
    o: ttfs.TensorDesc # contiguous
    lse: ttfs.TensorDesc # contiguous

    S_qo: tl.tensor 
    S_kv: tl.tensor

    B: tl.constexpr
    H: tl.constexpr
    D: tl.constexpr

    BLOCK_M: tl.constexpr 
    BLOCK_N: tl.constexpr

    cu_seqlen_q: tl.tensor
    cu_seqlen_kv: tl.tensor


@ttfs.aggregate
class AttentionArgs:
    tensors: AttentionManager
    sm_scale: tl.constexpr

@ttfs.triton_jitx_kernel
def attn_fwd_varlen_kernel(args: AttentionArgs, BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr):
    bh_id = tl.program_id(1)
    seq_id = tl.program_id(0)
    b_id = bh_id // args.tensors.H
    h_id = bh_id % args.tensors.H
    # TMA offsets only support i32 values. 
    seq_q_start = tl.load(args.tensors.cu_seqlen_q + b_id).to(tl.int32)
    seq_q_end = tl.load(args.tensors.cu_seqlen_q + b_id + 1).to(tl.int32)
    q_start = seq_q_start + seq_id * BLOCK_M
    if q_start >= seq_q_end:
        return
    seq_kv_start = tl.load(args.tensors.cu_seqlen_kv + b_id).to(tl.int32)
    seq_kv_end = tl.load(args.tensors.cu_seqlen_kv + b_id + 1).to(tl.int32)
    # convert tm from jagged tensor to real tensor by two stmt:
    # 1. offset base pointers
    tm = args.tensors.offset_all_tensor_ptr("S_qo,S_kv", (seq_q_start, seq_kv_start))
    # 2. replace real dims
    # WARNING: if your value isn't constexpr, replaced dim must not be constexpr, we will check this.
    # WARNING: currently we have no type check for replaced dims.
    tm = tm.replace_packed_dims("S_qo,S_kv", (seq_q_end - seq_q_start, seq_kv_end - seq_kv_start))
    # now all tensors in tm are dense tensor instead of jagged tensor.
    # remain are same as standard attention kernel.
    tm = tm.offset_all_tensor("H,S_qo", (h_id, seq_id * BLOCK_M,))

    q_desc = tm.get_offseted_block_desc("q", "S,D", [BLOCK_M, tm.D])
    k_desc = tm.get_offseted_block_desc("k", "D,S", [tm.D, BLOCK_N])
    # offset_n is constexpr[0] by default in kv. 
    # required when modify offsets in desc directly.
    k_desc = k_desc.make_offset_dim_mutable("S")
    v_desc = tm.get_offseted_block_desc("v", "S,D", [BLOCK_N, tm.D])
    v_desc = v_desc.make_offset_dim_mutable("S")

    q = q_desc.masked_load(apply_mask=True)
    m_i = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")
    l_i = tl.zeros([BLOCK_M], dtype=tl.float32) + 1.0
    acc = tl.zeros([BLOCK_M, tm.D], dtype=tl.float32)
    QK_SCALE: tl.constexpr = args.sm_scale * 1.44269504  # 1/log(2)

    num_kv_blocks = tl.cdiv(tm.S_kv, BLOCK_N)
    offs_n = k_desc.get_blocked_offset_base("S")
    for kv_idx in range(num_kv_blocks):
        k = k_desc.masked_load(apply_mask=False) # .T
        # k = tl.load(k_ptrs, )
        qk = tl.dot(q, k)
        qk = tl.where(offs_n[None, :] < tm.S_kv, qk, float("-inf"))

        m_ij = tl.maximum(m_i, tl.max(qk, 1) * QK_SCALE)
        qk = qk * QK_SCALE - m_ij[:, None]
        p = tl.math.exp2(qk)
        # -- compute correction factor
        alpha = tl.math.exp2(m_i - m_ij)
        l_ij = tl.sum(p, 1)
        acc = acc * alpha[:, None]
        # prepare p and v for the dot
        v = v_desc.masked_load(apply_mask=False)
        # v = tl.load(v_ptrs, )
        p = p.to(tl.bfloat16)
        # note that this non transposed v for FP8 is only supported on Blackwell
        acc = tl.dot(p, v, acc)
        # update m_i and l_i
        # place this at the end of the loop to reduce register pressure
        l_i = l_i * alpha + l_ij
        m_i = m_ij
        k_desc = k_desc.increment_fixed_block("S", 1)
        v_desc = v_desc.increment_fixed_block("S", 1)
        offs_n += BLOCK_N
    o_desc = tm.get_offseted_block_desc("o", "S,D", [BLOCK_M, tm.D])
    lse_desc = tm.get_offseted_block_desc("lse", "S", [BLOCK_M])

    m_i += tl.math.log2(l_i)
    acc = acc / l_i[:, None]
    lse_desc.masked_store(m_i)
    o_desc.masked_store(acc.to(tl.bfloat16))

@ttfs.triton_jitx_kernel
def attn_fwd_varlen_tma_kernel(args: AttentionArgs, BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr):
    bh_id = tl.program_id(1)
    seq_id = tl.program_id(0)
    b_id = bh_id // args.tensors.H
    h_id = bh_id % args.tensors.H
    # TMA offsets only support i32 values. 
    seq_q_start = tl.load(args.tensors.cu_seqlen_q + b_id).to(tl.int32)
    seq_q_end = tl.load(args.tensors.cu_seqlen_q + b_id + 1).to(tl.int32)
    q_start = seq_q_start + seq_id * BLOCK_M
    if q_start >= seq_q_end:
        return
    seq_kv_start = tl.load(args.tensors.cu_seqlen_kv + b_id).to(tl.int32)
    seq_kv_end = tl.load(args.tensors.cu_seqlen_kv + b_id + 1).to(tl.int32)
    # convert tm from jagged tensor to real tensor by two stmt:
    # 1. offset base pointers
    tm = args.tensors.offset_all_tensor_ptr("S_qo,S_kv", (seq_q_start, seq_kv_start))
    # 2. replace real dims
    # WARNING: if your value isn't constexpr, replaced dim must not be constexpr, we will check this.
    # WARNING: currently we have no type check for replaced dims.
    tm = tm.replace_packed_dims("S_qo,S_kv", (seq_q_end - seq_q_start, seq_kv_end - seq_kv_start))
    # now all tensors in tm are dense tensor instead of jagged tensor.
    # remain are same as standard attention kernel (only diff is varlen can't use TMA store).
    tm = tm.offset_all_tensor("H,S_qo", (h_id, seq_id * BLOCK_M,))
    q_desc = tm.get_external_tma_block_desc("q", "S,D")
    k_desc = tm.get_external_tma_block_desc("k", "S,D")
    v_desc = tm.get_external_tma_block_desc("v", "S,D")

    q = q_desc.tma_load([0, 0])
    m_i = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")
    l_i = tl.zeros([BLOCK_M], dtype=tl.float32) + 1.0
    acc = tl.zeros([BLOCK_M, tm.D], dtype=tl.float32)
    QK_SCALE: tl.constexpr = args.sm_scale * 1.44269504  # 1/log(2)
    offs_n = k_desc.get_blocked_offset_base("S")

    num_kv_blocks = tl.cdiv(tm.S_kv, BLOCK_N)
    for kv_idx in range(num_kv_blocks):
        k = k_desc.tma_load([kv_idx * BLOCK_N, 0]).T
        # k = tl.load(k_ptrs).T
        qk = tl.dot(q, k)
        qk = tl.where(offs_n[None, :] < tm.S_kv, qk, float("-inf"))

        m_ij = tl.maximum(m_i, tl.max(qk, 1) * QK_SCALE)
        qk = qk * QK_SCALE - m_ij[:, None]
        p = tl.math.exp2(qk)
        # -- compute correction factor
        alpha = tl.math.exp2(m_i - m_ij)
        l_ij = tl.sum(p, 1)
        acc = acc * alpha[:, None]
        # prepare p and v for the dot
        v = v_desc.tma_load([kv_idx * BLOCK_N, 0])
        # v = tl.load(v_ptrs)
        p = p.to(tl.bfloat16)
        # note that this non transposed v for FP8 is only supported on Blackwell
        acc = tl.dot(p, v, acc)
        # update m_i and l_i
        # place this at the end of the loop to reduce register pressure
        l_i = l_i * alpha + l_ij
        m_i = m_ij
        offs_n += BLOCK_N
    o_desc = tm.get_offseted_block_desc("o", "S,D", [BLOCK_M, tm.D])
    lse_desc = tm.get_offseted_block_desc("lse", "S", [BLOCK_M])

    m_i += tl.math.log2(l_i)
    acc = acc / l_i[:, None]
    lse_desc.masked_store(m_i)
    o_desc.masked_store(acc.to(tl.bfloat16))

def attn_fwd_varlen(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, 
        cu_seqlen_q: torch.Tensor, cu_seqlen_kv: torch.Tensor,
        max_seqlen_q: int,
        sm_scale: Optional[float] = None, use_tma=False,):
    # cu_seqlen_q: accumulated seqlen of q, shape [B + 1], e.g. [0, 256, 384] for seqlen [256, 128]
    B, S_qo, H, D = q.shape
    assert B == 1
    num_seq = cu_seqlen_q.shape[0] - 1
    S_kv = k.shape[1]
    assert k.shape == (B, S_kv, H, D)
    assert v.shape == (B, S_kv, H, D)
    if sm_scale is None:
        sm_scale = 1.0 / math.sqrt(q.size(-1))
    o = torch.zeros_like(q)
    lse = torch.empty((B, H, S_qo), device=q.device, dtype=torch.float32)
    BLOCK_M = 128 
    BLOCK_N = 128
    if use_tma:
        tdesc_q = ttfs.TensorDesc.tma_from_tensor_triton(q[0], "S_qo->S,H,D", [BLOCK_M, 1, D])
        tdesc_k = ttfs.TensorDesc.tma_from_tensor_triton(k[0], "S_kv->S,H,D", [BLOCK_N, 1, D])
        tdesc_v = ttfs.TensorDesc.tma_from_tensor_triton(v[0], "S_kv->S,H,D", [BLOCK_N, 1, D])
    else:
        tdesc_q = ttfs.TensorDesc(q[0], "S_qo->S,H,D")
        tdesc_k = ttfs.TensorDesc(k[0], "S_kv->S,H,D")
        tdesc_v = ttfs.TensorDesc(v[0], "S_kv->S,H,D")
    # varlen fwd can't use tma store.
    tdesc_o = ttfs.TensorDesc(o[0], "S_qo->S,H,D")
    tdesc_lse = ttfs.TensorDesc(lse, "B,H,S_qo->S")

    tensors = AttentionManager(
        q=tdesc_q,
        k=tdesc_k,
        v=tdesc_v,
        o=tdesc_o,
        lse=tdesc_lse,
        S_qo=S_qo,
        S_kv=S_kv,
        B=B,
        H=H,
        D=D,
        BLOCK_M=BLOCK_M,
        BLOCK_N=BLOCK_N,
        cu_seqlen_q=cu_seqlen_q,
        cu_seqlen_kv=cu_seqlen_kv,
    )
    args = AttentionArgs(tensors=tensors, sm_scale=sm_scale)
    # grid: cdiv(max_seqlen_q, BLOCK_M), B * H
    grid = (div_up(max_seqlen_q, BLOCK_M), num_seq * H)
    # print("GRID", grid)
    if use_tma:
        attn_fwd_varlen_tma_kernel[grid](args=args, BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N)
    else:
        attn_fwd_varlen_kernel[grid](args=args, BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N)
    return o, lse

def _test_attn_fwd_varlen(B: int, S_qos: list[int], S_kvs: list[int], H: int, D: int, use_tma: bool = True):
    assert B == 1

    qs = [torch.randn((B, S_qo, H, D), device="cuda", dtype=torch.bfloat16) for S_qo in S_qos]
    ks = [torch.randn((B, S_kv, H, D), device="cuda", dtype=torch.bfloat16) for S_kv in S_kvs]
    vs = [torch.randn((B, S_kv, H, D), device="cuda", dtype=torch.bfloat16) for S_kv in S_kvs]
    cu_seqlen_q = torch.tensor([0] + S_qos, device="cuda", dtype=torch.int32).cumsum(dim=0).to(torch.int32)
    cu_seqlen_kv = torch.tensor([0] + S_kvs, device="cuda", dtype=torch.int32).cumsum(dim=0).to(torch.int32)
    max_seqlen_q = max(S_qos)
    max_seqlen_kv = max(S_kvs)
    q = torch.cat(qs, dim=1)
    k = torch.cat(ks, dim=1)
    v = torch.cat(vs, dim=1)

    o, lse = attn_fwd_varlen(q, k, v, cu_seqlen_q, cu_seqlen_kv,max_seqlen_q, use_tma=use_tma)
    # test by torch sdpa

    o_ref = _torch_jagged_sdpa_ref(qs, ks, vs)
    torch.testing.assert_close(o, o_ref, rtol=1e-2, atol=1e-2)
    

def test_attn_fwd_varlen():
    D = 64
    _test_attn_fwd_varlen(1, [256, 128], [256, 128], H=2, D=D, use_tma=False)
    torch.cuda.synchronize()
    _test_attn_fwd_varlen(1, [256, 128], [256, 128], H=2, D=D, use_tma=True)
    torch.cuda.synchronize()
    _test_attn_fwd_varlen(1, [353, 97], [421, 65], H=2, D=D, use_tma=False)
    torch.cuda.synchronize()
    _test_attn_fwd_varlen(1, [353, 97], [421, 65], H=2, D=D, use_tma=True)

if __name__ == "__main__":
    test_attn_fwd_varlen()