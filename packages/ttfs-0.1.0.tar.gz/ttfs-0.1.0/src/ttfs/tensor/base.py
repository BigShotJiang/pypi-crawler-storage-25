import ast
import dataclasses
import traceback
from typing import Any

import torch

import triton.language as tl
from triton.experimental.gluon import language as gl
from typing_extensions import Annotated

from ttfs.aggtype import (
    FieldMeta,
    TritonAggFieldAccessor,
    TritonAggFlatField,
    aggregate,
    aggregate_replace_gluon,
    aggregate_replace_triton,
    aggregate_super_method_gluon,
    aggregate_super_method_triton,
    constexpr_function,
    get_scalar_tensor,
    triton_jit,
    triton_jit_kernel,
)
from ttfs.mp import (
    TritonConstexprField,
    TritonField,
    all_fields_is_constexpr,
    cwrapped_add,
    dispatch_value,
    filter_constexpr_fields,
    filter_non_constexpr_fields,
    filter_tuple_by_bools_triton,
    get_all_field_keys_with_type,
    get_all_fields_with_type_gluon,
    get_dcls_fields,
    get_field,
    get_field_triton,
    get_num_warps,
    has_field,
    is_constexpr,
    is_gluon,
    merge_two_tuple,
    replace_all_fields_with_type_gluon,
    replace_all_fields_with_type_triton,
    replace_fields_gluon,
    replace_fields_triton,
    torch_dtype_to_gluon,
    tuple_to_cwrapper,
)
from ttfs.tensor import sym
from ttfs.tensor.core_ops import (
    merge_tuple_dict_gluon,
    merge_tuple_dict_key,
    merge_tuple_dict_triton,
)
from ttfs.tensor.layout import (
    get_default_block_io_layout,
    get_default_swizzed_shared_layout_nvidia,
)

from ttfs.mp import get_all_fields_with_type_triton
from triton.tools.tensor_descriptor import (
    TensorDescriptor as HostTensorDescriptorTriton,
)
from triton.experimental.gluon.nvidia.hopper import (
    TensorDescriptor as HostTensorDescriptorGluon,
)


@aggregate
class StrideWithMultipleOf:
    stride: Any
    multiple_of: tl.constexpr
    need_multiple_of: tl.constexpr


@aggregate
class NamedOffsets:
    offsets_cw: Annotated[tl.tuple, FieldMeta(is_kernel_arg=False)] = dataclasses.field(
        default_factory=lambda: tl.tuple([])
    )
    offset_names: Annotated[Any, tl.constexpr, FieldMeta(is_kernel_arg=False)] = (
        dataclasses.field(default_factory=lambda: tl.constexpr([]))
    )

    @triton_jit
    def get_filtered_offsets(self, exc_sym: tl.constexpr):
        filter_bools: tl.constexpr = sym.get_filter_offset_pair_bools_except(
            self.offset_names, exc_sym
        )
        new_offset_names: tl.constexpr = sym.filter_constexpr_lists(
            self.offset_names,
            filter_bools,
        )
        new_offsets = filter_tuple_by_bools_triton(self.offsets_cw, filter_bools)
        return NamedOffsets(new_offsets, new_offset_names)

    @triton_jit
    def get_included_offsets(self, inc_sym: tl.constexpr):
        filter_bools: tl.constexpr = sym.get_filter_offset_pair_bools(
            self.offset_names, inc_sym
        )
        new_offset_names: tl.constexpr = sym.filter_constexpr_lists(
            self.offset_names,
            filter_bools,
        )
        new_offsets = filter_tuple_by_bools_triton(self.offsets_cw, filter_bools)
        return NamedOffsets(new_offsets, new_offset_names)

    @triton_jit
    def get_cleared_named_offsets(self):
        new_offs = [
            TritonConstexprField(0)
            for _ in tl.tuple(sym.tuple_range(len(self.offsets_cw)))
        ]
        return NamedOffsets(new_offs, self.offset_names)

    @triton_jit
    def make_offset_dim_mutable(self, dim_axis: tl.constexpr):
        """Call this when you want to directly increment offset in a loop."""
        res = [
            TritonField(get_scalar_tensor(self.offsets_cw[i].value))
            if i == dim_axis and self.offsets_cw[i].is_constexpr
            else self.offsets_cw[i]
            for i in tl.tuple(sym.tuple_range(len(self.offset_names)))
        ]

        return self.replace_offset(res, self.offset_names)

    @triton_jit
    def replace_offset(self, new_offset_tuple, new_offset_names: tl.constexpr):
        tl.static_assert(
            len(new_offset_tuple) == len(new_offset_names),
            "New offset tuple length must match offsets length.",
        )
        if is_gluon():
            return aggregate_replace_gluon(
                self,
                offsets_cw=new_offset_tuple,
                offset_names=new_offset_names,
            )
        else:
            return aggregate_replace_triton(
                self,
                offsets_cw=new_offset_tuple,
                offset_names=new_offset_names,
            )

    @triton_jit
    def query_offsets_cw_by_sym(self, query_sym: tl.constexpr):
        block_dims_in_offset: tl.constexpr = sym.get_sym_axes_in_name_tuple(
            self.offset_names, query_sym
        )
        if sym.is_any_sym_in_names(query_sym, self.offset_names):
            offset_tuple = [
                self.offsets_cw[block_dims_in_offset[i]]
                if block_dims_in_offset[i] >= 0
                else TritonConstexprField(0)
                for i in tl.tuple(sym.tuple_range(len(block_dims_in_offset)))
            ]
        else:
            offset_tuple = [
                TritonConstexprField(0)
                for i in tl.tuple(sym.tuple_range(len(block_dims_in_offset)))
            ]
        return offset_tuple

    @triton_jit
    def query_named_offsets_by_sym(self, query_sym: tl.constexpr):
        return NamedOffsets(
            self.query_offsets_cw_by_sym(query_sym),
            sym.get_shape_names_from_sym(query_sym),
        )

    @triton_jit
    def get_sub_named_offset_by_sym(self, query_sym: tl.constexpr):
        tl.static_assert(
            sym.is_all_sym_in_names(query_sym, self.offset_names),
            f"All dims in query_sym {query_sym} must be in offset_names {self.offset_names}.",
        )
        return self.get_included_offsets(query_sym)

    @triton_jit
    def _merge_add_or_replace_offsets(
        self,
        query_offset_names: tl.constexpr,
        query_offsets_cw: tl.tuple,
        is_add: tl.constexpr,
    ):
        union_set: tl.constexpr = sym.merge_two_name_list(
            self.offset_names, query_offset_names, do_unique=True
        )
        union_offsets = [
            TritonConstexprField(0)
            if not sym.is_name_in_names(union_set[i], self.offset_names)
            else self.offsets_cw[
                sym.get_name_in_names_idx(union_set[i], self.offset_names)
            ]
            for i in tl.tuple(sym.tuple_range(len(union_set)))
        ]
        if is_add:
            union_offsets = [
                union_offsets[i]
                if not sym.is_name_in_names(union_set[i], query_offset_names)
                else cwrapped_add(
                    query_offsets_cw[
                        sym.get_name_in_names_idx(union_set[i], query_offset_names)
                    ],
                    union_offsets[i],
                )
                for i in tl.tuple(sym.tuple_range(len(union_set)))
            ]
        else:
            # replace
            union_offsets = [
                union_offsets[i]
                if not sym.is_name_in_names(union_set[i], query_offset_names)
                else query_offsets_cw[
                    sym.get_name_in_names_idx(union_set[i], query_offset_names)
                ]
                for i in tl.tuple(sym.tuple_range(len(union_set)))
            ]
        return self.replace_offset(union_offsets, union_set)

    @triton_jit
    def merge_replace_offsets(
        self, query_offset_names: tl.constexpr, query_offsets_cw: tl.tuple
    ):
        return self._merge_add_or_replace_offsets(
            query_offset_names, query_offsets_cw, False
        )

    @triton_jit
    def merge_add_offsets(
        self, query_offset_names: tl.constexpr, query_offsets_cw: tl.tuple
    ):
        return self._merge_add_or_replace_offsets(
            query_offset_names, query_offsets_cw, True
        )

    @triton_jit
    def get_offset_cw_by_name(self, name: tl.constexpr):
        tl.static_assert(
            sym.is_name_in_names(name, self.offset_names),
            f"Offset name {name} not found in offset names {self.offset_names}.",
        )
        return self.offsets_cw[sym.get_name_in_names_idx(name, self.offset_names)]

    @triton_jit
    def get_offset_cw_by_name_default_zero(self, name: tl.constexpr):
        if sym.is_name_in_names(name, self.offset_names):
            return self.offsets_cw[sym.get_name_in_names_idx(name, self.offset_names)]
        else:
            return TritonConstexprField(0)

    @triton_jit
    def get_offsets_cw_by_sym_default_zero(self, shape_sym: tl.constexpr):
        sym_names: tl.constexpr = sym.get_shape_names_from_sym(shape_sym)
        return [
            self.get_offset_cw_by_name_default_zero(tl.constexpr(sym_names[i]))
            for i in tl.tuple(sym.tuple_range(len(sym_names)))
        ]

    @triton_jit
    def is_name_exists(self, name: tl.constexpr):
        return TritonConstexprField(sym.is_name_in_names(name, self.offset_names))

    @triton_jit
    def cast_to_i64_if_needed(self):
        offsets_cw = [
            _cast_to_i64_if_needed(self.offsets_cw[i])
            for i in tl.tuple(sym.tuple_range(len(self.offsets_cw)))
        ]
        return self.replace_offset(offsets_cw, self.offset_names)


@aggregate
class TensorDesc:
    ptr: Any
    shape_sym: Annotated[str, tl.constexpr]
    # -1 or (-1, -1, 64, -1)
    strides: Annotated[Any, FieldMeta(is_kernel_arg=False)] = None
    stride_multiple_of: tl.constexpr = dataclasses.field(default=tl.constexpr(1))
    _ttfs_tmp_pv_stride: Annotated[
        str, tl.constexpr, FieldMeta(is_kernel_arg=False)
    ] = ""
    # only used when ptr is immutable (e.g. tensor descriptor).
    # otherwise offset will be added to pointer.
    _ttfs_immutable_named_offsets: Annotated[
        NamedOffsets, FieldMeta(is_kernel_arg=False)
    ] = dataclasses.field(default_factory=NamedOffsets)

    def __post_init__(self):
        if isinstance(self.ptr, torch.Tensor):
            # init from host code
            msg = (
                f"strides must be None in host side init, get {self.strides}. use "
                'Annotated[ttfs.TensorDesc, ttfs.tensor_desc_meta("B,H")] '
                "to indicate which dims to pass strides for. we will fill strides from torch tensor."
            )
            assert self.strides is None, msg
            sym_parts = sym.get_shape_names_from_sym(self.shape_sym)
            assert len(sym_parts) == self.ptr.ndim, (
                f"shape_sym {self.shape_sym} has {len(sym_parts)} dims, but tensor has {self.ptr.ndim} dims."
            )

        ndim: tl.constexpr = len(sym.get_shape_names_from_sym(self.shape_sym))
        if self.strides is None:
            self.strides = tl.tuple([tl.constexpr(-1)] * ndim)
        if isinstance(
            self.ptr, (HostTensorDescriptorTriton, HostTensorDescriptorGluon)
        ):
            sym_parts = sym.get_shape_names_from_sym(self.shape_sym)
            assert len(sym_parts) == self.ptr.base.ndim, (
                f"shape_sym {self.shape_sym} has {len(sym_parts)} dims, but tensor has {self.ptr.base.ndim} dims."
            )

        if isinstance(
            self.ptr,
            (
                tl.tensor_descriptor,
                gl.nvidia.hopper.tma.tensor_descriptor,
                HostTensorDescriptorTriton,
                HostTensorDescriptorGluon,
            ),
        ):
            # when use host-side tensor desc, validate ndim.
            # NOTE: strides and stride_multiple_of will be ignored. TODO should we check this, make sure users don't set them?
            assert ndim == len(self.ptr.block_shape), (
                f"TensorDesc shape_sym indicates {ndim} dims, but ptr has {len(self.ptr.block_shape)} dims."
            )

        assert isinstance(self.strides, tl.tuple), (
            f"Strides must be a tl.tuple, but got {type(self.strides)}."
        )
        pv_stride_sym = tl.core._unwrap_if_constexpr(self._ttfs_tmp_pv_stride)
        if pv_stride_sym != "":
            value_axes = sym.get_sym_axes_allow_invalid(self.shape_sym, pv_stride_sym)
            new_strides = list(tl.constexpr(-1) for _ in range(ndim))
            for j, axis in enumerate(value_axes):
                # axis may be -1 if allow_invalid.
                if axis >= 0:
                    assert axis < ndim, (
                        f"passed stride axis {axis} out of range for shape with ndim {ndim}."
                    )
                    new_strides[axis] = self.strides[j]
            self.strides = tl.tuple(new_strides)
            # WARNING: dataclasses.replace will trigger __post_init__, so we must clear this here.
            self._ttfs_tmp_pv_stride = ""
        if isinstance(self.strides, tl.tuple):
            assert len(self.strides) == ndim, (
                f"Strides length {len(self.strides)} doesn't match shape length {ndim}."
            )
        if isinstance(self.stride_multiple_of, (tl.tuple, tuple, list)):
            assert len(self.stride_multiple_of) == ndim, (
                f"stride_multiple_of length {len(self.stride_multiple_of)} doesn't match shape length {ndim}."
            )
        else:
            self.stride_multiple_of = tuple([1] * ndim)

    @staticmethod
    @sym.workaround_ignore_cache_record
    def tma_from_tensor_triton(
        ten: torch.Tensor, shape_sym: str, block_shape: list[int]
    ):
        names, _ = sym.parse_shape_sym(shape_sym)
        assert len(names) == len(block_shape), (
            f"shape_sym {shape_sym} has {len(names)} dims, but block_shape has {len(block_shape)} dims."
        )
        assert len(names) == ten.ndim, (
            f"shape_sym {shape_sym} has {len(names)} dims, but tensor has {ten.ndim} dims."
        )
        return TensorDesc(
            ptr=HostTensorDescriptorTriton.from_tensor(ten, block_shape),
            shape_sym=shape_sym,
        )

    @staticmethod
    @sym.workaround_ignore_cache_record
    def get_tma_desc_triton(ten: torch.Tensor, block_shape: list[int]):
        return HostTensorDescriptorTriton.from_tensor(ten, block_shape)

    @staticmethod
    @sym.workaround_ignore_cache_record
    def tma_from_tensor_gluon(
        ten: torch.Tensor, shape_sym: str, block_shape: list[int]
    ):
        names, _ = sym.parse_shape_sym(shape_sym)
        assert len(names) == len(block_shape), (
            f"shape_sym {shape_sym} has {len(names)} dims, but block_shape has {len(block_shape)} dims."
        )
        assert len(names) == ten.ndim, (
            f"shape_sym {shape_sym} has {len(names)} dims, but tensor has {ten.ndim} dims."
        )
        layout = gl.NVMMASharedLayout.get_default_for(
            block_shape, torch_dtype_to_gluon(ten.dtype)
        )
        return TensorDesc(
            ptr=HostTensorDescriptorGluon.from_tensor(ten, block_shape, layout),
            shape_sym=shape_sym,
        )

    @staticmethod
    @sym.workaround_ignore_cache_record
    def get_tma_desc_gluon(ten: torch.Tensor, block_shape: list[int]):
        layout = gl.NVMMASharedLayout.get_default_for(
            block_shape, torch_dtype_to_gluon(ten.dtype)
        )
        return HostTensorDescriptorGluon.from_tensor(ten, block_shape, layout)

    @staticmethod
    @triton_jit
    def empty():
        return TensorDesc(
            ptr=None,
            shape_sym="B",
        )

    @staticmethod
    def empty_host():
        return TensorDesc(
            ptr=None,
            shape_sym="B",
        )

    @triton_jit
    def get_dtype(self):
        dtype: tl.constexpr = self.ptr.dtype.element_ty
        return TritonConstexprField(dtype)

    @triton_jit
    def get_ndim(self):
        ndim: tl.constexpr = len(sym.get_shape_names_from_sym(self.shape_sym))
        return TritonConstexprField(ndim)

    @triton_jit
    def is_tma_desc(self):
        if is_gluon():
            return TritonConstexprField(
                isinstance(self.ptr, gl.nvidia.hopper.tma.tensor_descriptor)
            )
        else:
            return TritonConstexprField(isinstance(self.ptr, tl.tensor_descriptor))

    @triton_jit
    def is_valid_desc(self):
        # ptr may be none.
        return TritonConstexprField(self.ptr is not None)

    @triton_jit
    def assert_is_valid(self):
        tl.static_assert(self.is_valid_desc().value, "desc pointer must not be None.")

    @triton_jit
    def assert_is_pointer(self):
        tl.static_assert(
            not self.is_tma_desc().value, "Only support pointer tensor desc."
        )

    @triton_jit
    def assert_is_tma_desc(self):
        tl.static_assert(self.is_tma_desc().value, "Only support tma tensor desc.")

    @triton_jit
    def get_default_blocked_io_layout_from_block(
        self, block_shape_sym: tl.constexpr, block_shape: tl.constexpr
    ):
        tl.static_assert(is_gluon(), "layout is only supported in gluon backend.")
        num_warps: tl.constexpr = get_num_warps()
        order: tl.constexpr = sym.get_blocked_layout_order(
            self.shape_sym, block_shape_sym
        )
        # tl.static_print(block_shape_sym, block_shape, order)

        layout: tl.constexpr = get_default_block_io_layout(
            shape=block_shape,
            bitwidth=self.get_dtype().value.primitive_bitwidth,
            order=order,
            num_warps=num_warps,
            num_threads_per_warp=32,
        )
        return TritonConstexprField(layout)

    @triton_jit
    def get_immutable_offseted_desc(
        self, off_names: tl.constexpr, offsets_cw: tl.tuple
    ):
        new_named_offs = self._ttfs_immutable_named_offsets.merge_add_offsets(
            off_names, offsets_cw
        )
        if is_gluon():
            return aggregate_replace_gluon(
                self,
                _ttfs_immutable_named_offsets=new_named_offs,
            )
        else:
            return aggregate_replace_triton(
                self,
                _ttfs_immutable_named_offsets=new_named_offs,
            )


class TensorDescFieldAccessor(TritonAggFieldAccessor):
    def __init__(
        self, ndim: int, passed_strides: str = "", constexpr_strides: str = ""
    ):
        # currently ndim is only used in validation
        self._ndim = ndim
        self._passed_strides = passed_strides
        if passed_strides != "":
            self._num_value_stride = len(passed_strides.split(","))
        else:
            self._num_value_stride = 0
        passed_strides_parts = [x.strip() for x in passed_strides.split(",")]
        constexpr_stride_idxes: list[int] = []
        if constexpr_strides:
            constexpr_stride_parts = [x.strip() for x in constexpr_strides.split(",")]
            for i, part in enumerate(passed_strides_parts):
                if part in constexpr_stride_parts:
                    constexpr_stride_idxes.append(i)
        self._constexpr_stride_idxes = constexpr_stride_idxes
        self._stride_multiple_of_short_name = "stride_mul"
        if ndim > 0:
            assert self._num_value_stride <= ndim, (
                f"passed_strides {passed_strides} has more dims than ndim {ndim}."
            )

    def get_custom_fields(self) -> list[tuple[str, bool]]:
        res: list[tuple[str, bool]] = [
            ("ptr", False),
            ("shape_sym", True),
            (self._stride_multiple_of_short_name, True),
        ]
        for i in range(self._num_value_stride):
            is_constexpr = i in self._constexpr_stride_idxes
            res.append((f"s{i}", is_constexpr))
        return res

    def get_load_call_node(
        self, meta: TritonAggFlatField, root_arg_name: str, fn_node: ast.Call
    ) -> ast.Call:
        new_stride_tuples = []
        for i in range(self._num_value_stride):
            arg_name = meta.mangle_path(root_arg_name, f"s{i}")
            new_stride_tuples.append(ast.Name(id=arg_name, ctx=ast.Load()))

        node = ast.Call(
            func=fn_node,
            args=[],
            keywords=[
                ast.keyword(
                    arg="ptr",
                    value=ast.Name(
                        id=meta.mangle_path(root_arg_name, "ptr"), ctx=ast.Load()
                    ),
                ),
                ast.keyword(
                    arg="shape_sym",
                    value=ast.Name(
                        id=meta.mangle_path(root_arg_name, "shape_sym"),
                        ctx=ast.Load(),
                    ),
                ),
                ast.keyword(
                    arg="stride_multiple_of",
                    value=ast.Name(
                        id=meta.mangle_path(
                            root_arg_name, self._stride_multiple_of_short_name
                        ),
                        ctx=ast.Load(),
                    ),
                ),
            ],
        )
        if self._passed_strides != "":
            node.keywords.append(
                ast.keyword(
                    arg="strides",
                    value=ast.Tuple(elts=new_stride_tuples, ctx=ast.Load()),
                ),
            )
            node.keywords.append(
                ast.keyword(
                    arg="_ttfs_tmp_pv_stride",
                    value=ast.Constant(value=self._passed_strides),
                )
            )
        return node

    def get_flatten_agg_to_kwarg_lines(
        self, meta: TritonAggFlatField, root_arg_name: str, desc_path: str
    ) -> list[str]:

        lines = [
            f"kwargs['{meta.mangle_path(root_arg_name, 'ptr')}'] = {desc_path}.ptr",
            f"kwargs['{meta.mangle_path(root_arg_name, 'shape_sym')}'] = {desc_path}.shape_sym",
            f"kwargs['{meta.mangle_path(root_arg_name, self._stride_multiple_of_short_name)}'] = {desc_path}.stride_multiple_of",
        ]
        if self._ndim > 0:
            lines.append(
                f"assert({desc_path}.ptr is not None and {desc_path}.ptr.ndim == {self._ndim}, 'TensorDesc ndim mismatch, expected {self._ndim}, get ' + str({desc_path}.ptr.ndim))"
            )
        if self._num_value_stride > 0:
            axes_var_name = meta.mangle_path(root_arg_name, "axes")
            # shape_sym is constexpr in host aggregate
            # allow invalid sym in passed_strides here.
            lines.append(
                f"{axes_var_name} = ttfs.tensor.sym.cached_get_sym_axes_host({desc_path}.shape_sym.value, '{self._passed_strides}', True)"
            )
            lines.append(f"if {desc_path}.ptr is not None:")
            for i in range(self._num_value_stride):
                # TODO currently hack for tensor descriptor.
                lines.append(f"    _stride_{i} = -1")
                lines.append(f"    if {axes_var_name}[{i}] >= 0:")
                lines.append(
                    f"        _stride_{i} = {desc_path}.ptr.stride({axes_var_name}[{i}]) if isinstance({desc_path}.ptr, torch.Tensor) else {desc_path}.ptr.strides[{axes_var_name}[{i}]]"
                )
                lines.append(
                    f"    kwargs['{meta.mangle_path(root_arg_name, f's{i}')}'] = _stride_{i}"
                )
        return lines


def tensor_desc_meta(
    passed_strides: str = "", constexpr_strides: str = "", ndim=-1
) -> FieldMeta:
    return FieldMeta(
        accessor=TensorDescFieldAccessor(ndim, passed_strides, constexpr_strides)
    )


@aggregate
class TensorDimMultipleOf:
    pass


@aggregate(kw_only=True)
class TensorManagerBase:
    ttfs_dim_multiple_of: TensorDimMultipleOf = dataclasses.field(
        default_factory=lambda: TensorDimMultipleOf()
    )
    _ttfs_internal_named_offsets: Annotated[
        NamedOffsets, Any, FieldMeta(is_kernel_arg=False)
    ] = dataclasses.field(default_factory=NamedOffsets)
    # store dims that replaced by replace_packed_dims.
    _ttfs_internal_original_dims: Annotated[
        NamedOffsets, Any, FieldMeta(is_kernel_arg=False)
    ] = dataclasses.field(default_factory=NamedOffsets)

    def __post_init__(self):
        # validate all TensorDesc fields
        fields = get_dcls_fields(self)
        all_fields_desc = []
        all_fields_not_desc = []
        for f in fields:
            key = f.name
            value = getattr(self, key)
            if isinstance(value, TensorDesc):
                all_fields_desc.append(key)
            else:
                all_fields_not_desc.append(key)
        for f in get_dcls_fields(TensorManagerBase):
            all_fields_not_desc.remove(f.name)
        shape_values = {}
        for f in fields:
            key = f.name
            value = getattr(self, key)
            if isinstance(value, TensorDesc):
                shape_sym = gl._unwrap_if_constexpr(value.shape_sym)
                shape_names, _ = sym.parse_shape_sym(shape_sym)

                if isinstance(value.ptr, torch.Tensor):
                    # cross-validation of shapes
                    for dim, shape_value in zip(shape_names, value.ptr.shape):
                        if dim in shape_values:
                            src_tensor_name, src_shape_value, shape_sym = shape_values[
                                dim
                            ]
                            assert src_shape_value == shape_value, (
                                f"Dimension {dim} has inconsistent shape values: {shape_values[dim]}({src_tensor_name}:{shape_sym}) and {shape_value}({key})."
                            )
                        else:
                            shape_values[dim] = (key, shape_value, value.shape_sym)
                elif isinstance(
                    value.ptr, (HostTensorDescriptorGluon, HostTensorDescriptorTriton)
                ):
                    assert isinstance(value.ptr.base, torch.Tensor), (
                        "Currently we only support host tensor desc with torch tensor base."
                    )
                    for dim, shape_value in zip(shape_names, value.ptr.base.shape):
                        if dim in shape_values:
                            src_tensor_name, src_shape_value, shape_sym = shape_values[
                                dim
                            ]
                            assert src_shape_value == shape_value, (
                                f"Dimension {dim} has inconsistent shape values: {shape_values[dim]}({src_tensor_name}:{shape_sym}) and {shape_value}({key})."
                            )
                        else:
                            shape_values[dim] = (key, shape_value, value.shape_sym)
                for dim_name in shape_names:
                    assert dim_name in all_fields_not_desc, (
                        f"Dimension {dim_name} doesn't exist in TensorManager. available dims: {all_fields_not_desc}"
                    )
                assert len(shape_names) == len(value.strides), (
                    f"Strides length {len(value.strides)} doesn't match shape length {len(shape_names)} for tensor {key}."
                )
        for f in fields:
            key = f.name
            value = getattr(self, key)
            if isinstance(value, tl.constexpr):
                if key in shape_values:
                    src_tensor_name, src_shape_value, shape_sym = shape_values[key]
                    assert src_shape_value == value.value, (
                        f"Dimension {key} has inconsistent shape values: {src_shape_value}({src_tensor_name}:{shape_sym}) and {value.value}({key})."
                    )

    @triton_jit
    def get_tensor_desc(self, name: tl.constexpr):
        desc = get_field(self, name).value
        return desc

    @triton_jit
    def get_dim_multiple_of(self, dim_name: tl.constexpr):
        if has_field(self.ttfs_dim_multiple_of, dim_name):
            dim_multiple_of_field = get_field(self.ttfs_dim_multiple_of, dim_name)
            tl.static_assert(
                dim_multiple_of_field.is_constexpr,
                "all fields in `ttfs_dim_multiple_of` must be constexpr.",
            )
            return dim_multiple_of_field
        else:
            return TritonConstexprField(1)

    @triton_jit
    def get_tensor_dim_size(self, name: tl.constexpr, axis: tl.constexpr):
        desc = get_field(self, name).value
        dim_name: tl.constexpr = sym.get_name_by_dim(desc.shape_sym, axis)
        return get_field(self, dim_name)

    @triton_jit
    def get_tensor_dim_size_by_name(self, name: tl.constexpr, dim_name: tl.constexpr):
        desc = get_field(self, name).value
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            desc.shape_sym, dim_name
        )
        return get_field(self, dim_name_unified)

    @triton_jit
    def get_tensor_stride(self, name: tl.constexpr, axis: tl.constexpr):
        desc = get_field(self, name).value
        if is_constexpr(desc.strides[axis]):
            if desc.strides[axis] < 0:
                # calc stride from dims, assume contiguous
                stride_names: tl.constexpr = sym.get_stride_names(desc.shape_sym, axis)
                constexpr_fields: tl.constexpr = filter_constexpr_fields(
                    self, stride_names
                )
                non_constexpr_fields: tl.constexpr = filter_non_constexpr_fields(
                    self, stride_names
                )
                # aggregate can keep constexpr info
                stride_c = TritonConstexprField(1)
                for i in gl.static_range(len(constexpr_fields)):
                    field = self._get_dim_field_may_replaced(
                        tl.constexpr(constexpr_fields[i])
                    )
                    # field = get_field(self, tl.constexpr(constexpr_fields[i]))
                    stride_c = TritonConstexprField(stride_c.value * field.value)
                if all_fields_is_constexpr(self, stride_names):
                    return stride_c
                else:
                    # for non-constexpr dims, we may need to use multiple_of
                    stride = 1
                    for i in gl.static_range(len(non_constexpr_fields)):
                        # field = get_field(self, tl.constexpr(non_constexpr_fields[i]))
                        field = self._get_dim_field_may_replaced(
                            tl.constexpr(non_constexpr_fields[i])
                        )

                        stride *= field.value
                    return TritonField(stride * stride_c.value)
            else:
                return TritonConstexprField(desc.strides[axis])
        else:
            return TritonField(desc.strides[axis])

    @triton_jit
    def _get_dim_field_may_replaced(
        self,
        name: tl.constexpr,
    ):
        if self._ttfs_internal_original_dims.is_name_exists(name).value:
            field = self._ttfs_internal_original_dims.get_offset_cw_by_name(name)
        else:
            field = get_field(self, tl.constexpr(name))
        return field

    @triton_jit
    def get_tensor_stride_with_multiple_of(
        self, name: tl.constexpr, axis: tl.constexpr
    ):
        desc = get_field(self, name).value
        stride_multiple_of_in_desc: tl.constexpr = desc.stride_multiple_of[axis]
        if is_constexpr(desc.strides[axis]):
            if desc.strides[axis] < 0:
                # if stride is unset, stride_multiple_of defined in desc will be ignored
                # calc stride from dims, assume contiguous
                stride_names: tl.constexpr = sym.get_stride_names(desc.shape_sym, axis)
                constexpr_fields: tl.constexpr = filter_constexpr_fields(
                    self, stride_names
                )
                non_constexpr_fields: tl.constexpr = filter_non_constexpr_fields(
                    self, stride_names
                )
                # aggregate can keep constexpr info
                stride_c = TritonConstexprField(1)
                stride_multiple_of_c = TritonConstexprField(1)
                for i in gl.static_range(len(constexpr_fields)):
                    field = self._get_dim_field_may_replaced(
                        tl.constexpr(constexpr_fields[i])
                    )
                    stride_c = TritonConstexprField(stride_c.value * field.value)
                    stride_multiple_of_c = TritonConstexprField(
                        stride_multiple_of_c.value
                        * self.get_dim_multiple_of(
                            tl.constexpr(constexpr_fields[i])
                        ).value
                    )
                if all_fields_is_constexpr(self, stride_names):
                    return StrideWithMultipleOf(
                        stride_c,
                        stride_multiple_of_c.value,
                        False,
                    )
                else:
                    # for non-constexpr dims, we may need to use multiple_of
                    stride = 1
                    for i in gl.static_range(len(non_constexpr_fields)):
                        field = self._get_dim_field_may_replaced(
                            tl.constexpr(non_constexpr_fields[i])
                        )
                        # field = get_field(self, tl.constexpr(non_constexpr_fields[i]))
                        stride *= field.value
                        stride_multiple_of_c = TritonConstexprField(
                            stride_multiple_of_c.value
                            * self.get_dim_multiple_of(
                                tl.constexpr(non_constexpr_fields[i])
                            ).value
                        )

                    return StrideWithMultipleOf(
                        TritonField(stride * stride_c.value),
                        stride_multiple_of_c.value,
                        stride_multiple_of_c.value != 1,
                    )
            else:
                return StrideWithMultipleOf(
                    TritonConstexprField(desc.strides[axis]),
                    stride_multiple_of_in_desc,
                    stride_multiple_of_in_desc != 1,
                )
        else:
            return StrideWithMultipleOf(
                TritonField(desc.strides[axis]),
                stride_multiple_of_in_desc,
                stride_multiple_of_in_desc != 1,
            )

    @triton_jit
    def get_tensor_stride_by_name(self, name: tl.constexpr, dim_name: tl.constexpr):
        desc = get_field(self, name).value
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            desc.shape_sym, dim_name
        )
        axis: tl.constexpr = sym.get_dim_by_name(desc.shape_sym, dim_name_unified)
        return self.get_tensor_stride(name, axis)

    @triton_jit
    def get_tensor_stride_with_multiple_of_by_name(
        self, name: tl.constexpr, dim_name: tl.constexpr
    ):
        desc = get_field(self, name).value
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            desc.shape_sym, dim_name
        )
        axis: tl.constexpr = sym.get_dim_by_name(desc.shape_sym, dim_name_unified)
        return self.get_tensor_stride_with_multiple_of(name, axis)

    @triton_jit
    def get_dim_offset_by_name_cwrapper(self, dim_name: tl.constexpr):
        if self._ttfs_internal_named_offsets.is_name_exists(dim_name).value:
            return self._ttfs_internal_named_offsets.get_offset_cw_by_name(dim_name)
        else:
            return TritonConstexprField(0)

    @triton_jit
    def get_dim_offset_tuple_cwrapper_by_names(self, dim_names: tl.constexpr):
        dim_name_lst: tl.constexpr = sym.unify_offset_names(dim_names)
        return [
            self.get_dim_offset_by_name_cwrapper(tl.constexpr(dim_name_lst[i]))
            for i in tl.tuple(sym.tuple_range(len(dim_name_lst)))
        ]

    @triton_jit
    def get_tensor_dim_is_divisible(
        self, name: tl.constexpr, axis: tl.constexpr, divisor: tl.constexpr
    ):
        desc = get_field(self, name).value
        dim_size = self.get_tensor_dim_size(name, axis)
        if dim_size.is_constexpr:
            return TritonConstexprField(dim_size.value % divisor == 0)
        else:
            dim_multiple_of: tl.constexpr = self.get_dim_multiple_of(
                sym.get_name_by_dim(desc.shape_sym, axis)
            ).value
            return TritonConstexprField(dim_multiple_of % divisor == 0)

    @triton_jit
    def get_ptr_offset(
        self,
        name: tl.constexpr,
        off_names: tl.constexpr,
        offsets_cw: tl.tuple,
    ):
        # off_names can be constexpr(["M", "N"]) or "M,N"
        off_names_u: tl.constexpr = sym.unify_offset_names(off_names)
        desc = get_field(self, name).value
        noffs = NamedOffsets(offsets_cw, off_names_u).get_included_offsets(
            desc.shape_sym
        )
        if len(noffs.offset_names) == 0:
            return 0
        else:
            offset = 0
            for i in gl.static_range(len(noffs.offset_names)):
                offset = (
                    offset
                    + self.get_tensor_stride_by_name(
                        name, tl.constexpr(noffs.offset_names[i])
                    ).value
                    * noffs.offsets_cw[i].value
                )
            return offset

    @triton_jit
    def get_offseted_ptr(
        self,
        name: tl.constexpr,
        off_names_sym: tl.constexpr,
        offsets_cw: tl.tuple,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        desc = get_field(self, name).value
        tl.static_assert(
            not desc.is_tma_desc().value, "Only support pointer tensor desc."
        )
        if cast_offset_to_64bit:
            offsets_cw = [
                _cast_to_i64_if_needed(offsets_cw[i])
                for i in tl.tuple(sym.tuple_range(len(offsets_cw)))
            ]
        return desc.ptr + self.get_ptr_offset(name, off_names_sym, offsets_cw)

    @triton_jit
    def get_current_offseted_ptr_except(
        self,
        name: tl.constexpr,
        except_sym: tl.constexpr,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        new_named_offs = self._ttfs_internal_named_offsets.get_filtered_offsets(
            except_sym
        )
        return self.get_offseted_ptr(
            name,
            new_named_offs.offset_names,
            new_named_offs.offsets_cw,
            cast_offset_to_64bit,
        )

    @triton_jit
    def get_tensor_dim_sizes_by_sym(self, name: tl.constexpr, shape_sym: tl.constexpr):
        shape_names: tl.constexpr = sym.get_shape_names_from_sym(shape_sym)
        shape = [
            self.get_tensor_dim_size_by_name(name, tl.constexpr(shape_names[i]))
            for i in tl.tuple(sym.tuple_range(len(shape_names)))
        ]
        return shape

    @triton_jit
    def get_tensor_strides_by_sym(self, name: tl.constexpr, shape_sym: tl.constexpr):
        shape_names: tl.constexpr = sym.get_shape_names_from_sym(shape_sym)
        shape = [
            self.get_tensor_stride_by_name(name, tl.constexpr(shape_names[i]))
            for i in tl.tuple(sym.tuple_range(len(shape_names)))
        ]
        return shape

    @triton_jit
    def get_block_desc(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
        block_sizes: tl.constexpr,
        block_layout: tl.constexpr = None,
    ):
        desc = get_field(self, name).value
        desc.assert_is_pointer()
        desc.assert_is_valid()
        if is_gluon():
            if block_layout is None:
                block_layout_: tl.constexpr = (
                    desc.get_default_blocked_io_layout_from_block(
                        block_shape_sym, block_sizes
                    ).value
                )
            else:
                block_layout_: tl.constexpr = block_layout
        else:
            block_layout_: tl.constexpr = None
        block_shape_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        if sym.is_any_sym_in_names(
            block_shape_sym_global, self._ttfs_internal_named_offsets.offset_names
        ):
            offset_tuple = self._ttfs_internal_named_offsets.query_offsets_cw_by_sym(
                block_shape_sym_global
            )
            return BlockedTensorDescWithOffset(
                # ptr=desc.ptr,
                ptr=self.get_current_offseted_ptr_except(name, block_shape_sym_global),
                shape_sym=desc.shape_sym,
                strides=desc.strides,
                name=name,
                mgr=self,
                layout=block_layout_,
                block_shape_sym=block_shape_sym,
                block_shape=block_sizes,
                offset_tuple=offset_tuple,
            )
        else:
            # return a pointer with current offset variables.
            # block_offsets
            return BlockedTensorDesc(
                # ptr=desc.ptr,
                ptr=self.get_current_offseted_ptr_except(name, block_shape_sym_global),
                shape_sym=desc.shape_sym,
                strides=desc.strides,
                name=name,
                mgr=self,
                layout=block_layout_,
                block_shape_sym=block_shape_sym,
                block_shape=block_sizes,
            )

    @triton_jit
    def get_offseted_block_desc(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
        block_sizes: tl.constexpr,
        block_layout: tl.constexpr = None,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        # TODO block_sizes must be constexpr, check this.
        desc = get_field(self, name).value
        desc.assert_is_pointer()
        desc.assert_is_valid()
        if is_gluon():
            if block_layout is None:
                block_layout_: tl.constexpr = (
                    desc.get_default_blocked_io_layout_from_block(
                        block_shape_sym, block_sizes
                    ).value
                )
            else:
                block_layout_: tl.constexpr = block_layout
        else:
            block_layout_: tl.constexpr = None
        block_shape_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        named_offsets = self._ttfs_internal_named_offsets.query_named_offsets_by_sym(
            block_shape_sym_global
        )
        if cast_offset_to_64bit:
            named_offsets = named_offsets.cast_to_i64_if_needed()
        # tl.static_print(block_shape_sym_global, named_offsets)
        return BlockedTensorDescWithOffset(
            # ptr=desc.ptr,
            ptr=self.get_current_offseted_ptr_except(
                name, block_shape_sym_global, cast_offset_to_64bit
            ),
            shape_sym=desc.shape_sym,
            strides=desc.strides,
            name=name,
            mgr=self,
            layout=block_layout_,
            block_shape_sym=block_shape_sym,
            block_shape=block_sizes,
            named_offsets=named_offsets,
        )

    @triton_jit
    def get_external_offset_block_desc(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
        block_sizes: tl.constexpr,
        offset_tuple: tl.tuple,
        block_layout: tl.constexpr = None,
    ):
        # TODO if desc.ptr is tma desc?
        desc = get_field(self, name).value
        desc.assert_is_pointer()
        desc.assert_is_valid()
        if is_gluon():
            if block_layout is None:
                block_layout_: tl.constexpr = (
                    desc.get_default_blocked_io_layout_from_block(
                        block_shape_sym, block_sizes
                    ).value
                )
            else:
                block_layout_: tl.constexpr = block_layout
        else:
            block_layout_: tl.constexpr = None
        block_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        block_sym_global_names: tl.constexpr = sym.get_shape_names_from_sym(
            block_sym_global
        )

        return BlockedTensorDescWithOffset(
            ptr=desc.ptr,
            shape_sym=desc.shape_sym,
            strides=desc.strides,
            name=name,
            mgr=self,
            layout=block_layout_,
            block_shape_sym=block_shape_sym,
            block_shape=block_sizes,
            named_offsets=NamedOffsets(offset_tuple, block_sym_global_names),
        )

    @triton_jit
    def get_external_tma_block_desc(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
        offset_tuple=None,
    ):
        desc = get_field(self, name).value
        desc.assert_is_valid()
        tl.static_assert(desc.is_tma_desc().value, "must be a tensor desc")
        if is_gluon():
            smem_layout: tl.constexpr = desc.ptr.layout
        else:
            smem_layout: tl.constexpr = None
        tma_desc = desc.ptr
        # TODO validate block_shape_sym
        block_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        block_sym_global_names: tl.constexpr = sym.get_shape_names_from_sym(
            block_sym_global
        )
        block_sym_axes: tl.constexpr = sym.get_sym_axes(desc.shape_sym, block_shape_sym)
        assert sym.is_int_list_sorted(block_sym_axes), (
            f"block_sym {block_shape_sym} must have same order as shape_sym {desc.shape_sym} in TMA."
        )

        named_offs_except_block = (
            self._ttfs_internal_named_offsets.get_filtered_offsets(block_sym_global)
        )
        named_offs_immu_except_block = (
            desc._ttfs_immutable_named_offsets.get_filtered_offsets(block_sym_global)
        )
        local_block_shape: tl.constexpr = sym.index_shape_and_valid_other_one(
            desc.ptr.block_shape, block_sym_axes
        )
        block_offset_in_tm = self.get_dim_offset_tuple_cwrapper_by_names(
            block_sym_global
        )
        immu_block_offset = (
            desc._ttfs_immutable_named_offsets.get_offsets_cw_by_sym_default_zero(
                block_sym_global
            )
        )
        offset_tuple_with_immu_offset = [
            cwrapped_add(block_offset_in_tm[i], immu_block_offset[i])
            for i in tl.tuple(sym.tuple_range(len(block_offset_in_tm)))
        ]
        new_named_offs = NamedOffsets(
            offset_tuple_with_immu_offset, block_sym_global_names
        )
        final_non_block_no = named_offs_except_block.merge_add_offsets(
            named_offs_immu_except_block.offset_names,
            named_offs_immu_except_block.offsets_cw,
        )
        # tl.static_print(name, "named_offs_immu_except_block",
        #     named_offs_except_block,
        #     named_offs_immu_except_block)

        # tl.static_print(name, "final_non_block_no",
        #     final_non_block_no.offsets_cw,
        #     final_non_block_no.offset_names,
        #     offset_tuple_with_immu_offset)
        if is_gluon():
            return BlockedTensorDescTMATriton(
                ptr=tma_desc,
                shape_sym=desc.shape_sym,
                strides=desc.strides,
                name=name,
                mgr=self,
                block_shape_sym=block_shape_sym,
                block_shape=local_block_shape,
                layout=smem_layout,
                non_block_named_offsets=final_non_block_no,
                named_offsets=(
                    NamedOffsets(offset_tuple, block_sym_global_names)
                    if offset_tuple is not None
                    else new_named_offs
                ),
            )
        else:
            return BlockedTensorDescTMATriton(
                ptr=tma_desc,
                shape_sym=desc.shape_sym,
                strides=desc.strides,
                name=name,
                mgr=self,
                block_shape_sym=block_shape_sym,
                block_shape=local_block_shape,
                layout=smem_layout,
                non_block_named_offsets=final_non_block_no,
                named_offsets=(
                    NamedOffsets(offset_tuple, block_sym_global_names)
                    if offset_tuple is not None
                    else new_named_offs
                ),
            )

    # @triton_jit
    # def create_tma_block_desc(
    #     self,
    #     name: tl.constexpr,
    #     block_shape_sym: tl.constexpr,
    #     block_sizes: tl.constexpr,
    #     offset_tuple=None,
    # ):
    #     # TODO currently we assume user offset pointer with all remain dims except block dims.
    #     # e.g. for [B, S, H, D], we assume user offset B and H when get block desc with block shape [S, D]

    #     # if user use `offset_all_tensor`, we get b and h offset and original pointer.
    #     # it's ok because B, H, D is always divisible, we can use [B * S, H * D] as blocked tma desc.

    #     # however, if tensor shape is [B, H, S, D], we must use [B * H * S, D] as blocked tma desc,
    #     # if S isn't divisible, this tma will load/store wrong data.
    #     desc = get_field(self, name).value
    #     desc.assert_is_valid()
    #     tl.static_assert(not desc.is_tma_desc().value, "this function is used for device-side TensorDescriptor.")
    #     shape = self.get_tensor_dim_sizes_by_sym(name, block_shape_sym)
    #     strides = self.get_tensor_strides_by_sym(name, block_shape_sym)
    #     if is_gluon():
    #         smem_layout: tl.constexpr = gl.NVMMASharedLayout.get_default_for(
    #             block_sizes,
    #             desc.get_dtype().value,
    #             # TODO transposed only support matrix.
    #             transposed=sym.check_matrix_is_transposed(
    #                 desc.shape_sym, block_shape_sym
    #             ),
    #         )
    #         # WARNING: this requires triton 3.6+
    #         tma_desc = gl.nvidia.hopper.tma.make_tensor_descriptor(
    #             desc.ptr, shape, strides, block_sizes, smem_layout
    #         )
    #     else:
    #         tma_desc = tl.make_tensor_descriptor(
    #             desc.ptr, shape, strides, block_sizes
    #         )
    #         smem_layout: tl.constexpr = None
    #     block_sym_unified: tl.constexpr = sym.local_sym_to_global(
    #         desc.shape_sym, block_shape_sym
    #     )

    #     return BlockedTensorDescWithOffset(
    #         ptr=tma_desc,
    #         shape_sym=desc.shape_sym,
    #         strides=desc.strides,
    #         name=name,
    #         mgr=self,
    #         block_shape_sym=block_shape_sym,
    #         block_shape=block_sizes,
    #         layout=smem_layout,
    #         offset_tuple=(
    #             offset_tuple
    #             if offset_tuple is not None
    #             else self.get_dim_offset_tuple_cwrapper_by_names(block_sym_unified)
    #         ),
    #     )

    @triton_jit
    def get_block_desc_by_ptr(
        self,
        ptr,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
        block_sizes: tl.constexpr,
        block_layout: tl.constexpr = None,
    ):
        desc = get_field(self, name).value
        desc.assert_is_valid()
        if is_gluon():
            if block_layout is None:
                block_layout_: tl.constexpr = (
                    desc.get_default_blocked_io_layout_from_block(
                        block_shape_sym, block_sizes
                    ).value
                )
            else:
                block_layout_: tl.constexpr = block_layout
        else:
            block_layout_: tl.constexpr = None

        return BlockedTensorDesc(
            ptr=ptr,
            shape_sym=desc.shape_sym,
            strides=desc.strides,
            name=name,
            mgr=self,
            block_shape_sym=block_shape_sym,
            block_shape=block_sizes,
            layout=block_layout_,
        )

    @triton_jit
    def _get_offseted_desc(
        self,
        desc_key: tl.constexpr,
        desc,
        off_names_sym: tl.constexpr,
        offsets_cw: tl.tuple,
    ):

        if desc.is_valid_desc().value:
            if desc.is_tma_desc().value:
                res = desc.get_immutable_offseted_desc(
                    off_names=sym.get_shape_names_from_sym(off_names_sym),
                    offsets_cw=offsets_cw,
                )
            else:
                if is_gluon():
                    res = aggregate_replace_gluon(
                        desc,
                        ptr=self.get_offseted_ptr(
                            desc_key,
                            off_names_sym,
                            offsets_cw,
                            cast_offset_to_64bit=True,
                        ),
                    )
                else:
                    res = aggregate_replace_triton(
                        desc,
                        ptr=self.get_offseted_ptr(
                            desc_key,
                            off_names_sym,
                            offsets_cw,
                            cast_offset_to_64bit=True,
                        ),
                    )

        else:
            res = desc
        return res

    @triton_jit
    def offset_all_tensor_ptr(self, off_names_sym: tl.constexpr, offsets: tl.tuple):
        """offset all tensor desc ptrs that contain dimensions in off_names.
        e.g. for tensor manager with q(B, S, H, D), m(B, H, S) and c(B, S),
        tm.offset_all_tensor_ptr(["B", "H"], (1, 2)) will offset q and m ptrs by b and h.
        c will be offseted only by b.

        tensor descriptors behavior is same as `offset_all_tensor`.

        WARNING: you should use offset_all_tensor for dimensions that need to check boundry.
        WARNING: this function should be used in situation such as varlen attn.
        """
        off_names: tl.constexpr = sym.get_shape_names_from_sym(off_names_sym)
        tl.static_assert(
            len(off_names) == len(offsets), "offset names and offsets length mismatch."
        )
        all_field_keys: tl.constexpr = get_all_field_keys_with_type(self, TensorDesc)
        offsets_cw = tuple_to_cwrapper(offsets)
        tl.static_print(
            "[ttfs.static] offset_all_tensor_ptr all_field_keys:", all_field_keys
        )
        if is_gluon():
            all_fields_tuple = get_all_fields_with_type_gluon(self, TensorDesc)
            all_fields_tuple_offseted = [
                self._get_offseted_desc(
                    all_field_keys[i],
                    all_fields_tuple[i],
                    off_names_sym,
                    offsets_cw,
                )
                for i in tl.tuple(sym.tuple_range(len(all_field_keys)))
            ]
            return replace_all_fields_with_type_gluon(
                self, TensorDesc, all_fields_tuple_offseted
            )
        else:
            all_fields_tuple = get_all_fields_with_type_triton(self, TensorDesc)

            all_fields_tuple_offseted = [
                self._get_offseted_desc(
                    all_field_keys[i],
                    all_fields_tuple[i],
                    off_names_sym,
                    offsets_cw,
                )
                for i in tl.tuple(sym.tuple_range(len(all_field_keys)))
            ]
            return replace_all_fields_with_type_triton(
                self, TensorDesc, all_fields_tuple_offseted
            )

    @triton_jit
    def offset_all_tensor(self, off_names: tl.constexpr, offsets: tl.tuple):
        """Offset tensor descriptors without change ptrs.
        usually used in dimensions that may be out of boundry, e.g. sequence dimension.

        WARNING: you can't use this in a loop because it will change static type of this aggregate object.
        TODO currently this function will override previous offset, which may confuse users.
        """

        # store offsets in _ttfs_internal_offset_names and _ttfs_internal_offsets_cw
        off_names_u: tl.constexpr = sym.unify_offset_names(off_names)
        tl.static_assert(
            len(off_names_u) == len(offsets),
            "offset names and offsets length mismatch.",
        )

        if is_gluon():
            return aggregate_replace_gluon(
                self,
                _ttfs_internal_named_offsets=self._ttfs_internal_named_offsets.merge_add_offsets(
                    off_names_u, tuple_to_cwrapper(offsets)
                ),
            )
        else:
            return aggregate_replace_triton(
                self,
                _ttfs_internal_named_offsets=self._ttfs_internal_named_offsets.merge_add_offsets(
                    off_names_u, tuple_to_cwrapper(offsets)
                ),
            )

    @triton_jit
    def replace_packed_dims(
        self,
        dims_sym: tl.constexpr,
        dims_tuple,
    ):
        """When we want to handle one sequence of a packed tensor, we need to set
        the packed dimensions to the actual sequence length.
        WARNING: call this function only affect boundry check. the stride calculation based on shape
        still use original dims, so don't use this to change dims!
        """
        dims_names: tl.constexpr = sym.get_shape_names_from_sym(dims_sym)
        dims_tuple_cw = tuple_to_cwrapper(dims_tuple)
        values = [
            _tm_replace_validate(
                get_field(self, tl.constexpr(dims_names[i])), dims_tuple_cw[i]
            )
            for i in tl.tuple(sym.tuple_range(len(dims_names)))
        ]
        original_dims = [
            get_field(self, tl.constexpr(dims_names[i]))
            for i in tl.tuple(sym.tuple_range(len(dims_names)))
        ]
        # original_dims may contains dims that is already replaced, so we
        # use old correct values to replace+merge original_dims.
        if is_gluon():
            return aggregate_replace_gluon(
                replace_fields_gluon(self, dims_names, values),
                _ttfs_internal_original_dims=NamedOffsets(
                    original_dims, dims_names
                ).merge_replace_offsets(
                    self._ttfs_internal_original_dims.offset_names,
                    self._ttfs_internal_original_dims.offsets_cw,
                ),
            )
        else:
            return aggregate_replace_triton(
                replace_fields_triton(self, dims_names, values),
                _ttfs_internal_original_dims=NamedOffsets(
                    original_dims, dims_names
                ).merge_replace_offsets(
                    self._ttfs_internal_original_dims.offset_names,
                    self._ttfs_internal_original_dims.offsets_cw,
                ),
            )


@triton_jit
def _tm_replace_validate(prev_value_to_assign, value):
    if prev_value_to_assign.is_constexpr:
        tl.static_assert(
            value.is_constexpr, "can't assign non-constexpr value to constexpr field"
        )
    return value


@constexpr_function
def _insert_front(val, vec):
    # print(val, vec, tl.core._unwrap_if_constexpr(vec))
    return [val] + [tl.core._unwrap_if_constexpr(v) for v in vec]


@aggregate(kw_only=True)
class BlockedTensorDesc(TensorDesc):
    name: tl.constexpr
    mgr: TensorManagerBase
    block_shape_sym: tl.constexpr  # e.g. "S,H", can be alias name
    block_shape: tl.constexpr  # e.g. (32, 32)
    layout: tl.constexpr

    @triton_jit
    def offset_desc_ptr(
        self,
        off_names: tl.constexpr,
        offsets: tl.tuple,
    ):
        self.assert_is_pointer()
        self.assert_is_valid()

        return aggregate_replace_gluon(
            self,
            # pointer check (not tma) is done in get_offseted_ptr
            ptr=self.mgr.get_offseted_ptr(
                self.name,
                off_names,
                offsets,
            ),
        )

    @triton_jit
    def get_dim_size(self, axis: tl.constexpr):
        return self.mgr.get_tensor_dim_size(self.name, axis)

    @triton_jit
    def get_dim_size_by_block_dim(self, block_dim: tl.constexpr):
        block_name: tl.constexpr = sym.get_block_dim_name_by_idx(
            self.block_shape_sym, block_dim
        )
        return self.get_dim_size_by_name(block_name)

    @triton_jit
    def get_dim_size_by_name(self, dim_name: tl.constexpr):
        return self.mgr.get_tensor_dim_size_by_name(self.name, dim_name)

    @triton_jit
    def get_block_size_by_name(self, block_dim_name: tl.constexpr):
        dim: tl.constexpr = sym.get_dim_by_name(self.block_shape_sym, block_dim_name)
        return TritonConstexprField(self.block_shape[dim])

    @triton_jit
    def get_stride(self, axis: tl.constexpr):
        return self.mgr.get_tensor_stride(self.name, axis)

    @triton_jit
    def get_stride_by_name(self, dim_name: tl.constexpr):
        return self.mgr.get_tensor_stride_by_name(self.name, dim_name)

    @triton_jit
    def get_blocked_masks_except_axis(self, axis: tl.constexpr):
        return self.get_blocked_masks(except_axis=axis)

    @triton_jit
    def get_blocked_masks_except_dim_name(self, block_dim_name: tl.constexpr):
        dim: tl.constexpr = sym.get_dim_by_name(self.block_shape_sym, block_dim_name)
        return self.get_blocked_masks_except_axis(dim)

    @triton_jit
    def _get_block_dim_is_divisible(self, axis: tl.constexpr):
        block_size: tl.constexpr = self.block_shape[axis]
        dim = self.get_dim_size_by_block_dim(axis)
        if dim.is_constexpr:
            return TritonConstexprField(dim.value % block_size == 0)
        else:
            dim_multiple_of: tl.constexpr = self.mgr.get_dim_multiple_of(
                sym.get_block_dim_name_by_idx(self.block_shape_sym, axis)
            ).value
            return TritonConstexprField(dim_multiple_of % block_size == 0)

    @triton_jit
    def _get_block_axes_is_divisible(self, except_axis: tl.constexpr = -1):
        block_dim_is_divisible: tl.constexpr = [
            self._get_block_dim_is_divisible(i).value
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        return TritonConstexprField(
            sym.get_false_inds_of_bool_tuple(block_dim_is_divisible, except_axis)
        )

    @triton_jit
    def is_need_block_mask(self, except_axis: tl.constexpr = -1):
        block_dims_is_divisible = self._get_block_axes_is_divisible(except_axis)
        return TritonConstexprField(len(block_dims_is_divisible.value) > 0)

    @triton_jit
    def get_blocked_masks(self, except_axis: tl.constexpr = -1):
        block_dims_is_divisible = self._get_block_axes_is_divisible(except_axis)
        gl.static_assert(
            len(block_dims_is_divisible.value) > 0,
            "use `is_need_block_mask` to check before get mask.",
        )
        masks = [
            (
                self.get_blocked_offset_by_idx(
                    block_dims_is_divisible.value[i], expand_dims=True
                )
                < self.get_dim_size_by_block_dim(block_dims_is_divisible.value[i]).value
            )
            for i in tl.tuple(sym.tuple_range(len(block_dims_is_divisible.value)))
        ]

        mask = masks[0]
        for i in tl.static_range(1, len(masks)):
            mask = mask & masks[i]
        return mask

    @triton_jit
    def get_default_blocked_io_layout(self):
        return self.get_default_blocked_io_layout_from_block(
            self.block_shape_sym, self.block_shape
        )

    @triton_jit
    def get_cur_offset_cw_by_block_idx(self, block_idx):
        return TritonConstexprField(0)

    @triton_jit
    def get_blocked_offset_by_idx(
        self,
        idx: tl.constexpr,
        expand_dims: tl.constexpr = False,
        out_of_range: tl.constexpr = 0,
        use_i64: tl.constexpr = False,
    ):
        block_size: tl.constexpr = self.block_shape[idx]
        if is_gluon():
            res_layout: tl.constexpr = sym.get_sliced_layout(
                self.layout, len(self.block_shape), idx
            )
            res = gl.arange(0, block_size, layout=res_layout)
        else:
            res = tl.arange(0, block_size)
        if use_i64:
            res = res.to(tl.int64)
        dim_name: tl.constexpr = sym.get_block_dim_name_by_idx(
            self.block_shape_sym, idx
        )
        # dim_name_global: tl.constexpr = sym.local_name_to_global(
        #     self.shape_sym, dim_name
        # )
        res = res + self.get_cur_offset_cw_by_block_idx(idx).value
        if out_of_range == 0:
            res_oor = res
        elif out_of_range == 1:
            boundry = self.get_dim_size_by_block_dim(idx)
            res_oor = gl.where(res < boundry.value, res, 0)
        else:
            boundry = self.get_dim_size_by_block_dim(idx)
            # TODO should we use multiple_of in ttfs_dim_multiple_of here if boundry isn't constexpr?
            res_oor = res % boundry.value

        if not expand_dims:
            return res_oor
        else:
            return self.unslice_1d_offset(res_oor, dim_name)

    @triton_jit
    def get_blocked_offset_base_by_idx(
        self,
        idx: tl.constexpr,
        expand_dims: tl.constexpr = False,
    ):
        block_size: tl.constexpr = self.block_shape[idx]
        if is_gluon():
            res_layout: tl.constexpr = sym.get_sliced_layout(
                self.layout, len(self.block_shape), idx
            )
            res = gl.arange(0, block_size, layout=res_layout)
        else:
            res = tl.arange(0, block_size)
        dim_name: tl.constexpr = sym.get_block_dim_name_by_idx(
            self.block_shape_sym, idx
        )
        if not expand_dims:
            return res
        else:
            return self.unslice_1d_offset(res, dim_name)

    @triton_jit
    def _get_dim_by_block_dim_name(self, dim_name: tl.constexpr):
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            self.shape_sym, dim_name
        )
        block_sym_unified: tl.constexpr = sym.local_sym_to_global(
            self.shape_sym, self.block_shape_sym
        )
        block_idx: tl.constexpr = sym.get_dim_by_name(
            block_sym_unified, dim_name_unified
        )
        return TritonConstexprField(block_idx)

    @triton_jit
    def unslice_1d_offset(self, offset_1d, dim_name: tl.constexpr):
        block_idx: tl.constexpr = self._get_dim_by_block_dim_name(dim_name).value
        return self.unslice_1d_offset_by_idx(offset_1d, block_idx)

    @triton_jit
    def unslice_1d_offset_by_idx(self, offset_1d, block_idx: tl.constexpr):
        axes: tl.constexpr = sym.get_sliced_axes(
            len(self.block_shape), block_idx, descending=False
        )
        for i in tl.static_range(len(axes)):
            offset_1d = offset_1d.expand_dims(axes[i])
        return offset_1d

    @triton_jit
    def get_blocked_offset(
        self,
        dim_name: tl.constexpr,
        expand_dims: tl.constexpr = False,
        out_of_range: tl.constexpr = 0,
    ):
        dim: tl.constexpr = self._get_dim_by_block_dim_name(dim_name).value
        return self.get_blocked_offset_by_idx(dim, expand_dims, out_of_range)

    @triton_jit
    def get_blocked_offset_base(
        self,
        dim_name: tl.constexpr,
        expand_dims: tl.constexpr = False,
    ):
        """Get base blocked offset without adding current offset, which can be used to create mask."""
        dim: tl.constexpr = self._get_dim_by_block_dim_name(dim_name).value
        return self.get_blocked_offset_base_by_idx(dim, expand_dims)

    @triton_jit
    def get_blocked_ptrs(
        self,
        out_of_range: tl.constexpr = 0,
        use_i64: tl.constexpr = False,
        gather_inds=None,
        gather_axis: tl.constexpr = 0,
        add_offset_to_inds: tl.constexpr = True,
    ):
        strides = [
            self.mgr.get_tensor_stride_with_multiple_of_by_name(
                self.name, sym.get_block_dim_name_by_idx(self.block_shape_sym, i)
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        if gather_inds is not None:
            if add_offset_to_inds:
                offsets = [
                    (
                        self.get_cur_offset_cw_by_block_idx(i).value
                        + self.unslice_1d_offset_by_idx(gather_inds, i)
                    )
                    if i == gather_axis
                    else self.get_blocked_offset_by_idx(
                        i,
                        expand_dims=True,
                        out_of_range=out_of_range,
                        use_i64=use_i64,
                    )
                    for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
                ]
            else:
                offsets = [
                    (self.unslice_1d_offset_by_idx(gather_inds, i))
                    if i == gather_axis
                    else self.get_blocked_offset_by_idx(
                        i,
                        expand_dims=True,
                        out_of_range=out_of_range,
                        use_i64=use_i64,
                    )
                    for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
                ]

        else:
            offsets = [
                self.get_blocked_offset_by_idx(
                    i,
                    expand_dims=True,
                    out_of_range=out_of_range,
                    use_i64=use_i64,
                )
                for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
            ]

        # triton/gluon analysizer perfer ptr + offset pattern instead of ptr + some_func_or_op(), so we have to inline them here.
        # if use ptr + self.get_blocked_offsets() or use gl.static_range to sum offsets first, triton kernel will use more registers.

        # multiple_of: if last dim isn't constexpr, it must be multiple_of aligned to allow vector access.
        # user can specify it by `stride_multiple_of` in TensorDesc or `ttfs_dim_multiple_of` in TensorManager (for auto inferenced stride).
        if len(strides) == 1:
            return self.ptr + offsets[0] * (
                tl.multiple_of(strides[0].stride.value, strides[0].multiple_of)
                if strides[0].need_multiple_of
                else strides[0].stride.value
            )
        elif len(strides) == 2:
            return (
                self.ptr
                + offsets[0]
                * (
                    tl.multiple_of(strides[0].stride.value, strides[0].multiple_of)
                    if strides[0].need_multiple_of
                    else strides[0].stride.value
                )
                + offsets[1]
                * (
                    tl.multiple_of(strides[1].stride.value, strides[1].multiple_of)
                    if strides[1].need_multiple_of
                    else strides[1].stride.value
                )
            )
        elif len(strides) == 3:
            return (
                self.ptr
                + offsets[0]
                * (
                    tl.multiple_of(strides[0].stride.value, strides[0].multiple_of)
                    if strides[0].need_multiple_of
                    else strides[0].stride.value
                )
                + offsets[1]
                * (
                    tl.multiple_of(strides[1].stride.value, strides[1].multiple_of)
                    if strides[1].need_multiple_of
                    else strides[1].stride.value
                )
                + offsets[2]
                * (
                    tl.multiple_of(strides[2].stride.value, strides[2].multiple_of)
                    if strides[2].need_multiple_of
                    else strides[2].stride.value
                )
            )
        elif len(strides) == 4:
            return (
                self.ptr
                + offsets[0]
                * (
                    tl.multiple_of(strides[0].stride.value, strides[0].multiple_of)
                    if strides[0].need_multiple_of
                    else strides[0].stride.value
                )
                + offsets[1]
                * (
                    tl.multiple_of(strides[1].stride.value, strides[1].multiple_of)
                    if strides[1].need_multiple_of
                    else strides[1].stride.value
                )
                + offsets[2]
                * (
                    tl.multiple_of(strides[2].stride.value, strides[2].multiple_of)
                    if strides[2].need_multiple_of
                    else strides[2].stride.value
                )
                + offsets[3]
                * (
                    tl.multiple_of(strides[3].stride.value, strides[3].multiple_of)
                    if strides[3].need_multiple_of
                    else strides[3].stride.value
                )
            )
        else:
            # general case, but use more registers.
            res = offsets[0]
            for i in gl.static_range(1, len(strides)):
                res += offsets[i] * (
                    tl.multiple_of(strides[i].stride.value, strides[i].multiple_of)
                    if strides[i].need_multiple_of
                    else strides[i].stride.value
                )
            return self.ptr + res

    @triton_jit
    def get_blocked_offsets(self, out_of_range: tl.constexpr = 0):
        strides = [
            self.mgr.get_tensor_stride_with_multiple_of_by_name(
                self.name, sym.get_block_dim_name_by_idx(self.block_shape_sym, i)
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        offsets = [
            self.get_blocked_offset_by_idx(
                i, expand_dims=True, out_of_range=out_of_range
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        res = offsets[0]
        for i in gl.static_range(1, len(strides)):
            res += offsets[i] * (
                tl.multiple_of(strides[i].stride.value, strides[i].multiple_of)
                if strides[i].need_multiple_of
                else strides[i].stride.value
            )
        return res

    @triton_jit
    def get_default_smem_layout(self):
        tl.static_assert(is_gluon(), "layout is only supported in gluon backend.")
        gl.static_assert(
            len(self.block_shape) <= 2, "Only support 1D/2D blocked tensor for now."
        )
        return TritonConstexprField(
            gl.NVMMASharedLayout.get_default_for(
                self.block_shape,
                self.get_dtype().value,
                transposed=sym.check_matrix_is_transposed(
                    self.shape_sym, self.block_shape_sym
                ),
            )
        )

    @triton_jit
    def get_default_swizzled_smem_layout(self, op_idx: tl.constexpr):
        tl.static_assert(is_gluon(), "layout is only supported in gluon backend.")
        gl.static_assert(
            len(self.block_shape) == 2, "Only support 2D blocked tensor for now."
        )
        kwidth: tl.constexpr = 32 // self.get_dtype().value.primitive_bitwidth
        is_transposed = sym.check_matrix_is_transposed(
            self.shape_sym, self.block_shape_sym
        )
        return TritonConstexprField(
            get_default_swizzed_shared_layout_nvidia(
                op_idx,
                kwidth,
                self.block_shape,
                [0, 1] if is_transposed else [1, 0],
                self.get_dtype().value,
            )
        )

    @triton_jit
    def allocate_shared_memory(self, num_stages: tl.constexpr):
        tl.static_assert(
            is_gluon(), "allocate_shared_memory is only supported in gluon backend."
        )
        dtype: gl.constexpr = self.get_dtype().value
        # tl.static_print(self.name, "allocate_shared_memory", num_stages, self.block_shape)
        return gl.allocate_shared_memory(
            dtype,
            _insert_front(num_stages, self.block_shape),
            layout=self.get_default_smem_layout().value,
        )

    @triton_jit
    def allocate_single_shared_memory(self):
        tl.static_assert(
            is_gluon(), "allocate_shared_memory is only supported in gluon backend."
        )
        dtype: gl.constexpr = self.get_dtype().value
        return gl.allocate_shared_memory(
            dtype, self.block_shape, layout=self.get_default_smem_layout().value
        )

    @triton_jit
    def masked_load(self, apply_mask: tl.constexpr = True, other=None):
        """Load current block immediately. mask is applied by default.
        Usually used in triton kernels without loop.

        Don't use this function in any loop, use iterator in io.py instead.
        """
        self.assert_is_pointer()
        if apply_mask and self.is_need_block_mask().value:
            mask = self.get_blocked_masks()
        else:
            mask = None
        pointers = self.get_blocked_ptrs()
        if is_gluon():
            return gl.load(pointers, mask, other)
        else:
            return tl.load(pointers, mask, other)

    @triton_jit
    def masked_gather(
        self,
        inds,
        axis: tl.constexpr,
        apply_mask: tl.constexpr = True,
        other=None,
        add_offset_to_inds: tl.constexpr = True,
    ):
        """Load current block immediately. mask is applied by default.
        Usually used in triton kernels without loop.

        Don't use this function in any loop, use iterator in io.py instead.
        """
        self.assert_is_pointer()
        if apply_mask and self.is_need_block_mask(axis).value:
            mask = self.get_blocked_masks(axis)
        else:
            mask = None
        pointers = self.get_blocked_ptrs(
            gather_inds=inds, gather_axis=axis, add_offset_to_inds=add_offset_to_inds
        )
        if is_gluon():
            return gl.load(pointers, mask, other)
        else:
            return tl.load(pointers, mask, other)

    @triton_jit
    def masked_store(
        self, value, apply_mask: tl.constexpr = True, use_i64: tl.constexpr = False
    ):
        """Store current block immediately. mask is applied by default.
        Usually used in triton kernels without loop.

        Don't use this function in any loop, use iterator in io.py instead.
        """
        self.assert_is_pointer()
        if apply_mask and self.is_need_block_mask().value:
            mask = self.get_blocked_masks()
        else:
            mask = None
        pointers = self.get_blocked_ptrs(use_i64=use_i64)
        if is_gluon():
            gl.store(pointers, value, mask)
        else:
            tl.store(pointers, value, mask)


@aggregate(kw_only=True)
class BlockedTensorDescWithOffset(BlockedTensorDesc):
    named_offsets: NamedOffsets

    @triton_jit
    def get_offseted_ptr(
        self,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        self.assert_is_pointer()
        self.assert_is_valid()
        offsets_cw = self.named_offsets.offsets_cw

        return self.mgr.get_offseted_ptr(
            self.name,
            self.named_offsets.offset_names,
            offsets_cw,
            cast_offset_to_64bit=cast_offset_to_64bit,
        )

    @triton_jit
    def get_offseted_ptr_desc(
        self,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        """replace pointer with offseted pointer and clear offsets (set to 0) in desc.
        return new desc.
        WARNING: don't use this inside any loop.
        """
        self.assert_is_pointer()
        self.assert_is_valid()
        offsets_cw = self.named_offsets.offsets_cw
        if is_gluon():
            return aggregate_replace_gluon(
                self,
                ptr=self.mgr.get_offseted_ptr(
                    self.name,
                    self.named_offsets.offset_names,
                    offsets_cw,
                    cast_offset_to_64bit=cast_offset_to_64bit,
                ),
                named_offsets=self.named_offsets.get_cleared_named_offsets(),
            )
        else:
            return aggregate_replace_triton(
                self,
                ptr=self.mgr.get_offseted_ptr(
                    self.name,
                    self.named_offsets.offset_names,
                    offsets_cw,
                    cast_offset_to_64bit=cast_offset_to_64bit,
                ),
                named_offsets=self.named_offsets.get_cleared_named_offsets(),
            )

    @triton_jit
    def get_cur_offset_cw_by_block_idx(self, block_idx: tl.constexpr):
        return self.named_offsets.offsets_cw[block_idx]

    @tl.core.builtin
    def offset(self, _semantic=None, **kwargs):
        shape, alias = sym.parse_shape_sym(tl.core._unwrap_if_constexpr(self.shape_sym))
        cur_names = self.named_offsets.offset_names
        cur_names = tl.core._unwrap_if_constexpr(cur_names)
        global_to_alias = {s: a for a, s in zip(alias, shape)}
        cur_names_alias = [global_to_alias[n] for n in cur_names]
        for k in kwargs:
            assert k in cur_names or k in cur_names_alias, (
                f"offset name {k} not found in current named offsets {cur_names}/{cur_names_alias}"
            )
        values = [self.named_offsets.offsets_cw[i] for i in range(len(cur_names))]
        for k, v in kwargs.items():
            if k in cur_names:
                origin_idx = cur_names.index(k)
            else:
                origin_idx = cur_names_alias.index(k)
            v2 = values[origin_idx]
            v2_is_c = tl.core._unwrap_if_constexpr(v2.is_constexpr)
            if isinstance(v, (tl.constexpr, str, int, float, bool)) and v2_is_c:
                if isinstance(v, tl.constexpr):
                    v = v.value
                v2_value = v2.value
                if isinstance(v2_value, tl.constexpr):
                    v2_value = v2_value.value
                values[origin_idx] = TritonConstexprField(v + v2.value)
            else:
                if isinstance(v, tl.constexpr):
                    v = v.value
                v2_value = v2.value
                if isinstance(v2_value, tl.constexpr):
                    v2_value = v2_value.value
                values[origin_idx] = TritonField(_semantic.add(v, v2_value, True))
        named_offs = NamedOffsets(
            tl.tuple(values),
            self.named_offsets.offset_names,
        )
        return dataclasses.replace(
            self,
            named_offsets=named_offs,
        )

    @triton_jit
    def _increment_offset_dim(self, block_idx: tl.constexpr, value_cw):
        tl.static_assert(
            not self.named_offsets.offsets_cw[block_idx].is_constexpr,
            "you can't increment constexpr offset, convert "
            "it to tensor before entering any loop first.",
        )
        res = [
            dispatch_value(
                self.named_offsets.offsets_cw[i].value
                + (value_cw.value if i == block_idx else 0)
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        return res

    @triton_jit
    def _increment_offset_dim_nocheck(self, block_idx: tl.constexpr, value_cw):
        res = [
            dispatch_value(
                self.named_offsets.offsets_cw[i].value
                + (value_cw.value if i == block_idx else 0)
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        return res

    @triton_jit
    def make_offset_dim_mutable(self, dim_name: tl.constexpr):
        """Call this when you want to directly increment offset in a loop."""
        # TODO let dim_name support multiple dims like "B,H"
        dim_idx: tl.constexpr = self._get_dim_by_block_dim_name(dim_name).value

        res = [
            TritonField(get_scalar_tensor(self.named_offsets.offsets_cw[i].value))
            if i == dim_idx and self.named_offsets.offsets_cw[i].is_constexpr
            else self.named_offsets.offsets_cw[i]
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        return self.replace_offset(res)

    @triton_jit
    def get_blocked_offset_by_idx(
        self,
        idx: tl.constexpr,
        expand_dims: tl.constexpr = False,
        out_of_range: tl.constexpr = 0,
        use_i64: tl.constexpr = False,
    ):
        # triton don't support string constexpr in argument, so we have to use int.
        # out_of_range: 0("none") | 1("zero") | 2("circular")
        block_size: tl.constexpr = self.block_shape[idx]
        if is_gluon():
            res_layout: tl.constexpr = sym.get_sliced_layout(
                self.layout, len(self.block_shape), idx
            )
            res = (
                gl.arange(0, block_size, layout=res_layout)
                + self.get_cur_offset_cw_by_block_idx(idx).value
            )
        else:
            res = (
                tl.arange(0, block_size)
                + self.get_cur_offset_cw_by_block_idx(idx).value
            )
        if use_i64:
            res = res.to(tl.int64)
        if out_of_range == 0:
            res_oor = res
        elif out_of_range == 1:
            boundry = self.get_dim_size_by_block_dim(idx)
            res_oor = gl.where(res < boundry.value, res, 0)
        else:
            boundry = self.get_dim_size_by_block_dim(idx)
            res_oor = res % boundry.value
        if not expand_dims:
            return res_oor
        else:
            axes: tl.constexpr = sym.get_sliced_axes(
                len(self.block_shape), idx, descending=False
            )
            for i in tl.static_range(len(axes)):
                res_oor = res_oor.expand_dims(axes[i])
            return res_oor

    @triton_jit
    def increment_fixed_block(self, dim_name: tl.constexpr, num_block: tl.constexpr):
        dim_idx: tl.constexpr = self._get_dim_by_block_dim_name(dim_name).value
        new_offset_tuple = self._increment_offset_dim(
            dim_idx, TritonConstexprField(num_block * self.block_shape[dim_idx])
        )
        return self.replace_offset(new_offset_tuple)

    @triton_jit
    def replace_offset(self, new_offset_tuple):
        gl.static_assert(
            len(new_offset_tuple) == len(self.block_shape),
            "New offset tuple length must match block shape length.",
        )
        if is_gluon():
            return aggregate_replace_gluon(
                self,
                named_offsets=NamedOffsets(
                    new_offset_tuple, self.named_offsets.offset_names
                ),
            )
        else:
            return aggregate_replace_triton(
                self,
                named_offsets=NamedOffsets(
                    new_offset_tuple, self.named_offsets.offset_names
                ),
            )

    @triton_jit
    def replace_block_offset(self, new_block_offset_tuple):
        gl.static_assert(
            len(new_block_offset_tuple) == len(self.block_shape),
            "New offset tuple length must match block shape length.",
        )
        new_offset_tuple = [
            TritonField(new_block_offset_tuple[i] * self.block_shape[i].value)
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        if is_gluon():
            return aggregate_replace_gluon(
                self,
                named_offsets=NamedOffsets(
                    new_offset_tuple, self.named_offsets.offset_names
                ),
            )
        else:
            return aggregate_replace_triton(
                self,
                named_offsets=NamedOffsets(
                    new_offset_tuple, self.named_offsets.offset_names
                ),
            )

    @triton_jit
    def gather(self, offsets, add_offset_to_inds: tl.constexpr = True):
        tl.static_assert(
            len(offsets) == 2 and len(self.block_shape) == 2,
            "currently only support 2D gather to make api compatible with TMA gather.",
        )
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        self.assert_is_pointer()
        # find gather axis
        is_blocked_tensors = [
            TritonConstexprField(True)
            if (
                isinstance(offsets_cw_arg[i].value, tl.tensor)
                and offsets_cw_arg[i].value.numel > 1
            )
            else TritonConstexprField(False)
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        true_inds: tl.constexpr = sym.get_true_inds_of_bool_tuple_cw(
            is_blocked_tensors, -1
        )
        false_inds: tl.constexpr = sym.get_false_inds_of_bool_tuple_cw(
            is_blocked_tensors, -1
        )
        tl.static_assert(len(true_inds) == 1, "only support gather on one blocked dim")
        new_offset_tuple = self._increment_offset_dim_nocheck(
            false_inds[0], offsets_cw_arg[false_inds[0]]
        )
        return self.replace_offset(new_offset_tuple).masked_gather(
            offsets_cw_arg[true_inds[0]].value,
            axis=true_inds[0],
            apply_mask=True,
            add_offset_to_inds=add_offset_to_inds,
        )


@triton_jit
def _cast_to_i32_if_needed(value_cw):
    if value_cw.is_constexpr:
        return value_cw
    else:
        value = value_cw.value
        if value.dtype == tl.int64:
            return TritonField(value.astype(tl.int32))
        else:
            return TritonField(value)


@triton_jit
def _cast_to_i64_if_needed(value_cw):
    if value_cw.is_constexpr:
        return value_cw
    else:
        value = value_cw.value
        if value.dtype == tl.int64:
            return TritonField(value.astype(tl.int64))
        else:
            return TritonField(value)


@aggregate(kw_only=True)
class BlockedTensorDescTMABase(BlockedTensorDescWithOffset):
    non_block_named_offsets: NamedOffsets

    @triton_jit
    def get_all_offsets_cw_for_tma(self, block_offsets_cw):
        tl.static_assert(
            len(block_offsets_cw) == len(self.block_shape),
            "block offsets length must match block shape length.",
        )
        block_sym_global: tl.constexpr = sym.local_sym_to_global(
            self.shape_sym, self.block_shape_sym
        )
        block_names: tl.constexpr = sym.get_shape_names_from_sym(block_sym_global)
        overall_offsets = merge_two_tuple(
            self.non_block_named_offsets.offsets_cw, block_offsets_cw
        )
        overall_offset_names: tl.constexpr = sym.merge_two_name_list(
            self.non_block_named_offsets.offset_names, block_names
        )
        sym_axes: tl.constexpr = sym.get_sym_axes_in_name_tuple(
            overall_offset_names, self.shape_sym
        )
        # tl.static_print("sym_axes", block_offsets_cw, overall_offset_names, self.shape_sym, sym_axes, [0, 1])
        offset_tuple_cw = [
            overall_offsets[sym_axes[i]]
            if sym_axes[i] >= 0
            else TritonConstexprField(0)
            for i in tl.tuple(sym.tuple_range(len(sym_axes)))
        ]
        return offset_tuple_cw


@aggregate(kw_only=True)
class BlockedTensorDescTMATriton(BlockedTensorDescTMABase):
    @triton_jit
    def tma_load(self, offsets):
        self.assert_is_tma_desc()
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        offsets_cw = [
            dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(offsets_cw)
        res = self.ptr.load(
            [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ]
        )
        res = res.reshape(self.block_shape)
        return res

    @triton_jit
    def tma_store(self, offsets, value):
        value = value.reshape(self.ptr.block_shape)
        self.assert_is_tma_desc()
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        offsets_cw = [
            dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(offsets_cw)
        self.ptr.store(
            [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ],
            value,
        )

    @triton_jit
    def tma_atomic_add(self, offsets, value):
        value = value.reshape(self.ptr.block_shape)
        self.assert_is_tma_desc()
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        offsets_cw = [
            dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(offsets_cw)
        self.ptr.atomic_add(
            [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ],
            value,
        )

    @triton_jit
    def tma_gather(self, offsets, add_offset_to_inds: tl.constexpr = True):
        self.assert_is_tma_desc()
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        offsets_cw = [
            offsets_cw_arg[i]
            if (
                isinstance(offsets_cw_arg[i].value, tl.tensor)
                and offsets_cw_arg[i].value.numel > 1
                and not add_offset_to_inds
            )
            else dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(offsets_cw)
        value = self.ptr.gather(
            *[
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ]
        )
        # value = value.reshape(self.ptr.block_shape)
        return value

    @triton_jit
    def gather(self, offsets, add_offset_to_inds: tl.constexpr = True):
        return self.tma_gather(offsets, add_offset_to_inds)

    @triton_jit
    def tma_scatter(self, offsets, value, add_offset_to_inds: tl.constexpr = True):
        value = value.reshape(self.ptr.block_shape)
        self.assert_is_tma_desc()
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        offsets_cw = [
            offsets_cw_arg[i]
            if (
                isinstance(offsets_cw_arg[i].value, tl.tensor)
                and offsets_cw_arg[i].value.numel > 1
                and not add_offset_to_inds
            )
            else dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(offsets_cw)
        self.ptr.scatter(
            [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ],
            value,
        )
