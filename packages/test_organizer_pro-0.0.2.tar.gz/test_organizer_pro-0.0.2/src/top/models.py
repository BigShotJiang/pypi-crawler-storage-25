from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SpanResult:
    """Result of mutation testing for a specific column span within a line."""

    col_start: int
    col_end: int
    caught: bool
    description: str = ""
    mutated_line: str = ""

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "col_start": self.col_start,
            "col_end": self.col_end,
            "caught": self.caught,
            "description": self.description,
        }
        if self.mutated_line:
            result["mutated_line"] = self.mutated_line
        return result


@dataclass
class LineCoverage:
    """Coverage data for a single file: which lines are covered and which are asserted."""

    covered: set[int] = field(default_factory=set)
    asserted: set[int] = field(default_factory=set)
    partially_asserted: dict[int, list[SpanResult]] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "covered": sorted(self.covered),
            "asserted": sorted(self.asserted),
        }
        if self.partially_asserted:
            result["partially_asserted"] = {
                str(line): [s.to_dict() for s in spans] for line, spans in sorted(self.partially_asserted.items())
            }
        return result


@dataclass
class TestResult:
    """Full analysis result for a single test."""

    __test__ = False  # prevent pytest from collecting this dataclass

    test_id: str
    files: dict[str, LineCoverage] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {self.test_id: {filepath: lc.to_dict() for filepath, lc in self.files.items()}}


@dataclass
class AnalysisResult:
    """Complete analysis output for all tests."""

    results: list[TestResult] = field(default_factory=list)
    baselines: dict[str, set[int]] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for r in self.results:
            out.update(r.to_dict())
        return out


@dataclass
class MutationResult:
    """Result of mutating a single line and running a test."""

    file: str
    line: int
    caught: bool  # True = test failed (line is asserted)
