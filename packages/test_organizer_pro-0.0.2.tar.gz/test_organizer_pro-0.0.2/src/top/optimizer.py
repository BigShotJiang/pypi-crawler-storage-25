from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class OptimizeResult:
    """Result of test redundancy analysis."""

    keepers: list[str]
    redundant: dict[str, list[str]]  # redundant test → list of keepers that cover it

    def to_dict(self) -> dict[str, Any]:
        return {
            "keepers": self.keepers,
            "redundant": self.redundant,
        }


Line = tuple[str, int]  # (filepath, line_number)


def find_redundant_tests(analysis: dict[str, Any]) -> OptimizeResult:
    """Find redundant tests using greedy minimum set cover.

    A test is redundant if every line it asserts is also asserted by at least
    one keeper test. Uses three phases: index+deduplicate, essential tests,
    greedy cover.
    """
    # Phase 0 — Build index
    test_lines: dict[str, set[Line]] = {}
    line_tests: dict[Line, set[str]] = {}

    for test_id, files in analysis.items():
        lines: set[Line] = set()
        for filepath, file_data in files.items():
            for line_num in file_data.get("asserted", []):
                lines.add((filepath, line_num))
        test_lines[test_id] = lines
        for line in lines:
            line_tests.setdefault(line, set()).add(test_id)

    all_tests = set(test_lines)

    # Tests with no asserted lines are immediately redundant
    empty_tests = {t for t, lines in test_lines.items() if not lines}

    # Line signature deduplication: group lines by their test-set signature
    sig_groups: dict[frozenset[str], list[Line]] = {}
    for line, tests in line_tests.items():
        sig = frozenset(tests)
        sig_groups.setdefault(sig, []).append(line)

    # Phase 1 — Essential tests (sole asserter of at least one line group)
    keepers: set[str] = set()
    covered_sigs: set[frozenset[str]] = set()

    for sig in sig_groups:
        if len(sig) == 1:
            keepers.update(sig)
            covered_sigs.add(sig)

    # Mark all sigs covered by essential tests
    for sig in list(sig_groups):
        if sig & keepers:
            covered_sigs.add(sig)

    uncovered_sigs = {sig: len(lines) for sig, lines in sig_groups.items() if sig not in covered_sigs}

    # Phase 2 — Greedy cover
    candidates = all_tests - keepers - empty_tests
    while uncovered_sigs:
        best_test = max(
            sorted(candidates),
            key=lambda t: sum(w for sig, w in uncovered_sigs.items() if t in sig),
        )
        keepers.add(best_test)
        candidates.discard(best_test)
        uncovered_sigs = {sig: w for sig, w in uncovered_sigs.items() if best_test not in sig}

    # Build redundant mapping: for each redundant test, which keepers cover its lines
    redundant: dict[str, list[str]] = {}
    for test in sorted(all_tests - keepers):
        covering_keepers: set[str] = set()
        for line in test_lines[test]:
            for keeper in keepers:
                if line in test_lines[keeper]:
                    covering_keepers.add(keeper)
        redundant[test] = sorted(covering_keepers)

    return OptimizeResult(
        keepers=sorted(keepers),
        redundant=redundant,
    )


def skip_redundant_tests(project_path: str, result: OptimizeResult) -> list[str]:
    """Add skip decorators to redundant test functions.

    Uses @unittest.skip for tests inside classes in files that import unittest,
    @pytest.mark.skip for everything else. Returns list of modified file paths.
    """
    # Group by file to handle multiple tests per file (insert in reverse order)
    by_file: dict[str, list[tuple[str, str | None, list[str]]]] = {}
    for test_id, covered_by in result.redundant.items():
        parts = test_id.split("::")
        file_path = parts[0]
        func_name = parts[-1]
        class_name = parts[1] if len(parts) == 3 else None
        by_file.setdefault(file_path, []).append((func_name, class_name, covered_by))

    modified: list[str] = []
    for file_path, tests in sorted(by_file.items()):
        abs_path = Path(project_path) / file_path
        if not abs_path.is_file():
            continue

        source = abs_path.read_text()
        tree = ast.parse(source)
        uses_unittest = _has_import(tree, "unittest")

        # Collect insertions: (line_index, decorator_line, import_module)
        insertions: list[tuple[int, str, str]] = []
        for func_name, class_name, covered_by in tests:
            node = _find_func_node(tree, func_name, class_name)
            if node is None or _already_skipped(node):
                continue

            insert_at = (node.decorator_list[0].lineno if node.decorator_list else node.lineno) - 1
            indent = _get_indent(source.splitlines()[node.lineno - 1])
            reason = f"Redundant: covered by {', '.join(covered_by)}"

            if uses_unittest and class_name is not None:
                decorator = f'{indent}@unittest.skip("{reason}")\n'
                import_mod = "unittest"
            else:
                decorator = f'{indent}@pytest.mark.skip(reason="{reason}")\n'
                import_mod = "pytest"

            insertions.append((insert_at, decorator, import_mod))

        if not insertions:
            continue

        lines = source.splitlines(True)

        # Insert in reverse line order to preserve indices
        insertions.sort(key=lambda x: x[0], reverse=True)
        needed_imports: set[str] = set()
        for insert_at, decorator, import_mod in insertions:
            lines.insert(insert_at, decorator)
            needed_imports.add(import_mod)

        # Add missing imports at top
        for mod in sorted(needed_imports):
            if not _has_import(tree, mod):
                lines.insert(0, f"import {mod}\n")

        abs_path.write_text("".join(lines))
        modified.append(file_path)

    return sorted(modified)


def _find_func_node(
    tree: ast.Module, func_name: str, class_name: str | None
) -> ast.FunctionDef | ast.AsyncFunctionDef | None:
    """Find a test function AST node by name and optional class."""
    if class_name:
        for node in tree.body:
            if isinstance(node, ast.ClassDef) and node.name == class_name:
                for item in node.body:
                    if isinstance(item, ast.FunctionDef | ast.AsyncFunctionDef) and item.name == func_name:
                        return item
    else:
        for node in tree.body:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef) and node.name == func_name:
                return node
    return None


def _already_skipped(node: ast.FunctionDef | ast.AsyncFunctionDef) -> bool:
    """Check if a function already has a skip decorator."""
    for dec in node.decorator_list:
        target = dec.func if isinstance(dec, ast.Call) else dec
        if isinstance(target, ast.Attribute) and target.attr == "skip":
            return True
    return False


def _has_import(tree: ast.Module, module: str) -> bool:
    """Check if a module is imported at the top level."""
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == module:
                    return True
        if isinstance(node, ast.ImportFrom) and node.module == module:
            return True
    return False


def _get_indent(line: str) -> str:
    """Extract leading whitespace from a line."""
    return line[: len(line) - len(line.lstrip())]
