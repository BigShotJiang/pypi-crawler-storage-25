from __future__ import annotations

import json
from pathlib import Path

import click

from top.analyzer import analyze
from top.optimizer import find_redundant_tests, skip_redundant_tests

DEFAULT_OUTPUT = ".top/analysis.json"


@click.group()
def main() -> None:
    """TOP - Test Organizer Pro: find redundant pytest tests."""


@main.command()
@click.argument("project_path", type=click.Path(exists=True))
@click.option(
    "--source",
    "-s",
    multiple=True,
    help="Source directories to measure coverage for (can be repeated).",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    default=DEFAULT_OUTPUT,
    help=f"Output file path relative to project. Defaults to {DEFAULT_OUTPUT}.",
)
@click.option(
    "--stdout",
    is_flag=True,
    default=False,
    help="Print JSON to stdout instead of writing to a file.",
)
@click.option(
    "--include-tests",
    is_flag=True,
    default=False,
    help="Include test files in coverage/assertion output. Off by default.",
)
@click.option(
    "--html",
    is_flag=True,
    default=False,
    help="Generate an HTML report in .top/report/.",
)
def analyze_cmd(
    project_path: str,
    source: tuple[str, ...],
    output: str,
    stdout: bool,
    include_tests: bool,
    html: bool,
) -> None:
    """Analyze a pytest project to find which lines each test actually asserts."""
    source_dirs = list(source) if source else None

    result = analyze(project_path, source_dirs, include_tests=include_tests)
    data = json.dumps(result.to_dict(), indent=2)

    if stdout:
        click.echo(data)
    else:
        resolved = Path(project_path) / output
        resolved.parent.mkdir(parents=True, exist_ok=True)
        resolved.write_text(data)
        click.echo(f"Results written to {resolved}", err=True)

    if html:
        from top.report import generate_report

        report_dir = Path(project_path) / ".top" / "report"
        generate_report(result, project_path, report_dir)
        click.echo(f"HTML report written to {report_dir}", err=True)


@main.command()
@click.argument("project_path", type=click.Path(exists=True))
@click.option(
    "--input",
    "-i",
    "input_path",
    type=click.Path(),
    default=DEFAULT_OUTPUT,
    help=f"Analysis JSON file path relative to project. Defaults to {DEFAULT_OUTPUT}.",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    default=None,
    help="Write JSON report to this path.",
)
@click.option(
    "--skip",
    is_flag=True,
    default=False,
    help="Add skip decorators to redundant test functions.",
)
def optimize(project_path: str, input_path: str, output: str | None, skip: bool) -> None:
    """Find redundant tests that can be removed without losing assertion coverage."""
    resolved_input = Path(project_path) / input_path
    if not resolved_input.is_file():
        raise click.ClickException(f"Analysis file not found: {resolved_input}")

    analysis = json.loads(resolved_input.read_text())
    result = find_redundant_tests(analysis)

    click.echo(f"Keepers: {len(result.keepers)} tests", err=True)
    click.echo(f"Redundant: {len(result.redundant)} tests", err=True)

    if result.redundant:
        click.echo("", err=True)
        for test_id, covered_by in result.redundant.items():
            click.echo(f"  {test_id}", err=True)
            click.echo(f"    covered by: {', '.join(covered_by)}", err=True)

    if skip and result.redundant:
        modified = skip_redundant_tests(project_path, result)
        click.echo(f"\nSkip decorators added to {len(modified)} files:", err=True)
        for f in modified:
            click.echo(f"  {f}", err=True)

    if output:
        resolved_output = Path(project_path) / output
        resolved_output.parent.mkdir(parents=True, exist_ok=True)
        resolved_output.write_text(json.dumps(result.to_dict(), indent=2))
        click.echo(f"\nReport written to {resolved_output}", err=True)
