from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path


def run_test_with_coverage(
    project_path: str,
    test_id: str,
    source_dirs: list[str] | None = None,
) -> dict[str, set[int]]:
    """Run a single test with coverage and return {filepath: {line_numbers}}."""
    with tempfile.TemporaryDirectory() as tmpdir:
        cov_data = Path(tmpdir) / "coverage.json"

        cmd = [
            sys.executable,
            "-m",
            "coverage",
            "run",
            "--branch",
        ]
        if source_dirs:
            # Resolve source dirs to absolute paths so they work regardless of cwd
            abs_sources = [str(Path(s).resolve()) if not Path(s).is_absolute() else s for s in source_dirs]
            cmd.extend(["--source", ",".join(abs_sources)])

        cmd.extend(
            [
                "-m",
                "pytest",
                test_id,
                "-x",
                "-q",
                "--no-header",
                "--tb=no",
                "-p",
                "no:cov",
                "-o",
                "addopts=",
                "--rootdir",
                ".",
            ]
        )

        subprocess.run(
            cmd,
            cwd=project_path,
            capture_output=True,
            text=True,
            env=_coverage_env(tmpdir),
        )

        # Export coverage data as JSON
        subprocess.run(
            [
                sys.executable,
                "-m",
                "coverage",
                "json",
                "-o",
                str(cov_data),
            ],
            cwd=project_path,
            capture_output=True,
            text=True,
            env=_coverage_env(tmpdir),
        )

        if not cov_data.exists():
            return {}

        return _parse_coverage_json(cov_data, project_path)


def run_baseline_for_test_file(
    project_path: str,
    test_file: str,
    source_dirs: list[str] | None = None,
) -> dict[str, set[int]]:
    """Compute baseline coverage for a test file by replicating its imports in a noop test.

    This captures import-time line execution (module-level code, function defs, etc.)
    that would be covered by any test in this file regardless of what the test does.
    """
    abs_test = Path(project_path) / test_file
    import_lines = _extract_imports(abs_test)

    noop_source = import_lines + "\ndef test_noop():\n    pass\n"
    # Place noop test in the same directory as the original test file
    # so that __file__-relative paths (like sys.path manipulation) resolve correctly
    test_dir = (Path(project_path) / test_file).parent
    noop_test = test_dir / "_top_noop_test.py"
    noop_rel = str(noop_test.relative_to(Path(project_path)))
    try:
        noop_test.write_text(noop_source)
        return run_test_with_coverage(
            project_path,
            noop_rel,
            source_dirs=source_dirs,
        )
    finally:
        noop_test.unlink(missing_ok=True)


def subtract_baseline(
    coverage: dict[str, set[int]],
    baseline: dict[str, set[int]],
) -> dict[str, set[int]]:
    """Remove baseline lines from coverage, returning only net-new lines."""
    result: dict[str, set[int]] = {}
    for filepath, lines in coverage.items():
        baseline_lines = baseline.get(filepath, set())
        net = lines - baseline_lines
        if net:
            result[filepath] = net
    return result


def run_test_quick(project_path: str, test_id: str) -> bool:
    """Run a single test without coverage. Returns True if the test passes."""
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            test_id,
            "-x",
            "-q",
            "--no-header",
            "--tb=no",
            "-p",
            "no:cov",
            "-o",
            "addopts=",
            "--rootdir",
            ".",
        ],
        cwd=project_path,
        capture_output=True,
        text=True,
        env=_base_env(),
    )
    return result.returncode == 0


def _extract_imports(test_file: Path) -> str:
    """Extract import statements and sys.path manipulation from a test file."""
    import ast as ast_mod

    source = test_file.read_text()
    try:
        tree = ast_mod.parse(source)
    except SyntaxError:
        return ""

    lines: list[str] = []
    source_lines = source.splitlines()
    for node in ast_mod.iter_child_nodes(tree):
        if isinstance(node, ast_mod.Import | ast_mod.ImportFrom):
            # Grab the original source lines for the import
            start = node.lineno - 1
            end = node.end_lineno or node.lineno
            lines.extend(source_lines[start:end])
        elif isinstance(node, ast_mod.Expr) and isinstance(node.value, ast_mod.Call):
            # Capture sys.path manipulation like sys.path.insert(...)
            start = node.lineno - 1
            end = node.end_lineno or node.lineno
            lines.extend(source_lines[start:end])

    return "\n".join(lines) + "\n" if lines else ""


def _base_env() -> dict[str, str]:
    """Build base env dict for all subprocesses.

    Disables bytecode caching so mutated source files are never masked
    by stale .pyc files whose mtime+size happen to match.
    """
    import os

    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


def _coverage_env(data_dir: str) -> dict[str, str]:
    """Build env dict that points coverage at our temp directory."""
    env = _base_env()
    env["COVERAGE_FILE"] = str(Path(data_dir) / ".coverage")
    return env


def _parse_coverage_json(json_path: Path, project_path: str) -> dict[str, set[int]]:
    """Parse coverage.json and return {relative_filepath: {line_numbers}}."""
    data = json.loads(json_path.read_text())
    result: dict[str, set[int]] = {}
    project = Path(project_path).resolve()

    for filepath, file_data in data.get("files", {}).items():
        executed = file_data.get("executed_lines", [])
        if not executed:
            continue
        # Paths in coverage JSON are relative to the subprocess cwd (project_path)
        abs_filepath = (Path(project_path) / filepath).resolve()
        try:
            rel = str(abs_filepath.relative_to(project))
        except ValueError:
            rel = filepath
        result[rel] = set(executed)

    return result
