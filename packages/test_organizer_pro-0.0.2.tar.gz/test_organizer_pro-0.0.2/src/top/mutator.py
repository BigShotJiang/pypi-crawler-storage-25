from __future__ import annotations

import ast
import copy
from pathlib import Path

# Operator swap tables
COMPARE_SWAPS: dict[type, type] = {
    ast.Eq: ast.NotEq,
    ast.NotEq: ast.Eq,
    ast.Lt: ast.GtE,
    ast.LtE: ast.Gt,
    ast.Gt: ast.LtE,
    ast.GtE: ast.Lt,
    ast.Is: ast.IsNot,
    ast.IsNot: ast.Is,
    ast.In: ast.NotIn,
    ast.NotIn: ast.In,
}

BINOP_SWAPS: dict[type, type] = {
    ast.Add: ast.Sub,
    ast.Sub: ast.Add,
    ast.Mult: ast.FloorDiv,
    ast.FloorDiv: ast.Mult,
}

BOOLOP_SWAPS: dict[type, type] = {
    ast.And: ast.Or,
    ast.Or: ast.And,
}

# Human-readable operator names for mutation descriptions
_OP_NAMES: dict[type, str] = {
    ast.Eq: "==",
    ast.NotEq: "!=",
    ast.Lt: "<",
    ast.LtE: "<=",
    ast.Gt: ">",
    ast.GtE: ">=",
    ast.Is: "is",
    ast.IsNot: "is not",
    ast.In: "in",
    ast.NotIn: "not in",
    ast.Add: "+",
    ast.Sub: "-",
    ast.Mult: "*",
    ast.FloorDiv: "//",
    ast.And: "and",
    ast.Or: "or",
}


class LineMutator:
    """Generate mutations for a specific line in a Python source file."""

    def __init__(self, filepath: str, line: int):
        self.filepath = filepath
        self.line = line
        self.source = Path(filepath).read_text()
        self.tree = ast.parse(self.source)

    def generate_mutations(self) -> list[tuple[str, int, int, str]]:
        """Return a list of (mutated_source, col_start, col_end, description) for the target line.

        Each mutation is a complete file source with one change on the target line,
        along with the column span of the AST node that was mutated and a
        human-readable description of the change.
        """
        mutations: list[tuple[str, int, int, str]] = []

        for node in ast.walk(self.tree):
            if not hasattr(node, "lineno") or node.lineno != self.line:
                continue
            mutations.extend(self._mutate_node(node))

        return mutations

    def _node_span(self, node: ast.AST) -> tuple[int, int]:
        """Return (col_start, col_end) for a node."""
        return (getattr(node, "col_offset", 0), getattr(node, "end_col_offset", 0))

    def _mutate_node(self, node: ast.AST) -> list[tuple[str, int, int, str]]:
        mutations: list[tuple[str, int, int, str]] = []
        span = self._node_span(node)

        # Comparison operator swap
        if isinstance(node, ast.Compare):
            for i, op in enumerate(node.ops):
                swap = COMPARE_SWAPS.get(type(op))
                if swap:
                    mutated = self._apply_mutation(node, "ops", i, swap())
                    if mutated:
                        desc = f"replace `{_OP_NAMES[type(op)]}` with `{_OP_NAMES[swap]}`"
                        mutations.append((mutated, *span, desc))
                    if mutations:
                        break  # one mutation per node is enough

        # Binary operator swap
        elif isinstance(node, ast.BinOp):
            swap = BINOP_SWAPS.get(type(node.op))
            if swap:
                mutated = self._apply_mutation(node, "op", None, swap())
                if mutated:
                    desc = f"replace `{_OP_NAMES[type(node.op)]}` with `{_OP_NAMES[swap]}`"
                    mutations.append((mutated, *span, desc))

        # Boolean operator swap
        elif isinstance(node, ast.BoolOp):
            swap = BOOLOP_SWAPS.get(type(node.op))
            if swap:
                mutated = self._apply_mutation(node, "op", None, swap())
                if mutated:
                    desc = f"replace `{_OP_NAMES[type(node.op)]}` with `{_OP_NAMES[swap]}`"
                    mutations.append((mutated, *span, desc))

        # Negate UnaryOp (not x -> x, -x -> x)
        elif isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            mutated = self._replace_node(node, node.operand)
            if mutated:
                mutations.append((mutated, *span, "remove `not`"))

        # Return value mutation
        elif isinstance(node, ast.Return) and node.value is not None:
            mutated = self._mutate_return(node)
            if mutated:
                mutations.append((mutated, *span, self._return_description(node)))

        # Constant mutation (True/False, numbers)
        elif isinstance(node, ast.Constant):
            mutated = self._mutate_constant(node)
            if mutated:
                mutations.append((mutated, *span, self._constant_description(node)))

        return mutations

    def _return_description(self, node: ast.Return) -> str:
        """Describe a return value mutation."""
        assert node.value is not None
        if isinstance(node.value, ast.Constant):
            return self._constant_description(node.value)
        return "replace return value with `None`"

    @staticmethod
    def _constant_description(node: ast.Constant) -> str:
        """Describe a constant mutation."""
        val = node.value
        if val is True:
            return "replace `True` with `False`"
        if val is False:
            return "replace `False` with `True`"
        if isinstance(val, int | float) and val == 0:
            return "replace `0` with `1`"
        if isinstance(val, int | float):
            return f"replace `{val}` with `0`"
        if isinstance(val, str) and val == "":
            return "replace `''` with `'mutated'`"
        if isinstance(val, str):
            return f"replace `'{val}'` with `''`"
        return "mutate constant"

    def _mutate_return(self, node: ast.Return) -> str | None:
        """Mutate a return statement's value."""
        assert node.value is not None
        if isinstance(node.value, ast.Constant):
            return self._mutate_constant(node.value)
        # For non-constant returns, replace with None
        new_node = copy.deepcopy(node)
        new_node.value = ast.Constant(value=None)
        ast.fix_missing_locations(new_node)
        return self._replace_node(node, new_node)

    def _mutate_constant(self, node: ast.Constant) -> str | None:
        """Mutate a constant value."""
        val = node.value
        new_val: bool | int | float | str
        if val is True:
            new_val = False
        elif val is False:
            new_val = True
        elif isinstance(val, int | float) and val == 0:
            new_val = 1
        elif isinstance(val, int | float):
            new_val = 0
        elif isinstance(val, str) and val == "":
            new_val = "mutated"
        elif isinstance(val, str):
            new_val = ""
        else:
            return None

        new_node = ast.Constant(value=new_val)
        ast.copy_location(new_node, node)
        return self._replace_node(node, new_node)

    def _apply_mutation(self, node: ast.AST, attr: str, index: int | None, new_value: ast.AST) -> str | None:
        """Apply a mutation to a node attribute and return the mutated source."""
        tree = copy.deepcopy(self.tree)
        target = self._find_matching_node(tree, node)
        if target is None:
            return None

        if index is not None:
            getattr(target, attr)[index] = new_value
        else:
            setattr(target, attr, new_value)

        ast.fix_missing_locations(tree)
        try:
            return ast.unparse(tree)
        except Exception:
            return None

    def _replace_node(self, old: ast.AST, new: ast.AST) -> str | None:
        """Replace a node in the tree and return mutated source."""
        tree = copy.deepcopy(self.tree)
        replacer = _NodeReplacer(old, new)
        new_tree = replacer.visit(tree)
        ast.fix_missing_locations(new_tree)
        try:
            return ast.unparse(new_tree)
        except Exception:
            return None

    def _find_matching_node(self, tree: ast.AST, original: ast.AST) -> ast.AST | None:
        """Find a node in a deep-copied tree that matches the original by position and type."""
        for node in ast.walk(tree):
            if (
                type(node) is type(original)
                and getattr(node, "lineno", None) == getattr(original, "lineno", None)
                and getattr(node, "col_offset", None) == getattr(original, "col_offset", None)
            ):
                return node
        return None


class _NodeReplacer(ast.NodeTransformer):
    """Replace a specific AST node identified by position."""

    def __init__(self, old: ast.AST, new: ast.AST):
        self.old_type = type(old)
        self.old_line = getattr(old, "lineno", None)
        self.old_col = getattr(old, "col_offset", None)
        self.new = new
        self.replaced = False

    def visit(self, node: ast.AST) -> ast.AST:
        if (
            not self.replaced
            and type(node) is self.old_type
            and getattr(node, "lineno", None) == self.old_line
            and getattr(node, "col_offset", None) == self.old_col
        ):
            self.replaced = True
            return self.new
        result = super().visit(node)
        assert isinstance(result, ast.AST)
        return result


def mutate_file_line(filepath: str, line: int) -> list[tuple[str, int, int, str]]:
    """High-level API: generate all mutations for a specific line in a file.

    Returns a list of (mutated_source, col_start, col_end, description) tuples.
    """
    try:
        mutator = LineMutator(filepath, line)
        return mutator.generate_mutations()
    except SyntaxError:
        return []
