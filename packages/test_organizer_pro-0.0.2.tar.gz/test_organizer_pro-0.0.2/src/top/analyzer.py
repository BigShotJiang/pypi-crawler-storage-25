from __future__ import annotations

import sys
from pathlib import Path

from top.discovery import discover_tests
from top.models import AnalysisResult, LineCoverage, SpanResult, TestResult
from top.mutator import mutate_file_line
from top.runner import (
    run_baseline_for_test_file,
    run_test_quick,
    run_test_with_coverage,
    subtract_baseline,
)


def analyze(
    project_path: str,
    source_dirs: list[str] | None = None,
    *,
    include_tests: bool = False,
) -> AnalysisResult:
    """Run the full analysis pipeline on a project.

    1. Discover all tests
    2. Compute baseline (import-time) coverage
    3. For each test: collect coverage, subtract baseline
    4. For each net-new line: mutate and check if test catches it
    5. Return structured results
    """
    project = str(Path(project_path).resolve())

    _log(f"Discovering tests in {project}...")
    test_ids = discover_tests(project)
    _log(f"Found {len(test_ids)} tests")

    # Group tests by file for shared baseline computation
    tests_by_file: dict[str, list[str]] = {}
    for test_id in test_ids:
        test_file = test_id.split("::")[0]
        tests_by_file.setdefault(test_file, []).append(test_id)

    # Compute per-file baselines (one baseline per test file, shared by all tests in it)
    _log("Computing baselines per test file...")
    baselines: dict[str, dict[str, set[int]]] = {}
    for test_file in tests_by_file:
        _log(f"  Baseline for {test_file}...")
        baselines[test_file] = run_baseline_for_test_file(project, test_file, source_dirs)
        total = sum(len(lines) for lines in baselines[test_file].values())
        _log(f"    {total} import-time lines")

    merged_baselines: dict[str, set[int]] = {}
    for file_baselines in baselines.values():
        for filepath, lines in file_baselines.items():
            merged_baselines.setdefault(filepath, set()).update(lines)

    results = AnalysisResult(baselines=merged_baselines)
    test_num = 0

    for test_file, file_test_ids in tests_by_file.items():
        baseline = baselines[test_file]
        for test_id in file_test_ids:
            test_num += 1
            _log(f"[{test_num}/{len(test_ids)}] Analyzing {test_id}...")

            test_result = analyze_single_test(project, test_id, baseline, source_dirs, include_tests=include_tests)
            results.results.append(test_result)

    return results


def analyze_single_test(
    project_path: str,
    test_id: str,
    baseline: dict[str, set[int]],
    source_dirs: list[str] | None = None,
    *,
    include_tests: bool = False,
) -> TestResult:
    """Analyze a single test: coverage, baseline subtraction, mutation."""
    # Step 1: Run test with coverage
    raw_coverage = run_test_with_coverage(project_path, test_id, source_dirs)

    # Step 2: Subtract baseline
    net_coverage = subtract_baseline(raw_coverage, baseline)

    test_result = TestResult(test_id=test_id)

    if not net_coverage:
        return test_result

    # Step 3: Filter out the test file itself unless --include-tests
    test_file = test_id.split("::")[0]
    if not include_tests:
        net_coverage = {f: lines for f, lines in net_coverage.items() if f != test_file}

    # Step 4: For each net-new line, mutate and check
    for filepath, lines in net_coverage.items():
        abs_path = str(Path(project_path) / filepath)
        lc = LineCoverage(covered=set(lines))

        for line in sorted(lines):
            span_results = check_line_mutations(project_path, abs_path, line, test_id)
            if not span_results:
                continue
            all_caught = all(sr.caught for sr in span_results)
            any_caught = any(sr.caught for sr in span_results)
            if all_caught:
                lc.asserted.add(line)
            elif any_caught:
                lc.partially_asserted[line] = span_results

        test_result.files[filepath] = lc

    return test_result


def check_line_mutations(
    project_path: str,
    filepath: str,
    line: int,
    test_id: str,
) -> list[SpanResult]:
    """Mutate a line and check which spans are caught.

    Returns a list of SpanResult, one per unique span, indicating whether
    any mutation targeting that span caused the test to fail.
    Returns an empty list if no mutations are possible.
    """
    mutations = mutate_file_line(filepath, line)
    if not mutations:
        return []

    original = Path(filepath).read_text()
    original_unparsed = _unparse(original)

    # Group mutations by span, track if any mutation per span is caught
    span_caught: dict[tuple[int, int], bool] = {}
    span_desc: dict[tuple[int, int], str] = {}
    span_mutated_line: dict[tuple[int, int], str] = {}
    for mutated_source, col_start, col_end, description in mutations:
        span = (col_start, col_end)
        if span not in span_caught:
            span_caught[span] = False
            span_desc[span] = description
            span_mutated_line[span] = _find_mutated_line(original_unparsed, mutated_source)
        if mutated_source == original:
            continue
        if span_caught[span]:
            continue  # Already caught for this span, skip
        try:
            Path(filepath).write_text(mutated_source)
            passed = run_test_quick(project_path, test_id)
            if not passed:
                span_caught[span] = True
        finally:
            Path(filepath).write_text(original)

    return [
        SpanResult(
            col_start=s[0],
            col_end=s[1],
            caught=c,
            description=span_desc[s],
            mutated_line=span_mutated_line[s],
        )
        for s, c in sorted(span_caught.items())
    ]


def _unparse(source: str) -> list[str]:
    """Parse and unparse source to get a normalized baseline for diffing."""
    import ast

    return ast.unparse(ast.parse(source)).splitlines()


def _find_mutated_line(original_lines: list[str], mutated_source: str) -> str:
    """Find the changed line by diffing original and mutated unparsed sources."""
    mutated_lines = mutated_source.splitlines()
    for orig, mut in zip(original_lines, mutated_lines, strict=False):
        if orig != mut:
            return mut.strip()
    return ""


def _log(msg: str) -> None:
    print(msg, file=sys.stderr)
