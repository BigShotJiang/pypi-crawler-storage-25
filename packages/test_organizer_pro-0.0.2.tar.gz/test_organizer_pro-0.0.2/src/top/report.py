from __future__ import annotations

import html
from dataclasses import dataclass, field
from pathlib import Path

from top.models import AnalysisResult, LineCoverage, SpanResult


@dataclass
class LineInfo:
    """Per-line aggregated annotation data."""

    is_baseline: bool = False
    covered_by: list[str] = field(default_factory=list)
    asserted_by: list[str] = field(default_factory=list)
    partially_asserted_by: list[str] = field(default_factory=list)
    uncaught_mutations: list[str] = field(default_factory=list)
    spans: list[SpanResult] = field(default_factory=list)
    partial_spans_by_test: dict[str, list[SpanResult]] = field(default_factory=dict)


@dataclass
class FileReport:
    """All data needed to render one source file's report page."""

    filepath: str
    source_lines: list[str]
    lines: dict[int, LineInfo] = field(default_factory=dict)

    @property
    def total_lines(self) -> int:
        return len(self.source_lines)

    @property
    def baseline_count(self) -> int:
        return sum(1 for li in self.lines.values() if li.is_baseline)

    @property
    def covered_count(self) -> int:
        return sum(1 for li in self.lines.values() if li.covered_by)

    @property
    def asserted_count(self) -> int:
        return sum(1 for li in self.lines.values() if li.asserted_by)

    @property
    def partially_asserted_count(self) -> int:
        return sum(1 for li in self.lines.values() if li.partially_asserted_by)


def build_file_reports(
    result: AnalysisResult,
    project_path: str,
) -> list[FileReport]:
    """Invert test-centric results into file-centric reports."""
    all_files: set[str] = set()
    for tr in result.results:
        all_files.update(tr.files.keys())
    all_files.update(result.baselines.keys())

    reports: list[FileReport] = []
    for filepath in sorted(all_files):
        abs_path = Path(project_path) / filepath
        if not abs_path.is_file():
            continue
        source = abs_path.read_text()
        source_lines = source.splitlines()

        lines_info: dict[int, LineInfo] = {}
        baseline_lines = result.baselines.get(filepath, set())

        for line_num in range(1, len(source_lines) + 1):
            covered_by: list[str] = []
            asserted_by: list[str] = []
            partially_asserted_by: list[str] = []
            uncaught_descs: set[str] = set()
            # Merge spans across tests: a span is caught if ANY test caught it
            merged_spans: dict[tuple[int, int], SpanResult] = {}
            per_test_spans: dict[str, list[SpanResult]] = {}
            for tr in result.results:
                lc = tr.files.get(filepath, LineCoverage())
                if line_num in lc.covered:
                    covered_by.append(tr.test_id)
                if line_num in lc.asserted:
                    asserted_by.append(tr.test_id)
                if line_num in lc.partially_asserted:
                    partially_asserted_by.append(tr.test_id)
                    per_test_spans[tr.test_id] = lc.partially_asserted[line_num]
                    for s in lc.partially_asserted[line_num]:
                        key = (s.col_start, s.col_end)
                        if key in merged_spans:
                            existing = merged_spans[key]
                            if s.caught and not existing.caught:
                                merged_spans[key] = s
                        else:
                            merged_spans[key] = s
                        if not s.caught and s.description:
                            uncaught_descs.add(s.description)

            is_baseline = line_num in baseline_lines
            merged_span_list = [merged_spans[k] for k in sorted(merged_spans)]

            if is_baseline or covered_by or asserted_by or partially_asserted_by:
                lines_info[line_num] = LineInfo(
                    is_baseline=is_baseline,
                    covered_by=sorted(covered_by),
                    asserted_by=sorted(asserted_by),
                    partially_asserted_by=sorted(partially_asserted_by),
                    uncaught_mutations=sorted(uncaught_descs),
                    spans=merged_span_list,
                    partial_spans_by_test=per_test_spans,
                )

        reports.append(
            FileReport(
                filepath=filepath,
                source_lines=source_lines,
                lines=lines_info,
            )
        )

    return reports


def generate_report(
    result: AnalysisResult,
    project_path: str,
    report_dir: Path,
) -> None:
    """Generate the full HTML report."""
    report_dir.mkdir(parents=True, exist_ok=True)
    file_reports = build_file_reports(result, project_path)
    _write_index_page(report_dir, file_reports)
    for fr in file_reports:
        _write_file_page(report_dir, fr)


def _write_index_page(report_dir: Path, file_reports: list[FileReport]) -> None:
    rows = ""
    for fr in file_reports:
        total = fr.total_lines
        if total == 0:
            bar_html = '<div class="bar"></div>'
        else:
            pct_asserted = fr.asserted_count / total * 100
            pct_partial = fr.partially_asserted_count / total * 100
            pct_covered = (fr.covered_count - fr.asserted_count - fr.partially_asserted_count) / total * 100
            pct_baseline = fr.baseline_count / total * 100
            bar_html = (
                '<div class="bar">'
                f'<div class="bar-asserted" style="width:{pct_asserted:.1f}%"></div>'
                f'<div class="bar-partial" style="width:{pct_partial:.1f}%"></div>'
                f'<div class="bar-covered" style="width:{pct_covered:.1f}%"></div>'
                f'<div class="bar-baseline" style="width:{pct_baseline:.1f}%"></div>'
                "</div>"
            )

        link = f"{fr.filepath}.html"
        rows += (
            "<tr>"
            f'<td><a href="{html.escape(link)}">{html.escape(fr.filepath)}</a></td>'
            f"<td>{total}</td>"
            f"<td>{fr.baseline_count}</td>"
            f"<td>{fr.covered_count}</td>"
            f"<td>{fr.partially_asserted_count}</td>"
            f"<td>{fr.asserted_count}</td>"
            f"<td>{bar_html}</td>"
            "</tr>\n"
        )

    page = _page_template(
        "TOP Analysis Report",
        f"""\
<h1>TOP Analysis Report</h1>
<table>
<thead><tr>
<th>File</th><th>Lines</th><th>Baseline</th>
<th>Covered</th><th>Partial</th><th>Asserted</th><th>Coverage</th>
</tr></thead>
<tbody>
{rows}</tbody>
</table>""",
    )
    (report_dir / "index.html").write_text(page)


def _write_file_page(report_dir: Path, fr: FileReport) -> None:
    depth = fr.filepath.count("/")
    back_link = "../" * depth + "index.html"

    rows = ""
    for line_num, line_text in enumerate(fr.source_lines, start=1):
        li = fr.lines.get(line_num)
        all_spans_caught = li.spans and all(s.caught for s in li.spans) if li else False
        if li and (li.asserted_by or all_spans_caught) and li.partially_asserted_by:
            # Some tests fully assert, others partially — line is asserted overall
            cls = "line-asserted"
            cov_count = str(len(li.covered_by))
            ast_count = str(len(li.asserted_by) + len(li.partially_asserted_by))
        elif li and li.asserted_by:
            cls = "line-asserted"
            cov_count = str(len(li.covered_by))
            ast_count = str(len(li.asserted_by))
        elif li and li.partially_asserted_by:
            cls = "line-partial"
            cov_count = str(len(li.covered_by))
            ast_count = str(len(li.partially_asserted_by))
        elif li and li.covered_by:
            cls = "line-covered"
            cov_count = str(len(li.covered_by))
            ast_count = ""
        elif li and li.is_baseline:
            cls = "line-baseline"
            cov_count = ""
            ast_count = ""
        else:
            cls = ""
            cov_count = ""
            ast_count = ""

        if li and li.spans and not li.asserted_by:
            code_html = _render_annotated_source(line_text, li.spans)
        else:
            code_html = html.escape(line_text)

        cov_cell = _count_cell("cov", line_num, cov_count)
        # When both asserted and partially asserted, toggle both detail rows
        if li and li.asserted_by and li.partially_asserted_by:
            toggle_js = f"toggle('ast-{line_num}');toggle('past-{line_num}')"
            ast_cell = f'<td class="ast-count clickable" onclick="{toggle_js}">{ast_count}</td>'
        else:
            ast_cell = _count_cell("ast", line_num, ast_count)
        rows += (
            f'<tr class="{cls}" id="L{line_num}">'
            f'<td class="ln">{line_num}</td>'
            f"{cov_cell}{ast_cell}"
            f'<td class="code"><pre>{code_html}</pre></td>'
            "</tr>\n"
        )
        if li and li.covered_by:
            rows += _detail_row(f"cov-{line_num}", "Covered by:", li.covered_by)
        if li and li.asserted_by:
            rows += _detail_row(f"ast-{line_num}", "Asserted by:", li.asserted_by)
        if li and li.partially_asserted_by:
            partial_id = f"past-{line_num}" if li.asserted_by else f"ast-{line_num}"
            rows += _partial_detail_row(partial_id, li.partial_spans_by_test)

    page = _page_template(
        f"{fr.filepath} — TOP Report",
        f"""\
<div class="header">
<a href="{html.escape(back_link)}">&larr; Back to index</a>
<h1>{html.escape(fr.filepath)}</h1>
</div>
<div class="legend">
<span class="legend-asserted">Asserted</span>
<span class="legend-partial">Partially asserted</span>
<span class="legend-covered">Covered only</span>
<span class="legend-baseline">Baseline (import-time)</span>
</div>
<table class="source">
<thead><tr><th class="ln"></th><th class="cov-count">cov</th><th class="ast-count">ast</th><th></th></tr></thead>
{rows}</table>""",
    )

    out_path = report_dir / f"{fr.filepath}.html"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(page)


def _render_annotated_source(line_text: str, spans: list[SpanResult]) -> str:
    """Render source line with caught/uncaught spans highlighted.

    Characters inside a caught span get class="span-caught",
    characters inside an uncaught span get class="span-uncaught",
    characters outside any span are plain escaped text.
    """
    # Build a per-character class map
    char_class: list[str] = [""] * len(line_text)
    for s in spans:
        cls = "span-caught" if s.caught else "span-uncaught"
        end = min(s.col_end, len(line_text))
        start = min(s.col_start, len(line_text))
        for i in range(start, end):
            # uncaught takes priority over caught for display
            if char_class[i] == "" or cls == "span-uncaught":
                char_class[i] = cls

    # Group consecutive characters by class and build HTML
    parts: list[str] = []
    i = 0
    while i < len(line_text):
        cls = char_class[i]
        j = i
        while j < len(line_text) and char_class[j] == cls:
            j += 1
        chunk = html.escape(line_text[i:j])
        if cls:
            tooltip = "Mutation caught" if cls == "span-caught" else "Mutation NOT caught"
            parts.append(f'<span class="{cls}" title="{tooltip}">{chunk}</span>')
        else:
            parts.append(chunk)
        i = j

    return "".join(parts)


def _count_cell(kind: str, line_num: int, count: str) -> str:
    """Render a clickable cov/ast count cell."""
    if not count:
        return f'<td class="{kind}-count"></td>'
    detail_id = f"{kind}-{line_num}"
    return f'<td class="{kind}-count clickable" onclick="toggle(\'{detail_id}\')">{count}</td>'


def _detail_row(detail_id: str, label: str, tests: list[str]) -> str:
    """Render a hidden detail row listing test names."""
    test_list = "".join(f"<li>{html.escape(t)}</li>" for t in tests)
    return (
        f'<tr class="detail-row" id="{detail_id}">'
        f'<td></td><td colspan="3">'
        f'<span class="detail-label">{html.escape(label)}</span>'
        f'<ul class="test-list">{test_list}</ul>'
        f"</td></tr>\n"
    )


def _partial_detail_row(detail_id: str, spans_by_test: dict[str, list[SpanResult]]) -> str:
    """Render a hidden detail row for partial assertions with per-test mutation details."""
    test_items = ""
    for test_id in sorted(spans_by_test):
        spans = spans_by_test[test_id]
        caught_items = ""
        uncaught_items = ""
        for s in spans:
            desc = html.escape(s.description) if s.description else "mutation"
            if s.caught:
                caught_items += f'<li><span class="mutation-desc mutation-caught">{desc}</span></li>'
            else:
                mutated = html.escape(s.mutated_line) if s.mutated_line else ""
                line_html = f'<pre class="mutation-line">{mutated}</pre>' if mutated else ""
                uncaught_items += f'<li><span class="mutation-desc">{desc}:</span>{line_html}</li>'
        mutations_html = ""
        if caught_items:
            mutations_html += f'<ul class="mutation-list">{caught_items}</ul>'
        if uncaught_items:
            mutations_html += f'<ul class="mutation-list">{uncaught_items}</ul>'
        test_items += f"<li>{html.escape(test_id)}{mutations_html}</li>"
    content = f'<span class="detail-label">Partially asserted by:</span><ul class="test-list">{test_items}</ul>'
    return f'<tr class="detail-row" id="{detail_id}"><td></td><td colspan="3">{content}</td></tr>\n'


def _page_template(title: str, body: str) -> str:
    return f"""\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{html.escape(title)}</title>
<style>
{_css()}
</style>
</head>
<body>
{body}
{_js()}
</body>
</html>
"""


def _css() -> str:
    return """\
body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 2em; color: #1f2937; }
h1 { font-size: 1.4em; margin: 0.5em 0; }
table { border-collapse: collapse; width: 100%; }
thead th { text-align: left; padding: 6px 10px; border-bottom: 2px solid #d1d5db; font-size: 0.85em; color: #6b7280; }
tbody td { padding: 4px 10px; border-bottom: 1px solid #f3f4f6; }
tbody tr:hover { background: #f9fafb; }
a { color: #2563eb; text-decoration: none; }
a:hover { text-decoration: underline; }
.bar { display: flex; height: 10px; background: #e5e7eb; border-radius: 3px; overflow: hidden; min-width: 120px; }
.bar-asserted { background: #22c55e; }
.bar-partial { background: #f97316; }
.bar-covered { background: #eab308; }
.bar-baseline { background: #9ca3af; }
.source { table-layout: fixed; }
.source td { padding: 0 4px; vertical-align: top; border-bottom: none; }
.source tr:hover { background: #f0f9ff; }
.ln { color: #9ca3af; text-align: right; padding-right: 12px !important;
  user-select: none; width: 4em; white-space: nowrap; }
.cov-count, .ast-count { color: #6b7280; text-align: center; width: 3em; font-size: 0.85em; cursor: default; }
.source thead th { border-bottom: 1px solid #d1d5db; font-size: 0.75em; color: #9ca3af; padding: 2px 4px; }
.code pre { margin: 0; font-family: "SF Mono", "Cascadia Code", "Consolas", monospace;
  font-size: 0.85em; white-space: pre; overflow-x: auto; }
.line-asserted { background: #dcfce7; }
.line-partial { background: #fed7aa; }
.line-covered { background: #fef9c3; }
.line-baseline { background: #f3f4f6; }
.line-asserted:hover { background: #bbf7d0; }
.line-partial:hover { background: #fdba74; }
.line-covered:hover { background: #fef08a; }
.line-baseline:hover { background: #e5e7eb; }
.header { margin-bottom: 1em; }
.header a { font-size: 0.9em; }
.legend { margin-bottom: 1em; }
.legend span { display: inline-block; padding: 2px 10px; margin-right: 8px; font-size: 0.8em; border-radius: 3px; }
.legend-asserted { background: #dcfce7; }
.legend-partial { background: #fed7aa; }
.legend-covered { background: #fef9c3; }
.legend-baseline { background: #f3f4f6; }
.detail-row { display: none; }
.detail-row.open { display: table-row; }
.detail-row td { padding: 0 0 0 8em; }
.test-list { margin: 2px 0; padding-left: 1.5em; font-size: 0.8em; color: #374151; }
.test-list li { padding: 1px 0; }
.clickable { cursor: pointer; text-decoration: underline; }
.clickable:hover { color: #2563eb; }
.detail-label { font-size: 0.75em; font-weight: 600; color: #6b7280;
  text-transform: uppercase; letter-spacing: 0.05em; }
.span-caught { background: #bbf7d0; border-radius: 2px; }
.span-uncaught { background: #fecaca; border-radius: 2px; text-decoration: wavy underline #dc2626; }
.mutation-list { margin: 4px 0; padding-left: 1.5em; font-size: 0.8em; list-style: none; }
.mutation-list li { padding: 3px 0; }
.mutation-desc { color: #6b7280; font-size: 0.9em; }
.mutation-caught { color: #15803d; }
.mutation-line { display: inline; margin: 0 0 0 0.5em; padding: 1px 6px; background: #fef2f2;
  border: 1px solid #fecaca; border-radius: 3px; font-family: "SF Mono", "Cascadia Code", "Consolas", monospace;
  font-size: 0.95em; color: #991b1b; }
"""


def _js() -> str:
    return """\
<script>
function toggle(id) {
  var row = document.getElementById(id);
  if (row) row.classList.toggle('open');
}
</script>
"""
