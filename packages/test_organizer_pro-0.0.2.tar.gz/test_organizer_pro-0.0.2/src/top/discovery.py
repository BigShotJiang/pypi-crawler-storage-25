from __future__ import annotations

import subprocess
import sys


def discover_tests(project_path: str) -> list[str]:
    """Discover all test node IDs in the target project using pytest --collect-only."""
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "pytest",
            "--collect-only",
            "-q",
            "--no-header",
            "-p",
            "no:cov",
            "-o",
            "addopts=",
            "--rootdir",
            ".",
        ],
        cwd=project_path,
        capture_output=True,
        text=True,
    )
    if result.returncode not in (0, 5):  # 5 = no tests collected
        raise RuntimeError(f"pytest collection failed (exit {result.returncode}):\n{result.stderr}")

    test_ids = []
    for line in result.stdout.strip().splitlines():
        line = line.strip()
        # pytest -q outputs lines like "test_foo.py::test_bar" followed by a summary
        if "::" in line and not line.startswith(("=", "-", " ")):
            test_ids.append(line)
    return test_ids
