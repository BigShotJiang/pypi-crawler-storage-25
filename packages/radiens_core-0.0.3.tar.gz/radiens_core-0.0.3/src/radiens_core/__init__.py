"""Radiens Python client for neuroscience data acquisition and analysis."""

from importlib.metadata import version

__version__ = version("radiens-core")

from radiens_core.allego_client import AllegoClient
from radiens_core.curate_client import CurateClient
from radiens_core.models.common import ServiceEndpoint
from radiens_core.models.core_config import CableDelay, CoreConfig, SetCoreConfigRequest
from radiens_core.models.dataset import (
    BandParams,
    BulkSinkParams,
    BulkSourceParams,
    CARParams,
    DownsampleParams,
    FileInfo,
    HighLowPassParams,
    NotchParams,
    PairedRefParams,
    ProtocolSpec,
    SinkParams,
    SliceChannelsParams,
    SliceTimeParams,
    SourceParams,
    TransformEdge,
    TransformNode,
    TransformNodeType,
    VirtualRefParams,
)
from radiens_core.models.kpi import KpiMetric, KpiMetricId, KpiMetricsResult, KpiMode, KpiStatus
from radiens_core.models.spikes import ChannelSpikeData, NeuronInfo, NeuronSpikeData, NeuronsResult, SpikesSpec
from radiens_core.models.spikesorter import (
    DashElement,
    InputFeatureType,
    SpikeDetectParams,
    SpikeSorterClustererParams,
    SpikeSorterCommand,
    SpikeSorterDashboard,
    SpikeSorterDashboardGeneral,
    SpikeSorterFeatureParams,
    SpikeSorterLaunchParams,
    SpikeSorterLaunchResult,
    SpikeSorterState,
    SpikeSorterStateSystem,
    SpikeSorterSubCommand,
    SpikeSorterType,
)
from radiens_core.models.triggers import TriggerChannel
from radiens_core.videre_client import VidereClient

__all__ = [
    "AllegoClient",
    "BandParams",
    "BulkSinkParams",
    "BulkSourceParams",
    "CARParams",
    "CableDelay",
    "ChannelSpikeData",
    "CoreConfig",
    "CurateClient",
    "DashElement",
    "DownsampleParams",
    "FileInfo",
    "HighLowPassParams",
    "InputFeatureType",
    "KpiMetric",
    "KpiMetricId",
    "KpiMetricsResult",
    "KpiMode",
    "KpiStatus",
    "NeuronInfo",
    "NeuronSpikeData",
    "NeuronsResult",
    "NotchParams",
    "PairedRefParams",
    "ProtocolSpec",
    "ServiceEndpoint",
    "SetCoreConfigRequest",
    "SinkParams",
    "SliceChannelsParams",
    "SliceTimeParams",
    "SourceParams",
    "SpikeDetectParams",
    "SpikeSorterClustererParams",
    "SpikeSorterCommand",
    "SpikeSorterDashboard",
    "SpikeSorterDashboardGeneral",
    "SpikeSorterFeatureParams",
    "SpikeSorterLaunchParams",
    "SpikeSorterLaunchResult",
    "SpikeSorterState",
    "SpikeSorterStateSystem",
    "SpikeSorterSubCommand",
    "SpikeSorterType",
    "SpikesSpec",
    "TransformEdge",
    "TransformNode",
    "TransformNodeType",
    "TriggerChannel",
    "VidereClient",
    "VirtualRefParams",
    "__version__",
]
