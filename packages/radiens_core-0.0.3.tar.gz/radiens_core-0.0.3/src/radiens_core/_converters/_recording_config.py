"""Recording config converters — domain models <-> proto messages."""

from __future__ import annotations

from radiens_core._generated import allegoserver_pb2
from radiens_core.models.status import DataRecordingType, RecordingConfig

# --- DataRecordingType enum conversion ---

_DATA_RECORDING_TYPE_TO_PROTO: dict[DataRecordingType, allegoserver_pb2.DataRecordingType.ValueType] = {
    DataRecordingType.CONTINUOUS: allegoserver_pb2.continuous,
    DataRecordingType.SPIKES: allegoserver_pb2.spikes,
    DataRecordingType.CONTINUOUS_AND_SPIKES: allegoserver_pb2.continuousAndSpikes,
}

_DATA_RECORDING_TYPE_FROM_PROTO: dict[int, DataRecordingType] = {
    int(allegoserver_pb2.continuous): DataRecordingType.CONTINUOUS,
    int(allegoserver_pb2.spikes): DataRecordingType.SPIKES,
    int(allegoserver_pb2.continuousAndSpikes): DataRecordingType.CONTINUOUS_AND_SPIKES,
}


def data_recording_type_to_proto(drt: DataRecordingType) -> allegoserver_pb2.DataRecordingType.ValueType:
    """Convert domain DataRecordingType to proto DataRecordingType."""
    return _DATA_RECORDING_TYPE_TO_PROTO[drt]


def data_recording_type_from_proto(pb: int) -> DataRecordingType:
    """Convert proto DataRecordingType int to domain DataRecordingType."""
    return _DATA_RECORDING_TYPE_FROM_PROTO[pb]


def recording_config_to_proto(
    config: RecordingConfig,
) -> allegoserver_pb2.ConfigRecording:
    """Convert domain RecordingConfig to proto ConfigRecording."""
    return allegoserver_pb2.ConfigRecording(
        baseFileName=config.base_file_name,
        baseFilePath=config.base_file_path,
        dataSourceIdx=config.datasource_idx,
        timeStamp=config.time_stamp,
        splitFilesByPort=config.split_files_by_port,
        forceStartAtTStamp0=config.force_start_at_tstamp_0,
        recordingType=data_recording_type_to_proto(config.recording_type),
    )


def recording_config_from_proto(
    proto: allegoserver_pb2.ConfigRecording,
) -> RecordingConfig:
    """Convert proto ConfigRecording to domain RecordingConfig."""
    return RecordingConfig(
        base_file_name=proto.baseFileName,
        base_file_path=proto.baseFilePath,
        datasource_idx=proto.dataSourceIdx,
        time_stamp=proto.timeStamp,
        split_files_by_port=proto.splitFilesByPort,
        force_start_at_tstamp_0=proto.forceStartAtTStamp0,
        recording_type=data_recording_type_from_proto(proto.recordingType),
    )
