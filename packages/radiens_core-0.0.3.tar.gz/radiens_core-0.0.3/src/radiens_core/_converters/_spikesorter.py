"""Converters for spike sorter control and status messages."""

from __future__ import annotations

from typing import cast

from radiens_core._generated import common_pb2, spikesorter_pb2
from radiens_core.models.ports import Port
from radiens_core.models.spikesorter import (
    DashElement,
    InputFeatureType,
    SpikeDetectParams,
    SpikeSorterClustererParams,
    SpikeSorterCommand,
    SpikeSorterCriterionLevel,
    SpikeSorterDashboard,
    SpikeSorterDashboardGeneral,
    SpikeSorterDynamicConfig,
    SpikeSorterDynamicCriteria,
    SpikeSorterDynamicUpdatePeriod,
    SpikeSorterFeatureParams,
    SpikeSorterLaunchParams,
    SpikeSorterLaunchResult,
    SpikeSorterParamCommand,
    SpikeSorterState,
    SpikeSorterStateSystem,
    SpikeSorterSubCommand,
    SpikeSorterType,
)


def spike_sorter_state_from_proto(proto: spikesorter_pb2.SpikeSorterState) -> SpikeSorterState:
    """Convert SpikeSorterState proto to domain model."""
    return SpikeSorterState(
        sys=SpikeSorterStateSystem(proto.sys),
        frac_complete=proto.fracComplete if proto.HasField("fracComplete") else 0.0,
        is_on=proto.isOn if proto.HasField("isOn") else False,
        msg=proto.msg if proto.HasField("msg") else "",
        error_msg=proto.errorMsg if proto.HasField("errorMsg") else "",
        warn_msg=proto.warnMsg if proto.HasField("warnMsg") else "",
    )


def spike_sorter_launch_params_to_proto(params: SpikeSorterLaunchParams) -> spikesorter_pb2.SpikeSorterLaunchRequest:
    """Convert SpikeSorterLaunchParams domain model to proto request."""
    proto = spikesorter_pb2.SpikeSorterLaunchRequest(
        discoverNoise=params.discover_noise,
        isAutoOn=params.is_auto_on,
        subCmd=cast("spikesorter_pb2.SpikeSorterSubCommand.ValueType", params.sub_cmd.value),
    )
    if params.dsource_id:
        proto.dsourceID = params.dsource_id
    if params.nbr_pattern is not None:
        proto.nbrPattern = params.nbr_pattern
    if params.sink_dsrc_id:
        proto.sinkDsrcID = params.sink_dsrc_id

    if params.clusterer_params:
        proto.clustererParams.CopyFrom(spike_sorter_clusterer_params_to_proto(params.clusterer_params))
    if params.feature_params:
        proto.featureParams.CopyFrom(spike_sorter_feature_params_to_proto(params.feature_params))

    return proto


def spike_sorter_clusterer_params_to_proto(
    params: SpikeSorterClustererParams,
) -> spikesorter_pb2.SpikeSorterClustererParamsRequest:
    """Convert SpikeSorterClustererParams domain model to proto request."""
    proto = spikesorter_pb2.SpikeSorterClustererParamsRequest(disabled=params.disabled)
    if params.pos_influence_frac is not None:
        proto.posInfluenceFrac = params.pos_influence_frac
    if params.wfm_shape_influence_frac is not None:
        proto.wfmShapeInfluenceFrac = params.wfm_shape_influence_frac
    if params.eps is not None:
        proto.eps = params.eps
    if params.min_pts is not None:
        proto.minPts = params.min_pts
    return proto


def spike_sorter_feature_params_to_proto(
    params: SpikeSorterFeatureParams,
) -> spikesorter_pb2.SpikeSorterFeatureParamsRequest:
    """Convert SpikeSorterFeatureParams domain model to proto request."""
    # Map InputFeatureType domain enum to FTR_TYPE_* proto enum values
    feature_type_map = {
        InputFeatureType.WFM: spikesorter_pb2.FTR_TYPE_WFM,
        InputFeatureType.SPD: spikesorter_pb2.FTR_TYPE_SPD,
        InputFeatureType.WFM_POS: spikesorter_pb2.FTR_TYPE_WFM_POS,
        InputFeatureType.SPD_POS: spikesorter_pb2.FTR_TYPE_SPD_POS,
    }

    proto = spikesorter_pb2.SpikeSorterFeatureParamsRequest(
        numFeatures=params.num_features,
        featureType=feature_type_map[params.feature_type],
    )
    if params.latent_dim is not None:
        proto.latentDim = params.latent_dim
    if params.resample_wfm_len is not None:
        proto.resampleWfmLen = params.resample_wfm_len
    return proto


def spike_sorter_launch_result_from_proto(proto: spikesorter_pb2.SpikeSorterLaunchReply) -> SpikeSorterLaunchResult:
    """Convert SpikeSorterLaunchReply proto to domain model."""
    return SpikeSorterLaunchResult(
        spike_sorter_id=proto.spikeSorterID,
        sorter_type=SpikeSorterType(proto.sorterType),
        msg=proto.msg if proto.HasField("msg") else "",
    )


def build_spike_sorter_command_proto(
    spike_sorter_id: str,
    cmd: SpikeSorterCommand,
    sub_cmd: SpikeSorterSubCommand = SpikeSorterSubCommand.NULL,
    clusterer_params: SpikeSorterClustererParams | None = None,
    feature_params: SpikeSorterFeatureParams | None = None,
) -> spikesorter_pb2.SpikeSorterCommandRequest:
    """Build a SpikeSorterCommandRequest proto."""
    proto = spikesorter_pb2.SpikeSorterCommandRequest(
        spikeSorterID=spike_sorter_id,
        cmd=cast("spikesorter_pb2.SpikeSorterCommand.ValueType", cmd.value),
        subCmd=cast("spikesorter_pb2.SpikeSorterSubCommand.ValueType", sub_cmd.value),
    )
    if clusterer_params:
        proto.clustererParams.CopyFrom(spike_sorter_clusterer_params_to_proto(clusterer_params))
    if feature_params:
        proto.featureParams.CopyFrom(spike_sorter_feature_params_to_proto(feature_params))
    return proto


def spike_sorter_dashboard_from_proto(proto: spikesorter_pb2.SpikeSorterDashboardReply) -> SpikeSorterDashboard:
    """Convert SpikeSorterDashboardReply proto to domain model."""
    general = None
    if proto.HasField("general"):
        g = proto.general
        general = SpikeSorterDashboardGeneral(
            state=spike_sorter_state_from_proto(g.state),
            sorter_type=SpikeSorterType(g.sorterType),
            sorter_id=g.sorterID,
            datasource_id=g.datasourceID,
            time_range=(g.timeRange[0], g.timeRange[1]) if len(g.timeRange) >= 2 else (0.0, 0.0),
            num_total_sites=g.numTotalSites,
            num_enabled_sites=g.numEnabledSites,
            num_active_sites=g.numActiveSites,
            num_neurons=g.numNeurons,
            probe_yield=g.probeYield,
            site_yield=g.siteYield,
            num_spikes_processed=g.numSpikesProcessed,
            num_spikes_labeled=g.numSpikesLabeled,
            sort_efficiency=g.sortEfficiency,
        )

    return SpikeSorterDashboard(
        enabled_ports=[Port(p) for p in proto.enabledPorts],
        general=general,
    )


def dash_element_to_proto(element: DashElement) -> spikesorter_pb2.DashElement.ValueType:
    """Convert DashElement enum to proto enum value."""
    return cast("spikesorter_pb2.DashElement.ValueType", element.value)


def spike_detect_params_from_proto(proto: common_pb2.SpikeSorterParamCommandRecord) -> SpikeDetectParams:
    """Convert SpikeSorterParamCommandRecord to SpikeDetectParams."""
    return SpikeDetectParams(
        is_enabled=proto.isEnabled if proto.HasField("isEnabled") else None,
        ntv_chan_idx=proto.ntvChanIdx if proto.HasField("ntvChanIdx") else None,
        thr=list(proto.thr) if proto.thr else None,
        thr_sd=list(proto.thrSd) if proto.thrSd else None,
        thr_wdw_pts=list(proto.thrWdwPts) if proto.thrWdwPts else None,
        thr_wdw=list(proto.thrWdw) if proto.thrWdw else None,
        shadow=proto.shadow if proto.HasField("shadow") else None,
        shadow_pts=proto.shadowPts if proto.HasField("shadowPts") else None,
        is_set_thr=list(proto.isSetThr) if proto.isSetThr else None,
        weak_thr=list(proto.weakThr) if proto.weakThr else None,
        weak_thr_sd=list(proto.weakThrSd) if proto.weakThrSd else None,
    )


def build_spike_sorter_set_params_proto(
    sorter_id: str,
    params: SpikeDetectParams,
    channels: list[int],
) -> common_pb2.SpikeSorterSetParamsRequest:
    """Convert SpikeDetectParams to a bulk SpikeSorterSetParamsRequest proto."""
    requests = []

    if params.thr is not None:
        req = common_pb2.SpikeSorterSetParamRequest(
            spikeSorterID=sorter_id,
            cmd=cast("common_pb2.SpikeSorterParamCommand.ValueType", SpikeSorterParamCommand.THR_LEVEL.value),
            regFloat64=params.thr,
            regBool=[True, True] if len(params.thr) >= 2 else [True],
            ntvChanIdx=channels,
        )
        requests.append(req)

    if params.thr_sd is not None:
        req = common_pb2.SpikeSorterSetParamRequest(
            spikeSorterID=sorter_id,
            cmd=cast("common_pb2.SpikeSorterParamCommand.ValueType", SpikeSorterParamCommand.THR_LEVEL_SD.value),
            regFloat64=params.thr_sd,
            regBool=[True, True] if len(params.thr_sd) >= 2 else [True],
            ntvChanIdx=channels,
        )
        requests.append(req)

    if params.thr_wdw is not None:
        req = common_pb2.SpikeSorterSetParamRequest(
            spikeSorterID=sorter_id,
            cmd=cast("common_pb2.SpikeSorterParamCommand.ValueType", SpikeSorterParamCommand.THR_WDW.value),
            regFloat64=params.thr_wdw,
            ntvChanIdx=channels,
        )
        requests.append(req)

    if params.shadow is not None:
        req = common_pb2.SpikeSorterSetParamRequest(
            spikeSorterID=sorter_id,
            cmd=cast("common_pb2.SpikeSorterParamCommand.ValueType", SpikeSorterParamCommand.SHADOW.value),
            regFloat64=[params.shadow],
            ntvChanIdx=channels,
        )
        requests.append(req)

    if params.weak_thr is not None:
        req = common_pb2.SpikeSorterSetParamRequest(
            spikeSorterID=sorter_id,
            cmd=cast("common_pb2.SpikeSorterParamCommand.ValueType", SpikeSorterParamCommand.WEAK_THR_LEVEL.value),
            regFloat64=params.weak_thr,
            regBool=[True, True] if len(params.weak_thr) >= 2 else [True],
            ntvChanIdx=channels,
        )
        requests.append(req)

    if params.weak_thr_sd is not None:
        req = common_pb2.SpikeSorterSetParamRequest(
            spikeSorterID=sorter_id,
            cmd=cast("common_pb2.SpikeSorterParamCommand.ValueType", SpikeSorterParamCommand.WEAK_THR_LEVEL_SD.value),
            regFloat64=params.weak_thr_sd,
            regBool=[True, True] if len(params.weak_thr_sd) >= 2 else [True],
            ntvChanIdx=channels,
        )
        requests.append(req)

    if params.is_set_thr is not None:
        # Activation request uses regBool to indicate WHICH polarities to update,
        # and regFloat64 to indicate ON (1.0) or OFF (0.0).
        req = common_pb2.SpikeSorterSetParamRequest(
            spikeSorterID=sorter_id,
            cmd=cast("common_pb2.SpikeSorterParamCommand.ValueType", SpikeSorterParamCommand.THR_ACTIVATE.value),
            regBool=[True, True] if len(params.is_set_thr) >= 2 else [True],
            regFloat64=[1.0 if b else 0.0 for b in params.is_set_thr],
            ntvChanIdx=channels,
        )
        requests.append(req)

    return common_pb2.SpikeSorterSetParamsRequest(params=requests)


def spike_sorter_dynamic_config_from_proto(proto: spikesorter_pb2.SpikeSorterDynamic) -> SpikeSorterDynamicConfig:
    """Convert SpikeSorterDynamic to SpikeSorterDynamicConfig."""
    criteria = None
    if proto.HasField("criteria"):
        c = proto.criteria
        criteria = SpikeSorterDynamicCriteria(
            detect=SpikeSorterCriterionLevel(c.detect) if c.HasField("detect") else None,
            train=SpikeSorterCriterionLevel(c.train) if c.HasField("train") else None,
            sort=SpikeSorterCriterionLevel(c.sort) if c.HasField("sort") else None,
        )

    update_period_sec = None
    if proto.HasField("updatePeriodSec"):
        u = proto.updatePeriodSec
        update_period_sec = SpikeSorterDynamicUpdatePeriod(
            detect=u.detect if u.HasField("detect") else None,
            train=u.train if u.HasField("train") else None,
            sort=u.sort if u.HasField("sort") else None,
        )

    return SpikeSorterDynamicConfig(
        is_enabled=proto.isEnabled if proto.HasField("isEnabled") else None,
        update_period_sec=update_period_sec,
        criteria=criteria,
    )


def build_spike_sorter_dynamic_proto(config: SpikeSorterDynamicConfig) -> spikesorter_pb2.SpikeSorterDynamic:
    """Convert SpikeSorterDynamicConfig to SpikeSorterDynamic proto."""
    proto = spikesorter_pb2.SpikeSorterDynamic()
    if config.is_enabled is not None:
        proto.isEnabled = config.is_enabled

    if config.criteria is not None:
        c = spikesorter_pb2.SpikeSorterDynamic.Criteria()
        if config.criteria.detect is not None:
            c.detect = cast("spikesorter_pb2.SpikeSorterCriterionLevel.ValueType", config.criteria.detect.value)
        if config.criteria.train is not None:
            c.train = cast("spikesorter_pb2.SpikeSorterCriterionLevel.ValueType", config.criteria.train.value)
        if config.criteria.sort is not None:
            c.sort = cast("spikesorter_pb2.SpikeSorterCriterionLevel.ValueType", config.criteria.sort.value)
        proto.criteria.CopyFrom(c)

    if config.update_period_sec is not None:
        u = spikesorter_pb2.SpikeSorterDynamic.UpdatePeriodSec()
        if config.update_period_sec.detect is not None:
            u.detect = config.update_period_sec.detect
        if config.update_period_sec.train is not None:
            u.train = config.update_period_sec.train
        if config.update_period_sec.sort is not None:
            u.sort = config.update_period_sec.sort
        proto.updatePeriodSec.CopyFrom(u)

    return proto
