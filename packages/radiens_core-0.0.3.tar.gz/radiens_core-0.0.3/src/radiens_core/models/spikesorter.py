"""Spike sorter control and status domain models."""

from __future__ import annotations

from enum import IntEnum

from pydantic import BaseModel, ConfigDict, Field

from radiens_core.models.ports import Port


class SpikeSorterType(IntEnum):
    """Supported spike sorter types."""

    NULL = 0
    VEX_STREAM = 1
    SPIKES_STREAM = 2
    VEX_FILE = 3
    SPIKES_FILE = 4


class SpikeSorterParamCommand(IntEnum):
    """Commands for updating individual spike sorter detection parameters."""

    THR_LEVEL = 1
    THR_LEVEL_SD = 4
    THR_WDW = 8
    WEAK_THR_LEVEL = 10
    WEAK_THR_LEVEL_SD = 13
    SHADOW = 17
    THR_ACTIVATE = 19
    WEAK_THR_ACTIVATE = 21


class SpikeSorterCriterionLevel(IntEnum):
    """Stringency levels for AI evaluation."""

    LEAST = 0
    LESS = 1
    BALANCED = 2
    MORE = 3
    MOST = 4


class SpikeDetectParams(BaseModel):
    """Detection parameters for a single recording channel.

    All fields are optional to allow for partial updates.

    Attributes:
        is_enabled: Whether detection is enabled on this channel.
        ntv_chan_idx: Native channel index (used in return structures, not set via bulk update).
        thr: Threshold values in microvolts ``[neg, pos]``.
        thr_sd: Threshold values in standard deviations ``[neg, pos]``.
        thr_wdw_pts: Threshold window in points ``[pre, post, total]``.
        thr_wdw: Threshold window in seconds ``[pre, post, total]``.
        shadow: Shadow period in seconds.
        shadow_pts: Shadow period in points.
        is_set_thr: Whether threshold is set ``[neg, pos]``.
        weak_thr: Weak threshold values in microvolts ``[neg, pos]``.
        weak_thr_sd: Weak threshold values in standard deviations ``[neg, pos]``.
    """

    model_config = ConfigDict(frozen=True)

    is_enabled: bool | None = None
    ntv_chan_idx: int | None = None
    thr: list[float] | None = None
    thr_sd: list[float] | None = None
    thr_wdw_pts: list[int] | None = None  # Read-only; populated by server, ignored by set_detect_params.
    thr_wdw: list[float] | None = None
    shadow: float | None = None
    shadow_pts: int | None = None  # Read-only; populated by server, ignored by set_detect_params.
    is_set_thr: list[bool] | None = None
    weak_thr: list[float] | None = None
    weak_thr_sd: list[float] | None = None


class SpikeSorterDynamicCriteria(BaseModel):
    """Criteria stringency levels for AI auto-updates."""

    model_config = ConfigDict(frozen=True)

    detect: SpikeSorterCriterionLevel | None = None
    train: SpikeSorterCriterionLevel | None = None
    sort: SpikeSorterCriterionLevel | None = None


class SpikeSorterDynamicUpdatePeriod(BaseModel):
    """Update periods in seconds for AI auto-updates."""

    model_config = ConfigDict(frozen=True)

    detect: float | None = None
    train: float | None = None
    sort: float | None = None


class SpikeSorterDynamicConfig(BaseModel):
    """Configuration for AI dynamic tracking auto-updates.

    Attributes:
        is_enabled: Whether dynamic AI tracking is enabled.
        update_period_sec: Schedule for dynamic updates.
        criteria: Stringency criteria for updates.
    """

    model_config = ConfigDict(frozen=True)

    is_enabled: bool | None = None
    update_period_sec: SpikeSorterDynamicUpdatePeriod | None = None
    criteria: SpikeSorterDynamicCriteria | None = None


class SpikeSorterCommand(IntEnum):
    """Commands for controlling an active spike sorter."""

    ON = 0
    OFF = 1
    CLEAR_SORT = 2
    REBASE = 4
    INIT = 5


class SpikeSorterSubCommand(IntEnum):
    """Sub-commands for spike sorter operations."""

    NULL = 0  # Full sorting with clustering
    DETECT_ONLY = 2  # Detect spikes without sorting/clustering


class SpikeSorterStateSystem(IntEnum):
    """Overall system state of a spike sorter."""

    ON = 0
    OFF = 1
    NOT_CONFIGURED = 2


class SpikeSorterState(BaseModel):
    """Current state and progress of a spike sorter.

    Attributes:
        sys: Overall system state (ON, OFF, NOT_CONFIGURED).
        frac_complete: Fraction of the current operation completed (0.0 to 1.0).
        is_on: Whether the sorter is currently active.
        msg: Status message from the server.
        error_msg: Error message if the sorter is in an error state.
        warn_msg: Warning message from the server.
    """

    model_config = ConfigDict(frozen=True)

    sys: SpikeSorterStateSystem
    frac_complete: float = 0.0
    is_on: bool = False
    msg: str = ""
    error_msg: str = ""
    warn_msg: str = ""


class InputFeatureType(IntEnum):
    """Feature types used for spike sorting."""

    WFM = 0
    SPD = 1
    WFM_POS = 2
    SPD_POS = 3


class SpikeSorterFeatureParams(BaseModel):
    """Parameters for feature extraction during spike sorting.

    Attributes:
        num_features: Number of features to extract.
        feature_type: Type of features to extract.
        latent_dim: Latent dimension for feature reduction.
        resample_wfm_len: Length to resample waveforms to.
    """

    model_config = ConfigDict(frozen=True)

    num_features: int
    feature_type: InputFeatureType = InputFeatureType.WFM
    latent_dim: int | None = None
    resample_wfm_len: int | None = None


class SpikeSorterClustererParams(BaseModel):
    """Parameters for the spike clustering algorithm.

    Attributes:
        pos_influence_frac: Influence of spike position on clustering.
        wfm_shape_influence_frac: Influence of waveform shape on clustering.
        eps: Epsilon parameter for DBSCAN-like clustering.
        min_pts: Minimum points for a cluster.
        disabled: Whether clustering is disabled.
    """

    model_config = ConfigDict(frozen=True)

    pos_influence_frac: float | None = None
    wfm_shape_influence_frac: float | None = None
    eps: float | None = None
    min_pts: int | None = None
    disabled: bool = False


class SpikeSorterLaunchParams(BaseModel):
    """Parameters for launching a new spike sorter.

    Attributes:
        dsource_id: ID of the data source to sort (required for file sorting).
        discover_noise: Whether to perform noise discovery.
        is_auto_on: Whether to automatically start sorting after launch.
        nbr_pattern: Neighbor pattern for multi-channel sorting.
        sink_dsrc_id: ID for the resultant .spikes file.
        sub_cmd: Sub-command for the sorting operation.
        clusterer_params: Optional clustering parameters.
        feature_params: Optional feature extraction parameters.
    """

    model_config = ConfigDict(frozen=True)

    dsource_id: str | None = None
    discover_noise: bool = True
    is_auto_on: bool = True
    nbr_pattern: int | None = None
    sink_dsrc_id: str | None = None
    sub_cmd: SpikeSorterSubCommand = SpikeSorterSubCommand.NULL
    clusterer_params: SpikeSorterClustererParams | None = None
    feature_params: SpikeSorterFeatureParams | None = None


class SpikeSorterLaunchResult(BaseModel):
    """Result of a spike sorter launch request.

    Attributes:
        spike_sorter_id: Unique ID of the launched sorter.
        sorter_type: Type of the launched sorter.
        msg: Status message from the server.
    """

    model_config = ConfigDict(frozen=True)

    spike_sorter_id: str
    sorter_type: SpikeSorterType
    msg: str = ""


class DashElement(IntEnum):
    """Elements available for the spike sorter dashboard."""

    ENABLED_PORTS = 1
    GENERAL = 2
    PORT_STATS = 3
    SITE_STATS = 4
    SITE_PANEL = 5
    NEURON_STATS = 6
    NEURON_PANEL = 7
    AI = 8


class SpikeSorterDashboardGeneral(BaseModel):
    """General summary metrics for the spike sorter dashboard."""

    model_config = ConfigDict(frozen=True)

    state: SpikeSorterState
    sorter_type: SpikeSorterType
    sorter_id: str
    datasource_id: str
    time_range: tuple[float, float]
    num_total_sites: int
    num_enabled_sites: int
    num_active_sites: int
    num_neurons: int
    probe_yield: float
    site_yield: float
    num_spikes_processed: int
    num_spikes_labeled: int
    sort_efficiency: float


class SpikeSorterDashboard(BaseModel):
    """Comprehensive spike sorter dashboard data.

    Attributes:
        enabled_ports: List of hardware ports with active sorting.
        general: General summary metrics.
    """

    model_config = ConfigDict(frozen=True)

    enabled_ports: list[Port] = Field(default_factory=list)
    general: SpikeSorterDashboardGeneral | None = None
