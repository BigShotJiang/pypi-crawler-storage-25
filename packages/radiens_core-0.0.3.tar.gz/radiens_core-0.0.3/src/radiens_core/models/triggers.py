"""Trigger control domain models and enums."""

from __future__ import annotations

from enum import IntEnum

from pydantic import BaseModel, ConfigDict

from radiens_core.models.ports import Port
from radiens_core.models.stim import StimKeypressIndex


class TriggerChannel(IntEnum):
    """Trigger channel identifier. Values match proto ``allego.TriggerChannel``."""

    T_DIN_0 = 0
    T_DIN_1 = 1
    T_DIN_2 = 2
    T_DIN_3 = 3
    T_DIN_4 = 4
    T_DIN_5 = 5
    T_DIN_6 = 6
    T_DIN_7 = 7
    T_DIN_8 = 8
    T_DIN_9 = 9
    T_DIN_10 = 10
    T_DIN_11 = 11
    T_DIN_12 = 12
    T_DIN_13 = 13
    T_DIN_14 = 14
    T_DIN_15 = 15
    T_DOUT_0 = 16
    T_DOUT_1 = 17
    T_DOUT_2 = 18
    T_DOUT_3 = 19
    T_DOUT_4 = 20
    T_DOUT_5 = 21
    T_DOUT_6 = 22
    T_DOUT_7 = 23
    T_DOUT_8 = 24
    T_DOUT_9 = 25
    T_DOUT_10 = 26
    T_DOUT_11 = 27
    T_DOUT_12 = 28
    T_DOUT_13 = 29
    T_DOUT_14 = 30
    T_DOUT_15 = 31
    T_NONE = 32


class SetTriggerStateRequest(BaseModel):
    """Request to set trigger channel state.

    Attributes:
        channel: Trigger channel identifier. References TriggerChannel.
        enabled: Whether the channel should be enabled.
        port: Hardware port identifier. References Port.
    """

    model_config = ConfigDict(frozen=True)

    channel: TriggerChannel
    enabled: bool
    port: Port


class TriggerState(BaseModel):
    """Current trigger channel configuration.

    Attributes:
        enabled_channels: List of currently enabled trigger channels.
        ports: List of ports with enabled triggers.
    """

    model_config = ConfigDict(frozen=True)

    enabled_channels: list[TriggerChannel]
    ports: list[Port]


class ManualStimTriggerRequest(BaseModel):
    """Request for manual stimulation trigger.

    Attributes:
        trigger: Keypress trigger (1-8). References StimKeypressIndex.
        trigger_on: Whether to turn the trigger on or off.
    """

    model_config = ConfigDict(frozen=True)

    trigger: StimKeypressIndex
    trigger_on: bool


class ManualStimTriggerToggleRequest(BaseModel):
    """Request to toggle manual stimulation trigger.

    Attributes:
        trigger: Keypress trigger (1-8). References StimKeypressIndex.
    """

    model_config = ConfigDict(frozen=True)

    trigger: StimKeypressIndex
