# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

*No unreleased changes.*

## [0.0.3] - 2026-04-07

### Added

#### AllegoClient

- Added Sinaps probe control methods: `load_all_mosi()`, `transmit_mosi()`, `read_wire_out()`, `get_sinaps_status_registers()`, and `flash_sinaps()`.
- Added explicit action methods: `start_streaming()`, `stop_streaming()`, `start_recording(*, port?)`, `stop_recording(*, port?)`, `set_stim_trigger(*, trigger, on)`, and `toggle_stim_trigger(*, trigger)`.
- Added partial-update method names: `update_recording_config(config)` and `update_core_config(*, samp_freq?, loop_dur?, pcache_persistence?, cable_delay?)`.
- Added trigger helpers: `enable_trigger(*, channel, port?)`, `disable_trigger(*, channel, port?)`, and `disable_all_triggers()`.
- Added spike sorter control methods: `get_spike_sorter_ids()`, `get_default_spike_sorter_id()`, `get_spike_sorter_state()`, `spike_sorter_command()`, `get_spike_sorter_dashboard()`, `get_detect_params()`, and `set_detect_params()`.

#### VidereClient

- Added offline spike sorter control methods: `get_spike_sorter_ids()`, `spike_sorter_launch()`, `spike_sorter_command()`, `spike_sorter_cancel()`, `get_spike_sorter_state()`, `get_spike_sorter_dashboard()`, `spike_sorter_delete()`, `get_detect_params()`, and `set_detect_params()`.

#### Domain Models And Exports

- Added `SinapsStatusRegisters`.
- Added spike sorter models and enums, including `SpikeSorterState`, `SpikeSorterLaunchParams`, `SpikeSorterLaunchResult`, `SpikeSorterDashboard`, `SpikeDetectParams`, `SpikeSorterCommand`, `SpikeSorterSubCommand`, `DashElement`, and related feature/clustering parameter models.
- Exported `TriggerChannel` from the top-level `radiens_core` package.
- Added `FlexDataset` (`DatasetMetadata | str | Path`) for dataset-taking methods in Videre and Curate clients.

#### Channel Metadata

- Added `ChannelInfo` fields: `name`, `ntv_name`, `is_selected`, `probe_id`, `headstage_id`, and `sensor_id`.
- Added inline site position fields on `ChannelInfo` (`probe_*`, `tissue_*`, `site_shape`, `site_area_um2`, bounding box limits, and transform offsets) with `None` for non-AMP channels.
- Added `ChannelInfo` convenience APIs: `has_position`, `bounding_box_size`, `bounding_box_center`, and `get_area()`.
- Added `ChannelMetadata` per-channel metadata collections: `chan_names`, `ntv_chan_names`, `probe_ids`, `headstage_ids`, and `sensor_ids`.

### Changed

- **AllegoClient**: `restart()` now takes `*, mode: BackboneMode` instead of a `RestartRequest` model.
- **AllegoClient**: `set_stim_step()` now takes `*, step: StimStep` instead of a `StimStepRequest` model.
- **AllegoClient**: `get_signals()` now accepts an optional `signals` parameter (defaults to all amplifier channels; `time_range` remains required).
- **AllegoClient**: `get_kpi_metrics()` now accepts optional `channel_indices` and `time_range` (defaults to all channels and a 5-second lookback window).
- **VidereClient**: `set_dsp_group()` now takes `stage` and `params` as keyword-only arguments.
- **VidereClient**: `get_signals()` now accepts optional `time_range` and `signals`; omitted values default to full recording and all amplifier channels.
- **VidereClient**: `get_kpi_metrics()` now accepts optional `channel_indices` and `time_range`; omitted values default to all channels and full recording.
- **VidereClient**: `get_spikes_by_channel()`, `get_spikes_by_neuron()`, and `get_neurons()` now accept `channels` as `list[int]`, `SignalSpec`, or `"all"` (in addition to `None`).
- **VidereClient**: `get_spikes_by_channel()` and `get_spikes_by_neuron()` now accept optional `time_range` and default to full recording when omitted.
- **VidereClient**: `get_spikes_spec()`, `get_spikes_by_channel()`, and `get_spikes_by_neuron()` now use the dedicated `RADIENS_SPIKE_SORTER` service endpoint.
- **CurateClient**: removed the `order` parameter from `notch()` and `bulk_notch()` (implementation is fixed to a second-order IIR notch).
- **DatasetMetadata**: added `base_path` property.
- **ChannelInfo**: `site_position` is now a computed `@property` rather than a stored field; access remains `info.site_position`.
- **Models package**: `TimeRangeSpec` and `SignalSpec` are exported via `radiens_core.models.__all__`.

### Deprecated

- `AllegoClient.set_stream_state()`: Use `start_streaming()` or `stop_streaming()` instead.
- `AllegoClient.set_record_state()`: Use `start_recording()` or `stop_recording()` instead.
- `AllegoClient.manual_stim_trigger()`: Use `set_stim_trigger()` instead.
- `AllegoClient.manual_stim_trigger_toggle()`: Use `toggle_stim_trigger()` instead.
- `AllegoClient.set_recording_config()`: Use `update_recording_config()` instead.
- `AllegoClient.set_core_config()`: Use `update_core_config()` instead.
- `AllegoClient.set_trigger_state()`: Use `enable_trigger()`, `disable_trigger()`, or `disable_all_triggers()` instead.

### Fixed

- **VidereClient**: `get_spikes_by_channel()` now correctly applies channel filtering to spike raster and optional waveform queries.

## [0.0.2] - 2026-03-25

### Added

- `VidereClient.get_spikes_spec()`: Retrieve spike interface metadata for a linked dataset.
- `VidereClient.get_spikes_by_channel()`: Retrieve spike timestamps and neuron labels per recording channel, with optional waveform snippets.
- `VidereClient.get_spikes_by_neuron()`: Same spike data regrouped by sorted neuron identity.
- `VidereClient.get_neurons()`: Retrieve neuron descriptors (spike count, rate, SNR, waveform peak amplitude, probe position) per channel.
- New domain models: `SpikesSpec`, `ChannelSpikeData`, `NeuronSpikeData`, `NeuronsResult`, `NeuronInfo`.
- `DatasetMetadata.associated_spikes_ids`: List of registered spikes datasource IDs discovered when the recording file was linked.

### Changed

- `link_data_file()` now automatically discovers and registers any associated `.spikes` file alongside the recording, populating `DatasetMetadata.associated_spikes_ids`. No change required at the call site.

## [0.0.1] - 2026-03-23

Initial stable release. All three clients (`AllegoClient`, `VidereClient`, `CurateClient`) with zero-config service discovery, strict mypy typing, and Pydantic v2 domain models.

### Added

#### AllegoClient (Real-time Acquisition)

- `healthcheck()`, `get_status()`, `set_stream_state()`, `set_record_state()`, `restart()` for session lifecycle.
- `get_signals()` for real-time signal data retrieval with `FlexTimeRange` / `FlexSignalSpec` convenience types.
- `get_channel_metadata()` for channel information.
- `get_stim_params()`, `set_stim_params()`, `set_trigger_control()` for stimulation control, including `headstage_global_amp_settle`.
- `get_recording_config()` and related methods for recording configuration.
- `get_dsp_group()` and `set_dsp_group()` for real-time filter configuration.
- `get_core_config()` and `set_core_config()` for global hardware settings (sampling frequency, loop duration, cable delays).
- `get_intan_impedance()` for channel impedance measurement and `scan_ports()` for hardware discovery.
- `get_dac_reg()`, `set_dac_gain()`, `set_dac_stream()`, `set_dac_off()`, `set_dac_highpass()` for DAC control.
- `get_dio_reg()`, `set_dio_events()`, `set_dio_manual()`, `set_dio_gated()`, `set_dio_pulse()` for Digital Output control.
- `get_kpi_metrics()`, `get_kpi_status()`, `set_kpi_packet_dur()`, `set_kpi_update_period()` for real-time signal-quality metrics.

#### VidereClient (Offline Analysis)

- `link_data_file()` for linking recorded data files (`.xdat`, `.rhd`).
- `get_signals()` for offline signal data retrieval.
- `get_dsp_group()` and `set_dsp_group()` for offline filter configuration.
- `list_data_sources()`, `list_data_source_ids()`, `clear_data_sources()`, `export_data_source()` for data source management.
- `get_kpi_metrics()`, `get_kpi_status()`, `kpi_calculate()`, `kpi_clear()`, `set_kpi_packet_dur()` for offline signal-quality metrics.

#### CurateClient (Data Curation)

- `link_data_file()` with `Path` support and progress bars.
- `slice_time()` and `slice_channels()` for time and channel subsetting.
- `downsample()` for sample-rate reduction.
- `highpass()`, `lowpass()`, `bandpass()`, `bandstop()`, `notch()` for filtering transforms.
- `car()` for Common Average Reference, `virtual_ref()` and `paired_ref()` for re-referencing.
- `set_protocol()` for registering arbitrary multi-step transform graphs (DAGs).

#### Domain Models

- `StimParams` with stimulation enums and `headstage_global_amp_settle`.
- `DSPGroup`, `DSPParams`, `DSPType`, `FilterStage` for filter configuration.
- `CoreConfig`, `CableDelay`, `SetCoreConfigRequest` for hardware settings.
- `Impedance`, `ImpedanceValue` for impedance data.
- `AnalogOutRegister`, `AnalogOutChannel`, `DACHighPass` for DAC configuration.
- `DigitalOutRegister`, `DigitalOutChannelRegister`, `DIOMode` for DIO configuration.
- `KpiMetric`, `KpiMetricId`, `KpiMetricsResult`, `KpiMode`, `KpiStatus` for signal-quality metrics.
- `TransformNode`, `TransformEdge`, `TransformNodeType` and all transform parameter models for curation protocols.
- `FlexTimeRange` and `FlexSignalSpec` convenience types with Pydantic runtime coercion.

#### Infrastructure

- Zero-config authentication via `AuthInterceptor`.
- Auto-discovery of server UUID and service endpoints.
- `BaseClient` with shared gRPC channel pool and lifecycle management.
- Proto-driven type safety architecture with `_converters/` / `_services/` layer separation.
- MkDocs documentation site with auto-generated API reference.
- Automated PyPI publishing via GitHub Actions (Trusted Publishing).

[Unreleased]: https://github.com/NeuroNexus/radiens-core-python/compare/v0.0.3...HEAD
[0.0.3]: https://github.com/NeuroNexus/radiens-core-python/compare/v0.0.2...v0.0.3
