"""Tests for Vix11Middleware (ASGI)."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest

from vix11.client import AsyncVix11Client
from vix11.middleware import Vix11Middleware
from vix11.types import DetectResponse, Vix11Error


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_scope(path: str = "/api/chat", method: str = "GET") -> dict[str, Any]:
    return {
        "type": "http",
        "method": method,
        "path": path,
        "headers": [],
    }


async def _make_receive(body: bytes = b"") -> Any:
    """Create a simple receive callable that returns the body once."""
    calls = [False]

    async def receive() -> dict[str, Any]:
        if not calls[0]:
            calls[0] = True
            return {"type": "http.request", "body": body, "more_body": False}
        return {"type": "http.disconnect"}

    return receive


class ResponseCapture:
    """Capture ASGI send() calls."""

    def __init__(self) -> None:
        self.events: list[dict[str, Any]] = []

    async def __call__(self, event: dict[str, Any]) -> None:
        self.events.append(event)

    @property
    def status(self) -> int:
        for e in self.events:
            if e["type"] == "http.response.start":
                return e["status"]
        return 0

    @property
    def body(self) -> dict[str, Any]:
        for e in self.events:
            if e["type"] == "http.response.body":
                return json.loads(e["body"])
        return {}


class DummyApp:
    """Simple ASGI app that returns 200 OK."""

    def __init__(self) -> None:
        self.called = False

    async def __call__(
        self,
        scope: dict[str, Any],
        receive: Any,
        send: Any,
    ) -> None:
        self.called = True
        body = json.dumps({"result": "ok"}).encode()
        await send(
            {
                "type": "http.response.start",
                "status": 200,
                "headers": [[b"content-type", b"application/json"]],
            }
        )
        await send({"type": "http.response.body", "body": body})


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestVix11Middleware:
    @pytest.mark.asyncio
    async def test_passes_clean_requests(self) -> None:
        app = DummyApp()
        client = AsyncVix11Client("https://vix11.example.com", "agent-1")
        middleware = Vix11Middleware(app, client)

        allow_result = DetectResponse(action="allow", score=0.05, layers=[], total_duration_ms=2.0)

        with patch.object(client, "detect", new_callable=AsyncMock, return_value=allow_result):
            scope = _make_scope()
            receive = await _make_receive(b'{"prompt": "hello"}')
            send = ResponseCapture()
            await middleware(scope, receive, send)

        assert app.called
        assert send.status == 200
        assert send.body["result"] == "ok"

    @pytest.mark.asyncio
    async def test_blocks_on_block_action(self) -> None:
        app = DummyApp()
        client = AsyncVix11Client("https://vix11.example.com", "agent-1")
        middleware = Vix11Middleware(app, client)

        block_result = DetectResponse(action="block", score=0.95, layers=[], total_duration_ms=1.0)

        with patch.object(client, "detect", new_callable=AsyncMock, return_value=block_result):
            scope = _make_scope()
            receive = await _make_receive(b'{"prompt": "bad"}')
            send = ResponseCapture()
            await middleware(scope, receive, send)

        assert not app.called
        assert send.status == 403
        assert send.body["action"] == "block"

    @pytest.mark.asyncio
    async def test_returns_429_on_throttle(self) -> None:
        app = DummyApp()
        client = AsyncVix11Client("https://vix11.example.com", "agent-1")
        middleware = Vix11Middleware(app, client)

        throttle_result = DetectResponse(action="throttle", score=0.45, layers=[], total_duration_ms=1.0)

        with patch.object(client, "detect", new_callable=AsyncMock, return_value=throttle_result):
            scope = _make_scope()
            receive = await _make_receive(b"")
            send = ResponseCapture()
            await middleware(scope, receive, send)

        assert not app.called
        assert send.status == 429
        assert send.body["action"] == "throttle"

    @pytest.mark.asyncio
    async def test_passes_through_on_shadow_ban(self) -> None:
        """Shadow-ban should pass through to the app (stealth degradation)."""
        app = DummyApp()
        client = AsyncVix11Client("https://vix11.example.com", "agent-1")
        middleware = Vix11Middleware(app, client)

        sb_result = DetectResponse(action="shadow-ban", score=0.7, layers=[], total_duration_ms=1.0)

        with patch.object(client, "detect", new_callable=AsyncMock, return_value=sb_result):
            scope = _make_scope()
            receive = await _make_receive(b"")
            send = ResponseCapture()
            await middleware(scope, receive, send)

        assert app.called
        assert send.status == 200

    @pytest.mark.asyncio
    async def test_fails_open_on_detection_error(self) -> None:
        """If Vix11 detection service is unavailable, pass through."""
        app = DummyApp()
        client = AsyncVix11Client("https://vix11.example.com", "agent-1")
        middleware = Vix11Middleware(app, client)

        with patch.object(
            client,
            "detect",
            new_callable=AsyncMock,
            side_effect=Vix11Error(502, "Service unavailable"),
        ):
            scope = _make_scope()
            receive = await _make_receive(b"")
            send = ResponseCapture()
            await middleware(scope, receive, send)

        assert app.called
        assert send.status == 200

    @pytest.mark.asyncio
    async def test_non_http_scope_passes_through(self) -> None:
        """Non-HTTP scopes (websocket, lifespan) should pass through directly."""
        app = DummyApp()
        client = AsyncVix11Client("https://vix11.example.com", "agent-1")
        middleware = Vix11Middleware(app, client)

        scope = {"type": "lifespan"}
        receive = await _make_receive(b"")
        send = ResponseCapture()
        await middleware(scope, receive, send)

        assert app.called
