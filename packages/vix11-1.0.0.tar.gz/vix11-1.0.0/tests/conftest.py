"""Shared fixtures for Vix11 SDK tests."""

from __future__ import annotations

import pytest

BASE_URL = "https://vix11.example.com"
AGENT_ID = "test-agent-001"
API_KEY = "test-api-key-xyz"


@pytest.fixture
def base_url() -> str:
    return BASE_URL


@pytest.fixture
def agent_id() -> str:
    return AGENT_ID


@pytest.fixture
def api_key() -> str:
    return API_KEY
