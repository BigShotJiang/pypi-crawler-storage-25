"""ASGI middleware for integrating Vix11 detection into FastAPI / Starlette apps."""

from __future__ import annotations

import json
from typing import Any, Callable

from vix11.client import AsyncVix11Client
from vix11.types import Vix11Error


class Vix11Middleware:
    """ASGI middleware that runs Vix11 detection on every HTTP request.

    Usage with FastAPI::

        from vix11 import AsyncVix11Client
        from vix11.middleware import Vix11Middleware

        client = AsyncVix11Client("https://vix11.example.com", agent_id="my-agent")
        app.add_middleware(Vix11Middleware, client=client)
    """

    def __init__(
        self,
        app: Any,
        client: AsyncVix11Client,
        block_action: str = "block",
    ) -> None:
        self.app = app
        self.client = client
        self.block_action = block_action

    async def __call__(
        self,
        scope: dict[str, Any],
        receive: Callable[..., Any],
        send: Callable[..., Any],
    ) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        # Build path from scope
        path: str = scope.get("path", "/")

        # Read the request body
        body_parts: list[bytes] = []
        request_complete = False

        async def receive_wrapper() -> dict[str, Any]:
            nonlocal request_complete
            message = await receive()
            if message["type"] == "http.request":
                body_parts.append(message.get("body", b""))
                if not message.get("more_body", False):
                    request_complete = True
            return message

        # We need to consume the body to send it to Vix11, then replay it
        # For simplicity, read all body chunks first
        while not request_complete:
            await receive_wrapper()

        raw_body = b"".join(body_parts)
        payload = raw_body.decode("utf-8", errors="replace") if raw_body else ""

        # Run detection
        try:
            result = await self.client.detect(endpoint=path, payload=payload)
        except Vix11Error:
            # If detection service is down, fail open -- let the request through
            await self._replay_app(scope, raw_body, send)
            return

        # Act on the detection result
        if result.action == "block":
            await self._send_json_response(
                send,
                status=403,
                body={"error": "Request denied by security policy", "action": "block"},
            )
            return

        if result.action == "throttle":
            await self._send_json_response(
                send,
                status=429,
                body={"error": "Too many requests", "action": "throttle", "retryAfterMs": 5000},
            )
            return

        # allow or shadow-ban: pass through to the app
        await self._replay_app(scope, raw_body, send)

    async def _replay_app(
        self,
        scope: dict[str, Any],
        body: bytes,
        send: Callable[..., Any],
    ) -> None:
        """Replay the consumed body back to the downstream ASGI app."""
        body_sent = False

        async def replayed_receive() -> dict[str, Any]:
            nonlocal body_sent
            if not body_sent:
                body_sent = True
                return {"type": "http.request", "body": body, "more_body": False}
            # After body is sent, return disconnect
            return {"type": "http.disconnect"}

        await self.app(scope, replayed_receive, send)

    @staticmethod
    async def _send_json_response(
        send: Callable[..., Any],
        status: int,
        body: dict[str, Any],
    ) -> None:
        """Send a JSON response directly via ASGI."""
        payload = json.dumps(body).encode("utf-8")
        await send(
            {
                "type": "http.response.start",
                "status": status,
                "headers": [
                    [b"content-type", b"application/json"],
                    [b"content-length", str(len(payload)).encode("ascii")],
                ],
            }
        )
        await send(
            {
                "type": "http.response.body",
                "body": payload,
            }
        )
