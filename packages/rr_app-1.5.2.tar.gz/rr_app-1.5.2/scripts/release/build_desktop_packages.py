#!/usr/bin/env python3
"""Build desktop release artifacts with local scripts.

This wrapper keeps artifact names aligned with the publish workflow:
- Windows: rr-app-<version>-portable-win64.zip and installer/*.exe
- macOS:   rr-app-<version>-macos-app.zip and rr-app-<version>-macos.dmg
"""

from __future__ import annotations

import argparse
import ast
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path


DIST_DIR_NAME = "dist"
BUILD_DIR_NAME = "build"

DESKTOP_CLEANUP_PATTERNS: dict[str, tuple[str, ...]] = {
    "windows": ("rr-app-*-portable-win64.zip", "installer/rr-app-*-setup*.exe"),
    "macos": ("rr-app-*-macos-app.zip", "rr-app-*-macos.dmg"),
}

PYTHON_GLOB_PATTERNS: tuple[str, ...] = ("rr_app-*.whl", "rr_app-*.tar.gz")
TRANSIENT_DIST_DIRS: dict[str, tuple[str, ...]] = {
    "windows": ("rr",),
    "macos": ("RR App", "RR App.app"),
}


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _normalize_version(raw: str) -> str:
    value = str(raw).strip()
    if not value:
        raise ValueError("Version cannot be empty.")
    return value[1:] if value.startswith("v") else value


def _read_source_version(repo_root: Path) -> str:
    version_file = repo_root / "rr_app" / "__init__.py"
    if not version_file.is_file():
        raise RuntimeError(f"Could not find source version file: {version_file}")

    module = ast.parse(version_file.read_text(encoding="utf-8"), filename=str(version_file))
    for node in module.body:
        if not isinstance(node, ast.Assign):
            continue
        if len(node.targets) != 1:
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name) or target.id != "__version__":
            continue
        if not isinstance(node.value, ast.Constant) or not isinstance(node.value.value, str):
            raise RuntimeError("__version__ must be assigned to a string literal in rr_app/__init__.py")
        # Keep desktop package names and python package metadata in sync from one source of truth.
        return _normalize_version(node.value.value)
    raise RuntimeError("Could not find __version__ assignment in rr_app/__init__.py")


def _resolve_target() -> str:
    system_name = platform.system()
    if system_name == "Windows":
        return "windows"
    if system_name == "Darwin":
        return "macos"
    raise RuntimeError("Desktop packaging supports only Windows and macOS hosts.")


def _run(cmd: list[str], cwd: Path, env: dict[str, str] | None = None, dry_run: bool = False) -> None:
    rendered = " ".join(cmd)
    print(f"$ {rendered}")
    if dry_run:
        return
    subprocess.run(cmd, cwd=str(cwd), env=env, check=True)


def _build_windows(repo_root: Path, version: str, dry_run: bool) -> None:
    script = repo_root / "scripts" / "release" / "build_windows.ps1"
    cmd = [
        "powershell",
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(script),
        "-Version",
        version,
        "-PythonExe",
        sys.executable,
        "-DistDir",
        DIST_DIR_NAME,
    ]
    _run(cmd, cwd=repo_root, dry_run=dry_run)


def _build_macos(repo_root: Path, version: str, dry_run: bool) -> None:
    script = repo_root / "scripts" / "release" / "build_macos.sh"
    env = os.environ.copy()
    env["PYTHON_EXE"] = sys.executable
    env["DIST_DIR"] = DIST_DIR_NAME
    cmd = ["bash", str(script), version]
    _run(cmd, cwd=repo_root, env=env, dry_run=dry_run)


def _verify_windows_outputs(dist_path: Path, version: str) -> list[Path]:
    portable_zip = dist_path / f"rr-app-{version}-portable-win64.zip"
    installer_matches = sorted((dist_path / "installer").glob(f"rr-app-{version}-setup*.exe"))
    if not portable_zip.is_file():
        raise RuntimeError(f"Missing Windows portable zip: {portable_zip}")
    if not installer_matches:
        raise RuntimeError(
            "Missing Windows installer .exe in dist/installer/. "
            "Check Inno Setup installation (`iscc`) and rerun."
        )
    return [portable_zip, *installer_matches]


def _verify_macos_outputs(dist_path: Path, version: str) -> list[Path]:
    app_zip = dist_path / f"rr-app-{version}-macos-app.zip"
    dmg = dist_path / f"rr-app-{version}-macos.dmg"
    missing = [path for path in (app_zip, dmg) if not path.is_file()]
    if missing:
        rendered = ", ".join(str(path) for path in missing)
        raise RuntimeError(f"Missing macOS artifact(s): {rendered}")
    return [app_zip, dmg]


def _cleanup_superseded_artifacts(dist_path: Path, target: str, version: str, keep_paths: list[Path]) -> None:
    keep_set = {path.resolve() for path in keep_paths}
    keep_prefix = f"rr_app-{version}"
    delete_paths: set[Path] = set()
    delete_dirs: set[Path] = set()

    # Cleanup flow:
    # 1) Collect all known desktop artifacts for this host target and keep only this run's verified outputs.
    # 2) Prune Python wheel/sdist files that do not match the current source version.
    # 3) Remove transient PyInstaller output directories left in dist/ after packaging.
    # 4) Execute deletions only after verification has already confirmed current outputs exist.
    for pattern in DESKTOP_CLEANUP_PATTERNS[target]:
        for path in sorted(dist_path.glob(pattern)):
            if not path.is_file():
                continue
            if path.resolve() in keep_set:
                continue
            delete_paths.add(path.resolve())

    for pattern in PYTHON_GLOB_PATTERNS:
        for path in sorted(dist_path.glob(pattern)):
            if not path.is_file():
                continue
            if path.name.startswith(keep_prefix):
                continue
            delete_paths.add(path.resolve())

    for dirname in TRANSIENT_DIST_DIRS[target]:
        dir_path = (dist_path / dirname).resolve()
        if dir_path.exists() and dir_path.is_dir():
            delete_dirs.add(dir_path)

    if not delete_paths and not delete_dirs:
        print("No superseded artifacts or transient dist directories found.")
        return

    print(f"Removing superseded artifacts: {len(delete_paths)} file(s), {len(delete_dirs)} directory(ies)")
    for path in sorted(delete_paths):
        path.unlink(missing_ok=True)
        print(f"- deleted {path}")
    for path in sorted(delete_dirs):
        shutil.rmtree(path, ignore_errors=False)
        print(f"- deleted {path}")


def _cleanup_build_dir(repo_root: Path) -> None:
    build_dir = (repo_root / BUILD_DIR_NAME).resolve()
    if not build_dir.exists():
        print("No build directory to remove.")
        return
    if not build_dir.is_dir():
        raise RuntimeError(f"Expected build path to be a directory: {build_dir}")

    shutil.rmtree(build_dir)
    print(f"Removed build intermediates: {build_dir}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Build local desktop release packages with fixed host target, "
            "fixed dist output, and rr_app.__version__."
        )
    )
    parser.add_argument("--dry-run", action="store_true", help="Print commands without running builders.")
    args = parser.parse_args()

    repo_root = _repo_root()
    version = _read_source_version(repo_root)
    dist_path = (repo_root / DIST_DIR_NAME).resolve()
    target = _resolve_target()

    print(f"Repo root: {repo_root}")
    print(f"Target: {target}")
    print(f"Python executable: {sys.executable}")
    print(f"Dist directory: {dist_path}")
    print("Version source: rr_app.__version__")
    print(f"Version: {version}")

    if target == "windows":
        _build_windows(
            repo_root=repo_root,
            version=version,
            dry_run=args.dry_run,
        )
        if args.dry_run:
            return
        artifacts = _verify_windows_outputs(dist_path=dist_path, version=version)
    else:
        _build_macos(
            repo_root=repo_root,
            version=version,
            dry_run=args.dry_run,
        )
        if args.dry_run:
            return
        artifacts = _verify_macos_outputs(dist_path=dist_path, version=version)

    _cleanup_superseded_artifacts(
        dist_path=dist_path,
        target=target,
        version=version,
        keep_paths=artifacts,
    )
    _cleanup_build_dir(repo_root=repo_root)

    # Artifact validation flow:
    # 1) Run the per-OS builder script.
    # 2) Verify exact filename patterns used by the current publish workflow.
    # 3) Remove superseded outputs only after validation succeeds.
    # 4) Remove local build intermediates to keep the repository clean.
    # 5) Print absolute output paths so local/private handoff is straightforward.
    print("\nArtifacts ready:")
    for artifact in artifacts:
        print(f"- {artifact}")


if __name__ == "__main__":
    main()
