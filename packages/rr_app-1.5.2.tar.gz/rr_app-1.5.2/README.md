# RR App (`rr_emg`)

Language: **English** | [繁體中文](README.zh-TW.md) | [简体中文](README.zh-CN.md)

## Overview

`rr_emg` is a desktop GUI for Bluetooth monitoring and control.

It supports:
- **EMGS devices** (EMG + IMU streaming)
- **AKR-compatible devices** (including `rr_akr2` protocol behavior and other compatible devices such as EMGS-family products)

Typical use:
- scan and connect to devices,
- monitor live data,
- send control/configuration commands,
- record sessions for analysis.

## Audience

- Operators and clinicians
- R&D teams
- Integrators and developers

For operator-focused instructions, see `IFU.md`.

## Requirements

- Python `>=3.10,<3.14`
- Bluetooth-capable host (macOS / Linux / Windows)

## Installation

### Option 1: Release packages (recommended for most operators)

Download from [GitHub Releases](https://github.com/o0fung/RR_EMG/releases/latest).

- Windows: `rr-app-<version>-setup.exe`
- macOS: `rr-app-<version>-macos.dmg`

On macOS, if Gatekeeper warns on unsigned builds, right-click the app and choose **Open**.

### Option 2: PyPI / pipx

```bash
pip install rr-app
```

or

```bash
pipx install rr-app
```

### Option 3: From source (developer path)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Quick Start

1. Turn on host Bluetooth.
2. Power on target device(s).
3. Launch:

```bash
rr
```

4. Scan and connect in the app.
5. Use **Signals** tab for live monitoring.
6. Use settings/control actions as needed.
7. Start recording when session export is required.

Simulation mode (no hardware):

```bash
RR_BACKEND=sim rr
```

## Device Compatibility Notes

- EMGS discovery prefix: `EMGS`
- AKR discovery prefixes: `AKR` and optional legacy `BT`
- AKR BLE profile fallback is built-in (new profile first, legacy profile fallback)

## Protocol and OTA Docs

- AKR/BT CLI + telemetry: `doc/BT_AKR_DEVICE_PROTOCOL.md`
- OTA CLI session protocol: `doc/OTA_PROTOCOL_CLI_SESSION.md`

## Data and Logs

- Startup logs:
  - macOS: `~/Library/Logs/rr-app`
  - Linux/Windows: `~/.rr-app/logs`
- Default recording folder: `~/rr_data`

## Project Links

- Homepage: [RR_EMG](https://github.com/o0fung/RR_EMG)
- Issues: [GitHub Issues](https://github.com/o0fung/RR_EMG/issues)

