from __future__ import annotations

import asyncio
from contextlib import suppress
import logging
import sys
from pathlib import Path

import qasync
from PyQt6 import QtWidgets

from . import __version__, config
from .devices.core.controller import DeviceController
from .gui.main_window import MainWindow
from .i18n import DEFAULT_LANGUAGE_PACKS, load_language_packs
from .logging_utils import setup_logging
from .update_check import get_newer_release_version


logger = logging.getLogger(__name__)


def _resource_path(rel: str) -> Path:
    return Path(__file__).resolve().parent / rel


def main() -> int:
    setup_logging(logging.INFO)

    app = QtWidgets.QApplication(sys.argv)

    cwd = Path.cwd()
    language_packs, current_language = load_language_packs(
        candidate_paths=[
            str(cwd / "resources" / "languages.json"),
            str(cwd / "rr_app" / "resources" / "languages.json"),
        ],
        default_language_packs=DEFAULT_LANGUAGE_PACKS,
    )

    app_name = config.APP_TITLE
    try:
        current_texts = language_packs.get(current_language, {}).get("texts", {})
        default_texts = language_packs.get("en", {}).get("texts", {})
        if isinstance(current_texts, dict):
            app_name = str(current_texts.get("app_title", app_name))
        if app_name == config.APP_TITLE and isinstance(default_texts, dict):
            app_name = str(default_texts.get("app_title", app_name))
    except Exception:
        app_name = config.APP_TITLE
    app.setApplicationName(app_name)

    # Dark theme stylesheet
    qss_path = _resource_path("resources/style.qss")
    if qss_path.exists():
        app.setStyleSheet(qss_path.read_text(encoding="utf-8"))
    else:
        logger.warning("Stylesheet missing: %s", qss_path)

    # Qt + asyncio integration
    loop = qasync.QEventLoop(app)
    asyncio.set_event_loop(loop)

    # Pick backend from env (optional): EMGS_BACKEND=sim
    controller = DeviceController()
    win = MainWindow(
        controller,
        language_packs=language_packs,
        current_language=current_language,
    )
    win.show()

    async def _startup_update_notice_task() -> None:
        # Startup update flow is intentionally best-effort:
        # 1) query latest version in a background task, 2) compare to local version,
        # 3) show notice only when newer exists, 4) stay silent on all failures.
        try:
            latest = await get_newer_release_version(
                current_version=__version__,
                api_url=str(getattr(config, "UPDATE_CHECK_PYPI_JSON_URL", "")),
                timeout_s=float(getattr(config, "UPDATE_CHECK_TIMEOUT_S", 2.5)),
            )
        except Exception:
            logger.debug("Startup update check failed unexpectedly", exc_info=True)
            return
        if latest:
            logger.warning("Update available: current=v%s latest=v%s", __version__, latest)
            with suppress(Exception):
                win.show_update_available_notice(latest)

    with loop:
        # Best-effort cleanup on unexpected top-level exceptions.
        def _excepthook(exc_type, exc, tb) -> None:
            with suppress(Exception):
                logger.exception("Unhandled exception", exc_info=(exc_type, exc, tb))
            with suppress(Exception):
                asyncio.create_task(controller.manager.shutdown())
            with suppress(Exception):
                QtWidgets.QApplication.instance().quit()

        sys.excepthook = _excepthook
        if bool(getattr(config, "UPDATE_CHECK_ENABLED", True)):
            # `asyncio.create_task(...)` needs a *running* loop. At this point
            # we are still in pre-run setup, so schedule directly on qasync loop.
            loop.create_task(_startup_update_notice_task())
        loop.run_forever()
    return 0

