from __future__ import annotations

DEFAULT_REC_OUT_DIRNAME = "rr_data"

REC_EMG_FIELDS_ALL: tuple[str, ...] = (
    "emg_raw_mV",
    "emg_clean_ecg_mV",
    "emg_ecg_artifact_mV",
    "emg_env_rms",
    "emg_mdf_hz",
    "emg_mnf_hz",
    "emg_pkt_rms_v",
    "emg_snr",
    "fatigue_score",
    "fatigue_conf",
)

_REC_AXES3: tuple[str, str, str] = ("x", "y", "z")
_REC_QUAT: tuple[str, str, str, str] = ("w", "x", "y", "z")
REC_IMU_FIELDS_ALL: tuple[str, ...] = tuple(
    [f"raw_acc_{a}" for a in _REC_AXES3]
    + [f"acc_{a}" for a in _REC_AXES3]
    + [f"lin_acc_{a}" for a in _REC_AXES3]
    + [f"raw_gyr_{a}" for a in _REC_AXES3]
    + [f"gyr_{a}" for a in _REC_AXES3]
    + [f"uncal_mag_{a}" for a in _REC_AXES3]
    + [f"mag_{a}" for a in _REC_AXES3]
    + [f"quat_game_{a}" for a in _REC_QUAT]
    + [f"quat_geomag_{a}" for a in _REC_QUAT]
)

REC_ROBOT_FIELDS_ALL: tuple[str, ...] = tuple(
    [
        "walk_fid",
        "walk_dt_ms",
        "walk_exec_ms",
        "walk_out",
        "walk_state",
        "walk_tilt_forward_deg",
        "walk_pos_rad",
        "walk_vel_rad_s",
        "walk_tq_nm",
        "walk_temp_c",
        "walk_vbus_v",
        "walk_pattern",
        "walk_err_code",
        "walk_fb_age_ms",
    ]
    + [f"walk_acc_{a}" for a in _REC_AXES3]
    + [f"walk_gyr_{a}" for a in _REC_AXES3]
    + [f"walk_mag_{a}" for a in _REC_AXES3]
    + [
        "cpm_fid",
        "cpm_dt_ms",
        "cpm_state",
        "cpm_dir",
        "cpm_blocked_event",
        "cpm_block_reason",
        "cpm_blocked_consecutive",
        "cpm_cmd_spd_rad_s",
        "cpm_pos_rad",
        "cpm_vel_rad_s",
        "cpm_tq_nm",
        "cpm_temp_c",
        "cpm_vbus_v",
        "cpm_pattern",
        "cpm_err_code",
        "cpm_fb_age_ms",
        "cpm_df_limit_rad",
        "cpm_pf_limit_rad",
        "cpm_elapsed_s",
        "cpm_remaining_s",
        "cpm_has_remaining",
        "cpm_repetition_count",
    ]
    + [
        "measure_fid",
        "measure_dt_ms",
        "measure_state",
        "measure_dir",
        "measure_blocked",
        "measure_result_flags",
        "measure_pos_rad",
        "measure_vel_rad_s",
        "measure_tq_nm",
        "measure_temp_c",
        "measure_vbus_v",
        "measure_pattern",
        "measure_err_code",
        "measure_fb_age_ms",
        "measure_prom_df_end_rad",
        "measure_prom_pf_end_rad",
        "measure_arom_df_max_rad",
        "measure_arom_pf_min_rad",
        "measure_flag_prom_df_valid",
        "measure_flag_prom_pf_valid",
        "measure_flag_arom_valid",
        "measure_flag_seq_active",
        "measure_flag_arom_running",
    ]
    + [
        "cfg_fid",
        "cfg_robot_id",
        "cfg_ble_target",
        "cfg_gait_model",
        "cfg_gait_mode",
        "cfg_side_is_left",
        "cfg_df_assist_pct",
        "cfg_pf_assist_pct",
        "cfg_df_torque",
        "cfg_df_angle",
        "cfg_df_speed",
        "cfg_df_kp",
        "cfg_df_kd",
        "cfg_pf_torque",
        "cfg_pf_angle",
        "cfg_pf_speed",
        "cfg_pf_kp",
        "cfg_pf_kd",
        "cfg_cpm_target_df_rad",
        "cfg_cpm_target_pf_rad",
        "cfg_cpm_speed_to_df_rad_s",
        "cfg_cpm_speed_to_pf_rad_s",
        "cfg_cpm_block_tq_nm",
        "cfg_cpm_wait_to_df_ms",
        "cfg_cpm_wait_to_pf_ms",
    ]
)
