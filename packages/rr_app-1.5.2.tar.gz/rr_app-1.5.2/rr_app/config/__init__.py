"""Central configuration package for the rewrite."""

from __future__ import annotations

from .. import __version__
from .akr import *  # noqa: F403
from .core import *  # noqa: F403
from .emgs import *  # noqa: F403
from .recording import *  # noqa: F403

APP_TITLE = f"RR_APP v{__version__}"
