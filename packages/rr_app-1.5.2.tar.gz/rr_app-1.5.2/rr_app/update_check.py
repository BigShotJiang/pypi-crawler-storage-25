from __future__ import annotations

import asyncio
import importlib
import json
import logging
import re
import ssl
from itertools import zip_longest
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

logger = logging.getLogger(__name__)

def _resolve_ca_bundle_path() -> str | None:
    # Probe common CA bundle providers in order:
    # 1) standalone certifi package, 2) pip vendored certifi (often present even
    # when certifi isn't explicitly installed in the venv).
    for module_name in ("certifi", "pip._vendor.certifi"):
        try:
            mod = importlib.import_module(module_name)
            where_fn = getattr(mod, "where", None)
            if callable(where_fn):
                path = str(where_fn()).strip()
                if path:
                    return path
        except Exception:
            continue
    return None


def _build_ssl_context() -> ssl.SSLContext:
    # Some Python builds on macOS can miss a usable system CA chain.
    # Prefer certifi CA bundle (including pip-vendored copy) when available;
    # otherwise use default context.
    cafile = _resolve_ca_bundle_path()
    if cafile:
        try:
            return ssl.create_default_context(cafile=cafile)
        except Exception:
            pass
    return ssl.create_default_context()


def _fetch_latest_pypi_version_sync(api_url: str, timeout_s: float) -> str | None:
    req = Request(
        api_url,
        headers={
            "Accept": "application/json",
            "User-Agent": "rr-app-update-check",
        },
    )
    try:
        with urlopen(
            req,
            timeout=max(0.1, float(timeout_s)),
            context=_build_ssl_context(),
        ) as resp:
            if int(getattr(resp, "status", 200)) != 200:
                logger.info("Update check skipped: PyPI returned status %s", getattr(resp, "status", "unknown"))
                return None
            payload = json.loads(resp.read().decode("utf-8"))
    except (HTTPError, URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        logger.debug("Update check failed while fetching PyPI metadata: %s", exc)
        return None

    info = payload.get("info", {})
    latest = str(info.get("version", "")).strip() if isinstance(info, dict) else ""
    return latest or None


def _parse_numeric_version(value: str) -> tuple[int, ...] | None:
    # Fallback parser accepts dotted numeric versions only (for example: 1.4.5).
    # This is intentionally strict so we avoid false positives when suffix-heavy
    # prerelease/dev version strings appear and `packaging` is unavailable.
    cleaned = str(value).strip()
    if not cleaned or not re.fullmatch(r"\d+(?:\.\d+)*", cleaned):
        return None
    return tuple(int(part) for part in cleaned.split("."))


def _compare_numeric_versions(lhs: tuple[int, ...], rhs: tuple[int, ...]) -> int:
    for l_part, r_part in zip_longest(lhs, rhs, fillvalue=0):
        if l_part > r_part:
            return 1
        if l_part < r_part:
            return -1
    return 0


def _is_newer_version(candidate: str, current: str) -> bool:
    try:
        version_mod = importlib.import_module("packaging.version")
        version_cls = getattr(version_mod, "Version", None)
        invalid_cls = getattr(version_mod, "InvalidVersion", Exception)
        if callable(version_cls):
            try:
                return bool(version_cls(candidate) > version_cls(current))
            except invalid_cls:
                logger.debug(
                    "Update check falling back to numeric version parser: candidate=%s current=%s",
                    candidate,
                    current,
                )
    except Exception:
        pass

    parsed_candidate = _parse_numeric_version(candidate)
    parsed_current = _parse_numeric_version(current)
    if parsed_candidate is None or parsed_current is None:
        return False
    return _compare_numeric_versions(parsed_candidate, parsed_current) > 0


async def get_newer_release_version(*, current_version: str, api_url: str, timeout_s: float) -> str | None:
    latest = await asyncio.to_thread(
        _fetch_latest_pypi_version_sync,
        api_url,
        timeout_s,
    )
    if not latest:
        return None
    if not _is_newer_version(latest, current_version):
        return None
    return latest
