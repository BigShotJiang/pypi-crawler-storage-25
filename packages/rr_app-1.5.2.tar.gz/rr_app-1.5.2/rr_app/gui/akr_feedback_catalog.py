from __future__ import annotations

import math
import re

# Authoritative AKR CLI feedback field catalog shared by
# the Settings dialog table and Signals chart tile builder.
AKR_RUNTIME_STATUS_FIELDS: tuple[str, ...] = (
    "fw_name",
    "fw_version_str",
    "is_left",
    "task_to_test",
    "mode",
    "gait_model",
    "motor_connected",
    "motor_feedback_age_ms",
    "motor_can_id",
    "motor_pattern",
    "motor_error_code",
    "motor_fault_error_code",
    "motor_mode_0x7005",
    "motor_mode_0x7005_name",
    "sound_noncritical",
    "sound_critical",
    "imu_ok",
    "ble_connected",
    "ble_ver",
    "ble_name",
    "ble_lename",
    "robot_id",
    "ble_target_name",
    "ble_tx_used",
    "ble_tx_peak",
    "ble_tx_enq",
    "ble_tx_drop",
    "rf_paired",
    "rf_key_id",
    "rf_bit_split_us",
    "mech_position_rad",
    "speed_rad_s",
    "torque_nm",
    "temp_c",
    "vbus_v",
)

AKR_TELEM_ARG_FIELDS: tuple[str, ...] = (
    "fid",
    "dt_ms",
    "exec_ms",
    "out",
    "state",
    "acc_x",
    "acc_y",
    "acc_z",
    "gyr_x",
    "gyr_y",
    "gyr_z",
    "mag_x",
    "mag_y",
    "mag_z",
    "tilt_forward_deg",
    "pos_rad",
    "vel_rad_s",
    "tq_nm",
    "temp_c",
    "vbus_v",
    "pattern",
    "err_code",
    "fb_age_ms",
    "cpm_state",
    "dir",
    "blocked_event",
    "cpm_block_reason",
    "blocked_consecutive",
    "block_tq",
    "cpm_exit_state",
    "cmd_spd_rad_s",
    "df_limit_rad",
    "pf_limit_rad",
    "elapsed_s",
    "remaining_s",
    "has_remaining",
    "repetition_count",
    "measure_state",
    "blocked",
    "result_flags",
    "prom_df_end_rad",
    "prom_pf_end_rad",
    "arom_df_max_rad",
    "arom_pf_min_rad",
    "cfg_fid",
    "cfg_gait_model",
    "cfg_gait_mode",
    "cfg_side_is_left",
    "cfg_df_assist_pct",
    "cfg_pf_assist_pct",
    "cfg_df_torque",
    "cfg_df_angle",
    "cfg_df_speed",
    "cfg_df_kp",
    "cfg_df_kd",
    "cfg_pf_torque",
    "cfg_pf_angle",
    "cfg_pf_speed",
    "cfg_pf_kp",
    "cfg_pf_kd",
    "cfg_cpm_target_df_rad",
    "cfg_cpm_target_pf_rad",
    "cfg_cpm_speed_to_df_rad_s",
    "cfg_cpm_speed_to_pf_rad_s",
    "cfg_cpm_block_tq_nm",
    "cfg_cpm_wait_to_df_ms",
    "cfg_cpm_wait_to_pf_ms",
)

AKR_RUNTIME_DUPLICATE_FIELDS: tuple[str, ...] = (
    "mode",
    "pos_rad",
    "vel_rad_s",
    "tq_nm",
    "temp_c",
    "err_code",
    "vbus_v",
    "acc_x",
    "acc_y",
    "acc_z",
    "gyr_x",
    "gyr_y",
    "gyr_z",
    "mag_x",
    "mag_y",
    "mag_z",
    "tilt_forward_deg",
)

AKR_TELEM_BUFFER_SOURCES: dict[str, tuple[tuple[str, int], ...]] = {
    "fid": (("akr_walk_fid_buffer", 0), ("akr_cpm_fid_buffer", 0), ("akr_test_fid_buffer", 0)),
    "dt_ms": (("akr_walk_dt_ms_buffer", 0), ("akr_cpm_dt_ms_buffer", 0), ("akr_test_dt_ms_buffer", 0)),
    "exec_ms": (("akr_walk_exec_ms_buffer", 0),),
    "out": (("akr_walk_out_buffer", 0),),
    "state": (("akr_walk_state_buffer", 0),),
    "acc_x": (("akr_walk_acc_buffer", 0),),
    "acc_y": (("akr_walk_acc_buffer", 1),),
    "acc_z": (("akr_walk_acc_buffer", 2),),
    "gyr_x": (("akr_walk_gyr_buffer", 0),),
    "gyr_y": (("akr_walk_gyr_buffer", 1),),
    "gyr_z": (("akr_walk_gyr_buffer", 2),),
    "mag_x": (("akr_walk_mag_buffer", 0),),
    "mag_y": (("akr_walk_mag_buffer", 1),),
    "mag_z": (("akr_walk_mag_buffer", 2),),
    "tilt_forward_deg": (("akr_walk_tilt_forward_deg_buffer", 0),),
    "pos_rad": (("akr_walk_pos_rad_buffer", 0), ("akr_cpm_pos_rad_buffer", 0), ("akr_test_pos_rad_buffer", 0)),
    "vel_rad_s": (("akr_walk_vel_rad_s_buffer", 0), ("akr_cpm_vel_rad_s_buffer", 0), ("akr_test_vel_rad_s_buffer", 0)),
    "tq_nm": (("akr_walk_tq_nm_buffer", 0), ("akr_cpm_tq_nm_buffer", 0), ("akr_test_tq_nm_buffer", 0)),
    "temp_c": (("akr_walk_temp_c_buffer", 0), ("akr_cpm_temp_c_buffer", 0), ("akr_test_temp_c_buffer", 0)),
    "vbus_v": (("akr_walk_vbus_v_buffer", 0), ("akr_cpm_vbus_v_buffer", 0), ("akr_test_vbus_v_buffer", 0)),
    "pattern": (("akr_walk_pattern_buffer", 0), ("akr_cpm_pattern_buffer", 0), ("akr_test_pattern_buffer", 0)),
    "err_code": (("akr_walk_err_code_buffer", 0), ("akr_cpm_err_code_buffer", 0), ("akr_test_err_code_buffer", 0)),
    "fb_age_ms": (("akr_walk_fb_age_ms_buffer", 0), ("akr_cpm_fb_age_ms_buffer", 0), ("akr_test_fb_age_ms_buffer", 0)),
    "cpm_state": (("akr_cpm_state_buffer", 0),),
    "dir": (("akr_cpm_dir_buffer", 0), ("akr_test_dir_buffer", 0)),
    "blocked_event": (("akr_cpm_blocked_event_buffer", 0),),
    "cpm_block_reason": (("akr_cpm_block_reason_buffer", 0),),
    "blocked_consecutive": (("akr_cpm_blocked_consecutive_buffer", 0),),
    "cmd_spd_rad_s": (("akr_cpm_cmd_spd_rad_s_buffer", 0),),
    "df_limit_rad": (("akr_cpm_df_limit_rad_buffer", 0),),
    "pf_limit_rad": (("akr_cpm_pf_limit_rad_buffer", 0),),
    "elapsed_s": (("akr_cpm_elapsed_s_buffer", 0),),
    "remaining_s": (("akr_cpm_remaining_s_buffer", 0),),
    "has_remaining": (("akr_cpm_has_remaining_buffer", 0),),
    "repetition_count": (("akr_cpm_repetition_count_buffer", 0),),
    "measure_state": (("akr_test_state_buffer", 0),),
    "blocked": (("akr_test_blocked_buffer", 0),),
    "result_flags": (("akr_test_result_flags_buffer", 0),),
    "prom_df_end_rad": (("akr_test_prom_df_end_rad_buffer", 0),),
    "prom_pf_end_rad": (("akr_test_prom_pf_end_rad_buffer", 0),),
    "arom_df_max_rad": (("akr_test_arom_df_max_rad_buffer", 0),),
    "arom_pf_min_rad": (("akr_test_arom_pf_min_rad_buffer", 0),),
    "cfg_fid": (("akr_cfg_fid_buffer", 0),),
    "cfg_gait_model": (("akr_cfg_gait_model_buffer", 0),),
    "cfg_gait_mode": (("akr_cfg_gait_mode_buffer", 0),),
    "cfg_side_is_left": (("akr_cfg_side_is_left_buffer", 0),),
    "cfg_df_assist_pct": (("akr_cfg_df_assist_pct_buffer", 0),),
    "cfg_pf_assist_pct": (("akr_cfg_pf_assist_pct_buffer", 0),),
    "cfg_df_torque": (("akr_cfg_df_torque_buffer", 0),),
    "cfg_df_angle": (("akr_cfg_df_angle_buffer", 0),),
    "cfg_df_speed": (("akr_cfg_df_speed_buffer", 0),),
    "cfg_df_kp": (("akr_cfg_df_kp_buffer", 0),),
    "cfg_df_kd": (("akr_cfg_df_kd_buffer", 0),),
    "cfg_pf_torque": (("akr_cfg_pf_torque_buffer", 0),),
    "cfg_pf_angle": (("akr_cfg_pf_angle_buffer", 0),),
    "cfg_pf_speed": (("akr_cfg_pf_speed_buffer", 0),),
    "cfg_pf_kp": (("akr_cfg_pf_kp_buffer", 0),),
    "cfg_pf_kd": (("akr_cfg_pf_kd_buffer", 0),),
    "cfg_cpm_target_df_rad": (("akr_cfg_cpm_target_df_rad_buffer", 0),),
    "cfg_cpm_target_pf_rad": (("akr_cfg_cpm_target_pf_rad_buffer", 0),),
    "cfg_cpm_speed_to_df_rad_s": (("akr_cfg_cpm_speed_to_df_rad_s_buffer", 0),),
    "cfg_cpm_speed_to_pf_rad_s": (("akr_cfg_cpm_speed_to_pf_rad_s_buffer", 0),),
    "cfg_cpm_block_tq_nm": (("akr_cfg_cpm_block_tq_nm_buffer", 0),),
    "cfg_cpm_wait_to_df_ms": (("akr_cfg_cpm_wait_to_df_ms_buffer", 0),),
    "cfg_cpm_wait_to_pf_ms": (("akr_cfg_cpm_wait_to_pf_ms_buffer", 0),),
}

AKR_CLI_PARSED_EXTRA_FIELDS: tuple[str, ...] = (
    "motor_fw_version",
    "rr_akr_flag",
    "rr_cpm_flag",
    "rr_test_flag",
    "zero_sta",
    "zero_position_rad",
)

# Modes exported directly to the Signals chart tile builder.
AKR_CLI_CHART_MODE_DEFS: tuple[tuple[str, str, tuple[str, ...]], ...] = (
    (
        "runtime_motor",
        "Runtime Motor (CLI show)",
        (
            "mech_position_rad",
            "speed_rad_s",
            "torque_nm",
            "temp_c",
            "vbus_v",
            "motor_feedback_age_ms",
            "motor_can_id",
            "motor_pattern",
            "motor_mode_0x7005",
            "motor_error_code",
            "motor_fault_error_code",
        ),
    ),
    (
        "runtime_connectivity",
        "Runtime Connectivity (CLI show)",
        (
            "ble_connected",
            "rf_paired",
            "motor_connected",
            "imu_ok",
            "sound_noncritical",
            "sound_critical",
            "ble_tx_used",
            "ble_tx_peak",
            "ble_tx_enq",
            "ble_tx_drop",
            "rf_key_id",
            "rf_bit_split_us",
        ),
    ),
    (
        "runtime_state",
        "Runtime State (CLI show)",
        (
            "is_left",
            "task_to_test",
            "mode",
            "gait_model",
        ),
    ),
    (
        "telem_core",
        "Telemetry Core",
        (
            "fid",
            "dt_ms",
            "exec_ms",
            "out",
            "state",
            "acc_x",
            "acc_y",
            "acc_z",
            "gyr_x",
            "gyr_y",
            "gyr_z",
            "mag_x",
            "mag_y",
            "mag_z",
            "tilt_forward_deg",
            "pos_rad",
            "vel_rad_s",
            "tq_nm",
            "pattern",
            "err_code",
            "fb_age_ms",
        ),
    ),
    (
        "telem_cpm",
        "Telemetry CPM",
        (
            "cpm_state",
            "dir",
            "blocked_event",
            "cpm_block_reason",
            "blocked_consecutive",
            "block_tq",
            "cpm_exit_state",
            "cmd_spd_rad_s",
            "df_limit_rad",
            "pf_limit_rad",
            "elapsed_s",
            "remaining_s",
            "has_remaining",
            "repetition_count",
        ),
    ),
    (
        "telem_measure",
        "Telemetry Measure",
        (
            "measure_state",
            "blocked",
            "result_flags",
            "prom_df_end_rad",
            "prom_pf_end_rad",
            "arom_df_max_rad",
            "arom_pf_min_rad",
        ),
    ),
    (
        "telem_cfg",
        "Telemetry CFG",
        (
            "cfg_fid",
            "cfg_gait_model",
            "cfg_gait_mode",
            "cfg_side_is_left",
            "cfg_df_assist_pct",
            "cfg_pf_assist_pct",
            "cfg_df_torque",
            "cfg_df_angle",
            "cfg_df_speed",
            "cfg_df_kp",
            "cfg_df_kd",
            "cfg_pf_torque",
            "cfg_pf_angle",
            "cfg_pf_speed",
            "cfg_pf_kp",
            "cfg_pf_kd",
            "cfg_cpm_target_df_rad",
            "cfg_cpm_target_pf_rad",
            "cfg_cpm_speed_to_df_rad_s",
            "cfg_cpm_speed_to_pf_rad_s",
            "cfg_cpm_block_tq_nm",
            "cfg_cpm_wait_to_df_ms",
            "cfg_cpm_wait_to_pf_ms",
        ),
    ),
    (
        "cli_extras",
        "CLI Parser Extras",
        (
            "rr_akr_flag",
            "rr_cpm_flag",
            "rr_test_flag",
            "zero_sta",
            "zero_position_rad",
        ),
    ),
)

AKR_CLI_BOOLEAN_FIELDS: frozenset[str] = frozenset(
    {
        "is_left",
        "motor_connected",
        "imu_ok",
        "ble_connected",
        "rf_paired",
        "sound_noncritical",
        "sound_critical",
        "cfg_side_is_left",
        "blocked",
        "blocked_event",
    }
)

AKR_CLI_DISCRETE_STATUS_FIELDS: frozenset[str] = frozenset(
    {
        "mode",
        "gait_model",
        "task_to_test",
        "state",
        "out",
        "cpm_state",
        "cpm_exit_state",
        "cpm_block_reason",
        "dir",
        "measure_state",
        "result_flags",
        "pattern",
        "err_code",
        "motor_error_code",
        "motor_fault_error_code",
        "motor_mode_0x7005",
        "motor_pattern",
        "rr_akr_flag",
        "rr_cpm_flag",
        "rr_test_flag",
        "zero_sta",
    }
)

AKR_CLI_ENUM_VALUE_MAPS: dict[str, dict[str, float]] = {
    "mode": {"stop": 0.0, "walk": 1.0, "cpm": 2.0, "measure": 3.0, "test": 4.0},
    "task_to_test": {"walk": 1.0, "cpm": 2.0, "measure": 3.0, "test": 4.0},
    "gait_model": {
        "none": 0.0,
        "first_contact": 1.0,
        "loading_response": 2.0,
        "mid_stance": 3.0,
        "terminal_stance": 4.0,
        "pre_swing": 5.0,
        "initial_swing": 6.0,
        "mid_swing": 7.0,
        "terminal_swing": 8.0,
    },
}

_NUMERIC_PREFIX_RE = re.compile(r"^\s*([-+]?(?:\d+(?:\.\d*)?|\.\d+))")


def parse_akr_feedback_numeric_value(key: str, value: object) -> float | None:
    """Convert CLI feedback text values into numeric samples for charting."""
    field = str(key).strip().lower()
    txt = str(value).strip()
    if not field or not txt or txt == "-":
        return None

    low = txt.lower()
    if field in AKR_CLI_BOOLEAN_FIELDS:
        if low in {"1", "true", "yes", "on"}:
            return 1.0
        if low in {"0", "false", "no", "off"}:
            return 0.0

    mapped = AKR_CLI_ENUM_VALUE_MAPS.get(field)
    if mapped is not None and low in mapped:
        return float(mapped[low])

    # The parser can emit hex strings for error/mode fields; preserve numeric meaning.
    if low.startswith("0x"):
        try:
            return float(int(low, 16))
        except Exception:
            return None

    try:
        val = float(txt)
        return val if math.isfinite(val) else None
    except Exception:
        match = _NUMERIC_PREFIX_RE.match(txt)
        if not match:
            return None
        try:
            val = float(match.group(1))
            return val if math.isfinite(val) else None
        except Exception:
            return None
