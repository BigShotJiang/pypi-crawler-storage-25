from __future__ import annotations

from PyQt6 import QtCore, QtWidgets

from ..widgets import MultiSignalPlot, SignalGroupControl


def build_signals_tab(self) -> None:
    """Build the Signals tab UI onto an existing `MainWindow` instance."""
    # --- Signals tab ---
    self.signals_page = QtWidgets.QWidget()
    signals_layout = QtWidgets.QVBoxLayout(self.signals_page)
    signals_layout.setContentsMargins(12, 12, 12, 12)
    signals_layout.setSpacing(10)

    # Signals controls (single plot, multiple traces)
    controls = QtWidgets.QHBoxLayout()
    controls.setContentsMargins(0, 0, 0, 0)
    controls.setSpacing(8)
    self.combo_sig_device = QtWidgets.QComboBox()
    self.combo_sig_device.setMinimumWidth(200)
    self.btn_sig_identify = QtWidgets.QToolButton()
    self.btn_sig_identify.setText(self._t("btn_identify", "Identify"))
    self.btn_sig_identify.setToolTip(
        self._t(
            "tooltip_sig_identify",
            "Identify: light selected device purple briefly (works even while streaming).",
        )
    )
    self.btn_sig_identify.clicked.connect(self._identify_selected_signal_device)
    self.btn_sig_settings = QtWidgets.QToolButton()
    self.btn_sig_settings.setText(self._t("btn_settings", "Settings"))
    self.btn_sig_settings.setToolTip(
        self._t(
            "tooltip_sig_settings",
            "Open Settings for the selected Signals device.",
        )
    )
    self.btn_sig_settings.clicked.connect(self._open_settings_for_signal_device)
    self.combo_sig_device.currentIndexChanged.connect(self._on_signal_device_changed_for_led)
    # Device kind affects which signal types/modes are relevant (e.g., AKR has no EMG).
    self.combo_sig_device.currentIndexChanged.connect(self._populate_signal_type_combo)

    # Signal type (EMG, ACC, etc.)
    self.combo_sig_type = QtWidgets.QComboBox()
    self.combo_sig_type.setMinimumWidth(160)

    # Signal mode (Raw, Calibrated, etc.)
    self.combo_sig_mode = QtWidgets.QComboBox()
    self.combo_sig_mode.setMinimumWidth(160)
    self.combo_sig_mode.setEnabled(False)

    # Signal axis (X, Y, Z, etc.)
    self.combo_sig_axis = QtWidgets.QComboBox()
    # Axis labels can be long (e.g., "Filtered |gyr|"); keep it readable.
    self.combo_sig_axis.setMinimumWidth(160)
    try:
        self.combo_sig_axis.setSizeAdjustPolicy(QtWidgets.QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.combo_sig_axis.setMinimumContentsLength(16)
    except Exception:
        pass
    self.combo_sig_axis.setEnabled(False)

    self._init_signal_presets_map()
    self._populate_signal_type_combo()

    # Connect signals
    self.combo_sig_type.currentIndexChanged.connect(self._on_signal_type_changed)
    self.combo_sig_mode.currentIndexChanged.connect(self._on_signal_mode_changed)

    self.btn_sig_add = QtWidgets.QPushButton(self._t("btn_add", "Add"))
    self.btn_sig_clear = QtWidgets.QPushButton(
        self._t("btn_remove_all", "Remove all")
    )
    self.btn_sig_add.clicked.connect(self._add_trace_from_ui)
    self.btn_sig_clear.clicked.connect(self._remove_all_traces)

    lbl_style = "color: #d7e1ff; font-weight: 600;"
    self.lbl_sig_device = QtWidgets.QLabel(self._t("label_device", "Device"))
    self.lbl_sig_device.setStyleSheet(lbl_style)
    self.lbl_sig_signal = QtWidgets.QLabel(self._t("label_signal", "Signal"))
    self.lbl_sig_signal.setStyleSheet(lbl_style)

    controls.addWidget(self.lbl_sig_device)
    controls.addWidget(self.combo_sig_device, 0)
    controls.addWidget(self.btn_sig_identify)
    controls.addWidget(self.btn_sig_settings)

    # Visual separator so "Device" and "Signal" read as distinct groups.
    sep = QtWidgets.QFrame()
    sep.setFrameShape(QtWidgets.QFrame.Shape.VLine)
    sep.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
    sep.setStyleSheet("color: #22306b; background: #22306b;")
    controls.addSpacing(6)
    controls.addWidget(sep)
    controls.addSpacing(10)

    controls.addWidget(self.lbl_sig_signal)
    controls.addWidget(self.combo_sig_type, 0)
    controls.addWidget(self.combo_sig_mode, 0)
    controls.addWidget(self.combo_sig_axis, 0)
    controls.addStretch(1)
    controls.addWidget(self.btn_sig_add)
    controls.addWidget(self.btn_sig_clear)

    signals_layout.addLayout(controls)

    # Signals plot uses per-device origins (handled in data providers), so no global origin here.
    self.multi_plot = MultiSignalPlot(time_origin_s_provider=None)
    # Right panel: up to 3 per-group control widgets (cluster settings).
    self._sig_group_controls: dict[str, SignalGroupControl] = {}
    self.sig_group_panel = QtWidgets.QScrollArea()
    self.sig_group_panel.setWidgetResizable(True)
    self.sig_group_panel.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
    self.sig_group_panel.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    self.sig_group_panel.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    self.sig_group_panel_inner = QtWidgets.QWidget()
    self.sig_group_panel_layout = QtWidgets.QVBoxLayout(self.sig_group_panel_inner)
    self.sig_group_panel_layout.setContentsMargins(0, 0, 0, 0)
    self.sig_group_panel_layout.setSpacing(10)
    self.sig_group_panel_layout.addStretch(1)
    self.sig_group_panel.setWidget(self.sig_group_panel_inner)
    self.sig_group_panel.setMinimumWidth(320)

    split = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
    split.addWidget(self.multi_plot)
    split.addWidget(self.sig_group_panel)
    split.setStretchFactor(0, 5)
    split.setStretchFactor(1, 1)
    signals_layout.addWidget(split, 1)

    # Bottom-right controls: stream + RX status
    footer = QtWidgets.QHBoxLayout()
    footer.setContentsMargins(0, 0, 0, 0)
    footer.setSpacing(10)
    self.lbl_sig_session = QtWidgets.QLabel(self._t("session_idle", "Session: IDLE"))
    self.lbl_sig_session.setStyleSheet("color: #9fb2e8; font-weight: 600;")
    footer.addWidget(self.lbl_sig_session, 0)
    footer.addStretch(1)

    self.btn_sig_freeze = QtWidgets.QToolButton()
    self.btn_sig_freeze.setText(self._t("btn_freeze", "Freeze"))
    self.btn_sig_freeze.setCheckable(True)
    self.btn_sig_freeze.setToolTip(
        self._t(
            "tooltip_freeze",
            "Freeze: pauses plot updates only (stream continues).",
        )
    )
    self.btn_sig_freeze.toggled.connect(self._set_plot_frozen)
    self.btn_sig_connect = QtWidgets.QToolButton()
    # Shadow Connect-tab action so users can reconnect without leaving Signals.
    self.btn_sig_connect.setDefaultAction(self.action_connect)
    self.btn_sig_connect.setToolTip(
        self._t(
            "tooltip_sig_connect",
            "Connect selected devices from the Connect tab selection.",
        )
    )
    self.btn_sig_preset_load = QtWidgets.QToolButton()
    self.btn_sig_preset_load.setText(self._t("btn_load_preset", "Load Preset…"))
    self.btn_sig_preset_load.setToolTip(
        self._t(
            "tooltip_load_preset",
            "Load a Signals preset profile from a JSON file.",
        )
    )
    self.btn_sig_preset_load.clicked.connect(self._signals_preset_load_clicked)
    self.btn_sig_preset_save = QtWidgets.QToolButton()
    self.btn_sig_preset_save.setText(self._t("btn_save_preset", "Save Preset…"))
    self.btn_sig_preset_save.setToolTip(
        self._t(
            "tooltip_save_preset",
            "Save the current Signals tiles and styles to a JSON file.",
        )
    )
    self.btn_sig_preset_save.clicked.connect(self._signals_preset_save_clicked)

    self.btn_sig_reset = QtWidgets.QPushButton(self._t("btn_reset", "Reset"))
    self.btn_sig_reset.setToolTip(
        self._t(
            "tooltip_sig_reset",
            "Reset processed-data buffers/state (envelope, MDF/MNF, fatigue baseline) without restarting streaming.",
        )
    )
    self.btn_sig_reset.clicked.connect(self._signals_reset_processed)

    self.btn_sig_record_start = QtWidgets.QPushButton(
        self._t("btn_start_record", "Start Record")
    )
    self.btn_sig_record_stop = QtWidgets.QPushButton(
        self._t("btn_stop_record", "Stop Record")
    )
    self.btn_sig_record_start.setToolTip(
        self._t(
            "tooltip_start_record",
            "Start recording streamed data to CSV files (EMG + IMU).",
        )
    )
    self.btn_sig_record_stop.setToolTip(
        self._t(
            "tooltip_stop_record",
            "Stop recording and close CSV files.",
        )
    )
    self.btn_sig_record_start.clicked.connect(self._signals_start_record)
    self.btn_sig_record_stop.clicked.connect(self._signals_stop_record)

    self.btn_sig_stream_start = QtWidgets.QPushButton(
        self._t("btn_start_stream", "Start Stream")
    )
    self.btn_sig_stream_stop = QtWidgets.QPushButton(
        self._t("btn_stop_stream", "Stop Stream")
    )
    self.btn_sig_stream_start.clicked.connect(lambda: self._signals_stream_plotted(True))
    self.btn_sig_stream_stop.clicked.connect(lambda: self._signals_stream_plotted(False))
    footer.addWidget(self.btn_sig_connect)
    footer.addWidget(self.btn_sig_preset_load)
    footer.addWidget(self.btn_sig_preset_save)
    footer.addWidget(self.btn_sig_freeze)
    footer.addWidget(self.btn_sig_reset)
    footer.addWidget(self.btn_sig_record_start)
    footer.addWidget(self.btn_sig_record_stop)
    footer.addWidget(self.btn_sig_stream_start)
    footer.addWidget(self.btn_sig_stream_stop)
    signals_layout.addLayout(footer)
    self.tabs.addTab(self.signals_page, self._t("tab_signals", "Signals"))


def retranslate_signals_tab(self) -> None:
    self.btn_sig_identify.setText(self._t("btn_identify", "Identify"))
    self.btn_sig_identify.setToolTip(
        self._t(
            "tooltip_sig_identify",
            "Identify: light selected device purple briefly (works even while streaming).",
        )
    )
    self.btn_sig_settings.setText(self._t("btn_settings", "Settings"))
    self.btn_sig_settings.setToolTip(
        self._t(
            "tooltip_sig_settings",
            "Open Settings for the selected Signals device.",
        )
    )
    self.btn_sig_add.setText(self._t("btn_add", "Add"))
    self.btn_sig_clear.setText(self._t("btn_remove_all", "Remove all"))
    self.lbl_sig_device.setText(self._t("label_device", "Device"))
    self.lbl_sig_signal.setText(self._t("label_signal", "Signal"))
    self.btn_sig_freeze.setText(
        self._t("btn_frozen", "Frozen")
        if bool(getattr(self, "_plot_frozen", False))
        else self._t("btn_freeze", "Freeze")
    )
    self.btn_sig_freeze.setToolTip(
        self._t(
            "tooltip_freeze",
            "Freeze: pauses plot updates only (stream continues).",
        )
    )
    self.btn_sig_connect.setToolTip(
        self._t(
            "tooltip_sig_connect",
            "Connect selected devices from the Connect tab selection.",
        )
    )
    self.btn_sig_preset_load.setText(self._t("btn_load_preset", "Load Preset…"))
    self.btn_sig_preset_load.setToolTip(
        self._t(
            "tooltip_load_preset",
            "Load a Signals preset profile from a JSON file.",
        )
    )
    self.btn_sig_preset_save.setText(self._t("btn_save_preset", "Save Preset…"))
    self.btn_sig_preset_save.setToolTip(
        self._t(
            "tooltip_save_preset",
            "Save the current Signals tiles and styles to a JSON file.",
        )
    )
    self.btn_sig_reset.setText(self._t("btn_reset", "Reset"))
    self.btn_sig_reset.setToolTip(
        self._t(
            "tooltip_sig_reset",
            "Reset processed-data buffers/state (envelope, MDF/MNF, fatigue baseline) without restarting streaming.",
        )
    )
    self.btn_sig_record_start.setText(self._t("btn_start_record", "Start Record"))
    self.btn_sig_record_stop.setText(self._t("btn_stop_record", "Stop Record"))
    self.btn_sig_record_start.setToolTip(
        self._t(
            "tooltip_start_record",
            "Start recording streamed data to CSV files (EMG + IMU).",
        )
    )
    self.btn_sig_record_stop.setToolTip(
        self._t(
            "tooltip_stop_record",
            "Stop recording and close CSV files.",
        )
    )
    self.btn_sig_stream_start.setText(self._t("btn_start_stream", "Start Stream"))
    self.btn_sig_stream_stop.setText(self._t("btn_stop_stream", "Stop Stream"))
    self._update_signal_rx_status()

