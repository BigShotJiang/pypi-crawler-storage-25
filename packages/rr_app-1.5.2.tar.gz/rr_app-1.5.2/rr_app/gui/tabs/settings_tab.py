from __future__ import annotations

import sys
from pathlib import Path

from PyQt6 import QtCore, QtGui, QtWidgets

from ... import config


def build_settings_tab(self) -> None:
    """Build the Settings tab UI onto an existing `MainWindow` instance."""
    # --- Settings tab ---
    self.settings_page = QtWidgets.QWidget()
    settings_layout = QtWidgets.QVBoxLayout(self.settings_page)
    settings_layout.setContentsMargins(12, 12, 12, 12)
    settings_layout.setSpacing(12)

    # Info paragraph removed (was mainly developer-facing).
    self.lbl_settings_info = QtWidgets.QLabel("")

    # --- Save / Load Profile (top of Settings page) ---
    self.grp_profile = QtWidgets.QGroupBox(
        self._t("settings_group_profile", "Save / Load Profile")
    )
    prof_l = QtWidgets.QHBoxLayout(self.grp_profile)
    prof_l.setContentsMargins(10, 10, 10, 10)
    prof_l.setSpacing(8)
    self.edit_profile_path = QtWidgets.QLineEdit()
    self.edit_profile_path.setPlaceholderText(
        self._t("profile_path_placeholder", "Profile file path (.json)")
    )
    self.btn_profile_load = QtWidgets.QPushButton(self._t("btn_load", "Load…"))
    self.btn_profile_save = QtWidgets.QPushButton(self._t("btn_save", "Save…"))
    self.btn_profile_reset = QtWidgets.QPushButton(self._t("btn_reset", "Reset"))
    prof_l.addWidget(self.edit_profile_path, 1)
    prof_l.addWidget(self.btn_profile_load)
    prof_l.addWidget(self.btn_profile_save)
    prof_l.addWidget(self.btn_profile_reset)

    self.btn_profile_load.clicked.connect(self._profile_load_clicked)
    self.btn_profile_save.clicked.connect(self._profile_save_clicked)
    self.btn_profile_reset.clicked.connect(self._profile_reset_clicked)

    self.grp_processed = QtWidgets.QGroupBox(
        self._t("settings_group_processed", "Processed Data")
    )
    grp_layout = QtWidgets.QVBoxLayout(self.grp_processed)
    grp_layout.setContentsMargins(10, 10, 10, 10)
    grp_layout.setSpacing(8)

    form = QtWidgets.QFormLayout()
    form.setContentsMargins(0, 0, 0, 0)
    form.setHorizontalSpacing(12)
    form.setVerticalSpacing(8)
    # Let the right/field column actually grow with available width.
    # Without this, word-wrapped hint labels can get a narrow width and wrap early.
    form.setFieldGrowthPolicy(QtWidgets.QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)

    def _hint(txt: str) -> QtWidgets.QLabel:
        lab = QtWidgets.QLabel(txt)
        lab.setWordWrap(True)
        lab.setStyleSheet("color: #9fb2e8; font-size: 11px;")
        lab.setMinimumWidth(0)
        lab.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Preferred)
        return lab

    def _heading(txt: str) -> QtWidgets.QLabel:
        lab = QtWidgets.QLabel(txt)
        f = QtGui.QFont(lab.font())
        f.setBold(True)
        # Make headings visually distinct without being huge.
        f.setPointSize(max(12, int(f.pointSize() if f.pointSize() > 0 else 11) + 2))
        lab.setFont(f)
        lab.setStyleSheet("color: #d7e1ff;")
        lab.setWordWrap(True)
        return lab

    def _req(txt: str) -> QtWidgets.QLabel:
        """Important requirements (shown in red) for enabling processed signals."""
        lab = QtWidgets.QLabel(txt)
        lab.setWordWrap(True)
        lab.setStyleSheet("color: #ff4757; font-weight: 800; font-size: 11px;")
        lab.setMinimumWidth(0)
        lab.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Preferred)
        return lab

    def _row_with_hint(w: QtWidgets.QWidget, hint_txt: str) -> tuple[QtWidgets.QWidget, QtWidgets.QLabel]:
        wrap = QtWidgets.QWidget()
        wrap.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding, QtWidgets.QSizePolicy.Policy.Preferred)
        # Stack hint below the control so the hint can use the full field width
        # (prevents early wrapping caused by long control text, e.g. checkboxes).
        l = QtWidgets.QVBoxLayout(wrap)
        l.setContentsMargins(0, 0, 0, 0)
        l.setSpacing(2)
        l.addWidget(w)
        hint_label = _hint(hint_txt)
        l.addWidget(hint_label)
        return wrap, hint_label

    self.lbl_proc_heading_emg_analysis = _heading(
        self._t("settings_heading_emg_analysis", "— EMG Analysis —")
    )
    form.addRow(self.lbl_proc_heading_emg_analysis)
    self.lbl_proc_req_emg_raw_envelope = _req(
        self._t(
            "settings_req_emg_raw_envelope",
            "Requires: EMG RAW streaming enabled on the device (processed EMG is computed from raw EMG samples).",
        )
    )
    form.addRow(self.lbl_proc_req_emg_raw_envelope)

    self.chk_proc_emg_env = QtWidgets.QCheckBox(
        self._t("settings_chk_emg_rms_envelope", "Enable EMG RMS Envelope")
    )
    self.chk_proc_emg_env.setToolTip(
        self._t(
            "tooltip_settings_chk_emg_rms_envelope",
            "When enabled, the next streaming session will compute EMG RMS envelope data.",
        )
    )
    self.chk_proc_emg_env.setChecked(bool(getattr(self.controller.manager, "proc_enable_emg_rms_envelope_next", False)))
    self.chk_proc_emg_env.toggled.connect(self._on_proc_settings_changed)
    self.row_proc_emg_env_wrap, self.lbl_proc_hint_emg_env = _row_with_hint(
        self.chk_proc_emg_env,
        self._t(
            "settings_hint_emg_rms_envelope",
            "Computes a smoothed RMS envelope over raw EMG samples (next session).",
        ),
    )
    form.addRow("", self.row_proc_emg_env_wrap)

    self.spin_proc_emg_env_win = QtWidgets.QSpinBox()
    self.spin_proc_emg_env_win.setRange(10, 5000)
    self.spin_proc_emg_env_win.setSingleStep(10)
    self.spin_proc_emg_env_win.setSuffix(self._t("suffix_samples", " samples"))
    self.spin_proc_emg_env_win.setToolTip(
        self._t(
            "tooltip_settings_rms_window",
            "RMS envelope window length in samples (latched next session).",
        )
    )
    self.spin_proc_emg_env_win.setValue(int(getattr(self.controller.manager, "proc_emg_rms_window_n_next", config.EMG_RMS_WINDOW_N)))
    self.spin_proc_emg_env_win.valueChanged.connect(self._on_proc_settings_changed)
    self.lbl_proc_rms_window = QtWidgets.QLabel(
        self._t("settings_label_rms_window", "RMS window")
    )
    self.row_proc_rms_window_wrap, self.lbl_proc_hint_rms_window = _row_with_hint(
        self.spin_proc_emg_env_win,
        self._t(
            "settings_hint_rms_window",
            "Number of samples used in RMS envelope. Larger = smoother but slower response.",
        ),
    )
    form.addRow(self.lbl_proc_rms_window, self.row_proc_rms_window_wrap)

    self.chk_proc_emg_freq = QtWidgets.QCheckBox(
        self._t(
            "settings_chk_emg_freq_features",
            "Enable EMG Frequency Features (MDF/MNF)",
        )
    )
    self.chk_proc_emg_freq.setToolTip(
        self._t(
            "tooltip_settings_chk_emg_freq_features",
            "When enabled, the next streaming session will compute median/mean frequency and spectra.",
        )
    )
    self.chk_proc_emg_freq.setChecked(bool(getattr(self.controller.manager, "proc_enable_emg_freq_features_next", False)))
    self.chk_proc_emg_freq.toggled.connect(self._on_proc_settings_changed)
    self.row_proc_emg_freq_wrap, self.lbl_proc_hint_emg_freq = _row_with_hint(
        self.chk_proc_emg_freq,
        self._t(
            "settings_hint_emg_freq_features",
            "Computes MDF/MNF from a windowed FFT over the last N raw EMG samples (next session).",
        ),
    )
    form.addRow("", self.row_proc_emg_freq_wrap)

    self.spin_proc_emg_spec_win = QtWidgets.QSpinBox()
    self.spin_proc_emg_spec_win.setRange(128, 10000)
    self.spin_proc_emg_spec_win.setSingleStep(100)
    self.spin_proc_emg_spec_win.setSuffix(self._t("suffix_samples", " samples"))
    self.spin_proc_emg_spec_win.setToolTip(
        self._t(
            "tooltip_settings_fft_window",
            "Spectral window length in samples (latched next session).",
        )
    )
    self.spin_proc_emg_spec_win.setValue(int(getattr(self.controller.manager, "proc_emg_spec_window_n_next", getattr(config, "EMG_SPEC_WINDOW_N", 1000))))
    self.spin_proc_emg_spec_win.valueChanged.connect(self._on_proc_settings_changed)
    self.lbl_proc_fft_window = QtWidgets.QLabel(
        self._t("settings_label_fft_window", "FFT window")
    )
    self.row_proc_fft_window_wrap, self.lbl_proc_hint_fft_window = _row_with_hint(
        self.spin_proc_emg_spec_win,
        self._t(
            "settings_hint_fft_window",
            "FFT window length in samples. Larger = better frequency resolution, slower updates.",
        ),
    )
    form.addRow(self.lbl_proc_fft_window, self.row_proc_fft_window_wrap)

    # --- Fatigue (unsupervised) ---
    self.lbl_proc_heading_fatigue = _heading(
        self._t("settings_heading_fatigue", "— Fatigue (unsupervised) —")
    )
    form.addRow(self.lbl_proc_heading_fatigue)
    self.lbl_proc_req_fatigue = _req(
        self._t(
            "settings_req_fatigue",
            'Requires: Enable "EMG Frequency Features (MDF/MNF)" + EMG RAW streaming (fatigue uses MDF + RMS trend).',
        )
    )
    form.addRow(self.lbl_proc_req_fatigue)

    self.chk_proc_emg_fatigue = QtWidgets.QCheckBox(
        self._t("settings_chk_fatigue_score", "Enable fatigue score (heuristic)")
    )
    self.chk_proc_emg_fatigue.setToolTip(
        self._t(
            "tooltip_settings_chk_fatigue_score",
            "Computes a 0..1 fatigue score from MDF drop + RMS rise (requires EMG Frequency Features). This is NOT a calibrated probability.",
        )
    )
    self.chk_proc_emg_fatigue.setChecked(bool(getattr(self.controller.manager, "proc_enable_emg_fatigue_next", getattr(config, "EMG_FATIGUE_ENABLE_DEFAULT", False))))
    self.chk_proc_emg_fatigue.toggled.connect(self._on_proc_settings_changed)
    self.row_proc_fatigue_wrap, self.lbl_proc_hint_fatigue = _row_with_hint(
        self.chk_proc_emg_fatigue,
        self._t(
            "settings_hint_fatigue_score",
            "Heuristic fatigue score from MDF drop + RMS rise (not a calibrated probability).",
        ),
    )
    form.addRow("", self.row_proc_fatigue_wrap)

    self.spin_proc_emg_fatigue_baseline_s = QtWidgets.QDoubleSpinBox()
    self.spin_proc_emg_fatigue_baseline_s.setDecimals(1)
    self.spin_proc_emg_fatigue_baseline_s.setRange(1.0, 120.0)
    self.spin_proc_emg_fatigue_baseline_s.setSingleStep(1.0)
    self.spin_proc_emg_fatigue_baseline_s.setSuffix(self._t("suffix_seconds", " s"))
    self.spin_proc_emg_fatigue_baseline_s.setToolTip(
        self._t(
            "tooltip_settings_fatigue_baseline",
            "Baseline duration (first N seconds) used to estimate non-fatigued MDF/RMS.",
        )
    )
    self.spin_proc_emg_fatigue_baseline_s.setValue(float(getattr(self.controller.manager, "proc_emg_fatigue_baseline_s_next", getattr(config, "EMG_FATIGUE_BASELINE_S", 10.0))))
    self.spin_proc_emg_fatigue_baseline_s.valueChanged.connect(self._on_proc_settings_changed)
    self.lbl_proc_fatigue_baseline = QtWidgets.QLabel(
        self._t("settings_label_fatigue_baseline", "Baseline")
    )
    self.row_proc_fatigue_baseline_wrap, self.lbl_proc_hint_fatigue_baseline = _row_with_hint(
        self.spin_proc_emg_fatigue_baseline_s,
        self._t(
            "settings_hint_fatigue_baseline",
            "First N seconds used to define the non-fatigued reference level.",
        ),
    )
    form.addRow(self.lbl_proc_fatigue_baseline, self.row_proc_fatigue_baseline_wrap)

    self.spin_proc_emg_fatigue_w_mdf = QtWidgets.QDoubleSpinBox()
    self.spin_proc_emg_fatigue_w_mdf.setDecimals(1)
    self.spin_proc_emg_fatigue_w_mdf.setRange(0.0, 100.0)
    self.spin_proc_emg_fatigue_w_mdf.setSingleStep(5.0)
    self.spin_proc_emg_fatigue_w_mdf.setSuffix(self._t("suffix_percent", " %"))
    self.spin_proc_emg_fatigue_w_mdf.setToolTip(
        self._t(
            "tooltip_settings_fatigue_weight_mdf",
            "Weight for MDF drop contribution (percent; weights are normalized internally).",
        )
    )
    self.spin_proc_emg_fatigue_w_mdf.setValue(float(getattr(self.controller.manager, "proc_emg_fatigue_weight_mdf_pct_next", getattr(config, "EMG_FATIGUE_WEIGHT_MDF_PCT", 70.0))))
    self.spin_proc_emg_fatigue_w_mdf.valueChanged.connect(self._on_proc_settings_changed)
    self.lbl_proc_fatigue_weight_mdf = QtWidgets.QLabel(
        self._t("settings_label_fatigue_weight_mdf", "Weight MDF")
    )
    self.row_proc_fatigue_weight_mdf_wrap, self.lbl_proc_hint_fatigue_weight_mdf = _row_with_hint(
        self.spin_proc_emg_fatigue_w_mdf,
        self._t(
            "settings_hint_fatigue_weight_mdf",
            "Relative weight of MDF drop in the fatigue score.",
        ),
    )
    form.addRow(self.lbl_proc_fatigue_weight_mdf, self.row_proc_fatigue_weight_mdf_wrap)

    self.spin_proc_emg_fatigue_w_rms = QtWidgets.QDoubleSpinBox()
    self.spin_proc_emg_fatigue_w_rms.setDecimals(1)
    self.spin_proc_emg_fatigue_w_rms.setRange(0.0, 100.0)
    self.spin_proc_emg_fatigue_w_rms.setSingleStep(5.0)
    self.spin_proc_emg_fatigue_w_rms.setSuffix(self._t("suffix_percent", " %"))
    self.spin_proc_emg_fatigue_w_rms.setToolTip(
        self._t(
            "tooltip_settings_fatigue_weight_rms",
            "Weight for RMS rise contribution (percent; weights are normalized internally).",
        )
    )
    self.spin_proc_emg_fatigue_w_rms.setValue(float(getattr(self.controller.manager, "proc_emg_fatigue_weight_rms_pct_next", getattr(config, "EMG_FATIGUE_WEIGHT_RMS_PCT", 30.0))))
    self.spin_proc_emg_fatigue_w_rms.valueChanged.connect(self._on_proc_settings_changed)
    self.lbl_proc_fatigue_weight_rms = QtWidgets.QLabel(
        self._t("settings_label_fatigue_weight_rms", "Weight RMS")
    )
    self.row_proc_fatigue_weight_rms_wrap, self.lbl_proc_hint_fatigue_weight_rms = _row_with_hint(
        self.spin_proc_emg_fatigue_w_rms,
        self._t(
            "settings_hint_fatigue_weight_rms",
            "Relative weight of RMS rise in the fatigue score.",
        ),
    )
    form.addRow(self.lbl_proc_fatigue_weight_rms, self.row_proc_fatigue_weight_rms_wrap)

    self.spin_proc_emg_fatigue_conf_n = QtWidgets.QSpinBox()
    self.spin_proc_emg_fatigue_conf_n.setRange(5, 500)
    self.spin_proc_emg_fatigue_conf_n.setSingleStep(5)
    self.spin_proc_emg_fatigue_conf_n.setSuffix(self._t("suffix_updates", " updates"))
    self.spin_proc_emg_fatigue_conf_n.setToolTip(
        self._t(
            "tooltip_settings_fatigue_conf_window",
            "Confidence uses MDF monotonicity over the last N feature updates.",
        )
    )
    self.spin_proc_emg_fatigue_conf_n.setValue(int(getattr(self.controller.manager, "proc_emg_fatigue_conf_recent_n_next", getattr(config, "EMG_FATIGUE_CONF_RECENT_N", 60))))
    self.spin_proc_emg_fatigue_conf_n.valueChanged.connect(self._on_proc_settings_changed)
    self.lbl_proc_fatigue_conf_window = QtWidgets.QLabel(
        self._t("settings_label_fatigue_conf_window", "Confidence window")
    )
    self.row_proc_fatigue_conf_window_wrap, self.lbl_proc_hint_fatigue_conf_window = _row_with_hint(
        self.spin_proc_emg_fatigue_conf_n,
        self._t(
            "settings_hint_fatigue_conf_window",
            "N most recent feature updates used to compute confidence.",
        ),
    )
    form.addRow(self.lbl_proc_fatigue_conf_window, self.row_proc_fatigue_conf_window_wrap)

    # --- Respiratory EMG: ECG artifact reduction ---
    self.lbl_proc_heading_resp_emg_ecg = _heading(
        self._t("settings_heading_resp_emg_ecg", "— Respiratory EMG (ECG artifact) —")
    )
    form.addRow(self.lbl_proc_heading_resp_emg_ecg)
    self.lbl_proc_req_resp_emg_ecg = _req(
        self._t(
            "settings_req_resp_emg_ecg",
            "Requires: EMG RAW streaming enabled on the device (filtering is host-side and applies next session).",
        )
    )
    form.addRow(self.lbl_proc_req_resp_emg_ecg)

    self.chk_proc_emg_ecg_filter = QtWidgets.QCheckBox(
        self._t("settings_chk_emg_ecg_filter", "Enable ECG artifact reduction")
    )
    self.chk_proc_emg_ecg_filter.setToolTip(
        self._t(
            "tooltip_settings_chk_emg_ecg_filter",
            "Reduces ECG contamination in respiratory EMG (upper chest / lower rib cage). Recommended for breathing-muscle channels.",
        )
    )
    self.chk_proc_emg_ecg_filter.setChecked(bool(getattr(self.controller.manager, "proc_enable_emg_ecg_filter_next", getattr(config, "EMG_ECG_FILTER_ENABLE_DEFAULT", False))))
    self.chk_proc_emg_ecg_filter.toggled.connect(self._on_proc_settings_changed)
    self.row_proc_emg_ecg_filter_wrap, self.lbl_proc_hint_emg_ecg_filter = _row_with_hint(
        self.chk_proc_emg_ecg_filter,
        self._t(
            "settings_hint_emg_ecg_filter",
            "Recommended: high-pass for live use; wavelet for cleaner post-review.",
        ),
    )
    form.addRow("", self.row_proc_emg_ecg_filter_wrap)

    self.combo_proc_emg_ecg_method = QtWidgets.QComboBox()
    self.combo_proc_emg_ecg_method.addItem(
        self._t("settings_method_highpass", "Adaptive high-pass (recommended)"),
        "highpass",
    )
    self.combo_proc_emg_ecg_method.addItem(
        self._t("settings_method_wavelet", "Wavelet soft-threshold (experimental)"),
        "wavelet",
    )
    self.combo_proc_emg_ecg_method.setToolTip(
        self._t(
            "tooltip_settings_ecg_method",
            "Method used to suppress ECG from respiratory EMG.",
        )
    )
    method_next = str(getattr(self.controller.manager, "proc_emg_ecg_filter_method_next", getattr(config, "EMG_ECG_FILTER_METHOD_DEFAULT", "highpass"))).strip().lower()
    idx_method = max(0, self.combo_proc_emg_ecg_method.findData(method_next))
    self.combo_proc_emg_ecg_method.setCurrentIndex(idx_method)
    self.combo_proc_emg_ecg_method.currentIndexChanged.connect(self._on_proc_settings_changed)
    self.lbl_proc_ecg_method = QtWidgets.QLabel(
        self._t("settings_label_ecg_method", "Method")
    )
    self.row_proc_ecg_method_wrap, self.lbl_proc_hint_ecg_method = _row_with_hint(
        self.combo_proc_emg_ecg_method,
        self._t(
            "settings_hint_ecg_method",
            "High-pass is lower latency; wavelet can better suppress QRS morphology.",
        ),
    )
    form.addRow(self.lbl_proc_ecg_method, self.row_proc_ecg_method_wrap)

    self.spin_proc_emg_ecg_hp_cutoff_hz = QtWidgets.QDoubleSpinBox()
    self.spin_proc_emg_ecg_hp_cutoff_hz.setDecimals(1)
    self.spin_proc_emg_ecg_hp_cutoff_hz.setRange(5.0, 120.0)
    self.spin_proc_emg_ecg_hp_cutoff_hz.setSingleStep(1.0)
    self.spin_proc_emg_ecg_hp_cutoff_hz.setSuffix(self._t("suffix_hz", " Hz"))
    self.spin_proc_emg_ecg_hp_cutoff_hz.setToolTip(
        self._t(
            "tooltip_settings_ecg_hp_cutoff",
            "High-pass cutoff for ECG suppression (higher cutoff removes more ECG and low-frequency EMG).",
        )
    )
    self.spin_proc_emg_ecg_hp_cutoff_hz.setValue(float(getattr(self.controller.manager, "proc_emg_ecg_hp_cutoff_hz_next", getattr(config, "EMG_ECG_FILTER_HP_CUTOFF_HZ", 25.0))))
    self.spin_proc_emg_ecg_hp_cutoff_hz.valueChanged.connect(self._on_proc_settings_changed)
    self.lbl_proc_ecg_hp_cutoff = QtWidgets.QLabel(
        self._t("settings_label_ecg_hp_cutoff", "HP cutoff")
    )
    self.row_proc_ecg_hp_cutoff_wrap, self.lbl_proc_hint_ecg_hp_cutoff = _row_with_hint(
        self.spin_proc_emg_ecg_hp_cutoff_hz,
        self._t(
            "settings_hint_ecg_hp_cutoff",
            "Typical respiratory EMG range: 20–35 Hz cutoff; start near 25 Hz.",
        ),
    )
    form.addRow(self.lbl_proc_ecg_hp_cutoff, self.row_proc_ecg_hp_cutoff_wrap)

    self.spin_proc_emg_ecg_wavelet_levels = QtWidgets.QSpinBox()
    self.spin_proc_emg_ecg_wavelet_levels.setRange(1, 8)
    self.spin_proc_emg_ecg_wavelet_levels.setSingleStep(1)
    self.spin_proc_emg_ecg_wavelet_levels.setToolTip(
        self._t(
            "tooltip_settings_ecg_wavelet_levels",
            "Wavelet decomposition levels (higher can remove more ECG morphology).",
        )
    )
    self.spin_proc_emg_ecg_wavelet_levels.setValue(int(getattr(self.controller.manager, "proc_emg_ecg_wavelet_levels_next", getattr(config, "EMG_ECG_FILTER_WAVELET_LEVELS", 4))))
    self.spin_proc_emg_ecg_wavelet_levels.valueChanged.connect(self._on_proc_settings_changed)
    self.lbl_proc_ecg_wavelet_levels = QtWidgets.QLabel(
        self._t("settings_label_ecg_wavelet_levels", "Wavelet levels")
    )
    self.row_proc_ecg_wavelet_levels_wrap, self.lbl_proc_hint_ecg_wavelet_levels = _row_with_hint(
        self.spin_proc_emg_ecg_wavelet_levels,
        self._t("settings_hint_ecg_wavelet_levels", "Used when method is wavelet."),
    )
    form.addRow(self.lbl_proc_ecg_wavelet_levels, self.row_proc_ecg_wavelet_levels_wrap)

    self.spin_proc_emg_ecg_wavelet_shrink = QtWidgets.QDoubleSpinBox()
    self.spin_proc_emg_ecg_wavelet_shrink.setDecimals(2)
    self.spin_proc_emg_ecg_wavelet_shrink.setRange(0.1, 5.0)
    self.spin_proc_emg_ecg_wavelet_shrink.setSingleStep(0.1)
    self.spin_proc_emg_ecg_wavelet_shrink.setToolTip(
        self._t(
            "tooltip_settings_ecg_wavelet_shrink",
            "Wavelet shrink factor (higher = stronger denoise).",
        )
    )
    self.spin_proc_emg_ecg_wavelet_shrink.setValue(float(getattr(self.controller.manager, "proc_emg_ecg_wavelet_shrink_next", getattr(config, "EMG_ECG_FILTER_WAVELET_SHRINK", 1.0))))
    self.spin_proc_emg_ecg_wavelet_shrink.valueChanged.connect(self._on_proc_settings_changed)
    self.lbl_proc_ecg_wavelet_shrink = QtWidgets.QLabel(
        self._t("settings_label_ecg_wavelet_shrink", "Wavelet shrink")
    )
    self.row_proc_ecg_wavelet_shrink_wrap, self.lbl_proc_hint_ecg_wavelet_shrink = _row_with_hint(
        self.spin_proc_emg_ecg_wavelet_shrink,
        self._t(
            "settings_hint_ecg_wavelet_shrink",
            "Used when method is wavelet; increase if ECG peaks remain visible.",
        ),
    )
    form.addRow(self.lbl_proc_ecg_wavelet_shrink, self.row_proc_ecg_wavelet_shrink_wrap)
    # Wrap the long processed-data panel in a scroll area so the Settings page doesn't grow taller.
    self.lbl_proc_note = QtWidgets.QLabel(
        self._t(
            "settings_note_processed_next_session",
            "Note: changes apply next session; stop streaming to change.",
        )
    )
    self.lbl_proc_note.setStyleSheet("color: #9fb2e8;")

    proc_scroll = QtWidgets.QScrollArea()
    proc_scroll.setWidgetResizable(True)
    proc_scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)

    proc_inner = QtWidgets.QWidget()
    proc_inner_l = QtWidgets.QVBoxLayout(proc_inner)
    proc_inner_l.setContentsMargins(0, 0, 0, 0)
    proc_inner_l.setSpacing(8)
    proc_inner_l.addLayout(form)
    proc_inner_l.addWidget(self.lbl_proc_note)
    proc_inner_l.addStretch(1)
    proc_scroll.setWidget(proc_inner)

    grp_layout.addWidget(proc_scroll, 1)

    # --- Recording Data (right panel on Settings page) ---
    self.grp_recording = QtWidgets.QGroupBox(
        self._t("settings_group_recording", "Recording Data")
    )
    rec_layout = QtWidgets.QVBoxLayout(self.grp_recording)
    rec_layout.setContentsMargins(10, 10, 10, 10)
    rec_layout.setSpacing(8)

    # Target folder row
    row_dir = QtWidgets.QWidget()
    row_dir_l = QtWidgets.QHBoxLayout(row_dir)
    row_dir_l.setContentsMargins(0, 0, 0, 0)
    row_dir_l.setSpacing(6)
    self.edit_rec_out_dir = QtWidgets.QLineEdit()
    self.edit_rec_out_dir.setPlaceholderText(
        self._t(
            "placeholder_recording_output_folder",
            "Recording output folder (base directory)",
        )
    )
    self.edit_rec_out_dir.setText(str(getattr(self, "_rec_out_dir", "")))
    self.btn_rec_browse = QtWidgets.QToolButton()
    self.btn_rec_browse.setText(self._t("btn_browse", "Browse…"))
    self.btn_rec_browse.setToolTip(
        self._t("tooltip_browse_recording", "Choose recording output folder")
    )
    row_dir_l.addWidget(self.edit_rec_out_dir, 1)
    row_dir_l.addWidget(self.btn_rec_browse, 0)

    def _browse_rec_dir() -> None:
        default_out = str(
            getattr(self, "_rec_out_dir", "")
            or (Path.home() / str(getattr(config, "DEFAULT_REC_OUT_DIRNAME", "rr_data")))
        )
        # Keep folder-dialog startup path purely string-based so we do not block
        # on existence checks for stale/unreachable network mounts.
        start = str(self.edit_rec_out_dir.text().strip() or default_out or Path.home())
        options = QtWidgets.QFileDialog.Option.ShowDirsOnly
        if sys.platform.startswith("linux") or sys.platform.startswith("win"):
            options |= QtWidgets.QFileDialog.Option.DontUseNativeDialog
        d = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            self._t("dialog_select_recording_folder", "Select recording output folder"),
            start,
            options=options,
        )
        if d:
            self.edit_rec_out_dir.setText(str(d))

    self.btn_rec_browse.clicked.connect(_browse_rec_dir)

    def _sync_rec_dir(*_args) -> None:
        self._rec_out_dir = self.edit_rec_out_dir.text().strip()

    self.edit_rec_out_dir.textChanged.connect(_sync_rec_dir)
    self.lbl_output_folder = QtWidgets.QLabel(
        self._t("label_output_folder", "Output folder")
    )
    rec_layout.addWidget(self.lbl_output_folder)
    rec_layout.addWidget(row_dir)

    # Column selection
    self.lbl_rec_columns_intro = QtWidgets.QLabel(
        self._t(
            "settings_recording_columns_intro",
            "Columns to include (independent of EMGS mode toggles)",
        )
    )
    self.lbl_rec_columns_intro.setStyleSheet("color: #9fb2e8;")
    rec_layout.addWidget(self.lbl_rec_columns_intro)
    self.lbl_rec_emg_ecg_tip = QtWidgets.QLabel(
        self._t(
            "settings_recording_emg_ecg_tip",
            "Tip: for respiratory EMG, enable `emg_clean_ecg_mV` and `emg_ecg_artifact_mV` to compare filter quality.",
        )
    )
    self.lbl_rec_emg_ecg_tip.setStyleSheet("color: #9fb2e8; font-size: 11px;")
    self.lbl_rec_emg_ecg_tip.setWordWrap(True)
    rec_layout.addWidget(self.lbl_rec_emg_ecg_tip)

    cols_scroll = QtWidgets.QScrollArea()
    cols_scroll.setWidgetResizable(True)
    cols_scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
    cols_inner = QtWidgets.QWidget()
    cols_scroll.setWidget(cols_inner)
    cols_l = QtWidgets.QVBoxLayout(cols_inner)
    cols_l.setContentsMargins(0, 0, 0, 0)
    cols_l.setSpacing(10)

    # EMG columns
    self.grp_rec_emg_cols = QtWidgets.QGroupBox(
        self._t("settings_group_rec_emg_columns", "EMG columns (1 ms)")
    )
    g1_wrap = QtWidgets.QVBoxLayout(self.grp_rec_emg_cols)
    g1_wrap.setContentsMargins(8, 8, 8, 8)
    g1_wrap.setSpacing(8)
    g1_btns = QtWidgets.QHBoxLayout()
    g1_btns.setContentsMargins(0, 0, 0, 0)
    g1_btns.setSpacing(6)
    self.btn_rec_emg_all = QtWidgets.QToolButton()
    self.btn_rec_emg_all.setText(self._t("action_select_all", "Select All"))
    self.btn_rec_emg_none = QtWidgets.QToolButton()
    self.btn_rec_emg_none.setText(self._t("action_select_none", "Select None"))
    g1_btns.addWidget(self.btn_rec_emg_all)
    g1_btns.addWidget(self.btn_rec_emg_none)
    g1_btns.addStretch(1)
    g1_wrap.addLayout(g1_btns)
    g1 = QtWidgets.QGridLayout()
    g1.setContentsMargins(0, 0, 0, 0)
    g1.setHorizontalSpacing(10)
    g1.setVerticalSpacing(6)
    g1_wrap.addLayout(g1)
    self._rec_emg_chk: dict[str, QtWidgets.QCheckBox] = {}
    for i, f in enumerate(self._rec_emg_fields_all):
        cb = QtWidgets.QCheckBox(f)
        cb.setChecked(f in self._rec_emg_fields_selected)
        self._rec_emg_chk[f] = cb
        g1.addWidget(cb, i // 2, i % 2)

    # IMU columns
    self.grp_rec_imu_cols = QtWidgets.QGroupBox(
        self._t("settings_group_rec_imu_columns", "IMU columns (10 ms)")
    )
    g2_wrap = QtWidgets.QVBoxLayout(self.grp_rec_imu_cols)
    g2_wrap.setContentsMargins(8, 8, 8, 8)
    g2_wrap.setSpacing(8)
    g2_btns = QtWidgets.QHBoxLayout()
    g2_btns.setContentsMargins(0, 0, 0, 0)
    g2_btns.setSpacing(6)
    self.btn_rec_imu_all = QtWidgets.QToolButton()
    self.btn_rec_imu_all.setText(self._t("action_select_all", "Select All"))
    self.btn_rec_imu_none = QtWidgets.QToolButton()
    self.btn_rec_imu_none.setText(self._t("action_select_none", "Select None"))
    g2_btns.addWidget(self.btn_rec_imu_all)
    g2_btns.addWidget(self.btn_rec_imu_none)
    g2_btns.addStretch(1)
    g2_wrap.addLayout(g2_btns)
    g2 = QtWidgets.QGridLayout()
    g2.setContentsMargins(0, 0, 0, 0)
    g2.setHorizontalSpacing(10)
    g2.setVerticalSpacing(6)
    g2_wrap.addLayout(g2)
    self._rec_imu_chk: dict[str, QtWidgets.QCheckBox] = {}
    for i, f in enumerate(self._rec_imu_fields_all):
        cb = QtWidgets.QCheckBox(f)
        cb.setChecked(f in self._rec_imu_fields_selected)
        self._rec_imu_chk[f] = cb
        g2.addWidget(cb, i // 3, i % 3)

    # AKR motor common columns (virtual helper controls mapped to walk/cpm/measure fields).
    self._rec_akr_motor_common_map: dict[str, tuple[str, str, str]] = {
        # Shared Motor + Health fields across walk/cpm/measure. State is intentionally excluded.
        "fid": ("walk_fid", "cpm_fid", "measure_fid"),
        "dt_ms": ("walk_dt_ms", "cpm_dt_ms", "measure_dt_ms"),
        "pos_rad": ("walk_pos_rad", "cpm_pos_rad", "measure_pos_rad"),
        "vel_rad_s": ("walk_vel_rad_s", "cpm_vel_rad_s", "measure_vel_rad_s"),
        "tq_nm": ("walk_tq_nm", "cpm_tq_nm", "measure_tq_nm"),
        "temp_c": ("walk_temp_c", "cpm_temp_c", "measure_temp_c"),
        "vbus_v": ("walk_vbus_v", "cpm_vbus_v", "measure_vbus_v"),
        "pattern": ("walk_pattern", "cpm_pattern", "measure_pattern"),
        "err_code": ("walk_err_code", "cpm_err_code", "measure_err_code"),
        "fb_age_ms": ("walk_fb_age_ms", "cpm_fb_age_ms", "measure_fb_age_ms"),
    }
    _akr_motor_common_fields = {
        str(f)
        for fields in self._rec_akr_motor_common_map.values()
        for f in fields
    }

    # AKR columns (AKR / RR telemetry)
    def _build_akr_group(
        title: str,
        prefixes: tuple[str, ...],
        *,
        exclude_fields: set[str] | None = None,
    ) -> tuple[QtWidgets.QGroupBox, dict[str, QtWidgets.QCheckBox], QtWidgets.QToolButton, QtWidgets.QToolButton]:
        grp = QtWidgets.QGroupBox(title)
        wrap = QtWidgets.QVBoxLayout(grp)
        wrap.setContentsMargins(8, 8, 8, 8)
        wrap.setSpacing(8)

        btns = QtWidgets.QHBoxLayout()
        btns.setContentsMargins(0, 0, 0, 0)
        btns.setSpacing(6)
        btn_all = QtWidgets.QToolButton()
        btn_all.setText(self._t("action_select_all", "Select All"))
        btn_none = QtWidgets.QToolButton()
        btn_none.setText(self._t("action_select_none", "Select None"))
        btns.addWidget(btn_all)
        btns.addWidget(btn_none)
        btns.addStretch(1)
        wrap.addLayout(btns)

        grid = QtWidgets.QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(6)
        wrap.addLayout(grid)

        items: dict[str, QtWidgets.QCheckBox] = {}
        excluded = set(exclude_fields or ())
        fields = [f for f in self._rec_akr_fields_all if str(f).startswith(prefixes) and str(f) not in excluded]
        for i, f in enumerate(fields):
            cb = QtWidgets.QCheckBox(f)
            cb.setChecked(f in self._rec_akr_fields_selected)
            items[f] = cb
            grid.addWidget(cb, i // 2, i % 2)
        return grp, items, btn_all, btn_none

    self.grp_rec_robot_walk_cols, self._rec_akr_walk_chk, self.btn_rec_robot_walk_all, self.btn_rec_robot_walk_none = _build_akr_group(
        self._t("settings_group_rec_robot_walk_columns", "AKR Walk columns (20 ms)"),
        ("walk_",),
        exclude_fields=_akr_motor_common_fields,
    )
    self.grp_rec_robot_cpm_cols, self._rec_akr_cpm_chk, self.btn_rec_robot_cpm_all, self.btn_rec_robot_cpm_none = _build_akr_group(
        self._t("settings_group_rec_robot_cpm_columns", "AKR CPM columns (20 ms)"),
        ("cpm_",),
        exclude_fields=_akr_motor_common_fields,
    )
    self.grp_rec_robot_measure_cols, self._rec_akr_measure_chk, self.btn_rec_robot_measure_all, self.btn_rec_robot_measure_none = _build_akr_group(
        self._t("settings_group_rec_robot_measure_columns", "AKR Measure columns (20 ms)"),
        ("measure_",),
        exclude_fields=_akr_motor_common_fields,
    )
    self.grp_rec_robot_cfg_cols, self._rec_akr_cfg_chk, self.btn_rec_robot_cfg_all, self.btn_rec_robot_cfg_none = _build_akr_group(
        self._t("settings_group_rec_robot_config_columns", "AKR Config columns (20 ms)"),
        ("cfg_",),
    )

    # Backing checkboxes for common motor fields.
    # These fields are controlled via the virtual "AKR Motor common" group
    # and intentionally hidden from per-mode groups to avoid duplicate UI rows.
    self._rec_akr_motor_common_backing_chk: dict[str, QtWidgets.QCheckBox] = {}
    for f in sorted(_akr_motor_common_fields):
        cb = QtWidgets.QCheckBox(str(f), self.settings_page)
        cb.setVisible(False)
        cb.setChecked(str(f) in self._rec_akr_fields_selected)
        self._rec_akr_motor_common_backing_chk[str(f)] = cb

    self.grp_rec_robot_motor_common_cols = QtWidgets.QGroupBox(
        self._t(
            "settings_group_rec_robot_motor_common_columns",
            "AKR Motor common columns (20 ms)",
        )
    )
    gmc_wrap = QtWidgets.QVBoxLayout(self.grp_rec_robot_motor_common_cols)
    gmc_wrap.setContentsMargins(8, 8, 8, 8)
    gmc_wrap.setSpacing(8)
    gmc_btns = QtWidgets.QHBoxLayout()
    gmc_btns.setContentsMargins(0, 0, 0, 0)
    gmc_btns.setSpacing(6)
    self.btn_rec_robot_motor_common_all = QtWidgets.QToolButton()
    self.btn_rec_robot_motor_common_all.setText(
        self._t("action_select_all", "Select All")
    )
    self.btn_rec_robot_motor_common_none = QtWidgets.QToolButton()
    self.btn_rec_robot_motor_common_none.setText(
        self._t("action_select_none", "Select None")
    )
    gmc_btns.addWidget(self.btn_rec_robot_motor_common_all)
    gmc_btns.addWidget(self.btn_rec_robot_motor_common_none)
    gmc_btns.addStretch(1)
    gmc_wrap.addLayout(gmc_btns)
    gmc_grid = QtWidgets.QGridLayout()
    gmc_grid.setContentsMargins(0, 0, 0, 0)
    gmc_grid.setHorizontalSpacing(10)
    gmc_grid.setVerticalSpacing(6)
    gmc_wrap.addLayout(gmc_grid)

    self._rec_akr_motor_common_chk: dict[str, QtWidgets.QCheckBox] = {}
    for i, key in enumerate(self._rec_akr_motor_common_map.keys()):
        cb = QtWidgets.QCheckBox(str(key))
        cb.setTristate(True)
        cb.setToolTip(
            self._t(
                "tooltip_settings_rec_robot_motor_common",
                "Controls Walk + CPM + Measure for this field",
            )
        )
        self._rec_akr_motor_common_chk[str(key)] = cb
        gmc_grid.addWidget(cb, i // 2, i % 2)

    # Backward-compatible aggregate used by profile/load/reset logic.
    self._rec_akr_chk: dict[str, QtWidgets.QCheckBox] = {}
    self._rec_akr_chk.update(self._rec_akr_walk_chk)
    self._rec_akr_chk.update(self._rec_akr_cpm_chk)
    self._rec_akr_chk.update(self._rec_akr_measure_chk)
    self._rec_akr_chk.update(self._rec_akr_cfg_chk)
    self._rec_akr_chk.update(self._rec_akr_motor_common_backing_chk)

    self._rec_akr_common_syncing = False

    def _sync_rec_columns(*_args) -> None:
        self._rec_emg_fields_selected = {k for k, cb in self._rec_emg_chk.items() if cb.isChecked()}
        self._rec_imu_fields_selected = {k for k, cb in self._rec_imu_chk.items() if cb.isChecked()}
        self._rec_akr_fields_selected = {k for k, cb in getattr(self, "_rec_akr_chk", {}).items() if cb.isChecked()}

    def _refresh_robot_common_checks() -> None:
        if bool(getattr(self, "_rec_akr_common_syncing", False)):
            return
        self._rec_akr_common_syncing = True
        try:
            for key, fields in getattr(self, "_rec_akr_motor_common_map", {}).items():
                cb = getattr(self, "_rec_akr_motor_common_chk", {}).get(key)
                if cb is None:
                    continue
                vals = [bool(getattr(self, "_rec_akr_chk", {}).get(f).isChecked()) for f in fields if getattr(self, "_rec_akr_chk", {}).get(f) is not None]
                if not vals:
                    state = QtCore.Qt.CheckState.Unchecked
                elif all(vals):
                    state = QtCore.Qt.CheckState.Checked
                elif any(vals):
                    state = QtCore.Qt.CheckState.PartiallyChecked
                else:
                    state = QtCore.Qt.CheckState.Unchecked
                cb.blockSignals(True)
                try:
                    cb.setCheckState(state)
                finally:
                    cb.blockSignals(False)
        finally:
            self._rec_akr_common_syncing = False

    def _apply_robot_common_check(key: str, state_int: int) -> None:
        if bool(getattr(self, "_rec_akr_common_syncing", False)):
            return
        fields = getattr(self, "_rec_akr_motor_common_map", {}).get(str(key), ())
        if not fields:
            return
        state = QtCore.Qt.CheckState(state_int)
        target = (state == QtCore.Qt.CheckState.Checked) or (state == QtCore.Qt.CheckState.PartiallyChecked)
        self._rec_akr_common_syncing = True
        try:
            for f in fields:
                cb = getattr(self, "_rec_akr_chk", {}).get(str(f))
                if cb is None:
                    continue
                cb.blockSignals(True)
                try:
                    cb.setChecked(bool(target))
                finally:
                    cb.blockSignals(False)
        finally:
            self._rec_akr_common_syncing = False
        _sync_rec_columns()
        _refresh_robot_common_checks()

    def _set_akr_common_group_checked(checked: bool) -> None:
        state = (QtCore.Qt.CheckState.Checked if checked else QtCore.Qt.CheckState.Unchecked).value
        for k in getattr(self, "_rec_akr_motor_common_chk", {}).keys():
            _apply_robot_common_check(str(k), state)

    # Expose helper so profile load/reset code can refresh this virtual group.
    self._refresh_robot_common_checks = _refresh_robot_common_checks

    for cb in list(self._rec_emg_chk.values()) + list(self._rec_imu_chk.values()) + list(getattr(self, "_rec_akr_chk", {}).values()):
        cb.toggled.connect(_sync_rec_columns)
    for cb in list(getattr(self, "_rec_akr_chk", {}).values()):
        cb.toggled.connect(_refresh_robot_common_checks)
    for key, cb in getattr(self, "_rec_akr_motor_common_chk", {}).items():
        cb.stateChanged.connect(lambda state, k=key: _apply_robot_common_check(k, state))

    def _set_group_checked(items: dict[str, QtWidgets.QCheckBox], checked: bool) -> None:
        for cb in items.values():
            cb.blockSignals(True)
            try:
                cb.setChecked(bool(checked))
            finally:
                cb.blockSignals(False)
        _sync_rec_columns()

    self.btn_rec_emg_all.clicked.connect(lambda: _set_group_checked(self._rec_emg_chk, True))
    self.btn_rec_emg_none.clicked.connect(lambda: _set_group_checked(self._rec_emg_chk, False))
    self.btn_rec_imu_all.clicked.connect(lambda: _set_group_checked(self._rec_imu_chk, True))
    self.btn_rec_imu_none.clicked.connect(lambda: _set_group_checked(self._rec_imu_chk, False))
    self.btn_rec_robot_walk_all.clicked.connect(lambda: _set_group_checked(self._rec_akr_walk_chk, True))
    self.btn_rec_robot_walk_none.clicked.connect(lambda: _set_group_checked(self._rec_akr_walk_chk, False))
    self.btn_rec_robot_cpm_all.clicked.connect(lambda: _set_group_checked(self._rec_akr_cpm_chk, True))
    self.btn_rec_robot_cpm_none.clicked.connect(lambda: _set_group_checked(self._rec_akr_cpm_chk, False))
    self.btn_rec_robot_measure_all.clicked.connect(lambda: _set_group_checked(self._rec_akr_measure_chk, True))
    self.btn_rec_robot_measure_none.clicked.connect(lambda: _set_group_checked(self._rec_akr_measure_chk, False))
    self.btn_rec_robot_cfg_all.clicked.connect(lambda: _set_group_checked(self._rec_akr_cfg_chk, True))
    self.btn_rec_robot_cfg_none.clicked.connect(lambda: _set_group_checked(self._rec_akr_cfg_chk, False))
    self.btn_rec_robot_motor_common_all.clicked.connect(lambda: _set_akr_common_group_checked(True))
    self.btn_rec_robot_motor_common_none.clicked.connect(lambda: _set_akr_common_group_checked(False))

    cols_l.addWidget(self.grp_rec_emg_cols)
    cols_l.addWidget(self.grp_rec_imu_cols)
    cols_l.addWidget(self.grp_rec_robot_motor_common_cols)
    cols_l.addWidget(self.grp_rec_robot_walk_cols)
    cols_l.addWidget(self.grp_rec_robot_cpm_cols)
    cols_l.addWidget(self.grp_rec_robot_measure_cols)
    cols_l.addWidget(self.grp_rec_robot_cfg_cols)
    cols_l.addStretch(1)
    _refresh_robot_common_checks()
    rec_layout.addWidget(cols_scroll, 1)

    # Controls at top, info at bottom. Recording panel sits to the right.
    top_row = QtWidgets.QHBoxLayout()
    top_row.setContentsMargins(0, 0, 0, 0)
    top_row.setSpacing(12)
    top_row.addWidget(self.grp_processed, 2)
    top_row.addWidget(self.grp_recording, 1)
    settings_layout.addWidget(self.grp_profile)
    settings_layout.addLayout(top_row)
    settings_layout.addStretch(1)
    self.tabs.addTab(self.settings_page, self._t("tab_settings", "Settings"))


def retranslate_settings_tab(self) -> None:
    self.grp_profile.setTitle(self._t("settings_group_profile", "Save / Load Profile"))
    self.edit_profile_path.setPlaceholderText(
        self._t("profile_path_placeholder", "Profile file path (.json)")
    )
    self.btn_profile_load.setText(self._t("btn_load", "Load…"))
    self.btn_profile_save.setText(self._t("btn_save", "Save…"))
    self.btn_profile_reset.setText(self._t("btn_reset", "Reset"))
    self.grp_processed.setTitle(self._t("settings_group_processed", "Processed Data"))
    self.grp_recording.setTitle(self._t("settings_group_recording", "Recording Data"))
    self.lbl_proc_heading_emg_analysis.setText(
        self._t("settings_heading_emg_analysis", "— EMG Analysis —")
    )
    self.lbl_proc_req_emg_raw_envelope.setText(
        self._t(
            "settings_req_emg_raw_envelope",
            "Requires: EMG RAW streaming enabled on the device (processed EMG is computed from raw EMG samples).",
        )
    )
    self.chk_proc_emg_env.setText(
        self._t("settings_chk_emg_rms_envelope", "Enable EMG RMS Envelope")
    )
    self.chk_proc_emg_env.setToolTip(
        self._t(
            "tooltip_settings_chk_emg_rms_envelope",
            "When enabled, the next streaming session will compute EMG RMS envelope data.",
        )
    )
    self.lbl_proc_hint_emg_env.setText(
        self._t(
            "settings_hint_emg_rms_envelope",
            "Computes a smoothed RMS envelope over raw EMG samples (next session).",
        )
    )
    self.spin_proc_emg_env_win.setSuffix(self._t("suffix_samples", " samples"))
    self.spin_proc_emg_env_win.setToolTip(
        self._t(
            "tooltip_settings_rms_window",
            "RMS envelope window length in samples (latched next session).",
        )
    )
    self.lbl_proc_rms_window.setText(self._t("settings_label_rms_window", "RMS window"))
    self.lbl_proc_hint_rms_window.setText(
        self._t(
            "settings_hint_rms_window",
            "Number of samples used in RMS envelope. Larger = smoother but slower response.",
        )
    )
    self.chk_proc_emg_freq.setText(
        self._t(
            "settings_chk_emg_freq_features",
            "Enable EMG Frequency Features (MDF/MNF)",
        )
    )
    self.chk_proc_emg_freq.setToolTip(
        self._t(
            "tooltip_settings_chk_emg_freq_features",
            "When enabled, the next streaming session will compute median/mean frequency and spectra.",
        )
    )
    self.lbl_proc_hint_emg_freq.setText(
        self._t(
            "settings_hint_emg_freq_features",
            "Computes MDF/MNF from a windowed FFT over the last N raw EMG samples (next session).",
        )
    )
    self.spin_proc_emg_spec_win.setSuffix(self._t("suffix_samples", " samples"))
    self.spin_proc_emg_spec_win.setToolTip(
        self._t(
            "tooltip_settings_fft_window",
            "Spectral window length in samples (latched next session).",
        )
    )
    self.lbl_proc_fft_window.setText(self._t("settings_label_fft_window", "FFT window"))
    self.lbl_proc_hint_fft_window.setText(
        self._t(
            "settings_hint_fft_window",
            "FFT window length in samples. Larger = better frequency resolution, slower updates.",
        )
    )
    self.lbl_proc_heading_fatigue.setText(
        self._t("settings_heading_fatigue", "— Fatigue (unsupervised) —")
    )
    self.lbl_proc_req_fatigue.setText(
        self._t(
            "settings_req_fatigue",
            'Requires: Enable "EMG Frequency Features (MDF/MNF)" + EMG RAW streaming (fatigue uses MDF + RMS trend).',
        )
    )
    self.chk_proc_emg_fatigue.setText(
        self._t("settings_chk_fatigue_score", "Enable fatigue score (heuristic)")
    )
    self.chk_proc_emg_fatigue.setToolTip(
        self._t(
            "tooltip_settings_chk_fatigue_score",
            "Computes a 0..1 fatigue score from MDF drop + RMS rise (requires EMG Frequency Features). This is NOT a calibrated probability.",
        )
    )
    self.lbl_proc_hint_fatigue.setText(
        self._t(
            "settings_hint_fatigue_score",
            "Heuristic fatigue score from MDF drop + RMS rise (not a calibrated probability).",
        )
    )
    self.spin_proc_emg_fatigue_baseline_s.setSuffix(self._t("suffix_seconds", " s"))
    self.spin_proc_emg_fatigue_baseline_s.setToolTip(
        self._t(
            "tooltip_settings_fatigue_baseline",
            "Baseline duration (first N seconds) used to estimate non-fatigued MDF/RMS.",
        )
    )
    self.lbl_proc_fatigue_baseline.setText(
        self._t("settings_label_fatigue_baseline", "Baseline")
    )
    self.lbl_proc_hint_fatigue_baseline.setText(
        self._t(
            "settings_hint_fatigue_baseline",
            "First N seconds used to define the non-fatigued reference level.",
        )
    )
    self.spin_proc_emg_fatigue_w_mdf.setSuffix(self._t("suffix_percent", " %"))
    self.spin_proc_emg_fatigue_w_mdf.setToolTip(
        self._t(
            "tooltip_settings_fatigue_weight_mdf",
            "Weight for MDF drop contribution (percent; weights are normalized internally).",
        )
    )
    self.lbl_proc_fatigue_weight_mdf.setText(
        self._t("settings_label_fatigue_weight_mdf", "Weight MDF")
    )
    self.lbl_proc_hint_fatigue_weight_mdf.setText(
        self._t(
            "settings_hint_fatigue_weight_mdf",
            "Relative weight of MDF drop in the fatigue score.",
        )
    )
    self.spin_proc_emg_fatigue_w_rms.setSuffix(self._t("suffix_percent", " %"))
    self.spin_proc_emg_fatigue_w_rms.setToolTip(
        self._t(
            "tooltip_settings_fatigue_weight_rms",
            "Weight for RMS rise contribution (percent; weights are normalized internally).",
        )
    )
    self.lbl_proc_fatigue_weight_rms.setText(
        self._t("settings_label_fatigue_weight_rms", "Weight RMS")
    )
    self.lbl_proc_hint_fatigue_weight_rms.setText(
        self._t(
            "settings_hint_fatigue_weight_rms",
            "Relative weight of RMS rise in the fatigue score.",
        )
    )
    self.spin_proc_emg_fatigue_conf_n.setSuffix(self._t("suffix_updates", " updates"))
    self.spin_proc_emg_fatigue_conf_n.setToolTip(
        self._t(
            "tooltip_settings_fatigue_conf_window",
            "Confidence uses MDF monotonicity over the last N feature updates.",
        )
    )
    self.lbl_proc_fatigue_conf_window.setText(
        self._t("settings_label_fatigue_conf_window", "Confidence window")
    )
    self.lbl_proc_hint_fatigue_conf_window.setText(
        self._t(
            "settings_hint_fatigue_conf_window",
            "N most recent feature updates used to compute confidence.",
        )
    )
    self.lbl_proc_heading_resp_emg_ecg.setText(
        self._t("settings_heading_resp_emg_ecg", "— Respiratory EMG (ECG artifact) —")
    )
    self.lbl_proc_req_resp_emg_ecg.setText(
        self._t(
            "settings_req_resp_emg_ecg",
            "Requires: EMG RAW streaming enabled on the device (filtering is host-side and applies next session).",
        )
    )
    self.chk_proc_emg_ecg_filter.setText(
        self._t("settings_chk_emg_ecg_filter", "Enable ECG artifact reduction")
    )
    self.chk_proc_emg_ecg_filter.setToolTip(
        self._t(
            "tooltip_settings_chk_emg_ecg_filter",
            "Reduces ECG contamination in respiratory EMG (upper chest / lower rib cage). Recommended for breathing-muscle channels.",
        )
    )
    self.lbl_proc_hint_emg_ecg_filter.setText(
        self._t(
            "settings_hint_emg_ecg_filter",
            "Recommended: high-pass for live use; wavelet for cleaner post-review.",
        )
    )
    # Keep the current method data selected while replacing localized labels.
    current_method = str(self.combo_proc_emg_ecg_method.currentData() or "highpass")
    try:
        self.combo_proc_emg_ecg_method.blockSignals(True)
        self.combo_proc_emg_ecg_method.clear()
        self.combo_proc_emg_ecg_method.addItem(
            self._t("settings_method_highpass", "Adaptive high-pass (recommended)"),
            "highpass",
        )
        self.combo_proc_emg_ecg_method.addItem(
            self._t("settings_method_wavelet", "Wavelet soft-threshold (experimental)"),
            "wavelet",
        )
        idx = self.combo_proc_emg_ecg_method.findData(current_method)
        self.combo_proc_emg_ecg_method.setCurrentIndex(max(0, idx))
    finally:
        self.combo_proc_emg_ecg_method.blockSignals(False)
    self.combo_proc_emg_ecg_method.setToolTip(
        self._t(
            "tooltip_settings_ecg_method",
            "Method used to suppress ECG from respiratory EMG.",
        )
    )
    self.lbl_proc_ecg_method.setText(self._t("settings_label_ecg_method", "Method"))
    self.lbl_proc_hint_ecg_method.setText(
        self._t(
            "settings_hint_ecg_method",
            "High-pass is lower latency; wavelet can better suppress QRS morphology.",
        )
    )
    self.spin_proc_emg_ecg_hp_cutoff_hz.setSuffix(self._t("suffix_hz", " Hz"))
    self.spin_proc_emg_ecg_hp_cutoff_hz.setToolTip(
        self._t(
            "tooltip_settings_ecg_hp_cutoff",
            "High-pass cutoff for ECG suppression (higher cutoff removes more ECG and low-frequency EMG).",
        )
    )
    self.lbl_proc_ecg_hp_cutoff.setText(
        self._t("settings_label_ecg_hp_cutoff", "HP cutoff")
    )
    self.lbl_proc_hint_ecg_hp_cutoff.setText(
        self._t(
            "settings_hint_ecg_hp_cutoff",
            "Typical respiratory EMG range: 20–35 Hz cutoff; start near 25 Hz.",
        )
    )
    self.spin_proc_emg_ecg_wavelet_levels.setToolTip(
        self._t(
            "tooltip_settings_ecg_wavelet_levels",
            "Wavelet decomposition levels (higher can remove more ECG morphology).",
        )
    )
    self.lbl_proc_ecg_wavelet_levels.setText(
        self._t("settings_label_ecg_wavelet_levels", "Wavelet levels")
    )
    self.lbl_proc_hint_ecg_wavelet_levels.setText(
        self._t("settings_hint_ecg_wavelet_levels", "Used when method is wavelet.")
    )
    self.spin_proc_emg_ecg_wavelet_shrink.setToolTip(
        self._t(
            "tooltip_settings_ecg_wavelet_shrink",
            "Wavelet shrink factor (higher = stronger denoise).",
        )
    )
    self.lbl_proc_ecg_wavelet_shrink.setText(
        self._t("settings_label_ecg_wavelet_shrink", "Wavelet shrink")
    )
    self.lbl_proc_hint_ecg_wavelet_shrink.setText(
        self._t(
            "settings_hint_ecg_wavelet_shrink",
            "Used when method is wavelet; increase if ECG peaks remain visible.",
        )
    )
    self.lbl_proc_note.setText(
        self._t(
            "settings_note_processed_next_session",
            "Note: changes apply next session; stop streaming to change.",
        )
    )
    self.lbl_output_folder.setText(self._t("label_output_folder", "Output folder"))
    self.edit_rec_out_dir.setPlaceholderText(
        self._t(
            "placeholder_recording_output_folder",
            "Recording output folder (base directory)",
        )
    )
    self.btn_rec_browse.setText(self._t("btn_browse", "Browse…"))
    self.btn_rec_browse.setToolTip(
        self._t("tooltip_browse_recording", "Choose recording output folder")
    )
    self.lbl_rec_columns_intro.setText(
        self._t(
            "settings_recording_columns_intro",
            "Columns to include (not dependent on sensor enable state)",
        )
    )
    self.lbl_rec_emg_ecg_tip.setText(
        self._t(
            "settings_recording_emg_ecg_tip",
            "Tip: for respiratory EMG, enable `emg_clean_ecg_mV` and `emg_ecg_artifact_mV` to compare filter quality.",
        )
    )
    self.grp_rec_emg_cols.setTitle(
        self._t("settings_group_rec_emg_columns", "EMG columns (1 ms)")
    )
    self.grp_rec_imu_cols.setTitle(
        self._t("settings_group_rec_imu_columns", "IMU columns (10 ms)")
    )
    self.grp_rec_robot_walk_cols.setTitle(
        self._t("settings_group_rec_robot_walk_columns", "AKR Walk columns (20 ms)")
    )
    self.grp_rec_robot_cpm_cols.setTitle(
        self._t("settings_group_rec_robot_cpm_columns", "AKR CPM columns (20 ms)")
    )
    self.grp_rec_robot_measure_cols.setTitle(
        self._t(
            "settings_group_rec_robot_measure_columns",
            "AKR Measure columns (20 ms)",
        )
    )
    self.grp_rec_robot_cfg_cols.setTitle(
        self._t("settings_group_rec_robot_config_columns", "AKR Config columns (20 ms)")
    )
    self.grp_rec_robot_motor_common_cols.setTitle(
        self._t(
            "settings_group_rec_robot_motor_common_columns",
            "AKR Motor common columns (20 ms)",
        )
    )
    for btn in (
        self.btn_rec_emg_all,
        self.btn_rec_imu_all,
        self.btn_rec_robot_walk_all,
        self.btn_rec_robot_cpm_all,
        self.btn_rec_robot_measure_all,
        self.btn_rec_robot_cfg_all,
        self.btn_rec_robot_motor_common_all,
    ):
        btn.setText(self._t("action_select_all", "Select All"))
    for btn in (
        self.btn_rec_emg_none,
        self.btn_rec_imu_none,
        self.btn_rec_robot_walk_none,
        self.btn_rec_robot_cpm_none,
        self.btn_rec_robot_measure_none,
        self.btn_rec_robot_cfg_none,
        self.btn_rec_robot_motor_common_none,
    ):
        btn.setText(self._t("action_select_none", "Select None"))
    for cb in self._rec_akr_motor_common_chk.values():
        cb.setToolTip(
            self._t(
                "tooltip_settings_rec_robot_motor_common",
                "Controls Walk + CPM + Measure for this field",
            )
        )

