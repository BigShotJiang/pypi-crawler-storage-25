from __future__ import annotations

from PyQt6 import QtCore, QtWidgets

from ..widgets import XYTrajectoryPlot


def build_scenario_tab(self) -> None:
    """Build the Scenario tab UI onto an existing `MainWindow` instance."""
    # --- Scenario tab ---
    self.scenario_page = QtWidgets.QWidget()
    scenario_layout = QtWidgets.QVBoxLayout(self.scenario_page)
    scenario_layout.setContentsMargins(12, 12, 12, 12)
    scenario_layout.setSpacing(10)

    scn_controls = QtWidgets.QHBoxLayout()
    scn_controls.setContentsMargins(0, 0, 0, 0)
    scn_controls.setSpacing(8)

    lbl_style = "color: #d7e1ff; font-weight: 600;"
    self.lbl_scn_device = QtWidgets.QLabel(self._t("label_device", "Device"))
    self.lbl_scn_device.setStyleSheet(lbl_style)
    self.combo_scn_device = QtWidgets.QComboBox()
    self.combo_scn_device.setMinimumWidth(200)
    # macOS: ensure it accepts mouse/focus normally (some styles can interfere).
    try:
        self.combo_scn_device.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
    except Exception:
        pass
    self.btn_scn_identify = QtWidgets.QToolButton()
    self.btn_scn_identify.setText(self._t("btn_identify", "Identify"))
    self.btn_scn_identify.setToolTip(
        self._t(
            "tooltip_scn_identify",
            "Identify: light selected device purple briefly.",
        )
    )
    self.btn_scn_identify.clicked.connect(self._identify_selected_scenario_device)

    self.lbl_scn_scenario = QtWidgets.QLabel(self._t("label_scenario", "Scenario"))
    self.lbl_scn_scenario.setStyleSheet(lbl_style)
    self.combo_scn_scenario = QtWidgets.QComboBox()
    self.combo_scn_scenario.setMinimumWidth(220)
    self.combo_scn_scenario.addItems([self._t("placeholder_dash", "—")])
    # Placeholder for future scenarios.
    self.combo_scn_scenario.setEnabled(False)

    self.combo_scn_options = QtWidgets.QComboBox()
    self.combo_scn_options.setMinimumWidth(180)
    self.combo_scn_options.addItems(
        [
            self._t("scenario_options_placeholder", "Options (placeholder)"),
            self._t("placeholder_dash", "—"),
        ]
    )
    self.combo_scn_options.setEnabled(False)
    self.combo_scn_options.setStyleSheet("color: #7f8c8d;")

    self.btn_scn_add = QtWidgets.QPushButton(self._t("btn_add", "Add"))
    self.btn_scn_remove = QtWidgets.QPushButton(self._t("btn_remove", "Remove"))
    self.btn_scn_add.setToolTip(
        self._t(
            "tooltip_scn_add",
            "Use selected device as the active scenario input.",
        )
    )
    self.btn_scn_remove.setToolTip(
        self._t(
            "tooltip_scn_remove",
            "Clear the active scenario input (clears trajectory).",
        )
    )
    self.btn_scn_add.clicked.connect(self._scenario_add_from_ui)
    self.btn_scn_remove.clicked.connect(self._scenario_remove_active)

    scn_controls.addWidget(self.lbl_scn_device)
    scn_controls.addWidget(self.combo_scn_device, 0)
    scn_controls.addWidget(self.btn_scn_identify)

    sep2 = QtWidgets.QFrame()
    sep2.setFrameShape(QtWidgets.QFrame.Shape.VLine)
    sep2.setFrameShadow(QtWidgets.QFrame.Shadow.Sunken)
    sep2.setStyleSheet("color: #22306b; background: #22306b;")
    scn_controls.addSpacing(6)
    scn_controls.addWidget(sep2)
    scn_controls.addSpacing(10)

    scn_controls.addWidget(self.lbl_scn_scenario)
    scn_controls.addWidget(self.combo_scn_scenario, 0)
    scn_controls.addWidget(self.combo_scn_options, 0)
    scn_controls.addStretch(1)
    scn_controls.addWidget(self.btn_scn_add)
    scn_controls.addWidget(self.btn_scn_remove)

    scenario_layout.addLayout(scn_controls)

    self.scn_plot = XYTrajectoryPlot(title=self._t("label_scenario", "Scenario"))

    # Right panel: scenario tiles (created by Add), similar to Signals right panel.
    self.scn_group_panel = QtWidgets.QScrollArea()
    self.scn_group_panel.setWidgetResizable(True)
    self.scn_group_panel.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
    self.scn_group_panel.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    self.scn_group_panel.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    self.scn_group_panel_inner = QtWidgets.QWidget()
    self.scn_group_panel_layout = QtWidgets.QVBoxLayout(self.scn_group_panel_inner)
    self.scn_group_panel_layout.setContentsMargins(0, 0, 0, 0)
    self.scn_group_panel_layout.setSpacing(10)
    self.scn_group_panel_layout.addStretch(1)
    self.scn_group_panel.setWidget(self.scn_group_panel_inner)
    self.scn_group_panel.setMinimumWidth(320)

    split2 = QtWidgets.QSplitter(QtCore.Qt.Orientation.Horizontal)
    split2.addWidget(self.scn_plot)
    split2.addWidget(self.scn_group_panel)
    split2.setStretchFactor(0, 5)
    split2.setStretchFactor(1, 1)
    scenario_layout.addWidget(split2, 1)

    scn_footer = QtWidgets.QHBoxLayout()
    scn_footer.setContentsMargins(0, 0, 0, 0)
    scn_footer.setSpacing(10)
    self.lbl_scn_session = QtWidgets.QLabel(self._t("session_idle", "Session: IDLE"))
    self.lbl_scn_session.setStyleSheet("color: #9fb2e8; font-weight: 600;")
    scn_footer.addWidget(self.lbl_scn_session, 0)
    scn_footer.addStretch(1)

    self.btn_scn_freeze = QtWidgets.QToolButton()
    self.btn_scn_freeze.setText(self._t("btn_freeze", "Freeze"))
    self.btn_scn_freeze.setCheckable(True)
    self.btn_scn_freeze.setToolTip(
        self._t(
            "tooltip_freeze",
            "Freeze: pauses plot updates only (stream continues).",
        )
    )
    self.btn_scn_freeze.toggled.connect(self._set_plot_frozen)

    self.btn_scn_reset = QtWidgets.QPushButton(self._t("btn_reset", "Reset"))
    self.btn_scn_reset.setToolTip(
        self._t(
            "tooltip_scn_reset",
            "Reset processed-data buffers/state without restarting streaming.",
        )
    )
    self.btn_scn_reset.clicked.connect(self._signals_reset_processed)

    self.btn_scn_record_start = QtWidgets.QPushButton(
        self._t("btn_start_record", "Start Record")
    )
    self.btn_scn_record_stop = QtWidgets.QPushButton(
        self._t("btn_stop_record", "Stop Record")
    )
    self.btn_scn_record_start.setToolTip(
        self._t(
            "tooltip_start_record",
            "Start recording streamed data to CSV files (EMG + IMU).",
        )
    )
    self.btn_scn_record_stop.setToolTip(
        self._t(
            "tooltip_stop_record",
            "Stop recording and close CSV files.",
        )
    )
    self.btn_scn_record_start.clicked.connect(self._signals_start_record)
    self.btn_scn_record_stop.clicked.connect(self._signals_stop_record)

    self.btn_scn_stream_start = QtWidgets.QPushButton(
        self._t("btn_start_stream", "Start Stream")
    )
    self.btn_scn_stream_stop = QtWidgets.QPushButton(
        self._t("btn_stop_stream", "Stop Stream")
    )
    self.btn_scn_stream_start.clicked.connect(lambda: self._scenario_stream_selected(True))
    self.btn_scn_stream_stop.clicked.connect(lambda: self._scenario_stream_selected(False))

    scn_footer.addWidget(self.btn_scn_freeze)
    scn_footer.addWidget(self.btn_scn_reset)
    scn_footer.addWidget(self.btn_scn_record_start)
    scn_footer.addWidget(self.btn_scn_record_stop)
    scn_footer.addWidget(self.btn_scn_stream_start)
    scn_footer.addWidget(self.btn_scn_stream_stop)
    scenario_layout.addLayout(scn_footer)

    self.tabs.addTab(self.scenario_page, self._t("tab_scenario", "Scenario"))


def retranslate_scenario_tab(self) -> None:
    self.lbl_scn_device.setText(self._t("label_device", "Device"))
    self.btn_scn_identify.setText(self._t("btn_identify", "Identify"))
    self.btn_scn_identify.setToolTip(
        self._t(
            "tooltip_scn_identify",
            "Identify: light selected device purple briefly.",
        )
    )
    self.lbl_scn_scenario.setText(self._t("label_scenario", "Scenario"))
    try:
        self.combo_scn_scenario.blockSignals(True)
        self.combo_scn_scenario.clear()
        self.combo_scn_scenario.addItems([self._t("placeholder_dash", "—")])
    finally:
        self.combo_scn_scenario.blockSignals(False)
    try:
        self.combo_scn_options.blockSignals(True)
        self.combo_scn_options.clear()
        self.combo_scn_options.addItems(
            [
                self._t("scenario_options_placeholder", "Options (placeholder)"),
                self._t("placeholder_dash", "—"),
            ]
        )
    finally:
        self.combo_scn_options.blockSignals(False)
    self.btn_scn_add.setText(self._t("btn_add", "Add"))
    self.btn_scn_remove.setText(self._t("btn_remove", "Remove"))
    self.btn_scn_add.setToolTip(
        self._t(
            "tooltip_scn_add",
            "Use selected device as the active scenario input.",
        )
    )
    self.btn_scn_remove.setToolTip(
        self._t(
            "tooltip_scn_remove",
            "Clear the active scenario input (clears trajectory).",
        )
    )
    self.scn_plot.title.setText(self._t("label_scenario", "Scenario"))
    self.btn_scn_freeze.setText(
        self._t("btn_frozen", "Frozen")
        if bool(getattr(self, "_plot_frozen", False))
        else self._t("btn_freeze", "Freeze")
    )
    self.btn_scn_freeze.setToolTip(
        self._t(
            "tooltip_freeze",
            "Freeze: pauses plot updates only (stream continues).",
        )
    )
    self.btn_scn_reset.setText(self._t("btn_reset", "Reset"))
    self.btn_scn_reset.setToolTip(
        self._t(
            "tooltip_scn_reset",
            "Reset processed-data buffers/state without restarting streaming.",
        )
    )
    self.btn_scn_record_start.setText(self._t("btn_start_record", "Start Record"))
    self.btn_scn_record_stop.setText(self._t("btn_stop_record", "Stop Record"))
    self.btn_scn_record_start.setToolTip(
        self._t(
            "tooltip_start_record",
            "Start recording streamed data to CSV files (EMG + IMU).",
        )
    )
    self.btn_scn_record_stop.setToolTip(
        self._t(
            "tooltip_stop_record",
            "Stop recording and close CSV files.",
        )
    )
    self.btn_scn_stream_start.setText(self._t("btn_start_stream", "Start Stream"))
    self.btn_scn_stream_stop.setText(self._t("btn_stop_stream", "Stop Stream"))
    self._update_signal_rx_status()

