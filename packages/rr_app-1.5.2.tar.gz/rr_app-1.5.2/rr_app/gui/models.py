from __future__ import annotations

from typing import Callable

from PyQt6 import QtCore

from ..devices.core.controller import DeviceController
from ..devices.emgs.state import DeviceState


class DeviceTableModel(QtCore.QAbstractTableModel):
    """Qt model exposing controller.manager.devices as a sortable table."""

    COLUMNS = [
        ("name", "table_name", "Name", lambda d: d.params.name),
        ("address", "table_address", "Address", lambda d: d.params.address),
        ("status", "table_status", "Status", lambda d: d.params.status),
        ("battery", "table_battery", "Battery", lambda d: d.params.battery),
        ("device_time", "table_device_time", "Device Time", lambda d: d.params.timestamp),
        ("clock_delta", "table_clock_delta", "ClockΔ", lambda d: d.clock_delta_ms),
        ("sensors", "table_sensors", "Sensors", lambda d: d.params.mode),
        ("firmware", "table_firmware", "Firmware", lambda d: d.params.firmware),
        ("hardware", "table_hardware", "Hardware", lambda d: d.params.hardware),
        ("dsp", "table_dsp", "DSP", lambda d: d.params.dsp),
        ("conn_interval", "table_conn_int", "ConnInt", lambda d: d.params.conn_interval),
    ]

    def __init__(
        self,
        controller: DeviceController,
        *,
        translate: Callable[[str, str], str] | None = None,
    ) -> None:
        super().__init__()
        self.controller = controller
        self._translate = translate or (lambda _key, default: default)

    def _addrs(self) -> list[str]:
        # Deterministic order based on insertion order in dict
        return list(self.controller.manager.devices.keys())

    def device_at(self, row: int) -> DeviceState | None:
        addrs = self._addrs()
        if row < 0 or row >= len(addrs):
            return None
        return self.controller.manager.devices.get(addrs[row])

    def address_at(self, row: int) -> str | None:
        addrs = self._addrs()
        if row < 0 or row >= len(addrs):
            return None
        return addrs[row]

    def rowCount(self, parent: QtCore.QModelIndex = QtCore.QModelIndex()) -> int:
        if parent.isValid():
            return 0
        return len(self.controller.manager.devices)

    def columnCount(self, parent: QtCore.QModelIndex = QtCore.QModelIndex()) -> int:
        if parent.isValid():
            return 0
        return len(self.COLUMNS)

    def headerData(self, section: int, orientation: QtCore.Qt.Orientation, role: int = QtCore.Qt.ItemDataRole.DisplayRole):
        if role != QtCore.Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == QtCore.Qt.Orientation.Horizontal:
            _id, key, default, _getter = self.COLUMNS[section]
            return self._translate(str(key), str(default))
        return str(section + 1)

    def data(self, index: QtCore.QModelIndex, role: int = QtCore.Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        dev = self.device_at(index.row())
        if not dev:
            return None
        col_id, _key, _default, col_fn = self.COLUMNS[index.column()]
        if role == QtCore.Qt.ItemDataRole.DisplayRole:
            try:
                # Status merges connected + streaming state
                if col_id == "status":
                    # Prefer "Awaiting Data" if health check says RX is stale.
                    if dev.params.status == "Unstable":
                        return self._translate("status_unstable", "Awaiting Data")
                    if dev.is_streaming:
                        return self._translate("status_streaming", "Streaming")
                    return dev.params.status
                if col_id == "clock_delta":
                    if dev.clock_delta_ms is None:
                        return "-"
                    return self._translate(
                        "clock_delta_fmt",
                        "{delta:+d} ms",
                    ).format(delta=dev.clock_delta_ms)
                return str(col_fn(dev))
            except Exception:
                return ""
        if role == QtCore.Qt.ItemDataRole.TextAlignmentRole:
            # Make the “metadata” columns tidy: Firmware..ConnInt center aligned.
            # Column indices: 7 Firmware, 8 Hardware, 9 DSP, 10 ConnInt
            if index.column() in (7, 8, 9, 10):
                return int(QtCore.Qt.AlignmentFlag.AlignCenter | QtCore.Qt.AlignmentFlag.AlignVCenter)
        if role == QtCore.Qt.ItemDataRole.DecorationRole:
            if col_id == "status":
                # More intuitive icons:
                # - disconnected: red cross
                # - connected (idle): green check
                # - awaiting data: orange dot
                # - streaming: blue broadcast
                if dev.params.status == "Unstable":
                    return _icon_dot("#ffa502")
                if dev.is_streaming:
                    return _icon_broadcast("#4ea1ff")
                if dev.is_connected:
                    return _icon_check("#2ed573")
                return _icon_cross("#ff4757")
            return None
        if role == QtCore.Qt.ItemDataRole.ForegroundRole:
            if col_id == "clock_delta" and dev.clock_delta_ms is not None:
                from .. import config
                if abs(int(dev.clock_delta_ms)) >= int(config.CLOCK_DRIFT_WARN_MS):
                    from PyQt6 import QtGui
                    return QtGui.QBrush(QtGui.QColor("#ff4757"))
        if role == QtCore.Qt.ItemDataRole.UserRole:
            if col_id == "battery":
                # Let the delegate paint charging indicator without a separate column.
                return {"charging": bool(dev.is_charging)}
        # Tooltips for long fields (e.g., macOS UUID addresses)
        if role == QtCore.Qt.ItemDataRole.ToolTipRole:
            if col_id == "address":
                return dev.params.address
            if col_id == "sensors":
                return dev.params.mode
            if col_id == "clock_delta":
                if dev.clock_delta_ms is None:
                    return self._translate(
                        "tooltip_clock_delta_empty",
                        "No clock delta yet (wait for A3/AG response)",
                    )
                return self._translate(
                    "tooltip_clock_delta_value",
                    "Clock delta (device - host): {delta:+d} ms",
                ).format(delta=dev.clock_delta_ms)
        return None

    def flags(self, index: QtCore.QModelIndex):
        if not index.isValid():
            return QtCore.Qt.ItemFlag.NoItemFlags
        return QtCore.Qt.ItemFlag.ItemIsEnabled | QtCore.Qt.ItemFlag.ItemIsSelectable

    def refresh_all(self) -> None:
        self.beginResetModel()
        self.endResetModel()

    def refresh_row_by_address(self, address: str) -> None:
        addrs = self._addrs()
        if address not in addrs:
            return
        row = addrs.index(address)
        top_left = self.index(row, 0)
        bottom_right = self.index(row, self.columnCount() - 1)
        self.dataChanged.emit(
            top_left,
            bottom_right,
            [
                QtCore.Qt.ItemDataRole.DisplayRole,
                QtCore.Qt.ItemDataRole.DecorationRole,
                # Battery charging indicator is provided via UserRole metadata.
                QtCore.Qt.ItemDataRole.UserRole,
                # ClockΔ warning tint uses ForegroundRole.
                QtCore.Qt.ItemDataRole.ForegroundRole,
            ],
        )


_ICON_CACHE: dict[tuple[str, str], object] = {}


def _icon_dot(color_hex: str):
    # Lazy import: QtGui only when needed.
    from PyQt6 import QtGui

    key = ("dot", color_hex)
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    size = 12
    pm = QtGui.QPixmap(size, size)
    pm.fill(QtCore.Qt.GlobalColor.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
    p.setPen(QtCore.Qt.PenStyle.NoPen)
    p.setBrush(QtGui.QColor(color_hex))
    p.drawEllipse(1, 1, size - 2, size - 2)
    p.end()
    icon = QtGui.QIcon(pm)
    _ICON_CACHE[key] = icon
    return icon


def _icon_check(color_hex: str):
    from PyQt6 import QtGui

    key = ("check", color_hex)
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    size = 14
    pm = QtGui.QPixmap(size, size)
    pm.fill(QtCore.Qt.GlobalColor.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
    pen = QtGui.QPen(QtGui.QColor(color_hex))
    pen.setWidth(2)
    pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(QtCore.Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    # Check mark
    p.drawLine(3, 8, 6, 11)
    p.drawLine(6, 11, 11, 3)
    p.end()
    icon = QtGui.QIcon(pm)
    _ICON_CACHE[key] = icon
    return icon


def _icon_cross(color_hex: str):
    from PyQt6 import QtGui

    key = ("cross", color_hex)
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    size = 14
    pm = QtGui.QPixmap(size, size)
    pm.fill(QtCore.Qt.GlobalColor.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
    pen = QtGui.QPen(QtGui.QColor(color_hex))
    pen.setWidth(2)
    pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap)
    p.setPen(pen)
    p.drawLine(4, 4, 10, 10)
    p.drawLine(10, 4, 4, 10)
    p.end()
    icon = QtGui.QIcon(pm)
    _ICON_CACHE[key] = icon
    return icon


def _icon_broadcast(color_hex: str):
    """A small 'broadcast/waves' icon for streaming state."""
    from PyQt6 import QtGui

    key = ("broadcast", color_hex)
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    size = 14
    pm = QtGui.QPixmap(size, size)
    pm.fill(QtCore.Qt.GlobalColor.transparent)
    p = QtGui.QPainter(pm)
    p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
    pen = QtGui.QPen(QtGui.QColor(color_hex))
    pen.setWidth(2)
    pen.setCapStyle(QtCore.Qt.PenCapStyle.RoundCap)
    p.setPen(pen)
    # Center dot
    p.setBrush(QtGui.QColor(color_hex))
    p.setPen(QtCore.Qt.PenStyle.NoPen)
    p.drawEllipse(6, 6, 2, 2)
    p.setBrush(QtCore.Qt.BrushStyle.NoBrush)
    p.setPen(pen)
    # Two arcs (left/right)
    p.drawArc(3, 3, 8, 8, 40 * 16, 100 * 16)
    p.drawArc(3, 3, 8, 8, 220 * 16, 100 * 16)
    p.end()
    icon = QtGui.QIcon(pm)
    _ICON_CACHE[key] = icon
    return icon

