from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from PyQt6 import QtCore, QtGui, QtWidgets

from .. import config
from ..devices.core.controller import DeviceController
from .mixins.connect_actions import ConnectActionsMixin
from .mixins.runtime import MainWindowRuntimeMixin
from .mixins.session_controls import SignalsScenarioSessionMixin
from .mixins.signals_plotting import SignalsPlotMixin
from .mixins.settings_profiles import SettingsProfilesMixin
from .tabs.connect_tab import build_connect_tab
from .tabs.connect_tab import retranslate_connect_tab
from .tabs.scenario_tab import build_scenario_tab
from .tabs.scenario_tab import retranslate_scenario_tab
from .tabs.settings_tab import build_settings_tab
from .tabs.settings_tab import retranslate_settings_tab
from .tabs.signals_tab import build_signals_tab
from .tabs.signals_tab import retranslate_signals_tab
from .widgets import (
    ScenarioControlTile,
)

if TYPE_CHECKING:
    from ..recording import RecordingSession


class MainWindow(
    QtWidgets.QMainWindow,
    SettingsProfilesMixin,
    ConnectActionsMixin,
    SignalsScenarioSessionMixin,
    SignalsPlotMixin,
    MainWindowRuntimeMixin,
):
    recording_visual_state_changed = QtCore.pyqtSignal(bool)

    def __init__(
        self,
        controller: DeviceController,
        *,
        language_packs: dict[str, dict[str, object]] | None = None,
        current_language: str = "en",
    ) -> None:
        super().__init__()
        self.controller = controller
        self._ui_settings = QtCore.QSettings("rr", "rr_app")
        self.language_packs = (
            language_packs
            if isinstance(language_packs, dict) and language_packs
            else {"en": {"name": "English", "texts": {}}}
        )
        persisted_language = str(self._ui_settings.value("ui/language", "") or "").strip()
        requested_language = persisted_language or str(current_language or "en")
        self.current_language = (
            requested_language if requested_language in self.language_packs else "en"
        )
        self._init_state()

        self._apply_main_window_title()
        self.resize(1200, 800)

        self._build_actions()
        self._build_ui()
        self._wire_signals()
        self._restore_last_profile()
        self._retranslate_ui()
        self._set_recording_visual_state(False)

        self._plot_timer = QtCore.QTimer(self)
        self._plot_timer.setInterval(config.PLOT_REFRESH_MS)
        self._plot_timer.timeout.connect(self._refresh_plots)
        self._plot_timer.start()

        # Periodic lightweight polling to keep table state fresh for connected devices.
        self._poll_timer = QtCore.QTimer(self)
        self._poll_timer.setInterval(int(config.DEVICE_POLL_INTERVAL_S * 1000))
        self._poll_timer.timeout.connect(self._poll_connected_devices)
        self._poll_timer.start()

        # Slow cadence "all info" refresh (heavier than A3 poll). Skip streaming devices by default.
        self._full_update_timer = QtCore.QTimer(self)
        self._full_update_timer.setInterval(int(config.DEVICE_FULL_UPDATE_INTERVAL_S * 1000))
        self._full_update_timer.timeout.connect(self._full_update_connected_devices)
        self._full_update_timer.start()

        # Global quick-exit shortcut (works even when dialogs have focus).
        # This avoids confusion where Esc closes a dialog but leaves devices connected.
        try:
            self._esc_shortcut = QtGui.QShortcut(QtGui.QKeySequence(QtCore.Qt.Key.Key_Escape), self)
            self._esc_shortcut.setContext(QtCore.Qt.ShortcutContext.ApplicationShortcut)
            self._esc_shortcut.activated.connect(self.close)
        except Exception:
            self._esc_shortcut = None

    def _text_template(self, key: str, default: str | None = None) -> str:
        current_texts = self.language_packs.get(self.current_language, {}).get("texts", {})
        default_texts = self.language_packs.get("en", {}).get("texts", {})
        template = str(default if default is not None else key)
        if isinstance(current_texts, dict):
            template = str(current_texts.get(key, template))
        if template == key and isinstance(default_texts, dict):
            template = str(default_texts.get(key, template))
        return template

    def _t(self, key: str, default: str | None = None, **kwargs) -> str:
        template = self._text_template(key, default=default)
        if kwargs:
            try:
                return template.format(**kwargs)
            except Exception:
                return template
        return template

    def _language_options(self) -> list[tuple[str, str]]:
        options: list[tuple[str, str]] = []
        for code, payload in self.language_packs.items():
            name = payload.get("name", code) if isinstance(payload, dict) else code
            options.append((str(code), str(name)))
        options.sort(key=lambda item: (0 if item[0] == "en" else 1, item[0]))
        return options

    def _set_language(self, language_code: str) -> None:
        code = str(language_code or "").strip()
        if code not in self.language_packs:
            return
        if code == self.current_language:
            return
        self.current_language = code
        try:
            self._ui_settings.setValue("ui/language", self.current_language)
        except Exception:
            pass
        self._retranslate_ui()

    def _build_language_corner_widget(self) -> None:
        self.language_corner_widget = QtWidgets.QWidget(self.tabs)
        corner_layout = QtWidgets.QHBoxLayout(self.language_corner_widget)
        corner_layout.setContentsMargins(0, 0, 0, 0)
        corner_layout.setSpacing(6)

        self.lbl_language = QtWidgets.QLabel(self._t("language_label", "Language"))
        self.combo_language = QtWidgets.QComboBox()
        for code, name in self._language_options():
            self.combo_language.addItem(str(name), str(code))
        idx_lang = self.combo_language.findData(self.current_language)
        self.combo_language.setCurrentIndex(idx_lang if idx_lang >= 0 else 0)
        self.combo_language.currentIndexChanged.connect(
            lambda _idx: self._set_language(str(self.combo_language.currentData() or "en"))
        )
        corner_layout.addWidget(self.lbl_language)
        corner_layout.addWidget(self.combo_language, 0)

        self.tabs.setCornerWidget(
            self.language_corner_widget,
            QtCore.Qt.Corner.TopRightCorner,
        )
        self._retranslate_language_corner_widget()

    def _retranslate_language_corner_widget(self) -> None:
        self.lbl_language.setText(self._t("language_label", "Language"))
        language_hint = self._t(
            "language_switch_hint",
            "Apply language immediately without restarting.",
        )
        self.language_corner_widget.setToolTip(language_hint)
        self.combo_language.setToolTip(language_hint)

        current_code = str(self.combo_language.currentData() or self.current_language or "en")
        try:
            self.combo_language.blockSignals(True)
            self.combo_language.clear()
            for code, name in self._language_options():
                self.combo_language.addItem(str(name), str(code))
            idx = self.combo_language.findData(current_code)
            self.combo_language.setCurrentIndex(idx if idx >= 0 else 0)
        finally:
            self.combo_language.blockSignals(False)

    def _retranslate_ui(self) -> None:
        self._apply_main_window_title()
        self.action_scan.setText(self._t("action_scan", "Scan"))
        self.action_select_all.setText(self._t("action_select_all", "Select All"))
        self.action_select_none.setText(self._t("action_select_none", "Select None"))
        self.action_connect.setText(self._t("action_connect", "Connect"))
        self.action_disconnect.setText(self._t("action_disconnect", "Disconnect"))
        self.action_update.setText(self._t("action_update", "Update Info"))
        self.action_settings.setText(self._t("action_settings", "Settings…"))
        self.action_record_start.setText(self._t("action_record_start", "Start Record"))
        self.action_record_stop.setText(self._t("action_record_stop", "Stop Record"))
        self.action_time_sync.setText(self._t("action_time_sync", "Time Sync"))
        self.action_bulk_modes.setText(
            self._t("action_bulk_modes", "Bulk Mode Settings…")
        )
        self.action_stream_start.setText(self._t("action_stream_start", "Start Stream"))
        self.action_stream_stop.setText(self._t("action_stream_stop", "Stop Stream"))
        self._retranslate_language_corner_widget()

        if getattr(self, "tabs", None) is not None:
            connect_idx = self.tabs.indexOf(getattr(self, "connect_page", None))
            signals_idx = self.tabs.indexOf(getattr(self, "signals_page", None))
            scenario_idx = self.tabs.indexOf(getattr(self, "scenario_page", None))
            settings_idx = self.tabs.indexOf(getattr(self, "settings_page", None))
            if connect_idx >= 0:
                self.tabs.setTabText(connect_idx, self._t("tab_connect", "Connect"))
            if signals_idx >= 0:
                self.tabs.setTabText(signals_idx, self._t("tab_signals", "Signals"))
            if scenario_idx >= 0:
                self.tabs.setTabText(scenario_idx, self._t("tab_scenario", "Scenario"))
            if settings_idx >= 0:
                self.tabs.setTabText(settings_idx, self._t("tab_settings", "Settings"))

        self._retranslate_connect_tab()
        self._retranslate_signals_tab()
        self._retranslate_scenario_tab()
        self._retranslate_settings_tab()
        self.device_model.refresh_all()
        self._refresh_signal_device_list()
        self._refresh_scenario_device_list()
        self._update_signal_rx_status()

    def _retranslate_connect_tab(self) -> None:
        retranslate_connect_tab(self)

    def _retranslate_signals_tab(self) -> None:
        retranslate_signals_tab(self)

    def _retranslate_scenario_tab(self) -> None:
        retranslate_scenario_tab(self)

    def _retranslate_settings_tab(self) -> None:
        retranslate_settings_tab(self)

    def _apply_main_window_title(self) -> None:
        self.setWindowTitle(
            self._t(
                "main_window_title",
                "RR_APP v{version}",
                version=getattr(config, "__version__", ""),
            )
        )

    def show_update_available_notice(self, latest_version: str) -> None:
        latest = str(latest_version or "").strip()
        if not latest:
            return
        QtWidgets.QMessageBox.warning(
            self,
            self._t(
                "dialog_update_available_title",
                "Update Available",
            ),
            self._t(
                "dialog_update_available_body",
                "A newer version is available.\n\n"
                "Current version: v{current}\n"
                "Latest version: v{latest}\n\n"
                "Press OK to continue with the current version.",
                current=getattr(config, "__version__", ""),
                latest=latest,
            ),
            QtWidgets.QMessageBox.StandardButton.Ok,
        )

    def _init_state(self) -> None:
        """Initialize internal state (kept out of `__init__` for readability)."""
        self._closing: bool = False
        self._plot_frozen: bool = False
        self._plot_refresh_tick: int = 0
        # Legacy: keep internal plot budget string for debugging/perf; no longer shown in UI label.
        self._plot_budget_status: str = ""
        self._plot_dyn_every: int = 1
        self._plot_last_refresh_ms: float = 0.0
        self._plot_last_tick_monotonic_s: float = 0.0
        self._plot_loop_lag_ms: float = 0.0
        self._plot_fast_rendering: bool = True
        self._signal_status_refresh_interval_s: float = 0.25
        self._signal_status_last_refresh_monotonic_s: float = 0.0
        self._signal_status_last_refresh_ms: float = 0.0
        self._signal_status_ui_cache: dict[str, object] = {}
        self._last_device_update_ms: float = 0.0

        self._recorder: RecordingSession | None = None
        self._recording: bool = False
        self._recording_visual_active: bool = False
        self._signals_session_start_monotonic_s: float | None = None
        self._recording_start_monotonic_s: float | None = None
        self._last_recording_duration_s: float | None = None

        # Recording settings (UI-controlled).
        self._rec_out_dir: str = str(Path.home() / str(getattr(config, "DEFAULT_REC_OUT_DIRNAME", "rr_data")))
        self._rec_emg_fields_all: tuple[str, ...] = tuple(getattr(config, "REC_EMG_FIELDS_ALL", ()))
        self._rec_imu_fields_all: tuple[str, ...] = tuple(getattr(config, "REC_IMU_FIELDS_ALL", ()))
        self._rec_akr_fields_all: tuple[str, ...] = tuple(getattr(config, "REC_ROBOT_FIELDS_ALL", ()))
        # Default: select none (user chooses).
        self._rec_emg_fields_selected: set[str] = set()
        self._rec_imu_fields_selected: set[str] = set()
        self._rec_akr_fields_selected: set[str] = set()

        # Per-device plot origin (latched on first EMG/IMU data packet after Start Stream).
        self._device_origin_s: dict[str, float | None] = {}
        self._device_origin_armed_addrs: set[str] = set()
        self._device_origin_arm_monotonic_s: float = 0.0

        # Scenario page state.
        self._scenario_active_key: str | None = None
        self._scenario_controls: dict[str, ScenarioControlTile] = {}

    def _set_recording_visual_state(self, active: bool) -> None:
        active = bool(active)
        # Recording visual state transition order matters:
        # 1) avoid redundant repolish work, 2) update the dynamic QSS property,
        # 3) repolish + notify listeners (e.g., the AKR settings prompt).
        if bool(self._recording_visual_active) == active:
            return
        self._recording_visual_active = active
        self.setProperty("recordingActive", active)
        style = self.style()
        if style is not None:
            style.unpolish(self)
            style.polish(self)
        self.update()
        self.recording_visual_state_changed.emit(active)

    # ---------- UI ----------
    def _build_actions(self) -> None:
        self.action_scan = QtGui.QAction(self._t("action_scan", "Scan"), self)
        self.action_select_all = QtGui.QAction(
            self._t("action_select_all", "Select All"), self
        )
        self.action_select_none = QtGui.QAction(
            self._t("action_select_none", "Select None"), self
        )
        self.action_connect = QtGui.QAction(self._t("action_connect", "Connect"), self)
        self.action_disconnect = QtGui.QAction(
            self._t("action_disconnect", "Disconnect"), self
        )
        self.action_update = QtGui.QAction(
            self._t("action_update", "Update Info"), self
        )
        self.action_settings = QtGui.QAction(
            self._t("action_settings", "Settings…"), self
        )
        self.action_record_start = QtGui.QAction(
            self._t("action_record_start", "Start Record"), self
        )
        self.action_record_stop = QtGui.QAction(
            self._t("action_record_stop", "Stop Record"), self
        )
        self.action_time_sync = QtGui.QAction(
            self._t("action_time_sync", "Time Sync"), self
        )
        self.action_bulk_modes = QtGui.QAction(
            self._t("action_bulk_modes", "Bulk Mode Settings…"), self
        )
        # Streaming is controlled from the Signals tab only (not from Connect tab).
        self.action_stream_start = QtGui.QAction(
            self._t("action_stream_start", "Start Stream"), self
        )
        self.action_stream_stop = QtGui.QAction(
            self._t("action_stream_stop", "Stop Stream"), self
        )

    def _build_ui(self) -> None:
        # Main tabs
        self.tabs = QtWidgets.QTabWidget()
        self.setCentralWidget(self.tabs)
        self._build_language_corner_widget()

        build_connect_tab(self)
        build_signals_tab(self)
        build_scenario_tab(self)
        build_settings_tab(self)

        # Tab-changed behavior is owned by MainWindow (affects LED selection).
        self.tabs.currentChanged.connect(self._on_tab_changed)

        # Status bar
        self.status = QtWidgets.QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage(
            self._t(
                "status_backend",
                "Backend: {backend}",
                backend=self.controller.backend_kind,
            )
        )

        self._trace_colors = ["#4ea1ff", "#2ed573", "#ffa502", "#ff4757", "#9b59ff", "#00d2d3", "#e67e22"]
        self._trace_color_i = 0
        self._refresh_signal_device_list()
        self._refresh_scenario_device_list()
        self._sync_scenario_controls()
        self._update_signal_rx_status()
        # Per-cluster default palettes (rotate when creating new clusters).
        self._sig_group_palette: dict[str, dict[str, str]] = {}
        self._sig_palette_sets: list[dict[str, str]] = [
            {"X": "#ff4757", "Y": "#2ed573", "Z": "#4ea1ff", "W": "#c8d6e5"},  # red/green/blue (+W grey)
            {"X": "#9b59ff", "Y": "#00d2d3", "Z": "#e67e22", "W": "#d7e1ff"},  # purple/cyan/orange (+W light)
            {"X": "#f368e0", "Y": "#10ac84", "Z": "#54a0ff", "W": "#c8d6e5"},  # pink/teal/blue (+W grey)
            {"X": "#ee5253", "Y": "#c8d6e5", "Z": "#feca57", "W": "#d7e1ff"},  # red/grey/yellow (+W light)
        ]

