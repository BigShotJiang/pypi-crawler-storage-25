from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
from PyQt6 import QtCore, QtWidgets

from ..akr_feedback_catalog import (
    AKR_CLI_BOOLEAN_FIELDS,
    AKR_CLI_CHART_MODE_DEFS,
    AKR_CLI_DISCRETE_STATUS_FIELDS,
    AKR_TELEM_BUFFER_SOURCES,
)
from ..akr_feedback_buffers import resolve_akr_buffer
from ..widgets import SignalGroupControl


class SignalsPlotMixin:
    _SIGNALS_PRESET_SCHEMA = "signals_preset"
    _SIGNALS_PRESET_VERSION = 1
    _SIGNALS_PRESET_LAST_PATH_KEY = "signals_presets/last_path"
    _SIGNALS_PRESET_UI_YIELD_EVERY = 6

    def _signals_notify_user(self, text: str, *, timeout_ms: int = 6000) -> None:
        """Show a Signals preset message in both log panel and status bar."""
        self.log_view.append_line(str(text))
        try:
            self.status.showMessage(str(text), int(timeout_ms))
        except Exception:
            pass

    def _ensure_signals_preset_state(self) -> None:
        if not isinstance(getattr(self, "_signals_group_meta", None), dict):
            self._signals_group_meta = {}

    def _signals_selected_device_addr(self) -> str | None:
        addr = self.combo_sig_device.currentData()
        if not isinstance(addr, str) or not addr:
            return None
        return str(addr)

    def _signals_device_kind_for_addr(self, addr: str | None) -> str:
        if not addr:
            return self._t("device_default_name", "EMGS")
        dev = self.controller.manager.devices.get(str(addr))
        if not dev:
            return self._t("device_default_name", "EMGS")
        return str(
            getattr(
                getattr(dev, "params", None),
                "kind",
                self._t("device_default_name", "EMGS"),
            )
        ).upper()

    def _signals_remember_preset_path(self, path: str) -> None:
        try:
            self._ui_settings.setValue(self._SIGNALS_PRESET_LAST_PATH_KEY, str(path))
        except Exception:
            pass

    def _signals_last_preset_path(self) -> str:
        try:
            return str(self._ui_settings.value(self._SIGNALS_PRESET_LAST_PATH_KEY, "") or "").strip()
        except Exception:
            return ""

    def _signals_group_key_for_selection(self, addr: str, type_label: str, mode_label: str, axis_label: str) -> str:
        group_info = self._signal_presets_map.get(type_label, {})
        group_name = str(group_info.get("group", ""))
        parts = [group_name, str(mode_label)]
        if axis_label:
            parts.append(str(axis_label))
        return f"{addr}:{' • '.join(parts)}"

    def _signals_preset_load_start_dir(self) -> str:
        # Keep dialog behavior consistent with Settings profiles:
        # last-used path -> recording folder -> app default folder.
        current = self._signals_last_preset_path()
        start_dir = ""
        try:
            if current:
                p = Path(current)
                start_dir = str(p.parent if p.suffix else p)
        except Exception:
            start_dir = ""
        if not start_dir:
            # Keep fallback local and predictable to avoid blocking checks on
            # stale/unreachable mounts before the dialog even opens.
            start_dir = str(self._default_recording_dir())
        return str(start_dir)

    @staticmethod
    def _signals_file_dialog_options() -> QtWidgets.QFileDialog.Option:
        options = QtWidgets.QFileDialog.Option(0)
        if sys.platform.startswith("linux") or sys.platform.startswith("win"):
            options |= QtWidgets.QFileDialog.Option.DontUseNativeDialog
        return options

    def _signals_preset_save_start_path(self) -> str:
        # Save-as path policy mirrors Settings profiles:
        # reuse last-used file/dir when valid, otherwise fall back to recording/default dir
        # and suggest a timestamped file name.
        current = self._signals_last_preset_path()
        default_name = f"signals_preset_{time.strftime('%Y%m%d_%H%M%S')}.json"
        start_path = ""
        try:
            if current:
                p = Path(current)
                if not p.suffix:
                    start_path = str(p / default_name)
                else:
                    start_path = str(p)
        except Exception:
            start_path = ""
        if not start_path:
            base = str(self._default_recording_dir())
            return str(Path(base) / default_name)
        base = str(Path(start_path).parent or self._default_recording_dir())
        return str(Path(base) / str(Path(start_path).name))

    def _signals_preset_tile_snapshot(self, group: str) -> dict[str, Any] | None:
        self._ensure_signals_preset_state()
        meta = self._signals_group_meta.get(group)
        if not isinstance(meta, dict):
            return None
        cfg = self.multi_plot.get_group_config(group)
        if cfg is None:
            return None
        traces_payload = []
        for tr in self.multi_plot.traces_in_group(group):
            suffix = str(tr.key).split(":")[-1] if ":" in str(tr.key) else str(tr.key)
            traces_payload.append(
                {
                    "series_key_suffix": str(suffix),
                    "color": str(tr.color),
                }
            )
        return {
            "signal": {
                "type_label": str(meta.get("type_label", "")),
                "mode_label": str(meta.get("mode_label", "")),
                "axis_label": str(meta.get("axis_label", "")),
            },
            "group": {
                "y_min": float(cfg.y_min_raw),
                "y_max": float(cfg.y_max_raw),
                "scale": float(cfg.scale),
            },
            "traces": traces_payload,
        }

    def _signals_write_preset_json_atomic(self, path: str, payload: dict[str, Any]) -> None:
        out_path = Path(path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = out_path.with_name(f".{out_path.name}.tmp-{time.time_ns()}")
        try:
            tmp_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            tmp_path.replace(out_path)
        finally:
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except Exception:
                pass

    def _signals_preset_save_clicked(self) -> None:
        self._ensure_signals_preset_state()
        addr = self._signals_selected_device_addr()
        if not addr:
            self.log_view.append_line(
                self._t(
                    "log_signals_preset_no_device",
                    "Signals preset: no device selected",
                )
            )
            return
        groups = self.multi_plot.list_groups()
        if not groups:
            self.log_view.append_line(
                self._t(
                    "log_signals_preset_nothing_to_save",
                    "Signals preset: nothing to save (no tiles)",
                )
            )
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            self._t("dialog_save_signals_preset", "Save Signals Preset"),
            self._signals_preset_save_start_path(),
            self._t("file_filter_json_all", "JSON (*.json);;All files (*)"),
            options=self._signals_file_dialog_options(),
        )
        if not path:
            return
        if not path.lower().endswith(".json"):
            path = path + ".json"

        tiles = []
        skipped = 0
        for group in groups:
            tile = self._signals_preset_tile_snapshot(group)
            if tile is None:
                skipped += 1
                continue
            sig = tile.get("signal", {})
            if not all(str(sig.get(k, "")).strip() for k in ("type_label", "mode_label")):
                skipped += 1
                continue
            tiles.append(tile)
        if not tiles:
            self.log_view.append_line(
                self._t(
                    "log_signals_preset_save_failed_empty",
                    "Signals preset: save failed (no serializable tiles)",
                )
            )
            return

        payload = {
            "schema": self._SIGNALS_PRESET_SCHEMA,
            "version": self._SIGNALS_PRESET_VERSION,
            "device_kind": self._signals_device_kind_for_addr(addr),
            "created_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "tiles": tiles,
        }
        try:
            self._signals_write_preset_json_atomic(path, payload)
        except Exception as e:
            self.log_view.append_line(
                self._t(
                    "log_signals_preset_save_failed",
                    "Signals preset: failed to save: {error}",
                    error=e,
                )
            )
            return
        self._signals_remember_preset_path(path)
        self.log_view.append_line(
            self._t(
                "log_signals_preset_saved",
                "Signals preset: saved {saved} tile(s) to {path}",
                saved=len(tiles),
                path=path,
            )
            + (
                self._t("log_signals_preset_skipped_suffix", " ({count} skipped)", count=skipped)
                if skipped
                else ""
            )
        )

    def _signals_validate_loaded_preset(self, payload: Any) -> tuple[dict[str, Any] | None, str | None]:
        if not isinstance(payload, dict):
            return None, "file content must be a JSON object"
        schema = str(payload.get("schema", "")).strip()
        if schema != self._SIGNALS_PRESET_SCHEMA:
            return None, f"unsupported schema '{schema or '<missing>'}'"
        try:
            version = int(payload.get("version", 0))
        except Exception:
            return None, "version must be an integer"
        if version != self._SIGNALS_PRESET_VERSION:
            return None, f"unsupported version {version}"
        tiles = payload.get("tiles")
        if not isinstance(tiles, list):
            return None, "missing or invalid tiles list"
        return payload, None

    def _signals_apply_loaded_preset(self, *, addr: str, payload: dict[str, Any]) -> tuple[int, int]:
        total = 0
        loaded = 0
        self._remove_all_traces()

        # Ordered, replace-all apply flow:
        # 1) add each tile by logical selection labels
        # 2) restore group config (y/scale)
        # 3) restore per-trace color overrides by series suffix
        for tile in payload.get("tiles", []):
            if not isinstance(tile, dict):
                continue
            total += 1
            signal = tile.get("signal", {}) if isinstance(tile.get("signal"), dict) else {}
            type_label = str(signal.get("type_label", "")).strip()
            mode_label = str(signal.get("mode_label", "")).strip()
            axis_label = str(signal.get("axis_label", ""))
            if not type_label or not mode_label:
                continue
            if not self._signals_add_trace_by_labels(addr, type_label, mode_label, axis_label):
                continue

            group = self._signals_group_key_for_selection(addr, type_label, mode_label, axis_label)
            cfg_data = tile.get("group", {}) if isinstance(tile.get("group"), dict) else {}
            try:
                self.multi_plot.set_group_config(
                    group,
                    y_min=float(cfg_data.get("y_min")),
                    y_max=float(cfg_data.get("y_max")),
                    scale=float(cfg_data.get("scale")),
                )
            except Exception:
                pass

            traces = self.multi_plot.traces_in_group(group)
            by_suffix = {
                (str(tr.key).split(":")[-1] if ":" in str(tr.key) else str(tr.key)): tr.key
                for tr in traces
            }
            for tr_saved in tile.get("traces", []) if isinstance(tile.get("traces"), list) else []:
                if not isinstance(tr_saved, dict):
                    continue
                suffix = str(tr_saved.get("series_key_suffix", "")).strip()
                color = str(tr_saved.get("color", "")).strip()
                trace_key = by_suffix.get(suffix)
                if trace_key and color:
                    self.multi_plot.set_trace_color(trace_key, color)
            loaded += 1
            if loaded % int(self._SIGNALS_PRESET_UI_YIELD_EVERY) == 0:
                # Large presets can perform hundreds of UI updates in one go.
                # Yield periodically so the GUI stays responsive while apply continues.
                QtWidgets.QApplication.processEvents(
                    QtCore.QEventLoop.ProcessEventsFlag.ExcludeUserInputEvents
                )

        self._sync_signal_group_controls()
        return loaded, total

    def _signals_preset_load_clicked(self) -> None:
        addr = self._signals_selected_device_addr()
        if not addr:
            self._signals_notify_user(
                self._t(
                    "log_signals_preset_no_device",
                    "Signals preset: no device selected",
                ),
            )
            return
        kind = self._signals_device_kind_for_addr(addr)
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            self._t("dialog_load_signals_preset", "Load Signals Preset"),
            self._signals_preset_load_start_dir(),
            self._t("file_filter_json_all", "JSON (*.json);;All files (*)"),
            options=self._signals_file_dialog_options(),
        )
        if not path:
            return
        try:
            payload = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception as e:
            self._signals_notify_user(
                self._t(
                    "log_signals_preset_load_failed",
                    "Signals preset: failed to load: {error}",
                    error=e,
                )
            )
            return

        preset, err = self._signals_validate_loaded_preset(payload)
        if preset is None:
            self._signals_notify_user(
                self._t(
                    "log_signals_preset_invalid",
                    "Signals preset: invalid file ({error})",
                    error=err,
                )
            )
            return
        file_kind = str(preset.get("device_kind", "")).strip().upper()
        if file_kind and file_kind != kind:
            self._signals_notify_user(
                self._t(
                    "log_signals_preset_kind_mismatch",
                    "Signals preset: device kind mismatch (file={file_kind}, selected={selected_kind})",
                    file_kind=file_kind,
                    selected_kind=kind,
                )
            )
            return

        loaded, total = self._signals_apply_loaded_preset(addr=addr, payload=preset)
        self._signals_remember_preset_path(path)
        # Preset load has multiple outcomes after replace-all apply:
        # 1) file has no usable tiles, 2) 0 tiles applied, 3) partial apply, 4) full apply.
        # Distinguish these so users can quickly tell why the page looks unchanged or emptied.
        if total <= 0:
            self._signals_notify_user(
                self._t(
                    "log_signals_preset_loaded_empty",
                    "Signals preset: file has no valid tiles to apply ({path})",
                    path=path,
                )
            )
            return
        if loaded <= 0:
            self._signals_notify_user(
                self._t(
                    "log_signals_preset_loaded_zero",
                    "Signals preset: loaded 0/{total} tile(s); no entries matched current Signals options ({path})",
                    total=total,
                    path=path,
                )
            )
            return
        if loaded < total:
            self._signals_notify_user(
                self._t(
                    "log_signals_preset_loaded_partial",
                    "Signals preset: partially loaded {loaded}/{total} tile(s) from {path}",
                    loaded=loaded,
                    total=total,
                    path=path,
                )
            )
            return
        self._signals_notify_user(
            self._t(
                "log_signals_preset_loaded",
                "Signals preset: loaded {loaded}/{total} tile(s) from {path}",
                loaded=loaded,
                total=total,
                path=path,
            )
        )

    def _signals_add_trace_by_labels(self, addr: str, type_label: str, mode_label: str, axis_label: str) -> bool:
        """Drive the existing combobox UI + `_add_trace_from_ui()` using text labels.

        Returns True if a trace/group was added (best-effort), False if selection failed.
        """

        def _set_combo_by_data(combo, want) -> bool:
            for i in range(combo.count()):
                if combo.itemData(i) == want:
                    combo.setCurrentIndex(i)
                    return True
            return False

        def _set_combo_by_text(combo, want: str) -> bool:
            want = str(want)
            for i in range(combo.count()):
                if str(combo.itemText(i)) == want:
                    combo.setCurrentIndex(i)
                    return True
            return False

        def _set_combo_by_data_str_ci(combo, want: str) -> bool:
            want = str(want).strip().lower()
            for i in range(combo.count()):
                v = combo.itemData(i)
                if isinstance(v, str) and v.strip().lower() == want:
                    combo.setCurrentIndex(i)
                    return True
            return False

        # Select device (if needed).
        try:
            if str(self.combo_sig_device.currentData() or "") != str(addr):
                # Prefer matching on itemData (address stored as data).
                if not _set_combo_by_data(self.combo_sig_device, str(addr)):
                    # Fallback: match visible text if needed.
                    _set_combo_by_text(self.combo_sig_device, str(addr))
        except Exception:
            pass

        # Type is stored as itemData (type label string).
        if not _set_combo_by_data(self.combo_sig_type, type_label):
            # Some items may have data==label but with different object identity; try case-insensitive match.
            if not _set_combo_by_data_str_ci(self.combo_sig_type, type_label):
                return False

        # Mode combo items are dicts in itemData; use visible text.
        if not _set_combo_by_text(self.combo_sig_mode, mode_label):
            return False

        # Axis items use axis label as both text and data; match text.
        if axis_label:
            if not _set_combo_by_text(self.combo_sig_axis, axis_label):
                # Case-insensitive fallback for axes like "state" / "STATE".
                want = str(axis_label).strip().lower()
                for i in range(self.combo_sig_axis.count()):
                    if str(self.combo_sig_axis.itemText(i)).strip().lower() == want:
                        self.combo_sig_axis.setCurrentIndex(i)
                        break

        before_groups = set(self.multi_plot.list_groups())
        before_traces = self.multi_plot.trace_count()
        try:
            self._add_trace_from_ui()
        except Exception:
            return False
        after_groups = set(self.multi_plot.list_groups())
        after_traces = self.multi_plot.trace_count()
        return (len(after_groups) > len(before_groups)) or (int(after_traces) > int(before_traces))

    def _init_signal_presets_map(self) -> None:
        self._signal_presets_map = {
            "Electromyography (EMG)": {
                "group": "EMG",
                "modes": [
                    {
                        "label": "Raw",
                        "data": {"mode": "raw"},
                        "axes": [
                            "Raw only",
                            "Raw + Packet RMS overlay",
                        ],
                    },
                    {"label": "Packet RMS (10 Hz)", "data": {"mode": "pkt_rms"}},
                    {"label": "SNR", "data": {"mode": "snr"}},
                ]
            },
            "Accelerometer (ACC)": {
                "group": "ACC",
                "modes": [
                    {"label": "Raw", "data": {"mode": "raw"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "Calibrated", "data": {"mode": "cal"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "Linear", "data": {"mode": "linear"}, "axes": ["XYZ", "X", "Y", "Z"]},
                ]
            },
            "Gyroscope (GYR)": {
                "group": "GYR",
                "modes": [
                    {"label": "Raw", "data": {"mode": "raw"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "Calibrated", "data": {"mode": "cal"}, "axes": ["XYZ", "X", "Y", "Z"]},
                ]
            },
            "Magnetometer (MAG)": {
                "group": "MAG",
                "modes": [
                    {"label": "Uncalibrated", "data": {"mode": "uncal"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "Calibrated", "data": {"mode": "cal"}, "axes": ["XYZ", "X", "Y", "Z"]},
                ]
            },
            "Quaternion": {
                "group": "QUAT",
                "modes": [
                    {"label": "Game rotation vector", "data": {"mode": "game"}, "axes": ["WXYZ", "W", "X", "Y", "Z"]},
                    {"label": "Geomag rotation vector", "data": {"mode": "geomag"}, "axes": ["WXYZ", "W", "X", "Y", "Z"]},
                ]
            },
            "Processed Data": {
                "group": "PROCESSED",
                "modes": [
                    {
                        "label": "EMG RMS Envelope",
                        "data": {"mode": "emg_env"},
                        "axes": [
                            "RMS Envelope only",
                            "Raw EMG + RMS Envelope Overlay",
                        ],
                    },
                    {
                        "label": "EMG Frequency Features",
                        "data": {"mode": "emg_freq"},
                        "axes": [
                            "Median Frequency (MDF)",
                            "Mean Frequency (MNF)",
                        ],
                    },
                    {
                        "label": "EMG Spectrum (PSD)",
                        "data": {"mode": "emg_psd"},
                        "axes": [
                            "0–500 Hz mapped to 0–3 s",
                        ],
                    },
                    {
                        "label": "EMG Spectrum (relative power)",
                        "data": {"mode": "emg_psd_lin"},
                        "axes": [
                            "0–500 Hz mapped to 0–3 s",
                        ],
                    },
                    {
                        "label": "Fatigue (unsupervised)",
                        "data": {"mode": "emg_fatigue"},
                        "axes": [
                            "Score (0–1)",
                            "Confidence (0–1)",
                            "Score + Confidence overlay",
                        ],
                    },
                    {
                        "label": "Respiratory EMG (ECG filtered)",
                        "data": {"mode": "emg_ecg_clean"},
                        "axes": [
                            "ECG-filtered EMG only",
                            "Raw + ECG-filtered Overlay",
                            "Estimated ECG artifact only",
                        ],
                    },
                ]
            },
            "AKR: Walk": {
                "group": "ROBOT_WALK",
                "modes": [
                    {"label": "Timing", "data": {"mode": "timing"}, "axes": ["exec_ms"]},
                    {"label": "Model", "data": {"mode": "model"}, "axes": ["out", "state", "tilt_forward_deg"]},
                    {"label": "IMU Acc", "data": {"mode": "acc"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "IMU Gyr", "data": {"mode": "gyr"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "IMU Mag", "data": {"mode": "mag"}, "axes": ["XYZ", "X", "Y", "Z"]},
                    {"label": "Motor", "data": {"mode": "motor"}, "axes": ["pos_rad", "vel_rad_s", "tq_nm", "temp_c", "vbus_v"]},
                    {"label": "Health", "data": {"mode": "health"}, "axes": ["pattern", "err_code", "fb_age_ms"]},
                ],
            },
            "AKR: Motor": {
                "group": "ROBOT_MOTOR",
                "modes": [
                    {"label": "Timing", "data": {"mode": "timing"}, "axes": ["dt_ms", "fid"]},
                    {"label": "Motor", "data": {"mode": "motor"}, "axes": ["pos_rad", "vel_rad_s", "tq_nm", "temp_c", "vbus_v"]},
                    {"label": "Health", "data": {"mode": "health"}, "axes": ["pattern", "err_code", "fb_age_ms"]},
                ],
            },
            "AKR: CPM": {
                "group": "ROBOT_CPM",
                "modes": [
                    {"label": "State", "data": {"mode": "state"}, "axes": ["cpm_state", "dir", "blocked_event", "blocked_consecutive"]},
                    {"label": "Command", "data": {"mode": "cmd"}, "axes": ["cmd_spd_rad_s"]},
                    {"label": "Motor", "data": {"mode": "motor"}, "axes": ["pos_rad", "vel_rad_s", "tq_nm", "temp_c", "vbus_v"]},
                    {"label": "Limits", "data": {"mode": "limits"}, "axes": ["df_limit_rad", "pf_limit_rad"]},
                    {"label": "Progress", "data": {"mode": "progress"}, "axes": ["elapsed_s", "remaining_s", "has_remaining", "repetition_count"]},
                    {"label": "Health", "data": {"mode": "health"}, "axes": ["pattern", "err_code", "fb_age_ms"]},
                ],
            },
            "AKR: Measure": {
                "group": "ROBOT_MEASURE",
                "modes": [
                    {"label": "State", "data": {"mode": "state"}, "axes": ["measure_state", "dir", "blocked", "result_flags"]},
                    {"label": "Flags", "data": {"mode": "flags"}, "axes": ["prom_df_valid", "prom_pf_valid", "arom_valid", "seq_active", "arom_running"]},
                    {"label": "Motor", "data": {"mode": "motor"}, "axes": ["pos_rad", "vel_rad_s", "tq_nm", "temp_c", "vbus_v"]},
                    {"label": "Results", "data": {"mode": "results"}, "axes": ["prom_df_end_rad", "prom_pf_end_rad", "arom_df_max_rad", "arom_pf_min_rad"]},
                    {"label": "Health", "data": {"mode": "health"}, "axes": ["pattern", "err_code", "fb_age_ms"]},
                ],
            },
            "AKR: Config": {
                "group": "ROBOT_CFG",
                "modes": [
                    {"label": "Config", "data": {"mode": "config"}, "axes": ["cfg_gait_model", "cfg_gait_mode", "cfg_side_is_left"]},
                    {"label": "Assist", "data": {"mode": "assist"}, "axes": ["cfg_df_assist_pct", "cfg_pf_assist_pct"]},
                    {"label": "DF", "data": {"mode": "df"}, "axes": ["cfg_df_torque", "cfg_df_angle", "cfg_df_speed", "cfg_df_kp", "cfg_df_kd"]},
                    {"label": "PF", "data": {"mode": "pf"}, "axes": ["cfg_pf_torque", "cfg_pf_angle", "cfg_pf_speed", "cfg_pf_kp", "cfg_pf_kd"]},
                    {"label": "CPM", "data": {"mode": "cpm"}, "axes": ["cfg_cpm_target_df_rad", "cfg_cpm_target_pf_rad", "cfg_cpm_speed_to_df_rad_s", "cfg_cpm_speed_to_pf_rad_s", "cfg_cpm_block_tq_nm", "cfg_cpm_wait_to_df_ms", "cfg_cpm_wait_to_pf_ms"]},
                ],
            },
            "AKR: CLI Feedback": {
                "group": "ROBOT_CLI",
                "modes": [
                    {"label": mode_label, "data": {"mode": mode_key}, "axes": list(mode_axes)}
                    for mode_key, mode_label, mode_axes in AKR_CLI_CHART_MODE_DEFS
                ],
            },
        }

    def _populate_signal_type_combo(self) -> None:
        is_akr = False
        try:
            addr = self.combo_sig_device.currentData()
            dev = self.controller.manager.devices.get(str(addr)) if isinstance(addr, str) else None
            is_akr = self.controller.manager.is_akr_device_obj(dev) if dev else False
        except Exception:
            is_akr = False
        self.combo_sig_type.blockSignals(True)
        self.combo_sig_type.clear()
        self.combo_sig_type.addItem(
            self._t("select_type_placeholder", "Select Type..."),
            None,
        )
        labels = list(self._signal_presets_map.keys())
        # AKR devices: keep the selector minimal (no EMG/QUAT).
        if is_akr:
            labels = [
                "AKR: Motor",
                "AKR: Walk",
                "AKR: CPM",
                "AKR: Measure",
                "AKR: Config",
                "AKR: CLI Feedback",
            ]
        else:
            # Robot telemetry is AKR-specific; hide these for EMGS devices to reduce confusion.
            labels = [l for l in labels if not str(l).startswith("AKR:")]
        for label in labels:
            if label in self._signal_presets_map:
                self.combo_sig_type.addItem(label, label)
        self.combo_sig_type.blockSignals(False)
        # Reset dependents
        self._on_signal_type_changed()

    def _on_signal_type_changed(self) -> None:
        type_label = self.combo_sig_type.currentData()

        self.combo_sig_mode.blockSignals(True)
        self.combo_sig_mode.clear()
        self.combo_sig_mode.setEnabled(False)

        self.combo_sig_axis.blockSignals(True)
        self.combo_sig_axis.clear()
        self.combo_sig_axis.setEnabled(False)

        if not type_label:
            self.combo_sig_mode.blockSignals(False)
            self.combo_sig_axis.blockSignals(False)
            return

        group_info = self._signal_presets_map.get(type_label)
        if not group_info:
            self.combo_sig_mode.blockSignals(False)
            self.combo_sig_axis.blockSignals(False)
            return
        modes = group_info.get("modes", [])
        # If AKR device is selected, hide duplicate/unsupported modes to reduce clutter.
        try:
            addr = self.combo_sig_device.currentData()
            dev = self.controller.manager.devices.get(str(addr)) if isinstance(addr, str) else None
            is_akr = self.controller.manager.is_akr_device_obj(dev) if dev else False
        except Exception:
            is_akr = False
        if is_akr:
            grp = str(group_info.get("group") or "").upper()
            if grp in {"ACC", "GYR", "MAG"}:
                # Keep only the calibrated flavor for AKR (raw/uncal/linear are duplicates or unsupported).
                modes = [m for m in modes if str(m.get("data", {}).get("mode", "")).lower() == "cal"]
        if modes:
            self.combo_sig_mode.setEnabled(True)
            for m in modes:
                self.combo_sig_mode.addItem(m["label"], m)

            # Select first item by default if appropriate
            if self.combo_sig_mode.count() > 0:
                self.combo_sig_mode.setCurrentIndex(0)
                # Manually trigger mode update since we blocked signals or want to force update
                self._on_signal_mode_changed()

        self.combo_sig_mode.blockSignals(False)
        self.combo_sig_axis.blockSignals(False)

    def _on_signal_mode_changed(self) -> None:
        mode_info = self.combo_sig_mode.currentData()

        self.combo_sig_axis.blockSignals(True)
        self.combo_sig_axis.clear()
        self.combo_sig_axis.setEnabled(False)

        if not mode_info:
            self.combo_sig_axis.blockSignals(False)
            return

        axes = mode_info.get("axes", [])
        if axes:
            self.combo_sig_axis.setEnabled(True)
            for ax in axes:
                self.combo_sig_axis.addItem(ax, ax)
            if self.combo_sig_axis.count() > 0:
                self.combo_sig_axis.setCurrentIndex(0)

        self.combo_sig_axis.blockSignals(False)

    def _default_group_config_for_preset(self, preset: object) -> tuple[float, float, float]:
        # Defaults are per-cluster; user can override in the right panel.
        if isinstance(preset, dict):
            grp = (preset.get("group") or "").upper()
            mode = (preset.get("mode") or "").lower()
            axis = (preset.get("axis") or "").lower()
            if grp == "EMG":
                if mode == "pkt_rms":
                    # DSP encodes packet RMS as 0..3 V.
                    return 0.0, 3.0, 1.0
                if mode == "snr":
                    return 0.0, 255.0, 1.0
                return -2.0, 2.0, 1.0
            if grp == "ACC":
                if mode == "raw":
                    return -2000.0, 2000.0, 1.0
                return -2.0, 2.0, 100.0
            if grp == "GYR":
                if mode == "raw":
                    return -2000.0, 2000.0, 1.0
                return -200.0, 200.0, 1.0
            if grp == "MAG":
                return -100.0, 100.0, 10.0
            if grp == "QUAT":
                return -1.0, 1.0, 1.0
            if grp == "PROCESSED":
                # Processed EMG envelope shares EMG scale.
                if mode == "emg_env":
                    return -2.0, 2.0, 1.0
                if mode == "emg_freq":
                    return 0.0, 250.0, 1.0
                if mode == "emg_psd":
                    return -80.0, 0.0, 1.0
                if mode == "emg_psd_lin":
                    return 0.0, 1.0, 1.0
                if mode == "emg_fatigue":
                    return 0.0, 1.0, 1.0
                if mode == "emg_ecg_clean":
                    return -2.0, 2.0, 1.0
            if grp in {"ROBOT_WALK", "ROBOT_CPM", "ROBOT_TEST", "ROBOT_MEASURE", "ROBOT_CFG"}:
                if mode in {"timing", "model", "health"}:
                    return 0.0, 5.0, 10.0
                if mode == "config":
                    if axis in {"cfg_side_is_left"}:
                        return 0.0, 1.0, 1.0
                    if axis in {"cfg_gait_mode"}:
                        return 0.0, 2.0, 1.0
                    if axis in {"cfg_gait_model"}:
                        return 0.0, 8.0, 1.0
                    return 0.0, 5.0, 10.0
                if mode == "assist":
                    return 0.0, 100.0, 1.0
                if mode in {"df", "pf", "cpm"}:
                    return -3.0, 3.0, 1.0
                if mode == "state":
                    if axis in {"dir"}:
                        return -1.0, 1.0, 1.0
                    if axis in {"blocked"}:
                        return 0.0, 1.0, 1.0
                    if axis in {"blocked_event"}:
                        return 0.0, 1.0, 1.0
                    if axis in {"blocked_consecutive"}:
                        return 0.0, 16.0, 1.0
                    if axis in {"result_flags"}:
                        return 0.0, 31.0, 1.0
                    if axis in {"test_state", "measure_state", "cpm_state", "out", "state"}:
                        return -1.0, 8.0, 1.0
                    return 0.0, 5.0, 10.0
                if mode == "flags":
                    return 0.0, 1.0, 1.0
                if mode in {"acc"}:
                    return -2.0, 2.0, 100.0
                if mode in {"gyr"}:
                    return -200.0, 200.0, 1.0
                if mode in {"mag"}:
                    return -100.0, 100.0, 10.0
                if mode in {"motor", "cmd", "limits", "results", "progress"}:
                    if axis in {"pos_rad", "prom_df_end_rad", "prom_pf_end_rad", "arom_df_max_rad", "arom_pf_min_rad"}:
                        return -0.6, 0.6, 50.0
                    if axis in {"vel_rad_s"}:
                        return -10.0, 10.0, 5.0
                    if axis in {"tq_nm"}:
                        return -3.0, 3.0, 5.0
                    if axis in {"temp_c"}:
                        return 0.0, 50.0, 1.0
                    if axis in {"vbus_v"}:
                        return 0.0, 80.0, 1.0
                    if axis in {"elapsed_s"}:
                        return 0.0, 120.0, 1.0
                    if axis in {"remaining_s"}:
                        return 0.0, 120.0, 1.0
                    if axis in {"has_remaining"}:
                        return 0.0, 1.0, 1.0
                    if axis in {"repetition_count"}:
                        return 0.0, 50.0, 1.0
                    return -50.0, 50.0, 1.0
            if grp == "ROBOT_CLI":
                if axis in AKR_CLI_BOOLEAN_FIELDS:
                    return 0.0, 1.0, 1.0
                if axis in AKR_CLI_DISCRETE_STATUS_FIELDS:
                    return -1.0, 16.0, 1.0
                if axis.endswith("_rad"):
                    return -0.6, 0.6, 50.0
                if axis.endswith("_rad_s"):
                    return -10.0, 10.0, 5.0
                if axis.endswith("_nm") or axis in {"torque_nm"}:
                    return -3.0, 3.0, 5.0
                if axis in {"temp_c"}:
                    return 0.0, 60.0, 1.0
                if axis in {"vbus_v"}:
                    return 0.0, 80.0, 1.0
                if axis.endswith("_ms"):
                    return 0.0, 200.0, 1.0
                if axis in {"elapsed_s", "remaining_s", "repetition_count"}:
                    return 0.0, 120.0, 1.0
                if axis in {"has_remaining"}:
                    return 0.0, 1.0, 1.0
                return -50.0, 50.0, 1.0
            if grp == "ROBOT_MOTOR":
                if mode in {"health", "timing"}:
                    return 0.0, 5.0, 10.0
                if mode in {"motor"}:
                    if axis in {"pos_rad"}:
                        return -0.6, 0.6, 50.0
                    if axis in {"vel_rad_s"}:
                        return -10.0, 10.0, 5.0
                    if axis in {"tq_nm"}:
                        return -3.0, 3.0, 5.0
                    if axis in {"temp_c"}:
                        return 0.0, 50.0, 1.0
                    if axis in {"vbus_v"}:
                        return 0.0, 80.0, 1.0
                    return -50.0, 50.0, 1.0
        
        return -1.0, 1.0, 1.0

    def _add_trace_from_ui(self) -> None:
        self._ensure_signals_preset_state()
        addr = self.combo_sig_device.currentData()
        if not isinstance(addr, str) or not addr:
            self.log_view.append_line(
                self._t("log_signals_no_selected_device", "Signals: no device selected")
            )
            return

        type_label = self.combo_sig_type.currentData()
        mode_info = self.combo_sig_mode.currentData()
        axis_label = self.combo_sig_axis.currentData()

        if not type_label or not mode_info:
            self.log_view.append_line(
                self._t(
                    "log_signals_select_valid_type_mode",
                    "Signals: please select a valid signal type and mode",
                )
            )
            return

        # Reconstruct the equivalent of the old preset_data
        group_info = self._signal_presets_map.get(type_label, {})
        group_name = group_info.get("group", "")

        preset_data = dict(mode_info.get("data", {}))
        preset_data["group"] = group_name

        full_label_parts = [group_name]
        full_label_parts.append(mode_info["label"])

        if axis_label:
            preset_data["axis"] = axis_label
            full_label_parts.append(axis_label)

        preset_label = " • ".join(full_label_parts)
        preset_data["label"] = preset_label

        y_min, y_max, group_scale = self._default_group_config_for_preset(preset_data)

        # The rest is mostly the same, just using the new preset_label
        group = f"{addr}:{preset_label}"
        label = f"{preset_label}\n{addr}"
        is_new_group = group not in self.multi_plot.list_groups()
        if is_new_group and group not in self._sig_group_palette:
            pal = self._sig_palette_sets[len(self._sig_group_palette) % len(self._sig_palette_sets)]
            self._sig_group_palette[group] = dict(pal)
        group_meta = {
            "type_label": str(type_label),
            "mode_label": str(mode_info.get("label", "")),
            "axis_label": str(axis_label or ""),
        }

        def _remember_group_meta() -> None:
            if group in self.multi_plot.list_groups():
                self._signals_group_meta[group] = dict(group_meta)

        def points_from_deque(buf, idx: int, window_s: float, *, origin_s: float | None = None) -> tuple[np.ndarray, np.ndarray] | None:
            if not buf:
                return None
            t_end = float(buf[-1][0])
            t_min = t_end - float(window_s)
            pts: list[tuple[float, float]] = []
            for ts, samples in reversed(buf):
                if ts < t_min:
                    break
                if samples and idx < len(samples):
                    pts.append((float(ts), float(samples[idx])))
            if not pts:
                return None
            pts.reverse()
            t = np.fromiter((p[0] for p in pts), dtype=float, count=len(pts))
            y = np.fromiter((p[1] for p in pts), dtype=float, count=len(pts))
            if origin_s is not None and t.size:
                t = t - float(origin_s)
            return t, y

        axis_map = {"X": 0, "Y": 1, "Z": 2}
        axis_colors = self._sig_group_palette.get(group, {"X": "#ff4757", "Y": "#2ed573", "Z": "#4ea1ff"})

        def dev_or_none():
            return self.controller.manager.devices.get(addr)

        def prov_emg_raw() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.emg_buffer, 0, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_emg_pkt_rms() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return points_from_deque(dev.emg_packet_rms_buffer, 0, 3.0, origin_s=self._device_time_origin_s(addr)) if dev.emg_packet_rms_buffer else None

        def prov_emg_snr() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return points_from_deque(dev.emg_snr_buffer, 0, 3.0, origin_s=self._device_time_origin_s(addr)) if dev.emg_snr_buffer else None

        def prov_emg_env() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return points_from_deque(dev.emg_rms_buffer, 0, 3.0, origin_s=self._device_time_origin_s(addr)) if dev.emg_rms_buffer else None

        def prov_emg_mdf() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return points_from_deque(dev.emg_median_freq_buffer, 0, 6.0, origin_s=self._device_time_origin_s(addr)) if dev.emg_median_freq_buffer else None

        def prov_emg_mnf() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return points_from_deque(dev.emg_mean_freq_buffer, 0, 6.0, origin_s=self._device_time_origin_s(addr)) if dev.emg_mean_freq_buffer else None

        def _map_spectrum_to_time_axis(
            dev: object, f: np.ndarray, y: np.ndarray, *, f_max: float = 500.0, win_s: float = 3.0
        ) -> tuple[np.ndarray, np.ndarray] | None:
            if f is None or y is None or len(f) == 0:
                return None
            f = np.asarray(f, dtype=float)
            y = np.asarray(y, dtype=float)
            # Shift spectrum into the current rolling x-window so it stays visible.
            origin_s = self._device_time_origin_s(addr)
            t_end = None
            buf = getattr(dev, "emg_buffer", None)
            if buf:
                t_end = float(buf[-1][0])
                if origin_s is not None:
                    t_end = t_end - float(origin_s)
            if t_end is None:
                t_end = float(win_s)
            x0 = float(t_end) - float(win_s)
            t = x0 + (f / float(f_max)) * float(win_s)
            return t, y

        def prov_emg_psd_db() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            spec = getattr(dev, "emg_spectrum_last", None)
            if not spec:
                return None
            f, p_db = spec
            return _map_spectrum_to_time_axis(dev, f, p_db)

        def prov_emg_psd_lin() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            spec = getattr(dev, "emg_spectrum_last_linear", None)
            if not spec:
                return None
            f, p_rel = spec
            return _map_spectrum_to_time_axis(dev, f, p_rel)

        def prov_emg_fatigue_score() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return (
                points_from_deque(dev.emg_fatigue_score_buffer, 0, 12.0, origin_s=self._device_time_origin_s(addr))
                if getattr(dev, "emg_fatigue_score_buffer", None)
                else None
            )

        def prov_emg_fatigue_conf() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return (
                points_from_deque(dev.emg_fatigue_conf_buffer, 0, 12.0, origin_s=self._device_time_origin_s(addr))
                if getattr(dev, "emg_fatigue_conf_buffer", None)
                else None
            )

        def prov_emg_ecg_clean() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return (
                points_from_deque(dev.emg_ecg_clean_buffer, 0, 3.0, origin_s=self._device_time_origin_s(addr))
                if getattr(dev, "emg_ecg_clean_buffer", None)
                else None
            )

        def prov_emg_ecg_artifact() -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            return (
                points_from_deque(dev.emg_ecg_artifact_buffer, 0, 3.0, origin_s=self._device_time_origin_s(addr))
                if getattr(dev, "emg_ecg_artifact_buffer", None)
                else None
            )

        def prov_acc(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.acc_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_raw_acc(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.raw_acc_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_lin_acc(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.lin_acc_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_gyr(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.gyr_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_raw_gyr(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.raw_gyr_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_mag(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.mag_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_uncal_mag(i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            return points_from_deque(dev.uncal_mag_buffer, i, 3.0, origin_s=self._device_time_origin_s(addr)) if dev else None

        def prov_quat(buf_name: str, i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            buf = getattr(dev, buf_name, None)
            return points_from_deque(buf, i, 3.0, origin_s=self._device_time_origin_s(addr)) if buf is not None else None

        def prov_akr_scalar(buf_name: str) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            buf = resolve_akr_buffer(dev, buf_name)
            return points_from_deque(buf, 0, 6.0, origin_s=None) if buf is not None else None

        def prov_akr_scalar_any(buf_names: tuple[str, ...]) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            best_name = None
            best_ts = float("-inf")
            for bn in buf_names:
                buf = resolve_akr_buffer(dev, bn)
                if not buf:
                    continue
                try:
                    ts = float(buf[-1][0])
                except Exception:
                    continue
                if ts > best_ts:
                    best_ts = ts
                    best_name = bn
            if best_name is None:
                return None
            buf = resolve_akr_buffer(dev, best_name)
            return points_from_deque(buf, 0, 6.0, origin_s=None) if buf is not None else None

        def prov_akr_vec3(buf_name: str, i: int) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            buf = resolve_akr_buffer(dev, buf_name)
            return points_from_deque(buf, int(i), 6.0, origin_s=None) if buf is not None else None

        def prov_akr_cli_field(field_key: str) -> tuple[np.ndarray, np.ndarray] | None:
            dev = dev_or_none()
            if not dev:
                return None
            key = str(field_key).strip().lower()
            if not key:
                return None

            # Source routing for CLI-backed chart channels:
            # 1) Prefer rr_telem buffers when the field is part of binary telemetry.
            # 2) Fall back to runtime/show parser buffers for CLI-only fields.
            # 3) Pick the freshest available source so mode transitions don't leave stale traces.
            sources = AKR_TELEM_BUFFER_SOURCES.get(key)
            if sources:
                best_buf_name: str | None = None
                best_idx = 0
                best_ts = float("-inf")
                for buf_name, value_idx in sources:
                    buf = resolve_akr_buffer(dev, buf_name)
                    if not buf:
                        continue
                    try:
                        ts = float(buf[-1][0])
                    except Exception:
                        continue
                    if ts >= best_ts:
                        best_ts = ts
                        best_buf_name = str(buf_name)
                        best_idx = int(value_idx)
                if best_buf_name:
                    best_buf = resolve_akr_buffer(dev, best_buf_name)
                    if best_buf is not None:
                        return points_from_deque(best_buf, best_idx, 6.0, origin_s=None)

            runtime_map = getattr(getattr(dev, "akr", None), "akr_cli_feedback_buffer_by_key", None)
            if not isinstance(runtime_map, dict):
                return None
            runtime_buf = runtime_map.get(key)
            if runtime_buf is None:
                return None
            return points_from_deque(runtime_buf, 0, 6.0, origin_s=None)

        dev = dev_or_none()

        # Interpret preset selection via metadata.
        if not isinstance(preset_data, dict):
            preset_data = {}
        grp = (preset_data.get("group") or "").upper()
        mode = (preset_data.get("mode") or "").lower()
        ax = (preset_data.get("axis") or "").upper()

        if grp == "EMG":
            color = axis_colors.get("X", "#4ea1ff")
            if mode == "raw":
                variant = (preset_data.get("axis") or "").strip().lower()
                self.multi_plot.add_trace(
                    key=f"{group}:RAW",
                    label=label,
                    group=group,
                    color=color,
                    y_min=y_min,
                    y_max=y_max,
                    data_provider=prov_emg_raw,
                    pen_width=1.2,
                    scale=group_scale,
                )
                if "packet rms" in variant:
                    # Packet RMS may be empty until streaming starts; still allow adding the curve.
                    self.multi_plot.add_trace(
                        key=f"{group}:RMS",
                        label=label,
                        group=group,
                        color="#ffa502",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_pkt_rms,
                        pen_width=2.0,
                        pen_style=QtCore.Qt.PenStyle.DashLine,
                    )
            elif mode == "pkt_rms":
                # Allow adding even if buffer is empty; it will draw once data arrives.
                self.multi_plot.add_trace(key=f"{group}:RMS", label=label, group=group, color="#ffa502", y_min=y_min, y_max=y_max, data_provider=prov_emg_pkt_rms, pen_width=2.0, scale=group_scale)
            elif mode == "snr":
                # SNR is packet-based; allow adding even if buffer is empty.
                self.multi_plot.add_trace(key=f"{group}:SNR", label=label, group=group, color="#9b59b6", y_min=y_min, y_max=y_max, data_provider=prov_emg_snr, pen_width=2.0, scale=group_scale)
            else:
                self.log_view.append_line(f"Signals: unknown EMG mode: {mode}")

        elif grp == "PROCESSED":
            # Processed Data -> EMG RMS Envelope
            if mode == "emg_env":
                variant = (preset_data.get("axis") or "").strip().lower()
                if variant.startswith("raw"):
                    self.multi_plot.add_trace(
                        key=f"{group}:RAW",
                        label=label,
                        group=group,
                        color=axis_colors.get("X", "#4ea1ff"),
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_raw,
                        pen_width=1.2,
                        scale=group_scale,
                    )
                    self.multi_plot.add_trace(
                        key=f"{group}:ENV",
                        label=label,
                        group=group,
                        color="#ffa502",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_env,
                        pen_width=2.0,
                        pen_style=QtCore.Qt.PenStyle.DashLine,
                        scale=group_scale,
                        show_value_label=True,
                    )
                else:
                    self.multi_plot.add_trace(
                        key=f"{group}:ENV",
                        label=label,
                        group=group,
                        color="#ffa502",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_env,
                        pen_width=2.0,
                        scale=group_scale,
                        show_value_label=True,
                    )
            elif mode == "emg_freq":
                variant = (preset_data.get("axis") or "").strip().lower()
                prov = prov_emg_mdf
                key = "MDF"
                if "mean frequency" in variant and "power" not in variant:
                    prov = prov_emg_mnf
                    key = "MNF"
                self.multi_plot.add_trace(
                    key=f"{group}:{key}",
                    label=label,
                    group=group,
                    color="#54a0ff",
                    y_min=y_min,
                    y_max=y_max,
                    data_provider=prov,
                    pen_width=2.0,
                    scale=group_scale,
                    show_value_label=True,
                )
            elif mode == "emg_psd":
                # Map frequency axis (0..500Hz) into our 0..3s x-axis window.
                self.multi_plot.set_group_x_markers(group, [(float(hz) / 500.0) * 3.0 for hz in range(50, 501, 50)])
                self.multi_plot.add_trace(
                    key=f"{group}:PSD",
                    label=label,
                    group=group,
                    color="#c8d6e5",
                    y_min=y_min,
                    y_max=y_max,
                    data_provider=prov_emg_psd_db,
                    pen_width=2.0,
                    scale=1.0,
                )
            elif mode == "emg_psd_lin":
                # Map frequency axis (0..500Hz) into our 0..3s x-axis window.
                self.multi_plot.set_group_x_markers(group, [(float(hz) / 500.0) * 3.0 for hz in range(50, 501, 50)])
                self.multi_plot.add_trace(
                    key=f"{group}:PSD_REL",
                    label=label,
                    group=group,
                    color="#2ed573",
                    y_min=y_min,
                    y_max=y_max,
                    data_provider=prov_emg_psd_lin,
                    pen_width=2.0,
                    scale=1.0,
                    show_value_label=True,
                )
            elif mode == "emg_fatigue":
                variant = (preset_data.get("axis") or "").strip().lower()
                if "overlay" in variant:
                    self.multi_plot.add_trace(
                        key=f"{group}:FATIGUE",
                        label=label,
                        group=group,
                        color="#ffa502",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_fatigue_score,
                        pen_width=2.0,
                        scale=1.0,
                        show_value_label=True,
                    )
                    self.multi_plot.add_trace(
                        key=f"{group}:CONF",
                        label=label,
                        group=group,
                        color="#54a0ff",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_fatigue_conf,
                        pen_width=2.0,
                        pen_style=QtCore.Qt.PenStyle.DashLine,
                        scale=1.0,
                        show_value_label=False,
                    )
                elif "conf" in variant:
                    self.multi_plot.add_trace(
                        key=f"{group}:CONF",
                        label=label,
                        group=group,
                        color="#54a0ff",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_fatigue_conf,
                        pen_width=2.0,
                        scale=1.0,
                        show_value_label=True,
                    )
                else:
                    self.multi_plot.add_trace(
                        key=f"{group}:FATIGUE",
                        label=label,
                        group=group,
                        color="#ffa502",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_fatigue_score,
                        pen_width=2.0,
                        scale=1.0,
                        show_value_label=True,
                    )
            elif mode == "emg_ecg_clean":
                variant = (preset_data.get("axis") or "").strip().lower()
                if "raw +" in variant:
                    self.multi_plot.add_trace(
                        key=f"{group}:RAW",
                        label=label,
                        group=group,
                        color=axis_colors.get("X", "#4ea1ff"),
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_raw,
                        pen_width=1.2,
                        scale=group_scale,
                    )
                    self.multi_plot.add_trace(
                        key=f"{group}:ECG_CLEAN",
                        label=label,
                        group=group,
                        color="#2ed573",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_ecg_clean,
                        pen_width=2.0,
                        pen_style=QtCore.Qt.PenStyle.DashLine,
                        scale=group_scale,
                        show_value_label=True,
                    )
                elif "artifact" in variant:
                    self.multi_plot.add_trace(
                        key=f"{group}:ECG_ART",
                        label=label,
                        group=group,
                        color="#ff6b6b",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_ecg_artifact,
                        pen_width=2.0,
                        scale=group_scale,
                        show_value_label=True,
                    )
                else:
                    self.multi_plot.add_trace(
                        key=f"{group}:ECG_CLEAN",
                        label=label,
                        group=group,
                        color="#2ed573",
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=prov_emg_ecg_clean,
                        pen_width=2.0,
                        scale=group_scale,
                        show_value_label=True,
                    )
            else:
                self.log_view.append_line(f"Signals: unknown PROCESSED mode: {mode}")

        elif grp == "ROBOT_WALK":
            axis = (preset_data.get("axis") or "").strip().lower()
            if mode == "acc":
                buf_name = "akr_walk_acc_buffer"
                if ax == "XYZ":
                    for a in ("X", "Y", "Z"):
                        i = axis_map[a]
                        self.multi_plot.add_trace(
                            key=f"{group}:{a}",
                            label=label,
                            group=group,
                            color=axis_colors.get(a, "#4ea1ff"),
                            y_min=y_min,
                            y_max=y_max,
                            data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                            scale=group_scale,
                        )
                else:
                    i = axis_map.get(ax, 0)
                    self.multi_plot.add_trace(
                        key=f"{group}:{ax}",
                        label=label,
                        group=group,
                        color=axis_colors.get(ax, "#4ea1ff"),
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                        scale=group_scale,
                    )
                # IMPORTANT: keep right-panel tiles in sync even on early-return paths.
                _remember_group_meta()
                self._sync_signal_group_controls()
                return
            if mode == "gyr":
                buf_name = "akr_walk_gyr_buffer"
                if ax == "XYZ":
                    for a in ("X", "Y", "Z"):
                        i = axis_map[a]
                        self.multi_plot.add_trace(
                            key=f"{group}:{a}",
                            label=label,
                            group=group,
                            color=axis_colors.get(a, "#4ea1ff"),
                            y_min=y_min,
                            y_max=y_max,
                            data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                            scale=group_scale,
                        )
                else:
                    i = axis_map.get(ax, 0)
                    self.multi_plot.add_trace(
                        key=f"{group}:{ax}",
                        label=label,
                        group=group,
                        color=axis_colors.get(ax, "#4ea1ff"),
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                        scale=group_scale,
                    )
                # IMPORTANT: keep right-panel tiles in sync even on early-return paths.
                _remember_group_meta()
                self._sync_signal_group_controls()
                return
            if mode == "mag":
                buf_name = "akr_walk_mag_buffer"
                if ax == "XYZ":
                    for a in ("X", "Y", "Z"):
                        i = axis_map[a]
                        self.multi_plot.add_trace(
                            key=f"{group}:{a}",
                            label=label,
                            group=group,
                            color=axis_colors.get(a, "#4ea1ff"),
                            y_min=y_min,
                            y_max=y_max,
                            data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                            scale=group_scale,
                        )
                else:
                    i = axis_map.get(ax, 0)
                    self.multi_plot.add_trace(
                        key=f"{group}:{ax}",
                        label=label,
                        group=group,
                        color=axis_colors.get(ax, "#4ea1ff"),
                        y_min=y_min,
                        y_max=y_max,
                        data_provider=(lambda ii=i, bn=buf_name: prov_akr_vec3(bn, ii)),
                        scale=group_scale,
                    )
                # IMPORTANT: keep right-panel tiles in sync even on early-return paths.
                _remember_group_meta()
                self._sync_signal_group_controls()
                return

            scalar_map: dict[str, str] = {
                "dt_ms": "akr_walk_dt_ms_buffer",
                "exec_ms": "akr_walk_exec_ms_buffer",
                "fid": "akr_walk_fid_buffer",
                "out": "akr_walk_out_buffer",
                "state": "akr_walk_state_buffer",
                "tilt_forward_deg": "akr_walk_tilt_forward_deg_buffer",
                "pos_rad": "akr_walk_pos_rad_buffer",
                "vel_rad_s": "akr_walk_vel_rad_s_buffer",
                "tq_nm": "akr_walk_tq_nm_buffer",
                "temp_c": "akr_walk_temp_c_buffer",
                "vbus_v": "akr_walk_vbus_v_buffer",
                "pattern": "akr_walk_pattern_buffer",
                "err_code": "akr_walk_err_code_buffer",
                "fb_age_ms": "akr_walk_fb_age_ms_buffer",
            }
            buf = scalar_map.get(axis)
            if not buf:
                self.log_view.append_line("Signals: unknown AKR: Walk axis")
                return
            self.multi_plot.add_trace(
                key=f"{group}:{axis}",
                label=label,
                group=group,
                color="#00d2d3",
                y_min=y_min,
                y_max=y_max,
                data_provider=(lambda bn=buf: prov_akr_scalar(bn)),
                pen_width=2.0,
                scale=group_scale,
                show_value_label=True,
            )

        elif grp == "ROBOT_CPM":
            axis = (preset_data.get("axis") or "").strip().lower()
            scalar_map: dict[str, str] = {
                "dt_ms": "akr_cpm_dt_ms_buffer",
                "fid": "akr_cpm_fid_buffer",
                "cpm_state": "akr_cpm_state_buffer",
                "dir": "akr_cpm_dir_buffer",
                "blocked_event": "akr_cpm_blocked_event_buffer",
                "blocked_consecutive": "akr_cpm_blocked_consecutive_buffer",
                "cmd_spd_rad_s": "akr_cpm_cmd_spd_rad_s_buffer",
                "pos_rad": "akr_cpm_pos_rad_buffer",
                "vel_rad_s": "akr_cpm_vel_rad_s_buffer",
                "tq_nm": "akr_cpm_tq_nm_buffer",
                "temp_c": "akr_cpm_temp_c_buffer",
                "vbus_v": "akr_cpm_vbus_v_buffer",
                "pattern": "akr_cpm_pattern_buffer",
                "err_code": "akr_cpm_err_code_buffer",
                "fb_age_ms": "akr_cpm_fb_age_ms_buffer",
                "df_limit_rad": "akr_cpm_df_limit_rad_buffer",
                "pf_limit_rad": "akr_cpm_pf_limit_rad_buffer",
                "elapsed_s": "akr_cpm_elapsed_s_buffer",
                "remaining_s": "akr_cpm_remaining_s_buffer",
                "has_remaining": "akr_cpm_has_remaining_buffer",
                "repetition_count": "akr_cpm_repetition_count_buffer",
            }
            buf = scalar_map.get(axis)
            if not buf:
                self.log_view.append_line("Signals: unknown AKR: CPM axis")
                return
            self.multi_plot.add_trace(
                key=f"{group}:{axis}",
                label=label,
                group=group,
                color="#00d2d3",
                y_min=y_min,
                y_max=y_max,
                data_provider=(lambda bn=buf: prov_akr_scalar(bn)),
                pen_width=2.0,
                scale=group_scale,
                show_value_label=True,
            )

        elif grp == "ROBOT_CFG":
            axis = (preset_data.get("axis") or "").strip().lower()
            scalar_map: dict[str, str] = {
                "cfg_fid": "akr_cfg_fid_buffer",
                "cfg_gait_model": "akr_cfg_gait_model_buffer",
                "cfg_gait_mode": "akr_cfg_gait_mode_buffer",
                "cfg_side_is_left": "akr_cfg_side_is_left_buffer",
                "cfg_df_assist_pct": "akr_cfg_df_assist_pct_buffer",
                "cfg_pf_assist_pct": "akr_cfg_pf_assist_pct_buffer",
                "cfg_df_torque": "akr_cfg_df_torque_buffer",
                "cfg_df_angle": "akr_cfg_df_angle_buffer",
                "cfg_df_speed": "akr_cfg_df_speed_buffer",
                "cfg_df_kp": "akr_cfg_df_kp_buffer",
                "cfg_df_kd": "akr_cfg_df_kd_buffer",
                "cfg_pf_torque": "akr_cfg_pf_torque_buffer",
                "cfg_pf_angle": "akr_cfg_pf_angle_buffer",
                "cfg_pf_speed": "akr_cfg_pf_speed_buffer",
                "cfg_pf_kp": "akr_cfg_pf_kp_buffer",
                "cfg_pf_kd": "akr_cfg_pf_kd_buffer",
                "cfg_cpm_target_df_rad": "akr_cfg_cpm_target_df_rad_buffer",
                "cfg_cpm_target_pf_rad": "akr_cfg_cpm_target_pf_rad_buffer",
                "cfg_cpm_speed_to_df_rad_s": "akr_cfg_cpm_speed_to_df_rad_s_buffer",
                "cfg_cpm_speed_to_pf_rad_s": "akr_cfg_cpm_speed_to_pf_rad_s_buffer",
                "cfg_cpm_block_tq_nm": "akr_cfg_cpm_block_tq_nm_buffer",
                "cfg_cpm_wait_to_df_ms": "akr_cfg_cpm_wait_to_df_ms_buffer",
                "cfg_cpm_wait_to_pf_ms": "akr_cfg_cpm_wait_to_pf_ms_buffer",
            }
            buf = scalar_map.get(axis)
            if not buf:
                self.log_view.append_line("Signals: unknown AKR: Config axis")
                return
            self.multi_plot.add_trace(
                key=f"{group}:{axis}",
                label=label,
                group=group,
                color="#00d2d3",
                y_min=y_min,
                y_max=y_max,
                data_provider=(lambda bn=buf: prov_akr_scalar(bn)),
                pen_width=2.0,
                scale=group_scale,
                show_value_label=True,
            )

        elif grp == "ROBOT_CLI":
            axis = (preset_data.get("axis") or "").strip().lower()
            if not axis:
                self.log_view.append_line("Signals: unknown AKR: CLI Feedback axis")
                return
            self.multi_plot.add_trace(
                key=f"{group}:{axis}",
                label=label,
                group=group,
                color="#00d2d3",
                y_min=y_min,
                y_max=y_max,
                data_provider=(lambda field_key=axis: prov_akr_cli_field(field_key)),
                pen_width=2.0,
                scale=group_scale,
                show_value_label=True,
            )

        elif grp == "ROBOT_MOTOR":
            axis = (preset_data.get("axis") or "").strip().lower()
            scalar_map: dict[str, tuple[str, ...]] = {
                "dt_ms": ("akr_walk_dt_ms_buffer", "akr_cpm_dt_ms_buffer", "akr_test_dt_ms_buffer"),
                "fid": ("akr_walk_fid_buffer", "akr_cpm_fid_buffer", "akr_test_fid_buffer"),
                "pos_rad": ("akr_walk_pos_rad_buffer", "akr_cpm_pos_rad_buffer", "akr_test_pos_rad_buffer"),
                "vel_rad_s": ("akr_walk_vel_rad_s_buffer", "akr_cpm_vel_rad_s_buffer", "akr_test_vel_rad_s_buffer"),
                "tq_nm": ("akr_walk_tq_nm_buffer", "akr_cpm_tq_nm_buffer", "akr_test_tq_nm_buffer"),
                "temp_c": ("akr_walk_temp_c_buffer", "akr_cpm_temp_c_buffer", "akr_test_temp_c_buffer"),
                "vbus_v": ("akr_walk_vbus_v_buffer", "akr_cpm_vbus_v_buffer", "akr_test_vbus_v_buffer"),
                "pattern": ("akr_walk_pattern_buffer", "akr_cpm_pattern_buffer", "akr_test_pattern_buffer"),
                "err_code": ("akr_walk_err_code_buffer", "akr_cpm_err_code_buffer", "akr_test_err_code_buffer"),
                "fb_age_ms": ("akr_walk_fb_age_ms_buffer", "akr_cpm_fb_age_ms_buffer", "akr_test_fb_age_ms_buffer"),
            }
            buf_names = scalar_map.get(axis)
            if not buf_names:
                self.log_view.append_line("Signals: unknown AKR: Motor axis")
                return
            self.multi_plot.add_trace(
                key=f"{group}:{axis}",
                label=label,
                group=group,
                color="#00d2d3",
                y_min=y_min,
                y_max=y_max,
                data_provider=(lambda bns=buf_names: prov_akr_scalar_any(bns)),
                pen_width=2.0,
                scale=group_scale,
                show_value_label=True,
            )

        elif grp in {"ROBOT_TEST", "ROBOT_MEASURE"}:
            axis = (preset_data.get("axis") or "").strip().lower()
            scalar_map: dict[str, str] = {
                "dt_ms": "akr_test_dt_ms_buffer",
                "fid": "akr_test_fid_buffer",
                "measure_state": "akr_test_state_buffer",
                "test_state": "akr_test_state_buffer",
                "dir": "akr_test_dir_buffer",
                "blocked": "akr_test_blocked_buffer",
                "result_flags": "akr_test_result_flags_buffer",
                "pos_rad": "akr_test_pos_rad_buffer",
                "vel_rad_s": "akr_test_vel_rad_s_buffer",
                "tq_nm": "akr_test_tq_nm_buffer",
                "temp_c": "akr_test_temp_c_buffer",
                "vbus_v": "akr_test_vbus_v_buffer",
                "pattern": "akr_test_pattern_buffer",
                "err_code": "akr_test_err_code_buffer",
                "fb_age_ms": "akr_test_fb_age_ms_buffer",
                "prom_df_end_rad": "akr_test_prom_df_end_rad_buffer",
                "prom_pf_end_rad": "akr_test_prom_pf_end_rad_buffer",
                "arom_df_max_rad": "akr_test_arom_df_max_rad_buffer",
                "arom_pf_min_rad": "akr_test_arom_pf_min_rad_buffer",
                "prom_df_valid": "akr_test_flag_prom_df_valid_buffer",
                "prom_pf_valid": "akr_test_flag_prom_pf_valid_buffer",
                "arom_valid": "akr_test_flag_arom_valid_buffer",
                "seq_active": "akr_test_flag_seq_active_buffer",
                "arom_running": "akr_test_flag_arom_running_buffer",
            }
            buf = scalar_map.get(axis)
            if not buf:
                self.log_view.append_line("Signals: unknown AKR: Measure axis")
                return
            self.multi_plot.add_trace(
                key=f"{group}:{axis}",
                label=label,
                group=group,
                color="#00d2d3",
                y_min=y_min,
                y_max=y_max,
                data_provider=(lambda bn=buf: prov_akr_scalar(bn)),
                pen_width=2.0,
                scale=group_scale,
                show_value_label=True,
            )

        elif grp == "ACC":
            prov = {"raw": prov_raw_acc, "cal": prov_acc, "linear": prov_lin_acc}.get(mode)
            if prov is None:
                self.log_view.append_line(f"Signals: unknown ACC mode: {mode}")
            elif ax == "XYZ":
                for a in ("X", "Y", "Z"):
                    i = axis_map[a]
                    self.multi_plot.add_trace(key=f"{group}:{a}", label=label, group=group, color=axis_colors.get(a, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)
            else:
                i = axis_map.get(ax, 0)
                self.multi_plot.add_trace(key=f"{group}:{ax}", label=label, group=group, color=axis_colors.get(ax, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)

        elif grp == "GYR":
            prov = {"raw": prov_raw_gyr, "cal": prov_gyr}.get(mode)
            if prov is None:
                self.log_view.append_line(f"Signals: unknown GYR mode: {mode}")
            elif ax == "XYZ":
                for a in ("X", "Y", "Z"):
                    i = axis_map[a]
                    self.multi_plot.add_trace(key=f"{group}:{a}", label=label, group=group, color=axis_colors.get(a, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)
            else:
                i = axis_map.get(ax, 0)
                self.multi_plot.add_trace(key=f"{group}:{ax}", label=label, group=group, color=axis_colors.get(ax, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)

        elif grp == "MAG":
            prov = {"uncal": prov_uncal_mag, "cal": prov_mag}.get(mode)
            if prov is None:
                self.log_view.append_line(f"Signals: unknown MAG mode: {mode}")
            elif ax == "XYZ":
                for a in ("X", "Y", "Z"):
                    i = axis_map[a]
                    self.multi_plot.add_trace(key=f"{group}:{a}", label=label, group=group, color=axis_colors.get(a, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)
            else:
                i = axis_map.get(ax, 0)
                self.multi_plot.add_trace(key=f"{group}:{ax}", label=label, group=group, color=axis_colors.get(ax, "#4ea1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, p=prov: p(ii)), scale=group_scale)

        elif grp == "QUAT":
            buf_name = "quat_game_buffer" if mode == "game" else ("quat_geomag_buffer" if mode == "geomag" else "")
            if not buf_name:
                self.log_view.append_line(f"Signals: unknown QUAT mode: {mode}")
            else:
                # Quaternion axis order matches device decoder (<4f) as [w, x, y, z].
                q_map = {"W": 0, "X": 1, "Y": 2, "Z": 3}
                if ax == "WXYZ":
                    for a in ("W", "X", "Y", "Z"):
                        i = q_map[a]
                        self.multi_plot.add_trace(key=f"{group}:{a}", label=label, group=group, color=axis_colors.get(a, "#d7e1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, bn=buf_name: prov_quat(bn, ii)), scale=group_scale)
                else:
                    i = q_map.get(ax, 0)
                    self.multi_plot.add_trace(key=f"{group}:{ax}", label=label, group=group, color=axis_colors.get(ax, "#d7e1ff"), y_min=y_min, y_max=y_max, data_provider=(lambda ii=i, bn=buf_name: prov_quat(bn, ii)), scale=group_scale)

        else:
            self.log_view.append_line(f"Signals: unhandled signal group '{grp}' or mode '{mode}'")
        _remember_group_meta()
        self._sync_signal_group_controls()

    def _remove_all_traces(self) -> None:
        self._ensure_signals_preset_state()
        self.multi_plot.clear()
        self._signals_group_meta.clear()
        self._sync_signal_group_controls()

    def _sync_signal_group_controls(self) -> None:
        """Ensure right-panel control widgets match the plotted groups."""
        self._ensure_signals_preset_state()
        groups = self.multi_plot.list_groups()

        # Remove widgets for groups that no longer exist.
        for g in list(self._sig_group_controls.keys()):
            if g in groups:
                continue
            w = self._sig_group_controls.pop(g)
            w.setParent(None)
        for g in list(self._signals_group_meta.keys()):
            if g not in groups:
                self._signals_group_meta.pop(g, None)

        # Create/update widgets in plot group order.
        for g in groups:
            if g not in self._sig_group_controls:
                w = SignalGroupControl(
                    group=g,
                    title=self.multi_plot.group_label(g),
                    parent=self.sig_group_panel_inner,
                    translate=lambda key, default: self._t(key, default),
                )
                w.remove_requested.connect(self._remove_signal_group)
                w.config_changed.connect(self._on_signal_group_config_changed)
                w.color_changed.connect(self._on_signal_group_color_changed)
                w.move_up_requested.connect(self._move_signal_group_up)
                w.move_down_requested.connect(self._move_signal_group_down)
                # Insert before the stretch spacer at the end.
                self.sig_group_panel_layout.insertWidget(self.sig_group_panel_layout.count() - 1, w)
                self._sig_group_controls[g] = w

        # Physically reorder tiles in the layout to match `groups`.
        # (Move up/down must visibly move the tile in the right panel.)
        for i in reversed(range(self.sig_group_panel_layout.count())):
            item = self.sig_group_panel_layout.itemAt(i)
            w = item.widget() if item else None
            if isinstance(w, SignalGroupControl):
                self.sig_group_panel_layout.takeAt(i)

        for g in groups:
            self.sig_group_panel_layout.insertWidget(self.sig_group_panel_layout.count() - 1, self._sig_group_controls[g])

        for idx, g in enumerate(groups):
            w = self._sig_group_controls[g]
            w.retranslate(lambda key, default: self._t(key, default))
            w.set_title(self.multi_plot.group_label(g))
            w.set_move_enabled(up=(idx > 0), down=(idx < len(groups) - 1))
            cfg = self.multi_plot.get_group_config(g)
            if cfg:
                w.set_values(y_min=cfg.y_min_raw, y_max=cfg.y_max_raw, scale=cfg.scale)

            traces = []
            for tr in self.multi_plot.traces_in_group(g):
                short = tr.key.split(":")[-1] if ":" in tr.key else tr.key
                traces.append((tr.key, short, tr.color))
            w.set_traces(traces)
        # Immediately refresh streaming control enable state after plot composition changes.
        self._update_signal_rx_status()

    def _remove_signal_group(self, group: str) -> None:
        self._ensure_signals_preset_state()
        self.multi_plot.remove_group(group)
        self._sig_group_palette.pop(group, None)
        self._signals_group_meta.pop(group, None)
        self._sync_signal_group_controls()

    def _move_signal_group_up(self, group: str) -> None:
        self.multi_plot.move_group(group, -1)
        self._sync_signal_group_controls()

    def _move_signal_group_down(self, group: str) -> None:
        self.multi_plot.move_group(group, +1)
        self._sync_signal_group_controls()

    def _on_signal_group_config_changed(self, group: str, y_min: float, y_max: float, scale: float) -> None:
        self.multi_plot.set_group_config(group, y_min=y_min, y_max=y_max, scale=scale)

    def _on_signal_group_color_changed(self, trace_key: str, color_hex: str) -> None:
        self.multi_plot.set_trace_color(trace_key, color_hex)

