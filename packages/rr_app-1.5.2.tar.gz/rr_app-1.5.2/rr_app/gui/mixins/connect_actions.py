from __future__ import annotations

import sys
import time

from PyQt6 import QtCore, QtWidgets

from ..widgets import AkrDeviceSettingsDialog, BulkModeSettingsDialog, DeviceSettingsDialog


class ConnectActionsMixin:
    def _selected_kind(self, addrs: list[str]) -> str | None:
        manager = self.controller.manager
        normalized_addrs = [str(a) for a in addrs]
        kinds = {
            manager.kind_of_device(manager.devices.get(a))
            for a in normalized_addrs
            if manager.devices.get(a) is not None
        }
        if len(kinds) == 1:
            return next(iter(kinds))
        return None

    def _apply_device_action_visibility(self, selected_kind: str | None) -> None:
        # Device-specific actions are hidden unless selection resolves to one kind.
        # Flow:
        # 1) no/unknown kind -> hide all device-specific actions,
        # 2) EMGS -> show full EMGS action set,
        # 3) AKR -> show Settings + record aliases.
        is_emgs = str(selected_kind or "").upper() == "EMGS"
        is_akr = str(selected_kind or "").upper() == "AKR"
        self.action_settings.setVisible(bool(is_emgs or is_akr))
        self.action_record_start.setVisible(bool(is_akr))
        self.action_record_stop.setVisible(bool(is_akr))
        self.action_update.setVisible(bool(is_emgs))
        self.action_time_sync.setVisible(bool(is_emgs))
        self.action_bulk_modes.setVisible(bool(is_emgs))

    def _enforce_single_kind_selection(self) -> list[str]:
        manager = self.controller.manager
        selection = self.table.selectionModel()
        rows = list(selection.selectedRows())
        if not rows:
            return []
        row_info: list[tuple[QtCore.QModelIndex, str, str]] = []
        for idx in rows:
            src = self.device_proxy.mapToSource(idx)
            addr = self.device_model.address_at(src.row())
            if not addr:
                continue
            dev = manager.devices.get(str(addr))
            if dev is None:
                continue
            row_info.append((idx, str(addr), manager.kind_of_device(dev)))
        if not row_info:
            return []
        kinds = {kind for _, _, kind in row_info}
        if len(kinds) <= 1:
            return [addr for _, addr, _ in row_info]

        current_idx = self.table.currentIndex()
        keep_kind: str | None = None
        if current_idx.isValid():
            src = self.device_proxy.mapToSource(current_idx)
            current_addr = self.device_model.address_at(src.row())
            if current_addr:
                current_dev = manager.devices.get(str(current_addr))
                if current_dev is not None:
                    keep_kind = manager.kind_of_device(current_dev)
        if keep_kind is None:
            keep_kind = row_info[0][2]
        kept_rows = [(idx, addr) for idx, addr, kind in row_info if kind == keep_kind]
        # Mixed selection is auto-corrected to keep only one kind so action visibility
        # and command routing stay deterministic.
        blocker = QtCore.QSignalBlocker(selection)
        try:
            selection.clearSelection()
            flags = QtCore.QItemSelectionModel.SelectionFlag.Select | QtCore.QItemSelectionModel.SelectionFlag.Rows
            for idx, _addr in kept_rows:
                selection.select(idx, flags)
            if kept_rows:
                self.table.setCurrentIndex(kept_rows[0][0])
        finally:
            _ = blocker
        self.log_view.append_line(
            self._t(
                "log_single_kind_selection_enforced",
                "Selection adjusted: only one device type can be selected at a time.",
            )
        )
        return [addr for _, addr in kept_rows]

    # ---------- Signals / actions ----------
    def _wire_signals(self) -> None:
        self.action_scan.triggered.connect(self.controller.scan)
        self.action_select_all.triggered.connect(self._select_all_rows)
        self.action_select_none.triggered.connect(self._select_none_rows)
        self.action_connect.triggered.connect(self._connect_selected)
        self.action_disconnect.triggered.connect(self._disconnect_selected)
        self.action_update.triggered.connect(self._update_selected)
        self.action_settings.triggered.connect(self._open_settings_for_selected)
        self.action_record_start.triggered.connect(self._start_record_from_connect_alias)
        self.action_record_stop.triggered.connect(self._stop_record_from_connect_alias)
        self.action_time_sync.triggered.connect(self._time_sync_selected)
        self.action_bulk_modes.triggered.connect(self._open_bulk_mode_settings)
        # Stream actions are not exposed on the Connect tab anymore.

        self.controller.signal_log.connect(self.log_view.append_line)
        self.controller.signal_device_list_changed.connect(self._on_device_list_changed)
        self.controller.signal_device_updated.connect(self._on_device_updated)

        self.table.selectionModel().selectionChanged.connect(self._on_table_selection_changed)
        self._update_action_enabled()

        self.table.customContextMenuRequested.connect(self._open_table_context_menu)

    @QtCore.pyqtSlot()
    def _start_record_from_connect_alias(self) -> None:
        # Keep alias behavior order-aligned with existing record controls:
        # 1) run the canonical recording start handler,
        # 2) refresh shared session/button state caches,
        # 3) refresh Connect action states immediately (no device-update lag).
        self._signals_start_record()
        self._update_signal_rx_status()
        self._update_action_enabled()

    @QtCore.pyqtSlot()
    def _stop_record_from_connect_alias(self) -> None:
        # Same parity flow as start alias: delegate first, then refresh UI state now.
        self._signals_stop_record()
        self._update_signal_rx_status()
        self._update_action_enabled()

    def _on_table_selection_changed(self, *_args) -> None:
        self._enforce_single_kind_selection()
        self._update_action_enabled()
        # Selection-driven LED UX: selected connected devices glow purple.
        addrs = [
            a
            for a in self._selected_addresses()
            if (self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_connected)
        ]
        self.controller.set_table_selected_devices(addrs)

    def _update_action_enabled(self) -> None:
        # Scan is always available.
        self.action_scan.setEnabled(True)
        manager = self.controller.manager

        # Bulk modes applies to EMGS devices only.
        any_connected_emgs = any(d.is_connected and manager.is_emgs_device_obj(d) for d in manager.devices.values())
        any_streaming_emgs = any(d.is_streaming and manager.is_emgs_device_obj(d) for d in manager.devices.values())

        addrs = self._selected_addresses()
        if not addrs:
            self._apply_device_action_visibility(None)
            # No selection: only allow the global EMGS-only action (Bulk Modes) if applicable.
            self.action_bulk_modes.setEnabled(bool(any_connected_emgs) and (not bool(any_streaming_emgs)))
            for a in [
                self.action_connect,
                self.action_disconnect,
                self.action_update,
                self.action_settings,
                self.action_record_start,
                self.action_record_stop,
                self.action_time_sync,
            ]:
                a.setEnabled(False)
            return

        devs = [self.controller.manager.devices.get(a) for a in addrs]
        devs = [d for d in devs if d is not None]
        if not devs:
            self._apply_device_action_visibility(None)
            return
        all_emgs_selected = all(manager.is_emgs_device_obj(d) for d in devs)
        all_akr_selected = all(manager.is_akr_device_obj(d) for d in devs)
        single_kind_selected = bool(all_emgs_selected or all_akr_selected)
        selected_kind = "EMGS" if all_emgs_selected else ("AKR" if all_akr_selected else None)
        self._apply_device_action_visibility(selected_kind)

        connected = [d.is_connected for d in devs]
        streaming = [d.is_streaming for d in devs]

        any_connected = any(connected)
        all_connected = all(connected)
        any_disconnected = any(not c for c in connected)

        any_not_streaming = any(not s for s in streaming)
        all_not_streaming = all(not s for s in streaming)
        any_streaming_global = any(d.is_streaming for d in manager.devices.values())
        connect_block_reason = manager.connect_block_reason_for(addrs)

        # Connect is meaningful only when at least one selected device is NOT connected.
        self.action_connect.setEnabled(any_disconnected and (connect_block_reason is None))
        # Disconnect is meaningful only when at least one selected device IS connected.
        self.action_disconnect.setEnabled(any_connected)

        # While a device is streaming, disable other commands for that selection
        # (Update Info / Settings / Time Sync) to avoid BLE congestion and inconsistent state.
        self.action_update.setEnabled(all_connected and all_not_streaming and all_emgs_selected)
        # Settings is available for both EMGS and AKR (different dialogs).
        # AKR devices may stream continuously; keep Settings enabled for AKR even while streaming.
        self.action_settings.setEnabled(all_connected and single_kind_selected and (all_not_streaming or all_akr_selected))
        # Record aliases must stay behavior-identical to existing Start/Stop controls.
        # Visibility remains AKR-only, but enabled state mirrors the shared session rules.
        self.action_record_start.setEnabled(
            bool(any_streaming_global) and (not bool(self._recording))
        )
        self.action_record_stop.setEnabled(
            bool(self._recording)
        )
        self.action_time_sync.setEnabled(all_connected and all_not_streaming and all_emgs_selected)

        # Bulk Mode Settings is EMGS-only; if a AKR device is selected, gray it out.
        self.action_bulk_modes.setEnabled(
            bool(any_connected_emgs)
            and (not bool(any_streaming_emgs))
            and bool(all_emgs_selected)
        )

        # Streaming controls are on the Signals tab.
        self.action_stream_start.setEnabled(False)
        self.action_stream_stop.setEnabled(False)

    def _select_all_rows(self) -> None:
        self.table.selectAll()

    def _select_none_rows(self) -> None:
        self.table.clearSelection()

    def _poll_connected_devices(self) -> None:
        # Poll connected devices even if user is not selecting them.
        #
        # While streaming, avoid sending TIME_SYNC polls ("heartbeat") so the device can
        # focus on data packets and the UI doesn't look like it's only receiving A3 replies.
        poll_addrs = [
            a
            for a, d in self.controller.manager.devices.items()
            if d.is_connected
            and (not d.is_streaming)
            and self.controller.manager.is_emgs_device_obj(d)
        ]
        if poll_addrs:
            self.controller.poll_many(poll_addrs)

        # For streaming devices, only do a local health check (no BLE traffic).
        # This now applies to all kinds so backend/link mismatch is detected
        # even when a device has no periodic command traffic.
        stream_addrs = [
            a
            for a, d in self.controller.manager.devices.items()
            if d.is_connected
            and d.is_streaming
        ]
        if stream_addrs:
            self.controller.check_health_many(stream_addrs)

    def _full_update_connected_devices(self) -> None:
        # Heavier refresh: query full info set. Avoid while streaming to reduce BLE congestion.
        addrs = [
            a
            for a, d in self.controller.manager.devices.items()
            if d.is_connected
            and (not d.is_streaming)
            and self.controller.manager.is_emgs_device_obj(d)
        ]
        if addrs:
            self.controller.update_many(addrs)

    def _selected_addresses(self) -> list[str]:
        selected = self.table.selectionModel().selectedRows()
        addrs: list[str] = []
        for idx in selected:
            src = self.device_proxy.mapToSource(idx)
            addr = self.device_model.address_at(src.row())
            if addr:
                addrs.append(addr)
        return addrs

    @QtCore.pyqtSlot()
    def _connect_selected(self) -> None:
        addrs = self._selected_addresses()
        block_reason = self.controller.manager.connect_block_reason_for(addrs)
        if block_reason is not None:
            self.log_view.append_line(block_reason)
            return
        # Connect only those not already connected
        to_connect = [a for a in addrs if not self.controller.manager.devices[a].is_connected]
        if to_connect:
            self.controller.connect_many(to_connect)
        else:
            self.log_view.append_line(
                self._t(
                    "log_connect_nothing_to_do",
                    "Connect: nothing to do (already connected?)",
                )
            )

    @QtCore.pyqtSlot()
    def _disconnect_selected(self) -> None:
        addrs = [a for a in self._selected_addresses() if self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_connected]
        if addrs:
            self.controller.disconnect_many(addrs)

    @QtCore.pyqtSlot()
    def _update_selected(self) -> None:
        addrs = [a for a in self._selected_addresses() if self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_connected]
        if addrs:
            self.controller.update_many(addrs)

    @QtCore.pyqtSlot()
    def _time_sync_selected(self) -> None:
        addrs = [a for a in self._selected_addresses() if self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_connected]
        if not addrs:
            return
        self.controller.time_sync_one(addrs[0])

    @QtCore.pyqtSlot()
    def _open_settings_for_selected(self) -> None:
        addrs = self._selected_addresses()
        if not addrs:
            return
        self._open_settings_for_address(str(addrs[0]))

    def _open_settings_for_address(self, addr: str) -> None:
        addr = str(addr)
        dev = self.controller.manager.devices.get(addr)
        if not dev:
            return
        if not dev.is_connected:
            self.log_view.append_line(
                self._t("log_settings_device_not_connected", "Settings: device not connected")
            )
            return
        if self.controller.manager.is_akr_device_obj(dev):
            # Maximize/restore behavior depends on whether the WM sees this as a
            # regular top-level window or an owned/transient dialog.
            # Flow:
            # 1) Linux/Windows -> open as top-level (no transient parent),
            # 2) pass explicit owner for cross-tab helpers,
            # 3) keep other platforms unchanged.
            wm_managed_top_level = sys.platform.startswith("linux") or sys.platform.startswith("win")
            dlg = AkrDeviceSettingsDialog(
                controller=self.controller,
                address=str(addr),
                device_name=str(dev.params.name),
                parent=None if wm_managed_top_level else self,
                translate=lambda key, default: self._t(key, default),
                signals_owner=self if wm_managed_top_level else None,
            )
            dlg.exec()
            return

        dlg = DeviceSettingsDialog(
            dev,
            parent=self,
            translate=lambda key, default: self._t(key, default),
        )
        if dlg.exec() == QtWidgets.QDialog.DialogCode.Accepted:
            settings = dlg.get_values()
            self.controller.apply_settings_dict(addr, settings)

    def _stream_selected(self, enable: bool) -> None:
        addrs = [a for a in self._selected_addresses() if self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_connected]
        if addrs:
            self.controller.stream_many(addrs, enable)

    def _open_table_context_menu(self, pos: QtCore.QPoint) -> None:
        # Only show context menu when right-clicking on an actual device row.
        idx = self.table.indexAt(pos)
        if not idx.isValid():
            return

        # If user right-clicks a different row, select it first so actions apply intuitively.
        sel = self.table.selectionModel()
        if sel and not sel.isSelected(idx):
            sel.select(
                idx,
                QtCore.QItemSelectionModel.SelectionFlag.ClearAndSelect
                | QtCore.QItemSelectionModel.SelectionFlag.Rows,
            )
            self.table.setCurrentIndex(idx)

        menu = QtWidgets.QMenu(self)
        menu.addAction(self.action_scan)
        menu.addAction(self.action_select_all)
        menu.addAction(self.action_select_none)
        menu.addSeparator()
        menu.addAction(self.action_connect)
        menu.addAction(self.action_disconnect)
        menu.addSeparator()
        for action in [
            self.action_update,
            self.action_time_sync,
            self.action_settings,
            self.action_record_start,
            self.action_record_stop,
            self.action_bulk_modes,
        ]:
            if action.isVisible():
                menu.addAction(action)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    @QtCore.pyqtSlot()
    def _open_bulk_mode_settings(self) -> None:
        # Apply to all connected devices; avoid applying while any is streaming.
        devs = {a: d for a, d in self.controller.manager.devices.items() if d.is_connected}
        if not devs:
            self.log_view.append_line(
                self._t(
                    "log_bulk_no_connected",
                    "Bulk Mode Settings: no connected devices",
                )
            )
            return
        if any(d.is_streaming for d in devs.values()):
            self.log_view.append_line(
                self._t(
                    "log_bulk_stop_streaming_first",
                    "Bulk Mode Settings: stop streaming before applying",
                )
            )
            return

        dlg = BulkModeSettingsDialog(
            parent=self,
            translate=lambda key, default: self._t(key, default),
        )
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        icm_enabled, emg_mode = dlg.get_values()
        addrs = list(devs.keys())
        self.controller.apply_modes_many(addrs, icm_enabled, int(emg_mode))
        self.log_view.append_line(
            self._t(
                "log_bulk_applied",
                "Bulk Mode Settings: applied to {count} device(s)",
                count=len(addrs),
            )
        )

    @QtCore.pyqtSlot()
    def _on_device_list_changed(self) -> None:
        self.device_model.refresh_all()
        self._refresh_signal_device_list()
        self._refresh_scenario_device_list()
        self._sync_scenario_controls()
        self._update_action_enabled()

    @QtCore.pyqtSlot(str)
    def _on_device_updated(self, address: str) -> None:
        t0 = time.perf_counter()
        self.device_model.refresh_row_by_address(address)
        # Scenario tiles: update subtitle if this device is present.
        try:
            for k, tile in getattr(self, "_scenario_controls", {}).items():
                if f"::{address}" in str(k):
                    tile.set_subtitle(self._scenario_tile_subtitle_for_device(str(address)))
        except Exception:
            pass
        # Recording: capture new samples on each device update.
        if getattr(self, "_recording", False) and getattr(self, "_recorder", None) is not None:
            try:
                dev = self.controller.manager.devices.get(address)
                if dev is not None:
                    self._recorder.capture_device(addr=str(address), dev=dev)
            except Exception:
                pass
        # If a new streaming session was armed, latch per-device origin to the first EMG/IMU data packet we see.
        if address in getattr(self, "_device_origin_armed_addrs", set()):
            dev = self.controller.manager.devices.get(address)
            if dev and self._device_origin_s.get(address) is None:
                arm = float(getattr(self, "_device_origin_arm_monotonic_s", 0.0))
                ts_ms: int | None = None
                # Prefer EMG packet timestamp; fall back to IMU.
                if dev.last_emg_time_s is not None and float(dev.last_emg_time_s) >= arm and dev.last_emg_packet_ts_ms is not None:
                    ts_ms = int(dev.last_emg_packet_ts_ms)
                elif dev.last_imu_time_s is not None and float(dev.last_imu_time_s) >= arm and getattr(dev, "last_imu_packet_ts_ms", None) is not None:
                    ts_ms = int(getattr(dev, "last_imu_packet_ts_ms"))
                if ts_ms is not None:
                    self._device_origin_s[address] = float(ts_ms) / 1000.0
                    self._device_origin_armed_addrs.discard(address)
                    try:
                        self.status.showMessage(
                            self._t(
                                "status_plot_origin_latched",
                                "Plot origin latched for {address}: {seconds:0.3f}s",
                                address=address,
                                seconds=self._device_origin_s[address],
                            )
                        )
                    except Exception:
                        pass
        self._update_action_enabled()
        self._update_signal_rx_status()
        self._last_device_update_ms = (time.perf_counter() - t0) * 1000.0

