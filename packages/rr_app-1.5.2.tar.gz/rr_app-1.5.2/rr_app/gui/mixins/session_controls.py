from __future__ import annotations

import sys
import time
from pathlib import Path

from PyQt6 import QtCore, QtGui, QtWidgets

from ... import config
from ...recording import (
    DeviceWideRecorder,
    RecordingSession,
    create_session_device_recorder,
    default_recording_session_paths,
    device_recording_paths,
)
from ..widgets import ScenarioControlTile


class SignalsScenarioSessionMixin:
    # ---------- Signals (charts): session controls ----------
    def _refresh_signal_device_list(self) -> None:
        # Keep current selection if possible.
        prev = self.combo_sig_device.currentData()
        self.combo_sig_device.blockSignals(True)
        self.combo_sig_device.clear()
        self.combo_sig_device.addItem(
            self._t("select_device_placeholder", "Select device..."), None
        )
        for addr, dev in self.controller.manager.devices.items():
            name = (
                dev.params.name
                if dev.params.name and dev.params.name != "/"
                else self._t("device_default_name", "EMGS")
            )
            self.combo_sig_device.addItem(f"{name}  ({addr})", addr)
        self.combo_sig_device.blockSignals(False)
        if prev:
            idx = self.combo_sig_device.findData(prev)
            if idx >= 0:
                self.combo_sig_device.setCurrentIndex(idx)
            else:
                self.combo_sig_device.setCurrentIndex(0)
        else:
            self.combo_sig_device.setCurrentIndex(0)
        self._update_signal_rx_status()

    def _refresh_scenario_device_list(self) -> None:
        # Keep current selection if possible.
        # NOTE: In PyQt, `bool(QComboBox)` can be False when it has 0 items
        # (because `__len__` maps to `count()`), so don't use truthiness here.
        if getattr(self, "combo_scn_device", None) is None:
            return
        prev = self.combo_scn_device.currentData()
        self.combo_scn_device.blockSignals(True)
        self.combo_scn_device.clear()
        self.combo_scn_device.addItem(
            self._t("select_device_placeholder", "Select device..."), None
        )
        for addr, dev in self.controller.manager.devices.items():
            name = (
                dev.params.name
                if dev.params.name and dev.params.name != "/"
                else self._t("device_default_name", "EMGS")
            )
            self.combo_scn_device.addItem(f"{name}  ({addr})", addr)
        self.combo_scn_device.blockSignals(False)
        if prev:
            idx = self.combo_scn_device.findData(prev)
            if idx >= 0:
                self.combo_scn_device.setCurrentIndex(idx)
            else:
                self.combo_scn_device.setCurrentIndex(0)
        else:
            self.combo_scn_device.setCurrentIndex(0)

        # If the active scenario device disappeared, clear it.
        try:
            if self._scenario_active_key:
                # If active device vanished, clear active key.
                if "::" in str(self._scenario_active_key):
                    addr = str(self._scenario_active_key).split("::", 1)[1]
                    if addr not in self.controller.manager.devices:
                        self._scenario_active_key = None
                        if getattr(self, "scn_plot", None):
                            self.scn_plot.clear()
        except Exception:
            pass

    def _scenario_tile_subtitle_for_device(self, addr: str) -> str:
        dev = self.controller.manager.devices.get(str(addr))
        if not dev:
            return str(addr)
        name = (
            dev.params.name
            if dev.params.name and dev.params.name != "/"
            else self._t("device_default_name", "EMGS")
        )
        status = dev.params.status
        streaming = (
            f" • {self._t('status_streaming_lower', 'streaming')}"
            if bool(getattr(dev, "is_streaming", False))
            else ""
        )
        return f"{name} ({addr}) • {status}{streaming}"

    def _sync_scenario_controls(self) -> None:
        """Remove stale Scenario tiles and keep active highlight consistent."""
        # Drop tiles for devices that no longer exist.
        for k in list(getattr(self, "_scenario_controls", {}).keys()):
            if "::" not in str(k):
                continue
            addr = str(k).split("::", 1)[1]
            if addr in self.controller.manager.devices:
                continue
            tile = self._scenario_controls.pop(k, None)
            if tile is not None:
                try:
                    tile.setParent(None)
                except Exception:
                    pass
            if self._scenario_active_key == k:
                self._scenario_active_key = None
                try:
                    self.scn_plot.clear()
                except Exception:
                    pass
        self._scenario_update_active_highlight()
        self._scenario_apply_plot_bounds()

    def _scenario_update_active_highlight(self) -> None:
        for k, tile in getattr(self, "_scenario_controls", {}).items():
            try:
                tile.retranslate(lambda kk, dd: self._t(kk, dd))
                tile.set_active(bool(self._scenario_active_key == k))
            except Exception:
                pass

    def _scenario_global_plot_bounds(self) -> tuple[float, float, float, float] | None:
        """Global plot bounds across all Scenario tiles.

        Rule: if multiple tiles exist, use the largest max for x/y respectively.
        (For mins, use the smallest min so the view covers all configured ranges.)
        """
        xs0: list[float] = []
        xs1: list[float] = []
        ys0: list[float] = []
        ys1: list[float] = []
        for tile in self._scenario_controls.values():
            try:
                x0, x1, y0, y1 = tile.get_bounds()
                x0, x1 = float(x0), float(x1)
                y0, y1 = float(y0), float(y1)
                if x1 < x0:
                    x0, x1 = x1, x0
                if y1 < y0:
                    y0, y1 = y1, y0
                xs0.append(x0)
                xs1.append(x1)
                ys0.append(y0)
                ys1.append(y1)
            except Exception:
                continue
        if not xs0:
            return None
        return (min(xs0), max(xs1), min(ys0), max(ys1))

    def _scenario_apply_plot_bounds(self) -> None:
        if getattr(self, "scn_plot", None) is None:
            return
        b = self._scenario_global_plot_bounds()
        try:
            if b is None:
                x0, x1, y0, y1 = (-1.0, 1.0, -1.0, 1.0)
            else:
                x0, x1, y0, y1 = b
            self.scn_plot.set_bounds(x_min=float(x0), x_max=float(x1), y_min=float(y0), y_max=float(y1))
        except Exception:
            pass

    @staticmethod
    def _fmt_dur(s: float) -> str:
        s = float(max(0.0, s))
        sec = int(s + 0.5)
        h = sec // 3600
        m = (sec % 3600) // 60
        ss = sec % 60
        if h > 0:
            return f"{h:d}:{m:02d}:{ss:02d}"
        return f"{m:02d}:{ss:02d}"

    @staticmethod
    def _safe_existing_dir(path: str) -> str:
        """Return an existing directory, else fall back to default recording dir."""
        try:
            p = Path(str(path)).expanduser()
            if p.exists():
                if p.is_dir():
                    return str(p)
                if p.parent.exists() and p.parent.is_dir():
                    return str(p.parent)
        except Exception:
            pass
        # Keep file dialogs anchored to the app default recording base.
        fallback = Path.home() / str(getattr(config, "DEFAULT_REC_OUT_DIRNAME", "rr_data"))
        try:
            fallback.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return str(fallback if fallback.exists() else Path.home())

    def _on_signal_device_changed_for_led(self, *_args) -> None:
        """Signals-page device selection → LED (purple), suppressed while streaming."""
        addr = self.combo_sig_device.currentData()
        if isinstance(addr, str) and addr:
            self.controller.set_signals_selected_devices([addr])
        else:
            self.controller.set_signals_selected_devices([])
        self._update_signal_rx_status()

    def _identify_selected_signal_device(self) -> None:
        """Flash purple LED for the currently selected Signals-page device."""
        addr = self.combo_sig_device.currentData()
        if isinstance(addr, str) and addr:
            self.controller.identify_device(addr)

    def _open_settings_for_signal_device(self) -> None:
        """Open device Settings for the currently selected Signals-page device."""
        addr = self.combo_sig_device.currentData()
        if not (isinstance(addr, str) and addr):
            self.log_view.append_line(
                self._t(
                    "log_settings_no_selected_on_signals",
                    "Settings: no device selected on Signals page",
                )
            )
            return
        self._open_settings_for_address(str(addr))

    def _identify_selected_scenario_device(self) -> None:
        """Flash purple LED for the currently selected Scenario-page device."""
        addr = self.combo_scn_device.currentData() if getattr(self, "combo_scn_device", None) is not None else None
        if isinstance(addr, str) and addr:
            self.controller.identify_device(addr)

    def _scenario_add_from_ui(self) -> None:
        """Add a Scenario tile (right panel) from UI selection."""
        addr = self.combo_scn_device.currentData() if getattr(self, "combo_scn_device", None) is not None else None
        if not (isinstance(addr, str) and addr):
            return
        addr = str(addr)

        scenario_label = str(
            self.combo_scn_scenario.currentText()
            if getattr(self, "combo_scn_scenario", None) is not None
            else self._t("label_scenario", "Scenario")
        )
        scenario_key = "mouse"  # only scenario implemented right now
        key = f"{scenario_key}::{addr}"

        # Create tile if missing.
        if key not in self._scenario_controls:
            tile = ScenarioControlTile(
                key=key,
                title=scenario_label,
                subtitle=self._scenario_tile_subtitle_for_device(addr),
                parent=self,
                translate=lambda k, d: self._t(k, d),
            )
            tile.remove_requested.connect(self._scenario_remove_by_key)
            tile.activate_requested.connect(self._scenario_set_active_key)
            try:
                tile.bounds_changed.connect(self._on_scenario_tile_bounds_changed)
            except Exception:
                pass
            # Insert before the stretch at the end.
            try:
                self.scn_group_panel_layout.insertWidget(self.scn_group_panel_layout.count() - 1, tile)
            except Exception:
                self.scn_group_panel_layout.addWidget(tile)
            self._scenario_controls[key] = tile

        self._scenario_set_active_key(key)
        self._scenario_apply_plot_bounds()
        try:
            self.status.showMessage(
                self._t(
                    "status_scenario_added_selected",
                    "Scenario: added/selected {addr}",
                    addr=addr,
                )
            )
        except Exception:
            pass

    def _scenario_remove_active(self) -> None:
        """Remove the active Scenario tile (or the selected device's tile)."""
        key = self._scenario_active_key
        if not key:
            addr = self.combo_scn_device.currentData() if getattr(self, "combo_scn_device", None) is not None else None
            if isinstance(addr, str) and addr:
                key = f"mouse::{addr}"
        if key:
            self._scenario_remove_by_key(str(key))

    def _scenario_set_active_key(self, key: str) -> None:
        key = str(key)
        if key not in getattr(self, "_scenario_controls", {}):
            return
        self._scenario_active_key = key
        self._scenario_update_active_highlight()

    def _scenario_remove_by_key(self, key: str) -> None:
        key = str(key)
        tile = self._scenario_controls.pop(key, None)
        if tile is not None:
            try:
                tile.setParent(None)
            except Exception:
                pass
        if self._scenario_active_key == key:
            self._scenario_active_key = None
            try:
                self.scn_plot.clear()
            except Exception:
                pass
        self._scenario_update_active_highlight()
        self._scenario_apply_plot_bounds()

    def _on_scenario_tile_bounds_changed(self, *_args) -> None:
        # Recompute the global bounds and apply (largest max among tiles).
        self._scenario_apply_plot_bounds()

    def _scenario_stream_selected(self, enable: bool) -> None:
        """Start/stop streaming for the Scenario page.

        For now: streams all connected devices (Scenario right panel is per-device tiles).
        """
        target_addrs = [a for a, d in self.controller.manager.devices.items() if d.is_connected]

        if not target_addrs:
            self.log_view.append_line(
                self._t("log_scenario_no_connected", "Scenario: no connected devices")
            )
            return

        eligible_devs = {a: d for a in target_addrs if (d := self.controller.manager.devices.get(a)) and d.is_connected}
        if not eligible_devs:
            self.log_view.append_line(
                self._t("log_scenario_no_connected", "Scenario: no connected devices")
            )
            return

        if enable:
            to_start = [a for a, d in eligible_devs.items() if not d.is_streaming]
            if not to_start:
                self.log_view.append_line(
                    self._t(
                        "log_scenario_already_streaming",
                        "Scenario: devices already streaming",
                    )
                )
                return
            self._signals_session_start_monotonic_s = time.monotonic()
            self._device_origin_arm_monotonic_s = time.monotonic()
            for a in to_start:
                self._device_origin_s[a] = None
            self._device_origin_armed_addrs = set(to_start)
            self.controller.stream_many(to_start, enable=True)
        else:
            to_stop = [a for a, d in eligible_devs.items() if d.is_streaming]
            if not to_stop:
                self.log_view.append_line(
                    self._t(
                        "log_scenario_none_streaming",
                        "Scenario: no devices are streaming",
                    )
                )
                return
            self.controller.stream_many(to_stop, enable=False)

    def _on_tab_changed(self, index: int) -> None:
        # Only keep Signals-page LED selection active while Signals tab is visible.
        try:
            w = self.tabs.widget(index)
        except Exception:
            return
        if w is self.signals_page:
            self._on_signal_device_changed_for_led()
        else:
            self.controller.set_signals_selected_devices([])

    def _signal_plot_addresses(self) -> list[str]:
        """Return device addresses that are currently 'enlisted' in the plot."""
        addrs: list[str] = []
        known_addrs = [str(a) for a in self.controller.manager.devices.keys()]
        for g in self.multi_plot.list_groups():
            g = str(g)
            # Group keys are built as f"{addr}:{preset_label}".
            # NOTE: addresses themselves may contain ':' (e.g., BLE MACs), so
            # split(":", 1) is incorrect. Match against known device addresses.
            matched_addr = None
            for addr in known_addrs:
                if g.startswith(f"{addr}:"):
                    if matched_addr is None or len(addr) > len(matched_addr):
                        matched_addr = addr
            if matched_addr:
                addrs.append(matched_addr)
        # Preserve order, unique.
        return list(dict.fromkeys(addrs))

    def _device_time_origin_s(self, address: str) -> float | None:
        """Per-device plot origin (seconds), latched at stream start."""
        return self._device_origin_s.get(str(address))

    def _signals_stream_plotted(self, enable: bool) -> None:
        # Streaming session is driven by what's plotted. If nothing is plotted, allow
        # streaming all connected devices (useful for "record-only" workflows).
        plot_addrs = self._signal_plot_addresses()
        if plot_addrs:
            target_addrs = list(plot_addrs)
        else:
            target_addrs = [a for a, d in self.controller.manager.devices.items() if d.is_connected]
        if not target_addrs:
            self.log_view.append_line(
                self._t("log_signals_no_connected", "Signals: no connected devices")
            )
            return

        eligible_devs = {a: d for a in target_addrs if (d := self.controller.manager.devices.get(a)) and d.is_connected}
        if not eligible_devs:
            self.log_view.append_line(
                self._t("log_signals_no_connected", "Signals: no connected devices")
            )
            return

        if enable:
            to_start = [a for a, d in eligible_devs.items() if not d.is_streaming]
            if not to_start:
                self.log_view.append_line(
                    self._t(
                        "log_signals_already_streaming",
                        "Signals: devices already streaming",
                    )
                )
                return
            # Session elapsed timer starts now (reset when stream starts).
            self._signals_session_start_monotonic_s = time.monotonic()
            # Arm per-device plot origins: each device latches t0 on its first EMG/IMU data packet
            # received after stream start. (Not shared across devices.)
            self._device_origin_arm_monotonic_s = time.monotonic()
            for a in to_start:
                self._device_origin_s[a] = None
            self._device_origin_armed_addrs = set(to_start)
            self.controller.stream_many(to_start, enable=True)
        else:
            to_stop = [a for a, d in eligible_devs.items() if d.is_streaming]
            if not to_stop:
                self.log_view.append_line(
                    self._t(
                        "log_signals_none_streaming",
                        "Signals: no devices are streaming",
                    )
                )
                return
            self.controller.stream_many(to_stop, enable=False)

    def _update_signal_rx_status(self) -> None:
        self._signal_status_last_refresh_monotonic_s = time.monotonic()
        cache_obj = getattr(self, "_signal_status_ui_cache", {})
        cache: dict[str, object] = cache_obj if isinstance(cache_obj, dict) else {}

        def _set_enabled_cached(cache_key: str, widget: QtWidgets.QWidget | None, enabled: bool) -> None:
            if widget is None:
                return
            wanted = bool(enabled)
            state_key = f"{cache_key}:enabled"
            if cache.get(state_key) == wanted:
                return
            cache[state_key] = wanted
            try:
                widget.setEnabled(wanted)
            except Exception:
                pass

        def _set_label_cached(
            cache_key: str,
            label: QtWidgets.QLabel | None,
            text: str,
            style: str,
        ) -> None:
            if label is None:
                return
            text_key = f"{cache_key}:text"
            style_key = f"{cache_key}:style"
            if cache.get(text_key) != text:
                cache[text_key] = text
                try:
                    label.setText(text)
                except Exception:
                    pass
            if cache.get(style_key) != style:
                cache[style_key] = style
                try:
                    label.setStyleSheet(style)
                except Exception:
                    pass

        # Session status: show if ANY device is currently streaming (even if no plotted curves).
        any_streaming_global = any(d.is_streaming for d in self.controller.manager.devices.values())
        any_streaming_emgs = any(
            d.is_streaming and str(getattr(d.params, "kind", "EMGS")).upper() == "EMGS"
            for d in self.controller.manager.devices.values()
        )
        # Update both Signals and Scenario session labels (same underlying stream/record state).
        for lbl_key, lbl in (
            ("sig", getattr(self, "lbl_sig_session", None)),
            ("scn", getattr(self, "lbl_scn_session", None)),
        ):
            if not lbl:
                continue
            if any_streaming_global:
                now = time.monotonic()
                t0 = float(self._signals_session_start_monotonic_s) if self._signals_session_start_monotonic_s is not None else now
                elapsed = self._fmt_dur(now - t0)
                parts = [
                    self._t(
                        "session_streaming",
                        "Session: STREAMING • {elapsed}",
                        elapsed=elapsed,
                    )
                ]
                if bool(getattr(self, "_recording", False)) and getattr(self, "_recording_start_monotonic_s", None) is not None:
                    rec_elapsed = self._fmt_dur(now - float(self._recording_start_monotonic_s))
                    parts.append(
                        self._t("session_rec", "REC • {elapsed}", elapsed=rec_elapsed)
                    )
                elif getattr(self, "_last_recording_duration_s", None) is not None:
                    parts.append(
                        self._t(
                            "session_last_rec",
                            "Last REC • {elapsed}",
                            elapsed=self._fmt_dur(
                                float(self._last_recording_duration_s)
                            ),
                        )
                    )
                _set_label_cached(
                    f"session_label:{lbl_key}",
                    lbl,
                    "  |  ".join(parts),
                    "color: #2ed573; font-weight: 700;",
                )
            else:
                parts = [self._t("session_idle", "Session: IDLE")]
                if getattr(self, "_last_recording_duration_s", None) is not None:
                    parts.append(
                        self._t(
                            "session_last_rec",
                            "Last REC • {elapsed}",
                            elapsed=self._fmt_dur(
                                float(self._last_recording_duration_s)
                            ),
                        )
                    )
                _set_label_cached(
                    f"session_label:{lbl_key}",
                    lbl,
                    "  |  ".join(parts),
                    "color: #9fb2e8; font-weight: 600;",
                )

        # Settings page: processed-data toggles are not allowed to change mid-session.
        if getattr(self, "chk_proc_emg_env", None):
            # Lock EMG processed-data settings only when EMGS devices are streaming.
            locked = bool(any_streaming_emgs)
            for w in (
                self.chk_proc_emg_env,
                getattr(self, "spin_proc_emg_env_win", None),
                getattr(self, "chk_proc_emg_freq", None),
                getattr(self, "spin_proc_emg_spec_win", None),
                getattr(self, "chk_proc_emg_fatigue", None),
                getattr(self, "spin_proc_emg_fatigue_baseline_s", None),
                getattr(self, "spin_proc_emg_fatigue_w_mdf", None),
                getattr(self, "spin_proc_emg_fatigue_w_rms", None),
                getattr(self, "spin_proc_emg_fatigue_conf_n", None),
                getattr(self, "chk_proc_emg_ecg_filter", None),
                getattr(self, "combo_proc_emg_ecg_method", None),
                getattr(self, "spin_proc_emg_ecg_hp_cutoff_hz", None),
                getattr(self, "spin_proc_emg_ecg_wavelet_levels", None),
                getattr(self, "spin_proc_emg_ecg_wavelet_shrink", None),
            ):
                if w is None:
                    continue
                _set_enabled_cached(f"proc_locked:{id(w)}", w, not locked)
            # When not locked, disable fatigue parameter spins unless fatigue is enabled.
            if not locked and getattr(self, "chk_proc_emg_fatigue", None):
                enabled = bool(self.chk_proc_emg_fatigue.isChecked())
                for w in (
                    getattr(self, "spin_proc_emg_fatigue_baseline_s", None),
                    getattr(self, "spin_proc_emg_fatigue_w_mdf", None),
                    getattr(self, "spin_proc_emg_fatigue_w_rms", None),
                    getattr(self, "spin_proc_emg_fatigue_conf_n", None),
                ):
                    if w is None:
                        continue
                    _set_enabled_cached(f"proc_fatigue:{id(w)}", w, bool(enabled))
            if not locked and getattr(self, "chk_proc_emg_ecg_filter", None):
                enabled = bool(self.chk_proc_emg_ecg_filter.isChecked())
                method = str(self.combo_proc_emg_ecg_method.currentData() if getattr(self, "combo_proc_emg_ecg_method", None) is not None else "highpass").strip().lower()
                if getattr(self, "combo_proc_emg_ecg_method", None) is not None:
                    _set_enabled_cached("proc_ecg:method", self.combo_proc_emg_ecg_method, bool(enabled))
                if getattr(self, "spin_proc_emg_ecg_hp_cutoff_hz", None) is not None:
                    _set_enabled_cached(
                        "proc_ecg:hp_cutoff",
                        self.spin_proc_emg_ecg_hp_cutoff_hz,
                        bool(enabled) and method != "wavelet",
                    )
                if getattr(self, "spin_proc_emg_ecg_wavelet_levels", None) is not None:
                    _set_enabled_cached(
                        "proc_ecg:wavelet_levels",
                        self.spin_proc_emg_ecg_wavelet_levels,
                        bool(enabled) and method == "wavelet",
                    )
                if getattr(self, "spin_proc_emg_ecg_wavelet_shrink", None) is not None:
                    _set_enabled_cached(
                        "proc_ecg:wavelet_shrink",
                        self.spin_proc_emg_ecg_wavelet_shrink,
                        bool(enabled) and method == "wavelet",
                    )
        # Enable streaming controls (Signals tab) based on whether there are any plotted curves/devices.
        plot_addrs = self._signal_plot_addresses()
        if not plot_addrs:
            # When nothing is plotted, enable stream controls based on all connected devices.
            devs_all = [d for d in self.controller.manager.devices.values() if d.is_connected]
            sig_any_connected = bool(devs_all)
            sig_any_streaming = any(d.is_streaming for d in devs_all)
            sig_any_not_streaming = any((not d.is_streaming) for d in devs_all)
        else:
            devs = [self.controller.manager.devices.get(a) for a in plot_addrs]
            devs = [d for d in devs if d is not None]
            connected = [d for d in devs if d.is_connected]
            sig_any_connected = bool(connected)
            sig_any_streaming = any(d.is_streaming for d in connected)
            sig_any_not_streaming = any((not d.is_streaming) for d in connected)

        try:
            _set_enabled_cached("sig_btn:stream_start", self.btn_sig_stream_start, bool(sig_any_connected) and bool(sig_any_not_streaming))
            _set_enabled_cached("sig_btn:stream_stop", self.btn_sig_stream_stop, bool(sig_any_connected) and bool(sig_any_streaming))
            _set_enabled_cached("sig_btn:record_start", self.btn_sig_record_start, bool(any_streaming_global) and not bool(self._recording))
            _set_enabled_cached("sig_btn:record_stop", self.btn_sig_record_stop, bool(self._recording))
            _set_enabled_cached("sig_btn:reset", self.btn_sig_reset, bool(any_streaming_global))
            selected_addr = self.combo_sig_device.currentData() if getattr(self, "combo_sig_device", None) is not None else None
            selected_dev = self.controller.manager.devices.get(str(selected_addr)) if isinstance(selected_addr, str) and selected_addr else None
            if selected_dev is None or not bool(getattr(selected_dev, "is_connected", False)):
                _set_enabled_cached("sig_btn:settings", self.btn_sig_settings, False)
            else:
                # Mirror Connect-tab Settings rule: AKR can stay configurable while streaming.
                is_akr = self.controller.manager.is_akr_device_obj(selected_dev)
                _set_enabled_cached(
                    "sig_btn:settings",
                    self.btn_sig_settings,
                    (not bool(getattr(selected_dev, "is_streaming", False))) or is_akr,
                )
        except Exception:
            pass

        # Scenario tab stream/record/reset controls (currently global/session-level like Signals).
        try:
            any_connected_global = any(d.is_connected for d in self.controller.manager.devices.values())
            any_not_streaming_global = any(d.is_connected and (not d.is_streaming) for d in self.controller.manager.devices.values())
            _set_enabled_cached("scn_btn:stream_start", self.btn_scn_stream_start, bool(any_connected_global) and bool(any_not_streaming_global))
            _set_enabled_cached("scn_btn:stream_stop", self.btn_scn_stream_stop, bool(any_connected_global) and bool(any_streaming_global))
            _set_enabled_cached("scn_btn:record_start", self.btn_scn_record_start, bool(any_streaming_global) and not bool(self._recording))
            _set_enabled_cached("scn_btn:record_stop", self.btn_scn_record_stop, bool(self._recording))
            _set_enabled_cached("scn_btn:reset", self.btn_scn_reset, bool(any_streaming_global))
        except Exception:
            pass
        self._signal_status_ui_cache = cache

    def _signals_reset_processed(self) -> None:
        # Reset processed buffers for currently streaming devices (prefer those enlisted in plot).
        plot_addrs = self._signal_plot_addresses()
        addrs = [a for a in plot_addrs if (self.controller.manager.devices.get(a) and self.controller.manager.devices[a].is_streaming)]
        if not addrs:
            addrs = [a for a, d in self.controller.manager.devices.items() if d.is_streaming]
        if not addrs:
            self.log_view.append_line(
                self._t("log_reset_no_streaming", "Reset: no streaming devices")
            )
            return
        self.controller.reset_processed_state_many(addrs)
        # Reset session elapsed timer as requested (acts like a "reset stream" marker).
        self._signals_session_start_monotonic_s = time.monotonic()
        self.log_view.append_line(
            self._t(
                "log_reset_cleared",
                "Reset: processed state cleared for {count} device(s)",
                count=len(addrs),
            )
        )
        self._update_signal_rx_status()

    def _signals_start_record(self) -> None:
        if self._recording:
            return
        # Record all currently streaming devices (even if not plotted).
        addrs = [a for a, d in self.controller.manager.devices.items() if d.is_streaming]
        if not addrs:
            self.log_view.append_line(
                self._t(
                    "log_record_no_streaming",
                    "Record: no streaming devices (start streaming first)",
                )
            )
            return
        # Use configured output folder (Settings → Recording Data). If missing, ask once.
        out_base = str(getattr(self, "_rec_out_dir", "") or "").strip()
        if not out_base:
            options = QtWidgets.QFileDialog.Option.ShowDirsOnly
            if sys.platform.startswith("linux") or sys.platform.startswith("win"):
                options |= QtWidgets.QFileDialog.Option.DontUseNativeDialog
            out_base = QtWidgets.QFileDialog.getExistingDirectory(
                self,
                self._t(
                    "dialog_select_recording_folder",
                    "Select recording output folder",
                ),
                "",
                options=options,
            )
            if not out_base:
                return
            try:
                self._rec_out_dir = str(out_base)
                if getattr(self, "edit_rec_out_dir", None):
                    self.edit_rec_out_dir.setText(str(out_base))
            except Exception:
                pass

        # Column selection from Settings (does not depend on sensor enable state).
        emg_fields = [f for f in self._rec_emg_fields_all if f in self._rec_emg_fields_selected]
        imu_fields = [f for f in self._rec_imu_fields_all if f in self._rec_imu_fields_selected]
        akr_fields = [f for f in self._rec_akr_fields_all if f in self._rec_akr_fields_selected]
        include_emg = bool(emg_fields)
        include_imu = bool(imu_fields)
        include_robot = bool(akr_fields)
        if not include_emg and not include_imu and not include_robot:
            self.log_view.append_line(
                self._t(
                    "log_record_no_columns",
                    "Record: no columns selected (enable at least one column in Settings -> Recording Data)",
                )
            )
            return

        # Create session folder rr_<timestamp>/ and per-device files.
        session_paths = default_recording_session_paths(out_base, prefix="rr")
        recorders: dict[str, DeviceWideRecorder] = {}
        session_kind = (
            self.controller.manager.active_session_orchestrator_kind()
            or self.controller.manager.active_session_kind()
            or "EMGS"
        )
        session_is_akr = str(session_kind).strip().upper() == "AKR"
        for a in addrs:
            dev = self.controller.manager.devices.get(a)
            if not dev:
                continue
            # Use device plot origin if latched; otherwise fall back to earliest available sample.
            origin_s = self._device_time_origin_s(a)
            if origin_s is None:
                guess: float | None = None
                try:
                    if dev.emg_buffer:
                        guess = float(dev.emg_buffer[0][0])
                    elif dev.acc_buffer:
                        guess = float(dev.acc_buffer[0][0])
                    elif getattr(dev, "raw_acc_buffer", None):
                        if dev.raw_acc_buffer:
                            guess = float(dev.raw_acc_buffer[0][0])
                    elif getattr(dev, "akr", None) and dev.akr.akr_step_dt_ms_buffer:
                        guess = float(dev.akr.akr_step_dt_ms_buffer[0][0])
                except Exception:
                    guess = None
                origin_s = float(guess) if guess is not None else 0.0

            paths = device_recording_paths(
                session_paths,
                addr=str(a),
                include_emg=include_emg,
                include_imu=include_imu,
                include_robot=(include_robot and session_is_akr),
                prefix="rr",
            )
            try:
                recorders[str(a)] = create_session_device_recorder(
                    session_kind=session_kind,
                    addr=str(a),
                    paths=paths,
                    origin_s=float(origin_s),
                    emg_fields=emg_fields,
                    imu_fields=imu_fields,
                    robot_fields=(akr_fields if session_is_akr else []),
                    on_log=self.log_view.append_line,
                )
            except Exception as e:
                self.log_view.append_line(
                    self._t(
                        "log_record_open_failed",
                        "Record: failed to open files for {addr}: {error}",
                        addr=a,
                        error=e,
                    )
                )

        if not recorders:
            self.log_view.append_line(
                self._t(
                    "log_record_failed_start",
                    "Record: failed to start (no recorders created)",
                )
            )
            return

        # Prime recorder cursors at start so only post-start samples are recorded.
        for addr, recorder in recorders.items():
            dev = self.controller.manager.devices.get(str(addr))
            if dev is None:
                continue
            try:
                recorder.prime_capture_cursors(dev)
            except Exception:
                pass

        self._recorder = RecordingSession(session_paths=session_paths, recorders=recorders, on_log=self.log_view.append_line)
        self._recording = True
        self._recording_start_monotonic_s = time.monotonic()
        self._last_recording_duration_s = None
        if hasattr(self, "_set_recording_visual_state"):
            self._set_recording_visual_state(True)
        self.log_view.append_line(
            self._t(
                "log_record_started",
                "Record: started ({count} device(s))",
                count=len(recorders),
            )
        )
        self._update_signal_rx_status()

    def _open_recording_output_folder(self, out_dir: Path | None) -> bool:
        if out_dir is None:
            return False
        try:
            folder = Path(out_dir)
            if not folder.exists():
                return False
            return bool(
                QtGui.QDesktopServices.openUrl(
                    QtCore.QUrl.fromLocalFile(str(folder.resolve()))
                )
            )
        except Exception:
            return False

    def _signals_stop_record(self, *, reveal_output_folder: bool = True) -> None:
        if not self._recording:
            return

        # Stop flow is order-sensitive:
        # 1) Snapshot the session directory before closing the recorder.
        # 2) Close all writers and reset in-memory recording state.
        # 3) Optionally reveal the finished output folder for user-triggered stops.
        output_dir: Path | None = None
        if self._recorder is not None:
            try:
                output_dir = Path(self._recorder.session_paths.root_dir)
            except Exception:
                output_dir = None
        t0 = float(self._recording_start_monotonic_s) if self._recording_start_monotonic_s is not None else None
        try:
            if self._recorder is not None:
                self._recorder.close()
        except Exception:
            pass
        self._recorder = None
        self._recording = False
        self._recording_start_monotonic_s = None
        if hasattr(self, "_set_recording_visual_state"):
            self._set_recording_visual_state(False)
        if t0 is not None:
            self._last_recording_duration_s = float(max(0.0, time.monotonic() - t0))
        self.log_view.append_line(self._t("log_record_stopped", "Record: stopped"))
        if reveal_output_folder and output_dir is not None:
            opened = self._open_recording_output_folder(output_dir)
            if opened:
                self.log_view.append_line(
                    self._t(
                        "log_record_folder_opened",
                        "Record: opened folder -> {path}",
                        path=str(output_dir),
                    )
                )
            else:
                self.log_view.append_line(
                    self._t(
                        "log_record_folder_open_failed",
                        "Record: failed to open folder -> {path}",
                        path=str(output_dir),
                    )
                )
        self._update_signal_rx_status()

    def _set_plot_frozen(self, frozen: bool) -> None:
        self._plot_frozen = bool(frozen)
        for btn in (getattr(self, "btn_sig_freeze", None), getattr(self, "btn_scn_freeze", None)):
            if not btn:
                continue
            try:
                btn.blockSignals(True)
                btn.setChecked(bool(self._plot_frozen))
                btn.setText(
                    self._t("btn_frozen", "Frozen")
                    if self._plot_frozen
                    else self._t("btn_freeze", "Freeze")
                )
            except Exception:
                pass
            finally:
                try:
                    btn.blockSignals(False)
                except Exception:
                    pass
        # Keep a subtle hint in the status bar.
        try:
            if self._plot_frozen:
                self.status.showMessage(
                    self._t(
                        "status_plot_frozen",
                        "Plot frozen (stream continues).",
                    )
                )
            else:
                self.status.showMessage(
                    self._t(
                        "status_backend",
                        "Backend: {backend}",
                        backend=self.controller.backend_kind,
                    )
                )
        except Exception:
            pass

