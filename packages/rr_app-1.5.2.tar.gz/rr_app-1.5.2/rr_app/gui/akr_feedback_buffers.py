from __future__ import annotations


def resolve_akr_buffer(dev: object, buffer_name: str) -> object | None:
    """Return an AKR telemetry buffer by name from device state."""
    # AKR decode writes rr_telem channels under `dev.akr`.
    # We still check the top-level device object as a guarded fallback
    # so callers fail safe if they receive older/non-AKR state shapes.
    akr_state = getattr(dev, "akr", None)
    buf = getattr(akr_state, buffer_name, None) if akr_state is not None else None
    if buf is not None:
        return buf
    return getattr(dev, buffer_name, None)
