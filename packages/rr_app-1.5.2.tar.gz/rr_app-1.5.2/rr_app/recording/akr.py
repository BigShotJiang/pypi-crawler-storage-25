from __future__ import annotations

import time
from typing import Any


ROBOT_SCALAR_SPECS: list[tuple[str, str, str]] = [
    ("akr_step_dt_ms_buffer", "step_dt_ms", "walk"),
    ("akr_exec_ms_buffer", "exec_ms", "walk"),
    ("akr_out_buffer", "out", "walk"),
    ("akr_state_buffer", "state", "walk"),
    ("akr_walk_fid_buffer", "walk_fid", "walk"),
    ("akr_walk_dt_ms_buffer", "walk_dt_ms", "walk"),
    ("akr_walk_exec_ms_buffer", "walk_exec_ms", "walk"),
    ("akr_walk_out_buffer", "walk_out", "walk"),
    ("akr_walk_state_buffer", "walk_state", "walk"),
    ("akr_walk_tilt_forward_deg_buffer", "walk_tilt_forward_deg", "walk"),
    ("akr_walk_pos_rad_buffer", "walk_pos_rad", "walk"),
    ("akr_walk_vel_rad_s_buffer", "walk_vel_rad_s", "walk"),
    ("akr_walk_tq_nm_buffer", "walk_tq_nm", "walk"),
    ("akr_walk_temp_c_buffer", "walk_temp_c", "walk"),
    ("akr_walk_vbus_v_buffer", "walk_vbus_v", "walk"),
    ("akr_walk_pattern_buffer", "walk_pattern", "walk"),
    ("akr_walk_err_code_buffer", "walk_err_code", "walk"),
    ("akr_walk_fb_age_ms_buffer", "walk_fb_age_ms", "walk"),
    ("akr_cpm_fid_buffer", "cpm_fid", "cpm"),
    ("akr_cpm_dt_ms_buffer", "cpm_dt_ms", "cpm"),
    ("akr_cpm_state_buffer", "cpm_state", "cpm"),
    ("akr_cpm_dir_buffer", "cpm_dir", "cpm"),
    ("akr_cpm_blocked_event_buffer", "cpm_blocked_event", "cpm"),
    ("akr_cpm_block_reason_buffer", "cpm_block_reason", "cpm"),
    ("akr_cpm_blocked_consecutive_buffer", "cpm_blocked_consecutive", "cpm"),
    ("akr_cpm_cmd_spd_rad_s_buffer", "cpm_cmd_spd_rad_s", "cpm"),
    ("akr_cpm_pos_rad_buffer", "cpm_pos_rad", "cpm"),
    ("akr_cpm_vel_rad_s_buffer", "cpm_vel_rad_s", "cpm"),
    ("akr_cpm_tq_nm_buffer", "cpm_tq_nm", "cpm"),
    ("akr_cpm_temp_c_buffer", "cpm_temp_c", "cpm"),
    ("akr_cpm_vbus_v_buffer", "cpm_vbus_v", "cpm"),
    ("akr_cpm_pattern_buffer", "cpm_pattern", "cpm"),
    ("akr_cpm_err_code_buffer", "cpm_err_code", "cpm"),
    ("akr_cpm_fb_age_ms_buffer", "cpm_fb_age_ms", "cpm"),
    ("akr_cpm_df_limit_rad_buffer", "cpm_df_limit_rad", "cpm"),
    ("akr_cpm_pf_limit_rad_buffer", "cpm_pf_limit_rad", "cpm"),
    ("akr_cpm_elapsed_s_buffer", "cpm_elapsed_s", "cpm"),
    ("akr_cpm_remaining_s_buffer", "cpm_remaining_s", "cpm"),
    ("akr_cpm_has_remaining_buffer", "cpm_has_remaining", "cpm"),
    ("akr_cpm_repetition_count_buffer", "cpm_repetition_count", "cpm"),
    ("akr_test_fid_buffer", "measure_fid", "measure"),
    ("akr_test_dt_ms_buffer", "measure_dt_ms", "measure"),
    ("akr_test_state_buffer", "measure_state", "measure"),
    ("akr_test_dir_buffer", "measure_dir", "measure"),
    ("akr_test_blocked_buffer", "measure_blocked", "measure"),
    ("akr_test_result_flags_buffer", "measure_result_flags", "measure"),
    ("akr_test_pos_rad_buffer", "measure_pos_rad", "measure"),
    ("akr_test_vel_rad_s_buffer", "measure_vel_rad_s", "measure"),
    ("akr_test_tq_nm_buffer", "measure_tq_nm", "measure"),
    ("akr_test_temp_c_buffer", "measure_temp_c", "measure"),
    ("akr_test_vbus_v_buffer", "measure_vbus_v", "measure"),
    ("akr_test_pattern_buffer", "measure_pattern", "measure"),
    ("akr_test_err_code_buffer", "measure_err_code", "measure"),
    ("akr_test_fb_age_ms_buffer", "measure_fb_age_ms", "measure"),
    ("akr_test_prom_df_end_rad_buffer", "measure_prom_df_end_rad", "measure"),
    ("akr_test_prom_pf_end_rad_buffer", "measure_prom_pf_end_rad", "measure"),
    ("akr_test_arom_df_max_rad_buffer", "measure_arom_df_max_rad", "measure"),
    ("akr_test_arom_pf_min_rad_buffer", "measure_arom_pf_min_rad", "measure"),
    ("akr_test_flag_prom_df_valid_buffer", "measure_flag_prom_df_valid", "measure"),
    ("akr_test_flag_prom_pf_valid_buffer", "measure_flag_prom_pf_valid", "measure"),
    ("akr_test_flag_arom_valid_buffer", "measure_flag_arom_valid", "measure"),
    ("akr_test_flag_seq_active_buffer", "measure_flag_seq_active", "measure"),
    ("akr_test_flag_arom_running_buffer", "measure_flag_arom_running", "measure"),
]

CFG_SCALAR_SPECS: list[tuple[str, str]] = [
    ("akr_cfg_fid_buffer", "cfg_fid"),
    ("akr_cfg_side_is_left_buffer", "cfg_side_is_left"),
    ("akr_cfg_df_assist_pct_buffer", "cfg_df_assist_pct"),
    ("akr_cfg_pf_assist_pct_buffer", "cfg_pf_assist_pct"),
    ("akr_cfg_df_torque_buffer", "cfg_df_torque"),
    ("akr_cfg_df_angle_buffer", "cfg_df_angle"),
    ("akr_cfg_df_speed_buffer", "cfg_df_speed"),
    ("akr_cfg_df_kp_buffer", "cfg_df_kp"),
    ("akr_cfg_df_kd_buffer", "cfg_df_kd"),
    ("akr_cfg_pf_torque_buffer", "cfg_pf_torque"),
    ("akr_cfg_pf_angle_buffer", "cfg_pf_angle"),
    ("akr_cfg_pf_speed_buffer", "cfg_pf_speed"),
    ("akr_cfg_pf_kp_buffer", "cfg_pf_kp"),
    ("akr_cfg_pf_kd_buffer", "cfg_pf_kd"),
    ("akr_cfg_cpm_target_df_rad_buffer", "cfg_cpm_target_df_rad"),
    ("akr_cfg_cpm_target_pf_rad_buffer", "cfg_cpm_target_pf_rad"),
    ("akr_cfg_cpm_speed_to_df_rad_s_buffer", "cfg_cpm_speed_to_df_rad_s"),
    ("akr_cfg_cpm_speed_to_pf_rad_s_buffer", "cfg_cpm_speed_to_pf_rad_s"),
    ("akr_cfg_cpm_block_tq_nm_buffer", "cfg_cpm_block_tq_nm"),
    ("akr_cfg_cpm_wait_to_df_ms_buffer", "cfg_cpm_wait_to_df_ms"),
    ("akr_cfg_cpm_wait_to_pf_ms_buffer", "cfg_cpm_wait_to_pf_ms"),
    ("akr_cfg_gait_model_buffer", "cfg_gait_model"),
    ("akr_cfg_gait_mode_buffer", "cfg_gait_mode"),
]

ROBOT_VEC_SPECS: list[tuple[str, str, str]] = [
    ("acc_buffer", "acc", "walk"),
    ("gyr_buffer", "gyr", "walk"),
    ("mag_buffer", "mag", "walk"),
    ("akr_walk_acc_buffer", "walk_acc", "walk"),
    ("akr_walk_gyr_buffer", "walk_gyr", "walk"),
    ("akr_walk_mag_buffer", "walk_mag", "walk"),
]

FID_BUFFER_BY_PACKET: dict[str, tuple[str, str]] = {
    "walk": ("akr_walk_fid_buffer", "walk_fid"),
    "cpm": ("akr_cpm_fid_buffer", "cpm_fid"),
    "measure": ("akr_test_fid_buffer", "measure_fid"),
}


def capture_akr_stream(recorder: Any, *, dev: object, origin: float, source_mode: str) -> None:
    if not bool(getattr(recorder, "_robot_enabled", False)):
        return

    akr = getattr(dev, "akr", None)
    source = akr if akr is not None else dev
    akr_scalar_rows: dict[str, list[tuple[float, list[float]]]] = {}
    akr_vec_rows: dict[str, list[tuple[float, list[float]]]] = {}
    cfg_scalar_rows: dict[str, list[tuple[float, list[float]]]] = {}

    for buf_name, _field, _packet in ROBOT_SCALAR_SPECS:
        buf = getattr(source, buf_name, None)
        if not buf:
            continue
        rows = recorder._iter_new_from_deque(str(buf_name), buf)
        if rows:
            akr_scalar_rows[str(buf_name)] = rows
    for buf_name, _sig, _packet in ROBOT_VEC_SPECS:
        buf = getattr(source, buf_name, None)
        if not buf:
            continue
        rows = recorder._iter_new_from_deque(str(buf_name) + ":robot", buf)
        if rows:
            akr_vec_rows[str(buf_name)] = rows
    for buf_name, _field in CFG_SCALAR_SPECS:
        buf = getattr(source, buf_name, None)
        if not buf:
            continue
        rows = recorder._iter_new_from_deque(str(buf_name) + ":cfg", buf)
        if rows:
            cfg_scalar_rows[str(buf_name)] = rows

    for buf_name, field in CFG_SCALAR_SPECS:
        rows = cfg_scalar_rows.get(str(buf_name), [])
        for _ts, vals in rows:
            if not vals:
                continue
            recorder._update_robot_cfg_latest(str(field), vals[0])

    akr_ts_map: dict[tuple[str, int], tuple[str, int, int]] = {}
    for packet_type, (buf_name, fid_field) in FID_BUFFER_BY_PACKET.items():
        rows = akr_scalar_rows.get(str(buf_name), [])
        for ts, vals in rows:
            if not vals:
                continue
            try:
                fid = int(round(float(vals[0])))
            except Exception:
                continue
            t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_20, stream="robot")
            if t_ms is None:
                continue
            row_key = recorder._ensure_robot_frame(
                packet_type=packet_type,
                source_mode=source_mode,
                frame_fid=fid,
                t_ms=t_ms,
            )
            if row_key is None:
                continue
            akr_ts_map[(str(packet_type), recorder._robot_ts_key(float(ts)))] = row_key
            recorder._set_robot_scalar(
                str(fid_field),
                row_key=row_key,
                source_mode=source_mode,
                t_ms=t_ms,
                value=float(vals[0]),
                collide_tag=f"{str(packet_type).upper()}_FID",
            )

    for buf_name, field, packet_type in ROBOT_SCALAR_SPECS:
        if str(field) == str(FID_BUFFER_BY_PACKET.get(str(packet_type), ("", ""))[1]):
            continue
        rows = akr_scalar_rows.get(str(buf_name), [])
        for ts, vals in rows:
            t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_20, stream="robot")
            if t_ms is None:
                continue
            row_key = recorder._resolve_robot_row_key(
                packet_type=str(packet_type),
                ts_s=float(ts),
                ts_map=akr_ts_map,
            )
            if row_key is None:
                recorder._robot_unmapped_value_drop_n += 1
                continue
            value = vals[0] if vals else ""
            recorder._set_robot_scalar(
                str(field),
                row_key=row_key,
                source_mode=source_mode,
                t_ms=t_ms,
                value=value,
                collide_tag=str(packet_type).upper(),
            )

    for buf_name, sig, packet_type in ROBOT_VEC_SPECS:
        rows = akr_vec_rows.get(str(buf_name), [])
        for ts, vals in rows:
            t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_20, stream="robot")
            if t_ms is None:
                continue
            row_key = recorder._resolve_robot_row_key(
                packet_type=str(packet_type),
                ts_s=float(ts),
                ts_map=akr_ts_map,
            )
            if row_key is None:
                recorder._robot_unmapped_value_drop_n += 1
                continue
            recorder._set_robot_vec3(
                str(sig),
                row_key=row_key,
                source_mode=source_mode,
                t_ms=t_ms,
                vals=list(vals),
                collide_tag=str(sig).upper(),
            )

    if recorder._robot_w is not None and bool(getattr(akr, "akr_robot_identity_seen", False)):
        rid = recorder._robot_id_csv_value(getattr(akr, "akr_robot_id", ""))
        ble_target = str(getattr(akr, "akr_ble_target_name", "") or "").strip()
        if not ble_target:
            rid_raw = str(getattr(akr, "akr_robot_id", "") or "").strip()
            ble_target = (f"AKR_{rid_raw}" if rid_raw else "AKR")
        text_fields = {
            "cfg_robot_id": rid,
            "cfg_ble_target": ble_target,
        }
        t_ms_identity = recorder._round_t_ms_or_none(
            float(time.monotonic()) - origin,
            rounder=recorder._round_ms_20,
            stream="robot",
        )
        if t_ms_identity is not None:
            for field, value in text_fields.items():
                if recorder._robot_idx.get(str(field)) is None:
                    continue
                cur = str(value)
                if recorder._robot_text_last.get(str(field), "") == cur:
                    continue
                recorder._update_robot_cfg_latest(str(field), cur)
                row_key = recorder._resolve_latest_robot_non_cfg_row_key()
                if row_key is None:
                    continue
                recorder._robot_text_last[str(field)] = cur
                recorder._set_robot_scalar(
                    str(field),
                    row_key=row_key,
                    source_mode=source_mode,
                    t_ms=t_ms_identity,
                    value=cur,
                    collide_tag="CFG",
                )

