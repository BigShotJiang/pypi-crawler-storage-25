from __future__ import annotations

from typing import Any


def capture_emg_imu_stream(recorder: Any, *, dev: object, origin: float) -> None:
    # EMG/IMU capture flow is intentionally grouped here:
    # 1) drain each ring buffer using recorder cursor state,
    # 2) align timestamps per stream policy (1 ms EMG, 10 ms IMU),
    # 3) write into recorder pending-row maps (last-write-wins on collisions).
    # Keeping this flow in one helper isolates EMGS-oriented field mapping from
    # AKR packet handling and keeps DeviceWideRecorder.capture orchestration-thin.
    buf = getattr(dev, "emg_buffer", None)
    if recorder._emg_w is not None and buf:
        rows = recorder._iter_new_from_deque("emg_buffer", buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_1, stream="emg")
                if t_ms is None:
                    continue
                recorder._emg_max_ms = max(recorder._emg_max_ms, int(t_ms))
                recorder._set_emg("emg_raw_mV", t_ms, (vals[0] if vals else ""))

    buf = getattr(dev, "emg_ecg_clean_buffer", None)
    if recorder._emg_w is not None and buf:
        rows = recorder._iter_new_from_deque("emg_ecg_clean_buffer", buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_1, stream="emg")
                if t_ms is None:
                    continue
                recorder._emg_max_ms = max(recorder._emg_max_ms, int(t_ms))
                recorder._set_emg("emg_clean_ecg_mV", t_ms, (vals[0] if vals else ""))

    buf = getattr(dev, "emg_ecg_artifact_buffer", None)
    if recorder._emg_w is not None and buf:
        rows = recorder._iter_new_from_deque("emg_ecg_artifact_buffer", buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_1, stream="emg")
                if t_ms is None:
                    continue
                recorder._emg_max_ms = max(recorder._emg_max_ms, int(t_ms))
                recorder._set_emg("emg_ecg_artifact_mV", t_ms, (vals[0] if vals else ""))

    buf = getattr(dev, "emg_rms_buffer", None)
    if recorder._emg_w is not None and buf:
        rows = recorder._iter_new_from_deque("emg_rms_buffer", buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_1, stream="emg")
                if t_ms is None:
                    continue
                recorder._emg_max_ms = max(recorder._emg_max_ms, int(t_ms))
                recorder._set_emg("emg_env_rms", t_ms, (vals[0] if vals else ""))

    buf = getattr(dev, "emg_median_freq_buffer", None)
    if recorder._emg_w is not None and buf:
        rows = recorder._iter_new_from_deque("emg_median_freq_buffer", buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_1, stream="emg")
                if t_ms is None:
                    continue
                recorder._emg_max_ms = max(recorder._emg_max_ms, int(t_ms))
                recorder._set_emg("emg_mdf_hz", t_ms, (vals[0] if vals else ""))

    buf = getattr(dev, "emg_mean_freq_buffer", None)
    if recorder._emg_w is not None and buf:
        rows = recorder._iter_new_from_deque("emg_mean_freq_buffer", buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_1, stream="emg")
                if t_ms is None:
                    continue
                recorder._emg_max_ms = max(recorder._emg_max_ms, int(t_ms))
                recorder._set_emg("emg_mnf_hz", t_ms, (vals[0] if vals else ""))

    buf = getattr(dev, "emg_packet_rms_buffer", None)
    if recorder._emg_w is not None and buf:
        rows = recorder._iter_new_from_deque("emg_packet_rms_buffer", buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_1, stream="emg")
                if t_ms is None:
                    continue
                recorder._emg_max_ms = max(recorder._emg_max_ms, int(t_ms))
                recorder._set_emg("emg_pkt_rms_v", t_ms, (vals[0] if vals else ""))

    buf = getattr(dev, "emg_snr_buffer", None)
    if recorder._emg_w is not None and buf:
        rows = recorder._iter_new_from_deque("emg_snr_buffer", buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_1, stream="emg")
                if t_ms is None:
                    continue
                recorder._emg_max_ms = max(recorder._emg_max_ms, int(t_ms))
                recorder._set_emg("emg_snr", t_ms, (vals[0] if vals else ""))

    buf = getattr(dev, "emg_fatigue_score_buffer", None)
    if recorder._emg_w is not None and buf:
        rows = recorder._iter_new_from_deque("emg_fatigue_score_buffer", buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_1, stream="emg")
                if t_ms is None:
                    continue
                recorder._emg_max_ms = max(recorder._emg_max_ms, int(t_ms))
                recorder._set_emg("fatigue_score", t_ms, (vals[0] if vals else ""))

    buf = getattr(dev, "emg_fatigue_conf_buffer", None)
    if recorder._emg_w is not None and buf:
        rows = recorder._iter_new_from_deque("emg_fatigue_conf_buffer", buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_1, stream="emg")
                if t_ms is None:
                    continue
                recorder._emg_max_ms = max(recorder._emg_max_ms, int(t_ms))
                recorder._set_emg("fatigue_conf", t_ms, (vals[0] if vals else ""))

    imu_specs = [
        ("raw_acc_buffer", "raw_acc", 3),
        ("acc_buffer", "acc", 3),
        ("lin_acc_buffer", "lin_acc", 3),
        ("raw_gyr_buffer", "raw_gyr", 3),
        ("gyr_buffer", "gyr", 3),
        ("uncal_mag_buffer", "uncal_mag", 3),
        ("mag_buffer", "mag", 3),
        ("quat_game_buffer", "quat_game", 4),
        ("quat_geomag_buffer", "quat_geomag", 4),
    ]
    for buf_name, sig, dim in imu_specs:
        buf = getattr(dev, buf_name, None)
        if recorder._imu_w is None or not buf:
            continue
        rows = recorder._iter_new_from_deque(str(buf_name), buf)
        if rows:
            for ts, vals in rows:
                t_ms = recorder._round_t_ms_or_none(float(ts) - origin, rounder=recorder._round_ms_10, stream="imu")
                if t_ms is None:
                    continue
                recorder._imu_max_ms = max(recorder._imu_max_ms, int(t_ms))
                if int(dim) == 4:
                    recorder._set_imu_vec4(str(sig), t_ms, vals)
                elif int(dim) == 1:
                    recorder._set_imu_scalar(str(sig), t_ms, (vals[0] if vals else ""))
                else:
                    recorder._set_imu_vec3(str(sig), t_ms, vals)
