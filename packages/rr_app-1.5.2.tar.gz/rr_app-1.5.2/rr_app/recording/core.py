from __future__ import annotations

import csv
import datetime as _dt
import json
import math
from dataclasses import dataclass
from pathlib import Path
import heapq
import time
from typing import Any, Callable, Deque, Optional

from .akr import capture_akr_stream
from .emgs import capture_emg_imu_stream


_ROBOT_MEASURE_FIELD_ALIASES: dict[str, str] = {
    # Canonical (v5+) -> legacy (v4)
    "measure_fid": "test_fid",
    "measure_dt_ms": "test_dt_ms",
    "measure_state": "test_state",
    "measure_dir": "test_dir",
    "measure_blocked": "test_blocked",
    "measure_result_flags": "test_result_flags",
    "measure_pos_rad": "test_pos_rad",
    "measure_vel_rad_s": "test_vel_rad_s",
    "measure_tq_nm": "test_tq_nm",
    "measure_temp_c": "test_temp_c",
    "measure_vbus_v": "test_vbus_v",
    "measure_pattern": "test_pattern",
    "measure_err_code": "test_err_code",
    "measure_fb_age_ms": "test_fb_age_ms",
    "measure_prom_df_end_rad": "test_prom_df_end_rad",
    "measure_prom_pf_end_rad": "test_prom_pf_end_rad",
    "measure_arom_df_max_rad": "test_arom_df_max_rad",
    "measure_arom_pf_min_rad": "test_arom_pf_min_rad",
    "measure_flag_prom_df_valid": "test_flag_prom_df_valid",
    "measure_flag_prom_pf_valid": "test_flag_prom_pf_valid",
    "measure_flag_arom_valid": "test_flag_arom_valid",
    "measure_flag_seq_active": "test_flag_seq_active",
    "measure_flag_arom_running": "test_flag_arom_running",
}

# Also support reverse lookup for legacy-selected columns.
_ROBOT_MEASURE_FIELD_ALIASES.update({v: k for k, v in list(_ROBOT_MEASURE_FIELD_ALIASES.items())})
_ROBOT_MEASURE_LEGACY_TO_CANON: dict[str, str] = {
    k: v for k, v in _ROBOT_MEASURE_FIELD_ALIASES.items() if str(k).startswith("test_")
}

_ROBOT_FID_GAP_FILL_MAX = 200
_ROBOT_FLUSH_LAG_FIDS = 16
_ROBOT_KEY_COLUMNS: tuple[str, ...] = (
    "t_ms",
    "segment_id",
    "packet_type",
    "source_mode",
    "frame_fid",
    "note",
)


@dataclass(slots=True)
class RecordingPaths:
    emg_csv: Path | None
    imu_csv: Path | None
    robot_csv: Path | None


def default_recording_paths(
    out_dir: str | Path,
    *,
    prefix: str = "recording",
    include_emg: bool = True,
    include_imu: bool = True,
    include_robot: bool = False,
) -> RecordingPaths:
    # Backwards-compatible helper (single device). Prefer using RecordingSessionPaths below.
    ts = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    return RecordingPaths(
        emg_csv=(out / f"{prefix}_{ts}_emg.csv") if include_emg else None,
        imu_csv=(out / f"{prefix}_{ts}_imu.csv") if include_imu else None,
        robot_csv=(out / f"{prefix}_{ts}_robot.csv") if include_robot else None,
    )


@dataclass(slots=True)
class RecordingSessionPaths:
    """Folder + timestamp used for a recording session."""

    root_dir: Path
    timestamp: str  # YYYYMMDD_HHMMSS


def default_recording_session_paths(base_dir: str | Path, *, prefix: str = "rr") -> RecordingSessionPaths:
    ts = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    root = Path(base_dir) / f"{prefix}_{ts}"
    root.mkdir(parents=True, exist_ok=True)
    return RecordingSessionPaths(root_dir=root, timestamp=ts)


def _sanitize_addr(addr: str) -> str:
    return str(addr).replace(":", "").replace("-", "").strip() or "addr"


def device_recording_paths(
    session: RecordingSessionPaths,
    *,
    addr: str,
    include_emg: bool,
    include_imu: bool,
    include_robot: bool,
    prefix: str = "rr",
) -> RecordingPaths:
    a = _sanitize_addr(addr)
    ts = str(session.timestamp)
    out = Path(session.root_dir)
    return RecordingPaths(
        emg_csv=(out / f"{prefix}_emg_{a}_{ts}.csv") if include_emg else None,
        imu_csv=(out / f"{prefix}_imu_{a}_{ts}.csv") if include_imu else None,
        robot_csv=(out / f"{prefix}_robot_{a}_{ts}.csv") if include_robot else None,
    )


class DeviceWideRecorder:
    """Per-device recorder producing wide CSVs.

    - EMG: 1 ms alignment
    - IMU: 10 ms alignment
    - AKR telemetry (AKR/RR_AKR): fid-keyed rows with 20 ms host timestamp metadata
    """

    def __init__(
        self,
        *,
        addr: str,
        paths: RecordingPaths,
        origin_s: float,
        emg_fields: list[str],
        imu_fields: list[str],
        robot_fields: list[str] | None = None,
        on_log: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.addr = str(addr)
        self.paths = paths
        self.origin_s = float(origin_s)
        self.emg_fields = list(emg_fields)
        self.imu_fields = list(imu_fields)
        self.robot_fields = self._normalize_robot_fields_for_csv(list(robot_fields or []))
        self._on_log = on_log
        self._record_started_utc = _dt.datetime.now(_dt.timezone.utc)
        self._record_started_monotonic_s = time.monotonic()
        self._metadata_json_path = self._build_metadata_json_path()

        # (addr, buf_name) -> last_ts_s captured
        self._last_ts: dict[str, float] = {}

        # Pending rows.
        self._emg_rows: dict[int, list[Any]] = {}
        self._imu_rows: dict[int, list[Any]] = {}
        self._robot_rows: dict[tuple[str, int, int], list[Any]] = {}
        self._emg_max_ms: int = -10**18
        self._imu_max_ms: int = -10**18
        self._emg_heap: list[int] = []
        self._imu_heap: list[int] = []
        self._robot_fid_heap_by_stream: dict[tuple[str, int], list[int]] = {}
        self._robot_fid_set_by_stream: dict[tuple[str, int], set[int]] = {}
        self._robot_max_fid_by_stream: dict[tuple[str, int], int] = {}
        self._robot_last_fid_by_packet: dict[str, int] = {}
        self._robot_segment_by_packet: dict[str, int] = {}
        self._robot_latest_key_by_packet: dict[str, tuple[str, int, int]] = {}
        self._emg_heap_set: set[int] = set()
        self._imu_heap_set: set[int] = set()
        self._robot_missing_fid_fill_max: int = int(_ROBOT_FID_GAP_FILL_MAX)
        self._robot_flush_lag_fids: int = int(_ROBOT_FLUSH_LAG_FIDS)

        self._emg_f = None
        self._emg_w = None
        self._emg_header: list[str] = []
        self._emg_idx: dict[str, int] = {}
        self._emg_state_i: int | None = None
        self._emg_collide_n: int = 0
        if self.paths.emg_csv is not None:
            self._emg_header, self._emg_idx = self._build_emg_header(self.emg_fields)
            self._emg_state_i = self._emg_idx.get("state")
            self._emg_f = open(self.paths.emg_csv, "w", newline="", encoding="utf-8")
            self._emg_w = csv.writer(self._emg_f)
            self._emg_w.writerow(self._emg_header)

        self._imu_f = None
        self._imu_w = None
        self._imu_header: list[str] = []
        self._imu_idx: dict[str, int] = {}
        self._imu_state_i: int | None = None
        self._imu_collide_n: int = 0
        if self.paths.imu_csv is not None:
            self._imu_header, self._imu_idx = self._build_imu_header(self.imu_fields)
            self._imu_state_i = self._imu_idx.get("state")
            self._imu_f = open(self.paths.imu_csv, "w", newline="", encoding="utf-8")
            self._imu_w = csv.writer(self._imu_f)
            self._imu_w.writerow(self._imu_header)

        self._robot_f = None
        self._robot_w = None
        self._robot_header: list[str] = []
        self._robot_idx: dict[str, int] = {}
        self._robot_segment_i: int | None = None
        self._robot_packet_i: int | None = None
        self._robot_source_mode_i: int | None = None
        self._robot_frame_fid_i: int | None = None
        self._robot_note_i: int | None = None
        self._robot_collide_n: int = 0
        self._robot_discontinuity_n: int = 0
        self._robot_unmapped_value_drop_n: int = 0
        self._robot_enabled: bool = self.paths.robot_csv is not None
        self._robot_base_csv_path: Path | None = Path(self.paths.robot_csv) if self.paths.robot_csv is not None else None
        self._robot_active_segment_label: str | None = None
        self._robot_active_session_mode: str | None = None
        self._robot_active_file_mode_label: str | None = None
        self._robot_active_file_seq: int = 0
        self._robot_file_seq_global: int = 0
        self._robot_last_source_mode: str | None = None
        self._robot_idle_split_pending: bool = False
        self._robot_force_split_next_segment: bool = False
        self._robot_deferred_split_pending: bool = False
        self._robot_deferred_split_from_mode: str | None = None
        self._robot_deferred_split_to_mode: str | None = None
        self._robot_active_csv_path: Path | None = None
        self._robot_paths_written: list[Path] = []
        self._robot_segment_metadata: list[dict[str, Any]] = []
        self._robot_rows_written_segment_n: int = 0
        self._robot_compacted_drop_n_total: int = 0
        self._robot_cfg_latest: dict[str, Any] = {}
        self._robot_cfg_fields_selected: set[str] = set(
            str(f) for f in self.robot_fields if str(f).startswith("cfg_")
        )
        self._robot_latest_non_cfg_key: tuple[str, int, int] | None = None
        self._robot_compacted_drop_n: int = 0
        self._robot_text_last: dict[str, str] = {}
        self._emg_negative_t_ms_drop_n: int = 0
        self._imu_negative_t_ms_drop_n: int = 0
        self._robot_negative_t_ms_drop_n: int = 0
        self._emg_rows_written_n: int = 0
        self._imu_rows_written_n: int = 0
        self._robot_rows_written_n: int = 0
        if self.paths.robot_csv is not None:
            self._robot_header, self._robot_idx = self._build_robot_header(self.robot_fields)
            self._robot_segment_i = self._robot_idx.get("segment_id")
            self._robot_packet_i = self._robot_idx.get("packet_type")
            self._robot_source_mode_i = self._robot_idx.get("source_mode")
            self._robot_frame_fid_i = self._robot_idx.get("frame_fid")
            self._robot_note_i = self._robot_idx.get("note")

        if self.paths.emg_csv is not None:
            self._log(f"Recording: EMG -> {self.paths.emg_csv}")
        if self.paths.imu_csv is not None:
            self._log(f"Recording: IMU -> {self.paths.imu_csv}")
        if self.paths.robot_csv is not None:
            self._log(f"Recording: AKR base -> {self.paths.robot_csv}")

    def _log(self, msg: str) -> None:
        if self._on_log:
            self._on_log(msg)

    def _build_metadata_json_path(self) -> Path | None:
        sample_csv_path: Path | None = None
        for candidate in (self.paths.emg_csv, self.paths.imu_csv, self.paths.robot_csv):
            if candidate is not None:
                sample_csv_path = Path(candidate)
                break
        if sample_csv_path is None:
            return None
        # Keep metadata filename deterministic per device/session while avoiding CSV parsing changes.
        # Example: rr_meta_AA11BB22_20260420_120102.json
        stem_parts = str(sample_csv_path.stem).split("_")
        session_ts = ""
        if len(stem_parts) >= 2 and stem_parts[-2].isdigit() and stem_parts[-1].isdigit():
            if len(stem_parts[-2]) == 8 and len(stem_parts[-1]) == 6:
                session_ts = f"{stem_parts[-2]}_{stem_parts[-1]}"
            else:
                session_ts = stem_parts[-1]
        elif stem_parts:
            session_ts = stem_parts[-1]
        ts_suffix = f"_{session_ts}" if session_ts else ""
        return sample_csv_path.parent / f"rr_meta_{_sanitize_addr(self.addr)}{ts_suffix}.json"

    def _stream_metadata(
        self,
        *,
        csv_path: Path | None,
        header: list[str],
        selected_fields: list[str],
        alignment_ms: int,
        flush_lag_ms: int,
        rows_written: int,
        collisions: int,
        dropped_negative_t_ms: int,
        dropped_empty_columns: int = 0,
    ) -> dict[str, Any]:
        enabled = csv_path is not None
        out = {
            "enabled": bool(enabled),
            "csv_path": str(csv_path) if csv_path is not None else None,
            "header": list(header),
            "selected_fields": list(selected_fields),
            "alignment_ms": int(alignment_ms),
            "flush_lag_ms": int(flush_lag_ms),
            "rows_written": int(rows_written),
            "collisions": int(collisions),
            "dropped_negative_t_ms": int(dropped_negative_t_ms),
        }
        if int(dropped_empty_columns) > 0:
            out["dropped_empty_columns"] = int(dropped_empty_columns)
        return out

    def _build_metadata_payload(self, *, ended_utc: _dt.datetime, duration_s: float) -> dict[str, Any]:
        robot_first_path = self._robot_paths_written[0] if self._robot_paths_written else None
        robot_csv_paths = [str(p) for p in self._robot_paths_written]
        robot_stream = self._stream_metadata(
            csv_path=robot_first_path,
            header=self._robot_header,
            selected_fields=self.robot_fields,
            alignment_ms=20,
            flush_lag_ms=self._robot_flush_lag_fids,
            rows_written=self._robot_rows_written_n,
            collisions=self._robot_collide_n,
            dropped_negative_t_ms=self._robot_negative_t_ms_drop_n,
            dropped_empty_columns=self._robot_compacted_drop_n_total,
        )
        robot_stream["enabled"] = bool(self._robot_enabled)
        if robot_csv_paths:
            robot_stream["csv_paths"] = list(robot_csv_paths)
        if self._robot_segment_metadata:
            robot_stream["segments"] = list(self._robot_segment_metadata)
        return {
            "schema_version": 1,
            "device_address": str(self.addr),
            "device_address_sanitized": _sanitize_addr(self.addr),
            "recording_started_utc": self._record_started_utc.isoformat(),
            "recording_ended_utc": ended_utc.isoformat(),
            "recording_duration_s": float(duration_s),
            "origin_s": float(self.origin_s),
            "timestamp_policy": {
                "negative_t_ms": "drop",
                "collision_aggregation": "last",
                "robot_row_key": "packet_type+segment_id+frame_fid",
            },
            "streams": {
                "emg": self._stream_metadata(
                    csv_path=self.paths.emg_csv,
                    header=self._emg_header,
                    selected_fields=self.emg_fields,
                    alignment_ms=1,
                    flush_lag_ms=50,
                    rows_written=self._emg_rows_written_n,
                    collisions=self._emg_collide_n,
                    dropped_negative_t_ms=self._emg_negative_t_ms_drop_n,
                ),
                "imu": self._stream_metadata(
                    csv_path=self.paths.imu_csv,
                    header=self._imu_header,
                    selected_fields=self.imu_fields,
                    alignment_ms=10,
                    flush_lag_ms=200,
                    rows_written=self._imu_rows_written_n,
                    collisions=self._imu_collide_n,
                    dropped_negative_t_ms=self._imu_negative_t_ms_drop_n,
                ),
                "robot": robot_stream,
            },
        }

    def _write_metadata_json(self) -> None:
        out = self._metadata_json_path
        if out is None:
            return
        ended_utc = _dt.datetime.now(_dt.timezone.utc)
        duration_s = max(0.0, float(time.monotonic()) - float(self._record_started_monotonic_s))
        payload = self._build_metadata_payload(ended_utc=ended_utc, duration_s=duration_s)
        try:
            out.write_text(json.dumps(payload, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
            self._log(f"Recording: metadata -> {out}")
        except Exception as e:
            self._log(f"Recording: failed to write metadata for {self.addr}: {e}")

    def close(self) -> None:
        # Flush all pending rows before closing files.
        self._flush_emg(final=True)
        self._flush_imu(final=True)
        if self._emg_f is not None:
            try:
                self._emg_f.flush()
            except Exception:
                pass
            try:
                self._emg_f.close()
            except Exception:
                pass
        if self._emg_collide_n and self._on_log:
            self._on_log(f"Recording note ({self.addr}): EMG collisions={self._emg_collide_n} (multiple samples mapped to same t_ms; last wins)")
        if self._emg_negative_t_ms_drop_n and self._on_log:
            self._on_log(f"Recording note ({self.addr}): EMG dropped_negative_t_ms={self._emg_negative_t_ms_drop_n}")
        if self._imu_f is not None:
            try:
                self._imu_f.flush()
            except Exception:
                pass
            try:
                self._imu_f.close()
            except Exception:
                pass
        if self._imu_collide_n and self._on_log:
            self._on_log(f"Recording note ({self.addr}): IMU collisions={self._imu_collide_n} (multiple samples mapped to same t_ms; last wins)")
        if self._imu_negative_t_ms_drop_n and self._on_log:
            self._on_log(f"Recording note ({self.addr}): IMU dropped_negative_t_ms={self._imu_negative_t_ms_drop_n}")
        self._finalize_active_robot_segment()
        if self._robot_collide_n and self._on_log:
            self._on_log(f"Recording note ({self.addr}): AKR collisions={self._robot_collide_n} (multiple values wrote the same packet_type+segment_id+frame_fid row; last wins)")
        if self._robot_discontinuity_n and self._on_log:
            self._on_log(
                f"Recording note ({self.addr}): AKR discontinuities={self._robot_discontinuity_n} "
                "(new packet segment file opened)"
            )
        if self._robot_unmapped_value_drop_n and self._on_log:
            self._on_log(f"Recording note ({self.addr}): AKR dropped_without_fid_context={self._robot_unmapped_value_drop_n}")
        if self._robot_negative_t_ms_drop_n and self._on_log:
            self._on_log(f"Recording note ({self.addr}): AKR dropped_negative_t_ms={self._robot_negative_t_ms_drop_n}")
        self._write_metadata_json()

    @staticmethod
    def _build_emg_header(fields: list[str]) -> tuple[list[str], dict[str, int]]:
        cols = ["t_ms", "state"] + [str(f) for f in fields]
        return cols, {c: i for i, c in enumerate(cols)}

    @staticmethod
    def _build_imu_header(fields: list[str]) -> tuple[list[str], dict[str, int]]:
        cols = ["t_ms", "state"] + [str(f) for f in fields]
        return cols, {c: i for i, c in enumerate(cols)}

    @staticmethod
    def _build_robot_header(fields: list[str]) -> tuple[list[str], dict[str, int]]:
        # Use "note" (not "state") so the robot field "state" can be recorded as data.
        cols = ["t_ms", "segment_id", "packet_type", "source_mode", "frame_fid", "note"] + [str(f) for f in fields]
        return cols, {c: i for i, c in enumerate(cols)}

    @staticmethod
    def _normalize_robot_fields_for_csv(fields: list[str]) -> list[str]:
        out: list[str] = []
        seen: set[str] = set()
        for raw in fields:
            key = str(raw)
            # Accept legacy test_* selections first.
            key = _ROBOT_MEASURE_LEGACY_TO_CANON.get(key, key)
            if key in seen:
                continue
            seen.add(key)
            out.append(key)
        return out

    @staticmethod
    def _round_ms_1(ts_s: float) -> int:
        return int(round(float(ts_s) * 1000.0))

    @staticmethod
    def _round_ms_10(ts_s: float) -> int:
        # 10 ms = 0.01 s
        return int(round(float(ts_s) * 100.0)) * 10

    @staticmethod
    def _round_ms_20(ts_s: float) -> int:
        # 20 ms = 0.02 s
        return int(round(float(ts_s) * 50.0)) * 20

    def _round_t_ms_or_none(
        self,
        rel_s: float,
        *,
        rounder: Callable[[float], int],
        stream: str,
    ) -> int | None:
        t_ms = int(rounder(float(rel_s)))
        if t_ms >= 0:
            return t_ms
        # Keep drops stream-specific so logs clearly show where negatives came from.
        stream_key = str(stream).strip().lower()
        if stream_key == "emg":
            self._emg_negative_t_ms_drop_n += 1
        elif stream_key == "imu":
            self._imu_negative_t_ms_drop_n += 1
        else:
            self._robot_negative_t_ms_drop_n += 1
        return None

    def _iter_new_from_deque(self, buf_key: str, buf: Deque[tuple[float, list[float]]]) -> list[tuple[float, list[float]]]:
        """Return new samples strictly newer than last captured timestamp for this buffer."""
        key = str(buf_key)
        last = float(self._last_ts.get(key, -1e18))
        out_rev: list[tuple[float, list[float]]] = []
        for ts, samples in reversed(buf):
            if float(ts) <= last:
                break
            out_rev.append((float(ts), list(samples)))
        if not out_rev:
            return []
        out_rev.reverse()
        self._last_ts[key] = float(out_rev[-1][0])
        return out_rev

    @staticmethod
    def _normalize_source_mode(mode_raw: object) -> str:
        # Keep mode values deterministic and parse-friendly in CSV:
        # 1) normalize host mode text to lowercase,
        # 2) strip UI suffixes like "walk • emg",
        # 3) collapse punctuation/spaces to underscores.
        token = str(mode_raw or "").strip().lower()
        if not token:
            return "unknown"
        for sep in ("•", "|"):
            if sep in token:
                token = token.split(sep, 1)[0].strip()
        if token.startswith("mode:"):
            token = token.split(":", 1)[1].strip()
        if token.endswith(" mode"):
            token = token[:-5].strip()
        out_chars: list[str] = []
        prev_us = False
        for ch in token:
            if ch.isalnum():
                out_chars.append(ch)
                prev_us = False
                continue
            if not prev_us:
                out_chars.append("_")
                prev_us = True
        normalized = "".join(out_chars).strip("_")
        return normalized or "unknown"

    @staticmethod
    def _latest_buffer_ts(buf: object) -> float | None:
        try:
            if not buf:
                return None
            tail = buf[-1]
            if not isinstance(tail, tuple) or not tail:
                return None
            return float(tail[0])
        except Exception:
            return None

    def prime_capture_cursors(self, dev: object) -> None:
        # Prime per-buffer cursors to "latest now" at record start so first capture
        # only consumes samples that arrive after Start Record.
        # We prime base key + robot/cfg suffix variants because capture() reads both.
        for attr_name in dir(dev):
            if not str(attr_name).endswith("_buffer"):
                continue
            ts = self._latest_buffer_ts(getattr(dev, str(attr_name), None))
            if ts is None:
                continue
            key = str(attr_name)
            self._last_ts[key] = float(ts)
            self._last_ts[f"{key}:robot"] = float(ts)
            self._last_ts[f"{key}:cfg"] = float(ts)

    def _robot_csv_path_for_segment(self, *, mode: str, seq: int) -> Path | None:
        base = self._robot_base_csv_path
        if base is None:
            return None
        suffix = base.suffix or ".csv"
        stem = base.stem
        # Keep segment suffix as NNmode so lexical ordering matches segment order
        # and naming stays aligned with the recorder convention (01test, 02walk, ...).
        return base.with_name(f"{stem}_{int(seq):02d}{mode}{suffix}")

    @staticmethod
    def _normalize_robot_packet_type(packet_type_raw: object) -> str:
        token = str(packet_type_raw or "").strip().lower() or "unknown"
        return token

    @staticmethod
    def _robot_mode_transition_family(mode: str) -> str:
        normalized = str(mode or "").strip().lower() or "unknown"
        if normalized in {"test", "model_test"}:
            return "test"
        return normalized

    def _is_direct_test_walk_transition(self, *, mode_prev: str, mode_now: str) -> bool:
        prev_family = self._robot_mode_transition_family(mode_prev)
        now_family = self._robot_mode_transition_family(mode_now)
        return {prev_family, now_family} == {"test", "walk"}

    def _clear_robot_deferred_split_state(self) -> None:
        self._robot_deferred_split_pending = False
        self._robot_deferred_split_from_mode = None
        self._robot_deferred_split_to_mode = None

    def _robot_resolve_file_label(self, *, packet_type: str, source_mode: str) -> str:
        # Hybrid label policy (packet_type + source_mode):
        # 1) keep packet family as the baseline (`walk`/`cpm`/`measure`),
        # 2) map walk/measure packets to `test` only when runtime mode explicitly
        #    says test/model_test so test and measure stay distinct in filenames,
        # 3) fall back to packet-derived labels if mode text is temporarily stale.
        packet = self._normalize_robot_packet_type(packet_type)
        mode = self._normalize_source_mode(source_mode)
        if packet == "walk":
            if mode in {"test", "model_test"}:
                return "test"
            return "walk"
        if packet == "measure":
            if mode in {"test", "model_test"}:
                return "test"
            return "measure"
        if packet == "test":
            return "test"
        if packet == "cpm":
            return "cpm"
        return packet

    def _update_robot_mode_transition_state(self, *, source_mode: str) -> None:
        if not self._robot_enabled:
            return
        mode_now = self._normalize_source_mode(source_mode)
        mode_prev = self._robot_last_source_mode
        if mode_prev is None:
            self._robot_last_source_mode = mode_now
            return
        if mode_now == mode_prev:
            return

        # Mode-transition split flow:
        # 1) entering idle does not create an idle CSV, but marks a pending split,
        # 2) leaving idle forces the next non-idle packet into a new segment file,
        # 3) direct test<->walk switches defer the split so transition-tail frames
        #    can stay in the previous file until the first fid discontinuity,
        # 4) other direct non-idle switches still force an immediate split.
        if mode_now == "idle":
            self._clear_robot_deferred_split_state()
            self._robot_idle_split_pending = True
        elif (mode_prev == "idle") and (self._robot_idle_split_pending):
            self._clear_robot_deferred_split_state()
            self._robot_force_split_next_segment = True
            self._robot_idle_split_pending = False
        elif self._is_direct_test_walk_transition(mode_prev=mode_prev, mode_now=mode_now):
            # Deferred test<->walk mode handoff:
            # 1) keep writing to the current segment file,
            # 2) preserve runtime source_mode values in rows,
            # 3) split only when the first discontinuity confirms a new burst.
            self._robot_force_split_next_segment = False
            self._robot_idle_split_pending = False
            if self._robot_active_segment_label is not None:
                self._robot_deferred_split_pending = True
                self._robot_deferred_split_from_mode = self._robot_mode_transition_family(mode_prev)
                self._robot_deferred_split_to_mode = self._robot_mode_transition_family(mode_now)
            else:
                self._clear_robot_deferred_split_state()
        else:
            self._clear_robot_deferred_split_state()
            self._robot_force_split_next_segment = True
            self._robot_idle_split_pending = False

        self._robot_last_source_mode = mode_now

    def _robot_is_mode_compatible_with_label(self, *, source_mode: str, file_label: str) -> bool:
        mode = self._normalize_source_mode(source_mode)
        label = str(file_label or "unknown").strip().lower() or "unknown"

        # Session-acceptance guard:
        # 1) `idle` / `unknown` are transitional for motion packets and must not
        #    create or contaminate walk/test/cpm/measure segment files,
        # 2) mode-specific files only accept rows from the matching runtime mode
        #    family (`test` also accepts `model_test`),
        # 3) unknown labels fall back to permissive behavior so non-mode streams
        #    keep existing handling.
        if mode in {"idle", "unknown"}:
            return False
        if label == "test":
            return mode in {"test", "model_test"}
        if label == "walk":
            return mode == "walk"
        if label == "cpm":
            return mode == "cpm"
        if label == "measure":
            return mode == "measure"
        return True

    def _reset_robot_pending_state(self) -> None:
        self._robot_rows.clear()
        self._robot_fid_heap_by_stream.clear()
        self._robot_fid_set_by_stream.clear()
        self._robot_max_fid_by_stream.clear()
        self._robot_last_fid_by_packet.clear()
        self._robot_segment_by_packet.clear()
        self._robot_latest_key_by_packet.clear()
        self._robot_latest_non_cfg_key = None

    def _rotate_robot_label_if_needed(
        self,
        file_label: str,
        *,
        force_new_segment: bool = False,
    ) -> None:
        if not self._robot_enabled:
            return
        label = str(file_label or "unknown").strip().lower() or "unknown"
        if self._robot_active_segment_label is None:
            self._robot_active_segment_label = label
            return
        if (self._robot_active_segment_label == label) and (not bool(force_new_segment)):
            return
        # Label transition/forced-split handling is order-dependent:
        # 1) finalize/compact any currently open robot segment file,
        # 2) clear pending fid-based state so row keys do not span files,
        # 3) switch active label; next fid lazily opens the next segment file.
        self._finalize_active_robot_segment()
        self._reset_robot_pending_state()
        self._robot_active_segment_label = label

    def _ensure_active_robot_segment_writer(self, *, packet_type: str, source_mode: str) -> None:
        if not self._robot_enabled:
            return
        packet = self._normalize_robot_packet_type(packet_type)
        file_mode_label = self._robot_resolve_file_label(
            packet_type=packet,
            source_mode=source_mode,
        )
        force_new_segment = bool(self._robot_force_split_next_segment)
        self._robot_force_split_next_segment = False
        defer_transition_tail = (
            self._robot_deferred_split_pending
            and (self._robot_w is not None)
            and (self._robot_active_segment_label is not None)
            and ({str(self._robot_active_segment_label or ""), str(file_mode_label)} == {"test", "walk"})
        )
        target_file_label = str(self._robot_active_segment_label) if defer_transition_tail else str(file_mode_label)
        if defer_transition_tail:
            force_new_segment = False
        self._rotate_robot_label_if_needed(target_file_label, force_new_segment=force_new_segment)
        if self._robot_w is not None:
            return
        # Packet-driven segmentation opens files only on telemetry frames. During
        # idle windows no walk/cpm/measure frame arrives, so no idle file is created.
        seq = int(self._robot_file_seq_global) + 1
        self._robot_file_seq_global = int(seq)
        out_path = self._robot_csv_path_for_segment(mode=target_file_label, seq=seq)
        if out_path is None:
            return
        self._robot_active_segment_label = target_file_label
        self._robot_active_session_mode = target_file_label
        self._robot_active_file_mode_label = target_file_label
        self._robot_active_file_seq = int(seq)
        self._robot_active_csv_path = Path(out_path)
        self._robot_rows_written_segment_n = 0
        self._robot_compacted_drop_n = 0
        try:
            self._robot_f = open(out_path, "w", newline="", encoding="utf-8")
            self._robot_w = csv.writer(self._robot_f)
            self._robot_w.writerow(self._robot_header)
            self._log(f"Recording: AKR -> {out_path}")
        except Exception as e:
            self._robot_f = None
            self._robot_w = None
            self._robot_active_csv_path = None
            self._log(f"Recording: failed to open AKR segment for {self.addr}: {e}")

    def _finalize_active_robot_segment(self) -> None:
        path = self._robot_active_csv_path
        if self._robot_w is None or self._robot_f is None or path is None:
            self._robot_f = None
            self._robot_w = None
            self._robot_active_csv_path = None
            self._robot_active_file_mode_label = None
            self._robot_active_file_seq = 0
            self._robot_active_session_mode = None
            self._robot_rows_written_segment_n = 0
            return
        self._flush_robot(final=True)
        try:
            self._robot_f.flush()
        except Exception:
            pass
        try:
            self._robot_f.close()
        except Exception:
            pass
        self._robot_f = None
        self._robot_w = None
        self._robot_active_csv_path = None
        compact_info = self._compact_robot_csv_columns(csv_path=Path(path))
        dropped_cols = int(compact_info.get("dropped_empty_columns", 0))
        rows_out = int(compact_info.get("rows_written", self._robot_rows_written_segment_n))
        header_out = list(compact_info.get("header", self._robot_header))
        if rows_out > 0:
            self._robot_paths_written.append(Path(path))
            self._robot_segment_metadata.append(
                {
                    "mode": str(self._robot_active_segment_label or "unknown"),
                    "file_mode_label": str(
                        self._robot_active_file_mode_label
                        or str(self._robot_active_segment_label or "unknown")
                    ),
                    "segment_index": int(self._robot_active_file_seq),
                    "csv_path": str(path),
                    "rows_written": int(rows_out),
                    "header": list(header_out),
                    "selected_fields": [c for c in header_out if c not in _ROBOT_KEY_COLUMNS],
                    "dropped_empty_columns": int(dropped_cols),
                }
            )
        else:
            try:
                if Path(path).exists():
                    Path(path).unlink()
            except Exception:
                pass
        self._robot_compacted_drop_n_total += int(dropped_cols)
        self._robot_compacted_drop_n = 0
        self._robot_rows_written_segment_n = 0
        self._robot_active_file_mode_label = None
        self._robot_active_file_seq = 0
        self._robot_active_session_mode = None

    def _row_emg(self, t_ms: int) -> list[Any]:
        row = self._emg_rows.get(int(t_ms))
        if row is None:
            row = ["" for _ in range(len(self._emg_header))]
            row[0] = int(t_ms)
            self._emg_rows[int(t_ms)] = row
            if t_ms not in self._emg_heap_set:
                heapq.heappush(self._emg_heap, int(t_ms))
                self._emg_heap_set.add(int(t_ms))
        return row

    def _row_imu(self, t_ms: int) -> list[Any]:
        row = self._imu_rows.get(int(t_ms))
        if row is None:
            row = ["" for _ in range(len(self._imu_header))]
            row[0] = int(t_ms)
            self._imu_rows[int(t_ms)] = row
            if t_ms not in self._imu_heap_set:
                heapq.heappush(self._imu_heap, int(t_ms))
                self._imu_heap_set.add(int(t_ms))
        return row

    @staticmethod
    def _robot_ts_key(ts_s: float) -> int:
        # Use microsecond quantization to map parallel per-frame buffers back together.
        return int(round(float(ts_s) * 1_000_000.0))

    def _row_robot(
        self,
        *,
        packet_type: str,
        source_mode: str,
        segment_id: int,
        frame_fid: int,
        t_ms: int | None,
    ) -> list[Any]:
        packet = str(packet_type or "robot").strip().lower() or "robot"
        mode = str(source_mode or "unknown").strip().lower() or "unknown"
        seg = int(segment_id)
        fid = int(frame_fid)
        key = (packet, seg, fid)
        row = self._robot_rows.get(key)
        if row is None:
            row = ["" for _ in range(len(self._robot_header))]
            if (t_ms is not None) and (t_ms >= 0):
                row[0] = int(t_ms)
            if self._robot_segment_i is not None:
                row[self._robot_segment_i] = seg
            if self._robot_packet_i is not None:
                row[self._robot_packet_i] = packet
            if self._robot_source_mode_i is not None:
                row[self._robot_source_mode_i] = mode
            if self._robot_frame_fid_i is not None:
                row[self._robot_frame_fid_i] = fid
            if packet != "cfg":
                self._apply_robot_cfg_latest_to_row(row)
            self._robot_rows[key] = row
            stream_key = (packet, seg)
            heap = self._robot_fid_heap_by_stream.setdefault(stream_key, [])
            seen = self._robot_fid_set_by_stream.setdefault(stream_key, set())
            if fid not in seen:
                heapq.heappush(heap, fid)
                seen.add(fid)
            cur_max = self._robot_max_fid_by_stream.get(stream_key, -10**18)
            self._robot_max_fid_by_stream[stream_key] = max(int(cur_max), fid)
        elif (t_ms is not None) and (t_ms >= 0) and self._is_empty(row[0]):
            row[0] = int(t_ms)
        if self._robot_source_mode_i is not None and self._is_empty(row[self._robot_source_mode_i]):
            row[self._robot_source_mode_i] = mode
        return row

    @staticmethod
    def _is_empty(v: Any) -> bool:
        return v is None or v == ""

    @staticmethod
    def _collide_tag_for_imu_signal(sig: str) -> str:
        s = str(sig).lower()
        if s.startswith("acc") or s.startswith("raw_acc") or s.startswith("lin_acc"):
            return "ACC"
        if s.startswith("gyr") or s.startswith("raw_gyr"):
            return "GYR"
        if s.startswith("mag") or s.startswith("uncal_mag"):
            return "MAG"
        if s.startswith("quat"):
            return "QUAT"
        return "IMU"

    def _mark_collide(self, row: list[Any], *, state_i: int | None, tag: str, is_emg: bool) -> None:
        if state_i is None:
            return
        # Collision flag: multiple samples fell into same rounded timestamp bucket.
        # We intentionally keep the last value (aggregation='last').
        tag = str(tag).strip().upper() or ("EMG" if is_emg else "IMU")
        cur = str(row[state_i] or "").strip()
        if not cur:
            row[state_i] = f"COLLIDE:{tag}"
        else:
            # Merge tags: COLLIDE:ACC,GYR
            if cur.startswith("COLLIDE:"):
                existing = [t.strip().upper() for t in cur.split(":", 1)[1].split(",") if t.strip()]
            elif cur == "COLLIDE":
                existing = []
            else:
                # Unknown legacy marker, keep it but append collide info.
                existing = []
            if tag not in existing:
                existing.append(tag)
            row[state_i] = "COLLIDE:" + ",".join(existing) if existing else "COLLIDE"
        if is_emg:
            self._emg_collide_n += 1
        else:
            self._imu_collide_n += 1

    def _append_robot_note(self, row: list[Any], note: str) -> None:
        if self._robot_note_i is None:
            return
        token = str(note or "").strip()
        if not token:
            return
        cur = str(row[self._robot_note_i] or "").strip()
        if not cur:
            row[self._robot_note_i] = token
            return
        parts = [p.strip() for p in cur.split(";") if p.strip()]
        if token not in parts:
            parts.append(token)
        row[self._robot_note_i] = ";".join(parts)

    def _mark_robot_collide(self, row: list[Any], *, note_i: int | None, tag: str) -> None:
        """Collision marker for Robot CSV (does NOT affect IMU/EMG counters)."""
        if note_i is None:
            return
        collide_tag = str(tag).strip().upper() or "ROBOT"
        cur = str(row[note_i] or "").strip()
        parts = [p.strip() for p in cur.split(";") if p.strip()]
        collide_tokens: list[str] = []
        others: list[str] = []
        for token in parts:
            if token.startswith("COLLIDE:"):
                collide_tokens.extend([t.strip().upper() for t in token.split(":", 1)[1].split(",") if t.strip()])
            elif token == "COLLIDE":
                continue
            else:
                others.append(token)
        if collide_tag not in collide_tokens:
            collide_tokens.append(collide_tag)
        merged = "COLLIDE:" + ",".join(collide_tokens) if collide_tokens else "COLLIDE"
        out = others + [merged]
        row[note_i] = ";".join(out)
        self._robot_collide_n += 1

    def _flush_robot_stream(self, stream_key: tuple[str, int], *, final: bool = False) -> None:
        if self._robot_w is None:
            return
        heap = self._robot_fid_heap_by_stream.get(stream_key)
        if not heap:
            return
        max_fid = int(self._robot_max_fid_by_stream.get(stream_key, -10**18))
        thr = max_fid if final else (max_fid - int(self._robot_flush_lag_fids))
        seen = self._robot_fid_set_by_stream.get(stream_key, set())
        while heap and int(heap[0]) <= int(thr):
            fid = int(heapq.heappop(heap))
            if fid in seen:
                seen.discard(fid)
            row = self._robot_rows.pop((stream_key[0], stream_key[1], fid), None)
            if row is not None:
                self._robot_w.writerow(row)
                self._robot_rows_written_n += 1
                self._robot_rows_written_segment_n += 1
        if not heap:
            self._robot_fid_heap_by_stream.pop(stream_key, None)
            self._robot_fid_set_by_stream.pop(stream_key, None)
            self._robot_max_fid_by_stream.pop(stream_key, None)

    def _ensure_robot_frame(
        self,
        *,
        packet_type: str,
        source_mode: str,
        frame_fid: int,
        t_ms: int | None,
    ) -> tuple[str, int, int] | None:
        packet = self._normalize_robot_packet_type(packet_type)
        segment_label = self._robot_resolve_file_label(
            packet_type=packet,
            source_mode=source_mode,
        )
        # Segment acceptance flow is intentionally order-sensitive:
        # 1) resolve the target file label from packet + runtime mode,
        # 2) reject transitional/mismatched rows before any rotate/open side effects,
        # 3) only then open/split and materialize frame+gap rows.
        if not self._robot_is_mode_compatible_with_label(source_mode=source_mode, file_label=segment_label):
            return None
        self._ensure_active_robot_segment_writer(
            packet_type=packet,
            source_mode=source_mode,
        )
        if self._robot_w is None:
            return None
        fid = int(frame_fid)
        segment = int(self._robot_active_file_seq)
        prev_fid = self._robot_last_fid_by_packet.get(packet)
        discontinuity_note = ""
        force_split_same_packet = False
        deferred_transition_boundary_split = False
        deferred_transition_active = (
            self._robot_deferred_split_pending
            and ({str(self._robot_active_segment_label or ""), str(segment_label)} == {"test", "walk"})
        )
        if prev_fid is not None:
            # Segment and gap policy:
            # 1) contiguous fid continues in the same segment,
            # 2) small forward gaps are explicitly backfilled with placeholder rows,
            # 3) large jumps/resets mark discontinuity and start a new output segment file.
            if fid < prev_fid:
                self._flush_robot_stream((packet, segment), final=True)
                self._robot_discontinuity_n += 1
                discontinuity_note = f"DISCONT:RESET:{prev_fid}->{fid}"
                force_split_same_packet = True
                deferred_transition_boundary_split = bool(deferred_transition_active)
            elif fid > (prev_fid + 1):
                gap = int(fid - prev_fid - 1)
                if deferred_transition_active:
                    self._flush_robot_stream((packet, segment), final=True)
                    self._robot_discontinuity_n += 1
                    discontinuity_note = f"DISCONT:JUMP:{prev_fid}->{fid}"
                    force_split_same_packet = True
                    deferred_transition_boundary_split = True
                else:
                    fill_n = min(gap, int(self._robot_missing_fid_fill_max))
                    for missing_fid in range(prev_fid + 1, prev_fid + 1 + fill_n):
                        gap_row = self._row_robot(
                            packet_type=packet,
                            source_mode=source_mode,
                            segment_id=segment,
                            frame_fid=missing_fid,
                            t_ms=None,
                        )
                        self._append_robot_note(gap_row, "GAP:FID_MISSING")
                    if gap > fill_n:
                        self._flush_robot_stream((packet, segment), final=True)
                        self._robot_discontinuity_n += 1
                        discontinuity_note = f"DISCONT:JUMP:{prev_fid}->{fid}"
                        force_split_same_packet = True
        if force_split_same_packet:
            # Discontinuity split flow:
            # 1) default path keeps current strict packet-discontinuity segmentation,
            # 2) deferred test<->walk path consumes the pending split exactly here so
            #    the tail remains in the previous file and the resumed burst starts
            #    the new file without synthetic gap filler rows at the boundary.
            if deferred_transition_boundary_split:
                self._clear_robot_deferred_split_state()
            self._robot_force_split_next_segment = False
            self._rotate_robot_label_if_needed(
                segment_label,
                force_new_segment=True,
            )
            self._ensure_active_robot_segment_writer(
                packet_type=packet,
                source_mode=source_mode,
            )
            if self._robot_w is None:
                return None
            segment = int(self._robot_active_file_seq)
        self._robot_segment_by_packet[packet] = int(segment)
        self._robot_last_fid_by_packet[packet] = int(fid)
        row = self._row_robot(
            packet_type=packet,
            source_mode=source_mode,
            segment_id=segment,
            frame_fid=fid,
            t_ms=t_ms,
        )
        if discontinuity_note:
            self._append_robot_note(row, discontinuity_note)
        key = (packet, segment, fid)
        self._robot_latest_key_by_packet[packet] = key
        if packet != "cfg":
            self._robot_latest_non_cfg_key = key
        return key

    def _flush_emg(self, *, final: bool = False) -> None:
        if self._emg_w is None:
            return
        lag_ms = 50
        thr = self._emg_max_ms if final else (self._emg_max_ms - lag_ms)
        while self._emg_heap and int(self._emg_heap[0]) <= int(thr):
            t = int(heapq.heappop(self._emg_heap))
            self._emg_heap_set.discard(t)
            row = self._emg_rows.pop(t, None)
            if row is not None:
                self._emg_w.writerow(row)
                self._emg_rows_written_n += 1

    def _flush_imu(self, *, final: bool = False) -> None:
        if self._imu_w is None:
            return
        lag_ms = 200
        thr = self._imu_max_ms if final else (self._imu_max_ms - lag_ms)
        while self._imu_heap and int(self._imu_heap[0]) <= int(thr):
            t = int(heapq.heappop(self._imu_heap))
            self._imu_heap_set.discard(t)
            row = self._imu_rows.pop(t, None)
            if row is not None:
                self._imu_w.writerow(row)
                self._imu_rows_written_n += 1

    def _flush_robot(self, *, final: bool = False) -> None:
        if self._robot_w is None:
            return
        for stream_key in list(self._robot_fid_heap_by_stream.keys()):
            self._flush_robot_stream(stream_key, final=bool(final))

    def _set_emg(self, field: str, t_ms: int, value: Any) -> None:
        if self._emg_w is None:
            return
        idx = self._emg_idx.get(str(field))
        if idx is None:
            return
        row = self._row_emg(int(t_ms))
        # Collision: we already wrote this cell for this t_ms and now we overwrite it (last wins).
        if (not self._is_empty(row[idx])) and (not self._is_empty(value)):
            self._mark_collide(row, state_i=self._emg_state_i, tag="EMG", is_emg=True)
        row[idx] = value

    def _set_imu_vec3(self, sig: str, t_ms: int, vals: list[float]) -> None:
        if self._imu_w is None:
            return
        tag = self._collide_tag_for_imu_signal(sig)
        for comp, v in zip(("x", "y", "z"), (vals + [None, None, None])[:3]):
            key = f"{sig}_{comp}"
            idx = self._imu_idx.get(key)
            if idx is None:
                continue
            row = self._row_imu(int(t_ms))
            if (not self._is_empty(row[idx])) and (not self._is_empty(v)):
                self._mark_collide(row, state_i=self._imu_state_i, tag=tag, is_emg=False)
            row[idx] = v

    def _set_imu_vec4(self, sig: str, t_ms: int, vals: list[float]) -> None:
        if self._imu_w is None:
            return
        tag = self._collide_tag_for_imu_signal(sig)
        for comp, v in zip(("w", "x", "y", "z"), (vals + [None, None, None, None])[:4]):
            key = f"{sig}_{comp}"
            idx = self._imu_idx.get(key)
            if idx is None:
                continue
            row = self._row_imu(int(t_ms))
            if (not self._is_empty(row[idx])) and (not self._is_empty(v)):
                self._mark_collide(row, state_i=self._imu_state_i, tag=tag, is_emg=False)
            row[idx] = v

    def _set_imu_scalar(self, field: str, t_ms: int, value: Any) -> None:
        """Set a scalar IMU field (exact column name, no _x/_y/_z expansion)."""
        if self._imu_w is None:
            return
        idx = self._imu_idx.get(str(field))
        if idx is None:
            return
        row = self._row_imu(int(t_ms))
        if (not self._is_empty(row[idx])) and (not self._is_empty(value)):
            self._mark_collide(row, state_i=self._imu_state_i, tag="IMU", is_emg=False)
        row[idx] = value

    def _set_robot_scalar(
        self,
        field: str,
        *,
        row_key: tuple[str, int, int],
        source_mode: str,
        t_ms: int | None,
        value: Any,
        collide_tag: str,
    ) -> None:
        if self._robot_w is None:
            return
        key = str(field)
        # Canonicalize legacy/variant names to the active header key.
        key = _ROBOT_MEASURE_LEGACY_TO_CANON.get(key, key)
        idx = self._robot_idx.get(key)
        if idx is None:
            # Extra fallback: if a caller passed pre-canonical key.
            alt = _ROBOT_MEASURE_LEGACY_TO_CANON.get(str(field))
            if alt is not None:
                idx = self._robot_idx.get(str(alt))
        if idx is None:
            return
        row = self._row_robot(
            packet_type=str(row_key[0]),
            source_mode=source_mode,
            segment_id=int(row_key[1]),
            frame_fid=int(row_key[2]),
            t_ms=t_ms,
        )
        if (not self._is_empty(row[idx])) and (not self._is_empty(value)):
            self._mark_robot_collide(row, note_i=self._robot_note_i, tag=str(collide_tag))
        row[idx] = value

    def _set_robot_vec3(
        self,
        sig: str,
        *,
        row_key: tuple[str, int, int],
        source_mode: str,
        t_ms: int | None,
        vals: list[float],
        collide_tag: str,
    ) -> None:
        if self._robot_w is None:
            return
        tag = str(collide_tag).strip().upper() or str(sig).strip().upper() or "ROBOT"
        for comp, v in zip(("x", "y", "z"), (vals + [None, None, None])[:3]):
            key = f"{sig}_{comp}"
            idx = self._robot_idx.get(key)
            if idx is None:
                continue
            row = self._row_robot(
                packet_type=str(row_key[0]),
                source_mode=source_mode,
                segment_id=int(row_key[1]),
                frame_fid=int(row_key[2]),
                t_ms=t_ms,
            )
            if (not self._is_empty(row[idx])) and (not self._is_empty(v)):
                self._mark_robot_collide(row, note_i=self._robot_note_i, tag=tag)
            row[idx] = v

    @staticmethod
    def _robot_id_csv_value(raw_robot_id: object) -> str:
        token = str(raw_robot_id or "").strip()
        if not token:
            return "<empty>"
        return token

    def _resolve_robot_row_key(
        self,
        *,
        packet_type: str,
        ts_s: float | None,
        ts_map: dict[tuple[str, int], tuple[str, int, int]],
    ) -> tuple[str, int, int] | None:
        packet = str(packet_type or "robot").strip().lower() or "robot"
        if ts_s is not None:
            k = (packet, self._robot_ts_key(float(ts_s)))
            mapped = ts_map.get(k)
            if mapped is not None:
                return mapped
        return self._robot_latest_key_by_packet.get(packet)

    def _resolve_latest_robot_non_cfg_row_key(self) -> tuple[str, int, int] | None:
        if self._robot_latest_non_cfg_key is not None:
            return self._robot_latest_non_cfg_key
        for packet in ("walk", "cpm", "measure"):
            got = self._robot_latest_key_by_packet.get(packet)
            if got is not None:
                return got
        return None

    def _update_robot_cfg_latest(self, field: str, value: Any) -> None:
        key = str(field)
        if key not in self._robot_cfg_fields_selected:
            return
        if self._is_empty(value):
            return
        self._robot_cfg_latest[key] = value

    def _apply_robot_cfg_latest_to_row(self, row: list[Any]) -> None:
        # Propagate selected cfg_* values as latest-known constants:
        # 1) only for cfg fields the user selected,
        # 2) only after each field has been observed at least once,
        # 3) never overwrite an already-populated cell in the same row.
        # This keeps "blank until first cfg observed" and avoids synthetic collisions.
        for field, value in self._robot_cfg_latest.items():
            idx = self._robot_idx.get(str(field))
            if idx is None:
                continue
            if self._is_empty(row[idx]):
                row[idx] = value

    def _compact_robot_csv_columns(self, *, csv_path: Path | None = None) -> dict[str, Any]:
        out_info: dict[str, Any] = {
            "rows_written": 0,
            "dropped_empty_columns": 0,
            "header": list(self._robot_header),
        }
        path = Path(csv_path) if csv_path is not None else (Path(self.paths.robot_csv) if self.paths.robot_csv is not None else None)
        if path is None:
            return out_info
        csv_path = Path(path)
        if not csv_path.exists():
            return out_info
        try:
            with csv_path.open("r", newline="", encoding="utf-8") as f:
                rows = list(csv.reader(f))
        except Exception as e:
            self._log(f"Recording: robot CSV compact read failed for {self.addr}: {e}")
            return out_info
        if not rows:
            return out_info
        header = list(rows[0])
        data_rows = rows[1:]

        # Deduplicate by logical row key before column pruning.
        # A row can be emitted twice when:
        # 1) fid row arrives first and gets flushed (fid-only row),
        # 2) correlated scalar/vector buffers arrive later and re-materialize the same key.
        # We merge duplicates by keeping first non-empty value per column and unioning notes.
        packet_i = header.index("packet_type") if "packet_type" in header else -1
        seg_i = header.index("segment_id") if "segment_id" in header else -1
        fid_i = header.index("frame_fid") if "frame_fid" in header else -1
        note_i = header.index("note") if "note" in header else -1
        if packet_i >= 0 and seg_i >= 0 and fid_i >= 0:
            merged_by_key: dict[tuple[str, str, str], list[str]] = {}
            order: list[tuple[str, str, str]] = []
            for src in data_rows:
                row = [src[i] if i < len(src) else "" for i in range(len(header))]
                key = (
                    str(row[packet_i]).strip(),
                    str(row[seg_i]).strip(),
                    str(row[fid_i]).strip(),
                )
                cur = merged_by_key.get(key)
                if cur is None:
                    merged_by_key[key] = list(row)
                    order.append(key)
                    continue
                for i, value in enumerate(row):
                    if i == note_i:
                        continue
                    if (str(cur[i]).strip() == "") and (str(value).strip() != ""):
                        cur[i] = value
                if note_i >= 0:
                    note_parts = [p.strip() for p in str(cur[note_i]).split(";") if p.strip()]
                    incoming_parts = [p.strip() for p in str(row[note_i]).split(";") if p.strip()]
                    for p in incoming_parts:
                        if p not in note_parts:
                            note_parts.append(p)
                    cur[note_i] = ";".join(note_parts)
            data_rows = [merged_by_key[k] for k in order]

        keep_idx: list[int] = []
        dropped_idx: list[int] = []
        for i, col in enumerate(header):
            if str(col) in _ROBOT_KEY_COLUMNS:
                keep_idx.append(i)
                continue
            has_data = any((i < len(r)) and (str(r[i]).strip() != "") for r in data_rows)
            if has_data:
                keep_idx.append(i)
            else:
                dropped_idx.append(i)
        if not dropped_idx:
            # No column-level compaction happened, but dedup may still have changed row count.
            if len(data_rows) != len(rows) - 1:
                out_rows = [header] + data_rows
                tmp_path = csv_path.with_name(csv_path.name + ".tmp")
                try:
                    with tmp_path.open("w", newline="", encoding="utf-8") as f:
                        w = csv.writer(f)
                        for row in out_rows:
                            w.writerow(row)
                    tmp_path.replace(csv_path)
                except Exception as e:
                    try:
                        if tmp_path.exists():
                            tmp_path.unlink()
                    except Exception:
                        pass
                    self._log(f"Recording: robot CSV dedupe write failed for {self.addr}: {e}")
            out_info["rows_written"] = int(len(data_rows))
            out_info["header"] = list(header)
            return out_info
        compact_rows: list[list[str]] = []
        compact_rows.append([header[i] if i < len(header) else "" for i in keep_idx])
        for row in data_rows:
            compact_rows.append([row[i] if i < len(row) else "" for i in keep_idx])
        tmp_path = csv_path.with_name(csv_path.name + ".tmp")
        try:
            with tmp_path.open("w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                for row in compact_rows:
                    w.writerow(row)
            tmp_path.replace(csv_path)
        except Exception as e:
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except Exception:
                pass
            self._log(f"Recording: AKR CSV compact write failed for {self.addr}: {e}")
            return out_info
        dropped_n = int(len(dropped_idx))
        out_info["rows_written"] = int(len(compact_rows) - 1)
        out_info["dropped_empty_columns"] = int(dropped_n)
        out_info["header"] = list(compact_rows[0]) if compact_rows else list(header)
        self._log(
            f"Recording note ({self.addr}): AKR compacted_empty_columns={dropped_n}"
        )
        return out_info

    def capture(self, dev: object) -> None:
        """Capture new samples from this device into CSV."""
        origin = float(self.origin_s)
        source_mode = self._normalize_source_mode(getattr(getattr(dev, "params", None), "mode", None))
        self._update_robot_mode_transition_state(source_mode=source_mode)

        capture_emg_imu_stream(self, dev=dev, origin=origin)

        capture_akr_stream(self, dev=dev, origin=origin, source_mode=source_mode)

        # Flush periodically to reduce loss on crash (best-effort).
        if self._emg_f is not None:
            try:
                self._emg_f.flush()
            except Exception:
                pass
        if self._imu_f is not None:
            try:
                self._imu_f.flush()
            except Exception:
                pass
        if self._robot_f is not None:
            try:
                self._robot_f.flush()
            except Exception:
                pass
        self._flush_emg()
        self._flush_imu()
        self._flush_robot()


class EmgsDeviceRecorder(DeviceWideRecorder):
    """Recorder specialized for sensor-only streams (EMG/IMU, no robot telemetry)."""

    def __init__(
        self,
        *,
        addr: str,
        paths: RecordingPaths,
        origin_s: float,
        emg_fields: list[str],
        imu_fields: list[str],
        robot_fields: list[str] | None = None,
        on_log: Optional[Callable[[str], None]] = None,
    ) -> None:
        _ = robot_fields
        super().__init__(
            addr=addr,
            paths=paths,
            origin_s=origin_s,
            emg_fields=emg_fields,
            imu_fields=imu_fields,
            robot_fields=[],
            on_log=on_log,
        )

    def capture(self, dev: object) -> None:
        origin = float(self.origin_s)
        capture_emg_imu_stream(self, dev=dev, origin=origin)

        if self._emg_f is not None:
            try:
                self._emg_f.flush()
            except Exception:
                pass
        if self._imu_f is not None:
            try:
                self._imu_f.flush()
            except Exception:
                pass
        self._flush_emg()
        self._flush_imu()


class AkrDeviceRecorder(DeviceWideRecorder):
    """Recorder specialized for robot devices (EMG/IMU + robot telemetry)."""


def create_session_device_recorder(
    *,
    session_kind: str,
    addr: str,
    paths: RecordingPaths,
    origin_s: float,
    emg_fields: list[str],
    imu_fields: list[str],
    robot_fields: list[str] | None = None,
    on_log: Optional[Callable[[str], None]] = None,
) -> DeviceWideRecorder:
    kind = str(session_kind or "EMGS").strip().upper()
    use_akr_profile = kind == "AKR"
    recorder_cls: type[DeviceWideRecorder] = AkrDeviceRecorder if use_akr_profile else EmgsDeviceRecorder
    return recorder_cls(
        addr=addr,
        paths=paths,
        origin_s=origin_s,
        emg_fields=emg_fields,
        imu_fields=imu_fields,
        robot_fields=(list(robot_fields or []) if use_akr_profile else []),
        on_log=on_log,
    )


class RecordingSession:
    """A multi-device recording session producing per-device files."""

    def __init__(
        self,
        *,
        session_paths: RecordingSessionPaths,
        recorders: dict[str, DeviceWideRecorder],
        on_log: Optional[Callable[[str], None]] = None,
    ) -> None:
        self.session_paths = session_paths
        self.recorders = dict(recorders)
        self._on_log = on_log
        if self._on_log:
            self._on_log(f"Recording: folder -> {self.session_paths.root_dir}")

    def close(self) -> None:
        for r in list(self.recorders.values()):
            try:
                r.close()
            except Exception:
                pass
        self.recorders.clear()

    def capture_device(self, *, addr: str, dev: object) -> None:
        r = self.recorders.get(str(addr))
        if r is None:
            return
        r.capture(dev)

