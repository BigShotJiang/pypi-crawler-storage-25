from __future__ import annotations

import collections
import math
import struct
import time
from dataclasses import dataclass, field
from typing import Deque, Optional

import numpy as np

from ... import config
from ..akr.state import AkrDeviceState
from ..core.state import BaseDeviceState
from .ble import protocol


@dataclass(slots=True)
class DeviceState(BaseDeviceState):
    """Per-device state (UI-friendly) + minimal decode hooks."""

    # Modes (mirrors EMGS_v4 semantics)
    icm_enabled: list[bool] = field(default_factory=lambda: [False] * 9)
    emg_mode: int = 0  # 0 OFF, 1 RMS, 2 RAW

    # Host-side processing toggles (latched at stream start by EmgsManager).
    proc_enable_emg_rms_envelope: bool = False
    proc_emg_rms_window_n: int = config.EMG_RMS_WINDOW_N
    proc_enable_emg_freq_features: bool = False
    proc_emg_spec_window_n: int = config.EMG_SPEC_WINDOW_N
    # Unsupervised fatigue score (heuristic) configuration.
    # NOTE: This requires spectral features (MDF/MNF) to be enabled to produce MDF.
    proc_enable_emg_fatigue: bool = config.EMG_FATIGUE_ENABLE_DEFAULT
    proc_emg_fatigue_baseline_s: float = config.EMG_FATIGUE_BASELINE_S
    proc_emg_fatigue_weight_mdf_pct: float = config.EMG_FATIGUE_WEIGHT_MDF_PCT
    proc_emg_fatigue_weight_rms_pct: float = config.EMG_FATIGUE_WEIGHT_RMS_PCT
    proc_emg_fatigue_conf_recent_n: int = config.EMG_FATIGUE_CONF_RECENT_N
    proc_enable_emg_ecg_filter: bool = config.EMG_ECG_FILTER_ENABLE_DEFAULT
    proc_emg_ecg_filter_method: str = config.EMG_ECG_FILTER_METHOD_DEFAULT
    proc_emg_ecg_hp_cutoff_hz: float = config.EMG_ECG_FILTER_HP_CUTOFF_HZ
    proc_emg_ecg_wavelet_levels: int = config.EMG_ECG_FILTER_WAVELET_LEVELS
    proc_emg_ecg_wavelet_shrink: float = config.EMG_ECG_FILTER_WAVELET_SHRINK

    # Ring buffers: (t_rel_s, samples)
    emg_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN))
    emg_rms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN))
    emg_median_freq_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN))
    emg_mean_freq_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN))
    emg_spectrum_last: Optional[tuple[np.ndarray, np.ndarray]] = None
    emg_spectrum_last_linear: Optional[tuple[np.ndarray, np.ndarray]] = None
    emg_fatigue_score_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN))
    emg_fatigue_conf_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN))
    emg_ecg_clean_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN))
    emg_ecg_artifact_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN))
    emg_packet_rms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN))
    emg_snr_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.EMG_RING_LEN))

    # IMU buffers that are consumed by GUI/recording and currently shared across device kinds.
    raw_acc_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    acc_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    lin_acc_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    raw_gyr_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    gyr_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    uncal_mag_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    mag_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    quat_game_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    quat_geomag_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))

    # Dedicated AKR runtime state.
    akr: AkrDeviceState = field(default_factory=AkrDeviceState)
    last_emg_time_s: Optional[float] = None
    last_imu_time_s: Optional[float] = None
    emg_frames_total: int = 0
    imu_frames_total: int = 0
    last_emg_snr: Optional[int] = None
    last_emg_rms_raw: Optional[int] = None
    last_emg_rms_u16: Optional[int] = None
    # Advanced settings/telemetry (queried via 'S''A' responses)
    power_safe_lvl_percent: Optional[int] = None
    emg_threshold: Optional[int] = None
    storage_threshold_percent: Optional[int] = None
    icm_freq: dict[int, int] = field(default_factory=dict)
    icm_scale: dict[int, int] = field(default_factory=dict)
    icm_bias_acc: Optional[tuple[int, int, int]] = None
    icm_bias_gyr: Optional[tuple[int, int, int]] = None
    icm_bias_mag: Optional[tuple[int, int, int]] = None
    # Clock health (computed from TIME_SYNC/GET_TIMESTAMP replies in manager)
    last_device_ts_ms: Optional[int] = None
    last_host_ts_ms: Optional[int] = None
    clock_delta_ms: Optional[int] = None
    # Gap/jitter diagnostics
    last_emg_packet_id: Optional[int] = None
    last_emg_packet_ts_ms: Optional[int] = None
    last_imu_packet_ts_ms: Optional[int] = None
    emg_missing_samples_est: int = 0
    imu_anomaly_count: int = 0
    _imu_last_packet_id: dict[int, int] = field(default_factory=dict)
    _imu_last_packet_ts_ms: dict[int, int] = field(default_factory=dict)
    _imu_last_sample_t_ms: dict[int, float] = field(default_factory=dict)
    _emg_rms_sq_window: Deque[float] = field(default_factory=collections.deque)
    _emg_rms_sq_sum: float = 0.0
    _fatigue_t0_s: Optional[float] = None
    _fatigue_baseline_mdf: Deque[float] = field(default_factory=collections.deque)
    _fatigue_baseline_rms: Deque[float] = field(default_factory=collections.deque)
    _fatigue_recent_mdf: Deque[float] = field(default_factory=collections.deque)
    _emg_ecg_hp_prev_x: float = 0.0
    _emg_ecg_hp_prev_y: float = 0.0
    _emg_ecg_wavelet_hist: Deque[float] = field(default_factory=collections.deque)

    def reset(self) -> None:
        self.is_connected = False
        self.is_streaming = False
        self.is_charging = False
        self.last_rx_monotonic_s = None
        self.icm_enabled = [False] * 9
        self.emg_mode = 0
        self.emg_buffer.clear()
        self.emg_rms_buffer.clear()
        self.emg_median_freq_buffer.clear()
        self.emg_mean_freq_buffer.clear()
        self.emg_packet_rms_buffer.clear()
        self.emg_snr_buffer.clear()
        self.emg_spectrum_last = None
        self.emg_spectrum_last_linear = None
        self.emg_fatigue_score_buffer.clear()
        self.emg_fatigue_conf_buffer.clear()
        self.emg_ecg_clean_buffer.clear()
        self.emg_ecg_artifact_buffer.clear()
        self.raw_acc_buffer.clear()
        self.acc_buffer.clear()
        self.lin_acc_buffer.clear()
        self.raw_gyr_buffer.clear()
        self.gyr_buffer.clear()
        self.uncal_mag_buffer.clear()
        self.mag_buffer.clear()
        self.quat_game_buffer.clear()
        self.quat_geomag_buffer.clear()
        self.akr.reset()
        self.last_emg_time_s = None
        self.last_imu_time_s = None
        self.emg_frames_total = 0
        self.imu_frames_total = 0
        self.last_emg_snr = None
        self.last_emg_rms_raw = None
        self.last_emg_rms_u16 = None
        self.power_safe_lvl_percent = None
        self.emg_threshold = None
        self.storage_threshold_percent = None
        self.icm_freq.clear()
        self.icm_scale.clear()
        self.icm_bias_acc = None
        self.icm_bias_gyr = None
        self.icm_bias_mag = None
        self.last_device_ts_ms = None
        self.last_host_ts_ms = None
        self.clock_delta_ms = None
        self.last_emg_packet_id = None
        self.last_emg_packet_ts_ms = None
        self.last_imu_packet_ts_ms = None
        self.emg_missing_samples_est = 0
        self.imu_anomaly_count = 0
        self._imu_last_packet_id.clear()
        self._imu_last_packet_ts_ms.clear()
        self._imu_last_sample_t_ms.clear()
        self._emg_rms_sq_window.clear()
        self._emg_rms_sq_sum = 0.0
        self._fatigue_t0_s = None
        self._fatigue_baseline_mdf.clear()
        self._fatigue_baseline_rms.clear()
        self._fatigue_recent_mdf.clear()
        self._emg_ecg_hp_prev_x = 0.0
        self._emg_ecg_hp_prev_y = 0.0
        self._emg_ecg_wavelet_hist.clear()
        self.proc_enable_emg_rms_envelope = False
        self.proc_emg_rms_window_n = int(getattr(config, "EMG_RMS_WINDOW_N", 100))
        self.proc_enable_emg_freq_features = False
        self.proc_emg_spec_window_n = int(getattr(config, "EMG_SPEC_WINDOW_N", 1000))
        self.proc_enable_emg_fatigue = bool(getattr(config, "EMG_FATIGUE_ENABLE_DEFAULT", False))
        self.proc_emg_fatigue_baseline_s = float(getattr(config, "EMG_FATIGUE_BASELINE_S", 10.0))
        self.proc_emg_fatigue_weight_mdf_pct = float(getattr(config, "EMG_FATIGUE_WEIGHT_MDF_PCT", 70.0))
        self.proc_emg_fatigue_weight_rms_pct = float(getattr(config, "EMG_FATIGUE_WEIGHT_RMS_PCT", 30.0))
        self.proc_emg_fatigue_conf_recent_n = int(getattr(config, "EMG_FATIGUE_CONF_RECENT_N", 60))
        self.proc_enable_emg_ecg_filter = bool(getattr(config, "EMG_ECG_FILTER_ENABLE_DEFAULT", False))
        self.proc_emg_ecg_filter_method = str(getattr(config, "EMG_ECG_FILTER_METHOD_DEFAULT", "highpass"))
        self.proc_emg_ecg_hp_cutoff_hz = float(getattr(config, "EMG_ECG_FILTER_HP_CUTOFF_HZ", 25.0))
        self.proc_emg_ecg_wavelet_levels = int(getattr(config, "EMG_ECG_FILTER_WAVELET_LEVELS", 4))
        self.proc_emg_ecg_wavelet_shrink = float(getattr(config, "EMG_ECG_FILTER_WAVELET_SHRINK", 1.0))
        self.params.status = "Disconnected"

    def _push_emg_rms(self, t_s: float, emg: float) -> float:
        _ = t_s
        v2 = float(emg) * float(emg)
        self._emg_rms_sq_window.append(v2)
        self._emg_rms_sq_sum += v2
        n_max = int(getattr(self, "proc_emg_rms_window_n", getattr(config, "EMG_RMS_WINDOW_N", 100)))
        if n_max <= 0:
            n_max = 1
        while len(self._emg_rms_sq_window) > n_max:
            old_v2 = float(self._emg_rms_sq_window.popleft())
            self._emg_rms_sq_sum -= old_v2
        n = len(self._emg_rms_sq_window)
        if n <= 0:
            return 0.0
        return float(math.sqrt(max(0.0, self._emg_rms_sq_sum / float(n))))

    def _compute_emg_spectral_features(
        self, x: np.ndarray, fs_hz: float
    ) -> tuple[float, float, tuple[np.ndarray, np.ndarray] | None, tuple[np.ndarray, np.ndarray] | None]:
        if x.size < 8:
            return 0.0, 0.0, None, None
        x0 = x.astype(float) - float(np.mean(x))
        w = np.hanning(int(x0.size))
        xw = x0 * w
        X = np.fft.rfft(xw)
        P = (X.real * X.real + X.imag * X.imag)
        f = np.fft.rfftfreq(int(xw.size), d=1.0 / float(fs_hz))
        if f.size > 1:
            f = f[1:]
            P = P[1:]
        tot = float(np.sum(P))
        if not math.isfinite(tot) or tot <= 0.0:
            return 0.0, 0.0, None, None
        mean_f = float(np.sum(f * P) / tot)
        c = np.cumsum(P)
        mdf = float(f[int(np.searchsorted(c, 0.5 * c[-1], side="left"))]) if c.size else 0.0
        p_max = float(np.max(P)) if P.size else 0.0
        if not math.isfinite(p_max) or p_max <= 0.0:
            return mdf, mean_f, None, None
        p_rel = P / (p_max + 1e-12)
        p_db = 10.0 * np.log10(p_rel + 1e-12)
        return mdf, mean_f, (f, p_db), (f, p_rel)

    @staticmethod
    def _soft_threshold(x: np.ndarray, thr: float) -> np.ndarray:
        return np.sign(x) * np.maximum(np.abs(x) - float(thr), 0.0)

    def _wavelet_soft_denoise_haar(self, x: np.ndarray, *, levels: int, shrink: float) -> np.ndarray:
        if x.size < 8:
            return x
        n0 = int(x.size)
        n = 1 << int(math.floor(math.log2(max(2, n0))))
        xw = np.asarray(x[-n:], dtype=float).copy()
        coeffs: list[np.ndarray] = []
        cur = xw
        lv = int(max(1, min(8, levels)))
        for _ in range(lv):
            if cur.size < 2:
                break
            a = (cur[0::2] + cur[1::2]) / math.sqrt(2.0)
            d = (cur[0::2] - cur[1::2]) / math.sqrt(2.0)
            coeffs.append(d)
            cur = a
        approx = cur
        if coeffs:
            finest = coeffs[0]
            sigma = float(np.median(np.abs(finest)) / 0.6745) if finest.size else 0.0
            thr = float(max(0.0, shrink) * sigma * math.sqrt(2.0 * math.log(max(2, n))))
            coeffs = [self._soft_threshold(d, thr) for d in coeffs]
        rec = approx
        for d in reversed(coeffs):
            up = np.empty(d.size * 2, dtype=float)
            up[0::2] = (rec + d) / math.sqrt(2.0)
            up[1::2] = (rec - d) / math.sqrt(2.0)
            rec = up
        out = np.asarray(x, dtype=float).copy()
        out[-n:] = rec[-n:]
        return out

    def _apply_emg_ecg_filter_packet(self, packet_mv: list[float]) -> list[float]:
        if not packet_mv:
            return []
        if not bool(getattr(self, "proc_enable_emg_ecg_filter", False)):
            return list(packet_mv)
        method = str(getattr(self, "proc_emg_ecg_filter_method", "highpass")).strip().lower()
        fs = float(getattr(config, "EMG_SAMPLE_RATE_HZ", 1000))
        if method != "wavelet":
            fc = float(max(1.0, min(150.0, float(getattr(self, "proc_emg_ecg_hp_cutoff_hz", 25.0)))))
            dt = 1.0 / max(1.0, fs)
            rc = 1.0 / (2.0 * math.pi * fc)
            alpha = rc / (rc + dt)
            prev_x = float(getattr(self, "_emg_ecg_hp_prev_x", 0.0))
            prev_y = float(getattr(self, "_emg_ecg_hp_prev_y", 0.0))
            out: list[float] = []
            for x in packet_mv:
                y = float(alpha * (prev_y + float(x) - prev_x))
                out.append(y)
                prev_x = float(x)
                prev_y = y
            self._emg_ecg_hp_prev_x = prev_x
            self._emg_ecg_hp_prev_y = prev_y
            return out

        win_n = int(max(128, min(4096, int(getattr(config, "EMG_ECG_FILTER_WAVELET_WIN_N", 512)))))
        hist = self._emg_ecg_wavelet_hist
        for x in packet_mv:
            hist.append(float(x))
        while len(hist) > win_n:
            hist.popleft()
        arr = np.asarray(hist, dtype=float)
        lv = int(max(1, min(8, int(getattr(self, "proc_emg_ecg_wavelet_levels", 4)))))
        shrink = float(max(0.0, min(5.0, float(getattr(self, "proc_emg_ecg_wavelet_shrink", 1.0)))))
        den = self._wavelet_soft_denoise_haar(arr, levels=lv, shrink=shrink)
        k = len(packet_mv)
        if den.size < k:
            return list(packet_mv)
        return [float(v) for v in den[-k:]]

    def _emg_u16_to_mv(self, r_u16: int) -> float:
        r = float(r_u16)
        v = (r / float(config.EMG_ADC_MAX)) * float(config.EMG_ADC_FULL_SCALE_V) - float(config.EMG_ADC_MID_V)
        return float(v / float(config.EMG_GAIN_V_PER_V) * float(config.EMG_OUTPUT_SCALE))

    def _emg_u16_to_v(self, r_u16: int) -> float:
        r = float(r_u16)
        return float((r / float(config.EMG_ADC_MAX)) * float(config.EMG_ADC_FULL_SCALE_V))

    def decode_notification(self, data: bytes) -> None:
        if not data or len(data) < 3:
            return
        if chr(data[0]) != "S":
            return
        pkt_type = chr(data[1])
        if pkt_type == protocol.PacketType.CHARGING:
            self.is_charging = (data[2] == 1)
            return
        if pkt_type == protocol.PacketType.APP_HELPER:
            self._decode_app_helper(data)
            return
        if pkt_type == protocol.PacketType.DATA_EMG:
            self._decode_emg_fw(data)
            return
        if pkt_type == protocol.PacketType.DATA_IMU:
            self._decode_imu_fw(data)
            return

    def _decode_app_helper(self, data: bytes) -> None:
        cmd = chr(data[2])
        try:
            if cmd == "0":
                batt = int(data[3])
                charge = int(data[4])
                self.is_charging = (charge == 1)
                batt_lo = int(3.10 * 50.0)
                batt_hi = int(4.15 * 50.0)
                batt_val = (batt - batt_lo) / (batt_hi - batt_lo) * 100.0
                batt_val = max(0.0, min(100.0, batt_val))
                self.params.battery = f"{batt_val:1.0f} %"
                fw = int(data[5]) << 8 | int(data[6])
                hw = int(data[7]) << 8 | int(data[8])
                self.params.firmware = f"{(fw >> 8) & 0xFF}.{fw & 0xFF}"
                self.params.hardware = f"{(hw >> 8) & 0xFF}.{hw & 0xFF}"
            elif cmd == "3":
                batt = int(data[3])
                charge = int(data[4])
                self.is_charging = (charge == 1)
                batt_lo = int(3.10 * 50.0)
                batt_hi = int(4.15 * 50.0)
                batt_val = (batt - batt_lo) / (batt_hi - batt_lo) * 100.0
                batt_val = max(0.0, min(100.0, batt_val))
                self.params.battery = f"{batt_val:1.0f} %"
                ts_ms = int(struct.unpack_from("<Q", data, 5)[0])
                self.params.timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts_ms / 1000.0))
            elif cmd == "K":
                raw = data[3:15]
                name = bytes(raw).split(b"\x00", 1)[0].decode("ascii", errors="ignore")
                if name:
                    self.params.name = name
            elif cmd == "n":
                mi = struct.unpack_from("<H", data, 3)[0]
                ma = struct.unpack_from("<H", data, 5)[0]
                self.params.conn_interval = f"{mi},{ma}"
            elif cmd == "X":
                idx = int(data[3])
                val = (int(data[4]) == 1)
                if 0 <= idx < len(self.icm_enabled):
                    self.icm_enabled[idx] = val
                    self._update_mode_string()
            elif cmd == "x":
                self.emg_mode = int(data[3])
                self._update_mode_string()
            elif cmd == "s":
                self.power_safe_lvl_percent = int(data[3])
            elif cmd == "T":
                self.emg_threshold = int(struct.unpack_from("<H", data, 3)[0])
            elif cmd == "V":
                self.storage_threshold_percent = int(data[3])
            elif cmd == "Z":
                self.icm_freq[int(data[3])] = int(data[4])
            elif cmd == "D":
                self.icm_scale[int(data[3])] = int(data[4])
            elif cmd == "B":
                bias_acc = []
                bias_gyr = []
                bias_mag = []
                for i in range(3):
                    bias_acc.append(int(struct.unpack_from("<i", data, 3 + i * 4)[0]))
                    bias_gyr.append(int(struct.unpack_from("<i", data, 15 + i * 4)[0]))
                    bias_mag.append(int(struct.unpack_from("<i", data, 27 + i * 4)[0]))
                self.icm_bias_acc = tuple(bias_acc)  # type: ignore[assignment]
                self.icm_bias_gyr = tuple(bias_gyr)  # type: ignore[assignment]
                self.icm_bias_mag = tuple(bias_mag)  # type: ignore[assignment]
            elif cmd == "a":
                batt = int(data[3])
                charge = int(data[4])
                self.is_charging = (charge == 1)
                batt_lo = int(3.10 * 50.0)
                batt_hi = int(4.15 * 50.0)
                batt_val = (batt - batt_lo) / (batt_hi - batt_lo) * 100.0
                batt_val = max(0.0, min(100.0, batt_val))
                self.params.battery = f"{batt_val:1.0f} %"
                self.params.dsp = f"{int(data[5])}.{int(data[6])}.{int(data[7])}"
            elif cmd == "G":
                ts_ms = int(struct.unpack_from("<Q", data, 3)[0])
                self.params.timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts_ms / 1000.0))
            elif cmd == "5":
                self.is_streaming = True
            elif cmd == "7":
                self.is_streaming = False
        except Exception:
            return

    def _update_mode_string(self) -> None:
        sensors: list[str] = []
        if self.icm_enabled[0]:
            sensors.append("RACC")
        if self.icm_enabled[1]:
            sensors.append("ACC")
        if self.icm_enabled[2]:
            sensors.append("LIN")
        if self.icm_enabled[3]:
            sensors.append("RGYR")
        if self.icm_enabled[4]:
            sensors.append("GYR")
        if self.icm_enabled[5]:
            sensors.append("UMAG")
        if self.icm_enabled[6]:
            sensors.append("MAG")
        if self.icm_enabled[7]:
            sensors.append("QUAT")
        if self.icm_enabled[8]:
            sensors.append("GEOQ")

        emg = {0: "EMG:OFF", 1: "EMG:RMS", 2: "EMG:RMS+RAW"}.get(int(self.emg_mode), "EMG:?")
        txt = " ".join(sensors) if sensors else "-"
        self.params.mode = f"{txt} • {emg}"

    def _decode_emg_fw(self, data: bytes) -> None:
        if len(data) < 16:
            return
        try:
            payload_len = int(data[2])
            if len(data) < payload_len + 3:
                return
            batt = int(data[3])
            charge_state = int(data[4])
            packet_id = int(struct.unpack_from("<H", data, 5)[0])
            timestamp_ms = int(struct.unpack_from("<Q", data, 7)[0])

            self.is_charging = (charge_state == 1)
            batt_lo = int(3.10 * 50.0)
            batt_hi = int(4.15 * 50.0)
            batt_val = (batt - batt_lo) / (batt_hi - batt_lo) * 100.0
            batt_val = max(0.0, min(100.0, batt_val))
            self.params.battery = f"{batt_val:1.0f} %"

            if self.last_emg_packet_id is not None:
                gap = (packet_id - self.last_emg_packet_id) & 0xFFFF
                if gap > 1:
                    self.emg_missing_samples_est += (gap - 1) * 100

            data_pos = 16
            data_bytes = data[data_pos : 3 + payload_len]
            if len(data_bytes) >= 3:
                rms_u16 = int(struct.unpack_from(">H", data_bytes, 0)[0])
                snr = int(data_bytes[2])
                self.last_emg_snr = snr
                self.last_emg_rms_u16 = rms_u16
                self.emg_snr_buffer.append((float(timestamp_ms) / 1000.0, [float(snr)]))
                rms_v = self._emg_u16_to_v(int(rms_u16))
                self.emg_packet_rms_buffer.append((float(timestamp_ms) / 1000.0, [float(rms_v)]))

            if payload_len == 216 and len(data_bytes) >= 203:
                raw = data_bytes[3:203]
                if len(raw) == 200:
                    readings = struct.unpack_from(">100H", raw, 0)
                    packet_mv: list[float] = [self._emg_u16_to_mv(int(r)) for r in readings]
                    packet_mv_ecg_clean = self._apply_emg_ecg_filter_packet(packet_mv)
                    for i, emg in enumerate(packet_mv):
                        t_s = (float(timestamp_ms) + float(i)) / 1000.0
                        self.emg_buffer.append((t_s, [float(emg)]))
                        if i < len(packet_mv_ecg_clean):
                            emg_clean = float(packet_mv_ecg_clean[i])
                            self.emg_ecg_clean_buffer.append((t_s, [emg_clean]))
                            self.emg_ecg_artifact_buffer.append((t_s, [float(emg) - emg_clean]))
                        else:
                            emg_clean = float(emg)
                        if self.proc_enable_emg_rms_envelope:
                            src = float(emg_clean) if bool(getattr(self, "proc_enable_emg_ecg_filter", False)) else float(emg)
                            rms = self._push_emg_rms(t_s, src)
                            self.emg_rms_buffer.append((t_s, [float(rms)]))

                    # Spectral/fatigue flow is order-dependent:
                    # 1) pull last N cleaned/raw samples, 2) compute MDF/MNF once per packet,
                    # 3) update optional fatigue baseline/trend from the same window.
                    if self.proc_enable_emg_freq_features:
                        n_win = int(getattr(self, "proc_emg_spec_window_n", getattr(config, "EMG_SPEC_WINDOW_N", 1000)))
                        if n_win > 0:
                            vals: list[float] = []
                            src_buf = self.emg_ecg_clean_buffer if bool(getattr(self, "proc_enable_emg_ecg_filter", False)) else self.emg_buffer
                            for _ts, s in reversed(src_buf):
                                if s:
                                    vals.append(float(s[0]))
                                    if len(vals) >= n_win:
                                        break
                            if len(vals) >= max(8, min(n_win, 64)):
                                vals.reverse()
                                x = np.asarray(vals, dtype=float)
                                fs = float(getattr(config, "EMG_SAMPLE_RATE_HZ", 1000))
                                mdf, mnf, spec_db, spec_lin = self._compute_emg_spectral_features(x, fs)
                                t_feat = float(self.emg_buffer[-1][0]) if self.emg_buffer else (float(timestamp_ms) / 1000.0)
                                self.emg_median_freq_buffer.append((t_feat, [float(mdf)]))
                                self.emg_mean_freq_buffer.append((t_feat, [float(mnf)]))
                                self.emg_spectrum_last = spec_db
                                self.emg_spectrum_last_linear = spec_lin
                                if self.proc_enable_emg_fatigue:
                                    baseline_s = float(getattr(self, "proc_emg_fatigue_baseline_s", getattr(config, "EMG_FATIGUE_BASELINE_S", 10.0)))
                                    baseline_s = float(max(0.5, min(600.0, baseline_s)))
                                    recent_n = int(getattr(self, "proc_emg_fatigue_conf_recent_n", getattr(config, "EMG_FATIGUE_CONF_RECENT_N", 60)))
                                    recent_n = int(max(4, min(2000, recent_n)))
                                    w_mdf_pct = float(getattr(self, "proc_emg_fatigue_weight_mdf_pct", getattr(config, "EMG_FATIGUE_WEIGHT_MDF_PCT", 70.0)))
                                    w_rms_pct = float(getattr(self, "proc_emg_fatigue_weight_rms_pct", getattr(config, "EMG_FATIGUE_WEIGHT_RMS_PCT", 30.0)))
                                    w_sum = float(max(1e-9, max(0.0, w_mdf_pct) + max(0.0, w_rms_pct)))
                                    w_mdf = float(max(0.0, w_mdf_pct) / w_sum)
                                    w_rms = float(max(0.0, w_rms_pct) / w_sum)

                                    if self._fatigue_t0_s is None:
                                        self._fatigue_t0_s = float(t_feat)
                                    try:
                                        rms_win = float(math.sqrt(max(0.0, float(np.mean(x * x)))))
                                    except Exception:
                                        rms_win = 0.0
                                    if float(t_feat) - float(self._fatigue_t0_s) <= float(baseline_s):
                                        self._fatigue_baseline_mdf.append(float(mdf))
                                        self._fatigue_baseline_rms.append(float(rms_win))
                                        cap = int(max(50, min(2000, baseline_s * 100.0)))
                                        while len(self._fatigue_baseline_mdf) > cap:
                                            self._fatigue_baseline_mdf.popleft()
                                        while len(self._fatigue_baseline_rms) > cap:
                                            self._fatigue_baseline_rms.popleft()
                                    self._fatigue_recent_mdf.append(float(mdf))
                                    while len(self._fatigue_recent_mdf) > int(recent_n):
                                        self._fatigue_recent_mdf.popleft()
                                    base_mdf = float(np.median(np.asarray(self._fatigue_baseline_mdf, dtype=float))) if self._fatigue_baseline_mdf else 0.0
                                    base_rms = float(np.median(np.asarray(self._fatigue_baseline_rms, dtype=float))) if self._fatigue_baseline_rms else 0.0
                                    if base_mdf > 0.0 and base_rms > 0.0:
                                        mdf_drop = (base_mdf - float(mdf)) / (base_mdf + 1e-9)
                                        rms_rise = (float(rms_win) - base_rms) / (base_rms + 1e-9)
                                        score = float(max(0.0, min(1.0, w_mdf * mdf_drop + w_rms * rms_rise)))
                                    else:
                                        score = 0.0
                                    conf = 0.2
                                    try:
                                        arr = np.asarray(self._fatigue_recent_mdf, dtype=float)
                                        if arr.size >= 4:
                                            down = float(np.mean(np.diff(arr) < 0.0))
                                            conf = float(max(0.0, min(1.0, 0.2 + 0.8 * down)))
                                    except Exception:
                                        conf = 0.2
                                    self.emg_fatigue_score_buffer.append((t_feat, [score]))
                                    self.emg_fatigue_conf_buffer.append((t_feat, [conf]))

            self.last_emg_time_s = time.monotonic()
            self.emg_frames_total += 1
            self.last_emg_packet_id = packet_id
            self.last_emg_packet_ts_ms = timestamp_ms
        except Exception:
            return

    def _decode_imu_fw(self, data: bytes) -> None:
        if len(data) < 15:
            return
        try:
            sensor_type = int(data[5])
            timestamp_ms = int(struct.unpack_from("<Q", data, 6)[0])
            self.last_imu_packet_ts_ms = int(timestamp_ms)
            samplingfreq_hz = int(data[14]) or 100
            dt_ms = 1000.0 / float(samplingfreq_hz)
            raw = data[15:]
            if not raw:
                return

            if sensor_type in (0, 3):
                sample_size = 6
                n = len(raw) // sample_size
                if n <= 0:
                    return
                base_ms = float(timestamp_ms)
                for k in range(n):
                    x, y, z = struct.unpack_from("<3h", raw, k * sample_size)
                    t_s = (base_ms + k * dt_ms) / 1000.0
                    buf = self.raw_acc_buffer if sensor_type == 0 else self.raw_gyr_buffer
                    buf.append((t_s, [float(x), float(y), float(z)]))
                self._imu_last_sample_t_ms[sensor_type] = base_ms + (n - 1) * dt_ms
            elif sensor_type in (7, 8):
                sample_size = 16
                n = len(raw) // sample_size
                if n <= 0:
                    return
                base_ms = float(timestamp_ms)
                for k in range(n):
                    q = struct.unpack_from("<4f", raw, k * sample_size)
                    sample_ms = float(base_ms + k * dt_ms)
                    t_s = sample_ms / 1000.0
                    buf = self.quat_game_buffer if sensor_type == 7 else self.quat_geomag_buffer
                    buf.append((t_s, [float(q[0]), float(q[1]), float(q[2]), float(q[3])]))
                self._imu_last_sample_t_ms[sensor_type] = base_ms + (n - 1) * dt_ms
            else:
                sample_size = 12
                n = len(raw) // sample_size
                if n <= 0:
                    return
                base_ms = float(timestamp_ms)
                for k in range(n):
                    x, y, z = struct.unpack_from("<3f", raw, k * sample_size)
                    t_s = (base_ms + k * dt_ms) / 1000.0
                    if sensor_type in (1, 2):
                        buf = self.acc_buffer if sensor_type == 1 else self.lin_acc_buffer
                        buf.append((t_s, [float(x), float(y), float(z)]))
                    elif sensor_type == 4:
                        self.gyr_buffer.append((t_s, [float(x), float(y), float(z)]))
                    elif sensor_type == 5:
                        self.uncal_mag_buffer.append((t_s, [float(x), float(y), float(z)]))
                    elif sensor_type == 6:
                        self.mag_buffer.append((t_s, [float(x), float(y), float(z)]))
                self._imu_last_sample_t_ms[sensor_type] = base_ms + (n - 1) * dt_ms

            self.last_imu_time_s = time.monotonic()
            self.imu_frames_total += 1
        except Exception:
            return

