"""EMGS BLE protocol constants/helpers.

Adapted from `backup/EMGS_v4/protocol.py` to keep all UUIDs/opcodes in one place.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final, Iterable, Union


# Nordic UART Service characteristic UUIDs
CHAR_UUID: Final = {
    "WRITE": "6e400002-b5a3-f393-e0a9-e50e24dcca9e",   # RX on peripheral (we write here)
    "NOTIFY": "6e400003-b5a3-f393-e0a9-e50e24dcca9e",  # TX from peripheral (we subscribe)
}


@dataclass(frozen=True, slots=True)
class Command:
    opcode: str
    description: str = ""


# Query commands (GET*)
GET_VERSION = Command("A0", "Get firmware/hardware version")
GET_DSP_VERSION = Command("Aa", "Get DSP version")
TIME_SYNC = Command("A3", "Time sync (get current device timestamp + batt/charge)")
GET_TIMESTAMP = Command("AG", "Get current timestamp")
GET_BLE_NAME = Command("AK", "Get BLE advertising name")
GET_CONN_INTERVAL = Command("An", "Get BLE connection interval")
GET_EMG_ENABLE = Command("Ax", "Get EMG enable state")
GET_LOW_BATT_LVL = Command("As", "Get power-safe (low battery) level (%)")
GET_EMG_THRESHOLD = Command("AT", "Get EMG threshold (uint16 LE)")
GET_OUT_OF_STORAGE_THRESHOLD = Command("AV", "Get out-of-storage threshold (%)")

# ICM configuration queries
ICM_GET_FREQ = Command("AZ", "Get ICM sampling frequency for a sensor type")
ICM_GET_SCALE = Command("AD", "Get ICM scale for a sensor type")
ICM_GET_BIAS = Command("AB", "Get ICM bias (acc/gyr/mag)")


def get_icm_enable_commands() -> Iterable[Command]:
    for idx in range(9):
        yield Command("AX", f"Get ICM enable state index {idx}")


# Set / action commands
SET_BLE_NAME = Command("AF", "Set BLE advertising name (12 bytes + NUL padding)")
SET_CONN_INTERVAL = Command("Am", "Set BLE connection interval (min,max) <H <H")
SET_ICM_ENABLE = Command("AW", "Set ICM enable state (index,value)")
ICM_SET_FREQ = Command("AY", "Set ICM sampling frequency (sensor_type,freq)")
ICM_SET_SCALE = Command("AC", "Set ICM scale (sensor_type,scale)")
ICM_SET_BIAS = Command("AR", "Set ICM bias (acc[3],gyr[3],mag[3]) int32 LE")
ICM_SET_AUTO_SAVE_BIAS = Command("Ad", "Set ICM auto-save bias (0/1)")
SET_EMG_ENABLE = Command("Aw", "Set EMG enable state")
SET_LOW_BATT_LVL = Command("At", "Set power-safe (low battery) level (%)")
SET_EMG_THRESHOLD = Command("AS", "Set EMG threshold (uint16 LE)")
SET_OUT_OF_STORAGE_THRESHOLD = Command("AU", "Set out-of-storage threshold (%)")
SET_TIMESTAMP = Command("A9", "Set device timestamp (8 bytes little-endian ms)")
STREAM_START = Command("A5", "Start data stream")
STREAM_STOP = Command("A7", "Stop data stream")
SET_INDICATOR = Command("Ar", "Set indicator (RGB/VIB)")


class IndicatorRGB:
    OFF = 0b00000000
    BLUE = 0b00001001
    YELLOW = 0b00010001
    PURPLE = 0b00011001


class IndicatorVIB:
    OFF = 0b00000000
    ON = 0b00000010


class PacketType:
    CHARGING = "C"
    APP_HELPER = "A"
    DATA_EMG = "E"
    DATA_IMU = "I"
    CONN_INTERVAL = "G"
    ERROR_GENERIC = "X"
    DEBUG_DATA_PIN = "D"
    ERROR_RTC = "F"
    ERROR_READ_MEM = "J"
    DSP_UPGRADE_OK = "M"
    DSP_UPGRADE_FAIL = "N"
    DEBUG_OFFLINE = "q"


_CmdPart = Union[str, int, bytes, bytearray]


def build_payload(*parts: _CmdPart) -> bytes:
    out = bytearray()
    for p in parts:
        if isinstance(p, str):
            out.extend(ord(ch) for ch in p)
        elif isinstance(p, int):
            out.append(p & 0xFF)
        elif isinstance(p, (bytes, bytearray)):
            out.extend(p)
        else:
            raise TypeError(f"Unsupported payload part type: {type(p)!r}")
    return bytes(out)


def require_len(payload: bytes, expected: int) -> bytes:
    if len(payload) != expected:
        raise ValueError(f"Bad payload length: expected {expected}, got {len(payload)}")
    return payload

