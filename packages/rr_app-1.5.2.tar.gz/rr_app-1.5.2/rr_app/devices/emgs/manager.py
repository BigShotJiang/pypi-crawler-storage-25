from __future__ import annotations

from typing import TYPE_CHECKING

from ..core.base import DEVICE_KIND_EMGS
from ..core.registry import get_handler
from ..core.session_manager import BaseSessionManager

if TYPE_CHECKING:
    from ...ble.manager import DeviceSessionManager
    from .state import DeviceState


class EmgsSessionManager(BaseSessionManager):
    kind = DEVICE_KIND_EMGS

    async def connect_one(self, manager: DeviceSessionManager, address: str, dev: DeviceState) -> None:
        handler = get_handler(self.kind)
        await handler.connect(manager, address, dev)
        dev.set_connected(True)
        await handler.post_connect(manager, address, dev)

    async def stream_one(self, manager: DeviceSessionManager, address: str, dev: DeviceState, enable: bool) -> None:
        if not manager.backend.is_connected(address):
            return
        await manager._stream_one_emgs(address, dev, enable=bool(enable))

