from __future__ import annotations

import struct
import time
from typing import TYPE_CHECKING

from ... import config
from ..core.base import DEVICE_KIND_EMGS, DeviceCapabilities, DeviceHandler
from .ble import protocol

if TYPE_CHECKING:
    from .state import DeviceState
    from ...ble.manager import DeviceSessionManager


class EmgsDeviceHandler(DeviceHandler):
    kind = DEVICE_KIND_EMGS
    capabilities = DeviceCapabilities(
        supports_stream_toggle=True,
        supports_settings=True,
        supports_ota=False,
        emits_text_lines=False,
    )

    async def connect(self, manager: DeviceSessionManager, address: str, dev: DeviceState) -> None:
        _ = dev
        await manager.backend.connect(
            address,
            on_notify=manager._on_notify,
            on_disconnect=manager._on_disconnect,
            write_uuid=protocol.CHAR_UUID["WRITE"],
            notify_uuid=protocol.CHAR_UUID["NOTIFY"],
        )

    async def post_connect(self, manager: DeviceSessionManager, address: str, dev: DeviceState) -> None:
        _ = dev
        await manager.set_timestamp_now(address)
        await manager.update_one(address)

    def handle_notify(self, manager: DeviceSessionManager, address: str, dev: DeviceState, data: bytes) -> None:
        is_emgs_frame = bool(data) and len(data) >= 2 and (data[0] == ord("S"))
        pkt_type = chr(data[1]) if is_emgs_frame else "?"
        host_ms = int(time.time() * 1000)

        if manager._debug_cmd and pkt_type == "A" and len(data) >= 3:
            cmd = chr(data[2])
            msg = f"RX [{address}] type=A cmd={cmd} len={len(data)}"
            if manager._debug_cmd_hex:
                hx = " ".join(f"{b:02X}" for b in data[:32])
                msg += f" head={hx}"
            manager._log(msg)

        if pkt_type == "A" and len(data) >= 11:
            try:
                cmd = chr(data[2])
                ts_ms = None
                if cmd == "3" and len(data) >= 13:
                    ts_ms = int(struct.unpack_from("<Q", data, 5)[0])
                elif cmd == "G" and len(data) >= 11:
                    ts_ms = int(struct.unpack_from("<Q", data, 3)[0])
                if ts_ms is not None:
                    dev.last_device_ts_ms = ts_ms
                    send_ms = None
                    if cmd == "3":
                        send_ms = manager._last_time_sync_send_ms.get(address)
                    elif cmd == "G":
                        send_ms = manager._last_get_ts_send_ms.get(address)
                    host_est_ms = int((send_ms + host_ms) / 2) if send_ms is not None else host_ms
                    dev.last_host_ts_ms = host_est_ms
                    dev.clock_delta_ms = ts_ms - host_est_ms
            except Exception:
                pass

        st = manager._rx_stats.setdefault(address, {})
        st["bytes"] = st.get("bytes", 0) + len(data)
        st[pkt_type] = st.get(pkt_type, 0) + 1

        if manager._debug_rx_hex and pkt_type in {"E", "I", "A"}:
            now = time.monotonic()
            last = manager._rx_last_hex_s.get(address, 0.0)
            if (now - last) >= 1.0:
                manager._rx_last_hex_s[address] = now
                hx = " ".join(f"{b:02X}" for b in data[:32])
                manager._log(f"RXHEX [{address}] type={pkt_type} len={len(data)} head={hx}")

        try:
            dev.decode_notification(data)
        except Exception as e:
            hx = " ".join(f"{b:02X}" for b in data[:32])
            manager._log(f"RX decode error [{address}] type={pkt_type} len={len(data)} err={e} head={hx}")

        if manager._debug_rx:
            now = time.monotonic()
            last = manager._rx_last_log_s.get(address, 0.0)
            if (now - last) >= 1.0:
                manager._rx_last_log_s[address] = now
                manager._log(
                    f"RX [{address}] A={st.get('A',0)} E={st.get('E',0)} I={st.get('I',0)} bytes={st.get('bytes',0)}"
                )

        now = time.monotonic()
        last_ui = manager._ui_last_emit_s.get(address, 0.0)
        if (now - last_ui) >= config.UI_DEVICE_UPDATE_MIN_INTERVAL_S:
            manager._ui_last_emit_s[address] = now
            manager._notify_updated(address)

