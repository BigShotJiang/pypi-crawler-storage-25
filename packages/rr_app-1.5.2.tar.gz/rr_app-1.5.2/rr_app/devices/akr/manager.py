from __future__ import annotations

import asyncio
import sys
from typing import TYPE_CHECKING

from ... import config
from .ble import ota_transfer, protocol as akr_protocol
from ..core.base import DEVICE_KIND_AKR
from ..core.registry import get_handler
from ..core.session_manager import BaseSessionManager
from .ota_session import AkrOtaSessionStartError, start_ota_session

if TYPE_CHECKING:
    from ...ble.manager import DeviceSessionManager
    from ..emgs.state import DeviceState


class AkrSessionManager(BaseSessionManager):
    kind = DEVICE_KIND_AKR

    async def connect_one(self, manager: DeviceSessionManager, address: str, dev: DeviceState) -> None:
        handler = get_handler(self.kind)
        await handler.connect(manager, address, dev)
        dev.set_connected(True)
        await handler.post_connect(manager, address, dev)
        # Linux/Windows reconnects can receive a delayed stale disconnect callback from an
        # old client object shortly after a new connect succeeds. Guard the handoff with a
        # short settle window so we fail fast instead of keeping a "connected but dead CLI"
        # session alive in UI state.
        if sys.platform.startswith("linux") or sys.platform.startswith("win"):
            await asyncio.sleep(0.2)
            if not manager.backend.is_connected(address) or not dev.is_connected:
                manager._log(
                    f"Connect race guard tripped: {address}: stale callback/mismatch after reconnect"
                )
                raise RuntimeError("connect-race-stale-callback")
        # AKR devices begin streaming runtime telemetry right after connect.
        dev.is_streaming = True

    async def stream_one(self, manager: DeviceSessionManager, address: str, dev: DeviceState, enable: bool) -> None:
        if not manager.backend.is_connected(address):
            return
        # AKR streams immediately after connect; stream toggle is local UX state only.
        dev.is_streaming = bool(enable)
        if enable:
            manager._reset_akr_stream_state(address, dev)
        manager._notify_updated(address)

    async def send_ota_frames(
        self,
        manager: DeviceSessionManager,
        address: str,
        file_path: str,
        *,
        ack_timeout_ms: int,
        retries: int,
        inter_frame_ms: int,
        write_chunk_size: int,
        write_with_response: bool,
    ) -> ota_transfer.OtaSummary:
        dev = manager.devices.get(address)
        if not dev or not manager._supports_ota(address):
            raise RuntimeError("OTA is only supported for connected AKR devices")
        if not manager.backend.is_connected(address):
            raise RuntimeError(f"Not connected: {address}")

        frames = ota_transfer.load_and_validate_frames(file_path)
        requested_ack_timeout_ms_i = int(ack_timeout_ms)
        requested_retries_i = int(retries)
        requested_inter_frame_ms_i = int(inter_frame_ms)
        requested_write_chunk_size_i = int(write_chunk_size)
        requested_write_with_response_b = bool(write_with_response)
        enforce_safe_profile = bool(getattr(config, "AKR_OTA_ENFORCE_SAFE_PROFILE", True))
        safe_min_ack_timeout_ms = int(getattr(config, "AKR_OTA_SAFE_MIN_ACK_TIMEOUT_MS", 1200))
        safe_min_retries = int(getattr(config, "AKR_OTA_SAFE_MIN_RETRIES", 15))
        safe_min_inter_frame_ms = int(getattr(config, "AKR_OTA_SAFE_MIN_INTER_FRAME_MS", 3))
        safe_max_write_chunk_size = max(1, int(getattr(config, "AKR_OTA_SAFE_MAX_WRITE_CHUNK_SIZE", 120)))
        safe_force_write_with_response = bool(getattr(config, "AKR_OTA_SAFE_FORCE_WRITE_WITH_RESPONSE", True))

        # Safe profile enforcement clamps user-selected values onto a reliability-first envelope:
        # 1) increase timeout/retry pacing to reduce transient BLE loss sensitivity,
        # 2) cap chunk size to limit large-write fragility on constrained links,
        # 3) force write-with-response to serialize chunk delivery and ACK timing.
        # Keeping this centralized guarantees safety regardless of UI/script entrypoint.
        if enforce_safe_profile:
            ack_timeout_ms_i = max(requested_ack_timeout_ms_i, safe_min_ack_timeout_ms)
            retries_i = max(requested_retries_i, safe_min_retries)
            inter_frame_ms_i = max(requested_inter_frame_ms_i, safe_min_inter_frame_ms)
            write_chunk_size_i = max(1, min(requested_write_chunk_size_i, safe_max_write_chunk_size))
            write_with_response_b = bool(safe_force_write_with_response or requested_write_with_response_b)
        else:
            ack_timeout_ms_i = requested_ack_timeout_ms_i
            retries_i = requested_retries_i
            inter_frame_ms_i = requested_inter_frame_ms_i
            write_chunk_size_i = requested_write_chunk_size_i
            write_with_response_b = requested_write_with_response_b

        data_timeout_floor_ms = int(config.AKR_OTA_DATA_ACK_TIMEOUT_MS)
        data_timeout_multiplier = float(getattr(config, "AKR_OTA_DATA_ACK_TIMEOUT_MULTIPLIER", 2.0))
        data_timeout_abs_max_ms = int(getattr(config, "AKR_OTA_DATA_ACK_TIMEOUT_MAX_MS", 20000))
        # DATA timeout tuning flow:
        # 1) derive timeout from user ACK timeout so presets scale together,
        # 2) apply fixed lower bound to avoid too-small values,
        # 3) cap upper bound to keep retries bounded and predictable.
        data_ack_timeout_ms_i = int(
            min(
                max(float(ack_timeout_ms_i) * data_timeout_multiplier, float(data_timeout_floor_ms)),
                float(max(1000, data_timeout_abs_max_ms)),
            )
        )
        base_options = ota_transfer.OtaOptions(
            ack_timeout_ms=ack_timeout_ms_i,
            data_ack_timeout_ms=data_ack_timeout_ms_i,
            retries=int(retries_i),
            inter_frame_ms=int(inter_frame_ms_i),
            write_chunk_size=int(write_chunk_size_i),
            write_with_response=bool(write_with_response_b),
        )

        lock = manager._akr_ota_lock.setdefault(str(address), asyncio.Lock())
        if lock.locked():
            raise RuntimeError("OTA is already running for this device")

        async with lock:
            manager._akr_get_ota_ack_queue(address)
            manager._akr_clear_ota_ack_queue(address)
            manager._log(f"AKR OTA: start address={address} file={file_path}")
            if enforce_safe_profile:
                manager._log(
                    "AKR OTA "
                    f"[{address}] safe profile enforced: requested "
                    f"ack_timeout_ms={requested_ack_timeout_ms_i} retries={requested_retries_i} "
                    f"inter_frame_ms={requested_inter_frame_ms_i} chunk={requested_write_chunk_size_i} "
                    f"write_with_response={requested_write_with_response_b} -> effective "
                    f"ack_timeout_ms={ack_timeout_ms_i} retries={retries_i} "
                    f"inter_frame_ms={inter_frame_ms_i} chunk={write_chunk_size_i} "
                    f"write_with_response={write_with_response_b}"
                )
            manager._log(
                f"AKR OTA [{address}] effective timeout profile: ack_timeout_ms={ack_timeout_ms_i} "
                f"data_ack_timeout_ms={data_ack_timeout_ms_i} "
                f"(multiplier={data_timeout_multiplier:.2f} floor={data_timeout_floor_ms} "
                f"max={data_timeout_abs_max_ms})"
            )
            profile = akr_protocol.AKR_CONNECT_PROFILES[0]
            manager._akr_get_ota_line_queue(address)
            manager._akr_clear_ota_ack_queue(address)
            manager._akr_clear_ota_line_queue(address)
            manager._log(
                f"AKR OTA [{address}] attempt profile={profile.name} "
                f"write_with_response={bool(base_options.write_with_response)} "
                f"ack_timeout_ms={int(base_options.ack_timeout_ms)} "
                f"data_ack_timeout_ms={int(base_options.data_ack_timeout_ms or 0)}"
            )
            try:
                # OTA session startup must be explicitly staged before binary frames.
                # Flow:
                # 1) clear stale text/ACK queues from previous traffic,
                # 2) send CLI command `update firmware`,
                # 3) wait for exact CLI confirmation line,
                # 4) clear queues again before first binary frame write.
                # This prevents mixed CLI bytes from being mistaken as frame ACKs.
                start_line = await start_ota_session(
                    manager,
                    address,
                    command=str(config.AKR_OTA_SESSION_START_COMMAND),
                    expected_line=str(config.AKR_OTA_SESSION_START_EXPECTED_LINE),
                    timeout_s=float(config.AKR_OTA_SESSION_START_TIMEOUT_S),
                    retries=int(config.AKR_OTA_SESSION_START_RETRIES),
                )
                manager._log(f"AKR OTA [{address}] session-start confirmed: {start_line!r}")
                summary = await ota_transfer.send_frames(
                    frames=frames,
                    options=base_options,
                    write_chunk=lambda chunk, with_response: manager.backend.write(
                        address,
                        chunk,
                        response=with_response,
                    ),
                    wait_ack=lambda timeout_s: manager._akr_wait_ota_ack(address, timeout_s),
                    clear_acks=lambda: manager._akr_clear_ota_ack_queue(address),
                    on_progress=lambda p: manager._emit_akr_ota_progress(address, p),
                    on_log=lambda msg: manager._log(f"AKR OTA [{address}] {msg}"),
                )
                manager._log(
                    "AKR OTA: done "
                    f"address={address} elapsed={summary.elapsed_s:.2f}s "
                    f"payload={summary.payload_sent_ok}B "
                    f"profile={profile.name} "
                    f"write_with_response={bool(base_options.write_with_response)}"
                )
                return summary
            except ota_transfer.OtaTransferError as e:
                terminal_nak = bool(bytes(e.last_ack) in ota_transfer.NAK_SET)
                manager._log(
                    f"AKR OTA [{address}] failed: "
                    f"frame={e.frame_index} type=0x{e.frame_type:02X} "
                    f"expected={e.expected_ack!r} last_ack={e.last_ack!r} "
                    f"timeout_only={e.timeout_only} terminal_nak={terminal_nak}"
                )
                if terminal_nak:
                    raise RuntimeError(
                        "OTA session ended by device with terminal ACK "
                        f"{e.last_ack!r} at frame {e.frame_index}. "
                        "Start a new session with `update firmware` and retry from START."
                    ) from e
                raise RuntimeError(
                    f"Frame {e.frame_index} failed after {e.retries} retries "
                    f"(timeout_only={e.timeout_only})"
                ) from e
            except AkrOtaSessionStartError as e:
                manager._log(
                    f"AKR OTA [{address}] session-start failed: "
                    f"cmd={e.command!r} expected={e.expected_line!r} "
                    f"retries={e.attempts} timeout_s={e.timeout_s:.2f}"
                )
                raise RuntimeError(
                    f"OTA session-start failed: expected {e.expected_line!r} "
                    f"within {e.timeout_s:.2f}s"
                ) from e
            except Exception as e:
                manager._log(
                    f"AKR OTA [{address}] transport error: "
                    f"{type(e).__name__}: {e!r}"
                )
                raise RuntimeError(
                    f"OTA failed: {type(e).__name__}: {e}"
                ) from e

