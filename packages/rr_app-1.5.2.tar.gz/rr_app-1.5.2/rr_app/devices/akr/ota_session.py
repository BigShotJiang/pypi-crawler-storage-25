from __future__ import annotations

import asyncio
import time

from .ble import utils as akr_utils
from ..core.contracts import AkrOtaSessionHost


class AkrOtaSessionStartError(RuntimeError):
    def __init__(
        self,
        *,
        address: str,
        command: str,
        expected_line: str,
        timeout_s: float,
        attempts: int,
        last_line: str,
    ) -> None:
        super().__init__(
            "AKR OTA session start failed "
            f"(address={address}, command={command!r}, expected={expected_line!r}, "
            f"attempts={attempts}, timeout_s={float(timeout_s):.2f}, last_line={last_line!r})"
        )
        self.address = str(address)
        self.command = str(command)
        self.expected_line = str(expected_line)
        self.timeout_s = float(timeout_s)
        self.attempts = int(attempts)
        self.last_line = str(last_line)


async def _wait_ota_line(
    host: AkrOtaSessionHost,
    address: str,
    *,
    expected_line: str,
    timeout_s: float,
) -> tuple[str, str]:
    q = host._akr_get_ota_line_queue(address)
    expect = akr_utils.normalize_cli_line(expected_line)
    deadline_s = time.monotonic() + max(0.1, float(timeout_s))
    last_line = ""
    # Session-start confirmation matching uses one fixed deadline:
    # 1) consume queued CLI lines in order,
    # 2) retain the latest non-match for diagnostics,
    # 3) stop at one hard timeout so noisy streams cannot extend attempts.
    while True:
        remaining_s = deadline_s - time.monotonic()
        if remaining_s <= 0:
            raise asyncio.TimeoutError()
        got = await asyncio.wait_for(q.get(), timeout=remaining_s)
        last_line = str(got)
        if akr_utils.normalize_cli_line(got) == expect:
            return str(got), last_line


async def start_ota_session(
    host: AkrOtaSessionHost,
    address: str,
    *,
    command: str,
    expected_line: str,
    timeout_s: float,
    retries: int,
) -> str:
    retries_i = max(1, int(retries))
    timeout_f = max(0.1, float(timeout_s))
    last_line = ""
    for attempt in range(1, retries_i + 1):
        host._akr_clear_ota_ack_queue(address)
        host._akr_clear_ota_line_queue(address)
        await host.akr_send_line(address, command)
        try:
            line, last_line = await _wait_ota_line(
                host,
                address,
                expected_line=expected_line,
                timeout_s=timeout_f,
            )
            host._akr_clear_ota_ack_queue(address)
            host._akr_clear_ota_line_queue(address)
            return line
        except asyncio.TimeoutError:
            host._log(
                f"AKR OTA [{address}] session-start timeout: attempt={attempt}/{retries_i} "
                f"timeout={timeout_f:.2f}s expected={expected_line!r}"
            )
    raise AkrOtaSessionStartError(
        address=str(address),
        command=str(command),
        expected_line=str(expected_line),
        timeout_s=timeout_f,
        attempts=retries_i,
        last_line=last_line,
    )

