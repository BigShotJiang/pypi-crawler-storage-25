from __future__ import annotations

import collections
from dataclasses import dataclass, field
from typing import Deque, Optional

from ... import config


@dataclass(slots=True)
class AkrDeviceState:
    # AKR text-stream and telemetry state.
    akr_origin_monotonic_s: Optional[float] = None
    akr_step_dt_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_exec_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_out_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_state_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_fid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_dt_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_exec_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_out_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_state_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_acc_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_gyr_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_mag_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_tilt_forward_deg_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_pos_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_vel_rad_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_tq_nm_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_temp_c_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_vbus_v_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_pattern_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_err_code_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_walk_fb_age_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_fid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_dt_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_state_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_dir_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_blocked_event_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_block_reason_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_blocked_consecutive_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_cmd_spd_rad_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_pos_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_vel_rad_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_tq_nm_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_temp_c_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_vbus_v_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_pattern_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_err_code_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_fb_age_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_df_limit_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_pf_limit_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_elapsed_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_remaining_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_has_remaining_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cpm_repetition_count_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_fid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_dt_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_state_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_dir_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_blocked_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_result_flags_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_pos_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_vel_rad_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_tq_nm_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_temp_c_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_vbus_v_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_pattern_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_err_code_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_fb_age_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_prom_df_end_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_prom_pf_end_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_arom_df_max_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_arom_pf_min_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_flag_prom_df_valid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_flag_prom_pf_valid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_flag_arom_valid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_flag_seq_active_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_test_flag_arom_running_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_fid_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_gait_model_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_gait_mode_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_side_is_left_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_df_assist_pct_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_pf_assist_pct_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_df_torque_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_df_angle_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_df_speed_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_df_kp_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_df_kd_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_pf_torque_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_pf_angle_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_pf_speed_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_pf_kp_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_pf_kd_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_cpm_target_df_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_cpm_target_pf_rad_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_cpm_speed_to_df_rad_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_cpm_speed_to_pf_rad_s_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_cpm_block_tq_nm_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_cpm_wait_to_df_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cfg_cpm_wait_to_pf_ms_buffer: Deque[tuple[float, list[float]]] = field(default_factory=lambda: collections.deque(maxlen=config.IMU_RING_LEN))
    akr_cli_feedback_origin_monotonic_s: Optional[float] = None
    akr_cli_feedback_buffer_by_key: dict[str, Deque[tuple[float, list[float]]]] = field(default_factory=dict)
    akr_robot_identity_seen: bool = False
    akr_robot_id: str = ""
    akr_ble_target_name: str = ""
    akr_robot_fw_version: str = ""

    def reset(self) -> None:
        for field_name in self.__dataclass_fields__:
            value = getattr(self, field_name)
            if isinstance(value, collections.deque):
                value.clear()
            elif isinstance(value, dict):
                value.clear()
            elif field_name.endswith("_seen"):
                setattr(self, field_name, False)
            elif field_name.endswith("_name") or field_name.endswith("_id") or field_name.endswith("_version"):
                setattr(self, field_name, "")
            elif field_name.endswith("_s"):
                setattr(self, field_name, None)

