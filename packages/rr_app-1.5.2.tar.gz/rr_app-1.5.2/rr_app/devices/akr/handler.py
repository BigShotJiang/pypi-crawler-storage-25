from __future__ import annotations

import asyncio
import time
from typing import TYPE_CHECKING

from ... import config
from ..core.base import DEVICE_KIND_AKR, DeviceCapabilities, DeviceHandler
from .ble import protocol
from .ble import stream

if TYPE_CHECKING:
    from ..core.contracts import AkrHandlerHost
    from ..emgs.state import DeviceState


class AkrDeviceHandler(DeviceHandler):
    kind = DEVICE_KIND_AKR
    capabilities = DeviceCapabilities(
        supports_stream_toggle=False,
        supports_settings=False,
        supports_ota=True,
        emits_text_lines=True,
    )

    async def connect(self, manager: AkrHandlerHost, address: str, dev: DeviceState) -> None:
        _ = dev
        selected_profile = None
        preferred_profile = protocol.AKR_CONNECT_PROFILES[0]
        profile_count = len(protocol.AKR_CONNECT_PROFILES)
        last_connect_error: Exception | None = None
        for idx, profile in enumerate(protocol.AKR_CONNECT_PROFILES, start=1):
            manager._log(
                f"Connect: {address}: trying AKR BLE profile "
                f"{profile.name} ({idx}/{profile_count})"
            )
            try:
                await manager.backend.connect(
                    address,
                    on_notify=manager._on_notify,
                    on_disconnect=manager._on_disconnect,
                    write_uuid=profile.write_uuid,
                    notify_uuid=profile.notify_uuid,
                )
                selected_profile = profile
                break
            except asyncio.CancelledError:
                raise
            except Exception as e:
                last_connect_error = e
                manager._log(
                    f"Connect: {address}: profile {profile.name} failed: "
                    f"{type(e).__name__}: {e!r}"
                )

        if selected_profile is None:
            if last_connect_error is not None:
                raise last_connect_error
            raise RuntimeError("AKR connect failed: no BLE profile candidates configured")

        if selected_profile.name != preferred_profile.name:
            manager._log(
                f"Connect: {address}: fallback profile in use: "
                f"{selected_profile.name} (preferred {preferred_profile.name} unavailable)"
            )
            manager._emit_akr_line(
                address,
                f"[BLE] Fallback profile in use: {selected_profile.name}",
            )
        else:
            manager._log(f"Connect: {address}: using AKR BLE profile {selected_profile.name}")

    async def post_connect(self, manager: AkrHandlerHost, address: str, dev: DeviceState) -> None:
        _ = manager
        _ = address
        _ = dev

    def handle_notify(self, manager: AkrHandlerHost, address: str, dev: DeviceState, data: bytes) -> None:
        _ = dev
        manager._akr_feed_ota_ack_bytes(address, bytes(data))
        stream.handle_rx_bytes(manager, address, bytes(data))
        now = time.monotonic()
        last_ui = manager._ui_last_emit_s.get(address, 0.0)
        if (now - last_ui) >= config.UI_DEVICE_UPDATE_MIN_INTERVAL_S:
            manager._ui_last_emit_s[address] = now
            manager._notify_updated(address)

