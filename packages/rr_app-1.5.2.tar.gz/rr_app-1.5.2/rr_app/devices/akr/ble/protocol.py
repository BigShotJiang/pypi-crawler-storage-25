"""AKR BLE profile definitions.

Use one production BLE profile for AKR devices.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final


@dataclass(frozen=True, slots=True)
class AkrBleProfile:
    name: str
    service_uuid: str
    write_uuid: str
    notify_uuid: str


# Production AKR profile.
# FSC-BT986 GATT:
# - Service: FFF0
# - Notify:  FFF1
# - Write:   FFF2
AKR_PROFILE_PRIMARY: Final[AkrBleProfile] = AkrBleProfile(
    name="AKR_PRIMARY_FFF0",
    service_uuid="0000fff0-0000-1000-8000-00805f9b34fb",
    write_uuid="0000fff2-0000-1000-8000-00805f9b34fb",
    notify_uuid="0000fff1-0000-1000-8000-00805f9b34fb",
)

# Connection order remains a tuple for manager retry logic, but includes
# only the supported production profile.
AKR_CONNECT_PROFILES: Final[tuple[AkrBleProfile, ...]] = (
    AKR_PROFILE_PRIMARY,
)


__all__ = [
    "AkrBleProfile",
    "AKR_PROFILE_PRIMARY",
    "AKR_CONNECT_PROFILES",
]

