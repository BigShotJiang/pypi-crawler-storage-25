from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Awaitable, Callable, Iterable


SYNC1 = 0x55
SYNC2 = 0xAA

FRAME_START = 0x01
FRAME_DATA = 0x02
FRAME_END = 0x03

FRAME_HDR_LEN = 7
START_META_LEN = 6

ACK_MAP = {
    FRAME_START: b"S",
    FRAME_DATA: b"A",
    FRAME_END: b"O",
}

NAK_SET = {b"E", b"F"}


WriteChunkFn = Callable[[bytes, bool], Awaitable[None]]
WaitAckFn = Callable[[float], Awaitable[bytes]]
ClearAcksFn = Callable[[], None]
ProgressFn = Callable[["OtaProgress"], None]
LogFn = Callable[[str], None]
SleepFn = Callable[[float], Awaitable[None]]


@dataclass(frozen=True, slots=True)
class OtaOptions:
    ack_timeout_ms: int = 800
    data_ack_timeout_ms: int | None = None
    retries: int = 10
    inter_frame_ms: int = 0
    write_chunk_size: int = 180
    write_with_response: bool = False

    def validate(self) -> None:
        if int(self.write_chunk_size) <= 0:
            raise ValueError("write_chunk_size must be > 0")
        if int(self.retries) <= 0:
            raise ValueError("retries must be > 0")
        if int(self.ack_timeout_ms) <= 0:
            raise ValueError("ack_timeout_ms must be > 0")
        if self.data_ack_timeout_ms is not None and int(self.data_ack_timeout_ms) <= 0:
            raise ValueError("data_ack_timeout_ms must be > 0 when provided")
        if int(self.inter_frame_ms) < 0:
            raise ValueError("inter_frame_ms must be >= 0")


@dataclass(frozen=True, slots=True)
class OtaProgress:
    frame_index: int
    frame_total: int
    frame_type: int
    attempt: int
    ack: bytes
    payload_total: int
    payload_sent_ok: int
    progress_pct: float
    bytes_written_total: int
    elapsed_s: float
    avg_payload_kbps: float
    avg_line_kbps: float
    inst_payload_kbps: float


@dataclass(frozen=True, slots=True)
class OtaSummary:
    frame_total: int
    payload_total: int
    payload_sent_ok: int
    bytes_written_total: int
    elapsed_s: float
    avg_payload_kbps: float
    avg_line_kbps: float


class OtaTransferError(RuntimeError):
    def __init__(
        self,
        *,
        message: str,
        frame_index: int,
        frame_type: int,
        expected_ack: bytes,
        last_ack: bytes,
        retries: int,
        timeout_only: bool,
        saw_any_ack: bool,
    ) -> None:
        super().__init__(message)
        self.frame_index = int(frame_index)
        self.frame_type = int(frame_type)
        self.expected_ack = bytes(expected_ack)
        self.last_ack = bytes(last_ack)
        self.retries = int(retries)
        self.timeout_only = bool(timeout_only)
        self.saw_any_ack = bool(saw_any_ack)


def split_frames(blob: bytes) -> list[tuple[int, bytes]]:
    frames: list[tuple[int, bytes]] = []
    i = 0
    n = len(blob)
    while i < n:
        if i + FRAME_HDR_LEN + 2 > n:
            raise ValueError(f"Incomplete frame at offset {i}")
        if blob[i] != SYNC1 or blob[i + 1] != SYNC2:
            raise ValueError(f"Bad sync at offset {i}: {blob[i]:02X} {blob[i+1]:02X}")

        frame_type = blob[i + 2]
        payload_len = blob[i + 7] | (blob[i + 8] << 8)
        frame_len = 2 + FRAME_HDR_LEN + payload_len + 2
        end = i + frame_len
        if end > n:
            raise ValueError(f"Incomplete frame body at offset {i}, need {frame_len} bytes")

        frames.append((frame_type, blob[i:end]))
        i = end
    return frames


def crc16_ccitt_false(data: bytes, init: int = 0xFFFF) -> int:
    crc = init & 0xFFFF
    for b in data:
        crc ^= (b << 8) & 0xFFFF
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
    return crc


def payload_len_from_frame(frame: bytes) -> int:
    return frame[7] | (frame[8] << 8)


def decode_frame_header(frame: bytes) -> tuple[int, int, int]:
    frame_type = frame[2]
    offset = frame[3] | (frame[4] << 8) | (frame[5] << 16) | (frame[6] << 24)
    payload_len = payload_len_from_frame(frame)
    return frame_type, offset, payload_len


def validate_frames_preflight(frames: Iterable[tuple[int, bytes]]) -> None:
    frame_list = list(frames)
    if len(frame_list) < 3:
        raise ValueError("Frame file is too short; expected at least START, DATA, END")

    first_type, first_frame = frame_list[0]
    last_type, _ = frame_list[-1]
    if first_type != FRAME_START:
        raise ValueError(f"First frame must be START (0x01), got 0x{first_type:02X}")
    if last_type != FRAME_END:
        raise ValueError(f"Last frame must be END (0x03), got 0x{last_type:02X}")

    start_type, start_offset, start_len = decode_frame_header(first_frame)
    if start_type != FRAME_START or start_offset != 0 or start_len != START_META_LEN:
        raise ValueError("START frame has invalid offset/len")
    image_size = (
        first_frame[9]
        | (first_frame[10] << 8)
        | (first_frame[11] << 16)
        | (first_frame[12] << 24)
    )
    if image_size == 0:
        raise ValueError("START frame image_size must be non-zero")

    expected_next_offset = 0
    total_data_bytes = 0
    saw_data = False
    for idx, (frame_type, frame) in enumerate(frame_list, start=1):
        ft, off, plen = decode_frame_header(frame)
        if ft != frame_type:
            raise ValueError(f"Frame type mismatch at frame {idx}")

        core = frame[2 : 2 + FRAME_HDR_LEN + plen]
        read_crc = frame[2 + FRAME_HDR_LEN + plen] | (frame[2 + FRAME_HDR_LEN + plen + 1] << 8)
        calc_crc = crc16_ccitt_false(core)
        if read_crc != calc_crc:
            raise ValueError(f"Frame CRC mismatch at frame {idx}: 0x{read_crc:04X} != 0x{calc_crc:04X}")

        if frame_type == FRAME_START:
            continue
        if frame_type == FRAME_DATA:
            saw_data = True
            if plen == 0 or plen > 512:
                raise ValueError(f"DATA payload_len out of range at frame {idx}: {plen}")
            if off != expected_next_offset:
                raise ValueError(
                    f"DATA offset discontinuity at frame {idx}: got {off}, expected {expected_next_offset}"
                )
            expected_next_offset += plen
            total_data_bytes += plen
            continue
        if frame_type == FRAME_END:
            if plen != 0:
                raise ValueError("END payload_len must be 0")
            if off != expected_next_offset:
                raise ValueError(f"END offset {off} does not match DATA bytes {expected_next_offset}")
            continue
        raise ValueError(f"Unknown frame type 0x{frame_type:02X} at frame {idx}")

    if not saw_data:
        raise ValueError("No DATA frames found")
    if total_data_bytes != image_size:
        raise ValueError(f"START image_size {image_size} does not match DATA bytes {total_data_bytes}")


def load_and_validate_frames(file_path: str | Path) -> list[tuple[int, bytes]]:
    data = Path(file_path).read_bytes()
    frames = split_frames(data)
    if not frames:
        raise ValueError("No frames found in file")
    validate_frames_preflight(frames)
    return frames


async def _write_frame(
    *,
    frame: bytes,
    write_chunk: WriteChunkFn,
    chunk_size: int,
    with_response: bool,
) -> int:
    i = 0
    n = len(frame)
    while i < n:
        chunk = frame[i : i + chunk_size]
        await write_chunk(chunk, with_response)
        i += len(chunk)
    return n


async def send_frames(
    *,
    frames: list[tuple[int, bytes]],
    options: OtaOptions,
    write_chunk: WriteChunkFn,
    wait_ack: WaitAckFn,
    clear_acks: ClearAcksFn | None = None,
    on_progress: ProgressFn | None = None,
    on_log: LogFn | None = None,
    sleep_fn: SleepFn | None = None,
) -> OtaSummary:
    options.validate()
    if not frames:
        raise ValueError("No frames to send")

    sleep_impl = sleep_fn or asyncio.sleep
    ack_timeout_s = float(options.ack_timeout_ms) / 1000.0
    data_ack_timeout_s = (
        float(options.data_ack_timeout_ms) / 1000.0
        if options.data_ack_timeout_ms is not None
        else (ack_timeout_s * 2.0)
    )
    inter_frame_s = float(options.inter_frame_ms) / 1000.0

    payload_total = sum(payload_len_from_frame(f) for t, f in frames if t == FRAME_DATA)
    payload_sent_ok = 0
    bytes_written_total = 0
    start_time = time.perf_counter()

    if on_log:
        on_log(f"Total frames: {len(frames)}")
        on_log(f"DATA payload bytes (image): {payload_total}")

    for idx, (frame_type, frame) in enumerate(frames, start=1):
        expect_ack = ACK_MAP.get(frame_type)
        if expect_ack is None:
            raise ValueError(f"Unknown frame type 0x{frame_type:02X} at index {idx}")
        frame_payload_len = payload_len_from_frame(frame)
        ok = False
        saw_any_ack = False
        last_ack = b""

        frame_ack_timeout_s = data_ack_timeout_s if frame_type == FRAME_DATA else ack_timeout_s
        for attempt in range(1, int(options.retries) + 1):
            if clear_acks is not None:
                clear_acks()

            t0 = time.perf_counter()
            bytes_written_total += await _write_frame(
                frame=frame,
                write_chunk=write_chunk,
                chunk_size=int(options.write_chunk_size),
                with_response=bool(options.write_with_response),
            )

            attempt_ack_timeout_s = frame_ack_timeout_s
            if frame_type == FRAME_DATA:
                attempt_ack_timeout_s = min(
                    frame_ack_timeout_s * (1.0 + (0.35 * float(attempt - 1))),
                    frame_ack_timeout_s * 2.0,
                )

            try:
                ack = await wait_ack(attempt_ack_timeout_s)
            except asyncio.TimeoutError:
                ack = b""
            if ack:
                saw_any_ack = True
            last_ack = ack

            if ack == expect_ack:
                ok = True
                if frame_type == FRAME_DATA:
                    payload_sent_ok += frame_payload_len
                elapsed = max(1e-9, time.perf_counter() - start_time)
                progress = (payload_sent_ok * 100.0 / payload_total) if payload_total > 0 else 100.0
                avg_payload_kbps = (payload_sent_ok / 1024.0) / elapsed
                avg_line_kbps = (bytes_written_total / 1024.0) / elapsed
                frame_elapsed = max(1e-9, time.perf_counter() - t0)
                inst_payload_kbps = (frame_payload_len / 1024.0) / frame_elapsed if frame_type == FRAME_DATA else 0.0
                update = OtaProgress(
                    frame_index=idx,
                    frame_total=len(frames),
                    frame_type=frame_type,
                    attempt=attempt,
                    ack=ack,
                    payload_total=payload_total,
                    payload_sent_ok=payload_sent_ok,
                    progress_pct=progress,
                    bytes_written_total=bytes_written_total,
                    elapsed_s=elapsed,
                    avg_payload_kbps=avg_payload_kbps,
                    avg_line_kbps=avg_line_kbps,
                    inst_payload_kbps=inst_payload_kbps,
                )
                if on_progress:
                    on_progress(update)
                if on_log:
                    on_log(
                        f"[{idx}/{len(frames)}] type=0x{frame_type:02X} ACK={ack.decode(errors='replace')} "
                        f"attempt={attempt} progress={progress:.2f}% "
                        f"payload={payload_sent_ok}/{payload_total}B "
                        f"avg_payload={avg_payload_kbps:.2f}KB/s avg_line={avg_line_kbps:.2f}KB/s "
                        f"inst_payload~{inst_payload_kbps:.2f}KB/s"
                    )
                break

            if ack in NAK_SET:
                if on_log:
                    on_log(
                        f"[{idx}/{len(frames)}] type=0x{frame_type:02X} terminal NAK="
                        f"{ack.decode(errors='replace')} attempt={attempt}"
                    )
                raise OtaTransferError(
                    message=(
                        f"Frame {idx} got terminal NAK {ack!r}; OTA session ended on device. "
                        "Host must restart with `update firmware`."
                    ),
                    frame_index=idx,
                    frame_type=frame_type,
                    expected_ack=expect_ack,
                    last_ack=ack,
                    retries=attempt,
                    timeout_only=False,
                    saw_any_ack=True,
                )
            if on_log:
                if ack == b"":
                    timeout_budget_ms = int(attempt_ack_timeout_s * 1000.0)
                    on_log(
                        f"[{idx}/{len(frames)}] type=0x{frame_type:02X} timeout "
                        f"attempt={attempt} wait_ms={timeout_budget_ms}"
                    )
                else:
                    on_log(f"[{idx}/{len(frames)}] type=0x{frame_type:02X} unexpected={ack!r} attempt={attempt}")

        if not ok:
            raise OtaTransferError(
                message=f"Frame {idx} failed after {options.retries} retries",
                frame_index=idx,
                frame_type=frame_type,
                expected_ack=expect_ack,
                last_ack=last_ack,
                retries=int(options.retries),
                timeout_only=(not saw_any_ack),
                saw_any_ack=saw_any_ack,
            )
        if inter_frame_s > 0:
            await sleep_impl(inter_frame_s)

    elapsed_total = max(1e-9, time.perf_counter() - start_time)
    summary = OtaSummary(
        frame_total=len(frames),
        payload_total=payload_total,
        payload_sent_ok=payload_sent_ok,
        bytes_written_total=bytes_written_total,
        elapsed_s=elapsed_total,
        avg_payload_kbps=(payload_sent_ok / 1024.0) / elapsed_total,
        avg_line_kbps=(bytes_written_total / 1024.0) / elapsed_total,
    )
    if on_log:
        on_log("OTA frames send done.")
        on_log(
            f"Summary: elapsed={summary.elapsed_s:.2f}s payload={summary.payload_sent_ok}B "
            f"avg_payload={summary.avg_payload_kbps:.2f}KB/s "
            f"line_tx={summary.bytes_written_total}B avg_line={summary.avg_line_kbps:.2f}KB/s"
        )
    return summary


__all__ = [
    "ACK_MAP",
    "FRAME_DATA",
    "FRAME_END",
    "FRAME_START",
    "NAK_SET",
    "OtaOptions",
    "OtaProgress",
    "OtaSummary",
    "OtaTransferError",
    "crc16_ccitt_false",
    "decode_frame_header",
    "load_and_validate_frames",
    "payload_len_from_frame",
    "send_frames",
    "split_frames",
    "validate_frames_preflight",
]

