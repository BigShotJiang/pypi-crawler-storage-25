from __future__ import annotations

import math
import re
import struct
import time
from typing import TYPE_CHECKING

from . import utils as akr_utils

if TYPE_CHECKING:
    from ...core.contracts import AkrStreamHost
    from ...emgs.state import DeviceState


def emit_text_line(manager: AkrStreamHost, address: str, line: str) -> None:
    s = str(line).replace("\x00", "")
    if not s:
        return
    while True:
        stripped = s.strip()
        if stripped == ">":
            manager._emit_akr_line(address, ">")
            return
        if s.startswith("> "):
            manager._emit_akr_line(address, ">")
            s = s[2:]
            if not s:
                return
            continue
        break
    manager._akr_feed_ota_line(address, s)
    manager._emit_akr_line(address, s)
    maybe_parse_runtime_status_line(manager, address, s)
    maybe_parse_rr_akr_line(manager, address, s)


def _update_robot_identity(
    manager: AkrStreamHost,
    address: str,
    dev: DeviceState,
    *,
    robot_id: str | None,
    ble_target: str | None,
) -> None:
    changed = akr_utils.update_robot_identity(dev, robot_id=robot_id, ble_target=ble_target)
    if changed:
        manager._notify_updated(address)


def _append_cfg_snapshot(manager: AkrStreamHost, address: str, dev: DeviceState, updates: dict[str, float]) -> None:
    fid = int(manager._akr_cli_cfg_fid.get(address, 0))
    manager._akr_cli_cfg_fid[address] = akr_utils.append_cfg_snapshot(dev, updates, cfg_fid=fid)


def maybe_parse_runtime_status_line(manager: AkrStreamHost, address: str, line: str) -> None:
    # Runtime line parsing order is intentional:
    # 1) parse strong identity/version prefixes first,
    # 2) then handle mode transitions,
    # 3) finally fall back to generic key/value cfg snapshots.
    # This avoids generic parsing swallowing identity-specific updates.
    dev = manager.devices.get(address)
    if not dev:
        return
    s = str(line).strip()
    if not s or s == ">":
        return

    m_mode_line = re.match(r"(?i)^MODE\s+mode=([a-z0-9_]+)\s*$", s)
    if m_mode_line:
        mode_new = str(m_mode_line.group(1) or "").strip().lower()
        if mode_new and str(getattr(dev.params, "mode", "")).strip().lower() != mode_new:
            dev.params.mode = mode_new
            manager._notify_updated(address)
        return

    m_robot_id = re.match(r"(?i)^ROBOT\s+ID\s+id=(\S+)\s+ble_name=(\S+)\s*$", s)
    if m_robot_id:
        _update_robot_identity(
            manager,
            address,
            dev,
            robot_id=akr_utils.decode_robot_id_token(m_robot_id.group(1), dash_is_empty=False),
            ble_target=str(m_robot_id.group(2)).strip(),
        )
        return

    m_robot_ver = re.match(r"(?i)^ROBOT\s+VER\s+([^\r\n]+)\s*$", s)
    if m_robot_ver:
        fw_ver = str(m_robot_ver.group(1) or "").strip()
        if fw_ver:
            changed = False
            if str(getattr(dev.akr, "akr_robot_fw_version", "")) != fw_ver:
                dev.akr.akr_robot_fw_version = fw_ver
                changed = True
            if str(getattr(dev.params, "firmware", "")) != fw_ver:
                dev.params.firmware = fw_ver
                changed = True
            if changed:
                manager._notify_updated(address)
        return

    if s.upper().startswith("BRIEF "):
        brief_values = akr_utils.extract_kv_pairs(s)
        if brief_values:
            rid_tok = brief_values.get("rid")
            bletgt_tok = brief_values.get("bletgt")
            _update_robot_identity(
                manager,
                address,
                dev,
                robot_id=(akr_utils.decode_robot_id_token(rid_tok, dash_is_empty=True) if rid_tok is not None else None),
                ble_target=(str(bletgt_tok).strip() if bletgt_tok is not None else None),
            )
            fw_tok = str(brief_values.get("fw", "")).strip()
            if fw_tok and str(getattr(dev.akr, "akr_robot_fw_version", "")) != fw_tok:
                dev.akr.akr_robot_fw_version = fw_tok
                dev.params.firmware = fw_tok
                manager._notify_updated(address)
            mode_tok = str(brief_values.get("mode", "")).strip().lower()
            if mode_tok and str(getattr(dev.params, "mode", "")).strip().lower() != mode_tok:
                dev.params.mode = mode_tok
                manager._notify_updated(address)

            brief_updates: dict[str, float] = {}
            side_tok = str(brief_values.get("side", "")).strip().lower()
            if side_tok in {"l", "left", "1", "true", "yes"}:
                brief_updates["side_is_left"] = 1.0
            elif side_tok in {"r", "right", "0", "false", "no"}:
                brief_updates["side_is_left"] = 0.0
            gait_val = akr_utils.parse_gait_model(brief_values.get("model"))
            if gait_val is not None:
                brief_updates["gait_model"] = gait_val
            if brief_updates:
                _append_cfg_snapshot(manager, address, dev, brief_updates)
        return

    m_show_robot_id = re.match(r"(?i)^RobotID\s*:\s*id=(\S+)\s+ble_target=(\S+)\s*$", s)
    if m_show_robot_id:
        _update_robot_identity(
            manager,
            address,
            dev,
            robot_id=akr_utils.decode_robot_id_token(m_show_robot_id.group(1), dash_is_empty=False),
            ble_target=str(m_show_robot_id.group(2)).strip(),
        )
        return

    m_set_robot_id_ok = re.match(r"(?i)^OK\s+robot\s+id=(\S+)\s+\(saved\)\s*$", s)
    if m_set_robot_id_ok:
        _update_robot_identity(
            manager,
            address,
            dev,
            robot_id=akr_utils.decode_robot_id_token(m_set_robot_id_ok.group(1), dash_is_empty=False),
            ble_target=None,
        )
        return

    rf_lower = s.lower()
    if rf_lower.startswith("rf short ") or rf_lower.startswith("rf long "):
        rf_values = akr_utils.extract_kv_pairs(s)
        mode_new = str(rf_values.get("mode") or "").strip().lower()
        if mode_new and str(getattr(dev.params, "mode", "")).strip().lower() != mode_new:
            dev.params.mode = mode_new
            manager._notify_updated(address)
        return

    if s.lower().startswith("work mode") and "=" in s:
        mode = s.split("=", 1)[1].strip()
        if mode:
            mode_new = str(mode).strip().lower()
            if mode_new and str(getattr(dev.params, "mode", "")).strip().lower() != mode_new:
                dev.params.mode = mode_new
                manager._notify_updated(address)
        return

    m_model_readback = re.match(r"(?i)^MODEL\s*:\s*([^\s\r\n]+)\s*$", s)
    if m_model_readback:
        gait_val = akr_utils.parse_gait_model(m_model_readback.group(1))
        if gait_val is not None:
            _append_cfg_snapshot(manager, address, dev, {"gait_model": gait_val})
        return

    values = akr_utils.extract_kv_pairs(s)
    if not values:
        return
    updates: dict[str, float] = {}

    if s.lower().startswith("ok ") and "mode" in values:
        mode_new = str(values.get("mode") or "").strip().lower()
        if mode_new and str(getattr(dev.params, "mode", "")).strip().lower() != mode_new:
            dev.params.mode = mode_new
            manager._notify_updated(address)

    section_match = re.match(r"(?i)^([a-z]+)(?:\s+move)?\s*:", s)
    section = str(section_match.group(1)).strip().lower() if section_match else ""

    if section == "df":
        akr_utils.add_cfg_float(updates, "df_torque", values.get("torque", values.get("tq")))
        akr_utils.add_cfg_float(updates, "df_angle", values.get("angle"))
        akr_utils.add_cfg_float(updates, "df_speed", values.get("speed"))
        akr_utils.add_cfg_float(updates, "df_kp", values.get("kp"))
        akr_utils.add_cfg_float(updates, "df_kd", values.get("kd"))
    elif section == "pf":
        akr_utils.add_cfg_float(updates, "pf_torque", values.get("torque", values.get("tq")))
        akr_utils.add_cfg_float(updates, "pf_angle", values.get("angle"))
        akr_utils.add_cfg_float(updates, "pf_speed", values.get("speed"))
        akr_utils.add_cfg_float(updates, "pf_kp", values.get("kp"))
        akr_utils.add_cfg_float(updates, "pf_kd", values.get("kd"))
    elif section == "cpm":
        akr_utils.add_cfg_float(updates, "cpm_target_df_rad", akr_utils.parse_float(values.get("df_rad")), radians=False)
        akr_utils.add_cfg_float(updates, "cpm_target_pf_rad", akr_utils.parse_float(values.get("pf_rad")), radians=False)
        akr_utils.add_cfg_float(updates, "cpm_speed_to_df_rad_s", values.get("speed_df"))
        akr_utils.add_cfg_float(updates, "cpm_speed_to_pf_rad_s", values.get("speed_pf"))
        akr_utils.add_cfg_float(updates, "cpm_block_tq_nm", values.get("block_tq"))
        akr_utils.add_cfg_float(updates, "cpm_wait_to_df_ms", values.get("wait_df_ms"))
        akr_utils.add_cfg_float(updates, "cpm_wait_to_pf_ms", values.get("wait_pf_ms"))
    elif section == "assist":
        akr_utils.add_cfg_float(updates, "df_assist_pct", values.get("df_pct"))
        akr_utils.add_cfg_float(updates, "pf_assist_pct", values.get("pf_pct"))
    elif "side" in values:
        side_raw = str(values.get("side", "")).strip().lower()
        if side_raw in {"l", "left", "1", "true", "yes"}:
            updates["side_is_left"] = 1.0
        elif side_raw in {"r", "right", "0", "false", "no"}:
            updates["side_is_left"] = 0.0

    gait_raw = values.get("gait_model")
    if gait_raw is None and "model" in values:
        gait_raw = values.get("model")
    gait_val = akr_utils.parse_gait_model(gait_raw)
    if gait_val is not None:
        updates["gait_model"] = gait_val

    gait_mode_raw = values.get("gait_mode")
    if gait_mode_raw is None and "terrain" in values:
        gait_mode_raw = values.get("terrain")
    if gait_mode_raw is None and "walk_mode" in values:
        gait_mode_raw = values.get("walk_mode")
    gait_mode_val = akr_utils.parse_gait_mode(gait_mode_raw)
    if gait_mode_val is not None:
        updates["gait_mode"] = gait_mode_val

    if updates:
        _append_cfg_snapshot(manager, address, dev, updates)


def handle_rx_text_bytes(manager: AkrStreamHost, address: str, data: bytes) -> None:
    try:
        chunk = bytes(data).decode("utf-8", errors="replace")
    except Exception:
        chunk = ""
    if not chunk:
        return
    chunk = chunk.replace("\r\n", "\n").replace("\r", "\n")
    buf = manager._akr_rx_buf.get(address, "")
    buf += chunk
    lines = buf.split("\n")
    for line in lines[:-1]:
        emit_text_line(manager, address, line)
    rem = lines[-1]
    if rem.strip() == ">":
        manager._emit_akr_line(address, ">")
        rem = ""
    elif rem.startswith("> "):
        manager._emit_akr_line(address, ">")
        rem = rem[2:]
    manager._akr_rx_buf[address] = rem


def _crc16_ccitt_false(data: bytes, *, init: int = 0xFFFF) -> int:
    crc = int(init) & 0xFFFF
    for b in data:
        crc ^= (int(b) & 0xFF) << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
    return crc & 0xFFFF


def parse_telem_frames(manager: AkrStreamHost, address: str) -> None:
    dev = manager.devices.get(address)
    if not dev:
        return
    enabled = bool(getattr(dev, "is_streaming", False))
    buf = manager._akr_rx_bin.setdefault(address, bytearray())
    if not buf:
        return

    sync = b"\xA5\x5A"
    ver = 0x01
    type_walk = 0x01
    type_cpm = 0x02
    type_test = 0x03
    type_cfg = 0x04

    rad_scale = 1000.0
    rad_s_scale = 1000.0
    nm_scale = 1000.0
    temp_c_scale = 10.0
    imu_scale = 100.0
    vbus_v_scale = 100.0

    # Mixed-stream decode flow:
    # 1) resync on binary frame header (A5 5A) and CRC-validate payload,
    # 2) treat non-frame bytes as UTF-8 CLI text chunks,
    # 3) decode packet by type into AKR buffers and shared IMU buffers.
    while True:
        i = buf.find(sync)
        if i < 0:
            if buf and buf[-1] == sync[0]:
                prefix = bytes(buf[:-1])
                if prefix:
                    handle_rx_text_bytes(manager, address, prefix)
                buf[:] = bytearray([sync[0]])
                return
            if buf:
                handle_rx_text_bytes(manager, address, bytes(buf))
                buf.clear()
            return
        if i > 0:
            prefix = bytes(buf[:i])
            del buf[:i]
            if prefix:
                handle_rx_text_bytes(manager, address, prefix)
            continue
        if len(buf) < 5:
            return

        got_ver = int(buf[2])
        pkt_type = int(buf[3])
        payload_len = int(buf[4])
        if got_ver != ver:
            del buf[:1]
            continue
        frame_len = 5 + payload_len + 2
        if len(buf) < frame_len:
            return

        frame = bytes(buf[:frame_len])
        crc_expect = int(struct.unpack_from("<H", frame, 5 + payload_len)[0])
        crc_got = _crc16_ccitt_false(frame[2 : 5 + payload_len])
        if crc_got != crc_expect:
            del buf[:1]
            continue

        payload = frame[5 : 5 + payload_len]
        del buf[:frame_len]

        if (not enabled) and (pkt_type != type_cfg):
            continue

        now = time.monotonic()
        if dev.akr.akr_origin_monotonic_s is None:
            dev.akr.akr_origin_monotonic_s = float(now)
        t_rel = float(now) - float(dev.akr.akr_origin_monotonic_s or now)

        try:
            if pkt_type == type_walk:
                fmt = "<IHHbb" + ("h" * 14) + "bBH" + "h"
                if struct.calcsize(fmt) != payload_len:
                    continue
                (
                    fid,
                    dt_ms,
                    exec_ms,
                    out_v,
                    state_v,
                    accx,
                    accy,
                    accz,
                    gyrx,
                    gyry,
                    gyrz,
                    magx,
                    magy,
                    magz,
                    tilt_forward_i,
                    pos_i,
                    vel_i,
                    tq_i,
                    temp_i,
                    pattern,
                    err_code,
                    fb_age_ms,
                    vbus_i,
                ) = struct.unpack_from(fmt, payload, 0)
                acc = [float(accx) / imu_scale, float(accy) / imu_scale, float(accz) / imu_scale]
                gyr = [float(gyrx) / imu_scale, float(gyry) / imu_scale, float(gyrz) / imu_scale]
                mag = [float(magx) / imu_scale, float(magy) / imu_scale, float(magz) / imu_scale]
                dev.akr.akr_walk_fid_buffer.append((t_rel, [float(fid)]))
                dev.akr.akr_walk_dt_ms_buffer.append((t_rel, [float(dt_ms)]))
                dev.akr.akr_walk_exec_ms_buffer.append((t_rel, [float(exec_ms)]))
                dev.akr.akr_walk_out_buffer.append((t_rel, [float(out_v)]))
                dev.akr.akr_walk_state_buffer.append((t_rel, [float(state_v)]))
                dev.akr.akr_walk_acc_buffer.append((t_rel, list(acc)))
                dev.akr.akr_walk_gyr_buffer.append((t_rel, list(gyr)))
                dev.akr.akr_walk_mag_buffer.append((t_rel, list(mag)))
                dev.akr.akr_walk_tilt_forward_deg_buffer.append((t_rel, [float(tilt_forward_i) / imu_scale]))
                dev.akr.akr_walk_pos_rad_buffer.append((t_rel, [float(pos_i) / rad_scale]))
                dev.akr.akr_walk_vel_rad_s_buffer.append((t_rel, [float(vel_i) / rad_s_scale]))
                dev.akr.akr_walk_tq_nm_buffer.append((t_rel, [float(tq_i) / nm_scale]))
                dev.akr.akr_walk_temp_c_buffer.append((t_rel, [float(temp_i) / temp_c_scale]))
                dev.akr.akr_walk_vbus_v_buffer.append((t_rel, [float(vbus_i) / vbus_v_scale]))
                dev.akr.akr_walk_pattern_buffer.append((t_rel, [float(pattern)]))
                dev.akr.akr_walk_err_code_buffer.append((t_rel, [float(err_code)]))
                dev.akr.akr_walk_fb_age_ms_buffer.append((t_rel, [float(fb_age_ms)]))
                dev.acc_buffer.append((t_rel, list(acc)))
                dev.gyr_buffer.append((t_rel, list(gyr)))
                dev.mag_buffer.append((t_rel, list(mag)))
                dev.last_imu_time_s = float(now)
                dev.imu_frames_total += 1
            elif pkt_type == type_cpm:
                fmt = "<IHBbBBB" + ("h" * 5) + "bBH" + "hh" + "ffBf" + "h"
                if struct.calcsize(fmt) != payload_len:
                    continue
                (
                    fid,
                    dt_ms,
                    cpm_state,
                    dir_v,
                    blocked_event,
                    block_reason,
                    blocked_consecutive,
                    cmd_i,
                    pos_i,
                    vel_i,
                    tq_i,
                    temp_i,
                    pattern,
                    err_code,
                    fb_age_ms,
                    df_lim_i,
                    pf_lim_i,
                    elapsed_s,
                    remaining_s,
                    has_remaining,
                    repetition_count,
                    vbus_i,
                ) = struct.unpack_from(fmt, payload, 0)
                remaining_s_value = float(remaining_s) if int(has_remaining) != 0 else math.nan
                dev.akr.akr_cpm_fid_buffer.append((t_rel, [float(fid)]))
                dev.akr.akr_cpm_dt_ms_buffer.append((t_rel, [float(dt_ms)]))
                dev.akr.akr_cpm_state_buffer.append((t_rel, [float(cpm_state)]))
                dev.akr.akr_cpm_dir_buffer.append((t_rel, [float(dir_v)]))
                dev.akr.akr_cpm_blocked_event_buffer.append((t_rel, [float(blocked_event)]))
                dev.akr.akr_cpm_block_reason_buffer.append((t_rel, [float(block_reason)]))
                dev.akr.akr_cpm_blocked_consecutive_buffer.append((t_rel, [float(blocked_consecutive)]))
                dev.akr.akr_cpm_cmd_spd_rad_s_buffer.append((t_rel, [float(cmd_i) / rad_s_scale]))
                dev.akr.akr_cpm_pos_rad_buffer.append((t_rel, [float(pos_i) / rad_scale]))
                dev.akr.akr_cpm_vel_rad_s_buffer.append((t_rel, [float(vel_i) / rad_s_scale]))
                dev.akr.akr_cpm_tq_nm_buffer.append((t_rel, [float(tq_i) / nm_scale]))
                dev.akr.akr_cpm_temp_c_buffer.append((t_rel, [float(temp_i) / temp_c_scale]))
                dev.akr.akr_cpm_vbus_v_buffer.append((t_rel, [float(vbus_i) / vbus_v_scale]))
                dev.akr.akr_cpm_pattern_buffer.append((t_rel, [float(pattern)]))
                dev.akr.akr_cpm_err_code_buffer.append((t_rel, [float(err_code)]))
                dev.akr.akr_cpm_fb_age_ms_buffer.append((t_rel, [float(fb_age_ms)]))
                dev.akr.akr_cpm_df_limit_rad_buffer.append((t_rel, [float(df_lim_i) / rad_scale]))
                dev.akr.akr_cpm_pf_limit_rad_buffer.append((t_rel, [float(pf_lim_i) / rad_scale]))
                dev.akr.akr_cpm_elapsed_s_buffer.append((t_rel, [float(elapsed_s)]))
                dev.akr.akr_cpm_remaining_s_buffer.append((t_rel, [remaining_s_value]))
                dev.akr.akr_cpm_has_remaining_buffer.append((t_rel, [float(1.0 if int(has_remaining) != 0 else 0.0)]))
                dev.akr.akr_cpm_repetition_count_buffer.append((t_rel, [float(repetition_count)]))
                dev.last_imu_time_s = float(now)
                dev.imu_frames_total += 1
            elif pkt_type == type_test:
                fmt = "<IHBbBB" + ("h" * 4) + "bBH" + ("h" * 4) + "h"
                if struct.calcsize(fmt) != payload_len:
                    continue
                (
                    fid,
                    dt_ms,
                    test_state,
                    dir_v,
                    blocked,
                    result_flags,
                    pos_i,
                    vel_i,
                    tq_i,
                    temp_i,
                    pattern,
                    err_code,
                    fb_age_ms,
                    prom_df_i,
                    prom_pf_i,
                    arom_df_i,
                    arom_pf_i,
                    vbus_i,
                ) = struct.unpack_from(fmt, payload, 0)
                flags = int(result_flags)
                dev.akr.akr_test_fid_buffer.append((t_rel, [float(fid)]))
                dev.akr.akr_test_dt_ms_buffer.append((t_rel, [float(dt_ms)]))
                dev.akr.akr_test_state_buffer.append((t_rel, [float(test_state)]))
                dev.akr.akr_test_dir_buffer.append((t_rel, [float(dir_v)]))
                dev.akr.akr_test_blocked_buffer.append((t_rel, [float(blocked)]))
                dev.akr.akr_test_result_flags_buffer.append((t_rel, [float(flags)]))
                dev.akr.akr_test_pos_rad_buffer.append((t_rel, [float(pos_i) / rad_scale]))
                dev.akr.akr_test_vel_rad_s_buffer.append((t_rel, [float(vel_i) / rad_s_scale]))
                dev.akr.akr_test_tq_nm_buffer.append((t_rel, [float(tq_i) / nm_scale]))
                dev.akr.akr_test_temp_c_buffer.append((t_rel, [float(temp_i) / temp_c_scale]))
                dev.akr.akr_test_vbus_v_buffer.append((t_rel, [float(vbus_i) / vbus_v_scale]))
                dev.akr.akr_test_pattern_buffer.append((t_rel, [float(pattern)]))
                dev.akr.akr_test_err_code_buffer.append((t_rel, [float(err_code)]))
                dev.akr.akr_test_fb_age_ms_buffer.append((t_rel, [float(fb_age_ms)]))
                dev.akr.akr_test_prom_df_end_rad_buffer.append((t_rel, [float(prom_df_i) / rad_scale]))
                dev.akr.akr_test_prom_pf_end_rad_buffer.append((t_rel, [float(prom_pf_i) / rad_scale]))
                dev.akr.akr_test_arom_df_max_rad_buffer.append((t_rel, [float(arom_df_i) / rad_scale]))
                dev.akr.akr_test_arom_pf_min_rad_buffer.append((t_rel, [float(arom_pf_i) / rad_scale]))
                dev.akr.akr_test_flag_prom_df_valid_buffer.append((t_rel, [1.0 if (flags & (1 << 0)) else 0.0]))
                dev.akr.akr_test_flag_prom_pf_valid_buffer.append((t_rel, [1.0 if (flags & (1 << 1)) else 0.0]))
                dev.akr.akr_test_flag_arom_valid_buffer.append((t_rel, [1.0 if (flags & (1 << 2)) else 0.0]))
                dev.akr.akr_test_flag_seq_active_buffer.append((t_rel, [1.0 if (flags & (1 << 3)) else 0.0]))
                dev.akr.akr_test_flag_arom_running_buffer.append((t_rel, [1.0 if (flags & (1 << 4)) else 0.0]))
                dev.last_imu_time_s = float(now)
                dev.imu_frames_total += 1
            elif pkt_type == type_cfg:
                fmt = "<IBBBBB" + ("h" * 10) + ("h" * 5) + "HH"
                if struct.calcsize(fmt) != payload_len:
                    continue
                (
                    fid,
                    gait_model,
                    gait_mode,
                    side_is_left,
                    df_assist_pct,
                    pf_assist_pct,
                    df_torque_i,
                    df_angle_i,
                    df_speed_i,
                    df_kp_i,
                    df_kd_i,
                    pf_torque_i,
                    pf_angle_i,
                    pf_speed_i,
                    pf_kp_i,
                    pf_kd_i,
                    cpm_target_df_i,
                    cpm_target_pf_i,
                    cpm_speed_df_i,
                    cpm_speed_pf_i,
                    cpm_block_tq_i,
                    cpm_wait_df_ms,
                    cpm_wait_pf_ms,
                ) = struct.unpack_from(fmt, payload, 0)
                dev.akr.akr_cfg_fid_buffer.append((t_rel, [float(fid)]))
                dev.akr.akr_cfg_gait_model_buffer.append((t_rel, [float(gait_model)]))
                dev.akr.akr_cfg_gait_mode_buffer.append((t_rel, [float(gait_mode)]))
                dev.akr.akr_cfg_side_is_left_buffer.append((t_rel, [1.0 if int(side_is_left) != 0 else 0.0]))
                dev.akr.akr_cfg_df_assist_pct_buffer.append((t_rel, [float(df_assist_pct)]))
                dev.akr.akr_cfg_pf_assist_pct_buffer.append((t_rel, [float(pf_assist_pct)]))
                dev.akr.akr_cfg_df_torque_buffer.append((t_rel, [float(df_torque_i) / nm_scale]))
                dev.akr.akr_cfg_df_angle_buffer.append((t_rel, [float(df_angle_i) / rad_scale]))
                dev.akr.akr_cfg_df_speed_buffer.append((t_rel, [float(df_speed_i) / rad_s_scale]))
                dev.akr.akr_cfg_df_kp_buffer.append((t_rel, [float(df_kp_i) / 100.0]))
                dev.akr.akr_cfg_df_kd_buffer.append((t_rel, [float(df_kd_i) / 100.0]))
                dev.akr.akr_cfg_pf_torque_buffer.append((t_rel, [float(pf_torque_i) / nm_scale]))
                dev.akr.akr_cfg_pf_angle_buffer.append((t_rel, [float(pf_angle_i) / rad_scale]))
                dev.akr.akr_cfg_pf_speed_buffer.append((t_rel, [float(pf_speed_i) / rad_s_scale]))
                dev.akr.akr_cfg_pf_kp_buffer.append((t_rel, [float(pf_kp_i) / 100.0]))
                dev.akr.akr_cfg_pf_kd_buffer.append((t_rel, [float(pf_kd_i) / 100.0]))
                dev.akr.akr_cfg_cpm_target_df_rad_buffer.append((t_rel, [float(cpm_target_df_i) / rad_scale]))
                dev.akr.akr_cfg_cpm_target_pf_rad_buffer.append((t_rel, [float(cpm_target_pf_i) / rad_scale]))
                dev.akr.akr_cfg_cpm_speed_to_df_rad_s_buffer.append((t_rel, [float(cpm_speed_df_i) / rad_s_scale]))
                dev.akr.akr_cfg_cpm_speed_to_pf_rad_s_buffer.append((t_rel, [float(cpm_speed_pf_i) / rad_s_scale]))
                dev.akr.akr_cfg_cpm_block_tq_nm_buffer.append((t_rel, [float(cpm_block_tq_i) / nm_scale]))
                dev.akr.akr_cfg_cpm_wait_to_df_ms_buffer.append((t_rel, [float(cpm_wait_df_ms)]))
                dev.akr.akr_cfg_cpm_wait_to_pf_ms_buffer.append((t_rel, [float(cpm_wait_pf_ms)]))
                dev.last_imu_time_s = float(now)
                dev.imu_frames_total += 1
            else:
                continue
        except Exception:
            continue


def handle_rx_bytes(manager: AkrStreamHost, address: str, data: bytes) -> None:
    if not data:
        return
    buf = manager._akr_rx_bin.setdefault(address, bytearray())
    buf.extend(bytes(data))
    parse_telem_frames(manager, address)


def maybe_parse_rr_akr_line(manager: AkrStreamHost, address: str, line: str) -> None:
    dev = manager.devices.get(address)
    if not dev:
        return
    if not bool(getattr(dev, "is_streaming", False)):
        return
    s = str(line)
    if "RR_AKR" not in s:
        return
    m = akr_utils.RR_AKR_LINE_RE.search(s)
    if not m:
        return
    try:
        step_dt = float(int(m.group("step_dt")))
        exec_ms = float(int(m.group("exec")))
        out_v = float(int(m.group("out")))
        state_v = float(int(m.group("state")))
        acc = [float(m.group("accx")), float(m.group("accy")), float(m.group("accz"))]
        gyr = [float(m.group("gyrx")), float(m.group("gyry")), float(m.group("gyrz"))]
        mag = [float(m.group("magx")), float(m.group("magy")), float(m.group("magz"))]
    except Exception:
        return

    now = time.monotonic()
    if dev.akr.akr_origin_monotonic_s is None:
        dev.akr.akr_origin_monotonic_s = float(now)
    t_rel = float(now) - float(dev.akr.akr_origin_monotonic_s or now)
    try:
        dev.akr.akr_step_dt_ms_buffer.append((t_rel, [float(step_dt)]))
        dev.akr.akr_exec_ms_buffer.append((t_rel, [float(exec_ms)]))
        dev.akr.akr_out_buffer.append((t_rel, [float(out_v)]))
        dev.akr.akr_state_buffer.append((t_rel, [float(state_v)]))
    except Exception:
        pass
    try:
        dev.acc_buffer.append((t_rel, list(acc)))
        dev.gyr_buffer.append((t_rel, list(gyr)))
        dev.mag_buffer.append((t_rel, list(mag)))
    except Exception:
        pass
    dev.last_imu_time_s = time.monotonic()
    dev.imu_frames_total += 1

