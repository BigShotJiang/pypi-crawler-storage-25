from __future__ import annotations

import math
import re
import time


RR_AKR_LINE_RE = re.compile(
    r"RR_AKR\s+"
    r".*?step_dt=(?P<step_dt>-?\d+)\s*ms"
    r".*?exec=(?P<exec>-?\d+)\s*ms"
    r".*?out=(?P<out>-?\d+)"
    r".*?state=(?P<state>-?\d+)"
    r".*?acc=\[(?P<accx>[+\-0-9.]+)\s+(?P<accy>[+\-0-9.]+)\s+(?P<accz>[+\-0-9.]+)\]"
    r".*?gyr=\[(?P<gyrx>[+\-0-9.]+)\s+(?P<gyry>[+\-0-9.]+)\s+(?P<gyrz>[+\-0-9.]+)\]"
    r".*?mag=\[(?P<magx>[+\-0-9.]+)\s+(?P<magy>[+\-0-9.]+)\s+(?P<magz>[+\-0-9.]+)\]"
)

AKR_GAIT_MODEL_NAME_TO_CODE: dict[str, float] = {
    "base": 0.0,
    "update": 1.0,
    "model_test": 2.0,
    "test": 2.0,
}

AKR_GAIT_MODE_NAME_TO_CODE: dict[str, float] = {
    "stair_down": 0.0,
    "down": 0.0,
    "level": 1.0,
    "walk_level": 1.0,
    "stair_up": 2.0,
    "up": 2.0,
}


def normalize_cli_line(line: str) -> str:
    return " ".join(str(line).replace("\x00", "").strip().lower().split())


def extract_kv_pairs(text: str) -> dict[str, str]:
    pairs: dict[str, str] = {}
    for m in re.finditer(r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([^\s,\)\]]+)", str(text)):
        key = str(m.group(1) or "").strip().lower()
        val = str(m.group(2) or "").strip()
        if key:
            pairs[key] = val
    return pairs


def parse_float(raw: object) -> float | None:
    if raw is None:
        return None
    try:
        return float(str(raw).strip())
    except Exception:
        return None


def parse_gait_model(raw: object) -> float | None:
    token = str(raw or "").strip().lower()
    if not token:
        return None
    mapped = AKR_GAIT_MODEL_NAME_TO_CODE.get(token)
    if mapped is not None:
        return float(mapped)
    return parse_float(token)


def parse_gait_mode(raw: object) -> float | None:
    token = str(raw or "").strip().lower()
    if not token:
        return None
    mapped = AKR_GAIT_MODE_NAME_TO_CODE.get(token)
    if mapped is not None:
        return float(mapped)
    return parse_float(token)


def decode_robot_id_token(raw: object, *, dash_is_empty: bool) -> str:
    token = str(raw or "").strip()
    if not token:
        return ""
    t_low = token.lower()
    if t_low in {"<empty>", "empty"}:
        return ""
    if dash_is_empty and token == "-":
        return ""
    return token.upper()


def add_cfg_float(updates: dict[str, float], key: str, raw: object, *, radians: bool = False) -> None:
    val = raw if isinstance(raw, float) else parse_float(raw)
    if val is None:
        return
    if radians:
        val = float(math.radians(val))
    updates[str(key)] = float(val)


def cfg_last_value(buf: object, default: float = 0.0) -> float:
    try:
        if not buf:
            return float(default)
        _t, values = buf[-1]
        if values:
            return float(values[0])
    except Exception:
        pass
    return float(default)


def update_robot_identity(dev: object, *, robot_id: str | None, ble_target: str | None) -> bool:
    akr = getattr(dev, "akr", dev)
    changed = False
    if robot_id is not None:
        rid_new = str(robot_id).strip().upper()
        if str(getattr(akr, "akr_robot_id", "")) != rid_new:
            setattr(akr, "akr_robot_id", rid_new)
            changed = True
    else:
        rid_new = str(getattr(akr, "akr_robot_id", "")).strip().upper()

    ble_new = str(ble_target or "").strip()
    if not ble_new:
        ble_new = f"AKR_{rid_new}" if rid_new else "AKR"
    if str(getattr(akr, "akr_ble_target_name", "")) != ble_new:
        setattr(akr, "akr_ble_target_name", ble_new)
        changed = True

    if not bool(getattr(akr, "akr_robot_identity_seen", False)):
        setattr(akr, "akr_robot_identity_seen", True)
        changed = True
    return changed


def append_cfg_snapshot(dev: object, updates: dict[str, float], *, cfg_fid: int) -> int:
    akr = getattr(dev, "akr", dev)
    now = time.monotonic()
    if getattr(akr, "akr_origin_monotonic_s", None) is None:
        setattr(akr, "akr_origin_monotonic_s", float(now))
    t_rel = float(now) - float(getattr(akr, "akr_origin_monotonic_s", now) or now)

    state: dict[str, float] = {
        "gait_model": cfg_last_value(getattr(akr, "akr_cfg_gait_model_buffer"), 0.0),
        "gait_mode": cfg_last_value(getattr(akr, "akr_cfg_gait_mode_buffer"), 1.0),
        "side_is_left": cfg_last_value(getattr(akr, "akr_cfg_side_is_left_buffer"), 0.0),
        "df_assist_pct": cfg_last_value(getattr(akr, "akr_cfg_df_assist_pct_buffer"), 100.0),
        "pf_assist_pct": cfg_last_value(getattr(akr, "akr_cfg_pf_assist_pct_buffer"), 100.0),
        "df_torque": cfg_last_value(getattr(akr, "akr_cfg_df_torque_buffer"), 0.0),
        "df_angle": cfg_last_value(getattr(akr, "akr_cfg_df_angle_buffer"), 0.0),
        "df_speed": cfg_last_value(getattr(akr, "akr_cfg_df_speed_buffer"), 0.0),
        "df_kp": cfg_last_value(getattr(akr, "akr_cfg_df_kp_buffer"), 0.0),
        "df_kd": cfg_last_value(getattr(akr, "akr_cfg_df_kd_buffer"), 0.0),
        "pf_torque": cfg_last_value(getattr(akr, "akr_cfg_pf_torque_buffer"), 0.0),
        "pf_angle": cfg_last_value(getattr(akr, "akr_cfg_pf_angle_buffer"), 0.0),
        "pf_speed": cfg_last_value(getattr(akr, "akr_cfg_pf_speed_buffer"), 0.0),
        "pf_kp": cfg_last_value(getattr(akr, "akr_cfg_pf_kp_buffer"), 0.0),
        "pf_kd": cfg_last_value(getattr(akr, "akr_cfg_pf_kd_buffer"), 0.0),
        "cpm_target_df_rad": cfg_last_value(getattr(akr, "akr_cfg_cpm_target_df_rad_buffer"), 0.0),
        "cpm_target_pf_rad": cfg_last_value(getattr(akr, "akr_cfg_cpm_target_pf_rad_buffer"), 0.0),
        "cpm_speed_to_df_rad_s": cfg_last_value(getattr(akr, "akr_cfg_cpm_speed_to_df_rad_s_buffer"), 0.0),
        "cpm_speed_to_pf_rad_s": cfg_last_value(getattr(akr, "akr_cfg_cpm_speed_to_pf_rad_s_buffer"), 0.0),
        "cpm_block_tq_nm": cfg_last_value(getattr(akr, "akr_cfg_cpm_block_tq_nm_buffer"), 0.0),
        "cpm_wait_to_df_ms": cfg_last_value(getattr(akr, "akr_cfg_cpm_wait_to_df_ms_buffer"), 0.0),
        "cpm_wait_to_pf_ms": cfg_last_value(getattr(akr, "akr_cfg_cpm_wait_to_pf_ms_buffer"), 0.0),
    }
    state.update(updates)

    getattr(akr, "akr_cfg_fid_buffer").append((t_rel, [float(cfg_fid)]))
    getattr(akr, "akr_cfg_gait_model_buffer").append((t_rel, [float(state["gait_model"])]))
    getattr(akr, "akr_cfg_gait_mode_buffer").append((t_rel, [float(state["gait_mode"])]))
    getattr(akr, "akr_cfg_side_is_left_buffer").append((t_rel, [float(state["side_is_left"])]))
    getattr(akr, "akr_cfg_df_assist_pct_buffer").append((t_rel, [float(state["df_assist_pct"])]))
    getattr(akr, "akr_cfg_pf_assist_pct_buffer").append((t_rel, [float(state["pf_assist_pct"])]))
    getattr(akr, "akr_cfg_df_torque_buffer").append((t_rel, [float(state["df_torque"])]))
    getattr(akr, "akr_cfg_df_angle_buffer").append((t_rel, [float(state["df_angle"])]))
    getattr(akr, "akr_cfg_df_speed_buffer").append((t_rel, [float(state["df_speed"])]))
    getattr(akr, "akr_cfg_df_kp_buffer").append((t_rel, [float(state["df_kp"])]))
    getattr(akr, "akr_cfg_df_kd_buffer").append((t_rel, [float(state["df_kd"])]))
    getattr(akr, "akr_cfg_pf_torque_buffer").append((t_rel, [float(state["pf_torque"])]))
    getattr(akr, "akr_cfg_pf_angle_buffer").append((t_rel, [float(state["pf_angle"])]))
    getattr(akr, "akr_cfg_pf_speed_buffer").append((t_rel, [float(state["pf_speed"])]))
    getattr(akr, "akr_cfg_pf_kp_buffer").append((t_rel, [float(state["pf_kp"])]))
    getattr(akr, "akr_cfg_pf_kd_buffer").append((t_rel, [float(state["pf_kd"])]))
    getattr(akr, "akr_cfg_cpm_target_df_rad_buffer").append((t_rel, [float(state["cpm_target_df_rad"])]))
    getattr(akr, "akr_cfg_cpm_target_pf_rad_buffer").append((t_rel, [float(state["cpm_target_pf_rad"])]))
    getattr(akr, "akr_cfg_cpm_speed_to_df_rad_s_buffer").append((t_rel, [float(state["cpm_speed_to_df_rad_s"])]))
    getattr(akr, "akr_cfg_cpm_speed_to_pf_rad_s_buffer").append((t_rel, [float(state["cpm_speed_to_pf_rad_s"])]))
    getattr(akr, "akr_cfg_cpm_block_tq_nm_buffer").append((t_rel, [float(state["cpm_block_tq_nm"])]))
    getattr(akr, "akr_cfg_cpm_wait_to_df_ms_buffer").append((t_rel, [float(state["cpm_wait_to_df_ms"])]))
    getattr(akr, "akr_cfg_cpm_wait_to_pf_ms_buffer").append((t_rel, [float(state["cpm_wait_to_pf_ms"])]))

    setattr(dev, "last_imu_time_s", float(now))
    setattr(dev, "imu_frames_total", int(getattr(dev, "imu_frames_total", 0)) + 1)
    return int(cfg_fid) + 1

