from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from .base import DEVICE_KIND_AKR, DEVICE_KIND_EMGS

if TYPE_CHECKING:
    from ...ble.manager import DeviceSessionManager
    from ..emgs.state import DeviceState


class SessionOrchestrator(ABC):
    """Session-scoped orchestration for one device kind."""

    kind: str

    def on_device_connected(self, manager: DeviceSessionManager, address: str, dev: DeviceState) -> None:
        _ = manager
        _ = address
        _ = dev

    @abstractmethod
    async def stream_one(self, manager: DeviceSessionManager, address: str, dev: DeviceState, enable: bool) -> bool:
        """Handle stream toggle for this kind. Return True when handled."""
        raise NotImplementedError


class EmgsSessionOrchestrator(SessionOrchestrator):
    kind = DEVICE_KIND_EMGS

    async def stream_one(self, manager: DeviceSessionManager, address: str, dev: DeviceState, enable: bool) -> bool:
        if not manager.backend.is_connected(address):
            return True
        await manager._stream_one_emgs(address, dev, enable=bool(enable))
        return True


class AkrSessionOrchestrator(SessionOrchestrator):
    kind = DEVICE_KIND_AKR

    def on_device_connected(self, manager: DeviceSessionManager, address: str, dev: DeviceState) -> None:
        _ = manager
        _ = address
        dev.is_streaming = True

    async def stream_one(self, manager: DeviceSessionManager, address: str, dev: DeviceState, enable: bool) -> bool:
        if not manager.backend.is_connected(address):
            return True
        # AKR streams immediately after connect; stream toggle is local UX state only.
        dev.is_streaming = bool(enable)
        if enable:
            manager._reset_akr_stream_state(address, dev)
        manager._notify_updated(address)
        return True


def create_session_orchestrator(kind: str) -> SessionOrchestrator:
    value = str(kind or DEVICE_KIND_EMGS).strip().upper()
    if value == DEVICE_KIND_AKR:
        return AkrSessionOrchestrator()
    return EmgsSessionOrchestrator()

