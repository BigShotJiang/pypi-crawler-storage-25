from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(slots=True)
class DeviceParams:
    name: str = "/"
    address: str = "/"
    # Device kind is used to route BLE/protocol behavior through handlers.
    kind: str = "EMGS"
    status: str = "Disconnected"
    timestamp: str = "/"
    battery: str = "/"
    mode: str = "/"
    firmware: str = "/"
    hardware: str = "/"
    dsp: str = "/"
    conn_interval: str = "/"


@dataclass(slots=True)
class BaseDeviceState:
    params: DeviceParams
    is_connected: bool = False
    is_streaming: bool = False
    is_charging: bool = False
    # Connection health: updated on any RX notify packet.
    last_rx_monotonic_s: Optional[float] = None

    def mark_unstable(self) -> None:
        if self.is_connected:
            self.params.status = "Unstable"

    def set_connected(self, connected: bool) -> None:
        self.is_connected = connected
        self.params.status = "Connected" if connected else "Disconnected"

