from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from .base import DEVICE_KIND_AKR, DEVICE_KIND_EMGS

if TYPE_CHECKING:
    from ...ble.manager import DeviceSessionManager
    from ..emgs.state import DeviceState


class BaseSessionManager(ABC):
    kind: str

    @abstractmethod
    async def connect_one(self, manager: DeviceSessionManager, address: str, dev: DeviceState) -> None:
        raise NotImplementedError

    @abstractmethod
    async def stream_one(self, manager: DeviceSessionManager, address: str, dev: DeviceState, enable: bool) -> None:
        raise NotImplementedError

    async def send_ota_frames(
        self,
        manager: DeviceSessionManager,
        address: str,
        file_path: str,
        *,
        ack_timeout_ms: int,
        retries: int,
        inter_frame_ms: int,
        write_chunk_size: int,
        write_with_response: bool,
    ) -> object:
        raise NotImplementedError(f"OTA is not supported for session kind: {self.kind}")


def create_session_manager(kind: str) -> BaseSessionManager:
    value = str(kind or DEVICE_KIND_EMGS).strip().upper()
    if value == DEVICE_KIND_AKR:
        from ..akr.manager import AkrSessionManager

        return AkrSessionManager()
    from ..emgs.manager import EmgsSessionManager

    return EmgsSessionManager()

