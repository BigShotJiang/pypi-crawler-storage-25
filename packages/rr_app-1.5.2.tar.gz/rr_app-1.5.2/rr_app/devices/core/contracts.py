from __future__ import annotations

import asyncio
from typing import Callable, Protocol, TYPE_CHECKING

if TYPE_CHECKING:
    from ...devices.akr.ble.ota_transfer import OtaProgress
    from ...devices.emgs.state import DeviceState


class AkrHandlerHost(Protocol):
    backend: object
    _ui_last_emit_s: dict[str, float]

    def _on_notify(self, address: str, data: bytes) -> None:
        ...

    def _on_disconnect(self, address: str) -> None:
        ...

    def _log(self, msg: str) -> None:
        ...

    def _emit_akr_line(self, addr: str, line: str) -> None:
        ...

    def _notify_updated(self, addr: str) -> None:
        ...

    def _akr_feed_ota_ack_bytes(self, address: str, data: bytes) -> None:
        ...


class AkrStreamHost(Protocol):
    devices: dict[str, DeviceState]
    _akr_cli_cfg_fid: dict[str, int]
    _akr_rx_buf: dict[str, str]
    _akr_rx_bin: dict[str, bytearray]

    def _emit_akr_line(self, addr: str, line: str) -> None:
        ...

    def _notify_updated(self, addr: str) -> None:
        ...

    def _akr_feed_ota_line(self, address: str, line: str) -> None:
        ...


class AkrOtaSessionHost(Protocol):
    def _akr_get_ota_line_queue(self, address: str) -> asyncio.Queue[str]:
        ...

    def _akr_clear_ota_ack_queue(self, address: str) -> None:
        ...

    def _akr_clear_ota_line_queue(self, address: str) -> None:
        ...

    async def akr_send_line(self, address: str, line: str) -> None:
        ...

    def _log(self, msg: str) -> None:
        ...

    async def _akr_wait_ota_ack(self, address: str, timeout_s: float) -> bytes:
        ...

    def _emit_akr_ota_progress(self, addr: str, progress: OtaProgress) -> None:
        ...

    @property
    def _akr_ota_lock(self) -> dict[str, asyncio.Lock]:
        ...

