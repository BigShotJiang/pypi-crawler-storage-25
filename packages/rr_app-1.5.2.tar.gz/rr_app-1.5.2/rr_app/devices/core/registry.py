from __future__ import annotations

from ... import config
from ..akr.handler import AkrDeviceHandler
from .base import DEVICE_KIND_AKR, DEVICE_KIND_EMGS, DeviceHandler
from ..emgs.handler import EmgsDeviceHandler


_HANDLERS: dict[str, DeviceHandler] = {
    DEVICE_KIND_EMGS: EmgsDeviceHandler(),
    DEVICE_KIND_AKR: AkrDeviceHandler(),
}


def normalize_kind(kind: str | None) -> str:
    value = str(kind or DEVICE_KIND_EMGS).strip().upper()
    if value in _HANDLERS:
        return value
    return DEVICE_KIND_EMGS


def infer_kind_from_name(name: str | None) -> str:
    text = str(name or "")
    if text.startswith(tuple(getattr(config, "AKR_NAME_PREFIXES", ("AKR",)))):
        return DEVICE_KIND_AKR
    return DEVICE_KIND_EMGS


def get_handler(kind: str | None) -> DeviceHandler:
    return _HANDLERS[normalize_kind(kind)]

