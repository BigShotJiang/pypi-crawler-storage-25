from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...ble.manager import DeviceSessionManager
    from ..emgs.state import DeviceState


DEVICE_KIND_EMGS = "EMGS"
DEVICE_KIND_AKR = "AKR"


@dataclass(frozen=True, slots=True)
class DeviceCapabilities:
    supports_stream_toggle: bool
    supports_settings: bool
    supports_ota: bool
    emits_text_lines: bool


class DeviceHandler(ABC):
    kind: str
    capabilities: DeviceCapabilities

    @abstractmethod
    async def connect(self, manager: DeviceSessionManager, address: str, dev: DeviceState) -> None:
        raise NotImplementedError

    @abstractmethod
    async def post_connect(self, manager: DeviceSessionManager, address: str, dev: DeviceState) -> None:
        raise NotImplementedError

    @abstractmethod
    def handle_notify(self, manager: DeviceSessionManager, address: str, dev: DeviceState, data: bytes) -> None:
        raise NotImplementedError

