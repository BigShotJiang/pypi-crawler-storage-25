from __future__ import annotations

import asyncio
import logging
import os
import re
import math
from dataclasses import dataclass, field, fields
from typing import Callable, Optional

from .. import config
from .backend import Backend, DiscoveredDevice
from ..devices.core.state import DeviceParams
from ..devices.emgs.state import DeviceState
from ..devices.emgs.ble import protocol
from ..devices.akr.ble import ota_transfer
from ..devices.core.registry import get_handler, infer_kind_from_name, normalize_kind
from ..devices.core.session_manager import BaseSessionManager, create_session_manager
import struct
import time


logger = logging.getLogger(__name__)

LogFn = Callable[[str], None]
UpdateFn = Callable[[str], None]  # device address updated
AkrLineFn = Callable[[str, str], None]  # (address, line)
OtaProgressFn = Callable[[str, ota_transfer.OtaProgress], None]  # (address, progress)

class SessionKindConflictError(RuntimeError):
    def __init__(
        self,
        *,
        active_kind: str,
        requested_kind: str,
        addresses: list[str],
    ) -> None:
        active = normalize_kind(active_kind)
        requested = normalize_kind(requested_kind)
        addrs = [str(a) for a in addresses]
        super().__init__(
            "Session is locked to one device type per Connect->Disconnect cycle "
            f"(active={active}, requested={requested}, addresses={addrs})"
        )
        self.active_kind = active
        self.requested_kind = requested
        self.addresses = addrs
        self.user_message = (
            "Connect blocked: current session is locked to "
            f"{active}. Disconnect all {active} devices before connecting {requested}."
        )


@dataclass(slots=True)
class DeviceSessionManager:
    backend: Backend
    on_log: Optional[LogFn] = None
    on_device_updated: Optional[UpdateFn] = None
    on_akr_line: Optional[AkrLineFn] = None
    on_akr_ota_progress: Optional[OtaProgressFn] = None

    devices: dict[str, DeviceState] = field(default_factory=dict)

    # Internal state (must be declared because dataclass(slots=True) has no __dict__)
    _shutting_down: bool = False
    _debug_rx: bool = False
    _debug_rx_hex: bool = False
    _debug_cmd: bool = False
    _debug_cmd_hex: bool = False
    _rx_stats: dict[str, dict[str, int]] = field(default_factory=dict)
    _rx_last_log_s: dict[str, float] = field(default_factory=dict)
    _rx_last_hex_s: dict[str, float] = field(default_factory=dict)
    _ui_last_emit_s: dict[str, float] = field(default_factory=dict)
    _last_time_sync_send_ms: dict[str, int] = field(default_factory=dict)
    _last_get_ts_send_ms: dict[str, int] = field(default_factory=dict)
    _akr_rx_buf: dict[str, str] = field(default_factory=dict)  # addr -> partial line buffer
    _akr_rx_bin: dict[str, bytearray] = field(default_factory=dict)  # addr -> binary stream buffer (rr_telem framing)
    _akr_cli_cfg_fid: dict[str, int] = field(default_factory=dict)  # addr -> synthetic cfg fid for CLI-derived snapshots
    _akr_ota_ack_queue: dict[str, asyncio.Queue[bytes]] = field(default_factory=dict)
    _akr_ota_line_queue: dict[str, asyncio.Queue[str]] = field(default_factory=dict)
    _akr_ota_lock: dict[str, asyncio.Lock] = field(default_factory=dict)
    # Host-side processing configuration (applies on next stream start).
    proc_enable_emg_rms_envelope_next: bool = False
    proc_emg_rms_window_n_next: int = config.EMG_RMS_WINDOW_N
    proc_enable_emg_freq_features_next: bool = False
    proc_emg_spec_window_n_next: int = config.EMG_SPEC_WINDOW_N
    proc_enable_emg_fatigue_next: bool = config.EMG_FATIGUE_ENABLE_DEFAULT
    proc_emg_fatigue_baseline_s_next: float = config.EMG_FATIGUE_BASELINE_S
    proc_emg_fatigue_weight_mdf_pct_next: float = config.EMG_FATIGUE_WEIGHT_MDF_PCT
    proc_emg_fatigue_weight_rms_pct_next: float = config.EMG_FATIGUE_WEIGHT_RMS_PCT
    proc_emg_fatigue_conf_recent_n_next: int = config.EMG_FATIGUE_CONF_RECENT_N
    proc_enable_emg_ecg_filter_next: bool = config.EMG_ECG_FILTER_ENABLE_DEFAULT
    proc_emg_ecg_filter_method_next: str = config.EMG_ECG_FILTER_METHOD_DEFAULT
    proc_emg_ecg_hp_cutoff_hz_next: float = config.EMG_ECG_FILTER_HP_CUTOFF_HZ
    proc_emg_ecg_wavelet_levels_next: int = config.EMG_ECG_FILTER_WAVELET_LEVELS
    proc_emg_ecg_wavelet_shrink_next: float = config.EMG_ECG_FILTER_WAVELET_SHRINK
    # Indicator LED UX state (purely for UI affordances like "selected rows").
    _led_state: dict[str, str] = field(default_factory=dict)        # last applied state (e.g. 'purple','off')
    _led_last_ts_s: dict[str, float] = field(default_factory=dict)  # last LED write timestamp (monotonic seconds)
    _led_min_interval_s: float = 0.15                               # minimum seconds between 'purple' writes per device
    _ui_selected_addrs_by_source: dict[str, set[str]] = field(
        default_factory=lambda: {"table": set(), "signals": set(), "identify": set()}
    )
    _led_prev_before_select: dict[str, str] = field(default_factory=dict)  # addr -> prior state before selection override
    _led_override_active: set[str] = field(default_factory=set)            # addr where we've actually applied purple override
    _identify_token: dict[str, float] = field(default_factory=dict)         # addr -> token to cancel stale identify timers
    _selection_led_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    _session_manager: BaseSessionManager | None = None

    def __post_init__(self) -> None:
        # RX diagnostics / UI throttling (env-controlled)
        self._debug_rx = os.environ.get("EMGS_DEBUG_RX", "").strip().lower() in {"1", "true", "yes"}
        self._debug_rx_hex = os.environ.get("EMGS_DEBUG_RX_HEX", "").strip().lower() in {"1", "true", "yes"}
        self._debug_cmd = os.environ.get("EMGS_DEBUG_CMD", "").strip().lower() in {"1", "true", "yes"}
        self._debug_cmd_hex = os.environ.get("EMGS_DEBUG_CMD_HEX", "").strip().lower() in {"1", "true", "yes"}

    def _log(self, msg: str) -> None:
        logger.info("%s", msg)
        if self.on_log:
            self.on_log(msg)

    def _notify_updated(self, addr: str) -> None:
        if self.on_device_updated:
            self.on_device_updated(addr)

    def _clear_akr_connection_state(self, address: str) -> None:
        """Drop AKR transport/parser transient state for this address."""
        self._akr_rx_buf.pop(address, None)
        self._akr_rx_bin.pop(address, None)
        self._akr_cli_cfg_fid.pop(address, None)
        self._akr_ota_ack_queue.pop(address, None)
        self._akr_ota_line_queue.pop(address, None)
        self._akr_ota_lock.pop(address, None)

    def _finalize_device_disconnect(self, address: str, dev: DeviceState, *, reason: str) -> None:
        """Apply consistent local cleanup after any disconnect path."""
        was_active = bool(dev.is_connected or dev.is_streaming or dev.params.status != "Disconnected")
        self._clear_akr_connection_state(address)
        dev.reset()
        self._drop_selection_state_for_address(address)
        self._clear_session_state_if_idle()
        self._notify_updated(address)
        if was_active:
            self._log(f"Disconnect finalized ({reason}): {address}")

    async def _disconnect_backend_best_effort(self, address: str, *, reason: str) -> None:
        try:
            await self.backend.disconnect(address)
        except Exception as e:
            self._log(
                f"Disconnect cleanup warning ({reason}): "
                f"{address}: {type(e).__name__}: {e!r}"
            )

    def _device_kind(self, address: str) -> str:
        dev = self.devices.get(address)
        if not dev:
            return normalize_kind(None)
        kind = normalize_kind(getattr(dev.params, "kind", None))
        dev.params.kind = kind
        return kind

    def _is_emgs_device(self, address: str) -> bool:
        return self._device_kind(address) == "EMGS"

    def _is_akr_device(self, address: str) -> bool:
        return self._device_kind(address) == "AKR"

    def _supports_stream_toggle(self, address: str) -> bool:
        return bool(get_handler(self._device_kind(address)).capabilities.supports_stream_toggle)

    def _supports_settings(self, address: str) -> bool:
        return bool(get_handler(self._device_kind(address)).capabilities.supports_settings)

    def _supports_ota(self, address: str) -> bool:
        return bool(get_handler(self._device_kind(address)).capabilities.supports_ota)

    def kind_of_device(self, dev: object | None) -> str:
        if dev is None:
            return normalize_kind(None)
        try:
            params = getattr(dev, "params", None)
            return normalize_kind(getattr(params, "kind", None))
        except Exception:
            return normalize_kind(None)

    def is_emgs_device_obj(self, dev: object | None) -> bool:
        return self.kind_of_device(dev) == "EMGS"

    def is_akr_device_obj(self, dev: object | None) -> bool:
        return self.kind_of_device(dev) == "AKR"

    def active_session_kind(self) -> str | None:
        """Return current session kind while any devices are connected."""
        if self._session_manager is not None:
            return normalize_kind(getattr(self._session_manager, "kind", None))
        kinds = {
            self.kind_of_device(dev)
            for dev in self.devices.values()
            if bool(getattr(dev, "is_connected", False))
        }
        if not kinds:
            return None
        if len(kinds) == 1:
            return next(iter(kinds))
        # Mixed connected kinds should not occur after policy enforcement.
        return None

    def active_session_orchestrator_kind(self) -> str | None:
        # Compatibility helper for older callers; now sourced from session manager.
        return self.active_session_kind()

    def connect_block_reason_for(self, addresses: list[str]) -> str | None:
        """Return a UI-facing reason when selected addresses violate session policy."""
        normalized_addrs = [str(a) for a in addresses]
        target_kinds = {
            self._device_kind(a)
            for a in normalized_addrs
            if self.devices.get(a) is not None and not bool(self.devices[a].is_connected)
        }
        if not target_kinds:
            return None
        if len(target_kinds) > 1:
            return "Connect blocked: select only one device type per session (AKR or EMGS)."
        requested_kind = next(iter(target_kinds))
        active_kind = self.active_session_kind()
        if active_kind is None:
            return None
        if normalize_kind(active_kind) == normalize_kind(requested_kind):
            return None
        return (
            "Connect blocked: current session is locked to "
            f"{active_kind}. Disconnect all {active_kind} devices before connecting {requested_kind}."
        )

    def _ensure_session_manager(self, kind: str) -> BaseSessionManager:
        normalized = normalize_kind(kind)
        if self._session_manager is None:
            self._session_manager = create_session_manager(normalized)
            return self._session_manager
        current = normalize_kind(getattr(self._session_manager, "kind", None))
        if current != normalized:
            self._session_manager = create_session_manager(normalized)
        return self._session_manager

    def _clear_session_state_if_idle(self) -> None:
        has_connected = any(bool(d.is_connected) for d in self.devices.values())
        if not has_connected:
            self._session_manager = None

    def _assert_session_policy_for_connect(self, *, address: str, requested_kind: str) -> None:
        active_kind = self.active_session_kind()
        if active_kind is None:
            return
        if normalize_kind(active_kind) == normalize_kind(requested_kind):
            return
        raise SessionKindConflictError(
            active_kind=active_kind,
            requested_kind=requested_kind,
            addresses=[str(address)],
        )

    def _assert_session_policy_for_connect_many(self, addresses: list[str]) -> None:
        requested: dict[str, str] = {}
        for address in [str(v) for v in addresses]:
            dev = self.devices.get(address)
            if dev is None:
                continue
            if bool(dev.is_connected):
                continue
            requested[address] = self._device_kind(address)
        if not requested:
            return
        kinds = {normalize_kind(v) for v in requested.values()}
        if len(kinds) > 1:
            raise RuntimeError(
                "Connect blocked: selected devices span multiple kinds. "
                "Start one Connect->Disconnect session per kind."
            )
        kind = next(iter(kinds))
        active_kind = self.active_session_kind()
        if active_kind is None:
            return
        if normalize_kind(active_kind) == kind:
            return
        raise SessionKindConflictError(
            active_kind=active_kind,
            requested_kind=kind,
            addresses=list(requested.keys()),
        )

    def _emit_akr_line(self, addr: str, line: str) -> None:
        if self.on_akr_line:
            try:
                self.on_akr_line(str(addr), str(line))
            except Exception:
                pass

    def _emit_akr_ota_progress(self, addr: str, progress: ota_transfer.OtaProgress) -> None:
        if self.on_akr_ota_progress:
            try:
                self.on_akr_ota_progress(str(addr), progress)
            except Exception:
                pass

    def _akr_get_ota_ack_queue(self, address: str) -> asyncio.Queue[bytes]:
        return self._akr_ota_ack_queue.setdefault(str(address), asyncio.Queue())

    def _akr_clear_ota_ack_queue(self, address: str) -> None:
        q = self._akr_get_ota_ack_queue(address)
        while True:
            try:
                q.get_nowait()
            except asyncio.QueueEmpty:
                break

    async def _akr_wait_ota_ack(self, address: str, timeout_s: float) -> bytes:
        q = self._akr_get_ota_ack_queue(address)
        return await asyncio.wait_for(q.get(), timeout=timeout_s)

    def _akr_feed_ota_ack_bytes(self, address: str, data: bytes) -> None:
        q = self._akr_ota_ack_queue.get(str(address))
        if q is None:
            return
        for b in bytes(data):
            if b in (ord("S"), ord("A"), ord("O"), ord("E"), ord("F")):
                q.put_nowait(bytes([b]))

    def _akr_get_ota_line_queue(self, address: str) -> asyncio.Queue[str]:
        return self._akr_ota_line_queue.setdefault(str(address), asyncio.Queue())

    def _akr_clear_ota_line_queue(self, address: str) -> None:
        q = self._akr_get_ota_line_queue(address)
        while True:
            try:
                q.get_nowait()
            except asyncio.QueueEmpty:
                break

    def _akr_feed_ota_line(self, address: str, line: str) -> None:
        q = self._akr_ota_line_queue.get(str(address))
        if q is None:
            return
        q.put_nowait(str(line))

    async def scan(self, timeout_s: float = config.SCAN_TIMEOUT_S) -> list[DiscoveredDevice]:
        retry_count = max(0, int(getattr(config, "SCAN_EMPTY_RETRY_COUNT", 0)))
        max_attempts = 1 + retry_count
        found: list[DiscoveredDevice] = []
        for attempt in range(1, max_attempts + 1):
            if attempt == 1:
                self._log("Scan: discovering devices...")
            else:
                self._log(f"Scan: retry {attempt - 1}/{retry_count} (no devices found).")
            found = await self.backend.scan(timeout_s=timeout_s)
            if found:
                break

        # Keep connected devices; refresh scanned (disconnected) list
        keep_connected = {a: d for a, d in self.devices.items() if d.is_connected}
        self.devices = dict(keep_connected)

        for dd in found:
            if dd.address in self.devices:
                continue
            kind = infer_kind_from_name(dd.name)
            params = DeviceParams(name=dd.name, address=dd.address, kind=kind)
            self.devices[dd.address] = DeviceState(params=params)

        if found:
            self._log(f"Scan: found {len(found)} device(s).")
        else:
            self._log(f"Scan: found 0 device(s) after {max_attempts} attempt(s).")
        for addr in list(self.devices.keys()):
            self._notify_updated(addr)
        return found

    async def connect_many(self, addresses: list[str]) -> None:
        self._assert_session_policy_for_connect_many(addresses)
        await asyncio.gather(*(self.connect_one(a) for a in addresses))

    async def connect_one(self, address: str) -> None:
        if self._shutting_down:
            return
        dev = self.devices.get(address)
        if not dev:
            self.devices[address] = DeviceState(params=DeviceParams(name="/", address=address))
            dev = self.devices[address]
        if dev.is_connected and not self.backend.is_connected(address):
            self._log(f"Connect stale-state detected: forcing local cleanup before reconnect: {address}")
            self._finalize_device_disconnect(address, dev, reason="stale-before-connect")
        if dev.is_connected:
            return

        self._log(f"Connect: {address}")
        try:
            kind = normalize_kind(getattr(dev.params, "kind", "EMGS"))
            dev.params.kind = kind
            self._assert_session_policy_for_connect(address=address, requested_kind=kind)
            await self._ensure_session_manager(kind).connect_one(self, address, dev)
            self._notify_updated(address)
        except SessionKindConflictError as e:
            self._log(e.user_message)
            raise
        except asyncio.CancelledError:
            # App is shutting down; ensure device is reset.
            await self._disconnect_backend_best_effort(address, reason="connect-cancelled")
            self._finalize_device_disconnect(address, dev, reason="connect-cancelled")
            raise
        except Exception as e:
            # Some Bleak exceptions stringify to empty; include class name + repr for debug.
            self._log(f"Connect failed: {address}: {type(e).__name__}: {e!r}")
            had_live_link = bool(dev.is_connected or self.backend.is_connected(address))
            if had_live_link:
                await self._disconnect_backend_best_effort(address, reason="post-connect-failure")
                self._finalize_device_disconnect(address, dev, reason="post-connect-failure")
            else:
                self._finalize_device_disconnect(address, dev, reason="connect-failure")

    def _on_disconnect(self, address: str) -> None:
        """Called by backend when a connection drops unexpectedly."""
        dev = self.devices.get(address)
        if not dev:
            return
        self._finalize_device_disconnect(address, dev, reason="callback")

    async def disconnect_many(self, addresses: list[str]) -> None:
        await asyncio.gather(*(self.disconnect_one(a) for a in addresses))

    async def disconnect_one(self, address: str) -> None:
        dev = self.devices.get(address)
        if not dev:
            return
        backend_connected = self.backend.is_connected(address)
        if not dev.is_connected and not backend_connected:
            self._finalize_device_disconnect(address, dev, reason="user-disconnect")
            return
        if not dev.is_connected and backend_connected:
            self._log(f"Disconnect: stale backend link cleanup: {address}")
        else:
            self._log(f"Disconnect: {address}")
        try:
            await self._disconnect_backend_best_effort(address, reason="user-disconnect")
        finally:
            self._finalize_device_disconnect(address, dev, reason="user-disconnect")

    async def shutdown(self) -> None:
        """Best-effort cleanup for app exit."""
        self._shutting_down = True
        # Stop streaming first (best-effort)
        for addr, dev in list(self.devices.items()):
            if dev.is_connected and dev.is_streaming:
                try:
                    await self.stream_one(addr, enable=False)
                except Exception:
                    pass
        # Disconnect all
        for addr, dev in list(self.devices.items()):
            if dev.is_connected:
                try:
                    await self.disconnect_one(addr)
                except Exception:
                    pass
        # Backend cleanup
        try:
            await self.backend.shutdown()
        except Exception:
            pass

    async def update_many(self, addresses: list[str]) -> None:
        await asyncio.gather(*(self.update_one(a) for a in addresses))

    async def poll_many(self, addresses: list[str]) -> None:
        """Lightweight periodic polling to keep connected device state fresh.

        We intentionally keep this minimal (one command) to avoid BLE congestion.
        """
        await asyncio.gather(*(self.poll_one(a) for a in addresses))

    def check_health_many(self, addresses: list[str]) -> None:
        """Local health check without sending any BLE traffic.

        Useful while streaming: if RX stops, mark device as Awaiting Data.
        """
        now = time.monotonic()
        for a in addresses:
            self.check_health_one(a, now=now)

    def check_health_one(self, address: str, *, now: float | None = None) -> None:
        dev = self.devices.get(address)
        if not dev or not dev.is_connected:
            return
        if not self.backend.is_connected(address):
            self._finalize_device_disconnect(address, dev, reason="health-backend-mismatch")
            return
        t_now = time.monotonic() if now is None else now
        last = dev.last_rx_monotonic_s
        if last is None:
            return
        if (t_now - last) >= config.DEVICE_UNSTABLE_TIMEOUT_S:
            if dev.params.status != "Unstable":
                dev.mark_unstable()
                self._notify_updated(address)

    def reset_processed_state_many(self, addresses: list[str]) -> None:
        """Reset host-side *processed* buffers/state without changing streaming state.

        This is useful for restarting derived metrics (envelope, MDF/MNF, fatigue baseline)
        without stopping/restarting the stream.
        """
        for a in addresses:
            self.reset_processed_state_one(a)

    def reset_processed_state_one(self, address: str) -> None:
        dev = self.devices.get(address)
        if not dev:
            return
        # Clear processed buffers only (keep raw EMG/IMU).
        try:
            dev.emg_rms_buffer.clear()
            dev._emg_rms_sq_window.clear()
            dev._emg_rms_sq_sum = 0.0
        except Exception:
            pass
        try:
            dev.emg_median_freq_buffer.clear()
            dev.emg_mean_freq_buffer.clear()
            dev.emg_spectrum_last = None
            dev.emg_spectrum_last_linear = None
        except Exception:
            pass
        try:
            dev.emg_fatigue_score_buffer.clear()
            dev.emg_fatigue_conf_buffer.clear()
            dev._fatigue_t0_s = None
            dev._fatigue_baseline_mdf.clear()
            dev._fatigue_baseline_rms.clear()
            dev._fatigue_recent_mdf.clear()
        except Exception:
            pass
        try:
            dev.emg_ecg_clean_buffer.clear()
            dev.emg_ecg_artifact_buffer.clear()
            dev._emg_ecg_hp_prev_x = 0.0
            dev._emg_ecg_hp_prev_y = 0.0
            dev._emg_ecg_wavelet_hist.clear()
        except Exception:
            pass
        # Emit update so UI can reflect immediate reset.
        self._notify_updated(address)

    async def poll_one(self, address: str) -> None:
        dev = self.devices.get(address)
        if dev and dev.is_connected and not self.backend.is_connected(address):
            self._finalize_device_disconnect(address, dev, reason="poll-backend-mismatch")
            return
        if not self.backend.is_connected(address):
            return
        if not self._is_emgs_device(address):
            return
        dev = self.devices.get(address)
        if dev and dev.is_connected:
            # Mark "Awaiting Data" if we haven't received any RX from the device recently.
            last = dev.last_rx_monotonic_s
            if last is not None and (time.monotonic() - last) >= config.DEVICE_UNSTABLE_TIMEOUT_S:
                if dev.params.status != "Unstable":
                    dev.mark_unstable()
                    self._notify_updated(address)
        # TIME_SYNC ('A3') returns battery/charge + timestamp on this firmware.
        await self._write_time_sync_query(address)

    async def _write_time_sync_query(self, address: str) -> None:
        self._last_time_sync_send_ms[address] = int(time.time() * 1000)
        await self._write(address, protocol.build_payload(protocol.TIME_SYNC.opcode))

    async def _write_get_timestamp_query(self, address: str) -> None:
        self._last_get_ts_send_ms[address] = int(time.time() * 1000)
        await self._write(address, protocol.build_payload(protocol.GET_TIMESTAMP.opcode))

    def _emgs_update_payloads(self) -> list[bytes]:
        """Build static EMGS GET payload list used during full refresh."""
        payloads: list[bytes] = [
            protocol.build_payload(protocol.GET_VERSION.opcode),
            protocol.build_payload(protocol.GET_DSP_VERSION.opcode),
            protocol.build_payload(protocol.GET_BLE_NAME.opcode),
            protocol.build_payload(protocol.GET_CONN_INTERVAL.opcode),
            protocol.build_payload(protocol.GET_EMG_ENABLE.opcode),
            protocol.build_payload(protocol.GET_LOW_BATT_LVL.opcode),
            protocol.build_payload(protocol.GET_EMG_THRESHOLD.opcode),
            protocol.build_payload(protocol.GET_OUT_OF_STORAGE_THRESHOLD.opcode),
            protocol.build_payload(protocol.ICM_GET_BIAS.opcode),
        ]
        payloads.extend(protocol.build_payload("AX", idx) for idx in range(9))
        payloads.extend(protocol.build_payload("AZ", sensor_type) for sensor_type in (1, 4, 6, 7, 8))
        payloads.extend(protocol.build_payload("AD", sensor_type) for sensor_type in (1, 4))
        return payloads

    async def update_one(self, address: str) -> None:
        if not self.backend.is_connected(address):
            return
        if not self._supports_settings(address):
            return
        # Keep update ordering explicit:
        # 1) metadata/version,
        # 2) clock probes with host timestamp bookmarks for delta estimation,
        # 3) static mode/threshold/bias snapshots.
        update_payloads = self._emgs_update_payloads()
        for payload in update_payloads[:2]:
            await self._write(address, payload)
        await self._write_time_sync_query(address)
        await self._write_get_timestamp_query(address)
        for payload in update_payloads[2:]:
            await self._write(address, payload)
        # Notify decode will update device fields

    async def stream_many(self, addresses: list[str], enable: bool) -> None:
        await asyncio.gather(*(self.stream_one(a, enable=enable) for a in addresses))

    async def _stream_one_emgs(self, address: str, dev: DeviceState, *, enable: bool) -> None:
        cmd = protocol.STREAM_START.opcode if enable else protocol.STREAM_STOP.opcode
        await self._write(address, protocol.build_payload(cmd))
        # Optimistic state update (device will also ACK via notify if firmware does)
        if enable:
            self._prepare_emgs_stream_session(dev)
        dev.is_streaming = bool(enable)
        self._notify_updated(address)
        # Selection LED is suppressed while streaming; refresh if this device is selected.
        async with self._selection_led_lock:
            await self._refresh_selection_leds_locked()

    def _reset_akr_stream_state(self, address: str, dev: DeviceState) -> None:
        """Reset AKR runtime buffers/parsers for a fresh local stream session.

        Flow:
        1) Reset AKR-relative time origins and runtime feedback containers.
        2) Clear all AKR telemetry/history buffers (`akr_*_buffer`) dynamically.
        3) Clear shared IMU buffers used by AKR plots plus parser/OTA transient queues.
        """
        dev.akr.akr_origin_monotonic_s = None
        dev.akr.akr_cli_feedback_origin_monotonic_s = None
        dev.akr.akr_cli_feedback_buffer_by_key.clear()
        for f in fields(type(dev.akr)):
            name = f.name
            if not (name.startswith("akr_") and name.endswith("_buffer")):
                continue
            buf = getattr(dev.akr, name, None)
            if hasattr(buf, "clear"):
                try:
                    buf.clear()
                except Exception:
                    pass
        try:
            dev.acc_buffer.clear()
            dev.gyr_buffer.clear()
            dev.mag_buffer.clear()
        except Exception:
            pass
        self._akr_rx_buf[address] = ""
        self._akr_rx_bin[address] = bytearray()
        self._akr_cli_cfg_fid.pop(address, None)
        self._akr_ota_ack_queue.pop(address, None)
        self._akr_ota_line_queue.pop(address, None)

    def _prepare_emgs_stream_session(self, dev: DeviceState) -> None:
        """Initialize EMGS host-side processing state for a new stream session."""
        dev.proc_enable_emg_rms_envelope = bool(self.proc_enable_emg_rms_envelope_next)
        dev.proc_emg_rms_window_n = int(self.proc_emg_rms_window_n_next)
        dev.proc_enable_emg_freq_features = bool(self.proc_enable_emg_freq_features_next)
        dev.proc_emg_spec_window_n = int(self.proc_emg_spec_window_n_next)
        dev.proc_enable_emg_fatigue = bool(self.proc_enable_emg_fatigue_next)
        dev.proc_emg_fatigue_baseline_s = float(self.proc_emg_fatigue_baseline_s_next)
        dev.proc_emg_fatigue_weight_mdf_pct = float(self.proc_emg_fatigue_weight_mdf_pct_next)
        dev.proc_emg_fatigue_weight_rms_pct = float(self.proc_emg_fatigue_weight_rms_pct_next)
        dev.proc_emg_fatigue_conf_recent_n = int(self.proc_emg_fatigue_conf_recent_n_next)
        dev.proc_enable_emg_ecg_filter = bool(self.proc_enable_emg_ecg_filter_next)
        dev.proc_emg_ecg_filter_method = str(self.proc_emg_ecg_filter_method_next)
        dev.proc_emg_ecg_hp_cutoff_hz = float(self.proc_emg_ecg_hp_cutoff_hz_next)
        dev.proc_emg_ecg_wavelet_levels = int(self.proc_emg_ecg_wavelet_levels_next)
        dev.proc_emg_ecg_wavelet_shrink = float(self.proc_emg_ecg_wavelet_shrink_next)
        # Start the envelope from a clean slate each session (prevents mixing across sessions).
        dev.emg_rms_buffer.clear()
        dev._emg_rms_sq_window.clear()
        dev._emg_rms_sq_sum = 0.0
        # Clear other processed buffers for a fresh session.
        dev.emg_median_freq_buffer.clear()
        dev.emg_mean_freq_buffer.clear()
        dev.emg_spectrum_last = None
        dev.emg_spectrum_last_linear = None
        dev.emg_fatigue_score_buffer.clear()
        dev.emg_fatigue_conf_buffer.clear()
        dev._fatigue_t0_s = None
        dev._fatigue_baseline_mdf.clear()
        dev._fatigue_baseline_rms.clear()
        dev._fatigue_recent_mdf.clear()
        dev.emg_ecg_clean_buffer.clear()
        dev.emg_ecg_artifact_buffer.clear()
        dev._emg_ecg_hp_prev_x = 0.0
        dev._emg_ecg_hp_prev_y = 0.0
        dev._emg_ecg_wavelet_hist.clear()

    async def _write_emgs_setting(self, address: str, payload: bytes, expected_len: int) -> None:
        if not self.backend.is_connected(address):
            return
        if not self._supports_settings(address):
            return
        await self._write(address, protocol.require_len(payload, expected_len))

    async def stream_one(self, address: str, enable: bool) -> None:
        if not self.backend.is_connected(address):
            return
        dev = self.devices.get(address)
        if dev is None:
            return
        # Stream routing is session-scoped through per-kind session managers.
        kind = self.kind_of_device(dev)
        await self._ensure_session_manager(kind).stream_one(self, address, dev, bool(enable))
        return

    async def set_indicator_led(self, address: str, state: str) -> None:
        # Optional UX; safe no-op if invalid.
        if not self._is_emgs_device(address):
            return
        rgb_code = {
            "off": protocol.IndicatorRGB.OFF,
            "blue": protocol.IndicatorRGB.BLUE,
            "yellow": protocol.IndicatorRGB.YELLOW,
            "purple": protocol.IndicatorRGB.PURPLE,
        }
        code = rgb_code.get(state)
        if code is None:
            return
        if not self.backend.is_connected(address):
            return

        # Cache + light throttling to avoid BLE congestion on rapid row selection changes.
        prev = self._led_state.get(address)
        if prev == state:
            return
        now = time.monotonic()
        last = self._led_last_ts_s.get(address, 0.0)
        # Only throttle "purple" selection flashes; always allow restoring the prior state.
        if state == "purple" and (now - last) < self._led_min_interval_s:
            return

        self._led_state[address] = state
        if state == "purple":
            self._led_last_ts_s[address] = now
        await self._write(address, protocol.build_payload(protocol.SET_INDICATOR.opcode, 0, code))

    def _drop_selection_state_for_address(self, address: str) -> None:
        """Remove address from all selection/identify bookkeeping (no BLE writes)."""
        for s in self._ui_selected_addrs_by_source.values():
            s.discard(address)
        self._led_override_active.discard(address)
        self._led_prev_before_select.pop(address, None)
        self._identify_token.pop(address, None)

    def _selected_union(self) -> set[str]:
        out: set[str] = set()
        for s in self._ui_selected_addrs_by_source.values():
            out |= set(s)
        return out

    def _should_allow_selection_led(self, address: str) -> bool:
        """Return True if we should show a purple selection LED right now."""
        dev = self.devices.get(address)
        if not dev or not dev.is_connected:
            return False
        # Identify source overrides streaming suppression.
        if address in self._ui_selected_addrs_by_source.get("identify", set()):
            return True
        return not bool(dev.is_streaming)

    async def _refresh_selection_leds_locked(self) -> None:
        """Apply purple selection LEDs for all UI selection sources (lock must be held)."""
        desired = {a for a in self._selected_union() if self.backend.is_connected(a)}

        # Drop bookkeeping for devices no longer selected by ANY source.
        for a in list(self._led_prev_before_select.keys()):
            if a in desired:
                continue
            if a in self._led_override_active:
                prev = self._led_prev_before_select.get(a, "off")
                await self.set_indicator_led(a, prev)
                self._led_override_active.discard(a)
            self._led_prev_before_select.pop(a, None)

        # Ensure we have a previous-state snapshot for all selected devices.
        for a in desired:
            if a not in self._led_prev_before_select:
                self._led_prev_before_select[a] = self._led_state.get(a, "off")

        # Enforce current policy (purple if selected and allowed; otherwise restore).
        for a in desired:
            allow = self._should_allow_selection_led(a)
            if allow and a not in self._led_override_active:
                await self.set_indicator_led(a, "purple")
                self._led_override_active.add(a)
            elif (not allow) and a in self._led_override_active:
                prev = self._led_prev_before_select.get(a, "off")
                await self.set_indicator_led(a, prev)
                self._led_override_active.discard(a)

    async def _set_ui_selected_devices(self, source: str, addresses: list[str]) -> None:
        """Update one selection source and refresh LEDs (purple)."""
        async with self._selection_led_lock:
            desired = {a for a in addresses if self.backend.is_connected(a)}
            if source not in self._ui_selected_addrs_by_source:
                self._ui_selected_addrs_by_source[source] = set()
            self._ui_selected_addrs_by_source[source] = desired
            await self._refresh_selection_leds_locked()

    async def set_table_selected_devices(self, addresses: list[str]) -> None:
        """Connect-page selection → device indicator LED (purple), suppressed while streaming."""
        await self._set_ui_selected_devices("table", addresses)

    async def set_signals_selected_devices(self, addresses: list[str]) -> None:
        """Signals-page device selection → device indicator LED (purple), suppressed while streaming."""
        await self._set_ui_selected_devices("signals", addresses)

    async def identify_device(self, address: str, *, duration_s: float = 2.0) -> None:
        """Temporarily light a device purple to help identify it (allowed even while streaming)."""
        if not self.backend.is_connected(address):
            return
        token = time.monotonic()
        async with self._selection_led_lock:
            self._identify_token[address] = token
            self._ui_selected_addrs_by_source.setdefault("identify", set()).add(address)
            await self._refresh_selection_leds_locked()

        async def _clear_later() -> None:
            try:
                await asyncio.sleep(max(0.1, float(duration_s)))
            except asyncio.CancelledError:
                return
            async with self._selection_led_lock:
                if self._identify_token.get(address) != token:
                    return
                self._identify_token.pop(address, None)
                self._ui_selected_addrs_by_source.get("identify", set()).discard(address)
                await self._refresh_selection_leds_locked()

        asyncio.create_task(_clear_later())

    async def set_timestamp_now(self, address: str) -> None:
        if not self.backend.is_connected(address):
            return
        if not self._supports_settings(address):
            return
        # Device timestamp advances in 10ms ticks; align to reduce quantization error.
        now_ms = int(time.time() * 1000)
        now_ms = int(now_ms - (now_ms % 10))
        payload = protocol.build_payload(protocol.SET_TIMESTAMP.opcode, struct.pack("<Q", now_ms))
        await self._write_emgs_setting(address, payload, 10)
        # Pull a fresh TIME_SYNC reply so UI updates clock delta immediately.
        await self.poll_one(address)

    async def apply_settings(
        self,
        address: str,
        *,
        ble_name: Optional[str] = None,
        conn_interval_min: Optional[int] = None,
        conn_interval_max: Optional[int] = None,
        icm_enabled: Optional[list[bool]] = None,  # len 9
        emg_mode: Optional[int] = None,            # 0/1/2
    ) -> None:
        """Apply device settings (best-effort).

        Keeps individual writes simple and resilient. Caller can follow with update_one().
        """
        if not self.backend.is_connected(address):
            return
        if not self._supports_settings(address):
            return

        if ble_name is not None:
            # Firmware expects exactly 12 bytes (NUL padded). Keep prefix if caller provides it.
            name = ble_name[:12]
            name_bytes = name.encode("ascii", errors="ignore")[:12]
            name_bytes = name_bytes + b"\x00" * (12 - len(name_bytes))
            payload = protocol.build_payload(protocol.SET_BLE_NAME.opcode, name_bytes)
            await self._write_emgs_setting(address, payload, 14)

        if conn_interval_min is not None and conn_interval_max is not None:
            payload = protocol.build_payload(
                protocol.SET_CONN_INTERVAL.opcode,
                struct.pack("<H", int(conn_interval_min)),
                struct.pack("<H", int(conn_interval_max)),
            )
            await self._write_emgs_setting(address, payload, 6)

        if icm_enabled is not None:
            if len(icm_enabled) != 9:
                raise ValueError("icm_enabled must have length 9")
            for idx, enabled in enumerate(icm_enabled):
                payload = protocol.build_payload(protocol.SET_ICM_ENABLE.opcode, idx, 1 if enabled else 0)
                await self._write_emgs_setting(address, payload, 4)

        if emg_mode is not None:
            payload = protocol.build_payload(protocol.SET_EMG_ENABLE.opcode, int(emg_mode))
            await self._write_emgs_setting(address, payload, 3)

    async def apply_modes_many(self, addresses: list[str], *, icm_enabled: list[bool], emg_mode: int) -> None:
        """Apply only the 5 mode settings across many devices, then refresh."""
        addrs = [
            a
            for a in addresses
            if self.backend.is_connected(a)
            and (self.devices.get(a) is not None)
            and self._supports_settings(a)
        ]
        if not addrs:
            return
        await asyncio.gather(*(self.apply_settings(a, icm_enabled=list(icm_enabled), emg_mode=int(emg_mode)) for a in addrs))
        # Pull fresh info so UI shows the updated modes.
        await self.update_many(addrs)

    async def set_emg_threshold(self, address: str, threshold: int) -> None:
        payload = protocol.build_payload(protocol.SET_EMG_THRESHOLD.opcode, struct.pack("<H", int(threshold)))
        await self._write_emgs_setting(address, payload, 4)

    async def set_power_safe_level(self, address: str, level_percent: int) -> None:
        payload = protocol.build_payload(protocol.SET_LOW_BATT_LVL.opcode, int(level_percent))
        await self._write_emgs_setting(address, payload, 3)

    async def set_storage_threshold(self, address: str, level_percent: int) -> None:
        payload = protocol.build_payload(protocol.SET_OUT_OF_STORAGE_THRESHOLD.opcode, int(level_percent))
        await self._write_emgs_setting(address, payload, 3)

    async def set_icm_freq(self, address: str, sensor_type: int, freq: int) -> None:
        payload = protocol.build_payload(protocol.ICM_SET_FREQ.opcode, int(sensor_type), int(freq))
        await self._write_emgs_setting(address, payload, 4)

    async def set_icm_scale(self, address: str, sensor_type: int, scale: int) -> None:
        payload = protocol.build_payload(protocol.ICM_SET_SCALE.opcode, int(sensor_type), int(scale))
        await self._write_emgs_setting(address, payload, 4)

    async def set_icm_bias(self, address: str, bias_acc: list[int], bias_gyr: list[int], bias_mag: list[int]) -> None:
        if not self.backend.is_connected(address):
            return
        if not self._supports_settings(address):
            return
        if len(bias_acc) != 3 or len(bias_gyr) != 3 or len(bias_mag) != 3:
            raise ValueError("bias lists must have length 3")
        payload = protocol.build_payload(
            protocol.ICM_SET_BIAS.opcode,
            b"".join(struct.pack("<i", int(x)) for x in bias_acc),
            b"".join(struct.pack("<i", int(x)) for x in bias_gyr),
            b"".join(struct.pack("<i", int(x)) for x in bias_mag),
        )
        # opcode(2) + 36 bytes = 38
        await self._write_emgs_setting(address, payload, 38)

    async def set_icm_auto_save_bias(self, address: str, enable: bool) -> None:
        payload = protocol.build_payload(protocol.ICM_SET_AUTO_SAVE_BIAS.opcode, 1 if enable else 0)
        await self._write_emgs_setting(address, payload, 3)

    async def _write(self, address: str, payload: bytes) -> None:
        if self._debug_cmd:
            # Payload begins with 2 ASCII bytes opcode (e.g. b'A5', b'AX', etc.)
            try:
                op = payload[:2].decode("ascii", errors="replace")
            except Exception:
                op = "??"
            msg = f"TX [{address}] op={op} len={len(payload)}"
            if self._debug_cmd_hex:
                hx = " ".join(f"{b:02X}" for b in payload[:32])
                msg += f" head={hx}"
            self._log(msg)
        try:
            await self.backend.write(address, payload)
        except Exception as e:
            self._log(f"Write failed: {address}: {type(e).__name__}: {e!r}")
            dev = self.devices.get(address)
            if not dev or not dev.is_connected:
                return
            # Any write error after a marked-connected state is treated as a transport break.
            # Flow:
            # 1) force backend disconnect so stale clients/notifications are drained,
            # 2) run the same finalizer used by callback/user-disconnect paths.
            await self._disconnect_backend_best_effort(address, reason="write-failure")
            self._finalize_device_disconnect(address, dev, reason="write-failure")

    def _on_notify(self, address: str, data: bytes) -> None:
        dev = self.devices.get(address)
        if not dev:
            dev = DeviceState(params=DeviceParams(name="/", address=address))
            self.devices[address] = dev
        dev.last_rx_monotonic_s = time.monotonic()
        # Any RX implies the link is healthy again.
        if dev.is_connected and dev.params.status == "Unstable":
            dev.params.status = "Connected"
        kind = normalize_kind(getattr(dev.params, "kind", "EMGS"))
        dev.params.kind = kind
        get_handler(kind).handle_notify(self, address, dev, data)

    async def akr_send_line(self, address: str, line: str) -> None:
        """Send a single ASCII/UTF-8 CLI line to a AKR device (best-effort).

        Uses the per-device WRITE characteristic selected at connect-time.
        """
        dev = self.devices.get(address)
        if not dev or not self._is_akr_device(address):
            return
        if not self.backend.is_connected(address):
            return
        s = str(line or "").strip()
        if not s:
            return
        # STM32 CLI in `backup/akr_code_v2/Core/Src/cli_uart.c` treats CR as newline and ignores LF after CR,
        # so CRLF is a safe cross-platform terminator.
        payload = (s + "\r\n").encode("utf-8", errors="replace")
        await self._write(address, payload)

    async def akr_send_ota_frames(
        self,
        address: str,
        file_path: str,
        *,
        ack_timeout_ms: int = config.AKR_OTA_ACK_TIMEOUT_MS,
        retries: int = config.AKR_OTA_RETRIES,
        inter_frame_ms: int = config.AKR_OTA_INTER_FRAME_MS,
        write_chunk_size: int = config.AKR_OTA_WRITE_CHUNK_SIZE,
        write_with_response: bool = config.AKR_OTA_WRITE_WITH_RESPONSE_DEFAULT,
    ) -> ota_transfer.OtaSummary:
        session_manager = self._ensure_session_manager("AKR")
        return await session_manager.send_ota_frames(
            self,
            address,
            file_path,
            ack_timeout_ms=int(ack_timeout_ms),
            retries=int(retries),
            inter_frame_ms=int(inter_frame_ms),
            write_chunk_size=int(write_chunk_size),
            write_with_response=bool(write_with_response),
        )


class EmgsManager(DeviceSessionManager):
    """Backward-compatible alias; use DeviceSessionManager for new code."""


