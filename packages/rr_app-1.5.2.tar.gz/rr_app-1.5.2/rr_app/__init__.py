"""RR App PyQt6 application (clean rewrite).

Run with:
    python -m rr_app
"""

from __future__ import annotations

import sys

__all__ = ["__version__"]

# Safety: never write __pycache__/bytecode into the checked-out repo / installed package.
# This avoids "accidental updates" to a git checkout when running `rr` or `python -m rr_app`.
sys.dont_write_bytecode = True

__version__ = "1.5.2"

"""
 v1.4.0:
   - Added Signals preset profile (save/load)
   - Updated Settings prompt button grid

 v1.4.1:
   - Added mutlilingual translation selector support

 v1.4.3:
   - Fixed data recording CSV format

 v1.4.9:
   - Can read new CPM telemetry (for remaining time)

 v1.5.0:
   - Fixed CPM target_deg to _rad; refactored the rr_app

"""
