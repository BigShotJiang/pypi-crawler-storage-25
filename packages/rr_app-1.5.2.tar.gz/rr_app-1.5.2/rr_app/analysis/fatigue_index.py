from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True, slots=True)
class FatigueIndexConfig:
    """Unsupervised fatigue score configuration (no ground truth required)."""

    baseline_s: float = 10.0  # use early windows as baseline
    w_mdf: float = 0.7
    w_rms: float = 0.3


def _clip01(x: np.ndarray) -> np.ndarray:
    return np.clip(np.asarray(x, dtype=float), 0.0, 1.0)


def fatigue_index_unsupervised(
    t_s: np.ndarray,
    *,
    rms: np.ndarray,
    mdf_hz: np.ndarray,
    cfg: FatigueIndexConfig = FatigueIndexConfig(),
) -> tuple[np.ndarray, np.ndarray]:
    """Compute (fatigue_score_0to1, confidence_0to1) from feature trends.

    This is NOT a calibrated probability. It's a heuristic score that tends to increase when:
    - MDF decreases (classic fatigue marker)
    - RMS increases (often, but not always)
    """
    t = np.asarray(t_s, dtype=float).reshape(-1)
    rms = np.asarray(rms, dtype=float).reshape(-1)
    mdf = np.asarray(mdf_hz, dtype=float).reshape(-1)
    n = int(min(t.size, rms.size, mdf.size))
    if n <= 0:
        return np.zeros((0,), dtype=float), np.zeros((0,), dtype=float)

    t = t[:n]
    rms = rms[:n]
    mdf = mdf[:n]

    # Baseline = early segment (by time).
    t0 = float(np.min(t))
    t1 = t0 + float(cfg.baseline_s)
    base_mask = t <= t1
    if not np.any(base_mask):
        base_mask = np.arange(n) < max(1, n // 10)

    mdf0 = float(np.nanmedian(mdf[base_mask]))
    rms0 = float(np.nanmedian(rms[base_mask]))
    if not math.isfinite(mdf0) or mdf0 <= 0:
        mdf0 = float(np.nanmedian(mdf)) if np.nanmedian(mdf) > 0 else 1.0
    if not math.isfinite(rms0) or rms0 <= 0:
        rms0 = float(np.nanmedian(rms)) if np.nanmedian(rms) > 0 else 1.0

    # Components
    mdf_drop = _clip01((mdf0 - mdf) / (mdf0 + 1e-9))
    rms_rise = _clip01((rms - rms0) / (rms0 + 1e-9))
    score = _clip01(float(cfg.w_mdf) * mdf_drop + float(cfg.w_rms) * rms_rise)

    # Confidence heuristic: higher when MDF trend is consistently decreasing.
    conf = np.zeros_like(score, dtype=float)
    try:
        from scipy.stats import spearmanr  # type: ignore

        # Trend over time: fatigue implies mdf decreases, so corr(t, -mdf) should be positive.
        rho, _p = spearmanr(t, -mdf, nan_policy="omit")
        rho = 0.0 if not math.isfinite(float(rho)) else float(rho)
        # Map rho in [-1..1] to [0..1] with some floor.
        trend_conf = _clip01((rho + 1.0) / 2.0)
        conf = 0.2 + 0.8 * float(trend_conf)
    except Exception:
        # Fallback: use monotonicity of MDF (fraction of steps that go down).
        if n >= 2:
            down = float(np.mean(np.diff(mdf) < 0))
            conf = 0.2 + 0.8 * float(_clip01(down))
        else:
            conf = np.ones_like(score, dtype=float) * 0.2

    return score, _clip01(conf)

