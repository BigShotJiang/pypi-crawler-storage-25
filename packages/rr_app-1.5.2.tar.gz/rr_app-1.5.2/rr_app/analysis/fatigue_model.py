from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np


def _require_sklearn() -> "object":
    try:
        import sklearn  # type: ignore
    except ModuleNotFoundError as e:  # pragma: no cover
        raise ModuleNotFoundError(
            "scikit-learn is required for training/calibration. Install with: pip install -r requirements.txt"
        ) from e
    return sklearn


@dataclass(frozen=True, slots=True)
class TrainConfig:
    model: str = "logreg"  # "logreg" | "gbdt"
    calibrate: str = "sigmoid"  # "sigmoid" | "isotonic" | "none"
    random_state: int = 1337
    max_iter: int = 2000
    # Conformal prediction set coverage (1-alpha). alpha=0.1 -> 90% sets.
    conformal_alpha: float = 0.1


def build_classifier(cfg: TrainConfig) -> Any:
    _require_sklearn()
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler

    model = str(cfg.model).lower()
    if model == "logreg":
        clf = LogisticRegression(
            penalty="l2",
            C=1.0,
            max_iter=int(cfg.max_iter),
            multi_class="multinomial",
            solver="lbfgs",
            random_state=int(cfg.random_state),
        )
        # Logistic regression benefits from standardization.
        return Pipeline([("scaler", StandardScaler()), ("clf", clf)])
    if model == "gbdt":
        clf = HistGradientBoostingClassifier(random_state=int(cfg.random_state))
        return Pipeline([("clf", clf)])
    raise ValueError(f"Unknown model={cfg.model!r}")


def maybe_calibrate(estimator: Any, *, method: str, cv: int = 3) -> Any:
    _require_sklearn()
    from sklearn.calibration import CalibratedClassifierCV

    method = str(method).lower()
    if method in ("none", "", "false", "0"):
        return estimator
    if method not in ("sigmoid", "isotonic"):
        raise ValueError(f"Unknown calibrate method={method!r}")
    return CalibratedClassifierCV(estimator, method=method, cv=int(cv))


def groupwise_cv_metrics(X: np.ndarray, y: np.ndarray, groups: np.ndarray, *, cfg: TrainConfig) -> dict[str, float]:
    """Subject-wise validation metrics (macro F1 + log loss + Brier)."""
    _require_sklearn()
    from sklearn.model_selection import GroupKFold
    from sklearn.metrics import f1_score, accuracy_score, log_loss

    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=int)
    g = np.asarray(groups)

    uniq = np.unique(g)
    n_groups = int(uniq.size)
    if n_groups < 2:
        raise ValueError("Need at least 2 groups for subject-wise validation")

    n_splits = min(5, n_groups)
    cv = GroupKFold(n_splits=n_splits)

    f1s: list[float] = []
    accs: list[float] = []
    lls: list[float] = []
    briers: list[float] = []

    classes = np.unique(y)
    n_classes = int(classes.size)

    for tr, te in cv.split(X, y, groups=g):
        est = build_classifier(cfg)
        est = maybe_calibrate(est, method=cfg.calibrate, cv=3)
        est.fit(X[tr], y[tr])
        y_hat = est.predict(X[te])
        f1s.append(float(f1_score(y[te], y_hat, average="macro")))
        accs.append(float(accuracy_score(y[te], y_hat)))

        # Probabilistic metrics
        if hasattr(est, "predict_proba"):
            p = est.predict_proba(X[te])
            # Ensure columns correspond to class labels 0..K-1 if needed.
            try:
                lls.append(float(log_loss(y[te], p, labels=list(range(n_classes)))))
            except Exception:
                # Fallback: compute log loss with inferred labels.
                lls.append(float(log_loss(y[te], p)))
            # Multi-class Brier: mean sum_k (p_k - 1[y=k])^2
            y_onehot = np.eye(n_classes, dtype=float)[y[te]]
            briers.append(float(np.mean(np.sum((p - y_onehot) ** 2, axis=1))))

    return {
        "cv_groups": float(n_groups),
        "cv_splits": float(n_splits),
        "accuracy_mean": float(np.mean(accs)),
        "f1_macro_mean": float(np.mean(f1s)),
        "log_loss_mean": float(np.mean(lls)) if lls else float("nan"),
        "brier_mean": float(np.mean(briers)) if briers else float("nan"),
    }


def fit_final_model(X: np.ndarray, y: np.ndarray, *, cfg: TrainConfig) -> Any:
    est = build_classifier(cfg)
    est = maybe_calibrate(est, method=cfg.calibrate, cv=3)
    est.fit(np.asarray(X, dtype=float), np.asarray(y, dtype=int))
    return est


def predict_with_confidence(estimator: Any, X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return (y_pred, p_pred) where p_pred is max class probability."""
    X = np.asarray(X, dtype=float)
    if hasattr(estimator, "predict_proba"):
        p = estimator.predict_proba(X)
        y = np.argmax(p, axis=1).astype(int)
        conf = np.max(p, axis=1).astype(float)
        return y, conf
    # Fallback: hard predictions only
    y = estimator.predict(X).astype(int)
    return y, np.ones((y.size,), dtype=float)


def conformal_threshold_from_calibration_probs(p_calib: np.ndarray, y_calib: np.ndarray, *, alpha: float = 0.1) -> float:
    """Compute split-conformal threshold for prediction sets.

    Nonconformity score s = 1 - p_true. Then choose q = quantile_{ceil((n+1)*(1-alpha))/n}.
    A class k is included in the set if 1 - p_k <= q  <=>  p_k >= 1 - q.
    """
    p = np.asarray(p_calib, dtype=float)
    y = np.asarray(y_calib, dtype=int)
    if p.ndim != 2:
        raise ValueError("p_calib must be 2D (n_samples, n_classes)")
    if y.size != p.shape[0]:
        raise ValueError("y_calib length must match p_calib rows")

    alpha = float(alpha)
    if not (0.0 < alpha < 1.0):
        raise ValueError(f"alpha must be in (0,1), got {alpha}")

    p_true = p[np.arange(y.size), y]
    s = 1.0 - np.clip(p_true, 0.0, 1.0)
    n = float(s.size)
    # Conformal quantile with (n+1)(1-alpha) rule.
    q_level = math.ceil((n + 1.0) * (1.0 - alpha)) / n
    q_level = min(1.0, max(0.0, q_level))
    q = float(np.quantile(s, q_level, method="higher"))
    return q


def prediction_set_from_probs(p: np.ndarray, *, q: float) -> list[list[int]]:
    """Return a prediction set (list of class indices) per sample."""
    p = np.asarray(p, dtype=float)
    q = float(q)
    thr = 1.0 - q
    out: list[list[int]] = []
    for i in range(p.shape[0]):
        cls = [int(k) for k in range(p.shape[1]) if float(p[i, k]) >= thr]
        if not cls:
            cls = [int(np.argmax(p[i]))]
        out.append(cls)
    return out


def save_model(path: str | Path, *, estimator: Any, cfg: TrainConfig, feature_names: list[str], meta: dict[str, Any] | None = None) -> None:
    _require_sklearn()
    import joblib  # type: ignore

    payload = {
        "estimator": estimator,
        "train_config": asdict(cfg),
        "feature_names": list(feature_names),
        "meta": meta or {},
    }
    joblib.dump(payload, str(path))


def load_model(path: str | Path) -> dict[str, Any]:
    _require_sklearn()
    import joblib  # type: ignore

    payload = joblib.load(str(path))
    if not isinstance(payload, dict) or "estimator" not in payload:
        raise ValueError("Invalid model file format")
    return payload


def save_metrics_json(path: str | Path, metrics: dict[str, float]) -> None:
    Path(path).write_text(json.dumps(metrics, indent=2, sort_keys=True) + "\n", encoding="utf-8")

