# -*- coding: utf-8 -*-
"""
@File        : rag_config.py
@Date        : 2026/4/3
@Author      : cabin
"""

from pydantic import BaseModel


class RagConfig(BaseModel):
    """
    RAG配置
    """
    name: str
    description: str
    top_k: int = 5
    mqe: bool = False
    hyde: bool = False
    chunk_splitter: bool = False
