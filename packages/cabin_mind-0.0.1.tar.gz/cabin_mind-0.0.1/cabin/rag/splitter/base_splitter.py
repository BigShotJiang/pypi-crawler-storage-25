# -*- coding: utf-8 -*-
"""
@File        : base_splitter.py
@Date        : 2026/4/2
@Author      : cabin
"""
from abc import ABC, abstractmethod


class BaseSplitter(ABC):
    """
    文档分块基类
    """

    @abstractmethod
    def split(self, text: str, chunk_split: bool, chunk_token: int, overlap_token: int) -> list[dict]:
        """
        文档分块
        :param text: 原始的markdown文档
        :param chunk_split: 是否分块
        :param chunk_token: 分块token上限
        :param overlap_token: 重叠token上限
        :return: 分块
        """
        pass
