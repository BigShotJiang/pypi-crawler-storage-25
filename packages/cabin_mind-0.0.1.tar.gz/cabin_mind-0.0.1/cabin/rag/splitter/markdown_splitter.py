# -*- coding: utf-8 -*-
"""
@File        : markdown_splitter.py
@Date        : 2026/4/2
@Author      : cabin
"""
import logging

from cabin.rag.splitter.base_splitter import BaseSplitter

logger = logging.getLogger(__name__)


def _is_cjk(ch: str) -> bool:
    """
    增强版：包含中文、日文、韩文 + 中文标点 + 全角符号
    """
    code = ord(ch)
    return (
        # CJK 汉字
            0x4E00 <= code <= 0x9FFF or
            0x3400 <= code <= 0x4DBF or
            0x20000 <= code <= 0x2CEAF or
            0xF900 <= code <= 0xFAFF or
            # 中文标点 & 全角符号
            0x3000 <= code <= 0x303F or
            0xFF00 <= code <= 0xFFEF or
            # 常用标点
            ch in '，。！？；：""''()[]{}【】、~@#￥%……&*'
    )


def _approx_token_len(text: str) -> int:
    """
    Token 估算
    """
    cjk_count = sum(1 for ch in text if _is_cjk(ch))
    # 剩下的按英文/数字/符号处理
    ascii_part = ''.join([ch if not _is_cjk(ch) else ' ' for ch in text])
    ascii_tokens = len([t for t in ascii_part.split() if t])
    return cjk_count + ascii_tokens


def _split_token(paragraph: list[dict], chunk_token: int, overlap_token: int) -> list[dict]:
    """
    拆分token
    """
    chunks: list[dict] = []
    cur_tokens: int = 0
    cur_paragraph: list[dict] = []
    i = 0
    while i < len(paragraph):
        p = paragraph[i]
        # 估算token数据
        tokens = _approx_token_len(p['content']) or 1
        # 此前累计 + 当前段落未超过阈值
        if cur_tokens + tokens <= chunk_token or not cur_paragraph:
            cur_paragraph.append(p)
            cur_tokens += tokens
            i += 1
        # 超过了阈值，则我们将其拼为chunk
        else:
            start = cur_paragraph[0]['start']
            end = cur_paragraph[-1]['end']
            chunks.append({
                'content': '\n\n'.join([p['content'] for p in cur_paragraph]),
                'head': next((p['head'] for p in reversed(cur_paragraph) if p['head']), None),
                'start': start,
                'end': end
            })
            # 额外添加覆盖段落，主要是为了让每个chunk之间有一定的重叠部分，保证语义的连贯
            if overlap_token > 0 and cur_paragraph:
                token = 0
                temp_paragraph: list[dict] = []
                for item in reversed(cur_paragraph):
                    cur_paragraph_token = _approx_token_len(item['content']) or 1
                    if token + cur_paragraph_token >= overlap_token:
                        break
                    token += cur_paragraph_token
                    temp_paragraph.append(item)
                cur_tokens = token
                cur_paragraph = list(reversed(temp_paragraph))
            else:
                cur_paragraph = []
                cur_tokens = 0
            # 避免死循环
            if cur_paragraph and cur_tokens + tokens > chunk_token:
                cur_tokens = 0
                cur_paragraph = []
    # 最后拼接最后一段
    if cur_paragraph:
        chunks.append({
            'content': '\n\n'.join([p['content'] for p in cur_paragraph]),
            'head': next((p['head'] for p in reversed(cur_paragraph) if p['head']), None),
            'start': cur_paragraph[0]['start'],
            'end': cur_paragraph[-1]['end']
        })
    return chunks


def _split_paragraph(text: str) -> list[dict]:
    """
    拆分段落：按照标题维度拆分
    """
    lines = text.splitlines()
    paragraphs: list[dict] = []
    heading_stack: list[dict] = []
    cur_tokens = 0
    buf: list[str] = []

    def flush_buf():
        """
        刷新缓冲区
        """
        # 如果缓冲区为空，直接返回
        if not buf:
            return
        content = '\n'.join(buf).strip()
        if not content:
            return
        paragraphs.append({
            'content': content,
            'head': ' > '.join([item['title'] for item in heading_stack]),
            'start': max(0, cur_tokens - len(content)),
            'end': cur_tokens
        })
        buf.clear()

    for line in lines:
        # 只要遇到标题，我们就将缓冲区的内容全部刷新
        if line.strip().startswith('#'):
            flush_buf()
            level = len(line.strip()) - len(line.strip().lstrip('#'))
            title = line.strip().lstrip('#').strip()

            # 需要保证标题按照层级来
            if level == 0:
                level = 1
            if len(heading_stack) > 0:
                last = heading_stack[-1]
                while last and level <= last['level']:
                    heading_stack.pop()
                    last = heading_stack[-1] if len(heading_stack) > 0 else None
            heading_stack.append({'title': title, 'level': level})
            cur_tokens += len(line) + 1
        # 如果是正文内容，则添加到缓冲区中
        else:
            buf.append(line)
            cur_tokens += len(line) + 1

    # 再把最后一部分添加到段落里
    flush_buf()
    return paragraphs


class MarkdownSplitter(BaseSplitter):
    """
    Markdown 文档分块器
    """

    def split(self, text: str, chunk_split: bool, chunk_token: int, overlap_token: int) -> list[dict]:
        """
        Markdown 文档分块
        """
        if not text:
            logger.warning("待处理文档内容为空!")
            return []
        # 先拆分段落
        paragraphs = _split_paragraph(text)
        if not chunk_split:
            return paragraphs
        # 再按照token拆分
        return _split_token(paragraphs, chunk_token, overlap_token)
