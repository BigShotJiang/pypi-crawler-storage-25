# -*- coding: utf-8 -*-
"""
@File        : rag_retriever.py
@Date        : 2026/4/3
@Author      : cabin
"""
import logging
import os.path

from cabin.vector.vector_db_config import VectorDBConfig
from cabin.vector.vector_db_manager import vector_db_manager
from cabin.vector.vector_dto import VectorDTO
from cabin.rag.parser.markdown_parser import MarkdownParser
from cabin.rag.splitter.markdown_splitter import MarkdownSplitter
from cabin.utils.file_util import FileUtil

logger = logging.getLogger(__name__)


class RagRetriever:
    """
    RAG Retriever
    """

    def __init__(self, mqe: bool = False, hyde: bool = False, top_k: int = 10, chunk_split: bool = False):
        # 这些配置完全内置，对Agent是黑盒
        self.mqe = mqe
        self.hyde = hyde
        self.top_k = top_k
        self.chunk_split = chunk_split
        self.parser = MarkdownParser()
        self.splitter = MarkdownSplitter()
        self.chunk_token = 512
        self.overlap_token = 64
        vector_db_config = VectorDBConfig(
            vector_db_cls='vector.chroma_vector_db.ChromaVectorDB',
            collection_name='rag',
            embedding_model='all-MiniLM-L6-v2',
            persist_dir='./vector_db',
            local=True
        )
        self.vector_db = vector_db_manager.get_vector_db_instance(vector_db_config)

    def add_document(self, file_path: str):
        """
        单文档向量化存储
        """
        if not os.path.exists(file_path):
            return
        # 提取文件名
        file_name = os.path.basename(file_path)
        # 生成唯一ID，用于去重
        doc_id = FileUtil.generate_unique_id(file_path)
        # 检查向量数据库中是否已存在
        if self.vector_db.exist(doc_id):
            logger.warning("文档已存在，无需重复向量化")
            return
        # 文档解析
        text = self.parser.parse(file_path)
        # 文档分块
        chunks = self.splitter.split(text, self.chunk_split, self.chunk_token, self.overlap_token)
        # 向量存储
        self.vector_db.add_batch([chunk['content'] for chunk in chunks],
                                 [
                                     {
                                         'heading_path': chunk['head'],
                                         'start': chunk['start'],
                                         'end': chunk['end'],
                                         'file_name': file_name,
                                         'doc_id': doc_id
                                     } for chunk in chunks
                                 ]
                                 )

    def retrieve(self, query: str) -> list[VectorDTO]:
        """
        RAG检索
        """
        # 是否支持MQE
        if self.mqe:
            pass
        # 是否支持Hyde
        if self.hyde:
            pass
        # 向量检索
        return self.vector_db.retrieve(query, self.top_k)
