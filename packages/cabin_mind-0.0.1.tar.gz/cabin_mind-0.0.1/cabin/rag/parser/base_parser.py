# -*- coding: utf-8 -*-
"""
@File        : base_parser.py
@Date        : 2026/3/31
@Author      : cabin
"""
from abc import ABC, abstractmethod


class BaseParser(ABC):
    """
    文档解析基类
    """

    @abstractmethod
    def parse(self, file_path: str) -> str:
        """
        解析文档
        """
        pass
