# -*- coding: utf-8 -*-
"""
@File        : markdown_parser.py
@Date        : 2026/3/31
@Author      : cabin
"""
import logging
import os.path

from markitdown import MarkItDown

from cabin.rag.parser.base_parser import BaseParser

logger = logging.getLogger(__name__)


class MarkdownParser(BaseParser):
    """
    Markdown 文件解析器
    """

    def parse(self, file_path: str) -> str:
        """
        所有格式，统一转换为Markdown，支持格式如下：
        - pdf、world、txt、md
        - excel、ppt
        - 图片
        - 音频
        - 网页
        """
        if not os.path.exists(file_path):
            logger.warning(f"文件不存在: {file_path}")
            return ""
        md = MarkItDown()
        result = md.convert(file_path)
        return result.text_content

if __name__ == '__main__':
    print(MarkdownParser().parse("/cabin/rag/星域抽奖营收下降分析与优化方案.pdf"))
