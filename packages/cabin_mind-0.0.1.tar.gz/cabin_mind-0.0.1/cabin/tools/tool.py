import asyncio
from abc import ABC, abstractmethod

from cabin.tools.tool_metadata import ToolMetadata
from cabin.tools.tool_param_schema import ToolParamSchema
from cabin.tools.tool_request import ToolRequest
from cabin.tools.tool_response import ToolResponse


class Tool(ABC):
    """
    工具抽象类
    """
    _metadata: ToolMetadata = None

    def run(self, request: ToolRequest) -> ToolResponse:
        """
        执行方法
        """
        return asyncio.run(self.execute(request))

    async def async_run(self, request: ToolRequest) -> ToolResponse:
        """
        异步执行方法
        """
        return await self.execute(request)

    @abstractmethod
    async def execute(self, request: ToolRequest) -> ToolResponse:
        """
        真实执行方法
        """
        pass

    def get_tool_full_desc(self):
        """
        获取工具的完整描述
        """
        # 获取工具基本信息
        tool_name, description = self._metadata.tool_name, self._metadata.tool_desc
        # 获取工具参数信息
        tool_params: list[ToolParamSchema] = self._metadata.tool_params
        # 构建工具完整描述
        full_desc = ''
        full_desc += f'工具名称：{tool_name}\n'
        full_desc += f'功能：{description}\n'
        full_desc += f'参数：\n'
        full_desc += '\n'.join(
            f"- {param.name}：{param.type}，{'必填' if param.required else '选填'}，{param.description}，如：{param.example if param.example else '无'}"
            for param in tool_params
        )
        return full_desc

    @property
    def tool_metadata(self):
        return self._metadata

    @classmethod
    def get_tool_metadata(cls):
        return cls._metadata
