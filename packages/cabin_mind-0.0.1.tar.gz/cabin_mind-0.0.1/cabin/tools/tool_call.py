# -*- coding: utf-8 -*-
"""
@File        : tool_call.py
@Date        : 2026/3/31
@Author      : cabin
"""
import json

from pydantic import BaseModel


class FunctionCall(BaseModel):
    """
    函数调用对象
    """
    name: str
    arguments: str

    @property
    def arg_dict(self) -> dict:
        try:
            return json.loads(self.arguments)
        except json.JSONDecodeError:
            return {}


class ToolCall(BaseModel):
    """
    标准的tool call
    """
    id: str
    type: str = 'function'
    function: FunctionCall
