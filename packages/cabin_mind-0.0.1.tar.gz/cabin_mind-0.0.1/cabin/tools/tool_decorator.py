from typing import Type

from cabin.tools.tool import Tool
from cabin.tools.tool_metadata import ToolMetadata
from cabin.tools.tool_param_schema import ToolParamSchema


def tool_meta(tool_name: str, tool_desc: str, tool_params: list[ToolParamSchema]):
    """
    工具元信息装饰器
    :param tool_name: 工具名称
    :param tool_desc: 工具描述
    :param tool_params: 工具入参列表
    """

    def decorator(cls: Type[Tool]):
        # 校验：确保装饰的是 Tool 的子类
        if not issubclass(cls, Tool):
            raise TypeError(f"@tool_meta 只能装饰 Tool 的子类，当前类：{cls.__name__}")
        # 校验：确保相应属性必须有值
        if not tool_name or not tool_desc:
            raise ValueError(f"工具名称和描述不能为空，当前类：{cls.__name__}")

        # 将元信息挂载到工具类的类属性上
        cls._metadata = ToolMetadata(
            tool_name=tool_name,
            tool_desc=tool_desc,
            tool_params=tool_params
        )

        return cls

    return decorator
