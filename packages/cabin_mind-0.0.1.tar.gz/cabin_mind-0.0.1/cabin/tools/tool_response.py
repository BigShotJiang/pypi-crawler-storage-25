# -*- coding: utf-8 -*-
"""
@File        : tool_response.py
@Date        : 2026/3/28
@Author      : cabin
"""
from typing import Any, Optional

from pydantic import BaseModel


class ToolResponse(BaseModel):
    """
    定义工具的统一出参
    """
    success: bool = True
    content: Optional[str] = None  # 自然语言描述
