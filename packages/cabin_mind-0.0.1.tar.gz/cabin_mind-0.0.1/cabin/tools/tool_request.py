# -*- coding: utf-8 -*-
"""
@File        : tool_request.py
@Date        : 2026/3/28
@Author      : cabin
"""
from typing import Any, Optional

from pydantic import BaseModel


class ToolRequest(BaseModel):
    """
    定义工具的统一入参
    """
    params: Optional[dict[str, Any]] = None

