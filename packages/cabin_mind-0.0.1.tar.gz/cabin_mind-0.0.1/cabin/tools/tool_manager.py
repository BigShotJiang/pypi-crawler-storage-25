import threading
from typing import Optional, Any

from cabin.tools.tool import Tool


class ToolManager:
    """
    工具管理器,全局单例模式
    """
    _instance: Optional["ToolManager"] = None
    _lock: threading.Lock = threading.Lock()
    _tool_instance_map: dict[str, Tool] = {}
    _tool_cls_map: dict[str, type[Tool]] = {}

    def __new__(cls, *args, **kwargs):
        """
        双检锁机制
        """
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def clear(self):
        """
        清空注册的工具
        """
        with self._lock:
            self._tool_cls_map.clear()
            self._tool_instance_map.clear()

    def register_tool_cls(self, tool_name: str, tool_cls: type[Tool]):
        """
        注册工具cls，用于懒加载
        """
        with self._lock:
            self._tool_cls_map[tool_name] = tool_cls

    def register_tool_instance(self, tool_name: str, tool: Tool):
        """
        注册工具
        """
        with self._lock:
            self._tool_instance_map[tool_name] = tool

    def get(self, tool_name: str) -> Tool:
        """
        获取工具对象，支持懒加载
        """
        # 如果实例缓存中有，直接返回
        if tool_name in self._tool_instance_map:
            return self._tool_instance_map.get(tool_name)

        # 如果实例缓存中没有，则从cls缓存中获取，并实例化
        tool_cls = self._tool_cls_map.get(tool_name)
        if tool_cls:
            with self._lock:
                # 双检锁机制，防止多线程同时实例化
                if tool_name not in self._tool_instance_map:
                    tool_instance = tool_cls()
                    self._tool_instance_map[tool_name] = tool_instance
            return self._tool_instance_map.get(tool_name)

        # 否则抛出异常
        raise ValueError(f"Tool {tool_name} not found")

    def get_all_tools(self) -> str:
        """
        获取所有工具(会进行实例化)
        """
        return self._get_tool(list(self._tool_cls_map.keys()))

    def get_specify_tools(self, tool_names: list[str]) -> str:
        """
        获取指定工具(会进行实例化)
        """
        return self._get_tool(tool_names)

    def build_all_llm_tools(self) -> list[dict[str, Any]]:
        """
        构建所有llm工具(供function call)
        """
        return self._build_tool(list(self._tool_cls_map.keys()))

    def build_llm_tools(self, tool_names: list[str]) -> list[dict[str, Any]]:
        """
        构建llm工具(供function call)
        """
        return self._build_tool(tool_names)

    def get_available_tool_count(self) -> int:
        """
        获取可用工具数量(已实例化)
        """
        return len(self._tool_instance_map.keys())

    def get_available_tool_names(self):
        """
        获取可用工具名称(已实例化)
        """
        return list(self._tool_instance_map.keys())

    def _get_tool(self, tool_names: list[str]) -> Optional[str]:
        """
        获取工具
        """
        tools = [self.get(tool_name) for tool_name in tool_names]
        if len(tools) == 0:
            return None
        tool_desc = []
        for iteration, item in enumerate(tools):
            tool_full_desc = item.get_tool_full_desc()
            indented_desc = '\n'.join(
                f'  {line}' if i > 0 else line for i, line in enumerate(tool_full_desc.split('\n'))
            )
            tool_desc.append(f'{iteration + 1}.{indented_desc}')
        return '\n\n'.join(tool_desc)

    def _build_tool(self, tool_names: list[str]) -> list[dict[str, Any]]:
        """
        构建function call
        """
        tools = [self.get(tool_name) for tool_name in tool_names]
        if len(tools) == 0:
            return []
        llm_tools = []
        for tool in tools:
            tool_params = tool.tool_metadata.tool_params
            properties = {}
            for param in tool_params:
                properties[param.name] = {
                    'type': param.type,
                    'description': param.description
                }
            parameters = {
                'type': 'object',
                'required': [param.name for param in tool_params if param.required],
                'properties': properties
            }
            llm_tools.append({
                'type': 'function',
                'function': {
                    'name': tool.tool_metadata.tool_name,
                    'description': tool.tool_metadata.tool_desc,
                    'parameters': parameters
                }
            })
        return llm_tools


tool_manager = ToolManager()
