from typing import Literal

from pydantic import BaseModel


class ToolParamSchema(BaseModel):
    """
    工具参数约束
    """
    name: str
    type: Literal["string", "integer", "number", "boolean", "array", "object"]
    description: str
    required: bool
    example: str = None
