# -*- coding: utf-8 -*-
"""
@File        : rag_tool.py
@Date        : 2026/4/3
@Author      : cabin
"""
from cabin.rag.rag_config import RagConfig
from cabin.rag.rag_retriever import RagRetriever
from cabin.tools.tool import Tool
from cabin.tools.tool_metadata import ToolMetadata
from cabin.tools.tool_param_schema import ToolParamSchema
from cabin.tools.tool_request import ToolRequest
from cabin.tools.tool_response import ToolResponse


class RagTool(Tool):
    """
    RAG检索工具
    """

    def __init__(self, config: RagConfig):
        """
        动态注册
        """
        tool_metadata = ToolMetadata(
            tool_name=config.name,
            tool_desc=config.description,
            tool_params=[
                ToolParamSchema(name="query",
                                description="用户的问题或者检索的关键词，必须使用清晰完整的中文句子，不要省略任何关键信息",
                                type="string",
                                required=True
                                )
            ]
        )
        self._metadata = tool_metadata
        self.mqe = config.mqe
        self.hyde = config.hyde
        self.top_k = config.top_k
        self.chunk_split = config.chunk_splitter
        self.rag_retriever = RagRetriever(self.mqe, self.hyde, self.top_k)

    async def execute(self, request: ToolRequest) -> ToolResponse:
        """
        真实检索逻辑
        """
        query = request.params.get('query')
        if not query:
            return ToolResponse(success=False, content="缺少相关检索词，未检索到相关内容")
        result = self.rag_retriever.retrieve(query)
        if not result:
            return ToolResponse(success=False, content="未检索到相关内容")
        content = ""
        for index, item in enumerate(result):
            file_name = item.metadata.get('file_name')
            title = item.metadata.get('heading_path')
            content += (f"[编号] {index + 1}\n"
                        f"来源：{file_name}\n"
                        f"章节：{title}\n"
                        f"内容：{item.content}\n\n")
        if not content.strip():
            return ToolResponse(success=False, content="未检索到相关内容")
        return ToolResponse(success=True, content=content)
