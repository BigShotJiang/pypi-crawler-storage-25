from typing import Optional, List

from pydantic import BaseModel, ConfigDict

from cabin.tools.tool_param_schema import ToolParamSchema


class ToolMetadata(BaseModel):
    """
    工具元信息数据类：强制约束工具的所有元信息，支持扩展
    用于统一管理工具的名称、描述、执行函数、版本等核心信息
    """
    model_config = ConfigDict(
        frozen=True,
        arbitrary_types_allowed=True
    )
    tool_name: str
    tool_desc: str
    tool_params: Optional[List[ToolParamSchema]] = None
