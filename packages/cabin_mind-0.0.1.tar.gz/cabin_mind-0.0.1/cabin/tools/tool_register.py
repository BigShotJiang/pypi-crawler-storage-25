import logging
import os
import sys

from cabin.tools.tool import Tool
from cabin.tools.tool_manager import tool_manager
from cabin.utils.module_util import ModuleUtil

logger = logging.getLogger(__name__)

DEFAULT_EXCLUDE_DIRS = ['__pycache__', '.venv', 'venv']


class ToolRegister:
    """
    工具扫描和注册
    """

    def __init__(self, base_path: list[str], exclude_dirs: list[str] = None, lazy_load: bool = False):
        self.base_path = base_path
        self.exclude_dirs = exclude_dirs or DEFAULT_EXCLUDE_DIRS
        self.lazy_load = lazy_load

    def register(self):
        """
        扫描工具
        """
        logger.info('=' * 30 + f'> 开始进行Tool注册，当前模式：{"懒加载" if self.lazy_load else "非懒加载"} ')
        # 清空历史注册的工具
        tool_manager.clear()
        # 对每个目录进行遍历
        for path in self.base_path:
            # 检查是否为目录
            if not os.path.isdir(path):
                print(f'非目录路径：{path}')
                continue
            # 处理每一个目录
            self._scan_single_path(path)
        logger.info(f'当前已实例化工具如下：{tool_manager.get_available_tool_names()}')
        logger.info('=' * 30 + f'> Tool注册结束，共实例化{tool_manager.get_available_tool_count()}个 ')

    def _scan_single_path(self, path: str):
        """
        递归加载每一个目录
        """
        # 递归遍历目录下的所有文件
        for cur_dir, dirs, files in os.walk(path):
            # 剔除掉排除的路径
            dirs[:] = [d for d in dirs if d not in self.exclude_dirs]
            # 遍历文件
            for file in files:
                # 过滤一些非工具文件
                if not file.endswith('.py') or file == '__init__.py':
                    continue
                # 注册和加载工具
                self._scan_single_tool(os.path.join(cur_dir, file))

    def _scan_single_tool(self, file_path: str):
        """
        扫描注册单个工具
        """
        # 动态加载模块
        module_name = f'dynamic_tool_{hash(file_path)}'
        module = ModuleUtil.dynamic_load_module(module_name, file_path)
        if module is None:
            return

        # 遍历模块的属性
        has_valid_tool = False
        for item in dir(module):
            # 获取属性对象
            attr = getattr(module, item)
            # 过滤无需注册
            if not isinstance(attr, type) or not issubclass(attr, Tool) or attr is Tool:
                continue
            # 校验_tool_metadata
            if not hasattr(attr, '_metadata'):
                logger.warning(f'{attr.__name__}缺少_tool_metadata')
                continue
            tool_metadata = attr.get_tool_metadata()
            if tool_metadata is None:
                continue
            # 如果是懒加载，这里注册cls即可
            if self.lazy_load:
                tool_manager.register_tool_cls(tool_metadata.tool_name, attr)
                has_valid_tool = True
                continue
            # 实例化对象
            attr_obj: Tool = attr()
            try:
                # 执行方法，获取需要注册的基本
                tool_name = attr_obj.tool_metadata.tool_name
                # 工具注册
                tool_manager.register_tool_instance(tool_name, attr_obj)
                # 注册成功，标记为有效
                has_valid_tool = True
            except Exception as e:
                logger.warning(f'{attr.__name__}注册失败: {e}')

        # 如果没有有效的工具，则删除模块，防止内存泄露
        if not has_valid_tool and module_name in sys.modules:
            del sys.modules[module_name]
