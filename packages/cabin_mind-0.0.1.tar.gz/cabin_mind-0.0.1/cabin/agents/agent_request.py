# -*- coding: utf-8 -*-
"""
@File        : agent_request.py
@Date        : 2026/3/28
@Author      : cabin
"""
from typing import Any, Optional

from pydantic import BaseModel


class AgentRequest(BaseModel):
    """
    Agent入参定义
    """
    query: Optional[str] = None
    params: Optional[dict[str, Any]] = None
