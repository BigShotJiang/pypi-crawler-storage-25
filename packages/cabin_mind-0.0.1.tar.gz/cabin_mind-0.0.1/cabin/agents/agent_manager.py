# -*- coding: utf-8 -*-
"""
@File        : agent_manager.py
@Date        : 2026/3/28
@Author      : cabin
"""
import threading
from typing import Optional

from cabin.agents.agent import Agent
from cabin.agents.agent_metadata import AgentMetadata
from cabin.memories.memory_manager import MemoryManager
from cabin.models.llm_client import LLMClient


class AgentManager:
    """
    Agent管理器
    """
    _instance: Optional['AgentManager'] = None
    _agent_instance_map: dict[str, Agent] = {}
    _agent_cls_map: dict[str, tuple[type[Agent], AgentMetadata, LLMClient, MemoryManager]] = {}
    _lock: threading.Lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        """
        双检锁机制
        """
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def clear(self):
        """
        清空注册的Agent
        """
        with self._lock:
            self._agent_cls_map.clear()
            self._agent_instance_map.clear()

    def register_agent_cls(self, agent_name, agent_cls: type[Agent], agent_metadata: AgentMetadata,
                           llm_client: LLMClient, memory: MemoryManager):
        """
        注册Agent cls
        """
        with self._lock:
            self._agent_cls_map[agent_name] = (agent_cls, agent_metadata, llm_client, memory)

    def register_agent_instance(self, agent_name: str, agent: Agent):
        """
        注册Agent示例
        """
        with self._lock:
            self._agent_instance_map[agent_name] = agent

    def get(self, agent_name: str) -> Agent:
        """
        获取Agent实例，支持懒加载
        """
        # 如果实例缓存存在，直接返回
        if agent_name in self._agent_instance_map:
            return self._agent_instance_map.get(agent_name)

        # 如果实例缓存不存在，尝试从类缓存中加载
        agent_cls_tuple = self._agent_cls_map.get(agent_name)
        if agent_cls_tuple:
            with self._lock:
                # 双检锁机制，防止多线程同时创建实例
                if agent_name not in self._agent_instance_map:
                    agent = agent_cls_tuple[0]()
                    agent._metadata = agent_cls_tuple[1]
                    agent._llm_client = agent_cls_tuple[2]
                    agent._memory = agent_cls_tuple[3]
                    self._agent_instance_map[agent_name] = agent
            return agent

        raise ValueError(f'未找到Agent实例:{agent_name}')

    def get_total_count(self):
        """
        获取Agent总数(已实例化)
        """
        return len(self._agent_instance_map.keys())

    def get_available_agent_names(self):
        """
        获取可用Agent名称(已实例化)
        """
        return list(self._agent_instance_map.keys())


agent_manager = AgentManager()
