# -*- coding: utf-8 -*-
"""
@File        : agent_response.py
@Date        : 2026/3/28
@Author      : cabin
"""
from typing import Optional

from pydantic import BaseModel


class AgentResponse(BaseModel):
    """
    定义Agent出参
    """
    success: bool = True
    message: Optional[str] = None
    content: Optional[str] = None
