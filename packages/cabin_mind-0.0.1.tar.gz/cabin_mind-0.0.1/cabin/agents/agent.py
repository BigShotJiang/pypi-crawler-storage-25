#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@File        : agents.py
@Date        : 2026/3/3
@Author      : cabin
"""
import asyncio
from abc import ABC, abstractmethod

from cabin.agents.agent_metadata import AgentMetadata
from cabin.agents.agent_request import AgentRequest
from cabin.agents.agent_response import AgentResponse
from cabin.memories.memory_manager import MemoryManager
from cabin.models.llm_client import LLMClient


class Agent(ABC):
    """
    Agent 抽象基类
    """
    _metadata: AgentMetadata
    _llm_client: LLMClient
    _memory: MemoryManager

    def run(self, agent_input: AgentRequest, **kwargs) -> AgentResponse:
        """
        Agent的同步执行主流程
        """
        return asyncio.run(self.execute(agent_input, **kwargs))

    async def async_run(self, agent_input: AgentRequest, **kwargs) -> AgentResponse:
        """
        Agent的异步执行主流程
        """
        return await self.execute(agent_input, **kwargs)

    @abstractmethod
    async def execute(self, agent_input: AgentRequest, **kwargs) -> AgentResponse:
        """
        真实的执行方法
        """
        pass
