# -*- coding: utf-8 -*-
"""
@File        : agent_register.py
@Date        : 2026/3/28
@Author      : cabin
"""
import logging
import os.path
import sys

from cabin.agents.agent import Agent
from cabin.agents.agent_manager import agent_manager
from cabin.agents.agent_metadata import AgentMetadata, ModelConfig
from cabin.memories.memory_config import MemoryConfig
from cabin.memories.memory_manager import MemoryManager
from cabin.models.client_pool import client_pool
from cabin.models.llm_client import LLMClient
from cabin.rag.rag_config import RagConfig
from cabin.tools.rag_tool import RagTool
from cabin.tools.tool_manager import tool_manager
from cabin.utils.file_util import FileUtil
from cabin.utils.module_util import ModuleUtil

DEFAULT_EXCLUDE_DIRS = ['__pycache__', '.git', 'build', 'dist', 'env', 'venv', '.venv']

logger = logging.getLogger(__name__)


def _parse_yaml(path: str) -> tuple[str, None] | tuple[None, AgentMetadata]:
    """
    解析yaml配置文件
    """
    yaml_path = os.path.splitext(path)[0] + '.yaml'
    if not os.path.exists(yaml_path):
        return f'缺少yaml配置文件:{yaml_path}', None
    # 解析yaml配置文件
    agent_metadata = FileUtil.parse_yaml_to_agent_metadata(yaml_path)
    if agent_metadata is None:
        return f'解析yaml配置文件失败:{yaml_path}', None
        # 必须含agent_name
    if not agent_metadata.name:
        return f'缺少agent_name:{yaml_path}', None
    # 必须包含模型相关配置
    if not agent_metadata.model or not agent_metadata.model.name or not agent_metadata.model.api_key or not agent_metadata.model.base_url or not agent_metadata.model.client_path:
        return f'缺少模型相关配置:{yaml_path}', None
    return None, agent_metadata


def _init_memory(config: MemoryConfig, llm_client: LLMClient, model_config: ModelConfig) -> tuple[None, None] | tuple[
    None, MemoryManager] | tuple[str, None]:
    """
    初始化Memory
    """
    if config is None:
        return None, None
    try:
        return None, MemoryManager(config, llm_client, model_config)
    except Exception as e:
        return str(e), None


def _init_rag(metadata: AgentMetadata):
    """
    初始化RAG
    """
    try:
        rag_config: RagConfig = metadata.rag
        rag_tool = RagTool(rag_config)
        # 注册工具
        tool_manager.register_tool_instance(rag_config.name, rag_tool)
        # 挂载RAG
        metadata.tools.append(rag_config.name)
    except Exception as e:
        raise e


class AgentRegister:
    """
    Agent注册器
    """

    def __init__(self, base_path: list[str], exclude_dirs: list[str] = None, lazy_load: bool = False):
        self.base_path = base_path
        self.exclude_dirs = exclude_dirs or DEFAULT_EXCLUDE_DIRS
        self.lazy_load = lazy_load

    def register(self):
        """
        注册Agent
        """
        logger.info('=' * 30 + f'> 开始进行Agent注册，当前模式：{"懒加载" if self.lazy_load else "非懒加载"} ')
        # 先清空
        agent_manager.clear()
        # 遍历路径
        for path in self.base_path:
            if not os.path.isdir(path):
                continue
            # 扫描遍历每个目录
            self._scan_register_dir(path)
        logger.info(f'当前已实例化Agent如下：{agent_manager.get_available_agent_names()}')
        logger.info('=' * 30 + f'> Agent注册结束，共实例化{agent_manager.get_total_count()}个')

    def _scan_register_dir(self, path):
        """
        扫描注册每个Agent
        """
        for cur_dir, dirs, files in os.walk(path):
            # 排除目录
            dirs[:] = [d for d in dirs if d not in self.exclude_dirs]
            # 遍历文件
            for file in files:
                # 排除非py文件
                if not file.endswith('.py') or file == '__init__.py':
                    continue
                # 扫描注册单个
                self._scan_single_agent(os.path.join(cur_dir, file))

    def _scan_single_agent(self, path):
        """
        扫描注册单个Agent
        """
        # 动态加载模块
        module_name = f'dynamic_agent_{hash(path)}'
        module = ModuleUtil.dynamic_load_module(module_name, path)
        if module is None:
            return

        # 遍历模块的所有属性
        has_valid_agent = False
        for item in dir(module):
            attr = getattr(module, item)
            # 过滤无需注册
            if not isinstance(attr, type) or not issubclass(attr, Agent) or attr is Agent:
                continue
            # 解析yaml
            error, agent_metadata = _parse_yaml(path)
            if agent_metadata is None:
                raise ValueError(error)
            # 实例化client
            llm_client = client_pool.get_client(agent_metadata.model)
            if llm_client is None:
                raise ValueError(f'实例化client失败:{agent_metadata.model.client_path}')
            # 实例化memory
            error, memory = _init_memory(agent_metadata.memory, llm_client, agent_metadata.model)
            if memory is None and error:
                raise ValueError(error)
            # rag工具注册 && 挂载agent
            if agent_metadata.rag:
                _init_rag(agent_metadata)
            # 如果是懒加载，则只注册cls
            if self.lazy_load:
                agent_manager.register_agent_cls(agent_metadata.name, attr, agent_metadata, llm_client, memory)
                has_valid_agent = True
                continue
            # 实例化Agent对象，并设置元数据
            agent_obj: Agent = attr()
            agent_obj._metadata = agent_metadata
            agent_obj._llm_client = llm_client
            agent_obj._memory = memory
            # 注册Agent
            agent_manager.register_agent_instance(agent_metadata.name, agent_obj)
            # 标记为有效
            has_valid_agent = True

        # 若无效，则删除模块，防止内存泄露
        if not has_valid_agent and module_name in sys.modules:
            del sys.modules[module_name]
