# -*- coding: utf-8 -*-
"""
@File        : agent_metadata.py
@Date        : 2026/3/28
@Author      : cabin
"""
from typing import Optional

from pydantic import BaseModel, ConfigDict

from cabin.memories.memory_config import MemoryConfig
from cabin.rag.rag_config import RagConfig


class ModelConfig(BaseModel):
    name: str
    api_key: str
    base_url: str
    timeout: int = 12000
    client_path: str
    temperature: float = 0.3

class AgentMetadata(BaseModel):
    """
    Agent的元数据
    """
    model_config = ConfigDict(
        frozen=True,
        arbitrary_types_allowed=True
    )
    # 基础信息
    name: str = None
    description: str = None
    prompt: str
    max_steps: Optional[int] = 50
    max_token: Optional[int] = None
    # 模型配置
    model: ModelConfig
    # 工具
    tools: Optional[list[str]] = []
    # 记忆配置
    memory: Optional[MemoryConfig] = None
    # RAG 配置
    rag: Optional[RagConfig] = None
