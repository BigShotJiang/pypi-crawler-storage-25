# -*- coding: utf-8 -*-
"""
@File        : start_config.py
@Date        : 2026/4/5
@Author      : cabin
"""
from typing import Optional

from pydantic import BaseModel


class ToolConfig(BaseModel):
    """
    工具配置项
    """
    # 是否懒加载
    laze_load: bool = False
    # 加载路径
    load_path: Optional[list[str]] = None
    # 排除路径
    exclude_dirs: Optional[list[str]] = None


class AgentConfig(BaseModel):
    """
    Agent配置项
    """
    # 是否懒加载
    laze_load: bool = False
    # 加载路径
    load_path: Optional[list[str]] = None
    # 排除路径
    exclude_dirs: Optional[list[str]] = None


class StartConfig(BaseModel):
    """
    项目启动配置项
    """
    # 工具配置
    tool_config: ToolConfig
    # Agent配置
    agent_config: AgentConfig
