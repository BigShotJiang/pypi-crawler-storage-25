# logging_config.py
import logging
import sys
import colorlog


# 配置根日志记录器
def setup_logging():
    """
    配置彩色日志
    """
    # 创建一个handler，输出到控制台 (sys.stdout)
    console_handler = logging.StreamHandler(stream=sys.stdout)

    # 创建彩色格式化器
    # 参考 colorlog 官方文档配置 [citation:3]
    formatter = colorlog.ColoredFormatter(
        # 日志格式字符串
        # %(log_color)s 会根据级别自动添加颜色
        fmt='%(asctime)s - %(log_color)s%(levelname)s%(reset)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',  # 时间格式
        reset=True,  # 每条日志后重置颜色
        log_colors={  # 定义不同级别对应的颜色 [citation:3][citation:7]
            'DEBUG': 'cyan',
            'INFO': 'green',
            'WARNING': 'yellow',
            'ERROR': 'red',
            'CRITICAL': 'red,bg_white',  # 红字白底，醒目
        },
        secondary_log_colors={},  # 不需要二次颜色
        style='%'  # 使用 % 格式化风格
    )

    # 设置handler的格式化器
    console_handler.setFormatter(formatter)

    # 获取根日志记录器
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)

    # 清除已有的handler（避免重复）
    if root_logger.hasHandlers():
        root_logger.handlers.clear()

    # 添加新的handler
    root_logger.addHandler(console_handler)

    # 返回logger（可选）
    return root_logger


# 在模块加载时执行一次配置
setup_logging()
