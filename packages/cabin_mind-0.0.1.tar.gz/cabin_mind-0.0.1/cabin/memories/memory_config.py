# -*- coding: utf-8 -*-
"""
@File        : memory_config.py
@Date        : 2026/3/29
@Author      : cabin
"""
from pydantic import BaseModel


class ShortMemoryConfig(BaseModel):
    """
    短期记忆配置
    """
    # 存储的消息数
    max_len: int = 30
    # 消息过期时间，单位秒
    expired: int = 3600


class LongMemoryConfig(BaseModel):
    """
    长期记忆配置
    """
    # 向量数据库全类名
    vector_db_cls: str = 'vector.chroma_vector_db.ChromaVectorDB'
    # 向量数据库表名
    collection_name: str = 'default'
    # Embedding模型
    embedding_model: str = 'all-MiniLM-L6-v2'
    # 持久化目录地址
    persist_dir: str = './vector_db'
    # 是否本地Embedding模型
    local: bool = True
    # 存储分数阈值
    score_threshold: float = 0.7


class MemoryConfig(BaseModel):
    """
    Memory 配置
    """
    # 短期记忆开关
    short_memory_switch: bool = True
    # 长期记忆开关
    long_memory_switch: bool = True
    # 短期记忆配置
    short_memory: ShortMemoryConfig
    # 长期记忆配置
    long_memory: LongMemoryConfig
