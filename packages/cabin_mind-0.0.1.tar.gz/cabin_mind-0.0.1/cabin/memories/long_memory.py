# -*- coding: utf-8 -*-
"""
@File        : long_memory.py
@Date        : 2026/3/29
@Author      : cabin
"""
import threading
import time

from cabin.vector.vector_db_config import VectorDBConfig
from cabin.vector.vector_db_manager import vector_db_manager
from cabin.vector.vector_dto import VectorDTO
from cabin.memories.memory_config import LongMemoryConfig


class LongMemory:
    """
    长期记忆：存储用户维度向量化数据
    """

    def __init__(self, config: LongMemoryConfig):
        self.config = config
        vector_db_config = VectorDBConfig(
            vector_db_cls=self.config.vector_db_cls,
            collection_name=self.config.collection_name,
            embedding_model=self.config.embedding_model,
            persist_dir=self.config.persist_dir,
            local=self.config.local
        )
        self.vector_db = vector_db_manager.get_vector_db_instance(vector_db_config)
        self.lock = threading.Lock()

    def add(self, user_id: str, content: str, importance: float = 0.5):
        """
        添加长期记忆
        :param user_id: 用户ID
        :param content:内容
        :param importance: 重要性
        """
        with self.lock:
            metadata = {
                'userId': user_id,
                'importance': importance,
                'time': time.time()
            }
            self.vector_db.add(content, metadata)

    def get(self, user_id: str, query: str, top_k: int) -> list[VectorDTO]:
        """
        获取长期记忆
        :param user_id: 用户ID
        :param query: 查询内容
        :param top_k: 返回数量
        :return:
        """
        with self.lock:
            where = {
                'userId': user_id
            }
            return self.vector_db.retrieve(query, top_k, where)

    def clear(self, user_id: str):
        """
        清除长期记忆
        :param user_id: 用户ID
        """
        with self.lock:
            where = {
                "userId": user_id
            }
            self.vector_db.delete(where)

    def clear_all(self):
        """
        清除所有长期记忆
        """
        with self.lock:
            self.vector_db.clear()
