# -*- coding: utf-8 -*-
"""
@File        : short_memory.py
@Date        : 2026/3/29
@Author      : cabin
"""
import threading
import time
from typing import Any

from cabin.memories.memory_config import ShortMemoryConfig


class ShortMemory:
    """
    短期记忆：存储会话维度对话历史
    """

    def __init__(self, config: ShortMemoryConfig):
        self.config = config
        self.memory: dict[str, list[dict[str, Any]]] = {}
        self.lock = threading.Lock()

    def add(self, session_id: str, role: str, content: str):
        """
        添加短期记忆
        """
        # 构建记忆
        cur_message = {
            'role': role,
            'content': content,
            'time': time.time()
        }
        # 获取当前会话记忆
        memory_list = self.memory.get(session_id, [])
        # 添加当前消息
        memory_list.append(cur_message)
        # 如果超出限制长度，则剔除第一条
        if self.config.max_len and len(memory_list) > self.config.max_len:
            memory_list.pop(0)
        # 更新记忆
        with self.lock:
            self.memory[session_id] = memory_list

    def get(self, session_id: str):
        """
        获取短期记忆
        """
        with self.lock:
            # 获取会话短期记忆
            memory_list = self.memory.get(session_id, [])
            # 过期淘汰
            if self.config.expired:
                now = time.time()
                memory_list = [item for item in memory_list if now - item['time'] < self.config.expired]
                # 写回memory，实际上是一种懒删除
                self.memory[session_id] = memory_list
            return memory_list

    def clear(self, session_id: str):
        """
        清空短期记忆
        """
        with self.lock:
            if not self.memory and session_id in self.memory:
                del self.memory[session_id]

    def clear_all(self):
        """
        清空所有短期记忆
        """
        with self.lock:
            self.memory.clear()
