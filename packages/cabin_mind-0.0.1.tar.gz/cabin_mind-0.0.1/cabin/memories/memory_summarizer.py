# -*- coding: utf-8 -*-
"""
@File        : importance.py
@Date        : 2026/3/30
@Author      : cabin
"""
import logging
from typing import Optional

from cabin.agents.agent_metadata import ModelConfig
from cabin.models.llm_client import LLMClient
from cabin.models.llm_request import LLMRequest

logger = logging.getLogger(__name__)


class MemorySummarizer:
    """
    对内容进行总结提炼
    """
    _prompt = """
    我当前正在进行长期记忆存储，请对以下用户内容进行提炼总结，输出可长期保存的精简信息：
    
    用户内容：{text}
    结果：
    """

    def __init__(self, llm_client: LLMClient, model_config: ModelConfig):
        self.llm_client = llm_client
        self.model_config = model_config

    async def llm_summary(self, text: str) -> Optional[str]:
        """
        长期记忆摘要
        """
        try:
            llm_request: LLMRequest = LLMRequest(
                model=self.model_config.name,
                messages=[{"role": "user", "content": MemorySummarizer._prompt.format(text=text)}],
                timeout=self.model_config.timeout
            )
            response = await self.llm_client.async_invoke(llm_request)
            if not response.success or not response.content:
                logger.error(f"llm_summary error: {response.message}")
                return None
            return response.content
        except Exception as e:
            logger.error(f"llm_summary error: {str(e)}")
            return None
