# -*- coding: utf-8 -*-
"""
@File        : importance.py
@Date        : 2026/3/30
@Author      : cabin
"""
import logging

from cabin.agents.agent_metadata import ModelConfig
from cabin.models.llm_client import LLMClient
from cabin.models.llm_request import LLMRequest

logger = logging.getLogger(__name__)


class MemoryScorer:
    """
    长期记忆打分
    """
    _prompt = """
    请评估以下用户内容是否值得长期记忆，仅输出0~1的小数：
    0~0.3：闲聊、无意义
    0.4~0.6：普通对话
    0.7~1.0：重要信息(用户偏好、信息、目标、身份等)
    
    用户内容：{text}
    分数：
    """

    def __init__(self, llm_client: LLMClient, model_config: ModelConfig):
        self.llm_client = llm_client
        self.model_config = model_config

    async def llm_score(self, text: str) -> float:
        """
        长期记忆进行打分
        """
        try:
            llm_request: LLMRequest = LLMRequest(
                model=self.model_config.name,
                messages=[{"role": "user", "content": MemoryScorer._prompt.format(text=text)}],
                timeout=self.model_config.timeout
            )
            response = await self.llm_client.async_invoke(llm_request)
            if not response.success or not response.content:
                logger.error(f"llm_score error: {response.message}")
                return 0.5
            return float(response.content)
        except Exception as e:
            logger.error(f"llm_score error: {str(e)}")
            return 0.5
