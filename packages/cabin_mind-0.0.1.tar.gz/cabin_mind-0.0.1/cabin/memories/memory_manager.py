# -*- coding: utf-8 -*-
"""
@File        : memory_manager.py
@Date        : 2026/3/29
@Author      : cabin
"""
from cabin.agents.agent_metadata import ModelConfig
from cabin.memories.long_memory import LongMemory
from cabin.memories.memory_config import MemoryConfig
from cabin.memories.memory_scorer import MemoryScorer
from cabin.memories.memory_summarizer import MemorySummarizer
from cabin.memories.short_memory import ShortMemory
from cabin.models.llm_client import LLMClient


class MemoryManager:
    """
    Memory 管理器
    """

    def __init__(self, config: MemoryConfig, llm_client: LLMClient, model_config: ModelConfig):
        if not config:
            raise ValueError("MemoryConfig is None")
        self.config = config
        # 初始化短期记忆
        self.short_memory = ShortMemory(self.config.short_memory) if self.config.short_memory_switch else None
        # 初始化长期记忆
        if self.config.long_memory_switch:
            self.long_memory = LongMemory(self.config.long_memory)
            self.scorer = MemoryScorer(llm_client, model_config)
            self.summarizer = MemorySummarizer(llm_client, model_config)

    async def add_memory(self, user_id: str, session_id, role: str, content: str):
        """
        添加记忆
        """
        # 添加短期记忆
        if self.short_memory:
            self.short_memory.add(session_id, role, content)

        # 未开启长期记忆
        if self.long_memory is None:
            return

        # 非用户话术
        if role != "user":
            return

        # 打分
        score = await self.scorer.llm_score(content)
        if score < self.config.long_memory.score_threshold:
            return

        # 总结
        summary = await self.summarizer.llm_summary(content)
        if summary is None:
            return

        # 去重
        if self._is_duplicate(user_id, content):
            return

        # 存储长期记忆
        self.long_memory.add(user_id, summary, score)

    def get_short_memory(self, session_id):
        """
        获取短期记忆
        """
        if self.short_memory is None:
            raise ValueError("short memory is not activated")
        short_messages = self.short_memory.get(session_id)
        if len(short_messages) == 0:
            return '无历史对话记录'
        return "\n\n".join([f"{message['role']}: {message['content']}" for message in short_messages])

    def get_long_memory(self, user_id: str, query: str, top_k: int = 5):
        """
        获取长期记忆
        """
        if self.long_memory is None:
            raise ValueError("long memory is not activated")
        long_messages = self.long_memory.get(user_id, query, top_k)
        if len(long_messages) == 0:
            return '无长期记忆'
        return "\n".join([f"{message.content}" for message in long_messages])

    def get_memory(self, user_id: str, session_id, query: str, top_k: int = 5):
        """
        获取记忆
        """
        if not self.short_memory or not self.long_memory:
            raise ValueError("memory is not activated")
        return {
            'short_memory': self.get_short_memory(session_id),
            'long_memory': self.get_long_memory(user_id, query, top_k)
        }

    def _is_duplicate(self, user_id: str, content: str) -> bool:
        """
        是否重复
        """
        if self.long_memory is None:
            return True
        messages = self.long_memory.get(user_id, content, 2)
        return any(message["content"] == content for message in messages)
