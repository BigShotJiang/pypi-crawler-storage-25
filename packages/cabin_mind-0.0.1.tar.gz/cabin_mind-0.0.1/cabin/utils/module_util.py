# -*- coding: utf-8 -*-
"""
@File        : module_util.py
@Date        : 2026/3/28
@Author      : cabin
"""
import logging
import sys
from importlib import util
from types import ModuleType
from typing import Optional

logger = logging.getLogger(__name__)


class ModuleUtil:
    """
    模块工具类
    """

    @staticmethod
    def dynamic_load_module(module_name: str, file_path: str) -> Optional[ModuleType]:
        """
        动态加载模块
        """
        try:
            # 生成一个唯一的模块名（基于文件路径）
            spec = util.spec_from_file_location(module_name, file_path)
            if spec is None or spec.loader is None:
                raise ImportError(f"无法从 {file_path} 创建模块 spec")
            # 确保模块不在sys.modules中
            if module_name in sys.modules:
                del sys.modules[module_name]
            # 加载模块
            module = util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module
        except Exception as e:
            logger.warning(f'动态加载模块失败，模块名:{module_name}')
            return None

    @staticmethod
    def get_cls_by_path(class_path: str) -> Optional[type]:
        """
        根据类路径获取cls对象
        """
        try:
            module, class_name = class_path.rsplit('.', 1)
            module = __import__(module, fromlist=[class_name])
            return getattr(module, class_name)
        except Exception as e:
            logger.warning(f'根据类路径获取cls对象失败，类路径:{class_path}')
            return None

