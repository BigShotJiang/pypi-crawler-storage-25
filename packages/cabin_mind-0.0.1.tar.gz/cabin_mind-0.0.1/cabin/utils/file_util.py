# -*- coding: utf-8 -*-
"""
@File        : file_util.py
@Date        : 2026/3/28
@Author      : cabin
"""
import hashlib
import logging
from typing import Optional

import yaml

from cabin.agents.agent_metadata import AgentMetadata

logger = logging.getLogger(__name__)

class FileUtil:
    """
    文件工具类
    """

    @staticmethod
    def parse_yaml_to_agent_metadata(path: str) -> Optional[AgentMetadata]:
        """
        解析yaml文件为AgentMetadata对象
        """
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return AgentMetadata(**yaml.safe_load(f))
        except Exception as e:
            logger.warning(f'解析yaml文件失败: {str(e)}')
            return None

    @staticmethod
    def generate_unique_id(path: str) -> str:
        """
        生成唯一ID
        """
        md5 = hashlib.md5()
        with open(path, 'rb') as f:
            while True:
                data = f.read(4096)
                if not data:
                    break
                md5.update(data)
        return md5.hexdigest()
