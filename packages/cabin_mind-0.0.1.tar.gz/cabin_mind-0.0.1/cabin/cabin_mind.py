# -*- coding: utf-8 -*-
"""
@File        : cabin_mind.py
@Date        : 2026/4/5
@Author      : cabin
"""
import logging
import os

import yaml

from cabin.agents.agent_register import AgentRegister
from cabin.configs.start_config import StartConfig
from cabin.tools.tool_register import ToolRegister

logger = logging.getLogger(__name__)


def _convert_to_absolute_paths(base_dir: str, paths: list) -> list:
    """
    相对路径转绝对路径
    """
    return [
        os.path.join(base_dir, path)
        if not os.path.isabs(path)
        else path
        for path in paths
    ]


def _validate_config_path(config_path: str) -> str:
    """
    配置路径校验
    """
    if not config_path:
        raise ValueError('config path is empty')
    abs_config_path = os.path.abspath(config_path)
    if not os.path.exists(abs_config_path):
        raise ValueError(f'config file not found: {config_path}')
    return abs_config_path


def _register_agents(start_config: StartConfig, config_dir: str):
    """
    Agent注册
    """
    if start_config.agent_config and start_config.agent_config.load_path:
        abs_load_path = _convert_to_absolute_paths(
            config_dir,
            start_config.agent_config.load_path
        )
        lazy_load = start_config.agent_config.laze_load
        exclude_dirs = start_config.agent_config.exclude_dirs
        AgentRegister(base_path=abs_load_path, exclude_dirs=exclude_dirs, lazy_load=lazy_load).register()


def _register_tools(start_config: StartConfig, config_dir: str):
    """
    工具注册
    """
    if start_config.tool_config and start_config.tool_config.load_path:
        abs_load_path = _convert_to_absolute_paths(
            config_dir,
            start_config.tool_config.load_path
        )
        lazy_load = start_config.tool_config.laze_load
        exclude_dirs = start_config.tool_config.exclude_dirs
        ToolRegister(base_path=abs_load_path, exclude_dirs=exclude_dirs, lazy_load=lazy_load).register()


def _parse_config_path(config_path: str) -> tuple[StartConfig, str]:
    """
    配置文件验证解析
    """
    # 配置路径校验
    abs_config_path = _validate_config_path(config_path)
    # 配置文件解析
    start_config: StartConfig = StartConfig(**yaml.safe_load(open(abs_config_path, 'r', encoding='utf-8')))
    if not start_config:
        raise ValueError(f'config path parse fail: {config_path}')
    # 获取根路径
    config_dir = os.path.dirname(abs_config_path)
    return start_config, config_dir


class CabinMind:

    @classmethod
    def start(cls, config_path: str):
        """
        初始化
        """
        try:
            # 配置文件验证解析
            config_dir, start_config = _parse_config_path(config_path)
            # 工具扫描注册
            _register_tools(config_dir, start_config)
            # Agent扫描注册
            _register_agents(config_dir, start_config)
        except Exception as e:
            logger.error(f'CabinMind Start Fail，{str(e)}')
            raise e
