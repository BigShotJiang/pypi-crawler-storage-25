# -*- coding: utf-8 -*-
"""
@File        : client_pool.py
@Date        : 2026/3/29
@Author      : cabin
"""
import logging
import threading
from typing import Optional

from cabin.agents.agent_metadata import ModelConfig
from cabin.models.llm_client import LLMClient
from cabin.utils.module_util import ModuleUtil

logger = logging.getLogger(__name__)


def _generate_cache_key(model_config: ModelConfig) -> str:
    return f'{model_config.client_path}-{model_config.api_key}-{model_config.base_url}'


class ClientPool:
    """
    模型客户端池化管理
    """

    _instance: Optional['ClientPool'] = None
    _client_map: dict[str, LLMClient] = {}
    _lock: threading.Lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def get_client(self, model_config: ModelConfig) -> Optional[LLMClient]:
        """
        获取模型客户端
        """
        # 根据模型配置生成唯一cacheKey
        cache_key = _generate_cache_key(model_config)
        # 查询缓存
        if cache_key not in self._client_map:
            # 获取类对象
            cls = ModuleUtil.get_cls_by_path(model_config.client_path)
            # 实例化类对象
            if not cls:
                raise ValueError(f'未找到类对象: {model_config.client_path}')
            llm_client = cls(api_key=model_config.api_key, base_url=model_config.base_url)
            # 存入缓存
            self._client_map[cache_key] = llm_client
        # 存在直接返回
        return self._client_map[cache_key]


client_pool = ClientPool()
