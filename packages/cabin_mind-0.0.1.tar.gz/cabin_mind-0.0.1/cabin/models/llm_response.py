# -*- coding: utf-8 -*-
"""
@File        : llm_response.py
@Date        : 2026/3/28
@Author      : cabin
"""
from typing import Any, Optional

from pydantic import BaseModel

from cabin.tools.tool_call import ToolCall


class LLMResponse(BaseModel):
    """
    定义模型的统一输出
    """
    success: bool = True,
    message: Optional[str] = None,
    content: Optional[str] = None,
    model: Optional[str] = None,
    raw: Optional[Any] = None,
    id: Optional[str] = None,
    finish_reason: Optional[str] = None
    # function call 工具输出
    tool_calls: list[ToolCall] = None
