#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@File        : openai_client.py
@Date        : 2026/3/3
@Author      : cabin
"""
import json
import logging
from collections.abc import AsyncGenerator
from typing import get_args, get_type_hints, get_origin, Literal, Any, Type, List

from openai import AsyncOpenAI, OpenAI
from openai.types.chat import ChatCompletionMessageParam, ChatCompletionMessageToolCallUnion

from cabin.models.llm_client import LLMClient
from cabin.models.llm_request import LLMRequest
from cabin.models.llm_response import LLMResponse
from cabin.models.llm_stream_chunk import LLMStreamChunk
from cabin.tools.tool_call import ToolCall, FunctionCall

logger = logging.getLogger(__name__)


# =================== 常量定义 ================ #
def get_all_roles() -> dict[str, Type[Any]]:
    message_type = {}
    union_types = get_args(ChatCompletionMessageParam)
    for union_type in union_types:
        type_hints = get_type_hints(union_type)
        if 'role' in type_hints:
            role = type_hints['role']
            if get_origin(role) is Literal:
                for role_type in get_args(role):
                    message_type[role_type] = union_type
    return message_type


ALL_MESSAGE_TYPE: dict[str, Type[Any]] = get_all_roles()


# =================== 消息列表转换 ============= #
def _convert_llm_message(messages: list[dict[str, str]]) -> list[ChatCompletionMessageParam]:
    """
    消息转换
    """
    result = []
    for message in messages:
        if 'role' not in message:
            raise ValueError('Missing "role" in message')
        if message['role'] not in ALL_MESSAGE_TYPE.keys():
            raise ValueError('Unknown "role" in message')
        result.append(ALL_MESSAGE_TYPE[message['role']](**message))
    return result


def _parse_tool_calls(llm_tool_calls: List[ChatCompletionMessageToolCallUnion]) -> list[ToolCall]:
    """
    Tool Call 解析
    """
    tool_calls = []
    if not llm_tool_calls or len(llm_tool_calls) == 0:
        return tool_calls
    for tool_call in llm_tool_calls:
        tool_calls.append(
            ToolCall(
                id=tool_call.id,
                type=tool_call.type,
                function=FunctionCall(
                    name=tool_call.function.name,
                    arguments=tool_call.function.arguments
                )
            )
        )
    return tool_calls


def _parse_stream_tool_calls(tool_map: dict[int, dict[str, Any]]) -> list[ToolCall]:
    """
    解析流式输出的工具调用
    """
    result: list[ToolCall] = []
    for idx in sorted(tool_map.keys()):
        data = tool_map[idx]
        name = data.get("name") or ""
        if not name:
            continue
        args = data.get("arguments") or "{}"
        result.append(
            ToolCall(
                id=data.get("id") or "",
                type="function",
                function=FunctionCall(name=name, arguments=args),
            )
        )
    return result


class OpenAIClient(LLMClient):
    """
    通用的模型客户端
    """

    def __init__(self, api_key: str, base_url: str):
        super().__init__(api_key, base_url)
        self.client = OpenAI(api_key=api_key, base_url=base_url)
        self.async_client = AsyncOpenAI(api_key=api_key, base_url=base_url)

    async def execute(self, llm_request: LLMRequest) -> LLMResponse:
        """
        模型调用(同步、异步非流式)
        """
        if not llm_request or not llm_request.model or len(llm_request.messages) == 0:
            raise ValueError('Miss Required Parameter')
        try:
            # 参数转换
            llm_input = _convert_llm_message(llm_request.messages)
            # 模型调用
            response = self.client.chat.completions.create(
                messages=llm_input,
                model=llm_request.model,
                temperature=llm_request.temperature,
                timeout=llm_request.timeout,
                stream=False,
                tools=llm_request.tools
            )
            # 组装返回结果
            llm_response = LLMResponse()
            llm_response.success = True
            llm_response.id = response.id
            llm_response.model = response.model
            llm_response.finish_reason = response.choices[0].finish_reason
            message = response.choices[0].message
            if message:
                llm_response.content = message.content
                llm_response.tool_calls = _parse_tool_calls(message.tool_calls)
                llm_response.message = message.model_dump_json()
            return llm_response
        except Exception as e:
            logger.error(f'Llm Invoke Failed: {str(e)}')
            return LLMResponse(success=False, message=str(e))

    async def stream_execute(self, llm_request: LLMRequest) -> AsyncGenerator[LLMStreamChunk, None]:
        """
        流式模型调用(同步、异步流式)
        """
        if not llm_request or not llm_request.model or len(llm_request.messages) == 0:
            raise ValueError('Miss Required Parameter')
        try:
            # 参数转换
            llm_input = _convert_llm_message(llm_request.messages)
            # 流式调用
            stream = await self.async_client.chat.completions.create(
                messages=llm_input,
                model=llm_request.model,
                temperature=llm_request.temperature,
                timeout=llm_request.timeout,
                stream=True,
                tools=llm_request.tools
            )
        except Exception as e:
            logger.error(f'Llm Stream Invoke Failed: {str(e)}')
            yield LLMStreamChunk(
                is_final=True,
                final_response=LLMResponse(success=False, message=str(e)),
            )
            return

        # 解析流式输出，yield返回每个chunk
        accumulated_content = ""
        tool_map: dict[int, dict[str, str]] = {}
        finish_reason = ""
        response_id = ""
        response_model = ""

        async for chunk in stream:
            if not chunk:
                continue
            if chunk.id:
                response_id = chunk.id
            if chunk.model:
                response_model = chunk.model
            if not chunk.choices:
                continue
            choice = chunk.choices[0]
            if not choice:
                continue
            if not choice.delta:
                continue
            delta = choice.delta
            if delta.content:
                accumulated_content += delta.content
                yield LLMStreamChunk(
                    delta_content=delta.content,
                    accumulated_content=accumulated_content,
                )
            if delta.tool_calls:
                for tool in delta.tool_calls:
                    idx = tool.index
                    if idx not in tool_map:
                        tool_map[idx] = {"id": "", "name": "", "arguments": ""}
                    if tool.id:
                        tool_map[idx]["id"] = tool.id
                    function = tool.function
                    if function:
                        if function.name:
                            tool_map[idx]["name"] = function.name
                        if function.arguments:
                            tool_map[idx]["arguments"] = tool_map[idx].get("arguments", "") + function.arguments

            if choice.finish_reason:
                finish_reason = choice.finish_reason

        # 整个流式执行结束，返回完整的数据
        tool_calls = _parse_stream_tool_calls(tool_map)

        llm_message: dict[str, Any] = {
            "role": "assistant",
            "content": accumulated_content if accumulated_content else None,
            "tool_calls": [tool_call.model_dump() for tool_call in tool_calls]
        }

        llm_response = LLMResponse(
            success=True,
            id=response_id,
            model=response_model,
            finish_reason=finish_reason,
            content=accumulated_content if accumulated_content else None,
            tool_calls=tool_calls if tool_calls else None,
            message=json.dumps(llm_message, ensure_ascii=False),
        )

        yield LLMStreamChunk(
            is_final=True,
            final_response=llm_response
        )
