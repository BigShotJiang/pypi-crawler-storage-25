# -*- coding: utf-8 -*-
"""
@File        : llm_request.py
@Date        : 2026/3/29
@Author      : cabin
"""
from typing import Any

from pydantic import BaseModel


class LLMRequest(BaseModel):
    """
    定义模型的输入参数
    """
    model: str
    messages: list[dict[str, str]]
    temperature: float = 0.3
    timeout: int = 60
    # tools 支持function call
    tools: list[dict[str, Any]] = None
