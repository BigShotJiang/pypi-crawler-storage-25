# -*- coding: utf-8 -*-
"""
流式输出分片（单轮 LLM 调用内的 token / delta）
"""
from typing import Optional

from pydantic import BaseModel

from cabin.models.llm_response import LLMResponse


class LLMStreamChunk(BaseModel):
    """
    流式分片：中间片仅有 delta；最后一片 is_final=True 并携带完整 LLMResponse。
    """
    delta_content: Optional[str] = None
    accumulated_content: str = ""
    is_final: bool = False
    final_response: Optional[LLMResponse] = None
