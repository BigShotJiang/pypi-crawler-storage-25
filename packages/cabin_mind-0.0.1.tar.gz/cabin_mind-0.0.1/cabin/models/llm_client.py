# -*- coding: utf-8 -*-
"""
@File        : llm_client.py
@Date        : 2026/3/29
@Author      : cabin
"""
import asyncio
import inspect
from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator, AsyncIterable
from typing import Callable, Optional, cast

from cabin.models.llm_request import LLMRequest
from cabin.models.llm_response import LLMResponse
from cabin.models.llm_stream_chunk import LLMStreamChunk


class LLMClient(ABC):
    """
    模型客户端的基类
    """

    def __init__(self, api_key: str, base_url: str):
        self.api_key = api_key
        self.base_url = base_url
        if not self.api_key or not self.base_url:
            raise ValueError("api_key and base_url must be set")

    def invoke(self, llm_request: LLMRequest) -> LLMResponse:
        """
        同步非流式模型调用
        """
        return asyncio.run(self.execute(llm_request))

    async def async_invoke(self, llm_request: LLMRequest) -> LLMResponse:
        """
        异步非流式模型调用
        """
        return await self.execute(llm_request)

    async def async_stream_invoke(
            self,
            llm_request: LLMRequest,
            on_delta: Optional[Callable[[str], object]] = None,
    ) -> LLMResponse:
        """
        异步流式模型调用
        """
        final: Optional[LLMResponse] = None
        # PyCharm/Pylance 常把「async def + 注解 AsyncGenerator」误判为 Coroutine；cast 为 AsyncIterable 与 async for 语义一致
        stream_iterable = cast(
            AsyncIterable[LLMStreamChunk],
            self.stream_execute(llm_request),
        )
        async for chunk in stream_iterable:
            if chunk.delta_content and on_delta:
                maybe = on_delta(chunk.delta_content)
                if inspect.isawaitable(maybe):
                    await maybe
            if chunk.is_final and chunk.final_response is not None:
                final = chunk.final_response
        if final is None:
            return LLMResponse(success=False, message="流式输出未返回完整响应")
        return final

    @abstractmethod
    async def execute(self, llm_request: LLMRequest) -> LLMResponse:
        """
        执行模型调用
        """
        pass

    async def stream_execute(self, llm_request: LLMRequest) -> AsyncGenerator[LLMStreamChunk, None]:
        """
        流式调用：子类应 override 为 async generator。
        基类用 raise + yield 形成异步生成器，避免被误判为「返回 Coroutine 的普通 async def」。
        """
        raise NotImplementedError(f"{self.__class__.__name__} 未实现 stream_execute")
        yield LLMStreamChunk()  # noqa: unreachable
