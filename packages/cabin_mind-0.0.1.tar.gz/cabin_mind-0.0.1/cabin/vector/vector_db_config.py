# -*- coding: utf-8 -*-
"""
@File        : vector_db_config.py
@Date        : 2026/3/29
@Author      : cabin
"""
from pydantic import BaseModel


class VectorDBConfig(BaseModel):
    """
    向量数据库配置
    """
    # 向量数据库全类名
    vector_db_cls: str
    # 向量数据库表名
    collection_name: str
    # Embedding模型
    embedding_model: str
    # 持久化目录地址
    persist_dir: str
    # 是否本地Embedding模型
    local: bool
