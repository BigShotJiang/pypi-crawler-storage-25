# -*- coding: utf-8 -*-
"""
@File        : vector_db_manager.py
@Date        : 2026/3/29
@Author      : cabin
"""
import threading
from typing import Optional

from cabin.vector.base_vector_db import BaseVectorDB
from cabin.vector.vector_db_config import VectorDBConfig
from cabin.utils.module_util import ModuleUtil


def _generate_cache_key(config: VectorDBConfig):
    """
    唯一键生成
    """
    return f'{config.vector_db_cls}-{config.collection_name}-{config.persist_dir}-{config.local}'


class VectorDBManager:
    """
    向量数据库管理器
    """
    _instance: Optional['VectorDBManager'] = None
    # 存储实例
    _vector_db_instance_map: dict[str, BaseVectorDB] = {}
    # 锁
    _lock: threading.Lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        """
        双检锁机制
        """
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def get_vector_db_instance(self, config: VectorDBConfig) -> BaseVectorDB:
        """
        获取实例
        """
        # 生成唯一键
        cache_key = _generate_cache_key(config)
        # 不存在，则实例化
        if cache_key not in self._vector_db_instance_map:
            vector_cls = ModuleUtil.get_cls_by_path(config.vector_db_cls)
            if not vector_cls:
                raise ValueError(f'未找到向量数据库类：{config.vector_db_cls}')
            vector_db_instance = vector_cls(config)
            self._vector_db_instance_map[cache_key] = vector_db_instance
        return self._vector_db_instance_map[cache_key]


vector_db_manager = VectorDBManager()
