# -*- coding: utf-8 -*-
"""
@File        : base_vector_db.py
@Date        : 2026/3/29
@Author      : cabin
"""
from abc import ABC, abstractmethod
from typing import Optional, Any

from cabin.vector.vector_db_config import VectorDBConfig
from cabin.vector.vector_dto import VectorDTO


class BaseVectorDB(ABC):
    """
    向量数据库基类
    """

    def __init__(self, config: VectorDBConfig):
        """
        初始化向量数据库
        """
        self.config = config

    @abstractmethod
    def add(self, text: str, metadata: Optional[dict[str, Any]] = None):
        """
        添加向量
        :param text: 文本
        :param metadata: 元数据
        """
        pass

    @abstractmethod
    def add_batch(self, texts: list[str], metadatas: Optional[list[dict[str, Any]]] = None):
        """
        批量添加向量
        """
        pass

    @abstractmethod
    def retrieve(self, query: str, top_k: int = 5, where: Optional[dict[str, Any]] = None) -> list[VectorDTO]:
        """
        检索向量
        :param query: 查询文本
        :param top_k: 返回数量
        :param where: 过滤条件
        :return: 检索结果
        """
        pass

    @abstractmethod
    def delete(self, where: Optional[dict[str, Any]]):
        """
        根据条件删除向量
        :param where:  过滤条件
        """
        pass

    @abstractmethod
    def clear(self):
        """
        清空向量
        """
        pass

    @abstractmethod
    def exist(self, doc_id) -> bool:
        """
        判断文档是否存在
        """
        pass
