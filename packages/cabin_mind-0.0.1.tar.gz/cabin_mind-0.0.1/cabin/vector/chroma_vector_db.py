# -*- coding: utf-8 -*-
"""
@File        : chroma_vector_db.py
@Date        : 2026/3/29
@Author      : cabin
"""
import threading
import uuid
from typing import Optional, Any

import chromadb
from chromadb import ClientAPI
from chromadb.utils import embedding_functions

from cabin.vector.base_vector_db import BaseVectorDB
from cabin.vector.vector_db_config import VectorDBConfig
from cabin.vector.vector_dto import VectorDTO


class ChromaVectorDB(BaseVectorDB):
    """
    Chroma 向量数据库
    """

    # 保证DB的Client在同dir下是单例模式
    _client_cache_map: dict[str, ClientAPI] = {}
    _lock: threading.Lock = threading.Lock()

    def __init__(self, config: VectorDBConfig):
        """
        初始化向量数据库
        :param config: 向量数据库配置
        """
        super().__init__(config)
        # 初始化客户端
        self.client = self._client_cache_map.get(self.config.persist_dir, None)
        if self.client is None:
            with self._lock:
                if self.config.persist_dir not in self._client_cache_map:
                    self.client = chromadb.PersistentClient(path=self.config.persist_dir)
                    self._client_cache_map[self.config.persist_dir] = self.client
        # 嵌入模型，区分本地和云端
        if self.config.local:
            self.embedding_function = embedding_functions.SentenceTransformerEmbeddingFunction(
                model_name=self.config.embedding_model)
        else:
            pass
        # 初始化集合表，collection_name和embedding必须是配对的不能错乱
        self.collection = self.client.get_or_create_collection(
            name=self.config.collection_name,
            embedding_function=self.embedding_function
        )
        self.lock = threading.Lock()

    def add(self, text: str, metadata: Optional[dict[str, Any]] = None):
        """
        添加向量
        :param text: 文本
        :param metadata: 元数据
        """
        with self.lock:
            self.collection.add(
                ids=str(uuid.uuid4()),
                documents=text,
                metadatas=metadata
            )

    def add_batch(self, texts: list[str], metadatas: Optional[list[dict[str, Any]]] = None):
        """
        批量添加向量
        :param texts: 文本列表
        :param metadatas: 元数据列表
        """
        with self.lock:
            self.collection.add(
                ids=[str(uuid.uuid4()) for _ in texts],
                documents=texts,
                metadatas=metadatas
            )

    def retrieve(self, query: str, top_k: int = 5, where: Optional[dict[str, Any]] = None) -> \
            list[VectorDTO]:
        """
        检索向量
        :param query: 查询文本
        :param top_k: 返回数量
        :param where: 过滤条件
        :return: 检索结果
        """
        with self.lock:
            query_result = self.collection.query(
                query_texts=query,
                n_results=top_k,
                where=where
            )
            result = []
            # 遍历填充
            for idx, doc, distance, metadata in zip(
                    query_result.get('ids', [])[0],
                    query_result.get('documents', [])[0],
                    query_result.get('distances', [])[0],
                    query_result.get('metadatas', [])[0]):
                result.append(
                    VectorDTO(id=idx, content=doc, distance=distance, metadata=metadata, score=1 / (distance + 1) * 100)
                )
            return result

    def delete(self, where: Optional[dict[str, Any]]):
        """
        根据条件删除向量
        :param where:  过滤条件
        """
        with self.lock:
            self.collection.delete(where=where)

    def clear(self):
        """
        清空向量
        """
        with self.lock:
            self.collection.delete()

    def exist(self, doc_id) -> bool:
        """
        判断文档是否存在
        """
        metadata = {
            'doc_id': doc_id
        }
        with self.lock:
            result = self.collection.get(where=metadata)
            if not result:
                return False
            documents = result.get('documents', [])
            return len(documents) > 0
