# -*- coding: utf-8 -*-
"""
@File        : vector_dto.py
@Date        : 2026/3/29
@Author      : cabin
"""
from typing import Optional, Any

from pydantic import BaseModel


class VectorDTO(BaseModel):
    """
    向量数据返回的结果
    """
    id: str
    content: str
    score: float
    distance: float
    metadata: Optional[dict[str, Any]] = None
