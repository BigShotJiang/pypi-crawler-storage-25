#!/usr/bin/env python3
"""Tap CLI - Python wrapper for the tap binary."""

import os
import sys
import platform
import subprocess
import urllib.request
import urllib.error
import json
from pathlib import Path

VERSION = "0.14.1"
GITHUB_REPO = "LeonTing1010/tap"
NPM_REGISTRY = "https://registry.npmjs.org/@taprun/cli"
CACHE_DIR = Path.home() / ".tap" / "bin"


def get_platform_package():
    """Determine the correct npm package name for the current platform."""
    system = platform.system().lower()
    machine = platform.machine().lower()
    
    if system == "darwin":
        if machine in ("arm64", "aarch64"):
            return "cli-darwin-arm64"
        else:
            return "cli-darwin-x64"
    elif system == "linux":
        return "cli-linux-x64"
    elif system == "windows":
        return "cli-win32-x64"
    else:
        raise RuntimeError(f"Unsupported platform: {system} {machine}")


def get_binary_name():
    """Get the binary name for the current platform."""
    system = platform.system().lower()
    if system == "windows":
        return "tap.exe"
    return "tap"


def download_from_npm():
    """Download the tap binary from npm registry."""
    package = get_platform_package()
    binary_name = get_binary_name()
    
    # Get package metadata from npm
    npm_url = f"https://registry.npmjs.org/@taprun/{package}"
    
    try:
        with urllib.request.urlopen(npm_url, timeout=30) as response:
            data = json.loads(response.read().decode('utf-8'))
        
        # Get the latest version's tarball URL
        latest_version = data.get('dist-tags', {}).get('latest', VERSION)
        version_data = data.get('versions', {}).get(latest_version, {})
        tarball_url = version_data.get('dist', {}).get('tarball', '')
        
        if not tarball_url:
            raise RuntimeError(f"Could not find tarball URL for {package}@{latest_version}")
        
        print(f"Downloading tap {latest_version} for your platform...")
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        
        # Download tarball
        import tarfile
        import tempfile
        
        with tempfile.NamedTemporaryFile(suffix='.tgz', delete=False) as tmp:
            urllib.request.urlretrieve(tarball_url, tmp.name)
            
            # Extract the binary
            with tarfile.open(tmp.name, 'r:gz') as tar:
                # Find the binary in the package
                for member in tar.getmembers():
                    if member.name.endswith(f'bin/{binary_name}') or member.name.endswith(binary_name):
                        # Extract to cache dir
                        extracted = tar.extract(member, CACHE_DIR)
                        # Get the actual file path
                        extracted_path = CACHE_DIR / member.name
                        final_path = CACHE_DIR / binary_name
                        
                        # Move to final location if needed
                        if extracted_path != final_path:
                            extracted_path.rename(final_path)
                        
                        # Make executable on Unix systems
                        if platform.system() != "Windows":
                            final_path.chmod(0o755)
                        
                        # Cleanup temp files
                        os.unlink(tmp.name)
                        # Cleanup extracted directory structure
                        import shutil
                        pkg_dir = CACHE_DIR / "package"
                        if pkg_dir.exists():
                            shutil.rmtree(pkg_dir)
                        
                        print(f"Downloaded to {final_path}")
                        return final_path
        
        raise RuntimeError(f"Binary not found in package {package}")
        
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"Failed to download tap binary: HTTP {e.code}")
    except Exception as e:
        raise RuntimeError(f"Failed to download tap binary: {e}")


def get_binary_path():
    """Get the path to the tap binary, downloading if necessary.

    Resolution order (matches taprun.api._resolve_bin):
      1. TAPRUN_BIN env var (explicit override; e.g. brew-installed tap)
      2. ~/.tap/bin/tap (cached download from npm)
      3. Download from @taprun/cli-* npm registry → ~/.tap/bin/tap
    """
    explicit = os.environ.get("TAPRUN_BIN")
    if explicit:
        explicit_path = Path(explicit)
        if not explicit_path.is_file():
            raise RuntimeError(f"TAPRUN_BIN={explicit} does not exist")
        return explicit_path

    binary_name = get_binary_name()
    binary_path = CACHE_DIR / binary_name

    # Check if binary already exists
    if binary_path.exists():
        return binary_path

    # Download the binary from npm
    return download_from_npm()


def main():
    """Main entry point - proxy to the tap binary."""
    try:
        binary_path = get_binary_path()
        
        # Pass all arguments to the tap binary
        args = [str(binary_path)] + sys.argv[1:]
        
        # Execute the binary
        result = subprocess.run(args, check=False)
        sys.exit(result.returncode)
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
