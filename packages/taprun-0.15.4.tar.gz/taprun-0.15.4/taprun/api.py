"""Subprocess wrapper around the `tap` CLI.

Each public function shells out to the binary located via
`TAPRUN_BIN` env var or `tap` on PATH. Output is parsed as JSON
where the CLI supports `--json`; raw stdout otherwise.

Errors:
- `TapNotFoundError` when the `tap` binary cannot be located.
- `TapError` (non-zero exit) carrying stderr + the failed argv.

Latency note: each call is one process spawn (~30-100 ms on a
warm machine). Acceptable for batch agent jobs; for hot loops
prefer `tap mcp start` and call via MCP.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from typing import Any, Optional, Union


class TapError(RuntimeError):
    """Raised when the `tap` CLI exits non-zero."""

    def __init__(self, argv: list[str], returncode: int, stderr: str) -> None:
        self.argv = argv
        self.returncode = returncode
        self.stderr = stderr
        super().__init__(
            f"tap {' '.join(argv[1:])} exited {returncode}: {stderr.strip() or '(no stderr)'}"
        )


class TapNotFoundError(RuntimeError):
    """Raised when the `tap` binary cannot be located. Install via brew
    or set TAPRUN_BIN to the path."""


def _resolve_bin() -> str:
    explicit = os.environ.get("TAPRUN_BIN")
    if explicit:
        if not os.path.isfile(explicit):
            raise TapNotFoundError(f"TAPRUN_BIN={explicit} does not exist")
        return explicit
    found = shutil.which("tap")
    if not found:
        raise TapNotFoundError(
            "`tap` not found on PATH. Install with `brew install LeonTing1010/tap/tap` "
            "or set TAPRUN_BIN to the binary path."
        )
    return found


def _run_cli(args: list[str], *, parse_json: bool = True) -> Any:
    """Spawn the `tap` CLI with the given args. Returns parsed JSON
    when `parse_json=True` and the output is parsable, else raw text.
    Raises `TapError` on non-zero exit."""
    bin_path = _resolve_bin()
    argv = [bin_path] + args
    proc = subprocess.run(
        argv,
        capture_output=True,
        text=True,
        check=False,
    )
    if proc.returncode != 0:
        raise TapError(argv, proc.returncode, proc.stderr)
    out = proc.stdout
    if not parse_json:
        return out
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        # Some CLI commands print a mix of progress text + a JSON tail.
        # Best-effort: return raw text and let the caller parse.
        return out


def run(tap_id: str, *, args: Optional[dict[str, Any]] = None) -> Any:
    """Execute a compiled tap by `<site>/<name>` id. Returns parsed
    rows (typically a list of dicts).

    >>> rows = run("hn/top")
    >>> len(rows) > 0
    True
    """
    cli_args = ["run", tap_id, "--json"]
    if args:
        for k, v in args.items():
            cli_args.extend([f"--{k}", str(v)])
    return _run_cli(cli_args)


def doctor(tap_id: str) -> Any:
    """Run health + drift verification on a tap. Returns the doctor
    verdict (status + details).

    >>> v = doctor("hn/top")
    >>> v["status"] in ("ok", "broken", "stale")
    True
    """
    return _run_cli(["doctor", tap_id, "--json"])


# `verify` is an alias for `doctor` — both names appear in the
# three-plane refactor ADR. SDK exposes both for ergonomic choice.
verify = doctor


def forge(
    target: Optional[str] = None,
    *,
    desc: Optional[str] = None,
    intent: str = "read",
    trajectory: Union[str, dict, list, None] = None,
    site: Optional[str] = None,
    name: Optional[str] = None,
) -> Any:
    """Compile a tap from a URL, natural-language description, OR a
    browser-use AgentHistoryList trajectory.

    Three modes:

    1. URL — Tier 0 deterministic compile, no AI:

       >>> forge("https://news.ycombinator.com")

    2. Description (BYOK AI loop):

       >>> forge("get github trending repos")

    3. Trajectory — compile a recorded agent run into a deterministic
       plan that replays at zero LLM tokens:

       >>> from browser_use import Agent
       >>> agent = Agent(task="...", llm=...)
       >>> result = await agent.run()
       >>> forge(trajectory=result.model_dump(),
       ...      site="ycombinator", name="homepage")

       Pass either a parsed dict / AgentHistoryList JSON, or a path
       to a JSON file. `site` and `name` are required.
    """
    if trajectory is not None:
        if not site or not name:
            raise ValueError("forge(trajectory=...) requires both site= and name=")
        if isinstance(trajectory, str) and os.path.isfile(trajectory):
            traj_path = trajectory
            cleanup_path: Optional[str] = None
        else:
            payload = trajectory if isinstance(trajectory, str) else json.dumps(trajectory)
            fd, traj_path = tempfile.mkstemp(suffix=".trajectory.json")
            try:
                with os.fdopen(fd, "w") as f:
                    f.write(payload)
            except BaseException:
                os.unlink(traj_path)
                raise
            cleanup_path = traj_path
        try:
            return _run_cli(
                ["forge", "--from-trajectory", traj_path, "--site", site, "--name", name],
                parse_json=False,
            )
        finally:
            if cleanup_path:
                try:
                    os.unlink(cleanup_path)
                except OSError:
                    pass

    if target is None:
        raise ValueError("forge() requires `target` (URL or description) or `trajectory=`")
    args = ["forge", target]
    if desc:
        args.extend(["--desc", desc])
    if intent != "read":
        args.extend(["--intent", intent])
    return _run_cli(args, parse_json=False)


def list_taps(site: Optional[str] = None) -> Any:
    """List installed taps. Optional site filter.

    >>> taps = list_taps("hn")
    """
    args = ["list"]
    if site:
        args.append(site)
    args.append("--json")
    return _run_cli(args)


def show(tap_id: str) -> Any:
    """Inspect a tap (source + manifest + fingerprint).

    >>> info = show("hn/top")
    """
    return _run_cli(["show", tap_id])


def stats() -> Any:
    """K(t) telemetry — token cost per capability accumulated across
    runs. Returns the stats snapshot in the same shape as
    `tap stats --json`.

    >>> s = stats()
    """
    return _run_cli(["stats", "--json"])


def _which() -> Union[str, None]:
    """Diagnostic — return the `tap` binary path that would be used,
    or None if not found. Public for users debugging install paths."""
    try:
        return _resolve_bin()
    except TapNotFoundError:
        return None
