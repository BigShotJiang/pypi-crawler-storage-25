import logging
from unittest.mock import MagicMock, patch

from llg3d import main
from llg3d.solvers.numpy import NumPySolver


def test_verbosity_arg_parsing():
    """Test that verbosity argument is correctly parsed."""
    args = main.parse_args(["--verbosity", "WARNING"])
    assert args.verbosity == "WARNING"

    args = main.parse_args(["--verbosity", "DEBUG"])
    assert args.verbosity == "DEBUG"

    # Default value
    args = main.parse_args([])
    assert args.verbosity == "INFO"


def test_progress_bar_visibility_logic():
    """Test that progress bar is disabled when logging level > INFO."""
    solver = NumPySolver(N=10, solver="numpy")

    # Case 1: INFO level -> Progress bar should be enabled (disable=False)
    with patch("logging.getLogger") as mock_get_logger:
        mock_logger = MagicMock()
        mock_logger.getEffectiveLevel.return_value = logging.INFO
        mock_get_logger.return_value = mock_logger

        # Check that disable is False (tqdm default)
        # Note: In MPI context (rank > 0), _progress_bar returns a range object, not tqdm.
        # This test assumes rank 0 or non-MPI context where _tqdm_file is not None.
        if solver._tqdm_file is not None:
            pbar = solver._progress_bar()
            assert not pbar.disable  # type: ignore
        else:
            # If _tqdm_file is None (e.g. MPI rank > 0), it returns a range
            pbar = solver._progress_bar()
            assert isinstance(pbar, range)

    # Case 2: WARNING level -> Progress bar should be disabled (disable=True)
    with patch("logging.getLogger") as mock_get_logger:
        mock_logger = MagicMock()
        mock_logger.getEffectiveLevel.return_value = logging.WARNING
        mock_get_logger.return_value = mock_logger

        if solver._tqdm_file is not None:
            pbar = solver._progress_bar()
            assert pbar.disable  # type: ignore
        else:
            pbar = solver._progress_bar()
            assert isinstance(pbar, range)


def test_main_logging_output(caplog):
    """Test that main logs solver info."""
    caplog.set_level(logging.INFO)

    with patch("llg3d.solvers.get_solver_class") as mock_get_solver:
        mock_solver_cls = MagicMock()
        mock_solver_instance = MagicMock()
        mock_solver_instance.__str__.return_value = "MockSolverStringRepresentation"  # type: ignore

        # Setup mock to return the instance
        mock_solver_cls.return_value = mock_solver_instance
        mock_get_solver.return_value = mock_solver_cls

        # Mocking arguments to avoid validation errors
        with patch("llg3d.main.parse_args") as mock_parse_args:
            mock_args = MagicMock()
            mock_args.verbosity = "INFO"
            mock_args.solver = "numpy"
            mock_parse_args.return_value = mock_args

            # Run main
            main.main(["--N", "1", "--verbosity", "INFO"])

        # Check that the solver string representation is in the logs
        # Note: In MPI environment, only rank 0 logs output.
        from llg3d import solvers

        if solvers.rank == 0:
            assert "MockSolverStringRepresentation" in caplog.text
