from dataclasses import fields

from llg3d import solvers
from llg3d.parameters import (
    ElementType,
    InitType,
    PrecisionType,
    RunParameters,
    VerbosityType,
    arg_parameters,
    lit_to_list,
)


def test_constructor_with_kwargs():
    """Test RunParameters constructor with keyword arguments."""
    params = RunParameters(element="Iron", N=1000, T=300.0)
    assert params.element == "Iron"
    assert params.N == 1000
    assert params.T == 300.0
    # Check other fields retain defaults
    assert params.dt == 1.0e-14
    assert params.Jx == 300


def test_as_dict():
    """Test as_dict() method."""
    params = RunParameters(element="Nickel", N=2000)
    params_dict = params.as_dict()

    assert isinstance(params_dict, dict)
    assert params_dict["element"] == "Nickel"
    assert params_dict["N"] == 2000
    # Should have all fields
    field_names = {f.name for f in fields(RunParameters)}
    assert set(params_dict.keys()) == field_names


def test_as_dict_roundtrip():
    """Test that RunParameters can be reconstructed from as_dict()."""
    original = RunParameters(element="Cobalt", N=3000, T=500.0)
    reconstructed = RunParameters(**original.as_dict())

    assert original.element == reconstructed.element
    assert original.N == reconstructed.N
    assert original.T == reconstructed.T
    assert original.dt == reconstructed.dt


def test_str_parameter():
    d = {
        "element": "Cobalt",
        "N": 500,
        "dt": 1e-14,
        "Jx": 300,
        "Jy": 21,
        "Jz": 21,
        "dx": 1e-09,
        "T": 1100,
        "H_ext": 0.0,
        "start_averaging": 2000,
        "n_mean": 1,
        "n_profile": 100,
        "blocking": True,
        "solver": "numpy",
        "verbosity": "DEBUG",
        "precision": "single",
        "seed": 54321,
    }
    expected = f"""\
element         : Cobalt
N               = 500
dt              = 1e-14
Jx              = 300
Jy              = 21
Jz              = 21
dx              = 1e-09
T               = 1100
H_ext           = 0.0
init_type       : 0
result_file     : run.npz
start_averaging = 2000
n_mean          = 1
n_profile       = 100
solver          : numpy
precision       : single
blocking        = True
seed            = 54321
device          : auto
profiling       = False
verbosity       : DEBUG
np              = {solvers.size}
"""
    assert str(RunParameters(**d)) == expected


def test_lit_to_list():
    """Test lit_to_list function."""
    elements = lit_to_list(ElementType)
    assert elements == ["Cobalt", "Iron", "Nickel"]

    init_types = lit_to_list(InitType)
    assert init_types == ["0", "dw"]

    precisions = lit_to_list(PrecisionType)
    assert precisions == ["single", "double"]

    verbosities = lit_to_list(VerbosityType)
    assert "DEBUG" in verbosities
    assert "INFO" in verbosities
    assert "WARNING" in verbosities
    assert "ERROR" in verbosities
    assert "CRITICAL" in verbosities


def test_arg_parameters_structure():
    """Test that arg_parameters has correct structure."""
    assert isinstance(arg_parameters, dict)
    assert len(arg_parameters) > 0

    # All entries should have 'help' and 'default'
    for name, param in arg_parameters.items():
        assert "help" in param, f"Parameter {name} missing 'help'"
        assert "default" in param, f"Parameter {name} missing 'default'"
        assert isinstance(param["help"], str), f"Parameter {name} help should be string"


def test_arg_parameters_contains_expected_fields():
    """Test that arg_parameters contains all expected parameters."""
    expected_params = [
        "element",
        "N",
        "dt",
        "Jx",
        "Jy",
        "Jz",
        "dx",
        "T",
        "H_ext",
        "init_type",
        "result_file",
        "start_averaging",
        "n_mean",
        "n_profile",
        "solver",
        "precision",
        "blocking",
        "seed",
        "device",
        "profiling",
        "verbosity",
        "np",
    ]
    for param in expected_params:
        assert param in arg_parameters, f"Missing parameter: {param}"


def test_arg_parameters_defaults_match_dataclass():
    """Test that arg_parameters defaults match RunParameters defaults."""
    default_params = RunParameters()

    # Check a few critical defaults
    assert arg_parameters["element"]["default"] == default_params.element
    assert arg_parameters["N"]["default"] == default_params.N
    assert arg_parameters["dt"]["default"] == default_params.dt
    assert arg_parameters["T"]["default"] == default_params.T
    assert arg_parameters["blocking"]["default"] == default_params.blocking
    assert arg_parameters["profiling"]["default"] == default_params.profiling


def test_arg_parameters_choices():
    """Test that parameters with choices have them listed."""
    # Parameters with choices
    assert "choices" in arg_parameters["element"]
    assert arg_parameters["element"]["choices"] == ["Cobalt", "Iron", "Nickel"]

    assert "choices" in arg_parameters["init_type"]
    assert arg_parameters["init_type"]["choices"] == ["0", "dw"]

    assert "choices" in arg_parameters["precision"]
    assert "single" in arg_parameters["precision"]["choices"]
    assert "double" in arg_parameters["precision"]["choices"]


def test_arg_parameters_actions():
    """Test that boolean parameters have store_true action."""
    assert arg_parameters["blocking"].get("action") == "store_true"
    assert arg_parameters["profiling"].get("action") == "store_true"


def test_arg_parameters_types():
    """Test that type metadata is correctly set."""
    assert arg_parameters["seed"].get("type") is int
