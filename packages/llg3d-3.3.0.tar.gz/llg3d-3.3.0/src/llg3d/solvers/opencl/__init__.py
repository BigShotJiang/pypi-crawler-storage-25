"""
LLG3D solver using OpenCL.

.. toctree::
   :hidden:

   ../opencl_kernels

Uses :doc:`../opencl_kernels` for the OpenCL kernel implementations.
"""

from .solver import (
    OpenCLSolver,
    Program,
    TimedKernel,
    get_context_and_device,
    get_precision,
)

__all__ = [
    "OpenCLSolver",
    "Program",
    "TimedKernel",
    "get_context_and_device",
    "get_precision",
]
