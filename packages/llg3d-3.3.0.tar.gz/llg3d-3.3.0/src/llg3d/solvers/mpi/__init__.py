"""
LLG3D solver using MPI.

The parallelization is done in the x direction.
"""

from .solver import (
    MPISolver,
    initialize_mpi,
    ArgumentParser,
    Boundaries,
    Boundaries_3d,
)
from . import solver

__all__ = [
    "MPISolver",
    "initialize_mpi",
    "ArgumentParser",
    "Boundaries",
    "Boundaries_3d",
    "comm",
    "rank",
    "size",
    "status",
]


def __getattr__(name):
    if name in ("comm", "rank", "size", "status"):
        return getattr(solver, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
