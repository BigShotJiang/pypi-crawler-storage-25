"""LLG3D solver using NumPy."""

from .solver import NumPySolver

__all__ = ["NumPySolver"]
