"""
Parameters for the simulation.

The :py:class:`RunParameters` dataclass defines all the parameters for the simulation,
along with their types, default values, and help text.

The :py:data:`arg_parameters` dictionary is generated from the dataclass fields and is
used to create the command-line interface for the simulation.

Adding a new parameter is as simple as adding a new field to the
:py:class:`RunParameters` class with appropriate metadata:

- this field will be accessible as attribute to all :py:mod:`llg3d.solvers` classes
- the :py:data:`arg_parameters` will be automatically updated to include the new
  parameter in the CLI.
"""

from argparse import Action
from dataclasses import MISSING, asdict, dataclass, field, fields
from typing import Any, Literal, NotRequired, TypedDict

from . import solvers

# Type definitions for parameter names
ElementType = Literal["Cobalt", "Iron", "Nickel"]
SolverType = Literal["opencl", "mpi", "numpy", "jax"]
PrecisionType = Literal["single", "double"]
DeviceType = Literal["cpu", "gpu", "auto"]
InitType = Literal["0", "dw"]
VerbosityType = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]


@dataclass
class RunParameters:
    """
    Store simulation parameters.

    Example:
        >>> params = RunParameters(element="Cobalt", N=1000)
        >>> print(params)
        element         : Cobalt
        N               = 1000
        dt              = 1e-14
        Jx              = 300
        Jy              = 21
        Jz              = 21
        dx              = 1e-09
        T               = 1100
        H_ext           = 0.0
        init_type       : 0
        result_file     : run.npz
        start_averaging = 2000
        n_mean          = 1
        n_profile       = 0
        solver          : numpy
        precision       : double
        blocking        = False
        seed            = 12345
        device          : auto
        profiling       = False
        verbosity       : INFO
        np              = 1
    """

    element: ElementType = field(
        default="Cobalt",
        metadata={
            "help": "Chemical element of the sample",
            "choices": ElementType,
        },
    )  #: Chemical element of the sample
    N: int = field(
        default=5000,
        metadata={"help": "Number of time iterations"},
    )  #: Number of iterations
    dt: float = field(
        default=1.0e-14,
        metadata={"help": "Time step"},
    )  #: Time step
    Jx: int = field(
        default=300,
        metadata={"help": "Number of points in x"},
    )  #: Number of points in x
    Jy: int = field(
        default=21,
        metadata={"help": "Number of points in y"},
    )  #: Number of points in y
    Jz: int = field(
        default=21,
        metadata={"help": "Number of points in z"},
    )  #: Number of points in z
    dx: float = field(
        default=1.0e-9,
        metadata={"help": "Step in x"},
    )  #: Step in x
    T: float = field(
        default=0.0,
        metadata={"help": "Temperature (K)"},
    )  #: Temperature (K)
    H_ext: float = field(
        default=0.0,
        metadata={"help": "External field (A/m)"},
    )  #: External field (A/m)
    init_type: InitType = field(
        default="0",
        metadata={
            "help": "Type of initialization ('0' for uniform, 'dw' for domain wall)",
            "choices": InitType,
        },
    )  #: Initialization type
    result_file: str = field(
        default="run.npz",
        metadata={"help": "Name of the npz result file"},
    )  #: Result file name
    start_averaging: int = field(
        default=4000,
        metadata={"help": "Start index of time average"},
    )  #: Start index of time average
    n_mean: int = field(
        default=1,
        metadata={"help": "Spatial average frequency (number of iterations)"},
    )  #: Spatial average frequency (number of iterations)
    n_profile: int = field(
        default=0,
        metadata={"help": "x-profile save frequency (number of iterations)"},
    )  #: x-profile save frequency (number of iterations)
    solver: SolverType = field(
        default_factory=lambda: "numpy" if solvers.size == 1 else "mpi",
        metadata={
            "help": "Solver to use for the simulation",
            "choices": SolverType,
        },
    )  #: Solver to use
    precision: PrecisionType = field(
        default="double",
        metadata={
            "help": "Precision of the floating point (single or double)",
            "choices": PrecisionType,
        },
    )  #: Precision of the simulation
    blocking: bool = field(
        default=False,
        metadata={
            "help": "Use blocking communications (MPI solver only)",
            "action": "store_true",
        },
    )  #: Use blocking communications
    seed: int = field(
        default=12345,
        metadata={
            "help": "Random seed for temperature fluctuations",
            "type": int,
        },
    )  #: Random seed for temperature fluctuations
    device: DeviceType = field(
        default="auto",
        metadata={
            "help": "Device to use by the OpenCL solver",
            "choices": DeviceType,
        },
    )  #: Device to use
    profiling: bool = field(
        default=False,
        metadata={
            "help": "Enable profiling output (internal profiler)",
            "action": "store_true",
        },
    )  #: Enable profiling output
    verbosity: VerbosityType = field(
        default="INFO",
        metadata={
            "help": "Logging verbosity level",
            "choices": VerbosityType,
        },
    )  #: Logging verbosity level
    np: int = field(
        default_factory=lambda: solvers.size,
        metadata={"help": "Number of processes (for MPI solver)"},
    )  #: Number of processes (for MPI solver)

    def as_dict(self) -> dict[str, Any]:
        """
        Convert RunParameters to a dictionary.

        Returns:
            Dictionary representation of the parameters
        """
        return asdict(self)

    def __str__(self) -> str:
        """Return solver information in a readable format."""
        # Compute the width of the longest parameter name
        width = max([len(f.name) for f in fields(self)])
        s = ""
        for f in fields(self):
            value = getattr(self, f.name)
            # the seprator is ":" for strings and "=" for others
            sep = ":" if isinstance(value, str) else "="
            s += "{0:<{1}} {2} {3}\n".format(f.name, width, sep, value)
        return s


ParameterValue = str | int | float | bool | None


class ArgParameter(TypedDict):
    """Metadata for a simulation parameter."""

    help: str
    default: ParameterValue
    choices: NotRequired[Any]
    action: NotRequired[str | type[Action]]
    type: NotRequired[type]


def lit_to_list(lit: Any) -> list[Any]:
    """
    Convert a Literal type to a list of its possible values.

    Args:
        lit: Literal type

    Returns:
        List of possible values
    """
    return list(lit.__args__)


def _generate_arg_parameters() -> dict[str, ArgParameter]:
    """
    Generate arg_parameters from RunParameters fields metadata.

    Returns:
        Dictionary of argument parameters for CLI
    """
    params: dict[str, ArgParameter] = {}
    for f in fields(RunParameters):
        metadata = f.metadata or {}
        if not metadata.get("help"):
            # Skip fields without help text (internal-only fields)
            continue

        # Determine default value
        if f.default is not MISSING:
            default_value = f.default
        elif f.default_factory is not MISSING:
            default_value = f.default_factory()
        else:
            # Use None or a sentinel value if your type allows it
            default_value = None

        arg_param: ArgParameter = {
            "help": metadata["help"],
            "default": default_value,
        }

        # Add optional metadata fields
        if "choices" in metadata:
            arg_param["choices"] = lit_to_list(metadata["choices"])
        if "action" in metadata:
            arg_param["action"] = metadata["action"]
        if "type" in metadata:
            arg_param["type"] = metadata["type"]

        params[f.name] = arg_param

    return params


#: simulation CLI parameters
arg_parameters: dict[str, ArgParameter] = _generate_arg_parameters()
