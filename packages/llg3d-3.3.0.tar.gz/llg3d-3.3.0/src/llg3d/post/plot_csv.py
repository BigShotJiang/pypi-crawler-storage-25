"""
Plot data from a CSV file.

Create a figure with one subplot for each column in the CSV file (except the first
one, which is assumed to be the x-axis).
Each subplot will show the corresponding column as a function of the first column.
"""

from pathlib import Path
import numpy as np

from matplotlib import pyplot as plt


def plot_csv(file: Path, show: bool = False):
    """
    Plot data from a CSV file.

    Args:
        file: Path to the CSV file. The first column is assumed to be the x-axis
            (e.g., Temperature), and the others are y-axes (e.g., m_0, x_0, w).
        show: display the graph in a graphical window.
    """
    data = np.genfromtxt(file, delimiter=",", names=True, dtype=None, encoding="utf-8")
    names = data.dtype.names

    fig, axes = plt.subplots(3, 1, figsize=(8, 12))

    for ax, name in zip(axes, names[1:]):
        ax.plot(data["T"], data[name], marker="o")
        ax.set_xlabel(rf"${names[0]}$")
        ax.set_ylabel(rf"${name}$")
        ax.set_title(rf"${name}$ vs ${names[0]}$")
        ax.grid()

    fig.tight_layout()
    fig.savefig(file.with_suffix(".png"), dpi=300)
    print(f"Written to {file.with_suffix('.png')}")
    if show:
        plt.show()


def main():
    """Main function to parse arguments and call the plotting function."""
    import argparse

    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument("file", type=Path, help="Path to the CSV file")
    parser.add_argument(
        "-s",
        "--show",
        action="store_true",
        default=False,
        help="Display the plot (omit to disable display in non-interactive runs).",
    )
    args = parser.parse_args()

    plot_csv(args.file, show=args.show)
