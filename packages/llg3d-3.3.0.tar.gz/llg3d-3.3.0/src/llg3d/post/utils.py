"""Command-line argument parsing for post-processing scripts."""

import argparse
from pathlib import Path

import numpy as np

from ..grid import Grid
from ..io import RunResults
from .extract import extract_values


def get_x_coords(result: RunResults) -> np.ndarray:
    """
    Extract x coordinates from the result.

    Args:
        result: RunResults object

    Returns:
        x coordinates as a numpy array
    """
    grid_params = extract_values(
        result, "params/Jx", "params/Jy", "params/Jz", "params/dx"
    )
    grid = Grid(*grid_params)  # type: ignore
    x_coords = grid.get_x_coords(local=False)
    return x_coords


def get_cli_args(
    description: str | None, default_image_filepath: Path
) -> argparse.Namespace:
    """
    Parse command-line arguments for post-processing scripts.

    Args:
        description: Description of the script for the help message.
        default_image_filepath: Default path to save the output image.

    Returns:
        Parsed command-line arguments.
    """
    parser = argparse.ArgumentParser(
        description=description, formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument("files", nargs="+", type=Path, help="Path to the result files.")
    parser.add_argument(
        "-i",
        "--image_filepath",
        type=Path,
        default=default_image_filepath,
        help="Path to save the image",
    )
    parser.add_argument(
        "-s",
        "--show",
        action="store_true",
        default=False,
        help="Display the plot (omit to disable display in non-interactive runs).",
    )
    return parser.parse_args()
