"""Analyse domain wall profiles."""

import numpy as np
from scipy.optimize import curve_fit

from llg3d.io import RunResults

from .utils import get_x_coords


def fit_data_to_tanh(x: np.ndarray, data: np.ndarray) -> tuple[np.float64, ...]:
    """
    Fit the data to a hyperbolic tangent function.

    Args:
        x: x coordinates
        data: magnetization profile data

    Returns:
        A tuple (m_0, x_0, w) containing the fitted parameters:
        - m_0: saturation magnetization
        - x_0: center of the domain wall
        - w: width of the domain wall
    """
    # Initial guess for the parameters
    m_0_guess = 1.0  # Assuming the saturation magnetization is around 1
    x_0_guess = x[len(x) // 2]  # Assuming the domain wall is initially centered
    w_guess = (x[-1] - x[0]) / 10
    p0 = (m_0_guess, x_0_guess, w_guess)
    bounds = (
        (0, x[0], 0),  # m_0 > 0, x_0 > x_min, w > 0
        (1, x[-1], x[-1] - x[0]),  # m_0 < 1, x_0 < x_max, w < L_x
    )

    # Fit the tanh function to the data
    def tanh_func(x, m_0, x_0, w):
        return m_0 * np.tanh((x - x_0) / w)

    popt, _ = curve_fit(tanh_func, x, data, p0=p0, bounds=bounds, nan_policy="raise")
    # Warn if the fit is not good (e.g., if the parameters are at the bounds)
    if np.any(popt == bounds[0]) or np.any(popt == bounds[1]):
        print(
            "Warning: Fit parameters are at the bounds. The fit may not be good. "
            f"Fitted parameters: m_0={popt[0]:.4f}, x_0={popt[1]:.4f}, w={popt[2]:.4f}"
        )

    return tuple(popt)


def fit_m1_to_tanh(result: RunResults, time_index: int = -1) -> tuple[np.float64, ...]:
    r"""
    Fit the magnetization profile to a hyperbolic tangent function.

    The function is defined as:

    .. math::
        m(x) = m_0 * \tanh\left(\frac{x - x_0}{w}\right)

    where:

    - m_0 is the saturation magnetization,
    - x_0 is the center of the domain wall,
    - w is the width of the domain wall.

    Args:
        result: RunResults object containing the magnetization profile.
        time_index: Index of the time step to fit (default is the last time step).
          etc.). Default is -1 (last time step).

    Returns:
        A tuple (m_0, x_0, w) containing the fitted parameters.
    """
    # Extract the x coordinates and the magnetization profile
    x = get_x_coords(result)
    x_profiles = result.get_record("x_profiles")
    m1_profile = x_profiles["m1"][time_index]

    return fit_data_to_tanh(x, m1_profile)
