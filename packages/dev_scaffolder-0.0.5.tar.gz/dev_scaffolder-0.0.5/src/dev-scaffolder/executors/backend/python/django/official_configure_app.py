import argparse
import sys
import os
import re
from typing import List

# Add the project root to sys.path
sys.path.append(
    os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..')))

from executors.base import BaseExecutor
from executors.backend.python.django.official import DjangoOfficialExecutor
from batteries.base import BaseBattery
from batteries.registry import parse_batteries
from typings.base import (
    DjangoOfficialTemplateArgs,
    ExecutorResponseStatus,
    WriteToFileContent
)
from constants.backend.python.base import (
    DJANGO_APP_URL_CONFIG,
    DJANGO_VIEW_FUNCTION_IMPORT_JSON_RESPONSE,
    DJANGO_VIEW_FUNCTION,
)
from utils.base import write_into_file, get_venv_python_executor


class DjangoOfficialConfigureAppExecutor(BaseExecutor):
    """
    Executor that scaffolds an official Django project and then configures
    the generated app with a starter views.py, urls.py, and project URL wiring.

    Accepts an optional list of batteries (e.g. CorsHeadersBattery,
    RestFrameworkBattery, PostgreSQLBattery) that are applied after the base
    app is configured. Each battery handles its own package installation and
    settings configuration.

    Delegates project/app creation to DjangoOfficialExecutor and shares the
    active spinner with it so interactive prompts (e.g. directory replacement)
    are handled correctly.
    """

    def __init__(self, batteries: List[BaseBattery] = None):
        super().__init__()
        self.batteries = batteries or []

    def get_venv_environment(self) -> str:
        """
        Delegates venv setup to DjangoOfficialExecutor.

        :return: Path to the venv Python executable.
        :rtype: str
        """
        return DjangoOfficialExecutor().get_venv_environment()

    def install_dependencies(self, venv_python_executor: str) -> ExecutorResponseStatus:
        """
        Dependencies are managed by each battery. This method is a no-op.

        :param venv_python_executor: Path to the venv Python executable.
        :type venv_python_executor: str
        :return: ExecutorResponseStatus indicating success.
        :rtype: ExecutorResponseStatus
        """
        return ExecutorResponseStatus(success=True)

    # ------------------------------------------------------------------
    # App configuration helpers
    # ------------------------------------------------------------------

    def _integrate_app_url_into_project(self, path: str, directory_name: str, app_name: str) -> None:
        """
        Integrate the app urls.py in the project urls

        :param path: The current folder the project folder is in
        :type path: str
        :param directory_name: The project folder name
        :type directory_name: str
        :param app_name: The app name
        :type app_name: str
        :return: None
        :rtype: None
        """
        project_urls_path = os.path.join(path, directory_name, "urls.py")
        try:
            with open(project_urls_path, 'r') as f:
                content = f.read()

            modified_content = content.replace(
                'urlpatterns = [\n',
                (
                    "urlpatterns = [\n"
                    f"  path('{app_name}/', include('{app_name}.urls')),\n"
                )
            )
            modified_content = modified_content.replace(
                "from django.urls import path",
                "from django.urls import path, include"
            )

            with open(project_urls_path, "w") as f:
                f.write(modified_content)

        except FileNotFoundError:
            self.console.print(
                f"[bold red]File was not found at {project_urls_path}[/bold red]"
            )

    def _insert_app_re(self, content: str, new_app: str) -> str:
        """Installed app insertion using regex"""

        pattern = r'(INSTALLED_APPS\s*=\s*\[)(.*?)(\])'

        def insert_app(match):
            prefix = match.group(1)
            apps_content = match.group(2)
            suffix = match.group(3)

            # Clean up the apps content
            apps_content = apps_content.rstrip()

            # Add comma if there are existing apps
            if apps_content.strip():
                # Add a comma after the last app if needed
                if apps_content.strip() and not apps_content.strip().endswith(','):
                    apps_content += ','
                new_content = f"{prefix}{apps_content}\n    '{new_app}',\n{suffix}"
            else:
                # Empty list
                new_content = f"{prefix}\n    '{new_app}',\n{suffix}"

            return new_content

        return re.sub(pattern, insert_app, content, flags=re.DOTALL)

    def _configure_app_in_installed_apps(self, path: str, directory_name: str, app_name: str) -> None:
        project_settings_path = os.path.join(path, directory_name, "settings.py")
        try:
            with open(project_settings_path, 'r') as f:
                content = f.read()

            modified_content = self._insert_app_re(content, app_name)

            with open(project_settings_path, "w") as f:
                f.write(modified_content)

        except FileNotFoundError:
            self.console.print(
                f"[bold red]File was not found at {project_settings_path}[/bold red]"
            )

    def _modify_views_py(self, path: str, app_name: str) -> None:
        views_file = os.path.join(path, app_name, "views.py")
        write_into_file(
            views_file,
            [
                WriteToFileContent(line=0, content=DJANGO_VIEW_FUNCTION_IMPORT_JSON_RESPONSE),
                WriteToFileContent(line=-1, content=DJANGO_VIEW_FUNCTION)
            ]
        )

    def _create_app_urls_py(self, path: str, app_name: str) -> None:
        app_path = os.path.join(path, app_name)
        os.chdir(app_path)
        open("urls.py", "w").close()
        urls_file = os.path.join(path, app_name, "urls.py")
        write_into_file(
            urls_file,
            [WriteToFileContent(line=0, content=DJANGO_APP_URL_CONFIG)]
        )

    def _configure_app(self, path: str, app_name: str, directory_name: str) -> None:
        self._modify_views_py(path, app_name)
        self._create_app_urls_py(path, app_name)
        self._integrate_app_url_into_project(path, directory_name, app_name)
        self._configure_app_in_installed_apps(path, directory_name, app_name)
        self.console.print(
            f"[bold green]Django app {app_name} configured successfully in {path}[/bold green]"
        )

    # ------------------------------------------------------------------
    # BaseExecutor lifecycle
    # ------------------------------------------------------------------

    def execute_creation_commands(self, **kwargs) -> ExecutorResponseStatus:
        """
        Scaffolds the Django project/app via DjangoOfficialExecutor, configures
        the app, then applies each battery in order.

        :param kwargs:
            - project_name (str): Name of the Django project.
            - directory_name (str): Name of the output directory.
            - app_name (str): Name of the Django app to create and configure.
        :return: ExecutorResponseStatus indicating success or failure.
        :rtype: ExecutorResponseStatus
        """
        project_name = kwargs["project_name"]
        directory_name = kwargs["directory_name"]
        app_name = kwargs["app_name"]

        # Share the active spinner so prepare_directory can pause/resume it
        django_executor = DjangoOfficialExecutor()
        django_executor._status = self._status

        self._update_status(f"[bold blue]Scaffolding Django project '{project_name}'...[/bold blue]")
        response = django_executor.generate(
            project_name=project_name,
            directory_name=directory_name,
            app_name=app_name,
        )

        if not response.success:
            return ExecutorResponseStatus(success=False)

        if response.message == "APP_CREATION_FAILED":
            self.console.print("[bold red]App creation failed — cannot configure app[/bold red]")
            return ExecutorResponseStatus(success=False)

        self._update_status(f"[bold blue]Configuring Django app '{app_name}'...[/bold blue]")
        self._configure_app(response.path, app_name, directory_name)

        venv_python_executor = get_venv_python_executor()

        for battery in self.batteries:
            battery_name = battery.__class__.__name__
            self._update_status(f"[bold blue]Applying {battery_name}...[/bold blue]")
            install_response = battery.install(venv_python_executor)
            if not install_response.success:
                return ExecutorResponseStatus(success=False)
            battery.configure(response.path, project_name, app_name)

        self._update_status("[bold blue]Updating requirements.txt...[/bold blue]")
        django_executor.add_packages_to_requirements_txt(venv_python_executor, response.path)

        self._update_status("[bold blue]Writing README.md...[/bold blue]")
        self._write_readme(response.path, project_name=project_name, app_name=app_name)

        return ExecutorResponseStatus(success=True)

    def get_readme_content(self, **kwargs) -> str:
        project_name = kwargs.get("project_name", "project")
        app_name = kwargs.get("app_name", "")
        app_section = (
            f"\n## App: `{app_name}`\n\n"
            f"The `{app_name}` app is wired into the project with a starter view and URL config.\n\n"
            f"Visit http://localhost:8000/{app_name}/ to see the default response.\n"
        ) if app_name else ""
        return (
            f"# {project_name}\n\n"
            "A Django project scaffolded with dev-scaffolder.\n\n"
            "## Requirements\n\n"
            "- Python 3.8+\n\n"
            "## Setup\n\n"
            "```bash\n"
            "python -m venv venv\n"
            "source venv/bin/activate       # macOS / Linux\n"
            "venv\\Scripts\\activate          # Windows\n\n"
            "pip install -r requirements.txt\n"
            "```\n\n"
            "## Run\n\n"
            "```bash\n"
            "python manage.py migrate\n"
            "python manage.py runserver\n"
            "```\n\n"
            "Open http://localhost:8000 in your browser."
            f"{app_section}\n"
        )

    def generate(self, **kwargs: DjangoOfficialTemplateArgs) -> ExecutorResponseStatus:
        """
        Internal implementation for generating and configuring the Django app template.

        Resolves arguments and delegates to execute_creation_commands.
        Called by run(); do not call directly.

        :param kwargs:
            - project_name (str): Name of the Django project.
            - directory_name (str): Name of the output directory.
            - app_name (str): Name of the Django app.
        :return: ExecutorResponseStatus indicating success or failure.
        :rtype: ExecutorResponseStatus
        """
        project_name = kwargs.get("project_name", "test") or "test"
        directory_name = kwargs.get("directory_name", "") or project_name
        app_name = kwargs.get("app_name", "")

        batteries_arg = kwargs.get("batteries", "") or ""
        if batteries_arg and not self.batteries:
            self.batteries = parse_batteries(batteries_arg)

        return self.execute_creation_commands(
            project_name=project_name,
            directory_name=directory_name,
            app_name=app_name,
        )

    @classmethod
    def build_arg_parser(cls) -> argparse.ArgumentParser:
        parser = super().build_arg_parser()
        parser.add_argument('--project_name', type=str, default='myproject',
                            help='Name of the Django project')
        parser.add_argument('--directory_name', type=str, default='myproject',
                            help='Name of the Django project directory')
        parser.add_argument('--app_name', type=str, default='core',
                            help='Name of the Django app')
        parser.add_argument('--batteries', type=str, default='',
                            help='Comma-separated batteries to apply, e.g. "Rest Framework,PostgreSQL"')
        return parser


# Module-level shim so existing callers using generate_django_official_configure_app_template() still work
def generate_django_official_configure_app_template(**kwargs) -> ExecutorResponseStatus:
    return DjangoOfficialConfigureAppExecutor().run(**kwargs)


if __name__ == '__main__':
    args = DjangoOfficialConfigureAppExecutor.build_arg_parser().parse_args()
    DjangoOfficialConfigureAppExecutor().run(
        project_name=args.project_name,
        app_name=args.app_name,
        directory_name=args.directory_name,
        batteries=args.batteries,
    )
