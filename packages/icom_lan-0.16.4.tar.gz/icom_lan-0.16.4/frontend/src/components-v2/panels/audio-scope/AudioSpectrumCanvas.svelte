<script lang="ts">
  import { onMount } from 'svelte';
  import { renderAudioSpectrum, AudioSpectrumRendererState, type SpectrumState } from './audio-spectrum-renderer';

  interface Props {
    /** FFT pixel data from AudioFftScope (0-160 range) */
    data: Uint8Array | null;
    /** Register a push callback for streaming updates */
    onRegisterPush?: (fn: (data: Uint8Array) => void) => void;
    /** Effective bandwidth of the FFT data in Hz */
    bandwidth: number;
    /** Filter passband width in Hz */
    filterWidth: number;
    /** Max filter width in Hz */
    filterWidthMax: number;
    /** PBT inner raw value (0-255, center=128) */
    pbtInner?: number;
    /** PBT outer raw value (0-255, center=128) */
    pbtOuter?: number;
    /** Manual notch active */
    manualNotch?: boolean;
    /** Manual notch frequency (0-255 raw) */
    notchFreq?: number;
    /** Contour level (0=off, >0=active) */
    contour?: number;
    /** Contour center frequency offset (0-255 raw) */
    contourFreq?: number;
  }

  let {
    data,
    onRegisterPush,
    bandwidth = 48000,
    filterWidth = 2400,
    filterWidthMax = 4000,
    pbtInner = 128,
    pbtOuter = 128,
    manualNotch = false,
    notchFreq = 128,
    contour = 0,
    contourFreq = 128,
  }: Props = $props();

  let canvas: HTMLCanvasElement;
  let cssWidth = $state(1);
  let cssHeight = $state(1);
  let rafId = 0;
  let visible = true;
  let latestPixels: Uint8Array | null = null;
  const rendererState = new AudioSpectrumRendererState();

  function draw(): void {
    if (!visible) { rafId = 0; return; }
    const pixels = latestPixels ?? data;

    if (canvas && pixels && cssWidth > 1 && cssHeight > 1) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const state: SpectrumState = {
          pixels,
          bandwidth,
          filterWidth,
          filterWidthMax,
          pbtInner,
          pbtOuter,
          manualNotch,
          notchFreq,
          contour,
          contourFreq,
        };
        renderAudioSpectrum(ctx, cssWidth, cssHeight, state, rendererState);
      }
    }

    // Only reschedule if there is data to render; the push callback will restart the loop
    if (latestPixels ?? data) {
      rafId = requestAnimationFrame(draw);
    } else {
      rafId = 0;
    }
  }

  function onVisibilityChange() {
    visible = !document.hidden;
    if (visible && rafId === 0) rafId = requestAnimationFrame(draw);
  }

  onMount(() => {
    onRegisterPush?.((pixels: Uint8Array) => {
      latestPixels = pixels;
      // Restart rAF loop if it stopped because there was no data
      if (rafId === 0 && visible) rafId = requestAnimationFrame(draw);
    });

    document.addEventListener('visibilitychange', onVisibilityChange);
    rafId = requestAnimationFrame(draw);

    const ro = new ResizeObserver((entries) => {
      const rect = entries[0]?.contentRect;
      if (!rect) return;
      cssWidth = Math.max(1, Math.floor(rect.width));
      cssHeight = Math.max(1, Math.floor(rect.height));
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.round(cssWidth * dpr);
      canvas.height = Math.round(cssHeight * dpr);
      canvas.getContext('2d')?.setTransform(dpr, 0, 0, dpr, 0, 0);
      rendererState.reset();
    });
    ro.observe(canvas);

    return () => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      ro.disconnect();
      cancelAnimationFrame(rafId);
      rafId = 0;
    };
  });
</script>

<canvas bind:this={canvas} class="audio-spectrum-canvas"></canvas>

<style>
  canvas {
    display: block;
    width: 100%;
    height: 100%;
  }
</style>
