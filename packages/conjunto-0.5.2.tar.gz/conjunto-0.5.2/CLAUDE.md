# CLAUDE.md

Guidance for Claude Code when working in this repository.
**Treat this file as an index** — long-form prose lives in `docs/usage/*` and `docs/components/*`. Link, don't duplicate.

## Quick start

```bash
uv sync                              # install deps
uv run pytest                        # full test suite
uv run pytest tests/test_x.py::TestX::test_y
uv run black .                       # format
uv build                             # package
```

- **Never** call `python` / `pytest` / `black` bare — always `uv run …`.
- **Docs & changelog are mandatory** for any feature change. One-line `CHANGELOG.md`, details in `docs/`.
- **Do not `git push`.** `git add,stash,commit` is OK.

## Absolute rules (hard constraints)

| Rule                                                                                                                                                                                           | Rationale                                                                                                          |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------|
| Interfaces MUST start with `I` (`IMenuItem`, `IScope`, `IWidget`, …).                                                                                                                          | Project-wide convention.                                                                                           |
| Multi-line template comments use `{% comment %} … {% endcomment %}`. Never multi-line `{# … #}`.                                                                                               | Django raises `TemplateSyntaxError`.                                                                               |
| Code docs, docstrings, comments, translatable strings: **English**. Translations via i18n.                                                                                                     | Everything else must be translatable.                                                                              |
| Settings access: `request.scoped_settings.get("ns", "key")` via the proxy.                                                                                                                     | `AbstractSettings` / `request.app_settings` are gone.                                                              |
| Inside `conjunto/settings/*`, import Django's settings as `from django.conf import settings as django_settings`.                                                                               | The `conjunto.settings` package shadows `django.conf.settings`.                                                    |
| `DependentFieldsMixin` HTMX re-renders: pass form data as `initial=`, never bound.                                                                                                             | Bound forms validate on partial data and leak errors into the UI.                                                  |
| In-app pages extend `conjunto/app_base.html`. `conjunto/base.html` is for chrome-less pages only.                                                                                              | See `docs/usage/layout.md`.                                                                                        |
| Any form rendering a conjunto widget with `Media` (`TimePickerInput`, `DatePickerInput`, `PersistentFileWidget`, …) **must emit `{{ form.media }}`** — also in HTMX partials and modal bodies. | Without it the widget silently degrades to a plain text input — no console error.                                  |
| Datetime/Time output: use `                                                                                                                                                                    | localtime` (template) or `timezone.localtime()` (Python) before formatting — even with `USE_TZ=True`. Be explicit. | Renders intent, survives `USE_TZ=False`. |
| Python 3.12+. Black ≥ 25.12.0.                                                                                                                                                                 | CI fails otherwise.                                                                                                |
| HTMX work goes through the `htmx-patterns` skill. Conjunto/Tabler work goes through the `conjunto` / `tabler` skills.                                                                          | Skills are the single source of truth — never apply patterns from memory.                                          |

## What conjunto is

Django framework for component-based, plugin-extendable apps. Stack: **GDAPS** (plugins) + **Tabler.io** (Bootstrap 5) + **HTMX** + **django-tables2** + **crispy-forms**.

## Editable sibling workflow for consumers

Consumers (medux, medspeak, …) depend on conjunto via **regular PyPI** in `pyproject.toml` / `uv.lock`. For local dev they overlay the sibling checkout on top of the synced venv:

```makefile
dev-local: dev-pypi
	uv pip install --no-deps --quiet -e ../conjunto
	uv pip install --no-deps --quiet -e ../gdaps

dev-pypi:
	uv sync --dev
```

`pyproject.toml` and `uv.lock` are never mutated. `uv sync` wipes the overlay → re-run `make dev-local`. CI always resolves from PyPI. Replaces the older `[tool.uv.sources]`-with-commented-lines pattern.

## Repository map

| Path                                                   | Purpose                                                                                                                                                |
|--------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
| `src/conjunto/api/interfaces/`                         | Top-level GDAPS interfaces (`IElement`, `IElementGroup`, `IWidgetArea`, `IWidget`, `ILoginMethod`, `ILoginViewExtension`, `IPostLoginAction`).         |
| `src/conjunto/auth/`                                   | `ConjuntoLoginView`, `ConjuntoLoginCompleteView`, `ConjuntoAuthenticationForm`. Plugin-extendable login + two-step tenant pick. → `docs/usage/auth.md` |
| `src/conjunto/menu/`                                   | `IMenuItem` + `Menus` registry (consumed via `request.menus.<name>`).                                                                                  |
| `src/conjunto/settings/`                               | Settings **page UI** (`ISettingsGroup/Section/Form`).                                                                                                  |
| `src/conjunto/settings/scoped/`                        | Scoped-setting data layer: `ScopedSetting`, `Device`, `IScope`, registry, resolver, proxy.                                                             |
| `src/conjunto/scoped_settings.py`                      | Framework-level `SettingRegistry.register(...)` calls.                                                                                                 |
| `src/conjunto/tenants/`                                | `AbstractTenant` + `Tenant`, `TenantMembership`, `TenantRole`, mixins, `TenantPickView`.                                                               |
| `src/conjunto/widgets/`                                | Dashboard widgets (lazy HTMX, Gridstack reorder, USER-scoped layout).                                                                                  |
| `src/conjunto/audit_log/`                              | `ModelLogEntry`, `LogActionRegistry`, `log_action()`.                                                                                                  |
| `src/conjunto/htmx/views.py`                           | `HtmxRequestMixin`, `SuccessEventMixin`, `HtmxFormViewMixin`, `HtmxDeleteView`, `Modal*View`, `DependentFieldsView`.                                   |
| `src/conjunto/tables.py`                               | `RowAction`, `RowActionsMixin`, `IRowAction`, `HeaderAction`, `IHeaderAction`, `standard_add_action`.                                                  |
| `src/conjunto/filters.py`                              | `Filter`, `ChoiceFilter`, `BooleanFilter` for `TableListView`.                                                                                         |
| `src/conjunto/views.py`                                | `TableListView`, `AutoPermissionsViewMixin`, `CrispyFormHelperMixin`, `DialogType`.                                                                    |
| `src/conjunto/cms/`                                    | `StaticPage`, `VersionedPage`, `VersionedPageMixin`.                                                                                                   |
| `src/conjunto/forms/`                                  | `DependentFieldsMixin`, `PersistentFileField`, `SafeHTMLField`, `TimeField`/`TimePickerInput`, `DatePickerInput`, `SelectGroup*`.                      |
| `src/conjunto/sortable/`                               | `SortableModelMixin`, `SortableReorderView`, sortable template tags.                                                                                   |
| `src/conjunto/profiles/`                               | Optional `UserProfile` + avatar; `ISettingsForm` under User → Profile.                                                                                 |
| `src/conjunto/templatetags/avatar.py`                  | `{% load avatar %}` → `{% avatar %}` — **lives in core**, always loadable.                                                                             |
| `src/conjunto/archive/`                                | Soft-delete + versioning + retention (replaces `django-safedelete`).                                                                                   |
| `src/conjunto/wizard/`                                 | Multi-step form wizard with session drafts.                                                                                                            |
| `src/conjunto/middleware.py`                           | `ConjuntoMiddleware` + `ConjuntoMessagesMiddleware` + `TimezoneMiddleware`.                                                                            |
| `src/conjunto/templates/conjunto/`                     | `base.html` (slim) + `app_base.html` (full app layout).                                                                                                |
| `src/conjunto/static/conjunto/`                        | First-party assets only: `conjunto.css`, `conjunto.js`, `toasts.js`, `theme_toggle.js`, `datepicker.js`. **No third-party JS/CSS.**                    |
| `src/conjunto/_vendor/registry.py`                     | Library registry + downloader for the per-project asset bootstrap. No standalone CLI.                                                                  |
| `src/conjunto/management/commands/update_libraries.py` | Single entry point for fetching third-party JS/CSS.                                                                                                    |
| `src/conjunto/checks.py`                               | System check `conjunto.W002` (missing libraries).                                                                                                      |
| `tests/`                                               | Test suite + test app `tests/test_app/`.                                                                                                               |
| `docs/usage/`                                          | Long-form reference docs — link here instead of duplicating.                                                                                           |

## Static libraries

Conjunto **does not bundle** third-party JS/CSS in the wheel. Consumers fetch them with:

```bash
python manage.py update_libraries --suggest   # one-off: prints CONJUNTO_LIBRARIES = [...]
python manage.py update_libraries             # ongoing: download
python manage.py update_libraries --check     # CI guard, no network
python manage.py update_libraries --all|--list|--force
```

Required consumer settings:

```python
STATICFILES_DIRS = [BASE_DIR / "static", BASE_DIR / "static-vendored"]
CONJUNTO_VENDOR_DIR = BASE_DIR / "static-vendored" / "conjunto"
CONJUNTO_LIBRARIES = ["htmx", "tabler", ...]
```

`CORE_LIBRARIES = {"htmx", "tabler"}` (every page); `APP_LAYOUT_LIBRARIES = {"alpine", "litepicker", "sortable"}` (anything extending `app_base.html`); `--suggest` adds companions via `LIBRARY_COMPANIONS`. System check `conjunto.W002` warns about missing files (suppressed during `update_libraries`/`migrate`/`collectstatic`/`compilemessages`/`makemessages`/`makemigrations`/`test`).

**Hard rules.** Single entry point — never reintroduce `scripts/update_libraries.py` or `_vendor.registry.main_cli`. Argparse `help=` text must escape literal `%` as `%%` (Python 3.14). Never commit `static-vendored/`. TinyMCE is GPLv2-or-later — keep its license files alongside the editor JS. Tests must mock `conjunto._vendor.registry.requests.get`. Full reference: `docs/usage/static_libraries.md`.

## Zero Trust touchpoints

When touching these features, name the CISA pillar(s) in the commit message / PR body.

| Feature                                                                                | Pillar(s)             |
|----------------------------------------------------------------------------------------|-----------------------|
| `TenantAwareModelBackend`, `TenantMembership`, `TenantRole`, `tenant_role_permissions` | Identity, Application |
| `TenantModelMixin`, `OptionalTenantModelMixin`, `override_tenant()`                    | Data                  |
| `ScopedSetting.locked`, `lockable_scopes`                                              | Application, Data     |
| `session_lifetime_*`, remember-me, `ILoginMethod`, custom login                        | Identity              |
| `cj_device_id` cookie + DEVICE-scoped settings                                         | Device                |
| `maintenance_mode`                                                                     | Application           |
| `CONJUNTO_ENVIRONMENT_BANNER`                                                          | Operations            |

See `docs/usage/environment_banner.md`.

## Layout & templates

Full reference: `docs/usage/layout.md`.

- **`conjunto/base.html`** (~60 lines) — `<doctype>`, `<head>`, `<body>` with CSRF, modal/toast slots, scripts. Chrome-less.
- **`conjunto/app_base.html`** — extends `base.html`, adds topbar, sidebar, scrollable canvas (`.cj-page-content` is the only thing that scrolls), statusbar, both offcanvas panels. **In-app pages extend this.**

Block hierarchy: `title`, `meta`, `extra_css` → `top_bar` (`top_bar_brand` / `top_bar_center` / `top_bar_actions` / `top_bar_right`) → `sidebar` → `canvas` (`page_header` → `page_pretitle` / `page_title` / `page_actions`, `messages`, `content`) → `offcanvas_left` / `offcanvas_right` → `footer` → `statusbar` → `modal` / `toasts` / `scripts`. `top_bar_actions` is the slot for page-specific topbar buttons.

Menus consumed by `app_base.html`: `menus.main` (topbar nav), `menus.user` (avatar dropdown), `menus.sidebar` (left rail, 2 levels, `inline_action` per top-level item), `menus.footer` (statusbar links).

`cj_layout` priority chain: `settings.py defaults → request.scoped_settings (DB) → view context cj_layout` (last wins). Keys: `style` (`"fluid"`/`"boxed"`), `topbar_fixed`, `sidebar_width`, `color_scheme` (set server-side on `<html data-bs-theme>` to avoid dark-mode flash), `theme_switcher`. Django settings: `CONJUNTO_LAYOUT`, `CONJUNTO_TOPBAR_FIXED`, `CONJUNTO_SIDEBAR_WIDTH`, `CONJUNTO_THEME_SWITCHER`. DB override via `ScopedSetting` rows for `conjunto.layout_style` etc. Single hamburger `#cj-sidebar-toggle` works on every screen size (collapse on desktop / overlay on mobile); JS API `cjToggleSidebar()`. Offcanvas panels `#cj-offcanvas-left` / `#cj-offcanvas-right` are always in the DOM.

## GDAPS

Interfaces in `src/conjunto/api/interfaces/` (project-wide) and feature packages (e.g. `ISettingsGroup/Section/Form`, `IScope`). Hooks via `gdaps.hooks` — the `register_log_actions` hook is defined in `src/conjunto/api/interfaces/__init__.py`. Plugin implementations are auto-discovered.

## Menus (`IMenuItem`)

Full reference: `docs/usage/menus.md`. Plugins implement `IMenuItem`; route via `menu = "main"|"user"|"sidebar"|"footer"`. `parent` accepts a slug string or (preferred) a class reference. Items are instantiated per-request (`IMenuItem(request=request)`) and render only when `item.visible`. Visibility: `permissions_required = [...]` or override `_is_visible()`. Dynamic attrs: override `get_title()` / `get_icon()` / `get_disabled()` or make `title`/`icon` callables of `request`. Slug via `get_slug()` (method).

## Scoped settings (data layer)

Full reference: `docs/usage/settings.md`. Priority chain: **USER > DEVICE > GROUP > TENANT > VENDOR**. `locked` rows are floors; the **lowest-priority lock wins** (VENDOR lock = ultimate authority).

```python
val = request.scoped_settings.get("myapp", "feature_flag")              # raises if not registered
val = request.scoped_settings.get("myapp", "feature_flag", default=False)  # lenient
```

Templates: `{{ request.scoped_settings.myapp.feature_flag }}` (`""` if missing).

Register in a top-level `scoped_settings.py` (auto-discovered from `apps.ready()`):

```python
from conjunto.settings.scoped.models import Scope
from conjunto.settings.scoped.registry import SettingRegistry

SettingRegistry.register(
    "myapp", "feature_flag",
    type="bool", default=False,
    help_text="Enable the new feature.", icon="flag",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)
```

Registry **freezes** on first read; tests use `conjunto.settings.scoped.testing.unfreeze_registry()`. Resolver: one DB query per `(namespace, key)`, request-cached via `ScopedSettingsProxy`. GROUP tie-break: highest-pk group wins unlocked, lowest-pk locked wins. `ITenantScope.resolve` chain: `request.tenant` → `request.user.tenant_id` → `request.session['cj_tenant_id']`. DEVICE rows are anchored on a 10-year `cj_device_id` cookie set by `ConjuntoMiddleware`; bound to a user on first authenticated visit, never rebound.

Pre-registered keys (`src/conjunto/scoped_settings.py`):

| Key                                | Scopes                     | Purpose                                                                     |
|------------------------------------|----------------------------|-----------------------------------------------------------------------------|
| `conjunto.layout_style`            | V/T/USER (lock V/T)        | `"fluid"`/`"boxed"`                                                         |
| `conjunto.topbar_fixed`            | V/T/USER (lock V/T)        | bool                                                                        |
| `conjunto.sidebar_width`           | V/T/USER (lock V/T)        | CSS length                                                                  |
| `conjunto.color_scheme`            | V/T/DEVICE/USER (lock V/T) | `"light"`/`"dark"`                                                          |
| `conjunto.maintenance_mode`        | VENDOR                     | bool — non-staff redirected to `/maintenance/`                              |
| `auth.session_lifetime_default`    | V/T (lock V/T)             | seconds; 0 = browser-close (was `conjunto.session_lifetime_default` ≤0.3.2) |
| `auth.session_lifetime_remembered` | V/T (lock V/T)             | seconds; default 30 d (was `conjunto.session_lifetime_remembered` ≤0.3.2)   |
| `auth.show_remember_me`            | V/T (lock V/T)             | bool — show Remember-Me checkbox on login page                              |
| `conjunto.timezone`                | V/T/USER (lock V/T)        | IANA name; activated by `TimezoneMiddleware`                                |

## Settings page UI

Three flat interfaces: `ISettingsGroup` (rail category) → `ISettingsSection` (selectable, `?section=<n>`) → `ISettingsForm` (one form subsection). Each form declares `section = SomeSection` (class reference or slug). Built-ins: `UserGroup`, `UserProfileSection`, `UserNameFormPlugin`. URLs auto-mounted at `/settings/` via `PluginManager.urlpatterns()`.

HTMX flow: section clicks swap `#cj-settings-pane`; form saves return 204 + `HX-Trigger: settings:changed` + `showToast` + `HX-Reswap: none`. Pane refetches on `settings:changed from:body`. Invalid forms render the `settings-form` Django 6 partial (`conjunto/settings/page.html#settings-form`).

**Tabler layout rules** — follow the canonical Tabler settings page exactly (see the `tabler` skill's "Settings layout" section). Outer `.card > .row.g-0`. Rail `.col-md-3.border-end > .card-body` with `<h4 class="subheader">` (`.mt-4` on 2nd+) and `.list-group.list-group-transparent`. Pane `.col-md-9.d-flex.flex-column > .card-body` with `<h2 class="mb-4">` and `<h3 class="card-title">` (`.mt-4` on 2nd+). **No `<hr>` between subsections** — use `mt-4`. Don't improvise with plain Bootstrap.

## Tenants

Full reference: `docs/usage/tenants.md`.

- **`AbstractTenant`** — framework model (`uuid`, `name`, `slug` immutable after first save, `is_active`, timestamps). Domain fields go in the consumer subclass.
- **`Tenant`** — concrete default `conjunto_tenants.Tenant`; swap via `CONJUNTO_TENANT_MODEL = "myapp.Tenant"` **before** first migration.
- **`TenantMembership`** — `(user, tenant, role)`; save adds user to `tenant:<slug>:<role>` auth.Group. First member auto-`tenant_admin` (`TENANT_ADMIN_ROLE`).
- **`TenantRole`** — runtime-editable. `is_system=True` seeded from `AppConfig.tenant_role_permissions`; `is_system=False` user-defined. Save materializes the auth.Group authoritatively.
- **Role schema** on `AppConfig.tenant_role_permissions` with `extends` (acyclic DAG) — perms unioned across apps; `extends` must agree across apps. `tenant.save()` → `materialize_roles()` re-applies the schema (revokes perms no longer in schema).

Tenant binding (`ConjuntoMiddleware` → `conjunto.tenants.context` ContextVar): `request.tenant` → `request.user.tenant_id` → `request.session["cj_tenant_id"]` → first `TenantMembership`. `TenantAwareModelBackend` reads the ContextVar.

Tenant-scoped models:

| Mixin                           | `tenant` field   | `objects` (bound)        | `objects` (unbound)         | auto-inject on `create()`   |
|---------------------------------|------------------|--------------------------|-----------------------------|-----------------------------|
| `TenantModelMixin`              | FK NOT NULL      | `tenant=current`         | raises `TenantScopeMissing` | yes                         |
| `OptionalTenantModelMixin`      | FK nullable      | `current OR NULL`        | `NULL` only                 | no                          |
| `OptionalMultiTenantModelMixin` | M2M `tenants`    | contains current OR none | empty only                  | no                          |

All mixins: `Meta.base_manager_name = "all_objects"` so Django internals never tenant-filter. `TenantModelMixin` fails loud (background tasks/shells can't silently return empty). Escape via `with override_tenant(t):` or `Model.all_objects`. `is_vendor_owned` exposed by both Optional* variants → use with `VendorWriteProtectionMixin` to block non-vendor edits on vendor-owned rows. Pair with `TenantRequiredMixin` for ordinary tenant-bound edit views.

Picker: `TenantPickView` is **POST-only** at `/tenants/pick/`; UI is the inline statusbar dropup `{% tenant_badge %}` (no separate page). `TenantRequiredMixin` redirects to `/` with an info message when `request.tenant is None`. `get_allowed_tenants(request)` is request-cached. Don't model "no tenant" as a synthetic admin row — use `user.tenant=None` + session picker + `all_objects` for cross-tenant views.

Admin views in `conjunto.tenants.admin_urls`; consumers include them under their own admin URL tree and gate with their own `TenantAdminRequiredMixin`.

## Dashboard widgets

`IWidgetArea` (CSS-grid region, default 6 cols) + `IWidget` (lazy-loads template via HTMX into a card shell). Widget knobs: `area`, `template`, `col_span`, `min_col_span`/`max_col_span`, `resizable`, `removable`, `permission_required`, `@classmethod get_context_data(cls, request)`. URLs at `conjunto.widgets.urls` (`content`, `reorder`, `toggle-lock`). Per-area layout persisted as USER-scoped `ScopedSetting` (Gridstack `x`/`y`/`w`).

## Audit log

```python
from conjunto.audit_log import log_action

def register(registry):  # register_log_actions hook
    registry.register_action("user.login", label="Login", message="User logged in")

log_action("user.login", request, user=user)
```

Full reference: `docs/usage/logging.md`.

## Toasts

Full reference: `docs/components/toasts.md`. Driven by Django messages + HTMX. Toast container lives in `base.html`'s `{% block toasts %}`.

- `messages.success(request, "…")` works on both full loads and HTMX swaps (levels: `info`, `success`, `warning`, `error`, `debug`).
- `extra_tags="dismissible"` → persists until close; otherwise auto-hide 6 s.
- Direct HTMX response: `conjunto.http.add_toast(response, "Done", level="success")`.
- Client-side: dispatch a `showToast` `CustomEvent` on `window`.

**Middleware order**: `ConjuntoMessagesMiddleware` after `MessageMiddleware` and after `django_htmx.middleware.HtmxMiddleware`. HTMX responses get `HX-Trigger: conjunto:toasts`; full loads emit `<script id="cj-initial-toasts" type="application/json">`.

## Timezone activation

`TimezoneMiddleware` activates the `conjunto.timezone` scoped setting per request via `timezone.activate(ZoneInfo(...))` and `deactivate`s in `finally`. Empty/unknown → falls through to `settings.TIME_ZONE`. **Must run after `ConjuntoMiddleware`.** Templates still pipe through `|localtime` before `|date`/`|time` — explicit intent, survives `USE_TZ=False`.

## HTMX views

`HtmxFormViewMixin` (`src/conjunto/htmx/views.py`) supports both modal forms and **in-place partial pages**. For an in-place form that persists across saves:

- `success_url = ""` + `success_event = "some:event"` → mixin returns 204; `SuccessEventMixin.dispatch` adds `HX-Trigger`.
- In `form_valid`: call `super().form_valid(form)`, set `response["HX-Reswap"] = "none"` (otherwise the form's own `hx-target`/`hx-swap` removes the `<form>`). Add other events with `trigger_client_event(response, "showToast", params={...})`.
- The `<form>` keeps its normal `hx-target`/`hx-swap` so **validation errors** swap a re-rendered partial. A second element listens for the success event with `hx-trigger="some:event from:body"` + `hx-get="…"`.
- `form_invalid` is unaffected — point `template_name` at a Django 6 native partial (e.g. `"conjunto/settings/page.html#settings-form"`). **Don't** add `django-template-partials` — Django 6 ships native partials.

Canonical reference: `src/conjunto/settings/views.py::SettingsFormView`.

## Custom login

Full reference: `docs/usage/auth.md`.

`ConjuntoAuthenticationForm` (`src/conjunto/auth/forms.py`) is the form behind `ConjuntoLoginView`. It renders username + password + an optional Remember-Me checkbox (gated by `auth.show_remember_me`). The credentials form is **not** plugin-extendable on purpose — cross-cutting login concerns belong outside the pre-auth form (see `IPostLoginAction` and `ILoginViewExtension` below).

- **`ILoginViewExtension`** — `alter_context_data(view, ctx)`, `form_valid(view, request, user, form)`. Hook fires *after* `login()`. On the two-step tenant-pick path it fires in `ConjuntoLoginCompleteView` with `form=None` (the original credentials form is gone — extensions that need step-1 data must stash it themselves).
- **`IPostLoginAction`** — renderable hook fired on every authenticated page load via `{% render_plugins "IPostLoginAction" %}`; idiomatic place for one-shot post-login modals (timetracker check-in prompt, consent banners, …).
- **`ILoginMethod`** — alternative login buttons (SSO, SAML, magic link). Fields: `name`, `label`, `icon`, `url`, `weight`, `template_name` or override `render(request)`. Rendered via `{% login_methods %}` in `conjunto/templates/registration/login.html` (overridable).

`form.get_remember_me()` is the single source of truth — returns `False` whenever `auth.show_remember_me` is off, even if the POST contains `remember_me=on`. Lifetime: checked → `auth.session_lifetime_remembered`, unchecked or hidden → `auth.session_lifetime_default`.

## Tables / list views

Full reference: `docs/usage/tables.md` + `docs/usage/filters.md`. Modal target: `#dialog`. Building blocks:

- **`RowAction`** (dataclass) — `name`, `label`, `icon`, `url` (str or `(record) -> str`), `method`, `htmx`, `target`, `swap` (callables resolved per record), `confirm`, `confirm_style` (`"modal"`|`"inline"`), `variant`, `permission` (perm string or callable), `visible`, `weight`.
- **`RowActionsMixin`** — required `row_actions_namespace = "<ns>"`; routes must be named `<ns>_update` / `<ns>_delete` with `pk` kwarg (hard contract). Knobs: `row_actions` (default `("edit", "delete")`, `()` opts out), `extra_actions_menu`, `edit_permission`/`delete_permission`, `delete_confirm_style` (default `"modal"`), `delete_success_strategy` (`"wrapper-refresh"` / `"row-remove"`), `row_id_template` (`"row-{ns}-{pk}"`), `dialog_target` (`"#dialog"`), `listen_events`. **django-tables2 row_attrs callables must use `record` as the parameter name** or accept `**kwargs` (others are silently skipped by `call_with_appropriate`).
- **`IRowAction`** / **`IHeaderAction`** — GDAPS interfaces for pluggable actions; tables/views opt in via `extra_actions_menu` / `header_actions_menu`.
- **`HeaderAction`** + `standard_add_action("<ns>")` → `+Add` button reversing `<ns>_create`.
- **`TableListView`** — `SingleTableMixin` + `ListView` with `search_fields`, `filters`, `header_actions`, `header_actions_menu`, `filterset_class`. Context keys for `list_card.html`: `search_value`, `filter_values`, `header_actions`.
- **`Filter`/`ChoiceFilter`/`BooleanFilter`** — simple dataclass filters; for complex needs set `filterset_class` (django-filter takes over).

Templates: `conjunto/tables/list_card.html` (blocks: `card_header`, `search`, `filters`, `header_actions`, `card_body`). Partials: `_search.html`, `_header_actions.html`, `_row_actions.html`, `filters/_select.html`. Tags: `{% header_action_attrs action as attrs %}`, `|dict_item`.

**Delete success strategy**:
- `"wrapper-refresh"` (default) — server returns 204 + `HX-Trigger: <ns>:deleted`; wrapper re-fetches. Robust for paginated lists.
- `"row-remove"` — server returns 200 (empty body) + `HX-Retarget: #row-<ns>-<pk>` + `HX-Reswap: outerHTML swap:0.3s`. Idiomatic HTMX, no full re-render. The `<ns>:deleted` event still fires. Modal-confirm + row-remove also emits `closeModal` so `conjunto.js` hides the modal.

Modal form views built on `HtmxFormViewMixin` fire `HX-Trigger: <ns>:created|changed|deleted`; `list_card.html` self-refetches on `wrapper-refresh`.

## Sortable lists (`conjunto.sortable`)

Full reference: `docs/usage/sortable.md`. For FK-linked submodels (Meeting → Agendas, Patient → Medications, …) where order is owned by the parent. Fully HTMX-declarative — Sortable.js dispatches a native `end` event, HTMX listens via `hx-trigger="end"`, the server re-numbers via `bulk_update`. **No custom JavaScript** beyond the Sortable.js init in `conjunto.js`.

- **`SortableModelMixin`** (`from conjunto.sortable.models import …`) — `weight = PositiveIntegerField(default=0, db_index=True)`, `Meta.ordering = ("weight", "pk")`. `next_weight(step=10, **filter_kwargs)` for auto-append in `save()`.
- **`SortableReorderView`** (`from conjunto.sortable.views import …`) — class attrs: `model`, `parent_field` + `parent_url_kwarg`, `success_event`, `weight_step=10`. POST reads `request.POST.getlist("pks")`, intersects with the parent-scoped queryset, renumbers, returns 204.
- **Tags** (`{% load sortable %}`): `{% sortable_attrs reorder_url handle=".handle" indicator="" %}` on the container; `{% sortable_item obj %}` for each row.

**Hard import rule**: import from `conjunto.sortable.models` / `.views` — never from `conjunto.sortable` (the `__init__.py` is intentionally docstring-only to avoid pulling `models.py` into the import graph before `apps.ready()`).

Container needs CSS class `sortable` (rendered by `{% sortable_attrs %}`). Drag handle: `<span class="handle"><i class="ti ti-grip-vertical"></i></span>`. **Don't confuse with widget reorder** — widgets persist a per-user dashboard layout in `ScopedSetting`; sortable persists model-level ordering in the model's own `weight` column.

## Profiles & avatars

Full reference: `docs/usage/profiles.md`. `conjunto.profiles.UserProfile` is a `OneToOneField(AUTH_USER_MODEL, related_name="profile")` auto-created by a `post_save` signal. Fields: `avatar` (`ImageField`, `upload_to="avatars/<user_pk>/<uuid>.<ext>"`), timestamps. For pre-existing users: `UserProfile.get_or_create_for(user)`. Add `"conjunto.profiles"` to `INSTALLED_APPS` → `ISettingsForm` appears under User → Profile (form template needs `hx-encoding="multipart/form-data"`).

`{% load avatar %}` — **lives in core** (`conjunto.templatetags.avatar`), always loadable. Falls back to initials when `conjunto.profiles` is not installed. Never raises.

```django
{% load avatar %}
{% avatar %}                                  {# context.user / request.user #}
{% avatar some_user size="xs" extra_classes="me-2" %}
```

Sizes: `xs|sm|md|lg|xl|2xl` → `avatar-*` Tabler class. Initials: `first_name`+`last_name` → `get_full_name()` → `username[:2]` → `email[:2]` → `"?"`. **Never hand-roll avatar markup** — use `{% avatar %}`.

## TomSelect + HTMX (`django_tomselect`)

- **Always-on bug fix**: strips the `ts-hidden-accessible` (sr-only) class that `django_tomselect` leaks onto `.ts-wrapper` after re-init (would otherwise clip the wrapper to 1×1 px).

All four hooks compose freely. **Required consumer setup**: load TomSelect assets in `<head>` (override `extra_css` block + `{% tomselect_media %}`) — `use_htmx=True` widgets construct synchronously during body parse, `window.TomSelect` must exist. Run `compilejsi18n` so `/static/jsi18n/<lang>/djangojs.js` resolves. `hx-trigger` syntax: `change from:#id_<fieldname>` (Django default id, **not** `<fieldname>_id`).

## Forms

Full reference: `docs/usage/forms.md`.

**`DependentFieldsMixin`** — auto-wires HTMX on fields with a `<field>_changed(value)` callback (sets `hx-get`, `hx-trigger="change"`, `hx-include="closest form"`, `hx-target`, `hx-swap="outerHTML"`). In the fragment view re-instantiate the form **unbound** with `initial=<cleaned dict>` — never bound. Five-step value resolution: bound data → kwargs `initial` → field `initial` → instance → `None`. Callback always called, even with `value=None`. File inputs (`FileField`/`ImageField`) auto-receive `hx-preserve`; for files that must survive POST validation errors use `PersistentFileField`.

**`TimeField` + `TimePickerInput`** — drop-in replacement for `forms.TimeField`. Smart digit-only parsing (JS and Python identical, `_smart_parse_time`):

| Input   | Result  | Rule                                                |
|---------|---------|-----------------------------------------------------|
| `5`     | `05:00` | 1 digit → hour                                      |
| `12`    | `12:00` | 2 digits, ≤ 23 → `HH`                               |
| `45`    | `04:50` | 2 digits, > 23 → first = hour, second = tens-minute |
| `230`   | `23:00` | 3 digits, first two ≤ 23 → `HH:M0`                  |
| `730`   | `07:30` | 3 digits, first two > 23 → `0H:MM`                  |
| `0350`  | `03:50` | 4 digits → `HH:MM`                                  |

Args: `snap` (snap-to-next-N minutes for buttons + ↑/↓), `format_12h` (display only; POST stays 24h), `show_buttons` (default = on iff `snap` is set), `round_to` + `round_mode` (`"up"`/`"down"`/`"nearest"`) on the `TimeField`. Live `##:##` mask while typing; placeholder `--:--`. Pure JS (`conjunto/js/time_picker_input.js`), re-init on `htmx:load`. **Don't reimplement** the medux-timetracker-style `TimeSelector` — use `TimeField`/`TimePickerInput`.

## CSRF with HTMX

```django
{% load django_htmx %}
{% block body_attrs %} hx-headers='{"x-csrftoken": "{{ csrf_token }}"}'{% endblock %}
```

## Component patterns (when in doubt)

- `{% include "..." with param=value %}` — simple fragment reuse.
- `{% partialdef ... %}` (Django 6 native partials) — inline reusable snippets, especially for HTMX partial responses.
- `@register.inclusion_tag` — logic-heavy components.

## Things that NO LONGER exist (do not reintroduce)

- `AbstractSettings` model, `SETTINGS_MODEL` setting, `request.app_settings` → use `ScopedSetting` + `request.scoped_settings`.
- `CrudTableMixin` → renamed to `RowActionsMixin`.
- Tetra-based `ActionButtonsTable` / `TActionButton` / `HxActionButton` / `IActionButton` → use `RowAction` / `IRowAction`.
- Any Tetra components inside conjunto.
- Separate `/tenants/pick/` UI **page** — `TenantPickView` is POST-only; UI is the statusbar dropup.
- `scripts/update_libraries.py` and `_vendor.registry.main_cli` — single entry point is the management command.
- `django-safedelete` dependency — replaced by `conjunto.archive`.
- `{% load profiles %}` library — never existed. Use `{% load avatar %}`.
- Bundled third-party JS/CSS in the wheel — fetched per-project via `update_libraries`.
- `#cj-dialog` modal target — unified to `#dialog`.

## Code style

- Python 3.12+. Black ≥ 25.12.0.
- Type hints added progressively — add them on functions you touch.
- One-line `CHANGELOG.md` entry for every feature/fix; detailed prose in `docs/`.
