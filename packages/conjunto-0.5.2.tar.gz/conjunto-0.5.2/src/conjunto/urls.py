from django.urls import path

from .views import (
    MaintenanceView,
    ModelAutocompleteView,
    SaveColorSchemeView,
    SaveSidebarStateView,
)

app_name = "conjunto"

urlpatterns = [
    path("maintenance/", MaintenanceView.as_view(), name="maintenance"),
    path("autocomplete/", ModelAutocompleteView.as_view(), name="autocomplete"),
    path(
        "sidebar-state/<slug:side>/",
        SaveSidebarStateView.as_view(),
        name="sidebar-state",
    ),
    path("color-scheme/", SaveColorSchemeView.as_view(), name="color-scheme"),
]

# Note: ``conjunto.archive.urls`` is **not** included here — the archive
# URL module ships its own ``app_name`` and must be mounted as a separate
# include() from the consuming project's root urlconf (e.g. medux.urls)::
#
#     path("archive/", include("conjunto.archive.urls")),
#
# Keeping the archive URLs out of ``conjunto.urls`` avoids a forced
# namespace collision (``conjunto`` vs. ``conjunto_archive``) and keeps
# conjunto-only plugin projects free to opt into the UI or not.
