"""Custom Django model fields shipped by conjunto.

* :class:`ProtectedFileField` / :class:`ProtectedImageField` — store
  the file plaintext under :setting:`PROTECTED_MEDIA_ROOT` instead of
  :setting:`MEDIA_ROOT`. The contents are NOT encrypted; only the URL
  prefix is gated by Django (see ``LoginRequiredMediaView`` and
  downstream tenant-scoped wrappers).
* :class:`EncryptedFileField` / :class:`EncryptedImageField` — wrap
  :class:`ProtectedFileField` with AES-256-GCM stream encryption.
  Filenames are forced to a UUID4 (``<uuid>.enc``) so the on-disk path
  leaks no information about the original filename. The model MUST
  declare a companion :class:`~django.db.models.BinaryField`
  (``<name>_manifest`` by convention; rename via ``manifest_field=``)
  that holds the wrapped per-file DEK, the STREAM nonce prefix, the
  plaintext size and the key version.

The encrypted variants depend on a pluggable backend; see
:mod:`conjunto.files.encryption` for details and the
``CONJUNTO_FILE_ENCRYPTION_BACKEND`` setting.
"""

from __future__ import annotations

import datetime
import io
import logging
import os
from typing import IO, Iterator

from django.core import checks
from django.core.exceptions import FieldDoesNotExist
from django.core.files.base import ContentFile, File
from django.core.files.utils import validate_file_name
from django.db import models
from django.db.models import FileField, ImageField
from django.db.models.fields.files import FieldFile, ImageFieldFile

from .files.encryption import (
    DEFAULT_CHUNK_SIZE,
    Manifest,
    MissingManifestError,
    decrypt_stream,
    encrypt_uploaded_file,
    generate_uuid_filename,
    get_backend,
    unwrap_dek_for_read,
)
from .files.storage import ProtectedFileSystemStorage

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# Plain protected fields (unchanged behaviour)
# --------------------------------------------------------------------------- #


class ProtectedFileField(FileField):
    def __init__(self, **kwargs):
        kwargs["storage"] = ProtectedFileSystemStorage()
        super().__init__(**kwargs)

    def generate_filename(self, instance, filename):
        if callable(self.upload_to):
            filename = self.upload_to(instance, filename)
        else:
            dirname = datetime.datetime.now().strftime(str(self.upload_to))
            filename = os.path.join(dirname, filename)
        filename = validate_file_name(filename, allow_relative_path=True)
        logger.debug(
            f"Creating temp file for {filename}: {self.storage.generate_filename(filename)}"
        )
        return self.storage.generate_filename(filename)

    def pre_save(self, instance, add):
        """
        Ensure Django saves the full relative path (including upload_to).
        """
        file = super().pre_save(instance, add)

        if file and hasattr(file, "name"):
            # When upload_to is a callable, the storage has already built
            # the full path via generate_filename -> nothing to prepend.
            # When upload_to is a string, make sure the stored file path
            # includes that prefix (compatibility guard).
            upload_to = self.upload_to
            if (
                isinstance(upload_to, str)
                and upload_to
                and not file.name.startswith(upload_to)
            ):
                file.name = f"{upload_to}/{file.name}"
        return file


class ProtectedImageField(ImageField):
    def __init__(self, **kwargs):
        kwargs["storage"] = ProtectedFileSystemStorage()
        super().__init__(**kwargs)


# --------------------------------------------------------------------------- #
# Encrypted field-file descriptor
# --------------------------------------------------------------------------- #


class EncryptedFieldFile(FieldFile):
    """FieldFile that knows how to stream-decrypt its backing storage.

    * ``open("rb")`` returns the raw **ciphertext** stream. This is the
      mode the project-wide protected-media safety net uses; it must
      never expose plaintext.
    * :meth:`open_decrypted` returns a plaintext iterator suitable for
      :class:`django.http.FileResponse`. Each call emits one audit-log
      entry through the configured backend.
    * :attr:`url` raises — encrypted files MUST be served through a
      plugin-owned view that calls :meth:`open_decrypted`, never
      through a direct media URL.
    * :meth:`save` encrypts the content **before** the storage layer
      sees it, so plaintext never touches disk. Bypassing this (e.g.
      via ``field.storage.save(...)`` directly) is the migration path's
      job, not normal application code.
    """

    def save(self, name, content, save=True):
        """Encrypt ``content`` then persist the ciphertext via storage."""
        from django.core.exceptions import ImproperlyConfigured

        tenant_id = getattr(self.instance, "tenant_id", None)
        if tenant_id is None:
            raise ImproperlyConfigured(
                f"EncryptedFileField {self.field.model.__name__}.{self.field.name} "
                f"requires a tenant_id on the model instance."
            )

        target_name = self.field.generate_filename(self.instance, name or "upload")
        file_uuid = os.path.splitext(os.path.basename(target_name))[0]

        backend = get_backend()
        model_label = (
            f"{self.field.model._meta.app_label}.{self.field.model._meta.model_name}"
        )

        # Rewind so re-reads (validators, forms) don't strand the cursor.
        try:
            content.seek(0)
        except (AttributeError, io.UnsupportedOperation):
            pass

        buf = io.BytesIO()
        manifest = encrypt_uploaded_file(
            content,
            buf,
            backend=backend,
            tenant_id=tenant_id,
            model_label=model_label,
            field_name=self.field.name,
            file_uuid=file_uuid,
            chunk_size=self.field.chunk_size,
            max_size=self.field.max_plain_size,
        )
        buf.seek(0)

        saved_name = self.storage.save(target_name, ContentFile(buf.getvalue()))
        self.name = saved_name
        setattr(self.instance, self.field.attname, self.name)
        setattr(self.instance, self.field.manifest_attname, manifest.to_bytes())
        self._committed = True
        if save:
            self.instance.save()

    @property
    def url(self) -> str:  # type: ignore[override]
        raise NotImplementedError(
            f"EncryptedFileField.url is intentionally disabled. "
            f"Serve the file from a plugin view via "
            f"FileResponse({self.field.name}.open_decrypted()) so the "
            f"decrypt + audit happen under your access checks."
        )

    @property
    def size(self) -> int:  # type: ignore[override]
        manifest = self._manifest
        if manifest is None:
            return super().size
        return manifest.plain_size

    # -- manifest access --------------------------------------------- #

    @property
    def _manifest(self) -> Manifest | None:
        raw = getattr(self.instance, self.field.manifest_attname, None)
        if raw in (None, b""):
            return None
        return Manifest.from_bytes(bytes(raw))

    def _file_uuid(self) -> str:
        return os.path.splitext(os.path.basename(self.name))[0]

    # -- decrypt API ------------------------------------------------- #

    def open_decrypted(self) -> "_DecryptedFileResponseBody":
        """Return an iterable of plaintext chunks for the file.

        Raises :class:`MissingManifestError` if the row has no manifest
        (typically a pre-encryption row that has not been migrated yet —
        run ``manage.py encrypt_filefield``).
        """
        manifest = self._manifest
        if manifest is None:
            raise MissingManifestError(
                f"{self.field.model.__name__}.{self.field.name} (pk="
                f"{self.instance.pk}) has no manifest — run "
                f"manage.py encrypt_filefield to migrate, or check that the "
                f"manifest column was not cleared."
            )
        backend = get_backend()
        tenant_id = getattr(self.instance, "tenant_id", None)
        if tenant_id is None:
            raise MissingManifestError(
                f"{self.field.model.__name__} pk={self.instance.pk} has no "
                f"tenant_id — required to pick the KEK."
            )
        model_label = (
            f"{self.field.model._meta.app_label}.{self.field.model._meta.model_name}"
        )
        file_uuid = self._file_uuid()
        dek = unwrap_dek_for_read(
            manifest,
            backend=backend,
            tenant_id=tenant_id,
            model_label=model_label,
            field_name=self.field.name,
            file_uuid=file_uuid,
        )
        # Open the ciphertext file fresh — independent of the FieldFile's
        # own buffer state so the caller can iterate cleanly.
        source = self.storage.open(self.name, "rb")
        try:
            backend.audit_decrypt(
                tenant_id=tenant_id,
                key_version=manifest.key_version,
                model_label=model_label,
                object_pk=self.instance.pk,
                field_name=self.field.name,
                size=manifest.plain_size,
            )
        except Exception:  # pragma: no cover — audit MUST NOT break decrypts
            logger.warning("audit_decrypt failed", exc_info=True)
        return _DecryptedFileResponseBody(
            source=source,
            dek=dek,
            nonce_prefix=manifest.nonce_prefix,
            chunk_size=self.field.chunk_size,
            plain_size=manifest.plain_size,
        )


class _DecryptedFileResponseBody:
    """File-like wrapper around :func:`decrypt_stream`.

    Exposes the small interface :class:`django.http.FileResponse`
    actually consumes: ``read(size)``, iteration, ``close()``, and a
    ``len()`` hint via :func:`len` is not used by Django but kept
    indirectly through ``size``.
    """

    def __init__(
        self,
        *,
        source: IO[bytes],
        dek: bytes,
        nonce_prefix: bytes,
        chunk_size: int,
        plain_size: int,
    ) -> None:
        self._source = source
        self._iter: Iterator[bytes] = decrypt_stream(
            source, dek=dek, nonce_prefix=nonce_prefix, chunk_size=chunk_size
        )
        self._buffer = b""
        self._closed = False
        self.size = plain_size  # used by FileResponse for Content-Length

    def read(self, size: int = -1) -> bytes:
        if size is None or size < 0:
            chunks = [self._buffer]
            self._buffer = b""
            chunks.extend(self._iter)
            return b"".join(chunks)
        while len(self._buffer) < size:
            try:
                self._buffer += next(self._iter)
            except StopIteration:
                break
        out, self._buffer = self._buffer[:size], self._buffer[size:]
        return out

    def __iter__(self) -> Iterator[bytes]:
        if self._buffer:
            yield self._buffer
            self._buffer = b""
        yield from self._iter

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            self._source.close()
        except Exception:  # pragma: no cover
            pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


# --------------------------------------------------------------------------- #
# EncryptedFileField
# --------------------------------------------------------------------------- #


class EncryptedFileField(FileField):
    """``FileField`` whose contents are stream-encrypted at rest.

    Storage location is :setting:`PROTECTED_MEDIA_ROOT` (never the
    public :setting:`MEDIA_ROOT`). Filenames are forced to a UUID4 —
    the on-disk path leaks no information about the original upload
    name.

    The model **must** declare a companion :class:`BinaryField` that
    carries the wrapped per-file DEK, the STREAM nonce prefix, the
    key version and the plaintext size. By convention its name is
    ``<file_field>_manifest``; pass ``manifest_field="some_name"``
    to override::

        class Report(models.Model):
            pdf = EncryptedFileField(upload_to="reports/")
            pdf_manifest = models.BinaryField(
                null=True, blank=True, editable=False,
            )

    The check framework (``manage.py check``) rejects models that
    forget the manifest companion or declare it as the wrong type.

    Constructor extras (over :class:`FileField`):

    * ``manifest_field`` — name of the sibling ``BinaryField``.
      Defaults to ``<file_field>_manifest``.
    * ``chunk_size`` — STREAM plaintext chunk size in bytes
      (default 4 MiB). Must be the same for encrypt and decrypt; only
      adjust on green-field deployments.
    * ``max_plain_size`` — reject uploads larger than this many bytes
      (default ``None`` = unlimited).
    """

    attr_class = EncryptedFieldFile
    description = "File field with at-rest AES-256-GCM encryption"

    def __init__(
        self,
        *,
        manifest_field: str | None = None,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        max_plain_size: int | None = None,
        **kwargs,
    ) -> None:
        kwargs.setdefault("storage", ProtectedFileSystemStorage())
        self._manifest_field_kwarg = manifest_field
        self.chunk_size = chunk_size
        self.max_plain_size = max_plain_size
        super().__init__(**kwargs)

    # -- migration support ------------------------------------------- #

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        if self._manifest_field_kwarg is not None:
            kwargs["manifest_field"] = self._manifest_field_kwarg
        if self.chunk_size != DEFAULT_CHUNK_SIZE:
            kwargs["chunk_size"] = self.chunk_size
        if self.max_plain_size is not None:
            kwargs["max_plain_size"] = self.max_plain_size
        # Drop the storage kwarg — it's always ProtectedFileSystemStorage and
        # serialising it would force every consuming project to import it
        # in their migrations.
        kwargs.pop("storage", None)
        return name, path, args, kwargs

    @property
    def manifest_attname(self) -> str:
        return self._manifest_field_kwarg or f"{self.name}_manifest"

    # -- companion validation ---------------------------------------- #

    def check(self, **kwargs):
        errors = super().check(**kwargs)
        errors.extend(self._check_manifest_companion())
        return errors

    def _check_manifest_companion(self):
        if self.model is None:
            return []
        sibling_name = self.manifest_attname
        try:
            sibling = self.model._meta.get_field(sibling_name)
        except FieldDoesNotExist:
            return [
                checks.Error(
                    f"EncryptedFileField '{self.name}' requires a companion "
                    f"BinaryField '{sibling_name}' on the model.",
                    hint=(
                        f"Add `{sibling_name} = models.BinaryField("
                        f"null=True, blank=True, editable=False)` to "
                        f"{self.model.__name__}, or pass "
                        f"manifest_field='<existing-name>' to the field."
                    ),
                    obj=self,
                    id="conjunto.E001",
                )
            ]
        if not isinstance(sibling, models.BinaryField):
            return [
                checks.Error(
                    f"EncryptedFileField companion "
                    f"'{self.model.__name__}.{sibling_name}' must be a "
                    f"BinaryField (got {type(sibling).__name__}).",
                    obj=self,
                    id="conjunto.E002",
                )
            ]
        return []

    # -- filename forcing -------------------------------------------- #

    def generate_filename(self, instance, filename):
        # ``filename`` is whatever the upload provided; we ignore it
        # entirely. ``upload_to`` is used as a path prefix only.
        if callable(self.upload_to):
            prefix_with_name = self.upload_to(instance, filename)
            prefix = os.path.dirname(prefix_with_name)
        elif self.upload_to:
            prefix = datetime.datetime.now().strftime(str(self.upload_to))
        else:
            prefix = ""
        new_name = generate_uuid_filename(prefix)
        new_name = validate_file_name(new_name, allow_relative_path=True)
        return self.storage.generate_filename(new_name)

    # -- save path: encrypt before write ----------------------------- #

    def pre_save(self, model_instance, add):
        """Handle the form-upload path: ``obj.<field> = upload; obj.save()``.

        When :meth:`EncryptedFieldFile.save` is called explicitly the
        file is already encrypted and committed by the time we get here
        — we just return the persisted name. For form-style assignments
        we route the upload through the same save() method so the
        encrypt/manifest logic stays in one place.
        """
        file = getattr(model_instance, self.attname)
        if file is None or not file:
            return None

        if file._committed:
            return file.name

        # An uncommitted assignment (e.g. ``obj.blob = request.FILES["x"]``).
        # Delegate to the descriptor's save() so encryption happens uniformly.
        # save=False to avoid recursive instance.save() — we're inside pre_save.
        file.save(file.name or "upload", file.file, save=False)
        return file.name


# --------------------------------------------------------------------------- #
# EncryptedImageField
# --------------------------------------------------------------------------- #


class EncryptedFieldImageFile(EncryptedFieldFile, ImageFieldFile):
    """ImageFieldFile + encryption.

    We deliberately do **not** override ``_get_image_dimensions``; the
    base ImageField only inspects dimensions at upload time, and after
    that the cached ``width_field``/``height_field`` columns are used
    directly. Re-reading dimensions on every access would require a
    full decrypt and defeats the point of the dimension cache.
    """

    def save(self, name, content, save=True):
        # Sanitize the image (validate, populate width/height, strip EXIF)
        # BEFORE encryption — the cleaned bytes are what go to disk.
        sanitized = self.field._sanitize_image(self.instance, name, content)
        super().save(name, sanitized, save=save)


class EncryptedImageField(EncryptedFileField):
    """:class:`ImageField` equivalent with at-rest encryption.

    Validates the upload is a real image via Pillow before encrypting,
    optionally caches ``width_field``/``height_field`` like
    :class:`django.db.models.ImageField`, and **strips EXIF** so
    GPS/camera-serial metadata doesn't leak into the ciphertext.
    """

    attr_class = EncryptedFieldImageFile
    description = "Image field with at-rest AES-256-GCM encryption"

    def __init__(
        self,
        *,
        width_field: str | None = None,
        height_field: str | None = None,
        strip_exif: bool = True,
        **kwargs,
    ) -> None:
        self.width_field = width_field
        self.height_field = height_field
        self.strip_exif = strip_exif
        super().__init__(**kwargs)

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        if self.width_field:
            kwargs["width_field"] = self.width_field
        if self.height_field:
            kwargs["height_field"] = self.height_field
        if not self.strip_exif:
            kwargs["strip_exif"] = False
        return name, path, args, kwargs

    def _sanitize_image(self, model_instance, name, content):
        """Validate, capture dimensions, optionally strip EXIF.

        Returns a fresh in-memory file ready for encryption.
        """
        from PIL import Image

        try:
            content.seek(0)
        except (AttributeError, io.UnsupportedOperation):
            pass
        img = Image.open(content)
        img.load()  # force decode for validation

        if self.width_field:
            setattr(model_instance, self.width_field, img.width)
        if self.height_field:
            setattr(model_instance, self.height_field, img.height)

        out = io.BytesIO()
        fmt = img.format or "PNG"
        if self.strip_exif:
            # Re-save without EXIF / ICC / XMP / comment metadata by
            # creating a fresh image from the decoded pixels — no
            # metadata block is carried over.
            clean = Image.new(img.mode, img.size)
            clean.paste(img)
            clean.save(out, format=fmt)
        else:
            img.save(out, format=fmt)
        out.seek(0)
        return File(out, name=name)
