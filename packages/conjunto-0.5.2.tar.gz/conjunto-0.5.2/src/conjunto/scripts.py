"""Request-scoped registry for on-demand feature asset loading.

Views or template tags call ``request.cj_scripts.add(path)`` to register
a JS file and ``request.cj_scripts.add_css(path)`` for CSS. The
``{% conjunto_render_scripts %}`` tag in the base template emits the
collected tags once, deduplicated and in insertion order.

The registry is attached to the request by
:class:`~conjunto.middleware.ScriptRegistryMiddleware`.
"""

from __future__ import annotations

from django.templatetags.static import static
from django.utils.safestring import mark_safe


class ScriptRegistry:
    """Request-scoped registry for on-demand JS and CSS loading."""

    def __init__(self):
        self._scripts: list[tuple[str, bool]] = []
        self._css: list[str] = []
        self._seen: set[str] = set()

    def add(self, path: str, defer: bool = True) -> None:
        """Register a script path. Duplicates are silently ignored."""
        if path not in self._seen:
            self._seen.add(path)
            self._scripts.append((path, defer))

    def add_css(self, path: str) -> None:
        """Register a CSS path. Duplicates are silently ignored."""
        if path not in self._seen:
            self._seen.add(path)
            self._css.append(path)

    def render(self) -> str:
        """Return all registered scripts and CSS as HTML tags.

        Each ``<script>`` carries a deterministic id and
        ``hx-preserve='true'`` for the same reason as
        :func:`conjunto.templatetags.conjunto._render_js` — htmx must
        not re-evaluate scripts on hx-boost body swaps, otherwise IIFE
        listeners stack on document/window across navigations.
        """
        from .templatetags.conjunto import _script_id

        result = ""
        for path in self._css:
            result += f"<link rel='stylesheet' href='{static(path)}'>\n"
        for path, defer in self._scripts:
            defer_attr = " defer" if defer else ""
            sid = _script_id(path)
            result += (
                f"<script type='application/javascript' "
                f"src='{static(path)}'{defer_attr} "
                f"id='{sid}' hx-preserve='true'></script>\n"
            )
        return mark_safe(result)
