"""Plug the keyboard-shortcut overview into the conjunto settings page.

Adds one section ``User → Keyboard shortcuts`` rendered with a custom
template that lists every active shortcut for the request user. The
section is read-only by design — overrides happen at vendor / tenant
admin pages, see ``conjunto.shortcuts.admin_views``. Per-action edit
boxes appear only for actions whose ``writable_scopes`` include
``Scope.USER`` (rare: cosmetic preferences only).
"""

from __future__ import annotations

from django.utils.translation import gettext_lazy as _

from conjunto.settings.interfaces import ISettingsForm
from conjunto.settings.menus import UserGroup
from conjunto.settings.interfaces import ISettingsSection


class KeyboardShortcutsSection(ISettingsSection):
    """User → Keyboard shortcuts (read-only cheat-sheet for end users)."""

    name = "shortcuts"
    group = UserGroup
    title = _("Keyboard shortcuts")
    icon = "keyboard"
    weight = 50


class KeyboardShortcutsForm(ISettingsForm):
    """Custom-template subsection that lists effective shortcuts."""

    section = KeyboardShortcutsSection
    name = "shortcuts_overview"
    title = _("Active shortcuts")
    weight = 0
    template = "conjunto/shortcuts/_settings_overview.html"
