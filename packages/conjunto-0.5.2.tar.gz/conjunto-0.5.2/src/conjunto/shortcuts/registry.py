"""In-memory registry of :class:`IShortcutAction` subclasses.

Built once at app startup from GDAPS' ``IShortcutAction.__implementations__``,
frozen, and queried thereafter by the resolver, the settings UIs, the
template tags, and the system checks.

The registry is *index*-only — actual key bindings live in
:class:`~conjunto.settings.scoped.models.ScopedSetting` rows under the
``"shortcuts"`` namespace. Use :func:`effective_key_for` /
:func:`bindings_for_request` to resolve them.
"""

from __future__ import annotations

from typing import Iterable, Optional

from .interfaces import IShortcutAction
from .scopes import normalize_key


class ShortcutRegistry:
    """Class-level registry of action subclasses, indexed by full id."""

    _by_id: dict[str, type[IShortcutAction]] = {}
    _frozen: bool = False

    @classmethod
    def freeze(cls) -> None:
        """Snapshot every loaded :class:`IShortcutAction` subclass.

        Called from :meth:`ShortcutsConfig.ready` after the
        ``shortcuts`` autodiscover has run. Idempotent — re-freezing is a
        no-op so that test suites can re-import the package safely.
        """
        if cls._frozen:
            return
        cls._by_id = {}
        for action_cls in IShortcutAction.enabled_plugins():
            if not action_cls.namespace or not action_cls.name:
                # Skip the abstract base / malformed declarations.
                continue
            full_id = action_cls.full_id()
            if full_id in cls._by_id:
                # Two plugins claim the same id — last loaded wins, but
                # we surface this as system check S005.
                continue
            cls._by_id[full_id] = action_cls
        cls._frozen = True

    @classmethod
    def unfreeze(cls) -> None:
        """Test helper — re-allow registration."""
        cls._frozen = False
        cls._by_id = {}

    @classmethod
    def all(cls) -> Iterable[type[IShortcutAction]]:
        return cls._by_id.values()

    @classmethod
    def get(cls, full_id: str) -> Optional[type[IShortcutAction]]:
        return cls._by_id.get(full_id)

    @classmethod
    def by_category(cls) -> dict[str, list[type[IShortcutAction]]]:
        out: dict[str, list[type[IShortcutAction]]] = {}
        for a in sorted(cls._by_id.values(), key=lambda c: c.weight):
            out.setdefault(str(a.category or "Other"), []).append(a)
        return out


# ─────────────────────────────────────────────────────────────────────
# Effective-binding resolution helpers
# ─────────────────────────────────────────────────────────────────────


def effective_key_for(request, action_cls: type[IShortcutAction]) -> str:
    """Return the active key for ``action_cls`` in ``request`` context.

    Walks Conjunto's scoped-settings resolver. Returns ``""`` when no
    binding exists at any scope and the action has no ``default_key``.
    """
    scoped = getattr(request, "scoped_settings", None)
    if scoped is None:
        return action_cls.default_key
    val = scoped.get("shortcuts", action_cls.full_id(), default=None)
    if val is None or val == "":
        return action_cls.default_key
    return val


def bindings_for_request(request) -> list[dict]:
    """Return the per-request bindings list injected into the page.

    Each entry has the shape::

        {
          "id":      "cashbook.entry.create",
          "key":     "n",
          "scope":   "app:cashbook:*",   # or "global", "view:foo"
          "mode":    "single",
          "always_active": false,
          "handler": {
            "kind":   "htmx-get",
            "url":    "/cashbook/entries/add/",
            "target": "#dialog",
          },
        }

    Filtered to actions where :meth:`IShortcutAction.is_available`
    returns ``True`` for this request. Unbound actions (effective key
    is empty) are skipped.
    """
    out: list[dict] = []
    for action_cls in ShortcutRegistry.all():
        if not action_cls.is_available(request):
            continue
        key = normalize_key(effective_key_for(request, action_cls))
        if not key:
            continue
        out.append(
            {
                "id": action_cls.full_id(),
                "key": key,
                "scope": _scope_string(action_cls),
                "mode": action_cls.resolved_mode(),
                "always_active": bool(action_cls.always_active),
                "handler": _handler_payload(request, action_cls),
            }
        )
    return out


def _scope_string(action_cls: type[IShortcutAction]) -> str:
    if action_cls.scope_kind == "global":
        return "global"
    match = action_cls.scope_match
    if match is None:
        # Plugin author asked for "view" scope without an explicit pattern;
        # the action only fires when its template explicitly mounts.
        return f"{action_cls.scope_kind}:{action_cls.full_id()}"
    if callable(match):
        # Callable matchers can't be serialised; encode as id-keyed scope
        # and let the server include/exclude during binding generation.
        return f"{action_cls.scope_kind}:{action_cls.full_id()}"
    return f"{action_cls.scope_kind}:{match}"


def _handler_payload(request, action_cls: type[IShortcutAction]) -> dict:
    """Materialise the handler params into client-ready values."""
    from django.urls import NoReverseMatch, reverse

    kind = action_cls.handler_kind
    params = dict(action_cls.handler_params or {})
    payload: dict = {"kind": kind}

    if kind in {"navigate", "htmx-get", "htmx-post"}:
        url_name = params.get("url_name", "")
        url_kwargs = params.get("url_kwargs", {}) or {}
        try:
            payload["url"] = reverse(url_name, kwargs=url_kwargs) if url_name else ""
        except NoReverseMatch:
            payload["url"] = ""
        if "target" in params:
            payload["target"] = params["target"]
        if "swap" in params:
            payload["swap"] = params["swap"]
    elif kind == "click-selector":
        payload["selector"] = params.get("selector", "")
    elif kind == "custom-event":
        payload["event_name"] = params.get("event_name", "")
        payload["event_detail"] = params.get("event_detail", {})
    return payload
