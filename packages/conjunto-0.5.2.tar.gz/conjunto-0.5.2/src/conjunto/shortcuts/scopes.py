"""Scope-matching and key-normalisation helpers.

Pure-Python utilities — no Django imports — so they can run server-side
(during checks/tests) and conceptually mirror what the client-side resolver
does in JavaScript.
"""

from __future__ import annotations

import fnmatch


# ─────────────────────────────────────────────────────────────────────
# Activation-scope matching
# ─────────────────────────────────────────────────────────────────────

ACTIVE_SCOPE_KINDS = ("global", "app", "view")


def matches_url_pattern(pattern: str, url_name: str) -> bool:
    """Glob-match a URL-name pattern against a resolved URL name.

    Patterns use shell glob syntax: ``"cashbook:*"``, ``"cashbook:entry-*"``.
    A bare ``"cashbook"`` matches only the exact URL name ``"cashbook"``;
    use ``"cashbook:*"`` to match the whole namespace.
    """
    if not pattern or not url_name:
        return False
    return fnmatch.fnmatchcase(url_name, pattern)


def overlap(scope_a_kind: str, match_a, scope_b_kind: str, match_b) -> bool:
    """True iff two activation scopes can be active *at the same time*.

    Two ``"global"`` scopes always overlap. A ``"global"`` and any other
    overlap. Two ``"app"`` scopes overlap iff their url-name globs have a
    non-empty intersection. ``"view"`` only overlaps when it's the same
    explicit mount — without runtime info we treat distinct ``view``
    matches as disjoint.

    Used by system check S002 to flag default-key conflicts.
    """
    if "global" in (scope_a_kind, scope_b_kind):
        return True
    if scope_a_kind != scope_b_kind:
        return False
    if scope_a_kind == "view":
        return _normalised(match_a) == _normalised(match_b)
    # app vs app — check glob intersection
    a, b = _normalised(match_a), _normalised(match_b)
    if not a or not b:
        return False
    return _globs_intersect(a, b)


def _normalised(match) -> str:
    if match is None:
        return ""
    if callable(match):
        # Two callables: we cannot statically decide overlap; treat as
        # opaque tokens so only identical callables compare equal.
        return "<callable>"
    return str(match)


def _globs_intersect(a: str, b: str) -> bool:
    if a == b:
        return True
    # Treat ``foo:*`` as superset of ``foo:bar`` and ``foo:bar*``.
    if a.endswith(":*") and b.startswith(a[:-1]):
        return True
    if b.endswith(":*") and a.startswith(b[:-1]):
        return True
    if "*" not in a and "*" not in b:
        return False
    return fnmatch.fnmatchcase(b.replace("*", "_"), a) or fnmatch.fnmatchcase(
        a.replace("*", "_"), b
    )


# ─────────────────────────────────────────────────────────────────────
# Key-string normalisation
# ─────────────────────────────────────────────────────────────────────

_MOD_ORDER = ("Ctrl", "Alt", "Shift", "Meta", "Cmd", "CtrlOnly")


def normalize_key(key: str) -> str:
    """Canonicalise a key string.

    Only single-step keys are supported (with optional ``Ctrl`` / ``Alt`` /
    ``Shift`` / ``Meta`` / ``Cmd`` modifiers). Chord-style sequences like
    ``"g d"`` were dropped in 2026-05-18 — they swallowed keystrokes from
    focused inputs and surprised the user. Migrate to a modifier
    combination instead (e.g. ``Alt+d``).

    - Trim leading/trailing whitespace
    - Sort modifiers in fixed order ``Ctrl→Alt→Shift→Meta→Cmd→key``
    - Lower-case single-letter keys (``"N"`` → ``"n"``)

    Returns ``""`` for an empty/None input.
    """
    if not key:
        return ""
    return _normalise_step(key.strip())


def _normalise_step(step: str) -> str:
    pieces = [p for p in step.split("+") if p]
    if not pieces:
        return ""
    *mods, base = pieces
    seen: set[str] = set()
    sorted_mods: list[str] = []
    for m in _MOD_ORDER:
        for p in mods:
            if p == m and m not in seen:
                sorted_mods.append(m)
                seen.add(m)
    # Lowercase single-letter base keys; leave function keys, special keys
    # (Enter, Tab, ...) untouched.
    if len(base) == 1 and base.isalpha():
        base = base.lower()
    return "+".join(sorted_mods + [base])
