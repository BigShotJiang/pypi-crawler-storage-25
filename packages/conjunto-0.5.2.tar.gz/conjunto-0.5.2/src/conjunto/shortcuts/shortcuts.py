"""Conjunto's built-in shortcut actions.

Plugins ship their own ``shortcuts.py``; this file covers global navigation
and the always-active utilities (help, search, save, palette).
"""

from django.utils.translation import gettext_lazy as _

from .interfaces import IShortcutAction


# ─────────────────────────────────────────────────────────────────────
# Generic navigation (URL-less; relies on browser history)
# ─────────────────────────────────────────────────────────────────────


class NavBackAction(IShortcutAction):
    namespace = "nav"
    name = "back"
    title = _("Go back")
    icon = "arrow-left"
    category = _("Navigation")
    default_key = "Alt+ArrowLeft"
    mode = "modifier"
    scope_kind = "global"
    handler_kind = "custom-event"
    handler_params = {"event_name": "cj:nav:back"}
    weight = 30


# Note: domain-specific navigation actions (dashboard, patients list,
# appointments, …) belong in the consuming app's ``shortcuts.py`` —
# Conjunto cannot know what URL names downstream apps mount.


# ─────────────────────────────────────────────────────────────────────
# Always-active utilities (bypass the "no-fire-while-input-focused" rule)
# ─────────────────────────────────────────────────────────────────────


class FormSaveAction(IShortcutAction):
    namespace = "global"
    name = "form.save"
    title = _("Save current form")
    icon = "device-floppy"
    category = _("Forms")
    default_key = "Ctrl+s"
    mode = "modifier"
    scope_kind = "global"
    always_active = True
    handler_kind = "click-selector"
    handler_params = {"selector": "form button[type=submit]:not([disabled])"}
    weight = 5


class GlobalSearchAction(IShortcutAction):
    namespace = "global"
    name = "search"
    title = _("Focus global search")
    icon = "search"
    category = _("Navigation")
    default_key = "/"
    mode = "single"
    scope_kind = "global"
    always_active = True
    handler_kind = "click-selector"
    handler_params = {"selector": "[data-cj-global-search] input, input[type=search]"}
    weight = 6


class CheatsheetAction(IShortcutAction):
    namespace = "help"
    name = "cheatsheet"
    title = _("Show keyboard cheat-sheet")
    icon = "keyboard"
    category = _("Help")
    default_key = "?"
    mode = "single"
    scope_kind = "global"
    always_active = True
    handler_kind = "htmx-get"
    handler_params = {"url_name": "shortcuts:cheatsheet", "target": "#dialog"}
    weight = 1


class CommandPaletteAction(IShortcutAction):
    """Phase 2 — palette modal. Action exists so the key is reserved."""

    namespace = "palette"
    name = "open"
    title = _("Open command palette")
    icon = "command"
    category = _("Help")
    default_key = "Ctrl+k"
    mode = "modifier"
    scope_kind = "global"
    always_active = True
    handler_kind = "custom-event"
    handler_params = {"event_name": "cj:palette:open"}
    weight = 2


# ─────────────────────────────────────────────────────────────────────
# Modal interaction
# ─────────────────────────────────────────────────────────────────────


class ModalCloseAction(IShortcutAction):
    namespace = "modal"
    name = "close"
    title = _("Close current modal")
    icon = "x"
    category = _("Modals")
    default_key = "Escape"
    mode = "modifier"  # always-active equivalent — handled by Bootstrap natively
    scope_kind = "global"
    always_active = True
    handler_kind = "click-selector"
    handler_params = {"selector": "#dialog .btn-close, .modal.show .btn-close"}
    weight = 4
