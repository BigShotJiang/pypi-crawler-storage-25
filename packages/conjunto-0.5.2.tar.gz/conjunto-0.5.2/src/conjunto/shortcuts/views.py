"""Server-side views for the shortcut subsystem.

- :class:`CheatsheetView` — modal showing all currently-active shortcuts,
  triggered by the global ``?`` action.
- :class:`ConflictCheckView` — endpoint queried by the settings UI on each
  keystroke to validate a candidate binding.

Settings UIs (vendor / tenant / user) live in ``conjunto.shortcuts.admin_views``
to keep this module focused on runtime concerns.
"""

from __future__ import annotations

from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import JsonResponse
from django.utils.translation import gettext_lazy as _
from django.views.generic import TemplateView, View

from .registry import ShortcutRegistry, bindings_for_request
from .scopes import normalize_key, overlap


class CheatsheetView(LoginRequiredMixin, TemplateView):
    """Render the cheat-sheet modal body, scoped to currently-active actions."""

    template_name = "conjunto/shortcuts/cheatsheet.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        bindings = bindings_for_request(self.request)
        # Group by category for display.
        by_category: dict[str, list[dict]] = {}
        for b in bindings:
            action_cls = ShortcutRegistry.get(b["id"])
            if action_cls is None:
                continue
            cat = str(action_cls.category or _("Other"))
            by_category.setdefault(cat, []).append(
                {
                    "id": b["id"],
                    "key": b["key"],
                    "title": str(action_cls.title or action_cls.full_id()),
                    "description": str(action_cls.description or ""),
                    "icon": action_cls.icon or "",
                    "scope": b["scope"],
                }
            )
        for entries in by_category.values():
            entries.sort(key=lambda e: (e["title"].casefold(), e["key"]))
        ctx["categories"] = sorted(by_category.items(), key=lambda kv: kv[0].casefold())
        return ctx


class ConflictCheckView(LoginRequiredMixin, View):
    """JSON endpoint: report conflicts for a candidate ``(action, key)``.

    Query params:
        ``action``  — full id of the action being edited
        ``key``     — candidate key string
        ``scope``   — "vendor"|"tenant"|"user" (UI hint, not enforced here)

    Response::

        {
          "status": "ok"|"hard"|"soft"|"reserved"|"unbound",
          "conflicts": [
              {"id": "...", "title": "...", "scope": "..."},
              ...
          ],
          "message": "..."
        }
    """

    def get(self, request, *args, **kwargs):
        action_id = request.GET.get("action", "").strip()
        key = normalize_key(request.GET.get("key", ""))
        if not action_id:
            return JsonResponse(
                {"status": "error", "message": "missing action"}, status=400
            )
        candidate = ShortcutRegistry.get(action_id)
        if candidate is None:
            return JsonResponse(
                {"status": "error", "message": "unknown action"}, status=404
            )
        if not key:
            return JsonResponse(
                {
                    "status": "unbound",
                    "conflicts": [],
                    "message": _("Unbound — no key."),
                }
            )

        from .interfaces import BROWSER_RESERVED_KEYS

        if key in {normalize_key(k) for k in BROWSER_RESERVED_KEYS}:
            return JsonResponse(
                {
                    "status": "reserved",
                    "conflicts": [],
                    "message": _("Browser-reserved key — may not work."),
                }
            )

        hard, soft = [], []
        for other in ShortcutRegistry.all():
            if other.full_id() == action_id:
                continue
            if normalize_key(other.default_key) != key:
                # We're checking against *defaults* — production should also
                # consult the per-tenant ScopedSetting overrides; left as a
                # follow-up once the tenant settings UI lands.
                continue
            collide = overlap(
                candidate.scope_kind,
                candidate.scope_match,
                other.scope_kind,
                other.scope_match,
            )
            entry = {
                "id": other.full_id(),
                "title": str(other.title or other.full_id()),
                "scope": f"{other.scope_kind}/{other.scope_match}",
            }
            (hard if collide else soft).append(entry)

        if hard:
            return JsonResponse(
                {
                    "status": "hard",
                    "conflicts": hard + soft,
                    "message": _(
                        "Hard conflict in the same activation scope — submit blocked."
                    ),
                }
            )
        if soft:
            return JsonResponse(
                {
                    "status": "soft",
                    "conflicts": soft,
                    "message": _(
                        "Also bound in another scope — works but check intent."
                    ),
                }
            )
        return JsonResponse(
            {"status": "ok", "conflicts": [], "message": _("No conflict.")}
        )
