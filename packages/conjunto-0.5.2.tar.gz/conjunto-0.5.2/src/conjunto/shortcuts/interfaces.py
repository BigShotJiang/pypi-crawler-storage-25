"""Plugin interface for keyboard-bindable actions.

Subclass :class:`IShortcutAction` in a plugin's ``shortcuts.py`` module —
GDAPS auto-discovers it via :func:`django.utils.module_loading.autodiscover_modules`
in :meth:`conjunto.shortcuts.apps.ShortcutsConfig.ready`.

Each subclass becomes addressable as ``"<namespace>.<name>"`` and is mapped
to a key via :class:`conjunto.settings.scoped.models.ScopedSetting` in the
``"shortcuts"`` namespace.
"""

from __future__ import annotations

from typing import Any, Optional

from gdaps.api import Interface

from conjunto.settings.scoped.models import Scope


# Default lock model: vendor & tenant decide, lower scopes are forbidden.
_DEFAULT_WRITABLE = (Scope.VENDOR, Scope.TENANT)
_DEFAULT_LOCKABLE = (Scope.VENDOR, Scope.TENANT)


class IShortcutAction(Interface):
    """A keyboard-bindable action.

    Subclass attributes are class-level metadata only — no instance is
    created. Treat the subclass itself as the singleton record.

    Identity & presentation
    -----------------------
    ``namespace`` + ``name``
        Combined into the full id ``"<namespace>.<name>"`` (e.g.
        ``"cashbook.entry.create"``). Must be unique across all actions.
    ``title``, ``description``, ``icon``, ``category``
        Used by tooltips, cheat-sheet, command palette, settings UI.

    Default binding
    ---------------
    ``default_key``
        Normalised key string. Empty = unbound by default. Examples:
        ``"n"``, ``"Ctrl+s"``, ``"Alt+d"``, ``"F2"``. Only single-step
        keys are supported — chord sequences (``"g d"``) were dropped
        2026-05-18; use a modifier combination instead.
    ``mode``
        ``"modifier"`` (always active), ``"single"`` (only when no input
        focused), ``"auto"`` (derived from key shape).

    Activation context
    ------------------
    ``scope_kind``
        ``"global"`` (always active), ``"app"`` (URL-name match),
        ``"view"`` (only when explicitly mounted).
    ``scope_match``
        For ``"app"``/``"view"``: a URL-name glob (e.g. ``"cashbook:*"``)
        or a callable ``(request) -> bool``. ``None`` means: only active
        when explicitly mounted via :class:`{% shortcut_scope %}` tag /
        Alpine ``$store.cjShortcuts.push(...)``.

    Execution
    ---------
    ``handler_kind``
        One of ``"navigate"``, ``"htmx-get"``, ``"htmx-post"``,
        ``"click-selector"``, ``"custom-event"``.
    ``handler_params``
        Dict of kind-specific parameters; see
        :data:`HANDLER_PARAM_KEYS` for the canonical schema.

    Permissions & lock
    ------------------
    ``permission_required``
        Django permission string; checked in :meth:`is_available`.
    ``writable_scopes``
        Storage scopes allowed to override this binding. Defaults to
        ``[VENDOR, TENANT]`` — opting in lower scopes (USER/DEVICE/GROUP)
        triggers system check ``S003`` unless ``description`` is set.
    ``lockable_scopes``
        Subset of ``writable_scopes`` that may set ``locked=True``.
    ``always_active``
        Whitelist flag for help/save/search/palette — bypasses the
        "no fire while input focused" rule for ``"single"``-mode actions.
    """

    __sort_attribute__ = "weight"
    __instantiate_plugins__ = False

    # ── identity ──────────────────────────────────────────────────
    namespace: str = ""
    name: str = ""

    # ── presentation ──────────────────────────────────────────────
    title: str = ""
    description: str = ""
    icon: str = ""
    category: str = ""

    # ── default binding ───────────────────────────────────────────
    default_key: str = ""
    mode: str = "auto"  # "modifier" | "single" | "auto"

    # ── activation context ────────────────────────────────────────
    scope_kind: str = "view"  # "global" | "app" | "view"
    scope_match: Optional[Any] = None

    # ── execution ─────────────────────────────────────────────────
    handler_kind: str = "navigate"
    handler_params: dict = {}

    # ── permissions & lock ────────────────────────────────────────
    permission_required: str = ""
    writable_scopes: tuple = _DEFAULT_WRITABLE
    lockable_scopes: tuple = _DEFAULT_LOCKABLE
    always_active: bool = False
    weight: int = 100

    # ── derived helpers ───────────────────────────────────────────
    @classmethod
    def full_id(cls) -> str:
        """Return ``"<namespace>.<name>"`` — unique across all actions."""
        return f"{cls.namespace}.{cls.name}"

    @classmethod
    def is_available(cls, request) -> bool:
        """Override for runtime gating beyond ``permission_required``.

        Default returns ``True`` when ``permission_required`` is empty
        or the request user has the permission.
        """
        if not cls.permission_required:
            return True
        user = getattr(request, "user", None)
        if user is None or not user.is_authenticated:
            return False
        return user.has_perm(cls.permission_required)

    @classmethod
    def resolved_mode(cls) -> str:
        """Return the effective mode after ``"auto"`` derivation.

        ``"auto"`` → ``"modifier"`` if the default key contains
        ``Ctrl``/``Alt``/``Meta`` (or starts with ``F`` for function keys);
        otherwise ``"single"``.
        """
        if cls.mode != "auto":
            return cls.mode
        key = cls.default_key
        if not key:
            return "single"
        head = key.split("+")[0] if "+" in key else key
        if any(mod in key for mod in ("Ctrl+", "Alt+", "Meta+", "Cmd+")):
            return "modifier"
        if len(head) == 2 and head[0] == "F" and head[1].isdigit():
            return "modifier"
        return "single"


# Canonical handler_params keys per handler_kind. Documented for plugin
# authors and validated by the registry on freeze.
HANDLER_PARAM_KEYS: dict[str, frozenset[str]] = {
    "navigate": frozenset({"url_name", "url_kwargs", "url_kwargs_from"}),
    "htmx-get": frozenset(
        {"url_name", "url_kwargs", "url_kwargs_from", "target", "swap"}
    ),
    "htmx-post": frozenset(
        {"url_name", "url_kwargs", "url_kwargs_from", "target", "swap"}
    ),
    "click-selector": frozenset({"selector"}),
    "custom-event": frozenset({"event_name", "event_detail"}),
}


# Browser-reserved keys that may not be interceptable across all browsers.
# Used by system check S004 to warn — not to forbid.
BROWSER_RESERVED_KEYS: frozenset[str] = frozenset(
    {
        "Ctrl+w",
        "Ctrl+t",
        "Ctrl+n",
        "Ctrl+l",
        "Ctrl+r",
        "Ctrl+Shift+t",
        "Ctrl+Shift+n",
        "Ctrl+Shift+w",
        "F5",
        "F11",
    }
)
