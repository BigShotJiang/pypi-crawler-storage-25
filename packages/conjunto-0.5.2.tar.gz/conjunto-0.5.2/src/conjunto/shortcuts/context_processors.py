"""Standalone context processor for shortcut bindings.

**Most projects do NOT need this** — the canonical
``conjunto.context_processors.globals`` already injects
``cj_layout.shortcuts.bindings`` when ``conjunto.shortcuts`` is in
``INSTALLED_APPS``.

This module is kept for projects that don't use ``globals`` and need to
wire shortcuts independently. Add it to
``TEMPLATES[*].OPTIONS.context_processors`` *after* whatever processor
populates ``cj_layout``::

    "conjunto.shortcuts.context_processors.cj_layout_shortcuts",
"""

from __future__ import annotations

from .registry import bindings_for_request


def cj_layout_shortcuts(request) -> dict:
    """Add ``cj_layout.shortcuts`` ({"bindings": [...], "enabled": bool}).

    Returns an empty dict so it can be added to the processor list without
    side effects on the global namespace.
    """
    cj_layout = getattr(request, "_cj_layout_cache", None)
    if cj_layout is None:
        # cj_layout context processor hasn't run yet (or isn't installed).
        # Build a minimal dict; the resolver tolerates absence.
        cj_layout = {}
        request._cj_layout_cache = cj_layout

    # Skip on HTMX partial swaps — the binding list ships with the full
    # page render, partials inherit from the existing window.cjShortcuts.
    htmx = bool(getattr(request, "htmx", False))
    if htmx:
        cj_layout.setdefault("shortcuts", {"bindings": [], "enabled": True})
    else:
        cj_layout["shortcuts"] = {
            "bindings": bindings_for_request(request),
            "enabled": True,
        }
    return {"cj_layout": cj_layout}
