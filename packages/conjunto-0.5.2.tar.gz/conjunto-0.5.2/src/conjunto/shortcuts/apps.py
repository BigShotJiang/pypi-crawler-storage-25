"""AppConfig for the conjunto.shortcuts subsystem.

Discovery-only here — the registry freeze and system-check registration both
hook off ``apps.ready()``. We deliberately avoid Django signals: every step
is explicit and traceable.
"""

from django.apps import AppConfig
from django.utils.module_loading import autodiscover_modules
from django.utils.translation import gettext_lazy as _


class ShortcutsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "conjunto.shortcuts"
    label = "conjunto_shortcuts"
    verbose_name = _("Keyboard shortcuts")

    def ready(self):
        # Importing interfaces & built-in actions makes GDAPS register them.
        from . import interfaces  # noqa: F401
        from . import shortcuts as _builtin_shortcuts  # noqa: F401
        from . import checks  # noqa: F401
        from . import menus  # noqa: F401  — registers the settings section

        # Auto-discover ``shortcuts.py`` in every installed app so consumer
        # ``IShortcutAction`` subclasses get registered. Mirrors Django's
        # admin / scoped_settings autodiscovery.
        autodiscover_modules("shortcuts")

        # Freeze the registry so further subclasses raise loudly.
        from .registry import ShortcutRegistry

        ShortcutRegistry.freeze()

        # Now that every action is known, register one ScopedSetting spec
        # per action so the storage layer accepts writes.
        from .scoped_settings import register_all_shortcut_specs

        register_all_shortcut_specs()
