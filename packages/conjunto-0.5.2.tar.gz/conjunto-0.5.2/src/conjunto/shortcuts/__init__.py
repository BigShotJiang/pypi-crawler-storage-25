"""Plugin-extensible keyboard shortcut system.

This package provides four moving parts that work together:

1. :class:`~conjunto.shortcuts.interfaces.IShortcutAction` — GDAPS interface;
   plugin authors subclass to register a keyboard-bindable action.
2. :class:`~conjunto.shortcuts.registry.ShortcutRegistry` — collects every
   ``IShortcutAction`` subclass at startup, indexes them by full id, exposes
   lookups for the resolver and the settings UI.
3. ``conjunto/static/conjunto/js/shortcuts.js`` — single AlpineJS store +
   single global ``keydown`` listener; resolves each press against the
   activation-scope stack.
4. Three settings UIs (vendor / tenant / user) on top of conjunto's existing
   ``ScopedSetting`` infrastructure with ``namespace="shortcuts"``.

See ``docs/superpowers/specs/2026-05-03-keyboard-shortcuts-design.md`` for
the full design rationale and the rollout phases.
"""

default_app_config = "conjunto.shortcuts.apps.ShortcutsConfig"
