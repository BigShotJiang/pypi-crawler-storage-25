"""URL routes for the shortcut subsystem.

Mount in the project's root urlconf::

    path("shortcuts/", include("conjunto.shortcuts.urls", namespace="shortcuts")),
"""

from django.urls import path

from .admin_views import TenantShortcutsAdminView, VendorShortcutsAdminView
from .views import CheatsheetView, ConflictCheckView

app_name = "shortcuts"

urlpatterns = [
    path("cheatsheet/", CheatsheetView.as_view(), name="cheatsheet"),
    path("check-conflict/", ConflictCheckView.as_view(), name="check-conflict"),
    path("admin/vendor/", VendorShortcutsAdminView.as_view(), name="admin-vendor"),
    path("admin/tenant/", TenantShortcutsAdminView.as_view(), name="admin-tenant"),
]
