"""Django system checks for the shortcut subsystem.

Run via ``python manage.py check`` (or ``--tag shortcuts``). The checks
are advisory at startup — they iterate the frozen
:class:`~conjunto.shortcuts.registry.ShortcutRegistry` and surface conflicts
and policy violations.

Severity matrix:

- ``S002`` ERROR — same default key, scopes *do* overlap (build breaker)
- ``S003`` WARNING — action exposes USER scope without ``description``
- ``S004`` WARNING — default key is a browser-reserved combination
- ``S005`` WARNING — duplicate full id between two registered subclasses

Note: there is no S001 anymore. Same default key in non-overlapping
scopes is the common idiomatic case (e.g. ``n`` = "new" in every app)
and emits nothing. Only real conflicts (S002) get reported.
"""

from __future__ import annotations

from django.core.checks import Error, Tags, Warning, register

from conjunto.settings.scoped.models import Scope

from .interfaces import BROWSER_RESERVED_KEYS
from .registry import ShortcutRegistry
from .scopes import normalize_key, overlap

CHECK_TAG = "shortcuts"


@register(Tags.compatibility, deploy=False)
def check_shortcut_conflicts(app_configs, **kwargs):
    """Emit S002 for overlapping default-key collisions across actions.

    Reported pairwise so the user sees every offending combination.
    Non-overlapping scopes (idiomatic case: ``n`` = "new" in every
    app) emit nothing — no news is good news.
    """
    issues = []
    by_key: dict[str, list] = {}
    for a in ShortcutRegistry.all():
        if not a.default_key:
            continue
        by_key.setdefault(normalize_key(a.default_key), []).append(a)

    for key, actions in by_key.items():
        if len(actions) < 2:
            continue
        for i, a in enumerate(actions):
            for b in actions[i + 1 :]:
                if not overlap(
                    a.scope_kind, a.scope_match, b.scope_kind, b.scope_match
                ):
                    continue
                issues.append(
                    Error(
                        f"Shortcut conflict: '{key}' is default-bound to both "
                        f"'{a.full_id()}' (scope {a.scope_kind}/{a.scope_match}) "
                        f"and '{b.full_id()}' (scope "
                        f"{b.scope_kind}/{b.scope_match}).",
                        id="conjunto.S002",
                        obj=a.full_id(),
                    )
                )
    return issues


@register(Tags.compatibility, deploy=False)
def check_user_scope_justification(app_configs, **kwargs):
    """Emit S003 when an action allows USER without describing why."""
    issues = []
    for a in ShortcutRegistry.all():
        writable = set(a.writable_scopes or ())
        if Scope.USER in writable and not str(a.description or "").strip():
            issues.append(
                Warning(
                    f"Action '{a.full_id()}' allows Scope.USER in writable_scopes "
                    "but has no `description=` justifying the user-overridable "
                    "default. Document why this is a personal-preference action.",
                    hint=(
                        "Either set a `description=_('…')` explaining the opt-in, "
                        "or restrict writable_scopes to [Scope.VENDOR, Scope.TENANT]."
                    ),
                    id="conjunto.S003",
                    obj=a.full_id(),
                )
            )
    return issues


@register(Tags.compatibility, deploy=False)
def check_browser_reserved_keys(app_configs, **kwargs):
    """Emit S004 when an action's default key collides with browser bindings."""
    issues = []
    for a in ShortcutRegistry.all():
        if not a.default_key:
            continue
        if normalize_key(a.default_key) in {
            normalize_key(k) for k in BROWSER_RESERVED_KEYS
        }:
            issues.append(
                Warning(
                    f"Action '{a.full_id()}' uses browser-reserved key "
                    f"'{a.default_key}' — may not work reliably across browsers.",
                    hint=(
                        "Choose a non-conflicting modifier combination, or accept "
                        "that some browsers will swallow the keystroke."
                    ),
                    id="conjunto.S004",
                    obj=a.full_id(),
                )
            )
    return issues
