"""Template tags for the shortcut subsystem.

- ``{% shortcut_button "<full.id>" class="…" label="…" icon="…" %}``
- ``{% shortcut_kbd "<full.id>" %}``  — inline ``<kbd>`` badge
- ``{% shortcut_scope "<scope-id>" %}…{% endshortcut_scope %}`` — explicit
  view-scope mount (auto-pushes/pops on the AlpineJS store)

All three render server-side using the same registry lookup. Empty effective
key → button still works (just no shortcut hint), kbd → empty string,
scope wrapper → still emits the wrapper so a plugin author can rely on it.
"""

from __future__ import annotations

from django import template
from django.urls import NoReverseMatch, reverse
from django.utils.html import format_html
from django.utils.safestring import mark_safe
from django.utils.translation import gettext as _

from ..registry import ShortcutRegistry, effective_key_for

register = template.Library()


@register.filter(name="dictlookup")
def dictlookup(d, key):
    """Look up ``key`` in dict ``d``. Returns ``""`` on miss.

    Used by the admin template to fetch per-action error/draft strings
    keyed by full id.
    """
    if not isinstance(d, dict):
        return ""
    return d.get(key, "")


@register.simple_tag(takes_context=True)
def shortcut_button(context, action_id: str, **opts):
    """Render a button bound to the action ``action_id``.

    Accepted ``**opts``:

    - ``class`` / ``class_`` — CSS classes for the button. ``class`` is
      preferred in templates (matches HTML), ``class_`` is the Python
      escape hatch.
    - ``label`` — override the button text (defaults to action title).
    - ``icon`` — Tabler icon name without the ``ti-`` prefix.
    - ``extra`` — extra raw HTML attributes to inject (use sparingly).

    Wires the matching ``hx-*``/`href`/`onclick` attributes based on the
    action's ``handler_kind``. Renders a tooltip + ``<kbd>`` hint with the
    user's currently-effective key.
    """
    label = str(opts.pop("label", ""))
    icon = str(opts.pop("icon", ""))
    class_ = str(opts.pop("class", opts.pop("class_", "btn btn-sm btn-primary")))
    extra = str(opts.pop("extra", ""))
    if opts:
        # Surface unknown kwargs immediately rather than silently ignoring
        raise TypeError(
            f"shortcut_button: unknown keyword argument(s) {sorted(opts)!r}"
        )

    request = context.get("request")
    action_cls = ShortcutRegistry.get(action_id)
    if action_cls is None:
        return mark_safe(
            f'<button class="{class_}" disabled title="{_("Unknown shortcut action")} '
            f'({action_id})">?</button>'
        )

    key = effective_key_for(request, action_cls) if request else action_cls.default_key
    label_text = str(label or action_cls.title or action_id)
    icon_name = icon or action_cls.icon
    icon_html = (
        format_html('<i class="ti ti-{} fs-2 me-1"></i>', icon_name)
        if icon_name
        else ""
    )
    title_attr = f"{label_text} ({key})" if key else label_text
    aria_attr = f' aria-keyshortcuts="{key}"' if key else ""
    kbd_html = (
        format_html(
            '<kbd class="ms-2 d-none d-md-inline opacity-50">{}</kbd>',
            key,
        )
        if key
        else ""
    )

    handler_attrs = _handler_attrs(action_cls)
    return format_html(
        '<button type="button" class="{}" data-action="{}" title="{}"{}{} {}>{}{}{}</button>',
        class_,
        action_id,
        title_attr,
        mark_safe(aria_attr),
        mark_safe(extra and f" {extra}"),
        mark_safe(handler_attrs),
        icon_html,
        label_text,
        kbd_html,
    )


def _handler_attrs(action_cls) -> str:
    kind = action_cls.handler_kind
    params = action_cls.handler_params or {}
    if kind in {"htmx-get", "htmx-post"}:
        try:
            url = reverse(params["url_name"], kwargs=params.get("url_kwargs", {}) or {})
        except (NoReverseMatch, KeyError):
            return ""
        verb = "hx-get" if kind == "htmx-get" else "hx-post"
        target = params.get("target", "#dialog")
        swap = params.get("swap", "innerHTML")
        return f'{verb}="{url}" hx-target="{target}" hx-swap="{swap}"'
    if kind == "navigate":
        try:
            url = reverse(params["url_name"], kwargs=params.get("url_kwargs", {}) or {})
        except (NoReverseMatch, KeyError):
            return ""
        return f"onclick=\"window.location.assign('{url}')\""
    return ""


@register.simple_tag(takes_context=True)
def shortcut_kbd(context, action_id: str):
    """Render the ``<kbd>`` hint badge for ``action_id``.

    Empty result if no key is effective — plugin templates can use this in
    custom button markup without conditional logic.
    """
    request = context.get("request")
    action_cls = ShortcutRegistry.get(action_id)
    if action_cls is None:
        return ""
    key = effective_key_for(request, action_cls) if request else action_cls.default_key
    if not key:
        return ""
    return format_html('<kbd class="ms-2 opacity-50">{}</kbd>', key)


@register.tag(name="shortcut_scope")
def do_shortcut_scope(parser, token):
    """``{% shortcut_scope "view:foo" %} … {% endshortcut_scope %}``."""
    try:
        _, scope = token.split_contents()
    except ValueError:
        raise template.TemplateSyntaxError(
            "shortcut_scope requires a single quoted scope id"
        )
    nodelist = parser.parse(("endshortcut_scope",))
    parser.delete_first_token()
    return _ScopeNode(scope.strip("\"'"), nodelist)


class _ScopeNode(template.Node):
    def __init__(self, scope: str, nodelist):
        self.scope = scope
        self.nodelist = nodelist

    def render(self, context):
        body = self.nodelist.render(context)
        return format_html(
            '<div data-shortcut-scope="{}" x-data x-init="$store.cjShortcuts && '
            "$store.cjShortcuts.push('{}')\">{}</div>",
            self.scope,
            self.scope,
            mark_safe(body),
        )
