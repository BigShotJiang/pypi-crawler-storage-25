"""Auto-register every :class:`IShortcutAction` as a scoped-setting spec.

The shortcut value is stored under ``namespace="shortcuts"``,
``key="<action.namespace>.<action.name>"``. This module is auto-imported by
``conjunto.settings.apps.SettingsConfig.ready`` (which runs before our
own ``apps.ready`` because it sits earlier in ``INSTALLED_APPS``), so we
defer the actual sweep to a function called from
:meth:`conjunto.shortcuts.apps.ShortcutsConfig.ready` instead.

Why split this out: ``SettingRegistry`` freezes on first read; we must
register *all* shortcut keys before anyone calls ``request.scoped_settings``
for the first time. Doing it in ``ShortcutsConfig.ready`` after the
autodiscover sweep is the only safe order.
"""

from __future__ import annotations

from conjunto.settings.scoped.registry import SettingRegistry

from .registry import ShortcutRegistry


def register_all_shortcut_specs() -> None:
    """Register one ``SettingSpec`` per discovered :class:`IShortcutAction`.

    Idempotent — re-registration of the same spec is a no-op (the
    registry tolerates exact-duplicate registrations).
    """
    for action_cls in ShortcutRegistry.all():
        try:
            SettingRegistry.register(
                "shortcuts",
                action_cls.full_id(),
                type="str",
                default=action_cls.default_key or "",
                help_text=str(action_cls.title or action_cls.description or ""),
                icon=action_cls.icon or "keyboard",
                writable_scopes=list(action_cls.writable_scopes or ()),
                lockable_scopes=list(action_cls.lockable_scopes or ()),
            )
        except Exception:
            # The registry raises RuntimeError after freeze; if a test
            # has already exercised the registry we just continue.
            pass
