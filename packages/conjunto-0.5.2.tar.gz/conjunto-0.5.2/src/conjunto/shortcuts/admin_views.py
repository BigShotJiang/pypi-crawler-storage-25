"""Vendor / Tenant administration views for keyboard-shortcut bindings.

Two URLs, same view class with different ``scope`` configuration:

- ``shortcuts:admin-vendor`` — superuser only, edits the VENDOR row.
- ``shortcuts:admin-tenant`` — tenant_admin only, edits the TENANT row;
  Vendor-locked actions appear disabled.

The user-facing read-only cheat-sheet lives in ``views.CheatsheetView``
and is reachable via the global ``?`` shortcut.

Save flow is bulk: one HTMX POST submits every changed input. The
backend per-action validates against ``ConflictCheckView`` semantics and
returns the form re-rendered with inline errors when something doesn't
fit, or a 204 + ``HX-Trigger: showToast`` on success.
"""

from __future__ import annotations

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.http import HttpResponse
from django.utils.translation import gettext_lazy as _
from django.views.generic import TemplateView

from conjunto.settings.scoped.models import Scope, ScopedSetting
from conjunto.settings.scoped.scopes import ITenantScope

from .registry import ShortcutRegistry, effective_key_for
from .scopes import normalize_key, overlap


class _AdminShortcutsView(LoginRequiredMixin, UserPassesTestMixin, TemplateView):
    """Shared scaffolding for vendor / tenant settings pages."""

    template_name = "conjunto/shortcuts/admin.html"
    scope: Scope = Scope.TENANT  # overridden per subclass
    audience: str = "tenant"  # template hint

    def test_func(self):
        # Subclasses override.
        return False

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["audience"] = self.audience
        ctx["scope_label"] = self.scope.name
        ctx["rows"] = self._build_rows()
        return ctx

    def _build_rows(self) -> list[dict]:
        request = self.request
        own_rows = self._scope_rows()
        rows: list[dict] = []
        for action in sorted(
            ShortcutRegistry.all(),
            key=lambda a: (str(a.category), a.weight, a.full_id()),
        ):
            full_id = action.full_id()
            own = own_rows.get(full_id)
            vendor_locked = self._vendor_locked(full_id)
            rows.append(
                {
                    "id": full_id,
                    "title": str(action.title or full_id),
                    "category": str(action.category or _("Other")),
                    "icon": action.icon,
                    "scope_kind": action.scope_kind,
                    "scope_match": action.scope_match,
                    "default_key": action.default_key,
                    "effective_key": effective_key_for(request, action),
                    "own_value": own.value if own else "",
                    "own_locked": bool(own and own.locked),
                    "vendor_locked": vendor_locked,
                    "lockable": Scope(self.scope) in (action.lockable_scopes or ()),
                    "writable": Scope(self.scope) in (action.writable_scopes or ()),
                }
            )
        return rows

    def _scope_filters(self) -> dict:
        """Return ORM filter kwargs identifying the current scope row."""
        if self.scope == Scope.VENDOR:
            return {"scope": Scope.VENDOR}
        if self.scope == Scope.TENANT:
            tenants = ITenantScope.resolve(self.request)
            tenant_id = tenants[0] if tenants else None
            return {"scope": Scope.TENANT, "tenant_id": tenant_id}
        raise ValueError(f"Unsupported admin scope {self.scope!r}")

    def _scope_rows(self) -> dict[str, ScopedSetting]:
        """Existing ScopedSetting rows for this scope, keyed by action id."""
        qs = ScopedSetting.objects.filter(
            namespace="shortcuts", **self._scope_filters()
        )
        return {row.key: row for row in qs}

    def _vendor_locked(self, action_id: str) -> bool:
        if self.scope == Scope.VENDOR:
            return False
        return ScopedSetting.objects.filter(
            namespace="shortcuts",
            key=action_id,
            scope=Scope.VENDOR,
            locked=True,
        ).exists()

    # ── POST: bulk save ────────────────────────────────────────────
    def post(self, request, *args, **kwargs):
        rows = self._build_rows()
        actions_by_id = {r["id"]: r for r in rows}
        errors: dict[str, str] = {}
        ops: list[tuple[str, str, bool]] = []

        for action_id, row in actions_by_id.items():
            if not row["writable"] or row["vendor_locked"]:
                continue
            field = f"key__{action_id}"
            new_val = normalize_key(request.POST.get(field, "").strip())
            new_lock = (
                request.POST.get(f"lock__{action_id}") == "on" and row["lockable"]
            )
            ops.append((action_id, new_val, new_lock))

        # Inline conflict check — same scope = hard conflict.
        for action_id, val, _lock in ops:
            if not val:
                continue
            action = ShortcutRegistry.get(action_id)
            for other_id, other_val, _ol in ops:
                if other_id == action_id or other_val != val:
                    continue
                other = ShortcutRegistry.get(other_id)
                if overlap(
                    action.scope_kind,
                    action.scope_match,
                    other.scope_kind,
                    other.scope_match,
                ):
                    errors[action_id] = _(
                        "Conflict with '%(other)s' in the same activation scope."
                    ) % {"other": other.full_id()}

        if errors:
            ctx = self.get_context_data(**kwargs)
            ctx["errors"] = errors
            ctx["draft"] = {a: v for a, v, _l in ops}
            return self.render_to_response(ctx)

        # Persist.
        scope_filters = self._scope_filters()
        for action_id, val, lock in ops:
            existing = ScopedSetting.objects.filter(
                namespace="shortcuts", key=action_id, **scope_filters
            ).first()
            if not val:
                if existing:
                    existing.delete()
                continue
            if existing is None:
                ScopedSetting.objects.create(
                    namespace="shortcuts",
                    key=action_id,
                    value=val,
                    locked=lock,
                    **scope_filters,
                )
            elif existing.value != val or existing.locked != lock:
                existing.value = val
                existing.locked = lock
                existing.save(update_fields=["value", "locked"])

        # Invalidate the per-request scoped-settings cache so the page
        # re-renders with the new effective keys.
        scoped = getattr(request, "scoped_settings", None)
        if scoped is not None:
            for action_id, _v, _l in ops:
                try:
                    scoped.invalidate("shortcuts", action_id)
                except Exception:
                    pass

        messages.success(request, _("Keyboard shortcuts saved."))
        resp = HttpResponse(status=204)
        resp["HX-Trigger"] = "showToast"
        return resp


class VendorShortcutsAdminView(_AdminShortcutsView):
    scope = Scope.VENDOR
    audience = "vendor"

    def test_func(self):
        return self.request.user.is_superuser


class TenantShortcutsAdminView(_AdminShortcutsView):
    scope = Scope.TENANT
    audience = "tenant"

    def test_func(self):
        # Reuse conjunto's tenant_admin contract — the conjunto.tenants
        # app exposes a helper, but we keep this dependency-free here:
        # superuser OR change_scopedsetting permission.
        u = self.request.user
        return bool(
            u.is_superuser or u.has_perm("conjunto_settings.change_scopedsetting")
        )
