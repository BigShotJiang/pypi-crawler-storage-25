"""Idempotent seed of vendor-default shortcut bindings.

Walks the frozen :class:`~conjunto.shortcuts.registry.ShortcutRegistry`,
creating one ``ScopedSetting`` row per action with ``default_key`` set,
scoped to ``Scope.VENDOR``. Existing rows are left untouched — vendor
admins keep manual overrides across plugin upgrades.

Run automatically from ``MeduxPluginAppConfig.install()``; safe to invoke
manually with ``python manage.py seed_shortcuts``.
"""

from __future__ import annotations

from django.core.management.base import BaseCommand

from conjunto.settings.scoped.models import Scope, ScopedSetting

from ...registry import ShortcutRegistry


class Command(BaseCommand):
    help = "Seed vendor-default keyboard shortcut bindings (idempotent)."

    def add_arguments(self, parser):
        parser.add_argument(
            "--force",
            action="store_true",
            help=(
                "Overwrite existing vendor rows with the current plugin "
                "default. Without --force, manually-edited vendor values "
                "are preserved."
            ),
        )

    def handle(self, *args, **opts):
        force = bool(opts.get("force"))
        created = updated = skipped = 0

        for action_cls in ShortcutRegistry.all():
            if not action_cls.default_key:
                continue
            full_id = action_cls.full_id()
            existing = ScopedSetting.objects.filter(
                namespace="shortcuts",
                key=full_id,
                scope=Scope.VENDOR,
            ).first()
            if existing is None:
                ScopedSetting.objects.create(
                    namespace="shortcuts",
                    key=full_id,
                    scope=Scope.VENDOR,
                    value=action_cls.default_key,
                    locked=False,
                )
                created += 1
            elif force and existing.value != action_cls.default_key:
                existing.value = action_cls.default_key
                existing.save(update_fields=["value"])
                updated += 1
            else:
                skipped += 1

        self.stdout.write(
            self.style.SUCCESS(
                f"seed_shortcuts: created={created}, updated={updated}, "
                f"skipped={skipped}"
            )
        )
