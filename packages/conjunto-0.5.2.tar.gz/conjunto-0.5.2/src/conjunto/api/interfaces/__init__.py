from django.utils.translation import gettext_lazy as _
from gdaps import hooks
from gdaps.api import Interface
from gdaps.api.interfaces import ITemplatePlugin

from conjunto.audit_log.registry import LogActionRegistry
from conjunto.api.interfaces.websockets import IWebsocketURL  # noqa: F401

hooks.define("register_log_actions", (LogActionRegistry,))


class IElementGroup(Interface):
    """A group of pluggable elements.

    Implementations of this interface should provide a name, title, and weight
    of the group. You can use this group then in IElements to separate concerns.
    """

    name: str = ""
    title: str = ""
    weight: int = 0


class GeneralGroup(IElementGroup):
    """A default group for all elements without a specified group."""

    name = "general"
    title = _("General settings")


class IElement(Interface):
    """A metadata interface for pluggable, listable elements.

    IElement provides plugin discovery (via GDAPS ``enabled_plugins()``) and
    standardized metadata (``name``, ``title``, ``icon``, ``weight``, ``group``)
    plus the :meth:`enabled` hook for conditional activation.

    **Rendering is NOT the interface's responsibility.** A consuming view —
    see :class:`conjunto.settings.views.SettingsView` for the canonical
    example — iterates ``enabled_plugins()`` and assembles the UI, typically
    with Django 6's ``partials`` feature. This keeps plugin registration and
    presentation decoupled: one view can render many plugin instances as a
    list, grid, tab set, or anything else.

    **Optional HTMX lazy-load convention.** Subinterfaces or concrete plugins
    may declare an ``hx_url`` classmethod/property returning a URL. Consuming
    templates can then emit an ``hx-get`` stub
    (``<div hx-get="..." hx-trigger="load">``) to load the element lazily.
    This is a convention, not a contract — ``ISettingsSection`` /
    ``ISettingsForm`` do not use it because ``SettingsView`` renders
    them directly.

    Example:
        See ``conjunto/settings/interfaces.py`` for ``ISettingsSection``
        and ``ISettingsForm``, which are the idiomatic IElement subclasses:
        pure metadata, rendered by a dedicated view.
    """

    __abstract__ = True
    __instantiate_plugins__ = False

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # If this is a plugin (not the interface itself), require a name.
        if hasattr(self, "_interface") and not getattr(self, "name", None):
            raise AttributeError(
                f"{self.__class__.__name__} must have a 'name' attribute."
            )

    name: str
    """The unique identifier of the element. Used in URLs and HTML attributes."""

    title: str = ""
    """The human-readable title. How it is displayed is up to the consuming view."""

    icon: str = ""
    """Optional icon name, used when the element is listed with icons."""

    weight: int = 0
    """Sort weight — higher values sink the element further down the list."""

    group: type[IElementGroup] = GeneralGroup
    """The group this element belongs to. Can be used to render group headers."""

    @classmethod
    def enabled(cls) -> bool:
        """Hook for implementations to define if the element is enabled.

        Returns:
            True if the element is enabled (default), False if not.
        """
        return True


class IWidgetArea(Interface):
    """A named area that can host draggable widget cards.

    Plugins implement this to define widget areas (e.g. a dashboard,
    a patient detail sidebar). The area uses a CSS Grid with a
    configurable number of columns (default 6). Each widget can span
    a variable number of columns, and users can resize widgets via
    drag handles.

    Widgets register themselves to an area via :attr:`IWidget.area`.
    """

    __sort_attribute__ = "weight"
    __instantiate_plugins__ = False

    name: str
    title: str = ""
    icon: str = "layout-dashboard"
    weight: int = 100
    columns: int = 6

    @classmethod
    def get_widgets(cls, request) -> list:
        """Return all permitted IWidget implementations for this area."""
        return [
            w
            for w in IWidget.enabled_plugins()
            if w.area is cls and w.has_permission(request)
        ]


class IWidget(Interface):
    """A widget rendered as a Tabler card, loaded via HTMX.

    Plugins implement this interface to contribute widgets to a
    :class:`IWidgetArea`. Each widget is lazy-loaded via HTMX into
    its card shell. Users can reorder and resize widgets when the
    area is unlocked. The ``col_span`` attribute controls how many
    grid columns the widget occupies by default.
    """

    __sort_attribute__ = "weight"
    __instantiate_plugins__ = False

    name: str
    title: str = ""
    icon: str = "widget"
    weight: int = 100
    area: type[IWidgetArea] = None
    permission_required: str | None = None
    template: str = ""

    col_span: int = 2
    """Default width in grid columns (1–6)."""

    min_col_span: int = 1
    """Minimum width the user can resize this widget to."""

    max_col_span: int = 6
    """Maximum width the user can resize this widget to."""

    resizable: bool = True
    """Whether the user can resize this widget."""

    removable: bool = False
    """Whether the user can remove this widget from the area."""

    @classmethod
    def has_permission(cls, request) -> bool:
        """Whether the current user may see this widget."""
        if not request.user.is_authenticated:
            return False
        if cls.permission_required:
            return request.user.has_perm(cls.permission_required)
        return True

    @classmethod
    def get_context_data(cls, request) -> dict:
        """Return extra template context for this widget's content."""
        return {}


class IRightSidebar(ITemplatePlugin):
    """A content block rendered into the right sidebar.

    Plugins implement this to contribute content (widget stacks, tool
    panels, contextual info) to the right sidebar. Multiple
    implementations stack vertically, ordered by :attr:`weight` (lower
    first). Each block renders its own :attr:`template_name` with the
    context contributed by :meth:`get_plugin_context`.

    Unlike the left sidebar — which is fed via the
    ``sidebar_left_content`` template block (typically overridden by
    the consuming app) — the right sidebar is plugin-driven by default
    via ``{% render_plugins "IRightSidebar" %}``. Apps that need full
    control can still override the ``sidebar_right_content`` block.

    Visibility can be gated by overriding :meth:`get_plugin_context`
    and returning an unchanged context whose template short-circuits,
    or by returning a context with a flag the template reads. There
    is no separate ``is_available`` hook because ``render_plugins``
    already iterates every enabled implementation — keep gating
    inside the plugin's own template.
    """

    __sort_attribute__ = "weight"

    name: str
    weight: int = 100


class ILoginMethod(Interface):
    """Alternative login method rendered on the login page."""

    __sort_attribute__ = "weight"
    __instantiate_plugins__ = False

    name: str
    label: str = ""
    icon: str = ""
    url: str = ""
    weight: int = 100
    template_name: str = ""

    @classmethod
    def is_enabled(cls, request) -> bool:
        """Return True if this method should be shown for the given request."""
        return True

    @classmethod
    def render(cls, request) -> str:
        """Return custom HTML for the button, or an empty string for the default."""
        if cls.template_name:
            from django.template.loader import render_to_string

            return render_to_string(
                cls.template_name, {"method": cls, "request": request}
            )
        return ""


class ILoginViewExtension(Interface):
    """Hook for extending :class:`conjunto.auth.views.ConjuntoLoginView`.

    Plugins implementing this interface can hook into the login view
    lifecycle:

    - :meth:`alter_context_data` — contribute extra context data to the
      login template.
    - :meth:`form_valid` — react to a successful login, e.g. record a
      timetracker check-in or write a custom audit-log entry. Called
      *after* :func:`django.contrib.auth.login` has bound the user to
      the session, so ``request.user`` is authenticated. For the
      two-step tenant-pick flow, the hook fires once the user has
      finished the second step (i.e. in
      :class:`conjunto.auth.views.ConjuntoLoginCompleteView`), not on
      the deferred credentials POST.
    """

    __instantiate_plugins__ = False

    @classmethod
    def alter_context_data(cls, view, context: dict) -> None:
        """Contribute extra entries to the login template context."""

    @classmethod
    def form_valid(cls, view, request, user, form) -> None:
        """React to a successful login. ``user`` is already authenticated."""


class IPostLoginAction(ITemplatePlugin):
    """A renderable hook fired on every authenticated page load.

    Plugins implement this to inject HTML — typically a one-shot HTMX
    trigger that opens a modal — that follows the user *after* a
    successful login. Examples: a "do you want to check in?" prompt
    from a time-tracking plugin, a "review pending consents" banner
    from a compliance plugin, a "your password expires in 3 days"
    nag from an auth-policy plugin.

    Usage in a base template (only authenticated users):

    .. code-block:: django

        {% load gdaps %}
        {% if request.user.is_authenticated %}
            {% render_plugins "IPostLoginAction" %}
        {% endif %}

    Each implementation must set :attr:`template_name`. Implementations
    are responsible for being *cheap* on every request and for gating
    their own visibility — typically by reading (and consuming) a
    session flag in :meth:`get_plugin_context`.

    .. important::

       :meth:`get_plugin_context` **must mutate the incoming**
       :class:`~django.template.Context` **and return it** — never
       return a plain ``dict``. GDAPS' ``render_plugins`` tag passes
       the result to the low-level
       :meth:`django.template.base.Template.render`, which accesses
       ``context.render_context`` and other internals. A ``dict``
       raises ``AttributeError: 'dict' object has no attribute
       'render_context'``. (High-level helpers like
       :func:`~django.shortcuts.render` accept dicts, but this code
       path does not.) Idiomatic implementation::

           @classmethod
           def get_plugin_context(cls, context):
               context["my_var"] = ...
               return context
    """
