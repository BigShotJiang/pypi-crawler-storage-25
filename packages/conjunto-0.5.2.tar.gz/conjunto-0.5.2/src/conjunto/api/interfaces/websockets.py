"""WebSocket-related GDAPS interfaces.

Plugins contribute Channels routes via :class:`IWebsocketURL`. The
aggregated patterns are exposed by :mod:`conjunto.routing` so consumer
projects can wire them into a single ASGI application without
re-implementing the routing layer per project.
"""

from django.urls import URLPattern

from gdaps.api import Interface


class IWebsocketURL(Interface):
    """URL patterns for websockets, contributed by plugins.

    Each implementation declares one or more ``urlpatterns`` that get
    concatenated into the project's websocket URL router. Example::

        from django.urls import path
        from conjunto.api.interfaces import IWebsocketURL
        from myapp.consumers import MyConsumer

        class MyAppWebsocketURL(IWebsocketURL):
            urlpatterns = [
                path("ws/myapp/", MyConsumer.as_asgi()),
            ]

    Conjunto's :func:`conjunto.routing.asgi_application` collects every
    enabled implementation and builds the final
    :class:`channels.routing.URLRouter`.
    """

    urlpatterns: list[URLPattern] = []
