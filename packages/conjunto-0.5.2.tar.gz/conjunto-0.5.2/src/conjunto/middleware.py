import threading
import zoneinfo
from datetime import timedelta

from django.contrib import messages
from django.http import HttpResponse
from django.shortcuts import reverse, redirect
from django.conf import settings
from django.urls import NoReverseMatch
from django.utils import timezone
from django_htmx.http import trigger_client_event

from conjunto.menu import Menus

_thread_locals = threading.local()

# Long-lived device cookie: 10 years.
DEVICE_COOKIE_NAME = "cj_device_id"
DEVICE_COOKIE_MAX_AGE = 10 * 365 * 24 * 60 * 60
# Debounce Device.last_seen writes to at most once per 5 minutes.
DEVICE_LAST_SEEN_DEBOUNCE = timedelta(minutes=5)


def get_current_request():
    """Return the current request object for this thread, or None."""
    return getattr(_thread_locals, "request", None)


class ConjuntoMiddleware:
    """Main conjunto middleware.

    Wires up the three request-level attributes conjunto's views and
    templates rely on:

    - ``request.device`` — the :class:`Device` identified by the
      ``cj_device_id`` cookie (created on first visit, never rebound
      across users).
    - ``request.scoped_settings`` — the
      :class:`ScopedSettingsProxy` giving access to the effective
      setting value for any ``(namespace, key)`` along the
      ``USER > DEVICE > GROUP > TENANT > VENDOR`` overlay chain.
    - ``request.menus`` — the :class:`Menus` plugin registry for the
      current request.

    Also handles the maintenance-mode redirect, gated on the
    ``conjunto.maintenance_mode`` VENDOR-scoped setting. When the flag
    is truthy, non-staff users are redirected to ``/maintenance/``
    unless they are already on the login or maintenance page or
    requesting a media file.

    Ordering: must run **after** ``django.contrib.auth`` middleware
    (we read ``request.user``) and after any consumer middleware that
    populates ``request.tenant``. If ``request.tenant`` is unset we
    fall back to ``request.session['cj_tenant_id']`` and then to the
    first tenant the user holds a ``TenantMembership`` for.
    Whatever is resolved is published on the
    :class:`~conjunto.tenants.context` ContextVar so that the
    :class:`~conjunto.tenants.backends.TenantAwareModelBackend`
    sees the right tenant during permission checks.
    """

    def __init__(self, get_response) -> None:
        self.get_response = get_response

    def __call__(self, request) -> HttpResponse:
        from conjunto.settings.scoped.models import Device
        from conjunto.settings.scoped.proxy import ScopedSettingsProxy

        _thread_locals.request = request

        # ---- Tenant context ----
        # Push the current tenant (if any) into the tenant ContextVar
        # so that TenantAwareModelBackend and any out-of-view code path
        # can read it via conjunto.tenants.context.get_current_tenant().
        # ``request.tenant`` may have been set by an earlier, consumer-
        # specific middleware (subdomain router, hostname resolver, …);
        # if not, we fall back to the user's declared tenant or a
        # session-selected tenant, mirroring ITenantScope.resolve().
        tenant_token = self._bind_tenant_context(request)

        # The tenant ContextVar MUST be reset on every code path out of
        # __call__ — otherwise it leaks across requests in the same
        # worker. The single ``try/finally`` below covers both the
        # normal path and the maintenance early-return.
        try:
            # ---- Device resolution ----
            cookie_value = request.COOKIES.get(DEVICE_COOKIE_NAME)
            device = self._load_or_create_device(Device, cookie_value, request)

            # Bind device.user on first authenticated visit; never rebind.
            if (
                getattr(request, "user", None) is not None
                and request.user.is_authenticated
            ):
                if device.user_id is None:
                    device.user = request.user
                    device.save(update_fields=["user"])
                elif device.user_id != request.user.pk:
                    device = Device.objects.create(
                        user=request.user,
                        user_agent=(request.META.get("HTTP_USER_AGENT") or "")[:500],
                    )

            request.device = device
            request.scoped_settings = ScopedSettingsProxy(request)

            # ---- Maintenance mode ----
            maintenance_response = self._maintenance_redirect(request)
            if maintenance_response is not None:
                return maintenance_response

            # ---- Menus ----
            request.menus = Menus(request)

            # ---- Debounced last_seen bump ----
            now = timezone.now()
            if now - device.last_seen >= DEVICE_LAST_SEEN_DEBOUNCE:
                Device.objects.filter(pk=device.pk).update(last_seen=now)

            response = self.get_response(request)
        finally:
            if tenant_token is not None:
                from conjunto.tenants.context import reset_current_tenant

                reset_current_tenant(tenant_token)

        # ---- Write device cookie if the browser isn't carrying it ----
        if cookie_value != str(device.cookie_id):
            response.set_cookie(
                DEVICE_COOKIE_NAME,
                str(device.cookie_id),
                max_age=DEVICE_COOKIE_MAX_AGE,
                httponly=True,
                samesite="Lax",
            )

        return response

    @staticmethod
    def _bind_tenant_context(request):
        """Resolve the active tenant for this request and push it onto the
        tenant ContextVar. Also populates ``request.tenant`` if it wasn't
        already set. Returns the ContextVar reset token (or ``None`` if
        no tenant could be resolved).

        Resolution order:

        1. ``request.tenant`` — pre-set by upstream middleware (e.g.
           subdomain routing).
        2. ``request.session['cj_tenant_id']`` — tenant previously
           selected by the user (tenant switcher / login).
        3. First tenant the user holds a
           :class:`~conjunto.tenants.models.TenantMembership` for —
           automatic fallback so single-tenant users never need to
           pick explicitly.  The resolved tenant is persisted into the
           session so subsequent requests skip the membership query.
        """
        from conjunto.tenants.context import set_current_tenant
        from conjunto.tenants.utils import get_tenant_model

        tenant = getattr(request, "tenant", None)
        if tenant is None:
            TenantModel = get_tenant_model()

            # --- Session -------------------------------------------------
            session = getattr(request, "session", None)
            if session is not None:
                tenant_pk = session.get("cj_tenant_id")
                if tenant_pk is not None:
                    try:
                        tenant = TenantModel.objects.get(pk=tenant_pk)
                    except TenantModel.DoesNotExist:
                        tenant = None

            # --- TenantMembership fallback --------------------------------
            if tenant is None:
                user = getattr(request, "user", None)
                if user is not None and user.is_authenticated:
                    from conjunto.tenants.models import TenantMembership

                    membership = (
                        TenantMembership.objects.filter(
                            user=user,
                            tenant__is_active=True,
                        )
                        .select_related("tenant")
                        .order_by("pk")
                        .first()
                    )
                    if membership is not None:
                        tenant = membership.tenant
                        # Persist so subsequent requests skip this query.
                        if session is not None:
                            session["cj_tenant_id"] = tenant.pk

            request.tenant = tenant

        if tenant is None:
            return None
        return set_current_tenant(tenant)

    @staticmethod
    def _load_or_create_device(Device, cookie_value, request):
        """Return a Device matching the cookie, or a freshly created one."""
        from django.core.exceptions import ValidationError

        if cookie_value:
            try:
                return Device.objects.get(cookie_id=cookie_value)
            except (Device.DoesNotExist, ValueError, ValidationError):
                # Stale or malformed cookie — fall through to create.
                pass
        return Device.objects.create(
            user_agent=(request.META.get("HTTP_USER_AGENT") or "")[:500],
        )

    @staticmethod
    def _maintenance_redirect(request):
        """Return a redirect response if the request should be locked out
        by maintenance mode, otherwise ``None``.

        Reads the ``conjunto.maintenance_mode`` VENDOR-scoped setting
        (registered in ``conjunto.scoped_settings``). Staff users
        bypass the redirect. Login and maintenance pages are always
        reachable; ``settings.MEDIA_URL`` is whitelisted.
        """
        if not request.scoped_settings.get(
            "conjunto", "maintenance_mode", default=False
        ):
            return None
        user = getattr(request, "user", None)
        if user is not None and user.is_authenticated and user.is_staff:
            return None
        maintenance_url = None
        for name in ("conjunto:maintenance", "maintenance"):
            try:
                maintenance_url = reverse(name)
                break
            except NoReverseMatch:
                continue
        if maintenance_url is None:
            return None
        try:
            login_url = reverse("login")
        except NoReverseMatch:
            login_url = None

        path = request.path
        allowed = {maintenance_url}
        if login_url is not None:
            allowed.add(login_url)
        if path in allowed:
            return None
        media_url = settings.MEDIA_URL
        # Skip the "don't block media files" exception when MEDIA_URL is
        # unset or the root "/" — otherwise every path matches.
        if media_url and media_url != "/" and path.startswith(media_url):
            return None
        return redirect(maintenance_url)


def _messages_to_toasts(storage) -> list[dict]:
    """Convert a ``django.contrib.messages`` storage into toast dicts.

    Iterating the storage marks the messages as used, so the default
    ``{% if messages %}`` template block will not re-render them.
    """
    toasts: list[dict] = []
    for message in storage:
        extra_tags = (message.extra_tags or "").split()
        toasts.append(
            {
                "message": str(message.message),
                "level": message.level_tag,
                "tags": message.tags,
                "dismissible": "dismissible" in extra_tags,
            }
        )
    return toasts


class ConjuntoMessagesMiddleware:
    """Deliver Django ``messages`` to the browser as Bootstrap toasts.

    For **HTMX** responses the pending messages are drained from the
    messages storage and attached to the response as an ``HX-Trigger``
    header carrying a ``conjunto:toasts`` event. Client-side JavaScript
    (``conjunto/js/toasts.js``) listens for that event and renders each
    toast via Bootstrap's Toast component.

    For **full-page** responses the messages are *not* drained here —
    they flow through the normal template context and are rendered into
    a ``<script id="cj-initial-toasts" type="application/json">`` block
    by ``conjunto/includes/toasts.html``, which the same client JS picks
    up on ``DOMContentLoaded``.

    Must be registered **after** both
    ``django.contrib.messages.middleware.MessageMiddleware`` and
    ``django_htmx.middleware.HtmxMiddleware``.
    """

    def __init__(self, get_response) -> None:
        self.get_response = get_response

    def __call__(self, request) -> HttpResponse:
        response = self.get_response(request)

        # Only act on HTMX responses; full-page responses render the
        # messages via the template (see includes/toasts.html).
        if not getattr(request, "htmx", False):
            return response
        if not hasattr(request, "_messages"):
            return response

        storage = messages.get_messages(request)
        toasts = _messages_to_toasts(storage)
        # Force the storage to be marked as used even if the iteration
        # above didn't already do so (e.g. an empty storage).
        storage.used = True

        if toasts:
            trigger_client_event(response, "conjunto:toasts", params={"toasts": toasts})
        return response


class TimezoneMiddleware:
    """Activate the timezone resolved from the ``conjunto.timezone`` scoped setting.

    Reads the effective value of the ``conjunto.timezone`` key along the
    standard ``USER > TENANT > VENDOR`` overlay (a USER override beats a
    TENANT default; a VENDOR/TENANT lock beats a USER override). The
    resolved name must be a valid IANA timezone identifier (e.g.
    ``"Europe/Vienna"``). An empty value or an unknown name leaves
    Django's default ``settings.TIME_ZONE`` in place.

    Activation is via :func:`django.utils.timezone.activate`; the
    activated zone is :func:`~django.utils.timezone.deactivate`-d in a
    ``finally`` block so request-local state never leaks into the next
    request handled by the same worker thread.

    Ordering: must run **after** :class:`ConjuntoMiddleware` so that
    ``request.scoped_settings`` is available. Place it directly after
    ``ConjuntoMiddleware`` in ``MIDDLEWARE``.
    """

    def __init__(self, get_response) -> None:
        self.get_response = get_response

    def __call__(self, request) -> HttpResponse:
        tz_name = ""
        try:
            tz_name = request.scoped_settings.get("conjunto", "timezone", default="")
        except Exception:
            # During very early startup or unusual contexts the proxy
            # may not be available; fall through to the default zone.
            pass
        activated = False
        if tz_name:
            try:
                timezone.activate(zoneinfo.ZoneInfo(tz_name))
                activated = True
            except zoneinfo.ZoneInfoNotFoundError:
                # Stale / typo'd setting — fall back to default.
                pass
        try:
            return self.get_response(request)
        finally:
            if activated:
                timezone.deactivate()


class ScriptRegistryMiddleware:
    """Attach a :class:`~conjunto.scripts.ScriptRegistry` to every request.

    Views and template tags can call ``request.cj_scripts.add(path)`` to
    register feature scripts on demand. The ``{% conjunto_render_scripts %}`` tag
    in the base template emits the collected ``<script>`` tags.

    Must be registered in ``MIDDLEWARE`` **before** any view middleware that
    might call ``request.cj_scripts.add()``.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        from conjunto.scripts import ScriptRegistry

        request.cj_scripts = ScriptRegistry()
        return self.get_response(request)
