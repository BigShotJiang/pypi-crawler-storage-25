"""``archive_cleanup`` — scheduled retention cleanup.

Walks every ``ArchivableMixin``-bearing model, finds rows whose soft-
delete predates their :class:`RetentionPolicy` window, and physically
purges them (row + all associated ``ArchiveVersion`` / ``ArchiveRevisionMeta``
rows) atomically. Each purge is recorded in ``DeletionLog`` with
``reason=retention_expired``.

Patent design-around (DOLORES): this is explicitly a management command,
never an HTTP API. Every piece of documentation refers to the feature as
"scheduled retention cleanup" — never "bulk delete API", "retention
service endpoint", or similar patent-risky wording.

Zero-Trust anchors:

- **Identity pillar**: the command runs under the *system* actor, not
  a user. ``DeletionLog.triggered_by`` records ``"archive_cleanup:<uuid>"``
  — the uuid distinguishes one run from another.
- **Application pillar**: retention tokens are only issuable inside
  :func:`cleanup_context` (see ``retention/token.py``); web views cannot
  acquire one, full stop.
- **Data pillar**: all log rows that describe the purged row are
  physically removed in the same transaction. No orphan versions, no
  orphan revision metas, no orphan access logs.

Options:

- ``--dry-run`` — show what would be purged, write nothing.
- ``--tenant <id>`` — restrict to one tenant.
- ``--model <app.Model>`` — restrict to one model.
- ``--limit <n>`` — maximum rows purged in this run (safety valve).
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from typing import Iterable

from django.apps import apps
from django.core.management.base import BaseCommand, CommandError
from django.db import connection, transaction
from django.utils import timezone

from conjunto.archive.mixins import ArchivableMixin
from conjunto.archive.models import DeletionLog, DeletionReason
from conjunto.archive.retention import (
    RetentionToken,
    cleanup_context,
    policy_for_model,
)

logger = logging.getLogger(__name__)


# Postgres-only: ARTHUR's report prescribes SKIP LOCKED + 30s lock_timeout
# so two cleanup runs cannot deadlock each other on the same tenant.
_LOCK_TIMEOUT_MS: int = 30_000


@dataclass
class _PurgeStats:
    """Counters collected across one cleanup run."""

    scanned: int = 0
    purged: int = 0
    versions_purged: int = 0
    metas_purged: int = 0
    errors: int = 0


class Command(BaseCommand):
    help = (
        "Scheduled retention cleanup: purge soft-deleted rows whose "
        "retention window has elapsed. DOLORES-approved management-command "
        "path; no HTTP API exists for this feature."
    )

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Show what would be purged without writing anything.",
        )
        parser.add_argument(
            "--tenant",
            type=str,
            default=None,
            help="Restrict cleanup to one tenant (PK as string).",
        )
        parser.add_argument(
            "--model",
            type=str,
            default=None,
            help="Restrict to a single model, e.g. 'myapp.Patient'.",
        )
        parser.add_argument(
            "--limit",
            type=int,
            default=None,
            help="Maximum rows purged across all models in this run.",
        )

    # ------------------------------------------------------------------ #
    # Entry point
    # ------------------------------------------------------------------ #
    def handle(self, *args, **options) -> None:
        dry_run: bool = options["dry_run"]
        tenant_filter: str | None = options["tenant"]
        model_filter: str | None = options["model"]
        limit: int | None = options["limit"]

        run_id = uuid.uuid4().hex[:12]
        triggered_by = f"archive_cleanup:{run_id}"
        stats = _PurgeStats()

        logger.info(
            "archive_cleanup start run_id=%s dry_run=%s tenant=%s model=%s limit=%s",
            run_id,
            dry_run,
            tenant_filter or "*",
            model_filter or "*",
            limit if limit is not None else "-",
        )

        models_to_scan = list(self._resolve_models(model_filter))
        if not models_to_scan:
            self.stdout.write(
                self.style.WARNING(
                    "No ArchivableMixin models match the filter — nothing to do."
                )
            )
            logger.info("archive_cleanup end run_id=%s no_models_matched", run_id)
            return

        # cleanup_context() is the Zero-Trust boundary: inside, we are
        # allowed to issue RetentionTokens; outside, RetentionToken.issue()
        # raises PermissionError. Everything we do runs inside the scope.
        with cleanup_context():
            for model in models_to_scan:
                if limit is not None and stats.purged >= limit:
                    break
                self._process_model(
                    model,
                    tenant_filter=tenant_filter,
                    limit=limit,
                    dry_run=dry_run,
                    triggered_by=triggered_by,
                    stats=stats,
                )

        self._report(stats, dry_run=dry_run)
        logger.info(
            "archive_cleanup end run_id=%s scanned=%d purged=%d "
            "versions=%d metas=%d errors=%d",
            run_id,
            stats.scanned,
            stats.purged,
            stats.versions_purged,
            stats.metas_purged,
            stats.errors,
        )

    # ------------------------------------------------------------------ #
    # Model discovery
    # ------------------------------------------------------------------ #
    @staticmethod
    def _resolve_models(model_filter: str | None) -> Iterable[type]:
        """Yield every concrete ``ArchivableMixin`` subclass to scan."""
        if model_filter:
            try:
                model = apps.get_model(model_filter)
            except (LookupError, ValueError) as exc:
                raise CommandError(
                    f"--model {model_filter!r} does not resolve: {exc}"
                ) from exc
            if not issubclass(model, ArchivableMixin):
                raise CommandError(
                    f"{model_filter} is not an ArchivableMixin subclass."
                )
            yield model
            return

        for model in apps.get_models():
            if issubclass(model, ArchivableMixin):
                yield model

    # ------------------------------------------------------------------ #
    # Per-model loop
    # ------------------------------------------------------------------ #
    def _process_model(
        self,
        model: type,
        *,
        tenant_filter: str | None,
        limit: int | None,
        dry_run: bool,
        triggered_by: str,
        stats: _PurgeStats,
    ) -> None:
        policy = policy_for_model(model)
        today = timezone.localdate()
        # Retention is anchored on ``deleted_at``. Compute the cutoff
        # once and filter with a simple LTE — avoids per-row python-side
        # policy dispatch and lets Postgres use the index on deleted_at.
        from datetime import timedelta

        cutoff_date = today - timedelta(days=policy.years * 365)

        # Use ``all_objects`` because soft-deleted rows are invisible to
        # the default manager. deleted_at__lte(cutoff) pulls expired rows
        # only; the ``isnull=False`` is belt-and-braces.
        qs = model.all_objects.filter(
            deleted_at__isnull=False,
            deleted_at__date__lte=cutoff_date,
        )

        # Optional tenant filter — only meaningful on tenant-scoped
        # models. On non-tenant models the filter is a silent no-op
        # (no tenant attr means qs is unchanged).
        if tenant_filter is not None and self._has_tenant_field(model):
            qs = qs.filter(tenant_id=tenant_filter)

        qs = qs.order_by("deleted_at")

        # Postgres SKIP LOCKED for safe concurrent runs. On SQLite /
        # other backends, ``select_for_update(skip_locked=True)`` is a
        # no-op; we only attempt it on Postgres to avoid backend errors.
        if connection.vendor == "postgresql":
            self._set_lock_timeout()
            qs = qs.select_for_update(skip_locked=True)

        # Evaluate qs fully up front so the retention-cleanup loop
        # does not hold a long-running cursor over the source table.
        candidates = list(qs[: (limit - stats.purged) if limit is not None else None])
        stats.scanned += len(candidates)

        if not candidates:
            return

        for instance in candidates:
            if limit is not None and stats.purged >= limit:
                return
            self._purge_one(
                instance,
                model=model,
                dry_run=dry_run,
                triggered_by=triggered_by,
                stats=stats,
            )

    @staticmethod
    def _has_tenant_field(model: type) -> bool:
        """Return True if the model carries a ``tenant`` FK."""
        try:
            model._meta.get_field("tenant")
            return True
        except Exception:  # pragma: no cover - defensive; trivial branch
            return False

    @staticmethod
    def _set_lock_timeout() -> None:
        """Apply Postgres lock_timeout for this transaction (30 s)."""
        with connection.cursor() as cur:
            cur.execute(f"SET LOCAL lock_timeout = '{_LOCK_TIMEOUT_MS}ms'")

    # ------------------------------------------------------------------ #
    # Per-row purge
    # ------------------------------------------------------------------ #
    def _purge_one(
        self,
        instance,
        *,
        model: type,
        dry_run: bool,
        triggered_by: str,
        stats: _PurgeStats,
    ) -> None:
        label = f"{model._meta.app_label}.{model.__name__}(pk={instance.pk})"
        if dry_run:
            self.stdout.write(f"[DRY-RUN] would purge {label}")
            stats.purged += 1
            return

        # Snapshot identity before the cascade: Django nulls the pk on
        # successful DELETE, so we must capture the pk (and the tenant
        # FK value) before ``_hard_delete_cascade`` runs.
        frozen_pk = str(instance.pk)
        frozen_tenant = self._tenant_of(instance)

        try:
            with transaction.atomic():
                token = RetentionToken.issue(purpose="archive_cleanup")
                counts = instance._hard_delete_cascade(token=token)
                # Write the DeletionLog entry after the purge lands so
                # that a failed purge never leaves behind a log row
                # that claims the delete happened.
                DeletionLog.objects.create(
                    app_label=model._meta.app_label,
                    model_name=model.__name__,
                    object_pk=frozen_pk,
                    tenant=frozen_tenant,
                    reason=DeletionReason.RETENTION_EXPIRED,
                    triggered_by=triggered_by,
                    deleted_at_final=timezone.now(),
                )
        except Exception:
            # Log and continue — one row's failure must not stop the run.
            # The operator sees the full traceback in the Django log.
            logger.exception("archive_cleanup: purge failed for %s, continuing", label)
            stats.errors += 1
            return

        stats.purged += 1
        stats.versions_purged += counts.get("archive_versions", 0)
        stats.metas_purged += counts.get("revision_metas", 0)
        logger.info("archive_cleanup purged %s counts=%r", label, counts)

    @staticmethod
    def _tenant_of(instance) -> object | None:
        """Return the tenant FK value, if any, for DeletionLog tagging."""
        return getattr(instance, "tenant", None)

    # ------------------------------------------------------------------ #
    # Reporting
    # ------------------------------------------------------------------ #
    def _report(self, stats: _PurgeStats, *, dry_run: bool) -> None:
        header = "[DRY-RUN] " if dry_run else ""
        self.stdout.write(
            self.style.SUCCESS(
                f"{header}archive_cleanup done: "
                f"scanned={stats.scanned} purged={stats.purged} "
                f"versions={stats.versions_purged} metas={stats.metas_purged} "
                f"errors={stats.errors}"
            )
        )
