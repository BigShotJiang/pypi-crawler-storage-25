"""``archive_reconcile`` — restore-safety for the deletion log.

Use case: an operator restores a historical database backup that still
contains rows which were later physically purged by ``archive_cleanup``.
Without reconciliation, those rows would "zombie" back into existence.

``archive_reconcile`` walks every ``DeletionLog`` entry, checks whether
the corresponding source row exists in the current database, and, if
so, re-purges it with ``reason=reconcile_after_restore``. A fresh
``DeletionLog`` row is written for each re-purge so the audit trail
records the reconciliation as a distinct event.

Zero-Trust anchors:

- **Identity**: runs under the system actor, like ``archive_cleanup``.
  ``triggered_by`` = ``"archive_reconcile:<run-id>"``.
- **Data**: each re-purge is atomic (instance + ArchiveVersion + meta).
- **Application**: tokens are issued inside :func:`cleanup_context`; the
  command cannot be trivially invoked from the request cycle.

Options:

- ``--dry-run`` — show what would be re-purged, write nothing.
- ``--tenant <id>`` — restrict reconciliation to one tenant.
"""

from __future__ import annotations

import logging
import uuid

from django.apps import apps
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from conjunto.archive.mixins import ArchivableMixin
from conjunto.archive.models import DeletionLog, DeletionReason
from conjunto.archive.retention import (
    RetentionToken,
    cleanup_context,
)

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = (
        "Reconcile DeletionLog against the current database after a "
        "backup restore: re-purge rows that reappeared."
    )

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Show what would be re-purged without writing anything.",
        )
        parser.add_argument(
            "--tenant",
            type=str,
            default=None,
            help="Restrict reconciliation to one tenant (PK as string).",
        )

    # ------------------------------------------------------------------ #
    # Entry point
    # ------------------------------------------------------------------ #
    def handle(self, *args, **options) -> None:
        dry_run: bool = options["dry_run"]
        tenant_filter: str | None = options["tenant"]
        run_id = uuid.uuid4().hex[:12]
        triggered_by = f"archive_reconcile:{run_id}"

        logger.info(
            "archive_reconcile start run_id=%s dry_run=%s tenant=%s",
            run_id,
            dry_run,
            tenant_filter or "*",
        )

        log_qs = DeletionLog.objects.all().order_by("-created_at")
        if tenant_filter is not None:
            log_qs = log_qs.filter(tenant_id=tenant_filter)

        scanned = 0
        redeleted = 0
        errors = 0

        # Deduplicate: for the same (app_label, model_name, object_pk),
        # we only need to re-purge once even if several DeletionLog
        # entries exist. Iterate sorted so the newest log row wins.
        seen: set[tuple[str, str, str]] = set()

        with cleanup_context():
            for log_row in log_qs.iterator(chunk_size=500):
                key = (log_row.app_label, log_row.model_name, log_row.object_pk)
                if key in seen:
                    continue
                seen.add(key)
                scanned += 1

                model = self._resolve_model(*key[:2])
                if model is None:
                    logger.warning(
                        "archive_reconcile: model %s.%s no longer installed, skipping",
                        log_row.app_label,
                        log_row.model_name,
                    )
                    continue

                instance = self._fetch_instance(model, log_row.object_pk)
                if instance is None:
                    # Expected happy path: the row is actually gone.
                    continue

                # The row came back — re-purge it.
                label = (
                    f"{log_row.app_label}.{log_row.model_name}(pk={log_row.object_pk})"
                )
                if dry_run:
                    self.stdout.write(f"[DRY-RUN] would re-purge {label}")
                    redeleted += 1
                    continue

                # Snapshot the tenant FK before ``_hard_delete_cascade``
                # nulls it, mirroring archive_cleanup's approach.
                frozen_tenant = getattr(instance, "tenant", None)
                try:
                    with transaction.atomic():
                        token = RetentionToken.issue(purpose="archive_reconcile")
                        instance._hard_delete_cascade(token=token)
                        DeletionLog.objects.create(
                            app_label=log_row.app_label,
                            model_name=log_row.model_name,
                            object_pk=log_row.object_pk,
                            tenant=frozen_tenant,
                            reason=DeletionReason.RECONCILE_AFTER_RESTORE,
                            triggered_by=triggered_by,
                            deleted_at_final=timezone.now(),
                        )
                    redeleted += 1
                    logger.info("archive_reconcile re-purged %s", label)
                except Exception:
                    logger.exception("archive_reconcile: re-purge failed for %s", label)
                    errors += 1

        header = "[DRY-RUN] " if dry_run else ""
        self.stdout.write(
            self.style.SUCCESS(
                f"{header}archive_reconcile done: "
                f"scanned={scanned} redeleted={redeleted} errors={errors}"
            )
        )
        logger.info(
            "archive_reconcile end run_id=%s scanned=%d redeleted=%d errors=%d",
            run_id,
            scanned,
            redeleted,
            errors,
        )

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _resolve_model(app_label: str, model_name: str) -> type | None:
        try:
            model = apps.get_model(app_label, model_name)
        except (LookupError, ValueError):
            return None
        if not issubclass(model, ArchivableMixin):
            return None
        return model

    @staticmethod
    def _fetch_instance(model: type, object_pk: str):
        """Return the instance for ``object_pk`` if it still exists.

        Uses ``all_objects`` because a reappeared row might be alive,
        soft-deleted, or anything in between — we want to find it either
        way so we can re-purge it.
        """
        try:
            return model.all_objects.filter(pk=object_pk).first()
        except (ValueError, TypeError):
            # pk type mismatch (e.g. object_pk is a uuid string but the
            # reinstated model uses int pk) — treat as "no match".
            return None
