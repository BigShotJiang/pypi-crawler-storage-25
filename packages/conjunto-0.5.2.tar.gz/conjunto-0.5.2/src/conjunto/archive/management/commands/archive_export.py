"""``archive_export`` — tenant-scoped full export (FUDGE AVV / insolvency).

Writes an NDJSON stream per model under ``<output>/<tenant-id>/`` so the
output is streamable and safe for multi-GB tenants. Each line is a
self-contained JSON object with the full row payload.

Exported data per tenant:

- All ``ArchivableMixin``-bearing rows of each installed model, both
  alive and soft-deleted (``all_objects``).
- All ``ArchiveVersion`` rows referencing those source rows, with their
  ``ArchiveRevisionMeta`` inlined.
- Any ``TemporalMixin`` historical row is captured by the source-row
  loop (TemporalMixin does not store rows in a side table — every
  valid_from/valid_to row is a normal row on the concrete model).

Deliberately **not** exported:

- ``DeletionLog`` rows — the audit trail stays internal even on a
  tenant export (Zero-Trust identity / application pillars; a tenant
  handing their data to an insolvency administrator does not also hand
  over the operator's own audit log).

This command is read-only. It never creates ``DeletionLog`` entries,
never soft-deletes, never hard-deletes. Running it twice is safe.

Patent-phrasing guard: documented as "tenant data export" throughout.
The word "bulk" is avoided in user-facing strings.
"""

from __future__ import annotations

import datetime
import decimal
import hashlib
import json
import logging
import uuid
from pathlib import Path
from typing import Any

from django.apps import apps
from django.contrib.contenttypes.models import ContentType
from django.core.management.base import BaseCommand, CommandError

from conjunto.archive.mixins import ArchivableMixin
from conjunto.archive.models import ArchiveVersion

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = (
        "Tenant-scoped full export: all archivable rows + all "
        "ArchiveVersion snapshots + revision metadata for the given "
        "tenant. NDJSON format, one file per model."
    )

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--tenant",
            type=str,
            required=True,
            help="Tenant PK as string. Required.",
        )
        parser.add_argument(
            "--output",
            type=str,
            required=True,
            help="Output directory. Will be created if missing.",
        )

    # ------------------------------------------------------------------ #
    # Entry point
    # ------------------------------------------------------------------ #
    def handle(self, *args, **options) -> None:
        tenant_id: str = options["tenant"]
        output: str = options["output"]

        run_id = uuid.uuid4().hex[:12]
        out_dir = Path(output).expanduser().resolve() / str(tenant_id)
        out_dir.mkdir(parents=True, exist_ok=True)

        logger.info(
            "archive_export start run_id=%s tenant=%s out=%s",
            run_id,
            tenant_id,
            out_dir,
        )

        manifest: dict[str, Any] = {
            "run_id": run_id,
            "tenant_id": tenant_id,
            "generated_at": datetime.datetime.now(tz=datetime.UTC).isoformat(),
            "files": [],
        }

        models_with_data = [
            m for m in apps.get_models() if issubclass(m, ArchivableMixin)
        ]
        if not models_with_data:
            raise CommandError(
                "No ArchivableMixin models are installed; nothing to export."
            )

        for model in models_with_data:
            written = self._export_model(model, tenant_id=tenant_id, out_dir=out_dir)
            if written is None:
                continue
            manifest["files"].append(written)

        manifest_path = out_dir / "manifest.json"
        manifest_path.write_text(
            json.dumps(manifest, indent=2, sort_keys=True, default=_json_default),
            encoding="utf-8",
        )

        self.stdout.write(
            self.style.SUCCESS(
                f"archive_export done: wrote {len(manifest['files'])} "
                f"model files + manifest.json to {out_dir}"
            )
        )
        logger.info(
            "archive_export end run_id=%s files=%d", run_id, len(manifest["files"])
        )

    # ------------------------------------------------------------------ #
    # Per-model export
    # ------------------------------------------------------------------ #
    def _export_model(
        self,
        model: type,
        *,
        tenant_id: str,
        out_dir: Path,
    ) -> dict | None:
        qs = model.all_objects.all()
        if self._has_tenant_field(model):
            qs = qs.filter(tenant_id=tenant_id)

        # Deterministic ordering so re-runs produce identical SHA256.
        qs = qs.order_by("pk")

        rows = list(qs.iterator(chunk_size=500))
        if not rows:
            return None

        model_label = f"{model._meta.app_label}.{model.__name__}"
        filename = f"{model._meta.app_label}.{model.__name__}.ndjson"
        path = out_dir / filename

        ct = ContentType.objects.get_for_model(model)
        version_qs = (
            ArchiveVersion.objects.filter(
                content_type=ct,
                object_id__in=[str(r.pk) for r in rows],
            )
            .select_related("revision_meta")
            .order_by("object_id", "created_at")
        )

        hasher = hashlib.sha256()

        with path.open("w", encoding="utf-8") as fh:
            # Write source rows first, then versions. Each line is a
            # self-describing record with a ``kind`` discriminator.
            for row in rows:
                line = json.dumps(
                    {
                        "kind": "row",
                        "model": model_label,
                        "pk": _json_default(row.pk),
                        "data": _row_to_dict(row),
                    },
                    sort_keys=True,
                    default=_json_default,
                )
                fh.write(line + "\n")
                hasher.update(line.encode("utf-8") + b"\n")

            for version in version_qs:
                line = json.dumps(
                    {
                        "kind": "archive_version",
                        "model": model_label,
                        "object_pk": version.object_id,
                        "schema_version": version.schema_version,
                        "created_at": _json_default(version.created_at),
                        "serialized_data": version.serialized_data,
                        "revision_meta": {
                            "reason_code": version.revision_meta.reason_code,
                            "comment": version.revision_meta.comment,
                            "created_at": _json_default(
                                version.revision_meta.created_at
                            ),
                            "user_id": _json_default(version.revision_meta.user_id),
                            "tenant_id": _json_default(version.revision_meta.tenant_id),
                        },
                    },
                    sort_keys=True,
                    default=_json_default,
                )
                fh.write(line + "\n")
                hasher.update(line.encode("utf-8") + b"\n")

        return {
            "model": model_label,
            "file": filename,
            "row_count": len(rows),
            "version_count": version_qs.count(),
            "sha256": hasher.hexdigest(),
        }

    @staticmethod
    def _has_tenant_field(model: type) -> bool:
        try:
            model._meta.get_field("tenant")
            return True
        except Exception:
            return False


# ---------------------------------------------------------------------- #
# Serialisation helpers
# ---------------------------------------------------------------------- #
def _row_to_dict(instance) -> dict[str, Any]:
    """Serialise one archivable row to a plain dict."""
    payload: dict[str, Any] = {}
    for field in type(instance)._meta.concrete_fields:
        if field.is_relation and field.many_to_one:
            payload[field.name] = getattr(instance, field.attname)
        else:
            payload[field.name] = getattr(instance, field.attname, None)
    return payload


def _json_default(value: Any) -> Any:
    """``json.dumps`` default hook for datetimes, Decimal, UUID, etc."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
        return value.isoformat()
    if isinstance(value, decimal.Decimal):
        return str(value)
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, bytes):
        return value.hex()
    return str(value)
