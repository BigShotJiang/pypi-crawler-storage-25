"""Retention policy — how long soft-deleted rows survive before purge.

The policy object answers two questions per archivable model:

1. **When does this row's retention end?** — ``retention_end_for(instance)``
   returns the date on which ``archive_cleanup`` will purge the row.
2. **Is it ripe?** — ``is_expired(instance)`` compares that date against
   today.

Retention is counted **from the soft-delete timestamp** (``deleted_at``),
not from creation. Rationale (FUDGE ruling): § 1489 ABGB triggers when
a party could first have asserted the claim — for us that is the moment
the record was removed from active use, i.e. soft-deleted. A row that
was never soft-deleted is never expired, regardless of age.

Per-model overrides live on the model's ``Archive`` inner class:

- ``Archive.retention_years`` — desired retention length; ``None`` means
  "use the policy default".
- ``Archive.retention_floor_years`` — absolute minimum the policy must
  not undercut. Medical models ship with ``30`` (§ 51 ÄrzteG), accounting
  models with ``7`` (§ 132 UGB / § 212 BAO).

If ``retention_years`` is lower than ``retention_floor_years``, the
policy silently clamps upward. This is **not** an error — it prevents
a plugin author's well-meaning "keep for 10 years" from violating the
medical retention floor, which would be a statutory breach.

The backwards-compatible re-export of :class:`RetentionToken` at the
bottom of this module exists so that Phase-1/-2/-3 import sites keep
working; the token itself now lives in
``conjunto.archive.retention.token``.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import TYPE_CHECKING

from django.utils import timezone

if TYPE_CHECKING:  # pragma: no cover
    from django.db.models import Model


# Policy defaults the blueprint nails down:
#
# - Medical models: 30 years (§ 51 ÄrzteG, § 1489 ABGB).
# - Accounting models: 7 years (§ 132 UGB, § 212 BAO — nerdocs scope AT).
#
# The framework default is the medical one — we would rather err on the
# safe side for a practice-management codebase. Plugin authors for
# non-medical models override ``retention_floor_years`` + ``retention_years``
# on their ``Archive`` inner class.
DEFAULT_RETENTION_YEARS: int = 30
DEFAULT_MEDICAL_FLOOR_YEARS: int = 30
DEFAULT_ACCOUNTING_FLOOR_YEARS: int = 7


@dataclass(frozen=True)
class RetentionPolicy:
    """How long rows of a model are kept after soft-delete.

    A single ``RetentionPolicy`` instance is derived per model at
    lookup time from the model's ``Archive`` inner class. The dataclass
    is frozen to make the policy effectively immutable during a
    cleanup run.
    """

    years: int = DEFAULT_RETENTION_YEARS
    floor_years: int = DEFAULT_MEDICAL_FLOOR_YEARS

    def __post_init__(self) -> None:
        # Frozen dataclass: use object.__setattr__ to clamp upward.
        if self.years < self.floor_years:
            object.__setattr__(self, "years", self.floor_years)
        if self.years <= 0:
            raise ValueError(
                f"RetentionPolicy.years must be positive; got {self.years!r}."
            )
        if self.floor_years < 0:
            raise ValueError(
                f"RetentionPolicy.floor_years must be non-negative; "
                f"got {self.floor_years!r}."
            )

    # ------------------------------------------------------------------ #
    # Instance-level queries
    # ------------------------------------------------------------------ #
    def retention_end_for(self, instance: "Model") -> date | None:
        """Return the date on which ``instance`` may be hard-deleted.

        Returns ``None`` if the instance is not soft-deleted — a live
        row has no retention end.
        """
        deleted_at = getattr(instance, "deleted_at", None)
        if deleted_at is None:
            return None
        # Convert datetime to date in the active timezone so that
        # retention boundaries respect the operator's calendar day.
        if hasattr(deleted_at, "date"):
            deleted_date = timezone.localtime(deleted_at).date()
        else:
            deleted_date = deleted_at  # already a ``date``
        # ``timedelta`` does not accept years directly; use 365-day years
        # and accept leap-year drift (retention is measured in whole
        # years; one day either way is immaterial for 7/30-year windows).
        return deleted_date + timedelta(days=self.years * 365)

    def is_expired(self, instance: "Model", *, today: date | None = None) -> bool:
        """Return True iff this instance's retention window has elapsed.

        ``today`` defaults to ``timezone.localdate()``; tests inject a
        fixed date.
        """
        end = self.retention_end_for(instance)
        if end is None:
            return False
        ref = today if today is not None else timezone.localdate()
        return ref >= end


# ---------------------------------------------------------------------- #
# Registry: resolve policy per model
# ---------------------------------------------------------------------- #
_POLICY_CACHE: dict[type, RetentionPolicy] = {}


def policy_for_model(model: type) -> RetentionPolicy:
    """Return the effective retention policy for ``model``.

    Reads ``Archive.retention_years`` and ``Archive.retention_floor_years``
    from the model; falls back to the framework defaults. Caches per
    class because policy resolution is pure and called on the hot path
    of ``archive_cleanup``.
    """
    cached = _POLICY_CACHE.get(model)
    if cached is not None:
        return cached

    archive_cls = getattr(model, "Archive", None)
    years = (
        getattr(archive_cls, "retention_years", None)
        if archive_cls is not None
        else None
    )
    floor = (
        getattr(archive_cls, "retention_floor_years", None)
        if archive_cls is not None
        else None
    )

    resolved_floor = floor if floor is not None else DEFAULT_MEDICAL_FLOOR_YEARS
    resolved_years = years if years is not None else DEFAULT_RETENTION_YEARS

    policy = RetentionPolicy(
        years=resolved_years,
        floor_years=resolved_floor,
    )
    _POLICY_CACHE[model] = policy
    return policy


def _reset_policy_cache() -> None:
    """Clear the policy cache. Exposed for tests that reconfigure models."""
    _POLICY_CACHE.clear()


# Backwards-compatible re-export — Phase 1/2/3 imported RetentionToken
# from conjunto.archive.retention.policy. The real implementation now
# lives in .token, but the symbol stays reachable here.
from conjunto.archive.retention.token import RetentionToken  # noqa: E402, F401


__all__ = [
    "RetentionPolicy",
    "RetentionToken",
    "policy_for_model",
    "DEFAULT_RETENTION_YEARS",
    "DEFAULT_MEDICAL_FLOOR_YEARS",
    "DEFAULT_ACCOUNTING_FLOOR_YEARS",
]
