"""Retention subsystem — Phase 4 public API.

- :class:`RetentionPolicy` — per-model "how long do we keep this" policy
  with statutory floor enforcement.
- :func:`policy_for_model` — resolve the effective policy for a model.
- :class:`RetentionToken` — Zero-Trust capsule authorising one
  physical ``hard_delete()``. TTL, PID-bound, single-use.
- :func:`cleanup_context` — context manager under which (and only under
  which) ``RetentionToken.issue()`` succeeds.
"""

from conjunto.archive.retention.policy import (
    DEFAULT_ACCOUNTING_FLOOR_YEARS,
    DEFAULT_MEDICAL_FLOOR_YEARS,
    DEFAULT_RETENTION_YEARS,
    RetentionPolicy,
    policy_for_model,
)
from conjunto.archive.retention.token import (
    RetentionToken,
    cleanup_context,
)

__all__ = [
    "RetentionPolicy",
    "RetentionToken",
    "cleanup_context",
    "policy_for_model",
    "DEFAULT_ACCOUNTING_FLOOR_YEARS",
    "DEFAULT_MEDICAL_FLOOR_YEARS",
    "DEFAULT_RETENTION_YEARS",
]
