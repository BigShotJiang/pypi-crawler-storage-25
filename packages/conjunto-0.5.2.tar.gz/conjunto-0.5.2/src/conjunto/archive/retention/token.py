"""``RetentionToken`` — Zero-Trust capsule for ``hard_delete()``.

A ``RetentionToken`` is the one-time authorisation object that lets
``ArchivableMixin.hard_delete()`` actually purge a row. Every property
of the token is a guard against accidental or hostile use:

- **Factory-only construction.** The constructor refuses direct calls;
  callers must go through :meth:`RetentionToken.issue`, which itself is
  only meaningful inside the ``cleanup_context()`` context manager.
  Web views that try to issue a token receive ``PermissionError``.
- **TTL.** Tokens self-expire five minutes after issuance (configurable
  via the Django setting ``CONJUNTO_ARCHIVE_RETENTION_TOKEN_TTL``).
- **PID binding.** A token only validates inside the same OS process
  that issued it — a fork/exec into an unrelated context invalidates it.
- **Single use.** ``validate_or_raise()`` marks the token as consumed;
  a second call raises ``PermissionError`` regardless of remaining TTL.

The token is intentionally cheap — no crypto, no database row. Its
security property is contextual: only the retention cleanup command
runs inside ``cleanup_context()``, and nothing else can create a valid
token. Postgres-trigger-level protection is a v2 item (Blueprint §10).
"""

from __future__ import annotations

import contextlib
import contextvars
import os
import time
import uuid
from dataclasses import dataclass, field
from typing import Iterator

from django.conf import settings

# Sentinel passed by ``issue()`` into the constructor. Ensures the
# dataclass ``__post_init__`` can tell factory-origin from a direct
# ``RetentionToken(...)`` call.
_ISSUE_SENTINEL: object = object()

# Contextvar flag that ``cleanup_context()`` flips while the retention
# cleanup command is running. Any attempt to issue a token outside an
# active cleanup context is rejected. ``contextvars`` propagate across
# ``sync_to_async`` / thread boundaries correctly, unlike ``threading.local``.
_cleanup_active: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "conjunto_archive_cleanup_active", default=False
)

# Five-minute default TTL per Phase-4 spec. Overridable via Django
# setting ``CONJUNTO_ARCHIVE_RETENTION_TOKEN_TTL`` (seconds, int).
DEFAULT_TTL_SECONDS: int = 5 * 60


def _resolve_default_ttl() -> int:
    """Return the configured token TTL, falling back to five minutes."""
    return int(
        getattr(
            settings,
            "CONJUNTO_ARCHIVE_RETENTION_TOKEN_TTL",
            DEFAULT_TTL_SECONDS,
        )
    )


@contextlib.contextmanager
def cleanup_context() -> Iterator[None]:
    """Mark the current execution context as trusted retention cleanup.

    ``RetentionToken.issue()`` only succeeds while this context manager
    is active. The three retention management commands
    (``archive_cleanup``, ``archive_reconcile``, and the internal
    fallback in ``archive_export`` if it ever needs one) enter this
    context at the start of their ``handle()``; nothing else should.

    Web view code that calls ``RetentionToken.issue()`` will hit the
    ``PermissionError`` raised by ``issue()``, because the contextvar
    defaults to ``False`` on request threads.
    """
    token = _cleanup_active.set(True)
    try:
        yield
    finally:
        _cleanup_active.reset(token)


def _is_cleanup_context_active() -> bool:
    """Return True iff a retention cleanup context is currently active."""
    return _cleanup_active.get()


@dataclass
class RetentionToken:
    """Authorisation capsule for a single ``hard_delete()`` call.

    Never construct this directly — use :meth:`issue` from inside a
    :func:`cleanup_context`. The private-key sentinel parameter exists
    solely to enforce the factory rule.
    """

    purpose: str
    _private_key: object = field(repr=False, default=None)
    _issued_at: float = field(default_factory=time.monotonic, repr=False)
    _ttl_seconds: int = field(default=DEFAULT_TTL_SECONDS, repr=False)
    _process_id: int = field(default_factory=os.getpid, repr=False)
    _token_id: uuid.UUID = field(default_factory=uuid.uuid4, repr=False)
    _consumed: bool = field(default=False, repr=False)

    def __post_init__(self) -> None:
        if self._private_key is not _ISSUE_SENTINEL:
            raise RuntimeError(
                "RetentionToken cannot be constructed directly. "
                "Use RetentionToken.issue(purpose=...) from inside a "
                "cleanup_context() block (retention cleanup commands only)."
            )

    # ------------------------------------------------------------------ #
    # Factory
    # ------------------------------------------------------------------ #
    @classmethod
    def issue(
        cls,
        *,
        purpose: str,
        ttl_seconds: int | None = None,
    ) -> "RetentionToken":
        """Issue a fresh retention token inside a trusted cleanup context.

        Raises ``PermissionError`` if called outside ``cleanup_context()``
        (i.e. from a web view, a signal handler, or untrusted plugin code).
        """
        if not _is_cleanup_context_active():
            raise PermissionError(
                "RetentionToken.issue() is only permitted inside "
                "cleanup_context(). Physical deletes are reserved for "
                "scheduled retention cleanup commands."
            )
        return cls(
            purpose=purpose,
            _private_key=_ISSUE_SENTINEL,
            _ttl_seconds=(
                ttl_seconds if ttl_seconds is not None else _resolve_default_ttl()
            ),
        )

    # ------------------------------------------------------------------ #
    # Validity check — non-consuming
    # ------------------------------------------------------------------ #
    def valid(self) -> bool:
        """Return True iff the token is still usable (non-consuming).

        A token is valid while:

        - it has not been consumed by ``validate_or_raise()``,
        - its TTL has not elapsed, AND
        - it is being checked from the same OS process that issued it.

        Does NOT mark the token as consumed — that is ``validate_or_raise``'s
        job. ``valid()`` is what ``ArchivableMixin.hard_delete()`` calls
        today (Phase 1 signature); the Phase-4 cleanup command uses
        ``validate_or_raise`` to additionally enforce single-use.
        """
        if self._consumed:
            return False
        if os.getpid() != self._process_id:
            return False
        elapsed = time.monotonic() - self._issued_at
        return elapsed < self._ttl_seconds

    # ------------------------------------------------------------------ #
    # Consuming validation
    # ------------------------------------------------------------------ #
    def validate_or_raise(self) -> None:
        """Assert the token is usable and mark it as consumed.

        Raises ``PermissionError`` with a precise reason for each of
        the three failure modes: expired, wrong process (PID mismatch),
        and reused.
        """
        if self._consumed:
            raise PermissionError(
                "RetentionToken has already been consumed; tokens are single-use."
            )
        if os.getpid() != self._process_id:
            raise PermissionError(
                "RetentionToken is bound to the issuing process; "
                "cross-process use is forbidden."
            )
        elapsed = time.monotonic() - self._issued_at
        if elapsed >= self._ttl_seconds:
            raise PermissionError(
                f"RetentionToken has expired "
                f"(ttl={self._ttl_seconds}s, age={elapsed:.1f}s)."
            )
        self._consumed = True


__all__ = [
    "RetentionToken",
    "cleanup_context",
    "DEFAULT_TTL_SECONDS",
]
