"""Snapshot serialisation helpers for ``ArchivableMixin``.

The snapshot pipeline is invoked from ``ArchivableMixin._create_snapshot``
after every ``save()`` / ``delete()`` / ``restore()``. We keep the
implementation in its own module so the mixin stays small and the
logic is easy to cover in isolation.

Design decisions:

- **Native JSONField.** We never go through ``json.dumps`` manually —
  the ``ArchiveVersion.serialized_data`` column is a ``models.JSONField``
  and Django is responsible for serialising dicts, lists, ints, strings,
  bools, and null. Non-JSON-safe values (``datetime``, ``Decimal``,
  ``UUID``) are normalised to ISO 8601 / strings here so the stored
  blob remains DB-neutral.
- **No foreign blobs.** Related objects referenced by a ForeignKey are
  stored by primary key only. ``Archive.follow_fk`` lets a plugin author
  opt into a richer representation (``{"pk": ..., "repr": ...}``) for
  referenced rows that are themselves archivable, but the snapshot
  never recursively serialises another model.
- **Excluded fields.** ``Archive.excluded_fields`` removes fields from
  the snapshot. Use sparingly — the Zero-Trust data pillar expects
  deterministic capture of all field values. Documented as an escape
  hatch for transient/derived fields, never for health-relevant data.
- **Atomic write.** ``ArchiveVersion`` and ``ArchiveRevisionMeta`` are
  created together inside ``transaction.atomic()`` so that a half-
  written revision can never appear in the audit trail.
"""

from __future__ import annotations

import datetime
import decimal
import uuid
from typing import Any

from django.contrib.contenttypes.models import ContentType
from django.db import transaction

from conjunto.archive.middleware import RevisionContext, get_current_context


def _json_safe(value: Any) -> Any:
    """Return a JSON-native representation of ``value``.

    Django's JSONField encoder handles dicts, lists, strings, ints,
    floats, bools and ``None`` natively. The remaining python-standard
    types we see in practice (``datetime``, ``date``, ``time``,
    ``Decimal``, ``UUID``, ``bytes``) we normalise here so the
    serialised blob is portable across DB backends and re-readable in
    pure python.

    ForeignKey values are never passed through here — the caller
    already extracted the PK via ``field.attname``.
    """
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
        return value.isoformat()
    if isinstance(value, decimal.Decimal):
        return str(value)
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, bytes):
        # Rare in archivable rows; hex-encode to keep the blob JSON-safe.
        return value.hex()
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    # Fallback: stringify. This is the rare path and deliberately lossy;
    # a plugin author that hits this should declare a custom encoder.
    return str(value)


def _archive_config(model) -> type:
    """Return the resolved ``Archive`` inner class of ``model``.

    Falls back to ``ArchivableMixin.Archive`` when the concrete model
    did not override it.
    """
    return getattr(model, "Archive", None) or type(
        "Archive", (), {"excluded_fields": [], "follow_fk": []}
    )


def _row_payload(instance) -> dict[str, Any]:
    """Serialise one archivable row to a JSON-safe dict.

    Rules:

    - Every concrete field is captured except ``row_version`` (a pure
      concurrency counter, not domain data) and anything listed in
      ``Archive.excluded_fields``.
    - ForeignKey fields are captured as ``{"pk": <id>}`` by default.
      Fields named in ``Archive.follow_fk`` are captured as
      ``{"pk": <id>, "repr": <str(related)>}`` so timeline UIs can
      show a human label without a DB round-trip.
    """
    model = type(instance)
    cfg = _archive_config(model)
    excluded = set(getattr(cfg, "excluded_fields", []) or [])
    follow = set(getattr(cfg, "follow_fk", []) or [])

    payload: dict[str, Any] = {}
    for field in model._meta.concrete_fields:
        if field.name in excluded:
            continue
        if field.name == "row_version":
            continue

        if field.is_relation and field.many_to_one:
            fk_id = getattr(instance, field.attname)
            if fk_id is None:
                payload[field.name] = None
                continue
            entry: dict[str, Any] = {"pk": _json_safe(fk_id)}
            if field.name in follow:
                related = getattr(instance, field.name, None)
                if related is not None:
                    entry["repr"] = str(related)
            payload[field.name] = entry
            continue

        # Plain scalar / text / JSON field.
        value = getattr(instance, field.attname, None)
        payload[field.name] = _json_safe(value)

    return payload


def _resolve_reason(requested: str | None, context: RevisionContext) -> str:
    """Pick the reason code to store, preferring the explicit caller value."""
    if requested:
        return requested
    if context.reason_code:
        return context.reason_code
    return "update"


def create_snapshot(
    instance,
    *,
    reason_code: str | None = None,
) -> object:
    """Write an ``ArchiveVersion`` + ``ArchiveRevisionMeta`` pair.

    Runs atomically. Returns the created ``ArchiveVersion`` for the
    rare caller that wants to chain (tests, admin views).
    """
    # Import inside the function to dodge the app-registry bootstrap —
    # ``conjunto.archive`` must stay import-safe before Django has set
    # up the ORM (see the note in ``conjunto.archive.__init__``).
    from conjunto.archive.models import ArchiveRevisionMeta, ArchiveVersion

    model = type(instance)
    ctx = get_current_context()
    schema_version = int(getattr(model, "archive_schema_version", 1))
    data = _row_payload(instance)

    with transaction.atomic():
        meta = ArchiveRevisionMeta.objects.create(
            user=ctx.user,
            tenant=ctx.tenant,
            reason_code=_resolve_reason(reason_code, ctx),
            comment=ctx.comment or "",
        )
        return ArchiveVersion.objects.create(
            content_type=ContentType.objects.get_for_model(model),
            object_id=str(instance.pk),
            serialized_data=data,
            schema_version=schema_version,
            revision_meta=meta,
        )


__all__ = ["create_snapshot"]
