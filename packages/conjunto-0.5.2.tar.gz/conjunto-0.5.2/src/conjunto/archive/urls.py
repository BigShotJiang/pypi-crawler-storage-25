"""URL configuration for ``conjunto.archive`` Phase-5 views.

Mounted from ``conjunto.urls`` under ``archive/`` so plugin projects
inherit the routes for free when they include ``conjunto.urls``.
"""

from __future__ import annotations

from django.urls import path

from conjunto.archive.views import (
    ArchiveRevertConfirmView,
    ArchiveRevertView,
    ArchiveTimelineView,
)

app_name = "conjunto_archive"

urlpatterns = [
    # Timeline for one archivable row, addressed by content type + pk.
    path(
        "timeline/<int:content_type_id>/<str:object_id>/",
        ArchiveTimelineView.as_view(),
        name="timeline",
    ),
    # Modal body for the revert confirmation.
    path(
        "revert/confirm/<int:version_pk>/",
        ArchiveRevertConfirmView.as_view(),
        name="revert-confirm",
    ),
    # POST-only revert apply handler.
    path(
        "revert/<int:version_pk>/",
        ArchiveRevertView.as_view(),
        name="revert",
    ),
]
