"""Register the ``revert`` reason code on ``ArchiveRevisionMeta``.

Phase 5 introduces ``ArchivableMixin.revert()``. Every successful
revert writes a fresh snapshot with ``reason_code='revert'`` so the
timeline shows the rollback as a first-class event. The choice list on
``ArchiveRevisionMeta.reason_code`` needs to grow by one entry — that
is what this migration records.
"""

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("conjunto_archive", "0001_initial"),
    ]

    operations = [
        migrations.AlterField(
            model_name="archiverevisionmeta",
            name="reason_code",
            field=models.CharField(
                choices=[
                    ("create", "Row created"),
                    ("update", "Row updated"),
                    ("soft_delete", "Row soft-deleted"),
                    ("restore", "Soft-delete reverted"),
                    ("revert", "Reverted to a historical snapshot"),
                    (
                        "hard_delete_precursor",
                        "Final snapshot before physical deletion",
                    ),
                ],
                max_length=32,
            ),
        ),
    ]
