"""``ArchiveRevisionMeta`` — Phase 2 user/tenant context for each snapshot.

Every ``ArchiveVersion`` row points at exactly one ``ArchiveRevisionMeta``
row, which records *who* caused the snapshot, *in which tenant context*,
and *why* (reason code). The meta row is append-only — any attempt to
``update()`` or ``delete()`` it, either through the queryset or at the
instance level, raises ``TamperEvidenceViolation``.

The user FK uses ``SET_NULL`` so historical revisions remain readable
even after the user is removed from the system. The tenant FK is
optional for models that are not tenant-scoped.
"""

from __future__ import annotations

from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _

from conjunto.archive.managers.append_only import (
    AppendOnlyManager,
    AppendOnlyModelMixin,
)


class ReasonCode(models.TextChoices):
    """Reason codes the snapshot pipeline writes on every revision.

    The enum is deliberately small — snapshots record ``what`` the row
    looked like; ``why`` is captured here at a coarse granularity.
    Free-form commentary lives in ``ArchiveRevisionMeta.comment``.
    """

    CREATE = "create", _("Row created")
    UPDATE = "update", _("Row updated")
    SOFT_DELETE = "soft_delete", _("Row soft-deleted")
    RESTORE = "restore", _("Soft-delete reverted")
    REVERT = "revert", _("Reverted to a historical snapshot")
    HARD_DELETE_PRECURSOR = (
        "hard_delete_precursor",
        _("Final snapshot before physical deletion"),
    )


def _tenant_model_setting() -> str:
    """Return the swappable tenant model path, with the conjunto default.

    Mirrors ``conjunto.tenants`` semantics — the FK resolves lazily so
    the archive app stays importable even if the consumer never declared
    ``CONJUNTO_TENANT_MODEL``.
    """
    return getattr(settings, "CONJUNTO_TENANT_MODEL", "conjunto_tenants.Tenant")


class ArchiveRevisionMeta(AppendOnlyModelMixin):
    """Who/which tenant/why for a single snapshot.

    Instances are created atomically together with an ``ArchiveVersion``
    row from ``ArchivableMixin._create_snapshot``. The one-to-one back
    relation lives on ``ArchiveVersion.revision_meta``.
    """

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
        help_text=_(
            "User who caused the revision. NULL for system-triggered "
            "snapshots (management commands, signals without a request)."
        ),
    )
    tenant = models.ForeignKey(
        _tenant_model_setting(),
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
        help_text=_(
            "Tenant in whose context the revision was created. NULL for "
            "non-tenant-scoped models or cross-tenant admin actions."
        ),
    )
    reason_code = models.CharField(
        max_length=32,
        choices=ReasonCode.choices,
    )
    comment = models.TextField(
        blank=True,
        default="",
        help_text=_("Optional free-form note from the caller."),
    )
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    objects = AppendOnlyManager()

    class Meta:
        app_label = "conjunto_archive"
        base_manager_name = "objects"
        indexes = [
            models.Index(fields=["-created_at"]),
            models.Index(fields=["user", "-created_at"]),
        ]
        default_permissions = ("view",)

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"RevisionMeta({self.reason_code}, {self.created_at:%Y-%m-%d %H:%M})"
