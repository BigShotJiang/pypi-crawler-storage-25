"""``ArchiveAccessLog`` — separate audit trail for archive-level reads.

§ 14 DSG (Austrian data-protection act) requires that access to audit
archives be itself auditable, on a separate log from the normal
application audit trail. Phase 1 ships a minimal skeleton so the
``AppendOnlyManager`` has a concrete table to protect; Phase 2 adds
``user`` / ``tenant`` / ``viewed_version`` / ``ip`` / ``purpose``
(dropdown) columns.
"""

from __future__ import annotations

from django.db import models

from conjunto.archive.managers.append_only import (
    AppendOnlyManager,
    AppendOnlyModelMixin,
)


class ArchiveAccessLog(AppendOnlyModelMixin):
    """Immutable record of access to archived rows.

    Append-only at both the manager and the instance level — code
    catching a ``TamperEvidenceViolation`` here is almost always a
    bug, not a recoverable error.
    """

    purpose = models.CharField(max_length=64)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    objects = AppendOnlyManager()

    class Meta:
        app_label = "conjunto_archive"
        base_manager_name = "objects"  # tamper-evidence on related-lookups too
        indexes = [models.Index(fields=["-created_at"])]
        default_permissions = ("view",)
