"""``DeletionLog`` — permanent record of every hard-delete.

One row is written by ``archive_cleanup`` / ``archive_reconcile`` / any
other path that physically deletes an archivable row. The log is the
sole remaining evidence a row ever existed after purge; it survives
the rows it describes.

All columns are immutable — :class:`AppendOnlyManager` + the
``AppendOnlyModelMixin`` refuse ``update()``, ``delete()`` and
save-after-PK at both queryset and instance level. Postgres-level
trigger protection is a v2 item (Blueprint §10.3).
"""

from __future__ import annotations

from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _

from conjunto.archive.managers.append_only import (
    AppendOnlyManager,
    AppendOnlyModelMixin,
)


def _tenant_model_setting() -> str:
    """Return the swappable tenant model path, with the conjunto default."""
    return getattr(settings, "CONJUNTO_TENANT_MODEL", "conjunto_tenants.Tenant")


class DeletionReason(models.TextChoices):
    """Why a row was physically deleted.

    Small closed enum — every hard-delete path in ``conjunto.archive``
    is one of these. Free-form explanation lives in ``triggered_by``.
    """

    RETENTION_EXPIRED = (
        "retention_expired",
        _("Retention window elapsed (scheduled cleanup)"),
    )
    MANUAL_HARD_DELETE = (
        "manual_hard_delete",
        _("Operator-initiated physical delete"),
    )
    TENANT_EXPORT_PURGE = (
        "tenant_export_purge",
        _("Tenant export completed; source data purged"),
    )
    RECONCILE_AFTER_RESTORE = (
        "reconcile_after_restore",
        _("Row reappeared after backup restore and was re-deleted"),
    )


class DeletionLog(AppendOnlyModelMixin):
    """Immutable record of a physical delete.

    Columns keep the row fully self-describing even after the source
    model is dropped: ``app_label`` + ``model_name`` survive
    ``ContentType`` churn and DB restores across schema changes.
    """

    # Model-identity fields. Stored as raw labels rather than an FK to
    # ContentType so a DeletionLog row stays readable after a model is
    # renamed, moved, or removed outright.
    app_label = models.CharField(
        max_length=100,
        help_text=_("App label of the deleted model at purge time."),
    )
    model_name = models.CharField(
        max_length=100,
        help_text=_("Model class name (<code>__name__</code>) of the deleted row."),
    )
    object_pk = models.CharField(
        max_length=64,
        help_text=_("Primary key of the deleted row, stringified."),
    )

    # Tenant link for tenant-scoped filtering in ``archive_reconcile`` —
    # nullable for global/system rows that never belonged to a tenant.
    tenant = models.ForeignKey(
        _tenant_model_setting(),
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
        help_text=_(
            "Tenant the deleted row belonged to, if any. SET_NULL so "
            "that historical DeletionLog entries outlive the tenant."
        ),
    )

    # Why the row was deleted — always one of DeletionReason.
    reason = models.CharField(
        max_length=32,
        choices=DeletionReason.choices,
        help_text=_("Reason enum for this deletion."),
    )

    # Who / what triggered the delete. Not a user FK — deletions run
    # under a command identity, not a user identity (see Zero-Trust
    # identity pillar: archive_cleanup is a system actor). Format:
    # ``"<command-name>:<instance-id>"`` or a similar free-form label.
    triggered_by = models.CharField(
        max_length=128,
        help_text=_(
            "Command or subsystem that triggered the delete, plus a "
            "run identifier. Format: '<command>:<run-id>'."
        ),
    )

    # Time the physical delete actually landed — distinct from
    # ``created_at`` in case the log is written asynchronously or
    # replayed from another source.
    deleted_at_final = models.DateTimeField(
        help_text=_("UTC timestamp of the physical delete."),
    )

    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    objects = AppendOnlyManager()

    class Meta:
        app_label = "conjunto_archive"
        base_manager_name = "objects"  # tamper-evidence on related-lookups too
        indexes = [
            models.Index(fields=["app_label", "model_name", "object_pk"]),
            models.Index(fields=["-created_at"]),
            models.Index(fields=["tenant", "-created_at"]),
            models.Index(fields=["reason", "-created_at"]),
        ]
        default_permissions = ("view",)

    def __str__(self) -> str:  # pragma: no cover - trivial
        return (
            f"DeletionLog({self.app_label}.{self.model_name}:{self.object_pk}, "
            f"reason={self.reason}, by={self.triggered_by})"
        )
