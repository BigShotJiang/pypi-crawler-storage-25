"""``ArchiveVersion`` — JSON snapshot of an archivable row.

One ``ArchiveVersion`` row is written for every ``save()`` / ``delete()``
/ ``restore()`` of an ``ArchivableMixin`` instance. The snapshot carries:

- ``content_type`` + ``object_id`` — a generic foreign key to the
  source row, with a ``CharField`` object_id so UUID-PK models are
  supported out of the box.
- ``serialized_data`` — a **native** ``JSONField``. Django maps this to
  Postgres ``JSONB`` and SQLite ``JSON1`` automatically; we never store
  the snapshot as serialised text.
- ``schema_version`` — ``archive_schema_version`` of the source model
  at snapshot time, so reverts across breaking schema evolutions can
  replay a migration chain (Phase 2 ships the chain; reverts land in
  Phase 4 of the revert UI).
- ``revision_meta`` — one-to-one link to the user / tenant / reason
  context captured at snapshot time.

Rows are append-only — ``ArchiveVersion.objects.update()`` /
``.delete()`` / ``.bulk_update()`` raise ``TamperEvidenceViolation``.
Instance-level ``save()`` after the PK is set is equally forbidden.
"""

from __future__ import annotations

from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models
from django.utils.translation import gettext_lazy as _

from conjunto.archive.managers.append_only import (
    AppendOnlyManager,
    AppendOnlyModelMixin,
)


class ArchiveVersion(AppendOnlyModelMixin):
    """Native-JSON snapshot of an archivable model instance.

    Schema choices the blueprint fixes in stone:

    - ``object_id`` is a ``CharField(64)``. It holds the source row's
      primary key as a string, regardless of whether the source uses
      integers, UUIDs, or composite keys. Integer-only ``object_id``
      was rejected to keep the door open for UUID-PK plugins without a
      future migration.
    - ``serialized_data`` is a native ``models.JSONField``. DB-neutral:
      maps to JSONB on Postgres, JSON1 on SQLite.
    - ``schema_version`` is copied from the source model's
      ``archive_schema_version`` class attribute at snapshot time; the
      revert path uses it to decide whether to run migrations.
    """

    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.PROTECT,
        related_name="+",
        help_text=_("Type of the archived model."),
    )
    object_id = models.CharField(
        max_length=64,
        help_text=_(
            "Primary key of the archived row, stringified. Supports "
            "integer, UUID, and composite keys."
        ),
    )
    content_object = GenericForeignKey("content_type", "object_id")

    serialized_data = models.JSONField(
        help_text=_(
            "Native JSONField snapshot of the row at the time of the "
            "triggering save/delete/restore."
        ),
    )
    schema_version = models.PositiveIntegerField(
        help_text=_(
            "Value of the source model's <code>archive_schema_version</code> at "
            "snapshot time. Drives the migration chain on revert."
        ),
    )
    revision_meta = models.OneToOneField(
        "conjunto_archive.ArchiveRevisionMeta",
        on_delete=models.PROTECT,
        related_name="archive_version",
        help_text=_("User / tenant / reason context for this revision."),
    )
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    objects = AppendOnlyManager()

    class Meta:
        app_label = "conjunto_archive"
        base_manager_name = "objects"
        indexes = [
            # Hot path: timeline view for one source row.
            models.Index(fields=["content_type", "object_id", "-created_at"]),
            # Hot path: retention cleanup scan.
            models.Index(fields=["-created_at"]),
        ]
        default_permissions = ("view",)

    def __str__(self) -> str:  # pragma: no cover - trivial
        return (
            f"ArchiveVersion({self.content_type_id}:{self.object_id} "
            f"v{self.schema_version} @ {self.created_at:%Y-%m-%d %H:%M})"
        )
