"""``ArchiveMigration`` — snapshot schema-evolution primitive.

A plugin model declares a list of migrations on its ``Archive`` inner
class, one per breaking schema change. At revert time, the chain is
applied in order from the snapshot's ``schema_version`` up to the
current ``archive_schema_version`` so that the caller sees the row
with today's field layout, regardless of when the snapshot was
written.

Example::

    class Invoice(ArchivableMixin, models.Model):
        total = models.DecimalField(max_digits=12, decimal_places=2)

        archive_schema_version = 2

        class Archive:
            archive_migrations = [
                ArchiveMigration(
                    from_version=1,
                    to_version=2,
                    migrate_fn=lambda d: {**d, "total": d.pop("amount", 0)},
                ),
            ]

On startup, ``validate_migration_chain`` ensures every model whose
``archive_schema_version`` is > 1 has a gap-free chain from 1 up to its
current version. A gap raises ``ImproperlyConfigured`` so the problem
is visible at deployment time, not during the first revert attempt.
"""

from __future__ import annotations

import dataclasses
from typing import Callable, Iterable

from django.core.exceptions import ImproperlyConfigured

from conjunto.archive.exceptions import ArchiveMigrationError

Snapshot = dict
"""Type alias for a snapshot payload (pre-/post-migration)."""


@dataclasses.dataclass(frozen=True)
class ArchiveMigration:
    """One step in a snapshot schema-migration chain.

    ``migrate_fn`` must be pure: it takes the snapshot dict and returns
    a new dict (callers should not mutate input). Side effects (DB
    writes, network calls) are forbidden — the migration pipeline may
    run repeatedly on the same snapshot during a revert preview.
    """

    from_version: int
    to_version: int
    migrate_fn: Callable[[Snapshot], Snapshot]

    def __post_init__(self) -> None:
        if self.to_version <= self.from_version:
            raise ValueError(
                f"ArchiveMigration must advance version: "
                f"from_version={self.from_version} "
                f"to_version={self.to_version}"
            )


def validate_migration_chain(
    migrations: Iterable[ArchiveMigration],
    current_version: int,
    *,
    model_label: str = "<unknown>",
) -> None:
    """Raise ``ImproperlyConfigured`` if the chain has a gap.

    The chain is valid iff, starting from version 1, every version
    between 1 and ``current_version`` appears as the ``from_version`` of
    exactly one migration (with matching ``to_version = from_version + 1``
    — we only support single-step migrations; composite steps have to be
    decomposed by the plugin author to keep revert logic predictable).
    """
    if current_version <= 1:
        # Nothing to migrate, nothing to validate.
        return

    # Index by from_version; reject duplicates.
    by_from: dict[int, ArchiveMigration] = {}
    for m in migrations:
        if m.from_version in by_from:
            raise ImproperlyConfigured(
                f"{model_label}: duplicate archive migration from "
                f"version {m.from_version}."
            )
        by_from[m.from_version] = m

    for v in range(1, current_version):
        m = by_from.get(v)
        if m is None:
            raise ImproperlyConfigured(
                f"{model_label}: missing archive migration from "
                f"version {v} to {v + 1}. "
                f"archive_schema_version is {current_version}; every "
                f"step must be covered."
            )
        if m.to_version != v + 1:
            raise ImproperlyConfigured(
                f"{model_label}: archive migration from {v} jumps to "
                f"{m.to_version}; only single-step migrations are "
                f"supported (expected to_version={v + 1})."
            )


def apply_migrations(
    snapshot: Snapshot,
    *,
    from_version: int,
    to_version: int,
    migrations: Iterable[ArchiveMigration],
) -> Snapshot:
    """Replay the chain from ``from_version`` to ``to_version``.

    Raises ``ArchiveMigrationError`` if a required step is missing from
    the passed-in list (``validate_migration_chain`` should have caught
    this at startup, but the runtime check is cheap insurance against a
    consumer that skipped the validator).
    """
    if from_version == to_version:
        return dict(snapshot)
    if to_version < from_version:
        raise ArchiveMigrationError(
            f"Cannot migrate backwards: from_version={from_version} "
            f"to_version={to_version}"
        )

    by_from: dict[int, ArchiveMigration] = {m.from_version: m for m in migrations}

    data = dict(snapshot)
    v = from_version
    while v < to_version:
        step = by_from.get(v)
        if step is None or step.to_version != v + 1:
            raise ArchiveMigrationError(
                f"Missing migration from version {v} to {v + 1}."
            )
        data = step.migrate_fn(data)
        v += 1
    return data
