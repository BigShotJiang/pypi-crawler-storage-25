"""Schema-evolution primitives for ``conjunto.archive`` snapshots.

Plugin authors declare an ``archive_migrations`` list on their model's
``Archive`` inner class whenever ``archive_schema_version`` is bumped.
The list is validated at app-ready time and applied on revert to an
older snapshot.
"""

from conjunto.archive.schema.migration import (
    ArchiveMigration,
    apply_migrations,
    validate_migration_chain,
)

__all__ = [
    "ArchiveMigration",
    "apply_migrations",
    "validate_migration_chain",
]
