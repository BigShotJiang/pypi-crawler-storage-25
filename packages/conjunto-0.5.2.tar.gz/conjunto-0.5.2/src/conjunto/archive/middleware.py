"""Revision context middleware + contextvar-backed accessor.

``RevisionContextMiddleware`` captures the authenticated user and the
current tenant from every incoming request into a ``contextvars`` slot
that the snapshot pipeline reads at the moment a snapshot is written.
``contextvars`` (not ``threading.local``) because Django 6 can run
views under async, and ``contextvars`` propagate correctly across
``async`` and ``sync_to_async`` boundaries.

For non-web contexts — management commands, scheduled jobs,
background tasks — a ``revision_context(...)`` context manager sets the
same slot explicitly.

HTMX is specifically accounted for: ``HX-Request`` headers do not
change the middleware path. Django invokes the middleware once per
request (including partial HTMX swaps), so the user/tenant are
refreshed on every fragment round-trip.
"""

from __future__ import annotations

import contextlib
import contextvars
import dataclasses
from typing import Iterator


@dataclasses.dataclass(frozen=True)
class RevisionContext:
    """Immutable snapshot of the currently active revision context.

    All three slots may be ``None`` — that is the "system-triggered"
    case (shell, early-startup signals, tests without a request).
    Snapshot code must handle the null path cleanly.
    """

    user: object | None = None
    tenant: object | None = None
    reason_code: str | None = None
    comment: str = ""


_EMPTY = RevisionContext()

_current_context: contextvars.ContextVar[RevisionContext] = contextvars.ContextVar(
    "conjunto_archive_revision_context", default=_EMPTY
)


def get_current_context() -> RevisionContext:
    """Return the currently active ``RevisionContext`` (possibly empty)."""
    return _current_context.get()


def _resolve_user(request):
    """Return the authenticated user from ``request`` or ``None``.

    The middleware defers user access until the snapshot pipeline reads
    it — lazy evaluation of ``request.user`` is fine here.
    """
    user = getattr(request, "user", None)
    if user is None:
        return None
    is_auth = getattr(user, "is_authenticated", False)
    return user if is_auth else None


def _resolve_tenant(request):
    """Return the active tenant from the request, or ``None``.

    Conjunto binds the tenant via ``conjunto.tenants`` middleware as
    ``request.tenant`` (see ``TenantMiddleware``). Archive middleware
    must be placed *after* the tenant middleware in settings so the
    attribute is already populated.
    """
    return getattr(request, "tenant", None)


class RevisionContextMiddleware:
    """Populate the revision context for the lifetime of one request.

    Usage in ``settings.MIDDLEWARE``::

        MIDDLEWARE = [
            ...,
            "conjunto.tenants.middleware.TenantMiddleware",
            "conjunto.archive.middleware.RevisionContextMiddleware",
            ...,
        ]

    Ordering matters: the tenant middleware must run first so
    ``request.tenant`` is set by the time the archive middleware
    captures it.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        context = RevisionContext(
            user=_resolve_user(request),
            tenant=_resolve_tenant(request),
            reason_code=None,
            comment="",
        )
        token = _current_context.set(context)
        try:
            return self.get_response(request)
        finally:
            _current_context.reset(token)


@contextlib.contextmanager
def revision_context(
    *,
    user=None,
    tenant=None,
    reason_code: str | None = None,
    comment: str = "",
) -> Iterator[RevisionContext]:
    """Explicit context manager for non-web callers.

    Use this in management commands, Celery tasks, shell sessions, or
    any other code path that is not served by the request middleware::

        with revision_context(user=admin, reason_code="bulk_import"):
            for row in rows:
                row.save()
    """
    ctx = RevisionContext(
        user=user,
        tenant=tenant,
        reason_code=reason_code,
        comment=comment,
    )
    token = _current_context.set(ctx)
    try:
        yield ctx
    finally:
        _current_context.reset(token)


__all__ = [
    "RevisionContext",
    "RevisionContextMiddleware",
    "get_current_context",
    "revision_context",
]
