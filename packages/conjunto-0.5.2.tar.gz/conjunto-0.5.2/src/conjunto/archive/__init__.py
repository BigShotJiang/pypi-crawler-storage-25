"""conjunto.archive - versioned archive, soft-delete and retention subsystem.

Phase 1 (Eigenbau):
    - ``ArchivableMixin`` — soft-delete + optimistic locking + cascade.
    - ``CascadePolicy`` — five policies (three user-facing, two retention-only).
    - ``StaleObjectError`` — raised on ``row_version`` conflicts.
    - ``AppendOnlyManager`` — tamper-evidence guard for log tables.
    - ``ArchiveAccessLog``, ``DeletionLog`` — append-only log skeletons.
    - ``RetentionToken`` — Zero-Trust gate for ``hard_delete()``.

Phase 2 will add ``ArchiveVersion`` / ``ArchiveRevisionMeta`` (JSON
snapshot), ``RevisionContextMiddleware``, and schema-migration chains.
See ``Specs/conjunto/archive-implementation-plan.md``.

Import-time notes:
    - This package MUST NOT import any Django model at import time.
      Models live under ``.models.*`` and are picked up by the app
      registry. Model classes (``ArchivableMixin``, ``CascadePolicy``
      enum) are re-exported via ``__getattr__`` below so callers see
      the usual flat namespace without triggering a model import
      before Django's app registry is ready.
"""

from conjunto.archive.exceptions import (
    ArchiveError,
    ArchiveMigrationError,
    RetentionFloorViolation,
    StaleObjectError,
    TamperEvidenceViolation,
)

default_app_config = "conjunto.archive.apps.ConjuntoArchiveConfig"

__all__ = [
    "ArchivableMixin",
    "ArchiveError",
    "ArchiveMigrationError",
    "CascadePolicy",
    "RetentionFloorViolation",
    "StaleObjectError",
    "TamperEvidenceViolation",
    "TemporalMixin",
]


def __getattr__(name):
    """Lazy re-export of model-backed symbols.

    ``ArchivableMixin``, ``TemporalMixin`` and ``CascadePolicy`` live in
    ``conjunto.archive.mixins`` but are exposed as top-level names.
    Defer the actual import until Django's app registry has finished
    populating so that importing ``conjunto.archive`` from
    ``INSTALLED_APPS`` does not trip ``AppRegistryNotReady``.
    """
    if name == "ArchivableMixin":
        from conjunto.archive.mixins import ArchivableMixin

        return ArchivableMixin
    if name == "CascadePolicy":
        from conjunto.archive.mixins import CascadePolicy

        return CascadePolicy
    if name == "TemporalMixin":
        from conjunto.archive.mixins import TemporalMixin

        return TemporalMixin
    raise AttributeError(f"module 'conjunto.archive' has no attribute {name!r}")
