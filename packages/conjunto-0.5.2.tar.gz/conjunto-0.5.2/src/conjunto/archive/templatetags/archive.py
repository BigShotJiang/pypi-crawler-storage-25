"""Template tags for ``conjunto.archive``.

Usage::

    {% load archive %}
    ...
    {% archive_timeline instance %}

The ``archive_timeline`` inclusion tag renders the full timeline body
for an archivable instance directly into the template. It takes care of
pulling the ``ArchiveVersion`` queryset and shaping it the way the
partial expects, so plugin detail pages can embed the history with a
single line.
"""

from __future__ import annotations

from django import template
from django.contrib.contenttypes.models import ContentType

from conjunto.archive.mixins.archivable import ArchivableMixin
from conjunto.archive.models import ArchiveVersion

register = template.Library()


@register.inclusion_tag("archive/_timeline.html", takes_context=True)
def archive_timeline(context, instance):
    """Inline-render the revision timeline for ``instance``.

    ``instance`` must be an ``ArchivableMixin`` subclass instance with a
    set primary key. When the instance has no archive history (legacy
    rows created before the archive app shipped), the partial renders
    the "no archive history" banner.

    Raises:
        TypeError: if ``instance`` is not an ``ArchivableMixin`` subclass.
    """
    if not isinstance(instance, ArchivableMixin):
        raise TypeError(
            "archive_timeline expects an ArchivableMixin instance, "
            f"got {type(instance).__name__}"
        )

    ct = ContentType.objects.get_for_model(type(instance))
    versions = (
        ArchiveVersion.objects.filter(content_type=ct, object_id=str(instance.pk))
        .select_related("revision_meta", "revision_meta__user")
        .order_by("-created_at")
    )
    return {
        "archive_instance": instance,
        "archive_versions": versions,
        "archive_has_versions": versions.exists(),
        # Propagate request / csrf_token etc. for the partial.
        "request": context.get("request"),
        "csrf_token": context.get("csrf_token"),
    }
