"""Optimistic locking helpers for ``ArchivableMixin``.

Phase 1 isolates the atomic compare-and-swap UPDATE in one place so
the mixin stays readable. The actual save-time plumbing lives in
``ArchivableMixin.save()``.
"""

from __future__ import annotations

from typing import Iterable

from django.db import router, transaction

from conjunto.archive.exceptions import StaleObjectError


def compare_and_swap(
    instance,
    *,
    update_fields: Iterable[str] | None,
) -> int:
    """Atomic UPDATE ... WHERE row_version = <loaded>.

    Returns the newly persisted ``row_version`` on success; raises
    ``StaleObjectError`` if zero rows matched (another writer bumped
    the version in between load and save).

    The caller is responsible for:

    - having ``instance.pk`` set (this is never called on INSERT),
    - having already mutated ``instance`` fields in memory,
    - bumping ``row_version`` AFTER we confirm the UPDATE landed.
    """
    expected = instance.row_version
    new_version = expected + 1
    model = type(instance)
    using = router.db_for_write(model, instance=instance)

    # Build the update dict. If the caller provided ``update_fields``,
    # honour it (plus row_version), otherwise write every concrete field
    # except the pk and row_version (which we set separately).
    values: dict[str, object] = {}
    if update_fields is not None:
        for name in update_fields:
            if name == "row_version":
                continue
            values[name] = getattr(instance, model._meta.get_field(name).attname)
    else:
        for field in model._meta.concrete_fields:
            if field.primary_key:
                continue
            if field.name == "row_version":
                continue
            values[field.attname] = getattr(instance, field.attname)

    values["row_version"] = new_version

    with transaction.atomic(using=using):
        affected = (
            model._base_manager.using(using)
            .filter(pk=instance.pk, row_version=expected)
            .update(**values)
        )

    if affected == 0:
        raise StaleObjectError(model, instance.pk, expected)

    instance.row_version = new_version
    return new_version
