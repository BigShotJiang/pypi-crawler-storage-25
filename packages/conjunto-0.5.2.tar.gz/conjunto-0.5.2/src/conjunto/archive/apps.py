"""Django AppConfig for ``conjunto.archive``.

Phase 2 hooks in:
- model imports (so the append-only log tables are registered),
- the ``archive_migrations``-chain validator, which runs over every
  discovered ``ArchivableMixin`` subclass and raises at deployment time
  if the chain is incomplete.
"""

from __future__ import annotations

from django.apps import AppConfig


class ConjuntoArchiveConfig(AppConfig):
    name = "conjunto.archive"
    label = "conjunto_archive"
    verbose_name = "Conjunto Archive"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self) -> None:
        # Importing models here ensures the append-only log tables are
        # registered even when the package is imported before Django
        # fully populates its app registry.
        from conjunto.archive import models as _models  # noqa: F401

        self._validate_archive_migration_chains()

    # ------------------------------------------------------------------ #
    # Startup validator
    # ------------------------------------------------------------------ #
    def _validate_archive_migration_chains(self) -> None:
        """Enforce gap-free ``archive_migrations`` for every archivable model.

        The validator walks every installed model, picks the ones that
        inherit from ``ArchivableMixin`` with ``archive_schema_version``
        above 1, and delegates the per-model check to
        ``conjunto.archive.schema.validate_migration_chain``. Any gap
        raises ``ImproperlyConfigured`` so the deployment fails at
        startup rather than on the first revert attempt.
        """
        from django.apps import apps

        from conjunto.archive.mixins import ArchivableMixin
        from conjunto.archive.schema import validate_migration_chain

        for model in apps.get_models():
            if not issubclass(model, ArchivableMixin):
                continue
            current = int(getattr(model, "archive_schema_version", 1))
            if current <= 1:
                continue
            archive_cls = getattr(model, "Archive", None)
            migrations = getattr(archive_cls, "archive_migrations", None) or []
            validate_migration_chain(
                migrations,
                current_version=current,
                model_label=f"{model._meta.app_label}.{model.__name__}",
            )
