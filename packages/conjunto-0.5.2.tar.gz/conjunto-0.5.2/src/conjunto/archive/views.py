"""Phase 5 views: timeline, revert-confirmation modal, revert-apply.

Three class-based views serve the UI-side of ``conjunto.archive``:

1. ``ArchiveTimelineView`` — renders the chronological list of
   ``ArchiveVersion`` entries for a single archivable row, wrapped in a
   Tabler card. Pulls via HTMX or full-page equally well.
2. ``ArchiveRevertConfirmView`` — returns the revert-confirmation
   modal body, meant to be swapped into the shared ``#dialog`` target.
3. ``ArchiveRevertView`` — POST handler that validates permissions,
   calls ``instance.revert(to_version)``, and either emits a toast +
   ``HX-Redirect`` back to the caller on success, or renders the
   stale-conflict / unrevertable partial on failure.

Permission gating:

- Timeline + confirm views require authentication only.
- Revert apply additionally requires the user to hold the ``change_<model>``
  Django permission on the source model, which covers Conjunto's
  ``tenant_admin`` role and any custom role that has been granted the
  change permission for the specific archivable type. Plugin projects
  that need finer-grained gating can subclass the view and override
  ``has_revert_permission``.

Zero-Trust touch-points:

- CSRF is Django-standard via the ``conjunto/base.html`` body-level
  ``hx-headers``. No view disables it.
- ``row_version`` flows through ``ArchivableMixin.revert()`` → any
  parallel writer triggers ``StaleObjectError`` which this layer
  converts into a 409 + ``_stale_conflict.html`` partial.
- The content-type / object-id pair is looked up defensively — the
  view raises 404 on a mismatch rather than trusting the caller's URL
  segment.
"""

from __future__ import annotations

from typing import Any

from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.contenttypes.models import ContentType
from django.http import (
    Http404,
    HttpResponse,
    HttpResponseForbidden,
    HttpResponseNotAllowed,
)
from django.shortcuts import render
from django.urls import reverse
from django.utils.translation import gettext as _
from django.views import View
from django.views.generic import TemplateView
from django_htmx.http import trigger_client_event

from conjunto.archive.exceptions import (
    StaleObjectError,
    UnrevertableVersionError,
)
from conjunto.archive.mixins.archivable import ArchivableMixin
from conjunto.archive.models import ArchiveVersion


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #


def _resolve_instance_from_ct(content_type_id: int | str, object_id: str):
    """Return the ``ArchivableMixin`` instance the URL points at.

    Raises ``Http404`` on any mismatch — the content type must exist,
    the target model class must subclass ``ArchivableMixin``, and the
    primary key must resolve.
    """
    try:
        ct = ContentType.objects.get_for_id(int(content_type_id))
    except (ContentType.DoesNotExist, ValueError, TypeError) as exc:
        raise Http404("Unknown content type") from exc

    model = ct.model_class()
    if model is None or not issubclass(model, ArchivableMixin):
        raise Http404("Content type is not archivable")

    # Use all_objects so the timeline is visible on soft-deleted rows too.
    manager = getattr(model, "all_objects", model._default_manager)
    try:
        return manager.get(pk=object_id)
    except model.DoesNotExist as exc:
        raise Http404(f"{model.__name__}(pk={object_id}) not found") from exc


def _get_version_or_404(version_pk):
    """Look up an ``ArchiveVersion`` with related FKs in one query."""
    try:
        return ArchiveVersion.objects.select_related(
            "revision_meta", "content_type"
        ).get(pk=version_pk)
    except ArchiveVersion.DoesNotExist as exc:
        raise Http404(f"ArchiveVersion(pk={version_pk}) not found") from exc


def _has_change_permission(user, instance) -> bool:
    """Return True if ``user`` may edit ``instance``.

    We gate on the model's ``change_<model>`` permission. Superusers
    pass; unauthenticated users fail. Conjunto's ``tenant_admin`` role
    holds the change permission for tenant-scoped archivable models by
    default (see ``conjunto.tenants.roles``).
    """
    if user is None or not getattr(user, "is_authenticated", False):
        return False
    if getattr(user, "is_superuser", False):
        return True
    opts = type(instance)._meta
    return user.has_perm(f"{opts.app_label}.change_{opts.model_name}")


# --------------------------------------------------------------------------- #
# Views
# --------------------------------------------------------------------------- #


class ArchiveTimelineView(LoginRequiredMixin, TemplateView):
    """Render the archive timeline for a single archivable row.

    URL: ``archive/timeline/<int:content_type_id>/<str:object_id>/``

    HTMX-aware — the view returns the same partial body regardless of
    request type, wrapped into a Tabler card. Callers embed it via the
    ``{% archive_timeline instance %}`` template tag for the simple
    case; HTMX swaps land on the ``#archive-timeline-<pk>`` target.
    """

    template_name = "archive/timeline.html"

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        context = super().get_context_data(**kwargs)
        instance = _resolve_instance_from_ct(
            self.kwargs["content_type_id"],
            self.kwargs["object_id"],
        )
        context["archive_instance"] = instance
        context["archive_versions"] = self._versions_for(instance)
        context["archive_has_versions"] = context["archive_versions"].exists()
        return context

    @staticmethod
    def _versions_for(instance):
        ct = ContentType.objects.get_for_model(type(instance))
        return (
            ArchiveVersion.objects.filter(content_type=ct, object_id=str(instance.pk))
            .select_related("revision_meta", "revision_meta__user")
            .order_by("-created_at")
        )


class ArchiveRevertConfirmView(LoginRequiredMixin, TemplateView):
    """Render the revert-confirmation modal body for one version.

    URL: ``archive/revert/confirm/<int:version_pk>/``

    The confirm view returns the body that replaces ``#dialog`` on the
    caller's page; the form posts back to :class:`ArchiveRevertView`.
    Only users with change-permission on the source model see an
    actionable submit button — others see a forbidden notice.
    """

    template_name = "archive/_revert_modal.html"

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        context = super().get_context_data(**kwargs)
        version = _get_version_or_404(self.kwargs["version_pk"])
        instance = _resolve_instance_from_ct(version.content_type_id, version.object_id)
        context["archive_version"] = version
        context["archive_instance"] = instance
        context["revert_url"] = reverse("conjunto_archive:revert", args=[version.pk])
        context["has_permission"] = _has_change_permission(self.request.user, instance)
        return context


class ArchiveRevertView(LoginRequiredMixin, View):
    """POST-only handler that applies a revert.

    URL: ``archive/revert/<int:version_pk>/``

    On success: emits ``HX-Trigger: showToast`` plus ``HX-Redirect``
    back to the referrer (or the timeline view) so the caller's page
    rebuilds with the reverted data.

    On ``StaleObjectError``: returns the stale-conflict partial with
    HTTP 409 so HTMX swaps it into the dialog target.

    On ``UnrevertableVersionError``: returns the unrevertable partial
    with HTTP 422.
    """

    http_method_names = ["post"]

    def post(self, request, *args, **kwargs):
        if request.method != "POST":  # belt-and-braces, Django routes POST here
            return HttpResponseNotAllowed(["POST"])

        version = _get_version_or_404(self.kwargs["version_pk"])
        instance = _resolve_instance_from_ct(version.content_type_id, version.object_id)

        if not _has_change_permission(request.user, instance):
            return HttpResponseForbidden(
                _("You do not have permission to revert this record.")
            )

        try:
            instance.revert(version, user=request.user)
        except StaleObjectError:
            return render(
                request,
                "archive/_stale_conflict.html",
                {"archive_instance": instance},
                status=409,
            )
        except UnrevertableVersionError as exc:
            return render(
                request,
                "archive/_unrevertable.html",
                {
                    "archive_instance": instance,
                    "archive_version": version,
                    "error_message": str(exc),
                },
                status=422,
            )

        # Success path — emit a toast + client-side redirect to refresh
        # the caller's page with the reverted data. We fall back to the
        # timeline view itself if no referrer is available.
        redirect_url = request.META.get("HTTP_REFERER") or self._timeline_url_for(
            instance
        )
        response = HttpResponse(status=204)
        trigger_client_event(
            response,
            "showToast",
            params={
                "message": _("Reverted to the version from %(date)s.")
                % {"date": version.created_at.strftime("%Y-%m-%d %H:%M")},
                "type": "success",
            },
        )
        response["HX-Redirect"] = redirect_url
        return response

    @staticmethod
    def _timeline_url_for(instance) -> str:
        ct = ContentType.objects.get_for_model(type(instance))
        return reverse("conjunto_archive:timeline", args=[ct.pk, str(instance.pk)])


__all__ = [
    "ArchiveTimelineView",
    "ArchiveRevertConfirmView",
    "ArchiveRevertView",
]
