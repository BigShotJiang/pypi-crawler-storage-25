"""Exceptions raised by ``conjunto.archive``.

These are the public error types Phase 1 introduces. Downstream plugin
code catches them; the mixins and managers raise them.
"""

from __future__ import annotations

from django.utils.translation import gettext_lazy as _


class ArchiveError(Exception):
    """Base class for every exception raised by ``conjunto.archive``."""


class StaleObjectError(ArchiveError):
    """Raised when an optimistic-lock ``save()`` hits a stale ``row_version``.

    The caller loaded a row, another writer updated it in between, and
    the UPDATE ... WHERE row_version = <old> affected zero rows.
    Recovery strategy: reload, merge, retry.
    """

    default_message = _(
        "This record was modified by someone else. Please reload and retry."
    )

    def __init__(self, model, pk, expected_version):
        self.model = model
        self.pk = pk
        self.expected_version = expected_version
        super().__init__(
            f"Stale {model.__name__} pk={pk}: expected row_version="
            f"{expected_version}, but database row moved on."
        )


class TamperEvidenceViolation(ArchiveError):
    """Raised when code tries to mutate or delete an append-only row.

    Protects ``ArchiveAccessLog``, ``DeletionLog``, ``ArchiveVersion``
    (Phase 2), and ``ArchiveRevisionMeta`` (Phase 2). These tables are
    the audit trail — the whole point is that app-level code cannot
    tamper with them.
    """


class RetentionFloorViolation(ArchiveError):
    """Raised when a retention override tries to dig under the hard floor."""


class ArchiveMigrationError(ArchiveError):
    """Raised when snapshot schema-migration chain is incomplete (Phase 2)."""


class UnrevertableVersionError(ArchiveError):
    """Raised when an ``ArchiveVersion`` cannot be applied back onto its row.

    Causes:

    - A required migration step between the snapshot's ``schema_version``
      and the model's current ``archive_schema_version`` is missing.
    - The snapshot references a field that no longer exists on the
      model and is not remapped by any migration step.
    - The snapshot originates from a different content type.

    Callers should catch this and surface a ``_stale_conflict.html``-
    style partial, or a plain 409 response — the revert cannot proceed
    until the chain is closed.
    """

    default_message = _(
        "This archived version cannot be applied to the current schema."
    )
