"""Managers and querysets for ``TemporalMixin``.

Manager strategy — finalised in blueprint v6.1 as **Option C**:

- ``Model.objects`` is the default manager and returns **every** row
  (current + historical + archived). Django-conform, transparent, no
  hidden filter. Historic query helpers (``.at``, ``.history_for``,
  ``.valid_between``) live on this manager's queryset because they
  operate on the full history.
- ``Model.current`` is a second manager, pre-filtered to
  ``valid_to__isnull=True`` AND ``archived=False``. It exposes the
  plain ``QuerySet`` API (no historic helpers) — filtering a single
  slice-in-time through ``.at(date)`` would be misleading.

Rationale: for ``TemporalMixin`` every version is legitimate data
(an invoice from 2024 referring to the old last name is correct, not a
bug). A default manager that implicitly filters would cause rows to
"disappear" and hide the history from naive queries — the opposite of
the invariant we need.
"""

from __future__ import annotations

from datetime import date as _date

from django.db import models
from django.db.models import Q


class TemporalQuerySet(models.QuerySet):
    """QuerySet with historic query helpers.

    Semantics:

    - ``valid_from`` is inclusive: the row is valid *from* this day on.
    - ``valid_to`` is inclusive on its last day: the row is valid
      *through* this day. ``NULL`` means "no end".
    - A row is considered active at date ``D`` iff
      ``valid_from <= D AND (valid_to IS NULL OR valid_to >= D)``.
    """

    def at(self, when: _date) -> "TemporalQuerySet":
        """Return rows valid on the given date (inclusive)."""
        return self.filter(
            Q(valid_to__isnull=True) | Q(valid_to__gte=when),
            valid_from__lte=when,
        )

    def valid_between(self, start: _date, end: _date) -> "TemporalQuerySet":
        """Return rows whose validity range overlaps ``[start, end]``.

        A row overlaps iff its ``valid_from`` is on or before ``end``
        AND its ``valid_to`` is either NULL (open-ended) or on/after
        ``start``.
        """
        return self.filter(
            Q(valid_to__isnull=True) | Q(valid_to__gte=start),
            valid_from__lte=end,
        )

    def history_for(self, **lookups) -> "TemporalQuerySet":
        """Return the full history matching ``lookups``, chronologically.

        Typical use::

            PatientName.objects.history_for(patient=some_patient)

        Sorted by ``valid_from`` ascending. Includes archived rows —
        the caller explicitly asked for history.
        """
        return self.filter(**lookups).order_by("valid_from")


class TemporalManager(models.Manager.from_queryset(TemporalQuerySet)):
    """Default manager for temporal models — sees every row."""


class CurrentOnlyManager(models.Manager):
    """Pre-filtered manager that exposes only the currently active row.

    "Currently active" means ``valid_to IS NULL`` and ``archived =
    False``. The manager deliberately uses the plain ``Manager`` base
    rather than ``TemporalManager`` — the ``.at`` / ``.history_for`` /
    ``.valid_between`` helpers would be misleading on a slice-in-time
    view of the data.
    """

    def get_queryset(self) -> models.QuerySet:
        return super().get_queryset().filter(valid_to__isnull=True, archived=False)


__all__ = [
    "CurrentOnlyManager",
    "TemporalManager",
    "TemporalQuerySet",
]
