"""Append-only manager for audit/log models.

``ArchiveAccessLog``, ``DeletionLog``, ``ArchiveVersion``, and
``ArchiveRevisionMeta`` are append-only by contract. Any attempt to
mutate or delete rows through the ORM raises
``TamperEvidenceViolation``.

Phase 4 introduces one controlled escape hatch:
:meth:`AppendOnlyQuerySet.retention_purge` accepts a valid
``RetentionToken`` and performs a privileged DELETE that bypasses the
tamper-evidence guard. Its sole legitimate caller is the
``archive_cleanup`` command when physically removing an archivable
row together with all of its ``ArchiveVersion`` rows — the retention
window has elapsed, and the log rows by definition cease to apply
when the source row is gone.

This is the Phase-1, DB-agnostic guard. v2 of the blueprint layers a
Postgres trigger on top so even raw SQL cannot tamper.
"""

from __future__ import annotations

import contextlib
import contextvars
from typing import Iterator

from django.db import models

from conjunto.archive.exceptions import TamperEvidenceViolation


# Contextvar flag that :func:`privileged_purge` flips while a single
# retention-purge "unit of work" is running. The unit of work starts
# by consuming a RetentionToken via ``validate_or_raise()`` and ends
# when the context manager exits. Inside, :meth:`AppendOnlyQuerySet.retention_purge`
# allows DELETE; outside, it raises ``PermissionError``.
_purge_active: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "conjunto_archive_purge_active", default=False
)


@contextlib.contextmanager
def privileged_purge(*, retention_token) -> Iterator[None]:
    """Open a privileged purge scope for one retention unit of work.

    The caller passes the :class:`RetentionToken` that authorises this
    scope. The token is **consumed** at the top of the context (the
    single-use property fires once per purge, not once per row), and
    the contextvar flag is set so ``retention_purge`` queryset calls
    inside the ``with`` block are allowed.

    One scope = one logical hard-delete (source row + its
    ``ArchiveVersion`` rows + their ``ArchiveRevisionMeta`` rows + the
    ``DeletionLog`` write). Callers that need to purge another row
    must issue a new token and open a fresh scope.

    Raises ``PermissionError`` if the token is missing, expired, from
    another process, or already consumed.
    """
    # Lazy import to avoid circular dep at package bootstrap.
    from conjunto.archive.retention.token import RetentionToken

    if not isinstance(retention_token, RetentionToken):
        raise PermissionError(
            "privileged_purge requires a RetentionToken instance; "
            f"got {type(retention_token).__name__}."
        )
    retention_token.validate_or_raise()
    flag = _purge_active.set(True)
    try:
        yield
    finally:
        _purge_active.reset(flag)


def _is_purge_context_active() -> bool:
    """Return True iff a privileged purge scope is currently open."""
    return _purge_active.get()


class AppendOnlyQuerySet(models.QuerySet):
    """QuerySet that refuses to perform updates or deletes."""

    def update(self, **kwargs):
        raise TamperEvidenceViolation(
            f"{self.model.__name__} is append-only; .update() is forbidden."
        )

    def bulk_update(self, objs, fields, batch_size=None):
        raise TamperEvidenceViolation(
            f"{self.model.__name__} is append-only; .bulk_update() is forbidden."
        )

    def delete(self):
        raise TamperEvidenceViolation(
            f"{self.model.__name__} is append-only; .delete() is forbidden."
        )

    def retention_purge(self) -> int:
        """Privileged DELETE path for retention cleanup.

        Only callable inside an open :func:`privileged_purge` scope
        (which itself requires a valid :class:`RetentionToken` at
        entry). Outside that scope, raises ``PermissionError``.

        Returns the number of rows Django's DELETE actually removed.

        CAUTION: this is the one legitimate tamper-evidence bypass.
        Every other caller MUST go through ``.delete()`` and receive a
        ``TamperEvidenceViolation``.
        """
        if not _is_purge_context_active():
            raise PermissionError(
                "retention_purge is only permitted inside a "
                "privileged_purge() scope. Physical deletes of "
                "append-only log rows are reserved for retention cleanup."
            )
        return models.QuerySet.delete(self)[0]


class AppendOnlyManager(models.Manager.from_queryset(AppendOnlyQuerySet)):
    """Manager wrapping ``AppendOnlyQuerySet`` for log-style models."""


class AppendOnlyModelMixin(models.Model):
    """Instance-level guard — refuses ``save()``-after-PK and ``delete()``.

    Concrete log models inherit from this (rather than ``models.Model``)
    so that neither the queryset path nor the instance path can sneak a
    mutation through. ``objects`` is swapped to ``AppendOnlyManager`` at
    the concrete-model level, not here, because abstract inherited
    managers interact with Django's manager-inheritance rules.
    """

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if self.pk is not None:
            raise TamperEvidenceViolation(
                f"{type(self).__name__} is append-only; cannot re-save an "
                "existing row."
            )
        return super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise TamperEvidenceViolation(
            f"{type(self).__name__} is append-only; .delete() is forbidden."
        )
