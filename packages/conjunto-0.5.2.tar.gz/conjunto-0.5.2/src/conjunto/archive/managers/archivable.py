"""Manager + QuerySet for ``ArchivableMixin``.

Responsibilities:

- Filter soft-deleted rows out of the default visibility.
- Provide ``all_objects`` (including deleted) and ``deleted_objects``
  variants via manager configuration, not per-call ``.with_deleted()``
  gymnastics.
- Guard bulk mutations (``.update()`` / ``.bulk_update()`` / ``.delete()``)
  so plugin code cannot bypass the soft-delete semantics by accident.

Snapshot creation is intentionally NOT wired here — Phase 2 attaches
the snapshot hook from inside ``ArchivableMixin.save()``. The manager
only guards visibility and deletion semantics.
"""

from __future__ import annotations

from django.db import models

from conjunto.archive.retention.policy import RetentionToken


class ArchivableQuerySet(models.QuerySet):
    """QuerySet aware of the ``deleted_at`` soft-delete marker.

    The default visibility is controlled by the bound manager (see
    ``ArchivableManager.get_queryset``) rather than inside the queryset
    itself. That keeps ``.filter(...)`` composition predictable: if you
    start from ``Model.objects.all()`` you already see only alive rows.
    """

    def delete(self):
        """Soft-delete every matched row, one by one.

        We intentionally loop (not a single ``UPDATE`` stmt) so that
        each row follows the same ``CascadePolicy`` path as individual
        ``instance.delete()`` calls. Phase 4 layers on a retention-aware
        bulk path that takes advantage of ``UPDATE ... WHERE pk IN (...)``.
        """
        count = 0
        for obj in self:
            obj.delete()
            count += 1
        return count

    def hard_delete(self, *, retention_token: RetentionToken | None):
        """Physically delete every matched row.

        Mirrors ``ArchivableMixin.hard_delete``. Callers without a valid
        ``RetentionToken`` hit ``PermissionError`` — there is no other
        path from the ORM to a physical delete.
        """
        if (
            not isinstance(retention_token, RetentionToken)
            or not retention_token.valid()
        ):
            raise PermissionError(
                "QuerySet.hard_delete requires a valid RetentionToken. "
                "Physical deletes are reserved for scheduled retention cleanup."
            )
        return super().delete()

    # The base ``update()`` is fine — the guard is visibility-based.
    # A caller who wants to touch deleted rows explicitly uses
    # ``Model.all_objects.update(...)``.


class ArchivableManager(models.Manager):
    """Manager that filters soft-deleted rows by default.

    Instantiate three variants on each ``ArchivableMixin`` subclass:

    - ``objects`` — alive rows only (default visibility);
    - ``all_objects`` — alive + soft-deleted;
    - ``deleted_objects`` — soft-deleted only.
    """

    _queryset_class = ArchivableQuerySet

    def __init__(self, *, with_deleted: bool = False, only_deleted: bool = False):
        super().__init__()
        if with_deleted and only_deleted:
            raise ValueError("with_deleted and only_deleted are mutually exclusive")
        self._with_deleted = with_deleted
        self._only_deleted = only_deleted

    # ------------------------------------------------------------------ #
    # Django hooks
    # ------------------------------------------------------------------ #
    def get_queryset(self) -> ArchivableQuerySet:
        qs = self._queryset_class(model=self.model, using=self._db, hints=self._hints)
        if self._only_deleted:
            return qs.filter(deleted_at__isnull=False)
        if self._with_deleted:
            return qs
        return qs.filter(deleted_at__isnull=True)

    def deconstruct(self):
        """Let Django's migration autodetector reproduce the manager.

        Django serialises managers by calling ``deconstruct()``. We
        override to surface our bool flags so the generated migration
        code round-trips cleanly.
        """
        path = "conjunto.archive.managers.ArchivableManager"
        kwargs = {}
        if self._with_deleted:
            kwargs["with_deleted"] = True
        if self._only_deleted:
            kwargs["only_deleted"] = True
        return (None, path, (), kwargs)
