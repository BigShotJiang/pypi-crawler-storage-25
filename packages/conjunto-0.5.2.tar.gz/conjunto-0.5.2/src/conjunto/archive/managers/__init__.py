"""Managers and querysets for ``conjunto.archive``.

The actual classes live in the submodules. This package re-exports
them through lazy ``__getattr__`` to avoid circular imports between
``managers`` and ``mixins`` during Django's app-registry bootstrap.
"""

from __future__ import annotations

__all__ = [
    "AppendOnlyManager",
    "AppendOnlyQuerySet",
    "AppendOnlyModelMixin",
    "ArchivableManager",
    "ArchivableQuerySet",
    "CurrentOnlyManager",
    "TemporalManager",
    "TemporalQuerySet",
]


def __getattr__(name):
    if name in {"AppendOnlyManager", "AppendOnlyQuerySet", "AppendOnlyModelMixin"}:
        from conjunto.archive.managers import append_only

        return getattr(append_only, name)
    if name in {"ArchivableManager", "ArchivableQuerySet"}:
        from conjunto.archive.managers import archivable

        return getattr(archivable, name)
    if name in {"CurrentOnlyManager", "TemporalManager", "TemporalQuerySet"}:
        from conjunto.archive.managers import temporal

        return getattr(temporal, name)
    raise AttributeError(
        f"module 'conjunto.archive.managers' has no attribute {name!r}"
    )
