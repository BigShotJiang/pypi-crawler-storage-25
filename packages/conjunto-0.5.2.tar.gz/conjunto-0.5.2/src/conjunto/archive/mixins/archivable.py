"""``ArchivableMixin`` — soft-delete + optimistic locking + cascade.

Phase 1 scope:

- Four lifecycle fields: ``deleted_at``, ``deleted_by``,
  ``deleted_by_cascade``, ``row_version``.
- Soft-delete via ``delete(user=...)`` (never hard-deletes).
- ``restore()`` to undo a soft-delete (within retention window — Phase 4
  enforces the window; Phase 1 always allows restore).
- ``hard_delete(retention_token=...)`` — the one and only physical-delete
  path. Gated by ``RetentionToken``.
- ``save()`` with atomic UPDATE ... WHERE row_version = loaded. Raises
  ``StaleObjectError`` on conflict.
- Three managers: ``objects`` (alive only), ``all_objects``,
  ``deleted_objects``.
- Cascade dispatch per ``Archive.cascade_policy``.

Phase 2 adds ``_create_snapshot`` hooks; Phase 1 leaves a stub so the
signature is stable. Phase 4 layers retention + scheduled cleanup on top.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from django.conf import settings
from django.db import models, transaction
from django.utils import timezone

from conjunto.archive.concurrency import compare_and_swap
from conjunto.archive.managers.archivable import ArchivableManager
from conjunto.archive.mixins.cascade import CascadePolicy
from conjunto.archive.retention.policy import RetentionToken

if TYPE_CHECKING:  # pragma: no cover
    pass


class ArchivableMixin(models.Model):
    """Soft-delete + optimistic-locking mixin for plugin models.

    Usage::

        class Patient(TenantScopedMixin, ArchivableMixin, models.Model):
            ...

            class Archive:
                cascade_policy = CascadePolicy.SOFT_DELETE_CASCADE

    MRO rule: ``ArchivableMixin`` must sit before ``models.Model`` and
    after any mixin that overrides ``save()`` / ``delete()``. All
    overriding mixins must call ``super()`` cooperatively.
    """

    deleted_at = models.DateTimeField(null=True, blank=True, editable=False)
    deleted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        editable=False,
        on_delete=models.PROTECT,
        related_name="+",
    )
    deleted_by_cascade = models.BooleanField(default=False, editable=False)
    row_version = models.PositiveIntegerField(default=0, editable=False)

    # Phase-2 hook: plugin authors bump this manually when a breaking
    # schema change lands, so the snapshot-migration chain has a version
    # to attach. Phase 1 writes it onto future ArchiveVersion rows; the
    # attribute is already legal to set today.
    archive_schema_version: int = 1

    # Three canonical managers. Overriding subclasses may layer extra
    # managers on top, but these three are the contract.
    objects = ArchivableManager()
    all_objects = ArchivableManager(with_deleted=True)
    deleted_objects = ArchivableManager(only_deleted=True)

    class Meta:
        abstract = True
        base_manager_name = "all_objects"

    class Archive:
        """Per-model archive configuration.

        Plugin authors override this as an inner class. Only fields
        ``ArchivableMixin`` touches in Phase 1 are ``cascade_policy``;
        the rest (``retention_years``, ``follow_fk``,
        ``archive_migrations``, ``excluded_fields``) are Phase 2+ and
        listed here for forward compatibility.
        """

        cascade_policy: CascadePolicy = CascadePolicy.SOFT_DELETE_CASCADE
        retention_years: int | None = None
        retention_floor_years: int = 30
        follow_fk: list[str] = []
        archive_migrations: list = []
        excluded_fields: list[str] = []

    # ------------------------------------------------------------------ #
    # Lifecycle: save
    # ------------------------------------------------------------------ #
    def save(self, *args, **kwargs) -> None:  # type: ignore[override]
        """Persist ``self`` with optimistic-lock semantics.

        INSERT path (first save): behaves like ``models.Model.save`` —
        no compare-and-swap, ``row_version`` stays at its default.

        UPDATE path: runs an atomic compare-and-swap against the
        previously loaded ``row_version``. Zero rows matched => another
        writer won => ``StaleObjectError``.
        """
        update_fields = kwargs.get("update_fields")

        if self._state.adding or self.pk is None:
            # INSERT: fall through to Django's normal save, leave
            # row_version at its default. We keep this path cooperative
            # with any mixin that overrides save() — super() calls up
            # the MRO as usual.
            super().save(*args, **kwargs)
            self._create_snapshot(reason_code="create")
            return

        # UPDATE: compare-and-swap.
        # ``update_fields`` may include ``row_version`` (harmless) or be
        # None (we rewrite every concrete field).
        compare_and_swap(
            self,
            update_fields=list(update_fields) if update_fields else None,
        )
        self._create_snapshot(reason_code="update")

    # ------------------------------------------------------------------ #
    # Lifecycle: soft delete
    # ------------------------------------------------------------------ #
    def delete(
        self,
        *args,
        user=None,
        reason_code: str = "soft_delete",
        _cascaded: bool = False,
        **kwargs,
    ) -> None:  # type: ignore[override]
        """Soft-delete per ``Archive.cascade_policy``.

        Plugin code sees one method name (``delete``) regardless of the
        declared policy; the dispatch happens here.

        ``*args`` / ``**kwargs`` are swallowed to keep
        ``super().delete(using=...)`` signatures from leaking into the
        public API. Concrete cascade behaviour is implemented below.
        """
        policy = self._cascade_policy()

        if policy == CascadePolicy.NO_DELETE:
            raise PermissionError(
                f"{type(self).__name__} declares CascadePolicy.NO_DELETE; "
                "delete() is forbidden on this model."
            )

        # All hard-delete policies degrade to soft-delete on this path.
        # The only legitimate path to a physical delete is via
        # ``hard_delete(retention_token=...)``.

        if self.deleted_at is not None:
            # Idempotent: deleting an already-deleted row is a no-op.
            return

        with transaction.atomic():
            self.deleted_at = timezone.now()
            self.deleted_by = user
            self.deleted_by_cascade = _cascaded
            super().save(
                update_fields=["deleted_at", "deleted_by", "deleted_by_cascade"]
            )

            if policy == CascadePolicy.SOFT_DELETE_CASCADE:
                self._cascade_soft_delete(user=user)

        self._create_snapshot(reason_code=reason_code)

    # ------------------------------------------------------------------ #
    # Lifecycle: restore
    # ------------------------------------------------------------------ #
    def restore(self, *, user=None) -> None:
        """Undo a soft-delete. Phase 4 will gate this by retention window.

        Clears ``deleted_at``, ``deleted_by``, and ``deleted_by_cascade``.
        Emits a snapshot with ``reason_code='restore'`` (Phase 2 hook).
        """
        if self.deleted_at is None:
            return
        with transaction.atomic():
            self.deleted_at = None
            self.deleted_by = None
            self.deleted_by_cascade = False
            super().save(
                update_fields=["deleted_at", "deleted_by", "deleted_by_cascade"]
            )
        self._create_snapshot(reason_code="restore")

    # ------------------------------------------------------------------ #
    # Lifecycle: revert to a historical snapshot
    # ------------------------------------------------------------------ #
    def revert(self, to_version, *, user=None, comment: str = ""):
        """Revert this instance to the state captured in ``to_version``.

        Loads ``to_version.serialized_data`` and — if the snapshot was
        written under an older ``archive_schema_version`` — replays the
        model's ``archive_migrations`` chain so the payload matches
        today's field layout. The migrated payload is written back onto
        ``self`` via the normal optimistic-lock ``save()`` path, which
        in turn emits a fresh ``ArchiveVersion`` with
        ``reason_code='revert'``.

        Raises:
            StaleObjectError: another writer bumped ``row_version``
                between the caller's load and this call. The caller
                should surface the ``_stale_conflict.html`` partial and
                let the user retry after reloading.
            UnrevertableVersionError: the snapshot belongs to a
                different content type, or the migration chain between
                the snapshot's schema version and the current one is
                missing a step, or a scalar field in the snapshot no
                longer exists on the model and is not remapped.

        The method returns ``self`` (now mutated + saved). The caller is
        responsible for any surrounding UI refresh — ``revert()`` does
        not touch the request / response cycle.
        """
        from django.contrib.contenttypes.models import ContentType

        from conjunto.archive.exceptions import (
            StaleObjectError,
            UnrevertableVersionError,
        )
        from conjunto.archive.middleware import revision_context
        from conjunto.archive.schema.migration import apply_migrations

        model = type(self)

        # --- Guard: snapshot must belong to this instance ---------------
        own_ct = ContentType.objects.get_for_model(model)
        if to_version.content_type_id != own_ct.pk:
            raise UnrevertableVersionError(
                f"ArchiveVersion(pk={to_version.pk}) belongs to content type "
                f"{to_version.content_type_id}, not to {model.__name__}."
            )
        if str(to_version.object_id) != str(self.pk):
            raise UnrevertableVersionError(
                f"ArchiveVersion(pk={to_version.pk}) targets object "
                f"{to_version.object_id}, not {self.pk}."
            )

        # --- Migration chain: replay if the snapshot is on an older
        #     schema version than the model currently declares. --------
        archive_cls = getattr(model, "Archive", None)
        migrations = list(getattr(archive_cls, "archive_migrations", []) or [])
        current_version = int(getattr(model, "archive_schema_version", 1))
        from_version = int(to_version.schema_version)

        if from_version > current_version:
            raise UnrevertableVersionError(
                f"ArchiveVersion schema_version={from_version} is newer "
                f"than the model's current archive_schema_version="
                f"{current_version}; downgrade reverts are not supported."
            )

        try:
            payload = apply_migrations(
                dict(to_version.serialized_data or {}),
                from_version=from_version,
                to_version=current_version,
                migrations=migrations,
            )
        except Exception as exc:
            # ``apply_migrations`` raises ``ArchiveMigrationError`` on a
            # missing step; we surface the Phase-5 public error instead
            # so UI code can render one partial.
            raise UnrevertableVersionError(str(exc)) from exc

        # --- Apply payload onto instance fields ------------------------
        # We walk the concrete fields (skipping pk + row_version) and
        # only touch fields that are actually present in the payload.
        # Any leftover scalar key in the payload that has no matching
        # model field is treated as unrevertable (schema drift). PK
        # fields that happen to be in the payload are silently ignored
        # — the snapshot pipeline records them for completeness but we
        # never overwrite the PK on revert.
        all_field_names = {f.name for f in model._meta.concrete_fields}
        concrete_by_name = {
            f.name: f
            for f in model._meta.concrete_fields
            if not f.primary_key and f.name != "row_version"
        }

        unknown = (
            set(payload.keys())
            - all_field_names
            # row_version is also valid to see in older snapshots
            # (the snapshot pipeline strips it today, but we stay
            # forward-compatible for any payload that still carries it).
            - {"row_version"}
        )
        if unknown:
            raise UnrevertableVersionError(
                f"Archived fields {sorted(unknown)!r} no longer exist on "
                f"{model.__name__} and no migration step remapped them."
            )

        for name, field in concrete_by_name.items():
            if name not in payload:
                continue
            raw = payload[name]
            if field.is_relation and field.many_to_one:
                # ``_row_payload`` stored FKs as {"pk": ...} (optionally
                # with "repr"). Restore the scalar PK onto ``<field>_id``.
                pk_value = raw["pk"] if isinstance(raw, dict) else raw
                setattr(self, field.attname, pk_value)
            else:
                setattr(self, field.attname, raw)

        # --- Save with revert reason code ------------------------------
        # We go straight through compare_and_swap + _create_snapshot so
        # we can set ``reason_code='revert'`` on the new snapshot. The
        # normal ``save()`` path would write ``reason_code='update'``
        # (it passes the hard-coded value to ``_create_snapshot``, which
        # takes precedence over any context reason).
        #
        # Any parallel writer that bumped ``row_version`` between the
        # caller's load and this call causes ``StaleObjectError`` — the
        # exact same guarantee the interactive save path offers.
        ctx_kwargs: dict = {"reason_code": "revert"}
        if user is not None:
            ctx_kwargs["user"] = user
        if comment:
            ctx_kwargs["comment"] = comment

        try:
            with revision_context(**ctx_kwargs):
                compare_and_swap(self, update_fields=None)
                self._create_snapshot(reason_code="revert")
        except StaleObjectError:
            # Re-raise untouched — callers match on the type.
            raise

        return self

    # ------------------------------------------------------------------ #
    # Lifecycle: hard delete (Zero-Trust gate)
    # ------------------------------------------------------------------ #
    def hard_delete(self, *, retention_token: RetentionToken | None) -> None:
        """Physically delete this row.

        Gated by ``RetentionToken``. Invoked only from retention
        cleanup (Phase 4) — plugin code and view handlers cannot legally
        call this without obtaining a token, and tokens are only issued
        from the cleanup context.

        Soft-check path only: just the token's ``valid()``. Call
        :meth:`_hard_delete_cascade` instead if you also want the
        associated ``ArchiveVersion`` / ``ArchiveRevisionMeta`` rows
        purged atomically under a consuming ``validate_or_raise`` token
        check — that is what the retention cleanup command uses.
        """
        if (
            not isinstance(retention_token, RetentionToken)
            or not retention_token.valid()
        ):
            raise PermissionError(
                "hard_delete requires a valid RetentionToken. "
                "Physical deletes are reserved for scheduled retention cleanup."
            )

        policy = self._cascade_policy()
        if policy == CascadePolicy.NO_DELETE:
            raise PermissionError(
                f"{type(self).__name__} declares CascadePolicy.NO_DELETE; "
                "hard_delete() is forbidden on this model."
            )

        # Bypass our own soft-delete ``delete()``; go straight to
        # Django's model delete for the physical purge.
        models.Model.delete(self)

    def _hard_delete_cascade(self, *, token: RetentionToken) -> dict[str, int]:
        """Purge the row + all of its ``ArchiveVersion`` / meta rows.

        Single unit of work per ``token``. The token is consumed
        (``validate_or_raise``) at the top of the
        :func:`conjunto.archive.managers.append_only.privileged_purge`
        scope; that scope authorises the cascading DELETEs of the
        append-only log tables.

        Returns a small dict with per-table row counts for logging.
        """
        from conjunto.archive.managers.append_only import privileged_purge
        from conjunto.archive.models import ArchiveRevisionMeta, ArchiveVersion

        policy = self._cascade_policy()
        if policy == CascadePolicy.NO_DELETE:
            raise PermissionError(
                f"{type(self).__name__} declares CascadePolicy.NO_DELETE; "
                "_hard_delete_cascade() is forbidden on this model."
            )

        from django.contrib.contenttypes.models import ContentType

        ct = ContentType.objects.get_for_model(type(self))
        object_id_str = str(self.pk)

        counts: dict[str, int] = {
            "instance": 0,
            "archive_versions": 0,
            "revision_metas": 0,
        }

        with transaction.atomic():
            with privileged_purge(retention_token=token):
                # 1) Find the set of RevisionMeta PKs that belong to this
                #    row's ArchiveVersions — we purge them after the
                #    ArchiveVersion delete because of the FK from
                #    ArchiveVersion.revision_meta (PROTECT).
                versions_qs = ArchiveVersion.objects.filter(
                    content_type=ct, object_id=object_id_str
                )
                meta_ids = list(versions_qs.values_list("revision_meta_id", flat=True))

                # 2) Purge ArchiveVersion rows.
                counts["archive_versions"] = versions_qs.retention_purge()

                # 3) Purge the now-orphan RevisionMeta rows. Only the
                #    ones referenced exclusively by this row's
                #    ArchiveVersions — since revision_meta is
                #    OneToOneField on ArchiveVersion (each meta has at
                #    most one version), purging meta_ids is safe.
                if meta_ids:
                    meta_qs = ArchiveRevisionMeta.objects.filter(pk__in=meta_ids)
                    counts["revision_metas"] = meta_qs.retention_purge()

                # 4) Physically delete the source row itself. This
                #    happens inside the privileged scope so any
                #    cascading FK-on-delete behaviour that lands on
                #    append-only tables is also legal.
                models.Model.delete(self)
                counts["instance"] = 1

        return counts

    # ------------------------------------------------------------------ #
    # Snapshot hook — Phase 2 implementation
    # ------------------------------------------------------------------ #
    def _create_snapshot(self, *, reason_code: str, user=None, tenant=None) -> None:
        """Write an ``ArchiveVersion`` + ``ArchiveRevisionMeta`` pair.

        Called from ``save()`` / ``delete()`` / ``restore()`` after the
        row has been persisted. The snapshot captures every concrete
        field (minus ``row_version`` and ``Archive.excluded_fields``)
        as a native-JSON blob.

        User and tenant default to the request-bound
        ``RevisionContext``; callers that want to force a value (for
        example, bulk imports or migration scripts) use
        ``revision_context(...)`` as a context manager rather than
        passing them in explicitly — keeps the snapshot API tight.
        """
        # Avoid snapshotting rows that never made it to the DB.
        if self.pk is None:
            return None
        # Import lazily so the mixin stays import-safe during Django
        # app-registry bootstrap.
        from conjunto.archive.snapshot import create_snapshot

        create_snapshot(self, reason_code=reason_code)
        return None

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #
    def _cascade_policy(self) -> CascadePolicy:
        """Resolve the effective cascade policy for this instance."""
        archive_cls = getattr(type(self), "Archive", None)
        if archive_cls is None:
            return CascadePolicy.SOFT_DELETE_CASCADE
        policy = getattr(
            archive_cls, "cascade_policy", CascadePolicy.SOFT_DELETE_CASCADE
        )
        # Coerce strings (from migrations / legacy code) back to enum.
        try:
            return CascadePolicy(policy)
        except ValueError:
            return CascadePolicy.SOFT_DELETE_CASCADE

    def _cascade_soft_delete(self, *, user) -> None:
        """Cascade soft-delete to archivable FK children.

        We walk every reverse relation of this model, and for each one
        whose target model is an ``ArchivableMixin`` subclass, we
        soft-delete the matching rows with ``_cascaded=True``. Non-
        archivable targets are left alone — Django's own ``on_delete``
        handles them only on physical delete, which is not what we're
        doing here.
        """
        for rel in type(self)._meta.get_fields():
            # Skip FK-forward, M2M, and things that aren't reverse FKs.
            if not (rel.one_to_many or rel.one_to_one):
                continue
            # Skip forward relations (concrete fields on *this* model, e.g.
            # an explicit ``OneToOneField(parent_link=True)`` introduced by
            # Django multi-table inheritance). Those are not cascade
            # targets — they point *to* a parent row that we do not own —
            # and they have no ``get_accessor_name()``. Reverse relations
            # (``ManyToOneRel`` / ``OneToOneRel`` instances) report
            # ``concrete=False``.
            if getattr(rel, "concrete", False):
                continue
            related_model = rel.related_model
            if related_model is None:
                continue
            if not issubclass(related_model, ArchivableMixin):
                continue

            accessor = rel.get_accessor_name()
            if accessor is None:
                continue
            manager = getattr(self, accessor, None)
            if manager is None:
                continue

            # one_to_one returns an instance on attribute access; guard.
            if rel.one_to_one:
                try:
                    child = manager  # descriptor already resolved
                except related_model.DoesNotExist:
                    continue
                if child is None or child.deleted_at is not None:
                    continue
                child.delete(user=user, _cascaded=True)
                continue

            # Reverse many — use .all_objects so we don't accidentally
            # skip rows that were already soft-deleted elsewhere.
            source_manager = getattr(
                related_model, "all_objects", related_model._default_manager
            )
            fk_name = rel.field.name
            for child in source_manager.filter(**{fk_name: self}):
                if child.deleted_at is not None:
                    continue
                child.delete(user=user, _cascaded=True)
