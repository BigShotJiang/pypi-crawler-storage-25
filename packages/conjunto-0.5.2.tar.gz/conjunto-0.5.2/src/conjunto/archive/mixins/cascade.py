"""Cascade-policy enum + dispatcher for ``ArchivableMixin``.

Five distinct behaviours, orthogonal to each other. Eigenbau — we own
the semantics end to end so the Long-Term-Support promise is ours.

Exposure to plugin authors is deliberately narrow:

- ``SOFT_DELETE``, ``SOFT_DELETE_CASCADE``, ``NO_DELETE`` are the three
  user-facing options. A plugin declares one of them on the model's
  ``Archive.cascade_policy`` attribute.
- ``HARD_DELETE`` and ``HARD_DELETE_NOCASCADE`` exist as named-constants
  so the retention subsystem (Phase 4) can speak the same vocabulary.
  They are **not** reachable through ``instance.delete()`` — the only
  path to a physical delete is ``hard_delete(retention_token=...)``.
"""

from __future__ import annotations

from django.db import models
from django.utils.translation import gettext_lazy as _


class CascadePolicy(models.TextChoices):
    """Five cascade behaviours for archivable rows."""

    SOFT_DELETE = "soft_delete", _("Soft delete (no cascade)")
    SOFT_DELETE_CASCADE = (
        "soft_delete_cascade",
        _("Soft delete + cascade to archivable children"),
    )
    HARD_DELETE = "hard_delete", _("Hard delete (retention only)")
    HARD_DELETE_NOCASCADE = (
        "hard_delete_nocascade",
        _("Hard delete without cascade (retention only)"),
    )
    NO_DELETE = "no_delete", _("Forbid any delete (system singletons)")


# Policies that plugin code may legally declare on a model's Archive
# inner class. Retention-cleanup-only policies are filtered out to make
# sure an accidental declaration does not open a hard-delete path.
USER_FACING_POLICIES = frozenset(
    {
        CascadePolicy.SOFT_DELETE,
        CascadePolicy.SOFT_DELETE_CASCADE,
        CascadePolicy.NO_DELETE,
    }
)
