"""``TemporalMixin`` — structured historisation for actively queried values.

Use this mixin when the *history* of a value is part of the business
logic, not just an audit requirement. Typical domain examples:

- ``PatientName`` — old invoices need the name that was current when
  the invoice was issued.
- ``PatientAddress`` — letters sent in 2024 need the 2024 address.
- ``InsuranceContract`` — historical claims need the policy that
  applied on the date of loss.
- ``TaxRate`` — invoices use the VAT rate in force on their date.

Contract
--------

- ``valid_from`` is inclusive: the row is valid *from* this day on.
- ``valid_to`` is inclusive on its last day: the row is valid
  *through* this day. ``NULL`` means "no end yet" — i.e. this is the
  currently valid version.
- ``archived`` flags a row as retired without closing its validity
  range. Useful when a row should disappear from the ``current``
  manager while remaining factually true for historical queries.

Manager strategy (Option C, finalised in blueprint v6.1)::

    class PatientName(TemporalMixin, models.Model):
        ...

    PatientName.objects       # all rows (default — Django-conform)
    PatientName.current       # pre-filtered to valid_to IS NULL, archived=False

Combination with ``ArchivableMixin``
------------------------------------

``TemporalMixin`` is orthogonal to ``ArchivableMixin``. Both can be
mixed in together::

    class PatientName(ArchivableMixin, TemporalMixin, models.Model):
        ...

With the combination, ``supersede()`` triggers a snapshot for both
rows via the ``ArchivableMixin.save()`` hook — one ``update`` snapshot
for the closed row and one ``create`` snapshot for the new row.

Soft-delete on a temporal row is *not* a supersede: it sets
``deleted_at`` but leaves ``valid_from`` / ``valid_to`` untouched.
Likewise, cascade soft-delete from a parent model soft-deletes the
temporal children but never touches their validity — the children's
history is still factually true.

Direct writes to ``valid_to`` are not blocked by the mixin — a caller
with a legitimate need (data migrations, admin fixes) can set it via
``instance.valid_to = some_date; instance.save()``. This bypasses the
supersede semantics and is documented as an escape hatch in
``docs/archive/temporal-mixin.md``.
"""

from __future__ import annotations

from datetime import date as _date
from datetime import timedelta

from django.db import models, transaction
from django.db.models import F, Q
from django.utils import timezone

from conjunto.archive.managers.temporal import (
    CurrentOnlyManager,
    TemporalManager,
)


def _today() -> _date:
    """Return today's date in the active timezone.

    Centralised so tests can monkeypatch a single helper if they need a
    deterministic date.
    """
    return timezone.localdate()


class TemporalMixin(models.Model):
    """Valid-from/valid-to history mixin with an atomic supersede lifecycle."""

    valid_from = models.DateField(default=_today, db_index=True)
    valid_to = models.DateField(null=True, blank=True, default=None, db_index=True)
    archived = models.BooleanField(default=False, db_index=True)

    # Option C: two managers. ``objects`` is the transparent default
    # (sees all rows); ``current`` is the convenience filter.
    objects = TemporalManager()
    current = CurrentOnlyManager()

    class Meta:
        abstract = True
        indexes = [
            # Composite index for the hot ``.at(date)`` path.
            models.Index(fields=["valid_from", "valid_to"]),
        ]
        constraints = [
            # Reject rows whose closed range is inverted. NULL passes
            # through (``valid_to IS NULL`` = still current).
            models.CheckConstraint(
                condition=Q(valid_to__isnull=True) | Q(valid_to__gte=F("valid_from")),
                name="%(app_label)s_%(class)s_valid_range",
            ),
        ]

    # ------------------------------------------------------------------ #
    # Lifecycle: supersede
    # ------------------------------------------------------------------ #
    def supersede(self, **new_values) -> "TemporalMixin":
        """Close this row and open a successor, atomically.

        Convention
        ----------

        - ``self.valid_to`` is set to ``today() - 1 day`` (inclusive last
          day the old row applied).
        - The new row is inserted with ``valid_from = today()`` and
          ``valid_to = None``.

        Validation
        ----------

        - ``self.valid_to`` must be ``None`` and ``self.archived`` must
          be ``False`` — otherwise the row is no longer "current" and
          cannot be superseded.
        - At least one of ``new_values`` must actually change a field —
          creating an identical successor would pollute the history
          with no information gain. Raises ``ValueError`` otherwise.

        Atomicity
        ---------

        The old-row update and the new-row insert run inside a single
        ``transaction.atomic()`` block with a ``select_for_update()`` on
        self. Concurrent callers either see a serialised outcome (one
        wins, the other sees the row as already-closed and raises
        ``ValueError``) or, on databases without row locks, hit the
        validity ``CheckConstraint`` when the first committer wins.

        Returns
        -------

        The freshly-created successor instance, fully saved.
        """
        if not new_values:
            raise ValueError(
                "supersede() requires at least one field to change — "
                "an identical successor would pollute the history."
            )

        with transaction.atomic():
            # Race-condition guard: lock the row and re-read the state
            # that gates the legality check.
            locked = (
                type(self)
                ._base_manager.select_for_update()
                .filter(pk=self.pk)
                .values("valid_to", "archived")
                .first()
            )
            if locked is None:
                raise ValueError(
                    f"Cannot supersede {type(self).__name__}(pk={self.pk}): "
                    "row no longer exists."
                )
            if locked["valid_to"] is not None or locked["archived"]:
                raise ValueError(
                    f"supersede() is only allowed on a current row "
                    f"(valid_to IS NULL, archived=False). "
                    f"{type(self).__name__}(pk={self.pk}) has "
                    f"valid_to={locked['valid_to']!r}, "
                    f"archived={locked['archived']!r}."
                )

            # Reject no-op supersedes. Compare new_values against the
            # current instance — if every requested value already
            # matches, there is nothing to record.
            changed = False
            for field_name, requested in new_values.items():
                current = getattr(self, field_name)
                if current != requested:
                    changed = True
                    break
            if not changed:
                raise ValueError(
                    "supersede() requires at least one field to actually "
                    "change; all provided values match the existing row."
                )

            today = _today()
            # Close the old row.
            self.valid_to = today - timedelta(days=1)
            self.save(update_fields=["valid_to"])

            # Build the successor: copy every concrete non-PK field,
            # overlay ``new_values``, reset the temporal fields.
            successor = self._build_successor(new_values, valid_from=today)
            successor.save()

        return successor

    # ------------------------------------------------------------------ #
    # Lifecycle: archive
    # ------------------------------------------------------------------ #
    def archive(self) -> None:
        """Mark this row as archived without closing its validity range.

        Use when a row should drop out of the ``current`` manager but
        still be factually true for historical queries (e.g. a tax rate
        that was announced but cancelled before use).
        """
        if self.archived:
            return
        self.archived = True
        self.save(update_fields=["archived"])

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #
    def _build_successor(
        self, new_values: dict, *, valid_from: _date
    ) -> "TemporalMixin":
        """Construct (but do not save) a successor of this row.

        Copies every concrete non-PK field (including the other temporal
        fields), overlays the caller's ``new_values``, then resets the
        temporal state so the successor starts life as the currently-
        valid row.
        """
        cls = type(self)
        kwargs: dict[str, object] = {}
        for field in cls._meta.concrete_fields:
            if field.primary_key:
                continue
            # Skip reverse-managed fields (none on this abstract mixin
            # today, but future-proof the copy loop).
            kwargs[field.attname] = getattr(self, field.attname)

        # Overlay caller-requested changes.
        kwargs.update(new_values)

        # Reset the temporal slots for the successor.
        kwargs["valid_from"] = valid_from
        kwargs["valid_to"] = None
        kwargs["archived"] = False

        # If combined with ArchivableMixin, the successor starts as a
        # fresh row with row_version=0 and no soft-delete markers. The
        # field loop above copies ``deleted_at`` etc. from self, which
        # for a current row are already None/0 — but clear them
        # explicitly so a successor of an edge-case input can never
        # inherit stale concurrency state.
        for reset_attr in (
            "deleted_at",
            "deleted_by_id",
            "deleted_by_cascade",
            "row_version",
        ):
            if reset_attr in kwargs:
                if reset_attr == "deleted_by_cascade":
                    kwargs[reset_attr] = False
                elif reset_attr == "row_version":
                    kwargs[reset_attr] = 0
                else:
                    kwargs[reset_attr] = None

        return cls(**kwargs)


__all__ = ["TemporalMixin"]
