"""Framework-level scoped setting registrations."""

from django.conf import settings as django_settings

from conjunto.settings.scoped.models import Scope
from conjunto.settings.scoped.registry import SettingRegistry

SettingRegistry.register(
    "conjunto",
    "layout_style",
    type="str",
    default=getattr(django_settings, "CONJUNTO_LAYOUT", "fluid"),
    help_text="Page layout: 'fluid' (container-fluid) or 'boxed' (container-xl).",
    icon="layout",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "topbar_fixed",
    type="bool",
    default=getattr(django_settings, "CONJUNTO_TOPBAR_FIXED", True),
    help_text="Whether the topbar uses position:fixed (True) or position:sticky (False).",
    icon="layout-navbar",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "sidebar_left_width",
    type="str",
    default=getattr(django_settings, "CONJUNTO_SIDEBAR_LEFT_WIDTH", "15rem"),
    help_text="CSS length of the left sidebar (e.g. '15rem', '240px').",
    icon="layout-sidebar",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "sidebar_left_mode",
    type="str",
    default=getattr(django_settings, "CONJUNTO_SIDEBAR_LEFT_MODE", "full"),
    help_text=(
        "Left sidebar display mode: 'full' (text + icons + submenus), "
        "'mini' (icons only, submenus open as click-popovers), "
        "'collapsed' (sidebar hidden). The 'sidebar_left_width' setting "
        "only applies in 'full' mode."
    ),
    icon="layout-sidebar",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.DEVICE, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "sidebar_right_width",
    type="str",
    default=getattr(django_settings, "CONJUNTO_SIDEBAR_RIGHT_WIDTH", "20rem"),
    help_text="CSS length of the right sidebar (e.g. '20rem', '320px').",
    icon="layout-sidebar-right",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "sidebar_right_mode",
    type="str",
    default=getattr(django_settings, "CONJUNTO_SIDEBAR_RIGHT_MODE", "collapsed"),
    help_text=(
        "Right sidebar display mode: 'full' (text + icons + widgets), "
        "'mini' (icons only, content opens as click-popovers), "
        "'collapsed' (sidebar hidden, default). The 'sidebar_right_width' "
        "setting only applies in 'full' mode."
    ),
    icon="layout-sidebar-right",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.DEVICE, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "maintenance_mode",
    type="bool",
    default=False,
    help_text="When True, non-staff users are redirected to /maintenance/.",
    icon="tool",
    writable_scopes=[Scope.VENDOR],
    lockable_scopes=[Scope.VENDOR],
)

SettingRegistry.register(
    "auth",
    "session_lifetime_default",
    type="int",
    default=getattr(django_settings, "CONJUNTO_SESSION_LIFETIME_DEFAULT", 0),
    help_text=(
        "Session lifetime in seconds when the user does NOT check "
        "'Remember me' on the login page. 0 means the session expires "
        "when the browser closes (Django default). Positive values set "
        "an absolute expiry via request.session.set_expiry()."
    ),
    icon="clock",
    writable_scopes=[Scope.VENDOR, Scope.TENANT],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "auth",
    "session_lifetime_remembered",
    type="int",
    default=getattr(
        django_settings, "CONJUNTO_SESSION_LIFETIME_REMEMBERED", 60 * 60 * 24 * 30
    ),
    help_text=(
        "Session lifetime in seconds when the user checks 'Remember me' "
        "on the login page. Default is 30 days (2592000 seconds)."
    ),
    icon="clock-check",
    writable_scopes=[Scope.VENDOR, Scope.TENANT],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "auth",
    "show_remember_me",
    type="bool",
    default=True,
    help_text=(
        "Show the 'Remember me' checkbox on the login page. When False, "
        "the checkbox is hidden and every login uses "
        "auth.session_lifetime_default — users cannot opt into the "
        "longer 'remembered' lifetime. Useful for sites where shared "
        "kiosks or compliance rules forbid persistent sessions."
    ),
    icon="device-floppy",
    writable_scopes=[Scope.VENDOR, Scope.TENANT],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "color_scheme",
    type="str",
    default="light",
    help_text="Color scheme: 'light' or 'dark'. Persisted per user to avoid flash of wrong theme on page load.",
    icon="palette",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.DEVICE, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "accessibility",
    "enabled",
    type="bool",
    default=False,
    help_text=(
        "When True, the conjunto accessibility stylesheet (a11y.css) is "
        "loaded — adding a 2 px keyboard-focus outline on every "
        "interactive element so screen-reader and keyboard-only users "
        "always see where focus is. Off by default because the visual "
        "ring conflicts with Tabler's softer focus halo and not every "
        "deployment needs the WAI-ARIA-strength indicator."
    ),
    icon="accessible",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "show_help_hints",
    type="bool",
    default=True,
    help_text=(
        "When True, <code>{% help_hint %}</code> blocks render a small info "
        "icon next to section titles whose tooltip carries the "
        "in-context help text. Power users tend to disable this once "
        "they know the UI; the icons stay out of their way."
    ),
    icon="info-circle",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "timezone",
    type="str",
    default="",
    help_text=(
        "IANA timezone name (e.g. 'Europe/Vienna') used to render datetime "
        "values. Empty value falls back to Django's settings.TIME_ZONE. "
        "Activated per request by TimezoneMiddleware."
    ),
    icon="clock",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)
