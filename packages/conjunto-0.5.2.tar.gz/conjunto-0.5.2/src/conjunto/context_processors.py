from django.conf import settings as django_settings
from importlib import metadata
from conjunto.models import Vendor


__all__ = ["globals", "settings"]


# Inline-style fragments for every supported toast position. ``{m}`` is
# substituted with the configured ``CONJUNTO_TOAST_MARGIN`` value.
_TOAST_POSITION_STYLES = {
    "top-left": "top: {m}; left: {m};",
    "top-center": "top: {m}; left: 50%; transform: translateX(-50%);",
    "top-right": "top: {m}; right: {m};",
    "bottom-left": "bottom: {m}; left: {m};",
    "bottom-center": "bottom: {m}; left: 50%; transform: translateX(-50%);",
    "bottom-right": "bottom: {m}; right: {m};",
}


def _toast_config():
    position = getattr(django_settings, "CONJUNTO_TOAST_POSITION", "top-right")
    margin = getattr(django_settings, "CONJUNTO_TOAST_MARGIN", "1rem")
    template = (
        _TOAST_POSITION_STYLES.get(position) or _TOAST_POSITION_STYLES["top-right"]
    )
    return {
        "position": position,
        "margin": margin,
        "style": template.format(m=margin),
    }


# Default banner configuration. Consumers override via the
# ``CONJUNTO_ENVIRONMENT_BANNER`` setting (list of dicts). Each entry:
#
#   * ``name``               — short label (e.g. ``"LOCAL"``); rendered into
#                              the tab-title prefix and the banner tooltip.
#   * ``hosts``              — list of hostnames to match against
#                              ``request.get_host()`` (case-insensitive,
#                              port stripped).
#   * ``color``              — CSS color for the 4 px stripe.
#   * ``require_debug``      — if ``True``, the entry only matches when
#                              ``settings.DEBUG`` is on. Guards against
#                              false positives when a misconfigured
#                              reverse proxy makes the production backend
#                              see ``localhost`` as the request host.
#   * ``fallback_on_debug``  — if ``True`` and no host matches, this entry
#                              is selected when ``settings.DEBUG`` is on.
_DEFAULT_ENVIRONMENT_BANNER = [
    {
        "name": "LOCAL",
        "hosts": ["localhost", "127.0.0.1", "0.0.0.0"],
        "color": "#dc3545",
        "require_debug": True,
        "fallback_on_debug": True,
    },
]


def _environment_banner(request):
    """Return the matching ``{"name", "color"}`` dict, or ``None``.

    Match order: exact host match wins (entries with
    ``require_debug=True`` are skipped when ``DEBUG=False``). If
    nothing matches and ``DEBUG`` is on, the first entry with
    ``fallback_on_debug=True`` is used. In production with all rules
    failing, this returns ``None`` and the banner is not rendered.
    """
    config = getattr(
        django_settings, "CONJUNTO_ENVIRONMENT_BANNER", _DEFAULT_ENVIRONMENT_BANNER
    )
    if not config:
        return None

    debug = getattr(django_settings, "DEBUG", False)
    host = request.get_host().split(":")[0].lower()
    for entry in config:
        if entry.get("require_debug") and not debug:
            continue
        hosts = [h.lower() for h in (entry.get("hosts") or [])]
        if host in hosts:
            return {
                "name": entry.get("name", ""),
                "color": entry.get("color", "#dc3545"),
            }

    if debug:
        for entry in config:
            if entry.get("fallback_on_debug"):
                return {
                    "name": entry.get("name", ""),
                    "color": entry.get("color", "#dc3545"),
                }

    return None


# try to get version using the importlib.metadata module
# you have to set PROJECT_NAME in settings.py for that.
# But this is obligatory anyway, and helps to avoid searching for version strings
# elsewhere.
__version__ = metadata.version(django_settings.PROJECT_NAME)


def _websockets_enabled() -> bool:
    """Resolve the ``cj_layout.websockets`` flag.

    Honours an explicit ``CONJUNTO_WEBSOCKETS_ENABLED`` setting; falls
    back to auto-detect (``"channels"`` in ``INSTALLED_APPS`` AND
    ``ASGI_APPLICATION`` configured). Templates must gate every
    WS-bound surface (bell, ``hx-ext="ws"`` connectors, …) on this
    flag — never assume.
    """
    explicit = getattr(django_settings, "CONJUNTO_WEBSOCKETS_ENABLED", None)
    if explicit is not None:
        return bool(explicit)
    installed = set(getattr(django_settings, "INSTALLED_APPS", ()))
    return "channels" in installed and bool(
        getattr(django_settings, "ASGI_APPLICATION", None)
    )


def globals(request):  # noqa
    # Build cj_layout from Django settings defaults, then overlay the
    # effective scoped-setting values (VENDOR → USER chain). Views can
    # further override by setting ctx["cj_layout"] = {...}.
    default_style = getattr(django_settings, "CONJUNTO_LAYOUT", "fluid")
    default_topbar = getattr(django_settings, "CONJUNTO_TOPBAR_FIXED", True)
    default_sidebar_left_width = getattr(
        django_settings, "CONJUNTO_SIDEBAR_LEFT_WIDTH", "15rem"
    )
    default_sidebar_left_mode = getattr(
        django_settings, "CONJUNTO_SIDEBAR_LEFT_MODE", "full"
    )
    default_sidebar_right_width = getattr(
        django_settings, "CONJUNTO_SIDEBAR_RIGHT_WIDTH", "20rem"
    )
    default_sidebar_right_mode = getattr(
        django_settings, "CONJUNTO_SIDEBAR_RIGHT_MODE", "collapsed"
    )
    theme_switcher = bool(getattr(django_settings, "CONJUNTO_THEME_SWITCHER", True))
    websockets = _websockets_enabled()
    notifications = websockets and (
        "conjunto.notifications" in getattr(django_settings, "INSTALLED_APPS", ())
    )

    scoped = getattr(request, "scoped_settings", None)
    sidebar_left_mode_locked = False
    sidebar_right_mode_locked = False
    if scoped is not None:
        layout = {
            "style": scoped.get("conjunto", "layout_style", default=default_style),
            "topbar_fixed": scoped.get(
                "conjunto", "topbar_fixed", default=default_topbar
            ),
            "sidebar_left_width": scoped.get(
                "conjunto", "sidebar_left_width", default=default_sidebar_left_width
            ),
            "sidebar_left_mode": scoped.get(
                "conjunto", "sidebar_left_mode", default=default_sidebar_left_mode
            ),
            "sidebar_right_width": scoped.get(
                "conjunto", "sidebar_right_width", default=default_sidebar_right_width
            ),
            "sidebar_right_mode": scoped.get(
                "conjunto", "sidebar_right_mode", default=default_sidebar_right_mode
            ),
            "color_scheme": scoped.get("conjunto", "color_scheme", default="light"),
            "theme_switcher": theme_switcher,
            "websockets": websockets,
            "notifications": notifications,
        }
        # Resolve the lock indicators separately — UIs need to know
        # whether to disable each side's toggle button and resize handle.
        try:
            from conjunto.settings.scoped.resolver import get_resolution

            sidebar_left_mode_locked = get_resolution(
                "conjunto", "sidebar_left_mode", request
            ).is_locked
            sidebar_right_mode_locked = get_resolution(
                "conjunto", "sidebar_right_mode", request
            ).is_locked
        except KeyError:
            # Setting not registered (e.g. test environment without
            # conjunto's scoped_settings.py) — leave unlocked.
            pass
    else:
        layout = {
            "style": default_style,
            "topbar_fixed": default_topbar,
            "sidebar_left_width": default_sidebar_left_width,
            "sidebar_left_mode": default_sidebar_left_mode,
            "sidebar_right_width": default_sidebar_right_width,
            "sidebar_right_mode": default_sidebar_right_mode,
            "color_scheme": "light",
            "theme_switcher": theme_switcher,
            "websockets": websockets,
            "notifications": notifications,
        }
    layout["sidebar_left_mode_locked"] = sidebar_left_mode_locked
    layout["sidebar_right_mode_locked"] = sidebar_right_mode_locked

    # Inject keyboard-shortcut bindings if the subsystem is installed.
    # Skipped on HTMX partial swaps (the parent page already shipped them).
    if "conjunto.shortcuts" in getattr(django_settings, "INSTALLED_APPS", ()):
        if not getattr(request, "htmx", False):
            try:
                from conjunto.shortcuts.registry import bindings_for_request

                layout["shortcuts"] = {
                    "bindings": bindings_for_request(request),
                    "enabled": True,
                }
            except Exception:
                # Registry not yet frozen (very early request) — degrade silently.
                layout["shortcuts"] = {"bindings": [], "enabled": True}
        else:
            layout["shortcuts"] = {"bindings": [], "enabled": True}
    else:
        layout["shortcuts"] = {"bindings": [], "enabled": False}

    return {
        "globals": {
            "project_title": django_settings.PROJECT_TITLE,
            "version": __version__,
            "layout": layout["style"],  # kept for backwards-compat
        },
        "cj_layout": layout,
        "cj_toasts": _toast_config(),
        "cj_environment": _environment_banner(request),
        "menus": getattr(request, "menus", None),
        "vendor": Vendor.get_instance(),
    }


def settings(request):
    return {
        "scoped_settings": getattr(request, "scoped_settings", None),
        "PRODUCTION": getattr(django_settings, "PRODUCTION", False),
        "tabler": getattr(django_settings, "TABLER", {}),
    }
