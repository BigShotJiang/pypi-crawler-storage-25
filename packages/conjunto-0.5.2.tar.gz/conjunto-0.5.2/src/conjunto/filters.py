"""Reusable filter dataclasses for TableListView.

A `Filter` is a declarative description of one filter widget in the
table header. It knows (a) which GET param / queryset field it maps
to, (b) which template renders its widget, and (c) how to apply a
chosen value to a queryset.

The built-in flavours are:

- `Filter`: base class; applies a plain ``qs.filter(name=value)``.
- `ChoiceFilter`: single-select dropdown with explicit choices.
- `BooleanFilter`: three-way dropdown (all / yes / no).

Consumers typically declare them on the view::

    filters = [
        ChoiceFilter("status", label=_("Status"), choices=Project.STATUS),
        BooleanFilter("is_archived", label=_("Archived")),
    ]

For complex cases (ranges, dates, multi-select) set
``filterset_class`` on the view — ``TableListView`` then hands off
to ``django-filter`` and ignores ``filters``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Iterator

from django.db.models import QuerySet
from django.utils.translation import gettext_lazy as _

__all__ = ["Filter", "ChoiceFilter", "BooleanFilter"]


@dataclass
class Filter:
    """Base filter. Applies ``qs.filter(name=value)`` for truthy values."""

    name: str
    label: str = ""
    empty_label: str = _("—")
    widget_template: str = "conjunto/filters/_select.html"

    def apply(self, qs: QuerySet, value: Any) -> QuerySet:
        if value in (None, ""):
            return qs
        return qs.filter(**{self.name: value})

    def iter_choices(self) -> Iterator[tuple[str, str]]:
        return iter(())


@dataclass
class ChoiceFilter(Filter):
    """Single-select filter with explicit choices."""

    choices: Iterable[tuple[str, str]] = field(default_factory=tuple)

    def iter_choices(self) -> Iterator[tuple[str, str]]:
        yield "", str(self.empty_label)
        for value, label in self.choices:
            yield str(value), str(label)


@dataclass
class BooleanFilter(Filter):
    """Three-way filter: all / true / false."""

    true_label: str = _("Yes")
    false_label: str = _("No")

    def apply(self, qs: QuerySet, value: Any) -> QuerySet:
        if value == "1":
            return qs.filter(**{self.name: True})
        if value == "0":
            return qs.filter(**{self.name: False})
        return qs

    def iter_choices(self) -> Iterator[tuple[str, str]]:
        yield "", str(self.empty_label)
        yield "1", str(self.true_label)
        yield "0", str(self.false_label)
