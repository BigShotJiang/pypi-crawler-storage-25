"""Views for the conjunto settings page.

:class:`SettingsView` renders the full page and — when HTMX targets
``#cj-settings-card`` — only the rail+pane partial (so the active
class on the rail stays in sync with the visible pane).
:class:`SettingsFormView` handles a single :class:`ISettingsForm`
POST. On success it returns an empty 204 response decorated with a
``showToast`` HTMX trigger and ``HX-Reswap: none`` so the client-side
form element is left untouched (the user's typed values stay on
screen). On validation errors the view renders the single-form
partial (``page.html#settings-form``) with the bound form so HTMX can
swap only the affected ``<section>``.

External listeners (e.g. the ``System → Plugins`` *Sync from disk*
button) can still trigger ``settings:changed`` to force a full card
reload — the card's ``hx-trigger="settings:changed from:body"`` is
preserved for that use case — but individual form saves no longer do.
"""

from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import PermissionDenied
from django.http import Http404
from django.utils.translation import gettext_lazy as _
from django.views.generic import FormView, TemplateView
from django_htmx.http import trigger_client_event

from conjunto.htmx.views import HtmxRequestMixin
from conjunto.http import HttpResponseEmpty

from .interfaces import (
    ISettingsForm,
    ISettingsSection,
    find_form_by_name,
    resolve_section,
)

CARD_ID = "cj-settings-card"


class SettingsView(LoginRequiredMixin, TemplateView):
    """Full settings page, with HTMX partial support for card swaps.

    A click on a rail entry (or the ``settings:changed`` self-refresh)
    targets ``#cj-settings-card`` and re-renders the rail + pane
    together so the active class on the rail stays in sync with the
    visible pane.
    """

    template_name = "conjunto/settings/page.html"
    htmx_partial_template = "conjunto/settings/page.html#settings-card"

    def get_template_names(self):
        if self.request.htmx and self.request.htmx.target == CARD_ID:
            return [self.htmx_partial_template]
        return [self.template_name]

    # ------------------------------------------------------------------
    # data assembly
    # ------------------------------------------------------------------
    def _build_groups(self):
        """Return ``[(group_cls, [section_cls, ...]), ...]``, permission-filtered.

        Groups and sections are each sorted by their ``weight`` attribute.
        """
        sections_by_group: dict = {}
        for section_cls in ISettingsSection.enabled_plugins():
            if not section_cls.has_permission(self.request):
                continue
            group = getattr(section_cls, "group", None)
            if group is None:
                continue
            sections_by_group.setdefault(group, []).append(section_cls)

        groups = []
        for group in sorted(sections_by_group, key=lambda g: getattr(g, "weight", 0)):
            sections = sorted(
                sections_by_group[group],
                key=lambda s: getattr(s, "weight", 0),
            )
            groups.append((group, sections))
        return groups

    def _pick_active(self, groups):
        """Pick the active section from ``?section=<name>`` or fall back to
        the first available."""
        requested = self.request.GET.get("section")
        flat = [s for _, sections in groups for s in sections]
        if requested:
            for section_cls in flat:
                if getattr(section_cls, "name", None) == requested:
                    return section_cls
        return flat[0] if flat else None

    def _forms_for(self, active_section):
        """Build bound (unbound) form instances for each matching form plugin.

        Plugins may omit ``form_class`` when they supply a custom
        ``template`` — in that case the form value is ``None`` and the
        subsection is rendered purely via the custom template.
        """
        out = []
        active_name = getattr(active_section, "name", None)
        for form_cls in ISettingsForm.enabled_plugins():
            plugin = form_cls()
            target = resolve_section(getattr(plugin, "section", None))
            if target is None or getattr(target, "name", None) != active_name:
                continue
            form_class = plugin.get_form_class()
            if form_class is None:
                if plugin.get_template() is None:
                    continue
                out.append((plugin, None))
                continue
            kwargs = {"initial": plugin.get_initial(self.request)}
            instance = plugin.get_instance(self.request)
            if instance is not None:
                kwargs["instance"] = instance
            out.append((plugin, form_class(**kwargs)))
        return out

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        groups = self._build_groups()
        active = self._pick_active(groups)
        ctx["groups"] = groups
        ctx["active_section"] = active
        ctx["forms"] = self._forms_for(active) if active is not None else []
        ctx["card_id"] = CARD_ID
        return ctx


class SettingsFormView(LoginRequiredMixin, HtmxRequestMixin, FormView):
    """POST handler for a single :class:`ISettingsForm` plugin.

    Success: 204 empty body with ``HX-Reswap: none`` so the client form
    stays on screen untouched; an ``HX-Trigger`` fires ``showToast`` to
    confirm the save. No pane-wide reload is triggered.

    Error: renders the ``page.html#settings-form`` partial with the bound
    invalid form; HTMX replaces only the single ``<section>`` element.
    """

    template_name = "conjunto/settings/page.html#settings-form"
    enforce_htmx = True

    plugin: ISettingsForm
    active_section: type[ISettingsSection]

    # ------------------------------------------------------------------
    # dispatch: load plugin + permission check
    # ------------------------------------------------------------------
    def dispatch(self, request, *args, form_name=None, **kwargs):
        plugin_cls = find_form_by_name(form_name) if form_name else None
        if plugin_cls is None:
            raise Http404(f"Unknown settings form '{form_name}'")
        self.plugin = plugin_cls()
        section = resolve_section(getattr(self.plugin, "section", None))
        if section is None:
            raise Http404(f"Settings form '{form_name}' has no resolvable section.")
        if not section.has_permission(request):
            raise PermissionDenied
        self.active_section = section
        return super().dispatch(request, *args, **kwargs)

    # ------------------------------------------------------------------
    # form plumbing delegated to the plugin
    # ------------------------------------------------------------------
    def get_form_class(self):
        return self.plugin.get_form_class()

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        instance = self.plugin.get_instance(self.request)
        if instance is not None:
            kwargs["instance"] = instance
        # Plugin-supplied initial is a weaker default than POSTed data,
        # which ``super().get_form_kwargs`` already added under "data".
        plugin_initial = self.plugin.get_initial(self.request)
        if plugin_initial:
            kwargs["initial"] = {**plugin_initial, **kwargs.get("initial", {})}
        return kwargs

    # ------------------------------------------------------------------
    # success / error responses
    # ------------------------------------------------------------------
    def form_valid(self, form):
        self.plugin.save(form, self.request)
        # Build a 204 response directly — we bypass FormView's redirect
        # machinery because success_url is intentionally empty (no
        # navigation on save).
        response = HttpResponseEmpty()
        # Prevent HTMX from applying the form's outerHTML swap to the
        # empty body — otherwise the client form element disappears.
        response["HX-Reswap"] = "none"
        # Confirm the save with a toast via the conjunto toast pattern.
        trigger_client_event(
            response,
            "showToast",
            params={
                "message": str(_("Saved successfully")),
                "type": "success",
            },
        )
        # Plugin-supplied extra triggers (optional) — used by e.g. the
        # color-scheme form to sync the client-side localStorage cache.
        extra = self.plugin.extra_success_triggers(form, self.request)
        if extra:
            for event_name, params in extra.items():
                trigger_client_event(response, event_name, params=params)
        # Full-reload opt-in: settings that affect theme/layout-bound DOM
        # (color scheme, sidebar width, topbar position, language, …)
        # cannot be safely re-applied live — Tabler hangs the theme on
        # multiple surfaces (data-bs-theme, theme-dark class, sidebar
        # variant, charts, code highlight). A single ``HX-Refresh: true``
        # makes the next paint render against the freshly persisted
        # value with zero re-init logic on the client.
        if getattr(self.plugin, "requires_full_reload", False):
            response["HX-Refresh"] = "true"
        return response

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["plugin"] = self.plugin
        ctx["active_section"] = self.active_section
        return ctx
