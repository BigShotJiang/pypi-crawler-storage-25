"""Rename ``conjunto.sidebar_mode`` / ``conjunto.sidebar_width`` to
``conjunto.sidebar_left_mode`` / ``conjunto.sidebar_left_width``.

Part of the symmetric left/right sidebar refactor: every sidebar symbol
(setting key, body class, CSS class, JS helper) is now suffixed with the
side. Existing DEVICE/USER rows for the old keys must follow, otherwise
the resolver returns the default for the new key and silently drops the
user's persisted mode/width.
"""

from __future__ import annotations

from django.db import migrations

RENAMES = {
    "sidebar_mode": "sidebar_left_mode",
    "sidebar_width": "sidebar_left_width",
}


def _rename(apps, schema_editor, *, mapping: dict[str, str]) -> None:
    ScopedSetting = apps.get_model("conjunto_settings", "ScopedSetting")
    for old, new in mapping.items():
        ScopedSetting.objects.filter(namespace="conjunto", key=old).update(key=new)


def forwards(apps, schema_editor):
    _rename(apps, schema_editor, mapping=RENAMES)


def backwards(apps, schema_editor):
    _rename(apps, schema_editor, mapping={v: k for k, v in RENAMES.items()})


class Migration(migrations.Migration):

    dependencies = [
        ("conjunto_settings", "0008_session_lifetime_namespace_to_auth"),
    ]

    operations = [
        migrations.RunPython(forwards, backwards),
    ]
