"""Move session_lifetime_default / session_lifetime_remembered from the
``conjunto`` namespace into the ``auth`` namespace.

The keys are still about session expiry (an authentication concern), so
they were grouped with the rest of the auth-related scoped settings
(``auth.show_remember_me`` and friends). Existing DB rows must be
migrated, otherwise the resolver would return the default for the new
namespace and ignore any vendor- or tenant-level overrides set via the
old name.
"""

from __future__ import annotations

from django.db import migrations

OLD_NAMESPACE = "conjunto"
NEW_NAMESPACE = "auth"
KEYS = ("session_lifetime_default", "session_lifetime_remembered")


def _move_namespace(apps, schema_editor, *, src: str, dst: str) -> None:
    ScopedSetting = apps.get_model("conjunto_settings", "ScopedSetting")
    ScopedSetting.objects.filter(namespace=src, key__in=KEYS).update(namespace=dst)


def forwards(apps, schema_editor):
    _move_namespace(apps, schema_editor, src=OLD_NAMESPACE, dst=NEW_NAMESPACE)


def backwards(apps, schema_editor):
    _move_namespace(apps, schema_editor, src=NEW_NAMESPACE, dst=OLD_NAMESPACE)


class Migration(migrations.Migration):

    dependencies = [
        ("conjunto_settings", "0007_alter_device_id_alter_scopedsetting_id"),
    ]

    operations = [
        migrations.RunPython(forwards, backwards),
    ]
