"""Effective-value resolver for scoped settings.

Given ``(namespace, key, request)``, compute the value that wins the
priority overlay across all scope levels, obeying:

1. **Priority chain** (higher wins in the normal walk):
   ``USER > DEVICE > GROUP > TENANT > VENDOR``.

2. **Locks are floors** (``locked=True`` pins a value against higher
   scopes). The walk runs **lowest-to-highest**, so the first lock
   encountered wins — equivalently, the **lowest-priority** lock wins
   when multiple locks exist. A VENDOR lock is the ultimate authority;
   a TENANT lock blocks GROUP/DEVICE/USER but yields to a VENDOR lock.

3. **Site filter** is orthogonal to the scope chain. Queries match
   ``site = request.site OR site IS NULL``. Within a tier, a
   site-specific row beats a site-null row at the same scope ref.

4. **IGroupScope tie-breaks** when the user is in multiple groups:
   - Among locked rows, the **lowest-pk** group wins.
   - Among unlocked rows, the **highest-pk** group wins.

5. **Missing spec is strict**: ``SettingRegistry.get_spec`` raises
   ``KeyError``. This is intentional — a stale DB row without a
   registered spec is a code/data drift and should be visible.
"""

from collections import defaultdict
from decimal import Decimal
from typing import Any, Optional

from django.db.models import Q

from .models import Scope, ScopedSetting
from .registry import SettingRegistry, SettingSpec
from .scopes import IDeviceScope, IGroupScope, ITenantScope, IUserScope, IVendorScope

# Walk order: lowest-priority first, so that locks short-circuit at
# the lowest level and the lowest-priority lock wins.
_SCOPES_LOWEST_FIRST = [
    IVendorScope,
    ITenantScope,
    IGroupScope,
    IDeviceScope,
    IUserScope,
]


_MISSING = object()


def get_effective(namespace: str, key: str, request) -> Any:
    """Return the effective value of ``(namespace, key)`` for the request.

    Raises:
        KeyError: if the key is not registered in
            :class:`SettingRegistry` (strict mode).
    """
    info = get_resolution(namespace, key, request)
    return info.value


# ---------------------------------------------------------------------------
# Resolution introspection (used by the settings UI for locks + defaults).
# ---------------------------------------------------------------------------


class Resolution:
    """Outcome of a scoped-settings resolution.

    Used by UI layers that need to know **why** the effective value won
    (e.g. lock indicator, default-hint, fallback-scope label). Pure data;
    no DB access on attribute reads.
    """

    __slots__ = ("value", "winning_scope", "lock_scope", "fallback")

    def __init__(
        self,
        value: Any,
        winning_scope: Optional[int],
        lock_scope: Optional[int],
        fallback: Optional[tuple[Any, int]] = None,
    ):
        # ``value``           — effective value returned to callers.
        # ``winning_scope``   — Scope int that produced ``value`` (None
        #                       if value comes from the spec default).
        # ``lock_scope``      — lowest-priority Scope that holds a lock,
        #                       if any. ``None`` means no lock applies.
        # ``fallback``        — (value, scope) the user would fall back
        #                       to if their USER-scope row was deleted.
        #                       ``None`` means the spec default would
        #                       apply (no scope to display).
        self.value = value
        self.winning_scope = winning_scope
        self.lock_scope = lock_scope
        self.fallback = fallback

    @property
    def is_locked(self) -> bool:
        return self.lock_scope is not None


def get_resolution(namespace: str, key: str, request) -> Resolution:
    """Walk the scope chain and return a structured :class:`Resolution`.

    Mirrors :func:`get_effective` exactly for the ``value`` field but
    additionally reports which scope won, whether a lock applies, and
    what default would be shown if the USER-scope row was removed.

    Raises:
        KeyError: if the key is not registered in
            :class:`SettingRegistry` (strict mode).
    """
    spec = SettingRegistry.get_spec(namespace, key)

    current_site = getattr(request, "site", None)
    if current_site is not None and getattr(current_site, "pk", None) is None:
        current_site = None

    rows = ScopedSetting.objects.filter(namespace=namespace, key=key)
    if current_site is not None:
        rows = rows.filter(Q(site=current_site) | Q(site__isnull=True))
    else:
        rows = rows.filter(site__isnull=True)

    by_scope: dict[int, list[ScopedSetting]] = defaultdict(list)
    for row in rows:
        by_scope[row.scope].append(row)

    # Walk lowest-to-highest, tracking (a) the lowest-priority lock, if
    # any, that shadows higher tiers, (b) the highest-priority winner
    # below USER (fallback when USER row is deleted), and (c) the
    # ultimate winner.
    resolved: Any = _MISSING
    winning_scope: Optional[int] = None
    lock_scope: Optional[int] = None
    fallback_value: Any = _MISSING
    fallback_scope: Optional[int] = None

    for scope_cls in _SCOPES_LOWEST_FIRST:
        refs = scope_cls.resolve(request)
        if refs is None:
            continue
        tier_rows = by_scope.get(scope_cls.scope_id, [])
        if not tier_rows:
            continue
        winner = _pick_winner(tier_rows, scope_cls, refs, current_site)
        if winner is None:
            continue
        if winner.locked and lock_scope is None:
            # Lowest-priority lock wins and short-circuits the rest of
            # the walk for the effective value. Locks above this tier
            # are masked.
            lock_scope = scope_cls.scope_id
            resolved = winner.value
            winning_scope = scope_cls.scope_id
            # Locks below USER are also the fallback when the USER row
            # is deleted.
            if scope_cls.scope_id != Scope.USER:
                fallback_value = winner.value
                fallback_scope = scope_cls.scope_id
            break
        # Track every non-locked winner as the running effective value
        # *and* — when below USER scope — as the fallback the USER row
        # would defer to if removed.
        resolved = winner.value
        winning_scope = scope_cls.scope_id
        if scope_cls.scope_id != Scope.USER:
            fallback_value = winner.value
            fallback_scope = scope_cls.scope_id

    if resolved is _MISSING:
        # No row at any scope → spec default. Default values are passed
        # in the registrant's native type, so no coercion needed.
        return Resolution(
            value=spec.default,
            winning_scope=None,
            lock_scope=None,
            fallback=None,
        )

    fallback: Optional[tuple[Any, int]]
    if fallback_value is _MISSING:
        fallback = None
    else:
        fallback = (_coerce_value(spec, fallback_value), fallback_scope)

    return Resolution(
        value=_coerce_value(spec, resolved),
        winning_scope=winning_scope,
        lock_scope=lock_scope,
        fallback=fallback,
    )


def _coerce_value(spec: SettingSpec, value: Any) -> Any:
    """Coerce a JSON-stored value back into the spec's declared type.

    JSONField has no native ``Decimal`` — values registered with
    ``type="decimal"`` round-trip through a string and need explicit
    coercion on read. Other types (``str``, ``int``, ``bool``, ``text``,
    ``json``) round-trip natively through ``DjangoJSONEncoder`` and are
    passed through untouched.
    """
    if value is None:
        return value
    if spec.type == "decimal" and not isinstance(value, Decimal):
        return Decimal(str(value))
    return value


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _row_fk_for(scope_id: int, row: ScopedSetting) -> Optional[int]:
    """Return the FK pk this row uses for the given scope, or None."""
    if scope_id == Scope.VENDOR:
        return None
    if scope_id == Scope.USER:
        return row.user_id
    if scope_id == Scope.GROUP:
        return row.group_id
    if scope_id == Scope.DEVICE:
        return row.device_id
    if scope_id == Scope.TENANT:
        return row.tenant_id
    return None


def _site_id(row: ScopedSetting) -> Optional[int]:
    return row.site_id


def _pick_winner(
    tier_rows: list[ScopedSetting],
    scope_cls,
    refs: list,
    current_site,
) -> Optional[ScopedSetting]:
    """Pick the winning row for one tier, applying site + group rules.

    For each ``ref`` in ``refs`` we collect matching rows and prefer a
    site-specific row over a site-null row. Then we apply the tier's
    tie-break rule:

    - VENDOR / TENANT / DEVICE / USER tiers: at most one ref → at most
      one candidate after site tie-break → that row is the winner.
    - GROUP tier: one candidate per group the user belongs to. Within
      locked candidates, lowest-pk group wins; within unlocked, highest.
    """
    current_site_id = current_site.pk if current_site is not None else None

    # Per ref, pick the site-specific row if present else the site-null one.
    per_ref_winners: list[tuple[Optional[int], ScopedSetting]] = []
    for ref in refs:
        matching = [r for r in tier_rows if _row_fk_for(scope_cls.scope_id, r) == ref]
        if not matching:
            continue
        site_specific = [
            r
            for r in matching
            if _site_id(r) == current_site_id and current_site_id is not None
        ]
        if site_specific:
            per_ref_winners.append((ref, site_specific[0]))
        else:
            site_null = [r for r in matching if _site_id(r) is None]
            if site_null:
                per_ref_winners.append((ref, site_null[0]))

    if not per_ref_winners:
        return None

    if scope_cls.scope_id != Scope.GROUP:
        # Single-ref tiers: there's only one candidate.
        return per_ref_winners[0][1]

    # GROUP tie-break: prefer locked rows (lowest-pk group wins among
    # them), else highest-pk group among unlocked.
    locked = [(ref, row) for ref, row in per_ref_winners if row.locked]
    if locked:
        locked.sort(key=lambda pair: pair[0])  # lowest pk first
        return locked[0][1]
    per_ref_winners.sort(key=lambda pair: pair[0])  # lowest to highest
    return per_ref_winners[-1][1]
