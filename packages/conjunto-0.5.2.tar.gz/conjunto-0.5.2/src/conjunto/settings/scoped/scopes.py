"""Built-in :class:`IScope` implementations: Vendor, Tenant, Group,
Device, User.

All five are registered as GDAPS plugins automatically via the
``InterfaceMeta`` metaclass when this module is imported from
``conjunto.settings.apps.SettingsConfig.ready()``.

Priority chain (from ``weight``): USER (40) > DEVICE (30) > GROUP (20)
> TENANT (10) > VENDOR (0). Higher weight wins in the normal walk. The
resolver walks **lowest-to-highest** so that locks short-circuit at
their own level and the lowest-priority lock wins.
"""

from typing import Optional

from django.utils.translation import gettext_lazy as _

from .interfaces import IScope
from .models import Scope


# ---------------------------------------------------------------------------
# Vendor
# ---------------------------------------------------------------------------


class IVendorScope(IScope):
    """Global, vendor-level defaults. No FK — one row per
    (namespace, key, site)."""

    scope_id = Scope.VENDOR
    name = "vendor"
    title = _("Vendor")
    icon = "building-store"
    weight = 0

    @classmethod
    def resolve(cls, request) -> Optional[list[Optional[int]]]:
        # Vendor scope always applies. The "None" element signals
        # "no FK needed" to the resolver.
        return [None]

    @classmethod
    def filter_kwargs(cls, ref: Optional[int]) -> dict:
        return {
            "scope": cls.scope_id,
            "user__isnull": True,
            "group__isnull": True,
            "device__isnull": True,
            "tenant__isnull": True,
        }

    @classmethod
    def can_edit(cls, request, ref: Optional[int]) -> bool:
        user = getattr(request, "user", None)
        if user is None or not user.is_authenticated:
            return False
        return user.has_perm("conjunto_settings.manage_vendor_settings")


# ---------------------------------------------------------------------------
# Tenant
# ---------------------------------------------------------------------------


class ITenantScope(IScope):
    """Tenant-scoped settings. Resolves the active tenant from
    ``request.tenant`` which is populated by
    :class:`~conjunto.middleware.ConjuntoMiddleware`.

    Returns ``None`` if no tenant is active for this request.
    """

    scope_id = Scope.TENANT
    name = "tenant"
    title = _("Tenant")
    icon = "building"
    weight = 10

    @classmethod
    def resolve(cls, request) -> Optional[list[Optional[int]]]:
        tenant = getattr(request, "tenant", None)
        if tenant is not None and getattr(tenant, "pk", None) is not None:
            return [tenant.pk]
        return None

    @classmethod
    def filter_kwargs(cls, ref: Optional[int]) -> dict:
        return {"scope": cls.scope_id, "tenant_id": ref}

    @classmethod
    def can_edit(cls, request, ref: Optional[int]) -> bool:
        user = getattr(request, "user", None)
        if user is None or not user.is_authenticated:
            return False
        if not user.has_perm("conjunto_settings.change_scopedsetting"):
            return False
        from django.contrib.auth.models import Group
        from conjunto.tenants.utils import get_tenant_model

        try:
            tenant = get_tenant_model().objects.get(pk=ref)
        except Exception:
            return False
        # A user can edit tenant-scoped settings if they are in the
        # tenant's admin role group (``tenant:<slug>:tenant_admin``).
        try:
            admin_group = Group.objects.get(name=f"tenant:{tenant.slug}:tenant_admin")
        except Group.DoesNotExist:
            return False
        return admin_group.user_set.filter(pk=user.pk).exists()

    @classmethod
    def ref_display(cls, ref: Optional[int]) -> str:
        if ref is None:
            return ""
        from conjunto.tenants.utils import get_tenant_model

        try:
            return str(get_tenant_model().objects.get(pk=ref))
        except Exception:
            return f"tenant#{ref}"


# ---------------------------------------------------------------------------
# Group
# ---------------------------------------------------------------------------


class IGroupScope(IScope):
    """Django ``auth.Group``-scoped settings.

    A user may belong to multiple groups → ``resolve()`` returns all of
    their group pks sorted ASC. Tie-break rules applied by the resolver:

    - In the normal (unlocked) walk, the **highest-pk** group row wins.
    - Among locked rows within this tier, the **lowest-pk** group wins.

    Deterministic but unspecified relative to Django's Group ordering.
    Document loudly.
    """

    scope_id = Scope.GROUP
    name = "group"
    title = _("Group")
    icon = "users"
    weight = 20

    @classmethod
    def resolve(cls, request) -> Optional[list[Optional[int]]]:
        user = getattr(request, "user", None)
        if user is None or not user.is_authenticated:
            return None
        pks = list(user.groups.order_by("pk").values_list("pk", flat=True))
        return pks or None

    @classmethod
    def filter_kwargs(cls, ref: Optional[int]) -> dict:
        return {"scope": cls.scope_id, "group_id": ref}

    @classmethod
    def can_edit(cls, request, ref: Optional[int]) -> bool:
        user = getattr(request, "user", None)
        if user is None or not user.is_authenticated:
            return False
        if not user.has_perm("conjunto_settings.change_scopedsetting"):
            return False
        return user.groups.filter(pk=ref).exists()

    @classmethod
    def ref_display(cls, ref: Optional[int]) -> str:
        if ref is None:
            return ""
        from django.contrib.auth.models import Group

        try:
            return Group.objects.get(pk=ref).name
        except Group.DoesNotExist:
            return f"group#{ref}"


# ---------------------------------------------------------------------------
# Device
# ---------------------------------------------------------------------------


class IDeviceScope(IScope):
    """Browser/device-scoped settings. Requires
    :class:`conjunto.middleware.ScopedSettingsMiddleware` to have set
    ``request.device``."""

    scope_id = Scope.DEVICE
    name = "device"
    title = _("Device")
    icon = "device-laptop"
    weight = 30

    @classmethod
    def resolve(cls, request) -> Optional[list[Optional[int]]]:
        device = getattr(request, "device", None)
        if device is None or getattr(device, "pk", None) is None:
            return None
        return [device.pk]

    @classmethod
    def filter_kwargs(cls, ref: Optional[int]) -> dict:
        return {"scope": cls.scope_id, "device_id": ref}

    @classmethod
    def can_edit(cls, request, ref: Optional[int]) -> bool:
        device = getattr(request, "device", None)
        if device is None:
            return False
        return device.pk == ref

    @classmethod
    def ref_display(cls, ref: Optional[int]) -> str:
        return f"device#{ref}" if ref is not None else ""


# ---------------------------------------------------------------------------
# User
# ---------------------------------------------------------------------------


class IUserScope(IScope):
    """Per-user settings. Only applicable when the request is
    authenticated."""

    scope_id = Scope.USER
    name = "user"
    title = _("User")
    icon = "user"
    weight = 40

    @classmethod
    def resolve(cls, request) -> Optional[list[Optional[int]]]:
        user = getattr(request, "user", None)
        if user is None or not user.is_authenticated:
            return None
        return [user.pk]

    @classmethod
    def filter_kwargs(cls, ref: Optional[int]) -> dict:
        return {"scope": cls.scope_id, "user_id": ref}

    @classmethod
    def can_edit(cls, request, ref: Optional[int]) -> bool:
        user = getattr(request, "user", None)
        if user is None or not user.is_authenticated:
            return False
        if not user.has_perm("conjunto_settings.change_scopedsetting"):
            return False
        return user.pk == ref

    @classmethod
    def ref_display(cls, ref: Optional[int]) -> str:
        if ref is None:
            return ""
        from django.contrib.auth import get_user_model

        try:
            return str(get_user_model().objects.get(pk=ref))
        except Exception:
            return f"user#{ref}"
