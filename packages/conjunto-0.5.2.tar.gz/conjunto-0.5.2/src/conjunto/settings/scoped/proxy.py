"""Request-level proxy for scoped settings.

Attached by :class:`conjunto.middleware.ScopedSettingsMiddleware` as
``request.scoped_settings``. Exposes two API surfaces:

- **Python/view code** — explicit method call with strict or lenient
  default behavior::

      value = request.scoped_settings.get("core", "theme")
      value = request.scoped_settings.get("core", "theme", default="light")

- **Template code** — attribute access sugar, tolerant of missing
  specs (renders as empty string)::

      {{ request.scoped_settings.core.theme }}

Both paths share the same per-request cache, so the effective-value
resolver runs at most once per (namespace, key) per request regardless
of API used.
"""

from typing import Any

from .resolver import get_effective

_MISSING = object()


class ScopedSettingsProxy:
    """Per-request facade over :func:`get_effective`."""

    def __init__(self, request):
        self._request = request
        self._cache: dict[tuple[str, str], Any] = {}

    def get(
        self,
        namespace: str,
        key: str,
        default: Any = _MISSING,
    ) -> Any:
        """Return the effective value.

        Without ``default``, missing specs raise ``KeyError`` — that is
        the strict mode callers should prefer for explicit lookups.
        With ``default``, a missing spec falls back to the provided
        value (useful for optional integrations).
        """
        cache_key = (namespace, key)
        if cache_key in self._cache:
            return self._cache[cache_key]
        try:
            value = get_effective(namespace, key, self._request)
        except KeyError:
            if default is _MISSING:
                raise
            value = default
        self._cache[cache_key] = value
        return value

    def __getattr__(self, namespace: str) -> "Namespace":
        # Only called for attributes not found normally (i.e. not
        # ``_request``, ``_cache``, ``get``). Returning a Namespace
        # object enables ``proxy.<namespace>.<key>`` sugar.
        if namespace.startswith("_"):
            raise AttributeError(namespace)
        return Namespace(self, namespace)

    def invalidate(self, namespace: str | None = None, key: str | None = None) -> None:
        """Clear the per-request cache for a key, a namespace, or all."""
        if namespace is None:
            self._cache.clear()
        elif key is None:
            self._cache = {k: v for k, v in self._cache.items() if k[0] != namespace}
        else:
            self._cache.pop((namespace, key), None)


class Namespace:
    """Attribute-access helper for template-side lookup.

    Returns the empty string for missing specs so templates never break
    on a typo or a deregistered key.
    """

    def __init__(self, proxy: ScopedSettingsProxy, namespace: str):
        self._proxy = proxy
        self._namespace = namespace

    def __getattr__(self, key: str) -> Any:
        if key.startswith("_"):
            raise AttributeError(key)
        return self._proxy.get(self._namespace, key, default="")

    def __getitem__(self, key: str) -> Any:
        return self._proxy.get(self._namespace, key, default="")
