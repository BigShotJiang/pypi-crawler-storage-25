"""Conjunto-owned WebSocket routing.

Aggregates :class:`~conjunto.api.interfaces.IWebsocketURL` plugin
contributions into a single ``websocket_urlpatterns`` list and wraps
the resulting :class:`channels.routing.URLRouter` in a
``ProtocolTypeRouter`` plus :class:`channels.auth.AuthMiddlewareStack`.

Consumer projects keep their ``asgi.py`` to a single line::

    # myproject/asgi.py
    from conjunto.routing import asgi_application
    application = asgi_application()

Plugins must declare ``IWebsocketURL`` subclasses in modules that are
loaded at Django startup (typically ``<plugin>/routing.py`` imported
from the plugin's ``AppConfig.ready()``). Lazy imports here avoid
loading the ORM during module import.
"""

from __future__ import annotations


def _collect_websocket_urlpatterns():
    """Return the concatenated ``urlpatterns`` of every enabled plugin."""

    from conjunto.api.interfaces import IWebsocketURL

    patterns = []
    for plugin in IWebsocketURL:
        patterns.extend(plugin.urlpatterns)
    return patterns


class _LazyWebsocketURLPatterns(list):
    """A list whose contents are populated on first iteration.

    Plugins register ``IWebsocketURL`` implementations during Django
    startup (``AppConfig.ready()``). Building the list at module import
    time would lose every plugin loaded after conjunto. Behaving like a
    plain list keeps the public surface trivial for callers that
    iterate or pass it to ``URLRouter``.
    """

    _populated = False

    def _populate(self):
        if not self._populated:
            super().extend(_collect_websocket_urlpatterns())
            self._populated = True

    def __iter__(self):
        self._populate()
        return super().__iter__()

    def __len__(self):
        self._populate()
        return super().__len__()

    def __getitem__(self, item):
        self._populate()
        return super().__getitem__(item)

    def __contains__(self, item):
        self._populate()
        return super().__contains__(item)


websocket_urlpatterns = _LazyWebsocketURLPatterns()
"""Aggregated websocket patterns, populated lazily from ``IWebsocketURL``."""


def asgi_application():
    """Return a fully wired Channels ``ProtocolTypeRouter``.

    HTTP requests fall through to Django's standard ASGI app; websocket
    requests are routed via :data:`websocket_urlpatterns` behind
    :class:`channels.auth.AuthMiddlewareStack` so consumers can rely on
    ``self.scope["user"]``.
    """

    from channels.auth import AuthMiddlewareStack
    from channels.routing import ProtocolTypeRouter, URLRouter
    from django.core.asgi import get_asgi_application

    django_asgi_app = get_asgi_application()

    return ProtocolTypeRouter(
        {
            "http": django_asgi_app,
            "websocket": AuthMiddlewareStack(URLRouter(list(websocket_urlpatterns))),
        }
    )
