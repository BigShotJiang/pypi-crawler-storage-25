import logging

from django import forms
from django.forms.widgets import FileInput
from django.utils.translation import gettext_lazy as _

from conjunto.forms.fields import (
    DEFAULT_ALLOWED_ATTRIBUTES,
    DEFAULT_ALLOWED_PROTOCOLS,
    DEFAULT_ALLOWED_TAGS,
    ColorField,
    IconField,
    PartialDate,
    PartialDateField,
    PartialDatePrecision,
    PersistentFileField,
    SafeHTMLField,
    TimeField,
)
from conjunto.forms.widgets.color_select import (
    DEFAULT_LIGHT_COLORS,
    TABLER_COLORS,
    ColorSelect,
    ColorSelectMultiple,
)
from conjunto.forms.widgets.button_group_select import (
    ButtonGroupSelect,
    ButtonGroupSelectMultiple,
)
from conjunto.forms.widgets.icon_select import (
    IconSelect,
    IconSelectMultiple,
)
from conjunto.forms.tenant import TenantFormMixin  # noqa: F401
from conjunto.forms.widgets.decimal_stepper import DecimalStepperInput
from conjunto.forms.widgets.integer_stepper import IntegerStepperInput
from conjunto.forms.widgets.persistent_file import PersistentFileWidget
from conjunto.forms.widgets.time_picker import TimePickerInput

logger = logging.getLogger(__name__)

__all__ = [
    "DEFAULT_ALLOWED_ATTRIBUTES",
    "DEFAULT_ALLOWED_PROTOCOLS",
    "DEFAULT_ALLOWED_TAGS",
    "DEFAULT_LIGHT_COLORS",
    "TABLER_COLORS",
    "ButtonGroupSelect",
    "ButtonGroupSelectMultiple",
    "ColorField",
    "ColorSelect",
    "ColorSelectMultiple",
    "DecimalStepperInput",
    "DependentFieldsMixin",
    "ErrorLogMixin",
    "IconField",
    "IconSelect",
    "IconSelectMultiple",
    "IntegerStepperInput",
    "PartialDate",
    "PartialDateField",
    "PartialDatePrecision",
    "PersistentFileField",
    "PersistentFileWidget",
    "SafeHTMLField",
    "TimeField",
    "TimePickerInput",
]


class DependentFieldsMixin:
    """Mixin for forms with dependent fields, auto-wired for HTMX.

    Define ``<fieldname>_changed(value)`` methods to react to field changes.
    The mixin auto-discovers these methods, sets ``hx-*`` attributes on the
    trigger field widgets, and calls the callbacks on form instantiation so
    that dependent fields are always in a consistent state.

    Example::

        class SignupForm(DependentFieldsMixin, forms.ModelForm):
            update_url = reverse_lazy("signup_form_fragment")

            def country_changed(self, value):
                if value:
                    self.fields["federal_state"].queryset = (
                        FederalState.objects.filter(country=value)
                    )

    File inputs (``FileField``, ``ImageField``) automatically receive the
    ``hx-preserve`` attribute so that user-selected files are not lost
    when a trigger field causes an HTMX re-render. For forms where files
    must also survive POST validation errors, use
    :class:`~conjunto.forms.PersistentFileField` instead of the standard
    ``FileField``.

    The mixin uses ``hx-get`` (no CSRF needed), ``hx-include="closest form"``
    (sends all sibling field values so the server has full context), and
    ``hx-target`` / ``hx-swap="outerHTML"`` to replace the target element
    with the re-rendered version.

    Performance tuning attributes:
        update_url: The URL (str or lazy) for the HTMX fragment view that
            re-renders this form. Required.
        hx_target: The CSS selector for ``hx-target`` (default: whole form).
            Defaults to ``"closest form"`` which replaces the entire
            ``<form>`` element. Override this if your fragment view renders
            only an inner container (e.g. ``"#form-body"``).
        hx_swap: The swap strategy for ``hx-swap``. Defaults to ``"outerHTML"``.
        hx_trigger: The trigger spec for ``hx-trigger`` (default: ``"change"``).
            Override on text-like inputs to add debouncing, e.g.
            ``"keyup changed delay:300ms"``.
        hx_indicator: Optional CSS selector for ``hx-indicator``. When set,
            HTMX adds the ``htmx-request`` class to the matched element while
            the request is in flight — perfect for spinners/loaders.
        trigger_targets: Optional ``{field_name: css_selector}`` mapping. When
            a trigger field has an entry here, only that subtree is swapped
            (via ``hx-target`` + ``hx-select``) instead of the whole form.
            This is dramatically faster on large forms because the browser
            replaces a much smaller DOM subtree and other inputs keep their
            focus and state. Example::

                trigger_targets = {"country": "#div_id_federal_state"}
        disable_trigger_autocomplete: When ``True``, every trigger widget
            gets ``autocomplete="off"``. This forces a hard reset to the
            server-rendered initial value on reload / back-navigation /
            bfcache restore — at the cost of losing the user's last-entered
            value. The default (``False``) leaves the browser's form-restore
            behaviour intact.

    Selective callback execution:
        When a fragment view passes ``triggered_field=<name>`` to the form
        ``__init__`` (the bundled :class:`DependentFieldsView` does this from
        the ``HX-Trigger-Name`` HTMX header), only that one ``*_changed()``
        callback runs — saving DB lookups and queryset evaluations on every
        re-render. Caveat: transitive dependencies (callback A sets a
        queryset that callback B depends on) must be re-established inside
        the triggered callback.
    """

    update_url = None
    hx_target: str = "closest form"
    hx_swap: str = "outerHTML"
    hx_trigger: str = "change"
    hx_indicator: str | None = None
    trigger_targets: dict[str, str] | None = None
    disable_trigger_autocomplete: bool = False

    def get_update_url(self):
        """Return the URL for the HTMX fragment view."""
        return self.update_url or "."

    def _get_trigger_fields(self) -> list[str]:
        """Auto-discover which fields have a ``*_changed()`` callback."""
        result = []
        for name in dir(self):
            if not name.endswith("_changed"):
                continue
            field_name = name.removesuffix("_changed")
            if field_name in self.fields and callable(getattr(self, name)):
                result.append(field_name)
        return result

    def __init__(self, *args, triggered_field: str | None = None, **kwargs):
        super().__init__(*args, **kwargs)

        # Track which (if any) field actually triggered an HTMX re-render —
        # used by apply_dependencies() to skip irrelevant callbacks.
        self._triggered_field = triggered_field

        url = self.get_update_url()
        trigger_fields = self._get_trigger_fields()
        targets = self.trigger_targets or {}

        for field_name in trigger_fields:
            attrs = {
                "hx-get": str(url),
                "hx-trigger": self.hx_trigger,
                "hx-include": "closest form",
                "hx-swap": self.hx_swap,
            }
            # Per-trigger targeted swap: server still renders the full form
            # but the client only swaps the named subtree (hx-select extracts
            # it from the response, hx-target points at the DOM mount point).
            per_target = targets.get(field_name)
            if per_target:
                attrs["hx-target"] = per_target
                attrs["hx-select"] = per_target
            else:
                attrs["hx-target"] = self.hx_target
            if self.hx_indicator:
                attrs["hx-indicator"] = self.hx_indicator
            self.fields[field_name].widget.attrs.update(attrs)
            if self.disable_trigger_autocomplete:
                # setdefault on the widget itself so an explicit user-set
                # autocomplete value (e.g. "username") is never overridden.
                self.fields[field_name].widget.attrs.setdefault("autocomplete", "off")

        # Preserve file inputs during HTMX swaps so that user-selected
        # files are not lost when a trigger field causes a re-render.
        for field_name, field in self.fields.items():
            if isinstance(field.widget, FileInput):
                field.widget.attrs.setdefault("hx-preserve", True)

        # Resolve current data: positional arg[0] or kwargs["data"]
        data = None
        if args:
            data = args[0]
        elif "data" in kwargs:
            data = kwargs["data"]

        initial = kwargs.get("initial", {})

        self.apply_dependencies(data=data, initial=initial)

    def apply_dependencies(self, data=None, initial=None):
        """Call ``*_changed()`` callbacks with current field values.

        If ``self._triggered_field`` is set (passed via the ``triggered_field``
        kwarg in ``__init__``), only that one callback runs. Otherwise all
        ``*_changed()`` callbacks run.

        Priority chain for the value passed to each callback:

        1. **Bound data** (POST submit) — ``self.data[field_name]``
        2. **Initial from kwargs** (HTMX re-render or explicit ``initial=``)
        3. **Field's own initial** (``field.initial``, the default on the
           field definition)
        4. **Model instance** (edit forms with a saved instance)
        5. **None** — callback is still called so it can set defaults

        Callbacks are **always** called, even with ``value=None``.
        """
        all_triggers = self._get_trigger_fields()
        if self._triggered_field and self._triggered_field in all_triggers:
            fields_to_process = [self._triggered_field]
        else:
            fields_to_process = all_triggers

        for field_name in fields_to_process:
            callback = getattr(self, f"{field_name}_changed")
            value = None

            # 1. Bound data (POST submit)
            if data and field_name in data:
                raw = data.get(field_name)
                value = self._resolve_field_value(field_name, raw)
            # 2. Initial from kwargs (HTMX re-render or explicit initial=)
            elif initial and field_name in initial:
                raw = initial.get(field_name)
                value = self._resolve_field_value(field_name, raw)
            # 3. Field's own initial value (form field default)
            elif (
                field_name in self.fields
                and self.fields[field_name].initial is not None
            ):
                value = self.fields[field_name].initial
            # 4. Model instance (edit forms with a saved instance)
            elif (
                hasattr(self, "instance")
                and self.instance
                and getattr(self.instance, "pk", None)
                and hasattr(self.instance, field_name)
            ):
                value = getattr(self.instance, field_name)
            # 5. None — callback still gets called so it can set defaults

            callback(value)

    def _resolve_field_value(self, field_name: str, raw):
        """Resolve a raw value (e.g. PK string) to a model instance for FK fields.

        For fields with a ``queryset`` attribute (ModelChoiceField etc.), looks
        up the instance by primary key. For all other fields, returns the raw
        value unchanged.
        """
        field = self.fields.get(field_name)
        if raw and field and hasattr(field, "queryset") and field.queryset is not None:
            try:
                return field.queryset.get(pk=raw)
            except (field.queryset.model.DoesNotExist, ValueError, TypeError):
                return None
        return raw

    def fields_required(self, fields: str | list[str], msg: str = None) -> None:
        """Mark *fields* as required during ``clean()``.

        Useful for conditionally required fields whose ``required`` attribute
        is toggled by a ``*_changed()`` callback.

        Args:
            fields: A single field name or list of field names.
            msg: Custom error message. Defaults to "This field is required.".
        """
        if isinstance(fields, str):
            fields = [fields]
        for field in fields:
            if not self.cleaned_data.get(field, ""):
                error = forms.ValidationError(msg or _("This field is required."))
                self.add_error(field, error)


class ErrorLogMixin:
    """A mixin that can be added to a Form during development/debugging, so that it
    logs all form errors."""

    def add_error(self, field, error):
        if field:
            logger.info("Form error on field %s: %s", field, error)
        else:
            logger.info("Form error: %s", error)
        super().add_error(field, error)
