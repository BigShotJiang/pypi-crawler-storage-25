"""Form fields for conjunto.

This module provides reusable form fields with secure defaults.
"""

from __future__ import annotations

from datetime import time
from typing import Iterable, Literal

import bleach
from django import forms
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import UploadedFile
from django.utils.translation import gettext_lazy as _

from conjunto.forms.widgets.color_select import (
    TABLER_COLORS,
    ColorSelect,
    ColorSelectMultiple,
)
from conjunto.forms.widgets.icon_select import (
    IconSelect,
    IconSelectMultiple,
)
from conjunto.forms.widgets.persistent_file import PersistentFileWidget
from conjunto.forms.widgets.time_picker import TimePickerInput


# Restrictive but practical default whitelist for WYSIWYG editor output
# (TinyMCE, CKEditor, etc.). Deny-by-default — anything not listed here is
# stripped or escaped. Extend explicitly via the ``allowed_*`` parameters.
DEFAULT_ALLOWED_TAGS: frozenset[str] = frozenset(
    {
        "p",
        "br",
        "strong",
        "em",
        "u",
        "s",
        "sub",
        "sup",
        "ul",
        "ol",
        "li",
        "a",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "blockquote",
        "code",
        "pre",
        "hr",
        "span",
    }
)

DEFAULT_ALLOWED_ATTRIBUTES: dict[str, list[str]] = {
    "a": ["href", "title", "rel", "target"],
    "span": ["class"],
}

DEFAULT_ALLOWED_PROTOCOLS: frozenset[str] = frozenset({"http", "https", "mailto"})


class SafeHTMLField(forms.CharField):
    """A ``CharField`` that sanitizes HTML input on the server using ``bleach``.

    This field is intended for content produced by WYSIWYG/rich-text editors
    (TinyMCE, CKEditor, etc.). Even when the editor renders only "safe"
    output client-side, the server **must not** trust it — a malicious user
    can bypass the editor and POST arbitrary HTML directly. ``SafeHTMLField``
    enforces a deny-by-default whitelist of tags, attributes and URL
    protocols, removing or escaping anything else.

    Defense in depth: this is the *first* layer. Templates that render the
    cleaned value with ``|safe`` rely on this sanitization having happened.

    Args:
        allowed_tags: Iterable of tag names. Defaults to
            :data:`DEFAULT_ALLOWED_TAGS`.
        allowed_attributes: Mapping of tag name to list of attribute names,
            or a callable as accepted by :func:`bleach.clean`. Defaults to
            :data:`DEFAULT_ALLOWED_ATTRIBUTES`.
        allowed_protocols: Iterable of URL protocols allowed in attributes
            like ``href`` / ``src``. Defaults to
            :data:`DEFAULT_ALLOWED_PROTOCOLS` (``http``, ``https``,
            ``mailto``).
        strip_disallowed: If ``True`` (default), disallowed tags are removed
            entirely. If ``False``, they are HTML-escaped so the literal
            markup is visible to the user. (Named distinctly from
            ``CharField``'s ``strip`` whitespace-trimming kwarg.)
        strip_comments: If ``True`` (default), HTML comments are removed.

    Example::

        from conjunto.forms import SafeHTMLField

        class ArticleForm(forms.Form):
            body = SafeHTMLField(
                allowed_tags=["p", "br", "strong", "em", "a", "img"],
                allowed_attributes={"a": ["href"], "img": ["src", "alt"]},
            )

    The default widget is a plain :class:`~django.forms.Textarea`. Downstream
    projects can swap in a TinyMCE / CKEditor widget by passing ``widget=``
    explicitly — sanitization happens regardless of the widget used.
    """

    widget = forms.Textarea
    default_error_messages = {
        "invalid": _("Enter valid HTML content."),
    }

    def __init__(
        self,
        *args,
        allowed_tags: Iterable[str] | None = None,
        allowed_attributes: dict | None = None,
        allowed_protocols: Iterable[str] | None = None,
        strip_disallowed: bool = True,
        strip_comments: bool = True,
        **kwargs,
    ):
        # Note: parameter is named ``strip_disallowed`` rather than ``strip``
        # because ``CharField`` already accepts a ``strip`` kwarg (whitespace
        # trimming on input). Using a distinct name avoids that collision.
        # Materialize iterables to lists — bleach expects list/set, not a
        # one-shot generator. ``None`` means "use the conjunto default".
        self.allowed_tags = list(
            allowed_tags if allowed_tags is not None else DEFAULT_ALLOWED_TAGS
        )
        self.allowed_attributes = (
            allowed_attributes
            if allowed_attributes is not None
            else dict(DEFAULT_ALLOWED_ATTRIBUTES)
        )
        self.allowed_protocols = list(
            allowed_protocols
            if allowed_protocols is not None
            else DEFAULT_ALLOWED_PROTOCOLS
        )
        self.strip_disallowed = strip_disallowed
        self.strip_comments = strip_comments
        super().__init__(*args, **kwargs)

    def to_python(self, value) -> str:
        """Return the sanitized HTML string.

        Empty values follow the standard ``CharField`` contract (returned as
        an empty string). Non-empty values are passed through
        :func:`bleach.clean`.
        """
        value = super().to_python(value)
        if value in self.empty_values:
            return value
        return bleach.clean(
            value,
            tags=self.allowed_tags,
            attributes=self.allowed_attributes,
            protocols=self.allowed_protocols,
            strip=self.strip_disallowed,
            strip_comments=self.strip_comments,
        )


def _smart_parse_time(value, *, format_12h: bool = False) -> time | None:
    """Parse user time input liberally; return ``None`` on unparseable values.

    Mirrors the JS-side parser in ``conjunto/js/time_picker_input.js`` so that
    a form submitted by a non-JS client (or before JS has run) still validates.

    Rules by digit count, after stripping non-digit characters and any optional
    AM/PM suffix:

    * 1 digit:  hour only (``"5"`` → ``05:00``).
    * 2 digits: ``HH`` if ``≤ 23``, else first digit is the hour and the second
      is the **tens** digit of the minute (``"45"`` → ``04:50``,
      ``"73"`` → ``07:30``).
    * 3 digits: ``HH:M0`` if the first two digits are a valid hour
      (``"230"`` → ``23:00``); otherwise ``0H:MM``
      (``"730"`` → ``07:30``, ``"405"`` → ``04:05``).
    * 4 digits: ``HH:MM`` directly.
    """
    if value in (None, ""):
        return None
    s = str(value).strip().lower()
    if not s:
        return None

    suffix: str | None = None
    if format_12h:
        for marker in ("am", "pm"):
            if s.endswith(marker):
                suffix = marker
                s = s[: -len(marker)].strip()
                break

    digits = "".join(c for c in s if c.isdigit())
    if not digits or len(digits) > 4:
        return None

    if len(digits) == 1:
        h, m = int(digits), 0
    elif len(digits) == 2:
        v = int(digits)
        if v <= 23:
            h, m = v, 0
        else:
            h = int(digits[0])
            m = int(digits[1]) * 10
    elif len(digits) == 3:
        first_two = int(digits[:2])
        if first_two <= 23:
            h = first_two
            m = int(digits[2]) * 10
        else:
            h = int(digits[0])
            m = int(digits[1:])
    else:  # 4 digits
        h = int(digits[:2])
        m = int(digits[2:])

    if suffix == "pm" and h < 12:
        h += 12
    elif suffix == "am" and h == 12:
        h = 0

    if not (0 <= h <= 23 and 0 <= m <= 59):
        return None
    return time(h, m)


def _round_time(t: time, round_to: int, mode: Literal["up", "down", "nearest"]) -> time:
    """Round ``t`` to the next ``round_to``-minute step.

    ``mode`` is one of:

    * ``"down"``: round towards 00:00 (``14:23`` step 15 → ``14:15``).
    * ``"up"``: round away from 00:00 (``14:23`` step 15 → ``14:30``). When the
      result reaches 24:00 it wraps to 00:00 — ``time`` has no day component.
    * ``"nearest"``: standard half-up rounding (``14:22`` → ``14:15``,
      ``14:23`` → ``14:30``).
    """
    total = t.hour * 60 + t.minute
    if mode == "down":
        rounded = (total // round_to) * round_to
    elif mode == "up":
        rounded = -(-total // round_to) * round_to
    elif mode == "nearest":
        rounded = round(total / round_to) * round_to
    else:
        raise ValueError(f"Unknown round mode: {mode!r}")
    rounded %= 24 * 60
    return time(rounded // 60, rounded % 60)


class TimeField(forms.TimeField):
    """Drop-in replacement for :class:`forms.TimeField` with conjunto extras.

    Adds:

    * smart-parsing of bare-digit input on the server side (defense in depth
      mirror of the JS in :class:`TimePickerInput`),
    * optional snap-step buttons in the UI (``snap=15``),
    * optional 12h-display mode (``format_12h=True``) — internally still
      ``datetime.time`` (24h),
    * optional rounding of the cleaned value to the next ``round_to``-minute
      step (``round_to=15, round_mode="up"|"down"|"nearest"``).

    Example::

        class TimeEntryForm(forms.Form):
            start_time = TimeField(snap=15, round_to=15, round_mode="down")
            end_time   = TimeField(snap=15, round_to=15, round_mode="up")
    """

    widget = TimePickerInput

    def __init__(
        self,
        *args,
        snap: int | None = None,
        format_12h: bool = False,
        show_buttons: bool = True,
        round_to: int | None = None,
        round_mode: Literal["up", "down", "nearest"] = "nearest",
        **kwargs,
    ):
        # Build a TimePickerInput with the UX flags unless the caller passed
        # an explicit widget.
        if "widget" not in kwargs:
            kwargs["widget"] = TimePickerInput(
                snap=snap,
                format_12h=format_12h,
                show_buttons=show_buttons,
            )
        super().__init__(*args, **kwargs)
        self.format_12h = format_12h
        self.round_to = round_to
        self.round_mode = round_mode

    def to_python(self, value):
        if value in self.empty_values:
            return None
        try:
            return super().to_python(value)
        except ValidationError:
            parsed = _smart_parse_time(value, format_12h=self.format_12h)
            if parsed is None:
                raise
            return parsed

    def clean(self, value):
        result = super().clean(value)
        if result is not None and self.round_to:
            result = _round_time(result, self.round_to, self.round_mode)
        return result


class ColorField(forms.ChoiceField):
    """A ``ChoiceField`` rendered as a Tabler ``form-colorinput`` swatch row.

    Convenience wrapper around :class:`~conjunto.forms.widgets.ColorSelect`
    with the full Tabler palette pre-wired as choices. The cleaned value
    is the chosen color name (e.g. ``"blue"``); store it in a
    ``CharField`` on the model.

    Args:
        choices: Optional iterable of ``(value, label)`` tuples. Defaults
            to :data:`~conjunto.forms.widgets.TABLER_COLORS`.
        light_colors: Optional iterable of values whose swatches are too
            light for a default border. Forwarded to ``ColorSelect``.
        multiple: If ``True``, render checkboxes via
            :class:`~conjunto.forms.widgets.ColorSelectMultiple` and
            return a list of values. The caller is responsible for
            persisting the list (JSON / comma-separated) — use a
            ``MultipleChoiceField`` for full validation if you need it.
        ``**kwargs``: forwarded to ``ChoiceField`` (``required``,
            ``initial``, …).

    Example::

        from conjunto.forms.fields import ColorField

        class TagForm(forms.Form):
            color = ColorField(initial="blue")
    """

    def __init__(
        self,
        *args,
        choices=None,
        light_colors=None,
        multiple: bool = False,
        **kwargs,
    ):
        resolved_choices = list(choices) if choices is not None else list(TABLER_COLORS)
        widget_class = ColorSelectMultiple if multiple else ColorSelect
        kwargs.setdefault(
            "widget",
            widget_class(choices=resolved_choices, light_colors=light_colors),
        )
        super().__init__(*args, choices=resolved_choices, **kwargs)


class IconField(forms.ChoiceField):
    """A ``ChoiceField`` rendered as a Tabler ``form-selectgroup`` icon row.

    The cleaned value is the chosen Tabler icon name (e.g. ``"moon"``).
    Store it in a ``CharField`` on the model and render it with
    ``<i class="ti ti-{{ icon }}"></i>``.

    Args:
        choices: **Required** iterable of ``(name, label)`` tuples. ``name``
            is the Tabler icon name without the ``ti-`` prefix. There is no
            default set — icons are always context-specific (unlike colors,
            which have a natural Tabler palette).
        multiple: If ``True``, render checkboxes via
            :class:`~conjunto.forms.widgets.IconSelectMultiple` and return a
            list of values. The caller is responsible for persisting the
            list (JSON / comma-separated) — use a ``MultipleChoiceField``
            for full validation if you need it.
        ``**kwargs``: forwarded to ``ChoiceField`` (``required``,
            ``initial``, …).

    Example::

        from conjunto.forms.fields import IconField

        class CategoryForm(forms.Form):
            icon = IconField(choices=[
                ("moon",       _("Moon")),
                ("sun",        _("Sun")),
                ("cloud-rain", _("Rain")),
            ])
    """

    def __init__(
        self,
        *args,
        choices,
        multiple: bool = False,
        **kwargs,
    ):
        resolved_choices = list(choices)
        widget_class = IconSelectMultiple if multiple else IconSelect
        kwargs.setdefault("widget", widget_class(choices=resolved_choices))
        super().__init__(*args, choices=resolved_choices, **kwargs)


class PersistentFileField(forms.FileField):
    """A ``FileField`` that preserves already-uploaded files across re-renders.

    Browsers cannot re-populate a native ``<input type="file">`` with a
    previously uploaded file for security reasons. This field pairs with
    :class:`~conjunto.forms.widgets.persistent_file.PersistentFileWidget` to
    render a "already uploaded: <name> [Replace] [Remove]" state whenever
    ``initial`` holds a file reference, and a regular file input otherwise.

    The field is generic — it has no knowledge of wizards. It is the first
    consumer of the "upload once, keep across re-renders" pattern, but any
    form (e.g. a single-step form that re-renders on validation errors)
    can use it.

    Typical wiring:

    * The view instantiates the form with ``initial={"attachment": <file-ref>}``
      where ``<file-ref>`` is an object exposing ``name`` / ``url``
      (and optionally ``original_name``, ``pk``).
    * For the remove-button to appear, the widget's ``delete_url`` must be
      set — the form is responsible for setting this (e.g. in ``__init__``).

    ``clean()`` semantics:

    * A freshly uploaded ``UploadedFile`` -> that upload is returned.
    * The "clear" marker (``<name>-clear=on``) in the POST data -> the
      field value is ``False`` (Django's standard "delete the file" signal).
    * Otherwise, if ``initial`` contains a file reference -> that reference
      passes through; ``required=True`` is considered satisfied because a
      file does exist server-side.
    """

    widget = PersistentFileWidget

    def clean(self, data, initial=None):
        # Treat the Django "clear" sentinel (``False``) as an explicit remove.
        # The caller (form/view) is responsible for actually deleting the
        # persisted file — the field only surfaces the intent.
        if data is False:
            return False

        # A freshly uploaded file always wins.
        if isinstance(data, UploadedFile):
            return super().clean(data, initial)

        # No new upload: if ``initial`` holds a file reference, the field
        # is considered satisfied. This is the key behaviour that makes
        # the field "persistent" across re-renders.
        if initial:
            return initial

        # Nothing new, nothing persisted: delegate to the normal FileField
        # logic so ``required`` validation kicks in.
        return super().clean(data, initial)


# ----------------------------------------------------------------------- #
# Partial date — date with optional precision (day / month / year)
# ----------------------------------------------------------------------- #


class PartialDatePrecision:
    """Constants for :class:`PartialDate.precision`.

    Kept as bare strings rather than an ``enum`` so the value can be
    stored verbatim in a :class:`~django.db.models.CharField` without an
    extra cast.
    """

    DAY = "day"
    MONTH = "month"
    YEAR = "year"
    CHOICES = (
        (DAY, _("Day")),
        (MONTH, _("Month")),
        (YEAR, _("Year")),
    )


class PartialDate:
    """A date with an explicit precision.

    Internally stored as a real :class:`datetime.date` (always normalised
    to the first of the period — 1 January for years, 1st of the month
    for months) plus a ``precision`` marker. This lets DB columns stay
    plain ``DateField`` (sortable, range-queryable) while preserving the
    user's original level of detail for display.
    """

    __slots__ = ("date", "precision")

    def __init__(self, date_, precision):
        self.date = date_
        self.precision = precision

    def __repr__(self):
        return f"PartialDate({self.date!r}, {self.precision!r})"

    def __eq__(self, other):
        return (
            isinstance(other, PartialDate)
            and self.date == other.date
            and self.precision == other.precision
        )

    def __hash__(self):
        return hash((self.date, self.precision))


class PartialDateField(forms.CharField):
    """Form field that accepts a date with optional precision.

    Returns a :class:`PartialDate` from ``to_python``. The user may
    enter:

    - a full date in the active locale's
      ``DATE_INPUT_FORMATS`` (e.g. ``12.03.2024`` for ``de``,
      ``2024-03-12`` for ``en``),
    - a month, defaulting to ``mm/yyyy`` / ``mm.yyyy`` / ISO ``yyyy-mm``,
    - or a year (``yyyy``).

    A consumer that needs custom month/year formats can pass
    ``month_input_formats`` / ``year_input_formats`` at construction.
    """

    DEFAULT_MONTH_INPUT_FORMATS = ("%m/%Y", "%m.%Y", "%Y-%m")
    DEFAULT_YEAR_INPUT_FORMATS = ("%Y",)

    default_error_messages = {
        "invalid": _("Enter a valid date, month/year, or year."),
    }

    def __init__(
        self,
        *args,
        month_input_formats=None,
        year_input_formats=None,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.month_input_formats = (
            tuple(month_input_formats)
            if month_input_formats is not None
            else self.DEFAULT_MONTH_INPUT_FORMATS
        )
        self.year_input_formats = (
            tuple(year_input_formats)
            if year_input_formats is not None
            else self.DEFAULT_YEAR_INPUT_FORMATS
        )

    def to_python(self, value):
        if value in self.empty_values:
            return None
        if isinstance(value, PartialDate):
            return value
        from datetime import date as date_cls, datetime
        from django.utils import formats as django_formats

        text = str(value).strip()

        # 1) Day-precision via the active locale's DATE_INPUT_FORMATS.
        for fmt in django_formats.get_format("DATE_INPUT_FORMATS"):
            try:
                d = datetime.strptime(text, fmt).date()
            except (ValueError, TypeError):
                continue
            return PartialDate(d, PartialDatePrecision.DAY)

        # 2) Month-precision.
        for fmt in self.month_input_formats:
            try:
                parsed = datetime.strptime(text, fmt).date()
            except (ValueError, TypeError):
                continue
            return PartialDate(
                date_cls(parsed.year, parsed.month, 1),
                PartialDatePrecision.MONTH,
            )

        # 3) Year-precision.
        for fmt in self.year_input_formats:
            try:
                parsed = datetime.strptime(text, fmt).date()
            except (ValueError, TypeError):
                continue
            return PartialDate(
                date_cls(parsed.year, 1, 1),
                PartialDatePrecision.YEAR,
            )

        raise ValidationError(
            self.error_messages["invalid"],
            code="invalid",
        )
