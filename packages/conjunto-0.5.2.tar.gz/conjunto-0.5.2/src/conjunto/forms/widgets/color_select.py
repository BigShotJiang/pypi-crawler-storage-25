"""ColorSelect — a Tabler ``form-colorinput`` widget for color picking.

Renders a row of small color swatches as radio buttons (single select) or
checkboxes (``multiple=True``). Each option's ``value`` is used both as the
form value and as the Tabler/Bootstrap background class
(``bg-{value}``) — so passing ``"blue"`` paints the swatch with
``.bg-blue``. Light swatches (white, yellow, …) are rendered with the
``form-colorinput-light`` border so they stay visible on a light page.
"""

from __future__ import annotations

from collections.abc import Iterable

from django import forms

# The Tabler.io palette — values match Tabler's ``bg-*`` utility classes.
# Labels are human-readable color names. Used as the default choices for
# :class:`~conjunto.forms.fields.ColorField` and as a convenient choices
# argument for ad-hoc ``ColorSelect`` usages.
TABLER_COLORS: tuple[tuple[str, str], ...] = (
    ("blue", "Blue"),
    ("azure", "Azure"),
    ("indigo", "Indigo"),
    ("purple", "Purple"),
    ("pink", "Pink"),
    ("red", "Red"),
    ("orange", "Orange"),
    ("yellow", "Yellow"),
    ("lime", "Lime"),
    ("green", "Green"),
    ("teal", "Teal"),
    ("cyan", "Cyan"),
    ("dark", "Dark"),
    ("white", "White"),
)

# Swatches whose background is too light for a default border — they get
# the ``form-colorinput-light`` modifier class on the surrounding label so
# the swatch stays visible.
DEFAULT_LIGHT_COLORS: frozenset[str] = frozenset({"white"})


class ColorSelect(forms.widgets.ChoiceWidget):
    """Tabler ``form-colorinput`` color picker.

    By default renders a radio group (single value). Pass ``multiple=True``
    to render checkboxes — useful for storing multiple selected colors in
    a JSON / comma-separated CharField.

    Args:
        attrs: Extra HTML attributes for the rendered ``<input>`` elements.
        choices: Iterable of ``(value, label)`` 2-tuples. Defaults to
            :data:`TABLER_COLORS`. The ``value`` doubles as the Tabler
            color name (rendered as ``bg-{value}``).
        multiple: If ``True``, render as checkboxes; otherwise radios.
        light_colors: Iterable of values whose swatches are too light for
            a default border (rendered with ``form-colorinput-light``).
            Defaults to :data:`DEFAULT_LIGHT_COLORS` (``{"white"}``).

    Example::

        from conjunto.forms.widgets.color_select import ColorSelect, TABLER_COLORS

        class TagForm(forms.Form):
            color = forms.CharField(
                widget=ColorSelect(choices=TABLER_COLORS),
            )
    """

    template_name = "conjunto/widgets/color_select.html"
    option_template_name = None  # options handled in the main template

    def __init__(
        self,
        attrs: dict | None = None,
        choices: Iterable[tuple[str, str]] = (),
        *,
        multiple: bool = False,
        light_colors: Iterable[str] | None = None,
    ):
        super().__init__(attrs, choices or TABLER_COLORS)
        self.multiple = multiple
        self.light_colors = (
            frozenset(light_colors)
            if light_colors is not None
            else DEFAULT_LIGHT_COLORS
        )

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        context["widget"]["multiple"] = self.multiple
        for _group, options, _index in context["widget"]["optgroups"]:
            for option in options:
                option_value = (
                    str(option["value"]) if option["value"] is not None else ""
                )
                option["attrs"]["class"] = "form-colorinput-input"
                option["bg_class"] = f"bg-{option_value}" if option_value else ""
                option["is_light"] = option_value in self.light_colors
        return context


class ColorSelectMultiple(ColorSelect):
    """Convenience subclass — renders checkboxes instead of radios."""

    def __init__(
        self,
        attrs: dict | None = None,
        choices: Iterable[tuple[str, str]] = (),
        *,
        light_colors: Iterable[str] | None = None,
    ):
        super().__init__(attrs, choices, multiple=True, light_colors=light_colors)

    def value_from_datadict(self, data, files, name):
        if hasattr(data, "getlist"):
            return data.getlist(name)
        return data.get(name)

    def value_omitted_from_data(self, data, files, name):
        return name not in data
