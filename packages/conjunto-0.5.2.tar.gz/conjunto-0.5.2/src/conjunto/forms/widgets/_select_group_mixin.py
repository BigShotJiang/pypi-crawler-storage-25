"""Shared mixin for choice widgets that toggle between radio + checkbox.

Used by :class:`conjunto.forms.widgets.icon_select.IconSelect` and
:class:`conjunto.forms.widgets.button_group_select.ButtonGroupSelect`
to keep the ``multiple`` flag plumbing (and the matching
``value_from_datadict`` / ``value_omitted_from_data`` for checkbox
mode) in one place.
"""

from __future__ import annotations

from collections.abc import Iterable


class SelectGroupMixin:
    """Adds a ``multiple`` flag to a :class:`forms.widgets.ChoiceWidget`.

    A widget that mixes this in renders ``<input type="radio">`` by
    default, and ``<input type="checkbox">`` when constructed with
    ``multiple=True``. The widget template reads ``widget.multiple``
    from the context to pick the right input type.

    Subclasses are expected to override ``template_name`` and
    (optionally) extend ``get_context`` for widget-specific data.
    """

    multiple: bool = False

    def __init__(
        self,
        attrs: dict | None = None,
        choices: Iterable[tuple[str, str]] = (),
        *,
        multiple: bool = False,
    ):
        super().__init__(attrs, choices)
        self.multiple = multiple

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        context["widget"]["multiple"] = self.multiple
        return context

    # --- multi-select plumbing (only meaningful when multiple=True) ---

    def value_from_datadict(self, data, files, name):
        if self.multiple and hasattr(data, "getlist"):
            return data.getlist(name)
        return data.get(name)

    def value_omitted_from_data(self, data, files, name):
        if self.multiple:
            return name not in data
        return super().value_omitted_from_data(data, files, name)
