from typing import Literal

from django import forms

from conjunto.forms.widgets.color_select import (  # noqa: F401
    DEFAULT_LIGHT_COLORS,
    TABLER_COLORS,
    ColorSelect,
    ColorSelectMultiple,
)
from conjunto.forms.widgets.icon_select import (  # noqa: F401
    IconSelect,
    IconSelectMultiple,
)
from conjunto.forms.widgets.time_picker import TimePickerInput  # noqa: F401

Size = Literal["sm", "md", "lg"]


def _merge_size_class(attrs: dict, size: Size, base: str = "form-control") -> dict:
    """Append the Tabler size modifier (``form-control-sm`` / ``-lg``) to attrs.

    Idempotent: if the attribute already contains ``{base}-{size}``, do nothing.
    Always ensures ``base`` itself is present so crispy-forms doesn't double-add it.
    """
    if size == "md":
        return attrs
    classes = (attrs.get("class") or "").split()
    if base not in classes:
        classes.append(base)
    modifier = f"{base}-{size}"
    if modifier not in classes:
        classes.append(modifier)
    attrs["class"] = " ".join(classes)
    return attrs


class DatePickerInput(forms.widgets.DateInput):
    """A DateInput that uses a date picker.

    It adds Litepicker.js for that input field.
    Additionally, you can specify another field with ``end_field_name``
    that is used for date ranges by Litepicker.

    Args:
        attrs: Extra HTML attributes for the ``<input>``.
        end_field_name: Name of a sibling date field that, together with
            this one, forms a Litepicker date range.
        size: Tabler size variant — ``"sm"``, ``"md"`` (default), or
            ``"lg"``. Adds ``form-control-{size}`` to the rendered input.
    """

    class Media:
        js = ("conjunto/js/datepicker.js",)

    template_name = "conjunto/widgets/datepicker_input.html"

    def __init__(self, attrs=None, end_field_name=None, *, size: Size = "md"):
        if attrs is None:
            attrs = {}
        attrs.update({"autocomplete": "off"})
        if end_field_name:
            attrs.update({"data-end-field": end_field_name})
        if size not in ("sm", "md", "lg"):
            raise ValueError(
                f'DatePickerInput size must be "sm", "md", or "lg" (got {size!r}).'
            )
        self.size = size
        super().__init__(attrs)

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        _merge_size_class(context["widget"]["attrs"], self.size)
        return context


class SelectGroup(forms.widgets.ChoiceWidget):
    """A SelectGroup widget that resembles the Tabler.io form-selectgroup."""

    template_name = "conjunto/widgets/selectgroup.html"
    option_template_name = None  # We handle options in the main template

    def __init__(self, attrs=None, choices=(), multiple=False, as_btn_group=False):
        super().__init__(attrs, choices)
        self.multiple = multiple
        self.as_btn_group = as_btn_group

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        context["widget"]["multiple"] = self.multiple
        context["widget"]["as_btn_group"] = self.as_btn_group
        # Ensure correct classes for the input element.
        # We don't want 'form-control' or other classes inherited from the field.
        input_class = "btn-check" if self.as_btn_group else "form-selectgroup-input"
        for group, options, index in context["widget"]["optgroups"]:
            for option in options:
                option["attrs"]["class"] = input_class
        return context


class SelectGroupMultiple(SelectGroup):
    """A convenience SelectGroup widget for multiple choices."""

    def __init__(self, attrs=None, choices=(), as_btn_group=False):
        super().__init__(attrs, choices, multiple=True, as_btn_group=as_btn_group)

    def value_from_datadict(self, data, files, name):
        return data.getlist(name)

    def value_omitted_from_data(self, data, files, name):
        return name not in data


# Re-exports of widget classes that depend on helpers defined above. Keep at
# the bottom so the partial-init module already exposes ``Size`` and
# ``_merge_size_class`` when the submodule imports them.
from conjunto.forms.widgets.date_stepper import (  # noqa: E402,F401
    DateStepperInput as DateStepperInput,
)
from conjunto.forms.widgets.decimal_stepper import (  # noqa: E402,F401
    DecimalStepperInput as DecimalStepperInput,
)
from conjunto.forms.widgets.integer_stepper import (  # noqa: E402,F401
    IntegerStepperInput as IntegerStepperInput,
)
