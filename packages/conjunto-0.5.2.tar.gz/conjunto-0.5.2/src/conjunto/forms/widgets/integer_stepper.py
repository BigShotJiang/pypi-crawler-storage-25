"""Integer stepper widget for conjunto.

A Tabler-styled replacement for ``forms.NumberInput`` with clickable
``[-]`` and ``[+]`` icon-addons that increment/decrement the input value
without a server roundtrip. The shared template + Alpine plumbing lives
in :class:`conjunto.forms.widgets._stepper_base.BaseStepperInput`; this
module only provides the integer-flavoured ``coerce``/``mask`` snippets
and a typed ``__init__``.

Consumers may pass any Alpine directives through ``attrs`` — most notably
``x-model.number`` — to bind the input value into a surrounding Alpine
scope. The widget itself does **not** put an ``x-model`` on the input,
so consumer-side bindings never collide with widget internals.
"""

from __future__ import annotations

from conjunto.forms.widgets._stepper_base import Align, BaseStepperInput, Size


class IntegerStepperInput(BaseStepperInput):
    """Tabler-styled integer input with clickable ``[-]`` / ``[+]`` icons.

    The rendered markup is a Tabler ``input-icon`` container holding a
    ``[-]`` icon-addon on the left, a centered ``form-control`` in the
    middle, and a ``[+]`` icon-addon on the right. Both addons are
    ``<span role="button">`` elements; clicking them adds/subtracts
    ``step`` from the current value via Alpine and dispatches a bubbling
    ``input`` event so any surrounding ``x-model`` picks up the change.

    Args:
        attrs: Extra HTML attributes for the ``<input>``. Alpine
            directives like ``x-model.number`` or ``@input`` are passed
            through verbatim.
        size: Tabler size variant — ``"sm"``, ``"md"`` (default), or
            ``"lg"``.
        step: Integer increment per ``[-]``/``[+]`` click. Default ``1``.
        min: Optional lower bound. ``[-]`` will clamp at this value.
        max: Optional upper bound. ``[+]`` will clamp at this value.
        align: Text alignment — ``"start"``, ``"center"``, or ``"end"``
            (default).
        allow_negative: When ``True`` the input mask permits a leading
            ``-``. Default ``False`` — most use cases (counts, quantities)
            are non-negative. Setting ``min`` < 0 does *not* implicitly
            flip this; pass ``allow_negative=True`` explicitly.
    """

    stepper_kind = "integer"
    inputmode = "numeric"

    def __init__(
        self,
        attrs: dict | None = None,
        *,
        size: Size = "md",
        step: int = 1,
        min: int | None = None,
        max: int | None = None,
        align: Align = "end",
        allow_negative: bool = False,
    ):
        if not isinstance(step, int) or isinstance(step, bool):
            raise TypeError(
                f"IntegerStepperInput.step must be int (got {type(step).__name__}). "
                "Use DecimalStepperInput for fractional steps."
            )
        self.step = step
        super().__init__(
            attrs,
            size=size,
            min=min,
            max=max,
            align=align,
            allow_negative=allow_negative,
        )

    def get_alpine_lines(self) -> list[str]:
        return [
            f"_step: {self.step}",
            "_coerce(v) {"
            " const n = parseInt(v, 10);"
            " return Number.isFinite(n) ? n : 0;"
            " }",
            "_commit(v) {"
            " if (this._max !== null && v > this._max) v = this._max;"
            " if (this._min !== null && v < this._min) v = this._min;"
            " this.$refs.input.value = v;"
            " this.$refs.input.dispatchEvent("
            "new Event('input', {bubbles: true}));"
            " }",
            "inc() {"
            " this._commit(this._coerce(this.$refs.input.value) + this._step);"
            " }",
            "dec() {"
            " this._commit(this._coerce(this.$refs.input.value) - this._step);"
            " }",
            "mask(el) {"
            " const re = this._allowNegative ? /[^\\d-]/g : /[^\\d]/g;"
            " const cleaned = el.value.replace(re, '').replace(/(?!^)-/g, '');"
            " if (cleaned !== el.value) el.value = cleaned;"
            " }",
        ]
