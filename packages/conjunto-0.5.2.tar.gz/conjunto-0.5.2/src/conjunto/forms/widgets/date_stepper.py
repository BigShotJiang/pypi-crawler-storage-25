"""Tabler-styled configurable date input.

A single ``input-group`` widget that combines a text date input with any
combination of: day stepper buttons (``<`` / ``>``), week stepper buttons
(``<<`` / ``>>``), a ``Today`` button, and a Litepicker popup on focus.
Keyboard shortcuts on the input mirror the day/week stepper buttons
(``ArrowUp``/``ArrowDown`` for day, ``Shift+Arrow*`` for week).

The widget renders Django's ``SHORT_DATE_FORMAT`` and emits the locale's
format string as a ``data-date-format`` attribute on the wrapper so the
Alpine code in ``date_stepper.js`` can parse/format values without a
server roundtrip.
"""

from __future__ import annotations

from typing import Literal

from django import forms
from django.utils.formats import get_format

Size = Literal["sm", "md", "lg"]


def _django_to_js_format(djfmt: str) -> str:
    """Convert a Django date format string to the moment-like tokens used by
    the JS helpers in ``date_stepper.js`` (and Litepicker).

    Supports the four tokens that appear in Django's bundled
    ``SHORT_DATE_FORMAT`` values: ``Y`` (4-digit year), ``y`` (2-digit
    year), ``m`` (zero-padded month), ``d`` (zero-padded day). Any other
    character passes through unchanged.
    """
    mapping = {"Y": "YYYY", "y": "YY", "m": "MM", "d": "DD"}
    out: list[str] = []
    for ch in djfmt:
        out.append(mapping.get(ch, ch))
    return "".join(out)


class DateStepperInput(forms.widgets.DateInput):
    """Configurable date input with optional stepper buttons + Litepicker.

    The whole widget is a single Tabler ``input-group`` whose direct
    children are the optional buttons and the ``<input>``. No outer
    wrapper, no nested groups.

    Args:
        attrs: Extra HTML attributes for the ``<input>``.
        picker: When ``True`` (default) the input carries the
            ``datepickerinput`` class so ``datepicker.js`` initialises
            Litepicker on focus.
        day_stepper: When ``True``, render ``<`` / ``>`` icon-buttons that
            step the value by one day. Also wires
            ``@keydown.up``/``@keydown.down`` on the input.
        week_stepper: When ``True``, render ``<<`` / ``>>`` icon-buttons
            that step the value by seven days. Also wires
            ``@keydown.shift.up``/``@keydown.shift.down`` on the input.
        today: When ``True``, render a trailing ``Today`` button that
            sets the value to the current date.
        size: Tabler size variant — ``"sm"``, ``"md"`` (default), or
            ``"lg"``. Adds ``input-group-{size}`` to the wrapper and
            ``form-control-{size}`` to the input.
    """

    template_name = "conjunto/widgets/date_stepper_input.html"

    class Media:
        js = (
            "conjunto/js/datepicker.js",
            "conjunto/js/date_stepper.js",
        )

    def __init__(
        self,
        attrs: dict | None = None,
        *,
        picker: bool = True,
        day_stepper: bool = False,
        week_stepper: bool = False,
        today: bool = False,
        size: Size = "md",
    ):
        if size not in ("sm", "md", "lg"):
            raise ValueError(
                f'DateStepperInput size must be "sm", "md", or "lg" (got {size!r}).'
            )
        if attrs is None:
            attrs = {}
        attrs.setdefault("autocomplete", "off")
        self.picker = picker
        self.day_stepper = day_stepper
        self.week_stepper = week_stepper
        self.today = today
        self.size = size
        super().__init__(attrs)

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        widget = context["widget"]

        existing = (widget["attrs"].get("class") or "").split()
        classes: list[str] = []
        for cls in ("form-control", "text-center", *existing):
            if cls and cls not in classes:
                classes.append(cls)
        if self.size != "md":
            modifier = f"form-control-{self.size}"
            if modifier not in classes:
                classes.append(modifier)
        if self.picker and "datepickerinput" not in classes:
            classes.append("datepickerinput")
        widget["attrs"]["class"] = " ".join(classes)

        widget["picker"] = self.picker
        widget["day_stepper"] = self.day_stepper
        widget["week_stepper"] = self.week_stepper
        widget["today"] = self.today
        widget["size"] = self.size
        widget["size_suffix"] = "" if self.size == "md" else f"-{self.size}"
        widget["date_format_js"] = _django_to_js_format(get_format("SHORT_DATE_FORMAT"))
        return context
