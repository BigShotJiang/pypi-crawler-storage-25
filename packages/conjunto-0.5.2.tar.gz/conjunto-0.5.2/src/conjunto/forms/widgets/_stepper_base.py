"""Shared base class for Tabler-styled numeric stepper widgets.

Both :class:`IntegerStepperInput` and :class:`DecimalStepperInput` render the
same Tabler ``input-icon`` skeleton with a clickable ``[-]`` icon-addon on the
left, a centered ``<input>`` in the middle, and a ``[+]`` icon-addon on the
right. The buttons are Alpine-driven and dispatch a bubbling ``input`` event
on every change so any surrounding ``x-model`` (or other listener) picks up
the new value without a server roundtrip.

The two subclasses differ only in how they parse, mask, and format values:

* :class:`IntegerStepperInput` uses ``parseInt`` and a digit-only mask.
* :class:`DecimalStepperInput` uses ``parseFloat``, derives a locale-aware
  decimal separator from Django's i18n machinery, and rounds to a fixed
  number of decimal places.

Subclasses provide their JS snippets via ``get_alpine_overrides()``; the
shared template (``conjunto/widgets/_stepper_base.html``) consumes them.
"""

from __future__ import annotations

from typing import Literal

from django import forms

Size = Literal["sm", "md", "lg"]
Align = Literal["start", "center", "end"]


class BaseStepperInput(forms.NumberInput):
    """Abstract Tabler ``input-icon`` stepper with ``[-]``/``[+]`` icon addons.

    Subclasses MUST override:

    * ``stepper_kind`` — short identifier (``"integer"``/``"decimal"``); used
      to compose ``cj-{kind}-stepper`` / ``cj-{kind}-decrement`` /
      ``cj-{kind}-increment`` CSS hooks so existing styles and tests keep
      addressing each variant individually.
    * ``inputmode`` — HTML ``inputmode`` attribute (``"numeric"`` /
      ``"decimal"``).
    * :meth:`get_alpine_lines` — return a ``list[str]`` of raw Alpine
      ``x-data`` field/method literals (e.g. ``"_step: 1"``,
      ``"_coerce(v) { ... }"``). Each line is emitted verbatim as a
      comma-separated entry inside ``x-data="{ ... }"``.

    Common attributes:

    Args:
        attrs: Extra HTML attributes for the ``<input>``. Alpine directives
            like ``x-model.number`` are passed through verbatim.
        size: Tabler size variant — ``"sm"``, ``"md"`` (default), or
            ``"lg"``. Adds ``form-control-{size}`` to the input and
            ``input-icon-{size}`` to the wrapper.
        min: Optional lower bound. ``[-]`` clamps at this value.
        max: Optional upper bound. ``[+]`` clamps at this value.
        align: Text alignment inside the input — ``"start"``, ``"center"``,
            or ``"end"`` (default). Maps to Bootstrap's ``text-{align}``.
        allow_negative: When ``True``, the input mask permits a leading
            ``-``. Default ``False``. Setting ``min`` < 0 does not flip
            this implicitly — pass ``allow_negative=True`` explicitly.
    """

    template_name = "conjunto/widgets/_stepper_base.html"

    class Media:
        css = {"all": ("conjunto/css/stepper.css",)}

    stepper_kind: str = "stepper"
    inputmode: str = "numeric"

    def __init__(
        self,
        attrs: dict | None = None,
        *,
        size: Size = "md",
        min=None,
        max=None,
        align: Align = "end",
        allow_negative: bool = False,
    ):
        if size not in ("sm", "md", "lg"):
            raise ValueError(
                f'{type(self).__name__} size must be "sm", "md", or "lg" '
                f"(got {size!r})."
            )
        if align not in ("start", "center", "end"):
            raise ValueError(
                f'{type(self).__name__} align must be "start", "center", or '
                f'"end" (got {align!r}).'
            )
        self.size = size
        self.min = min
        self.max = max
        self.align = align
        self.allow_negative = allow_negative
        super().__init__(attrs)

    def get_alpine_lines(self) -> list[str]:
        """Return raw Alpine ``x-data`` lines provided by the subclass.

        Each list entry is a complete JS object-literal entry, either a
        property (``"_step: 1"``) or a method shorthand
        (``"_coerce(v) { ... }"``). Lines are joined with ``,`` in
        :meth:`_render_alpine_fields` and inlined into ``x-data="{ ... }"``.
        Subclasses MUST override this; the base returns an empty list only
        as a safety net.
        """
        return []

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        widget = context["widget"]

        # Build the full ``class`` attribute on the input centrally so the
        # rendered ``<input>`` carries it exactly once. Existing user-supplied
        # classes (via ``attrs={"class": "..."}``) are preserved.
        existing = (widget["attrs"].get("class") or "").split()
        classes: list[str] = []
        for cls in ("form-control", *existing):
            if cls and cls not in classes:
                classes.append(cls)
        if self.size != "md":
            modifier = f"form-control-{self.size}"
            if modifier not in classes:
                classes.append(modifier)
        align_class = f"text-{self.align}"
        if align_class not in classes:
            classes.append(align_class)
        widget["attrs"]["class"] = " ".join(classes)

        widget["size"] = self.size
        widget["size_suffix"] = "" if self.size == "md" else f"-{self.size}"
        widget["min"] = self.min
        widget["max"] = self.max
        widget["align"] = self.align
        widget["allow_negative"] = self.allow_negative
        widget["stepper_kind"] = self.stepper_kind
        widget["inputmode"] = self.inputmode

        # Compose the Alpine x-data literal here — Django templates can't
        # easily render a dict with un-quoted JS RHSs, so we serialize once
        # and the template emits the result inside ``x-data="{ ... }"``.
        widget["alpine_fields"] = self._render_alpine_fields()
        return context

    def _render_alpine_fields(self) -> str:
        """Serialize the Alpine ``x-data`` body as a comma-separated literal.

        Order: shared bound fields first (``_min``/``_max``/``_allowNegative``),
        then subclass-supplied lines (``_step``, ``_coerce``, ``_format``,
        ``_commit``, ``inc``/``dec``, ``mask``, …) in insertion order.
        """
        common = [
            f"_min: {self._js_number_or_null(self.min)}",
            f"_max: {self._js_number_or_null(self.max)}",
            f"_allowNegative: {'true' if self.allow_negative else 'false'}",
        ]
        # Newlines + indentation keep the rendered HTML readable; tests still
        # match on substrings (e.g. ``_step: 1``) so layout is not load-bearing.
        return ",\n       ".join(common + self.get_alpine_lines())

    @staticmethod
    def _js_number_or_null(value) -> str:
        """Render ``value`` as a JS number literal or ``null``."""
        if value is None:
            return "null"
        return str(value)
