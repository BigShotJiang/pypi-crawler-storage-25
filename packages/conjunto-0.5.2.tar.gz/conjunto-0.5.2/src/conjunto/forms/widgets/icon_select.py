"""IconSelect — a Tabler ``form-selectgroup`` widget for icon picking.

Renders a row of icon tiles as radio buttons (single select) or checkboxes
(``multiple=True``). Each option's ``value`` is the Tabler icon name without
the ``ti-`` prefix — the template renders ``<i class="ti ti-{value}">``.

The cleaned value is the chosen icon name (e.g. ``"moon"``); store it in a
``CharField`` on the model.
"""

from __future__ import annotations

from collections.abc import Iterable

from django import forms

from conjunto.forms.widgets._select_group_mixin import SelectGroupMixin


class IconSelect(SelectGroupMixin, forms.widgets.ChoiceWidget):
    """Tabler ``form-selectgroup`` icon picker.

    By default renders a radio group (single value). Pass ``multiple=True``
    to render checkboxes — useful for storing multiple selected icons in a
    JSON / comma-separated CharField.

    Args:
        attrs: Extra HTML attributes for the rendered ``<input>`` elements.
        choices: Iterable of ``(name, label)`` 2-tuples. ``name`` is the
            Tabler icon name without the ``ti-`` prefix (e.g. ``"moon"``,
            ``"cloud-rain"``). ``label`` is shown as a ``title`` tooltip
            and as a ``visually-hidden`` caption for screen readers.
        multiple: If ``True``, render as checkboxes; otherwise radios.

    Example::

        from conjunto.forms.widgets.icon_select import IconSelect

        class CategoryForm(forms.Form):
            icon = forms.CharField(
                widget=IconSelect(choices=[
                    ("moon", "Moon"),
                    ("sun", "Sun"),
                ]),
            )
    """

    template_name = "conjunto/widgets/icon_select.html"
    option_template_name = None  # options handled in the main template

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        for _group, options, _index in context["widget"]["optgroups"]:
            for option in options:
                option_value = (
                    str(option["value"]) if option["value"] is not None else ""
                )
                option["attrs"]["class"] = "form-selectgroup-input"
                option["icon_class"] = f"ti ti-{option_value}" if option_value else ""
        return context


class IconSelectMultiple(IconSelect):
    """Convenience subclass — renders checkboxes instead of radios."""

    def __init__(
        self,
        attrs: dict | None = None,
        choices: Iterable[tuple[str, str]] = (),
    ):
        super().__init__(attrs, choices, multiple=True)
