"""ButtonGroupSelect — Tabler ``btn-group`` radio / checkbox widget.

Renders a list of choices as a horizontal (or vertical) button group
where the active selection appears as a "pressed" button.

The cleaned value is the chosen ``value`` (e.g. ``"smoking"``); store
it in a ``CharField``-with-choices on the model. With ``multiple=True``
the cleaned value is a list — store comma-separated or in a JSONField.
"""

from __future__ import annotations

from collections.abc import Iterable

from django import forms

from conjunto.forms.widgets._select_group_mixin import SelectGroupMixin


class ButtonGroupSelect(SelectGroupMixin, forms.widgets.ChoiceWidget):
    """Tabler ``btn-group`` choice widget.

    Args:
        attrs: Extra HTML attributes for the rendered ``<input>`` elements.
        choices: Iterable of ``(value, label)`` 2-tuples.
        multiple: If ``True``, render as checkboxes; otherwise radios.
        vertical: If ``True``, render with ``btn-group-vertical``; else
            ``btn-group`` (horizontal). Vertical layout is appropriate
            for long choice lists; horizontal for 2–5 short labels.

    Example::

        from conjunto.forms.widgets.button_group_select import (
            ButtonGroupSelect,
        )

        class TimerForm(forms.Form):
            duration = forms.ChoiceField(
                choices=[("1", "1 min"), ("5", "5 min"), ("10", "10 min")],
                widget=ButtonGroupSelect,  # horizontal radio
            )
    """

    template_name = "conjunto/widgets/button_group_select.html"
    option_template_name = None  # options handled in the main template

    def __init__(
        self,
        attrs: dict | None = None,
        choices: Iterable[tuple[str, str]] = (),
        *,
        multiple: bool = False,
        vertical: bool = False,
        option_titles: dict[str, str] | None = None,
    ):
        """
        Args:
            option_titles: Optional ``{choice_value: tooltip_text}`` map.
                When set, the matching ``<label>`` gets a ``title`` attribute
                so the user sees the tooltip on hover (multi-line text is
                supported — newlines in the value are kept by the browser
                inside the ``title`` attribute).
        """
        super().__init__(attrs, choices, multiple=multiple)
        self.vertical = vertical
        self.option_titles = option_titles or {}

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        context["widget"]["vertical"] = self.vertical
        # crispy / bootstrap-5 adds ``is-invalid`` to the widget attrs on
        # validation error. The default Bootstrap CSS only highlights
        # ``<input>`` / ``<select>`` elements with that class — for a
        # button-radio group we need to lift the flag onto the wrapping
        # ``.btn-group`` so the user can actually see the field is bad.
        incoming = (attrs or {}).get("class", "") or ""
        context["widget"]["has_error"] = "is-invalid" in incoming.split()
        for _group, options, _index in context["widget"]["optgroups"]:
            for option in options:
                option["attrs"]["class"] = "btn-check"
                tip = self.option_titles.get(str(option["value"]))
                if tip:
                    option["title"] = tip
        return context


class ButtonGroupSelectMultiple(ButtonGroupSelect):
    """Convenience subclass — renders checkboxes instead of radios."""

    def __init__(
        self,
        attrs: dict | None = None,
        choices: Iterable[tuple[str, str]] = (),
        *,
        vertical: bool = False,
    ):
        super().__init__(attrs, choices, multiple=True, vertical=vertical)
