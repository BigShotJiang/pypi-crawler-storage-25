"""PersistentFileWidget — a file input widget that survives re-renders.

Once a file has been uploaded for a form field, the browser cannot re-populate
the native ``<input type="file">`` with that file on subsequent renders for
security reasons. This widget renders differently depending on whether an
initial file is already present:

* No initial file -> standard ``<input type="file">``.
* Initial file present -> a compact display of the uploaded file name with
  two buttons:

  - **Replace**: toggles a hidden ``<input type="file">`` back into view.
  - **Remove**: fires ``hx-delete`` against a delete URL provided by the
    form/view (set via :attr:`delete_url`).

The widget is intentionally generic; it is not wizard-specific. The wizard
module consumes it, but any conjunto form (e.g. a single-step form that
re-renders on validation errors) can use it to prevent loss of uploaded
files.
"""

from __future__ import annotations

from typing import Literal

from django import forms

Size = Literal["sm", "md", "lg"]


class PersistentFileWidget(forms.ClearableFileInput):
    """File input widget that shows already-uploaded files as replace/remove.

    Attributes:
        template_name: Path to the partial template rendering the widget.
        delete_url: Optional URL (str) for the HTMX ``hx-delete`` endpoint
            that removes the persisted file. May be ``None`` if removal is
            not supported; the remove button is hidden in that case.
        clear_checkbox_name_suffix: Name suffix for the hidden "clear"
            marker input. Kept compatible with Django's ``ClearableFileInput``.

    Args:
        attrs: Extra HTML attributes for the ``<input type="file">``.
        delete_url: HTMX delete-endpoint URL.
        size: Tabler size variant — ``"sm"``, ``"md"`` (default), or
            ``"lg"``. Adds ``form-control-{size}`` to the rendered input.
    """

    template_name = "conjunto/forms/_persistent_file.html"

    def __init__(
        self,
        attrs=None,
        delete_url: str | None = None,
        *,
        size: Size = "md",
    ) -> None:
        super().__init__(attrs)
        self.delete_url = delete_url
        if size not in ("sm", "md", "lg"):
            raise ValueError(
                f'PersistentFileWidget size must be "sm", "md", or "lg" (got {size!r}).'
            )
        self.size = size

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        # ``value`` can be any of:
        # - an ``UploadedFile`` (fresh POST, bound form)
        # - a ``FieldFile`` (ModelForm with existing instance)
        # - any object exposing ``.name`` / ``.url`` / ``.original_name``
        # - a string (unlikely here, but handled)
        # - ``None``
        widget_ctx = context["widget"]
        has_file = bool(value) and not isinstance(value, str)
        display_name = ""
        file_url = ""
        file_pk = None

        if has_file:
            # Prefer a human-friendly ``original_name`` (WizardDraftFile),
            # fall back to ``name`` attr, then str(value).
            display_name = (
                getattr(value, "original_name", None)
                or getattr(value, "name", None)
                or str(value)
            )
            file_url = getattr(value, "url", "") or ""
            file_pk = getattr(value, "pk", None)

        widget_ctx.update(
            {
                "has_file": has_file,
                "display_name": display_name,
                "file_url": file_url,
                "file_pk": file_pk,
                "delete_url": self.delete_url,
                "clear_checkbox_name": self.clear_checkbox_name(name),
                "clear_checkbox_id": self.clear_checkbox_id(
                    self.clear_checkbox_name(name)
                ),
                "size": self.size,
                "size_suffix": "" if self.size == "md" else f"-{self.size}",
            }
        )
        return context

    def value_from_datadict(self, data, files, name):
        """Extract a new uploaded file, the clear marker, or ``None``.

        When the user clicks "Remove", the partial submits a hidden input
        ``<name>-clear=on`` (Django's default convention), which signals
        that the persisted file should be deleted. When the user selects
        a new file via the "Replace" flow, the new upload is returned
        normally.
        """
        return super().value_from_datadict(data, files, name)
