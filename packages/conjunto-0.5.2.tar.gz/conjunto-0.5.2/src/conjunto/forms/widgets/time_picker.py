"""Time picker widget for conjunto.

A Tabler-styled replacement for ``forms.TimeInput`` with smart digit-only
parsing, optional snap-step icons, and optional 12h display. The Python-side
widget is purely presentational; the matching parser lives in
``conjunto/static/conjunto/js/time_picker_input.js``. Server-side fallback
parsing happens in :class:`conjunto.forms.fields.TimeField`.
"""

from __future__ import annotations

from datetime import time
from typing import Literal

from django import forms

Size = Literal["sm", "md", "lg"]


class TimePickerInput(forms.TimeInput):
    """Tabler-styled time input with smart parsing and optional snap icons.

    The rendered markup is a Tabler ``input-icon`` container holding — by
    default — a ``[-]`` icon-addon on the left, a centered ``form-control``
    in the middle, and a ``[+]`` icon-addon on the right. Both addons are
    rendered as ``<span role="button">`` so the widget can itself be
    embedded inside a Bootstrap ``input-group`` (an ``input-group`` cannot
    be nested in another ``input-group``). The ``[-]``/``[+]`` icons jump
    to the next ``snap``-minute step.

    The ``value`` attribute is always the canonical 24h ``HH:MM`` Django
    expects on POST — even when ``format_12h=True``, the JS computes the
    user-facing display from that.

    Args:
        attrs: Extra HTML attributes for the ``<input>``.
        snap: Step in minutes. When set, ``+``/``-`` icons and the
            ``ArrowUp`` / ``ArrowDown`` keys jump to the next multiple of
            ``snap`` (snap-to-grid, not increment-by-N).
        format_12h: Display the value as ``hh:mm AM/PM`` in the field. The
            POSTed value stays 24h ``HH:MM``.
        show_buttons: Render the ``[-]``/``[+]`` icons. Icons are only
            rendered when ``snap`` is also set; pass ``show_buttons=False``
            to opt out even when ``snap`` is set. The icons are disabled
            on render whenever the field has no valid value, and the JS
            keeps that state in sync as the user types.
        size: Tabler size variant — ``"sm"``, ``"md"`` (default), or
            ``"lg"``. Controls the ``form-control``/``input-icon`` size
            class. Compose with the corresponding ``input-group-{size}``
            on a parent ``input-group`` if you embed this widget there.
    """

    template_name = "conjunto/widgets/time_picker_input.html"

    class Media:
        js = ("conjunto/js/time_picker_input.js",)
        css = {"all": ("conjunto/css/time_picker_input.css",)}

    def __init__(
        self,
        attrs=None,
        *,
        snap: int | None = None,
        format_12h: bool = False,
        show_buttons: bool = True,
        size: Size = "md",
    ):
        super().__init__(attrs)
        self.snap = snap
        self.format_12h = format_12h
        self.show_buttons = show_buttons
        if size not in ("sm", "md", "lg"):
            raise ValueError(
                f'TimePickerInput size must be "sm", "md", or "lg" (got {size!r}).'
            )
        self.size = size

    def format_value(self, value):
        # Always render the value as canonical 24h ``HH:MM`` so that the JS
        # parser, the smart-parsing fallback, and Django's TimeField round-trip
        # without surprises. The default would keep seconds (``14:30:00``).
        if isinstance(value, time):
            return value.strftime("%H:%M")
        return super().format_value(value)

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        widget = context["widget"]
        # Icons require snap. show_buttons=False is an explicit opt-out.
        widget["snap"] = self.snap
        widget["format_12h"] = self.format_12h
        widget["show_buttons"] = bool(self.snap) and self.show_buttons
        # The JS keeps icon state in sync; the server-rendered initial
        # state is "enabled iff there is already a value to step from".
        widget["buttons_disabled"] = not isinstance(value, time)
        widget["size"] = self.size
        widget["size_suffix"] = "" if self.size == "md" else f"-{self.size}"
        return context
