"""Decimal stepper widget for conjunto.

A Tabler-styled stepper for fractional values (prices, dosages, weights).
Inherits the ``[-] input [+]`` skeleton from
:class:`conjunto.forms.widgets._stepper_base.BaseStepperInput` and adds:

* ``parseFloat``-based coerce + ``toFixed`` rounding to neutralise
  floating-point drift (``0.1 + 0.2`` → ``0.3``, not ``0.30000000000000004``).
* A locale-aware decimal separator pulled from Django's i18n
  (``DECIMAL_SEPARATOR`` format), so DE-AT users see ``0,5`` and EN users
  see ``0.5``. The submitted POST value follows the same convention; pair
  with a ``DecimalField(localize=True)`` on the form side and Django round-
  trips the value transparently.
* Auto-derived ``decimal_places`` from ``step`` (``0.1`` → 1, ``0.25`` → 2).
  Override explicitly if you want extra padding (``decimal_places=3`` for
  ``step=0.1`` renders ``0.100``).

The widget itself does **not** put an ``x-model`` on the input, so consumer-
side bindings (``attrs={"x-model.number": "..."}`` or similar) never collide
with widget internals.
"""

from __future__ import annotations

from decimal import Decimal

from django.utils.formats import get_format

from conjunto.forms.widgets._stepper_base import Align, BaseStepperInput, Size


def _derive_decimal_places(step) -> int:
    """Count significant decimal places in ``step`` (``0.1`` → 1, ``1`` → 0)."""
    s = format(Decimal(str(step)), "f")  # avoid scientific notation
    if "." not in s:
        return 0
    return len(s.split(".")[1].rstrip("0"))


def _step_as_js_number(step) -> str:
    """Render ``step`` as a canonical JS number literal (always with ``.``)."""
    return format(Decimal(str(step)), "f")


class DecimalStepperInput(BaseStepperInput):
    """Tabler-styled decimal input with clickable ``[-]`` / ``[+]`` icons.

    Same visual structure as :class:`IntegerStepperInput`, but the Alpine
    plumbing parses values as floats, applies a locale-aware decimal
    separator, and rounds to ``decimal_places`` on every commit.

    Args:
        attrs: Extra HTML attributes for the ``<input>``. Alpine directives
            are passed through verbatim.
        size: Tabler size variant — ``"sm"``, ``"md"`` (default), or
            ``"lg"``.
        step: Increment per click. Accepts ``int``, ``float``, or
            ``Decimal``. Default ``Decimal("0.1")``. Use ``Decimal`` for
            currency / scores to avoid float-rounding surprises in the
            derived ``decimal_places`` count.
        min: Optional lower bound (numeric). ``[-]`` clamps here.
        max: Optional upper bound (numeric). ``[+]`` clamps here.
        align: Text alignment — ``"start"``, ``"center"``, or ``"end"``
            (default).
        allow_negative: When ``True``, the input mask permits a leading
            ``-``. Default ``False``.
        decimal_places: Number of digits after the separator. Defaults to
            the step's significant decimal-place count (``Decimal("0.25")``
            → 2). Set explicitly to force a fixed precision regardless of
            ``step``.
        decimal_separator: Override the locale-derived separator. Default
            is :func:`django.utils.formats.get_format`'s ``DECIMAL_SEPARATOR``
            for the active language. Pass ``"."`` to force a fixed
            separator (e.g. for unit fields where locale doesn't apply).
    """

    stepper_kind = "decimal"
    inputmode = "decimal"

    def __init__(
        self,
        attrs: dict | None = None,
        *,
        size: Size = "md",
        step: int | float | Decimal = Decimal("0.1"),
        min=None,
        max=None,
        align: Align = "end",
        allow_negative: bool = False,
        decimal_places: int | None = None,
        decimal_separator: str | None = None,
    ):
        self.step = step
        self.decimal_places = (
            decimal_places
            if decimal_places is not None
            else _derive_decimal_places(step)
        )
        # Resolve the separator at construction time. ``get_format`` honours
        # the active translation; if the widget is built outside a request
        # cycle (forms instantiated in a script), the project's default
        # language wins.
        self.decimal_separator = (
            decimal_separator
            if decimal_separator is not None
            else get_format("DECIMAL_SEPARATOR")
        )
        super().__init__(
            attrs,
            size=size,
            min=min,
            max=max,
            align=align,
            allow_negative=allow_negative,
        )

    def format_value(self, value):
        """Render the initial value with the active decimal separator.

        Django's ``NumberInput.format_value`` returns ``str(value)`` which
        is always Python's canonical ``.`` separator. For DE-AT we swap it
        so the field never paints with a ``.`` when the rest of the page
        uses ``,``.
        """
        if value is None or value == "":
            return ""
        s = super().format_value(value)
        if self.decimal_separator != ".":
            s = s.replace(",", ".").replace(".", self.decimal_separator)
        return s

    def get_alpine_lines(self) -> list[str]:
        # JS expects ``.`` in number literals regardless of locale.
        step_js = _step_as_js_number(self.step)
        # Escape the separator for embedding in a JS single-quoted string;
        # only ``\`` and ``'`` need escaping for our character set.
        sep = self.decimal_separator.replace("\\", "\\\\").replace("'", "\\'")
        places = self.decimal_places
        return [
            f"_step: {step_js}",
            f"_decimalPlaces: {places}",
            f"_decimalSeparator: '{sep}'",
            "_coerce(v) {"
            " const cleaned = String(v).replace(this._decimalSeparator, '.');"
            " const n = parseFloat(cleaned);"
            " return Number.isFinite(n) ? n : 0;"
            " }",
            "_format(n) {"
            " const fixed = n.toFixed(this._decimalPlaces);"
            " return fixed.replace('.', this._decimalSeparator);"
            " }",
            "_commit(v) {"
            " if (this._max !== null && v > this._max) v = this._max;"
            " if (this._min !== null && v < this._min) v = this._min;"
            " this.$refs.input.value = this._format(v);"
            " this.$refs.input.dispatchEvent("
            "new Event('input', {bubbles: true}));"
            " }",
            "inc() {"
            " this._commit(this._coerce(this.$refs.input.value) + this._step);"
            " }",
            "dec() {"
            " this._commit(this._coerce(this.$refs.input.value) - this._step);"
            " }",
            "mask(el) {"
            " const sep = this._decimalSeparator;"
            " const sepEsc = sep.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&');"
            " const re = new RegExp('[^\\\\d\\\\-' + sepEsc + ']', 'g');"
            " let cleaned = el.value.replace(re, '').replace(/(?!^)-/g, '');"
            " if (!this._allowNegative) cleaned = cleaned.replace(/-/g, '');"
            " const parts = cleaned.split(sep);"
            " if (parts.length > 2)"
            " cleaned = parts[0] + sep + parts.slice(1).join('');"
            " if (cleaned !== el.value) el.value = cleaned;"
            " }",
        ]
