"""TenantFormMixin: ``tenant`` is a required kwarg, single-choice helper.

Standard mixin for plugin forms that need a tenant-scoped queryset.
The ``tenant`` is captured before ``super().__init__`` runs so that
ModelForm field initialisation can rely on ``self.tenant`` if needed.
"""

from __future__ import annotations

from django.forms import HiddenInput


class TenantFormMixin:
    """Form mixin that enforces a ``tenant`` kwarg and offers a
    one-shot helper to hide a ModelChoiceField when the queryset is
    single-valued.
    """

    def __init__(self, *args, tenant, **kwargs):
        # ``tenant`` is REQUIRED. Calling without it raises TypeError —
        # surfacing forgotten plumbing loudly is the point of this
        # mixin.
        self.tenant = tenant
        super().__init__(*args, **kwargs)

    def hide_field_if_single(self, field_name, queryset):
        """Replace the field's widget with ``HiddenInput`` when the
        queryset has exactly one entry; pre-set initial.

        Always sets the queryset on the field as a side-effect.
        Returns the resolved single instance, or ``None`` for
        zero / multiple-choice cases.
        """
        single = queryset.first() if queryset.count() == 1 else None
        self.fields[field_name].queryset = queryset
        if single is not None:
            self.fields[field_name].initial = single
            self.fields[field_name].widget = HiddenInput()
        return single
