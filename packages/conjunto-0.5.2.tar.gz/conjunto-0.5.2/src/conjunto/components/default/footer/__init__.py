from tetra import Component


class Footer(Component):
    pass
