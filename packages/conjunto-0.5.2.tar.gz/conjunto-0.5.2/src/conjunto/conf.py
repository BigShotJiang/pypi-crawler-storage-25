"""Centralised access to conjunto-level defaults.

Conjunto historically resolves ``CONJUNTO_*`` settings inline via
``getattr(django.conf.settings, "CONJUNTO_FOO", default)`` at the call
site. This module collects the *defaults* in one place so that downstream
code can import them and keep call sites short.

Each accessor performs a fresh ``getattr`` lookup against
``django.conf.settings`` so test overrides (``@override_settings``) keep
working.
"""

from django.conf import settings


# Default role assigned by the post_save User signal when auto-creating
# the home TenantMembership. Override via ``settings.CONJUNTO_DEFAULT_USER_ROLE``.
CONJUNTO_DEFAULT_USER_ROLE = "user"


def get_default_user_role() -> str:
    """Return the configured default tenant role name for new users."""

    return getattr(settings, "CONJUNTO_DEFAULT_USER_ROLE", CONJUNTO_DEFAULT_USER_ROLE)
