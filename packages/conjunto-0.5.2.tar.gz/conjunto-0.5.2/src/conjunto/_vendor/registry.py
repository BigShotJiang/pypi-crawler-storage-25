"""Vendored third-party JS/CSS library registry and downloader.

Conjunto used to ship every required third-party library
(TinyMCE, Tabler, HTMX, Alpine, …) inside its wheel. That made the
wheel ~16 MB while the actual Python code is < 1 MB; ~95 % of the
download was assets that not every consumer needs.

The libraries now live **outside the wheel** and are fetched
per-project by ``python manage.py update_libraries``. This module is
the single source of truth for:

* the ``LIBRARIES`` registry (URLs, versions, file layouts)
* the download primitives (file-by-file and tarball-with-rename)
* the ``--suggest`` template scanner that tells a consumer which
  ``CONJUNTO_LIBRARIES`` entries their templates actually require

**License obligation**: TinyMCE Community Edition is GPLv2-or-later.
Its ``LICENSE.TXT`` MUST be shipped alongside the assets — the
``keep`` lists below ensure that, and the test suite has a guard.
"""

from __future__ import annotations

import io
import os
import re
import sys
import tarfile
from collections.abc import Iterable, Iterator
from pathlib import Path

import requests

# ── Library URL constants ───────────────────────────────────────────────

UNPKG = "https://unpkg.com"

# unpkg.com returns 500 for ``@tabler/icons-webfont`` (empirically since
# at least 2026-04). Pin to jsDelivr — same versioned mirror of npm.
TI_VERSION = "3.41.0"
TI_PATH = f"https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@{TI_VERSION}/dist"

TABLER_VERSION = "1.4.0"
TABLER_PATH = f"https://cdn.jsdelivr.net/npm/@tabler/core@{TABLER_VERSION}/dist"

# TinyMCE Community Edition (GPLv2-or-later).
# Self-hosted only — no CDN runtime references (Zero-Trust data pillar,
# GDPR Art. 44 ff.). The npm tarball ships ``LICENSE.TXT`` at the root
# of the package directory; keep it so the GPLv2 notice is distributed
# with the assets (FUDGE condition 3).
TINYMCE_VERSION = "7.9.2"
TINYMCE_TARBALL = f"https://registry.npmjs.org/tinymce/-/tinymce-{TINYMCE_VERSION}.tgz"

# Language packs ship in a separate npm package (``tinymce-i18n``) that
# tracks all major TinyMCE versions in parallel sub-directories
# (``langs5/``, ``langs6/``, ``langs7/``, ``langs8/``). For TinyMCE 7 we
# pull only ``langs7/`` and remap it to ``langs/`` so the runtime
# ``language_url`` (``/static/conjunto/tinymce/langs/<code>.js``) resolves.
TINYMCE_I18N_VERSION = "26.4.6"
TINYMCE_I18N_TARBALL = (
    f"https://registry.npmjs.org/tinymce-i18n/-/tinymce-i18n-{TINYMCE_I18N_VERSION}.tgz"
)


# ── LIBRARIES registry ──────────────────────────────────────────────────

LIBRARIES: dict[str, list | dict] = {
    "alpine": [
        ("js/alpine.js", f"{UNPKG}/alpinejs/dist/cdn.js", "w"),
        ("js/alpine.min.js", f"{UNPKG}/alpinejs/dist/cdn.min.js", "w"),
    ],
    "chartjs": [
        ("js/chart.min.js", f"{UNPKG}/chart.js@4.4.9/dist/chart.umd.js", "w"),
    ],
    "dropzone": [
        ("js/dropzone.min.js", f"{UNPKG}/dropzone@5/dist/min/dropzone.min.js", "w"),
        ("js/dropzone.js", f"{UNPKG}/dropzone@5/dist/dropzone.js", "w"),
        ("css/dropzone.min.css", f"{UNPKG}/dropzone@5/dist/min/dropzone.min.css", "w"),
        ("css/dropzone.css", f"{UNPKG}/dropzone@5/dist/dropzone.css", "w"),
    ],
    "fslightbox": [
        ("js/fslightbox.js", f"{UNPKG}/fslightbox", "w"),
    ],
    "htmx": [
        ("js/htmx/htmx.js", f"{UNPKG}/htmx.org@latest/dist/htmx.js", "w"),
        ("js/htmx/htmx.min.js", f"{UNPKG}/htmx.org@latest/dist/htmx.min.js", "w"),
        ("js/htmx/ext/ws.js", "https://cdn.jsdelivr.net/npm/htmx-ext-ws@2.0.4", "w"),
        ("js/htmx/ext/debug.js", f"{UNPKG}/htmx.org@latest/dist/ext/debug.js", "w"),
        (
            "js/htmx/ext/head-support.js",
            f"{UNPKG}/htmx-ext-head-support@latest",
            "w",
        ),
    ],
    "litepicker": [
        ("js/litepicker.js", f"{UNPKG}/litepicker/dist/litepicker.js", "w"),
    ],
    "sortable": [
        (
            "js/Sortable.min.js",
            "https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js",
            "w",
        ),
        (
            "js/Sortable.js",
            "https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.js",
            "w",
        ),
    ],
    "tinymce": {
        "type": "tarball",
        "url": TINYMCE_TARBALL,
        "dest": "tinymce",
        "strip_components": 1,  # drop the ``package/`` wrapper
        "keep": (
            "tinymce.min.js",
            "tinymce.js",
            "icons",
            "models",
            "plugins",
            "skins",
            "themes",
            # License & notices — MUST be shipped alongside the assets
            # (GPLv2 distribution obligation). TinyMCE renamed
            # ``LICENSE.TXT`` to ``license.md`` somewhere around v7.5.
            "license.md",
            "README.md",
            "CHANGELOG.md",
            "package.json",
        ),
    },
    # Language packs for TinyMCE 7. Extracted into the same ``tinymce/``
    # destination so they sit next to ``tinymce.min.js`` under
    # ``langs/<code>.js`` — the path the runtime ``language_url`` config
    # in ``conjunto_require_tinymce`` points at.
    "tinymce-i18n": {
        "type": "tarball",
        "url": TINYMCE_I18N_TARBALL,
        "dest": "tinymce",
        "strip_components": 1,
        "keep": ("langs7", "LICENSE.md", "NOTICE.md"),
        "rename": {"langs7": "langs"},
    },
    "tabler": [
        ("css/tabler.css", f"{TABLER_PATH}/css/tabler.css", "w"),
        ("css/tabler.min.css", f"{TABLER_PATH}/css/tabler.min.css", "w"),
        ("js/tabler.js", f"{TABLER_PATH}/js/tabler.js", "w"),
        ("js/tabler.min.js", f"{TABLER_PATH}/js/tabler.min.js", "w"),
        ("js/tabler-theme.js", f"{TABLER_PATH}/js/tabler-theme.js", "w"),
        ("js/tabler-theme.min.js", f"{TABLER_PATH}/js/tabler-theme.min.js", "w"),
        ("css/fonts/tabler-icons.woff", f"{TI_PATH}/fonts/tabler-icons.woff", "wb"),
        ("css/fonts/tabler-icons.woff2", f"{TI_PATH}/fonts/tabler-icons.woff2", "wb"),
        ("css/tabler-icons.css", f"{TI_PATH}/tabler-icons.css", "w"),
        ("css/tabler-icons.min.css", f"{TI_PATH}/tabler-icons.min.css", "w"),
    ],
}


# ── Library classification ──────────────────────────────────────────────
#
# These three sets mirror the loading classification in
# ``conjunto/templatetags/conjunto.py`` (CORE_JS / APP_JS / FEATURE_JS).
# They drive ``--suggest``: every project that uses conjunto needs the
# CORE set unconditionally; ``conjunto/app_base.html``-extending
# projects also need the APP_LAYOUT set; FEATURE libs are added based
# on which ``{% conjunto_require_X %}`` tags appear.

CORE_LIBRARIES: frozenset[str] = frozenset({"htmx", "tabler"})

APP_LAYOUT_LIBRARIES: frozenset[str] = frozenset({"alpine", "litepicker", "sortable"})

# Maps the X in ``{% conjunto_require_X %}`` to the library name.
FEATURE_TAG_TO_LIBRARY: dict[str, str] = {
    "chart": "chartjs",
    "dropzone": "dropzone",
    "fslightbox": "fslightbox",
    "tinymce": "tinymce",
}

# Pairs of libraries that always belong together.
LIBRARY_COMPANIONS: dict[str, tuple[str, ...]] = {
    "tinymce": ("tinymce-i18n",),
}


# ── Download primitives ─────────────────────────────────────────────────


def _download_tarball(name: str, spec: dict, dest_root: Path) -> bool:
    """Fetch an npm-style tarball and extract selected members.

    Strips ``strip_components`` leading path segments. When ``keep`` is
    set, only top-level members listed there (plus their children) are
    written. All other members are skipped — keeps the static tree
    reasonably small for packages like TinyMCE.

    ``rename`` is an optional mapping ``{src: dst}`` applied to the
    first path segment after stripping; used by ``tinymce-i18n`` to
    materialize ``langs7/de.js`` as ``langs/de.js``.
    """
    url = spec["url"]
    dest = dest_root / spec["dest"]
    strip = spec.get("strip_components", 0)
    keep = set(spec["keep"]) if spec.get("keep") else None
    rename = spec.get("rename") or {}

    print(f"  tarball  <-  {url}")
    response = requests.get(url, stream=True)
    if response.status_code != 200:
        print(
            f"  ERROR {response.status_code}: could not fetch {url}",
            file=sys.stderr,
        )
        return False

    os.makedirs(dest, exist_ok=True)
    written = 0
    buf = io.BytesIO(response.content)
    with tarfile.open(fileobj=buf, mode="r:gz") as tar:
        for member in tar.getmembers():
            if not (member.isfile() or member.isdir()):
                # skip symlinks / devices — defence in depth
                continue
            parts = member.name.split("/")
            if len(parts) <= strip:
                continue
            rel_parts = list(parts[strip:])
            if keep is not None and rel_parts[0] not in keep:
                continue
            if rel_parts[0] in rename:
                rel_parts[0] = rename[rel_parts[0]]
            rel_path = Path(*rel_parts)
            target = dest / rel_path

            # Path-traversal guard: target must stay inside dest.
            try:
                target.resolve().relative_to(dest.resolve())
            except ValueError:
                print(
                    f"  SKIP unsafe path in tarball: {member.name}",
                    file=sys.stderr,
                )
                continue

            if member.isdir():
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(target.parent, exist_ok=True)
            extracted = tar.extractfile(member)
            if extracted is None:
                continue
            with open(target, "wb") as f:
                f.write(extracted.read())
            written += 1
    print(f"  extracted {written} files into {dest}")
    return True


def download_library(name: str, dest_root: Path) -> bool:
    """Download library ``name`` into ``dest_root``.

    ``dest_root`` is the directory that will hold ``js/``, ``css/``,
    ``tinymce/``, … sub-trees — typically
    ``settings.CONJUNTO_VENDOR_DIR`` for consumer projects, or
    ``<conjunto-repo>/src/conjunto/static/conjunto`` for the conjunto
    dev workflow.
    """
    entry = LIBRARIES[name]
    if isinstance(entry, dict) and entry.get("type") == "tarball":
        return _download_tarball(name, entry, dest_root)

    files = entry
    ok = True
    for file_name, url, mode in files:
        target = dest_root / file_name
        os.makedirs(target.parent, exist_ok=True)
        print(f"  {file_name}  <-  {url}")
        response = requests.get(url)
        if response.status_code != 200:
            print(
                f"  ERROR {response.status_code}: could not fetch {url}",
                file=sys.stderr,
            )
            ok = False
            continue
        with open(target, mode) as f:
            if mode == "w":
                f.write(response.text)
            else:
                f.write(response.content)
    return ok


# ── Expected-file enumeration (for --check and tests) ───────────────────


def iter_expected_files(name: str) -> Iterator[Path]:
    """Yield relative paths that ``download_library(name)`` is expected to produce.

    For file-by-file libraries this is the literal ``file_name`` from each
    tuple. For tarball libraries we yield a small set of canary files
    drawn from the registry: the entry-point JS (when known) plus any
    LICENSE / NOTICE files in ``keep`` (the latter is the GPLv2 guard
    for TinyMCE).

    The iterator deliberately does *not* pre-walk every member of every
    tarball — that would require unpacking the archive at registry
    inspection time. The canary set is enough for ``--check`` to detect
    a missing or incomplete install.
    """
    entry = LIBRARIES[name]
    if isinstance(entry, dict) and entry.get("type") == "tarball":
        sub = Path(entry["dest"])
        seen: set[Path] = set()
        for member in entry.get("keep", ()):
            # Only top-level files (with an extension) are reliable
            # canaries; sub-directories like ``plugins/`` would require
            # unpacking the tarball to enumerate members.
            if "." not in member:
                continue
            rel = sub / member
            if rel not in seen:
                seen.add(rel)
                yield rel
        # Library-specific extra canaries (paths produced by ``rename``
        # logic or otherwise not present in ``keep`` literally):
        if name == "tinymce-i18n":
            extra = sub / "langs" / "de.js"
            if extra not in seen:
                yield extra
        return

    for file_name, _url, _mode in entry:
        yield Path(file_name)


def is_library_present(name: str, dest_root: Path) -> tuple[bool, list[Path]]:
    """Return ``(all_present, missing_paths)`` for ``name`` under ``dest_root``."""
    missing: list[Path] = []
    for rel in iter_expected_files(name):
        if not (dest_root / rel).exists():
            missing.append(rel)
    return (not missing, missing)


# ── Reverse index: static path → library name (for --suggest) ───────────


def _build_reverse_index() -> dict[str, str]:
    """Build a static-path → library lookup.

    Maps every concrete file path the registry produces back to its
    library. Tarball libraries register their ``dest`` directory as a
    *prefix* (one entry, value = library name) since we cannot
    enumerate every TinyMCE plugin file at registry-construction time.

    When multiple tarball libraries share a ``dest`` (e.g. ``tinymce``
    and ``tinymce-i18n`` both write into ``tinymce/``), the **first**
    registered library wins. The :data:`LIBRARY_COMPANIONS` mechanism
    then ensures the secondary library is suggested alongside the
    primary one.
    """
    index: dict[str, str] = {}
    for name, entry in LIBRARIES.items():
        if isinstance(entry, dict) and entry.get("type") == "tarball":
            # Prefix-style: any "<dest>/..." path belongs to this library.
            # Stored with a trailing "/" sentinel so prefix matching is
            # unambiguous (``tinymce/`` matches ``tinymce/foo`` but not
            # ``tinymce-other/bar``).
            key = entry["dest"] + "/"
            index.setdefault(key, name)
            continue
        for file_name, _url, _mode in entry:
            index.setdefault(file_name, name)
    return index


REVERSE_INDEX: dict[str, str] = _build_reverse_index()


def lookup_library_for_path(rel_path: str) -> str | None:
    """Return the library name owning ``rel_path`` (relative to
    ``static/conjunto/``), or ``None`` if no entry matches.
    """
    if rel_path in REVERSE_INDEX:
        return REVERSE_INDEX[rel_path]
    # Prefix-match for tarball libraries.
    for prefix, lib in REVERSE_INDEX.items():
        if prefix.endswith("/") and rel_path.startswith(prefix):
            return lib
    return None


# ── Template-scan suggestion algorithm ──────────────────────────────────


_RE_REQUIRE_TAG = re.compile(r"{%\s*conjunto_require_(\w+)\s*%}")
_RE_STATIC_REF = re.compile(r"""{%\s*static\s+['"]conjunto/([^'"]+)['"]""")
_RE_EXTENDS_APP_BASE = re.compile(r"""{%\s*extends\s+['"]conjunto/app_base\.html['"]""")


def suggest_libraries(template_dirs: Iterable[Path]) -> set[str]:
    """Scan the given template directories and return the libraries
    they require.

    Algorithm:
      1. Start with :data:`CORE_LIBRARIES`.
      2. Walk every ``*.html`` under each ``template_dirs`` entry.
      3. Match ``{% conjunto_require_X %}`` → :data:`FEATURE_TAG_TO_LIBRARY`.
      4. Match ``{% static "conjunto/<path>" %}`` → :func:`lookup_library_for_path`.
      5. If any template extends ``conjunto/app_base.html``, add
         :data:`APP_LAYOUT_LIBRARIES`.
      6. Apply :data:`LIBRARY_COMPANIONS` (e.g. tinymce → tinymce-i18n).

    Returns the set, which the caller usually ``sorted()``-s for
    deterministic output. Unresolvable patterns (dynamic ``{% include
    some_var %}``, conditional dispatch via Python) are *not*
    discovered — this is documented behaviour.
    """
    libs: set[str] = set(CORE_LIBRARIES)
    saw_app_base = False

    for root in template_dirs:
        if not root.exists() or not root.is_dir():
            continue
        for path in root.rglob("*.html"):
            try:
                text = path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            for tag in _RE_REQUIRE_TAG.findall(text):
                lib = FEATURE_TAG_TO_LIBRARY.get(tag)
                if lib:
                    libs.add(lib)
            for static_ref in _RE_STATIC_REF.findall(text):
                lib = lookup_library_for_path(static_ref)
                if lib:
                    libs.add(lib)
            if not saw_app_base and _RE_EXTENDS_APP_BASE.search(text):
                saw_app_base = True

    if saw_app_base:
        libs.update(APP_LAYOUT_LIBRARIES)

    # Apply companion pairing (tinymce → tinymce-i18n etc.).
    for lib in list(libs):
        for companion in LIBRARY_COMPANIONS.get(lib, ()):
            libs.add(companion)

    return libs
