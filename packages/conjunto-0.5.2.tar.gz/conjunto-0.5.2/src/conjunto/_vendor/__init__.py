"""Internal subpackage for vendored-library plumbing.

The leading underscore signals "internal API"; importing from
``conjunto._vendor`` from app code is unsupported. Public surface is the
``update_libraries`` management command.
"""
