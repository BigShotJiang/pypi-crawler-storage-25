from typing import Any, Callable, Optional

from django.core.exceptions import ImproperlyConfigured, PermissionDenied
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.utils.translation import gettext_lazy as _
from django.views import View
from django.views.generic import DeleteView, CreateView, UpdateView, DetailView
from django_htmx.http import HttpResponseClientRedirect, trigger_client_event

from conjunto.http import HttpResponseEmpty
from conjunto.views import CrispyFormHelperMixin, DialogType, AutoPermissionsViewMixin


class DependentFieldsView(View):
    """Generic view for handling HTMX dependent-field re-renders.

    Instantiates ``form_class`` with ``initial=`` from GET params so the
    form stays **unbound** — no validation errors are shown during
    field-change re-renders.  Validation only happens on actual form
    submission (POST).

    ``apply_dependencies()`` runs automatically in the form's
    ``__init__`` (via ``DependentFieldsMixin``), using the ``initial``
    values to call the ``*_changed()`` callbacks.

    By default **all** ``*_changed()`` callbacks run on every re-render. This
    is the safe choice when you have multiple independent triggers — e.g. a
    ``country`` filter for ``federal_state`` and a ``health_care_type``
    visibility toggle for ``speciality``: changing one trigger must not wipe
    the other's state.

    For forms where every callback is genuinely independent (no shared
    queryset or visibility state across triggers) you can opt into the
    leaner mode by setting ``isolate_triggered_callback = True``. The view
    then forwards the HTMX ``HX-Trigger-Name`` header as ``triggered_field``
    to the form, and only that one callback runs. This saves DB lookups on
    every re-render but **requires** that no other dependent state is
    re-derived inside skipped callbacks.

    Subclass and set ``form_class`` and ``template_name`` (typically a
    Django 6 partial like ``"app/signup.html#form_body"``).

    Override ``get_context_data()`` to inject extra context.

    Example::

        class SignupFragmentView(DependentFieldsView):
            form_class = SignupForm
            template_name = "medspeak/medspeakaccount_signup.html#signup_form_body"
    """

    form_class = None
    template_name = None
    isolate_triggered_callback: bool = False

    def get_form(self, request):
        """Instantiate the form with initial= (not data=) so it is unbound."""
        kwargs = {"initial": request.GET.dict()}
        if self.isolate_triggered_callback:
            triggered = request.headers.get("HX-Trigger-Name")
            if triggered:
                kwargs["triggered_field"] = triggered
        return self.form_class(**kwargs)

    def get(self, request, *args, **kwargs):
        form = self.get_form(request)
        return render(request, self.template_name, self.get_context_data(form=form))

    def get_context_data(self, **kwargs):
        return kwargs


class HtmxRequestMixin:
    """Optionally checks if request originates from HTMX.

    Attributes:
        enforce_htmx: if True, all requests that do not come from a HTMX element are blocked.

    Raises:
        PermissionDenied: if enforce_htmx==True and request origins from a non-HTMX caller.
    """

    enforce_htmx: bool = True

    def dispatch(self, request, *args, **kwargs):
        if self.enforce_htmx and not self.request.htmx:
            raise PermissionDenied(
                f"Permission denied: View {self.__class__.__name__} can only be called by a HTMX request."
            )
        return super().dispatch(request, *args, **kwargs)


class SuccessEventMixin(HtmxRequestMixin):
    """A HTMX view mixin that always returns an empty response.

    Attributes:
        success_event: a Javascript event that is triggered on the client after
            the request is completed.

    Returns:
        A response with a "HX-Trigger" attribute which triggers a Javascript event
        on the client.

    If your view parents have a `post` method, that method is called, and it's response
    is reused and modified, so that the event is triggered on the client.

    If your view has no post method (TemplateView etc.), a HttpResponseEmpty is created.
    """

    success_event: str = ""

    def get_success_event(self):
        """Override this to return (e.g. generated) success event."""
        return self.success_event

    def dispatch(self, request, *args, **kwargs):
        """If POST request and response status is 200, trigger a Javascript event."""
        response = super().dispatch(request, *args, **kwargs)
        if (
            request.htmx
            and self.request.method == "POST"
            and self.get_success_event()
            and 200 <= response.status_code < 300
        ):
            trigger_client_event(response, self.get_success_event())

        return response


class HtmxFormViewMixin(SuccessEventMixin):
    """
    Mixin for a FormView that uses HTMX.

    If any of the parent views return a HttpResponseRedirect, it will be converted
    into a HttpResponseClientRedirect, so that HTMX does the redirection on the client.
    HTMX forms also accept an empty success_url, if a success_event is present,
    e.g. could a form reload itself after a button was pressed. There is not always
    a need to redirect.

    In case of a normal request origin (enforce_htmx must be False then), the original
    HttpResponse(Redirect?) is kept as is.
    """

    def get_success_url(self):
        """Return success_url, even if it is empty.

        FormViews raise an Exception if success_url is empty. We need to capture that.
        """
        return getattr(self, "success_url", "")

    def form_valid(self, form):
        """Trigger a Javascript event on the client."""
        response = super().form_valid(form)
        # if coming from a HTMX request, and there is a success_url, we need to redirect
        # to it's URL using HTMX. So we replace the HttpResponseRedirect with a
        # `HX-Trigger` version.
        # FIXME: this shouldn't be in form_valid(), as it interferes with saving of
        #  form data. Should be in post() or dispatch().
        #  if e.g. a child view decides not to call super().form_valid (which is ok!)
        #  this code isn't called - but it should be.

        success_url = self.get_success_url()
        if self.request.htmx and isinstance(response, HttpResponseRedirect):
            # if neither success_url nor success_event is set, raise original Exception.
            if not success_url and not self.get_success_event():
                raise ImproperlyConfigured(
                    "No URL to redirect to. Provide a "
                    "success_url, or a success_event."
                )

            if success_url:
                response = HttpResponseClientRedirect(success_url)
            else:
                response = HttpResponseEmpty()

        # in case of a normal request origin, the original HttpResponse(Redirect?) is
        # kept as is.
        return response


class RowRemoveDeleteMixin:
    """Mixin that turns a delete view into the HTMX ``row-remove`` flow.

    Set ``success_strategy = "row-remove"`` to enable; with the default
    ``"default"`` the mixin is a no-op so existing views keep working.

    On a successful HTMX delete, the response is rewritten to:

    - status ``200`` with an empty body,
    - ``HX-Retarget: <row_target>`` (default
      ``"#row-<slug>-<pk>"`` built from ``row_id_namespace``),
    - ``HX-Reswap: outerHTML swap:0.3s`` (override via ``row_swap``),
    - an additional ``closeModal`` ``HX-Trigger`` so a wrapping
      modal is dismissed (harmless when there is no modal).

    The regular ``success_event`` is still emitted by
    ``SuccessEventMixin.dispatch`` so sub-listeners (counters,
    aggregate headers) can refresh on the side — ``row-remove`` is
    additive, not either-or.

    The mixin **must** sit ahead of any view in the MRO that triggers
    ``Model.delete()`` (which sets ``self.object.pk = None``). It
    captures the row target *before* calling ``super().form_valid()``
    so the pk is still available.
    """

    success_strategy: str = "default"
    """``"default"`` or ``"row-remove"``. See class docstring."""

    row_id_namespace: str = ""
    """Slug used in the default row target.

    Should match the consuming table's ``row_actions_namespace``
    (e.g. ``"meetings:attendance"``). The mixin slugifies it to
    ``"meetings-attendance"`` for the CSS id.
    """

    row_target: Optional[str | Callable[[Any], str]] = None
    """CSS selector (or callable ``(self) -> str``) for the ``<tr>``.

    When ``None`` and ``success_strategy == "row-remove"``, the
    mixin derives ``"#row-<slugified-namespace>-<pk>"``. Override
    for non-default row id templates.
    """

    row_swap: str = "outerHTML swap:0.3s"
    """Value forwarded as ``HX-Reswap``. Default fades the row out."""

    def get_row_target(self) -> str:
        if callable(self.row_target):
            return self.row_target(self)
        if self.row_target:
            return str(self.row_target)
        from django.utils.text import slugify

        # Replace ``:`` BEFORE slugify because Django's slugify drops
        # the colon entirely without inserting a separator. Must match
        # ``RowActionsMixin.get_row_id`` so the ids line up.
        ns = slugify(self.row_id_namespace.replace(":", "-"))
        return f"#row-{ns}-{self.object.pk}"

    def form_valid(self, form):
        wants_row_remove = self.request.htmx and self.success_strategy == "row-remove"
        # Capture the target BEFORE super(): a downstream form_valid
        # (HtmxDeleteView, DeleteView) calls Model.delete() which sets
        # self.object.pk to None.
        row_target = self.get_row_target() if wants_row_remove else None

        response = super().form_valid(form)

        if wants_row_remove:
            response = HttpResponse("", status=200)
            response["HX-Retarget"] = row_target
            response["HX-Reswap"] = self.row_swap
            # SuccessEventMixin.dispatch adds the configured
            # success_event on the way out (status 200 keeps it
            # inside the 2xx gate), so we don't trigger it twice.
            # We only add closeModal here — harmless when the
            # request did not originate from a modal.
            trigger_client_event(response, "closeModal")
        return response


class HtmxDeleteView(RowRemoveDeleteMixin, HtmxFormViewMixin, DeleteView):
    """Enhanced DeleteView that per default returns an empty HttpResponse.

    Uses the `success_url` attribute of the view to get the URL to redirect
    to via HTMX after successful deletion. If `success_url` is None, no redirection is
    made.

    Set ``success_strategy = "row-remove"`` (and ``row_id_namespace``)
    to opt into the HTMX-idiomatic row-removal flow — see
    :class:`RowRemoveDeleteMixin`.

    Deletion happens in ``BaseDeleteView.form_valid`` via the super
    chain — this view does **not** call ``self.object.delete()``
    explicitly to avoid the double-delete that would raise
    ``ValueError: ... can't be deleted because its pk attribute is
    set to None.`` (Model.delete() clears the instance's pk on
    success.)
    """

    # most of the time, you will use POST, or a modal dialog for deleting,
    # so use this as default template, override as needed.
    template_name = "conjunto/modal_confirm_delete.html"


class ModalFormViewMixin(HtmxFormViewMixin, CrispyFormHelperMixin):
    """Mixin for FormViews that should live in a modal.

    It relies on crispy-forms intensively, and already provides a form
    helper instance attribute you can use.

    In many cases, you need no template, as this mixin provides a generic one with
    a customizable title. The form is generated using crispy-forms.
    If you want to customize if further, then, extend "conjunto/modal_form.html".
    This template uses a ``header`` with a ``title`` block, a ``body``,
    and a ``footer`` block to override, for your modal dialog. In the
    footer, there is always a "Cancel" button, and as default, a "Save"
    button, You can fully override the buttons using the "footer" block.

    When the modal pops up, the focus is set to the first visible input
    element.

    You can customize the content of the "Save" button by changing the `button_content`
    attribute to another string.

    If the form is saved successfully, it returns an empty HttpResponse(204)
    and emits the event specified in ``success_event`` on the client,
    so that it can reload changed content.

    Attributes:
        modal_title: the title of the modal form
        autofocus_field: the field that gets the autofocus when the modal is shown
        button_content: the content of the 'Save' button. Default: _("Save")
        dialog_type: the type of the dialog: INFO, DELETE, CREATE, UPDATE
        autocomplete: if True, let the browser autocomplete the form. Default: True
    """

    template_name = "conjunto/modal_form.html"
    """The default template name for the modal form. This template provides
    a simple modal form. You can extend it in your own templates too."""

    modal_title: str = ""

    autofocus_field = ""  # FIXME: fix autofocus field

    autocomplete = True

    button_content = _("Save")

    dialog_type: DialogType = DialogType.NOTSET

    def get_modal_title(self) -> str:
        """Returns a string that is used as title of the modal."""
        return self.modal_title

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        icon = ""
        submit_btn_css_class = ""
        form_attrs = {}
        if self.autocomplete:
            form_attrs["autocomplete"] = "off"
        match self.dialog_type:
            case DialogType.DELETE:
                icon = "trash"
                submit_btn_css_class = "danger danger"
            case DialogType.INFO:
                icon = "info-circle"
                submit_btn_css_class = "info info"
        context.update(
            {
                "modal_title": self.get_modal_title(),
                "button_content": self.button_content,
                "dialog_type": self.dialog_type,
                "DialogType": DialogType,
                "icon": icon,
                "submit_button_css_class": submit_btn_css_class or "primary",
                "form_attrs": " ".join(
                    [f"{key}={value}" for key, value in form_attrs.items()]
                ),
            }
        )
        return context


class _ModalModelViewMixin(AutoPermissionsViewMixin, ModalFormViewMixin):
    """Internal mixin for Create/Update/DeleteViews (with permissions) that lives in a
    Modal.

    You shouldn't have to use this directly.

    It automatically generates the Modal title. Override as needed.

    Attributes:
        _modal_title_template: the title of the modal dialog,
            with an `{instance}` placeholder.
    """

    _modal_title_template = None  # "Edit/Create '{instance}'"

    def get_modal_title(self) -> str:
        if self.modal_title:
            return self.modal_title
        if self._modal_title_template:
            return self._modal_title_template.format(
                instance=self.model._meta.verbose_name
            )
        return ""


class ModalCreateView(_ModalModelViewMixin, CreateView):
    """Convenience CreateView (with permissions) that lives in a Modal.

    It automatically generates the Modal title and sets the "create_<model>" permission
    of the given model as necessary permission. Override as needed.
    """

    _permissions_verb = "add"
    _modal_title_template = _("Create '{instance}'")


class ModalUpdateView(_ModalModelViewMixin, UpdateView):
    """Convenience UpdateView (with permissions) that lives in a Modal.

    It automatically generates the Modal title and sets the "change_<model>" permission
    of the given model as necessary permission. Override as needed.
    """

    button_content = _("Save")
    dialog_type = DialogType.UPDATE
    _permissions_verb = "change"
    _modal_title_template = _("Edit '{instance}'")


class ModalDetailView(_ModalModelViewMixin, DetailView):
    """Convenience DetailView (with permissions) that lives in a Modal."""

    dialog_type = DialogType.NOTSET
    _permissions_verb = "view"
    _modal_title_template = None


class ModalDeleteView(RowRemoveDeleteMixin, _ModalModelViewMixin, DeleteView):
    """Convenience DeleteView (with permissions) that lives in a Modal.

    It automatically generates the Modal title and sets the
    ``delete_<model>`` permission of the given model as necessary
    permission. Override as needed.

    Set ``success_strategy = "row-remove"`` (and ``row_id_namespace``)
    to opt into the HTMX-idiomatic row-removal flow — the modal is
    auto-closed on success via a ``closeModal`` ``HX-Trigger``. See
    :class:`RowRemoveDeleteMixin`.
    """

    button_content = _("Delete")
    template_name = "conjunto/modal_confirm_delete.html"
    dialog_type = DialogType.DELETE
    _permissions_verb = "delete"
    _modal_title_template = _("Delete '{instance}'")
    # Deletion happens in BaseDeleteView.form_valid via the super
    # chain — same contract as HtmxDeleteView. RowRemoveDeleteMixin
    # captures the row target before super() so the pk is still
    # available even though Model.delete() will clear it.


class BulkActionView(HtmxRequestMixin, View):
    """Server-side base for a multi-record bulk action.

    Companion to :class:`conjunto.tables.BulkAction`. The bar button
    sends the user-selected primary keys as a list under ``pks`` (or
    whatever :attr:`pk_field` overrides). ``GET`` requests are
    intended for the modal-confirm flow — they render :attr:`template_name`
    with ``pks``, ``count`` and ``queryset`` in context so a template
    can show "Delete these N items?" with the chosen records and a
    submit button POSTing back to the same URL. ``POST`` performs the
    action via :meth:`perform` and returns ``204 No Content`` with
    ``HX-Trigger: <success_event>``. The caller's list wrapper is
    expected to listen for ``<success_event>`` and re-fetch itself.

    Subclasses must set at least :attr:`model` (or override
    :meth:`get_queryset`) and :meth:`perform`. Permissions are
    enforced via :attr:`permission_required` (Django perm string) —
    return ``True`` from :meth:`has_permission` for an open endpoint.

    Pks land twice in the request lifecycle:

    - On the initial GET (bar button → modal), they arrive as query
      parameters (``hx-include`` on the button forwards them).
    - On the POST submit (modal form → action), they arrive as form
      fields rendered by the modal template as hidden ``<input
      name="pks">`` elements — see ``modal_confirm_bulk.html``.

    The default :attr:`template_name` renders the generic confirm
    modal; override per-action when the wording matters
    ("Delete N accounts" vs. "Block N accounts with reason"). For
    the no-confirm path (``BulkAction.confirm`` empty), the bar
    button POSTs directly and :meth:`get` is never called.
    """

    enforce_htmx = True
    http_method_names = ["get", "post"]

    #: Name of the form / query parameter carrying selected pks.
    pk_field: str = "pks"

    #: Model class to filter by ``pk__in``. Override
    #: :meth:`get_queryset` for non-default managers or extra scope.
    model = None

    #: Django permission string. Empty string means "open" — typically
    #: combined with view-level perm checks on the consumer side.
    permission_required: str = ""

    #: HTMX event triggered on a successful POST (204 response).
    success_event: str = ""

    #: Template rendered on GET to confirm the action.
    template_name: str = "conjunto/tables/_bulk_confirm.html"

    def get_pks(self) -> list[str]:
        source = (
            self.request.POST if self.request.method == "POST" else self.request.GET
        )
        return source.getlist(self.pk_field)

    def get_queryset(self):
        if self.model is None:
            raise ImproperlyConfigured(
                f"{type(self).__name__} requires `model` or a "
                f"`get_queryset()` override."
            )
        return self.model._default_manager.filter(pk__in=self.get_pks())

    def has_permission(self) -> bool:
        if not self.permission_required:
            return True
        user = getattr(self.request, "user", None)
        return bool(user and user.has_perm(self.permission_required))

    def dispatch(self, request, *args, **kwargs):
        if not self.has_permission():
            raise PermissionDenied
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        qs = self.get_queryset()
        return {
            "pks": self.get_pks(),
            "pk_field": self.pk_field,
            "queryset": qs,
            "count": qs.count(),
            "action_url": self.request.path,
            **kwargs,
        }

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, self.get_context_data())

    def post(self, request, *args, **kwargs):
        qs = self.get_queryset()
        self.perform(qs)
        response = HttpResponse(status=204)
        if self.success_event:
            response["HX-Trigger"] = self.success_event
        return response

    def perform(self, queryset):  # pragma: no cover - subclass hook
        """Apply the bulk action to ``queryset``.

        Override in subclasses. The default raises so a mis-wired view
        fails loudly instead of silently doing nothing.
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement perform(queryset)."
        )
