"""Wizard step form helpers.

:class:`WizardStepForm` is a thin ``forms.Form`` subclass that knows how to

* accept a ``draft`` + ``step`` on construction and pull initial values
  (both scalars and persisted file references) from the draft,
* tell the ``PersistentFileField`` widgets which ``hx-delete`` URL to use
  for the "Remove" button,
* persist its own ``cleaned_data`` + ``UploadedFile`` values back into the
  :class:`~conjunto.wizard.models.WizardDraft`.

Forms *without* file fields can subclass :class:`WizardStepForm` or just
plain ``forms.Form`` — nothing in the wizard code forces the base class.
Only file fields need the persistence round-trip, and those need the
widget's ``delete_url`` attribute wired up.
"""

from __future__ import annotations

from django import forms
from django.core.files.uploadedfile import UploadedFile
from django.urls import NoReverseMatch, reverse

from conjunto.forms.fields import PersistentFileField
from conjunto.wizard.models import WizardDraft, WizardDraftFile


class WizardStepForm(forms.Form):
    """Base class for wizard step forms.

    Extra constructor kwargs:

    * ``draft`` — :class:`WizardDraft` the form belongs to.
    * ``step`` — slug of the current step.
    * ``wizard_url_namespace`` — optional namespace prefix used when
      building ``hx-delete`` URLs for persistent file fields. Defaults to
      empty, which assumes a project-level URL name ``wizard-file-delete``.
      Consumers typically override by passing e.g. ``"onboarding"`` so
      ``reverse("onboarding:wizard-file-delete", args=[pk])`` is tried.

    The constructor:

    1. Pulls scalar ``initial`` from ``draft.data[step]`` (if not supplied
       by the caller).
    2. Pulls file references from ``draft.files.filter(step=step, field=…)``
       and puts them into ``initial[field_name]``.
    3. For every :class:`PersistentFileField`, sets the widget's
       ``delete_url`` so the "Remove" button appears.
    """

    wizard_url_namespace: str = ""

    def __init__(
        self,
        *args,
        draft: WizardDraft | None = None,
        step: str | None = None,
        wizard_url_namespace: str | None = None,
        **kwargs,
    ) -> None:
        self.draft = draft
        self.step = step or ""
        if wizard_url_namespace is not None:
            self.wizard_url_namespace = wizard_url_namespace

        # Merge draft data / draft files into ``initial`` *before* calling
        # ``super().__init__``; otherwise the field objects have no chance
        # to see the initial values when they build their widgets.
        initial = dict(kwargs.pop("initial", None) or {})
        if draft is not None and step:
            for key, val in draft.get_step_data(step).items():
                initial.setdefault(key, val)
            for draft_file in draft.files.filter(step=step):
                # A persisted file trumps whatever initial value the caller
                # supplied — the persisted file is the authoritative state.
                initial[draft_file.field] = draft_file
        kwargs["initial"] = initial
        super().__init__(*args, **kwargs)

        # Wire delete URLs into ``PersistentFileWidget`` instances.
        for name, field in self.fields.items():
            if not isinstance(field, PersistentFileField):
                continue
            draft_file = (
                draft.files.filter(step=step, field=name).first()
                if draft is not None and step
                else None
            )
            if draft_file is not None:
                field.widget.delete_url = self._build_delete_url(draft_file.pk)

    # ------------------------------------------------------------------ utilities

    def _build_delete_url(self, pk: int) -> str:
        """Resolve the ``hx-delete`` URL for a :class:`WizardDraftFile` pk."""
        candidates = []
        if self.wizard_url_namespace:
            candidates.append(f"{self.wizard_url_namespace}:wizard-file-delete")
        candidates.append("wizard-file-delete")
        for name in candidates:
            try:
                return reverse(name, args=[pk])
            except NoReverseMatch:
                continue
        return ""

    # --------------------------------------------------------------------- save

    def save_to_draft(self, draft: WizardDraft, step: str) -> None:
        """Persist this form's ``cleaned_data`` into the draft.

        * File fields are split off and persisted as :class:`WizardDraftFile`
          rows. The JSON-stored ``data`` dict gets a marker ``{"__file__":
          <WizardDraftFile pk>}`` so later steps can see that the field
          is satisfied.
        * Scalar fields are stored verbatim (JSON-serializable values only;
          the ``DjangoJSONEncoder`` handles ``date``/``Decimal``).

        A "clear" marker (cleaned value ``False``) deletes any existing
        :class:`WizardDraftFile` for that field.
        """
        if not self.is_valid():  # defensive — callers should validate first
            raise ValueError("WizardStepForm.save_to_draft called on an invalid form.")

        file_field_names = {
            name
            for name, field in self.fields.items()
            if isinstance(field, PersistentFileField)
        }

        scalar_data: dict = {}
        for name, value in self.cleaned_data.items():
            if name in file_field_names:
                self._persist_file_value(draft, step, name, value)
                # Replace the binary payload with a reference marker so
                # ``data`` stays JSON-serializable.
                if value:
                    scalar_data[name] = {"__file__": True}
            else:
                scalar_data[name] = value

        draft.set_step_data(step, scalar_data)
        draft.mark_visited(step)
        draft.save()

    def _persist_file_value(
        self,
        draft: WizardDraft,
        step: str,
        field: str,
        value,
    ) -> None:
        existing = draft.files.filter(step=step, field=field).first()
        # ``False`` == clear marker: delete any persisted file, done.
        if value is False:
            if existing is not None:
                existing.delete_from_storage()
                existing.delete()
            return
        # Fresh upload: replace any existing persisted file.
        if isinstance(value, UploadedFile):
            if existing is not None:
                existing.delete_from_storage()
                existing.delete()
            WizardDraftFile.objects.create(
                draft=draft,
                step=step,
                field=field,
                file=value,
                original_name=value.name,
            )
            return
        # An existing WizardDraftFile passed through unchanged — nothing to do.
