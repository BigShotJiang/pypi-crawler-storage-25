"""URL patterns shared by wizard implementations.

Consumers typically mount this module under a namespace that also contains
their concrete ``WizardStepView`` subclass:

.. code-block:: python

    # myapp/urls.py
    from django.urls import path, include
    from conjunto.wizard.urls import wizard_file_urlpatterns
    from .wizards import PatientOnboardingWizard

    app_name = "onboarding"

    urlpatterns = [
        path(
            "",
            PatientOnboardingWizard.as_view(),
            name="wizard-start",
            kwargs={"step": None},
        ),
        path(
            "<slug:step>/",
            PatientOnboardingWizard.as_view(),
            name="wizard-step",
        ),
        *wizard_file_urlpatterns,
    ]

The ``wizard-file-delete`` URL name is expected by
:class:`conjunto.wizard.forms.WizardStepForm` — if you rename it, pass
``wizard_url_namespace`` on the form / view so the delete buttons keep
working.
"""

from __future__ import annotations

from django.urls import path

from conjunto.wizard.views import WizardFileDeleteView


wizard_file_urlpatterns = [
    path(
        "file/<int:pk>/",
        WizardFileDeleteView.as_view(),
        name="wizard-file-delete",
    ),
]

# ``urlpatterns`` is provided for projects that want to ``include()`` this
# module directly. The list contains only the file-delete endpoint; step
# routes must be wired in the consuming URL conf because they reference
# the specific ``WizardStepView`` subclass.
urlpatterns = list(wizard_file_urlpatterns)
