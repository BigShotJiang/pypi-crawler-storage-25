"""conjunto.wizard — generic multi-step form wizard.

The package ships:

* :mod:`conjunto.wizard.models` — ``WizardDraft``, ``WizardDraftFile``
* :mod:`conjunto.wizard.views` — ``WizardViewMixin``, ``WizardStepView``,
  ``WizardFileDeleteView``
* :mod:`conjunto.wizard.forms` — ``WizardStepForm``
* :mod:`conjunto.wizard.middleware` — optional ``WizardDraftMergeMiddleware``
"""

default_app_config = "conjunto.wizard.apps.WizardConfig"
