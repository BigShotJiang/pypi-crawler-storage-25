"""Optional middleware / signal handler for merging anonymous wizard drafts.

Django rotates ``session_key`` on login (session-fixation protection).
Without mitigation, a wizard draft started anonymously would appear
abandoned right after the user logs in. The handler below listens to the
``user_logged_in`` signal and transfers every :class:`WizardDraft` that
was bound to the pre-login session onto the new one — and records the
user for good measure.

Activation (project settings):

.. code-block:: python

    # settings.py
    INSTALLED_APPS = [..., "conjunto.wizard", ...]
    CONJUNTO_WIZARD_MERGE_ON_LOGIN = True  # default: True

Middleware registration is *not* required — the signal handler is connected
in :func:`connect_merge_signal`. A middleware wrapper is provided for
projects that prefer an explicit ``MIDDLEWARE`` entry.
"""

from __future__ import annotations

from django.conf import settings
from django.contrib.auth.signals import user_logged_in
from django.db import IntegrityError, transaction
from django.dispatch import receiver

from conjunto.wizard.models import WizardDraft


def _enabled() -> bool:
    return getattr(settings, "CONJUNTO_WIZARD_MERGE_ON_LOGIN", True)


@receiver(user_logged_in)
def merge_anonymous_drafts(sender, request, user, **kwargs) -> None:
    """Re-bind drafts from the pre-login ``session_key`` onto the new one.

    The signal fires *after* Django has rotated the session_key, but the
    old key is still available on ``request.session.session_key`` only
    until ``login()`` returns — so we read it from the request first if
    needed. In practice, Django calls ``cycle_key()`` inside ``login()``
    *before* sending the signal, so the new key is what we see here. We
    therefore look up by ``user`` first (if the user previously had any
    drafts) and by old keys stashed under
    ``request.session["_wizard_prev_session_key"]``.
    """
    if not _enabled():
        return

    new_session_key = request.session.session_key
    old_session_key = request.session.pop("_wizard_prev_session_key", None)

    if old_session_key and old_session_key != new_session_key:
        drafts = WizardDraft.objects.filter(session_key=old_session_key)
        for draft in drafts:
            # Collisions possible if the authenticated user already has a
            # draft for the same wizard_key. Prefer keeping the anon draft
            # (the user was actively filling it in); drop the older one.
            try:
                with transaction.atomic():
                    WizardDraft.objects.filter(
                        session_key=new_session_key,
                        wizard_key=draft.wizard_key,
                    ).exclude(pk=draft.pk).delete()
                    draft.session_key = new_session_key
                    draft.user = user
                    draft.save(update_fields=["session_key", "user", "updated"])
            except IntegrityError:  # pragma: no cover - defensive
                continue

    # Regardless of key rotation: stamp ``user`` on drafts that now belong
    # to this session but have no owner yet.
    WizardDraft.objects.filter(session_key=new_session_key, user__isnull=True).update(
        user=user
    )


def connect_merge_signal() -> None:  # pragma: no cover - trivial
    """No-op connector kept for explicit imports.

    The signal handler above is already connected via ``@receiver``; this
    function exists so a consumer can do ``connect_merge_signal()`` from
    their ``AppConfig.ready`` to make the dependency explicit.
    """
    return None


class WizardDraftMergeMiddleware:
    """Record the current ``session_key`` before the view runs.

    When Django's ``LoginView`` fires ``user_logged_in`` it has already
    rotated the session key. By stashing the pre-login key here, the
    signal handler above can still find anonymous drafts that belonged to
    the caller.

    Usage: add this entry *before* ``AuthenticationMiddleware`` in
    ``MIDDLEWARE``.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if (
            hasattr(request, "session")
            and request.session.session_key
            and not request.user.is_authenticated
        ):
            request.session["_wizard_prev_session_key"] = request.session.session_key
        return self.get_response(request)
