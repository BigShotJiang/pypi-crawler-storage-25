"""Wizard draft models.

Two models make up the server-side draft state of a wizard flow:

* :class:`WizardDraft` — one row per ``(session_key, wizard_key)``. Holds
  the per-step ``cleaned_data`` dict, the list of visited steps, and an
  optional ``user`` reference for drafts that outlive an anonymous->login
  transition.
* :class:`WizardDraftFile` — one row per ``(draft, step, field)``. Files
  are persisted here server-side because browsers cannot re-populate a
  ``<input type="file">`` across requests.

Identification is primarily via ``session_key``. Django middleware ensures
every request has a session; the wizard view forces the session to be saved
if needed so even anonymous users have a durable key.

Security / Zero-Trust:

* *Identity* — drafts are bound to a session. Sensitive wizards should
  additionally require login by mixing ``LoginRequiredMixin`` into the
  subclass view.
* *Data* — files are stored under ``ProtectedFileSystemStorage``, never
  under the public ``MEDIA_ROOT``.
* *Application* — ``WizardFileDeleteView`` enforces that the caller owns
  the draft (IDOR protection); see :mod:`conjunto.wizard.views`.
"""

from __future__ import annotations

from django.conf import settings
from django.core.serializers.json import DjangoJSONEncoder
from django.db import models

from conjunto.fields import ProtectedFileField


class WizardDraft(models.Model):
    """Server-side state of an in-progress wizard.

    Works for both anonymous and authenticated users. The primary identity
    is the Django session (``session_key``). When a user logs in during
    an active wizard, :class:`~conjunto.wizard.middleware.WizardDraftMergeMiddleware`
    sets ``user`` on the matching draft.
    """

    session_key = models.CharField(max_length=40, db_index=True)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name="wizard_drafts",
    )
    wizard_key = models.CharField(max_length=100)
    current_step = models.CharField(max_length=100, blank=True, default="")
    visited_steps = models.JSONField(default=list, blank=True)
    data = models.JSONField(default=dict, blank=True, encoder=DjangoJSONEncoder)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = "conjunto_wizard"
        constraints = [
            models.UniqueConstraint(
                fields=["session_key", "wizard_key"],
                name="uniq_session_wizard",
            ),
        ]
        indexes = [
            models.Index(fields=["user", "wizard_key"]),
            models.Index(fields=["updated"]),
        ]

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"WizardDraft({self.wizard_key}, session={self.session_key[:8]}…)"

    def mark_visited(self, step: str) -> None:
        """Append ``step`` to ``visited_steps`` if not already present."""
        if step not in self.visited_steps:
            self.visited_steps = [*self.visited_steps, step]

    def set_step_data(self, step: str, cleaned_data: dict) -> None:
        """Store JSON-safe cleaned data for a step.

        File values are *not* stored here; they live in ``WizardDraftFile``.
        Callers must strip uploads before calling this method.
        """
        data = dict(self.data)
        data[step] = cleaned_data
        self.data = data

    def get_step_data(self, step: str) -> dict:
        """Return the stored cleaned_data for a step (or empty dict)."""
        return dict(self.data.get(step, {}))


def _draft_file_upload_to(instance: "WizardDraftFile", filename: str) -> str:
    """Compute a storage sub-path for a draft file.

    Files land under ``wizards/drafts/<draft-id>/<step>/<field>/<filename>``.
    The ``draft-id`` prefix makes per-draft cleanup trivial on disk.
    """
    return f"wizards/drafts/{instance.draft_id}/{instance.step}/{instance.field}/{filename}"


class WizardDraftFile(models.Model):
    """A file uploaded in one step of a wizard, persisted until finish/abort."""

    draft = models.ForeignKey(
        WizardDraft,
        related_name="files",
        on_delete=models.CASCADE,
    )
    step = models.CharField(max_length=100)
    field = models.CharField(max_length=100)
    file = ProtectedFileField(upload_to=_draft_file_upload_to)
    original_name = models.CharField(max_length=255)
    uploaded = models.DateTimeField(auto_now_add=True)

    class Meta:
        app_label = "conjunto_wizard"
        constraints = [
            models.UniqueConstraint(
                fields=["draft", "step", "field"],
                name="uniq_draft_step_field",
            ),
        ]

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"WizardDraftFile({self.step}.{self.field}: {self.original_name})"

    # The PersistentFileWidget inspects ``name``/``url``/``original_name``/``pk``
    # to render the "already uploaded" state — all four are already satisfied
    # by the fields above plus ``file.url`` from the storage.

    @property
    def name(self) -> str:
        """Return the storage-relative file name (for widget display)."""
        try:
            return self.file.name
        except ValueError:
            return self.original_name

    @property
    def url(self) -> str:
        """Return a URL for the file, empty string if the storage can't serve one."""
        try:
            return self.file.url
        except (ValueError, AttributeError):
            return ""

    def delete_from_storage(self) -> None:
        """Remove the physical file from disk (best-effort, ignores missing)."""
        try:
            self.file.delete(save=False)
        except Exception:  # noqa: BLE001 - best effort cleanup
            pass
