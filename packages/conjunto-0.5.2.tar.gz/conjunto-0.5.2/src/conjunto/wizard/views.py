"""Wizard CBVs.

Design goals:

* Works for *anonymous* users — no ``LoginRequiredMixin`` in the base class.
  Sensitive wizards (PII, GDPR-relevant data) should add ``LoginRequiredMixin``
  in the subclass.
* Draft state is identified by ``request.session.session_key``. The first
  step forces a ``session.save()`` so that even anonymous users have a
  stable key.
* HTMX-native: GET returns a step partial, POST validates and swaps the
  next/prev/final step partial. Full-page GETs return the full wizard
  page.
* Navigation: linear-forward, free backward/jump-to-visited. Attempts to
  skip ahead return HTTP 403.

Zero-Trust:

* ``WizardFileDeleteView`` enforces that the ``WizardDraftFile`` belongs
  to the *current* session. Authenticated users additionally must match
  ``draft.user`` when set. This closes IDOR on the delete endpoint.
* Files are stored via ``ProtectedFileField`` → not served from
  ``MEDIA_ROOT``. Consumers must add a URL mapping to serve them only
  to entitled callers (same contract as ``ProtectedMediaBaseView``).
"""

from __future__ import annotations

from typing import Any

from django.core.exceptions import PermissionDenied
from django.http import (
    Http404,
    HttpResponse,
    HttpResponseRedirect,
)
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.views import View
from django.views.generic import TemplateView
from django_htmx.http import HttpResponseClientRedirect

from conjunto.http import HttpResponseEmpty
from conjunto.wizard.models import WizardDraft, WizardDraftFile


# --------------------------------------------------------------------- helpers


def _ensure_session_key(request) -> str:
    """Make sure the current request has a persisted ``session_key``.

    Django lazily creates a session row on first write. For anonymous
    wizard users we force the write here so the draft's primary identity
    is stable across requests.
    """
    if not request.session.session_key:
        request.session.save()
    return request.session.session_key


# ---------------------------------------------------------------- Mixin + Views


class WizardViewMixin:
    """Shared state + navigation helpers for wizard views.

    Class attributes (required on subclasses):

    * ``wizard_key`` — unique string identifying the wizard type.
    * ``steps`` — list of ``(step_name, form_class)`` tuples in order.
    * ``url_name`` — URL name (reverseable) for the step view itself.
      Must accept a ``step`` kwarg.
    * ``success_url`` — where to redirect after :meth:`commit`.

    Optional:

    * ``url_namespace`` — namespace prefix for ``url_name`` and
      ``wizard-file-delete``. Set when including :mod:`conjunto.wizard.urls`
      under a namespace.
    * ``template_name`` — full-page template (defaults to the wizard base).
    * ``partial_template_name`` — HTMX fragment template.
    """

    wizard_key: str = ""
    steps: list[tuple[str, type]] = []
    url_name: str = ""
    url_namespace: str = ""
    success_url: str = ""
    template_name: str = "conjunto/wizard/wizard_base.html"
    partial_template_name: str = "conjunto/wizard/_step_form.html"

    # ------------------------------------------------------------------ helpers

    @classmethod
    def step_names(cls) -> list[str]:
        return [name for name, _form in cls.steps]

    @classmethod
    def get_form_class(cls, step: str) -> type | None:
        for name, form in cls.steps:
            if name == step:
                return form
        return None

    @classmethod
    def first_step(cls) -> str:
        return cls.steps[0][0] if cls.steps else ""

    @classmethod
    def last_step(cls) -> str:
        return cls.steps[-1][0] if cls.steps else ""

    @classmethod
    def next_step(cls, step: str) -> str | None:
        names = cls.step_names()
        try:
            idx = names.index(step)
        except ValueError:
            return None
        return names[idx + 1] if idx + 1 < len(names) else None

    @classmethod
    def prev_step(cls, step: str) -> str | None:
        names = cls.step_names()
        try:
            idx = names.index(step)
        except ValueError:
            return None
        return names[idx - 1] if idx > 0 else None

    # --------------------------------------------------------- draft management

    def get_draft(self) -> WizardDraft:
        """Return (or lazily create) the draft for the current session."""
        session_key = _ensure_session_key(self.request)
        defaults: dict[str, Any] = {}
        if self.request.user.is_authenticated:
            defaults["user"] = self.request.user
        draft, _created = WizardDraft.objects.get_or_create(
            session_key=session_key,
            wizard_key=self.wizard_key,
            defaults=defaults,
        )
        # Keep draft.user in sync with an authenticated request. Drafts
        # started anonymously stay anonymous until login.
        if self.request.user.is_authenticated and draft.user_id != self.request.user.pk:
            draft.user = self.request.user
            draft.save(update_fields=["user"])
        return draft

    def is_step_accessible(self, draft: WizardDraft, step: str) -> bool:
        """Return ``True`` if the user may jump to ``step``.

        Allowed:
        * already visited steps
        * the first step (always accessible)
        * the next step right after the last visited one (linear forward)
        """
        if step == self.first_step():
            return True
        if step in draft.visited_steps:
            return True
        # The next unvisited step after the last visited block is also OK.
        names = self.step_names()
        if not draft.visited_steps:
            return False
        last_visited = max(
            (names.index(s) for s in draft.visited_steps if s in names),
            default=-1,
        )
        try:
            target_idx = names.index(step)
        except ValueError:
            return False
        return target_idx == last_visited + 1

    # ---------------------------------------------------------------- form util

    def build_form(
        self,
        draft: WizardDraft,
        step: str,
        *,
        data=None,
        files=None,
    ):
        form_class = self.get_form_class(step)
        if form_class is None:
            raise Http404("Unknown wizard step")
        kwargs = {"draft": draft, "step": step}
        if self.url_namespace:
            kwargs["wizard_url_namespace"] = self.url_namespace
        if data is not None or files is not None:
            kwargs["data"] = data
            kwargs["files"] = files
        return form_class(**kwargs)

    # ------------------------------------------------------------ commit hook

    def commit(self, draft: WizardDraft) -> Any:
        """Hook for subclasses — turn draft into real domain state.

        Default: no-op. Consumers override this to create their target
        object(s) and copy files from ``draft.files`` into final storage.
        """
        return None

    # --------------------------------------------------------------- URL build

    def step_url(self, step: str) -> str:
        name = self.url_name or "wizard-step"
        if self.url_namespace:
            name = f"{self.url_namespace}:{name}"
        return reverse(name, kwargs={"step": step})


class WizardStepView(WizardViewMixin, TemplateView):
    """Generic wizard step view.

    Subclass, set ``wizard_key``, ``steps``, ``url_name`` (and ideally
    override :meth:`commit`), then wire two URLs — see
    :mod:`conjunto.wizard.urls` for the template.
    """

    template_name = "conjunto/wizard/wizard_base.html"

    # --------------------------------------------------------------------- GET

    def get(self, request, *args, **kwargs):
        draft = self.get_draft()
        step = kwargs.get("step") or draft.current_step or self.first_step()
        if not step:
            raise Http404("Wizard has no steps.")
        if not self.is_step_accessible(draft, step):
            if request.htmx:
                raise PermissionDenied("Step not yet accessible.")
            return redirect(self.step_url(draft.current_step or self.first_step()))
        # Remember the current step so a refresh lands on it.
        if draft.current_step != step:
            draft.current_step = step
            draft.save(update_fields=["current_step", "updated"])

        form = self.build_form(draft, step)
        context = self._step_context(draft, step, form)
        template = self.partial_template_name if request.htmx else self.template_name
        return self.response_class(
            request=request,
            template=[template],
            context=context,
            using=self.template_engine,
        )

    # -------------------------------------------------------------------- POST

    def post(self, request, *args, **kwargs):
        draft = self.get_draft()
        step = kwargs.get("step") or draft.current_step or self.first_step()
        if not self.is_step_accessible(draft, step):
            raise PermissionDenied("Step not yet accessible.")

        action = request.POST.get("_action", "next")
        form = self.build_form(draft, step, data=request.POST, files=request.FILES)

        # "prev" ignores validation — the user wants to go back, not forward.
        if action == "prev":
            prev = self.prev_step(step)
            if prev is None:
                return self._render_step(request, draft, step)
            draft.current_step = prev
            draft.save(update_fields=["current_step", "updated"])
            return self._render_step(request, draft, prev)

        if not form.is_valid():
            context = self._step_context(draft, step, form)
            template = (
                self.partial_template_name if request.htmx else self.template_name
            )
            return self.response_class(
                request=request,
                template=[template],
                context=context,
                using=self.template_engine,
                status=422,
            )

        form.save_to_draft(draft, step)

        if action == "finish" or (action == "next" and step == self.last_step()):
            # Final step — commit and redirect.
            self.commit(draft)
            # Cascade deletes the files; the FS cleanup relies on
            # ProtectedFileField.storage. Consumers that need the files
            # post-commit must copy them off the draft *before* deletion.
            for df in draft.files.all():
                df.delete_from_storage()
            draft.delete()
            if request.htmx:
                if self.success_url:
                    return HttpResponseClientRedirect(self.success_url)
                return HttpResponseEmpty()
            return HttpResponseRedirect(self.success_url or "/")

        # Jump to an explicit step (from the stepper) — validate accessibility.
        if action == "jump":
            target = request.POST.get("target", "")
            if target and self.is_step_accessible(draft, target):
                draft.current_step = target
                draft.save(update_fields=["current_step", "updated"])
                return self._render_step(request, draft, target)

        # Default: next
        nxt = self.next_step(step) or step
        draft.current_step = nxt
        draft.save(update_fields=["current_step", "updated"])
        return self._render_step(request, draft, nxt)

    # -------------------------------------------------------------------- util

    def _render_step(self, request, draft: WizardDraft, step: str) -> HttpResponse:
        form = self.build_form(draft, step)
        context = self._step_context(draft, step, form)
        template = self.partial_template_name if request.htmx else self.template_name
        return self.response_class(
            request=request,
            template=[template],
            context=context,
            using=self.template_engine,
        )

    def _step_context(self, draft: WizardDraft, step: str, form) -> dict:
        """Build context dict for the step template(s)."""
        names = self.step_names()
        step_items = []
        for idx, name in enumerate(names):
            step_items.append(
                {
                    "name": name,
                    "title": name.replace("_", " ").title(),
                    "index": idx + 1,
                    "accessible": self.is_step_accessible(draft, name),
                    "active": name == step,
                    "visited": name in draft.visited_steps,
                    "url": self.step_url(name),
                }
            )
        return {
            "draft": draft,
            "form": form,
            "current_step": step,
            "step_items": step_items,
            "prev_step": self.prev_step(step),
            "next_step": self.next_step(step),
            "is_first": step == self.first_step(),
            "is_final": step == self.last_step(),
            "wizard_key": self.wizard_key,
            "wizard_step_url": self.step_url(step),
        }


class WizardFileDeleteView(View):
    """HTMX ``DELETE`` endpoint for removing a persisted wizard file.

    Zero-Trust gate: the file must belong to a draft bound to the caller's
    session (or, if the draft has a user set, the caller must be that
    user). Anything else is a 404/403 — no information leak about the
    existence of other drafts.
    """

    http_method_names = ["delete", "post"]

    def delete(self, request, pk: int, *args, **kwargs):
        return self._perform(request, pk)

    def post(self, request, pk: int, *args, **kwargs):
        # Fallback for browsers / buttons that cannot issue DELETE.
        return self._perform(request, pk)

    def _perform(self, request, pk: int) -> HttpResponse:
        session_key = _ensure_session_key(request)
        draft_file = get_object_or_404(
            WizardDraftFile.objects.select_related("draft"),
            pk=pk,
        )
        draft = draft_file.draft

        # Session ownership is the primary check.
        if draft.session_key != session_key:
            # When a draft has been merged to an authenticated user, allow
            # that user to reach their files even from a fresh session
            # (e.g. across browser restarts).
            if not (request.user.is_authenticated and draft.user_id == request.user.pk):
                raise PermissionDenied("Not allowed to delete this file.")

        # Extra paranoia: if the draft is bound to a user, deny anonymous
        # callers even if they somehow know the session_key.
        if draft.user_id and not request.user.is_authenticated:
            raise PermissionDenied("Not allowed to delete this file.")

        if (
            draft.user_id
            and request.user.is_authenticated
            and draft.user_id != request.user.pk
        ):
            raise PermissionDenied("Not allowed to delete this file.")

        draft_file.delete_from_storage()
        draft_file.delete()

        # Return an empty, freshly-rendered "no file" fragment that HTMX
        # swaps into the placeholder — re-enables the native file input.
        from django.template.loader import render_to_string

        html = render_to_string(
            "conjunto/forms/_persistent_file.html",
            {
                "widget": {
                    "name": request.GET.get("field", draft_file.field),
                    "has_file": False,
                    "display_name": "",
                    "file_url": "",
                    "file_pk": None,
                    "delete_url": None,
                    "attrs": {},
                }
            },
            request=request,
        )
        return HttpResponse(html)
