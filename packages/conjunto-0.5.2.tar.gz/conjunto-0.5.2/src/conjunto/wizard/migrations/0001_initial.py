"""Initial migration for conjunto.wizard."""

from __future__ import annotations

import django.core.serializers.json
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models

import conjunto.fields
import conjunto.wizard.models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="WizardDraft",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("session_key", models.CharField(db_index=True, max_length=40)),
                ("wizard_key", models.CharField(max_length=100)),
                (
                    "current_step",
                    models.CharField(blank=True, default="", max_length=100),
                ),
                ("visited_steps", models.JSONField(blank=True, default=list)),
                (
                    "data",
                    models.JSONField(
                        blank=True,
                        default=dict,
                        encoder=django.core.serializers.json.DjangoJSONEncoder,
                    ),
                ),
                ("created", models.DateTimeField(auto_now_add=True)),
                ("updated", models.DateTimeField(auto_now=True)),
                (
                    "user",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="wizard_drafts",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={},
        ),
        migrations.AddConstraint(
            model_name="wizarddraft",
            constraint=models.UniqueConstraint(
                fields=("session_key", "wizard_key"),
                name="uniq_session_wizard",
            ),
        ),
        migrations.AddIndex(
            model_name="wizarddraft",
            index=models.Index(
                fields=["user", "wizard_key"],
                name="conjunto_wi_user_id_28938e_idx",
            ),
        ),
        migrations.AddIndex(
            model_name="wizarddraft",
            index=models.Index(
                fields=["updated"],
                name="conjunto_wi_updated_3c5309_idx",
            ),
        ),
        migrations.CreateModel(
            name="WizardDraftFile",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("step", models.CharField(max_length=100)),
                ("field", models.CharField(max_length=100)),
                (
                    "file",
                    conjunto.fields.ProtectedFileField(
                        upload_to=conjunto.wizard.models._draft_file_upload_to
                    ),
                ),
                ("original_name", models.CharField(max_length=255)),
                ("uploaded", models.DateTimeField(auto_now_add=True)),
                (
                    "draft",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="files",
                        to="conjunto_wizard.wizarddraft",
                    ),
                ),
            ],
            options={},
        ),
        migrations.AddConstraint(
            model_name="wizarddraftfile",
            constraint=models.UniqueConstraint(
                fields=("draft", "step", "field"),
                name="uniq_draft_step_field",
            ),
        ),
    ]
