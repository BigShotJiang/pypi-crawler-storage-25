from django.apps import AppConfig


class WizardConfig(AppConfig):
    """AppConfig for the conjunto wizard module.

    Registers the :mod:`conjunto.wizard` app so its models and migrations
    are picked up by Django. No signal wiring here; the optional login-merge
    middleware is opt-in via ``MIDDLEWARE`` in the consumer project.
    """

    default_auto_field = "django.db.models.BigAutoField"
    name = "conjunto.wizard"
    label = "conjunto_wizard"
    verbose_name = "Conjunto Wizard"
