"""Management command: remove stale wizard drafts and their files.

Run daily (via cron / systemd-timer) alongside ``clearsessions``::

    uv run python manage.py conjunto_wizard_cleanup --older-than 7d

``--older-than`` accepts a simple ``<int><unit>`` shortcut (``s``/``m``/
``h``/``d``/``w``) or raw hours. Drafts whose ``updated`` timestamp falls
before the threshold are deleted; ``CASCADE`` removes the attached
:class:`~conjunto.wizard.models.WizardDraftFile` rows, and each file's
physical storage copy is removed first so we do not leak bytes on disk.
"""

from __future__ import annotations

import re
from datetime import timedelta

from django.contrib.sessions.models import Session
from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone

from conjunto.wizard.models import WizardDraft


_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}


def _parse_duration(raw: str) -> timedelta:
    match = re.fullmatch(r"(\d+)\s*([smhdw]?)", raw.strip().lower())
    if not match:
        raise CommandError(f"Invalid duration {raw!r}. Use e.g. '7d', '24h', '30m'.")
    amount = int(match.group(1))
    unit = match.group(2) or "h"
    return timedelta(seconds=amount * _UNITS[unit])


class Command(BaseCommand):
    help = "Delete stale conjunto wizard drafts (and their files)."

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--older-than",
            default="7d",
            help=(
                "Duration threshold (default: 7d). Accepts '<int><unit>' "
                "with unit in s/m/h/d/w."
            ),
        )
        parser.add_argument(
            "--orphan-sessions",
            action="store_true",
            help=(
                "Also delete drafts whose session_key no longer exists in "
                "the Django session store."
            ),
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Only print what would be deleted.",
        )

    def handle(self, *args, **options) -> None:
        threshold = timezone.now() - _parse_duration(options["older_than"])
        qs = WizardDraft.objects.filter(updated__lt=threshold)

        if options["orphan_sessions"]:
            known_keys = set(Session.objects.values_list("session_key", flat=True))
            orphan_qs = WizardDraft.objects.exclude(session_key__in=known_keys)
            qs = (qs | orphan_qs).distinct()

        count = qs.count()
        if options["dry_run"]:
            self.stdout.write(
                f"Would delete {count} wizard draft(s) older than {threshold.isoformat()}."
            )
            return

        # Purge the physical files first — cascade will drop the DB rows,
        # but the storage layer does not know about the cascade.
        for draft in qs:
            for draft_file in draft.files.all():
                draft_file.delete_from_storage()

        qs.delete()
        self.stdout.write(self.style.SUCCESS(f"Deleted {count} stale wizard draft(s)."))
