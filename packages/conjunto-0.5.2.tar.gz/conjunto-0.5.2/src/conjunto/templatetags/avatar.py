"""The ``{% avatar %}`` template tag.

Lives in the core conjunto app (not in :mod:`conjunto.profiles`) so it
is always loadable — ``conjunto`` is by definition installed whenever
its templates are rendered. When :mod:`conjunto.profiles` is also in
``INSTALLED_APPS``, the tag resolves the stored avatar image; otherwise
it degrades cleanly to rendered initials.
"""

from __future__ import annotations

from django import template
from django.apps import apps as django_apps

register = template.Library()


_SIZE_ALIASES = {
    "xs": "avatar-xs",
    "sm": "avatar-sm",
    "md": "",  # Tabler default
    "lg": "avatar-lg",
    "xl": "avatar-xl",
    "2xl": "avatar-2xl",
}


def _resolve_size(size: str | None) -> str:
    if not size:
        return ""
    return _SIZE_ALIASES.get(size, size)


def _resolve_user(context, user):
    """Fall back to ``context.user`` / ``request.user`` when no user given."""
    if user is not None:
        return user
    user = context.get("user")
    if user is not None:
        return user
    request = context.get("request")
    if request is not None:
        return getattr(request, "user", None)
    return None


def _compute_initials(user, max_len: int = 2) -> str:
    """Local copy of :func:`conjunto.profiles.utils.compute_initials`.

    Duplicated here so the tag has no import-time dependency on the
    profiles app — rendering must work with ``conjunto.profiles``
    uninstalled.
    """
    first = (getattr(user, "first_name", "") or "").strip()
    last = (getattr(user, "last_name", "") or "").strip()
    if first and last:
        return (first[:1] + last[:1]).upper()

    full = ""
    if hasattr(user, "get_full_name"):
        try:
            full = (user.get_full_name() or "").strip()
        except Exception:
            full = ""
    if full:
        tokens = full.split()
        if len(tokens) >= 2:
            return (tokens[0][:1] + tokens[-1][:1]).upper()
        return tokens[0][:max_len].upper()

    username = (getattr(user, "username", "") or "").strip()
    if username:
        return username[:max_len].upper()

    email = (getattr(user, "email", "") or "").strip()
    if email:
        return email[:max_len].upper()

    return "?"


def _lookup_avatar_url(user) -> str | None:
    """Return the stored avatar URL if :mod:`conjunto.profiles` is installed."""
    if not django_apps.is_installed("conjunto.profiles"):
        return None
    try:
        UserProfile = django_apps.get_model("conjunto_profiles", "UserProfile")
    except LookupError:
        return None
    profile = UserProfile.objects.filter(user=user).first()
    if profile is None:
        return None
    return profile.avatar_url


@register.inclusion_tag(
    "conjunto/_avatar.html",
    takes_context=True,
    name="avatar",
)
def avatar_tag(context, user=None, size: str | None = None, extra_classes: str = ""):
    """Render a user avatar as an image (if set) or initials fallback.

    Usage::

        {% load avatar %}
        {% avatar %}                            {# context.user / request.user #}
        {% avatar some_user %}
        {% avatar some_user size="xs" extra_classes="me-2" %}

    Size aliases: ``xs``, ``sm``, ``md`` (default), ``lg``, ``xl``,
    ``2xl``. Unknown strings pass through, so arbitrary Tabler classes
    work too.

    When ``conjunto.profiles`` is installed, a stored avatar image is
    used; otherwise the tag always falls back to initials. Never
    raises — anonymous / ``None`` users render as ``?``.
    """
    resolved = _resolve_user(context, user)
    image_url: str | None = None
    initials = "?"

    if resolved is not None and getattr(resolved, "is_authenticated", True):
        initials = _compute_initials(resolved)
        image_url = _lookup_avatar_url(resolved)

    return {
        "image_url": image_url,
        "initials": initials,
        "size_class": _resolve_size(size),
        "extra_classes": extra_classes,
    }
