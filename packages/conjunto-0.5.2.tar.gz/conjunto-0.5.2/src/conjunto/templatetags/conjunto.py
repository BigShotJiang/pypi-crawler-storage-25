import json

from crispy_forms.exceptions import CrispyError
from django import template
from django.conf import settings
from django.contrib.sites.models import Site
from django.core.files import File
from django.forms import boundfield
from django.template.defaultfilters import stringfilter
from django.template.loader import get_template
from django.templatetags.static import static
from django.utils.html import escape
from django.utils.safestring import mark_safe
from django.utils.translation import get_language

register = template.Library()

# ── Script lists ────────────────────────────────────────────────────────
# Core scripts are needed on every page (public + app).
CORE_JS = [
    "conjunto/js/htmx/htmx.min.js",
    # head-support keeps plugin-owned <link rel="stylesheet"> / <script>
    # tags alive when hx-boost swaps only the <body>. Without it, a
    # plugin that adds its own <link> via {% block extra_css %} loses
    # the stylesheet whenever the user navigates onto the plugin's
    # page via a boosted rail link.
    "conjunto/js/htmx/ext/head-support.js",
    "conjunto/js/tabler.js",
    "conjunto/js/toasts.js",
]
CORE_JS_NO_DEFER = [
    "conjunto/js/tabler-theme.min.js",
]
# App scripts are only needed inside the authenticated app layout.
APP_JS = [
    "conjunto/js/alpine.min.js",
    "conjunto/js/litepicker.js",
    "conjunto/js/Sortable.min.js",
    "conjunto/js/conjunto.js",
    "conjunto/js/shortcuts.js",
    "conjunto/js/bulk_select.js",
]
# Feature scripts are loaded on demand via conjunto_require_* tags.
FEATURE_JS = {
    "dropzone": "conjunto/js/dropzone.min.js",
    "chart": "conjunto/js/chart.min.js",
    "fslightbox": "conjunto/js/fslightbox.js",
    "tinymce": "conjunto/tinymce/tinymce.min.js",
}

# Subset of TinyMCE language packs that ship with the self-hosted
# bundle. When ``get_language()`` does not match a key here, the editor
# falls back to English (TinyMCE's built-in default).
TINYMCE_LANGS = {
    "de": "de",
    "de-at": "de",
    "de-ch": "de",
    "fr": "fr_FR",
    "es": "es",
    "it": "it",
    "nl": "nl",
    "pt": "pt_PT",
    "pt-br": "pt_BR",
    "ru": "ru",
    "zh-hans": "zh_CN",
    "ja": "ja",
}


@register.simple_tag(takes_context=True)
def login_methods(context):
    """Return enabled ILoginMethod implementations for rendering on the login page."""
    from conjunto.api.interfaces import ILoginMethod

    request = context.get("request")
    methods = []
    for cls in ILoginMethod:
        if not cls.is_enabled(request):
            continue
        methods.append(
            {
                "name": cls.name,
                "label": cls.label,
                "icon": cls.icon,
                "url": cls.url,
                "rendered": cls.render(request),
            }
        )
    return methods


@register.filter
def toasts_data(messages_iterable) -> list:
    """Convert a ``django.contrib.messages`` iterable into a list of
    toast dicts suitable for ``json_script``.

    Consumes the storage so the default ``{% if messages %}`` block
    does not re-render the same messages elsewhere.
    """
    result = []
    if not messages_iterable:
        return result
    for message in messages_iterable:
        extra_tags = (message.extra_tags or "").split()
        result.append(
            {
                "message": str(message.message),
                "level": message.level_tag,
                "tags": message.tags,
                "dismissible": "dismissible" in extra_tags,
            }
        )
    return result


@register.simple_tag(takes_context=True)
def site_title(context) -> str:
    # Get the current site
    current_site = Site.objects.get_current(context.request)
    return current_site.name if current_site else ""


@register.simple_tag(takes_context=True)
def conjunto_css(context) -> str:
    css = [
        "conjunto/css/tabler.min.css",
        "conjunto/css/tabler-icons.min.css",
        "conjunto/css/conjunto.css",
    ]
    if _accessibility_enabled(context):
        css.append("conjunto/css/a11y.css")

    result = ""
    for css_file in css:
        result += f"<link rel='stylesheet' href='{static(css_file)}'>\n"
    return mark_safe(result)


def _accessibility_enabled(context) -> bool:
    """Read ``accessibility.enabled`` from ``request.scoped_settings``.

    Returns ``False`` if the setting is unavailable (e.g. before the
    scoped-settings middleware has bound it on the request, or in
    rendering paths without a request) — in that case we keep the
    extra stylesheet out, matching the registered default.
    """
    request = context.get("request")
    if request is None:
        return False
    scoped = getattr(request, "scoped_settings", None)
    if scoped is None:
        return False
    try:
        return bool(scoped.get("accessibility", "enabled", default=False))
    except Exception:  # noqa: BLE001 — defensive: never break CSS rendering
        return False


def _script_id(path: str) -> str:
    """Stable, page-unique id for a JS asset path.

    ``hx-preserve`` matches old vs. new DOM by id, so the id must be
    deterministic across renders and unique within the page.
    """
    return "cj-script-" + path.replace("/", "-").replace(".", "-")


def _render_js(paths: list[str], defer: bool = True) -> str:
    """Render a list of JS paths as preserved <script> tags.

    Each tag carries a deterministic id and ``hx-preserve='true'`` so
    that hx-boost body swaps do **not** re-evaluate the script. Without
    this, htmx clones every ``<script src>`` it finds in the swapped
    body and the browser re-executes the IIFE, stacking duplicate
    listeners on document/window. Symptom: toggle buttons appear dead
    because the handler now fires N times and the class flips on/off
    N times. Inline ``<script src>`` tags written directly into layout
    templates (e.g. ``core/base.html``, plugin partials) need the same
    treatment — see ``id="..." hx-preserve="true"`` there.
    """
    result = ""
    defer_attr = " defer" if defer else ""
    for js_file in paths:
        sid = _script_id(js_file)
        result += (
            f"<script type='application/javascript' "
            f"src='{static(js_file)}'{defer_attr} "
            f"id='{sid}' hx-preserve='true'></script>\n"
        )
    return result


@register.simple_tag
def conjunto_core_scripts() -> str:
    """Render only the core scripts needed on every page (htmx, toasts, theme)."""
    return mark_safe(
        _render_js(CORE_JS, defer=True) + _render_js(CORE_JS_NO_DEFER, defer=False)
    )


@register.simple_tag
def conjunto_app_scripts() -> str:
    """Render app-level scripts (Alpine, Tabler, Litepicker, Sortable, conjunto).

    The theme-toggle script is **not** emitted here. It is coupled to the
    UI in ``conjunto/includes/theme_toggle.html`` so that UI and JS are
    gated end-to-end by the same ``{% if cj_layout.theme_switcher %}``
    check in ``app_base.html`` — even when a downstream template
    overrides the ``app_scripts`` block without ``{{ block.super }}``.
    """
    return mark_safe(_render_js(APP_JS, defer=True))


@register.simple_tag(takes_context=True)
def require_script(context, path: str):
    """Register a plugin JS asset for the current request.

    Use from any template (including partials without their own view
    hook, e.g. an ``ITopbarAction`` include) to load JS via the
    conjunto-managed pipeline. The script lands in the rendered
    output with a deterministic id + ``hx-preserve='true'``, so htmx
    skips re-evaluation on hx-boost body swaps. See
    :func:`_render_js` for the rationale.

    Plugin templates must never write ``<script>`` tags directly; see
    the "Plugin assets" section in MedUX' CODING-GUIDELINES.md.
    """
    request = context.get("request")
    if request and hasattr(request, "cj_scripts"):
        request.cj_scripts.add(path)
    return ""


@register.simple_tag(takes_context=True)
def require_css(context, path: str):
    """Register a plugin CSS asset for the current request.

    Counterpart to :func:`require_script` — plugin templates must
    never write ``<link rel="stylesheet">`` tags directly; route
    every stylesheet through ``cj_scripts`` so the page loads each
    asset once and in a predictable order.
    """
    request = context.get("request")
    if request and hasattr(request, "cj_scripts"):
        request.cj_scripts.add_css(path)
    return ""


@register.simple_tag(takes_context=True)
def conjunto_require_dropzone(context):
    """Register dropzone.js for loading. Also adds dropzone CSS."""
    request = context.get("request")
    if request and hasattr(request, "cj_scripts"):
        request.cj_scripts.add(FEATURE_JS["dropzone"])
        request.cj_scripts.add_css("conjunto/css/dropzone.min.css")
    return ""


@register.simple_tag(takes_context=True)
def conjunto_require_chart(context):
    """Register chart.js for loading."""
    request = context.get("request")
    if request and hasattr(request, "cj_scripts"):
        request.cj_scripts.add(FEATURE_JS["chart"])
    return ""


@register.simple_tag(takes_context=True)
def conjunto_require_fslightbox(context):
    """Register fslightbox.js for loading."""
    request = context.get("request")
    if request and hasattr(request, "cj_scripts"):
        request.cj_scripts.add(FEATURE_JS["fslightbox"])
    return ""


# TinyMCE default toolbar — deliberately lean. Block-level markup only
# (bold/italic/lists/links/h2/h3/code). No inline ``style`` attrs, no
# raw <script> capability. All output is untrusted HTML and MUST be run
# through a server-side sanitizer (e.g. ``bleach``) before persistence.
_TINYMCE_DEFAULT_TOOLBAR = "bold italic | bullist numlist | link | h2 h3 | code"
_TINYMCE_DEFAULT_PLUGINS = "lists link code"


@register.simple_tag(takes_context=True)
def conjunto_require_tinymce(context, selector: str = "textarea.tinymce"):
    """Register TinyMCE (Community Edition, GPLv2) for loading.

    Self-hosted assets only — downloaded by the consumer project via
    ``python manage.py update_libraries tinymce`` into
    ``CONJUNTO_VENDOR_DIR``. No CDN runtime references (Zero-Trust
    data pillar + GDPR Art. 44 ff.).

    Emits one ``<script>`` tag registering ``tinymce.min.js`` and a
    second inline init snippet bound to ``selector`` (default:
    ``textarea.tinymce``). Idempotent per request — repeated calls in
    included templates produce only one script tag and one init block.

    **Security warning.** TinyMCE produces raw HTML. Any value that
    leaves the editor MUST be sanitised on the server (e.g. with
    ``bleach``) before it is stored or displayed. Conjunto does not
    currently ship a ``SafeHTMLField`` — consumer apps are responsible
    for sanitising TinyMCE output themselves.

    Args:
        selector: CSS selector for the target textarea(s). Defaults to
            ``textarea.tinymce``. Pass a project-specific selector when
            multiple editors with different configs coexist.
    """
    request = context.get("request")
    if not (request and hasattr(request, "cj_scripts")):
        return ""

    # Register the editor asset — ScriptRegistry deduplicates by path.
    request.cj_scripts.add(FEATURE_JS["tinymce"])

    # Emit the init snippet at most once per request, regardless of how
    # many times the tag is rendered.
    flag = "_cj_tinymce_initialised"
    if getattr(request, flag, False):
        return ""
    setattr(request, flag, True)

    # Dark-mode skin follows conjunto.color_scheme (VENDOR→USER chain).
    color_scheme = "light"
    scoped = getattr(request, "scoped_settings", None)
    if scoped is not None:
        color_scheme = scoped.get("conjunto", "color_scheme", default="light")
    skin = "oxide-dark" if color_scheme == "dark" else "oxide"
    content_css = "dark" if color_scheme == "dark" else "default"

    # Language pack — fall back to English when unmapped.
    django_lang = (get_language() or "en").lower()
    tinymce_lang = TINYMCE_LANGS.get(django_lang)

    base_url = static("conjunto/tinymce/").rstrip("/")

    config = {
        # TinyMCE v7 Community Edition requires ``license_key: 'gpl'``.
        "license_key": "gpl",
        "selector": selector,
        "base_url": base_url,
        "skin": skin,
        "skin_url": f"{base_url}/skins/ui/{skin}",
        "content_css": content_css,
        "content_css_url": (f"{base_url}/skins/content/{content_css}/content.min.css"),
        "plugins": _TINYMCE_DEFAULT_PLUGINS,
        "toolbar": _TINYMCE_DEFAULT_TOOLBAR,
        "menubar": False,
        "branding": False,
        "promotion": False,
        # Self-hosted — suppress any CDN fallback.
        "referrer_policy": "origin",
    }
    if tinymce_lang:
        config["language"] = tinymce_lang
        config["language_url"] = f"{base_url}/langs/{tinymce_lang}.js"

    init_json = json.dumps(config)
    # CSP nonce support. ``django-csp`` (and compatible middlewares)
    # attach a per-request ``csp_nonce`` attribute to the request. When
    # present, we mirror it onto the inline ``<script>`` so the init
    # snippet survives a strict ``script-src`` policy without
    # ``'unsafe-inline'``. When absent, we emit the plain inline script
    # — no behavioural change for projects that have not opted in to
    # CSP yet.
    nonce = getattr(request, "csp_nonce", None)
    nonce_attr = f' nonce="{nonce}"' if nonce else ""
    snippet = (
        f"<script type='application/javascript' defer{nonce_attr}>"
        "document.addEventListener('DOMContentLoaded', function () {"
        f"  if (window.tinymce) {{ window.tinymce.init({init_json}); }}"
        "});"
        "</script>"
    )
    return mark_safe(snippet)


@register.simple_tag(takes_context=True)
def conjunto_render_scripts(context):
    """Render all registered feature scripts and CSS. Call once in the base template."""
    request = context.get("request")
    if request and hasattr(request, "cj_scripts"):
        return request.cj_scripts.render()
    return ""


@register.simple_tag(takes_context=True)
def render_element(context, element, **kwargs):
    """
    Renders a plugin element.

    Examples:
        ```django
        {% render_element my_element %}
        ```
        You can override (existing) attributes from within the template:
        ```django
        {% render_element my_element title="Settings" %}
        ```
    """
    return mark_safe(
        element.__class__.as_view(**kwargs)(context.request).render().content.decode()
    )


@register.filter
def is_image(file) -> bool:
    """Returns True if the file is an image, False otherwise.

    This ATM works just by determining the file extension.
    # TODO: maybe use PIL for this purpose - CAVE speed.
    """
    return isinstance(file, File) and file.name.split(".")[-1] in [
        "png",
        "jpg",
        "jpeg",
        "gif",
    ]


@register.filter(name="display_only")
def as_crispy_display(field, label_class="", field_class=""):
    """
    Renders a form field like a django-crispy-forms field, but read-only, without the input field.

        {% load crispy_forms_tags %}
        {{ form.field|as_crispy_display }}
    """
    if not isinstance(field, boundfield.BoundField) and settings.DEBUG:
        raise CrispyError(
            f"|as_crispy_display got passed an invalid or inexistent field: {field}"
        )

    attributes = {
        "field": field,
        "form_show_errors": True,
        "form_show_labels": True,
        "label_class": label_class,
        "field_class": field_class,
    }

    attributes["field"].field.disabled = True
    return get_template("conjunto/widgets/field_display.html").render(attributes)


@register.filter
@stringfilter
def trim(value):
    return value.strip()


@register.simple_tag
def kbd_clickable(label, *, role="button", tabindex="0", classes="", extra_attrs=""):
    """Open tag for an a11y-compliant clickable non-button element.

    Use this when you genuinely cannot use a ``<button>`` or ``<a>`` (rare —
    e.g. an entire row that should also be clickable). Renders the
    accessibility attributes and a JavaScript bridge that turns Enter/Space
    into a click event.

    Usage in a template::

        <span {% kbd_clickable "Open patient" %} hx-get="..." hx-target="...">
          ...
        </span>

    The output is a string of HTML attributes — the caller still writes the
    element tag itself.
    """
    safe_label = str(label).replace('"', "&quot;")
    class_attr = ("cj-kbd-clickable " + str(classes)).strip()
    onkeydown = (
        "if(event.key==='Enter'||event.key===' ')"
        "{event.preventDefault();this.click();}"
    )
    return mark_safe(
        f'role="{role}" tabindex="{tabindex}" aria-label="{safe_label}" '
        f'class="{class_attr}" {extra_attrs} '
        f'onkeydown="{onkeydown}"'
    )


# ── Help hint ───────────────────────────────────────────────────────────
# Block tag {% help_hint [icon="info-circle"] %} … {% endhelp_hint %}
# Renders a small blue icon whose Bootstrap tooltip carries the body
# text. Visibility is gated by the ``conjunto.show_help_hints``
# scoped setting so power users can switch the hints off globally.


class _HelpHintNode(template.Node):
    def __init__(self, nodelist, icon_var):
        self.nodelist = nodelist
        self.icon_var = icon_var

    def render(self, context):
        request = context.get("request")
        if not _help_hints_enabled(request):
            return ""
        text = self.nodelist.render(context).strip()
        if not text:
            return ""
        if self.icon_var is not None:
            icon = self.icon_var.resolve(context)
        else:
            icon = "info-circle"
        return mark_safe(
            f'<i class="ti ti-{escape(icon)} text-blue cj-help-hint" '
            f'role="img" '
            f'tabindex="0" '
            f'data-bs-toggle="tooltip" '
            f'data-bs-placement="top" '
            f'title="{escape(text)}" '
            f'aria-label="{escape(text)}"></i>'
        )


def _help_hints_enabled(request) -> bool:
    if request is None:
        return True
    scoped = getattr(request, "scoped_settings", None)
    if scoped is None:
        return True
    try:
        return bool(scoped.get("conjunto", "show_help_hints", default=True))
    except Exception:  # noqa: BLE001 — defensive: never break rendering
        return True


@register.tag(name="help_hint")
def do_help_hint(parser, token):
    """``{% help_hint [icon="info-circle"] %} … {% endhelp_hint %}``.

    Renders a small blue tooltip icon next to a section title. The
    body of the block is the help text. Optional ``icon=`` argument
    swaps the default ``info-circle`` for any Tabler icon name (no
    ``ti ti-`` prefix). Hidden globally via the
    ``conjunto.show_help_hints`` scoped setting.
    """
    bits = token.split_contents()
    icon_var = None
    for bit in bits[1:]:
        if "=" in bit:
            key, value = bit.split("=", 1)
            if key == "icon":
                icon_var = parser.compile_filter(value)
    nodelist = parser.parse(("endhelp_hint",))
    parser.delete_first_token()
    return _HelpHintNode(nodelist, icon_var)
