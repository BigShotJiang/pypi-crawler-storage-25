"""Template tags/filters for the `TableListView` pattern.

Provides:
- ``header_action_attrs``: resolve a ``HeaderAction``'s HTML attribute
  dict (URL, hx-* flags, CSS class) for rendering in the card header.
- ``dict_item``: safely look up a value in a dict with empty-string
  fallback — used to pass per-filter selected values into the filter
  widget template without relying on a missing builtin.
"""

from __future__ import annotations

from django import template

from conjunto.tables import BulkAction, HeaderAction

register = template.Library()


@register.simple_tag(takes_context=True)
def header_action_attrs(context, action: HeaderAction) -> dict[str, str]:
    """Return the dict of HTML attributes for a header action."""
    return action.render_attrs(context["request"])


@register.simple_tag(takes_context=True)
def bulk_action_attrs(context, action: BulkAction) -> dict[str, str]:
    """Return the dict of HTML attributes for a bulk action."""
    return action.render_attrs(context["request"])


@register.filter
def dict_item(d, key):
    """Return ``d[key]`` with graceful fallback to empty string."""
    if not d:
        return ""
    return d.get(key, "")
