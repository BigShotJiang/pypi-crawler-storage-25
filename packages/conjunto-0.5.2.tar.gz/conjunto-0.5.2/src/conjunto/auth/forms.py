"""Authentication form for :class:`conjunto.auth.views.ConjuntoLoginView`.

The form is built so the login card template
(:file:`registration/_login_card.html`) stays generic across consumer
projects:

- The crispy ``FormHelper`` carries only the **field layout** — the
  surrounding ``<form>`` element, the CSRF token, and the sign-in button
  are owned by the template (``helper.form_tag = False``,
  ``helper.disable_csrf = True``).
- A ``remember_me`` checkbox is added conditionally based on the
  ``auth.show_remember_me`` scoped setting so a vendor or tenant admin
  can hide it without subclassing.

Cross-cutting login concerns (e.g. a time-tracking "kommen / gehen"
toggle) belong outside the credentials form. Use a post-login modal
fired via :class:`~conjunto.api.interfaces.IPostLoginAction`, or a
permanent in-app action — the credentials form should do nothing but
authenticate.
"""

from __future__ import annotations

from crispy_bootstrap5.bootstrap5 import FloatingField
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Field, Layout
from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm as DjangoAuthenticationForm
from django.utils.translation import gettext_lazy as _

User = get_user_model()


def _show_remember_me(request) -> bool:
    """Return whether the remember-me checkbox should be rendered.

    Reads the ``auth.show_remember_me`` scoped setting. Defaults to
    ``True`` when the proxy is unavailable (e.g. middleware not
    installed in a unit test) so the form keeps Django's classic
    behaviour out of the box.
    """
    scoped = getattr(request, "scoped_settings", None)
    if scoped is None:
        return True
    try:
        return bool(scoped.get("auth", "show_remember_me", default=True))
    except Exception:
        return True


class ConjuntoAuthenticationForm(DjangoAuthenticationForm):
    """Login form on top of Django's :class:`AuthenticationForm`.

    Adds a ``remember_me`` boolean field when ``auth.show_remember_me``
    is enabled. The view consumes its value to pick between
    ``auth.session_lifetime_default`` and
    ``auth.session_lifetime_remembered``.
    """

    def __init__(self, request=None, *args, **kwargs):
        super().__init__(request, *args, **kwargs)

        self.fields["username"].help_text = ""
        self.fields["username"].widget.attrs.update({"autofocus": True})
        self.fields["password"].help_text = ""

        layout_entries = [
            FloatingField("username"),
            FloatingField("password"),
        ]

        self._show_remember_me = _show_remember_me(request)
        if self._show_remember_me:
            self.fields["remember_me"] = forms.BooleanField(
                label=_("Remember me on this device"),
                required=False,
                initial=False,
            )
            layout_entries.append(Field("remember_me"))

        self.helper = FormHelper()
        self.helper.form_tag = False
        self.helper.disable_csrf = True
        self.helper.layout = Layout(*layout_entries)

    def get_remember_me(self) -> bool:
        """Return the (gated) remember-me flag from cleaned data.

        Returns ``False`` whenever the checkbox is hidden by the scoped
        setting, regardless of what the POST body contains. Callers can
        rely on this instead of reading ``request.POST`` directly.
        """
        if not self._show_remember_me:
            return False
        return bool(self.cleaned_data.get("remember_me", False))
