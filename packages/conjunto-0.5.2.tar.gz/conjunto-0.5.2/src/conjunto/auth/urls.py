"""URL configuration for the conjunto login flow.

Wire this from a consumer project's root URL conf::

    from django.urls import include, path

    urlpatterns = [
        # Conjunto login + optional two-step tenant pick.
        path("accounts/", include("conjunto.auth.urls")),
        # Logout, password change/reset, etc. still come from contrib.auth.
        path("accounts/", include("django.contrib.auth.urls")),
        ...
    ]

The two views live under the URL names ``login`` and
``login-complete`` (no namespace), to match Django's auth URL
conventions and so existing ``{% url 'login' %}`` references keep
working.
"""

from django.urls import path

from .views import ConjuntoLoginCompleteView, ConjuntoLoginView

urlpatterns = [
    path("login/", ConjuntoLoginView.as_view(), name="login"),
    path(
        "login-complete/",
        ConjuntoLoginCompleteView.as_view(),
        name="login-complete",
    ),
]
