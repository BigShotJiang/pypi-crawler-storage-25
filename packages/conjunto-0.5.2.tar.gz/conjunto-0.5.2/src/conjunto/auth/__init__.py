"""Login views with optional two-step tenant pick.

The default Django ``LoginView`` flow is fine for users who only have
access to one tenant. When a user can pick from two or more tenants
this package's :class:`~conjunto.auth.views.ConjuntoLoginView` defers
final authentication: the credentials are validated, the user identity
is stashed into the session as "pending login", and an HTMX swap
replaces the credentials card with a tenant picker. Selecting a tenant
POSTs back to :class:`~conjunto.auth.views.ConjuntoLoginCompleteView`
which finalises authentication, binds the chosen tenant to the
session, and redirects.

Wire the URL module from a consumer project::

    # myproject/urls.py
    from django.urls import include, path

    urlpatterns = [
        path("accounts/", include("conjunto.auth.urls")),
        path("accounts/", include("django.contrib.auth.urls")),  # logout, password reset
        ...
    ]
"""
