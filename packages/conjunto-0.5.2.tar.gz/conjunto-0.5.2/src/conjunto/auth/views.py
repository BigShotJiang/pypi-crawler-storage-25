"""Login views with optional two-step tenant pick.

See :mod:`conjunto.auth` for the high-level overview.

Implementation notes:

- The credentials form is :class:`ConjuntoAuthenticationForm`, which
  extends Django's stock ``AuthenticationForm`` with a conditional
  Remember-Me checkbox and the
  :class:`~conjunto.api.interfaces.ILoginViewExtension` plugin hook.
  ``ConjuntoLoginView`` overrides ``form_valid`` / ``form_invalid`` to
  add HTMX awareness, the deferred-login branch, and the
  :class:`~conjunto.api.interfaces.ILoginViewExtension` hook.
- "Pending login" state lives in the (anonymous) session under
  :data:`PENDING_LOGIN_KEY`. It carries the user pk, the auth backend
  used, the ``next`` URL, the remember-me flag, and a creation
  timestamp. State older than :data:`PENDING_LOGIN_TTL` seconds is
  refused — the user has to start over.
- :func:`django.contrib.auth.login` is called only after a tenant has
  been picked. Users with zero or one tenants are logged in
  immediately, mirroring the classic flow.
- For users with exactly one accessible tenant the chosen tenant is
  also stamped into the session under
  :data:`conjunto.tenants.views.SESSION_KEY` so the middleware binds
  it on the next request without an extra picker round-trip.
"""

from __future__ import annotations

import time

from django.contrib.auth import get_user_model, login
from django.contrib.auth.views import LoginView
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.views import View

from conjunto.api.interfaces import ILoginViewExtension
from conjunto.auth.forms import ConjuntoAuthenticationForm
from conjunto.tenants.utils import get_tenant_model
from conjunto.tenants.views import SESSION_KEY as TENANT_SESSION_KEY

User = get_user_model()


def _run_view_extensions(view, request, user, form) -> None:
    """Invoke ``ILoginViewExtension.form_valid`` on every implementation.

    Called *after* :func:`django.contrib.auth.login` has bound the user
    to the session, so ``request.user`` is authenticated and any
    side-effects (e.g. timetracker check-ins) can rely on it.
    Exceptions raised by individual extensions propagate — extensions
    must catch their own non-fatal errors.
    """
    for extension in ILoginViewExtension.enabled_plugins():
        extension.form_valid(view, request, user, form)


#: Session key carrying the deferred-login state between credentials
#: validation and tenant selection.
PENDING_LOGIN_KEY = "cj_pending_login"

#: Maximum age of a pending-login record, in seconds. State older than
#: this is refused — the user has to start the login over.
PENDING_LOGIN_TTL = 600


def _allowed_tenants_for_user(user):
    """Return the active tenants ``user`` is allowed to pick from.

    Mirrors :func:`conjunto.tenants.utils.get_allowed_tenants` but takes
    a user instance directly because the request's user is still
    anonymous when this is called.
    """
    Tenant = get_tenant_model()
    qs = Tenant.objects.filter(is_active=True).order_by("name")
    if not user.is_superuser:
        qs = qs.filter(memberships__user=user).distinct()
    return qs


def _set_session_lifetime(request, remember_me: bool) -> None:
    """Apply the remembered/default session lifetime, if registered.

    Reads ``auth.session_lifetime_remembered`` /
    ``auth.session_lifetime_default`` from the scoped settings.
    Silently no-ops if the proxy is unavailable (e.g. middleware not
    installed in tests).
    """
    scoped = getattr(request, "scoped_settings", None)
    if scoped is None:
        return
    key = "session_lifetime_remembered" if remember_me else "session_lifetime_default"
    try:
        value = scoped.get("auth", key, default=None)
    except Exception:
        value = None
    if value is None:
        return
    try:
        request.session.set_expiry(int(value))
    except (TypeError, ValueError):
        pass


class ConjuntoLoginView(LoginView):
    """Login view with optional two-step tenant pick.

    Behaviour by tenant count:

    - **0 tenants** — log in immediately, redirect (or HX-Redirect on
      HTMX) to ``next``. The user lands tenant-less.
    - **1 tenant** — log in immediately, stamp the tenant id into the
      session, and redirect.
    - **2+ tenants** — do *not* call ``login()``. Stash the pending
      login state into the session and return the tenant-pick partial.
      The user finishes the login by POSTing the chosen tenant to
      :class:`ConjuntoLoginCompleteView`.

    On ``form_invalid`` the credentials partial is re-rendered with a
    ``422`` status when the request is HTMX, so HTMX still swaps the
    error back into the card.
    """

    template_name = "registration/login.html"
    credentials_partial_template = "registration/_login_card.html"
    tenant_pick_template = "registration/_login_tenant_pick.html"
    authentication_form = ConjuntoAuthenticationForm

    def form_valid(self, form):
        user = form.get_user()
        tenants = list(_allowed_tenants_for_user(user))
        next_url = self.get_success_url()
        if hasattr(form, "get_remember_me"):
            remember_me = form.get_remember_me()
        else:
            remember_me = bool(self.request.POST.get("remember_me"))

        if len(tenants) >= 2:
            self.request.session[PENDING_LOGIN_KEY] = {
                "user_id": user.pk,
                "backend": getattr(user, "backend", None),
                "remember_me": remember_me,
                "next": next_url,
                "ts": int(time.time()),
            }
            ctx = {"tenants": tenants, "next": next_url}
            if getattr(self.request, "htmx", False):
                return render(self.request, self.tenant_pick_template, ctx)
            # Non-HTMX fallback: render the full login page with the
            # picker swapped in for the credentials card.
            ctx["card_template"] = self.tenant_pick_template
            return render(self.request, self.template_name, ctx)

        # 0 or 1 tenant: classic login.
        login(self.request, user)
        if len(tenants) == 1:
            self.request.session[TENANT_SESSION_KEY] = tenants[0].pk
        _set_session_lifetime(self.request, remember_me)
        _run_view_extensions(self, self.request, user, form)
        if getattr(self.request, "htmx", False):
            response = HttpResponse(status=204)
            response["HX-Redirect"] = next_url
            return response
        return HttpResponseRedirect(next_url)

    def form_invalid(self, form):
        if getattr(self.request, "htmx", False):
            # The credentials partial only needs the form. We deliberately
            # bypass ``super().get_context_data()`` — Django's ``LoginView``
            # pulls the current ``Site`` for ``site``/``site_name``, which
            # the partial does not render and which would force every
            # consuming project to seed a Site row just for re-renders of
            # the form errors.
            return render(
                self.request,
                self.credentials_partial_template,
                {
                    "form": form,
                    "card_template": self.credentials_partial_template,
                },
                status=422,
            )
        return super().form_invalid(form)

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        # The main template renders ``card_template`` inside the
        # swap target. Default is the credentials card.
        ctx.setdefault("card_template", self.credentials_partial_template)
        for extension in ILoginViewExtension.enabled_plugins():
            extension.alter_context_data(self, ctx)
        return ctx


class ConjuntoLoginCompleteView(View):
    """Finalize a deferred login by accepting a tenant selection.

    Reads the pending-login record from the session, validates the
    chosen tenant against the user's accessible set, calls
    :func:`django.contrib.auth.login`, stamps the tenant id, applies
    the session lifetime, and redirects (HX-Redirect for HTMX).

    Failure modes (expired/invalid state, unknown or disallowed
    tenant) bounce the user back to the login page.
    """

    http_method_names = ["post"]
    login_url_name = "login"

    def post(self, request):
        pending = request.session.get(PENDING_LOGIN_KEY)
        if not pending or (time.time() - pending.get("ts", 0)) > PENDING_LOGIN_TTL:
            request.session.pop(PENDING_LOGIN_KEY, None)
            return self._bounce_to_login(request)

        user = User.objects.filter(pk=pending["user_id"], is_active=True).first()
        if user is None:
            request.session.pop(PENDING_LOGIN_KEY, None)
            return self._bounce_to_login(request)

        tenants = list(_allowed_tenants_for_user(user))
        try:
            tenant_pk = int(request.POST.get("tenant", ""))
        except (TypeError, ValueError):
            return self._bounce_to_login(request)
        tenant = next((t for t in tenants if t.pk == tenant_pk), None)
        if tenant is None:
            return self._bounce_to_login(request)

        backend = pending.get("backend")
        if backend:
            user.backend = backend
        login(request, user)
        request.session[TENANT_SESSION_KEY] = tenant.pk
        _set_session_lifetime(request, bool(pending.get("remember_me")))
        next_url = pending.get("next") or "/"
        request.session.pop(PENDING_LOGIN_KEY, None)
        # ILoginViewExtension hooks fire after the *effective* login —
        # i.e. once the user has finished the second step. We pass
        # ``form=None`` because the original credentials form is no
        # longer available; extensions that need data from the
        # credentials POST must stash it themselves during step 1.
        _run_view_extensions(self, request, user, None)

        if getattr(request, "htmx", False):
            response = HttpResponse(status=204)
            response["HX-Redirect"] = next_url
            return response
        return HttpResponseRedirect(next_url)

    def _bounce_to_login(self, request):
        try:
            url = reverse(self.login_url_name)
        except Exception:
            url = "/"
        if getattr(request, "htmx", False):
            response = HttpResponse(status=204)
            response["HX-Redirect"] = url
            return response
        return HttpResponseRedirect(url)
