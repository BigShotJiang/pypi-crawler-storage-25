from __future__ import annotations

import enum
import logging
from functools import reduce
from operator import or_
from typing import Any, ClassVar, Iterable, Optional

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout
from django.apps import apps
from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core import signing
from django.core.cache import cache
from django.core.exceptions import ImproperlyConfigured
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db import models
from django.db.models import Q, QuerySet
from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.encoding import force_str
from django.utils.html import escape
from django.utils.http import urlsafe_base64_decode
from django.views import View
from django.views.generic import ListView, TemplateView
from django.views.static import serve
from django_tables2 import SingleTableMixin

from conjunto.filters import Filter

User = get_user_model()


class DialogType(enum.Enum):
    """Enumeration of possible dialog levels.

    Levels are used from Python's logging module
    """

    CRITICAL = logging.CRITICAL
    ERROR = logging.ERROR
    WARNING = logging.WARNING
    INFO = logging.INFO
    DEBUG = logging.DEBUG
    NOTSET = logging.NOTSET

    CREATE = NOTSET
    UPDATE = NOTSET
    DELETE = WARNING


class CrispyFormHelperMixin:
    """
    A mixin that helps with Crispy Forms.

    It creates a form helper instance attribute (if it doesn't exist yet) and sets
    form_tag to false. It also provides a form_layout attribute, which is a list of
    Crispy fields which will then be used as layout in the form.
    """

    form_layout: list = []
    """The crispy forms layout for the form"""

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        # make sure that Crispy Forms doesn't create its own form tag
        # as this would destroy the modal window.
        # create a default form helper in case of none is created and remove form tag
        if not hasattr(form, "helper"):
            form.helper = FormHelper()
            form.helper.form_tag = False
            if self.form_layout:
                form.helper.layout = Layout(*self.form_layout)
        return form


def clean_dict(input_dict: dict) -> dict:
    """Clean the input dictionary by removing any key-value pairs where the value is "undefined".

    :param input_dict: The input dictionary to be cleaned.
    :return: A dictionary with the same keys as the input dictionary, but with the "undefined" values removed.
    """
    return {key: value for key, value in input_dict.items() if value != "undefined"}


class PrepopulateFormViewMixin:
    """
    A mixin class that prepopulates form fields with values from the request.GET
    parameters.

    This mixin can be used with any FormView class to automatically prepopulate
    form fields with values from the URL query string parameters.

    Example usage:

    class MyFormView(PrepopulateFormMixin, FormView):
        form_class = MyForm
        template_name = 'my_template.html'
        success_url = reverse_lazy('my_success_url')

    In the above example, the form fields will be prepopulated with values from the URL
    query string parameters when the form view is loaded.
    """

    def get_initial(self):
        """Returns the initial data for the form."""
        initial = super().get_initial()
        initial.update(clean_dict(self.request.GET.dict()))
        return initial


class PersistentFileUploadMixin:
    """View mixin that caches ``PersistentFileField`` uploads across re-renders.

    When a traditional POST fails validation the browser reloads the page
    and every ``<input type="file">`` is empty.  This mixin stores the
    uploaded files in Django's cache and restores them on subsequent POSTs
    until the form finally submits successfully, so the user does not have
    to re-select files after fixing other validation errors.

    Usage::

        class MyView(PersistentFileUploadMixin, View):
            def post(self, request, *args, **kwargs):
                files = self.get_form_files(request)
                form = MyForm(data=request.POST, files=files)
                if not form.is_valid():
                    self.persist_form_files(request, form)
                    return render(request, "form.html", {"form": form})
                self.clear_persisted_files(request)
                ...
    """

    _pfu_session_key = "_pfu_keys"
    _pfu_cache_timeout = 3600  # seconds

    def _pfu_cache_key(self, request, field_name):
        if not request.session.session_key:
            request.session.create()
        return f"pfu:{request.session.session_key}:{field_name}"

    def _pfu_load(self, cache_key):
        data = cache.get(cache_key)
        if data is None:
            return None
        return SimpleUploadedFile(
            name=data["name"],
            content=data["content"],
            content_type=data["content_type"],
        )

    def get_form_files(self, request):
        """Return ``request.FILES`` merged with previously cached files.

        Call this before instantiating the form so restored files look
        like fresh uploads to the form and its fields.
        """
        files = request.FILES.copy()
        keys = request.session.get(self._pfu_session_key, {})
        for field_name, cache_key in keys.items():
            if field_name in files:
                continue
            restored = self._pfu_load(cache_key)
            if restored is not None:
                files[field_name] = restored
        return files

    def persist_form_files(self, request, form):
        """Cache uploads and expose them through ``form.initial``.

        Call this after ``form.is_valid()`` returned ``False``.  For every
        :class:`~conjunto.forms.PersistentFileField` with an uploaded file
        (either fresh from ``request.FILES`` or previously cached), the
        file is written to the cache and the widget is given a reference
        so it can render "already uploaded: <name>" on the next render.
        """
        from conjunto.forms.fields import PersistentFileField

        keys = request.session.get(self._pfu_session_key, {})
        for name, field in form.fields.items():
            if not isinstance(field, PersistentFileField):
                continue
            uploaded = request.FILES.get(name)
            if uploaded is not None:
                cache_key = self._pfu_cache_key(request, name)
                uploaded.seek(0)
                cache.set(
                    cache_key,
                    {
                        "name": uploaded.name,
                        "content": uploaded.read(),
                        "content_type": uploaded.content_type,
                    },
                    timeout=self._pfu_cache_timeout,
                )
                uploaded.seek(0)
                keys[name] = cache_key
                form.initial[name] = uploaded
            elif name in keys:
                restored = self._pfu_load(keys[name])
                if restored is None:
                    continue
                form.initial[name] = restored
            else:
                continue
            # BoundField.initial is a cached_property — after is_valid() it
            # already holds the stale value (None).  Evict the cache so the
            # widget picks up the reference we just wrote to form.initial.
            form._bound_fields_cache.pop(name, None)
        request.session[self._pfu_session_key] = keys

    def clear_persisted_files(self, request):
        """Remove cached files after a successful submission."""
        for cache_key in request.session.pop(self._pfu_session_key, {}).values():
            cache.delete(cache_key)


class LatestVersionMixin:
    """
    A mixin for views that require fetching the latest version of an object.

    You can override the template in `<your_app_name>/versioned_page.html`.

    Attributes:
        no_object_available (str): The message to display when no object is available.
        create_url (str): The URL to link to where a new object can be created.
        edit_url (str): The URL to link to where an existing object can be edited.
    """

    no_object_available: str = ""
    create_url: str = ""
    edit_url: str = ""

    def __init__(self):
        super().__init__()
        if not self.model:
            raise AttributeError(
                f"{self.__class__.__name__} must provide a 'model' attribute."
            )
        self.no_object_available = self.no_object_available or (
            f"No {self.model._meta.verbose_name} available."
        )

        if not self.create_url:
            raise AttributeError(
                f"{self.__class__.__name__} must provide a 'create_url' attribute "
                f" to link to a new {self.model._meta.verbose_name} object."
            )

    def get_object(self):
        return super().get_queryset().order_by("-version").last()

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context.update(
            {
                "no_object_available": self.no_object_available,
                "create_url": self.create_url,
            }
        )
        return context

    def get_template_names(self):
        """If no template_name is defined, return "versioned_page.html" for the app
        the current view is coming from.

        e.g. if the current view is in the app "my_app" and the template name is not
        defined, it returns "my_app/versioned_page.html".
        """
        return (
            self.template_name
            if self.template_name
            else [f"{ self.request.resolver_match.app_name}/versioned_page.html"]
        )


class MaintenanceView(TemplateView):
    template_name = "maintenance.html"


class AutoPermissionsViewMixin(PermissionRequiredMixin):
    """
    Automatically uses view/create/change/delete permissions for the given model.
    To be used with a CRUD view.

    It automatically generates the "<verb>_<model>" permission
    of the given model as necessary permission for this view.

    Attributes:
        _permissions_verb: the verb to create the permissions:
            'view', 'create', 'change', 'delete'. Defaults to "view".
    """

    _permissions_verb = "view"  # create, change, delete

    def get_permission_required(self):
        if self.permission_required is None:
            model = self.model
            if not model:
                raise AttributeError(
                    f"Model {self.__class__.__name__} needs a model attribute to "
                    f"auto-calculate permissions from."
                )
            return (
                f"{model._meta.app_label}.{self._permissions_verb}_{model._meta.model_name}",
            )
        if isinstance(self.permission_required, str):
            perms = (self.permission_required,)
        else:
            perms = self.permission_required
        return perms


class AnonymousRequiredMixin(PermissionRequiredMixin):
    """View mixin that only allows access for anonymous users."""

    def has_permission(self):
        # TODO: instead of a 403, redirect to LOGIN_REDIRECT_URL

        if not self.request.user.is_anonymous:
            redirect(reverse(settings.LOGIN_REDIRECT_URL))
        return True


class ProtectedMediaBaseView(View):
    """Base view that served protected media files.

    Don't use this class directly. Use `PermissionRequiredMediaView` or
    `LoginRequiredMediaView` instead.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if self.__class__.__name__ == "ProtectedMediaBaseView":
            raise NotImplementedError(
                "ProtectedMediaBaseView may not be used directly. "
                "Use PermissionRequiredMediaView or LoginRequiredMediaView instead."
            )

    def get(self, request, path, as_download=False):  # noqa
        # TODO: implement `as_download`
        # Construct the full path to the media file
        response = serve(
            request,
            path,
            document_root=settings.PROTECTED_MEDIA_ROOT,
            show_indexes=False,
        )
        return response


class LoginRequiredMediaView(LoginRequiredMixin, ProtectedMediaBaseView):
    """A view that serves, but protects media files from unauthorized access by
    checking if user is logged in.

    It denies access to the `settings.PROTECTED_MEDIA_ROOT` directory to any
    anonymous user.
    You can directly use it in your urls.py:

    Example usage:
    ```python
    # urls.py
    urlpatterns = [
        path(
            "media/protected/<path>/",
            LoginRequiredMediaView.as_view(),
            name="protected_media",
        ),
        ...,
    ]
    ```
    """


class PermissionRequiredMediaView(PermissionRequiredMixin, ProtectedMediaBaseView):
    """A view that serves, but protects media files from unauthorized access by
    checking user permissions.

    It denies access to the `settings.PROTECTED_MEDIA_ROOT` directory without proper
    permissions.
    As it inherits PermissionRequiredMixin, you have to use the `permission_required`
    attribute to set the required permissions. You can directly use it in your urls.py
    by adding the permission_required attribute as parameter to `as_view()`,
    or subclass the view and set it there.

    Example usage:
    ```python
    # urls.py
    urlpatterns = [
        path(
            "media/protected/<path>/",
            PermissionRequiredMediaView.as_view(
                permission_required="my_project.view_media"),
            name="protected_media",
        ),
        ...,
    ]
    ```
    """


class TokenValidationView(TemplateView):
    """A TemplateView that verifies a token link.

    It renders a template you have to set, which has some context variables
    available:
        token_valid (bool): True if the token was verified correctly, else False
        token_user (User): The User object from the token.
        token_already_used (bool): True if the cause of the token being invalid was
            that a certain hashed user attribute checked in the token had been changed.

    You have to provide a template_name.

    Attributes:
        template_name: The name of the template to render.
        token_generator: The obligatory token generator to use.
        token_already_used: Whether the token has already been used. Defaults to
            False, you can set it to true depending on conditions you set for yourself
    """

    token_generator = None
    token_already_used: bool = False

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.token_user: User | None = None

        if not self.token_generator:
            raise ImproperlyConfigured(
                f"{self.__class__.__name__} requires 'token_generator' attribute."
            )

    def get_context_data(self, **kwargs) -> dict:
        """Get token from URL and pass it into the template."""
        context = super().get_context_data(**kwargs)
        context.update(
            token_user=self.token_user, token_already_used=self.token_already_used
        )
        return context

    def token_valid(self) -> None:
        pass

    def token_invalid(self, **kwargs) -> None:
        pass

    def check_token_preconditions(self) -> bool:
        """Returns True if a precondition for token validity was already met,
        else False.

        It can be assumed that self.token_user is already set.
        E.g., the token could be invalid if clicked a second time on the link,
        The user must be above 16 years, etc.
        Use view attributes and include them into your template context if you want to
        show more information about the failing in your template
        """

    def get(self, request, uidb64, token, *args, **kwargs) -> HttpResponse:
        try:
            uid = force_str(urlsafe_base64_decode(uidb64))
            self.token_user = User.objects.get(pk=uid)
        except (TypeError, ValueError, OverflowError, User.DoesNotExist):
            # user stays None in case of any error
            pass

        # Check token precondition in subclasses
        if self.token_user is not None:
            if self.check_token_preconditions():
                # if user is just a system user, no MedspeakAccount -> deny it!
                if self.token_generator.check_token(self.token_user, token):
                    self.token_valid()
                    return self.render_to_response(
                        self.get_context_data(token_valid=True)
                    )

        self.token_invalid()
        return self.render_to_response(self.get_context_data(token_valid=False))


_VALID_SIDEBAR_MODES = ("full", "mini", "collapsed")
_VALID_SIDEBAR_SIDES = ("left", "right")
_WIDTH_RE = r"^\d+(\.\d+)?(px|rem|em|vw)$"


class SaveSidebarStateView(View):
    """Endpoint to persist a sidebar's display state (mode + width).

    Accepts POST to ``/sidebar-state/<side>/`` with JSON body
    ``{"mode": "full|mini|collapsed", "width": "<css-length>"}``. Both
    keys are optional; the request must carry at least one. The view
    treats each piece independently:

    * ``mode`` is persisted in DEVICE scope for both authenticated and
      anonymous users — a tablet may want ``mini`` while a desktop
      wants ``full``.
    * ``width`` is persisted in USER scope for authenticated users only;
      anonymous requests with a ``width`` payload return 401.

    A VENDOR- or TENANT-level lock on the side's mode/width key makes
    the corresponding part of the request return 403 (server-enforced
    defense in depth — the UI also disables the toggle / hides the
    handle client-side).
    """

    http_method_names = ["post"]

    def post(self, request, side, *args, **kwargs):
        import json

        from conjunto.settings.scoped.models import Scope, ScopedSetting
        from conjunto.settings.scoped.resolver import get_resolution

        if side not in _VALID_SIDEBAR_SIDES:
            return JsonResponse({"error": "Invalid side"}, status=400)

        try:
            data = json.loads(request.body)
        except (json.JSONDecodeError, ValueError):
            return JsonResponse({"error": "Invalid JSON"}, status=400)

        mode = (data.get("mode") or "").strip().lower() or None
        width = (data.get("width") or "").strip() or None
        if not mode and not width:
            return JsonResponse({"error": "Nothing to persist"}, status=400)

        mode_key = f"sidebar_{side}_mode"
        width_key = f"sidebar_{side}_width"

        if mode is not None:
            if mode not in _VALID_SIDEBAR_MODES:
                return JsonResponse({"error": "Invalid sidebar mode"}, status=400)
            resolution = get_resolution("conjunto", mode_key, request)
            if resolution.is_locked and resolution.lock_scope in (
                Scope.VENDOR,
                Scope.TENANT,
            ):
                return JsonResponse({"error": "Mode is locked"}, status=403)
            device = getattr(request, "device", None)
            if device is None:
                # ConjuntoMiddleware sets ``request.device`` on every
                # request via the ``cj_device_id`` cookie — missing
                # means the middleware is misconfigured.
                return JsonResponse({"error": "Device not available"}, status=400)
            ScopedSetting.objects.update_or_create(
                namespace="conjunto",
                key=mode_key,
                scope=Scope.DEVICE,
                device=device,
                defaults={"value": mode},
            )
            request.scoped_settings.invalidate("conjunto", mode_key)

        if width is not None:
            import re

            if not re.match(_WIDTH_RE, width):
                return JsonResponse({"error": "Invalid CSS length"}, status=400)
            if not request.user.is_authenticated:
                return JsonResponse(
                    {"error": "Authentication required for width"}, status=401
                )
            resolution = get_resolution("conjunto", width_key, request)
            if resolution.is_locked and resolution.lock_scope in (
                Scope.VENDOR,
                Scope.TENANT,
            ):
                return JsonResponse({"error": "Width is locked"}, status=403)
            ScopedSetting.objects.update_or_create(
                namespace="conjunto",
                key=width_key,
                scope=Scope.USER,
                user=request.user,
                defaults={"value": width},
            )
            request.scoped_settings.invalidate("conjunto", width_key)

        return JsonResponse({"ok": True})


class SaveColorSchemeView(View):
    """HTMX endpoint to persist the user's color scheme preference.

    Accepts POST with JSON body ``{"color_scheme": "light"|"dark"}``.
    For authenticated users the value is stored as a USER-scoped setting;
    for anonymous users it is stored as a DEVICE-scoped setting.
    This ensures the server can render ``data-bs-theme`` on the ``<html>``
    tag during the initial page load, eliminating the flash of wrong theme.
    """

    http_method_names = ["post"]

    def post(self, request, *args, **kwargs):
        import json

        from conjunto.settings.scoped.models import Scope, ScopedSetting

        try:
            data = json.loads(request.body)
        except (json.JSONDecodeError, ValueError):
            return JsonResponse({"error": "Invalid JSON"}, status=400)

        scheme = data.get("color_scheme", "").strip().lower()
        if scheme not in ("light", "dark"):
            return JsonResponse({"error": "Invalid color scheme"}, status=400)

        if request.user.is_authenticated:
            ScopedSetting.objects.update_or_create(
                namespace="conjunto",
                key="color_scheme",
                scope=Scope.USER,
                user=request.user,
                defaults={"value": scheme},
            )
        else:
            device = getattr(request, "device", None)
            if device is not None:
                ScopedSetting.objects.update_or_create(
                    namespace="conjunto",
                    key="color_scheme",
                    scope=Scope.DEVICE,
                    device=device,
                    defaults={"value": scheme},
                )

        request.scoped_settings.invalidate("conjunto", "color_scheme")
        return JsonResponse({"ok": True})


class ModelAutocompleteView(LoginRequiredMixin, View):
    """Generic autocomplete view for model-based search using a signed token.

    The token is generated by :class:`~conjunto.forms.widgets.AutocompleteInput`
    using Django's signing framework. It encodes the model path, search fields,
    and label field so that this single view can handle autocomplete for any model.

    Requires the user to be logged in. Override ``get_queryset()`` in a subclass
    to add custom filtering (e.g. tenant scoping).

    Returns JSON: ``{"results": [{"value": "<pk>", "label": "<display>"}], "query": "<q>"}``.

    Beware this can open a security hole, as ANY models can be retrieved, if the token matches.
    """

    raise_exception = True

    def get(self, request, *args, **kwargs) -> JsonResponse:

        token = request.GET.get("token", "")
        try:
            data = signing.loads(token)
            model: type[models.Model] = apps.get_model(data["model"])
            search_fields: list[str] = data["search_fields"]
            label_field: str = data.get("label_field", "__str__")
        except (signing.BadSignature, signing.SignatureExpired, KeyError, LookupError):
            return JsonResponse({"results": [], "query": ""}, status=403)

        query = request.GET.get("q", "")
        if not query:
            return JsonResponse({"results": [], "query": query})

        search_q = Q()
        for field in search_fields:
            search_q |= Q(**{f"{field}__icontains": query})

        qs = model.objects.filter(search_q)[:20]

        def _label(obj) -> str:
            if label_field == "__str__":
                return str(obj)
            return str(getattr(obj, label_field, obj))

        results = [
            {"value": escape(str(obj.pk)), "label": escape(_label(obj))} for obj in qs
        ]
        return JsonResponse({"results": results, "query": query})


class TableListView(SingleTableMixin, ListView):
    """List view with built-in search, filters, and header actions.

    Combines ``django-tables2``'s ``SingleTableMixin`` with:

    - ``search_fields``: iterable of model field paths to OR-search
      (icontains) against ``?q=``.
    - ``filters``: list of :class:`conjunto.filters.Filter` instances,
      each bound to a ``?<name>=`` GET parameter.
    - ``header_actions``: list of :class:`conjunto.tables.HeaderAction`
      instances rendered in the card header.
    - ``header_actions_menu``: GDAPS slot name for pluggable
      ``IHeaderAction`` implementations that augment
      ``header_actions``.
    - ``filterset_class``: optional ``django-filter`` ``FilterSet``
      class that takes precedence over ``filters``.

    ``get_queryset`` applies search first, then filters, then hands the
    result off to the superclass. The view also exposes
    ``search_fields``, ``filters``, ``filter_values``, ``search_value``,
    ``search_placeholder``, ``search_param`` and ``header_actions``
    in the template context so the built-in
    ``conjunto/tables/list_card.html`` template (Phase 2) can render
    them.
    """

    search_fields: ClassVar[Iterable[str]] = ()
    search_placeholder: ClassVar[str] = ""
    search_param: ClassVar[str] = "q"
    filters: ClassVar[Iterable[Filter]] = ()
    header_actions: ClassVar[Iterable[Any]] = ()
    header_actions_menu: ClassVar[str] = ""
    filterset_class: ClassVar[Optional[type]] = None

    def get_queryset(self) -> QuerySet:
        qs = super().get_queryset()
        qs = self.apply_search(qs)
        qs = self.apply_filters(qs)
        return qs

    def apply_search(self, qs: QuerySet) -> QuerySet:
        """OR-combine ``icontains`` clauses over ``search_fields``."""
        term = (self.request.GET.get(self.search_param) or "").strip()
        if not term or not self.search_fields:
            return qs
        clauses = [Q(**{f"{f}__icontains": term}) for f in self.search_fields]
        return qs.filter(reduce(or_, clauses))

    def apply_filters(self, qs: QuerySet) -> QuerySet:
        """Apply every declared :class:`Filter` to ``qs``.

        When ``filterset_class`` is set, defer to ``django-filter``
        entirely (``filters`` is ignored).
        """
        if self.filterset_class is not None:
            fs = self.filterset_class(self.request.GET, queryset=qs)
            return fs.qs
        for f in self.filters:
            value = self.request.GET.get(f.name, "")
            qs = f.apply(qs, value)
        return qs

    def collect_header_actions(self) -> list:
        """Combine declarative ``header_actions`` with GDAPS plugins.

        Plugins that match ``header_actions_menu`` are instantiated
        and asked for their :class:`HeaderAction` via ``to_header_action``.
        The final list is permission-filtered and weight-sorted.
        """
        from conjunto.tables import HeaderAction, IHeaderAction

        actions: list[HeaderAction] = list(self.header_actions)
        if self.header_actions_menu:
            for plugin_cls in IHeaderAction.enabled_plugins():
                if getattr(plugin_cls, "menu", "") != self.header_actions_menu:
                    continue
                plugin = plugin_cls()
                action = plugin.to_header_action(self.request)
                if action is None:
                    continue
                actions.append(action)
        actions = [a for a in actions if a.is_allowed(self.request)]
        actions.sort(key=lambda a: a.weight)
        return actions

    def get_context_data(self, **kwargs) -> dict[str, Any]:
        ctx = super().get_context_data(**kwargs)
        ctx["search_fields"] = tuple(self.search_fields)
        ctx["search_placeholder"] = self.search_placeholder
        ctx["search_param"] = self.search_param
        ctx["search_value"] = self.request.GET.get(self.search_param, "")
        ctx["filters"] = list(self.filters)
        ctx["filter_values"] = {
            f.name: self.request.GET.get(f.name, "") for f in self.filters
        }
        ctx["header_actions"] = self.collect_header_actions()
        return ctx
