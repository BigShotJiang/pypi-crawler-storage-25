"""Reusable table machinery with consistent row actions.

This module provides three building blocks for tables that need
recognizable, system-wide row actions:

- `RowAction`: declarative description of a single row-level action
  (label, icon, URL, HTMX attributes, permission, visibility, confirm
  modal, weight). Everything a button needs, with no template fragments.
- `ActionsColumn`: a `django_tables2.Column` that renders a list of
  `RowAction`s into a Tabler `btn-list` via the
  `conjunto/tables/_row_actions.html` template.
- `RowActionsMixin`: a `tables.Table` mixin that wires up the "actions"
  column, assembles the standard edit/delete actions from a URL
  namespace, pulls in extra actions contributed by `IRowAction` GDAPS
  plugins, and attaches the table wrapper to HTMX `hx-trigger` listen
  events so it auto-refreshes on CRUD success events.

The design is intentionally dataclass-first: consumer code builds
`RowAction` instances or registers `IRowAction` plugins, and the table
knows how to render them. There is no metaclass magic, no string
templating, and no `format_html` calls in Python.

HTMX vs. plain navigation is a per-action flag (`htmx=True` by default).
The delete action opens a modal confirmation dialog by default
(targets `#dialog`); individual actions can override this with
`confirm_style="inline"` (browser-native `hx-confirm`) or by providing
their own `confirm_url`.

Listen events follow the convention `"<namespace>:created"`,
`"<namespace>:changed"`, `"<namespace>:deleted"`. A `RowActionsMixin`
table listens for these by default on its wrapper element, which has
`id="table-<slug>"` and `hx-trigger="<event> from:body"`.

In addition, the module exposes :class:`HeaderAction`, :class:`IHeaderAction`,
and :func:`standard_add_action` — the symmetric primitives for
table-header buttons (`+Add`, `Export`, …) consumed by
``conjunto.views.TableListView``.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Callable, Iterable, Optional

import django_tables2 as tables
from django.http import HttpRequest
from django.template.loader import render_to_string
from django.urls import reverse
from django.utils.safestring import SafeString, mark_safe
from django.utils.text import slugify
from django.utils.translation import gettext_lazy as _
from gdaps.api import Interface

__all__ = [
    "RowAction",
    "IRowAction",
    "ActionsColumn",
    "RowActionsMixin",
    "standard_edit_action",
    "standard_delete_action",
    "HeaderAction",
    "IHeaderAction",
    "standard_add_action",
    "BulkAction",
    "IBulkAction",
    "get_bulk_actions",
]


#: Default HTMX target for modal dialogs opened from a row action.
#: Override by setting `RowAction.target` or `RowActionsMixin.dialog_target`.
DEFAULT_DIALOG_TARGET = "#dialog"


@dataclass
class RowAction:
    """Declarative description of one row-level action button.

    A `RowAction` is the only thing a table needs to render one button.
    It carries both the display data (label, icon, CSS variant) and the
    behavior (URL, HTTP method, HTMX attributes, confirm flow,
    permission check). `RowActionsMixin.get_row_actions` builds a list
    of these per record and hands them to `ActionsColumn`.

    Three resolution helpers turn per-record values into strings:

    - `url`, `target`, and `swap` may each be a string (used as-is)
      or a callable `(record) -> str`. Use `reverse(...)` for static
      URL names and a lambda for anything that needs the record's
      pk — for example to point an HTMX swap at the row's own
      ``<tr>`` (`target=lambda r: f"#row-{r.pk}"`).
    - `visible` may be `None` (always visible) or a callable
      `(record, request) -> bool`. It runs *after* the permission
      check; both must pass.

    The `confirm` attribute triggers either a browser-native
    `hx-confirm` (`confirm_style="inline"`) or an HTMX modal fetch
    (`confirm_style="modal"`, default). In modal mode the button
    issues `hx-get` against `confirm_url` — typically a
    `ModalDeleteView` URL — and the server returns the confirmation
    form; the actual delete happens on POST from inside the modal. If
    `confirm_url` is not set, the action's own `url` is used.
    """

    name: str
    label: str
    icon: str = ""
    url: str | Callable[[Any], str] = ""
    method: str = "get"
    htmx: bool = True
    target: str | Callable[[Any], str] = DEFAULT_DIALOG_TARGET
    swap: str | Callable[[Any], str] = "innerHTML"
    confirm: str = ""
    confirm_style: str = "modal"
    confirm_url: str | Callable[[Any], str] = ""
    variant: str = "btn-ghost-secondary"
    permission: Optional[str | Callable[[Any, HttpRequest], bool]] = None
    visible: Optional[Callable[[Any, HttpRequest], bool]] = None
    weight: int = 100
    extra_attrs: dict[str, str] = field(default_factory=dict)

    def resolve_url(self, record: Any) -> str:
        return self.url(record) if callable(self.url) else str(self.url)

    def resolve_target(self, record: Any) -> str:
        return self.target(record) if callable(self.target) else str(self.target)

    def resolve_swap(self, record: Any) -> str:
        return self.swap(record) if callable(self.swap) else str(self.swap)

    def resolve_confirm_url(self, record: Any) -> str:
        if self.confirm_url:
            return (
                self.confirm_url(record)
                if callable(self.confirm_url)
                else str(self.confirm_url)
            )
        return self.resolve_url(record)

    def is_allowed(self, record: Any, request: HttpRequest) -> bool:
        """Return True if this action should render for (record, request).

        Combines `permission` (Django perm string or callable) and
        `visible` (callable). Both must pass. Missing `request.user`
        is treated as unauthenticated.
        """
        perm = self.permission
        if perm is not None:
            if callable(perm):
                if not perm(record, request):
                    return False
            else:
                user = getattr(request, "user", None)
                if user is None or not user.has_perm(perm):
                    return False
        if self.visible is not None and not self.visible(record, request):
            return False
        return True

    def render_attrs(self, record: Any) -> dict[str, str]:
        """Build the HTML attribute dict for this action's button."""
        attrs: dict[str, str] = {
            "class": f"btn btn-sm btn-icon {self.variant}".strip(),
            "title": str(self.label),
            "aria-label": str(self.label),
        }
        url = self.resolve_url(record)
        target = self.resolve_target(record)
        swap = self.resolve_swap(record)

        if self.confirm and self.confirm_style == "modal":
            # Modal-based confirm: GET the confirm URL into the dialog.
            attrs["hx-get"] = self.resolve_confirm_url(record)
            attrs["hx-target"] = target
            attrs["hx-swap"] = swap
        elif self.htmx:
            attrs[f"hx-{self.method}"] = url
            attrs["hx-target"] = target
            attrs["hx-swap"] = swap
            if self.confirm and self.confirm_style == "inline":
                attrs["hx-confirm"] = str(self.confirm)
        else:
            # Plain navigation. For POST we still fall back to HTMX,
            # because plain POST needs a wrapping form.
            attrs["href"] = url

        attrs.update({k: str(v) for k, v in self.extra_attrs.items()})
        return attrs


@dataclass
class HeaderAction:
    """Declarative description of one header-level action button.

    Symmetrical to :class:`RowAction` but resolved once per request
    (no record binding). Typical use: `+Add`, `Export`, `Import`.
    """

    name: str
    label: str
    icon: str = "plus"
    url: str | Callable[[HttpRequest], str] = ""
    method: str = "get"
    htmx: bool = True
    target: str = "#dialog"
    swap: str = "innerHTML"
    variant: str = "btn-primary"
    permission: Optional[str | Callable[[HttpRequest], bool]] = None
    visible: Optional[Callable[[HttpRequest], bool]] = None
    weight: int = 100
    extra_attrs: dict[str, str] = field(default_factory=dict)

    def resolve_url(self, request: HttpRequest) -> str:
        return self.url(request) if callable(self.url) else str(self.url)

    def is_allowed(self, request: HttpRequest) -> bool:
        """Return True if this action should render for ``request``.

        Combines `permission` (Django perm string or callable) and
        `visible` (callable). Both must pass. Missing `request.user`
        or anonymous user is treated as unauthenticated.
        """
        perm = self.permission
        if perm is not None:
            if callable(perm):
                if not perm(request):
                    return False
            else:
                user = getattr(request, "user", None)
                if user is None or not user.has_perm(perm):
                    return False
        if self.visible is not None and not self.visible(request):
            return False
        return True

    def render_attrs(self, request: HttpRequest) -> dict[str, str]:
        """Build the HTML attribute dict for this action's button."""
        attrs: dict[str, str] = {
            "class": f"btn {self.variant}".strip(),
            "title": str(self.label),
        }
        url = self.resolve_url(request)
        if self.htmx:
            attrs[f"hx-{self.method}"] = url
            attrs["hx-target"] = self.target
            attrs["hx-swap"] = self.swap
        else:
            attrs["href"] = url
        attrs.update({k: str(v) for k, v in self.extra_attrs.items()})
        return attrs


class IHeaderAction(Interface):
    """GDAPS interface for pluggable header actions.

    Implementations attach to a named menu slot. Tables / views that
    set ``header_actions_menu`` pick up all plugins whose ``menu``
    matches and render the returned :class:`HeaderAction`s.

    Attributes:
        menu: Slot name this action attaches to.
        weight: Sort weight among actions in the same slot (ascending).
    """

    menu: str = ""
    weight: int = 100

    def to_header_action(
        self, request: HttpRequest
    ) -> Optional[HeaderAction]:  # pragma: no cover - interface
        raise NotImplementedError


def standard_add_action(
    url_namespace: str,
    *,
    permission: Optional[str] = None,
    weight: int = 10,
    label: Optional[str] = None,
) -> HeaderAction:
    """Build the standard '+Add' header action for a URL namespace.

    Expects a URL named ``<namespace>_create`` with no kwargs. Opens
    the create form in the modal dialog by default.
    """
    return HeaderAction(
        name="add",
        label=label or _("Add"),
        icon="plus",
        url=lambda request: reverse(f"{url_namespace}_create"),
        method="get",
        htmx=True,
        variant="btn-primary",
        permission=permission,
        weight=weight,
    )


class IRowAction(Interface):
    """GDAPS interface for pluggable row actions.

    Implement this in a consumer app to contribute extra row actions
    to tables that declare a matching `extra_actions_menu`. One plugin
    class represents one action; `to_row_action(request, record)`
    returns a fully-built `RowAction` or `None` to skip rendering.

    Attributes:
        menu: Slot name this action attaches to. Tables with
            `extra_actions_menu = "<menu>"` pick up all plugins that
            share that value.
        weight: Sort weight among actions in the same row (ascending).
    """

    menu: str = ""
    weight: int = 100

    def to_row_action(
        self, request: HttpRequest, record: Any
    ) -> Optional[RowAction]:  # pragma: no cover - interface
        raise NotImplementedError


def standard_edit_action(
    url_namespace: str,
    *,
    target: str = DEFAULT_DIALOG_TARGET,
    permission: Optional[str] = None,
    weight: int = 10,
) -> RowAction:
    """Build the standard 'edit' row action for a URL namespace.

    Expects a URL named `<namespace>_update` that accepts a `pk`
    kwarg. Opens the edit form in the modal dialog by default.
    """
    return RowAction(
        name="edit",
        label=_("Edit"),
        icon="pencil",
        url=lambda record: reverse(f"{url_namespace}_update", kwargs={"pk": record.pk}),
        method="get",
        htmx=True,
        target=target,
        permission=permission,
        weight=weight,
    )


def standard_delete_action(
    url_namespace: str,
    *,
    target: str | Callable[[Any], str] = DEFAULT_DIALOG_TARGET,
    swap: str | Callable[[Any], str] = "innerHTML",
    permission: Optional[str] = None,
    weight: int = 20,
    confirm_style: str = "modal",
    inline_confirm_text: str = "",
    success_strategy: str = "wrapper-refresh",
    row_target: Optional[str | Callable[[Any], str]] = None,
) -> RowAction:
    """Build the standard 'delete' row action for a URL namespace.

    Expects a URL named `<namespace>_delete` that accepts a `pk`
    kwarg. With `confirm_style="modal"` (default) the button GETs
    the delete view into the dialog, where a confirmation form then
    POSTs back. With `confirm_style="inline"` the click uses a
    browser-native `hx-confirm` prompt and issues the delete request
    directly.

    Two ``success_strategy`` values are supported:

    - ``"wrapper-refresh"`` (default): the table wrapper listens for
      the ``<ns>:deleted`` event and re-fetches itself after a
      successful delete. The button's ``target``/``swap`` attributes
      stay at the modal dialog (or whatever the caller passes).
    - ``"row-remove"``: HTMX swaps the row out of the DOM directly,
      no full table re-render. ``row_target`` (callable
      ``(record) -> css_selector``) tells the action which element
      to swap; the server is expected to return ``200`` with an
      empty body and ``HX-Reswap: outerHTML swap:0.3s`` (handled
      by ``HtmxDeleteView`` when its ``success_strategy`` matches).
      For inline confirm the row target is set as the action's
      ``hx-target`` directly. For modal confirm the action still
      opens the modal at ``target`` (typically ``#dialog``); the
      server overrides target/swap via ``HX-Retarget``/``HX-Reswap``
      headers when the form POST succeeds.
    """
    if success_strategy == "row-remove":
        if row_target is None:
            raise ValueError(
                "standard_delete_action(success_strategy='row-remove') requires "
                "row_target=lambda record: '#some-id'."
            )
        if confirm_style == "inline":
            # Direct POST from the button onto the row itself.
            target = row_target
            swap = "outerHTML swap:0.3s"

    return RowAction(
        name="delete",
        label=_("Delete"),
        icon="trash",
        url=lambda record: reverse(f"{url_namespace}_delete", kwargs={"pk": record.pk}),
        method="post" if confirm_style == "inline" else "get",
        htmx=True,
        target=target,
        swap=swap,
        variant="btn-ghost-danger",
        confirm=inline_confirm_text or _("Really delete this item?"),
        confirm_style=confirm_style,
        permission=permission,
        weight=weight,
    )


class ActionsColumn(tables.Column):
    """A `django_tables2.Column` that renders a row's action buttons.

    The column does not carry the list of actions itself — the parent
    `RowActionsMixin.render_actions` builds the per-record list and
    passes it in via `render_to_string`. This keeps the column
    stateless and lets each row resolve permissions against the
    current request.
    """

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("verbose_name", _("Actions"))
        kwargs.setdefault("empty_values", ())
        kwargs.setdefault("orderable", False)
        attrs = kwargs.setdefault("attrs", {})
        attrs.setdefault("td", {"class": "text-end cj-row-actions"})
        attrs.setdefault("th", {"class": "text-end cj-row-actions"})
        super().__init__(*args, **kwargs)


class RowActionsMixin:
    """Mixin that adds an 'actions' column with row action buttons.

    Declare this alongside `django_tables2.Table` and set at least
    `row_actions_namespace`. The mixin then:

    - appends an `actions` column at the end of `Meta.sequence`;
    - builds standard edit/delete actions via
      `standard_edit_action` / `standard_delete_action` using the
      namespace's `<ns>_update` / `<ns>_delete` URL names;
    - appends extra actions contributed by `IRowAction` plugins whose
      `menu` equals `extra_actions_menu`;
    - sorts the combined list by weight and renders the buttons;
    - exposes `listen_events` so the calling template can wire the
      table wrapper to `hx-trigger` and refresh itself on
      `<ns>:created|changed|deleted` success events.

    Class attributes:
        row_actions_namespace: Required. Base name for CRUD URLs, e.g.
            `"projects:project"`. Expected routes:
            `{namespace}_update`, `{namespace}_delete`.
        row_actions: Names of standard actions to include. Defaults
            to `("edit", "delete")`. Set to `()` to opt out.
        extra_actions_menu: GDAPS menu slot for `IRowAction` plugins
            that should appear *additionally* to the standard actions.
        edit_permission / delete_permission: Django permission strings
            gating the standard actions. `None` means "always allow".
        delete_confirm_style: `"modal"` (default) or `"inline"`.
        dialog_target: HTMX target for actions that open the modal.
            Defaults to `#dialog`.
        listen_events: Explicit list of events. If unset, defaults to
            `["<namespace>:created", "<namespace>:changed",
            "<namespace>:deleted"]` (only the ones whose standard
            actions are enabled, plus always `:created`).
    """

    row_actions_namespace: str = ""
    row_actions: Iterable[str] = ("edit", "delete")
    extra_actions_menu: str = ""
    edit_permission: Optional[str] = None
    delete_permission: Optional[str] = None
    delete_confirm_style: str = "modal"
    delete_success_strategy: str = "wrapper-refresh"
    """How a successful delete refreshes the UI.

    - ``"wrapper-refresh"`` (default): the table wrapper listens for
      the ``<ns>:deleted`` event and re-fetches itself.
    - ``"row-remove"``: HTMX removes the row from the DOM directly,
      no full table re-render. The mixin then auto-injects an ``id``
      into ``row_attrs`` (if the consumer has not set one) so the
      row is targetable by a stable selector. Pair with a
      ``HtmxDeleteView`` whose ``success_strategy`` matches.
    """
    row_id_template: str = "row-{ns}-{pk}"
    """Template for the ``<tr>``-level DOM id when ``row-remove`` is active.

    Placeholders: ``{ns}`` is the slugified ``row_actions_namespace``
    (``:`` replaced by ``-``); ``{pk}`` is the record's primary key.
    Override at table-class level to use a different stable identifier
    (e.g. a UUID or slug field). The result must be a valid CSS id.
    """
    dialog_target: str = DEFAULT_DIALOG_TARGET
    listen_events: Optional[list[str]] = None

    def __init__(self, *args, request: Optional[HttpRequest] = None, **kwargs):
        if not self.row_actions_namespace:
            raise AttributeError(
                f"{type(self).__name__} must set 'row_actions_namespace' "
                f"(e.g. 'projects:project')."
            )

        # Inject the actions column. `RowActionsMixin` is not a
        # `tables.Table` subclass, so its class-level `Column` attrs
        # are invisible to django-tables2's declarative metaclass.
        # `extra_columns` is the documented hook for this.
        extra = list(kwargs.pop("extra_columns", []))
        if not any(name == "actions" for name, _ in extra):
            extra.append(("actions", ActionsColumn()))
        kwargs["extra_columns"] = extra

        # Ensure "actions" stays at the end of the column sequence.
        sequence = kwargs.get("sequence") or getattr(
            getattr(self, "Meta", object), "sequence", ("...",)
        )
        sequence = tuple(c for c in sequence if c != "actions") + ("actions",)
        kwargs["sequence"] = sequence

        # When row-remove is active, ensure each <tr> carries a stable
        # id so a delete can target it via `outerHTML` swap. Merge with
        # any caller-provided / Meta-declared row_attrs so we never
        # clobber an explicit id.
        if self.delete_success_strategy == "row-remove":
            meta_row_attrs = dict(
                getattr(getattr(self, "Meta", object), "row_attrs", None) or {}
            )
            kwarg_row_attrs = dict(kwargs.get("row_attrs") or {})
            merged = {**meta_row_attrs, **kwarg_row_attrs}
            if "id" not in merged:
                merged["id"] = lambda record: self.get_row_id(record)
            kwargs["row_attrs"] = merged

        super().__init__(*args, **kwargs)

        # Table carries the request for per-row permission checks.
        self._cj_request: Optional[HttpRequest] = request or getattr(
            self, "request", None
        )

    # ---- row id resolution ---------------------------------------------

    def get_row_id(self, record: Any) -> str:
        """Return the stable DOM id for the row representing ``record``.

        Used for the ``row-remove`` delete strategy. Override to use a
        different identifier (e.g. ``record.uuid``); the result must be
        a valid CSS id.
        """
        # Replace ``:`` BEFORE slugify because Django's slugify drops
        # the colon entirely without inserting a separator.
        ns = slugify(self.row_actions_namespace.replace(":", "-"))
        return self.row_id_template.format(ns=ns, pk=record.pk)

    # ---- action assembly ------------------------------------------------

    def get_standard_actions(self) -> list[RowAction]:
        """Build the configured standard actions (edit/delete)."""
        actions: list[RowAction] = []
        ns = self.row_actions_namespace
        if "edit" in self.row_actions:
            actions.append(
                standard_edit_action(
                    ns,
                    target=self.dialog_target,
                    permission=self.edit_permission,
                )
            )
        if "delete" in self.row_actions:
            row_target = (
                (lambda r: f"#{self.get_row_id(r)}")
                if self.delete_success_strategy == "row-remove"
                else None
            )
            actions.append(
                standard_delete_action(
                    ns,
                    target=self.dialog_target,
                    permission=self.delete_permission,
                    confirm_style=self.delete_confirm_style,
                    success_strategy=self.delete_success_strategy,
                    row_target=row_target,
                )
            )
        return actions

    def get_extra_actions(self, request: HttpRequest, record: Any) -> list[RowAction]:
        """Collect `IRowAction` plugins for this table's menu slot."""
        if not self.extra_actions_menu:
            return []
        result: list[RowAction] = []
        for plugin_cls in IRowAction.enabled_plugins():
            if getattr(plugin_cls, "menu", "") != self.extra_actions_menu:
                continue
            plugin = plugin_cls()
            action = plugin.to_row_action(request, record)
            if action is None:
                continue
            # Default the action's weight to its plugin class weight.
            if action.weight == 100 and getattr(plugin_cls, "weight", 100) != 100:
                action = replace(action, weight=plugin_cls.weight)
            result.append(action)
        return result

    def get_row_actions(self, record: Any, request: HttpRequest) -> list[RowAction]:
        """Return the ordered, permission-filtered actions for one row.

        Override this to inject per-row logic without touching the
        rendering machinery.
        """
        actions = self.get_standard_actions() + self.get_extra_actions(request, record)
        actions = [a for a in actions if a.is_allowed(record, request)]
        actions.sort(key=lambda a: a.weight)
        return actions

    def render_actions(self, record) -> SafeString:
        request = self._get_request()
        if request is None:
            return mark_safe("")
        actions = self.get_row_actions(record, request)
        if not actions:
            return mark_safe("")
        buttons = [
            {
                "attrs": action.render_attrs(record),
                "icon": action.icon,
                "name": action.name,
            }
            for action in actions
        ]
        return render_to_string(
            "conjunto/tables/_row_actions.html",
            {"buttons": buttons},
            request=request,
        )

    # ---- wrapper + listen events ---------------------------------------

    def get_listen_events(self) -> list[str]:
        """Return the HTMX listen events for the table wrapper."""
        if self.listen_events is not None:
            return list(self.listen_events)
        ns = self.row_actions_namespace
        events = [f"{ns}:created"]
        if "edit" in self.row_actions:
            events.append(f"{ns}:changed")
        if "delete" in self.row_actions:
            events.append(f"{ns}:deleted")
        return events

    @property
    def wrapper_id(self) -> str:
        """Stable DOM id for the table wrapper, used by templates."""
        # Replace ``:`` BEFORE slugify (slugify drops colons silently).
        return f"table-{slugify(self.row_actions_namespace.replace(':', '-'))}"

    @property
    def hx_trigger(self) -> str:
        """`hx-trigger` value joining all listen events."""
        return ", ".join(f"{e} from:body" for e in self.get_listen_events())

    # ---- helpers --------------------------------------------------------

    def _get_request(self) -> Optional[HttpRequest]:
        # django-tables2 sets `self.request` from the template tag's
        # context; fall back to the one passed into __init__.
        return getattr(self, "request", None) or self._cj_request


# --------------------------------------------------------------------------- #
# Bulk actions — multi-record action bar                                      #
# --------------------------------------------------------------------------- #


#: Default name of the form/query parameter carrying selected primary keys.
DEFAULT_BULK_PK_NAME = "pks"


@dataclass
class BulkAction:
    """Declarative description of one bulk-action bar button.

    A ``BulkAction`` describes an action applied to multiple selected
    records — the multi-row counterpart to :class:`RowAction`. The
    actual record selection lives on the client as ``<input type=
    "checkbox" name="pks" value="<pk>">`` elements; HTMX picks them up
    automatically via ``hx-include="[name='pks']:checked"`` injected by
    :meth:`render_attrs`.

    Two confirmation styles are supported, both compatible with the
    selection-bar UI:

    - ``confirm_style="modal"`` (default when ``confirm`` is set): the
      button issues an HTMX ``GET`` to ``url`` with the selected pks as
      query parameters, expecting the server to return a confirmation
      modal into ``target`` (typically ``#dialog``). The modal's form
      then POSTs to the same URL with the pks rendered as hidden
      ``<input name="pks">`` fields. :class:`BulkActionView` ships a
      ready-made GET handler that renders a confirmation template; see
      ``conjunto.htmx.views.BulkActionView`` for the contract.
    - ``confirm_style="inline"``: a browser-native ``hx-confirm``
      prompt fires before HTMX issues a direct ``POST``. Quicker but
      ugly; reserve for non-destructive actions.
    - Empty ``confirm``: HTMX issues a direct ``POST`` to ``url`` with
      no confirmation. The server is responsible for any safety check.

    The ``visible`` and ``permission`` hooks gate rendering, mirroring
    :class:`HeaderAction`. Neither bound to a record — the action lives
    at the table level, not per-row, so the callbacks receive only the
    request.

    Example::

        BulkAction(
            name="delete",
            label=_("Delete selected"),
            icon="trash",
            url=reverse_lazy("medspeak:accounts:bulk_delete"),
            variant="btn-danger",
            confirm=_("Delete these accounts?"),
            permission="medspeak.delete_medspeakaccount",
            weight=10,
        )
    """

    name: str
    label: str
    icon: str = ""
    url: str | Callable[[HttpRequest], str] = ""
    target: str = DEFAULT_DIALOG_TARGET
    swap: str = "innerHTML"
    confirm: str = ""
    confirm_style: str = "modal"
    pk_field: str = DEFAULT_BULK_PK_NAME
    variant: str = "btn-ghost-secondary"
    permission: Optional[str | Callable[[HttpRequest], bool]] = None
    visible: Optional[Callable[[HttpRequest], bool]] = None
    weight: int = 100
    extra_attrs: dict[str, str] = field(default_factory=dict)

    def resolve_url(self, request: HttpRequest) -> str:
        return self.url(request) if callable(self.url) else str(self.url)

    def is_allowed(self, request: HttpRequest) -> bool:
        """Return True if this action should render for ``request``.

        Combines ``permission`` (Django perm string or callable) and
        ``visible`` (callable). Both must pass. Missing ``request.user``
        or anonymous user is treated as unauthenticated.
        """
        perm = self.permission
        if perm is not None:
            if callable(perm):
                if not perm(request):
                    return False
            else:
                user = getattr(request, "user", None)
                if user is None or not user.has_perm(perm):
                    return False
        if self.visible is not None and not self.visible(request):
            return False
        return True

    def render_attrs(self, request: HttpRequest) -> dict[str, str]:
        """Build the HTML attribute dict for this action's button.

        Always emits ``hx-include="[name='{pk_field}']:checked"`` so
        every checked selection-checkbox in the surrounding form is
        forwarded with the request.
        """
        attrs: dict[str, str] = {
            "class": f"btn btn-sm {self.variant}".strip(),
            "title": str(self.label),
            "hx-include": f"[name='{self.pk_field}']:checked",
        }
        url = self.resolve_url(request)

        if self.confirm and self.confirm_style == "modal":
            # Modal-based confirm: GET the confirm URL into the dialog,
            # forwarding the checked pks as query parameters. The modal
            # form then POSTs back to the same URL with the pks as
            # hidden inputs to perform the action.
            attrs["hx-get"] = url
            attrs["hx-target"] = self.target
            attrs["hx-swap"] = self.swap
        else:
            attrs["hx-post"] = url
            attrs["hx-swap"] = "none"
            if self.confirm and self.confirm_style == "inline":
                attrs["hx-confirm"] = str(self.confirm)

        attrs.update({k: str(v) for k, v in self.extra_attrs.items()})
        return attrs


class IBulkAction(Interface):
    """GDAPS interface for pluggable bulk actions.

    Implementations attach to a named menu slot. Views that pass
    ``bulk_actions_menu`` to :func:`get_bulk_actions` pick up all
    plugins whose ``menu`` matches and render the returned
    :class:`BulkAction`s additionally to the consumer's hard-coded
    ``bulk_actions`` list.

    Attributes:
        menu: Slot name this action attaches to.
        weight: Sort weight among actions in the same slot (ascending).
    """

    menu: str = ""
    weight: int = 100

    def to_bulk_action(
        self, request: HttpRequest
    ) -> Optional[BulkAction]:  # pragma: no cover - interface
        raise NotImplementedError


def get_bulk_actions(
    request: HttpRequest,
    actions: Iterable[BulkAction] = (),
    menu: str = "",
) -> list[BulkAction]:
    """Return the ordered, permission-filtered bulk actions for ``request``.

    Combines a consumer-provided iterable with any :class:`IBulkAction`
    plugins whose ``menu`` matches ``menu`` (empty means no plugin
    discovery), filters by ``is_allowed``, and sorts by ``weight``.
    """
    combined: list[BulkAction] = list(actions)
    if menu:
        for plugin_cls in IBulkAction.enabled_plugins():
            if getattr(plugin_cls, "menu", "") != menu:
                continue
            plugin = plugin_cls()
            action = plugin.to_bulk_action(request)
            if action is None:
                continue
            if action.weight == 100 and getattr(plugin_cls, "weight", 100) != 100:
                action = replace(action, weight=plugin_cls.weight)
            combined.append(action)
    combined = [a for a in combined if a.is_allowed(request)]
    combined.sort(key=lambda a: a.weight)
    return combined
