"""Reusable Channels consumers.

:class:`ModelConsumer` is the canonical base for "render an HTML
fragment to a per-user/per-object channel group on every model change"
flows — typed for HTMX's ``ws`` extension and OOB swaps. Subclass it
instead of re-implementing the same boilerplate per plugin.
"""

import json

from asgiref.sync import async_to_sync
from channels.generic.websocket import WebsocketConsumer

from django.db import models
from django.template.loader import get_template


class ModelConsumer(WebsocketConsumer):
    """Base consumer that broadcasts model updates as HTML to a channel group.

    Subclasses set ``model`` and ``template_name``. The default group name is
    the model's ``verbose_name``; override :meth:`get_group_name` to scope the
    group per user or per object. Override :meth:`get_template_context` to
    customize what the template receives (e.g. fetch fresh data instead of
    relying on the serialized instance payload sent by the signal).
    """

    model: type[models.Model] = None
    template_name: str = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.model:
            raise AttributeError(
                f"{self.__class__.__name__} needs a 'model' attribute."
            )
        if not self.template_name:
            raise AttributeError(
                f"{self.__class__.__name__} needs a 'template_name' attribute."
            )

    def get_group_name(self) -> str:
        return str(self.model._meta.verbose_name)

    def get_template_context(self, event: dict) -> dict:
        """Build the template context for a ``model.updated`` event.

        The default unpacks the serialized instance payload. The ``data``
        field is what a sender (e.g. a ``post_save`` signal) put on the
        channel-layer message — typically a Django ``serialize("json", ...)``
        string, which is a list with a single ``{pk, model, fields}`` dict.
        """
        payload = json.loads(event["data"])[0]
        return {"pk": payload["pk"], **payload["fields"]}

    def connect(self):
        self.group_name = self.get_group_name()
        async_to_sync(self.channel_layer.group_add)(self.group_name, self.channel_name)
        self.accept()

    def disconnect(self, code):
        # ``connect()`` may have been rejected (e.g. unauthenticated user),
        # in which case ``group_name`` was never set. Guard against that.
        group_name = getattr(self, "group_name", None)
        if group_name and self.channel_layer is not None:
            async_to_sync(self.channel_layer.group_discard)(
                group_name, self.channel_name
            )

    def model_updated(self, event):
        context = self.get_template_context(event)
        html = get_template(self.template_name).render(context)
        self.send(text_data=html)
