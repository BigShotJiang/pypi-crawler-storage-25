"""Download conjunto's third-party JS/CSS libraries into the consumer project's
static folder.

Conjunto's wheel ships only its own first-party assets. Every consumer
project (medspeak, medux, …) runs this command to fetch the bulk of
the JS/CSS deps from upstream registries (npm, jsDelivr, unpkg) into a
local directory that's added to ``STATICFILES_DIRS``.

Typical bootstrap:

    $ python manage.py update_libraries --suggest   # → CONJUNTO_LIBRARIES = [...]
    # paste into settings.py
    $ python manage.py update_libraries             # download what's listed
    $ python manage.py collectstatic --noinput

Run with ``--check`` from CI to verify the static tree is populated
before running the build, without touching the network.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from django.apps import apps
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from conjunto._vendor.registry import (
    CORE_LIBRARIES,
    LIBRARIES,
    download_library,
    is_library_present,
    suggest_libraries,
)


def _resolve_dest() -> Path:
    """Resolve the per-project vendor directory.

    Order:
      1. ``settings.CONJUNTO_VENDOR_DIR`` if set.
      2. ``Path(STATICFILES_DIRS[0]) / "conjunto"`` as a fallback.
      3. Hard error otherwise — the consumer needs to make a choice.
    """
    explicit = getattr(settings, "CONJUNTO_VENDOR_DIR", None)
    if explicit:
        return Path(explicit)
    static_dirs = getattr(settings, "STATICFILES_DIRS", None) or []
    if static_dirs:
        first = static_dirs[0]
        # Each entry can be either a path or a (prefix, path) tuple.
        if isinstance(first, (tuple, list)):
            first = first[1]
        return Path(first) / "conjunto"
    raise CommandError(
        "Cannot determine where to place vendored libraries. "
        "Set CONJUNTO_VENDOR_DIR or add an entry to STATICFILES_DIRS."
    )


def _collect_template_dirs() -> list[Path]:
    """All directories that ``--suggest`` should scan."""
    dirs: list[Path] = []
    for cfg in apps.get_app_configs():
        candidate = Path(cfg.path) / "templates"
        if candidate.exists():
            dirs.append(candidate)
    for tmpl in getattr(settings, "TEMPLATES", ()):
        for d in tmpl.get("DIRS", ()):
            dirs.append(Path(d))
    for entry in getattr(settings, "STATICFILES_DIRS", ()):
        if isinstance(entry, (tuple, list)):
            entry = entry[1]
        # STATICFILES_DIRS aren't template roots, but consumer projects
        # sometimes co-locate small fragments under static/. Cheap to scan.
        path = Path(entry)
        if path.exists():
            dirs.append(path)
    return dirs


def _format_python_list(items: list[str]) -> str:
    """Pretty-print a sorted Python list literal for copy-paste into settings.py."""
    if not items:
        return "[]"
    inner = "\n".join(f'    "{item}",' for item in items)
    return f"[\n{inner}\n]"


class Command(BaseCommand):
    help = (
        "Download conjunto's third-party JS/CSS libraries into the "
        "consumer project's static folder (see docs/usage/static_libraries.md)."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "library",
            nargs="*",
            help=f"Specific libraries to (re-)download. Available: {sorted(LIBRARIES)}.",
        )
        parser.add_argument(
            "--all",
            action="store_true",
            help="Download every library known to the registry.",
        )
        parser.add_argument(
            "--list",
            action="store_true",
            help="Print the registry (name + version) and exit.",
        )
        parser.add_argument(
            "--suggest",
            action="store_true",
            help=(
                # `%` must be escaped as `%%` — argparse runs the help string
                # through `% action.__dict__`, and Python 3.14's _check_help
                # validates this at add_argument() time. argparse renders
                # `%%` back to `%` when displaying.
                "Scan project templates for {%% conjunto_require_X %%} and "
                "{%% static 'conjunto/...' %%} references and print a "
                "ready-to-paste CONJUNTO_LIBRARIES = [...] block. "
                "Does not download anything."
            ),
        )
        parser.add_argument(
            "--check",
            action="store_true",
            help=(
                "Verify (no network) that every expected library file "
                "exists in the destination. Exits 1 on missing files. "
                "Use this as a CI / pre-deploy guard."
            ),
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Re-download even if files already exist.",
        )
        parser.add_argument(
            "--dest",
            help=(
                "Override the destination directory for this run. "
                "Defaults to settings.CONJUNTO_VENDOR_DIR (or "
                "STATICFILES_DIRS[0]/conjunto)."
            ),
        )

    # ── Subcommands ──────────────────────────────────────────────────

    def _handle_list(self) -> None:
        self.stdout.write("Available libraries:")
        for name in LIBRARIES:
            entry = LIBRARIES[name]
            kind = "tarball" if isinstance(entry, dict) else "files"
            self.stdout.write(f"  {name:18s}  ({kind})")

    def _handle_suggest(self) -> None:
        suggested = suggest_libraries(_collect_template_dirs())
        ordered = sorted(suggested)
        configured = list(getattr(settings, "CONJUNTO_LIBRARIES", []) or [])
        self.stdout.write("Detected libraries from your templates:")
        self.stdout.write(self.style.SUCCESS(""))
        self.stdout.write(
            self.style.SUCCESS(
                f"    CONJUNTO_LIBRARIES = {_format_python_list(ordered)}"
            )
        )
        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS("Copy the block above into settings.py."))
        if configured:
            missing = sorted(set(ordered) - set(configured))
            extra = sorted(set(configured) - set(ordered))
            if missing:
                self.stdout.write("")
                self.stdout.write(
                    self.style.WARNING(
                        f"Currently MISSING from CONJUNTO_LIBRARIES: {missing}"
                    )
                )
            if extra:
                self.stdout.write(
                    self.style.NOTICE(
                        f"Currently configured but not detected in templates: {extra} "
                        "(may still be needed for code-level use)."
                    )
                )

    def _handle_check(self, dest: Path, libs: list[str]) -> int:
        any_missing = False
        for lib in libs:
            ok, missing = is_library_present(lib, dest)
            if ok:
                self.stdout.write(self.style.SUCCESS(f"[{lib}] OK"))
            else:
                any_missing = True
                self.stdout.write(self.style.ERROR(f"[{lib}] MISSING:"))
                for rel in missing:
                    self.stdout.write(f"    {dest / rel}")
        if any_missing:
            self.stdout.write("")
            self.stdout.write(
                self.style.ERROR(
                    "Run `python manage.py update_libraries` to fetch them."
                )
            )
            return 1
        return 0

    def _handle_download(
        self,
        dest: Path,
        libs: list[str],
        *,
        force: bool,
    ) -> int:
        dest.mkdir(parents=True, exist_ok=True)
        failed: list[str] = []
        for name in libs:
            if name not in LIBRARIES:
                self.stderr.write(f"Unknown library: {name}")
                failed.append(name)
                continue
            if not force:
                ok, _missing = is_library_present(name, dest)
                if ok:
                    self.stdout.write(
                        f"[{name}] already present, skipping (use --force to refresh)"
                    )
                    continue
            self.stdout.write(self.style.MIGRATE_HEADING(f"[{name}]"))
            if not download_library(name, dest):
                failed.append(name)
        if failed:
            self.stderr.write(self.style.ERROR(f"\nFailed: {failed}"))
            return 1
        return 0

    def _print_suggest_diff(self, libs_used: list[str]) -> None:
        """After a download, run a suggest-scan and warn if templates need more."""
        try:
            suggested = suggest_libraries(_collect_template_dirs())
        except Exception:  # pragma: no cover — never fail the command on suggest
            return
        missing = sorted(suggested - set(libs_used))
        if not missing:
            return
        self.stdout.write("")
        self.stdout.write(
            self.style.WARNING(
                f"Templates suggest you also need: {missing}\n"
                "Update CONJUNTO_LIBRARIES in settings.py and re-run."
            )
        )

    # ── Dispatch ─────────────────────────────────────────────────────

    def handle(self, *args: Any, **options: Any) -> None:
        if options["list"]:
            self._handle_list()
            return
        if options["suggest"]:
            self._handle_suggest()
            return

        # Resolve destination once for download / check.
        dest = Path(options["dest"]) if options.get("dest") else _resolve_dest()

        # Determine which libraries to process.
        if options["all"]:
            libs = list(LIBRARIES)
        elif options["library"]:
            libs = list(options["library"])
        else:
            configured = getattr(settings, "CONJUNTO_LIBRARIES", None)
            if configured:
                libs = list(configured)
            else:
                libs = sorted(CORE_LIBRARIES)
                self.stdout.write(
                    self.style.NOTICE(
                        f"CONJUNTO_LIBRARIES not set — falling back to core "
                        f"{libs}. Run `python manage.py update_libraries "
                        f"--suggest` for a tailored list."
                    )
                )

        if options["check"]:
            sys.exit(self._handle_check(dest, libs))

        rc = self._handle_download(dest, libs, force=options["force"])
        # Always run the suggest-scan after a download — the user
        # explicitly asked for "suggest sollte immer gemacht werden,
        # für settings.py".
        if not options["library"] and not options["all"]:
            self._print_suggest_diff(libs)
        if rc:
            sys.exit(rc)
