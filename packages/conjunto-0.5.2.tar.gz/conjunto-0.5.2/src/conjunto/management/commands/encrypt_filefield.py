"""Bulk-migrate a model's plain FileField rows to EncryptedFileField.

Usage::

    python manage.py encrypt_filefield <app_label>.<ModelName> <field_name>

Run **after** changing the field type in ``models.py`` to
:class:`conjunto.fields.EncryptedFileField` and running
``makemigrations`` / ``migrate`` (which adds the companion
``<field_name>_manifest`` BinaryField).

The command is idempotent: rows with a non-null manifest are skipped,
so re-running after a partial failure is safe.
"""

from __future__ import annotations

from django.apps import apps
from django.core.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = (
        "Re-encrypt existing plain files in place for a given "
        "EncryptedFileField. Idempotent; safe to re-run."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "model",
            help="Target model, as 'app_label.ModelName'.",
        )
        parser.add_argument(
            "field",
            help="Name of the EncryptedFileField on the model.",
        )
        parser.add_argument(
            "--batch-size",
            type=int,
            default=100,
            help="DB chunk size for the iterator (default: 100).",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Report what would be done; touch nothing.",
        )
        parser.add_argument(
            "--keep-originals",
            action="store_true",
            help="Do not delete plain files after successful re-encrypt.",
        )
        parser.add_argument(
            "--tenant-id",
            default=None,
            help="Restrict to a single tenant id (default: all tenants).",
        )
        parser.add_argument(
            "--upload-to-prefix",
            default=None,
            help=(
                "Override the directory prefix for new files. "
                "Default: reuse the original file's directory. Typical use: "
                "'<tenant_slug>/<plugin>/<sub>' to match the protected-media "
                "tenant-slug convention."
            ),
        )

    def handle(self, *args, **opts):
        from conjunto.files.encryption import migrate_to_encrypted

        try:
            app_label, model_name = opts["model"].split(".", 1)
        except ValueError:
            raise CommandError(
                "model must be 'app_label.ModelName' (got %r)" % opts["model"]
            )
        try:
            model = apps.get_model(app_label, model_name)
        except LookupError as exc:
            raise CommandError(str(exc)) from exc

        field_name = opts["field"]
        try:
            model._meta.get_field(field_name)
        except Exception as exc:
            raise CommandError(
                f"{model.__name__} has no field {field_name!r}: {exc}"
            ) from exc

        def _progress(obj, *, dry_run: bool):
            self.stdout.write(
                f"  {'WOULD encrypt' if dry_run else 'encrypted'} "
                f"{model.__name__} pk={obj.pk}"
            )

        self.stdout.write(
            f"Encrypting {model._meta.label}.{field_name} "
            f"(batch_size={opts['batch_size']}, "
            f"dry_run={opts['dry_run']}, "
            f"keep_originals={opts['keep_originals']})…"
        )

        counters = migrate_to_encrypted(
            model,
            field_name,
            batch_size=opts["batch_size"],
            dry_run=opts["dry_run"],
            keep_originals=opts["keep_originals"],
            tenant_id=opts["tenant_id"],
            upload_to_prefix=opts["upload_to_prefix"],
            progress=_progress,
        )

        self.stdout.write(
            self.style.SUCCESS(
                f"Done. processed={counters['processed']} "
                f"skipped={counters['skipped']} errors={counters['errors']}"
            )
        )
        if counters["errors"]:
            raise CommandError(
                f"{counters['errors']} row(s) failed — see log for details."
            )
