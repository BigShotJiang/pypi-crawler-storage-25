"""GDAPS interfaces for tenant lifecycle hooks.

Plugins implement :class:`ITenantLifecycle` to contribute idempotent
per-tenant initialization (default master data, seed accounts, …) that
must run whenever a tenant is created or back-filled.

The interface is invoked from two places:

- :mod:`conjunto.tenants.signals` — ``post_save`` handler that fires
  ``setup_tenant`` for every newly created tenant.
- ``conjunto.tenants.management.commands.setup_tenant`` — admin tool to
  re-run the lifecycle hooks for one or more existing tenants
  (idempotent by contract).

Forward-compatibility plan: this interface is intentionally **never
subclassed**. Future hooks (e.g. ``teardown_tenant``) are added here
directly with a no-op default so existing implementers are not broken.
"""

from __future__ import annotations

from gdaps.api import Interface


class ITenantLifecycle(Interface):
    """Per-tenant lifecycle hooks contributed by plugins.

    Implementations live in their plugin (e.g.
    ``medux/plugins/cashbook/lifecycle.py``) and must be imported at
    Django startup — typically via ``AppConfig.ready()``::

        def ready(self):
            from . import lifecycle  # noqa: F401

    Hooks are **classmethods** and receive the tenant instance directly,
    so no plugin state crosses the boundary.

    Implementations MUST be idempotent: a second invocation for the same
    tenant must be a no-op. Use ``get_or_create`` /
    ``update_or_create`` rather than ``create``. The signal handler and
    the ``setup_tenant`` management command both rely on this guarantee.

    Hooks MUST also be defensive towards their own failures: a plugin
    that raises in ``setup_tenant`` will be caught by the calling
    signal/command, logged via :mod:`logging.exception`, and skipped —
    other implementers continue to run, and the tenant ``post_save``
    transaction completes regardless.
    """

    __sort_attribute__ = "weight"
    __instantiate_plugins__ = False

    weight: int = 100
    """Sort weight; lower runs first. Default 100 — most plugins keep it."""

    @classmethod
    def setup_tenant(cls, tenant) -> None:
        """Initialize per-tenant data for ``tenant``.

        Called once after a new tenant has been created (via
        :class:`~conjunto.tenants.signals.tenant_created` ``post_save``)
        and re-runnably from the ``setup_tenant`` management command.

        Idempotency contract: a second invocation for the same
        ``tenant`` is a no-op. Implementations typically use
        :meth:`~django.db.models.QuerySet.get_or_create` /
        :meth:`~django.db.models.QuerySet.update_or_create` and never
        ``create`` blindly.

        Default: no-op. Implementations override.
        """
