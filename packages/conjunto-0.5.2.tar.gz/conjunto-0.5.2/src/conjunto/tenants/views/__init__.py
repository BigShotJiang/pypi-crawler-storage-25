"""Tenant switch endpoint.

A POST-only endpoint that persists the user's tenant selection in the
session.  The choice is stored in ``request.session["cj_tenant_id"]``
and :class:`conjunto.middleware.ConjuntoMiddleware` picks it up as the
last fallback when binding the tenant ContextVar on every subsequent
request.

The actual tenant picker UI is rendered inline in the statusbar via the
``{% tenant_badge %}`` template tag (a Bootstrap dropup).
"""

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.utils.http import url_has_allowed_host_and_scheme
from django.utils.translation import gettext_lazy as _
from django.views.generic import View

from conjunto.tenants.utils import get_allowed_tenants


SESSION_KEY = "cj_tenant_id"


class TenantPickView(LoginRequiredMixin, View):
    """Persist a tenant selection in the session (POST only)."""

    http_method_names = ["post"]

    def _allowed_tenants(self, request):
        return get_allowed_tenants(request)

    def _safe_next(self, request, candidate):
        if candidate and url_has_allowed_host_and_scheme(
            url=candidate,
            allowed_hosts={request.get_host()},
            require_https=request.is_secure(),
        ):
            return candidate
        return "/"

    def post(self, request):
        raw = request.POST.get("tenant", "")
        next_url = self._safe_next(request, request.POST.get("next", ""))

        if raw == "":
            messages.error(request, _("Invalid tenant selection."))
            return self._respond(request, fallback=reverse("tenants:pick"))

        allowed = self._allowed_tenants(request)
        try:
            tenant_pk = int(raw)
        except (TypeError, ValueError):
            messages.error(request, _("Invalid tenant selection."))
            return self._respond(request, fallback=reverse("tenants:pick"))

        tenant = allowed.filter(pk=tenant_pk).first()
        if tenant is None:
            messages.error(request, _("You are not allowed to pick this tenant."))
            return self._respond(request, fallback=reverse("tenants:pick"))

        old_tenant_id = request.session.get(SESSION_KEY)
        request.session[SESSION_KEY] = tenant.pk
        if old_tenant_id != tenant.pk:
            from conjunto.tenants.signals import tenant_switched

            tenant_switched.send(
                sender=self.__class__,
                request=request,
                user=request.user,
                old_tenant_id=old_tenant_id,
                new_tenant_id=tenant.pk,
            )
        messages.success(
            request,
            _("Switched to tenant %(name)s.") % {"name": tenant.name},
        )
        return self._respond(request, fallback=next_url)

    def _respond(self, request, fallback="/"):
        """Return an HTMX-aware response.

        HTMX callers get a 204 with ``HX-Refresh: true`` so the page
        reloads under the new tenant context.  Non-HTMX callers get a
        regular redirect.
        """
        if getattr(request, "htmx", False):
            response = HttpResponse(status=204)
            response["HX-Refresh"] = "true"
            return response
        return HttpResponseRedirect(fallback)
