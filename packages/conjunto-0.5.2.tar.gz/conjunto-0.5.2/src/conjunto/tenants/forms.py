"""Forms for tenant-scoped permission management.

Provides forms for:

- **Role CRUD**: :class:`TenantRoleForm` for creating/editing
  :class:`~conjunto.tenants.models.TenantRole` instances with a
  grouped permission widget.
- **User CRUD**: :class:`TenantUserCreateForm` for creating users
  within a tenant, :class:`TenantUserEditForm` for editing user
  details.
- **Role assignment**: :class:`UserRolesForm` for assigning/revoking
  tenant-scoped roles on a single user.
"""

from __future__ import annotations

from collections import defaultdict

from crispy_forms.helper import FormHelper
from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm as DjangoUserCreationForm
from django.contrib.auth.models import Permission
from django.db import transaction
from django.utils.translation import gettext_lazy as _

from conjunto.tenants.models import TenantMembership, TenantRole

User = get_user_model()


# ---------------------------------------------------------------------------
# Grouped permission widget
# ---------------------------------------------------------------------------


class GroupedPermissionWidget(forms.CheckboxSelectMultiple):
    """A CheckboxSelectMultiple that renders permissions grouped by app > model.

    The template ``conjunto/tenants/_permission_widget.html`` receives
    ``widget.grouped_choices`` — a list of
    ``(app_label, [(model_verbose, [(pk, codename, verb, checked), ...])])``.
    """

    template_name = "conjunto/tenants/_permission_widget.html"

    def __init__(self, *args, system_permission_pks=None, **kwargs):
        super().__init__(*args, **kwargs)
        # PKs of permissions that come from AppConfig declarations and
        # should be rendered as disabled (checked but not toggleable).
        self.system_permission_pks = set(system_permission_pks or [])

    def get_context(self, name, value, attrs):
        ctx = super().get_context(name, value, attrs)
        # Build grouped structure for the template.
        value_set = set(str(v) for v in (value or []))
        grouped: dict[str, dict[str, list]] = defaultdict(lambda: defaultdict(list))

        for pk, label in self.choices:
            try:
                perm = Permission.objects.select_related("content_type").get(pk=pk)
            except Permission.DoesNotExist:
                continue
            ct = perm.content_type
            app_label = ct.app_label
            model_cls = ct.model_class()
            model_verbose = (
                model_cls._meta.verbose_name.title() if model_cls else ct.model
            )
            model_name = ct.model
            codename = perm.codename
            if codename.endswith(f"_{model_name}"):
                verb = codename[: -(len(model_name) + 1)]
            else:
                verb = codename
            checked = str(pk) in value_set
            is_system = pk in self.system_permission_pks
            grouped[app_label][model_verbose].append(
                {
                    "pk": pk,
                    "verb": verb,
                    "checked": checked,
                    "is_system": is_system,
                    "name": name,
                }
            )

        # Sort for deterministic rendering.
        grouped_sorted = []
        for app in sorted(grouped):
            models = []
            for model in sorted(grouped[app]):
                perms = sorted(grouped[app][model], key=lambda p: p["verb"])
                models.append((model, perms))
            grouped_sorted.append((app, models))

        ctx["widget"]["grouped_choices"] = grouped_sorted
        return ctx


# ---------------------------------------------------------------------------
# Role forms
# ---------------------------------------------------------------------------


class TenantRoleForm(forms.ModelForm):
    """Form for creating or editing a :class:`TenantRole`.

    For system roles the ``name`` field is readonly and AppConfig-declared
    permissions are rendered as disabled checkboxes via
    :class:`GroupedPermissionWidget`.
    """

    class Meta:
        model = TenantRole
        fields = ["name", "label", "description", "permissions"]

    def __init__(self, *args, tenant=None, **kwargs):
        self.tenant = tenant
        super().__init__(*args, **kwargs)

        instance = self.instance

        # Build system permission PKs for the widget.
        system_pks = set()
        if instance and instance.pk and instance.is_system:
            from conjunto.tenants.roles import get_flat_schema

            schema = get_flat_schema()
            schema_perms = schema.get(instance.name, {})
            system_pks = self._resolve_permission_pks(schema_perms)
            # Make name readonly for system roles.
            self.fields["name"].disabled = True

        self.fields["permissions"].widget = GroupedPermissionWidget(
            system_permission_pks=system_pks,
        )
        self.fields["permissions"].queryset = Permission.objects.select_related(
            "content_type"
        ).order_by("content_type__app_label", "content_type__model", "codename")

        # For system roles, pre-select the system permissions.
        if system_pks and not self.is_bound:
            current = set(self.initial.get("permissions", []))
            self.initial["permissions"] = list(current | system_pks)

        self.helper = FormHelper(self)
        self.helper.form_tag = False

    def save(self, commit=True):
        instance = super().save(commit=False)
        if self.tenant:
            instance.tenant = self.tenant
        if commit:
            instance.save()
            self.save_m2m()
        return instance

    @staticmethod
    def _resolve_permission_pks(schema_perms: dict) -> set[int]:
        """Resolve a ``{model_ref: [verb, ...]}`` map to a set of Permission PKs."""
        from django.apps import apps
        from django.contrib.contenttypes.models import ContentType

        pks = set()
        for model_ref, verbs in schema_perms.items():
            try:
                if isinstance(model_ref, str):
                    app_label, model_name = model_ref.rsplit(".", 1)
                    model = apps.get_model(app_label, model_name)
                else:
                    model = model_ref
                ct = ContentType.objects.get_for_model(model)
            except (LookupError, ContentType.DoesNotExist):
                continue
            for verb in verbs:
                codename = f"{verb}_{ct.model}"
                try:
                    perm = Permission.objects.get(content_type=ct, codename=codename)
                    pks.add(perm.pk)
                except Permission.DoesNotExist:
                    continue
        return pks


# ---------------------------------------------------------------------------
# User forms
# ---------------------------------------------------------------------------


class TenantUserCreateForm(DjangoUserCreationForm):
    """Form for creating a new user within a tenant context.

    Adds an optional ``roles`` field so the admin can assign initial
    roles at creation time.
    """

    roles = forms.ModelMultipleChoiceField(
        queryset=TenantRole.objects.none(),
        required=False,
        widget=forms.CheckboxSelectMultiple,
        label=_("Initial roles"),
    )

    class Meta:
        model = User
        fields = [
            "username",
            "first_name",
            "last_name",
            "email",
        ]

    def __init__(self, *args, tenant=None, **kwargs):
        self.tenant = tenant
        super().__init__(*args, **kwargs)
        if tenant:
            self.fields["roles"].queryset = TenantRole.objects.filter(
                tenant=tenant
            ).order_by("name")
        self.helper = FormHelper(self)
        self.helper.form_tag = False

    @transaction.atomic
    def save(self, commit=True):
        user = super().save(commit=False)
        user.is_staff = True
        if commit:
            user.save()
            # Create TenantMembership for each selected role.
            selected_roles = self.cleaned_data.get("roles", [])
            if selected_roles:
                for role in selected_roles:
                    TenantMembership.objects.get_or_create(
                        user=user, tenant=self.tenant, role=role.name
                    )
            elif self.tenant:
                # No roles selected — create a base "user" membership
                # so the user appears in the tenant's user list. Fall
                # back to first available role if no "user" role exists.
                base_role = TenantRole.objects.filter(
                    tenant=self.tenant, name="user"
                ).first()
                if base_role is None:
                    base_role = (
                        TenantRole.objects.filter(tenant=self.tenant)
                        .order_by("name")
                        .first()
                    )
                if base_role:
                    TenantMembership.objects.get_or_create(
                        user=user, tenant=self.tenant, role=base_role.name
                    )
        return user


class TenantUserEditForm(forms.ModelForm):
    """Form for editing an existing user's basic details within a tenant."""

    class Meta:
        model = User
        fields = ["first_name", "last_name", "email", "is_active"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.form_tag = False


# ---------------------------------------------------------------------------
# User-role assignment form
# ---------------------------------------------------------------------------


class UserRolesForm(forms.Form):
    """Multi-choice form for assigning/revoking a user's tenant-scoped roles.

    The choices are sourced from :class:`TenantRole` records rather than
    the raw AppConfig schema, so custom roles are included.
    """

    roles = forms.MultipleChoiceField(
        label=_("Roles"),
        required=False,
        widget=forms.CheckboxSelectMultiple,
    )

    def __init__(self, *args, target_user, tenant, **kwargs):
        self.target_user = target_user
        self.tenant = tenant
        initial = kwargs.setdefault("initial", {})
        initial.setdefault("roles", self._current_roles())
        super().__init__(*args, **kwargs)
        self.fields["roles"].choices = [
            (r.name, r.label)
            for r in TenantRole.objects.filter(tenant=tenant).order_by("name")
        ]
        self.helper = FormHelper(self)
        self.helper.form_tag = False

    def _current_roles(self) -> list[str]:
        return list(
            self.target_user.tenant_memberships.filter(tenant=self.tenant)
            .order_by("role")
            .values_list("role", flat=True)
        )

    @transaction.atomic
    def save(self) -> None:
        """Sync TenantMembership rows to match the submitted selection."""
        desired = set(self.cleaned_data["roles"])
        current = set(self._current_roles())

        for role in desired - current:
            TenantMembership.objects.create(
                user=self.target_user, tenant=self.tenant, role=role
            )
        for role in current - desired:
            for membership in TenantMembership.objects.filter(
                user=self.target_user, tenant=self.tenant, role=role
            ):
                membership.delete()
