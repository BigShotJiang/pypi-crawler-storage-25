"""Tenant lifecycle signal wiring.

Connects a defensive ``post_save`` handler on the swappable tenant
model that walks every :class:`~conjunto.tenants.interfaces.ITenantLifecycle`
implementer and runs ``setup_tenant`` on it. Plugin failures are caught
and logged — they MUST never block tenant creation.

Also connects a ``post_migrate`` handler on the ``conjunto_tenants``
app that seeds an ``Admin`` tenant if none exists, so
``createsuperuser`` always has a target for the ``User.tenant`` FK.
"""

from __future__ import annotations

import logging

from django.apps import apps
from django.conf import settings
from django.db.models.signals import post_migrate, post_save
from django.dispatch import Signal, receiver

from .interfaces import ITenantLifecycle
from .utils import get_tenant_model

logger = logging.getLogger(__name__)


tenant_switched = Signal()
"""Emitted after a user switches their active tenant in the session.

Receivers get the keyword arguments:

- ``sender`` — the view class that performed the switch.
- ``request`` — the current ``HttpRequest`` (so listeners can mutate
  ``request.session``).
- ``user`` — the authenticated user.
- ``old_tenant_id`` — the previous tenant pk, or ``None`` on first pick.
- ``new_tenant_id`` — the freshly selected tenant pk.

Listeners must clear any session state that was bound to the previous
tenant (e.g. patient selection, scope caches) — defense in depth even
when the underlying lookup is tenant-scoped server-side.
"""


def _tenant_model_label() -> str:
    """Return the swappable tenant model label.

    Defaults to ``conjunto_tenants.Tenant`` when ``CONJUNTO_TENANT_MODEL``
    is not configured (matches the default installed by
    :mod:`conjunto.tenants.__init__`).
    """
    return getattr(settings, "CONJUNTO_TENANT_MODEL", "conjunto_tenants.Tenant")


def run_tenant_lifecycle(tenant) -> list[tuple[type, BaseException | None]]:
    """Invoke every :class:`ITenantLifecycle` implementer for ``tenant``.

    Returns a list of ``(implementer_class, error_or_None)`` tuples, one
    per implementer, in iteration order. Errors are caught and logged
    via :func:`logging.Logger.exception`; they never propagate.
    """
    results: list[tuple[type, BaseException | None]] = []
    for impl in ITenantLifecycle:
        try:
            impl.setup_tenant(tenant)
        except Exception as exc:  # noqa: BLE001 — defensive boundary
            logger.exception(
                "ITenantLifecycle.%s.setup_tenant failed for tenant %r",
                impl.__name__,
                getattr(tenant, "pk", "<unknown>"),
            )
            results.append((impl, exc))
        else:
            results.append((impl, None))
    return results


@receiver(post_save, dispatch_uid="conjunto_tenants_setup_tenant")
def _on_tenant_post_save(sender, instance, created, **kwargs):
    """Run :class:`ITenantLifecycle` hooks for newly created tenants.

    ``post_save`` fires for every model in the project, so we filter on
    ``sender`` against the swappable tenant model and ignore updates.
    """
    try:
        tenant_model = apps.get_model(_tenant_model_label())
    except (LookupError, ValueError):
        return
    if sender is not tenant_model:
        return
    if not created:
        return
    run_tenant_lifecycle(instance)


@receiver(
    post_save,
    sender=settings.AUTH_USER_MODEL,
    dispatch_uid="conjunto_tenants_home_membership",
)
def _create_home_membership(sender, instance, created, **kwargs):
    """Auto-create a TenantMembership for the user's home tenant.

    The FK names the tenant; RBAC routes through Memberships, so the
    new user needs a Membership(home_tenant, role=user) to actually
    have permissions in their own tenant. Idempotent via
    ``get_or_create``.
    """
    if not created:
        return
    from conjunto.conf import get_default_user_role
    from conjunto.tenants.models import TenantMembership

    role = get_default_user_role()
    TenantMembership.objects.get_or_create(
        user=instance,
        tenant=instance.tenant,
        role=role,
    )


@receiver(post_migrate, dispatch_uid="conjunto_tenants_seed_default")
def _seed_default_tenant(sender, **kwargs):
    """Ensure at least one tenant exists after migrate.

    Idempotent: skips when any tenant already exists. Slug ``admin``,
    name ``Admin`` — these are the seed defaults; project authors can
    rename / disable the tenant later.
    """
    if getattr(sender, "label", None) != "conjunto_tenants":
        return
    Tenant = get_tenant_model()
    if not Tenant.objects.exists():
        Tenant.objects.create(slug="admin", name="Admin", is_active=True)
