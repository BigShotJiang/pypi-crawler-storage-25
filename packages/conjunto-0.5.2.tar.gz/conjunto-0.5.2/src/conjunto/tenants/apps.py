from django.utils.translation import gettext_lazy as _
from gdaps import api


class TenantsConfig(api.PluginConfig):
    """GDAPS plugin providing the framework-level Tenant model.

    Conjunto ships an abstract + concrete swappable Tenant pair so
    consumer apps can either use the default ``conjunto_tenants.Tenant``
    or subclass :class:`AbstractTenant` and point
    ``CONJUNTO_TENANT_MODEL`` at their own model — exactly mirroring
    Django's ``AUTH_USER_MODEL`` pattern.
    """

    label = "conjunto_tenants"
    name = "conjunto.tenants"
    verbose_name = _("Tenants")

    #: Baseline tenant role template.
    #:
    #: The ``tenant_admin`` role is the default administration role for
    #: tenant-scoped user management.  It grants full CRUD on User,
    #: TenantMembership and TenantRole so that a tenant admin can
    #: manage users and their roles within the tenant autonomously.
    #: Consumer apps extend the role via their own
    #: ``AppConfig.tenant_role_permissions`` declarations.
    tenant_role_permissions = {
        "tenant_admin": {
            "permissions": {
                "auth.User": ["view", "add", "change", "delete"],
                "conjunto_tenants.TenantMembership": [
                    "view",
                    "add",
                    "change",
                    "delete",
                ],
                "conjunto_tenants.TenantRole": ["view", "add", "change", "delete"],
            },
        },
    }

    class PluginMeta:
        verbose_name = _("Tenants")
        author = "Christian González"
        author_email = "christian.gonzalez@nerdocs.at"
        description = _("Framework-level Tenant model (swappable).")
        version = "1.0.0"
        category = "Conjunto"
        obligatory = True

    def ready(self):
        # Import the post_save handler that fans out to every
        # ``ITenantLifecycle`` implementer when a new tenant is saved,
        # plus the ``post_migrate`` handler that seeds the default
        # ``Admin`` tenant when none exists.
        from . import signals  # noqa: F401
