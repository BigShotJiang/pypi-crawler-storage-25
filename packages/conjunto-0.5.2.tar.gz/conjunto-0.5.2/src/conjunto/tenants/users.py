"""Abstract User mixin: tenant FK + tenants property.

Combine with :class:`django.contrib.auth.models.AbstractUser` (or any
custom abstract user). The FK is **NOT NULL** -- the DB schema enforces
that every user has a home tenant; ``createsuperuser`` is bridged via
:class:`conjunto.tenants.managers.TenantAwareUserManagerMixin`, which
defaults the FK to the seed tenant when the caller does not supply one.

The ``tenants`` property returns the user's active memberships and
includes the home tenant -- the home Membership is auto-created by the
post_save signal in :mod:`conjunto.tenants.signals`.
"""

from __future__ import annotations

from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _


class TenantUserFKMixin(models.Model):
    """Adds ``tenant`` (NOT NULL FK) and ``tenants`` (property) to a User."""

    tenant = models.ForeignKey(
        settings.CONJUNTO_TENANT_MODEL,
        on_delete=models.PROTECT,
        related_name="primary_users",
        verbose_name=_("Home tenant"),
    )

    class Meta:
        abstract = True

    @property
    def tenants(self):
        """Active tenants this user has a TenantMembership in.

        Returns a queryset (lazy). Includes the home tenant -- the
        post_save signal creates a Membership(home_tenant, role=user)
        on user creation.
        """
        from conjunto.tenants.utils import get_tenant_model

        Tenant = get_tenant_model()
        return Tenant.objects.filter(
            memberships__user=self,
            is_active=True,
        ).distinct()
