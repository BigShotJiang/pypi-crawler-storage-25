"""Tenant-scoping managers for :class:`TenantModelMixin`.

Every queryset obtained from a tenant-scoped model's ``objects`` manager
is implicitly filtered to the tenant currently bound on the
:mod:`conjunto.tenants.context` ContextVar. Accessing ``objects`` with
no tenant bound raises :class:`TenantScopeMissing` — the contract is
deliberately loud so that Celery tasks, management commands and shell
sessions don't silently return empty querysets.

Escape hatches:

- Every tenant-scoped model also exposes an unscoped ``all_objects``
  manager (a plain :class:`~django.db.models.Manager`) for code that
  legitimately needs to cross tenants (backups, migrations, admin
  superuser views, global reports).
- Django's own internals (FK validation, cascade deletes, admin
  autocomplete, ``get_profile``-style reverse access) use
  ``_base_manager``, which is wired to ``all_objects`` via
  ``Meta.base_manager_name`` so those code paths are never tenant-
  filtered.
- :func:`conjunto.tenants.context.override_tenant` binds a tenant for
  the duration of a ``with`` block — the idiomatic way to run
  tenant-scoped code out of the HTTP request cycle.
"""

from django.core.management import CommandError
from django.db import models
from django.db.models import Q

from .context import get_current_tenant


class TenantScopeMissing(RuntimeError):
    """Raised when a tenant-scoped manager is used without a bound tenant."""


class TenantAwareUserManagerMixin:
    """UserManager mixin: defaults the ``tenant`` FK on user creation.

    ``manage.py createsuperuser`` does not prompt for FK-typed fields,
    so without this bridge the post_migrate-seeded ``Admin`` tenant
    would not get picked up and user creation would fail with an
    ``IntegrityError`` on the NOT NULL FK declared by
    :class:`conjunto.tenants.users.TenantUserFKMixin`.

    Mix into your project's UserManager:

    .. code-block:: python

        from django.contrib.auth.models import UserManager
        from conjunto.tenants.managers import TenantAwareUserManagerMixin

        class CommonUserManager(TenantAwareUserManagerMixin, UserManager):
            pass

    Both :meth:`create_user` and :meth:`create_superuser` are bridged:
    if no ``tenant`` keyword is supplied, the oldest active tenant
    (ordered by ``pk``) is used. If no active tenant exists at all,
    :class:`~django.core.management.CommandError` is raised so the
    operator gets a helpful hint to run ``migrate`` first.
    """

    def _get_seed_tenant(self):
        from conjunto.tenants.utils import get_tenant_model

        Tenant = get_tenant_model()
        seed = Tenant.objects.filter(is_active=True).order_by("pk").first()
        if seed is None:
            raise CommandError(
                "No tenant exists. Run `manage.py migrate` first to seed "
                "the default tenant before creating a superuser."
            )
        return seed

    def create_superuser(self, username, email=None, password=None, **extra):
        if "tenant" not in extra:
            extra["tenant"] = self._get_seed_tenant()
        return super().create_superuser(username, email, password, **extra)

    def create_user(self, username, email=None, password=None, **extra):
        if "tenant" not in extra:
            extra["tenant"] = self._get_seed_tenant()
        return super().create_user(username, email, password, **extra)


def _require_tenant(model):
    tenant = get_current_tenant()
    if tenant is None:
        raise TenantScopeMissing(
            f"{model.__name__} was accessed without a bound tenant. "
            f"Wrap the call in `conjunto.tenants.context.override_tenant(...)` "
            f"or use `{model.__name__}.all_objects` for an unscoped queryset."
        )
    return tenant


class TenantQuerySet(models.QuerySet):
    """QuerySet that injects the bound tenant on ``create``/``bulk_create``."""

    def create(self, **kwargs):
        if "tenant" not in kwargs and "tenant_id" not in kwargs:
            kwargs["tenant"] = _require_tenant(self.model)
        return super().create(**kwargs)

    def bulk_create(self, objs, *args, **kwargs):
        objs = list(objs)
        tenant = None
        for obj in objs:
            if getattr(obj, "tenant_id", None) is None:
                if tenant is None:
                    tenant = _require_tenant(self.model)
                obj.tenant = tenant
        return super().bulk_create(objs, *args, **kwargs)


class TenantManager(models.Manager.from_queryset(TenantQuerySet)):
    """Manager that auto-filters every queryset by the bound tenant.

    Raises :class:`TenantScopeMissing` when accessed with no tenant
    bound. Use the sibling ``all_objects`` manager (or
    :func:`~conjunto.tenants.context.override_tenant`) to opt out.
    """

    def get_queryset(self):
        tenant = _require_tenant(self.model)
        return super().get_queryset().filter(tenant=tenant)


class OptionalTenantQuerySet(models.QuerySet):
    """QuerySet for models where ``tenant`` is nullable.

    ``create``/``bulk_create`` do **not** auto-inject the current tenant —
    passing no tenant is a legitimate way to create a global row that
    is visible to every tenant.
    """


class OptionalTenantManager(models.Manager.from_queryset(OptionalTenantQuerySet)):
    """Like :class:`TenantManager`, but also surfaces global
    (``tenant IS NULL``) rows to every tenant.

    Unlike :class:`TenantManager`, accessing this manager with **no**
    tenant bound is *not* an error — it degrades gracefully to
    "global rows only" (``tenant IS NULL``). That matches the
    semantics of the ``Optional`` variant: the model is allowed to
    exist without a tenant at all, so a tenant-less caller is a
    legitimate state rather than a scoping bug.
    """

    def get_queryset(self):
        qs = super().get_queryset()
        tenant = get_current_tenant()
        if tenant is None:
            return qs.filter(tenant__isnull=True)
        return qs.filter(Q(tenant=tenant) | Q(tenant__isnull=True))


# ---------------------------------------------------------------------------
# Multi-tenant variant (M2M ``tenants``)
# ---------------------------------------------------------------------------


class OptionalMultiTenantQuerySet(models.QuerySet):
    """QuerySet for models where ``tenants`` is a M2M to the Tenant model.

    Mirrors :class:`OptionalTenantQuerySet`: ``create``/``bulk_create`` do
    **not** auto-inject the bound tenant. A row with no tenant
    associations is the idiomatic "vendor row" and is visible to every
    tenant; stamping the active tenant is the caller's responsibility
    and must happen **after** ``save()`` via
    ``obj.tenants.add(current)`` (Django M2M can't be set on an unsaved
    instance).
    """


class OptionalMultiTenantManager(
    models.Manager.from_queryset(OptionalMultiTenantQuerySet)
):
    """Like :class:`OptionalTenantManager`, but ``tenants`` is a M2M.

    Use-case: rows that can legitimately belong to **several** tenants
    at once — e.g. a medical device shared by a practice community
    ("Geraetegemeinschaft"), where two or more tenants jointly own and
    use the same physical unit. A single-FK ``tenant`` field cannot
    model that.

    Visibility:

    - No tenant bound → vendor rows only (``tenants`` is empty).
    - Tenant bound    → rows that include this tenant **OR** are vendor
      rows (``tenants`` is empty). The ``Q(tenants=current) |
      Q(tenants__isnull=True)`` predicate uses a LEFT OUTER JOIN on
      the M2M table and can produce duplicates for rows associated
      with multiple tenants; ``.distinct()`` is applied unconditionally
      to keep the semantics sane.

    ``all_objects`` remains available as the unscoped escape hatch
    (plain :class:`~django.db.models.Manager`).
    """

    def get_queryset(self):
        qs = super().get_queryset()
        tenant = get_current_tenant()
        if tenant is None:
            return qs.filter(tenants__isnull=True)
        return qs.filter(Q(tenants=tenant) | Q(tenants__isnull=True)).distinct()
