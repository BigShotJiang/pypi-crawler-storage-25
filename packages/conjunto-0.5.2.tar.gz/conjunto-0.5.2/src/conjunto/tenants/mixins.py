"""View mixins for tenant-aware request handling."""

from django.contrib import messages
from django.core.exceptions import ImproperlyConfigured, PermissionDenied
from django.shortcuts import redirect
from django.utils.translation import gettext_lazy as _


class TenantRequiredMixin:
    """Redirect to ``/`` if no tenant is bound on the request.

    Tenant-scoped views should inherit from this mixin. If
    ``request.tenant`` is ``None``, the user is redirected to the root
    URL with a message prompting them to pick a tenant via the statusbar
    dropdown.
    """

    #: Where to redirect when no tenant is bound.
    tenant_missing_redirect_url = "/"

    def dispatch(self, request, *args, **kwargs):
        if getattr(request, "tenant", None) is None:
            messages.info(request, _("Please select a tenant to continue."))
            return redirect(self.tenant_missing_redirect_url)
        return super().dispatch(request, *args, **kwargs)


class VendorWriteProtectionMixin:
    """Block writes against vendor-owned (global) rows for non-vendor users.

    Meant for ``UpdateView`` / ``DeleteView`` subclasses whose model
    uses :class:`~conjunto.tenants.models.OptionalTenantModelMixin` — or
    any model that exposes a duck-typed ``is_vendor_owned`` property.

    Rationale
    ---------
    :class:`~conjunto.tenants.managers.OptionalTenantManager` exposes
    two classes of rows to every tenant:

    - **Vendor rows** (``tenant IS NULL``) — globally installed, usually
      shipped via a vendor data pack. Visible to every tenant but must
      only be editable by the vendor.
    - **Tenant rows** (``tenant = <X>``) — local rows belonging to a
      single tenant.

    The manager filters reads correctly, but does **not** enforce write
    protection: without this mixin, tenant A could technically ``POST``
    against the edit view for a vendor row and thereby mutate data seen
    by tenant B — a privilege escalation against the vendor scope.

    Behaviour
    ---------
    After ``super().get_object()`` resolves the target row, the mixin
    inspects ``obj.is_vendor_owned``:

    - ``False`` → tenant row → request proceeds normally (the view's
      own scoping, e.g. :class:`TenantRequiredMixin`, is already in
      effect).
    - ``True`` → vendor row → the mixin delegates to
      :meth:`~conjunto.settings.scoped.scopes.IVendorScope.can_edit`.
      If the check returns ``False``, the view raises
      ``PermissionDenied`` (Django renders a 403).

    ``IVendorScope.can_edit`` — semantics
    --------------------------------------
    Vendor-edit authority is gated on the Django permission
    ``conjunto_settings.manage_vendor_settings`` (see
    :class:`~conjunto.settings.scoped.scopes.IVendorScope`). In
    practice this is held only by the vendor's superadmin account (or
    a specifically granted vendor-admin role). Regular tenant users —
    including tenant admins — never hold this permission, so they
    cannot mutate vendor-owned rows, even though the row itself is
    visible to them.

    The mixin reuses the existing scope semantics on purpose: vendor
    data-pack entries and vendor-scoped settings already share one
    write-authority boundary (the vendor), so one permission governs
    both. If a project ever needs a separate boundary for data-pack
    rows, override :meth:`is_write_allowed` on the view.

    Duck typing
    -----------
    The mixin does **not** inspect ``obj.tenant`` directly. Instead it
    looks for ``obj.is_vendor_owned`` (see
    :attr:`~conjunto.tenants.models.OptionalTenantModelMixin.is_vendor_owned`).
    This lets future tenant-topologies (e.g. an
    ``OptionalMultiTenantModelMixin`` with an M2M ``tenants`` field,
    where "vendor-owned" maps to ``not self.tenants.exists()``) drop
    the same view mixin in without the view layer needing to know the
    underlying shape. A model that does not expose the property raises
    :class:`ImproperlyConfigured` with a pointing error message — no
    silent bypass.

    Example
    -------
    .. code-block:: python

        from conjunto.tenants.mixins import (
            TenantRequiredMixin, VendorWriteProtectionMixin,
        )
        from django.views.generic import UpdateView

        class DeviceTypeUpdateView(
            TenantRequiredMixin,
            VendorWriteProtectionMixin,
            UpdateView,
        ):
            model = DeviceType
            form_class = DeviceTypeForm
            template_name = "devices/device_type_form.html"

    Tenant-owned ``DeviceType`` rows (``tenant = <X>``) are editable by
    the tenant as usual. Vendor-owned rows (``tenant IS NULL``) are
    read-only for everyone who does not hold
    ``conjunto_settings.manage_vendor_settings``.
    """

    def get_object(self, queryset=None):
        obj = super().get_object(queryset=queryset)
        if not hasattr(obj, "is_vendor_owned"):
            raise ImproperlyConfigured(
                f"{type(self).__name__} uses VendorWriteProtectionMixin "
                f"but {type(obj).__name__} does not expose an "
                f"`is_vendor_owned` property. Either inherit from "
                f"conjunto.tenants.models.OptionalTenantModelMixin or "
                f"define the property manually on the model."
            )
        if obj.is_vendor_owned and not self.is_write_allowed(obj):
            raise PermissionDenied(
                _("You are not allowed to modify this vendor-owned entry.")
            )
        return obj

    def is_write_allowed(self, obj) -> bool:
        """Hook returning whether the current request may write ``obj``.

        Default: delegates to
        :meth:`~conjunto.settings.scoped.scopes.IVendorScope.can_edit`
        with ``ref=None`` (vendor scope has no FK). Override on a
        subclass if a project needs a different authority model for
        vendor-row writes (e.g. "vendor-pack editor" vs. "vendor
        settings editor").
        """
        from conjunto.settings.scoped.scopes import IVendorScope

        return IVendorScope.can_edit(self.request, None)
