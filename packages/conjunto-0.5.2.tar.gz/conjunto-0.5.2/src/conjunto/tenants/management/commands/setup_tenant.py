"""Management command: re-run ``ITenantLifecycle`` hooks for tenants.

Useful to back-fill plugin-contributed master data on tenants that
predate a plugin's installation, or to verify idempotency of
implementations after refactoring.
"""

from __future__ import annotations

from django.core.management.base import BaseCommand, CommandError

from conjunto.tenants.interfaces import ITenantLifecycle
from conjunto.tenants.signals import run_tenant_lifecycle
from conjunto.tenants.utils import get_tenant_model


class Command(BaseCommand):
    """Run :class:`ITenantLifecycle` hooks for selected tenants.

    Examples::

        python manage.py setup_tenant 1 2 3
        python manage.py setup_tenant --all

    Exit code is ``0`` when every implementer succeeded for every
    selected tenant, ``1`` if at least one implementer raised. Failing
    implementers do not abort the run — every other tenant and every
    other implementer is still attempted.
    """

    help = "Run ITenantLifecycle.setup_tenant for the given tenants."

    def add_arguments(self, parser):
        parser.add_argument(
            "tenant_ids",
            nargs="*",
            type=int,
            help="Primary keys of tenants to set up.",
        )
        parser.add_argument(
            "--all",
            action="store_true",
            dest="all_tenants",
            help="Set up every tenant in the database.",
        )

    def handle(self, *args, **options):
        tenant_ids: list[int] = options["tenant_ids"]
        all_tenants: bool = options["all_tenants"]

        if not tenant_ids and not all_tenants:
            raise CommandError("Provide at least one tenant id, or pass --all.")
        if tenant_ids and all_tenants:
            raise CommandError("Pass either tenant ids or --all, not both.")

        Tenant = get_tenant_model()
        if all_tenants:
            tenants = list(Tenant.objects.all().order_by("pk"))
        else:
            tenants = list(Tenant.objects.filter(pk__in=tenant_ids).order_by("pk"))
            found_ids = {t.pk for t in tenants}
            missing = sorted(set(tenant_ids) - found_ids)
            if missing:
                self.stderr.write(
                    self.style.WARNING(f"Skipping unknown tenant ids: {missing}")
                )

        if not tenants:
            self.stdout.write("No tenants selected.")
            return

        implementer_count = sum(1 for _ in ITenantLifecycle)
        self.stdout.write(
            f"Running {implementer_count} ITenantLifecycle implementer(s) "
            f"on {len(tenants)} tenant(s)."
        )

        had_failure = False
        for tenant in tenants:
            label = f"{tenant.pk} ({getattr(tenant, 'slug', tenant)})"
            self.stdout.write(f"Tenant {label}:")
            results = run_tenant_lifecycle(tenant)
            if not results:
                self.stdout.write("  (no implementers registered)")
                continue
            for impl, error in results:
                if error is None:
                    self.stdout.write(self.style.SUCCESS(f"  OK   {impl.__name__}"))
                else:
                    had_failure = True
                    self.stdout.write(
                        self.style.ERROR(
                            f"  FAIL {impl.__name__}: "
                            f"{error.__class__.__name__}: {error}"
                        )
                    )

        if had_failure:
            # Non-zero exit so CI / scripts can react. Django
            # surfaces ``CommandError`` as exit code 1 by default.
            raise CommandError(
                "One or more ITenantLifecycle implementers failed; see log above."
            )
