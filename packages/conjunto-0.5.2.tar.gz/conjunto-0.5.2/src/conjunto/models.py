from typing import Self

from django.core.exceptions import MultipleObjectsReturned
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.core.serializers.json import DjangoJSONEncoder
from django.db import models, IntegrityError
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from phonenumber_field.modelfields import PhoneNumberField


# thanks to https://stackoverflow.com/questions/49735906/how-to-implement-singleton-in-django/49736970#49736970
class SingletonModel(models.Model):
    """Singleton Django Model.

    Allow only one instance of the model to be created.
    To get the instance of the model, use `<YourModel>.get_instance()`.
    """

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        """Save object to the database.

        Raises:
            IntegrityError: if there is already another instance in the database.
        """

        # If '_aggressive' attribute is set, remove all other entries if there are any.
        # if self._aggressive:
        #     self.__class__.objects.exclude(id=self.id).delete()
        if not self.pk:
            self.pk = self.get_instance().pk
        super().save(*args, **kwargs)

    @classmethod
    def get_instance(cls) -> Self:
        """Load object from the database.

        Failing that, create a new empty (default) instance of the object and return it
        (without saving it - you have to do that yourself).

        Raises:
            IntegrityError: if there are more than one objects saved in the databases.
        """

        try:
            return cls.objects.get()
        except cls.DoesNotExist:
            return cls()
        except MultipleObjectsReturned:
            raise IntegrityError(
                f"There are more than one instances of {cls.__name__} saved in the database"
            )


class Vendor(SingletonModel):
    """The vendor that is responsible for this appliance."""

    # TODO find an easy way to deploy data in Vendor model
    # maybe in a preferences.toml file?

    name = models.CharField(max_length=255)
    address = models.CharField(max_length=255, blank=True, null=True)
    zip = models.CharField(max_length=10, blank=True, null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    phone = PhoneNumberField(blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    website = models.URLField(blank=True, null=True)

    def __str__(self):
        return self.name


class AutoDateTimeField(models.DateTimeField):
    def pre_save(self, model_instance, add):
        return timezone.now()


class CreatedModifiedModel(models.Model):
    """A simple mixin for model classes that need to have created/modified fields."""

    created = models.DateTimeField(_("Created"), editable=False, default=timezone.now)
    modified = AutoDateTimeField(_("Modified"), default=timezone.now)

    class Meta:
        abstract = True


class VersionSnapshot(models.Model):
    """Snapshot of a HistoryVersionedModel instance before each update.

    Stores all concrete field values as JSON, keyed by field attname.
    """

    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.CASCADE,
        editable=False,
    )
    object_id = models.PositiveBigIntegerField(editable=False)
    content_object = GenericForeignKey("content_type", "object_id")
    version = models.PositiveIntegerField(editable=False)
    snapshot = models.JSONField(encoder=DjangoJSONEncoder, editable=False)
    saved_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["version"]
        indexes = [models.Index(fields=["content_type", "object_id"])]

    def __str__(self):
        return f"{self.content_type} #{self.object_id} v{self.version}"


class HistoryVersionedModel(models.Model):
    """Versioned model with a stable PK and a separate snapshot history table.

    On every save() of an existing instance, the current field values are
    snapshotted into VersionSnapshot before the record is updated. The PK
    never changes, making it safe to reference via ForeignKey.

    Usage:
        class MyModel(HistoryVersionedModel):
            title = models.CharField(max_length=255)
            content = models.TextField()

        obj = MyModel(title="Test", content="v1")
        obj.save()  # version=1, no snapshot yet

        obj.content = "v2"
        obj.save()  # version=2, v1 state stored in VersionSnapshot

        obj.get_history()  # QuerySet of VersionSnapshot entries ordered by version
    """

    version = models.PositiveIntegerField(default=1, editable=False)
    created_at = models.DateTimeField(
        _("Created"), editable=False, default=timezone.now
    )
    modified_at = AutoDateTimeField(_("Modified"), default=timezone.now)

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if self.pk:
            current = self.__class__.objects.get(pk=self.pk)
            snapshot = {
                field.attname: getattr(current, field.attname)
                for field in self._meta.concrete_fields
            }
            VersionSnapshot.objects.create(
                content_type=ContentType.objects.get_for_model(self.__class__),
                object_id=self.pk,
                version=current.version,
                snapshot=snapshot,
            )
            self.version = current.version + 1
        super().save(*args, **kwargs)

    def get_history(self):
        """Return all previous snapshots ordered by version."""
        return VersionSnapshot.objects.filter(
            content_type=ContentType.objects.get_for_model(self.__class__),
            object_id=self.pk,
        ).order_by("version")
