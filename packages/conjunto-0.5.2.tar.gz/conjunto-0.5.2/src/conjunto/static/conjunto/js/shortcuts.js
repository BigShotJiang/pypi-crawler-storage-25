/**
 * Conjunto keyboard shortcut runtime.
 *
 * Single AlpineJS store + single global keydown listener. The store holds
 * the per-page bindings (server-injected as `window.cjShortcutsBindings`)
 * and an activation-scope stack that templates push/pop via the
 * `{% shortcut_scope %}` tag or the `$store.cjShortcuts.push/pop` API.
 *
 * See docs/superpowers/specs/2026-05-03-keyboard-shortcuts-design.md.
 */

(function () {
  "use strict";

  // Chord-style shortcuts ("g d") were dropped in 2026-05-18 — they
  // swallow keystrokes from focused inputs and surprise the user.
  // Only single keys (with optional Ctrl/Alt/Shift modifiers) remain.
  const TYPING_TAGS = new Set(["INPUT", "TEXTAREA", "SELECT"]);

  /** Detect whether a focus target should swallow non-modifier keys. */
  function isTyping(target) {
    if (!target) return false;
    if (target.isContentEditable) return true;
    if (TYPING_TAGS.has(target.tagName)) {
      // checkbox/radio/button-shaped inputs aren't text fields
      const t = (target.type || "").toLowerCase();
      if (target.tagName === "INPUT" && ["checkbox", "radio", "button", "submit"].includes(t)) {
        return false;
      }
      return true;
    }
    return false;
  }

  /** Normalise a KeyboardEvent into a binding key string. */
  function eventToKey(ev) {
    const mods = [];
    if (ev.ctrlKey || ev.metaKey) mods.push("Ctrl"); // Cmd → Ctrl on Mac
    if (ev.altKey) mods.push("Alt");
    if (ev.shiftKey) mods.push("Shift");

    let key;
    // Function keys: use ev.key directly.
    if (/^F\d{1,2}$/.test(ev.key)) {
      key = ev.key;
    } else if (ev.code && ev.code.startsWith("Key") && ev.code.length === 4) {
      // Layout-independent letter (KeyN → n)
      key = ev.code.slice(3).toLowerCase();
    } else if (ev.code && ev.code.startsWith("Digit") && ev.code.length === 6) {
      key = ev.code.slice(5);
    } else {
      // Special keys (Enter, Escape, ArrowLeft, '/', '?'): trust ev.key
      key = ev.key;
    }
    if (!key) return "";
    return mods.length ? mods.join("+") + "+" + key : key;
  }

  /** Glob match: `cashbook:*` against `cashbook:entry-list` etc. */
  function globMatch(pattern, candidate) {
    if (!pattern || !candidate) return false;
    if (pattern === candidate) return true;
    if (pattern.endsWith(":*")) {
      const prefix = pattern.slice(0, -1); // keep the colon
      return candidate.startsWith(prefix);
    }
    // Generic glob support (rarely needed)
    const re = new RegExp(
      "^" +
        pattern
          .split("*")
          .map((p) => p.replace(/[.+^${}()|[\]\\]/g, "\\$&"))
          .join(".*") +
        "$"
    );
    return re.test(candidate);
  }

  function dispatchHandler(handler) {
    if (!handler) return;
    switch (handler.kind) {
      case "navigate":
        if (handler.url) window.location.assign(handler.url);
        break;
      case "htmx-get":
      case "htmx-post":
        if (window.htmx && handler.url) {
          window.htmx.ajax(
            handler.kind === "htmx-get" ? "GET" : "POST",
            handler.url,
            { target: handler.target || "#dialog", swap: handler.swap || "innerHTML" }
          );
        }
        break;
      case "click-selector": {
        if (!handler.selector) return;
        const el = document.querySelector(handler.selector);
        if (el) {
          if (typeof el.focus === "function") el.focus();
          if (typeof el.click === "function") el.click();
        }
        break;
      }
      case "custom-event":
        if (handler.event_name) {
          document.dispatchEvent(
            new CustomEvent(handler.event_name, {
              detail: handler.event_detail || {},
              bubbles: true,
            })
          );
        }
        break;
    }
  }

  document.addEventListener("alpine:init", () => {
    if (!window.Alpine) return;

    Alpine.store("cjShortcuts", {
      bindings: window.cjShortcutsBindings || [],
      stack: ["global"],

      push(scope) {
        if (!scope) return;
        if (this.stack[0] !== scope) this.stack.unshift(scope);
      },

      pop(scope) {
        const i = this.stack.indexOf(scope);
        if (i >= 0) this.stack.splice(i, 1);
      },

      replaceBindings(bindings) {
        this.bindings = Array.isArray(bindings) ? bindings : [];
      },

      _scopeActive(scope) {
        // "global" always active; other scopes match if any item on the
        // stack matches the scope's url-glob.
        if (scope === "global") return true;
        const colon = scope.indexOf(":");
        if (colon < 0) return this.stack.includes(scope);
        const pattern = scope.slice(colon + 1);
        return this.stack.some((s) => globMatch(pattern, s) || globMatch(pattern, _resolvedRouteName));
      },

      findBinding(key) {
        // Walk stack top→bottom, take the first matching binding.
        for (const scope of this.stack) {
          for (const b of this.bindings) {
            if (b.key !== key) continue;
            if (b.scope === "global" || this._scopeActive(b.scope)) {
              return b;
            }
          }
        }
        // Stack didn't match — also consider purely-global bindings.
        for (const b of this.bindings) {
          if (b.key === key && b.scope === "global") return b;
        }
        return null;
      },

      execute(binding) {
        if (!binding) return;
        dispatchHandler(binding.handler);
      },
    });

    // Try to auto-detect the resolved route name; consumers can override
    // by setting `window.cjShortcutsRouteName` before alpine:init fires.
    const _resolvedRouteName = window.cjShortcutsRouteName || "";

    const store = Alpine.store("cjShortcuts");

    document.addEventListener("keydown", (ev) => {
      // Don't intercept while user is interacting with form controls
      // unless the target binding is `always_active` or `mode == "modifier"`.
      const typing = isTyping(ev.target);
      const key = eventToKey(ev);
      if (!key) return;

      const binding = store.findBinding(key);
      if (!binding) return;

      const allowModifier = binding.mode === "modifier";
      const allowAlways = !!binding.always_active;
      if (typing && !allowModifier && !allowAlways) {
        // User is typing — let the keystroke through to the input.
        return;
      }

      ev.preventDefault();
      store.execute(binding);
    });

    // HTMX integration — refresh bindings when the server pushes a new page.
    document.addEventListener("htmx:afterSettle", (ev) => {
      // If the swap brought a fresh `cjShortcutsBindings` payload (boosted
      // page navigation), reload it.
      if (window.cjShortcutsBindings && Array.isArray(window.cjShortcutsBindings)) {
        store.replaceBindings(window.cjShortcutsBindings);
      }
    });

    // MutationObserver: pop view-scope on element removal.
    const obs = new MutationObserver((mutations) => {
      for (const m of mutations) {
        for (const node of m.removedNodes) {
          if (!(node instanceof HTMLElement)) continue;
          const scope = node.getAttribute && node.getAttribute("data-shortcut-scope");
          if (scope) store.pop(scope);
          // Also handle removed descendants
          if (node.querySelectorAll) {
            node.querySelectorAll("[data-shortcut-scope]").forEach((el) => {
              store.pop(el.getAttribute("data-shortcut-scope"));
            });
          }
        }
      }
    });
    obs.observe(document.body, { childList: true, subtree: true });
  });
})();
