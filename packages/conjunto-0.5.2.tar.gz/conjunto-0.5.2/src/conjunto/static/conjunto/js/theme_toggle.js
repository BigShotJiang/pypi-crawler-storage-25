(() => {
  // Theme toggle. Loaded only when CONJUNTO_THEME_SWITCHER is enabled.
  //
  // The corresponding UI (conjunto/includes/theme_toggle.html) triggers
  // this function via onclick="window.toggleTheme()". The server-side
  // persistence endpoint URL is read from [data-color-scheme-url] on
  // the toggle container so the same script works regardless of URL
  // prefixes (e.g. language prefixes or a mounted subpath).

  // Apply a color scheme to the live DOM and persist it in
  // ``localStorage["tabler-theme"]`` so that Tabler's early-parse
  // ``tabler-theme.js`` reads the freshly-saved value on the NEXT
  // full page load. Used both by the topbar toggle (immediate) and
  // by the ``colorSchemeChanged`` HX-Trigger fired after a server
  // persist via /settings/ (so the two surfaces stay in sync).
  function applyColorScheme(value) {
    const v = value === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-bs-theme', v);
    if (v === 'dark') {
      document.documentElement.classList.add('theme-dark');
    } else {
      document.documentElement.classList.remove('theme-dark');
    }
    try { localStorage.setItem('tabler-theme', v); } catch (e) { /* noop */ }
  }

  // ── HX-Trigger listener ────────────────────────────────────
  // Settings form persists a new color scheme server-side and
  // emits ``colorSchemeChanged`` via HX-Trigger. Without this
  // mirror into ``localStorage["tabler-theme"]``, the next full
  // page load would re-read the stale client cache before first
  // paint and visually revert the skin to the previous value.
  document.body.addEventListener('colorSchemeChanged', function (event) {
    const detail = (event && event.detail) || {};
    applyColorScheme(detail.value);
  });

  window.toggleTheme = function () {
    const currentTheme = document.documentElement.getAttribute('data-bs-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-bs-theme', newTheme);
    if (newTheme === 'dark') {
      document.documentElement.classList.add('theme-dark');
    } else {
      document.documentElement.classList.remove('theme-dark');
    }
    try { localStorage.setItem('tabler-theme', newTheme); } catch (e) {}

    // Persist color scheme server-side so the next full page load
    // renders the correct data-bs-theme attribute without a flash.
    var urlEl = document.querySelector('[data-color-scheme-url]');
    if (urlEl) {
      var url = urlEl.getAttribute('data-color-scheme-url');
      var csrfToken = '';
      var csrfEl = document.querySelector('[name=csrfmiddlewaretoken]');
      if (csrfEl) csrfToken = csrfEl.value;
      fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrfToken,
        },
        body: JSON.stringify({color_scheme: newTheme}),
      }).catch(function () { /* best-effort, localStorage is the fallback */ });
    }
  };
})();
