// Conjunto DateStepperInput — helpers used by the inline Alpine x-data in
// the widget template. Exposed as window.cjDateStep / window.cjDateSetToday
// so the template can call them without registering an Alpine component.
//
// Supported date format tokens (matching the Python widget's
// _django_to_js_format): YYYY (4-digit year), YY (2-digit year), MM
// (zero-padded month), DD (zero-padded day). The Django SHORT_DATE_FORMAT
// of the active locale is rendered into the wrapper as data-date-format
// and passed to these helpers via the Alpine scope.
(() => {
  "use strict";

  function pad2(n) {
    return String(n).padStart(2, "0");
  }

  function parseDate(value, format) {
    if (!value) return null;
    const tokens = ["YYYY", "YY", "MM", "DD"];
    let regexSrc = "";
    const order = [];
    let i = 0;
    while (i < format.length) {
      let matched = null;
      for (const tok of tokens) {
        if (format.startsWith(tok, i)) {
          matched = tok;
          break;
        }
      }
      if (matched) {
        if (matched === "YYYY") regexSrc += "(\\d{4})";
        else regexSrc += "(\\d{2})";
        order.push(matched);
        i += matched.length;
      } else {
        // Escape any regex-special char from the literal.
        regexSrc += format[i].replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        i += 1;
      }
    }
    const re = new RegExp("^" + regexSrc + "$");
    const m = re.exec(String(value).trim());
    if (!m) return null;
    let year = null,
      month = null,
      day = null;
    for (let k = 0; k < order.length; k++) {
      const v = parseInt(m[k + 1], 10);
      if (order[k] === "YYYY") year = v;
      else if (order[k] === "YY") year = v < 70 ? 2000 + v : 1900 + v;
      else if (order[k] === "MM") month = v;
      else if (order[k] === "DD") day = v;
    }
    if (year === null || month === null || day === null) return null;
    const d = new Date(year, month - 1, day);
    if (
      d.getFullYear() !== year ||
      d.getMonth() !== month - 1 ||
      d.getDate() !== day
    ) {
      return null;
    }
    return d;
  }

  function formatDate(date, format) {
    const yyyy = String(date.getFullYear());
    const yy = yyyy.slice(-2);
    const mm = pad2(date.getMonth() + 1);
    const dd = pad2(date.getDate());
    let out = "";
    let i = 0;
    while (i < format.length) {
      if (format.startsWith("YYYY", i)) {
        out += yyyy;
        i += 4;
      } else if (format.startsWith("YY", i)) {
        out += yy;
        i += 2;
      } else if (format.startsWith("MM", i)) {
        out += mm;
        i += 2;
      } else if (format.startsWith("DD", i)) {
        out += dd;
        i += 2;
      } else {
        out += format[i];
        i += 1;
      }
    }
    return out;
  }

  function commit(input, date) {
    input.value = formatDate(date, input.closest("[data-date-format]").dataset.dateFormat);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  window.cjDateStep = function (input, format, days) {
    const current = parseDate(input.value, format) || new Date();
    current.setDate(current.getDate() + days);
    commit(input, current);
  };

  window.cjDateSetToday = function (input /*, format */) {
    commit(input, new Date());
  };

  // Exposed for tests.
  window.cjDateStepper = { parseDate, formatDate };
})();
