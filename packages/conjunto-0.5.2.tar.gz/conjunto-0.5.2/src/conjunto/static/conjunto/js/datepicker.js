// Litepicker initialiser for `.datepickerinput` elements.
//
// Runs on initial page load, after every `htmx:load` (so modals and
// other HTMX-swapped fragments get their Litepickers wired up), and
// closes any open picker when its containing modal starts hiding —
// otherwise the picker popup stays detached on screen after the
// modal disappears.
(() => {
  "use strict";

  function convertDateFormat(djangoFormat) {
    const formatMap = { Y: "YYYY", m: "MM", d: "DD" };
    let jsFormat = "";
    for (let i = 0; i < djangoFormat.length; i++) {
      const char = djangoFormat.charAt(i);
      jsFormat += formatMap[char] || char;
    }
    return jsFormat;
  }

  function initInputs(scope) {
    const root = scope && scope.querySelectorAll ? scope : document;
    const inputs = root.querySelectorAll(".datepickerinput");
    if (!inputs.length) return;

    const format = convertDateFormat(get_format("SHORT_DATE_FORMAT"));
    const lang = globals.LANGUAGE_CODE;

    const endMap = {};
    for (const e of inputs) {
      if (e._litepicker) continue;
      const endFieldName = e.dataset.endField;
      if (endFieldName) {
        endMap[e.name] = document.getElementsByName(endFieldName)[0];
      }
    }

    inputs.forEach((e) => {
      if (e._litepicker) return;
      if (e.dataset.endField) {
        const endEl = endMap[e.name];
        const picker = new Litepicker({
          element: e,
          elementEnd: endEl,
          singleMode: false,
          allowRepick: true,
          lang,
          format,
        });
        picker.on("selected", () => endEl && endEl.focus());
        e._litepicker = picker;
        if (endEl) endEl._litepicker = picker;
      } else if (!Object.values(endMap).includes(e)) {
        const picker = new Litepicker({ element: e, lang, format });
        picker.on("selected", () => e.focus());
        e._litepicker = picker;
      }
    });
  }

  function initOnLoad() {
    initInputs(document);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initOnLoad);
  } else {
    initOnLoad();
  }

  // HTMX-swapped fragments (modals, partial reloads) need a re-scan.
  if (document.body) {
    document.body.addEventListener("htmx:load", (e) => {
      const elt = (e.detail && e.detail.elt) || document;
      initInputs(elt);
    });
  }

  // Close any open Litepicker when its containing modal starts hiding —
  // otherwise the popup remains visible after the modal disappears.
  // `hide.bs.modal` fires before the close animation and before the
  // `hidden.bs.modal` handler in conjunto.js wipes `#dialog`.
  document.addEventListener("hide.bs.modal", (e) => {
    if (!e.target || !e.target.querySelectorAll) return;
    e.target.querySelectorAll(".datepickerinput").forEach((el) => {
      const picker = el._litepicker;
      if (picker && typeof picker.hide === "function") picker.hide();
    });
  });
})();
