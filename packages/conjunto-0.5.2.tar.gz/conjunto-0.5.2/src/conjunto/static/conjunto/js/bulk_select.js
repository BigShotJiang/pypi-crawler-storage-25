/*
 * Alpine factory backing the bulk-action selection bar.
 *
 * Usage in templates:
 *
 *   <div x-data="cjBulkSelect()" id="some-wrapper" hx-trigger="...">
 *     <table>
 *       <thead>
 *         <tr>
 *           <th><input type="checkbox" data-cj-bulk-master
 *                      @change="toggleAll($event.target.checked)"></th>
 *           ...
 *         </tr>
 *       </thead>
 *       <tbody>
 *         {% for record in records %}
 *           <tr>
 *             <td><input type="checkbox" name="pks" value="{{ record.pk }}"
 *                        @change="sync()"></td>
 *             ...
 *           </tr>
 *         {% endfor %}
 *       </tbody>
 *     </table>
 *     {% include "conjunto/tables/_bulk_actions_bar.html" %}
 *   </div>
 *
 * Contract:
 *   - The per-row checkbox name MUST be ``pks`` (or match the
 *     ``pk_field`` on the BulkAction; default is ``pks``).
 *   - The master checkbox MUST carry ``data-cj-bulk-master`` so
 *     ``toggleAll()`` and ``sync()`` can address it without leaking
 *     into selectors that match table content.
 *   - HTMX picks up the checked pks automatically via the
 *     ``hx-include="[name='pks']:checked"`` attribute that
 *     ``BulkAction.render_attrs()`` injects on every button. No JS
 *     code path collects pks for HTMX — the include selector does.
 */
document.addEventListener('alpine:init', () => {
  window.Alpine.data('cjBulkSelect', () => ({
    count: 0,

    init() {
      // Cover the case where the partial is HTMX-swapped in with some
      // checkboxes already pre-checked (e.g. server-side "select all"
      // links — rare, but cheap to honour).
      this.sync();
    },

    /**
     * Re-read the DOM and recompute ``count`` + master-checkbox state.
     * Call after any change to per-row checkboxes.
     */
    sync() {
      const boxes = this._boxes();
      const checked = boxes.filter((b) => b.checked);
      this.count = checked.length;
      const master = this._master();
      if (master) {
        master.checked = checked.length > 0 && checked.length === boxes.length;
        master.indeterminate =
          checked.length > 0 && checked.length < boxes.length;
      }
    },

    /**
     * Master-checkbox handler. ``checked === true`` selects every
     * per-row checkbox in scope; ``false`` deselects them all.
     */
    toggleAll(checked) {
      for (const box of this._boxes()) {
        box.checked = !!checked;
      }
      this.sync();
    },

    /**
     * Clear the selection. Used by the "Clear" button in the bar and
     * after a successful bulk action.
     */
    clear() {
      for (const box of this._boxes()) {
        box.checked = false;
      }
      const master = this._master();
      if (master) {
        master.checked = false;
        master.indeterminate = false;
      }
      this.count = 0;
    },

    _boxes() {
      // Scope to ``this.$root`` so a page with multiple selection
      // tables can't cross-contaminate. The selector is intentionally
      // narrow: only the form-field-named inputs participate, not any
      // other checkbox that may live in the wrapper.
      return Array.from(
        this.$root.querySelectorAll('input[type="checkbox"][name="pks"]'),
      );
    },

    _master() {
      return this.$root.querySelector(
        'input[type="checkbox"][data-cj-bulk-master]',
      );
    },
  }));
});
