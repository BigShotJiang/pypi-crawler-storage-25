// Conjunto TimePickerInput — strict digits-only mask, auto-colon, snap-step
// arrows + buttons. Mirror of conjunto.forms.fields._smart_parse_time
// (server-side fallback for non-JS clients).
(() => {
  "use strict";

  const SELECTOR = '[data-cj-time-input]:not([data-cj-time-init])';

  // ---------------------------------------------------------------------
  // Pure parsing
  // ---------------------------------------------------------------------

  function smartParse(raw, format12h) {
    if (raw === null || raw === undefined) return null;
    let s = String(raw).trim().toLowerCase();
    if (!s) return null;
    let suffix = null;
    if (format12h) {
      for (const marker of ["am", "pm"]) {
        if (s.endsWith(marker)) {
          suffix = marker;
          s = s.slice(0, -marker.length).trim();
          break;
        }
      }
    }
    const digits = s.replace(/\D/g, "");
    if (!digits || digits.length > 4) return null;
    let h, m;
    if (digits.length === 1) {
      h = parseInt(digits, 10); m = 0;
    } else if (digits.length === 2) {
      const v = parseInt(digits, 10);
      if (v <= 23) { h = v; m = 0; }
      else {
        h = parseInt(digits[0], 10);
        m = parseInt(digits[1], 10) * 10;
      }
    } else if (digits.length === 3) {
      const firstTwo = parseInt(digits.slice(0, 2), 10);
      if (firstTwo <= 23) {
        h = firstTwo; m = parseInt(digits[2], 10) * 10;
      } else {
        h = parseInt(digits[0], 10);
        m = parseInt(digits.slice(1), 10);
      }
    } else {
      h = parseInt(digits.slice(0, 2), 10);
      m = parseInt(digits.slice(2), 10);
    }
    if (suffix === "pm" && h < 12) h += 12;
    else if (suffix === "am" && h === 12) h = 0;
    if (h < 0 || h > 23 || m < 0 || m > 59) return null;
    return { h, m };
  }

  const pad = (n) => String(n).padStart(2, "0");
  const format24h = (t) => `${pad(t.h)}:${pad(t.m)}`;
  function format12h(t) {
    let h = t.h % 12;
    if (h === 0) h = 12;
    return `${pad(h)}:${pad(t.m)} ${t.h < 12 ? "AM" : "PM"}`;
  }
  const display = (t, fmt12) => (fmt12 ? format12h(t) : format24h(t));

  function wrap(total) { return ((total % 1440) + 1440) % 1440; }

  function snapStep(t, snap, direction) {
    let total = t.h * 60 + t.m;
    total = direction > 0
      ? Math.floor(total / snap) * snap + snap
      : Math.ceil(total / snap) * snap - snap;
    total = wrap(total);
    return { h: Math.floor(total / 60), m: total % 60 };
  }

  // ---------------------------------------------------------------------
  // 24h mask: digits only, auto-insert ":" after position 2, max 4 digits
  // ---------------------------------------------------------------------

  function reformat24h(input) {
    const oldVal = input.value;
    const oldCursor = input.selectionStart ?? oldVal.length;

    // Count digits at-or-before the cursor — that's our anchor.
    let digitsBeforeCursor = 0;
    for (let i = 0; i < oldCursor && i < oldVal.length; i++) {
      if (oldVal[i] >= "0" && oldVal[i] <= "9") digitsBeforeCursor++;
    }

    const digits = oldVal.replace(/\D/g, "").slice(0, 4);
    const formatted = digits.length <= 2
      ? digits
      : digits.slice(0, 2) + ":" + digits.slice(2);

    if (formatted === oldVal) return;

    input.value = formatted;

    let newPos = digitsBeforeCursor + (digitsBeforeCursor > 2 ? 1 : 0);
    if (newPos > formatted.length) newPos = formatted.length;
    // Some browsers can't set selection inside an input that just received a
    // value during the same event tick — schedule for the next frame.
    requestAnimationFrame(() => {
      try { input.setSelectionRange(newPos, newPos); } catch (_) {}
    });
  }

  // ---------------------------------------------------------------------
  // Buttons + arrow keys
  // ---------------------------------------------------------------------

  function setButtonsState(input) {
    const group = input.closest(".cj-time-picker");
    if (!group) return;
    const fmt12 = input.dataset.format12h === "true";
    const valid = smartParse(input.value, fmt12) !== null;
    group.querySelectorAll(".cj-time-increment, .cj-time-decrement")
      .forEach((el) => {
        // Addons render as <span role="button"> (so the widget can sit
        // inside an input-group). aria-disabled is the equivalent of the
        // native <button disabled> attribute we used previously.
        if (valid) el.removeAttribute("aria-disabled");
        else el.setAttribute("aria-disabled", "true");
      });
  }

  function step(input, direction, big) {
    const fmt12 = input.dataset.format12h === "true";
    const snap = parseInt(input.dataset.snap || "0", 10) || 0;
    const current = smartParse(input.value, fmt12);
    if (!current) return;
    let next;
    if (big) {
      const total = wrap(current.h * 60 + current.m + (direction > 0 ? 60 : -60));
      next = { h: Math.floor(total / 60), m: total % 60 };
    } else if (snap > 0) {
      next = snapStep(current, snap, direction);
    } else {
      const total = wrap(current.h * 60 + current.m + direction);
      next = { h: Math.floor(total / 60), m: total % 60 };
    }
    input.value = display(next, fmt12);
    setButtonsState(input);
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function normalize(input) {
    const fmt12 = input.dataset.format12h === "true";
    const parsed = smartParse(input.value, fmt12);
    if (parsed) input.value = display(parsed, fmt12);
    setButtonsState(input);
  }

  // ---------------------------------------------------------------------
  // Per-input init
  // ---------------------------------------------------------------------

  function initInput(input) {
    if (input.dataset.cjTimeInit === "true") return;
    input.dataset.cjTimeInit = "true";

    const fmt12 = input.dataset.format12h === "true";

    // Server emits canonical "HH:MM" (or rarely "HH:MM:SS"); normalize for
    // display so the mask stays consistent on initial render.
    if (input.value) {
      const parsed = smartParse(input.value, false);
      if (parsed) input.value = fmt12 ? format12h(parsed) : format24h(parsed);
    }

    if (!fmt12) {
      // Block any non-digit single-character insertion (typed or composed).
      // Paste/drop are let through — reformat24h() strips any non-digits
      // afterwards, which is simpler and handles "1530" / "15:30" / "15h30"
      // pastes uniformly.
      input.addEventListener("beforeinput", (event) => {
        const t = event.inputType;
        if (t === "insertText" || t === "insertCompositionText") {
          if (!/^\d$/.test(event.data || "")) event.preventDefault();
        }
      });
      input.addEventListener("input", () => {
        reformat24h(input);
        setButtonsState(input);
      });
    } else {
      input.addEventListener("input", () => setButtonsState(input));
    }

    input.addEventListener("blur", () => normalize(input));
    input.addEventListener("change", () => normalize(input));

    input.addEventListener("keydown", (event) => {
      if (event.key === "ArrowUp") {
        event.preventDefault();
        event.stopPropagation();
        step(input, +1, event.shiftKey);
      } else if (event.key === "ArrowDown") {
        event.preventDefault();
        event.stopPropagation();
        step(input, -1, event.shiftKey);
      } else if (event.key === "Enter") {
        normalize(input);
      }
    });

    const group = input.closest(".cj-time-picker");
    if (group) {
      const inc = group.querySelector(".cj-time-increment");
      const dec = group.querySelector(".cj-time-decrement");
      const handle = (direction) => (e) => {
        e.preventDefault();
        const target = e.currentTarget;
        if (target && target.getAttribute("aria-disabled") === "true") return;
        step(input, direction, false);
      };
      if (inc) inc.addEventListener("click", handle(+1));
      if (dec) dec.addEventListener("click", handle(-1));
    }

    setButtonsState(input);
  }

  // ---------------------------------------------------------------------
  // Bootstrap
  // ---------------------------------------------------------------------

  function initAll(root) {
    const scope = root && root.querySelectorAll ? root : document;
    scope.querySelectorAll(SELECTOR).forEach(initInput);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => initAll(document));
  } else {
    initAll(document);
  }
  // HTMX-swapped fragments: re-scan the swapped subtree.
  document.body && document.body.addEventListener("htmx:load", (event) => {
    const elt = event.detail && event.detail.elt;
    initAll(elt || document);
  });
})();
