(() => {
  // ── Sidebar mode controller ─────────────────────────────────
  // Single source of truth for each sidebar's display state on
  // desktop (>= 992px): exactly one of three body classes per side
  // — cj-sidebar-{left,right}-mode-{full,mini,collapsed}. Classes
  // are server-rendered on first paint to avoid FOUC; changes go
  // through cjSetSidebarMode(side, mode).
  //
  // Persistence target is DEVICE scope (mode) + USER scope (width)
  // via /sidebar-state/<side>/ (SaveSidebarStateView).
  const SIDEBAR_MODES = ['full', 'mini', 'collapsed'];
  const SIDES = ['left', 'right'];
  const DEFAULT_WIDTH = {left: '15rem', right: '20rem'};

  function modeClass(side, mode) {
    return 'cj-sidebar-' + side + '-mode-' + mode;
  }

  function openClass(side) {
    return 'cj-sidebar-' + side + '-open';
  }

  function getSidebarMode(side) {
    for (const m of SIDEBAR_MODES) {
      if (document.body.classList.contains(modeClass(side, m))) return m;
    }
    return side === 'right' ? 'collapsed' : 'full';
  }

  function isSidebarLocked(side) {
    return document.body.dataset['sidebar' + cap(side) + 'ModeLocked'] === '1';
  }

  function cap(s) {
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  function stateUrl(side) {
    return document.body.dataset['sidebar' + cap(side) + 'StateUrl'];
  }

  function lastExpandedKey(side) {
    return 'sidebar' + cap(side) + 'LastExpandedMode';
  }

  function widthVar(side) {
    return '--cj-sidebar-' + side + '-width';
  }

  function miniWidthVar(side) {
    return '--cj-sidebar-' + side + '-mini-width';
  }

  function postJSON(url, body) {
    if (!url) return;
    const csrfEl = document.querySelector('[name=csrfmiddlewaretoken]');
    if (!csrfEl) return;
    return fetch(url, {
      method: 'POST',
      headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrfEl.value},
      body: JSON.stringify(body)
    });
  }

  function persistSidebarState(side, payload) {
    return postJSON(stateUrl(side), payload);
  }

  // Mini mode shows only level-1 icons — no submenu flyout. A click
  // on a parent item follows the link's own href (or is inert if the
  // parent has no URL). This helper disposes any previously-attached
  // Bootstrap dropdown and strips the data-bs-toggle attribute so the
  // anchor behaves like a normal link. Idempotent; safe on every call.
  function disposeSidebarDropdowns() {
    const items = document.querySelectorAll('#cj-sidebar-left [data-cj-sidebar-item-has-children]');
    const Bs = window.bootstrap || window.tabler;
    items.forEach((li) => {
      const trigger = li.querySelector(':scope > .cj-sidebar-row > .cj-sidebar-link');
      if (!trigger) return;
      if (Bs && Bs.Dropdown) {
        const inst = Bs.Dropdown.getInstance(trigger);
        if (inst) inst.dispose();
      }
      trigger.removeAttribute('data-bs-toggle');
      trigger.removeAttribute('aria-expanded');
    });
  }

  window.cjSetSidebarMode = function(side, mode, opts) {
    if (!SIDES.includes(side) || !SIDEBAR_MODES.includes(mode)) return;
    opts = opts || {};
    const persist = opts.persist !== false;
    const body = document.body;
    const previousMode = getSidebarMode(side);
    SIDEBAR_MODES.forEach((m) => body.classList.remove(modeClass(side, m)));
    body.classList.add(modeClass(side, mode));
    // ``lastExpandedMode`` records which expanded mode (full / mini)
    // to restore when toggling out of collapsed. When entering
    // ``collapsed`` we capture the *previous* mode so a "mini →
    // collapsed → toggle" path correctly restores to 'mini'.
    if (mode === 'collapsed') {
      if (previousMode !== 'collapsed') body.dataset[lastExpandedKey(side)] = previousMode;
    } else {
      body.dataset[lastExpandedKey(side)] = mode;
    }
    if (side === 'left') {
      disposeSidebarDropdowns();
    }
    if (persist && !isSidebarLocked(side)) {
      return persistSidebarState(side, {mode: mode});
    }
  };

  // Initial cleanup: strip any stale dropdown wiring left behind by an
  // older template/JS pair (cache, FOUC of older asset version).
  disposeSidebarDropdowns();

  // Seed lastExpandedMode for both sides so the very first toggle
  // out of an initially-collapsed page lands on the correct expanded
  // mode (mini vs full).
  SIDES.forEach((side) => {
    const initial = getSidebarMode(side);
    if (initial !== 'collapsed') {
      document.body.dataset[lastExpandedKey(side)] = initial;
    }
  });

  window.cjToggleSidebar = function(side) {
    if (!SIDES.includes(side)) return;
    const w = window.innerWidth || document.documentElement.clientWidth;
    if (w < 992) {
      document.body.classList.toggle(openClass(side));
      return;
    }
    if (isSidebarLocked(side)) return;
    const cur = getSidebarMode(side);
    if (cur === 'collapsed') {
      const restore = document.body.dataset[lastExpandedKey(side)] || 'full';
      cjSetSidebarMode(side, SIDEBAR_MODES.includes(restore) && restore !== 'collapsed' ? restore : 'full');
    } else {
      cjSetSidebarMode(side, 'collapsed');
    }
  };

  // Close mobile sidebar overlay on backdrop click (both sides).
  document.addEventListener('click', function(e) {
    SIDES.forEach((side) => {
      if (document.body.classList.contains(openClass(side)) &&
          !e.target.closest('#cj-sidebar-' + side) &&
          !e.target.closest('#cj-sidebar-' + side + '-toggle')) {
        document.body.classList.remove(openClass(side));
      }
    });
  });

  // ── Sidebar resize / magnetic snap (desktop only) ──────────
  // Magnetic snap targets: 0 and the mini-mode width. Free drag is
  // only possible above MIN_FREE_W (= MINI_W + SNAP_PX). Below that
  // the sidebar lives in one of the two snap states — there is no
  // free-drag width between 0 and MINI_W.
  //
  // Re-bound on every ``htmx:load`` (idempotent via the
  // ``data-resize-bound`` flag) so the sidebar can drop its
  // ``hx-preserve`` — without that, the rail's per-page active class
  // never updated on boosted navigations.
  const MAX_W = 480;
  const SNAP_PX = 15;

  function bindSidebarResize(side) {
    const handle = document.getElementById('cj-sidebar-' + side + '-resize');
    if (!handle || handle.dataset.resizeBound === '1') return;
    handle.dataset.resizeBound = '1';
    const sidebarEl = document.getElementById('cj-sidebar-' + side);
    if (!sidebarEl) return;
    let startX, startW;

    function miniWidth() {
      const raw = getComputedStyle(document.body).getPropertyValue(miniWidthVar(side)).trim();
      if (raw.endsWith('rem')) return parseFloat(raw) * 16;
      if (raw.endsWith('px')) return parseFloat(raw);
      return 56;
    }

    handle.addEventListener('pointerdown', function(e) {
      if ((window.innerWidth || document.documentElement.clientWidth) < 992) return;
      if (isSidebarLocked(side)) return;
      if (getSidebarMode(side) === 'collapsed') return;
      e.preventDefault();
      startX = e.clientX;
      startW = sidebarEl.getBoundingClientRect().width;
      document.body.classList.add('cj-sidebar-resizing');
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener('pointermove', function(e) {
      if (!document.body.classList.contains('cj-sidebar-resizing')) return;
      // Right-side drag: dragging LEFT = wider, so flip the sign.
      const delta = side === 'left' ? (e.clientX - startX) : (startX - e.clientX);
      const target = startW + delta;
      const MINI_W = miniWidth();
      const MIN_FREE_W = MINI_W + SNAP_PX;
      let nextMode;
      if (target >= MIN_FREE_W) {
        nextMode = 'full';
        const w = Math.min(MAX_W, Math.max(MIN_FREE_W, target));
        document.body.style.setProperty(widthVar(side), w + 'px');
      } else if (target >= MINI_W - SNAP_PX) {
        nextMode = 'mini';
      } else if (target < SNAP_PX) {
        nextMode = 'collapsed';
      } else {
        // Dead zone — sticky at the last snap.
        return;
      }
      if (getSidebarMode(side) !== nextMode) {
        cjSetSidebarMode(side, nextMode, {persist: false, animate: false});
      }
    });
    handle.addEventListener('pointerup', async function(e) {
      if (!document.body.classList.contains('cj-sidebar-resizing')) return;
      handle.releasePointerCapture(e.pointerId);
      document.body.classList.remove('cj-sidebar-resizing');
      const finalMode = getSidebarMode(side);
      const payload = {mode: finalMode};
      if (finalMode === 'full') {
        payload.width = Math.round(sidebarEl.getBoundingClientRect().width) + 'px';
      }
      await persistSidebarState(side, payload);
    });
    handle.addEventListener('dblclick', async function() {
      if (isSidebarLocked(side)) return;
      const def = document.body.dataset['defaultSidebar' + cap(side) + 'Width'] || DEFAULT_WIDTH[side];
      document.body.style.setProperty(widthVar(side), def);
      await persistSidebarState(side, {mode: 'full', width: def});
      // Apply mode locally without re-posting (just persisted above).
      cjSetSidebarMode(side, 'full', {persist: false});
    });
  }

  function bindAllSidebarResizes() {
    SIDES.forEach(bindSidebarResize);
  }
  bindAllSidebarResizes();
  document.body.addEventListener('htmx:load', bindAllSidebarResizes);

  // ── Sortable ────────────────────────────────────────────────
  // Initialise Sortable.js on every `.sortable` container under `root`.
  //
  // Persistence is fully declarative — the container is expected to carry
  // `hx-post` + `hx-trigger="end"` (rendered by `{% sortable_attrs %}`),
  // and Sortable.js' native `end` DOM event triggers the HTMX request. No
  // onEnd callback or htmx.ajax glue is needed here.
  //
  // Re-initialised on `htmx:load` so that swapped-in subtrees pick up the
  // behaviour automatically. Idempotent via the `_cjSortableInited` flag.
  function initSortables(root) {
    if (!root || !root.querySelectorAll) return;
    const containers = root.querySelectorAll('.sortable');
    containers.forEach((el) => {
      if (el._cjSortableInited) return;
      const handle = el.dataset.sortableHandle || '.handle';
      new Sortable(el, {
        animation: 150,
        ghostClass: 'bg-info',
        handle: handle
      });
      el._cjSortableInited = true;
    });
  }
  initSortables(document.body);
  document.body.addEventListener('htmx:load', (e) => initSortables(e.target));

  // -------------- Bootstrap tooltips --------------
  // Tabler/Bootstrap tooltips are opt-in: any element with
  // `data-bs-toggle="tooltip"` needs an explicit
  // `new bootstrap.Tooltip(el)` call. We do that on every page load
  // and on every htmx swap, idempotent via `_cjTooltipInited`.
  function initTooltips(root) {
    if (!root || !root.querySelectorAll) return;
    if (typeof bootstrap === 'undefined' || !bootstrap.Tooltip) return;
    const targets = root.querySelectorAll('[data-bs-toggle="tooltip"]');
    targets.forEach((el) => {
      if (el._cjTooltipInited) return;
      new bootstrap.Tooltip(el);
      el._cjTooltipInited = true;
    });
  }
  initTooltips(document.body);
  document.body.addEventListener('htmx:load', (e) => initTooltips(e.target));

  // -------------- CSRF for HTMX requests --------------
  // Django requires a CSRF token on every state-changing request. For
  // classic <form>-based POSTs the {% csrf_token %} hidden input does
  // the job. HTMX requests issued from a plain element (e.g. a row
  // action's <button hx-post=…>) carry no form, so without help here
  // they hit the server with no token and get a 403.
  //
  // Wire the token globally via htmx:configRequest so every non-GET
  // request gets ``X-CSRFToken`` added. The token is read fresh on
  // each request because hx-boost body swaps replace the
  // {% csrf_token %} hidden input with a new node.
  document.addEventListener('htmx:configRequest', (e) => {
    const method = (e.detail.verb || 'get').toLowerCase()
    if (method === 'get' || method === 'head' || method === 'options') return
    if (e.detail.headers && e.detail.headers['X-CSRFToken']) return
    const input = document.querySelector('[name=csrfmiddlewaretoken]')
    const token = input ? input.value : ''
    if (token) {
      e.detail.headers = e.detail.headers || {}
      e.detail.headers['X-CSRFToken'] = token
    }
  })

  // -------------- Modals --------------
  // Based on Benoit Blanchon's django-htmx modal pattern:
  // https://blog.benoitblanchon.fr/django-htmx-modal-form/
  //
  // Contract:
  //   • A trigger fetches a modal view with `hx-target="#dialog"` and
  //     `hx-swap="innerHTML"`. The view returns the inner dialog
  //     HTML (typically `conjunto/modal_form.html`).
  //   • `htmx:afterSwap` on `#dialog` → show the Bootstrap modal.
  //   • A 204 No Content response targeting `#dialog` → close the
  //     modal. This is the `ModalFormViewMixin` success flow: on
  //     save, the view returns 204 with `HX-Trigger: <event>` and
  //     no body, the listener cancels the swap so the form element
  //     stays put through the close animation, and Bootstrap hides
  //     the modal.
  //   • On `hidden.bs.modal`, wipe `#dialog` so the next open starts
  //     from a clean slate.
  //
  // All lookups must happen on each event — never cache `#modal` or
  // its `Modal` instance in a closure. `hx-boost` swaps the body's
  // innerHTML on every navigation, replacing `#modal` with a fresh
  // node; a captured reference would point at the detached old node
  // and `show()`/`hide()` would silently no-op after the first nav.
  // Bootstrap modal events bubble, so `shown.bs.modal` /
  // `hidden.bs.modal` are bound via delegation on `document`.
  function getBsModal() {
    const el = document.getElementById('modal')
    if (!el) return null
    return (window.bootstrap || window.tabler).Modal.getOrCreateInstance(el)
  }

  document.addEventListener('htmx:beforeSwap', (e) => {
    // 204 No Content from any element inside the modal → close it.
    // The check uses .closest('#modal') (not target.id === 'dialog')
    // because the form's submit request has hx-target="this", which
    // makes target be the <form id="modal-form">, NOT #dialog. We
    // want both flows to work:
    //   • open flow: GET → swap into #dialog → afterSwap → show
    //   • submit flow: POST → 204 → beforeSwap → hide
    // Status code is checked instead of `xhr.response`/`xhr.responseText`
    // because `xhr.response` can be falsy depending on responseType
    // even for valid bodies, which would wrongly cancel the swap.
    const target = e.detail.target
    if (target && target.closest && target.closest('#modal') && e.detail.xhr.status === 204) {
      getBsModal()?.hide()
      e.detail.shouldSwap = false
    }
  })

  document.addEventListener('htmx:afterSwap', (e) => {
    // Open flow: a non-empty response was swapped into #dialog →
    // show the modal. Restricted to target.id === 'dialog' so that
    // form submits whose response gets swapped into the form
    // itself (hx-target="this") do not re-trigger show().
    if (e.detail.target.id === 'dialog') {
      getBsModal()?.show()
    }
  })

  // Explicit close trigger for response flows that don't use the
  // 204-into-#modal convention. The row-remove delete strategy in
  // `HtmxDeleteView` returns 200 with HX-Retarget pointing at the
  // <tr>, which means the modal-close heuristic above won't fire
  // (target is no longer inside #modal). The server therefore
  // emits a `closeModal` HX-Trigger event; we listen on body and
  // hide() unconditionally — harmless when no modal is open.
  document.body.addEventListener('closeModal', () => getBsModal()?.hide())

  // Focus the first visible input/textarea/submit after the modal
  // is shown, so keyboard users land somewhere useful.
  document.addEventListener('shown.bs.modal', (e) => {
    if (e.target.id !== 'modal') return
    const selectors = [
      'textarea:not([type="hidden"])',
      'input:not([type="hidden"])',
      'button[type="submit"]',
    ]
    for (const sel of selectors) {
      for (const el of e.target.querySelectorAll(sel)) {
        if (!el.hidden && !el.disabled) {
          el.focus()
          return
        }
      }
    }
  })

  // Clean up the dialog on close so stale form state does not
  // leak into the next open.
  document.addEventListener('hidden.bs.modal', (e) => {
    if (e.target.id !== 'modal') return
    const dialog = document.getElementById('dialog')
    if (dialog) dialog.innerHTML = ''
  })

  // // Litepicker
  // const litepickers = document.querySelectorAll('.textinput');
  // console.log("registering ",litepickers)
  // litepickers.forEach((litepicker) => {
  //   new Litepicker({
  //     element: litepicker
  //   });
  // })

  // Theme toggle lives in conjunto/js/theme_toggle.js and is loaded
  // conditionally via ``conjunto_app_scripts`` when the
  // ``CONJUNTO_THEME_SWITCHER`` setting is enabled.

  // ── django_tomselect + HTMX integration ────────────────────
  // All hooks survive HTMX swaps; init is idempotent
  // per TomSelect instance via the ``_cjTomSelectInited`` flag. No-op
  // when django_tomselect is not installed.
  //
  //   1. ts-hidden-accessible leak (always on, no opt-in flag):
  //      django_tomselect leaks the ``ts-hidden-accessible`` (sr-only)
  //      class onto ``.ts-wrapper`` when a widget is re-initialised
  //      after a swap. The wrapper becomes 1×1 px clipped and the
  //      whole input disappears. Strip the class on every swap.
  //

  function setupTomSelectClearOnAdd(scope) {
    if (!scope || !scope.querySelectorAll) return;
    scope.querySelectorAll('select').forEach((s) => {
      const ts = s.tomselect;
      if (!ts || ts._cjTomSelectClearOnAddInited) return;
      if (ts.settings && ts.settings.mode !== 'multi') return;
      ts._cjTomSelectClearOnAddInited = true;
      ts.on('item_add', function () {
        ts.setTextboxValue('');
      });
    });
  }

  function processTomSelectSwap(target) {
    if (!(target instanceof Element)) return;

    target.querySelectorAll('.ts-wrapper.ts-hidden-accessible').forEach((w) => {
      w.classList.remove('ts-hidden-accessible');
    });

    setupTomSelectClearOnAdd(target);
  }

  setupTomSelectClearOnAdd(document.body);
  document.body.addEventListener('htmx:afterSwap', (e) => {
    processTomSelectSwap(e.detail && e.detail.target);
  });
})();
