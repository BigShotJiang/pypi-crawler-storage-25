"""Template tags emitting the HTMX wiring for Sortable.js drag-and-drop lists.

The pattern follows https://htmx.org/examples/sortable/: Sortable.js
dispatches a native ``end`` DOM event on the container after a drop;
HTMX listens to it via ``hx-trigger="end"`` and POSTs the form data
(hidden ``pks`` inputs) in current DOM order. No custom JavaScript is
required — only ``Sortable.create()`` initialization, which conjunto's
shipped ``conjunto.js`` already takes care of via the ``.sortable``
selector.
"""

from __future__ import annotations

from django import template
from django.utils.html import format_html

register = template.Library()


@register.simple_tag
def sortable_attrs(reorder_url, handle: str = ".handle", indicator: str = ""):
    """Render the container attributes for a Sortable + HTMX list.

    Emits the ``sortable`` CSS class (so conjunto's JS picks it up) plus the
    HTMX attributes that POST the new order to ``reorder_url`` whenever
    Sortable.js fires its native ``end`` event::

        <ul {% sortable_attrs reorder_url=reorder_url %}>
          ...
        </ul>

    ``handle`` is forwarded to Sortable.js via a data attribute so consumers
    can opt into a different drag-handle selector. ``indicator`` is an
    optional CSS selector for an HTMX indicator element.
    """
    if indicator:
        return format_html(
            'class="sortable" hx-post="{}" hx-trigger="end" '
            'hx-include="[name=\'pks\']" hx-swap="none" '
            'hx-indicator="{}" data-sortable-handle="{}"',
            reorder_url,
            indicator,
            handle,
        )
    return format_html(
        'class="sortable" hx-post="{}" hx-trigger="end" '
        'hx-include="[name=\'pks\']" hx-swap="none" '
        'data-sortable-handle="{}"',
        reorder_url,
        handle,
    )


@register.simple_tag
def sortable_item(obj):
    """Render the hidden PK input for a single sortable item.

    Place inside each row of a sortable list so the browser sends the items
    in their current DOM order on drop::

        <li class="card">
          {% sortable_item agenda %}
          ...
        </li>
    """
    return format_html('<input type="hidden" name="pks" value="{}">', obj.pk)
