"""Generic HTMX view that persists a new order for a sortable model."""

from __future__ import annotations

from django.http import HttpResponse, HttpResponseBadRequest
from django.views import View
from django_htmx.http import trigger_client_event

from conjunto.htmx.views import HtmxRequestMixin
from conjunto.views import AutoPermissionsViewMixin


class SortableReorderView(AutoPermissionsViewMixin, HtmxRequestMixin, View):
    """Re-number ``weight`` for a list of items based on POSTed PK order.

    Wire format follows the pattern from https://htmx.org/examples/sortable/:
    a hidden ``<input type="hidden" name="pks" value="{pk}">`` per item is
    POSTed in current DOM order. The view reads ``request.POST.getlist("pks")``
    and assigns ``weight = (i + 1) * weight_step`` to each item, persisting
    via :meth:`~django.db.models.QuerySet.bulk_update`.

    Subclass attributes:

    ``model``
        Required. The :class:`~conjunto.sortable.SortableModelMixin` subclass
        being reordered. The view does not enforce inheritance — any model
        with a ``weight`` integer field works — but :class:`SortableModelMixin`
        is the supported public contract.

    ``parent_field``
        Optional. Name of a FK field used to scope the queryset to a single
        parent (e.g. ``"meeting"`` for ``Meeting → Agenda``). When set,
        ``parent_url_kwarg`` must also be set.

    ``parent_url_kwarg``
        Name of the URL kwarg that carries the parent's PK.

    ``success_event``
        Optional. If set, the response carries an ``HX-Trigger`` with this
        event name so other parts of the page can refetch themselves.

    ``weight_step``
        Step size between consecutive weight values. Default ``10`` — leaves
        gaps for manual insertions between two items.

    Permissions default to ``change_<model>`` via
    :class:`~conjunto.views.AutoPermissionsViewMixin`. HTMX-only access is
    enforced by :class:`~conjunto.htmx.views.HtmxRequestMixin`.
    """

    model = None
    parent_field: str | None = None
    parent_url_kwarg: str | None = None
    success_event: str | None = None
    weight_step: int = 10
    _permissions_verb = "change"

    def get_queryset(self, **kwargs):
        """Return the queryset of items eligible for reordering.

        When ``parent_field`` is set, the queryset is scoped to the parent
        identified by ``kwargs[parent_url_kwarg]``. Items belonging to other
        parents are silently excluded — never re-numbered.
        """
        qs = self.model._default_manager.all()
        if self.parent_field and self.parent_url_kwarg:
            parent_pk = kwargs.get(self.parent_url_kwarg)
            if parent_pk is None:
                return qs.none()
            qs = qs.filter(**{self.parent_field: parent_pk})
        return qs

    def post(self, request, *args, **kwargs):
        if self.model is None:
            raise ValueError(
                f"{type(self).__name__} requires a `model` class attribute."
            )

        raw_pks = request.POST.getlist("pks")
        if not raw_pks:
            return HttpResponseBadRequest("Missing 'pks' in POST data.")

        # Parse to int and drop unparseable entries — defends against
        # malformed input without raising.
        ordered_pks: list[int] = []
        for raw in raw_pks:
            try:
                ordered_pks.append(int(raw))
            except (TypeError, ValueError):
                continue
        if not ordered_pks:
            return HttpResponseBadRequest("No valid PKs in 'pks'.")

        # Restrict to items that belong to the queryset (and the parent
        # scope, if configured). Cross-parent PKs are silently ignored.
        items_by_pk = {
            obj.pk: obj
            for obj in self.get_queryset(**kwargs).filter(pk__in=ordered_pks)
        }

        to_update = []
        for index, pk in enumerate(ordered_pks):
            obj = items_by_pk.get(pk)
            if obj is None:
                continue
            new_weight = (index + 1) * self.weight_step
            if obj.weight != new_weight:
                obj.weight = new_weight
                to_update.append(obj)

        if to_update:
            self.model._default_manager.bulk_update(to_update, ["weight"])

        response = HttpResponse(status=204)
        if self.success_event:
            trigger_client_event(response, self.success_event)
        return response
