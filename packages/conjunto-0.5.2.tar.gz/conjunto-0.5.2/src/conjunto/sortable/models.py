"""Abstract model mixin that adds a ``weight`` field for manual sorting."""

from __future__ import annotations

from django.db import models
from django.db.models import Max


class SortableModelMixin(models.Model):
    """Abstract base class for models that should be drag-and-drop sortable.

    Adds a ``weight`` :class:`~django.db.models.PositiveIntegerField` (default
    ``0``, indexed) and orders queries by ``("weight", "pk")``. Pair the model
    with :class:`conjunto.sortable.SortableReorderView` to persist a new order
    via HTMX.

    Subclasses can override ``Meta.ordering``::

        class Agenda(SortableModelMixin, models.Model):
            ...

            class Meta(SortableModelMixin.Meta):
                ordering = ("weight", "title")
    """

    weight = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        abstract = True
        ordering = ("weight", "pk")

    @classmethod
    def next_weight(cls, step: int = 10, **filter_kwargs) -> int:
        """Return the next free weight value for a new instance.

        Convenience helper for ``save()`` overrides that auto-append new rows
        at the end of a list. Pass ``**filter_kwargs`` to scope the lookup to
        a specific parent (e.g. ``meeting=meeting``)::

            def save(self, *args, **kwargs):
                if not self.pk:
                    self.weight = type(self).next_weight(meeting=self.meeting)
                super().save(*args, **kwargs)
        """
        current_max = (
            cls.objects.filter(**filter_kwargs).aggregate(m=Max("weight"))["m"] or 0
        )
        return current_max + step
