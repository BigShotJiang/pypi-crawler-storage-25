"""Reusable drag-and-drop sortable lists for FK-linked models with ``weight``.

This package provides three pieces that work together:

1. ``sortable.SortableModelMixin`` — adds a ``weight`` ``PositiveIntegerField`` and the
   ``next_weight()`` helper to a Django model.
2. ``sortable.SortableReorderView`` — generic POST view that re-numbers ``weight``
   values via ``bulk_update`` based on a list of PKs sent in DOM order.
3. ``{% sortable_attrs %}`` and ``{% sortable_item %}`` template tags that
   emit the HTMX wiring for the htmx.org Sortable.js pattern.

See ``docs/usage/sortable.md`` for the full API and a usage example.
"""
