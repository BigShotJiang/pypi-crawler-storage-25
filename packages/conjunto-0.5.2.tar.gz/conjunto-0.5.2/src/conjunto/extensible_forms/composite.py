"""Generic master + plugin sub-forms composite.

Subclass per master model; configure the four ``ClassVar``s and the
``field_slot_map``. See ``docs/extensible_forms.md`` for the contract.
"""

from __future__ import annotations

import json
from typing import ClassVar, Type

from django import forms
from django.core.serializers.json import DjangoJSONEncoder
from django.db import transaction


class CompositeForm:
    """Compose one ``master_form_class`` with N plugin sub-forms.

    Sub-form discovery iterates ``section_interface`` (a GDAPS ``Interface``
    subclass). Each sub-form is instantiated with ``prefix=instance_attr``
    so rendered field names become ``{instance_attr}-{name}``. On save the
    master is persisted first, then each sub-form's instance is linked via
    ``setattr(obj, owner_attr, master_instance)`` and saved.
    """

    #: ``ModelForm`` (or ``Form``) class for the master half.
    master_form_class: ClassVar[Type[forms.BaseForm]]

    #: GDAPS ``Interface`` subclass whose impls feed this composite.
    section_interface: ClassVar[Type]

    #: Attribute name on each sub-form's model that holds the FK back to the
    #: master instance (e.g. ``"patient"`` for ``PatientAT.patient``).
    owner_attr: ClassVar[str]

    #: Namespace prefix for the custom Alpine event vocabulary
    #: (``"<namespace>:set"``, ``"<namespace>:invalidate"``).
    event_namespace: ClassVar[str]

    #: Mapping master-field name → slot enum member. Fields not in the map
    #: bucket into the last enum member (convention: EXTRA).
    field_slot_map: ClassVar[dict]

    def __init__(self, *, data=None, files=None, instance=None, request=None):
        master_kwargs: dict = {"data": data, "files": files}
        if issubclass(self.master_form_class, forms.ModelForm):
            master_kwargs["instance"] = instance
        self.master = self.master_form_class(**master_kwargs)
        self._subforms: list[tuple[type, forms.BaseForm]] = []
        for impl in self.section_interface:
            if impl.form_class is None:
                continue
            if impl.check is not None and request is not None:
                try:
                    if not impl.check(request):
                        continue
                except Exception:  # noqa: BLE001 — never block on plugin gate
                    continue
            sub_kwargs: dict = {
                "data": data,
                "files": files,
                "prefix": impl.instance_attr,
            }
            if issubclass(impl.form_class, forms.ModelForm):
                sub_kwargs["instance"] = self._resolve_instance(instance, impl)
            sub = impl.form_class(**sub_kwargs)
            self._subforms.append((impl, sub))

    @staticmethod
    def _resolve_instance(master_instance, impl):
        """Resolve the sub-form's bound instance.

        Returns:
            - The existing related row for updates (``getattr(master_instance,
              impl.instance_attr, None)``).
            - A freshly constructed ``impl.form_class.Meta.model()`` for creates
              against a ``ModelForm`` sub-form.
            - ``None`` if no ``master_instance`` is given AND the sub-form is a
              plain ``forms.Form`` (no ``Meta.model``). The composite's
              ``__init__`` then skips passing ``instance=`` to the sub-form.
        """
        if master_instance is None:
            return None
        existing = getattr(master_instance, impl.instance_attr, None)
        if existing is not None:
            return existing
        # For ModelForms, create a fresh model instance; for plain Forms None.
        model = getattr(getattr(impl.form_class, "Meta", None), "model", None)
        if model is not None:
            return model()
        return None

    def is_valid(self) -> bool:
        """Validate master and ALL sub-forms so users see all errors at once."""
        master_ok = self.master.is_valid()
        sub_results = [sub.is_valid() for _, sub in self._subforms]
        return master_ok and all(sub_results)

    @transaction.atomic
    def save(self):
        """Save master first, then link and save each sub-form."""
        master_instance = self.master.save()
        for impl, sub in self._subforms:
            model = getattr(getattr(sub, "Meta", None), "model", None)
            if model is None:
                continue
            obj = sub.save(commit=False)
            setattr(obj, self.owner_attr, master_instance)
            obj.save()
            # M2M fields on sub-forms are not handled — add ``sub.save_m2m()``
            # if a future sub-form needs M2M support.
        return master_instance

    @property
    def media(self):
        m = self.master.media
        for _, sub in self._subforms:
            m = m + sub.media
        return m

    def initial_json(self) -> str:
        """JSON literal for ``x-data='extensibleForm({…})'``.

        Master keys are bare; sub-form keys are ``{prefix}-{name}``. Values
        use ``BoundField.value()`` so data > initial > model-default
        precedence is honoured. Encoded with ``DjangoJSONEncoder`` for
        date / decimal / UUID round-tripping.
        """
        values: dict[str, object] = {}
        for name in self.master.fields:
            values[name] = self.master[name].value()
        for impl, sub in self._subforms:
            prefix = impl.instance_attr
            for name in sub.fields:
                values[f"{prefix}-{name}"] = sub[name].value()
        return json.dumps(values, cls=DjangoJSONEncoder, ensure_ascii=False)

    def as_crispy(self) -> str:
        """Build one synthetic ``Form`` carrying all visible fields with the
        correct prefix; render it with :func:`build_slot_layout`."""
        from crispy_forms.helper import FormHelper
        from crispy_forms.utils import render_crispy_form

        from .layout import build_slot_layout

        all_fields: dict = {}
        all_initial: dict = {}
        for name, field in self.master.fields.items():
            all_fields[name] = field
            all_initial[name] = self.master[name].value()
        for impl, sub in self._subforms:
            for name, field in sub.fields.items():
                key = f"{impl.instance_attr}-{name}"
                all_fields[key] = field
                all_initial[key] = sub[name].value()

        class _RenderForm(forms.Form):
            pass

        bound = _RenderForm(data=None, initial=all_initial)
        bound.fields = all_fields
        helper = FormHelper()
        helper.form_tag = False
        helper.disable_csrf = True
        helper.layout = build_slot_layout(self)
        return render_crispy_form(bound, helper=helper)

    def __str__(self):
        return self.as_crispy()
