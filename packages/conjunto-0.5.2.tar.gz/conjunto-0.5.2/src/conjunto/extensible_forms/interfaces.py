"""Plugin-section contract for :class:`CompositeForm`.

Concrete owner plugins combine this mix-in with ``gdaps.api.Interface`` to
create a discoverable interface tied to their composite form::

    class IPatientFormSection(FormSectionContract, Interface):
        __sort_attribute__ = "weight"
        __instantiate_plugins__ = False
"""

from __future__ import annotations

from typing import Callable, Optional


class FormSectionContract:
    """Attributes every plugin section must (or may) declare.

    Not a Django ``Form``, not a GDAPS ``Interface`` — a plain mix-in so the
    concrete owner-plugin interface stays a regular GDAPS Interface subclass
    that GDAPS auto-discovers via ``__subclasses__``.
    """

    #: ``ModelForm`` (or plain ``Form``) class instantiated by the composite.
    form_class: type = None

    #: Attribute on the master instance that holds the related profile row
    #: (e.g. ``"austria"`` for ``patient.austria``). Doubles as the form
    #: ``prefix`` so rendered field names become ``{instance_attr}-{name}``.
    instance_attr: str = ""

    #: Slot the contribution renders in. Must be a member of the owner's
    #: :class:`FormSlot` subclass. Defaults to ``None`` (= EXTRA fallback)
    #: so an undeclared contribution never displaces master fields.
    slot = None

    #: Sort weight inside a slot, ascending. Lower comes first.
    weight: int = 100

    #: Optional ``(request) -> bool`` gate (e.g. tenant scoped settings).
    check: Optional[Callable] = None
