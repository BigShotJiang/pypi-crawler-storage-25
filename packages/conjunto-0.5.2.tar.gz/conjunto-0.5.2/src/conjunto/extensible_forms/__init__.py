"""Reusable composite-form framework.

A master form (``ModelForm``) combined with N plugin-contributed sub-forms,
rendered flat into one ``<form>`` so the tab order follows DOM order. See
``docs/extensible_forms.md`` for the author guide.
"""

from .composite import CompositeForm
from .interfaces import FormSectionContract
from .layout import build_slot_layout
from .slots import FormSlot

__all__ = [
    "CompositeForm",
    "FormSectionContract",
    "FormSlot",
    "build_slot_layout",
]
