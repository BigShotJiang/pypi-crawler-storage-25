"""Abstract base for typed form-slot enums.

Concrete owner plugins declare their slots by subclassing :class:`FormSlot`::

    class PatientFormSlot(FormSlot):
        NAME = "name", _("Name")
        IDENTIFICATION = "identification", _("Identification")
        ...
        EXTRA = "extra", _("Extra")

By convention the **last** declared member is the catch-all (``EXTRA``); the
layout builder uses it as the default bucket for unmapped master fields.
"""

from django.db import models


class FormSlot(models.TextChoices):
    """Marker base for slot enums. Subclasses are normal ``TextChoices``."""

    class Meta:
        abstract = True
