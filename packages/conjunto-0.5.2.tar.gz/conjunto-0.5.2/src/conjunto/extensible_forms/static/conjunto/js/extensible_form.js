// Generic Alpine component for ``CompositeForm`` master+sub forms.
//
// Each form is one component instance owning a reactive ``fields`` object.
// Plugins write to master fields via custom events; the owner plugin picks
// the event namespace (e.g. ``patient-form``, ``family-history-form``) and
// renders the listener via ``{% extensible_form_attrs composite %}``.
//
// Event vocabulary (cross-plugin):
//   <namespace>:set         detail = { name, value, only_if_empty? }
//   <namespace>:invalidate  detail = { name, message }
"use strict";

window.extensibleForm = function (initial) {
    return {
        fields: Object.assign({}, initial || {}),

        onSetField(event) {
            const detail = event.detail || {};
            const name = detail.name;
            if (!name) return;
            if (detail.only_if_empty && this.fields[name]) return;
            this.fields[name] = detail.value;
        },
    };
};
