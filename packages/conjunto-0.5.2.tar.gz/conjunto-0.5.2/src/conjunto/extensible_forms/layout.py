"""Build a flat crispy ``Layout`` from a :class:`CompositeForm`."""

from __future__ import annotations

from crispy_forms.layout import Field, Layout


def build_slot_layout(composite) -> Layout:
    """Walk every master + sub-form field, ordered by slot declaration then
    by section weight inside each slot.

    Master-field → slot mapping is read from ``composite.field_slot_map``.
    Master fields without an entry fall back into the **last** enum member
    (convention: EXTRA). Sub-forms render after master fields within their
    slot, sorted by ``section.weight`` ascending.
    """
    slot_enum = _infer_slot_enum(composite)
    fallback_slot = list(slot_enum)[-1]

    master_in_slot: dict = {s: [] for s in slot_enum}
    for name in composite.master.fields:
        slot = composite.field_slot_map.get(name, fallback_slot)
        master_in_slot[slot].append(name)

    subs_in_slot: dict = {s: [] for s in slot_enum}
    for impl, sub in composite._subforms:
        target = impl.slot if impl.slot is not None else fallback_slot
        subs_in_slot[target].append((impl, sub))
    for s in subs_in_slot:
        subs_in_slot[s].sort(key=lambda pair: pair[0].weight)

    items: list = []
    for slot in slot_enum:
        for name in master_in_slot[slot]:
            items.append(Field(name))
        for impl, sub in subs_in_slot[slot]:
            for fname in sub.fields:
                items.append(Field(f"{impl.instance_attr}-{fname}"))
    return Layout(*items)


def _infer_slot_enum(composite):
    """Pick the slot enum class from either ``field_slot_map`` values or
    the first section's ``slot`` attribute. Empty composites (no master
    fields mapped, no sections registered) raise ``ValueError`` — the
    config is incomplete and would render an empty form silently."""
    for v in composite.field_slot_map.values():
        return type(v)
    for impl, _ in composite._subforms:
        if impl.slot is not None:
            return type(impl.slot)
    raise ValueError(
        f"{type(composite).__name__}: cannot infer slot enum — populate "
        f"``field_slot_map`` or register at least one IFormSection."
    )
