"""Template tag emitting the canonical Alpine wiring for a CompositeForm."""

from django import template
from django.utils.html import escape
from django.utils.safestring import mark_safe

register = template.Library()


@register.simple_tag
def extensible_form_attrs(composite):
    """Return the ``x-data`` + namespaced ``@…:set.window`` listener attrs.

    Usage::

        <form {% extensible_form_attrs composite %} method="post">

    ``composite.event_namespace`` decides the listener name
    (``patient-form`` → ``@patient-form:set.window``). The initial JSON is
    HTML-escaped inside the ``x-data`` single quotes so user-controlled
    values cannot break out of the attribute.
    """
    initial_json = escape(composite.initial_json())
    return mark_safe(
        f"x-data='extensibleForm({initial_json})' "
        f'@{composite.event_namespace}:set.window="onSetField($event)"'
    )
