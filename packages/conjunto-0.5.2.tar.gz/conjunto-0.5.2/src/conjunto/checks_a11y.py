"""Accessibility system checks (A001–A004).

Run via ``python manage.py check --tag a11y``. The checks scan template
files and the rendered DOM (via crispy-forms inspection) for the most
common WCAG 2.1 violations that hand-rolled markup tends to introduce.

These checks are *advisory*: they report issues, they don't block startup.
CI hook (``--fail-level WARNING``) enforces them on PRs; existing
violations live in ``docs/a11y-debt.md`` whitelisted by id+file+line.

Severity matrix:

- ``A001`` — clickable non-button (``<div hx-*>`` / ``<span onclick>``)
  without ``role="button"`` and ``tabindex="0"``
- ``A002`` — ``<input>`` without an associated ``<label>`` (id+for or wrap)
- ``A003`` — ``<img>`` without ``alt``
- ``A004`` — ``<button>`` with no visible text and no ``aria-label``
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

from django.apps import apps
from django.conf import settings
from django.core.checks import Warning, register

CHECK_TAG = "a11y"


# ─────────────────────────────────────────────────────────────────────
# Template-source scanners
# ─────────────────────────────────────────────────────────────────────

_TEMPLATE_SUFFIX = ".html"

_RE_TAG = re.compile(r"<(?P<tag>[a-zA-Z][a-zA-Z0-9]*)(?P<attrs>[^>]*)>", re.DOTALL)
_RE_ATTR = re.compile(
    r"""(?P<name>[a-zA-Z_:][a-zA-Z0-9_\-:]*)\s*=\s*(?:"(?P<dq>[^"]*)"|'(?P<sq>[^']*)')"""
)
# Request-triggering HTMX attrs — these are the only hx-* attrs that imply a
# user interaction handler on the element. hx-target/-swap/-trigger/-ext/
# ws-connect/hx-swap-oob alone don't make the element clickable.
_RE_HX_REQUEST = re.compile(r"\bhx-(?:get|post|put|delete|patch)\b")
_RE_ONCLICK = re.compile(r"\bonclick\b")
# Events that mean "user did something" — anything else in hx-trigger
# (load, revealed, intersect, <custom-event>, every Ns, …) is non-interactive.
_INTERACTIVE_TRIGGER_EVENTS = {
    "click",
    "dblclick",
    "mousedown",
    "mouseup",
    "mouseover",
    "mouseenter",
    "mouseleave",
    "keydown",
    "keyup",
    "keypress",
    "focus",
    "blur",
    "submit",
    "change",
    "input",
}
# Runtime attr-injection patterns. When a template includes Django's widget
# attrs partial (or crispy's `bootstrap[5]/layout/attrs.html`) or iterates
# `<thing>.attrs.items`, the rendered element has attributes (`id=…`,
# `aria-label=…`, …) that the static scanner cannot see.
_RE_RUNTIME_ATTRS = re.compile(
    r"""django/forms/widgets/attrs\.html
        |bootstrap[0-9]*/layout/attrs\.html
        |\.attrs\.items\b""",
    re.IGNORECASE | re.VERBOSE,
)
# Stripped before scanning — comments don't render to the DOM.
_RE_DJANGO_LINE_COMMENT = re.compile(r"\{#.*?#\}", re.DOTALL)
_RE_DJANGO_BLOCK_COMMENT = re.compile(
    r"\{%\s*comment\b[^%]*%\}.*?\{%\s*endcomment\s*%\}", re.DOTALL
)
_RE_HTML_COMMENT = re.compile(r"<!--.*?-->", re.DOTALL)


def _strip_comments(text: str) -> str:
    """Replace every comment with same-length whitespace so byte offsets
    (used by ``line_of``) stay correct.
    """

    def _blank(match: re.Match) -> str:
        return re.sub(r"[^\n]", " ", match.group(0))

    text = _RE_DJANGO_BLOCK_COMMENT.sub(_blank, text)
    text = _RE_DJANGO_LINE_COMMENT.sub(_blank, text)
    text = _RE_HTML_COMMENT.sub(_blank, text)
    return text


def _iter_app_templates() -> Iterable[Path]:
    """Yield every template file shipped by an app under
    ``<app>/templates/``. Project-level template dirs from
    ``TEMPLATES[*].DIRS`` are scanned too.
    """
    seen: set[Path] = set()
    for app_config in apps.get_app_configs():
        tpl_dir = Path(app_config.path) / "templates"
        if tpl_dir.is_dir():
            for p in tpl_dir.rglob(f"*{_TEMPLATE_SUFFIX}"):
                if p not in seen:
                    seen.add(p)
                    yield p
    for tpl_engine in getattr(settings, "TEMPLATES", []):
        for d in tpl_engine.get("DIRS", []) or []:
            d = Path(d)
            if d.is_dir():
                for p in d.rglob(f"*{_TEMPLATE_SUFFIX}"):
                    if p not in seen:
                        seen.add(p)
                        yield p


def _parse_attrs(blob: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for m in _RE_ATTR.finditer(blob):
        out[m.group("name").lower()] = m.group("dq") or m.group("sq") or ""
    return out


def _is_a11y_debt(template_path: Path, check_id: str, line_no: int) -> bool:
    """Read the project's a11y debt whitelist (if present) and return True
    when (check_id, file, line) is grandfathered.

    Format of ``docs/a11y-debt.md``: lines containing
    ``[A001 path/to/file.html:42]`` are treated as the canonical record.
    """
    debt_path = Path(getattr(settings, "BASE_DIR", "."), "docs", "a11y-debt.md")
    if not debt_path.is_file():
        return False
    try:
        text = debt_path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return False
    needle = f"[{check_id} {template_path.name}:{line_no}]"
    return needle in text


def _scan_template(path: Path) -> list:
    issues = []
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return issues

    text = _strip_comments(text)

    line_starts = [0]
    for i, ch in enumerate(text):
        if ch == "\n":
            line_starts.append(i + 1)

    def line_of(pos: int) -> int:
        # Binary search would be faster, but templates are small.
        for i, start in enumerate(line_starts):
            if start > pos:
                return i
        return len(line_starts)

    for m in _RE_TAG.finditer(text):
        tag = m.group("tag").lower()
        raw_attrs = m.group("attrs") or ""
        attrs = _parse_attrs(raw_attrs)
        ln = line_of(m.start())

        # A001: clickable non-button (div/span with hx-get/post/… or onclick)
        if tag in {"div", "span", "i", "img"}:
            has_onclick = bool(_RE_ONCLICK.search(raw_attrs))
            has_hx_request = bool(_RE_HX_REQUEST.search(raw_attrs))
            # hx-trigger gates interactivity: HTMX default is "click" for
            # non-form elements, but an explicit non-click trigger (load,
            # custom event, …) means the element fires on something other
            # than user action and shouldn't be flagged.
            hx_trigger = attrs.get("hx-trigger", "")
            if hx_trigger:
                tokens = re.findall(r"[a-zA-Z][a-zA-Z0-9_\-]*", hx_trigger)
                triggered_by_user = any(
                    t.lower() in _INTERACTIVE_TRIGGER_EVENTS for t in tokens
                )
            else:
                # No hx-trigger → HTMX default ("click" on non-form els).
                triggered_by_user = has_hx_request
            looks_clickable = has_onclick or (has_hx_request and triggered_by_user)
            if looks_clickable:
                role_ok = attrs.get("role") in {"button", "link", "menuitem", "tab"}
                tabindex_ok = "tabindex" in attrs
                if not (role_ok and tabindex_ok):
                    if not _is_a11y_debt(path, "conjunto.A001", ln):
                        issues.append(
                            Warning(
                                f"{path}:{ln}: <{tag}> with hx-*/onclick is missing "
                                'role="button" and/or tabindex="0".',
                                hint=(
                                    "Use a <button> element, or apply the "
                                    "{% kbd_clickable %} template tag."
                                ),
                                id="conjunto.A001",
                                obj=str(path),
                            )
                        )

        # A003: <img> without alt
        if tag == "img" and "alt" not in attrs:
            if not _is_a11y_debt(path, "conjunto.A003", ln):
                issues.append(
                    Warning(
                        f"{path}:{ln}: <img> without `alt` attribute.",
                        hint=(
                            'Decorative images: alt="". Informative '
                            "images: short, accurate description."
                        ),
                        id="conjunto.A003",
                        obj=str(path),
                    )
                )

        # A004: <button> with no visible text and no aria-label
        if tag == "button":
            # A heuristic: look for the closing </button> within ~512 chars.
            close = text.find("</button>", m.end())
            inner = text[m.end() : close] if close != -1 else ""
            # Skip buttons whose attrs are injected at runtime via a
            # `{% for k, v in <thing>.attrs.items %}…{% endfor %}` loop;
            # aria-label may be set by the caller's RowAction/HeaderAction.
            if _RE_RUNTIME_ATTRS.search(raw_attrs):
                continue
            visible_text = re.sub(r"<[^>]+>", "", inner)
            # {% translate "X" %} / {% trans "X" %} → literal "X".
            visible_text = re.sub(
                r"\{%\s*(?:translate|trans)\s+[\"']([^\"']+)[\"'][^%]*%\}",
                r"\1",
                visible_text,
            )
            # {% blocktranslate %}…{% endblocktranslate %}: keep inner content,
            # only drop the tags themselves.
            visible_text = re.sub(
                r"\{%\s*end?(?:blocktranslate|blocktrans)\b[^%]*%\}",
                "",
                visible_text,
            )
            # {{ var }} renders to something at runtime — count as visible.
            visible_text = re.sub(r"\{\{[^}]+\}\}", "X", visible_text)
            # Drop comments and the remaining non-output statement tags
            # ({% if %}, {% csrf_token %}, …).
            visible_text = re.sub(r"\{#.*?#\}|\{%[^%]+%\}", "", visible_text).strip()
            # An empty `title=""` / `aria-label=""` does not satisfy a11y.
            has_label = bool(attrs.get("aria-label", "").strip()) or bool(
                attrs.get("title", "").strip()
            )
            if not visible_text and not has_label:
                if not _is_a11y_debt(path, "conjunto.A004", ln):
                    issues.append(
                        Warning(
                            f"{path}:{ln}: icon-only <button> without `aria-label` "
                            "or `title`.",
                            hint=(
                                "Add aria-label='…' so screen-reader users know "
                                "what the button does."
                            ),
                            id="conjunto.A004",
                            obj=str(path),
                        )
                    )

    return issues


@register("a11y", deploy=False)
def check_a11y_templates(app_configs, **kwargs):
    """A001 / A002 / A003 / A004 — template-source scan."""
    issues: list = []
    for path in _iter_app_templates():
        # Skip vendored / third-party templates; they are out of our control.
        if any(
            seg in path.parts
            for seg in (
                "_vendor",
                "tinymce",
                "node_modules",
                ".venv",
                ".tox",
                "site-packages",
            )
        ):
            continue
        issues.extend(_scan_template(path))
        issues.extend(_scan_template_for_a002(path))
    return issues


_RE_INPUT = re.compile(
    r"<input\b([^>]*)>",
    re.IGNORECASE,
)
_RE_LABEL_FOR = re.compile(
    r'<label\b[^>]*\bfor\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE
)
_RE_LABEL_OPEN = re.compile(r"<label\b[^>]*>", re.IGNORECASE)
_RE_LABEL_CLOSE = re.compile(r"</label\s*>", re.IGNORECASE)


def _implicit_label_ranges(text: str) -> list[tuple[int, int]]:
    """Return (start, end) char ranges covered by `<label>…</label>` blocks
    so a nested <input> can be treated as implicitly labelled (HTML5).
    """
    opens = [(m.start(), m.end()) for m in _RE_LABEL_OPEN.finditer(text)]
    closes = [m.start() for m in _RE_LABEL_CLOSE.finditer(text)]
    ranges: list[tuple[int, int]] = []
    ci = 0
    for o_start, o_end in opens:
        while ci < len(closes) and closes[ci] < o_end:
            ci += 1
        if ci >= len(closes):
            break
        ranges.append((o_start, closes[ci]))
        ci += 1
    return ranges


def _scan_template_for_a002(path: Path) -> list:
    """A002 — every named <input> needs a <label for=…> with matching id."""
    issues = []
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return issues

    text = _strip_comments(text)

    label_targets = {m.group(1) for m in _RE_LABEL_FOR.finditer(text)}
    label_blocks = _implicit_label_ranges(text)

    line_starts = [0]
    for i, ch in enumerate(text):
        if ch == "\n":
            line_starts.append(i + 1)

    def line_of(pos: int) -> int:
        for i, start in enumerate(line_starts):
            if start > pos:
                return i
        return len(line_starts)

    def in_implicit_label(pos: int) -> bool:
        return any(start <= pos <= end for start, end in label_blocks)

    for m in _RE_INPUT.finditer(text):
        raw = m.group(1)
        attrs = _parse_attrs(raw)
        input_type = attrs.get("type", "text").lower()
        if input_type in {"hidden", "submit", "button", "image", "reset"}:
            continue
        # `aria-hidden="true"` removes the element from the accessibility
        # tree — screen readers skip it, so no label is required.
        if attrs.get("aria-hidden", "").lower() == "true":
            continue
        # Implicit-label wrap (`<label><input …></label>`) is HTML5-valid
        # and a fully accessible labelling mechanism.
        if in_implicit_label(m.start()):
            continue
        # Widget template that delegates attr rendering to Django (e.g.
        # `{% include "django/forms/widgets/attrs.html" %}` or a
        # `{% for k, v in widget.attrs.items %}…{% endfor %}` loop) — the
        # rendered input has `id=…` set, the scanner just can't see it.
        if _RE_RUNTIME_ATTRS.search(raw):
            continue
        # `title="…"` (non-empty) satisfies WAI-ARIA accessible-name
        # calculation when no <label> is present. Suboptimal UX, but valid.
        if attrs.get("title", "").strip():
            continue
        # Skip crispy-rendered fields — those have id_xxx and are handled
        # by Django form widgets which always emit a <label>.
        # We're catching hand-rolled inputs only.
        input_id = attrs.get("id")
        if not input_id:
            # Without an id, no <label for=…> can match. This is
            # already a problem for assistive tech; flag it.
            ln = line_of(m.start())
            if not _is_a11y_debt(path, "conjunto.A002", ln):
                if "aria-label" not in attrs and "aria-labelledby" not in attrs:
                    issues.append(
                        Warning(
                            f"{path}:{ln}: <input> without `id` and without "
                            "`aria-label` or `aria-labelledby`.",
                            id="conjunto.A002",
                            obj=str(path),
                        )
                    )
            continue
        if input_id not in label_targets and (
            "aria-label" not in attrs and "aria-labelledby" not in attrs
        ):
            ln = line_of(m.start())
            if not _is_a11y_debt(path, "conjunto.A002", ln):
                issues.append(
                    Warning(
                        f"{path}:{ln}: <input id='{input_id}'> has no "
                        "matching <label for='{input_id}'> and no "
                        "aria-label/aria-labelledby.",
                        id="conjunto.A002",
                        obj=str(path),
                    )
                )

    return issues
