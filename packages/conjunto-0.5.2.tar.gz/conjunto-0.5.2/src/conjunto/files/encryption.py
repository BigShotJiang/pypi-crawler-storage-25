"""Encrypted file storage primitives.

This module provides the building blocks for :class:`EncryptedFileField`
and :class:`EncryptedImageField` (see :mod:`conjunto.fields`):

* :class:`IFileEncryptionBackend` — the integration seam. Downstream
  projects (e.g. ``medux.crypto``) provide a real KEK/audit backend;
  conjunto ships only an in-memory backend for tests and local dev.
* :class:`Manifest` — fixed-length binary header persisted on a sidecar
  ``<name>_manifest`` ``BinaryField``. Holds the wrapped per-file DEK,
  the STREAM nonce prefix, the key version, the plaintext size and a
  format version byte for future evolution.
* Streaming AES-256-GCM helpers based on Rogaway's STREAM construction
  (12-byte nonce = 7-byte random prefix ∥ 4-byte chunk counter ∥
  1-byte final-flag). Truncation, reordering and bit-flip attacks all
  surface as :class:`cryptography.exceptions.InvalidTag`.
* :func:`migrate_to_encrypted` — bulk re-encryption helper for moving
  plain ``FileField`` / ``ProtectedFileField`` rows to
  :class:`EncryptedFileField` in place.

Threat model and field-level documentation live in
``docs/encrypted-files.md``.
"""

from __future__ import annotations

import importlib
import logging
import os
import struct
import uuid
from dataclasses import dataclass
from threading import RLock
from typing import IO, Iterator, Protocol, runtime_checkable

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from django.db import transaction

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# Constants & layout
# --------------------------------------------------------------------------- #

#: Default plaintext chunk size for STREAM encryption (4 MiB).
DEFAULT_CHUNK_SIZE = 4 * 1024 * 1024

#: Maximum number of chunks per file (uint32 counter).
MAX_CHUNKS = 2**32 - 1

#: AES-GCM authentication tag length.
TAG_LEN = 16

#: AES-GCM nonce length.
NONCE_LEN = 12

#: STREAM nonce prefix length (random per file).
NONCE_PREFIX_LEN = 7

#: AAD used when (un)wrapping the per-file DEK with the tenant KEK.
WRAP_AAD_VERSION = b"conjunto.files/wrap/v1"


# --------------------------------------------------------------------------- #
# Exceptions
# --------------------------------------------------------------------------- #


class FileEncryptionError(Exception):
    """Base class for file-encryption errors."""


class MissingManifestError(FileEncryptionError):
    """Raised when a decrypt is attempted on a row with no manifest set.

    This either means (a) the row was created before encryption was
    enabled and has not been migrated yet (run
    ``manage.py encrypt_filefield``), or (b) the manifest column was
    accidentally cleared. Either way, returning the on-disk bytes as
    "plaintext" would be a silent data-protection failure, so we raise.
    """


class FileTooLargeError(FileEncryptionError):
    """Raised when the plaintext exceeds the configured maximum."""


class BackendNotConfigured(ImproperlyConfigured):
    """Raised when no :class:`IFileEncryptionBackend` is installed."""


# --------------------------------------------------------------------------- #
# Manifest
# --------------------------------------------------------------------------- #


# Fixed binary layout (little-endian network-style):
#
#   +---------+--------+---------------+--------------+---------------+-------------+
#   | magic   | ver    | flags         | key_version  | nonce_prefix  | plain_size  |
#   | 4 bytes | 1 byte | 1 byte        | 2 bytes BE   | 7 bytes       | 8 bytes BE  |
#   +---------+--------+---------------+--------------+---------------+-------------+
#   | wrapped_dek_len  | wrapped_dek (variable, typically 60 bytes)               |
#   | 2 bytes BE       |                                                          |
#   +------------------+----------------------------------------------------------+
#
# Total fixed prefix: 4 + 1 + 1 + 2 + 7 + 8 + 2 = 25 bytes.
# With a typical 60-byte wrapped DEK that's 85 bytes total.
MANIFEST_MAGIC = b"CFE1"
MANIFEST_VERSION = 1
_FIXED_PREFIX = struct.Struct(">4sBBH7sQH")
_FIXED_PREFIX_LEN = _FIXED_PREFIX.size  # 25


@dataclass(frozen=True)
class Manifest:
    """Parsed manifest for an encrypted file.

    See module docstring for the binary layout.
    """

    version: int
    flags: int
    key_version: int
    nonce_prefix: bytes
    plain_size: int
    wrapped_dek: bytes

    def to_bytes(self) -> bytes:
        if len(self.nonce_prefix) != NONCE_PREFIX_LEN:
            raise ValueError(
                f"nonce_prefix must be {NONCE_PREFIX_LEN} bytes, "
                f"got {len(self.nonce_prefix)}"
            )
        return (
            _FIXED_PREFIX.pack(
                MANIFEST_MAGIC,
                self.version,
                self.flags,
                self.key_version,
                self.nonce_prefix,
                self.plain_size,
                len(self.wrapped_dek),
            )
            + self.wrapped_dek
        )

    @classmethod
    def from_bytes(cls, blob: bytes) -> "Manifest":
        if blob is None or len(blob) < _FIXED_PREFIX_LEN:
            raise FileEncryptionError("manifest blob too short")
        magic, version, flags, key_version, nonce_prefix, plain_size, dek_len = (
            _FIXED_PREFIX.unpack(blob[:_FIXED_PREFIX_LEN])
        )
        if magic != MANIFEST_MAGIC:
            raise FileEncryptionError(f"manifest magic mismatch: {magic!r}")
        if version != MANIFEST_VERSION:
            raise FileEncryptionError(f"unsupported manifest version: {version}")
        wrapped = blob[_FIXED_PREFIX_LEN : _FIXED_PREFIX_LEN + dek_len]
        if len(wrapped) != dek_len:
            raise FileEncryptionError("manifest truncated (wrapped DEK)")
        return cls(
            version=version,
            flags=flags,
            key_version=key_version,
            nonce_prefix=bytes(nonce_prefix),
            plain_size=plain_size,
            wrapped_dek=bytes(wrapped),
        )


# --------------------------------------------------------------------------- #
# Backend protocol
# --------------------------------------------------------------------------- #


@runtime_checkable
class IFileEncryptionBackend(Protocol):
    """Pluggable backend interface for tenant-scoped file encryption.

    Implementations are responsible for KEK loading, DEK (un)wrapping and
    audit-log emission. Conjunto knows nothing about KEK storage — that
    is the integrator's job.

    Method contracts:

    * :meth:`get_active_key_version` — return the current key version
      under which new files for ``tenant_id`` should be encrypted.
    * :meth:`wrap_dek` — AES-256-GCM wrap a fresh 32-byte DEK using the
      tenant's KEK. ``aad`` binds the wrap to a logical location
      (model/field/file-uuid/key-version). Returns the wrapped blob.
    * :meth:`unwrap_dek` — reverse of :meth:`wrap_dek`. Must propagate
      :class:`cryptography.exceptions.InvalidTag` on tamper.
    * :meth:`audit_decrypt` — called once per successful
      :meth:`EncryptedFieldFile.open_decrypted`. MUST NOT raise; logging
      / sampling / DB writes are the backend's call.
    """

    def get_active_key_version(self, tenant_id: int | str) -> int: ...

    def wrap_dek(
        self,
        dek: bytes,
        *,
        tenant_id: int | str,
        key_version: int,
        aad: bytes,
    ) -> bytes: ...

    def unwrap_dek(
        self,
        wrapped: bytes,
        *,
        tenant_id: int | str,
        key_version: int,
        aad: bytes,
    ) -> bytes: ...

    def audit_decrypt(
        self,
        *,
        tenant_id: int | str,
        key_version: int,
        model_label: str,
        object_pk: object,
        field_name: str,
        size: int,
    ) -> None: ...


# --------------------------------------------------------------------------- #
# Backend registry
# --------------------------------------------------------------------------- #


_backend_lock = RLock()
_backend: IFileEncryptionBackend | None = None


def set_backend(backend: IFileEncryptionBackend | None) -> None:
    """Install (or clear) the active backend. Mostly used by tests."""
    global _backend
    with _backend_lock:
        _backend = backend


def get_backend() -> IFileEncryptionBackend:
    """Return the configured backend, instantiating it lazily.

    Resolution order:

    1. A backend previously installed via :func:`set_backend`.
    2. ``settings.CONJUNTO_FILE_ENCRYPTION_BACKEND`` — a dotted path to
       a class implementing :class:`IFileEncryptionBackend`.

    Raises :class:`BackendNotConfigured` if neither is available.
    """
    global _backend
    with _backend_lock:
        if _backend is not None:
            return _backend
        dotted = getattr(settings, "CONJUNTO_FILE_ENCRYPTION_BACKEND", None)
        if not dotted:
            raise BackendNotConfigured(
                "EncryptedFileField requires CONJUNTO_FILE_ENCRYPTION_BACKEND "
                "to be set to a dotted path of an IFileEncryptionBackend "
                "implementation (or install one explicitly via "
                "conjunto.files.encryption.set_backend())."
            )
        module_path, _, cls_name = dotted.rpartition(".")
        if not module_path:
            raise ImproperlyConfigured(
                f"CONJUNTO_FILE_ENCRYPTION_BACKEND must be a dotted path, "
                f"got: {dotted!r}"
            )
        module = importlib.import_module(module_path)
        cls = getattr(module, cls_name)
        _backend = cls()
        return _backend


def reset_backend() -> None:
    """Discard the cached backend (used in tests)."""
    set_backend(None)


# --------------------------------------------------------------------------- #
# AAD helpers
# --------------------------------------------------------------------------- #


def build_wrap_aad(
    *, model_label: str, field_name: str, file_uuid: str, key_version: int
) -> bytes:
    """AAD bound into the DEK wrap.

    A swap of the manifest column between (model, field, file-uuid)
    triples fails the GCM tag, because all four pieces are in the AAD.
    No row-pk is included — the file-uuid is the canonical file
    identifier and is already part of the stored file path.
    """
    return f"{model_label}|{field_name}|{file_uuid}|v{key_version}".encode("utf-8")


def _stream_nonce(prefix: bytes, counter: int, is_final: bool) -> bytes:
    """Compose the per-chunk nonce per Rogaway STREAM.

    Layout: ``prefix(7) || counter_be4(4) || final_flag(1)`` = 12 bytes.

    * ``counter`` must monotonically increase from 0 across the chunks
      of a single file (uint32 BE).
    * ``is_final`` MUST be ``True`` for the last chunk and ``False`` for
      all others. Truncating the stream therefore yields the wrong
      final-flag → InvalidTag.
    """
    if len(prefix) != NONCE_PREFIX_LEN:
        raise ValueError("prefix must be 7 bytes")
    if not (0 <= counter <= MAX_CHUNKS):
        raise ValueError("counter overflow (file too large for chunk size)")
    return prefix + counter.to_bytes(4, "big") + (b"\x01" if is_final else b"\x00")


# --------------------------------------------------------------------------- #
# Streaming encrypt / decrypt
# --------------------------------------------------------------------------- #


def encrypt_stream(
    source: IO[bytes],
    dest: IO[bytes],
    *,
    dek: bytes,
    nonce_prefix: bytes,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    max_size: int | None = None,
) -> int:
    """Encrypt ``source`` into ``dest`` using AES-256-GCM-STREAM.

    Returns the number of plaintext bytes consumed. Raises
    :class:`FileTooLargeError` if ``max_size`` is exceeded.

    The stream format is **just a concatenation of ciphertext+tag
    chunks** — there is no per-chunk length prefix because the chunk
    size is fixed (the last chunk is the only short one). Readers must
    use the same ``chunk_size``; this is recorded out-of-band in the
    manifest (currently fixed at :data:`DEFAULT_CHUNK_SIZE`; if we ever
    need a configurable chunk size, store it in the manifest's
    ``flags`` byte).
    """
    aes = AESGCM(dek)
    counter = 0
    plain_total = 0
    pending: bytes | None = None
    while True:
        chunk = source.read(chunk_size)
        if not chunk:
            # source exhausted — flush pending as final chunk
            if pending is not None:
                nonce = _stream_nonce(nonce_prefix, counter, is_final=True)
                dest.write(aes.encrypt(nonce, pending, None))
                counter += 1
            elif counter == 0:
                # empty source: still emit one final empty chunk so the
                # final-flag is asserted at decrypt time.
                nonce = _stream_nonce(nonce_prefix, 0, is_final=True)
                dest.write(aes.encrypt(nonce, b"", None))
                counter = 1
            return plain_total

        if pending is not None:
            # ship the previous (now known non-final) chunk
            nonce = _stream_nonce(nonce_prefix, counter, is_final=False)
            dest.write(aes.encrypt(nonce, pending, None))
            counter += 1
            if counter > MAX_CHUNKS:
                raise FileTooLargeError("STREAM counter overflow")

        pending = chunk
        plain_total += len(chunk)
        if max_size is not None and plain_total > max_size:
            raise FileTooLargeError(f"plaintext exceeds maximum of {max_size} bytes")


def decrypt_stream(
    source: IO[bytes],
    *,
    dek: bytes,
    nonce_prefix: bytes,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
) -> Iterator[bytes]:
    """Yield plaintext chunks from an encrypted stream.

    Each yielded chunk is at most ``chunk_size`` bytes. The final chunk
    may be shorter (including zero bytes for an originally-empty file).

    Raises :class:`cryptography.exceptions.InvalidTag` on any tamper,
    reorder or truncation.
    """
    aes = AESGCM(dek)
    counter = 0
    encrypted_chunk_size = chunk_size + TAG_LEN
    pending: bytes | None = None
    while True:
        encrypted = source.read(encrypted_chunk_size)
        if not encrypted:
            if pending is None:
                raise FileEncryptionError("stream truncated before final chunk")
            # Decrypt the held-back chunk as final.
            nonce = _stream_nonce(nonce_prefix, counter, is_final=True)
            yield aes.decrypt(nonce, pending, None)
            return
        if pending is not None:
            nonce = _stream_nonce(nonce_prefix, counter, is_final=False)
            yield aes.decrypt(nonce, pending, None)
            counter += 1
        pending = encrypted


# --------------------------------------------------------------------------- #
# In-memory backend (tests & local dev only)
# --------------------------------------------------------------------------- #


class InMemoryFileEncryptionBackend:
    """In-process backend used by conjunto's own tests and local dev.

    Generates a random 32-byte KEK per ``(tenant_id, key_version)`` on
    first sight, holds them in a dict. Audit calls are recorded in
    :attr:`audit_log` for assertions.

    **Not for production** — keys are RAM-only and lost on restart.
    """

    def __init__(self) -> None:
        self._keks: dict[tuple[int | str, int], bytes] = {}
        self._active: dict[int | str, int] = {}
        self.audit_log: list[dict] = []

    # -- internal helpers --------------------------------------------- #

    def _kek(self, tenant_id: int | str, key_version: int) -> bytes:
        try:
            return self._keks[(tenant_id, key_version)]
        except KeyError:
            kek = os.urandom(32)
            self._keks[(tenant_id, key_version)] = kek
            self._active.setdefault(tenant_id, key_version)
            return kek

    # -- IFileEncryptionBackend --------------------------------------- #

    def get_active_key_version(self, tenant_id: int | str) -> int:
        if tenant_id not in self._active:
            # bootstrap a v1 KEK for first-time tenants
            self._kek(tenant_id, 1)
            self._active[tenant_id] = 1
        return self._active[tenant_id]

    def wrap_dek(
        self,
        dek: bytes,
        *,
        tenant_id: int | str,
        key_version: int,
        aad: bytes,
    ) -> bytes:
        kek = self._kek(tenant_id, key_version)
        nonce = os.urandom(NONCE_LEN)
        return nonce + AESGCM(kek).encrypt(nonce, dek, WRAP_AAD_VERSION + b"|" + aad)

    def unwrap_dek(
        self,
        wrapped: bytes,
        *,
        tenant_id: int | str,
        key_version: int,
        aad: bytes,
    ) -> bytes:
        if len(wrapped) < NONCE_LEN + TAG_LEN:
            raise FileEncryptionError("wrapped DEK too short")
        kek = self._kek(tenant_id, key_version)
        nonce, ct = wrapped[:NONCE_LEN], wrapped[NONCE_LEN:]
        return AESGCM(kek).decrypt(nonce, ct, WRAP_AAD_VERSION + b"|" + aad)

    def audit_decrypt(
        self,
        *,
        tenant_id: int | str,
        key_version: int,
        model_label: str,
        object_pk: object,
        field_name: str,
        size: int,
    ) -> None:
        self.audit_log.append(
            {
                "tenant_id": tenant_id,
                "key_version": key_version,
                "model_label": model_label,
                "object_pk": object_pk,
                "field_name": field_name,
                "size": size,
            }
        )

    # -- test helpers ------------------------------------------------- #

    def rotate(self, tenant_id: int | str) -> int:
        """Bump the active key version for ``tenant_id`` and return it."""
        new_version = self._active.get(tenant_id, 0) + 1
        self._kek(tenant_id, new_version)
        self._active[tenant_id] = new_version
        return new_version


# --------------------------------------------------------------------------- #
# Helpers used by EncryptedFieldFile
# --------------------------------------------------------------------------- #


def generate_uuid_filename(prefix: str = "") -> str:
    """Return ``"<prefix>/<uuid4>.enc"`` (or just ``"<uuid4>.enc"``)."""
    name = f"{uuid.uuid4().hex}.enc"
    if prefix:
        return f"{prefix.rstrip('/')}/{name}"
    return name


def encrypt_uploaded_file(
    source: IO[bytes],
    dest: IO[bytes],
    *,
    backend: IFileEncryptionBackend,
    tenant_id: int | str,
    model_label: str,
    field_name: str,
    file_uuid: str,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    max_size: int | None = None,
) -> Manifest:
    """Stream-encrypt ``source`` into ``dest``; return the Manifest.

    Caller is responsible for committing ``dest`` to the storage and for
    persisting the returned manifest bytes on the model row.
    """
    key_version = backend.get_active_key_version(tenant_id)
    dek = os.urandom(32)
    nonce_prefix = os.urandom(NONCE_PREFIX_LEN)
    try:
        plain_size = encrypt_stream(
            source,
            dest,
            dek=dek,
            nonce_prefix=nonce_prefix,
            chunk_size=chunk_size,
            max_size=max_size,
        )
        aad = build_wrap_aad(
            model_label=model_label,
            field_name=field_name,
            file_uuid=file_uuid,
            key_version=key_version,
        )
        wrapped = backend.wrap_dek(
            dek, tenant_id=tenant_id, key_version=key_version, aad=aad
        )
    finally:
        # Best-effort wipe of the DEK we held in a bytes object.
        del dek
    return Manifest(
        version=MANIFEST_VERSION,
        flags=0,
        key_version=key_version,
        nonce_prefix=nonce_prefix,
        plain_size=plain_size,
        wrapped_dek=wrapped,
    )


def unwrap_dek_for_read(
    manifest: Manifest,
    *,
    backend: IFileEncryptionBackend,
    tenant_id: int | str,
    model_label: str,
    field_name: str,
    file_uuid: str,
) -> bytes:
    """Unwrap the manifest's DEK using the configured backend."""
    aad = build_wrap_aad(
        model_label=model_label,
        field_name=field_name,
        file_uuid=file_uuid,
        key_version=manifest.key_version,
    )
    return backend.unwrap_dek(
        manifest.wrapped_dek,
        tenant_id=tenant_id,
        key_version=manifest.key_version,
        aad=aad,
    )


# --------------------------------------------------------------------------- #
# Bulk migration helper
# --------------------------------------------------------------------------- #


def migrate_to_encrypted(
    model,
    field_name: str,
    *,
    batch_size: int = 100,
    dry_run: bool = False,
    keep_originals: bool = False,
    tenant_id: int | str | None = None,
    upload_to_prefix: str | None = None,
    progress=None,
) -> dict[str, int]:
    """Re-encrypt existing plaintext files in place.

    Walks ``model`` rows whose ``<field_name>_manifest`` is ``None`` (or
    empty), reads the file at the existing storage path, generates a
    fresh UUID, stream-encrypts to a new path, sets the sidecar
    manifest, updates the path column, deletes the original.

    The function is idempotent (rows with non-empty manifests are
    skipped) and safe to re-run after a crash. Each row is wrapped in
    its own DB transaction; partial state is cleaned up on failure.

    ``upload_to_prefix`` lets the caller supply a custom directory
    prefix for new files (otherwise the field's ``upload_to`` is used).

    Returns a counters dict: ``{"processed", "skipped", "errors"}``.
    """
    from conjunto.fields import EncryptedFileField  # local — avoids cycle

    field = model._meta.get_field(field_name)
    if not isinstance(field, EncryptedFileField):
        raise TypeError(
            f"{model.__name__}.{field_name} must be an EncryptedFileField "
            f"(got {type(field).__name__})"
        )
    manifest_attr = field.manifest_attname

    backend = get_backend()
    storage = field.storage
    model_label = f"{model._meta.app_label}.{model._meta.model_name}"

    qs = model._base_manager.filter(**{f"{manifest_attr}__isnull": True}).exclude(
        **{field_name: ""}
    )
    if tenant_id is not None:
        qs = qs.filter(tenant_id=tenant_id)
    qs = qs.only("pk", field_name, manifest_attr, "tenant_id")

    counters = {"processed": 0, "skipped": 0, "errors": 0}

    for obj in qs.iterator(chunk_size=batch_size):
        old_path = getattr(obj, field_name).name
        if not old_path:
            counters["skipped"] += 1
            continue
        obj_tenant = getattr(obj, "tenant_id", None)
        if obj_tenant is None:
            logger.warning(
                "Skipping %s pk=%s: no tenant_id — cannot pick a KEK",
                model_label,
                obj.pk,
            )
            counters["skipped"] += 1
            continue

        prefix = upload_to_prefix
        if prefix is None:
            prefix = os.path.dirname(old_path)
        new_path = generate_uuid_filename(prefix)
        file_uuid = os.path.splitext(os.path.basename(new_path))[0]

        if dry_run:
            counters["processed"] += 1
            if progress is not None:
                progress(obj, dry_run=True)
            continue

        try:
            with storage.open(old_path, "rb") as src:
                # Storage.save consumes a Django File-like; we route the
                # encrypted bytes through a temp spooled file.
                from django.core.files.base import ContentFile
                import io

                buf = io.BytesIO()
                manifest = encrypt_uploaded_file(
                    src,
                    buf,
                    backend=backend,
                    tenant_id=obj_tenant,
                    model_label=model_label,
                    field_name=field_name,
                    file_uuid=file_uuid,
                    chunk_size=field.chunk_size,
                    max_size=field.max_plain_size,
                )
                buf.seek(0)
                saved_path = storage.save(new_path, ContentFile(buf.getvalue()))
        except Exception:
            logger.exception(
                "Failed to encrypt %s pk=%s field=%s",
                model_label,
                obj.pk,
                field_name,
            )
            counters["errors"] += 1
            continue

        try:
            with transaction.atomic():
                setattr(obj, field_name, saved_path)
                setattr(obj, manifest_attr, manifest.to_bytes())
                obj.save(update_fields=[field_name, manifest_attr])
        except Exception:
            logger.exception(
                "DB update failed for %s pk=%s — rolling back new file %s",
                model_label,
                obj.pk,
                saved_path,
            )
            try:
                storage.delete(saved_path)
            except Exception:  # pragma: no cover — defensive
                logger.warning("Could not clean up new file %s", saved_path)
            counters["errors"] += 1
            continue

        if not keep_originals:
            try:
                storage.delete(old_path)
            except Exception:  # pragma: no cover — orphan, not fatal
                logger.warning(
                    "Could not delete original %s after successful re-encrypt "
                    "of %s pk=%s — left as orphan",
                    old_path,
                    model_label,
                    obj.pk,
                )

        counters["processed"] += 1
        if progress is not None:
            progress(obj, dry_run=False)

    return counters
