from django.apps import AppConfig


class ConjuntoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "conjunto"

    def ready(self):
        from . import components  # noqa
        from . import checks  # noqa
        from . import checks_a11y  # noqa
