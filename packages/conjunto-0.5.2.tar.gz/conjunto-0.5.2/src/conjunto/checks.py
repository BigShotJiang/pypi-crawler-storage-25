import sys

from django.core.checks import Error, Tags, Warning, register
from django.urls import reverse, NoReverseMatch
from django.conf import settings


@register()
def check_django_tomselect(app_configs, **kwargs):
    errors = []
    if "django_tomselect" not in settings.INSTALLED_APPS:
        errors.append(
            Warning(
                "'django_tomselect' is not in INSTALLED_APPS.",
                hint=(
                    "Make sure 'django_tomselect' is installed and in INSTALLED_APPS so that "
                    "its static files and templates are discoverable. "
                    "This is required for AutocompleteField and AutocompleteMultipleField."
                ),
                id="conjunto.W001",
            )
        )
    return errors


@register()
def check_settings(app_configs, **kwargs):
    errors = []
    if not hasattr(settings, "PROJECT_TITLE"):
        errors.append(
            Error(
                "The setting 'PROJECT_TITLE' is not defined.",
                hint="Add a human readable 'PROJECT_TITLE' to your settings.",
                id="conjunto.E001",
            )
        )
    if not hasattr(settings, "PROJECT_NAME"):
        errors.append(
            Error(
                "The setting 'PROJECT_NAME' is not defined.",
                hint="Add a machine readable 'PROJECT_NAME' to your settings.",
                id="conjunto.E002",
            )
        )
    return errors


# Subcommands that *might* run before vendored libs are populated. The
# check fires for every other command so dev runserver / wsgi startup
# warns immediately, but skipping it during these prevents bootstrap
# friction (you can't fix the warning without running the very command
# the warning would block).
_SKIP_VENDOR_CHECK_COMMANDS = {
    "update_libraries",
    "migrate",
    "makemigrations",
    "collectstatic",
    "compilemessages",
    "makemessages",
    "test",
}


@register(Tags.staticfiles)
def check_vendored_libraries(app_configs, **kwargs):
    """Warn when CONJUNTO_LIBRARIES files are missing from disk.

    The fix is always the same: ``python manage.py update_libraries``.
    """
    if len(sys.argv) > 1 and sys.argv[1] in _SKIP_VENDOR_CHECK_COMMANDS:
        return []
    # Local imports so importing this module doesn't pull in
    # ``conjunto._vendor`` (and thus ``requests``) in environments that
    # never run the check (e.g. wheel-build introspection).
    from conjunto._vendor.registry import (
        CORE_LIBRARIES,
        is_library_present,
    )
    from conjunto.management.commands.update_libraries import _resolve_dest

    libs = list(getattr(settings, "CONJUNTO_LIBRARIES", None) or sorted(CORE_LIBRARIES))
    try:
        dest = _resolve_dest()
    except Exception:
        # No CONJUNTO_VENDOR_DIR and no STATICFILES_DIRS — let the user
        # discover that directly via ``manage.py update_libraries``.
        return []

    missing_per_lib: list[tuple[str, list]] = []
    for lib in libs:
        ok, missing = is_library_present(lib, dest)
        if not ok:
            missing_per_lib.append((lib, missing))
    if not missing_per_lib:
        return []

    listed = "\n".join(
        f"  - {lib} (missing: {', '.join(str(p) for p in paths[:3])}"
        f"{', …' if len(paths) > 3 else ''})"
        for lib, paths in missing_per_lib
    )
    return [
        Warning(
            "Conjunto's vendored JS/CSS libraries are not present on disk.",
            hint=(
                "Run `python manage.py update_libraries` to fetch them.\n"
                "Missing libraries:\n" + listed
            ),
            id="conjunto.W002",
        )
    ]


@register()
def check_auth_urls(app_configs, **kwargs):
    errors = []
    for url_name in ["login", "logout"]:
        try:
            reverse(url_name)
        except NoReverseMatch:
            errors.append(
                Error(
                    f"The named URL '{url_name}' is not defined in our project.",
                    hint=f"Add a '{url_name}' URL to your URLconf.",
                    id=f"conjunto.E00{3 if url_name == 'login' else 4}",
                )
            )

    return errors
