"""User profile (avatar + future extension points) for conjunto.

Conjunto deliberately does not ship its own ``User`` model — projects use
``AUTH_USER_MODEL`` or swap in their own. To attach user-scoped metadata
(avatar today, possibly timezone/display name tomorrow) without touching
the user model, this app follows the classic Django profile pattern:
a separate :class:`UserProfile` model with a ``OneToOneField`` to
``settings.AUTH_USER_MODEL``.

A ``post_save`` signal on the user model auto-creates the companion
profile row so call sites can treat ``user.profile`` as always present.
"""

default_app_config = "conjunto.profiles.apps.ProfilesConfig"
