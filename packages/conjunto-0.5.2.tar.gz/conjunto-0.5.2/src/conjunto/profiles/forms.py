"""Forms for the profiles app."""

from django import forms
from django.utils.translation import gettext_lazy as _

from .models import UserProfile


class UserAvatarForm(forms.ModelForm):
    """Lets the user upload or clear their avatar image."""

    class Meta:
        model = UserProfile
        fields = ["avatar"]
        labels = {"avatar": _("Avatar")}
        help_texts = {
            "avatar": _(
                "Upload a square image. It will be displayed in the top bar "
                "and wherever your account is shown."
            ),
        }
