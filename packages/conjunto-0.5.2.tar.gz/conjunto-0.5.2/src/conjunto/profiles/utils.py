"""Pure helpers for the profiles app — safe to import anywhere."""

from __future__ import annotations


def compute_initials(user, max_len: int = 2) -> str:
    """Derive display initials for a user.

    Preference order:

    1. First letter of ``first_name`` + first letter of ``last_name``.
    2. First and last token of ``get_full_name()``.
    3. First ``max_len`` characters of ``username``.
    4. First ``max_len`` characters of ``email``.
    5. Literal ``"?"`` as last resort.
    """
    first = (getattr(user, "first_name", "") or "").strip()
    last = (getattr(user, "last_name", "") or "").strip()
    if first and last:
        return (first[:1] + last[:1]).upper()

    full = ""
    if hasattr(user, "get_full_name"):
        try:
            full = (user.get_full_name() or "").strip()
        except Exception:
            full = ""
    if full:
        tokens = full.split()
        if len(tokens) >= 2:
            return (tokens[0][:1] + tokens[-1][:1]).upper()
        return tokens[0][:max_len].upper()

    username = (getattr(user, "username", "") or "").strip()
    if username:
        return username[:max_len].upper()

    email = (getattr(user, "email", "") or "").strip()
    if email:
        return email[:max_len].upper()

    return "?"
