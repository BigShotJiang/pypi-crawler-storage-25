"""Auto-create a :class:`UserProfile` whenever a user is created.

Kept as a ``post_save`` signal (not a ``create_user`` override) so every
code path that writes a user row — admin, management commands, tests,
fixtures — ends up with a profile attached.
"""

from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import UserProfile


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def ensure_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.get_or_create(user=instance)
