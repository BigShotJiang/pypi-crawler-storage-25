from django.utils.translation import gettext_lazy as _
from gdaps import api


class ProfilesConfig(api.PluginConfig):
    """GDAPS plugin providing a user profile model and avatar rendering.

    The profile model is a companion row keyed by ``AUTH_USER_MODEL`` —
    conjunto does not own the user model itself. An auto-create signal
    ensures every user has a matching profile row after the first save.
    """

    label = "conjunto_profiles"
    name = "conjunto.profiles"
    verbose_name = _("User profiles")

    class PluginMeta:
        verbose_name = _("User profiles")
        author = "Christian González"
        author_email = "christian.gonzalez@nerdocs.at"
        description = _("User profile with avatar.")
        version = "1.0.0"
        category = "Conjunto"
        obligatory = False

    def ready(self):
        # Import signal handlers so the auto-create hook is connected.
        from . import signals  # noqa: F401

        # Import the avatar settings plugin so the InterfaceMeta
        # metaclass registers it with GDAPS.
        from . import menus  # noqa: F401
