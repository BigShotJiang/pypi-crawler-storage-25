"""UserProfile — companion row for ``AUTH_USER_MODEL``.

Holds user-scoped metadata that does not belong on the user model
itself (which conjunto never owns). Currently just an avatar; the model
is a natural home for future fields such as timezone, display name, or
UI preferences that are not better expressed as a ``ScopedSetting``.

Access patterns
---------------

- ``user.profile`` — reverse OneToOne. Present on every user thanks to
  the ``post_save`` signal in :mod:`conjunto.profiles.signals`.
- :meth:`UserProfile.get_or_create_for` — explicit, safe for users that
  pre-date the initial migration.
- :func:`conjunto.profiles.utils.compute_initials` — rendering helper
  used by the ``{% avatar %}`` template tag.
"""

from __future__ import annotations

import uuid
from pathlib import Path

from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _


def avatar_upload_to(instance: "UserProfile", filename: str) -> str:
    """Namespace avatars per user, randomize the filename.

    Using a UUID avoids collisions between successive uploads and lets
    us drop stale files via ``delete()`` without leaking the original
    client filename into the URL.
    """
    suffix = Path(filename).suffix.lower() or ".bin"
    return f"avatars/{instance.user_id}/{uuid.uuid4().hex}{suffix}"


class UserProfile(models.Model):
    """Per-user metadata keyed by ``AUTH_USER_MODEL``."""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="profile",
        verbose_name=_("User"),
    )
    avatar = models.ImageField(
        _("Avatar"),
        upload_to=avatar_upload_to,
        blank=True,
        null=True,
    )
    created_at = models.DateTimeField(_("Created at"), auto_now_add=True)
    updated_at = models.DateTimeField(_("Updated at"), auto_now=True)

    class Meta:
        verbose_name = _("User profile")
        verbose_name_plural = _("User profiles")

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"Profile<{self.user_id}>"

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    @classmethod
    def get_or_create_for(cls, user) -> "UserProfile":
        """Return the profile for ``user``, creating it if needed.

        Useful for code paths that run against users created before the
        initial profile migration, or in tests / data migrations where
        the ``post_save`` signal might not fire.
        """
        profile, _created = cls.objects.get_or_create(user=user)
        return profile

    @property
    def avatar_url(self) -> str | None:
        """URL of the stored avatar file, or ``None`` if not set."""
        if self.avatar and hasattr(self.avatar, "url"):
            try:
                return self.avatar.url
            except ValueError:
                return None
        return None
