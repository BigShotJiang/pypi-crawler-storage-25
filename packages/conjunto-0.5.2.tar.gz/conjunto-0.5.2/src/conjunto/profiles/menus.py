"""Settings-page plugin contributions for :mod:`conjunto.profiles`.

Adds an "Avatar" subsection under the built-in ``User → Profile``
section. Because the form handles a file upload, the plugin ships its
own template with ``hx-encoding="multipart/form-data"`` so HTMX posts
the binary payload correctly.
"""

from django.utils.translation import gettext_lazy as _

from conjunto.settings.interfaces import ISettingsForm
from conjunto.settings.menus import UserProfileSection

from .forms import UserAvatarForm
from .models import UserProfile


class UserAvatarFormPlugin(ISettingsForm):
    """Avatar subsection under ``User → Profile``."""

    section = UserProfileSection
    name = "user_avatar"
    title = _("Avatar")
    weight = 10
    form_class = UserAvatarForm
    template = "conjunto/profiles/_settings_avatar.html"

    def get_instance(self, request):
        return UserProfile.get_or_create_for(request.user)
