"""Signal handlers for the notifications app.

A ``post_save`` on :class:`~conjunto.notifications.models.Notification`
is broadcast as a ``model.updated`` event to the recipient's channel
group (:data:`notifications.user.<pk>`). The connected
:class:`~conjunto.notifications.consumers.NotificationConsumer` re-renders
the dropdown — the payload is intentionally empty because the consumer
re-queries the current top-N rows.
"""

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer


def notify_recipient(sender, instance, **kwargs):
    """Broadcast a `model.updated` event to the recipient's group.

    The consumer re-fetches the current list on receipt, so no payload
    is needed beyond the group dispatch.
    """

    channel_layer = get_channel_layer()
    if channel_layer is None:
        # No CHANNEL_LAYERS configured — silently no-op so non-channels
        # tests still exercise the model.
        return
    group_name = f"notifications.user.{instance.recipient_id}"
    async_to_sync(channel_layer.group_send)(
        group_name,
        {"type": "model.updated", "data": "[]"},
    )
