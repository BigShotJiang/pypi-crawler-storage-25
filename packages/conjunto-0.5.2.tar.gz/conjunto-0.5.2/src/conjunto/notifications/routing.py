"""``IWebsocketURL`` plugin for the notifications consumer."""

from django.urls import path

from conjunto.api.interfaces import IWebsocketURL

from .consumers import NotificationConsumer


class NotificationsWebsocketURL(IWebsocketURL):
    urlpatterns = [
        path("ws/notifications/", NotificationConsumer.as_asgi()),
    ]
