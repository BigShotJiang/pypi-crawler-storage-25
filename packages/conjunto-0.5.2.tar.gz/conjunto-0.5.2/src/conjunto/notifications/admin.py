from django.contrib import admin

from .models import Notification


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = (
        "recipient",
        "level",
        "message",
        "blocking",
        "dismissible",
        "created",
        "read_at",
    )
    list_filter = ("level", "blocking", "dismissible")
    search_fields = ("message", "recipient__username")
    readonly_fields = ("created",)
