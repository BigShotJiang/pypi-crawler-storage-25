from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView

from .models import Notification


class NotificationsUnreadView(LoginRequiredMixin, TemplateView):
    """Render the bell dropdown content (initial HTMX `load` request).

    The same partial is re-rendered live by
    :class:`~conjunto.notifications.consumers.NotificationConsumer` on
    every ``model.updated`` channel event.
    """

    template_name = "conjunto/notifications/dropdown_content.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["notifications"] = Notification.objects.filter(
            recipient=self.request.user
        )[:10]
        return context
