from django.urls import path

from .views import NotificationsUnreadView

app_name = "notifications"

urlpatterns = [
    path(
        "unread/",
        NotificationsUnreadView.as_view(),
        name="notifications-unread",
    ),
]
