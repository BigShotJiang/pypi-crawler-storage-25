import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="Notification",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "created",
                    models.DateTimeField(
                        default=django.utils.timezone.now, editable=False
                    ),
                ),
                (
                    "level",
                    models.PositiveIntegerField(
                        choices=[
                            (25, "success"),
                            (10, "info"),
                            (20, "info"),
                            (30, "warning"),
                            (40, "danger"),
                        ],
                        default=20,
                    ),
                ),
                ("message", models.CharField(max_length=1024)),
                (
                    "blocking",
                    models.BooleanField(
                        default=False,
                        help_text="Should the notification block the user's workflow?",
                    ),
                ),
                (
                    "dismissible",
                    models.BooleanField(
                        default=True,
                        help_text=(
                            "Should the notification be dismissible by the user? "
                            "If not, it will fade away itself."
                        ),
                    ),
                ),
                (
                    "read_at",
                    models.DateTimeField(blank=True, editable=False, null=True),
                ),
                (
                    "recipient",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                "ordering": ("-created",),
            },
        ),
    ]
