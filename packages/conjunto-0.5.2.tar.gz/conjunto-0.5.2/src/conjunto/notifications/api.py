"""Public notification API.

Mirrors :mod:`django.contrib.messages` semantics but writes to a
persistent :class:`~conjunto.notifications.models.Notification` row so
the recipient sees the entry in the bell dropdown across page loads
and tabs (the ``post_save`` signal pushes the change live via
WebSockets).

All helpers are safe to call from any sync code path — views,
management commands, signal handlers, post-save hooks::

    from conjunto.notifications import add, info, warning, error

    info(user, _("Backup completed."))
    warning(user, _("License expires in 7 days."), dismissible=True)
    error(user, _("Sync failed."), blocking=True)
    add(user, level=messages.INFO, message=_("..."))
"""

from django.contrib.messages import constants

__all__ = (
    "add",
    "debug",
    "info",
    "success",
    "warning",
    "error",
    "NotificationFailure",
)


class NotificationFailure(Exception):
    """Raised when a notification could not be persisted."""


def add(user, level: int, message, *, blocking: bool = False, dismissible: bool = True):
    """Persist one notification for ``user``.

    The signal handler in :mod:`conjunto.notifications.signals`
    broadcasts the change to the recipient's channel group, so any
    connected tab re-renders its dropdown.

    Args:
        user: Recipient. Must be a real, saved user instance — anonymous
            notifications are not supported.
        level: One of the :mod:`django.contrib.messages` level constants.
        message: Translated, human-readable message string.
        blocking: When True the notification interrupts the workflow
            until the user acknowledges it.
        dismissible: When False the notification fades on its own and
            cannot be closed manually.
    """
    from .models import Notification

    Notification.objects.create(
        recipient=user,
        level=level,
        message=message,
        blocking=blocking,
        dismissible=dismissible,
    )


def debug(user, message, *, blocking: bool = False, dismissible: bool = True):
    """Add a notification with the ``DEBUG`` level."""
    add(user, constants.DEBUG, message, blocking=blocking, dismissible=dismissible)


def info(user, message, *, blocking: bool = False, dismissible: bool = True):
    """Add a notification with the ``INFO`` level."""
    add(user, constants.INFO, message, blocking=blocking, dismissible=dismissible)


def success(user, message, *, blocking: bool = False, dismissible: bool = True):
    """Add a notification with the ``SUCCESS`` level."""
    add(user, constants.SUCCESS, message, blocking=blocking, dismissible=dismissible)


def warning(user, message, *, blocking: bool = False, dismissible: bool = True):
    """Add a notification with the ``WARNING`` level."""
    add(user, constants.WARNING, message, blocking=blocking, dismissible=dismissible)


def error(user, message, *, blocking: bool = False, dismissible: bool = True):
    """Add a notification with the ``ERROR`` level."""
    add(user, constants.ERROR, message, blocking=blocking, dismissible=dismissible)
