from django.apps import AppConfig
from django.db.models.signals import post_save
from django.utils.translation import gettext_lazy as _


class NotificationsConfig(AppConfig):
    name = "conjunto.notifications"
    verbose_name = _("Notifications")
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self):
        # Import side-effects: register the IWebsocketURL plugin and
        # connect the post_save signal that broadcasts dropdown updates.
        from . import routing  # noqa: F401
        from . import signals
        from .models import Notification

        post_save.connect(
            signals.notify_recipient,
            sender=Notification,
            dispatch_uid="conjunto.notifications.notify_recipient",
        )
