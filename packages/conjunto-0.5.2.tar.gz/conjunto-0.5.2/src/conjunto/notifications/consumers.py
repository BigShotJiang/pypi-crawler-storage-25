"""WebSocket consumer that pushes the recipient's bell dropdown.

Connected clients join a per-user channel group
(:data:`notifications.user.<pk>`). The post-save signal in
:mod:`conjunto.notifications.signals` broadcasts a ``model.updated``
event to that group on every
:class:`~conjunto.notifications.models.Notification` write; this
consumer re-renders the dropdown OOB partial and ships the HTML over
the wire. HTMX's ``ws`` extension swaps it into ``#notifications-dropdown``.
"""

from conjunto.consumers import ModelConsumer

from .models import Notification


class NotificationConsumer(ModelConsumer):
    """Push the current user's notifications dropdown on every change."""

    model = Notification
    template_name = "conjunto/notifications/dropdown_oob.html"

    def connect(self):
        user = self.scope.get("user")
        if not user or not user.is_authenticated:
            self.close()
            return
        super().connect()

    def get_group_name(self) -> str:
        return f"notifications.user.{self.scope['user'].pk}"

    def get_template_context(self, event):
        user = self.scope["user"]
        return {
            "notifications": Notification.objects.filter(recipient=user)[:10],
            "user": user,
        }
