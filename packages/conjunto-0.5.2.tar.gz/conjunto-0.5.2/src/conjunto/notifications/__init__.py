"""Per-user notifications with WebSocket-pushed bell dropdown.

Optional Conjunto sub-app. Add ``"conjunto.notifications"`` to
``INSTALLED_APPS`` and the ``app_base.html`` topbar will render a bell
fed by a Channels consumer that pushes the rendered list on every
:class:`~conjunto.notifications.models.Notification` row change.

Public API — importable from any consumer::

    from conjunto.notifications import add, info, success, warning, error

    info(user, _("Backup completed."))
    warning(user, _("..."), dismissible=True)
    error(user, _("..."), blocking=True)

See :mod:`conjunto.notifications.api` for the full signature.
"""

from .api import add, debug, error, info, success, warning

__all__ = ["add", "debug", "error", "info", "success", "warning"]
