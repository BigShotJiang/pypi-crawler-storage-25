from django.conf import settings
from django.contrib import messages
from django.db import models
from django.db.models import IntegerChoices
from django.utils import timezone
from django.utils.translation import gettext_lazy as _


class MessageTags(IntegerChoices):
    """Message-level constants reused from :mod:`django.contrib.messages`.

    The string label is the Bootstrap/Tabler colour token used in
    the dropdown's status-dot CSS class (``bg-{tag}``).
    """

    SUCCESS = messages.SUCCESS, "success"
    DEBUG = messages.DEBUG, "info"
    INFO = messages.INFO, "info"
    WARNING = messages.WARNING, "warning"
    ERROR = messages.ERROR, "danger"


class Notification(models.Model):
    """A blocking or non-blocking, optionally dismissible notification.

    Created by :func:`conjunto.notifications.api.add` (and the level
    helpers ``info``/``success``/``warning``/``error``). The
    ``post_save`` signal in
    :mod:`conjunto.notifications.signals` broadcasts a
    ``model.updated`` event to the recipient's
    ``notifications.user.<pk>`` channel group; a connected
    :class:`~conjunto.notifications.consumers.NotificationConsumer`
    re-renders the bell dropdown for every open tab.
    """

    created = models.DateTimeField(editable=False, default=timezone.now)
    level = models.PositiveIntegerField(choices=MessageTags, default=messages.INFO)
    recipient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    message = models.CharField(max_length=1024)
    blocking = models.BooleanField(
        default=False,
        help_text=_("Should the notification block the user's workflow?"),
    )
    dismissible = models.BooleanField(
        default=True,
        help_text=_(
            "Should the notification be dismissible by the user? "
            "If not, it will fade away itself."
        ),
    )
    read_at = models.DateTimeField(null=True, blank=True, editable=False)

    class Meta:
        ordering = ("-created",)

    def __str__(self):
        return self.message

    def tags(self):
        """Return the Bootstrap/Tabler colour token for this level.

        Used by the dropdown template as ``bg-{{ notification.tags }}``.
        """
        return MessageTags(self.level).label
