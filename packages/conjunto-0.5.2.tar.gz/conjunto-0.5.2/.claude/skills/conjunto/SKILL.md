---
name: conjunto
description: Use when working in any Django project that lists `conjunto` as a dependency (check `pyproject.toml`, `requirements*.txt`, `uv.lock`, `INSTALLED_APPS`) — covers GDAPS plugins/interfaces, audit log, menus, layout (`conjunto/base.html` vs `conjunto/app_base.html`, `cj_layout`), three-mode sidebar (`conjunto.sidebar_mode`: full/mini/collapsed), scoped settings (USER>DEVICE>GROUP>TENANT>VENDOR + locks), tenants (`AbstractTenant`, `CONJUNTO_TENANT_MODEL`, `TenantRole`, `tenant_admin`, `ITenantLifecycle`, `setup_tenant`), profiles/avatars, widget dashboard, login (`ConjuntoLoginView`, `ConjuntoAuthenticationForm`, `ILoginMethod`, `ILoginViewExtension`, `IPostLoginAction`, two-step tenant pick), WebSockets (`IWebsocketURL`, `ModelConsumer`, `CONJUNTO_WEBSOCKETS_ENABLED`), notifications (`conjunto.notifications`), CMS, HTMX patterns, vendored libraries (`update_libraries`, `CONJUNTO_LIBRARIES`, `CONJUNTO_VENDOR_DIR`), extensible forms (`conjunto.extensible_forms`, `CompositeForm`, `FormSlot`, `FormSectionContract`, `build_slot_layout`, `{% extensible_form_attrs %}`). Also trigger on `IMenuItem`, `IScope`/`IVendorScope`/`ITenantScope`/`IGroupScope`/`IDeviceScope`/`IUserScope`, `ISettingsSection`/`ISettingsGroup`/`ISettingsForm` (`requires_full_reload`), `IWidget`/`IWidgetArea`, `IRowAction`/`IHeaderAction`, `ScopedSetting`, `SettingRegistry`, `Resolution`/`get_resolution`, `TenantMembership`, `tenant_role_permissions`, `auth.session_lifetime_*`, `auth.show_remember_me`, `cj_layout.websockets`/`.notifications`, `cj-sidebar-mode-*`, `cjSetSidebarMode`, `SaveSidebarModeView`, `cj_device_id` cookie, `notifications.user.<pk>` channel group, `hx-ext="ws"`/`htmx-ext-ws`, `log_action`, `DependentFieldsMixin`, `*_changed()` callback, `conjunto.forms.TimeField`/`TimePickerInput`/`DatePickerInput`/`PersistentFileField`/`SafeHTMLField`/`SelectGroup`/`IntegerStepperInput`/`ColorField`/`TABLER_COLORS`/`PartialDateField`, `data-tomselect-*`, `ts-hidden-accessible`, `{% conjunto_require_X %}`, `conjunto.W002`, TinyMCE GPLv2, or files under `src/conjunto/`.
---

# Conjunto — Skill Reference

Django framework for component-based, plugin-extendable apps. Stack: GDAPS (plugins) + Tabler.io (UI) + django-tables2 + crispy-forms + HTMX. **Tetra is NOT part of conjunto** — never suggest it.

## Authoritative reference

**The code and project docs are the source of truth.** When working *outside* the `conjunto` source directory, `Read` the relevant doc before answering:

- `Projekte/conjunto/CLAUDE.md` — architecture, GDAPS, audit log, menus, layout, blocks, `cj_layout`, scoped settings, code style.
- `Projekte/conjunto/docs/usage/settings.md` — scoped settings (registry, resolver, proxy, device, tenant, admin).
- `Projekte/conjunto/docs/usage/tenants.md` — `AbstractTenant`, swappable `CONJUNTO_TENANT_MODEL`.
- `Projekte/conjunto/docs/usage/layout.md` — full layout reference.
- `Projekte/conjunto/docs/usage/maintenance_mode.md` — maintenance flow via `conjunto.maintenance_mode`.
- `Projekte/conjunto/docs/usage/tables.md` — `TableListView` + `RowActionsMixin` + `IRowAction`/`IHeaderAction`, modal confirm, `list_card.html`.
- `Projekte/conjunto/docs/usage/filters.md` — `Filter`/`ChoiceFilter`/`BooleanFilter` + `filterset_class` escape hatch.
- `Projekte/conjunto/docs/usage/sortable.md` — `conjunto.sortable` (drag-and-drop ordering via `weight`, HTMX-declarative).
- `Projekte/conjunto/docs/usage/sidebar.md` — three-mode sidebar (`full`/`mini`/`collapsed`), `conjunto.sidebar_mode`, drag-snap.
- `Projekte/conjunto/docs/usage/auth.md` — `ConjuntoLoginView`, `ConjuntoAuthenticationForm`, two-step tenant pick, `ILoginViewExtension`, `IPostLoginAction`, `auth.*` settings.
- `Projekte/conjunto/docs/usage/notifications.md` — `conjunto.notifications` activation, API, channel-group contract.
- `Projekte/conjunto/docs/usage/profiles.md` — `UserProfile`, avatar `ImageField`, `{% avatar %}` tag.
- `Projekte/conjunto/docs/usage/static_libraries.md` — `manage.py update_libraries`, registry, CI integration, TinyMCE GPLv2.
- `Projekte/conjunto/docs/extensible_forms.md` — `conjunto.extensible_forms` author guide (`CompositeForm`, `FormSlot`, owner + contributor recipes, event vocabulary).
- `Projekte/conjunto/src/conjunto/_vendor/registry.py` — single source for `LIBRARIES`, `CORE_LIBRARIES`, `APP_LAYOUT_LIBRARIES`, `FEATURE_TAG_TO_LIBRARY`, `LIBRARY_COMPANIONS`.
- `Projekte/conjunto/src/conjunto/` — interfaces, components, templates, CSS.

If docs and code disagree, trust the code and flag the docs as stale.

## Hard rules (apply always)

- **Two base templates (v0.2.1, BREAKING):**
  - `conjunto/base.html` — slim shell (`<head>`, `body`, `modal`, `toasts`, `scripts`). Use for login / error / print pages.
  - `conjunto/app_base.html` — full layout (topbar + sidebar + canvas + statusbar + offcanvas). **Use for every authenticated in-app page.** Historical block names (`top_bar*`, `sidebar*`, `canvas`, `page_header`, `page_actions`, `messages`, `content`, `footer`, `statusbar`, `offcanvas_left/right`) live in `app_base.html`.
- **Tabler icons:** `<i class="ti ti-{name}"></i>`.
- **Menus** are GDAPS `IMenuItem` plugins; slots: `menus.main`, `menus.user`, `menus.sidebar`, `menus.footer`.
- **Ordering field is always `weight`** — never `order`/`position`/`sort_order`. Lower first, vertical and horizontal alike. Applies to every interface (`IMenuItem`, `IWidget`, `IWidgetArea`, `ISettingsSection`/`Group`, `IRowAction`, `IHeaderAction`, `ILoginMethod`, `IScope`, …).
- **Audit log:** register actions via `register_log_actions` hook before calling `log_action(...)`.
- **Settings:** `request.scoped_settings.get("namespace", "key")`. Old `request.app_settings` / `AbstractSettings` / `SETTINGS_MODEL` are gone. Register every `(namespace, key)` in a top-level `scoped_settings.py`.
- **Layout chain:** `settings.py → request.scoped_settings → view context cj_layout`. Scoped keys: `conjunto.layout_style`, `conjunto.topbar_fixed`, `conjunto.sidebar_width`, `conjunto.color_scheme`. Flags merged into `cj_layout`: `theme_switcher` (`CONJUNTO_THEME_SWITCHER`), `websockets` (`CONJUNTO_WEBSOCKETS_ENABLED`, default auto-detect), `notifications` (true iff `conjunto.notifications` ∈ `INSTALLED_APPS` AND `cj_layout.websockets`). **Templates gate features on `cj_layout.*` flags** — never assume.
- **Page-specific topbar buttons** go in the `top_bar_actions` block.
- **Python 3.13+, Django ≥ 6.0.3, gdaps ≥ 0.13.0, black formatter, `uv run ...`.**
- **Template partials:** Django 6 native `{% partialdef %}` / `template#partial`. **Do NOT** add `django-template-partials`.
- **Docs / docstrings / translatable strings: English.** Translation via i18n.
- **List views:** `conjunto.views.TableListView` + `conjunto.tables.RowActionsMixin`. Old Tetra-based `ActionButtonsTable`/`TActionButton`/`HxActionButton`/`IActionButton`/`CrudTableMixin` are **gone**.
- **`{{ form.media }}` mandatory** for every form template (and HTMX-swapped partials, modal bodies) using a JS-bearing widget (`DatePickerInput`, `TimePickerInput`, `PersistentFileWidget`, TinyMCE/SafeHTML). Without it widgets silently degrade to plain inputs. Alternative: include widget JS once globally.
- **Third-party JS/CSS is NOT in the wheel.** Consumers fetch via `python manage.py update_libraries` into `CONJUNTO_VENDOR_DIR` (typ. `BASE_DIR/static-vendored/conjunto/`). Without `CONJUNTO_LIBRARIES` + `CONJUNTO_VENDOR_DIR` + matching `STATICFILES_DIRS`, every page 404s.
- **Mobile first.** Pages viewable on tablets/phones with reduced clutter. Use `-xl`/`-lg`/`-md`/`-sm`/`-xs` classes to hide non-essentials on small screens.

## Static libraries (`manage.py update_libraries`)

Single entry point. Legacy `scripts/update_libraries.py` and `_vendor.registry.main_cli` are gone — never reintroduce a parallel CLI.

**Required `settings.py` block (Layout B):**

```python
STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STATICFILES_DIRS = [
    BASE_DIR / "static",            # first-party (in git)
    BASE_DIR / "static-vendored",   # auto-generated, NOT in git
]
CONJUNTO_VENDOR_DIR = BASE_DIR / "static-vendored" / "conjunto"
CONJUNTO_LIBRARIES = ["htmx", "tabler"]   # run `update_libraries --suggest`
```

`.gitignore`: `/staticfiles/`, `/static-vendored/`.

**Inventory** (single source: `conjunto._vendor.registry`):

| Name | Pulled in when |
|---|---|
| `htmx`, `tabler` | **Core** — every page (`CORE_LIBRARIES`). |
| `alpine`, `litepicker`, `sortable` | **App layout** — anything extending `app_base.html` (`APP_LAYOUT_LIBRARIES`). |
| `chartjs`, `dropzone`, `fslightbox` | Triggered by `{% conjunto_require_chart/dropzone/fslightbox %}`. |
| `tinymce` (+ auto-paired `tinymce-i18n` via `LIBRARY_COMPANIONS`) | `{% conjunto_require_tinymce %}`. **GPLv2-or-later.** |

```bash
python manage.py update_libraries --suggest   # print tailored CONJUNTO_LIBRARIES
python manage.py update_libraries             # download (skips existing; --force to refresh)
python manage.py update_libraries --check     # no-network presence check (CI)
```

Runs **before** `collectstatic` in every deploy path. Air-gapped: `--all` once on build agent, ship `static-vendored/conjunto/` as artefact. `{% conjunto_require_X %}` declares per-feature deps; `--suggest` scans templates (mapping `_vendor.registry.FEATURE_TAG_TO_LIBRARY`).

**System check `conjunto.W002`** reports missing files at startup with fix command. Suppressed during `update_libraries`/`migrate`/`collectstatic`/`compilemessages`/`test`.

**Hard rules:**
- Never commit `static-vendored/`.
- Never override the management command per-project — add to `_vendor.registry.LIBRARIES` upstream.
- Tests mocking `update_libraries` must mock `conjunto._vendor.registry.requests.get` — never hit npm/jsDelivr.
- TinyMCE: keep `LICENSE.TXT`, `README.md`, `CHANGELOG.md`, `package.json` next to editor JS (GPLv2 obligation).
- Argparse `help=` text: escape literal `%` as `%%` (Python 3.14 `_check_help` validates at parser-build).

## Scoped settings (`conjunto.settings.scoped`)

**Mental model.** Overlay across 5 scopes, priority lowest→highest: **VENDOR → TENANT → GROUP → DEVICE → USER**. Highest matching row wins. A `locked=True` row is a **floor** — no higher scope can dig under it. Multiple locks: **lowest-priority lock wins**. Site is an orthogonal filter, not a sixth scope.

**Register every key** at startup in a top-level `scoped_settings.py`; auto-discovered by `conjunto.settings.apps.SettingsConfig.ready()`:

```python
from conjunto.settings.scoped.models import Scope
from conjunto.settings.scoped.registry import SettingRegistry

SettingRegistry.register(
    "myapp", "email_digest",
    type="bool", default=True,
    help_text="Whether the user receives a weekly digest email.",
    icon="mail",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)
```

Invariant: `lockable_scopes ⊆ writable_scopes`. Registry **freezes on first read**; later registration raises `RuntimeError`. Tests: `conjunto.settings.scoped.testing.unfreeze_registry()` context manager.

**Read:**

```python
value = request.scoped_settings.get("myapp", "email_digest")               # strict (KeyError on missing spec)
value = request.scoped_settings.get("myapp", "email_digest", default=True) # lenient
# Template (missing → ""):
{{ request.scoped_settings.myapp.email_digest }}
```

Per-request cache; repeat reads hit no DB.

**Write** (no `SettingRegistry.set()` — use ORM, gate with `IScope.can_edit/can_lock`):

```python
from conjunto.settings.scoped.models import Scope, ScopedSetting
from conjunto.settings.scoped.scopes import IUserScope

if not IUserScope.can_edit(request, request.user.pk):
    raise PermissionDenied
ScopedSetting.objects.update_or_create(
    namespace="myapp", key="email_digest",
    scope=Scope.USER, user=request.user,
    defaults={"value": enabled},
)
request.scoped_settings.invalidate("myapp", "email_digest")
```

**Five scopes** (`conjunto.settings.scoped.scopes`, all `I`-prefixed GDAPS plugins):

- `IVendorScope` — global, no FK; `can_edit` requires `conjunto_settings.manage_vendor_settings`.
- `ITenantScope` — resolves `request.tenant` → `request.user.tenant_id` → `request.session['cj_tenant_id']`; `can_edit` = `tenant_admin` role + `change_scopedsetting`.
- `IGroupScope` — user's `auth.Group`s sorted by pk ASC. **Tie-break:** unlocked walk = highest pk; locked walk = lowest pk.
- `IDeviceScope` — `request.device.pk`, set by `ConjuntoMiddleware` from `cj_device_id` cookie.
- `IUserScope` — `request.user.pk`; `can_edit` = own pk + `change_scopedsetting`.

**Device** = 10-year `cj_device_id` UUID cookie (HttpOnly, SameSite=Lax). Bound to user on first auth visit; **never rebound** — different user creates a new Device row. GDPR: durable identifier, must be disclosed.

**Resolver** (`get_effective`): single-pass walk, one DB query, short-circuits on first lock, falls back to `spec.default`. **Introspection** (`get_resolution(namespace, key, request) -> Resolution`): same walk, returns `value`, `winning_scope`, `lock_scope`, `is_locked`, `fallback=(value, scope)` (what would win if USER row deleted). Same cache.

**Pre-registered conjunto keys** (`src/conjunto/scoped_settings.py`):

| Key | Scopes | Notes |
|---|---|---|
| `conjunto.layout_style` | VENDOR/TENANT/USER | `"fluid"` or `"boxed"` |
| `conjunto.topbar_fixed` | VENDOR/TENANT/USER | bool |
| `conjunto.sidebar_width` | VENDOR/TENANT/USER | CSS length |
| `conjunto.color_scheme` | USER/DEVICE/TENANT/VENDOR | `"light"`/`"dark"`; applied to `<html data-bs-theme>` before first paint |
| `conjunto.maintenance_mode` | VENDOR only | bool; `ConjuntoMiddleware` redirects non-staff to `/maintenance/` |
| `conjunto.sidebar_mode` | VENDOR/TENANT/DEVICE/USER (lockable VENDOR/TENANT) | `"full"`/`"mini"`/`"collapsed"`; default `"full"`. Drag/toggle writes DEVICE. |
| `conjunto.timezone` | VENDOR/TENANT/USER (lockable VENDOR/TENANT) | IANA name; activated by `TimezoneMiddleware` |
| `auth.session_lifetime_default` | VENDOR/TENANT | int sec, default `0` (browser-close). Was `conjunto.session_lifetime_default` ≤ 0.3.x — migration `conjunto_settings/0008_*` rewrites rows. |
| `auth.session_lifetime_remembered` | VENDOR/TENANT | int sec, default `2592000` (30 d). Same migration. |
| `auth.show_remember_me` | VENDOR/TENANT (lockable both) | bool, default `True`. When `False`, login form omits checkbox AND `form.get_remember_me()` returns `False` even if POST has `remember_me=on`. |

**`TimezoneMiddleware`** activates `conjunto.timezone` per request (`timezone.activate(ZoneInfo(...))`, `deactivate` in `finally`). **Must run after `ConjuntoMiddleware`** (needs `request.scoped_settings`). Templates: `{% load tz %}` + `|localtime` before `|date`/`|time`.

## Tenants (`conjunto.tenants`)

`AbstractTenant` + concrete swappable `Tenant` via `CONJUNTO_TENANT_MODEL`. Default: `"conjunto_tenants.Tenant"` installed at package import. If swapping: set **before first migration**.

`Tenant.save()` auto-materializes `tenant:<slug>:<role>` auth.Groups + seeds `TenantRole` rows. First user is auto-assigned the **`tenant_admin`** role (`AbstractTenant.TENANT_ADMIN_ROLE`). Subclass for domain fields — never put domain fields in conjunto.

**`TenantRole`** — system roles (`is_system=True`, seeded from `AppConfig.tenant_role_permissions`) and custom roles (admin-created). System role base perms cannot be revoked; admins can add via `permissions` M2M. `save()` materializes the auth.Group; `delete()` removes it. Helpers in `conjunto.tenants.roles`: `seed_system_roles(tenant)`, `available_roles_for_tenant(tenant)`.

**Admin views** (`conjunto.tenants.views/`, URL module `conjunto.tenants.admin_urls`, 10 patterns): Roles `TenantRoleListView`/`CreateView`/`UpdateView`/`DeleteView` (system role name locked, AppConfig perms disabled); Users `TenantUserListView`/`CreateView`/`UpdateView`/`RemoveView` (last admin cannot be removed); Memberships `UserRoleListView`, `ManageUserRolesView`. URL names: `role-list/-add/-edit/-delete`, `user-list/-add/-edit/-remove`, `user-role-list/-manage`. List views: `base_template = "conjunto/app_base.html"` (overrideable).

**Forms** (`conjunto.tenants.forms`): `TenantRoleForm` (`GroupedPermissionWidget`), `TenantUserCreateForm`/`TenantUserEditForm`, `UserRolesForm` (multi-checkbox synced to `TenantMembership` on save).

**`ITenantLifecycle`** (`conjunto.tenants.interfaces`) — per-tenant init hook for plugin master data. Classmethod `setup_tenant(cls, tenant)`, **must be idempotent** (`get_or_create`/`update_or_create`, never bare `create`). Wired into `Tenant.post_save`; failures caught + `logger.exception`'d so one bad plugin doesn't abort tenant creation. Implementations in plugin-side `lifecycle.py`, imported from `AppConfig.ready()`. `weight` (default 100) sorts execution. **Never subclass** the interface itself — future hooks (`teardown_tenant`, …) added in-place.

```bash
python manage.py setup_tenant 1 2 3   # back-fill specific tenants
python manage.py setup_tenant --all   # back-fill every tenant
```

Output per tenant + per implementer (`OK`/`FAIL`); exit `1` if any raised, run still attempts every implementer.

## Settings page UI (`conjunto.settings`)

GitHub-style left-rail + right-pane form layout. Plugin-driven via 3 GDAPS interfaces:

- `ISettingsGroup` — left-rail category. `name`, `title`, `weight`.
- `ISettingsSection` — entry under a group. `group=<GroupClass>`, `name`, `title`, `icon`, `weight`. Override `has_permission(cls, request)`.
- `ISettingsForm` — right-pane subsection. `section=<SectionClass>`, `name`, `title`, `weight`, `form_class`. Optional: `get_initial`, `get_instance`, `save`, `extra_success_triggers`, `requires_full_reload`.

Place subclasses in `<app>/menus.py` (same convention as `IMenuItem`).

**HTMX flow — already wired in `SettingsFormView`. Do not write your own.** Class chain: `(LoginRequiredMixin, HtmxFormViewMixin, FormView)`. Success → 204 + `HX-Reswap: none` + `HX-Trigger: showToast` + `HX-Trigger: settings:changed`. `#cj-settings-pane` listens for `settings:changed from:body` and re-fetches the partial.

**Theme/layout-bound settings — opt into `requires_full_reload = True`.** Color scheme, layout style, sidebar width, topbar position, language, timezone all touch many DOM nodes (Tabler hangs active theme on `data-bs-theme`, `theme-dark` class, sidebar variant, charts, code highlight, plus `localStorage["tabler-theme"]` cache). Opt-in makes `SettingsFormView.form_valid` set `HX-Refresh: true` AFTER `plugin.save(...)`. HTMX runs `HX-Trigger` handlers (incl. `extra_success_triggers` like `colorSchemeChanged`) BEFORE `location.reload()` → persist → fire triggers → reload. Skip for non-visual settings (avatar, name, e-mail).

If a submit triggers full reload, check (in order): (1) `<form>` has resolvable `hx-post="{% url 'settings:form' plugin.name %}"` with `plugin.name` matching `<slug:form_name>`; (2) crispy fields don't have block-level HTML in labels (plain `help_text`); (3) HTMX loaded via `{% conjunto_scripts %}` in `conjunto/base.html`; (4) dynamic forms rebuild the same fields on POST; (5) `{% csrf_token %}` present.

## HtmxFormViewMixin

For custom HTMX form views, inherit `conjunto.htmx.views.HtmxFormViewMixin`:

- `enforce_htmx = True` → non-HTMX requests raise `PermissionDenied`.
- Empty `success_url` + non-empty `success_event` → 204 with `HX-Trigger: <event>`.
- Non-empty `success_url` → `HX-Redirect`.
- Redirect responses from `super().form_valid` auto-converted for HTMX.

Related: `SuccessEventMixin`, `ModalFormViewMixin`, `ModalCreateView`/`UpdateView`/`DeleteView` (all in `conjunto/htmx/views.py`).

## Modals — hard rule

**Never write custom modal markup or modal-lifecycle JS.** No hand-rolled `<div class="modal">`, no `bootstrap.Modal(...).show()`, no inline scripts, no `htmx:afterSwap` listeners for modals.

- **Server:** subclass `ModalCreateView`/`UpdateView`/`DeleteView`/`DetailView`, or `ModalFormViewMixin` + plain `CreateView`/`UpdateView`/`DeleteView` (no auto-perms). Set `model`, `form_class`, optionally `modal_title`, `button_content`, `dialog_type`, `success_event`. `ModalXxxView` mixes in `AutoPermissionsViewMixin` (enforces `<verb>_<model>` per request) — drop to `ModalFormViewMixin + CreateView` if perms aren't yet wired.
- **Template:** default `conjunto/modal_form.html` or extend it (override `body`/`header`/`title`/`footer`/`submit-button`/`content` blocks). Don't write the `<div class="modal …">` wrapper — `modal_form.html` only renders the inner `<form class="modal-content">`; persistent `.modal`/`.modal-dialog` lives in consumer's base template.
- **Trigger button:** `hx-get="{% url 'ns:view' %}"`, `hx-target="#dialog"`, `hx-swap="innerHTML"`. Default target id `#dialog` (overridable via `RowAction.target`/`HeaderAction.target`/`RowActionsMixin.dialog_target`).
- **In-modal interactivity:** Alpine.js declaratively (`x-data`, `x-model`, `:value`, `x-bind`). Custom JS only for content logic, never for lifecycle.
- **Success:** `ModalFormViewMixin` returns 204 + `HX-Trigger: <success_event>`. Lists listen via `hx-trigger="<event> from:body"`.

If a modal won't open/close, the bug is in the base-template wrapper or `success_event` wiring — not a missing custom script.

## Table list views (`conjunto.views.TableListView`)

Stack: `TableListView` (= `SingleTableMixin + ListView`) + `RowActionsMixin` (django-tables2 mixin) + `conjunto/tables/list_card.html`. Provides search, filters, header actions, CRUD auto-refresh, `hx-push-url` bookmarkable URLs.

**Hard URL contract:** `row_actions_namespace = "app:model"` + `standard_add_action("app:model")` → expects `<ns>_create`, `<ns>_update`, `<ns>_delete` URL names (with `pk` for update/delete). Add routes or build a custom `RowAction`/`HeaderAction`.

**Symbols:**

- `RowActionsMixin` (ex `CrudTableMixin`) — appends `actions` column; merges `IRowAction` plugins from `extra_actions_menu`; filters by perm/visible; sorts by weight. Override `get_row_actions(record, request)`. `wrapper_id = "table-<slug>"`, events `<ns>:created|changed|deleted`.
- `RowAction` — dataclass per row button (label, icon, url, method, htmx, target, confirm, confirm_style, variant, permission, visible, weight).
- `IRowAction` — GDAPS interface (`menu = "<slot>"`, `to_row_action(request, record)`).
- `HeaderAction` — symmetrical to `RowAction`, no `record`. Default `variant="btn-primary"`, `target="#dialog"`.
- `IHeaderAction` — GDAPS interface for header actions. Slot via `header_actions_menu`.
- `standard_add_action("app:model")` — ready-made `+Add` using `<ns>_create`.
- `conjunto.filters.Filter`/`ChoiceFilter`/`BooleanFilter` — simple dataclasses. Complex: `filterset_class = MyFilterSet` (django-filter).

**Minimal:**

```python
# views.py
from conjunto.views import TableListView
from conjunto.filters import BooleanFilter, ChoiceFilter
from conjunto.tables import standard_add_action

class ProjectListView(TableListView):
    model = Project
    table_class = ProjectTable
    template_name = "projects/project_list.html"
    search_fields = ("name", "owner__name")
    filters = [
        ChoiceFilter("status", label=_("Status"), choices=Project.Status.choices),
        BooleanFilter("is_archived", label=_("Archived")),
    ]
    header_actions = [standard_add_action("projects:project")]
    header_actions_menu = "projects.header_actions"

# tables.py
import django_tables2 as tables
from conjunto.tables import RowActionsMixin

class ProjectTable(RowActionsMixin, tables.Table):
    row_actions_namespace = "projects:project"
    class Meta:
        model = Project
        fields = ("name", "owner", "status", "created_at")
```

```django
{% extends "projects/base.html" %}
{% block content %}{% include "conjunto/tables/list_card.html" %}{% endblock %}
```

**Delete success — 200 vs 204 is semantic, not style:**
- `"wrapper-refresh"` (default) → server **204**; wrapper reacts to `<ns>:deleted` and re-fetches. HTMX must NOT swap.
- `"row-remove"` → server **200 + empty body** with `HX-Retarget: #row-…` + `HX-Reswap: outerHTML swap:0.3s` (`RowRemoveDeleteMixin`). HTMX skips swaps on 204 (`HX-Retarget`/`HX-Reswap` ignored), so empty 200 is **required**. Don't "simplify" `RowRemoveDeleteMixin` to 204.

**Auto-refresh:** wrapper has `hx-trigger="{{ table.hx_trigger }}"` — any `HtmxFormViewMixin` view firing `HX-Trigger: <ns>:created|changed|deleted` triggers self-refetch. Live search + filter changes flow with `hx-push-url="true"`.

**Block overrides** (`list_card.html`): `search`, `filters`, `header_actions`, `card_header`, `card_body`. Use `extends`, not `include`.

## Sortable lists (`conjunto.sortable`)

Drag-and-droppable FK-linked submodels (Meeting → Agendas, Patient → Medications). Fully HTMX-declarative: Sortable.js dispatches `end`, HTMX listens, server re-numbers `weight` via `bulk_update`. **No custom JS** beyond what `conjunto.js` ships.

- **`SortableModelMixin`** (`conjunto.sortable.models`) — abstract; adds `weight = PositiveIntegerField(default=0, db_index=True)` + `Meta.ordering = ("weight", "pk")`. Classmethod `next_weight(step=10, **filter)` for auto-append.
- **`SortableReorderView`** (`conjunto.sortable.views`) — generic CBV. Attrs: `model` (req), `parent_field` + `parent_url_kwarg` (scopes queryset), `success_event`, `weight_step=10`, `_permissions_verb="change"`. Inherits `AutoPermissionsViewMixin` + `HtmxRequestMixin(enforce_htmx=True)`. POST reads `request.POST.getlist("pks")`, intersects with parent-scoped queryset, re-numbers, returns 204. Cross-parent / unknown PKs silently dropped.
- **Template tags** (`{% load sortable %}`):
  - `{% sortable_attrs reorder_url handle=".handle" indicator="" %}` — emits `class="sortable" hx-post hx-trigger="end" hx-include="[name='pks']" hx-swap="none"`.
  - `{% sortable_item obj %}` — emits `<input type="hidden" name="pks" value="{obj.pk}">`.
- **Convenience template:** `conjunto/sortable/_list.html` for the 80% case.

**Hard rules:**

- **Import from `conjunto.sortable.models`/`.views`, NEVER from `conjunto.sortable`.** Top-level re-export pulls `models.py` before `apps.ready()` and breaks startup. `conjunto/sortable/__init__.py` is intentionally empty.
- Container CSS class must be `sortable`; `conjunto.js` re-binds on every `htmx:load` with idempotency flag.
- Drag handle: `<span class="handle"><i class="ti ti-grip-vertical"></i></span>`. Override via `handle=".my-handle"`.
- `weight` from mixin — never add manually. Subclass `Meta` should inherit from `SortableModelMixin.Meta` to keep `abstract = True`.
- Auto-append on save: `if not self.pk: self.weight = type(self).next_weight(parent=self.parent)`.
- `bulk_update` writes only changed rows — safe on partial POSTs.
- **Not the same as widget reorder** (`conjunto.widgets`): widgets persist per-user dashboard layout in `ScopedSetting`; sortable persists model-level ordering in `weight`. Independent.

```python
class Agenda(SortableModelMixin, models.Model):
    meeting = models.ForeignKey(Meeting, on_delete=CASCADE, related_name="agendas")
    title = models.CharField(max_length=200)
    def save(self, *args, **kwargs):
        if not self.pk:
            self.weight = type(self).next_weight(meeting=self.meeting)
        super().save(*args, **kwargs)

class AgendaReorderView(SortableReorderView):
    model = Agenda
    parent_field = "meeting"
    parent_url_kwarg = "meeting_id"
    success_event = "agendas:reordered"
```

```django
{% load sortable %}
<ul {% sortable_attrs reorder_url=reorder_url %}>
  {% for agenda in meeting.agendas.all %}
    <li class="card mb-2 p-2 d-flex align-items-center">
      {% sortable_item agenda %}
      <span class="handle me-2"><i class="ti ti-grip-vertical"></i></span>
      <div class="flex-fill">{{ agenda.title }}</div>
    </li>
  {% endfor %}
</ul>
```

## Widget dashboard (`conjunto.widgets`)

Plugin-driven dashboard: **widget area** = named CSS-Grid container; **widgets** = draggable/resizable Tabler cards lazy-loaded via HTMX.

- **`IWidgetArea`** — `name`, `title`, `icon`, `weight`, `columns` (default 6). `get_widgets(request)`.
- **`IWidget`** — `name`, `title`, `icon`, `weight`, `area`, `permission_required`, `template`, `col_span` (default 2, `min_col_span`–`max_col_span`, cap 6), `resizable`, `removable`. Override `has_permission(request)`, `get_context_data(request)`.

Place under `<app>/widgets.py`. Lazy-fetched into `conjunto/widgets/card_shell.html`; area template `conjunto/widgets/area.html`. Per-user placement persists.

## Sidebar — three modes (`conjunto.sidebar_mode`)

Active mode is `conjunto.sidebar_mode` scoped setting (writable VENDOR/TENANT/DEVICE/USER, lockable VENDOR/TENANT). Plugin `IMenuItem`s do **not** need to be mode-aware.

| Mode | Visual | Width source |
|---|---|---|
| `full` | Icons + titles + inline submenus (Bootstrap collapse). | `conjunto.sidebar_width` (free-drag). |
| `mini` | Icons only — level-1 just. **No submenu flyout**; click follows the item's own href, parents without URL are inert. To reach a child, expand to `full`. | `--cj-sidebar-mini-width` (default `3.5rem`). |
| `collapsed` | Sidebar hidden — main content fills canvas. | n/a |

**Body classes:** `cj-sidebar-mode-full`/`-mini`/`-collapsed`. Legacy single class `cj-sidebar-collapsed` **gone**.

**Drag + topbar toggle.** Right-edge handle supports free-drag in `full` and **magnetic snap** below: `target ≥ MINI_W + 15` → full; `MINI_W ± 15` → snap mini; `< 15` → snap collapsed. Mode switches during drag are visual-only; on `pointerup` final mode persisted via `SaveSidebarModeView` (DEVICE scope default). Double-click resets to default `full` + default width. Hamburger `#cj-sidebar-toggle` toggles between `lastExpandedMode` (on `body.dataset.lastExpandedMode`, default `full`) and `collapsed`.

**Server-side enforcement.** VENDOR/TENANT lock disables toggle + handle in UI **and** makes `SaveSidebarModeView` return `403` on POST. No client-side bypass.

**JS API** (loaded by `conjunto.js`):

```js
cjSetSidebarMode(mode, { persist = true, animate = true })   // "full"|"mini"|"collapsed"
cjToggleSidebar()                                            // hamburger semantics
```

**Mobile (< 992px).** Mode classes ignored; sidebar falls back to overlay (`cj-sidebar-open` + backdrop). Persisted mode survives resize.

Per-project default: `CONJUNTO_SIDEBAR_MODE = "full"`. Menu item `title` attribute used as native tooltip in `mini` mode + a11y hint everywhere.

## Authentication & login (`conjunto.auth`)

Three pieces:

- **`ConjuntoAuthenticationForm`** (`conjunto.auth.forms`) — extends Django's `AuthenticationForm` with conditional `remember_me` gated by `auth.show_remember_me`. `helper.form_tag = False` + `helper.disable_csrf = True` — `<form>`/CSRF/submit live in `_login_card.html`. **Credentials form is NOT plugin-extendable on purpose** (anonymous request, attack surface).
- **`ConjuntoLoginView` / `ConjuntoLoginCompleteView`** (`conjunto.auth.views`) — HTMX-aware login + optional two-step tenant pick.
- **`ILoginMethod`**, **`ILoginViewExtension`**, **`IPostLoginAction`** — three plugin hooks.

```python
# myproject/urls.py
urlpatterns = [
    path("accounts/", include("conjunto.auth.urls")),     # login, login-complete
    path("accounts/", include("django.contrib.auth.urls")),  # logout, password reset
]
```

`registration/login.html` extends `conjunto/base.html`. Partials: `_login_card.html`, `_login_tenant_pick.html`. Override blocks: `login_brand`, `login_welcome`, `login_title`, `login_form_top`, `login_extensions`, `login_alternative_methods`, `login_footer`. Password-reset link guarded with `{% url 'password_reset' as … %}` + `{% if %}`.

**Two-step tenant pick:**

| Accessible tenants | Behaviour |
|---|---|
| 0 | `login()`, redirect to `next` (tenant-less). |
| 1 | `login()`, stamp tenant id into session, redirect. |
| 2+ | **No `login()`** yet. Pending (`user_id`, `backend`, `next`, `remember_me`, `ts`) stashed in session under `PENDING_LOGIN_KEY`; tenant-pick partial returned. User finalizes via POST to `ConjuntoLoginCompleteView`. State older than `PENDING_LOGIN_TTL` refused. |

`form_invalid` re-renders credentials partial with **HTTP 422** for HTMX.

**Remember-me — single source of truth.** Wire to `request.session.set_expiry()` via `form.get_remember_me()` (returns `False` whenever `auth.show_remember_me` is off, even if POST says `remember_me=on`). Lifetime: checked → `auth.session_lifetime_remembered`; unchecked/hidden → `auth.session_lifetime_default`.

**`ILoginViewExtension`** — react to successful login (audit, prefetch, check-in). Classmethods:
- `form_valid(view, request, user, form)` — fires **after** `login()`. On two-step path fires in `LoginCompleteView` with `form=None` (original form is gone — extensions needing step-1 data stash it in `request.session`).
- `alter_context_data(view, ctx)` — mutate template context.

Hooks must catch own non-fatal errors; raises propagate and break login.

**`IPostLoginAction`** — renderable hook fired on every authenticated page load via `{% render_plugins "IPostLoginAction" %}`. Idiomatic for one-shot post-login modals (check-in, consent). **Implementations must return a `Context`, not a `dict`.**

**`ILoginMethod`** (`conjunto.api.interfaces`) — alternative sign-ins (social, SSO, WebAuthn, magic link). Attrs: `name`, `label`, `icon`, `url`, `weight`, `template_name`. Optional: `is_enabled(request)`, `render(request)`. Rendered into `login_alternative_methods` via `{% login_methods %}` (load `conjunto`).

## WebSockets (`IWebsocketURL`, `ModelConsumer`)

channels + channels-redis are conjunto deps; consumers don't list them again.

**Activation:** `CONJUNTO_WEBSOCKETS_ENABLED` (default auto-detect: `"channels" in INSTALLED_APPS and ASGI_APPLICATION`). Exposed as `cj_layout.websockets`. **Always gate WS-bound UI with `{% if cj_layout.websockets %}`** — never `{% if user.is_authenticated %}` alone.

```python
from conjunto.api.interfaces import IWebsocketURL
from myapp.consumers import MyConsumer

class MyAppWebsocketURL(IWebsocketURL):
    urlpatterns = [path("ws/myapp/", MyConsumer.as_asgi())]
```

`conjunto.routing.websocket_urlpatterns` auto-collects impls; `conjunto.routing.asgi_application()` wires them in:

```python
# myproject/asgi.py
from conjunto.routing import asgi_application
application = asgi_application()
```

**`ModelConsumer`** (`conjunto.consumers`) — renders HTML template on every `model.updated` channel-layer event, sends over wire (typed for HTMX `ws` extension swaps). Subclass: set `model`, `template_name`, override `get_group_name()` (per-user/per-object scope) and `get_template_context(event)`. Pair with `post_save` signal broadcasting `{"type": "model.updated", ...}`. **Never re-implement** — old `medux.core.consumers.ModelConsumer` is gone.

`htmx-ext-ws` (`js/htmx/ext/ws.js`) is in `_vendor.registry`; `app_base.html` loads it conditionally on `cj_layout.websockets`.

**Channel layer:** conjunto does NOT ship a default `CHANNEL_LAYERS`. Consumers configure (`InMemoryChannelLayer` DEBUG, `RedisChannelLayer` prod). Misconfig manifests as "consumer connects, nothing arrives".

## Notifications (`conjunto.notifications`)

Per-user bell dropdown fed by WS consumer pushing rendered list on every `Notification` change. **Optional** — drop from `INSTALLED_APPS` and bell disappears.

**Activation chain:** (1) `conjunto.notifications` ∈ `INSTALLED_APPS`, (2) `cj_layout.websockets` true, (3) user authenticated. Gate is `{% if cj_layout.notifications %}` in `app_base.html`'s `top_bar_right`. Don't render the bell yourself — duplication produces phantom dropdown.

**Public API:**

```python
from conjunto.notifications import add, info, success, warning, error

info(user, _("Backup completed."))
warning(user, _("License key expires in 7 days."), dismissible=True)
error(user, _("Sync failed."), blocking=True)
add(user, level=messages.INFO, message=_("..."), blocking=False, dismissible=True)
```

`level` reuses `django.contrib.messages` constants. `blocking=True` interrupts until acknowledged; `dismissible=True` (default) allows toast close. Triggers `post_save` → broadcasts to **`notifications.user.<pk>`** channel group; `NotificationConsumer` re-renders dropdown to every connected tab via `hx-swap-oob`.

**Model**: `recipient` (FK), `level`, `message` (1024), `blocking`, `dismissible`, `created`, `read_at`.

**Initial load:** `hx-trigger="load"` GET against `notifications:notifications-unread` renders the same template as WS consumer.

**Customization:** override `conjunto/notifications/dropdown_content.html` and `toast.html` via Django's loader. **Never** re-implement consumer or signal handler.

**No double dropdown:** MedUX (or any consumer) **must not** override `top_bar_right` to add a bell — conjunto already renders it. If overriding `top_bar_right` for adjacent items, call `{{ block.super }}`.

## User profiles and avatars (`conjunto.profiles`)

`UserProfile` = `OneToOneField(AUTH_USER_MODEL, related_name="profile")`, auto-created via `post_save` (`user.profile` always safe). Fields: `avatar` (`ImageField`, `upload_to="avatars/<user_pk>/<uuid>.<ext>"`), `created_at`, `updated_at`. Pre-existing users: `UserProfile.get_or_create_for(user)`.

**Wire-up:** add `"conjunto.profiles"` to `INSTALLED_APPS` + migrate. Registers `UserAvatarFormPlugin` (`ISettingsForm`) under `User → Profile`. Avatar form template uses `hx-encoding="multipart/form-data"`.

**`{% avatar %}` tag** lives in **core** (`conjunto.templatetags.avatar`), not in `conjunto.profiles` — `{% load avatar %}` always succeeds, falls back to initials when profiles isn't installed. Never raises.

**Hard rule:** **Never `{% load profiles %}`** — that library does NOT exist. All conjunto templates use `{% load avatar %}`. Partial: `conjunto/_avatar.html` (also core). Symptom `TemplateSyntaxError: 'profiles' is not a registered tag library` → fix with `{% load avatar %}`.

```django
{% load avatar %}
{% avatar %}                                  {# context.user / request.user #}
{% avatar some_user %}
{% avatar some_user size="xs" extra_classes="me-2" %}
```

Sizes: `xs`/`sm`/`md` (default)/`lg`/`xl`/`2xl` → `avatar-<size>`. Initials: `first_name`+`last_name` → `get_full_name()` → `username[:2]` → `email[:2]` → `"?"`. Programmatic: `conjunto.profiles.utils.compute_initials(user)`.

**Never hand-roll** `<span class="avatar" style="background-image: url(…)">…</span>` — use `{% avatar %}`.

## Form widgets & fields (`conjunto.forms`)

Always reach for conjunto fields/widgets first — never reimplement Tabler-styled inputs per plugin.

| Field / Widget | Use for |
|---|---|
| `TimeField` / `TimePickerInput` | Time input. Smart digit-only parsing + snap buttons + 12h display + `clean()` rounding. |
| `DatePickerInput` | Date inputs. Wraps Litepicker; `end_field_name` for ranges. |
| `PersistentFileField` / `PersistentFileWidget` | File upload surviving form re-renders (HTMX swaps, validation, wizard). |
| `SafeHTMLField` | WYSIWYG output, server-side bleach with deny-by-default whitelist. |
| `SelectGroup` / `SelectGroupMultiple` | Tabler `.form-selectgroup` radio/checkbox grids; `as_btn_group=True` for `.btn-group`. Older — prefer specific subclasses below. |
| `ButtonGroupSelect` / `ButtonGroupSelectMultiple` | Tabler `.btn-group` (default) / `.btn-group-vertical` (`vertical=True`) radio/checkbox group. Use for short option lists. |
| `IconSelect` / `IconSelectMultiple` | Tabler `.form-selectgroup` icon-tile picker. `choices` = `(name, label)`; `name` is Tabler icon without `ti-` prefix. Pair with `IconField`. |
| `ColorField` / `ColorSelect` / `ColorSelectMultiple` | Tabler `.form-colorinput` color swatch picker. `ColorField` = `ChoiceField` with `TABLER_COLORS` pre-wired (radio; `multiple=True` → checkboxes). Value doubles as `bg-{value}` class. `light_colors=("white", …)` adds `form-colorinput-light` border. No JS, no `Media`. |
| `PartialDateField` | Locale-aware date input accepting year (`2024`), month (`03/2024` / `2024-03`), or full date. Returns `PartialDate(date, precision)` from `to_python`. Pair with `*_precision` companion CharField on model; unwrap in `Form.clean()`/`save()`. |
| `IntegerStepperInput` | Integer field with clickable `[-]`/`[+]` icon-addons (Alpine, no roundtrip). `size`, `step`, `min`, `max`, `align`, `allow_negative=False`. Pass `attrs={"x-model.number": "..."}` to bind into surrounding Alpine scope. Renders `<input type="text" inputmode="numeric">`. |
| `DependentFieldsMixin` | Forms with one field controlling another (queryset, visibility, required). Own section. |

### Time input

```python
from conjunto.forms import TimeField, TimePickerInput

class TimeEntryForm(forms.Form):
    start_time = TimeField(snap=15, round_to=15, round_mode="down")
    end_time   = TimeField(snap=15, round_to=15, round_mode="up")

class AlarmModelForm(forms.ModelForm):
    class Meta:
        widgets = {"wake_up": TimePickerInput(snap=5, format_12h=True)}
```

Smart parsing (JS `time_picker_input.js` ≡ Python `_smart_parse_time`):

| Input | Result | Rule |
|---|---|---|
| `5` | `05:00` | 1 digit → hour |
| `12` | `12:00` | 2 digits ≤ 23 → `HH` |
| `45` | `04:50` | 2 digits > 23 → first=hour, second=tens-min |
| `230` | `23:00` | 3 digits, first two ≤ 23 → `HH:M0` |
| `730` | `07:30` | 3 digits, first two > 23 → `0H:MM` |
| `0350` | `03:50` | 4 digits → `HH:MM` |

- Live `##:##` mask; POSTed value canonical 24h `HH:MM`.
- `snap=N` → snap-to-next-N (from `12:23`, `+` lands on `12:30`); ↑/↓ keys, **Shift+↑/↓** = ±60min. **Buttons rendered only when `snap` is set**, disabled until field valid.
- `show_buttons=False` → suppress buttons, keep snap on arrow keys.
- `format_12h=True` → display only; POSTed value canonical 24h. Live mask skipped.
- `round_to=N, round_mode="up"|"down"|"nearest"` → server rounding on `clean()`; independent of `snap`.
- Pure JS, nothing in `CONJUNTO_LIBRARIES`. Re-init on `htmx:load`.
- **Don't reimplement** medux-timetracker-style `TimeSelector` — replace with `TimeField`/`TimePickerInput`.

### Date input

```python
from conjunto.forms.widgets import DatePickerInput

class HolidayForm(forms.Form):
    first_day = forms.DateField(widget=DatePickerInput(end_field_name="last_day"))
    last_day  = forms.DateField(widget=DatePickerInput)
```

Litepicker; requires `litepicker` in `CONJUNTO_LIBRARIES`.

### Persistent file

Survives form re-renders (HTMX swap, POST validation error, wizard step) — renders "already uploaded `<name>` [Replace] [Remove]" when `initial` carries a file ref. Auto-pairs with `DependentFieldsMixin`'s `hx-preserve` for files. Use instead of plain `forms.FileField`.

### Color picker

```python
from conjunto.forms import ColorField, ColorSelect, TABLER_COLORS

class TagForm(forms.Form):
    color = ColorField(initial="blue")
    # ad-hoc on a CharField: forms.CharField(widget=ColorSelect())
    # subset:                ColorField(choices=[("red", "Red"), ("green", "Green")])
    # multi:                 ColorField(multiple=True)  # checkboxes; persist the list
```

Renders Tabler `.form-colorinput` (radio default; `multiple=True` → checkboxes via `ColorSelectMultiple`). `value` doubles as Bootstrap class — `"blue"` → `bg-blue`. `light_colors=("white",)` (default) wraps pale swatches in `form-colorinput-light` so they stay visible on light bg. Pure CSS — no JS, no `Media`, no `update_libraries` entry. Validates against palette via `ChoiceField`.

### Crispy-forms

All conjunto widgets work with `{{ form|crispy }}` out of the box. Only `PersistentFileField` ships a Crispy template override (`bootstrap5/layout/field_file.html`).

## Model file fields (`conjunto.fields`)

- `ProtectedFileField` / `ProtectedImageField` — plaintext under `PROTECTED_MEDIA_ROOT`; URL gated by Django (auth/tenant). Bytes unencrypted.
- `EncryptedFileField` / `EncryptedImageField` — AES-256-GCM stream encryption at rest (Rogaway STREAM, 4 MiB chunks). UUID4 filenames (`<uuid>.enc`), per-file DEK wrapped by tenant KEK, key rotation via manifest re-wrap. `.url` raises — serve via `FileResponse(field.open_decrypted())` so the audit log fires under your access check. `EncryptedImageField` strips EXIF/ICC/XMP by default. Pluggable backend via `CONJUNTO_FILE_ENCRYPTION_BACKEND` (medux ships `medux.crypto.file_backend`). Bulk-migrate plaintext rows in place: `manage.py encrypt_filefield <app.Model> <field>`. → docs/encrypted-files.md
- **Companion `BinaryField` required, no magic.** Model must declare `<field>_manifest = models.BinaryField(null=True, blank=True, editable=False)` next to every `EncryptedFile/Image-Field` (rename via `manifest_field="custom"`). Without it `manage.py check` raises `conjunto.E001` (missing) / `conjunto.E002` (wrong type). The instance also needs `tenant_id` (FK or int) so the backend can pick the KEK.

## Extensible forms (`conjunto.extensible_forms`)

Reusable composite-form framework: one master `ModelForm` + N plugin-contributed sub-forms rendered flat into a single `<form>` (tab order follows DOM order). Use when other plugins must contribute fields to a master entity's form (Patient, FamilyHistoryEntry, …) instead of separate cards.

**Public surface** (`from conjunto.extensible_forms import …`):

| Symbol | Purpose |
|---|---|
| `FormSlot` | Abstract `TextChoices` base; owner subclasses declare slots. Convention: last member = `EXTRA` catch-all for unmapped master fields. |
| `FormSectionContract` | Section attribute mix-in: `form_class`, `instance_attr` (also used as form `prefix`), `slot`, `weight`, `check`. Combine with `gdaps.api.Interface` (`__sort_attribute__ = "weight"`, `__instantiate_plugins__ = False`). |
| `CompositeForm` | Subclass per master model; set `master_form_class`, `section_interface`, `owner_attr`, `event_namespace`, `field_slot_map`. Discovers sections, aggregates validation + `media`, atomic `save()` (master first, then `setattr(obj, owner_attr, master); obj.save()` per section). |
| `build_slot_layout()` | Crispy `Layout` from slot map + section weight. |
| `{% extensible_form_attrs composite %}` | Renders `x-data="extensibleForm(...)"` + namespaced event listener on `<form>`. |
| `conjunto/js/extensible_form.js` | Alpine factory backing the reactive `fields` object. |

**Event vocabulary** (`<ns>` = `event_namespace`):
- `<ns>:set` — `{ name, value, only_if_empty? }` → set master field value (skip if `only_if_empty` and field non-empty).
- `<ns>:invalidate` — `{ name, message }` → client-side error class.

**Owner plugin recipe.** Declare slot enum + section interface + composite subclass; call `PluginManager.load_plugin_submodules("<topic>_form_sections")` in `apps.ready()`. Template:

```django
{% load static extensible_form %}
<form {% extensible_form_attrs composite %} method="post"
      hx-post="..." hx-target="#dialog" hx-swap="innerHTML">
  {% csrf_token %}
  {{ composite|safe }}
  <button type="submit">Save</button>
</form>
<script src="{% static 'conjunto/js/extensible_form.js' %}"></script>
{{ composite.media }}
```

**Contributor recipe.** Drop `<topic>_form_sections.py` in the contributing plugin with a class subclassing the section interface (`form_class`, `instance_attr`, `slot`, `weight`, optional `check`). Sub-form ships its JS via `Media.js` — composite aggregates automatically.

Current users: `medux-patients` (`PatientCompositeForm` / `PatientFormSlot` / `IPatientFormSection`); `medux-austria` contributes `AustriaPatientFormSection` dispatching `patient-form:set` to auto-fill `birth_date` from SVNR.

Author guide: `Projekte/conjunto/docs/extensible_forms.md`.

## Dependent form fields (`DependentFieldsMixin`)

For forms where one field affects another's queryset/visibility/required state. **Only supported pattern in conjunto** — never use Alpine `x-model`/`x-show` in HTMX-swapped areas (Alpine state persists across swaps → stale values).

How it works:
1. Mixin auto-discovers `<fieldname>_changed(value)` methods.
2. Sets `hx-get`, `hx-trigger="change"`, `hx-include="closest form"`, `hx-target`, `hx-swap="outerHTML"` on each trigger field's widget — **no manual template markup**.
3. On every instantiation (initial + fragment re-render) calls callbacks with current values (from `data`/`initial`/`instance`).
4. FK fields: raw PK strings auto-resolved via `_resolve_field_value()`.

```python
from conjunto.forms import DependentFieldsMixin

class MyForm(DependentFieldsMixin, forms.ModelForm):
    update_url = reverse_lazy("myapp:form_fragment")
    # hx_target = "#my-form"  # optional, default: "closest form"

    def country_changed(self, value):
        if value:
            self.fields["state"].queryset = State.objects.filter(country=value)

    def type_changed(self, value):
        show = value and getattr(value, "code", None) == "special"
        self.fields["detail"].required = show
        if not show:
            self.fields["detail"].widget = forms.HiddenInput()
```

No `trigger_fields` list — auto-discovered.

```python
from conjunto.htmx.views import DependentFieldsView

class MyFormFragmentView(DependentFieldsView):
    form_class = MyForm
    template_name = "myapp/form.html#form-body"   # Django 6 partial
```

```django
<form method="post" action="{% url 'myapp:submit' %}">
  {% csrf_token %}
  {% partialdef form-body inline %}
    {{ form|crispy }}
    <button type="submit" class="btn btn-primary">{% translate "Save" %}</button>
  {% endpartialdef %}
</form>
```

Conditional validation:

```python
def clean(self):
    if self.cleaned_data.get("type") == "special":
        self.fields_required(["detail", "extra_info"])
    return self.cleaned_data
```

**Key rules:**
- **No Alpine** in HTMX-swapped form areas. Visibility/state are server-side only.
- `hx-include="closest form"` sends all current values — server has full context.
- `update_url` must accept GET params and render the form partial.
- Works with crispy-forms.

## TomSelect + HTMX (`django_tomselect`)

`django_tomselect` widgets survive HTMX swaps only with conjunto's two integration steps. **Don't write hand-rolled `htmx:afterSwap` listeners or `hx-on::after-swap` one-liners** — conjunto already handles it.

**Required setup:**

1. **Load TomSelect assets in `<head>`, not body-end.** With `use_htmx=True`, the widget renders an inline init script directly after `<select>` — `window.TomSelect` must be defined synchronously while body is parsed.

   ```django
   {% load django_tomselect %}
   {% block extra_css %}
       {{ block.super }}
       {% tomselect_media %}
   {% endblock %}
   ```

   Loading via `{% block app_scripts %}` → `ReferenceError: TomSelect is not defined`.

2. **`STATICI18N_ROOT` + `STATICFILES_DIRS`** wired + `python manage.py compilejsi18n` run, else `/static/jsi18n/<lang>/djangojs.js` 404s and TomSelect i18n breaks.

**Conjunto-side automation** (in `conjunto.js`, declarative via `data-tomselect-*` on container, typically `<form>`). Global `htmx:afterSwap` listener re-applies after every swap, idempotent via `_cjTomSelectInited`. **Never write hand-rolled lifecycle JS** — extend `conjunto.js` with a new `data-tomselect-*` attribute instead.

- **Always-on bug fix:** `django_tomselect` leaks `ts-hidden-accessible` (sr-only) onto `.ts-wrapper` after re-init → wrapper becomes 1×1 px clipped. Conjunto strips it on every swap.
- **`data-tomselect-clear`:** clear all enclosed instances after every swap (auto-submit forms returning to empty pill list).
- **`data-tomselect-tab-advances`:** when Tab pressed in open dropdown with active option, select AND let browser's Tab move focus.
- **`data-tomselect-submit-on-enter`:** when Enter selects from open dropdown, also submit surrounding form via `requestSubmit()`. Tab- and click-driven selections do NOT submit.

```django
<form hx-post="{% url '...' %}" hx-target="#wrapper" hx-swap="innerHTML"
      data-tomselect-clear data-tomselect-tab-advances data-tomselect-submit-on-enter>
  {{ form.members }}
  {{ form.arrived_at }}
  <button type="submit">{% translate 'Add' %}</button>
</form>
```

All four hooks compose freely. No hardcoded select id, no inline JS, no `hx-on`.

**`hx-trigger` syntax for change-on-select:** `change from:#id_<fieldname>` (colon after `from`, `#` for CSS id). Django default id is `id_<fieldname>`, **never** `<fieldname>_id`.

## Keyboard shortcuts (`conjunto.shortcuts`)

Plugin-extensible shortcut system. Activated by adding `"conjunto.shortcuts"` to `INSTALLED_APPS`. Storage via `ScopedSetting` (namespace `"shortcuts"`). Client = AlpineJS store + single global `keydown` listener; no Mousetrap, no hotkeys-js.

**Action registration** — `IShortcutAction` (auto-discovered from `<app>/shortcuts.py`):

```python
from conjunto.shortcuts.interfaces import IShortcutAction
from conjunto.settings.scoped.models import Scope

class CashbookCreateEntryAction(IShortcutAction):
    namespace = "cashbook"; name = "entry.create"   # full id = "cashbook.entry.create"
    title = _("New cashbook entry"); icon = "plus"; category = _("Actions")
    default_key = "n"; mode = "single"               # mode: "modifier"|"single"|"auto"
    scope_kind = "app"; scope_match = "cashbook:*"   # URL-name glob OR callable(request)
    handler_kind = "htmx-get"                         # navigate|htmx-get|htmx-post|click-selector|custom-event
    handler_params = {"url_name": "cashbook:entry-add", "target": "#dialog"}
    permission_required = "cashbook.add_entry"
    # writable_scopes / lockable_scopes default to [VENDOR, TENANT] — DO NOT widen casually
```

**Hard rules:**

- **Default `writable_scopes = [Scope.VENDOR, Scope.TENANT]`**, `lockable_scopes` same. USER/DEVICE/GROUP cannot write by default. Opting in `Scope.USER` requires `description=` justification (system check `S003` warns).
- **`scope_kind`** decides activation: `global` (always), `app` (URL-name glob match), `view` (only when explicitly mounted via template tag/JS API).
- **Activation scope ≠ storage scope.** Activation = runtime stack (`global`/`app:cashbook:*`/`view:foo`); storage = `ScopedSetting` 5-tier hierarchy.
- **`always_active=True`** is a whitelist for help/save/search/palette — bypasses "no fire while input focused" for `single`-mode.
- **Key normalisation:** single-step keys only (chord sequences like `g d` were dropped 2026-05-18 — they swallowed keystrokes from focused inputs). Examples: `Ctrl+s`, `Ctrl+Shift+/`, `Alt+d`, `F2`, `Escape`, `/`. Modifier order fixed: `Ctrl→Alt→Shift→Meta→key`. `Ctrl` auto-maps to `Cmd` on Mac (use `CtrlOnly+…` for Win-only).
- **`seed_shortcuts` mgmt command** writes `default_key` to VENDOR scope; idempotent; auto-called from `MeduxPluginAppConfig.install()`.
- **Effective bindings** injected as `cj_layout.shortcuts.bindings` (server-side filtered on `is_available` + perms).
- **`#dialog` reuse:** cheat-sheet (`?`) and palette (`Ctrl+K`, Phase 2) render into standard `#dialog`.

**Template tags (always preferred over hand-rolled `<button>`):**

```django
{% load shortcuts %}
{% shortcut_button "cashbook.entry.create" class="btn btn-sm btn-primary" %}
{# emits button + tooltip + <kbd>n</kbd> badge + aria-keyshortcuts="n" + hx-attrs #}

<button class="my-class" hx-get="…">Save {% shortcut_kbd "global.form.save" %}</button>

{% shortcut_scope "cashbook:entry-list" %}
  …  {# auto-pushes/pops the view scope on the AlpineJS store #}
{% endshortcut_scope %}
```

**Settings UIs (auto-mounted):**

| URL | Audience | Editable scope |
|---|---|---|
| `/adm/vendor/shortcuts/` | superuser | VENDOR |
| `/adm/tenant/shortcuts/` | tenant_admin | TENANT (read-only where Vendor locked) |
| `/settings/shortcuts/` | end user | only actions with `Scope.USER ∈ writable_scopes` (rare); else read-only cheat-sheet |

Live conflict detection on key entry (client-side debounced + server-side authoritative via `shortcuts:check-conflict`). Hard conflict (same scope) blocks submit; soft conflict (different scopes) → yellow hint.

**System checks** (`manage.py check`):

- `conjunto.S002` — ERROR: same default key in overlapping scopes (build-breaker). Non-overlapping scopes are silent (idiomatic `n` = "new" in every app).
- `conjunto.S003` — WARNING: action allows `Scope.USER` without `description=` justification
- `conjunto.S004` — WARNING: browser-reserved key (`Ctrl+W` etc.)

**Anti-patterns:** inline `keydown` handlers / `<element x-on:keydown.…>` for binding; per-template `data-shortcut="n"`; Mousetrap, hotkeys-js, or any other JS shortcut lib; writing to USER scope for non-cosmetic actions; reimplementing cheat-sheet/palette in a plugin.

## Accessibility baseline (`conjunto.a11y`)

Hard precondition for keyboard operability. Checks via `manage.py check --tag a11y`; CI hook `--fail-level WARNING` blocks new violations (existing ones whitelisted in `docs/a11y-debt.md`).

**Hard rules:**

- **Skip-link required:** `app_base.html` block `skip_links` defaults to `<a class="visually-hidden-focusable" href="#main-content">{% trans "Skip to main content" %}</a>`; `<main id="main-content">` is mandatory.
- **`:focus-visible` ring** in `_a11y.scss`, never `outline: 0`. Bootstrap defaults overrideable if ring stays ≥ 2px contrast 3:1.
- **Modal default `data-bs-keyboard="true"`** (BREAKING from old default — Esc must close). Wizard exception via override block.
- **Tab order = DOM order.** Only `tabindex="0"` (default) or `-1` (out). No positive `tabindex`. Visual reordering via Flexbox `order:` is a Layer 1 bug if it diverges.
- **Clickable non-buttons:** `<div hx-get="…">` MUST get `role="button" tabindex="0"` + Enter/Space handler — use `{% kbd_clickable %}` template tag.
- **Icon-only buttons** require `aria-label` (system check `A004`).
- **`htmx:afterSwap` focus restore** for `#dialog` modal — automatic via `conjunto.js`, no per-template wiring.

**System checks (a11y tag):**

- `conjunto.A001` — `<div>`/`<span>` with `hx-*` and no `role`/`tabindex`
- `conjunto.A002` — `<input>` without `<label>`
- `conjunto.A003` — `<img>` without `alt`
- `conjunto.A004` — `<button>` without visible text and without `aria-label`

## Import-collision heads-up

`conjunto.settings` (package) and `django.conf.settings` (module attribute) collide if both bind to local `settings` in one file. Inside `conjunto/settings/*.py`, use `from django.conf import settings as django_settings`.
