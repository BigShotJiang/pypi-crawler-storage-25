# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.5.2] - 2026-05-21
### Added
- `BulkAction` dataclass + `IBulkAction` GDAPS interface +
  `get_bulk_actions()` helper in `conjunto.tables` — multi-record
  action bar for list pages, symmetrical to `HeaderAction`/`IHeaderAction`.
  Buttons auto-include `[name='pks']:checked` so the user's selection
  travels with the request. Confirmation styles: `modal` (default,
  fetches a confirm modal into `#dialog`), `inline` (browser-native
  `hx-confirm`), or none (direct POST).
- `BulkActionView` base in `conjunto.htmx.views` — receives `pks` via
  `request.POST.getlist()`, scopes by `model` (or `get_queryset()`),
  runs `perform(queryset)`, returns 204 + `HX-Trigger: <success_event>`.
  Default `GET` renders the confirm modal so the modal-confirm flow
  works without per-action boilerplate.
- Sticky bottom selection bar
  (`conjunto/tables/_bulk_actions_bar.html`) + checkbox-column
  partials (`_bulk_select_th.html` / `_bulk_select_td.html`) +
  default confirm modal (`_bulk_confirm.html`). Alpine factory
  `cjBulkSelect()` (`conjunto/js/bulk_select.js`) tracks selection
  count, master-checkbox state (incl. indeterminate), and the clear
  helper — wired into `APP_JS` so it loads everywhere `app_base.html`
  is in use.
- `DateStepperInput` (`conjunto.forms.widgets`) — configurable date input
  rendered as a single Tabler `input-group` with optional day stepper
  (`<` / `>`), week stepper (`<<` / `>>`), `Today` button, and Litepicker
  popup on focus. Keyboard shortcuts on the input mirror the buttons
  (`ArrowUp`/`ArrowDown` for day, `Shift+Arrow*` for week).

### Fixed
- datepicker: Litepicker popup now closes when its containing Bootstrap
  modal starts hiding (was leaving the picker overlay on screen after
  modal close). Also re-initialises on `htmx:load` so pickers in
  HTMX-swapped fragments work.

### Changed
- shortcuts: `conjunto.S001` retired. Same default key in non-overlapping scopes
  (idiomatic `n` = "new" across every app) used to emit a noisy INFO at every
  `manage.py check` / `runserver` boot — now silent. Only real conflicts
  (overlapping scopes, `S002`) get reported.

## [0.5.0] - 2026-05-18
### Changed
- **BREAKING**(shortcuts): chord shortcuts dropped (e.g. `g X`); migrate to modifier combos like `Alt+X`.
- **BREAKING**: `EncryptedFileField` / `EncryptedImageField` no longer auto-injects the
  companion `<field>_manifest` `BinaryField` via `contribute_to_class`. Models must declare it
  explicitly (`<field>_manifest = models.BinaryField(null=True, blank=True, editable=False)`)
  or pass `manifest_field="custom_name"` to point at a different name. `manage.py check`
  enforces the companion (`conjunto.E001` missing, `conjunto.E002` wrong type). Reason: the
  implicit field broke `CreateModel` migrations on fresh plugins (duplicate column on
  `migrate`).

### Added
- `EncryptedFileField` / `EncryptedImageField` (`conjunto.fields`) — at-rest AES-256-GCM streaming with pluggable backend (`CONJUNTO_FILE_ENCRYPTION_BACKEND`). UUID filenames, explicit sidecar manifest companion, key-rotation via manifest re-wrap, EXIF strip on images. Includes `encrypt_filefield` management command for migrating existing plain `FileField`/`ProtectedFileField` rows in place. → docs/encrypted-files.md
- feat: `conjunto.extensible_forms` — reusable composite-form framework. Provides `FormSlot`
  (abstract `TextChoices` base), `FormSectionContract` mix-in, `CompositeForm` (master + N plugin
  sub-forms, atomic save, aggregated media, JSON initial), `build_slot_layout`,
  `extensibleForm()` Alpine factory and `{% extensible_form_attrs %}` template tag. See
  `docs/extensible_forms.md` for the author guide.

## [0.4.2] - 2026-05-09
### Documentation
- Migration note for plugins moving off `medux.notifications` to `conjunto.notifications` (no shim — explicit import switch).

## [0.4.1] - 2026-05-07
### Added
- `tenant_switched` Django signal in `conjunto.tenants.signals` — emitted by `TenantPickView`/`LoginCompleteView` after a tenant switch so consumer apps can clear tenant-bound session state.
- `{% help_hint %}` block template tag for inline tooltips.
- `PartialDateField` form field — locale-aware day/month/year input returning a `PartialDate(date, precision)` for medical-history fields where only the year (or month) is known.
- `ButtonGroupSelect` / `ButtonGroupSelectMultiple` form widgets — Tabler `.btn-group` radio/checkbox group; horizontal default, `vertical=True` for `.btn-group-vertical`.
- `document_title_body` block in `app_base.html` for full-bleed document layouts.

### Fixed
- Trailing-slash menu item URLs now match sub-paths in `IMenuItem.is_active`.

## [0.4.0] - 2026-05-06
### Added
- `IconField` form field (`conjunto.forms`) — Tabler `form-selectgroup` icon picker for a curated `choices=` set; `multiple=True` for checkbox mode. → docs/components/icon_field.md
- `TenantUserFKMixin` (abstract User model mixin in `conjunto.tenants.users`) — adds a NOT NULL `tenant` FK plus a `tenants` (plural) property listing the user's active TenantMemberships. Combine with `AbstractUser`. Project users that adopt the mixin gain a DB-level guarantee that every user has a home tenant.
- `TenantAwareUserManagerMixin` (`conjunto.tenants.managers`) — UserManager mixin that defaults the `tenant` FK to the seed tenant in `create_superuser` / `create_user` so `manage.py createsuperuser` works against the new NOT NULL constraint.
- `conjunto.tenants.signals` — `post_migrate` seeds an `Admin` tenant on first migrate (slug `admin`); `post_save User` auto-creates the home `TenantMembership(role=CONJUNTO_DEFAULT_USER_ROLE)`. Both idempotent, opt-in via the User model adopting `TenantUserFKMixin`.
- `TenantFormMixin` (`conjunto.forms.tenant`) — form mixin enforcing a `tenant` kwarg with a `hide_field_if_single(field, queryset)` helper for single-choice picker hiding.
- Setting `CONJUNTO_DEFAULT_USER_ROLE` (default `"user"`, in `conjunto.conf`) controls the role used by the home-Membership signal.
- `IntegerStepperInput` and `DecimalStepperInput` form widgets — Tabler-styled `[-] input [+]` numeric steppers sharing a common `BaseStepperInput` (template + Alpine plumbing). Alpine-driven (no HTMX), drop-in for `forms.NumberInput`; `size`, `step`, `min`, `max`, `align`, `allow_negative` configurable; `attrs` pass through Alpine directives (e.g. `x-model.number`). `DecimalStepperInput` adds locale-aware decimal separator (via `get_format("DECIMAL_SEPARATOR")`), auto-derived `decimal_places` from `step`, and `toFixed`-based commit to neutralise float drift. → docs/usage/stepper.md
- `conjunto.notifications` sub-app — per-user bell dropdown fed by a Channels consumer (`notifications.user.<pk>` group), public API `add/info/success/warning/error(user, ...)`, gated by `cj_layout.notifications`. Owns `IWebsocketURL`, `ModelConsumer`, `conjunto.routing.asgi_application()` and the `cj_layout.websockets`/`.notifications` flags. → docs/usage/notifications.md
- Three-mode sidebar (`full`/`mini`/`collapsed`) with magnetic drag-snap; `conjunto.sidebar_mode` scoped setting (V/T/DEVICE/USER). → docs/usage/sidebar.md
- Two-step login: tenant picker swap when user has access to ≥2 tenants. → docs/usage/tenants.md
- Post-login plugin hooks: `ILoginViewExtension` (form_valid / context) + `IPostLoginAction` (one-shot modal). → docs/usage/auth.md
- `auth.show_remember_me` scoped setting gates the Remember-Me checkbox. → docs/usage/auth.md
- `conjunto.settings.scoped.resolver.get_resolution()` returns a `Resolution` dataclass (`value`, `winning_scope`, `lock_scope`, `fallback`) so UI layers can render lock indicators + default-hints without a second resolver pass. `get_effective` is unchanged.
- `ITenantLifecycle` interface plus tenant `post_save` signal handler and `setup_tenant` management command — plugins contribute idempotent per-tenant initialization. → docs/usage/tenants.md

### Changed
- `{% tenant_badge %}` hidden for users with a single accessible tenant.

### Changed (BREAKING)
- `conjunto.session_lifetime_default`/`_remembered` moved to `auth.session_lifetime_*`; data migration `conjunto_settings/0008` rewrites existing rows.
- Body class `cj-sidebar-collapsed` removed; replaced by `cj-sidebar-mode-collapsed` (one of three `cj-sidebar-mode-*` classes).
- Tenant switcher: "Work without tenant" entry and superuser clear-action removed; `TenantPickView` no longer accepts an empty selection; middleware `explicit_no_tenant` branch dropped — every authenticated user holds a `TenantMembership` after the user→tenant FK refactor, so a session-bound "no tenant" state is unreachable.

### Added
- `ISettingsForm.extra_success_triggers(form, request)` optional hook — extra HX-Trigger entries fired alongside `showToast` after a successful settings-form save (used e.g. by the color-scheme form to sync `localStorage["tabler-theme"]` so the next reload's pre-paint script doesn't revert the skin).
- `theme_toggle.js` listens for `colorSchemeChanged` events and mirrors the change into `<html data-bs-theme>` plus `localStorage["tabler-theme"]` — symmetric with the topbar toggle.
- `ISettingsForm.requires_full_reload` opt-in — when `True`, a successful POST sets `HX-Refresh: true` so the browser reloads, deterministic for theme/layout-bound settings (color scheme, sidebar width, topbar position, language, timezone) where re-applying live across all Tabler surfaces is brittle.

### Fixed
- `ConjuntoMiddleware.__call__` leaked the tenant ContextVar across requests when a maintenance redirect hit the early-return path (the `try/finally` reset block sat below the redirect). The `try/finally` now wraps the entire request lifecycle, so every code path out of `__call__` resets the ContextVar.
- Regression test pins login form `username` field to `<input type="text">` so a future widget tweak cannot reintroduce the `type="email"` bug that blocked non-email usernames on the client side.
- `app_base.html` body tag rendered duplicate `class=` attribute (`class="antialiased"` from `base.html` + `class="cj-sidebar-mode-..."` from `body_attrs` block); browsers silently dropped the second one, so the saved sidebar mode never applied on F5. `antialiased` now lives inside the `body_attrs` default.
- Sidebar drag pointerup posted mode + width as concurrent fetches → SQLite `database is locked` race; mode/width POSTs are now awaited sequentially. Same fix applied to the dblclick reset path.
- Toggling out of `collapsed` always restored to `full`, even when the user had snapped to `mini` first; `cjSetSidebarMode` now captures the *previous* expanded mode before switching to `collapsed`, and the initial expanded mode is seeded from the server-rendered body class.
- Slide-in animation from `collapsed` looked like it came from much further right when the user had been in `mini` before, because collapsed mode dropped the mini width and snapped to the free-drag width. CSS now preserves mini width while collapsed via `[data-last-expanded-mode="mini"]`.
- `#cj-settings-pane` self-refresh `hx-on::config-request` no longer hijacks descendant form POSTs (HTMX attribute inheritance trap — `hx-on:` is an event listener that bubbles, not subject to `disableInheritance`); guarded with `event.target === this` so only the pane's own GET gets the path rewrite.
- `#cj-settings-pane` self-refresh now derives the request URL from `window.location.search` at trigger time so external `settings:changed` triggers reload the section the user navigated to, not the one active on initial page render.
- Sidebar leaf items now carry `title=` unconditionally so the native browser tooltip identifies them in mini mode (where the visible label is hidden); harmless in full mode.

## [0.3.2] - 2026-04-29
### Fixed
- Restore sub-package templates dropped from 0.3.1 wheel.

## [0.3.1] 2026-04-29
### Changed (BREAKING)
- **BREAKING**: third-party JS/CSS unbundled, fetched via `update_libraries` (~16MB→~300KB wheel).

### Added
- `forms.TimeField` + `TimePickerInput` — smart-parsing time input. → docs/usage/forms.md
- `conjunto.sortable` — declarative HTMX list reordering via Sortable.js. → docs/usage/sortable.md
- `update_libraries` management command for fetching third-party JS/CSS.
- System check `conjunto.W002` — warns about missing vendored libraries.
- Internal `conjunto._vendor.registry` for library metadata + downloads.
- `docs/usage/static_libraries.md` reference for the new vendoring flow.
- `DependentFieldsMixin` perf hooks (subtree swaps, debounce, isolated callbacks).
- `conjunto.profiles` — optional user-profile app with avatar upload.
- `{% avatar %}` template tag — image when present, initials fallback. → docs/usage/profiles.md
- `OptionalMultiTenantModelMixin` — M2M tenancy for rows shared across tenants.
- `VendorWriteProtectionMixin` — blocks non-vendor edits on vendor-owned rows.
- `conjunto.archive` — soft-delete + versioning + retention. → docs/archive/

### Removed
- `django-safedelete` dependency (replaced by `conjunto.archive`).
- `scripts/update_libraries.py` and `_vendor.registry.main_cli` — replaced by management command.

### Changed
- Rename `CrudTableMixin` → `RowActionsMixin`; add `TableListView`, `HeaderAction`, filters.
- "Work without tenant" entry in tenant dropup for superusers.
- `conjunto.wizard` — multi-step form wizard with session drafts. → docs/usage/wizard.md
- `forms.PersistentFileField` — file field that survives form re-renders.
- `forms.SafeHTMLField` — `CharField` with bleach-based HTML sanitization.
- `CONJUNTO_THEME_SWITCHER` setting — gates the topbar light/dark toggle.

### Fixed
- `update_libraries` no longer crashes on Python 3.14 (escaped `%` in argparse help).
- `TemporalMixin` tests use `timezone.localdate()` to avoid date-boundary flake.
- `ArchivableMixin._cascade_soft_delete` no longer crashes on `parent_link` O2O fields.
- Unified modal dialog target to `#dialog` (was inconsistent `#cj-dialog`).
- `IMenuItem.disabled=True` now renders with `.disabled` class instead of hiding.
- Theme toggle JS now emitted by its own include — no `block.super` requirement.
- `ProtectedFileField.pre_save` no longer crashes when `upload_to` is a callable.
- `{% conjunto_require_tinymce %}` tag — self-hosted TinyMCE v7 with CSP nonce.
- `tinymce` library entry — downloads npm tarball into `static/conjunto/tinymce/`.
- `THIRD_PARTY_LICENSES.md` with GPLv2 notice for bundled TinyMCE assets.
- Fix password visibility toggle on login; non-field errors render as Tabler alert.

## [0.2.2] - 2026-04-15
### Added
- `DependentFieldsMixin` — HTMX-wired forms with `<field>_changed()` callbacks.
- `DependentFieldsView` — generic view for HTMX fragment re-renders of dependent forms.

### Fixed
- `DependentFieldsView` uses `initial=` (unbound), preventing premature validation errors.
- `apply_dependencies()` now includes `field.initial` in value resolution chain.
- `_resolve_field_value()` checks `queryset is not None` before PK lookup.
- Instance fallback in `apply_dependencies()` now requires `instance.pk`.

## [0.2.1] - 2026-05-15
### Added
- Slim, generic `conjunto/base.html` — document shell only (head, body, modal/toast/scripts).
- New `conjunto/app_base.html` — full app layout (topbar/sidebar/canvas/statusbar).

### Changed
- **BREAKING**: `conjunto/base.html` is slim now; in-app pages must extend `app_base.html`.

### Added (previously logged for 0.1.2)
- `CONJUNTO_TENANT_MODEL` is now optional (defaults to `conjunto_tenants.Tenant`).
- Server-side dark-mode persistence via `conjunto.color_scheme` scoped setting.
- New `sidebar_toggle` block wrapping `#cj-sidebar-toggle`.
- New `registration/login.html` blocks: `login_brand`/`welcome`/`title`/`extensions`/`footer`.
- `ILoginMethod` interface for alternative sign-in methods (SSO/social/WebAuthn).
- `remember_me` checkbox in the shipped login card.
- `conjunto.session_lifetime_default`/`_remembered` scoped settings drive session lifetime.

### Changed (previously logged for 0.1.2)
- Rename scope classes: `IVendorScope`, `ITenantScope`, `IGroupScope`, `IDeviceScope`, `IUserScope`.
- Simplify tenant handling; rename admin role to `tenant_admin`.
- Replace tenant-picker page with inline statusbar dropdown.
- Bump gdaps dependency to >=0.13.0.
- `registration/login.html` blanks `top_bar` and centers brand above the login card.

### Fixed
- Fix `test_all_five_scopes_are_registered` for abstract `IScope` interface.
- Guard "I forgot password" link with `{% url 'password_reset' as ... %}` + `{% if %}`.

## [0.1.1] - 2026-04-13
### Changed
- Bump gdaps dependency to >=0.13.0.
- Simplify tenant handling; rename admin role to `tenant_admin`.
- Replace tenant-picker page with inline dropdown.
- Update README: replace Tetra with HTMX in framework description.

## [0.1.0] - 2026-04-13

**Major release: Complete removal of Tetra, migration to HTMX.**

### Added
- Complete HTMX-based layout: fixed topbar, resizable sidebar, two offcanvas panels, statusbar.
- Scoped settings system (USER>DEVICE>GROUP>TENANT>VENDOR), replacing `AbstractSettings`.
- Toast notification system based on Django messages + HTMX.
- `HtmxFormViewMixin` for in-place partial swaps (not just modals).
- `CrudTableMixin` + `RowAction` system with pluggable `IRowAction` GDAPS interface.
- Tenant system: `TenantModelMixin`, `OptionalTenantModelMixin`, picker, `TenantRequiredMixin`.
- Per-tenant role system with tenant-aware auth backend.
- Settings page UI with `ISettingsGroup`/`Section`/`Form` plugin architecture.
- Configurable toast container positioning.
- `page_subtitle` block in base template.
- Resizable sidebar with persistent width (localStorage).
- GitLab CI pipeline for automated testing and PyPI publishing.

### Changed
- **BREAKING**: removed Tetra dependency entirely; all UI is HTMX-based.
- **BREAKING**: replaced `AbstractSettings` with scoped settings.
- **BREAKING**: removed toasts component; migrated to Django messages + HTMX.
- Complete redesign of layout (topbar/sidebar/offcanvas/canvas/footer).
- Django dependency >=6.0.3.
- Rewrote modal logic and form handling for HTMX.
- Migrated all JS libraries to current versions.
- Removed `suitable_django_autocomplete` integration.

### Fixed
- Modal form override now replaces form instead of appending.
- Type-hint formatting in settings `section` attribute.

## [0.0.26] - 2026-03-15
### Added
- `LogActionResult` enum + `result` field on log actions and `ModelLogEntry`.
- `show_actions` management command.
- `register_log_actions` hook for audit logging.
- Annotations for improved code clarity.

### Changed
- Bumped Django and `gdaps` dependencies.
- Updated to Tetra 0.4 API.
- Use Tetra slots instead of blocks in components.
- Refactored `Card` component to use `_pre_load`.
- Improved tests for models and logging.

### Fixed
- SPDX license attribute in `pyproject.toml`.
- Buffer length access in `ProtectedFileSystemStorage`.
- `Toasts` component to use external JS.
- `Updatable` component now saves trigger event.

## [0.0.25] - 2025-12-19
### Added
- Test configuration and pytest setup in `conftest.py`.
- Django test app configuration.
- Template directory configuration in test settings.
- Support for GDAPS and conjunto apps in test environment.

### Changed
- Updated project configuration structure for testing.
- Test database now uses in-memory SQLite.

### Fixed
- Django setup and configuration for test suite.
- Plugin configuration handling in tests.

## [0.0.24] - 2025-08-08
### Added
- Audit log functionality.
- `Updatable` component saves trigger event.
- `show_actions` management command.
- `register_log_actions` hook.

### Changed
- Updated to Tetra 0.4 API.
- Use Tetra slots instead of blocks in components.

### Fixed
- Component template compilation issues.
- Toast component JavaScript loading.

## [0.0.23] - 2025-07-27
- ...

## [0.0.22] - 2024-04-19
- Documentation improvements.
- Drop separate `tabler` app.

## [0.0.21] - 2024-03-21
- Use `gettext_lazy` for model translations.
- Rename conjunto migration 0003 to proper name.

## [0.0.20] - 2024-03-21
### Fixed
- Add missing data files.

## [0.0.19] - 2024-03-21
- Switch build tool from flit to setuptools.
- Gitignore `.mo` files.
- Add menu check for anonymous users.

## [0.0.18] - 2024-03-13
### Added
- Token helper views.
- Variable icon font sizes in button components.

## [0.0.17] - 2024-03-08
- Update `HtmxLinkElement`.

## [0.0.16] - 2024-03-05
- Add HTMX lightbox.
- Disable modal form button while posting.
- Enable HTMX spinner.
- Rebase `HtmxSetModelAttributeView` on `SuccessEventMixin`.

## [0.0.15] - 2023-02-29
- Add `datagrid-item` component.
- Improve "static" page views.

## [0.0.14] - 2023-02-28
- Fix tabler issues (#1836).
- **BREAKING**: rename `required_permissions` to `permission_required` in `IMenuItem`.
- Improve link functionality.

## [0.0.13] - 2023-02-27
### Added
- Listitem component accepts subtitle slot in addition to attribute.
- Allow autocomplete and custom form attrs in `ModalFormView`.
- Secure password generator helper.
- Menu helpers: `is_staff`, `is_authenticated`.

### Changed
- **BREAKING**: rename HTMX mixins for clarity.
- Rename "Site Editor" permissions group to "Content Editor".

## [0.0.12] - 2023-02-23
### Added
- Protected media files download support.

## [0.0.11] - 2023-02-21
- Improve `Updatable` component.

## [0.0.10] - 2023-02-19
### Added
- More fixes for HTMX form handling and redirects.

## [0.0.9] - 2023-02-19
### Added
- Allow auto `<img>` tags in datagrids.
- Fixes for HTMX form handling and redirects.

## [0.0.8]
- Fix `LicensePage` error.

## [0.0.7]
- Fix `PRODUCTION` env variable for red background bar.

## [0.0.6]
- Mark testing sites with red header bar.
- Rename GDAPS "component" to "element" (avoid django-web-components clash).
- Massively improve element rendering.
- Add Tabler components: list, (action)buttons, etc.
- Migrate more helper classes from `medux-common`.

## [0.0.5] 2023-12-23
- Update translations.
- Move CMS functionality to `conjunto.cms` subapp.

## [0.0.4] 2023-12-23
### Fixed
- Maintenance mode.

### Changed
- Rename `maintenance_text` to `maintenance_content`.

## [0.0.3]
### Added
- Documentation at readthedocs.
- Many small bugfixes.

## [0.0.2]
### Added
- Move common classes/helpers from `medux-common` to conjunto.
- Makefile for common tasks.

## [0.0.1]
- Initial version.
