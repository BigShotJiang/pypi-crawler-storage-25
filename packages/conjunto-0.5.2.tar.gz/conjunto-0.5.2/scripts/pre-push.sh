#!/usr/bin/env bash
# Pre-push: run formatters, auto-commit any reformatting, then pytest.
#
# black and ruff are normally caught at pre-commit time, so commits are
# usually lint-clean. This is a defensive net for cases where pre-commit
# was bypassed (--no-verify) or hook versions drifted.
#
# NOTE: an auto-commit created by this script is NOT part of the current
# push -- git already determined the refs to push when the hook started.
# Run `git push` again to ship the lint commit.

set -euo pipefail
cd "$(git rev-parse --show-toplevel)"

echo "==> pre-push: running black + ruff"
pre-commit run black --all-files >/dev/null 2>&1 || true
pre-commit run ruff  --all-files >/dev/null 2>&1 || true

if ! git diff --quiet; then
    echo "==> pre-push: auto-formatter changed files; committing"
    git add -u
    git commit --no-verify -m "style: auto-format on pre-push"
    echo ""
    echo "    NOTE: this auto-commit is NOT in the current push."
    echo "    Run \`git push\` again afterwards to ship it."
    echo ""
fi

echo "==> pre-push: running pytest"
exec uv run pytest
