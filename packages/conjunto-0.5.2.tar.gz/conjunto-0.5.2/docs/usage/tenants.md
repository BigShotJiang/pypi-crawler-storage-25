# Tenants

Conjunto ships a neutral, framework-level `Tenant` model as an
abstract base plus a concrete swappable default. The pattern mirrors
Django's `AUTH_USER_MODEL`: use the default as-is, or subclass
`AbstractTenant` in your own app and point `CONJUNTO_TENANT_MODEL` at
your model **before** the first migration.

!!! info "`CONJUNTO_TENANT_MODEL` is optional"
    You only need to set `CONJUNTO_TENANT_MODEL` if you **swap** the
    tenant model. When the setting is absent, conjunto installs
    `"conjunto_tenants.Tenant"` as the default at package import time,
    so the shipped concrete `Tenant` works out of the box.

## The default

```python
from conjunto.tenants.models import Tenant

tenant = Tenant.objects.create(name="Acme Clinic", slug="acme")
```

Fields:

- `uuid` — stable external identifier (auto-generated).
- `name` — human-readable display name (shown by `__str__`).
- `slug` — URL-safe identifier. **Immutable after first save**: it is
  baked into every `tenant:<slug>:<role>` group name, and renaming it
  would orphan every user's role memberships. The field stays
  `editable=True` (so create-forms can include it), but `save()`
  raises `ValueError` if you change the slug on an existing row.
- `is_active` — soft deactivation flag.
- `created_at` / `updated_at` — audit timestamps.

The default is deliberately minimal. If you need to attach a person
(doctor, practice owner, …) or a company (address, phone, …) to the
tenant, subclass it.

## Subclassing

```python
# medux_tenants/models.py
from django.db import models
from conjunto.tenants.models import AbstractTenant


class Tenant(AbstractTenant):
    # Medical-specific fields the clinic needs:
    title      = models.CharField(max_length=50, blank=True)
    first_name = models.CharField(max_length=255)
    last_name  = models.CharField(max_length=255)
    address    = models.CharField(max_length=255)
    phone      = models.CharField(max_length=30, blank=True)
    email      = models.EmailField(unique=True, blank=True, null=True)

    class Meta(AbstractTenant.Meta):
        swappable = "CONJUNTO_TENANT_MODEL"

    def initials(self):
        return f"{self.last_name[0].upper()}{self.first_name[0].upper()}"
```

Then in `settings.py`:

```python
CONJUNTO_TENANT_MODEL = "medux_tenants.Tenant"
```

**Critical:** set this **before** the first migration that touches
the `conjunto_settings.ScopedSetting` table. Django treats swappable
model swaps mid-project as destructive — follow the same guidance as
`AUTH_USER_MODEL`.

## Resolving the active model

Framework code and consumers should never hard-import the concrete
Tenant class. Use the helper:

```python
from conjunto.tenants.utils import get_tenant_model

Tenant = get_tenant_model()
```

The helper reads `settings.CONJUNTO_TENANT_MODEL` (default
`"conjunto_tenants.Tenant"`), raises `ImproperlyConfigured` on
malformed or missing labels, and returns the model class.

## Roles and permissions

The core challenge of multi-tenant permissions is that the same user
may hold different roles in different tenants. User A might be an
**admin** in tenant Acme and only a **viewer** in tenant Globex.
Django's `auth.Group` is a global namespace, so simply adding a user
to a "Editor" group would grant that role **everywhere**. Conjunto
solves this with three cooperating pieces:

1. **Role templates** declared in each app's `AppConfig`.
2. **Per-tenant materialized groups** named `tenant:<slug>:<role>`.
3. A **tenant-aware authentication backend** that only counts a
   tenant-prefixed group when its slug matches the currently active
   tenant.

### Declaring roles

Any app can contribute roles — and permissions to roles — via its
`AppConfig.tenant_role_permissions`:

```python
# my_app/apps.py
from django.apps import AppConfig

class MyAppConfig(AppConfig):
    name = "my_app"

    tenant_role_permissions = {
        "viewer": {
            "permissions": {"my_app.Article": ["view"]},
        },
        "editor": {
            "extends": "viewer",
            "permissions": {"my_app.Article": ["add", "change"]},
        },
        "admin": {
            "extends": "editor",
            "permissions": {"my_app.Article": ["delete"]},
        },
    }
```

Rules:

- **Cross-app merging**: multiple apps may contribute permissions
  to the same role. Their `permissions` dicts are unioned per model.
- **Inheritance via `extends`**: roles inherit all permissions of
  their parent. Declare the chain once, in any app; other apps may
  omit `extends` and just pile permissions onto the role name.
- **Conflict detection**: if two apps declare different `extends`
  for the same role, `update_permissions` raises
  `RoleSchemaError` and exits non-zero. Same for cycles.
- Conjunto itself declares only an empty `admin` role as a baseline,
  so every tenant always has a `tenant:<slug>:admin` group that
  `ITenantScope.can_edit` can look up.

### Materialization

Role groups are created in two moments:

- **On `Tenant.save()`** — the first save (and every subsequent save)
  runs `materialize_roles()`, which resolves the full, flattened role
  schema across all installed apps and applies it **authoritatively**
  to this tenant's `tenant:<slug>:<role>` groups. Permissions dropped
  from the schema are revoked.
- **On `manage.py update_permissions`** — walks every existing
  tenant and re-applies the current schema. Run this after any
  deployment that changes role declarations.

### Runtime-editable roles (`TenantRole`)

While `tenant_role_permissions` declares roles in code, tenant admins
may also need to create custom roles at runtime. The `TenantRole`
model bridges both worlds:

```python
from conjunto.tenants.models import TenantRole

# System roles are seeded automatically from AppConfig declarations.
# Custom roles are created by tenant admins:
TenantRole.objects.create(
    tenant=acme,
    name="receptionist",
    label="Receptionist",
    description="Front-desk staff with limited access.",
)
# Then assign specific permissions via the M2M:
role = TenantRole.objects.get(tenant=acme, name="receptionist")
role.permissions.add(view_patient_perm, view_schedule_perm)
role.save()  # materializes the tenant:acme:receptionist group
```

Fields:

- `tenant` — FK to the tenant this role belongs to.
- `name` — machine-readable slug (e.g. `"admin"`, `"receptionist"`).
  Unique per tenant.
- `label` — human-readable display name.
- `description` — optional longer description.
- `is_system` — `True` for roles seeded from `tenant_role_permissions`.
  System roles cannot be deleted through the UI; their base
  permissions (from AppConfig) are always included and cannot be
  revoked. Admins can add *extra* permissions on top.
- `permissions` — M2M to `auth.Permission`. For system roles, these
  are extras on top of the AppConfig schema. For custom roles, this
  is the complete permission set.

**Seeding**: system roles are created/updated automatically:

- On every `Tenant.save()` (after `materialize_roles()`).
- On `manage.py update_permissions`.

Use `seed_system_roles(tenant)` to trigger seeding programmatically:

```python
from conjunto.tenants.roles import seed_system_roles
seed_system_roles(acme)
```

Use `available_roles_for_tenant(tenant)` to get all roles (system +
custom) for a tenant:

```python
from conjunto.tenants.roles import available_roles_for_tenant
roles = available_roles_for_tenant(acme)
```

### Assigning users to roles

Use `TenantMembership`:

```python
from conjunto.tenants.models import TenantMembership

TenantMembership.objects.create(user=alice, tenant=acme, role="editor")
```

The `save()` of the membership adds the user to the corresponding
`tenant:acme:editor` group; its `delete()` removes them. The uniqueness
constraint is `(user, tenant, role)`: the same user can hold many
roles in many tenants, but each combination exists at most once.

### Permission checks

Add the tenant-aware backend to `settings.py`:

```python
AUTHENTICATION_BACKENDS = [
    "conjunto.tenants.backends.TenantAwareModelBackend",
]
```

And make sure `conjunto.middleware.ConjuntoMiddleware` is installed —
it pushes the active tenant onto a `ContextVar` on every request.
Normal `user.has_perm("my_app.change_article")` then only considers
groups relevant to the current tenant, plus any global groups whose
name does **not** start with `tenant:`. Global groups are the escape
hatch for vendor/support roles that must span all tenants.

### Out-of-request use

Celery tasks, management commands, and shell sessions do **not**
have a middleware-set tenant. Bind one explicitly:

```python
from conjunto.tenants.context import override_tenant

with override_tenant(acme):
    user.has_perm("my_app.change_article")  # evaluated against Acme
```

Without a bound tenant, the backend only counts non-tenant groups.

## How the tenant scope resolves on a request

Conjunto's middleware resolves `request.tenant` using the same chain
the `ITenantScope` setting resolver uses, so you rarely need to write
your own middleware unless you have a custom source (subdomain /
hostname routing):

1. **`request.tenant`** — if a consumer middleware has already set it,
   conjunto honors that and only pushes it onto the tenant ContextVar.
2. **`request.user.tenant_id`** — if the user model carries a `tenant`
   FK, the middleware looks up the `Tenant` row and sets
   `request.tenant`.
3. **`request.session["cj_tenant_id"]`** — for apps where the user
   picks a tenant at login and the choice is stored in the session.

The resolved tenant is published on both `request.tenant` and the
`conjunto.tenants.context` ContextVar, so template code, scoped
settings, and the auth backend all see the same value.

## Natural keys

`AbstractTenant.natural_key()` returns `(slug,)`, suitable for
`dumpdata --natural-foreign` / `loaddata` workflows. A slug-unique
constraint is enforced via `SlugField(unique=True)`.

w## Tenant-scoped domain models

`conjunto.tenants.models` ships two mixins for marking one of your own
models as tenant-owned. Both auto-wire a manager that filters every
queryset by the tenant currently bound on
`conjunto.tenants.context` — the same ContextVar
`ConjuntoMiddleware` populates from `request.tenant` on every
request.

| Mixin                       | `tenant` FK | `objects` (bound) | `objects` (unbound)           | `create()` auto-injects |
|-----------------------------|-------------|-------------------|-------------------------------|-------------------------|
| `TenantModelMixin`          | NOT NULL    | `tenant=current`  | **raises `TenantScopeMissing`** | **yes**                 |
| `OptionalTenantModelMixin`  | nullable    | `tenant=current` + `tenant IS NULL` | `tenant IS NULL` only | no                      |

Example:

```python
from conjunto.tenants.models import TenantModelMixin, OptionalTenantModelMixin
from django.db import models


class Invoice(TenantModelMixin):
    number = models.CharField(max_length=32, unique=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)


class VatRate(OptionalTenantModelMixin):
    country = models.CharField(max_length=2)
    rate    = models.DecimalField(max_digits=5, decimal_places=2)
```

Both mixins expose two managers:

- **`objects`** — the scoped manager. Filters by the bound tenant on
  every queryset and (for `TenantModelMixin`) auto-populates
  `tenant` on `create()` / `bulk_create()`.
- **`all_objects`** — a plain, unscoped `Manager`. Also wired as
  `Meta.base_manager_name`, so Django's own internals (FK validation,
  cascade deletes, admin autocomplete, reverse-relation access) are
  **never** tenant-filtered.

### Fail loud, not silent

`TenantModelMixin.objects` raises `TenantScopeMissing` when accessed
with no tenant bound. This is deliberate: Celery tasks, management
commands and shell sessions that forget to bind a tenant would
otherwise silently return empty querysets. The fail-loud contract
gives you a stacktrace pointing at the exact call site instead.

`OptionalTenantModelMixin.objects` is more permissive — with no
tenant bound it degrades to "global rows only" (`tenant IS NULL`).
That matches "optional tenant" semantics: a tenant-less caller is
a legitimate state, not a bug.

### Idioms

```python
from conjunto.tenants.context import override_tenant

# Inside a view: middleware has already bound request.tenant.
# Just use the manager — no explicit tenant= needed.
invoices = Invoice.objects.filter(amount__gt=100)
Invoice.objects.create(number="INV-042", amount=Decimal("99.90"))

# Creating a global VAT rate visible to every tenant:
VatRate.all_objects.create(country="DE", rate="19", tenant=None)

# Celery task / management command: bind a tenant explicitly.
with override_tenant(acme):
    Invoice.objects.bulk_create([Invoice(...) for _ in batch])

# Cross-tenant report / backup: step outside the scope deliberately.
for inv in Invoice.all_objects.all():
    export(inv)
```

If you hit `TenantScopeMissing`, the call site is running outside a
request without an `override_tenant(...)` block. Either wrap the
caller or use `all_objects` — **don't** silently catch the exception.

### Write-protecting vendor-owned rows

`OptionalTenantModelMixin` intentionally lets every tenant **see**
vendor rows (`tenant IS NULL`) — typically entries shipped via a
vendor data pack (list of insurance carriers, hospitals, device
types). The manager does **not** enforce write protection, though:
without an extra guard, tenant A could `POST` against the edit view
for a vendor row and mutate data seen by tenant B.

Use `conjunto.tenants.mixins.VendorWriteProtectionMixin` on any
`UpdateView` / `DeleteView` whose model is vendor-aware:

```python
from conjunto.tenants.mixins import (
    TenantRequiredMixin, VendorWriteProtectionMixin,
)
from django.views.generic import UpdateView, DeleteView

class DeviceTypeUpdateView(
    TenantRequiredMixin,
    VendorWriteProtectionMixin,
    UpdateView,
):
    model = DeviceType
    form_class = DeviceTypeForm

class DeviceTypeDeleteView(
    TenantRequiredMixin,
    VendorWriteProtectionMixin,
    DeleteView,
):
    model = DeviceType
```

Behaviour:

- **Tenant row** (`obj.tenant is not None`) — the mixin is a no-op.
  Tenant scoping is still the caller's responsibility (it already is,
  via the model manager + `TenantRequiredMixin`).
- **Vendor row** (`obj.tenant is None`) — the mixin delegates to
  `IVendorScope.can_edit(request, None)`. That check is gated on the
  `conjunto_settings.manage_vendor_settings` Django permission, which
  regular tenant users — including tenant admins — do not hold. Denied
  requests raise `PermissionDenied` → Django renders a 403.

The mixin uses a **duck-typed property** `obj.is_vendor_owned`, not
`obj.tenant`, to classify a row. `OptionalTenantModelMixin` defines
the property as `self.tenant_id is None`; a future
`OptionalMultiTenantModelMixin` (M2M `tenants`) can override it as
`not self.tenants.exists()`, and the view mixin keeps working without
changes.

If a model does not expose `is_vendor_owned`, the mixin raises
`ImproperlyConfigured` with a pointing error message — there is no
silent bypass.

To change the "who may edit vendor rows?" policy on a per-view basis,
override `is_write_allowed(self, obj) -> bool`. The default returns
`IVendorScope.can_edit(self.request, None)`.

## The tenant picker

Users who legitimately have `user.tenant = None` (most commonly
superadmins) choose which tenant they want to work in for the
current session via the built-in tenant picker. The choice is
stored in `request.session["cj_tenant_id"]`, which
`ConjuntoMiddleware` already reads as its last fallback when
resolving the active tenant on every subsequent request.

### Do not create a synthetic "admin tenant"

It is tempting to paper over "admin without a tenant" by creating a
ghost `Tenant` row and assigning the admin to it. **Don't.** Ghost
tenants pollute every tenant-scoped table with rows that don't
belong to a real business entity, and they force the admin into a
single tenant's view when they usually need to work across all of
them. The idiomatic path is:

- `user.tenant = None` is a **supported state** for superadmins.
- The admin picks a working tenant from the picker (session-based).
- Views that genuinely need to cross tenant boundaries use
  `Model.all_objects` explicitly.

### `TenantPickView`

`conjunto.tenants.views.TenantPickView` is auto-mounted at
`/tenants/pick/` by `PluginManager.urlpatterns()` (URL name
`tenants:pick`):

- **`GET`** renders a Tabler-styled radio list of the tenants the
  user is allowed on. Superusers see every active tenant; everyone
  else is filtered to their `TenantMembership` entries. The
  `?next=` query parameter is forwarded into a hidden form field.
- **`POST`** validates the submitted `tenant` pk against the same
  allowed set, stores it in `request.session["cj_tenant_id"]` and
  redirects to `?next=` (filtered through
  `url_has_allowed_host_and_scheme` — no open-redirect risk).
- **`POST` with `tenant=""` (superusers only)** clears the active
  tenant: the session key is set to ``None``, which the middleware
  treats as a sticky "work without tenant" signal (the
  `TenantMembership` fallback is skipped as long as the key stays
  ``None``). Non-superusers get a rejection message. Exposed in the
  statusbar dropup as a "Work without tenant" entry.

The list of allowed tenants is produced by
`conjunto.tenants.utils.get_allowed_tenants(request)`, which
caches its queryset on the request object. The view and the
statusbar badge (below) share the same helper so there is at most
one extra query per request.

### `TenantRequiredMixin`

Tenant-scoped class-based views should inherit from
`conjunto.tenants.mixins.TenantRequiredMixin`. If `request.tenant`
is `None` at dispatch time, the user is redirected to
`tenants:pick?next=<current URL>`:

```python
from conjunto.tenants.mixins import TenantRequiredMixin
from django.views.generic import ListView

class InvoiceList(TenantRequiredMixin, ListView):
    model = Invoice
    # No explicit tenant filtering needed — Invoice.objects
    # already filters by the bound tenant.
```

Override `tenant_picker_url_name` to point at a project-specific
picker, or `tenant_picker_next_param` to use a different query
parameter name.

### Statusbar badge

`conjunto/base.html`'s statusbar includes a `{% tenant_badge %}`
template tag (from `conjunto.tenants.templatetags.tenant_tags`)
that renders a small Tabler chip with the current tenant's name.
The badge is rendered **only when the user has something to do
with it**:

- **2+ tenants accessible** (regular user with multiple memberships
  or superuser with multiple tenants in the DB): dropup listing the
  tenants, current one marked with a check.
- **No tenant bound + at least one tenant accessible**: dropup
  labelled "No tenant" listing pickable tenants.
- **Superuser with a tenant bound**: dropup that always includes
  a "Work without tenant" entry (`ti ti-building-off`) so the
  superuser can clear the active tenant — even when only one tenant
  exists in the database.

A regular user with **exactly one** accessible tenant gets no badge
at all. The tenant is implied by the user's identity, and a
non-actionable chip would just be visual noise. The inclusion-tag
context exposes `should_show` so consumers wrapping the tag can use
the same flag.

The badge uses the same cached `get_allowed_tenants(request)`
helper, so it adds at most one `COUNT(*)` query per page render.

To use the tag directly in your own templates:

```django
{% load tenant_tags %}
{% tenant_badge %}
```

### Two-step login (optional)

`conjunto.auth.ConjuntoLoginView` defers the call to
`django.contrib.auth.login()` when the authenticated user has
**two or more** accessible tenants:

1. The credentials are POSTed via HTMX to `/accounts/login/`.
2. The form validates the password but does **not** log the user
   in. Instead it stashes the user identity (pk, auth backend,
   remember-me, `next` URL, timestamp) into the session under
   `cj_pending_login` and returns the
   `registration/_login_tenant_pick.html` partial — which replaces
   the credentials card via `hx-target="#cj-login-card"
   hx-swap="outerHTML"`.
3. The user picks a tenant. The pick POSTs to
   `/accounts/login-complete/`, which calls `login()`, stamps the
   chosen tenant id into the session under `cj_tenant_id`, applies
   the configured `auth.session_lifetime_*` setting, and
   redirects to the original `next` URL.

Users with zero or one accessible tenants get the classic
single-POST flow (and one-tenant users get their tenant
auto-bound).

Wire the URL module in the consumer's root URL conf:

```python
from django.urls import include, path

urlpatterns = [
    path("accounts/", include("conjunto.auth.urls")),
    path("accounts/", include("django.contrib.auth.urls")),  # logout, password reset
    ...
]
```

Pending login state expires after 10 minutes
(`conjunto.auth.views.PENDING_LOGIN_TTL`); after that the user has
to start over.

## Tenant administration UI

Conjunto ships a complete set of views for managing users, roles, and
role assignments within a tenant. These views are designed to be
mounted by consuming apps into their own administration URL tree.

### Views overview

| Area | Views | Purpose |
|------|-------|---------|
| **Roles** | `TenantRoleListView`, `TenantRoleCreateView`, `TenantRoleUpdateView`, `TenantRoleDeleteView` | CRUD for `TenantRole` — list, create custom roles, edit permissions, delete (system roles protected) |
| **Users** | `TenantUserListView`, `TenantUserCreateView`, `TenantUserUpdateView`, `TenantUserRemoveView` | CRUD for users within a tenant — list members, create users, edit details, remove from tenant |
| **User-role assignment** | `UserRoleListView`, `ManageUserRolesView` | Assign/revoke roles on a per-user basis via a checkbox modal |

All views inherit from `LoginRequiredMixin` and `TenantRequiredMixin`.
Consuming apps should add their own admin-permission mixin (e.g.
`TenantAdminRequiredMixin`) by subclassing the views.

### Mounting the URL patterns

Conjunto provides a ready-made URL module at
`conjunto.tenants.admin_urls`:

```python
from django.urls import path, include
from conjunto.tenants.admin_urls import urlpatterns as tenant_admin_urls

urlpatterns = [
    path("administration/tenant/", include(tenant_admin_urls)),
]
```

The URL names are:

| Name | URL | View |
|------|-----|------|
| `role-list` | `roles/` | `TenantRoleListView` |
| `role-add` | `roles/add/` | `TenantRoleCreateView` |
| `role-edit` | `roles/<pk>/edit/` | `TenantRoleUpdateView` |
| `role-delete` | `roles/<pk>/delete/` | `TenantRoleDeleteView` |
| `user-list` | `users/` | `TenantUserListView` |
| `user-add` | `users/add/` | `TenantUserCreateView` |
| `user-edit` | `users/<pk>/edit/` | `TenantUserUpdateView` |
| `user-remove` | `users/<pk>/remove/` | `TenantUserRemoveView` |
| `user-role-list` | `user-roles/` | `UserRoleListView` |
| `user-role-manage` | `user-roles/<pk>/manage/` | `ManageUserRolesView` |

### Customizing the base template

The list views use `base_template = "conjunto/base.html"` by default.
To integrate with your project's admin layout, subclass the views
and set `base_template`:

```python
from conjunto.tenants.views.roles import TenantRoleListView as _RoleList

class TenantRoleListView(MyAdminMixin, _RoleList):
    base_template = "myapp/administration.html"
```

### Namespace resolution in templates

The templates use a `urls` context dict (provided by the views) to
build fully-qualified URL names that work regardless of the namespace
under which the patterns are mounted. For example, when mounted under
`adm:tenant:`, the template receives
`urls.role_add = "adm:tenant:role-add"` and uses it as
`{% url urls.role_add %}`.

### Forms

The forms live in `conjunto.tenants.forms`:

- **`TenantRoleForm`** — ModelForm for `TenantRole` with a
  `GroupedPermissionWidget` that renders permissions grouped by
  app > model > verb. For system roles, AppConfig-declared
  permissions are shown as disabled checkboxes (locked).
- **`TenantUserCreateForm`** — extends Django's `UserCreationForm`
  with an optional `roles` field for initial role assignment.
- **`TenantUserEditForm`** — edits `first_name`, `last_name`,
  `email`, `is_active`.
- **`UserRolesForm`** — multi-checkbox form sourced from `TenantRole`
  records. Syncs `TenantMembership` rows on save.

### HTMX events

The views emit HTMX events on success so tables auto-refresh:

| Event | Emitted by |
|-------|-----------|
| `tenant_roles:changed` | Role create/edit/delete |
| `tenant_users:changed` | User create/edit/remove |
| `user_roles:changed` | Role assignment changes |

## Tenant lifecycle (`ITenantLifecycle`)

A GDAPS interface that lets plugins contribute idempotent **per-tenant
initialization** — seed master data, default accounts, plugin-specific
preferences — that must run whenever a tenant is created.

This is the conjunto-side counterpart to GDAPS' `PluginMeta` hooks:

| Hook | When it runs | Scope |
|---|---|---|
| `PluginMeta.install()` | First `syncplugins` per plugin | Vendor-wide one-shot |
| `PluginMeta.initialize()` | Every Django start | Quick health checks |
| `ITenantLifecycle.setup_tenant(tenant)` | Every new tenant | Per-tenant master data |

### The interface

`ITenantLifecycle` lives in `conjunto.tenants.interfaces`. Subclass it
in your plugin and implement `setup_tenant`:

```python
# medux/plugins/cashbook/lifecycle.py
from conjunto.tenants.interfaces import ITenantLifecycle
from django.utils.translation import gettext_lazy as _

from .models import Balance


class CashbookTenantLifecycle(ITenantLifecycle):
    """Seed a default cash drawer for every new tenant."""

    @classmethod
    def setup_tenant(cls, tenant) -> None:
        Balance.objects.get_or_create(
            tenant=tenant,
            is_cash=True,
            defaults={
                "name": _("Cash drawer"),
                "currency": "EUR",
                "is_active": True,
            },
        )
```

Import the module at startup so GDAPS sees the registration:

```python
# apps.py
class CashbookConfig(MeduxPluginAppConfig):
    name = "medux.plugins.cashbook"

    def ready(self):
        from . import lifecycle  # noqa: F401
```

Cross-link: see `medux-cashbook` for the canonical implementation.

### Idempotency

Every implementer MUST be idempotent. Use `get_or_create` /
`update_or_create`, never `create`. The signal handler runs once per
tenant `post_save` (creation only); the management command may re-run
the same hook against existing tenants for back-fill.

### How it is invoked

Conjunto wires a `post_save` receiver on the swappable tenant model
that fans out to every `ITenantLifecycle` implementer when
`created=True`. The receiver is **defensive**: a plugin that raises
in `setup_tenant` is caught, logged via `logger.exception`, and
skipped — every other implementer continues, and the tenant is
persisted regardless.

### Back-filling existing tenants

```bash
python manage.py setup_tenant 1 2 3   # specific ids
python manage.py setup_tenant --all   # every tenant
```

Console output is per tenant + per implementer (`OK`/`FAIL`). Exit
code is `0` on full success and `1` (raised as `CommandError`) when
any implementer raised — but the run still attempts every other
implementer/tenant.

### Forward-compatibility

`ITenantLifecycle` is intentionally **never subclassed**. Future
hooks (e.g. `teardown_tenant`) are added to the interface itself with
a no-op default so existing implementers keep working without any
change.


## User-Tenant guarantee

A project that wires conjunto's `TenantUserFKMixin` into its `User`
model gets a **DB-schema-level** guarantee that every authenticated
user has a home tenant. The active tenant for a request remains
`request.tenant` (set by `TenantMiddleware`); the FK names the home
tenant the user was created in.

### Adopting the mixin

In your project's user model:

```python
from django.contrib.auth.models import AbstractUser, UserManager

from conjunto.tenants.users import TenantUserFKMixin
from conjunto.tenants.managers import TenantAwareUserManagerMixin


class CommonUserManager(TenantAwareUserManagerMixin, UserManager):
    pass


class CommonUser(AbstractUser, TenantUserFKMixin):
    objects = CommonUserManager()
```

The mixin adds a NOT NULL `tenant` FK (`on_delete=PROTECT`,
`related_name="primary_users"`) and a `tenants` property that returns
the user's active `TenantMembership` tenants as a queryset. The
manager mixin defaults the FK to the seed tenant in `create_user` /
`create_superuser` so `manage.py createsuperuser` works against the
NOT NULL constraint.

### Bootstrap hooks

Two signal handlers in `conjunto.tenants.signals` fire automatically
when a project adopts the mixin:

* **`post_migrate`** — seeds an `Admin` tenant (`slug="admin"`) on
  first migrate so `createsuperuser` always has a target. Idempotent
  (no-op when any tenant exists).
* **`post_save User`** — auto-creates a home `TenantMembership(role=…)`
  for every newly-created user. The role comes from
  `settings.CONJUNTO_DEFAULT_USER_ROLE` (default `"user"`).

Together: `manage.py migrate` + `manage.py createsuperuser` + nothing
else is enough to bootstrap a fresh deployment to a usable state.

### Querying

```python
user.tenant                            # FK → home tenant (always set)
user.tenants                           # queryset of active membership tenants
User.objects.filter(tenant=t)          # users whose home tenant is t
User.objects.filter(tenant_memberships__tenant=t)  # users with any membership in t
```

### `TenantFormMixin`

Forms in tenant-scoped apps should inherit `TenantFormMixin` from
`conjunto.forms.tenant`. The mixin makes `tenant` a required `__init__`
kwarg (missing it raises `TypeError`, no silent cross-tenant leak)
and provides a `hide_field_if_single(field, queryset)` helper that
turns single-choice ModelChoiceFields into a HiddenInput pre-set to
the only option:

```python
from conjunto.forms.tenant import TenantFormMixin


class EntryForm(TenantFormMixin, forms.ModelForm):
    class Meta:
        model = Entry
        fields = ["balance", "amount", "comment"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)  # tenant captured by mixin

        single = self.hide_field_if_single(
            "balance",
            Balance.objects.filter(is_active=True),
        )
        # branch the layout on `single` if the visible field set
        # changes when the picker is hidden
```

View callers pass `tenant=request.tenant` as before.
