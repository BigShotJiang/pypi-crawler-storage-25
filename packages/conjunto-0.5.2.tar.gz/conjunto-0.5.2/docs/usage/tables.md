# Tables and List Views

Conjunto ships a reusable layer on top of
[`django-tables2`](https://django-tables2.readthedocs.io/) that gives
you a consistent, recognizable set of CRUD action buttons on every
list table in your project, plus a full-fledged list-view pattern
with live search, filters, and header actions.

Two cooperating pieces:

- **`RowActionsMixin`** (in `conjunto.tables`) — adds an `actions`
  column with edit/delete/… buttons to any `django-tables2` table.
- **`TableListView`** (in `conjunto.views`) — a Class-Based View that
  combines `SingleTableMixin` with search, filters, and header
  actions under a consistent Tabler-styled card layout
  (`conjunto/tables/list_card.html`).

Use `RowActionsMixin` whenever you need the actions column.
Use `TableListView` whenever you build a proper list page with a card,
search bar, filters, and `+Add` button.

## Quick start

The minimum setup — a `TableListView` that lists `Project` records
with live search, an `is_archived` filter, and a `+Add` header action:

```python
# projects/tables.py
import django_tables2 as tables
from conjunto.tables import RowActionsMixin
from .models import Project


class ProjectTable(RowActionsMixin, tables.Table):
    row_actions_namespace = "projects:project"

    class Meta:
        model = Project
        fields = ("name", "owner", "created_at")
```

```python
# projects/views.py
from django.utils.translation import gettext_lazy as _
from conjunto.views import TableListView
from conjunto.filters import BooleanFilter
from conjunto.tables import standard_add_action
from .models import Project
from .tables import ProjectTable


class ProjectListView(TableListView):
    model = Project
    table_class = ProjectTable
    template_name = "projects/project_list.html"
    search_fields = ("name", "owner__username")
    filters = [BooleanFilter("is_archived", label=_("Archived"))]
    header_actions = [standard_add_action("projects:project")]
```

```django
{# projects/templates/projects/project_list.html #}
{% extends "conjunto/base.html" %}
{% block content %}
  {% include "conjunto/tables/list_card.html" %}
{% endblock %}
```

And the URL conf:

```python
urlpatterns = [
    path("projects/", ProjectListView.as_view(), name="project_list"),
    path("projects/add/", ProjectCreateView.as_view(), name="project_create"),
    path("projects/<int:pk>/edit/", ProjectUpdateView.as_view(),
         name="project_update"),
    path("projects/<int:pk>/delete/", ProjectDeleteView.as_view(),
         name="project_delete"),
]
```

That is the whole setup. You get:

- a Tabler list card with a search box, a filter dropdown, and a
  `+Add` button in the header;
- a table rendered by `django-tables2` with an `actions` column
  (edit, delete);
- live HTMX search (`keyup changed delay:300ms`) and filter changes;
- URL reflects search + filter state (`?q=…&is_archived=1`);
- auto-refresh of the table after any `project:created` /
  `project:changed` / `project:deleted` event.

## `RowActionsMixin`

The mixin that lets any `django-tables2` table grow CRUD row buttons.

```python
from conjunto.tables import RowActionsMixin

class ProjectTable(RowActionsMixin, tables.Table):
    row_actions_namespace = "projects:project"
    row_actions = ("edit", "delete")          # default
    edit_permission = "projects.change_project"  # optional
    delete_permission = "projects.delete_project"  # optional
    delete_confirm_style = "modal"            # "modal" (default) or "inline"
    delete_success_strategy = "wrapper-refresh"  # default; or "row-remove"
    row_id_template = "row-{ns}-{pk}"         # used by row-remove
    dialog_target = "#dialog"                 # default modal target
    listen_events = None                      # override auto-detected event list
```

| Attribute | Meaning |
|---|---|
| `row_actions_namespace` | URL-name prefix. Views `<ns>_update`, `<ns>_delete`, … are reversed via this. **Required.** |
| `row_actions` | Which built-in actions to render (`"edit"`, `"delete"`). |
| `edit_permission` / `delete_permission` | Permission strings gating the respective button. |
| `delete_confirm_style` | `"modal"` (HTMX-loads into `#dialog`) or `"inline"` (browser-native `confirm()`). |
| `delete_success_strategy` | `"wrapper-refresh"` (default; the wrapper listens for `<ns>:deleted` and re-fetches the table) or `"row-remove"` (HTMX swaps the row's `<tr>` out of the DOM directly, no full re-fetch). |
| `row_id_template` | Template for the `<tr>` DOM id when `row-remove` is active. Default `"row-{ns}-{pk}"` where `{ns}` is the slugified namespace and `{pk}` the record pk. |
| `dialog_target` | CSS-selector for the HTMX target when the button opens a modal. |
| `listen_events` | Override the list of events that trigger table auto-refresh (defaults to `"<ns>:created, <ns>:changed, <ns>:deleted"`). |

The mixin adds an `actions` column at the end of the sequence and
exposes two template helpers:

- `table.wrapper_id` — stable DOM id, e.g. `table-projects-project`.
- `table.hx_trigger` — comma-joined `"<event> from:body"` trigger
  list.

## The `RowAction` dataclass

Every button is a `RowAction`:

```python
from conjunto.tables import RowAction

RowAction(
    name="publish",
    label=_("Publish"),
    icon="send",
    url=lambda record: reverse("projects:project_publish", kwargs={"pk": record.pk}),
    method="post",
    htmx=True,
    target="#dialog",
    swap="innerHTML",
    confirm=_("Really publish this project?"),
    confirm_style="inline",           # or "modal"
    variant="btn-ghost-secondary",    # Tabler btn variant
    permission="projects.publish_project",
    visible=lambda rec, req: not rec.is_archived,
    weight=50,
)
```

- **`url`** — string or callable `(record) -> str`.
- **`htmx=True`** (default) renders `hx-<method>` / `hx-target` /
  `hx-swap`. `htmx=False` renders a plain `<a href>`.
- **`permission`** — string (`"app.codename"`) or callable
  `(record, request) -> bool`. Both `permission` and `visible` must
  pass for the button to render.
- **`weight`** — sort key within one row (low first). Standard
  edit=10, delete=20.

## Confirm flows

Delete defaults to **modal confirm**: the button issues `hx-get`
against the delete view, loads the result into `#dialog`, and the
actual delete happens when the user submits the confirmation form.

For a browser-native prompt instead:

```python
class ProjectTable(RowActionsMixin, tables.Table):
    row_actions_namespace = "projects:project"
    delete_confirm_style = "inline"
```

The modal target defaults to `#dialog`. Override per table via
`dialog_target`, or per action via `RowAction.target`.

## Delete success strategies

Two ways to update the UI after a successful delete; pick whichever
matches the page:

### `"wrapper-refresh"` (default)

The wrapper element listens for the `<ns>:deleted` event on `body`
and re-fetches the whole table. Robust for paginated lists with
counters, aggregates, or server-side sort — those values stay
consistent. Pair with the `TableListView`/`list_card.html` stack;
the wrapper's `hx-trigger` is wired automatically.

### `"row-remove"` — HTMX-idiomatic row deletion

The server returns 200 with an empty body and the headers
`HX-Retarget: #row-<ns>-<pk>`, `HX-Reswap: outerHTML swap:0.3s`.
HTMX swaps the empty body into the row's `<tr>`, removing it with
a fade animation. No full table re-render, no flicker, no
roundtrip for unchanged rows.

```python
class AttendanceTable(RowActionsMixin, tables.Table):
    row_actions_namespace = "meetings:attendance"
    row_actions = ("delete",)
    delete_success_strategy = "row-remove"
    delete_confirm_style = "modal"   # or "inline"
```

The mixin auto-injects `id="row-meetings-attendance-<pk>"` into
each `<tr>`. Override `row_id_template` (e.g. `"row-att-{pk}"`)
or pass an explicit `Meta.row_attrs = {"id": lambda record: ...}`
to override the default — the mixin will not clobber an explicit
id. Note that django-tables2 requires the lambda parameter to be
named `record` (or the lambda must accept `**kwargs`); other names
are silently skipped.

Server side, set `success_strategy = "row-remove"` and
`row_id_namespace` on the matching `HtmxDeleteView` /
`ModalDeleteView` so the response carries the right
`HX-Retarget` value:

```python
from conjunto.htmx.views import ModalDeleteView

class AttendanceDeleteView(ModalDeleteView):
    model = Attendance
    success_strategy = "row-remove"
    row_id_namespace = "meetings:attendance"   # matches the table
```

Both `confirm_style` modes work with `row-remove`:

- **inline + row-remove**: Click → browser confirm → POST →
  empty body swapped into the row → fades out. Lightest-weight
  variant, no modal involved.
- **modal + row-remove**: Click → modal confirms → form POST →
  server emits `HX-Retarget`/`HX-Reswap` + a `closeModal`
  trigger; HTMX swaps the empty body into the row, the modal
  closes. The `closeModal` listener is shipped in
  `conjunto.js`.

The view also fires the regular `<ns>:deleted` `HX-Trigger`
event for any sub-component (counters, aggregate headers) that
wants to refresh on the side — so `row-remove` is additive, not
either-or.

## Custom actions

Override `get_row_actions` to inject per-row logic without touching
the standard actions:

```python
from conjunto.tables import RowActionsMixin, RowAction

class ProjectTable(RowActionsMixin, tables.Table):
    row_actions_namespace = "projects:project"

    def get_row_actions(self, record, request):
        actions = super().get_row_actions(record, request)
        if record.is_draft:
            actions.append(RowAction(
                name="publish",
                label=_("Publish"),
                icon="send",
                url=lambda r: reverse("projects:project_publish", kwargs={"pk": r.pk}),
                method="post",
                weight=15,
            ))
        return sorted(actions, key=lambda a: a.weight)
```

Opt out of a standard action by restricting `row_actions`:

```python
class ProjectTable(RowActionsMixin, tables.Table):
    row_actions_namespace = "projects:project"
    row_actions = ("edit",)   # no delete button
```

Or disable them entirely (`row_actions = ()`) and build everything
yourself.

## Plugin actions via `IRowAction`

Extra row buttons from other apps (classic GDAPS extensibility):

```python
# other_app/row_actions.py
from conjunto.tables import IRowAction, RowAction

class ArchiveProjectAction(IRowAction):
    menu = "projects.row_actions"
    weight = 30

    def to_row_action(self, request, record):
        if record.is_archived:
            return None
        return RowAction(
            name="archive",
            label="Archive",
            icon="archive",
            url=reverse("other_app:archive_project", kwargs={"pk": record.pk}),
            method="post",
        )
```

Opt the table in:

```python
class ProjectTable(RowActionsMixin, tables.Table):
    row_actions_namespace = "projects:project"
    extra_actions_menu = "projects.row_actions"
```

## Header actions

`TableListView` can display a row of buttons in the card header
(`+Add`, `Export`, `Import`, …). They are declared as
`HeaderAction` dataclasses:

```python
from conjunto.tables import HeaderAction, standard_add_action

class ProjectListView(TableListView):
    ...
    header_actions = [
        standard_add_action("projects:project"),
        HeaderAction(
            name="export",
            label=_("Export CSV"),
            icon="download",
            url="/projects/export.csv",
            htmx=False,
            variant="btn-ghost-secondary",
            permission="projects.view_project",
            weight=50,
        ),
    ]
```

`standard_add_action(url_namespace)` is the shortcut for the common
`+Add` button — it reverses `<namespace>_create` at render time.

Each `HeaderAction` supports the same `permission` / `visible` hooks
as `RowAction`, plus `weight` for ordering.

### Pluggable header actions (`IHeaderAction`)

The GDAPS interface `IHeaderAction` lets other apps contribute
buttons:

```python
# other_app/header_actions.py
from conjunto.tables import IHeaderAction, HeaderAction

class ImportProjectsAction(IHeaderAction):
    menu = "projects.list.header"
    weight = 20

    def to_header_action(self, request):
        if not request.user.has_perm("projects.add_project"):
            return None
        return HeaderAction(
            name="import",
            label="Import",
            icon="upload",
            url="/projects/import/",
            variant="btn-ghost-secondary",
        )
```

Opt the view in:

```python
class ProjectListView(TableListView):
    ...
    header_actions_menu = "projects.list.header"
```

All `IHeaderAction` plugins whose `menu` matches are collected, each
`to_header_action(request)` is called, and `None` results are
skipped. Results are merged with the static `header_actions`, filtered
by `is_allowed`, and sorted by `weight`.

## Search & filters

`TableListView` adds two declarative knobs:

- **`search_fields`** — iterable of model field paths to OR-search
  (icontains) against the `?q=` GET parameter.
- **`filters`** — list of
  [`conjunto.filters.Filter`](filters.md) instances, each bound to a
  `?<name>=` GET parameter.

```python
from conjunto.filters import ChoiceFilter, BooleanFilter

class ProjectListView(TableListView):
    ...
    search_fields = ("name", "owner__username")
    filters = [
        ChoiceFilter("status", label=_("Status"),
                     choices=Project.STATUS_CHOICES),
        BooleanFilter("is_archived", label=_("Archived")),
    ]
```

For complex filtering (ranges, date pickers, multi-select), set
`filterset_class` on the view — `TableListView` hands the queryset
off to `django-filter` and ignores `filters`.

See [the Filters documentation](filters.md) for the full Filter API.

## Auto-refresh on success events

`RowActionsMixin` exposes two template helpers that make the whole
list card refresh automatically when an HTMX form view fires a
success event:

- `table.wrapper_id` — stable DOM id, e.g.
  `table-projects-project`.
- `table.hx_trigger` — comma-joined `"<event> from:body"` trigger
  list.

`conjunto/tables/list_card.html` wires these up for you — you do
not need to write the wrapper yourself.

If you do not use `list_card.html` (e.g. a bare table somewhere),
the raw pattern is:

```django
{% load render_table from django_tables2 %}

<div id="{{ table.wrapper_id }}"
     hx-get="{{ request.path }}"
     hx-trigger="{{ table.hx_trigger }}"
     hx-swap="outerHTML"
     hx-select="#{{ table.wrapper_id }}">
  {% render_table table %}
</div>
```

Your modal forms (built on `HtmxFormViewMixin` /
`SuccessEventMixin`) return `HX-Trigger: <ns>:created` (or
`:changed` / `:deleted`) on success — the wrapper picks it up and
re-renders.

Override `listen_events` on the table for a different event set, or
`get_listen_events()` for dynamic logic.

## Templates

The pattern ships four templates under
`src/conjunto/templates/conjunto/`:

| Template | Role |
|---|---|
| `tables/list_card.html` | Main card (search + filters + header-actions + table) — `{% include %}` it from your list page. |
| `tables/_search.html` | Search-input partial. Rendered when `search_fields` is non-empty. |
| `tables/_header_actions.html` | Header-action button list. Uses the `header_action_attrs` template tag. |
| `tables/_row_actions.html` | Per-row button list inside the `actions` column. |
| `filters/_select.html` | Default filter widget — a `<select>` dropdown, wired up with HTMX. |

### Overriding blocks

`list_card.html` defines five named blocks:

| Block | What it wraps |
|---|---|
| `card_header` | The entire `<div class="card-header">` (search + filters + header actions). |
| `search` | The search input slot. |
| `filters` | The filter widget slot. |
| `header_actions` | The right-aligned button slot. |
| `card_body` | The table body (defaults to `{% render_table table %}`). |

If you need more control, `extend` the template instead of including
it:

```django
{% extends "conjunto/tables/list_card.html" %}

{% block header_actions %}
  <div class="btn-list">
    {{ block.super }}
    <a class="btn btn-ghost-secondary" href="/my/extra/link/">
      <i class="ti ti-external-link"></i>
      {% trans "Open dashboard" %}
    </a>
  </div>
{% endblock %}
```

### Overriding filter widgets

Each `Filter` has a `widget_template` attribute that defaults to
`conjunto/filters/_select.html`. Change it per filter to render a
custom widget:

```python
filters = [
    ChoiceFilter("status", widget_template="my_app/filters/_status_pills.html"),
]
```

The widget template receives `filter`, `current_value`, `table`, and
`request` in its context.

## Bulk actions

Multi-record actions ("delete selected", "block selected", "export
selected") build on three pieces:

- **`BulkAction`** dataclass — declarative button (label, icon, URL,
  variant, confirm flow, permission). Symmetrical to
  `HeaderAction`, but always carries
  `hx-include="[name='pks']:checked"` so the user's checkbox
  selection travels along.
- **`IBulkAction`** GDAPS interface + **`get_bulk_actions()`** —
  merge plugin-contributed actions with the view's hard-coded list,
  filter by `is_allowed()`, sort by `weight`.
- **`BulkActionView`** (in `conjunto.htmx.views`) — server base that
  reads `request.POST.getlist('pks')`, runs `perform(queryset)`, and
  returns `204 + HX-Trigger: <success_event>`. `GET` renders the
  confirmation modal so the modal-confirm flow works out of the box.

UI shape: a sticky bottom bar (`conjunto/tables/_bulk_actions_bar.html`)
shows "N selected" + one button per action, plus a "Clear" button.
The bar lives inside an Alpine `x-data="cjBulkSelect()"` scope that
tracks selection count + master-checkbox state. The bar is
auto-hidden until `count > 0`.

### Wiring up a list page

```python
# views.py
from django.urls import reverse_lazy
from django.utils.translation import gettext_lazy as _

from conjunto.tables import BulkAction, get_bulk_actions


class AccountListView(PermissionRequiredMixin, ListView):
    permission_required = "myapp.view_account"
    ...

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["bulk_actions"] = get_bulk_actions(
            self.request,
            actions=[
                BulkAction(
                    name="delete",
                    label=_("Delete selected"),
                    icon="trash",
                    url=reverse_lazy("myapp:account:bulk_delete"),
                    variant="btn-danger",
                    confirm=_("Delete these accounts?"),
                    permission="myapp.delete_account",
                    weight=10,
                ),
                BulkAction(
                    name="block",
                    label=_("Block selected"),
                    icon="user-pause",
                    url=reverse_lazy("myapp:account:bulk_block"),
                    variant="btn-warning",
                    confirm=_("Block these accounts?"),
                    permission="myapp.change_account",
                    weight=20,
                ),
            ],
            menu="myapp.account.bulk",  # for IBulkAction plugins
        )
        return ctx
```

```django
{# account_list.html (the swap-target partial) #}
<div x-data="cjBulkSelect()" id="account-list" hx-trigger="...">
  <table>
    <thead>
      <tr>
        {% include "conjunto/tables/_bulk_select_th.html" %}
        <th>Name</th> ...
      </tr>
    </thead>
    <tbody>
      {% for account in accounts %}
        <tr>
          {% include "conjunto/tables/_bulk_select_td.html" with pk=account.pk %}
          <td>{{ account.name }}</td> ...
        </tr>
      {% endfor %}
    </tbody>
  </table>
  {% include "conjunto/tables/_bulk_actions_bar.html" %}
</div>
```

### The action endpoint

```python
# views.py — bulk delete
from conjunto.htmx.views import BulkActionView


class AccountBulkDeleteView(BulkActionView):
    model = Account
    permission_required = "myapp.delete_account"
    success_event = "accounts:changed"
    template_name = "myapp/_account_bulk_delete_confirm.html"

    def perform(self, queryset):
        queryset.delete()
```

`GET` renders `template_name` with `pks`, `count`, `queryset`, and
`action_url` in context — typically a small modal form that POSTs
back to the same URL with the pks rendered as hidden inputs. The
default template at `conjunto/tables/_bulk_confirm.html` already
handles the boilerplate; override `template_name` per-action only
when wording matters ("Delete N accounts" vs. "Block N accounts
with reason").

For a direct-POST action (no confirmation) leave `BulkAction.confirm`
empty — the bar button issues `hx-post` directly, no modal round-trip.

### Refresh strategy

`perform()` returns. The view sends `204 + HX-Trigger:
<success_event>`. The list wrapper (with `hx-trigger="<event> from:body"`)
re-fetches itself, the table renders fresh, Alpine re-initialises
with `count=0`, the bar disappears. No client-side selection
clearing needed.

### Plugin actions

A plugin can contribute an action without touching the host view —
register an `IBulkAction` implementation with a matching `menu`:

```python
# in your plugin's tables.py / menus.py
from conjunto.tables import BulkAction, IBulkAction


class ExportCsvBulkAction(IBulkAction):
    menu = "myapp.account.bulk"
    weight = 50

    def to_bulk_action(self, request):
        if not request.user.has_perm("myapp.export_account"):
            return None
        return BulkAction(
            name="export",
            label=_("Export as CSV"),
            icon="file-download",
            url=reverse_lazy("myapp:account:bulk_export"),
            variant="btn-ghost-secondary",
        )
```

`get_bulk_actions(..., menu="myapp.account.bulk")` picks it up
automatically — same discovery model as `IRowAction` /
`IHeaderAction`.
