# TinyMCE Rich-Text Editor

Conjunto ships optional integration for the **TinyMCE Community
Edition** (GPLv2-or-later, v7) as a rich-text editor. Assets are
**self-hosted** — they are downloaded by the consumer project via
`python manage.py update_libraries tinymce` and served from
`<CONJUNTO_VENDOR_DIR>/tinymce/`. **No CDN runtime references** are
used. This is required by:

- **Zero Trust — data pillar.** All assets must be served from
  infrastructure we control.
- **GDPR Art. 44 ff.** Loading JS from a CDN leaks the visitor's IP
  address to a third-party processor and triggers international
  data-transfer obligations. Self-hosting avoids the question.

## Installation

### 1. Download the assets

```
python manage.py update_libraries tinymce
```

This fetches the official npm tarball for the pinned version
(`TINYMCE_VERSION` in `src/conjunto/_vendor/registry.py`) and
extracts a curated subset into `<CONJUNTO_VENDOR_DIR>/tinymce/`: the
editor JS, icons, language packs, models, plugins, skins, themes,
and — critically — the upstream `LICENSE.TXT` (GPLv2 notice, required
for redistribution). The companion package `tinymce-i18n` is pulled
in automatically via `LIBRARY_COMPANIONS`.

### 2. Register in your template

```django
{% load conjunto %}

{% conjunto_require_tinymce %}

<textarea name="body" class="tinymce">{{ form.body.value|default_if_none:"" }}</textarea>
```

The tag is **idempotent per request**. Rendering it from multiple
included templates produces only one `<script>` tag and one `init`
block.

### 3. Pick a selector (optional)

The default CSS selector is `textarea.tinymce`. Pass a custom one when
you need multiple editors with different configurations on one page:

```django
{% conjunto_require_tinymce selector="#article-body" %}
```

## Features

- **GPL license key.** TinyMCE v7 requires `license_key: 'gpl'` for
  the Community Edition — the tag sets this automatically.
- **Self-hosted skin.** `oxide` for light mode, `oxide-dark` for dark
  mode. Follows the `conjunto.color_scheme` scoped setting.
- **Self-hosted content CSS.** `content/default` / `content/dark`,
  served from the local static tree.
- **i18n.** Language pack picked from Django's active language via
  `get_language()`. Falls back to English when the language is not in
  the bundled set (`de`, `de-at`, `de-ch`, `fr`, `es`, `it`, `nl`,
  `pt`, `pt-br`, `ru`, `zh-hans`, `ja` as of writing).
- **Lean toolbar.** `bold italic | bullist numlist | link | h2 h3 |
  code`. No inline `style` attrs, no raw `<script>` inputs.
- **No branding, no promotion, no menubar.**

## Output sanitisation — MANDATORY

!!! danger "TinyMCE emits raw HTML — never trust it."
    Every value that leaves a TinyMCE editor and hits your database
    **must** be sanitised on the server before persistence, using a
    bleach-based allowlist or a dedicated library such as
    [nh3](https://pypi.org/project/nh3/). Never bypass this step.
    Client-side toolbar restrictions can be defeated trivially.

Conjunto **does not currently ship a `SafeHTMLField`**. Each consumer
app is responsible for its own sanitisation layer. A minimal
reference implementation:

```python
import bleach
from django.db import models

ALLOWED_TAGS = [
    "p", "br", "strong", "em", "u",
    "ul", "ol", "li",
    "h2", "h3", "blockquote", "code", "pre",
    "a",
]
ALLOWED_ATTRS = {"a": ["href", "title", "rel"]}

class SanitisedHTMLField(models.TextField):
    def pre_save(self, model_instance, add):
        value = getattr(model_instance, self.attname) or ""
        clean = bleach.clean(
            value,
            tags=ALLOWED_TAGS,
            attributes=ALLOWED_ATTRS,
            strip=True,
        )
        setattr(model_instance, self.attname, clean)
        return clean
```

Add `bleach` to your project's `pyproject.toml` — it is **not** a
conjunto dependency on purpose (consumers pick their sanitiser).

## Content-Security-Policy

The inline `init` snippet is emitted as a `<script>` element with
literal TinyMCE configuration. Under a strict CSP without
`'unsafe-inline'` for `script-src`, the browser would refuse to
execute it — unless the element carries a matching per-request
`nonce`.

**The tag handles nonces automatically.** If the active request has a
`request.csp_nonce` attribute (set by `django-csp`'s middleware, or
any compatible CSP middleware that follows the same convention), the
tag adds `nonce="<value>"` to the emitted `<script>` element. No
configuration on the tag side is required — enable the middleware,
send a `script-src 'self' 'nonce-<value>'` header, and the init
snippet is covered.

When no `csp_nonce` attribute is present, the tag falls back to a
plain inline script (no `nonce` attribute). This preserves backwards
compatibility for projects that have not yet adopted CSP.

Do **not** globally allow `'unsafe-inline'` just for TinyMCE — that
weakens your CSP posture for every other script on the page.

### Minimal django-csp setup

```python
# settings.py
INSTALLED_APPS = [..., "csp", ...]
MIDDLEWARE = [..., "csp.middleware.CSPMiddleware", ...]

CONTENT_SECURITY_POLICY = {
    "DIRECTIVES": {
        "script-src": ["'self'"],
        "default-src": ["'self'"],
        # ... your other directives ...
    },
}
```

`django-csp` automatically injects the nonce into outgoing responses
and attaches `request.csp_nonce` — no further wiring is needed for
the TinyMCE tag.

## License & redistribution

TinyMCE is **GPLv2-or-later**. When you distribute a build of your
project that includes the downloaded `static/conjunto/tinymce/` tree,
you must:

- Keep `LICENSE.TXT` in the asset directory (extracted automatically).
- Preserve the copyright notice.
- Either ship the complete corresponding source of TinyMCE or provide
  a written offer pointing to the pinned upstream tarball URL.

See `THIRD_PARTY_LICENSES.md` at the repository root.

## Updating

To bump the TinyMCE version (in conjunto itself):

1. Edit `TINYMCE_VERSION` in `src/conjunto/_vendor/registry.py`.
2. Release a new conjunto version. Consumers re-fetch via
   `python manage.py update_libraries --force tinymce` after upgrading.
3. Update `THIRD_PARTY_LICENSES.md` if the upstream license terms
   have changed (they should not, unless TinyMCE is re-licensed).
