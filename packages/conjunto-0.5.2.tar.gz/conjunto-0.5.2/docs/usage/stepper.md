# Stepper widgets

Tabler-styled `[-] input [+]` numeric inputs with clickable icon-addons
on the **left** and **right** of the input. Both buttons are Alpine-driven
and dispatch a bubbling `input` event on every change — no HTMX, no server
roundtrip. They replace the browser's native number-input spinners (which
are inconsistent across browsers and notoriously hard to style).

Two flavours share a common base:

| Widget                  | For                                  | Step type            |
|-------------------------|--------------------------------------|----------------------|
| `IntegerStepperInput`   | counts, quantities, scores           | `int`                |
| `DecimalStepperInput`   | prices, dosages, weights, percent    | `int` / `float` / `Decimal` |

The shared base (`BaseStepperInput`) owns the markup, sizing, alignment,
min/max clamping, and the `cj-stepper` CSS class. Each subclass only
contributes its parsing/masking/formatting JS.

## Integer stepper

```python
from django import forms
from conjunto.forms import IntegerStepperInput

class OrderForm(forms.Form):
    quantity = forms.IntegerField(
        widget=IntegerStepperInput(step=1, min=0, max=999),
    )
```

| Argument         | Default | Notes                                                         |
|------------------|---------|---------------------------------------------------------------|
| `size`           | `"md"`  | `"sm"` / `"md"` / `"lg"` (Tabler form-control sizes)          |
| `step`           | `1`     | **Must be `int`.** Use `DecimalStepperInput` for fractions.   |
| `min`, `max`     | `None`  | Numeric clamps; `[-]`/`[+]` stop at the bound                 |
| `align`          | `"end"` | `"start"` / `"center"` / `"end"` (Bootstrap `text-…`)         |
| `allow_negative` | `False` | Allow a leading `-` in the mask. `min < 0` does NOT flip this |

Passing a non-int `step` raises `TypeError` — the type system steers you
to the right widget.

## Decimal stepper

```python
from decimal import Decimal
from django import forms
from conjunto.forms import DecimalStepperInput

class PriceForm(forms.Form):
    amount = forms.DecimalField(
        max_digits=8, decimal_places=2, localize=True,
        widget=DecimalStepperInput(step=Decimal("0.10"), min=0),
    )
```

`DecimalStepperInput` adds:

| Argument            | Default                               | Notes                                              |
|---------------------|---------------------------------------|----------------------------------------------------|
| `step`              | `Decimal("0.1")`                      | `int` / `float` / `Decimal`. `Decimal` recommended for currency |
| `decimal_places`    | derived from `step` (`0.25` → 2)      | Override to force fixed precision                  |
| `decimal_separator` | `get_format("DECIMAL_SEPARATOR")`     | Locale-aware (`,` in DE, `.` in EN). Override with `"."` to force |

`+ all base arguments above`.

### Locale handling

The decimal separator is resolved at widget construction time via
`django.utils.formats.get_format("DECIMAL_SEPARATOR")` — DE-AT users see
`0,5`, EN users see `0.5`. Pair the widget with `DecimalField(localize=True)`
so the form round-trips the comma-formatted POST value back to a
`Decimal`. If you need a fixed format (e.g. unit-less ratios), pass
`decimal_separator="."` explicitly.

Float-precision drift (`0.1 + 0.2 → 0.30000000000000004`) is neutralised
on every commit via `toFixed(decimal_places)`, so the rendered value is
always clean.

## Alpine binding

Neither widget puts an `x-model` on the input — that's intentional, so
consumer-side bindings never collide with widget internals. Pass any
Alpine directive through `attrs`:

```python
IntegerStepperInput(attrs={"x-model.number": "form.quantity"})
DecimalStepperInput(attrs={"x-model.number": "form.amount"})
```

The widget always dispatches a bubbling `input` event after `inc()`/
`dec()` so an external `x-model` (or other listener) picks up the
programmatic change.

## CSS / Media

Both widgets share `static/conjunto/css/stepper.css`, included via the
`Media` inner class. Buttons set `pointer-events: auto` inline so clicks
land even when `{{ form.media }}` is missing (modal forms commonly skip
it). The hover/disabled styling needs the CSS — for full visual polish,
include `{{ form.media }}` in the form template.

## When NOT to use

- For continuous values where a slider fits better, use a
  `<input type="range">`. Steppers are for **discrete** values.
- For very large ranges (>1000 clicks), pair the stepper with a typed-in
  fallback or use a slider — clicking 500 times is bad UX.
- For `forms.IntegerField(choices=…)` (radio-like enums), a select
  widget is clearer.
