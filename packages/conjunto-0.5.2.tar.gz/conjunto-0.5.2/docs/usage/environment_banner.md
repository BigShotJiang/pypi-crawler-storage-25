# Environment banner

Conjunto renders a thin coloured stripe at the very top of every page
when the current request is not hitting production. It also prefixes
the browser-tab title with the environment name (e.g.
`[LOCAL] medSpeak`). Both are driven by the
**`CONJUNTO_ENVIRONMENT_BANNER`** Django setting and the
`cj_environment` template variable.

The point is operational: you immediately notice that the tab open in
front of you is the dev server, not the live one, before clicking
"Delete user" on what you thought was a staging row.

## The default

Out of the box, conjunto ships exactly one banner entry:

```python
CONJUNTO_ENVIRONMENT_BANNER = [
    {
        "name": "LOCAL",
        "hosts": ["localhost", "127.0.0.1", "0.0.0.0"],
        "color": "#dc3545",   # red
        "require_debug": True,
        "fallback_on_debug": True,
    },
]
```

Behaviour with this default:

| Request host | `DEBUG` | Banner |
|---|---|---|
| `localhost`, `127.0.0.1`, `0.0.0.0` | `True` | LOCAL (red) |
| `localhost`, `127.0.0.1`, `0.0.0.0` | `False` | **none** (`require_debug` blocks it) |
| anything else | `True` | LOCAL via `fallback_on_debug` |
| anything else | `False` | none |

Production (`DEBUG=False`, real domain) renders nothing — neither
markup nor a tab-title prefix. The banner partial short-circuits when
`cj_environment` is `None`, so there is no leftover empty `<div>`.

## Per-entry options

Each entry in `CONJUNTO_ENVIRONMENT_BANNER` is a dict:

| Key | Type | Default | Meaning |
|---|---|---|---|
| `name` | `str` | `""` | Short label. Rendered as `[NAME]` in the tab title and as the banner's `aria-label` / `title` tooltip. |
| `hosts` | `list[str]` | `[]` | Hostnames matched against `request.get_host()` (case-insensitive, port stripped). |
| `color` | `str` (CSS) | `"#dc3545"` | Background colour of the 4 px stripe. |
| `require_debug` | `bool` | `False` | If `True`, the entry only matches when `settings.DEBUG=True`. **Use this for the LOCAL entry** — see "Why `require_debug`" below. |
| `fallback_on_debug` | `bool` | `False` | If `True` and no host matched, this entry is selected when `DEBUG=True`. Useful when you start `runserver 0.0.0.0:8000` and connect from another machine on the LAN — the request host is no longer `localhost`, but you still want the banner. |

## Match order

The lookup runs in this fixed order:

1. **Host match** against each entry in declaration order. First match
   wins. Entries with `require_debug=True` are skipped when
   `DEBUG=False`.
2. **DEBUG fallback**: if no host matched and `DEBUG=True`, the first
   entry with `fallback_on_debug=True` is used.
3. Otherwise: `None`. Banner and tab-title prefix are skipped.

## Adding a STAGING banner

Just append a second entry. STAGING boxes typically run with
`DEBUG=False`, so leave `require_debug` off:

```python
CONJUNTO_ENVIRONMENT_BANNER = [
    {
        "name": "LOCAL",
        "hosts": ["localhost", "127.0.0.1", "0.0.0.0"],
        "color": "#dc3545",
        "require_debug": True,
        "fallback_on_debug": True,
    },
    {
        "name": "STAGING",
        "hosts": ["staging.medspeak.io"],
        "color": "#fd7e14",   # orange
    },
]
```

Add a custom colour per environment, but keep them visually distinct
from each other and from the page chrome.

## Disabling

Set the value to an empty list. Nothing is rendered, ever:

```python
CONJUNTO_ENVIRONMENT_BANNER = []
```

## Why `require_debug` — the reverse-proxy gotcha

`request.get_host()` returns the value of the HTTP `Host` header (or
`X-Forwarded-Host` if you have set `USE_X_FORWARDED_HOST = True`).
Reverse proxies *should* forward the original host through to the
upstream Django process, e.g. with `proxy_set_header Host $host;` in
nginx. If they don't — and people forget this all the time — the
upstream sees `localhost` for every production request, and a
host-only LOCAL banner would light up the live site in red.

`require_debug` defends against that. The default LOCAL entry has it
on, so even a misconfigured proxy can't trigger the LOCAL banner in
production: production runs with `DEBUG=False`, and a
`require_debug`-gated entry doesn't match there.

If you ever run a fully local dev server with `DEBUG=False`, you'll
need to either drop `require_debug` from your custom config or accept
that the banner won't show. Production safety beats local rarity.

## Customising the partial

The banner template is `conjunto/_environment_banner.html`. It uses
inline CSS (`position: fixed; top: 0; height: 4px;`) so it works
without any extra stylesheet. Override the template path-style if you
need a thicker stripe, a label inside the stripe, or a different
position — but keep it cheap to render: it runs on every request.

The driving template variable is `cj_environment`, populated by
`conjunto.context_processors.globals` (already wired up in
`conjunto/base.html`, inherited by `conjunto/app_base.html`).
