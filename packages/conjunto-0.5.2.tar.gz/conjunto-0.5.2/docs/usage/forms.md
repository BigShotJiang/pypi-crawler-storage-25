# Forms

> **Hard prerequisite for any widget that ships JS or CSS:** the page
> template that renders the form **must** emit `{{ form.media }}` (or an
> equivalent `<script>`/`<link>` for the widget's assets). This applies to
> `DatePickerInput` (Litepicker), `TimePickerInput` (live mask + ↑/↓ keys
> + buttons), `PersistentFileWidget`, anything with a `Media` inner class,
> and any TinyMCE/SafeHTML widget combination. **Without `{{ form.media }}`
> these widgets silently degrade to plain inputs** — typing letters
> "works" (because Django's default text input accepts anything) but the
> JS-driven UX (mask, filter, picker, buttons, auto-format) is gone.
>
> ```django
> {# Full-page form #}
> {% block extra_js %}
>   {{ form.media }}
> {% endblock %}
>
> {# Modal/HTMX partial — also include here, otherwise the swap arrives JS-less #}
> <div class="modal-content">
>   {{ form.media }}
>   <form ...>{{ form|crispy }}</form>
> </div>
> ```
>
> If a widget JS file is included once globally in your base template (e.g.
> via `<script src="{% static '…' %}">`), `{{ form.media }}` becomes
> optional for that one file — but the safer default is to always emit
> `{{ form.media }}` so widgets are self-sufficient.

## Safe HTML input (`SafeHTMLField`)

`SafeHTMLField` is a `forms.CharField` subclass that sanitizes HTML on the
**server** using [bleach](https://bleach.readthedocs.io/). Use it for any
field whose value originates from a WYSIWYG/rich-text editor (TinyMCE,
CKEditor, …) before storing or rendering it.

### Why server-side sanitization

The editor only sanitizes what the user *sees*. Anyone can bypass the
editor and POST arbitrary HTML — including `<script>`, `onclick=…`, or
`href="javascript:…"` — directly to your view. Templates that render
editor output with `|safe` *trust* that the value has already been
cleaned. `SafeHTMLField` is that cleaning step (defense in depth, CISA
Zero Trust pillar 5: data).

### Quick start

```python
from django import forms
from conjunto.forms import SafeHTMLField

class ArticleForm(forms.Form):
    title = forms.CharField()
    body = SafeHTMLField()
```

That's it. With no arguments, `SafeHTMLField` applies a restrictive but
practical default whitelist (`p`, `br`, `strong`, `em`, `u`, `s`, `sub`,
`sup`, `ul`, `ol`, `li`, `a`, `h1`–`h6`, `blockquote`, `code`, `pre`,
`hr`, `span`), allows `href`/`title`/`rel`/`target` on `<a>` and `class`
on `<span>`, and accepts only `http`, `https` and `mailto` URL protocols.
Everything else is stripped.

### Customizing the whitelist

```python
class CommentForm(forms.Form):
    body = SafeHTMLField(
        allowed_tags=["p", "br", "strong", "em", "a"],
        allowed_attributes={"a": ["href"]},
        allowed_protocols=["https", "mailto"],
    )
```

| Argument             | Default                              | Notes                                                       |
| -------------------- | ------------------------------------ | ----------------------------------------------------------- |
| `allowed_tags`       | `DEFAULT_ALLOWED_TAGS`               | Whitelist of tag names. Anything else is stripped.          |
| `allowed_attributes` | `DEFAULT_ALLOWED_ATTRIBUTES`         | Mapping of tag → attribute names.                           |
| `allowed_protocols`  | `DEFAULT_ALLOWED_PROTOCOLS`          | Allowed URL protocols (`href`/`src`).                       |
| `strip_disallowed`   | `True`                               | `True` removes disallowed tags, `False` HTML-escapes them.  |
| `strip_comments`     | `True`                               | Remove HTML comments.                                       |

The defaults are exposed as `conjunto.forms.DEFAULT_ALLOWED_TAGS`,
`DEFAULT_ALLOWED_ATTRIBUTES` and `DEFAULT_ALLOWED_PROTOCOLS` if you want
to extend them rather than replace them:

```python
from conjunto.forms import DEFAULT_ALLOWED_TAGS, SafeHTMLField

class ArticleForm(forms.Form):
    body = SafeHTMLField(
        allowed_tags=list(DEFAULT_ALLOWED_TAGS) + ["img", "figure", "figcaption"],
        allowed_attributes={"a": ["href", "title"], "img": ["src", "alt"]},
    )
```

!!! note "Parameter name `strip_disallowed`"
    Django's `CharField` already accepts a `strip` kwarg (whitespace
    trimming on input). To avoid that collision, the bleach behaviour is
    exposed as `strip_disallowed`.

### Widget

The default widget is `forms.Textarea`. Pass `widget=` to wire up a
TinyMCE / CKEditor widget — sanitization runs regardless of the widget
used:

```python
body = SafeHTMLField(widget=TinyMCEWidget())
```

### What gets removed

Given the input

```html
<p>Hi <strong>there</strong></p>
<script>alert(1)</script>
<a href="javascript:alert(1)" onclick="alert(2)">x</a>
<p style="color:red">styled</p>
<!-- secret -->
```

`SafeHTMLField` returns

```html
<p>Hi <strong>there</strong></p>
alert(1)
<a>x</a>
<p>styled</p>
```

— `<script>` and `onclick=` are gone, the `javascript:` href is dropped,
the inline `style` attribute is removed, and the comment is stripped.
The literal text inside `<script>` survives as plain text (no execution
context).

## Dependent Fields (HTMX)

`DependentFieldsMixin` lets you build forms where some fields react to
changes in other fields — e.g. a *country* selector that filters the
*federal state* queryset, or a *role* selector that shows/hides extra fields.

The mixin auto-discovers `<fieldname>_changed(value)` methods, wires up
`hx-*` attributes on the trigger widgets, and calls the callbacks both on
initial render and on HTMX re-renders.

### Quick start

```python
from django.urls import reverse_lazy
from django import forms
from conjunto.forms import DependentFieldsMixin

class SignupForm(DependentFieldsMixin, forms.ModelForm):
    update_url = reverse_lazy("signup_form_fragment")

    country = forms.ChoiceField(choices=[("AT", "Austria"), ("DE", "Germany")])
    federal_state = forms.ModelChoiceField(queryset=FederalState.objects.none())
    role = forms.ChoiceField(choices=[("user", "User"), ("doc", "Doctor")])
    speciality = forms.CharField(required=False)

    def country_changed(self, value):
        """Filter federal_state queryset whenever country changes."""
        if value:
            self.fields["federal_state"].queryset = (
                FederalState.objects.filter(country=value)
            )

    def role_changed(self, value):
        """Show speciality only for doctors."""
        is_doc = value == "doc"
        self.fields["speciality"].required = is_doc
        if not is_doc:
            self.fields["speciality"].widget = forms.HiddenInput()
```

### How it works

1. **Auto-discovery:** On `__init__`, the mixin scans for methods named
   `<fieldname>_changed`. For each match, it sets `hx-get`, `hx-trigger`,
   `hx-include`, `hx-target`, and `hx-swap` on the field's widget.

2. **`hx-include="closest form"`** ensures *all* form field values are sent
   with the GET request, so the server has the full form state. This
   prevents fields resetting to initial value bugs.

3. **`hx-target` / `hx-swap="outerHTML"`** replaces the target element
   with the re-rendered version. The default `hx_target` is `"closest form"`,
   which replaces the entire `<form>` element. Override `hx_target` on the
   form class if your fragment view renders only an inner container:
   ```python
   class MyForm(DependentFieldsMixin, forms.Form):
       hx_target = "#form-body"  # only swap the inner container
   ```

4. **`apply_dependencies()`** is called in `__init__` with the current
   data/initial/instance values, so callbacks run on every render — not just
   on HTMX fragment requests.  It uses this priority chain for field values:
   `bound data > initial kwargs > field.initial > model instance > None`.
   Callbacks are **always** called, even with `value=None`, so they can
   set correct defaults (e.g., hiding a dependent field).

5. **`_resolve_field_value()`** converts raw PK strings to model instances
   for `ModelChoiceField` fields (those with a non-``None`` ``queryset``
   attribute), so your callback receives the actual object.  For all other
   fields (plain ``ChoiceField``, ``CharField``, etc.) the raw value is
   returned unchanged.

### Fragment view

For the HTMX re-render endpoint, use `DependentFieldsView`:

```python
from conjunto.htmx.views import DependentFieldsView

class SignupFragmentView(DependentFieldsView):
    form_class = SignupForm
    template_name = "myapp/signup.html#form_body"
```

Or write a minimal view yourself — the mixin handles everything in `__init__`:

```python
class SignupFragmentView(View):
    def get(self, request):
        form = SignupForm(initial=request.GET.dict())
        return render(request, "myapp/signup.html#form_body", {"form": form})
```

!!! important
    Use `initial=` instead of `data=` so the form stays **unbound** and no
    validation errors appear during field-change re-renders.

### Template

No manual `hx-*` attributes needed on trigger fields — the mixin adds them
automatically. Just render the form normally:

```django
<form id="signup-form" method="post">
  {% csrf_token %}
  {% partialdef form_body %}
  <div id="form-body">
    {{ form.country }}
    {{ form.federal_state }}
    {{ form.role }}
    {{ form.speciality }}
  </div>
  {% endpartialdef %}
  <button type="submit">Submit</button>
</form>
```

### Conditional validation

Use `fields_required()` in your `clean()` method for fields that are only
required depending on the state of another field:

```python
def clean(self):
    cleaned = super().clean()
    if cleaned.get("role") == "doc":
        self.fields_required("speciality")
    return cleaned
```

### Important notes

- **MRO:** Place `DependentFieldsMixin` *before* `forms.Form` /
  `forms.ModelForm` in the class definition.
- **No Alpine.js needed** in the swapped area — visibility is controlled
  server-side (e.g. `HiddenInput` or `{% if %}` in the template).
- **No CSRF token needed** for the fragment view — it uses `hx-get`.
- The mixin uses `hx-get` (not `hx-post`) for lightweight re-renders.
- **No validation errors on re-render:** The `DependentFieldsView` uses
  `initial=` (not `data=`) to populate the form. This keeps the form
  **unbound** — no validation errors are shown during field-change
  re-renders. Validation only happens on actual form submission (POST).

### Performance tuning

Three knobs let you trade some convenience for noticeably snappier re-renders
on large or busy forms.

#### Targeted swaps with `trigger_targets`

By default the entire `<form>` is re-rendered on every trigger change. For
forms with many fields this is wasteful — both the server (Crispy renders all
field wrappers) and the client (the whole form is replaced, losing focus on
unrelated inputs). Declare per-trigger CSS selectors in `trigger_targets`:

```python
class SignupForm(DependentFieldsMixin, forms.ModelForm):
    update_url = reverse_lazy("signup_form_fragment")
    # Only swap the dependent field, not the whole form.
    trigger_targets = {"country": "#div_id_federal_state"}

    country = forms.ChoiceField(...)
    federal_state = forms.ModelChoiceField(...)

    def country_changed(self, value):
        if value:
            self.fields["federal_state"].queryset = (
                FederalState.objects.filter(country=value)
            )
```

When a trigger field has an entry, the mixin sets both `hx-target` and
`hx-select` to that selector. The server still renders the full form, but the
client extracts only the named subtree from the response and replaces just
that — other inputs keep their focus and value, and the DOM update is
dramatically smaller.

If a trigger field is **not** in the mapping, it falls back to the form-level
`hx_target` (`"closest form"` by default). For genuine server-side savings,
point the fragment view at a Django 6 partial that renders only the relevant
subtree.

#### Selective callback execution (opt-in)

By default **every** `*_changed()` callback runs on every re-render.  This is
the safe choice for the common case: a form with multiple independent
triggers, where changing one trigger must not wipe the other's state.
Example — `country` filters `federal_state`, while `health_care_type`
toggles `speciality` visibility.  If only the triggered callback ran, the
`federal_state` queryset would be reset to its default the moment the user
touched `health_care_type`.

For forms where every trigger is **truly independent** of every other
trigger (no shared queryset / visibility state), opt into the leaner mode:

```python
class SignupFragmentView(DependentFieldsView):
    form_class = SignupForm
    template_name = "myapp/signup.html#form_body"
    isolate_triggered_callback = True  # only run the triggered callback
```

When opted in, the view forwards the HTMX `HX-Trigger-Name` header (the
`name` attribute of the element that fired the request) to the form, which
runs only that one callback.  This saves the per-trigger
`_resolve_field_value()` DB lookup and the callback body itself.

You can also pass the kwarg directly when instantiating the form yourself:

```python
form = SignupForm(initial=request.GET.dict(),
                  triggered_field=request.headers.get("HX-Trigger-Name"))
```

If `triggered_field` is unknown or `None`, the mixin runs all callbacks.

#### Browser form-restore on reload (F5 / bfcache)

Browsers restore form values across reloads and back/forward navigation
without firing a `change` event. For dependent forms this can desync the
visible value from the dependent fields' state (which were rendered
against the server's initial). Opt in to a hard reset to server defaults
on reload:

```python
class HardResetForm(DependentFieldsMixin, forms.Form):
    disable_trigger_autocomplete = True   # adds autocomplete="off"
    ...
```

The trade-off: the user's last selection is lost on reload, but the
cascade is guaranteed consistent. Use this on wizard steps and forms
where a clean restart-state matters more than preserving keystrokes.

#### `hx_trigger` and `hx_indicator`

Two class attributes let you tune the trigger spec and add a loading
indicator:

```python
class SearchForm(DependentFieldsMixin, forms.Form):
    update_url = reverse_lazy("search_fragment")
    hx_trigger = "keyup changed delay:300ms"   # debounce text inputs
    hx_indicator = "#cj-search-spinner"         # show spinner during request

    q = forms.CharField()

    def q_changed(self, value):
        ...
```

`hx_trigger` defaults to `"change"`, which is correct for `<select>` /
`<input type="checkbox">` / `<input type="radio">`. For `<input type="text">`
or `<textarea>` you typically want `keyup changed delay:NNNms` to debounce
keystrokes. `hx_indicator` is opt-in (no default) — when set, HTMX adds the
`htmx-request` class to the matched element while the request is in flight,
which Bootstrap/Tabler spinners can pick up to show/hide themselves.

### File inputs and dependent fields

Two independent problems affect file inputs in HTMX forms:

1. **HTMX swap loses the selection.** When a trigger field changes and
   the form is re-rendered via HTMX, any `<input type="file">` inside
   the swapped area would be replaced by an empty one.
2. **POST validation error loses the upload.** Full-page POST submits
   reload the page, and browser security forbids re-populating file
   inputs, so the user must re-select the file.

`DependentFieldsMixin` handles the first problem by adding
[`hx-preserve`](https://htmx.org/attributes/hx-preserve/) to every
file input widget (`FileInput`, `ClearableFileInput`,
`PersistentFileWidget`).  HTMX leaves those DOM elements untouched
during the swap.

```python
class UploadForm(DependentFieldsMixin, forms.Form):
    update_url = reverse_lazy("upload_fragment")

    category = forms.ChoiceField(choices=[("a", "A"), ("b", "B")])
    document = forms.FileField()          # gets hx-preserve automatically

    def category_changed(self, value):
        ...
```

Opt out per field by setting `hx-preserve` explicitly to `False`:

```python
document = forms.FileField(
    widget=forms.FileInput(attrs={"hx-preserve": False}),
)
```

For the second problem — surviving POST validation errors — use
[`PersistentFileField`](../forms/persistent_file_field.md) together
with `PersistentFileUploadMixin`.  See
[the end-to-end example](../forms/persistent_file_field.md#end-to-end-example-file-upload-with-dependent-fields).

## Time input (`TimeField` + `TimePickerInput`)

> **The widget needs `{{ form.media }}`.** Without it the JS — which provides
> the live `##:##` mask, the digits-only filter, the auto-colon, the ↑/↓
> keys, and the `[-]`/`[+]` buttons — is never loaded, and the field
> degrades to a plain text input. Make sure your form template (or the
> partial that re-renders it) emits `{{ form.media }}`. Symptom: typing
> letters is accepted, no auto-colon, ↑/↓ do nothing. See the bottom of
> this section for the exact wiring.

`conjunto.forms.TimeField` is a drop-in replacement for `django.forms.TimeField`
with a Tabler-styled widget, smart parsing of bare-digit input, optional
snap-step buttons, and optional rounding on `clean()`. Internally everything
stays `datetime.time` (24h) — Django's `TimeField` round-trips unchanged.

### Quick start

```python
from django import forms
from conjunto.forms import TimeField

class TimeEntryForm(forms.Form):
    start_time = TimeField(snap=15, round_to=15, round_mode="down")
    end_time   = TimeField(snap=15, round_to=15, round_mode="up")
```

The widget renders a Tabler `input-icon` container with the step icons as
inner `input-icon-addon` elements (left = `[-]`, right = `[+]`). This means
the widget can itself be embedded inside a Bootstrap `input-group` (an
`input-group` cannot be nested in another `input-group`). As the user
types, a live `##:##` mask auto-inserts the colon at position 2 — `1530` is
shown as `15:30` while typing, and an empty field shows `--:--` as a
placeholder so the structure is always visible. The POSTed value is always
24h `HH:MM`, no matter how the user typed it.

`[-]` and `[+]` icons appear **only** when `snap` is set; without `snap`
there is no defined step size, so the widget renders just the input. When
the field is empty (or contains an invalid value), the icons are disabled
via `aria-disabled="true"` (CSS handles the visual state and pointer-events
suppression) — the JS keeps that state in sync as the user types.

### Smart-parsing rules

The user may type any of these — both client-side (JS in
`conjunto/js/time_picker_input.js`) and server-side (`TimeField.to_python`
fallback) accept them identically:

| Input    | Result   | Rule                                                              |
|----------|----------|-------------------------------------------------------------------|
| `5`      | `05:00`  | 1 digit → hour                                                    |
| `12`     | `12:00`  | 2 digits, ≤ 23 → `HH`                                             |
| `45`     | `04:50`  | 2 digits, > 23 → first digit = hour, second digit = tens-minute   |
| `73`     | `07:30`  | dito                                                              |
| `230`    | `23:00`  | 3 digits, first two ≤ 23 → `HH:M0`                                |
| `730`    | `07:30`  | 3 digits, first two > 23 → `0H:MM`                                |
| `405`    | `04:05`  | dito                                                              |
| `0350`   | `03:50`  | 4 digits → `HH:MM`                                                |
| `1430`   | `14:30`  | dito                                                              |
| `14:30`  | `14:30`  | already canonical                                                 |

Anything that resolves to an invalid hour or minute (e.g. `9999`, `99`) is
rejected on the server and left untouched in the client (the user keeps their
text and can correct it).

### Snap-to-step buttons + ↑/↓ keys

`snap=15` makes both the `[-]`/`[+]` buttons **and** the ↑/↓ keys jump to
the next or previous multiple of 15 minutes — *not* an additive ±15. From
`12:23` the next `+` lands on `12:30`, not `12:38`. With **Shift+↑/↓** the
field moves by ±60 minutes. Without `snap`, no buttons are rendered, and
↑/↓ moves by ±1 minute.

```python
class AlarmForm(forms.Form):
    wake_up = TimeField(snap=5)               # buttons + ↑/↓ snap to 5-min grid
    bed_time = TimeField()                    # no buttons, smart-parse only
    quick = TimeField(snap=15, show_buttons=False)  # snap on ↑/↓ only
```

### Size variants

`TimePickerInput`, `DatePickerInput`, and `PersistentFileWidget` all accept
a `size` keyword (one of `"sm"`, `"md"`, `"lg"`) which maps to Tabler's
`form-control-{size}` modifier. Useful when the widget appears in a dense
table-row form, a card-header, or a modal where the default size is too
loud.

```python
from conjunto.forms import TimePickerInput, DatePickerInput, PersistentFileWidget

class CompactForm(forms.ModelForm):
    class Meta:
        widgets = {
            "wake_up":    TimePickerInput(snap=5, size="sm"),
            "start_date": DatePickerInput(size="sm"),
            "attachment": PersistentFileWidget(size="sm"),
        }
```

For `TimePickerInput`, the size also flows through to the surrounding
`input-icon` container so the `[-]`/`[+]` icons scale with the input.

### Rounding on save (`round_to`, `round_mode`)

`round_to` is independent of `snap`: it runs on every `clean()` and rounds
the cleaned `time` to the next `round_to`-minute step. Useful when the
user-facing input is fine-grained but stored values must be on a grid (e.g.
billed time entries):

```python
# Always round work-day starts down, ends up — payroll style.
start_time = TimeField(round_to=15, round_mode="down")
end_time   = TimeField(round_to=15, round_mode="up")

# Or symmetric:
slot       = TimeField(round_to=30, round_mode="nearest")
```

| `round_mode` | Behaviour                                                  |
|--------------|------------------------------------------------------------|
| `"down"`     | toward 00:00 (`14:23` → `14:15`)                           |
| `"up"`       | away from 00:00 (`14:23` → `14:30`); `23:59` wraps to `00:00` |
| `"nearest"`  | half-up (`14:22` → `14:15`, `14:23` → `14:30`); default    |

### 12h display (`format_12h=True`)

```python
wake_up = TimeField(format_12h=True)
```

The user sees `02:30 PM`, can type `230pm` or `1430` interchangeably, and
the field still stores `time(14, 30)`. The `<input value="…">` attribute is
always 24h — the JS converts it to the 12h display on init and on every
button click / arrow press.

### Using just the widget

If you only want the widget and not the convenience field (e.g. on a
`ModelForm` whose model field is already a `TimeField`):

```python
from conjunto.forms import TimePickerInput

class MyForm(forms.ModelForm):
    class Meta:
        model = MyModel
        fields = ["wake_up"]
        widgets = {
            "wake_up": TimePickerInput(snap=5, format_12h=True),
        }
```

`TimePickerInput.__init__` accepts `snap`, `format_12h`, `show_buttons`, and
`size` (one of `"sm"`, `"md"`, `"lg"`). Note that server-side rounding
(`round_to`/`round_mode`) lives on the conjunto `TimeField`, not on the
widget — combine both if you need both:

```python
class MyForm(forms.ModelForm):
    wake_up = TimeField(round_to=15, round_mode="nearest")
```

### Argument reference

| Argument       | Where         | Default     | Effect                                                   |
|----------------|---------------|-------------|----------------------------------------------------------|
| `snap`         | both          | `None`      | Step in minutes for snap-to-grid buttons + ↑/↓. Without `snap`, no buttons are rendered and ↑/↓ moves by ±1. |
| `format_12h`   | both          | `False`     | Display `hh:mm AM/PM`; POSTed value stays 24h `HH:MM`.   |
| `show_buttons` | both          | `True`      | Opt out of `[-]`/`[+]` buttons even when `snap` is set.  |
| `round_to`     | `TimeField`   | `None`      | Round cleaned value to next N-minute step.               |
| `round_mode`   | `TimeField`   | `"nearest"` | `"up"` / `"down"` / `"nearest"`.                         |

### Notes

- Pure JS — no external library; nothing to add to `CONJUNTO_LIBRARIES`.
- Re-initializes itself on every `htmx:load`, so HTMX-swapped partials work
  out of the box.
- The Python parser is exposed as `_smart_parse_time` and `_round_time` in
  `conjunto.forms.fields` for unit tests; treat them as internal but stable.

### Make sure the JS actually loads

The widget ships its JS via Django's `Media` class. For the live mask, the
non-digit input filter, and the ↑/↓ keys to work, **the page must include
`{{ form.media }}`** (or an equivalent that emits the widget's JS):

```django
{# Full-page form #}
{% block extra_js %}
  {{ form.media }}
{% endblock %}

{# Modal/HTMX partial — also include here, otherwise the input is dumb #}
<div class="modal-content">
  {{ form.media }}
  <form ...>{{ form|crispy }}</form>
</div>
```

If the field renders but typing letters works, the buttons don't update,
and ↑/↓ does nothing — that's the symptom of a missing `{{ form.media }}`.
The simplest global fix is to include the script once in your base template
(it self-initializes on `DOMContentLoaded` and re-runs on `htmx:load`):

```django
<script src="{% static 'conjunto/js/time_picker_input.js' %}"></script>
```
