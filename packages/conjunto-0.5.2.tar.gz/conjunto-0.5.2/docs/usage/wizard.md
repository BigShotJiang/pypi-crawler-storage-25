# Multi-Step Wizard (`conjunto.wizard`)

`conjunto.wizard` provides a small, HTMX-native wizard framework for forms
that fit badly into a single page — patient onboarding, tenant setup,
multi-part signup, etc.

The wizard is deliberately minimal:

- Server-side state in two models (`WizardDraft`, `WizardDraftFile`) —
  no session-data payload to grow boundlessly, easy to inspect and
  clean up.
- Identification by `session_key` — **anonymous users are supported**.
  Sensitive wizards can add `LoginRequiredMixin` in the subclass.
- Linear forward navigation with free jump-back-to-visited via a
  clickable Tabler stepper. Skipping unvisited steps is blocked.
- File uploads survive step transitions and validation errors via the
  generic [`PersistentFileField`](../forms/persistent_file_field.md).
- Crispy-forms rendering, HTMX partial swaps, no JavaScript glue code.

## Quick start

```python
# myapp/wizards.py
from django import forms
from django.urls import reverse_lazy

from conjunto.forms import PersistentFileField
from conjunto.wizard.forms import WizardStepForm
from conjunto.wizard.views import WizardStepView


class PersonalStep(WizardStepForm):
    first_name = forms.CharField(max_length=50)
    last_name = forms.CharField(max_length=50)


class PhotoStep(WizardStepForm):
    photo = PersistentFileField(required=True)


class ConfirmStep(WizardStepForm):
    agreed = forms.BooleanField()


class PatientOnboardingWizard(WizardStepView):
    wizard_key = "patient_onboarding"
    url_name = "wizard-step"
    url_namespace = "onboarding"          # optional, see URLs below
    steps = [
        ("personal", PersonalStep),
        ("photo",    PhotoStep),
        ("confirm",  ConfirmStep),
    ]
    success_url = reverse_lazy("patients:list")

    def commit(self, draft):
        # Called on the final step, after the last form validated.
        # Build your real domain objects from draft.data / draft.files.
        ...
```

```python
# myapp/urls.py
from django.urls import path

from conjunto.wizard.urls import wizard_file_urlpatterns
from .wizards import PatientOnboardingWizard

app_name = "onboarding"

urlpatterns = [
    path(
        "onboarding/",
        PatientOnboardingWizard.as_view(),
        name="wizard-start",
    ),
    path(
        "onboarding/<slug:step>/",
        PatientOnboardingWizard.as_view(),
        name="wizard-step",
    ),
    *wizard_file_urlpatterns,
]
```

Register `conjunto.wizard` in `INSTALLED_APPS`, run `uv run python
manage.py migrate`, and the wizard is live at `/onboarding/`. No login
required.

## Anatomy

### Models

- `WizardDraft` — one row per `(session_key, wizard_key)`. Unique
  constraint prevents "duplicate wizards in the same session". Holds
  `data` (JSON, one sub-dict per step), `visited_steps` (list),
  `current_step`, and an optional `user` ForeignKey set when a user
  logs in mid-wizard.
- `WizardDraftFile` — one row per `(draft, step, field)`. Physical
  file stored under `PROTECTED_MEDIA_ROOT/wizards/drafts/<draft>/<step>/<field>/`
  via `ProtectedFileSystemStorage`. Cascade-deleted with its draft.

### Forms

`WizardStepForm` is a `forms.Form` subclass that:

1. Pulls `initial` data from `draft.data[step]`.
2. Pulls persisted `WizardDraftFile` rows for the current step into
   `initial[<field>]` so `PersistentFileField` renders the
   "already uploaded" state.
3. Wires the `hx-delete` URL for each persistent file field.
4. Provides `save_to_draft(draft, step)` which:
   - persists fresh uploads as `WizardDraftFile` rows (replacing any
     previous file under the same `(step, field)`, deleting the old
     bytes on disk),
   - stores JSON-safe `cleaned_data` into `draft.data`,
   - marks the step as visited.

### Views

- `WizardViewMixin` — helper methods for step resolution, draft
  lookup, accessibility checks.
- `WizardStepView` — the main CBV. Subclass and declare `wizard_key`,
  `steps`, `url_name`, `success_url`, override `commit()`.
- `WizardFileDeleteView` — HTMX `DELETE` endpoint for removing a
  persisted file. Enforces session + user ownership (IDOR-safe).

### Templates

- `conjunto/wizard/wizard_base.html` — full-page wrapper, extends
  `conjunto/app_base.html`.
- `conjunto/wizard/_stepper.html` — Tabler `.steps` strip, each step
  either active, clickable (visited / next unvisited) or muted.
- `conjunto/wizard/_step_form.html` — the actual form + Back/Next/
  Finish buttons. HTMX swaps this partial into `#wizard-body`.

## Navigation model

- **Forward:** "Next" only advances after the current step validates.
- **Backward:** "Back" always works; no re-validation.
- **Jump:** clicking a step in the stepper sends an HTMX GET; the
  server checks `is_step_accessible()`. Non-HTMX requests get a 302
  back to the current step; HTMX requests get 403.

Accessible = step is in `visited_steps` OR step is the first one after
the last visited one OR step is the very first step. This is strict by
design — a user cannot skip steps they haven't filled in yet, and the
UI reflects that with muted stepper items.

## Zero-Trust

The wizard follows the CISA pillars:

- **Identity** — base class does *not* require login. Anonymous users
  are supported out of the box. Sensitive wizards must add
  `LoginRequiredMixin` (PII, medical data, …). When a user logs in
  mid-wizard, `WizardDraftMergeMiddleware` (opt-in) rebinds the draft
  to the rotated session_key.
- **Application** — `WizardFileDeleteView` checks session ownership
  first; if the draft has a `user`, that user's authentication is also
  required. IDOR-proof.
- **Data** — files live in `ProtectedFileSystemStorage`
  (`PROTECTED_MEDIA_ROOT`), **never** under the public `MEDIA_ROOT`.
  Consumer apps must mount a `LoginRequiredMediaView` (or
  `PermissionRequiredMediaView`) under `PROTECTED_MEDIA_URL` to serve
  these files only to the right callers.

## Concurrency caveats

- The `(session_key, wizard_key)` unique constraint means a single
  session can only run *one* draft per wizard type. Opening the same
  wizard in two tabs under the same session will have them clobber
  each other. If you need tab-independent drafts, encode a `draft_id`
  into the URL (not yet shipped).
- Session lifetime governs draft lifetime implicitly. The cleanup
  command removes drafts older than `--older-than`, which you should
  run on at least the same cadence as Django's `clearsessions`.

## Cleanup

```bash
uv run python manage.py conjunto_wizard_cleanup --older-than 7d
# Dry run
uv run python manage.py conjunto_wizard_cleanup --older-than 7d --dry-run
# Also drop drafts whose session_key has already been purged
uv run python manage.py conjunto_wizard_cleanup --older-than 7d --orphan-sessions
```

Run it daily via cron / systemd-timer alongside `clearsessions`.

## Merging anonymous drafts on login

Django's `LoginView` rotates the `session_key` to prevent session
fixation. The optional `WizardDraftMergeMiddleware` plus its signal
handler capture the pre-login key and rebind drafts onto the
authenticated session:

```python
# settings.py
MIDDLEWARE = [
    # ... before AuthenticationMiddleware ...
    "conjunto.wizard.middleware.WizardDraftMergeMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    # ...
]
CONJUNTO_WIZARD_MERGE_ON_LOGIN = True   # default
```

The `user_logged_in` signal handler inside `conjunto.wizard.middleware`
does the actual rebind; the middleware's job is simply to stash the
old session key before Django's `login()` rotates it.

## Subclassing examples

### Sensitive wizard — require login

```python
from django.contrib.auth.mixins import LoginRequiredMixin

class SensitiveWizard(LoginRequiredMixin, WizardStepView):
    wizard_key = "diagnosis_intake"
    ...
```

### Non-Django-template callable `upload_to`

`ProtectedFileField` now handles callable `upload_to` — no changes
required in consumer code, but heads-up for folks who subclassed it.

## Known limitations

- Single draft per `(session_key, wizard_key)` — multiple tabs collide.
- No built-in concurrency or optimistic locking on `draft.data` — if
  you need it, wrap `form.save_to_draft` in a `select_for_update()`.
- The final-step commit deletes draft + files unconditionally. If
  `commit()` needs the files *after* the draft is gone, copy them in
  `commit()` before returning.
- File delete URL is resolved by name (`wizard-file-delete` or
  `<namespace>:wizard-file-delete`). Custom URL names require passing
  `wizard_url_namespace=` when instantiating the form.
