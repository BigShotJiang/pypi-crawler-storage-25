# Notifications

Per-user bell dropdown fed by a Channels consumer that pushes the
rendered list on every `Notification` row change. Optional —
`conjunto.notifications` is opt-in: drop it from `INSTALLED_APPS`
and the bell disappears.

## Activation

Three conditions must all be true for the bell to render:

1. `"conjunto.notifications"` is in `INSTALLED_APPS`.
2. `cj_layout.websockets` is true. Auto-detected by Conjunto:
   `"channels"` in `INSTALLED_APPS` AND `ASGI_APPLICATION` is set.
   Override explicitly via `CONJUNTO_WEBSOCKETS_ENABLED = True/False`.
3. `request.user.is_authenticated`.

Templates gate exclusively on `{% if cj_layout.notifications %}` —
never assume.

The flag composition lives in `conjunto.context_processors.globals`;
templates that override `top_bar_right` (e.g. focused workspaces) must
include `conjunto/notifications/_bell.html` with the same gate to keep
parity with the regular shell.

## Wiring

```python
# settings.py
INSTALLED_APPS = [
    ...,
    "channels",
    "conjunto",
    "conjunto.notifications",
    ...,
]

ASGI_APPLICATION = "myproject.asgi.application"

CHANNEL_LAYERS = {
    "default": {"BACKEND": "channels.layers.InMemoryChannelLayer"} if DEBUG
    else {"BACKEND": "channels_redis.core.RedisChannelLayer",
          "CONFIG": {"hosts": [("127.0.0.1", 6379)]}},
}
```

```python
# myproject/asgi.py
from conjunto.routing import asgi_application
application = asgi_application()
```

```python
# myproject/urls.py
urlpatterns = [
    ...,
    path("notifications/", include("conjunto.notifications.urls")),
]
```

`conjunto.routing.asgi_application` aggregates every enabled
`IWebsocketURL` plugin (incl. `NotificationsWebsocketURL` ->
`/ws/notifications/`). Plugins do not need to wire ASGI themselves.

## Public API

```python
from conjunto.notifications import add, info, success, warning, error

info(user, _("Backup completed."))
warning(user, _("License key expires in 7 days."), dismissible=True)
error(user, _("Sync failed."), blocking=True)
success(user, _("Patient record imported."))
add(user, level=messages.INFO, message=_("..."), blocking=False, dismissible=True)
```

- `user`: real, saved user instance — anonymous notifications are not
  supported.
- `level`: re-uses `django.contrib.messages` constants.
- `blocking`: when True, the notification interrupts the workflow until
  acknowledged.
- `dismissible`: when False, the notification fades on its own and
  cannot be closed manually.

The signal handler in `conjunto.notifications.signals` broadcasts a
`model.updated` event to `notifications.user.<pk>`; every connected
`NotificationConsumer` re-renders the dropdown for that user via
`hx-swap-oob`.

## Channel-group contract

| Aspect | Value |
|---|---|
| Group name | `notifications.user.<recipient.pk>` |
| Event type | `model.updated` |
| Consumer | `conjunto.notifications.consumers.NotificationConsumer` |
| Template | `conjunto/notifications/dropdown_oob.html` |

Auth: the consumer rejects unauthenticated scopes (`self.close()`
before `accept()`), so the per-user channel group is only joined for
the legitimate session user.

## Customization

Override these templates via Django's loader (project-local
`templates/conjunto/notifications/...` wins over the wheel):

| Template | Purpose |
|---|---|
| `conjunto/notifications/_bell.html` | Bell + dropdown wrapper rendered into `app_base.html#top_bar_right`. |
| `conjunto/notifications/dropdown_content.html` | List partial — initial HTMX load AND every WS push. |
| `conjunto/notifications/dropdown_oob.html` | OOB swap wrapper (`hx-swap-oob="innerHTML"`). |

Do **not** re-implement the consumer or the signal handler — extend
behaviour by overriding the templates, customising
`Notification.message` content at the call site, or by writing a
sibling consumer/group if a different broadcast pattern is needed.

## Migration from `medux.notifications`

Earlier MedUX versions shipped a `medux.notifications` app; it has been
moved into `conjunto.notifications` (medux commit `0d66e17`). There is
**no compatibility shim** — plugins importing the old path fail at
first use with `ModuleNotFoundError: No module named
'medux.notifications'`. Update the import:

```python
# old
from medux.notifications import api as notifications_api

# new — either keep the namespaced form
from conjunto.notifications import api as notifications_api
# or import the helpers directly
from conjunto.notifications import info, success, warning, error
```

The function surface is identical (same names, same `(user, message,
...)` positional signature). Callers that previously used
`error(message=..., recipient=...)` keyword form must switch to
positional `error(user, message)`.

## Anti-patterns to avoid

- **Phantom dropdown:** rendering the bell yourself in
  `top_bar_right` while `conjunto.notifications` is also installed
  produces two dropdowns. Always gate on `cj_layout.notifications`
  and let the conjunto include do the work.
- **`f"user_{pk}"` groups:** legacy Channels group naming — the
  current contract is `notifications.user.<pk>`.
- **Anonymous notifications:** every helper requires a real user.
  Site-wide announcements are a different feature (CMS banner / toast
  on next page load) — do not bend `Notification` to fit them.
