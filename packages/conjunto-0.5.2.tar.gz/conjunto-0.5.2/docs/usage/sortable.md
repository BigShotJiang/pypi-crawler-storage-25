# Sortable lists

Conjunto provides a reusable drag-and-drop sortable-list pattern for
FK-linked submodels with a `weight` field — for example,
`Meeting → Agendas`, `Patient → Medications`, or any list whose order
matters and is owned by the parent (not the user).

The implementation follows the
[htmx.org Sortable.js example](https://htmx.org/examples/sortable/):
Sortable.js dispatches a native `end` DOM event on the container after
a drop, HTMX listens via `hx-trigger="end"` and POSTs the new order to
the server. **No custom JavaScript is required** beyond conjunto's
shipped `Sortable.create()` initialization.

The package lives in `conjunto.sortable` and provides three pieces:

| Symbol | Import |
|---|---|
| `SortableModelMixin` | `from conjunto.sortable.models import SortableModelMixin` |
| `SortableReorderView` | `from conjunto.sortable.views import SortableReorderView` |
| `{% sortable_attrs %}` / `{% sortable_item %}` | `{% load sortable %}` |

!!! warning "Always import from the submodule, never from the package"

    Always import from `conjunto.sortable.models` and
    `conjunto.sortable.views` — **never** from `conjunto.sortable`
    directly. A top-level re-export would pull `models.py` into the
    import graph as soon as anything touches `conjunto.sortable`,
    which can run before Django's `apps.ready()` and break startup.
    The `__init__.py` is therefore intentionally empty of re-exports.

## `SortableModelMixin`

Adds a `weight = PositiveIntegerField(default=0, db_index=True)` and
sets `Meta.ordering = ("weight", "pk")`:

```python
from django.db import models
from conjunto.sortable.models import SortableModelMixin

class Agenda(SortableModelMixin, models.Model):
    meeting = models.ForeignKey(
        "meetings.Meeting", on_delete=models.CASCADE, related_name="agendas",
    )
    title = models.CharField(max_length=200)
```

Subclass `Meta` to customise ordering — pull in the mixin's `Meta` so
you don't lose `abstract = True`:

```python
class Meta(SortableModelMixin.Meta):
    ordering = ("weight", "title")
```

### `next_weight()`

Convenience helper for `save()` overrides that auto-append new rows at
the end of a list:

```python
def save(self, *args, **kwargs):
    if not self.pk:
        self.weight = type(self).next_weight(meeting=self.meeting)
    super().save(*args, **kwargs)
```

`next_weight(step=10, **filter_kwargs)` returns the maximum `weight`
within the filtered queryset plus `step`. The default step of `10`
matches the step `SortableReorderView` uses on persistence — that
leaves room for manual insertions between two existing items.

## `SortableReorderView`

Generic class-based view that re-numbers `weight` for the items whose
PKs are sent in `request.POST.getlist("pks")`:

```python
from conjunto.sortable.views import SortableReorderView

class AgendaReorderView(SortableReorderView):
    model = Agenda
    parent_field = "meeting"
    parent_url_kwarg = "meeting_id"
    success_event = "agendas:reordered"
```

URL conf:

```python
path(
    "meetings/<int:meeting_id>/agendas/reorder/",
    AgendaReorderView.as_view(),
    name="agenda-reorder",
)
```

### Class attributes

| Attribute | Default | Effect |
|---|---|---|
| `model` | required | Model whose `weight` field is updated. |
| `parent_field` | `None` | FK name used to scope the queryset (e.g. `"meeting"`). |
| `parent_url_kwarg` | `None` | URL kwarg carrying the parent PK. Pair with `parent_field`. |
| `success_event` | `None` | If set, response carries `HX-Trigger: <event>`. |
| `weight_step` | `10` | Spacing between consecutive `weight` values. |
| `_permissions_verb` | `"change"` | Used by `AutoPermissionsViewMixin` — default permission is `change_<model>`. |

### Behaviour

- The view is **HTMX-only** (`HtmxRequestMixin(enforce_htmx=True)`).
  Direct browser POSTs return 403.
- On success the response is `204 No Content`. If `success_event` is
  set, an `HX-Trigger` header is added so other parts of the page can
  refetch themselves via `hx-trigger="<event> from:body"`.
- PKs not belonging to the parent scope are **silently ignored** —
  they are never re-numbered, even if they appear in the POST. This
  protects against clients reordering items in someone else's tree.
- Unknown PKs and unparseable values are dropped.
- `bulk_update` is used to write the new weights in one query.

## Template tags

```django
{% load sortable %}

<ul {% sortable_attrs reorder_url=reorder_url %}>
  {% for agenda in meeting.agendas.all %}
    <li class="card mb-2 p-2 d-flex align-items-center">
      {% sortable_item agenda %}
      <span class="handle me-2 text-muted" style="cursor: grab;">
        <i class="ti ti-grip-vertical"></i>
      </span>
      <div class="flex-fill">{{ agenda.title }}</div>
    </li>
  {% endfor %}
</ul>
```

`{% sortable_attrs reorder_url handle=".handle" indicator="" %}` renders:

```text
class="sortable" hx-post="…" hx-trigger="end"
hx-include="[name='pks']" hx-swap="none"
data-sortable-handle=".handle"
```

`{% sortable_item obj %}` renders a single hidden input
`<input type="hidden" name="pks" value="{obj.pk}">`.

The container element can be any block-level tag (`<ul>`, `<div>`,
`<form>`, `<tbody>` …) — Sortable.js works with all of them, and HTMX
attributes are tag-agnostic.

The CSS class `.handle` marks the drag-handle. By convention, a Tabler
icon is used:

```html
<span class="handle"><i class="ti ti-grip-vertical"></i></span>
```

To use a different selector, pass `handle=".my-handle"` to
`{% sortable_attrs %}`.

### CSRF

Conjunto-based projects typically set
`<body hx-headers='{"x-csrftoken": "{{ csrf_token }}"}'>` (see the
project CLAUDE.md), which makes every HTMX request CSRF-safe out of
the box. If your project doesn't do this, place a `{% csrf_token %}`
inside the sortable container — HTMX picks it up via `hx-include`.

### Convenience template

For the 80 %-case (vertical list with a drag handle on the left and a
small per-item template), include the shipped wrapper:

```django
{% include "conjunto/sortable/_list.html" with items=meeting.agendas.all reorder_url=reorder_url item_template="myapp/_agenda_item.html" %}
```

The wrapper renders a `<ul>` with the standard handle + per-item
template injection. For custom markup, use `{% sortable_attrs %}` and
`{% sortable_item %}` directly.

## End-to-end flow

1. Page renders the sortable list with hidden PK inputs.
2. User drags an item.
3. Sortable.js dispatches a native `end` DOM event on the container.
4. HTMX hears the event via `hx-trigger="end"` and POSTs all `pks`
   inputs (`hx-include="[name='pks']"`) in current DOM order to
   `reorder_url`.
5. `SortableReorderView.post()` re-numbers `weight` via `bulk_update`
   and returns `204 No Content` (+ optional `HX-Trigger`).
6. If a `success_event` is configured, downstream listeners can react
   (e.g. refetch a counter or sibling component).

## JavaScript

Conjunto's shipped `conjunto.js` initialises Sortable.js on every
`.sortable` container and re-binds on `htmx:load` so HTMX-swapped
subtrees pick up the behaviour automatically. Sortable.js options:

```javascript
new Sortable(el, {
  animation: 150,
  ghostClass: 'bg-info',
  handle: el.dataset.sortableHandle || '.handle',
});
```

There is no project-level JS code to write.
