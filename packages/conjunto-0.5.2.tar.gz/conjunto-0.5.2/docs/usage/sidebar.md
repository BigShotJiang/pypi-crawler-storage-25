# Sidebars (left and right)

The conjunto layout ships two symmetrical sidebars — one on each side of
the canvas. Each has three discrete display modes, persistent width, a
drag-resize handle with magnetic snap, and a topbar toggle button. The
two sides are fully independent: locking, modes, widths, and on-mobile
overlays are tracked per side.

| Mode | Visual | Width source |
|------|--------|--------------|
| `full` | Icons + titles + content / inline submenus. | `conjunto.sidebar_{left,right}_width` (free-drag, persisted). |
| `mini` | Icons only. Submenus are not shown — only level-1 items. A click follows the item's own href; a parent without its own URL is inert. To reach a submenu item, expand the sidebar to `full`. | `--cj-sidebar-{left,right}-mini-width` CSS variable (default `3.5rem`). |
| `collapsed` | Sidebar fully hidden — main content fills that side. | n/a |

The mode logic lives entirely in conjunto. Plugins implementing
`IMenuItem` with `menu="sidebar"` (left content) or `IRightSidebar`
(right content) do not need to be mode-aware.

## Scoped settings

```
conjunto.sidebar_left_mode    (str, default "full")
conjunto.sidebar_right_mode   (str, default "collapsed")
  writable_scopes : VENDOR, TENANT, DEVICE, USER
  lockable_scopes : VENDOR, TENANT

conjunto.sidebar_left_width   (str CSS length, default "15rem")
conjunto.sidebar_right_width  (str CSS length, default "20rem")
  writable_scopes : VENDOR, TENANT, USER
  lockable_scopes : VENDOR, TENANT
```

Resolver order is the standard `USER > DEVICE > GROUP > TENANT > VENDOR`.
Drag and topbar toggles write **mode** to DEVICE (per-device preference)
and **width** to USER (per-user preference). A vendor- or tenant-level
lock disables both the toggle button and the resize handle and is
enforced server-side by `SaveSidebarStateView` (403 on locked POST).

Override the framework defaults per-project via Django settings:

```python
CONJUNTO_SIDEBAR_LEFT_MODE = "full"
CONJUNTO_SIDEBAR_LEFT_WIDTH = "15rem"
CONJUNTO_SIDEBAR_RIGHT_MODE = "collapsed"
CONJUNTO_SIDEBAR_RIGHT_WIDTH = "20rem"
```

## Right-sidebar content (`IRightSidebar`)

The left sidebar is fed by the `sidebar_left_content` template block
(typically overridden by the consuming app — medux drops the rail
there). The right sidebar is plugin-driven by default: every
implementation of `IRightSidebar` renders its `template_name` into
the right `<aside>`, ordered by `weight`. Apps that want full control
can still override the `sidebar_right_content` block.

`IRightSidebar` inherits from gdaps `ITemplatePlugin`. Idiomatic
implementation:

```python
from conjunto.api.interfaces import IRightSidebar

class WaitingListBlock(IRightSidebar):
    name = "waiting-list"
    weight = 10
    template_name = "myapp/_waiting_list_block.html"

    def get_plugin_context(self, context):
        context["entries"] = WaitingEntry.objects.all()
        return context
```

## Magnetic snap drag

Both sides ship the same magnetic-snap resize handle (on the inner edge
of the sidebar, so the cursor stays inside the viewport):

```
target ≥ MINI_W + 15  → full mode, --cj-sidebar-{side}-width = target
MINI_W ± 15           → snap to mini mode
target < 15           → snap to collapsed
between (sticky)      → stays at the last snap until the cursor
                        crosses a snap-zone threshold
```

Mode switches during drag are visual-only. On `pointerup` the view
fires a single POST to `/sidebar-state/<side>/` carrying both the final
mode and (in full mode) the final width. Double-click resets to default
`full` + framework default width.

The right-side drag uses an inverted axis (dragging left = wider) so
both handles feel identical to the user.

## Topbar toggle buttons

```
#cj-sidebar-left-toggle    onclick="cjToggleSidebar('left')"
#cj-sidebar-right-toggle   onclick="cjToggleSidebar('right')"
```

Both toggle between the **last expanded mode** of that side (`full` or
`mini`) and `collapsed`. The last-expanded mode lives on
`body.dataset.sidebar{Left,Right}LastExpandedMode` and is written every
time the mode of that side changes to something other than `collapsed`.

## CSS variables

```css
:root {
  --cj-sidebar-left-width: 15rem;
  --cj-sidebar-left-mini-width: 3.5rem;
  --cj-sidebar-right-width: 20rem;
  --cj-sidebar-right-mini-width: 3.5rem;
}
```

Body classes (exactly one per side):

```
.cj-sidebar-{left,right}-mode-{full,mini,collapsed}
```

Lock indicators:

```
body[data-sidebar-{left,right}-mode-locked]
```

## JavaScript API

```js
cjSetSidebarMode(side, mode, opts?)    // side: "left"|"right"
                                       // mode: "full"|"mini"|"collapsed"
   opts.persist  default true          // POST to /sidebar-state/<side>/

cjToggleSidebar(side)                  // side: "left"|"right"
```

Both functions live on `window` and are loaded by `conjunto.js` via
`conjunto_app_scripts`.

## Mobile (< 992px)

Mode classes are intentionally ignored below 992px width. Each sidebar
falls back to the overlay behaviour driven by
`cj-sidebar-{left,right}-open` — opened/closed by its topbar toggle,
drawn over the main content with a shared backdrop. The persisted mode
survives across viewport resizes; widening the window past 992px
restores the configured mode for each side.

## BREAKING changes vs older conjunto

- `conjunto.sidebar_mode` → `conjunto.sidebar_left_mode` (data
  migration `conjunto_settings/0009_rename_sidebar_keys.py` renames
  existing rows).
- `conjunto.sidebar_width` → `conjunto.sidebar_left_width` (same
  migration).
- Body class `cj-sidebar-mode-*` → `cj-sidebar-left-mode-*`.
- Body class `cj-sidebar-open` → `cj-sidebar-left-open`.
- CSS variables `--cj-sidebar-{width,mini-width}` → `--cj-sidebar-left-{width,mini-width}`.
- ID `#cj-sidebar` → `#cj-sidebar-left`; `#cj-sidebar-resize` →
  `#cj-sidebar-left-resize`; `#cj-sidebar-toggle` →
  `#cj-sidebar-left-toggle`.
- Template block `sidebar` → `sidebar_left_content` (apps that
  overrode it must rename their override).
- URLs `/sidebar-mode/`, `/sidebar-width/` → `/sidebar-state/<side>/`
  (URL name `conjunto:sidebar-state`).
- JS API: `cjSetSidebarMode(mode)` → `cjSetSidebarMode(side, mode)`;
  `cjToggleSidebar()` → `cjToggleSidebar(side)`.
- The previous `offcanvas_right` template block is replaced by the
  full right sidebar; render content via `IRightSidebar` plugins or
  by overriding the `sidebar_right_content` block.
