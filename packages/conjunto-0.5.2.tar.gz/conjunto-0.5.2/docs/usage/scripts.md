# Scripts & Assets

Conjunto splits its JavaScript and CSS into three tiers so that pages
only load what they actually need.

| Tier                | What it includes                                              | Loaded on          |
|---------------------|---------------------------------------------------------------|--------------------|
| **Core scripts**    | htmx, tabler.js, toasts.js, tabler-theme                     | Every page         |
| **App scripts**     | Alpine.js, Litepicker, Sortable, conjunto.js                  | App pages only     |
| **Feature scripts** | dropzone, chart.js, fslightbox (and their CSS where needed)   | On demand          |

Core scripts are required everywhere (including public/marketing pages).
App scripts are added by `app_base.html` and provide the interactive
features of the authenticated application shell. Feature scripts are
registered on the fly by individual templates and rendered once at the
bottom of the page.

---

## Template Tags Reference

All tags live in the `conjunto` template tag library:

```django
{% load conjunto %}
```

| Tag                              | Purpose                                        | Loaded on      |
|----------------------------------|-------------------------------------------------|----------------|
| `{% conjunto_css %}`             | Core CSS (Tabler, Tabler Icons, conjunto.css)  | Every page     |
| `{% conjunto_core_scripts %}`    | htmx, tabler.js, toasts.js + tabler-theme (no defer) | Every page |
| `{% conjunto_app_scripts %}`     | Alpine.js, Litepicker, Sortable, conjunto.js   | App pages only |
| `{% conjunto_require_dropzone %}`| Registers dropzone.js + dropzone.css           | On demand      |
| `{% conjunto_require_chart %}`   | Registers chart.min.js                         | On demand      |
| `{% conjunto_require_fslightbox %}`| Registers fslightbox.js                      | On demand      |
| `{% conjunto_require_tinymce %}` | Registers TinyMCE v7 CE (self-hosted, GPLv2)   | On demand      |
| `{% conjunto_render_scripts %}`  | Renders all registered feature scripts/CSS     | Once in base.html |

---

## Template Block Hierarchy

The script-related blocks in `base.html` are arranged like this:

```
conjunto_core_scripts        <-- always loaded (not a block, called directly)
{% block app_scripts %}      <-- filled by app_base.html
{% block feature_scripts %}  <-- renders conjunto_render_scripts
{% block scripts %}          <-- for child templates
```

This ordering guarantees that core scripts are available first, then
app-level scripts, then any feature scripts registered during template
rendering, and finally any ad-hoc scripts added by child templates.

---

## How It Works

1. **`base.html`** calls `{% conjunto_core_scripts %}` directly (no
   block wrapper) and defines the three blocks `app_scripts`,
   `feature_scripts` and `scripts`.

2. **`app_base.html`** fills the `app_scripts` block with
   `{{ block.super }}` + `{% conjunto_app_scripts %}`, so app pages
   get both core and app scripts automatically.

3. **Feature scripts** work through a request-scoped registry:
      - `ScriptRegistryMiddleware` attaches a `ScriptRegistry` instance
        to `request.cj_scripts` at the start of every request.
      - Any template code can call `{% conjunto_require_dropzone %}` (or
        `_chart`, `_fslightbox`) to register a script. Views can also
        call `request.cj_scripts.add(path)` or
        `request.cj_scripts.add_css(path)` directly in Python.
      - At the bottom of `base.html`, `{% conjunto_render_scripts %}`
        emits all collected `<script>` and `<link>` tags, deduplicated
        and in insertion order.

!!! note
    The registry deduplicates automatically. Calling
    `{% conjunto_require_chart %}` from multiple included templates
    will still produce only a single `<script>` tag.

---

## Setup

Add `ScriptRegistryMiddleware` to your `MIDDLEWARE` setting. It must
run **before** any view middleware that might register scripts:

```python
MIDDLEWARE = [
    # ...
    "conjunto.middleware.ConjuntoMiddleware",
    "conjunto.middleware.ScriptRegistryMiddleware",
    # ...
]
```

!!! warning
    Without `ScriptRegistryMiddleware` the `{% conjunto_require_* %}`
    tags will silently do nothing, because `request.cj_scripts` will
    not exist.

---

## Examples

### Feature script in a template

```django
{% load conjunto %}

{% conjunto_require_chart %}

{# ... later in the template ... #}
<canvas id="my-chart"></canvas>
```

The `chart.min.js` script tag will be rendered by
`{% conjunto_render_scripts %}` in `base.html` — no need to touch
the `scripts` block.

### Public page (Core only)

```django
{% extends "conjunto/base.html" %}
{% load i18n %}

{% block title %}{% trans "Welcome" %}{% endblock %}

{% block body %}
  <h1>{% trans "Hello, world!" %}</h1>
{% endblock %}

{# Only htmx + tabler + toasts loaded -- no Alpine, Sortable etc. #}
```

### App page (Core + App)

```django
{% extends "conjunto/app_base.html" %}
{% load i18n %}

{% block title %}{% trans "Dashboard" %}{% endblock %}
{% block page_title %}{% trans "Dashboard" %}{% endblock %}

{% block content %}
  <p>{% trans "Core + App scripts loaded automatically." %}</p>
{% endblock %}
```

### Registering scripts from a view

```python
def my_view(request):
    # Register a feature script from Python code
    request.cj_scripts.add("myapp/js/fancy-widget.js")
    request.cj_scripts.add_css("myapp/css/fancy-widget.css")
    return render(request, "myapp/fancy.html")
```
