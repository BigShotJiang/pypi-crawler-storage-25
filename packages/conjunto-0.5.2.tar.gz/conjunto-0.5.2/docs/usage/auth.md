# Authentication & login

Conjunto ships its own login flow built on top of Django's stock
auth. Three pieces work together:

1. **`ConjuntoAuthenticationForm`** — extends Django's
   `AuthenticationForm` with a conditional Remember-Me checkbox.
2. **`ConjuntoLoginView` / `ConjuntoLoginCompleteView`** — HTMX-aware
   login views with optional two-step tenant pick (see
   [`tenants.md`](tenants.md)).
3. **`ILoginViewExtension`** and **`IPostLoginAction`** — GDAPS hooks
   that let plugins react to a successful login (audit-log entries,
   one-shot post-login modals, …) without subclassing the form or
   view. The credentials form itself is **not** plugin-extendable on
   purpose: cross-cutting concerns belong outside the pre-auth form.

Wire them up from a consumer project::

```python
# myproject/urls.py
from django.urls import include, path

urlpatterns = [
    path("accounts/", include("conjunto.auth.urls")),     # login, login-complete
    path("accounts/", include("django.contrib.auth.urls")),  # logout, password reset
    ...
]
```

## Remember-Me checkbox

The form renders a "Remember me on this device" checkbox iff the
`auth.show_remember_me` scoped setting is truthy (default: `True`,
writable + lockable for VENDOR and TENANT).

| Setting          | Lifetime applied                       |
|------------------|----------------------------------------|
| Hidden (`False`) | always `auth.session_lifetime_default` |
| Visible, checked | `auth.session_lifetime_remembered`     |
| Visible, unchecked | `auth.session_lifetime_default`      |

The view consumes the value through `form.get_remember_me()`, which
returns `False` whenever the checkbox is hidden — even if the POST body
still contains `remember_me=on`. There is no way for a user to opt into
a longer-lived session against a vendor lock.

To hide the checkbox site-wide:

```python
from conjunto.settings.scoped.models import Scope, ScopedSetting

ScopedSetting.objects.update_or_create(
    namespace="auth", key="show_remember_me",
    scope=Scope.VENDOR,
    defaults={"value": False, "locked": True},
)
```

## Why the credentials form is not plugin-extendable

It is tempting to let plugins inject extra fields into the login form
(e.g. a time-tracker "kommen / gehen" toggle). Conjunto deliberately
does *not* offer a hook for this:

- The pre-auth form runs on an anonymous request. Extra fields
  broaden the attack surface without adding security value.
- HTMX validation round-trips with extra fields tend to leak
  plugin-specific UI state into the credentials path.
- The natural place for "after login, do X" logic is *after* the
  user is authenticated.

Use one of these instead:

- **`ILoginViewExtension`** — react to a successful login (write an
  audit-log entry, prefetch caches, record a check-in). See below.
- **`IPostLoginAction`** — render a one-shot HTMX trigger on the next
  authenticated page load (e.g. open a "do you want to check in?"
  modal). Implementations live alongside `IMenuItem` and friends and
  are rendered via `{% render_plugins "IPostLoginAction" %}` in the
  base template (only for authenticated users).

## `ILoginViewExtension` — reacting to a successful login

Use this to record check-ins, write audit-log entries, prefetch
caches, etc.

```python
from conjunto.api.interfaces import ILoginViewExtension
from conjunto.audit_log import log_action


class TimetrackerCheckinHook(ILoginViewExtension):
    @classmethod
    def form_valid(cls, view, request, user, form):
        # ``form`` is the bound credentials form on the classic path.
        # On the two-step tenant-pick path it is ``None`` because the
        # original credentials form is no longer available — extensions
        # that need data from the credentials POST must stash it
        # themselves (e.g. via ``request.session``).
        log_action("user.login", request, user=user)

    @classmethod
    def alter_context_data(cls, view, context):
        context["something_for_template"] = ...
```

Hook lifecycle:

| Path                     | When `form_valid` fires                    | `form` argument     |
|--------------------------|--------------------------------------------|---------------------|
| 0 or 1 accessible tenant | After `login()`, before redirect           | bound form          |
| 2+ accessible tenants    | After `login()` in `LoginCompleteView`     | `None` (see note)   |

Hooks must catch their own non-fatal errors. Anything they raise
propagates and breaks the login.

## Default form behaviour

With `auth.show_remember_me=True` the form renders three fields:
`username`, `password`, `remember_me`. The credentials POST takes the
same path as Django's default `LoginView`, plus the conjunto-specific
tenant pick when applicable.

## Things to keep in mind

- `helper.form_tag = False` and `helper.disable_csrf = True` are
  intentional — the `<form>` tag, CSRF token, and submit button are
  owned by `_login_card.html`. A custom `AUTH_FORM` subclass must
  not introduce its own `Card(...)` or `<form>` wrapper.
- Setting names: scoped settings under the `auth` namespace are
  reserved for login/auth concerns — that includes the Remember-Me
  toggle and the session-lifetime keys (`auth.session_lifetime_default`,
  `auth.session_lifetime_remembered`). These keys used to live under
  `conjunto.*`; the migration in `conjunto_settings/0008_*` rewrites
  existing DB rows on upgrade.
- This module does not (yet) provide OAuth, OIDC, or token-link
  authentication. For those, use the `ILoginMethod` interface to
  contribute alternative buttons on the login page and dispatch to a
  provider-specific URL.
