# Static Libraries — `manage.py update_libraries`

Conjunto's third-party JavaScript and CSS libraries (TinyMCE, Tabler,
HTMX, Alpine, Chart.js, …) are **not** bundled into the conjunto
wheel. Each consumer project fetches just the libraries it actually
uses into its own static directory via the
`update_libraries` management command.

## Why?

- **Wheel size.** Bundling everything pushed the wheel to ~16 MB —
  ~95 % of which is third-party assets. Pulling them out drops the
  wheel to ~300 KB.
- **Selective install.** A medux-style backoffice app needs HTMX +
  Tabler. A medspeak-style content site additionally wants TinyMCE +
  Chart.js. Shipping all of it everywhere is wasteful.
- **Auditability.** A positive whitelist in `pyproject.toml` makes it
  obvious which files are first-party (authored in this repo) vs.
  fetched from upstream registries.
- **Zero-Trust + GDPR Art. 44 ff.** All assets are still self-hosted
  (no CDN at runtime) — only the *download time* hits an external
  registry.

## Project layout

The recommended layout — and the one used by every nerdocs consumer —
keeps vendored libraries in a dedicated `static-vendored/` directory,
gitignored as a whole:

```
BASE_DIR/
  static/                    # first-party app assets (in git)
    medspeak/...
    cms/...
  static-vendored/           # auto-generated, NOT in git
    conjunto/
      tinymce/
      js/htmx/...
      css/tabler.min.css
      ...
  staticfiles/               # collectstatic output, NOT in git
```

This keeps `static/` clean for app-owned assets and lets you
`rm -rf static-vendored/` without losing anything you wrote yourself.

## Settings

Add to your project's `settings.py`:

```python
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STATICFILES_DIRS = [
    BASE_DIR / "static",
    BASE_DIR / "static-vendored",
]

# Where update_libraries writes. Defaults to STATICFILES_DIRS[0]/conjunto
# when unset, but being explicit makes the layout self-documenting.
CONJUNTO_VENDOR_DIR = BASE_DIR / "static-vendored" / "conjunto"

# Which libraries to fetch. Run `manage.py update_libraries --suggest`
# once to get a tailored list based on your templates.
CONJUNTO_LIBRARIES = [
    "htmx",
    "tabler",
    # "alpine", "litepicker", "sortable",  # add for `conjunto/app_base.html`
    # "tinymce", "tinymce-i18n",            # add for rich-text editing
    # "chartjs",                            # add for `{% conjunto_require_chart %}`
]
```

Add to `.gitignore`:

```
/staticfiles/
/static-vendored/
```

## First run / bootstrapping a project

```bash
# 1. Get a tailored list from your templates.
$ python manage.py update_libraries --suggest
Detected libraries from your templates:

    CONJUNTO_LIBRARIES = [
        "chartjs",
        "htmx",
        "tabler",
        "tinymce",
        "tinymce-i18n",
    ]

Copy the block above into settings.py.

# 2. Paste the block into settings.py, then:
$ python manage.py update_libraries
[htmx]
  js/htmx/htmx.js  <-  https://unpkg.com/htmx.org@latest/dist/htmx.js
  ...
[tabler]
  ...
[tinymce]
  tarball  <-  https://registry.npmjs.org/tinymce/-/tinymce-7.9.2.tgz
  extracted 1267 files into …/static-vendored/conjunto/tinymce
[tinymce-i18n]
  tarball  <-  https://registry.npmjs.org/tinymce-i18n/-/tinymce-i18n-26.4.6.tgz
  extracted 70 files into …/static-vendored/conjunto/tinymce
[chartjs]
  ...

# 3. Check that everything is in place.
$ python manage.py update_libraries --check
[htmx] OK
[tabler] OK
[chartjs] OK
[tinymce] OK
[tinymce-i18n] OK

# 4. Now run the rest of the bootstrap.
$ python manage.py migrate
$ python manage.py collectstatic --noinput
$ python manage.py runserver
```

## Command reference

| Invocation | Effect |
|---|---|
| `update_libraries` | Download every library in `CONJUNTO_LIBRARIES` (or core `[htmx, tabler]` if unset). Skips libs already present unless `--force` is given. Always prints a `--suggest`-diff at the end so out-of-sync settings surface immediately. |
| `update_libraries tinymce tabler` | Download exactly these libraries — overrides `CONJUNTO_LIBRARIES`. |
| `update_libraries --all` | Download every library known to the registry. Useful for testing. |
| `update_libraries --list` | Print the registry (name + kind). |
| `update_libraries --suggest` | Scan project templates for `{% conjunto_require_X %}` and `{% static "conjunto/..." %}` references; print a ready-to-paste `CONJUNTO_LIBRARIES = [...]` block. Does **not** download. |
| `update_libraries --check` | No-network presence check. Exits 1 if any expected file is missing. Use this in CI before `collectstatic`. |
| `update_libraries --force` | Re-download even when files already exist. |
| `update_libraries --dest <path>` | Override `CONJUNTO_VENDOR_DIR` for one run. |

## Library inventory

| Name | Kind | Used for |
|---|---|---|
| `htmx` | files | Core: every page (`CORE_JS`). |
| `tabler` | files | Core: every page (CSS + JS + icon webfont). |
| `alpine` | files | Authenticated app layout (`conjunto/app_base.html`). |
| `litepicker` | files | Authenticated app layout (date picker widgets). |
| `sortable` | files | Authenticated app layout (drag-drop ordering). |
| `chartjs` | files | Triggered by `{% conjunto_require_chart %}`. |
| `dropzone` | files | Triggered by `{% conjunto_require_dropzone %}`. |
| `fslightbox` | files | Triggered by `{% conjunto_require_fslightbox %}`. |
| `tinymce` | tarball | Triggered by `{% conjunto_require_tinymce %}`. **GPLv2-or-later.** |
| `tinymce-i18n` | tarball | Language packs for TinyMCE (auto-paired). |

The `tabler` entry pulls Bootstrap 5, Tabler core CSS/JS, and the
Tabler-Icons webfont — i.e. everything `{% conjunto_css %}` and
`{% conjunto_core_scripts %}` reference.

## CI / deployment

Run `update_libraries` **before** `collectstatic` in every deploy
path. Two examples:

### Makefile

```make
staticfiles:
    cd src && python manage.py update_libraries
    cd src && python manage.py collectstatic --noinput
```

### Ansible

```yaml
- name: Download conjunto-managed JS/CSS libraries
  command: "{{ venv_python }} manage.py update_libraries"
  args:
    chdir: "{{ django_project_path }}"

- name: Collect Django's staticfiles
  command: "{{ venv_python }} manage.py collectstatic --noinput"
  args:
    chdir: "{{ django_project_path }}"
```

For air-gapped environments, run `update_libraries --all` once in a
network-attached build agent and ship the resulting
`static-vendored/conjunto/` tree as a build artefact alongside the
wheel.

## Diagnostics

When `CONJUNTO_LIBRARIES` is set but libraries are missing on disk,
`python manage.py check` reports `conjunto.W002` with a list of
missing files and the exact fix command. The same check fires at
process start (`runserver`/WSGI) so you get a single warning during
local dev too. The check is intentionally suppressed during
`update_libraries`, `migrate`, `makemigrations`, `collectstatic`,
`compilemessages`, `makemessages`, and `test` so the very command
that *fixes* the warning isn't blocked by it.

## TinyMCE — GPLv2 obligation

TinyMCE Community Edition is GPLv2-or-later. Conjunto's downloader
keeps `LICENSE.TXT`, `README.md`, `CHANGELOG.md` and `package.json`
alongside the editor JS so the GPLv2 distribution obligation is
satisfied wherever the assets land. Don't strip those files when
configuring your CDN/edge cache.
