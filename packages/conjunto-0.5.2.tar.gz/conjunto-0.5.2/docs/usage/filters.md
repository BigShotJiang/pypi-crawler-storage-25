# Filters

Conjunto provides a small, declarative Filter API for
[`TableListView`](tables.md) pages. A `Filter` describes one filter
widget in the table's card header: which GET parameter it binds to,
which template renders the widget, and how a chosen value is applied
to the queryset.

Filters live in `conjunto.filters`:

| Class | Use case |
|---|---|
| `Filter` | Base class — plain `qs.filter(name=value)` for truthy values. |
| `ChoiceFilter` | Single-select dropdown with explicit choices. |
| `BooleanFilter` | Three-way dropdown (all / yes / no). |

For complex cases (ranges, dates, multi-select, dependent filters)
use `filterset_class` instead — see "django-filter integration"
below.

## Purpose and scope

The Filter API is deliberately small. It covers the 80 % case of a
typical admin list page: a handful of dropdowns that map to exact
equality lookups on model fields.

If you need:

- range (`__gte` / `__lte`), icontains, in-list;
- datepickers or chained filters;
- multiple filterable fields off a single queryset annotation;

then reach for [`django-filter`](https://django-filter.readthedocs.io/)
and set `filterset_class` on the view.

## `Filter` (base class)

Applies `qs.filter(<name>=<value>)` for truthy values and renders a
plain `<select>` widget. Used as-is if you have a small, fixed set
of values and just need a simple equality match.

```python
from conjunto.filters import Filter

Filter(
    name="status",          # GET parameter and ORM keyword
    label="Status",         # human-readable label (i18n-friendly)
    empty_label="—",        # rendered as the "no filter" option
    widget_template="conjunto/filters/_select.html",  # override for custom widget
)
```

`Filter.iter_choices()` returns an empty iterable by default — you
would typically override `widget_template` when using the base class
directly, since the default select has no options to render.

## `ChoiceFilter`

Single-select filter with a fixed list of choices:

```python
from conjunto.filters import ChoiceFilter
from django.utils.translation import gettext_lazy as _

ChoiceFilter(
    name="status",
    label=_("Status"),
    empty_label=_("All statuses"),
    choices=[
        ("open", _("Open")),
        ("closed", _("Closed")),
        ("archived", _("Archived")),
    ],
)
```

The rendered `<select>` starts with an "all" option (blank value,
`empty_label`) and then the supplied choices. Selecting a value
maps directly to `qs.filter(status=value)`.

You can also use a model's `TextChoices` / `IntegerChoices`:

```python
ChoiceFilter("status", label=_("Status"), choices=Project.Status.choices)
```

## `BooleanFilter`

Three-way filter (all / true / false):

```python
from conjunto.filters import BooleanFilter

BooleanFilter(
    name="is_archived",
    label=_("Archived"),
    true_label=_("Archived"),
    false_label=_("Active"),
)
```

GET values:

- `?is_archived=1` → `qs.filter(is_archived=True)`
- `?is_archived=0` → `qs.filter(is_archived=False)`
- anything else / missing → queryset unchanged

## Using filters on a view

Declare a list of filter instances on the view:

```python
from conjunto.views import TableListView
from conjunto.filters import ChoiceFilter, BooleanFilter

class ProjectListView(TableListView):
    model = Project
    table_class = ProjectTable
    template_name = "projects/project_list.html"
    filters = [
        ChoiceFilter("status", label=_("Status"),
                     choices=Project.Status.choices),
        BooleanFilter("is_archived", label=_("Archived")),
    ]
```

`TableListView.get_queryset()` calls `apply_filters()` which walks
the `filters` list and invokes `Filter.apply(qs, value)` for each
filter where a GET parameter is present.

The view also exposes the current values to the template via
`filter_values` (a `{name: value}` dict), so that
`conjunto/tables/list_card.html` can pre-select each dropdown.

## Rendering

By default each filter is rendered by
`conjunto/filters/_select.html`, a simple Tabler-styled `<select>`
wired up with HTMX to trigger a list refresh on change:

```django
{% load i18n %}
<select name="{{ filter.name }}"
        class="form-select"
        hx-trigger="change"
        hx-get="{{ request.path }}"
        hx-target="closest .list-card"
        hx-select="#{{ table.wrapper_id }}"
        hx-swap="outerHTML"
        hx-include="closest .list-card [name]"
        hx-push-url="true">
  {% for value, label in filter.iter_choices %}
    <option value="{{ value }}"{% if value == current_value %} selected{% endif %}>{{ label }}</option>
  {% endfor %}
</select>
```

Change the widget per filter:

```python
filters = [
    ChoiceFilter(
        "status",
        label=_("Status"),
        choices=Project.Status.choices,
        widget_template="projects/filters/_status_pills.html",
    ),
]
```

The widget template receives these context variables:

- `filter` — the `Filter` instance (use `filter.name`, `filter.label`,
  `filter.iter_choices`).
- `current_value` — the currently selected value (or empty string).
- `table` — the table instance, so you can target
  `#{{ table.wrapper_id }}`.
- `request` — the current request.

## Writing a custom filter

Subclass `Filter` and override `apply` (and optionally
`iter_choices`):

```python
from dataclasses import dataclass
from conjunto.filters import Filter


@dataclass
class SinceFilter(Filter):
    """Filter `created_at >= today - N days`."""

    widget_template: str = "my_app/filters/_since.html"

    def apply(self, qs, value):
        if not value:
            return qs
        try:
            days = int(value)
        except (TypeError, ValueError):
            return qs
        from datetime import timedelta
        from django.utils import timezone
        cutoff = timezone.now() - timedelta(days=days)
        return qs.filter(**{f"{self.name}__gte": cutoff})
```

## django-filter integration

For anything beyond the built-in filters, set `filterset_class` on
the view — `TableListView` hands the queryset off to
`django-filter` and ignores `filters`:

```python
import django_filters

class ProjectFilterSet(django_filters.FilterSet):
    created_after = django_filters.DateFilter(
        field_name="created_at", lookup_expr="gte")
    status = django_filters.ChoiceFilter(choices=Project.Status.choices)

    class Meta:
        model = Project
        fields = ["status", "created_after"]


class ProjectListView(TableListView):
    model = Project
    table_class = ProjectTable
    filterset_class = ProjectFilterSet
```

When `filterset_class` is set, `filters` is ignored — render the
filterset yourself in the `filters` block of `list_card.html` or in
a custom template.
