# Settings

Conjunto's settings subsystem is a **scope-based overlay** system:
every setting is stored as one or more rows in a single `ScopedSetting`
table, and the effective value for a request is the overlay of all
rows matching that request along the priority chain

```
USER > DEVICE > GROUP > TENANT > VENDOR
```

Higher priority wins in the normal walk. A per-row **lock** flag
short-circuits the walk: a locked row acts as a "floor" no higher
scope can dig under. When multiple locks exist, the **lowest-priority**
lock wins — a VENDOR lock is the ultimate authority; a TENANT lock
beats GROUP/DEVICE/USER but yields to a VENDOR lock.

The old per-site `AbstractSettings` singleton is gone.
`SETTINGS_MODEL`, `request.app_settings`, and subclassing
`AbstractSettings` are no longer part of conjunto.

## The five scopes

| Scope    | Priority | Ref FK               | Applies when                                 |
|----------|----------|----------------------|----------------------------------------------|
| `VENDOR` | lowest   | *(none)*             | Always                                        |
| `TENANT` |          | Swappable Tenant     | A tenant resolver returns a pk (see below)    |
| `GROUP`  |          | `auth.Group`         | User is authenticated and in one or more groups |
| `DEVICE` |          | `conjunto.Device`    | `ConjuntoMiddleware` resolved a device cookie |
| `USER`   | highest  | `AUTH_USER_MODEL`    | User is authenticated                         |

**Site** is an orthogonal filter, not a sixth scope. Every
`ScopedSetting` row optionally points at a
`django.contrib.sites.Site`. Queries match `site = request.site OR site
IS NULL`. Within a tier, a site-specific row beats a site-null row.

## Registering a setting

Every `(namespace, key)` pair that your app exposes must be declared
in a `scoped_settings.py` module at the top level of the app.
`ConjuntoMiddleware`'s `ready()` auto-discovers these modules across
all installed apps on startup.

```python
# myapp/scoped_settings.py
from conjunto.settings.scoped.models import Scope
from conjunto.settings.scoped.registry import SettingRegistry

SettingRegistry.register(
    "myapp",
    "email_digest",
    type="bool",
    default=True,
    help_text="Whether the user receives a weekly digest email.",
    icon="mail",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)
```

The spec fields:

- `type` — one of `"str"`, `"int"`, `"bool"`, `"text"`, `"json"`.
  Advisory: the storage is a `JSONField` that accepts native Python
  types directly; `type` is hinted to the UI.
- `default` — returned by the resolver when no row matches.
- `writable_scopes` — scopes where rows for this key may be written.
- `lockable_scopes` — subset of `writable_scopes` where `locked=True`
  is permitted. Typical pattern: VENDOR and TENANT can lock user
  settings against self-override; a user cannot self-lock.
- `ui_widget` — optional hint string for a custom form widget.

The registry is **frozen** on first read. Registrations after startup
raise `RuntimeError`. Tests use
`conjunto.settings.scoped.testing.unfreeze_registry()` as a context
manager to snapshot/restore the registry.

## Reading a setting

On every request, `ConjuntoMiddleware` attaches a
`ScopedSettingsProxy` at `request.scoped_settings`. Two API surfaces:

**Python / view code — strict mode (recommended):**

```python
value = request.scoped_settings.get("myapp", "email_digest")
```

Raises `KeyError` if the spec isn't registered.

**Python / view code — lenient mode:**

```python
value = request.scoped_settings.get("myapp", "email_digest", default=True)
```

Returns the provided default on missing spec.

**Template code:**

```django
{{ request.scoped_settings.myapp.email_digest }}
```

Missing keys render as empty string (template-friendly). The cache
ensures at most one DB query per `(namespace, key)` per request.

## Writing a setting

There is no `SettingRegistry.set()` — values are rows in the
`ScopedSetting` table and are written through normal Django ORM calls.
Permission gating is the responsibility of the caller:

```python
from conjunto.settings.scoped.models import Scope, ScopedSetting
from conjunto.settings.scoped.scopes import IUserScope

def save_user_email_digest(request, enabled: bool):
    if not IUserScope.can_edit(request, request.user.pk):
        raise PermissionDenied
    ScopedSetting.objects.update_or_create(
        namespace="myapp",
        key="email_digest",
        scope=Scope.USER,
        user=request.user,
        site=request.site if request.site_id else None,
        defaults={"value": enabled},
    )
    request.scoped_settings.invalidate("myapp", "email_digest")
```

Remember to invalidate the per-request cache if the write is followed
by a same-request read.

## Tenant resolution

Tenant scope is special because conjunto ships a default `Tenant`
model but doesn't impose tenant routing. `ITenantScope.resolve(request)`
tries three sources in order:

1. `request.tenant` if a consumer middleware populated it (subdomain
   routing pattern).
2. `request.user.tenant_id` if the consumer's user model has a
   `tenant` FK (simplest pattern).
3. `request.session["cj_tenant_id"]` for session-selected tenants.

If none yield a pk, tenant scope is skipped for this request.

See `docs/usage/tenants.md` for the full Tenant model reference.

## Device identification

The `Device` model is conjunto's anchor for DEVICE-scoped settings.
Identification is a long-lived `cj_device_id` UUID cookie (10-year
max-age, HttpOnly, SameSite=Lax) created by `ConjuntoMiddleware` on
first visit. The cookie **does** survive logout; binding to a user
happens lazily on the first authenticated request. Once bound, the
device is **never rebound** across users — a different user logging
in on the same browser creates a new Device row.

**GDPR note.** The `cj_device_id` cookie is a durable tracking
identifier. Consumer apps subject to GDPR must disclose it in their
cookie banner / records of processing.

## Login / session settings

Two scoped settings drive the session lifetime chosen by the
"Remember me" checkbox on the default login page
(`registration/login.html`):

| Key                                    | Type  | Default              | Scopes           | Meaning                                                                 |
|----------------------------------------|-------|----------------------|------------------|-------------------------------------------------------------------------|
| `auth.session_lifetime_default`        | `int` | `0` (browser)        | `VENDOR, TENANT` | Session expiry in seconds when *Remember me* is **not** checked.        |
| `auth.session_lifetime_remembered`     | `int` | `2592000` (30 days)  | `VENDOR, TENANT` | Session expiry in seconds when *Remember me* **is** checked.            |
| `auth.show_remember_me`                | `bool`| `True`               | `VENDOR, TENANT` | Show the Remember-Me checkbox on the login page (see `auth.md`).        |

A value of `0` means the session expires when the browser closes
(`request.session.set_expiry(0)`). Any positive value is an absolute
expiry in seconds. Defaults can be overridden per deployment with the
Django settings `CONJUNTO_SESSION_LIFETIME_DEFAULT` and
`CONJUNTO_SESSION_LIFETIME_REMEMBERED`.

Consuming the settings is the job of the login view. MedUX's
`LoginView` reads `remember_me` from the POST data and calls
`request.session.set_expiry(...)` with the matching key. Projects that
ship their own `LoginView` should do the same.

## Per-user timezone — `conjunto.timezone` + `TimezoneMiddleware`

Conjunto ships a scoped setting plus a middleware that lets users (or
tenants, or the deployment) pin a preferred IANA timezone. With
`USE_TZ=True` Django stores every datetime as UTC; the active timezone
during rendering decides what the user actually sees.

| Key                  | Type  | Default | Scopes                        | Meaning                                                                |
|----------------------|-------|---------|-------------------------------|------------------------------------------------------------------------|
| `conjunto.timezone`  | `str` | `""`    | `VENDOR, TENANT, USER` (lockable `VENDOR, TENANT`) | IANA name (e.g. `"Europe/Vienna"`); empty falls back to `settings.TIME_ZONE`. |

`conjunto.middleware.TimezoneMiddleware` activates the resolved value
per request via `django.utils.timezone.activate(zoneinfo.ZoneInfo(...))`
and `deactivate`s it in a `finally` block so per-thread state never
leaks across requests. Empty values and unknown IANA names fall through
silently to Django's default zone.

**Wiring:**

```python
# settings.py
MIDDLEWARE = [
    # ...
    "conjunto.middleware.ConjuntoMiddleware",
    "conjunto.middleware.TimezoneMiddleware",  # must run AFTER ConjuntoMiddleware
    # ...
]
```

**Settings UI:** consumer projects expose the key with a small
`ISettingsForm` plugin under their localising / preferences section:

```python
import zoneinfo
from django import forms
from django.utils.translation import gettext_lazy as _
from conjunto.settings.interfaces import ISettingsForm
from conjunto.settings.scoped.models import Scope, ScopedSetting


class TimezoneForm(forms.Form):
    timezone = forms.ChoiceField(label=_("Timezone"), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["timezone"].choices = [
            ("", _("Use deployment default")),
            *((z, z) for z in sorted(zoneinfo.available_timezones())),
        ]


class TimezoneFormPlugin(ISettingsForm):
    name = "timezone"
    section = MyLocalizingSection
    title = _("Timezone")
    weight = 0
    form_class = TimezoneForm

    def get_initial(self, request) -> dict:
        return {"timezone": request.scoped_settings.get("conjunto", "timezone")}

    def save(self, form, request) -> None:
        ScopedSetting.objects.update_or_create(
            namespace="conjunto", key="timezone",
            scope=Scope.USER, user=request.user,
            defaults={"value": form.cleaned_data.get("timezone", "") or ""},
        )
        request.scoped_settings.invalidate("conjunto", "timezone")
```

**Templates:** even with the middleware activated, render datetime
values explicitly through the `|localtime` filter before `|date`/`|time`
formatting (`{% load tz %}` once per template). This makes the intent
obvious in the source and keeps the templates correct under
`USE_TZ=False` deployments. The active zone for the current request is
available as `{% get_current_timezone as TIME_ZONE %}` for display.

**Full-reload after save** (`requires_full_reload`). Theme/layout-bound
settings — color scheme, layout style, sidebar width, topbar position,
language, timezone — touch many DOM nodes (Tabler hangs the active
theme on `data-bs-theme`, the `theme-dark` class, sidebar variant,
charts, code highlight, plus the `localStorage["tabler-theme"]` cache
its early-paint script reads). Re-applying every surface live is
brittle and racy.

Opt the form into a deterministic full reload:

```python
class TimezoneFormPlugin(ISettingsForm):
    name = "timezone"
    section = MyLocalizingSection
    form_class = TimezoneForm
    requires_full_reload = True   # opt-in
    # ...
```

`SettingsFormView.form_valid` then sets `HX-Refresh: true` on the 204
response **after** `plugin.save(...)` has persisted the value. HTMX
fires any `HX-Trigger` events first (so an `extra_success_triggers`
hook still runs — useful e.g. for syncing
`localStorage["tabler-theme"]` before the reload), then calls
`location.reload()`.

## Pluggable login methods — `ILoginMethod`

Additional sign-in entry points (social providers, SSO, WebAuthn, magic
link, …) plug into the login page via the `ILoginMethod` GDAPS
interface. Each implementation becomes a button in the
`login_alternative_methods` block of `registration/login.html` (see
[Template blocks](template_blocks.md)).

```python
from conjunto.api.interfaces import ILoginMethod

class GoogleLogin(ILoginMethod):
    name = "google"
    label = "Google"
    icon = "brand-google"
    url = "/accounts/google/login/"
    weight = 10
```

Attributes:

| Attribute       | Type   | Purpose                                                                 |
|-----------------|--------|-------------------------------------------------------------------------|
| `name`          | `str`  | Unique identifier. Rendered as `data-login-method` on the button.       |
| `label`         | `str`  | Human-readable, translatable button label.                              |
| `icon`          | `str`  | Tabler icon name without the `ti ti-` prefix (e.g. `brand-google`).     |
| `url`           | `str`  | Target URL — typically the provider's authorization flow start.         |
| `weight`        | `int`  | Sort weight; higher values sink the button further down.                |
| `template_name` | `str`  | Optional custom template rendered with `{"method": cls, "request": …}`. |

Optional hooks:

- `is_enabled(cls, request) -> bool` — gate the method on feature
  flags, tenant settings or device capability.
- `render(cls, request) -> str` — return a fully custom HTML snippet;
  takes precedence over the default button markup when it returns a
  non-empty string.

The `login_methods` template tag (in the `conjunto` library) is what
the shipped `registration/login.html` uses internally to iterate
enabled implementations; no extra wiring is required.

## Admin UI

Conjunto ships read/write Django admin pages for `ScopedSetting`,
`Device`, and `Tenant`. They are the operator's emergency-access view
onto the data; the per-scope-tabbed editor UI on the `/settings/` page
is a follow-up feature (not in v1).

## Related docs

- `docs/usage/tenants.md` — Tenant model and the swappable
  `CONJUNTO_TENANT_MODEL` pattern.
- `docs/usage/maintenance_mode.md` — maintenance-mode flow, now driven
  by the `conjunto.maintenance_mode` VENDOR-scoped setting.
- `docs/usage/layout.md` — how the layout keys (`layout_style`,
  `topbar_fixed`, `sidebar_width`) hook into the context processor.
