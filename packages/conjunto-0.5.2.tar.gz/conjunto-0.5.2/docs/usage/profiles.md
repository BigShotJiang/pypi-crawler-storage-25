# User profiles

Conjunto never owns the user model — projects use Django's `AUTH_USER_MODEL`
or swap in their own. To attach user-scoped metadata (today: an avatar;
tomorrow: timezone, display name, …) without touching the user model,
`conjunto.profiles` follows the classic Django profile pattern: a
separate `UserProfile` model with a `OneToOneField` to
`settings.AUTH_USER_MODEL`.

A `post_save` signal auto-creates the companion row for every new user,
so call sites can rely on `user.profile` being present.

## Installation

Add the app to `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    # …
    "conjunto",
    "conjunto.profiles",
    # …
]
```

Then run migrations. For users that existed before the profile
migration, call `UserProfile.get_or_create_for(user)` on demand — the
template tag already does this safely.

## The `UserProfile` model

```python
from conjunto.profiles.models import UserProfile

profile = user.profile                       # attribute access via reverse OneToOne
profile = UserProfile.get_or_create_for(user)  # safe for pre-migration users

profile.avatar                               # ImageField, may be empty
profile.avatar_url                           # URL string or None
```

Uploaded files are stored under `MEDIA_ROOT/avatars/<user_pk>/<uuid>.<ext>`
— namespaced per user with a randomised basename so successive uploads
don't collide and the original client filename isn't leaked.

## The `{% avatar %}` template tag

The tag ships in the **core** conjunto app, not in `conjunto.profiles`.
That way `{% load avatar %}` always succeeds — even when a project
hasn't opted into the profiles app yet. When `conjunto.profiles` *is*
installed, the tag resolves the stored avatar image; otherwise it
always falls back to initials.

```django
{% load avatar %}

{# Current user (from context.user or request.user). #}
{% avatar %}

{# Explicit user. #}
{% avatar some_user %}

{# Sized, with extra classes. #}
{% avatar some_user size="xs" extra_classes="me-2" %}
```

Behaviour:

- When the user has an avatar: renders a Tabler `.avatar` span with the
  image as `background-image`.
- Otherwise: renders the same span with uppercase initials as text
  content. Initials come from `first_name` + `last_name`, falling back
  to `get_full_name`, then the first two characters of `username`, then
  `email`, finally `?`.
- Anonymous or `None` users render as `?`.
- Never raises — safe to drop anywhere.

### Size aliases

| `size`  | Class       |
|---------|-------------|
| `xs`    | `avatar-xs` |
| `sm`    | `avatar-sm` |
| `md`    | *(default)* |
| `lg`    | `avatar-lg` |
| `xl`    | `avatar-xl` |
| `2xl`   | `avatar-2xl`|

Unknown strings pass through unchanged, so `size="avatar-xl rounded"`
also works for one-off combinations.

## Settings page integration

`conjunto.profiles` contributes an **Avatar** subsection to the built-in
`User → Profile` section (see `docs/usage/settings.md`). The subsection
uses its own template with `hx-encoding="multipart/form-data"` so the
file upload is posted correctly over HTMX.

## Initials helper

If you need the initials logic outside a template:

```python
from conjunto.profiles.utils import compute_initials

compute_initials(user)          # "AC"
compute_initials(user, max_len=3)
```
