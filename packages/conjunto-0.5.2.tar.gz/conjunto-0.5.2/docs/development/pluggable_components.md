# Pluggable Components (HTMX)

Conjunto exposes plugin-discovered UI extensions through GDAPS
**interfaces** that carry pure metadata (`name`, `title`, `icon`,
`weight`, …) plus a `template` path or a `get_context_data()` hook. A
**consuming view** enumerates the plugins, applies permission gates
and ordering, and renders them as **server-rendered HTMX partials** —
optionally lazy-loaded.

> Older revisions of Conjunto integrated Tetra components as plugin
> entry points (`IComponent.is_component`, `{% component =widget /%}`).
> That path has been removed. Tetra is still used internally for a few
> low-level UI primitives (`conjunto/components/default/{page,card,
> accordion,footer,avatar,modal_button}`) but is no longer the plugin
> extension mechanism. New plugin contributions go through the HTMX
> path described below.

## Core interface: `IElement`

`conjunto.api.interfaces.IElement` is the metadata base for every
listable, plugin-contributed UI fragment:

```python
class IElement(Interface):
    name: str          # unique slug (URL fragment, HTML id)
    title: str = ""    # human-readable, gettext_lazy
    icon: str = ""     # Tabler icon name (without "ti ti-")
    weight: int = 0    # sort weight, lower first
    group: type[IElementGroup] = GeneralGroup

    @classmethod
    def enabled(cls) -> bool: ...
```

Two important rules:

- **`__instantiate_plugins__ = False`** — plugins are class objects,
  not instances. Iterate via `IElement.enabled_plugins()`.
- **Rendering is not the interface's responsibility.** A plugin
  declares *what* it is; a consuming view decides *how* to render
  (list, grid, tab set, lazy-loaded card, …) and emits the HTMX
  attributes.

## The HTMX rendering pattern

```text
plugin (metadata)            consuming view             template
─────────────────────────    ──────────────────────     ──────────────────────────
class FooSection(IElement):   def get_context_data():   {% for s in sections %}
    name = "foo"                  ctx["sections"] = [     <a hx-get="?section={{s.name}}"
    title = _("Foo")                  s for s in           hx-target="#pane">…</a>
    icon = "settings"                 IFooSection         {% endfor %}
    template = "foo.html"             .enabled_plugins()
                                      if s.has_perm(req)]
```

Two concrete shapes for the consuming view:

1. **Eager render in the same response.** The view loads
   `enabled_plugins()`, builds context, the template iterates and
   includes each plugin's partial directly. Used for left-rail
   navigation entries that are cheap to render.

2. **Lazy-load via HTMX.** The view emits a card *shell* with
   `hx-get="<plugin-content-url>" hx-trigger="load"` for each plugin.
   A separate generic view resolves `(area, plugin_name)` and renders
   the plugin's content template on demand. Used when content is
   expensive (DB queries, external APIs) or when the surrounding
   layout — Gridstack, drag-and-drop — needs the cards to land in the
   DOM first.

## Real-world example: settings

`conjunto/settings/interfaces.py` defines a three-level hierarchy that
renders eagerly:

```python
class ISettingsGroup(IElementGroup): ...        # left-rail category
class ISettingsSection(IElement):               # entry under a group
    group: type[ISettingsGroup]
    permission_required: str | None = None

class ISettingsForm(IElement):                  # right-pane form
    section: type[ISettingsSection] | str
    form_class = None
    template: str | None = None
    requires_full_reload: bool = False
```

The consuming view (`conjunto.settings.views.SettingsView`) builds the
groups, picks the active section from `?section=<name>`, instantiates
the matching `ISettingsForm` plugins and binds their forms.
**`get_template_names()` returns either the full page or a
`#settings-pane` partial** depending on the HTMX target — that is the
core pattern for swapping a single pane without reloading the chrome:

```python
def get_template_names(self):
    if self.request.htmx and self.request.htmx.target == PANE_ID:
        return ["conjunto/settings/page.html#settings-pane"]
    return ["conjunto/settings/page.html"]
```

A successful `ISettingsForm` POST returns `204 No Content` with
`HX-Reswap: none` and `HX-Trigger: showToast`. Sections opt into a
full `HX-Refresh` via `requires_full_reload = True` for changes that
ripple across many DOM nodes (theme, language, layout).

## Real-world example: widgets (lazy-loaded)

`IWidgetArea` and `IWidget` (in `conjunto.api.interfaces`) implement
the lazy-load shape on top of Gridstack.js:

```python
class IWidgetArea(Interface):
    name: str
    columns: int = 6

class IWidget(Interface):
    name: str
    title: str = ""
    icon: str = "widget"
    area: type[IWidgetArea] = None
    template: str = ""              # widget content template
    permission_required: str | None = None
    col_span: int = 2

    @classmethod
    def has_permission(cls, request) -> bool: ...

    @classmethod
    def get_context_data(cls, request) -> dict: ...
```

The card shell (`conjunto/templates/conjunto/widgets/card_shell.html`)
emits a placeholder card with three HTMX attributes — content arrives
on first paint:

```django
<div class="card-body"
     hx-get="{% url 'widgets:content' area_name=area.name widget_name=widget.name %}"
     hx-trigger="load"
     hx-swap="innerHTML">
  {% include "conjunto/widgets/card_loading.html" %}
</div>
```

A single generic content view resolves the plugin and renders its
template:

```python
class WidgetContentView(LoginRequiredMixin, View):
    def get(self, request, area_name, widget_name):
        area_cls = _find_area(area_name) or raise_404
        widget_cls = _find_widget(area_cls, widget_name) or raise_404
        if not widget_cls.has_permission(request):
            raise Http404            # hide existence from unauthorised users
        ctx = widget_cls.get_context_data(request)
        ctx["request"] = request
        return render(request, widget_cls.template, ctx)
```

`WidgetAreaMixin` — used by host views to render the area — populates
the layout (positions, widths, lock state) from
`ScopedSetting`s, so users can drag/resize widgets and the layout
persists per scope. `WidgetReorderView` and `WidgetToggleLockView`
write back through the same scoped-settings store.

This is the canonical *lazy-load via HTMX* shape: shell first, content
on `hx-trigger="load"`, optional `hx_url` convention on the plugin
class.

## Render-hook pattern: `IPostLoginAction` / `ITemplatePlugin`

For plugins that contribute a *renderable fragment* into a host
template (login, base, dashboard, …) without their own host view, use
`gdaps.api.interfaces.ITemplatePlugin`. `IPostLoginAction` is the
canonical example:

```python
class IPostLoginAction(ITemplatePlugin):
    """A renderable hook fired on every authenticated page load."""
```

The host template invokes it via the GDAPS `render_plugins` tag —
no consuming view in between:

```django
{% load gdaps %}
{% if request.user.is_authenticated %}
    {% render_plugins "IPostLoginAction" %}
{% endif %}
```

Implementations declare a `template_name` and override
`get_plugin_context(context)` to inject variables. **The hook must
mutate and return the incoming `Context`, never a plain `dict`** —
`render_plugins` calls the low-level `Template.render(context)` which
needs `context.render_context`.

Typical contribution from a plugin: a one-shot HTMX trigger that opens
a modal, gated by a session flag the plugin sets and consumes itself.

## Permissions and visibility

Each interface decides its own gate. The two common shapes:

- **Class-level `permission_required: str`** + a `has_permission(request)`
  classmethod (`IWidget`, `ISettingsSection`, `ILoginMethod`).
- **`enabled() -> bool`** classmethod for cross-cutting toggles
  (`IElement.enabled`, `ILoginMethod.is_enabled(request)`).

Consuming views must filter `enabled_plugins()` through both. Hide
existence from unauthorised users by **returning 404 instead of 403**
in lazy-load endpoints (`WidgetContentView` does this).

## When to use which

| Need                                              | Use                              |
|---------------------------------------------------|----------------------------------|
| Listable navigation/menu entry                    | `IMenuItem` (see `menus.md`)     |
| Settings rail / pane / form                       | `ISettingsGroup` / `ISettingsSection` / `ISettingsForm` |
| Dashboard or sidebar card with HTMX content       | `IWidgetArea` + `IWidget`        |
| Custom listable area, eagerly rendered            | Subclass `IElement`              |
| Drop a fragment into a host template, no view     | `ITemplatePlugin` + `{% render_plugins %}` |
| Login flow extension                              | `ILoginMethod` / `ILoginViewExtension` / `IPostLoginAction` |
| Tetra component                                   | Internal core UI only — not a plugin extension point |

## Conventions for plugin-side code

- Inherit from `IElement` (or one of the specialised subinterfaces).
  Set `__instantiate_plugins__ = False` if you subclass `Interface`
  directly.
- Use `weight` for ordering. Lower first. No `order` / `priority`.
- Wrap `title` in `gettext_lazy`.
- Tabler icon name only (`"settings"`), no `ti ti-` prefix — the
  template applies it.
- Gate sensitive content with `permission_required` *and* return 404
  in the lazy-load view to avoid leaking existence.
- Keep `get_context_data()` cheap. Lazy-load is the right answer for
  expensive content, not a reason to skip caching.
- Re-use the consuming view's HTMX conventions
  (`HX-Trigger: showToast`, `HX-Reswap: none`, `HX-Refresh: true` for
  full reloads). Don't invent a parallel signal scheme.
