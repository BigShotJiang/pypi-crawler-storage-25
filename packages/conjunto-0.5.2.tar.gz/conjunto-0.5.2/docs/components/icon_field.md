# IconField

A form field that renders a small curated set of Tabler icons as a tile picker
(`form-selectgroup`). Analogous to `ColorField`, but for icons.

## Quick start

```python
from conjunto.forms import IconField
from django.utils.translation import gettext_lazy as _

class CategoryForm(forms.ModelForm):
    icon = IconField(choices=[
        ("moon",       _("Moon")),
        ("sun",        _("Sun")),
        ("cloud",      _("Cloud")),
        ("cloud-rain", _("Rain")),
    ])

    class Meta:
        model = Category
        fields = ("name", "icon")
```

The cleaned value is the Tabler icon **name** (without the `ti-` prefix).
Persist it in a regular `CharField(max_length=64)` on the model and render
it with:

```django
<i class="ti ti-{{ category.icon }}"></i>
```

## Choices format

`(name, label)` tuples — same as any `ChoiceField`. Names come from the
Tabler icon catalog: <https://tabler.io/icons>. Pass the slug *without* the
`ti-` prefix (so `"cloud-rain"`, not `"ti-cloud-rain"`).

The label is used both as a browser `title` tooltip on hover and as a
`visually-hidden` caption for screen readers.

## `choices` is required

Unlike `ColorField`, `IconField` has **no default set**. Icons are always
context-specific — there is no "natural" Tabler icon palette. Calling
`IconField()` without `choices` raises `TypeError`.

## Multiple selection

```python
icon = IconField(choices=..., multiple=True, required=False)
```

Renders checkboxes instead of radios via `IconSelectMultiple`. `IconField`
itself is a `ChoiceField` and only validates a single value — for full
multi-value validation use `forms.MultipleChoiceField` with
`widget=IconSelectMultiple`.

## Visual styling

The widget renders Tabler's `form-selectgroup` markup with an additional
`cj-icon-select` class. A scoped CSS override in `conjunto.css` removes the
per-tile border and shows it only on the checked tile.
