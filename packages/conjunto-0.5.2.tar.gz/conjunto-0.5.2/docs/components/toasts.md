# Toasts

Conjunto ships a Bootstrap/Tabler toast system that is wired directly
into Django's `messages` framework and HTMX. There is no component to
include — the toast container lives in `conjunto/base.html` and is
rendered on every page that extends it.

## Examples

### Standard toasts

![toasts.png](../images/toasts.png)

### Dismissible toast

![toast_dismissible.png](../images/toast_dismissible.png)

---

## How it works

1. A view calls Django's `messages` framework as usual:
   ```python
   from django.contrib import messages
   messages.success(request, "Settings saved.")
   ```
2. Depending on the request type, conjunto delivers the message to the
   browser:
   - **Full-page response:** `conjunto/includes/toasts.html` renders
     the pending messages into a
     `<script id="cj-initial-toasts" type="application/json">` block
     inside the toast container.
   - **HTMX response:** `ConjuntoMessagesMiddleware` drains the
     messages storage and attaches an `HX-Trigger` header carrying a
     `conjunto:toasts` DOM event with the same payload.
3. `conjunto/js/toasts.js` (loaded automatically by `{% conjunto_core_scripts %}`)
   listens for both sources, builds a Bootstrap `.toast` element for
   each entry, and shows it via `new bootstrap.Toast(el).show()`.

---

## Wiring

Make sure your `settings.py` has the messages framework enabled
(Django's default) and register the middleware **after**
`MessageMiddleware` and `django_htmx.middleware.HtmxMiddleware`:

```python
MIDDLEWARE = [
    # ...
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django_htmx.middleware.HtmxMiddleware",
    "conjunto.middleware.ConjuntoMessagesMiddleware",
    # ...
]
```

That's it — every template extending `conjunto/base.html` will now
show toasts.

---

## Configuration

The toast container's placement is controlled by two Django settings:

| Setting                    | Default      | Purpose                                                  |
|----------------------------|--------------|----------------------------------------------------------|
| `CONJUNTO_TOAST_POSITION`  | `"top-right"`| Corner or edge of the viewport where toasts stack.       |
| `CONJUNTO_TOAST_MARGIN`    | `"1rem"`     | Distance from the viewport edges. Any CSS length.        |

`CONJUNTO_TOAST_POSITION` accepts one of:

- `top-left`
- `top-center`
- `top-right` *(default)*
- `bottom-left`
- `bottom-center`
- `bottom-right`

`CONJUNTO_TOAST_MARGIN` is a single value applied to both axes — e.g.
`"1rem"`, `"24px"`, `"2vh"`. For the `*-center` positions it is applied
to the top/bottom edge only (horizontal centering uses a CSS transform).

```python
# settings.py
CONJUNTO_TOAST_POSITION = "bottom-center"
CONJUNTO_TOAST_MARGIN = "2rem"
```

The values are resolved by `conjunto.context_processors.globals` into
an inline `style` attribute on the `#cj-toasts` container, so changes
take effect on the next page load without any CSS recompile.

---

## Usage

### From any view

```python
from django.contrib import messages

def my_view(request):
    messages.info(request, "You have new mail.")
    messages.warning(request, "Could not save file.")
    messages.error(
        request,
        "Critical error. Stop working.",
        extra_tags="dismissible",
    )
    return render(request, "...")
```

- **Level** — `messages.debug / info / success / warning / error`
  map to Tabler's soft color variants (`bg-info-lt`,
  `bg-success-lt`, …).
- **`extra_tags="dismissible"`** — the toast stays on screen until the
  user closes it via the `×` button. Without this flag the toast
  auto-hides after the container's default delay (6 seconds).

This works on **both** full-page requests and HTMX partial swaps.
You do not need to think about which kind of response you're
producing.

### From a view that returns an `HttpResponse` directly

Views that bypass the messages framework (e.g. HTMX partial handlers
that return a small fragment) can use the `add_toast` helper:

```python
from conjunto.http import add_toast

def htmx_partial(request):
    response = render(request, "partials/row.html", {...})
    add_toast(response, "Row updated", level="success")
    return response
```

`add_toast(response, message, level="info", dismissible=False, delay=None)`
attaches a `showToast` event to the response's `HX-Trigger` header.

### From client-side JavaScript

Dispatch a `showToast` `CustomEvent` on `document.body` (the same
target HTMX uses for `HX-Trigger` events):

```javascript
document.body.dispatchEvent(new CustomEvent("showToast", {
  bubbles: true,
  detail: {
    message: "This is a test notification!",
    level: "success",   // "info" | "success" | "warning" | "error" | "debug"
    dismissible: true,  // optional
    delay: 4000         // optional, ms — ignored when dismissible
  }
}));
```

---

## Reference

### Middleware

`conjunto.middleware.ConjuntoMessagesMiddleware`

Drains `django.contrib.messages` on HTMX responses and attaches a
`conjunto:toasts` event to the `HX-Trigger` header. On full-page
responses it leaves the messages alone — the template's toast include
will render them.

### Template include

`conjunto/includes/toasts.html` — rendered by
`conjunto/base.html`'s `{% block toasts %}`. Contains:

- `#cj-toasts` — the Bootstrap toast container
  (`toast-container position-fixed` + an inline `style` computed from
  `CONJUNTO_TOAST_POSITION` / `CONJUNTO_TOAST_MARGIN`).
- `#cj-initial-toasts` — a JSON `<script>` block with any pending
  initial messages (omitted when there are none).

Default auto-hide delay is 6000 ms, controlled by
`data-cj-toast-delay` on the container. Override it by providing
`cj_toast_delay` in the template context.

### Python helper

`conjunto.http.add_toast(response, message, level="info", dismissible=False, delay=None)`

Attaches a `showToast` event to `response`'s `HX-Trigger` header and
returns the response unchanged.

### DOM events

| Event              | Dispatched on   | Payload                                                |
|--------------------|-----------------|--------------------------------------------------------|
| `conjunto:toasts`  | `document.body` | `{toasts: [{message, level, tags, dismissible}, ...]}` |
| `showToast`        | `document.body` | `{message, level, dismissible?, delay?}`               |

Both events are handled by `conjunto/js/toasts.js`. The JS file is
bundled by `{% conjunto_core_scripts %}`, so you don't need to include it
manually.

### Toast payload fields

| Field         | Type    | Description                                                            |
|---------------|---------|------------------------------------------------------------------------|
| `message`     | string  | Body text. Inserted via `textContent`, so it's safe against XSS.       |
| `level`       | string  | One of `debug`, `info`, `success`, `warning`, `error`. Maps to a Tabler soft color class. |
| `dismissible` | boolean | If `true`, the toast shows an `×` button and never auto-hides.         |
| `delay`       | int     | (optional) Per-toast auto-hide delay in ms. Ignored when dismissible.  |
| `tags`        | string  | (optional) Full Django message tags string. Informational only.        |
