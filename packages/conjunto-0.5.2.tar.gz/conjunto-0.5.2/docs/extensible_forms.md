# `conjunto.extensible_forms` — author guide

Reusable composite-form framework. A master form (`ModelForm`) plus N plugin-contributed sub-forms,
rendered flat inside one `<form>`. Tab order follows DOM order. Cross-plugin client-side reactivity uses a
small published event vocabulary.

## When to use

Use this when a form represents a master entity (Patient, FamilyHistoryEntry, Encounter, …) **and** you
expect plugins to contribute additional fields that should appear inside the same form rather than as
separate cards.

## Anatomy

| Symbol                       | Owner    | Purpose                                                |
|------------------------------|----------|--------------------------------------------------------|
| `FormSlot`                   | conjunto | Abstract `TextChoices` base for layout anchors         |
| `FormSectionContract`        | conjunto | Section attribute contract (mix-in)                    |
| `CompositeForm`              | conjunto | Master + sub-forms; atomic save; media; initial JSON   |
| `build_slot_layout()`        | conjunto | Crispy `Layout` from slot map + section weight         |
| `extensibleForm()`           | conjunto | Alpine factory holding the reactive `fields` object    |
| `{% extensible_form_attrs %}`| conjunto | Renders `x-data` + namespaced event listener           |

Owner plugins declare four custom types (see "Recipe" below): slot enum, section interface,
composite-form subclass, field-slot map.

## Recipe — owner plugin

```python
# myplugin/models/forms_slot.py
from django.utils.translation import gettext_lazy as _
from conjunto.extensible_forms import FormSlot


class FoobarFormSlot(FormSlot):
    HEAD = "head", _("Head")
    BODY = "body", _("Body")
    EXTRA = "extra", _("Extra")    # convention: last member = catch-all
```

```python
# myplugin/interfaces.py
from gdaps.api import Interface
from conjunto.extensible_forms import FormSectionContract


class IFoobarFormSection(FormSectionContract, Interface):
    __sort_attribute__ = "weight"
    __instantiate_plugins__ = False
```

```python
# myplugin/forms.py
from django import forms
from conjunto.extensible_forms import CompositeForm
from .interfaces import IFoobarFormSection
from .models import FoobarFormSlot


class FoobarMasterForm(forms.ModelForm):
    class Meta:
        model = Foobar
        fields = ["title", "body"]


class FoobarCompositeForm(CompositeForm):
    master_form_class = FoobarMasterForm
    section_interface = IFoobarFormSection
    owner_attr = "foobar"
    event_namespace = "foobar-form"
    field_slot_map = {
        "title": FoobarFormSlot.HEAD,
        "body": FoobarFormSlot.BODY,
    }
```

```python
# myplugin/apps.py — inside ``ready``
from gdaps.pluginmanager import PluginManager


class MyPluginConfig(...):
    def ready(self):
        super().ready()
        PluginManager.load_plugin_submodules("foobar_form_sections")
```

```django
{# myplugin/templates/myplugin/foobar_form.html #}
{% load static extensible_form %}
<form {% extensible_form_attrs composite %} method="post"
      hx-post="..." hx-target="#dialog" hx-swap="innerHTML">
    {% csrf_token %}
    {{ composite|safe }}
    <button type="submit">Save</button>
</form>
<script src="{% static 'conjunto/js/extensible_form.js' %}"></script>
{{ composite.media }}
```

## Recipe — contributing plugin

A plugin that contributes a sub-form drops a single file `foobar_form_sections.py` into its app:

```python
from myplugin.interfaces import IFoobarFormSection
from myplugin.models import FoobarFormSlot
from .forms import MySubForm


class MySubSection(IFoobarFormSection):
    form_class = MySubForm
    instance_attr = "myplugin"          # foobar.myplugin reverse 1:1
    slot = FoobarFormSlot.BODY
    weight = 20
    # check = lambda req: req.scoped_settings.get(...)   # optional gate
```

The sub-form ships its JS via `Media.js`; the composite aggregates `media` automatically.

## Event vocabulary

| Event              | Detail                            | Master behaviour                                    |
|--------------------|-----------------------------------|----------------------------------------------------|
| `<ns>:set`         | `{ name, value, only_if_empty? }` | Set field value (skip if `only_if_empty` + exists) |
| `<ns>:invalidate`  | `{ name, message }`               | Apply client-side error class                      |

`<ns>` is the owner's `event_namespace` (e.g. `patient-form`, `family-history-form`). The listener is
wired automatically by `{% extensible_form_attrs %}`.

## Sketch — a second user (`FamilyHistoryCompositeForm`)

For an eCard-fetch integration of family history, the owner plugin (likely `medux-patients`) would add:

```python
class FamilyHistoryFormSlot(FormSlot):
    RELATION = "relation", _("Relation")
    CONDITION = "condition", _("Condition")
    SOURCE = "source", _("Source")          # eCard origin meta lives here
    EXTRA = "extra", _("Extra")


class IFamilyHistoryFormSection(FormSectionContract, Interface):
    __sort_attribute__ = "weight"
    __instantiate_plugins__ = False


class FamilyHistoryCompositeForm(CompositeForm):
    master_form_class = FamilyHistoryMasterForm
    section_interface = IFamilyHistoryFormSection
    owner_attr = "family_history"
    event_namespace = "family-history-form"
    field_slot_map = {
        "relationship":  FamilyHistoryFormSlot.RELATION,
        "condition":     FamilyHistoryFormSlot.CONDITION,
        "age_at_onset":  FamilyHistoryFormSlot.CONDITION,
        "deceased":      FamilyHistoryFormSlot.CONDITION,
    }
```

`medux-elga` later contributes an `IFamilyHistoryFormSection` that targets the `SOURCE` slot and ships
JS dispatching `family-history-form:set` to pre-fill `condition` from an eCard query.
