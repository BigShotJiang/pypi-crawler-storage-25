# Encrypted file fields

`conjunto.fields.EncryptedFileField` and `EncryptedImageField` wrap the
plain `FileField` / `ImageField` API with at-rest AES-256-GCM
encryption. They are intended for any project that needs to store user
uploads in a way that the bytes-on-disk view is useless to anyone who
isn't going through the application's audit-gated decrypt path —
medical records, legal documents, tax records, anything that
GDPR Art. 32 / equivalent regimes flag as "encryption at rest expected".

## Use it

```python
from conjunto.fields import EncryptedFileField, EncryptedImageField


class Report(models.Model):
    tenant = models.ForeignKey("tenants.Tenant", on_delete=models.PROTECT)
    title = models.CharField(max_length=200)
    pdf = EncryptedFileField(upload_to="reports/", max_plain_size=50 * 1024 * 1024)
    pdf_manifest = models.BinaryField(null=True, blank=True, editable=False)


class Patient(models.Model):
    tenant = models.ForeignKey("tenants.Tenant", on_delete=models.PROTECT)
    width = models.PositiveIntegerField(null=True, blank=True)
    height = models.PositiveIntegerField(null=True, blank=True)
    portrait = EncryptedImageField(
        upload_to="patients/portraits/",
        width_field="width",
        height_field="height",
    )
    portrait_manifest = models.BinaryField(null=True, blank=True, editable=False)
```

Three requirements at model time:

1. Every `EncryptedFileField` / `EncryptedImageField` **must** be paired with a sibling
   `BinaryField` (`null=True, blank=True, editable=False`) named `<field>_manifest`.
   Pass `manifest_field="custom_name"` to override the convention. `manage.py check`
   rejects models that forget the sibling.
2. The model **must** carry a `tenant_id` attribute (FK or plain int). The configured
   backend picks the KEK based on it.
3. The configured backend must be installed via the
   `CONJUNTO_FILE_ENCRYPTION_BACKEND` setting (see [Backends](#backends)).

Writing:

```python
report = Report(tenant=current_tenant, title="X-ray summary")
report.pdf.save("xray.pdf", request.FILES["upload"], save=True)
```

Reading — **never** through `.url`:

```python
from django.http import FileResponse
from django.contrib.auth.decorators import login_required


@login_required
def download_report(request, pk):
    report = get_object_or_404(
        Report, pk=pk, tenant=request.tenant
    )
    return FileResponse(
        report.pdf.open_decrypted(),
        as_attachment=True,
        filename=f"report-{pk}.pdf",
        content_type="application/pdf",
    )
```

`report.pdf.url` deliberately raises `NotImplementedError` so the field
cannot accidentally be linked from a template. Each
`open_decrypted()` call emits one audit-log entry through the backend.

## What the field gives you

* **Filename is always a UUID.** The on-disk path is
  `<upload_to>/<uuid4>.enc`. The original upload name is dropped — if
  you need to surface it to users, store it in a separate column
  (plaintext if the name itself isn't sensitive, or another
  encrypted field if it is).
* **Sidecar manifest.** The model declares a `<field>_manifest`
  `BinaryField` (or whatever name you passed via `manifest_field=`).
  It carries the wrapped per-file DEK, the STREAM nonce prefix, the
  key version and the plaintext size. Don't touch it manually; the
  field reads and writes it on save / decrypt.
* **Streaming AES-256-GCM** (Rogaway STREAM construction, 4 MiB
  chunks by default). Truncation, reordering and bit-flip attacks
  surface as `cryptography.exceptions.InvalidTag`.
* **Per-file DEK**, wrapped by the tenant KEK. Rotating the tenant KEK
  rewraps the manifest only — file bytes are not rewritten.
* **`.size` reads the manifest** (plaintext bytes), not the on-disk
  ciphertext size.
* **`EncryptedImageField` validates uploads with Pillow**, populates
  `width_field` / `height_field` at upload time, and **strips EXIF /
  ICC / XMP / comment metadata** by default. Pass
  `strip_exif=False` to disable.

## Backends

Conjunto ships no production backend. Plug one in via:

```python
# settings.py
CONJUNTO_FILE_ENCRYPTION_BACKEND = "myapp.crypto.MyBackend"
```

Implement the `conjunto.files.encryption.IFileEncryptionBackend`
protocol — four methods, all per-tenant:

```python
class MyBackend:
    def get_active_key_version(self, tenant_id): ...
    def wrap_dek(self, dek, *, tenant_id, key_version, aad): ...
    def unwrap_dek(self, wrapped, *, tenant_id, key_version, aad): ...
    def audit_decrypt(self, *, tenant_id, key_version, model_label,
                      object_pk, field_name, size): ...
```

For tests, the bundled `InMemoryFileEncryptionBackend` generates random
KEKs per `(tenant_id, key_version)` and records audit calls in a list:

```python
import pytest
from conjunto.files import encryption as enc


@pytest.fixture
def backend():
    be = enc.InMemoryFileEncryptionBackend()
    enc.set_backend(be)
    yield be
    enc.reset_backend()
```

## Manifest format

Fixed-length binary header followed by the variable-length wrapped DEK.
Total typically ~85 bytes.

```
+---------+------+------+---------------+----------------+---------------+
| magic   | ver  | flags| key_version   | nonce_prefix   | plain_size    |
| 4 bytes | 1 B  | 1 B  | 2 B BE        | 7 bytes        | 8 B BE        |
+---------+------+------+---------------+----------------+---------------+
| wrapped_dek_len  | wrapped_dek (variable)                              |
| 2 B BE           |                                                     |
+------------------+-----------------------------------------------------+
```

* `magic` = `b"CFE1"` — fail-fast guard against accidentally feeding a
  random blob to `Manifest.from_bytes`.
* `ver` is the manifest schema version. Bumped if the layout ever
  evolves; readers MUST reject unknown versions.
* `flags` is reserved for future use (no current values defined).
* `nonce_prefix` is the random 7-byte STREAM prefix. Each chunk's
  12-byte nonce = `prefix(7) ‖ counter_be(4) ‖ final_flag(1)`.

## STREAM chunk layout on disk

The on-disk file is *just* a concatenation of AES-GCM ciphertext+tag
blocks — there is no per-chunk length prefix, because the plaintext
chunk size is fixed (`field.chunk_size`, default 4 MiB). Readers use
the same chunk size to slice the file; the last chunk is the only one
that may be short.

Each chunk's nonce includes the `final_flag` bit. The encrypter sets
it on the last chunk only; truncating the file therefore yields the
wrong final-flag at decrypt time → `InvalidTag`.

## Threat model (short)

* **Defends against**: file-system / backup attackers, restore-to-wrong
  tenant, accidental `.url` leaks (`url` raises), single-bit tampering
  on the ciphertext or manifest, file-bytes swap between rows (AAD
  binds to model / field / file-uuid / key-version), key rotation
  without re-encrypting bytes.
* **Does not defend against**: a fully-compromised application server
  (it has the KEK), side-channel timing leakage, OCR / full-text
  indexes built by other code on the decrypted bytes, RAM forensics
  after a decrypt.
* **Intentional leakage**: file size (≈chunk granularity), upload
  mtime, the fact that a file exists, image dimensions (cached at
  upload). EXIF is stripped by default for `EncryptedImageField`.

## Migrating from plain `FileField` / `ProtectedFileField`

Four steps:

1. **Edit `models.py`** — change the field type from `FileField`
   (or `ProtectedFileField`) to `EncryptedFileField`, **and** add the
   companion `<field>_manifest = models.BinaryField(null=True, blank=True,
   editable=False)` next to it. Leave `upload_to`, `null`, `blank` etc.
   on the file field as they are.
2. **`makemigrations`** — Django generates an `AlterField` for the file
   column and an `AddField` for the new `BinaryField`. No manual
   editing needed.
3. **`migrate`** — pure schema change so far; existing rows still hold
   plain files at their old paths and an empty manifest.
4. **`python manage.py encrypt_filefield <app.Model> <field>`** —
   walks rows with empty manifest, reads each plain file, generates a
   UUID, stream-encrypts to the new path, writes the manifest, drops
   the old file. Idempotent and safe to re-run after a crash.

Flags:

```
--batch-size=N         # iterator chunk (default 100)
--dry-run              # report only; touch nothing
--keep-originals       # don't delete plain files after re-encrypt
--tenant-id=N          # restrict to one tenant
--upload-to-prefix=…   # override the new file's directory prefix
```

Atomicity per row:

* Encrypt failure → old file + DB unchanged.
* DB save failure → freshly written ciphertext is rolled back via
  `storage.delete()`.
* Delete of the original failing after successful commit → logged
  WARNING; the row is fully migrated, the old file is an orphan you
  can clean up later.

`EncryptedFieldFile.open("rb")` returns the **ciphertext** stream and
works even with an empty manifest — that's the read mode the migration
command uses to grab the legacy plain file. `open_decrypted()` raises
`MissingManifestError` on rows that haven't been migrated yet, so you
never silently serve plaintext as if it were "decrypted".

## Programmatic migration

```python
from conjunto.files.encryption import migrate_to_encrypted
from myapp.models import Report

counters = migrate_to_encrypted(
    Report,
    "pdf",
    batch_size=200,
    upload_to_prefix="reports/",  # or omit to reuse existing dir
)
# {"processed": N, "skipped": N, "errors": N}
```
