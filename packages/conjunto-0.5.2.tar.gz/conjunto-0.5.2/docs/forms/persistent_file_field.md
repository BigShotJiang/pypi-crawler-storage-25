# `PersistentFileField`

`PersistentFileField` is a generic `FileField` whose value survives form
re-renders — validation errors, wizard step transitions, HTMX partial
swaps — without the user having to re-select the file.

The browser cannot re-populate `<input type="file">` with a previously
uploaded file for security reasons. Instead, the field pairs with
`PersistentFileWidget`, which renders one of two states:

- **No file yet** — a normal `<input type="file">`.
- **File already present** — the file name, a **Replace** button
  (toggles a fresh `<input type="file">` back into view) and an
  optional **Remove** button (fires `hx-delete` against a URL supplied
  by the form/view).

The field is not wizard-specific. Any conjunto form with an upload
field that must re-render (validation errors, HTMX swaps, multi-step
flows) can use it.

## Usage

```python
from django import forms
from conjunto.forms import PersistentFileField


class ContactForm(forms.Form):
    name = forms.CharField()
    attachment = PersistentFileField(required=False)
```

### Preserving an already-uploaded file

Pass a "file reference" object via `initial`. Any object exposing
`.name`, `.url` and (optionally) `.original_name` / `.pk` works —
`FieldFile` (Django), `WizardDraftFile`, or a plain stand-in.

```python
form = ContactForm(
    data=request.POST,
    files=request.FILES,
    initial={"attachment": existing_attachment_ref},
)
```

When the form re-renders, the widget shows the existing file. When the
form POSTs back:

- A new upload (`UploadedFile`) always wins.
- The "clear" marker (`attachment-clear=on`) returns `False`, the
  standard Django signal for "delete the existing file".
- Otherwise, the initial reference passes through unchanged and
  `required=True` is considered satisfied.

### Wiring the Remove button

`PersistentFileWidget.delete_url` controls whether the Remove button
is rendered and where it posts. Set it from the form/view:

```python
form.fields["attachment"].widget.delete_url = reverse("myapp:remove-attachment")
```

Leaving `delete_url=None` hides the Remove button — only the Replace
flow is available. This is useful when the "remove" semantic is
handled elsewhere (e.g. on the object itself).

### Preserving files on POST validation errors

When a traditional POST fails validation, the browser reloads the page
and file inputs are empty.  `PersistentFileUploadMixin` solves this
by caching uploaded files in Django's cache and restoring them on
subsequent POSTs.

```python
from conjunto.views import PersistentFileUploadMixin


class MyCreateView(PersistentFileUploadMixin, View):
    def post(self, request, *args, **kwargs):
        files = self.get_form_files(request)           # restore cached files
        form = MyForm(data=request.POST, files=files)
        if not form.is_valid():
            self.persist_form_files(request, form)      # cache + form.initial
            return render(request, "myapp/form.html", {"form": form})
        self.clear_persisted_files(request)              # cleanup on success
        # ... save logic
```

The mixin provides three methods:

| Method                                | When to call               | What it does                                      |
| ------------------------------------- | -------------------------- | ------------------------------------------------- |
| `get_form_files(request)`             | Before form creation       | Returns `request.FILES` merged with cached files  |
| `persist_form_files(request, form)`   | After `is_valid()` fails   | Caches uploads, sets `form.initial` for widget    |
| `clear_persisted_files(request)`      | After successful save      | Deletes cached files                              |

Files are stored in Django's cache with a one-hour TTL
(`_pfu_cache_timeout`).  Override the attribute on your view to
change the timeout.

!!! note "Cache backend"
    The default `LocMemCache` works for development.  In production,
    use a backend that supports values of several megabytes (Redis,
    Memcached, or file-based cache).

## End-to-end example: file upload with dependent fields

A complete, working example of a form that combines
[`DependentFieldsMixin`](../usage/forms.md#dependent-fields-htmx)
(country → federal state) with a `PersistentFileField` (identity
proof).  Files survive both HTMX re-renders (when the user switches
country) and POST validation errors.

### Form

```python
# myapp/forms.py
from django import forms
from django.urls import reverse_lazy

from conjunto.forms import DependentFieldsMixin, PersistentFileField
from myapp.models import FederalState


class SignupForm(DependentFieldsMixin, forms.Form):
    update_url = reverse_lazy("myapp:signup_fragment")

    country = forms.ChoiceField(choices=[("AT", "Austria"), ("DE", "Germany")])
    federal_state = forms.ModelChoiceField(queryset=FederalState.objects.none())
    identity_proof = PersistentFileField()

    def country_changed(self, value):
        if value:
            self.fields["federal_state"].queryset = (
                FederalState.objects.filter(country=value)
            )
```

`country` triggers an HTMX re-render when it changes — the mixin wires
up `hx-get` / `hx-target` / `hx-swap` automatically, and adds
`hx-preserve` to `identity_proof` so the selected file survives the
swap.

### Views

```python
# myapp/views.py
from django.shortcuts import redirect, render
from django.views import View

from conjunto.htmx.views import DependentFieldsView
from conjunto.views import PersistentFileUploadMixin

from myapp.forms import SignupForm


class SignupView(PersistentFileUploadMixin, View):
    template_name = "myapp/signup.html"

    def get(self, request):
        return render(request, self.template_name, {"form": SignupForm()})

    def post(self, request):
        files = self.get_form_files(request)
        form = SignupForm(data=request.POST, files=files)
        if not form.is_valid():
            self.persist_form_files(request, form)
            return render(request, self.template_name, {"form": form})
        self.clear_persisted_files(request)
        # ... save + redirect ...
        return redirect("myapp:thanks")


class SignupFragmentView(DependentFieldsView):
    """HTMX fragment endpoint for dependent-field re-renders."""

    form_class = SignupForm
    template_name = "myapp/signup.html#signup_form_body"
```

### URLs

```python
# myapp/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path("signup/", views.SignupView.as_view(), name="signup"),
    path(
        "signup/fragment/",
        views.SignupFragmentView.as_view(),
        name="signup_fragment",
    ),
]
```

### Template

```django
{# myapp/templates/myapp/signup.html #}
{% load crispy_forms_tags %}

<form id="signup-form" method="post" enctype="multipart/form-data">
  {% csrf_token %}
  {% partialdef signup_form_body %}
  <div id="signup-form-body">
    {{ form|crispy }}
  </div>
  {% endpartialdef %}
  <button type="submit">Sign up</button>
</form>
```

The form body is wrapped in `{% partialdef %}` so the HTMX fragment
view can return just that slice of the template.

### What happens at runtime

| User action | What happens |
| --- | --- |
| User selects a file, then changes `country` | HTMX fires GET to `signup_fragment`, form is re-rendered, `hx-preserve` keeps the file input in place — selection preserved. |
| User submits the form with an invalid field | POST validation fails; `persist_form_files` writes the uploaded file to the cache and attaches it to `form.initial`; the widget renders "already uploaded: &lt;name&gt; [Replace]". |
| User fixes the error and re-submits **without re-selecting the file** | `get_form_files` restores the cached file as a fresh upload; validation passes; `clear_persisted_files` cleans up the cache. |

## Template

The widget uses `conjunto/forms/_persistent_file.html`. The file state
block looks like:

```html
<div class="persistent-file">
  <i class="ti ti-paperclip"></i>
  <a href="{{ file_url }}" target="_blank">{{ display_name }}</a>
  <button data-bs-toggle="collapse" data-bs-target="#pf-replace-{{ name }}">
    Replace
  </button>
  <button hx-delete="{{ delete_url }}" hx-target="closest .persistent-file">
    Remove
  </button>
</div>
```

Override the template in your own `templates/conjunto/forms/_persistent_file.html`
to change the markup (e.g. Bootstrap card instead of inline row).

## Zero-Trust notes

- Files uploaded via this field inherit the storage backend of the
  consuming model/view. Use `conjunto.fields.ProtectedFileField` for
  sensitive data so files land in `PROTECTED_MEDIA_ROOT`, *never*
  under the public `MEDIA_ROOT`.
- The Remove button hits a URL *you* provide — **secure that view**.
  IDOR is the default failure mode of "delete by primary key": check
  that the caller owns the file. `conjunto.wizard.views.WizardFileDeleteView`
  is an example of the right pattern.

## Caveats

- `clean()` returns whatever `initial` is when no new upload happened.
  Downstream code must be prepared for either a fresh `UploadedFile`
  **or** whatever reference type was supplied as `initial`. Plain
  `ModelForm` consumers should convert to the final storage format in
  the view/`save()` call.
- The widget's "Replace" behaviour is a Bootstrap collapse, which
  requires Bootstrap JS (bundled via `conjunto_scripts`).
