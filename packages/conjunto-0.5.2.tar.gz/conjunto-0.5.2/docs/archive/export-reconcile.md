# ``archive_export`` and ``archive_reconcile``

Two helper commands to satisfy statutory obligations around tenant
data portability and restore safety.

## ``archive_export`` — tenant-scoped data export

Used for AVV handover and insolvency cases (FUDGE ruling). Exports
every archivable row + every ``ArchiveVersion`` for one tenant into a
directory full of NDJSON files.

```bash
uv run python manage.py archive_export \
  --tenant 42 \
  --output /srv/exports/tenant-42-2026-04-18/
```

Output layout:

```
<output>/<tenant-id>/
  manifest.json                # one entry per model file + SHA256
  myapp.Patient.ndjson         # one line per row and per ArchiveVersion
  myapp.Invoice.ndjson
  ...
```

Each file contains two flavours of record, distinguished by the
``kind`` field:

- ``kind: "row"`` — the primary (possibly soft-deleted) row, serialised
  as a plain dict.
- ``kind: "archive_version"`` — one ``ArchiveVersion`` snapshot,
  including the inlined ``revision_meta`` (reason code, user id, tenant
  id, timestamp).

### What is NOT exported

- ``DeletionLog`` rows. Deletions are audit-internal; they stay with
  the operator, not with the tenant handover.

### Read-only

The command never soft-deletes, hard-deletes, or writes a
``DeletionLog`` row. Running it twice produces identical SHA256 hashes
in the manifest (rows are ordered by primary key).

## ``archive_reconcile`` — restore-safety

```bash
uv run python manage.py archive_reconcile --dry-run
uv run python manage.py archive_reconcile
uv run python manage.py archive_reconcile --tenant 42
```

Use case: an operator restores a historical database backup that still
contains rows which ``archive_cleanup`` had already purged. Without
``archive_reconcile``, those rows would "zombie" back.

The command walks every ``DeletionLog`` entry, checks whether the
corresponding source row is back in the current database, and if so,
re-purges it under a fresh ``RetentionToken`` — writing a new
``DeletionLog`` entry with ``reason=reconcile_after_restore`` and
``triggered_by=archive_reconcile:<run-id>``.

### Idempotency

Running the command twice is safe: after the first run, the zombie row
is gone, so the second run finds no match and writes no log row.
