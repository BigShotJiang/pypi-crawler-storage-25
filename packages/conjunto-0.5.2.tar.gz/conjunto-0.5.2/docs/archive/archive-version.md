# `ArchiveVersion` and `ArchiveRevisionMeta`

> **Status:** Phase 2 of `conjunto.archive` — the JSON-snapshot layer.
> Soft-delete and optimistic locking live in Phase 1 (see
> [`archivable-mixin.md`](archivable-mixin.md)); revert UI + retention
> cleanup land in later phases.

Every `save()` / `delete()` / `restore()` on an `ArchivableMixin`
instance writes one `ArchiveVersion` row carrying a native-JSON
snapshot of the instance, paired with one `ArchiveRevisionMeta` row
that records who made the change, in which tenant, and why.

---

## TL;DR

```python
folder = Folder.objects.create(name="Inbox")
# Writes one ArchiveVersion with reason_code="create".

folder.name = "Archive"
folder.save()
# Writes a second ArchiveVersion with reason_code="update".

folder.delete(user=request.user)
# Writes a third version with reason_code="soft_delete".
```

All three versions are readable via the generic back-reference:

```python
from django.contrib.contenttypes.models import ContentType
from conjunto.archive.models import ArchiveVersion

ct = ContentType.objects.get_for_model(Folder)
history = ArchiveVersion.objects.filter(
    content_type=ct,
    object_id=str(folder.pk),
).order_by("created_at")

for v in history:
    print(v.revision_meta.reason_code, v.serialized_data)
```

---

## Schema

### `ArchiveVersion`

| Field             | Type                | Purpose                                                  |
|-------------------|---------------------|----------------------------------------------------------|
| `content_type`    | `FK(ContentType)`   | Points at the source model.                              |
| `object_id`       | `CharField(64)`     | Source row's PK, stringified (integer, UUID, composite). |
| `content_object`  | `GenericForeignKey` | Resolves to the live row (may be soft-deleted).          |
| `serialized_data` | `JSONField`         | Native JSON. Maps to Postgres JSONB / SQLite JSON1.      |
| `schema_version`  | `PositiveInteger`   | `archive_schema_version` at snapshot time.               |
| `revision_meta`   | `OneToOne`          | Per-revision user/tenant/reason context.                 |
| `created_at`      | `DateTimeField`     | Append-only creation timestamp.                          |

### `ArchiveRevisionMeta`

| Field         | Type               | Purpose                                   |
|---------------|--------------------|-------------------------------------------|
| `user`        | `FK(User)` nullable| Who caused the revision (SET_NULL).       |
| `tenant`      | `FK(Tenant)` null  | Tenant context (SET_NULL for anon admin). |
| `reason_code` | `CharField` choice | `create` / `update` / `soft_delete` / `restore` / `hard_delete_precursor`. |
| `comment`     | `TextField`        | Optional free-form note.                  |
| `created_at`  | `DateTimeField`    | Append-only creation timestamp.           |

Both tables are **append-only**: `.update()`, `.bulk_update()`,
`.delete()`, and `instance.save()`-after-PK raise
`TamperEvidenceViolation`.

---

## How snapshots are created

The pipeline is:

1. `ArchivableMixin.save()` finishes persisting the row.
2. `ArchivableMixin._create_snapshot(reason_code=...)` is invoked.
3. The snapshot helper reads the current `RevisionContext` (user,
   tenant, fallback reason) from the contextvar set by
   `RevisionContextMiddleware` or by `revision_context(...)`.
4. It serialises every concrete field of the instance (minus
   `row_version` and anything listed in `Archive.excluded_fields`)
   into a JSON-safe dict.
5. ForeignKey fields are captured as `{"pk": ...}`. Fields named in
   `Archive.follow_fk` get an additional `"repr": str(related)` entry.
6. `ArchiveVersion` and `ArchiveRevisionMeta` are written atomically.

### Configuring the snapshot

```python
from conjunto.archive import ArchivableMixin, CascadePolicy


class Invoice(ArchivableMixin, models.Model):
    number = models.CharField(max_length=32)
    total = models.DecimalField(max_digits=12, decimal_places=2)
    issued_to = models.ForeignKey("Customer", on_delete=models.PROTECT)

    # Phase-2 options:
    archive_schema_version = 1

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE_CASCADE

        # Include a human label for the FK target in each snapshot.
        follow_fk = ["issued_to"]

        # Fields that must never be persisted (derived/transient).
        # WARNING: Zero-Trust data pillar — never exclude medical or
        # financial values. Use only for derived/transient columns.
        excluded_fields: list[str] = []
```

---

## The `RevisionContext`

### Web requests

Install the middleware **after** the tenant middleware:

```python
MIDDLEWARE = [
    # ...
    "conjunto.tenants.middleware.TenantMiddleware",
    "conjunto.archive.middleware.RevisionContextMiddleware",
    # ...
]
```

The middleware reads `request.user` and `request.tenant` and binds them
into a `contextvars.ContextVar` for the lifetime of the request. HTMX
partial swaps go through the same middleware — no HTMX-specific
handling needed.

### Non-web callers (management commands, tasks)

```python
from conjunto.archive.middleware import revision_context

with revision_context(user=admin, reason_code="bulk_import"):
    for row in rows:
        row.save()
```

### No context

If no middleware and no `revision_context(...)` is active,
`user` and `tenant` are stored as `NULL` — a "system" event. The
snapshot itself is still written; the audit trail remains complete.

---

## Reverting (Phase 4 UI)

Phase 2 ships the infrastructure; the revert UI and Timeline widget
land in Phase 5. Programmatic revert looks like this:

```python
# Pseudocode — full revert view arrives in Phase 5.
version = ArchiveVersion.objects.filter(
    content_type=ct,
    object_id=str(invoice.pk),
).latest("created_at")

# Snapshot schema may be older than current model schema.
payload = apply_migrations(
    version.serialized_data,
    from_version=version.schema_version,
    to_version=Invoice.archive_schema_version,
    migrations=Invoice.Archive.archive_migrations,
)

for field_name, value in payload.items():
    setattr(invoice, field_name, value)
invoice.save()  # writes another ArchiveVersion with reason_code="update"
```

See [`schema-versioning.md`](schema-versioning.md) for the migration
chain contract.
