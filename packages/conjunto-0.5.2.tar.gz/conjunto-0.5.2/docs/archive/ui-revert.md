# Archive UI — timeline + revert

Phase 5 ships the end-user side of `conjunto.archive`:

- A chronological **timeline widget** that shows every snapshot for a
  single archivable row.
- A **revert flow** — confirmation modal + POST handler — that rewinds
  the row to any historical snapshot.
- Graceful degradation on **optimistic-locking conflicts** and
  **schema drift** via dedicated HTMX partials.

All three pieces are server-rendered with HTMX; no JavaScript beyond
what `conjunto/base.html` already ships is required in consumer apps.

## Embedding the timeline

The simplest integration is the inclusion template tag.  Load it once
at the top of the template, then drop the tag wherever the history
should appear:

```django
{% extends "medux/patient/detail.html" %}
{% load archive %}

{% block side_panel %}
  {{ block.super }}
  {% archive_timeline patient %}
{% endblock %}
```

The tag renders a Tabler card with:

- A heading (`Revision history`) and chronological Tabler `timeline`
  entries.
- Color-coded badges per `ReasonCode` — `create` green, `update` blue,
  `soft_delete` orange, `restore` info, `revert` purple.
- A **Revert** button on every non-current entry (hidden for the
  newest revision and for `revert` entries themselves so the history
  cannot spiral into a "revert chain").
- User + tenant attribution pulled from `ArchiveRevisionMeta`.
- A legacy banner ("No archive history available") when the row has no
  `ArchiveVersion` entries yet — used for rows that existed before the
  archive app landed.

Requirements on the instance:

- Must inherit from `conjunto.archive.ArchivableMixin`.
- Must have a primary key (`instance.pk is not None`).

Passing anything else raises `TypeError` at render time, so plugin
bugs surface loudly instead of rendering an empty card.

## The revert flow, step by step

```
 Timeline button  ──hx-get──▶  RevertConfirmView  (modal body)
                                      │
                                      │ user clicks "Revert"
                                      ▼
                                 RevertView  (POST)
                                      │
                 ┌────────────────────┼────────────────────┐
                 ▼                    ▼                    ▼
         204 + HX-Redirect      409 + stale        422 + unrevertable
         + showToast toast      conflict partial   partial
                 │                    │                    │
          browser reloads       modal swapped        modal swapped
          caller's page        with reload button    with error notice
```

1. **Timeline "Revert" button** issues `hx-get` against
   `conjunto_archive:revert-confirm` and swaps the response into
   `#dialog`.
2. The confirmation modal posts back to `conjunto_archive:revert` via
   `hx-post`. Users without the model's `change_*` permission see a
   `Permission required` notice instead of the submit button.
3. On success the view returns HTTP 204 plus an `HX-Redirect` back to
   the referrer and an `HX-Trigger: showToast` with the success
   message. The caller's page refreshes with the reverted data.
4. On `StaleObjectError` (another writer bumped `row_version`) the
   view returns the `_stale_conflict.html` partial with HTTP 409 so
   HTMX swaps the notice into `#dialog`. The user reloads the page
   and retries.
5. On `UnrevertableVersionError` (missing migration step, snapshot
   field no longer exists on the model, future schema version) the
   view returns `_unrevertable.html` with HTTP 422.

## Wiring the URLs

`conjunto.archive.urls` ships its own `app_name = "conjunto_archive"`
and is **not** automatically included by `conjunto.urls` (avoids a
forced namespace collision). Include it once from the project root
urlconf:

```python
# medux/urls.py
urlpatterns = [
    path("", include("conjunto.urls")),
    path("archive/", include("conjunto.archive.urls")),
    ...
]
```

URL names:

| Name                            | URL pattern                              | View                       |
|---------------------------------|------------------------------------------|----------------------------|
| `conjunto_archive:timeline`     | `<content_type_id>/<object_id>/`         | `ArchiveTimelineView`      |
| `conjunto_archive:revert-confirm` | `revert/confirm/<version_pk>/`         | `ArchiveRevertConfirmView` |
| `conjunto_archive:revert`       | `revert/<version_pk>/` (POST only)       | `ArchiveRevertView`        |

## Permissions

The confirm view and timeline are gated by `LoginRequiredMixin` only —
every authenticated user can *see* the history.  Actual reverts
require the caller to hold the model's `change_<model>` permission.
Conjunto's `tenant_admin` role holds the change permission for
tenant-scoped archivable models out of the box; plugin projects that
need more granular rules subclass `ArchiveRevertView` and override
`has_revert_permission()`.

## API surface: `ArchivableMixin.revert()`

```python
instance = Patient.objects.get(pk=pk)
version = instance.archive_versions.get(pk=version_pk)  # example lookup
instance.revert(version, user=request.user, comment="Correction per audit")
```

Behaviour:

- Reads `version.serialized_data` and replays `Archive.archive_migrations`
  forward if `version.schema_version < current archive_schema_version`.
- Writes field values back onto the instance.
- Calls the optimistic-lock `save()` path + writes a fresh snapshot
  with `reason_code='revert'`.
- Returns `self` so callers can chain.
- Raises `StaleObjectError` on a concurrent writer.
- Raises `UnrevertableVersionError` when the chain has a gap, when the
  snapshot references a field the model no longer has, or when the
  snapshot belongs to a different content type / object.

`revert()` itself never touches the request / response cycle; the
caller is responsible for any surrounding UI refresh.  The view layer
(`ArchiveRevertView`) does that automatically via `HX-Redirect`.

## Schematic: revert lifecycle

```
                            save()           revert()
 user  ──────►  instance  ──────────►  V1 ──────────►  V2
    (click "Revert")        (snapshot)         (new snapshot,
                                               reason='revert')

        row_version         row_version           row_version
            0          ➜         1         ➜          2
```

The revert itself becomes a first-class entry in the timeline, so an
unintended rollback can be undone by reverting to the "update" snapshot
that preceded it. Time travel through the archive is a cycle, not a
tree.
