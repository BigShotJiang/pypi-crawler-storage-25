# `ArchivableMixin` — Plugin Author's Guide (Phase 1)

> **Status:** Phase 1 of `conjunto.archive` — soft-delete, optimistic
> locking, and cascade policies. Snapshot / revert / retention cleanup
> land in later phases; the hooks for them are already in place.

This is the smallest conjunto primitive for making a model "archivable":
soft-delete (never physical delete by default), optimistic locking on
concurrent writes, and a controlled cascade policy.

The mixin is deliberately thin — four fields, three managers, one enum.
No external dependencies: no `django-safedelete`, no `django-reversion`,
no vendoring. All behaviour is defined inside `conjunto.archive`.

---

## TL;DR

```python
from django.db import models

from conjunto.archive import ArchivableMixin, CascadePolicy


class Patient(ArchivableMixin, models.Model):
    name = models.CharField(max_length=200)

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE_CASCADE
```

- `Patient.objects` — alive rows only (default).
- `Patient.all_objects` — alive + soft-deleted.
- `Patient.deleted_objects` — soft-deleted only.
- `patient.delete(user=request.user)` → marks the row deleted, cascades
  to archivable FK children.
- `patient.restore()` → undoes a soft-delete.
- `patient.hard_delete(retention_token=...)` → the only path to a
  physical delete. Requires a `RetentionToken` that only the scheduled
  cleanup command issues — plugin code cannot fabricate one.

---

## What the mixin adds to your model

| Field                | Type                    | Purpose                                   |
|----------------------|-------------------------|-------------------------------------------|
| `deleted_at`         | `DateTimeField`         | Soft-delete timestamp. `NULL` = alive.    |
| `deleted_by`         | `FK(User)` nullable     | Who soft-deleted the row.                 |
| `deleted_by_cascade` | `BooleanField`          | `True` if deleted by a parent cascade.    |
| `row_version`        | `PositiveIntegerField`  | Optimistic-locking counter.               |

Plus three managers (`objects`, `all_objects`, `deleted_objects`) and
one inner `Archive` class for per-model configuration.

---

## Choosing a `CascadePolicy`

The enum has five members. Only three are intended for plugin authors —
the other two are internal retention-cleanup vocabulary.

```text
What happens when code calls instance.delete()?
│
├── Is this a system singleton (vendor entry, tenant root, …)?
│   ├── YES  → CascadePolicy.NO_DELETE
│   │          (raises PermissionError on every delete call)
│   │
│   └── NO
│       │
│       ├── Does deleting the row logically delete its children?
│       │   (e.g. Patient → Diagnoses, Orders, Notes)
│       │   │
│       │   ├── YES → CascadePolicy.SOFT_DELETE_CASCADE  [default]
│       │   │
│       │   └── NO  → CascadePolicy.SOFT_DELETE
│       │              (children stay alive; only this row is archived)
```

Policies the plugin author does NOT set directly:

- `HARD_DELETE` / `HARD_DELETE_NOCASCADE` — vocabulary for the
  retention cleanup command (Phase 4). Plugin code declaring these on
  a model is a no-op: `instance.delete()` always goes through the
  soft-delete path; the only way to a physical delete is
  `hard_delete(retention_token=...)`, and tokens are not issuable from
  plugin code.

Default when `class Archive` is omitted: `SOFT_DELETE_CASCADE`.

---

## MRO and cooperative mixins

`ArchivableMixin` overrides `save()` and `delete()`. Other mixins that
do the same (e.g. a custom `AuditMixin`) must call `super()` properly.
Recommended MRO (left-to-right = highest priority to lowest):

```python
class Patient(TenantScopedMixin, AuditMixin, ArchivableMixin, models.Model):
    ...
```

Rule of thumb: **`ArchivableMixin` sits right before `models.Model`**.
Any mixin further left that overrides lifecycle methods cooperates via
`super()`.

---

## Optimistic locking

Every `save()` on an existing row runs an atomic

```sql
UPDATE <table> SET ..., row_version = <old> + 1
WHERE pk = <loaded_pk> AND row_version = <loaded_version>;
```

Zero rows affected ⇒ another writer already bumped the version ⇒
`StaleObjectError` is raised. Recovery strategy: reload, re-apply the
user's edit (or show a conflict UI), save again.

```python
from conjunto.archive import StaleObjectError

try:
    patient.name = "…"
    patient.save()
except StaleObjectError:
    patient.refresh_from_db()
    # show conflict UI, merge, retry
```

Phase 1 ships the raw mechanism; the form-level integration
(`OptimisticLockFormMixin`, `_stale_conflict.html`) lands in v1.5.

---

## Tamper-evidence guards

`ArchivableMixin` enforces two guards that matter for audit compliance:

1. **Default visibility excludes soft-deleted rows.** `.update()` and
   `.filter(...)` on the default manager will never hit a deleted row
   unless the caller explicitly opts in via `all_objects`.
2. **Audit log tables are append-only.** `ArchiveAccessLog` and
   `DeletionLog` use `AppendOnlyManager`, which raises
   `TamperEvidenceViolation` on any attempted `update()`,
   `bulk_update()`, or `delete()` — at the queryset AND instance level,
   including the `_base_manager` and `_default_manager` back-doors.

```python
from conjunto.archive.exceptions import TamperEvidenceViolation

ArchiveAccessLog.objects.filter(...).update(purpose="x")
# → TamperEvidenceViolation

log_entry.purpose = "x"
log_entry.save()
# → TamperEvidenceViolation (save after pk is set)
```

Phase 2 will layer Postgres triggers on top so even raw SQL cannot
tamper; Phase 1 is the DB-agnostic baseline.

---

## Hard delete (Zero Trust)

The only path to a physical delete is through `hard_delete()`, gated
by a `RetentionToken`. Plugin code cannot construct a valid token —
the constructor raises `RuntimeError` — and the factory
`RetentionToken.issue()` is meant to be called only from the scheduled
retention cleanup command (Phase 4).

Practical consequence for plugin authors: **you never call
`hard_delete()` yourself.** You call `delete()`; retention cleanup
later decides when (if ever) a physical delete happens.

---

## Phase-2 forward compatibility

The mixin already exposes `archive_schema_version: int` as a
class-level attribute and a `_create_snapshot(...)` no-op hook. Phase 2
will:

- bump `_create_snapshot` from a no-op to a real snapshot writer that
  stores a JSON row in `ArchiveVersion` (native JSONField);
- read `archive_schema_version` when reverting to a historical state so
  snapshots across schema-evolution boundaries can be migrated via a
  transform chain;
- wire `RevisionContextMiddleware` so snapshots carry the request
  user / tenant / correlation-ID automatically.

None of that requires a change to the plugin-facing API. A Phase-1
model written today will keep working without modification.

---

## Testing your own archivable model

A sample test pattern the conjunto test suite uses:

```python
@pytest.mark.django_db
def test_soft_delete_hides_from_default_manager(user):
    row = MyModel.objects.create(name="x")
    row.delete(user=user)

    assert MyModel.objects.filter(pk=row.pk).count() == 0
    assert MyModel.all_objects.filter(pk=row.pk).count() == 1
    row.refresh_from_db()
    assert row.deleted_at is not None
    assert row.deleted_by == user
```

Run with `uv run pytest`.
