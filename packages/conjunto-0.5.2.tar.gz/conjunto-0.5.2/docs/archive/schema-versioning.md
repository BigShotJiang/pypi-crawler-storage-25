# Snapshot schema versioning

> **Status:** Phase 2 of `conjunto.archive`.

When a plugin author changes the shape of an archivable model (renaming
a column, splitting a field, normalising units), every historical
snapshot taken before the change still holds the *old* shape. Reverting
to such a snapshot requires a migration chain so the caller ends up
with a row that fits today's model.

---

## The contract

Each archivable model has a class attribute
`archive_schema_version: int` (default `1`). Bump it whenever a field
is renamed, removed, split, or has its semantics changed. For every
version step you introduce, add one `ArchiveMigration` to
`Archive.archive_migrations`.

```python
from conjunto.archive import ArchivableMixin
from conjunto.archive.schema import ArchiveMigration


class Invoice(ArchivableMixin, models.Model):
    total = models.DecimalField(max_digits=12, decimal_places=2)

    # Bumped from 1 to 2 when ``amount`` was renamed to ``total``.
    archive_schema_version = 2

    class Archive:
        archive_migrations = [
            ArchiveMigration(
                from_version=1,
                to_version=2,
                migrate_fn=lambda d: {
                    **{k: v for k, v in d.items() if k != "amount"},
                    "total": d.get("amount", "0"),
                },
            ),
        ]
```

### Rules

1. **Single-step migrations only.** `to_version` must be
   `from_version + 1`. Composite jumps like `1 → 3` are rejected at
   startup.
2. **No gaps.** Versions from `1` up to `archive_schema_version - 1`
   must each appear exactly once as a `from_version`.
3. **Pure functions.** `migrate_fn(dict) -> dict` must be deterministic
   and side-effect-free. The pipeline may call it multiple times on
   the same snapshot (preview mode).
4. **Additive by default.** Prefer adding a new field with a sensible
   default over renaming/dropping an existing one; that way version
   bumps stay rare and historical queries remain painless.

---

## Startup validation

At Django startup (`AppConfig.ready`), `conjunto.archive` walks every
installed `ArchivableMixin` subclass whose `archive_schema_version` is
greater than `1` and calls
`conjunto.archive.schema.validate_migration_chain`. Missing steps,
duplicates, or multi-step jumps raise `ImproperlyConfigured` — the
deployment fails at boot rather than on the first revert attempt.

---

## Applying the chain

Revert code (Phase 5 UI) calls `apply_migrations` with the snapshot's
`schema_version` and the model's current version:

```python
from conjunto.archive.schema import apply_migrations

payload = apply_migrations(
    snapshot=version.serialized_data,
    from_version=version.schema_version,
    to_version=Invoice.archive_schema_version,
    migrations=Invoice.Archive.archive_migrations,
)
```

If a required step is somehow missing at runtime (shouldn't happen if
the startup validator ran), `ArchiveMigrationError` is raised.

---

## Testing your chain

A minimal unit test for each `migrate_fn`:

```python
def test_invoice_v1_to_v2_renames_amount_to_total():
    step = Invoice.Archive.archive_migrations[0]
    result = step.migrate_fn({"amount": "42.00", "other": 1})

    assert result == {"total": "42.00", "other": 1}
```

Combine with the end-to-end snapshot-then-revert test the Phase 5
revert view will land.
