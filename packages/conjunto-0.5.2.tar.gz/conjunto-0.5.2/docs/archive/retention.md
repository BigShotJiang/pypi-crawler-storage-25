# Retention Policy

Every soft-deleted row in ``conjunto.archive`` survives until its
retention window elapses. This page describes how the window is computed
and how to override it per model.

## Defaults

| Domain        | ``years`` | ``floor_years`` | Source                |
|---------------|-----------|-----------------|-----------------------|
| Medical       | 30        | 30              | § 51 ÄrzteG, § 1489 ABGB |
| Accounting    | 7         | 7               | § 132 UGB, § 212 BAO  |
| Framework default | 30    | 30              | Medical (err on the safe side) |

The framework default is the **medical** 30-year retention. A plugin
author building a non-medical model must explicitly override
``Archive.retention_floor_years`` (e.g. 7 for accounting).

## Anchor: ``deleted_at``

Retention is counted from the soft-delete timestamp, not from creation.
§ 1489 ABGB triggers when a party could first assert the claim — for
an archivable row that is the moment the row was removed from active
use, i.e. soft-deleted. A row that was never soft-deleted is never
expired, regardless of age.

## Per-model override

```python
from conjunto.archive import ArchivableMixin, CascadePolicy

class Invoice(ArchivableMixin, models.Model):
    ...

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE
        retention_years = 10          # desired length
        retention_floor_years = 7     # statutory minimum (accounting)
```

### Floor enforcement

``retention_years`` is silently clamped upward to ``retention_floor_years``
if it would otherwise undercut the floor. This is **not** an error: the
intent is to stop a plugin author's well-meaning "keep only for 10
years" from violating the 30-year medical retention floor.

## API

```python
from conjunto.archive.retention import policy_for_model

policy = policy_for_model(Invoice)
policy.retention_end_for(instance)   # -> date | None
policy.is_expired(instance)          # -> bool
```

``retention_end_for(instance)`` returns ``None`` for a live row and the
retention end date for a soft-deleted row. ``is_expired(instance)``
uses today's date (``timezone.localdate()``) by default; pass
``today=`` to inject a different date in tests.

## Lifecycle

1. A user soft-deletes a row — ``deleted_at = timezone.now()``.
2. Time passes.
3. ``archive_cleanup`` runs and finds the row via
   ``deleted_at__date__lte=cutoff_date``.
4. ``_hard_delete_cascade(token=...)`` atomically removes the row,
   every ``ArchiveVersion`` for it, and every ``ArchiveRevisionMeta``
   referenced by those versions.
5. A ``DeletionLog`` row is written (``reason=retention_expired``).

See [cleanup-command.md](cleanup-command.md) for operational details.
