# `TemporalMixin` — Plugin Author's Guide (Phase 3)

> **Status:** Phase 3 of `conjunto.archive`. Ships the temporal
> primitive for structured, queryable historization of values that
> change over time.

`TemporalMixin` is the second orthogonal versioning primitive in
`conjunto.archive`. Where `ArchivableMixin` writes a JSON snapshot
for audit purposes on every change, `TemporalMixin` keeps the row
itself around — every version is a real DB row with a validity range
that the application can query directly.

The two mixins combine freely:

```python
class PatientName(ArchivableMixin, TemporalMixin, models.Model):
    ...
```

---

## When to reach for `TemporalMixin`

Use it when the **history of a value is part of the business logic**,
not merely an audit requirement. Typical examples:

| Use case                   | Why temporal history matters                                 |
|----------------------------|--------------------------------------------------------------|
| `PatientName`              | Old invoices must show the name current at issue date.       |
| `PatientAddress`           | Letters mailed last year used the old address.               |
| `InsuranceContract`        | A claim from 2023 is evaluated against the 2023 policy.      |
| `TaxRate`                  | Invoices compute tax with the rate in force on their date.   |
| `PracticeOpeningHours`     | Historical calendar views need the hours that applied.       |

If the history is only relevant for **audit, liability, or §51 ÄrzteG**
compliance — not for active queries — reach for `ArchivableMixin`
alone. The entry in `docs/archive/choosing-a-primitive.md` walks through
the decision tree in detail.

---

## TL;DR

```python
from datetime import date
from decimal import Decimal

from django.db import models

from conjunto.archive import TemporalMixin


class TaxRate(TemporalMixin, models.Model):
    name = models.CharField(max_length=32)
    rate = models.DecimalField(max_digits=5, decimal_places=2)
```

```python
# Create the initial row. valid_from defaults to today, valid_to to None.
vat = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))

# Rate changes — close the old row, open a new one in one atomic step.
new_vat = vat.supersede(rate=Decimal("13.00"))

# Query what was valid on a historical date.
applicable = TaxRate.objects.at(date(2023, 4, 15)).get(name="VAT")

# Current view (only the open-ended, non-archived row).
current = TaxRate.current.get(name="VAT")
```

---

## What the mixin adds to your model

| Field        | Type                    | Purpose                                                              |
|--------------|-------------------------|----------------------------------------------------------------------|
| `valid_from` | `DateField` (indexed)   | Inclusive start of the validity range. Defaults to today.            |
| `valid_to`   | `DateField` (indexed, nullable) | Inclusive end of the range. `NULL` means "still current".     |
| `archived`   | `BooleanField` (indexed) | Retires the row without closing the range (see below).              |

Plus a check constraint (`valid_to IS NULL OR valid_to >= valid_from`),
a composite `(valid_from, valid_to)` index for the `.at(date)` hot
path, and two managers.

---

## The validity convention

The mixin ships **one** convention and documents it hard, because
inclusive-vs-exclusive confusion is the #1 source of temporal bugs.

- **`valid_from`** — inclusive. The row is valid *from* this day on.
- **`valid_to`** — inclusive last day. The row is valid *through* this
  day. `NULL` = no end, i.e. currently active.

Example: if you supersede today (`2026-04-19`):

```
old row:  valid_from = 2020-06-12,  valid_to = 2026-04-18   (inclusive last day)
new row:  valid_from = 2026-04-19,  valid_to = None         (currently active)
```

A row is active on day `D` iff `valid_from <= D AND (valid_to IS NULL OR valid_to >= D)`.
The `.at(date)` and `.valid_between(start, end)` helpers enforce exactly this.

---

## The two managers (Option C)

`TemporalMixin` ships two managers with deliberately different
contracts:

```python
PatientName.objects   # ALL rows (current + historical + archived)
PatientName.current   # pre-filtered to valid_to IS NULL AND archived=False
```

`objects` is the **default manager** and is fully transparent —
`PatientName.objects.all()` returns the entire history. This is
Django-conform and intentional: every historical row is **correct
data**, not soft-deleted data. Filtering it out by default would hide
rows from naive queries and cause the kind of "where is my row?"
bug that is hard to debug.

The historic query helpers live on `objects` (the full-history
manager):

| Method                            | Returns                                                                 |
|-----------------------------------|-------------------------------------------------------------------------|
| `.at(date)`                       | Rows active on ``date``.                                                |
| `.valid_between(start, end)`      | Rows whose validity overlaps ``[start, end]``.                          |
| `.history_for(**lookups)`         | All rows matching ``lookups``, chronologically (``valid_from ASC``).    |

`current` is a plain, pre-filtered manager. It does NOT expose the
historic helpers — `.at(date)` on a single-row view of the data would
be misleading.

**Why not a single filtering default manager?** Because for
`TemporalMixin` every version is legitimate data. An invoice from 2024
referring to the old last name is correct. Hiding historical rows by
default would punish the common "give me all versions" query, which
is how the mixin earns its keep.

This is the opposite contract to `ArchivableMixin`, where soft-deleted
rows *are* filtered by default — there, the soft-deleted row is "gone"
from an application standpoint.

---

## Supersede: closing the old, opening the new

`supersede(**new_values)` is the **atomic** one-step transition for
replacing the currently-valid row with a successor.

```python
# Patient changes her last name on marriage.
name = patient.names(manager="current").get()
# Or, via the model-level manager:
#   name = PatientName.current.get(patient=patient)

new_name = name.supersede(last_name="Mueller")
# old name:  valid_to = today - 1
# new name:  valid_from = today, valid_to = None
```

### What `supersede()` does, step by step

1. Acquires a `SELECT ... FOR UPDATE` on the row to serialize concurrent callers.
2. Re-reads `valid_to` and `archived` to confirm the row is still the current one.
3. Confirms at least one of `new_values` actually changes a field. If every value equals the current row's value, raises `ValueError` — an identical successor would pollute the history with no new information.
4. Sets `self.valid_to = today() - 1 day` and saves.
5. Builds a successor by copying every non-PK concrete field, overlaying `new_values`, resetting `valid_from=today()`, `valid_to=None`, `archived=False` (and, if combined with `ArchivableMixin`, `deleted_at=None`, `row_version=0`).
6. Saves the successor.
7. Returns the successor.

All seven steps run inside a single `transaction.atomic()` block. If
the successor save fails, the `valid_to` update on the old row rolls
back automatically.

### When `supersede()` raises `ValueError`

- **Called on a closed row** (`valid_to IS NOT NULL`).
- **Called on an archived row** (`archived=True`).
- **Called with no kwargs**, or with kwargs that all equal the current values.
- **Called on a row that was concurrently deleted** (the `SELECT FOR UPDATE` finds no row).

### Concurrency

Two concurrent `supersede()` calls on the same row serialise on the
`SELECT FOR UPDATE`: the first commit wins, the second sees `valid_to`
already set and raises `ValueError`. On SQLite (no row-level locks)
the second transaction may hit the `valid_range` `CheckConstraint`
on the successor's validity instead — either way, the invariant holds.

---

## Archive: retiring without closing

`archive()` flips the `archived` flag on a row. The row drops out of
`current` but its `valid_from` / `valid_to` are untouched, so
historical queries still see it.

Useful when a row was published but should not apply any more:

```python
# Tax rate was announced but withdrawn before its effective date.
rate = TaxRate.objects.get(...)
rate.archive()

assert rate not in TaxRate.current.all()
# but still retrievable via the full-history manager:
assert rate in TaxRate.objects.all()
```

---

## Combination with `ArchivableMixin`

Combining the two mixins stacks audit-JSON snapshotting on top of
structured history:

```python
class PatientName(ArchivableMixin, TemporalMixin, models.Model):
    patient = models.ForeignKey(Patient, related_name="names",
                                on_delete=models.PROTECT)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)

    archive_schema_version = 1

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE
        retention_years = 30
        follow_fk = ["patient"]
```

### What the combination gives you

- **Two snapshots per `supersede()`**: one `update` snapshot for the
  closed row (capturing `valid_to`), one `create` snapshot for the
  successor.
- **Soft-delete is orthogonal to temporal validity.** Soft-deleting a
  temporal row sets `deleted_at` but leaves `valid_from` / `valid_to`
  untouched — the history is still factually true.
- **Cascade soft-delete does NOT supersede temporal children.** When a
  non-temporal `Patient` (with `SOFT_DELETE_CASCADE`) is soft-deleted,
  every `PatientName` child is soft-deleted as well (its `deleted_at`
  is set), but the validity range stays. No successor row is created.
  Rationale: the historical name is still correct on the old invoices;
  only the parent is "gone".

### MRO rules

- `ArchivableMixin` **must** come before `TemporalMixin` in the MRO, so
  the save-hook in `ArchivableMixin` wraps the `save()` that
  `supersede()` issues.
- Both mixins must come before `models.Model`.

---

## Writing to `valid_to` directly

Nothing in the mixin blocks a caller from setting `valid_to` by hand:

```python
rate.valid_to = date(2025, 12, 31)
rate.save()
```

This bypasses the supersede semantics (no atomicity, no successor is
created, no snapshot is issued for a successor). **Use only for data
migrations, admin fixes, or explicit one-shot corrections.** Normal
business logic uses `supersede()`.

Documented as an escape hatch rather than an API surface. The audit
trail (if `ArchivableMixin` is combined in) will capture the write
as a regular update snapshot.

---

## Escape-hatch: explicit `valid_from`

The default of `valid_from = today()` covers the common case. When a
row needs to start from a known historical date (data import, catch-up
seeding), pass it explicitly:

```python
TaxRate.objects.create(
    name="VAT",
    rate=Decimal("20.00"),
    valid_from=date(2020, 1, 1),
    valid_to=date(2021, 12, 31),
)
```

---

## Use-case recap

| Model                  | Mixins                           | Notes                                                         |
|------------------------|----------------------------------|---------------------------------------------------------------|
| `PatientName`          | `ArchivableMixin + TemporalMixin`| Marriage, legal name change. Audit AND queryable history.     |
| `PatientAddress`       | `ArchivableMixin + TemporalMixin`| Move, return address for old letters.                         |
| `InsuranceContract`    | `TemporalMixin`                  | History is business-critical; audit less so.                  |
| `TaxRate`              | `TemporalMixin`                  | Purely fiscal; no user associated with a rate change.         |
| `Diagnosis`            | `ArchivableMixin`                | Corrections create new rows; no date-slice query pattern.     |

---

## Testing your own temporal model

A typical test pattern:

```python
import pytest
from datetime import date

from my_app.models import MyTemporal


@pytest.mark.django_db
def test_supersede_closes_old_and_opens_new():
    v1 = MyTemporal.objects.create(name="x", value=1)
    v2 = v1.supersede(value=2)

    v1.refresh_from_db()
    assert v1.valid_to is not None
    assert v2.valid_from > v1.valid_to
    assert v2.valid_to is None
    assert v2.value == 2


@pytest.mark.django_db
def test_at_date_returns_historical_version():
    MyTemporal.objects.create(
        name="x", value=1,
        valid_from=date(2020, 1, 1), valid_to=date(2020, 12, 31),
    )
    MyTemporal.objects.create(name="x", value=2, valid_from=date(2021, 1, 1))

    assert MyTemporal.objects.at(date(2020, 6, 15)).get().value == 1
    assert MyTemporal.objects.at(date(2023, 6, 15)).get().value == 2
```

Run with `uv run pytest`.
