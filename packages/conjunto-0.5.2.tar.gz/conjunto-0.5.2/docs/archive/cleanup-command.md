# ``archive_cleanup`` — scheduled retention cleanup

Management command that purges soft-deleted rows whose
:doc:`retention <retention>` window has elapsed.

## Why a management command, never an HTTP API

Patent design-around (DOLORES): public HTTP endpoints for "bulk delete"
are a patent minefield. We route retention through ``manage.py`` and
operate it from systemd / cron. All user-facing documentation refers
to the feature as "scheduled retention cleanup", never as a "bulk
delete API" or "retention service endpoint".

## Usage

```bash
# Dry run across all tenants + models
uv run python manage.py archive_cleanup --dry-run

# Restrict to one model
uv run python manage.py archive_cleanup --model myapp.Patient

# Restrict to one tenant
uv run python manage.py archive_cleanup --tenant 42

# Safety valve: cap the number of rows purged in one run
uv run python manage.py archive_cleanup --limit 500
```

## What one purge does, per row

1. Open a ``cleanup_context()`` scope (Zero-Trust application-pillar
   gate). Inside, ``RetentionToken.issue()`` succeeds; outside, it
   raises ``PermissionError``.
2. Issue a fresh :class:`RetentionToken`.
3. Call ``instance._hard_delete_cascade(token=...)``. Inside:
   - ``privileged_purge(retention_token=token)`` consumes the token
     once (``validate_or_raise``) and opens a scope in which the
     tamper-evident log tables may be DELETEd.
   - ``ArchiveVersion`` rows for this instance are purged.
   - ``ArchiveRevisionMeta`` rows referenced by those versions are
     purged.
   - The source instance itself is physically deleted.
4. Write a ``DeletionLog`` entry with ``reason=retention_expired`` and
   ``triggered_by=archive_cleanup:<run-id>``.

## Concurrency

- **Postgres**: each row scan uses ``SELECT ... FOR UPDATE SKIP LOCKED``
  with ``lock_timeout = 30s`` so concurrent runs cannot deadlock on the
  same tenant.
- **SQLite + others**: ``select_for_update(skip_locked=True)`` is a
  no-op; retention cleanup is still safe because each purge runs in a
  transaction and the DeletionLog entry is idempotent.

## Identity (Zero-Trust)

The command runs under the **system** actor, not a user. ``DeletionLog``
records ``triggered_by = "archive_cleanup:<run-id>"``. The ``run-id``
is a short uuid that distinguishes one run from another — useful for
log correlation.

## Monitoring

Minimal by design:

- ``logger.info`` / ``logger.error`` on the ``conjunto.archive`` logger.
- No Healthchecks ping, no weekly summary, no metric export.

If you want richer observability, add a handler on your Django logging
config that forwards the ``conjunto.archive`` logger wherever you need
it. The command deliberately does not ship integrations.
