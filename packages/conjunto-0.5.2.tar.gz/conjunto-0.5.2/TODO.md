# TODO

- **ScopedSetting: MariaDB-kompatible Uniqueness via `GeneratedField`.**
  Partielle `UniqueConstraint`s + `Coalesce("site_id", 0)` lösen auf MariaDB W036/W044 aus (keine DB-seitige Durchsetzung).
  Ersatz: eine `STORED GeneratedField`-Spalte `unique_key` (z. B. `scope:namespace:key:user_id:group_id:device_id:tenant_id:site_id` mit `COALESCE(..., 0)`) und ein einziger unbedingter `UniqueConstraint(fields=["unique_key"])`.
  Funktioniert cross-DB (MariaDB/MySQL/Postgres/SQLite), ersetzt die fünf pro-Scope-Constraints.
