# Third-Party Licenses

Conjunto itself is released under the MIT license (see `LICENSE`).

The following third-party components may be **bundled with the built
distribution** (downloaded by consumer projects via
`python manage.py update_libraries` into `<CONJUNTO_VENDOR_DIR>/`,
using the registry pinned in `src/conjunto/_vendor/registry.py`) and
are covered by their own licenses. Their full license texts are
distributed alongside their assets.

---

## TinyMCE (Community Edition)

- **Upstream:** https://github.com/tinymce/tinymce
- **Version bundled:** 7.x (pinned in `src/conjunto/_vendor/registry.py` as
  `TINYMCE_VERSION`)
- **Copyright:** Copyright (c) 2024 Ephox Corporation DBA Tiny
  Technologies, Inc.
- **License:** GNU General Public License v2.0 or later (GPL-2.0-or-later)
- **Bundled license text:** `<CONJUNTO_VENDOR_DIR>/tinymce/LICENSE.TXT` (in consumer projects, after `python manage.py update_libraries tinymce`)

TinyMCE is distributed under the terms of the GNU General Public
License version 2 or (at your option) any later version. When you
redistribute Conjunto together with the TinyMCE assets, you must:

1. Ship the `LICENSE.TXT` file that comes inside the TinyMCE package.
   `src/conjunto/_vendor/registry.py` extracts it automatically — do not
   remove it.
2. Provide the complete corresponding source code of TinyMCE, or a
   written offer to do so. Since Conjunto downloads the **unmodified**
   official npm tarball from `registry.npmjs.org/tinymce`, a pointer
   to the upstream tarball URL (pinned by version in
   `src/conjunto/_vendor/registry.py`) satisfies this requirement.
3. Preserve the copyright notice above.

TinyMCE is used **only as Community Edition**. No commercial features,
no cloud/CDN integration, no API key is used. The editor is initialised
with `license_key: 'gpl'` as required by TinyMCE v7.

### GPLv2 interaction with Conjunto's MIT license

Conjunto links to TinyMCE dynamically at runtime through the browser
(separate `<script>` tags on a web page). TinyMCE is not statically
linked into Conjunto's Python/Django codebase. Consumers who wish to
avoid GPLv2 obligations in their own application can opt out of the
TinyMCE integration by simply not calling
`{% conjunto_require_tinymce %}` and not listing `tinymce` in
`CONJUNTO_LIBRARIES` (so `python manage.py update_libraries` never
fetches it).
