"""Phase-3 tests for ``TemporalMixin.supersede()``.

Covers the happy path (closing the old row, opening a new row),
validation rules (``ValueError`` on non-current or no-op), and atomicity
(the transaction rolls back on failure during creation of the successor).
"""

from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

import pytest
from django.utils import timezone

from tests.test_app.temporal_models import TaxRate


@pytest.mark.django_db
def test_supersede_happy_path_closes_old_and_opens_new():
    old = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))
    old_pk = old.pk

    new = old.supersede(rate=Decimal("19.00"))

    old.refresh_from_db()
    # Convention: old valid_to = today - 1 day (inclusive last day),
    # new valid_from = today. Use ``timezone.localdate()`` — same source
    # as the model default (see ``TemporalMixin._today``).
    today = timezone.localdate()
    assert old.valid_to == today - timedelta(days=1)
    assert new.valid_from == today
    assert new.valid_to is None
    assert new.pk != old_pk
    assert new.rate == Decimal("19.00")
    # Unchanged fields are copied through.
    assert new.name == old.name


@pytest.mark.django_db
def test_supersede_returns_new_instance():
    old = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))
    result = old.supersede(rate=Decimal("13.00"))
    assert isinstance(result, TaxRate)
    assert result.pk is not None


@pytest.mark.django_db
def test_supersede_on_closed_row_raises():
    """A row that already has ``valid_to`` set is no longer current;
    supersede is not allowed."""
    closed = TaxRate.objects.create(
        name="VAT",
        rate=Decimal("20.00"),
        valid_from=date(2020, 1, 1),
        valid_to=date(2021, 12, 31),
    )

    with pytest.raises(ValueError, match="current row"):
        closed.supersede(rate=Decimal("13.00"))


@pytest.mark.django_db
def test_supersede_on_archived_row_raises():
    live = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))
    live.archive()

    with pytest.raises(ValueError, match="current row"):
        live.supersede(rate=Decimal("13.00"))


@pytest.mark.django_db
def test_supersede_without_changes_raises():
    """A successor that copies every field unchanged is a sinnloser
    record — reject before the DB write."""
    rate = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))

    with pytest.raises(ValueError, match="at least one field"):
        rate.supersede(rate=Decimal("20.00"))


@pytest.mark.django_db
def test_supersede_with_no_kwargs_raises():
    rate = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))

    with pytest.raises(ValueError, match="at least one field"):
        rate.supersede()


@pytest.mark.django_db
def test_supersede_is_atomic(monkeypatch):
    """If creating the successor fails, the closed ``valid_to`` on the
    original row must be rolled back."""
    old = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))
    assert old.valid_to is None

    # Force the successor ``save`` to fail.
    import tests.test_app.temporal_models as tm

    real_save = tm.TaxRate.save
    calls = {"count": 0}

    def flaky_save(self, *args, **kwargs):
        calls["count"] += 1
        if calls["count"] == 2:  # first save = old update, second = new insert
            raise RuntimeError("simulated failure")
        return real_save(self, *args, **kwargs)

    monkeypatch.setattr(tm.TaxRate, "save", flaky_save)

    with pytest.raises(RuntimeError):
        old.supersede(rate=Decimal("13.00"))

    old.refresh_from_db()
    # Rolled back: valid_to must still be None.
    assert old.valid_to is None


@pytest.mark.django_db
def test_supersede_chained_twice():
    """Three generations — each supersede() closes the previous one
    and opens a fresh current row."""
    gen1 = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))
    gen2 = gen1.supersede(rate=Decimal("19.00"))
    gen3 = gen2.supersede(rate=Decimal("13.00"))

    gen1.refresh_from_db()
    gen2.refresh_from_db()

    assert gen1.valid_to is not None
    assert gen2.valid_to is not None
    assert gen3.valid_to is None
    assert TaxRate.current.count() == 1
    assert TaxRate.current.get().pk == gen3.pk


@pytest.mark.django_db
def test_supersede_preserves_unchanged_fields():
    rate = TaxRate.objects.create(name="Standard-VAT", rate=Decimal("20.00"))
    new = rate.supersede(rate=Decimal("13.00"))
    assert new.name == "Standard-VAT"
