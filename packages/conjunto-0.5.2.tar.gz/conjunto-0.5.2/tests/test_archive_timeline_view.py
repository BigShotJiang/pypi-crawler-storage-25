"""Phase-5 tests — ``ArchiveTimelineView`` + template tag.

Covers rendering for populated + empty timelines, LoginRequired
gating, the 404 path on unknown content type / object, and the
``{% archive_timeline %}`` template tag.
"""

from __future__ import annotations

import pytest
from django.contrib.contenttypes.models import ContentType
from django.template import Context, Template
from django.urls import reverse

from tests.test_app.archivable_models import Folder


@pytest.fixture
def user(db, django_user_model):
    return django_user_model.objects.create_user(username="erin", password="pw")


@pytest.fixture
def folder(db):
    return Folder.objects.create(name="Inbox")


def _timeline_url(folder):
    ct = ContentType.objects.get_for_model(Folder)
    return reverse("conjunto_archive:timeline", args=[ct.pk, folder.pk])


# --------------------------------------------------------------------------- #
# View rendering
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_timeline_view_requires_login(client, folder):
    response = client.get(_timeline_url(folder))
    assert response.status_code in (302, 401)


@pytest.mark.django_db
def test_timeline_view_renders_for_populated_row(client, user, folder):
    folder.name = "Archive"
    folder.save()

    client.force_login(user)
    response = client.get(_timeline_url(folder))
    assert response.status_code == 200
    body = response.content.decode()

    # Reason labels from ReasonCode enum.
    assert "Row created" in body
    assert "Row updated" in body
    # Container id used by HTMX target.
    assert f'id="archive-timeline-{folder.pk}"' in body


@pytest.mark.django_db
def test_timeline_view_shows_legacy_banner_on_empty_history(client, user, folder):
    """Wipe the auto-created ArchiveVersion to simulate a legacy row.

    Legacy rows (created before ``ArchivableMixin`` shipped) have no
    ``ArchiveVersion`` entries. The timeline must surface the info
    banner in that case so the end-user understands why there is no
    history yet.
    """
    from conjunto.archive.managers.append_only import privileged_purge
    from conjunto.archive.models import ArchiveRevisionMeta, ArchiveVersion
    from conjunto.archive.retention.token import (
        RetentionToken,
        cleanup_context,
    )

    ct = ContentType.objects.get_for_model(Folder)
    with cleanup_context():
        token = RetentionToken.issue(purpose="test-wipe")
    with privileged_purge(retention_token=token):
        meta_ids = list(
            ArchiveVersion.objects.filter(
                content_type=ct, object_id=str(folder.pk)
            ).values_list("revision_meta_id", flat=True)
        )
        ArchiveVersion.objects.filter(
            content_type=ct, object_id=str(folder.pk)
        ).retention_purge()
        if meta_ids:
            ArchiveRevisionMeta.objects.filter(pk__in=meta_ids).retention_purge()

    client.force_login(user)
    response = client.get(_timeline_url(folder))
    assert response.status_code == 200
    body = response.content.decode()
    assert "No archive history available" in body


@pytest.mark.django_db
def test_timeline_view_404_for_unknown_content_type(client, user, folder):
    client.force_login(user)
    url = reverse("conjunto_archive:timeline", args=[9999, folder.pk])
    response = client.get(url)
    assert response.status_code == 404


@pytest.mark.django_db
def test_timeline_view_404_for_non_archivable_content_type(client, user, folder):
    from django.contrib.auth import get_user_model

    client.force_login(user)
    User = get_user_model()
    ct = ContentType.objects.get_for_model(User)
    url = reverse("conjunto_archive:timeline", args=[ct.pk, user.pk])
    response = client.get(url)
    assert response.status_code == 404


@pytest.mark.django_db
def test_timeline_view_404_for_missing_object(client, user, folder):
    client.force_login(user)
    ct = ContentType.objects.get_for_model(Folder)
    url = reverse("conjunto_archive:timeline", args=[ct.pk, 999999])
    response = client.get(url)
    assert response.status_code == 404


# --------------------------------------------------------------------------- #
# Template tag
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_archive_timeline_template_tag_renders_versions(rf, user, folder):
    folder.name = "Archive"
    folder.save()

    request = rf.get("/")
    request.user = user
    tpl = Template("{% load archive %}{% archive_timeline folder %}")
    rendered = tpl.render(Context({"folder": folder, "request": request}))
    assert "Row created" in rendered
    assert "Row updated" in rendered
    assert f'id="archive-timeline-{folder.pk}"' in rendered


@pytest.mark.django_db
def test_archive_timeline_template_tag_rejects_non_archivable(rf, user):
    from django.contrib.auth import get_user_model

    User = get_user_model()
    non_arch = User.objects.create_user(username="plain", password="pw")

    request = rf.get("/")
    request.user = user
    tpl = Template("{% load archive %}{% archive_timeline obj %}")
    with pytest.raises(TypeError):
        tpl.render(Context({"obj": non_arch, "request": request}))
