import django
import pytest
import tempfile
from pathlib import Path


def pytest_configure(config):
    from django.conf import settings

    if settings.configured:
        return

    BASE_DIR = Path(__file__).resolve().parent

    settings.configure(
        SECRET_KEY="test",
        BASE_DIR=BASE_DIR,
        DATABASES={
            "default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}
        },
        INSTALLED_APPS=[
            "django.contrib.admin",
            "django.contrib.auth",
            "django.contrib.contenttypes",
            "django.contrib.messages",
            "django.contrib.sessions",
            "django.contrib.sites",
            "gdaps",
            "conjunto",
            "conjunto.archive",
            "conjunto.tenants",
            "conjunto.settings",
            "conjunto.profiles",
            "conjunto.wizard",
            "conjunto.shortcuts",
            "conjunto.extensible_forms",
            "crispy_forms",
            "crispy_bootstrap5",
            "django_htmx",
            "django_tables2",
            "statici18n",
            "tests.test_app",
            "tests",
        ],
        AUTH_USER_MODEL="tests.TestUser",
        MIDDLEWARE=[
            "django.contrib.sessions.middleware.SessionMiddleware",
            "django.contrib.auth.middleware.AuthenticationMiddleware",
            "django.contrib.messages.middleware.MessageMiddleware",
            "django_htmx.middleware.HtmxMiddleware",
            "conjunto.middleware.ConjuntoMessagesMiddleware",
        ],
        ROOT_URLCONF="tests.test_app.urls",
        LOGIN_URL="/accounts/login/",
        CONJUNTO_TENANT_MODEL="conjunto_tenants.Tenant",
        CRISPY_TEMPLATE_PACK="bootstrap5",
        CRISPY_ALLOWED_TEMPLATE_PACKS="bootstrap5",
        PLUGIN1={"OVERRIDE": 20},
        PROJECT_NAME="conjunto",
        PROJECT_TITLE="Foo Bar",
        MEDIA_ROOT=tempfile.mkdtemp(prefix="conjunto_media_"),
        MEDIA_URL="/media/",
        PROTECTED_MEDIA_ROOT=tempfile.mkdtemp(prefix="conjunto_protected_"),
        PROTECTED_MEDIA_URL="/protected/",
        TIME_ZONE="Europe/Vienna",
        USE_TZ=True,
        TEMPLATES=[
            {
                "BACKEND": "django.template.backends.django.DjangoTemplates",
                "DIRS": [BASE_DIR / "templates"],
                "APP_DIRS": True,
                "OPTIONS": {
                    "context_processors": [
                        "django.template.context_processors.request",
                        "django.contrib.auth.context_processors.auth",
                        "django.contrib.messages.context_processors.messages",
                        "conjunto.context_processors.globals",
                    ],
                },
            },
        ],
    )

    django.setup()


@pytest.fixture
def terms_conditions_page(db):
    """Make sure that one TermsAndConditionsPage exists."""
    from conjunto.cms.models import TermsConditionsPage

    return TermsConditionsPage.objects.create(
        title="Terms and Conditions",
        body="Terms and conditions content",
        version=1,
    )


def _truncate_tenants():
    """Hard-truncate the tenant table for an empty starting state.

    ``Tenant.objects.all().delete()`` cascades into the
    ``DeletionLog.tenant`` FK (``on_delete=SET_NULL``) which trips the
    append-only manager guard regardless of whether any DeletionLog
    rows exist. We bypass the ORM and clear at the SQL layer instead;
    we clear all dependent tenant-FK tables first so SQLite's deferred
    FK check on teardown stays happy. DeletionLog rows are not touched
    — its tenant FK is nullable and append-only forbids any SQL UPDATE
    we'd need anyway; in fresh test DBs the table is empty.
    """
    from django.db import connection

    from conjunto.tenants.utils import get_tenant_model

    Tenant = get_tenant_model()
    dependents: list[str] = []
    for field in Tenant._meta.get_fields():
        if field.is_relation and field.auto_created and not field.concrete:
            related = field.related_model
            if related._meta.label == "conjunto_archive.DeletionLog":
                continue
            dependents.append(related._meta.db_table)
    with connection.cursor() as cursor:
        for table in dependents:
            cursor.execute(f'DELETE FROM "{table}"')
        cursor.execute(f'DELETE FROM "{Tenant._meta.db_table}"')


@pytest.fixture
def clean_tenants(db):
    """Remove the post_migrate-seeded ``Admin`` tenant.

    Opt-in fixture for tests that assume an empty tenant table or a
    specific tenant set. Most tests benefit from the seed tenant, so
    only the tests that explicitly count tenants or compare full
    tenant sets need this fixture.
    """
    _truncate_tenants()
    yield


@pytest.fixture
def no_auto_membership():
    """Disconnect the auto-create-home-Membership ``post_save`` signal.

    Opt-in fixture for tests that explicitly want a user with **no**
    :class:`~conjunto.tenants.models.TenantMembership` (or only the
    memberships the test creates itself). The default behaviour after
    Task 5 of the tenant-FK refactor is that every newly created user
    gets an idempotent membership in their home tenant, which breaks
    the historic "user with zero memberships" assumption many tests
    were written against.
    """
    from django.db.models.signals import post_save
    from django.conf import settings
    from conjunto.tenants.signals import _create_home_membership

    post_save.disconnect(
        _create_home_membership,
        sender=settings.AUTH_USER_MODEL,
        dispatch_uid="conjunto_tenants_home_membership",
    )
    try:
        yield
    finally:
        post_save.connect(
            _create_home_membership,
            sender=settings.AUTH_USER_MODEL,
            dispatch_uid="conjunto_tenants_home_membership",
        )
