"""Phase-3 tests for ``conjunto.archive.mixins.temporal.TemporalMixin``.

Covers field defaults, lifecycle (create, archive), and the two
managers (``objects`` sees all, ``current`` sees only active rows).
"""

from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

import pytest
from django.utils import timezone

from tests.test_app.temporal_models import TaxRate


@pytest.mark.django_db
def test_valid_from_defaults_to_today():
    rate = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))
    assert rate.valid_from == timezone.localdate()


@pytest.mark.django_db
def test_valid_to_defaults_to_none():
    rate = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))
    assert rate.valid_to is None


@pytest.mark.django_db
def test_archived_defaults_to_false():
    rate = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))
    assert rate.archived is False


@pytest.mark.django_db
def test_archive_sets_archived_flag_without_touching_valid_to():
    rate = TaxRate.objects.create(name="VAT", rate=Decimal("20.00"))
    original_valid_to = rate.valid_to

    rate.archive()

    rate.refresh_from_db()
    assert rate.archived is True
    assert rate.valid_to == original_valid_to


@pytest.mark.django_db
def test_explicit_valid_from_and_valid_to():
    start = date(2020, 1, 1)
    end = date(2021, 12, 31)
    rate = TaxRate.objects.create(
        name="OldVAT",
        rate=Decimal("19.00"),
        valid_from=start,
        valid_to=end,
    )
    assert rate.valid_from == start
    assert rate.valid_to == end


@pytest.mark.django_db
def test_valid_to_equal_to_valid_from_allowed():
    """Single-day record — edge case but legal."""
    d = date(2026, 4, 19)
    rate = TaxRate.objects.create(
        name="Flash",
        rate=Decimal("10.00"),
        valid_from=d,
        valid_to=d,
    )
    assert rate.valid_from == d
    assert rate.valid_to == d


@pytest.mark.django_db
def test_objects_manager_sees_all_rows():
    """Option C: objects is the transparent default manager."""
    yesterday = timezone.localdate() - timedelta(days=1)
    TaxRate.objects.create(
        name="old",
        rate=Decimal("20.00"),
        valid_from=date(2020, 1, 1),
        valid_to=yesterday,
    )
    TaxRate.objects.create(name="new", rate=Decimal("22.00"))

    assert TaxRate.objects.count() == 2


@pytest.mark.django_db
def test_current_manager_filters_to_active_only():
    yesterday = timezone.localdate() - timedelta(days=1)
    TaxRate.objects.create(
        name="old",
        rate=Decimal("20.00"),
        valid_from=date(2020, 1, 1),
        valid_to=yesterday,
    )
    TaxRate.objects.create(name="new", rate=Decimal("22.00"))

    assert TaxRate.current.count() == 1
    assert TaxRate.current.get().name == "new"


@pytest.mark.django_db
def test_current_manager_excludes_archived_rows():
    """An archived row must not appear in ``current`` even if
    ``valid_to`` is still NULL — the ``archived`` flag is an explicit
    override."""
    rate = TaxRate.objects.create(name="live", rate=Decimal("22.00"))
    assert TaxRate.current.count() == 1

    rate.archive()

    assert TaxRate.current.count() == 0
    assert TaxRate.objects.count() == 1
