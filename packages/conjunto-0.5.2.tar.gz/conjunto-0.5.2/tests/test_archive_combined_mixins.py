"""Phase-3 tests for combined ``ArchivableMixin + TemporalMixin`` models.

Covers:
- MRO resolution (no AttributeError, no field clash).
- ``supersede()`` triggers the Phase-2 snapshot hook for both rows.
- Soft-delete of a temporal row sets ``deleted_at`` but leaves
  ``valid_to`` untouched.
- Cascade soft-delete of a non-temporal parent cascades to temporal
  children without calling supersede on them.
"""

from __future__ import annotations

from decimal import Decimal

import pytest
from django.contrib.contenttypes.models import ContentType
from django.utils import timezone

from conjunto.archive.models import ArchiveVersion

from tests.test_app.temporal_models import (
    CombinedRate,
    TemporalChild,
    TemporalParent,
)


# --------------------------------------------------------------------------- #
# MRO
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_combined_mro_creates_row_with_all_fields():
    """ArchivableMixin (soft-delete + row_version) + TemporalMixin
    (valid_from/valid_to/archived) cooperate — all six fields present."""
    obj = CombinedRate.objects.create(name="VAT", rate=Decimal("20.00"))
    # From ArchivableMixin
    assert obj.deleted_at is None
    assert obj.row_version == 0
    # From TemporalMixin
    assert obj.valid_from == timezone.localdate()
    assert obj.valid_to is None
    assert obj.archived is False


# --------------------------------------------------------------------------- #
# Snapshot integration
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_supersede_triggers_archive_version_snapshots():
    """Two snapshots on supersede: one UPDATE on the old, one CREATE on
    the new."""
    obj = CombinedRate.objects.create(name="VAT", rate=Decimal("20.00"))
    # Initial create = one snapshot.
    ct = ContentType.objects.get_for_model(CombinedRate)
    initial = ArchiveVersion.objects.filter(content_type=ct).count()

    new = obj.supersede(rate=Decimal("13.00"))

    final = ArchiveVersion.objects.filter(content_type=ct).count()
    # One update snapshot for the closed row + one create snapshot for
    # the freshly inserted successor = two new rows.
    assert final - initial == 2

    # The create snapshot belongs to the new row.
    new_snap = ArchiveVersion.objects.filter(
        content_type=ct,
        object_id=str(new.pk),
    ).latest("created_at")
    assert new_snap.revision_meta.reason_code == "create"


@pytest.mark.django_db
def test_supersede_snapshot_reason_codes_are_update_and_create():
    obj = CombinedRate.objects.create(name="VAT", rate=Decimal("20.00"))
    old_pk = obj.pk

    new = obj.supersede(rate=Decimal("19.00"))

    ct = ContentType.objects.get_for_model(CombinedRate)
    old_last = ArchiveVersion.objects.filter(
        content_type=ct,
        object_id=str(old_pk),
    ).latest("created_at")
    new_last = ArchiveVersion.objects.filter(
        content_type=ct,
        object_id=str(new.pk),
    ).latest("created_at")

    assert old_last.revision_meta.reason_code == "update"
    assert new_last.revision_meta.reason_code == "create"


# --------------------------------------------------------------------------- #
# Soft-delete on a temporal row
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_soft_delete_on_temporal_row_keeps_valid_to_untouched():
    """Soft-delete and supersede are orthogonal. Soft-delete sets
    ``deleted_at`` but does not touch the temporal validity range."""
    obj = CombinedRate.objects.create(name="VAT", rate=Decimal("20.00"))
    original_valid_to = obj.valid_to

    obj.delete()

    obj.refresh_from_db()
    assert obj.deleted_at is not None
    assert obj.valid_to == original_valid_to


# --------------------------------------------------------------------------- #
# Cascade soft-delete does NOT supersede children
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_cascade_soft_delete_does_not_supersede_temporal_children():
    """The parent model has ``SOFT_DELETE_CASCADE``. When the parent is
    soft-deleted, temporal children are soft-deleted too (deleted_at set),
    but their ``valid_to`` remains untouched and no new successor row is
    created."""
    parent = TemporalParent.objects.create(name="P")
    child_a = TemporalChild.objects.create(parent=parent, label="a")
    child_b = TemporalChild.objects.create(parent=parent, label="b")

    before = TemporalChild.all_objects.count()
    parent.delete()
    after = TemporalChild.all_objects.count()

    # No new rows were created (no supersede).
    assert before == after

    child_a.refresh_from_db()
    child_b.refresh_from_db()

    # Cascade hit: both children are soft-deleted.
    assert child_a.deleted_at is not None
    assert child_b.deleted_at is not None
    # ... but their temporal validity is untouched.
    assert child_a.valid_to is None
    assert child_b.valid_to is None
