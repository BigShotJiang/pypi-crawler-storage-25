"""Phase-1 tests for the hard-delete guard (Zero Trust boundary).

``hard_delete()`` must be gated by a valid ``RetentionToken``. The
token is only issuable from an authorised context (e.g. the scheduled
``archive_cleanup`` management command). Plugin authors and HTTP
handlers MUST NOT be able to physically delete rows.
"""

from __future__ import annotations

import pytest

from conjunto.archive.retention import RetentionToken, cleanup_context

from tests.test_app.archivable_models import Folder


@pytest.mark.django_db
def test_retention_token_is_valid_after_issue():
    with cleanup_context():
        token = RetentionToken.issue(purpose="archive_cleanup")
    assert token.valid() is True
    assert token.purpose == "archive_cleanup"


@pytest.mark.django_db
def test_retention_token_cannot_be_constructed_directly():
    """Direct construction must raise — force callers through ``issue()``."""
    with pytest.raises(RuntimeError):
        RetentionToken(purpose="hack")  # type: ignore[call-arg]


@pytest.mark.django_db
def test_hard_delete_with_valid_token_deletes_physically():
    folder = Folder.objects.create(name="Inbox")
    pk = folder.pk
    with cleanup_context():
        token = RetentionToken.issue(purpose="archive_cleanup")

    folder.hard_delete(retention_token=token)

    assert Folder.all_objects.filter(pk=pk).count() == 0


@pytest.mark.django_db
def test_hard_delete_with_expired_token_raises(monkeypatch):
    folder = Folder.objects.create(name="Inbox")
    with cleanup_context():
        token = RetentionToken.issue(purpose="archive_cleanup")

    # Force the token to report invalid (simulate TTL expiry)
    monkeypatch.setattr(token, "valid", lambda: False)

    with pytest.raises(PermissionError):
        folder.hard_delete(retention_token=token)


@pytest.mark.django_db
def test_hard_delete_with_foreign_process_token_raises(monkeypatch):
    """A token issued in a different process must be rejected."""
    folder = Folder.objects.create(name="Inbox")
    with cleanup_context():
        token = RetentionToken.issue(purpose="archive_cleanup")

    monkeypatch.setattr(token, "_process_id", token._process_id + 1)

    with pytest.raises(PermissionError):
        folder.hard_delete(retention_token=token)


@pytest.mark.django_db
def test_hard_delete_rejects_plain_string_token():
    """Passing a string or int as token must raise, not silently succeed."""
    folder = Folder.objects.create(name="Inbox")
    with pytest.raises(PermissionError):
        folder.hard_delete(retention_token="letmein")
