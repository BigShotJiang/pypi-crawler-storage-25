"""Phase-5 tests — HTMX revert flow.

Covers the two complementary views that make up the interactive
revert UX: ``ArchiveRevertConfirmView`` (GET, modal body) and
``ArchiveRevertView`` (POST, applies the revert).

Matrix:

- Confirm modal renders for authenticated users.
- Non-privileged users see a "Permission required" notice instead of
  an actionable submit button.
- Apply with change permission writes a new snapshot and returns a
  204 + ``HX-Redirect`` + ``showToast`` trigger.
- Apply without permission returns 403.
- Apply on a stale row returns the ``_stale_conflict.html`` partial
  with HTTP 409.
- Apply on an unrevertable snapshot returns ``_unrevertable.html``
  with HTTP 422.
"""

from __future__ import annotations

import pytest
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from django.urls import reverse

from conjunto.archive.models import ArchiveVersion

from tests.test_app.archivable_models import Folder


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #
@pytest.fixture
def user(db, django_user_model):
    return django_user_model.objects.create_user(username="plain", password="pw")


@pytest.fixture
def editor(db, django_user_model):
    """User with change_folder permission — eligible to revert."""
    user = django_user_model.objects.create_user(username="boss", password="pw")
    perm = Permission.objects.get(
        content_type__app_label="test_app",
        codename="change_folder",
    )
    user.user_permissions.add(perm)
    return user


@pytest.fixture
def folder_with_history(db):
    folder = Folder.objects.create(name="Inbox")
    folder.name = "Archive"
    folder.save()
    return folder


def _versions_for(folder):
    return ArchiveVersion.objects.filter(
        content_type=ContentType.objects.get_for_model(Folder),
        object_id=str(folder.pk),
    ).order_by("created_at")


# --------------------------------------------------------------------------- #
# Confirm modal
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_revert_confirm_modal_renders_for_editor(client, editor, folder_with_history):
    first_version = _versions_for(folder_with_history).first()
    client.force_login(editor)
    url = reverse("conjunto_archive:revert-confirm", args=[first_version.pk])
    response = client.get(url)
    assert response.status_code == 200
    body = response.content.decode()
    assert "Revert to earlier version" in body
    # Submit button is present because user has change permission.
    assert (
        f'hx-post="{reverse("conjunto_archive:revert", args=[first_version.pk])}"'
        in body
    )


@pytest.mark.django_db
def test_revert_confirm_modal_shows_permission_notice_for_plain_user(
    client, user, folder_with_history
):
    first_version = _versions_for(folder_with_history).first()
    client.force_login(user)
    url = reverse("conjunto_archive:revert-confirm", args=[first_version.pk])
    response = client.get(url)
    assert response.status_code == 200
    body = response.content.decode()
    assert "Permission required" in body


@pytest.mark.django_db
def test_revert_confirm_requires_login(client, folder_with_history):
    first_version = _versions_for(folder_with_history).first()
    url = reverse("conjunto_archive:revert-confirm", args=[first_version.pk])
    response = client.get(url)
    assert response.status_code in (302, 401)


@pytest.mark.django_db
def test_revert_confirm_404_for_unknown_version(client, editor):
    client.force_login(editor)
    url = reverse("conjunto_archive:revert-confirm", args=[999999])
    response = client.get(url)
    assert response.status_code == 404


# --------------------------------------------------------------------------- #
# Apply
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_revert_apply_writes_new_snapshot(client, editor, folder_with_history):
    first_version = _versions_for(folder_with_history).first()
    client.force_login(editor)
    url = reverse("conjunto_archive:revert", args=[first_version.pk])
    response = client.post(url)

    assert response.status_code == 204
    assert "HX-Redirect" in response
    trigger = response.get("HX-Trigger", "")
    assert "showToast" in trigger

    folder_with_history.refresh_from_db()
    assert folder_with_history.name == "Inbox"

    reasons = list(
        _versions_for(folder_with_history).values_list(
            "revision_meta__reason_code", flat=True
        )
    )
    assert reasons == ["create", "update", "revert"]


@pytest.mark.django_db
def test_revert_apply_without_permission_is_forbidden(
    client, user, folder_with_history
):
    first_version = _versions_for(folder_with_history).first()
    client.force_login(user)
    url = reverse("conjunto_archive:revert", args=[first_version.pk])
    response = client.post(url)
    assert response.status_code == 403


@pytest.mark.django_db
def test_revert_apply_requires_login(client, folder_with_history):
    first_version = _versions_for(folder_with_history).first()
    url = reverse("conjunto_archive:revert", args=[first_version.pk])
    response = client.post(url)
    assert response.status_code in (302, 401)


@pytest.mark.django_db
def test_revert_apply_get_is_not_allowed(client, editor, folder_with_history):
    first_version = _versions_for(folder_with_history).first()
    client.force_login(editor)
    url = reverse("conjunto_archive:revert", args=[first_version.pk])
    response = client.get(url)
    assert response.status_code == 405


@pytest.mark.django_db
def test_revert_apply_returns_stale_conflict_on_parallel_update(
    client, editor, folder_with_history, monkeypatch
):
    """Simulate concurrent edit: the view loads the target instance,
    and in the moment between load and revert another writer bumped
    ``row_version``. We inject that race by monkeypatching
    ``ArchivableMixin.revert`` so it raises ``StaleObjectError`` the
    same way the real optimistic-locking path would. The view must
    turn that into a 409 + stale-conflict partial."""
    first_version = _versions_for(folder_with_history).first()

    from conjunto.archive.exceptions import StaleObjectError
    from conjunto.archive.mixins.archivable import ArchivableMixin

    def _raise_stale(self, to_version, *, user=None, comment=""):
        raise StaleObjectError(type(self), self.pk, self.row_version)

    monkeypatch.setattr(ArchivableMixin, "revert", _raise_stale)

    client.force_login(editor)
    url = reverse("conjunto_archive:revert", args=[first_version.pk])
    response = client.post(url)

    assert response.status_code == 409
    body = response.content.decode()
    assert "Record was modified" in body


@pytest.mark.django_db
def test_revert_apply_returns_unrevertable_on_schema_gap(
    client, editor, folder_with_history
):
    """A snapshot marked as future-schema can't be applied — 422."""
    first_version = _versions_for(folder_with_history).first()

    # Raw UPDATE — bypasses AppendOnlyManager (test-only detour).
    from django.db import connection

    with connection.cursor() as cursor:
        cursor.execute(
            "UPDATE conjunto_archive_archiveversion "
            "SET schema_version = 99 WHERE id = %s",
            [first_version.pk],
        )

    client.force_login(editor)
    url = reverse("conjunto_archive:revert", args=[first_version.pk])
    response = client.post(url)
    assert response.status_code == 422
    body = response.content.decode()
    assert "Version cannot be reverted" in body
