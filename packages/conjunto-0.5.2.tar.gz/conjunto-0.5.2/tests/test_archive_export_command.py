"""Phase-4 tests for ``manage.py archive_export``.

Covers:

- NDJSON output with one line per row and one line per ArchiveVersion.
- Manifest includes SHA256 hashes and is written atomically.
- Tenant scope filters rows (only relevant when tenant field exists).
- Read-only: running the command leaves the DB unchanged.
- DeletionLog is never written by the export path.
"""

from __future__ import annotations

import json
from io import StringIO

import pytest
from django.contrib.auth import get_user_model
from django.core.management import call_command

from conjunto.archive.models import DeletionLog

from tests.test_app.archivable_models import Folder, SoftOnlyRecord


@pytest.fixture
def user(db):
    User = get_user_model()
    return User.objects.create_user(username="alice", password="pw")


@pytest.mark.django_db
def test_export_writes_ndjson_per_model(tmp_path):
    Folder.objects.create(name="a")
    Folder.objects.create(name="b")
    SoftOnlyRecord.objects.create(label="x")

    call_command(
        "archive_export",
        "--tenant",
        "0",
        "--output",
        str(tmp_path),
        stdout=StringIO(),
    )

    tenant_dir = tmp_path / "0"
    assert tenant_dir.is_dir()
    folder_file = tenant_dir / "test_app.Folder.ndjson"
    record_file = tenant_dir / "test_app.SoftOnlyRecord.ndjson"
    # Tenant filter is a no-op on non-tenant models → both files exist.
    assert folder_file.is_file()
    assert record_file.is_file()

    # NDJSON: every line is valid JSON on its own.
    lines = folder_file.read_text(encoding="utf-8").strip().splitlines()
    parsed = [json.loads(line) for line in lines]
    assert {p["kind"] for p in parsed} <= {"row", "archive_version"}
    # Two Folder rows were created, so there are at least two "row" entries.
    rows = [p for p in parsed if p["kind"] == "row"]
    assert len(rows) == 2


@pytest.mark.django_db
def test_export_manifest_has_sha256(tmp_path):
    Folder.objects.create(name="solo")

    call_command(
        "archive_export",
        "--tenant",
        "0",
        "--output",
        str(tmp_path),
        stdout=StringIO(),
    )

    manifest_path = tmp_path / "0" / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert manifest["tenant_id"] == "0"
    assert "generated_at" in manifest
    assert len(manifest["files"]) >= 1
    first = manifest["files"][0]
    assert first["sha256"]
    assert len(first["sha256"]) == 64  # hex-encoded SHA256


@pytest.mark.django_db
def test_export_is_read_only(tmp_path, user):
    folder = Folder.objects.create(name="x")
    folder.delete(user=user)  # create a soft-delete state
    deletions_before = DeletionLog.objects.count()
    row_counts_before = {
        "folder_alive": Folder.objects.count(),
        "folder_all": Folder.all_objects.count(),
    }

    call_command(
        "archive_export",
        "--tenant",
        "0",
        "--output",
        str(tmp_path),
        stdout=StringIO(),
    )

    # Nothing changed in the DB.
    assert DeletionLog.objects.count() == deletions_before
    assert Folder.objects.count() == row_counts_before["folder_alive"]
    assert Folder.all_objects.count() == row_counts_before["folder_all"]


@pytest.mark.django_db
def test_export_includes_archive_versions(tmp_path):
    folder = Folder.objects.create(name="v1")
    folder.name = "v2"
    folder.save()  # produces one more ArchiveVersion

    call_command(
        "archive_export",
        "--tenant",
        "0",
        "--output",
        str(tmp_path),
        stdout=StringIO(),
    )

    folder_file = tmp_path / "0" / "test_app.Folder.ndjson"
    parsed = [
        json.loads(line)
        for line in folder_file.read_text(encoding="utf-8").strip().splitlines()
    ]
    versions = [p for p in parsed if p["kind"] == "archive_version"]
    assert len(versions) >= 2  # create + update
    # Each version entry has its revision_meta inlined.
    assert all("revision_meta" in v for v in versions)
