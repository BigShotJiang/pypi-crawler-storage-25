"""Phase-2 tamper-evidence tests for ``ArchiveRevisionMeta`` + ``ArchiveVersion``.

Both tables are append-only by contract. Any attempt to mutate or
delete rows — via queryset ``.update()``, ``.bulk_update()``,
``.delete()`` or instance ``.save()``/``.delete()`` after the PK is
set — must raise ``TamperEvidenceViolation``.
"""

from __future__ import annotations

import pytest
from django.contrib.auth import get_user_model

from conjunto.archive.exceptions import TamperEvidenceViolation
from conjunto.archive.models import ArchiveRevisionMeta, ArchiveVersion

from tests.test_app.archivable_models import Folder


@pytest.fixture
def user(db):
    User = get_user_model()
    return User.objects.create_user(username="eve", password="pw")


@pytest.fixture
def version_pair(db, user):
    """Return a ``(version, meta)`` pair already in the DB."""
    folder = Folder.objects.create(name="target")
    # ``Folder.objects.create`` also writes a version (create snapshot).
    version = ArchiveVersion.objects.get(object_id=str(folder.pk))
    return version, version.revision_meta


# --------------------------------------------------------------------------- #
# ArchiveRevisionMeta
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_revision_meta_queryset_update_forbidden(version_pair):
    with pytest.raises(TamperEvidenceViolation):
        ArchiveRevisionMeta.objects.filter(pk=version_pair[1].pk).update(
            reason_code="update"
        )


@pytest.mark.django_db
def test_revision_meta_queryset_delete_forbidden(version_pair):
    with pytest.raises(TamperEvidenceViolation):
        ArchiveRevisionMeta.objects.filter(pk=version_pair[1].pk).delete()


@pytest.mark.django_db
def test_revision_meta_bulk_update_forbidden(version_pair):
    with pytest.raises(TamperEvidenceViolation):
        ArchiveRevisionMeta.objects.bulk_update(
            [version_pair[1]], fields=["reason_code"]
        )


@pytest.mark.django_db
def test_revision_meta_instance_save_after_pk_forbidden(version_pair):
    meta = version_pair[1]
    meta.reason_code = "update"
    with pytest.raises(TamperEvidenceViolation):
        meta.save()


@pytest.mark.django_db
def test_revision_meta_instance_delete_forbidden(version_pair):
    with pytest.raises(TamperEvidenceViolation):
        version_pair[1].delete()


# --------------------------------------------------------------------------- #
# ArchiveVersion
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_archive_version_queryset_update_forbidden(version_pair):
    with pytest.raises(TamperEvidenceViolation):
        ArchiveVersion.objects.filter(pk=version_pair[0].pk).update(serialized_data={})


@pytest.mark.django_db
def test_archive_version_queryset_delete_forbidden(version_pair):
    with pytest.raises(TamperEvidenceViolation):
        ArchiveVersion.objects.filter(pk=version_pair[0].pk).delete()


@pytest.mark.django_db
def test_archive_version_instance_save_after_pk_forbidden(version_pair):
    version = version_pair[0]
    version.serialized_data = {}
    with pytest.raises(TamperEvidenceViolation):
        version.save()
