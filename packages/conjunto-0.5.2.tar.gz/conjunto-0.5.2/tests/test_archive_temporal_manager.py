"""Phase-3 tests for ``TemporalManager`` / ``TemporalQuerySet``.

Covers the three query helpers (``.at(date)``, ``.history_for(...)``,
``.valid_between(start, end)``) and the Option-C manager split:
``objects`` sees everything, ``current`` is pre-filtered.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from tests.test_app.temporal_models import TaxRate


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #
@pytest.fixture
def rate_history(db):
    """Three VAT rows for the same ``name`` at different validity ranges:

    - 2020-01-01 .. 2021-12-31 = 20.00
    - 2022-01-01 .. 2023-06-30 = 19.00
    - 2023-07-01 .. open       = 13.00
    """
    r1 = TaxRate.objects.create(
        name="VAT",
        rate=Decimal("20.00"),
        valid_from=date(2020, 1, 1),
        valid_to=date(2021, 12, 31),
    )
    r2 = TaxRate.objects.create(
        name="VAT",
        rate=Decimal("19.00"),
        valid_from=date(2022, 1, 1),
        valid_to=date(2023, 6, 30),
    )
    r3 = TaxRate.objects.create(
        name="VAT",
        rate=Decimal("13.00"),
        valid_from=date(2023, 7, 1),
    )
    return r1, r2, r3


# --------------------------------------------------------------------------- #
# .at(date)
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_at_date_returns_row_valid_at_exact_start(rate_history):
    r1, _r2, _r3 = rate_history
    hits = TaxRate.objects.at(date(2020, 1, 1))
    assert list(hits) == [r1]


@pytest.mark.django_db
def test_at_date_returns_row_valid_at_exact_end(rate_history):
    """``valid_to`` is inclusive: the row is still valid ON that day."""
    _r1, r2, _r3 = rate_history
    hits = TaxRate.objects.at(date(2023, 6, 30))
    assert list(hits) == [r2]


@pytest.mark.django_db
def test_at_date_returns_open_ended_row(rate_history):
    _r1, _r2, r3 = rate_history
    hits = TaxRate.objects.at(date(2026, 4, 19))
    assert list(hits) == [r3]


@pytest.mark.django_db
def test_at_date_before_any_row(rate_history):
    hits = TaxRate.objects.at(date(2019, 6, 30))
    assert list(hits) == []


@pytest.mark.django_db
def test_at_date_in_gap_between_rows():
    """Gap between valid_to and the next valid_from returns nothing."""
    TaxRate.objects.create(
        name="VAT",
        rate=Decimal("20.00"),
        valid_from=date(2020, 1, 1),
        valid_to=date(2020, 12, 31),
    )
    TaxRate.objects.create(
        name="VAT",
        rate=Decimal("13.00"),
        valid_from=date(2022, 1, 1),
    )
    # January 2021 is a gap.
    assert TaxRate.objects.at(date(2021, 6, 1)).count() == 0


# --------------------------------------------------------------------------- #
# .history_for(**filter)
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_history_for_returns_chronological_order(rate_history):
    r1, r2, r3 = rate_history
    rows = list(TaxRate.objects.history_for(name="VAT"))
    assert rows == [r1, r2, r3]


@pytest.mark.django_db
def test_history_for_isolates_by_filter():
    """Two unrelated histories do not leak into each other."""
    vat = TaxRate.objects.create(
        name="VAT",
        rate=Decimal("20.00"),
        valid_from=date(2020, 1, 1),
        valid_to=date(2021, 12, 31),
    )
    TaxRate.objects.create(
        name="Reduced",
        rate=Decimal("10.00"),
        valid_from=date(2020, 1, 1),
    )
    rows = list(TaxRate.objects.history_for(name="VAT"))
    assert rows == [vat]


# --------------------------------------------------------------------------- #
# .valid_between(start, end)
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_valid_between_picks_overlapping_rows(rate_history):
    r1, r2, _r3 = rate_history
    rows = set(TaxRate.objects.valid_between(date(2021, 6, 1), date(2022, 6, 1)))
    assert rows == {r1, r2}


@pytest.mark.django_db
def test_valid_between_excludes_non_overlapping(rate_history):
    # Range completely inside the closed gap? Here the dataset has no
    # gap, but we can still check the cutoff below the first row.
    rows = list(TaxRate.objects.valid_between(date(2010, 1, 1), date(2010, 12, 31)))
    assert rows == []


@pytest.mark.django_db
def test_valid_between_includes_open_ended_tail(rate_history):
    _r1, r2, r3 = rate_history
    rows = set(TaxRate.objects.valid_between(date(2023, 6, 1), date(2030, 1, 1)))
    assert rows == {r2, r3}


@pytest.mark.django_db
def test_valid_between_single_day_range(rate_history):
    _r1, _r2, r3 = rate_history
    d = date(2025, 6, 1)
    rows = list(TaxRate.objects.valid_between(d, d))
    assert rows == [r3]


# --------------------------------------------------------------------------- #
# Current manager contract
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_current_manager_does_not_expose_history_helpers():
    """By contract, ``.current`` is pre-filtered and does NOT carry the
    historic query helpers — they would be misleading on a single-row
    view of the data."""
    assert not hasattr(TaxRate.current, "at")
    assert not hasattr(TaxRate.current, "history_for")
    assert not hasattr(TaxRate.current, "valid_between")
