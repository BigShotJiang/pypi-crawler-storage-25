"""Doc-as-test for ``docs/archive/temporal-mixin.md``.

The marriage-name-change scenario in the docs ships as an executable
test so the docs never drift from the API. Uses ``TaxRate`` as a
domain-agnostic stand-in for ``PatientName`` (the conjunto test suite
does not carry a Patient model — MedUX-side tests cover the real model).
"""

from __future__ import annotations

from datetime import date, timedelta
from decimal import Decimal

import pytest
from django.utils import timezone

from tests.test_app.temporal_models import TaxRate


@pytest.mark.django_db
def test_doc_example_tax_rate_scenario():
    """Scenario from docs:

    - Before 2023-07-01: rate = 20.00.
    - On 2023-07-01 the rate changes to 13.00.
    - An invoice dated 2023-04-15 still needs to see the 20.00 rate.
    - An invoice dated 2024-01-20 needs the 13.00 rate.
    """
    old = TaxRate.objects.create(
        name="VAT",
        rate=Decimal("20.00"),
        valid_from=date(2020, 1, 1),
        valid_to=date(2023, 6, 30),
    )
    new = TaxRate.objects.create(
        name="VAT",
        rate=Decimal("13.00"),
        valid_from=date(2023, 7, 1),
    )

    # Historical invoice lookup
    applicable_old = TaxRate.objects.at(date(2023, 4, 15)).get(name="VAT")
    applicable_new = TaxRate.objects.at(date(2024, 1, 20)).get(name="VAT")

    assert applicable_old == old
    assert applicable_new == new

    # Current manager: one row.
    assert TaxRate.current.get(name="VAT") == new


@pytest.mark.django_db
def test_doc_example_supersede_transition():
    """Scenario from docs: supersede() idiom.

    - Today, ``rate=20.00`` is current.
    - ``.supersede(rate=Decimal("13.00"))`` closes today-1, opens today.
    - Yesterday: old row applies.
    - Today: new row applies.
    """
    old = TaxRate.objects.create(
        name="VAT",
        rate=Decimal("20.00"),
        valid_from=date(2020, 1, 1),
    )

    new = old.supersede(rate=Decimal("13.00"))

    # Use ``timezone.localdate()`` — same source as the model default
    # (see ``TemporalMixin._today``).
    today = timezone.localdate()
    yesterday = today - timedelta(days=1)

    applicable_yesterday = TaxRate.objects.at(yesterday).get(name="VAT")
    applicable_today = TaxRate.objects.at(today).get(name="VAT")

    assert applicable_yesterday.pk == old.pk
    assert applicable_today.pk == new.pk
    assert applicable_today.rate == Decimal("13.00")
