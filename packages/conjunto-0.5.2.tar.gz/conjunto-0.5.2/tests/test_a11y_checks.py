"""Tests for the accessibility template checks (A001–A004)."""

from __future__ import annotations

from pathlib import Path


from conjunto.checks_a11y import _scan_template, _scan_template_for_a002


def _write(tmp_path: Path, name: str, body: str) -> Path:
    p = tmp_path / name
    p.write_text(body, encoding="utf-8")
    return p


class TestA001ClickableNonButton:
    def test_div_with_hxget_without_role_warns(self, tmp_path):
        p = _write(
            tmp_path,
            "x.html",
            '<div hx-get="/foo" hx-target="#dialog">Click</div>',
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A001" in ids

    def test_div_with_hxget_and_role_button_silent(self, tmp_path):
        p = _write(
            tmp_path,
            "x.html",
            '<div hx-get="/foo" role="button" tabindex="0">Click</div>',
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A001" not in ids

    def test_button_element_excluded(self, tmp_path):
        p = _write(tmp_path, "x.html", '<button hx-get="/foo">Click</button>')
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A001" not in ids

    def test_hx_trigger_load_silent(self, tmp_path):
        # `hx-trigger="load"` fires on page load, not on user action.
        p = _write(
            tmp_path,
            "x.html",
            '<div hx-get="/foo" hx-trigger="load" hx-swap="innerHTML"></div>',
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A001" not in ids

    def test_hx_trigger_custom_event_silent(self, tmp_path):
        # Event-driven re-fetch (e.g. tenant_roles:changed from:body) is
        # not a user interaction.
        p = _write(
            tmp_path,
            "x.html",
            '<div hx-get="/foo" hx-trigger="settings:changed from:body"></div>',
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A001" not in ids

    def test_hx_swap_oob_only_silent(self, tmp_path):
        # No request attr, only an OOB-swap marker.
        p = _write(tmp_path, "x.html", '<div hx-swap-oob="innerHTML"></div>')
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A001" not in ids

    def test_ws_connect_silent(self, tmp_path):
        # WebSocket extension wrappers don't react to clicks.
        p = _write(
            tmp_path,
            "x.html",
            '<div hx-ext="ws" ws-connect="/ws/foo/"></div>',
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A001" not in ids


class TestA003ImgWithoutAlt:
    def test_img_without_alt_warns(self, tmp_path):
        p = _write(tmp_path, "x.html", '<img src="/foo.png">')
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A003" in ids

    def test_img_with_empty_alt_silent(self, tmp_path):
        p = _write(tmp_path, "x.html", '<img src="/foo.png" alt="">')
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A003" not in ids


class TestA004IconOnlyButton:
    def test_icon_only_without_aria_label_warns(self, tmp_path):
        p = _write(
            tmp_path,
            "x.html",
            '<button class="btn"><i class="ti ti-x"></i></button>',
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A004" in ids

    def test_icon_with_aria_label_silent(self, tmp_path):
        p = _write(
            tmp_path,
            "x.html",
            '<button aria-label="Close"><i class="ti ti-x"></i></button>',
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A004" not in ids

    def test_button_with_visible_text_silent(self, tmp_path):
        p = _write(tmp_path, "x.html", "<button>Save</button>")
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A004" not in ids

    def test_button_with_translate_text_silent(self, tmp_path):
        # `{% translate "X" %}` is visible text, not a stripped tag.
        p = _write(
            tmp_path,
            "x.html",
            "<button>{% translate 'Cancel' %}</button>",
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A004" not in ids

    def test_button_with_variable_text_silent(self, tmp_path):
        # `{{ var }}` renders to something at runtime — count as visible.
        p = _write(
            tmp_path,
            "x.html",
            "<button><i class='ti ti-check'></i>{{ button_content }}</button>",
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A004" not in ids

    def test_button_with_runtime_attrs_silent(self, tmp_path):
        # Attrs (incl. aria-label) injected at runtime via a `.attrs.items`
        # loop — the static scanner cannot see them.
        p = _write(
            tmp_path,
            "x.html",
            "<button type='button' {% for k, v in button.attrs.items %}"
            '{{ k }}="{{ v }}" {% endfor %}><i class="ti ti-x"></i></button>',
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A004" not in ids

    def test_empty_title_does_not_count(self, tmp_path):
        # `title=""` is not a valid accessible name.
        p = _write(
            tmp_path,
            "x.html",
            '<button title=""><i class="ti ti-x"></i></button>',
        )
        ids = {i.id for i in _scan_template(p)}
        assert "conjunto.A004" in ids


class TestA002InputLabel:
    def test_input_without_label_warns(self, tmp_path):
        p = _write(tmp_path, "x.html", '<input id="foo" type="text">')
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" in ids

    def test_input_with_matching_label_silent(self, tmp_path):
        p = _write(
            tmp_path,
            "x.html",
            '<label for="foo">Foo</label><input id="foo" type="text">',
        )
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" not in ids

    def test_input_with_aria_label_silent(self, tmp_path):
        p = _write(tmp_path, "x.html", '<input id="foo" aria-label="Foo">')
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" not in ids

    def test_hidden_input_excluded(self, tmp_path):
        p = _write(tmp_path, "x.html", '<input type="hidden" id="csrf" value="x">')
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" not in ids

    def test_implicit_label_wrap_silent(self, tmp_path):
        # `<label><input …></label>` is HTML5-valid implicit labelling.
        p = _write(
            tmp_path,
            "x.html",
            '<label class="form-check"><input type="checkbox" name="x">'
            "<span>Foo</span></label>",
        )
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" not in ids

    def test_input_with_title_silent(self, tmp_path):
        # `title="…"` satisfies WAI-ARIA accessible-name calculation.
        p = _write(
            tmp_path,
            "x.html",
            '<input type="checkbox" name="lock" title="Lock binding">',
        )
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" not in ids

    def test_widget_attrs_include_silent(self, tmp_path):
        # Django widget attr partial injects `id=…` at render time.
        p = _write(
            tmp_path,
            "x.html",
            '<input type="text" name="x" {% include "django/forms/widgets/'
            'attrs.html" %}>',
        )
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" not in ids

    def test_widget_attrs_items_loop_silent(self, tmp_path):
        p = _write(
            tmp_path,
            "x.html",
            '<input type="text" name="x" {% for k, v in widget.attrs.items %}'
            '{{ k }}="{{ v }}" {% endfor %}>',
        )
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" not in ids

    def test_aria_hidden_silent(self, tmp_path):
        # `aria-hidden="true"` removes the element from the a11y tree —
        # presentational/dummy inputs don't need a label.
        p = _write(
            tmp_path,
            "x.html",
            '<input type="checkbox" aria-hidden="true" tabindex="-1">',
        )
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" not in ids

    def test_input_in_django_comment_silent(self, tmp_path):
        # Inputs inside `{# … #}` aren't rendered.
        p = _write(
            tmp_path,
            "x.html",
            '{# <input type="text" name="ignored"> #}',
        )
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" not in ids

    def test_input_in_html_comment_silent(self, tmp_path):
        p = _write(
            tmp_path,
            "x.html",
            '<!-- <input type="text" name="ignored"> -->',
        )
        ids = {i.id for i in _scan_template_for_a002(p)}
        assert "conjunto.A002" not in ids


class TestKbdClickableTag:
    def test_renders_required_a11y_attrs(self):
        from django.template import Context, Template

        tpl = Template(
            "{% load conjunto %}<span {% kbd_clickable 'Open patient' %}></span>"
        )
        out = tpl.render(Context({}))
        assert 'role="button"' in out
        assert 'tabindex="0"' in out
        assert 'aria-label="Open patient"' in out
        assert "Enter" in out
        assert "this.click()" in out
