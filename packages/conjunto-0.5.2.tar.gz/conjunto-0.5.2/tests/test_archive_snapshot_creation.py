"""Phase-2 tests — snapshot creation via ``ArchivableMixin``.

Covers the auto-snapshot wiring on ``save()``, ``delete()``,
``restore()`` and the opt-ins controlled by the ``Archive`` inner
class (``follow_fk``, ``excluded_fields``). Cascade-driven snapshots
and FK-reference format are also exercised here.
"""

from __future__ import annotations

import pytest
from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType

from conjunto.archive.models import ArchiveVersion
from conjunto.archive.snapshot import create_snapshot  # noqa: F401 - covered via mixin

from tests.test_app.archivable_models import Document, Folder


@pytest.fixture
def user(db):
    User = get_user_model()
    return User.objects.create_user(username="carol", password="pw")


def _versions_for(obj):
    return ArchiveVersion.objects.filter(
        content_type=ContentType.objects.get_for_model(type(obj)),
        object_id=str(obj.pk),
    )


# --------------------------------------------------------------------------- #
# Save / delete / restore triggers
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_create_emits_one_version(user):
    folder = Folder.objects.create(name="Inbox")

    versions = list(_versions_for(folder))
    assert len(versions) == 1
    assert versions[0].revision_meta.reason_code == "create"
    assert versions[0].schema_version == 1


@pytest.mark.django_db
def test_update_emits_version_with_update_reason(user):
    folder = Folder.objects.create(name="Inbox")
    folder.name = "Archive"
    folder.save()

    reasons = list(
        _versions_for(folder)
        .order_by("created_at")
        .values_list("revision_meta__reason_code", flat=True)
    )
    assert reasons == ["create", "update"]


@pytest.mark.django_db
def test_soft_delete_emits_version_with_soft_delete_reason(user):
    folder = Folder.objects.create(name="Inbox")
    folder.delete(user=user)

    reasons = list(
        _versions_for(folder)
        .order_by("created_at")
        .values_list("revision_meta__reason_code", flat=True)
    )
    assert reasons == ["create", "soft_delete"]


@pytest.mark.django_db
def test_restore_emits_version_with_restore_reason(user):
    folder = Folder.objects.create(name="Inbox")
    folder.delete(user=user)
    folder.restore(user=user)

    reasons = list(
        _versions_for(folder)
        .order_by("created_at")
        .values_list("revision_meta__reason_code", flat=True)
    )
    assert reasons == ["create", "soft_delete", "restore"]


# --------------------------------------------------------------------------- #
# Snapshot contents
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_snapshot_captures_domain_fields():
    folder = Folder.objects.create(name="Inbox")
    payload = _versions_for(folder).first().serialized_data

    assert payload["name"] == "Inbox"
    # Lifecycle fields are included too — they are part of the domain.
    assert payload["deleted_at"] is None
    # row_version is deliberately excluded.
    assert "row_version" not in payload


@pytest.mark.django_db
def test_snapshot_captures_fk_as_pk_dict():
    folder = Folder.objects.create(name="Inbox")
    doc = Document.objects.create(title="report", folder=folder)

    payload = _versions_for(doc).first().serialized_data
    assert payload["folder"] == {"pk": folder.pk}


# --------------------------------------------------------------------------- #
# Per-model ``Archive`` options
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_follow_fk_adds_repr(monkeypatch):
    """If the plugin opts in via ``Archive.follow_fk``, repr is serialised."""
    monkeypatch.setattr(Document.Archive, "follow_fk", ["folder"], raising=False)

    folder = Folder.objects.create(name="Inbox")
    doc = Document.objects.create(title="report", folder=folder)

    payload = _versions_for(doc).first().serialized_data
    assert payload["folder"]["pk"] == folder.pk
    assert payload["folder"]["repr"] == str(folder)


@pytest.mark.django_db
def test_excluded_fields_not_in_snapshot(monkeypatch):
    """``Archive.excluded_fields`` removes fields from the payload."""
    monkeypatch.setattr(Folder.Archive, "excluded_fields", ["name"], raising=False)

    folder = Folder.objects.create(name="Secret")
    payload = _versions_for(folder).first().serialized_data

    assert "name" not in payload


# --------------------------------------------------------------------------- #
# Cascade-driven snapshots
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_cascade_soft_delete_snapshots_each_child(user):
    folder = Folder.objects.create(name="parent")
    d1 = Document.objects.create(title="a", folder=folder)
    d2 = Document.objects.create(title="b", folder=folder)

    folder.delete(user=user)

    for child in (d1, d2):
        reasons = list(
            _versions_for(child)
            .order_by("created_at")
            .values_list("revision_meta__reason_code", flat=True)
        )
        # create (initial save) + soft_delete (cascade) for each child.
        assert reasons == ["create", "soft_delete"]
