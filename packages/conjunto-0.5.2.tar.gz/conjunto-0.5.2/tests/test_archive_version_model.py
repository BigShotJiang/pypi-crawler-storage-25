"""Phase-2 tests — ``ArchiveVersion`` + ``ArchiveRevisionMeta`` models.

These tests exercise the model layer in isolation (create/read,
native-JSON storage, revision-meta link) without going through the
snapshot pipeline. Snapshot-pipeline tests live in
``test_archive_snapshot_creation.py``.
"""

from __future__ import annotations

import pytest
from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType

from conjunto.archive.models import (
    ArchiveRevisionMeta,
    ArchiveVersion,
    ReasonCode,
)
from tests.test_app.archivable_models import Folder


@pytest.fixture
def user(db):
    User = get_user_model()
    return User.objects.create_user(username="bob", password="pw")


# --------------------------------------------------------------------------- #
# Basic create/read
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_revision_meta_fields_persist(user):
    meta = ArchiveRevisionMeta.objects.create(
        user=user,
        reason_code=ReasonCode.CREATE,
        comment="initial seed",
    )
    meta.refresh_from_db()

    assert meta.user_id == user.pk
    assert meta.tenant_id is None
    assert meta.reason_code == ReasonCode.CREATE
    assert meta.comment == "initial seed"
    assert meta.created_at is not None


@pytest.mark.django_db
def test_archive_version_stores_native_json(user):
    folder = Folder.objects.create(name="Inbox")
    meta = ArchiveRevisionMeta.objects.create(user=user, reason_code="create")

    version = ArchiveVersion.objects.create(
        content_type=ContentType.objects.get_for_model(Folder),
        object_id=str(folder.pk),
        serialized_data={"name": "Inbox", "deleted_at": None},
        schema_version=1,
        revision_meta=meta,
    )
    version.refresh_from_db()

    # Native JSON: the DB returns a dict, not a string.
    assert isinstance(version.serialized_data, dict)
    assert version.serialized_data == {"name": "Inbox", "deleted_at": None}
    assert version.schema_version == 1
    assert version.object_id == str(folder.pk)


@pytest.mark.django_db
def test_object_id_is_charfield_accepts_uuid_string(user):
    """``object_id`` is a CharField so UUID-PK models work too."""
    meta = ArchiveRevisionMeta.objects.create(user=user, reason_code="create")
    ct = ContentType.objects.get_for_model(Folder)

    uuid_like = "9f6e2d8c-1a4b-4b8c-9a23-aaaaaaaaaaaa"
    version = ArchiveVersion.objects.create(
        content_type=ct,
        object_id=uuid_like,
        serialized_data={},
        schema_version=1,
        revision_meta=meta,
    )

    version.refresh_from_db()
    assert version.object_id == uuid_like


@pytest.mark.django_db
def test_revision_meta_backref_from_archive_version(user):
    meta = ArchiveRevisionMeta.objects.create(user=user, reason_code="create")
    folder = Folder.objects.create(name="x")
    version = ArchiveVersion.objects.create(
        content_type=ContentType.objects.get_for_model(Folder),
        object_id=str(folder.pk),
        serialized_data={"name": "x"},
        schema_version=1,
        revision_meta=meta,
    )

    assert meta.archive_version.pk == version.pk


@pytest.mark.django_db
def test_generic_foreign_key_resolves(user):
    folder = Folder.objects.create(name="gfk-target")
    meta = ArchiveRevisionMeta.objects.create(user=user, reason_code="create")
    version = ArchiveVersion.objects.create(
        content_type=ContentType.objects.get_for_model(Folder),
        object_id=str(folder.pk),
        serialized_data={"name": "gfk-target"},
        schema_version=1,
        revision_meta=meta,
    )

    resolved = version.content_object
    assert resolved.pk == folder.pk
    assert resolved.name == "gfk-target"
