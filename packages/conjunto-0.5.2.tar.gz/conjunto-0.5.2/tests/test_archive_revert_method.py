"""Phase-5 tests — ``ArchivableMixin.revert()``.

Covers:

- Happy path: revert rewinds scalar field values and emits a fresh
  ``ArchiveVersion`` row with ``reason_code='revert'``.
- Schema migration: when the snapshot's ``schema_version`` is older
  than the current model's, the migration chain replays over the
  payload before it lands on the row.
- Error paths:
    * ``StaleObjectError`` when another writer bumped ``row_version``
      between the caller's load and the revert.
    * ``UnrevertableVersionError`` when the snapshot belongs to a
      different content type / object.
    * ``UnrevertableVersionError`` when the migration chain has a
      gap, or a scalar field in the payload no longer exists on the
      model.
"""

from __future__ import annotations

import pytest
from django.contrib.contenttypes.models import ContentType

from conjunto.archive.exceptions import (
    StaleObjectError,
    UnrevertableVersionError,
)
from conjunto.archive.models import ArchiveVersion

from tests.test_app.archivable_models import Document, Folder, VersionedRecord


def _versions_for(obj):
    return ArchiveVersion.objects.filter(
        content_type=ContentType.objects.get_for_model(type(obj)),
        object_id=str(obj.pk),
    ).order_by("created_at")


# --------------------------------------------------------------------------- #
# Happy path
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_revert_restores_prior_field_value():
    folder = Folder.objects.create(name="Inbox")
    folder.name = "Archive"
    folder.save()

    versions = list(_versions_for(folder))
    assert len(versions) == 2
    create_version = versions[0]
    assert create_version.serialized_data["name"] == "Inbox"

    folder.revert(create_version)
    folder.refresh_from_db()

    assert folder.name == "Inbox"


@pytest.mark.django_db
def test_revert_emits_new_version_with_revert_reason():
    folder = Folder.objects.create(name="Inbox")
    folder.name = "Archive"
    folder.save()

    first_version = _versions_for(folder).first()
    folder.revert(first_version)

    reasons = list(
        _versions_for(folder).values_list("revision_meta__reason_code", flat=True)
    )
    # create, update, revert — the fresh snapshot must be last.
    assert reasons == ["create", "update", "revert"]


@pytest.mark.django_db
def test_revert_bumps_row_version():
    folder = Folder.objects.create(name="Inbox")
    folder.name = "Archive"
    folder.save()

    before = Folder.objects.get(pk=folder.pk).row_version
    folder = Folder.objects.get(pk=folder.pk)  # fresh load
    first_version = _versions_for(folder).first()
    folder.revert(first_version)

    after = Folder.objects.get(pk=folder.pk).row_version
    assert after == before + 1


@pytest.mark.django_db
def test_revert_returns_self():
    folder = Folder.objects.create(name="Inbox")
    folder.name = "Archive"
    folder.save()

    first_version = _versions_for(folder).first()
    result = folder.revert(first_version)

    assert result is folder


@pytest.mark.django_db
def test_revert_includes_user_on_new_revision_meta(django_user_model):
    user = django_user_model.objects.create_user(username="dora", password="pw")
    folder = Folder.objects.create(name="Inbox")
    folder.name = "Archive"
    folder.save()

    first_version = _versions_for(folder).first()
    folder.revert(first_version, user=user)

    revert_version = _versions_for(folder).last()
    assert revert_version.revision_meta.reason_code == "revert"
    assert revert_version.revision_meta.user_id == user.pk


# --------------------------------------------------------------------------- #
# Optimistic locking
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_revert_raises_stale_object_error_on_parallel_update():
    folder = Folder.objects.create(name="Inbox")
    folder.name = "Archive"
    folder.save()

    first_version = _versions_for(folder).first()

    # Load two independent copies, mutate + save one of them so the
    # other carries a stale row_version.
    a = Folder.objects.get(pk=folder.pk)
    b = Folder.objects.get(pk=folder.pk)
    a.name = "Outbox"
    a.save()

    with pytest.raises(StaleObjectError):
        b.revert(first_version)


# --------------------------------------------------------------------------- #
# Error paths
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_revert_rejects_version_for_different_content_type():
    folder = Folder.objects.create(name="Inbox")
    document = Document.objects.create(title="memo", folder=folder)

    folder_version = _versions_for(folder).first()
    # Try to apply a Folder snapshot to a Document — must fail.
    with pytest.raises(UnrevertableVersionError):
        document.revert(folder_version)


@pytest.mark.django_db
def test_revert_rejects_version_for_different_object_pk():
    a = Folder.objects.create(name="Inbox")
    b = Folder.objects.create(name="Outbox")

    a_version = _versions_for(a).first()
    with pytest.raises(UnrevertableVersionError):
        b.revert(a_version)


def _raw_update_version(pk: int, **fields) -> None:
    """Bypass the ``AppendOnlyManager`` via a raw SQL UPDATE.

    Tests occasionally need to mutate an ``ArchiveVersion`` row (to
    simulate schema drift the revert path cannot recover from). The
    manager rightfully refuses in production code, so we drop down to
    ``connection.cursor`` — test-only.
    """
    from django.db import connection

    set_clauses = []
    params = []
    for col, value in fields.items():
        # Django's native JSONField on SQLite expects text JSON in a raw
        # UPDATE. Use ``json.dumps`` for dict values.
        if isinstance(value, dict):
            import json as _json

            set_clauses.append(f"{col} = %s")
            params.append(_json.dumps(value))
        else:
            set_clauses.append(f"{col} = %s")
            params.append(value)
    params.append(pk)
    sql = (
        f"UPDATE conjunto_archive_archiveversion "
        f"SET {', '.join(set_clauses)} WHERE id = %s"
    )
    with connection.cursor() as cursor:
        cursor.execute(sql, params)


@pytest.mark.django_db
def test_revert_rejects_snapshot_with_unknown_field():
    """A scalar field in the payload that no longer exists on the model
    and is not remapped by any migration step is unrevertable."""
    folder = Folder.objects.create(name="Inbox")
    first_version = _versions_for(folder).first()

    _raw_update_version(
        first_version.pk,
        serialized_data={**first_version.serialized_data, "ghost_field": 1},
    )
    first_version.refresh_from_db()

    with pytest.raises(UnrevertableVersionError):
        folder.revert(first_version)


@pytest.mark.django_db
def test_revert_rejects_newer_schema_version():
    folder = Folder.objects.create(name="Inbox")
    first_version = _versions_for(folder).first()

    _raw_update_version(first_version.pk, schema_version=99)
    first_version.refresh_from_db()

    with pytest.raises(UnrevertableVersionError):
        folder.revert(first_version)


# --------------------------------------------------------------------------- #
# Schema-migration chain
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_revert_replays_migration_chain_for_older_snapshot():
    """A snapshot on schema v1 is forwarded to v2 before apply.

    We simulate the "legacy snapshot" case by:
    1) Creating a ``VersionedRecord`` on the current (v2) schema.
    2) Rewriting the *create* snapshot in place so it claims
       schema_version=1 with the old field name ``label_old`` instead
       of ``label``.
    3) Calling ``revert(first_version)`` — the migration chain must
       replay ``_v1_to_v2`` so the payload's ``label_old`` becomes
       ``label`` before it lands on the instance.
    """
    rec = VersionedRecord.objects.create(label="original")
    rec.label = "changed"
    rec.save()

    create_version = _versions_for(rec).first()

    _raw_update_version(
        create_version.pk,
        schema_version=1,
        serialized_data={"label_old": "original"},
    )
    create_version.refresh_from_db()

    rec.revert(create_version)
    rec.refresh_from_db()

    assert rec.label == "original"


@pytest.mark.django_db
def test_revert_rejects_snapshot_with_gap_in_migration_chain(monkeypatch):
    """When ``archive_migrations`` is empty but the snapshot is on an
    older schema, ``UnrevertableVersionError`` must bubble up."""
    rec = VersionedRecord.objects.create(label="original")
    rec.label = "changed"
    rec.save()

    create_version = _versions_for(rec).first()

    # Pretend the snapshot was written under a missing-chain schema.
    _raw_update_version(create_version.pk, schema_version=1)
    create_version.refresh_from_db()

    # Temporarily blank out the migration chain so apply_migrations
    # sees a gap.
    monkeypatch.setattr(VersionedRecord.Archive, "archive_migrations", [], raising=True)

    with pytest.raises(UnrevertableVersionError):
        rec.revert(create_version)
