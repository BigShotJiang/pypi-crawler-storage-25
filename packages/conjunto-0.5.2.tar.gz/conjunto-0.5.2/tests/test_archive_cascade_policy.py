"""Phase-1 tests for ``CascadePolicy``.

All five policies validated separately, plus mixed-model cascade
behaviour (archivable vs. non-archivable children).
"""

from __future__ import annotations

import pytest

from conjunto.archive import CascadePolicy
from conjunto.archive.retention import RetentionToken, cleanup_context

from tests.test_app.archivable_models import (
    Document,
    Folder,
    InheritedBase,
    InheritedChild,
    NoDeleteRecord,
    Note,
    SoftOnlyRecord,
)


@pytest.mark.django_db
def test_cascade_policy_enum_has_five_values():
    names = {p.name for p in CascadePolicy}
    assert names == {
        "SOFT_DELETE",
        "SOFT_DELETE_CASCADE",
        "HARD_DELETE",
        "HARD_DELETE_NOCASCADE",
        "NO_DELETE",
    }


# --------------------------------------------------------------------------- #
# SOFT_DELETE — no cascade
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_soft_delete_no_cascade_leaves_children_alive():
    folder = Folder.objects.create(name="parent")
    # SoftOnlyRecord has SOFT_DELETE policy — use it as a stand-alone row.
    row = SoftOnlyRecord.objects.create(label="x")

    row.delete()

    row.refresh_from_db()
    assert row.deleted_at is not None
    # Folder untouched
    assert Folder.objects.filter(pk=folder.pk).exists()


# --------------------------------------------------------------------------- #
# SOFT_DELETE_CASCADE — cascades to archivable FK children
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_soft_delete_cascade_to_archivable_children():
    folder = Folder.objects.create(name="parent")
    a = Document.objects.create(title="a", folder=folder)
    b = Document.objects.create(title="b", folder=folder)

    folder.delete()

    a.refresh_from_db()
    b.refresh_from_db()
    assert a.deleted_at is not None
    assert b.deleted_at is not None
    assert a.deleted_by_cascade is True
    assert b.deleted_by_cascade is True

    folder.refresh_from_db()
    assert folder.deleted_by_cascade is False


@pytest.mark.django_db
def test_soft_delete_cascade_skips_non_archivable_children():
    """Non-archivable FK children (no ArchivableMixin) are untouched.

    The cascade walks ArchivableMixin-aware reverse relations only. A
    plain FK on a non-archivable child model leaves those rows alive
    (or follows Django's own ``on_delete`` rules, not our concern here).
    """
    folder = Folder.objects.create(name="parent")
    note = Note.objects.create(text="hi", folder=folder)

    folder.delete()

    # Non-archivable child still exists in its own manager
    assert Note.objects.filter(pk=note.pk).exists()


@pytest.mark.django_db
def test_cascade_terminates_on_circular_fk():
    """No infinite recursion — cascading the same row twice is a no-op."""
    folder = Folder.objects.create(name="parent")
    child = Document.objects.create(title="a", folder=folder)

    folder.delete()
    # Re-trigger delete on an already-deleted row: must be idempotent.
    folder_reloaded = Folder.all_objects.get(pk=folder.pk)
    folder_reloaded.delete()

    child.refresh_from_db()
    assert child.deleted_at is not None


# --------------------------------------------------------------------------- #
# Multi-table inheritance — forward OneToOneField(parent_link=True) must not
# crash the cascade walk.
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_soft_delete_cascade_survives_mti_parent_link():
    """Regression guard for the MedUX ``Patient -> Person`` crash.

    ``InheritedChild`` declares an explicit
    ``OneToOneField(parent_link=True)`` back to ``InheritedBase``. That
    forward field is returned by ``_meta.get_fields()`` with
    ``one_to_one=True`` but has no ``get_accessor_name()`` — the pre-fix
    cascade walk raised ``AttributeError`` here. Soft-deleting the
    parent must complete cleanly.
    """
    parent = InheritedBase.objects.create(name="mti-parent")

    # Must not raise.
    parent.delete()

    parent.refresh_from_db()
    assert parent.deleted_at is not None


@pytest.mark.django_db
def test_soft_delete_cascade_on_mti_child_survives_parent_link():
    """Deleting the concrete MTI child must also not crash.

    Same guard as above, but starting from the child row — the forward
    ``parent_link`` OneToOneField is visible on the child's
    ``_meta.get_fields()`` and must be skipped just as cleanly.
    """
    child = InheritedChild.objects.create(name="mti-child", extra="data")

    # Must not raise.
    child.delete()

    child.refresh_from_db()
    assert child.deleted_at is not None


# --------------------------------------------------------------------------- #
# NO_DELETE — always rejects
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_no_delete_policy_rejects_soft():
    row = NoDeleteRecord.objects.create(name="singleton")
    with pytest.raises(PermissionError):
        row.delete()


@pytest.mark.django_db
def test_no_delete_policy_rejects_hard_even_with_token():
    row = NoDeleteRecord.objects.create(name="singleton")
    with cleanup_context():
        token = RetentionToken.issue(purpose="test")
    with pytest.raises(PermissionError):
        row.hard_delete(retention_token=token)


# --------------------------------------------------------------------------- #
# HARD_DELETE / HARD_DELETE_NOCASCADE — internal, not accessible via delete()
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_hard_delete_policy_not_reachable_via_delete():
    """Plugin authors cannot bypass soft-delete by declaring a hard policy.

    Even if ``Archive.cascade_policy = HARD_DELETE``, calling
    ``instance.delete()`` must still go through the soft-delete path;
    the only way to do a physical delete is via ``hard_delete()`` +
    ``RetentionToken``. The hard policies are *retention-cleanup*
    behaviours, not everyday user deletes.
    """

    # Build an ad-hoc policy check — we don't want a real HARD_DELETE
    # model in test data (the whole point is that you can't get one via
    # delete()). Just prove the manager guards the path.
    folder = Folder.objects.create(name="x")
    # Monkeypatch Archive for this instance only
    folder.Archive.cascade_policy = CascadePolicy.HARD_DELETE
    try:
        folder.delete()
    finally:
        folder.Archive.cascade_policy = CascadePolicy.SOFT_DELETE_CASCADE

    # Row still exists physically — delete() degraded to soft
    assert Folder.all_objects.filter(pk=folder.pk).exists()
    folder.refresh_from_db()
    assert folder.deleted_at is not None
