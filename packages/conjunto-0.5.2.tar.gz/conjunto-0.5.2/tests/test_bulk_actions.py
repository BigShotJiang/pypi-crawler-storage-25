"""Tests for conjunto.tables.BulkAction / IBulkAction / get_bulk_actions
and the matching ``BulkActionView`` server-side handler."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser, Permission
from django.core.exceptions import ImproperlyConfigured, PermissionDenied
from django.http import HttpRequest
from django.urls import path

from conjunto.htmx.views import BulkActionView
from conjunto.tables import (
    BulkAction,
    IBulkAction,
    get_bulk_actions,
)
from tests.test_app.models import Person

User = get_user_model()


def _request(user=None, method="GET"):
    req = HttpRequest()
    req.method = method
    req.user = user or AnonymousUser()
    req.META["SERVER_NAME"] = "testserver"
    req.META["SERVER_PORT"] = "80"
    return req


# --------------------------------------------------------------------------- #
# BulkAction dataclass                                                        #
# --------------------------------------------------------------------------- #


def test_bulk_action_resolve_url_string():
    a = BulkAction(name="delete", label="Delete", url="/delete/")
    assert a.resolve_url(_request()) == "/delete/"


def test_bulk_action_resolve_url_callable():
    a = BulkAction(
        name="delete",
        label="Delete",
        url=lambda req: f"/delete/?u={req.user.username}",
    )
    user = MagicMock(username="alice")
    assert a.resolve_url(_request(user)) == "/delete/?u=alice"


def test_bulk_action_is_allowed_no_permission():
    a = BulkAction(name="x", label="X")
    assert a.is_allowed(_request()) is True


def test_bulk_action_is_allowed_permission_string_rejects_anonymous():
    a = BulkAction(name="x", label="X", permission="auth.delete_user")
    assert a.is_allowed(_request()) is False


def test_bulk_action_is_allowed_permission_callable():
    a = BulkAction(
        name="x",
        label="X",
        permission=lambda req: req.user.username == "alice",
    )
    user = MagicMock(username="alice")
    assert a.is_allowed(_request(user)) is True


def test_bulk_action_is_allowed_visible_callable():
    a = BulkAction(name="x", label="X", visible=lambda req: False)
    assert a.is_allowed(_request()) is False


def test_bulk_action_render_attrs_direct_post_default():
    """Without a confirm message, the button posts directly."""
    a = BulkAction(name="resend", label="Resend", url="/resend/")
    attrs = a.render_attrs(_request())
    assert attrs["hx-post"] == "/resend/"
    assert attrs["hx-swap"] == "none"
    assert "hx-confirm" not in attrs
    assert "hx-get" not in attrs
    assert attrs["hx-include"] == "[name='pks']:checked"


def test_bulk_action_render_attrs_modal_confirm():
    """When confirm is set with default ``confirm_style='modal'``, the
    button GETs the URL into ``#dialog`` so the server returns the
    confirmation modal."""
    a = BulkAction(
        name="delete",
        label="Delete",
        url="/bulk-delete/",
        confirm="Sure?",
    )
    attrs = a.render_attrs(_request())
    assert attrs["hx-get"] == "/bulk-delete/"
    assert attrs["hx-target"] == "#dialog"
    assert attrs["hx-swap"] == "innerHTML"
    assert "hx-post" not in attrs
    assert "hx-confirm" not in attrs  # inline confirm not used here
    assert attrs["hx-include"] == "[name='pks']:checked"


def test_bulk_action_render_attrs_inline_confirm():
    """``confirm_style='inline'`` uses the browser-native confirm
    prompt and POSTs directly."""
    a = BulkAction(
        name="unblock",
        label="Unblock",
        url="/unblock/",
        confirm="Unblock all selected?",
        confirm_style="inline",
    )
    attrs = a.render_attrs(_request())
    assert attrs["hx-post"] == "/unblock/"
    assert attrs["hx-confirm"] == "Unblock all selected?"
    assert "hx-get" not in attrs


def test_bulk_action_render_attrs_custom_pk_field():
    """A non-default ``pk_field`` rewrites the ``hx-include`` selector."""
    a = BulkAction(name="x", label="X", url="/x/", pk_field="ids")
    attrs = a.render_attrs(_request())
    assert attrs["hx-include"] == "[name='ids']:checked"


def test_bulk_action_render_attrs_extra_attrs_override():
    a = BulkAction(
        name="x",
        label="X",
        url="/x/",
        extra_attrs={"data-thing": "1", "class": "btn btn-danger"},
    )
    attrs = a.render_attrs(_request())
    assert attrs["data-thing"] == "1"
    # extra_attrs wins for overlapping keys (override semantics)
    assert attrs["class"] == "btn btn-danger"


# --------------------------------------------------------------------------- #
# IBulkAction (GDAPS Interface) + get_bulk_actions                            #
# --------------------------------------------------------------------------- #


def test_ibulk_action_is_gdaps_interface():
    from gdaps.api.base import InterfaceMeta

    assert isinstance(IBulkAction, InterfaceMeta)


def test_ibulk_action_default_menu_and_weight():
    class DummyAction(IBulkAction):
        menu = "projects.bulk"

        def to_bulk_action(self, request):
            return None

    p = DummyAction()
    assert p.menu == "projects.bulk"
    assert p.weight == 100


def test_get_bulk_actions_filters_disallowed_and_sorts():
    """get_bulk_actions filters by is_allowed and sorts by weight."""
    a = BulkAction(name="a", label="A", url="/a/", weight=20)
    b = BulkAction(name="b", label="B", url="/b/", weight=10)
    c = BulkAction(
        name="c", label="C", url="/c/", weight=5, visible=lambda r: False
    )
    out = get_bulk_actions(_request(), actions=[a, b, c])
    assert [x.name for x in out] == ["b", "a"]


def test_get_bulk_actions_pulls_plugins_for_matching_menu(monkeypatch):
    """Plugins on the matching menu slot are appended to the iterable."""

    class PluginA(IBulkAction):
        menu = "accounts.bulk"
        weight = 30

        def to_bulk_action(self, request):
            return BulkAction(name="export", label="Export", url="/export/")

    class PluginB(IBulkAction):
        menu = "other.menu"

        def to_bulk_action(self, request):
            return BulkAction(name="x", label="X", url="/x/")

    monkeypatch.setattr(
        IBulkAction,
        "enabled_plugins",
        classmethod(lambda cls: [PluginA, PluginB]),
    )

    static_action = BulkAction(name="delete", label="Delete", url="/del/", weight=10)
    out = get_bulk_actions(
        _request(), actions=[static_action], menu="accounts.bulk"
    )
    # PluginB is on a different slot → not included; PluginA appears
    # and inherits its plugin-class weight (30), so it sorts after
    # the static action (weight 10).
    assert [x.name for x in out] == ["delete", "export"]
    assert out[1].weight == 30


def test_get_bulk_actions_skips_plugin_returning_none(monkeypatch):
    class PluginSkip(IBulkAction):
        menu = "accounts.bulk"

        def to_bulk_action(self, request):
            return None

    monkeypatch.setattr(
        IBulkAction, "enabled_plugins", classmethod(lambda cls: [PluginSkip])
    )

    out = get_bulk_actions(_request(), actions=[], menu="accounts.bulk")
    assert out == []


# --------------------------------------------------------------------------- #
# Template tag                                                                #
# --------------------------------------------------------------------------- #


def test_bulk_action_attrs_tag(rf):
    from django.template import Context, Template

    request = rf.get("/")
    request.user = AnonymousUser()
    action = BulkAction(name="delete", label="Delete", url="/del/")
    tpl = Template(
        "{% load conjunto_tables %}"
        "{% bulk_action_attrs action as a %}"
        "{{ a.class }}"
    )
    rendered = tpl.render(Context({"request": request, "action": action}))
    assert "btn" in rendered
    # Direct render_attrs is the canonical lookup for hyphenated keys.
    assert action.render_attrs(request)["hx-post"] == "/del/"


# --------------------------------------------------------------------------- #
# BulkActionView                                                              #
# --------------------------------------------------------------------------- #


class _DeletePersonView(BulkActionView):
    model = Person
    success_event = "people:changed"

    def perform(self, queryset):
        queryset.delete()


urlpatterns = [
    path("bulk-delete/", _DeletePersonView.as_view(), name="bulk_delete"),
]


@pytest.fixture(autouse=True)
def _urls(settings):
    settings.ROOT_URLCONF = "tests.test_bulk_actions"


def _htmx_request(rf, method, path, **kwargs):
    if method == "GET":
        req = rf.get(path, **kwargs)
    else:
        req = rf.post(path, **kwargs)
    req.htmx = True
    req.user = AnonymousUser()
    return req


def test_bulk_action_view_get_renders_confirm_modal(rf, db):
    Person.objects.create(name="Alice")
    Person.objects.create(name="Bob")
    pks = [str(p.pk) for p in Person.objects.all()]
    req = _htmx_request(rf, "GET", "/bulk-delete/", data={"pks": pks})

    response = _DeletePersonView.as_view()(req)

    assert response.status_code == 200
    body = response.content.decode()
    # The default modal template includes hidden inputs for each pk so
    # the form POST round-trips them.
    for pk in pks:
        assert f'name="pks" value="{pk}"' in body
    assert "Apply action to 2 items?" in body


def test_bulk_action_view_post_performs_and_triggers(rf, db):
    p1 = Person.objects.create(name="Alice")
    p2 = Person.objects.create(name="Bob")
    p3 = Person.objects.create(name="Carol")
    req = _htmx_request(
        rf, "POST", "/bulk-delete/", data={"pks": [str(p1.pk), str(p2.pk)]}
    )

    response = _DeletePersonView.as_view()(req)

    assert response.status_code == 204
    # HX-Trigger fires for the configured success_event.
    assert response["HX-Trigger"] == "people:changed"
    # Only the selected pks were deleted.
    remaining = list(Person.objects.values_list("pk", flat=True))
    assert remaining == [p3.pk]


def test_bulk_action_view_post_empty_pks_is_noop(rf, db):
    Person.objects.create(name="Alice")
    req = _htmx_request(rf, "POST", "/bulk-delete/", data={})

    response = _DeletePersonView.as_view()(req)

    assert response.status_code == 204
    assert Person.objects.count() == 1


def test_bulk_action_view_rejects_non_htmx(rf, db):
    req = rf.post("/bulk-delete/", data={"pks": []})
    req.htmx = False
    req.user = AnonymousUser()
    with pytest.raises(PermissionDenied):
        _DeletePersonView.as_view()(req)


def test_bulk_action_view_permission_denied_for_lacking_user(rf, db):
    class _GatedView(_DeletePersonView):
        permission_required = "test_app.delete_person"

    req = _htmx_request(rf, "POST", "/bulk-delete/", data={"pks": []})
    with pytest.raises(PermissionDenied):
        _GatedView.as_view()(req)


def test_bulk_action_view_permission_allows_user_with_perm(rf, db):
    class _GatedView(_DeletePersonView):
        permission_required = "test_app.delete_person"

    user = User.objects.create_user(username="boss", password="x")
    perm = Permission.objects.get(
        codename="delete_person", content_type__app_label="test_app"
    )
    user.user_permissions.add(perm)
    # Re-fetch so the perms cache is populated freshly.
    user = User.objects.get(pk=user.pk)

    req = _htmx_request(rf, "POST", "/bulk-delete/", data={"pks": []})
    req.user = user

    response = _GatedView.as_view()(req)
    assert response.status_code == 204


def test_bulk_action_view_requires_model_or_queryset_override(rf):
    class _Broken(BulkActionView):
        def perform(self, queryset):
            pass

    req = _htmx_request(rf, "POST", "/whatever/", data={})

    with pytest.raises(ImproperlyConfigured):
        _Broken.as_view()(req)


def test_bulk_action_view_perform_must_be_implemented(rf, db):
    class _NoPerform(BulkActionView):
        model = Person

    Person.objects.create(name="Alice")
    req = _htmx_request(rf, "POST", "/whatever/", data={"pks": ["1"]})

    with pytest.raises(NotImplementedError):
        _NoPerform.as_view()(req)
