"""Phase-1 GDAPS plugin integration smoke tests.

Validates that a model using ``ArchivableMixin`` is a well-behaved
Django/GDAPS citizen — importable from the public API, registered with
the app registry, combinable with common mixins, and does not break
migration autodetection.
"""

from __future__ import annotations

import pytest
from django.apps import apps

from tests.test_app.archivable_models import Folder


def test_public_api_exports():
    import conjunto.archive as arc

    # All Phase-1 public symbols must be importable from the package.
    for name in (
        "ArchivableMixin",
        "CascadePolicy",
        "StaleObjectError",
    ):
        assert hasattr(arc, name), f"conjunto.archive.{name} missing"


def test_archive_app_registered():
    cfg = apps.get_app_config("conjunto_archive")
    assert cfg.name == "conjunto.archive"


def test_log_models_registered():
    """``ArchiveAccessLog`` and ``DeletionLog`` live under the archive app."""
    access = apps.get_model("conjunto_archive", "ArchiveAccessLog")
    deletion = apps.get_model("conjunto_archive", "DeletionLog")
    assert access is not None
    assert deletion is not None


@pytest.mark.django_db
def test_archivable_model_has_mixin_fields():
    """Every ArchivableMixin subclass exposes the four lifecycle fields."""
    names = {f.name for f in Folder._meta.get_fields()}
    assert {"deleted_at", "deleted_by", "deleted_by_cascade", "row_version"}.issubset(
        names
    )


@pytest.mark.django_db
def test_archivable_model_has_three_managers():
    """ArchivableMixin provides three canonical managers."""
    assert hasattr(Folder, "objects")
    assert hasattr(Folder, "all_objects")
    assert hasattr(Folder, "deleted_objects")

    # And they behave as advertised:
    Folder.objects.create(name="alive")
    dead = Folder.objects.create(name="dead")
    dead.delete()

    assert Folder.objects.count() == 1
    assert Folder.all_objects.count() == 2
    assert Folder.deleted_objects.count() == 1


@pytest.mark.django_db
def test_mro_cooperative_with_plain_model():
    """ArchivableMixin calls ``super().save()`` correctly."""
    folder = Folder(name="x")
    folder.save()  # Should not raise
    assert folder.pk is not None
