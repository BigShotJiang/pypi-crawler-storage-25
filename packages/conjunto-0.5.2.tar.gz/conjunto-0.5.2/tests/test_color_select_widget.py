"""Tests for ColorSelect / ColorSelectMultiple / ColorField."""

from __future__ import annotations

from django import forms
from django.http import QueryDict

from conjunto.forms import (
    ColorField,
    ColorSelect,
    ColorSelectMultiple,
    TABLER_COLORS,
)


def test_default_choices_are_tabler_palette():
    widget = ColorSelect()
    rendered = widget.render("color", None)
    for value, _label in TABLER_COLORS:
        assert f'value="{value}"' in rendered
        assert f"bg-{value}" in rendered


def test_renders_radio_inputs_by_default():
    widget = ColorSelect()
    html = widget.render("color", None)
    assert 'type="radio"' in html
    assert 'type="checkbox"' not in html


def test_renders_checkbox_inputs_when_multiple():
    widget = ColorSelect(multiple=True)
    html = widget.render("color", None)
    assert 'type="checkbox"' in html
    assert 'type="radio"' not in html


def test_renders_form_colorinput_markup():
    widget = ColorSelect()
    html = widget.render("color", None)
    assert "form-colorinput" in html
    assert "form-colorinput-input" in html
    assert "form-colorinput-color" in html


def test_white_swatch_gets_light_modifier():
    widget = ColorSelect()
    html = widget.render("color", None)
    # The label that wraps the white swatch gets ``form-colorinput-light``.
    # Cheap way to assert that without HTML parsing: split on the value
    # marker and check the surrounding text.
    blue_idx = html.index('value="blue"')
    white_idx = html.index('value="white"')
    blue_section = html[max(0, blue_idx - 200) : blue_idx]
    white_section = html[max(0, white_idx - 200) : white_idx]
    assert "form-colorinput-light" in white_section
    assert "form-colorinput-light" not in blue_section


def test_custom_light_colors_override_default():
    widget = ColorSelect(light_colors=("yellow",))
    html = widget.render("color", None)
    yellow_idx = html.index('value="yellow"')
    white_idx = html.index('value="white"')
    yellow_section = html[max(0, yellow_idx - 200) : yellow_idx]
    white_section = html[max(0, white_idx - 200) : white_idx]
    assert "form-colorinput-light" in yellow_section
    assert "form-colorinput-light" not in white_section


def test_selected_value_marks_input_checked():
    widget = ColorSelect()
    html = widget.render("color", "red")
    red_idx = html.index('value="red"')
    red_section = html[max(0, red_idx - 200) : red_idx + 50]
    assert "checked" in red_section


def test_custom_choices_replace_palette():
    widget = ColorSelect(choices=(("primary", "Primary"), ("secondary", "Secondary")))
    html = widget.render("color", None)
    assert 'value="primary"' in html
    assert "bg-primary" in html
    assert 'value="blue"' not in html


def test_label_renders_as_title_for_tooltip():
    widget = ColorSelect()
    html = widget.render("color", None)
    assert 'title="Blue"' in html
    assert 'title="Red"' in html


def test_color_select_multiple_value_from_querydict():
    widget = ColorSelectMultiple()
    data = QueryDict("color=blue&color=red")
    assert widget.value_from_datadict(data, {}, "color") == ["blue", "red"]


def test_color_select_multiple_omitted_from_data():
    widget = ColorSelectMultiple()
    data = QueryDict("other=foo")
    assert widget.value_omitted_from_data(data, {}, "color") is True
    data2 = QueryDict("color=blue")
    assert widget.value_omitted_from_data(data2, {}, "color") is False


def test_color_field_validates_against_palette():
    class TagForm(forms.Form):
        color = ColorField()

    valid = TagForm(data={"color": "blue"})
    assert valid.is_valid()
    assert valid.cleaned_data["color"] == "blue"

    invalid = TagForm(data={"color": "rainbow"})
    assert not invalid.is_valid()
    assert "color" in invalid.errors


def test_color_field_uses_color_select_widget():
    class TagForm(forms.Form):
        color = ColorField()

    form = TagForm()
    assert isinstance(form.fields["color"].widget, ColorSelect)


def test_color_field_multiple_uses_multiple_widget():
    class TagForm(forms.Form):
        color = ColorField(multiple=True)

    form = TagForm()
    assert isinstance(form.fields["color"].widget, ColorSelectMultiple)


def test_color_field_custom_choices():
    class TagForm(forms.Form):
        color = ColorField(choices=(("primary", "Primary"),))

    form = TagForm(data={"color": "blue"})
    assert not form.is_valid()
    form2 = TagForm(data={"color": "primary"})
    assert form2.is_valid()


def test_color_field_initial_renders_as_checked():
    class TagForm(forms.Form):
        color = ColorField(initial="green")

    html = TagForm().as_p()
    green_idx = html.index('value="green"')
    green_section = html[max(0, green_idx - 200) : green_idx + 50]
    assert "checked" in green_section
