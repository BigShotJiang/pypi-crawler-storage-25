"""Phase-4 tests for ``manage.py archive_reconcile``.

Covers:

- Dry-run flags which rows would be re-deleted without writing anything.
- Real run re-purges rows whose DeletionLog entry predates an apparent
  restore.
- Fresh DeletionLog rows are written with reason=reconcile_after_restore.
- Command is idempotent: running twice produces only one new log entry
  per rediscovered row.
"""

from __future__ import annotations

from io import StringIO

import pytest
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.utils import timezone

from conjunto.archive.models import DeletionLog, DeletionReason

from tests.test_app.archivable_models import Folder


@pytest.fixture
def user(db):
    User = get_user_model()
    return User.objects.create_user(username="alice", password="pw")


def _fake_deletion_log(instance) -> DeletionLog:
    """Seed a DeletionLog row that claims ``instance`` was already deleted."""
    return DeletionLog.objects.create(
        app_label="test_app",
        model_name=type(instance).__name__,
        object_pk=str(instance.pk),
        tenant=None,
        reason=DeletionReason.RETENTION_EXPIRED,
        triggered_by="archive_cleanup:simulated",
        deleted_at_final=timezone.now(),
    )


@pytest.mark.django_db
def test_dry_run_lists_without_deleting(user):
    folder = Folder.objects.create(name="zombie")
    _fake_deletion_log(folder)

    out = StringIO()
    call_command("archive_reconcile", "--dry-run", stdout=out)

    # Still there; no new DeletionLog row.
    assert Folder.all_objects.filter(pk=folder.pk).exists()
    assert DeletionLog.objects.count() == 1
    assert "would re-purge" in out.getvalue()


@pytest.mark.django_db
def test_real_run_repurges_zombie_row(user):
    folder = Folder.objects.create(name="zombie")
    _fake_deletion_log(folder)

    call_command("archive_reconcile", stdout=StringIO())

    assert not Folder.all_objects.filter(pk=folder.pk).exists()
    # Two DeletionLog rows now: the fake original + the reconcile entry.
    logs = DeletionLog.objects.all().order_by("created_at")
    assert logs.count() == 2
    reconcile_log = logs.last()
    assert reconcile_log.reason == DeletionReason.RECONCILE_AFTER_RESTORE
    assert reconcile_log.triggered_by.startswith("archive_reconcile:")


@pytest.mark.django_db
def test_reconcile_skips_rows_that_are_actually_gone(user):
    # No matching source row — the "resurrection" never happened.
    DeletionLog.objects.create(
        app_label="test_app",
        model_name="Folder",
        object_pk="999999",
        tenant=None,
        reason=DeletionReason.RETENTION_EXPIRED,
        triggered_by="archive_cleanup:simulated",
        deleted_at_final=timezone.now(),
    )

    out = StringIO()
    call_command("archive_reconcile", stdout=out)

    # No re-purge happened.
    assert (
        DeletionLog.objects.filter(
            reason=DeletionReason.RECONCILE_AFTER_RESTORE
        ).count()
        == 0
    )


@pytest.mark.django_db
def test_reconcile_is_idempotent(user):
    folder = Folder.objects.create(name="zombie")
    _fake_deletion_log(folder)

    call_command("archive_reconcile", stdout=StringIO())
    logs_after_first = DeletionLog.objects.filter(
        reason=DeletionReason.RECONCILE_AFTER_RESTORE
    ).count()
    call_command("archive_reconcile", stdout=StringIO())
    logs_after_second = DeletionLog.objects.filter(
        reason=DeletionReason.RECONCILE_AFTER_RESTORE
    ).count()

    # Second run finds no zombies → no new reconcile log entry.
    assert logs_after_first == 1
    assert logs_after_second == 1
