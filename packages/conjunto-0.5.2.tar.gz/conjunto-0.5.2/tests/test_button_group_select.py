"""ButtonGroupSelect renders Tabler btn-group markup."""

from __future__ import annotations

from django import forms

from conjunto.forms import ButtonGroupSelect, ButtonGroupSelectMultiple


CHOICES = [
    ("active", "Active"),
    ("former", "Former"),
    ("never", "Never"),
]


def _render(widget, value=""):
    class F(forms.Form):
        f = forms.ChoiceField(choices=CHOICES, widget=widget)

    return F(initial={"f": value} if value else None)["f"].as_widget()


def test_horizontal_renders_btn_group():
    out = _render(ButtonGroupSelect(choices=CHOICES))
    assert 'class="btn-group ' in out
    assert "btn-group-vertical" not in out


def test_vertical_renders_btn_group_vertical():
    out = _render(ButtonGroupSelect(choices=CHOICES, vertical=True))
    assert "btn-group-vertical" in out


def test_radio_inputs_by_default():
    out = _render(ButtonGroupSelect(choices=CHOICES))
    assert 'type="radio"' in out
    assert 'type="checkbox"' not in out


def test_multiple_renders_checkboxes():
    out = _render(ButtonGroupSelectMultiple(choices=CHOICES))
    assert 'type="checkbox"' in out
    assert 'type="radio"' not in out


def test_btn_check_class_on_input():
    out = _render(ButtonGroupSelect(choices=CHOICES))
    assert 'class="btn-check"' in out


def test_label_renders_choice_text():
    out = _render(ButtonGroupSelect(choices=CHOICES))
    assert "Active" in out
    assert "Former" in out
    assert "Never" in out


def test_selected_value_marks_checked():
    out = _render(ButtonGroupSelect(choices=CHOICES), value="former")
    # The "former" input must be checked, others not.
    # Crude but reliable: check that "checked" appears exactly once.
    assert out.count("checked") == 1


def test_multiple_vertical_combined():
    out = _render(
        ButtonGroupSelectMultiple(choices=CHOICES, vertical=True),
    )
    assert "btn-group-vertical" in out
    assert 'type="checkbox"' in out
