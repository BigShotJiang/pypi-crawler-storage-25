"""Tests for ``conjunto.auth.forms.ConjuntoAuthenticationForm`` and the
``ILoginViewExtension`` plugin hook.

Covers:

- The ``remember_me`` checkbox is gated by the
  ``auth.show_remember_me`` scoped setting (rendered + applied iff
  truthy).
- ``ILoginViewExtension.form_valid`` fires after the effective login
  on the classic path AND on the two-step tenant-pick path.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from django.contrib.auth import get_user_model

from conjunto.api.interfaces import ILoginViewExtension
from conjunto.auth.forms import ConjuntoAuthenticationForm
from conjunto.auth.views import PENDING_LOGIN_KEY
from conjunto.tenants.models import Tenant, TenantMembership
from conjunto.tenants.views import SESSION_KEY as TENANT_SESSION_KEY


pytestmark = pytest.mark.django_db
User = get_user_model()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _patch_view_extensions(monkeypatch, extensions):
    monkeypatch.setattr(
        ILoginViewExtension,
        "enabled_plugins",
        classmethod(lambda cls: list(extensions)),
    )


def _patch_show_remember_me(monkeypatch, value: bool):
    """Stub ``_show_remember_me`` to a fixed value so tests don't need the
    scoped-settings middleware to be wired up."""
    from conjunto.auth import forms as forms_module

    monkeypatch.setattr(forms_module, "_show_remember_me", lambda request: value)


# ---------------------------------------------------------------------------
# remember_me checkbox gating
# ---------------------------------------------------------------------------


def test_remember_me_field_present_when_setting_is_truthy(monkeypatch):
    from django import forms

    _patch_show_remember_me(monkeypatch, True)
    form = ConjuntoAuthenticationForm()
    assert "remember_me" in form.fields
    assert isinstance(form.fields["remember_me"], forms.BooleanField)


def test_remember_me_field_absent_when_setting_is_falsy(monkeypatch):
    _patch_show_remember_me(monkeypatch, False)
    form = ConjuntoAuthenticationForm()
    assert "remember_me" not in form.fields


def test_remember_me_in_html_when_visible(client, monkeypatch):
    _patch_show_remember_me(monkeypatch, True)
    response = client.get("/accounts/login/")
    assert response.status_code == 200
    body = response.content.decode()
    assert 'name="remember_me"' in body


def test_remember_me_hidden_when_setting_off(client, monkeypatch):
    _patch_show_remember_me(monkeypatch, False)
    response = client.get("/accounts/login/")
    assert response.status_code == 200
    body = response.content.decode()
    assert 'name="remember_me"' not in body


def test_remember_me_post_ignored_when_hidden(client, monkeypatch):
    """Even if a malicious POST sends ``remember_me=on``, the gating in
    ``get_remember_me`` must enforce the setting."""
    _patch_show_remember_me(monkeypatch, False)
    User.objects.create_user(username="alice", password="hunter2")

    captured = {}

    def fake_set_session_lifetime(request, remember_me):
        captured["remember_me"] = remember_me

    with patch(
        "conjunto.auth.views._set_session_lifetime",
        side_effect=fake_set_session_lifetime,
    ):
        client.post(
            "/accounts/login/",
            {"username": "alice", "password": "hunter2", "remember_me": "on"},
        )
    assert captured.get("remember_me") is False


def test_remember_me_post_applied_when_visible(client, monkeypatch):
    _patch_show_remember_me(monkeypatch, True)
    User.objects.create_user(username="alice", password="hunter2")

    captured = {}

    def fake_set_session_lifetime(request, remember_me):
        captured["remember_me"] = remember_me

    with patch(
        "conjunto.auth.views._set_session_lifetime",
        side_effect=fake_set_session_lifetime,
    ):
        client.post(
            "/accounts/login/",
            {"username": "alice", "password": "hunter2", "remember_me": "on"},
        )
    assert captured.get("remember_me") is True


def test_username_field_renders_as_text_input(client, monkeypatch):
    """Regression: the username field must render as ``<input type="text">``,
    never ``type="email"``.

    Django's standard auth backend authenticates by ``username`` (not
    by e-mail). If the field were ``type="email"``, HTML5 client-side
    validation would block any user whose username is not in e-mail
    shape — even though the credentials are perfectly valid server-side.

    Pinning the input type here keeps the bug from regressing through
    a future widget tweak (e.g. a `FloatingField` subclass override or
    a stray ``attrs={"type": "email"}`` on the username field).
    """
    _patch_show_remember_me(monkeypatch, False)
    response = client.get("/accounts/login/")
    assert response.status_code == 200
    body = response.content.decode()
    import re

    match = re.search(r'<input[^>]*name="username"[^>]*>', body)
    assert match is not None, "username input not found in rendered login form"
    rendered = match.group(0)
    assert (
        'type="text"' in rendered
    ), f"username field must render as type=text, got: {rendered}"
    assert (
        'type="email"' not in rendered
    ), f"username field must NOT render as type=email, got: {rendered}"


def test_remember_me_unchecked_yields_false(client, monkeypatch):
    _patch_show_remember_me(monkeypatch, True)
    User.objects.create_user(username="alice", password="hunter2")

    captured = {}

    def fake_set_session_lifetime(request, remember_me):
        captured["remember_me"] = remember_me

    with patch(
        "conjunto.auth.views._set_session_lifetime",
        side_effect=fake_set_session_lifetime,
    ):
        client.post(
            "/accounts/login/",
            {"username": "alice", "password": "hunter2"},
        )
    assert captured.get("remember_me") is False


# ---------------------------------------------------------------------------
# ILoginViewExtension.form_valid lifecycle
# ---------------------------------------------------------------------------


class _RecordingViewExtension:
    """View extension that records every ``form_valid`` call."""

    calls: list = []

    @classmethod
    def form_valid(cls, view, request, user, form):
        cls.calls.append({"user_pk": user.pk, "auth": user.is_authenticated})

    @classmethod
    def alter_context_data(cls, view, ctx):
        ctx["_recorded"] = True


@pytest.fixture(autouse=True)
def _reset_recording_extension():
    _RecordingViewExtension.calls = []
    yield
    _RecordingViewExtension.calls = []


@pytest.fixture(autouse=True)
def _ensure_default_site(db):
    """Django's stock ``LoginView.get_context_data`` calls
    ``get_current_site(request)`` which requires a Site row. Existing
    auth tests POST only, but our tests also GET ``/accounts/login/``
    to inspect the rendered form — so we seed a default Site and clear
    the per-process domain cache."""
    from django.contrib.sites.models import SITE_CACHE, Site

    SITE_CACHE.clear()
    Site.objects.update_or_create(
        pk=1, defaults={"domain": "testserver", "name": "test"}
    )
    yield
    SITE_CACHE.clear()


def test_view_extension_fires_on_classic_login(client, monkeypatch):
    _patch_view_extensions(monkeypatch, [_RecordingViewExtension])
    user = User.objects.create_user(username="alice", password="hunter2")

    response = client.post(
        "/accounts/login/", {"username": "alice", "password": "hunter2"}
    )
    assert response.status_code == 302
    assert len(_RecordingViewExtension.calls) == 1
    call = _RecordingViewExtension.calls[0]
    assert call["user_pk"] == user.pk
    assert call["auth"] is True


def test_view_extension_does_not_fire_on_invalid_credentials(client, monkeypatch):
    _patch_view_extensions(monkeypatch, [_RecordingViewExtension])
    User.objects.create_user(username="alice", password="hunter2")

    client.post("/accounts/login/", {"username": "alice", "password": "wrong"})
    assert _RecordingViewExtension.calls == []


def test_view_extension_does_not_fire_on_deferred_credentials(client, monkeypatch):
    """Two-tenant path: the credentials POST defers the actual login —
    extensions must NOT run yet, since ``user`` would not be authenticated."""
    _patch_view_extensions(monkeypatch, [_RecordingViewExtension])

    acme = Tenant.objects.create(name="Acme", slug="acme")
    globex = Tenant.objects.create(name="Globex", slug="globex")
    user = User.objects.create_user(username="alice", password="hunter2")
    TenantMembership.objects.create(user=user, tenant=acme, role="admin")
    TenantMembership.objects.create(user=user, tenant=globex, role="admin")

    client.post(
        "/accounts/login/",
        {"username": "alice", "password": "hunter2"},
        HTTP_HX_REQUEST="true",
    )
    assert PENDING_LOGIN_KEY in client.session
    assert _RecordingViewExtension.calls == []


def test_view_extension_fires_after_tenant_pick(client, monkeypatch):
    _patch_view_extensions(monkeypatch, [_RecordingViewExtension])

    acme = Tenant.objects.create(name="Acme", slug="acme")
    globex = Tenant.objects.create(name="Globex", slug="globex")
    user = User.objects.create_user(username="alice", password="hunter2")
    TenantMembership.objects.create(user=user, tenant=acme, role="admin")
    TenantMembership.objects.create(user=user, tenant=globex, role="admin")

    client.post(
        "/accounts/login/",
        {"username": "alice", "password": "hunter2"},
        HTTP_HX_REQUEST="true",
    )
    response = client.post(
        "/accounts/login-complete/",
        {"tenant": str(globex.pk)},
        HTTP_HX_REQUEST="true",
    )
    assert response.status_code == 204
    assert client.session[TENANT_SESSION_KEY] == globex.pk
    assert len(_RecordingViewExtension.calls) == 1
    assert _RecordingViewExtension.calls[0]["user_pk"] == user.pk


def test_view_extension_alter_context_data_runs(client, monkeypatch):
    _patch_view_extensions(monkeypatch, [_RecordingViewExtension])
    response = client.get("/accounts/login/")
    assert response.status_code == 200
    assert response.context.get("_recorded") is True
