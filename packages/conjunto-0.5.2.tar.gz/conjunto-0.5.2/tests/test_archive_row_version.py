"""Phase-1 tests for optimistic locking via ``row_version``."""

from __future__ import annotations

import pytest

from conjunto.archive.exceptions import StaleObjectError

from tests.test_app.archivable_models import Folder


@pytest.mark.django_db
def test_row_version_starts_at_zero():
    folder = Folder.objects.create(name="Inbox")
    assert folder.row_version == 0


@pytest.mark.django_db
def test_row_version_increments_on_save():
    folder = Folder.objects.create(name="Inbox")
    assert folder.row_version == 0

    folder.name = "Outbox"
    folder.save()

    assert folder.row_version == 1
    folder.refresh_from_db()
    assert folder.row_version == 1


@pytest.mark.django_db
def test_row_version_increments_on_every_update():
    folder = Folder.objects.create(name="A")
    for expected in (1, 2, 3):
        folder.name = f"A{expected}"
        folder.save()
        assert folder.row_version == expected


@pytest.mark.django_db
def test_parallel_update_raises_stale_object_error():
    """Two concurrent loads of the same row must conflict on save."""
    folder = Folder.objects.create(name="Inbox")

    # Simulate two independent actors loading the same row.
    view_a = Folder.objects.get(pk=folder.pk)
    view_b = Folder.objects.get(pk=folder.pk)

    view_a.name = "By A"
    view_a.save()

    view_b.name = "By B"
    with pytest.raises(StaleObjectError):
        view_b.save()


@pytest.mark.django_db
def test_row_version_never_decremented_on_retry():
    """After a StaleObjectError, a reloaded instance continues the sequence."""
    folder = Folder.objects.create(name="Inbox")

    view_a = Folder.objects.get(pk=folder.pk)
    view_b = Folder.objects.get(pk=folder.pk)

    view_a.name = "first"
    view_a.save()
    assert view_a.row_version == 1

    view_b.name = "doomed"
    with pytest.raises(StaleObjectError):
        view_b.save()

    # Reload and retry
    view_b.refresh_from_db()
    assert view_b.row_version == 1
    view_b.name = "second"
    view_b.save()
    assert view_b.row_version == 2


@pytest.mark.django_db
def test_row_version_not_bumped_on_create():
    """Creating a brand-new row sets row_version to 0, not 1."""
    folder = Folder.objects.create(name="Inbox")
    # First save is an INSERT, not an UPDATE. Nothing to compare against.
    assert folder.row_version == 0
