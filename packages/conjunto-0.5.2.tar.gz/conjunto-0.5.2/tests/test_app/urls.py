"""Test project root URL conf.

Includes ``conjunto.settings.urls`` and the core ``conjunto.urls``
(for the ``maintenance`` URL name required by
``ConjuntoMiddleware._maintenance_redirect``). In real projects you
would let ``PluginManager.urlpatterns()`` auto-mount GDAPS plugin URLs,
but in the test harness we wire them directly to keep the test setup
self-contained.
"""

from django.http import HttpResponse
from django.urls import include, path

from conjunto.wizard.views import WizardFileDeleteView

from tests.test_app.wizard_views import WizardForTests
from tests.test_app.upload_views import PfuTestView

urlpatterns = [
    path("settings/", include("conjunto.settings.urls")),
    path("tenants/", include("conjunto.tenants.urls")),
    path("archive/", include("conjunto.archive.urls")),
    path("accounts/", include("conjunto.auth.urls")),
    path("shortcuts/", include("conjunto.shortcuts.urls")),
    path("accounts/logout/", lambda r: HttpResponse(""), name="logout"),
    # PersistentFileUploadMixin test view.
    path("pfu-test/", PfuTestView.as_view(), name="pfu-test"),
    # Wizard test harness: file-delete route first (more specific).
    path(
        "wizard/file/<int:pk>/",
        WizardFileDeleteView.as_view(),
        name="wizard-file-delete",
    ),
    path("wizard/", WizardForTests.as_view(), name="wizard-start"),
    path("wizard/<slug:step>/", WizardForTests.as_view(), name="wizard-step"),
    path("", include("conjunto.urls")),
]
