"""Minimal view for testing PersistentFileUploadMixin end-to-end."""

from django import forms
from django.shortcuts import render
from django.http import HttpResponse
from django.views import View

from conjunto.forms import PersistentFileField
from conjunto.views import PersistentFileUploadMixin


class PfuTestForm(forms.Form):
    document = PersistentFileField(required=True)
    count = forms.IntegerField(required=True)


class PfuTestView(PersistentFileUploadMixin, View):
    def get(self, request):
        form = PfuTestForm()
        return render(request, "test_app/pfu_form.html", {"form": form})

    def post(self, request):
        files = self.get_form_files(request)
        form = PfuTestForm(data=request.POST, files=files)
        if not form.is_valid():
            self.persist_form_files(request, form)
            return render(request, "test_app/pfu_form.html", {"form": form})
        self.clear_persisted_files(request)
        return HttpResponse("OK")
