"""Test models exercising ``conjunto.archive`` Phase 1 primitives.

These models live in the test app so that pytest-django's ``--nomigrations``
schema editor picks them up together with the other test models.
"""

from __future__ import annotations

from django.db import models

from conjunto.archive import ArchivableMixin, CascadePolicy


class Folder(ArchivableMixin, models.Model):
    """Parent model for cascade-delete tests."""

    name = models.CharField(max_length=64)

    class Meta:
        app_label = "test_app"

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE_CASCADE


class Document(ArchivableMixin, models.Model):
    """Archivable child model — cascade target of Folder."""

    title = models.CharField(max_length=64)
    folder = models.ForeignKey(
        Folder,
        on_delete=models.CASCADE,
        related_name="documents",
    )

    class Meta:
        app_label = "test_app"

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE


class Note(models.Model):
    """Non-archivable child model — used to verify cascade skips non-archivable."""

    text = models.CharField(max_length=255)
    folder = models.ForeignKey(
        Folder,
        on_delete=models.CASCADE,
        related_name="notes",
    )

    class Meta:
        app_label = "test_app"


class NoDeleteRecord(ArchivableMixin, models.Model):
    """Model that forbids any delete at all (system singletons)."""

    name = models.CharField(max_length=64)

    class Meta:
        app_label = "test_app"

    class Archive:
        cascade_policy = CascadePolicy.NO_DELETE


class SoftOnlyRecord(ArchivableMixin, models.Model):
    """Model with plain ``SOFT_DELETE`` policy (no cascade)."""

    label = models.CharField(max_length=64)

    class Meta:
        app_label = "test_app"

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE


class InheritedBase(ArchivableMixin, models.Model):
    """Parent model for multi-table-inheritance cascade tests.

    Exists separately from ``Folder`` so we can exercise the explicit
    ``OneToOneField(parent_link=True)`` forward-relation case (as seen
    in MedUX ``Patient.person -> Person``).
    """

    name = models.CharField(max_length=64)

    class Meta:
        app_label = "test_app"

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE_CASCADE


class InheritedChild(InheritedBase):
    """MTI child with an explicit ``parent_link`` OneToOneField.

    Mirrors the MedUX ``Patient -> Person`` relationship that used to
    crash ``_cascade_soft_delete`` because the forward parent-link
    ``OneToOneField`` has ``one_to_one=True`` but no
    ``get_accessor_name()``.
    """

    parent = models.OneToOneField(
        InheritedBase,
        on_delete=models.CASCADE,
        parent_link=True,
        primary_key=True,
        related_name="+",
    )
    extra = models.CharField(max_length=64, blank=True, default="")

    class Meta:
        app_label = "test_app"

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE_CASCADE


def _v1_to_v2(data: dict) -> dict:
    """Rename ``label_old`` to ``label`` on the snapshot payload."""
    out = dict(data)
    if "label_old" in out:
        out["label"] = out.pop("label_old")
    return out


# The migration chain must be set up *after* the ArchiveMigration import.
from conjunto.archive.schema.migration import ArchiveMigration  # noqa: E402


class VersionedRecord(ArchivableMixin, models.Model):
    """Archivable model that declares ``archive_schema_version=2``.

    Used by Phase-5 tests to validate that a snapshot taken under the
    older schema is migrated forward through the ``archive_migrations``
    chain before it is applied back onto the instance during revert.
    """

    label = models.CharField(max_length=64)

    archive_schema_version = 2

    class Meta:
        app_label = "test_app"

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE
        archive_migrations = [
            ArchiveMigration(
                from_version=1,
                to_version=2,
                migrate_fn=_v1_to_v2,
            )
        ]
