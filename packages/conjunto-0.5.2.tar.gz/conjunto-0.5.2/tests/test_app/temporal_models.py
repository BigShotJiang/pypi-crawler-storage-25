"""Test models exercising ``conjunto.archive.TemporalMixin`` (Phase 3).

These models are intentionally domain-agnostic so the Phase-3 tests
stay focused on the temporal primitives rather than MedUX-specific
semantics. The ``CombinedRate`` model exercises the
``ArchivableMixin + TemporalMixin`` combination that the Phase-3 DoD
requires.
"""

from __future__ import annotations

from django.db import models

from conjunto.archive import ArchivableMixin, CascadePolicy
from conjunto.archive.mixins.temporal import TemporalMixin


class TaxRate(TemporalMixin, models.Model):
    """Temporal-only model.

    Models a VAT rate that changes over time. Historical invoices need
    to query the rate that was valid on the invoice date.
    """

    name = models.CharField(max_length=32)
    rate = models.DecimalField(max_digits=5, decimal_places=2)

    class Meta:
        app_label = "test_app"


class CombinedRate(ArchivableMixin, TemporalMixin, models.Model):
    """Archivable + Temporal combined model.

    Proves the MRO works and that ``.supersede()`` triggers a snapshot
    via the Phase-2 hook.
    """

    name = models.CharField(max_length=32)
    rate = models.DecimalField(max_digits=5, decimal_places=2)

    class Meta:
        app_label = "test_app"

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE


class TemporalParent(ArchivableMixin, models.Model):
    """Non-temporal parent of ``TemporalChild`` — used to check that
    ``SOFT_DELETE_CASCADE`` on the parent does **not** supersede the
    temporal children.
    """

    name = models.CharField(max_length=32)

    class Meta:
        app_label = "test_app"

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE_CASCADE


class TemporalChild(ArchivableMixin, TemporalMixin, models.Model):
    """Temporal child of ``TemporalParent``.

    Combined with ``ArchivableMixin`` so soft-delete cascade from
    parent can run. The cascade soft-deletes the child row (sets
    ``deleted_at``); it must NOT touch ``valid_from`` / ``valid_to``.
    """

    parent = models.ForeignKey(
        TemporalParent,
        on_delete=models.CASCADE,
        related_name="children",
    )
    label = models.CharField(max_length=32)

    class Meta:
        app_label = "test_app"

    class Archive:
        cascade_policy = CascadePolicy.SOFT_DELETE
