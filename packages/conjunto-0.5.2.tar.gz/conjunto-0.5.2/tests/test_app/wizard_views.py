"""A concrete wizard used by the test suite."""

from __future__ import annotations

from django import forms

from conjunto.forms import PersistentFileField
from conjunto.wizard.forms import WizardStepForm
from conjunto.wizard.views import WizardStepView


class PersonalStep(WizardStepForm):
    first_name = forms.CharField(max_length=50)
    last_name = forms.CharField(max_length=50)


class PhotoStep(WizardStepForm):
    photo = PersistentFileField(required=True)
    note = forms.CharField(required=False, max_length=100)


class ConfirmStep(WizardStepForm):
    agreed = forms.BooleanField(required=True)


class WizardForTests(WizardStepView):
    wizard_key = "test_wizard"
    steps = [
        ("personal", PersonalStep),
        ("photo", PhotoStep),
        ("confirm", ConfirmStep),
    ]
    url_name = "wizard-step"
    success_url = "/wizard-done/"
    # Use only the partial template (the full app_base has too many deps
    # for the minimal test URL conf).
    template_name = "conjunto/wizard/_step_form.html"
    partial_template_name = "conjunto/wizard/_step_form.html"

    __test__ = False  # tell pytest this is not a test class
    committed: list = []

    def commit(self, draft) -> None:  # type: ignore[override]
        # Record a serializable snapshot for assertions.
        WizardForTests.committed.append(
            {
                "data": dict(draft.data),
                "files": [
                    (df.step, df.field, df.original_name) for df in draft.files.all()
                ],
                "user_id": draft.user_id,
            }
        )
