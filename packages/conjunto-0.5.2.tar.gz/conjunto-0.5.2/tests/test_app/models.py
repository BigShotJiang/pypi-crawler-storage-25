from django.db import models

from conjunto.models import HistoryVersionedModel, SingletonModel
from conjunto.sortable.models import SortableModelMixin
from conjunto.tenants.models import OptionalTenantModelMixin, TenantModelMixin

# Import archive test models so Django registers them with the app registry.
from tests.test_app.archivable_models import (  # noqa: F401
    Document,
    Folder,
    NoDeleteRecord,
    Note,
    SoftOnlyRecord,
    VersionedRecord,
)
from tests.test_app.temporal_models import (  # noqa: F401
    CombinedRate,
    TaxRate,
    TemporalChild,
    TemporalParent,
)


class SingletonTestModel(SingletonModel):
    app_label = "test_app"


class Person(models.Model):
    name = models.CharField(max_length=40)


class HistoryVersionedTestModel(HistoryVersionedModel):
    app_label = "test_app"
    title = models.CharField(max_length=255)
    content = models.TextField(blank=True)


class TenantDoc(TenantModelMixin):
    title = models.CharField(max_length=100)

    class Meta(TenantModelMixin.Meta):
        app_label = "test_app"


class OptionalTenantDoc(OptionalTenantModelMixin):
    title = models.CharField(max_length=100)

    class Meta(OptionalTenantModelMixin.Meta):
        app_label = "test_app"


class SortableTestParent(models.Model):
    """Parent container for ``SortableTestItem`` rows."""

    name = models.CharField(max_length=40)

    class Meta:
        app_label = "test_app"


class SortableTestItem(SortableModelMixin, models.Model):
    """Sortable child model exercising :class:`SortableModelMixin`."""

    parent = models.ForeignKey(
        SortableTestParent,
        on_delete=models.CASCADE,
        related_name="items",
        null=True,
        blank=True,
    )
    title = models.CharField(max_length=40)

    class Meta(SortableModelMixin.Meta):
        app_label = "test_app"


# Encrypted file fields ------------------------------------------------- #

from conjunto.fields import EncryptedFileField, EncryptedImageField  # noqa: E402


class EncryptedDoc(models.Model):
    """Minimal model exercising :class:`EncryptedFileField`."""

    tenant_id = models.IntegerField()
    title = models.CharField(max_length=100, blank=True, default="")
    blob = EncryptedFileField(upload_to="encdoc/", null=True, blank=True)
    blob_manifest = models.BinaryField(null=True, blank=True, editable=False)

    class Meta:
        app_label = "test_app"


class EncryptedImg(models.Model):
    """Minimal model exercising :class:`EncryptedImageField`."""

    tenant_id = models.IntegerField()
    width = models.PositiveIntegerField(null=True, blank=True)
    height = models.PositiveIntegerField(null=True, blank=True)
    pic = EncryptedImageField(
        upload_to="encimg/",
        width_field="width",
        height_field="height",
        null=True,
        blank=True,
    )
    pic_manifest = models.BinaryField(null=True, blank=True, editable=False)

    class Meta:
        app_label = "test_app"
