"""Test-only models for conjunto's test suite.

A concrete User model that picks up the tenant FK from
:class:`conjunto.tenants.users.TenantUserFKMixin` so the tests can
exercise the FK constraint, plus a tenant-aware UserManager that
defaults the FK on ``create_user``/``create_superuser``.
"""

from __future__ import annotations

from django.contrib.auth.models import AbstractUser, UserManager

from conjunto.tenants.managers import TenantAwareUserManagerMixin
from conjunto.tenants.users import TenantUserFKMixin


class TestUserManager(TenantAwareUserManagerMixin, UserManager):
    pass


class TestUser(TenantUserFKMixin, AbstractUser):
    objects = TestUserManager()

    class Meta:
        app_label = "tests"
