"""Phase-1 tests for ``conjunto.archive.ArchivableMixin``.

Covers soft-delete lifecycle, manager visibility, and hard-delete
gating. Snapshot behaviour is explicitly out of scope in Phase 1 —
``_create_snapshot`` is exercised in Phase 2.
"""

from __future__ import annotations

import pytest
from django.contrib.auth import get_user_model

from conjunto.archive.exceptions import StaleObjectError  # noqa: F401
from conjunto.archive.retention import RetentionToken, cleanup_context

from tests.test_app.archivable_models import (
    Folder,
    NoDeleteRecord,
    SoftOnlyRecord,
)


@pytest.fixture
def user(db):
    User = get_user_model()
    return User.objects.create_user(username="alice", password="pw")


# --------------------------------------------------------------------------- #
# Soft-delete basics
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_soft_delete_sets_deleted_at(user):
    folder = Folder.objects.create(name="Inbox")
    assert folder.deleted_at is None

    folder.delete(user=user)

    folder.refresh_from_db()
    assert folder.deleted_at is not None


@pytest.mark.django_db
def test_soft_delete_sets_deleted_by(user):
    folder = Folder.objects.create(name="Inbox")

    folder.delete(user=user)

    folder.refresh_from_db()
    assert folder.deleted_by_id == user.pk


@pytest.mark.django_db
def test_soft_delete_without_user_leaves_deleted_by_null():
    folder = Folder.objects.create(name="Inbox")

    folder.delete()

    folder.refresh_from_db()
    assert folder.deleted_at is not None
    assert folder.deleted_by_id is None


@pytest.mark.django_db
def test_default_manager_hides_soft_deleted(user):
    alive = Folder.objects.create(name="alive")
    dead = Folder.objects.create(name="dead")
    dead.delete(user=user)

    names = set(Folder.objects.values_list("name", flat=True))
    assert names == {"alive"}
    assert alive.pk in Folder.objects.values_list("pk", flat=True)


@pytest.mark.django_db
def test_all_objects_shows_soft_deleted(user):
    Folder.objects.create(name="alive")
    dead = Folder.objects.create(name="dead")
    dead.delete(user=user)

    names = set(Folder.all_objects.values_list("name", flat=True))
    assert names == {"alive", "dead"}


@pytest.mark.django_db
def test_deleted_objects_shows_only_soft_deleted(user):
    Folder.objects.create(name="alive")
    dead = Folder.objects.create(name="dead")
    dead.delete(user=user)

    names = set(Folder.deleted_objects.values_list("name", flat=True))
    assert names == {"dead"}


@pytest.mark.django_db
def test_restore_clears_deleted_at(user):
    folder = Folder.objects.create(name="Inbox")
    folder.delete(user=user)
    folder.refresh_from_db()
    assert folder.deleted_at is not None

    folder.restore(user=user)

    folder.refresh_from_db()
    assert folder.deleted_at is None
    assert folder.deleted_by is None
    assert folder.deleted_by_cascade is False


# --------------------------------------------------------------------------- #
# Hard-delete gate (Zero Trust)
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_hard_delete_without_token_raises():
    folder = Folder.objects.create(name="Inbox")

    with pytest.raises(PermissionError):
        folder.hard_delete(retention_token=None)


@pytest.mark.django_db
def test_hard_delete_with_invalid_token_raises():
    folder = Folder.objects.create(name="Inbox")

    class FakeToken:
        def valid(self):
            return False

    with pytest.raises(PermissionError):
        folder.hard_delete(retention_token=FakeToken())


@pytest.mark.django_db
def test_hard_delete_with_valid_token_removes_row():
    folder = Folder.objects.create(name="Inbox")
    pk = folder.pk

    with cleanup_context():
        token = RetentionToken.issue(purpose="test-cleanup")
    folder.hard_delete(retention_token=token)

    assert Folder.all_objects.filter(pk=pk).count() == 0


@pytest.mark.django_db
def test_no_delete_policy_blocks_delete():
    record = NoDeleteRecord.objects.create(name="singleton")

    with pytest.raises(PermissionError):
        record.delete()


@pytest.mark.django_db
def test_soft_delete_is_idempotent(user):
    """Deleting twice must not overwrite the original deleted_at."""
    record = SoftOnlyRecord.objects.create(label="x")
    record.delete(user=user)
    record.refresh_from_db()
    first_stamp = record.deleted_at

    record.delete(user=user)

    record.refresh_from_db()
    assert record.deleted_at == first_stamp
