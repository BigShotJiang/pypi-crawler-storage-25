"""Phase-2 tests — ``RevisionContextMiddleware`` + ``revision_context``.

Covers:
- The middleware sets the contextvar from the incoming request.
- Snapshot written inside the middleware picks up the request user.
- Without middleware, the snapshot pipeline records ``user=None``.
- The ``revision_context(...)`` context manager works for non-web
  callers (management commands, tasks, tests).
- HTMX requests also resolve user/tenant correctly — the middleware
  is called on every fragment swap, so there is no special path.
"""

from __future__ import annotations

from types import SimpleNamespace

import pytest
from django.contrib.auth import get_user_model

from conjunto.archive.middleware import (
    RevisionContext,
    RevisionContextMiddleware,
    get_current_context,
    revision_context,
)
from conjunto.archive.models import ArchiveVersion

from tests.test_app.archivable_models import Folder


@pytest.fixture
def user(db):
    User = get_user_model()
    return User.objects.create_user(username="dana", password="pw")


def _make_request(user, tenant=None, htmx: bool = False):
    request = SimpleNamespace(
        user=user,
        tenant=tenant,
        META={"HTTP_HX_REQUEST": "true"} if htmx else {},
    )
    return request


# --------------------------------------------------------------------------- #
# Middleware
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_middleware_binds_user_into_snapshot(user):
    captured = {}

    def view(request):
        # Snapshot created inside the view — must see the user.
        folder = Folder.objects.create(name="seen-by-view")
        captured["folder_pk"] = folder.pk
        return "ok"

    mw = RevisionContextMiddleware(view)
    mw(_make_request(user))

    version = ArchiveVersion.objects.get(object_id=str(captured["folder_pk"]))
    assert version.revision_meta.user_id == user.pk


@pytest.mark.django_db
def test_middleware_binds_tenant_into_snapshot(user):
    # A minimal tenant stand-in; we only need it to roundtrip through SET_NULL.
    from conjunto.tenants.models import Tenant

    tenant = Tenant.objects.create(name="Acme", slug="acme")
    captured = {}

    def view(request):
        folder = Folder.objects.create(name="in-tenant")
        captured["pk"] = folder.pk
        return "ok"

    mw = RevisionContextMiddleware(view)
    mw(_make_request(user, tenant=tenant))

    version = ArchiveVersion.objects.get(object_id=str(captured["pk"]))
    assert version.revision_meta.tenant_id == tenant.pk


@pytest.mark.django_db
def test_middleware_resets_contextvar_after_response(user):
    def view(request):
        ctx = get_current_context()
        assert ctx.user is user
        return "ok"

    mw = RevisionContextMiddleware(view)
    mw(_make_request(user))

    # After the request cycle, the contextvar must fall back to empty.
    ctx = get_current_context()
    assert ctx == RevisionContext()


@pytest.mark.django_db
def test_snapshot_without_middleware_has_null_user():
    """Without a request, user stays ``None`` — the system path."""
    folder = Folder.objects.create(name="no-context")

    version = ArchiveVersion.objects.get(object_id=str(folder.pk))
    assert version.revision_meta.user_id is None
    assert version.revision_meta.tenant_id is None


@pytest.mark.django_db
def test_anonymous_user_falls_back_to_null(user):
    """An unauthenticated ``request.user`` is stored as ``user=None``."""
    anon = SimpleNamespace(is_authenticated=False)

    def view(request):
        Folder.objects.create(name="anon-created")
        return "ok"

    mw = RevisionContextMiddleware(view)
    mw(SimpleNamespace(user=anon, tenant=None, META={}))

    folder = Folder.all_objects.get(name="anon-created")
    version = ArchiveVersion.objects.get(object_id=str(folder.pk))
    assert version.revision_meta.user_id is None


# --------------------------------------------------------------------------- #
# HTMX
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_middleware_works_on_htmx_request(user):
    """HTMX partial swaps call the middleware just like any other request."""
    captured = {}

    def view(request):
        assert request.META["HTTP_HX_REQUEST"] == "true"
        folder = Folder.objects.create(name="htmx")
        captured["pk"] = folder.pk
        return "ok"

    mw = RevisionContextMiddleware(view)
    mw(_make_request(user, htmx=True))

    version = ArchiveVersion.objects.get(object_id=str(captured["pk"]))
    assert version.revision_meta.user_id == user.pk


# --------------------------------------------------------------------------- #
# revision_context() for non-web callers
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_context_manager_sets_user_and_reason(user):
    with revision_context(user=user, reason_code="bulk_import", comment="seed"):
        folder = Folder.objects.create(name="bulk")

    version = ArchiveVersion.objects.get(object_id=str(folder.pk))
    assert version.revision_meta.user_id == user.pk
    assert version.revision_meta.reason_code == "create"
    # The context-manager reason is the fallback only — explicit
    # reason_code from save/delete/restore always wins.
    assert version.revision_meta.comment == "seed"


@pytest.mark.django_db
def test_context_manager_fallback_reason_when_none_set(user):
    """When no explicit reason is supplied, context-manager reason is used."""
    from conjunto.archive.snapshot import create_snapshot

    folder = Folder.objects.create(name="x")
    # There is already a "create" snapshot from the save above; we add
    # a second snapshot inside a context that supplies a fallback reason
    # code and verify the newest row uses that code.
    with revision_context(user=user, reason_code="manual_dump"):
        create_snapshot(folder)  # no explicit reason_code

    latest = (
        ArchiveVersion.objects.filter(object_id=str(folder.pk))
        .order_by("-created_at")
        .first()
    )
    assert latest.revision_meta.reason_code == "manual_dump"
    assert latest.revision_meta.user_id == user.pk
