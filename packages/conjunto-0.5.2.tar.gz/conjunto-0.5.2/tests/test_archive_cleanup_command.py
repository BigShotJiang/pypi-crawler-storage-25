"""Phase-4 tests for ``manage.py archive_cleanup``.

Covers:

- Dry-run does not delete.
- Real run purges rows whose retention window has elapsed.
- Model filter restricts the scan.
- Tenant filter restricts the scan.
- Limit caps the purge count.
- Run is idempotent (a second run does not re-purge anything).
- DeletionLog rows are written with the right metadata.
- Hard-delete cascade removes ArchiveVersion + ArchiveRevisionMeta too.
"""

from __future__ import annotations

from datetime import timedelta
from io import StringIO

import pytest
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.utils import timezone

from conjunto.archive.models import (
    ArchiveRevisionMeta,
    ArchiveVersion,
    DeletionLog,
    DeletionReason,
)
from conjunto.archive.retention.policy import _reset_policy_cache

from tests.test_app.archivable_models import Folder, SoftOnlyRecord


@pytest.fixture
def user(db):
    User = get_user_model()
    return User.objects.create_user(username="alice", password="pw")


@pytest.fixture(autouse=True)
def _reset_cache():
    _reset_policy_cache()
    yield
    _reset_policy_cache()


def _soft_delete_in_past(
    instance,
    *,
    years_ago: int,
    user,
) -> None:
    """Soft-delete ``instance`` and backdate ``deleted_at`` by N years."""
    instance.delete(user=user)
    instance.refresh_from_db()
    instance.deleted_at = timezone.now() - timedelta(days=365 * years_ago)
    type(instance).all_objects.filter(pk=instance.pk).update(
        deleted_at=instance.deleted_at
    )


def _monkeypatch_policy(monkeypatch, model, *, years: int, floor: int = 0):
    """Register a short-window policy for the cleanup scan."""
    from conjunto.archive.retention import policy
    from conjunto.archive.retention.policy import RetentionPolicy

    fake = RetentionPolicy(years=years, floor_years=floor)
    cache = policy._POLICY_CACHE
    cache[model] = fake


# --------------------------------------------------------------------------- #
# Dry-run
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_dry_run_does_not_delete(user, monkeypatch):
    folder = Folder.objects.create(name="old")
    _soft_delete_in_past(folder, years_ago=40, user=user)
    _monkeypatch_policy(monkeypatch, Folder, years=30, floor=30)

    out = StringIO()
    call_command("archive_cleanup", "--dry-run", stdout=out)

    # Row survives
    assert Folder.all_objects.filter(pk=folder.pk).exists()
    assert DeletionLog.objects.count() == 0
    assert "would purge" in out.getvalue()


# --------------------------------------------------------------------------- #
# Real run — happy path
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_real_run_purges_expired_row(user, monkeypatch):
    folder = Folder.objects.create(name="ancient")
    _soft_delete_in_past(folder, years_ago=40, user=user)
    _monkeypatch_policy(monkeypatch, Folder, years=30, floor=30)

    out = StringIO()
    call_command("archive_cleanup", stdout=out)

    assert not Folder.all_objects.filter(pk=folder.pk).exists()
    log = DeletionLog.objects.get()
    assert log.app_label == "test_app"
    assert log.model_name == "Folder"
    assert log.object_pk == str(folder.pk)
    assert log.reason == DeletionReason.RETENTION_EXPIRED
    assert log.triggered_by.startswith("archive_cleanup:")
    assert log.deleted_at_final is not None


@pytest.mark.django_db
def test_real_run_leaves_fresh_soft_delete_alone(user, monkeypatch):
    folder = Folder.objects.create(name="new")
    folder.delete(user=user)
    _monkeypatch_policy(monkeypatch, Folder, years=30, floor=30)

    call_command("archive_cleanup", stdout=StringIO())

    assert Folder.all_objects.filter(pk=folder.pk).exists()
    assert DeletionLog.objects.count() == 0


@pytest.mark.django_db
def test_real_run_leaves_live_rows_alone(user, monkeypatch):
    folder = Folder.objects.create(name="alive")
    _monkeypatch_policy(monkeypatch, Folder, years=30, floor=30)

    call_command("archive_cleanup", stdout=StringIO())

    assert Folder.all_objects.filter(pk=folder.pk).exists()
    assert folder.deleted_at is None


# --------------------------------------------------------------------------- #
# Hard-delete cascade — versions + metas vanish
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_purge_removes_archive_versions_and_metas(user, monkeypatch):
    folder = Folder.objects.create(name="purgeme")
    folder.name = "purgeme-edited"
    folder.save()  # creates a second ArchiveVersion
    _soft_delete_in_past(folder, years_ago=40, user=user)
    _monkeypatch_policy(monkeypatch, Folder, years=30, floor=30)

    from django.contrib.contenttypes.models import ContentType

    ct = ContentType.objects.get_for_model(Folder)
    # There are several versions for the row (create, update, soft-delete).
    versions_before = ArchiveVersion.objects.filter(
        content_type=ct, object_id=str(folder.pk)
    ).count()
    assert versions_before >= 2
    meta_ids_before = set(
        ArchiveVersion.objects.filter(
            content_type=ct, object_id=str(folder.pk)
        ).values_list("revision_meta_id", flat=True)
    )
    assert len(meta_ids_before) >= 2

    call_command("archive_cleanup", stdout=StringIO())

    # All version rows and the meta rows they referenced are gone.
    assert not ArchiveVersion.objects.filter(
        content_type=ct, object_id=str(folder.pk)
    ).exists()
    assert not ArchiveRevisionMeta.objects.filter(pk__in=meta_ids_before).exists()


# --------------------------------------------------------------------------- #
# Model + limit filters
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_model_filter_restricts_scan(user, monkeypatch):
    folder = Folder.objects.create(name="f")
    record = SoftOnlyRecord.objects.create(label="r")
    _soft_delete_in_past(folder, years_ago=40, user=user)
    _soft_delete_in_past(record, years_ago=40, user=user)

    _monkeypatch_policy(monkeypatch, Folder, years=30, floor=30)
    _monkeypatch_policy(monkeypatch, SoftOnlyRecord, years=30, floor=30)

    call_command("archive_cleanup", "--model", "test_app.Folder", stdout=StringIO())

    # Folder purged; SoftOnlyRecord survives.
    assert not Folder.all_objects.filter(pk=folder.pk).exists()
    assert SoftOnlyRecord.all_objects.filter(pk=record.pk).exists()


@pytest.mark.django_db
def test_limit_caps_purge_count(user, monkeypatch):
    f1 = Folder.objects.create(name="1")
    f2 = Folder.objects.create(name="2")
    f3 = Folder.objects.create(name="3")
    for f in (f1, f2, f3):
        _soft_delete_in_past(f, years_ago=40, user=user)
    _monkeypatch_policy(monkeypatch, Folder, years=30, floor=30)

    call_command("archive_cleanup", "--limit", "2", stdout=StringIO())

    purged = DeletionLog.objects.count()
    assert purged == 2
    remaining = Folder.all_objects.count()
    assert remaining == 1


# --------------------------------------------------------------------------- #
# Idempotency
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_second_run_is_noop(user, monkeypatch):
    folder = Folder.objects.create(name="once")
    _soft_delete_in_past(folder, years_ago=40, user=user)
    _monkeypatch_policy(monkeypatch, Folder, years=30, floor=30)

    call_command("archive_cleanup", stdout=StringIO())
    logs_after_first = DeletionLog.objects.count()

    # Second run finds nothing — the row is already gone.
    call_command("archive_cleanup", stdout=StringIO())
    logs_after_second = DeletionLog.objects.count()

    assert logs_after_first == 1
    assert logs_after_second == 1  # unchanged
