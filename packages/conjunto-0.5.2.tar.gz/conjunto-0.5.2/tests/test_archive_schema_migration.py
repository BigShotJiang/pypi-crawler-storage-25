"""Phase-2 tests — ``ArchiveMigration`` + startup validator.

Covers the migration dataclass validity checks, the chain application
helper, and the startup validator wired into ``AppConfig.ready``.
"""

from __future__ import annotations

import pytest
from django.core.exceptions import ImproperlyConfigured

from conjunto.archive.exceptions import ArchiveMigrationError
from conjunto.archive.schema import (
    ArchiveMigration,
    apply_migrations,
    validate_migration_chain,
)


# --------------------------------------------------------------------------- #
# Dataclass invariants
# --------------------------------------------------------------------------- #
def test_archive_migration_rejects_non_advancing_versions():
    with pytest.raises(ValueError):
        ArchiveMigration(from_version=2, to_version=2, migrate_fn=lambda d: d)


def test_archive_migration_rejects_backwards_version():
    with pytest.raises(ValueError):
        ArchiveMigration(from_version=3, to_version=2, migrate_fn=lambda d: d)


# --------------------------------------------------------------------------- #
# apply_migrations
# --------------------------------------------------------------------------- #
def test_apply_migrations_noop_for_same_version():
    assert apply_migrations(
        {"x": 1},
        from_version=1,
        to_version=1,
        migrations=[],
    ) == {"x": 1}


def test_apply_migrations_single_step():
    step = ArchiveMigration(
        from_version=1,
        to_version=2,
        migrate_fn=lambda d: {**d, "new_field": "added"},
    )
    result = apply_migrations(
        {"x": 1},
        from_version=1,
        to_version=2,
        migrations=[step],
    )
    assert result == {"x": 1, "new_field": "added"}


def test_apply_migrations_chain_runs_in_order():
    s1 = ArchiveMigration(1, 2, lambda d: {**d, "step_1": True})
    s2 = ArchiveMigration(2, 3, lambda d: {**d, "step_2": True})
    result = apply_migrations(
        {"x": 1},
        from_version=1,
        to_version=3,
        migrations=[s1, s2],
    )
    assert result == {"x": 1, "step_1": True, "step_2": True}


def test_apply_migrations_rejects_backwards_call():
    with pytest.raises(ArchiveMigrationError):
        apply_migrations({}, from_version=3, to_version=1, migrations=[])


def test_apply_migrations_raises_on_missing_step():
    step = ArchiveMigration(1, 2, lambda d: d)
    with pytest.raises(ArchiveMigrationError):
        apply_migrations(
            {},
            from_version=1,
            to_version=3,
            migrations=[step],  # 2 -> 3 is missing
        )


# --------------------------------------------------------------------------- #
# validate_migration_chain
# --------------------------------------------------------------------------- #
def test_validator_accepts_empty_chain_for_version_one():
    # No migrations are required when the model never bumped past v1.
    validate_migration_chain([], current_version=1, model_label="x")


def test_validator_rejects_gap():
    step = ArchiveMigration(1, 2, lambda d: d)
    with pytest.raises(ImproperlyConfigured):
        validate_migration_chain([step], current_version=3, model_label="x")


def test_validator_rejects_duplicate_step():
    s1 = ArchiveMigration(1, 2, lambda d: d)
    s2 = ArchiveMigration(1, 2, lambda d: d)
    with pytest.raises(ImproperlyConfigured):
        validate_migration_chain([s1, s2], current_version=2, model_label="x")


def test_validator_rejects_multi_step_jump():
    multi = ArchiveMigration(1, 3, lambda d: d)
    with pytest.raises(ImproperlyConfigured):
        validate_migration_chain([multi], current_version=3, model_label="x")


def test_validator_accepts_complete_chain():
    s1 = ArchiveMigration(1, 2, lambda d: d)
    s2 = ArchiveMigration(2, 3, lambda d: d)
    validate_migration_chain([s1, s2], current_version=3, model_label="x")


# --------------------------------------------------------------------------- #
# Startup validator (AppConfig.ready)
# --------------------------------------------------------------------------- #
def test_startup_validator_rejects_gap_in_archivable_model(monkeypatch):
    """Simulates a misconfigured plugin model loaded into the app registry."""
    from django.apps import apps

    from conjunto.archive.apps import ConjuntoArchiveConfig
    from conjunto.archive.mixins import ArchivableMixin
    from tests.test_app.archivable_models import SoftOnlyRecord

    # Point the model to version 3 but leave the chain empty. The
    # validator must see the gap at startup.
    monkeypatch.setattr(SoftOnlyRecord, "archive_schema_version", 3, raising=False)
    monkeypatch.setattr(SoftOnlyRecord.Archive, "archive_migrations", [], raising=False)
    assert issubclass(SoftOnlyRecord, ArchivableMixin)

    config = apps.get_app_config("conjunto_archive")
    assert isinstance(config, ConjuntoArchiveConfig)

    with pytest.raises(ImproperlyConfigured):
        config._validate_archive_migration_chains()


def test_startup_validator_accepts_clean_chain(monkeypatch):
    from django.apps import apps

    from tests.test_app.archivable_models import SoftOnlyRecord

    s1 = ArchiveMigration(1, 2, lambda d: d)
    monkeypatch.setattr(SoftOnlyRecord, "archive_schema_version", 2, raising=False)
    monkeypatch.setattr(
        SoftOnlyRecord.Archive, "archive_migrations", [s1], raising=False
    )

    config = apps.get_app_config("conjunto_archive")
    # No exception.
    config._validate_archive_migration_chains()
