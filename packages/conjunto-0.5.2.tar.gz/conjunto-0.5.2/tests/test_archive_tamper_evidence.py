"""Phase-1 tests for tamper-evidence guards.

Covers the two guard layers:

1. ``AppendOnlyManager`` on log tables — ``update()`` / ``bulk_update()``
   / ``delete()`` all raise ``TamperEvidenceViolation``.
2. ``ArchivableQuerySet`` on domain models — ``update()`` /
   ``bulk_update()`` / ``delete()`` respect soft-delete visibility and
   refuse to bypass the managed lifecycle.
"""

from __future__ import annotations

import pytest

from conjunto.archive.exceptions import TamperEvidenceViolation
from conjunto.archive.models import ArchiveAccessLog, DeletionLog

from tests.test_app.archivable_models import Folder


# --------------------------------------------------------------------------- #
# AppendOnlyManager on log tables
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_access_log_update_forbidden():
    entry = ArchiveAccessLog.objects.create(purpose="audit")

    with pytest.raises(TamperEvidenceViolation):
        ArchiveAccessLog.objects.filter(pk=entry.pk).update(purpose="hacked")


@pytest.mark.django_db
def test_access_log_delete_forbidden():
    ArchiveAccessLog.objects.create(purpose="audit")

    with pytest.raises(TamperEvidenceViolation):
        ArchiveAccessLog.objects.all().delete()


@pytest.mark.django_db
def test_access_log_bulk_update_forbidden():
    entries = [
        ArchiveAccessLog(purpose="a"),
        ArchiveAccessLog(purpose="b"),
    ]
    ArchiveAccessLog.objects.bulk_create(entries)

    with pytest.raises(TamperEvidenceViolation):
        ArchiveAccessLog.objects.bulk_update(entries, ["purpose"])


@pytest.mark.django_db
def test_access_log_instance_save_after_pk_forbidden():
    entry = ArchiveAccessLog.objects.create(purpose="audit")

    entry.purpose = "hacked"
    with pytest.raises(TamperEvidenceViolation):
        entry.save()


@pytest.mark.django_db
def test_access_log_instance_delete_forbidden():
    entry = ArchiveAccessLog.objects.create(purpose="audit")

    with pytest.raises(TamperEvidenceViolation):
        entry.delete()


@pytest.mark.django_db
def test_deletion_log_update_forbidden():
    from django.utils import timezone

    entry = DeletionLog.objects.create(
        app_label="test_app",
        model_name="folder",
        object_pk="1",
        reason="retention_expired",
        triggered_by="archive_cleanup:test",
        deleted_at_final=timezone.now(),
    )

    with pytest.raises(TamperEvidenceViolation):
        DeletionLog.objects.filter(pk=entry.pk).update(reason="hacked")


@pytest.mark.django_db
def test_deletion_log_delete_forbidden():
    from django.utils import timezone

    DeletionLog.objects.create(
        app_label="test_app",
        model_name="folder",
        object_pk="1",
        reason="retention_expired",
        triggered_by="archive_cleanup:test",
        deleted_at_final=timezone.now(),
    )

    with pytest.raises(TamperEvidenceViolation):
        DeletionLog.objects.all().delete()


# --------------------------------------------------------------------------- #
# ArchivableQuerySet tamper-evidence on domain models
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_queryset_update_respects_soft_delete_visibility():
    """`.update()` via default manager must not touch soft-deleted rows."""
    alive = Folder.objects.create(name="alive")
    dead = Folder.objects.create(name="dead")
    dead.delete()

    affected = Folder.objects.update(name="renamed")

    alive.refresh_from_db()
    dead.refresh_from_db()
    assert alive.name == "renamed"
    assert dead.name == "dead"
    assert affected == 1


@pytest.mark.django_db
def test_queryset_update_via_all_objects_spans_deleted():
    """``all_objects.update()`` explicitly opts into deleted rows."""
    alive = Folder.objects.create(name="alive")
    dead = Folder.objects.create(name="dead")
    dead.delete()

    affected = Folder.all_objects.update(name="x")

    alive.refresh_from_db()
    dead.refresh_from_db()
    assert alive.name == "x"
    assert dead.name == "x"
    assert affected == 2


@pytest.mark.django_db
def test_queryset_delete_is_soft_per_row():
    """Calling ``.delete()`` on a QS soft-deletes each row."""
    a = Folder.objects.create(name="a")
    b = Folder.objects.create(name="b")

    Folder.objects.filter(pk__in=[a.pk, b.pk]).delete()

    for row in Folder.all_objects.filter(pk__in=[a.pk, b.pk]):
        assert row.deleted_at is not None


@pytest.mark.django_db
def test_queryset_hard_delete_without_token_raises():
    a = Folder.objects.create(name="a")

    with pytest.raises(PermissionError):
        Folder.all_objects.filter(pk=a.pk).hard_delete(retention_token=None)


# --------------------------------------------------------------------------- #
# Zero-Trust: the tamper-evidence guard must survive bypass attempts via
# ``_base_manager``, ``_default_manager``, and ``Manager.using()`` — these
# are the usual back-doors an attacker or a careless plugin author might
# reach for.
# --------------------------------------------------------------------------- #
@pytest.mark.django_db
def test_append_only_base_manager_also_blocks_update():
    entry = ArchiveAccessLog.objects.create(purpose="audit")

    with pytest.raises(TamperEvidenceViolation):
        ArchiveAccessLog._base_manager.filter(pk=entry.pk).update(purpose="hack")


@pytest.mark.django_db
def test_append_only_default_manager_also_blocks_delete():
    ArchiveAccessLog.objects.create(purpose="audit")

    with pytest.raises(TamperEvidenceViolation):
        ArchiveAccessLog._default_manager.all().delete()


@pytest.mark.django_db
def test_append_only_using_default_db_also_blocks():
    """``Manager.using('default')`` must not open a bypass route."""
    entry = ArchiveAccessLog.objects.create(purpose="audit")

    with pytest.raises(TamperEvidenceViolation):
        ArchiveAccessLog.objects.using("default").filter(pk=entry.pk).update(
            purpose="hack"
        )
