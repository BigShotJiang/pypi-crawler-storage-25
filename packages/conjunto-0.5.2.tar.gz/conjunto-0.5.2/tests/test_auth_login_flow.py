"""Tests for ``conjunto.auth`` — the optional two-step login flow.

A user with two or more accessible tenants does not get logged in by
the credentials POST. Instead the credentials are validated, the user
identity is stashed into the session under
``cj_pending_login``, and an HTMX swap returns the tenant-pick partial.
:class:`~conjunto.auth.views.ConjuntoLoginCompleteView` then completes
authentication once a tenant is chosen.

Users with zero or one accessible tenants take the classic path: the
credentials POST logs them in and (for one-tenant users) stamps the
tenant id into the session.
"""

from __future__ import annotations

import pytest
from django.contrib.auth import get_user_model

from conjunto.auth.views import PENDING_LOGIN_KEY
from conjunto.tenants.models import Tenant, TenantMembership
from conjunto.tenants.views import SESSION_KEY as TENANT_SESSION_KEY


pytestmark = pytest.mark.django_db
User = get_user_model()


# ---------------------------------------------------------------------------
# 1-tenant path: classic login, tenant auto-bound
# ---------------------------------------------------------------------------


def test_login_with_single_tenant_logs_in_and_binds_tenant(client, no_auto_membership):
    only = Tenant.objects.create(name="Acme", slug="acme")
    user = User.objects.create_user(username="alice", password="hunter2")
    TenantMembership.objects.create(user=user, tenant=only, role="admin")

    response = client.post(
        "/accounts/login/",
        {"username": "alice", "password": "hunter2"},
    )
    assert response.status_code == 302
    # User is logged in.
    assert client.session.get("_auth_user_id") == str(user.pk)
    # Tenant auto-bound.
    assert client.session[TENANT_SESSION_KEY] == only.pk
    # No pending state lingering.
    assert PENDING_LOGIN_KEY not in client.session


def test_login_with_zero_tenants_logs_in_without_binding(client, no_auto_membership):
    user = User.objects.create_user(username="alice", password="hunter2")

    response = client.post(
        "/accounts/login/",
        {"username": "alice", "password": "hunter2"},
    )
    assert response.status_code == 302
    assert client.session.get("_auth_user_id") == str(user.pk)
    assert TENANT_SESSION_KEY not in client.session
    assert PENDING_LOGIN_KEY not in client.session


# ---------------------------------------------------------------------------
# 2-tenant path: deferred login, tenant pick required
# ---------------------------------------------------------------------------


def test_login_with_two_tenants_defers_login_and_returns_picker_partial(client):
    acme = Tenant.objects.create(name="Acme", slug="acme")
    globex = Tenant.objects.create(name="Globex", slug="globex")
    user = User.objects.create_user(username="alice", password="hunter2")
    TenantMembership.objects.create(user=user, tenant=acme, role="admin")
    TenantMembership.objects.create(user=user, tenant=globex, role="admin")

    response = client.post(
        "/accounts/login/",
        {"username": "alice", "password": "hunter2"},
        HTTP_HX_REQUEST="true",
    )
    assert response.status_code == 200
    # Login was deferred — user is NOT authenticated yet.
    assert "_auth_user_id" not in client.session
    # Pending state was stashed.
    pending = client.session[PENDING_LOGIN_KEY]
    assert pending["user_id"] == user.pk
    # Picker partial was rendered (contains both tenants).
    body = response.content.decode()
    assert 'id="cj-login-card"' in body
    assert "Acme" in body
    assert "Globex" in body


def test_login_complete_finishes_login_and_binds_chosen_tenant(client):
    acme = Tenant.objects.create(name="Acme", slug="acme")
    globex = Tenant.objects.create(name="Globex", slug="globex")
    user = User.objects.create_user(username="alice", password="hunter2")
    TenantMembership.objects.create(user=user, tenant=acme, role="admin")
    TenantMembership.objects.create(user=user, tenant=globex, role="admin")

    # Step 1: credentials.
    client.post(
        "/accounts/login/",
        {"username": "alice", "password": "hunter2"},
        HTTP_HX_REQUEST="true",
    )
    assert PENDING_LOGIN_KEY in client.session

    # Step 2: tenant pick.
    response = client.post(
        "/accounts/login-complete/",
        {"tenant": str(globex.pk)},
        HTTP_HX_REQUEST="true",
    )
    assert response.status_code == 204
    assert response["HX-Redirect"]
    # Now the user is authenticated.
    assert client.session.get("_auth_user_id") == str(user.pk)
    # Chosen tenant bound.
    assert client.session[TENANT_SESSION_KEY] == globex.pk
    # Pending state cleared.
    assert PENDING_LOGIN_KEY not in client.session


def test_login_complete_rejects_disallowed_tenant(client):
    acme = Tenant.objects.create(name="Acme", slug="acme")
    globex = Tenant.objects.create(name="Globex", slug="globex")
    forbidden = Tenant.objects.create(name="Forbidden", slug="forbidden")
    user = User.objects.create_user(username="alice", password="hunter2")
    TenantMembership.objects.create(user=user, tenant=acme, role="admin")
    TenantMembership.objects.create(user=user, tenant=globex, role="admin")

    client.post(
        "/accounts/login/",
        {"username": "alice", "password": "hunter2"},
        HTTP_HX_REQUEST="true",
    )
    response = client.post(
        "/accounts/login-complete/",
        {"tenant": str(forbidden.pk)},
        HTTP_HX_REQUEST="true",
    )
    # Bounce back to login.
    assert response.status_code == 204
    assert response["HX-Redirect"] == "/accounts/login/"
    # Not authenticated, no tenant bound.
    assert "_auth_user_id" not in client.session
    assert TENANT_SESSION_KEY not in client.session


def test_login_complete_without_pending_state_bounces_to_login(client):
    Tenant.objects.create(name="Acme", slug="acme")
    response = client.post(
        "/accounts/login-complete/",
        {"tenant": "1"},
        HTTP_HX_REQUEST="true",
    )
    assert response.status_code == 204
    assert response["HX-Redirect"] == "/accounts/login/"
    assert "_auth_user_id" not in client.session


def test_login_invalid_credentials_returns_credentials_partial_for_htmx(client):
    User.objects.create_user(username="alice", password="hunter2")

    response = client.post(
        "/accounts/login/",
        {"username": "alice", "password": "wrong"},
        HTTP_HX_REQUEST="true",
    )
    # Form re-renders with errors.
    assert response.status_code == 422
    body = response.content.decode()
    assert 'id="cj-login-card"' in body
    # No pending state, no auth.
    assert PENDING_LOGIN_KEY not in client.session
    assert "_auth_user_id" not in client.session


def test_login_invalid_credentials_renders_each_error_once(client):
    """Regression: the credentials partial used to render the
    non-field-errors block manually *and* delegate to crispy, which
    rendered the same alert a second time. Each error must appear
    exactly once in the swapped-in card.
    """
    User.objects.create_user(username="alice", password="hunter2")

    response = client.post(
        "/accounts/login/",
        {"username": "alice", "password": "wrong"},
        HTTP_HX_REQUEST="true",
    )
    assert response.status_code == 422
    body = response.content.decode()

    # The non-field error from ``AuthenticationForm.invalid_login``.
    # We pick the form's actual rendered text — whatever active locale
    # is in effect — by asking the form for it directly. Counting that
    # exact string in the body proves the deduplication contract
    # without coupling to an untranslated literal.
    from django.contrib.auth.forms import AuthenticationForm

    form = AuthenticationForm()
    expected_msg = form.error_messages["invalid_login"] % {
        "username": form.username_field.verbose_name
    }
    error_count = body.count(expected_msg)
    assert error_count == 1, (
        f"non-field error rendered {error_count} times; expected exactly 1. "
        "The credentials partial is duplicating the alert (manual block + "
        "crispy default)."
    )


# ---------------------------------------------------------------------------
# Superuser path: every active tenant counts as accessible
# ---------------------------------------------------------------------------


def test_superuser_login_with_two_tenants_defers(client):
    Tenant.objects.create(name="Acme", slug="acme")
    Tenant.objects.create(name="Globex", slug="globex")
    User.objects.create_superuser(username="root", password="rootpw")

    response = client.post(
        "/accounts/login/",
        {"username": "root", "password": "rootpw"},
        HTTP_HX_REQUEST="true",
    )
    assert response.status_code == 200
    assert "_auth_user_id" not in client.session
    assert PENDING_LOGIN_KEY in client.session


def test_superuser_login_with_single_tenant_logs_in_directly(client, clean_tenants):
    only = Tenant.objects.create(name="Acme", slug="acme")
    User.objects.create_superuser(username="root", password="rootpw")

    response = client.post(
        "/accounts/login/",
        {"username": "root", "password": "rootpw"},
    )
    assert response.status_code == 302
    assert "_auth_user_id" in client.session
    assert client.session[TENANT_SESSION_KEY] == only.pk
