"""Async feed resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any

from sdk._paging import Page
from sdk._preview import preview_resource
from sdk._request_options import RequestOptions
from sdk._validation import require_str
from sdk.async_resources._mixin_base import AsyncRequesterMixin
from sdk.resources.feeds import _extract_subscriptions


@preview_resource
class AsyncFeedsMixin(AsyncRequesterMixin):
    async def create_feed(
        self,
        *,
        project_id: str,
        name: str,
        source_agent_id: str,
        persistent: bool = False,
        target_corpus: dict[str, Any] | None = None,
        reactive: bool = False,
        execution_mode: str = "retrieve",
        schedule_interval: str | None = None,
        schedule_hour: int | None = None,
        start_from: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Create a new knowledge feed.

        Args:
            project_id: ID of the project that will own the feed.
            name: Human-readable name for the feed.
            source_agent_id: ID of the source agent for the feed.
            persistent: Whether the feed persists results to storage.
            target_corpus: Optional target corpus configuration dict. Pass
                ``{"existing": "<corpus-id>"}`` to write into an existing corpus,
                or ``{"create_new": True}`` to have the API create a new one.
            reactive: Whether the feed triggers on new data automatically.
            execution_mode: Execution mode for the feed (defaults to
                ``"retrieve"``).
            schedule_interval: Optional cron-style schedule interval.
            schedule_hour: UTC hour (0-23) for daily scheduled feeds. Only
                valid when schedule_interval is ``'1d'``.
            start_from: Optional ISO-8601 timestamp to start processing from.

        Returns:
            The newly created feed record.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        project_id = require_str(project_id, "project_id")
        source_agent_id = require_str(source_agent_id, "source_agent_id")
        payload: dict[str, Any] = {
            "project_id": project_id,
            "name": name,
            "source_agent_id": source_agent_id,
            "persistent": persistent,
            "reactive": reactive,
            "execution_mode": execution_mode,
        }
        if target_corpus is not None:
            payload["target_corpus"] = target_corpus
        if schedule_interval is not None:
            payload["schedule_interval"] = schedule_interval
        if schedule_hour is not None:
            payload["schedule_hour"] = schedule_hour
        if start_from is not None:
            payload["start_from"] = start_from
        data = await self._request(
            "POST", "/v1/feeds", json=payload, request_options=request_options
        )
        return self._maybe_validate(data, "FeedResponse")

    async def list_feeds(
        self,
        *,
        project_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
        request_options: RequestOptions | None = None,
    ) -> Page[dict[str, Any]]:
        """List feeds accessible to the current credentials.

        Args:
            project_id: Optional project ID to filter feeds by.
            limit: Maximum number of feeds to return per page.
            offset: Number of feeds to skip for pagination.

        Returns:
            A Page containing feed records with pagination metadata.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        params: dict[str, Any] = {}
        if project_id is not None:
            params["project_id"] = project_id
        return await self._list_page(
            "GET",
            "/v1/feeds",
            items_key="feeds",
            params=params or None,
            limit=limit,
            offset=offset,
        )

    async def get_feed(
        self,
        feed_id: str,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Retrieve a single feed by ID.

        Args:
            feed_id: Unique identifier of the feed.

        Returns:
            The feed record.

        Raises:
            NotFoundError: If the feed does not exist.
            Knowledge2Error: If the API request fails.
        """
        feed_id = require_str(feed_id, "feed_id")
        data = await self._request("GET", f"/v1/feeds/{feed_id}", request_options=request_options)
        return self._maybe_validate(data, "FeedResponse")

    async def update_feed(
        self,
        feed_id: str,
        *,
        name: str | None = None,
        execution_mode: str | None = None,
        reactive: bool | None = None,
        schedule_interval: str | None = None,
        schedule_hour: int | None = None,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Update feed settings.

        Args:
            feed_id: ID of the feed to update.
            name: New name for the feed.
            execution_mode: New execution mode for the feed.
            reactive: Whether the feed triggers on new data automatically.
            schedule_interval: New cron-style schedule interval.
            schedule_hour: UTC hour (0-23) for daily scheduled feeds. Only
                valid when schedule_interval is ``'1d'``.

        Returns:
            Updated feed record.

        Raises:
            NotFoundError: If the feed does not exist.
            Knowledge2Error: If the API request fails.
        """
        feed_id = require_str(feed_id, "feed_id")
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if execution_mode is not None:
            payload["execution_mode"] = execution_mode
        if reactive is not None:
            payload["reactive"] = reactive
        if schedule_interval is not None:
            payload["schedule_interval"] = schedule_interval
        if schedule_hour is not None:
            payload["schedule_hour"] = schedule_hour
        data = await self._request(
            "PATCH", f"/v1/feeds/{feed_id}", json=payload, request_options=request_options
        )
        return self._maybe_validate(data, "FeedResponse")

    async def delete_feed(
        self,
        feed_id: str,
        request_options: RequestOptions | None = None,
    ) -> None:
        """Delete a feed.

        Args:
            feed_id: Unique identifier of the feed to delete.

        Returns:
            None (the API returns 204 No Content on success).

        Raises:
            NotFoundError: If the feed does not exist.
            Knowledge2Error: If the API request fails.
        """
        feed_id = require_str(feed_id, "feed_id")
        await self._request("DELETE", f"/v1/feeds/{feed_id}", request_options=request_options)

    async def run_feed(
        self,
        feed_id: str,
        *,
        return_results: bool | None = None,
        dry_run: bool = False,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Trigger a feed run.

        Args:
            feed_id: Unique identifier of the feed to run.
            return_results: Whether to include results in the response.
                When ``None`` (default), the API applies a smart default
                based on feed type (``True`` for standard, ``False`` for
                persistent feeds).
            dry_run: If ``True``, simulate the run without persisting results.

        Returns:
            A dict containing the feed run results and metadata.

        Raises:
            NotFoundError: If the feed does not exist.
            Knowledge2Error: If the API request fails.
        """
        feed_id = require_str(feed_id, "feed_id")
        params: dict[str, Any] = {"dry_run": dry_run}
        if return_results is not None:
            params["return_results"] = return_results
        data = await self._request(
            "POST",
            f"/v1/feeds/{feed_id}/run",
            params=params,
            request_options=request_options,
        )
        return self._maybe_validate(data, "FeedRunResponse")

    # ------------------------------------------------------------------
    # Draft lifecycle
    # ------------------------------------------------------------------
    async def create_feed_draft(
        self,
        feed_id: str,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Create an editable draft of a feed."""
        feed_id = require_str(feed_id, "feed_id")
        data = await self._request(
            "POST", f"/v1/feeds/{feed_id}/draft", request_options=request_options
        )
        return self._maybe_validate(data, "FeedResponse")

    async def get_feed_draft(
        self,
        feed_id: str,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Retrieve the draft for a feed, if one exists."""
        feed_id = require_str(feed_id, "feed_id")
        data = await self._request(
            "GET", f"/v1/feeds/{feed_id}/draft", request_options=request_options
        )
        return self._maybe_validate(data, "FeedResponse")

    async def activate_feed_draft(
        self,
        feed_id: str,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Activate a draft, returning the updated parent feed."""
        feed_id = require_str(feed_id, "feed_id")
        data = await self._request(
            "POST",
            f"/v1/feeds/{feed_id}/draft/activate",
            request_options=request_options,
        )
        return self._maybe_validate(data, "FeedResponse")

    async def discard_feed_draft(
        self,
        feed_id: str,
        request_options: RequestOptions | None = None,
    ) -> None:
        """Discard a feed's draft without applying its config.

        Returns ``None`` on the default path. Under
        ``client.with_raw_response`` the underlying :class:`RawResponse`
        is propagated so raw-mode callers can inspect the 204 / 4xx
        status and headers of the DELETE call.
        """
        feed_id = require_str(feed_id, "feed_id")
        # Return the awaited _request() result so the raw-response
        # contract is preserved under client.with_raw_response.
        return await self._request(
            "DELETE", f"/v1/feeds/{feed_id}/draft", request_options=request_options
        )

    # ------------------------------------------------------------------
    # Subscriptions (read from feed side)
    # ------------------------------------------------------------------
    async def list_feed_subscriptions(
        self,
        feed_id: str,
        request_options: RequestOptions | None = None,
    ) -> list[dict[str, Any]]:
        """List subscriptions attached to a feed.

        Subscriptions are agent-scoped server-side; this helper reads
        the subscription view embedded in the feed record.

        Note:
            Under ``client.with_raw_response`` this method returns a
            :class:`~sdk._raw_response.RawResponse` whose ``parsed``
            attribute holds the ``list[dict]``; see the sync mirror
            for the static-signature rationale.
        """
        # Keep the FeedResponse validation path so ``validate_responses=True``
        # clients get schema enforcement on the feed record. Access the
        # subscriptions field in a way that works both for plain dicts and
        # for the validated FeedResponseModel.
        feed = await self.get_feed(feed_id, request_options=request_options)
        return _extract_subscriptions(feed)

    # ------------------------------------------------------------------
    # Feedback
    # ------------------------------------------------------------------
    async def submit_feed_feedback(
        self,
        feed_id: str,
        *,
        rating: int,
        chunk_id: str,
        feed_run_id: str,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Submit thumbs up/down feedback on a feed result."""
        feed_id = require_str(feed_id, "feed_id")
        chunk_id = require_str(chunk_id, "chunk_id")
        feed_run_id = require_str(feed_run_id, "feed_run_id")
        if rating not in (0, 1):
            raise ValueError("rating must be 0 (not relevant) or 1 (relevant)")
        payload: dict[str, Any] = {
            "rating": rating,
            "chunk_id": chunk_id,
            "feed_run_id": feed_run_id,
        }
        data = await self._request(
            "POST",
            f"/v1/feeds/{feed_id}/feedback",
            json=payload,
            request_options=request_options,
        )
        return self._maybe_validate(data, "FeedFeedbackSubmitResponse")

    async def get_feed_feedback_stats(
        self,
        feed_id: str,
        *,
        feed_run_id: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Get aggregated feedback stats for a feed."""
        feed_id = require_str(feed_id, "feed_id")
        params: dict[str, Any] = {}
        if feed_run_id is not None:
            params["feed_run_id"] = feed_run_id
        data = await self._request(
            "GET",
            f"/v1/feeds/{feed_id}/feedback",
            params=params or None,
            request_options=request_options,
        )
        return self._maybe_validate(data, "FeedFeedbackStatsResponse")
