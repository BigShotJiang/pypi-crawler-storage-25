"""Index management resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import cast

from sdk._request_options import RequestOptions
from sdk._validation import require_str
from sdk.resources._mixin_base import RequesterMixin
from sdk.types import (
    IndexBuildResponse,
    IndexCompactResponse,
    IndexOptimizeResponse,
    IndexStatusResponse,
)


class IndexesMixin(RequesterMixin):
    def sync_indexes(
        self,
        corpus_id: str,
        *,
        wait: bool = True,
        poll_s: int = 5,
        idempotency_key: str | None = None,
    ) -> IndexBuildResponse:
        """Synchronize the default core retrieval indexes for a corpus.

        This is the simplest public indexing entrypoint. It queues the platform's
        synchronized core retrieval snapshot using the default automatic
        incremental behavior.

        Raises:
            NotFoundError: If the corpus does not exist.
            ConflictError: If documents are still processing, no chunks are
                ready to index yet, or the request conflicts with an active
                idempotent build.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        headers = self._idempotency_headers(idempotency_key)
        data = self._request(
            "POST",
            f"/v1/corpora/{corpus_id}/indexes:sync",
            headers=headers,
        )
        if wait:
            job_id = data.get("job_id")
            if job_id:
                self._wait_for_job(job_id, poll_s=poll_s)
        return cast("IndexBuildResponse", data)

    def build_indexes(
        self,
        corpus_id: str,
        dense: bool = True,
        sparse: bool = True,
        sparse_metadata: bool | None = None,
        mode: str = "incremental",
        idempotency_key: str | None = None,
        *,
        sparse_metadata_required: bool = False,
        wait: bool = True,
        poll_s: int = 5,
        request_options: RequestOptions | None = None,
    ) -> IndexBuildResponse:
        """Advanced index build entrypoint for a corpus.

        Args:
            corpus_id: The corpus to build indexes for.
            dense: Whether to build a dense (vector) index.
            sparse: Whether to build a sparse (BM25) index.
            sparse_metadata: Whether to build the metadata sparse (BM25)
                index. ``None`` uses the server default.
            sparse_metadata_required: Whether metadata sparse is required for
                successful completion. When ``True``, a metadata-sparse skip is
                treated as a build failure.
            mode: Build mode — ``"incremental"`` is the default synchronized
                snapshot path, while ``"full"`` forces a rebuild from scratch.
            idempotency_key: Optional idempotency key to prevent
                duplicate builds.
            wait: If ``True`` (default), block until the index build
                job completes.
            poll_s: Polling interval in seconds when *wait* is ``True``.

        For most callers, :meth:`sync_indexes` is the simpler default.

        Returns:
            The index build response, including the background job ID.

        Raises:
            NotFoundError: If the corpus does not exist.
            ConflictError: If documents are still processing, no chunks are
                ready to index yet, or a duplicate idempotency key is detected.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        payload = {"dense": dense, "sparse": sparse, "mode": mode}
        if sparse_metadata is not None:
            payload["sparse_metadata"] = bool(sparse_metadata)
        if sparse_metadata_required:
            payload["sparse_metadata_required"] = True
        headers = self._idempotency_headers(idempotency_key)
        data = self._request(
            "POST",
            f"/v1/corpora/{corpus_id}/indexes:build",
            json=payload,
            headers=headers,
            request_options=request_options,
        )
        if wait:
            job_id = data.get("job_id")
            if job_id:
                self._wait_for_job(job_id, poll_s=poll_s)
        return self._maybe_validate(data, "IndexBuildResponse")

    def index_status(
        self,
        corpus_id: str,
        request_options: RequestOptions | None = None,
    ) -> IndexStatusResponse:
        """Retrieve the current index status for a corpus.

        Args:
            corpus_id: The corpus to check.

        Returns:
            Index status including a top-level retrieval summary plus per-family details.

        Raises:
            NotFoundError: If the corpus does not exist.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        data = self._request(
            "GET", f"/v1/corpora/{corpus_id}/indexes/status", request_options=request_options
        )
        return self._maybe_validate(data, "IndexStatusResponse")

    def rebuild_indexes(
        self,
        corpus_id: str,
        dense: bool = True,
        sparse: bool = True,
        sparse_metadata: bool | None = None,
        idempotency_key: str | None = None,
        *,
        sparse_metadata_required: bool = False,
        request_options: RequestOptions | None = None,
    ) -> IndexBuildResponse:
        """Force a full rebuild of indexes for a corpus.

        Unlike :meth:`build_indexes`, this always performs a full rebuild
        regardless of existing index state.

        Args:
            corpus_id: The corpus to rebuild indexes for.
            dense: Whether to rebuild the dense (vector) index.
            sparse: Whether to rebuild the sparse (BM25) index.
            sparse_metadata: Whether to rebuild the metadata sparse
                (BM25) index. ``None`` uses the server default.
            sparse_metadata_required: Whether metadata sparse is required for
                successful completion. When ``True``, a metadata-sparse skip is
                treated as a build failure.
            idempotency_key: Optional idempotency key to prevent
                duplicate rebuilds.

        Returns:
            The index build response, including the background job ID.

        Raises:
            NotFoundError: If the corpus does not exist.
            ConflictError: If documents are still processing, no chunks are
                ready to index yet, or a duplicate idempotency key is detected.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        payload = {"dense": dense, "sparse": sparse, "mode": "full"}
        if sparse_metadata is not None:
            payload["sparse_metadata"] = bool(sparse_metadata)
        if sparse_metadata_required:
            payload["sparse_metadata_required"] = True
        headers = self._idempotency_headers(idempotency_key)
        data = self._request(
            "POST",
            f"/v1/corpora/{corpus_id}/indexes:rebuild",
            json=payload,
            headers=headers,
            request_options=request_options,
        )
        return self._maybe_validate(data, "IndexBuildResponse")

    def compact_indexes(
        self,
        corpus_id: str,
        *,
        dense: bool = True,
        sparse: bool = True,
        keep: int = 1,
        request_options: RequestOptions | None = None,
    ) -> IndexCompactResponse:
        """Compact index artifacts for a corpus, removing old generations.

        Args:
            corpus_id: The corpus whose indexes to compact.
            dense: Whether to compact dense index artifacts.
            sparse: Whether to compact sparse index artifacts.
            keep: Number of recent index generations to retain.

        Returns:
            A summary of compacted artifacts.

        Raises:
            NotFoundError: If the corpus does not exist.
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        data = self._request(
            "POST",
            f"/v1/corpora/{corpus_id}/indexes:compact",
            params={"dense": dense, "sparse": sparse, "keep": keep},
            request_options=request_options,
        )
        return self._maybe_validate(data, "IndexCompactResponse")

    def optimize_indexes(
        self,
        corpus_id: str,
        *,
        example_queries: list[str] | None = None,
        query_count: int | None = None,
        top_k: int | None = None,
        metric: str | None = None,
        force: bool = False,
        wait: bool = True,
        poll_s: int = 5,
        idempotency_key: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> IndexOptimizeResponse:
        """Queue retrieval optimization for a corpus.

        The optimize flow tunes retrieval defaults such as BM25 and RRF
        using stored or inline example queries. It is the supported
        customer-facing tuning path for search quality improvements.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        payload: dict[str, object] = {"force": force}
        if example_queries is not None:
            payload["example_queries"] = example_queries
        if query_count is not None:
            payload["query_count"] = query_count
        if top_k is not None:
            payload["top_k"] = top_k
        if metric is not None:
            payload["metric"] = metric
        headers = self._idempotency_headers(idempotency_key)
        data = self._request(
            "POST",
            f"/v1/corpora/{corpus_id}/indexes:optimize",
            json=payload,
            headers=headers,
            request_options=request_options,
        )
        if wait:
            job_id = data.get("job_id")
            if job_id:
                self._wait_for_job(job_id, poll_s=poll_s)
        return self._maybe_validate(data, "IndexOptimizeResponse")
