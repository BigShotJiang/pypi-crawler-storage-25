"""Agent resource mixin for the Knowledge2 SDK."""

from __future__ import annotations

from typing import Any, Literal

from sdk._paging import Page
from sdk._preview import preview_resource
from sdk._request_options import RequestOptions
from sdk._validation import _check_deprecated_system_prompt, require_str
from sdk.resources._mixin_base import RequesterMixin


@preview_resource
class AgentsMixin(RequesterMixin):
    def create_agent(
        self,
        *,
        name: str,
        corpus_id: str,
        description: str | None = None,
        system_prompt: str | None = None,
        model: str | None = None,
        project_id: str | None = None,
        task_type: str | None = None,
        instructions: str | None = None,
        source_agents: list[dict[str, Any]] | None = None,
        tool_config: dict[str, Any] | None = None,
        intent_fallback: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Create a new knowledge agent.

        Args:
            name: Human-readable name for the agent.
            corpus_id: ID of the corpus the agent queries against.
            description: Optional description of the agent's purpose.
            system_prompt: Optional custom system prompt for the agent.
            model: Optional model identifier (defaults to server-side default).
            project_id: Optional project that will own the agent.
            task_type: Optional task type for the agent (e.g. "summarize", "extract").
            instructions: Optional natural-language instructions for the agent.
            source_agents: Optional list of source agent references, each with
                ``agent_id`` and ``mode`` keys. Each dict may also include an
                ``intent_descriptor`` dict for intent-based routing.
            tool_config: Optional tool configuration dictionary for the agent.
            intent_fallback: Optional fallback mode when intent routing yields
                no matches. One of ``"broadcast"`` (default), ``"empty"``, or
                ``"retry_wider"``.

        Returns:
            The newly created agent record.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        corpus_id = require_str(corpus_id, "corpus_id")
        _check_deprecated_system_prompt(system_prompt, instructions)
        payload: dict[str, Any] = {"name": name, "corpus_id": corpus_id}
        if description is not None:
            payload["description"] = description
        if system_prompt is not None:
            payload["instructions"] = system_prompt
        if model is not None:
            payload["model"] = model
        if project_id is not None:
            payload["project_id"] = project_id
        if task_type is not None:
            payload["task_type"] = task_type
        if instructions is not None:
            payload["instructions"] = instructions
        if source_agents is not None:
            payload["source_agents"] = source_agents
        if tool_config is not None:
            payload["tool_config"] = tool_config
        if intent_fallback is not None:
            payload["intent_fallback"] = intent_fallback
        data = self._request("POST", "/v1/agents", json=payload, request_options=request_options)
        return self._maybe_validate(data, "AgentResponse")

    def get_agent(
        self,
        agent_id: str,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Retrieve a single agent by ID.

        Args:
            agent_id: Unique identifier of the agent.

        Returns:
            The agent record.

        Raises:
            NotFoundError: If the agent does not exist.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        data = self._request("GET", f"/v1/agents/{agent_id}", request_options=request_options)
        return self._maybe_validate(data, "AgentResponse")

    def list_agents(
        self,
        *,
        project_id: str | None = None,
        limit: int = 20,
        offset: int = 0,
        request_options: RequestOptions | None = None,
    ) -> Page[dict[str, Any]]:
        """List agents accessible to the current credentials.

        Args:
            project_id: Optional project ID to filter agents by.
            limit: Maximum number of agents to return per page.
            offset: Number of agents to skip for pagination.

        Returns:
            A Page containing agent records with pagination metadata.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        params: dict[str, Any] = {}
        if project_id is not None:
            params["project_id"] = project_id
        return self._list_page(
            "GET",
            "/v1/agents",
            items_key="agents",
            params=params or None,
            limit=limit,
            offset=offset,
        )

    def update_agent(
        self,
        agent_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        corpus_id: str | None = None,
        system_prompt: str | None = None,
        model: str | None = None,
        task_type: str | None = None,
        instructions: str | None = None,
        source_agents: list[dict[str, Any]] | None = None,
        tool_config: dict[str, Any] | None = None,
        intent_fallback: str | None = None,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Update agent settings.

        Args:
            agent_id: ID of the agent to update.
            name: New name for the agent.
            description: New description for the agent.
            corpus_id: New corpus ID for the agent.
            system_prompt: New system prompt for the agent.
            model: New model identifier for the agent.
            task_type: New task type for the agent.
            instructions: New natural-language instructions for the agent.
            source_agents: New list of source agent references, each with
                ``agent_id`` and ``mode`` keys. Each dict may also include an
                ``intent_descriptor`` dict for intent-based routing.
            tool_config: New tool configuration dictionary for the agent.
            intent_fallback: New fallback mode when intent routing yields
                no matches. One of ``"broadcast"``, ``"empty"``, or
                ``"retry_wider"``.

        Returns:
            Updated agent record.

        Raises:
            NotFoundError: If the agent does not exist.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        _check_deprecated_system_prompt(system_prompt, instructions)
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if corpus_id is not None:
            payload["corpus_id"] = corpus_id
        if system_prompt is not None:
            payload["instructions"] = system_prompt
        if model is not None:
            payload["model"] = model
        if task_type is not None:
            payload["task_type"] = task_type
        if instructions is not None:
            payload["instructions"] = instructions
        if source_agents is not None:
            payload["source_agents"] = source_agents
        if tool_config is not None:
            payload["tool_config"] = tool_config
        if intent_fallback is not None:
            payload["intent_fallback"] = intent_fallback
        data = self._request(
            "PATCH", f"/v1/agents/{agent_id}", json=payload, request_options=request_options
        )
        return self._maybe_validate(data, "AgentResponse")

    def delete_agent(
        self,
        agent_id: str,
        request_options: RequestOptions | None = None,
    ) -> None:
        """Delete an agent.

        The agent must be in ``draft`` or ``archived`` status; deleting
        an ``active`` agent will return a 409 Conflict error.

        Args:
            agent_id: Unique identifier of the agent to delete.

        Returns:
            None (the API returns 204 No Content on success).

        Raises:
            NotFoundError: If the agent does not exist.
            ConflictError: If the agent is currently active.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        self._request("DELETE", f"/v1/agents/{agent_id}", request_options=request_options)

    def activate_agent(
        self,
        agent_id: str,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Activate a draft or archived agent.

        Validates that the agent's corpus is ready and model is valid
        before transitioning the agent to ``active`` status.

        Args:
            agent_id: Unique identifier of the agent to activate.

        Returns:
            The updated agent record with ``active`` status.

        Raises:
            NotFoundError: If the agent does not exist.
            ConflictError: If the agent is already active.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        data = self._request(
            "POST", f"/v1/agents/{agent_id}/activate", request_options=request_options
        )
        return self._maybe_validate(data, "AgentResponse")

    def archive_agent(
        self,
        agent_id: str,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Archive an active agent.

        Transitions the agent from ``active`` to ``archived`` status.

        Args:
            agent_id: Unique identifier of the agent to archive.

        Returns:
            The updated agent record with ``archived`` status.

        Raises:
            NotFoundError: If the agent does not exist.
            ConflictError: If the agent is not currently active.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        data = self._request(
            "POST", f"/v1/agents/{agent_id}/archive", request_options=request_options
        )
        return self._maybe_validate(data, "AgentResponse")

    def chat_with_agent(
        self,
        agent_id: str,
        *,
        query: str,
        top_k: int = 5,
        filters: dict[str, Any] | None = None,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Send a chat query to an active agent.

        The agent retrieves relevant context from its corpus and generates
        a grounded answer using its configured model and system prompt.

        Args:
            agent_id: Unique identifier of the agent to chat with.
            query: The user's question or prompt.
            top_k: Number of top search results to use as context.
            filters: Optional metadata filters to narrow the search scope.

        Returns:
            A chat response containing the generated answer and sources.

        Raises:
            NotFoundError: If the agent does not exist.
            ConflictError: If the agent is not active.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        payload: dict[str, Any] = {"query": query, "top_k": top_k}
        if filters is not None:
            payload["filters"] = filters
        data = self._request(
            "POST",
            f"/v1/agents/{agent_id}/chat",
            json=payload,
            request_options=request_options,
        )
        return self._maybe_validate(data, "AgentChatResponse")

    def list_agent_models(
        self,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """List available models for knowledge agents.

        Returns:
            A dict containing the list of supported model identifiers.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        data = self._request("GET", "/v1/agents/models", request_options=request_options)
        return self._maybe_validate(data, "AgentModelsResponse")

    def run_agent(
        self,
        agent_id: str,
        *,
        input_chunks: list[dict[str, Any]],
        top_k: int = 5,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Run an agent on a set of input chunks.

        The endpoint returns HTTP 202 and the task is queued as a background
        job. Poll ``list_agent_runs()`` or the Jobs API to check for
        completion.

        Args:
            agent_id: Unique identifier of the agent to run.
            input_chunks: List of input chunk dicts, each containing a ``text``
                key and an optional ``metadata`` key.
            top_k: Number of top search results to use as context.

        Returns:
            A dict containing ``job_id`` and ``status`` for the queued run.

        Raises:
            NotFoundError: If the agent does not exist.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        payload: dict[str, Any] = {"input_chunks": input_chunks, "top_k": top_k}
        data = self._request(
            "POST",
            f"/v1/agents/{agent_id}/run",
            json=payload,
            request_options=request_options,
        )
        return self._maybe_validate(data, "AgentRunResponse")

    def list_agent_runs(
        self,
        agent_id: str,
        *,
        limit: int = 100,
        offset: int = 0,
        request_options: RequestOptions | None = None,
    ) -> Page[dict[str, Any]]:
        """List runs for a given agent.

        Args:
            agent_id: Unique identifier of the agent.
            limit: Maximum number of runs to return per page.
            offset: Number of runs to skip for pagination.

        Returns:
            A Page containing agent run records with pagination metadata.

        Raises:
            NotFoundError: If the agent does not exist.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        return self._list_page(
            "GET",
            f"/v1/agents/{agent_id}/runs",
            items_key="runs",
            limit=limit,
            offset=offset,
        )

    def list_task_types(
        self,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """List available task types for knowledge agents.

        Returns:
            A dict containing the list of supported task type identifiers.

        Raises:
            Knowledge2Error: If the API request fails.
        """
        data = self._request("GET", "/v1/agents/task-types", request_options=request_options)
        return self._maybe_validate(data, "AgentTaskTypesResponse")

    def create_subscription(
        self,
        agent_id: str,
        *,
        feed_id: str,
        role: Literal["input", "output"],
        mode: Literal["always", "explicit", "nl_semantic"] | None = None,
        match_spec: dict[str, Any] | None = None,
        match_spec_description: str | None = None,
        threshold: float | None = None,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """Create a feed subscription for an agent.

        Args:
            agent_id: Unique identifier of the agent.
            feed_id: Unique identifier of the feed to subscribe to.
            role: Subscription role, either ``"input"`` or ``"output"``.
            mode: Subscription authoring mode — ``"always"`` (match every
                envelope), ``"explicit"`` (evaluate ``match_spec`` as-is), or
                ``"nl_semantic"`` (compile ``match_spec_description`` into a
                semantic predicate). Optional; when ``None`` the server
                derives behavior from ``match_spec`` presence (preview).
            match_spec: Predicate dictionary; required when
                ``mode="explicit"``. When ``mode="always"`` or
                ``mode="nl_semantic"``, ``match_spec`` must be omitted — the
                server returns HTTP 422 if both are present.
            match_spec_description: Natural-language description; required
                when ``mode="nl_semantic"``. Length must be in [10, 500].
            threshold: Optional cosine threshold override for
                ``nl_semantic`` mode. Server default is ``0.75``.

        Returns:
            The newly created subscription record. The response includes the
            compiled ``match_spec`` (populated by the server for
            ``nl_semantic`` mode) and echoes ``match_spec_description``.

        Raises:
            NotFoundError: If the agent or feed does not exist.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        feed_id = require_str(feed_id, "feed_id")
        payload: dict[str, Any] = {"feed_id": feed_id, "role": role}
        if mode is not None:
            payload["mode"] = mode
        if match_spec is not None:
            payload["match_spec"] = match_spec
        if match_spec_description is not None:
            payload["match_spec_description"] = match_spec_description
        if threshold is not None:
            payload["threshold"] = threshold
        data = self._request(
            "POST",
            f"/v1/agents/{agent_id}/subscriptions",
            json=payload,
            request_options=request_options,
        )
        return self._maybe_validate(data, "SubscriptionResponse")

    def list_subscriptions(
        self,
        agent_id: str,
        request_options: RequestOptions | None = None,
    ) -> dict[str, Any]:
        """List all feed subscriptions for an agent.

        Args:
            agent_id: Unique identifier of the agent.

        Returns:
            A dict containing the list of subscription records.

        Raises:
            NotFoundError: If the agent does not exist.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        data = self._request(
            "GET",
            f"/v1/agents/{agent_id}/subscriptions",
            request_options=request_options,
        )
        return self._maybe_validate(data, "SubscriptionListResponse")

    def delete_subscription(
        self,
        agent_id: str,
        subscription_id: str,
        request_options: RequestOptions | None = None,
    ) -> None:
        """Delete a feed subscription from an agent.

        Args:
            agent_id: Unique identifier of the agent.
            subscription_id: Unique identifier of the subscription to delete.

        Returns:
            None (the API returns 204 No Content on success).

        Raises:
            NotFoundError: If the agent or subscription does not exist.
            Knowledge2Error: If the API request fails.
        """
        agent_id = require_str(agent_id, "agent_id")
        subscription_id = require_str(subscription_id, "subscription_id")
        self._request(
            "DELETE",
            f"/v1/agents/{agent_id}/subscriptions/{subscription_id}",
            request_options=request_options,
        )
