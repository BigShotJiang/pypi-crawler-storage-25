"""Async Knowledge2 API client.

Usage::

    from sdk import AsyncKnowledge2

    async with AsyncKnowledge2(api_key="k2_...") as client:
        results = await client.search(corpus_id, "my query")

    # Or use the async factory to auto-detect org_id:
    client = await AsyncKnowledge2.create(api_key="k2_...")
"""

from __future__ import annotations

import contextvars
import functools
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx

from sdk._async_base import AsyncBaseClient
from sdk._base import ClientLimits, ClientTimeouts
from sdk._logging import set_debug as _set_debug
from sdk.async_resources import (
    AsyncA2AMixin,
    AsyncAgentsMixin,
    AsyncAuditMixin,
    AsyncAuthMixin,
    AsyncConsoleMixin,
    AsyncCorporaMixin,
    AsyncDocumentsMixin,
    AsyncFeedsMixin,
    AsyncGenerationModelsMixin,
    AsyncIndexesMixin,
    AsyncJobsMixin,
    AsyncMetadataMixin,
    AsyncOnboardingMixin,
    AsyncOrgsMixin,
    AsyncPipelinesMixin,
    AsyncProjectsMixin,
    AsyncSearchMixin,
    AsyncUsageMixin,
)
from sdk.models.auth import WhoAmIResponseModel

if TYPE_CHECKING:
    from sdk.config import K2Config

DEFAULT_API_HOST = "https://api.knowledge2.ai"

_SENTINEL = object()


def _whoami_org_id(whoami: object) -> str:
    if isinstance(whoami, WhoAmIResponseModel):
        return whoami.org_id
    if isinstance(whoami, dict):
        return str(whoami["org_id"])
    raise TypeError("whoami response missing org_id")


class AsyncKnowledge2(
    AsyncBaseClient,
    AsyncOrgsMixin,
    AsyncAuthMixin,
    AsyncProjectsMixin,
    AsyncCorporaMixin,
    AsyncDocumentsMixin,
    AsyncIndexesMixin,
    AsyncSearchMixin,
    AsyncMetadataMixin,
    AsyncJobsMixin,
    AsyncAuditMixin,
    AsyncUsageMixin,
    AsyncConsoleMixin,
    AsyncOnboardingMixin,
    AsyncAgentsMixin,
    AsyncFeedsMixin,
    AsyncGenerationModelsMixin,
    AsyncPipelinesMixin,
    AsyncA2AMixin,
):
    """Async Knowledge2 API client.

    The async variant of :class:`~sdk.client.Knowledge2`.  Supports
    ``async with`` context management and ``await``-based API calls.

    Note: ``org_id`` auto-detection requires an async network call, so
    it cannot happen in ``__init__``.  Use :meth:`create` for automatic
    ``org_id`` resolution.

    Args:
        config: Optional :class:`~sdk.config.K2Config` instance.
        api_host: Base URL of the Knowledge2 API.
        api_key: API key for authentication (``X-API-Key`` header).
        org_id: Organisation ID.  Use :meth:`create` for auto-detection.
        bearer_token: Bearer token for console / Auth0 authentication.
        bearer_token_factory: Callable returning a bearer token string.
        token_cache_ttl: Seconds to cache the factory-produced token.
        headers: Extra default headers sent with every request.
        user_agent: Custom ``User-Agent`` header value.
        timeout: Request timeout in seconds (or an ``httpx.Timeout``).
        limits: Connection pool limits.
        max_retries: Maximum number of automatic retries.
        validate_responses: Enable Pydantic response validation.
        http_client: Pre-configured ``httpx.AsyncClient``.  When
            supplied the SDK does **not** close it — the caller retains
            ownership.
    """

    def __init__(
        self,
        *,
        config: K2Config | None = None,
        api_host: str | object = _SENTINEL,
        api_key: str | None | object = _SENTINEL,
        org_id: str | None | object = _SENTINEL,
        bearer_token: str | None | object = _SENTINEL,
        bearer_token_factory: Callable[[], str] | None = None,
        token_cache_ttl: float = 300.0,
        admin_token: str | None | object = _SENTINEL,
        headers: dict[str, str] | None = None,
        user_agent: str | None = None,
        timeout: float | ClientTimeouts | httpx.Timeout | None = None,
        limits: ClientLimits | None = None,
        max_retries: int | object = _SENTINEL,
        validate_responses: bool | object = _SENTINEL,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        # Resolve config vs explicit kwargs (explicit kwargs win)
        resolved_api_host: str = DEFAULT_API_HOST
        resolved_api_key: str | None = None
        resolved_org_id: str | None = None
        resolved_bearer_token: str | None = None
        resolved_admin_token: str | None = None
        resolved_max_retries: int = 2
        resolved_validate_responses: bool = False

        if config is not None:
            resolved_api_host = str(config.api_host)
            resolved_api_key = config.api_key
            resolved_org_id = config.org_id
            resolved_bearer_token = config.bearer_token
            resolved_admin_token = config.admin_token
            resolved_max_retries = config.max_retries
            resolved_validate_responses = getattr(config, "validate_responses", False)
            # Build timeout from config if no explicit timeout given
            if timeout is None:
                timeout = ClientTimeouts(
                    connect=config.timeout_connect,
                    read=config.timeout_read,
                    write=config.timeout_write,
                )
            # Build limits from config if no explicit limits given
            if limits is None:
                limits = ClientLimits(
                    max_connections=config.max_connections,
                    max_keepalive_connections=config.max_keepalive_connections,
                )

        # Explicit kwargs override config
        if api_host is not _SENTINEL:
            resolved_api_host = api_host  # type: ignore[assignment]
        if api_key is not _SENTINEL:
            resolved_api_key = api_key  # type: ignore[assignment]
        if org_id is not _SENTINEL:
            resolved_org_id = org_id  # type: ignore[assignment]
        if bearer_token is not _SENTINEL:
            resolved_bearer_token = bearer_token  # type: ignore[assignment]
        if admin_token is not _SENTINEL:
            resolved_admin_token = admin_token  # type: ignore[assignment]
        if max_retries is not _SENTINEL:
            resolved_max_retries = max_retries  # type: ignore[assignment]
        if validate_responses is not _SENTINEL:
            resolved_validate_responses = validate_responses  # type: ignore[assignment]

        super().__init__(
            resolved_api_host,
            resolved_api_key,
            bearer_token=resolved_bearer_token,
            bearer_token_factory=bearer_token_factory,
            token_cache_ttl=token_cache_ttl,
            admin_token=resolved_admin_token,
            headers=headers,
            user_agent=user_agent,
            timeout=timeout,
            limits=limits,
            max_retries=resolved_max_retries,
            validate_responses=resolved_validate_responses,
            http_client=http_client,
        )
        self.org_id = resolved_org_id

    # ------------------------------------------------------------------
    # Async factory
    # ------------------------------------------------------------------

    @classmethod
    async def create(cls, *, lazy: bool = False, **kwargs: Any) -> AsyncKnowledge2:
        """Create an async client with automatic org_id detection.

        Equivalent to constructing the client and then calling
        ``get_whoami()`` to resolve the org_id when an API key is
        provided but no org_id is given.

        All keyword arguments are forwarded to :class:`AsyncKnowledge2`.

        Args:
            lazy: When ``True``, skip the automatic
                ``GET /v1/auth/whoami`` call.  ``org_id`` will remain
                ``None`` unless provided explicitly or resolved later
                via :meth:`get_whoami`.  Defaults to ``False``.
            **kwargs: Forwarded to :class:`AsyncKnowledge2`.
        """
        client = cls(**kwargs)
        if not lazy and client.org_id is None and client.api_key is not None:
            whoami = await client.get_whoami()
            client.org_id = _whoami_org_id(whoami)
        return client

    # ------------------------------------------------------------------
    # Factory classmethods
    # ------------------------------------------------------------------

    @classmethod
    async def from_env(cls, **overrides: Any) -> AsyncKnowledge2:
        """Create a client from ``K2_*`` environment variables.

        Equivalent to ``AsyncKnowledge2.create(config=K2Config())``.
        """
        from sdk.config import K2Config

        config = K2Config()
        return await cls.create(config=config, **overrides)

    @classmethod
    async def from_file(cls, path: str | Path, **overrides: Any) -> AsyncKnowledge2:
        """Create a client from a JSON or YAML config file.

        Args:
            path: Path to the configuration file.
            **overrides: K2Config field values that override file values.
        """
        from sdk.config import K2Config

        config = K2Config.from_file(path, **overrides)
        return await cls.create(config=config)

    @classmethod
    async def from_profile(
        cls,
        name: str,
        path: str | Path | None = None,
        **overrides: Any,
    ) -> AsyncKnowledge2:
        """Create a client from a named profile in a config file.

        Args:
            name: Profile key to load (e.g. ``"staging"``).
            path: Config file path. Defaults to ``~/.k2/config.yaml``.
            **overrides: K2Config field values that override profile values.
        """
        from sdk.config import K2Config

        config = K2Config.from_profile(name, path=path, **overrides)
        return await cls.create(config=config)

    # ------------------------------------------------------------------
    # Auth & debug helpers
    # ------------------------------------------------------------------

    def is_authenticated(self) -> bool:
        """Return ``True`` if any authentication credential is configured."""
        return bool(
            self.api_key or self.bearer_token or self.admin_token or self._bearer_token_factory
        )

    @staticmethod
    def set_debug(enabled: bool = True) -> None:
        """Enable or disable SDK debug logging."""
        _set_debug(enabled)

    @functools.cached_property
    def with_raw_response(self) -> AsyncWithRawResponse:
        """Return an adapter that wraps every method to return :class:`RawResponse`.

        Usage::

            raw = await async_client.with_raw_response.list_corpora()
            raw.status_code   # 200
            raw.headers       # {"content-type": "application/json", ...}
            raw.parsed        # Page[dict] — same typed result as normal call
        """
        return AsyncWithRawResponse(self)


class AsyncWithRawResponse:
    """Adapter that wraps an :class:`AsyncKnowledge2` client so that every
    public method returns a :class:`~sdk._raw_response.RawResponse`.

    Task-safe: uses a ``contextvars.ContextVar`` so concurrent tasks
    do not interfere with each other.
    """

    def __init__(self, client: AsyncKnowledge2) -> None:
        self._client = client

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._client, name)
        if not callable(attr) or name.startswith("_"):
            raise AttributeError(name)

        @functools.wraps(attr)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            token = self._client._raw_response_flag.set(True)
            try:
                return await attr(*args, **kwargs)
            finally:
                self._client._raw_response_flag.reset(token)

        return wrapper
