# Changelog

All notable changes to the Knowledge² Python SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.7.0] - 2026-04-23

### Added

- Feed draft lifecycle on both `Knowledge2` and `AsyncKnowledge2`:
  `create_feed_draft`, `get_feed_draft`, `activate_feed_draft`,
  `discard_feed_draft`. Activation returns the updated **parent** feed;
  the draft is deleted server-side.
- `list_feed_subscriptions(feed_id)` — read-only view of the subscriptions
  embedded on the feed record. Handles validated and raw-response modes,
  passing `with_raw_response` errors through unchanged and re-wrapping
  successful responses so status/headers survive.
- Feed feedback helpers: `submit_feed_feedback(feed_id, *, rating,
  chunk_id, feed_run_id)` and `get_feed_feedback_stats(feed_id, *,
  feed_run_id=None)`. `rating` is validated client-side to be `0` or `1`.
- New response types `FeedFeedbackSubmitResponse` and
  `FeedFeedbackStatsResponse` exported from `sdk.types`, with matching
  strict Pydantic models registered for `validate_responses=True`.
- `FeedSubscriptionResponse` (and its Pydantic model) now include
  `match_spec` and `match_spec_description` — the routing metadata
  returned by the feed-side subscription schema for `explicit` and
  `nl_semantic` subscriptions.

### Changed

- `FeedResponseModel.subscriptions` now always validates to a list
  (previously `list | None = None`). The server contract guarantees a
  list — empty by default — so validated clients can iterate without a
  None check. A legacy response containing `null` for `subscriptions`
  will now raise `ValidationError` instead of producing a `None` field.
- `FeedSubscriptionResponseModel.agent_id` and `role` are now required
  (previously `str | None = None`) to match the server schema and catch
  malformed subscription payloads in validated clients.

## [0.6.1] - 2026-04-17

### Added

- `upload_documents_batch_and_wait(...)` as the canonical blocking helper for raw-text batch ingestion
- `wait_for_document_batch(...)` for callers that intentionally enqueue first and resolve the batch later

### Changed

- base installs now include `pydantic`, so `pip install knowledge2` is import-clean and supports validated response models without an extra
- `knowledge2[pydantic]` remains accepted as a compatibility alias for older install commands
- batch wait helpers now enforce a single end-to-end timeout budget and support `with_raw_response` correctly
- `get_document_batch(...)` now surfaces stable `doc_ids` and live counters once a batch is visible, instead of waiting for terminal aggregation
- refreshed the primary onboarding docs and examples to prefer the blocking batch helper and the released public contract
- clarified early auth and quota guidance for the supported retrieval workflow

## [0.6.0] - 2026-04-16

### Changed

- `upload_documents_batch(..., wait=False)` returns an enqueue handle with `job_id`, `batch_id`, and `count`
- `get_document_batch(...)` is the supported batch-status lookup for raw-text uploads, including final `doc_ids` and per-item errors
- refreshed public SDK release notes to align with the current batch-upload surface

## [0.5.0] - 2026-04-13

### Changed

- aligned the published Python SDK support matrix with the public customer-facing surface
- refreshed README guidance, examples, and optimize-related test coverage for the current SDK capabilities

## [0.4.1] - 2026-04-03

### Changed

- Release automation hardening for the public SDK sync/tag/PyPI path. No SDK API surface changes.

## [0.3.0] - 2026-03-30

### Added

- **Async parallel uploads**: `upload_documents_parallel()` on `AsyncDocumentsMixin`, bringing parity with the sync client.
- **Typed response models**: New response types for agents (`sdk/types/agents.py`), feeds (`sdk/types/feeds.py`), and pipelines (`sdk/types/pipelines.py`).
- **Comprehensive unit tests**: 339 unit tests covering all SDK resource modules.
- **PyPI release pipeline**: Public-repo `pypi-release.yml` GitHub Actions workflow for automated publishing.
- **Python 3.13 classifier**: Added `Programming Language :: Python :: 3.13` to package metadata.
- **Changelog URL**: Added changelog link to `pyproject.toml` project URLs.
- Mark agents, feeds, pipelines, and A2A resources as preview — emits
  `RuntimeWarning` on first call to indicate feature-flag dependency

### Fixed

- **Python version badge**: README badge now correctly states Python 3.11+ (was 3.10+).

## [0.2.0] - 2026-03-12

### Added

- **`ClientTimeouts`** (#713): Per-phase HTTP timeout configuration (connect, read, write, pool). Accepts `ClientTimeouts` dataclass, `float`, or `httpx.Timeout`.
- **`require_str()` param guard** (#714): Validates non-empty, non-whitespace resource IDs at call site before API request.
- **SDK User-Agent** (#715): Auto-injected `User-Agent: k2-python-sdk/{version}` header on every request. Customizable via `user_agent` parameter.
- **`is_authenticated()` health check** (#716): Returns `True` if any auth credential (API key, bearer token, admin token, or factory) is configured.
- **`Page[T]` pagination** (#717): `list_*` methods return `Page[T]` frozen dataclass with `items`, `total`, `offset`, `limit`. Supports `len()`, iteration, and boolean check.
- **`SyncPager[T]`** (#717): Lazy paginator with `next_page()`, `iter_pages()`, and item-level iteration for `iter_*` methods.
- **`bearer_token_factory`** (#718): Callable-based dynamic auth for OAuth/OIDC. Thread-safe double-check locking with configurable `token_cache_ttl` (default 300s, 0 to disable). Auto-refreshes on 401.
- **Two-step delete guard** (#719): `delete_corpus()` requires `confirm=True` to execute. Raises `ValueError` if not confirmed.
- **`K2Config` frozen config** (#720): Pydantic-settings based configuration from environment variables (`K2_*` prefix), JSON/YAML files, or named profiles.
- **Sub-client namespaces** (#721): `client.documents.*`, `client.corpora.*`, `client.search_ns.*`, etc. Lightweight cached proxies — flat methods still work.
- **Parallel uploads** (#722): `upload_documents_parallel()` using `ThreadPoolExecutor` for concurrent document ingestion.
- **Pydantic response validation** (#723): Optional `validate_responses=True` or `Knowledge2Validated` class. Base installs now include the Pydantic model dependency.
- **`AsyncKnowledge2` client** (#724): Native async client using `httpx.AsyncClient`. `AsyncPager[T]` for async pagination. Factory methods: `create()`, `from_env()`, `from_file()`, `from_profile()`.
- **`RequestOptions`** (#732): Per-call overrides for timeout, retries, and passthrough headers. `request_options` parameter on all public methods.
- **`with_raw_response`** (#733): `client.with_raw_response.<method>(...)` returns `RawResponse[T]` with `status_code`, `headers`, and `parsed` body. Thread-safe (sync) and task-safe (async).
- **Custom `httpx.Client` injection** (#734): `http_client` parameter for custom TLS, proxies, or observability middleware. Explicit ownership — SDK never closes caller-supplied clients.

### Changed

- **`list_*` methods return `Page[T]`** instead of raw dicts. This is a breaking change for code that accessed the raw dict keys directly. Use `page.items` instead.

## [0.1.0] - 2026-02-13

### Added

- **Error hierarchy**: 10 exception types (`AuthenticationError`, `RateLimitError`,
  `ServerError`, `APIConnectionError`, `APITimeoutError`, etc.) with `retryable`
  property. All subclass `Knowledge2Error` for backward compatibility.
- **Automatic retry**: Exponential backoff with jitter for 5xx, 429, connection
  errors, and timeouts. Configurable via `max_retries` (default: 2). Rate limit
  429 responses honor `Retry-After` header.
- **Pagination iterators**: `iter_*` methods for all paginated `list_*` endpoints
  (e.g., `iter_documents`, `iter_corpora`, `iter_jobs`). Lazy page fetching.
- **Debug logging**: Logger named `knowledge2` with credential redaction.
  `set_debug()` convenience method.
- **Typed config parameters**: Search methods accept TypedDict types
  (`SearchHybridConfig`, `SearchRerankConfig`, etc.) alongside `dict[str, Any]`.
- **Comprehensive docstrings**: Google-style docstrings on all public methods.
- **Standalone package**: `pyproject.toml` for independent `pip install`.
- **SDK versioning**: `__version__` attribute and this changelog.
- **Focused examples**: Quick-start, search, document upload, error handling,
  pagination, and batch operations examples.
- **Comprehensive README**: Installation, authentication, configuration, error
  handling, pagination, and resource overview.

### Changed

- `fetch_whoami()` renamed to `get_whoami()` for consistency. `fetch_whoami()`
  is now a deprecated alias.
- `reconcile_jobs()` and `cancel_tuning_run()` return typed responses instead
  of `dict[str, Any]`.
