"""Shared response validation logic for sync and async clients."""

from __future__ import annotations

from typing import Any


def maybe_validate(data: Any, model_name: str, *, validate: bool, raw_response_cls: type) -> Any:
    """Validate response data through its Pydantic model if validation is enabled.

    Args:
        data: The raw dict from ``_request()``.
        model_name: The TypedDict class name (e.g. ``"SearchResponse"``).
        validate: Whether response validation is enabled.
        raw_response_cls: The RawResponse class to check against.

    Returns:
        The validated Pydantic model instance if validation is on,
        otherwise the raw dict unchanged.
    """
    if isinstance(data, raw_response_cls):
        return data
    if not validate or data is None:
        return data
    try:
        from sdk.models._registry import get_model_for_type
    except ImportError as exc:
        raise ImportError(
            "Response validation requires the bundled 'pydantic' dependency. "
            "Reinstall or upgrade the base 'knowledge2' package."
        ) from exc

    model_cls = get_model_for_type(model_name)
    if model_cls is None:
        return data
    return model_cls.model_validate(data)  # type: ignore[attr-defined]
