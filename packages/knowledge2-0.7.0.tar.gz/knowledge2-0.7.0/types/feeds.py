from __future__ import annotations

from typing import Any, TypedDict


class FeedSubscriptionResponse(TypedDict, total=False):
    """A subscription entry within a feed response."""

    id: str | None
    agent_id: str
    agent_name: str | None
    role: str
    match_spec: dict[str, Any] | None
    match_spec_description: str | None


class FeedResponse(TypedDict, total=False):
    """A single knowledge feed record."""

    id: str
    project_id: str
    source_agent_id: str
    name: str
    execution_mode: str
    persistent: bool
    reactive: bool
    target_corpus_id: str | None
    schedule_interval: str | None
    schedule_hour: int | None
    start_from: str | None
    activation_status: str
    last_checked_seq: int
    last_run_at: str | None
    last_run_result_count: int | None
    subscriptions: list[FeedSubscriptionResponse]
    parent_feed_id: str | None
    has_draft: bool
    created_at: str | None
    updated_at: str | None


class FeedListResponse(TypedDict):
    """Paginated list of feeds."""

    feeds: list[FeedResponse]
    total: int
    limit: int
    offset: int


class FeedRunResponse(TypedDict, total=False):
    """Response from triggering a feed run."""

    new_content: bool
    results: list[dict[str, Any]] | None
    result_count: int
    truncated: bool
    ingestion_job_id: str | None
    dry_run: bool
    would_ingest_count: int | None
    feed_run_id: str | None


class FeedFeedbackSubmitResponse(TypedDict):
    """Response from submitting feedback on a feed result.

    All fields are guaranteed by the server contract
    (``api/app/schemas/feedback.py``): ``message`` has a default of
    ``"ok"`` and ``feedback_id`` is the created record's id.
    """

    message: str
    feedback_id: str


class FeedFeedbackStatsResponse(TypedDict):
    """Aggregated feedback stats for a feed (optionally scoped to a run via query param).

    All fields are guaranteed by the server contract; counters default
    to 0 when no feedback has been submitted.
    """

    feed_id: str
    total: int
    positive: int
    negative: int
