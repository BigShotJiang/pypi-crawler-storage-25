"""Sub-client namespace accessors for the Knowledge2 SDK.

Lightweight proxy objects that group related methods into discoverable
namespaces without changing the existing flat API::

    # Flat (existing, unchanged)
    client.upload_document(corpus_id, file_path="doc.pdf")

    # Namespaced (new, equivalent)
    client.documents.upload(corpus_id, file_path="doc.pdf")
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sdk._paging import Page, SyncPager
    from sdk.client import Knowledge2
    from sdk.types import (
        ApiKeyCreateResponse,
        ApiKeyListResponse,
        ApiKeyRevokeResponse,
        ApiKeyRotateResponse,
        ChunkingConfig,
        CorpusDeleteResponse,
        CorpusResponse,
        CorpusStatusResponse,
        DocumentBatchEnqueueResponse,
        DocumentBatchStatusResponse,
        DocumentBatchUploadResponse,
        DocumentCreateResponse,
        DocumentDeleteResponse,
        DocumentDetailResponse,
        DocumentManifestIngestResponse,
        DocumentUploadCapabilitiesResponse,
        DocumentUrlIngestResponse,
        EmbeddingsResponse,
        FeedbackResponse,
        JobResponse,
        JobStatusResponse,
        ReconcileJobsResponse,
        SearchBatchResponse,
        SearchGenerateResponse,
        SearchResponse,
        WhoAmIResponse,
    )


class _Namespace:
    """Base class for namespace proxies."""

    __slots__ = ("_client",)

    def __init__(self, client: Knowledge2) -> None:
        self._client = client


# ------------------------------------------------------------------
# Documents
# ------------------------------------------------------------------


class DocumentsNamespace(_Namespace):
    """Document operations: ``client.documents.*``"""

    def upload(
        self,
        corpus_id: str,
        *,
        file_path: str | None = None,
        file_bytes: bytes | None = None,
        filename: str | None = None,
        raw_text: str | None = None,
        source_uri: str | None = None,
        metadata: dict[str, Any] | None = None,
        auto_index: bool | None = None,
        chunk_strategy: str | None = None,
        chunking: ChunkingConfig | None = None,
        idempotency_key: str | None = None,
    ) -> DocumentCreateResponse:
        return self._client.upload_document(
            corpus_id,
            file_path=file_path,
            file_bytes=file_bytes,
            filename=filename,
            raw_text=raw_text,
            source_uri=source_uri,
            metadata=metadata,
            auto_index=auto_index,
            chunk_strategy=chunk_strategy,
            chunking=chunking,
            idempotency_key=idempotency_key,
        )

    def upload_batch(
        self,
        corpus_id: str,
        documents: list[dict[str, Any]],
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> DocumentBatchEnqueueResponse | DocumentBatchStatusResponse:
        return self._client.upload_documents_batch(corpus_id, documents, idempotency_key, **kwargs)

    def upload_batch_and_wait(
        self,
        corpus_id: str,
        documents: list[dict[str, Any]],
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> DocumentBatchStatusResponse:
        return self._client.upload_documents_batch_and_wait(
            corpus_id, documents, idempotency_key, **kwargs
        )

    def upload_files_batch(
        self,
        corpus_id: str,
        files: list[tuple[str, bytes]],
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> DocumentBatchUploadResponse:
        return self._client.upload_files_batch(corpus_id, files, idempotency_key, **kwargs)

    def upload_parallel(
        self,
        corpus_id: str,
        file_paths: list[str],
        **kwargs: Any,
    ) -> list[DocumentCreateResponse]:
        return self._client.upload_documents_parallel(corpus_id, file_paths, **kwargs)

    def ingest_urls(
        self,
        corpus_id: str,
        urls: list[dict[str, Any]],
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> DocumentUrlIngestResponse:
        return self._client.ingest_urls(corpus_id, urls, idempotency_key, **kwargs)

    def ingest_manifest(
        self,
        corpus_id: str,
        manifest_uri: str,
        max_documents: int | None = None,
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> DocumentManifestIngestResponse:
        return self._client.ingest_manifest(
            corpus_id, manifest_uri, max_documents, idempotency_key, **kwargs
        )

    def get_batch(self, corpus_id: str, batch_id: str) -> DocumentBatchStatusResponse:
        return self._client.get_document_batch(corpus_id, batch_id)

    def wait_for_batch(
        self,
        corpus_id: str,
        batch_id: str,
        **kwargs: Any,
    ) -> DocumentBatchStatusResponse:
        return self._client.wait_for_document_batch(corpus_id, batch_id, **kwargs)

    def list(self, corpus_id: str, **kwargs: Any) -> Page[dict[str, Any]]:
        return self._client.list_documents(corpus_id, **kwargs)

    def iter(self, corpus_id: str, **kwargs: Any) -> SyncPager[dict[str, Any]]:
        return self._client.iter_documents(corpus_id, **kwargs)

    def get(self, doc_id: str) -> DocumentDetailResponse:
        return self._client.get_document(doc_id)

    def capabilities(self, corpus_id: str) -> DocumentUploadCapabilitiesResponse:
        return self._client.get_document_upload_capabilities(corpus_id)

    def update_metadata(self, doc_id: str, metadata: dict[str, Any]) -> dict[str, Any]:
        return self._client.update_document_metadata(doc_id, metadata)

    def delete(
        self, corpus_id: str, doc_id: str, *, confirm: bool = False, reindex: bool = False
    ) -> DocumentDeleteResponse:
        return self._client.delete_document(corpus_id, doc_id, confirm=confirm, reindex=reindex)

    def list_chunks(
        self, corpus_id: str, limit: int = 100, offset: int = 0
    ) -> Page[dict[str, Any]]:
        return self._client.list_chunks(corpus_id, limit=limit, offset=offset)

    def iter_chunks(self, corpus_id: str, *, limit: int = 100) -> SyncPager[dict[str, Any]]:
        return self._client.iter_chunks(corpus_id, limit=limit)


# ------------------------------------------------------------------
# Corpora
# ------------------------------------------------------------------


class CorporaNamespace(_Namespace):
    """Corpus operations: ``client.corpora.*``"""

    def create(self, project_id: str, name: str, description: str | None = None) -> CorpusResponse:
        return self._client.create_corpus(project_id, name, description)

    def list(self, limit: int = 100, offset: int = 0) -> Page[dict[str, Any]]:
        return self._client.list_corpora(limit=limit, offset=offset)

    def iter(self, *, limit: int = 100) -> SyncPager[dict[str, Any]]:
        return self._client.iter_corpora(limit=limit)

    def get(self, corpus_id: str) -> CorpusResponse:
        return self._client.get_corpus(corpus_id)

    def status(self, corpus_id: str) -> CorpusStatusResponse:
        return self._client.get_corpus_status(corpus_id)

    def update(self, corpus_id: str, **kwargs: Any) -> CorpusResponse:
        return self._client.update_corpus(corpus_id, **kwargs)

    def delete(
        self, corpus_id: str, *, confirm: bool = False, force: bool = False
    ) -> CorpusDeleteResponse:
        return self._client.delete_corpus(corpus_id, confirm=confirm, force=force)


# ------------------------------------------------------------------
# Search
# ------------------------------------------------------------------


class SearchNamespace(_Namespace):
    """Search operations: ``client.search_ns.*``"""

    def query(self, corpus_id: str, query: str, **kwargs: Any) -> SearchResponse:
        return self._client.search(corpus_id, query, **kwargs)

    def batch(self, corpus_id: str, queries: list[str], **kwargs: Any) -> SearchBatchResponse:
        return self._client.search_batch(corpus_id, queries, **kwargs)

    def generate(self, corpus_id: str, query: str, **kwargs: Any) -> SearchGenerateResponse:
        return self._client.search_generate(corpus_id, query, **kwargs)

    def embeddings(
        self, model: str, inputs: list[str], embed_type: str = "query"
    ) -> EmbeddingsResponse:
        return self._client.embeddings(model, inputs, embed_type)

    def feedback(self, corpus_id: str, query: str, **kwargs: Any) -> FeedbackResponse:
        return self._client.create_feedback(corpus_id, query, **kwargs)


# ------------------------------------------------------------------
# Jobs
# ------------------------------------------------------------------


class JobsNamespace(_Namespace):
    """Job operations: ``client.jobs.*``"""

    def get(self, job_id: str) -> JobResponse:
        return self._client.get_job(job_id)

    def list(self, **kwargs: Any) -> Page[dict[str, Any]]:
        return self._client.list_jobs(**kwargs)

    def iter(self, **kwargs: Any) -> SyncPager[dict[str, Any]]:
        return self._client.iter_jobs(**kwargs)

    def cancel(self, job_id: str) -> JobStatusResponse:
        return self._client.cancel_job(job_id)

    def retry(self, job_id: str) -> JobStatusResponse:
        return self._client.retry_job(job_id)

    def reconcile(self) -> ReconcileJobsResponse:
        return self._client.reconcile_jobs()


# ------------------------------------------------------------------
# Auth
# ------------------------------------------------------------------


class AuthNamespace(_Namespace):
    """Auth operations: ``client.auth.*``"""

    def create_api_key(
        self,
        org_id: str,
        name: str,
        scopes: dict[str, Any] | None = None,
    ) -> ApiKeyCreateResponse:
        return self._client.create_api_key(org_id, name, scopes)

    def list_api_keys(self) -> ApiKeyListResponse:
        return self._client.list_api_keys()

    def revoke_api_key(self, key_id: str) -> ApiKeyRevokeResponse:
        return self._client.revoke_api_key(key_id)

    def rotate_api_key(self, key_id: str) -> ApiKeyRotateResponse:
        return self._client.rotate_api_key(key_id)

    def whoami(self) -> WhoAmIResponse:
        return self._client.get_whoami()
