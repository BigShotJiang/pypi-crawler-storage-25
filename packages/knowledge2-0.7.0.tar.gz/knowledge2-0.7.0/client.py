"""Knowledge2 API client.

Usage::

    from sdk import Knowledge2

    client = Knowledge2(api_key="k2_...")
    results = client.search(corpus_id, "my query")

    # With validated config object:
    from sdk import K2Config
    config = K2Config(api_key="k2_...", max_retries=5)
    client = Knowledge2(config=config)

    # From environment variables:
    client = Knowledge2.from_env()
"""

from __future__ import annotations

import functools
import threading
from collections.abc import Callable
from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx

from sdk._base import BaseClient, ClientLimits, ClientTimeouts
from sdk._logging import set_debug as _set_debug
from sdk.models.auth import WhoAmIResponseModel
from sdk.resources import (
    A2AMixin,
    AgentsMixin,
    AuditMixin,
    AuthMixin,
    ConsoleMixin,
    CorporaMixin,
    DocumentsMixin,
    FeedsMixin,
    GenerationModelsMixin,
    IndexesMixin,
    JobsMixin,
    MetadataMixin,
    OnboardingMixin,
    OrgsMixin,
    PipelinesMixin,
    ProjectsMixin,
    SearchMixin,
    UsageMixin,
)

if TYPE_CHECKING:
    from sdk.config import K2Config
    from sdk.namespaces import (
        AuthNamespace,
        CorporaNamespace,
        DocumentsNamespace,
        JobsNamespace,
        SearchNamespace,
    )

DEFAULT_API_HOST = "https://api.knowledge2.ai"

_SENTINEL = object()


def _whoami_org_id(whoami: object) -> str:
    if isinstance(whoami, WhoAmIResponseModel):
        return whoami.org_id
    if isinstance(whoami, dict):
        return str(whoami["org_id"])
    raise TypeError("whoami response missing org_id")


class Knowledge2(
    BaseClient,
    OrgsMixin,
    AuthMixin,
    ProjectsMixin,
    CorporaMixin,
    DocumentsMixin,
    IndexesMixin,
    SearchMixin,
    MetadataMixin,
    JobsMixin,
    AuditMixin,
    UsageMixin,
    ConsoleMixin,
    OnboardingMixin,
    AgentsMixin,
    FeedsMixin,
    GenerationModelsMixin,
    PipelinesMixin,
    A2AMixin,
):
    """Knowledge2 API client.

    The SDK is intentionally self-contained so it can be published directly from
    the ``sdk/`` directory.

    Args:
        config: Optional :class:`~sdk.config.K2Config` instance.  When
            provided, its values are used as defaults that can be
            overridden by explicit keyword arguments.
        api_host: Base URL of the Knowledge2 API.
        api_key: API key for authentication (``X-API-Key`` header).
        org_id: Organisation ID.  Auto-detected from the API key when
            omitted via a ``GET /v1/auth/whoami`` call during construction.
            Pass explicitly to skip this network call.
        bearer_token: Bearer token for console / Auth0 authentication.
        bearer_token_factory: Callable returning a bearer token string.
            Called lazily on first request and cached for
            ``token_cache_ttl`` seconds.  Mutually exclusive with
            ``bearer_token``.
        token_cache_ttl: Seconds to cache the factory-produced token
            (default 300).  Set to ``0`` to disable caching.
        headers: Extra default headers sent with every request.
        user_agent: Custom ``User-Agent`` header value.
        timeout: Request timeout in seconds (or an ``httpx.Timeout``).
        limits: Connection pool limits.
        max_retries: Maximum number of automatic retries for transient
            errors (5xx, 429, connection failures, timeouts).  Set to
            ``0`` to disable.
        http_client: Pre-configured ``httpx.Client`` to use for HTTP
            transport.  When supplied, the SDK does **not** close it —
            the caller retains ownership.  ``timeout`` and ``limits``
            are ignored (configure them on the client directly).
        lazy: When ``True``, skip the automatic ``GET /v1/auth/whoami``
            call during construction.  ``org_id`` will remain ``None``
            unless provided explicitly or resolved later via
            :meth:`get_whoami`.  Defaults to ``False``.
    """

    def __init__(
        self,
        *,
        config: K2Config | None = None,
        api_host: str | object = _SENTINEL,
        api_key: str | None | object = _SENTINEL,
        org_id: str | None | object = _SENTINEL,
        bearer_token: str | None | object = _SENTINEL,
        bearer_token_factory: Callable[[], str] | None = None,
        token_cache_ttl: float = 300.0,
        admin_token: str | None | object = _SENTINEL,
        headers: dict[str, str] | None = None,
        user_agent: str | None = None,
        timeout: float | ClientTimeouts | httpx.Timeout | None = None,
        limits: ClientLimits | None = None,
        max_retries: int | object = _SENTINEL,
        validate_responses: bool | object = _SENTINEL,
        http_client: httpx.Client | None = None,
        lazy: bool = False,
    ) -> None:
        # Resolve config vs explicit kwargs (explicit kwargs win)
        resolved_api_host: str = DEFAULT_API_HOST
        resolved_api_key: str | None = None
        resolved_org_id: str | None = None
        resolved_bearer_token: str | None = None
        resolved_admin_token: str | None = None
        resolved_max_retries: int = 2
        resolved_validate_responses: bool = False

        if config is not None:
            resolved_api_host = str(config.api_host)
            resolved_api_key = config.api_key
            resolved_org_id = config.org_id
            resolved_bearer_token = config.bearer_token
            resolved_admin_token = config.admin_token
            resolved_max_retries = config.max_retries
            resolved_validate_responses = getattr(config, "validate_responses", False)
            # Build timeout from config if no explicit timeout given
            if timeout is None:
                timeout = ClientTimeouts(
                    connect=config.timeout_connect,
                    read=config.timeout_read,
                    write=config.timeout_write,
                )
            # Build limits from config if no explicit limits given
            if limits is None:
                limits = ClientLimits(
                    max_connections=config.max_connections,
                    max_keepalive_connections=config.max_keepalive_connections,
                )

        # Explicit kwargs override config
        if api_host is not _SENTINEL:
            resolved_api_host = api_host  # type: ignore[assignment]
        if api_key is not _SENTINEL:
            resolved_api_key = api_key  # type: ignore[assignment]
        if org_id is not _SENTINEL:
            resolved_org_id = org_id  # type: ignore[assignment]
        if bearer_token is not _SENTINEL:
            resolved_bearer_token = bearer_token  # type: ignore[assignment]
        if admin_token is not _SENTINEL:
            resolved_admin_token = admin_token  # type: ignore[assignment]
        if max_retries is not _SENTINEL:
            resolved_max_retries = max_retries  # type: ignore[assignment]
        if validate_responses is not _SENTINEL:
            resolved_validate_responses = validate_responses  # type: ignore[assignment]

        super().__init__(
            resolved_api_host,
            resolved_api_key,
            bearer_token=resolved_bearer_token,
            bearer_token_factory=bearer_token_factory,
            token_cache_ttl=token_cache_ttl,
            admin_token=resolved_admin_token,
            headers=headers,
            user_agent=user_agent,
            timeout=timeout,
            limits=limits,
            max_retries=resolved_max_retries,
            validate_responses=resolved_validate_responses,
            http_client=http_client,
        )
        self.org_id = resolved_org_id
        if not lazy and self.org_id is None and resolved_api_key is not None:
            whoami = self.get_whoami()
            self.org_id = _whoami_org_id(whoami)

    # ------------------------------------------------------------------
    # Factory classmethods
    # ------------------------------------------------------------------

    @classmethod
    def from_env(cls, **overrides: Any) -> Knowledge2:
        """Create a client from ``K2_*`` environment variables.

        Equivalent to ``Knowledge2(config=K2Config())``, with any
        *overrides* passed as constructor kwargs.

        Requires ``pydantic-settings`` — install via
        ``pip install knowledge2[config]``.
        """
        from sdk.config import K2Config

        config = K2Config()
        return cls(config=config, **overrides)

    @classmethod
    def from_file(cls, path: str | Path, **overrides: Any) -> Knowledge2:
        """Create a client from a JSON or YAML config file.

        Args:
            path: Path to the configuration file.
            **overrides: K2Config field values that override file
                values (e.g. ``api_key="k2_..."``).
        """
        from sdk.config import K2Config

        config = K2Config.from_file(path, **overrides)
        return cls(config=config)

    @classmethod
    def from_profile(
        cls,
        name: str,
        path: str | Path | None = None,
        **overrides: Any,
    ) -> Knowledge2:
        """Create a client from a named profile in a config file.

        Args:
            name: Profile key to load (e.g. ``"staging"``).
            path: Config file path. Defaults to ``~/.k2/config.yaml``.
            **overrides: K2Config field values that override profile
                values (e.g. ``api_key="k2_..."``).
        """
        from sdk.config import K2Config

        config = K2Config.from_profile(name, path=path, **overrides)
        return cls(config=config)

    # ------------------------------------------------------------------
    # Auth & debug helpers
    # ------------------------------------------------------------------

    def is_authenticated(self) -> bool:
        """Return ``True`` if any authentication credential is configured."""
        return bool(
            self.api_key or self.bearer_token or self.admin_token or self._bearer_token_factory
        )

    @staticmethod
    def set_debug(enabled: bool = True) -> None:
        """Enable or disable SDK debug logging.

        When enabled, request method, URL, response status, and retry
        attempts are logged to stderr.  Authentication headers are
        redacted.

        Args:
            enabled: ``True`` to turn on debug logging, ``False`` to
                turn it off.
        """
        _set_debug(enabled)

    # ------------------------------------------------------------------
    # Namespace accessors
    # ------------------------------------------------------------------

    @cached_property
    def with_raw_response(self) -> WithRawResponse:
        """Return an adapter that wraps every method to return :class:`RawResponse`.

        Usage::

            raw = client.with_raw_response.list_corpora()
            raw.status_code   # 200
            raw.headers       # {"content-type": "application/json", ...}
            raw.parsed        # Page[dict] — same typed result as normal call
        """
        return WithRawResponse(self)

    @cached_property
    def documents(self) -> DocumentsNamespace:
        """Document operations namespace: ``client.documents.*``"""
        from sdk.namespaces import DocumentsNamespace

        return DocumentsNamespace(self)

    @cached_property
    def corpora(self) -> CorporaNamespace:
        """Corpus operations namespace: ``client.corpora.*``"""
        from sdk.namespaces import CorporaNamespace

        return CorporaNamespace(self)

    @cached_property
    def search_ns(self) -> SearchNamespace:
        """Search operations namespace: ``client.search_ns.*``

        Named ``search_ns`` to avoid shadowing the :meth:`search` method.
        """
        from sdk.namespaces import SearchNamespace

        return SearchNamespace(self)

    @cached_property
    def jobs(self) -> JobsNamespace:
        """Job operations namespace: ``client.jobs.*``"""
        from sdk.namespaces import JobsNamespace

        return JobsNamespace(self)

    @cached_property
    def auth(self) -> AuthNamespace:
        """Auth operations namespace: ``client.auth.*``"""
        from sdk.namespaces import AuthNamespace

        return AuthNamespace(self)


class WithRawResponse:
    """Adapter that wraps a :class:`Knowledge2` client so that every
    public method returns a :class:`~sdk._raw_response.RawResponse`
    exposing HTTP status code, headers, and the parsed body.

    Thread-safe: uses a ``threading.local`` flag so concurrent threads
    do not interfere with each other.
    """

    def __init__(self, client: Knowledge2) -> None:
        self._client = client

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._client, name)
        if not callable(attr) or name.startswith("_"):
            raise AttributeError(name)

        @functools.wraps(attr)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            self._client._raw_response_flag.enabled = True
            try:
                return attr(*args, **kwargs)
            finally:
                self._client._raw_response_flag.enabled = False

        return wrapper


class Knowledge2Validated(Knowledge2):
    """Knowledge2 client with Pydantic response validation enabled by default.

    Equivalent to ``Knowledge2(validate_responses=True)``.
    """

    def __init__(self, **kwargs: Any) -> None:
        kwargs.setdefault("validate_responses", True)
        super().__init__(**kwargs)
