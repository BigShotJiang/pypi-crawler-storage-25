"""Pydantic models for agent types."""

from __future__ import annotations

from typing import Any

from sdk.models._base import K2BaseModel


class SourceAgentInfoModel(K2BaseModel):
    agent_id: str | None = None
    agent_name: str | None = None
    mode: str | None = None
    intent_descriptor: dict[str, Any] | None = None


class ToolConfigResponseModel(K2BaseModel):
    webhook_url: str | None = None
    webhook_secret: str | None = None
    webhook_retries: int | None = None


class AgentResponseModel(K2BaseModel):
    id: str | None = None
    org_id: str | None = None
    project_id: str | None = None
    name: str | None = None
    slug: str | None = None
    description: str | None = None
    corpus_id: str | None = None
    task_type: str | None = None
    instructions: str | None = None
    model: str | None = None
    status: str | None = None
    parent_agent_id: str | None = None
    source_agents: list[SourceAgentInfoModel] | None = None
    tool_config: ToolConfigResponseModel | None = None
    declared_schema: dict[str, Any] | None = None
    harvest_policy: str | None = None
    intent_fallback: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class AgentListResponseModel(K2BaseModel):
    agents: list[AgentResponseModel]
    total: int
    limit: int
    offset: int


class AgentChatResponseModel(K2BaseModel):
    answer: str | None = None
    model: str | None = None
    results: list[dict[str, Any]] | None = None
    used_sources: list[str] | None = None
    meta: dict[str, Any] | None = None


class AgentModelInfoModel(K2BaseModel):
    id: str | None = None
    name: str | None = None
    provider: str | None = None
    default: bool | None = None


class AgentModelsResponseModel(K2BaseModel):
    models: list[AgentModelInfoModel]


class TaskTypeInfoModel(K2BaseModel):
    id: str | None = None
    name: str | None = None
    description: str | None = None
    output_schema: str | None = None
    supports_chat: bool | None = None


class AgentTaskTypesResponseModel(K2BaseModel):
    task_types: list[TaskTypeInfoModel]


class ProvenanceModel(K2BaseModel):
    run_id: str | None = None
    agent_id: str | None = None
    agent_name: str | None = None
    agent_version: str | None = None
    task_type: str | None = None
    model: str | None = None
    input_chunk_ids: list[str] | None = None
    reference_corpus_id: str | None = None
    reference_chunk_ids: list[str] | None = None
    source_agents: list[dict[str, Any]] | None = None
    execution_time_ms: int | None = None
    envelope_version: int | None = None


class EnvelopeFieldsModel(K2BaseModel):
    declared: dict[str, Any] | None = None
    inferred: dict[str, Any] | None = None


class EnvelopeMetadataModel(K2BaseModel):
    declared: dict[str, Any] | None = None
    inferred: dict[str, Any] | None = None
    provenance: ProvenanceModel | None = None


class AgentRunEnvelopeModel(K2BaseModel):
    content: str | None = None
    fields: EnvelopeFieldsModel | None = None
    metadata: EnvelopeMetadataModel | None = None


class AgentRunResponseModel(K2BaseModel):
    job_id: str
    status: str


class AgentRunListItemModel(K2BaseModel):
    job_id: str | None = None
    status: str | None = None
    created_at: str | None = None
    completed_at: str | None = None
    result: dict[str, Any] | None = None
    error_message: str | None = None


class AgentRunListResponseModel(K2BaseModel):
    runs: list[AgentRunListItemModel]
    total: int


class SubscriptionResponseModel(K2BaseModel):
    id: str | None = None
    agent_id: str | None = None
    feed_id: str | None = None
    feed_name: str | None = None
    feed_activation_status: str | None = None
    role: str | None = None
    match_spec: dict[str, Any] | None = None
    match_spec_description: str | None = None
    created_at: str | None = None


class SubscriptionListResponseModel(K2BaseModel):
    subscriptions: list[SubscriptionResponseModel]
