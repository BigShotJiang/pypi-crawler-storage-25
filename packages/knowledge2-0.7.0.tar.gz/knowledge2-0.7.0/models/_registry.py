"""Registry mapping TypedDict names to Pydantic model classes."""

from __future__ import annotations

import threading
from typing import Any

_REGISTRY: dict[str, type] | None = None
_REGISTRY_LOCK = threading.Lock()


def _build_registry() -> dict[str, type]:
    """Build the TypedDict-name -> PydanticModel mapping."""
    from sdk.models.a2a import (
        A2AAgentAuthenticationModel,
        A2AAgentCapabilitiesModel,
        A2AAgentCardResponseModel,
        A2AAgentProviderModel,
        A2AAgentSkillModel,
        A2AArtifactModel,
        A2ADataPartModel,
        A2AJsonRpcErrorModel,
        A2AJsonRpcResponseModel,
        A2ATaskResponseModel,
        A2ATaskStatusModel,
        A2ATextPartModel,
    )
    from sdk.models.agents import (
        AgentChatResponseModel,
        AgentListResponseModel,
        AgentModelInfoModel,
        AgentModelsResponseModel,
        AgentResponseModel,
        AgentRunEnvelopeModel,
        AgentRunListItemModel,
        AgentRunListResponseModel,
        AgentRunResponseModel,
        AgentTaskTypesResponseModel,
        EnvelopeFieldsModel,
        EnvelopeMetadataModel,
        ProvenanceModel,
        SourceAgentInfoModel,
        SubscriptionListResponseModel,
        SubscriptionResponseModel,
        TaskTypeInfoModel,
        ToolConfigResponseModel,
    )
    from sdk.models.audit import (
        AuditLogActionsResponseModel,
        AuditLogItemModel,
        AuditLogListResponseModel,
    )
    from sdk.models.auth import (
        ApiKeyCreateResponseModel,
        ApiKeyListItemModel,
        ApiKeyListResponseModel,
        ApiKeyRevokeResponseModel,
        ApiKeyRotateResponseModel,
        WhoAmIResponseModel,
    )
    from sdk.models.chunks import (
        ChunkListItemModel,
        ChunkListResponseModel,
    )
    from sdk.models.common import (
        ApiErrorDetailModel,
    )
    from sdk.models.console import (
        ConsoleBootstrapResponseModel,
        ConsoleMeResponseModel,
        ConsoleOrgResponseModel,
        ConsoleProjectItemModel,
        ConsoleProjectListResponseModel,
        ConsoleSummaryResponseModel,
        InviteAcceptResponseModel,
        InviteCreateResponseModel,
        InviteListItemModel,
        InviteListResponseModel,
        MemberRemoveResponseModel,
        MemberUpdateResponseModel,
        TeamListResponseModel,
        TeamMemberModel,
    )
    from sdk.models.corpora import (
        CorpusDeleteResponseModel,
        CorpusListResponseModel,
        CorpusResponseModel,
        CorpusStatusResponseModel,
    )
    from sdk.models.documents import (
        BatchItemErrorModel,
        ChunkingConfigModel,
        DocumentBatchEnqueueResponseModel,
        DocumentBatchItemModel,
        DocumentBatchStatusResponseModel,
        DocumentBatchUploadResponseModel,
        DocumentCreateResponseModel,
        DocumentDeleteResponseModel,
        DocumentDetailResponseModel,
        DocumentListItemModel,
        DocumentListResponseModel,
        DocumentManifestIngestResponseModel,
        DocumentUploadCapabilitiesResponseModel,
        DocumentUploadFormatModel,
        DocumentUrlIngestResponseModel,
        DocumentUrlItemModel,
    )
    from sdk.models.embeddings import (
        EmbeddingItemModel,
        EmbeddingModelInfoModel,
        EmbeddingModelListResponseModel,
        EmbeddingsResponseModel,
    )
    from sdk.models.feedback import (
        FeedbackResponseModel,
    )
    from sdk.models.feeds import (
        FeedFeedbackStatsResponseModel,
        FeedFeedbackSubmitResponseModel,
        FeedListResponseModel,
        FeedResponseModel,
        FeedRunResponseModel,
        FeedSubscriptionResponseModel,
    )
    from sdk.models.generation_models import (
        GenerationModelItemModel,
        GenerationModelsListResponseModel,
    )
    from sdk.models.indexes import (
        IndexBuildResponseModel,
        IndexCompactResponseModel,
        IndexOptimizeResponseModel,
        IndexStatusResponseModel,
    )
    from sdk.models.jobs import (
        JobActionsModel,
        JobListItemModel,
        JobListResponseModel,
        JobResponseModel,
        JobStatusResponseModel,
        ReconcileJobsResponseModel,
    )
    from sdk.models.onboarding import (
        DatasetAnalysisDetailsModel,
        DatasetAnalysisRequestModel,
        DatasetAnalysisResponseModel,
        DatasetAnalysisSummaryModel,
        DocumentSummaryResponseModel,
        EvaluationDetailsModel,
        EvaluationListResponseModel,
        EvaluationMetricsModel,
        EvaluationReportResponseModel,
        EvaluationRequestModel,
        EvaluationResponseModel,
        EvaluationSummaryModel,
        GoldLabelChunkReferenceModel,
        GoldLabelDocumentReferenceModel,
        GoldLabelEntryModel,
        GoldLabelListItemModel,
        GoldLabelsListResponseModel,
        GoldLabelsUploadRequestModel,
        GoldLabelsUploadResponseModel,
        LexicalStrategyModel,
        OnboardingStatusResponseModel,
        QueryProfileResponseModel,
        ResolvedLabelInfoModel,
        SearcherPersonaModel,
        SummarizationRequestModel,
        SummarizationResponseModel,
        SummarizationStatusResponseModel,
        SyntheticQueryBatchDetailsModel,
        SyntheticQueryBatchListResponseModel,
        SyntheticQueryBatchResponseModel,
        SyntheticQueryBatchSummaryModel,
        SyntheticQueryGenerationRequestModel,
        SyntheticQuerySampleModel,
    )
    from sdk.models.orgs import (
        OrgResponseModel,
    )
    from sdk.models.pipelines import (
        ApplyResultModel,
        ArchiveResultModel,
        DraftActivateResultModel,
        DriftReportModel,
        DriftSummaryModel,
        DryRunResultModel,
        EntityDiffModel,
        FieldDiffModel,
        GraphEdgeModel,
        GraphNodeModel,
        GraphResponseModel,
        PipelineSpecListResponseModel,
        PipelineSpecResponseModel,
        RefreshChangesModel,
        RefreshResultModel,
        SkippedEntityModel,
        ValidationIssueModel,
    )
    from sdk.models.projects import (
        ProjectArchiveResultModel,
        ProjectDeleteResponseModel,
        ProjectDeletionConfirmationModel,
        ProjectDeletionRequestModel,
        ProjectListResponseModel,
        ProjectResponseModel,
        ProjectRestoreResultModel,
    )
    from sdk.models.search import (
        MetadataFilterModel,
        MetadataFiltersModel,
        SearchBatchOptionsModel,
        SearchBatchResponseModel,
        SearchColdStartMetaModel,
        SearchGenerateOptionsModel,
        SearchGenerateResponseModel,
        SearchGenerationConfigModel,
        SearchHybridConfigModel,
        SearchMetaModel,
        SearchOptionsModel,
        SearchRerankConfigModel,
        SearchResponseModel,
        SearchResultModel,
        SearchReturnConfigModel,
    )
    from sdk.models.usage import (
        UsageByCorpusItemModel,
        UsageByCorpusResponseModel,
        UsageByKeyItemModel,
        UsageByKeyResponseModel,
        UsageSeriesPointModel,
        UsageSummaryResponseModel,
    )

    return {
        # a2a
        "A2ATextPart": A2ATextPartModel,
        "A2ADataPart": A2ADataPartModel,
        "A2AArtifact": A2AArtifactModel,
        "A2ATaskStatus": A2ATaskStatusModel,
        "A2ATaskResponse": A2ATaskResponseModel,
        "A2AJsonRpcError": A2AJsonRpcErrorModel,
        "A2AJsonRpcResponse": A2AJsonRpcResponseModel,
        "A2AAgentSkill": A2AAgentSkillModel,
        "A2AAgentCapabilities": A2AAgentCapabilitiesModel,
        "A2AAgentProvider": A2AAgentProviderModel,
        "A2AAgentAuthentication": A2AAgentAuthenticationModel,
        "A2AAgentCardResponse": A2AAgentCardResponseModel,
        # agents
        "SourceAgentInfo": SourceAgentInfoModel,
        "ToolConfigResponse": ToolConfigResponseModel,
        "AgentResponse": AgentResponseModel,
        "AgentListResponse": AgentListResponseModel,
        "AgentChatResponse": AgentChatResponseModel,
        "AgentModelInfo": AgentModelInfoModel,
        "AgentModelsResponse": AgentModelsResponseModel,
        "TaskTypeInfo": TaskTypeInfoModel,
        "AgentTaskTypesResponse": AgentTaskTypesResponseModel,
        "AgentRunResponse": AgentRunResponseModel,
        "AgentRunEnvelope": AgentRunEnvelopeModel,
        "EnvelopeFields": EnvelopeFieldsModel,
        "EnvelopeMetadata": EnvelopeMetadataModel,
        "Provenance": ProvenanceModel,
        "AgentRunListItem": AgentRunListItemModel,
        "AgentRunListResponse": AgentRunListResponseModel,
        "SubscriptionResponse": SubscriptionResponseModel,
        "SubscriptionListResponse": SubscriptionListResponseModel,
        # audit
        "AuditLogItem": AuditLogItemModel,
        "AuditLogListResponse": AuditLogListResponseModel,
        "AuditLogActionsResponse": AuditLogActionsResponseModel,
        # auth
        "ApiKeyCreateResponse": ApiKeyCreateResponseModel,
        "ApiKeyRotateResponse": ApiKeyRotateResponseModel,
        "ApiKeyRevokeResponse": ApiKeyRevokeResponseModel,
        "ApiKeyListItem": ApiKeyListItemModel,
        "ApiKeyListResponse": ApiKeyListResponseModel,
        "WhoAmIResponse": WhoAmIResponseModel,
        # chunks
        "ChunkListItem": ChunkListItemModel,
        "ChunkListResponse": ChunkListResponseModel,
        # common
        "ApiErrorDetail": ApiErrorDetailModel,
        # console
        "ConsoleMeResponse": ConsoleMeResponseModel,
        "ConsoleBootstrapResponse": ConsoleBootstrapResponseModel,
        "ConsoleSummaryResponse": ConsoleSummaryResponseModel,
        "ConsoleProjectItem": ConsoleProjectItemModel,
        "ConsoleProjectListResponse": ConsoleProjectListResponseModel,
        "ConsoleOrgResponse": ConsoleOrgResponseModel,
        "TeamMember": TeamMemberModel,
        "TeamListResponse": TeamListResponseModel,
        "InviteListItem": InviteListItemModel,
        "InviteListResponse": InviteListResponseModel,
        "InviteCreateResponse": InviteCreateResponseModel,
        "InviteAcceptResponse": InviteAcceptResponseModel,
        "MemberUpdateResponse": MemberUpdateResponseModel,
        "MemberRemoveResponse": MemberRemoveResponseModel,
        # corpora
        "CorpusResponse": CorpusResponseModel,
        "CorpusListResponse": CorpusListResponseModel,
        "CorpusDeleteResponse": CorpusDeleteResponseModel,
        "CorpusStatusResponse": CorpusStatusResponseModel,
        # documents
        "BatchItemError": BatchItemErrorModel,
        "ChunkingConfig": ChunkingConfigModel,
        "DocumentCreateResponse": DocumentCreateResponseModel,
        "DocumentBatchEnqueueResponse": DocumentBatchEnqueueResponseModel,
        "DocumentBatchItem": DocumentBatchItemModel,
        "DocumentBatchStatusResponse": DocumentBatchStatusResponseModel,
        "DocumentUrlItem": DocumentUrlItemModel,
        "DocumentUrlIngestResponse": DocumentUrlIngestResponseModel,
        "DocumentManifestIngestResponse": DocumentManifestIngestResponseModel,
        "DocumentListItem": DocumentListItemModel,
        "DocumentListResponse": DocumentListResponseModel,
        "DocumentDetailResponse": DocumentDetailResponseModel,
        "DocumentDeleteResponse": DocumentDeleteResponseModel,
        "DocumentBatchUploadResponse": DocumentBatchUploadResponseModel,
        "DocumentUploadFormat": DocumentUploadFormatModel,
        "DocumentUploadCapabilitiesResponse": DocumentUploadCapabilitiesResponseModel,
        # embeddings
        "EmbeddingItem": EmbeddingItemModel,
        "EmbeddingModelInfo": EmbeddingModelInfoModel,
        "EmbeddingModelListResponse": EmbeddingModelListResponseModel,
        "EmbeddingsResponse": EmbeddingsResponseModel,
        # feedback
        "FeedbackResponse": FeedbackResponseModel,
        # feeds
        "FeedSubscriptionResponse": FeedSubscriptionResponseModel,
        "FeedResponse": FeedResponseModel,
        "FeedListResponse": FeedListResponseModel,
        "FeedRunResponse": FeedRunResponseModel,
        "FeedFeedbackSubmitResponse": FeedFeedbackSubmitResponseModel,
        "FeedFeedbackStatsResponse": FeedFeedbackStatsResponseModel,
        # generation_models
        "GenerationModelItem": GenerationModelItemModel,
        "GenerationModelsListResponse": GenerationModelsListResponseModel,
        # indexes
        "IndexBuildResponse": IndexBuildResponseModel,
        "IndexStatusResponse": IndexStatusResponseModel,
        "IndexCompactResponse": IndexCompactResponseModel,
        "IndexOptimizeResponse": IndexOptimizeResponseModel,
        # jobs
        "JobActions": JobActionsModel,
        "JobResponse": JobResponseModel,
        "JobListItem": JobListItemModel,
        "JobListResponse": JobListResponseModel,
        "JobStatusResponse": JobStatusResponseModel,
        "ReconcileJobsResponse": ReconcileJobsResponseModel,
        # onboarding
        "GoldLabelDocumentReference": GoldLabelDocumentReferenceModel,
        "GoldLabelChunkReference": GoldLabelChunkReferenceModel,
        "GoldLabelEntry": GoldLabelEntryModel,
        "GoldLabelsUploadRequest": GoldLabelsUploadRequestModel,
        "ResolvedLabelInfo": ResolvedLabelInfoModel,
        "GoldLabelsUploadResponse": GoldLabelsUploadResponseModel,
        "GoldLabelListItem": GoldLabelListItemModel,
        "GoldLabelsListResponse": GoldLabelsListResponseModel,
        "DatasetAnalysisRequest": DatasetAnalysisRequestModel,
        "DatasetAnalysisResponse": DatasetAnalysisResponseModel,
        "DatasetAnalysisSummary": DatasetAnalysisSummaryModel,
        "OnboardingStatusResponse": OnboardingStatusResponseModel,
        "QueryProfileResponse": QueryProfileResponseModel,
        "SearcherPersona": SearcherPersonaModel,
        "LexicalStrategy": LexicalStrategyModel,
        "DatasetAnalysisDetails": DatasetAnalysisDetailsModel,
        "SyntheticQueryGenerationRequest": SyntheticQueryGenerationRequestModel,
        "SyntheticQueryBatchResponse": SyntheticQueryBatchResponseModel,
        "SyntheticQueryBatchSummary": SyntheticQueryBatchSummaryModel,
        "SyntheticQueryBatchListResponse": SyntheticQueryBatchListResponseModel,
        "SyntheticQuerySample": SyntheticQuerySampleModel,
        "SyntheticQueryBatchDetails": SyntheticQueryBatchDetailsModel,
        "EvaluationRequest": EvaluationRequestModel,
        "EvaluationResponse": EvaluationResponseModel,
        "EvaluationMetrics": EvaluationMetricsModel,
        "EvaluationSummary": EvaluationSummaryModel,
        "EvaluationListResponse": EvaluationListResponseModel,
        "EvaluationDetails": EvaluationDetailsModel,
        "EvaluationReportResponse": EvaluationReportResponseModel,
        "SummarizationRequest": SummarizationRequestModel,
        "SummarizationResponse": SummarizationResponseModel,
        "SummarizationStatusResponse": SummarizationStatusResponseModel,
        "DocumentSummaryResponse": DocumentSummaryResponseModel,
        # orgs
        "OrgResponse": OrgResponseModel,
        # pipelines
        "ValidationIssue": ValidationIssueModel,
        "PipelineSpecResponse": PipelineSpecResponseModel,
        "PipelineSpecListResponse": PipelineSpecListResponseModel,
        "DryRunResult": DryRunResultModel,
        "ApplyResult": ApplyResultModel,
        "SkippedEntity": SkippedEntityModel,
        "ArchiveResult": ArchiveResultModel,
        "DraftActivateResult": DraftActivateResultModel,
        "FieldDiff": FieldDiffModel,
        "EntityDiff": EntityDiffModel,
        "DriftSummary": DriftSummaryModel,
        "DriftReport": DriftReportModel,
        "RefreshChanges": RefreshChangesModel,
        "RefreshResult": RefreshResultModel,
        "GraphNode": GraphNodeModel,
        "GraphEdge": GraphEdgeModel,
        "GraphResponse": GraphResponseModel,
        # projects
        "ProjectResponse": ProjectResponseModel,
        "ProjectDeleteResponse": ProjectDeleteResponseModel,
        "ProjectListResponse": ProjectListResponseModel,
        "ProjectArchiveResult": ProjectArchiveResultModel,
        "ProjectRestoreResult": ProjectRestoreResultModel,
        "ProjectDeletionRequest": ProjectDeletionRequestModel,
        "ProjectDeletionConfirmation": ProjectDeletionConfirmationModel,
        # search
        "SearchHybridConfig": SearchHybridConfigModel,
        "SearchRerankConfig": SearchRerankConfigModel,
        "SearchReturnConfig": SearchReturnConfigModel,
        "MetadataFilter": MetadataFilterModel,
        "MetadataFilters": MetadataFiltersModel,
        "SearchGenerationConfig": SearchGenerationConfigModel,
        "SearchOptions": SearchOptionsModel,
        "SearchGenerateOptions": SearchGenerateOptionsModel,
        "SearchBatchOptions": SearchBatchOptionsModel,
        "SearchResult": SearchResultModel,
        "SearchColdStartMeta": SearchColdStartMetaModel,
        "SearchMeta": SearchMetaModel,
        "SearchResponse": SearchResponseModel,
        "SearchBatchResponse": SearchBatchResponseModel,
        "SearchGenerateResponse": SearchGenerateResponseModel,
        # usage
        "UsageSeriesPoint": UsageSeriesPointModel,
        "UsageSummaryResponse": UsageSummaryResponseModel,
        "UsageByCorpusItem": UsageByCorpusItemModel,
        "UsageByCorpusResponse": UsageByCorpusResponseModel,
        "UsageByKeyItem": UsageByKeyItemModel,
        "UsageByKeyResponse": UsageByKeyResponseModel,
    }


def get_model_for_type(type_name: str) -> type | None:
    """Look up the Pydantic model class for a given TypedDict name.

    Args:
        type_name: The TypedDict class name (e.g. "SearchResponse").

    Returns:
        The corresponding Pydantic model class, or None if not found.
    """
    global _REGISTRY
    if _REGISTRY is None:
        with _REGISTRY_LOCK:
            if _REGISTRY is None:
                _REGISTRY = _build_registry()
    return _REGISTRY.get(type_name)
