"""Pydantic response models for the Knowledge2 SDK."""

from __future__ import annotations


def __getattr__(name: str):
    """Provide a helpful error when importing model classes without pydantic."""
    try:
        import pydantic
    except ImportError:
        raise ImportError(
            f"Cannot import '{name}' — Pydantic response models require the base "
            "'knowledge2' package to include 'pydantic'. Reinstall or upgrade "
            "'knowledge2'."
        ) from None
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
