"""Pydantic models for feed types."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from sdk.models._base import K2BaseModel


class FeedSubscriptionResponseModel(K2BaseModel):
    # `agent_id` and `role` are required server-side (api/app/schemas/feeds.py);
    # keep them non-Optional so validated clients catch a malformed payload.
    # Other fields (id, agent_name, match_spec*) are genuinely optional or
    # only populated for specific subscription modes.
    id: str | None = None
    agent_id: str
    agent_name: str | None = None
    role: str
    match_spec: dict[str, Any] | None = None
    match_spec_description: str | None = None


class FeedResponseModel(K2BaseModel):
    id: str | None = None
    project_id: str | None = None
    source_agent_id: str | None = None
    name: str | None = None
    execution_mode: str | None = None
    persistent: bool | None = None
    reactive: bool | None = None
    target_corpus_id: str | None = None
    schedule_interval: str | None = None
    schedule_hour: int | None = None
    start_from: str | None = None
    activation_status: str | None = None
    last_checked_seq: int | None = None
    last_run_at: str | None = None
    last_run_result_count: int | None = None
    # Server always returns a list (empty by default); no None path. Using
    # default_factory rather than a bare `[]` default avoids RUF012 (mutable
    # class attribute) while keeping validated clients free of None-checks.
    subscriptions: list[FeedSubscriptionResponseModel] = Field(default_factory=list)
    parent_feed_id: str | None = None
    has_draft: bool | None = None
    created_at: str | None = None
    updated_at: str | None = None


class FeedListResponseModel(K2BaseModel):
    feeds: list[FeedResponseModel]
    total: int
    limit: int
    offset: int


class FeedRunResponseModel(K2BaseModel):
    new_content: bool | None = None
    results: list[dict[str, Any]] | None = None
    result_count: int | None = None
    truncated: bool | None = None
    ingestion_job_id: str | None = None
    dry_run: bool | None = None
    would_ingest_count: int | None = None
    feed_run_id: str | None = None


class FeedFeedbackSubmitResponseModel(K2BaseModel):
    # Server guarantees both fields: `message` has a default of "ok" and
    # `feedback_id` is the created record's id. Keep them required so
    # ``Knowledge2Validated`` actually catches malformed 201 responses.
    message: str
    feedback_id: str


class FeedFeedbackStatsResponseModel(K2BaseModel):
    # Server guarantees all four fields (counters default to 0). Required
    # so validated clients catch a missing-field regression.
    feed_id: str
    total: int
    positive: int
    negative: int
