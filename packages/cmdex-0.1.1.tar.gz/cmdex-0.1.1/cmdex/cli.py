import click
from cmdex.explainer import explain_command
from rich import print
from importlib.metadata import version, PackageNotFoundError

def get_version():
    try:
        return version("cmdex")
    except PackageNotFoundError:
        return "0.0.0"  # fallback if not installed

@click.group()
@click.version_option(version=get_version(), prog_name="cmdex")
def cli():
    """Cmdex: Your Terminal Command Explainer"""
    pass

@cli.command(name="explain")
@click.argument("command_string")
def explain_cmd(command_string):
    panel = explain_command(command_string)
    print(panel)

# aliases
cli.add_command(explain_cmd, name="why")
cli.add_command(explain_cmd, name="xplain")

if __name__ == "__main__":
    cli()