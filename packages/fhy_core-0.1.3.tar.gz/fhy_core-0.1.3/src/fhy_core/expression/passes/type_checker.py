"""Bidirectional type checking and inference for expressions.

:func:`synthesize_expression_type` infers a type purely from the leaves of
an expression; :func:`check_expression_type` propagates an expected type
into the expression so weak literals can adopt the surrounding context,
then verifies the synthesized result is assignment-compatible with the
expected type. Both entry points return ``(Type, TypeQualifier)``.

This module raises :class:`FhYCoreTypeError` for type-rule violations and
:class:`NotImplementedError` for expression shapes / operations that are
not yet supported (boolean / string literals, boolean-result operations,
tensor operands, unknown ``UnaryOperation`` / ``Expression`` subclasses).

:class:`FhYCoreTypeError` instances raised through
:meth:`_TypeCheckContext.type_error` carry a context-framed message of one
of two shapes:

- "Type error while inferring type of `<root>`: <reason>"
- "Type error while inferring type of `<root>` at sub-expression `<sub>`:
  <reason>"

where ``<root>`` is the outermost expression on the context stack,
``<sub>`` is the sub-expression where the failure surfaced, and
``<reason>`` describes the specific rule that was violated along with the
types and values involved. The framing is provided by
:class:`_TypeCheckContext`, which the checker pushes / pops as it recurses.

A small number of module-level helpers (``_get_primitive_data_type``,
``_get_numeric_literal_value``, ``_get_real_float_core_data_type_for_bit_width``)
raise bare :class:`FhYCoreTypeError` instances without that framing - they
have no access to a context, and the checker does not catch and reframe
them, so callers can see either form on a failed type check.
"""

__all__ = [
    "get_core_data_type_from_literal_type",
    "synthesize_expression_type",
    "check_expression_type",
]

from contextlib import contextmanager
from typing import Callable, Iterator, TypeAlias

from fhy_core.expression.core import (
    BinaryExpression,
    BinaryOperation,
    Expression,
    IdentifierExpression,
    LiteralExpression,
    LiteralType,
    UnaryExpression,
    UnaryOperation,
)
from fhy_core.expression.pprint import pformat_expression
from fhy_core.identifier import Identifier
from fhy_core.pass_infrastructure import (
    PassExecutionError,
    VisitablePass,
    register_pass,
)
from fhy_core.types import (
    CoreDataType,
    FhYCoreTypeError,
    IndexType,
    NumericalType,
    PrimitiveDataType,
    Type,
    TypeQualifier,
    get_core_data_type_bit_width,
    is_weak_core_data_type,
    promote_core_data_types,
    promote_primitive_data_types,
    promote_type_qualifiers,
    resolve_literal_core_data_type,
)
from fhy_core.utils import Stack, is_strict_int

ExpressionValueType: TypeAlias = NumericalType | IndexType

_ARITHMETIC_OPERATIONS = frozenset(
    {
        BinaryOperation.ADD,
        BinaryOperation.SUBTRACT,
        BinaryOperation.MULTIPLY,
        BinaryOperation.DIVIDE,
        BinaryOperation.FLOOR_DIVIDE,
        BinaryOperation.MODULO,
        BinaryOperation.POWER,
    }
)

_UNSIGNED_CORE_DATA_TYPES = frozenset(
    {
        CoreDataType.UINT,
        CoreDataType.UINT8,
        CoreDataType.UINT16,
        CoreDataType.UINT32,
    }
)

_SIGNED_CORE_DATA_TYPES = frozenset(
    {
        CoreDataType.INT,
        CoreDataType.INT8,
        CoreDataType.INT16,
        CoreDataType.INT32,
        CoreDataType.INT64,
    }
)

_INTEGRAL_CORE_DATA_TYPES = _UNSIGNED_CORE_DATA_TYPES | _SIGNED_CORE_DATA_TYPES

_REAL_FLOAT_CORE_DATA_TYPES = frozenset(
    {
        CoreDataType.FLOAT,
        CoreDataType.FLOAT16,
        CoreDataType.FLOAT32,
        CoreDataType.FLOAT64,
    }
)

_COMPLEX_CORE_DATA_TYPES = frozenset(
    {
        CoreDataType.COMPLEX32,
        CoreDataType.COMPLEX64,
        CoreDataType.COMPLEX128,
    }
)

_FLOAT_LIKE_CORE_DATA_TYPES = _REAL_FLOAT_CORE_DATA_TYPES | _COMPLEX_CORE_DATA_TYPES


def _build_real_float_core_data_types_by_bit_width() -> tuple[
    tuple[int, CoreDataType], ...
]:
    entries: list[tuple[int, CoreDataType]] = []
    for core_data_type in _REAL_FLOAT_CORE_DATA_TYPES:
        bit_width = get_core_data_type_bit_width(core_data_type)
        if bit_width is not None:
            entries.append((bit_width, core_data_type))
    return tuple(sorted(entries))


_REAL_FLOAT_CORE_DATA_TYPES_BY_BIT_WIDTH = (
    _build_real_float_core_data_types_by_bit_width()
)


def get_core_data_type_from_literal_type(literal: LiteralType) -> CoreDataType:
    """Return the weak core data type assigned to a literal.

    Only numeric literals (``int`` and ``float``) participate in the type
    system; ``bool`` and ``str`` values are accepted by
    :class:`~fhy_core.expression.core.LiteralExpression` for other purposes
    (e.g. serialization round-trips) but have no numeric core data type and
    are rejected here with :class:`NotImplementedError`. Callers that may
    receive non-numeric literals should either filter them earlier or catch
    ``NotImplementedError`` explicitly.

    Raises:
        NotImplementedError: If ``literal`` is a ``bool`` or ``str``.
        ValueError: If ``literal`` is none of the supported literal types.

    """
    match literal:
        case bool():
            raise NotImplementedError("Boolean literals are not yet supported.")
        case int() if literal >= 0:
            return CoreDataType.UINT
        case int() if literal < 0:
            return CoreDataType.INT
        case float():
            return CoreDataType.FLOAT
        case str():
            raise NotImplementedError("String literals are not yet supported.")
        case _:
            raise ValueError(f"Unsupported literal type: {type(literal)}.")


def _format_expression(expression: Expression) -> str:
    """Format an expression for inclusion in error messages."""
    return pformat_expression(expression, show_id=True)


def _is_weak_numerical_type(numerical_type: NumericalType) -> bool:
    return is_weak_core_data_type(
        _get_primitive_data_type(numerical_type).core_data_type
    )


def _get_primitive_data_type(numerical_type: NumericalType) -> PrimitiveDataType:
    data_type = numerical_type.data_type
    if not isinstance(data_type, PrimitiveDataType):
        raise FhYCoreTypeError(f"expected a primitive data type, got {data_type}")
    return data_type


def _get_numeric_literal_value(literal_expression: LiteralExpression) -> int | float:
    literal_value = literal_expression.value
    if isinstance(literal_value, bool | str):
        raise FhYCoreTypeError(
            f"expected a numeric literal value, got {literal_value!r}"
        )
    return literal_value


def _is_integral_numerical_type(numerical_type: NumericalType) -> bool:
    return (
        _get_primitive_data_type(numerical_type).core_data_type
        in _INTEGRAL_CORE_DATA_TYPES
    )


def _get_real_float_core_data_type_for_bit_width(bit_width: int | None) -> CoreDataType:
    if bit_width is None:
        return CoreDataType.FLOAT
    for candidate_bit_width, candidate in _REAL_FLOAT_CORE_DATA_TYPES_BY_BIT_WIDTH:
        if candidate_bit_width >= bit_width:
            return candidate
    raise FhYCoreTypeError(
        f"no real float core data type found for bit width {bit_width}"
    )


def _lift_integral_against_float_like(
    left_core_data_type: CoreDataType, right_core_data_type: CoreDataType
) -> tuple[CoreDataType, CoreDataType]:
    """Promote whichever side is integral to a real-float of matching bit width.

    Used by both true and floor division to align an integer operand with a
    float-like operand before falling through to ``promote_core_data_types``.
    Floor division rejects complex operands upstream, so the float-like check
    reduces to a real-float check there; true division relies on the lift to
    bridge the integer / complex lattice gap.
    """
    if (
        left_core_data_type in _INTEGRAL_CORE_DATA_TYPES
        and right_core_data_type in _FLOAT_LIKE_CORE_DATA_TYPES
    ):
        left_core_data_type = _get_real_float_core_data_type_for_bit_width(
            get_core_data_type_bit_width(left_core_data_type)
        )
    elif (
        left_core_data_type in _FLOAT_LIKE_CORE_DATA_TYPES
        and right_core_data_type in _INTEGRAL_CORE_DATA_TYPES
    ):
        right_core_data_type = _get_real_float_core_data_type_for_bit_width(
            get_core_data_type_bit_width(right_core_data_type)
        )
    return left_core_data_type, right_core_data_type


class _TypeCheckContext:
    """Tracks the enclosing expression trace for context-rich error messages.

    The checker's public entry points (``synthesize``, ``check``) and each
    recursive ``_infer*`` call enter a new scope via :meth:`entering`, which
    pushes the expression being processed onto a stack. When an error is
    raised via :meth:`type_error`, the message includes the root expression
    (the first one pushed) and, when different, the current sub-expression
    (the most recently pushed one still live).

    The reason string passed to :meth:`type_error` should describe *what*
    went wrong without re-stating the expression itself; the context layer
    is responsible for that framing.
    """

    _stack: Stack[Expression]

    def __init__(self) -> None:
        self._stack = Stack[Expression]()

    @contextmanager
    def entering(self, expression: Expression) -> Iterator[None]:
        """Push ``expression`` onto the trace for the duration of the ``with`` block."""
        self._stack.push(expression)
        try:
            yield
        finally:
            self._stack.pop()

    def type_error(self, reason: str) -> FhYCoreTypeError:
        """Build a :class:`FhYCoreTypeError` framed by the current context trace."""
        if not self._stack:
            return FhYCoreTypeError(f"Type error: {reason}")
        stack_elements = tuple(self._stack)
        root = stack_elements[0]
        current = stack_elements[-1]
        root_text = _format_expression(root)
        if current is root:
            return FhYCoreTypeError(
                f"Type error while inferring type of `{root_text}`: {reason}"
            )
        current_text = _format_expression(current)
        return FhYCoreTypeError(
            f"Type error while inferring type of `{root_text}` "
            f"at sub-expression `{current_text}`: {reason}"
        )


@register_pass(
    "fhy_core.expression.type_checker",
    "Bidirectionally synthesize and check expression types.",
)
class ExpressionTypeChecker(VisitablePass[Expression, tuple[Type, TypeQualifier]]):
    """Bidirectional type checker for expressions."""

    _get_identifier_type: Callable[[Identifier], tuple[Type, TypeQualifier]]
    _context: _TypeCheckContext

    def __init__(
        self, get_identifier_type: Callable[[Identifier], tuple[Type, TypeQualifier]]
    ) -> None:
        super().__init__()
        self._get_identifier_type = get_identifier_type
        self._context = _TypeCheckContext()

    def synthesize(self, expression: Expression) -> tuple[Type, TypeQualifier]:
        """Synthesize a type for an expression."""
        return self._infer(expression)

    def check(
        self, expression: Expression, expected_type: Type
    ) -> tuple[Type, TypeQualifier]:
        """Check an expression against an expected type."""
        actual_type, actual_qualifier = self._infer(expression, expected_type)
        # `_infer` unwinds any `entering` scopes it opens before returning.
        # Re-enter `expression` here so `_check_expected_type` is framed
        # correctly whether `check` is called at top level or from within an
        # existing outer context (e.g. the late weak-literal rescue).
        with self._context.entering(expression):
            self._check_expected_type(expression, actual_type, expected_type)
        return actual_type, actual_qualifier

    # --- Visitor dispatch ----------------------------------------------------

    def visit_unary_expression(
        self, unary_expression: UnaryExpression
    ) -> tuple[Type, TypeQualifier]:
        return self._infer_unary_expression(unary_expression)

    def visit_binary_expression(
        self, binary_expression: BinaryExpression
    ) -> tuple[Type, TypeQualifier]:
        return self._infer_binary_expression(binary_expression)

    def visit_identifier_expression(
        self, identifier_expression: IdentifierExpression
    ) -> tuple[Type, TypeQualifier]:
        with self._context.entering(identifier_expression):
            identifier_type, identifier_qualifier = self._get_identifier_type(
                identifier_expression.identifier
            )
            if identifier_qualifier == TypeQualifier.OUTPUT:
                raise self._context.type_error(
                    f"identifier `{_format_expression(identifier_expression)}` has "
                    'type qualifier "output" and cannot be read from'
                )
            return (
                self._as_expression_value_type(identifier_expression, identifier_type),
                identifier_qualifier,
            )

    def visit_literal_expression(
        self, literal_expression: LiteralExpression
    ) -> tuple[Type, TypeQualifier]:
        return (
            NumericalType(
                PrimitiveDataType(
                    get_core_data_type_from_literal_type(literal_expression.value)
                )
            ),
            TypeQualifier.PARAM,
        )

    def get_noop_output(self, ir: Expression) -> tuple[Type, TypeQualifier]:
        raise PassExecutionError(
            f'Pass "{self.get_pass_name()}" does not define noop output for {ir!r}.'
        )

    # --- Core inference ------------------------------------------------------

    def _infer(
        self, expression: Expression, expected_type: Type | None = None
    ) -> tuple[Type, TypeQualifier]:
        match expression:
            case UnaryExpression():
                return self._infer_unary_expression(expression, expected_type)
            case BinaryExpression():
                return self._infer_binary_expression(expression, expected_type)
            case IdentifierExpression():
                return self.visit_identifier_expression(expression)
            case LiteralExpression():
                return self._infer_literal_expression(expression, expected_type)
            case _:
                raise NotImplementedError(
                    f"Unsupported expression type: {type(expression)}"
                )

    def _infer_literal_expression(
        self,
        literal_expression: LiteralExpression,
        expected_type: Type | None = None,
    ) -> tuple[Type, TypeQualifier]:
        with self._context.entering(literal_expression):
            if expected_type is None:
                return self.visit_literal_expression(literal_expression)

            expected_value_type = self._as_expression_value_type(
                literal_expression, expected_type
            )
            if isinstance(expected_value_type, IndexType):
                raise self._context.type_error(
                    f"a literal value cannot be checked against index type "
                    f"{expected_type}"
                )

            resolved_core_data_type = resolve_literal_core_data_type(
                _get_numeric_literal_value(literal_expression),
                _get_primitive_data_type(expected_value_type).core_data_type,
            )
            return (
                NumericalType(PrimitiveDataType(resolved_core_data_type)),
                TypeQualifier.PARAM,
            )

    def _infer_unary_expression(
        self,
        unary_expression: UnaryExpression,
        expected_type: Type | None = None,
    ) -> tuple[Type, TypeQualifier]:
        with self._context.entering(unary_expression):
            operand_type, operand_qualifier = self._infer(
                unary_expression.operand, expected_type
            )

            operand_value_type = self._as_expression_value_type(
                unary_expression, operand_type
            )

            match unary_expression.operation:
                case UnaryOperation.POSITIVE:
                    return operand_value_type, operand_qualifier
                case UnaryOperation.NEGATE:
                    if isinstance(operand_value_type, IndexType):
                        raise self._context.type_error(
                            "unary negation is not defined for index types; the "
                            "resulting bounds and stride cannot be inferred safely"
                        )
                    if isinstance(
                        unary_expression.operand, LiteralExpression
                    ) and _is_weak_numerical_type(operand_value_type):
                        return (
                            NumericalType(
                                PrimitiveDataType(
                                    get_core_data_type_from_literal_type(
                                        -_get_numeric_literal_value(
                                            unary_expression.operand
                                        )
                                    )
                                )
                            ),
                            operand_qualifier,
                        )
                    return operand_value_type, operand_qualifier
                case UnaryOperation.LOGICAL_NOT:
                    raise NotImplementedError(
                        "Boolean result types are not yet supported."
                    )
                case _:
                    raise NotImplementedError(
                        f"unary operation {unary_expression.operation} is not supported"
                    )

    def _infer_binary_expression(
        self,
        binary_expression: BinaryExpression,
        expected_type: Type | None = None,
    ) -> tuple[Type, TypeQualifier]:
        with self._context.entering(binary_expression):
            operation = binary_expression.operation
            left_expected, right_expected = (
                self._propagate_expected_type_to_literal_operands(
                    binary_expression, expected_type
                )
            )

            left_type, left_qualifier = self._infer(
                binary_expression.left, left_expected
            )
            right_type, right_qualifier = self._infer(
                binary_expression.right, right_expected
            )

            left_value_type = self._as_expression_value_type(
                binary_expression.left, left_type
            )
            right_value_type = self._as_expression_value_type(
                binary_expression.right, right_type
            )

            left_value_type, left_qualifier = self._apply_late_weak_literal_rescue(
                binary_expression.left,
                left_value_type,
                left_qualifier,
                right_value_type,
                operation,
            )
            right_value_type, right_qualifier = self._apply_late_weak_literal_rescue(
                binary_expression.right,
                right_value_type,
                right_qualifier,
                left_value_type,
                operation,
            )

            if operation not in _ARITHMETIC_OPERATIONS:
                raise NotImplementedError("Boolean result types are not yet supported.")

            return self._dispatch_arithmetic_binary(
                binary_expression,
                operation,
                left_value_type,
                right_value_type,
                left_qualifier,
                right_qualifier,
            )

    @staticmethod
    def _propagate_expected_type_to_literal_operands(
        binary_expression: BinaryExpression, expected_type: Type | None
    ) -> tuple[Type | None, Type | None]:
        if not (
            binary_expression.operation in _ARITHMETIC_OPERATIONS
            and isinstance(expected_type, NumericalType)
            and expected_type.is_scalar()
        ):
            return None, None
        left_expected = (
            expected_type
            if isinstance(binary_expression.left, LiteralExpression)
            else None
        )
        right_expected = (
            expected_type
            if isinstance(binary_expression.right, LiteralExpression)
            else None
        )
        return left_expected, right_expected

    def _apply_late_weak_literal_rescue(
        self,
        operand_expression: Expression,
        operand_value_type: ExpressionValueType,
        operand_qualifier: TypeQualifier,
        other_value_type: ExpressionValueType,
        operation: BinaryOperation,
    ) -> tuple[ExpressionValueType, TypeQualifier]:
        if not (
            operation in _ARITHMETIC_OPERATIONS
            and isinstance(operand_expression, LiteralExpression)
            and isinstance(operand_value_type, NumericalType)
            and _is_weak_numerical_type(operand_value_type)
            and isinstance(other_value_type, NumericalType)
            and not _is_weak_numerical_type(other_value_type)
        ):
            return operand_value_type, operand_qualifier
        checked_type, operand_qualifier = self.check(
            operand_expression, other_value_type
        )
        operand_value_type = self._as_expression_value_type(
            operand_expression, checked_type
        )
        return operand_value_type, operand_qualifier

    def _dispatch_arithmetic_binary(
        self,
        binary_expression: BinaryExpression,
        operation: BinaryOperation,
        left_value_type: ExpressionValueType,
        right_value_type: ExpressionValueType,
        left_qualifier: TypeQualifier,
        right_qualifier: TypeQualifier,
    ) -> tuple[Type, TypeQualifier]:
        result_qualifier = promote_type_qualifiers(left_qualifier, right_qualifier)

        if isinstance(left_value_type, NumericalType) and isinstance(
            right_value_type, NumericalType
        ):
            return (
                self._infer_arithmetic_numerical_pair(
                    operation, left_value_type, right_value_type
                ),
                result_qualifier,
            )

        elif operation in {
            BinaryOperation.DIVIDE,
            BinaryOperation.FLOOR_DIVIDE,
        }:
            raise self._context.type_error(
                "division is not defined for operands of index type"
            )

        elif isinstance(left_value_type, IndexType) and isinstance(
            right_value_type, IndexType
        ):
            raise self._context.type_error(
                f"the {operation.name.lower()} operation between two index types "
                "is not supported; arithmetic on two strided ranges does not "
                "generally produce a result whose index bounds and stride can be "
                "inferred safely. Index types are valid as operands of shift "
                "(``index +/- int``) or scale (``index * positive int literal``)."
            )

        elif operation == BinaryOperation.ADD:
            return (
                self._infer_index_shift_add(
                    binary_expression, left_value_type, right_value_type
                ),
                result_qualifier,
            )
        elif (
            operation == BinaryOperation.SUBTRACT
            and isinstance(left_value_type, IndexType)
            and isinstance(right_value_type, NumericalType)
        ):
            return (
                self._infer_index_shift_subtract(
                    binary_expression, left_value_type, right_value_type
                ),
                result_qualifier,
            )
        elif operation == BinaryOperation.MULTIPLY:
            return (
                self._infer_index_scale(
                    binary_expression, left_value_type, right_value_type
                ),
                result_qualifier,
            )
        else:
            raise self._context.type_error(
                f"the {operation.name.lower()} operation is not defined for "
                f"operands of types {left_value_type} and {right_value_type}; "
                "the resulting index bounds and stride cannot be inferred safely"
            )

    def _infer_arithmetic_numerical_pair(
        self,
        operation: BinaryOperation,
        left_value_type: NumericalType,
        right_value_type: NumericalType,
    ) -> NumericalType:
        if operation == BinaryOperation.DIVIDE:
            return NumericalType(
                self._get_division_primitive_data_type(
                    left_value_type, right_value_type
                )
            )
        if operation == BinaryOperation.FLOOR_DIVIDE:
            return NumericalType(
                self._get_floor_division_primitive_data_type(
                    left_value_type, right_value_type
                )
            )
        return NumericalType(
            promote_primitive_data_types(
                _get_primitive_data_type(left_value_type),
                _get_primitive_data_type(right_value_type),
            )
        )

    def _infer_index_shift_add(
        self,
        binary_expression: BinaryExpression,
        left_value_type: ExpressionValueType,
        right_value_type: ExpressionValueType,
    ) -> IndexType:
        if isinstance(left_value_type, IndexType) and isinstance(
            right_value_type, NumericalType
        ):
            if not _is_integral_numerical_type(right_value_type):
                raise self._context.type_error(
                    f"index shift requires an integral scalar offset, but the "
                    f"right operand has type {right_value_type}"
                )
            return self._shift_index_type(left_value_type, binary_expression.right)
        if isinstance(left_value_type, NumericalType) and isinstance(
            right_value_type, IndexType
        ):
            if not _is_integral_numerical_type(left_value_type):
                raise self._context.type_error(
                    f"index shift requires an integral scalar offset, but the "
                    f"left operand has type {left_value_type}"
                )
            return self._shift_index_type(right_value_type, binary_expression.left)
        # Unreachable: the dispatcher routes both-numerical and both-index cases
        # away before this helper, so mixed shapes are the only remaining ones.
        raise self._context.type_error(  # pragma: no cover
            f"the add operation is not defined for operands of types "
            f"{left_value_type} and {right_value_type}; the resulting "
            "index bounds and stride cannot be inferred safely"
        )

    def _infer_index_shift_subtract(
        self,
        binary_expression: BinaryExpression,
        left_value_type: IndexType,
        right_value_type: NumericalType,
    ) -> IndexType:
        if not _is_integral_numerical_type(right_value_type):
            raise self._context.type_error(
                f"index shift requires an integral scalar offset, but the "
                f"right operand has type {right_value_type}"
            )
        return self._shift_index_type(
            left_value_type, binary_expression.right, subtract=True
        )

    def _infer_index_scale(
        self,
        binary_expression: BinaryExpression,
        left_value_type: ExpressionValueType,
        right_value_type: ExpressionValueType,
    ) -> IndexType:
        if isinstance(left_value_type, IndexType) and isinstance(
            right_value_type, NumericalType
        ):
            scalar_literal = self._validate_index_scale_scalar(
                binary_expression.right, right_value_type, side="right"
            )
            return self._scale_index_type(left_value_type, scalar_literal)
        if isinstance(left_value_type, NumericalType) and isinstance(
            right_value_type, IndexType
        ):
            scalar_literal = self._validate_index_scale_scalar(
                binary_expression.left, left_value_type, side="left"
            )
            return self._scale_index_type(right_value_type, scalar_literal)
        # Unreachable: the dispatcher routes both-numerical and both-index cases
        # away before this helper, so mixed shapes are the only remaining ones.
        raise self._context.type_error(  # pragma: no cover
            f"the multiply operation is not defined for operands of types "
            f"{left_value_type} and {right_value_type}; the resulting "
            "index bounds and stride cannot be inferred safely"
        )

    def _validate_index_scale_scalar(
        self,
        scalar_expression: Expression,
        scalar_value_type: NumericalType,
        *,
        side: str,
    ) -> LiteralExpression:
        if not isinstance(scalar_expression, LiteralExpression):
            raise self._context.type_error(
                "index scaling requires a positive integer literal scalar, "
                f"but the {side} operand "
                f"`{_format_expression(scalar_expression)}` is not a "
                "literal expression"
            )
        if not _is_integral_numerical_type(scalar_value_type):
            raise self._context.type_error(
                "index scaling requires a positive integer literal scalar, "
                f"but the {side} operand has non-integral type "
                f"{scalar_value_type}"
            )
        return scalar_expression

    # --- Context-aware helpers ----------------------------------------------

    def _as_expression_value_type(
        self, expression: Expression, type_: Type
    ) -> ExpressionValueType:
        if isinstance(type_, IndexType):
            stride = type_.stride
            if (
                isinstance(stride, LiteralExpression)
                and is_strict_int(stride.value)
                and stride.value == 0
            ):
                raise self._context.type_error(
                    "index type with stride `0` is not allowed; stride must be "
                    "a non-zero integer or a non-literal expression"
                )
            return type_
        elif not isinstance(type_, NumericalType):  # pragma: no cover
            # Defensive: callers always supply IndexType, NumericalType, or a
            # type that becomes one through Type.bind_template; a future Type
            # subclass that bypasses both paths should fail loud.
            raise self._context.type_error(
                f"sub-expression `{_format_expression(expression)}` must resolve "
                f"to a scalar numerical type or index type, but got {type_}"
            )
        elif not isinstance(type_.data_type, PrimitiveDataType):
            raise self._context.type_error(
                f"sub-expression `{_format_expression(expression)}` must resolve "
                f"to a primitive numerical type, but got {type_}"
            )
        elif not type_.is_scalar():
            raise NotImplementedError(
                f"sub-expression `{_format_expression(expression)}` resolves to "
                f"tensor type {type_}, but only scalar numerical and index types "
                "are allowed in expressions"
            )
        else:
            return type_

    def _check_expected_type(
        self, expression: Expression, actual_type: Type, expected_type: Type
    ) -> None:
        if isinstance(actual_type, IndexType) and isinstance(expected_type, IndexType):
            if not actual_type.is_structurally_equivalent(expected_type):
                raise self._context.type_error(
                    f"synthesized index type {actual_type} is not structurally "
                    f"equivalent to the expected index type {expected_type}"
                )
            return

        actual_value_type = self._as_expression_value_type(expression, actual_type)
        expected_value_type = self._as_expression_value_type(expression, expected_type)
        if isinstance(actual_value_type, IndexType) or isinstance(
            expected_value_type, IndexType
        ):
            raise self._context.type_error(
                f"synthesized type {actual_type} is incompatible with the "
                f"expected type {expected_type}: one is an index type and the "
                "other is a numerical type"
            )

        promoted_type = promote_primitive_data_types(
            _get_primitive_data_type(actual_value_type),
            _get_primitive_data_type(expected_value_type),
        )
        if (
            promoted_type.core_data_type
            != _get_primitive_data_type(expected_value_type).core_data_type
        ):
            raise self._context.type_error(
                f"synthesized type {actual_type} is wider than the expected type "
                f"{expected_type}; promoting them yields {promoted_type}, which "
                "does not match the expected type"
            )

    def _scale_index_type(
        self, index_type: IndexType, scalar: LiteralExpression
    ) -> IndexType:
        value = scalar.value
        if not is_strict_int(value):  # pragma: no cover
            # Defensive: `_validate_index_scale_scalar` rejects non-integer
            # scalars before this method is reached from the dispatcher.
            raise self._context.type_error(
                f"index scaling requires an integer literal scalar, but got scalar "
                f"value {value!r}"
            )
        if value <= 0:
            raise self._context.type_error(
                f"index scaling requires a positive integer literal scalar, but "
                f"got scalar value {value}"
            )
        stride = index_type.stride
        if isinstance(stride, LiteralExpression) and is_strict_int(stride.value):
            new_stride: Expression = LiteralExpression(value * stride.value)
        else:
            new_stride = scalar * stride
        return IndexType(
            scalar * index_type.lower_bound,
            scalar * index_type.upper_bound,
            new_stride,
        )

    @staticmethod
    def _shift_index_type(
        index_type: IndexType,
        offset_expression: Expression,
        *,
        subtract: bool = False,
    ) -> IndexType:
        if subtract:
            return IndexType(
                index_type.lower_bound - offset_expression,
                index_type.upper_bound - offset_expression,
                index_type.stride,
            )
        return IndexType(
            index_type.lower_bound + offset_expression,
            index_type.upper_bound + offset_expression,
            index_type.stride,
        )

    def _get_division_primitive_data_type(
        self, left_type: NumericalType, right_type: NumericalType
    ) -> PrimitiveDataType:
        left_core_data_type = _get_primitive_data_type(left_type).core_data_type
        right_core_data_type = _get_primitive_data_type(right_type).core_data_type

        if (
            left_core_data_type in _INTEGRAL_CORE_DATA_TYPES
            and right_core_data_type in _INTEGRAL_CORE_DATA_TYPES
        ):
            concrete_bit_widths = [
                bit_width
                for bit_width in (
                    get_core_data_type_bit_width(left_core_data_type),
                    get_core_data_type_bit_width(right_core_data_type),
                )
                if bit_width is not None
            ]
            return PrimitiveDataType(
                _get_real_float_core_data_type_for_bit_width(
                    max(concrete_bit_widths) if concrete_bit_widths else None
                )
            )

        left_core_data_type, right_core_data_type = _lift_integral_against_float_like(
            left_core_data_type, right_core_data_type
        )
        return PrimitiveDataType(
            promote_core_data_types(left_core_data_type, right_core_data_type)
        )

    def _get_floor_division_primitive_data_type(
        self, left_type: NumericalType, right_type: NumericalType
    ) -> PrimitiveDataType:
        left_core_data_type = _get_primitive_data_type(left_type).core_data_type
        right_core_data_type = _get_primitive_data_type(right_type).core_data_type

        if (
            left_core_data_type in _INTEGRAL_CORE_DATA_TYPES
            and right_core_data_type in _INTEGRAL_CORE_DATA_TYPES
        ):
            return promote_primitive_data_types(
                _get_primitive_data_type(left_type),
                _get_primitive_data_type(right_type),
            )

        if (
            left_core_data_type in _COMPLEX_CORE_DATA_TYPES
            or right_core_data_type in _COMPLEX_CORE_DATA_TYPES
        ):
            raise self._context.type_error(
                f"floor division is not defined for complex numerical types "
                f"(operand types were {left_type} and {right_type})"
            )

        left_core_data_type, right_core_data_type = _lift_integral_against_float_like(
            left_core_data_type, right_core_data_type
        )
        return PrimitiveDataType(
            promote_core_data_types(left_core_data_type, right_core_data_type)
        )


def synthesize_expression_type(
    expression: Expression,
    get_identifier_type: Callable[[Identifier], tuple[Type, TypeQualifier]],
) -> tuple[Type, TypeQualifier]:
    """Synthesize a type for an expression.

    Args:
        expression: The expression to synthesize a type for.
        get_identifier_type: A function that returns the type of an identifier.

    Returns:
        A tuple containing the synthesized type and the type qualifier.

    """
    return ExpressionTypeChecker(get_identifier_type).synthesize(expression)


def check_expression_type(
    expression: Expression,
    expected_type: Type,
    get_identifier_type: Callable[[Identifier], tuple[Type, TypeQualifier]],
) -> tuple[Type, TypeQualifier]:
    """Check an expression against an expected type.

    Args:
        expression: The expression to check.
        expected_type: The expected type to check against.
        get_identifier_type: A function that returns the type of an identifier.

    Returns:
        A tuple containing the checked type and the type qualifier.

    """
    return ExpressionTypeChecker(get_identifier_type).check(expression, expected_type)
