"""TradeOdds SDK quickstart.

Set TRADEODDS_API_KEY in your environment, then run:

    python examples/quickstart.py

Outputs the historical win rate and median 5-day forward return for SPY when
VIX is in its current regime — an end-to-end live API call in <30 lines.
"""
from __future__ import annotations

import json
import os
import sys

from tradeodds import ApiError, TradeOddsClient


def main() -> int:
    if not os.environ.get("TRADEODDS_API_KEY"):
        print("Set TRADEODDS_API_KEY first. Get a key at https://tradeodds.io/account.")
        return 1

    with TradeOddsClient() as client:
        try:
            result = client.analyze(
                symbol="SPY",
                forward_period="5d",
                conditions={"daily_change": True, "vix_level": True, "regime": True},
                lookback_years="20y",
            )
        except ApiError as exc:
            print(f"API error [{exc.code}]: {exc.message}")
            if exc.hint:
                print(f"hint: {exc.hint}")
            return 1

    print(json.dumps(result, indent=2, default=str)[:1500])
    return 0


if __name__ == "__main__":
    sys.exit(main())
