"""TradeOdds — official Python SDK.

Quickstart:

    >>> from tradeodds import TradeOddsClient
    >>> client = TradeOddsClient()  # reads TRADEODDS_API_KEY
    >>> result = client.analyze(symbol="SPY", conditions={"vix_level": True})
    >>> print(f"{result['match_count']} historical matches")
"""
from .client import DEFAULT_BASE_URL, TradeOddsClient, __version__
from .exceptions import (
    ApiError,
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .types import (
    AnalyzeResult,
    DNAConditions,
    FactorMatchResult,
    ForwardPeriod,
    LookbackYears,
    PerfFilter,
    PerfMetric,
    PerfOperator,
    ReferencePeriod,
    ScreenerFilters,
    Symbol,
    SymbolListResponse,
)

# Backwards-compatibility alias — many SDKs expose `Client`.
Client = TradeOddsClient

__all__ = [
    "__version__",
    "Client",
    "TradeOddsClient",
    "DEFAULT_BASE_URL",
    # Exceptions
    "ApiError",
    "AuthError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
    # Types
    "AnalyzeResult",
    "DNAConditions",
    "FactorMatchResult",
    "ForwardPeriod",
    "LookbackYears",
    "PerfFilter",
    "PerfMetric",
    "PerfOperator",
    "ReferencePeriod",
    "ScreenerFilters",
    "Symbol",
    "SymbolListResponse",
]
