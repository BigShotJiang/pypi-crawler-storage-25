"""TypedDict definitions for TradeOdds request/response shapes.

These mirror the Pydantic models in ``backend/app/api/public_api.py``. Using
TypedDicts (instead of dataclasses) keeps the SDK zero-runtime-cost: requests
and responses round-trip as plain dicts, but editor / mypy autocomplete still
works.

For analyze / factor-match responses the server returns a rich nested object
that varies by tier — those are typed as ``Dict[str, Any]`` here so the SDK
doesn't drift when the response schema is extended. Inspect ``result.keys()``
or ``json.dumps(result, indent=2)`` on a real call to discover fields.
"""
from typing import Any, Dict, List, Literal, Optional

try:
    # Python 3.11+: TypedDict supports total=False per-key with NotRequired.
    from typing import NotRequired, TypedDict
except ImportError:  # pragma: no cover - Python 3.9 / 3.10
    from typing_extensions import NotRequired, TypedDict  # type: ignore[assignment]


# ── Reference / forward windows ────────────────────────────────────────

ReferencePeriod = Literal["1d", "2d", "3d", "4d", "5d", "1w", "1m"]
ForwardPeriod = Literal["1d", "2d", "3d", "4d", "5d", "20d", "1w", "1m"]
LookbackYears = Literal["1y", "3y", "5y", "10y", "20y", "max"]
PerfMetric = Literal["win_1d", "win_5d", "win_20d", "mean_1d", "mean_5d", "mean_20d"]
PerfOperator = Literal["gt", "lt"]


# ── Symbols ────────────────────────────────────────────────────────────

class Symbol(TypedDict):
    symbol: str
    name: Optional[str]
    sector: Optional[str]
    is_high_liquidity: bool
    is_etf: bool


class SymbolListResponse(TypedDict):
    count: int
    symbols: List[Symbol]


# ── Analyze / factor-match request shapes ──────────────────────────────

class DNAConditions(TypedDict, total=False):
    """DNA filter flags accepted by /analyze and /factor-match.

    Every key is optional — omit or set ``False`` to ignore a factor. ``daily_change``
    defaults to True server-side. ``magnitude_mode`` only applies when ``magnitude``
    is True.
    """
    daily_change: bool
    magnitude: bool
    magnitude_mode: Literal["add", "replace"]
    vix_level: bool
    vix_move: bool
    regime: bool
    rel_vol: bool
    rsi_zone: bool
    rsi_slope: bool
    structure_precision: bool
    earnings_prox: bool
    streak: bool
    volume_streak: bool
    earnings_perf: bool
    overnight_gap: bool
    analyst_trend: bool
    month_of_year: bool
    macro_risk: bool


class ScreenerFilters(TypedDict, total=False):
    is_etf: bool
    is_crypto: bool
    is_gold_standard: bool
    sector: str
    industry: str
    symbols: List[str]
    price_min: float
    price_max: float
    volume_min: float


class PerfFilter(TypedDict):
    metric: PerfMetric
    operator: PerfOperator
    threshold: float


# Response payloads vary by tier and feature flag — keep them open so the SDK
# doesn't break when the server adds fields.
AnalyzeResult = Dict[str, Any]
FactorMatchResult = Dict[str, Any]


__all__ = [
    "ReferencePeriod",
    "ForwardPeriod",
    "LookbackYears",
    "PerfMetric",
    "PerfOperator",
    "Symbol",
    "SymbolListResponse",
    "DNAConditions",
    "ScreenerFilters",
    "PerfFilter",
    "AnalyzeResult",
    "FactorMatchResult",
]
