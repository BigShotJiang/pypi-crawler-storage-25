"""Synchronous HTTP client for the TradeOdds REST API.

Thin wrapper around ``requests``: one method per endpoint, typed inputs,
typed exceptions on 4xx/5xx with the structured envelope's ``code`` / ``hint``
/ ``request_id`` preserved as exception attributes.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

import requests

from .exceptions import (
    ApiError,
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .types import (
    AnalyzeResult,
    DNAConditions,
    FactorMatchResult,
    ForwardPeriod,
    LookbackYears,
    PerfFilter,
    ReferencePeriod,
    ScreenerFilters,
    SymbolListResponse,
)

__version__ = "0.1.0"

DEFAULT_BASE_URL = "https://tradeodds-production.up.railway.app"


def _exception_for_status(status: int) -> type:
    if status == 401:
        return AuthError
    if status == 404:
        return NotFoundError
    if status == 429:
        return RateLimitError
    if status in (400, 422):
        return ValidationError
    if status >= 500:
        return ServerError
    return ApiError


class TradeOddsClient:
    """Synchronous client for the TradeOdds public REST API.

    Reads ``TRADEODDS_API_KEY`` from the environment by default. Override with
    ``api_key=`` / ``base_url=`` / ``timeout=`` constructor args. Pass a custom
    ``session=requests.Session()`` to share connection pooling or attach
    retries. ``symbols()`` works without an API key;
    ``analyze()`` and ``factor_match()`` require one.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = 200.0,
        session: Optional[requests.Session] = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("TRADEODDS_API_KEY")
        self.base_url = (
            base_url
            or os.environ.get("TRADEODDS_BASE_URL")
            or DEFAULT_BASE_URL
        ).rstrip("/")
        self.timeout = timeout
        self._session = session or requests.Session()

    # ── Public methods ──────────────────────────────────────────────

    def symbols(self, *, active_only: bool = True) -> SymbolListResponse:
        """``GET /api/v1/symbols`` — list every available instrument. No auth required."""
        return self._request(
            "GET",
            "/api/v1/symbols",
            params={"active_only": str(active_only).lower()},
            auth_required=False,
        )

    def analyze(
        self,
        symbol: str,
        *,
        reference_period: ReferencePeriod = "1d",
        forward_period: ForwardPeriod = "5d",
        conditions: Optional[DNAConditions] = None,
        lookback_years: LookbackYears = "max",
        price_tolerance: int = 0,
        vix_tolerance: int = 0,
    ) -> AnalyzeResult:
        """``POST /api/v1/analyze`` — historical pattern analysis on one symbol.

        Returns match count, win rate, median forward return, and historical
        instances. Billed at $0.05/call. Daily cap: 1,000/key. See README for
        the full conditions vocabulary.
        """
        body: Dict[str, Any] = {
            "symbol": symbol,
            "reference_period": reference_period,
            "forward_period": forward_period,
            "lookback_years": lookback_years,
            "price_tolerance": price_tolerance,
            "vix_tolerance": vix_tolerance,
        }
        if conditions is not None:
            body["conditions"] = dict(conditions)
        return self._request("POST", "/api/v1/analyze", json=body, auth_required=True)

    def factor_match(
        self,
        *,
        forward_periods: Optional[List[ForwardPeriod]] = None,
        conditions: Optional[DNAConditions] = None,
        filters: Optional[ScreenerFilters] = None,
        perf_filter: Optional[PerfFilter] = None,
        history_range: LookbackYears = "max",
        min_instances: int = 10,
        price_tolerance: int = 0,
        vix_tolerance: int = 0,
    ) -> FactorMatchResult:
        """``POST /api/v1/factor-match`` — scan all symbols for current DNA matches.

        Returns a ranked list with historical forward-return stats per symbol.
        Billed at $0.15/call. Daily cap: 200/key. Server caps at 180s; narrow
        ``filters`` if you time out.
        """
        body: Dict[str, Any] = {
            "forward_periods": forward_periods or ["1d", "5d", "20d"],
            "history_range": history_range,
            "min_instances": min_instances,
            "price_tolerance": price_tolerance,
            "vix_tolerance": vix_tolerance,
        }
        if conditions is not None:
            body["conditions"] = dict(conditions)
        if filters is not None:
            body["filters"] = dict(filters)
        if perf_filter is not None:
            body["perf_filter"] = dict(perf_filter)
        return self._request(
            "POST", "/api/v1/factor-match", json=body, auth_required=True
        )

    # ── Internals ───────────────────────────────────────────────────

    def _headers(self, auth_required: bool) -> Dict[str, str]:
        headers = {
            "User-Agent": f"tradeodds-python/{__version__}",
            "X-Client": "python-sdk",
            "Accept": "application/json",
        }
        if auth_required or self.api_key:
            if not self.api_key:
                raise AuthError(
                    "API key required.",
                    code="missing_api_key",
                    hint=(
                        "Pass api_key=... to TradeOddsClient or set the "
                        "TRADEODDS_API_KEY environment variable. "
                        "Get a key at https://tradeodds.io/account."
                    ),
                    status_code=401,
                )
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        auth_required: bool = False,
    ) -> Any:
        url = f"{self.base_url}{path}"
        try:
            resp = self._session.request(
                method,
                url,
                params=params,
                json=json,
                headers=self._headers(auth_required),
                timeout=self.timeout,
            )
        except requests.Timeout as exc:
            raise ServerError(
                f"Request to {path} timed out after {self.timeout}s.",
                code="client_timeout",
                hint="Increase TradeOddsClient(timeout=...) or narrow your filters.",
                status_code=None,
            ) from exc
        except requests.RequestException as exc:
            raise ApiError(
                f"Network error talking to TradeOdds: {exc}",
                code="network_error",
                hint="Check your connection and TRADEODDS_BASE_URL.",
            ) from exc

        if resp.status_code >= 400:
            self._raise_for_status(resp)

        if not resp.content:
            return None
        try:
            return resp.json()
        except ValueError as exc:  # malformed JSON — should never happen
            raise ServerError(
                f"Invalid JSON response from {path}: {exc}",
                code="invalid_response",
                status_code=resp.status_code,
            ) from exc

    @staticmethod
    def _raise_for_status(resp: requests.Response) -> None:
        """Translate an error response into a typed SDK exception."""
        request_id = resp.headers.get("X-Request-Id")
        try:
            payload = resp.json()
        except ValueError:
            payload = {}

        envelope = payload.get("error") if isinstance(payload, dict) else None
        if isinstance(envelope, dict):
            code = envelope.get("code") or "api_error"
            message = envelope.get("message") or resp.reason or "API error."
            hint = envelope.get("hint")
            request_id = envelope.get("request_id") or request_id
        else:
            # Non-v1 routes still use FastAPI's `{"detail": "..."}` shape.
            code = "api_error"
            detail = payload.get("detail") if isinstance(payload, dict) else None
            message = detail if isinstance(detail, str) else (resp.reason or "API error.")
            hint = None

        exc_cls = _exception_for_status(resp.status_code)
        raise exc_cls(
            message,
            code=code,
            hint=hint,
            request_id=request_id,
            status_code=resp.status_code,
        )

    # ── Context-manager support ────────────────────────────────────

    def close(self) -> None:
        self._session.close()

    def __enter__(self) -> "TradeOddsClient":
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()


__all__ = ["TradeOddsClient", "DEFAULT_BASE_URL", "__version__"]
