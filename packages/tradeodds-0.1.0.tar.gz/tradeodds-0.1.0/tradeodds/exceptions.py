"""Typed exceptions for the TradeOdds SDK.

All errors raised by `TradeOddsClient` inherit from `ApiError`. The structured
error envelope returned by the API (`code`, `message`, `hint`, `request_id`)
is preserved as attributes so callers and LLM agents can branch on the error
code rather than parsing prose.
"""
from typing import Optional


class ApiError(Exception):
    """Base class for all TradeOdds API errors.

    Attributes:
        code: Machine-readable error code (e.g. ``rate_limit_exceeded``).
        message: Human-readable error message from the API.
        hint: Suggested remediation, if the API provided one.
        request_id: Server-side request id for support contact.
        status_code: HTTP status code that triggered the error.
    """

    def __init__(
        self,
        message: str,
        *,
        code: str = "api_error",
        hint: Optional[str] = None,
        request_id: Optional[str] = None,
        status_code: Optional[int] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.hint = hint
        self.request_id = request_id
        self.status_code = status_code

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(code={self.code!r}, "
            f"status_code={self.status_code!r}, message={self.message!r})"
        )


class AuthError(ApiError):
    """Raised on 401 — missing or invalid API key."""


class NotFoundError(ApiError):
    """Raised on 404 — unknown symbol or resource."""


class RateLimitError(ApiError):
    """Raised on 429 — daily or per-minute quota exceeded."""


class ValidationError(ApiError):
    """Raised on 422 / 400 — invalid request body or parameters."""


class ServerError(ApiError):
    """Raised on 5xx — server-side failure or timeout (504)."""


__all__ = [
    "ApiError",
    "AuthError",
    "NotFoundError",
    "RateLimitError",
    "ValidationError",
    "ServerError",
]
