<!-- rye:signed:2026-04-01T04:53:30Z:35784e158b341bb726f161cd3d48a5de4c55d2963823a6a1437f61319ad8891a:0Jz1eL0mv8jhsG2A9rAt1BKKnnDvUhNYirXAsCsVAoD5mnAwmHs2n-8Mk3pVPJZVBXc40cWjnyztja3gxNQiAw:6ea18199041a1ea8 -->
# Push to Remote

Sync local project and user state to the remote CAS server.

```xml
<directive name="push" version="1.0.0">
  <metadata>
    <description>Build manifests and sync missing objects to remote.</description>
    <category>rye/core/remote</category>
    <author>rye-os</author>
    <model tier="fast" />
    <limits turns="3" tokens="4096" />
    <permissions>
      <execute>
        <tool>rye.core.remote.*</tool>
      </execute>
    </permissions>
  </metadata>

  <inputs />

  <outputs>
    <output name="sync_result">Push results including objects synced count</output>
  </outputs>
</directive>
```

<process>
  <step name="push">
    Execute the remote tool with action=push:
    ```
    rye execute tool rye/core/remote/remote with {"action": "push"}
    ```
  </step>

  <step name="report">
    Report the sync result: how many objects were synced, manifest hashes.
  </step>
</process>
