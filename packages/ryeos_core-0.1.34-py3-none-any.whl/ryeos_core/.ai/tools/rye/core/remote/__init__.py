# rye:signed:2026-04-01T04:53:30Z:cbef9718e6f47132717b5f530be14ea76f471c3cdf5e6df271b347cd13964a28:-9QT7Bl-N9gqCS9CiBvSNpFAw2xT8t6Qi_gx3izY5-_1lnIsHMH2-WloCJOl5qghvWmdBQLydK4RdwqvOHiKDQ:6ea18199041a1ea8
"""Remote execution tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/remote"
__tool_description__ = "Remote execution tools package"
