# rye:signed:2026-04-01T04:53:30Z:92135959fc270503eadbcebca8b86044e2c8542e11b5e6748d5970012de441ed:jrcTjfjatN0ExzzRzD8hXyM-5q5GTN1Uyme_7xe0LkJ2b2r2TUp5B0OemuqqyXe39VJeysLsdFZXW3GqqUqIDg:6ea18199041a1ea8
"""Python runtime library package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/runtimes/python/lib"
__tool_description__ = "Python runtime library package"
