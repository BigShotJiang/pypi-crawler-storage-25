# rye:signed:2026-04-01T04:53:30Z:8e1ab83b0df0e582e7c00467338e11bbfd40ef1932a98481f8733abecccc38d3:2u_g1uUIo0gdCJBXioVsGF4yR2NNNl1hJf_3C_fUUURo_zJ73p7XyrEaR7UaRHAIuLH5Tq_jQYqqIVPFfvASBQ:6ea18199041a1ea8
"""Telemetry tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/telemetry"
__tool_description__ = "Telemetry tools package"

from .mcp_logs import get_logs, get_log_stats

__all__ = ["get_logs", "get_log_stats"]
