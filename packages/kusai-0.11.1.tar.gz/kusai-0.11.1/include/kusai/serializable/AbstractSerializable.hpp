#pragma once

#include "nlohmann/json.hpp"

namespace kusai {
class AbstractSerializable {
 public:
  virtual ~AbstractSerializable() = default;

  [[nodiscard]] virtual nlohmann::json serialize() const = 0;

  [[nodiscard]] virtual bool deserialize(const nlohmann::json& data) = 0;

  void serializeToOstream(std::ostream& out) const;

  [[nodiscard]] bool deserializeFromIstream(std::istream& in);

 protected:
  explicit AbstractSerializable() = default;
};
}  // namespace kusai
