# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

import logging
from copy import deepcopy
from decimal import Decimal
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Case, F, OuterRef, Q, Subquery, When
from django.utils.html import mark_safe, format_html, escape
from django.utils.translation import gettext, override, get_language
from lino.api import dd, rt, _

logger = logging.getLogger(__name__)
from lino.core import constants
from lino.mixins import Created
from lino.modlib.linod.choicelists import schedule_often
from lino.modlib.notify.choicelists import MessageTypes
from lino.modlib.users.mixins import UserAuthored
from lino.utils.format_number import localize_number
from lino.utils.mti import get_child
from lino_xl.lib.accounting.roles import LedgerUser
from .actions import MakeDocumentPair, MarkDelivered
from .choicelists import VoucherActionStates

MessageTypes.add_item("document_followup", _("Document follow-up"))


class BoxedDocument(Created, UserAuthored):
    class Meta:
        abstract = True

    allow_cascaded_delete = ["partner", "voucher"]
    allow_cascaded_copy = set([])

    manager_roles_required = dd.login_required(LedgerUser)

    def has_document_pair(self):
        return rt.models.ltx.DocumentPair.exists_for_voucher(self.voucher)

    @dd.displayfield(_("Voucher"))
    def voucher_display(self, ar=None):
        if ar is None:
            return ""
        return ar.obj2htmls(self.voucher)

    @classmethod
    def is_my_inbound_document(cls, voucher, ar):
        InboundDocument = rt.models.ltx.InboundDocument
        ib = InboundDocument.objects.filter(voucher=voucher).first()
        if not ib:
            return False
        return ib.partner == ar.get_user().ledger.company

    @classmethod
    def is_my_outbound_document(cls, voucher, ar):
        OutboundDocument = rt.models.ltx.OutboundDocument
        ob = OutboundDocument.objects.filter(voucher=voucher).first()
        if not ob:
            return False
        return ob.partner == ar.get_user().ledger.company

    def disabled_fields(self, ar):
        dfs = super().disabled_fields(ar)
        dfs.add("author")
        return dfs


class OutboundDocument(BoxedDocument):
    class Meta:
        app_label = 'ltx'
        abstract = dd.is_abstract_model(__name__, 'OutboundDocument')
        verbose_name = _("Outbound document")
        verbose_name_plural = _("Outbound documents")

    voucher = dd.OneToOneField(
        dd.plugins.ltx.voucher_model,
        verbose_name=_("Voucher"),
        related_name='ltx_outbound_document'
    )

    partner = dd.ForeignKey(
        'contacts.Company',
        null=True, blank=True,
        verbose_name=_("Organization"),
        related_name='ltx_outbound_documents'
    )

    payment_done = dd.BooleanField(_("Payment done"), default=False)
    delivered = dd.BooleanField(_("Service/Good delivered"), default=False)

    mark_delivered = MarkDelivered()

    @dd.displayfield(_("Receiver"))
    def document_partner(self, ar=None):
        if ar is None:
            return ""
        return ar.obj2htmls(self.voucher.partner.company)

    @dd.displayfield(_("Status"))
    def status(self, ar=None):
        ib = rt.models.ltx.InboundDocument.objects.filter(voucher=self.voucher).first()
        if not ib:
            return "N/A"
        return ib.state.text

    @dd.displayfield(_("Remark"))
    def remark(self, ar=None):
        ib = rt.models.ltx.InboundDocument.objects.filter(voucher=self.voucher).first()
        if not ib:
            return ""
        return ib.remark

    @dd.displayfield(_("Delivery note"))
    def delivery_note(self, ar=None):
        if not self.delivered:
            return ""
        if not dd.is_installed("trading"):
            return ""
        InvoiceDispatch = getattr(rt.models.trading, "InvoiceDispatch", None)
        if not InvoiceDispatch:
            return ""
        CIO = get_child(self.voucher, rt.models.trading.CashInvoice)
        if CIO is None:
            return ""
        dn = InvoiceDispatch.objects.filter(sales_note=CIO).first()
        if dn is None:
            return ""
        return ar.obj2htmls(dn.delivery_note)

    def __str__(self) -> str:
        return _("Outbound document {0}").format(self.voucher)

    def full_clean(self, *args, **kwargs) -> None:
        super().full_clean(*args, **kwargs)
        if self.partner:
            if self.partner != self.voucher.journal.ledger.company:
                raise ValidationError(_(
                    "The organization must be the same as in the voucher.journal.ledger.company."
                ))
        else:
            self.partner = self.voucher.journal.ledger.company

    def disabled_fields(self, ar):
        dfs = super().disabled_fields(ar)
        ib = rt.models.ltx.InboundDocument.objects.filter(voucher=self.voucher).first()
        if self.delivered or (ib and ib.state == VoucherActionStates.rejected):
            dfs.add("mark_delivered")
        return dfs

    # @classmethod
    # def get_simple_parameters(cls):
    #     yield from super().get_simple_parameters()
    #     yield "payment_done"
    #     yield "delivered"

    def save_new_instance(elem, ar):
        r = super().save_new_instance(ar)
        elem.voucher.on_outbox_created(elem, ar)
        return r


class OutboundDocuments(dd.Table):
    label = _("Outbound documents")
    model = "ltx.OutboundDocument"
    required_roles = dd.login_required(dd.SiteStaff)
    column_names = ("partner voucher_display document_partner payment_done "
                    "delivered delivery_note status *")
    detail_layout = """
    voucher_display document_partner status
    remark
    partner payment_done
    delivered delivery_note
    user created
    ltx.ChangeSummariesByOutboundDocument
    """

    parameters = {
        "payment_done": models.NullBooleanField(_("Payment done"), null=True, blank=True),
        "delivered": models.NullBooleanField(_("Service/Good delivered"), null=True, blank=True),
    }

    @classmethod
    def get_request_queryset(self, ar, **filter):
        qs = super().get_request_queryset(ar, **filter)
        pv = ar.param_values
        if pv and pv.payment_done is not None:
            qs = qs.filter(payment_done=pv.payment_done)
        if pv and pv.delivered is not None:
            qs = qs.filter(delivered=pv.delivered)
        return qs


class OutboundDocumentsByPartner(OutboundDocuments):
    label = _("Outbound documents")
    master_key = "partner"
    required_roles = dd.login_required(LedgerUser)
    column_names = ("voucher_display document_partner payment_done "
                    "delivered delivery_note status *")

    detail_layout = """
    voucher_display document_partner status
    remark
    payment_done delivered delivery_note
    user created
    ltx.ChangeSummariesByOutboundDocument
    """

    @classmethod
    def param_defaults(self, ar, **kw):
        kw = super().param_defaults(ar, **kw)
        kw.update(user=None, payment_done=None, delivered=None)
        return kw

    @classmethod
    def get_disabled_fields(cls, obj, ar):
        dfs = super().get_disabled_fields(obj, ar)
        dfs.add("payment_done")
        dfs.add("delivered")
        return dfs

    @classmethod
    def get_request_queryset(cls, ar):
        qs = super().get_request_queryset(ar)
        user = ar.get_user()
        if user.is_anonymous:
            return qs.none()
        if user.ledger is None:
            return qs.none()
        return qs.filter(partner=user.ledger.company)


class InboundDocument(BoxedDocument):
    class Meta:
        app_label = 'ltx'
        abstract = dd.is_abstract_model(__name__, 'InboundDocument')
        verbose_name = _("Inbound document")
        verbose_name_plural = _("Inbound documents")

    voucher = dd.OneToOneField(
        dd.plugins.ltx.voucher_model,
        verbose_name=_("Voucher"),
        related_name='ltx_inbound_document'
    )

    partner = dd.ForeignKey(
        'contacts.Company',
        verbose_name=_("Organization"),
        related_name='ltx_inbound_documents'
    )

    workflow_state_field = 'state'

    state = VoucherActionStates.field(default="pending")

    remark = dd.RichTextField(_("Remark"), blank=True, format="html")

    make_document_pair = MakeDocumentPair()

    @dd.displayfield(_("Owner"))
    def document_partner(self, ar=None):
        if ar is None:
            return ""
        return ar.obj2htmls(self.voucher.journal.ledger.company)

    @dd.displayfield(_("Delivered"))
    def delivered(self, ar=None):
        ob = rt.models.ltx.OutboundDocument.objects.get(voucher=self.voucher)
        return ob.delivered

    @dd.displayfield(_("Payment done"))
    def payment_done(self, ar=None):
        ob = rt.models.ltx.OutboundDocument.objects.get(voucher=self.voucher)
        return ob.payment_done

    def __str__(self) -> str:
        return _("Inbound document {0}").format(self.voucher)

    @classmethod
    def get_simple_parameters(cls):
        yield from super().get_simple_parameters()
        yield "state"

    def after_ui_save(self, ar, cw):
        r = super().after_ui_save(ar, cw)
        if cw is not None and cw.has_changed("state"):
            if self.state == VoucherActionStates.rejected:
                VoucherActionStates.reject_my_own_document(self, ar)
        return r

    def full_clean(self, *args, **kwargs) -> None:
        super().full_clean(*args, **kwargs)
        if (self.state == VoucherActionStates.rejected
            and (not self.remark or self.remark.strip() == "")
        ):
            raise ValidationError(_("Remark is required when rejecting a document."))

        if self.partner:
            if self.partner != self.voucher.partner.company:
                raise ValidationError(_(
                    "The organization must be the same as in the voucher."
                ))
        else:
            self.partner = self.voucher.partner.company

    def disabled_fields(self, ar):
        dfs = super().disabled_fields(ar)
        dfs.add("state")
        dwfafld = getattr(self.voucher, "get_disabled_wf_actions_for_ltx_document", None)
        if callable(dwfafld):
            dwfafld(self, dfs)
        if self.state != VoucherActionStates.acknowledged:
            dfs.add("make_document_pair")
        OutboundDocument = rt.models.ltx.OutboundDocument
        ob = OutboundDocument.objects.filter(voucher=self.voucher).first()
        if ob and (ob.payment_done or ob.delivered):
            dfs.add(VoucherActionStates.rejected.transition.action_name)
        # if the inbound document is a counter part of one of my outbound
        # documents, Then there should be no possibility for a rejection.
        InboundDocument = rt.models.ltx.InboundDocument
        DocumentPair = rt.models.ltx.DocumentPair
        if (self.voucher.is_dependent(ar)
            and (ib := InboundDocument.objects.filter(
                voucher=DocumentPair.other_document(self.voucher)).first())
            and ib.state != VoucherActionStates.rejected
        ):
            dfs.add(VoucherActionStates.rejected.transition.action_name)
        return dfs


class InboundDocuments(dd.Table):
    label = _("Inbound documents")
    model = "ltx.InboundDocument"
    required_roles = dd.login_required(dd.SiteStaff)
    column_names = "partner voucher_display document_partner state *"
    detail_layout = """
    partner voucher_display document_partner state
    payment_done delivered
    user created
    remark
    ltx.ChangeSummariesByInboundDocument
    """


class InboundDocumentsByPartner(InboundDocuments):
    label = _("Inbound documents")
    master_key = "partner"
    required_roles = dd.login_required(LedgerUser)
    column_names = "voucher_display document_partner state *"

    detail_layout = """
    voucher_display document_partner state
    payment_done delivered
    user created
    remark
    ltx.ChangeSummariesByInboundDocument
    """

    @classmethod
    def get_request_queryset(cls, ar):
        qs = super().get_request_queryset(ar)
        user = ar.get_user()
        if user.is_anonymous:
            return qs.none()
        if user.ledger is None:
            return qs.none()
        return qs.filter(partner=user.ledger.company)


class DocumentPair(dd.Model):
    class Meta:
        app_label = 'ltx'
        abstract = dd.is_abstract_model(__name__, 'DocumentPair')
        verbose_name = _("Document pair")
        verbose_name_plural = _("Document pairs")

    source_voucher = dd.OneToOneField(
        dd.plugins.ltx.voucher_model,
        verbose_name=_("Source voucher"),
        related_name='ltx_document_pair_source',
    )

    target_voucher = dd.OneToOneField(
        dd.plugins.ltx.voucher_model,
        verbose_name=_("Target voucher"),
        related_name='ltx_document_pair_target',
    )

    auto_sync = dd.BooleanField(
        default=True,
        verbose_name=_("Auto-sync"),
        help_text=_(
            "If enabled, changes to one document will be automatically"
            " applied to the other document."
        ),
    )

    def __str__(self):
        return _("Document pair: {0} <-> {1}").format(
            self.source_voucher, self.target_voucher
        )

    def get_sync_source_voucher(self):
        sync_source_voucher = (
            self.source_voucher
            if self.is_sync_source_voucher(self.source_voucher)
            else self.target_voucher
        )
        assert self.is_sync_source_voucher(sync_source_voucher), _(
            "One of the pair vouchers must be the sync source"
        )
        return sync_source_voucher

    @classmethod
    def get_sync_source_journal_suffixes(cls):
        suffixes = dd.plugins.ltx.sync_source_journal_suffixes or ()
        return tuple(s.upper() for s in suffixes if s)

    @classmethod
    def is_sync_source_voucher(cls, voucher):
        return cls._is_sync_source(voucher)

    @classmethod
    def _is_sync_source(cls, voucher):
        # Sync is intentionally one-way: configured source journal refs -> paired voucher.
        suffixes = cls.get_sync_source_journal_suffixes()
        if not suffixes:
            return False
        journal_ref = (getattr(voucher.journal, "ref", None) or "").upper()
        return bool(
            getattr(voucher, "journal_id", None)
            and journal_ref
            and any(journal_ref.endswith(suffix) for suffix in suffixes)
        )

    @classmethod
    def get_for_voucher(cls, voucher):
        return cls.objects.filter(cls.get_voucher_query(voucher)).first()

    @classmethod
    def get_sync_target(cls, source_voucher):
        pair = cls.get_for_voucher(source_voucher)
        if pair is None or not pair.auto_sync or not cls._is_sync_source(source_voucher):
            return None, None
        target_voucher = pair.target_voucher
        if pair.target_voucher_id == source_voucher.id:
            target_voucher = pair.source_voucher
        return pair, target_voucher

    @classmethod
    def _item_payload(cls, item):
        product_label = None
        if item.product_id:
            product_label = dd.babelattr(item.product, 'name') or str(item.product)
        return {
            "id": item.pk,
            "seqno": item.seqno,
            "product_id": item.product_id,
            "product_label": product_label,
            "description": item.description,
            "qty": str(item.qty) if item.qty is not None else None,
            "discount_rate": (
                str(item.discount_rate) if item.discount_rate is not None else None
            ),
            "discount_amount": (
                str(item.discount_amount) if item.discount_amount is not None else None
            ),
            "unit_price": str(item.unit_price) if item.unit_price is not None else None,
            "total_base": str(item.total_base) if item.total_base is not None else None,
            "total_vat": str(item.total_vat) if item.total_vat is not None else None,
            "total_incl": str(item.total_incl) if item.total_incl is not None else None,
        }

    @classmethod
    def _voucher_payload(cls, voucher):
        return {
            "id": voucher.pk,
            "default_discount": (
                str(voucher.default_discount)
                if voucher.default_discount is not None
                else None
            ),
            "total_base": str(voucher.total_base) if voucher.total_base is not None else None,
            "total_vat": str(voucher.total_vat) if voucher.total_vat is not None else None,
            "total_incl": str(voucher.total_incl) if voucher.total_incl is not None else None,
            "items": [cls._item_payload(i) for i in voucher.items.order_by("seqno", "id")],
        }

    @classmethod
    def _stringify_value(cls, value):
        if value is None:
            return None
        return str(value)

    @classmethod
    def _maybe_reregister(cls, voucher, ar):
        VoucherStates = rt.models.accounting.VoucherStates
        if voucher.state != VoucherStates.registered:
            return False
        if ar is None:
            return False
        voucher.deregister(ar)
        return True

    @classmethod
    def _restore_registration(cls, voucher, ar, was_registered):
        if was_registered and ar is not None:
            voucher.register(ar)

    @classmethod
    def _next_sequence(cls, voucher):
        ChangeSummary = rt.models.ltx.ChangeSummary
        latest = (
            ChangeSummary.objects.filter(voucher=voucher)
            .order_by("-sequence")
            .values_list("sequence", flat=True)
            .first()
        )
        return (latest or 0) + 1

    @classmethod
    def _log_sync_event(
        cls,
        voucher,
        pair,
        event_type,
        summary,
        changes,
        user=None,
        voucher_snapshot_before=None,
        voucher_snapshot_after=None,
    ):
        ChangeSummary = rt.models.ltx.ChangeSummary
        cs = ChangeSummary(
            voucher=voucher,
            pair=pair,
            changed_by=user,
            sequence=cls._next_sequence(voucher),
            event_type=event_type,
            summary=summary,
            changes=changes,
            voucher_snapshot_before=voucher_snapshot_before or {},
            voucher_snapshot_after=voucher_snapshot_after or {},
        )
        cs.full_clean()
        cs.save()
        ChangeSummary._link_to_pair_partner(cs)
        return cs

    @classmethod
    def sync_default_discount(
        cls,
        source_voucher,
        ar=None,
        user=None,
        create_change_summaries=True,
    ):
        pair, target_voucher = cls.get_sync_target(source_voucher)
        if pair is None or target_voucher is None:
            return False
        source_discount = cls._stringify_value(source_voucher.default_discount)
        target_discount = cls._stringify_value(target_voucher.default_discount)
        if source_discount == target_discount:
            return False

        target_voucher._skip_document_pair_sync = True
        was_registered = cls._maybe_reregister(target_voucher, ar)
        target_voucher.default_discount = source_voucher.default_discount
        target_voucher.full_clean()
        target_voucher.save(update_fields=["default_discount"])
        cls._restore_registration(target_voucher, ar, was_registered)
        return False

    @classmethod
    def sync_invoice_item(cls, source_item):
        source_voucher = source_item.voucher
        pair, target_voucher = cls.get_sync_target(source_voucher)
        if pair is None or target_voucher is None:
            return False

        target_item = target_voucher.items.filter(seqno=source_item.seqno).first()
        if target_item is None:
            target_item = target_voucher.add_voucher_item()
            target_item.seqno = source_item.seqno

        tracked = [
            "product",
            "description",
            "qty",
            "discount_rate",
            "discount_amount",
            "unit_price",
        ]
        changes = {}
        for field in tracked:
            source_val = getattr(source_item, field)
            target_val = getattr(target_item, field)
            if field == "product":
                old_v = target_item.product_id
                new_v = source_item.product_id
                if old_v != new_v:
                    changes[field] = {"old": old_v, "new": new_v}
                    target_item.product = source_val
                continue
            old_v = cls._stringify_value(target_val)
            new_v = cls._stringify_value(source_val)
            if old_v != new_v:
                changes[field] = {"old": old_v, "new": new_v}
                setattr(target_item, field, source_val)

        return False

    @classmethod
    def sync_invoice_item_deletion(
        cls,
        source_item,
        ar=None,
        user=None,
    ):
        source_voucher = source_item.voucher
        pair, target_voucher = cls.get_sync_target(source_voucher)
        if pair is None or target_voucher is None:
            return False
        target_item = target_voucher.items.filter(seqno=source_item.seqno).first()
        if target_item is None:
            return False

        target_voucher._skip_document_pair_sync = True
        was_registered = cls._maybe_reregister(target_voucher, ar)
        setattr(target_item, "_skip_document_pair_sync", True)
        target_item.delete()
        target_voucher.compute_totals()
        target_voucher.full_clean()
        target_voucher.save()
        cls._restore_registration(target_voucher, ar, was_registered)
        return True

    @classmethod
    def sync_all_from_voucher(
        cls,
        source_voucher,
        ar=None,
        user=None,
    ):
        create_change_summaries = False
        pair, target_voucher = cls.get_sync_target(source_voucher)
        if pair is None or target_voucher is None:
            return False

        changed = cls.sync_default_discount(
            source_voucher,
            ar=ar,
            user=user,
            create_change_summaries=create_change_summaries,
        )
        source_seqnos = set()
        for source_item in source_voucher.items.order_by("seqno", "id"):
            source_seqnos.add(source_item.seqno)
            changed = cls.sync_invoice_item(source_item) or changed

        extra_items = target_voucher.items.exclude(seqno__in=source_seqnos)
        target_voucher._skip_document_pair_sync = True
        was_registered = cls._maybe_reregister(target_voucher, ar)
        for target_item in extra_items:
            setattr(target_item, "_skip_document_pair_sync", True)
            target_item.delete()

        target_voucher.full_clean()
        target_voucher.save()

        cls._restore_registration(target_voucher, ar, was_registered)

        return changed

    @classmethod
    def other_document(cls, voucher, resolve_expression=False):
        # When used in queryset annotations (e.g. with F/OuterRef), return
        # a SQL expression that resolves to the opposite voucher id.
        if resolve_expression:
            if isinstance(voucher, F):
                voucher = OuterRef(voucher.name)
            return Subquery(
                cls.objects.filter(Q(source_voucher=voucher) | Q(target_voucher=voucher))
                .annotate(
                    other_voucher_id=Case(
                        When(source_voucher=voucher, then=F("target_voucher_id")),
                        default=F("source_voucher_id"),
                    )
                )
                .values("other_voucher_id")[:1]
            )

        other_voucher_id = (
            cls.objects.filter(cls.get_voucher_query(voucher))
            .annotate(
                other_voucher_id=Case(
                    When(source_voucher=voucher, then=F("target_voucher_id")),
                    default=F("source_voucher_id"),
                )
            )
            .values_list("other_voucher_id", flat=True)
            .first()
        )
        if other_voucher_id is None:
            return None
        voucher_model = dd.resolve_model(dd.plugins.ltx.voucher_model)
        return voucher_model.objects.filter(pk=other_voucher_id).first()

    @classmethod
    def exists_for_voucher(cls, voucher):
        return cls.objects.filter(cls.get_voucher_query(voucher)).exists()

    @classmethod
    def get_voucher_query(cls, voucher):
        return Q(source_voucher=voucher) | Q(target_voucher=voucher)

    @classmethod
    def get_voucher_outerref_query(cls, voucher_field_name="voucher"):
        return (
            Q(source_voucher=OuterRef(voucher_field_name))
            | Q(target_voucher=OuterRef(voucher_field_name))
        )


class ChangeSummary(Created):
    class Meta:
        app_label = 'ltx'
        abstract = dd.is_abstract_model(__name__, 'ChangeSummary')
        verbose_name = _("Change summary")
        verbose_name_plural = _("Change summaries")

    voucher = dd.ForeignKey(
        dd.plugins.ltx.voucher_model,
        verbose_name=_("Voucher"),
        related_name='change_summaries',
    )

    pair = dd.ForeignKey(
        "ltx.DocumentPair",
        verbose_name=_("Document pair"),
        related_name="change_summaries",
        null=True,
        blank=True,
    )

    changed_by = dd.ForeignKey(
        "users.User",
        verbose_name=_("Changed by"),
        related_name="ltx_change_summaries",
        null=True,
        blank=True,
    )

    sequence = models.PositiveIntegerField(_("Sequence"), default=1)
    event_type = models.CharField(_("Event type"), max_length=50, blank=True)
    summary = models.CharField(_("Summary"), max_length=200, blank=True)
    changes = models.JSONField(_("Changes"), default=dict, blank=True)
    voucher_snapshot_before = models.JSONField(
        _("Voucher snapshot before"), default=dict, blank=True
    )
    voucher_snapshot_after = models.JSONField(
        _("Voucher snapshot after"), default=dict, blank=True
    )

    @classmethod
    def _link_to_pair_partner(cls, cs):
        """Create a ChangeSummaryVoucherLink for cs.voucher itself (self-link)
        so the link table is the single source of truth for all lookups.
        If the voucher also belongs to a DocumentPair, additionally link the
        pair-partner voucher so both sides share the same history records."""
        VoucherLink = rt.models.ltx.ChangeSummaryVoucherLink
        # Self-link: always create one for the primary voucher
        VoucherLink.objects.get_or_create(change_summary=cs, voucher_id=cs.voucher_id)
        # Pair-partner link
        DocumentPair = rt.models.ltx.DocumentPair
        pair = DocumentPair.get_for_voucher(cs.voucher)
        if pair is None:
            return
        other_id = (
            pair.target_voucher_id
            if pair.source_voucher_id == cs.voucher_id
            else pair.source_voucher_id
        )
        if other_id and other_id != cs.voucher_id:
            VoucherLink.objects.get_or_create(
                change_summary=cs, voucher_id=other_id
            )

    @classmethod
    def _item_map(cls, voucher_payload):
        return {
            int(item.get("seqno")): item
            for item in voucher_payload.get("items", [])
            if item.get("seqno") is not None
        }

    @classmethod
    def _voucher_model(cls):
        return dd.resolve_model(dd.plugins.ltx.voucher_model)

    @classmethod
    def _invoice_item_model(cls):
        return rt.models.trading.InvoiceItem

    @classmethod
    def _label_for_model_field(cls, model, field_name):
        try:
            return str(model._meta.get_field(field_name).verbose_name)
        except Exception:
            return field_name.replace("_", " ")

    @classmethod
    def _voucher_field_label(cls, field_name):
        mapped = {"journal": "journal"}.get(field_name, field_name)
        return cls._label_for_model_field(cls._voucher_model(), mapped)

    @classmethod
    def _item_field_label(cls, field_name):
        mapped = {"product_id": "product"}.get(field_name, field_name)
        return cls._label_for_model_field(cls._invoice_item_model(), mapped)

    @classmethod
    def _normalize_value(cls, value):
        if value is None:
            return None
        return str(value)

    @classmethod
    def _adjust_snapshot_total(cls, snapshot, field_name, delta):
        value = snapshot.get(field_name)
        if value is None:
            return
        snapshot[field_name] = str(Decimal(value) + delta)

    @classmethod
    def _get_product_label(cls, product_id):
        if not product_id:
            return None
        Product = rt.models.products.Product
        product = Product.objects.filter(pk=product_id).first()
        if product is None:
            return None
        return dd.babelattr(product, 'name') or str(product)

    @classmethod
    def _build_voucher_before_snapshot(cls, voucher, cw):
        after_snapshot = rt.models.ltx.DocumentPair._voucher_payload(voucher)
        if cw is None:
            return {}, after_snapshot, True
        # is_created: if cw.original_state has no id, voucher is newly created
        is_created = cw is None or not cw.original_state.get("id")
        if is_created:
            return {}, after_snapshot, True
        before_snapshot = deepcopy(after_snapshot)
        for field_name in [
            "default_discount",
            "total_base",
            "total_vat",
            "total_incl",
        ]:
            if field_name not in cw.original_state:
                continue
            payload_key = field_name
            before_snapshot[payload_key] = cls._normalize_value(
                cw.original_state.get(field_name)
            )
        return before_snapshot, after_snapshot, False

    @classmethod
    def _build_item_before_snapshot(cls, item, cw):
        after_snapshot = rt.models.ltx.DocumentPair._voucher_payload(item.voucher)
        if cw is None:
            return {}, after_snapshot, True
        old_item_id = cw.original_state.get("id")
        old_seqno = cw.original_state.get("seqno")
        is_created = not old_item_id
        before_snapshot = deepcopy(after_snapshot)
        current_seqno = item.seqno
        current_item = cls._item_map(after_snapshot).get(current_seqno, {})
        before_snapshot["items"] = [
            row for row in before_snapshot.get("items", [])
            if row.get("seqno") not in {current_seqno, old_seqno}
        ]
        if not is_created:
            old_item = deepcopy(rt.models.ltx.DocumentPair._item_payload(item))
            old_item["id"] = old_item_id
            for field_name in [
                "seqno",
                "product_id",
                "description",
                "qty",
                "discount_rate",
                "discount_amount",
                "unit_price",
                "total_base",
                "total_vat",
                "total_incl",
            ]:
                if field_name not in cw.original_state:
                    continue
                old_value = cw.original_state.get(field_name)
                if field_name == "product_id":
                    old_item["product_id"] = old_value
                    old_item["product_label"] = cls._get_product_label(old_value)
                else:
                    old_item[field_name] = cls._normalize_value(old_value)
            before_snapshot.setdefault("items", []).append(old_item)
            before_snapshot["items"] = sorted(
                before_snapshot["items"],
                key=lambda row: (
                    (row.get("seqno") is None),
                    str(row.get("seqno")) if row.get("seqno") is not None else "",
                    str(row.get("id")) if row.get("id") is not None else "",
                ),
            )
            for total_field in ["total_base", "total_vat", "total_incl"]:
                new_total = current_item.get(total_field)
                old_total = old_item.get(total_field)
                if new_total is None or old_total is None:
                    continue
                cls._adjust_snapshot_total(
                    after_snapshot,
                    total_field,
                    Decimal(new_total) - Decimal(old_total),
                )
        else:
            for total_field in ["total_base", "total_vat", "total_incl"]:
                item_total = current_item.get(total_field)
                if item_total is None:
                    continue
                cls._adjust_snapshot_total(
                    after_snapshot,
                    total_field,
                    Decimal(item_total),
                )
        return before_snapshot, after_snapshot, is_created

    @classmethod
    def _build_item_delete_snapshots(cls, item):
        before_snapshot = rt.models.ltx.DocumentPair._voucher_payload(item.voucher)
        after_snapshot = deepcopy(before_snapshot)
        deleted_item = cls._item_map(before_snapshot).get(item.seqno, {})
        after_snapshot["items"] = [
            row for row in after_snapshot.get("items", [])
            if row.get("seqno") != item.seqno
        ]
        for total_field in ["total_base", "total_vat", "total_incl"]:
            item_total = deleted_item.get(total_field)
            if item_total is None:
                continue
            cls._adjust_snapshot_total(
                after_snapshot,
                total_field,
                -Decimal(item_total),
            )
        return before_snapshot, after_snapshot

    @classmethod
    def _diff_fields(cls, before_snapshot, after_snapshot, field_names, label_getter):
        changes = []
        for field_name in field_names:
            old_value = before_snapshot.get(field_name)
            new_value = after_snapshot.get(field_name)
            if old_value != new_value:
                changes.append({
                    "field": field_name,
                    "label": label_getter(field_name),
                    "old": old_value,
                    "new": new_value,
                })
        return changes

    @classmethod
    def _create_entry(
        cls,
        voucher,
        event_type,
        summary,
        changes,
        user=None,
        pair=None,
        voucher_snapshot_before=None,
        voucher_snapshot_after=None,
    ):
        logger.debug(f"_create_entry: voucher={voucher.id}, event_type={event_type}, user={user}")
        cs = cls(
            voucher=voucher,
            pair=pair,
            changed_by=user,
            sequence=(
                cls.objects.filter(voucher=voucher)
                .order_by("-sequence")
                .values_list("sequence", flat=True)
                .first() or 0
            ) + 1,
            event_type=event_type,
            summary=summary,
            changes=changes or {},
            voucher_snapshot_before=voucher_snapshot_before or {},
            voucher_snapshot_after=voucher_snapshot_after or {},
        )
        cs.full_clean()
        cs.save()
        logger.debug(f"_create_entry: saved ChangeSummary {cs.id} for voucher {voucher.id}")
        cls._link_to_pair_partner(cs)
        return cs

    @classmethod
    def log_voucher_update(cls, voucher, cw, ar=None, user=None):
        before_snapshot, after_snapshot, is_created = cls._build_voucher_before_snapshot(
            voucher, cw
        )
        if before_snapshot == after_snapshot and not is_created:
            return None
        changes = cls._diff_fields(
            before_snapshot,
            after_snapshot,
            ["default_discount", "total_base", "total_vat", "total_incl"],
            cls._voucher_field_label,
        )
        return cls._create_entry(
            voucher=voucher,
            event_type="voucher_created" if is_created else "voucher_updated",
            summary=(
                _("Tracked voucher creation.")
                if is_created
                else _("Tracked voucher changes.")
            ),
            changes={"fields": changes},
            user=user,
            voucher_snapshot_before=before_snapshot,
            voucher_snapshot_after=after_snapshot,
        )

    @classmethod
    def log_invoice_item_update(cls, item, cw, ar=None, user=None):
        before_snapshot, after_snapshot, is_created = cls._build_item_before_snapshot(
            item, cw
        )
        if before_snapshot == after_snapshot and not is_created:
            return None
        before_items = cls._item_map(before_snapshot)
        after_items = cls._item_map(after_snapshot)
        previous_item = before_items.get(cw.original_state.get("seqno") if cw is not None else item.seqno)
        current_item = after_items.get(item.seqno)
        field_changes = []
        for field_name in [
            "product_id",
            "description",
            "qty",
            "discount_rate",
            "discount_amount",
            "unit_price",
            "total_base",
            "total_vat",
            "total_incl",
        ]:
            old_value = (previous_item or {}).get(field_name)
            new_value = (current_item or {}).get(field_name)
            if old_value == new_value:
                continue
            if field_name == "product_id":
                old_value = (previous_item or {}).get("product_label") or old_value
                new_value = (current_item or {}).get("product_label") or new_value
            field_changes.append({
                "field": field_name,
                "label": cls._item_field_label(field_name),
                "old": old_value,
                "new": new_value,
            })
        return cls._create_entry(
            voucher=item.voucher,
            event_type="item_created" if is_created else "item_updated",
            summary=(
                _("Tracked invoice item creation.")
                if is_created
                else _("Tracked invoice item changes.")
            ),
            changes={
                "seqno": item.seqno,
                "product": (current_item or {}).get("product_label"),
                "fields": field_changes,
            },
            user=user,
            voucher_snapshot_before=before_snapshot,
            voucher_snapshot_after=after_snapshot,
        )

    @classmethod
    def log_invoice_item_deletion(cls, item, user=None):
        before_snapshot, after_snapshot = cls._build_item_delete_snapshots(item)
        old_item = cls._item_map(before_snapshot).get(item.seqno, {})
        return cls._create_entry(
            voucher=item.voucher,
            event_type="item_deleted",
            summary=_("Tracked invoice item deletion."),
            changes={
                "seqno": item.seqno,
                "product": old_item.get("product_label"),
            },
            user=user,
            voucher_snapshot_before=before_snapshot,
            voucher_snapshot_after=after_snapshot,
        )

    @classmethod
    def inherit_voucher_history(cls, source_voucher, target_voucher, pair=None, user=None):
        """Link existing source_voucher ChangeSummaries to target_voucher via
        ChangeSummaryVoucherLink so both vouchers share the same records without
        copying. The newly created target_voucher does not get its own creation
        ChangeSummary; it only sees the inherited source history."""
        VoucherLink = rt.models.ltx.ChangeSummaryVoucherLink
        # Guard: already linked / inherited
        # if VoucherLink.objects.filter(voucher=target_voucher).exists():
        #     return
        # source_changes = cls.objects.filter(voucher=source_voucher).order_by("sequence", "id")
        # # Link every existing source ChangeSummary to target_voucher.
        # # If source has no history yet, target starts with no history too
        # # and will see source's history once it's created.
        # for source_change in source_changes:
        #     VoucherLink.objects.get_or_create(
        #         change_summary=source_change,
        #         voucher=target_voucher,
        #     )
        for voucher_link in source_voucher.linked_change_summaries.all():
            # cls._link_to_pair_partner(source_change)
            VoucherLink.objects.get_or_create(
                change_summary=voucher_link.change_summary,
                voucher=target_voucher,
            )

    @classmethod
    def update_pair_references_on_creation(cls, pair):
        """After creating a DocumentPair, update existing ChangeSummaries for the
        source_voucher to reference the newly created pair and set source/target
        voucher references. This ensures pre-pair ChangeSummaries know about the
        sync relationship and can respect is_sync_source logic."""
        # Update existing ChangeSummaries for the source voucher to reference the pair
        sync_source_voucher = pair.get_sync_source_voucher()
        source_changes = cls.objects.filter(
            voucher=pair.source_voucher,
            pair__isnull=True,
        )
        source_changes.update(voucher=sync_source_voucher, pair=pair)

    @classmethod
    def diff_between(cls, older, newer):
        old_after = older.voucher_snapshot_after or {}
        new_after = newer.voucher_snapshot_after or {}

        result = {
            "from_change": older.sequence,
            "to_change": newer.sequence,
            "voucher": str(newer.voucher),
            "voucher_changes": [],
            "item_changes": [],
        }

        result["voucher_changes"] = cls._diff_fields(
            old_after,
            new_after,
            ["default_discount", "total_base", "total_vat", "total_incl"],
            cls._voucher_field_label,
        )

        def collect_item_changes(old_payload, new_payload):
            old_map = cls._item_map(old_payload)
            new_map = cls._item_map(new_payload)
            seqnos = sorted(set(old_map.keys()) | set(new_map.keys()))
            for seqno in seqnos:
                old_item = old_map.get(seqno)
                new_item = new_map.get(seqno)
                if old_item is None:
                    result["item_changes"].append({
                        "seqno": seqno,
                        "product_id": (new_item or {}).get("product_id"),
                        "product": (new_item or {}).get("product_label"),
                        "change": str(_("Created")),
                        "new": new_item,
                    })
                    continue
                if new_item is None:
                    result["item_changes"].append({
                        "seqno": seqno,
                        "product_id": (old_item or {}).get("product_id"),
                        "product": (old_item or {}).get("product_label"),
                        "change": str(_("Deleted")),
                        "old": old_item,
                    })
                    continue
                fields = {}
                for fld in [
                    "product_id",
                    "description",
                    "qty",
                    "discount_rate",
                    "discount_amount",
                    "unit_price",
                    "total_base",
                    "total_vat",
                    "total_incl",
                ]:
                    if old_item.get(fld) != new_item.get(fld):
                        old_value = old_item.get(fld)
                        new_value = new_item.get(fld)
                        fields[fld] = {
                            "label": cls._item_field_label(fld),
                            "old": old_value,
                            "new": new_value,
                        }
                if fields:
                    result["item_changes"].append({
                        "seqno": seqno,
                        "product_id": new_item.get("product_id") or old_item.get("product_id"),
                        "product": new_item.get("product_label") or old_item.get("product_label"),
                        "change": str(_("Updated")),
                        "fields": fields,
                    })

        collect_item_changes(old_after, new_after)
        return result


class ChangeSummaryVoucherLink(dd.Model):
    """Maps a ChangeSummary to an additional voucher (e.g. the pair partner)
    so both vouchers share the same history records without copying rows."""

    allow_cascaded_delete = ["voucher", "change_summary"]
    allow_cascaded_copy = set([])

    class Meta:
        app_label = 'ltx'
        abstract = dd.is_abstract_model(__name__, 'ChangeSummaryVoucherLink')
        verbose_name = _("Change summary voucher link")
        verbose_name_plural = _("Change summary voucher links")
        unique_together = [('change_summary', 'voucher')]

    change_summary = dd.ForeignKey(
        "ltx.ChangeSummary",
        verbose_name=_("Change summary"),
        related_name="extra_voucher_links",
        on_delete=models.CASCADE,
    )

    voucher = dd.ForeignKey(
        dd.plugins.ltx.voucher_model,
        verbose_name=_("Voucher"),
        related_name="linked_change_summaries",
        on_delete=models.CASCADE,
    )


class CompareSelectedChanges(dd.Action):
    label = _("Compare selected changes")
    button_text = "Δ"
    select_rows = True
    show_in_bbar = True
    never_collapse = True

    @staticmethod
    def _fmt(value):
        if value in (None, ""):
            return "-"
        if isinstance(value, bool):
            return str(value)
        if isinstance(value, (int, float, Decimal)):
            return localize_number(value)
        if isinstance(value, str):
            try:
                numeric = Decimal(value)
            except Exception:
                return value
            return localize_number(numeric)
        return str(value)

    @staticmethod
    def _get_master_voucher(ar):
        """Resolve the effective voucher from the current master context.

        If master_instance is a BoxedDocument, use its .voucher; otherwise
        treat master_instance itself as a voucher.
        """
        master = ar.master_instance
        if master is None:
            return None
        return getattr(master, "voucher", master)

    @classmethod
    def _have_matching_voucher_link(cls, ar, older, newer):
        """Return True when both changes are linked to the same voucher.

        Prefer the voucher from master_instance when available. If unknown,
        accept any shared voucher link between both change summaries.
        """
        VoucherLink = rt.models.ltx.ChangeSummaryVoucherLink
        master_voucher = cls._get_master_voucher(ar)
        if master_voucher is not None:
            voucher_id = getattr(master_voucher, "pk", None)
            if voucher_id is None:
                return False
            return (
                VoucherLink.objects.filter(
                    change_summary=older,
                    voucher_id=voucher_id,
                ).exists()
                and VoucherLink.objects.filter(
                    change_summary=newer,
                    voucher_id=voucher_id,
                ).exists()
            )

        newer_voucher_ids = VoucherLink.objects.filter(
            change_summary=newer
        ).values("voucher_id")
        return VoucherLink.objects.filter(
            change_summary=older,
            voucher_id__in=Subquery(newer_voucher_ids),
        ).exists()

    @classmethod
    def _get_related_voucher_for_compare(cls, ar, older, newer):
        """Resolve the voucher that represents this comparison context.

        Prefer the voucher from master_instance when available. Otherwise,
        return one voucher shared by both change summaries via VoucherLink.
        """
        master_voucher = cls._get_master_voucher(ar)
        if getattr(master_voucher, "pk", None) is not None:
            return master_voucher

        VoucherLink = rt.models.ltx.ChangeSummaryVoucherLink
        shared_voucher_id = (
            VoucherLink.objects.filter(change_summary=older)
            .filter(
                voucher_id__in=Subquery(
                    VoucherLink.objects.filter(change_summary=newer).values("voucher_id")
                )
            )
            .order_by("voucher_id")
            .values_list("voucher_id", flat=True)
            .first()
        )
        if not shared_voucher_id:
            return None

        Voucher = dd.resolve_model(dd.plugins.ltx.voucher_model)
        return Voucher.objects.filter(pk=shared_voucher_id).first()

    @staticmethod
    def _product_text(product_id):
        if not product_id:
            return "-"
        Product = rt.models.products.Product
        product = Product.objects.filter(pk=product_id).first()
        if product is None:
            return str(product_id)
        return str(product)

    @classmethod
    def _localize_diff_products(cls, diff):
        """Replace snapshot product labels with live, translated product names."""
        for item_change in diff.get("item_changes", []):
            product_id = item_change.get("product_id")
            if product_id is None:
                if item_change.get("new"):
                    product_id = (item_change.get("new") or {}).get("product_id")
                elif item_change.get("old"):
                    product_id = (item_change.get("old") or {}).get("product_id")
            item_change["product"] = cls._product_text(product_id)

            fields = item_change.get("fields")
            if isinstance(fields, dict) and "product_id" in fields:
                pf = fields["product_id"]
                pf["old"] = cls._product_text(pf.get("old"))
                pf["new"] = cls._product_text(pf.get("new"))

    @classmethod
    def _render_fields_table(cls, fields):
        if not fields:
            return ""

        lbl_field = str(_("Field"))
        lbl_old = str(_("Old"))
        lbl_new = str(_("New"))

        rows = []
        values = fields.values() if isinstance(fields, dict) else fields
        for field in values:
            label = escape(cls._fmt(field.get("label") or field.get("field")))
            old_value = escape(cls._fmt(field.get("old")))
            new_value = escape(cls._fmt(field.get("new")))
            rows.append(
                "<tr>"
                f"<td data-label='{lbl_field}'>{label}</td>"
                f"<td data-label='{lbl_old}'>{old_value}</td>"
                f"<td data-label='{lbl_new}'>{new_value}</td>"
                "</tr>"
            )

        return (
            "<div class='ltx-table-wrap ltx-nested-wrap'>"
            "<table class='ltx-table ltx-nested'>"
            f"<thead><tr><th>{lbl_field}</th><th>{lbl_old}</th><th>{lbl_new}</th></tr></thead>"
            f"<tbody>{''.join(rows)}</tbody>"
            "</table>"
            "</div>"
        )

    @classmethod
    def _render_diff_html(cls, diff):
        lbl_field = str(_("Field"))
        lbl_old = str(_("Old"))
        lbl_new = str(_("New"))
        lbl_seq = str(_("Seq"))
        lbl_product = str(_("Product"))
        lbl_change = str(_("Change"))
        lbl_details = str(_("Details"))
        lbl_info = str(_("Info"))
        lbl_voucher = str(_("Voucher"))
        lbl_from_change = str(_("From Change"))
        lbl_to_change = str(_("To Change"))
        lbl_voucher_changes = str(_("Voucher changes"))
        lbl_item_changes = str(_("Item changes"))
        msg_created_item = str(_("Created item."))
        msg_deleted_item = str(_("Deleted item."))
        msg_no_field_details = str(_("No field-level details."))
        msg_no_voucher_changes = str(_("No voucher-level changes."))
        msg_no_item_changes = str(_("No item-level changes."))

        voucher_rows = []
        for change in diff.get("voucher_changes", []):
            label = escape(cls._fmt(change.get("label") or change.get("field")))
            old_value = escape(cls._fmt(change.get("old")))
            new_value = escape(cls._fmt(change.get("new")))
            voucher_rows.append(
                "<tr>"
                f"<td data-label='{lbl_field}'>{label}</td>"
                f"<td data-label='{lbl_old}'>{old_value}</td>"
                f"<td data-label='{lbl_new}'>{new_value}</td>"
                "</tr>"
            )

        item_rows = []
        for item_change in diff.get("item_changes", []):
            seqno = escape(cls._fmt(item_change.get("seqno")))
            product = escape(cls._fmt(item_change.get("product")))
            change_type = escape(cls._fmt(item_change.get("change")))
            details_html = cls._render_fields_table(item_change.get("fields"))
            if not details_html:
                if item_change.get("new"):
                    details_html = f"<div class='ltx-muted'>{escape(msg_created_item)}</div>"
                elif item_change.get("old"):
                    details_html = f"<div class='ltx-muted'>{escape(msg_deleted_item)}</div>"
                else:
                    details_html = f"<div class='ltx-muted'>{escape(msg_no_field_details)}</div>"

            item_rows.append(
                "<tr>"
                f"<td data-label='{lbl_seq}'>{seqno}</td>"
                f"<td data-label='{lbl_product}'>{product}</td>"
                f"<td data-label='{lbl_change}'>{change_type}</td>"
                f"<td data-label='{lbl_details}'>{details_html}</td>"
                "</tr>"
            )

        empty_voucher_row = f'<tr><td colspan="3" data-label="{lbl_info}">{escape(msg_no_voucher_changes)}</td></tr>'
        voucher_table = (
            "<div class='ltx-table-wrap'>"
            "<table class='ltx-table'>"
            f"<thead><tr><th>{lbl_field}</th><th>{lbl_old}</th><th>{lbl_new}</th></tr></thead>"
            f"<tbody>{''.join(voucher_rows) if voucher_rows else empty_voucher_row}</tbody>"
            "</table>"
            "</div>"
        )

        empty_item_row = f'<tr><td colspan="4" data-label="{lbl_info}">{escape(msg_no_item_changes)}</td></tr>'
        item_table = (
            "<div class='ltx-table-wrap'>"
            "<table class='ltx-table'>"
            f"<thead><tr><th>{lbl_seq}</th><th>{lbl_product}</th><th>{lbl_change}</th><th>{lbl_details}</th></tr></thead>"
            f"<tbody>{''.join(item_rows) if item_rows else empty_item_row}</tbody>"
            "</table>"
            "</div>"
        )

        return mark_safe(
            "<style>"
            ".ltx-diff{"
            "font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;"
            "font-size:13px;line-height:1.45;"
            "color:var(--text-color-lino,var(--text-color,#1f2937));}"
            ".ltx-meta{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;margin:0 0 12px 0;}"
            ".ltx-meta .card{"
            "border:1px solid var(--surface-border,#e5e7eb);"
            "border-radius:8px;padding:8px 10px;"
            "background:var(--surface-section,var(--surface-100,#f9fafb));}"
            ".ltx-meta .k{"
            "display:block;font-size:11px;"
            "color:var(--text-color-secondary,#6b7280);"
            "text-transform:uppercase;letter-spacing:.04em;}"
            ".ltx-meta .v{"
            "display:block;font-weight:600;margin-top:2px;"
            "color:var(--text-color-lino,var(--text-color,#111827));}"
            ".ltx-section{"
            "margin:12px 0 8px 0;font-weight:700;"
            "color:var(--text-color-lino,var(--text-color,#111827));}"
            ".ltx-table-wrap{"
            "overflow-x:auto;-webkit-overflow-scrolling:touch;"
            "border:1px solid var(--surface-border,#e5e7eb);"
            "border-radius:8px;"
            "background:var(--surface-card,var(--surface-0,#fff));}"
            ".ltx-table{width:100%;border-collapse:collapse;min-width:540px;}"
            ".ltx-table th,.ltx-table td{"
            "padding:8px 10px;"
            "border-bottom:1px solid var(--surface-border,#eef2f7);"
            "text-align:left;vertical-align:top;"
            "color:var(--text-color-lino,var(--text-color,inherit));}"
            ".ltx-table th{"
            "background:var(--surface-section,var(--surface-50,#f8fafc));"
            "font-weight:700;}"
            ".ltx-table tr:last-child td{border-bottom:none;}"
            ".ltx-nested-wrap{"
            "margin:4px 0;"
            "border-color:var(--primary-200,var(--primary-color,#dbeafe));}"
            ".ltx-nested{min-width:420px;}"
            ".ltx-muted{color:var(--text-color-secondary,#6b7280);}"
            "@media (max-width: 768px){"
            ".ltx-table{min-width:100%;}"
            ".ltx-table thead{display:none;}"
            ".ltx-table tr{display:block;border-bottom:1px solid var(--surface-border,#eef2f7);padding:8px 0;}"
            ".ltx-table td{display:flex;gap:8px;justify-content:space-between;align-items:flex-start;border-bottom:none;padding:6px 10px;}"
            ".ltx-table td::before{content:attr(data-label);font-weight:700;color:var(--text-color-secondary,#4b5563);min-width:90px;flex:0 0 90px;}"
            ".ltx-nested td::before{min-width:70px;flex:0 0 70px;}"
            "}"
            "</style>"
            "<div class='ltx-diff'>"
            "<div class='ltx-meta'>"
            f"<div class='card'><span class='k'>{lbl_voucher}</span><span class='v'>{escape(cls._fmt(diff.get('voucher')))}</span></div>"
            f"<div class='card'><span class='k'>{lbl_from_change}</span><span class='v'>{escape(cls._fmt(diff.get('from_change')))}</span></div>"
            f"<div class='card'><span class='k'>{lbl_to_change}</span><span class='v'>{escape(cls._fmt(diff.get('to_change')))}</span></div>"
            "</div>"
            f"<div class='ltx-section'>{lbl_voucher_changes}</div>"
            f"{voucher_table}"
            f"<div class='ltx-section'>{lbl_item_changes}</div>"
            f"{item_table}"
            "</div>"
        )

    def run_from_ui(self, ar, **kwargs):
        if len(ar.selected_rows) != 2:
            ar.error(_("Please select exactly two change records to compare."))
            return

        older, newer = sorted(ar.selected_rows, key=lambda cs: cs.sequence)

        custom_uid = (
            f"compare_voucher_changes_{older._meta.verbose_name}#"
            f"{older.pk}-#{newer.pk} user#{ar.get_user().pk}"
        )
        answer = ar.xcallback_answers.get("xcallback__" + custom_uid, None)
        if answer:
            ar.set_response(close_window=True)
            ar.success()
            return

        if not self._have_matching_voucher_link(ar, older, newer):
            ar.error(_("Selected changes must share a matching voucher link."))
            return

        diff = rt.models.ltx.ChangeSummary.diff_between(older, newer)
        related_voucher = self._get_related_voucher_for_compare(ar, older, newer)
        if related_voucher is not None:
            diff["voucher"] = str(related_voucher)
        self._localize_diff_products(diff)
        text = self._render_diff_html(diff)

        cb = ar.add_callback(text, uid=custom_uid)
        cb.set_title(_("Voucher comparison"))
        cb.add_choice("yes", lambda ar: None, _("Done"))
        ar.set_callback(cb)


class ChangeSummaries(dd.Table):
    model = "ltx.ChangeSummary"
    column_names = (
        "rowselect sequence event_type summary changed_by *"
    )
    order_by = ["-created", "-id"]
    editable = False
    allow_create = False
    allow_delete = False

    required_roles = dd.login_required(dd.SiteStaff)

    compare_selected_changes = CompareSelectedChanges()


class ChangeSummariesByVoucher(ChangeSummaries):
    master_key = "voucher"

    @classmethod
    def get_request_queryset(cls, ar, **filter):
        master = ar.master_instance
        if master is None:
            return cls.model.objects.none()
        return cls.model.objects.filter(
            Q(voucher=master) | Q(extra_voucher_links__voucher=master)
        ).distinct().order_by(*cls.order_by)


class ChangeSummariesByOutboundDocument(ChangeSummaries):
    """History panel for an OutboundDocument detail. The master instance
    is the OutboundDocument itself; changes are looked up through
    ChangeSummaryVoucherLink (which now always has a self-link entry for
    the primary voucher as well as the pair-partner voucher)."""
    master = "ltx.OutboundDocument"
    required_roles = dd.login_required(LedgerUser)

    @classmethod
    def get_request_queryset(cls, ar, **filter):
        master = ar.master_instance
        if master is None:
            return cls.model.objects.none()
        qs = super().get_request_queryset(ar, **filter).filter(
            extra_voucher_links__voucher=master.voucher
        ).distinct()  # .order_by(*cls.order_by)
        return qs


class ChangeSummariesByInboundDocument(ChangeSummariesByOutboundDocument):
    master = "ltx.InboundDocument"


class ChangeSummariesByPair(ChangeSummaries):
    master_key = "pair"


@schedule_often()
def put_to_inbox(ar):
    """Map outbox to inbox."""
    inbound_document_model = rt.models.ltx.InboundDocument
    voucher_model = dd.resolve_model(dd.plugins.ltx.voucher_model)
    User = settings.SITE.user_model
    gfks = dd.is_installed("gfks")
    contenttype_model = rt.models.gfks.ContentType if gfks else None
    for voucher in voucher_model.objects.filter(
        ltx_outbound_document__isnull=False,
        ltx_inbound_document__isnull=True,
    ):
        ib = inbound_document_model(voucher=voucher)
        ib.partner = getattr(
            voucher,
            "get_inbox_partner",
            lambda ar: voucher.partner.company,
        )(ar)
        ib.full_clean()
        ib.save_new_instance(
            ib.get_default_table().create_request(parent=ar)
        )

        if gfks:

            users = User.objects.filter(ledger__company=voucher.partner.company)
            recipients = [
                (user, user.mail_mode)
                for user in users
                if user.has_required_roles([LedgerUser])
            ]
            cls = rt.models.ltx.InboundDocumentsByPartner
            sar = cls.create_request(parent=ar, master_instance=voucher.partner.company)

            def msg_func(user):
                with override(user.language or get_language()):
                    subject = gettext(
                        "Incoming document to your inbox: {0}").format(str(voucher))

                    params = {
                        constants.URL_PARAM_MASTER_PK: voucher.partner.pk,
                        constants.URL_PARAM_MASTER_TYPE: contenttype_model.objects.get_for_model(
                            voucher.partner.__class__).pk,
                    }
                    if not user.has_usable_password():
                        params[constants.URL_PARAM_SUBST_USER] = user.pk

                    permalink = "{}{}".format(
                        settings.SITE.server_url,
                        ar.renderer.get_detail_url(ar, cls, ib.pk, **params),
                    )
                    doc_ = format_html('<a href="{}">{}</a>', permalink, str(voucher))
                    body = gettext(
                        "Incoming document {0} requires your attention.").format(doc_)
                    body = mark_safe("<p>{0}</p>".format(body))
                    return (subject, body)

            rt.models.notify.Message.emit_notification(
                sar, ib, MessageTypes.document_followup, msg_func, recipients
            )
