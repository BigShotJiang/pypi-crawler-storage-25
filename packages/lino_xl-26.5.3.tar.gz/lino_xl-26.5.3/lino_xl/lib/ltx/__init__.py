# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import ad, _


class Plugin(ad.Plugin):
    verbose_name = _("Trading eXchange")
    voucher_model = "trading.VatProductInvoice"
    sync_source_journal_suffixes = ("SSN",)
    # Maps a journal suffix to its paired journal suffix.
    # e.g. {"POR": "SSN", "SSN": "POR"} means POR <-> SSN pairing.
    journal_pair_map = {"POR": "SSN", "SSN": "POR"}

    needs_plugins = ["lino_xl.lib.ledgers"]

    def post_site_startup(self, site):
        r = super().post_site_startup(site)
        from lino_xl.lib.ltx.mixins import ExchangableVoucher
        if not issubclass(site.resolve_model(self.voucher_model), ExchangableVoucher):
            raise Exception(
                f"The voucher model {self.voucher_model} must inherit from ExchangableVoucher."
            )
        return r
