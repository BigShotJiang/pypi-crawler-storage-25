# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from django.conf import settings
from django.utils.html import mark_safe, format_html
from django.utils.translation import gettext, override, get_language
from lino.api import dd, rt, _
from lino.core import constants
from lino.modlib.notify.choicelists import MessageTypes
from lino_xl.lib.accounting.roles import LedgerUser


class VoucherActionStates(dd.Workflow):
    """Generic workflow for documents that require an approval-like action."""

    @classmethod
    def get_column_names(cls, ar):
        return "value name text button_text"

    @classmethod
    def reject_my_own_document(cls, obj, ar):
        """Helper method to reject a document from the same company."""
        ib = rt.models.ltx.InboundDocument.objects.get(
            voucher=rt.models.ltx.DocumentPair.other_document(obj.voucher))
        if ib.state != cls.rejected:
            ib.remark += "<p>" + _(
                "This document was automatically rejected because "
                "the related document was rejected.") + "</p>"
            ib.remark += "<p>" + _("Related documnet says:") + "</p>"
            ib.remark += obj.remark
            ib.full_clean()
            ib.save()
            sar = ar.bound_action.create_request(parent=ar, selected_rows=[ib])
            cls.rejected.transition.run_from_ui(sar)

    @classmethod
    def before_state_change(cls, obj, ar, oldstate, newstate):
        r = super().before_state_change(obj, ar, oldstate, newstate)
        OutboundDocument = rt.models.ltx.OutboundDocument
        ob = OutboundDocument.objects.get(voucher=obj.voucher)
        if newstate == cls.rejected:
            if ob.payment_done or ob.delivered:
                raise Exception(_(
                    "Cannot reject a document that has already been delivered or paid."))
            if not obj.remark or obj.remark.strip() == "":
                raise Exception(_("A remark is required to reject a document."))
        return r

    @classmethod
    def after_state_change(cls, obj, ar, oldstate, newstate):
        r = super().after_state_change(obj, ar, oldstate, newstate)
        notify_msg = ""
        if newstate == cls.acknowledged:
            obj.voucher.on_partners_acknowledgement(ar, oldstate)
            notify_msg = _("Document {doc} has been acknowledged.")
        elif newstate == cls.rejected:
            obj.voucher.on_partners_rejection(ar, oldstate)
            notify_msg = _("Document {doc} has been rejected.")
        elif newstate == cls.pending:
            obj.voucher.on_partners_decision_pending(ar, oldstate)
            notify_msg = _("Document {doc} is pending decision.")
        else:
            raise Exception(_("Unhandled state change: {0}").format(newstate))

        if oldstate == cls.pending:
            pv = ar.param_values.copy()
            if pv.get("state") == cls.pending:
                pv["state"] = None
            sar = ar.bound_action.create_request(parent=ar)
            sar.param_values = pv
            if "state" in sar.known_values and sar.known_values["state"] == cls.pending:
                del sar.known_values["state"]
            status = ar.get_status().copy()
            if "base_params" in status and "state" in status["base_params"]:
                del status["base_params"]["state"]
            sar._status = status
            js = sar.renderer.instance_handler(sar, obj, None)
            ar.set_response(eval_js=js)

        # We want to notify against source voucher only.
        dp = rt.models.ltx.DocumentPair.get_for_voucher(obj.voucher)
        if dp and dp.target_voucher == obj.voucher:
            return r

        # Send notification to original requester
        users = rt.models.users.User.objects.filter(
            ledger=obj.voucher.journal.ledger
        )
        recipients = [
            (user, user.mail_mode)
            for user in users
            if user.has_required_roles([LedgerUser])
        ]

        doc = rt.models.ltx.OutboundDocument.objects.get(voucher=obj.voucher)

        actor = rt.models.ltx.OutboundDocumentsByPartner
        sar = actor.create_request(parent=ar, master_instance=doc.partner)

        def msg_func(user):
            with override(user.language or get_language()):
                subject = gettext(notify_msg).format(doc=obj.voucher)

                params = {
                    constants.URL_PARAM_MASTER_PK: sar.master_instance.pk,
                    constants.URL_PARAM_MASTER_TYPE: rt.models.gfks.ContentType.objects
                    .get_for_model(sar.master_instance.__class__).pk,
                }
                if not user.has_usable_password():
                    params[constants.URL_PARAM_SUBST_USER] = user.pk
                permalink = "{}{}".format(
                    settings.SITE.server_url,
                    ar.renderer.get_detail_url(ar, actor, doc.pk, **params),
                )
                obj_url = format_html(
                    '<a href="{}">{}</a>', permalink, str(doc)
                )

                body = gettext("Your document ({0})'s state has been set to {1}").format(
                    obj_url, newstate.text
                )
                body = mark_safe("<p>{}</p>".format(body))
                return (subject, body)

        rt.models.notify.Message.emit_notification(
            sar, doc, MessageTypes.document_followup, msg_func, recipients
        )

        ar.set_response(refresh=True)
        return r


add = VoucherActionStates.add_item
add("10", _("Pending"), "pending")
add("20", _("Acknowledged"), "acknowledged")
# add('20', _("Approved"), 'approved')
add("30", _("Rejected"), "rejected")
# add('40', _("Completed"), 'completed')

VoucherActionStates.pending.add_transition(
    _("Pending"),
    button_text="⏳",
    show_in_toolbar=True,
    readonly=True,
    help_text=_("Mark this document as pending"),
    never_collapse=True,
)

VoucherActionStates.rejected.add_transition(
    _("Reject"),
    required_states="pending",
    button_text="✗",
    show_in_toolbar=True,
    readonly=True,
    help_text=_("Reject this document"),
    never_collapse=True,
)

VoucherActionStates.acknowledged.add_transition(
    _("Acknowledge"),
    required_states="pending",
    button_text="✓✓",
    show_in_toolbar=True,
    readonly=True,
    help_text=_("Acknowledge the availability of this document"),
    never_collapse=True,
)
