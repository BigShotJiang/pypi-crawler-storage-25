# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import dd, rt, _
from lino.utils.mti import get_child, insert_child, delete_child


def get_partners_obd_js(ar, voucher):
    """Return the JavaScript to open the OutboundDocumentsByPartner for the given voucher."""
    DocumentPair = rt.models.ltx.DocumentPair
    OutboundDocument = rt.models.ltx.OutboundDocument
    sar = rt.models.ltx.OutboundDocumentsByPartner.create_request(
        parent=ar,
        master_instance=ar.get_user().ledger.company,
    )
    ob = OutboundDocument.objects.get(voucher=DocumentPair.other_document(voucher))
    return sar.renderer.instance_handler(sar, ob, None)


def make_document_pair(ar, obj):
    """Action to create a document pair between an outbound and inbound document.

    Potentially creates an outbound document if there is none.
    """
    Journal = rt.models.accounting.Journal
    DocumentPair = rt.models.ltx.DocumentPair
    OutboundDocument = rt.models.ltx.OutboundDocument

    if not isinstance(obj, rt.models.ltx.InboundDocument):
        ar.error(_("This action can only be run on inbound documents."))
        return

    user = ar.get_user()

    if obj.has_document_pair():
        ar.set_response(eval_js=get_partners_obd_js(ar, obj.voucher))
        return


    if not user.ledger:
        ar.error(_("User must have a ledger assigned to create document pairs."))
        return

    document = obj.voucher

    if document.partner != user.ledger.company.partner_ptr:
        ar.error(_(
            "User can only create document pairs for documents related to their own company."
        ))
        return

    ref = document.journal.ref
    journal_pair_map = {
        k.upper(): v.upper() for k, v in (dd.plugins.ltx.journal_pair_map or {}).items()
    }
    matched_suffix = next(
        (suffix for suffix in journal_pair_map if ref.upper().endswith(suffix)), None
    )
    if matched_suffix is not None:
        paired_suffix = journal_pair_map[matched_suffix]
        outbound_journals = Journal.objects.filter(
            ledger=user.ledger,
            ref__iendswith=paired_suffix,
        )
        if not outbound_journals.exists():
            ar.error(
                _("No journal ending with '{0}' found for ledger {1}.").format(
                    paired_suffix, user.ledger
                )
            )
            return
        outbound_journal = outbound_journals.get()

        mti_child_created = False

        if (doc_model := outbound_journal.get_doc_model()) is document.__class__:
            d_obj = document
        else:
            assert issubclass(doc_model, document.__class__), _(
                "Journal {outbound_journal} has incompatible document model {doc_model} "
                "for source document {document} of type {document_class}"
            ).format(outbound_journal=outbound_journal, doc_model=doc_model,
                     document=document, document_class=document.__class__)
            d_obj = get_child(document, doc_model) or insert_child(document, doc_model)
            mti_child_created = True

        sar = ar.bound_action.create_request(parent=ar)
        outbound_document = d_obj.clone_row.run_from_code(
            sar, journal=outbound_journal, entry_date=dd.today(), state="draft",
            partner=document.journal.ledger.company, user=user)
        outbound_document._skip_document_pair_sync = True

        if mti_child_created:
            # outbound_document = insert_child(outbound_document, CashInvoice)
            delete_child(document, doc_model)

            if outbound_document.items.count() == 0 and document.items.count() > 0:
                for item in document.items.all():
                    item.clone_row.run_from_code(sar, voucher=outbound_document)
        else:
            outbound_document.register(ar)

        ob = OutboundDocument(
            voucher=outbound_document, partner=user.ledger.company)
        ob.full_clean()
        ob.save_new_instance(ob.get_default_table().create_request(parent=ar))

        dp = DocumentPair(source_voucher=document, target_voucher=outbound_document)
        dp.full_clean()
        dp.save_new_instance(dp.get_default_table().create_request(parent=ar))

        # Update existing ChangeSummaries for the source voucher to reference the new pair
        rt.models.ltx.ChangeSummary.update_pair_references_on_creation(dp)

        rt.models.ltx.ChangeSummary.inherit_voucher_history(
            document,
            outbound_document,
            pair=dp,
            user=user,
        )

        return dp


class MakeDocumentPair(dd.Action):
    """Action to create a document pair between an outbound and inbound document."""

    label = _("Create document pair")
    button_text = "🔗"
    show_in_toolbar = True
    never_collapse = True
    select_rows = True

    def run_from_ui(self, ar, **kwargs):
        obj = ar.selected_rows[0]
        if len(ar.selected_rows) > 1:
            ar.error(_("Please select only one document to create a document pair."))
            return

        if obj.state != rt.models.ltx.VoucherActionStates.acknowledged:
            ar.error(_("Document pair can only be created for acknowledged documents."))
            return

        dp = make_document_pair(ar, obj)
        if dp:
            ar.success(_("Document pair created successfully."))
            ar.set_response(eval_js=get_partners_obd_js(ar, obj.voucher))


class MarkDelivered(dd.Action):
    """Action to mark an inbound document as delivered."""

    label = _("Mark as delivered")
    button_text = "📬"
    show_in_toolbar = True
    never_collapse = True
    select_rows = True

    def run_from_ui(self, ar, **kwargs):
        msg = ""

        delivery_note = None

        for obj in ar.selected_rows:
            if not isinstance(obj, rt.models.ltx.OutboundDocument):
                ar.error(_("This action can only be run on outbound documents."))
                continue

            if obj.delivered:
                ar.info(_("Document is already marked as delivered."))
                continue

            partners_box_entry = rt.models.ltx.InboundDocument.objects.filter(
                voucher=obj.voucher).first()

            delivery_note = obj.voucher.on_delivered(ar, obj, partners_box_entry)
            obj.delivered = True
            obj.save(update_fields=['delivered'])
            msg += _("Document '{0}' marked as delivered.\n").format(obj.voucher)

        if msg:
            ar.success(msg, refresh=True)

        if len(ar.selected_rows) == 1 and delivery_note is not None:
            ar.goto_instance(delivery_note)
