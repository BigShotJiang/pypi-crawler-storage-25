# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import dd


class ExchangableVoucher(dd.Model):
    """Mixin for vouchers that can be exchanged between partners."""

    class Meta:
        abstract = True

    def on_outbox_created(self, outbound_document, ar):
        """Called when an outbound document is created for this voucher."""
        pass

    def on_partners_acknowledgement(self, ar, old_state):
        """Called when the voucher state is set to acknowledged."""
        pass

    def on_partners_rejection(self, ar, old_state):
        """Called when the voucher state is set to rejected."""
        pass

    def on_partners_decision_pending(self, ar, old_state):
        """Called when the voucher state is set to pending."""
        pass

    def on_delivered(self, ar, outbound_document, partner_inbox_entry):
        """Called when the outbound document related to this voucher is marked as delivered."""
        pass

    def is_dependent(self, ar):
        """Return True if this voucher is dependent on another voucher from a document pair."""
        return False
