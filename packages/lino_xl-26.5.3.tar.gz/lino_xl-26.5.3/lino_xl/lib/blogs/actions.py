# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from django.conf import settings
from lino.api import _, dd, rt
from lino.core import constants
from lino.modlib.notify.api import send_notification
from lino.modlib.notify.android import send_android_notification


class SendToList(dd.Action):
    """Send the selected blog posts to the mailing list."""
    label = _("Send to mailing list")
    select_rows = True

    required_roles = dd.login_required(dd.SiteAdmin)

    parameters = dict(
        news_list=dd.ForeignKey("lists.List", verbose_name=_("Mailing list")),
        send_push=dd.BooleanField(verbose_name=_("Send push notification"), default=False),
    )

    params_layout = """
    news_list
    send_push
    """

    def run_from_ui(self, ar):
        apv = ar.action_param_values
        for blog in ar.selected_rows:
            member_qs = settings.SITE.user_model.filter_active_users(
                apv.news_list.members.select_related("user").all(),
                dd.today(),
                prefix="user__",
            )

            if dd.is_installed("lists"):
                dd.logger.info(f"Sending '{blog.title}' to the mailing list {apv.news_list}...")
                self.send_to_mailing_list(member_qs, blog, ar)

            if dd.is_installed("notify") and apv.send_push:
                dd.logger.info(
                    f"Sending push notification for '{blog.title}' to the mailing list {apv.news_list}...")
                self.send_push_notification(member_qs, blog, ar)

        ar.success(_("Selected blog posts have been sent to the mailing list."), close_window=True)

    def send_to_mailing_list(self, qs, blog, ar):
        recipients = set()
        for member in qs.filter(user__email__gt="", user__verification_code=""):
            recipients.add("{} <{}>".format(member.user.get_full_name(), member.user.email))
        recipients = list(recipients)
        if not recipients:
            dd.logger.warning(f"No recipients found in the mailing list.")
            return

        sender = settings.SERVER_EMAIL
        subject = blog.title
        body = "".join(blog.as_page(ar))
        ar.send_email(subject, sender, body, recipients)

    def send_push_notification(self, qs, blog, ar):
        for member in qs:
            params = {}
            if not member.user.has_usable_password():
                params.update({constants.URL_PARAM_SUBST_USER: member.user.pk})
            action_url = ar.renderer.get_detail_url(
                ar, rt.models.blogs.PublicEntries, blog.pk, **params)
            send_notification(
                user=member.user,
                subject=blog.title,
                body=blog.body_short_preview,
                action_url=action_url,
                action_title=_("Read more"),
                created=dd.now(),
            )
            if dd.get_plugin_setting("notify", "use_FCM", False):
                send_android_notification(
                    user=member.user,
                    subject=blog.title,
                    body=blog.body_short_preview,
                    action_url=action_url,
                )
