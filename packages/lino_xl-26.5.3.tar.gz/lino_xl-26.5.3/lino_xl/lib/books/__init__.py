# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino import ad, _


class Plugin(ad.Plugin):
    verbose_name = _("Books")
    ticket_model = None

    def pre_site_startup(self, site):
        # from lino.mixins import Contactable
        # from lino_xl.lib.courses.mixins import Enrollable
        if self.ticket_model:
            from lino_xl.lib.books.mixins import Indexable
            ticket_model = site.models.resolve(self.ticket_model)
            if not issubclass(ticket_model, Indexable):
                raise Exception(f"ticket_model {self.ticket_model} must be Indexable")
            self.ticket_model = self.ticket_model
        super().pre_site_startup(site)

    def setup_main_menu(self, site, user_type, m, ar=None):
        # mg = site.plugins.contacts
        mg = self.get_menu_group()
        m = m.add_menu(mg.app_label, mg.verbose_name)
        m.add_action('books.Books')

    def setup_config_menu(self, site, user_type, m, ar=None):
        mg = self.get_menu_group()
        m = m.add_menu(mg.app_label, mg.verbose_name)
        m.add_action("books.BookTypes")

    def setup_explorer_menu(self, site, user_type, m, ar=None):
        mg = self.get_menu_group()
        m = m.add_menu(mg.app_label, mg.verbose_name)
        m.add_action("books.Books")
        if self.ticket_model is not None:
            m.add_action('books.BookSections')
        # m.add_action('blogs.AllTaggings')
