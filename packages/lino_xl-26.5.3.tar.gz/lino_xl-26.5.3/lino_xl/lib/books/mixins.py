# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import dd


class Indexable(dd.Model):

    class Meta:
        abstract = True

    def as_book_item(self, ar):
        return self.as_page(ar)

    def get_index_terms(self):
        yield str(self.ticket)
