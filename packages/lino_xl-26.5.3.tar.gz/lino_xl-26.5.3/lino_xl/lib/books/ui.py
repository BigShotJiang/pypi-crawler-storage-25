# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)


from lino.api import dd, rt, _
from lino.core import constants
from lino.modlib.office.roles import OfficeUser, OfficeStaff


class BookTypes(dd.Table):

    model = 'books.BookType'
    required_roles = dd.login_required(OfficeStaff)
    # ~ label = _("Book types")
    column_names = 'designation build_method template *'
    order_by = ["designation"]

    insert_layout = """
    designation
    build_method
    """

    detail_layout = """
    id designation
    build_method template document_class
    books.BooksByType
    """


class BookDetail(dd.DetailLayout):
    # main = "general first_panel more"
    main = "general books.ItemsByBook preview_panel more"

    general = dd.Panel(
        """
        title language:10
        subtitle editor_type:10
        body
        """,
        label=_("General"),
        required_roles=dd.login_required(OfficeUser))

    preview_panel = dd.Panel(
        """
        preview
        """, label=_("Preview"))

    more = dd.Panel("""more1 more2""", label=_("More"))
    more1 = """
    id
    """
    more2 = """
    book_type start_num
    publishing_state album
    build_method build_time
    """


class Books(dd.Table):
    required_roles = dd.login_required(OfficeStaff)
    model = "books.Book"
    column_names = "title id *"
    detail_layout = "books.BookDetail"
    insert_layout = """
    title
    subtitle
    """
    default_display_modes = {None: constants.DISPLAY_MODE_LIST}


class BooksByType(Books):
    master_key = "book_type"


class BookSections(dd.Table):
    model = 'books.BookSection'
    required_roles = dd.login_required(OfficeStaff)
    detail_layout = dd.DetailLayout("""
    book seqno
    title subtitle
    ticket
    body
    """, window_size=('auto', 40))

    insert_layout = """
    book
    ticket
    """


class ItemsByBook(BookSections):
    master_key = "book"
    required_roles = set()  # also for anonymous
    # default_display_modes = {None: constants.DISPLAY_MODE_TILES}
    label = _("Sections")
    column_names = "seqno title ticket *"
    insert_layout = """
    ticket
    """


class ItemsByTicket(BookSections):
    label = _("Used in")
    master_key = "ticket"
    default_display_modes = {
        None: constants.DISPLAY_MODE_SUMMARY,
        # 70: constants.DISPLAY_MODE_GRID
    }
    column_names = "seqno book *"
    insert_layout = """
    book
    """
