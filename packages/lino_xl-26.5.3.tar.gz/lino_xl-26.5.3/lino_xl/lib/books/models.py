# -*- coding: UTF-8 -*-
# Copyright 2014-2022 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from html import escape
from django.db import models
from django.conf import settings
from django.utils import translation
# from django.utils.translation import get_language
from django.core.exceptions import ValidationError
from lino.api import dd, rt, _
# from lino.utils import mti
from lino.utils.html import E, tostring, format_html, mark_safe
from lino.modlib.uploads.choicelists import ImageFormats, htmlimg
# from lino.utils.instantiator import get_or_create
# from lino.utils.mldbc.fields import LanguageField
from lino.mixins import Sequenced, Referrable
from lino.utils.mldbc.mixins import BabelDesignated
# from lino.modlib.summaries.mixins import Summarized
from lino.modlib.printing.mixins import PrintableType, TypedPrintable
from lino.modlib.printing.choicelists import DocumentClasses
from lino.modlib.comments.mixins import Commentable
from lino.modlib.linod.choicelists import schedule_daily
from lino.modlib.memo.mixins import TitledPreviewable, FormatPreviewable
from lino.modlib.users.mixins import UserAuthored, PrivacyRelevant
from lino.modlib.publisher.mixins import Publishable, PublishableContent
from lino.modlib.publisher.mixins import TranslatableContent, Illustrated

from lino_xl.lib.topics.mixins import Taggable
from lino_xl.lib.sources.mixins import SourcesReporter
from lino.modlib.bootstrap5 import PAGE_TITLE_TEMPLATE
from .ui import *


class BookType(BabelDesignated, PrintableType):
    templates_group = 'books/Book'

    document_class = DocumentClasses.field(blank=True, null=True)

    class Meta:
        app_label = 'books'
        verbose_name = _("Book type")
        verbose_name_plural = _("Book types")

    def get_document_class(self, ar):
        return self.document_class or super().get_document_class(ar)


class Book(
    TitledPreviewable, TypedPrintable, SourcesReporter,
    PublishableContent, Illustrated, FormatPreviewable
):
    class Meta:
        app_label = 'books'
        verbose_name = _("Book")
        verbose_name_plural = _("Books")
        abstract = dd.is_abstract_model(__name__, "Book")

    memo_command = "book"
    hide_title_marker = "-"

    language = dd.LanguageField()
    # child_node_depth = models.IntegerField(default=1)
    book_type = dd.ForeignKey("books.BookType", blank=True, null=True)
    start_num = models.IntegerField(
        _("Item numbers start at"), blank=True, null=False, default=1)

    def after_duplicate(self, source):
        for si in source.items.all():
            i = si.__class__(seqno=si.seqno, ticket=si.ticket, book=source)
            i.full_clean()
            i.save()

    @classmethod
    def get_simple_parameters(cls):
        lst = list(super().get_simple_parameters())
        lst.append('language')
        lst.append('album')
        lst.append('publishing_state')
        return lst

    # @classmethod
    # def param_defaults(self, ar, **kw):
    #     kw = super().param_defaults(ar, **kw)
    #     kw.update(language=get_language())
    #     return kw

    def __str__(self):
        return self.title or super().__str__()

    def get_printable_type(self):
        return self.book_type

    def must_build_printable(self, bm):
        for i in self.items.all():
            i.build_content()
        return super().must_build_printable(bm)

    def before_ui_save(self, ar, cw):
        if not self.language:
            if ar:
                if ar.request:
                    self.language = ar.request.LANGUAGE_CODE
                else:
                    self.language = ar.get_user().language
            else:
                self.language = settings.SITE.get_default_language()
        super().before_ui_save(ar, cw)

    def get_page_title(self):
        # tpl = f'<p class="display-4" style="{style}">{{}}</p>'
        # return format_html(tpl, self.title)
        if self.title.startswith(self.hide_title_marker):
            return ''
        return format_html(PAGE_TITLE_TEMPLATE, self.title)

    def as_page(self, ar, display_mode="detail", hlevel=1, home=None):
        if home is None:
            home = self
        yield self.get_title_div(ar)

        # if not self.is_public():
        #     return

        if False:  # display_mode == "story":
            yield self.get_body_parsed(ar, short=True)

        # if display_mode in ("detail", "story"):
        if True:  # display_mode == "detail":
            # if hlevel == 1 and not dd.plugins.memo.use_markup and self.parent_id:
            #     yield self.toc_html(ar)

            if hlevel == 1 and self.main_image:
                yield f"""
                <div class="row">
                    <div class="center-block">
                        <a href="#" class="thumbnail">
                            <img src="{self.main_image.get_media_file().get_image_url()}">
                        </a>
                    </div>
                </div>
                """

            # yield self.body_full_preview
            yield self.get_body_parsed(ar, short=False)

            A = rt.models.books.ItemsByBook
            sar = A.create_request(master_instance=self, parent=ar)
            for obj in sar:
                # for chunk in obj.as_page(sar):
                #     yield chunk
                # yield tostring(obj.as_summary_item(sar))
                yield "<p>"
                yield tostring(obj.as_paragraph(sar))
                yield "</p>"
            # qs = rt.models.publisher.PageItem.objects.filter(page=self)
            # if qs.count() > 0:
            #     yield "<ol>"
            #     for obj in qs.order_by('seqno'):
            #         yield "<li>"
            #         yield tostring(obj.ticket.as_summary_item(ar))
            #         yield "</li>"
            #     yield "</ol>"

    def get_source_items(self):
        for pi in self.items.filter(ticket__isnull=False):
            yield pi.ticket, pi.seqno


class BookSection(Sequenced, TitledPreviewable):

    class Meta:
        app_label = 'books'
        abstract = dd.is_abstract_model(__name__, 'BookSection')
        verbose_name = _("Book section")
        verbose_name_plural = _("Book sections")
        ordering = ['book', 'seqno']

    allow_cascaded_delete = ['book']

    book = dd.ForeignKey('books.Book', related_name="items")
    ticket = dd.ForeignKey(dd.plugins.books.ticket_model,
                           null=True, blank=True)

    def build_content(self):
        if isinstance(self.ticket, Publishable):
            self.ticket.build_content()

    def get_str_words(self, ar):
        yield str(self.seqno)+")"
        if not ar.is_obvious_field("ticket") and self.ticket is not None:
            yield str(self.ticket)
        if not ar.is_obvious_field("book"):
            yield _("in {book}").format(book=self.book)

    # @classmethod
    # def as_tile(self, ar, text=None, **kwargs):
    #     if text is None:
    #         text = str(self)
    #     if self.ticket_id:
    #         return self.ticket.as_summary_item(ar, text, **kwargs)
    #     return super().as_summary_item(ar, text, **kwargs)

    def as_summary_item(self, ar, text=None, **kwargs):
        # raise Exception("20240613")
        if text is None:
            text = self.as_str(ar)
        if ar is None:
            obj = super()
        elif ar.is_obvious_field('ticket'):
            obj = self.book
        elif ar.is_obvious_field('book') and self.ticket is not None:
            obj = self.ticket
        else:
            obj = super()
        return obj.as_summary_item(ar, text, **kwargs)

    def get_start_num(self):
        return self.book.start_num

    def get_siblings(self):
        return self.__class__.objects.filter(book=self.book)

    def get_page_title(self):
        # num = f'<span class="l-text-prioritaire">{self.seqno}</span>'
        # num = f'<span class="border border-dark rounded-3">{self.seqno}</span>'
        num = f'<span class="badge text-bg-primary">{self.seqno}</span>'
        title = mark_safe(num + " " + str(self.ticket))
        return format_html(PAGE_TITLE_TEMPLATE, title)

    def as_page(self, ar, **kwargs):
        kwargs.update(title=self.get_page_title())
        return self.ticket.as_page(ar, **kwargs)

    def as_book_item(self, ar):
        # if self.parent:
        #     right_aligned_text = format_html(
        #         """<span style="float: right; font-size:80%;">({})</span>""", self.parent)
        #     # """<span style="float: right;">({})</span>""", self.parent)
        # else:
        #     right_aligned_text = ""
        right_aligned_text = ""
        s = ""
        if self.title:
            s += format_html(
                '<h3><span class="song-number">{}</span>&nbsp;&nbsp; {}{}</h3>',
                self.seqno, self.title, right_aligned_text)
        s += self.body_full_preview.replace('<br class="soft-break"/>', "/ ")
        if self.ticket:
            s += self.ticket.as_book_item(self, ar)
        return s


BOOK_STYLES = """

.song-header {
  border: 0;
  margin-top: 1em;
  margin-bottom: 0em;
  margin-left: 0;
  margin-right: 0;
  break-after: avoid;
}

.song-parent {
    font-size:80%;
    vertical-align:middle;
}

.song-title {
    font-size:120%;
    vertical-align:middle;
}

.song-number {
    /* color: white; */
    vertical-align: middle;
    font-size: 150%;
    font-weight: bold;
    /* margin: 2pt;
    padding: 3pt 6pt;
    padding-bottom: 0pt;
    border:1pt solid black; */
}

h3 {
    vertical-align: middle;
    margin: 0pt;
    margin-top: 0.2em;
}

.lino-img-full {  /* used by ImageFormats.full */
	width:100%;
	height:auto;
    padding:0.4em;
}

"""

add = DocumentClasses.add_item

add("songbook", _("Songbook"), page_css=r"""
@page {
    size: a4 portrait;
    margin: {{document_class.margin}}mm;
    margin-bottom: {{document_class.margin+document_class.footer_height}}mm;
    {%- if True or document_class.top_right_image -%}
    margin-top: {{document_class.margin+document_class.header_height}}mm;
    {%- endif -%}
    margin-left: {{document_class.margin_left}}mm;
    margin-right: {{document_class.margin_right}}mm;
    {%- if document_class.page_background_image -%}
      background-image: url(file://{{document_class.page_background_image}});
      background-repeat: no-repeat;
      background-attachment: fixed;
      background-size: contain;
    {%- endif -%}
    font-family: "Liberation sans", "arial";
    font-size: 10pt;
    {% if document_class.top_right_image %}
    @top-right {
      height: {{document_class.header_height}}mm;
      width: {{document_class.top_right_width}}mm;
      padding: 0mm;
      text-align: right;
      background-image: url(file://{{document_class.top_right_image}});
      background-size: cover;
      content: "";  // may be empty but must exist, otherwise bg is not rendered
      // content: url(file://{{document_class.top_right_image}});
    }
    {% endif %}

    @bottom-left {
        vertical-align: middle;
        white-space: pre-line;
        content: '{%- block doctitle %}{{str(obj)}}{%- endblock %}'
    }
    @bottom-right {
        vertical-align: middle;
        white-space: pre;
        content: '\A{{_("Page")}} ' counter(page) ' {{_("of {0}").format("")}} ' counter(pages)
                 {%- if show_printed_time -%}
                 '\A{{_("Printed")}} {{fdm(dd.today())}} {{_("at")}} {{now.time().strftime("%H:%M")}}'
                 {%- endif %};
    }
}
""" + BOOK_STYLES)


add("songsheet", _("Song sheet"),
    header_height=0, footer_height=8, margin=10, mirror_pages=True, page_css=r"""
@page {
    size: a4 portrait;
    margin: {{document_class.margin}}mm;
    margin-bottom: {{document_class.margin+document_class.footer_height}}mm;
    {%- if True or document_class.top_right_image -%}
    margin-top: {{document_class.margin+document_class.header_height}}mm;
    {%- endif -%}
    {%- if document_class.page_background_image -%}
      background-image: url(file://{{document_class.page_background_image}});
      background-repeat: no-repeat;
      background-attachment: fixed;
      background-size: contain;
    {%- endif -%}
    font-family: "Liberation sans", "arial";
    font-size: 10pt;
    {% if document_class.top_right_image %}
    @top-right {
      height: {{document_class.header_height}}mm;
      width: {{document_class.top_right_width}}mm;
      padding: 0mm;
      text-align: right;
      background-image: url(file://{{document_class.top_right_image}});
      background-size: cover;
      content: "";  // may be empty but must exist, otherwise bg is not rendered
      // content: url(file://{{document_class.top_right_image}});
    }
    {% endif %}
    {%- if not document_class.mirror_pages -%}
        {%- if document_class.margin_left -%}
        margin-left: {{document_class.margin_left}}mm;
        {%- endif -%}
        {%- if document_class.margin_right -%}
        margin-right: {{document_class.margin_right}}mm;
        {%- endif -%}
        @bottom-left {
            vertical-align: middle; white-space: pre-line;
            content: {{parse(document_class.bottom_left_content)}};
        }
        @bottom-right {
            vertical-align: middle; white-space: pre-line;
            content: {{parse(document_class.bottom_right_content)}};
        }
    {% endif %}
}

{%- if document_class.mirror_pages -%}
@page:nth(odd) {
    {%- if document_class.margin_left -%}
    margin-left: {{document_class.margin_left}}mm;
    {%- endif -%}
    {%- if document_class.margin_right -%}
    margin-right: {{document_class.margin_right}}mm;
    {%- endif -%}
    @bottom-left {
        vertical-align: middle; white-space: pre-line;
        content: {{parse(document_class.bottom_left_content)}};
    }
    @bottom-right {
        vertical-align: middle; white-space: pre-line;
        content: {{parse(document_class.bottom_right_content)}};
    }
}
@page:nth(even) {
    {%- if document_class.margin_left -%}
    margin-right: {{document_class.margin_left}}mm;
    {%- endif -%}
    {%- if document_class.margin_right -%}
    margin-left: {{document_class.margin_right}}mm;
    {%- endif -%}
    @bottom-left {
        vertical-align: middle; white-space: pre-line;
        content: {{parse(document_class.bottom_right_content)}};
    }
    @bottom-right {
        vertical-align: middle; white-space: pre-line;
        content: {{parse(document_class.bottom_left_content)}};
    }
}
{%- endif -%}


""" + BOOK_STYLES)
