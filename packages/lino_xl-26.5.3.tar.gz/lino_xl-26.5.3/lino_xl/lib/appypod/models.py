# Copyright 2014-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)


from lino.api import dd, rt
from lino.core.tables import AbstractTable
from lino.utils.addressable import Addressable

from .mixins import (PrintTableAction, PortraitPrintTableAction,
                     PrintLabelsAction)
from .choicelists import *

AbstractTable.as_pdf = PrintTableAction()
AbstractTable.as_pdf_p = PortraitPrintTableAction()


Addressable.print_labels = PrintLabelsAction()
