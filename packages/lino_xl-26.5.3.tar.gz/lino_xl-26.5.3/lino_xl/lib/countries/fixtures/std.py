# -*- coding: UTF-8 -*-
# Copyright 2013-2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import dd


def objects():
    if dd.plugins.countries.full_data:
        from lino_xl.lib.countries.fixtures.all_countries import objects
        yield objects()
        if not dd.get_plugin_setting("polygon", "explicitly_load_places", False):
            # Developers may decide to load the boundaries data from geoboundaries
            # In such a case we don't want duplicate data from our fixtures.
            if dd.plugins.countries.country_code == 'EE':
                from lino_xl.lib.countries.fixtures.eesti import objects
                yield objects()
            elif dd.plugins.countries.country_code == 'BE':
                from lino_xl.lib.countries.fixtures.be import objects
                yield objects()
            elif dd.plugins.countries.country_code == 'BD':
                from lino_xl.lib.countries.fixtures.bd_places import objects
                yield objects()
    else:
        from lino_xl.lib.countries.fixtures.few_countries import objects
        yield objects()
