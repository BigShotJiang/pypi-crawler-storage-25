# -*- coding: UTF-8 -*-
# Copyright 2014-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""Imports all Bangladeshi places from :mod:`commondata`.

"""

from django.conf import settings
from lino import logger
from lino.api import dd

from commondata.places.bangladesh import DIVISIONS

BABEL_BN = any(l.django_code == "bn" for l in settings.SITE.BABEL_LANGS)

countries = dd.resolve_app("countries")


def cd2type(p):
    return countries.PlaceTypes.get_by_name(p.type)


def place2objects(country, place, parent=None):
    t = cd2type(place)
    if t is None:
        logger.info("20140612 ignoring place %s", place)
        return
    try:
        obj = countries.Place.objects.get(
            country=country, name=place.name, type=t, parent=parent
        )
    except countries.Place.DoesNotExist:
        obj = countries.Place(
            country=country,
            type=t,
            name=place.name,
            parent=parent,
        )
    
    if BABEL_BN:
        obj.name_bn = place.name_bn

    # We must save the parent before we can generate children.
    try:
        obj.full_clean()
    except Exception as e:
        raise Exception("Could not save %s : %r" % (dd.obj2str(obj), e))
    obj.save()
    yield obj

    for cp in place.children:
        yield place2objects(country, cp, obj)


def objects():
    BD = countries.Country.objects.get(isocode="BD")
    for p in DIVISIONS:
        yield place2objects(BD, p)
