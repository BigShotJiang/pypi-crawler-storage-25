# -*- coding: UTF-8 -*-
# Copyright 2025 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

import re
import subprocess
from PIL import Image, ImageChops
from textwrap import dedent
from jinja2.exceptions import TemplateNotFound
from django.conf import settings
from django.db import models
from datetime import datetime, timezone
from lino import logger
from lino.api import dd, rt, _
from lino.core import constants
from lino.mixins.sequenced import Hierarchical
from lino.mixins import Modified
from lino.mixins.clonable import Clonable
from lino.modlib.bootstrap5 import PAGE_TITLE_TEMPLATE
from lino.modlib.users.mixins import UserAuthored
from lino.modlib.users.mixins import PrivacyRelevant
from lino_xl.lib.books.mixins import Indexable
from lino.modlib.publisher.mixins import PublishableContent
from lino.modlib.comments.mixins import Commentable
from lino.modlib.memo.mixins import TitledPreviewable
from lino.modlib.uploads.choicelists import ImageFormats, ImageSizes, htmlimg
from lino.utils.html import format_html, escape, mark_safe, tostring
# from lino.utils.config import must_make
from lino.utils.mldbc.mixins import BabelDesignated
from lino_xl.lib.topics.mixins import Taggable
from lino_xl.lib.sources.mixins import Copyrighted
from lino.utils.media import MediaFile
from lino_xl.lib.sources.choicelists import AuthorRoles
from .ui import *

if dd.plugins.songs.use_lilypond:
    try:
        from lilyponddist import lilypondbin
        from midi2audio import FluidSynth
    except ImportError:
        pass


AUTHOR_MODEL = dd.plugins.sources.author_model
TICKET_MODEL = dd.get_plugin_setting('publisher', 'ticket_model', None)

LILY_ERROR_MARKER = "*!*"

AUDIO_HTML = """
<figure>
<figcaption>{text}</figcaption>
<audio controls loop src="{url}">
Your browser does not support the audio element.
</audio>
<a href="{url}">Download {name}</a>
</figure>
"""


def crop_image(pth):
    # thanks to neouyghur https://stackoverflow.com/a/48605963/407239
    im = Image.open(pth)
    bg = Image.new(im.mode, im.size, im.getpixel((0, 0)))
    diff = ImageChops.difference(im, bg)
    diff = ImageChops.add(diff, diff, 2.0, -100)
    # Bounding box given as a 4-tuple defining the left, upper, right, and lower pixel coordinates.
    # If the image is completely empty, this method returns None.
    bbox = diff.getbbox()
    if bbox:
        im = im.crop(bbox)
        im.save(pth)


def font_and_text(lines, staffname):
    for ln in lines:
        above = None
        font = 'std'
        text = ln
        if not ln or ln.startswith("# "):
            continue
        if ln[0] in "*+":
            fmtspec, text = ln.split(maxsplit=1)
            if "+" in fmtspec:
                above = staffname
            if "*" in fmtspec:
                font = "alt"
        yield font, above, text


def text2lyrics(txt, staffname="SA"):
    lyrics = dedent(txt.strip())
    # Lilypond doesn't like <br>tags (didn't test whether this helps):
    lyrics = lyrics.replace('<br class="soft-break"/>', "\n")
    # print(repr(lyrics))
    if not lyrics:
        return []
    if lyrics.startswith("- "):
        lines = re.split(r"^\W*- ", lyrics,  flags=re.MULTILINE)
        # print("20260226a", lines)
        assert lines[0] == ""
        # print(rv[1:])
        return font_and_text(lines[1:], staffname)
        # for ln in lines[1:]:
        #     if not ln.startswith("# "):
        #         yield ln
    else:
        return font_and_text([lyrics], staffname)
        # yield lyrics


class LilyFormat(dd.Choice):

    voices_filter = set()
    suffix = ".png"
    is_image = True

    def __init__(self, name, tplname=None, line_width=None, text=None, **kwargs):
        self.tplname = tplname
        self.line_width = line_width
        super().__init__(name, text, name, **kwargs)

    def get_lily_file(self, sng):
        return SongProxy(self, sng)

    def get_media_file(self, song):
        if dd.plugins.songs.use_lilypond:
            if song.scores_preamble:
                if self.voices_filter:
                    hide = True
                    for k in self.voices_filter:
                        if getattr(song, 'scores_' + k):
                            hide = False
                    if hide:
                        return
                leaf = str(song.pk) + "_" + self.value + self.suffix
                return MediaFile(False, "cache", "songs", leaf)


class LilyFormats(dd.ChoiceList):
    item_class = LilyFormat


add = LilyFormats.add_item
# add("web", "songs/satb_web.jinja.ly")
add("web", "songs/satb.jinja.ly", r"120\mm")
add("a4", "songs/satb.jinja.ly")
add("midi", "songs/midi.jinja.ly", suffix=".wav",
    is_image=False, text=_("MIDI (all voices)"))
add("midi_a", "songs/midi.jinja.ly",
    voices_filter={'alto'}, suffix=".wav", is_image=False, text=_("MIDI (alto)"))
add("midi_t", "songs/midi.jinja.ly",
    voices_filter={'tenor'}, suffix=".wav", is_image=False, text=_("MIDI (tenor)"))
add("midi_b", "songs/midi.jinja.ly",
    voices_filter={'bass'}, suffix=".wav", is_image=False, text=_("MIDI (bass)"))


class SongType(BabelDesignated, PublishableContent):

    class Meta:
        app_label = "songs"
        verbose_name = _("Song type")
        verbose_name_plural = _("Song types")


class SongProxy:

    def __init__(self, fmt, song):
        self.fmt = fmt
        self.song = song

    @property
    def media_file(self):
        return self.fmt.get_media_file(self.song)


class LyricsLine:
    def __init__(self, voice, font, text, above="SA"):
        self.voice = voice
        self.font = font
        self.text = text
        self.above = above


class Song(
        UserAuthored, PrivacyRelevant, TitledPreviewable, Commentable, Indexable,
        PublishableContent, Copyrighted, Taggable, Hierarchical, Modified):

    class Meta:
        app_label = "songs"
        verbose_name = _("Song")
        verbose_name_plural = _("Songs")

    memo_command = "song"
    auto_touch = False  # auto_touch would touch the song when we save build output

    song_type = dd.ForeignKey('songs.SongType', blank=True, null=True)
    language = dd.ForeignKey('languages.Language', blank=True, null=True)
    # source = dd.ForeignKey('sources.Source', blank=True, null=True)
    scores_tempo = dd.CharField(_("Tempo"), max_length=200, blank=True)
    time_signature = dd.CharField(
        _("Time signature"), max_length=200, blank=True)
    scores_preamble = dd.CharField(_("Preamble"), max_length=200, blank=True)
    scores_line_width = dd.CharField(
        _("Line width"), max_length=200, blank=True)
    scores_soprano = dd.RichTextField(
        _("Scores (soprano)"), blank=True, format="plain")
    scores_alto = dd.RichTextField(
        _("Scores (alto)"), blank=True, format="plain")
    scores_tenor = dd.RichTextField(
        _("Scores (tenor)"), blank=True, format="plain")
    scores_bass = dd.RichTextField(
        _("Scores (bass)"), blank=True, format="plain")
    # scores_lyrics = dd.RichTextField(_("Lyrics"), blank=True, format="plain")
    lyrics_soprano = dd.RichTextField(
        _("Lyrics (soprano)"), blank=True, format="plain")
    lyrics_alto = dd.RichTextField(
        _("Lyrics (alto)"), blank=True, format="plain")
    lyrics_tenor = dd.RichTextField(
        _("Lyrics (tenor)"), blank=True, format="plain")
    lyrics_bass = dd.RichTextField(
        _("Lyrics (bass)"), blank=True, format="plain")
    scores_chords = dd.RichTextField(_("Chords"), blank=True, format="plain")
    scores_errors = dd.RichTextField(
        _("Compilation output"), format="plain", editable=False)

    other_font = dd.BooleanField(
        _("Other font in second verse"), default=False)
    combine_parts = dd.BooleanField(_("Combine parts"), default=True)
    # must_build = dd.BooleanField(_("Must build"), default=True)
    vertical_spacing_outside = models.IntegerField(
        _("Vertical spacing outside"), default=70)
    vertical_spacing_inside = models.IntegerField(
        _("Vertical spacing inside"), default=50)

    # font_name = "Arial"  # Say `fc-list : family` for list of available fonts
    font_name = "sans"  # Say `fc-list : family` for list of available fonts
    # vertical_spacing_outside = 70  # 0: very tight, 100=normal, 150= 1.5xnormal
    # vertical_spacing_inside = 50  # 0: very tight, 100=normal, 150= 1.5xnormal
    # stave_vertical_extent_sa = "(-1 . 1)"
    # stave_vertical_extent_tb = "(-1 . 1)"

    # minimum-Y-extent takes a pair of numbers, so if you want to make it
    # smaller than its default #'(-4 . 4) then you could set
    # \override Staff.VerticalAxisGroup #'minimum-Y-extent = #'(-3 . 3)
    # This sets the vertical size of the current staff to 3 staff spaces on
    # either side of the center staff line. The value (-3 . 3) is interpreted as
    # an interval, where the center line is the 0, so the first number is
    # generally negative. The numbers need not match; for example, the staff can
    # be made larger at the bottom by setting it to (-6 . 4).

    def __str__(self):
        return self.title

    def full_clean(self, *args, **kwargs):
        # data migration 20260226:
        # if self.scores_lyrics and not self.lyrics_soprano:
        #     self.lyrics_soprano = self.scores_lyrics
        super().full_clean(*args, **kwargs)

    def after_duplicate(self, ar, master):
        super().after_duplicate(ar, master)
        self.parent = master
        self.touch()

    def before_ui_save(self, ar, cw):
        self.touch()
        super().before_ui_save(ar, cw)

    def after_ui_save(self, ar, cw):
        super().after_ui_save(ar, cw)
        self.build_content()

    def get_lyrics(self):
        for font, above, lyrics in text2lyrics(self.lyrics_soprano, "SA"):
            yield LyricsLine("soprano", font, lyrics, above)
        for font, above, lyrics in text2lyrics(self.lyrics_alto, "SA"):
            yield LyricsLine("alto", font, lyrics, above)

    @classmethod
    def setup_parameters(cls, fields):
        fields.setdefault(
            'author', dd.ForeignKey(
                AUTHOR_MODEL, verbose_name=_("Author"), blank=True, null=True))
        fields.setdefault(
            'composer', dd.ForeignKey(
                AUTHOR_MODEL, verbose_name=_("Composer"), blank=True, null=True))
        fields.setdefault(
            'topic', dd.ForeignKey(
                'topics.Topic', blank=True, null=True))
        super().setup_parameters(fields)

    @classmethod
    def get_simple_parameters(cls):
        lst = list(super().get_simple_parameters())
        lst.append('group')
        lst.append('song_type')
        lst.append('pub_date')
        return lst

    def build_content(self, force=False):
        # logger.info("20260222 build_content %s", self)
        if not dd.plugins.songs.use_lilypond:
            return
        errors = ""
        success = True
        env = settings.SITE.plugins.jinja.renderer.jinja_env
        for fmt in LilyFormats.get_list_items():
            # logger.info("20260222 fmt %s", fmt)
            mf = fmt.get_lily_file(self).media_file
            if mf is None:
                # raise Warning(f"20260221 no media_file for {fmt}")
                continue
            mtime = self.modified
            # if mtime is not None:
            #     # logger.info("20260221 no reason to build %s", mf.path)
            #     continue
            if mtime and not force and mf.path.exists():
                file_mtime = datetime.fromtimestamp(
                    mf.path.stat().st_mtime, tz=timezone.utc)
                # mf.path.stat().st_mtime
                # print(f"20260221 is {mtime.timestamp()} < {file_mtime}")
                # print(f"20260221 check whether {mtime} < {file_mtime}")
                if mtime < file_mtime:
                    # print(f"20260221 no need to build existing {mf.path}")
                    continue
            # logger.info("20260221 Must build %s using %s", mf.path, fmt.tplname)
            errors += f"\nBuild {mf.path} using {fmt.tplname}"
            try:
                tpl = env.get_template(fmt.tplname)
            except TemplateNotFound as e:
                errors += "\n" + str(e)
                continue
            context = dict()  # ar.get_printable_context()
            context.update(sng=self, fmt=fmt)
            scores_source = tpl.render(**context)
            mf.path.unlink(missing_ok=True)
            tmp_dir = settings.SITE.site_dir / "tmp"
            tmp_dir.mkdir(exist_ok=True)
            src = tmp_dir / f"tmp_{fmt.value}.ly"
            src.write_text(scores_source)
            mf.path.parent.mkdir(exist_ok=True, parents=True)
            cmd = [lilypondbin(), '--png', '-o', mf.path.with_suffix(''), src]
            lily_env = dict(HOME=tmp_dir)
            # Fontconfig requires HOME to be writable, otherwise it causes
            # warnings "No writable cache directories"
            options = dict(stdout=subprocess.PIPE,
                           universal_newlines=True,
                           stderr=subprocess.STDOUT,
                           env=lily_env)
            ret = subprocess.run(cmd, **options)
            errors += "\n" + ret.stdout + "\n"

            if fmt.is_image:
                if mf.path.exists():
                    crop_image(mf.path)
                    # logger.info("20260222 Built %s", cmd)
                else:
                    success = False
                    #     logger.info("20260222 Failed to build %s: %s", mf.path, errors)
                    # raise Warning(f"Failed to build {mf.path}:" + errors)
            else:
                midi_path = mf.path.with_suffix('.midi')
                if midi_path.exists():
                    FluidSynth().midi_to_audio(midi_path, mf.path)
        self.scores_errors = errors
        if success:
            self.title = self.title.rstrip(LILY_ERROR_MARKER)
        else:
            self.title = self.title.rstrip(
                LILY_ERROR_MARKER) + LILY_ERROR_MARKER
        # self.touch()
        # self.must_build = False
        self.full_clean()
        self.save()
        return

    # def as_tile(self, ar, prev, **kwargs):
    #     s = f"""<span style="font-size:2rem; float:left; padding-right:1rem;">{
    #         ar.obj2htmls(self)}</span> """
    #     s += _("{} pupils").format(Enrolment.objects.filter(group=self).count())
    #     s += "<br>"
    #     sar = rt.models.school.CoursesByGroup.create_request(
    #         parent=ar, master_instance=self)
    #     s += " ".join([
    #         sar.obj2htmls(
    #             obj, obj.subject.icon_text or str(obj.subject), title=str(obj.subject))
    #         for obj in sar])
    #     s = constants.TILE_TEMPLATE.format(chunk=s)
    #     if prev is not None and prev.grade != self.grade:
    #         s = """<p style="display:block;"></p>""" + s
    #     return mark_safe(s)

    def as_tile(self, ar, prev, **kwargs):
        if ar is None:
            return str(self)
        info = []
        if self.song_type:
            info.append(ar.obj2htmls(self.song_type))
        if self.pub_date:
            info.append(str(self.pub_date.year))
        s = mark_safe("|".join(info))

        s += mark_safe("<br>")
        t = _("Published {}")
        t = t.format(self.pub_date)
        s += ar.obj2htmls(self, title=t)

        prl = []
        AuthorCast = rt.models.sources.AuthorCast
        qs = AuthorCast.controlled_rows(self, role=AuthorRoles.author)
        for cast in qs:
            prl.append(ar.obj2htmls(
                cast.author,
                f"{cast.author.first_name} {cast.author.last_name}".strip()))
        if len(prl) > 0:
            # s += format_html(" {} ", _("by"))
            s += format_html("<br>{} ", "👤")  # (U+1F464)
            s += mark_safe(", ".join(prl))

        # if self.body_short_preview:
        #     s += mark_safe("\n" + self.body_short_preview)
        return format_html(constants.TILE_TEMPLATE, chunk=s)

    def as_paragraph(self, ar):
        if ar is None:
            return str(self)
        s = mark_safe("")
        t = _("Published {}")
        t = t.format(self.pub_date)
        s += ar.obj2htmls(self, title=t)

        prl = []
        AuthorCast = rt.models.sources.AuthorCast
        exposed_roles = {AuthorRoles.author, AuthorRoles.composer}
        for cast in AuthorCast.controlled_rows(self, role__in=exposed_roles):
            prl.append(ar.obj2htmls(
                cast.author,
                f"{cast.author.first_name} {cast.author.last_name}".strip()))
        if len(prl) > 0:
            s += format_html(" ({})", mark_safe(", ".join(prl)))

        if self.body_short_preview:
            s += mark_safe("\n" + self.body_short_preview)
        return s

    # def get_page_title(self):
    #     title = dd.babelattr(self, "title")
    #     return PAGE_TITLE_TEMPLATE.format(escape(title))

    def as_page(self, ar, display_mode="detail", title=None, **kwargs):
        yield self.get_title_div(ar)
        # yield title or self.get_page_title()
        items = []
        for pr in AuthorRoles.get_list_items():
            prl = []
            AuthorCast = rt.models.sources.AuthorCast
            for cast in AuthorCast.controlled_rows(self, role=pr):
                prl.append(ar.obj2htmls(cast.author))
            if len(prl) > 1:
                text = pr.text_plural
            elif len(prl) == 1:
                text = pr.text
            else:
                continue
            items.append(format_html("{}: {}", text,
                         mark_safe("; ".join(prl))))

        srcrefs = []
        for srcref in rt.models.sources.SourceRef.controlled_rows(self):
            srcrefs.append(ar.obj2htmls(srcref.source))
        if len(srcrefs):
            text = rt.models.sources.SourceRef._meta.verbose_name_plural
            items.append(format_html("{}: {}", text,
                         mark_safe("; ".join(srcrefs))))

        show_fields = ['song_type', 'parent']
        if False:
            show_fields.append('language')
            show_fields.append('user')
            show_fields.append('group')
        for k in show_fields:
            value = getattr(self, k)
            if value is not None:
                fld = self.__class__._meta.get_field(k)
                items.append(format_html(
                    "{}: {}", fld.verbose_name, ar.obj2htmls(value)))
        if self.license:
            lic = format_html('<a href="{}">{}</a>',
                              self.license.url, self.license)
            if self.copyright_owner:
                items.append(format_html(
                    '&copy; {} ({})', ar.obj2htmls(self.copyright_owner), lic))
            else:
                items.append(lic)

        if TICKET_MODEL:
            qs = rt.models.publisher.PageItem.objects.filter(ticket=self)
            if qs.count() > 0:
                used_in = mark_safe(", ".join([
                    tostring(obj.page.as_summary_item(ar))
                    for obj in qs.order_by('id')]))
                items.append(format_html(
                    "{}: {}", _("Used in"), used_in))

        if len(items):
            txt = " | ".join(items)
            yield """<p class="small">{}</p>""".format(txt)
            # https://getbootstrap.com/docs/3.4/css/#small-text

        # if (mf := sng.scores_image) is not None:
        if (mf := LilyFormats.web.get_lily_file(self).media_file) is not None:
            # if (mf := self.get_lily_file('web')) is not None:
            yield htmlimg(
                src=mf.url,
                # image_size=ImageSizes.solo,
                image_format=ImageFormats.full)

        for fmt in LilyFormats.filter(is_image=False):
            if (mf := fmt.get_media_file(self)):
                yield format_html(
                    AUDIO_HTML, url=mf.url, name=mf.path.name, text=fmt.text)

        # print(f"20251023 {self.body}")
        yield self.body_full_preview.replace('<br class="soft-break"/>', "/ ")

    def as_book_item(self, item, ar):
        s = ""
        if False:
            if self.parent:
                right_aligned_text = format_html(
                    """<span class="song-parent">({})</span>""", self.parent)
            else:
                right_aligned_text = ""
            s += format_html(
                '<h3><span class="song-number">{}</span>&nbsp;&nbsp; {}{}</h3>',
                item.seqno, self.title, right_aligned_text)
        else:
            if self.parent:
                s += format_html(
                    """\
                    <table class="song-header"><tr>
                      <td style="border:0;"><span class="song-number">{}&nbsp;</span><span class="song-title">{}</span></td>
                      <td style="border:0;text-align:right;"><span class="song-parent">{}</span></td>
                    </tr></table>""",
                    item.seqno, self.title, f"({self.parent})")
            else:
                s += format_html(
                    """\
                    <table class="song-header"><tr>
                      <td style="border:0;"><span class="song-number">{}&nbsp;</span><span class="song-title">{}</span></td>
                    </tr></table>""",
                    item.seqno, self.title)
        # s += """<div style="break-inside:avoid;">"""
        # sng = SongProxy(LilyFormats.a4, self)
        # if (mf := self.get_lily_file('a4')) is not None:
        if (mf := LilyFormats.a4.get_lily_file(self).media_file) is not None:
            # if (mf := sng.scores_image) is not None:
            s += htmlimg(
                src=f"file://{mf.path}",
                # image_size=ImageSizes.solo,
                image_format=ImageFormats.full)
        s += self.body_full_preview.replace('<br class="soft-break"/>', "/ ")
        # s += "</div>"
        return s

    def get_index_terms(self):
        yield self.title
        if self.parent:
            yield str(self.parent)


dd.update_field(Song, 'user', verbose_name=_("Editor"))
dd.update_field(Song, 'parent', verbose_name=_("Derived from"))
