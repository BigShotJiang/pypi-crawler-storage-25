\version "2.25.24"
\score{
\unfoldRepeats {
<<
{% if sng.scores_soprano and (not fmt.voices_filter or "soprano" in fmt.voices_filter) %}
\new Staff {
  \set Staff.midiInstrument = "french horn"
  {% if sng.scores_tempo %} \tempo {{sng.scores_tempo}} {% endif %}
  {% if sng.time_signature %} \time {{sng.time_signature}} {% endif %}
  {{sng.scores_preamble}}
  \relative g' { {{sng.scores_soprano}} }
}
{% endif %}
{% if sng.scores_alto and (not fmt.voices_filter or "alto" in fmt.voices_filter) %}
\new Staff {
  \set Staff.midiInstrument = "acoustic guitar (nylon)"
  {% if sng.scores_tempo %} \tempo {{sng.scores_tempo}} {% endif %}
  {% if sng.time_signature %} \time {{sng.time_signature}} {% endif %}
  {{sng.scores_preamble}}
  \relative g' { {{sng.scores_alto}} }
}
{% endif %}
{% if sng.scores_tenor and (not fmt.voices_filter or "tenor" in fmt.voices_filter) %}
\new Staff {
  \set Staff.midiInstrument = "acoustic grand"
  {% if sng.scores_tempo %} \tempo {{sng.scores_tempo}} {% endif %}
  {% if sng.time_signature %} \time {{sng.time_signature}} {% endif %}
  {{sng.scores_preamble}}
  \relative g' { {{sng.scores_tenor}} }
}
{% endif %}
{% if sng.scores_bass and (not fmt.voices_filter or "bass" in fmt.voices_filter) %}
\new Staff {
  \set Staff.midiInstrument = "acoustic bass"
  {% if sng.scores_tempo %} \tempo {{sng.scores_tempo}} {% endif %}
  {% if sng.time_signature %} \time {{sng.time_signature}} {% endif %}
  {{sng.scores_preamble}}
  \relative g' { {{sng.scores_bass}} }
}
{% endif %}
>>
}
\midi { }
}
