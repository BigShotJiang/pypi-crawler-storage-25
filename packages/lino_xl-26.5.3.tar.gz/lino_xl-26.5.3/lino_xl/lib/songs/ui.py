# -*- coding: UTF-8 -*-
# Copyright 2025 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import dd, _
from lino.modlib.users.mixins import My
from lino.core import constants
from lino_xl.lib.contacts.roles import ContactsStaff, ContactsUser
from lino_xl.lib.sources.choicelists import AuthorRoles


class SongTypes(dd.Table):
    required_roles = dd.login_required(ContactsStaff)
    model = 'songs.SongType'
    column_names = 'designation *'
    detail_layout = """id designation
    SongsByType
    """


class SongDetail(dd.DetailLayout):
    main = "general scores voices build copyright songs.SongsByParent more"

    general = dd.Panel("""
    general_left books.ItemsByTicket
    body comments.CommentsByRFC
    """, label=_("General"))

    general_left = """
    title:60 language:10
    subtitle parent
    """

    scores = dd.Panel("""
    scores_tempo time_signature scores_preamble
    scores_line_width vertical_spacing_outside
    vertical_spacing_inside  other_font combine_parts
    scores_chords
    """, label=_("Scores"))

    voices = dd.Panel("""
    scores_soprano lyrics_soprano
    scores_alto lyrics_alto
    scores_tenor lyrics_tenor
    scores_bass lyrics_bass
    """, label=_("Voices"))

    # preview_panel = dd.Panel("""
    # """, label=_("Preview"))

    build = dd.Panel("""
    scores_errors preview
    """, label=_("Build"))

    copyright = dd.Panel("""
    license copyright_owner year_published
    sources.ComposersByOwner sources.AuthorsByOwner sources.CastsByOwner
    """, label=_("Copyright"))

    more = dd.Panel("""
    id user group private song_type
    publishing_state pub_date
    sources.SourcesByOwner topics.TagsByOwner
    """, label=_("More"))


class Songs(dd.Table):
    model = "songs.Song"
    column_names = 'id title language *'
    detail_layout = "songs.SongDetail"
    insert_layout = """
    title
    language
    """
    # params_panel_pos = 'left'
    # params_layout = """
    # group
    # user
    # author
    # mentor
    # """


class SongsByType(Songs):
    master_key = 'song_type'


class SongsByGroup(Songs):
    master_key = 'group'


class SongsByCopyrightOwner(Songs):
    master_key = 'copyright_owner'


class SongsByParent(Songs):
    label = _("Derived songs")
    master_key = 'parent'


class MySongs(My, Songs):
    required_roles = dd.login_required(ContactsUser)
    # label = _("My entries")


class LatestSongs(Songs):
    required_roles = set()  # also for anonymous
    label = _("Latest songs")
    column_names = "pub_date title user *"
    order_by = ["-pub_date"]
    filter = dd.Q(pub_date__isnull=False)
    # default_display_modes = {None: constants.DISPLAY_MODE_LIST}
    # editable = False
    insert_layout = None  # disable the (+) button but permit editing
    default_display_modes = {
        None: constants.DISPLAY_MODE_LIST}
