# -*- coding: UTF-8 -*-
# Copyright 2024-2025 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from django.db import models
from lino.api import dd, rt, _
from lino.utils.html import format_html


class Copyrighted(dd.Model):

    class Meta:
        abstract = True

    copyright_owner = dd.ForeignKey("contacts.Company", verbose_name=_(
        "Copyright owner"), blank=True, null=True)
    year_published = models.CharField(
        _("Year published"), max_length=20, blank=True)
    license = dd.ForeignKey("sources.License", blank=True, null=True)


class SourcesReporter(dd.Model):

    class Meta:
        abstract = True

    def get_source_items(self):
        return []

    def get_index_items(self):
        rv = dict()
        for ticket, seqno in self.get_source_items():
            for term in ticket.get_index_terms():
                seqnos = rv.setdefault(term, set())
                seqnos.add(seqno)
        for k in sorted(rv.keys()):
            seqnos = rv[k]
            yield k, map(str, sorted(seqnos))

    def sources_summary(self):
        src2seqnos = dict()
        for ticket, seqno in self.get_source_items():
            for ref in rt.models.sources.SourceRef.controlled_rows(ticket):
                if ref.source.title:
                    seqnos_by_src = src2seqnos.setdefault(ref.source, set())
                    seqnos_by_src.add(seqno)
        if len(src2seqnos) > 0:
            for src, seqnos in src2seqnos.items():
                seqnos = map(str, sorted(seqnos))
                yield "{}: {}".format(src, ", ".join(seqnos))

    def authors_summary(page):
        for author in rt.models.sources.Author.objects.order_by('last_name', 'first_name'):
            role2seqnos = dict()
            # seqnos = set([])
            for cast in rt.models.sources.AuthorCast.objects.filter(author=author):
                for pi in page.items.filter(ticket=cast.owner):
                    seqnos_by_role = role2seqnos.setdefault(cast.role, set())
                    seqnos_by_role.add(pi.seqno)
            if len(role2seqnos) > 0:
                atext = str(author)
                chunks = []
                for role, seqnos in role2seqnos.items():
                    seqnos = map(str, sorted(seqnos))
                    # chunks.append(format_html("{} ({})", role, ", ".join(seqnos)))
                    chunks.append(format_html(
                        _("{seqnos} ({role})"), role=role.short_text, seqnos=", ".join(seqnos)))
                # atext = "{}, {}".format(author.last_name, author.first_name)
                # html += format_html("<p>{}: {}</p>\n", atext, "; ".join(chunks))
                yield "{}: {}".format(atext, "; ".join(chunks))

    def copyright_summary(page):
        co2seqnos = dict()
        for pi in page.items.filter(ticket__copyright_owner__isnull=False):
            seqnos = co2seqnos.setdefault(pi.ticket.copyright_owner, set())
            seqnos.add(pi.seqno)
        if len(co2seqnos) > 0:
            if len(co2seqnos) == 1:
                co = next(iter(co2seqnos))
                cotext = ", ".join(co.get_address_lines(with_url=True))
                yield "© {}".format(cotext)
                return
            for co, seqnos in co2seqnos.items():
                seqnos = map(str, sorted(seqnos))
                cotext = ", ".join(co.get_address_lines(with_url=True))
                yield "{} : © {}".format(", ".join(seqnos), cotext)
                # html += format_html("<p>{} : &copy; {}</p>\n", ", ".join(seqnos), cotext)
