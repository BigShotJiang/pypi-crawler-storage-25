# -*- coding: UTF-8 -*-
# Copyright 2019 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import dd, rt, _
from lino.utils.mldbc import babeld
from lino.utils import Cycler


def objects():
    List = rt.models.lists.List
    Member = rt.models.lists.Member

    LISTS = Cycler(List.objects.order_by('id'))

    for u in dd.settings.SITE.user_model.objects.order_by('id'):
        yield Member(user=u, list=LISTS.pop())
