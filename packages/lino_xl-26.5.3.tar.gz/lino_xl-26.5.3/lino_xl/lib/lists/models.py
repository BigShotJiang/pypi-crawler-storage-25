# -*- coding: UTF-8 -*-
# Copyright 2014-2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

# from uuid import uuid4
from django.db import models
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from django.utils.text import format_lazy

from lino_xl.lib.contacts.roles import ContactsStaff, ContactsUser
from lino_xl.lib.appypod.mixins import PrintLabelsAction
from lino.modlib.printing.mixins import Printable
from lino.modlib.users.mixins import UserAuthored
from lino.modlib.users.actions import send_welcome_email
from lino.modlib.publisher.choicelists import SpecialPages
from lino.utils.mldbc.mixins import BabelDesignated
from lino.mixins.ref import Referrable
from lino.mixins.sequenced import Sequenced
# from lino.core.utils import comma
from lino.utils.html import E, join_elems

from lino.api import dd, rt
# from lino import mixins
from lino.core import constants

from lino.modlib.printing.mixins import DirectPrintAction
# from lino.mixins.periods import Monthly
from lino.modlib.webforms.mixins import WebForm, create_user_request_executed


# allow_subscription = dd.is_installed("contacts") and dd.is_installed("system")

def get_default_list():
    return rt.models.lists.List.objects.filter(default_for_new_users=True).first()


class SubscribeToListRequest(WebForm):

    class Meta:
        app_label = 'lists'
        abstract = dd.is_abstract_model(__name__, 'SubscribeToListRequest')
        verbose_name = _("SubscribeToList request")
        verbose_name_plural = _("SubscribeToList request")

    first_name = models.CharField(_("First name"), max_length=30, blank=True)
    last_name = models.CharField(_("Last name"), max_length=30, blank=True)
    list = dd.ForeignKey("lists.List", default=get_default_list)

    def full_clean(self):
        if self.done_since is None:
            # User = rt.models.users.User
            qs = rt.models.lists.Member.objects.filter(
                user__email=self.email, list=self.list)
            if qs.first():
                raise Warning(_("{email} is already subscribed to {list}").format(
                    email=self.email, list=self.list))
        super().full_clean()

    def __str__(self):
        whom = f"{self.first_name} {self.last_name} <{self.email}>"
        return _("Subscribe {whom} to {list}").format(whom=whom, list=self.list)

    def execute_webform(self, ar):
        User = dd.settings.SITE.user_model
        Member = rt.models.lists.Member  # pylint: disable=W0621,C0103
        UserTypes = rt.models.users.UserTypes
        fields = ('first_name', 'last_name', 'email', 'language')
        ut = UserTypes.get_by_name(dd.plugins.users.user_type_new)
        user = User(
            user_type=ut, username=self.email,
            **{f: getattr(self, f) for f in fields})
        user.on_create(ar)
        user.must_verify()
        user.full_clean()
        user.save_new_instance(ar)
        recipients = ["{} <{}>".format(user.get_full_name(), user.email)]
        send_welcome_email(ar, user, recipients)
        membership = Member(list=self.list, user=user)
        membership.full_clean()
        membership.save_new_instance(ar)
        self.mark_done()


dd.update_field(SubscribeToListRequest, 'email', blank=False)


class SubscribeToListRequests(dd.Table):
    required_roles = dd.login_required(dd.SiteAdmin)
    model = "lists.SubscribeToListRequest"
    # submit_form = SubmitContactRequest()
    insert_layout = """
    first_name last_name
    email
    list
    """

    detail_layout = """
    ip_address session_key language
    created done_since
    first_name last_name
    email
    list
    """


class SubscribeToListRequestsWeb(SubscribeToListRequests):
    required_roles = set([])


class PrintMembers(DirectPrintAction):
    # combo_group = "creacert"
    label = _("Members")
    tplname = "list_members"
    build_method = "weasy2pdf"
    icon_name = None
    show_in_toolbar = False
    # parameters = Monthly(
    #     show_remarks=models.BooleanField(
    #         _("Show remarks"), default=False),
    #     show_states=models.BooleanField(
    #         _("Show states"), default=True))
    # params_layout = """
    # start_date
    # end_date
    # show_remarks
    # show_states
    # """
    # keep_user_values = True


# class ListType(mixins.BabelNamed):
class ListType(BabelDesignated):

    class Meta:
        app_label = 'lists'
        abstract = dd.is_abstract_model(__name__, 'ListType')
        verbose_name = _("List Type")
        verbose_name_plural = _("List Types")


class ListTypes(dd.Table):
    required_roles = dd.login_required(ContactsStaff)
    model = 'lists.ListType'
    column_names = 'designation *'


# class List(mixins.BabelNamed, mixins.Referrable):
class List(BabelDesignated, Referrable, Printable):

    class Meta:
        app_label = 'lists'
        abstract = dd.is_abstract_model(__name__, 'List')
        verbose_name = _("Newsletter")
        verbose_name_plural = _("Newsletters")

    list_type = dd.ForeignKey('lists.ListType', blank=True, null=True)
    remarks = models.TextField(_("Remarks"), blank=True)
    default_for_new_users = dd.BooleanField(_("Default for new users"), default=False)

    print_labels = PrintLabelsAction()
    print_members = PrintMembers()
    print_members_html = PrintMembers(build_method='weasy2html',
                                      label=format_lazy(
                                          u"{}{}", _("Members"), _(" (HTML)")))

    # if allow_subscription:
    #     subscribe = SubscribeToList()

    @dd.displayfield(_("Print"))
    def print_actions(self, ar):
        if ar is None:
            return ''
        elems = []
        elems.append(ar.instance_action_button(self.print_labels))
        elems.append(ar.instance_action_button(self.print_members))
        elems.append(ar.instance_action_button(self.print_members_html))
        return E.p(*join_elems(elems, sep=", "))

    def get_overview_elems(self, ar):
        return [self.as_summary_item(ar)]


class Lists(dd.Table):
    required_roles = dd.login_required(ContactsUser)
    # required_roles = set([])
    model = 'lists.List'
    # column_names = 'ref designation list_type *'
    column_names = 'ref overview list_type default_for_new_users *'
    order_by = ['ref']

    insert_layout = dd.InsertLayout("""
    ref list_type
    designation
    remarks
    """,
                                    window_size=(60, 12))

    detail_layout = dd.DetailLayout("""
    id ref list_type print_actions
    default_for_new_users
    designation
    remarks
    MembersByList
    """)


class Member(UserAuthored, Sequenced):

    class Meta:
        app_label = 'lists'
        abstract = dd.is_abstract_model(__name__, 'Member')
        verbose_name = _("List membership")
        verbose_name_plural = _("List memberships")
        unique_together = ('user', 'list')

    quick_search_fields = "user__first_name user__last_name user__username user__email remark"
    show_in_site_search = False
    allow_cascaded_delete = "list user"

    list = dd.ForeignKey('lists.List', related_name="members")
    # partner = dd.ForeignKey(partner_model, related_name="list_memberships")
    remark = models.CharField(_("Remark"), max_length=200, blank=True)

    def __str__(self):
        return _("{} is member of {}").format(self.user, self.list)

    def as_summary_item(self, ar, text=None, **kwargs):
        if ar is None:
            obj = super()
        elif ar.is_obvious_field("list"):
            obj = self.user
        elif ar.is_obvious_field("user"):
            obj = self.list
        else:
            obj = super()
        return obj.as_summary_item(ar, text, **kwargs)


dd.update_field(Member, 'user', related_name="list_memberships", verbose_name=_("Member"))


class Members(dd.Table):
    required_roles = dd.login_required(ContactsUser)
    model = 'lists.Member'
    detail_layout = dd.DetailLayout("""
    list
    user
    remark
    """,
                                    window_size=(60, 'auto'))


class MembersByList(Members):
    label = _("Members")
    master_key = 'list'
    order_by = ['seqno']
    column_names = "seqno user user__email remark workflow_buttons *"


class MembersByUser(Members):
    master_key = 'user'
    column_names = "list remark *"
    order_by = ['list__ref']
    default_display_modes = {None: constants.DISPLAY_MODE_SUMMARY}
    # summary_sep = ", "
    insert_layout = """
    list
    remark
    """


class AllMembers(Members):
    required_roles = dd.login_required(ContactsStaff)


# dd.inject_field(
#     "system.SiteConfig",
#     "newsletter_list",
#     dd.ForeignKey("lists.List", verbose_name=_(
#         "Newsletter list"), null=True, blank=True))


add = SpecialPages.add_item

add("subscribe", _("Subscribe"), page_name="subscribe", parent='home',
    body=_("Fill in the form below to subscribe to our newsletter.") +
    "\n\n[show lists.SubscribeToListRequestsWeb.insert]")


@dd.receiver(create_user_request_executed)
def subscribe_to_default_list(sender, ar, user, **kwargs):
    List = rt.models.lists.List
    Member = rt.models.lists.Member
    for l in List.objects.filter(default_for_new_users=True):
        membership = Member(list=l, user=user)
        membership.full_clean()
        membership.save_new_instance(ar)
