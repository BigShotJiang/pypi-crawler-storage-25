# -*- coding: UTF-8 -*-

from typing import Any, Dict

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from lino.api import rt

from ...choicelists import AdminLevels
from ...geoboundaries import build_place_records, load_boundary_dataset


class Command(BaseCommand):
    help = (
        "Import geoBoundaries GeoJSON layers into countries.Place and "
        "polygon.PlaceFeature for all admin levels present in the input."
    )

    def add_arguments(self, parser: Any) -> None:
        parser.add_argument(
            "paths",
            nargs="+",
            help=(
                "One or more GeoJSON files or directories. Directories are searched "
                "recursively for *.geojson files."
            ),
        )
        parser.add_argument(
            "--country",
            dest="country",
            help=(
                "ISO country code. When omitted, the importer detects it from "
                "geoBoundaries file names or feature properties."
            ),
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            dest="dry_run",
            default=False,
            help="Parse and validate the import without writing anything to the database.",
        )

    def handle(self, *args: Any, **options: Any) -> None:
        try:
            dataset = load_boundary_dataset(options["paths"], country_code=options.get("country"))
        except ValueError as exc:
            raise CommandError(str(exc)) from exc

        supported_levels: Dict[int, Any] = {
            int(choice.value): choice for choice in AdminLevels.get_list_items()
        }
        unsupported_levels = sorted(level for level in dataset.layers if level not in supported_levels)
        if unsupported_levels:
            levels_str = ", ".join(f"ADM{level}" for level in unsupported_levels)
            raise CommandError(
                "The current polygon.AdminLevels choicelist does not define "
                f"{levels_str}. Extend the choicelist before importing these layers."
            )

        Country = rt.models.countries.Country
        Place = rt.models.countries.Place
        PlaceFeature = rt.models.polygon.PlaceFeature

        try:
            country = Country.objects.get(isocode=dataset.country_code)
        except Country.DoesNotExist as exc:
            raise CommandError(
                f"Country {dataset.country_code!r} does not exist in countries.Country."
            ) from exc

        records = build_place_records(dataset)
        self.stdout.write(
            f"Detected {len(dataset.source_paths)} GeoJSON files for {dataset.country_code}:"
        )
        for path in dataset.source_paths:
            self.stdout.write(f"  - {path}")
        self.stdout.write(
            "Admin levels found: "
            + ", ".join(f"ADM{level}" for level in sorted(dataset.layers))
        )

        place_by_record_key: Dict[str, Any] = {}
        place_created = 0
        place_updated = 0
        feature_created = 0
        feature_updated = 0

        with transaction.atomic():
            for record in records:
                adm_level = supported_levels[record.level]
                parent = (
                    place_by_record_key.get(record.parent_key)
                    if record.parent_key is not None
                    else None
                )

                place, created = self.get_or_initialize_place(
                    Place,
                    country,
                    adm_level,
                    record.name,
                    parent,
                )
                place_changed = self.update_place(place, country, adm_level, record.name, parent)
                if created:
                    place_created += 1
                elif place_changed:
                    place_updated += 1

                place.full_clean()
                place.save()

                place_by_record_key[record.key] = place

                place_feature, feature_was_created = self.get_or_initialize_feature(PlaceFeature, place)
                feature_changed = self.update_feature(place_feature, place, record)
                if feature_was_created:
                    feature_created += 1
                elif feature_changed:
                    feature_updated += 1

                place_feature.full_clean()
                place_feature.save()

            if options["dry_run"]:
                transaction.set_rollback(True)

        action = "Would import" if options["dry_run"] else "Imported"
        self.stdout.write(
            f"{action} {len(records)} places across {len(dataset.layers)} admin levels."
        )
        self.stdout.write(
            f"Places created: {place_created}, updated: {place_updated}."
        )
        self.stdout.write(
            f"Features created: {feature_created}, updated: {feature_updated}."
        )

    def get_or_initialize_place(self, Place: Any, country: Any, adm_level: Any, name: str, parent: Any):
        place = Place.objects.filter(
            country=country,
            parent=parent,
            name=name,
            adm_level=adm_level,
            type=adm_level.place_type,
        ).first()
        if place is not None:
            return place, False
        return Place(), True

    def update_place(self, place: Any, country: Any, adm_level: Any, name: str, parent: Any) -> bool:
        from django.core.exceptions import ObjectDoesNotExist
        
        changed = False
        values = {
            "country": country,
            "parent": parent,
            "name": name,
            "adm_level": adm_level,
            "type": adm_level.place_type,
        }
        for field_name, value in values.items():
            try:
                current_value = getattr(place, field_name)
            except ObjectDoesNotExist:
                # ForeignKey not yet set on new object
                current_value = None
            
            if current_value != value:
                setattr(place, field_name, value)
                changed = True
        return changed

    def get_or_initialize_feature(self, PlaceFeature: Any, place: Any):
        feature = PlaceFeature.objects.filter(place=place).first()
        if feature is not None:
            return feature, False
        return PlaceFeature(), True

    def update_feature(self, place_feature: Any, place: Any, record: Any) -> bool:
        changed = False
        values = {
            "place": place,
            "geometry": record.geometry,
            "representative_point": record.representative_point,
        }
        for field_name, value in values.items():
            current = getattr(place_feature, field_name)
            if current != value:
                setattr(place_feature, field_name, value)
                changed = True
        return changed