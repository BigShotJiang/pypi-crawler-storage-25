# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from django.contrib.gis.db.models import PointField
from django.contrib.gis.db.models.functions import Distance
from django.contrib.gis.geos import Point
from django.db.models.signals import class_prepared

from lino.api import _, dd, rt
from lino_xl.lib.countries.mixins import AddressLocation
from .choicelists import AdminLevels

LOCATION_PROCESSOR = """(() => {
    async function getGeoLocation(context, preprocessedStack) {
        async function resolveLocation(location) {
            if (!location) {
                preprocessedStack.data = Object.assign(
                    preprocessedStack.data || {},
                    {location: ""}
                );
                return;
            }
            preprocessedStack.data = {location};
            await new Promise((resolve) => {
                window.App.URLContext.actionHandler.runAction({
                    action_full_name: '%s',
                    actorId: '%s',
                    status: {
                        fv: [location],
                    },
                    response_callback: (response) => {
                        Object.assign(preprocessedStack.data, response.data_record || {});
                        resolve();
                    },
                });
            });
        }

        if (typeof window.AndroidBridge !== 'undefined' &&
            typeof window.AndroidBridge.requestLocation === 'function'
        ) {
            await new Promise((resolve) => {
                window.Android = window.Android || {};
                window.Android.onLocationReceived = async (location) => {
                    try {
                        await resolveLocation(location || "");
                    } finally {
                        delete window.Android.onLocationReceived;
                        resolve();
                    }
                };
                window.AndroidBridge.requestLocation();
            });
            return;
        }
        if (!("geolocation" in navigator)) {
            await resolveLocation("");
        } else {
            await new Promise((resolve) => {
                navigator.geolocation.getCurrentPosition(async (position) => {
                    const location = `${position.coords.latitude},${position.coords.longitude}`;
                    await resolveLocation(location);
                    resolve();
                }, (e) => {
                    resolveLocation("").finally(resolve);
                }, {
                    enableHighAccuracy: true,
                });
            });
        }
    }
    return getGeoLocation;
})()"""

BEFORE_SHOW = """(() => {
    if (!window.App) {
        return false;
    } else if (!window.App.URLContext) {
        return false;
    }
    return window.App.URLContext.globals.isMobile;
})()"""


def get_set_location_meta():
    # Insert parameters in ascending order so chooser context ForeignKeys
    # are already resolved when referenced by the next level chooser.
    adm_levels = sorted(AdminLevels.get_list_items(), key=lambda c: int(c.value))
    layout_lines = []
    parameters = {}
    for adm_level in adm_levels:
        i = int(adm_level.value)
        if i == 0:
            continue

        param_name = f"adm_level_{adm_level.value}"

        layout_lines.append(param_name)
        parameters[param_name] = dd.ForeignKey(
            "countries.Place",
            blank=True,
            null=True,
            verbose_name=adm_level.text,
        )
    layout = "\n".join(reversed(layout_lines)) + ("\n" if layout_lines else "")
    return layout, parameters


adm_level_layout, adm_level_parameters = get_set_location_meta()


class SetLocation(dd.Action):
    """An action to set the location of a model instance.
    """

    label = _("Set location")
    button_text = "📍"
    select_rows = True
    beforeshow = BEFORE_SHOW

    parameters = dict(
        location=dd.CharField(_("Location"), max_length=255, editable=False),
        addr_line_1=dd.CharField(_("Address line 1"), max_length=255, blank=True),
        country=dd.ForeignKey("countries.Country", blank=True, null=True,
                              verbose_name=_("Country")),
        **adm_level_parameters,
    )

    params_layout = f"""
    addr_line_1
    {adm_level_layout}
    country
    """

    def __init__(self, *args, **kwargs):
        adm_levels = sorted(AdminLevels.get_list_items(),
                            key=lambda c: int(c.value), reverse=True)
        for adm_level in adm_levels:
            i = int(adm_level.value)
            if i == 0:
                continue
            if i == 1:
                def get_choices(adm_level):
                    def choices(country):
                        return rt.models.countries.Place.objects.filter(
                            adm_level=adm_level, country=country)
                    choices.context_params = ("country",)
                    return choices
                setattr(self, f"adm_level_{adm_level.value}_choices", get_choices(adm_level))
            else:
                prev_param = f"adm_level_{i - 1}"
                ns = {"adm_level": adm_level, "rt": rt}
                exec(
                    f"def choices({prev_param}, country):\n"
                    f"    qs = rt.models.countries.Place.objects.filter(adm_level=adm_level, country=country)\n"
                    f"    if {prev_param}:\n"
                    f"        qs = qs.filter(parent={prev_param})\n"
                    f"    return qs",
                    ns,
                )
                fn = ns["choices"]
                fn.context_params = (prev_param, "country")
                setattr(self, f"adm_level_{adm_level.value}_choices", fn)

        super().__init__(*args, **kwargs)

    # preprocessor = LOCATION_PROCESSOR

    def run_from_ui(self, ar, **kwargs):
        apv = ar.action_param_values

        lal = AdminLevels.lowest_admin_level()
        if (ladml := getattr(apv, f"adm_level_{lal.value}", None)) is None:
            ar.error(_("Please select a {}.").format(lal.text))
            return
        prev_p = ladml
        for i in range(int(lal.value) - 1, 0, -1):
            if (p := getattr(apv, f"adm_level_{i}", None)) is None:
                ar.error(_("Please select a {}.").format(AdminLevels.get_by_value(str(i)).text))
                return
            if prev_p.parent != p:
                ar.error(_("The selected {child} does not belong to the selected {parent}.").format(
                    child=AdminLevels.get_by_value(str(i + 1)).text,
                    parent=AdminLevels.get_by_value(str(i)).text))
                return
            prev_p = p
        
        if len(ar.selected_rows) != 1:
            ar.error(_("Please select exactly one row."))
            return

        obj = ar.selected_rows[0]
        point = [
            float(c) for c in ar.action_param_values.location.split(",") if c.strip()
        ]
        point.reverse()  # GeoDjango uses (lon, lat) order
        obj.location = Point(point, srid=4326)
        ladml_field = obj.lowest_admin_level_place_field or 'place_ladml'
        setattr(obj, ladml_field, ladml)
        addr_field = obj.address_line_1_field or 'street_addr'
        setattr(obj, addr_field, ar.action_param_values.addr_line_1)
        if not rt.models.polygon.PlaceFeature.objects.filter(
            place=ladml,
            geometry__contains=obj.location
        ).exists():
            # obj.location = ladml.features.first().representative_point
            pf = ladml.features.first()
            assert pf.__class__.objects.filter(pk=pf.pk).annotate(
                distance=Distance('geometry', obj.location)
            ).first().distance.m <= 500, _(
                "The selected location is too far from the selected {}. "
                "Please select a more precise location.".format(lal.text)
            )

        if isinstance(obj, AddressLocation):
            obj.addr2 = ladml.get_parental_line_str(reverse=True, verbose=True)

        obj.on_location_changed(ar)
        obj.full_clean()
        obj.save()
        ar.success(_("Location updated."), refresh=True, close_window=True)


class ResolveLocation(dd.Action):
    label = _("Get location")
    show_in_toolbar = False
    beforeshow = BEFORE_SHOW

    def run_from_ui(self, ar, **kwargs):
        location = ar.rqdata.get("fv")
        point = [float(c) for c in location.split(",") if c.strip()]
        point.reverse()  # GeoDjango uses (lon, lat) order
        location = Point(point, srid=4326)

        locality = find_lowest_adml_place(location)

        if locality is None:
            feature = rt.models.polygon.PlaceFeature.objects.filter(
                place__adm_level=AdminLevels.lowest_admin_level(),
            ).annotate(
                distance=Distance("representative_point", location)
            ).order_by("distance").first()

            dd.logger.debug("Closest feature to %s is %s (distance: %s, representative_point: %s)",
                            location, feature, feature.distance, feature.representative_point)

            locality = feature.place

        country = locality.country if locality else dd.plugins.countries.get_my_country()

        record = {
            "country": country.name,
            "countryHidden": country.pk,
        }

        if locality is None:
            ar.set_response(data_record=record)
            return

        while locality and int(locality.adm_level.value) > 0:
            record.update({
                f"adm_level_{locality.adm_level.value}": locality.name,
                f"adm_level_{locality.adm_level.value}Hidden": locality.pk,
            })
            locality = locality.parent

        ar.set_response(data_record=record)


class ExportLocationToGoogleMaps(dd.Action):
    label = _("Open in Google Maps")
    button_text = "🗺️"
    show_in_toolbar = True

    def run_from_ui(self, ar, **kwargs):
        obj = ar.selected_rows[0]
        if not obj.location:
            ar.error(_("No location set."))
            return
        url = f"https://www.google.com/maps/search/?api=1&query={obj.location.y},{obj.location.x}"
        ar.set_response(open_url=url)


def find_lowest_adml_place(location):
    PlaceFeature = rt.models.polygon.PlaceFeature
    AdminLevels = rt.models.polygon.AdminLevels

    feature = PlaceFeature.objects.filter(
        geometry__contains=location,
        place__adm_level=AdminLevels.lowest_admin_level(),
    ).first()

    dd.logger.debug("find_lowest_adml_place(%s) -> %s", location,
                    feature.place if feature else None)

    if feature is None:
        return None

    return feature.place


class Locatable(dd.Model):
    """A mixin to add a location field to a model.
    """

    lowest_admin_level_place_field = None
    address_line_1_field = None

    class Meta:
        abstract = True

    location = PointField(_("Location"), blank=True, default=Point([]), srid=4326)

    # place_ladml is added dynamically via class_prepared signal when
    # lowest_admin_level_place_field is None (see _contribute_place_ladml below)

    # street_addr is added dynamically via class_prepared signal when
    # address_line_1_field is None (see _contribute_street_addr below)

    set_location = SetLocation()
    resolve_location = ResolveLocation()
    export_location_to_google_maps = ExportLocationToGoogleMaps()

    resolve_location_actor = None

    def on_location_changed(self, ar):
        """Hook method called when the location of an instance is changed via SetLocation.
        """
        pass

    @classmethod
    def on_analyze(cls, site):
        if cls.resolve_location_actor is None:
            raise Exception(f"{cls.__name__} must define resolve_location_actor")
        if isinstance(cls.resolve_location_actor, str):
            cls.resolve_location_actor = dd.resolve_model(cls.resolve_location_actor)
        return super().on_analyze(site)

    def full_clean(self, *args, **kwargs) -> None:
        ladml_field = self.lowest_admin_level_place_field or 'place_ladml'
        if self.location and not getattr(self, ladml_field):
            setattr(self, ladml_field, find_lowest_adml_place(self.location))
        return super().full_clean(*args, **kwargs)

    def disabled_fields(self, ar):
        dfs = super().disabled_fields(ar)
        if not self.location:
            dfs.add("export_location_to_google_maps")
        return dfs


def _contribute_place_ladml(sender, **kwargs):
    """Add place_ladml FK to concrete Locatable subclasses that don't
    redirect to an existing field via lowest_admin_level_place_field."""
    try:
        if not issubclass(sender, Locatable):
            return
    except TypeError:
        return
    if sender._meta.abstract or sender._meta.proxy:
        return
    if sender.lowest_admin_level_place_field is not None:
        return
    if any(f.name == 'place_ladml' for f in sender._meta.local_fields):
        return
    field = dd.ForeignKey(
        "countries.Place",
        blank=True,
        null=True,
        verbose_name=_("Lowest admin level place"),
        related_name="located_%(app_label)s_%(class)s_set",
    )
    field.contribute_to_class(sender, 'place_ladml')


class_prepared.connect(_contribute_place_ladml)


def _contribute_street_addr(sender, **kwargs):
    """Add street_addr CharField to concrete Locatable subclasses that don't
    redirect to an existing field via address_line_1_field."""
    try:
        if not issubclass(sender, Locatable):
            return
    except TypeError:
        return
    if sender._meta.abstract or sender._meta.proxy:
        return
    if sender.address_line_1_field is not None:
        return
    if any(f.name == 'street_addr' for f in sender._meta.local_fields):
        return
    field = dd.CharField(_("Street address"), max_length=255, blank=True)
    field.contribute_to_class(sender, 'street_addr')


class_prepared.connect(_contribute_street_addr)


@dd.receiver(dd.post_startup)
def update_preprocessor(sender, **kwargs):
    for model in rt.models_by_base(Locatable):
        tbl = model.resolve_location_actor
        set_location = tbl.get_action_by_name("set_location")
        resolve_location = tbl.get_action_by_name("resolve_location")
        set_location.action.preprocessor = LOCATION_PROCESSOR % (
            resolve_location.action.full_name(), tbl.actor_id)
