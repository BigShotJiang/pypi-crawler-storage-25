# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""Extends django.contrib.gis."""

from collections.abc import Iterable

from lino.api import ad, _


class Plugin(ad.Plugin):
    """This plugin extends :mod:`django.contrib.gis` with some custom fields and
    widgets.

    """

    verbose_name = _("Polygon")
    explicitly_load_places = False
    """Set this to True only when you want to load places data from geoBoundaries.

    This flag avoids loading places data from countries/fixtures/std.py to avoid duplicates.
    """

    def setup_explorer_menu(config, site, user_type, m, ar=None):
        m = m.add_menu(config.app_label, config.verbose_name)
        m.add_action("polygon.PlaceFeatures")
