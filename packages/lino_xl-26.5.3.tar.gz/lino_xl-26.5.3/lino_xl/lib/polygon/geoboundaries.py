import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Set, Union, cast

from django.contrib.gis.geos import GEOSGeometry, MultiPolygon


GEObOUNDARIES_FILENAME_RE = re.compile(
    r"geoBoundaries-(?P<country>[A-Za-z0-9]+)-ADM(?P<level>\d+)(?:[_-].*)?\.geojson$",
    re.IGNORECASE,
)

NAME_PROPERTY_CANDIDATES = (
    "shapeName",
    "shapeNameEn",
    "shapeNameEN",
    "shape_name",
    "name",
    "NAME",
    "name_en",
    "NAME_EN",
    "admin",
    "ADMIN",
)


@dataclass
class BoundaryFeature:
    level: int
    name: str
    geometry: MultiPolygon
    representative_point: GEOSGeometry
    properties: Dict[str, Any]
    source_path: Path
    feature_index: int
    country_code: str
    parent: Optional["BoundaryFeature"] = None
    aggregate_key: Optional[str] = None


@dataclass
class BoundaryPlaceRecord:
    key: str
    level: int
    name: str
    parent_key: Optional[str]
    geometry: MultiPolygon
    representative_point: GEOSGeometry


@dataclass
class BoundaryDataset:
    country_code: str
    source_paths: List[Path]
    layers: Dict[int, List[BoundaryFeature]]

    def iter_features(self) -> Iterator[BoundaryFeature]:
        for level in sorted(self.layers):
            yield from self.layers[level]


def discover_geojson_files(paths: Sequence[Union[str, Path]]) -> List[Path]:
    files: List[Path] = []
    seen: Set[Path] = set()
    for raw_path in paths:
        path = Path(raw_path).expanduser().resolve()
        if not path.exists():
            raise ValueError(f"Input path does not exist: {path}")
        if path.is_dir():
            for child in sorted(path.rglob("*.geojson")):
                if child not in seen:
                    seen.add(child)
                    files.append(child)
            continue
        if path.suffix.lower() != ".geojson":
            raise ValueError(f"Unsupported input file (expected .geojson): {path}")
        if path not in seen:
            seen.add(path)
            files.append(path)
    if not files:
        raise ValueError("No GeoJSON files found in the provided input paths.")
    return files


def load_boundary_dataset(
    paths: Sequence[Union[str, Path]],
    *,
    country_code: Optional[str] = None,
) -> BoundaryDataset:
    """Loads GeoJSON files from the specified paths and constructs a BoundaryDataset."""
    source_paths = discover_geojson_files(paths)
    detected_country_codes: Set[str] = set()
    layers: Dict[int, List[BoundaryFeature]] = {}

    for path in source_paths:
        payload = json.loads(path.read_text(encoding="utf-8"))
        features = _get_feature_list(path, payload)
        if not features:
            continue

        level = _detect_admin_level(path, features)
        file_country_code = _detect_country_code(path, features, country_code)
        detected_country_codes.add(file_country_code)

        layer = layers.setdefault(level, [])
        for feature_index, feature in enumerate(features):
            geometry_payload = feature.get("geometry")
            if geometry_payload is None:
                raise ValueError(f"Feature {feature_index} in {path} has no geometry.")
            properties = cast(Dict[str, Any], feature.get("properties") or {})
            name = _extract_feature_name(path, feature_index, properties)
            geometry = _geometry_to_multipolygon(geometry_payload)
            layer.append(
                BoundaryFeature(
                    level=level,
                    name=name,
                    geometry=geometry,
                    representative_point=geometry.point_on_surface,
                    properties=properties,
                    source_path=path,
                    feature_index=feature_index,
                    country_code=file_country_code,
                )
            )

    if not layers:
        raise ValueError("No GeoJSON features found in the provided input paths.")

    if country_code is not None:
        detected_country_codes = {country_code.upper()}
    if len(detected_country_codes) != 1:
        found = ", ".join(sorted(detected_country_codes)) or "none"
        raise ValueError(
            "Could not determine a single country code for this import. "
            f"Detected: {found}. Use --country to override."
        )

    _link_parent_features(layers)

    return BoundaryDataset(
        country_code=next(iter(detected_country_codes)),
        source_paths=source_paths,
        layers=layers,
    )


def build_place_records(dataset: BoundaryDataset) -> List[BoundaryPlaceRecord]:
    records_by_key: Dict[str, BoundaryPlaceRecord] = {}
    records: List[BoundaryPlaceRecord] = []

    for level in sorted(dataset.layers):
        for feature in dataset.layers[level]:
            parent_key = feature.parent.aggregate_key if feature.parent is not None else None
            record_key = _make_record_key(level, feature.name, parent_key)
            feature.aggregate_key = record_key
            existing = records_by_key.get(record_key)
            if existing is None:
                record = BoundaryPlaceRecord(
                    key=record_key,
                    level=level,
                    name=feature.name,
                    parent_key=parent_key,
                    geometry=feature.geometry,
                    representative_point=feature.representative_point,
                )
                records_by_key[record_key] = record
                records.append(record)
                continue

            existing.geometry = _geometry_to_multipolygon(existing.geometry.union(feature.geometry))
            existing.representative_point = existing.geometry.point_on_surface

    return records


def _get_feature_list(path: Path, payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    if payload.get("type") == "FeatureCollection":
        raw_features = payload.get("features") or []
        if not isinstance(raw_features, list):
            raise ValueError(f"Invalid FeatureCollection in {path}")
        features = cast(List[Dict[str, Any]], raw_features)
        return features
    if payload.get("type") == "Feature":
        return [payload]
    raise ValueError(f"Unsupported GeoJSON payload in {path}: {payload.get('type')!r}")


def _detect_admin_level(path: Path, features: Iterable[Dict[str, Any]]) -> int:
    filename_match = GEObOUNDARIES_FILENAME_RE.search(path.name)
    if filename_match is not None:
        return int(filename_match.group("level"))

    for feature in features:
        properties = cast(Dict[str, Any], feature.get("properties") or {})
        for key in ("shapeType", "shape_type", "adminLevel", "adm_level"):
            value = properties.get(key)
            level = _parse_admin_level(value)
            if level is not None:
                return level

    raise ValueError(
        f"Could not detect admin level for {path}. Expected a geoBoundaries filename or shapeType property."
    )


def _detect_country_code(
    path: Path,
    features: Iterable[Dict[str, Any]],
    override: Optional[str],
) -> str:
    if override:
        return override.upper()

    filename_match = GEObOUNDARIES_FILENAME_RE.search(path.name)
    if filename_match is not None:
        return filename_match.group("country").upper()

    for feature in features:
        properties = cast(Dict[str, Any], feature.get("properties") or {})
        for key in ("shapeGroup", "country", "country_code", "iso", "isocode"):
            value = properties.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip().upper()

    raise ValueError(
        f"Could not detect country code for {path}. Use --country to override."
    )


def _parse_admin_level(value: Any) -> Optional[int]:
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        match = re.search(r"ADM(?P<level>\d+)", value, re.IGNORECASE)
        if match is not None:
            return int(match.group("level"))
        if value.isdigit():
            return int(value)
    return None


def _extract_feature_name(path: Path, feature_index: int, properties: Dict[str, Any]) -> str:
    for key in NAME_PROPERTY_CANDIDATES:
        value = properties.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()

    for key, value in properties.items():
        if "name" in key.lower() and isinstance(value, str) and value.strip():
            return value.strip()

    raise ValueError(f"Could not determine feature name for feature {feature_index} in {path}")


def _geometry_to_multipolygon(value: Any) -> MultiPolygon:
    if isinstance(value, GEOSGeometry):
        geometry = value
        if geometry.srid is None:
            geometry.srid = 4326
    else:
        geometry = GEOSGeometry(json.dumps(value), srid=4326)

    if geometry.geom_type == "Polygon":
        return MultiPolygon(geometry, srid=geometry.srid)
    if geometry.geom_type == "MultiPolygon":
        return cast(MultiPolygon, geometry)
    raise ValueError(f"Unsupported geometry type: {geometry.geom_type}")


def _link_parent_features(layers: Dict[int, List[BoundaryFeature]]) -> None:
    parent_level: Optional[int] = None
    for level in sorted(layers):
        if parent_level is None:
            parent_level = level
            continue

        parents = layers[parent_level]
        for feature in layers[level]:
            feature.parent = _find_parent_feature(feature, parents)
            if feature.parent is None:
                raise ValueError(
                    "Could not find a parent feature for "
                    f"{feature.name!r} (ADM{feature.level}) from {feature.source_path}"
                )
        parent_level = level


def _find_parent_feature(
    child: BoundaryFeature,
    parents: Sequence[BoundaryFeature],
) -> Optional[BoundaryFeature]:
    """Find parent feature for child using spatial containment, with fallback to nearest."""
    matches: List[BoundaryFeature] = []
    for parent in parents:
        if child.representative_point.within(parent.geometry) or parent.geometry.intersects(
            child.representative_point
        ):
            matches.append(parent)

    if matches:
        # Exact match found; return smallest by area (most specific)
        if len(matches) == 1:
            return matches[0]
        matches.sort(key=lambda feature: feature.geometry.area)
        return matches[0]

    # Fallback: No exact containment; use nearest parent by distance
    # This handles simplification artifacts where boundaries shift slightly
    best_parent = None
    best_distance = float('inf')
    for parent in parents:
        distance = child.representative_point.distance(parent.geometry)
        if distance < best_distance:
            best_distance = distance
            best_parent = parent
    
    return best_parent


def _make_record_key(level: int, name: str, parent_key: Optional[str]) -> str:
    return json.dumps([level, name, parent_key], ensure_ascii=False)