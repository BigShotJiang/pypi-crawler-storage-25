# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

"""
This module defines some custom fields and widgets for working with polygons in
a :ref:`pronto` application.
"""

from django.contrib.gis.db import models
from lino.api import dd, _
from .choicelists import AdminLevels


class PlaceFeature(dd.Model):
    """A model to represent a geographical feature with a multipolygon geometry.
    """

    quick_search_fields = "place__name"

    class Meta:
        app_label = "polygon"
        abstract = dd.is_abstract_model(__name__, "PlaceFeature")
        verbose_name = _("Place feature")
        verbose_name_plural = _("Place features")

    place = dd.ForeignKey("countries.Place", blank=True, null=True,
                          verbose_name=_("Place"), unique=True, related_name="features")
    geometry = models.MultiPolygonField(_("Geometry"))
    representative_point = models.PointField(_("Representative point"), blank=True, null=True)


class PlaceFeatures(dd.Table):
    model = "polygon.PlaceFeature"
    column_names = "place"
    required_roles = dd.login_required(dd.SiteAdmin)


dd.inject_field("countries.Place", "adm_level", AdminLevels.field(blank=True, null=True))
