# -*- coding: UTF-8 -*-
# Copyright 2026 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import dd, _
from lino_xl.lib.countries.choicelists import PlaceTypes


class AdminLevel(dd.Choice):
    verbose_name = _("Admin level")
    verbose_name_plural = _("Admin levels")

    def __init__(self, value=None, text=None, names=None, **kwargs):
        self.place_type = kwargs.pop("place_type")
        super().__init__(value, text, names, **kwargs)


class AdminLevels(dd.ChoiceList):
    verbose_name = _("Admin level")
    verbose_name_plural = _("Admin levels")

    @classmethod
    def lowest_admin_level(cls):
        return sorted(cls.get_list_items(), key=lambda c: int(c.value), reverse=True)[0]


add = AdminLevels.add_item
add("0", _("Country"), "country")
add("1", _("Division / Bibhag"), "division", place_type=PlaceTypes.division)
add("2", _("District / Zila"), "district", place_type=PlaceTypes.district)
add("3", _("Subdistrict / Upazila"), "subdistrict", place_type=PlaceTypes.subdistrict)
add("4", _("Union"), "union", place_type=PlaceTypes.union)
