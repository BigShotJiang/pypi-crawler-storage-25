"""Entry point for ``python -m agentshive``.

Used by the Windows daemon-detach path (``commands/start.py:_detach_windows``)
to re-launch the daemon as a detached child process without depending on the
``agentshive.cmd`` shim being on PATH inside the parent's resolution scope.
"""

from agentshive.cli import main

if __name__ == "__main__":
    main()
