"""AgentsHive SDK CLI — zero-code setup for connecting backends to AgentsHive.

Usage:
    agentshive setup      # interactive config wizard
    agentshive start      # start background daemon
    agentshive stop       # stop daemon
    agentshive status     # show connection and backend status
    agentshive doctor     # diagnostic checks
"""

from __future__ import annotations

import argparse
import sys


def _add_profile_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--profile",
        default="",
        help="Named profile (default: 'default'). Use 'staging' for staging.",
    )


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="agentshive",
        description="AgentsHive SDK — connect your machine to AgentsHive.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # --- setup ---
    sp_setup = subparsers.add_parser(
        "setup", help="Configure the SDK (interactive wizard)"
    )
    sp_setup.add_argument(
        "--no-interactive", action="store_true", help="Skip prompts, use flags"
    )
    sp_setup.add_argument(
        "--server", default="", help="Server URL (non-interactive mode)"
    )
    sp_setup.add_argument(
        "--token", default="", help="Backend token (non-interactive mode)"
    )
    sp_setup.add_argument(
        "--check",
        action="store_true",
        help=(
            "Persistence-only probe (AC-13): exit 0 iff config loads and token "
            "is non-empty; no network I/O, no writes."
        ),
    )
    sp_setup.add_argument(
        "--staging",
        action="store_true",
        help="Shortcut: pre-fill server URL for staging.agentshive.agency",
    )
    _add_profile_arg(sp_setup)

    # --- start ---
    sp_start = subparsers.add_parser("start", help="Start the daemon")
    sp_start.add_argument(
        "--foreground", action="store_true", help="Run in foreground (Ctrl+C to stop)"
    )
    sp_start.add_argument(
        "--test-mode",
        action="store_true",
        help="Skip real CLI backends — return deterministic responses (SDK E2E testing)",
    )
    _add_profile_arg(sp_start)

    # --- stop ---
    sp_stop = subparsers.add_parser("stop", help="Stop the daemon")
    _add_profile_arg(sp_stop)

    # --- status ---
    sp_status = subparsers.add_parser("status", help="Show daemon and backend status")
    _add_profile_arg(sp_status)

    # --- doctor ---
    sp_doctor = subparsers.add_parser("doctor", help="Run diagnostic checks")
    _add_profile_arg(sp_doctor)

    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "setup":
        from agentshive.commands.setup import run_setup

        run_setup(args)
    elif args.command == "start":
        from agentshive.commands.start import run_start

        run_start(args)
    elif args.command == "stop":
        from agentshive.commands.stop import run_stop

        run_stop(args)
    elif args.command == "status":
        from agentshive.commands.status import run_status

        run_status(args)
    elif args.command == "doctor":
        from agentshive.commands.doctor import run_doctor

        run_doctor(args)


if __name__ == "__main__":
    main()
