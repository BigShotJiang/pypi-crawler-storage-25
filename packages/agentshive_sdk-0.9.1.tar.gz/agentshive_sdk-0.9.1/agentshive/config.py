"""Configuration management for the AgentsHive SDK CLI.

Supports multiple named profiles under ``~/.agentshive/profiles/``, with
legacy ``~/.agentshive/config.json`` auto-migrated on first use.

Resolution precedence:
  1. ``AGENTSHIVE_SERVER_URL`` + ``AGENTSHIVE_TOKEN`` env-var pair (highest)
  2. ``--profile <name>`` CLI flag / ``AGENTSHIVE_PROFILE`` env var
  3. ``default`` profile (lowest)
"""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass, field, asdict
from pathlib import Path

CONFIG_DIR = Path(os.environ.get("AGENTSHIVE_CONFIG_DIR", Path.home() / ".agentshive"))
PROFILES_DIR = CONFIG_DIR / "profiles"
LEGACY_CONFIG_FILE = CONFIG_DIR / "config.json"
PID_FILE = CONFIG_DIR / "daemon.pid"
PROFILE_FILE = CONFIG_DIR / "daemon.profile"
LOG_FILE = CONFIG_DIR / "daemon.log"


@dataclass
class Config:
    """SDK configuration."""

    server_url: str = "https://agentshive.agency/"
    token: str = ""
    backends: dict[str, bool | dict] = field(default_factory=dict)
    auto_start: bool = False
    log_level: str = "info"
    timeout: int = 3600
    repo_path: str | None = None
    cf_access_client_id: str = ""
    cf_access_client_secret: str = ""


def _normalize_backends(raw: dict) -> dict[str, bool | dict]:
    """Normalize backend config values.

    Accepts both ``{"codex": true}`` and
    ``{"codex": {"enabled": true, "sandbox": "danger-full-access"}}``.
    """
    result: dict[str, bool | dict] = {}
    for name, value in raw.items():
        if isinstance(value, bool):
            result[name] = value
        elif isinstance(value, dict):
            result[name] = value
        else:
            result[name] = bool(value)
    return result


class ConfigError(Exception):
    """Raised when configuration is invalid or missing."""


def _migrate_legacy_config() -> None:
    """Copy legacy config.json to profiles/default.json if profiles don't exist yet.

    Uses copy (not symlink) for Windows compatibility. Leaves the legacy file
    in place so external scripts referencing the old path keep working.
    """
    if not LEGACY_CONFIG_FILE.exists():
        return
    if PROFILES_DIR.exists() and any(PROFILES_DIR.iterdir()):
        return
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    default_profile = PROFILES_DIR / "default.json"
    if not default_profile.exists():
        shutil.copy2(str(LEGACY_CONFIG_FILE), str(default_profile))


def _profile_path(name: str) -> Path:
    """Return the path for a named profile."""
    return PROFILES_DIR / f"{name}.json"


def load_profile(name: str) -> Config:
    """Load a named profile. Raises ConfigError if not found."""
    _migrate_legacy_config()
    path = _profile_path(name)
    if not path.exists() and name == "default" and LEGACY_CONFIG_FILE.exists():
        path = LEGACY_CONFIG_FILE
    if not path.exists():
        raise ConfigError(
            f"Profile '{name}' not found: {path}\n"
            f"Run 'agentshive setup --profile {name}' to create one."
        )
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError) as exc:
        raise ConfigError(f"Invalid profile file {path}: {exc}") from exc

    raw_timeout = data.get("timeout", 3600)
    try:
        timeout = int(raw_timeout)
    except (TypeError, ValueError):
        raise ConfigError(
            f"Invalid timeout value: {raw_timeout!r} (must be a positive integer)"
        )

    return Config(
        server_url=data.get("server_url", ""),
        token=data.get("token", ""),
        backends=_normalize_backends(data.get("backends", {})),
        auto_start=data.get("auto_start", False),
        log_level=data.get("log_level", "info"),
        timeout=timeout,
        repo_path=data.get("repo_path"),
        cf_access_client_id=data.get("cf_access_client_id", ""),
        cf_access_client_secret=data.get("cf_access_client_secret", ""),
    )


def load_config() -> Config:
    """Load config from the default profile. Backward-compatible entry point."""
    _migrate_legacy_config()
    return load_profile("default")


def save_config(config: Config, *, profile: str = "default") -> None:
    """Write config to disk with restricted permissions (0o600)."""
    _migrate_legacy_config()
    path = _profile_path(profile)
    try:
        PROFILES_DIR.mkdir(parents=True, exist_ok=True)
        os.chmod(str(PROFILES_DIR), 0o700)
        content = json.dumps(asdict(config), indent=2) + "\n"
        fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            os.write(fd, content.encode())
        finally:
            os.close(fd)
    except OSError as exc:
        raise ConfigError(f"Failed to write config: {exc}") from exc


def resolve_config(profile_name: str = "default") -> Config:
    """Resolve config with full precedence: env-var pair > profile.

    ``AGENTSHIVE_SERVER_URL`` and ``AGENTSHIVE_TOKEN`` must both be set or
    both be unset. Setting only one raises ConfigError to prevent
    accidentally pairing a staging URL with a prod token.

    ``CF_ACCESS_CLIENT_ID`` and ``CF_ACCESS_CLIENT_SECRET`` override the
    profile's cf_access fields when set. They may be set independently of
    the URL/token pair (e.g. to add CF Access headers to an existing
    profile without re-entering credentials).
    """
    url_env = os.environ.get("AGENTSHIVE_SERVER_URL", "").strip()
    tok_env = os.environ.get("AGENTSHIVE_TOKEN", "").strip()

    if bool(url_env) != bool(tok_env):
        raise ConfigError(
            "AGENTSHIVE_SERVER_URL and AGENTSHIVE_TOKEN must be set together. "
            "Set both to override the saved profile, or set neither and use "
            "--profile <name>."
        )

    if url_env and tok_env:
        try:
            config = load_profile(profile_name)
        except ConfigError:
            config = Config()
        config.server_url = url_env
        config.token = tok_env
    else:
        config = load_profile(profile_name)

    cf_id = os.environ.get("CF_ACCESS_CLIENT_ID", "").strip()
    cf_secret = os.environ.get("CF_ACCESS_CLIENT_SECRET", "").strip()
    if cf_id:
        config.cf_access_client_id = cf_id
    if cf_secret:
        config.cf_access_client_secret = cf_secret

    return config


def cf_access_headers(config: Config) -> dict[str, str]:
    """Build the CF Access header dict from config, or return empty dict."""
    headers: dict[str, str] = {}
    if config.cf_access_client_id:
        headers["CF-Access-Client-Id"] = config.cf_access_client_id
    if config.cf_access_client_secret:
        headers["CF-Access-Client-Secret"] = config.cf_access_client_secret
    return headers


def validate_config(config: Config) -> list[str]:
    """Return list of validation errors (empty = valid)."""
    errors = []
    if not config.server_url:
        errors.append("server_url is required")
    if not config.token:
        errors.append("token is required")
    elif not config.token.startswith("ahv_"):
        errors.append("token must start with 'ahv_'")
    enabled = [
        k
        for k, v in config.backends.items()
        if v is True or (isinstance(v, dict) and v.get("enabled", True))
    ]
    if not enabled:
        errors.append("At least one backend must be enabled")
    if not isinstance(config.timeout, int) or config.timeout <= 0:
        errors.append("timeout must be a positive integer (seconds)")
    return errors


def detect_backends() -> dict[str, bool]:
    """Detect which CLI backends are installed on PATH.

    Returns dict mapping backend name -> is_installed.
    """
    from agentshive.backends import list_all, is_available

    return {name: is_available(name) for name in list_all()}


def write_daemon_profile(profile_name: str) -> None:
    """Write the active profile name to the daemon metadata file."""
    PROFILE_FILE.write_text(profile_name)


def read_daemon_profile() -> str | None:
    """Read the active profile name, or None if not available."""
    if not PROFILE_FILE.exists():
        return None
    try:
        return PROFILE_FILE.read_text().strip() or None
    except OSError:
        return None


def remove_daemon_profile() -> None:
    """Remove the daemon profile metadata file."""
    PROFILE_FILE.unlink(missing_ok=True)


def resolve_profile_name(args: object) -> str:
    """Resolve profile name from CLI args, env var, or default."""
    name = getattr(args, "profile", None)
    if name:
        return name
    return os.environ.get("AGENTSHIVE_PROFILE", "default")
