"""OpenClaw CLI backend."""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import time

from .base import LocalCliBackend, LocalInvocationResult

logger = logging.getLogger(__name__)


class LocalOpenClawBackend(LocalCliBackend):
    """Wraps the ``openclaw`` CLI.

    Unlike other backends, OpenClaw takes input via ``--message`` flag
    rather than stdin and outputs JSON to **stderr** instead of stdout.
    """

    supports_resume = True
    _pending_prompt: str = ""

    @classmethod
    def is_available(cls) -> bool:
        return shutil.which("openclaw") is not None

    def _base_command(self) -> list[str]:
        return ["openclaw", "agent", "--local", "--json"]

    def _build_args(self, session_id: str | None = None) -> list[str]:
        cmd = list(self._base_command())
        if session_id:
            cmd.extend(["--session-id", session_id])
        else:
            cmd.extend(["--agent", "main"])
        if self._pending_prompt:
            cmd.extend(["--message", self._pending_prompt])
        return cmd

    def _get_stdin_data(self, prompt: str) -> str | None:
        return None

    async def invoke(
        self,
        prompt: str,
        session_id: str | None = None,
        timeout: int = 3600,
        cwd: str | None = None,
    ) -> LocalInvocationResult:
        self._pending_prompt = prompt
        try:
            cmd = self._build_args(session_id)
            cmd = self._resolve_executable(cmd)
            logger.info("Invoking %s: %s", self.__class__.__name__, " ".join(cmd))

            before_files = self._snapshot_image_files(cwd)
            t0 = time.monotonic()
            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=cwd,
                    start_new_session=True,
                )
            except FileNotFoundError as exc:
                raise self._missing_executable_error(cmd) from exc
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(None),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                self._kill_process_group(proc)
                await proc.wait()
                raise TimeoutError(f"Subprocess timed out after {timeout}s")

            duration = time.monotonic() - t0
            stderr_text = stderr_bytes.decode(errors="replace")
            stdout_text = stdout_bytes.decode(errors="replace")

            if proc.returncode != 0:
                logger.error(
                    "Subprocess failed (exit %d) in %.1fs: %s",
                    proc.returncode,
                    duration,
                    stderr_text[:300],
                )
                from agentshive.rate_limit import classify_rate_limit, RateLimitError

                combined = f"{stdout_text}\n{stderr_text}"
                snippet = classify_rate_limit(combined)
                if snippet:
                    logger.warning("Rate limit detected: %s", snippet[:100])
                    raise RateLimitError("local_backend", snippet)
                raise RuntimeError(f"Subprocess exited with code {proc.returncode}")

            logger.info(
                "Subprocess completed in %.1fs (exit=%d, stderr=%d chars)",
                duration,
                proc.returncode,
                len(stderr_text),
            )

            # OpenClaw writes JSON to stderr
            combined = stderr_text if stderr_text.strip() else stdout_text
            result = self._parse_output(combined)

            new_files = self._detect_new_files(before_files, cwd)
            if new_files:
                result.generated_files = new_files

            logger.info(
                "Parsed: text=%d chars, session_id=%s, tokens=%d/%d",
                len(result.text),
                result.session_id[:8] if result.session_id else None,
                result.input_tokens,
                result.output_tokens,
            )
            return result
        finally:
            self._pending_prompt = ""

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        raw = stdout.strip()
        # Strip any non-JSON lines (e.g. debug/gateway messages) before the JSON
        lines = raw.splitlines()
        json_start = None
        for i, line in enumerate(lines):
            if line.strip().startswith("{"):
                json_start = i
                break

        if json_start is not None:
            json_text = "\n".join(lines[json_start:])
        else:
            json_text = stdout.strip()

        try:
            data = json.loads(json_text)
        except json.JSONDecodeError:
            logger.warning(
                "Failed to parse JSON from openclaw output, treating as plain text"
            )
            return LocalInvocationResult(text=stdout.strip())

        # Extract text from payloads
        payloads = data.get("payloads", [])
        text_parts = [p.get("text", "") for p in payloads if p.get("text")]
        text = "\n".join(text_parts)
        media_urls = [p.get("mediaUrl") for p in payloads if p.get("mediaUrl")]

        meta = data.get("meta", {})
        agent_meta = meta.get("agentMeta", {})
        usage = agent_meta.get("usage", {})

        return LocalInvocationResult(
            text=text,
            session_id=agent_meta.get("sessionId"),
            stop_reason=meta.get("stopReason"),
            input_tokens=usage.get("input", 0),
            output_tokens=usage.get("output", 0),
            cache_read_tokens=usage.get("cacheRead", 0),
            media_urls=media_urls,
        )
