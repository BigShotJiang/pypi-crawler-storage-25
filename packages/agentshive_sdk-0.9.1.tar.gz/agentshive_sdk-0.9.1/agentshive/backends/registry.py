"""Backend registry -- maps backend names to classes."""

from __future__ import annotations

_backends: dict[str, type] = {}


def register(name: str, cls: type) -> None:
    """Register a backend class under *name*."""
    _backends[name] = cls


def create_backend(name: str, options: dict | None = None):
    """Create an instance of the backend registered under *name*."""
    cls = _backends.get(name)
    if cls is None:
        available = ", ".join(sorted(_backends.keys()))
        raise ValueError(f"Unknown backend: '{name}'. Available: {available}")
    return cls(options=options)


def is_available(name: str) -> bool:
    """Return True if *name* is registered and its CLI is on PATH."""
    cls = _backends.get(name)
    return cls.is_available() if cls else False


def list_available() -> list[str]:
    """Return sorted names of backends whose CLI is on PATH."""
    return [n for n, c in sorted(_backends.items()) if c.is_available()]


def list_all() -> list[str]:
    """Return sorted names of all registered backends."""
    return sorted(_backends.keys())
