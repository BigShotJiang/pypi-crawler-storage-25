"""Claude Code CLI backend."""

from __future__ import annotations

import json
import logging
import shutil

from .base import LocalCliBackend, LocalInvocationResult

logger = logging.getLogger(__name__)


def _str_or_none(value: object) -> str | None:
    return value if isinstance(value, str) else None


def _number_or_zero(value: object) -> int:
    if isinstance(value, bool):
        return 0
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return 0


def _float_or_zero(value: object) -> float:
    if isinstance(value, bool):
        return 0.0
    if isinstance(value, int | float):
        return float(value)
    return 0.0


def _text_from_content(content: object) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, dict):
        text = content.get("text")
        if isinstance(text, str):
            return text
        return _text_from_content(content.get("content"))
    if isinstance(content, list):
        return "".join(_text_from_content(part) for part in content)
    return ""


def _usage_from(data: dict[str, object]) -> dict[str, object]:
    usage = data.get("usage")
    return usage if isinstance(usage, dict) else {}


def _usage_has_token_fields(usage: dict[str, object]) -> bool:
    return any(
        key in usage
        for key in ("input_tokens", "output_tokens", "cache_read_input_tokens")
    )


def _add_usage(
    totals: dict[str, int],
    usage: dict[str, object],
) -> None:
    totals["input_tokens"] += _number_or_zero(usage.get("input_tokens"))
    totals["output_tokens"] += _number_or_zero(usage.get("output_tokens"))
    totals["cache_read_input_tokens"] += _number_or_zero(
        usage.get("cache_read_input_tokens")
    )


class LocalClaudeCodeBackend(LocalCliBackend):
    """Wraps the ``claude`` CLI (Claude Code)."""

    supports_resume = True

    @classmethod
    def is_available(cls) -> bool:
        return shutil.which("claude") is not None

    def _permissions_flags(self) -> list[str]:
        if not self.options.get("skip_permissions", True):
            return []
        return ["--dangerously-skip-permissions"]

    def _model_flag(self) -> list[str]:
        model = self.options.get("model", "")
        if model:
            return ["--model", model]
        return []

    def _effort_flag(self) -> list[str]:
        level = self.options.get("thinking_level", "")
        if level in ("low", "medium", "high"):
            return ["--effort", level]
        return []

    def _base_command(self) -> list[str]:
        return [
            "claude",
            "--print",
            *self._permissions_flags(),
            *self._model_flag(),
            *self._effort_flag(),
            "--output-format",
            "json",
            "-p",
        ]

    def _build_args(self, session_id: str | None = None) -> list[str]:
        args = list(self._base_command())
        if session_id:
            p_idx = args.index("-p")
            args.insert(p_idx, "--resume")
            args.insert(p_idx + 1, session_id)
        return args

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        try:
            data = json.loads(stdout)
        except json.JSONDecodeError:
            logger.warning(
                "Failed to parse JSON from claude output, treating as plain text"
            )
            return LocalInvocationResult(text=stdout.strip())

        if isinstance(data, list):
            return self._parse_event_list(data)
        if not isinstance(data, dict):
            logger.warning(
                "Unexpected JSON from claude output (%s), treating as plain text",
                type(data).__name__,
            )
            return LocalInvocationResult(text=stdout.strip())

        return self._parse_result_object(data)

    def _parse_result_object(self, data: dict[str, object]) -> LocalInvocationResult:
        usage = data.get("usage", {})
        if not isinstance(usage, dict):
            usage = {}
        text = _str_or_none(data.get("result"))
        if text is None:
            text = _text_from_content(data.get("content"))

        return LocalInvocationResult(
            text=text,
            session_id=_str_or_none(data.get("session_id")),
            stop_reason=_str_or_none(data.get("stop_reason"))
            or _str_or_none(data.get("stopReason")),
            input_tokens=_number_or_zero(usage.get("input_tokens")),
            output_tokens=_number_or_zero(usage.get("output_tokens")),
            cache_read_tokens=_number_or_zero(usage.get("cache_read_input_tokens")),
            cost_usd=_float_or_zero(data.get("total_cost_usd")),
        )

    def _parse_event_list(self, events: list[object]) -> LocalInvocationResult:
        """Parse Claude JSON arrays emitted by some CLI/plugin combinations.

        ``--output-format json`` usually returns one result object, but recent
        Claude Code builds can also wrap the same result in a top-level array of
        events. Prefer that final result object because it already contains the
        user-visible reply and aggregate usage.
        """
        dict_events = [event for event in events if isinstance(event, dict)]
        result_event = next(
            (
                event
                for event in reversed(dict_events)
                if event.get("type") == "result"
                and isinstance(event.get("result"), str)
            ),
            None,
        )
        if result_event is None:
            result_event = next(
                (
                    event
                    for event in reversed(dict_events)
                    if isinstance(event.get("result"), str)
                ),
                None,
            )
        if result_event is not None:
            logger.info(
                "Claude output returned JSON event array; using result event "
                "(events=%d, dict_events=%d)",
                len(events),
                len(dict_events),
            )
            return self._parse_result_event(result_event, dict_events)

        logger.info(
            "Claude output returned JSON event array without result event; "
            "falling back to assistant content (events=%d, dict_events=%d)",
            len(events),
            len(dict_events),
        )

        text_parts: list[str] = []
        session_id = None
        stop_reason = None
        usage_totals = {
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_read_input_tokens": 0,
        }
        cost_usd = 0.0

        for event in dict_events:
            if session_id is None:
                session_id = _str_or_none(event.get("session_id"))
            if stop_reason is None:
                stop_reason = _str_or_none(event.get("stop_reason")) or _str_or_none(
                    event.get("stopReason")
                )
            cost_usd = _float_or_zero(event.get("total_cost_usd")) or cost_usd

            message = event.get("message")
            if isinstance(message, dict):
                if session_id is None:
                    session_id = _str_or_none(message.get("session_id"))
                if stop_reason is None:
                    stop_reason = _str_or_none(
                        message.get("stop_reason")
                    ) or _str_or_none(message.get("stopReason"))
                if (
                    event.get("type") == "assistant"
                    or message.get("role") == "assistant"
                ):
                    text_parts.append(_text_from_content(message.get("content")))
                usage = _usage_from(message)
            else:
                if event.get("role") == "assistant":
                    text_parts.append(_text_from_content(event.get("content")))
                usage = _usage_from(event)

            # This is a last-resort fallback for malformed/truncated arrays. Some
            # Claude versions report cumulative usage per event, so summed values
            # can over-count and must not override authoritative result usage.
            _add_usage(usage_totals, usage)

        return LocalInvocationResult(
            text="".join(text_parts),
            session_id=session_id,
            stop_reason=stop_reason,
            input_tokens=usage_totals["input_tokens"],
            output_tokens=usage_totals["output_tokens"],
            cache_read_tokens=usage_totals["cache_read_input_tokens"],
            cost_usd=cost_usd,
        )

    def _parse_result_event(
        self,
        result_event: dict[str, object],
        dict_events: list[dict[str, object]],
    ) -> LocalInvocationResult:
        result = self._parse_result_object(result_event)
        if _usage_has_token_fields(_usage_from(result_event)):
            return result

        usage_totals = {
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_read_input_tokens": 0,
        }
        for event in dict_events:
            message = event.get("message")
            usage = (
                _usage_from(message)
                if isinstance(message, dict)
                else _usage_from(event)
            )
            _add_usage(usage_totals, usage)

        return LocalInvocationResult(
            text=result.text,
            session_id=result.session_id,
            stop_reason=result.stop_reason,
            input_tokens=usage_totals["input_tokens"],
            output_tokens=usage_totals["output_tokens"],
            cache_read_tokens=usage_totals["cache_read_input_tokens"],
            cost_usd=result.cost_usd,
            generated_files=result.generated_files,
            media_urls=result.media_urls,
        )
