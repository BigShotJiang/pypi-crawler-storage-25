"""Hermes Agent CLI backend — plain text output, session resume via --resume <id>.

Hermes (https://github.com/nousresearch/hermes-agent) uses ``hermes chat -Q -q``
for quiet single-query mode.  Response text goes to stdout; session_id is printed
to stderr.  Because session_id lives on stderr, we override ``invoke()`` to capture
both streams (same pattern as ``LocalOpenClawBackend``).

Token usage is not reported in quiet mode.  After capturing the response, we
optionally run ``hermes sessions export --session-id <id> -`` to extract token
counts from the session database (best-effort, 2 s timeout).
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import shutil
import time

from .base import LocalCliBackend, LocalInvocationResult

logger = logging.getLogger(__name__)

_SESSION_ID_RE = re.compile(r"session_id:\s*(\S+)")


class LocalHermesBackend(LocalCliBackend):
    """Wraps the ``hermes`` CLI."""

    supports_resume = True
    _pending_prompt: str = ""

    @classmethod
    def is_available(cls) -> bool:
        return shutil.which("hermes") is not None

    def _base_command(self) -> list[str]:
        return ["hermes", "chat", "-Q", "--yolo", "-q"]

    def _build_args(self, session_id: str | None = None) -> list[str]:
        cmd = list(self._base_command())
        if session_id:
            q_idx = cmd.index("-q")
            cmd.insert(q_idx, "--resume")
            cmd.insert(q_idx + 1, session_id)
        if self._pending_prompt:
            cmd.append(self._pending_prompt)
        return cmd

    def _get_stdin_data(self, prompt: str) -> str | None:
        return None

    async def _extract_tokens(self, session_id: str | None) -> tuple[int, int, int]:
        if not session_id:
            return 0, 0, 0
        proc: asyncio.subprocess.Process | None = None
        try:
            export_cmd = self._resolve_executable(
                ["hermes", "sessions", "export", "--session-id", session_id, "-"]
            )
            proc = await asyncio.create_subprocess_exec(
                *export_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                start_new_session=True,
            )
            stdout_bytes, _ = await asyncio.wait_for(proc.communicate(), timeout=2)
            text = stdout_bytes.decode(errors="replace").strip()
            if not text:
                return 0, 0, 0
            input_tokens = 0
            output_tokens = 0
            cache_read_tokens = 0
            for line in text.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                input_tokens += int(data.get("input_tokens", 0))
                output_tokens += int(data.get("output_tokens", 0))
                cache_read_tokens += int(data.get("cache_read_tokens", 0))
            return input_tokens, output_tokens, cache_read_tokens
        except Exception:
            logger.debug("Token extraction failed for session %s", session_id)
            return 0, 0, 0
        finally:
            if proc is not None and proc.returncode is None:
                try:
                    self._kill_process_group(proc)
                    await proc.wait()
                except Exception:
                    pass

    async def invoke(
        self,
        prompt: str,
        session_id: str | None = None,
        timeout: int = 3600,
        cwd: str | None = None,
    ) -> LocalInvocationResult:
        self._pending_prompt = prompt
        try:
            cmd = self._build_args(session_id)
            cmd = self._resolve_executable(cmd)
            logger.info("Invoking %s: %s", self.__class__.__name__, " ".join(cmd))

            before_files = self._snapshot_image_files(cwd)
            t0 = time.monotonic()
            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=cwd,
                    start_new_session=True,
                )
            except FileNotFoundError as exc:
                raise self._missing_executable_error(cmd) from exc
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(None),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                self._kill_process_group(proc)
                await proc.wait()
                raise TimeoutError(f"Subprocess timed out after {timeout}s")

            duration = time.monotonic() - t0
            stdout_text = stdout_bytes.decode(errors="replace")
            stderr_text = stderr_bytes.decode(errors="replace")

            if proc.returncode != 0:
                logger.error(
                    "Subprocess failed (exit %d) in %.1fs: %s",
                    proc.returncode,
                    duration,
                    stderr_text[:300],
                )
                from agentshive.rate_limit import classify_rate_limit, RateLimitError

                combined = f"{stdout_text}\n{stderr_text}"
                snippet = classify_rate_limit(combined)
                if snippet:
                    logger.warning("Rate limit detected: %s", snippet[:100])
                    raise RateLimitError("local_backend", snippet)
                raise RuntimeError(f"Subprocess exited with code {proc.returncode}")

            logger.info(
                "Subprocess completed in %.1fs (exit=%d, stderr=%d chars)",
                duration,
                proc.returncode,
                len(stderr_text),
            )

            result_text = stdout_text.strip()
            parsed_session_id = None
            for line in stderr_text.strip().splitlines():
                match = _SESSION_ID_RE.search(line)
                if match:
                    parsed_session_id = match.group(1)
                    break

            input_tokens, output_tokens, cache_read_tokens = await self._extract_tokens(
                parsed_session_id
            )

            result = LocalInvocationResult(
                text=result_text,
                session_id=parsed_session_id,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cache_read_tokens=cache_read_tokens,
            )

            new_files = self._detect_new_files(before_files, cwd)
            if new_files:
                result.generated_files = new_files

            logger.info(
                "Parsed: text=%d chars, session_id=%s, tokens=%d/%d",
                len(result.text),
                result.session_id[:8] if result.session_id else None,
                result.input_tokens,
                result.output_tokens,
            )
            return result
        finally:
            self._pending_prompt = ""

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        return LocalInvocationResult(text=stdout.strip())
