"""agentshive start — start the daemon (foreground or background)."""

from __future__ import annotations

import argparse
import atexit
import logging
import os
import signal
import sys
import time

from agentshive.config import (
    Config,
    ConfigError,
    LOG_FILE,
    PID_FILE,
    PROFILE_FILE,
    cf_access_headers,
    read_daemon_profile,
    remove_daemon_profile,
    resolve_config,
    resolve_profile_name,
    validate_config,
    write_daemon_profile,
)

logger = logging.getLogger(__name__)

LOG_ROTATE_SIZE = 10 * 1024 * 1024  # 10 MB

_DETACHED_CHILD_ENV = "AGENTSHIVE_DETACHED_CHILD"

_WIN_DETACHED_PROCESS = 0x00000008
_WIN_CREATE_NEW_PROCESS_GROUP = 0x00000200


def _extract_backend_options(backends: dict) -> dict[str, dict]:
    """Extract per-backend option dicts from config.

    ``{"codex": true}`` -> no options.
    ``{"codex": {"enabled": true, "sandbox": "danger-full-access"}}`` -> ``{"codex": {"sandbox": "danger-full-access"}}``.
    """
    result: dict[str, dict] = {}
    for name, value in backends.items():
        if isinstance(value, dict):
            opts = {k: v for k, v in value.items() if k != "enabled"}
            if opts:
                result[name] = opts
    return result


def _rotate_log_if_large(path) -> None:
    """Rotate the daemon log on startup if it exceeds the size limit."""
    try:
        if path.exists() and path.stat().st_size > LOG_ROTATE_SIZE:
            backup = path.with_suffix(path.suffix + ".1")
            backup.unlink(missing_ok=True)
            path.rename(backup)
    except OSError:
        pass


def _is_running(pid: int) -> bool:
    """Check if a process with the given PID is alive."""
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _read_pid() -> int | None:
    """Read PID from file, return None if not found or stale."""
    if not PID_FILE.exists():
        return None
    try:
        pid = int(PID_FILE.read_text().strip())
    except (ValueError, OSError):
        return None
    if _is_running(pid):
        return pid
    PID_FILE.unlink(missing_ok=True)
    PROFILE_FILE.unlink(missing_ok=True)
    return None


def _setup_detached_child_pid(*, profile_name: str) -> None:
    """Write own PID + profile to metadata files; called at the top of
    ``_run_foreground`` when running as a Windows-detached child.
    """
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))
    write_daemon_profile(profile_name)

    def _cleanup(*_: object) -> None:
        PID_FILE.unlink(missing_ok=True)
        remove_daemon_profile()
        sys.exit(0)

    atexit.register(lambda: PID_FILE.unlink(missing_ok=True))
    atexit.register(remove_daemon_profile)
    signal.signal(signal.SIGTERM, _cleanup)
    try:
        signal.signal(signal.SIGINT, _cleanup)
    except (ValueError, OSError):
        pass


def _run_foreground(
    config: Config, *, test_mode: bool = False, profile_name: str = "default"
) -> None:
    """Run daemon in the foreground (blocking)."""
    if os.environ.get(_DETACHED_CHILD_ENV) == "1":
        _setup_detached_child_pid(profile_name=profile_name)

    from agentshive.local_runner import run_daemon

    enabled = [
        k
        for k, v in config.backends.items()
        if v is True or (isinstance(v, dict) and v.get("enabled", True))
    ]
    if not enabled and test_mode:
        from agentshive.backends import list_all

        supported = list_all() or ["claude_code"]
    else:
        supported = enabled
    run_daemon(
        server_url=config.server_url,
        token=config.token,
        supported_backends=supported,
        timeout=config.timeout,
        log_level=config.log_level.upper(),
        test_mode=test_mode,
        repo_path=config.repo_path,
        backend_options=_extract_backend_options(config.backends),
        extra_headers=cf_access_headers(config),
    )


def _detach_windows(*, test_mode: bool = False, profile_name: str = "default") -> None:
    """Launch the daemon as a detached Windows process."""
    import subprocess

    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    _rotate_log_if_large(LOG_FILE)

    log_fh = open(LOG_FILE, "ab")
    try:
        cmd = [sys.executable, "-m", "agentshive", "start", "--foreground"]
        if test_mode:
            cmd.append("--test-mode")
        if profile_name != "default":
            cmd.extend(["--profile", profile_name])

        env = {**os.environ, _DETACHED_CHILD_ENV: "1"}
        creationflags = _WIN_DETACHED_PROCESS | _WIN_CREATE_NEW_PROCESS_GROUP

        try:
            subprocess.Popen(
                cmd,
                stdin=subprocess.DEVNULL,
                stdout=log_fh,
                stderr=log_fh,
                close_fds=True,
                creationflags=creationflags,
                env=env,
            )
        except OSError as exc:
            print(f"Error: failed to start daemon: {exc}", file=sys.stderr)
            sys.exit(1)
    finally:
        log_fh.close()

    print("  Starting AgentsHive daemon...")
    deadline = time.monotonic() + 5.0
    daemon_pid: int | None = None
    while time.monotonic() < deadline:
        time.sleep(0.2)
        daemon_pid = _read_pid()
        if daemon_pid:
            break

    if daemon_pid:
        print(f"  PID: {daemon_pid}")
        print(f"  Log: {LOG_FILE}")
        print()
        print("  Daemon is running. Use 'agentshive stop' to stop.")
    else:
        print(f"  Daemon may have failed to start. Check log: {LOG_FILE}")


def _daemonize(
    config: Config, *, test_mode: bool = False, profile_name: str = "default"
) -> None:
    """Daemonize: fork on POSIX, Popen-detach on Windows."""
    if sys.platform == "win32":
        _detach_windows(test_mode=test_mode, profile_name=profile_name)
        return

    try:
        pid = os.fork()
    except OSError as exc:
        print(f"Error: failed to fork: {exc}", file=sys.stderr)
        sys.exit(1)

    if pid > 0:
        print("  Starting AgentsHive daemon...")
        time.sleep(1)
        daemon_pid = _read_pid()
        if daemon_pid:
            print(f"  PID: {daemon_pid}")
            print(f"  Log: {LOG_FILE}")
            print()
            print("  Daemon is running. Use 'agentshive stop' to stop.")
        else:
            print(f"  Daemon may have failed to start. Check log: {LOG_FILE}")
        return

    os.setsid()

    try:
        pid2 = os.fork()
    except OSError:
        os._exit(1)

    if pid2 > 0:
        os._exit(0)

    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))
    write_daemon_profile(profile_name)

    try:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        _rotate_log_if_large(LOG_FILE)
        log_fd = os.open(str(LOG_FILE), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
        os.dup2(log_fd, sys.stdout.fileno())
        os.dup2(log_fd, sys.stderr.fileno())
        os.close(log_fd)
        devnull = os.open(os.devnull, os.O_RDONLY)
        os.dup2(devnull, sys.stdin.fileno())
        os.close(devnull)
    except OSError:
        PID_FILE.unlink(missing_ok=True)
        remove_daemon_profile()
        os._exit(1)

    def _cleanup(*_):
        PID_FILE.unlink(missing_ok=True)
        remove_daemon_profile()
        sys.exit(0)

    signal.signal(signal.SIGTERM, _cleanup)
    signal.signal(signal.SIGINT, _cleanup)

    try:
        _run_foreground(config, test_mode=test_mode, profile_name=profile_name)
    finally:
        PID_FILE.unlink(missing_ok=True)
        remove_daemon_profile()


def run_start(args: argparse.Namespace) -> None:
    """Run the start command."""
    env_test_mode = os.environ.get("AGENTSHIVE_SDK_TEST_MODE", "").lower() in (
        "1",
        "true",
        "yes",
    )
    test_mode = getattr(args, "test_mode", False) or env_test_mode
    profile_name = resolve_profile_name(args)

    try:
        config = resolve_config(profile_name)
    except ConfigError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    errors = validate_config(config)
    if test_mode:
        errors = [e for e in errors if "backend" not in e.lower()]
    if errors:
        print("Config errors:", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        sys.exit(1)

    existing_pid = _read_pid()
    if existing_pid:
        running_profile = read_daemon_profile()
        if running_profile:
            print(
                f"Daemon already running under profile '{running_profile}' "
                f"(PID {existing_pid})."
            )
        else:
            print(f"Daemon is already running (PID {existing_pid}).")
        print("Stop it (`agentshive stop`) before starting under a different profile.")
        sys.exit(0)

    if test_mode:
        print("  Test mode: real backends bypassed — deterministic responses only")

    enabled = [k for k, v in config.backends.items() if v]
    print()
    print(f"  Server:   {config.server_url}")
    print(f"  Profile:  {profile_name}")
    print(f"  Backends: {', '.join(enabled) or '(none — test mode)'}")
    print()

    if args.foreground:
        _run_foreground(config, test_mode=test_mode, profile_name=profile_name)
    else:
        _daemonize(config, test_mode=test_mode, profile_name=profile_name)
