"""agentshive setup — interactive (or non-interactive) configuration wizard."""

from __future__ import annotations

import argparse
import sys

from agentshive.config import (
    Config,
    ConfigError,
    PROFILES_DIR,
    detect_backends,
    load_profile,
    resolve_profile_name,
    save_config,
)


def _mask_token(token: str) -> str:
    if len(token) <= 8:
        return "****"
    return token[:4] + "****"


def _prompt(label: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    val = input(f"  {label}{suffix}: ").strip()
    return val or default


def _confirm(label: str, default: bool = False) -> bool:
    hint = "Y/n" if default else "y/N"
    val = input(f"  {label} [{hint}] ").strip().lower()
    if not val:
        return default
    return val in ("y", "yes")


def run_setup(args: argparse.Namespace) -> None:
    """Run the setup command."""
    if getattr(args, "check", False):
        _run_check(args)
        return

    profile_name = resolve_profile_name(args)

    existing = Config()
    try:
        existing = load_profile(profile_name)
    except ConfigError:
        pass

    if args.staging:
        if not args.server:
            args.server = "https://staging.agentshive.agency"
        if profile_name == "default":
            profile_name = "staging"
            existing = Config()
            try:
                existing = load_profile(profile_name)
            except ConfigError:
                pass

    if args.server:
        existing.server_url = args.server
    if args.token:
        existing.token = args.token

    if args.no_interactive:
        _run_non_interactive(args, existing, profile_name)
    else:
        _run_interactive(existing, profile_name)


def _run_check(args: argparse.Namespace) -> None:
    """AC-13 persistence-only probe."""
    profile_name = resolve_profile_name(args)
    try:
        existing = load_profile(profile_name)
    except ConfigError:
        sys.exit(1)
    if not existing.token:
        sys.exit(1)
    sys.exit(0)


def _profile_display_path(profile_name: str) -> str:
    return str(PROFILES_DIR / f"{profile_name}.json")


def _run_interactive(existing: Config, profile_name: str) -> None:
    print()
    print(f"  AgentsHive SDK Setup (profile: {profile_name})")
    print()

    server_url = _prompt("Server URL", existing.server_url)
    token_default = _mask_token(existing.token) if existing.token else ""
    token_input = _prompt("Backend token", token_default)
    if token_input == token_default:
        token = existing.token
    else:
        token = token_input

    print()
    print("  Detecting installed backends...")
    detected = detect_backends()
    for name, found in sorted(detected.items()):
        mark = "\u2713 found" if found else "\u2717 not found"
        print(f"    {name:15s} {mark}")
    print()

    backends: dict[str, bool] = {}
    for name, found in sorted(detected.items()):
        if found:
            prev = existing.backends.get(name, True)
            backends[name] = _confirm(f"Enable {name}?", default=prev)
        else:
            backends[name] = False

    print()
    auto_start = _confirm("Start daemon on login?", default=existing.auto_start)

    config = Config(
        server_url=server_url,
        token=token,
        backends=backends,
        auto_start=auto_start,
        log_level=existing.log_level,
        timeout=existing.timeout,
        repo_path=existing.repo_path,
        cf_access_client_id=existing.cf_access_client_id,
        cf_access_client_secret=existing.cf_access_client_secret,
    )
    save_config(config, profile=profile_name)
    print()
    print(f"  Config saved to {_profile_display_path(profile_name)}")
    print(f"  Run 'agentshive start --profile {profile_name}' to connect.")
    print()


def _run_non_interactive(
    args: argparse.Namespace, existing: Config, profile_name: str
) -> None:
    server_url = args.server or existing.server_url
    token = args.token or existing.token

    if not server_url:
        print("Error: --server is required in non-interactive mode", file=sys.stderr)
        sys.exit(1)
    if not token:
        print("Error: --token is required in non-interactive mode", file=sys.stderr)
        sys.exit(1)

    detected = detect_backends()
    backends: dict[str, bool | dict] = {}
    for name, found in detected.items():
        existing_val = existing.backends.get(name)
        if found and isinstance(existing_val, dict):
            backends[name] = {**existing_val, "enabled": True}
        elif found:
            backends[name] = True
        elif isinstance(existing_val, dict):
            backends[name] = {**existing_val, "enabled": False}
        else:
            backends[name] = False

    config = Config(
        server_url=server_url,
        token=token,
        backends=backends,
        auto_start=existing.auto_start,
        log_level=existing.log_level,
        timeout=existing.timeout,
        repo_path=existing.repo_path,
        cf_access_client_id=existing.cf_access_client_id,
        cf_access_client_secret=existing.cf_access_client_secret,
    )
    save_config(config, profile=profile_name)
    enabled = [k for k, v in backends.items() if v]
    print(f"Config saved to {_profile_display_path(profile_name)}")
    print(f"Backends enabled: {', '.join(enabled) or 'none'}")
