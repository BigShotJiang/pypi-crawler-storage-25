"""agentshive doctor — diagnostic checks."""

from __future__ import annotations

import argparse
import shutil
import sys

from agentshive.config import (
    Config,
    ConfigError,
    PID_FILE,
    PROFILES_DIR,
    cf_access_headers,
    read_daemon_profile,
    resolve_config,
    resolve_profile_name,
)

# Probe budgets accommodate SOCKS-proxy + CDN-fronted TLS handshakes
# (10-30s typical from China-mainland with Cloudflare fronting). Direct-
# network customers still see ms-scale completion; only the failure-path
# latency changes. RFC doctrine: "every probe has a budget appropriate to
# its network path."
_SERVER_PROBE_TIMEOUT_S = 30
_WS_HANDSHAKE_TIMEOUT_S = 30

# The websockets library raises this exact substring verbatim when it
# encounters a SOCKS proxy env var (ALL_PROXY / HTTPS_PROXY=socks5://...)
# but cannot import `python_socks`. Customers can't know the install-
# method-specific fix from the bare message, so doctor surfaces it inline.
_SOCKS_PYTHON_SOCKS_MARKER = "connecting through a SOCKS proxy requires python-socks"
_SOCKS_DEP_SPEC = "python-socks[asyncio]"


def _detect_install_method() -> str:
    """Detect how agentshive-sdk was installed by inspecting sys.executable.

    Returns one of:
    - "uv-tool" — sys.executable lives under .../uv/tools/<pkg>/... (the
      path agenthive's install.sh.tmpl ships at line 9-10).
    - "pipx"    — sys.executable lives under .../pipx/venvs/<pkg>/...
    - "pip"     — neither substring present (plain venv, system pip, conda).

    Both substrings are pipx/uv layout conventions baked into the tool, not
    user-configurable, so detection is reliable across $PIPX_HOME /
    $UV_TOOL_DIR overrides.
    """
    exe = sys.executable
    if "/uv/tools/" in exe:
        return "uv-tool"
    if "/pipx/venvs/" in exe:
        return "pipx"
    return "pip"


def _fix_command_for_missing_dep(dep_spec: str) -> str:
    """Build the install-method-appropriate command to inject `dep_spec`
    into the running agentshive-sdk install.

    Why this branches: `pip install <dep>` lands in whichever Python env
    happens to be active, which is typically NOT the isolated venv that
    uv-tool / pipx created for this CLI. Customer-visible symptom is "I
    installed it but doctor still says missing" — three iterations of
    that on a single ticket (2026-05-16) before substrate-grep grounded
    the canonical install path as `uv tool install`.
    """
    method = _detect_install_method()
    if method == "uv-tool":
        return f"uv tool install --with '{dep_spec}' agentshive-sdk"
    if method == "pipx":
        return f"pipx inject agentshive-sdk '{dep_spec}'"
    return f"pip install '{dep_spec}'"


# Indent so the "→" hint arrow lines up under the detail column of a _check
# row above it. _check format is `f"  {label:20s} {mark}{suffix}"` where
# suffix carries a leading space — so detail text starts at column 26
# (0-indexed column 25). 25 leading spaces puts "→" directly under the
# detail's first character.
_HINT_INDENT = " " * 25


def _check(label: str, ok: bool, detail: str = "") -> bool:
    mark = "\u2713" if ok else "\u2717"
    suffix = f" {detail}" if detail else ""
    print(f"  {label:20s} {mark}{suffix}")
    return ok


def run_doctor(_args: argparse.Namespace) -> None:
    """Run the doctor command."""
    print()
    all_ok = True

    profile_name = resolve_profile_name(_args)
    profile_path = PROFILES_DIR / f"{profile_name}.json"

    # 1. Config file
    config: Config | None = None
    try:
        config = resolve_config(profile_name)
        all_ok &= _check("Config", True, str(profile_path))
    except ConfigError:
        all_ok &= _check("Config", False, f"not found (profile '{profile_name}')")

    # 2. Profile
    all_ok &= _check("Profile", True, profile_name)

    # 2. Token
    if config:
        has_token = bool(config.token) and config.token.startswith("ahv_")
        masked = (
            config.token[:4] + "****" + config.token[-4:]
            if len(config.token) > 8
            else "(not set)"
        )
        all_ok &= _check("Token", has_token, masked)
    else:
        all_ok &= _check("Token", False, "no config")

    # 3. Server reachable
    if config and config.server_url:
        try:
            import httpx
        except ImportError:
            all_ok &= _check("Server", False, "httpx not installed (pip install httpx)")
            httpx = None  # type: ignore[assignment]
        if httpx is not None:
            try:
                headers = cf_access_headers(config)
                resp = httpx.get(
                    config.server_url,
                    timeout=_SERVER_PROBE_TIMEOUT_S,
                    follow_redirects=True,
                    headers=headers or None,
                )
                all_ok &= _check(
                    "Server", True, f"{config.server_url} (HTTP {resp.status_code})"
                )
            except Exception as exc:
                all_ok &= _check("Server", False, f"{config.server_url} ({exc})")
    else:
        all_ok &= _check("Server", False, "no server_url configured")

    # 4. WebSocket TLS (catches SSL cert issues proactively — the same class
    # of failure that leaves the daemon stuck in a reconnect loop).
    if config and config.server_url and config.token:
        all_ok &= _check_websocket(config)

    # 5. Backends
    print()
    print("  Backends:")
    from agentshive.backends import list_all

    for name in list_all():
        binary = _get_binary_name(name)
        path = shutil.which(binary)
        if path:
            all_ok &= _check(f"    {name}", True, f"{binary} found")
        else:
            _check(f"    {name}", False, f"{binary} not on PATH")
            # Not a hard failure — some backends being missing is fine

    # 6. Daemon
    print()
    import os

    pid = None
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            try:
                os.kill(pid, 0)
            except OSError:
                pid = None
        except (ValueError, OSError):
            pid = None
    if pid:
        running_profile = read_daemon_profile()
        suffix = f" (profile: {running_profile})" if running_profile else ""
        _check("Daemon", True, f"running (PID {pid}){suffix}")
    else:
        _check("Daemon", False, "not running")

    # Timeout-migration hint: the SDK default moved from 300s to 3600s. An
    # existing config.json written under the old default keeps timeout=300
    # because setup preserves explicit values. Users seeing agent replies
    # killed at ~5 min should upgrade. Auto-migrating disk values would
    # silently override user intent, so we surface the upgrade path instead.
    if config and isinstance(config.timeout, int) and config.timeout < 600:
        print(
            f"  Timeout hint:        config.timeout={config.timeout}s "
            f"(< 600s). New SDK default is 3600s (60 min). Edit "
            f"{profile_path} to update."
        )

    # Vendor-URL hint (sdk-cli-spec.md v1.2 shell-installer, agenthive@226666f
    # ownership table). When the installer is the vendor of record, the CEO's
    # recovery path on a failed doctor run is a re-curl against the workspace.
    # Deriving the URL from `server_url` avoids a second config surface.
    if config and config.server_url:
        vendor_url = config.server_url.rstrip("/") + "/api/install.sh"
        print(f"  Re-install:           {vendor_url}?token=<your-token>")
        print()

    if all_ok:
        print("  All checks passed.")
    else:
        print("  Some checks failed. Fix the issues above.")
    print()

    if not all_ok:
        sys.exit(1)


def _check_websocket(config: Config) -> bool:
    """Attempt a short-lived WebSocket handshake to verify TLS and auth."""
    import asyncio

    try:
        import websockets
    except ImportError:
        return _check("WebSocket", False, "websockets not installed")

    from agentshive.ws import _build_ssl_context

    ws_url = (
        config.server_url.replace("https://", "wss://")
        .replace("http://", "ws://")
        .rstrip("/")
    ) + f"/api/ws/backend?token={config.token}"
    # websockets.connect() rejects ssl= on ws:// URIs. Only build a TLS
    # context when the server is actually wss:// so local dev servers
    # (http://localhost:...) still work.
    ssl_ctx = _build_ssl_context() if ws_url.startswith("wss://") else None
    ok_label = "TLS + auth OK" if ssl_ctx else "auth OK (no TLS)"
    extra = cf_access_headers(config)
    connect_kwargs: dict = {
        "ssl": ssl_ctx,
        "open_timeout": _WS_HANDSHAKE_TIMEOUT_S,
        "close_timeout": 2,
    }
    if extra:
        connect_kwargs["additional_headers"] = extra

    async def _probe():
        async with websockets.connect(ws_url, **connect_kwargs):
            return True

    try:
        asyncio.run(_probe())
        return _check("WebSocket", True, ok_label)
    except Exception as exc:
        # Some websockets exceptions (e.g. InvalidURI) include the full URL in
        # their message — which contains the token. Redact before displaying.
        raw_detail = str(exc).replace(config.token, "ahv_***")
        detail = raw_detail[:77] + "..." if len(raw_detail) > 80 else raw_detail
        result = _check("WebSocket", False, detail)
        # Surface install-method-aware remediation for the missing-python-socks
        # case. Match against `raw_detail` (not the truncated `detail`) so the
        # marker still matches when the raw error is longer than 80 chars.
        if _SOCKS_PYTHON_SOCKS_MARKER in raw_detail:
            fix = _fix_command_for_missing_dep(_SOCKS_DEP_SPEC)
            print(f"{_HINT_INDENT}→ Fix: {fix}")
        return result


def _get_binary_name(backend_name: str) -> str:
    """Map backend registry name to expected CLI binary name."""
    mapping = {
        "claude_code": "claude",
        "gemini_cli": "gemini",
        "codex": "codex",
        "kimi_cli": "kimi",
        "openclaw": "openclaw",
        "opencode": "opencode",
    }
    return mapping.get(backend_name, backend_name)
