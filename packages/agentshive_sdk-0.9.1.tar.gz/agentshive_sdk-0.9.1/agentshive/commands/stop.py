"""agentshive stop — stop the running daemon."""

from __future__ import annotations

import argparse
import os
import signal
import sys
import time

from agentshive.config import PID_FILE, remove_daemon_profile


def run_stop(_args: argparse.Namespace) -> None:
    """Run the stop command."""
    if not PID_FILE.exists():
        print("Daemon is not running.")
        return

    try:
        pid = int(PID_FILE.read_text().strip())
    except (ValueError, OSError):
        print("Daemon is not running (invalid PID file).")
        PID_FILE.unlink(missing_ok=True)
        remove_daemon_profile()
        return

    try:
        os.kill(pid, 0)
    except OSError:
        print("Daemon is not running (stale PID file).")
        PID_FILE.unlink(missing_ok=True)
        remove_daemon_profile()
        return

    os.kill(pid, signal.SIGTERM)
    for _ in range(30):
        time.sleep(0.1)
        try:
            os.kill(pid, 0)
        except OSError:
            PID_FILE.unlink(missing_ok=True)
            remove_daemon_profile()
            print(f"Stopped AgentsHive daemon (PID {pid}).")
            return

    print("Daemon did not stop gracefully. Sending SIGKILL...", file=sys.stderr)
    try:
        os.kill(pid, signal.SIGKILL)
        time.sleep(0.2)
    except OSError:
        pass
    PID_FILE.unlink(missing_ok=True)
    remove_daemon_profile()
    print(f"Killed AgentsHive daemon (PID {pid}).")
