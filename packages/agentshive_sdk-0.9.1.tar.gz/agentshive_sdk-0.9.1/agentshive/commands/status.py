"""agentshive status — show daemon and backend status."""

from __future__ import annotations

import argparse
import os

from agentshive.config import (
    ConfigError,
    PID_FILE,
    PROFILES_DIR,
    detect_backends,
    read_daemon_profile,
    resolve_config,
    resolve_profile_name,
)


def _is_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def run_status(args: argparse.Namespace) -> None:
    """Run the status command."""
    print()

    profile_name = resolve_profile_name(args)

    try:
        config = resolve_config(profile_name)
    except ConfigError:
        print(f"  Config:  not found (profile '{profile_name}')")
        print("  Run 'agentshive setup' first.")
        print()
        return

    profile_path = PROFILES_DIR / f"{profile_name}.json"

    pid = None
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            if not _is_running(pid):
                pid = None
                PID_FILE.unlink(missing_ok=True)
        except (ValueError, OSError):
            pid = None

    if pid:
        running_profile = read_daemon_profile()
        profile_suffix = f" (profile: {running_profile})" if running_profile else ""
        print(f"  Daemon:    running (PID {pid}){profile_suffix}")
    else:
        print("  Daemon:    stopped")

    print(f"  Profile:   {profile_name}")
    print(f"  Config:    {profile_path}")
    print(f"  Server:    {config.server_url}")
    print()

    detected = detect_backends()
    print("  Backends:")
    for name in sorted(set(list(config.backends.keys()) + list(detected.keys()))):
        enabled = config.backends.get(name, False)
        installed = detected.get(name, False)
        if enabled and installed:
            status = "\u2713 enabled, available"
        elif enabled and not installed:
            status = "\u2713 enabled, NOT INSTALLED"
        elif not enabled and installed:
            status = "- disabled (installed)"
        else:
            status = "- not installed"
        print(f"    {name:15s} {status}")

    print()
