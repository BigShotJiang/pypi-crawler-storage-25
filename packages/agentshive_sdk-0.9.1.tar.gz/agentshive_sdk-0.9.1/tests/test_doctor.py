"""Tests for agentshive.commands.doctor."""

from __future__ import annotations

import pytest

from agentshive.commands.doctor import (
    _check_websocket,
    _detect_install_method,
    _fix_command_for_missing_dep,
    _SERVER_PROBE_TIMEOUT_S,
    _WS_HANDSHAKE_TIMEOUT_S,
)
from agentshive.config import Config


def test_check_websocket_redacts_token_on_error(monkeypatch, capsys):
    """An exception message containing the token must not leak to stdout."""
    token = "ahv_SECRETTOKEN_SHOULD_NEVER_APPEAR_IN_OUTPUT"
    config = Config(
        server_url="https://agentshive.agency/",
        token=token,
        backends={"claude_code": True},
    )

    import websockets

    def fake_connect(*_args, **_kwargs):
        # Mimic websockets.InvalidURI / similar: message echoes the full URL.
        raise ValueError(f"invalid URI wss://example/api/ws/backend?token={token}")

    monkeypatch.setattr(websockets, "connect", fake_connect)

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is False
    assert token not in out, "token leaked to stdout"
    assert "ahv_***" in out


@pytest.mark.parametrize(
    "exc",
    [
        RuntimeError("no URL in message"),
        ConnectionRefusedError("connection refused"),
    ],
)
def test_check_websocket_reports_error_without_token(monkeypatch, capsys, exc):
    """Errors without token in message still surface a useful detail."""
    config = Config(
        server_url="https://agentshive.agency/",
        token="ahv_irrelevant",
        backends={"claude_code": True},
    )

    import websockets

    def fake_connect(*_args, **_kwargs):
        raise exc

    monkeypatch.setattr(websockets, "connect", fake_connect)

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is False
    assert "WebSocket" in out


class _FakeConn:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *_args):
        return False


def _capture_connect(monkeypatch):
    """Stub websockets.connect and return a dict that captures call kwargs."""
    captured: dict = {}

    def fake_connect(*args, **kwargs):
        captured["args"] = args
        captured["kwargs"] = kwargs
        return _FakeConn()

    import websockets

    monkeypatch.setattr(websockets, "connect", fake_connect)
    return captured


def test_check_websocket_passes_no_ssl_for_http_server(monkeypatch, capsys):
    """http:// (→ ws://) must not receive an ssl context — websockets rejects it."""
    config = Config(
        server_url="http://localhost:8000",
        token="ahv_dev",
        backends={"claude_code": True},
    )
    captured = _capture_connect(monkeypatch)

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is True
    assert captured["kwargs"]["ssl"] is None
    assert "no TLS" in out


def test_check_websocket_passes_ssl_for_https_server(monkeypatch, capsys):
    """https:// (→ wss://) must receive a TLS context."""
    config = Config(
        server_url="https://agentshive.agency/",
        token="ahv_real",
        backends={"claude_code": True},
    )
    captured = _capture_connect(monkeypatch)

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is True
    assert captured["kwargs"]["ssl"] is not None
    assert "TLS + auth OK" in out


def test_doctor_warns_when_timeout_below_new_default(tmp_path, monkeypatch, capsys):
    """Users with timeout < 600s (e.g. the old 300s default) should see an
    upgrade hint. setup preserves existing values, so the hint is the only
    visible migration path for dogfood users on the old default."""
    from agentshive.config import save_config
    from agentshive.cli import main

    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.PROFILES_DIR", tmp_path / "profiles")
    monkeypatch.setattr(
        "agentshive.config.LEGACY_CONFIG_FILE", tmp_path / "config.json"
    )
    monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
    monkeypatch.setattr("agentshive.config.PROFILE_FILE", tmp_path / "daemon.profile")
    monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")
    monkeypatch.setattr(
        "agentshive.commands.doctor.PROFILES_DIR", tmp_path / "profiles"
    )
    monkeypatch.setattr("agentshive.commands.doctor.PID_FILE", tmp_path / "daemon.pid")

    save_config(
        Config(
            server_url="https://agentshive.example.com/",
            token="ahv_old_default_user",
            backends={"claude_code": True},
            timeout=300,
        )
    )

    monkeypatch.setattr("agentshive.commands.doctor._check_websocket", lambda _c: True)

    class _FakeResp:
        status_code = 200

    monkeypatch.setattr("httpx.get", lambda *_a, **_k: _FakeResp())

    try:
        main(["doctor"])
    except SystemExit:
        pass

    out = capsys.readouterr().out
    assert "Timeout hint" in out
    assert "300s" in out
    assert "3600s" in out


def test_doctor_no_timeout_hint_when_above_threshold(tmp_path, monkeypatch, capsys):
    """A config with timeout >= 600s should not see the upgrade hint."""
    from agentshive.config import save_config
    from agentshive.cli import main

    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.PROFILES_DIR", tmp_path / "profiles")
    monkeypatch.setattr(
        "agentshive.config.LEGACY_CONFIG_FILE", tmp_path / "config.json"
    )
    monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
    monkeypatch.setattr("agentshive.config.PROFILE_FILE", tmp_path / "daemon.profile")
    monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")
    monkeypatch.setattr(
        "agentshive.commands.doctor.PROFILES_DIR", tmp_path / "profiles"
    )
    monkeypatch.setattr("agentshive.commands.doctor.PID_FILE", tmp_path / "daemon.pid")

    save_config(
        Config(
            server_url="https://agentshive.example.com/",
            token="ahv_new_user",
            backends={"claude_code": True},
            timeout=3600,
        )
    )

    monkeypatch.setattr("agentshive.commands.doctor._check_websocket", lambda _c: True)

    class _FakeResp:
        status_code = 200

    monkeypatch.setattr("httpx.get", lambda *_a, **_k: _FakeResp())

    try:
        main(["doctor"])
    except SystemExit:
        pass

    out = capsys.readouterr().out
    assert "Timeout hint" not in out


@pytest.mark.parametrize(
    "executable,expected",
    [
        ("/Users/x/.local/share/uv/tools/agentshive-sdk/bin/python", "uv-tool"),
        ("/home/user/.local/pipx/venvs/agentshive-sdk/bin/python", "pipx"),
        ("/usr/local/bin/python3.11", "pip"),
        ("/Users/x/.pyenv/versions/3.11.7/bin/python", "pip"),
        # uv-tool with non-default UV_TOOL_DIR — the `/uv/tools/` substring
        # is still in the path by uv's convention.
        ("/custom/uv/tools/agentshive-sdk/bin/python", "uv-tool"),
        # pipx with non-default PIPX_HOME — same convention.
        ("/opt/pipx/venvs/agentshive-sdk/bin/python", "pipx"),
    ],
)
def test_detect_install_method_branches(monkeypatch, executable, expected):
    """sys.executable layout-convention substrings distinguish uv-tool /
    pipx / pip installs. Doctor's `→ Fix:` hint depends on this routing —
    the cost of a wrong hint is a customer support cycle (confirmed
    2026-05-16: pip-install lands in pyenv-global while agentshive runs
    from the uv-tool venv, dep doesn't take effect)."""
    monkeypatch.setattr("sys.executable", executable)
    assert _detect_install_method() == expected


def test_fix_command_for_missing_dep_uv_tool(monkeypatch):
    monkeypatch.setattr(
        "sys.executable",
        "/Users/x/.local/share/uv/tools/agentshive-sdk/bin/python",
    )
    assert _fix_command_for_missing_dep("python-socks[asyncio]") == (
        "uv tool install --with 'python-socks[asyncio]' agentshive-sdk"
    )


def test_fix_command_for_missing_dep_pipx(monkeypatch):
    monkeypatch.setattr(
        "sys.executable",
        "/home/user/.local/pipx/venvs/agentshive-sdk/bin/python",
    )
    assert _fix_command_for_missing_dep("python-socks[asyncio]") == (
        "pipx inject agentshive-sdk 'python-socks[asyncio]'"
    )


def test_fix_command_for_missing_dep_pip_fallback(monkeypatch):
    monkeypatch.setattr("sys.executable", "/usr/local/bin/python3.11")
    assert _fix_command_for_missing_dep("python-socks[asyncio]") == (
        "pip install 'python-socks[asyncio]'"
    )


def test_check_websocket_prints_socks_fix_hint_on_python_socks_error(
    monkeypatch, capsys
):
    """When websockets raises the SOCKS-requires-python-socks error, doctor
    surfaces the install-method-appropriate inject command on a follow-up
    line so the customer doesn't need to know the env layout themselves."""
    config = Config(
        server_url="https://agentshive.agency/",
        token="ahv_socks_user",
        backends={"claude_code": True},
    )

    import websockets

    def fake_connect(*_args, **_kwargs):
        raise OSError("connecting through a SOCKS proxy requires python-socks")

    monkeypatch.setattr(websockets, "connect", fake_connect)
    monkeypatch.setattr(
        "sys.executable",
        "/Users/x/.local/share/uv/tools/agentshive-sdk/bin/python",
    )

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is False
    assert "WebSocket" in out
    assert "→ Fix:" in out
    assert "uv tool install --with 'python-socks[asyncio]' agentshive-sdk" in out


def test_check_websocket_omits_fix_hint_when_error_is_not_socks(monkeypatch, capsys):
    """Generic WS errors (connection refused, TLS issues, timeouts) must NOT
    spam an irrelevant Fix hint — only the python-socks failure mode gets
    the install-method-aware remediation."""
    config = Config(
        server_url="https://agentshive.agency/",
        token="ahv_other_err",
        backends={"claude_code": True},
    )

    import websockets

    def fake_connect(*_args, **_kwargs):
        raise ConnectionRefusedError("connection refused")

    monkeypatch.setattr(websockets, "connect", fake_connect)

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is False
    assert "WebSocket" in out
    assert "→ Fix:" not in out


def test_check_websocket_matches_socks_marker_even_when_truncated(monkeypatch, capsys):
    """The fix hint check matches against the raw (untruncated) error
    message. A long surrounding error chain that pushes the marker past
    char 80 must still trigger the hint."""
    config = Config(
        server_url="https://agentshive.agency/",
        token="ahv_long_error",
        backends={"claude_code": True},
    )

    import websockets

    long_err = (
        "x" * 100 + " connecting through a SOCKS proxy requires python-socks "
        "(originally raised by python_socks loader chain)"
    )

    def fake_connect(*_args, **_kwargs):
        raise OSError(long_err)

    monkeypatch.setattr(websockets, "connect", fake_connect)
    monkeypatch.setattr("sys.executable", "/usr/local/bin/python3.11")

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is False
    assert "→ Fix: pip install 'python-socks[asyncio]'" in out


def test_check_websocket_uses_30s_open_timeout(monkeypatch, capsys):
    """SOCKS-proxy + CDN-fronted TLS handshakes take 10-30s on first
    connection; the prior 5s probe budget false-failed proxy-routed
    customers. The constant is the load-bearing thing — assert its value
    AND that websockets.connect receives it. Pin both so a constant change
    requires a test update (forcing the doctrine note to stay current)."""
    config = Config(
        server_url="https://agentshive.agency/",
        token="ahv_timeout",
        backends={"claude_code": True},
    )
    captured = _capture_connect(monkeypatch)

    assert _WS_HANDSHAKE_TIMEOUT_S == 30
    ok = _check_websocket(config)
    capsys.readouterr()  # drain

    assert ok is True
    assert captured["kwargs"]["open_timeout"] == 30


def test_server_probe_timeout_constant_is_30s():
    """Matches _WS_HANDSHAKE_TIMEOUT_S — both probes share the same
    proxy-friendly budget. Doctor doctrine: "every probe has a budget
    appropriate to its network path." Pin so future timeouts changes are
    visible in test diff."""
    assert _SERVER_PROBE_TIMEOUT_S == 30


def test_doctor_prints_reinstall_vendor_url(tmp_path, monkeypatch, capsys):
    """sdk-cli-spec.md v1.2 (agenthive@226666f): doctor surfaces the vendor
    URL the CEO can re-curl from, derived from the configured server_url so
    there's no second config surface to drift. Token value stays the
    placeholder `<your-token>` — doctor must never print real tokens to
    stdout on the vendor-URL line (token output is gated by the Token row
    masking elsewhere)."""
    from agentshive.config import save_config
    from agentshive.cli import main

    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.PROFILES_DIR", tmp_path / "profiles")
    monkeypatch.setattr(
        "agentshive.config.LEGACY_CONFIG_FILE", tmp_path / "config.json"
    )
    monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
    monkeypatch.setattr("agentshive.config.PROFILE_FILE", tmp_path / "daemon.profile")
    monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")
    monkeypatch.setattr(
        "agentshive.commands.doctor.PROFILES_DIR", tmp_path / "profiles"
    )
    monkeypatch.setattr("agentshive.commands.doctor.PID_FILE", tmp_path / "daemon.pid")

    save_config(
        Config(
            server_url="https://agentshive.example.com/",
            token="ahv_vendor_url_token",
            backends={"claude_code": True},
        )
    )

    # Short-circuit the network probes — vendor-URL line renders
    # regardless of Server/WebSocket check outcomes.
    monkeypatch.setattr("agentshive.commands.doctor._check_websocket", lambda _c: True)

    class _FakeResp:
        status_code = 200

    monkeypatch.setattr("httpx.get", lambda *_a, **_k: _FakeResp())

    try:
        main(["doctor"])
    except SystemExit:
        # Backend binaries on PATH may cause _check() to return False
        # depending on the test runner host; vendor-URL line renders
        # either way.
        pass

    out = capsys.readouterr().out
    assert "Re-install:" in out
    assert "https://agentshive.example.com/api/install.sh" in out
    assert "?token=<your-token>" in out
    assert "ahv_vendor_url_token" not in out
