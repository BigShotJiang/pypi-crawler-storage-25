"""Tests for the Windows daemonization path (commands/start.py).

Pins the Windows substrate fix for ``agentshive start``: POSIX uses
``os.fork()`` which doesn't exist on Windows, so the bare command raises
``AttributeError`` and the daemon never starts. The fix dispatches on
``sys.platform`` and uses ``subprocess.Popen`` with ``DETACHED_PROCESS |
CREATE_NEW_PROCESS_GROUP`` to spawn a child that survives parent terminal
close. PID_FILE is managed by the detached child via the
``AGENTSHIVE_DETACHED_CHILD=1`` env-var hook so ``stop``/``status`` resolve
to the actual long-lived daemon process.
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys

import pytest

from agentshive.commands import start as start_cmd


@pytest.fixture
def temp_config_dir(tmp_path, monkeypatch):
    """Redirect PID_FILE / LOG_FILE to a tmp dir for test isolation."""
    pid_file = tmp_path / "daemon.pid"
    log_file = tmp_path / "daemon.log"
    monkeypatch.setattr(start_cmd, "PID_FILE", pid_file)
    monkeypatch.setattr(start_cmd, "LOG_FILE", log_file)
    return tmp_path


def test_daemonize_dispatches_to_windows_path_when_win32(monkeypatch, temp_config_dir):
    """On sys.platform == 'win32', _daemonize calls _detach_windows, never os.fork.

    Pins the customer-blocking AttributeError fix: bare os.fork() doesn't
    exist on Windows; the platform-dispatch shunt is the whole point.
    """
    detach_called: dict[str, object] = {}

    def _fake_detach(*, test_mode: bool, profile_name: str = "default") -> None:
        detach_called["test_mode"] = test_mode
        detach_called["profile_name"] = profile_name

    def _fake_fork() -> int:
        raise AssertionError("os.fork() must NOT be called on Windows path")

    monkeypatch.setattr(start_cmd.sys, "platform", "win32")
    monkeypatch.setattr(start_cmd, "_detach_windows", _fake_detach)
    monkeypatch.setattr(start_cmd.os, "fork", _fake_fork, raising=False)

    cfg = start_cmd.Config(server_url="https://x", token="t", backends={})
    start_cmd._daemonize(cfg, test_mode=True)

    assert detach_called == {"test_mode": True, "profile_name": "default"}


def test_daemonize_uses_fork_on_posix(monkeypatch, temp_config_dir):
    """On POSIX, _daemonize keeps the existing fork-based code path."""
    fork_called: list[bool] = []

    def _fake_fork() -> int:
        fork_called.append(True)
        # Pretend we're the parent; return a non-zero PID so the function
        # returns immediately without trying to run the daemon body.
        return 12345

    monkeypatch.setattr(start_cmd.sys, "platform", "linux")
    monkeypatch.setattr(start_cmd.os, "fork", _fake_fork, raising=False)
    # _read_pid is called by parent to report status; stub it.
    monkeypatch.setattr(start_cmd, "_read_pid", lambda: 12345)
    # Don't actually sleep in the test.
    monkeypatch.setattr(start_cmd.time, "sleep", lambda _s: None)

    cfg = start_cmd.Config(server_url="https://x", token="t", backends={})
    start_cmd._daemonize(cfg, test_mode=False)

    assert fork_called == [True]


def test_detach_windows_popen_args(monkeypatch, temp_config_dir):
    """Popen receives the right argv, creation flags, env var, and stdio routing.

    Asserts the contract that:
    - argv re-execs `python -m agentshive start --foreground`
    - DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP creation flags set (so child
      survives parent terminal close)
    - AGENTSHIVE_DETACHED_CHILD=1 env var set so child writes PID_FILE
    - stdout/stderr point at the log file (inherited fh), stdin to DEVNULL
    - test_mode propagates to child argv
    """
    captured: dict[str, object] = {}

    class _FakePopen:
        pid = 99999

        def __init__(self, cmd, **kwargs):
            captured["cmd"] = cmd
            captured["kwargs"] = kwargs

    monkeypatch.setattr(subprocess, "Popen", _FakePopen)
    # _read_pid is polled after Popen — stub to return immediately.
    monkeypatch.setattr(start_cmd, "_read_pid", lambda: 99999)
    monkeypatch.setattr(start_cmd.time, "sleep", lambda _s: None)

    start_cmd._detach_windows(test_mode=True)

    cmd = captured["cmd"]
    kwargs = captured["kwargs"]

    # argv contract
    assert cmd[0] == sys.executable
    assert cmd[1:5] == ["-m", "agentshive", "start", "--foreground"]
    assert "--test-mode" in cmd

    # creation flags: both DETACHED_PROCESS (0x8) and CREATE_NEW_PROCESS_GROUP
    # (0x200) must be set. Bitwise-AND so this stays robust if other flags get
    # OR'd in later (e.g. CREATE_NO_WINDOW).
    flags = kwargs["creationflags"]
    assert flags & 0x00000008, "DETACHED_PROCESS not set"
    assert flags & 0x00000200, "CREATE_NEW_PROCESS_GROUP not set"

    # env var propagated
    assert kwargs["env"]["AGENTSHIVE_DETACHED_CHILD"] == "1"

    # stdio routing
    assert kwargs["stdin"] is subprocess.DEVNULL
    # stdout/stderr both point at the inherited log file handle — both args
    # must be the same handle so the child writes a single interleaved stream.
    assert kwargs["stdout"] is kwargs["stderr"]
    # close_fds=True is required on Windows so the child doesn't inherit the
    # parent's other open handles (only the explicitly-passed stdio).
    assert kwargs["close_fds"] is True


def test_detach_windows_propagates_test_mode_false(monkeypatch, temp_config_dir):
    """When test_mode=False, child argv must NOT carry --test-mode flag."""
    captured_cmd: list[list[str]] = []

    class _FakePopen:
        pid = 99999

        def __init__(self, cmd, **_kwargs):
            captured_cmd.append(cmd)

    monkeypatch.setattr(subprocess, "Popen", _FakePopen)
    monkeypatch.setattr(start_cmd, "_read_pid", lambda: 99999)
    monkeypatch.setattr(start_cmd.time, "sleep", lambda _s: None)

    start_cmd._detach_windows(test_mode=False)

    assert "--test-mode" not in captured_cmd[0]


def test_setup_detached_child_pid_writes_own_pid(temp_config_dir):
    """Detached child writes os.getpid() to PID_FILE — not parent's PID.

    Pins the "PID_FILE points at the long-lived daemon" contract: stop/status
    commands resolve to the right runner regardless of whether daemonization
    went through fork (POSIX grandchild) or Popen-detach (Windows child).
    """
    # No PID file before
    assert not start_cmd.PID_FILE.exists()

    start_cmd._setup_detached_child_pid(profile_name="default")

    assert start_cmd.PID_FILE.exists()
    written_pid = int(start_cmd.PID_FILE.read_text().strip())
    assert written_pid == os.getpid()

    handler_term = signal.getsignal(signal.SIGTERM)
    assert callable(handler_term)
    signal.signal(signal.SIGTERM, signal.SIG_DFL)


def test_setup_detached_child_pid_atexit_cleans_up(temp_config_dir, monkeypatch):
    """The atexit-registered cleanup unlinks PID_FILE so stop/status see no stale entry.

    We patch atexit.register to capture the cleanup callback rather than
    waiting for interpreter shutdown — invoking the captured callback manually
    is the deterministic way to assert the cleanup contract.
    """
    captured_callbacks: list[object] = []

    def _capture(callback):
        captured_callbacks.append(callback)
        return callback

    monkeypatch.setattr(start_cmd.atexit, "register", _capture)

    start_cmd._setup_detached_child_pid(profile_name="default")
    assert start_cmd.PID_FILE.exists()

    # Restore signal default so test teardown doesn't fire our cleanup.
    signal.signal(signal.SIGTERM, signal.SIG_DFL)

    # Fire the atexit callback as the interpreter would on normal shutdown.
    assert captured_callbacks, "atexit callback was never registered"
    captured_callbacks[0]()

    assert not start_cmd.PID_FILE.exists()


def test_run_foreground_invokes_pid_setup_when_env_var_set(
    monkeypatch, temp_config_dir
):
    """_run_foreground writes PID_FILE only when AGENTSHIVE_DETACHED_CHILD=1.

    Pins the env-var hook contract that connects _detach_windows (sets the
    var on Popen) to _run_foreground (reads the var, writes PID_FILE). If
    this drifts, Windows daemons run but no PID file ever appears, breaking
    stop/status.
    """
    monkeypatch.setenv("AGENTSHIVE_DETACHED_CHILD", "1")
    # Stub run_daemon so the test doesn't actually start a daemon loop.
    monkeypatch.setattr(
        "agentshive.local_runner.run_daemon",
        lambda **_kwargs: None,
    )
    # Stub atexit + signal so the cleanup callbacks don't persist past the
    # test (they'd unlink PID_FILE in the temp dir, which we want to assert
    # was created during _run_foreground).
    monkeypatch.setattr(start_cmd.atexit, "register", lambda _cb: None)
    monkeypatch.setattr(start_cmd.signal, "signal", lambda *_a, **_k: None)

    cfg = start_cmd.Config(server_url="https://x", token="t", backends={})
    start_cmd._run_foreground(cfg, test_mode=False)

    assert start_cmd.PID_FILE.exists()
    assert int(start_cmd.PID_FILE.read_text().strip()) == os.getpid()


def test_run_foreground_skips_pid_setup_when_env_var_unset(
    monkeypatch, temp_config_dir
):
    """User-invoked `agentshive start --foreground` (no env var) does NOT
    write PID_FILE — preserves the existing UX where Ctrl+C is the only
    lifecycle handle and stop/status don't apply."""
    monkeypatch.delenv("AGENTSHIVE_DETACHED_CHILD", raising=False)
    monkeypatch.setattr(
        "agentshive.local_runner.run_daemon",
        lambda **_kwargs: None,
    )

    cfg = start_cmd.Config(server_url="https://x", token="t", backends={})
    start_cmd._run_foreground(cfg, test_mode=False)

    assert not start_cmd.PID_FILE.exists()


@pytest.mark.skipif(
    sys.platform != "win32",
    reason="Windows DETACHED_PROCESS launch semantics — only meaningful on win32",
)
def test_detached_child_survives_parent_exit_on_windows(tmp_path):
    """End-to-end Windows smoke: a Popen with DETACHED_PROCESS keeps running
    after the parent process closes its handle to it.

    Mirrors PR #35's Windows-only .cmd shim launch test — proves the launch
    semantics actually work on the target substrate, not just that we pass
    the right flags. Failing here means the customer's terminal-close path
    needs more than DETACHED_PROCESS (e.g. an explicit cmd.exe /c wrapper
    or different stdio routing).
    """
    import time as _time

    sentinel = tmp_path / "child_pid.txt"
    # Trivial child: write own PID, sleep briefly, exit clean.
    code = (
        f"import os, time; "
        f"open(r'{sentinel}', 'w').write(str(os.getpid())); "
        f"time.sleep(0.5)"
    )
    proc = subprocess.Popen(
        [sys.executable, "-c", code],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        close_fds=True,
        creationflags=0x00000008 | 0x00000200,  # DETACHED_PROCESS | NEW_PG
    )

    # Give child time to write the sentinel.
    deadline = _time.monotonic() + 3.0
    while _time.monotonic() < deadline:
        if sentinel.exists() and sentinel.read_text().strip():
            break
        _time.sleep(0.05)

    assert sentinel.exists(), "Detached child failed to start"
    child_pid = int(sentinel.read_text().strip())
    assert child_pid != os.getpid()
    # Wait for child to exit cleanly so the test doesn't leak a process.
    proc.wait(timeout=5)
    assert proc.returncode == 0
