"""Tests for the Claude Code CLI backend."""

from __future__ import annotations

import json
import logging

from agentshive.backends.claude_code import LocalClaudeCodeBackend


def test_parse_output_single_result_object():
    backend = LocalClaudeCodeBackend()
    stdout = json.dumps(
        {
            "result": "final reply",
            "session_id": "sess-123",
            "stop_reason": "end_turn",
            "usage": {
                "input_tokens": 10,
                "output_tokens": 5,
                "cache_read_input_tokens": 3,
            },
            "total_cost_usd": 0.012,
        }
    )

    result = backend._parse_output(stdout)

    assert result.text == "final reply"
    assert result.session_id == "sess-123"
    assert result.stop_reason == "end_turn"
    assert result.input_tokens == 10
    assert result.output_tokens == 5
    assert result.cache_read_tokens == 3
    assert result.cost_usd == 0.012


def test_parse_output_top_level_event_list_prefers_final_result():
    backend = LocalClaudeCodeBackend()
    stdout = json.dumps(
        [
            {"type": "system", "session_id": "sess-abc"},
            {
                "type": "assistant",
                "message": {
                    "role": "assistant",
                    "content": [{"type": "text", "text": "intermediate"}],
                    "usage": {"input_tokens": 1, "output_tokens": 2},
                },
            },
            {
                "type": "result",
                "result": "final reply",
                "session_id": "sess-abc",
                "stopReason": "stop_sequence",
                "usage": {
                    "input_tokens": 12,
                    "output_tokens": 8,
                    "cache_read_input_tokens": 4,
                },
                "total_cost_usd": 0.034,
            },
        ]
    )

    result = backend._parse_output(stdout)

    assert result.text == "final reply"
    assert result.session_id == "sess-abc"
    assert result.stop_reason == "stop_sequence"
    assert result.input_tokens == 12
    assert result.output_tokens == 8
    assert result.cache_read_tokens == 4
    assert result.cost_usd == 0.034


def test_parse_output_top_level_event_list_falls_back_to_assistant_text():
    backend = LocalClaudeCodeBackend()
    stdout = json.dumps(
        [
            {
                "type": "assistant",
                "message": {
                    "session_id": "sess-fallback",
                    "role": "assistant",
                    "content": [
                        {"type": "text", "text": "hello "},
                        {"type": "tool_use", "name": "Bash"},
                    ],
                    "usage": {
                        "input_tokens": 7,
                        "output_tokens": 3,
                        "cache_read_input_tokens": 2,
                    },
                },
            },
            {
                "role": "assistant",
                "content": "world",
                "usage": {"input_tokens": 1, "output_tokens": 1},
            },
        ]
    )

    result = backend._parse_output(stdout)

    assert result.text == "hello world"
    assert result.session_id == "sess-fallback"
    assert result.input_tokens == 8
    assert result.output_tokens == 4
    assert result.cache_read_tokens == 2


def test_parse_output_top_level_event_list_logs_array_branch(caplog):
    backend = LocalClaudeCodeBackend()
    stdout = json.dumps([{"type": "result", "result": "ok"}])

    with caplog.at_level(logging.INFO, logger="agentshive.backends.claude_code"):
        result = backend._parse_output(stdout)

    assert result.text == "ok"
    assert "JSON event array" in caplog.text


def test_parse_output_result_event_without_usage_uses_fallback_usage():
    backend = LocalClaudeCodeBackend()
    stdout = json.dumps(
        [
            {
                "type": "assistant",
                "message": {
                    "role": "assistant",
                    "content": "reply",
                    "usage": {
                        "input_tokens": 11,
                        "output_tokens": 6,
                        "cache_read_input_tokens": 5,
                    },
                },
            },
            {
                "type": "result",
                "result": "final reply",
                "session_id": "sess-no-usage",
            },
        ]
    )

    result = backend._parse_output(stdout)

    assert result.text == "final reply"
    assert result.session_id == "sess-no-usage"
    assert result.input_tokens == 11
    assert result.output_tokens == 6
    assert result.cache_read_tokens == 5


def test_parse_output_result_event_zero_usage_does_not_sum_intermediate_usage():
    backend = LocalClaudeCodeBackend()
    stdout = json.dumps(
        [
            {
                "type": "assistant",
                "message": {
                    "role": "assistant",
                    "content": "intermediate",
                    "usage": {"input_tokens": 20, "output_tokens": 10},
                },
            },
            {
                "type": "result",
                "result": "final reply",
                "usage": {"input_tokens": 0, "output_tokens": 0},
            },
        ]
    )

    result = backend._parse_output(stdout)

    assert result.text == "final reply"
    assert result.input_tokens == 0
    assert result.output_tokens == 0
