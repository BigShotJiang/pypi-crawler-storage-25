"""Lifecycle tests for ``BackendClient.run()`` — single-event-loop start/stop.

Regression guard for the production wedge where the daemon logged
``RuntimeError: Event loop is closed``. The old ``run()`` drove ``start()`` and
``stop()`` in two *separate* ``asyncio.run()`` calls, so the httpx connection
pool (bound to the first loop on first use) was ``aclose()``'d on a second loop
→ "Event loop is closed". That error masked the real shutdown/reconnect failure
and could leave the daemon process alive but inert.
"""

import asyncio

from agentshive.client import BackendClient


def test_run_starts_and_stops_on_the_same_event_loop(monkeypatch):
    """start() and the stop()/cleanup must share one event loop.

    Closing the httpx pool on a different loop than the one that used it raises
    "Event loop is closed"; asserting a single loop is the regression guard.
    """
    c = BackendClient(server_url="http://testserver", token="test-token")
    seen: dict[str, int] = {}

    async def fake_start(supported_backends=None):
        seen["start_loop"] = id(asyncio.get_running_loop())

    async def fake_stop():
        seen["stop_loop"] = id(asyncio.get_running_loop())

    monkeypatch.setattr(c, "start", fake_start)
    monkeypatch.setattr(c, "stop", fake_stop)

    c.run(supported_backends=["claude_code"])

    assert "start_loop" in seen and "stop_loop" in seen
    assert seen["start_loop"] == seen["stop_loop"], (
        "start() and stop() ran on different event loops — httpx aclose() will "
        "raise 'Event loop is closed'"
    )


def test_run_cleans_up_and_surfaces_the_real_error_when_start_raises(monkeypatch):
    """If start() blows up, stop() still runs and the ORIGINAL error surfaces.

    The old two-loop shape could replace the real exception with a confusing
    cross-loop "Event loop is closed" raised from the finally.
    """
    c = BackendClient(server_url="http://testserver", token="test-token")
    stopped: dict[str, bool] = {}

    async def fake_start(supported_backends=None):
        raise RuntimeError("connect blew up")

    async def fake_stop():
        stopped["called"] = True

    monkeypatch.setattr(c, "start", fake_start)
    monkeypatch.setattr(c, "stop", fake_stop)

    import pytest

    with pytest.raises(RuntimeError, match="connect blew up"):
        c.run()
    assert stopped.get("called") is True
