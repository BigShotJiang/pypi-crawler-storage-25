"""AC-13 contract tests for `agentshive setup --check`.

Per `docs/sdk-cli-spec.md` v1.2 shell-installer amendment at
agenthive@226666f ("Required SDK-side tests (merge gate for Lane B)"),
this module encodes the five tests that lock the `--check` flag's
persistence-only semantics. Any change to these test names is a spec
amendment surface, not an internal refactor — the canonical shell body
and the backend golden-file test grep-reference the same AC-13 contract.
"""

from __future__ import annotations

import hashlib
import json
from unittest.mock import patch

import pytest

from agentshive.cli import main
from agentshive.config import Config, save_config


def _patch_paths(tmp_path, monkeypatch):
    profiles_dir = tmp_path / "profiles"
    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.PROFILES_DIR", profiles_dir)
    monkeypatch.setattr(
        "agentshive.config.LEGACY_CONFIG_FILE", tmp_path / "config.json"
    )
    monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
    monkeypatch.setattr("agentshive.config.PROFILE_FILE", tmp_path / "daemon.profile")
    monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")
    monkeypatch.setattr("agentshive.commands.setup.PROFILES_DIR", profiles_dir)
    return profiles_dir


def _seed_valid_config(tmp_path, monkeypatch) -> None:
    """Write a valid default profile with a non-empty token."""
    _patch_paths(tmp_path, monkeypatch)
    save_config(
        Config(
            server_url="https://example.com",
            token="ahv_test_token_123",
            backends={"claude_code": True},
        )
    )


def _seed_config_with_token(tmp_path, monkeypatch, token: str) -> None:
    """Write a config with an arbitrary token value (may be empty)."""
    _patch_paths(tmp_path, monkeypatch)
    save_config(
        Config(
            server_url="https://example.com",
            token=token,
            backends={"claude_code": True},
        )
    )


def _point_config_at(tmp_path, monkeypatch) -> None:
    """Point config machinery at tmp_path without writing any file."""
    _patch_paths(tmp_path, monkeypatch)


def test_check_exit_zero_on_valid_config(tmp_path, monkeypatch):
    """AC-13: seeded valid config + non-empty token -> exit 0."""
    _seed_valid_config(tmp_path, monkeypatch)
    with pytest.raises(SystemExit) as exc_info:
        main(["setup", "--check"])
    assert exc_info.value.code == 0


def test_check_exit_nonzero_on_missing_config(tmp_path, monkeypatch):
    """AC-13: no config file -> exit non-zero."""
    _point_config_at(tmp_path, monkeypatch)
    with pytest.raises(SystemExit) as exc_info:
        main(["setup", "--check"])
    assert exc_info.value.code != 0


def test_check_exit_nonzero_on_empty_token(tmp_path, monkeypatch):
    """AC-13: config persists, token="" -> exit non-zero."""
    _seed_config_with_token(tmp_path, monkeypatch, token="")
    profile_file = tmp_path / "profiles" / "default.json"
    assert profile_file.exists()
    data = json.loads(profile_file.read_text())
    assert data["token"] == ""

    with pytest.raises(SystemExit) as exc_info:
        main(["setup", "--check"])
    assert exc_info.value.code != 0


def test_check_does_no_network_io(tmp_path, monkeypatch):
    """AC-13 load-bearing: `--check` never invokes the SDK HTTP client."""
    _seed_valid_config(tmp_path, monkeypatch)

    with (
        patch("httpx.Client") as http_sync,
        patch("httpx.AsyncClient") as http_async,
        patch("httpx.get") as http_get,
        patch("httpx.post") as http_post,
        patch("websockets.connect") as ws_connect,
    ):
        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--check"])
        assert exc_info.value.code == 0

        assert http_sync.call_count == 0, "httpx.Client instantiated during --check"
        assert http_async.call_count == 0, (
            "httpx.AsyncClient instantiated during --check"
        )
        assert http_get.call_count == 0, "httpx.get called during --check"
        assert http_post.call_count == 0, "httpx.post called during --check"
        assert ws_connect.call_count == 0, "websockets.connect called during --check"


def test_check_is_read_only(tmp_path, monkeypatch):
    """AC-13: config mtime + SHA256 unchanged across `--check`."""
    _seed_valid_config(tmp_path, monkeypatch)
    profile_file = tmp_path / "profiles" / "default.json"

    mtime_before = profile_file.stat().st_mtime_ns
    sha_before = hashlib.sha256(profile_file.read_bytes()).hexdigest()

    with pytest.raises(SystemExit) as exc_info:
        main(["setup", "--check"])
    assert exc_info.value.code == 0

    mtime_after = profile_file.stat().st_mtime_ns
    sha_after = hashlib.sha256(profile_file.read_bytes()).hexdigest()

    assert mtime_before == mtime_after, "config mtime changed across --check"
    assert sha_before == sha_after, "config content hash changed across --check"
