"""Tests for agentshive.cli module."""

from __future__ import annotations

import json

import pytest

from agentshive.cli import main


def _patch_config_dir(monkeypatch, tmp_path):
    """Patch all config paths to a temp directory."""
    profiles_dir = tmp_path / "profiles"
    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.PROFILES_DIR", profiles_dir)
    monkeypatch.setattr(
        "agentshive.config.LEGACY_CONFIG_FILE", tmp_path / "config.json"
    )
    monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
    monkeypatch.setattr("agentshive.config.PROFILE_FILE", tmp_path / "daemon.profile")
    monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")
    monkeypatch.setattr("agentshive.commands.setup.PROFILES_DIR", profiles_dir)
    monkeypatch.setattr("agentshive.commands.status.PROFILES_DIR", profiles_dir)


class TestCLIDispatch:
    def test_no_command_prints_help(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main([])
        assert exc_info.value.code == 1

    def test_help_flag(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main(["--help"])
        assert exc_info.value.code == 0
        out = capsys.readouterr().out
        assert "setup" in out
        assert "start" in out
        assert "stop" in out
        assert "status" in out
        assert "doctor" in out

    def test_setup_subcommand_help(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--help"])
        assert exc_info.value.code == 0
        out = capsys.readouterr().out
        assert "--no-interactive" in out

    def test_setup_has_profile_flag(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--help"])
        assert exc_info.value.code == 0
        out = capsys.readouterr().out
        assert "--profile" in out

    def test_start_has_profile_flag(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main(["start", "--help"])
        assert exc_info.value.code == 0
        out = capsys.readouterr().out
        assert "--profile" in out

    def test_setup_has_staging_flag(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--help"])
        assert exc_info.value.code == 0
        out = capsys.readouterr().out
        assert "--staging" in out


class TestSetupNonInteractive:
    def test_writes_config(self, tmp_path, monkeypatch):
        _patch_config_dir(monkeypatch, tmp_path)

        main(
            [
                "setup",
                "--no-interactive",
                "--server",
                "https://example.com",
                "--token",
                "ahv_test_token_123",
            ]
        )

        profile_file = tmp_path / "profiles" / "default.json"
        assert profile_file.exists()
        data = json.loads(profile_file.read_text())
        assert data["server_url"] == "https://example.com"
        assert data["token"] == "ahv_test_token_123"
        assert isinstance(data["backends"], dict)

    def test_missing_token_exits(self, tmp_path, monkeypatch):
        _patch_config_dir(monkeypatch, tmp_path)

        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--no-interactive", "--server", "http://x"])
        assert exc_info.value.code == 1

    def test_setup_staging_profile(self, tmp_path, monkeypatch):
        _patch_config_dir(monkeypatch, tmp_path)

        main(
            [
                "setup",
                "--staging",
                "--no-interactive",
                "--token",
                "ahv_test_token_123",
            ]
        )

        profile_file = tmp_path / "profiles" / "staging.json"
        assert profile_file.exists()
        data = json.loads(profile_file.read_text())
        assert "staging.agentshive.agency" in data["server_url"]

    def test_setup_staging_does_not_leak_default_token(self, tmp_path, monkeypatch):
        """P1 regression: --staging must not carry over the default profile token."""
        _patch_config_dir(monkeypatch, tmp_path)

        from agentshive.config import save_config, Config

        save_config(
            Config(
                server_url="https://agentshive.agency/",
                token="ahv_prod_secret",
                backends={"claude_code": True},
            )
        )

        main(
            [
                "setup",
                "--staging",
                "--no-interactive",
                "--token",
                "ahv_staging_token",
            ]
        )

        profile_file = tmp_path / "profiles" / "staging.json"
        data = json.loads(profile_file.read_text())
        assert data["token"] == "ahv_staging_token"
        assert data["token"] != "ahv_prod_secret"

        default_file = tmp_path / "profiles" / "default.json"
        default_data = json.loads(default_file.read_text())
        assert default_data["token"] == "ahv_prod_secret"

    def test_setup_staging_interactive_uses_cli_server_and_token(
        self, tmp_path, monkeypatch
    ):
        """P1 regression: --staging --token in interactive mode must pre-fill
        the staging URL and the provided token, not prompt from empty defaults."""
        _patch_config_dir(monkeypatch, tmp_path)

        from unittest.mock import patch

        def _accept_default(label: str, default: str = "") -> str:
            return default

        with (
            patch("agentshive.commands.setup._prompt", side_effect=_accept_default),
            patch("agentshive.commands.setup._confirm", return_value=True),
            patch("agentshive.commands.setup.detect_backends", return_value={}),
        ):
            main(
                [
                    "setup",
                    "--staging",
                    "--token",
                    "ahv_staging_tok",
                ]
            )

        profile_file = tmp_path / "profiles" / "staging.json"
        assert profile_file.exists()
        data = json.loads(profile_file.read_text())
        assert "staging.agentshive.agency" in data["server_url"]
        assert data["token"] == "ahv_staging_tok"


class TestStopNoProcess:
    def test_stop_no_pid_file(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
        monkeypatch.setattr(
            "agentshive.commands.stop.PID_FILE", tmp_path / "daemon.pid"
        )
        main(["stop"])
        out = capsys.readouterr().out
        assert "not running" in out.lower()


class TestStatusNoConfig:
    def test_status_no_config(self, tmp_path, monkeypatch, capsys):
        _patch_config_dir(monkeypatch, tmp_path)
        main(["status"])
        out = capsys.readouterr().out
        assert "not found" in out.lower()
