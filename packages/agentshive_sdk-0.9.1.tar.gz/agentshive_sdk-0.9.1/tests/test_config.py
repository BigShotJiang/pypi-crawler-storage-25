"""Tests for agentshive.config module."""

from __future__ import annotations

import json

import pytest

from agentshive.config import (
    Config,
    ConfigError,
    cf_access_headers,
    detect_backends,
    load_config,
    load_profile,
    resolve_config,
    save_config,
    validate_config,
    write_daemon_profile,
    read_daemon_profile,
    remove_daemon_profile,
)


@pytest.fixture
def config_dir(tmp_path, monkeypatch):
    """Redirect config paths to a temp directory."""
    profiles_dir = tmp_path / "profiles"
    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.PROFILES_DIR", profiles_dir)
    monkeypatch.setattr(
        "agentshive.config.LEGACY_CONFIG_FILE", tmp_path / "config.json"
    )
    monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
    monkeypatch.setattr("agentshive.config.PROFILE_FILE", tmp_path / "daemon.profile")
    monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")
    return tmp_path


class TestSaveAndLoad:
    def test_round_trip(self, config_dir):
        config = Config(
            server_url="https://example.com",
            token="ahv_abc123",
            backends={"claude_code": True, "codex": False},
            auto_start=True,
            log_level="debug",
            repo_path="/home/user/project",
        )
        save_config(config)
        loaded = load_config()
        assert loaded.server_url == "https://example.com"
        assert loaded.token == "ahv_abc123"
        assert loaded.backends == {"claude_code": True, "codex": False}
        assert loaded.auto_start is True
        assert loaded.log_level == "debug"
        assert loaded.repo_path == "/home/user/project"

    def test_load_missing_file(self, config_dir):
        with pytest.raises(ConfigError, match="not found"):
            load_config()

    def test_load_invalid_json(self, config_dir):
        profiles = config_dir / "profiles"
        profiles.mkdir(parents=True)
        (profiles / "default.json").write_text("not json{")
        with pytest.raises(ConfigError, match="Invalid profile"):
            load_config()

    def test_save_creates_directory(self, tmp_path, monkeypatch):
        nested = tmp_path / "a" / "b"
        profiles = nested / "profiles"
        monkeypatch.setattr("agentshive.config.CONFIG_DIR", nested)
        monkeypatch.setattr("agentshive.config.PROFILES_DIR", profiles)
        save_config(Config(server_url="http://x", token="ahv_t"))
        assert (profiles / "default.json").exists()

    def test_load_defaults(self, config_dir):
        profiles = config_dir / "profiles"
        profiles.mkdir(parents=True)
        (profiles / "default.json").write_text('{"server_url": "http://x"}')
        config = load_config()
        assert config.server_url == "http://x"
        assert config.token == ""
        assert config.backends == {}
        assert config.auto_start is False
        assert config.repo_path is None
        assert config.timeout == 3600

    def test_dataclass_default_timeout_is_60min(self):
        assert Config().timeout == 3600

    def test_load_preserves_explicit_timeout(self, config_dir):
        profiles = config_dir / "profiles"
        profiles.mkdir(parents=True)
        (profiles / "default.json").write_text(
            '{"server_url": "http://x", "token": "ahv_t", "timeout": 300}'
        )
        config = load_config()
        assert config.timeout == 300

    def test_load_repo_path_null(self, config_dir):
        profiles = config_dir / "profiles"
        profiles.mkdir(parents=True)
        (profiles / "default.json").write_text(
            '{"server_url": "http://x", "token": "ahv_t", "repo_path": null}'
        )
        config = load_config()
        assert config.repo_path is None

    def test_load_repo_path_string(self, config_dir):
        profiles = config_dir / "profiles"
        profiles.mkdir(parents=True)
        (profiles / "default.json").write_text(
            '{"server_url": "http://x", "token": "ahv_t", "repo_path": "/tmp/repo"}'
        )
        config = load_config()
        assert config.repo_path == "/tmp/repo"


class TestProfiles:
    def test_save_named_profile(self, config_dir):
        config = Config(
            server_url="https://staging.agentshive.agency",
            token="ahv_stg_abc",
            backends={"claude_code": True},
        )
        save_config(config, profile="staging")
        loaded = load_profile("staging")
        assert loaded.server_url == "https://staging.agentshive.agency"
        assert loaded.token == "ahv_stg_abc"

    def test_load_nonexistent_profile(self, config_dir):
        with pytest.raises(ConfigError, match="not found"):
            load_profile("nonexistent")

    def test_profiles_isolated(self, config_dir):
        save_config(
            Config(server_url="https://prod.example", token="ahv_prod"),
            profile="default",
        )
        save_config(
            Config(server_url="https://staging.example", token="ahv_stg"),
            profile="staging",
        )
        assert load_profile("default").server_url == "https://prod.example"
        assert load_profile("staging").server_url == "https://staging.example"

    def test_legacy_migration(self, config_dir):
        legacy = config_dir / "config.json"
        legacy.write_text(
            json.dumps(
                {
                    "server_url": "https://legacy.example",
                    "token": "ahv_legacy",
                    "backends": {"claude_code": True},
                }
            )
        )
        config = load_profile("default")
        assert config.server_url == "https://legacy.example"
        assert config.token == "ahv_legacy"
        assert (config_dir / "profiles" / "default.json").exists()

    def test_legacy_not_overwritten(self, config_dir):
        legacy = config_dir / "config.json"
        legacy.write_text(
            json.dumps(
                {
                    "server_url": "https://legacy.example",
                    "token": "ahv_legacy",
                    "backends": {"claude_code": True},
                }
            )
        )
        load_profile("default")
        assert legacy.exists()
        assert legacy.read_text().startswith("{")


class TestEnvVarOverride:
    def test_env_var_pair_overrides_profile(self, config_dir, monkeypatch):
        save_config(
            Config(server_url="https://prod.example", token="ahv_prod"),
            profile="default",
        )
        monkeypatch.setenv("AGENTSHIVE_SERVER_URL", "https://staging.example")
        monkeypatch.setenv("AGENTSHIVE_TOKEN", "ahv_stg_override")
        config = resolve_config("default")
        assert config.server_url == "https://staging.example"
        assert config.token == "ahv_stg_override"

    def test_env_var_url_only_fails(self, config_dir, monkeypatch):
        save_config(
            Config(server_url="https://prod.example", token="ahv_prod"),
            profile="default",
        )
        monkeypatch.setenv("AGENTSHIVE_SERVER_URL", "https://staging.example")
        monkeypatch.delenv("AGENTSHIVE_TOKEN", raising=False)
        with pytest.raises(ConfigError, match="must be set together"):
            resolve_config("default")

    def test_env_var_token_only_fails(self, config_dir, monkeypatch):
        save_config(
            Config(server_url="https://prod.example", token="ahv_prod"),
            profile="default",
        )
        monkeypatch.delenv("AGENTSHIVE_SERVER_URL", raising=False)
        monkeypatch.setenv("AGENTSHIVE_TOKEN", "ahv_stg")
        with pytest.raises(ConfigError, match="must be set together"):
            resolve_config("default")

    def test_no_env_var_uses_profile(self, config_dir, monkeypatch):
        save_config(
            Config(server_url="https://prod.example", token="ahv_prod"),
            profile="default",
        )
        monkeypatch.delenv("AGENTSHIVE_SERVER_URL", raising=False)
        monkeypatch.delenv("AGENTSHIVE_TOKEN", raising=False)
        config = resolve_config("default")
        assert config.server_url == "https://prod.example"


class TestDaemonProfile:
    def test_write_and_read(self, config_dir):
        write_daemon_profile("staging")
        assert read_daemon_profile() == "staging"

    def test_read_missing(self, config_dir):
        assert read_daemon_profile() is None

    def test_remove(self, config_dir):
        write_daemon_profile("staging")
        remove_daemon_profile()
        assert read_daemon_profile() is None


class TestValidate:
    def test_valid_config(self):
        config = Config(
            server_url="https://agentshive.agency/",
            token="ahv_abc123",
            backends={"claude_code": True},
        )
        assert validate_config(config) == []

    def test_missing_token(self):
        config = Config(server_url="http://x", backends={"claude_code": True})
        errors = validate_config(config)
        assert any("token is required" in e for e in errors)

    def test_bad_token_prefix(self):
        config = Config(
            server_url="http://x", token="bad_token", backends={"claude_code": True}
        )
        errors = validate_config(config)
        assert any("ahv_" in e for e in errors)

    def test_no_backends_enabled(self):
        config = Config(
            server_url="http://x", token="ahv_abc", backends={"codex": False}
        )
        errors = validate_config(config)
        assert any("backend" in e.lower() for e in errors)


class TestDetectBackends:
    def test_returns_dict(self):
        result = detect_backends()
        assert isinstance(result, dict)
        assert "claude_code" in result
        assert "opencode" in result

    def test_values_are_bools(self):
        result = detect_backends()
        for v in result.values():
            assert isinstance(v, bool)


class TestSetupPreservesRepoPath:
    """Regression: setup must not drop repo_path when rewriting config."""

    @pytest.fixture
    def config_dir(self, tmp_path, monkeypatch):
        profiles_dir = tmp_path / "profiles"
        monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agentshive.config.PROFILES_DIR", profiles_dir)
        monkeypatch.setattr(
            "agentshive.config.LEGACY_CONFIG_FILE", tmp_path / "config.json"
        )
        monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
        monkeypatch.setattr(
            "agentshive.config.PROFILE_FILE", tmp_path / "daemon.profile"
        )
        monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")
        monkeypatch.setattr("agentshive.commands.setup.PROFILES_DIR", profiles_dir)
        return tmp_path

    def test_non_interactive_preserves_repo_path(self, config_dir):
        save_config(
            Config(
                server_url="https://example.com",
                token="ahv_test123",
                backends={"claude_code": True},
                repo_path="/repo/keep",
            )
        )
        from agentshive.commands.setup import _run_non_interactive
        import argparse

        args = argparse.Namespace(
            server=None,
            token=None,
            no_interactive=True,
            check=False,
            staging=False,
            profile="",
        )
        existing = load_config()
        _run_non_interactive(args, existing, "default")
        loaded = load_config()
        assert loaded.repo_path == "/repo/keep"


class TestResolveConfigEnvVarOnly:
    """P1 regression: env-var pair works without any saved profile."""

    @pytest.fixture(autouse=True)
    def _paths(self, tmp_path, monkeypatch):
        profiles_dir = tmp_path / "profiles"
        monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agentshive.config.PROFILES_DIR", profiles_dir)
        monkeypatch.setattr(
            "agentshive.config.LEGACY_CONFIG_FILE", tmp_path / "config.json"
        )
        monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
        monkeypatch.setattr(
            "agentshive.config.PROFILE_FILE", tmp_path / "daemon.profile"
        )
        monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")

    def test_env_vars_only_no_saved_profile(self, monkeypatch):
        monkeypatch.setenv("AGENTSHIVE_SERVER_URL", "https://ci.example.com")
        monkeypatch.setenv("AGENTSHIVE_TOKEN", "ahv_ci_token")
        cfg = resolve_config("default")
        assert cfg.server_url == "https://ci.example.com"
        assert cfg.token == "ahv_ci_token"

    def test_env_vars_override_saved_profile(self, tmp_path, monkeypatch):
        save_config(
            Config(
                server_url="https://prod.example.com",
                token="ahv_prod_secret",
                backends={"claude_code": True},
            )
        )
        monkeypatch.setenv("AGENTSHIVE_SERVER_URL", "https://staging.example.com")
        monkeypatch.setenv("AGENTSHIVE_TOKEN", "ahv_staging_token")
        cfg = resolve_config("default")
        assert cfg.server_url == "https://staging.example.com"
        assert cfg.token == "ahv_staging_token"

    def test_env_vars_preserve_saved_settings(self, tmp_path, monkeypatch):
        save_config(
            Config(
                server_url="https://prod.example.com",
                token="ahv_prod_secret",
                backends={"claude_code": True},
                timeout=7200,
                repo_path="/my/repo",
            )
        )
        monkeypatch.setenv("AGENTSHIVE_SERVER_URL", "https://staging.example.com")
        monkeypatch.setenv("AGENTSHIVE_TOKEN", "ahv_staging_token")
        cfg = resolve_config("default")
        assert cfg.timeout == 7200
        assert cfg.repo_path == "/my/repo"
        assert cfg.backends == {"claude_code": True}


class TestCFAccess:
    def test_config_defaults_empty(self):
        config = Config()
        assert config.cf_access_client_id == ""
        assert config.cf_access_client_secret == ""

    def test_round_trip_cf_fields(self, config_dir):
        config = Config(
            server_url="https://staging.example",
            token="ahv_test",
            cf_access_client_id="my-id",
            cf_access_client_secret="my-secret",
        )
        save_config(config)
        loaded = load_config()
        assert loaded.cf_access_client_id == "my-id"
        assert loaded.cf_access_client_secret == "my-secret"

    def test_load_missing_cf_fields_defaults_empty(self, config_dir):
        profiles = config_dir / "profiles"
        profiles.mkdir(parents=True)
        (profiles / "default.json").write_text(
            '{"server_url": "http://x", "token": "ahv_t"}'
        )
        config = load_config()
        assert config.cf_access_client_id == ""
        assert config.cf_access_client_secret == ""

    def test_env_var_overrides_cf_fields(self, config_dir, monkeypatch):
        save_config(
            Config(
                server_url="https://staging.example",
                token="ahv_test",
                cf_access_client_id="saved-id",
                cf_access_client_secret="saved-secret",
            )
        )
        monkeypatch.setenv("CF_ACCESS_CLIENT_ID", "env-id")
        monkeypatch.setenv("CF_ACCESS_CLIENT_SECRET", "env-secret")
        config = resolve_config("default")
        assert config.cf_access_client_id == "env-id"
        assert config.cf_access_client_secret == "env-secret"

    def test_env_var_partial_override(self, config_dir, monkeypatch):
        save_config(
            Config(
                server_url="https://staging.example",
                token="ahv_test",
                cf_access_client_id="saved-id",
                cf_access_client_secret="saved-secret",
            )
        )
        monkeypatch.setenv("CF_ACCESS_CLIENT_ID", "env-id")
        monkeypatch.delenv("CF_ACCESS_CLIENT_SECRET", raising=False)
        config = resolve_config("default")
        assert config.cf_access_client_id == "env-id"
        assert config.cf_access_client_secret == "saved-secret"

    def test_cf_access_headers_returns_dict(self):
        config = Config(
            cf_access_client_id="my-id",
            cf_access_client_secret="my-secret",
        )
        headers = cf_access_headers(config)
        assert headers == {
            "CF-Access-Client-Id": "my-id",
            "CF-Access-Client-Secret": "my-secret",
        }

    def test_cf_access_headers_empty_when_unset(self):
        config = Config()
        assert cf_access_headers(config) == {}

    def test_env_vars_work_with_url_token_pair(self, config_dir, monkeypatch):
        monkeypatch.setenv("AGENTSHIVE_SERVER_URL", "https://staging.example")
        monkeypatch.setenv("AGENTSHIVE_TOKEN", "ahv_stg")
        monkeypatch.setenv("CF_ACCESS_CLIENT_ID", "cf-id")
        monkeypatch.setenv("CF_ACCESS_CLIENT_SECRET", "cf-secret")
        cfg = resolve_config("default")
        assert cfg.server_url == "https://staging.example"
        assert cfg.token == "ahv_stg"
        assert cfg.cf_access_client_id == "cf-id"
        assert cfg.cf_access_client_secret == "cf-secret"


class TestSetupPreservesCFAccess:
    """Regression: agentshive setup must not wipe CF Access credentials."""

    @pytest.fixture
    def config_dir(self, tmp_path, monkeypatch):
        profiles_dir = tmp_path / "profiles"
        monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agentshive.config.PROFILES_DIR", profiles_dir)
        monkeypatch.setattr(
            "agentshive.config.LEGACY_CONFIG_FILE", tmp_path / "config.json"
        )
        monkeypatch.setattr("agentshive.config.PID_FILE", tmp_path / "daemon.pid")
        monkeypatch.setattr(
            "agentshive.config.PROFILE_FILE", tmp_path / "daemon.profile"
        )
        monkeypatch.setattr("agentshive.config.LOG_FILE", tmp_path / "daemon.log")
        monkeypatch.setattr("agentshive.commands.setup.PROFILES_DIR", profiles_dir)
        return tmp_path

    def test_non_interactive_preserves_cf_fields(self, config_dir):
        save_config(
            Config(
                server_url="https://staging.example",
                token="ahv_test123",
                backends={"claude_code": True},
                cf_access_client_id="cf-id-123",
                cf_access_client_secret="cf-secret-456",
            )
        )
        from agentshive.commands.setup import _run_non_interactive
        import argparse

        args = argparse.Namespace(
            server=None,
            token=None,
            no_interactive=True,
            check=False,
            staging=False,
            profile="",
        )
        existing = load_config()
        _run_non_interactive(args, existing, "default")
        loaded = load_config()
        assert loaded.cf_access_client_id == "cf-id-123"
        assert loaded.cf_access_client_secret == "cf-secret-456"
