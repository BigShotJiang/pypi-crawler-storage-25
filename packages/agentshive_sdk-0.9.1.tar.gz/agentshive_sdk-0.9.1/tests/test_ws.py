"""Tests for agentshive.ws."""

from __future__ import annotations

from agentshive.ws import AgentWS


async def _noop_on_message(_data):
    pass


async def test_agentws_redacts_token_in_error_log(monkeypatch, caplog):
    """daemon.log must never contain the raw backend token, even when the
    exception message (e.g. websockets.InvalidURI) echoes the full URI."""
    token = "ahv_SECRETTOKEN_MUST_NOT_APPEAR_IN_LOGS"
    ws = AgentWS(
        server_url="https://example.com/",
        token=token,
        on_message=_noop_on_message,
    )

    import websockets

    def fake_connect(url, **_kwargs):
        # Stop the reconnect loop after this attempt so the test terminates.
        ws._running = False
        # Mimic websockets.InvalidURI: full URI in the message.
        raise ValueError(f"invalid URI: {url}")

    monkeypatch.setattr(websockets, "connect", fake_connect)
    caplog.set_level("WARNING", logger="agentshive.ws")

    await ws.connect()

    warnings = [r.getMessage() for r in caplog.records if r.levelname == "WARNING"]
    assert warnings, "expected at least one WARNING log"
    for msg in warnings:
        assert token not in msg, f"token leaked in log: {msg!r}"
    assert any("ahv_***" in msg for msg in warnings)


class _FakeConn:
    """Minimal stand-in for a websockets.connect() context manager.

    __aenter__ returns self; the inner ``async for`` terminates immediately
    via StopAsyncIteration so the reconnect loop progresses past the
    message-receive stage without doing any real I/O.
    """

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_args):
        return False

    def __aiter__(self):
        return self

    async def __anext__(self):
        raise StopAsyncIteration


async def test_agentws_picks_ssl_by_scheme(monkeypatch):
    """wss:// → TLS context; ws:// → ssl=None (websockets rejects ssl on ws://).

    Sets ``_running = False`` inside the stubbed ``websockets.connect`` so the
    reconnect loop exits deterministically after one iteration — no races
    against the backoff ``asyncio.sleep``.
    """
    import websockets

    captured: list[dict] = []

    def make_fake_connect(ws_instance):
        def fake_connect(url, **kwargs):
            captured.append({"url": url, "ssl": kwargs.get("ssl")})
            # Flip here (not from outside the task) so the post-try
            # `if self._running` check in AgentWS.connect() is already False
            # and the loop exits without entering its reconnect sleep.
            ws_instance._running = False
            return _FakeConn()

        return fake_connect

    # wss:// path → ssl context expected
    ws_secure = AgentWS("https://example.com/", "ahv_x", _noop_on_message)
    monkeypatch.setattr(websockets, "connect", make_fake_connect(ws_secure))
    await ws_secure.connect()
    assert len(captured) == 1
    assert captured[-1]["ssl"] is not None

    captured.clear()

    # ws:// path → ssl must be None
    ws_plain = AgentWS("http://localhost:8000", "ahv_y", _noop_on_message)
    monkeypatch.setattr(websockets, "connect", make_fake_connect(ws_plain))
    await ws_plain.connect()
    assert len(captured) == 1
    assert captured[-1]["ssl"] is None


async def test_agentws_passes_extra_headers(monkeypatch):
    """CF Access headers are forwarded to websockets.connect()."""
    import websockets

    captured: list[dict] = []

    def make_fake_connect(ws_instance):
        def fake_connect(url, **kwargs):
            captured.append(
                {
                    "url": url,
                    "additional_headers": kwargs.get("additional_headers"),
                }
            )
            ws_instance._running = False
            return _FakeConn()

        return fake_connect

    ws = AgentWS(
        "https://example.com/",
        "ahv_x",
        _noop_on_message,
        extra_headers={
            "CF-Access-Client-Id": "my-id",
            "CF-Access-Client-Secret": "my-secret",
        },
    )
    monkeypatch.setattr(websockets, "connect", make_fake_connect(ws))
    await ws.connect()
    assert len(captured) == 1
    assert captured[0]["additional_headers"] == {
        "CF-Access-Client-Id": "my-id",
        "CF-Access-Client-Secret": "my-secret",
    }


async def test_agentws_no_extra_headers_by_default(monkeypatch):
    """Without extra_headers, additional_headers is not passed."""
    import websockets

    captured: list[dict] = []

    def make_fake_connect(ws_instance):
        def fake_connect(url, **kwargs):
            captured.append(
                {
                    "url": url,
                    "additional_headers": kwargs.get("additional_headers"),
                }
            )
            ws_instance._running = False
            return _FakeConn()

        return fake_connect

    ws = AgentWS("https://example.com/", "ahv_x", _noop_on_message)
    monkeypatch.setattr(websockets, "connect", make_fake_connect(ws))
    await ws.connect()
    assert len(captured) == 1
    assert captured[0]["additional_headers"] is None


async def test_agentws_sets_protocol_keepalive(monkeypatch):
    """connect() must pass ping keepalive so a half-open link surfaces as a
    drop instead of blocking the read loop forever (offline-but-no-reconnect)."""
    import websockets

    captured: list[dict] = []

    def make_fake_connect(ws_instance):
        def fake_connect(url, **kwargs):
            captured.append(kwargs)
            ws_instance._running = False
            return _FakeConn()

        return fake_connect

    ws = AgentWS("https://example.com/", "ahv_x", _noop_on_message)
    monkeypatch.setattr(websockets, "connect", make_fake_connect(ws))
    await ws.connect()

    assert len(captured) == 1
    assert captured[0]["ping_interval"] == 20
    assert captured[0]["ping_timeout"] == 20
    assert captured[0]["close_timeout"] == 10


async def test_heartbeat_closes_socket_on_send_failure(monkeypatch):
    """A failed heartbeat send closes the socket so the main read loop sees a
    drop and reconnects — rather than the heartbeat task dying silently while
    the daemon lingers connected-but-offline."""
    import agentshive.ws as ws_mod

    monkeypatch.setattr(ws_mod, "HEARTBEAT_INTERVAL", 0)

    class _DeadWS:
        def __init__(self) -> None:
            self.closed = False

        async def send(self, _data):
            raise ConnectionResetError("broken pipe")

        async def close(self):
            self.closed = True

    ws = AgentWS("https://example.com/", "ahv_x", _noop_on_message)
    dead = _DeadWS()
    await ws._heartbeat_loop(dead)
    assert dead.closed is True
