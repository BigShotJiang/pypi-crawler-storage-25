from agentshive.local_runner import (
    _collect_artifact_versions,
    _detect_artifact_drift,
    _merge_created_versions,
    build_user_prompt,
    build_resume_prompt,
    build_system_prompt,
    build_prompt,
)
from agentshive.models import Artifact, Attachment, Message


def test_build_user_prompt_no_quote():
    history = [
        Message(
            id="1",
            text="hello",
            thread_id="t1",
            space_id="s1",
            author_handle="user1",
            author_type="human",
        ),
        Message(
            id="2",
            text="hi there",
            thread_id="t1",
            space_id="s1",
            author_handle="agent1",
            author_type="agent",
        ),
    ]
    prompt = build_user_prompt(history)
    assert "@user1: hello" in prompt
    assert "@agent1: hi there" in prompt
    assert "MANDATORY_REPLY: NO" in prompt
    # Ensure no empty "In response to" blocks
    assert "In response to" not in prompt


def test_build_user_prompt_with_quote():
    history = [
        Message(
            id="1",
            text="original message",
            thread_id="t1",
            space_id="s1",
            author_handle="user1",
            author_type="human",
        ),
        Message(
            id="2",
            text="reply with quote",
            thread_id="t1",
            space_id="s1",
            author_handle="agent1",
            author_type="agent",
            quoted_message_id="1",
            quoted_message={"author_handle": "user1", "text": "original message"},
        ),
    ]
    prompt = build_user_prompt(history)
    assert "@user1: original message" in prompt
    assert (
        '@agent1: (In response to @user1: "original message") reply with quote'
        in prompt
    )


def test_build_resume_prompt_with_quote():
    new_messages = [
        Message(
            id="2",
            text="reply with quote",
            thread_id="t1",
            space_id="s1",
            author_handle="agent1",
            author_type="agent",
            quoted_message_id="1",
            quoted_message={"author_handle": "user1", "text": "original message"},
        )
    ]
    prompt = build_resume_prompt(new_messages, handle="agent1", must_reply=True)
    assert (
        '@agent1: (In response to @user1: "original message") reply with quote'
        in prompt
    )
    assert "You were directly addressed. You MUST reply — do not output PASS." in prompt


def test_build_system_prompt_includes_custom_instruction():
    """Per-agent system_instruction is included in the system prompt."""
    prompt = build_system_prompt(
        "You are a senior Python engineer.",
        "claude-eng",
    )
    assert "You are a senior Python engineer." in prompt
    assert "@claude-eng" in prompt


def test_build_system_prompt_includes_space_rules():
    """space_rules are injected as Project Rules."""
    prompt = build_system_prompt(
        "You are a helpful assistant.",
        "test-bot",
        space_rules="Always respond in bullet points.\nNo emojis.",
    )
    assert "## Project Rules" in prompt
    assert "Always respond in bullet points." in prompt
    assert "No emojis." in prompt


def test_build_system_prompt_omits_empty_rules():
    """Empty space_rules should not produce a Project Rules section."""
    prompt = build_system_prompt(
        "You are a helpful assistant.",
        "test-bot",
        space_rules="",
    )
    assert "## Project Rules" not in prompt


def test_build_system_prompt_includes_memory_context():
    """Memory context is appended to the system prompt."""
    prompt = build_system_prompt(
        "You are a helpful assistant.",
        "test-bot",
        memory_context="SELF: I prefer concise answers.",
    )
    assert "SELF: I prefer concise answers." in prompt


def test_build_prompt_uses_per_agent_instruction():
    """build_prompt passes system_instruction through to the system prompt."""
    history = [
        Message(
            id="1",
            text="hello",
            thread_id="t1",
            space_id="s1",
            author_handle="human",
            author_type="human",
        ),
    ]
    prompt = build_prompt(
        history,
        "You are the TPM responsible for project tracking.",
        "claude-tpm",
        space_rules="Ship weekly updates.",
    )
    assert "You are the TPM responsible for project tracking." in prompt
    assert "@claude-tpm" in prompt
    assert "## Project Rules" in prompt
    assert "Ship weekly updates." in prompt
    assert "@human: hello" in prompt


def test_build_resume_prompt_includes_project_rules():
    """Resume prompt includes project rules as a context reminder."""
    new_messages = [
        Message(
            id="1",
            text="what's the plan?",
            thread_id="t1",
            space_id="s1",
            author_handle="human",
            author_type="human",
        ),
    ]
    prompt = build_resume_prompt(
        new_messages,
        handle="bot",
        must_reply=True,
        space_rules="Always use TypeScript.\nNo console.log in prod.",
    )
    assert "Context reminder" in prompt
    assert "Project Rules:" in prompt
    assert "Always use TypeScript." in prompt
    assert "No console.log in prod." in prompt
    assert "@human: what's the plan?" in prompt


def test_build_resume_prompt_includes_memory_context():
    """Resume prompt includes memory context as a reminder."""
    new_messages = [
        Message(
            id="1",
            text="hi",
            thread_id="t1",
            space_id="s1",
            author_handle="human",
            author_type="human",
        ),
    ]
    prompt = build_resume_prompt(
        new_messages,
        handle="bot",
        memory_context="LEARNED: The codebase uses FastAPI with aiosqlite.",
    )
    assert "Context reminder" in prompt
    assert "LEARNED: The codebase uses FastAPI with aiosqlite." in prompt


def test_build_resume_prompt_no_context_when_empty():
    """Resume prompt omits context reminder when no rules or memory."""
    new_messages = [
        Message(
            id="1",
            text="hi",
            thread_id="t1",
            space_id="s1",
            author_handle="human",
            author_type="human",
        ),
    ]
    prompt = build_resume_prompt(new_messages, handle="bot")
    assert "Context reminder" not in prompt
    assert "Project Rules:" not in prompt


def test_build_resume_prompt_backwards_compatible():
    """Resume prompt still works without the new kwargs (backwards compat)."""
    new_messages = [
        Message(
            id="1",
            text="hello",
            thread_id="t1",
            space_id="s1",
            author_handle="user1",
            author_type="human",
        ),
    ]
    prompt = build_resume_prompt(new_messages, handle="bot", must_reply=False)
    assert "@user1: hello" in prompt
    assert 'output exactly "PASS"' in prompt
    assert "Context reminder" not in prompt


# ---------------------------------------------------------------------------
# Attachment rendering
#
# Regression tests for the bug where build_user_prompt / build_resume_prompt
# iterated messages and only emitted `m.text`, silently dropping every
# m.attachments entry. That made the model receive prompts like
# "@user: what does this pdf say?" with zero mention of the uploaded file, so
# it either confabulated content or replied "I don't see any attachment" even
# though the file was on disk on the server. The fix threads an
# ``attachment_paths`` mapping ({id: local_path}) through the prompt builders
# and renders a `[attachment: name (mime) — local path: ... Use your Read
# tool to open it.]` line per attachment.
# ---------------------------------------------------------------------------


def _msg_with_pdf(**overrides):
    defaults = dict(
        id="m1",
        text="can you read this pdf?",
        thread_id="t1",
        space_id="s1",
        author_handle="human",
        author_type="human",
        attachments=[
            Attachment(
                id="att-abc",
                filename="insurance.pdf",
                content_type="application/pdf",
                url="/api/attachments/att-abc",
            )
        ],
    )
    defaults.update(overrides)
    return Message(**defaults)


def test_build_user_prompt_renders_attachment_with_local_path():
    """When a local path is supplied, the prompt tells the agent exactly where to Read it."""
    msg = _msg_with_pdf()
    prompt = build_user_prompt(
        [msg],
        must_reply=True,
        attachment_paths={"att-abc": "/tmp/ahv/att-abc_insurance.pdf"},
    )
    assert "@human: can you read this pdf?" in prompt
    assert "[attachment: insurance.pdf (application/pdf)" in prompt
    assert "local path: /tmp/ahv/att-abc_insurance.pdf" in prompt
    assert "Use your Read tool to open it." in prompt


def test_build_user_prompt_flags_failed_download():
    """When no local path is supplied, the agent is told the content is unavailable.

    Important: we do NOT silently drop the attachment (that was the old bug) —
    the agent needs to know a file *exists* even if we couldn't fetch it, so
    it can ask the human to re-upload instead of hallucinating.
    """
    msg = _msg_with_pdf()
    prompt = build_user_prompt([msg], must_reply=True, attachment_paths=None)
    assert "[attachment: insurance.pdf (application/pdf)" in prompt
    assert "download failed" in prompt
    assert "content is NOT available" in prompt


def test_build_user_prompt_omits_attachment_line_when_no_attachments():
    """Messages without attachments must not gain a bogus attachment line."""
    msg = Message(
        id="m1",
        text="plain text",
        thread_id="t1",
        space_id="s1",
        author_handle="human",
        author_type="human",
    )
    prompt = build_user_prompt([msg], attachment_paths={"att-abc": "/tmp/x"})
    assert "[attachment:" not in prompt


def test_build_user_prompt_handles_missing_mime_type():
    """A missing/blank content_type should fall back to application/octet-stream, not crash."""
    msg = _msg_with_pdf(
        attachments=[
            Attachment(id="att-1", filename="weird.bin", content_type="", url="/x")
        ]
    )
    prompt = build_user_prompt(
        [msg],
        attachment_paths={"att-1": "/tmp/weird.bin"},
    )
    assert "[attachment: weird.bin (application/octet-stream)" in prompt


def test_build_resume_prompt_renders_attachment_with_local_path():
    """The resume path must render attachments too — this was half of the original bug."""
    msg = _msg_with_pdf()
    prompt = build_resume_prompt(
        [msg],
        handle="claude-eng",
        must_reply=True,
        attachment_paths={"att-abc": "/tmp/ahv/att-abc_insurance.pdf"},
    )
    assert "@human: can you read this pdf?" in prompt
    assert "[attachment: insurance.pdf (application/pdf)" in prompt
    assert "local path: /tmp/ahv/att-abc_insurance.pdf" in prompt


def test_build_prompt_passes_attachments_through_to_user_prompt():
    """The flat build_prompt wrapper must plumb attachment_paths through."""
    msg = _msg_with_pdf()
    prompt = build_prompt(
        [msg],
        "You are an engineer.",
        "claude-eng",
        must_reply=True,
        attachment_paths={"att-abc": "/tmp/ahv/insurance.pdf"},
    )
    assert "local path: /tmp/ahv/insurance.pdf" in prompt


def test_build_user_prompt_renders_multiple_attachments_in_message_order():
    """Multi-attachment messages should render one line per attachment."""
    msg = Message(
        id="m1",
        text="two files attached",
        thread_id="t1",
        space_id="s1",
        author_handle="human",
        author_type="human",
        attachments=[
            Attachment(
                id="a1", filename="one.pdf", content_type="application/pdf", url="/x"
            ),
            Attachment(id="a2", filename="two.png", content_type="image/png", url="/x"),
        ],
    )
    prompt = build_user_prompt(
        [msg],
        attachment_paths={"a1": "/tmp/one.pdf", "a2": "/tmp/two.png"},
    )
    # Both files must be present and each linked to its own local path.
    assert "[attachment: one.pdf (application/pdf)" in prompt
    assert "local path: /tmp/one.pdf" in prompt
    assert "[attachment: two.png (image/png)" in prompt
    assert "local path: /tmp/two.png" in prompt


# ---------------------------------------------------------------------------
# Artifact rendering
#
# Symmetric with attachment rendering above. Artifacts are structured docs
# (plans, specs, scoping docs) linked to the authoring message via
# artifacts.message_id. The backend now merges them onto each message in
# /threads/{id}/messages; the SDK must inline their body into the prompt so
# agents on thread_reply tasks can actually see what the thread is about.
#
# Previously the agent would respond with "I don't see the artifact body
# rendered in my thread" because nothing surfaced the content — that
# regression lives on permanently in these tests.
# ---------------------------------------------------------------------------


def _msg_with_artifact(**overrides) -> Message:
    defaults = dict(
        id="m-art",
        text="Here's the plan — thoughts?",
        thread_id="t1",
        space_id="s1",
        author_handle="claude-eng",
        author_type="agent",
        artifacts=[
            Artifact(
                id="art-1",
                title="Launch Plan",
                content="# Launch\n\nStep 1: ship it",
                content_type="markdown",
                status="draft",
                version=2,
                author_handle="claude-eng",
            )
        ],
    )
    defaults.update(overrides)
    return Message(**defaults)


def test_build_user_prompt_inlines_artifact_body():
    """The agent must see the artifact title AND full content in the prompt."""
    prompt = build_user_prompt([_msg_with_artifact()])
    assert (
        '[artifact: "Launch Plan" (type: markdown, version 2, status: draft, by @claude-eng)]'
        in prompt
    )
    assert "=== BEGIN ARTIFACT CONTENT ===" in prompt
    assert "# Launch" in prompt
    assert "Step 1: ship it" in prompt
    assert "=== END ARTIFACT CONTENT ===" in prompt


def test_build_user_prompt_omits_artifact_when_none():
    """Messages without artifacts must not produce a stray artifact block."""
    msg = Message(
        id="m1",
        text="plain text",
        thread_id="t1",
        space_id="s1",
        author_handle="human",
        author_type="human",
    )
    prompt = build_user_prompt([msg])
    assert "[artifact:" not in prompt
    assert "ARTIFACT CONTENT" not in prompt


def test_build_user_prompt_renders_multiple_artifacts():
    """One block per artifact, in message order."""
    msg = _msg_with_artifact(
        artifacts=[
            Artifact(
                id="art-1",
                title="Plan A",
                content="plan a body",
                content_type="markdown",
                status="draft",
                version=1,
                author_handle="alice",
            ),
            Artifact(
                id="art-2",
                title="Plan B",
                content="plan b body",
                content_type="markdown",
                status="approved",
                version=3,
                author_handle="bob",
            ),
        ]
    )
    prompt = build_user_prompt([msg])
    assert '"Plan A"' in prompt
    assert "plan a body" in prompt
    assert '"Plan B"' in prompt
    assert "status: approved" in prompt
    assert "plan b body" in prompt
    assert prompt.index("Plan A") < prompt.index("Plan B")


def test_build_user_prompt_handles_missing_content_type():
    """Blank content_type falls back to markdown, not crash."""
    msg = _msg_with_artifact(
        artifacts=[
            Artifact(
                id="art-1",
                title="Untitled",
                content="body",
                content_type="",
                status="draft",
                version=1,
                author_handle="alice",
            )
        ]
    )
    prompt = build_user_prompt([msg])
    assert "(type: markdown," in prompt


def test_build_resume_prompt_inlines_artifact_body():
    """The resume path must surface artifacts too — session-resume is the
    other branch that builds conversation history for the LLM."""
    prompt = build_resume_prompt(
        [_msg_with_artifact()],
        handle="claude-eng",
        must_reply=True,
    )
    assert '[artifact: "Launch Plan"' in prompt
    assert "Step 1: ship it" in prompt


def test_build_prompt_plumbs_artifacts_through():
    """The flat build_prompt wrapper must also inline artifact bodies."""
    prompt = build_prompt(
        [_msg_with_artifact()],
        "You are an engineer.",
        "claude-eng",
        must_reply=True,
    )
    assert '[artifact: "Launch Plan"' in prompt
    assert "Step 1: ship it" in prompt


def test_build_user_prompt_artifact_after_attachment():
    """If a message has both an attachment and an artifact, both render."""
    msg = Message(
        id="m1",
        text="see file and plan",
        thread_id="t1",
        space_id="s1",
        author_handle="human",
        author_type="human",
        attachments=[
            Attachment(
                id="a1",
                filename="notes.pdf",
                content_type="application/pdf",
                url="/x",
            )
        ],
        artifacts=[
            Artifact(
                id="art-1",
                title="Design",
                content="design body",
                content_type="markdown",
                status="draft",
                version=1,
                author_handle="alice",
            )
        ],
    )
    prompt = build_user_prompt([msg], attachment_paths={"a1": "/tmp/notes.pdf"})
    assert "[attachment: notes.pdf" in prompt
    assert '[artifact: "Design"' in prompt
    assert "design body" in prompt
    # Attachments render before artifacts so the order is deterministic.
    assert prompt.index("[attachment:") < prompt.index("[artifact:")


# ---------------------------------------------------------------------------
# Artifact version drift on resumed sessions
#
# The resume path only replays messages after last_seen, but artifacts are
# linked to their authoring message (often older). If an artifact was already
# shown at v1 and later edited to v2, the resumed prompt would miss the new
# body and the agent would reason over a stale cached version. The handler
# uses _detect_artifact_drift to catch this and fall back to a full prompt.
# ---------------------------------------------------------------------------


def _msg_with_version(v: int) -> Message:
    return Message(
        id="m1",
        text="here's the plan",
        thread_id="t1",
        space_id="s1",
        author_handle="alice",
        author_type="human",
        artifacts=[
            Artifact(
                id="art-1",
                title="Plan",
                content=f"body v{v}",
                content_type="markdown",
                status="draft",
                version=v,
                author_handle="alice",
            )
        ],
    )


def test_collect_artifact_versions_empty_history():
    assert _collect_artifact_versions([]) == {}


def test_collect_artifact_versions_maps_id_to_version():
    msg_a = _msg_with_version(1)
    msg_b = Message(
        id="m2",
        text="another",
        thread_id="t1",
        space_id="s1",
        author_handle="bob",
        author_type="human",
        artifacts=[
            Artifact(
                id="art-2",
                title="Other",
                content="x",
                content_type="markdown",
                status="approved",
                version=3,
                author_handle="bob",
            )
        ],
    )
    assert _collect_artifact_versions([msg_a, msg_b]) == {"art-1": 1, "art-2": 3}


def test_collect_artifact_versions_keeps_latest_for_duplicate_ids():
    """If the same artifact id shows up twice (shouldn't happen, but guard anyway),
    the map reflects the last-written version in iteration order."""
    m1 = _msg_with_version(1)
    m2 = _msg_with_version(2)
    # Both messages carry artifact id='art-1' at different versions
    assert _collect_artifact_versions([m1, m2]) == {"art-1": 2}


def test_detect_artifact_drift_no_previous_versions():
    """First turn — nothing to drift from."""
    assert _detect_artifact_drift([_msg_with_version(1)], {}) is False


def test_detect_artifact_drift_same_version():
    """Unchanged artifact — no drift."""
    assert _detect_artifact_drift([_msg_with_version(1)], {"art-1": 1}) is False


def test_detect_artifact_drift_version_bumped():
    """The key case: shown at v1, now v2 — caller must refresh."""
    assert _detect_artifact_drift([_msg_with_version(2)], {"art-1": 1}) is True


def test_detect_artifact_drift_new_artifact_not_drift():
    """A brand-new artifact (not in prev map) is not drift — its authoring
    message is necessarily after last_seen, so the normal resume path picks
    it up."""
    history = [
        _msg_with_version(1),  # art-1 previously seen at v1
        Message(
            id="m-new",
            text="new artifact",
            thread_id="t1",
            space_id="s1",
            author_handle="bob",
            author_type="human",
            artifacts=[
                Artifact(
                    id="art-brand-new",
                    title="Fresh",
                    content="fresh body",
                    content_type="markdown",
                    status="draft",
                    version=1,
                    author_handle="bob",
                )
            ],
        ),
    ]
    assert _detect_artifact_drift(history, {"art-1": 1}) is False


def test_detect_artifact_drift_one_of_many_bumped():
    """Returns True as soon as any previously-seen artifact is outdated."""
    history = [
        _msg_with_version(1),  # art-1 still v1
        Message(
            id="m2",
            text="other",
            thread_id="t1",
            space_id="s1",
            author_handle="bob",
            author_type="human",
            artifacts=[
                Artifact(
                    id="art-2",
                    title="Other",
                    content="x",
                    content_type="markdown",
                    status="approved",
                    version=5,
                    author_handle="bob",
                )
            ],
        ),
    ]
    assert _detect_artifact_drift(history, {"art-1": 1, "art-2": 3}) is True


def test_detect_artifact_drift_ignores_messages_without_artifacts():
    """Plain messages must not break detection."""
    plain = Message(
        id="mp",
        text="hi",
        thread_id="t1",
        space_id="s1",
        author_handle="bob",
        author_type="human",
    )
    assert _detect_artifact_drift([plain, _msg_with_version(2)], {"art-1": 1}) is True


# ---------------------------------------------------------------------------
# Self-authored artifact tracking
#
# _collect_artifact_versions runs on the *fetched* history, before the agent
# replies. Artifacts the agent creates via api.create_artifact in the current
# turn are absent from that snapshot. If we stored only the pre-reply snapshot,
# a later edit of a self-authored artifact would be missed — the artifact id
# wouldn't be in the map, drift detection would treat it as "new", and the
# resume path would reuse the session with the stale v1 body cached.
#
# _merge_created_versions folds the server-returned ids+versions back in so
# the stored snapshot is complete.
# ---------------------------------------------------------------------------


def test_merge_created_versions_empty():
    """No new creations → snapshot unchanged."""
    assert _merge_created_versions({"art-1": 2}, []) == {"art-1": 2}


def test_merge_created_versions_adds_new_entries():
    created = [{"id": "art-new", "version": 1, "title": "Plan"}]
    assert _merge_created_versions({}, created) == {"art-new": 1}


def test_merge_created_versions_preserves_existing_and_adds():
    created = [{"id": "art-b", "version": 1, "title": "B"}]
    assert _merge_created_versions({"art-a": 3}, created) == {"art-a": 3, "art-b": 1}


def test_merge_created_versions_tolerates_missing_id():
    """A malformed response (no id) is skipped, not crashed on."""
    created = [
        {"id": "art-ok", "version": 2},
        {"title": "no-id"},
        None,
    ]
    assert _merge_created_versions({}, created) == {"art-ok": 2}


def test_merge_created_versions_defaults_missing_version_to_1():
    """Newly-created artifacts default to v1 when the server omits version."""
    assert _merge_created_versions({}, [{"id": "art-x"}]) == {"art-x": 1}


# ---------------------------------------------------------------------------
# @all fan-out directive (cost mitigation)
#
# When the backend expands @all into N targeted mentions, it sets
# at_all_count=N on the WS task payload. The SDK appends an AT_ALL_FANOUT
# directive that biases each addressee toward PASS, since the
# MANDATORY_REPLY=YES that @all implies would otherwise produce N substantive
# replies for one user message. The directive only fires for true fan-outs
# (count >= 2); single-agent rooms degrade to a normal direct mention.
# ---------------------------------------------------------------------------


def _human_msg(text: str = "weigh in") -> Message:
    return Message(
        id="m1",
        text=text,
        thread_id="t1",
        space_id="s1",
        author_handle="human",
        author_type="human",
    )


def test_at_all_directive_renders_when_count_is_two_or_more():
    prompt = build_user_prompt([_human_msg()], must_reply=True, at_all_count=4)
    assert "MANDATORY_REPLY: YES" in prompt
    assert "@ALL_FANOUT:" in prompt
    assert "alongside 3 other agents" in prompt
    assert "PASS is the right answer" in prompt


def test_at_all_directive_singular_agent_phrasing():
    """count=2 means the addressee plus exactly 1 other — singular grammar."""
    prompt = build_user_prompt([_human_msg()], must_reply=True, at_all_count=2)
    assert "alongside 1 other agent " in prompt
    assert "alongside 1 other agents" not in prompt


def test_at_all_directive_skipped_for_count_below_two():
    """count=0 (the normal case, no @all) and count=1 (degenerate single-
    agent room) must not emit the directive — it would mislead the agent
    in the count=1 case and is just noise in the count=0 case."""
    for count in (0, 1):
        prompt = build_user_prompt([_human_msg()], must_reply=True, at_all_count=count)
        assert "@ALL_FANOUT" not in prompt, f"count={count} should not emit directive"


def test_at_all_directive_default_omitted():
    """Default behavior (no at_all_count kwarg) matches the pre-feature output."""
    prompt = build_user_prompt([_human_msg()], must_reply=True)
    assert "@ALL_FANOUT" not in prompt


def test_at_all_directive_resume_prompt():
    """The resume path must surface the directive too — agents on resumed
    sessions are equally subject to the cost-bias regime."""
    prompt = build_resume_prompt(
        [_human_msg()], handle="claude-eng", must_reply=True, at_all_count=3
    )
    assert "You were directly addressed. You MUST reply" in prompt
    assert "@ALL_FANOUT:" in prompt
    assert "alongside 2 other agents" in prompt


def test_at_all_directive_flat_build_prompt_plumbing():
    """build_prompt must thread at_all_count to build_user_prompt — without
    this, fall-back / truncation-retry / no-resume paths in local_runner
    would silently drop the directive."""
    prompt = build_prompt(
        [_human_msg()],
        "You are an engineer.",
        "claude-eng",
        must_reply=True,
        at_all_count=5,
    )
    assert "@ALL_FANOUT:" in prompt
    assert "alongside 4 other agents" in prompt


def test_self_authored_edit_is_detected_as_drift():
    """End-to-end of the review scenario: agent creates art-self v1 on turn N,
    human edits it to v2 before turn N+1, drift detection catches it.
    """
    # Pre-reply snapshot on turn N: no artifacts in thread yet.
    pre_snapshot: dict[str, int] = {}
    # Agent's reply produced an artifact; server returned it.
    created = [{"id": "art-self", "version": 1, "title": "Agent Plan"}]
    stored = _merge_created_versions(pre_snapshot, created)
    assert stored == {"art-self": 1}

    # Turn N+1: history now includes the agent's reply message carrying the
    # edited artifact at v2.
    history = [
        Message(
            id="m-agent-reply",
            text="here's the plan",
            thread_id="t1",
            space_id="s1",
            author_handle="claude-eng",
            author_type="agent",
            artifacts=[
                Artifact(
                    id="art-self",
                    title="Agent Plan",
                    content="v2 body",
                    content_type="markdown",
                    status="draft",
                    version=2,
                    author_handle="claude-eng",
                )
            ],
        ),
    ]
    assert _detect_artifact_drift(history, stored) is True
