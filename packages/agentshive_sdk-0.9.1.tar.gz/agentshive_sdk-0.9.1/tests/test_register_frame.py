"""Tests for the WS `register` frame builder.

Heartbeat-staleness chunk 2: every (re)connect must announce the SDK's
`sys.platform` so the server can attribute stale-backend events to an OS
family for the chunk-3 classifier. The frame is built by
`agentshive.client._build_register_frame`, extracted from `_on_ws_connect`
(closure inside `BackendClient.start`) so the shape is directly testable
without mocking websockets.
"""

from __future__ import annotations

import sys

from agentshive.client import _build_register_frame


def test_register_frame_includes_platform_when_supported_backends_present():
    frame = _build_register_frame(["claude-code", "gemini-cli"])
    assert frame["type"] == "register"
    assert frame["platform"] == sys.platform
    assert frame["supported_backends"] == ["claude-code", "gemini-cli"]


def test_register_frame_includes_platform_when_supported_backends_empty():
    """Backends with no agents configured at SDK startup must still report
    platform. The backend's `_apply_register_frame` (agenthive PR #415)
    accepts platform-only frames and no-ops on the supported_backends field.
    """
    frame = _build_register_frame([])
    assert frame["type"] == "register"
    assert frame["platform"] == sys.platform
    assert "supported_backends" not in frame


def test_register_frame_includes_platform_when_supported_backends_none():
    """`BackendClient.start(supported_backends=None)` is the public default
    in `client.py:328`. Platform must still be reported.
    """
    frame = _build_register_frame(None)
    assert frame["type"] == "register"
    assert frame["platform"] == sys.platform
    assert "supported_backends" not in frame


def test_register_frame_platform_is_raw_sys_platform_value():
    """Per the chunk 2 design lock, the SDK forwards `sys.platform` raw
    (`darwin` / `linux` / `win32` / `freebsd*` / etc). Bucketing happens
    server-side in the chunk-3 classifier, not here. Guards against a
    future "helpful" SDK-side coarsening regression.
    """
    frame = _build_register_frame(["x"])
    assert frame["platform"] == sys.platform
    # sys.platform is always lowercase identifier from Python — sanity-check
    # that the SDK isn't transforming it.
    assert frame["platform"].islower()
    assert " " not in frame["platform"]
