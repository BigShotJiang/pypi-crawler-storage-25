"""Hazards module."""
