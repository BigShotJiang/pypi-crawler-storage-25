from typing import Optional
from videodb._utils._video import play_stream, build_iframe_embed_code
from videodb._constants import (
    ApiPath,
)


class Shot:
    """Shot class to interact with video shots

    :ivar str video_id: Unique identifier for the video
    :ivar float video_length: Duration of the video in seconds
    :ivar str video_title: Title of the video
    :ivar float start: Start time of the shot in seconds
    :ivar float end: End time of the shot in seconds
    :ivar str text: Text content of the shot
    :ivar int search_score: Search relevance score
    :ivar str stream_url: URL to stream the shot
    :ivar str player_url: URL to play the shot in a player
    :ivar Optional[str] scene_index_id: ID of the scene index for scene search results
    :ivar Optional[str] scene_index_name: Name of the scene index for scene search results
    :ivar Optional[dict] metadata: Additional metadata for the shot
    """

    def __init__(
        self,
        _connection,
        video_id: str,
        video_length: float,
        video_title: str,
        start: float,
        end: float,
        text: Optional[str] = None,
        search_score: Optional[int] = None,
        scene_index_id: Optional[str] = None,
        scene_index_name: Optional[str] = None,
        metadata: Optional[dict] = None,
        stream_url: Optional[str] = None,
        player_url: Optional[str] = None,
    ) -> None:
        self._connection = _connection
        self.video_id = video_id
        self.video_length = video_length
        self.video_title = video_title
        self.start = start
        self.end = end
        self.text = text
        self.search_score = search_score
        self.scene_index_id = scene_index_id
        self.scene_index_name = scene_index_name
        self.metadata = metadata
        self.stream_url = stream_url
        self.player_url = player_url

    def __repr__(self) -> str:
        repr_str = (
            f"Shot("
            f"video_id={self.video_id}, "
            f"video_title={self.video_title}, "
            f"start={self.start}, "
            f"end={self.end}, "
            f"text={self.text}, "
            f"search_score={self.search_score}"
        )
        if self.scene_index_id:
            repr_str += f", scene_index_id={self.scene_index_id}"

        if self.scene_index_name:
            repr_str += f", scene_index_name={self.scene_index_name}"

        if self.metadata:
            repr_str += f", metadata={self.metadata}"

        repr_str += f", stream_url={self.stream_url}, player_url={self.player_url})"
        return repr_str

    def __getitem__(self, key):
        """Get an item from the shot object"""
        return self.__dict__[key]

    def generate_stream(self) -> str:
        """Generate a stream url for the shot.

        :return: The stream url
        :rtype: str
        """

        if self.stream_url:
            return self.stream_url
        else:
            stream_data = self._connection.post(
                path=f"{ApiPath.video}/{self.video_id}/{ApiPath.stream}",
                data={
                    "timeline": [(self.start, self.end)],
                    "length": self.video_length,
                },
            )
            self.stream_url = stream_data.get("stream_url")
            self.player_url = stream_data.get("player_url")
            return self.stream_url

    def play(self) -> str:
        """Generate a stream url for the shot and open it in the default browser/ notebook.

        :return: The stream url
        :rtype: str
        """
        self.generate_stream()
        return play_stream(self.stream_url)

    def get_embed_code(
        self,
        width: str = "100%",
        height: int = 405,
        title: str = "VideoDB Player",
        allow_fullscreen: bool = True,
        auto_generate: bool = True,
    ) -> str:
        """Generate an HTML iframe embed code for the shot.

        :param str width: Width of the iframe (default: "100%")
        :param int height: Height of the iframe in pixels (default: 405)
        :param str title: Title attribute for the iframe (default: "VideoDB Player")
        :param bool allow_fullscreen: Whether to allow fullscreen (default: True)
        :param bool auto_generate: If True and player_url is missing, auto-generate it (default: True)
        :return: HTML iframe string
        :rtype: str
        :raises ValueError: If player_url is not available
        """
        if not self.player_url and auto_generate:
            self.generate_stream()

        if not self.player_url:
            raise ValueError(
                "player_url not available. Call generate_stream() first or set auto_generate=True."
            )

        return build_iframe_embed_code(
            player_url=self.player_url,
            width=width,
            height=height,
            title=title,
            allow_fullscreen=allow_fullscreen,
        )
