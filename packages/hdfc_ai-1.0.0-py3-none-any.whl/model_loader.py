import os
import time
import threading
import subprocess
import sys
import platform
import requests
import litellm
from strands import Agent
from strands.models.llamacpp import LlamaCppModel
from rich.console import Console
from config import load_config, config_exists, run_setup_wizard

os.environ["LITELLM_LOCAL_MODEL_COST_MAP"] = "True"
os.environ["LITELLM_REQUEST_TIMEOUT"] = "30"

litellm.suppress_debug_info = True
litellm.set_verbose = False

console = Console()

_lock = threading.Lock()
_server_started = False

# ── Load config ───────────────────────────────────────────
if not config_exists():
    run_setup_wizard()

_config = load_config()
MODEL_PATH = _config.get("model_path", "")
SERVER_URL = _config.get("server_url", "http://localhost:8080")
MODE = _config.get("mode", "local")
# ─────────────────────────────────────────────────────────


def print_typewriter(text: str, delay: float = 0.02):
    """Print text character by character like a human typing."""
    for char in text:
        print(char, end="", flush=True)
        time.sleep(delay)
    print()


def get_server_command() -> list:
    """Returns the correct server start command for current OS."""
    base_cmd = [
        sys.executable, "-m", "llama_cpp.server",
        "--model", MODEL_PATH,
        "--host", "0.0.0.0",
        "--port", "8080",
        "--n_threads", "8",
        "--n_ctx", "8192",
    ]

    system = platform.system().lower()

    if system == "windows":
        return base_cmd

    elif system == "darwin":
        # Mac — use Metal GPU if available
        return base_cmd + ["--n_gpu_layers", "1"]

    else:
        # Linux — use CUDA if available, fallback to CPU
        try:
            subprocess.run(["nvidia-smi"], capture_output=True, check=True)
            return base_cmd + ["--n_gpu_layers", "32"]
        except:
            return base_cmd


def start_server():
    global _server_started
    if _server_started:
        return

    if MODE != "local":
        console.print(f"[SERVER] Using cloud model — no local server needed ✅")
        _server_started = True
        return

    if not MODEL_PATH or not os.path.exists(MODEL_PATH):
        console.print(f"[bold red][SERVER][/bold red] ❌ Model not found: {MODEL_PATH}")
        console.print(f"[bold red][SERVER][/bold red] Delete ~/.hdfc_ai/config.json and restart to reconfigure.")
        sys.exit(1)

    console.print("[SERVER] Starting llama-server in background...")

    cmd = get_server_command()
    system = platform.system().lower()

    if system == "windows":
        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        # Mac/Linux — run in background properly
        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )

    # Wait until server is ready
    for _ in range(40):
        try:
            requests.get(f"{SERVER_URL}/health", timeout=2)
            console.print("[SERVER] ✅ Model ready!")
            _server_started = True
            return
        except:
            time.sleep(3)

    raise RuntimeError(
        "❌ Server failed to start.\n"
        "Check your model path in ~/.hdfc_ai/config.json\n"
        "Or delete ~/.hdfc_ai/config.json and restart to reconfigure."
    )


def ask_model(prompt: str, system: str = "") -> str:
    with _lock:
        if MODE == "local":
            model = LlamaCppModel(
                base_url=SERVER_URL,
                params={
                    "temperature": 0.2,
                    "max_tokens": 4096,
                }
            )
            agent = Agent(
                model=model,
                system_prompt=system if system else "You are HDFC_AI, a smart coding assistant.",
                callback_handler=None
            )
            response = agent(prompt)
            return str(response).strip()

        # ── Cloud mode ────────────────────────────────────
        model_map = {
            "claude":  "claude-3-5-sonnet-20241022",
            "gpt4":    "gpt-4",
            "mistral": "mistral/mistral-7b-instruct",
        }
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = litellm.completion(
            model=model_map.get(MODE, "gpt-4"),
            messages=messages,
            temperature=0.2,
            max_tokens=4096,
        )
        return response.choices[0].message.content.strip()