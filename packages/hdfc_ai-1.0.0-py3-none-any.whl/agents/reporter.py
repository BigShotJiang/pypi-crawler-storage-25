import os
import difflib
from rich.console import Console
from model_loader import ask_model, print_typewriter

console = Console()


def generate_diff(original: str, modified: str, filename: str = "file") -> str:
    """Generate a unified diff between original and modified content."""
    original_lines = original.splitlines(keepends=True)
    modified_lines = modified.splitlines(keepends=True)
    diff = list(difflib.unified_diff(
        original_lines,
        modified_lines,
        fromfile=f"original/{filename}",
        tofile=f"modified/{filename}",
        lineterm=""
    ))
    return "".join(diff)


def show_diff(diff: str):
    """Print colored diff to console."""
    if not diff:
        console.print("[dim]No changes detected.[/dim]")
        return

    console.print("\n[bold white]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ DIFF ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[/bold white]")
    for line in diff.splitlines():
        if line.startswith("+") and not line.startswith("+++"):
            console.print(f"[bold green]{line}[/bold green]")
        elif line.startswith("-") and not line.startswith("---"):
            console.print(f"[bold red]{line}[/bold red]")
        elif line.startswith("@@"):
            console.print(f"[bold cyan]{line}[/bold cyan]")
        else:
            console.print(f"[dim]{line}[/dim]")
    console.print("[bold white]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[/bold white]\n")


def apply_changes(filepath: str, new_content: str):
    """Backup and overwrite the file with new content."""
    backup_path = filepath + ".bak"
    if os.path.exists(filepath):
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            original = f.read()
        with open(backup_path, "w", encoding="utf-8") as f:
            f.write(original)
        console.print(f"[bold yellow][REPORTER][/bold yellow] ⚠️  Backed up → {backup_path}")

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(new_content)
    console.print(f"[bold green][REPORTER][/bold green] ✅ Applied → {filepath}")


def run_reporter(original_content: str, new_code: str, analysis: str, relevant_files: list, user_prompt: str) -> bool:
    """
    Shows diff between original and new code.
    Asks user Y/N before applying.
    Returns True if changes were applied, False if discarded.
    """
    console.print("\n[bold magenta][REPORTER][/bold magenta] Preparing diff report...")

    if not new_code or not new_code.strip():
        console.print("[bold magenta][REPORTER][/bold magenta] ⚠️  No changes to apply")
        return False

    # Show summary of what will change
    console.print("\n[bold magenta][REPORTER][/bold magenta] 📋 Change Summary:")
    summary = ask_model(
        prompt=f"""User request: {user_prompt}

Analysis summary:
{analysis[:1000]}

Write a 2-3 line summary of what changes will be made and why.
Be specific about which files and what exactly changes.""",
        system="You are a code reviewer for HDFC_AI. Summarize the planned changes clearly and concisely."
    )
    print_typewriter(summary)
    print()

    # Generate and show diff for each relevant file
    applied_any = False
    for filepath in relevant_files:
        if not os.path.exists(filepath):
            continue

        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                original = f.read()
        except Exception as e:
            console.print(f"[bold red][REPORTER][/bold red] Could not read {filepath}: {e}")
            continue

        filename = os.path.basename(filepath)

        # Generate diff
        diff = generate_diff(original, new_code, filename)

        if not diff:
            console.print(f"[dim][REPORTER] No changes for {filename}[/dim]")
            continue

        # Show diff
        console.print(f"\n[bold magenta][REPORTER][/bold magenta] Diff for [bold]{filename}[/bold]:")
        show_diff(diff)

        # Ask Y/N before applying
        confirm = input(f"⚡ Apply changes to {filename}? (Y/N): ").strip().lower()
        if confirm == "y":
            apply_changes(filepath, new_code)
            applied_any = True
            console.print(f"[bold green][REPORTER][/bold green] ✅ Changes applied to {filename}")
        else:
            console.print(f"[bold red][REPORTER][/bold red] ❌ Changes discarded for {filename}")

    return applied_any