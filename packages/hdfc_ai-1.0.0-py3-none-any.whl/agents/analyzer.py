from rich.console import Console
from model_loader import ask_model, print_typewriter

console = Console()


def run_analyzer(content: str, user_prompt: str, plan: str = "", history: str = "") -> str:
    console.print("\n[bold yellow][ANALYZER][/bold yellow] Starting code analysis...")

    if not content.strip():
        console.print("[bold yellow][ANALYZER][/bold yellow] ⚠️  No content to analyze")
        return ""

    console.print("[bold yellow][ANALYZER][/bold yellow] → Parsing structure and logic...")

    analysis = ask_model(
        prompt=f"""You are a senior code analyst working as part of HDFC_AI coding assistant.

User Request: {user_prompt}

Plan:
{plan if plan else "No plan provided"}

{history}

Code to analyze:
{content[:3000]}

Based on the user request and plan, provide a thorough analysis:

IF user wants TEST CASES:
- List every class and every method found
- For each method: what it does, input params, expected output
- List edge cases to test
- List required imports

IF user wants BUG FIXES:
- List all bugs with exact line numbers
- List security vulnerabilities
- List exactly what needs to be fixed and how

IF user wants NEW FEATURES:
- Understand what needs to be built
- List structure and logic needed
- List dependencies required

IF user wants REFACTORING:
- List what can be improved
- List design pattern suggestions
- List performance improvements

IF user wants CODE REVIEW:
- List code quality issues
- List best practice violations
- List suggestions for improvement

Always be specific with file names, line numbers, and exact changes needed.""",
        system="""You are a senior code analyst for HDFC_AI, a smart coding assistant like aider.
Deeply understand the user request and plan, then analyze the code accordingly.
Always reference exact file names and line numbers.
Be specific, thorough, and actionable."""
    )

    console.print("\n[bold yellow][ANALYZER][/bold yellow] 📋 Analysis:\n")
    print_typewriter(analysis)
    print()
    console.print("[bold yellow][ANALYZER][/bold yellow] ✅ Done — analysis complete")
    return analysis