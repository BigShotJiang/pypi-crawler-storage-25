from rich.console import Console
from model_loader import ask_model, print_typewriter

console = Console()


def run_planner(user_prompt: str, project_context: str, history: str = "") -> str:
    console.print("\n[bold blue][PLANNER][/bold blue] Thinking about the plan...")

    plan = ask_model(
        prompt=f"""You are a senior software architect planning code changes.

Project structure:
{project_context}

{history}

User request: {user_prompt}

Create a clear, concise plan:
1. Which files need to be read or modified
2. What exactly needs to be changed and why
3. What is the step by step approach
4. Any risks or things to be careful about

Be specific about file names and what changes are needed.
Keep the plan short and actionable.""",
        system="""You are a senior software architect and planner for HDFC_AI coding assistant.
Your job is to create a clear, specific, actionable plan before any code is written or modified.
Always mention exact file names, what needs to change, and why.
Be concise — no fluff, just the plan."""
    )

    console.print(f"\n[bold blue][PLANNER][/bold blue] 📋 Plan:\n")
    print_typewriter(plan)
    print()

    # Ask user to confirm the plan before proceeding
    confirm = input("⚡ Proceed with this plan? (Y/N): ").strip().lower()
    if confirm != "y":
        console.print("[bold red][PLANNER][/bold red] ❌ Plan rejected — operation cancelled.\n")
        return ""

    console.print("[bold blue][PLANNER][/bold blue] ✅ Plan approved — starting agents...\n")
    return plan