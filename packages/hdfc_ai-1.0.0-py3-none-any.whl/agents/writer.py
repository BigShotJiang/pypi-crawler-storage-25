import os
import difflib
import shutil
from rich.console import Console
from rich.syntax import Syntax
from model_loader import ask_model

console = Console()


def generate_diff(original: str, modified: str, filename: str = "file") -> str:
    """Generate a unified diff between original and modified content."""
    original_lines = original.splitlines(keepends=True)
    modified_lines = modified.splitlines(keepends=True)
    diff = list(difflib.unified_diff(
        original_lines,
        modified_lines,
        fromfile=f"original/{filename}",
        tofile=f"modified/{filename}",
        lineterm=""
    ))
    return "".join(diff)


def show_diff(diff: str):
    """Print colored diff to console."""
    if not diff:
        console.print("[dim]No changes detected.[/dim]")
        return

    console.print("\n[bold white]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ DIFF ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[/bold white]")
    for line in diff.splitlines():
        if line.startswith("+") and not line.startswith("+++"):
            console.print(f"[bold green]{line}[/bold green]")
        elif line.startswith("-") and not line.startswith("---"):
            console.print(f"[bold red]{line}[/bold red]")
        elif line.startswith("@@"):
            console.print(f"[bold cyan]{line}[/bold cyan]")
        else:
            console.print(f"[dim]{line}[/dim]")
    console.print("[bold white]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[/bold white]\n")


def safe_backup(filepath: str):
    """Backup existing file before overwriting."""
    if os.path.exists(filepath):
        backup_path = filepath + ".bak"
        shutil.copy2(filepath, backup_path)
        console.print(f"[bold yellow][WRITER][/bold yellow] ⚠️  Backed up → {backup_path}")


def run_writer(analysis: str, user_prompt: str, plan: str = "", new_file: bool = False) -> dict:
    """
    Generates code changes based on analysis and plan.
    Returns a dict of {filepath: new_content}
    """
    console.print("\n[bold green][WRITER][/bold green] Preparing changes...")

    if not analysis.strip():
        console.print("[bold green][WRITER][/bold green] ⚠️  No analysis received")
        return {}

    prompt_lower = user_prompt.lower()

    if any(w in prompt_lower for w in ["test", "junit", "unit test", "test case"]):
        task_instruction = """Generate COMPLETE test cases.
- Cover every method and class
- Include positive, negative and edge cases
- Use proper test framework imports
- Return ONLY the complete test file content"""

    elif any(w in prompt_lower for w in ["fix", "bug", "error", "issue", "solve"]):
        task_instruction = """Fix ALL bugs and issues found in the analysis.
- Apply every fix mentioned in the analysis
- Keep the same structure and class names
- Return ONLY the complete fixed file content"""

    elif any(w in prompt_lower for w in ["refactor", "clean", "improve", "optimize"]):
        task_instruction = """Refactor the code based on the analysis.
- Improve code quality and structure
- Follow best practices
- Return ONLY the complete refactored file content"""

    elif new_file or any(w in prompt_lower for w in ["generate", "create", "build", "write", "add"]):
        task_instruction = """Generate the requested code based on the analysis and plan.
- Write clean, well-commented code
- Follow best practices
- Return ONLY the complete file content"""

    else:
        task_instruction = """Based on the analysis, plan, and user request apply the best changes.
- Return ONLY the complete updated file content"""

    console.print("[bold green][WRITER][/bold green] → Writing solution...")

    code = ask_model(
        prompt=f"""{task_instruction}

Plan:
{plan[:1000] if plan else "No plan provided"}

Analysis:
{analysis[:2000]}

User Request: {user_prompt}

Return ONLY the complete file content. No explanations. No markdown backticks.""",
        system="""You are an expert code writer for HDFC_AI coding assistant.
Write clean, complete, production-ready code.
Follow the task instruction strictly.
Return only the raw file content — no explanations, no markdown fences."""
    )

    # Clean markdown backticks if model adds them
    code = code.strip()
    if code.startswith("```"):
        code = "\n".join(code.split("\n")[1:])
    if code.endswith("```"):
        code = "\n".join(code.split("\n")[:-1])
    code = code.strip()

    console.print("[bold green][WRITER][/bold green] ✅ Changes ready")
    return code