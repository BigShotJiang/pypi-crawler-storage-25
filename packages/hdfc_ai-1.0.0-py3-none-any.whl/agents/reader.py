import os
from rich.console import Console
from model_loader import ask_model

console = Console()

SUPPORTED = (
    ".py", ".java", ".js", ".ts",
    ".cpp", ".c", ".cs", ".go",
    ".rs", ".md", ".txt", ".html", ".css"
)


def _read_all_files(folder: str) -> dict:
    """Recursively reads all supported files from folder and subfolders."""
    files_content = {}
    for root, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if not d.startswith(".")
                   and d not in ("__pycache__", "node_modules", "target",
                                 "build", "venv", ".venv", "output")]
        for filename in files:
            if filename.endswith(SUPPORTED):
                filepath = os.path.join(root, filename)
                rel_path = os.path.relpath(filepath, folder)
                try:
                    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read()
                        files_content[rel_path] = content
                        console.print(f"[bold cyan][READER][/bold cyan] → Loaded: {rel_path} ({len(content.splitlines())} lines)")
                except Exception as e:
                    console.print(f"[bold cyan][READER][/bold cyan] ⚠️ Could not read {rel_path}: {e}")
    return files_content


def run_reader(input_path: str = "."):
    console.print("\n[bold cyan][READER][/bold cyan] Starting file scan...")

    if not os.path.exists(input_path):
        console.print(f"[bold cyan][READER][/bold cyan] ⚠️ Path not found: {input_path}")
        return "", ""

    files_content = _read_all_files(input_path)

    if not files_content:
        console.print("[bold cyan][READER][/bold cyan] ⚠️ No readable files found")
        return "", ""

    # Combine all files into one context string
    all_content = ""
    for rel_path, content in files_content.items():
        all_content += f"\n\n--- FILE: {rel_path} ---\n{content}"

    console.print(f"[bold cyan][READER][/bold cyan] ✅ Done — {len(files_content)} files loaded")

    # Summarize project
    summary = ask_model(
        prompt=f"Project files and code:\n{all_content[:4000]}\n\nSummarize the project structure clearly.",
        system="You are a code reader agent for HDFC_AI. Summarize the structure and purpose of the project clearly and concisely."
    )

    return all_content, summary


def read_single_file(filepath: str) -> str:
    """Read a single file and return its content."""
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        console.print(f"[bold cyan][READER][/bold cyan] → Loaded: {filepath} ({len(content.splitlines())} lines)")
        return content
    except Exception as e:
        console.print(f"[bold cyan][READER][/bold cyan] ⚠️ Could not read {filepath}: {e}")
        return ""