import os
import json
import platform

# ── Config location (works on Windows, Mac, Linux) ────────
CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".hdfc_ai")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")


def get_os() -> str:
    """Detect current operating system."""
    system = platform.system().lower()
    if system == "windows":
        return "windows"
    elif system == "darwin":
        return "mac"
    else:
        return "linux"


def config_exists() -> bool:
    return os.path.exists(CONFIG_FILE)


def save_config(model_path: str, mode: str = "local", server_url: str = "http://localhost:8080"):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    config = {
        "model_path": model_path,
        "mode": mode,
        "server_url": server_url,
        "os": get_os()
    }
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

    # ── Secure the config file — no other user can read it ──
    if get_os() != "windows":
        os.chmod(CONFIG_FILE, 0o600)  # owner read/write only

    print(f"✅ Config saved to {CONFIG_FILE}")


def load_config() -> dict:
    if not config_exists():
        run_setup_wizard()
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)


def reset_config():
    """Delete config — triggers setup wizard on next run."""
    if os.path.exists(CONFIG_FILE):
        os.remove(CONFIG_FILE)
        print("✅ Config reset. Run hdfc_ai again to set up.")


def run_setup_wizard():
    os_name = get_os()

    print("\n🔧 HDFC_AI First Time Setup")
    print("━" * 40)
    print(f"Detected OS: {os_name.upper()}")
    print("You need a local GGUF model file.")
    print("Download from: https://huggingface.co/models?search=gguf\n")

    # Show example path based on OS
    if os_name == "windows":
        example = r"C:\Users\you\models\gemma.gguf"
    elif os_name == "mac":
        example = "/Users/you/models/gemma.gguf"
    else:
        example = "/home/you/models/gemma.gguf"

    print(f"Example path: {example}\n")

    model_path = input("📁 Enter your model path: ").strip()
    while not os.path.exists(model_path):
        print(f"❌ File not found: {model_path}")
        model_path = input("📁 Enter your model path: ").strip()

    server_url = input("🌐 Server URL (press Enter for default http://localhost:8080): ").strip()
    if not server_url:
        server_url = "http://localhost:8080"

    save_config(model_path=model_path, mode="local", server_url=server_url)
    print("\n✅ Setup complete! Starting HDFC_AI...\n")