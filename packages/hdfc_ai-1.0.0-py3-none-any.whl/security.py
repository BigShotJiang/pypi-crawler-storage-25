import hashlib
import os
import json
from pathlib import Path

CHECKSUM_FILE = os.path.join(os.path.expanduser("~"), ".hdfc_ai", "checksums.json")


def calculate_checksum(filepath: str) -> str:
    """Calculate SHA256 checksum of a file."""
    sha256 = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def generate_checksums(project_dir: str = ".") -> dict:
    """Generate checksums for all source files."""
    checksums = {}
    for root, dirs, files in os.walk(project_dir):
        dirs[:] = [d for d in dirs if not d.startswith(".")
                   and d not in ("__pycache__", "node_modules", "venv", ".venv", "dist", "build")]
        for f in files:
            if f.endswith((".py", ".toml", ".txt")):
                filepath = os.path.join(root, f)
                rel_path = os.path.relpath(filepath, project_dir)
                checksums[rel_path] = calculate_checksum(filepath)
    return checksums


def save_checksums(checksums: dict):
    """Save checksums to config directory."""
    os.makedirs(os.path.dirname(CHECKSUM_FILE), exist_ok=True)
    with open(CHECKSUM_FILE, "w") as f:
        json.dump(checksums, f, indent=2)

    # Secure on Mac/Linux
    import platform
    if platform.system().lower() != "windows":
        os.chmod(CHECKSUM_FILE, 0o600)


def verify_checksums(project_dir: str = ".") -> tuple[bool, list]:
    """
    Verify current files match saved checksums.
    Returns (all_ok, list_of_changed_files)
    """
    if not os.path.exists(CHECKSUM_FILE):
        return True, []

    with open(CHECKSUM_FILE, "r") as f:
        saved = json.load(f)

    current = generate_checksums(project_dir)
    changed = []

    for filepath, checksum in saved.items():
        if filepath not in current:
            changed.append(f"MISSING: {filepath}")
        elif current[filepath] != checksum:
            changed.append(f"MODIFIED: {filepath}")

    return len(changed) == 0, changed


def print_checksum_report():
    """Print SHA256 of all source files for public verification."""
    checksums = generate_checksums(".")
    print("\n🔐 HDFC_AI File Checksums (SHA256)")
    print("━" * 60)
    for filepath, checksum in checksums.items():
        print(f"{checksum}  {filepath}")
    print("━" * 60)
    print("Compare these with official checksums at your download source.\n")