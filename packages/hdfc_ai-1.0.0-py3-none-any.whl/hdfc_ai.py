#!/usr/bin/env python3
import sys
import os

# Add project root to path so agents and model_loader can be found
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import main

if __name__ == "__main__":
    main()