// Hand-written TS types mirroring the canonical JSON Schemas under
// ../src/augur_schema/json/. Keep these in sync; the Python loader is the
// authoritative validator. Codegen-from-JSON-schema lands later (issue #3
// follow-up) when the viewer needs full structural validation.

export const SCHEMA_VERSION = "0.1" as const;

export type CaptureMode =
  | "off"
  | "metadata"
  | "trace"
  | "screenshots"
  | "video"
  | "model_io"
  | "dispatch"
  | "replay"
  | "full";

export type CoordinateSpace =
  | "viewport_css_px"
  | "device_px"
  | "screenshot_px"
  | "dom_client_rect";

export type Provenance =
  | "screenshot"
  | "dom"
  | "human_override"
  | "replay_candidate"
  | "diagnostic";

export type RunStatus =
  | "running"
  | "succeeded"
  | "failed"
  | "cancelled"
  | "halted";

export type StepStatus =
  | "pending"
  | "running"
  | "succeeded"
  | "failed"
  | "skipped"
  | "recovered";

export type VerdictStatus =
  | "passed"
  | "failed"
  | "recoverable"
  | "skipped"
  | "unknown";

export interface ClientInfo {
  name: string;
  version?: string;
  git_sha?: string;
}

export interface Observation {
  artifact: string;
  media_type: "image/png" | "image/jpeg" | "image/webp";
  width: number;
  height: number;
  coordinate_space: CoordinateSpace;
  viewport?: { width: number; height: number; device_scale_factor?: number };
  url?: string;
  title?: string;
  scroll?: { x: number; y: number };
  hashes?: { sha256?: string; phash_64?: string };
  redaction?: {
    applied: boolean;
    policy_id?: string;
    regions?: Array<{ x1: number; y1: number; x2: number; y2: number; label?: string }>;
  };
  missing?: boolean;
}

export interface Action {
  type: string;
  params?: Record<string, unknown>;
  coordinate_space?: CoordinateSpace;
  dispatch_backend?: string;
}

export interface Grounding {
  provider: string;
  target_label?: string;
  coordinates?: { x: number; y: number };
  confidence?: number;
  evidence?: string;
  provenance: Provenance;
}

export interface Verdict {
  status: VerdictStatus;
  reason?: string;
  evidence_refs?: string[];
}

export interface RecoveryDecision {
  type:
    | "retry"
    | "alternate_grounding"
    | "skip"
    | "halt"
    | "replan"
    | "human_handoff"
    | "none";
  reason?: string;
  attempt?: number;
}

export interface StepTrace {
  step_id: string;
  step_index: number;
  intent?: string;
  step_type: string;
  required?: boolean;
  status: StepStatus;
  failure_class?: string;
  started_at: string;
  ended_at?: string | null;
  duration_ms?: number | null;
  observation_pre?: string | null;
  observation_post?: string | null;
  action?: Action;
  grounding?: Grounding;
  verdict?: Verdict;
  recovery_decision?: RecoveryDecision | null;
  events?: string[];
  logs?: string[];
}

export interface DebugSession {
  schema_version: string;
  debug_session_id: string;
  run_id: string;
  client: ClientInfo;
  capture_mode: CaptureMode;
  started_at: string;
  ended_at?: string | null;
  status: RunStatus;
  artifact_root?: string;
  trace_uri?: string;
  live?: {
    status_url?: string;
    video_url?: string;
    reasoning_url?: string;
  } | null;
  tags?: Record<string, string>;
}

export interface BundleManifest {
  schema_version: string;
  bundle_format: "augur-bundle";
  run_id: string;
  debug_session_id: string;
  client: ClientInfo;
  capture_mode: CaptureMode;
  created_at: string;
  redaction?: { policy_id: string; applied?: boolean };
  trace: "trace.json";
  step_count: number;
  paths: {
    steps: "steps/";
    screenshots: "screenshots/";
    crops?: "crops/";
    diffs?: "diffs/";
    events: "events/";
    logs: "logs/";
    replay?: "replay/";
    diagnostics?: "diagnostics/";
  };
  signatures?: Record<string, string>;
  missing?: string[];
}

export interface BundleTrace {
  session: DebugSession;
  steps: StepTrace[];
}
