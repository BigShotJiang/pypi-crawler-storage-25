# augur-schema changelog

## 0.2.1 (2026-05-23)

### Additive (back-compat) — causal attribution

- **`captured_versions.schema.json` (new)**: shared definition for the
  input-axis versions in effect when a step or fixture was captured.
  Records `model`, `prompt`, `prompt_hash` (new), `tool_descriptions_hash`
  (new), `env_fingerprint_ref` (new placeholder for primitive #10),
  `code_git_sha`, `grounder`. All fields optional — producers stamp what
  they know. Per SPEC §2.1 primitive #3 (causal attribution).
- `step_trace.schema.json`: new optional `captured_versions` field
  referencing the shared schema. Lets producers stamp per-step which
  model / prompt / tool descriptions / env / code / grounder were in
  effect, so cohort-level regression analysis can attribute outcome
  shifts to whichever axis moved. Closes the schema half of
  `mercurialsolo/augur#88` and `mercurialsolo/augur-sdk#10`.
- `replay_fixture.schema.json`: `captured_versions` field swapped from
  an inline definition to a `$ref` against the shared schema. Existing
  fixtures continue to validate (the shared schema is a superset of
  the original four fields).

## 0.2.0 (2026-05-23)

First standalone published release. Establishes `augur-schema` as a
PyPI + npm package consumable by external CUA adapter authors. Rolls up
all additive changes since `0.1.0` (previously tracked as unreleased
`0.1.1` and `0.1.2`).

### Packaging

- Published to PyPI as `augur-schema` via Trusted Publisher OIDC from the
  platform repo. Closes #96.
- Published to npm as `@augur/schema` in lockstep with the Python version.
- Schema versioning policy documented in `VERSIONING.md` — semver, breaking
  changes allowed across `0.x` minors, additive changes bump patch.
- `CHANGELOG.md` discipline enforced in CI on every schema-touching PR.

### Additive (back-compat) — capture-mode

- `step_trace.schema.json`: new optional `capture_mode` field
  (per-step override of the manifest's capture mode). Lets producers
  upgrade or downgrade the active capture mode mid-run (e.g. switch
  from `metadata` to `screenshots` after the first failed verifier
  check). Absence inherits the manifest mode. Closes #36.

### Additive (back-compat) — training-data substrate

- **`modelio.schema.json` (new)**: canonical record shape for one
  model call's full input + output. Loaded under short name
  `modelio`. Designed to be stored at
  `modelio/<step_index:04d>-<layer>-<seq>.json`. Closes #56.
- `step_trace.schema.json`: new optional `costs` object
  (total_usd, model_usd, gpu_usd, proxy_usd, tokens_in, tokens_out,
  cache_hit_tokens). Closes part of #58.
- `step_trace.schema.json`: new optional `latency` object
  (planner_ms, grounding_ms, dispatch_ms, verifier_ms, recovery_ms,
  total_ms). Closes part of #58.
- `step_trace.schema.json` → `verdict`: new optional `score` (0..1),
  `score_components` (open object), `comparator` (enum:
  verifier|model-judge|exact-match|human). Closes #59.
- `debug_session.schema.json`: new optional `costs` object with the
  same shape as the step-level one. Run-level rollup. Closes part of #58.

## 0.1.0 (2026-05-19)

Initial schema package. Records:

- `manifest.schema.json` — bundle envelope.
- `trace.schema.json` — combined session + steps document.
- `debug_session.schema.json` — top-level run record.
- `step_trace.schema.json` — one step.
- `observation.schema.json` — screenshot + viewport metadata.
- `decision_event.schema.json` — planner / verifier / recovery decisions.
- `replay_fixture.schema.json` — replay seed.
- `diagnostic_finding.schema.json` — output of the diagnostic rules engine.

Enums:

- `capture_mode.schema.json`
- `coordinate_space.schema.json`
- `provenance.schema.json`
- `failure_class.schema.json` (open string with examples)

Sample bundle: `examples/sample-bundle/` (5 steps, exercises every record).

Per `docs/versioning.md`, breaking changes are allowed across `0.x` minors.
