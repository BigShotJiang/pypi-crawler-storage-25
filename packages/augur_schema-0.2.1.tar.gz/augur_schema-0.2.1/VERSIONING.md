# augur-schema versioning policy

This package is the canonical contract between Augur producers (the SDK, third-party
CUA adapters) and Augur consumers (the server, viewer, CLI, diagnostic rule packs).
Stability of the schema directly affects the cost of upgrading either side, so
versioning is treated as a load-bearing decision, not a release-time afterthought.

## Semver discipline

The package follows [semver](https://semver.org/) with one caveat for the pre-1.0
phase, consistent with semver §4.

- **Pre-1.0** (current): a **minor** bump (`0.x.0 → 0.{x+1}.0`) is allowed to
  contain breaking changes. A **patch** bump (`0.x.y → 0.x.{y+1}`) is reserved for
  additive, backward-compatible changes.
- **Post-1.0**: standard semver. Breaking changes require a **major** bump
  (`x.y.z → {x+1}.0.0`). Additive changes bump minor.

The Python package (`augur-schema` on PyPI) and the TypeScript package
(`@augur/schema` on npm) always carry the **same version number** and ship from the
same git tag (`schema-vX.Y.Z`). Pinning one is equivalent to pinning the other.

## What counts as breaking

Breaking, in either direction:

- **Removed field** on any record (producers depending on emitting it break;
  consumers depending on reading it break).
- **Type narrowing** on an existing field (e.g. `string → enum`, `number → integer`).
- **Required-field addition** to an existing record (producers without it break
  validation).
- **Required-field downgrade-then-removal** (counts as removal).
- **Semantic change** to an existing field's meaning, even if the type is
  unchanged (e.g. `costs.total_usd` changing from "step cost" to "cumulative
  cost"). When in doubt, treat semantic changes as breaking.
- **Enum variant removal**.
- **Renaming** a record, a field, or an enum variant. Use deprecation, ship the
  new name as additive, then remove the old in a later breaking bump.
- **Coordinate-space or unit changes** on numeric fields.

## What counts as additive

Additive, backward-compatible:

- **New optional field** on an existing record.
- **New enum variant** in an open enum (i.e. one documented as accepting
  unknown values for forward-compatibility — most Augur enums are open).
- **New schema file** (a wholly new record type).
- **Loosening a numeric range** (e.g. `0..1 → 0..2`).
- **Loosening a required field to optional**.

Additive changes still get a CHANGELOG entry — the policy is "every PR that
touches `packages/schema/src/augur_schema/json/` updates `CHANGELOG.md`",
enforced in CI.

## Release flow

1. Schema PR lands on `main` with the change + CHANGELOG entry.
2. When ready to release, bump version in lockstep:
   - `packages/schema/pyproject.toml`
   - `packages/schema/package.json`
3. Tag: `schema-vX.Y.Z`. Push the tag.
4. `.github/workflows/release-schema.yml` runs: validates tag/CHANGELOG/pyproject
   coherence, builds, publishes to PyPI via Trusted Publisher OIDC, creates a
   GitHub Release with the CHANGELOG entry as the body.

The release workflow refuses to publish if:

- the tag version does not match both `pyproject.toml` and `package.json`;
- the CHANGELOG has no entry for the tag version;
- any schema fails to parse;
- the sample bundle does not validate against the current schemas.

## Pinning guidance for consumers

- **Python**: `augur-schema>=0.2,<0.3` until 1.0. Tight bounds are appropriate
  during pre-1.0 because breaking changes ship in minor bumps.
- **TypeScript**: `"@augur/schema": "^0.2.0"` works under npm semver semantics
  for pre-1.0 (npm treats `^0.x.y` as `>=0.x.y <0.x+1.0`), giving you patch
  updates without surprise breakage.
- **Lock files**: commit `uv.lock` / `pnpm-lock.yaml` in consumer repos. Schema
  upgrades become explicit PRs that can be reviewed.

## Stability promise

- **0.x**: pre-stable. Expect a small number of breaking changes per quarter
  while the SDK side fills out the Sentry-for-CUA primitive set (see SPEC §2.1).
- **1.0**: target after the schema additions for primitives #3, #5, #9, and #10
  have shipped and been exercised by at least one non-Mantis adapter.
- **Post-1.0**: breaking changes only on major bumps. Deprecation cycles of at
  least one minor before removal.
