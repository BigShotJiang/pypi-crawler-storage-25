# augur-schema

Canonical JSON Schemas for the Augur CUA debugger.

`json/` is the source of truth. Python and TypeScript types are hand-written mirrors
in `src/augur_schema/` and `ts/` — kept in sync by `tests/test_schema_roundtrip.py`.

Records:

- `manifest.schema.json` — bundle envelope
- `debug_session.schema.json` — top-level run/session record
- `step_trace.schema.json` — one step
- `observation.schema.json` — screenshot + viewport metadata
- `decision_event.schema.json` — ordered planner/verifier/recovery decisions
- `replay_fixture.schema.json` — replay seed for a step
- `diagnostic_finding.schema.json` — output of the diagnostic rules engine

Enums (separate files so they can be `$ref`d):

- `coordinate_space.schema.json`
- `provenance.schema.json`
- `capture_mode.schema.json`
- `failure_class.schema.json`

Schema version: see [`docs/versioning.md`](../../docs/versioning.md). Current: `0.1`.
