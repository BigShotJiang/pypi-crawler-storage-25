"""Augur schema package.

Canonical JSON Schemas live under `augur_schema/json/`. This module exposes
loaders and a small validation helper.
"""

from augur_schema._loader import (
    SCHEMA_VERSION,
    SchemaError,
    list_schemas,
    load_schema,
    schemas_dir,
    validator_for,
)

__all__ = [
    "SCHEMA_VERSION",
    "SchemaError",
    "list_schemas",
    "load_schema",
    "schemas_dir",
    "validator_for",
]
