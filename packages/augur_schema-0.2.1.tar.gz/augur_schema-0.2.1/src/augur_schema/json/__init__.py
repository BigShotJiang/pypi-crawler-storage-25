"""JSON Schemas (data). Imported via importlib.resources, not as Python."""
