import subprocess
import pyperclip


def inject_text(text: str):
    pyperclip.copy(text)
    subprocess.run(
        ["osascript", "-e", 'tell application "System Events" to keystroke "v" using {command down}'],
        check=True,
        capture_output=True,
    )
