import os
import platform

# Shorthand names exposed to the CLI and --list-models
MODELS = ["tiny", "base", "small", "medium", "large"]
DEFAULT_MODEL = "small"

# Backend-specific model identifiers
_MLX_MODELS = {
    "tiny":   "mlx-community/whisper-tiny.en-mlx-q4",
    "base":   "mlx-community/whisper-base.en-mlx-q4",
    "small":  "mlx-community/whisper-small.en-mlx-q4",
    "medium": "mlx-community/whisper-medium.en-mlx-q4",
    "large":  "mlx-community/whisper-large-v3-mlx-q4",
}

_FASTER_MODELS = {
    "tiny":   "tiny.en",
    "base":   "base.en",
    "small":  "small.en",
    "medium": "medium.en",
    "large":  "large-v3",
}


def _is_apple_silicon() -> bool:
    return platform.system() == "Darwin" and platform.machine() == "arm64"


def _resolve_model(shorthand: str) -> tuple[str, str]:
    """Return (backend, model_id) for the given shorthand."""
    name = shorthand if shorthand in _MLX_MODELS else DEFAULT_MODEL

    if _is_apple_silicon():
        try:
            import mlx_whisper  # noqa: F401
            return "mlx", _MLX_MODELS[name]
        except ImportError:
            pass

    return "faster", _FASTER_MODELS[name]


class Transcriber:
    def __init__(self, model: str = DEFAULT_MODEL):
        env_override = os.environ.get("LOCALFLOW_MODEL")
        shorthand = env_override if env_override else model
        self._backend, self._model_id = _resolve_model(shorthand)
        self._loaded = None

    def _load(self):
        if self._loaded is not None:
            return

        if self._backend == "mlx":
            import mlx_whisper
            self._loaded = mlx_whisper
        else:
            from faster_whisper import WhisperModel
            self._loaded = WhisperModel(
                self._model_id,
                device="cpu",
                compute_type="int8",
            )

    def transcribe_streaming(self, path: str):
        """Yield transcript text as each segment becomes available.

        faster-whisper returns a lazy generator — segments are yielded as
        transcription progresses (well above real-time speed), so callers
        can inject each chunk immediately rather than waiting for the full
        result.  mlx-whisper processes in one shot but is fast enough on
        Apple Silicon that a single yield is fine.
        """
        self._load()

        if self._backend == "mlx":
            result = self._loaded.transcribe(path, path_or_hf_repo=self._model_id)
            text = result["text"].strip()
            if text:
                yield text
        else:
            segments, _ = self._loaded.transcribe(
                path,
                beam_size=1,       # greedy decoding — lower latency, negligible quality loss
                vad_filter=True,   # skip silent gaps between segments
            )
            for seg in segments:
                if seg.text.strip():
                    yield seg.text
