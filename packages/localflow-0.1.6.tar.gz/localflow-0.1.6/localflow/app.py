import threading
import AppKit
import objc

from .popover import LocalFlowPopover
from .recorder import Recorder
from .transcriber import Transcriber, DEFAULT_MODEL
from .hotkey import HotkeyListener
from .injector import inject_text
from .icon import make_mic_icon


class AppDelegate(AppKit.NSObject):
    def applicationDidFinishLaunching_(self, notif):
        AppKit.NSApp.setActivationPolicy_(AppKit.NSApplicationActivationPolicyAccessory)

        self.status_item = AppKit.NSStatusBar.systemStatusBar().statusItemWithLength_(
            AppKit.NSVariableStatusItemLength
        )
        btn = self.status_item.button()
        btn.setImage_(make_mic_icon())
        btn.setToolTip_("LocalFlow — Hold ⌘⌥ and start speaking")
        btn.setAction_("togglePopover:")
        btn.setTarget_(self)

        self._model = getattr(self, "_model", DEFAULT_MODEL)
        self.popover = LocalFlowPopover.alloc().init()
        self.popover.set_delegate(self)
        self.recorder = Recorder()
        self.transcriber = Transcriber(model=self._model)
        self.hotkey = HotkeyListener(on_hold=self.start_recording, on_release=self.stop_recording)
        self.enabled = False

    def togglePopover_(self, sender):
        if self.popover.is_shown():
            self.popover.performClose_(sender)
        else:
            AppKit.NSApp.activateIgnoringOtherApps_(True)
            self.popover.showRelativeToRect_ofView_preferredEdge_(
                self.status_item.button().bounds(),
                self.status_item.button(),
                AppKit.NSMinYEdge,
            )

    @objc.python_method
    def set_enabled(self, enabled: bool):
        self.enabled = enabled
        if enabled:
            self.hotkey.start()
            self.popover.set_status("Enabled — Hold ⌘⌥ and start speaking")
        else:
            self.hotkey.stop()
            self.popover.set_status("Disabled")

    @objc.python_method
    def start_recording(self):
        if not self.enabled:
            return

        def _start():
            self.recorder.start()
            self.popover.set_status("Recording…")

        AppKit.NSOperationQueue.mainQueue().addOperationWithBlock_(_start)

    @objc.python_method
    def stop_recording(self):
        if not self.enabled:
            return

        # Stop the recorder on the main queue so it's guaranteed to run after
        # start_recording's _start block (main queue is FIFO). Only then hand
        # off the WAV path to a background thread for transcription.
        def _stop_on_main():
            self.popover.set_status("Transcribing…")
            path = self.recorder.stop()

            def _transcribe():
                try:
                    if path is None:
                        return
                    for chunk in self.transcriber.transcribe_streaming(path):
                        inject_text(chunk)
                except Exception:
                    import traceback
                    traceback.print_exc()

                def _done():
                    self.popover.set_status("Enabled — Hold ⌘⌥ and start speaking")

                AppKit.NSOperationQueue.mainQueue().addOperationWithBlock_(_done)

            threading.Thread(target=_transcribe, daemon=True).start()

        AppKit.NSOperationQueue.mainQueue().addOperationWithBlock_(_stop_on_main)


def run(model: str = DEFAULT_MODEL):
    app = AppKit.NSApplication.sharedApplication()
    delegate = AppDelegate.alloc().init()
    delegate._model = model
    app.setDelegate_(delegate)
    app.run()
