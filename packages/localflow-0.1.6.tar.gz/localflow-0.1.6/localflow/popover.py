import AppKit
import objc

_W, _H = 260, 200


class PopoverViewController(AppKit.NSViewController):
    def loadView(self):
        view = AppKit.NSView.alloc().initWithFrame_(AppKit.NSMakeRect(0, 0, _W, _H))
        self.setView_(view)

        # Title
        title = AppKit.NSTextField.labelWithString_("LocalFlow")
        title.setFont_(AppKit.NSFont.boldSystemFontOfSize_(14))
        title.setAlignment_(AppKit.NSTextAlignmentCenter)
        title.setFrame_(AppKit.NSMakeRect(0, 172, _W, 20))
        view.addSubview_(title)

        sep1 = AppKit.NSBox.alloc().initWithFrame_(AppKit.NSMakeRect(16, 163, _W - 32, 1))
        sep1.setBoxType_(AppKit.NSBoxSeparator)
        view.addSubview_(sep1)

        # Toggle
        self._switch = AppKit.NSSwitch.alloc().initWithFrame_(
            AppKit.NSMakeRect((_W - 51) / 2, 118, 51, 31)
        )
        self._switch.setState_(AppKit.NSControlStateValueOff)
        self._switch.setTarget_(self)
        self._switch.setAction_("toggleChanged:")
        view.addSubview_(self._switch)

        # State label (Disabled / Enabled / Recording… / Transcribing…)
        self._state_label = AppKit.NSTextField.labelWithString_("Disabled")
        self._state_label.setFont_(AppKit.NSFont.systemFontOfSize_(11))
        self._state_label.setTextColor_(AppKit.NSColor.secondaryLabelColor())
        self._state_label.setAlignment_(AppKit.NSTextAlignmentCenter)
        self._state_label.setFrame_(AppKit.NSMakeRect(0, 98, _W, 16))
        view.addSubview_(self._state_label)

        sep2 = AppKit.NSBox.alloc().initWithFrame_(AppKit.NSMakeRect(16, 84, _W - 32, 1))
        sep2.setBoxType_(AppKit.NSBoxSeparator)
        view.addSubview_(sep2)

        # Tagline
        tagline = AppKit.NSTextField.wrappingLabelWithString_(
            "Not Always Listening. Hold ⌘⌥ and start speaking for your personal no bs typewriter."
        )
        tagline.setFont_(AppKit.NSFont.systemFontOfSize_(11))
        tagline.setTextColor_(AppKit.NSColor.secondaryLabelColor())
        tagline.setAlignment_(AppKit.NSTextAlignmentCenter)
        tagline.setFrame_(AppKit.NSMakeRect(16, 8, _W - 32, 70))
        view.addSubview_(tagline)

        self._delegate = None

    @objc.python_method
    def set_delegate(self, delegate):
        self._delegate = delegate

    @objc.python_method
    def set_status(self, text: str):
        def _update():
            self._state_label.setStringValue_(text)
        AppKit.NSOperationQueue.mainQueue().addOperationWithBlock_(_update)

    def toggleChanged_(self, sender):
        enabled = sender.state() == AppKit.NSControlStateValueOn
        if self._delegate is not None:
            self._delegate.set_enabled(enabled)


class LocalFlowPopover(AppKit.NSPopover):
    def init(self):
        self = objc.super(LocalFlowPopover, self).init()
        if self is None:
            return None
        self._vc = PopoverViewController.alloc().init()
        self._vc.loadView()
        self.setContentViewController_(self._vc)
        self.setBehavior_(AppKit.NSPopoverBehaviorTransient)
        self.setAppearance_(
            AppKit.NSAppearance.appearanceNamed_(AppKit.NSAppearanceNameVibrantDark)
        )
        self.setContentSize_(AppKit.NSMakeSize(_W, _H))
        return self

    @objc.python_method
    def set_delegate(self, delegate):
        self._vc.set_delegate(delegate)

    @objc.python_method
    def set_status(self, text: str):
        self._vc.set_status(text)

    @objc.python_method
    def is_shown(self):
        return bool(self.isShown())
