import AppKit


def make_mic_icon() -> AppKit.NSImage:
    # NSImageSymbolConfiguration lets us set a consistent point size and weight
    # so the symbol sits at the right visual weight in the menubar.
    config = AppKit.NSImageSymbolConfiguration.configurationWithPointSize_weight_scale_(
        16, AppKit.NSFontWeightMedium, AppKit.NSImageSymbolScaleMedium
    )
    image = (
        AppKit.NSImage
        .imageWithSystemSymbolName_accessibilityDescription_("waveform.and.mic", "LocalFlow")
        .imageWithSymbolConfiguration_(config)
    )
    image.setTemplate_(True)  # lets macOS tint for light/dark mode and highlight state
    return image
