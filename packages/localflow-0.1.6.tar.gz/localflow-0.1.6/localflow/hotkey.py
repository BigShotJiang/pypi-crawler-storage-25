import threading
import AppKit

_CMD_OPT = AppKit.NSEventModifierFlagCommand | AppKit.NSEventModifierFlagOption


class HotkeyListener:
    def __init__(self, on_hold, on_release):
        self._on_hold = on_hold
        self._on_release = on_release
        self._monitor = None
        self._handle_ref = None
        self._active = False
        self._lock = threading.Lock()
        self._enabled = threading.Event()

    def start(self):
        self._enabled.set()
        if self._monitor is not None:
            return

        def _handle(event):
            if not self._enabled.is_set():
                return
            flags = int(event.modifierFlags()) & _CMD_OPT
            with self._lock:
                if flags == _CMD_OPT and not self._active:
                    self._active = True
                    self._on_hold()
                elif flags != _CMD_OPT and self._active:
                    self._active = False
                    self._on_release()

        self._handle_ref = _handle  # prevent GC
        self._monitor = AppKit.NSEvent.addGlobalMonitorForEventsMatchingMask_handler_(
            AppKit.NSEventMaskFlagsChanged, _handle
        )

    def stop(self):
        self._enabled.clear()
        with self._lock:
            if self._active:
                self._active = False
                self._on_release()
        if self._monitor is not None:
            AppKit.NSEvent.removeMonitor_(self._monitor)
            self._monitor = None
            self._handle_ref = None
