import tempfile
import numpy as np
import sounddevice as sd
import soundfile as sf

SAMPLE_RATE = 16_000


class Recorder:
    def __init__(self):
        self._frames = []
        self._stream = None

    def start(self):
        self._frames = []
        self._stream = sd.InputStream(
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype="float32",
            callback=self._callback,
        )
        self._stream.start()

    def _callback(self, indata, frames, time, status):
        self._frames.append(indata.copy())

    def stop(self) -> str | None:
        if self._stream is not None:
            self._stream.stop()
            self._stream.close()
            self._stream = None

        if not self._frames:
            return None

        audio = np.concatenate(self._frames, axis=0)
        path = tempfile.mktemp(suffix=".wav")
        sf.write(path, audio, SAMPLE_RATE)
        return path
