import argparse
from .transcriber import MODELS, DEFAULT_MODEL, _is_apple_silicon, _MLX_MODELS, _FASTER_MODELS


def main():
    parser = argparse.ArgumentParser(description="LocalFlow — local speech-to-text menubar app")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Whisper model to use (default: small)")
    parser.add_argument("--list-models", action="store_true", help="List available models and exit")
    args = parser.parse_args()

    if args.list_models:
        backend_models = _MLX_MODELS if _is_apple_silicon() else _FASTER_MODELS
        backend_name = "mlx-whisper" if _is_apple_silicon() else "faster-whisper"
        print(f"Backend: {backend_name}\n")
        print(f"{'Name':<8}  {'Model ID'}")
        print("-" * 55)
        for name in MODELS:
            default_marker = " (default)" if name == DEFAULT_MODEL else ""
            print(f"{name:<8}  {backend_models[name]}{default_marker}")
        return

    if args.model not in MODELS:
        print(f"Unknown model '{args.model}'. Run --list-models to see available options.")
        raise SystemExit(1)

    from .app import run
    run(model=args.model)


if __name__ == "__main__":
    main()
