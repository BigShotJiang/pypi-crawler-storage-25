from __future__ import annotations

import importlib.metadata
import sys
from pathlib import Path

project = "uv-start"

# General configuration
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
    "myst_parser",
    "sphinx_autodoc_typehints",
    "sphinx_rtd_theme",
]

source_suffix = {
    ".rst": "restructuredtext",
    ".md": "markdown",
}

master_doc = "index"

# Add project root to sys.path so autodoc can find uv_start
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

# Version info
try:
    release = importlib.metadata.version("uv-start")
except importlib.metadata.PackageNotFoundError:
    release = "0.0.0"
version = release

html_theme = "sphinx_rtd_theme"
