from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class AntennaFieldPowerState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ANTENNA_FIELD_POWER_STATE_UNSPECIFIED: _ClassVar[AntennaFieldPowerState]
    ANTENNA_FIELD_POWER_STATE_OFF: _ClassVar[AntennaFieldPowerState]
    ANTENNA_FIELD_POWER_STATE_ON: _ClassVar[AntennaFieldPowerState]
ANTENNA_FIELD_POWER_STATE_UNSPECIFIED: AntennaFieldPowerState
ANTENNA_FIELD_POWER_STATE_OFF: AntennaFieldPowerState
ANTENNA_FIELD_POWER_STATE_ON: AntennaFieldPowerState
