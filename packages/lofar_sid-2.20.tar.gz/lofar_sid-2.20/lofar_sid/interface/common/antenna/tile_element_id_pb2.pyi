from lofar_sid.interface.common.antenna import antenna_id_pb2 as _antenna_id_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TileElementId(_message.Message):
    __slots__ = ("tile", "tile_element_index")
    TILE_FIELD_NUMBER: _ClassVar[int]
    TILE_ELEMENT_INDEX_FIELD_NUMBER: _ClassVar[int]
    tile: _antenna_id_pb2.AntennaId
    tile_element_index: int
    def __init__(self, tile: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ..., tile_element_index: _Optional[int] = ...) -> None: ...
