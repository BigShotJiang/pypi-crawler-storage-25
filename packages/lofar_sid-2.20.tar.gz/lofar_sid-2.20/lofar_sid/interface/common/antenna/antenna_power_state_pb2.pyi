from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class AntennaPowerState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ANTENNA_POWER_STATE_UNSPECIFIED: _ClassVar[AntennaPowerState]
    ANTENNA_POWER_STATE_OFF: _ClassVar[AntennaPowerState]
    ANTENNA_POWER_STATE_ON: _ClassVar[AntennaPowerState]
ANTENNA_POWER_STATE_UNSPECIFIED: AntennaPowerState
ANTENNA_POWER_STATE_OFF: AntennaPowerState
ANTENNA_POWER_STATE_ON: AntennaPowerState
