from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class AntennaStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ANTENNA_STATUS_UNSPECIFIED: _ClassVar[AntennaStatus]
    ANTENNA_STATUS_OK: _ClassVar[AntennaStatus]
    ANTENNA_STATUS_SUSPICIOUS: _ClassVar[AntennaStatus]
    ANTENNA_STATUS_BROKEN: _ClassVar[AntennaStatus]
    ANTENNA_STATUS_BEYOND_REPAIR: _ClassVar[AntennaStatus]
    ANTENNA_STATUS_NOT_AVAILABLE: _ClassVar[AntennaStatus]
ANTENNA_STATUS_UNSPECIFIED: AntennaStatus
ANTENNA_STATUS_OK: AntennaStatus
ANTENNA_STATUS_SUSPICIOUS: AntennaStatus
ANTENNA_STATUS_BROKEN: AntennaStatus
ANTENNA_STATUS_BEYOND_REPAIR: AntennaStatus
ANTENNA_STATUS_NOT_AVAILABLE: AntennaStatus
