from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class AntennaUsage(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ANTENNA_USAGE_UNSPECIFIED: _ClassVar[AntennaUsage]
    ANTENNA_USAGE_AUTO: _ClassVar[AntennaUsage]
    ANTENNA_USAGE_FORCE_ON: _ClassVar[AntennaUsage]
    ANTENNA_USAGE_FORCE_OFF: _ClassVar[AntennaUsage]
ANTENNA_USAGE_UNSPECIFIED: AntennaUsage
ANTENNA_USAGE_AUTO: AntennaUsage
ANTENNA_USAGE_FORCE_ON: AntennaUsage
ANTENNA_USAGE_FORCE_OFF: AntennaUsage
