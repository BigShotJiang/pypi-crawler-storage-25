from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class DumperId(_message.Message):
    __slots__ = ("dispatched_id",)
    DISPATCHED_ID_FIELD_NUMBER: _ClassVar[int]
    dispatched_id: str
    def __init__(self, dispatched_id: _Optional[str] = ...) -> None: ...
