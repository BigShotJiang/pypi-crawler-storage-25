import datetime

from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from lofar_sid.interface.common.antenna_field import antenna_field_id_pb2 as _antenna_field_id_pb2
from lofar_sid.interface.common.transient_buffer import transient_buffer_dumper_state_pb2 as _transient_buffer_dumper_state_pb2
from lofar_sid.interface.common.transient_buffer import transient_buffer_processing_state_pb2 as _transient_buffer_processing_state_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TransientBufferState(_message.Message):
    __slots__ = ("antenna_field", "processing_state", "recorded_first_timestamp", "recorded_last_timestamp", "recorded_time_interval", "dumper_state")
    ANTENNA_FIELD_FIELD_NUMBER: _ClassVar[int]
    PROCESSING_STATE_FIELD_NUMBER: _ClassVar[int]
    RECORDED_FIRST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    RECORDED_LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    RECORDED_TIME_INTERVAL_FIELD_NUMBER: _ClassVar[int]
    DUMPER_STATE_FIELD_NUMBER: _ClassVar[int]
    antenna_field: _antenna_field_id_pb2.AntennaFieldId
    processing_state: _transient_buffer_processing_state_pb2.TransientBufferProcessingState
    recorded_first_timestamp: _timestamp_pb2.Timestamp
    recorded_last_timestamp: _timestamp_pb2.Timestamp
    recorded_time_interval: _duration_pb2.Duration
    dumper_state: _transient_buffer_dumper_state_pb2.TransientBufferDumperState
    def __init__(self, antenna_field: _Optional[_Union[_antenna_field_id_pb2.AntennaFieldId, _Mapping]] = ..., processing_state: _Optional[_Union[_transient_buffer_processing_state_pb2.TransientBufferProcessingState, str]] = ..., recorded_first_timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., recorded_last_timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., recorded_time_interval: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., dumper_state: _Optional[_Union[_transient_buffer_dumper_state_pb2.TransientBufferDumperState, str]] = ...) -> None: ...
