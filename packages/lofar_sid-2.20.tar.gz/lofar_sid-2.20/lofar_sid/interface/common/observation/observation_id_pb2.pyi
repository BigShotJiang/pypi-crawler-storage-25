from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class ObservationId(_message.Message):
    __slots__ = ("observation_id",)
    OBSERVATION_ID_FIELD_NUMBER: _ClassVar[int]
    observation_id: int
    def __init__(self, observation_id: _Optional[int] = ...) -> None: ...
