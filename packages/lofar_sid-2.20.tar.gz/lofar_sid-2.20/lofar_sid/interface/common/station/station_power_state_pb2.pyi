from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class StationPowerState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    STATION_POWER_STATE_UNSPECIFIED: _ClassVar[StationPowerState]
    STATION_POWER_STATE_OFF: _ClassVar[StationPowerState]
    STATION_POWER_STATE_HIBERNATE: _ClassVar[StationPowerState]
    STATION_POWER_STATE_STANDBY: _ClassVar[StationPowerState]
    STATION_POWER_STATE_ON: _ClassVar[StationPowerState]
STATION_POWER_STATE_UNSPECIFIED: StationPowerState
STATION_POWER_STATE_OFF: StationPowerState
STATION_POWER_STATE_HIBERNATE: StationPowerState
STATION_POWER_STATE_STANDBY: StationPowerState
STATION_POWER_STATE_ON: StationPowerState
