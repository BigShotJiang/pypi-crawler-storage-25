from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class StationId(_message.Message):
    __slots__ = ("station_name",)
    STATION_NAME_FIELD_NUMBER: _ClassVar[int]
    station_name: str
    def __init__(self, station_name: _Optional[str] = ...) -> None: ...
