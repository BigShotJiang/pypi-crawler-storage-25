import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from lofar_sid.interface.common.antenna import antenna_id_pb2 as _antenna_id_pb2
from lofar_sid.interface.common.antenna import antenna_info_pb2 as _antenna_info_pb2
from lofar_sid.interface.common.antenna import antenna_status_pb2 as _antenna_status_pb2
from lofar_sid.interface.common.antenna_field import antenna_field_id_pb2 as _antenna_field_id_pb2
from lofar_sid.interface.common.station import station_id_pb2 as _station_id_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetAntennaInfoRequest(_message.Message):
    __slots__ = ("station", "antenna_field", "antenna", "timestamp", "antenna_statuses")
    STATION_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_FIELD_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_STATUSES_FIELD_NUMBER: _ClassVar[int]
    station: _station_id_pb2.StationId
    antenna_field: _antenna_field_id_pb2.AntennaFieldId
    antenna: _antenna_id_pb2.AntennaId
    timestamp: _timestamp_pb2.Timestamp
    antenna_statuses: _containers.RepeatedScalarFieldContainer[_antenna_status_pb2.AntennaStatus]
    def __init__(self, station: _Optional[_Union[_station_id_pb2.StationId, _Mapping]] = ..., antenna_field: _Optional[_Union[_antenna_field_id_pb2.AntennaFieldId, _Mapping]] = ..., antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., antenna_statuses: _Optional[_Iterable[_Union[_antenna_status_pb2.AntennaStatus, str]]] = ...) -> None: ...

class GetAntennaInfoResponse(_message.Message):
    __slots__ = ("timestamp", "antenna_info")
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_INFO_FIELD_NUMBER: _ClassVar[int]
    timestamp: _timestamp_pb2.Timestamp
    antenna_info: _antenna_info_pb2.AntennaInfo
    def __init__(self, timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., antenna_info: _Optional[_Union[_antenna_info_pb2.AntennaInfo, _Mapping]] = ...) -> None: ...
