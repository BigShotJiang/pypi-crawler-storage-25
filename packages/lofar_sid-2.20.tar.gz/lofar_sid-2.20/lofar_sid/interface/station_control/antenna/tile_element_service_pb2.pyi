from google.protobuf import empty_pb2 as _empty_pb2
from lofar_sid.interface.common.antenna import antenna_power_state_pb2 as _antenna_power_state_pb2
from lofar_sid.interface.common.antenna import tile_element_id_pb2 as _tile_element_id_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetTileElementPowerStateRequest(_message.Message):
    __slots__ = ("tile_element",)
    TILE_ELEMENT_FIELD_NUMBER: _ClassVar[int]
    tile_element: _tile_element_id_pb2.TileElementId
    def __init__(self, tile_element: _Optional[_Union[_tile_element_id_pb2.TileElementId, _Mapping]] = ...) -> None: ...

class GetTileElementPowerStateResponse(_message.Message):
    __slots__ = ("tile_element", "tile_element_power_state")
    TILE_ELEMENT_FIELD_NUMBER: _ClassVar[int]
    TILE_ELEMENT_POWER_STATE_FIELD_NUMBER: _ClassVar[int]
    tile_element: _tile_element_id_pb2.TileElementId
    tile_element_power_state: _antenna_power_state_pb2.AntennaPowerState
    def __init__(self, tile_element: _Optional[_Union[_tile_element_id_pb2.TileElementId, _Mapping]] = ..., tile_element_power_state: _Optional[_Union[_antenna_power_state_pb2.AntennaPowerState, str]] = ...) -> None: ...

class SetTileElementPowerStateRequest(_message.Message):
    __slots__ = ("tile_element", "tile_element_power_state")
    TILE_ELEMENT_FIELD_NUMBER: _ClassVar[int]
    TILE_ELEMENT_POWER_STATE_FIELD_NUMBER: _ClassVar[int]
    tile_element: _tile_element_id_pb2.TileElementId
    tile_element_power_state: _antenna_power_state_pb2.AntennaPowerState
    def __init__(self, tile_element: _Optional[_Union[_tile_element_id_pb2.TileElementId, _Mapping]] = ..., tile_element_power_state: _Optional[_Union[_antenna_power_state_pb2.AntennaPowerState, str]] = ...) -> None: ...
