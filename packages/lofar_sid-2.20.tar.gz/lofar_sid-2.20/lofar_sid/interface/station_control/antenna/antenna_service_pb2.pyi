from google.protobuf import empty_pb2 as _empty_pb2
from lofar_sid.interface.common.antenna import antenna_id_pb2 as _antenna_id_pb2
from lofar_sid.interface.common.antenna import antenna_power_state_pb2 as _antenna_power_state_pb2
from lofar_sid.interface.common.antenna import antenna_status_pb2 as _antenna_status_pb2
from lofar_sid.interface.common.antenna import antenna_usage_pb2 as _antenna_usage_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetAntennaStatusRequest(_message.Message):
    __slots__ = ("antenna",)
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    antenna: _antenna_id_pb2.AntennaId
    def __init__(self, antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ...) -> None: ...

class GetAntennaStatusResponse(_message.Message):
    __slots__ = ("antenna", "antenna_status")
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_STATUS_FIELD_NUMBER: _ClassVar[int]
    antenna: _antenna_id_pb2.AntennaId
    antenna_status: _antenna_status_pb2.AntennaStatus
    def __init__(self, antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ..., antenna_status: _Optional[_Union[_antenna_status_pb2.AntennaStatus, str]] = ...) -> None: ...

class SetAntennaStatusRequest(_message.Message):
    __slots__ = ("antenna", "antenna_status")
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_STATUS_FIELD_NUMBER: _ClassVar[int]
    antenna: _antenna_id_pb2.AntennaId
    antenna_status: _antenna_status_pb2.AntennaStatus
    def __init__(self, antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ..., antenna_status: _Optional[_Union[_antenna_status_pb2.AntennaStatus, str]] = ...) -> None: ...

class GetAntennaPowerStateRequest(_message.Message):
    __slots__ = ("antenna",)
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    antenna: _antenna_id_pb2.AntennaId
    def __init__(self, antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ...) -> None: ...

class GetAntennaPowerStateResponse(_message.Message):
    __slots__ = ("antenna", "antenna_power_state")
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_POWER_STATE_FIELD_NUMBER: _ClassVar[int]
    antenna: _antenna_id_pb2.AntennaId
    antenna_power_state: _antenna_power_state_pb2.AntennaPowerState
    def __init__(self, antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ..., antenna_power_state: _Optional[_Union[_antenna_power_state_pb2.AntennaPowerState, str]] = ...) -> None: ...

class SetAntennaPowerStateRequest(_message.Message):
    __slots__ = ("antenna", "antenna_power_state")
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_POWER_STATE_FIELD_NUMBER: _ClassVar[int]
    antenna: _antenna_id_pb2.AntennaId
    antenna_power_state: _antenna_power_state_pb2.AntennaPowerState
    def __init__(self, antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ..., antenna_power_state: _Optional[_Union[_antenna_power_state_pb2.AntennaPowerState, str]] = ...) -> None: ...

class GetAntennaUsageRequest(_message.Message):
    __slots__ = ("antenna",)
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    antenna: _antenna_id_pb2.AntennaId
    def __init__(self, antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ...) -> None: ...

class GetAntennaUsageResponse(_message.Message):
    __slots__ = ("antenna", "antenna_usage")
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_USAGE_FIELD_NUMBER: _ClassVar[int]
    antenna: _antenna_id_pb2.AntennaId
    antenna_usage: _antenna_usage_pb2.AntennaUsage
    def __init__(self, antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ..., antenna_usage: _Optional[_Union[_antenna_usage_pb2.AntennaUsage, str]] = ...) -> None: ...

class SetAntennaUsageRequest(_message.Message):
    __slots__ = ("antenna", "antenna_usage")
    ANTENNA_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_USAGE_FIELD_NUMBER: _ClassVar[int]
    antenna: _antenna_id_pb2.AntennaId
    antenna_usage: _antenna_usage_pb2.AntennaUsage
    def __init__(self, antenna: _Optional[_Union[_antenna_id_pb2.AntennaId, _Mapping]] = ..., antenna_usage: _Optional[_Union[_antenna_usage_pb2.AntennaUsage, str]] = ...) -> None: ...
