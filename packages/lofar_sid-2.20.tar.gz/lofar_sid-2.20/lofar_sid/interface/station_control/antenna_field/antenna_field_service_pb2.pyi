from google.protobuf import empty_pb2 as _empty_pb2
from lofar_sid.interface.common.antenna_field import antenna_field_id_pb2 as _antenna_field_id_pb2
from lofar_sid.interface.common.antenna_field import antenna_field_power_state_pb2 as _antenna_field_power_state_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetAntennaFieldPowerStateRequest(_message.Message):
    __slots__ = ("antenna_field",)
    ANTENNA_FIELD_FIELD_NUMBER: _ClassVar[int]
    antenna_field: _antenna_field_id_pb2.AntennaFieldId
    def __init__(self, antenna_field: _Optional[_Union[_antenna_field_id_pb2.AntennaFieldId, _Mapping]] = ...) -> None: ...

class GetAntennaFieldPowerStateResponse(_message.Message):
    __slots__ = ("antenna_field", "antenna_field_power_state")
    ANTENNA_FIELD_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_FIELD_POWER_STATE_FIELD_NUMBER: _ClassVar[int]
    antenna_field: _antenna_field_id_pb2.AntennaFieldId
    antenna_field_power_state: _antenna_field_power_state_pb2.AntennaFieldPowerState
    def __init__(self, antenna_field: _Optional[_Union[_antenna_field_id_pb2.AntennaFieldId, _Mapping]] = ..., antenna_field_power_state: _Optional[_Union[_antenna_field_power_state_pb2.AntennaFieldPowerState, str]] = ...) -> None: ...

class SetAntennaFieldPowerStateRequest(_message.Message):
    __slots__ = ("antenna_field", "antenna_field_power_state")
    ANTENNA_FIELD_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_FIELD_POWER_STATE_FIELD_NUMBER: _ClassVar[int]
    antenna_field: _antenna_field_id_pb2.AntennaFieldId
    antenna_field_power_state: _antenna_field_power_state_pb2.AntennaFieldPowerState
    def __init__(self, antenna_field: _Optional[_Union[_antenna_field_id_pb2.AntennaFieldId, _Mapping]] = ..., antenna_field_power_state: _Optional[_Union[_antenna_field_power_state_pb2.AntennaFieldPowerState, str]] = ...) -> None: ...
