from google.protobuf import empty_pb2 as _empty_pb2
from lofar_sid.interface.common.station import station_power_state_pb2 as _station_power_state_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SetStationPowerStateRequest(_message.Message):
    __slots__ = ("station_power_state",)
    STATION_POWER_STATE_FIELD_NUMBER: _ClassVar[int]
    station_power_state: _station_power_state_pb2.StationPowerState
    def __init__(self, station_power_state: _Optional[_Union[_station_power_state_pb2.StationPowerState, str]] = ...) -> None: ...

class StationPowerStateResponse(_message.Message):
    __slots__ = ("station_power_state",)
    STATION_POWER_STATE_FIELD_NUMBER: _ClassVar[int]
    station_power_state: _station_power_state_pb2.StationPowerState
    def __init__(self, station_power_state: _Optional[_Union[_station_power_state_pb2.StationPowerState, str]] = ...) -> None: ...
