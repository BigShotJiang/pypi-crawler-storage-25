import datetime

from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from lofar_sid.interface.common.antenna import antenna_id_pb2 as _antenna_id_pb2
from lofar_sid.interface.common.antenna_field import antenna_field_id_pb2 as _antenna_field_id_pb2
from lofar_sid.interface.common.transient_buffer import transient_buffer_dumper_id_pb2 as _transient_buffer_dumper_id_pb2
from lofar_sid.interface.common.transient_buffer import transient_buffer_state_pb2 as _transient_buffer_state_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class FreezeBufferRequest(_message.Message):
    __slots__ = ("antenna_field",)
    ANTENNA_FIELD_FIELD_NUMBER: _ClassVar[int]
    antenna_field: _antenna_field_id_pb2.AntennaFieldId
    def __init__(self, antenna_field: _Optional[_Union[_antenna_field_id_pb2.AntennaFieldId, _Mapping]] = ...) -> None: ...

class RecordRequest(_message.Message):
    __slots__ = ("antenna_field",)
    ANTENNA_FIELD_FIELD_NUMBER: _ClassVar[int]
    antenna_field: _antenna_field_id_pb2.AntennaFieldId
    def __init__(self, antenna_field: _Optional[_Union[_antenna_field_id_pb2.AntennaFieldId, _Mapping]] = ...) -> None: ...

class StartDumpBufferRequest(_message.Message):
    __slots__ = ("antenna_list", "metadata", "duration_before_after", "duration_begin_end")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ANTENNA_LIST_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    DURATION_BEFORE_AFTER_FIELD_NUMBER: _ClassVar[int]
    DURATION_BEGIN_END_FIELD_NUMBER: _ClassVar[int]
    antenna_list: _antenna_id_pb2.AntennaIdList
    metadata: _containers.ScalarMap[str, str]
    duration_before_after: DumpDurationBeforeAfter
    duration_begin_end: DumpDurationBeginEnd
    def __init__(self, antenna_list: _Optional[_Union[_antenna_id_pb2.AntennaIdList, _Mapping]] = ..., metadata: _Optional[_Mapping[str, str]] = ..., duration_before_after: _Optional[_Union[DumpDurationBeforeAfter, _Mapping]] = ..., duration_begin_end: _Optional[_Union[DumpDurationBeginEnd, _Mapping]] = ...) -> None: ...

class StartDumpBufferResponse(_message.Message):
    __slots__ = ("dumper", "output_filename")
    DUMPER_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FILENAME_FIELD_NUMBER: _ClassVar[int]
    dumper: _transient_buffer_dumper_id_pb2.DumperId
    output_filename: str
    def __init__(self, dumper: _Optional[_Union[_transient_buffer_dumper_id_pb2.DumperId, _Mapping]] = ..., output_filename: _Optional[str] = ...) -> None: ...

class GetTransientBufferStateRequest(_message.Message):
    __slots__ = ("antenna_field", "dumper")
    ANTENNA_FIELD_FIELD_NUMBER: _ClassVar[int]
    DUMPER_FIELD_NUMBER: _ClassVar[int]
    antenna_field: _antenna_field_id_pb2.AntennaFieldId
    dumper: _transient_buffer_dumper_id_pb2.DumperId
    def __init__(self, antenna_field: _Optional[_Union[_antenna_field_id_pb2.AntennaFieldId, _Mapping]] = ..., dumper: _Optional[_Union[_transient_buffer_dumper_id_pb2.DumperId, _Mapping]] = ...) -> None: ...

class GetTransientBufferStateResponse(_message.Message):
    __slots__ = ("state",)
    STATE_FIELD_NUMBER: _ClassVar[int]
    state: _transient_buffer_state_pb2.TransientBufferState
    def __init__(self, state: _Optional[_Union[_transient_buffer_state_pb2.TransientBufferState, _Mapping]] = ...) -> None: ...

class MonitorTransientBufferStateResponse(_message.Message):
    __slots__ = ("state",)
    STATE_FIELD_NUMBER: _ClassVar[int]
    state: _transient_buffer_state_pb2.TransientBufferState
    def __init__(self, state: _Optional[_Union[_transient_buffer_state_pb2.TransientBufferState, _Mapping]] = ...) -> None: ...

class DumpDurationBeforeAfter(_message.Message):
    __slots__ = ("timestamp", "before", "after")
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    BEFORE_FIELD_NUMBER: _ClassVar[int]
    AFTER_FIELD_NUMBER: _ClassVar[int]
    timestamp: _timestamp_pb2.Timestamp
    before: _duration_pb2.Duration
    after: _duration_pb2.Duration
    def __init__(self, timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., before: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., after: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class DumpDurationBeginEnd(_message.Message):
    __slots__ = ("begin", "end")
    BEGIN_FIELD_NUMBER: _ClassVar[int]
    END_FIELD_NUMBER: _ClassVar[int]
    begin: _timestamp_pb2.Timestamp
    end: _timestamp_pb2.Timestamp
    def __init__(self, begin: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., end: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...
