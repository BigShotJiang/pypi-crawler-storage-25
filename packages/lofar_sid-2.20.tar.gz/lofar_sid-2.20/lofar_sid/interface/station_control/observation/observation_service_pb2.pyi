from google.protobuf import empty_pb2 as _empty_pb2
from lofar_sid.interface.common.observation import observation_id_pb2 as _observation_id_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StartObservationRequest(_message.Message):
    __slots__ = ("configuration",)
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    configuration: str
    def __init__(self, configuration: _Optional[str] = ...) -> None: ...

class StopObservationRequest(_message.Message):
    __slots__ = ("observation",)
    OBSERVATION_FIELD_NUMBER: _ClassVar[int]
    observation: _observation_id_pb2.ObservationId
    def __init__(self, observation: _Optional[_Union[_observation_id_pb2.ObservationId, _Mapping]] = ...) -> None: ...
