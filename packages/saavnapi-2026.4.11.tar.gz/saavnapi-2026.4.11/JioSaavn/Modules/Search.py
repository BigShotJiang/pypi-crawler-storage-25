import urllib.parse
import asyncio

from ..Core.Request import Request
from .. import endpoints
from ..Formatter.Song import format_song
from .Lyrics import get_lyrics


async def search(query, limit=10, lyrics=False, client=None):
    query = urllib.parse.quote(query)
    url = endpoints.SEARCH + query

    if client:
        data = await client.get(url)
    else:
        async with Request() as req:
            data = await req.get(url)

    if not data:
        return []

    songs = data.get("results") or data.get("songs", {}).get("data", [])
    songs = songs[:limit]

    sem = asyncio.Semaphore(5)

    async def process(song):
        try:
            async with sem:
                if not song.get("id"):
                    return None

                return await format_song(
                    song,
                    get_lyrics if lyrics else None
                )
        except:
            return None

    results = await asyncio.gather(*[
        process(s) for s in songs
    ], return_exceptions=True)


    return [r for r in results if r and not isinstance(r, Exception)]
