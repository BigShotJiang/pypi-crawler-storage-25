"""CLI commands — setup_cmd."""

import asyncio
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from flowly import __version__, __logo__

console = Console()

# ============================================================================
# Setup Commands
# ============================================================================

setup_app = typer.Typer(help="Interactive setup wizards")


@setup_app.callback(invoke_without_command=True)
def setup_main(ctx: typer.Context):
    """Run the full setup wizard (or use subcommands for specific setups)."""
    if ctx.invoked_subcommand is None:
        from flowly.cli.setup import setup_all
        setup_all()


@setup_app.command("telegram")
def setup_telegram_cmd():
    """Set up Telegram bot."""
    from flowly.cli.setup import setup_telegram
    setup_telegram()


@setup_app.command("voice")
def setup_voice_cmd():
    """Set up voice transcription (Groq Whisper)."""
    from flowly.cli.setup import setup_voice
    setup_voice()


@setup_app.command("voice-calls")
def setup_voice_calls_cmd():
    """Set up voice calls (Twilio)."""
    from flowly.cli.setup import setup_voice_calls
    setup_voice_calls()


@setup_app.command("openrouter")
def setup_openrouter_cmd():
    """Set up OpenRouter LLM provider."""
    from flowly.cli.setup import setup_openrouter
    setup_openrouter()


@setup_app.command("trello")
def setup_trello_cmd():
    """Set up Trello integration."""
    from flowly.cli.setup import setup_trello
    setup_trello()


@setup_app.command("discord")
def setup_discord_cmd():
    """Set up Discord bot."""
    from flowly.cli.setup import setup_discord
    setup_discord()


@setup_app.command("slack")
def setup_slack_cmd():
    """Set up Slack bot."""
    from flowly.cli.setup import setup_slack
    setup_slack()


@setup_app.command("agents")
def setup_agents_cmd():
    """Set up multi-agent orchestration."""
    from flowly.cli.setup import setup_agents
    setup_agents()


@setup_app.command("google-workspace")
def setup_google_workspace_cmd():
    """Install and authenticate the Google Workspace CLI (gws)."""
    from flowly.cli.setup import setup_google_workspace
    setup_google_workspace()


