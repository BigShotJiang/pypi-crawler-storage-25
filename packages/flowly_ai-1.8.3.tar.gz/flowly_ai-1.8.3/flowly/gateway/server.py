"""HTTP + WebSocket API server for gateway integrations."""

import asyncio
import base64
import json
import mimetypes
import uuid
from pathlib import Path
from typing import Any, Callable, Awaitable

import aiohttp
from aiohttp import web
from loguru import logger

from flowly.session.manager import SessionManager
from flowly.agent.subagent_registry import SubagentRegistry
from flowly.profile import get_flowly_home

# Maximum allowed request body size (1MB)
_MAX_BODY_SIZE = 1024 * 1024

# Type alias for the chat callback used by the /ws endpoint.
# Signature: (session_key, message, run_id, stream_callback, media) -> response_text
ChatCallback = Callable[
    [str, str, str, Callable[[str], Awaitable[None]] | None, list[str]],
    Awaitable[str],
]


def _save_attachments(attachments: list[dict], media_dir: Path) -> list[str]:
    """Resolve attachments to local file paths.

    Each attachment may contain:
      - ``filePath``: a native file path (preferred — zero-copy, used by desktop app
        when both app and gateway run on the same machine).
      - ``content``: base64-encoded file data (used by remote clients like iOS/relay).

    When ``filePath`` is provided and the file exists on disk, it is used directly
    without any decoding or copying.  Otherwise the base64 ``content`` is decoded
    and written to *media_dir*.
    """
    media_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for att in attachments:
        # Prefer native file path (desktop local optimisation)
        file_path = att.get("filePath", "")
        if file_path and Path(file_path).is_file():
            paths.append(str(Path(file_path)))
            continue

        # Fall back to base64 content (remote / relay clients)
        content = att.get("content", "")
        if not content:
            continue
        # Strip data URL prefix if present
        if isinstance(content, str) and "," in content and content.startswith("data:"):
            content = content.split(",", 1)[1]
        try:
            data = base64.b64decode(content)
        except Exception:
            continue
        mime = att.get("mimeType", "")
        filename = att.get("fileName", "")
        ext = Path(filename).suffix if filename else (mimetypes.guess_extension(mime) or "")
        fpath = media_dir / f"{uuid.uuid4().hex}{ext}"
        fpath.write_bytes(data)
        paths.append(str(fpath))
    return paths


class GatewayServer:
    """
    HTTP + WebSocket API server for gateway integrations.

    Provides endpoints for:
    - Health check (GET /health)
    - Voice message handling (POST /api/voice/message)
    - Cron triggers (POST /api/cron/run, /api/cron/reload)
    - Desktop WebSocket chat (GET /ws)
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 18790,
        on_voice_message: Callable[[str, str, str], Awaitable[str]] | None = None,
        on_cron_run: Callable[[str, bool], Awaitable[bool]] | None = None,
        on_cron_reload: Callable[[], Awaitable[int]] | None = None,
        on_chat_message: ChatCallback | None = None,
        sessions: SessionManager | None = None,
        subagent_registry: SubagentRegistry | None = None,
        artifact_store: Any | None = None,
        on_compact: Callable[[str, str | None], Awaitable[dict]] | None = None,
        on_clear: Callable[[str], Awaitable[dict]] | None = None,
    ):
        self.host = host
        self.port = port
        self.on_voice_message = on_voice_message
        self.on_cron_run = on_cron_run
        self.on_cron_reload = on_cron_reload
        self.on_chat_message = on_chat_message
        self.sessions = sessions
        self.subagent_registry = subagent_registry
        self.artifact_store = artifact_store
        self.on_compact = on_compact
        self.on_clear = on_clear
        self._app: web.Application | None = None
        self._runner: web.AppRunner | None = None
        self._site: web.TCPSite | None = None
        # Track active WebSocket clients and their running tasks for abort support.
        self._ws_clients: dict[str, web.WebSocketResponse] = {}
        self._active_tasks: dict[str, asyncio.Task] = {}
        # Tick task for periodic health pings to connected clients.
        self._tick_task: asyncio.Task | None = None
        # Browser extension client tracking (supports multiple, uses most recent)
        self._extension_clients: set[str] = set()  # all registered extension client IDs
        self._extension_active: str | None = None  # most recently registered
        self._extension_pending: dict[str, asyncio.Future] = {}  # request_id → Future

    def _create_app(self) -> web.Application:
        """Create the aiohttp application."""
        app = web.Application(client_max_size=_MAX_BODY_SIZE)
        app.router.add_get("/health", self._handle_health)
        if self.on_voice_message:
            app.router.add_post("/api/voice/message", self._handle_voice_message)
        app.router.add_post("/api/cron/run", self._handle_cron_run)
        app.router.add_post("/api/cron/reload", self._handle_cron_reload)
        # Artifact HTTP API
        if self.artifact_store:
            app.router.add_get("/api/artifacts", self._handle_artifacts_list)
            app.router.add_get("/api/artifacts/{id}", self._handle_artifacts_get)
            app.router.add_get("/api/artifacts/{id}/versions", self._handle_artifacts_versions)
        # Desktop WebSocket endpoint — active when chat callback is provided.
        if self.on_chat_message:
            app.router.add_get("/ws", self._handle_ws)
        return app

    # ------------------------------------------------------------------
    # HTTP handlers (unchanged)
    # ------------------------------------------------------------------

    async def _handle_health(self, request: web.Request) -> web.Response:
        return web.json_response({"status": "ok"})

    async def _handle_cron_run(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
            job_id = data.get("job_id", "")
            force = bool(data.get("force", False))
            if not job_id or len(job_id) > 256:
                return web.json_response({"error": "Invalid job_id"}, status=400)
            if not self.on_cron_run:
                return web.json_response({"error": "Cron handler not configured"}, status=500)
            success = await self.on_cron_run(job_id, force)
            if success:
                return web.json_response({"ok": True})
            else:
                return web.json_response({"error": f"Job '{job_id}' not found or disabled"}, status=404)
        except json.JSONDecodeError:
            return web.json_response({"error": "Invalid JSON"}, status=400)
        except Exception as e:
            logger.error(f"Error triggering cron job: {e}")
            return web.json_response({"error": "Internal server error"}, status=500)

    async def _handle_cron_reload(self, request: web.Request) -> web.Response:
        try:
            if not self.on_cron_reload:
                return web.json_response({"error": "Cron reload not configured"}, status=500)
            count = await self.on_cron_reload()
            return web.json_response({"ok": True, "jobs": count})
        except Exception as e:
            logger.error(f"Error reloading cron jobs: {e}")
            return web.json_response({"error": "Internal server error"}, status=500)

    async def _handle_voice_message(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
            call_sid = data.get("call_sid", "")
            from_number = data.get("from", "")
            text = data.get("text", "")
            if not call_sid or len(call_sid) > 128:
                return web.json_response({"error": "Invalid call_sid"}, status=400)
            if len(text) > 50000:
                return web.json_response({"error": "Message too large"}, status=413)
            logger.info(f"Voice message from {from_number}: {text[:50]}...")
            if not self.on_voice_message:
                return web.json_response({"error": "Voice handler not configured"}, status=500)
            response = await asyncio.wait_for(
                self.on_voice_message(call_sid, from_number, text),
                timeout=30.0,
            )
            return web.json_response({"response": response})
        except json.JSONDecodeError:
            return web.json_response({"error": "Invalid JSON"}, status=400)
        except asyncio.TimeoutError:
            logger.error("Voice message handler timeout")
            return web.json_response({"error": "Handler timeout"}, status=504)
        except Exception as e:
            logger.error(f"Error handling voice message: {e}")
            return web.json_response({"error": "Internal server error"}, status=500)

    # ------------------------------------------------------------------
    # WebSocket handler — desktop chat protocol
    # ------------------------------------------------------------------

    async def _handle_ws(self, request: web.Request) -> web.WebSocketResponse:
        """Handle a desktop WebSocket connection."""
        ws = web.WebSocketResponse(heartbeat=30.0, max_msg_size=10 * 1024 * 1024)
        await ws.prepare(request)

        client_id = str(uuid.uuid4())
        self._ws_clients[client_id] = ws
        logger.info(f"[WS] Desktop client connected: {client_id}")

        try:
            async for raw_msg in ws:
                if raw_msg.type == aiohttp.WSMsgType.TEXT:
                    try:
                        data = json.loads(raw_msg.data)
                    except json.JSONDecodeError:
                        await self._ws_send(ws, {"type": "error", "message": "Invalid JSON"})
                        continue
                    msg_type = data.get("type")
                    if msg_type == "rpc":
                        await self._handle_ws_rpc(ws, client_id, data)
                    elif msg_type == "ping":
                        await self._ws_send(ws, {"type": "pong", "timestamp": data.get("timestamp")})
                    elif msg_type == "tool_result":
                        # Fix #10: Only accept tool_result from registered extension clients
                        if client_id in self._extension_clients:
                            self._handle_extension_tool_result(data)
                        else:
                            logger.warning(f"[WS] tool_result from non-extension client {client_id}, ignoring")
                elif raw_msg.type in (aiohttp.WSMsgType.ERROR, aiohttp.WSMsgType.CLOSE):
                    break
        except Exception as e:
            logger.error(f"[WS] Client {client_id} error: {e}")
        finally:
            self._ws_clients.pop(client_id, None)
            if client_id in self._extension_clients:
                self._extension_clients.discard(client_id)
                # Fix #7: Cancel all pending futures for this extension
                cancelled = 0
                for req_id, future in list(self._extension_pending.items()):
                    if not future.done():
                        future.set_result({"error": "Extension disconnected"})
                        cancelled += 1
                    self._extension_pending.pop(req_id, None)
                # Fix #6: Fall back to another extension if available
                if self._extension_active == client_id:
                    self._extension_active = next(iter(self._extension_clients), None)
                logger.info(
                    f"[WS] Browser extension disconnected: {client_id} "
                    f"(cancelled {cancelled} pending, remaining: {len(self._extension_clients)})"
                )
            else:
                logger.info(f"[WS] Desktop client disconnected: {client_id}")

        return ws

    async def _handle_ws_rpc(self, ws: web.WebSocketResponse, client_id: str, data: dict) -> None:
        """Dispatch an RPC call to the appropriate handler."""
        method = data.get("method", "")
        rpc_id = data.get("id", "")
        params = data.get("params") or {}

        try:
            if method == "health":
                await self._ws_rpc_reply(ws, rpc_id, {"ok": True})

            elif method == "sessions.list":
                await self._ws_rpc_sessions_list(ws, rpc_id, params)

            elif method == "sessions.delete":
                await self._ws_rpc_sessions_delete(ws, rpc_id, params)

            elif method == "chat.history":
                await self._ws_rpc_chat_history(ws, rpc_id, params)

            elif method == "chat.send":
                await self._ws_rpc_chat_send(ws, client_id, rpc_id, params)

            elif method == "chat.abort":
                await self._ws_rpc_chat_abort(ws, rpc_id, params)

            elif method == "subagents.list":
                await self._ws_rpc_subagents_list(ws, rpc_id, params)

            elif method == "exec.approval.resolve":
                await self._ws_rpc_exec_approval_resolve(ws, rpc_id, params)

            elif method == "exec.approval.list":
                await self._ws_rpc_exec_approval_list(ws, rpc_id, params)

            # Artifacts
            elif method == "artifacts.list":
                await self._ws_rpc_artifacts_list(ws, rpc_id, params)
            elif method == "artifacts.get":
                await self._ws_rpc_artifacts_get(ws, rpc_id, params)
            elif method == "artifacts.create":
                await self._ws_rpc_artifacts_create(ws, rpc_id, params)
            elif method == "artifacts.update":
                await self._ws_rpc_artifacts_update(ws, rpc_id, params)
            elif method == "artifacts.delete":
                await self._ws_rpc_artifacts_delete(ws, rpc_id, params)
            elif method == "artifacts.pin":
                await self._ws_rpc_artifacts_pin(ws, rpc_id, params)
            elif method == "artifacts.versions":
                await self._ws_rpc_artifacts_versions(ws, rpc_id, params)

            # Chat commands (slash commands)
            elif method == "chat.compact":
                await self._ws_rpc_chat_compact(ws, rpc_id, params)
            elif method == "chat.clear":
                await self._ws_rpc_chat_clear(ws, rpc_id, params)

            # Browser extension registration
            elif method == "extension.register":
                self._extension_clients.add(client_id)
                self._extension_active = client_id
                logger.info(f"[WS] Browser extension registered: {client_id} (total: {len(self._extension_clients)})")
                await self._ws_rpc_reply(ws, rpc_id, {"ok": True})

            else:
                await self._ws_rpc_error(ws, rpc_id, "INVALID_REQUEST", f"Unknown method: {method}")
        except Exception as e:
            logger.error(f"[WS] RPC {method} error: {e}")
            await self._ws_rpc_error(ws, rpc_id, "UNAVAILABLE", str(e))

    # --- RPC: exec.approval ---

    async def _ws_rpc_exec_approval_resolve(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        approval_id = params.get("id", "")
        decision = params.get("decision", "")
        if decision not in ("allow-once", "allow-always", "deny"):
            await self._ws_rpc_error(ws, rpc_id, "INVALID_REQUEST", "Invalid decision")
            return

        from flowly.exec.approval_manager import get_approval_manager
        manager = get_approval_manager()
        if manager.resolve(approval_id, decision):
            await self._ws_rpc_reply(ws, rpc_id, {"ok": True})
        else:
            await self._ws_rpc_error(ws, rpc_id, "NOT_FOUND", "Approval not found or expired")

    async def _ws_rpc_exec_approval_list(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        from flowly.exec.approval_manager import get_approval_manager
        manager = get_approval_manager()
        pending = manager.list_pending()
        items = [{
            "id": p.id,
            "command": p.request.command,
            "sessionKey": p.session_key,
            "expiresAt": p.expires_at,
        } for p in pending]
        await self._ws_rpc_reply(ws, rpc_id, {"approvals": items})

    async def broadcast_approval_request(self, approval_id: str, command: str, session_key: str | None, expires_at: float) -> None:
        """Push an exec approval request to all connected desktop/web clients."""
        event = {
            "type": "event",
            "event": "exec.approval.requested",
            "data": {
                "id": approval_id,
                "command": command,
                "sessionKey": session_key,
                "expiresAt": expires_at,
            },
        }
        for ws in list(self._ws_clients.values()):
            await self._ws_send(ws, event)

    # --- RPC: subagents.list ---

    async def _ws_rpc_subagents_list(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.subagent_registry:
            await self._ws_rpc_reply(ws, rpc_id, {"tasks": []})
            return

        self.subagent_registry._load_from_disk()
        records = self.subagent_registry.all()

        status_filter = params.get("status")
        if status_filter == "running":
            records = [r for r in records if r.ended_at is None]
        elif status_filter == "completed":
            records = [r for r in records if r.outcome == "ok"]
        elif status_filter == "failed":
            records = [r for r in records if r.outcome in ("error", "timeout")]

        import time as _time
        tasks = []
        for r in sorted(records, key=lambda x: x.created_at, reverse=True):
            duration = None
            if r.started_at and r.ended_at:
                duration = round(r.ended_at - r.started_at, 1)
            elif r.started_at:
                duration = round(_time.time() - r.started_at, 1)

            tasks.append({
                "runId": r.run_id,
                "label": r.label,
                "task": r.task,
                "model": r.model,
                "status": "running" if r.ended_at is None else (r.outcome or "unknown"),
                "duration": duration,
                "createdAt": r.created_at,
                "endedAt": r.ended_at,
                "error": r.error,
                "parentSessionKey": r.parent_session_key,
            })

        await self._ws_rpc_reply(ws, rpc_id, {"tasks": tasks})

    # --- RPC: sessions.list ---

    async def _ws_rpc_sessions_list(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.sessions:
            await self._ws_rpc_reply(ws, rpc_id, {"sessions": []})
            return

        raw_sessions = self.sessions.list_sessions()
        sessions = []
        for s in raw_sessions:
            key = s.get("key", "")
            sessions.append({
                "key": key,
                "displayName": key.split(":", 1)[-1] if ":" in key else key,
                "updatedAt": s.get("updated_at"),
            })

        limit = params.get("limit")
        if limit and isinstance(limit, int):
            sessions = sessions[:limit]

        await self._ws_rpc_reply(ws, rpc_id, {"sessions": sessions})

    # --- RPC: sessions.delete ---

    async def _ws_rpc_sessions_delete(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        session_key = params.get("sessionKey", "")
        if not session_key or not self.sessions:
            await self._ws_rpc_error(ws, rpc_id, "INVALID_REQUEST", "sessionKey is required")
            return

        deleted = self.sessions.delete(session_key)
        await self._ws_rpc_reply(ws, rpc_id, {"deleted": deleted, "sessionKey": session_key})

    # --- RPC: chat.history ---

    async def _ws_rpc_chat_history(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        session_key = params.get("sessionKey", "")
        if not session_key or not self.sessions:
            await self._ws_rpc_reply(ws, rpc_id, {"sessionKey": session_key, "messages": []})
            return

        session = self.sessions.get_or_create(session_key)
        # Return full messages (not just role/content) for richer UI rendering.
        messages = []
        for m in session.messages:
            msg: dict[str, Any] = {"role": m["role"]}
            # Normalise content into array format expected by the iOS/desktop protocol.
            content_raw = m.get("content", "")
            if isinstance(content_raw, str):
                msg["content"] = [{"type": "text", "text": content_raw}]
            elif isinstance(content_raw, list):
                msg["content"] = content_raw
            else:
                msg["content"] = [{"type": "text", "text": str(content_raw)}]
            if "timestamp" in m:
                msg["timestamp"] = m["timestamp"]
            if "usage" in m:
                msg["usage"] = m["usage"]
            messages.append(msg)

        await self._ws_rpc_reply(ws, rpc_id, {
            "sessionKey": session_key,
            "sessionId": session_key,
            "messages": messages,
            "thinkingLevel": session.metadata.get("thinkingLevel"),
        })

    # --- RPC: chat.send ---

    async def _ws_rpc_chat_send(
        self, ws: web.WebSocketResponse, client_id: str, rpc_id: str, params: dict,
    ) -> None:
        message = params.get("message", "")
        attachments = params.get("attachments") or []
        if not message and not attachments:
            await self._ws_rpc_error(ws, rpc_id, "INVALID_REQUEST", "Empty message")
            return

        session_key = params.get("sessionKey") or f"desktop:{client_id}"
        idempotency_key = params.get("idempotencyKey") or str(uuid.uuid4())
        run_id = idempotency_key

        # Save attachments to disk
        media: list[str] = []
        if attachments:
            media_dir = get_flowly_home() / "media"
            media = _save_attachments(attachments, media_dir)

        # ACK immediately with runId so the client can track the run.
        await self._ws_rpc_reply(ws, rpc_id, {"runId": run_id, "status": "accepted"})

        # Build streaming callback that pushes delta events to this client.
        async def stream_callback(delta: str) -> None:
            try:
                await self._ws_send(ws, {
                    "type": "event",
                    "event": "agent",
                    "data": {
                        "runId": run_id,
                        "stream": "assistant",
                        "data": {"text": delta},
                    },
                })
            except Exception:
                pass  # Client may have disconnected mid-stream.

        # Process in background so we don't block the recv loop.
        task = asyncio.create_task(
            self._run_chat(ws, client_id, session_key, message, run_id, stream_callback, media)
        )
        self._active_tasks[run_id] = task
        task.add_done_callback(lambda _: self._active_tasks.pop(run_id, None))

    async def _run_chat(
        self,
        ws: web.WebSocketResponse,
        client_id: str,
        session_key: str,
        message: str,
        run_id: str,
        stream_callback: Callable[[str], Awaitable[None]],
        media: list[str] | None = None,
    ) -> None:
        """Execute the chat and send final/error events."""
        accumulated_text = ""

        # Wrap the stream callback to accumulate full text for the final event.
        async def tracking_callback(delta: str) -> None:
            nonlocal accumulated_text
            accumulated_text += delta
            await stream_callback(delta)

        try:
            assert self.on_chat_message is not None
            response = await self.on_chat_message(session_key, message, run_id, tracking_callback, media or [])

            # Send final chat event.
            await self._ws_send(ws, {
                "type": "event",
                "event": "chat",
                "data": {
                    "state": "final",
                    "runId": run_id,
                    "sessionKey": session_key,
                    "message": {
                        "role": "assistant",
                        "content": [{"type": "text", "text": response}],
                    },
                },
            })
        except asyncio.CancelledError:
            await self._ws_send(ws, {
                "type": "event",
                "event": "chat",
                "data": {"state": "aborted", "runId": run_id, "sessionKey": session_key},
            })
        except Exception as e:
            logger.error(f"[WS] chat.send run {run_id} failed: {e}")
            await self._ws_send(ws, {
                "type": "event",
                "event": "chat",
                "data": {
                    "state": "error",
                    "runId": run_id,
                    "sessionKey": session_key,
                    "errorMessage": str(e),
                },
            })

    # --- RPC: chat.abort ---

    async def _ws_rpc_chat_abort(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        run_id = params.get("runId", "")
        task = self._active_tasks.get(run_id)
        if task and not task.done():
            task.cancel()
        await self._ws_rpc_reply(ws, rpc_id, {"ok": True})

    # ------------------------------------------------------------------
    # RPC: chat.compact / chat.clear
    # ------------------------------------------------------------------

    async def _ws_rpc_chat_compact(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.on_compact:
            return await self._ws_rpc_error(ws, rpc_id, "UNAVAILABLE", "Compaction not available")
        session_key = params.get("sessionKey", "desktop:default")
        instructions = params.get("instructions")
        try:
            result = await self.on_compact(session_key, instructions)
            await self._ws_rpc_reply(ws, rpc_id, result)
        except Exception as e:
            logger.error(f"[WS] chat.compact error: {e}")
            await self._ws_rpc_error(ws, rpc_id, "INTERNAL", str(e))

    async def _ws_rpc_chat_clear(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.on_clear:
            return await self._ws_rpc_error(ws, rpc_id, "UNAVAILABLE", "Clear not available")
        session_key = params.get("sessionKey", "desktop:default")
        try:
            result = await self.on_clear(session_key)
            await self._ws_rpc_reply(ws, rpc_id, result)
        except Exception as e:
            logger.error(f"[WS] chat.clear error: {e}")
            await self._ws_rpc_error(ws, rpc_id, "INTERNAL", str(e))

    # ------------------------------------------------------------------
    # WebSocket helpers
    # ------------------------------------------------------------------

    async def _ws_send(self, ws: web.WebSocketResponse, data: dict) -> None:
        """Send JSON to a WebSocket client, silently ignoring closed connections."""
        try:
            if not ws.closed:
                await ws.send_json(data)
        except (ConnectionResetError, RuntimeError):
            pass

    async def _ws_rpc_reply(self, ws: web.WebSocketResponse, rpc_id: str, result: Any) -> None:
        await self._ws_send(ws, {"type": "rpc", "id": rpc_id, "result": result})

    # ------------------------------------------------------------------
    # Browser extension tool request/response
    # ------------------------------------------------------------------

    def has_extension_client(self) -> bool:
        """Check if a browser extension is connected."""
        if not self._extension_active:
            return False
        ws = self._ws_clients.get(self._extension_active)
        return ws is not None and not ws.closed

    async def send_extension_tool_request(
        self, request_id: str, action: str, params: dict
    ) -> dict:
        """Send a tool request to the extension and wait for the result."""
        if not self.has_extension_client():
            return {"error": "Extension not connected"}

        ws = self._ws_clients.get(self._extension_active)
        if not ws or ws.closed:
            return {"error": "Extension WebSocket closed"}
        loop = asyncio.get_running_loop()
        future: asyncio.Future = loop.create_future()
        self._extension_pending[request_id] = future

        try:
            await self._ws_send(ws, {
                "type": "tool_request",
                "id": request_id,
                "action": action,
                "params": params,
            })
            return await future
        finally:
            self._extension_pending.pop(request_id, None)

    def _handle_extension_tool_result(self, data: dict) -> None:
        """Handle a tool_result message from the extension."""
        request_id = data.get("id")
        result = data.get("result", {})
        future = self._extension_pending.get(request_id)
        if future and not future.done():
            future.set_result(result)

    async def _ws_rpc_error(self, ws: web.WebSocketResponse, rpc_id: str, code: str, message: str) -> None:
        await self._ws_send(ws, {
            "type": "rpc",
            "id": rpc_id,
            "error": {"code": code, "message": message},
        })

    # ------------------------------------------------------------------
    # RPC: artifacts
    # ------------------------------------------------------------------

    async def _ws_rpc_artifacts_list(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.artifact_store:
            return await self._ws_rpc_error(ws, rpc_id, "UNAVAILABLE", "Artifacts not enabled")
        results = self.artifact_store.list(
            type=params.get("type"),
            pinned=params.get("pinned"),
            search=params.get("search"),
            limit=params.get("limit", 50),
            offset=params.get("offset", 0),
        )
        await self._ws_rpc_reply(ws, rpc_id, {"artifacts": results})

    async def _ws_rpc_artifacts_get(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.artifact_store:
            return await self._ws_rpc_error(ws, rpc_id, "UNAVAILABLE", "Artifacts not enabled")
        artifact = self.artifact_store.get(params.get("id", ""))
        if not artifact:
            return await self._ws_rpc_error(ws, rpc_id, "NOT_FOUND", "Artifact not found")
        await self._ws_rpc_reply(ws, rpc_id, {"artifact": artifact})

    async def _ws_rpc_artifacts_create(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.artifact_store:
            return await self._ws_rpc_error(ws, rpc_id, "UNAVAILABLE", "Artifacts not enabled")
        art_type = params.get("type", "")
        title = params.get("title", "")
        content = params.get("content", "")
        if not art_type or not title or not content:
            return await self._ws_rpc_error(ws, rpc_id, "INVALID_REQUEST", "type, title, content required")
        artifact = self.artifact_store.create(
            type=art_type, title=title, content=content,
            pinned=params.get("pinned", False),
            dashboard_size=params.get("dashboardSize", "medium"),
            tags=params.get("tags"),
        )
        await self._broadcast_artifact_event("artifact.created", artifact)
        await self._ws_rpc_reply(ws, rpc_id, {"artifact": artifact})

    async def _ws_rpc_artifacts_update(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.artifact_store:
            return await self._ws_rpc_error(ws, rpc_id, "UNAVAILABLE", "Artifacts not enabled")
        artifact_id = params.get("id", "")
        if not artifact_id:
            return await self._ws_rpc_error(ws, rpc_id, "INVALID_REQUEST", "id required")
        artifact = self.artifact_store.update(
            artifact_id,
            title=params.get("title"),
            content=params.get("content"),
            pinned=params.get("pinned"),
            dashboard_size=params.get("dashboardSize"),
            tags=params.get("tags"),
        )
        if not artifact:
            return await self._ws_rpc_error(ws, rpc_id, "NOT_FOUND", "Artifact not found")
        await self._broadcast_artifact_event("artifact.updated", artifact)
        await self._ws_rpc_reply(ws, rpc_id, {"artifact": artifact})

    async def _ws_rpc_artifacts_delete(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.artifact_store:
            return await self._ws_rpc_error(ws, rpc_id, "UNAVAILABLE", "Artifacts not enabled")
        artifact_id = params.get("id", "")
        if not artifact_id:
            return await self._ws_rpc_error(ws, rpc_id, "INVALID_REQUEST", "id required")
        deleted = self.artifact_store.delete(artifact_id)
        if not deleted:
            return await self._ws_rpc_error(ws, rpc_id, "NOT_FOUND", "Artifact not found")
        await self._broadcast_artifact_event("artifact.deleted", {"id": artifact_id})
        await self._ws_rpc_reply(ws, rpc_id, {"ok": True})

    async def _ws_rpc_artifacts_pin(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.artifact_store:
            return await self._ws_rpc_error(ws, rpc_id, "UNAVAILABLE", "Artifacts not enabled")
        artifact_id = params.get("id", "")
        pinned = params.get("pinned", True)
        if not artifact_id:
            return await self._ws_rpc_error(ws, rpc_id, "INVALID_REQUEST", "id required")
        artifact = self.artifact_store.pin(artifact_id, pinned)
        if not artifact:
            return await self._ws_rpc_error(ws, rpc_id, "NOT_FOUND", "Artifact not found")
        await self._broadcast_artifact_event("artifact.updated", artifact)
        await self._ws_rpc_reply(ws, rpc_id, {"artifact": artifact})

    async def _ws_rpc_artifacts_versions(self, ws: web.WebSocketResponse, rpc_id: str, params: dict) -> None:
        if not self.artifact_store:
            return await self._ws_rpc_error(ws, rpc_id, "UNAVAILABLE", "Artifacts not enabled")
        artifact_id = params.get("id", "")
        if not artifact_id:
            return await self._ws_rpc_error(ws, rpc_id, "INVALID_REQUEST", "id required")
        versions = self.artifact_store.get_versions(artifact_id)
        await self._ws_rpc_reply(ws, rpc_id, {"versions": versions})

    async def _broadcast_subagent_event(self, event_name: str, data: dict) -> None:
        """Push subagent lifecycle event to all connected WS clients."""
        event = {"type": "event", "event": event_name, "data": data}
        for ws in list(self._ws_clients.values()):
            await self._ws_send(ws, event)

    async def _broadcast_compaction_event(self, data: dict) -> None:
        """Push compaction event to all connected WS clients."""
        event = {"type": "event", "event": "compaction", "data": data}
        for ws in list(self._ws_clients.values()):
            await self._ws_send(ws, event)

    async def _broadcast_artifact_event(self, event_name: str, data: dict) -> None:
        """Push artifact event to all connected WS clients."""
        event = {"type": "event", "event": event_name, "data": data}
        for ws in list(self._ws_clients.values()):
            await self._ws_send(ws, event)

    # ------------------------------------------------------------------
    # HTTP: artifacts
    # ------------------------------------------------------------------

    async def _handle_artifacts_list(self, request: web.Request) -> web.Response:
        params = dict(request.query)
        results = self.artifact_store.list(
            type=params.get("type"),
            pinned=params.get("pinned") == "true" if "pinned" in params else None,
            search=params.get("search"),
            limit=int(params.get("limit", 50)),
            offset=int(params.get("offset", 0)),
        )
        return web.json_response({"artifacts": results})

    async def _handle_artifacts_get(self, request: web.Request) -> web.Response:
        artifact_id = request.match_info["id"]
        artifact = self.artifact_store.get(artifact_id)
        if not artifact:
            return web.json_response({"error": "Not found"}, status=404)
        return web.json_response({"artifact": artifact})

    async def _handle_artifacts_versions(self, request: web.Request) -> web.Response:
        artifact_id = request.match_info["id"]
        versions = self.artifact_store.get_versions(artifact_id)
        return web.json_response({"versions": versions})

    # ------------------------------------------------------------------
    # Tick loop — periodic health pings to connected WS clients
    # ------------------------------------------------------------------

    async def _tick_loop(self) -> None:
        """Send periodic tick events to all connected desktop clients."""
        while True:
            try:
                await asyncio.sleep(10)
                if not self._ws_clients:
                    continue
                tick = {"type": "event", "event": "tick"}
                for ws in list(self._ws_clients.values()):
                    await self._ws_send(ws, tick)
            except asyncio.CancelledError:
                break
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the HTTP + WebSocket server."""
        self._app = self._create_app()
        self._runner = web.AppRunner(self._app)
        await self._runner.setup()
        self._site = web.TCPSite(self._runner, self.host, self.port)
        try:
            await self._site.start()
        except OSError as e:
            if e.errno in (48, 98):  # 48=macOS, 98=Linux: address already in use
                raise SystemExit(
                    f"\nPort {self.port} is already in use.\n"
                    f"The gateway service is probably already running.\n\n"
                    f"  flowly service status    — check running service\n"
                    f"  flowly service stop      — stop it first\n"
                    f"  flowly service restart   — restart it\n"
                ) from None
            raise
        if self.on_chat_message:
            self._tick_task = asyncio.create_task(self._tick_loop())
        logger.info(f"Gateway API listening on http://{self.host}:{self.port}")
        if self.on_chat_message:
            logger.info(f"Desktop WebSocket available at ws://{self.host}:{self.port}/ws")

    async def stop(self) -> None:
        """Stop the server and clean up."""
        if self._tick_task:
            self._tick_task.cancel()
            try:
                await self._tick_task
            except asyncio.CancelledError:
                pass
        # Cancel any in-flight chat tasks.
        for task in self._active_tasks.values():
            task.cancel()
        # Close all WebSocket connections.
        for ws in list(self._ws_clients.values()):
            await ws.close()
        self._ws_clients.clear()
        if self._site:
            await self._site.stop()
        if self._runner:
            await self._runner.cleanup()
        logger.info("Gateway API stopped")
