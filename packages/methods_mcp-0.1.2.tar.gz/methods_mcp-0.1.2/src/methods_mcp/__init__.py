"""methods-mcp — Lightweight MCP server for paper methods extraction + reproducibility heuristics."""

__version__ = "0.1.2"
