"""Tests for Plan B T8: grant_writing_hook_strength.

Covers 4 cases: strong hook / generic opener / short text / pure abstract.
Assertions focus on `comments` content (substrings) and key `observations`
booleans. Do NOT assert exact numeric score values — too brittle.
"""
from mcp_server_document.grant_writing.plan_b_T8 import (
    grant_writing_hook_strength,
)


# ------------------------------------------------------------------
# Case 1: Strong hook — tagline + digit + contrast + locus
# ------------------------------------------------------------------
def test_strong_hook_scores_high_with_acknowledgment():
    text = (
        "従来の電磁界ソルバは年間120億円の商用ライセンスに依存していた。"
        "我々の研究室は500 kHz帯で動作する国産OSSソルバを打ち立て、この壁を打破する。"
        "JSPS科研費の支援のもと、LLMが呼び出せる統合環境を構築する。"
    )
    r = grant_writing_hook_strength(text)

    # 構造チェック
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 6
    assert "source" in r
    assert "skill.md T1" in r["source"]

    # observations
    obs = r["observations"]
    assert obs["has_digit_in_hook"] is True
    assert obs["has_contrast_word"] is True
    assert obs["has_concrete_locus"] is True
    assert obs["starts_with_generic_template"] is False

    # 強い hook → score は高め
    assert r["score"] >= 7

    # 肯定コメントが含まれていることを確認
    joined = "\n".join(r["comments"])
    assert (
        "Hook 強度は十分" in joined
        or "Hook として機能している" in joined
        or "主張は立っている" in joined
    )


# ------------------------------------------------------------------
# Case 2: Generic opener — 「本研究は〜を目的とする」, no digit
# ------------------------------------------------------------------
def test_generic_opener_scores_low_and_warns():
    text = (
        "本研究は新しい材料設計手法の開発を目的とする。"
        "当該手法は理論的に興味深く、応用範囲が広いと考えられる。"
        "これにより分野の発展に寄与することが期待される。"
    )
    r = grant_writing_hook_strength(text)

    obs = r["observations"]
    assert obs["starts_with_generic_template"] is True
    assert obs["has_digit_in_hook"] is False

    # 凡庸 → score は低い
    assert r["score"] <= 4

    # 凡庸テンプレート警告コメントが必ず含まれる
    joined = "\n".join(r["comments"])
    assert "本研究は" in joined and "凡庸" in joined
    # 数値不在への指摘も含まれる
    assert "数値" in joined


# ------------------------------------------------------------------
# Case 3: Short text (< 30 chars) — no crash, observations populated
# ------------------------------------------------------------------
def test_short_text_no_crash():
    text = "短い。"
    r = grant_writing_hook_strength(text)

    # 構造は保たれる
    assert "score" in r
    assert "comments" in r
    assert "observations" in r

    obs = r["observations"]
    # 全キーが揃っていること
    assert "hook_chars_analyzed" in obs
    assert "first_sentence_len" in obs
    assert "has_digit_in_hook" in obs
    assert "has_contrast_word" in obs
    assert "has_concrete_locus" in obs
    assert "starts_with_generic_template" in obs
    assert "tagline_line_present" in obs

    # 値が妥当
    assert obs["hook_chars_analyzed"] == len(text)
    assert obs["first_sentence_len"] == len("短い")

    # comments は少なくとも 2 つ
    assert len(r["comments"]) >= 2


def test_empty_text_no_crash():
    r = grant_writing_hook_strength("")
    assert r["observations"]["hook_chars_analyzed"] == 0
    assert r["observations"]["first_sentence_len"] == 0
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Case 4: Pure abstract — no digits, no contrast, long sentence
# ------------------------------------------------------------------
def test_pure_abstract_identifies_missing_elements():
    text = (
        "近年の技術動向を鑑みると、多様な問題が存在しており、"
        "それらに対して包括的かつ体系的なアプローチを構築することが"
        "学術的にも社会的にも極めて重要な意義を有していると広く認識されつつある。"
    )
    r = grant_writing_hook_strength(text)

    obs = r["observations"]
    assert obs["has_digit_in_hook"] is False
    assert obs["has_contrast_word"] is False
    # 抽象論 → locus も無い想定
    assert obs["has_concrete_locus"] is False

    # score は低い
    assert r["score"] <= 4

    # 欠落要素についての助言コメントが含まれる
    joined = "\n".join(r["comments"])
    assert "数値" in joined  # has_digit 欠如
    assert "対立" in joined or "しかし" in joined  # contrast 欠如
    assert "locus" in joined or "現場" in joined  # locus 欠如


# ------------------------------------------------------------------
# Additional: hint / source fixed content
# ------------------------------------------------------------------
def test_hint_and_source_content():
    r = grant_writing_hook_strength("テスト本文。")
    assert "粗い温度計" in r["hint"]
    assert "skill.md T1" in r["hint"]
    assert "最適化ゲーム" in r["hint"]
    assert "skill.md T1" in r["source"]
    assert "木下" in r["source"]


# ------------------------------------------------------------------
# 社/会社誤検出の回帰テスト (2026-04-23 hardening)
# ------------------------------------------------------------------
def test_locus_no_false_positive_on_shakai():
    """「社会的」「社会」「社員」「社交」「社内」等の漢語で locus 誤検出しない。"""
    text = "本研究は社会的に重要である。社員の意識も変わり、社交辞令も不要になる。社内教育を通じて実現する。"
    r = grant_writing_hook_strength(text)
    assert r["observations"]["has_concrete_locus"] is False


def test_locus_true_positive_on_kabushiki_gaisha():
    """「株式会社」「〜電機」「〜工業」等、明示的な企業名 suffix は拾う。"""
    text = "三菱電機株式会社との共同研究で、年間 120 億円規模の電磁界解析を実現する。"
    r = grant_writing_hook_strength(text)
    assert r["observations"]["has_concrete_locus"] is True


def test_locus_true_positive_on_famous_company():
    """三菱/日立/東芝 等の頻出社名は拾う。"""
    text = "日立の量産ラインで実装する電磁界ソルバを、本研究で開発する。"
    r = grant_writing_hook_strength(text)
    assert r["observations"]["has_concrete_locus"] is True


def test_locus_true_positive_on_university():
    """大学/教授/研究室は引き続き拾う。"""
    text = "近畿大学工学部の研究室で、教授と共同で実施する研究である。"
    r = grant_writing_hook_strength(text)
    assert r["observations"]["has_concrete_locus"] is True
