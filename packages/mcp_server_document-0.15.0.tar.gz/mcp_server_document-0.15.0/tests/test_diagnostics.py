"""Exercise a representative sample of diagnostic tools with synthetic input."""
import pytest


@pytest.fixture
def bad_ja_text():
    return (
        "本研究は重要である。これまでの手法では解決できないと考えられる問題を、"
        "新規手法によって解決することを目的として行うのである。この手法では、"
        "計算量が多い、複雑な操作が必要である、精度が低いといった問題点があると"
        "考えられている。そこで、我々は本研究において、新しいアルゴリズムを提案"
        "する。提案手法により、従来の問題点を解決することができる。これにより、"
        "本研究の意義は非常に大きいと考えられる。"
    )


@pytest.fixture
def bad_en_text():
    return (
        "In this paper, we propose a novel and highly innovative method. "
        "Recent advances in the field have been substantial. "
        "It is well-known that state-of-the-art methods achieve remarkable results. "
        "There are many approaches that tend to be used. "
        "This paper presents a cutting-edge solution."
    )


def test_grant_writing_lint_bedrock_detects_issues(bad_ja_text):
    from mcp_server_document.grant_writing.tools import grant_writing_lint_bedrock
    res = grant_writing_lint_bedrock(bad_ja_text)
    assert "issue_count" in res
    # Expected: at least hedging (と考えられる)
    rules = {issue["rule"] for issue in res["issues"]}
    assert "hedging_expressions" in rules


def test_grant_writing_redundancy_finds_replacements(bad_ja_text):
    from mcp_server_document.grant_writing.tools import grant_writing_suggest_redundancy_fixes
    res = grant_writing_suggest_redundancy_fixes(bad_ja_text)
    # 「することができる」 pattern is present
    assert res["total_matches"] >= 1


def test_grant_writing_kanji_ratio_balanced(bad_ja_text):
    from mcp_server_document.grant_writing.tools import grant_writing_check_kanji_ratio
    res = grant_writing_check_kanji_ratio(bad_ja_text)
    assert 0.0 <= res["kanji_ratio"] <= 1.0
    assert res["status"] in ("hiragana_heavy", "kanji_heavy", "balanced")


def test_paper_writing_paragraph_opener_detects_banned(bad_en_text):
    from mcp_server_document.paper_writing.tools import paper_writing_check_paragraph_opener
    # Each sentence can be its own "paragraph" via blank-line separation
    paras = "\n\n".join(bad_en_text.split(". "))
    res = paper_writing_check_paragraph_opener(paras)
    assert res["weak_opener_count"] >= 2


def test_paper_writing_strong_adjective_budget_flags_hype(bad_en_text):
    from mcp_server_document.paper_writing.tools import paper_writing_check_strong_adjective_budget
    res = paper_writing_check_strong_adjective_budget(bad_en_text)
    # "novel", "innovative", "state-of-the-art", "cutting-edge" all present;
    # adjective (not adverb) forms "remarkable" / "substantial" are NOT matched
    # by design (regex targets the -ly adverbs).
    assert res["total_strong_adjectives"] >= 3


def test_presentation_over_politeness_detects():
    from mcp_server_document.presentation.tools import presentation_check_over_politeness
    script = "本日は研究を発表させていただきます。測定を報告させていただきます。"
    res = presentation_check_over_politeness(script)
    assert res["total_over_polite"] >= 2


def test_presentation_time_13_rule_returns_densities():
    from mcp_server_document.presentation.tools import presentation_check_time_13_rule
    script = "研究の背景と動機を説明する。" * 30 + "手法を述べる 50 kHz。" * 30 + "A_ij = B_kl の関係 15 mT。" * 30
    res = presentation_check_time_13_rule(script)
    assert "block_specialist_densities" in res
    assert len(res["block_specialist_densities"]) == 3


# ---------- #2: 主述距離 false positive 抑止 ----------
def test_subject_predicate_skips_sub_particle_ha():
    """副助詞「については」「にとっては」を主題と誤認しない。"""
    from mcp_server_document.grant_writing.tools import (
        grant_writing_check_subject_predicate_distance,
    )
    text = (
        "本件については詳細な調査が必要であり、関係者にとっては重要な課題である。"
        "研究者にとっては挑戦的な分野である。"
    )
    r = grant_writing_check_subject_predicate_distance(text)
    assert r["violation_count"] == 0
    assert r["skipped_no_topic_comma"] == r["total_sentences"]


def test_subject_predicate_skips_simple_sentences():
    """読点無しの単純文は解析対象外。"""
    from mcp_server_document.grant_writing.tools import (
        grant_writing_check_subject_predicate_distance,
    )
    text = "これは重要だ。本研究は画期的である。成果は大きい。"
    r = grant_writing_check_subject_predicate_distance(text)
    assert r["violation_count"] == 0


def test_subject_predicate_flags_long_after_topic_comma():
    """「本研究は、……」の後に長い節が続く文は flag。"""
    from mcp_server_document.grant_writing.tools import (
        grant_writing_check_subject_predicate_distance,
    )
    text = (
        "本研究は、従来手法の限界を超え、国産 OSS を基盤として、"
        "国際標準の一角を日本が持つための学術基盤の確立を目指す。"
    )
    r = grant_writing_check_subject_predicate_distance(text)
    assert r["violation_count"] >= 1


def test_subject_predicate_short_topic_sentence_ok():
    """「本研究は、画期的である。」は閾値内で flag しない。"""
    from mcp_server_document.grant_writing.tools import (
        grant_writing_check_subject_predicate_distance,
    )
    text = "本研究は、画期的である。"
    r = grant_writing_check_subject_predicate_distance(text)
    assert r["violation_count"] == 0
    assert r["analyzed_sentences"] == 1
