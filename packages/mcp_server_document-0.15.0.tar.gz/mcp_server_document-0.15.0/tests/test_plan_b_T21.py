"""Tests for Plan B T21: grant_writing_challenge_4_strategies.

4 cases covering: all-4 strategies / vision+roadmap only /
empty-ish text / roadmap only.
Assertions focus on `comments` substrings, `observations.coverage_count`,
and `score`.
"""
from mcp_server_document.grant_writing.plan_b_T21 import (
    grant_writing_challenge_4_strategies,
)


# ------------------------------------------------------------------
# Case 1: All 4 strategies present → score == 10, coverage_count == 4
# ------------------------------------------------------------------
def test_all_four_strategies_present_full_score():
    text = (
        # systematic_review: 既存研究 + 体系的 + これまでの
        "本領域の既存研究をこれまでの流れに沿って体系的に整理すると、"
        # problem_view: 課題 + 限界 + 打破
        "既存手法には深刻な課題があり、アプローチの限界を打破する必要がある。"
        # vision: 将来像 + 拓く + 未来
        "本研究が拓く将来像は、未来の産業に貢献する新たな地平である。"
        # roadmap: 道筋 + フェーズ + マイルストーン
        "この将来像に到達する道筋として、第 1 フェーズで基礎検証、"
        "第 2 フェーズでマイルストーン達成を目指す。"
    )
    r = grant_writing_challenge_4_strategies(text)

    # 構造
    assert r["score_max"] == 10
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 5
    assert "source" in r
    assert "中安豪" in r["source"]
    assert "hint" in r

    # observations
    obs = r["observations"]
    assert obs["coverage_count"] == 4
    assert set(obs["covered_strategies"]) == {
        "systematic_review",
        "problem_view",
        "vision",
        "roadmap",
    }
    assert obs["missing_strategies"] == []

    # strategies dict: 各方策に hit sample が入る (max 3)
    for sid in ("systematic_review", "problem_view", "vision", "roadmap"):
        hits = obs["strategies"][sid]
        assert isinstance(hits, list)
        assert 1 <= len(hits) <= 3

    # score
    assert r["score"] == 10.0

    # 肯定コメント
    joined = "\n".join(r["comments"])
    assert "4 方策すべて" in joined or "挑戦的研究として評価" in joined


# ------------------------------------------------------------------
# Case 2: Only vision + roadmap (2/4) → score == 5,
# missing_strategies includes systematic_review + problem_view
# ------------------------------------------------------------------
def test_vision_roadmap_only_partial_score():
    text = (
        # vision: 将来像 + 拓く + 未来 (NO 新たな に注意: 使わない)
        "本研究が拓く将来像は、未来の社会に広がる展望である。"
        # roadmap: 道筋 + フェーズ + マイルストーン
        "その道筋として、第 1 フェーズでマイルストーンを設定する。"
        # 体系的/整理/既存研究 系や 課題/問題/限界 系は含まない
    )
    r = grant_writing_challenge_4_strategies(text)

    obs = r["observations"]
    assert obs["coverage_count"] == 2
    assert "vision" in obs["covered_strategies"]
    assert "roadmap" in obs["covered_strategies"]
    assert "systematic_review" in obs["missing_strategies"]
    assert "problem_view" in obs["missing_strategies"]

    # score == 5.0
    assert r["score"] == 5.0

    # missing 2 つそれぞれに fix コメントが含まれる
    joined = "\n".join(r["comments"])
    assert "既存研究の体系的整理が不在" in joined
    assert "課題に対する自分の見解が不在" in joined
    assert "方策 1" in joined
    assert "方策 2" in joined


# ------------------------------------------------------------------
# Case 3: Empty-ish text (no strategy keywords) → score == 0,
# missing_strategies = all 4
# ------------------------------------------------------------------
def test_empty_text_all_missing():
    text = "あいうえお。かきくけこ。"  # どの keyword にも hit しない
    r = grant_writing_challenge_4_strategies(text)

    obs = r["observations"]
    assert obs["coverage_count"] == 0
    assert obs["covered_strategies"] == []
    assert set(obs["missing_strategies"]) == {
        "systematic_review",
        "problem_view",
        "vision",
        "roadmap",
    }

    # score == 0
    assert r["score"] == 0.0

    # 4 件中 3 件の fix コメントが出る (上限 3)
    assert 2 <= len(r["comments"]) <= 5
    joined = "\n".join(r["comments"])
    # 少なくとも 3 つの方策の fix コメントが含まれる
    present = sum(
        1
        for kw in (
            "既存研究の体系的整理が不在",
            "課題に対する自分の見解が不在",
            "有益性のある将来像が不在",
            "将来像に到達する道筋が不在",
        )
        if kw in joined
    )
    assert present >= 3

    # 完全に空文字も落ちない
    r_empty = grant_writing_challenge_4_strategies("")
    assert r_empty["score"] == 0.0
    assert r_empty["observations"]["coverage_count"] == 0


# ------------------------------------------------------------------
# Case 4: Just roadmap (年度フェーズマイルストーンしか書かれていない)
# → score == 2.5, 3 missing
# ------------------------------------------------------------------
def test_only_roadmap_quarter_score():
    # roadmap 系のみ: 道筋 / フェーズ / マイルストーン / 段階 / 手順
    # 以下を厳守: 既存研究/体系的/整理/レビュー/先行研究/分野通念/これまでの NG
    #           課題/問題/限界/不足/未解決/変革/打破/乗り越える NG
    #           将来像/ビジョン/景色/展望/拓く/未来/新たな NG
    text = (
        "第 1 フェーズで要素技術を検証する段階を設け、"
        "第 2 フェーズでマイルストーンを順次達成する手順を示す。"
        "全体の道筋はガントチャートで管理する。"
    )
    r = grant_writing_challenge_4_strategies(text)

    obs = r["observations"]
    assert obs["coverage_count"] == 1
    assert obs["covered_strategies"] == ["roadmap"]
    assert set(obs["missing_strategies"]) == {
        "systematic_review",
        "problem_view",
        "vision",
    }

    # roadmap だけ hit を持つ
    assert len(obs["strategies"]["roadmap"]) >= 1
    assert obs["strategies"]["systematic_review"] == []
    assert obs["strategies"]["problem_view"] == []
    assert obs["strategies"]["vision"] == []

    # score == 2.5
    assert r["score"] == 2.5

    # 3 missing に対する fix コメントが入る (上限 3 なので全部入る)
    joined = "\n".join(r["comments"])
    assert "既存研究の体系的整理が不在" in joined
    assert "課題に対する自分の見解が不在" in joined
    assert "有益性のある将来像が不在" in joined
