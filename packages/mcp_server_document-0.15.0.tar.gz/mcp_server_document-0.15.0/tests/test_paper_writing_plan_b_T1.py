"""Tests for Plan B T1: paper_writing_abstract_strength.

Covers 5 cases: strong EN / weak EN / strong JA / background-heavy /
short (empty + 1-sentence). Assertions focus on `comments` content
(substrings) and key `observations` (booleans, banned_phrases list).
Exact numeric scores are NOT asserted.
"""
from mcp_server_document.paper_writing.plan_b_T1 import (
    paper_writing_abstract_strength,
)


# ------------------------------------------------------------------
# Case 1: Strong EN abstract
# ------------------------------------------------------------------
def test_strong_en_abstract_scores_high():
    """problem + method + quantitative + impact + active opening verb."""
    text = (
        "We propose a hybrid surface-integral reduced-order solver for "
        "eddy-current problems, where existing electromagnetic solvers "
        "suffer from a bottleneck when resolving 0.1 mm skin depths at "
        "50 kHz. We demonstrate a 3.2x speedup over the reference "
        "finite-element pipeline with only 2.5% accuracy loss. This "
        "enables parametric sweeps over 50 operating points within a "
        "single day, which improves design workflow for induction "
        "heating engineers."
    )
    r = paper_writing_abstract_strength(text)

    # structure
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 6
    assert "Wallwork" in r["source"]
    assert "skill.md" in r["source"]

    obs = r["observations"]
    assert obs["language"] == "en"
    assert obs["has_problem"] is True
    assert obs["has_method"] is True
    assert obs["has_quantitative_result"] is True
    assert obs["has_impact"] is True
    assert obs["strong_opening_verb"] is True
    assert obs["banned_phrases"] == []
    assert "word_count" in obs

    # strong abstract → score >= 7
    assert r["score"] >= 7

    # 肯定コメントが含まれる
    joined = "\n".join(r["comments"])
    assert "4 要素" in joined and "十分" in joined


# ------------------------------------------------------------------
# Case 2: Weak EN abstract — banned phrase, no number, passive
# ------------------------------------------------------------------
def test_weak_en_abstract_flags_banned_and_low_score():
    text = (
        "It is well-known that electromagnetic simulation has been "
        "studied extensively. In this paper, the general theory is "
        "discussed. Recent advances in the area have been reported by "
        "various authors. The topic is considered to be important."
    )
    r = paper_writing_abstract_strength(text)

    obs = r["observations"]
    assert obs["language"] == "en"
    # banned phrases hit
    assert len(obs["banned_phrases"]) >= 1
    joined_banned = " ".join(obs["banned_phrases"]).lower()
    assert (
        "well-known" in joined_banned
        or "well known" in joined_banned
        or "in this paper" in joined_banned
        or "recent advances" in joined_banned
    )
    # no quantitative result
    assert obs["has_quantitative_result"] is False
    # weak opening verb (passive / it-is)
    assert obs["strong_opening_verb"] is False

    # weak → score <= 4
    assert r["score"] <= 4

    # banned-phrase 警告 comment
    joined = "\n".join(r["comments"])
    assert "禁句" in joined or "banned" in joined.lower() or "desk-reject" in joined
    # 定量不在の指摘
    assert "定量" in joined or "数値" in joined


# ------------------------------------------------------------------
# Case 3: Strong JA abstract
# ------------------------------------------------------------------
def test_strong_ja_abstract_scores_high():
    text = (
        "従来の電磁界ソルバは 0.1 mm の表皮深さを解像する際に計算コストの"
        "課題を抱えていた。本稿では表面積分法と低次元モデルを融合する"
        "新ソルバを提案する。参考の有限要素実装に対し 3.2 倍の高速化と "
        "2.5% 以下の精度劣化を達成した。これにより実世界の誘導加熱設計で"
        "50 点規模のパラメータ掃引が 1 日で実現可能となり、設計工程の"
        "向上に寄与する。"
    )
    r = paper_writing_abstract_strength(text)

    obs = r["observations"]
    assert obs["language"] == "ja"
    assert obs["has_problem"] is True
    assert obs["has_method"] is True
    assert obs["has_quantitative_result"] is True
    assert obs["has_impact"] is True
    assert "char_count" in obs
    assert obs["char_count"] > 0

    # strong → score >= 7
    assert r["score"] >= 7

    # 肯定 comment
    joined = "\n".join(r["comments"])
    assert "4 要素" in joined and "十分" in joined


# ------------------------------------------------------------------
# Case 4: Background-heavy abstract
# ------------------------------------------------------------------
def test_background_heavy_abstract_flags_ratio():
    """Most sentences start with review/background signals."""
    text = (
        "Recent advances in electromagnetic simulation have been widely "
        "reported. Over the past ten years, many researchers have "
        "studied this topic. Traditionally, finite-element methods have "
        "been the dominant approach in the literature. Previously, "
        "studies have compared various formulations. We present a new "
        "tool."
    )
    r = paper_writing_abstract_strength(text)

    obs = r["observations"]
    # background ratio > 0.4
    assert obs["background_ratio"] > 0.4

    # background warning comment
    joined = "\n".join(r["comments"])
    assert (
        "既存研究レビュー" in joined
        or "背景" in joined
        or "寄与に舵" in joined
    )


# ------------------------------------------------------------------
# Case 5a: Empty abstract
# ------------------------------------------------------------------
def test_empty_abstract_no_crash():
    r = paper_writing_abstract_strength("")
    assert "score" in r
    assert "comments" in r
    assert "observations" in r

    obs = r["observations"]
    # 全キーが揃っていること
    assert "language" in obs
    assert "has_problem" in obs
    assert "has_method" in obs
    assert "has_quantitative_result" in obs
    assert "has_impact" in obs
    assert "strong_opening_verb" in obs
    assert "banned_phrases" in obs
    assert "background_ratio" in obs

    # bool 型
    assert isinstance(obs["has_problem"], bool)
    assert isinstance(obs["has_method"], bool)
    assert isinstance(obs["has_quantitative_result"], bool)
    assert isinstance(obs["has_impact"], bool)
    assert isinstance(obs["banned_phrases"], list)

    # comments 少なくとも 2 つ
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Case 5b: Single-sentence abstract
# ------------------------------------------------------------------
def test_single_sentence_abstract_no_crash():
    text = "We propose a new method."
    r = paper_writing_abstract_strength(text)

    obs = r["observations"]
    assert obs["language"] == "en"
    assert obs["has_method"] is True
    assert obs["strong_opening_verb"] is True
    # 構造保持
    assert "word_count" in obs
    assert obs["word_count"] == 5

    # comments 2 個以上
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Additional: hint / source content
# ------------------------------------------------------------------
def test_hint_and_source_content():
    r = paper_writing_abstract_strength("テスト本文。")
    assert "score" in r["hint"]
    assert "skill.md" in r["hint"] or "Wallwork" in r["hint"]
    assert "Wallwork" in r["source"]
    assert "skill.md" in r["source"]


# ------------------------------------------------------------------
# Additional: language forced override
# ------------------------------------------------------------------
def test_language_forced_ja():
    """language='ja' でも en テキストに対し強制日本語モードで動作。"""
    text = "We propose a method."
    r = paper_writing_abstract_strength(text, language="ja")
    assert r["observations"]["language"] == "ja"
    # 日本語モードなら char_count キー
    assert "char_count" in r["observations"]


def test_language_forced_en():
    text = "本稿では手法を提案する。"
    r = paper_writing_abstract_strength(text, language="en")
    assert r["observations"]["language"] == "en"
    assert "word_count" in r["observations"]
