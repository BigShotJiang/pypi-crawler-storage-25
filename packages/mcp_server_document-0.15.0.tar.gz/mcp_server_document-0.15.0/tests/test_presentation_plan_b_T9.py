"""Tests for Plan B T9: presentation_arrow_usage.

4 cases:
1. no_arrows        — 矢印 0 本、score == 10
2. 3_arrows_ok      — 1 slide に 3 本 (閾値内)、score high
3. overused         — 1 slide に 5 本、overused_slides に登場、score 低下
4. heavy_weight     — 太線 (>2pt) 矢印 → heavy_arrows 検出、score 低下
"""
from __future__ import annotations

import pathlib

import pytest


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
_A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"


def _add_slide(prs, layout_idx: int = 6):
    """Add a blank slide (layout 6 is typically 'Blank')."""
    try:
        return prs.slides.add_slide(prs.slide_layouts[layout_idx])
    except IndexError:
        return prs.slides.add_slide(prs.slide_layouts[0])


def _add_arrow(slide, *, width_pt: float = 1.0, with_arrow_end: bool = True):
    """Add a straight connector with (optionally) a tailEnd arrow.

    Returns the connector shape.
    """
    from pptx.enum.shapes import MSO_CONNECTOR
    from pptx.util import Inches, Pt
    from lxml import etree

    conn = slide.shapes.add_connector(
        MSO_CONNECTOR.STRAIGHT,
        Inches(1), Inches(1),
        Inches(3), Inches(1),
    )
    # Setting line.width materialises <a:ln w=".."/> in the XML tree.
    conn.line.width = Pt(width_pt)

    if with_arrow_end:
        ln = conn._element.find(f".//{{{_A_NS}}}ln")
        assert ln is not None, "line element should exist after width set"
        tail_end = etree.SubElement(ln, f"{{{_A_NS}}}tailEnd")
        tail_end.set("type", "triangle")

    return conn


# ------------------------------------------------------------------
# Case 1: no arrows — score == 10
# ------------------------------------------------------------------
def test_no_arrows(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T9 import (
        presentation_arrow_usage,
    )

    prs = Presentation()
    _add_slide(prs)
    _add_slide(prs)

    out = tmp_path / "no_arrows.pptx"
    prs.save(str(out))

    r = presentation_arrow_usage(str(out))

    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 2
    assert obs["total_arrow_count"] == 0
    assert obs["max_per_slide"] == 0
    assert obs["overused_slides"] == []
    assert obs["heavy_arrows"] == []
    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    assert "矢印" in joined


# ------------------------------------------------------------------
# Case 2: 3 arrows on one slide — adequate usage
# ------------------------------------------------------------------
def test_3_arrows_ok(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T9 import (
        presentation_arrow_usage,
    )

    prs = Presentation()
    slide = _add_slide(prs)
    for _ in range(3):
        _add_arrow(slide, width_pt=1.0, with_arrow_end=True)

    out = tmp_path / "three_arrows.pptx"
    prs.save(str(out))

    r = presentation_arrow_usage(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 1
    assert obs["total_arrow_count"] == 3
    assert obs["max_per_slide"] == 3
    assert obs["overused_slides"] == []  # 3 is not > 3
    assert obs["heavy_arrows"] == []
    # No overuse, no heavy → score stays at 10
    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    assert "適正" in joined or "矢印" in joined


# ------------------------------------------------------------------
# Case 3: overused — 5 arrows on one slide
# ------------------------------------------------------------------
def test_overused_slide(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T9 import (
        presentation_arrow_usage,
    )

    prs = Presentation()
    slide = _add_slide(prs)
    for _ in range(5):
        _add_arrow(slide, width_pt=1.0, with_arrow_end=True)

    out = tmp_path / "overused.pptx"
    prs.save(str(out))

    r = presentation_arrow_usage(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_arrow_count"] == 5
    assert obs["max_per_slide"] == 5
    assert obs["overused_slides"] == [0]
    assert obs["heavy_arrows"] == []
    # -2 for 1 overused slide → score <= 8
    assert r["score"] <= 8.0, r

    joined = "\n".join(r["comments"])
    assert "矢印過多" in joined
    assert "宮野 S10" in joined


# ------------------------------------------------------------------
# Case 4: heavy_weight — 2 thick arrows on one slide
# ------------------------------------------------------------------
def test_heavy_weight_arrows(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T9 import (
        presentation_arrow_usage,
    )

    prs = Presentation()
    slide = _add_slide(prs)
    # 2 thick arrows (3pt each > 2pt threshold)
    _add_arrow(slide, width_pt=3.0, with_arrow_end=True)
    _add_arrow(slide, width_pt=3.0, with_arrow_end=True)

    out = tmp_path / "heavy.pptx"
    prs.save(str(out))

    r = presentation_arrow_usage(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_arrow_count"] == 2
    assert len(obs["heavy_arrows"]) == 2
    for ha in obs["heavy_arrows"]:
        assert ha["slide_idx"] == 0
        assert ha["line_weight"] > 25400  # 2pt
        assert ha["has_fill"] is False
    # 2 heavy arrows → -2 penalty → score == 8
    assert r["score"] <= 9.0

    joined = "\n".join(r["comments"])
    assert "太線" in joined or "塗りつぶし" in joined


# ------------------------------------------------------------------
# Structural contract
# ------------------------------------------------------------------
def test_hint_and_source_content(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T9 import (
        presentation_arrow_usage,
    )

    prs = Presentation()
    _add_slide(prs)
    out = tmp_path / "tiny.pptx"
    prs.save(str(out))

    r = presentation_arrow_usage(str(out))
    assert r["score_max"] == 10
    assert "hint" in r and "EMU" in r["hint"]
    assert "source" in r
    assert "S10" in r["source"]
    assert "宮野" in r["source"]


# ------------------------------------------------------------------
# Error path: missing file
# ------------------------------------------------------------------
def test_missing_file_returns_error(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T9 import (
        presentation_arrow_usage,
    )

    ghost = tmp_path / "does_not_exist.pptx"
    r = presentation_arrow_usage(str(ghost))
    assert "error" in r
    assert "not found" in r["error"]
