"""Tests for presentation Plan B T12: presentation_health_report — meta aggregation.

grant_writing T16 / paper_writing T8 と同じ return shape を検証する。
"""
from __future__ import annotations

import pathlib

import pytest


def _make_pptx(
    tmp_path: pathlib.Path,
    slides: list[tuple[str, str]],
    filename: str = "deck.pptx",
) -> pathlib.Path:
    """Build a pptx with (title, body) per slide using Title+Content layout."""
    pytest.importorskip("pptx")
    from pptx import Presentation

    prs = Presentation()
    for title_text, body_text in slides:
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        for ph in slide.placeholders:
            try:
                idx = ph.placeholder_format.idx
            except Exception:
                continue
            if idx == 0:
                ph.text = title_text
            else:
                ph.text = body_text
    out = tmp_path / filename
    prs.save(str(out))
    return out


def test_T12_clean_deck_few_critical(tmp_path):
    """骨格の整った deck: CRITICAL 件数は少なめ。"""
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T12 import (
        presentation_health_report,
    )
    # Hook (T1) が強く、outline slide (T5) があり、Take-home (T2) 明示、
    # pie/3D/logo は無し — CRITICAL が少ないことを期待。
    p = _make_pptx(tmp_path, [
        ("500 kHz 帯で動作する新方式",
         "我々の研究室で 14 年運用してきた商用 CAE を置換。"),
        ("本日のアウトライン",
         "1. 背景\n2. 提案手法\n3. 結果\n4. まとめ"),
        ("従来手法の限界",
         "100 kHz 以上で精度が劣化する。"),
        ("提案手法",
         "新しい数値解析により 5 倍高速化。"),
        ("結果",
         "従来比 12% の精度改善を確認。"),
        ("Take-home: 提案手法で解析を 5 倍加速",
         "500 kHz 帯で 12% 精度改善を実証した。"),
    ])
    r = presentation_health_report(str(p))
    # 全 11 tool (T1-T11) が回る
    assert len(r["tools_run"]) == 11
    assert r["overall_severity"] in ("CRITICAL", "HIGH", "MEDIUM", "LOW")
    # 骨格はある deck なので CRITICAL の件数は 5 件未満
    n_critical = sum(
        1 for i in r["priority_issues"] if i["severity"] == "CRITICAL"
    )
    assert n_critical < 5, r["priority_issues"]


def test_T12_neglected_deck_many_critical(tmp_path):
    """Hook も Takehome も無い空 deck: CRITICAL / HIGH が多く出る。"""
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T12 import (
        presentation_health_report,
    )
    # 空タイトルのみ、中身ほぼゼロ
    p = _make_pptx(tmp_path, [
        ("タイトル", ""),
        ("", ""),
        ("", ""),
    ])
    r = presentation_health_report(str(p))
    sevs = [i["severity"] for i in r["priority_issues"]]
    assert "CRITICAL" in sevs or "HIGH" in sevs, r
    assert r["overall_severity"] in ("CRITICAL", "HIGH", "MEDIUM"), r

    # priority_issues は severity 降順
    rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "UNKNOWN": 3, "LOW": 4}
    assert sevs == sorted(sevs, key=lambda s: rank.get(s, 99))


def test_T12_skip_arg(tmp_path):
    """skip='T4,T8' で該当 tool を除外できる。"""
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T12 import (
        presentation_health_report,
    )
    p = _make_pptx(tmp_path, [
        ("タイトル", "bodytext"),
        ("slide 2", "more content"),
    ])
    r = presentation_health_report(str(p), skip="T4,T8")
    assert "T4" not in r["tools_run"]
    assert "T8" not in r["tools_run"]
    assert "T4" in r["tools_skipped"]
    assert "T8" in r["tools_skipped"]
    # 残り 9 tool は実行される
    assert len(r["tools_run"]) == 9


def test_T12_missing_file():
    """file not found: overall_severity CRITICAL, summary に path 情報。"""
    from mcp_server_document.presentation.plan_b_T12 import (
        presentation_health_report,
    )
    r = presentation_health_report("/nonexistent/no_such_deck.pptx")
    assert r["overall_score"] == 0.0
    assert r["overall_severity"] == "CRITICAL"
    assert "no_such_deck.pptx" in r["summary_comment"]
    assert r["tools_run"] == []
    # priority_issues に T12 自身の error エントリ
    assert any(i["tool"] == "T12" for i in r["priority_issues"])


def test_T12_shape_contract(tmp_path):
    """返り値の shape: 8 key 全部あり。grant T16 / paper T8 と同じ。"""
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T12 import (
        presentation_health_report,
    )
    p = _make_pptx(tmp_path, [("t1", "b1"), ("t2", "b2")])
    r = presentation_health_report(str(p))
    for k in (
        "overall_score",
        "overall_severity",
        "summary_comment",
        "detailed_scores",
        "priority_issues",
        "tools_run",
        "tools_skipped",
        "hint",
        "source",
    ):
        assert k in r, f"missing key: {k}"
    # 制約
    assert 0 <= r["overall_score"] <= 10
    assert isinstance(r["summary_comment"], str)
    assert len(r["summary_comment"]) > 10
    assert isinstance(r["detailed_scores"], dict)
    assert isinstance(r["priority_issues"], list)
    assert isinstance(r["tools_run"], list)
    assert isinstance(r["tools_skipped"], list)
    # source には Plan B の由来
    assert "Plan B" in r["source"]
