"""Tests for Plan B T9: concrete scene density diagnostic.

Covers the 4 shape cases described in the plan:
1. Dense concrete: score >= 8
2. Pure abstract: score <= 3, comments identify abstract windows
3. Mixed: partial score
4. Short text (< 500 chars, 1 concrete): single-window analysis, score = 10

Assertions avoid exact score matching; use substring / range checks.
"""
from __future__ import annotations

import pytest

from mcp_server_document.grant_writing.plan_b_T9 import (
    grant_writing_concrete_scene_density,
)


# ------------------------------------------------------------------
# Case 1: Dense concrete — multiple 数値+単位, 固有名, 場所 markers
# ------------------------------------------------------------------
def test_dense_concrete_high_score():
    """1 ウィンドウに多数の具体要素があれば score >= 8。"""
    # 約 600 字。数値+単位、Latin 識別子、カタカナ語、場所マーカーが散りばめ。
    chunk = (
        "三菱電機で 14 年の実務経験を積んだ。"
        "500 kHz の IH コイル設計案件では PCB ボードの試作を 5 回、"
        "ソルバ実行に 2 時間、プロト検証に 3 日を要した。"
        "JMAG と NGSolve で比較評価を行い、研究室の学生 2 名と連携した。"
        "パワーアカデミーの 2026 年度助成 500 万円を確保し、"
        "工場現場での測定を 10 件実施、精度は 95 % に到達した。"
        "LLM を用いた自動設計支援は 3 ヶ月の開発で基盤が整った。"
        "本研究は KDDI 財団の助成と合わせ 2 年間で展開する。"
    )
    # Make sure len >= window_chars so multiple windows are tested
    text = chunk * 2
    assert len(text) >= 500

    r = grant_writing_concrete_scene_density(text)
    assert r["score_max"] == 10
    assert r["score"] >= 8, f"expected dense score>=8, got {r['score']}"

    obs = r["observations"]
    assert obs["total_chars"] == len(text)
    assert obs["total_windows"] >= 1
    assert obs["abstract_only_windows"] == 0
    # All windows OK
    assert all(w["status"] == "OK" for w in obs["windows"])
    # comments should acknowledge — mention 具体 or 臨場感
    joined = " ".join(r["comments"])
    assert ("具体" in joined) or ("臨場感" in joined)


# ------------------------------------------------------------------
# Case 2: Pure abstract — 2000 字 with no 数値/固有名/場所
# ------------------------------------------------------------------
def test_pure_abstract_low_score_with_char_ranges():
    """抽象論のみの 2000 字: score <= 3, comments に char range + '抽象'。"""
    # ひらがな中心、数字なし、Latin なし、カタカナ 3 字以上なし、場所なし。
    # 厳しく作るため、カタカナを完全に排除する。
    sentence = (
        "このけんきゅうはたいへんじゅうようであるとかんがえられる。"
        "そのためにきはくないとあくしつなもくひょうをたてたいとおもう。"
        "さらにこうぞうてきなりかいをふかめるべきであり、"
        "わたしたちはこれまでのほうしきをみなおすひつようがある。"
    )
    text = sentence * 10  # ~600 chars per 10 repetitions; pad to >2000
    while len(text) < 2000:
        text += sentence
    assert len(text) >= 2000

    r = grant_writing_concrete_scene_density(text)
    assert r["score"] <= 3, f"expected abstract score<=3, got {r['score']}"

    obs = r["observations"]
    assert obs["total_windows"] >= 3
    assert obs["abstract_only_windows"] >= 1
    # At least one window status ABSTRACT_ONLY
    assert any(w["status"] == "ABSTRACT_ONLY" for w in obs["windows"])

    # Comments should include "字目" (char range marker) and the word "抽象"
    joined = " ".join(r["comments"])
    assert "字目" in joined
    assert "抽象" in joined
    # At most 6 comments
    assert 1 <= len(r["comments"]) <= 6


# ------------------------------------------------------------------
# Case 3: Mixed — first half concrete, second half abstract
# ------------------------------------------------------------------
def test_mixed_partial_score_with_abstract_indices():
    """前半 concrete + 後半 abstract: 部分スコアと abstract window の ID。"""
    concrete_chunk = (
        "三菱電機で 14 年の PCB 設計案件を担当し、500 kHz の IH コイル試作を 5 回、"
        "JMAG と NGSolve で比較した。工場現場では 10 件の測定を行った。"
    )
    # Build 600 chars of concrete
    concrete_half = ""
    while len(concrete_half) < 600:
        concrete_half += concrete_chunk

    abstract_sentence = (
        "このけんきゅうはたいへんじゅうようであるとかんがえられる。"
        "そのためにきはくないとあくしつなもくひょうをたてたいとおもう。"
    )
    abstract_half = ""
    while len(abstract_half) < 600:
        abstract_half += abstract_sentence

    text = concrete_half + abstract_half
    assert len(text) >= 1200

    r = grant_writing_concrete_scene_density(text)
    # Expect partial: neither full 10 nor zero
    assert 0 < r["score"] < 10, f"expected partial, got {r['score']}"

    obs = r["observations"]
    assert obs["total_windows"] >= 2
    # There should be at least one OK and at least one ABSTRACT_ONLY
    statuses = [w["status"] for w in obs["windows"]]
    assert "OK" in statuses
    assert "ABSTRACT_ONLY" in statuses

    # comments should mention char ranges of the abstract windows
    joined = " ".join(r["comments"])
    assert "字目" in joined
    assert "抽象" in joined


# ------------------------------------------------------------------
# Case 4: Short text (< 500 chars) with 1 concrete element → score = 10
# ------------------------------------------------------------------
def test_short_text_single_window_with_concrete_scores_10():
    """短文 (<500 chars) で具体要素 >= 1 なら single-window 解析 score=10。"""
    text = "三菱電機で 14 年の実務。500 kHz IH コイルを試作した。"
    assert len(text) < 500

    r = grant_writing_concrete_scene_density(text)
    assert r["score"] == 10
    assert r["score_max"] == 10

    obs = r["observations"]
    assert obs["total_windows"] == 1
    assert obs["abstract_only_windows"] == 0
    w = obs["windows"][0]
    assert w["idx"] == 0
    assert w["status"] == "OK"
    assert w["concrete_count"] >= 1

    # Comment acknowledges concrete scene
    joined = " ".join(r["comments"])
    assert ("具体" in joined) or ("臨場感" in joined)


# ------------------------------------------------------------------
# Bonus: short text with ZERO concrete is ABSTRACT_ONLY → score 0
# ------------------------------------------------------------------
def test_short_text_no_concrete_scores_zero():
    """短文 (<500) で具体要素ゼロなら score 0 で char-range comment 発火。"""
    text = "このけんきゅうはじゅうようであるとおもう。"
    assert len(text) < 500

    r = grant_writing_concrete_scene_density(text)
    assert r["score"] == 0
    obs = r["observations"]
    assert obs["total_windows"] == 1
    assert obs["abstract_only_windows"] == 1
    joined = " ".join(r["comments"])
    assert "字目" in joined
    assert "抽象" in joined


# ------------------------------------------------------------------
# Bonus: empty text
# ------------------------------------------------------------------
def test_empty_text_gives_warning():
    """空テキストは score=0 で警告コメント。"""
    r = grant_writing_concrete_scene_density("")
    assert r["score"] == 0
    assert r["observations"]["total_chars"] == 0
    assert r["observations"]["total_windows"] == 0
    # Has at least one warning comment
    assert len(r["comments"]) >= 1


# ------------------------------------------------------------------
# Return-shape sanity
# ------------------------------------------------------------------
def test_return_shape_contains_all_keys():
    r = grant_writing_concrete_scene_density("テスト用のとてもみじかいぶん")
    for key in ("score", "score_max", "comments", "observations", "hint", "source"):
        assert key in r, f"missing key: {key}"
    assert "T5" in r["source"] or "suggest_vivid_scene" in r["source"]
    assert isinstance(r["comments"], list)
    assert isinstance(r["observations"], dict)
