"""Tests for v0.8.0: word repetition + sentence ending + line plot lint.

Sources:
- 中島利勝・塚本真也『知的な科学・技術文章の書き方』コロナ社 1996
- 塚本真也『作図力学』
"""
from __future__ import annotations

import json
import pathlib
import pytest


# ---------------------------------------------------------------------------
# paper_writing_check_word_repetition
# ---------------------------------------------------------------------------
def test_word_repetition_kanji_detected():
    """Kanji noun repetition within 40-char window should be flagged."""
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_word_repetition,
    )
    text = "変化は急速である。変化の要因を測定する。"
    r = paper_writing_check_word_repetition(text, window_chars=40)
    assert r["total_findings"] >= 1
    assert "変化" in r["unique_repeated_words"]


def test_word_repetition_stopword_excluded():
    """Stop words (研究, 論文, 本研究 etc.) must not be flagged."""
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_word_repetition,
    )
    text = "本研究では電磁界解析を行う。本研究の手法は新しい。本研究の成果は有用だ。"
    r = paper_writing_check_word_repetition(text, window_chars=40)
    assert "本研究" not in r["unique_repeated_words"]


def test_word_repetition_english_detected():
    """English technical terms repeating within window are flagged."""
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_word_repetition,
    )
    text = "We apply ESIM to coil. The ESIM accuracy is high with ESIM results."
    r = paper_writing_check_word_repetition(text, window_chars=60)
    assert r["total_findings"] >= 1
    assert "ESIM" in r["unique_repeated_words"]


def test_word_repetition_outside_window_not_flagged():
    """Same word far apart should not be flagged."""
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_word_repetition,
    )
    # 同じ語だが 50+ 字離れている
    text = "磁界解析を行う。" + ("x" * 80) + "磁界強度を求める。"
    r = paper_writing_check_word_repetition(text, window_chars=30)
    # Should not flag 磁界 since distance > 30
    assert not any(f["word"] == "磁界" for f in r["findings"])


# ---------------------------------------------------------------------------
# paper_writing_check_sentence_ending_variety
# ---------------------------------------------------------------------------
def test_sentence_ending_critical_run_detected():
    """3 consecutive 「である」 should produce a critical_run entry."""
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_sentence_ending_variety,
    )
    text = "本論文は A である。B は C である。D は E である。"
    r = paper_writing_check_sentence_ending_variety(text,
                                                       consecutive_threshold=3)
    assert r["total_sentences"] == 3
    assert r["critical_runs"]
    assert r["critical_runs"][0]["ending"] == "である"
    assert r["critical_runs"][0]["length"] == 3


def test_sentence_ending_varied_no_critical():
    """Varied endings should yield no critical runs."""
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_sentence_ending_variety,
    )
    text = "A を提案する。B を示した。C の結果を得る。D と考えられる。"
    r = paper_writing_check_sentence_ending_variety(text)
    assert r["total_sentences"] == 4
    assert r["critical_runs"] == []
    # Entropy should be high for varied endings
    assert r["shannon_entropy_bits"] > 1.0


def test_sentence_ending_empty_text():
    """Empty text should not crash."""
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_sentence_ending_variety,
    )
    r = paper_writing_check_sentence_ending_variety("")
    assert r["total_sentences"] == 0
    assert r["critical_runs"] == []


def test_sentence_ending_histogram_exists():
    """Histogram keys reflect detected endings."""
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_sentence_ending_variety,
    )
    text = "A である。B する。C した。"
    r = paper_writing_check_sentence_ending_variety(text)
    assert set(r["ending_histogram"].keys()) & {"である", "する", "した"}


# ---------------------------------------------------------------------------
# diagram_lint_line_plot
# ---------------------------------------------------------------------------
def _make_minimal_plot(tmp_path: pathlib.Path, with_caption=True,
                          with_axis_label=True, with_data_line=True) -> pathlib.Path:
    """Synthesise a bare-bones Excalidraw line-plot document."""
    elements = []
    eid = 0
    def _eid():
        nonlocal eid
        eid += 1
        return f"e{eid}"
    if with_data_line:
        elements.append({
            "id": _eid(), "type": "line",
            "x": 50, "y": 40, "width": 200, "height": 100,
            "angle": 0, "strokeColor": "#1e1e1e",
            "backgroundColor": "transparent", "strokeWidth": 2,
            "fillStyle": "solid", "strokeStyle": "solid",
            "roughness": 0, "opacity": 100,
            "points": [[0, 100], [50, 60], [100, 40], [150, 70], [200, 20]],
            "isDeleted": False, "groupIds": [],
            "seed": 1, "version": 1, "versionNonce": 1,
            "boundElements": None,
        })
    if with_axis_label:
        for i, lbl in enumerate(["X axis", "Y axis"]):
            elements.append({
                "id": _eid(), "type": "text",
                "x": 120 + i * 10, "y": 150 + i * 5,
                "width": 60, "height": 16,
                "angle": 0, "strokeColor": "#1e1e1e",
                "backgroundColor": "transparent", "strokeWidth": 1,
                "fillStyle": "solid", "strokeStyle": "solid",
                "roughness": 0, "opacity": 100,
                "text": lbl, "fontSize": 14, "fontFamily": 2,
                "isDeleted": False, "groupIds": [],
                "seed": 1, "version": 1, "versionNonce": 1,
                "boundElements": None,
            })
    if with_caption:
        elements.append({
            "id": _eid(), "type": "text",
            "x": 50, "y": 170, "width": 200, "height": 16,
            "angle": 0, "strokeColor": "#1e1e1e",
            "backgroundColor": "transparent", "strokeWidth": 1,
            "fillStyle": "solid", "strokeStyle": "solid",
            "roughness": 0, "opacity": 100,
            "text": "Fig. 1. Example", "fontSize": 14, "fontFamily": 2,
            "isDeleted": False, "groupIds": [],
            "seed": 1, "version": 1, "versionNonce": 1,
            "boundElements": None,
        })
    doc = {"type": "excalidraw", "version": 2,
           "elements": elements,
           "appState": {"viewBackgroundColor": "#ffffff"}}
    path = tmp_path / "plot.excalidraw"
    path.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
    return path


def test_lint_line_plot_ok_case(tmp_path):
    from mcp_server_document.diagram.tools import diagram_lint_line_plot
    p = _make_minimal_plot(tmp_path, True, True, True)
    r = diagram_lint_line_plot(str(p))
    assert "error" not in r, r
    assert r["text_count"] >= 2
    assert r["line_count"] >= 1
    assert r["verdict"] in ("ok", "minor_issues"), r


def test_lint_line_plot_missing_axis_labels(tmp_path):
    from mcp_server_document.diagram.tools import diagram_lint_line_plot
    p = _make_minimal_plot(tmp_path, True, False, True)
    r = diagram_lint_line_plot(str(p), min_axis_labels=2)
    rules = [f["rule"] for f in r["findings"]]
    assert "axis_labels" in rules
    assert r["verdict"] == "needs_fix"


def test_lint_line_plot_no_data(tmp_path):
    from mcp_server_document.diagram.tools import diagram_lint_line_plot
    p = _make_minimal_plot(tmp_path, True, True, False)
    r = diagram_lint_line_plot(str(p))
    rules = [f["rule"] for f in r["findings"]]
    assert "no_data_series" in rules
    assert r["verdict"] == "needs_fix"


def test_lint_line_plot_missing_file():
    from mcp_server_document.diagram.tools import diagram_lint_line_plot
    r = diagram_lint_line_plot("/nonexistent/no.excalidraw")
    assert "error" in r


def test_lint_line_plot_empty_doc(tmp_path):
    from mcp_server_document.diagram.tools import diagram_lint_line_plot
    p = tmp_path / "empty.excalidraw"
    p.write_text('{"type":"excalidraw","version":2,"elements":[],"appState":{}}',
                  encoding="utf-8")
    r = diagram_lint_line_plot(str(p))
    assert r["verdict"] == "empty"
