"""Tests for Plan B T19: grant_writing_5w1h_coverage.

Covers 4 cases: full coverage / half coverage / zero coverage / short text.
Assertions focus on `observations.coverage_count` and `comments` substrings.
Do NOT assert exact numeric score values — too brittle.
"""
from mcp_server_document.grant_writing.plan_b_T19 import (
    grant_writing_5w1h_coverage,
)


# ------------------------------------------------------------------
# Case 1: Full coverage — all 6 axes in first 500 chars
# ------------------------------------------------------------------
def test_full_coverage_scores_high():
    text = (
        "申請者は近畿大学の研究室で、令和6年度から本研究期間として"
        "電磁界解析 OSS を開発する。従来手法の限界という課題を背景に、"
        "AI を用いて自律設計を実現するアプローチを採る。"
        "共同研究者と国内外の現場で実証を重ね、LLM による統合環境を構築する。"
    )
    r = grant_writing_5w1h_coverage(text)

    # 構造チェック
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 5
    assert "source" in r
    assert "skill.md" in r["source"]

    obs = r["observations"]
    assert obs["coverage_count"] == 6
    assert obs["missing_axes"] == []
    assert set(obs["covered_axes"]) == {"who", "what", "when", "where", "why", "how"}

    # 全軸カバー → score は高い (6/6 -> 10.0)
    assert r["score"] >= 8
    assert r["score"] >= 8.3  # skill.md 閾値 5/6 以上

    # 全軸カバー肯定コメント
    joined = "\n".join(r["comments"])
    assert "全軸" in joined or "情報密度" in joined


# ------------------------------------------------------------------
# Case 2: Half coverage — 3/6 axes
# ------------------------------------------------------------------
def test_half_coverage_score_mid():
    # who (申請者), what (解析), how (手法) はあるが
    # when/where/why は無い
    text = (
        "申請者は解析の新しい手法を試みる。"
        "これは技術的に興味深い試みである。"
    )
    r = grant_writing_5w1h_coverage(text)

    obs = r["observations"]
    # 約 3/6 のオーダ (多少のブレは許容)
    assert 2 <= obs["coverage_count"] <= 4
    assert len(obs["missing_axes"]) >= 1
    assert len(obs["missing_axes"]) <= 4

    # score はおよそ中間 (3/6 = 5.0 付近)
    assert 2 <= r["score"] <= 7

    # 助言コメントが missing 軸について含まれる
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Case 3: Zero coverage — 中立な短文
# ------------------------------------------------------------------
def test_zero_coverage_score_low():
    # who/what/when/where/why/how いずれの keyword も含まない
    text = "この文はごく普通の一文である。特に意味は無い。"
    r = grant_writing_5w1h_coverage(text)

    obs = r["observations"]
    assert obs["coverage_count"] == 0
    assert set(obs["missing_axes"]) == {"who", "what", "when", "where", "why", "how"}
    assert obs["covered_axes"] == []

    # score は 0 または極めて低い
    assert r["score"] <= 1.0

    # 低カバー警告コメントが出ている
    joined = "\n".join(r["comments"])
    assert "低い" in joined or "不在" in joined or "不明" in joined or "無い" in joined


# ------------------------------------------------------------------
# Case 4: Short text (<100 chars) — no crash, observations populated
# ------------------------------------------------------------------
def test_short_text_no_crash():
    text = "短い文。"
    r = grant_writing_5w1h_coverage(text)

    # 構造は保たれる
    assert "score" in r
    assert "comments" in r
    assert "observations" in r

    obs = r["observations"]
    # 全キーが揃っていること
    assert "scan_chars_analyzed" in obs
    assert "coverage" in obs
    assert "covered_axes" in obs
    assert "missing_axes" in obs
    assert "coverage_count" in obs

    # coverage に 6 軸全てのキーがある
    assert set(obs["coverage"].keys()) == {"who", "what", "when", "where", "why", "how"}

    # scan_chars_analyzed は実際のテキスト長以下
    assert obs["scan_chars_analyzed"] == len(text)

    # comments は少なくとも 2 つ
    assert len(r["comments"]) >= 2


def test_empty_text_no_crash():
    r = grant_writing_5w1h_coverage("")
    obs = r["observations"]
    assert obs["scan_chars_analyzed"] == 0
    assert obs["coverage_count"] == 0
    assert set(obs["coverage"].keys()) == {"who", "what", "when", "where", "why", "how"}
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Additional: hint / source fixed content
# ------------------------------------------------------------------
def test_hint_and_source_content():
    r = grant_writing_5w1h_coverage("テスト本文。")
    assert "keyword" in r["hint"]
    assert "T12" in r["hint"] or "併用" in r["hint"]
    assert "skill.md" in r["source"]
    assert "5/6" in r["source"] or "5W1H" in r["source"]


# ------------------------------------------------------------------
# scan_chars parameter is honored
# ------------------------------------------------------------------
def test_scan_chars_limits_analysis():
    # 冒頭 50 字には「申請者」だけ、50 字以降に他が来る例
    text = "申請者が居る。" + "あ" * 100 + "令和6年度に大学で解析を手法を用いて行う。"
    r_short = grant_writing_5w1h_coverage(text, scan_chars=30)
    r_long = grant_writing_5w1h_coverage(text, scan_chars=500)

    # scan_chars が狭いほど coverage_count は小さい (<=)
    assert r_short["observations"]["coverage_count"] <= r_long["observations"]["coverage_count"]
    # 長いスキャンの方が多くカバーする
    assert r_long["observations"]["coverage_count"] >= 3
