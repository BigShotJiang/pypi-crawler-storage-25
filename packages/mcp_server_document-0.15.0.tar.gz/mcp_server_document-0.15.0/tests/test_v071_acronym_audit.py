"""Tests for v0.7.2 grant_writing_acronym_usage_audit tool.

Rule (2026-04-22): first occurrence uses full form `expansion (ACRONYM)`;
abbreviation allowed from 2nd occurrence; if count < min_uses_for_abbrev,
recommend dropping the abbreviation entirely.
"""
from mcp_server_document.grant_writing.tools import (
    grant_writing_acronym_usage_audit,
)


def test_ok_when_expansion_first_and_enough_uses():
    text = ("Effective Surface Impedance Method (ESIM) を用いる。"
            "ESIM は高速計算が可能。さらに ESIM を拡張する。")
    r = grant_writing_acronym_usage_audit(text)
    esim = next(f for f in r["findings"] if f["acronym"] == "ESIM")
    assert esim["count"] == 3
    assert esim["first_form"] == "expansion"
    assert esim["verdict"] == "ok"
    assert r["summary_counts"]["ok"] >= 1


def test_fix_first_use_when_acronym_first():
    text = ("ESIM を用いる。ESIM は高速計算が可能。"
            "さらに ESIM を拡張して評価する。")
    r = grant_writing_acronym_usage_audit(text)
    esim = next(f for f in r["findings"] if f["acronym"] == "ESIM")
    assert esim["count"] == 3
    assert esim["first_form"] == "acronym"
    assert esim["verdict"] == "fix_first_use"
    assert r["summary_counts"]["fix_first_use"] >= 1


def test_drop_abbrev_when_few_uses():
    text = "本研究では POD を単発で使用する。"
    r = grant_writing_acronym_usage_audit(text)
    pod = next(f for f in r["findings"] if f["acronym"] == "POD")
    assert pod["count"] == 1
    assert pod["verdict"] == "drop_abbrev"


def test_whitelist_skips_known_acronyms():
    text = ("IEEE TMAG への投稿を予定。JSPS 申請も進める。"
            "PDF 出力は問題ない。IEEE は複数回登場する。")
    r = grant_writing_acronym_usage_audit(text)
    names = {f["acronym"] for f in r["findings"]}
    # IEEE/JSPS/PDF should be whitelisted by default
    assert "IEEE" not in names
    assert "JSPS" not in names
    assert "PDF" not in names


def test_custom_min_uses_threshold():
    text = ("POD を 2 回使う。POD は便利。MSFEM は 1 回のみ。")
    r_default = grant_writing_acronym_usage_audit(text)  # min_uses=3
    pod_default = next(f for f in r_default["findings"] if f["acronym"] == "POD")
    assert pod_default["verdict"] == "drop_abbrev"  # 2 < 3 → drop

    r_lax = grant_writing_acronym_usage_audit(text, min_uses_for_abbrev=2)
    pod_lax = next(f for f in r_lax["findings"] if f["acronym"] == "POD")
    assert pod_lax["verdict"] != "drop_abbrev"  # 2 >= 2 → not drop


def test_user_whitelist():
    text = "ESIM を導入。ESIM の拡張。ESIM 評価。"
    r = grant_writing_acronym_usage_audit(text, whitelist="ESIM")
    assert all(f["acronym"] != "ESIM" for f in r["findings"])
