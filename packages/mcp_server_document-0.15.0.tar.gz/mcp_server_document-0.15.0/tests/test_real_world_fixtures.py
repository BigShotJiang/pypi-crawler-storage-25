"""Real-world fixture smoke tests (v0.14.0).

合成だが現実的な grant / paper / pptx fixture を構築し、
health_report + 主要 tools を通す end-to-end テスト。
目的:
  - v0.14.0 以降の regression を 1 コマンドで検出
  - 実運用前の「全ツールが crash せず、妥当な score を返す」保証
  - 実申請書 / 実論文に対して tools を走らせた時の挙動をプレビュー

実際の手元文書ではなく、典型構造を再現した synthetic fixture。
テンプレはユーザー CLAUDE.md (菅原研、近畿大学、電磁界解析、国産 OSS) の
文脈に合わせた内容。
"""
from __future__ import annotations

import pytest


# ==================================================================
# Fixture 1: JSPS 短期招へい申請書 (tex)
# ==================================================================
GRANT_TEX_FIXTURE = r"""
\section{招へい目的}
LLM が呼び出せる国産 OSS 電磁界ソルバを、日本発の文法で国際標準層に
打ち立てる——本研究はその学術基盤の確立である。

これまで三菱電機株式会社で 14 年にわたり電磁界解析を担当してきた。
500 kHz IH コイルの設計案件で、CAD 準備に 3 日、ソルバ実行に 2 時間を
要した経験から、統合的設計環境の必要性を痛感した。さらに本研究では、
AI 自律設計環境としての展開を目指す。

\section{共同研究者}
近畿大学の山田太郎教授が解析を担当する。
Adam Johnson 博士 (ETH Zurich) が国際連携を主導する。
申請者は本研究の総括と実装を担当する。

\section{スケジュール}
\begin{itemize}
\item 令和6年度: 基礎検討、既存 OSS レビュー
\item 令和7年度: プロトタイプ実装、中間報告
\item 令和8年度: 実証実験、論文投稿、完成
\end{itemize}

\section{予算}
\begin{tabular}{|l|r|}
\hline
物品費 & 80万円 \\
旅費 & 40万円 \\
人件費 & 30万円 \\
その他 & 10万円 \\
合計 & 160万円 \\
\hline
\end{tabular}

\section{本研究が拓く景色}
Motor 領域で JMAG + MotorAI が実証した国産 CAE × AI 自律設計の熟成曲線を、
PCB 領域で再現する。採択後は継続的な共同研究へと展開し、
国際標準層へ波及させる。
"""


# ==================================================================
# Fixture 2: IEEE Transactions 論文 (tex) + bib
# ==================================================================
PAPER_TEX_FIXTURE = r"""
\section{Introduction}
Recent advances in computational electromagnetics have been substantial.
Many existing methods suffer from high computational cost.

We propose a novel surface impedance method (SIM) that reduces
simulation time by 3.2x compared to conventional FEM \cite{ref1,ref2,ref3}.
As shown in Fig.~\ref{fig:arch}, our approach integrates LLM-callable
Python bindings with C++ numerical core.

Our contributions are:
\begin{itemize}
\item We propose SIM with 4th-order accuracy \cite{ref4}.
\item We demonstrate 3.2x speedup on 500 kHz IH coil benchmarks.
\item We provide an open-source implementation at github.com/xxx.
\end{itemize}

\section{Method}
The method consists of three stages. First, surface mesh is generated.
Second, impedance is computed from \eqref{eq:imp}.
\begin{equation}
Z_s = \sqrt{j\omega\mu/\sigma} \label{eq:imp}
\end{equation}
Third, fields are recovered via \eqref{eq:imp}.

\begin{figure}
\caption{System architecture showing LLM-C++ bridge.}
\label{fig:arch}
\end{figure}

\section{Results}
Table~\ref{tab:benchmark} shows benchmark results. SIM achieves
3.2x speedup with 2.1% error compared to reference FEM.

\begin{table}
\caption{Benchmark comparison}
\label{tab:benchmark}
\end{table}

\section{Discussion}
SIM has several limitations. First, it assumes linear materials.
Second, mesh quality impacts accuracy — we observed 5% error
degradation when mesh size exceeds skin depth. Third, the method
has not been validated beyond 1 MHz.

Despite these limitations, SIM fills an important gap in
open-source EM simulation tools.

\section{Conclusion}
We proposed SIM, demonstrated 3.2x speedup, and released it as OSS.
Future work includes nonlinear extension.
"""

PAPER_BIB_FIXTURE = """
@article{ref1,
  author = {Smith, J. and Doe, A.},
  title = {Surface impedance in CEM},
  journal = {IEEE Trans. Magn.},
  year = {2023},
  volume = {59},
  pages = {1-10},
  url = {https://doi.org/10.1109@example.1234}
}
@article{ref2,
  author = {Tanaka, H. and Yamada, K.},
  title = {FEM methods},
  journal = {IEEJ Trans. FM},
  year = {2022}
}
@article{ref3,
  author = {Sugahara, K.},
  title = {Prior work by author},
  journal = {IEEE TMAG},
  year = {2024}
}
@article{ref4,
  author = {Wang, L. and Chen, X.},
  title = {Higher-order methods},
  journal = {J. Comput. Phys.},
  year = {2025}
}
"""

PAPER_ABSTRACT_FIXTURE = (
    "We propose a surface impedance method (SIM) for fast electromagnetic "
    "simulation. SIM reduces computational cost by 3.2x while maintaining "
    "2.1% error. The method is released as open-source to enable LLM-based "
    "autonomous design. We demonstrate SIM on 500 kHz IH coil benchmarks."
)


# ==================================================================
# Grant health_report smoke test
# ==================================================================
class TestGrantFixture:
    def test_health_report_runs(self):
        """grant_writing_health_report が fixture で crash せず妥当な
        score を返すこと。"""
        from mcp_server_document.grant_writing.plan_b_T16 import (
            grant_writing_health_report,
        )
        r = grant_writing_health_report(
            GRANT_TEX_FIXTURE, applicant_name="申請者"
        )
        assert "overall_score" in r
        assert 0 <= r["overall_score"] <= 10
        assert r["overall_severity"] in ("CRITICAL", "HIGH", "MEDIUM", "LOW")
        # 共同研究者が 3 人 (山田教授 / Adam Johnson 博士 / 申請者) で役割動詞近接
        # → T12 score は高いはず
        details = r["detailed_scores"]
        assert "T12" in details
        # 予算合計と積み上げが整合 → T13 は high
        assert details.get("T13", 0) >= 5
        # スケジュール令和6-8 + マイルストーン → T14 は high
        assert details.get("T14", 0) >= 6

    def test_hook_strength_runs(self):
        from mcp_server_document.grant_writing.plan_b_T8 import (
            grant_writing_hook_strength,
        )
        r = grant_writing_hook_strength(GRANT_TEX_FIXTURE)
        # 「500 kHz」「14 年」「三菱電機」「近畿大学」があるので
        # has_digit + has_concrete_locus True
        assert r["observations"]["has_digit_in_hook"] is True
        assert r["observations"]["has_concrete_locus"] is True

    def test_uline_check_on_grant_fixture(self, tmp_path):
        """uline overflow check が grant fixture で crash しない。"""
        from mcp_server_document.grant_writing.plan_b_T22 import (
            grant_writing_check_uline_overflow_risk,
        )
        tex = tmp_path / "g.tex"
        tex.write_text(GRANT_TEX_FIXTURE, encoding="utf-8")
        r = grant_writing_check_uline_overflow_risk(str(tex))
        # fixture に \uline が無いので total_underlines == 0
        assert r["observations"]["total_underlines"] == 0
        assert r["score"] == 10.0


# ==================================================================
# Paper health_report smoke test
# ==================================================================
class TestPaperFixture:
    def test_abstract_strength_runs(self):
        from mcp_server_document.paper_writing.plan_b_T1 import (
            paper_writing_abstract_strength,
        )
        r = paper_writing_abstract_strength(
            PAPER_ABSTRACT_FIXTURE, language="en"
        )
        # 4 要素揃った abstract なので score は高め
        assert r["score"] >= 5
        obs = r["observations"]
        assert obs["has_method"] is True
        assert obs["has_quantitative_result"] is True

    def test_contribution_clarity_runs(self):
        from mcp_server_document.paper_writing.plan_b_T2 import (
            paper_writing_contribution_clarity_score,
        )
        r = paper_writing_contribution_clarity_score(PAPER_TEX_FIXTURE)
        # \begin{itemize} + We propose / demonstrate / provide → 3 item +
        # claim verbs 3 以上
        assert r["observations"].get("item_count", 0) >= 3
        claim_verbs = r["observations"].get("claim_verbs_found", [])
        assert len(claim_verbs) >= 2

    def test_claim_quantification_runs(self):
        from mcp_server_document.paper_writing.plan_b_T3 import (
            paper_writing_claim_quantification,
        )
        r = paper_writing_claim_quantification(PAPER_TEX_FIXTURE)
        assert "unquantified_count" in r["observations"]

    def test_limitation_statement_detected(self):
        from mcp_server_document.paper_writing.plan_b_T4 import (
            paper_writing_limitation_statement_presence,
        )
        r = paper_writing_limitation_statement_presence(PAPER_TEX_FIXTURE)
        assert r["observations"]["discussion_found"] is True
        assert len(r["observations"]["limitation_paragraphs"]) >= 1

    def test_figure_referencing_coverage(self):
        from mcp_server_document.paper_writing.plan_b_T6 import (
            paper_writing_figure_referencing_coverage,
        )
        r = paper_writing_figure_referencing_coverage(PAPER_TEX_FIXTURE)
        # fig:arch と tab:benchmark 両方 \ref されている
        assert r["observations"]["total_labels"] >= 2
        assert len(r["observations"]["unreferenced_labels"]) == 0


# ==================================================================
# Presentation smoke test (synthetic pptx)
# ==================================================================
class TestPresentationFixture:
    @pytest.fixture
    def pptx_path(self, tmp_path):
        pptx = pytest.importorskip("pptx")
        from pptx.util import Inches, Pt
        prs = pptx.Presentation()
        # Slide 1: title with digit + locus
        slide1 = prs.slides.add_slide(prs.slide_layouts[0])
        slide1.shapes.title.text = "年間 120 億円の商用 CAE を国産 OSS で置換"
        slide1.placeholders[1].text = (
            "三菱電機の 500 kHz IH コイル設計案件で培った経験を活かす"
        )
        # Slide 2: Outline
        slide2 = prs.slides.add_slide(prs.slide_layouts[1])
        slide2.shapes.title.text = "Outline"
        slide2.placeholders[1].text = "1. 背景\n2. 手法\n3. 結果\n4. まとめ"
        # Slide 3-5: content
        for i in range(3):
            s = prs.slides.add_slide(prs.slide_layouts[1])
            s.shapes.title.text = f"Section {i+1}"
            s.placeholders[1].text = f"内容 {i+1} の簡潔な説明。"
        # Slide 6: takehome
        slide_t = prs.slides.add_slide(prs.slide_layouts[1])
        slide_t.shapes.title.text = "Take-home"
        slide_t.placeholders[1].text = (
            "提案手法は 3.2× 高速化を実現。国産 OSS で配布。"
        )
        # Slide 7: Q&A
        slide_qa = prs.slides.add_slide(prs.slide_layouts[1])
        slide_qa.shapes.title.text = "Q&A"
        path = tmp_path / "deck.pptx"
        prs.save(str(path))
        return str(path)

    def test_hook_runs(self, pptx_path):
        from mcp_server_document.presentation.plan_b_T1 import (
            presentation_opening_hook_strength,
        )
        r = presentation_opening_hook_strength(pptx_path)
        # "120 億円" 数値 + 三菱電機 locus
        assert r["observations"].get("has_digit_in_opening") is True

    def test_takehome_detected(self, pptx_path):
        from mcp_server_document.presentation.plan_b_T2 import (
            presentation_takehome_strength,
        )
        r = presentation_takehome_strength(pptx_path)
        # Q&A が最終なので take-home は 1 つ前 (Take-home slide)
        assert r["observations"]["takehome_slide_idx"] >= 0

    def test_progress_indicator_found(self, pptx_path):
        from mcp_server_document.presentation.plan_b_T5 import (
            presentation_check_progress_indicator,
        )
        r = presentation_check_progress_indicator(pptx_path)
        # Outline slide が存在
        assert len(r["observations"]["section_header_indices"]) >= 1

    def test_no_pie_3d(self, pptx_path):
        from mcp_server_document.presentation.plan_b_T3 import (
            presentation_check_pie_3d_charts,
        )
        r = presentation_check_pie_3d_charts(pptx_path)
        # fixture に chart が無い
        assert r["observations"]["total_charts"] == 0
