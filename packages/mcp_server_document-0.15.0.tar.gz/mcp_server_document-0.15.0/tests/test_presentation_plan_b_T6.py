"""Tests for Plan B T6: presentation_visual_text_ratio_score.

4 cases:
1. balanced_deck — visual_ratio around 0.3-0.7, no crowded slides
2. text_heavy_deck — visual_ratio < 0.3 on all slides, low score + penalty
3. image_heavy_deck — visual_ratio > 0.7, image_heavy_count > half
4. empty_deck — total_slides == 0, score = 10

Assertions focus on `observations` keys (text_heavy_count / image_heavy_count /
median_visual_ratio / crowded_slides) and substrings in `comments`.
Numeric score checked only as inequalities (not exact).
"""
from __future__ import annotations

import base64
import pathlib

import pytest


# 1x1 red pixel PNG (base64 encoded)
PNG_BYTES = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk"
    "YAAAAAYAAjCB0C8AAAAASUVORK5CYII="
)


def _write_dot_png(tmp_path: pathlib.Path) -> pathlib.Path:
    img_path = tmp_path / "dot.png"
    img_path.write_bytes(PNG_BYTES)
    return img_path


def _add_textbox(slide, left_emu, top_emu, width_emu, height_emu, text):
    from pptx.util import Emu
    box = slide.shapes.add_textbox(
        Emu(left_emu), Emu(top_emu), Emu(width_emu), Emu(height_emu)
    )
    box.text_frame.text = text
    return box


# ------------------------------------------------------------------
# Case 1: balanced deck — text and image roughly comparable per slide
# ------------------------------------------------------------------
def test_balanced_deck(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Emu
    from mcp_server_document.presentation.plan_b_T6 import (
        presentation_visual_text_ratio_score,
    )

    img = _write_dot_png(tmp_path)
    prs = Presentation()
    blank = prs.slide_layouts[6]  # Blank

    # 3 slides each with ~equal image and text shape area
    # image area: 2_000_000 * 2_000_000 = 4e12
    # text area : 2_000_000 * 2_000_000 = 4e12  -> ratio ~= 0.5
    for _ in range(3):
        slide = prs.slides.add_slide(blank)
        slide.shapes.add_picture(
            str(img),
            left=Emu(500_000),
            top=Emu(500_000),
            width=Emu(2_000_000),
            height=Emu(2_000_000),
        )
        _add_textbox(
            slide,
            3_000_000, 500_000,
            2_000_000, 2_000_000,
            "short caption",
        )

    out = tmp_path / "balanced.pptx"
    prs.save(str(out))

    r = presentation_visual_text_ratio_score(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 3
    assert len(obs["per_slide_stats"]) == 3
    # Every slide has both area > 0
    for s in obs["per_slide_stats"]:
        assert s["image_area_emu"] > 0
        assert s["text_area_emu"] > 0
        assert 0.3 <= s["visual_ratio"] <= 0.7
    # No text-crowded slides
    assert obs["text_heavy_count"] == 0
    # Not overwhelmingly image-heavy either
    assert obs["image_heavy_count"] <= 1
    assert 0.3 <= obs["median_visual_ratio"] <= 0.7
    # score is mid-range, not penalised
    assert r["score"] >= 3
    assert r["score"] <= 8

    joined = "\n".join(r["comments"])
    # balanced-deck comment should fire
    assert "Zen" in joined or "balance" in joined or "crowded slide なし" in joined


# ------------------------------------------------------------------
# Case 2: text-heavy deck — big text box + tiny picture on every slide
# ------------------------------------------------------------------
def test_text_heavy_deck(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Emu
    from mcp_server_document.presentation.plan_b_T6 import (
        presentation_visual_text_ratio_score,
    )

    img = _write_dot_png(tmp_path)
    prs = Presentation()
    blank = prs.slide_layouts[6]

    # 5 slides with dominant text box + tiny picture
    # image: 100_000 * 100_000 = 1e10
    # text : 5_000_000 * 5_000_000 = 2.5e13 -> ratio << 0.3
    for i in range(5):
        slide = prs.slides.add_slide(blank)
        slide.shapes.add_picture(
            str(img),
            left=Emu(100_000),
            top=Emu(100_000),
            width=Emu(100_000),
            height=Emu(100_000),
        )
        _add_textbox(
            slide,
            500_000, 500_000,
            5_000_000, 5_000_000,
            f"slide {i + 1} bullet 1\nbullet 2\nbullet 3\n" + ("x" * 200),
        )

    out = tmp_path / "text_heavy.pptx"
    prs.save(str(out))

    r = presentation_visual_text_ratio_score(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 5
    # All slides are text-heavy
    assert obs["text_heavy_count"] == 5
    assert obs["image_heavy_count"] == 0
    assert obs["median_visual_ratio"] < 0.3
    # Crowded_slides up to 3
    assert len(obs["crowded_slides"]) == 3
    # Score low, penalty applied (>0.5 text-heavy)
    assert r["score"] <= 4, r

    joined = "\n".join(r["comments"])
    # text-crowded warning
    assert "text-crowded" in joined
    assert "Reynolds Zen" in joined or "1 slide = 1 visual" in joined


# ------------------------------------------------------------------
# Case 3: image-heavy deck — picture dominates, minimal text
# ------------------------------------------------------------------
def test_image_heavy_deck(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Emu
    from mcp_server_document.presentation.plan_b_T6 import (
        presentation_visual_text_ratio_score,
    )

    img = _write_dot_png(tmp_path)
    prs = Presentation()
    blank = prs.slide_layouts[6]

    # 4 slides with large picture, no text
    for _ in range(4):
        slide = prs.slides.add_slide(blank)
        slide.shapes.add_picture(
            str(img),
            left=Emu(500_000),
            top=Emu(500_000),
            width=Emu(7_000_000),
            height=Emu(5_000_000),
        )

    out = tmp_path / "image_heavy.pptx"
    prs.save(str(out))

    r = presentation_visual_text_ratio_score(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 4
    assert obs["image_heavy_count"] == 4
    assert obs["text_heavy_count"] == 0
    assert obs["median_visual_ratio"] > 0.7
    # Score high (median * 10 ~ 10), no penalty
    assert r["score"] >= 7

    joined = "\n".join(r["comments"])
    # image-heavy warning (since > half)
    assert "image-heavy" in joined or "image で置換できない" in joined


# ------------------------------------------------------------------
# Case 4: empty deck — score = 10, no crash
# ------------------------------------------------------------------
def test_empty_deck(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T6 import (
        presentation_visual_text_ratio_score,
    )

    prs = Presentation()
    out = tmp_path / "empty.pptx"
    prs.save(str(out))

    r = presentation_visual_text_ratio_score(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 0
    assert obs["per_slide_stats"] == []
    assert obs["crowded_slides"] == []
    assert obs["median_visual_ratio"] == 0.0
    assert obs["text_heavy_count"] == 0
    assert obs["image_heavy_count"] == 0
    assert r["score"] == 10.0
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Structural contract: hint / source / score_max
# ------------------------------------------------------------------
def test_hint_and_source_content(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T6 import (
        presentation_visual_text_ratio_score,
    )

    prs = Presentation()
    prs.slides.add_slide(prs.slide_layouts[6])
    out = tmp_path / "one.pptx"
    prs.save(str(out))

    r = presentation_visual_text_ratio_score(str(out))
    assert r["score_max"] == 10
    assert "hint" in r and "EMU" in r["hint"]
    assert "source" in r
    assert "Reynolds" in r["source"] or "Zen" in r["source"]
    assert "宮野" in r["source"]


# ------------------------------------------------------------------
# Error path: missing file
# ------------------------------------------------------------------
def test_missing_file_returns_default(tmp_path):
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T6 import (
        presentation_visual_text_ratio_score,
    )

    ghost = tmp_path / "does_not_exist.pptx"
    r = presentation_visual_text_ratio_score(str(ghost))
    # Matches T4 pattern: graceful return with default score / empty obs
    assert r["score"] == 10.0
    obs = r["observations"]
    assert obs["total_slides"] == 0
    assert obs["per_slide_stats"] == []
    joined = "\n".join(r["comments"])
    assert "not found" in joined
