"""Tests for Plan B T7: presentation_speaker_note_ratio.

4 cases:
1. well_prepared_deck — 殆どの slide に note、比率 balanced
2. no_notes_deck — speaker note 全く無し
3. script_heavy_deck — note が slide text の 5 倍超
4. mixed — 一部の slide だけに note

Assertions focus on `observations` keys and `comments` substrings;
numeric score values are only checked as inequalities (not exact).
"""
from __future__ import annotations

import pathlib

import pytest


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _make_slide(prs, layout_idx: int, title: str, body: str | None = None,
                note: str | None = None):
    """Add a slide to *prs* and optionally fill title/body/note."""
    slide = prs.slides.add_slide(prs.slide_layouts[layout_idx])
    for ph in slide.placeholders:
        try:
            if ph.placeholder_format.idx == 0:
                ph.text = title
            elif body is not None:
                ph.text = body
        except Exception:
            continue
    if note is not None:
        try:
            ns = slide.notes_slide
            ns.notes_text_frame.text = note
        except Exception:
            pass
    return slide


# ------------------------------------------------------------------
# Case 1: well_prepared_deck — note coverage high, balanced ratio
# ------------------------------------------------------------------
def test_well_prepared_deck(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T7 import (
        presentation_speaker_note_ratio,
    )

    prs = Presentation()
    # body ~30 chars, note ~60 chars -> ratio ~2.0 (balanced)
    body = "bullet one about method\nbullet two about method"
    note = (
        "ここで method の詳細を語る。"
        "audience が理解しやすいよう具体例を挟む。"
        "時間は 1 分を目安に。"
    )
    for i in range(5):
        _make_slide(prs, 1, f"Slide {i + 1}", body, note)

    out = tmp_path / "well_prepared.pptx"
    prs.save(str(out))

    r = presentation_speaker_note_ratio(str(out))
    assert "error" not in r, r

    obs = r["observations"]
    assert obs["total_slides"] == 5
    assert obs["slides_with_notes"] == 5
    assert obs["slides_without_notes"] == 0
    assert obs["notes_ratio_coverage"] == 1.0
    assert 1.0 <= obs["mean_note_to_slide_ratio"] <= 5.0, obs
    assert obs["overly_note_heavy_slides"] == []
    assert len(obs["per_slide_ratios"]) == 5

    # balanced comment
    joined = "\n".join(r["comments"])
    assert "発表準備として適切" in joined

    # score: +5 (coverage) +3 (balanced) = 8
    assert r["score"] >= 7


# ------------------------------------------------------------------
# Case 2: no_notes_deck — speaker note 全く無し
# ------------------------------------------------------------------
def test_no_notes_deck(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T7 import (
        presentation_speaker_note_ratio,
    )

    prs = Presentation()
    for i in range(4):
        _make_slide(prs, 1, f"Slide {i + 1}", f"body {i + 1}")

    out = tmp_path / "no_notes.pptx"
    prs.save(str(out))

    r = presentation_speaker_note_ratio(str(out))
    assert "error" not in r, r

    obs = r["observations"]
    assert obs["total_slides"] == 4
    assert obs["slides_with_notes"] == 0
    assert obs["slides_without_notes"] == 4
    assert obs["notes_ratio_coverage"] == 0.0
    assert obs["mean_note_to_slide_ratio"] == 0.0
    assert obs["overly_note_heavy_slides"] == []

    joined = "\n".join(r["comments"])
    assert "speaker note 全く無し" in joined

    # score: coverage 0 (<0.3) -> no +5; mean 0 -> no +3 => 0
    assert r["score"] <= 3


# ------------------------------------------------------------------
# Case 3: script_heavy_deck — note が slide text の 5 倍超
# ------------------------------------------------------------------
def test_script_heavy_deck(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T7 import (
        presentation_speaker_note_ratio,
    )

    prs = Presentation()
    # Short body (~5 chars), long note (~100 chars) -> ratio >> 5
    short_body = "要点"
    long_note = (
        "ここでは非常に長い台本を記述します。"
        "audience に向けて話す内容をすべて書き下しているため、"
        "発表者はこれを読み上げる形になってしまう risk があります。"
        "本来は bullet 化すべき情報量です。"
    )
    for i in range(6):
        _make_slide(prs, 1, f"Slide {i + 1}", short_body, long_note)

    out = tmp_path / "script_heavy.pptx"
    prs.save(str(out))

    r = presentation_speaker_note_ratio(str(out))
    assert "error" not in r, r

    obs = r["observations"]
    assert obs["total_slides"] == 6
    assert obs["slides_with_notes"] == 6
    # all should be flagged as overly note heavy (ratio > 5)
    assert len(obs["overly_note_heavy_slides"]) == 6
    assert obs["mean_note_to_slide_ratio"] > 5.0

    joined = "\n".join(r["comments"])
    assert "台本朗読型" in joined
    assert "note が slide text の 5 倍超" in joined

    # score: +5 (coverage) +0 (mean > 5 not in [1,5]) -2 (heavy > 30%) = 3
    assert r["score"] <= 4


# ------------------------------------------------------------------
# Case 4: mixed — 一部の slide だけに note
# ------------------------------------------------------------------
def test_mixed_deck(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T7 import (
        presentation_speaker_note_ratio,
    )

    prs = Presentation()
    body = "bullet one\nbullet two"
    note = "ここで background を説明。先行研究との関係を述べる。"
    # 2 with notes, 3 without -> coverage = 0.4
    _make_slide(prs, 1, "Intro", body, note)
    _make_slide(prs, 1, "Background", body, note)
    _make_slide(prs, 1, "Method", body)
    _make_slide(prs, 1, "Result", body)
    _make_slide(prs, 1, "Conclusion", body)

    out = tmp_path / "mixed.pptx"
    prs.save(str(out))

    r = presentation_speaker_note_ratio(str(out))
    assert "error" not in r, r

    obs = r["observations"]
    assert obs["total_slides"] == 5
    assert obs["slides_with_notes"] == 2
    assert obs["slides_without_notes"] == 3
    assert obs["notes_ratio_coverage"] == 0.4

    # per_slide_ratios list shape
    assert len(obs["per_slide_ratios"]) == 5
    for entry in obs["per_slide_ratios"]:
        assert "idx" in entry
        assert "slide_char_count" in entry
        assert "note_char_count" in entry
        assert "note_to_slide_ratio" in entry

    # notes-bearing slides must have non-zero note_char_count
    assert obs["per_slide_ratios"][0]["note_char_count"] > 0
    assert obs["per_slide_ratios"][2]["note_char_count"] == 0

    # score: +5 (coverage >= 0.3). mean_ratio depends on bodies — just
    # check it's a reasonable float.
    assert r["score"] >= 4


# ------------------------------------------------------------------
# Structural / hint-source contract
# ------------------------------------------------------------------
def test_hint_and_source_content(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T7 import (
        presentation_speaker_note_ratio,
    )

    prs = Presentation()
    _make_slide(prs, 1, "x", "y")
    out = tmp_path / "tiny.pptx"
    prs.save(str(out))

    r = presentation_speaker_note_ratio(str(out))
    assert r["score_max"] == 10
    assert "hint" in r
    assert "notes_text_frame" in r["hint"]
    assert "source" in r
    assert "木下" in r["source"] or "宮野" in r["source"]


# ------------------------------------------------------------------
# Empty deck — no crash
# ------------------------------------------------------------------
def test_empty_deck_no_crash(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T7 import (
        presentation_speaker_note_ratio,
    )

    prs = Presentation()
    out = tmp_path / "empty.pptx"
    prs.save(str(out))

    r = presentation_speaker_note_ratio(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 0
    assert obs["slides_with_notes"] == 0
    assert obs["slides_without_notes"] == 0
    assert obs["notes_ratio_coverage"] == 0.0
    assert obs["per_slide_ratios"] == []
    assert obs["mean_note_to_slide_ratio"] == 0.0
    assert obs["overly_note_heavy_slides"] == []
    assert r["score"] == 10.0
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Error path: missing file
# ------------------------------------------------------------------
def test_missing_file_returns_error(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T7 import (
        presentation_speaker_note_ratio,
    )

    ghost = tmp_path / "does_not_exist.pptx"
    r = presentation_speaker_note_ratio(str(ghost))
    assert "error" in r
    assert "not found" in r["error"]
