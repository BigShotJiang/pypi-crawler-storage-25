"""Tests for Plan B T10: presentation_check_underline_in_pptx.

4 cases:
1. No underlines (clean deck) — score 10, comments clean
2. Moderate: 3-6 underlines across deck — score stays high
3. Excessive single slide: 5+ underlines on one slide — over_threshold fires
4. Excessive deck: > 10 underlines scattered — deck-wide warning fires

Assertions focus on observations keys and comment substrings;
numeric score values are only checked as inequalities.
"""
from __future__ import annotations

import pathlib

import pytest


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _add_slide_with_runs(prs, layout_idx: int, title: str,
                          run_specs: list[tuple[str, bool]]):
    """Add a slide and populate a textbox with runs.

    ``run_specs`` is a list of ``(text, underlined)`` pairs.
    """
    from pptx.util import Inches

    slide = prs.slides.add_slide(prs.slide_layouts[layout_idx])
    for ph in slide.placeholders:
        try:
            if ph.placeholder_format.idx == 0:
                ph.text = title
        except Exception:
            continue
    tb = slide.shapes.add_textbox(Inches(1), Inches(2), Inches(6), Inches(3))
    tf = tb.text_frame
    para = tf.paragraphs[0]
    for text, underlined in run_specs:
        run = para.add_run()
        run.text = text
        if underlined:
            run.font.underline = True
        else:
            # leave as None (inherit default) — treated as not underlined
            pass
    return slide


# ------------------------------------------------------------------
# Case 1: No underlines — clean
# ------------------------------------------------------------------
def test_no_underlines_clean_deck(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T10 import (
        presentation_check_underline_in_pptx,
    )

    prs = Presentation()
    for i in range(5):
        _add_slide_with_runs(
            prs, 1, f"Slide {i + 1}",
            [("no emphasis here", False), (" plain text", False)],
        )

    out = tmp_path / "clean.pptx"
    prs.save(str(out))

    r = presentation_check_underline_in_pptx(str(out))
    assert "error" not in r.get("observations", {}), r
    obs = r["observations"]
    assert obs["total_slides"] == 5
    assert obs["total_underlined_runs"] == 0
    assert obs["per_slide_underline_count"] == [0, 0, 0, 0, 0]
    assert obs["over_threshold_slides"] == []
    assert obs["total_underline_density"] == 0.0
    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    assert "適正" in joined or "emphasis" in joined


# ------------------------------------------------------------------
# Case 2: Moderate (1 underline per slide * 4 slides = 4 total) — high score
# ------------------------------------------------------------------
def test_moderate_underline_count(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T10 import (
        presentation_check_underline_in_pptx,
    )

    prs = Presentation()
    for i in range(4):
        _add_slide_with_runs(
            prs, 1, f"Slide {i + 1}",
            [("key", True), (" body text", False)],
        )

    out = tmp_path / "moderate.pptx"
    prs.save(str(out))

    r = presentation_check_underline_in_pptx(str(out))
    obs = r["observations"]
    assert obs["total_slides"] == 4
    assert obs["total_underlined_runs"] == 4
    assert obs["per_slide_underline_count"] == [1, 1, 1, 1]
    assert obs["over_threshold_slides"] == []
    # 4 / 4 = 1.0 underlines per slide — well within budget
    assert obs["total_underline_density"] == 1.0
    assert r["score"] >= 8

    joined = "\n".join(r["comments"])
    assert "適正" in joined


# ------------------------------------------------------------------
# Case 3: Excessive single slide — 5 underlines on one slide
# ------------------------------------------------------------------
def test_excessive_single_slide(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T10 import (
        presentation_check_underline_in_pptx,
    )

    prs = Presentation()
    # slide 1: 5 underlines (over threshold >= 4)
    _add_slide_with_runs(
        prs, 1, "busy slide",
        [
            ("one", True), (" ", False),
            ("two", True), (" ", False),
            ("three", True), (" ", False),
            ("four", True), (" ", False),
            ("five", True),
        ],
    )
    # slides 2-3: clean
    for i in range(2):
        _add_slide_with_runs(
            prs, 1, f"Clean {i + 2}",
            [("ok", False)],
        )

    out = tmp_path / "single_excessive.pptx"
    prs.save(str(out))

    r = presentation_check_underline_in_pptx(str(out))
    obs = r["observations"]
    assert obs["total_slides"] == 3
    assert obs["total_underlined_runs"] == 5
    assert obs["per_slide_underline_count"][0] == 5
    # slide 1 is over threshold (>= 4) — 1-indexed
    assert 1 in obs["over_threshold_slides"]
    # Score drops because of over-threshold slide (-1) but total not > 10
    assert r["score"] <= 9

    joined = "\n".join(r["comments"])
    assert "4 個以上" in joined
    assert "slide" in joined.lower() or "slide" in joined


# ------------------------------------------------------------------
# Case 4: Excessive deck — > 10 underlines scattered
# ------------------------------------------------------------------
def test_excessive_deck_wide(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T10 import (
        presentation_check_underline_in_pptx,
    )

    prs = Presentation()
    # 12 slides, each with 1 underline (scattered — not single-slide heavy)
    # 12 > 10 deck total, 12 > 12 * 3? No, 12 = 12 < 36. So only the ">10"
    # branch fires, not the density branch.
    for i in range(12):
        _add_slide_with_runs(
            prs, 1, f"S{i + 1}",
            [("x", True), (" rest", False)],
        )

    out = tmp_path / "deck_excessive.pptx"
    prs.save(str(out))

    r = presentation_check_underline_in_pptx(str(out))
    obs = r["observations"]
    assert obs["total_slides"] == 12
    assert obs["total_underlined_runs"] == 12
    assert obs["over_threshold_slides"] == []

    joined = "\n".join(r["comments"])
    # Deck-wide wallpaper warning should fire
    assert "壁紙化" in joined
    assert "12" in joined


# ------------------------------------------------------------------
# Structural / hint-source contract
# ------------------------------------------------------------------
def test_structure_and_hint_source(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T10 import (
        presentation_check_underline_in_pptx,
    )

    prs = Presentation()
    _add_slide_with_runs(prs, 1, "tiny", [("x", False)])
    out = tmp_path / "tiny.pptx"
    prs.save(str(out))

    r = presentation_check_underline_in_pptx(str(out))
    assert r["score_max"] == 10
    assert "hint" in r and "MSO_TEXT_UNDERLINE_TYPE" in r["hint"]
    assert "source" in r
    assert "S14" in r["source"]
    assert "宮野" in r["source"]
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 5


# ------------------------------------------------------------------
# Empty deck / no crash
# ------------------------------------------------------------------
def test_empty_deck_no_crash(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T10 import (
        presentation_check_underline_in_pptx,
    )

    prs = Presentation()
    out = tmp_path / "empty.pptx"
    prs.save(str(out))

    r = presentation_check_underline_in_pptx(str(out))
    obs = r["observations"]
    assert obs["total_slides"] == 0
    assert obs["total_underlined_runs"] == 0
    assert obs["per_slide_underline_count"] == []
    assert obs["over_threshold_slides"] == []
    assert r["score"] == 10.0
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Error path: missing file
# ------------------------------------------------------------------
def test_missing_file_returns_error(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T10 import (
        presentation_check_underline_in_pptx,
    )

    ghost = tmp_path / "does_not_exist.pptx"
    r = presentation_check_underline_in_pptx(str(ghost))
    assert r["observations"].get("error", "").startswith("file not found")
    # Still a valid Plan B shape
    assert r["score_max"] == 10
    assert isinstance(r["comments"], list)
