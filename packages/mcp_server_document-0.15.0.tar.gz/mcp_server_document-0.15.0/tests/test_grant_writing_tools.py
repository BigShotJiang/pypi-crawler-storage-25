"""Direct tests for grant_writing tools that lacked coverage.

Targets: count_underlines, validate_pdf_pages, check_overfull_hbox,
analyze_sentences, count_weak_expressions, check_misuse_japanese.
"""
import pytest

from mcp_server_document.grant_writing.tools import (
    grant_writing_count_underlines,
    grant_writing_validate_pdf_pages,
    grant_writing_check_overfull_hbox,
    grant_writing_analyze_sentences,
    grant_writing_count_weak_expressions,
    grant_writing_check_misuse_japanese,
)


# ---------- count_underlines ----------
def test_count_underlines_counts_each_macro(tmp_path):
    tex = tmp_path / "a.tex"
    tex.write_text(
        r"\uline{A}\underline{B}\uwave{C}\uline{D}\sout{E}",
        encoding="utf-8",
    )
    r = grant_writing_count_underlines(str(tex))
    assert r["total_underlines"] == 5
    assert r["by_macro"]["uline"] == 2
    assert r["by_macro"]["underline"] == 1
    assert r["by_macro"]["uwave"] == 1
    assert r["by_macro"]["sout"] == 1


def test_count_underlines_empty_file(tmp_path):
    tex = tmp_path / "empty.tex"
    tex.write_text("no underlines here", encoding="utf-8")
    r = grant_writing_count_underlines(str(tex))
    assert r["total_underlines"] == 0
    assert r["by_macro"] == {}


def test_count_underlines_missing_file():
    r = grant_writing_count_underlines("/nonexistent/path.tex")
    assert "error" in r


# ---------- validate_pdf_pages ----------
@pytest.fixture
def mini_pdf(tmp_path):
    pymupdf = pytest.importorskip("pymupdf")
    p = tmp_path / "mini.pdf"
    doc = pymupdf.open()
    doc.new_page()
    doc.new_page()
    doc.new_page()  # 3 pages
    doc.save(str(p))
    doc.close()
    return p


def test_validate_pdf_pages_within_limit(mini_pdf):
    r = grant_writing_validate_pdf_pages(str(mini_pdf), page_limit=5)
    assert r["page_count"] == 3
    assert r["within_limit"] is True
    assert r["pages_over"] == 0


def test_validate_pdf_pages_over_limit(mini_pdf):
    r = grant_writing_validate_pdf_pages(str(mini_pdf), page_limit=2)
    assert r["page_count"] == 3
    assert r["within_limit"] is False
    assert r["pages_over"] == 1


def test_validate_pdf_pages_missing_file():
    r = grant_writing_validate_pdf_pages("/nonexistent.pdf", page_limit=5)
    assert "error" in r


# ---------- check_overfull_hbox ----------
def test_check_overfull_hbox_parses_log(tmp_path):
    log = tmp_path / "a.log"
    log.write_text(
        "Overfull \\hbox (12.3pt too wide) in paragraph at lines 42--45\n"
        "some other junk line\n"
        "Overfull \\hbox (0.5pt too wide) in paragraph at lines 100\n",
        encoding="utf-8",
    )
    r = grant_writing_check_overfull_hbox(str(log))
    assert r["overfull_count"] == 2
    assert any("42" in d["lines"] for d in r["overfull_details"])


def test_check_overfull_hbox_clean_log(tmp_path):
    log = tmp_path / "clean.log"
    log.write_text("no warnings here.", encoding="utf-8")
    r = grant_writing_check_overfull_hbox(str(log))
    assert r["overfull_count"] == 0


def test_check_overfull_hbox_missing_file():
    r = grant_writing_check_overfull_hbox("/nonexistent.log")
    assert "error" in r


# ---------- analyze_sentences ----------
def test_analyze_sentences_basic_stats():
    text = "短い文。" + "あ" * 100 + "。もう一文。"
    r = grant_writing_analyze_sentences(text, max_len=80)
    assert r["total_sentences"] == 3
    assert r["max_length"] >= 100
    assert r["over_threshold_count"] >= 1


def test_analyze_sentences_empty_text():
    r = grant_writing_analyze_sentences("")
    assert "error" in r


def test_analyze_sentences_no_delimiter_treated_as_one():
    r = grant_writing_analyze_sentences("句点なし")
    assert r["total_sentences"] == 1
    assert r["max_length"] == 4


# ---------- count_weak_expressions ----------
def test_count_weak_expressions_counts_hedges():
    text = (
        "本研究は重要と考えられる。さらに発展可能性がある。"
        "効果が期待される。示唆されるものが多い。"
    )
    r = grant_writing_count_weak_expressions(text)
    assert r["total_weak_expressions"] >= 4
    assert "と考えられる" in r["by_pattern"]


def test_count_weak_expressions_empty():
    r = grant_writing_count_weak_expressions("本研究は成果を出した。")
    assert r["total_weak_expressions"] == 0


# ---------- check_misuse_japanese ----------
def test_check_misuse_finds_kougo():
    text = "よろしかったでしょうか。こんにちわ。なにげに有効。"
    r = grant_writing_check_misuse_japanese(text)
    matches = {h["match"] for h in r["issues"]}
    assert "よろしかったでしょうか" in matches
    assert "こんにちわ" in matches
    assert "なにげに" in matches


def test_check_misuse_clean_text():
    text = "本研究は新規手法を提案する。"
    r = grant_writing_check_misuse_japanese(text)
    assert r["total_matches"] == 0
