"""Tests for Plan B T5: paper_writing_related_work_density.

5 cases:
1. balanced_intro (20-40 cites, low self-cite, recent refs, many competitors)
2. sparse_intro (few cites)
3. self_cite_heavy (ratio > 0.20)
4. old_refs_only (recent_ratio < 0.40)
5. no_intro (\\section{Introduction} absent)

Assertions focus on `comments` substrings and key `observations` booleans/counts.
Do NOT over-assert exact scores.
"""
from mcp_server_document.paper_writing.plan_b_T5 import (
    paper_writing_related_work_density,
)


def _make_bib_entry(key: str, author: str, year: int) -> str:
    return (
        f"@article{{{key},\n"
        f"  author = {{{author}}},\n"
        f"  title  = {{Some Title}},\n"
        f"  journal= {{Some Journal}},\n"
        f"  year   = {{{year}}},\n"
        f"}}\n"
    )


def _bib_from_list(entries: list[tuple[str, str, int]]) -> str:
    return "\n".join(_make_bib_entry(k, a, y) for k, a, y in entries)


# ------------------------------------------------------------------
# Case 1: Balanced intro (happy path)
# ------------------------------------------------------------------
def test_balanced_intro_scores_high():
    # 25 cites: 3 self (Sugahara) + 22 competitors.
    # Recent: 15 in 2022-2026 (>=2021), old: 10 pre-2021 → recent_ratio = 15/25 = 0.60.
    competitor_keys = []
    entries: list[tuple[str, str, int]] = []
    for i in range(15):
        k = f"comp_recent_{i}"
        competitor_keys.append(k)
        entries.append((k, f"Smith, A{i} and Jones, B{i}", 2022 + (i % 4)))
    for i in range(7):
        k = f"comp_old_{i}"
        competitor_keys.append(k)
        entries.append((k, f"Brown, C{i}", 2010 + i))
    self_keys = []
    for i in range(3):
        k = f"self_{i}"
        self_keys.append(k)
        entries.append((k, f"Sugahara, K. and Other, Z{i}", 2020 + i))

    bib = _bib_from_list(entries)

    all_keys = competitor_keys + self_keys
    cite_block = ", ".join(all_keys)
    tex = (
        r"\section{Introduction}" + "\n"
        "Background paragraph with many related works "
        r"\cite{" + cite_block + "}.\n"
        "More intro text.\n\n"
        r"\section{Method}" + "\n"
        "Method content.\n"
    )

    r = paper_writing_related_work_density(
        tex, bib=bib, author_last_names="Sugahara"
    )

    assert r["score_max"] == 10
    obs = r["observations"]
    assert obs["introduction_found"] is True
    assert obs["introduction_cite_total"] == 25
    assert len(obs["self_cite_keys"]) == 3
    assert obs["self_cite_ratio"] <= 0.20
    assert obs["competitor_cite_count"] == 22
    assert obs["recent_ratio"] >= 0.40
    assert isinstance(obs["year_histogram"], dict)
    # Should have entries for recent years
    assert any(y >= 2022 for y in obs["year_histogram"].keys())

    assert r["score"] >= 7

    # All-good comment expected
    joined = "\n".join(r["comments"])
    assert "良好" in joined or "balance" in joined.lower()


# ------------------------------------------------------------------
# Case 2: Sparse intro (few cites)
# ------------------------------------------------------------------
def test_sparse_intro_flagged():
    entries = [
        ("a", "Smith, A", 2023),
        ("b", "Jones, B", 2024),
        ("c", "Brown, C", 2022),
    ]
    bib = _bib_from_list(entries)
    tex = (
        r"\section{Introduction}" + "\n"
        r"Prior work includes \cite{a,b,c}." + "\n\n"
        r"\section{Method}" + "\n"
    )
    r = paper_writing_related_work_density(
        tex, bib=bib, author_last_names="Sugahara"
    )

    obs = r["observations"]
    assert obs["introduction_found"] is True
    assert obs["introduction_cite_total"] == 3

    joined = "\n".join(r["comments"])
    assert "少ない" in joined or "20-40" in joined
    # "何も読んでいない" 表現 or reviewer-2 hint
    assert "reviewer" in joined.lower() or "何も読んでいない" in joined

    # score < perfect (missing count, competitors < 5)
    assert r["score"] < 10


# ------------------------------------------------------------------
# Case 3: Self-cite heavy
# ------------------------------------------------------------------
def test_self_cite_heavy_flagged():
    # 20 cites, 10 self → 50% self-cite ratio
    entries: list[tuple[str, str, int]] = []
    self_keys = []
    comp_keys = []
    for i in range(10):
        k = f"self_{i}"
        self_keys.append(k)
        entries.append((k, f"Sugahara, K. and Co, {i}", 2023))
    for i in range(10):
        k = f"comp_{i}"
        comp_keys.append(k)
        entries.append((k, f"Other, X{i}", 2023))
    bib = _bib_from_list(entries)

    cite_block = ", ".join(self_keys + comp_keys)
    tex = (
        r"\section{Introduction}" + "\n"
        r"Intro \cite{" + cite_block + "}.\n"
        r"\section{Method}" + "\n"
    )
    r = paper_writing_related_work_density(
        tex, bib=bib, author_last_names="Sugahara"
    )

    obs = r["observations"]
    assert obs["introduction_cite_total"] == 20
    assert len(obs["self_cite_keys"]) == 10
    assert obs["self_cite_ratio"] > 0.20

    joined = "\n".join(r["comments"])
    assert "自己引用" in joined
    assert "NG #5" in joined or "競合研究" in joined


# ------------------------------------------------------------------
# Case 4: Old refs only
# ------------------------------------------------------------------
def test_old_refs_only_flagged():
    # All cites from 1999-2005 → 0% recent
    entries: list[tuple[str, str, int]] = []
    keys = []
    for i in range(25):
        k = f"old_{i}"
        keys.append(k)
        entries.append((k, f"Smith{i}, A", 1999 + (i % 7)))
    bib = _bib_from_list(entries)

    cite_block = ", ".join(keys)
    tex = (
        r"\section{Introduction}" + "\n"
        r"Background \cite{" + cite_block + "}.\n"
        r"\section{Method}" + "\n"
    )
    r = paper_writing_related_work_density(
        tex, bib=bib, author_last_names="Sugahara"
    )

    obs = r["observations"]
    assert obs["introduction_cite_total"] == 25
    assert obs["recent_ratio"] < 0.40
    # competitor count ample
    assert obs["competitor_cite_count"] >= 20

    joined = "\n".join(r["comments"])
    assert "5 年以内" in joined or "最新動向" in joined


# ------------------------------------------------------------------
# Case 5: No introduction section
# ------------------------------------------------------------------
def test_no_intro_section_flagged():
    tex = (
        r"\section{Background}" + "\n"
        r"Some text \cite{x}." + "\n"
        r"\section{Method}" + "\n"
    )
    bib = _bib_from_list([("x", "Smith, A", 2024)])
    r = paper_writing_related_work_density(
        tex, bib=bib, author_last_names="Sugahara"
    )

    obs = r["observations"]
    assert obs["introduction_found"] is False
    assert obs["introduction_cite_total"] == 0
    # Paper-wide still counts
    assert obs["total_cites_in_paper"] == 1

    assert r["score"] == 2.0

    joined = "\n".join(r["comments"])
    assert "Introduction" in joined and "見つから" in joined


# ------------------------------------------------------------------
# Additional: structural / edge cases
# ------------------------------------------------------------------
def test_empty_input_no_crash():
    r = paper_writing_related_work_density("", bib="", author_last_names="")
    assert "score" in r
    assert "comments" in r
    assert "observations" in r
    assert r["observations"]["introduction_found"] is False
    assert r["observations"]["introduction_cite_total"] == 0
    assert len(r["comments"]) >= 2


def test_none_input_no_crash():
    r = paper_writing_related_work_density(
        None, bib=None, author_last_names=None  # type: ignore[arg-type]
    )
    assert r["observations"]["introduction_found"] is False
    assert r["score"] == 2.0


def test_hint_and_source_content():
    r = paper_writing_related_work_density(
        "", bib="", author_last_names=""
    )
    assert "brace-balanced" in r["hint"]
    assert "author_last_names" in r["hint"]
    assert "NG #5" in r["source"]
    assert "Wallwork" in r["source"]


def test_braced_author_nested_self_detection():
    """nested-brace author field ({Sugahara, K.} and Co) も self として検出。"""
    bib = (
        "@article{s1,\n"
        "  author = {{Sugahara}, K. and Co, A},\n"
        "  year = {2024},\n"
        "}\n"
        "@article{c1,\n"
        "  author = {Other, X},\n"
        "  year = {2024},\n"
        "}\n"
    )
    tex = (
        r"\section{Introduction}" + "\n"
        r"Refs \cite{s1,c1}." + "\n"
        r"\section{Method}" + "\n"
    )
    r = paper_writing_related_work_density(
        tex, bib=bib, author_last_names="Sugahara"
    )
    obs = r["observations"]
    assert "s1" in obs["self_cite_keys"]
    assert "c1" not in obs["self_cite_keys"]
