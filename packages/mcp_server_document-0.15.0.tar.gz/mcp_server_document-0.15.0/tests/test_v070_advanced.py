"""Tests for v0.7.0: preprocess + detect_shapes + text_regions + bezier
+ semantic_group + stroke_width_normalize + svg/tikz export."""
from __future__ import annotations

import json
import pathlib

import pytest


def _make_rect_line_image(tmp_path: pathlib.Path) -> pathlib.Path:
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    import numpy as np
    import cv2
    img = np.full((200, 300, 3), 255, dtype=np.uint8)
    # Two FILLED rectangles (axis-aligned); isolated so contours stay separate
    cv2.rectangle(img, (20, 20), (120, 80), (0, 0, 0), thickness=-1)
    cv2.rectangle(img, (200, 100), (280, 170), (0, 0, 0), thickness=-1)
    # A standalone line (no arrow)
    cv2.line(img, (20, 130), (100, 130), (0, 0, 0), thickness=2)
    # A filled circle
    cv2.circle(img, (160, 40), 18, (0, 0, 0), thickness=-1)
    p = tmp_path / "shapes.png"
    cv2.imwrite(str(p), img)
    return p


def _simple_excalidraw_with_zigzag(tmp_path: pathlib.Path) -> pathlib.Path:
    doc = {
        "type": "excalidraw", "version": 2,
        "elements": [{
            "id": "zig", "type": "line",
            "x": 0.0, "y": 0.0, "width": 100.0, "height": 20.0,
            "angle": 0, "strokeColor": "#000000",
            "backgroundColor": "transparent",
            "fillStyle": "solid", "strokeWidth": 1,
            "strokeStyle": "solid", "roughness": 0,
            "opacity": 100,
            "points": [[i, (i % 2) * 4] for i in range(0, 101, 5)],
            "seed": 1, "version": 1, "versionNonce": 1,
            "isDeleted": False, "groupIds": [], "boundElements": None,
        }],
        "appState": {"viewBackgroundColor": "#ffffff"},
    }
    p = tmp_path / "zig.excalidraw"
    p.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
    return p


def _mixed_excalidraw(tmp_path: pathlib.Path) -> pathlib.Path:
    doc = {
        "type": "excalidraw", "version": 2,
        "elements": [
            {"id": "r1", "type": "rectangle",
             "x": 10, "y": 10, "width": 80, "height": 40,
             "angle": 0, "strokeColor": "#1e1e1e",
             "backgroundColor": "transparent", "strokeWidth": 2,
             "fillStyle": "hachure", "strokeStyle": "solid",
             "roughness": 0, "opacity": 100,
             "isDeleted": False, "groupIds": [],
             "seed": 1, "version": 1, "versionNonce": 1,
             "boundElements": None},
            {"id": "e1", "type": "ellipse",
             "x": 150, "y": 15, "width": 40, "height": 40,
             "angle": 0, "strokeColor": "#1e1e1e",
             "backgroundColor": "#ffcccc", "strokeWidth": 2,
             "fillStyle": "solid", "strokeStyle": "solid",
             "roughness": 0, "opacity": 100,
             "isDeleted": False, "groupIds": [],
             "seed": 1, "version": 1, "versionNonce": 1,
             "boundElements": None},
            {"id": "a1", "type": "arrow",
             "x": 90, "y": 30, "width": 60, "height": 0,
             "angle": 0, "strokeColor": "#1e1e1e",
             "backgroundColor": "transparent", "strokeWidth": 2,
             "fillStyle": "solid", "strokeStyle": "solid",
             "roughness": 0, "opacity": 100,
             "points": [[0, 0], [60, 0]],
             "isDeleted": False, "groupIds": [],
             "endArrowhead": "arrow",
             "seed": 1, "version": 1, "versionNonce": 1,
             "boundElements": None},
            {"id": "t1", "type": "text",
             "x": 10, "y": 80, "width": 80, "height": 16,
             "angle": 0, "strokeColor": "#1e1e1e",
             "backgroundColor": "transparent", "strokeWidth": 1,
             "fillStyle": "solid", "strokeStyle": "solid",
             "roughness": 0, "opacity": 100,
             "text": "Hello & world",
             "fontSize": 16, "fontFamily": 2,
             "textAlign": "left", "verticalAlign": "top",
             "isDeleted": False, "groupIds": [],
             "seed": 1, "version": 1, "versionNonce": 1,
             "boundElements": None},
        ],
        "appState": {"viewBackgroundColor": "#ffffff"},
    }
    p = tmp_path / "mixed.excalidraw"
    p.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# preprocess
# ---------------------------------------------------------------------------
def test_preprocess_smoke(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    from mcp_server_document.diagram.tools import diagram_preprocess

    p = _make_rect_line_image(tmp_path)
    out = tmp_path / "pre.png"
    r = diagram_preprocess(str(p), str(out), deskew=True, denoise=True,
                              enhance_contrast=True, binarize="otsu")
    assert "error" not in r, r
    assert out.exists()
    assert r["output_is_binary"] is True


def test_preprocess_missing():
    from mcp_server_document.diagram.tools import diagram_preprocess
    r = diagram_preprocess("/nonexistent/nope.png", "/tmp/out.png")
    assert "error" in r


def test_preprocess_no_binarize(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    from mcp_server_document.diagram.tools import diagram_preprocess

    p = _make_rect_line_image(tmp_path)
    out = tmp_path / "pre_nobin.png"
    r = diagram_preprocess(str(p), str(out), binarize="")
    assert r["output_is_binary"] is False


# ---------------------------------------------------------------------------
# detect_shapes
# ---------------------------------------------------------------------------
def test_detect_shapes_counts(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    from mcp_server_document.diagram.tools import diagram_detect_shapes

    p = _make_rect_line_image(tmp_path)
    out = tmp_path / "shapes.excalidraw"
    r = diagram_detect_shapes(str(p), str(out),
                                 detect_arrows=False,
                                 detect_circles=True)
    assert "error" not in r, r
    assert r["total_elements"] >= 2
    # Expect at least one rectangle detected
    assert r["counts"]["rectangle"] >= 1
    doc = json.loads(out.read_text(encoding="utf-8"))
    types = {el["type"] for el in doc["elements"]}
    assert "rectangle" in types


def test_detect_shapes_missing():
    from mcp_server_document.diagram.tools import diagram_detect_shapes
    r = diagram_detect_shapes("/nonexistent/nope.png", "/tmp/out.excalidraw")
    assert "error" in r


# ---------------------------------------------------------------------------
# detect_text_regions
# ---------------------------------------------------------------------------
def test_detect_text_regions_empty(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    from mcp_server_document.diagram.tools import diagram_detect_text_regions

    p = _make_rect_line_image(tmp_path)  # no text
    r = diagram_detect_text_regions(str(p))
    assert "error" not in r
    # Shapes image has no text — word_count may be 0 or very small
    assert isinstance(r["words"], list)


def test_detect_text_regions_missing():
    from mcp_server_document.diagram.tools import diagram_detect_text_regions
    r = diagram_detect_text_regions("/nonexistent/nope.png")
    assert "error" in r


# ---------------------------------------------------------------------------
# fit_bezier
# ---------------------------------------------------------------------------
def test_fit_bezier_compression(tmp_path):
    from mcp_server_document.diagram.tools import diagram_fit_bezier
    p = _simple_excalidraw_with_zigzag(tmp_path)
    out = tmp_path / "smoothed.excalidraw"
    r = diagram_fit_bezier(str(p), str(out), min_points=5,
                              samples_per_segment=8, corner_angle_deg=40)
    assert "error" not in r, r
    assert r["elements_modified"] == 1


def test_fit_bezier_missing():
    from mcp_server_document.diagram.tools import diagram_fit_bezier
    r = diagram_fit_bezier("/nonexistent/nope.excalidraw", "/tmp/o.excalidraw")
    assert "error" in r


# ---------------------------------------------------------------------------
# semantic_group
# ---------------------------------------------------------------------------
def test_semantic_group_auto_eps(tmp_path):
    from mcp_server_document.diagram.tools import diagram_semantic_group
    p = _mixed_excalidraw(tmp_path)
    out = tmp_path / "grouped.excalidraw"
    r = diagram_semantic_group(str(p), str(out), eps=0.0, min_samples=2)
    assert "error" not in r, r
    # Four elements, likely 1 cluster with 2+ members and some noise
    assert r["total_elements"] == 4
    doc = json.loads(out.read_text(encoding="utf-8"))
    # At least some elements should have received a semantic_ groupId
    has_semantic = any(
        any(g.startswith("semantic_") for g in el.get("groupIds", []))
        for el in doc["elements"]
    )
    assert has_semantic or r["noise_elements"] == 4


def test_semantic_group_missing():
    from mcp_server_document.diagram.tools import diagram_semantic_group
    r = diagram_semantic_group("/nonexistent/nope.excalidraw",
                                  "/tmp/o.excalidraw")
    assert "error" in r


# ---------------------------------------------------------------------------
# stroke_width_normalize
# ---------------------------------------------------------------------------
def test_stroke_width_normalize_autobuckets(tmp_path):
    from mcp_server_document.diagram.tools import diagram_stroke_width_normalize
    p = _mixed_excalidraw(tmp_path)
    out = tmp_path / "norm.excalidraw"
    r = diagram_stroke_width_normalize(str(p), str(out))
    assert "error" not in r, r
    assert isinstance(r["buckets"], list)
    assert r["buckets"]


def test_stroke_width_normalize_manual(tmp_path):
    from mcp_server_document.diagram.tools import diagram_stroke_width_normalize
    p = _mixed_excalidraw(tmp_path)
    out = tmp_path / "norm2.excalidraw"
    r = diagram_stroke_width_normalize(str(p), str(out),
                                          buckets="1,2,4")
    assert "error" not in r
    assert r["buckets"] == [1.0, 2.0, 4.0]


# ---------------------------------------------------------------------------
# excalidraw_to_svg
# ---------------------------------------------------------------------------
def test_svg_export_mixed(tmp_path):
    from mcp_server_document.diagram.tools import diagram_excalidraw_to_svg
    p = _mixed_excalidraw(tmp_path)
    out = tmp_path / "mixed.svg"
    r = diagram_excalidraw_to_svg(str(p), str(out))
    assert "error" not in r, r
    assert out.exists()
    svg = out.read_text(encoding="utf-8")
    assert "<svg" in svg
    assert "<rect" in svg
    assert "<ellipse" in svg
    assert "Hello &amp; world" in svg  # properly escaped


def test_svg_export_missing():
    from mcp_server_document.diagram.tools import diagram_excalidraw_to_svg
    r = diagram_excalidraw_to_svg("/nonexistent/nope.excalidraw",
                                     "/tmp/o.svg")
    assert "error" in r


# ---------------------------------------------------------------------------
# excalidraw_to_tikz
# ---------------------------------------------------------------------------
def test_tikz_export_mixed(tmp_path):
    from mcp_server_document.diagram.tools import diagram_excalidraw_to_tikz
    p = _mixed_excalidraw(tmp_path)
    out = tmp_path / "mixed.tex"
    r = diagram_excalidraw_to_tikz(str(p), str(out), scale=0.5, y_flip=True)
    assert "error" not in r, r
    assert out.exists()
    tex = out.read_text(encoding="utf-8")
    assert r"\begin{tikzpicture}" in tex
    assert r"\end{tikzpicture}" in tex
    assert r"rectangle" in tex
    assert r"ellipse" in tex
    # LaTeX special chars escaped
    assert r"Hello \& world" in tex
    # Arrow has `->`
    assert "->" in tex


def test_tikz_export_missing():
    from mcp_server_document.diagram.tools import diagram_excalidraw_to_tikz
    r = diagram_excalidraw_to_tikz("/nonexistent/nope.excalidraw",
                                      "/tmp/o.tex")
    assert "error" in r
