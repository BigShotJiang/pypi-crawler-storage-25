"""Tests for Plan B T2: paper_writing_contribution_clarity_score.

5 cases:
1. Ideal contribution list (itemize + claim verbs)
2. Hedged contribution (hedge drops score)
3. Prose-only contribution (numbered prose, item_count >= 3)
4. No contribution block (flag False, score low)
5. Non-parallel items (is_parallel_pos False)

Assertions focus on `comments` substrings and key `observations` booleans.
Do NOT over-assert exact scores.
"""
from mcp_server_document.paper_writing.plan_b_T2 import (
    paper_writing_contribution_clarity_score,
)


# ------------------------------------------------------------------
# Case 1: Ideal contribution list
# ------------------------------------------------------------------
def test_ideal_contribution_list_scores_high():
    tex = r"""
\section{Introduction}
Deep networks have reshaped the field.
Prior work addresses isolated aspects but none integrate X with Y.

The main contributions of this paper are as follows:
\begin{itemize}
  \item We propose a new hybrid solver that unifies X and Y.
  \item We demonstrate a 4.2\% accuracy improvement over the baseline.
  \item We show that the approach scales to 10$\times$ larger grids.
\end{itemize}

\section{Method}
Details follow.
"""
    r = paper_writing_contribution_clarity_score(tex)

    # 構造
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert 2 <= len(r["comments"]) <= 6
    assert "skill.md" in r["source"]
    assert "CARS" in r["source"]

    obs = r["observations"]
    assert obs["contribution_block_detected"] is True
    assert len(obs["claim_verbs_found"]) >= 3
    # propose / demonstrate / show 全て
    for v in ("propose", "demonstrate", "show"):
        assert v in obs["claim_verbs_found"]
    assert obs["item_count"] == 3
    assert obs["hedge_count"] == 0
    assert obs["has_quantitative"] is True

    # 高スコア
    assert r["score"] >= 7


# ------------------------------------------------------------------
# Case 2: Hedged contribution
# ------------------------------------------------------------------
def test_hedged_contribution_drops_score():
    tex = r"""
\section{Introduction}
Some context.

Our contributions are:
\begin{itemize}
  \item We propose X, which may improve accuracy.
  \item We present Y, which could be useful in similar settings.
  \item We show Z potentially applies to other domains.
\end{itemize}
"""
    r = paper_writing_contribution_clarity_score(tex)

    obs = r["observations"]
    assert obs["contribution_block_detected"] is True
    assert obs["hedge_count"] >= 1

    # comments に hedge 指摘が含まれる
    joined = "\n".join(r["comments"])
    assert "hedge" in joined.lower() or "断定" in joined

    # 理想 case (>=7) より低い傾向
    # 断定すると 1 点減、quant なしで更に 1 点減る想定
    assert r["score"] < 10


# ------------------------------------------------------------------
# Case 3: Prose-only contribution
# ------------------------------------------------------------------
def test_prose_only_contribution_detected():
    tex = r"""
\section{Introduction}
Background and motivation here. Some more context.

Our contributions are threefold.
First, we propose a novel hybrid formulation that achieves 12\% improvement.
Second, we demonstrate scaling to 4$\times$ larger problems.
Finally, we show broad applicability to three distinct benchmarks.

\section{Method}
Method details.
"""
    r = paper_writing_contribution_clarity_score(tex)

    obs = r["observations"]
    assert obs["contribution_block_detected"] is True
    # First / Second / Finally → 3 項目
    assert obs["item_count"] >= 3
    # claim verbs 複数
    assert len(obs["claim_verbs_found"]) >= 2


# ------------------------------------------------------------------
# Case 4: No contribution block
# ------------------------------------------------------------------
def test_no_contribution_block_flagged():
    tex = r"""
\section{Introduction}
This paper discusses the behavior of systems.
There are various aspects to consider in this domain.
We look at several aspects in what follows.

\section{Method}
Method details.
"""
    r = paper_writing_contribution_clarity_score(tex)

    obs = r["observations"]
    assert obs["contribution_block_detected"] is False
    # score は低い (score = 2 fallback)
    assert r["score"] <= 3

    joined = "\n".join(r["comments"])
    assert "Contribution" in joined
    assert "明示" in joined or "宣言" in joined


# ------------------------------------------------------------------
# Case 5: Non-parallel items
# ------------------------------------------------------------------
def test_non_parallel_items_flagged():
    tex = r"""
\section{Introduction}
Context here.

The contributions of this paper are:
\begin{itemize}
  \item An efficient solver for large-scale EM problems.
  \item We propose a new boundary-integral formulation.
  \item Benchmark results on three standard datasets are provided.
\end{itemize}
"""
    r = paper_writing_contribution_clarity_score(tex)

    obs = r["observations"]
    assert obs["contribution_block_detected"] is True
    assert obs["item_count"] == 3
    # 不揃い (ARTICLE / WE_VERB / OTHER)
    assert obs["is_parallel_pos"] is False

    joined = "\n".join(r["comments"])
    assert "parallelism" in joined or "不揃い" in joined


# ------------------------------------------------------------------
# Additional: empty input no crash
# ------------------------------------------------------------------
def test_empty_input_no_crash():
    r = paper_writing_contribution_clarity_score("")
    assert "score" in r
    assert "comments" in r
    assert "observations" in r
    assert r["observations"]["contribution_block_detected"] is False
    assert len(r["comments"]) >= 2


def test_none_input_no_crash():
    r = paper_writing_contribution_clarity_score(None)  # type: ignore[arg-type]
    assert r["observations"]["contribution_block_detected"] is False


# ------------------------------------------------------------------
# hint / source fixed content
# ------------------------------------------------------------------
def test_hint_and_source_content():
    r = paper_writing_contribution_clarity_score("test")
    assert "粗い温度計" in r["hint"]
    assert "CARS" in r["hint"]
    assert "skill.md T1" in r["source"]
    assert "Swales" in r["source"]
