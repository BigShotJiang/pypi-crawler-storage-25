"""Tests for v0.9.0: presentation_check_color_count_per_slide.

Source: 宮野公樹『研究発表のためのスライドデザイン』(講談社 2010).
"""
from __future__ import annotations

import pathlib
import pytest


def _make_simple_pptx(tmp_path: pathlib.Path, colors_per_slide: list[list[tuple[int, int, int]]]) -> pathlib.Path:
    """Create a pptx with given per-slide text colors."""
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor

    prs = Presentation()
    for rgb_list in colors_per_slide:
        slide_layout = prs.slide_layouts[5]  # Title Only
        slide = prs.slides.add_slide(slide_layout)
        left = top = Inches(1)
        width = Inches(5)
        height = Inches(0.5)
        for i, rgb in enumerate(rgb_list):
            txt_box = slide.shapes.add_textbox(left, top + Inches(0.6 * i), width, height)
            tf = txt_box.text_frame
            p = tf.paragraphs[0]
            run = p.add_run()
            run.text = f"Line {i}"
            run.font.size = Pt(24)
            run.font.color.rgb = RGBColor(*rgb)
    out = tmp_path / "test.pptx"
    prs.save(str(out))
    return out


def test_color_count_under_limit(tmp_path):
    """Slide with 3 colors under max_colors=5 should not violate."""
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.tools import (
        presentation_check_color_count_per_slide,
    )
    p = _make_simple_pptx(tmp_path, [[
        (255, 0, 0), (0, 255, 0), (0, 0, 255),
    ]])
    r = presentation_check_color_count_per_slide(str(p), max_colors=5)
    assert "error" not in r, r
    assert r["violating_count"] == 0


def test_color_count_over_limit(tmp_path):
    """Slide with 6 distinct colors should violate max=3."""
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.tools import (
        presentation_check_color_count_per_slide,
    )
    p = _make_simple_pptx(tmp_path, [[
        (255, 0, 0), (0, 255, 0), (0, 0, 255),
        (255, 255, 0), (0, 255, 255), (255, 0, 255),
    ]])
    r = presentation_check_color_count_per_slide(str(p), max_colors=3)
    assert r["violating_count"] == 1
    assert r["violating_slides"][0]["color_count"] >= 4


def test_color_count_missing_file():
    from mcp_server_document.presentation.tools import (
        presentation_check_color_count_per_slide,
    )
    r = presentation_check_color_count_per_slide("/nonexistent/no.pptx")
    assert "error" in r


def test_color_count_multi_slide(tmp_path):
    """Mixed slides: one clean, one over-saturated."""
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.tools import (
        presentation_check_color_count_per_slide,
    )
    p = _make_simple_pptx(tmp_path, [
        [(255, 0, 0), (0, 0, 0)],
        [(255, 0, 0), (0, 255, 0), (0, 0, 255), (128, 128, 128), (255, 128, 0)],
    ])
    r = presentation_check_color_count_per_slide(str(p), max_colors=3)
    assert r["total_slides"] == 2
    # 2nd slide should violate
    violating_slide_nums = [v["slide"] for v in r["violating_slides"]]
    assert 2 in violating_slide_nums
    assert 1 not in violating_slide_nums
