"""Direct tests for paper_writing tools that lacked coverage.

Targets the 13 untested diagnostics in
`mcp_server_document.paper_writing.tools`.
"""
import pytest

from mcp_server_document.paper_writing.tools import (
    paper_writing_analyze_sentences,
    paper_writing_check_abstract_background_ratio,
    paper_writing_check_citation_usage,
    paper_writing_check_english_redflags,
    paper_writing_check_figure_caption_showing,
    paper_writing_check_overfull_hbox,
    paper_writing_check_paragraph_length,
    paper_writing_check_passive_voice_ratio,
    paper_writing_check_self_citation_ratio,
    paper_writing_count_underlines,
    paper_writing_count_weak_expressions,
    paper_writing_validate_abstract_length,
    paper_writing_validate_pdf_pages,
)


# ---------- check_figure_caption_showing ----------
def test_paper_writing_check_figure_caption_detects_showing_form():
    res = paper_writing_check_figure_caption_showing(
        "Fig. 4 shows the relationship between A and B."
    )
    assert res["is_showing_form"] is True


def test_paper_writing_check_figure_caption_accepts_claim_form():
    res = paper_writing_check_figure_caption_showing(
        "The abundances of A and B were inversely related (Fig. 4)."
    )
    assert res["is_showing_form"] is False


# ---------- check_abstract_background_ratio ----------
def test_paper_writing_check_abstract_background_ratio_high_background():
    abstract = (
        "Magnetic materials have long been important in engineering. "
        "Recent developments have expanded their use. "
        "We propose a new method with 30% improvement."
    )
    res = paper_writing_check_abstract_background_ratio(abstract)
    assert 0.0 <= res["background_ratio"] <= 1.0
    assert res["total_sentences"] == 3
    assert res["background_chars"] > 0


def test_paper_writing_check_abstract_background_ratio_immediate_content():
    abstract = "We propose a new 3D solver achieving 10x speedup."
    res = paper_writing_check_abstract_background_ratio(abstract)
    assert res["background_ratio"] == 0.0


def test_paper_writing_check_abstract_background_ratio_empty():
    res = paper_writing_check_abstract_background_ratio("   ")
    assert "error" in res


# ---------- check_paragraph_length ----------
def test_paper_writing_check_paragraph_length_flags_long_paragraph():
    long_para = "word " * 400
    short_para = "word " * 10
    text = long_para + "\n\n" + short_para
    res = paper_writing_check_paragraph_length(text)
    assert res["total_paragraphs"] == 2
    assert res["over_warn"] >= 1
    assert res["language"] == "en"


def test_paper_writing_check_paragraph_length_single_giant():
    text = "word " * 500
    res = paper_writing_check_paragraph_length(text)
    assert res["total_paragraphs"] == 1
    assert res["single_giant_paragraph"] is True


# ---------- check_english_redflags ----------
def test_paper_writing_check_english_redflags_detects_common_issues():
    text = (
        "In the paper, we will show the results. "
        "Please refer to Section 2. "
        "We will demonstrate the approach. "
        "In order to solve this, we did X. "
        "In order to achieve Y, we did Z. "
        "In order to get W, we did V."
    )
    res = paper_writing_check_english_redflags(text)
    patterns = " ".join(i["pattern"] for i in res["issues"])
    assert "we will" in patterns.lower()
    assert "In the paper" in patterns or "In the paper/study/work" in patterns
    assert "Please refer to" in patterns
    assert "In order to" in patterns
    assert res["total_issues"] >= 4


def test_paper_writing_check_english_redflags_clean_text():
    text = "We propose a new method. The results show improvement."
    res = paper_writing_check_english_redflags(text)
    assert res["total_issues"] == 0


# ---------- validate_abstract_length ----------
def test_paper_writing_validate_abstract_length_english_within():
    text = " ".join(["word"] * 150)
    res = paper_writing_validate_abstract_length(text, max_words=200)
    assert res["detected_language"] == "en"
    assert res["count"] == 150
    assert res["within_limit"] is True
    assert res["excess"] == 0


def test_paper_writing_validate_abstract_length_japanese_over():
    text = "本研究では新規手法を提案する。" * 40
    res = paper_writing_validate_abstract_length(text, max_chars_ja=100)
    assert res["detected_language"] == "ja"
    assert res["within_limit"] is False
    assert res["excess"] > 0


# ---------- count_weak_expressions ----------
def test_paper_writing_count_weak_expressions_hits_hedges():
    text = (
        "効果が期待される。示唆される傾向が見られる。"
        "It seems the approach might be effective."
    )
    res = paper_writing_count_weak_expressions(text)
    assert res["total_weak_expressions"] >= 3
    assert "期待される" in res["by_pattern"]


def test_paper_writing_count_weak_expressions_clean():
    res = paper_writing_count_weak_expressions("本研究は成果を示した。")
    assert res["total_weak_expressions"] == 0


# ---------- analyze_sentences ----------
def test_paper_writing_analyze_sentences_stats():
    text = "短い文。" + "あ" * 120 + "。普通の文。"
    res = paper_writing_analyze_sentences(text, max_len=80)
    assert res["total_sentences"] == 3
    assert res["max_length"] >= 120
    assert res["over_threshold_count"] >= 1


def test_paper_writing_analyze_sentences_empty():
    res = paper_writing_analyze_sentences("")
    assert "error" in res


# ---------- check_self_citation_ratio ----------
def test_paper_writing_check_self_citation_ratio_with_bib(tmp_path):
    tex = tmp_path / "paper.tex"
    bib = tmp_path / "paper.bib"
    tex.write_text(
        r"See \cite{sug2024,other2020,sug2023}.",
        encoding="utf-8",
    )
    bib.write_text(
        "@article{sug2024, author={Sugahara, K.}, title={X}, year={2024}}\n"
        "@article{other2020, author={Smith, J.}, title={Y}, year={2020}}\n"
        "@article{sug2023, author={Sugahara, K. and Hane, Y.}, title={Z}, year={2023}}\n",
        encoding="utf-8",
    )
    res = paper_writing_check_self_citation_ratio(
        str(tex), str(bib), "Sugahara"
    )
    assert res["total_citations"] == 3
    assert res["self_citation_count"] == 2
    assert abs(res["self_citation_ratio"] - 2 / 3) < 0.01


def test_paper_writing_check_self_citation_ratio_missing_authors(tmp_path):
    tex = tmp_path / "a.tex"
    bib = tmp_path / "a.bib"
    tex.write_text(r"\cite{x}", encoding="utf-8")
    bib.write_text("@article{x, author={A}, year=2000}", encoding="utf-8")
    res = paper_writing_check_self_citation_ratio(str(tex), str(bib), "")
    assert "error" in res


# ---------- check_citation_usage ----------
def test_paper_writing_check_citation_usage_reports_mismatches(tmp_path):
    tex = tmp_path / "paper.tex"
    bib = tmp_path / "paper.bib"
    tex.write_text(
        r"\cite{a2020,missing2021} and \cite{b2022}.",
        encoding="utf-8",
    )
    bib.write_text(
        "@article{a2020, author={A}, year=2020}\n"
        "@article{b2022, author={B}, year=2022}\n"
        "@article{unused2019, author={C}, year=2019}\n",
        encoding="utf-8",
    )
    res = paper_writing_check_citation_usage(str(tex), str(bib))
    assert res["total_citations"] == 3
    assert res["total_bib_entries"] == 3
    assert "missing2021" in res["missing_in_bib"]
    assert "unused2019" in res["unused_in_tex"]


def test_paper_writing_check_citation_usage_missing_tex():
    res = paper_writing_check_citation_usage("/nonexistent.tex")
    assert "error" in res


# ---------- check_overfull_hbox ----------
def test_paper_writing_check_overfull_hbox_parses_log(tmp_path):
    log = tmp_path / "paper.log"
    log.write_text(
        "Overfull \\hbox (10.0pt too wide) in paragraph at lines 50--52\n"
        "random line\n"
        "Overfull \\hbox (3.5pt too wide) in paragraph at lines 200\n",
        encoding="utf-8",
    )
    res = paper_writing_check_overfull_hbox(str(log))
    assert res["overfull_count"] == 2
    assert len(res["overfull_details"]) == 2


def test_paper_writing_check_overfull_hbox_clean(tmp_path):
    log = tmp_path / "clean.log"
    log.write_text("normal output", encoding="utf-8")
    res = paper_writing_check_overfull_hbox(str(log))
    assert res["overfull_count"] == 0


def test_paper_writing_check_overfull_hbox_missing():
    res = paper_writing_check_overfull_hbox("/nonexistent.log")
    assert "error" in res


# ---------- count_underlines ----------
def test_paper_writing_count_underlines_counts_macros(tmp_path):
    tex = tmp_path / "a.tex"
    tex.write_text(
        r"\uline{x}\underline{y}\sout{z}\uline{w}",
        encoding="utf-8",
    )
    res = paper_writing_count_underlines(str(tex))
    assert res["total_underlines"] == 4
    assert res["by_macro"]["uline"] == 2
    assert res["by_macro"]["underline"] == 1
    assert res["by_macro"]["sout"] == 1


def test_paper_writing_count_underlines_clean(tmp_path):
    tex = tmp_path / "clean.tex"
    tex.write_text("no underlines here at all", encoding="utf-8")
    res = paper_writing_count_underlines(str(tex))
    assert res["total_underlines"] == 0
    assert res["by_macro"] == {}


def test_paper_writing_count_underlines_missing():
    res = paper_writing_count_underlines("/nonexistent.tex")
    assert "error" in res


# ---------- validate_pdf_pages ----------
@pytest.fixture
def mini_pdf(tmp_path):
    pymupdf = pytest.importorskip("pymupdf")
    p = tmp_path / "mini.pdf"
    doc = pymupdf.open()
    for _ in range(4):
        doc.new_page()
    doc.save(str(p))
    doc.close()
    return p


def test_paper_writing_validate_pdf_pages_within(mini_pdf):
    res = paper_writing_validate_pdf_pages(str(mini_pdf), page_limit=8)
    assert res["page_count"] == 4
    assert res["within_limit"] is True
    assert res["pages_over"] == 0


def test_paper_writing_validate_pdf_pages_over(mini_pdf):
    res = paper_writing_validate_pdf_pages(str(mini_pdf), page_limit=2)
    assert res["page_count"] == 4
    assert res["within_limit"] is False
    assert res["pages_over"] == 2


def test_paper_writing_validate_pdf_pages_missing():
    pytest.importorskip("pymupdf")
    res = paper_writing_validate_pdf_pages("/nonexistent.pdf", page_limit=5)
    assert "error" in res


# ---------- check_passive_voice_ratio ----------
def test_paper_writing_check_passive_voice_ratio_passive_heavy():
    text = (
        "The sample was heated. The field was measured. "
        "Results were recorded. The data were analyzed. "
        "Conclusions were drawn. Values are reported."
    )
    res = paper_writing_check_passive_voice_ratio(text)
    assert res["passive_count"] >= 4
    assert 0.0 <= res["passive_ratio"] <= 1.0


def test_paper_writing_check_passive_voice_ratio_active_text():
    text = "We propose a new method. Our approach improves accuracy."
    res = paper_writing_check_passive_voice_ratio(text)
    assert res["passive_count"] == 0
    assert res["verdict"] == "OK"
