"""Tests for Plan B T4: presentation_check_logo_on_every_slide.

Covers 4 cases:
1. Logo on every slide — is_logo_detected True, score low
2. Logo on title only — is_logo_detected False, score = 10
3. No pictures at all — score = 10
4. Different positions per slide — is_logo_detected False

Assertions focus on `is_logo_detected`, `score` bucket, and substrings in
`comments`. No brittle exact numeric assertions.
"""
from __future__ import annotations

import base64
import pathlib

import pytest


# 1x1 red pixel PNG (base64 encoded)
PNG_BYTES = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk"
    "YAAAAAYAAjCB0C8AAAAASUVORK5CYII="
)


def _write_dot_png(tmp_path: pathlib.Path) -> pathlib.Path:
    img_path = tmp_path / "dot.png"
    img_path.write_bytes(PNG_BYTES)
    return img_path


# ------------------------------------------------------------------
# Case 1: Logo on every slide (5 slides, same picture at same position)
# ------------------------------------------------------------------
def test_logo_on_every_slide_detected_low_score(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Emu
    from mcp_server_document.presentation.plan_b_T4 import (
        presentation_check_logo_on_every_slide,
    )

    img = _write_dot_png(tmp_path)
    prs = Presentation()
    blank_layout = prs.slide_layouts[6]  # Blank
    for _ in range(5):
        slide = prs.slides.add_slide(blank_layout)
        slide.shapes.add_picture(
            str(img),
            left=Emu(500_000),
            top=Emu(500_000),
            width=Emu(800_000),
            height=Emu(800_000),
        )

    out = tmp_path / "every.pptx"
    prs.save(str(out))

    r = presentation_check_logo_on_every_slide(str(out))

    # 構造チェック
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 5
    assert "source" in r and "S13" in r["source"]
    assert "hint" in r

    obs = r["observations"]
    assert obs["total_slides"] == 5
    assert obs["is_logo_detected"] is True
    assert obs["most_repeated_ratio"] == 1.0
    assert obs["most_repeated_key"] is not None
    # 位置キーが全スライドで 5 回
    assert max(obs["repeated_picture_stats"].values()) == 5
    assert len(obs["picture_shapes_per_slide"]) == 5

    # score は ratio=1.0 → 0 近傍
    assert r["score"] <= 1.0

    # コメントに「logo 推定」or 「ロゴ」警告が含まれる
    joined = "\n".join(r["comments"])
    assert "logo" in joined.lower() or "ロゴ" in joined
    assert "S13" in joined
    assert "5/5" in joined or "5枚" in joined or "5 枚" in joined


# ------------------------------------------------------------------
# Case 2: Logo on title only (1 slide has picture, others do not)
# ------------------------------------------------------------------
def test_logo_on_title_only_not_detected(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Emu
    from mcp_server_document.presentation.plan_b_T4 import (
        presentation_check_logo_on_every_slide,
    )

    img = _write_dot_png(tmp_path)
    prs = Presentation()
    blank_layout = prs.slide_layouts[6]

    # Slide 1: has a picture (logo on title)
    slide1 = prs.slides.add_slide(blank_layout)
    slide1.shapes.add_picture(
        str(img),
        left=Emu(500_000),
        top=Emu(500_000),
        width=Emu(800_000),
        height=Emu(800_000),
    )
    # Slides 2-5: no pictures
    for _ in range(4):
        prs.slides.add_slide(blank_layout)

    out = tmp_path / "title_only.pptx"
    prs.save(str(out))

    r = presentation_check_logo_on_every_slide(str(out))

    obs = r["observations"]
    assert obs["total_slides"] == 5
    assert obs["is_logo_detected"] is False
    # 位置キーの最大 count は 1 (slide1 のみ)
    assert max(obs["repeated_picture_stats"].values()) == 1
    assert obs["most_repeated_ratio"] <= 0.2

    # score = 10 (ロゴ過剰でない)
    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    # 基準を満たす旨のコメント
    assert "一律配置なし" in joined or "基準を満たす" in joined or "検出されない" in joined


# ------------------------------------------------------------------
# Case 3: No pictures at all
# ------------------------------------------------------------------
def test_no_pictures_score_10(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T4 import (
        presentation_check_logo_on_every_slide,
    )

    prs = Presentation()
    blank_layout = prs.slide_layouts[6]
    for _ in range(3):
        prs.slides.add_slide(blank_layout)

    out = tmp_path / "no_pics.pptx"
    prs.save(str(out))

    r = presentation_check_logo_on_every_slide(str(out))

    obs = r["observations"]
    assert obs["total_slides"] == 3
    assert obs["is_logo_detected"] is False
    assert obs["most_repeated_key"] is None
    assert obs["most_repeated_ratio"] == 0.0
    assert obs["repeated_picture_stats"] == {}
    # picture_shapes_per_slide は各 slide につき空 list
    assert all(not pics for pics in obs["picture_shapes_per_slide"])

    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    assert "picture" in joined.lower() or "画像" in joined or "不在" in joined


# ------------------------------------------------------------------
# Case 4: Different positions per slide — repeated image, different positions
# ------------------------------------------------------------------
def test_different_positions_not_detected(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Emu
    from mcp_server_document.presentation.plan_b_T4 import (
        presentation_check_logo_on_every_slide,
    )

    img = _write_dot_png(tmp_path)
    prs = Presentation()
    blank_layout = prs.slide_layouts[6]

    # 5 slides, each with the same PNG but at a clearly different position
    # (separation > 100K EMU quantum to avoid rounding collision)
    positions = [
        (500_000, 500_000),
        (2_000_000, 500_000),
        (3_500_000, 500_000),
        (500_000, 2_000_000),
        (2_000_000, 2_000_000),
    ]
    for (l, t) in positions:
        slide = prs.slides.add_slide(blank_layout)
        slide.shapes.add_picture(
            str(img),
            left=Emu(l),
            top=Emu(t),
            width=Emu(800_000),
            height=Emu(800_000),
        )

    out = tmp_path / "diff_pos.pptx"
    prs.save(str(out))

    r = presentation_check_logo_on_every_slide(str(out))

    obs = r["observations"]
    assert obs["total_slides"] == 5
    assert obs["is_logo_detected"] is False
    # 5 つの異なる位置キーが 1 回ずつ出現
    assert len(obs["repeated_picture_stats"]) == 5
    assert max(obs["repeated_picture_stats"].values()) == 1
    assert obs["most_repeated_ratio"] <= 0.2

    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    assert "一律配置なし" in joined or "基準を満たす" in joined or "検出されない" in joined


# ------------------------------------------------------------------
# Additional: file not found / hint+source invariants
# ------------------------------------------------------------------
def test_file_not_found_graceful():
    from mcp_server_document.presentation.plan_b_T4 import (
        presentation_check_logo_on_every_slide,
    )
    r = presentation_check_logo_on_every_slide("Z:/definitely_does_not_exist.pptx")
    # python-pptx が入っていれば file-not-found フォールバック分岐
    # 入っていなければ ImportError 分岐 — どちらも安全な dict を返す
    assert r["score_max"] == 10
    assert isinstance(r["comments"], list)
    assert r["observations"]["is_logo_detected"] is False
    assert "S13" in r["source"]


def test_hint_and_source_content(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T4 import (
        presentation_check_logo_on_every_slide,
    )
    prs = Presentation()
    prs.slides.add_slide(prs.slide_layouts[6])
    out = tmp_path / "tiny.pptx"
    prs.save(str(out))
    r = presentation_check_logo_on_every_slide(str(out))

    assert "位置マッチ" in r["hint"]
    assert "template" in r["hint"]
    assert "宮野" in r["source"]
    assert "S13" in r["source"]


def test_threshold_ratio_parameter_respected(tmp_path):
    """threshold_ratio を 0.5 に下げれば、3/5 枚の一致でも検出する。"""
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Emu
    from mcp_server_document.presentation.plan_b_T4 import (
        presentation_check_logo_on_every_slide,
    )

    img = _write_dot_png(tmp_path)
    prs = Presentation()
    blank_layout = prs.slide_layouts[6]

    # 3 枚は同位置、2 枚は空
    for _ in range(3):
        slide = prs.slides.add_slide(blank_layout)
        slide.shapes.add_picture(
            str(img),
            left=Emu(500_000),
            top=Emu(500_000),
            width=Emu(800_000),
            height=Emu(800_000),
        )
    for _ in range(2):
        prs.slides.add_slide(blank_layout)

    out = tmp_path / "3of5.pptx"
    prs.save(str(out))

    # 既定 threshold=0.8 → 0.6 未満なので is_logo_detected False
    r_default = presentation_check_logo_on_every_slide(str(out))
    assert r_default["observations"]["is_logo_detected"] is False

    # threshold を下げると検出される (ratio=0.6, count=3 >= 3)
    r_low = presentation_check_logo_on_every_slide(str(out), threshold_ratio=0.5)
    assert r_low["observations"]["is_logo_detected"] is True
    assert r_low["score"] < 10.0
