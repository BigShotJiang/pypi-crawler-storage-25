"""Tests for Plan B T13 — grant_writing_budget_logic_check."""

from __future__ import annotations

from mcp_server_document.grant_writing.plan_b_T13 import (
    grant_writing_budget_logic_check,
)


def test_consistent_budget():
    """整合した予算: 合計と積み上げが一致、費目揃い → score >= 8."""
    text = (
        "物品費: 100万円\n"
        "旅費: 50万円\n"
        "人件費: 30万円\n"
        "その他: 20万円\n"
        "合計: 200万円"
    )
    result = grant_writing_budget_logic_check(text)

    assert result["score_max"] == 10
    assert result["score"] >= 8
    obs = result["observations"]
    assert obs["sum_matches_stated"] is True
    assert obs["stated_total"] == 2_000_000
    assert obs["computed_sum"] == 2_000_000
    assert obs["missing_major_categories"] == []
    # 一致コメント
    assert any("一致" in c for c in result["comments"])
    # source
    assert "grant-writing" in result["source"]


def test_inconsistent_total():
    """合計額と積み上げが不一致 → sum_matches_stated False, 差異コメント."""
    text = (
        "物品費: 100万円\n"
        "旅費: 50万円\n"
        "合計: 200万円"
    )
    result = grant_writing_budget_logic_check(text)

    obs = result["observations"]
    assert obs["sum_matches_stated"] is False
    assert obs["stated_total"] == 2_000_000
    assert obs["computed_sum"] == 1_500_000
    # 差異を指摘するコメント
    assert any(
        ("一致しない" in c) or ("差" in c) for c in result["comments"]
    )
    # スコアはペナルティ分下がる
    assert result["score"] < 8


def test_missing_categories():
    """物品費しか記載なし → 旅費/人件費/その他 欠損を指摘."""
    text = (
        "物品費: 150万円\n"
        "電磁界解析用ワークステーションおよび計測プローブ一式を導入する。"
    )
    result = grant_writing_budget_logic_check(text)

    obs = result["observations"]
    # 物品費は検出
    assert "物品費" in obs["categories_present"]
    # 他 3 つは欠損
    missing = obs["missing_major_categories"]
    assert "旅費" in missing
    assert "人件費" in missing
    assert "その他" in missing
    # それぞれを指摘するコメントが少なくとも 2 つ (comments 上限 5 による)
    missing_comments = [
        c for c in result["comments"]
        if ("旅費" in c) or ("人件費" in c) or ("その他" in c)
    ]
    assert len(missing_comments) >= 2


def test_no_amounts_plain_text():
    """金額表記が全くない → score 低、明示的コメント."""
    text = (
        "本研究では電磁界解析の新手法を提案する。"
        "従来法では困難であった大規模問題に対応可能である。"
    )
    result = grant_writing_budget_logic_check(text)

    obs = result["observations"]
    assert obs["amounts"] == []
    assert obs["stated_total"] is None
    assert obs["computed_sum"] == 0
    assert result["score"] == 0
    # 金額なしの明示コメント
    assert any(
        ("金額表記" in c) or ("予算セクション" in c) for c in result["comments"]
    )


# ------------------------------------------------------------------
# 2026-04-23 hardening: LaTeX tabular の金額解析
# ------------------------------------------------------------------
def test_latex_tabular_amounts_extracted():
    """\\begin{tabular}...\\end{tabular} 内のセル金額を拾えること。"""
    text = (
        r"\begin{tabular}{|l|r|}" + "\n"
        r"\hline" + "\n"
        r"項目 & 金額 \\" + "\n"
        r"\hline" + "\n"
        r"物品費 & 100万円 \\" + "\n"
        r"旅費 & 50万円 \\" + "\n"
        r"人件費 & 30万円 \\" + "\n"
        r"その他 & 20万円 \\" + "\n"
        r"合計 & 200万円 \\" + "\n"
        r"\hline" + "\n"
        r"\end{tabular}"
    )
    r = grant_writing_budget_logic_check(text)
    # 4 件 + stated_total 1 件 が抽出される
    assert len(r["observations"]["amounts"]) >= 4
    # 合計 200万円 と積み上げ 100+50+30+20 が一致
    assert r["observations"]["sum_matches_stated"] is True
    assert r["score"] >= 8


def test_latex_tabular_inconsistent_total():
    """\\begin{tabular} 内で合計が合わない場合、flag する。"""
    text = (
        r"\begin{tabular}{|l|r|}" + "\n"
        r"\hline" + "\n"
        r"物品費 & 100万円 \\" + "\n"
        r"旅費 & 50万円 \\" + "\n"
        r"合計 & 200万円 \\" + "\n"
        r"\hline" + "\n"
        r"\end{tabular}"
    )
    r = grant_writing_budget_logic_check(text)
    assert r["observations"]["sum_matches_stated"] is False
    joined = "\n".join(r["comments"])
    assert "一致しない" in joined or "差" in joined


def test_latex_tabular_with_multicolumn():
    """\\multicolumn があっても中身を拾えること。"""
    text = (
        r"\begin{tabular}{|l|r|}" + "\n"
        r"\hline" + "\n"
        r"\multicolumn{2}{|c|}{経費内訳} \\" + "\n"
        r"\hline" + "\n"
        r"物品費 & 100万円 \\" + "\n"
        r"合計 & 100万円 \\" + "\n"
        r"\hline" + "\n"
        r"\end{tabular}"
    )
    r = grant_writing_budget_logic_check(text)
    assert len(r["observations"]["amounts"]) >= 1
    assert r["observations"]["sum_matches_stated"] is True


# ------------------------------------------------------------------
# 2026-04-23 Phase E: LaTeX マクロ (\SI, \num, \textbf) と共通単位末尾
# pattern、及びデバッグ出力 (preprocessed_text_head) の hardening。
# 実稿 KDDI 2027 で検出された regression fix。
# ------------------------------------------------------------------
def test_tabular_with_si_command():
    """\\SI{100}{万円} を 100 万円 として抽出する。"""
    tex = (
        r"\begin{tabular}{|l|r|}" + "\n"
        r"\hline" + "\n"
        r"物品費 & \SI{100}{万円} \\" + "\n"
        r"合計 & 100万円 \\" + "\n"
        r"\hline" + "\n"
        r"\end{tabular}"
    )
    r = grant_writing_budget_logic_check(tex)
    assert r["observations"]["sum_matches_stated"] is True
    assert r["observations"]["stated_total"] == 1_000_000


def test_tabular_with_num_command():
    """\\num{1000000} 円 を 1,000,000 円として抽出する。"""
    tex = (
        r"\begin{tabular}{|l|r|}" + "\n"
        r"\hline" + "\n"
        r"物品費 & \num{1000000} 円 \\" + "\n"
        r"合計 & 1000000 円 \\" + "\n"
        r"\hline" + "\n"
        r"\end{tabular}"
    )
    r = grant_writing_budget_logic_check(tex)
    assert r["observations"]["sum_matches_stated"] is True
    assert r["observations"]["stated_total"] == 1_000_000


def test_tabular_with_raw_comma_number():
    """1,000,000 円 (comma 付き full digit) を抽出する。"""
    tex = (
        r"\begin{tabular}{|l|r|}" + "\n"
        r"\hline" + "\n"
        r"物品費 & 1,000,000 円 \\" + "\n"
        r"合計 & 1,000,000 円 \\" + "\n"
        r"\hline" + "\n"
        r"\end{tabular}"
    )
    r = grant_writing_budget_logic_check(tex)
    assert len(r["observations"]["amounts"]) >= 1
    assert r["observations"]["sum_matches_stated"] is True


def test_latex_math_thousand_separator():
    """LaTeX 数式系の千単位区切り 3{,}600 を 3,600 として解釈できる。"""
    tex = (
        r"\begin{tabularx}{\linewidth}{|X|r|}" + "\n"
        r"\hline" + "\n"
        r"テーマ & 助成金額（千円）\\" + "\n"
        r"\hline" + "\n"
        r"課題 A & 3{,}600 \\" + "\n"
        r"\hline" + "\n"
        r"\end{tabularx}"
    )
    r = grant_writing_budget_logic_check(tex)
    # 3,600 千円 が抽出されるかどうかは shared-unit 分配に依存するため、
    # ここでは preprocessed_text_head に `3,600` が入っていることを確認。
    head = r["observations"]["preprocessed_text_head"]
    assert "3,600" in head


def test_observations_include_debug_snippet():
    """observations に preprocessed_text_head/raw_tabular_content が含まれる。"""
    tex = (
        r"\begin{tabular}{|l|r|} 物品費 & 100万円 \end{tabular}"
    )
    r = grant_writing_budget_logic_check(tex)
    obs = r["observations"]
    assert "preprocessed_text_head" in obs
    assert "raw_tabular_content" in obs
    assert isinstance(obs["preprocessed_text_head"], str)
    # 前処理後の content に 100万円 が残っていること
    assert "100" in obs["preprocessed_text_head"]


def test_shared_unit_suffix_pattern():
    """『300 万円 = 物品費 600／旅費 900／その他 150 千円』形式を解析できる。

    実稿 KDDI 2027 の 152 行目で発覚した pattern — individual items are
    bare numbers with a single shared 千円 suffix at the end of the list.
    """
    tex = (
        "3 年間総額 300 万円 = "
        "物品費 600／資料費 50／旅費 900／"
        "謝金 700／通信費 150／印刷費 200／"
        "消耗品費 50／その他 350 千円。"
    )
    r = grant_writing_budget_logic_check(tex)
    obs = r["observations"]
    # 300万円 (3,000,000 円) = 600+50+900+700+150+200+50+350 千円
    #                         = 3000 千円 = 3,000,000 円
    assert obs["stated_total"] == 3_000_000 or any(
        a["value_yen"] == 3_000_000 for a in obs["amounts"]
    )
    assert obs["computed_sum"] == 3_000_000
    # sum_matches_stated は stated_total 検出時のみ判定可能
    if obs["stated_total"] is not None:
        assert obs["sum_matches_stated"] is True


def test_shared_unit_excludes_year_and_percent():
    """共通単位末尾 pattern 内の年号 (2027/2028) と百分率 (23\\%) を除外。

    KDDI 2027 実稿の『Compumag 2027、CEFC 2028』や『総額の 23\\%、上限 30\\%』
    が誤って amounts に含まれないこと。
    """
    tex = (
        "3 年間総額 300 万円 = "
        "物品費 600／旅費 900（Compumag 2027、CEFC 2028）／"
        "謝金 700（総額の 23\\%、上限 30\\% 以内）／"
        "その他 800 千円。"
    )
    r = grant_writing_budget_logic_check(tex)
    obs = r["observations"]
    values = [a["value_yen"] for a in obs["amounts"]]
    # 2027/2028 が「2027万円=20,270,000」等として混入していないこと
    assert 20_270_000 not in values
    assert 20_280_000 not in values
    # 23%, 30% が「23万円=230,000 / 30万円=300,000」として混入していないこと
    # ただし 23/30 を 千円 解釈すると 23000/30000 となり他項目と衝突する可能性
    # があるため、合計額が期待どおりか (600+900+700+800=3000 千円) で検証
    assert obs["computed_sum"] == 3_000_000


def test_kddi_2027_budget_summary_sentence():
    """実稿 KDDI 2027 の予算 1 行サマリ: macro 除去と shared-unit 分配の E2E。"""
    tex = (
        r"3 年間総額 300 万円 = \textbf{設備備品費 600（GPU WS、Cubit 更新）"
        r"／資料費 50／出張旅費・滞在費 900（Compumag 2027、CEFC 2028、"
        r"NGSolve UM、国内）／謝金 700（大学院生 RA：総額の 23\%、"
        r"上限 30\% 以内）／通信・運搬費 150（GitHub Actions、クラウド）"
        r"／印刷費 200（IEEE TMAG 掲載料）／消耗品費 50／その他 350"
        r"（学会参加、日英翻訳）} 千円。"
    )
    r = grant_writing_budget_logic_check(tex)
    obs = r["observations"]
    assert obs["stated_total"] == 3_000_000
    assert obs["computed_sum"] == 3_000_000
    assert obs["sum_matches_stated"] is True
    assert r["score"] >= 8
