"""Tests for v0.4.0: paper +10, presentation +10, diagram +8, meta +4."""
import pathlib
import tempfile

import pytest


# ---------------------------------------------------------------------------
# paper_writing — 10 new tools
# ---------------------------------------------------------------------------
def test_paper_imrad_balance_ok():
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_imrad_balance,
    )
    text = (
        "# Abstract\n" + "A" * 50 + "\n"
        "# Introduction\n" + "B" * 300 + "\n"
        "# Method\n" + "C" * 500 + "\n"
        "# Result\n" + "D" * 600 + "\n"
        "# Discussion\n" + "E" * 400 + "\n"
        "# Conclusion\n" + "F" * 100 + "\n"
    )
    r = paper_writing_check_imrad_balance(text)
    assert "sections_found" in r
    assert len(r["sections_found"]) >= 5


def test_paper_imrad_not_enough_sections():
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_imrad_balance,
    )
    r = paper_writing_check_imrad_balance("plain text no headers here")
    assert "error" in r


def test_paper_tense_consistency():
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_tense_consistency,
    )
    text = ("## Discussion\n"
            "X is a stimulant. The distance was associated with Y. "
            "Z has been shown to ...")
    r = paper_writing_check_tense_consistency(text, section="Discussion")
    assert isinstance(r, dict)


def test_paper_figure_forward_reference(tmp_path):
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_figure_forward_reference,
    )
    tex = tmp_path / "doc.tex"
    tex.write_text(
        r"Text before \ref{fig:x}. "
        r"\begin{figure}\caption{X}\label{fig:x}\end{figure} "
        r"Text after."
    )
    r = paper_writing_check_figure_forward_reference(str(tex))
    assert isinstance(r, dict)


def test_paper_equation_numbering(tmp_path):
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_equation_numbering,
    )
    tex = tmp_path / "doc.tex"
    tex.write_text(
        r"\begin{equation}a\label{eq:a}\end{equation} "
        r"\begin{equation}b\end{equation} "
        r"See \eqref{eq:a}."
    )
    r = paper_writing_check_equation_numbering(str(tex))
    assert isinstance(r, dict)


def test_paper_cover_letter():
    from mcp_server_document.paper_writing.tools import (
        paper_writing_generate_cover_letter,
    )
    out = paper_writing_generate_cover_letter(
        journal="IEEE TMAG",
        title="A Novel Method",
        abstract="We present a method for...",
        contribution="10x faster than prior art.",
    )
    assert isinstance(out, str)
    assert "IEEE TMAG" in out
    assert "Novel Method" in out


def test_paper_response_letter():
    from mcp_server_document.paper_writing.tools import (
        paper_writing_generate_response_letter,
    )
    out = paper_writing_generate_response_letter(
        reviewer_comment="The method is unclear.",
        agreement_stance="agree",
        response_draft="We clarified in §2.1.",
    )
    assert isinstance(out, str)
    assert "reviewer" in out.lower() or "response" in out.lower() or "comment" in out.lower()


def test_paper_classify_reviewer_comment():
    from mcp_server_document.paper_writing.tools import (
        paper_writing_classify_reviewer_comment,
    )
    # Type A: typo
    r_a = paper_writing_classify_reviewer_comment(
        "There is a typo on page 3, line 5."
    )
    assert isinstance(r_a, dict)
    assert "difficulty" in r_a or "tier" in r_a or "category" in r_a
    # Type C: new experiment
    r_c = paper_writing_classify_reviewer_comment(
        "Please add a new experiment comparing with method Y."
    )
    assert isinstance(r_c, dict)


def test_paper_passive_voice_ratio():
    from mcp_server_document.paper_writing.tools import (
        paper_writing_check_passive_voice_ratio,
    )
    text = ("The sample was prepared. The data were analyzed. "
            "We measured X. The result was observed.")
    r = paper_writing_check_passive_voice_ratio(text)
    assert isinstance(r, dict)


def test_paper_lint_bib(tmp_path):
    from mcp_server_document.paper_writing.tools import (
        paper_writing_lint_reference_format,
    )
    bib = tmp_path / "refs.bib"
    bib.write_text(
        "@article{foo2020,\n  title={A},\n  author={B},\n  year={2020}\n}\n"
    )
    r = paper_writing_lint_reference_format(str(bib))
    assert isinstance(r, dict)


# ---------------------------------------------------------------------------
# presentation — 10 new tools
# ---------------------------------------------------------------------------
def test_presentation_time_14_rule():
    from mcp_server_document.presentation.tools import (
        presentation_check_time_14_rule,
    )
    script = "ああああ" * 500
    r = presentation_check_time_14_rule(script, slot_min=10.0)
    assert isinstance(r, dict)


def test_presentation_per_slide_time():
    from mcp_server_document.presentation.tools import (
        presentation_estimate_per_slide_time,
    )
    script = "slide one. slide two content. slide three more."
    r = presentation_estimate_per_slide_time(script)
    assert isinstance(r, dict)


def test_presentation_takehome_empty_path():
    from mcp_server_document.presentation.tools import (
        presentation_check_takehome_slide,
    )
    r = presentation_check_takehome_slide("/nonexistent/nope.pptx")
    assert "error" in r or "total_slides" in r


def test_presentation_title_verb_bad_path():
    from mcp_server_document.presentation.tools import (
        presentation_check_slide_title_verb,
    )
    r = presentation_check_slide_title_verb("/nonexistent/nope.pptx")
    assert "error" in r or isinstance(r, dict)


def test_presentation_font_size_bad_path():
    from mcp_server_document.presentation.tools import (
        presentation_check_pptx_font_size,
    )
    r = presentation_check_pptx_font_size("/nonexistent/nope.pptx")
    assert isinstance(r, dict)


def test_presentation_bullet_count_bad_path():
    from mcp_server_document.presentation.tools import (
        presentation_check_bullet_count_per_slide,
    )
    r = presentation_check_bullet_count_per_slide("/nonexistent/nope.pptx")
    assert isinstance(r, dict)


def test_presentation_qa_bad_path():
    from mcp_server_document.presentation.tools import (
        presentation_check_qa_backup_slides,
    )
    r = presentation_check_qa_backup_slides("/nonexistent/nope.pptx")
    assert isinstance(r, dict)


def test_presentation_image_ratio_bad_path():
    from mcp_server_document.presentation.tools import (
        presentation_check_image_text_ratio,
    )
    r = presentation_check_image_text_ratio("/nonexistent/nope.pptx")
    assert isinstance(r, dict)


def test_presentation_color_access_bad_path():
    from mcp_server_document.presentation.tools import (
        presentation_check_color_accessibility,
    )
    r = presentation_check_color_accessibility("/nonexistent/nope.pptx")
    assert isinstance(r, dict)


def test_presentation_bullet_ending_bad_path():
    from mcp_server_document.presentation.tools import (
        presentation_check_bullet_ending_style,
    )
    r = presentation_check_bullet_ending_style("/nonexistent/nope.pptx")
    assert isinstance(r, dict)


# ---------------------------------------------------------------------------
# diagram — 8 new tools
# ---------------------------------------------------------------------------
def test_diagram_push_file_not_found():
    from mcp_server_document.diagram.tools import diagram_push_to_canvas
    r = diagram_push_to_canvas("/nonexistent/nope.excalidraw")
    assert "error" in r


def test_diagram_clear_returns_dict():
    from mcp_server_document.diagram.tools import diagram_clear_canvas
    r = diagram_clear_canvas()
    assert isinstance(r, dict)  # error if server not running, ok otherwise


def test_diagram_export_png_no_server(tmp_path):
    from mcp_server_document.diagram.tools import diagram_export_canvas_png
    out = tmp_path / "out.png"
    r = diagram_export_canvas_png(str(out))
    # With no running server, error is expected
    assert isinstance(r, dict)


def test_diagram_load_file_not_found():
    from mcp_server_document.diagram.tools import diagram_load_excalidraw_file
    r = diagram_load_excalidraw_file("/nonexistent/nope.excalidraw")
    assert "error" in r


def test_diagram_load_file_ok(tmp_path):
    from mcp_server_document.diagram.tools import diagram_load_excalidraw_file
    import json
    p = tmp_path / "t.excalidraw"
    p.write_text(json.dumps({
        "elements": [
            {"id": "a", "type": "rectangle", "x": 0, "y": 0, "width": 10, "height": 10},
            {"id": "b", "type": "ellipse", "x": 20, "y": 30, "width": 40, "height": 50},
        ],
        "appState": {},
    }))
    r = diagram_load_excalidraw_file(str(p))
    assert r["element_count"] == 2
    assert r["type_histogram"] == {"rectangle": 1, "ellipse": 1}


def test_diagram_ocr_missing_file():
    from mcp_server_document.diagram.tools import diagram_ocr_text_layer
    r = diagram_ocr_text_layer("/nonexistent/nope.png")
    assert "error" in r


def test_diagram_mermaid_empty():
    from mcp_server_document.diagram.tools import diagram_mermaid_to_excalidraw
    r = diagram_mermaid_to_excalidraw("")
    assert "error" in r


def test_diagram_template_list():
    from mcp_server_document.diagram.tools import diagram_academic_template
    r = diagram_academic_template("")
    assert "available" in r
    assert "workflow" in r["available"]


def test_diagram_template_workflow():
    from mcp_server_document.diagram.tools import diagram_academic_template
    r = diagram_academic_template("workflow")
    assert r["kind"] == "workflow"
    assert r["element_count"] >= 3


def test_diagram_template_unknown():
    from mcp_server_document.diagram.tools import diagram_academic_template
    r = diagram_academic_template("nonesuch")
    assert "error" in r


def test_diagram_diff_missing():
    from mcp_server_document.diagram.tools import diagram_diff_excalidraw
    r = diagram_diff_excalidraw("/nonexistent/a", "/nonexistent/b")
    assert "error" in r


def test_diagram_diff_ok(tmp_path):
    from mcp_server_document.diagram.tools import diagram_diff_excalidraw
    import json
    pa = tmp_path / "a.excalidraw"
    pb = tmp_path / "b.excalidraw"
    pa.write_text(json.dumps({
        "elements": [
            {"id": "el1", "x": 0.0, "y": 0.0},
            {"id": "el2", "x": 10.0, "y": 10.0},
        ]
    }))
    pb.write_text(json.dumps({
        "elements": [
            {"id": "el1", "x": 5.0, "y": 0.0},  # moved
            {"id": "el3", "x": 20.0, "y": 20.0},  # added, el2 removed
        ]
    }))
    r = diagram_diff_excalidraw(str(pa), str(pb))
    assert r["added_count"] == 1
    assert r["removed_count"] == 1
    assert r["moved_count"] == 1


# ---------------------------------------------------------------------------
# document_meta — 4 new tools
# ---------------------------------------------------------------------------
def test_meta_deadline_future():
    from mcp_server_document.document_meta.tools import (
        document_meta_deadline_countdown,
    )
    r = document_meta_deadline_countdown("2099-01-01")
    assert r["days_remaining"] > 0
    assert r["urgency"] == "planning"


def test_meta_deadline_past():
    from mcp_server_document.document_meta.tools import (
        document_meta_deadline_countdown,
    )
    r = document_meta_deadline_countdown("1990-01-01")
    assert r["urgency"] == "past_due"


def test_meta_deadline_context_jsps():
    from mcp_server_document.document_meta.tools import (
        document_meta_deadline_countdown,
    )
    r = document_meta_deadline_countdown("2099-01-01", context="jsps_s2")
    assert "JSPS" in r["context_hint"] or "jsps" in r["context_hint"].lower() or \
           "招へい" in r["context_hint"]


def test_meta_diff_versions(tmp_path):
    from mcp_server_document.document_meta.tools import (
        document_meta_diff_versions,
    )
    a = tmp_path / "v1.txt"
    b = tmp_path / "v2.txt"
    a.write_text("hello\nworld\n")
    b.write_text("hello\nthere\n")
    r = document_meta_diff_versions(str(a), str(b))
    assert r["added_lines"] >= 1
    assert r["removed_lines"] >= 1


def test_meta_diff_missing():
    from mcp_server_document.document_meta.tools import (
        document_meta_diff_versions,
    )
    r = document_meta_diff_versions("/nonexistent/a", "/nonexistent/b")
    assert "error" in r


def test_meta_template_list():
    from mcp_server_document.document_meta.tools import (
        document_meta_template_loader,
    )
    r = document_meta_template_loader("")
    assert "available" in r
    assert "jsps_s2" in r["available"]


def test_meta_template_jsps():
    from mcp_server_document.document_meta.tools import (
        document_meta_template_loader,
    )
    r = document_meta_template_loader("jsps_s2")
    assert "template" in r
    assert "documentclass" in r["template"]


def test_meta_template_unknown():
    from mcp_server_document.document_meta.tools import (
        document_meta_template_loader,
    )
    r = document_meta_template_loader("nothing")
    assert "error" in r


def test_meta_lint_all(tmp_path):
    from mcp_server_document.document_meta.tools import (
        document_meta_lint_all,
    )
    p = tmp_path / "doc.tex"
    p.write_text(
        r"\documentclass{jsarticle}"
        "\n"
        r"\section{はじめに}"
        "\n本研究では ESIM を使用する。\n",
        encoding="utf-8",
    )
    r = document_meta_lint_all(str(p))
    assert "domain_detected" in r
    assert "summary" in r


def test_meta_lint_all_missing():
    from mcp_server_document.document_meta.tools import (
        document_meta_lint_all,
    )
    r = document_meta_lint_all("/nonexistent/nope.tex")
    assert "error" in r
