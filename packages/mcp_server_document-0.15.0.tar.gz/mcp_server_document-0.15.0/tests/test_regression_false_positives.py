"""Regression tests for known false-positive patterns reported by agents
during Plan B implementation (2026-04-23).

各 test は agent report から引用された具体的な false positive ケースを
固定。regex 緩和や闾値変更で regress しないよう回帰防止。
"""
from __future__ import annotations

import pytest


# ------------------------------------------------------------------
# grant_writing T8: has_concrete_locus の漢語 false positive
# (「社会的」「社員」「社交」等で誤発火しない)
# 履歴: v0.11.1 で enumerated company suffixes に書き換え済み
# ------------------------------------------------------------------
class TestGrantHookLocusRegression:
    def test_shakai_mushiro(self):
        from mcp_server_document.grant_writing.plan_b_T8 import (
            grant_writing_hook_strength,
        )
        # 「社会的」を含むが会社名は無い → locus False
        text = "本研究は社会的課題に取り組む。社会基盤の改善を目指す。"
        r = grant_writing_hook_strength(text)
        assert r["observations"]["has_concrete_locus"] is False

    def test_shagai_shanai_sharei(self):
        from mcp_server_document.grant_writing.plan_b_T8 import (
            grant_writing_hook_strength,
        )
        text = "社内教育の社員と社交辞令で議論する。社交的な場面もある。"
        r = grant_writing_hook_strength(text)
        assert r["observations"]["has_concrete_locus"] is False

    def test_real_company_still_detected(self):
        from mcp_server_document.grant_writing.plan_b_T8 import (
            grant_writing_hook_strength,
        )
        # 三菱電機 / 株式会社 など実社名は引き続き検出
        text = "三菱電機株式会社で 14 年勤務した経験を持つ。"
        r = grant_writing_hook_strength(text)
        assert r["observations"]["has_concrete_locus"] is True


# ------------------------------------------------------------------
# grant_writing T11: uptrajectory の文跨ぎ検出
# (v0.10.1 で [\s\S]{0,150} に広げた、遠距離ノイズは拾わない)
# ------------------------------------------------------------------
class TestGrantUptrajectoryRegression:
    def test_across_period(self):
        from mcp_server_document.grant_writing.plan_b_T11 import (
            grant_writing_continuity_check,
        )
        text = (
            "これまで当研究室では PCB 領域の電磁界ソルバを確立してきた。"
            "さらに本研究では AI 自律設計環境への発展を目指す。"
        )
        r = grant_writing_continuity_check(text)
        assert len(r["observations"]["uptrajectory_phrases"]) >= 1

    def test_far_apart_not_matched(self):
        from mcp_server_document.grant_writing.plan_b_T11 import (
            grant_writing_continuity_check,
        )
        filler = "本研究の背景として様々な要素がある。" * 20  # 500+ 字
        text = (
            "これまで多くの研究を確立してきた。" + filler +
            "さらに本研究では新しい方向へ進む。"
        )
        r = grant_writing_continuity_check(text)
        assert len(r["observations"]["uptrajectory_phrases"]) == 0


# ------------------------------------------------------------------
# grant_writing T12: カタカナ名・自己参照語の検出
# (v0.10.1 で追加)
# ------------------------------------------------------------------
class TestGrantCollaboratorRegression:
    def test_katakana_name_detected(self):
        from mcp_server_document.grant_writing.plan_b_T12 import (
            grant_writing_collaborator_roles_check,
        )
        text = "アダム・ジョン博士が国際連携を担当する。"
        r = grant_writing_collaborator_roles_check(text)
        names = [p["name"] for p in r["observations"]["people"]]
        assert any("アダム" in n for n in names)

    def test_applicant_self_reference_detected(self):
        from mcp_server_document.grant_writing.plan_b_T12 import (
            grant_writing_collaborator_roles_check,
        )
        text = "申請者は本研究の総括を担当する。"
        r = grant_writing_collaborator_roles_check(text)
        names = [p["name"] for p in r["observations"]["people"]]
        assert "申請者" in names


# ------------------------------------------------------------------
# grant_writing T13: LaTeX tabular 内の金額解析
# (v0.10.1 で tabular 前処理追加)
# ------------------------------------------------------------------
class TestGrantBudgetTabularRegression:
    def test_latex_tabular_consistent(self):
        from mcp_server_document.grant_writing.plan_b_T13 import (
            grant_writing_budget_logic_check,
        )
        tex = (
            r"\begin{tabular}{|l|r|}" + "\n"
            r"\hline" + "\n"
            r"物品費 & 100万円 \\" + "\n"
            r"旅費 & 50万円 \\" + "\n"
            r"人件費 & 30万円 \\" + "\n"
            r"その他 & 20万円 \\" + "\n"
            r"合計 & 200万円 \\" + "\n"
            r"\hline" + "\n"
            r"\end{tabular}"
        )
        r = grant_writing_budget_logic_check(tex)
        assert len(r["observations"]["amounts"]) >= 4
        assert r["observations"]["sum_matches_stated"] is True


# ------------------------------------------------------------------
# grant_writing T14: 令和・西暦混在の連続性正規化
# (v0.10.1 で西暦正規化、normalized_year 追加)
# ------------------------------------------------------------------
class TestGrantScheduleRegression:
    def test_reiwa_seireki_mixed_continuous(self):
        from mcp_server_document.grant_writing.plan_b_T14 import (
            grant_writing_schedule_consistency_check,
        )
        text = (
            "令和6年度は基礎検討を行う。"
            "2025年度は実証実験に移る。"
            "令和8年度に論文投稿し完成する。中間報告も行う。"
        )
        r = grant_writing_schedule_consistency_check(text)
        assert r["observations"]["year_continuity"] is True

    def test_reiwa_R_prefix_normalized(self):
        from mcp_server_document.grant_writing.plan_b_T14 import (
            grant_writing_schedule_consistency_check,
        )
        text = "R6 基盤検討、R7 実装、R8 完成、論文投稿。"
        r = grant_writing_schedule_consistency_check(text)
        years = sorted({
            m["normalized_year"] for m in r["observations"]["year_markers"]
            if m["normalized_year"] is not None
        })
        assert 2024 in years and 2025 in years and 2026 in years


# ------------------------------------------------------------------
# grant_writing NOTATION_PAIRS: 形式名詞の漢字熟語 false positive
# (v0.9.1 で 漢字前置 lookbehind に書き換え)
# ------------------------------------------------------------------
class TestGrantNotationPairsRegression:
    @pytest.mark.parametrize("text", [
        "仕事は進行中。事業は拡大。物事は変わる。",
        "時間は重要。時期が来る。開発時に確認。",
        "物質は分解。動物が登場。植物を観察。建物は古い。",
        "場所は決定。研究所で実験。近所に住む。",
        "行為は記録。為替が変動。作為に注意。",
    ])
    def test_kanji_compounds_not_flagged(self, text):
        from mcp_server_document.grant_writing.tools import (
            grant_writing_check_notation_variants,
        )
        r = grant_writing_check_notation_variants(text)
        # 形式名詞 pair は kana_kanji_variant type で出る
        kana_findings = [
            f for f in r["findings"] if f.get("type") == "kana_kanji_variant"
        ]
        # 漢字熟語のみ → kana_kanji_variant の variant_count は 0
        for f in kana_findings:
            assert f["variant_count"] == 0, (
                f"False positive for pattern {f['pattern']} in text: {text}"
            )


# ------------------------------------------------------------------
# presentation H4: font size master inheritance (v0.11.1 fix)
# 既存 test_presentation_hardening.py にあるが、重要度高のため
# regression として再確認
# ------------------------------------------------------------------
class TestPresentationFontSizeMasterRegression:
    def test_resolve_font_size_inheritance(self):
        """デフォルトテンプレ (font.size None) でも H4 の resolver が
        master/layout から値を拾う。"""
        pytest.importorskip("pptx")
        from pptx import Presentation
        # 実際にデフォルトテンプレートで作成した deck がある程度
        # resolved_font_size を出せるか smoke
        prs = Presentation()
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        # python-pptx のデフォルトレイアウトは 18pt 前後
        from mcp_server_document.presentation.tools import (
            presentation_check_pptx_font_size,
        )
        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".pptx", delete=False) as f:
            path = f.name
        prs.save(path)
        try:
            r = presentation_check_pptx_font_size(path, min_body_pt=40)
            # H4 fix が動けば unresolved_runs は全 run 数ではない
            assert "unresolved_runs" in r or "error" in r or "violations" in r
        finally:
            os.unlink(path)


# ------------------------------------------------------------------
# paper_writing H1: figure_forward_reference semantics reversal
# (v0.11.1 で position 比較を削除)
# ------------------------------------------------------------------
class TestPaperFigureForwardReferenceRegression:
    def test_no_forward_reference_count_key(self, tmp_path):
        """v0.11.1 で forward_reference_count は削除。orphan/dangling のみ。"""
        from mcp_server_document.paper_writing.tools import (
            paper_writing_check_figure_forward_reference,
        )
        tex_path = tmp_path / "p.tex"
        tex_path.write_text(
            r"As shown in Fig.~\ref{fig:a}, results converge. "
            r"\begin{figure}\caption{result}\label{fig:a}\end{figure}",
            encoding="utf-8",
        )
        r = paper_writing_check_figure_forward_reference(str(tex_path))
        assert "forward_reference_count" not in r
        assert "orphan_labels" in r or "labels_defined" in r


# ------------------------------------------------------------------
# paper_writing H2: equation_numbering 拡大パターン (v0.11.1)
# ------------------------------------------------------------------
class TestPaperEquationNumberingRegression:
    def test_align_star_detected(self, tmp_path):
        from mcp_server_document.paper_writing.tools import (
            paper_writing_check_equation_numbering,
        )
        tex_path = tmp_path / "eq.tex"
        tex_path.write_text(
            r"\begin{align*} x &= 1 \\ y &= 2 \end{align*}", encoding="utf-8"
        )
        r = paper_writing_check_equation_numbering(str(tex_path))
        # 旧 regex は align* を拾えなかった。新 regex は拾う。
        assert "error" not in r
        # 少なくとも 1 つの数式環境が検出されている
        assert any(
            isinstance(r.get(k), int) and r.get(k, 0) >= 1
            for k in ("equation_environments", "total_equations",
                      "env_count", "total_count", "environments_found")
        ) or any(
            isinstance(r.get(k), list) and len(r.get(k, [])) >= 1
            for k in ("environments", "equations", "found_envs")
        )


# ------------------------------------------------------------------
# paper_writing H3: .bib brace-balanced parser
# ------------------------------------------------------------------
class TestPaperBibBraceParserRegression:
    def test_stray_at_in_url_not_breaking(self, tmp_path):
        """url = {...@doi.org/...} の @ で body が切れないこと。"""
        from mcp_server_document.paper_writing.tools import (
            paper_writing_check_self_citation_ratio,
        )
        tex = tmp_path / "p.tex"
        bib = tmp_path / "b.bib"
        tex.write_text(r"See \cite{paper1}.", encoding="utf-8")
        bib.write_text(
            "@article{paper1,\n"
            '  author = {Sugahara, K.},\n'
            '  title = {Test Paper},\n'
            '  url = {https://test@doi.org/10.1234},\n'
            '  year = {2024}\n'
            "}\n",
            encoding="utf-8",
        )
        r = paper_writing_check_self_citation_ratio(
            str(tex), str(bib), author_last_names="Sugahara"
        )
        # author field が正しくパースされていれば self_cite として認識される
        assert "self_citation_count" in r or "self_cites" in r or \
               "total_citations" in r
