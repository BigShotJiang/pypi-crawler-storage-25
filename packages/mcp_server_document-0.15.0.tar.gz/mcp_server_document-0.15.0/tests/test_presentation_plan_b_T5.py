"""Tests for Plan B T5: presentation_check_progress_indicator.

4 cases:
1. Deck with Outline + section headers — longest_run < 10, score high
2. Long run without cue (20 content slides) — is_long_run_present True, score low
3. Empty deck / 1 slide — no crash
4. Outline-only (1 outline + 2 content) — is_long_run_present False, score high

Assertions focus on `observations` keys and `comments` substrings;
numeric score values are only checked as inequalities (not exact).
"""
from __future__ import annotations

import pathlib

import pytest


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _make_slide(prs, layout_idx: int, title: str, body: str | None = None):
    """Add a slide to *prs* using the layout at *layout_idx* and fill
    title / body placeholders when present."""
    slide = prs.slides.add_slide(prs.slide_layouts[layout_idx])
    for ph in slide.placeholders:
        try:
            if ph.placeholder_format.idx == 0:
                ph.text = title
            elif body is not None:
                ph.text = body
        except Exception:
            continue
    return slide


# ------------------------------------------------------------------
# Case 1: Outline + section headers — runs stay below threshold
# ------------------------------------------------------------------
def test_deck_with_outline_and_section_headers(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T5 import (
        presentation_check_progress_indicator,
    )

    prs = Presentation()
    # 1 Outline + 9 content + 1 section-2 + 5 content + 1 end
    _make_slide(prs, 1, "Outline", "1. Intro\n2. Method\n3. Results")
    for i in range(9):
        _make_slide(prs, 1, f"Method step {i + 1}", f"detail {i + 1}")
    _make_slide(prs, 1, "第2章 Results", "results follow")
    for i in range(5):
        _make_slide(prs, 1, f"Result {i + 1}", f"plot {i + 1}")
    _make_slide(prs, 1, "Conclusion", "take home")

    out = tmp_path / "with_outline.pptx"
    prs.save(str(out))

    r = presentation_check_progress_indicator(str(out), min_slides_without_cue=10)

    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 17
    # At least the "Outline" and "第2章 Results" slides are caught
    assert len(obs["section_header_indices"]) >= 2
    assert obs["longest_run_without_cue"] < 10, obs
    assert obs["is_long_run_present"] is False
    assert r["score"] >= 7

    joined = "\n".join(r["comments"])
    assert "section header" in joined or "進行位置 cue" in joined


# ------------------------------------------------------------------
# Case 2: Long run without cue — 20 content slides, no outline
# ------------------------------------------------------------------
def test_long_run_without_cue(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T5 import (
        presentation_check_progress_indicator,
    )

    prs = Presentation()
    for i in range(20):
        _make_slide(prs, 1, f"Content slide {i + 1}", f"bullet {i + 1}")

    out = tmp_path / "no_outline.pptx"
    prs.save(str(out))

    r = presentation_check_progress_indicator(str(out), min_slides_without_cue=10)

    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 20
    assert obs["section_header_indices"] == []
    assert obs["longest_run_without_cue"] == 20
    assert obs["is_long_run_present"] is True
    # Score is pushed low when run length far exceeds threshold.
    assert r["score"] <= 4, r

    joined = "\n".join(r["comments"])
    # Long-run warning must appear
    assert "section header / outline slide が無い" in joined \
        or "進行位置の cue" in joined
    # Strong warning for 15+ slide deck with zero cues
    assert "最低 1 枚は冒頭に目次" in joined


# ------------------------------------------------------------------
# Case 3: Empty deck / 1 slide — no crash, structure intact
# ------------------------------------------------------------------
def test_empty_deck_no_crash(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T5 import (
        presentation_check_progress_indicator,
    )

    prs = Presentation()
    out = tmp_path / "empty.pptx"
    prs.save(str(out))

    r = presentation_check_progress_indicator(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 0
    assert obs["section_header_indices"] == []
    assert obs["longest_run_without_cue"] == 0
    assert obs["is_long_run_present"] is False
    assert r["score"] == 10.0
    assert len(r["comments"]) >= 2


def test_single_slide_no_crash(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T5 import (
        presentation_check_progress_indicator,
    )

    prs = Presentation()
    _make_slide(prs, 1, "Only slide", "nothing else")
    out = tmp_path / "one.pptx"
    prs.save(str(out))

    r = presentation_check_progress_indicator(str(out), min_slides_without_cue=10)
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 1
    assert obs["longest_run_without_cue"] == 1
    assert obs["is_long_run_present"] is False
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Case 4: Outline-only — 1 outline + 2 content, run < threshold
# ------------------------------------------------------------------
def test_outline_only_small_deck(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T5 import (
        presentation_check_progress_indicator,
    )

    prs = Presentation()
    _make_slide(prs, 1, "Agenda", "1. Intro\n2. Result")
    _make_slide(prs, 1, "Intro", "background")
    _make_slide(prs, 1, "Result", "finding")

    out = tmp_path / "outline_only.pptx"
    prs.save(str(out))

    r = presentation_check_progress_indicator(str(out), min_slides_without_cue=10)
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 3
    # Agenda must be detected as outline
    assert len(obs["section_header_indices"]) >= 1
    assert 0 in obs["section_header_indices"]
    assert obs["is_long_run_present"] is False
    assert obs["longest_run_without_cue"] <= 2
    assert r["score"] >= 7

    joined = "\n".join(r["comments"])
    # Positive acknowledgement should fire
    assert "section header" in joined or "進行位置 cue" in joined


# ------------------------------------------------------------------
# Structural / hint-source contract
# ------------------------------------------------------------------
def test_hint_and_source_content(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T5 import (
        presentation_check_progress_indicator,
    )

    prs = Presentation()
    _make_slide(prs, 1, "x", "y")
    out = tmp_path / "tiny.pptx"
    prs.save(str(out))

    r = presentation_check_progress_indicator(str(out))
    assert r["score_max"] == 10
    assert "hint" in r and "layout" in r["hint"]
    assert "source" in r
    assert "S15" in r["source"]
    assert "宮野" in r["source"]


# ------------------------------------------------------------------
# Error path: missing file
# ------------------------------------------------------------------
def test_missing_file_returns_error(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T5 import (
        presentation_check_progress_indicator,
    )

    ghost = tmp_path / "does_not_exist.pptx"
    r = presentation_check_progress_indicator(str(ghost))
    assert "error" in r
    assert "not found" in r["error"]
