"""Tests for v0.5.0: diagram exact-trace + verify + OCR fill + smooth.

Uses a synthetic 60x60 raster (3 flat colors, solid background) so the round
trip through trace_exact → render-back can be pixel-perfect.
"""
from __future__ import annotations

import json
import pathlib

import pytest


def _make_flat_test_image(tmp_path: pathlib.Path) -> pathlib.Path:
    """Synthesize a 60x60 RGB image: white bg + red square + blue circle."""
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    import numpy as np
    import cv2
    img = np.full((60, 60, 3), 255, dtype=np.uint8)  # white BG
    # Red square 10-25 (BGR: 0,0,255)
    img[10:26, 10:26] = [0, 0, 255]
    # Blue circle centered at (45, 45) r=10 (BGR: 255, 0, 0)
    cv2.circle(img, (45, 45), 10, (255, 0, 0), thickness=-1)
    path = tmp_path / "synthetic_flat.png"
    cv2.imwrite(str(path), img)
    return path


def _make_stroke_test_excalidraw(tmp_path: pathlib.Path) -> pathlib.Path:
    """Excalidraw with a zig-zag line that smooth_polylines can compress."""
    doc = {
        "type": "excalidraw",
        "version": 2,
        "source": "test",
        "elements": [
            {
                "id": "zig1",
                "type": "line",
                "x": 10.0, "y": 10.0, "width": 90.0, "height": 10.0,
                "angle": 0, "strokeColor": "#000000",
                "backgroundColor": "transparent",
                "fillStyle": "solid", "strokeWidth": 1,
                "strokeStyle": "solid", "roughness": 0,
                "opacity": 100,
                "points": [
                    [0, 0], [1, 1], [2, 0], [3, 1], [4, 0], [5, 1],
                    [6, 0], [7, 1], [8, 0], [9, 1], [10, 0], [20, 5],
                    [30, 0], [40, 5], [50, 0], [60, 5], [70, 0], [80, 5],
                    [90, 0],
                ],
                "seed": 1, "version": 1, "versionNonce": 1,
                "isDeleted": False, "groupIds": [], "boundElements": None,
            }
        ],
        "appState": {"viewBackgroundColor": "#ffffff"},
    }
    path = tmp_path / "zigzag.excalidraw"
    path.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# trace_exact
# ---------------------------------------------------------------------------
def test_trace_exact_flat_image(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    from mcp_server_document.diagram.tools import diagram_trace_exact

    img_path = _make_flat_test_image(tmp_path)
    out_path = tmp_path / "exact.excalidraw"
    r = diagram_trace_exact(str(img_path), str(out_path),
                              max_colors=8, bg_detect=True)
    assert "error" not in r, r
    assert r["image_size"] == [60, 60]
    # 3 colors (white bg + red + blue) → 2 foreground clusters
    assert r["palette_size"] <= 8
    # At least 2 foreground polygons (red square + blue circle)
    assert r["total_elements"] >= 2
    # Out file is valid JSON
    doc = json.loads(out_path.read_text(encoding="utf-8"))
    assert doc["type"] == "excalidraw"
    assert len(doc["elements"]) == r["total_elements"]
    # All elements closed, solid fill, roughness=0
    for el in doc["elements"]:
        assert el["roughness"] == 0
        assert el["fillStyle"] == "solid"
        assert el["strokeWidth"] == 0
        # First and last point of polygon should coincide (closed)
        pts = el["points"]
        assert pts[0] == pts[-1]


def test_trace_exact_missing():
    from mcp_server_document.diagram.tools import diagram_trace_exact
    r = diagram_trace_exact("/nonexistent/nope.png", "/tmp/out.excalidraw")
    assert "error" in r


def test_trace_exact_with_simplify(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    from mcp_server_document.diagram.tools import diagram_trace_exact

    img_path = _make_flat_test_image(tmp_path)
    out_exact = tmp_path / "e.excalidraw"
    out_approx = tmp_path / "a.excalidraw"
    r_exact = diagram_trace_exact(str(img_path), str(out_exact),
                                    simplify_tolerance=0.0)
    r_approx = diagram_trace_exact(str(img_path), str(out_approx),
                                     simplify_tolerance=2.0)
    # Simplified should have fewer total vertices
    vx_exact = sum(c["total_vertices"] for c in r_exact["per_color"])
    vx_approx = sum(c["total_vertices"] for c in r_approx["per_color"])
    assert vx_approx <= vx_exact


# ---------------------------------------------------------------------------
# verify_pixel_match
# ---------------------------------------------------------------------------
def test_verify_pixel_match_roundtrip(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    pytest.importorskip("PIL")
    from mcp_server_document.diagram.tools import (
        diagram_trace_exact, diagram_verify_pixel_match,
    )

    img_path = _make_flat_test_image(tmp_path)
    out = tmp_path / "exact.excalidraw"
    diag = tmp_path / "diff.png"
    diagram_trace_exact(str(img_path), str(out), max_colors=8)
    r = diagram_verify_pixel_match(str(out), str(img_path),
                                      out_diff_png=str(diag))
    assert "error" not in r, r
    # For flat-color synthetic, PSNR should be very high
    psnr = r["psnr_db"]
    assert psnr == "inf" or float(psnr) >= 30, r
    assert r["mismatch_pixels_pct"] <= 10.0, r
    assert diag.exists()


def test_verify_pixel_match_missing():
    from mcp_server_document.diagram.tools import diagram_verify_pixel_match
    r = diagram_verify_pixel_match("/no/nope.excalidraw", "/no/nope.png")
    assert "error" in r


# ---------------------------------------------------------------------------
# text_fill_from_ocr (smoke — skip if pytesseract missing)
# ---------------------------------------------------------------------------
def test_text_fill_missing_files():
    from mcp_server_document.diagram.tools import diagram_text_fill_from_ocr
    r = diagram_text_fill_from_ocr(
        "/no/nope.excalidraw", "/no/nope.png", "/tmp/out.excalidraw"
    )
    assert "error" in r


def test_text_fill_passthrough_no_placeholders(tmp_path):
    pytest.importorskip("pytesseract")
    pytest.importorskip("PIL")
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    from mcp_server_document.diagram.tools import diagram_text_fill_from_ocr

    img_path = _make_flat_test_image(tmp_path)
    doc_path = tmp_path / "doc.excalidraw"
    doc_path.write_text(json.dumps({
        "type": "excalidraw", "version": 2,
        "elements": [
            {"id": "non_placeholder", "type": "rectangle",
             "x": 0, "y": 0, "width": 10, "height": 10,
             "text": "", "groupIds": [], "isDeleted": False},
        ],
        "appState": {},
    }), encoding="utf-8")
    out = tmp_path / "filled.excalidraw"
    r = diagram_text_fill_from_ocr(str(doc_path), str(img_path), str(out))
    # Errors allowed if Tesseract binary not present; either way smoke-only.
    assert isinstance(r, dict)


# ---------------------------------------------------------------------------
# smooth_polylines
# ---------------------------------------------------------------------------
def test_smooth_polylines_compression(tmp_path):
    from mcp_server_document.diagram.tools import diagram_smooth_polylines

    src = _make_stroke_test_excalidraw(tmp_path)
    out = tmp_path / "smoothed.excalidraw"
    r = diagram_smooth_polylines(str(src), str(out),
                                   epsilon=2.0, chaikin_iterations=2,
                                   only_types="line", min_points=5)
    assert "error" not in r, r
    assert r["elements_modified"] == 1
    # With epsilon=2.0 RDP removes many zig-zags, Chaikin adds some back,
    # net should be different from input — just smoke-check monotone fields.
    assert r["points_before"] >= r["points_after"] or r["compression_pct"] < 0


def test_smooth_polylines_no_match(tmp_path):
    from mcp_server_document.diagram.tools import diagram_smooth_polylines

    src = _make_stroke_test_excalidraw(tmp_path)
    out = tmp_path / "unchanged.excalidraw"
    r = diagram_smooth_polylines(str(src), str(out),
                                   only_types="freedraw",  # no match
                                   min_points=5)
    assert r["elements_modified"] == 0


def test_smooth_polylines_missing():
    from mcp_server_document.diagram.tools import diagram_smooth_polylines
    r = diagram_smooth_polylines("/no/nope.excalidraw", "/tmp/o.excalidraw")
    assert "error" in r
