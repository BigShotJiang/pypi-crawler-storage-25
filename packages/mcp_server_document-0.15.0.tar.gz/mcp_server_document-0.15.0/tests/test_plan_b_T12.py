"""Tests for Plan B T12: grant_writing_collaborator_roles_check.

Covers 4 cases: all roles clear / partial / no people / with applicant_name.
Assertions prioritize `observations` counts and `comments` substrings over
exact numeric scores.
"""
from mcp_server_document.grant_writing.plan_b_T12 import (
    grant_writing_collaborator_roles_check,
)


# ------------------------------------------------------------------
# Case 1: All roles clear
# ------------------------------------------------------------------
def test_all_roles_clear_scores_ten():
    text = "山田太郎教授が解析を担当する。鈴木花子博士が測定を実施する。"
    r = grant_writing_collaborator_roles_check(text)

    # 構造
    assert r["score_max"] == 10
    assert isinstance(r["comments"], list)
    assert "skill.md T2" in r["source"]

    obs = r["observations"]
    assert obs["total_people"] == 2
    assert obs["with_role"] == 2
    assert obs["without_role"] == 0

    # 全員に役割 → score は満点
    assert r["score"] == 10 or r["score"] == 10.0

    # 役割動詞集合に「担当」「実施」が含まれる
    verbs = set(obs["role_verbs_found_overall"])
    assert "担当" in verbs
    assert "実施" in verbs

    # 肯定コメントが含まれる
    joined = "\n".join(r["comments"])
    assert "全員" in joined or "十分" in joined


# ------------------------------------------------------------------
# Case 2: Partial — 1 with role, 1 without
# ------------------------------------------------------------------
def test_partial_roles_mid_score_and_lists_missing_person():
    text = "山田太郎教授が解析を担当する。鈴木花子博士は共著者である。"
    r = grant_writing_collaborator_roles_check(text)

    obs = r["observations"]
    assert obs["total_people"] == 2
    assert obs["with_role"] >= 1
    assert obs["without_role"] >= 1

    # score は中程度 (満点未満、0 以上)
    assert 0 < r["score"] < 10

    # 鈴木花子博士 が未記述リストに名指しで出ている
    joined = "\n".join(r["comments"])
    assert "鈴木花子博士" in joined
    assert "役割" in joined

    # 未記述の人物は role_verb=None
    missing = [p for p in obs["people"] if p["role_verb"] is None]
    assert any("鈴木花子博士" in p["name"] for p in missing)


# ------------------------------------------------------------------
# Case 3: No people
# ------------------------------------------------------------------
def test_no_people_returns_reasonable_score_and_advises():
    text = (
        "本研究は新規材料設計手法の開発を目的とする。"
        "複数の理論モデルを体系的に比較検証する予定である。"
    )
    r = grant_writing_collaborator_roles_check(text)

    obs = r["observations"]
    assert obs["total_people"] == 0
    assert obs["with_role"] == 0
    assert obs["without_role"] == 0
    assert obs["people"] == []

    # score は None 禁止。5 を使う仕様。
    assert r["score"] is not None
    assert r["score"] == 5 or r["score"] == 5.0

    # コメントが共同研究者の追記を促す
    joined = "\n".join(r["comments"])
    assert (
        "検出されなかった" in joined
        or "共同研究者" in joined
    )


# ------------------------------------------------------------------
# Case 4: With applicant_name — flags is_applicant
# ------------------------------------------------------------------
def test_applicant_name_flags_is_applicant():
    text = "山田太郎教授が解析を担当する。鈴木花子博士が測定を実施する。"
    r = grant_writing_collaborator_roles_check(text, applicant_name="山田太郎")

    obs = r["observations"]
    assert obs["total_people"] == 2

    applicants = [p for p in obs["people"] if p["is_applicant"]]
    assert len(applicants) == 1
    assert "山田太郎" in applicants[0]["name"]
    assert applicants[0]["is_applicant"] is True

    # 他方の人物は is_applicant=False
    non_applicants = [p for p in obs["people"] if not p["is_applicant"]]
    assert len(non_applicants) == 1
    assert "鈴木花子博士" in non_applicants[0]["name"]


# ------------------------------------------------------------------
# Additional: applicant present but without role verb triggers special comment
# ------------------------------------------------------------------
def test_applicant_without_role_gets_special_comment():
    text = "山田太郎教授は本課題の申請者である。鈴木花子博士が測定を担当する。"
    r = grant_writing_collaborator_roles_check(text, applicant_name="山田太郎")

    obs = r["observations"]
    applicants = [p for p in obs["people"] if p["is_applicant"]]
    assert len(applicants) == 1
    # 申請者に役割動詞が無い
    assert applicants[0]["role_verb"] is None

    joined = "\n".join(r["comments"])
    assert "申請者" in joined
    assert "山田太郎" in joined


# ------------------------------------------------------------------
# Additional: hint / source content
# ------------------------------------------------------------------
def test_hint_and_source_content():
    r = grant_writing_collaborator_roles_check("テスト本文。")
    assert "正規表現" in r["hint"]
    assert "敬称" in r["hint"]
    assert "skill.md T2" in r["source"]
    assert "check_character_list" in r["source"]


# ------------------------------------------------------------------
# Additional: empty / None inputs
# ------------------------------------------------------------------
def test_empty_text_no_crash():
    r = grant_writing_collaborator_roles_check("")
    assert r["observations"]["total_people"] == 0
    assert len(r["comments"]) >= 2


def test_none_text_no_crash():
    r = grant_writing_collaborator_roles_check(None)  # type: ignore[arg-type]
    assert r["observations"]["total_people"] == 0


# ------------------------------------------------------------------
# 2026-04-23 hardening: カタカナ名・自己参照の検出
# ------------------------------------------------------------------
def test_katakana_name_with_honorific():
    """「アダム・ジョン博士」のようなカタカナ名 + 敬称を検出。"""
    text = "アダム・ジョン博士が国際連携を担当する。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert any("アダム" in n and "博士" in n for n in names)
    people = [p for p in r["observations"]["people"] if "アダム" in p["name"]]
    assert any(p["role_verb"] is not None for p in people)


def test_katakana_name_with_equal_sign():
    """「マリー＝キュリー先生」のような = / ＝ / - を含むカタカナ名を検出。"""
    text = "マリー＝キュリー先生が共同研究を主導する。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert any("マリー" in n and "先生" in n for n in names)


def test_self_reference_applicant_detected():
    """「申請者」「筆者」「研究代表者」等の自己参照語を人物扱い。"""
    text = "申請者は本研究の総括を担当する。筆者は過去に電磁界解析を実施してきた。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert "申請者" in names
    assert "筆者" in names


def test_self_reference_without_role_flagged():
    """自己参照語があるが役割動詞が近くに無い場合は without_role カウント。"""
    text = "申請者については後述する。本研究の背景は以下の通りである。"
    r = grant_writing_collaborator_roles_check(text)
    people_names = [p["name"] for p in r["observations"]["people"]]
    assert "申請者" in people_names
    assert r["observations"]["without_role"] >= 1


# ------------------------------------------------------------------
# v0.14.1: noun + 様 / bare honorific false positive 除外
# 実稿 (KDDI 2027 / パワーアカデミー 2026) で検出された regression
# ------------------------------------------------------------------
def test_ouboushosama_not_person():
    """「応募書様」は人物扱いしない (v0.14.1 regression)。"""
    text = "応募書様の注意点を読む。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert "応募書様" not in names


def test_tayou_not_person():
    """「多様」は人物扱いしない。"""
    text = "多様な観点から議論する。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert not any("多様" in n for n in names)


def test_shiyou_not_person():
    """「仕様」「様子」「模様」等の noun + 様 は除外。"""
    text = "仕様を確認する。様子を見る。模様である。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert names == []


def test_ichiyou_douyou_not_person():
    """「一様」「同様」「異様」「奇様」は除外。"""
    text = "一様な場を仮定する。同様の結果。異様な光景。奇様な現象。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert names == []


def test_ousama_kamisama_not_person():
    """「王様」「神様」等の 1-kanji noun + 様 も除外。"""
    text = "王様や神様は伝説に登場する。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert names == []


def test_bare_junkyouju_not_person():
    """単独の「准教授」(bare honorific) は人物扱いしない。"""
    text = "准教授を招聘する。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert "准教授" not in names
    assert names == []


def test_real_person_name_still_detected_after_fix():
    """山田太郎教授 等の実人名は引き続き検出 (v0.14.1 no regression)。"""
    text = "山田太郎教授が担当する。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert any("山田" in n and "教授" in n for n in names)


def test_two_kanji_surname_with_sama_still_detected():
    """2-kanji 姓 + 様 (e.g. 「佐藤様」) は依然として人物扱い。"""
    text = "佐藤様が本日来訪した。"
    r = grant_writing_collaborator_roles_check(text)
    names = [p["name"] for p in r["observations"]["people"]]
    assert any("佐藤" in n and "様" in n for n in names)


def test_unique_name_scoring_not_inflated_by_repeats():
    """同じ名前が複数回出ても、unique 名ベースで score を計算する。

    旧実装: 「申請者」が 5 回登場し 1 回だけ役割動詞が近接 → score = 2.0
    新実装: unique 名数 1、そのうち 1 名が役割あり → score = 10.0
    """
    text = (
        "申請者は本研究の総括を担当する。"
        "申請者については後述する。"
        "申請者の所属は大学である。"
        "申請者の専門は電磁界解析である。"
        "申請者の経歴は 20 年に及ぶ。"
    )
    r = grant_writing_collaborator_roles_check(text)
    assert r["observations"]["unique_names_count"] == 1
    assert r["observations"]["with_role"] == 1
    assert r["score"] == 10.0
