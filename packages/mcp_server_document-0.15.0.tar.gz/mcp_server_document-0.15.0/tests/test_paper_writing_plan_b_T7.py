"""Tests for Plan B T7: paper_writing_given_new_ordering.

4 cases:
1. good_flow — EN paragraph where each sentence tail is echoed in next head
2. broken_flow — EN paragraph where consecutive sentences share no entities
3. single_sentence — only one sentence; total_sentence_pairs == 0, score 5
4. ja_given_new — JA paragraph with Kanji / Katakana compounds as connectors

Assertions focus on structure, key `observations` values, and comment
substrings. Exact numeric scores are NOT asserted tightly because the
tool is heuristic by design.
"""
from mcp_server_document.paper_writing.plan_b_T7 import (
    paper_writing_given_new_ordering,
)


# ------------------------------------------------------------------
# Case 1: good flow
# ------------------------------------------------------------------
def test_good_flow_en():
    text = (
        "We apply the proposed solver to the EddyCurrent benchmark. "
        "The EddyCurrent benchmark consists of 128 test geometries. "
        "Each of the 128 geometries is discretized with 50000 elements. "
        "These 50000 elements are then assembled into the SurfaceIntegral "
        "matrix. The SurfaceIntegral matrix has rank 48000."
    )
    r = paper_writing_given_new_ordering(text)

    # structure
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 5
    assert "Wallwork" in r["source"]
    assert "skill.md" in r["source"]
    assert "heuristic" in r["hint"]

    obs = r["observations"]
    assert obs["language"] == "en"
    assert obs["total_sentence_pairs"] >= 3
    # 各 pair で前文末の term (EddyCurrent / 128 / 50000 / SurfaceIntegral)
    # が次文頭に出る
    assert obs["ok_pairs"] >= 3
    assert obs["ok_ratio"] >= 0.6

    # 高スコア
    assert r["score"] >= 6
    joined = "\n".join(r["comments"])
    assert "良好" in joined or "機能" in joined


# ------------------------------------------------------------------
# Case 2: broken flow
# ------------------------------------------------------------------
def test_broken_flow_en():
    text = (
        "The proposed method reduces the computational cost by an order "
        "of magnitude. Electric vehicles are becoming popular worldwide. "
        "Quantum computers promise exponential speedup for certain tasks. "
        "Photosynthesis converts sunlight into chemical energy in plants."
    )
    r = paper_writing_given_new_ordering(text)

    obs = r["observations"]
    assert obs["total_sentence_pairs"] >= 2
    # ほぼ全 pair で entity 共有なし
    assert obs["ok_ratio"] < 0.5
    # poor_pairs に記録される
    assert len(obs["poor_pairs"]) >= 1
    pp = obs["poor_pairs"][0]
    assert "pair_idx" in pp
    assert "s1_tail" in pp
    assert "s2_head" in pp
    assert "reason" in pp

    joined = "\n".join(r["comments"])
    # 弱 or 中程度の指摘
    assert (
        "弱い" in joined
        or "中程度" in joined
        or "追いかけられない" in joined
        or "追いにくい" in joined
    )


# ------------------------------------------------------------------
# Case 3: single sentence — pairs == 0, score 5
# ------------------------------------------------------------------
def test_single_sentence():
    text = "We propose a new boundary-integral solver for eddy-current problems."
    r = paper_writing_given_new_ordering(text)

    obs = r["observations"]
    assert obs["total_sentence_pairs"] == 0
    assert obs["ok_pairs"] == 0
    assert obs["poor_pairs"] == []

    # score は 5 (heuristic N/A)
    assert r["score"] == 5.0

    joined = "\n".join(r["comments"])
    assert "単文" in joined or "無関係" in joined


# ------------------------------------------------------------------
# Case 4: JA given-new
# ------------------------------------------------------------------
def test_ja_given_new():
    text = (
        "我々は新しい境界積分ソルバを提案する。"
        "この境界積分ソルバは50000要素の離散化に適用できる。"
        "50000要素の離散化は従来手法より高速である。"
        "従来手法との比較実験を第3節で述べる。"
    )
    r = paper_writing_given_new_ordering(text)

    obs = r["observations"]
    assert obs["language"] == "ja"
    assert obs["total_sentence_pairs"] >= 2
    # 境界積分ソルバ / 50000 / 要素 / 従来手法 が連鎖する
    assert obs["ok_pairs"] >= 2
    assert obs["ok_ratio"] >= 0.5


# ------------------------------------------------------------------
# Additional: empty / None input robustness
# ------------------------------------------------------------------
def test_empty_input_no_crash():
    r = paper_writing_given_new_ordering("")
    assert "score" in r
    assert r["observations"]["total_sentence_pairs"] == 0
    # 単文扱い = score 5
    assert r["score"] == 5.0
    assert len(r["comments"]) >= 2


def test_none_input_no_crash():
    r = paper_writing_given_new_ordering(None)  # type: ignore[arg-type]
    assert r["observations"]["total_sentence_pairs"] == 0
    assert r["score"] == 5.0


# ------------------------------------------------------------------
# hint / source fixed content
# ------------------------------------------------------------------
def test_hint_and_source_content():
    r = paper_writing_given_new_ordering("test sentence.")
    assert "heuristic" in r["hint"]
    assert "Wallwork" in r["source"]
    assert "Given-New" in r["source"]
    assert "Halliday" in r["source"]
