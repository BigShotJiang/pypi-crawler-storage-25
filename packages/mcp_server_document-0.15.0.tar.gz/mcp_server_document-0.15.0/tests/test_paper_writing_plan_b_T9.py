"""Tests for Plan B T9: paper_writing_reviewer_2_trigger_summary.

5 cases:
1. clean_paper — quantified claims, limitation present, low self-cite:
   score high, top_triggers empty or minimal.
2. hype_heavy — many unquantified hype sentences:
   'unquantified_hype' in top_triggers, strong comment.
3. no_limitation — Discussion without limitation paragraph:
   'no_limitation' in top_triggers, reviewer-2 voice comment.
4. no_bib — self-cite check must be skipped when bib omitted:
   'self_cite_excess' is not among active triggers.
5. empty_text — returns reasonable score / shape without crashing.

Assertions focus on structure + membership of top_triggers; exact scores
are NOT tightly asserted because the tool is heuristic by design.
"""
from __future__ import annotations

from mcp_server_document.paper_writing.plan_b_T9 import (
    paper_writing_reviewer_2_trigger_summary,
)


# ------------------------------------------------------------------
# Shape helper
# ------------------------------------------------------------------
def _check_shape(r: dict) -> None:
    assert set(r.keys()) >= {
        "score", "score_max", "comments", "observations", "hint", "source",
    }
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert isinstance(r["comments"], list)
    assert 2 <= len(r["comments"]) <= 5
    obs = r["observations"]
    for key in ("risk_score_raw", "risk_percent", "triggers", "top_triggers"):
        assert key in obs, f"observations missing {key}"
    assert isinstance(obs["triggers"], list)
    assert isinstance(obs["top_triggers"], list)
    for t in obs["triggers"]:
        for k in ("name", "weight", "count", "contribution"):
            assert k in t, f"trigger missing {k}"
    assert "reviewer-2" in r["source"] or "Reviewer 2" in r["source"] \
        or "archetype" in r["source"]


# ------------------------------------------------------------------
# Case 1: clean paper (quantified, limitation present, low self-cite)
# ------------------------------------------------------------------
def test_clean_paper_has_high_score():
    """Quantified claims + limitation + referenced figures → reviewer-2 safe."""
    tex = (
        r"\section{Introduction}"
        r"The proposed method achieves 3.2x speed-up \cite{ref1} over the "
        r"baseline, and reduces memory by 24\% \cite{ref2}."
        r"Related work \cite{ref3,ref4,ref5} focuses on orthogonal aspects."
        r"\begin{figure}\caption{Setup}\label{fig:setup}\end{figure}"
        r"As shown in Fig.~\ref{fig:setup}, the pipeline is modular."
        r"Figure~\ref{fig:setup} is also referenced in the results."
        r"\section{Discussion}"
        r"The main finding is that the 3.2x speed-up holds across datasets."
        r"A key limitation is that our evaluation covers only synthetic data; "
        r"real-world traces may introduce noise that we have not yet "
        r"characterised, and the method assumes dense connectivity which "
        r"restricts applicability in sparse graphs. We plan to address "
        r"these constraints in follow-up studies."
        r"Finally, we conclude that the approach is promising."
    )
    bib = (
        "@article{ref1,author={Alice Smith},year={2024},title={Benchmark}}\n"
        "@article{ref2,author={Bob Tanaka},year={2023},title={Memory}}\n"
        "@article{ref3,author={Carol Jones},year={2024},title={Survey}}\n"
        "@article{ref4,author={Dan Wilson},year={2022},title={Theory}}\n"
        "@article{ref5,author={Eve Brown},year={2023},title={Related}}\n"
    )
    r = paper_writing_reviewer_2_trigger_summary(
        tex, bib=bib, author_last_names="Sugahara"
    )
    _check_shape(r)

    obs = r["observations"]
    # hype の定量付けが OK なので unquantified_hype は top にこない
    assert "unquantified_hype" not in obs["top_triggers"]
    # limitation あり → no_limitation も top にない
    assert "no_limitation" not in obs["top_triggers"]
    # self-cite は 0 (authors_set ≠ bib authors)
    assert "self_cite_excess" not in obs["top_triggers"]

    # 攻撃面小 ⇒ 高スコア (粗い、>= 7)
    assert r["score"] >= 7.0, f"expected clean score>=7, got {r['score']}"
    assert obs["risk_percent"] <= 30.0


# ------------------------------------------------------------------
# Case 2: hype-heavy paper (many unquantified hype claims)
# ------------------------------------------------------------------
def test_hype_heavy_unquantified_in_top():
    """数値/引用なしの hype 文多数 → unquantified_hype が top に来る。"""
    tex = (
        "Our method is significantly better than prior art. "
        "The proposed scheme is substantially faster than baselines. "
        "We achieve superior accuracy across all settings. "
        "The system is remarkably efficient. "
        "Results are notable and outperform existing approaches. "
        "\\section{Discussion}"
        "We conclude. A limitation is that evaluation is narrow; more "
        "experiments are needed in follow-up work to address this limited "
        "scope and potential generalisation concerns."
    )
    r = paper_writing_reviewer_2_trigger_summary(tex)
    _check_shape(r)

    obs = r["observations"]
    assert "unquantified_hype" in obs["top_triggers"], (
        f"expected unquantified_hype in top, got {obs['top_triggers']}"
    )
    # 先頭が最大 contribution (weight 3.0 かつ count 多い)
    assert obs["top_triggers"][0] == "unquantified_hype"

    # Reviewer-2 voice comment
    joined = "\n".join(r["comments"])
    assert "Reviewer" in joined or "reviewer" in joined
    assert "hype" in joined or "better than" in joined

    # 攻撃面大 → score は clean paper より低くなるはず (粗い温度計)
    # 5 件の hype 寄与 (weight 3.0) は risk に強く効く
    assert obs["risk_percent"] >= 15.0
    # unquantified_hype の contribution が全 trigger 中最大
    first = obs["triggers"][0]
    assert first["name"] == "unquantified_hype"
    assert first["contribution"] >= 2.0


# ------------------------------------------------------------------
# Case 3: no limitation — Discussion present but without limitation
# ------------------------------------------------------------------
def test_no_limitation_in_top():
    """Discussion はあるが limitation 段落無し → no_limitation が top。"""
    tex = (
        r"\section{Introduction}"
        r"We propose a solver achieving 4.1\% accuracy gain \cite{ref}."
        r"\section{Discussion}"
        r"The results indicate that the approach works on the benchmarks. "
        r"Overall the contribution advances the state of the art. "
        r"Future work will explore new datasets. "
        r"The conclusion is that the method is applicable."
    )
    r = paper_writing_reviewer_2_trigger_summary(tex)
    _check_shape(r)

    obs = r["observations"]
    assert "no_limitation" in obs["top_triggers"], (
        f"expected no_limitation in top, got {obs['top_triggers']}"
    )

    joined = "\n".join(r["comments"])
    assert "limitation" in joined.lower()
    assert "Reviewer" in joined or "reviewer" in joined


# ------------------------------------------------------------------
# Case 4: no bib → self-cite check auto-skipped
# ------------------------------------------------------------------
def test_missing_bib_skips_self_cite():
    """bib 未指定時は self_cite_excess が trigger 0 (skipped)。"""
    tex = (
        "The approach reduces cost by 24% \\cite{anyref}. "
        "See Section 2 for details. "
        "\\section{Discussion}"
        "A limitation is the synthetic nature of the benchmark; "
        "real-world deployment introduces noise we have not characterised "
        "and the 24% gain may not transfer cleanly to larger-scale traces "
        "as noted in our preliminary experiments."
    )
    # bib 未指定
    r = paper_writing_reviewer_2_trigger_summary(tex)
    _check_shape(r)

    obs = r["observations"]
    # self_cite_excess は top triggers に来てはならない
    assert "self_cite_excess" not in obs["top_triggers"]

    # かつ triggers 内の self_cite_excess は skipped マークが付く
    sc_entries = [t for t in obs["triggers"] if t["name"] == "self_cite_excess"]
    assert len(sc_entries) == 1
    sc = sc_entries[0]
    assert sc["count"] == 0.0
    assert sc["contribution"] == 0.0
    # extra にも skipped=True が出ている
    extra = sc.get("extra", {})
    assert extra.get("skipped") is True


# ------------------------------------------------------------------
# Case 5: empty text — returns reasonable shape without crashing
# ------------------------------------------------------------------
def test_empty_text_reasonable():
    """空テキストは crash せず、score は reasonable (0-10) / top_triggers 最小限。"""
    r = paper_writing_reviewer_2_trigger_summary("")
    _check_shape(r)

    obs = r["observations"]
    # 空文字は基本的に trigger を発火させない (hype 0 / figure 0 / etc.)
    # → top_triggers は空
    assert obs["top_triggers"] == []
    # score は高い (safe) 想定
    assert r["score"] >= 8.0
    # すべての trigger count は 0 に近い
    assert obs["risk_score_raw"] <= 1.0


# ------------------------------------------------------------------
# Bonus: None inputs tolerated
# ------------------------------------------------------------------
def test_none_inputs_tolerated():
    r = paper_writing_reviewer_2_trigger_summary(None, bib=None, author_last_names=None)
    _check_shape(r)
