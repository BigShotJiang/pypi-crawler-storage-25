"""Tests for T16 grant_writing_health_report — meta aggregation."""
from mcp_server_document.grant_writing.plan_b_T16 import grant_writing_health_report


def test_health_report_shape():
    text = "本研究は新しい手法を提案する。"
    r = grant_writing_health_report(text)
    assert "overall_score" in r
    assert "overall_severity" in r
    assert "priority_issues" in r
    assert "summary_comment" in r
    assert "detailed_scores" in r
    assert 0 <= r["overall_score"] <= 10


def test_health_report_critical_for_weak_draft():
    """骨格が欠けた初稿は CRITICAL が複数出るべき。"""
    text = "本研究は適切に進める。"
    r = grant_writing_health_report(text)
    severities = [i["severity"] for i in r["priority_issues"]]
    assert "CRITICAL" in severities or "HIGH" in severities
    assert r["overall_severity"] in ("CRITICAL", "HIGH", "MEDIUM")


def test_health_report_priority_sort():
    """priority_issues は CRITICAL が先頭。"""
    text = "本研究は適切に進める。"
    r = grant_writing_health_report(text)
    sevs = [i["severity"] for i in r["priority_issues"]]
    rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "UNKNOWN": 3, "LOW": 4}
    assert sevs == sorted(sevs, key=lambda s: rank.get(s, 99))


def test_health_report_skip_arg():
    """skip='T13,T14' で予算・スケジュール診断を除外できる。"""
    text = "本研究は新規手法を明らかにする。"
    r = grant_writing_health_report(text, skip="T13,T14")
    assert "T13" not in r["tools_run"]
    assert "T14" not in r["tools_run"]
    assert "T13" in r["tools_skipped"]
    assert "T14" in r["tools_skipped"]


def test_health_report_summary_comment_grounded():
    """summary_comment は CRITICAL/HIGH 件数を反映する。"""
    text = ""
    r = grant_writing_health_report(text)
    # Empty text → many CRITICAL
    assert isinstance(r["summary_comment"], str)
    assert len(r["summary_comment"]) > 20


def test_health_report_source_mentions_plan_b():
    text = "本研究は新規手法を明らかにする。"
    r = grant_writing_health_report(text)
    assert "Plan B" in r["source"]
