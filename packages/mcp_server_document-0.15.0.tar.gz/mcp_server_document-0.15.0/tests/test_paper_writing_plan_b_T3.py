"""Tests for Plan B T3: paper_writing_claim_quantification.

5 cases:
1. quantified_ok         — hype words backed by numbers / cite / figref → 0 flagged
2. unquantified_hype_flagged — bare hype → all flagged
3. mixed                 — half backed, half bare → partial flag count
4. empty                 — empty input → total_sentences == 0, comments ≥ 2
5. with_cite_counts_as_quantified — \\cite counts as quantification

Assertions focus on `observations` counts and key `comments` substrings.
Do NOT over-assert exact scores.
"""
from mcp_server_document.paper_writing.plan_b_T3 import (
    paper_writing_claim_quantification,
)


# ------------------------------------------------------------------
# Case 1: fully quantified hype → no flags
# ------------------------------------------------------------------
def test_quantified_ok_no_flags():
    text = (
        "The proposed method is 3.2× faster than the baseline. "
        "Accuracy improved significantly by 12% over prior work. "
        "The method is substantially better as shown in Fig. 5."
    )
    r = paper_writing_claim_quantification(text)

    # 構造
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert 2 <= len(r["comments"]) <= 5
    assert "skill.md NG #7" in r["source"]
    assert "Wallwork" in r["source"]

    obs = r["observations"]
    assert obs["total_sentences"] == 3
    # hype word の数だけ検出される
    assert len(obs["hype_sentences"]) >= 2
    # 全て 1 つ以上の裏付けあり
    for h in obs["hype_sentences"]:
        assert h["has_number"] or h["has_cite"] or h["has_figref"]
    assert obs["unquantified_count"] == 0
    assert obs["unquantified_examples"] == []
    # score は満点
    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    assert "reviewer-2 防衛済み" in joined or "防衛済み" in joined


# ------------------------------------------------------------------
# Case 2: bare hype → all flagged
# ------------------------------------------------------------------
def test_unquantified_hype_flagged():
    text = (
        "Our method is significantly better than existing approaches. "
        "The algorithm is substantially faster in practice. "
        "Results are remarkable and the approach is superior. "
        "The technique is highly effective."
    )
    r = paper_writing_claim_quantification(text)

    obs = r["observations"]
    assert obs["total_sentences"] == 4
    # 全ての文に hype があり、どれも裏付け無し
    assert len(obs["hype_sentences"]) == 4
    for h in obs["hype_sentences"]:
        assert h["has_number"] is False
        assert h["has_cite"] is False
        assert h["has_figref"] is False
    assert obs["unquantified_count"] == 4
    # unquantified_examples は最大 5 件 (ここでは 4 件)
    assert len(obs["unquantified_examples"]) == 4
    for ex in obs["unquantified_examples"]:
        assert "sentence" in ex
        assert "hype_word" in ex
        assert "pos" in ex
        # 120 文字以内に切り詰められている
        assert len(ex["sentence"]) <= 120

    # score = 10 - 4 = 6
    assert r["score"] == 6.0

    joined = "\n".join(r["comments"])
    assert "定量化されていない" in joined
    assert "reviewer-2" in joined
    # 件数指摘
    assert "4" in joined


# ------------------------------------------------------------------
# Case 3: mixed — half backed, half bare
# ------------------------------------------------------------------
def test_mixed_partial_flag():
    text = (
        "Our method is significantly better than existing approaches. "
        "The algorithm achieves 5.1× faster throughput. "
        "Results are remarkable in practice. "
        "Performance is superior as shown in Fig. 3."
    )
    r = paper_writing_claim_quantification(text)

    obs = r["observations"]
    assert obs["total_sentences"] == 4
    assert len(obs["hype_sentences"]) == 4
    # 2 件は裏付け付き (数値 or figref), 2 件は bare
    assert obs["unquantified_count"] == 2
    assert len(obs["unquantified_examples"]) == 2

    # has_number / has_figref の分布確認
    any_number = any(h["has_number"] for h in obs["hype_sentences"])
    any_figref = any(h["has_figref"] for h in obs["hype_sentences"])
    assert any_number
    assert any_figref

    # score = 10 - 2 = 8
    assert r["score"] == 8.0

    joined = "\n".join(r["comments"])
    assert "定量化されていない" in joined


# ------------------------------------------------------------------
# Case 4: empty input
# ------------------------------------------------------------------
def test_empty_input():
    r = paper_writing_claim_quantification("")
    obs = r["observations"]
    assert obs["total_sentences"] == 0
    assert obs["hype_sentences"] == []
    assert obs["unquantified_count"] == 0
    assert obs["unquantified_examples"] == []
    # score は 10 (flagged 数 0)
    assert r["score"] == 10.0

    assert len(r["comments"]) >= 2
    joined = "\n".join(r["comments"])
    assert "文検出ゼロ" in joined or "入力を確認" in joined


def test_none_input_no_crash():
    r = paper_writing_claim_quantification(None)  # type: ignore[arg-type]
    assert r["observations"]["total_sentences"] == 0
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Case 5: \cite counts as quantification
# ------------------------------------------------------------------
def test_cite_counts_as_quantified():
    text = (
        r"Our method is significantly better than prior work \cite{smith2020}. "
        r"The approach is substantially faster [12]. "
        r"Results outperform recent baselines \cite{doe2023,lee2024}."
    )
    r = paper_writing_claim_quantification(text)

    obs = r["observations"]
    assert obs["total_sentences"] == 3
    assert len(obs["hype_sentences"]) == 3
    # 全て cite あり
    for h in obs["hype_sentences"]:
        assert h["has_cite"] is True
    assert obs["unquantified_count"] == 0
    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    assert "防衛済み" in joined


# ------------------------------------------------------------------
# Extra: hype_sentences entry shape
# ------------------------------------------------------------------
def test_hype_sentence_entry_shape():
    text = "The method is significantly better."
    r = paper_writing_claim_quantification(text)
    obs = r["observations"]
    assert len(obs["hype_sentences"]) == 1
    h = obs["hype_sentences"][0]
    # required keys
    for key in ("pos", "sentence", "hype_word", "has_number", "has_cite", "has_figref"):
        assert key in h
    assert h["pos"] == 0
    # hype_word は lowercase 'significantly' もしくは 'better' のいずれか最初
    assert h["hype_word"].lower() in {"significantly", "better"}


# ------------------------------------------------------------------
# hint / source fixed content
# ------------------------------------------------------------------
def test_hint_and_source_content():
    r = paper_writing_claim_quantification("test")
    assert "hype word list は粗い" in r["hint"]
    assert "手判断" in r["hint"]
    assert "NG #7" in r["source"]
    assert "Wallwork" in r["source"]
    assert "reviewer-2" in r["source"]
