"""Regression tests for presentation-module bug fixes H1-H7.

H4 and H7 are the two CRITICAL bugs (100% false-negative on default
templates, and silent drop of table/SmartArt/grouped-shape text). The
remaining tests cover the less-severe but still-user-visible regressions.
"""
from __future__ import annotations

import pathlib

import pytest


# ---------------------------------------------------------------------------
# H1 — check_time_13_rule no longer detects every underscore filename as an
# "equation".
# ---------------------------------------------------------------------------
def test_h1_filename_underscore_not_counted_as_equation():
    from mcp_server_document.presentation.tools import (
        presentation_check_time_13_rule,
    )
    # Use ASCII-heavy scripts so the density is dominated by underscore
    # tokens; if the old regex were still in effect, filenames like
    # `result_v2.pptx` and `file_name.csv` would inflate the specialist
    # density to a non-zero value.
    benign_block = (
        "we ran file_name.csv through result_v2.pptx and stored the "
        "outputs in slide_1 for later review " * 4
    )
    script = benign_block * 3
    r = presentation_check_time_13_rule(script)
    # These are filenames, not equations; the per-block densities should
    # be essentially zero (no kana, no units, no $...$ / A_i tokens).
    assert all(d == 0 for d in r["block_specialist_densities"]), r


def test_h1_real_subscript_and_latex_still_detected():
    from mcp_server_document.presentation.tools import (
        presentation_check_time_13_rule,
    )
    # Last block mixes a real subscript ``A_i`` and a LaTeX equation.
    first = "導入のはなし。" * 10
    mid = "手法のはなし。" * 10
    last = "最終結果は $x = y$ で、A_i は成立する。" * 10
    script = first + mid + last
    r = presentation_check_time_13_rule(script)
    densities = r["block_specialist_densities"]
    assert densities[2] > densities[0], densities


# ---------------------------------------------------------------------------
# H2 — count_slides ignores commented-out \frame lines.
# ---------------------------------------------------------------------------
def test_h2_beamer_commented_frame_not_counted(tmp_path: pathlib.Path):
    from mcp_server_document.presentation.tools import (
        presentation_count_slides,
    )
    tex = tmp_path / "deck.tex"
    tex.write_text(
        r"""\documentclass{beamer}
\begin{document}
\begin{frame}{Title}Real slide.\end{frame}
% \frame{this is an old commented-out slide}
% \begin{frame}{Also commented}\end{frame}
\begin{frame}{Second}Another real slide.\end{frame}
\end{document}
""",
        encoding="utf-8",
    )
    r = presentation_count_slides(str(tex))
    assert r["frame_environments"] == 2, r
    assert r["short_frame_calls"] == 0, r
    assert r["total_slides"] == 2, r


# ---------------------------------------------------------------------------
# H3 — _slide_title picks title placeholder regardless of shape order.
# ---------------------------------------------------------------------------
def test_h3_title_placeholder_wins_over_first_shape(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Inches
    from mcp_server_document.presentation.tools import _slide_title

    prs = Presentation()
    # Layout 1 = "Title and Content" — has a body + title placeholder.
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    # Fill body first (NOT title) to exercise the shape-order fallback
    # vs placeholder-priority resolution.
    for ph in slide.placeholders:
        if ph.placeholder_format.idx == 0:
            ph.text = "THE REAL TITLE"
        else:
            ph.text = "body bullet that would fool shape-order code"

    out = tmp_path / "t.pptx"
    prs.save(str(out))

    prs2 = Presentation(str(out))
    slide2 = prs2.slides[0]
    assert _slide_title(slide2) == "THE REAL TITLE"


# ---------------------------------------------------------------------------
# H4 — check_pptx_font_size no longer returns 0 violations on default
# templates whose runs inherit size from master / layout. This is the
# most critical fix.
# ---------------------------------------------------------------------------
def test_h4_font_size_resolves_via_inheritance(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.tools import (
        presentation_check_pptx_font_size,
    )
    prs = Presentation()
    # Layout 1 = "Title and Content". Default body size in the built-in
    # python-pptx master is 18pt — BELOW min_body_pt=20, so we expect
    # the fixed tool to flag at least one violation.
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    for ph in slide.placeholders:
        if ph.placeholder_format.idx == 0:
            ph.text = "Title here"
        else:
            ph.text = "Body bullet that will inherit its size from master"
    out = tmp_path / "inherit.pptx"
    prs.save(str(out))

    r = presentation_check_pptx_font_size(str(out),
                                           min_body_pt=40,
                                           min_title_pt=100)
    # With aggressive thresholds, at least one violation must be found
    # — the OLD code would return zero because every run.font.size is
    # None. The new code resolves via layout/master inheritance.
    assert r["total_violations"] >= 1, r
    # And most runs should be resolvable, not "unresolved".
    assert r["unresolved_runs"] == 0 or r["unresolved_runs"] < r["total_violations"] + 5, r


def test_h4_font_size_respects_explicit_run_size(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from mcp_server_document.presentation.tools import (
        presentation_check_pptx_font_size,
    )
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[5])  # Title Only
    tb = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(5), Inches(1))
    tf = tb.text_frame
    p = tf.paragraphs[0]
    r0 = p.add_run()
    r0.text = "tiny"
    r0.font.size = Pt(8)

    out = tmp_path / "explicit.pptx"
    prs.save(str(out))

    r = presentation_check_pptx_font_size(str(out), min_body_pt=20)
    sizes = [v["size_pt"] for v in r["violations"]]
    assert 8 in sizes, r


def test_h4_font_size_reports_unresolved_count(tmp_path):
    """The output dict must contain `unresolved_runs` (new key)."""
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.tools import (
        presentation_check_pptx_font_size,
    )
    prs = Presentation()
    prs.slides.add_slide(prs.slide_layouts[6])  # Blank
    out = tmp_path / "blank.pptx"
    prs.save(str(out))
    r = presentation_check_pptx_font_size(str(out))
    assert "unresolved_runs" in r


# ---------------------------------------------------------------------------
# H5 — color_count theme-color tuple is pretty-printed as ``theme-<idx>``.
# ---------------------------------------------------------------------------
def test_h5_theme_color_formatting(tmp_path):
    pytest.importorskip("pptx")
    from mcp_server_document.presentation import tools as pt_mod
    # Unit-level: exercise the ``_fmt_color`` helper via the module.
    # Since ``_fmt_color`` is a closure inside the check function, we
    # smoke-test the observable behavior by constructing a tuple and
    # passing through ``_rgb_of`` wiring. A simpler end-to-end check:
    # hand-build a palette set and make sure ``violating_slides`` uses
    # the new formatter. We rely on the helper being reachable via the
    # public function only when include_theme=True yields a theme tuple.
    # (python-pptx default template uses RGB fills, so we assert at the
    # unit level via string shape.)
    tpl = ("theme", 5)
    # Simulate formatter behavior — the production code uses the same
    # rules via _fmt_color. We validate the public surface by exercising
    # the hex path instead (theme colors depend on builds).
    rgb = (255, 128, 0)
    # The public tool never returns the helper, but we can at least
    # guarantee the ugly ``str(tuple)`` representation never appears
    # in a palette_sample. This is a structural check via a generated
    # deck.
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    for i in range(6):
        tb = slide.shapes.add_textbox(Inches(1), Inches(0.5 + 0.5 * i),
                                       Inches(5), Inches(0.4))
        run = tb.text_frame.paragraphs[0].add_run()
        run.text = f"line {i}"
        run.font.size = Pt(18)
        run.font.color.rgb = RGBColor(10 + i * 20, 50 + i * 10, 100 + i)
    out = tmp_path / "palette.pptx"
    prs.save(str(out))
    from mcp_server_document.presentation.tools import (
        presentation_check_color_count_per_slide,
    )
    r = presentation_check_color_count_per_slide(str(out), max_colors=3)
    assert r["violating_count"] >= 1
    for v in r["violating_slides"]:
        for s in v["palette_sample"]:
            # No ugly Python tuple repr should leak.
            assert not s.startswith("("), s
            # Either hex or "theme-N"
            assert s.startswith("#") or s.startswith("theme-"), s


# ---------------------------------------------------------------------------
# H6 — bullet_count excludes title and chrome placeholders.
# ---------------------------------------------------------------------------
def test_h6_bullet_count_excludes_title(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.tools import (
        presentation_check_bullet_count_per_slide,
    )
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[1])  # Title + Content
    for ph in slide.placeholders:
        if ph.placeholder_format.idx == 0:
            ph.text = "Two-line\nTitle Here"
        else:
            # 3 real bullets
            tf = ph.text_frame
            tf.text = "bullet one"
            for j in range(2):
                p = tf.add_paragraph()
                p.text = f"bullet {j+2}"

    out = tmp_path / "bullets.pptx"
    prs.save(str(out))

    r = presentation_check_bullet_count_per_slide(str(out), max_bullets=4)
    # 3 body bullets < 4 — NO violation. If title (2 lines) were counted
    # the total would be 5 > 4 and we would incorrectly flag the slide.
    assert r["over_bullet_limit_count"] == 0, r


# ---------------------------------------------------------------------------
# H7 — extract_pptx_text walks into groups, tables, and (best-effort)
# SmartArt.
# ---------------------------------------------------------------------------
def test_h7_extract_text_from_grouped_shape(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from mcp_server_document.presentation.tools import (
        presentation_extract_pptx_text,
    )
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[5])  # Title Only
    shapes = slide.shapes

    # Build two textboxes that will be grouped.
    tb1 = shapes.add_textbox(Inches(1), Inches(1), Inches(3), Inches(0.5))
    tb1.text_frame.paragraphs[0].add_run().text = "GROUPED_ONE"
    tb2 = shapes.add_textbox(Inches(1), Inches(2), Inches(3), Inches(0.5))
    tb2.text_frame.paragraphs[0].add_run().text = "GROUPED_TWO"

    # ``ShapeTree.add_group_shape`` requires python-pptx >= 0.6.22; fall
    # back to the low-level ``SlideShapes`` grouping if available.
    grouped = False
    try:
        shapes.add_group_shape([tb1, tb2])
        grouped = True
    except (AttributeError, TypeError):
        # Older python-pptx — simulate by moving into a group spTree.
        # We still verify extraction of the ungrouped version.
        grouped = False

    out = tmp_path / "grouped.pptx"
    prs.save(str(out))
    r = presentation_extract_pptx_text(str(out))
    joined_all = "\n".join(s["text_preview"] for s in r["slides"])
    assert "GROUPED_ONE" in joined_all, r
    assert "GROUPED_TWO" in joined_all, r


def test_h7_extract_text_from_table(tmp_path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Inches
    from mcp_server_document.presentation.tools import (
        presentation_extract_pptx_text,
    )
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[5])  # Title Only
    tbl_shape = slide.shapes.add_table(2, 2, Inches(1), Inches(1),
                                        Inches(5), Inches(2))
    tbl = tbl_shape.table
    tbl.cell(0, 0).text = "HEADER_CELL"
    tbl.cell(0, 1).text = "HEADER_CELL_TWO"
    tbl.cell(1, 0).text = "DATA_CELL"
    tbl.cell(1, 1).text = "DATA_CELL_TWO"

    out = tmp_path / "table.pptx"
    prs.save(str(out))
    r = presentation_extract_pptx_text(str(out))
    joined = "\n".join(s["text_preview"] for s in r["slides"])
    # The old implementation silently dropped all table text.
    assert "HEADER_CELL" in joined, r
    assert "DATA_CELL" in joined, r


def test_h7_extract_text_plain_textbox_still_works(tmp_path):
    """Sanity: ordinary textboxes still extracted after the refactor."""
    pytest.importorskip("pptx")
    from pptx import Presentation
    from pptx.util import Inches
    from mcp_server_document.presentation.tools import (
        presentation_extract_pptx_text,
    )
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    tb = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(5), Inches(1))
    tb.text_frame.paragraphs[0].add_run().text = "PLAIN_TEXT"
    out = tmp_path / "plain.pptx"
    prs.save(str(out))
    r = presentation_extract_pptx_text(str(out))
    assert "PLAIN_TEXT" in r["slides"][0]["text_preview"]
