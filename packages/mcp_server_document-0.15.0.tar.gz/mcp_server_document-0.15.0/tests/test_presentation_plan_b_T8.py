"""Tests for Plan B T8: presentation_font_consistency.

4 cases:
1. single_font — 1 種のみ (含 default) — score 高
2. two_fonts_ok — 2 種 (日本語用 + 英数字用 相当) — score 10
3. many_fonts_warn — 5 種以上 — score 0, 警告コメント
4. mixed_with_rare — 2 dominant + 2 rare — rare_fonts に検出
"""
from __future__ import annotations

import pathlib

import pytest


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _add_text_slide(prs, lines_with_fonts):
    """Add a slide whose body text frame has one paragraph per entry.

    Parameters
    ----------
    lines_with_fonts : list[tuple[str, str | None]]
        (text, font_name) pairs.  font_name=None を渡すと run.font.name
        は未設定のまま (= ツール側では "(default)" として集計される)。
    """
    # 5 = "Title and Content" layout in the built-in default master;
    # but not all templates have index 5.  Use layout 1 (Title + Content)
    # which is the same one used by the T5 tests.
    slide = prs.slides.add_slide(prs.slide_layouts[1])

    # Find a body placeholder (idx != 0) — fall back to adding a textbox
    body = None
    for ph in slide.placeholders:
        try:
            if ph.placeholder_format.idx != 0 and ph.has_text_frame:
                body = ph
                break
        except Exception:
            continue
    if body is None:
        # Add a textbox as fallback
        from pptx.util import Inches
        body = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(6), Inches(4))

    tf = body.text_frame
    # Clear existing content — set first paragraph, then add more
    first = True
    for text, font_name in lines_with_fonts:
        if first:
            p = tf.paragraphs[0]
            # Reset any existing runs by overwriting the first run text
            if p.runs:
                run = p.runs[0]
                run.text = text
            else:
                run = p.add_run()
                run.text = text
            if font_name is not None:
                run.font.name = font_name
            first = False
        else:
            p = tf.add_paragraph()
            run = p.add_run()
            run.text = text
            if font_name is not None:
                run.font.name = font_name
    return slide


# ------------------------------------------------------------------
# Case 1: single font
# ------------------------------------------------------------------
def test_single_font(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T8 import (
        presentation_font_consistency,
    )

    prs = Presentation()
    # 3 slides, all runs use one font family
    for i in range(3):
        _add_text_slide(prs, [
            (f"line {i}-1", "Meiryo"),
            (f"line {i}-2", "Meiryo"),
            (f"line {i}-3", "Meiryo"),
        ])

    out = tmp_path / "single_font.pptx"
    prs.save(str(out))

    r = presentation_font_consistency(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 3
    assert obs["distinct_font_count"] == 1
    assert "Meiryo" in obs["font_family_counts"]
    assert obs["font_family_counts"]["Meiryo"] >= 9
    assert "Meiryo" in obs["dominant_fonts"]
    # 1 種 → rare にも該当するが count >= 3 なので rare_fonts は空
    assert obs["rare_fonts"] == []
    assert r["score"] == 10.0
    assert r["score_max"] == 10

    joined = "\n".join(r["comments"])
    assert "font 統一済み" in joined


# ------------------------------------------------------------------
# Case 2: two fonts (日本語 + 英数字 相当) — 理想
# ------------------------------------------------------------------
def test_two_fonts_ok(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T8 import (
        presentation_font_consistency,
    )

    prs = Presentation()
    for i in range(3):
        _add_text_slide(prs, [
            (f"日本語 {i}-1", "Meiryo"),
            (f"english {i}-2", "Arial"),
            (f"日本語 {i}-3", "Meiryo"),
            (f"english {i}-4", "Arial"),
        ])

    out = tmp_path / "two_fonts.pptx"
    prs.save(str(out))

    r = presentation_font_consistency(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["distinct_font_count"] == 2
    assert set(obs["dominant_fonts"]) == {"Meiryo", "Arial"}
    # Both fonts have >= 3 occurrences → rare is empty
    assert obs["rare_fonts"] == []
    assert r["score"] == 10.0

    joined = "\n".join(r["comments"])
    assert "font 統一済み" in joined


# ------------------------------------------------------------------
# Case 3: many fonts → warn
# ------------------------------------------------------------------
def test_many_fonts_warn(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T8 import (
        presentation_font_consistency,
    )

    prs = Presentation()
    fonts = ["Meiryo", "Arial", "Times New Roman", "Calibri", "Verdana"]
    # Put each font >= 3 times so nothing is "rare" — pure font-count signal
    for _rep in range(3):
        _add_text_slide(prs, [(f"text-{f}", f) for f in fonts])

    out = tmp_path / "many_fonts.pptx"
    prs.save(str(out))

    r = presentation_font_consistency(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["distinct_font_count"] == 5
    assert len(obs["dominant_fonts"]) == 3
    assert obs["rare_fonts"] == []
    # distinct >= 5 → base score 0
    assert r["score"] == 0.0

    joined = "\n".join(r["comments"])
    assert "混在" in joined
    assert "宮野 S11" in joined


# ------------------------------------------------------------------
# Case 4: mixed — 2 dominant + 2 rare (count 1-2) — rare detection
# ------------------------------------------------------------------
def test_mixed_with_rare(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T8 import (
        presentation_font_consistency,
    )

    prs = Presentation()
    # Slide 1: 4 Meiryo + 4 Arial (dominant)
    _add_text_slide(prs, [
        ("a1", "Meiryo"), ("a2", "Meiryo"), ("a3", "Meiryo"), ("a4", "Meiryo"),
        ("b1", "Arial"), ("b2", "Arial"), ("b3", "Arial"), ("b4", "Arial"),
    ])
    # Slide 2: 2 rare fonts sneaking in (count 1 and 2)
    _add_text_slide(prs, [
        ("c1", "Comic Sans MS"),  # count 1 → rare
        ("d1", "Impact"),  # count 2 → rare
        ("d2", "Impact"),
        ("more Meiryo", "Meiryo"),
        ("more Arial", "Arial"),
    ])

    out = tmp_path / "mixed.pptx"
    prs.save(str(out))

    r = presentation_font_consistency(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    # 4 distinct: Meiryo, Arial, Comic Sans MS, Impact
    assert obs["distinct_font_count"] == 4
    assert "Meiryo" in obs["dominant_fonts"]
    assert "Arial" in obs["dominant_fonts"]
    # Rare must include Comic Sans MS and Impact (counts 1 and 2)
    assert "Comic Sans MS" in obs["rare_fonts"]
    assert "Impact" in obs["rare_fonts"]
    # rare is NOT a subset of dominant (distinct divergence) → no -1 penalty
    assert r["score"] == 4.0

    joined = "\n".join(r["comments"])
    # Warn about distinct_font_count >= 4
    assert "混在" in joined
    # Warn about rare (paste-from-text)
    assert "コピペ起源" in joined or "paste-from-text" in joined


# ------------------------------------------------------------------
# Structural / hint-source contract
# ------------------------------------------------------------------
def test_hint_and_source_content(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T8 import (
        presentation_font_consistency,
    )

    prs = Presentation()
    _add_text_slide(prs, [("x", "Meiryo")])
    out = tmp_path / "tiny.pptx"
    prs.save(str(out))

    r = presentation_font_consistency(str(out))
    assert r["score_max"] == 10
    assert "hint" in r
    assert "default" in r["hint"]
    assert "source" in r
    assert "S11" in r["source"]
    assert "宮野" in r["source"]


# ------------------------------------------------------------------
# Error path: missing file
# ------------------------------------------------------------------
def test_missing_file_returns_error(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T8 import (
        presentation_font_consistency,
    )

    ghost = tmp_path / "does_not_exist.pptx"
    r = presentation_font_consistency(str(ghost))
    assert "error" in r
    assert "not found" in r["error"]
