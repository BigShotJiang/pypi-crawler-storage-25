"""Tests for Plan B T22: grant_writing_check_uline_overflow_risk."""
from mcp_server_document.grant_writing.plan_b_T22 import (
    grant_writing_check_uline_overflow_risk,
)


def test_short_uline_no_risk(tmp_path):
    """短い \\uline は risky 扱いしない。"""
    tex = tmp_path / "short.tex"
    tex.write_text(r"本研究は \uline{重要} である。", encoding="utf-8")
    r = grant_writing_check_uline_overflow_risk(str(tex))
    assert r["observations"]["total_underlines"] == 1
    assert r["observations"]["risky_count"] == 0
    assert r["score"] == 10.0


def test_long_uline_flagged(tmp_path):
    """30 字を超える \\uline は risky として flag。"""
    long_content = "本研究は国産 OSS 電磁界ソルバを日本発の文法で国際標準層に打ち立てる学術基盤である"
    tex = tmp_path / "long.tex"
    tex.write_text(rf"冒頭: \uline{{{long_content}}} である。", encoding="utf-8")
    r = grant_writing_check_uline_overflow_risk(str(tex))
    assert r["observations"]["risky_count"] >= 1
    assert r["score"] < 10.0
    joined = "\n".join(r["comments"])
    # 対策が示される
    assert "jumoline" in joined or "分割" in joined


def test_multiline_uline_flagged(tmp_path):
    """\\uline{...} 内に改行があれば risky (段落境界破綻リスク)。"""
    tex = tmp_path / "multiline.tex"
    # 実改行を含む内容 (raw string ではなく通常文字列で \n を newline として)
    tex.write_text(
        "本文 \\uline{前半\n後半部分も下線を引きたい} である。", encoding="utf-8"
    )
    r = grant_writing_check_uline_overflow_risk(str(tex))
    risky = r["observations"]["risky_findings"]
    assert len(risky) >= 1
    assert risky[0]["line_count"] >= 2


def test_nested_braces_in_uline(tmp_path):
    """ネスト括弧 \\uline{\\textbf{foo} bar} を正しく parse できる。"""
    tex = tmp_path / "nested.tex"
    tex.write_text(r"\uline{\textbf{重要}部分}について", encoding="utf-8")
    r = grant_writing_check_uline_overflow_risk(str(tex))
    # 閉じ括弧の対応が正しく取れていれば、content は "\\textbf{重要}部分"
    assert r["observations"]["total_underlines"] == 1


def test_commented_uline_ignored(tmp_path):
    """% コメント内の \\uline は対象外。"""
    tex = tmp_path / "commented.tex"
    tex.write_text(
        "本文。\n% これはコメント \\uline{無視されるべき非常に長い下線テキスト}\n続き。",
        encoding="utf-8",
    )
    r = grant_writing_check_uline_overflow_risk(str(tex))
    assert r["observations"]["total_underlines"] == 0


def test_multiple_macros_detected(tmp_path):
    """\\uline 以外の \\uwave / \\uuline / \\sout も対象に含まれる。"""
    long = "とても長い内容が連続しており行送りからはみ出す可能性が高い下線指定である"
    tex = tmp_path / "multi.tex"
    tex.write_text(
        rf"\uwave{{{long}}} \uuline{{{long}}} \sout{{{long}}}", encoding="utf-8"
    )
    r = grant_writing_check_uline_overflow_risk(str(tex))
    macros_found = {f["macro"] for f in r["observations"]["risky_findings"]}
    assert "uwave" in macros_found
    assert "uuline" in macros_found
    assert "sout" in macros_found


def test_missing_file():
    """存在しないファイル → error を observations に。"""
    r = grant_writing_check_uline_overflow_risk("/nonexistent/path.tex")
    assert "error" in r["observations"]
    assert r["score"] == 0.0


def test_custom_max_chars(tmp_path):
    """max_chars 引数で閾値を緩められる。"""
    content = "20 字ちょうどの下線内容を記述する"  # 17 字
    tex = tmp_path / "custom.tex"
    tex.write_text(rf"\uline{{{content}}}", encoding="utf-8")

    # 閾値 10 では risky
    r1 = grant_writing_check_uline_overflow_risk(str(tex), max_chars=10)
    assert r1["observations"]["risky_count"] == 1

    # 閾値 30 では安全
    r2 = grant_writing_check_uline_overflow_risk(str(tex), max_chars=30)
    assert r2["observations"]["risky_count"] == 0


def test_hint_and_source_content(tmp_path):
    """hint / source が運用知識を含む。"""
    tex = tmp_path / "h.tex"
    tex.write_text(r"\uline{短い}", encoding="utf-8")
    r = grant_writing_check_uline_overflow_risk(str(tex))
    assert "jumoline" in r["hint"] or "uline--" in r["hint"]
    assert "ulem" in r["source"]
