"""Tests for Plan B T11: presentation_slide_density_balance.

4 cases:
1. balanced_deck — 8 slides with similar char counts, Gini low, score high
2. imbalanced_deck — 1 huge slide + many thin slides, top_3_ratio > 0.5, score low
3. uniform — all slides exactly equal, Gini ~ 0, score = 10
4. empty — 0 slides, no crash, score = 10

Assertions focus on observations keys and comments substrings; numeric
score values are only checked as inequalities, not exact.
"""
from __future__ import annotations

import pathlib

import pytest


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _make_slide(prs, layout_idx: int, title: str, body: str | None = None):
    """Add a slide to *prs* using the layout at *layout_idx* and fill the
    title / body placeholders when present."""
    slide = prs.slides.add_slide(prs.slide_layouts[layout_idx])
    for ph in slide.placeholders:
        try:
            if ph.placeholder_format.idx == 0:
                ph.text = title
            elif body is not None:
                ph.text = body
        except Exception:
            continue
    return slide


# ------------------------------------------------------------------
# Case 1: balanced_deck — 8 slides with similar char counts
# ------------------------------------------------------------------
def test_balanced_deck(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T11 import (
        presentation_slide_density_balance,
    )

    prs = Presentation()
    # 8 slides each with ~30 chars of body
    body = "bullet point here with some content"  # ~35 chars
    for i in range(8):
        _make_slide(prs, 1, f"Title {i + 1}", body)

    out = tmp_path / "balanced.pptx"
    prs.save(str(out))

    r = presentation_slide_density_balance(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 8
    assert obs["total_text_chars"] > 0
    assert len(obs["per_slide_chars"]) == 8
    # Balanced → Gini should be low
    assert obs["gini_coefficient"] <= 0.2, obs
    assert obs["top_3_ratio"] <= 0.5
    assert r["score"] >= 7, r
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Case 2: imbalanced_deck — 1 huge slide + many thin slides
# ------------------------------------------------------------------
def test_imbalanced_deck(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T11 import (
        presentation_slide_density_balance,
    )

    prs = Presentation()
    # 2 huge slides with ~500 chars of body each, 6 thin slides with ~5 chars
    big_body = "x" * 500
    small_body = "a"
    _make_slide(prs, 1, "Big A", big_body)
    _make_slide(prs, 1, "Big B", big_body)
    for i in range(6):
        _make_slide(prs, 1, f"Tiny {i + 1}", small_body)

    out = tmp_path / "imbalanced.pptx"
    prs.save(str(out))

    r = presentation_slide_density_balance(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 8
    # Top-3 concentration very high
    assert obs["top_3_ratio"] > 0.5, obs
    # Gini should be sizeable
    assert obs["gini_coefficient"] > 0.3, obs
    # Score pushed down by penalty
    assert r["score"] <= 5, r

    joined = "\n".join(r["comments"])
    assert "集中" in joined or "密度偏り" in joined


# ------------------------------------------------------------------
# Case 3: uniform — all slides exactly equal text count
# ------------------------------------------------------------------
def test_uniform_deck(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T11 import (
        presentation_slide_density_balance,
    )

    prs = Presentation()
    # 5 slides, all with exactly the same title + body
    for i in range(5):
        _make_slide(prs, 1, "Same", "identical body text here")

    out = tmp_path / "uniform.pptx"
    prs.save(str(out))

    r = presentation_slide_density_balance(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 5
    # All equal → Gini exactly 0 (within rounding)
    assert obs["gini_coefficient"] == 0.0, obs
    # top-3 of 5 equal bins = 3/5 = 0.6 so penalty may fire, but Gini is 0
    # so base score is 10 - penalty at most = 8
    assert r["score"] >= 7.0, r

    joined = "\n".join(r["comments"])
    # Either balance-good comment or the top-3 penalty fired (but Gini 0)
    assert (
        "バランス良好" in joined
        or "均等配分" in joined
        or "集中" in joined
    )


# ------------------------------------------------------------------
# Case 4: empty deck
# ------------------------------------------------------------------
def test_empty_deck_no_crash(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T11 import (
        presentation_slide_density_balance,
    )

    prs = Presentation()
    out = tmp_path / "empty.pptx"
    prs.save(str(out))

    r = presentation_slide_density_balance(str(out))
    assert "error" not in r, r
    obs = r["observations"]
    assert obs["total_slides"] == 0
    assert obs["total_text_chars"] == 0
    assert obs["per_slide_chars"] == []
    assert obs["gini_coefficient"] == 0.0
    assert obs["top_3_ratio"] == 0.0
    assert r["score"] == 10.0
    assert len(r["comments"]) >= 2


# ------------------------------------------------------------------
# Structural / hint-source contract
# ------------------------------------------------------------------
def test_hint_and_source_content(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from pptx import Presentation
    from mcp_server_document.presentation.plan_b_T11 import (
        presentation_slide_density_balance,
    )

    prs = Presentation()
    _make_slide(prs, 1, "x", "y")
    out = tmp_path / "tiny.pptx"
    prs.save(str(out))

    r = presentation_slide_density_balance(str(out))
    assert r["score_max"] == 10
    assert "hint" in r and "Gini" in r["hint"]
    assert "source" in r
    assert "anti-pattern" in r["source"] or "横徹流" in r["source"]


# ------------------------------------------------------------------
# Error path: missing file
# ------------------------------------------------------------------
def test_missing_file_returns_error(tmp_path: pathlib.Path):
    pytest.importorskip("pptx")
    from mcp_server_document.presentation.plan_b_T11 import (
        presentation_slide_density_balance,
    )

    ghost = tmp_path / "does_not_exist.pptx"
    r = presentation_slide_density_balance(str(ghost))
    assert "error" in r
    assert "not found" in r["error"]
