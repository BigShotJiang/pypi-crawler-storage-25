"""Tests for Plan B T11: grant_writing_continuity_check."""

from __future__ import annotations

import pytest

from mcp_server_document.grant_writing.plan_b_T11 import (
    grant_writing_continuity_check,
)


def test_all_positive_high_score():
    """All positive: uptrajectory + vision + continuity words → score >= 8."""
    text = (
        "これまで当研究室では PCB 領域の電磁界ソルバを確立してきており、"
        "さらに本研究では AI 自律設計環境への発展を目指す。"
        "本研究が拓く景色は、Motor 領域の国産 CAE × AI 熟成曲線を PCB 領域で再現する未来像である。"
        "採択後は継続的な共同研究へと展開し、国際標準層へ波及させる。"
    )
    result = grant_writing_continuity_check(text)

    assert result["score"] >= 8
    assert result["score_max"] == 10
    obs = result["observations"]
    assert len(obs["uptrajectory_phrases"]) >= 1
    assert obs["continuity_word_count"] >= 3
    assert len(obs["vision_sentences"]) >= 1
    assert len(obs["termination_signals"]) == 0
    # 肯定コメントが混じっているか
    joined = " ".join(result["comments"])
    assert "上積み軌道" in joined or "良好" in joined


def test_no_continuity_low_score():
    """Neutral 500-char text with no uptrajectory, no vision → low score, callouts."""
    text = (
        "本報告では基板設計の一般的な手順について述べる。"
        "基板設計は回路図の作成から始まり、部品配置、配線、"
        "熱設計、EMI 対策、製造性検討へと進む。"
        "特に近年は高周波動作が増え、シグナルインテグリティの"
        "確保が重要となっている。回路シミュレータを用いて"
        "動作を確認し、問題があれば配線を見直す。"
        "部品メーカーのモデルを活用し、想定される負荷条件で"
        "動作波形を確認することが一般的である。"
        "熱解析は CFD ツールを利用し、ジャンクション温度を"
        "仕様値以下に抑える。これらの手順は設計規模にかかわらず"
        "共通して適用されるものであり、設計者の経験に依存する"
        "部分も少なくない。技術者教育の観点でも、"
        "こうした標準的プロセスを体系化することに意味がある。"
    )
    result = grant_writing_continuity_check(text)

    assert result["score"] < 8  # uptrajectory/vision 無ければ高くならない
    obs = result["observations"]
    assert len(obs["uptrajectory_phrases"]) == 0
    assert len(obs["vision_sentences"]) == 0
    assert len(obs["termination_signals"]) == 0

    joined = " ".join(result["comments"])
    assert "上積み軌道" in joined  # missing uptrajectory 告知
    assert "Vision" in joined  # missing vision 告知


def test_termination_signal_lowers_score():
    """termination signal present → score drops, comments warn."""
    text = (
        "これまで当研究室では電磁界ソルバを確立してきており、"
        "さらに本研究では拡張を図る。"
        "本研究をもって閉じる計画である。"
    )
    # baseline なし版と比較したいが、固定値でも assert できる
    result = grant_writing_continuity_check(text)

    obs = result["observations"]
    assert len(obs["termination_signals"]) >= 1

    # termination penalty で score は 8 未満 (5 + 3 uptraj + 0 or 2 cont + 0 vis - 4 term = 4 or 6)
    assert result["score"] <= 6

    joined = " ".join(result["comments"])
    assert "頂点終了" in joined or "完結" in joined


def test_only_vision_no_uptrajectory_partial():
    """Only vision, no uptrajectory → partial score with targeted comments."""
    text = (
        "本研究が拓く景色は、国産 OSS による電磁界解析基盤の確立である。"
        "未来像として学術層と産業層の接続を見据える。"
        "本報告では設計手法を述べる。"
    )
    result = grant_writing_continuity_check(text)

    obs = result["observations"]
    assert len(obs["vision_sentences"]) >= 1
    assert len(obs["uptrajectory_phrases"]) == 0
    assert len(obs["termination_signals"]) == 0

    # baseline 5 + vision 2 = 7 (uptraj/cont が不足)
    assert 5 <= result["score"] <= 8

    joined = " ".join(result["comments"])
    # uptrajectory 不在の指摘
    assert "上積み軌道" in joined
    # vision はあるので vision 無しコメントは出ない
    assert "Vision 段落が無い" not in joined


def test_return_shape():
    """Return shape sanity check."""
    result = grant_writing_continuity_check("テスト文章である。")
    assert set(result.keys()) == {
        "score",
        "score_max",
        "comments",
        "observations",
        "hint",
        "source",
    }
    assert isinstance(result["score"], float)
    assert result["score_max"] == 10
    assert isinstance(result["comments"], list)
    assert all(isinstance(c, str) for c in result["comments"])
    assert 2 <= len(result["comments"]) <= 5
    assert isinstance(result["hint"], str)
    assert "skill.md" in result["source"]

    obs = result["observations"]
    assert "uptrajectory_phrases" in obs
    assert "continuity_word_count" in obs
    assert "continuity_word_breakdown" in obs
    assert "vision_sentences" in obs
    assert "termination_signals" in obs


def test_empty_input():
    """Empty / None input should not crash."""
    for inp in ("", None):
        result = grant_writing_continuity_check(inp)
        assert 0 <= result["score"] <= 10
        assert len(result["comments"]) >= 2


# ------------------------------------------------------------------
# 2026-04-23 hardening: uptrajectory が文跨ぎでも検出されること
# ------------------------------------------------------------------
def test_uptrajectory_across_period():
    """「これまで〜確立してきた。さらに〜」のような文跨ぎパターンを拾う。"""
    text = (
        "これまで当研究室では PCB 領域の電磁界ソルバを確立してきた。"
        "さらに本研究では AI 自律設計環境への発展を目指す。"
    )
    r = grant_writing_continuity_check(text)
    assert len(r["observations"]["uptrajectory_phrases"]) >= 1


def test_uptrajectory_across_multiple_sentences():
    """短い中間文を挟んでも、150 字以内なら拾う。"""
    text = (
        "これまで三菱電機で 14 年にわたり電磁界解析を担当してきた。"
        "多くの案件で実証も積んできた。"
        "さらに本研究では国産 OSS として再実装する。"
    )
    r = grant_writing_continuity_check(text)
    assert len(r["observations"]["uptrajectory_phrases"]) >= 1


def test_uptrajectory_too_far_apart_not_matched():
    """150 字を大きく超えて離れたペアは拾わない (ノイズ防止)。"""
    long_filler = "本研究の背景として様々な要素を考慮する必要がある。" * 20  # ~500 chars
    text = (
        "これまで多くの研究を確立してきた。" + long_filler +
        "さらに本研究では新しい方向へ進む。"
    )
    r = grant_writing_continuity_check(text)
    assert len(r["observations"]["uptrajectory_phrases"]) == 0
