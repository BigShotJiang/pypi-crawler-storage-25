"""Tests for Plan B T10 — grant_writing_tagline_identify."""

from __future__ import annotations

from mcp_server_document.grant_writing.plan_b_T10 import (
    grant_writing_tagline_identify,
)


def test_first_sentence_challenge_tagline():
    """第一文が challenge 型タグライン → score 10."""
    text = (
        "LLM が呼び出せる国産 OSS 電磁界ソルバを打ち立てる。"
        "本研究はその学術基盤である。"
    )
    result = grant_writing_tagline_identify(text)

    assert result["score"] == 10
    assert result["score_max"] == 10
    cands = result["observations"]["candidates"]
    assert len(cands) >= 1
    assert cands[0]["type"] == "challenge"
    assert cands[0]["sentence_idx"] == 0
    assert result["observations"]["earliest_sentence_idx"] == 0
    # 強度十分コメント
    assert any("強度十分" in c for c in result["comments"])
    # source
    assert "木下" in result["source"]


def test_only_purpose_third_sentence():
    """purpose 型が 3 文目のみ → score は 4〜7 の範囲, purpose 弱さを指摘."""
    text = (
        "電力変換デバイスの発熱問題は深刻である。"
        "冷却器の大型化が課題となっている。"
        "本研究は発熱源を物理モデルで低減する手法の開発を目的とする。"
    )
    result = grant_writing_tagline_identify(text)

    # 3文目 = sentence_idx == 2 → score 7
    assert 4 <= result["score"] <= 7
    cands = result["observations"]["candidates"]
    assert len(cands) == 1
    assert cands[0]["type"] == "purpose"
    assert cands[0]["sentence_idx"] == 2
    # purpose 型の弱さに言及
    assert any("目的とする" in c or "purpose" in c or "弱い" in c for c in result["comments"])


def test_no_tagline_in_first_500_chars():
    """冒頭 500 字にタグラインなし → score 0, タグライン設置要求."""
    text = (
        "近年、電磁界シミュレーションの需要が高まっている。"
        "産業界では設計サイクル短縮が求められている。"
        "一方、商用ソルバのライセンス費用は年々増大している。"
        "大学・中小企業では予算制約が深刻である。"
        "このような背景のもと、本稿では現状を整理した。"
    )
    result = grant_writing_tagline_identify(text)

    assert result["score"] == 0
    assert result["observations"]["tagline_count_in_scan"] == 0
    assert result["observations"]["earliest_sentence_idx"] is None
    assert result["observations"]["candidates"] == []
    # タグライン設置を要求するコメント
    assert any(
        ("目標規定文" in c) and ("無い" in c or "ない" in c) for c in result["comments"]
    )


def test_empty_text():
    """空文字 → クラッシュせず score 0, candidates == []."""
    result = grant_writing_tagline_identify("")

    assert result["score"] == 0
    assert result["score_max"] == 10
    assert result["observations"]["candidates"] == []
    assert result["observations"]["earliest_sentence_idx"] is None
    assert result["observations"]["tagline_count_in_scan"] == 0
    # 空でも hint / source は埋まる
    assert isinstance(result["hint"], str) and result["hint"]
    assert isinstance(result["source"], str) and result["source"]


def test_observations_shape():
    """observations の構造チェック (仕様準拠)."""
    text = "国産 OSS で国際標準の一角を打ち立てる。"
    result = grant_writing_tagline_identify(text)
    obs = result["observations"]
    assert "scan_chars_used" in obs
    assert "candidates" in obs
    assert "earliest_sentence_idx" in obs
    assert "tagline_count_in_scan" in obs
    assert obs["scan_chars_used"] == 500
    c = obs["candidates"][0]
    for key in ("sentence_idx", "char_pos", "len", "type", "text"):
        assert key in c
    # 末尾記号なし
    assert not c["text"].endswith("。")
