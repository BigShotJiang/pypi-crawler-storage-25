"""Tests for Plan B T4: paper_writing_limitation_statement_presence.

5 cases:
1. Discussion with mid-position substantial limitation (ideal → high score)
2. Discussion without any limitation (score = 0)
3. Discussion with end-only limitation (comment: end placement warning)
4. Discussion with short limitation (< 150 chars) (comment: too short)
5. No discussion section detected (score = 3, comment: missing Discussion)

Assertions focus on `comments` substrings and key `observations` booleans.
Do NOT over-assert exact scores.
"""
from mcp_server_document.paper_writing.plan_b_T4 import (
    paper_writing_limitation_statement_presence,
)


# ------------------------------------------------------------------
# Case 1: Discussion with mid-position substantial limitation
# ------------------------------------------------------------------
def test_discussion_mid_limitation_scores_high():
    tex = r"""
\section{Introduction}
Intro text.

\section{Method}
Method text.

\section{Results}
Results text.

\section{Discussion}
Our main finding is that the proposed method achieves higher accuracy than baselines across all three datasets. This is consistent with the theoretical bound derived in Section 3. The improvement is especially pronounced for high-frequency signals.

A second interpretation concerns generalization. The method's invariance to affine transformations likely explains robustness in setting B, although further study is needed to disentangle the two effects.

There are several limitations to the current study that warrant discussion. First, the evaluation dataset is restricted to synthetic signals, so real-world noise characteristics may differ. Second, the method assumes a known forward operator, which is not always available in clinical imaging. Third, computational cost scales linearly with grid size, limiting applicability to very large problems. These caveats inform the scope of our conclusions and motivate the future-work directions described next.

Building on these limitations, future work will target noisy real-world data and explore operator-learning extensions. We believe this bridges the gap toward deployment.

\section{Conclusion}
Concluding remarks here.
"""
    r = paper_writing_limitation_statement_presence(tex)

    # 構造
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert 2 <= len(r["comments"]) <= 5
    assert "skill.md" in r["source"]
    assert "Wallwork" in r["source"]

    obs = r["observations"]
    assert obs["discussion_found"] is True
    assert obs["discussion_char_range"] is not None
    assert len(obs["limitation_paragraphs"]) >= 1

    # middle + substantial
    assert obs["mid_limitation_present"] is True
    assert obs["has_substantial_limitation"] is True

    # score 高い (base 5 + mid 3 + substantial 2 = 10)
    assert r["score"] >= 8

    # positive comment
    joined = "\n".join(r["comments"])
    assert "中盤" in joined or "§O" in joined


# ------------------------------------------------------------------
# Case 2: Discussion without any limitation
# ------------------------------------------------------------------
def test_no_limitation_flagged():
    tex = r"""
\section{Introduction}
Intro.

\section{Discussion}
Our results show strong performance across all benchmarks.
The proposed method is efficient and accurate.
We conclude that the approach is broadly applicable to similar problems.

\section{Conclusion}
Done.
"""
    r = paper_writing_limitation_statement_presence(tex)

    obs = r["observations"]
    assert obs["discussion_found"] is True
    assert obs["limitation_paragraphs"] == []
    assert obs["mid_limitation_present"] is False
    assert obs["has_substantial_limitation"] is False

    assert r["score"] == 0.0

    joined = "\n".join(r["comments"])
    assert "limitation" in joined.lower() or "caveat" in joined.lower()
    assert "NG #4" in joined or "正直" in joined


# ------------------------------------------------------------------
# Case 3: Discussion with end-only limitation
# ------------------------------------------------------------------
def test_end_only_limitation_flagged():
    tex = r"""
\section{Introduction}
Intro.

\section{Discussion}
Our main finding is that method A produces lower error than method B in all cases. This is consistent with the theoretical prediction.

A secondary finding is improved stability under noise. The stability gain is 2x better on average compared to the baseline approach.

We additionally find that convergence is faster in the proposed scheme, suggesting better conditioning of the iteration matrix.

One key takeaway is that the method generalizes across noise regimes. This is crucial for practical deployment in industrial settings.

We interpret this as evidence for the hypothesized mechanism, and we expand on implications below.

Finally, several limitations should be noted. The dataset is synthetic, and the evaluation assumes bounded input noise.

\section{Conclusion}
Done.
"""
    r = paper_writing_limitation_statement_presence(tex)

    obs = r["observations"]
    assert obs["discussion_found"] is True
    assert len(obs["limitation_paragraphs"]) >= 1

    # 全て end に限定
    positions = [
        p["position_in_discussion"] for p in obs["limitation_paragraphs"]
    ]
    assert all(pos == "end" for pos in positions)
    assert obs["mid_limitation_present"] is False

    joined = "\n".join(r["comments"])
    assert "末尾" in joined or "中盤" in joined or "Wallwork" in joined


# ------------------------------------------------------------------
# Case 4: Discussion with short limitation (< 150 chars)
# ------------------------------------------------------------------
def test_short_limitation_flagged():
    tex = r"""
\section{Introduction}
Intro.

\section{Discussion}
Our main finding is that method A produces lower error than method B. The magnitude of improvement is stable across seeds. This supports the core claim.

One limitation exists.

We further observe that convergence is monotonic. This is consistent with theory.

\section{Conclusion}
Done.
"""
    r = paper_writing_limitation_statement_presence(tex)

    obs = r["observations"]
    assert obs["discussion_found"] is True
    assert len(obs["limitation_paragraphs"]) >= 1
    # 短い
    assert obs["has_substantial_limitation"] is False
    min_len = min(
        p["length_chars"] for p in obs["limitation_paragraphs"]
    )
    assert min_len < 150

    joined = "\n".join(r["comments"])
    assert "短い" in joined or "150" in joined or "具体的" in joined


# ------------------------------------------------------------------
# Case 5: No discussion section
# ------------------------------------------------------------------
def test_no_discussion_section():
    tex = r"""
\section{Introduction}
Intro text.

\section{Method}
Method details.

\section{Results}
Results.

\section{Conclusion}
Concluding remarks, including a note about some limitation in passing.
"""
    r = paper_writing_limitation_statement_presence(tex)

    obs = r["observations"]
    assert obs["discussion_found"] is False
    assert obs["discussion_char_range"] is None
    assert obs["limitation_paragraphs"] == []

    # score = 3 fallback
    assert r["score"] == 3.0

    joined = "\n".join(r["comments"])
    assert "Discussion" in joined
    assert "見出し" in joined or "section" in joined.lower()


# ------------------------------------------------------------------
# Case 6: Markdown heading detection
# ------------------------------------------------------------------
def test_markdown_discussion_detected():
    md = """
## Introduction
Intro.

## Discussion
Main finding is that A outperforms B. This validates the approach.

Several limitations remain. The method currently assumes noise-free input, which restricts applicability to clean signals. Extending to noisy inputs requires an additional denoising stage, which we leave as future work. Also, scaling experiments are limited to medium-sized problems up to 1e5 variables.

We conclude with implications.

## Conclusion
Done.
"""
    r = paper_writing_limitation_statement_presence(md)
    obs = r["observations"]
    assert obs["discussion_found"] is True
    assert len(obs["limitation_paragraphs"]) >= 1


# ------------------------------------------------------------------
# Case 7: Japanese 考察 / 制約
# ------------------------------------------------------------------
def test_japanese_discussion_with_limitation():
    tex = r"""
\section{はじめに}
導入。

\section{考察}
本研究の主たる知見は、提案手法が既存法を全てのケースで上回ることである。これは理論予測と整合する。

一方で、本研究には制約が存在する。第一に、データ集合が合成データに限定され、実世界のノイズ特性を完全には反映していない。第二に、順問題作用素が既知であることを仮定しており、これは臨床応用では必ずしも成立しない。第三に、計算コストがグリッドサイズに比例するため、超大規模問題への適用は限定的である。これらの課題は今後の研究方針を形作る。

これらの制約を踏まえ、今後はノイズを含む実データでの検証を進める予定である。

\section{結論}
以上。
"""
    r = paper_writing_limitation_statement_presence(tex)
    obs = r["observations"]
    assert obs["discussion_found"] is True
    assert len(obs["limitation_paragraphs"]) >= 1


# ------------------------------------------------------------------
# Additional robustness
# ------------------------------------------------------------------
def test_empty_input_no_crash():
    r = paper_writing_limitation_statement_presence("")
    assert "score" in r
    assert "comments" in r
    assert "observations" in r
    assert r["observations"]["discussion_found"] is False
    assert len(r["comments"]) >= 2


def test_none_input_no_crash():
    r = paper_writing_limitation_statement_presence(None)  # type: ignore[arg-type]
    assert r["observations"]["discussion_found"] is False


def test_hint_and_source_content():
    r = paper_writing_limitation_statement_presence("test")
    assert "markdown" in r["hint"] or "LaTeX" in r["hint"]
    assert "skill.md" in r["source"]
    assert "Wallwork" in r["source"]
