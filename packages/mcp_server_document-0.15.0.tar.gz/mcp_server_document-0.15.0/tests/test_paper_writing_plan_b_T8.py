"""Tests for Plan B T8: paper_writing_health_report — Plan B meta aggregator.

5 cases:
1. clean_draft — 揃った draft: overall_severity は MEDIUM 以下、CRITICAL なし
2. critical_draft — 空に近い draft: CRITICAL/HIGH が出る
3. skip_T5 — skip="T5" で related_work を除外
4. no_bib_auto_skip — bib 空で T5 が自動 skip される
5. shape_contract — 返り値 shape の契約
"""
from mcp_server_document.paper_writing.plan_b_T8 import (
    paper_writing_health_report,
)


# ------------------------------------------------------------------
# Case 1: clean draft (Abstract + Intro + Discussion + figures refs)
# ------------------------------------------------------------------
def test_clean_draft_low_severity():
    abstract = (
        "Current inductor-design approaches suffer from long computation times. "
        "We propose a fast PEEC solver with adaptive mesh refinement. "
        "We demonstrate 94.2% accuracy and a 3.2x speedup over state-of-the-art. "
        "This enables real-time design exploration in practical workflows."
    )
    tex = (
        r"\section{Introduction}" + "\n"
        "Background. Prior work \\cite{a,b,c,d,e}. "
        "The state-of-the-art achieves 90% accuracy but takes hours.\n\n"
        "We propose a novel method. Our contributions are:\n"
        r"\begin{itemize}" + "\n"
        r"\item We propose a fast PEEC solver (Section 2)." + "\n"
        r"\item We demonstrate 94.2\% accuracy on benchmarks." + "\n"
        r"\item We reduce compute time by 3.2\times." + "\n"
        r"\end{itemize}" + "\n\n"
        r"\section{Method}" + "\n"
        r"See Figure \ref{fig:overview} for the pipeline." + "\n"
        r"The result in Figure \ref{fig:overview} shows clear improvement." + "\n"
        r"\begin{figure}\caption{Overview.}\label{fig:overview}\end{figure}" + "\n\n"
        r"\section{Discussion}" + "\n"
        r"Our approach has limitations: it assumes linearity \cite{a}. "
        "The method works for mid-frequency cases. Future work will extend it. "
        "We conclude with a clear outlook.\n"
    )
    bib = (
        "@article{a, author={Smith, A}, year={2023}}\n"
        "@article{b, author={Jones, B}, year={2024}}\n"
        "@article{c, author={Brown, C}, year={2022}}\n"
        "@article{d, author={Green, D}, year={2023}}\n"
        "@article{e, author={White, E}, year={2024}}\n"
    )
    r = paper_writing_health_report(
        tex, bib=bib, abstract=abstract, author_last_names="Sugahara"
    )
    assert r["overall_severity"] in ("LOW", "MEDIUM", "HIGH")
    # Should run all 7 tools (none auto-skipped)
    assert set(r["tools_run"]) >= {"T1", "T2", "T3", "T4", "T5", "T6", "T7"}
    assert r["tools_skipped"] == []


# ------------------------------------------------------------------
# Case 2: critical draft (empty-ish)
# ------------------------------------------------------------------
def test_critical_draft_flags_issues():
    tex = "This paper discusses things. It is significantly better."
    r = paper_writing_health_report(
        tex, bib="", abstract="Recent work studies X.",
        author_last_names="",
    )
    severities = [i["severity"] for i in r["priority_issues"]]
    assert "CRITICAL" in severities or "HIGH" in severities
    assert r["overall_severity"] in ("CRITICAL", "HIGH", "MEDIUM")


# ------------------------------------------------------------------
# Case 3: skip argument
# ------------------------------------------------------------------
def test_skip_T5_excludes_related_work():
    tex = r"\section{Introduction}" + "\nTest text.\n"
    r = paper_writing_health_report(
        tex, bib="@article{a, year=2024}", abstract="Test.",
        skip="T5",
    )
    assert "T5" not in r["tools_run"]
    assert "T5" in r["tools_skipped"]


# ------------------------------------------------------------------
# Case 4: no_bib → T5 auto-skipped
# ------------------------------------------------------------------
def test_no_bib_auto_skips_T5():
    tex = r"\section{Introduction}" + "\nTest.\n"
    r = paper_writing_health_report(
        tex, bib="", abstract="Test abstract with problem and method propose.",
    )
    assert "T5" not in r["tools_run"]
    assert "T5" in r["tools_skipped"]


def test_no_abstract_auto_skips_T1():
    tex = r"\section{Introduction}" + "\nTest.\n"
    r = paper_writing_health_report(tex, bib="", abstract="")
    assert "T1" not in r["tools_run"]
    assert "T1" in r["tools_skipped"]
    # Both auto-skipped
    assert "T5" in r["tools_skipped"]


# ------------------------------------------------------------------
# Case 5: shape contract
# ------------------------------------------------------------------
def test_shape_contract():
    r = paper_writing_health_report(
        "Some draft text.", bib="", abstract="",
    )
    # Required keys
    for key in (
        "overall_score", "score_max", "overall_severity",
        "summary_comment", "detailed_scores", "priority_issues",
        "tools_run", "tools_skipped", "hint", "source",
    ):
        assert key in r, f"missing key: {key}"
    assert r["score_max"] == 10
    assert 0 <= r["overall_score"] <= 10
    assert r["overall_severity"] in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "UNKNOWN")
    assert isinstance(r["detailed_scores"], dict)
    assert isinstance(r["priority_issues"], list)
    assert isinstance(r["tools_run"], list)
    assert isinstance(r["tools_skipped"], list)
    assert isinstance(r["summary_comment"], str)
    assert len(r["summary_comment"]) > 10
    # Plan B signature in source
    assert "Plan B" in r["source"]


def test_priority_issues_sorted_by_severity():
    """priority_issues は CRITICAL が先頭に来る。"""
    r = paper_writing_health_report(
        "Short text.", bib="", abstract="",
    )
    sevs = [i["severity"] for i in r["priority_issues"]]
    rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "UNKNOWN": 3, "LOW": 4}
    assert sevs == sorted(sevs, key=lambda s: rank.get(s, 99))
    # LOW は priority_issues に入らない
    assert "LOW" not in sevs


def test_none_inputs_no_crash():
    r = paper_writing_health_report(
        None, bib=None, abstract=None, author_last_names=None,  # type: ignore[arg-type]
    )
    assert "overall_score" in r
    assert r["score_max"] == 10


def test_skip_multiple():
    tex = r"\section{Introduction}" + "\nTest.\n"
    r = paper_writing_health_report(
        tex, bib="@a{x,year=2024}", abstract="Test.",
        skip="T3, T6",
    )
    assert "T3" not in r["tools_run"]
    assert "T6" not in r["tools_run"]
    assert "T3" in r["tools_skipped"]
    assert "T6" in r["tools_skipped"]
