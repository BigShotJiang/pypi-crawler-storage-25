"""Tests for Plan B T14 — grant_writing_schedule_consistency_check."""

from __future__ import annotations

from mcp_server_document.grant_writing.plan_b_T14 import (
    grant_writing_schedule_consistency_check,
)


def test_clean_schedule():
    """年度連続・フェーズ・マイルストーン・終期成果物揃い → score >= 8."""
    text = (
        "令和6年度: 基礎検討 Phase 1\n"
        "令和7年度: 実装 Phase 2, 中間報告\n"
        "令和8年度: 実証実験, 論文投稿, 完成"
    )
    result = grant_writing_schedule_consistency_check(text)

    assert result["score"] >= 8
    assert result["score_max"] == 10
    obs = result["observations"]
    assert obs["year_continuity"] is True
    reiwa_vals = sorted(
        {m["value"] for m in obs["year_markers"] if m["kind"] == "reiwa"}
    )
    assert reiwa_vals == [6, 7, 8]
    # Phase tokens captured (Phase 1 / Phase 2)
    assert obs["phases_total"] >= 2
    # milestones: 中間報告, 実証実験, 論文投稿, 完成 (>=2)
    assert len(obs["milestone_keywords_found"]) >= 2
    # 末尾 300字に「完成」あり
    assert obs["end_deliverable_present"] is True
    # all good コメント
    assert any("整合" in c for c in result["comments"])
    # source
    assert "スケジュール" in result["source"]


def test_year_gap():
    """令和6年度 → 令和8年度 (7年度欠) → year_continuity False."""
    text = "令和6年度: X\n令和8年度: Y"
    result = grant_writing_schedule_consistency_check(text)

    obs = result["observations"]
    assert obs["year_continuity"] is False
    # 欠落を指摘するコメント
    assert any(
        ("連続性" in c) or ("抜け" in c) for c in result["comments"]
    )
    # 減点が効いているか: 5 + 0(連続性無効) + 0(milestones<2) + 0(end無) - 2 = 3
    assert result["score"] <= 5


def test_no_milestones():
    """年度はあるがマイルストーン語 0 → 低スコア, milestone 要求."""
    text = "令和6年度～令和8年度にかけて研究を進める"
    result = grant_writing_schedule_consistency_check(text)

    obs = result["observations"]
    assert len(obs["milestone_keywords_found"]) == 0
    # milestone 不足の指摘
    assert any(
        ("マイルストーン" in c) or ("最低 2 件" in c)
        for c in result["comments"]
    )
    # スコアは 8 未満 (milestones +2 が付かない)
    assert result["score"] < 8


def test_plain_text():
    """スケジュール要素完全無し → score == 2 固定, 強い指摘."""
    text = "本研究は適切に進める。"
    result = grant_writing_schedule_consistency_check(text)

    obs = result["observations"]
    assert len(obs["year_markers"]) == 0
    assert len(obs["phase_tokens"]) == 0
    assert len(obs["milestone_keywords_found"]) == 0
    # 完全無検出 → score 2 に固定
    assert result["score"] == 2
    # スケジュール記述不在を指摘
    assert any("スケジュール記述が検出されない" in c for c in result["comments"])


def test_return_shape():
    """返却 dict の必須キー."""
    result = grant_writing_schedule_consistency_check("令和6年度")
    for key in ("score", "score_max", "comments", "observations", "hint", "source"):
        assert key in result
    assert isinstance(result["score"], float)
    assert result["score_max"] == 10
    assert isinstance(result["comments"], list)
    assert 1 <= len(result["comments"]) <= 5
    obs = result["observations"]
    for key in (
        "year_markers",
        "year_continuity",
        "phase_tokens",
        "milestone_keywords_found",
        "end_deliverable_present",
        "phases_total",
        "year_span",
    ):
        assert key in obs


# ------------------------------------------------------------------
# 2026-04-23 hardening: 令和・西暦混在を西暦正規化して連続性判定
# ------------------------------------------------------------------
def test_reiwa_seireki_mixed_continuous():
    """「令和6年度 / 2025年度 / 令和8年度」を西暦に正規化して連続判定。

    令和6年度 = 2024年度、令和8年度 = 2026年度、
    2025年度 は中間、結果として 2024-2025-2026 の連続に揃う。
    """
    text = (
        "令和6年度は基礎検討を行う。"
        "2025年度は実証実験に移る。"
        "令和8年度に論文投稿し完成する。中間報告も行う。"
    )
    r = grant_writing_schedule_consistency_check(text)
    assert r["observations"]["year_continuity"] is True
    # normalized_year が付いている
    for m in r["observations"]["year_markers"]:
        if m["kind"] in ("reiwa", "seireki", "relative_R"):
            assert m["normalized_year"] is not None


def test_reiwa_seireki_mixed_with_gap():
    """令和 6 (=2024) と 2026 年度 の間の 2025 年度が抜けていれば非連続。"""
    text = "令和6年度は基礎検討。2026年度に完成する。成果発表も行う。"
    r = grant_writing_schedule_consistency_check(text)
    assert r["observations"]["year_continuity"] is False


def test_normalized_year_for_reiwa_and_r_prefix():
    """R6 も令和6と同じ normalized_year = 2024。"""
    text = "R6 基盤検討、R7 実装、R8 完成、論文投稿。"
    r = grant_writing_schedule_consistency_check(text)
    years = sorted({
        m["normalized_year"] for m in r["observations"]["year_markers"]
        if m["normalized_year"] is not None
    })
    assert 2024 in years
    assert 2025 in years
    assert 2026 in years
    assert r["observations"]["year_continuity"] is True


def test_year_span_uses_normalized():
    """year_span は西暦正規化後の範囲で計算される。"""
    text = "令和6年度と令和8年度で実施する。論文投稿と完成を行う。"
    r = grant_writing_schedule_consistency_check(text)
    # 令和6=2024, 令和8=2026 → 2026-2024+1 = 3
    assert r["observations"]["year_span"] == 3
