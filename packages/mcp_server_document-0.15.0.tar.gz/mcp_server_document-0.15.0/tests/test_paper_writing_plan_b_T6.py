"""Tests for Plan B T6: paper_writing_figure_referencing_coverage.

5 cases:
1. all_well_referenced — 全 label が >= 2 回参照 → high score
2. unreferenced_figure — \\label 定義あるが \\ref なし → unreferenced flag
3. singleton_figure — 1 回しか \\ref されない → singleton flag
4. mixed — well / singleton / unreferenced が混在
5. no_labels — \\label 無し → score 10 (vacuously OK)

Assertions focus on `comments` substrings and key `observations` values.
Do NOT over-assert exact scores.
"""
from mcp_server_document.paper_writing.plan_b_T6 import (
    paper_writing_figure_referencing_coverage,
)


# ------------------------------------------------------------------
# Case 1: all labels referenced >= 2 times
# ------------------------------------------------------------------
def test_all_well_referenced_scores_high():
    tex = r"""
\section{Results}
As shown in Fig.~\ref{fig:overview}, the system has three stages.
The overall flow of Fig.~\ref{fig:overview} is described in detail below.

Table~\ref{tab:bench} summarizes the benchmark runs.
In \cref{tab:bench} we highlight the fastest configuration.

\begin{figure}
  \caption{System overview.}
  \label{fig:overview}
\end{figure}

\begin{table}
  \caption{Benchmarks.}
  \label{tab:bench}
\end{table}
"""
    r = paper_writing_figure_referencing_coverage(tex)

    # 構造
    assert r["score_max"] == 10
    assert 0.0 <= r["score"] <= 10.0
    assert 2 <= len(r["comments"]) <= 5
    assert "Tufte" in r["source"]
    assert "§17" in r["source"] or "Wallwork" in r["source"]

    obs = r["observations"]
    assert obs["total_labels"] == 2
    assert set(obs["well_referenced"]) == {"fig:overview", "tab:bench"}
    assert obs["unreferenced_labels"] == []
    assert obs["singleton_labels"] == []
    assert obs["ref_counts"]["fig:overview"] >= 2
    assert obs["ref_counts"]["tab:bench"] >= 2
    assert obs["coverage_ratio"] == 1.0

    # 高スコア (満点)
    assert r["score"] == 10

    joined = "\n".join(r["comments"])
    assert "good coverage" in joined or "複数箇所" in joined


# ------------------------------------------------------------------
# Case 2: unreferenced figure
# ------------------------------------------------------------------
def test_unreferenced_figure_flagged():
    tex = r"""
\section{Results}
All discussion proceeds without ever mentioning the figure.

\begin{figure}
  \caption{Orphan figure.}
  \label{fig:orphan}
\end{figure}
"""
    r = paper_writing_figure_referencing_coverage(tex)

    obs = r["observations"]
    assert obs["total_labels"] == 1
    assert obs["unreferenced_labels"] == ["fig:orphan"]
    assert obs["ref_counts"]["fig:orphan"] == 0
    assert obs["singleton_labels"] == []
    assert obs["well_referenced"] == []

    joined = "\n".join(r["comments"])
    assert "参照されない" in joined
    assert "fig:orphan" in joined

    # 1 件の unreferenced → 10 - 2 = 8
    assert r["score"] <= 8


# ------------------------------------------------------------------
# Case 3: singleton figure
# ------------------------------------------------------------------
def test_singleton_figure_flagged():
    tex = r"""
\section{Results}
See Fig.~\ref{fig:single} for the setup (mentioned only once).

\begin{figure}
  \caption{Only-cited-once figure.}
  \label{fig:single}
\end{figure}
"""
    r = paper_writing_figure_referencing_coverage(tex)

    obs = r["observations"]
    assert obs["total_labels"] == 1
    assert obs["singleton_labels"] == ["fig:single"]
    assert obs["ref_counts"]["fig:single"] == 1
    assert obs["unreferenced_labels"] == []
    assert obs["well_referenced"] == []

    joined = "\n".join(r["comments"])
    assert "1 回" in joined or "singleton" in joined.lower() or "redundant" in joined.lower()
    assert "fig:single" in joined

    # singleton 1 件 → 10 - 1 = 9
    assert r["score"] <= 9
    assert r["score"] >= 8


# ------------------------------------------------------------------
# Case 4: mixed — well / singleton / unreferenced
# ------------------------------------------------------------------
def test_mixed_labels():
    tex = r"""
\section{Results}
Fig.~\ref{fig:good} shows the pipeline.
The pipeline of Fig.~\ref{fig:good} supports three variants.

Fig.~\ref{fig:once} illustrates a minor detail.

Table~\ref{tab:also_good} lists the runtimes.
The runtimes in \cref{tab:also_good} vary across machines.

\begin{figure}
  \label{fig:good}
\end{figure}
\begin{figure}
  \label{fig:once}
\end{figure}
\begin{figure}
  \label{fig:unused}
\end{figure}
\begin{table}
  \label{tab:also_good}
\end{table}
"""
    r = paper_writing_figure_referencing_coverage(tex)

    obs = r["observations"]
    assert obs["total_labels"] == 4
    assert set(obs["well_referenced"]) == {"fig:good", "tab:also_good"}
    assert obs["singleton_labels"] == ["fig:once"]
    assert obs["unreferenced_labels"] == ["fig:unused"]
    # coverage = 2/4 = 0.5
    assert obs["coverage_ratio"] == 0.5
    assert obs["ref_counts"]["fig:good"] >= 2
    assert obs["ref_counts"]["fig:once"] == 1
    assert obs["ref_counts"]["fig:unused"] == 0

    joined = "\n".join(r["comments"])
    # 両方の flag が指摘されている
    assert "参照されない" in joined
    assert "1 回" in joined or "redundant" in joined.lower()

    # 1 unreferenced (-2) + 1 singleton (-1) → 10 - 3 = 7
    assert r["score"] == 7


# ------------------------------------------------------------------
# Case 5: no labels at all
# ------------------------------------------------------------------
def test_no_labels_vacuously_ok():
    tex = r"""
\section{Introduction}
This is a text-only paper with no figures or tables whatsoever.
It just has prose and references to other works~\cite{foo}.
"""
    r = paper_writing_figure_referencing_coverage(tex)

    obs = r["observations"]
    assert obs["total_labels"] == 0
    assert obs["labels_defined"] == {}
    assert obs["ref_counts"] == {}
    assert obs["unreferenced_labels"] == []
    assert obs["singleton_labels"] == []
    assert obs["well_referenced"] == []
    assert obs["coverage_ratio"] == 1.0

    # vacuously OK
    assert r["score"] == 10

    joined = "\n".join(r["comments"])
    assert "検出されない" in joined or "該当なし" in joined


# ------------------------------------------------------------------
# Additional robustness: empty / None input
# ------------------------------------------------------------------
def test_empty_input_no_crash():
    r = paper_writing_figure_referencing_coverage("")
    assert "score" in r
    assert "comments" in r
    assert r["observations"]["total_labels"] == 0
    assert r["score"] == 10
    assert len(r["comments"]) >= 2


def test_none_input_no_crash():
    r = paper_writing_figure_referencing_coverage(None)  # type: ignore[arg-type]
    assert r["observations"]["total_labels"] == 0
    assert r["score"] == 10


# ------------------------------------------------------------------
# hint / source fixed content
# ------------------------------------------------------------------
def test_hint_and_source_content():
    r = paper_writing_figure_referencing_coverage("test")
    assert "fig:" in r["hint"]
    assert "tab:" in r["hint"]
    assert "対象外" in r["hint"]
    assert "Tufte" in r["source"]
    assert "Wallwork" in r["source"]


# ------------------------------------------------------------------
# sec:/eq: prefix は対象外 (hint の仕様確認)
# ------------------------------------------------------------------
def test_non_figtab_labels_ignored():
    tex = r"""
\section{Intro} \label{sec:intro}
\begin{equation} x = 1 \label{eq:one} \end{equation}
Eq.~\ref{eq:one} and Sec.~\ref{sec:intro} are cited, but these
are not fig/tab labels so T6 should ignore them.
"""
    r = paper_writing_figure_referencing_coverage(tex)
    obs = r["observations"]
    assert obs["total_labels"] == 0
    assert r["score"] == 10
