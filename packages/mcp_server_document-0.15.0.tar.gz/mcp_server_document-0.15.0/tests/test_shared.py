"""Tests for mcp_server_document._shared helpers."""
from mcp_server_document._shared import (
    HEDGE_PATTERNS,
    scan_hedges,
    is_japanese,
    cjk_char_count,
    split_ja_sentences,
    split_mixed_sentences,
)


def test_scan_hedges_counts():
    text = "本研究は重要と考えられる。さらに発展の可能性がある。期待される成果もある。"
    total, by_pat = scan_hedges(text)
    assert total >= 3
    assert "と考えられる" in by_pat
    assert "可能性がある" in by_pat
    assert "期待される" in by_pat


def test_scan_hedges_none():
    total, by_pat = scan_hedges("本研究は成果を達成した。")
    assert total == 0
    assert by_pat == {}


def test_hedge_patterns_has_10():
    assert len(HEDGE_PATTERNS) >= 10


def test_is_japanese_pure_ja():
    assert is_japanese("本研究は新規手法を提案する。") is True


def test_is_japanese_pure_en():
    assert is_japanese("This paper proposes a novel method.") is False


def test_is_japanese_mixed_majority_ja():
    # JA-majority mixed: >= 30% CJK → True
    assert is_japanese("本研究は新規 algorithm を提案する。") is True


def test_is_japanese_mixed_majority_en():
    # EN-majority mixed: < 30% CJK → False (3 CJK / 25 non-ws = 0.12)
    assert is_japanese("本研究 proposes a new algorithm.") is False


def test_is_japanese_empty():
    assert is_japanese("") is False


def test_cjk_char_count():
    assert cjk_char_count("あいうえお") == 5
    assert cjk_char_count("漢字") == 2
    assert cjk_char_count("hello") == 0
    assert cjk_char_count("") == 0


def test_split_ja_sentences():
    text = "第一文。第二文．第三文。"
    result = split_ja_sentences(text)
    assert len(result) == 3
    assert result[0] == "第一文"


def test_split_ja_sentences_strips_empty():
    result = split_ja_sentences("。。 。")
    assert result == []


def test_split_mixed_sentences():
    text = "Japanese 文。English sentence. Another one!"
    result = split_mixed_sentences(text)
    assert len(result) >= 3


def test_split_mixed_sentences_empty():
    assert split_mixed_sentences("") == []
