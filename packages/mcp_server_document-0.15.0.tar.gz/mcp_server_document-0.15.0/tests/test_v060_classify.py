"""Tests for v0.6.0: OCR-inspired per-CC classification + auto pipeline."""
from __future__ import annotations

import json
import pathlib

import pytest


def _make_synth_image(tmp_path: pathlib.Path) -> pathlib.Path:
    """Synthesise a 120x120 image with: filled square, filled circle, and a
    thin diagonal line — spans the three main classes."""
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    import numpy as np
    import cv2
    img = np.full((120, 120, 3), 255, dtype=np.uint8)  # white bg
    # Filled black square (fill)
    cv2.rectangle(img, (10, 10), (45, 45), (0, 0, 0), thickness=-1)
    # Filled black circle (circle)
    cv2.circle(img, (90, 30), 15, (0, 0, 0), thickness=-1)
    # Thin diagonal line (line)
    cv2.line(img, (10, 90), (100, 110), (0, 0, 0), thickness=2)
    p = tmp_path / "synth_mixed.png"
    cv2.imwrite(str(p), img)
    return p


# ---------------------------------------------------------------------------
# classify_components
# ---------------------------------------------------------------------------
def test_classify_components_mixed_image(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    from mcp_server_document.diagram.tools import diagram_classify_components

    p = _make_synth_image(tmp_path)
    r = diagram_classify_components(str(p), min_area=20, use_ocr=False)
    assert "error" not in r, r
    assert r["total_cc"] >= 3, r
    hist = r["class_histogram"]
    # Expect at least one of each major class (circle, line, fill/other)
    assert "circle" in hist or "fill" in hist or "other" in hist
    # The 15-radius filled circle should get detected as circle
    # (relax: circularity may dip below 0.7 at this resolution, either
    # "circle" or "fill" is acceptable)
    labels_present = set(hist.keys())
    assert labels_present & {"circle", "fill", "line", "other", "text_like"}
    # stroke_width_stats populated
    assert r["stroke_width_stats"] is not None


def test_classify_components_bad_image():
    from mcp_server_document.diagram.tools import diagram_classify_components
    r = diagram_classify_components("/nonexistent/nope.png")
    assert "error" in r


def test_classify_components_writes_json(tmp_path):
    pytest.importorskip("cv2")
    pytest.importorskip("numpy")
    from mcp_server_document.diagram.tools import diagram_classify_components

    p = _make_synth_image(tmp_path)
    out = tmp_path / "cc.json"
    r = diagram_classify_components(str(p), out_json=str(out))
    assert "error" not in r
    assert out.exists()
    loaded = json.loads(out.read_text(encoding="utf-8"))
    assert loaded["total_cc"] == r["total_cc"]


# ---------------------------------------------------------------------------
# analyze_layers
# ---------------------------------------------------------------------------
def test_analyze_layers_empty_dir(tmp_path):
    from mcp_server_document.diagram.tools import diagram_analyze_layers
    r = diagram_analyze_layers(str(tmp_path))
    assert "error" in r


def test_analyze_layers_missing():
    from mcp_server_document.diagram.tools import diagram_analyze_layers
    r = diagram_analyze_layers("/nonexistent/dir")
    assert "error" in r


def test_analyze_layers_synth(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    from mcp_server_document.diagram.tools import diagram_analyze_layers
    import numpy as np
    import cv2

    # Build a fake "layers" dir with 3 pseudo-layer PNGs
    (tmp_path / "layer_fill.png").write_bytes(b"")  # placeholder, will overwrite
    fill_img = np.full((100, 100, 3), 255, dtype=np.uint8)
    cv2.rectangle(fill_img, (20, 20), (80, 80), (0, 0, 0), thickness=-1)
    cv2.imwrite(str(tmp_path / "layer_fill.png"), fill_img)

    line_img = np.full((100, 100, 3), 255, dtype=np.uint8)
    cv2.line(line_img, (5, 50), (95, 52), (0, 0, 0), thickness=2)
    cv2.imwrite(str(tmp_path / "layer_line.png"), line_img)

    circle_img = np.full((100, 100, 3), 255, dtype=np.uint8)
    cv2.circle(circle_img, (50, 50), 20, (0, 0, 0), thickness=-1)
    cv2.imwrite(str(tmp_path / "layer_circle.png"), circle_img)

    r = diagram_analyze_layers(str(tmp_path), min_area=20)
    assert "error" not in r, r
    assert r["layers_analyzed"] == 3
    by_name = {layer["filename"]: layer for layer in r["layers"]}
    assert "layer_fill.png" in by_name
    # Each layer has a recommended strategy
    for layer in r["layers"]:
        assert layer["recommended_strategy"] in (
            "fill_contour", "skeleton_lines", "circles_fit",
            "text_placeholder", "outline", "skip",
        )


# ---------------------------------------------------------------------------
# compose_auto
# ---------------------------------------------------------------------------
def test_compose_auto_smoke(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    from mcp_server_document.diagram.tools import diagram_compose_auto

    p = _make_synth_image(tmp_path)
    out = tmp_path / "out.excalidraw"
    r = diagram_compose_auto(str(p), str(out), min_area=20, use_ocr=False)
    assert "error" not in r, r
    assert r["total_elements"] >= 1
    assert out.exists()
    doc = json.loads(out.read_text(encoding="utf-8"))
    assert doc["type"] == "excalidraw"
    # All elements should have a groupIds label indicating their class
    labels_seen = set()
    for el in doc["elements"]:
        for g in (el.get("groupIds") or []):
            labels_seen.add(g)
    # Expect at least one known class label
    assert labels_seen & {"text_like", "line", "circle", "fill", "other"}


def test_compose_auto_missing():
    from mcp_server_document.diagram.tools import diagram_compose_auto
    r = diagram_compose_auto("/nonexistent/nope.png", "/tmp/out.excalidraw")
    assert "error" in r


# ---------------------------------------------------------------------------
# trace_iterative
# ---------------------------------------------------------------------------
def test_trace_iterative_converges_on_flat(tmp_path):
    pytest.importorskip("numpy")
    pytest.importorskip("cv2")
    pytest.importorskip("PIL")
    from mcp_server_document.diagram.tools import diagram_trace_iterative
    import numpy as np
    import cv2

    # Very simple image: 2-color flat should converge to PSNR >= 40 quickly
    img = np.full((60, 60, 3), 255, dtype=np.uint8)
    cv2.rectangle(img, (10, 10), (30, 30), (0, 0, 255), thickness=-1)
    p = tmp_path / "flat.png"
    cv2.imwrite(str(p), img)
    out = tmp_path / "iter.excalidraw"
    r = diagram_trace_iterative(str(p), str(out),
                                   target_psnr=30.0, max_iterations=3)
    assert "error" not in r, r
    assert r["iterations_run"] >= 1
    # Best PSNR should be a real number (not error state)
    best = r["best_psnr"]
    assert best == "inf" or float(best) > 10


def test_trace_iterative_missing():
    from mcp_server_document.diagram.tools import diagram_trace_iterative
    r = diagram_trace_iterative("/nonexistent/nope.png", "/tmp/out.excalidraw")
    assert "error" in r
