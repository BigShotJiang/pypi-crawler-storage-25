"""Tests for Plan B T20 — grant_writing_applicant_credentials_check."""

from __future__ import annotations

from mcp_server_document.grant_writing.plan_b_T20 import (
    grant_writing_applicant_credentials_check,
)


def test_rich_credentials_section():
    """見出し + 論文/科研費/国際/OSS/受賞/学会 の 6 要素 → score >= 7."""
    text = (
        "3. 研究遂行能力\n"
        "申請者はこれまでに査読付き論文を 10 本発表 (筆頭著者 6 本)。\n"
        "うち journal 論文 5 本は国際会議 (international) でも発表した。\n"
        "科研費 若手研究 (PI) を 2020 年に採択。JST さきがけも経験。\n"
        "実装は GitHub で公開、OSS として release 済み。\n"
        "2022 年に IEEE Young Researcher 優秀奨励賞を受賞。\n"
        "IEEJ 論文誌査読委員を継続中。\n"
        "\n"
        "4. 研究計画\n"
        "本研究の目的は…"
    )
    r = grant_writing_applicant_credentials_check(text)

    assert r["score"] >= 7
    obs = r["observations"]
    assert obs["section_detected"] is True
    assert obs["section_range"] is not None
    covered = obs["covered_categories"]
    assert len(covered) >= 6
    # 期待される必須カテゴリ
    for must in ("papers", "funding", "international", "oss", "awards", "societies"):
        assert must in covered
    # total count field
    assert obs["total_category_count"] == len(covered)


def test_no_section_at_all():
    """見出しなし + 身元記述なし → score <= 3, section_detected False."""
    text = "本研究は適切に進める。"
    r = grant_writing_applicant_credentials_check(text)

    obs = r["observations"]
    assert obs["section_detected"] is False
    assert obs["section_range"] is None
    assert obs["total_category_count"] == 0
    assert r["score"] <= 3
    # 見出し不在を指摘するコメント
    assert any("研究遂行能力" in c and "無い" in c for c in r["comments"])


def test_section_but_thin():
    """見出しあり、論文のみ言及 → section_detected True, low total_category_count."""
    text = (
        "応募者の研究遂行能力\n"
        "これまでに査読付き論文を発表してきた。"
    )
    r = grant_writing_applicant_credentials_check(text)

    obs = r["observations"]
    assert obs["section_detected"] is True
    assert "papers" in obs["covered_categories"]
    # thin: <= 2 category
    assert obs["total_category_count"] <= 2
    # missing の suggestion が入る
    missing_suggestions = [
        "獲得資金",
        "国際交流",
        "OSS",
        "受賞",
        "学会",
        "招待講演",
    ]
    assert any(
        any(kw in c for kw in missing_suggestions) for c in r["comments"]
    )
    # score は満点ではない
    assert r["score"] < 7


def test_whole_text_fallback():
    """見出しなしだが全文に credentials 散在 → fallback で covered あり."""
    text = (
        "本研究では Foo を提案する。"
        "なお申請者は査読付き論文 (journal) を複数発表し、"
        "科研費 若手研究を採択されている。"
        "IEEE Young Researcher 受賞歴あり。"
    )
    r = grant_writing_applicant_credentials_check(text)

    obs = r["observations"]
    assert obs["section_detected"] is False
    # fallback ですので、全文から credentials が拾える
    assert obs["total_category_count"] >= 1
    # papers / funding / awards / societies 等のいずれかが拾われる
    assert len(obs["covered_categories"]) >= 1
    # 見出し不在の指摘コメントが含まれる
    assert any("研究遂行能力" in c for c in r["comments"])


# ------------------------------------------------------------------
# Shape / sanity
# ------------------------------------------------------------------
def test_return_shape():
    """返却 dict の必須キー."""
    r = grant_writing_applicant_credentials_check("研究遂行能力\n論文あり")
    for key in ("score", "score_max", "comments", "observations", "hint", "source"):
        assert key in r
    assert isinstance(r["score"], float)
    assert r["score_max"] == 10
    assert isinstance(r["comments"], list)
    assert 1 <= len(r["comments"]) <= 5
    obs = r["observations"]
    for key in (
        "section_detected",
        "section_range",
        "credentials",
        "covered_categories",
        "missing_categories",
        "total_category_count",
    ):
        assert key in obs
    # credentials dict has all 8 keys
    for cat in (
        "papers", "funding", "international", "oss",
        "awards", "societies", "patents", "invited_talks",
    ):
        assert cat in obs["credentials"]
        assert isinstance(obs["credentials"][cat], int)


def test_source_mentions_nakayasu():
    """source に中安豪 / 新様式 / skill.md 等の原典が明記されている."""
    r = grant_writing_applicant_credentials_check("研究遂行能力")
    assert "中安豪" in r["source"] or "新様式" in r["source"]
