"""Excalidraw post-processing helpers (v0.7.0).

- ``fit_bezier_impl``             : smooth polylines by fitting cubic
                                     Bezier curves (Schneider method,
                                     simplified) and resampling at
                                     uniform arc length so the output is
                                     still a plain Excalidraw ``line``
                                     but with ~¼ the points and a much
                                     smoother look.
- ``semantic_group_impl``         : run DBSCAN on element bounding-box
                                     centres and assign shared
                                     ``groupIds`` so the user can select
                                     a logical chunk (icon, wordmark,
                                     block) with one click.
- ``stroke_width_normalize_impl`` : find the dominant stroke-width
                                     buckets and snap every element's
                                     stroke to the nearest bucket —
                                     stops the "every line a different
                                     width" look produced by raster
                                     tracers.
"""
from __future__ import annotations

import json
import math
import pathlib
from typing import Any


# ---------------------------------------------------------------------------
# Shared utilities
# ---------------------------------------------------------------------------
def _load_doc(path: str) -> tuple[dict | None, str | None]:
    p = pathlib.Path(path).expanduser()
    if not p.exists():
        return None, f"file not found: {p}"
    try:
        return json.loads(p.read_text(encoding="utf-8")), None
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        return None, f"parse error: {exc}"


def _write_doc(path: str, doc: dict) -> None:
    outp = pathlib.Path(path).expanduser()
    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")


# ---------------------------------------------------------------------------
# 4. fit_bezier — Schneider-style bezier smoothing (simplified)
# ---------------------------------------------------------------------------
def _resample_bezier_uniform(p0, p1, p2, p3, n_samples: int) -> list[list[float]]:
    """Sample a cubic Bezier at ``n_samples`` parameter values in [0, 1]."""
    pts = []
    for i in range(n_samples):
        t = i / (n_samples - 1) if n_samples > 1 else 0.0
        u = 1.0 - t
        x = (u * u * u * p0[0] + 3 * u * u * t * p1[0]
              + 3 * u * t * t * p2[0] + t * t * t * p3[0])
        y = (u * u * u * p0[1] + 3 * u * u * t * p1[1]
              + 3 * u * t * t * p2[1] + t * t * t * p3[1])
        pts.append([x, y])
    return pts


def _fit_cubic_bezier(points: list[list[float]]) -> tuple[list, list, list, list]:
    """Very rough cubic-Bezier fit: endpoints pinned, control points placed
    along tangent estimates at a distance proportional to chord length.

    This is NOT the full Schneider algorithm (which iterates via
    Newton-Raphson to refine parameters) but works well for the
    "smooth noisy polyline" use case.
    """
    if len(points) < 2:
        return None, None, None, None  # type: ignore
    p0 = list(points[0])
    p3 = list(points[-1])
    if len(points) == 2:
        # Degenerate: straight line with tangent == direction
        dx = p3[0] - p0[0]; dy = p3[1] - p0[1]
        p1 = [p0[0] + dx / 3.0, p0[1] + dy / 3.0]
        p2 = [p3[0] - dx / 3.0, p3[1] - dy / 3.0]
        return p0, p1, p2, p3
    # Tangent at p0: direction from p0 to the 2nd point, normalised
    tx0 = points[1][0] - p0[0]; ty0 = points[1][1] - p0[1]
    t0n = math.hypot(tx0, ty0) + 1e-9
    tx0 /= t0n; ty0 /= t0n
    # Tangent at p3 (opposite direction, from second-to-last to last):
    tx3 = p3[0] - points[-2][0]; ty3 = p3[1] - points[-2][1]
    t3n = math.hypot(tx3, ty3) + 1e-9
    tx3 /= t3n; ty3 /= t3n
    # Distance scale: use 1/3 of total chord length
    chord = math.hypot(p3[0] - p0[0], p3[1] - p0[1])
    dist = chord / 3.0
    p1 = [p0[0] + tx0 * dist, p0[1] + ty0 * dist]
    p2 = [p3[0] - tx3 * dist, p3[1] - ty3 * dist]
    return p0, p1, p2, p3


def _segment_polyline_at_corners(points: list[list[float]],
                                    angle_thresh_deg: float) -> list[list[list[float]]]:
    """Split a polyline at sharp corners. A vertex is a "corner" if the
    turn angle exceeds ``angle_thresh_deg``.
    """
    if len(points) < 3:
        return [points]
    thresh = math.cos(math.radians(angle_thresh_deg))
    # cos(angle) < thresh means the interior angle is more acute than threshold
    segments = []
    current = [points[0]]
    for i in range(1, len(points) - 1):
        a = points[i - 1]; b = points[i]; c = points[i + 1]
        v1x, v1y = b[0] - a[0], b[1] - a[1]
        v2x, v2y = c[0] - b[0], c[1] - b[1]
        m1 = math.hypot(v1x, v1y); m2 = math.hypot(v2x, v2y)
        if m1 == 0 or m2 == 0:
            current.append(b)
            continue
        cos_theta = (v1x * v2x + v1y * v2y) / (m1 * m2)
        current.append(b)
        if cos_theta < thresh:
            # Sharp corner → close segment and start a new one rooted at b
            segments.append(current)
            current = [b]
    current.append(points[-1])
    segments.append(current)
    # Drop tiny segments of length 1
    return [seg for seg in segments if len(seg) >= 2]


def fit_bezier_impl(excalidraw_path: str,
                     out_path: str,
                     min_points: int,
                     samples_per_segment: int,
                     corner_angle_deg: float,
                     only_types: list[str] | None) -> dict[str, Any]:
    doc, err = _load_doc(excalidraw_path)
    if err:
        return {"error": err}

    targets = set(only_types) if only_types else {"line", "freedraw"}
    modified = 0
    total_before = 0
    total_after = 0
    for el in doc.get("elements", []):
        if el.get("type") not in targets:
            continue
        pts = el.get("points") or []
        if len(pts) < min_points:
            continue
        pts = [list(p) for p in pts]
        closed = (len(pts) >= 3 and pts[0] == pts[-1])
        work = pts[:-1] if closed else pts[:]

        total_before += len(pts)
        segs = _segment_polyline_at_corners(work, corner_angle_deg)
        new_pts: list[list[float]] = []
        for seg in segs:
            p0, p1, p2, p3 = _fit_cubic_bezier(seg)
            if p0 is None:
                new_pts.extend(seg)
                continue
            resampled = _resample_bezier_uniform(
                p0, p1, p2, p3, n_samples=samples_per_segment,
            )
            # Avoid duplicating the join point when stitching segments
            if new_pts and resampled and new_pts[-1] == resampled[0]:
                new_pts.extend(resampled[1:])
            else:
                new_pts.extend(resampled)
        if closed:
            if new_pts and new_pts[0] != new_pts[-1]:
                new_pts.append(list(new_pts[0]))
        if not new_pts:
            continue
        # Re-anchor relative to min coord
        xs = [p[0] for p in new_pts]; ys = [p[1] for p in new_pts]
        mx, my = min(xs), min(ys)
        el["x"] = el.get("x", 0.0) + mx
        el["y"] = el.get("y", 0.0) + my
        el["width"] = max(xs) - mx
        el["height"] = max(ys) - my
        el["points"] = [[p[0] - mx, p[1] - my] for p in new_pts]
        total_after += len(el["points"])
        modified += 1

    _write_doc(out_path, doc)
    compression_pct = 0.0
    if total_before > 0:
        compression_pct = (1.0 - total_after / total_before) * 100.0
    return {
        "out_path": str(pathlib.Path(out_path).expanduser()),
        "elements_modified": modified,
        "points_before": total_before,
        "points_after": total_after,
        "compression_pct": round(compression_pct, 1),
        "samples_per_segment": samples_per_segment,
        "corner_angle_deg": corner_angle_deg,
    }


# ---------------------------------------------------------------------------
# 5. semantic_group — spatial DBSCAN to assign groupIds
# ---------------------------------------------------------------------------
def _dbscan_2d(points: list[tuple[float, float]],
                 eps: float,
                 min_samples: int) -> list[int]:
    n = len(points)
    labels = [-1] * n
    visited = [False] * n
    cluster = 0

    def _nbrs(i: int) -> list[int]:
        xi, yi = points[i]
        return [j for j in range(n)
                 if (points[j][0] - xi) ** 2 + (points[j][1] - yi) ** 2
                     <= eps * eps]

    for i in range(n):
        if visited[i]:
            continue
        visited[i] = True
        ns = _nbrs(i)
        if len(ns) < min_samples:
            labels[i] = -1
            continue
        labels[i] = cluster
        q = list(ns)
        while q:
            j = q.pop(0)
            if not visited[j]:
                visited[j] = True
                ns_j = _nbrs(j)
                if len(ns_j) >= min_samples:
                    q.extend(ns_j)
            if labels[j] == -1:
                labels[j] = cluster
        cluster += 1
    return labels


def semantic_group_impl(excalidraw_path: str,
                          out_path: str,
                          eps: float,
                          min_samples: int,
                          preserve_existing: bool) -> dict[str, Any]:
    doc, err = _load_doc(excalidraw_path)
    if err:
        return {"error": err}

    elements = doc.get("elements", [])
    if not elements:
        return {"error": "document has no elements"}

    # Auto-pick eps = 5% of canvas diagonal when user passes 0
    if eps <= 0:
        xs = [el.get("x", 0.0) for el in elements]
        ys = [el.get("y", 0.0) for el in elements]
        x2s = [el.get("x", 0.0) + el.get("width", 0.0) for el in elements]
        y2s = [el.get("y", 0.0) + el.get("height", 0.0) for el in elements]
        dx = (max(x2s) - min(xs)) if xs else 0.0
        dy = (max(y2s) - min(ys)) if ys else 0.0
        eps = max(20.0, math.hypot(dx, dy) * 0.05)

    centres: list[tuple[float, float]] = []
    for el in elements:
        cx = el.get("x", 0.0) + el.get("width", 0.0) / 2.0
        cy = el.get("y", 0.0) + el.get("height", 0.0) / 2.0
        centres.append((cx, cy))

    labels = _dbscan_2d(centres, eps=eps, min_samples=min_samples)

    cluster_counts: dict[int, int] = {}
    for lbl in labels:
        cluster_counts[lbl] = cluster_counts.get(lbl, 0) + 1
    noise = cluster_counts.pop(-1, 0)

    for el, lbl in zip(elements, labels):
        if lbl == -1:
            continue
        group_id = f"semantic_{lbl}"
        existing = el.get("groupIds") or []
        if preserve_existing:
            if group_id not in existing:
                existing.append(group_id)
            el["groupIds"] = existing
        else:
            el["groupIds"] = [group_id]

    _write_doc(out_path, doc)
    return {
        "out_path": str(pathlib.Path(out_path).expanduser()),
        "eps": eps,
        "min_samples": min_samples,
        "total_elements": len(elements),
        "clusters": len(cluster_counts),
        "cluster_sizes": sorted(cluster_counts.values(), reverse=True)[:20],
        "noise_elements": noise,
    }


# ---------------------------------------------------------------------------
# 8. stroke_width_normalize
# ---------------------------------------------------------------------------
def stroke_width_normalize_impl(excalidraw_path: str,
                                  out_path: str,
                                  buckets: list[float] | None,
                                  tolerance: float) -> dict[str, Any]:
    """Snap every element's ``strokeWidth`` to the nearest allowed bucket.

    If ``buckets`` is None, derive buckets by k-means-ish clustering of
    the current widths: the top-3 modes.
    """
    doc, err = _load_doc(excalidraw_path)
    if err:
        return {"error": err}
    elements = doc.get("elements", [])

    widths = [float(el.get("strokeWidth", 1))
                for el in elements
                if "strokeWidth" in el]
    if not widths:
        _write_doc(out_path, doc)
        return {"out_path": str(pathlib.Path(out_path).expanduser()),
                "modified": 0, "buckets": []}

    # Auto-derive 1-3 buckets by histogram mode extraction
    derived_buckets: list[float] = []
    if buckets is None or not buckets:
        # Round widths to 0.5 and count
        rounded = [round(w * 2.0) / 2.0 for w in widths]
        hist: dict[float, int] = {}
        for r in rounded:
            hist[r] = hist.get(r, 0) + 1
        sorted_modes = sorted(hist.items(), key=lambda kv: -kv[1])
        for val, _ in sorted_modes[:3]:
            derived_buckets.append(val)
        derived_buckets.sort()
    else:
        derived_buckets = sorted(buckets)

    def _snap(w: float) -> float:
        if not derived_buckets:
            return w
        best = min(derived_buckets, key=lambda b: abs(b - w))
        if abs(best - w) <= tolerance:
            return best
        return w

    modified = 0
    pre_widths: list[float] = []
    post_widths: list[float] = []
    for el in elements:
        if "strokeWidth" not in el:
            continue
        original = float(el["strokeWidth"])
        new_w = _snap(original)
        pre_widths.append(original)
        post_widths.append(new_w)
        if abs(new_w - original) > 1e-6:
            el["strokeWidth"] = int(new_w) if new_w == int(new_w) else new_w
            modified += 1

    _write_doc(out_path, doc)
    return {
        "out_path": str(pathlib.Path(out_path).expanduser()),
        "modified": modified,
        "buckets": derived_buckets,
        "tolerance": tolerance,
        "unique_widths_before": sorted(set(pre_widths)),
        "unique_widths_after": sorted(set(post_widths)),
    }
