"""Export Excalidraw JSON to publication-friendly formats (v0.7.0).

- ``excalidraw_to_svg_impl``   : standard SVG. Suitable for LaTeX
                                  ``\\includegraphics`` via pdflatex +
                                  svglib/inkscape, and for direct
                                  embedding via ``\\includesvg`` with
                                  the ``svg`` package.
- ``excalidraw_to_tikz_impl``  : TikZ ``\\draw`` commands. Directly
                                  ``\\input``-able into any LaTeX paper
                                  without a raster intermediate.

Only the common Excalidraw element types are supported (rectangle,
ellipse, line, arrow, text, freedraw). Rough.js "sketchy" rendering is
approximated as solid strokes — the focus is paper-ready output, not
exact visual reproduction of the Excalidraw editor.
"""
from __future__ import annotations

import json
import math
import pathlib
from typing import Any
from xml.sax.saxutils import escape


def _load_doc(path: str) -> tuple[dict | None, str | None]:
    p = pathlib.Path(path).expanduser()
    if not p.exists():
        return None, f"file not found: {p}"
    try:
        return json.loads(p.read_text(encoding="utf-8")), None
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        return None, f"parse error: {exc}"


def _canvas_bounds(elements: list[dict]) -> tuple[float, float, float, float]:
    """Return (x_min, y_min, x_max, y_max) across all element bboxes."""
    xs: list[float] = []
    ys: list[float] = []
    x2s: list[float] = []
    y2s: list[float] = []
    for el in elements:
        if el.get("isDeleted"):
            continue
        x = el.get("x", 0.0); y = el.get("y", 0.0)
        w = el.get("width", 0.0); h = el.get("height", 0.0)
        xs.append(x); ys.append(y)
        x2s.append(x + w); y2s.append(y + h)
    if not xs:
        return 0.0, 0.0, 100.0, 100.0
    return min(xs), min(ys), max(x2s), max(y2s)


# ---------------------------------------------------------------------------
# 6. excalidraw_to_svg
# ---------------------------------------------------------------------------
def excalidraw_to_svg_impl(excalidraw_path: str,
                             out_path: str,
                             margin: float,
                             bg_override: str) -> dict[str, Any]:
    doc, err = _load_doc(excalidraw_path)
    if err:
        return {"error": err}
    elements = doc.get("elements", [])
    xmin, ymin, xmax, ymax = _canvas_bounds(elements)
    width = xmax - xmin + 2 * margin
    height = ymax - ymin + 2 * margin
    tx = -xmin + margin
    ty = -ymin + margin

    bg = bg_override or (doc.get("appState") or {}).get(
        "viewBackgroundColor", "transparent",
    )

    lines_out: list[str] = []
    lines_out.append(
        f'<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'viewBox="0 0 {width:.2f} {height:.2f}" '
        f'width="{width:.2f}" height="{height:.2f}">'
    )
    if bg and bg != "transparent":
        lines_out.append(
            f'<rect x="0" y="0" width="{width:.2f}" height="{height:.2f}" '
            f'fill="{bg}"/>'
        )

    def _stroke_fill_attrs(el: dict) -> str:
        stroke = el.get("strokeColor", "#1e1e1e")
        fill = el.get("backgroundColor", "transparent")
        if not fill or fill == "transparent":
            fill = "none"
        sw = float(el.get("strokeWidth", 1) or 0)
        opacity = float(el.get("opacity", 100)) / 100.0
        return (f'stroke="{stroke}" fill="{fill}" '
                f'stroke-width="{sw}" opacity="{opacity:.3f}"')

    exported = 0
    skipped: dict[str, int] = {}

    for el in elements:
        if el.get("isDeleted"):
            continue
        kind = el.get("type")
        x = el.get("x", 0.0) + tx
        y = el.get("y", 0.0) + ty
        w = el.get("width", 0.0)
        h = el.get("height", 0.0)
        angle = el.get("angle", 0.0)
        attrs = _stroke_fill_attrs(el)
        transform = ""
        if abs(angle) > 1e-6:
            cx = x + w / 2.0; cy = y + h / 2.0
            deg = math.degrees(angle)
            transform = f' transform="rotate({deg:.2f} {cx:.2f} {cy:.2f})"'
        if kind == "rectangle":
            lines_out.append(
                f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" '
                f'height="{h:.2f}" {attrs}{transform}/>'
            )
            exported += 1
        elif kind == "ellipse":
            cx = x + w / 2.0; cy = y + h / 2.0
            rx = w / 2.0; ry = h / 2.0
            lines_out.append(
                f'<ellipse cx="{cx:.2f}" cy="{cy:.2f}" '
                f'rx="{rx:.2f}" ry="{ry:.2f}" {attrs}{transform}/>'
            )
            exported += 1
        elif kind in ("line", "arrow", "freedraw"):
            pts = el.get("points") or []
            if not pts:
                skipped[kind] = skipped.get(kind, 0) + 1
                continue
            abs_pts = [(x + p[0], y + p[1]) for p in pts]
            pts_str = " ".join(f"{p[0]:.2f},{p[1]:.2f}" for p in abs_pts)
            closed = (len(abs_pts) >= 3
                        and abs(abs_pts[0][0] - abs_pts[-1][0]) < 1e-3
                        and abs(abs_pts[0][1] - abs_pts[-1][1]) < 1e-3)
            if closed and kind == "line":
                lines_out.append(
                    f'<polygon points="{pts_str}" {attrs}{transform}/>'
                )
            elif kind == "arrow":
                # Define a simple arrow marker on first use
                if 'id="arrowhead"' not in "\n".join(lines_out):
                    lines_out.insert(1,
                        '<defs><marker id="arrowhead" markerWidth="10" '
                        'markerHeight="7" refX="9" refY="3.5" orient="auto">'
                        '<polygon points="0 0, 10 3.5, 0 7" fill="context-stroke"/>'
                        '</marker></defs>'
                    )
                stroke = el.get("strokeColor", "#1e1e1e")
                sw = float(el.get("strokeWidth", 1) or 0)
                opacity = float(el.get("opacity", 100)) / 100.0
                lines_out.append(
                    f'<polyline points="{pts_str}" stroke="{stroke}" '
                    f'fill="none" stroke-width="{sw}" opacity="{opacity:.3f}" '
                    f'marker-end="url(#arrowhead)"{transform}/>'
                )
            else:
                stroke = el.get("strokeColor", "#1e1e1e")
                sw = float(el.get("strokeWidth", 1) or 0)
                opacity = float(el.get("opacity", 100)) / 100.0
                lines_out.append(
                    f'<polyline points="{pts_str}" stroke="{stroke}" '
                    f'fill="none" stroke-width="{sw}" '
                    f'opacity="{opacity:.3f}"{transform}/>'
                )
            exported += 1
        elif kind == "text":
            text = escape(str(el.get("text", "")))
            if not text:
                skipped[kind] = skipped.get(kind, 0) + 1
                continue
            fs = el.get("fontSize", max(12, int(h * 0.8)))
            stroke = el.get("strokeColor", "#1e1e1e")
            opacity = float(el.get("opacity", 100)) / 100.0
            lines_out.append(
                f'<text x="{x:.2f}" y="{y + fs:.2f}" '
                f'font-size="{fs}" fill="{stroke}" '
                f'opacity="{opacity:.3f}"{transform}>{text}</text>'
            )
            exported += 1
        else:
            skipped[kind] = skipped.get(kind, 0) + 1

    lines_out.append("</svg>")

    outp = pathlib.Path(out_path).expanduser()
    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_text("\n".join(lines_out), encoding="utf-8")
    return {
        "out_path": str(outp),
        "viewbox": [round(width, 2), round(height, 2)],
        "exported_elements": exported,
        "skipped_by_type": skipped,
    }


# ---------------------------------------------------------------------------
# 7. excalidraw_to_tikz
# ---------------------------------------------------------------------------
def excalidraw_to_tikz_impl(excalidraw_path: str,
                              out_path: str,
                              scale: float,
                              y_flip: bool) -> dict[str, Any]:
    doc, err = _load_doc(excalidraw_path)
    if err:
        return {"error": err}
    elements = doc.get("elements", [])
    xmin, ymin, xmax, ymax = _canvas_bounds(elements)
    height = ymax - ymin

    def _pt(x: float, y: float) -> tuple[float, float]:
        # Normalise to xmin/ymin origin, optionally flip Y so the top of the
        # canvas becomes the top of the TikZ page (LaTeX's Y axis points up).
        xr = (x - xmin) * scale
        if y_flip:
            yr = (height - (y - ymin)) * scale
        else:
            yr = (y - ymin) * scale
        return xr, yr

    out_lines: list[str] = []
    out_lines.append("% Generated by mcp-server-document:diagram_excalidraw_to_tikz")
    out_lines.append("% Wrap with \\begin{tikzpicture} ... \\end{tikzpicture}")
    out_lines.append("\\begin{tikzpicture}")

    exported = 0
    skipped: dict[str, int] = {}

    for el in elements:
        if el.get("isDeleted"):
            continue
        kind = el.get("type")
        x = el.get("x", 0.0); y = el.get("y", 0.0)
        w = el.get("width", 0.0); h = el.get("height", 0.0)
        stroke = el.get("strokeColor", "#1e1e1e")
        fill = el.get("backgroundColor", "transparent")
        sw = float(el.get("strokeWidth", 1) or 0)
        draw_opts = [f'draw={{rgb,255:red,{int(stroke[1:3],16)};'
                      f'green,{int(stroke[3:5],16)};blue,{int(stroke[5:7],16)}}}']
        if fill and fill != "transparent":
            draw_opts.append(
                f'fill={{rgb,255:red,{int(fill[1:3],16)};'
                f'green,{int(fill[3:5],16)};blue,{int(fill[5:7],16)}}}'
            )
        if sw and sw != 1:
            draw_opts.append(f'line width={sw:.1f}pt')
        opts = ",".join(draw_opts)

        if kind == "rectangle":
            p1 = _pt(x, y + h); p2 = _pt(x + w, y)  # TikZ lower-left, upper-right
            out_lines.append(
                f'  \\draw[{opts}] ({p1[0]:.2f},{p1[1]:.2f}) '
                f'rectangle ({p2[0]:.2f},{p2[1]:.2f});'
            )
            exported += 1
        elif kind == "ellipse":
            cx, cy = x + w / 2.0, y + h / 2.0
            pc = _pt(cx, cy)
            rx = (w / 2.0) * scale; ry = (h / 2.0) * scale
            out_lines.append(
                f'  \\draw[{opts}] ({pc[0]:.2f},{pc[1]:.2f}) '
                f'ellipse ({rx:.2f} and {ry:.2f});'
            )
            exported += 1
        elif kind in ("line", "arrow", "freedraw"):
            pts = el.get("points") or []
            if not pts:
                skipped[kind] = skipped.get(kind, 0) + 1
                continue
            abs_pts = [_pt(x + p[0], y + p[1]) for p in pts]
            path_str = " -- ".join(f"({p[0]:.2f},{p[1]:.2f})" for p in abs_pts)
            arrow_mark = "->" if kind == "arrow" else ""
            full_opts = opts + (f",{arrow_mark}" if arrow_mark else "")
            out_lines.append(f'  \\draw[{full_opts}] {path_str};')
            exported += 1
        elif kind == "text":
            text = str(el.get("text", "")).replace("\\", "\\textbackslash{}") \
                .replace("_", "\\_").replace("%", "\\%") \
                .replace("&", "\\&").replace("#", "\\#")
            if not text.strip():
                skipped[kind] = skipped.get(kind, 0) + 1
                continue
            cx, cy = x + w / 2.0, y + h / 2.0
            pc = _pt(cx, cy)
            fs = el.get("fontSize", 14)
            out_lines.append(
                f'  \\node[anchor=center,font=\\fontsize{{{fs}}}{{'
                f'{int(fs * 1.2)}}}\\selectfont] at '
                f'({pc[0]:.2f},{pc[1]:.2f}) {{{text}}};'
            )
            exported += 1
        else:
            skipped[kind] = skipped.get(kind, 0) + 1

    out_lines.append("\\end{tikzpicture}")

    outp = pathlib.Path(out_path).expanduser()
    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_text("\n".join(out_lines), encoding="utf-8")

    return {
        "out_path": str(outp),
        "canvas_size_pt": [round((xmax - xmin) * scale, 2),
                            round((ymax - ymin) * scale, 2)],
        "exported_elements": exported,
        "skipped_by_type": skipped,
        "scale": scale,
        "y_flip": y_flip,
    }
