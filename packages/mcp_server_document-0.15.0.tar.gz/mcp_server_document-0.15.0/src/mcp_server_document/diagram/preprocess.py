"""OCR-style raster preprocessing + structural-shape detection (v0.7.0).

Three tools:

- ``preprocess_impl``        : deskew + bilateral denoise + CLAHE + adaptive
                                binarization. All OCR systems run this
                                kind of pipeline before recognition;
                                tracers should too.
- ``detect_shapes_impl``     : detect axis-aligned rectangles + straight
                                lines + arrows + circles → emit an
                                Excalidraw doc whose elements use the
                                *actual* primitive types (rectangle,
                                line, arrow, ellipse) instead of generic
                                polygons.
- ``detect_text_regions_impl``: MSER candidate regions + DBSCAN
                                clustering + stroke-width filter to
                                identify text regions at word and line
                                level (richer than the single MSER pass
                                in the old compose_layers).
"""
from __future__ import annotations

import json
import math
import pathlib
import uuid
from typing import Any


def _ensure_np():
    try:
        import numpy as np  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "numpy required. pip install mcp-server-document[diagram]"
        ) from exc
    return np


def _ensure_cv2():
    try:
        import cv2  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "opencv-python required. pip install mcp-server-document[diagram]"
        ) from exc
    return cv2


def _new_eid() -> str:
    return uuid.uuid4().hex[:16]


# ---------------------------------------------------------------------------
# 1. preprocess — OCR-style raster cleanup
# ---------------------------------------------------------------------------
def _detect_skew_angle(gray, max_angle_deg: float = 15.0) -> float:
    """Return an estimated skew angle (degrees) using Hough line voting."""
    np = _ensure_np()
    cv2 = _ensure_cv2()
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLines(edges, 1, np.pi / 180, threshold=100)
    if lines is None:
        return 0.0
    angles: list[float] = []
    for rho_theta in lines[:80]:
        _, theta = rho_theta[0]
        # Convert to angle relative to horizontal / vertical
        deg = math.degrees(theta) - 90.0
        # Normalise to (-45, 45]
        while deg <= -45.0:
            deg += 90.0
        while deg > 45.0:
            deg -= 90.0
        if abs(deg) <= max_angle_deg:
            angles.append(deg)
    if not angles:
        return 0.0
    # Median is robust to outliers.
    return float(np.median(angles))


def preprocess_impl(image_path: str,
                      out_path: str,
                      deskew: bool,
                      denoise: bool,
                      enhance_contrast: bool,
                      binarize: str,
                      max_skew_deg: float) -> dict[str, Any]:
    """Run OCR-style preprocessing and save the result."""
    np = _ensure_np()
    cv2 = _ensure_cv2()

    src = pathlib.Path(image_path).expanduser()
    if not src.exists():
        return {"error": f"image not found: {src}"}
    img = cv2.imdecode(
        np.fromfile(str(src), dtype=np.uint8), cv2.IMREAD_COLOR,
    )
    if img is None:
        return {"error": f"failed to decode: {src}"}

    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    skew_angle = 0.0
    if deskew:
        skew_angle = _detect_skew_angle(gray, max_angle_deg=max_skew_deg)
        if abs(skew_angle) > 0.1:
            M = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), skew_angle, 1.0)
            img = cv2.warpAffine(img, M, (w, h),
                                   flags=cv2.INTER_CUBIC,
                                   borderMode=cv2.BORDER_REPLICATE)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    if denoise:
        img = cv2.bilateralFilter(img, d=9, sigmaColor=75, sigmaSpace=75)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    if enhance_contrast:
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        gray_eq = clahe.apply(gray)
        # Re-merge back into colour by scaling
        ratio = (gray_eq.astype(np.float32) + 1.0) / (gray.astype(np.float32) + 1.0)
        img_enh = (img.astype(np.float32)
                    * np.dstack([ratio, ratio, ratio])).clip(0, 255)
        img = img_enh.astype(np.uint8)
        gray = gray_eq

    mask_out = None
    binar_method = binarize.lower().strip()
    if binar_method in ("otsu", "adaptive", "sauvola"):
        if binar_method == "otsu":
            _, mask_out = cv2.threshold(
                gray, 0, 255,
                cv2.THRESH_BINARY + cv2.THRESH_OTSU,
            )
        elif binar_method == "adaptive":
            mask_out = cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY, blockSize=25, C=10,
            )
        elif binar_method == "sauvola":
            try:
                from skimage.filters import threshold_sauvola  # type: ignore
            except ImportError:
                return {"error": "scikit-image required for Sauvola. "
                                  "pip install mcp-server-document[diagram]"}
            t = threshold_sauvola(gray, window_size=25, k=0.2)
            mask_out = ((gray > t) * 255).astype(np.uint8)

    outp = pathlib.Path(out_path).expanduser()
    outp.parent.mkdir(parents=True, exist_ok=True)
    if mask_out is not None and outp.suffix.lower() != ".png":
        # Force PNG for binary masks
        outp = outp.with_suffix(".png")
    # Write using cv2.imencode to support non-ASCII paths
    if mask_out is not None:
        success, buf = cv2.imencode(".png", mask_out)
    else:
        success, buf = cv2.imencode(".png", img)
    if not success:
        return {"error": "imencode failed"}
    outp.write_bytes(buf.tobytes())

    return {
        "out_path": str(outp),
        "image_size": [int(w), int(h)],
        "skew_angle_deg": round(float(skew_angle), 3),
        "deskew_applied": deskew and abs(skew_angle) > 0.1,
        "denoise_applied": bool(denoise),
        "enhance_contrast_applied": bool(enhance_contrast),
        "binarize_method": binar_method or "none",
        "output_is_binary": mask_out is not None,
    }


# ---------------------------------------------------------------------------
# 2. detect_shapes — axis-aligned rectangles + lines + arrows + circles
# ---------------------------------------------------------------------------
def _is_axis_aligned_rect(poly, w: int, h: int,
                             angle_tol_deg: float = 8.0,
                             len_tol_frac: float = 0.12) -> bool:
    """Return True iff the 4-vertex polygon is ~axis-aligned and ~rectangular."""
    if len(poly) != 4:
        return False
    pts = [(int(p[0][0]), int(p[0][1])) for p in poly]
    # Check that edges are roughly horizontal/vertical
    tol_rad = math.radians(angle_tol_deg)
    for i in range(4):
        x1, y1 = pts[i]; x2, y2 = pts[(i + 1) % 4]
        dx, dy = x2 - x1, y2 - y1
        if dx == 0 and dy == 0:
            return False
        angle = math.atan2(abs(dy), abs(dx))
        # Axis-aligned means either angle≈0 (horizontal) or angle≈π/2 (vertical)
        if not (angle < tol_rad or abs(angle - math.pi / 2) < tol_rad):
            return False
    # Opposite side length equality
    def _d(p, q):
        return math.hypot(p[0] - q[0], p[1] - q[1])
    e01 = _d(pts[0], pts[1])
    e23 = _d(pts[2], pts[3])
    e12 = _d(pts[1], pts[2])
    e30 = _d(pts[3], pts[0])
    if max(e01, e23) == 0 or max(e12, e30) == 0:
        return False
    if abs(e01 - e23) / max(e01, e23) > len_tol_frac:
        return False
    if abs(e12 - e30) / max(e12, e30) > len_tol_frac:
        return False
    return True


def _detect_arrowhead(line_x1, line_y1, line_x2, line_y2,
                        mask, search_radius: int = 12) -> bool:
    """Heuristic: check for a triangle of mask pixels near (x2,y2)."""
    np = _ensure_np()
    x0, y0 = int(line_x2), int(line_y2)
    h, w = mask.shape
    xa = max(0, x0 - search_radius); xb = min(w, x0 + search_radius + 1)
    ya = max(0, y0 - search_radius); yb = min(h, y0 + search_radius + 1)
    patch = mask[ya:yb, xa:xb]
    if patch.size == 0:
        return False
    # Arrow has an increased pixel density on ONE side of the line only.
    # Simple test: centroid of patch foreground pixels is meaningfully offset
    # from the tip along a direction not parallel to line.
    ys_, xs_ = np.where(patch > 0)
    if len(xs_) < 4:
        return False
    cx = float(xs_.mean()) + xa
    cy = float(ys_.mean()) + ya
    # Displacement of centroid from tip
    dx_cen = cx - x0
    dy_cen = cy - y0
    # Line direction (tip pointing from start→end)
    lx, ly = x0 - line_x1, y0 - line_y1
    length = math.hypot(lx, ly) + 1e-6
    lx /= length; ly /= length
    # Component of centroid displacement along the line (should be negative
    # if arrowhead sits just before the tip, i.e. pointing back along line)
    along = dx_cen * lx + dy_cen * ly
    # Must be clearly behind the tip
    return along < -2.0


def detect_shapes_impl(image_path: str,
                         out_path: str,
                         min_rect_area: int,
                         hough_min_line_length: int,
                         hough_max_line_gap: int,
                         detect_arrows: bool,
                         detect_circles: bool,
                         bg_color: str) -> dict[str, Any]:
    """Detect structural primitives and emit an Excalidraw document."""
    np = _ensure_np()
    cv2 = _ensure_cv2()

    src = pathlib.Path(image_path).expanduser()
    if not src.exists():
        return {"error": f"image not found: {src}"}
    img = cv2.imdecode(
        np.fromfile(str(src), dtype=np.uint8), cv2.IMREAD_COLOR,
    )
    if img is None:
        return {"error": f"failed to decode: {src}"}

    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # Binarise (foreground = dark on light)
    _, mask = cv2.threshold(gray, 0, 255,
                              cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    rect_elements: list[dict] = []
    line_elements: list[dict] = []
    arrow_elements: list[dict] = []
    ellipse_elements: list[dict] = []

    # ---- Rectangles ---------------------------------------------------
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                     cv2.CHAIN_APPROX_SIMPLE)
    used_rect_mask = np.zeros_like(mask)
    for c in contours:
        area = cv2.contourArea(c)
        if area < min_rect_area:
            continue
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.03 * peri, True)
        if _is_axis_aligned_rect(approx, w, h):
            xs = [p[0][0] for p in approx]; ys = [p[0][1] for p in approx]
            rx, ry = int(min(xs)), int(min(ys))
            rw, rh = int(max(xs) - min(xs)), int(max(ys) - min(ys))
            rect_elements.append({
                "id": _new_eid(), "type": "rectangle",
                "x": float(rx), "y": float(ry),
                "width": float(rw), "height": float(rh),
                "angle": 0, "strokeColor": "#1e1e1e",
                "backgroundColor": "transparent",
                "fillStyle": "hachure", "strokeWidth": 2,
                "strokeStyle": "solid", "roughness": 0,
                "opacity": 100,
                "seed": 1, "version": 1, "versionNonce": 1,
                "isDeleted": False, "groupIds": ["rect"],
                "boundElements": None, "updatedAt": 0,
                "link": None, "locked": False,
            })
            cv2.drawContours(used_rect_mask, [c], -1, 255, -1)

    # ---- Lines / Arrows (on a mask with rectangles zeroed out) ----------
    line_mask = cv2.bitwise_and(mask, cv2.bitwise_not(used_rect_mask))
    edges = cv2.Canny(line_mask, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(
        edges, 1, np.pi / 180, threshold=50,
        minLineLength=hough_min_line_length,
        maxLineGap=hough_max_line_gap,
    )
    if lines is not None:
        for ln in lines[:300]:
            x1, y1, x2, y2 = ln[0]
            is_arrow = False
            if detect_arrows and _detect_arrowhead(x1, y1, x2, y2, mask):
                is_arrow = True
            elif detect_arrows and _detect_arrowhead(x2, y2, x1, y1, mask):
                # Arrow points in the other direction — swap endpoints
                x1, y1, x2, y2 = x2, y2, x1, y1
                is_arrow = True
            mx, my = int(min(x1, x2)), int(min(y1, y2))
            rel = [[float(x1 - mx), float(y1 - my)],
                     [float(x2 - mx), float(y2 - my)]]
            el = {
                "id": _new_eid(),
                "type": "arrow" if is_arrow else "line",
                "x": float(mx), "y": float(my),
                "width": float(abs(x2 - x1)),
                "height": float(abs(y2 - y1)),
                "angle": 0, "strokeColor": "#1e1e1e",
                "backgroundColor": "transparent",
                "fillStyle": "solid", "strokeWidth": 2,
                "strokeStyle": "solid", "roughness": 0,
                "opacity": 100, "points": rel,
                "seed": 1, "version": 1, "versionNonce": 1,
                "isDeleted": False,
                "groupIds": ["arrow"] if is_arrow else ["line"],
                "boundElements": None, "updatedAt": 0,
                "link": None, "locked": False,
                "startBinding": None, "endBinding": None,
                "startArrowhead": None,
                "endArrowhead": "arrow" if is_arrow else None,
                "lastCommittedPoint": None,
            }
            if is_arrow:
                arrow_elements.append(el)
            else:
                line_elements.append(el)

    # ---- Circles ------------------------------------------------------
    if detect_circles:
        circles = cv2.HoughCircles(
            gray, cv2.HOUGH_GRADIENT, dp=1.2, minDist=25,
            param1=80, param2=30, minRadius=6,
            maxRadius=int(min(w, h) * 0.45),
        )
        if circles is not None:
            for c in circles[0][:100]:
                cx, cy, r = int(c[0]), int(c[1]), int(c[2])
                ellipse_elements.append({
                    "id": _new_eid(), "type": "ellipse",
                    "x": float(cx - r), "y": float(cy - r),
                    "width": float(2 * r), "height": float(2 * r),
                    "angle": 0, "strokeColor": "#1e1e1e",
                    "backgroundColor": "transparent",
                    "fillStyle": "hachure", "strokeWidth": 2,
                    "strokeStyle": "solid", "roughness": 0,
                    "opacity": 100,
                    "seed": 1, "version": 1, "versionNonce": 1,
                    "isDeleted": False, "groupIds": ["circle"],
                    "boundElements": None, "updatedAt": 0,
                    "link": None, "locked": False,
                })

    elements = (rect_elements + line_elements
                  + arrow_elements + ellipse_elements)
    doc = {
        "type": "excalidraw", "version": 2,
        "source": "mcp-server-document:diagram_detect_shapes",
        "elements": elements,
        "appState": {"viewBackgroundColor": bg_color, "gridSize": None},
        "files": {},
    }
    outp = pathlib.Path(out_path).expanduser()
    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")

    return {
        "out_path": str(outp),
        "image_size": [int(w), int(h)],
        "counts": {
            "rectangle": len(rect_elements),
            "line": len(line_elements),
            "arrow": len(arrow_elements),
            "ellipse": len(ellipse_elements),
        },
        "total_elements": len(elements),
    }


# ---------------------------------------------------------------------------
# 3. detect_text_regions — MSER + DBSCAN
# ---------------------------------------------------------------------------
def _simple_dbscan(points: list[tuple[float, float]],
                     eps: float,
                     min_samples: int) -> list[int]:
    """Tiny DBSCAN implementation (no sklearn). Returns per-point cluster id
    (or ``-1`` for noise)."""
    n = len(points)
    labels = [-1] * n
    visited = [False] * n
    cluster = 0

    def _neighbors(i: int) -> list[int]:
        xi, yi = points[i]
        return [j for j in range(n)
                 if (points[j][0] - xi) ** 2 + (points[j][1] - yi) ** 2
                     <= eps * eps]

    for i in range(n):
        if visited[i]:
            continue
        visited[i] = True
        nbrs = _neighbors(i)
        if len(nbrs) < min_samples:
            labels[i] = -1
            continue
        labels[i] = cluster
        queue = list(nbrs)
        while queue:
            j = queue.pop(0)
            if not visited[j]:
                visited[j] = True
                nbrs_j = _neighbors(j)
                if len(nbrs_j) >= min_samples:
                    queue.extend(nbrs_j)
            if labels[j] == -1:
                labels[j] = cluster
        cluster += 1
    return labels


def detect_text_regions_impl(image_path: str,
                               out_json: str,
                               min_area: int,
                               max_area: int,
                               dbscan_eps_frac: float,
                               dbscan_min_samples: int) -> dict[str, Any]:
    """Run MSER + DBSCAN to group text candidates at word/line level."""
    np = _ensure_np()
    cv2 = _ensure_cv2()

    src = pathlib.Path(image_path).expanduser()
    if not src.exists():
        return {"error": f"image not found: {src}"}
    img = cv2.imdecode(
        np.fromfile(str(src), dtype=np.uint8), cv2.IMREAD_COLOR,
    )
    if img is None:
        return {"error": f"failed to decode: {src}"}
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape

    try:
        mser = cv2.MSER_create(min_area=min_area, max_area=max_area)
    except AttributeError:
        mser = cv2.MSER_create()
        mser.setMinArea(min_area)
        mser.setMaxArea(max_area)

    regions, bboxes = mser.detectRegions(gray)

    # Filter by aspect ratio and uniformity
    candidates = []
    for (x, y, bw, bh) in bboxes:
        if bh == 0:
            continue
        aspect = bw / bh
        if aspect < 0.1 or aspect > 12.0:
            continue
        candidates.append((int(x), int(y), int(bw), int(bh)))

    # Cluster at word level by bbox centres with DBSCAN
    centres = [(x + bw / 2.0, y + bh / 2.0) for (x, y, bw, bh) in candidates]
    eps_word = max(5.0, min(w, h) * dbscan_eps_frac)
    word_labels = _simple_dbscan(centres, eps=eps_word,
                                   min_samples=dbscan_min_samples)

    words: list[dict] = []
    by_cluster: dict[int, list[tuple[int, int, int, int]]] = {}
    for cand, lbl in zip(candidates, word_labels):
        if lbl == -1:
            continue
        by_cluster.setdefault(lbl, []).append(cand)
    for cluster_id, members in by_cluster.items():
        xs = [m[0] for m in members]
        ys = [m[1] for m in members]
        x2s = [m[0] + m[2] for m in members]
        y2s = [m[1] + m[3] for m in members]
        words.append({
            "cluster_id": int(cluster_id),
            "bbox": [min(xs), min(ys),
                     max(x2s) - min(xs), max(y2s) - min(ys)],
            "member_count": len(members),
        })

    # Cluster at line level: cluster word centres by Y with a wide X tolerance
    line_centres = [(word["bbox"][1] + word["bbox"][3] / 2.0,
                     word["bbox"][0] + word["bbox"][2] / 2.0)
                     for word in words]
    eps_line = max(5.0, min(w, h) * dbscan_eps_frac * 1.6)
    line_labels = _simple_dbscan(
        [(0.0, pt[0]) for pt in line_centres],
        eps=eps_line, min_samples=max(1, dbscan_min_samples - 1),
    )
    lines: dict[int, list[int]] = {}
    for idx, lbl in enumerate(line_labels):
        if lbl == -1:
            continue
        lines.setdefault(lbl, []).append(idx)
    line_bboxes = []
    for lbl, word_indices in lines.items():
        xs = []; ys = []; x2s = []; y2s = []
        for wi in word_indices:
            bx, by, bw, bh = words[wi]["bbox"]
            xs.append(bx); ys.append(by)
            x2s.append(bx + bw); y2s.append(by + bh)
        line_bboxes.append({
            "cluster_id": int(lbl),
            "bbox": [min(xs), min(ys),
                     max(x2s) - min(xs), max(y2s) - min(ys)],
            "word_count": len(word_indices),
        })

    result = {
        "image_size": [int(w), int(h)],
        "mser_candidates": len(candidates),
        "words": words,
        "lines": line_bboxes,
        "word_count": len(words),
        "line_count": len(line_bboxes),
    }
    if out_json:
        outp = pathlib.Path(out_json).expanduser()
        outp.parent.mkdir(parents=True, exist_ok=True)
        outp.write_text(json.dumps(result, ensure_ascii=False, indent=2),
                         encoding="utf-8")
        result["out_json"] = str(outp)
    return result
