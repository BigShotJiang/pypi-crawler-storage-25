"""OCR-inspired per-component classification + auto-compose pipeline.

v0.6.0 replaces the **fixed strategy-per-layer** design of the original
compose_layers with a **per-connected-component** classifier that picks
the right tracing strategy for each blob individually.

Inspired by OCR preprocessing: instead of treating a layer as a single
unit, we analyze each connected component's geometric features (area,
aspect, density, stroke width via distance transform, circularity,
elongation) and assign one of the labels:

- ``text_like``  — small, clustered, uniform stroke width, MSER/OCR hit
- ``line``       — elongated, low density, thin stroke
- ``circle``     — high circularity, moderate density
- ``fill``       — large, dense, polygon-ish
- ``noise``      — below min_area
- ``other``      — mixed / ambiguous

Downstream tools (``compose_auto``) use these labels to pick a
per-component strategy: text_like → OCR-filled text element (or stub),
line → skeleton polyline with RDP+Chaikin, circle → ellipse, fill →
closed polygon.
"""
from __future__ import annotations

import json
import math
import pathlib
import uuid
from typing import Any

from . import exact_trace as _xt


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------
def _ensure_np():
    try:
        import numpy as np  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "numpy required. pip install mcp-server-document[diagram]"
        ) from exc
    return np


def _ensure_cv2():
    try:
        import cv2  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "opencv-python required. pip install mcp-server-document[diagram]"
        ) from exc
    return cv2


def _new_eid() -> str:
    return uuid.uuid4().hex[:16]


def _load_image_gray_or_mask(path: pathlib.Path):
    """Load image as a foreground mask (255 = FG, 0 = BG).

    For colour images with a light background, we Otsu-threshold on the
    L channel. For images that are already binary masks, we preserve them.
    """
    np = _ensure_np()
    cv2 = _ensure_cv2()

    raw = cv2.imdecode(np.fromfile(str(path), dtype=np.uint8), cv2.IMREAD_UNCHANGED)
    if raw is None:
        return None, None
    if raw.ndim == 2:
        mask = raw.copy()
        color = cv2.cvtColor(raw, cv2.COLOR_GRAY2BGR)
    else:
        color = raw if raw.shape[2] == 3 else cv2.cvtColor(raw, cv2.COLOR_BGRA2BGR)
        gray = cv2.cvtColor(color, cv2.COLOR_BGR2GRAY)
        # Heuristic: if the border average is bright (>180), the FG is dark
        # on a light BG; otherwise invert.
        border = np.concatenate([
            gray[0, :], gray[-1, :], gray[:, 0], gray[:, -1],
        ])
        bright_bg = float(np.mean(border)) > 180.0
        if bright_bg:
            _, mask = cv2.threshold(
                gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU,
            )
        else:
            _, mask = cv2.threshold(
                gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU,
            )
    return mask, color


# ---------------------------------------------------------------------------
# Per-CC feature extraction and classification
# ---------------------------------------------------------------------------
def _feature_vector_for_cc(cc_mask, bbox: tuple[int, int, int, int],
                             area: int) -> dict[str, float]:
    """Compute {area, aspect, density, circularity, elongation, stroke_width,
    perimeter, solidity} for a single component mask (bool/0-255 array).
    """
    np = _ensure_np()
    cv2 = _ensure_cv2()

    x, y, w, h = bbox
    aspect = w / h if h > 0 else 1.0
    density = area / (w * h) if w * h > 0 else 0.0
    elongation = (max(w, h) / min(w, h)) if min(w, h) > 0 else 1.0

    # Perimeter via contour
    mask_u8 = (cc_mask > 0).astype(np.uint8) * 255
    contours, _ = cv2.findContours(mask_u8, cv2.RETR_EXTERNAL,
                                     cv2.CHAIN_APPROX_NONE)
    perimeter = 0.0
    if contours:
        perimeter = float(max(cv2.arcLength(c, True) for c in contours))

    circularity = 0.0
    if perimeter > 0:
        circularity = 4.0 * math.pi * area / (perimeter * perimeter)

    # Solidity via convex hull
    solidity = 1.0
    if contours:
        c = max(contours, key=cv2.contourArea)
        hull_area = cv2.contourArea(cv2.convexHull(c))
        if hull_area > 0:
            solidity = float(area / hull_area)
            solidity = min(1.0, solidity)

    # Stroke width via distance transform on the CC mask
    dist = cv2.distanceTransform(mask_u8, cv2.DIST_L2, 3)
    stroke_width = 2.0 * float(np.mean(dist[mask_u8 > 0])) if area > 0 else 0.0

    return {
        "area": int(area),
        "bbox": [int(x), int(y), int(w), int(h)],
        "aspect": round(float(aspect), 3),
        "density": round(float(density), 3),
        "elongation": round(float(elongation), 3),
        "perimeter": round(perimeter, 1),
        "circularity": round(circularity, 3),
        "solidity": round(solidity, 3),
        "stroke_width": round(stroke_width, 2),
    }


def _classify_feature(feat: dict[str, float], min_area: int) -> str:
    """Rule-based classifier that maps features → label."""
    area = feat["area"]
    aspect = feat["aspect"]
    density = feat["density"]
    circularity = feat["circularity"]
    elongation = feat["elongation"]
    solidity = feat["solidity"]
    stroke_width = feat["stroke_width"]

    if area < min_area:
        return "noise"
    # Circle: nearly round + decent fill
    if circularity > 0.7 and density > 0.5:
        return "circle"
    # Line: elongated + low density + thin stroke
    if elongation > 5 and density < 0.45 and stroke_width < 6.0:
        return "line"
    # Text-like: small, ~square aspect, uniform stroke, moderate density
    if (20 <= area <= 3000 and 0.15 <= aspect <= 6.0
            and stroke_width < 10.0 and density > 0.15):
        return "text_like"
    # Fill: relaxed — catches filled letters with concave parts (C/E/A)
    # whose solidity is too low for the original solidity>0.6 rule, and
    # thick half-shapes (e.g. the half-sphere of a brain logo).
    if area > 200 and density > 0.3:
        return "fill"
    if area > 400 and solidity > 0.85:
        return "fill"
    # Fallback
    return "other"


def _enhance_with_ocr(components, image_bgr, lang: str):
    """Optionally refine text_like labels using OCR word confidences.

    For each component labelled ``text_like`` or ``other``, look up the
    overlapping OCR block. If an OCR word is found with confidence >= 30,
    attach ``ocr_text`` / ``ocr_conf`` to the feature dict and upgrade
    label to ``text_like`` when needed.
    """
    try:
        import pytesseract  # type: ignore
        from PIL import Image  # type: ignore
    except ImportError:
        return components, {"ocr_available": False}

    try:
        pil_img = Image.fromarray(image_bgr[:, :, ::-1])  # BGR→RGB
        data = pytesseract.image_to_data(
            pil_img, lang=lang, output_type=pytesseract.Output.DICT,
        )
    except Exception:
        return components, {"ocr_available": False}

    blocks = []
    n = len(data.get("text", []))
    for i in range(n):
        txt = (data["text"][i] or "").strip()
        if not txt:
            continue
        try:
            conf = float(data["conf"][i])
        except (ValueError, TypeError):
            conf = -1.0
        if conf < 30.0:
            continue
        blocks.append({
            "text": txt, "conf": conf,
            "x": int(data["left"][i]), "y": int(data["top"][i]),
            "w": int(data["width"][i]), "h": int(data["height"][i]),
        })

    ocr_hits = 0
    for comp in components:
        x, y, w, h = comp["bbox"]
        # IoU with every OCR block
        best = None
        best_iou = 0.0
        for b in blocks:
            ix1 = max(x, b["x"]); iy1 = max(y, b["y"])
            ix2 = min(x + w, b["x"] + b["w"]); iy2 = min(y + h, b["y"] + b["h"])
            if ix2 <= ix1 or iy2 <= iy1:
                continue
            inter = (ix2 - ix1) * (iy2 - iy1)
            union = w * h + b["w"] * b["h"] - inter
            iou = inter / union if union > 0 else 0.0
            if iou > best_iou:
                best_iou = iou
                best = b
        if best is not None and best_iou >= 0.2:
            comp["ocr_text"] = best["text"]
            comp["ocr_conf"] = round(best["conf"], 1)
            if comp["label"] in ("other", "line", "noise"):
                comp["label"] = "text_like"
                comp["label_source"] = "ocr_override"
            ocr_hits += 1

    return components, {"ocr_available": True,
                        "ocr_blocks_found": len(blocks),
                        "ocr_attached_to_cc": ocr_hits}


def classify_components_impl(image_path: str,
                               mask_path: str,
                               min_area: int,
                               use_ocr: bool,
                               ocr_lang: str,
                               out_json: str) -> dict[str, Any]:
    """Main entry for :func:`diagram_classify_components`."""
    np = _ensure_np()
    cv2 = _ensure_cv2()

    src_p = pathlib.Path(image_path).expanduser()
    if not src_p.exists():
        return {"error": f"image not found: {src_p}"}

    if mask_path:
        mask_p = pathlib.Path(mask_path).expanduser()
        if not mask_p.exists():
            return {"error": f"mask not found: {mask_p}"}
        mask_img = cv2.imdecode(
            np.fromfile(str(mask_p), dtype=np.uint8), cv2.IMREAD_GRAYSCALE,
        )
        if mask_img is None:
            return {"error": f"failed to decode mask: {mask_p}"}
        mask = (mask_img > 127).astype(np.uint8) * 255
        image_bgr = cv2.imdecode(
            np.fromfile(str(src_p), dtype=np.uint8), cv2.IMREAD_COLOR,
        )
    else:
        mask, image_bgr = _load_image_gray_or_mask(src_p)
        if mask is None:
            return {"error": f"failed to decode: {src_p}"}

    num, labels, stats, _centroids = cv2.connectedComponentsWithStats(
        mask, connectivity=8,
    )

    components = []
    # label 0 is background — skip
    for lbl in range(1, num):
        x = int(stats[lbl, cv2.CC_STAT_LEFT])
        y = int(stats[lbl, cv2.CC_STAT_TOP])
        w = int(stats[lbl, cv2.CC_STAT_WIDTH])
        h = int(stats[lbl, cv2.CC_STAT_HEIGHT])
        area = int(stats[lbl, cv2.CC_STAT_AREA])
        if area < max(1, min_area // 4):
            # hard cutoff for speed
            continue
        cc_mask = (labels[y:y+h, x:x+w] == lbl).astype(np.uint8) * 255
        feat = _feature_vector_for_cc(cc_mask, (x, y, w, h), area)
        feat["id"] = lbl
        feat["label"] = _classify_feature(feat, min_area=min_area)
        feat["label_source"] = "rule"
        components.append(feat)

    ocr_info = {"ocr_available": False}
    if use_ocr and image_bgr is not None:
        components, ocr_info = _enhance_with_ocr(
            components, image_bgr, lang=ocr_lang,
        )

    # Class histogram
    hist: dict[str, int] = {}
    for c in components:
        hist[c["label"]] = hist.get(c["label"], 0) + 1
    # Stroke-width distribution
    stroke_widths = [c["stroke_width"] for c in components
                      if c["label"] != "noise"
                      and not math.isnan(c["stroke_width"])
                      and not math.isinf(c["stroke_width"])]
    stroke_stats = None
    if len(stroke_widths) >= 2:
        arr = np.array(stroke_widths, dtype=np.float64)
        stroke_stats = {
            "mean": round(float(arr.mean()), 2),
            "std": round(float(arr.std()), 2),
            "min": round(float(arr.min()), 2),
            "max": round(float(arr.max()), 2),
            "p50": round(float(np.percentile(arr, 50)), 2),
        }
    elif len(stroke_widths) == 1:
        v = stroke_widths[0]
        stroke_stats = {"mean": v, "std": 0.0, "min": v, "max": v, "p50": v}

    result = {
        "image_path": str(src_p),
        "mask_path": str(mask_path) if mask_path else None,
        "total_cc": len(components),
        "class_histogram": hist,
        "stroke_width_stats": stroke_stats,
        "ocr": ocr_info,
        "components": components,
    }
    if out_json:
        outp = pathlib.Path(out_json).expanduser()
        outp.parent.mkdir(parents=True, exist_ok=True)
        outp.write_text(json.dumps(result, ensure_ascii=False, indent=2),
                          encoding="utf-8")
        result["out_json"] = str(outp)
    return result


# ---------------------------------------------------------------------------
# analyze_layers — read separate_layers output dir, recommend strategy
# ---------------------------------------------------------------------------
_STRATEGY_BY_DOMINANT = {
    "text_like": ("text_placeholder", "OCR-fill候補。compose_auto で OCR 結線推奨"),
    "line":      ("skeleton_lines", "細線レイヤ。Chaikin 平滑化候補"),
    "circle":    ("circles_fit", "Hough circle → ellipse 合成"),
    "fill":      ("fill_contour", "塗り潰し領域、polygon で合成"),
    "other":     ("outline", "混在、形状のみ保持"),
    "noise":     ("skip", "このレイヤは出力対象外推奨"),
}


def analyze_layers_impl(layers_dir: str,
                          min_area: int,
                          use_ocr: bool,
                          ocr_lang: str) -> dict[str, Any]:
    """Scan every layer PNG in ``layers_dir`` and recommend per-layer strategy."""
    lp = pathlib.Path(layers_dir).expanduser()
    if not lp.is_dir():
        return {"error": f"layers_dir not found: {lp}"}

    # Find PNGs that look like layer outputs (not the overview tile).
    layer_files = sorted(p for p in lp.glob("layer_*.png")
                          if "overview" not in p.name
                          and "quantized" not in p.name)
    if not layer_files:
        return {"error": f"no layer_*.png files in {lp}"}

    results = []
    for lf in layer_files:
        r = classify_components_impl(
            image_path=str(lf), mask_path="",
            min_area=min_area, use_ocr=use_ocr, ocr_lang=ocr_lang,
            out_json="",
        )
        if "error" in r:
            results.append({"filename": lf.name, "error": r["error"]})
            continue
        hist = r["class_histogram"]
        dominant = max(hist.items(), key=lambda kv: kv[1])[0] if hist else "noise"
        strategy, note = _STRATEGY_BY_DOMINANT.get(
            dominant, ("outline", "unknown"),
        )
        results.append({
            "filename": lf.name,
            "total_cc": r["total_cc"],
            "class_histogram": hist,
            "stroke_width_stats": r["stroke_width_stats"],
            "dominant_class": dominant,
            "recommended_strategy": strategy,
            "note": note,
        })

    # Overall summary
    all_hist: dict[str, int] = {}
    for r in results:
        for k, v in r.get("class_histogram", {}).items():
            all_hist[k] = all_hist.get(k, 0) + v

    return {
        "layers_dir": str(lp),
        "layers_analyzed": len(results),
        "aggregate_class_histogram": all_hist,
        "layers": results,
    }


# ---------------------------------------------------------------------------
# compose_auto — per-CC strategy picker
# ---------------------------------------------------------------------------
def _cc_to_polygon(cc_mask_u8, bbox, simplify_tolerance: float) -> list[tuple[int, int]] | None:
    """Extract an exterior polygon for one CC, optionally simplified."""
    np = _ensure_np()
    cv2 = _ensure_cv2()
    contours, _ = cv2.findContours(
        cc_mask_u8, cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_NONE if simplify_tolerance <= 0 else cv2.CHAIN_APPROX_TC89_L1,
    )
    if not contours:
        return None
    c = max(contours, key=cv2.contourArea)
    if simplify_tolerance > 0:
        c = cv2.approxPolyDP(c, simplify_tolerance, True)
    if len(c) < 3:
        return None
    return [(int(p[0][0]) + bbox[0], int(p[0][1]) + bbox[1]) for p in c]


def _cc_to_skeleton_polyline(cc_mask_u8, bbox) -> list[tuple[int, int]] | None:
    """Extract a single polyline by skeletonising the CC and walking the path."""
    try:
        from skimage.morphology import skeletonize  # type: ignore
    except ImportError:
        return None
    np = _ensure_np()
    bin_mask = cc_mask_u8 > 0
    if bin_mask.sum() < 3:
        return None
    skel = skeletonize(bin_mask)
    ys, xs = np.where(skel)
    if len(xs) < 2:
        return None
    # Sort skeleton points by a simple "nearest-neighbour walk" starting from
    # the topmost-leftmost pixel. Not optimal but good enough for thin
    # strokes that are mostly single-pixel paths.
    points = list(zip(xs.tolist(), ys.tolist()))
    # Start at the point with smallest x+y
    start_idx = min(range(len(points)), key=lambda i: points[i][0] + points[i][1])
    ordered = [points[start_idx]]
    remaining = set(range(len(points)))
    remaining.remove(start_idx)
    while remaining:
        last = ordered[-1]
        # Next = nearest remaining
        nxt = min(remaining, key=lambda i: (points[i][0]-last[0])**2
                                            + (points[i][1]-last[1])**2)
        ordered.append(points[nxt])
        remaining.remove(nxt)
    # Translate to absolute coordinates
    return [(p[0] + bbox[0], p[1] + bbox[1]) for p in ordered]


def _rdp_simplify_tuples(points: list[tuple[int, int]],
                           epsilon: float) -> list[tuple[int, int]]:
    if epsilon <= 0 or len(points) < 3:
        return list(points)
    # Reuse exact_trace._rdp_simplify with list-of-list format
    lists = [[p[0], p[1]] for p in points]
    out = _xt._rdp_simplify(lists, epsilon)
    return [(int(p[0]), int(p[1])) for p in out]


def _make_text_element(bbox, text: str, stroke: str = "#1e1e1e") -> dict:
    x, y, w, h = bbox
    font_size = max(12, int(h * 0.8))
    return {
        "id": _new_eid(), "type": "text",
        "x": float(x), "y": float(y),
        "width": float(w), "height": float(h),
        "angle": 0, "strokeColor": stroke,
        "backgroundColor": "transparent",
        "fillStyle": "solid", "strokeWidth": 1,
        "strokeStyle": "solid", "roughness": 0, "opacity": 100,
        "text": text, "fontSize": font_size, "fontFamily": 2,
        "textAlign": "left", "verticalAlign": "top",
        "baseline": int(h * 0.8),
        "originalText": text, "lineHeight": 1.25,
        "seed": 1, "version": 1, "versionNonce": 1,
        "isDeleted": False, "groupIds": ["text_like"],
        "boundElements": None, "updatedAt": 0,
        "link": None, "locked": False,
    }


def _make_ellipse_element(bbox, stroke: str = "#1e1e1e",
                            fill: str = "transparent") -> dict:
    x, y, w, h = bbox
    return {
        "id": _new_eid(), "type": "ellipse",
        "x": float(x), "y": float(y),
        "width": float(w), "height": float(h),
        "angle": 0, "strokeColor": stroke, "backgroundColor": fill,
        "fillStyle": "solid" if fill != "transparent" else "hachure",
        "strokeWidth": 1, "strokeStyle": "solid",
        "roughness": 0, "opacity": 100,
        "seed": 1, "version": 1, "versionNonce": 1,
        "isDeleted": False, "groupIds": ["circle"],
        "boundElements": None, "updatedAt": 0,
        "link": None, "locked": False,
    }


def _make_line_element(points: list[tuple[int, int]],
                         stroke: str = "#1e1e1e",
                         fill: str = "transparent",
                         groupIds: list[str] | None = None,
                         closed: bool = False,
                         stroke_width: int = 1) -> dict:
    if not points:
        return None  # type: ignore
    xs = [p[0] for p in points]; ys = [p[1] for p in points]
    mx, my = min(xs), min(ys)
    rel = [[p[0] - mx, p[1] - my] for p in points]
    if closed and rel[0] != rel[-1]:
        rel.append(list(rel[0]))
    return {
        "id": _new_eid(), "type": "line",
        "x": float(mx), "y": float(my),
        "width": float(max(xs) - mx), "height": float(max(ys) - my),
        "angle": 0, "strokeColor": stroke, "backgroundColor": fill,
        "fillStyle": "solid" if fill != "transparent" else "hachure",
        "strokeWidth": stroke_width, "strokeStyle": "solid",
        "roughness": 0, "opacity": 100,
        "points": rel,
        "seed": 1, "version": 1, "versionNonce": 1,
        "isDeleted": False,
        "groupIds": groupIds or [],
        "boundElements": None, "updatedAt": 0,
        "link": None, "locked": False,
        "startBinding": None, "endBinding": None,
        "startArrowhead": None, "endArrowhead": None,
        "lastCommittedPoint": None,
    }


def compose_auto_impl(image_path: str,
                       out_path: str,
                       min_area: int,
                       use_ocr: bool,
                       ocr_lang: str,
                       scale: float,
                       offset_x: float,
                       offset_y: float,
                       simplify_tolerance: float,
                       bg_color: str) -> dict[str, Any]:
    """Classify components and emit per-CC Excalidraw elements."""
    np = _ensure_np()
    cv2 = _ensure_cv2()

    src_p = pathlib.Path(image_path).expanduser()
    if not src_p.exists():
        return {"error": f"image not found: {src_p}"}

    mask, image_bgr = _load_image_gray_or_mask(src_p)
    if mask is None:
        return {"error": f"failed to decode: {src_p}"}

    num, labels, stats, _ = cv2.connectedComponentsWithStats(
        mask, connectivity=8,
    )

    components = []
    for lbl in range(1, num):
        x = int(stats[lbl, cv2.CC_STAT_LEFT])
        y = int(stats[lbl, cv2.CC_STAT_TOP])
        w = int(stats[lbl, cv2.CC_STAT_WIDTH])
        h = int(stats[lbl, cv2.CC_STAT_HEIGHT])
        area = int(stats[lbl, cv2.CC_STAT_AREA])
        if area < max(1, min_area // 4):
            continue
        cc_mask = (labels[y:y+h, x:x+w] == lbl).astype(np.uint8) * 255
        feat = _feature_vector_for_cc(cc_mask, (x, y, w, h), area)
        feat["id"] = int(lbl)
        feat["label"] = _classify_feature(feat, min_area=min_area)
        feat["label_source"] = "rule"
        feat["_mask_slice"] = (x, y, w, h)
        components.append(feat)

    if use_ocr:
        components, _ = _enhance_with_ocr(
            components, image_bgr, lang=ocr_lang,
        )

    elements: list[dict] = []
    per_label_counts: dict[str, int] = {}

    for feat in components:
        label = feat["label"]
        per_label_counts[label] = per_label_counts.get(label, 0) + 1
        x, y, w, h = feat["_mask_slice"]
        cc_mask = (labels[y:y+h, x:x+w] == feat["id"]).astype(np.uint8) * 255

        el = None
        if label == "noise":
            continue
        elif label == "text_like":
            if "ocr_text" in feat:
                el = _make_text_element(
                    (x, y, w, h), feat["ocr_text"],
                )
            else:
                # No OCR match — render the CC's own shape as a filled
                # polygon so the glyph is visible instead of an empty
                # placeholder. Japanese characters and decorative letters
                # that OCR misses still show up this way.
                poly = _cc_to_polygon(cc_mask, (x, y),
                                        simplify_tolerance=simplify_tolerance)
                if poly is not None:
                    poly = _rdp_simplify_tuples(poly, epsilon=simplify_tolerance)
                    el = _make_line_element(
                        poly, fill="#1e1e1e",
                        groupIds=["text_like"], closed=True, stroke_width=0,
                    )
        elif label == "circle":
            el = _make_ellipse_element((x, y, w, h))
        elif label == "line":
            poly = _cc_to_skeleton_polyline(cc_mask, (x, y))
            if poly is None:
                poly = _cc_to_polygon(cc_mask, (x, y),
                                        simplify_tolerance=max(simplify_tolerance, 1.0))
            if poly is not None:
                poly = _rdp_simplify_tuples(poly, epsilon=max(simplify_tolerance, 1.0))
                el = _make_line_element(
                    poly, groupIds=["line"], closed=False, stroke_width=1,
                )
        elif label == "fill":
            poly = _cc_to_polygon(cc_mask, (x, y),
                                    simplify_tolerance=simplify_tolerance)
            if poly is not None:
                poly = _rdp_simplify_tuples(poly, epsilon=simplify_tolerance)
                el = _make_line_element(
                    poly, fill="#1e1e1e",
                    groupIds=["fill"], closed=True, stroke_width=0,
                )
        else:  # other
            poly = _cc_to_polygon(cc_mask, (x, y),
                                    simplify_tolerance=simplify_tolerance)
            if poly is not None:
                poly = _rdp_simplify_tuples(poly, epsilon=simplify_tolerance)
                # Use the CC's pixel density to decide fill vs outline:
                # mostly-filled shapes that landed in "other" (e.g. filled
                # letters with complex contours) render with fill; sparse
                # ones stay as an outline-only polygon.
                if feat.get("density", 0.0) > 0.3:
                    el = _make_line_element(
                        poly, fill="#1e1e1e",
                        groupIds=["other_fill"], closed=True, stroke_width=0,
                    )
                else:
                    el = _make_line_element(
                        poly, groupIds=["other"], closed=True, stroke_width=1,
                    )

        if el is None:
            continue
        # Apply scale + offset
        if scale != 1.0 or offset_x != 0.0 or offset_y != 0.0:
            el["x"] = el.get("x", 0.0) * scale + offset_x
            el["y"] = el.get("y", 0.0) * scale + offset_y
            el["width"] = el.get("width", 0.0) * scale
            el["height"] = el.get("height", 0.0) * scale
            if "points" in el and el["points"]:
                el["points"] = [[p[0] * scale, p[1] * scale]
                                  for p in el["points"]]
            if el.get("type") == "text":
                el["fontSize"] = max(12, int(el["fontSize"] * scale))
        elements.append(el)

    doc = {
        "type": "excalidraw", "version": 2,
        "source": "mcp-server-document:diagram_compose_auto",
        "elements": elements,
        "appState": {"viewBackgroundColor": bg_color, "gridSize": None},
        "files": {},
    }
    outp = pathlib.Path(out_path).expanduser()
    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")

    return {
        "out_path": str(outp),
        "image_size": [int(image_bgr.shape[1]), int(image_bgr.shape[0])],
        "total_cc": len(components),
        "per_label_counts": per_label_counts,
        "total_elements": len(elements),
        "ocr_used": use_ocr,
    }


# ---------------------------------------------------------------------------
# compose_auto_layers — delegates to excalidraw/src/trace/compose_auto_layers.py
# ---------------------------------------------------------------------------
# The polyline / mesh recognition pipeline lives in the sibling
# mcp-server-excalidraw project at excalidraw/src/trace/
# compose_auto_layers.py. This wrapper adds the trace dir to sys.path,
# imports the module fresh, and forwards the call. Keeping the
# implementation there keeps raster→vector logic co-located with the
# rest of the excalidraw tooling (separate_layers.py, compose_layers.py,
# trace_image.py).
def compose_auto_layers_impl(image_path: str,
                              out_path: str,
                              min_area: int,
                              use_ocr: bool,
                              ocr_lang: str,
                              scale: float,
                              offset_x: float,
                              offset_y: float,
                              simplify_tolerance: float,
                              bg_color: str,
                              num_colors: int,
                              skip_bg_brightness: int,
                              detect_nodes: bool = True,
                              node_min_radius: int = 8,
                              node_max_radius: int = 40,
                              mesh_cutoff_brightness: int = 180) -> dict[str, Any]:
    """Thin shim around the excalidraw-side implementation."""
    import sys
    pkg_dir = pathlib.Path(__file__).resolve().parent.parent
    trace_dir = pkg_dir.parent.parent / "excalidraw" / "src" / "trace"
    if not trace_dir.is_dir():
        return {"error": f"excalidraw/src/trace/ not found at {trace_dir}"}
    sys.path.insert(0, str(trace_dir))
    try:
        if "compose_auto_layers" in sys.modules:
            del sys.modules["compose_auto_layers"]
        from compose_auto_layers import compose_auto_layers as _impl  # type: ignore
    except ImportError as exc:
        return {"error": f"failed to import excalidraw compose_auto_layers: {exc}"}
    finally:
        if str(trace_dir) in sys.path:
            sys.path.remove(str(trace_dir))
    return _impl(
        image_path=image_path, out_path=out_path,
        min_area=min_area, use_ocr=use_ocr, ocr_lang=ocr_lang,
        scale=scale, offset_x=offset_x, offset_y=offset_y,
        simplify_tolerance=simplify_tolerance, bg_color=bg_color,
        num_colors=num_colors, skip_bg_brightness=skip_bg_brightness,
        detect_nodes=detect_nodes,
        node_min_radius=node_min_radius,
        node_max_radius=node_max_radius,
        mesh_cutoff_brightness=mesh_cutoff_brightness,
    )


# ---------------------------------------------------------------------------
# trace_iterative — refinement loop using exact_trace + verify_pixel_match
# ---------------------------------------------------------------------------
def trace_iterative_impl(image_path: str,
                           out_path: str,
                           target_psnr: float,
                           max_iterations: int,
                           start_max_colors: int,
                           start_simplify: float,
                           min_area: int,
                           bg_detect: bool) -> dict[str, Any]:
    """Iteratively refine ``diagram_trace_exact`` parameters until PSNR target.

    Strategy: at each iteration, if PSNR below target:
      1. Increase ``max_colors`` (more palette) ; OR
      2. Reduce ``simplify_tolerance`` ; OR
      3. Lower ``min_area``.
    """
    src_p = pathlib.Path(image_path).expanduser()
    if not src_p.exists():
        return {"error": f"image not found: {src_p}"}

    max_colors = start_max_colors
    simplify = start_simplify
    current_min_area = min_area

    attempts = []
    best_psnr = -1.0
    best_doc_bytes: str | None = None
    best_metrics: dict[str, Any] | None = None
    best_params: dict[str, Any] | None = None

    tmp_out = pathlib.Path(out_path).expanduser()
    tmp_out.parent.mkdir(parents=True, exist_ok=True)

    for it in range(1, max_iterations + 1):
        r_trace = _xt.trace_exact_impl(
            image_path=str(src_p), out_path=str(tmp_out),
            max_colors=max_colors, simplify_tolerance=simplify,
            min_area=current_min_area, bg_detect=bg_detect,
            scale=1.0, offset_x=0.0, offset_y=0.0,
        )
        if "error" in r_trace:
            return {"error": f"trace failed in iter {it}: {r_trace['error']}"}
        r_verify = _xt.verify_pixel_match_impl(
            excalidraw_path=str(tmp_out),
            original_image_path=str(src_p),
            out_diff_png="",
            metric="all",
        )
        if "error" in r_verify:
            return {"error": f"verify failed in iter {it}: {r_verify['error']}"}

        psnr = r_verify["psnr_db"]
        psnr_val = 200.0 if psnr == "inf" else float(psnr)
        attempts.append({
            "iteration": it,
            "max_colors": max_colors,
            "simplify_tolerance": simplify,
            "min_area": current_min_area,
            "psnr_db": psnr,
            "total_elements": r_trace["total_elements"],
            "mismatch_pct": r_verify["mismatch_pixels_pct"],
        })

        if psnr_val > best_psnr:
            best_psnr = psnr_val
            best_doc_bytes = tmp_out.read_text(encoding="utf-8")
            best_metrics = r_verify
            best_params = {
                "max_colors": max_colors,
                "simplify_tolerance": simplify,
                "min_area": current_min_area,
            }

        if psnr_val >= target_psnr:
            break

        # Adjust params for next iteration
        if max_colors < 32:
            max_colors = min(32, max_colors + 4)
        elif simplify > 0:
            simplify = max(0.0, simplify / 2.0)
        elif current_min_area > 1:
            current_min_area = max(1, current_min_area // 2)
        else:
            # no more knobs, stop
            break

    # Write best output back
    if best_doc_bytes is not None:
        tmp_out.write_text(best_doc_bytes, encoding="utf-8")

    return {
        "out_path": str(tmp_out),
        "target_psnr": target_psnr,
        "best_psnr": best_psnr if best_psnr < 200 else "inf",
        "converged": best_psnr >= target_psnr,
        "iterations_run": len(attempts),
        "best_params": best_params,
        "best_metrics": best_metrics,
        "attempts": attempts,
    }
