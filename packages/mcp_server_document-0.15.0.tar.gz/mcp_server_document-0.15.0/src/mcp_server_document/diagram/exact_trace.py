"""Pixel-perfect vectorization helpers for the diagram sub-module.

Contains the heavy numerical algorithms used by the four v0.5.0 tools:

- `trace_exact_impl`           : color-quantize → per-cluster connected
                                  component → boundary pixels → Excalidraw
                                  polygon (roughness=0, solid fill).
- `verify_pixel_match_impl`    : rasterize Excalidraw polygons locally (PIL)
                                  → compare against original (MSE / PSNR /
                                  per-channel max-delta).
- `ocr_text_fill_impl`         : take existing Excalidraw whose compose
                                  output contains `text_placeholder` stubs
                                  → run OCR on the underlying raster →
                                  replace stub bounding boxes with filled
                                  Excalidraw `text` elements.
- `smooth_polylines_impl`      : Ramer–Douglas–Peucker simplify + Chaikin
                                  corner-cutting (2×) for compression +
                                  visual smoothing of hand-drawn strokes.

All numerical deps are lazy-imported so the plain server start-up does
not force opencv / skimage / PIL onto users who have not installed the
optional [diagram] extra.
"""
from __future__ import annotations

import json
import math
import pathlib
import uuid
from typing import Any


# ---------------------------------------------------------------------------
# Small utilities (no heavy deps)
# ---------------------------------------------------------------------------
def _new_eid() -> str:
    return uuid.uuid4().hex[:16]


def _rgb_to_hex(r: int, g: int, b: int) -> str:
    return f"#{int(r):02x}{int(g):02x}{int(b):02x}"


def _hex_to_rgb(color: str) -> tuple[int, int, int]:
    c = color.lstrip("#")
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def _ensure_np():
    try:
        import numpy as np  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "numpy is required for exact trace. "
            "pip install mcp-server-document[diagram]"
        ) from exc
    return np


def _ensure_cv2():
    try:
        import cv2  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "opencv-python is required for exact trace. "
            "pip install mcp-server-document[diagram]"
        ) from exc
    return cv2


def _ensure_pil():
    try:
        from PIL import Image, ImageDraw  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "Pillow is required for pixel-match verification. "
            "pip install mcp-server-document[diagram] or [ocr]"
        ) from exc
    return Image, ImageDraw


# ---------------------------------------------------------------------------
# Exact trace
# ---------------------------------------------------------------------------
def _quantize_image(img_bgr, max_colors: int, bg_detect: bool):
    """k-means color quantization with adaptive k.

    Returns (label_map HxW int32, palette_bgr List[(B,G,R)], bg_label or None).
    """
    np = _ensure_np()
    cv2 = _ensure_cv2()

    h, w = img_bgr.shape[:2]
    # Reshape to pixels
    data = img_bgr.reshape(-1, 3).astype(np.float32)

    # Adaptive k: start small, grow until added color is >5% of pixels but
    # stop at max_colors.
    best_k = None
    best_labels = None
    best_centers = None
    for k in range(2, max_colors + 1):
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
                    40, 0.5)
        _, labels, centers = cv2.kmeans(
            data, k, None, criteria, 3, cv2.KMEANS_PP_CENTERS,
        )
        best_k, best_labels, best_centers = k, labels, centers
        # If 2nd-smallest cluster is < 0.5% pixels, we've saturated.
        counts = np.bincount(labels.flatten(), minlength=k)
        sorted_counts = np.sort(counts)[::-1]
        if len(sorted_counts) >= 2 and sorted_counts[-1] / (h * w) < 0.005:
            # Last cluster is noise, this k is already too large → stop at
            # previous k (but keep current result if k==2)
            if k > 2:
                # Recompute with k-1
                _, labels, centers = cv2.kmeans(
                    data, k - 1, None, criteria, 3, cv2.KMEANS_PP_CENTERS,
                )
                best_k = k - 1
                best_labels = labels
                best_centers = centers
            break

    label_map = best_labels.reshape(h, w).astype(np.int32)
    palette_bgr = [tuple(int(c) for c in center) for center in best_centers]

    bg_label = None
    if bg_detect:
        # Find cluster with largest count that is also near the image border
        counts = np.bincount(label_map.flatten(), minlength=best_k)
        # Border pixels
        border = np.concatenate([
            label_map[0, :].flatten(),
            label_map[-1, :].flatten(),
            label_map[:, 0].flatten(),
            label_map[:, -1].flatten(),
        ])
        border_counts = np.bincount(border, minlength=best_k)
        # BG = largest cluster that dominates the border (>50%)
        border_total = border.size
        for lbl in np.argsort(-border_counts):
            if border_counts[lbl] / border_total > 0.5:
                bg_label = int(lbl)
                break

    return label_map, palette_bgr, bg_label


def _extract_polygons_for_label(label_map, target_label: int,
                                  simplify_tolerance: float,
                                  min_area: int) -> list[list[tuple[int, int]]]:
    """Return list of [(x, y), ...] polygons for the given label's pixels."""
    np = _ensure_np()
    cv2 = _ensure_cv2()

    mask = (label_map == target_label).astype(np.uint8) * 255
    # `CHAIN_APPROX_NONE` to keep ALL boundary pixels for exact reproduction.
    chain = cv2.CHAIN_APPROX_NONE if simplify_tolerance <= 0 else cv2.CHAIN_APPROX_TC89_L1
    contours, _ = cv2.findContours(
        mask, cv2.RETR_EXTERNAL, chain,
    )
    polys = []
    for ct in contours:
        area = cv2.contourArea(ct)
        if area < min_area:
            continue
        if simplify_tolerance > 0:
            approx = cv2.approxPolyDP(ct, simplify_tolerance, True)
            pts = [(int(p[0][0]), int(p[0][1])) for p in approx]
        else:
            pts = [(int(p[0][0]), int(p[0][1])) for p in ct]
        if len(pts) >= 3:
            polys.append(pts)
    return polys


def _poly_to_excalidraw_element(points: list[tuple[int, int]],
                                  fill_hex: str,
                                  stroke_hex: str,
                                  scale: float,
                                  offset: tuple[float, float]) -> dict:
    """Build one Excalidraw `line` element with `closed=true` and solid fill."""
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    min_x, min_y = min(xs), min(ys)
    max_x, max_y = max(xs), max(ys)
    ox, oy = offset
    element_x = min_x * scale + ox
    element_y = min_y * scale + oy
    rel_points = [[(p[0] - min_x) * scale, (p[1] - min_y) * scale]
                   for p in points]
    # Close the loop
    if rel_points[0] != rel_points[-1]:
        rel_points.append(list(rel_points[0]))
    return {
        "id": _new_eid(),
        "type": "line",
        "x": element_x,
        "y": element_y,
        "width": (max_x - min_x) * scale,
        "height": (max_y - min_y) * scale,
        "angle": 0,
        "strokeColor": stroke_hex,
        "backgroundColor": fill_hex,
        "fillStyle": "solid",
        "strokeWidth": 0,
        "strokeStyle": "solid",
        "roughness": 0,
        "opacity": 100,
        "points": rel_points,
        "seed": 1,
        "version": 1,
        "versionNonce": 1,
        "isDeleted": False,
        "groupIds": [],
        "frameId": None,
        "roundness": None,
        "boundElements": None,
        "updatedAt": 0,
        "link": None,
        "locked": False,
        "lastCommittedPoint": None,
        "startBinding": None,
        "endBinding": None,
        "startArrowhead": None,
        "endArrowhead": None,
    }


def trace_exact_impl(image_path: str,
                       out_path: str,
                       max_colors: int,
                       simplify_tolerance: float,
                       min_area: int,
                       bg_detect: bool,
                       scale: float,
                       offset_x: float,
                       offset_y: float) -> dict[str, Any]:
    """Main entry: raster → exact-reproduction Excalidraw JSON."""
    np = _ensure_np()
    cv2 = _ensure_cv2()

    src = pathlib.Path(image_path).expanduser()
    if not src.exists():
        return {"error": f"image not found: {src}"}
    img = cv2.imdecode(
        np.fromfile(str(src), dtype=np.uint8), cv2.IMREAD_COLOR,
    )
    if img is None:
        return {"error": f"failed to decode image: {src}"}

    label_map, palette_bgr, bg_label = _quantize_image(
        img, max_colors=max_colors, bg_detect=bg_detect,
    )
    unique_labels = sorted(set(int(x) for x in np.unique(label_map)))

    elements: list[dict] = []
    per_color_stats = []
    for lbl in unique_labels:
        if bg_label is not None and lbl == bg_label:
            continue
        b, g, r = palette_bgr[lbl]
        fill_hex = _rgb_to_hex(r, g, b)
        polys = _extract_polygons_for_label(
            label_map, lbl,
            simplify_tolerance=simplify_tolerance,
            min_area=min_area,
        )
        for poly in polys:
            el = _poly_to_excalidraw_element(
                poly, fill_hex=fill_hex, stroke_hex=fill_hex,
                scale=scale, offset=(offset_x, offset_y),
            )
            elements.append(el)
        per_color_stats.append({
            "label": lbl,
            "fill": fill_hex,
            "components": len(polys),
            "total_vertices": sum(len(p) for p in polys),
        })

    h, w = img.shape[:2]
    bg_hex = "#ffffff"
    if bg_label is not None:
        b, g, r = palette_bgr[bg_label]
        bg_hex = _rgb_to_hex(r, g, b)

    doc = {
        "type": "excalidraw",
        "version": 2,
        "source": "mcp-server-document:diagram_trace_exact",
        "elements": elements,
        "appState": {
            "viewBackgroundColor": bg_hex,
            "gridSize": None,
        },
        "files": {},
    }
    outp = pathlib.Path(out_path).expanduser()
    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")

    return {
        "out_path": str(outp),
        "image_size": [int(w), int(h)],
        "palette_size": len(palette_bgr),
        "bg_color": bg_hex,
        "total_elements": len(elements),
        "per_color": per_color_stats,
        "scale": scale,
    }


# ---------------------------------------------------------------------------
# Pixel-match verification — render Excalidraw polygons locally with PIL
# ---------------------------------------------------------------------------
def _rasterize_excalidraw_locally(excalidraw_doc: dict,
                                   size_wh: tuple[int, int],
                                   bg_rgb: tuple[int, int, int]):
    """Render the `line` elements (closed, solid fill) back to a PIL image.

    This is a *deliberately simple* rasterizer intended to match exactly what
    `diagram_trace_exact` emits (line elements with roughness=0, strokeWidth=0,
    fillStyle=solid, closed polygon). It will NOT render freeform sketches,
    rough.js output, or arbitrary Excalidraw scenes faithfully — that is out
    of scope for pixel-match verification.
    """
    Image, ImageDraw = _ensure_pil()
    w, h = size_wh
    img = Image.new("RGB", (w, h), bg_rgb)
    draw = ImageDraw.Draw(img)
    for el in excalidraw_doc.get("elements", []):
        if el.get("isDeleted"):
            continue
        if el.get("type") not in ("line", "polygon"):
            continue
        bg = el.get("backgroundColor") or "#ffffff"
        try:
            fill = _hex_to_rgb(bg) if bg and bg != "transparent" else None
        except ValueError:
            fill = None
        x0 = el.get("x", 0.0)
        y0 = el.get("y", 0.0)
        pts_rel = el.get("points") or []
        if len(pts_rel) < 3:
            continue
        abs_pts = [(x0 + p[0], y0 + p[1]) for p in pts_rel]
        if fill is not None:
            draw.polygon(abs_pts, fill=fill, outline=fill)
    return img


def verify_pixel_match_impl(excalidraw_path: str,
                              original_image_path: str,
                              out_diff_png: str = "",
                              metric: str = "all") -> dict[str, Any]:
    """Rasterize Excalidraw, diff against original; return PSNR/MSE/max-delta."""
    np = _ensure_np()
    cv2 = _ensure_cv2()
    Image, _ = _ensure_pil()

    excal_p = pathlib.Path(excalidraw_path).expanduser()
    orig_p = pathlib.Path(original_image_path).expanduser()
    if not excal_p.exists():
        return {"error": f"excalidraw not found: {excal_p}"}
    if not orig_p.exists():
        return {"error": f"original image not found: {orig_p}"}
    try:
        doc = json.loads(excal_p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        return {"error": f"parse error: {exc}"}

    orig_bgr = cv2.imdecode(
        np.fromfile(str(orig_p), dtype=np.uint8), cv2.IMREAD_COLOR,
    )
    if orig_bgr is None:
        return {"error": f"failed to decode original: {orig_p}"}
    h, w = orig_bgr.shape[:2]
    orig_rgb = cv2.cvtColor(orig_bgr, cv2.COLOR_BGR2RGB)

    bg_hex = (doc.get("appState") or {}).get("viewBackgroundColor", "#ffffff")
    try:
        bg_rgb = _hex_to_rgb(bg_hex)
    except ValueError:
        bg_rgb = (255, 255, 255)

    rendered_pil = _rasterize_excalidraw_locally(doc, (w, h), bg_rgb)
    rendered = np.asarray(rendered_pil)

    diff = orig_rgb.astype(np.int32) - rendered.astype(np.int32)
    mse = float(np.mean(diff.astype(np.float64) ** 2))
    psnr = float("inf") if mse == 0 else 20.0 * math.log10(
        255.0 / math.sqrt(mse)
    )
    max_delta = int(np.max(np.abs(diff)))
    abs_diff = np.abs(diff).astype(np.uint8)
    # "exact" = every channel within 1 gray level
    exact_match = bool(max_delta <= 1)
    # Per-channel mismatch pixel count (any channel differs by > 5)
    any_mismatch = np.any(abs_diff > 5, axis=2)
    mismatch_pct = float(np.mean(any_mismatch) * 100.0)

    if out_diff_png:
        outp = pathlib.Path(out_diff_png).expanduser()
        outp.parent.mkdir(parents=True, exist_ok=True)
        # Boost diff for human visibility
        vis = np.clip(abs_diff.astype(np.int32) * 4, 0, 255).astype(np.uint8)
        # Write as RGB
        cv2.imwrite(str(outp), cv2.cvtColor(vis, cv2.COLOR_RGB2BGR))

    result = {
        "image_size": [int(w), int(h)],
        "element_count": len(doc.get("elements", [])),
        "mse": round(mse, 3),
        "psnr_db": round(psnr, 2) if psnr != float("inf") else "inf",
        "max_delta": max_delta,
        "mismatch_pixels_pct": round(mismatch_pct, 3),
        "exact_match": exact_match,
        "verdict": (
            "pixel_perfect" if exact_match else
            "near_perfect (PSNR>=40dB)" if psnr >= 40 else
            "acceptable (PSNR>=30dB)" if psnr >= 30 else
            "poor"
        ),
    }
    if out_diff_png:
        result["diff_png"] = str(pathlib.Path(out_diff_png).expanduser())
    return result


# ---------------------------------------------------------------------------
# OCR → text element fill
# ---------------------------------------------------------------------------
def ocr_text_fill_impl(excalidraw_path: str,
                         original_image_path: str,
                         out_path: str,
                         lang: str,
                         min_confidence: float,
                         replace_placeholders: bool) -> dict[str, Any]:
    """Replace `text_placeholder` stubs with OCR-filled Excalidraw text elements.

    A "placeholder" here is an element with `type="text"` and `text==""`, or
    any element whose id starts with `text_placeholder_`, or (fallback) a
    rectangle with `groupIds` containing "text".
    """
    try:
        import pytesseract  # type: ignore
        from PIL import Image  # type: ignore
    except ImportError as exc:
        return {"error": f"pytesseract/Pillow not installed: {exc}. "
                         "pip install mcp-server-document[ocr]"}

    excal_p = pathlib.Path(excalidraw_path).expanduser()
    orig_p = pathlib.Path(original_image_path).expanduser()
    if not excal_p.exists():
        return {"error": f"excalidraw not found: {excal_p}"}
    if not orig_p.exists():
        return {"error": f"original image not found: {orig_p}"}
    try:
        doc = json.loads(excal_p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        return {"error": f"parse error: {exc}"}

    try:
        img = Image.open(orig_p)
    except Exception as exc:
        return {"error": f"image open failed: {type(exc).__name__}: {exc}"}

    def _is_text_placeholder(el: dict) -> bool:
        if el.get("type") == "text" and not (el.get("text") or "").strip():
            return True
        if str(el.get("id", "")).startswith("text_placeholder_"):
            return True
        if "text" in (el.get("groupIds") or []):
            return True
        return False

    elements = doc.get("elements", [])
    replacements = 0
    filled_samples: list[str] = []

    # Pre-compute once
    try:
        data = pytesseract.image_to_data(
            img, lang=lang, output_type=pytesseract.Output.DICT,
        )
    except Exception as exc:
        return {"error": f"OCR failed: {type(exc).__name__}: {exc}"}

    # Build list of OCR blocks (already filtered by confidence)
    ocr_blocks = []
    n = len(data.get("text", []))
    for i in range(n):
        txt = (data["text"][i] or "").strip()
        if not txt:
            continue
        try:
            conf = float(data["conf"][i])
        except (ValueError, TypeError):
            conf = -1.0
        if conf < min_confidence:
            continue
        ocr_blocks.append({
            "text": txt, "x": int(data["left"][i]),
            "y": int(data["top"][i]),
            "w": int(data["width"][i]),
            "h": int(data["height"][i]),
            "conf": conf,
        })

    def _best_ocr_for_box(bx: float, by: float, bw: float, bh: float):
        """Return OCR block with most IoU against element bbox, or None."""
        best = None
        best_iou = 0.0
        for blk in ocr_blocks:
            ix1 = max(bx, blk["x"])
            iy1 = max(by, blk["y"])
            ix2 = min(bx + bw, blk["x"] + blk["w"])
            iy2 = min(by + bh, blk["y"] + blk["h"])
            if ix2 <= ix1 or iy2 <= iy1:
                continue
            inter = (ix2 - ix1) * (iy2 - iy1)
            union = bw * bh + blk["w"] * blk["h"] - inter
            iou = inter / union if union > 0 else 0.0
            if iou > best_iou:
                best_iou = iou
                best = blk
        return best if best_iou > 0.1 else None

    new_elements = []
    for el in elements:
        if _is_text_placeholder(el):
            bx = el.get("x", 0.0)
            by = el.get("y", 0.0)
            bw = el.get("width", 0.0)
            bh = el.get("height", 0.0)
            ocr_hit = _best_ocr_for_box(bx, by, bw, bh)
            if ocr_hit is None and not replace_placeholders:
                new_elements.append(el)
                continue
            if ocr_hit is None:
                # Drop the empty placeholder
                continue
            filled = {
                "id": el.get("id") or _new_eid(),
                "type": "text",
                "x": bx,
                "y": by,
                "width": bw,
                "height": bh,
                "angle": 0,
                "strokeColor": el.get("strokeColor", "#1e1e1e"),
                "backgroundColor": "transparent",
                "fillStyle": "solid",
                "strokeWidth": 1,
                "strokeStyle": "solid",
                "roughness": 0,
                "opacity": 100,
                "text": ocr_hit["text"],
                "fontSize": max(12, int(bh * 0.8)),
                "fontFamily": 2,
                "textAlign": "left",
                "verticalAlign": "top",
                "baseline": int(bh * 0.8),
                "containerId": None,
                "originalText": ocr_hit["text"],
                "lineHeight": 1.25,
                "seed": 1,
                "version": 1,
                "versionNonce": 1,
                "isDeleted": False,
                "groupIds": el.get("groupIds") or [],
                "frameId": None,
                "boundElements": None,
                "updatedAt": 0,
                "link": None,
                "locked": False,
            }
            new_elements.append(filled)
            replacements += 1
            if len(filled_samples) < 10:
                filled_samples.append(ocr_hit["text"])
        else:
            new_elements.append(el)

    doc["elements"] = new_elements
    outp = pathlib.Path(out_path).expanduser()
    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
    return {
        "out_path": str(outp),
        "total_elements_before": len(elements),
        "total_elements_after": len(new_elements),
        "text_placeholders_replaced": replacements,
        "ocr_blocks_found": len(ocr_blocks),
        "sample_filled_texts": filled_samples,
        "lang": lang,
    }


# ---------------------------------------------------------------------------
# Smooth + simplify
# ---------------------------------------------------------------------------
def _rdp_simplify(points: list[list[float]],
                    epsilon: float) -> list[list[float]]:
    """Ramer–Douglas–Peucker simplification (iterative, O(n log n) expected)."""
    if len(points) <= 2 or epsilon <= 0:
        return list(points)

    def _perp_distance(p, a, b):
        (x, y) = p
        (ax, ay) = a
        (bx, by) = b
        dx, dy = bx - ax, by - ay
        if dx == 0 and dy == 0:
            return math.hypot(x - ax, y - ay)
        t = ((x - ax) * dx + (y - ay) * dy) / (dx * dx + dy * dy)
        t = max(0.0, min(1.0, t))
        cx, cy = ax + t * dx, ay + t * dy
        return math.hypot(x - cx, y - cy)

    stack = [(0, len(points) - 1)]
    keep = [False] * len(points)
    keep[0] = keep[-1] = True
    while stack:
        i, j = stack.pop()
        if j - i < 2:
            continue
        max_d = 0.0
        idx = -1
        for k in range(i + 1, j):
            d = _perp_distance(points[k], points[i], points[j])
            if d > max_d:
                max_d = d
                idx = k
        if max_d > epsilon and idx > 0:
            keep[idx] = True
            stack.append((i, idx))
            stack.append((idx, j))
    return [points[i] for i in range(len(points)) if keep[i]]


def _chaikin_subdivide(points: list[list[float]],
                         iterations: int,
                         closed: bool) -> list[list[float]]:
    """Chaikin corner-cutting: each edge splits into 1/4 and 3/4 points."""
    if iterations <= 0 or len(points) < 3:
        return list(points)
    pts = list(points)
    for _ in range(iterations):
        new_pts = []
        n = len(pts)
        end = n if closed else n - 1
        for i in range(end):
            p0 = pts[i]
            p1 = pts[(i + 1) % n]
            q = [0.75 * p0[0] + 0.25 * p1[0], 0.75 * p0[1] + 0.25 * p1[1]]
            r = [0.25 * p0[0] + 0.75 * p1[0], 0.25 * p0[1] + 0.75 * p1[1]]
            new_pts.extend([q, r])
        if not closed:
            # Keep the endpoints pinned.
            new_pts.insert(0, list(pts[0]))
            new_pts.append(list(pts[-1]))
        pts = new_pts
    return pts


def smooth_polylines_impl(excalidraw_path: str,
                            out_path: str,
                            epsilon: float,
                            chaikin_iterations: int,
                            only_types: list[str] | None,
                            min_points: int) -> dict[str, Any]:
    """Simplify + smooth polyline-like elements in an Excalidraw JSON."""
    excal_p = pathlib.Path(excalidraw_path).expanduser()
    if not excal_p.exists():
        return {"error": f"excalidraw not found: {excal_p}"}
    try:
        doc = json.loads(excal_p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        return {"error": f"parse error: {exc}"}

    targets = set(only_types) if only_types else {"line", "freedraw"}
    total_before = 0
    total_after = 0
    modified = 0
    for el in doc.get("elements", []):
        if el.get("type") not in targets:
            continue
        pts = el.get("points") or []
        if len(pts) < min_points:
            continue
        closed = False
        if len(pts) >= 3 and pts[0] == pts[-1]:
            closed = True
            working = pts[:-1]
        else:
            working = list(pts)
        total_before += len(pts)
        simplified = _rdp_simplify([list(p) for p in working],
                                     epsilon=epsilon)
        smoothed = _chaikin_subdivide(simplified,
                                        iterations=chaikin_iterations,
                                        closed=closed)
        if closed:
            smoothed.append(list(smoothed[0]))
        # Recompute bounding box (relative to origin)
        xs = [p[0] for p in smoothed]
        ys = [p[1] for p in smoothed]
        if xs and ys:
            shift_x = min(xs)
            shift_y = min(ys)
            # Translate so rel points start at (0,0)-offset-from-bbox-min
            # Keep element.x / .y aligned by adding shift to them
            el["x"] = el.get("x", 0.0) + shift_x
            el["y"] = el.get("y", 0.0) + shift_y
            el["width"] = max(xs) - shift_x
            el["height"] = max(ys) - shift_y
            el["points"] = [[p[0] - shift_x, p[1] - shift_y] for p in smoothed]
        else:
            el["points"] = smoothed
        total_after += len(el["points"])
        modified += 1

    outp = pathlib.Path(out_path).expanduser()
    outp.parent.mkdir(parents=True, exist_ok=True)
    outp.write_text(json.dumps(doc, ensure_ascii=False), encoding="utf-8")
    compression = 0.0
    if total_before > 0:
        compression = (1.0 - total_after / total_before) * 100.0
    return {
        "out_path": str(outp),
        "elements_modified": modified,
        "points_before": total_before,
        "points_after": total_after,
        "compression_pct": round(compression, 1),
        "epsilon": epsilon,
        "chaikin_iterations": chaikin_iterations,
    }
