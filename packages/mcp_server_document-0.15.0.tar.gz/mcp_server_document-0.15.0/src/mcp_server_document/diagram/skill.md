# Diagram Sub-module — raster-to-Excalidraw パイプライン

画像 (ロゴ、手描き図、研究イラスト) を Excalidraw のベクター要素に変換するための **2 段階パイプライン** を提供する。

**Phase 1 (`diagram_separate_layers`)**: 画像を意味的レイヤー PNG に分離
**Phase 2 (`diagram_compose_layers`)**: レイヤー PNG 群から Excalidraw JSON を組み立て

一発変換 (画像 → ベクター) は品質が低下する (論文メモリ経由の知見)。意味的レイヤーに分けて各層個別に処理する方が人間が tuning しやすく、結果も整う。

## 典型的ワークフロー

```python
# Phase 1: 分離
result1 = diagram_separate_layers(
    image_path="/path/to/logo.png",
    out_dir="/path/to/logo_layers",
    k=5,                      # 色クラスタ数
)
# -> logo_layers/ に 15 枚の PNG + layers_overview.png が保存される

# (ここで人間が layers_overview.png を目視して良いレイヤーを選定)

# Phase 2: 合成 (自動設定)
result2 = diagram_compose_layers(
    layers_dir="/path/to/logo_layers",
    out_path="/path/to/logo.excalidraw",
)
# -> logo.excalidraw として Excalidraw にインポート可能
```

## 各レイヤーの内容

`diagram_separate_layers` が生成する PNG:

| ファイル | 内容 |
|---|---|
| `_source.png` | 入力コピー (参照用) |
| `quantized_k{k}.png` | k-means 色量子化版 |
| `layer_color{N}_rgb*.png` | 色クラスタ毎 (透過 PNG + 白背景 flat 版) |
| `layer_bg.png` | 近白背景マスク |
| `layer_foreground.png` | 非背景すべて (黒FG on 白BG) |
| `layer_edges_canny.png` | Canny エッジ抽出 |
| `layer_thin_lines_all.png` | 細線全部 (骨格化後) |
| `layer_thin_short.png` | 短い細線成分 (< 40 px, ≈ 文字字形候補) |
| `layer_thin_long.png` | 長い細線成分 (≥ 40 px, ≈ 輪郭・磁場線) |
| `layer_thick_fills.png` | 大きい塗り潰し領域 (≥ min_fill_area px) |
| `layer_circles.png` | Hough 検出円 |
| `layer_text_mser.png` | MSER テキスト候補領域 |
| `layers_overview.png` | タイル状まとめ (4 列) |

## 戦略 (Strategies)

`diagram_compose_layers` の config で指定。`diagram_list_strategies()` で一覧取得可:

| 戦略 | 用途 | 主な params |
|---|---|---|
| `fill_contour` | 塗り潰し多角形 | min_area, epsilon, stroke, fill |
| `outline` | 塗り潰しなし閉多角形 | min_area, epsilon, stroke, width |
| `skeleton_lines` | 骨格化+線 trace | min_length, simplify, width, max_lines |
| `circles_fit` | Hough 円 → 楕円 | min/max_radius, max_circles |
| `text_placeholder` | MSER 空 text stub | min_area, min_height |
| `points` | 小成分 → 小円 | min_area, max_area |

## 自動設定 (`default_config_for`)

config_json 省略時の既定:

| レイヤー | 戦略 | 閾値 |
|---|---|---|
| `layer_thick_fills.png` | fill_contour | min_area=150, epsilon=0.003 |
| `layer_thin_long.png` | skeleton_lines | min_length=8, max_lines=200 |
| `layer_circles.png` | circles_fit | min_r=20, max_circles=20 |
| `layer_thin_short.png` | points | min_area=4, max_area=40 |

## tuning 指針

- **circles が多すぎる** → max_circles を 10 以下に、または min_radius を上げる
- **skeleton_lines が途切れる** → min_length を下げる、simplify を 0.5 に下げる
- **fill_contour が拾わない** → min_area を 50 に下げる、または separate_layers の min_fill_area を下げる
- **text を拾いたい** → layer_text_mser.png を text_placeholder 戦略に追加
- **特定色のみ抽出したい** → layer_color{N}.png を fill_contour や outline で使う

## 設計思想

1. **「一発変換は品質低下」**: 意味レイヤーに分けて各層 tuning するのが正道 (LAB memory feedback_image_to_excalidraw_layered より)
2. **人間が層を選ぶ**: `layers_overview.png` で視認 → 良い層を config で選択 → compose
3. **Excalidraw 要素は groupIds で層タグ**: インポート後に Excalidraw 上で層選択・編集可
4. **座標は整数化しない (float 保存)**: numpy.float32 は json.dumps で失敗するため `float()` で native 化
5. **依存を optional に**: opencv-python + scikit-image は `[full]` extras、コアツール群には影響せず

## 線図 lint — 塚本『作図力学』

科学・技術論文の線図が陥りがちな 15 項目 anti-pattern (塚本真也『作図力学』§4.3.2) を Excalidraw 構造レベルで検査する `diagram_lint_line_plot` を提供。

**塚本の 15 項目** (§4.3.2 図 4.20):
1. 座標軸線への矢印 → 特殊線図以外は **NG**
2. 横軸の量記号・単位 → 下方中央に記述
3. 縦軸の量記号 → 下から上に横書き
4. 量記号と単位の間 → スペース必須
5. スケール数字 → 不必要な有効桁数は NG
6. 原点スケール → 縦軸・横軸の右端/上端延長線の交差位置
7. プロット点 → 曲線の貫通を避ける (塗り潰し or 修正液)
8. スケール線 → 欠落させない
9. 図番号・キャプション → 下欄
10. キャプション → 枠で囲まない
11. 複数行キャプション → 行頭揃え
12. 分数形式単位 → `J/(kg·K)` 等正確に

**Excalidraw 構造レベルで検出可能** (diagram_lint_line_plot):
- ✅ 軸ラベル text 要素 ≥ 2 の有無
- ✅ キャプション text 要素 (plot 下方) の有無
- ✅ データ系列 line 要素の有無
- ✅ 座標軸線への矢印 (arrow 要素が原点付近)
- ✅ floating 要素の検出 (plot 外漂流)

**画像レベル必要** (本ツールでは不可、image 処理 tool 側):
- プロット点形状の判定 (塗り潰し/中空/三角)
- 曲線がプロット点を貫通するか
- スケール数字の有効桁数
- 量記号と単位の間のスペース

## 設計思想

1. **「一発変換は品質低下」**: 意味レイヤーに分けて各層 tuning するのが正道 (LAB memory feedback_image_to_excalidraw_layered より)
2. **人間が層を選ぶ**: `layers_overview.png` で視認 → 良い層を config で選択 → compose
3. **Excalidraw 要素は groupIds で層タグ**: インポート後に Excalidraw 上で層選択・編集可
4. **座標は整数化しない (float 保存)**: numpy.float32 は json.dumps で失敗するため `float()` で native 化
5. **依存を optional に**: opencv-python + scikit-image は `[full]` extras、コアツール群には影響せず
6. **lint は hint、違反数 0 化が目的ではない** (v0.7.1 anti-Goodhart 原則と同じ)

## 関連

- 別レポ (Node.js sibling): `github.com/ksugahar/mcp-server-document/tree/main/excalidraw/`
- 参考 upstream: [yctimlin/mcp_excalidraw](https://github.com/yctimlin/mcp_excalidraw)
- この sub-module は Python 側で画像→JSON 変換のみ行う。実際の canvas 表示は Node MCP が担当。
- 線図 lint の出典: 塚本真也『作図力学』§4.3.2 (知的な科学・技術文章の書き方 第 4 章から抜粋版)
