"""Unified MCP server entry point for mcp-server-document.

Registers tools from all sub-modules (grant_writing, paper_writing,
presentation, diagram) into a single FastMCP instance and launches
stdio transport.

Usage:
    $ mcp-server-document                # console-script entry
    $ python -m mcp_server_document      # module entry
"""
from __future__ import annotations

import sys

from mcp.server.fastmcp import FastMCP

from . import grant_writing, paper_writing, presentation, diagram, document_meta


def _build_mcp() -> tuple[FastMCP, dict[str, int]]:
    mcp = FastMCP("mcp-server-document")
    counts = {
        "grant_writing": grant_writing.register(mcp),
        "paper_writing": paper_writing.register(mcp),
        "presentation": presentation.register(mcp),
        "diagram": diagram.register(mcp),
        "document_meta": document_meta.register(mcp),
    }
    return mcp, counts


def main() -> None:
    """Entry point (console-script): launch stdio MCP server."""
    mcp, counts = _build_mcp()
    total = sum(counts.values())
    print(
        f"[mcp-server-document] registered {total} tools "
        f"(grant_writing={counts['grant_writing']}, "
        f"paper_writing={counts['paper_writing']}, "
        f"presentation={counts['presentation']}, "
        f"diagram={counts['diagram']}, "
        f"document_meta={counts['document_meta']})",
        file=sys.stderr,
    )
    mcp.run()


# Expose a module-level mcp instance for introspection / testing.
mcp, _counts = _build_mcp()


if __name__ == "__main__":
    main()
