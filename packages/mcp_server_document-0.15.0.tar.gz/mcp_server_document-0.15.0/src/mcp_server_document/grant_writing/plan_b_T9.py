"""Plan B T9: concrete scene density diagnostic for grant-writing.

skill.md NG パターン 2 「抽象論のみ」を定量化する。
スライドウィンドウで具体要素 (数値+単位, 固有名, 場所マーカー) の密度を測定し、
抽象論のみの領域を具体場面に書き換える提案を返す。

関連ツール:
- T5 `suggest_vivid_scene` (skill.md l.64-67)
- NG パターン 2 「抽象論のみ」(skill.md l.203)
- 木下 原則 4 「事実意見峻別」

grant_writing.tools.py のスタイルに合わせた plain callable。
@mcp.tool() デコレータは server.py 側で適用される想定。
"""

from __future__ import annotations

import re


# ------------------------------------------------------------------
# 具体要素の検出パターン
# ------------------------------------------------------------------

# 数値 + 単位 (頻出の申請書単位を優先)
_NUMBER_UNIT_RE = re.compile(
    r"\d+(?:\.\d+)?\s*"
    r"(?:kHz|MHz|GHz|Hz|mm|cm|km|m|kW|MW|W|V|A|"
    r"万円|億円|千円|円|"
    r"年|件|名|社|回|倍|%|％|日|月|台|本|個|分|時間|ms|s|μs|ns)"
)

# カタカナ複合語 (3 字以上の連続カタカナ)
_KATAKANA_RE = re.compile(r"[゠-ヿ]{3,}")

# Latin 識別子 (大文字 2 個以上を含む英数字 token)。
# "IH", "PCB", "JMAG", "LLM", "NGSolve" 等を拾う。
_LATIN_ID_RE = re.compile(r"\b(?=[A-Za-z0-9]*[A-Z]{2,})[A-Za-z][A-Za-z0-9]{1,}\b")

# 場所・組織マーカー
_PLACE_RE = re.compile(
    r"(?:研究室|会社|大学|研|教授|先生|案件|工場|現場|"
    r"財団|機構|学会|センター|電機|電気|国|省|庁)"
)


def _count_concrete(segment: str) -> int:
    """1 ウィンドウ分のテキスト中の具体要素数を返す。"""
    n = 0
    n += len(_NUMBER_UNIT_RE.findall(segment))
    n += len(_KATAKANA_RE.findall(segment))
    n += len(_LATIN_ID_RE.findall(segment))
    n += len(_PLACE_RE.findall(segment))
    return n


_HINT_DEFAULT = (
    "score はスライディング窓の抽象率ベース。"
    "全窓 OK でも読み返した時の『体温』とは別物。"
    "skill.md Case 1-3 の実例と照合し、comments の具体場面提案を 1 件ずつ吟味する。"
)

_SOURCE = (
    "skill.md T5 (suggest_vivid_scene) / "
    "NG パターン 2 (抽象論のみ) / "
    "木下 原則 4 (事実意見峻別)"
)


def grant_writing_concrete_scene_density(
    text: str,
    window_chars: int = 500,
    min_concrete_per_window: int = 1,
) -> dict:
    """skill.md NG#2「抽象論のみ」を定量化。

    window_chars ごとにスライドウィンドウで具体要素 (数値+固有名+場所) の
    密度を測る。

    Args:
        text: 解析対象テキスト
        window_chars: ウィンドウの文字幅 (既定 500)
        min_concrete_per_window: 1 ウィンドウで最低限必要な具体要素数
                                 (未満だと ABSTRACT_ONLY 判定)

    Returns:
        {
          "score": float (0-10),
          "score_max": 10,
          "comments": list[str],  # human-reviewer style
          "observations": dict,
          "hint": str,
          "source": str,
        }
    """
    total_chars = len(text)

    # Empty text
    if total_chars == 0:
        return {
            "score": 0.0,
            "score_max": 10,
            "comments": [
                "入力テキストが空。解析対象を指定すること。"
            ],
            "observations": {
                "total_chars": 0,
                "windows": [],
                "abstract_only_windows": 0,
                "total_windows": 0,
                "concrete_ratio": 0.0,
            },
            "hint": _HINT_DEFAULT,
            "source": _SOURCE,
        }

    # Short text: single window
    if total_chars < window_chars:
        concrete = _count_concrete(text)
        status = "OK" if concrete >= min_concrete_per_window else "ABSTRACT_ONLY"
        windows = [{
            "idx": 0,
            "char_range": [0, total_chars],
            "concrete_count": concrete,
            "status": status,
        }]
        if status == "OK":
            score = 10.0
            comments = [
                f"全 1 窓とも具体要素が揃っている。申請書として十分な臨場感。"
            ]
        else:
            score = 0.0
            comments = [
                f"0-{total_chars} 字目の領域が抽象論のみ (具体要素ゼロ)。"
                "三菱電機14年/PCB設計で3日/500 kHz IH コイル等の数値+場所を 1 件注入。",
                "抽象密度が高すぎる。skill.md Case 2/3 を参照し、"
                "最低 1 セクションあたり 1 つの具体場面 (固有名+数値+時期) を入れる。",
            ]
        abstract_only = 0 if status == "OK" else 1
        return {
            "score": score,
            "score_max": 10,
            "comments": comments,
            "observations": {
                "total_chars": total_chars,
                "windows": windows,
                "abstract_only_windows": abstract_only,
                "total_windows": 1,
                "concrete_ratio": 1.0 - abstract_only,
            },
            "hint": _HINT_DEFAULT,
            "source": _SOURCE,
        }

    # Sliding windows with stride = window_chars (non-overlapping) so that
    # the total_windows reflects the document size in a stable way.
    windows: list[dict] = []
    abstract_only = 0
    stride = window_chars
    idx = 0
    start = 0
    while start < total_chars:
        end = min(start + window_chars, total_chars)
        seg = text[start:end]
        concrete = _count_concrete(seg)
        status = "OK" if concrete >= min_concrete_per_window else "ABSTRACT_ONLY"
        if status == "ABSTRACT_ONLY":
            abstract_only += 1
        windows.append({
            "idx": idx,
            "char_range": [start, end],
            "concrete_count": concrete,
            "status": status,
        })
        idx += 1
        start += stride

    total_windows = len(windows)
    non_abstract = total_windows - abstract_only
    concrete_ratio = non_abstract / total_windows if total_windows else 0.0
    score = round(concrete_ratio * 10, 1)

    # Build comments (PRIMARY)
    comments: list[str] = []
    abstract_windows = [w for w in windows if w["status"] == "ABSTRACT_ONLY"]
    if abstract_windows:
        # Name up to 5 abstract windows by char range
        for w in abstract_windows[:5]:
            s, e = w["char_range"]
            comments.append(
                f"{s}-{e} 字目の領域が抽象論のみ (具体要素ゼロ)。"
                "三菱電機14年/PCB設計で3日/500 kHz IH コイル等の数値+場所を 1 件注入。"
            )
    else:
        comments.append(
            f"全 {total_windows} 窓とも具体要素が揃っている。申請書として十分な臨場感。"
        )

    if score < 4:
        comments.append(
            "抽象密度が高すぎる。skill.md Case 2/3 を参照し、"
            "最低 1 セクションあたり 1 つの具体場面 (固有名+数値+時期) を入れる。"
        )

    # Clamp to 6
    comments = comments[:6]
    if not comments:
        comments = [
            f"全 {total_windows} 窓とも具体要素が揃っている。申請書として十分な臨場感。"
        ]

    return {
        "score": score,
        "score_max": 10,
        "comments": comments,
        "observations": {
            "total_chars": total_chars,
            "windows": windows,
            "abstract_only_windows": abstract_only,
            "total_windows": total_windows,
            "concrete_ratio": round(concrete_ratio, 3),
        },
        "hint": _HINT_DEFAULT,
        "source": _SOURCE,
    }
