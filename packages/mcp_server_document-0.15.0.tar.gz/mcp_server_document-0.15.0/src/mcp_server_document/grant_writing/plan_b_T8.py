"""Plan B T8: 冒頭 Hook 強度診断 (grant_writing_hook_strength).

skill.md T1 (冒頭 Hook 強度) / 木下『理科系の作文技術』原則 2 (重点先行) に基づく
粗い温度計。最終判断は comments を読み、skill.md T1 の判定基準と照合すること。

設計方針:
- score は 0-10 の粗い温度計。9 以上は誤差範囲、6 以下は改善サイン。
- PRIMARY OUTPUT は comments (人間レビュアー風の助言文)。
- observations は raw measurement。自動化した numeric な正誤判定には使わない。
"""

from __future__ import annotations

import re


# ------------------------------------------------------------------
# 冒頭 Hook 判定用パターン
# ------------------------------------------------------------------
_CONTRAST_PATTERNS = [
    r"しかし",
    r"だが",
    r"従来",
    r"限界",
    r"にもかかわらず",
    r"の壁",
    r"打破",
    r"超える",
]

_LOCUS_PATTERNS = [
    # 研究機関
    r"研究室",
    r"研究所",
    r"研究院",
    # 学術
    r"大学",
    r"学部",
    r"教授",
    r"准教授",
    r"助教",
    r"先生",
    r"博士",
    r"医師",
    # 企業形態 — 「社」の誤検出を避けるため、
    # [...]{1,N}社 の greedy match は使わず明示的 suffix 列挙に絞る。
    # これで「社会」「社員」「社交」「社訓」等の漢語を拾わない。
    r"株式会社",
    r"有限会社",
    r"合同会社",
    r"[一-龥]{1,8}(電機|電子|電気|工業|製作所|化学|製薬|製鉄|重工"
    r"|製造|商事|運輸|建設|物産|銀行|証券|保険|商店)",
    # 既知大手社名 (grant 申請書で頻出するもののみ)
    r"三菱",
    r"日立",
    r"東芝",
    r"パナソニック",
    r"トヨタ",
    # プロジェクト・現場
    r"案件",
    r"工場",
    r"現場",
    r"企業",
    # 制度・資金源
    r"JSPS",
    r"JST",
    r"NEDO",
    r"MEXT",
    r"AMED",
    r"科研費",
    # 技術分野マーカー (grant 文脈で「具体 locus」扱い)
    r"PCB",
]

_GENERIC_TEMPLATE_PATTERN = r"^\s*本[研究申請書提案]{1,3}は.{0,40}?を(目的|目指)"

_DIGIT_PATTERN = r"\d+"


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
def grant_writing_hook_strength(text: str, hook_chars: int = 300) -> dict:
    """冒頭 (最初の hook_chars 字) が Hook として機能しているか診断。

    skill.md T1 (冒頭 Hook 強度) に基づき、冒頭テキストの以下要素を
    観察し、粗い score (0-10) と人間レビュアー風 comments を返す。

    観測項目:
    - 第一文の長さ (30-60 字が目安)
    - 数値の有無 (具体性の根拠)
    - 対立構造ワード (「しかし」「従来」「打破」等)
    - 現場・組織・人物ワード (「研究室」「教授」「JSPS」等)
    - 凡庸テンプレート (「本研究は〜を目的とする」)
    - タグライン (30-80 字の断言文)

    引数:
        text: 申請書本文 (全文または冒頭段落)
        hook_chars: 冒頭として解析する字数 (既定 300)

    返り値:
        dict: score / score_max / comments / observations / hint / source
    """
    if text is None:
        text = ""
    head = text[:hook_chars]

    # ---- observations ----
    # 第一文: 。または．で区切る
    sentences = [s.strip() for s in re.split(r"[。．]", head) if s.strip()]
    first_sentence = sentences[0] if sentences else ""
    first_sentence_len = len(first_sentence)

    has_digit_in_hook = bool(re.search(_DIGIT_PATTERN, head))
    has_contrast_word = any(re.search(p, head) for p in _CONTRAST_PATTERNS)
    has_concrete_locus = any(re.search(p, head) for p in _LOCUS_PATTERNS)
    starts_with_generic_template = bool(
        re.match(_GENERIC_TEMPLATE_PATTERN, head)
    )
    # タグライン: 30-80 字の断言文 (最初の文が該当するか)
    tagline_line_present = 30 <= first_sentence_len <= 80

    observations = {
        "hook_chars_analyzed": len(head),
        "first_sentence_len": first_sentence_len,
        "has_digit_in_hook": has_digit_in_hook,
        "has_contrast_word": has_contrast_word,
        "has_concrete_locus": has_concrete_locus,
        "starts_with_generic_template": starts_with_generic_template,
        "tagline_line_present": tagline_line_present,
    }

    # ---- score (粗い温度計) ----
    score = 0.0
    if 30 <= first_sentence_len <= 60:
        score += 2
    if has_digit_in_hook:
        score += 2
    if has_contrast_word:
        score += 2
    if has_concrete_locus:
        score += 2
    if starts_with_generic_template:
        score -= 3
    if tagline_line_present:
        score += 2
    score = max(0.0, min(10.0, score))

    # ---- comments (PRIMARY OUTPUT) ----
    comments: list[str] = []

    # 悪い観測 → 助言
    if starts_with_generic_template:
        comments.append(
            "「本研究は〜を目的とする」で始まる凡庸型。第一文を強い断言タグライン"
            "に置き換える (例: 「LLM が呼び出せる国産 OSS 電磁界ソルバを打ち立てる」)。"
        )
    if not has_digit_in_hook:
        comments.append(
            "冒頭に数値が無い。「500 kHz」「年間120億円」等の具体数値で重要性を"
            "裏付けると Hook が強くなる。"
        )
    if not has_contrast_word:
        comments.append(
            "冒頭に対立構造 (「しかし」「従来」「限界」「打破」等) が無い。"
            "問題の壁と、それを超える自分の主張を対比で示すと読者が引き込まれる。"
        )
    if not has_concrete_locus:
        comments.append(
            "冒頭に現場・組織・人物ワード (「〜研究室」「〜社」「JSPS」等) が無い。"
            "抽象論だけでなく具体的な locus を置くと審査員が情景を描きやすい。"
        )
    if first_sentence_len > 80:
        comments.append(
            f"第一文が長い ({first_sentence_len} 字)。80 字を超える冒頭文は"
            "読点疲労を招く。30-60 字の断言型タグラインに圧縮することを推奨。"
        )
    elif 0 < first_sentence_len < 15:
        comments.append(
            f"第一文が極端に短い ({first_sentence_len} 字)。Hook は 30-60 字"
            "程度の断言で情報密度を確保したい。"
        )
    if not tagline_line_present and first_sentence_len > 0:
        # タグライン不在を (他のコメントと重複しない限り) 通知
        if not (starts_with_generic_template or first_sentence_len > 80 or first_sentence_len < 15):
            comments.append(
                "第一文が 30-80 字の断言タグライン帯から外れている。"
                "冒頭 1 行で主張が立つよう圧縮したい。"
            )

    # 良い観測 → 静かな肯定
    if has_digit_in_hook and has_contrast_word:
        comments.append(
            "冒頭に数値と対立構造が揃っている。Hook 強度は十分。"
        )
    elif has_digit_in_hook and has_concrete_locus and tagline_line_present and not starts_with_generic_template:
        comments.append(
            "冒頭にタグライン・数値・具体 locus が揃っている。Hook として機能している。"
        )
    elif tagline_line_present and not starts_with_generic_template and len(comments) == 0:
        comments.append(
            "冒頭にタグライン相当の断言文がある。主張は立っている。"
        )

    # 入力が短すぎる等で何も生成されない場合のフォールバック
    if not comments:
        if len(head) < 30:
            comments.append(
                f"解析対象テキストが短い ({len(head)} 字)。Hook 強度を評価するに"
                "は冒頭 30 字以上が必要。"
            )
            comments.append(
                "冒頭を展開する段階で、数値・対立・現場 locus のいずれかを"
                "意識的に盛り込むと Hook が立ちやすい。"
            )
        else:
            comments.append(
                "冒頭の Hook 要素が判定困難。skill.md T1 の基準を直接参照して"
                "人間判断で補完すること。"
            )

    # 最大 6 個に制限
    comments = comments[:6]

    # 少なくとも 2 個を担保 (単純な肯定コメントだけの場合に補う)
    if len(comments) < 2:
        comments.append(
            "score は粗い指標。skill.md T1 の判定基準で最終確認を推奨。"
        )

    hint = (
        "score は粗い温度計。9 以上は誤差範囲、6 以下は改善サイン。"
        "最終判断は comments を読み、スキル (skill.md T1) の判定基準と照合すること。"
        "score を 10 に近づける最適化ゲームに陥らないこと。"
    )

    return {
        "score": float(score),
        "score_max": 10,
        "comments": comments,
        "observations": observations,
        "hint": hint,
        "source": "skill.md T1 (冒頭 Hook 強度) / 木下『理科系の作文技術』原則 2 (重点先行)",
    }
