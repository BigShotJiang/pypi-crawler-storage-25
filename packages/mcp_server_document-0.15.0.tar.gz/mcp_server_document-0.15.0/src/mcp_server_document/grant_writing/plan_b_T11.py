"""Plan B T11: 上積み軌道・Vision・頂点終了診断 (grant_writing_continuity_check).

skill.md B (上積みの示し方) / Vision 段落 / NG パターン 4 (頂点終了) に基づく
粗い温度計。これまで〜さらに/継続語/Vision 語/完結語 の有無と分布を見る。

設計方針:
- score は 0-10 の粗い温度計。構造語の有無を機械的に数えるだけ。
- PRIMARY OUTPUT は comments (人間レビュアー風の助言文)。
- observations は raw measurement。自動化した numeric な正誤判定には使わない。
"""

from __future__ import annotations

import re


# ------------------------------------------------------------------
# パターン定義
# ------------------------------------------------------------------
# 「これまで XX を {確立|...} 〜 {さらに|次に|本研究では|発展}」
# 文跨ぎも許容 (これまで〜確立してきた。さらに〜) — [\s\S] で 。 を含む
# あらゆる文字を許可。アンカー間の距離は各 150 字以内に制限し、
# 遠距離ノイズマッチを避ける。
_UPTRAJECTORY_PATTERN = re.compile(
    r"これまで[\s\S]{0,150}(?:確立|構築|実現|達成|開発|実証)"
    r"[\s\S]{0,150}(?:さらに|次に|本研究では|発展)"
)

# 継続語
_CONTINUITY_KEYWORDS = [
    "さらに",
    "次の",
    "継続",
    "発展",
    "波及",
    "展開",
    "拡張",
    "広げる",
]

# Vision 語 (未来像)
_VISION_KEYWORDS = [
    "景色",
    "展望",
    "未来像",
    "拓く",
    "取り戻す",
    "見据える",
]

# 頂点終了語 (完結) — 「完了」単独はノイズが多いので強い形だけ
_TERMINATION_KEYWORDS = [
    "完結する",
    "最終的に",
    "以上で",
    "完了して終わる",
    "本研究をもって閉じる",
]


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _split_sentences_with_pos(text: str) -> list[tuple[int, str]]:
    """Split by 。or．preserving starting position of each sentence."""
    results: list[tuple[int, str]] = []
    start = 0
    for m in re.finditer(r"[。．]", text):
        end = m.end()
        chunk = text[start:end].strip()
        if chunk:
            # pos = offset where stripped sentence starts
            raw = text[start:end]
            lead_ws = len(raw) - len(raw.lstrip())
            results.append((start + lead_ws, chunk))
        start = end
    # trailing fragment without period
    if start < len(text):
        raw = text[start:]
        chunk = raw.strip()
        if chunk:
            lead_ws = len(raw) - len(raw.lstrip())
            results.append((start + lead_ws, chunk))
    return results


def _find_sentences_containing(
    text: str, keywords: list[str]
) -> list[dict]:
    """Return [{pos, text}] for sentences containing any of keywords."""
    hits: list[dict] = []
    for pos, sent in _split_sentences_with_pos(text):
        if any(kw in sent for kw in keywords):
            hits.append({"pos": pos, "text": sent})
    return hits


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
def grant_writing_continuity_check(text: str) -> dict:
    """skill.md「上積み軌道」「Vision 段落」「頂点終了 NG」の定量診断。

    これまで〜さらに/継続語/Vision 語/完結語 の有無と分布を見る。

    引数:
        text: 申請書本文

    返り値:
        dict: score / score_max / comments / observations / hint / source
    """
    if text is None:
        text = ""

    # ---- observations ----
    # uptrajectory: これまで〜確立/構築/... 〜さらに/次に/...
    uptrajectory_phrases: list[dict] = []
    for m in _UPTRAJECTORY_PATTERN.finditer(text):
        uptrajectory_phrases.append({"pos": m.start(), "text": m.group(0)})

    # continuity words: 全体 count と breakdown
    breakdown: dict[str, int] = {}
    for kw in _CONTINUITY_KEYWORDS:
        breakdown[kw] = len(re.findall(re.escape(kw), text))
    continuity_word_count = sum(breakdown.values())

    # vision sentences
    vision_sentences = _find_sentences_containing(text, _VISION_KEYWORDS)

    # termination signals
    termination_signals = _find_sentences_containing(text, _TERMINATION_KEYWORDS)

    observations = {
        "uptrajectory_phrases": uptrajectory_phrases,
        "continuity_word_count": continuity_word_count,
        "continuity_word_breakdown": breakdown,
        "vision_sentences": vision_sentences,
        "termination_signals": termination_signals,
    }

    # ---- score ----
    score = 5.0
    if len(uptrajectory_phrases) >= 1:
        score += 3
    if continuity_word_count >= 3:
        score += 2
    if len(vision_sentences) >= 1:
        score += 2
    if len(termination_signals) >= 1:
        score -= 4
    score = max(0.0, min(10.0, score))

    # ---- comments ----
    comments: list[str] = []

    if len(uptrajectory_phrases) == 0:
        comments.append(
            "「これまで〜確立してきた、さらに〜へ」型の上積み軌道記述が無い。"
            "申請書は既存実績の上に新規価値を積む構造が標準 "
            "(skill.md B. 上積みの示し方)。"
        )
    else:
        comments.append(
            f"上積み軌道 {len(uptrajectory_phrases)} 件検出。"
            "既存実績→新規価値の流れが読める。"
        )

    if len(vision_sentences) == 0:
        comments.append(
            "Vision 段落が無い。「本研究が拓く景色」"
            "「Motor 領域で実証した〜を PCB 領域で再現する」のような"
            "未来像を §5 相当に配置 (skill.md Case 2)。"
        )

    if len(termination_signals) >= 1:
        comments.append(
            "「完結」「最終的に」等の頂点終了語が検出された。"
            "申請書は次の科研費・論文・共同研究へ繋ぐ『連続軌道』で"
            "締めるのが標準 (skill.md NG4)。"
        )

    if continuity_word_count < 3 and len(termination_signals) == 0:
        comments.append(
            f"継続語 (さらに/次の/継続/発展/波及/展開/拡張/広げる) "
            f"が {continuity_word_count} 件と少ない。"
            "採択後の展開・波及を示す語を散りばめたい。"
        )

    # all good
    if (
        len(uptrajectory_phrases) >= 1
        and continuity_word_count >= 3
        and len(vision_sentences) >= 1
        and len(termination_signals) == 0
    ):
        comments.append(
            "継続軌道・Vision・頂点終了回避、いずれも良好。"
        )

    # 2-5 comments 担保
    comments = comments[:5]
    if len(comments) < 2:
        comments.append(
            "score は粗い指標。skill.md B / Case 2 の Vision 実例で"
            "最終確認を推奨。"
        )

    hint = (
        "score は構造語の有無ベース。実際の論理整合は別物 "
        "(「さらに〜」が書いてあっても中身が薄ければダメ)。"
        "comments と skill.md Case 1/2/3 の Vision 実例を照合して判断。"
    )

    return {
        "score": float(score),
        "score_max": 10,
        "comments": comments,
        "observations": observations,
        "hint": hint,
        "source": "skill.md B (上積み) + Vision 段落 / NG パターン 4 (頂点終了)",
    }
