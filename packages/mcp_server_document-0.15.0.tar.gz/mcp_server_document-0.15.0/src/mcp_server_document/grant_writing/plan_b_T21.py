"""Plan B T21: 挑戦性を読み手に伝える 4 方策の実測
(grant_writing_challenge_4_strategies).

中安豪『申請書作成の理論』(2019) p.32 /
skill.md『挑戦性を読み手に伝える 4 方策』に基づき、
申請書本文に以下 4 方策が揃っているかを粗く検出する:

  (1) 分野の既存研究の体系的整理 — 変革すべき認識の提示・定義
  (2) 分野の課題に対する自分の見解 — 変革の必要性
  (3) 有益性のある将来像の提示     — 変革の方向性
  (4) 将来像に到達する道筋         — 変革の手段の提示

設計方針:
- keyword hit 数ではなく「カバー有無」で採点 (4 方策のうち幾つに
  何らかの言及があるか)。score = round((covered / 4) * 10, 1)。
- PRIMARY OUTPUT は comments (欠けている方策の 1-line fix)。
- keyword 検出は非常に粗い温度計。実質的な方策展開は body の論理で
  判断 — score 10 最適化ゲームには陥らないこと。
"""

from __future__ import annotations


# ------------------------------------------------------------------
# Keyword groups — 4 strategies
# ------------------------------------------------------------------
_STRATEGY_KEYWORDS: dict[str, list[str]] = {
    # (1) 分野の既存研究の体系的整理
    "systematic_review": [
        "体系的",
        "整理",
        "レビュー",
        "既存研究",
        "先行研究",
        "分野通念",
        "これまでの",
    ],
    # (2) 分野の課題に対する自分の見解
    "problem_view": [
        "課題",
        "問題",
        "限界",
        "不足",
        "未解決",
        "変革",
        "打破",
        "乗り越える",
    ],
    # (3) 有益性のある将来像の提示
    "vision": [
        "将来像",
        "ビジョン",
        "景色",
        "展望",
        "拓く",
        "未来",
        "新たな",
    ],
    # (4) 将来像に到達する道筋
    "roadmap": [
        "道筋",
        "ロードマップ",
        "計画",
        "段階",
        "フェーズ",
        "マイルストーン",
        "手順",
    ],
}


# Labels (Japanese) for comments
_STRATEGY_LABELS: dict[str, str] = {
    "systematic_review": "既存研究の体系的整理",
    "problem_view": "分野の課題に対する自分の見解",
    "vision": "有益性のある将来像",
    "roadmap": "将来像に到達する道筋",
}


# Fix-it comments per missing strategy
_MISSING_COMMENTS: dict[str, str] = {
    "systematic_review": (
        "既存研究の体系的整理が不在。"
        "「〜領域はこれまで X / Y / Z の方向で発展してきた」と"
        "先行研究を構造化して示す (中安豪 方策 1)。"
    ),
    "problem_view": (
        "分野の課題に対する自分の見解が不在。"
        "「既存手法は X の点で限界がある」と著者の判断を明示 "
        "(中安豪 方策 2)。"
    ),
    "vision": (
        "有益性のある将来像が不在。"
        "「本研究が拓く景色は〜」と 5 年後のユーザー便益を描く "
        "(中安豪 方策 3)。"
    ),
    "roadmap": (
        "将来像に到達する道筋が不在。"
        "フェーズ分け or 年度別マイルストーン + 手段を列挙 "
        "(中安豪 方策 4)。"
    ),
}


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
def _find_hits(text: str, keywords: list[str], max_samples: int = 3) -> list[str]:
    """Return up to `max_samples` distinct keywords that appear in text."""
    hits: list[str] = []
    for kw in keywords:
        if kw in text:
            hits.append(kw)
            if len(hits) >= max_samples:
                break
    return hits


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
def grant_writing_challenge_4_strategies(text: str) -> dict:
    """挑戦的研究 (開拓・萌芽) + 基盤系で有効な中安豪 p.32 の 4 方策が
    本文にそろっているかを実測:
    (1) 分野の既存研究の体系的整理, (2) 分野の課題に対する自分の見解,
    (3) 有益性のある将来像の提示, (4) 将来像に到達する道筋。

    引数:
        text: 申請書本文 (全文)

    返り値:
        dict: score / score_max / comments / observations / hint / source
    """
    if text is None:
        text = ""

    # ---- observations: hits per strategy ----
    strategies: dict[str, list[str]] = {}
    for sid, kws in _STRATEGY_KEYWORDS.items():
        strategies[sid] = _find_hits(text, kws, max_samples=3)

    covered_strategies = [sid for sid, hits in strategies.items() if hits]
    missing_strategies = [sid for sid, hits in strategies.items() if not hits]
    coverage_count = len(covered_strategies)

    observations = {
        "strategies": strategies,
        "covered_strategies": covered_strategies,
        "missing_strategies": missing_strategies,
        "coverage_count": coverage_count,
    }

    # ---- score ----
    score = round((coverage_count / 4) * 10, 1)

    # ---- comments (PRIMARY OUTPUT) ----
    comments: list[str] = []

    if coverage_count == 4:
        comments.append(
            "4 方策すべて言及あり。挑戦的研究として評価され得る構造。"
        )
    elif coverage_count == 3:
        comments.append(
            "4 方策中 3 方策カバー。基盤系なら十分、"
            "挑戦的なら残る 1 方策を補強。"
        )

    # 欠けている方策ごとに 1-line fix (最大 3 件)
    for sid in missing_strategies[:3]:
        comments.append(_MISSING_COMMENTS[sid])

    # 2-5 comments を保証
    if len(comments) < 2:
        # coverage_count == 4 で 1 件しか出なかった場合の補足
        labels = "・".join(_STRATEGY_LABELS[s] for s in covered_strategies)
        comments.append(
            f"カバー済み方策: {labels}。"
            "keyword hit ベースの粗い検出のため、"
            "各方策が実質的に展開されているか本文で確認。"
        )
    comments = comments[:5]

    hint = (
        "4 方策 keyword のどれかが 1 回でもヒットすればカバー扱いの粗い検出。"
        "実質的な『方策の展開』は body の論理で判断 — "
        "keyword hit だけで安心しない。"
        "挑戦的研究 (開拓・萌芽) では 4/4 必須。"
        "基盤系では 3/4 でも採択例あり。"
    )
    source = (
        "中安豪『申請書作成の理論』(2019) p.32 / "
        "skill.md 『挑戦性を読み手に伝える 4 方策』"
    )

    return {
        "score": float(score),
        "score_max": 10,
        "comments": comments,
        "observations": observations,
        "hint": hint,
        "source": source,
    }
