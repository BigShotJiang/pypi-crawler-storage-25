"""Plan B T20 — 研究遂行能力セクション業績要素実測.

skill.md 新様式欄別構成 (応募者の研究遂行能力及び研究環境, 2 頁割当て) /
中安豪『申請書作成の理論』(2019, Robust Japan) に基づく。

設計方針:
- 「研究遂行能力」等のセクション見出しを検出し、その範囲内で業績要素を照合する。
- 見出し不在なら全文を対象にフォールバックし、section_detected=False を立てる。
- 8 カテゴリ (論文/資金/国際/OSS/受賞/学会/特許/招待講演) の粗い keyword 照合。
- score は 0-10 の粗い温度計。covered_categories / 8 の比例配分。
- PRIMARY OUTPUT は comments (人間レビュアー風の助言文)。
"""

from __future__ import annotations

import re


_SOURCE = (
    "中安豪『申請書作成の理論』(2019, Robust Japan) — "
    "新様式欄別構成 / skill.md 中安豪セクション"
)

_HINT = (
    "keyword 照合ベースの粗い検出。『論文』が 1 回書かれているだけで papers カテゴリは"
    "カバー扱いになる — 充実度は別途 body 読込で確認。"
    "分野によっては patents / OSS が不要なこともあるため、missing 自体が罰則ではない。"
)


# ---- セクション見出し regex ---------------------------------------------
# 「研究遂行能力」「研究環境」「これまでの研究活動」「業績」等
# 先頭の番号・記号 (e.g. "3. ", "(2) ", "■", "■") は許容
_SECTION_HEADINGS = [
    "研究遂行能力",
    "研究環境",
    "これまでの研究活動",
    "これまでの研究",
    "業績",
    "研究業績",
    "応募者の研究遂行能力",
]

# 次のセクションへの境界語 (research plan body に典型)
_NEXT_SECTION_MARKERS = [
    "本研究の目的",
    "研究目的",
    "研究の目的",
    "研究の背景",
    "研究計画",
    "研究の方法",
    "研究方法",
    "着想に至った経緯",
    "研究経費",
    "参考文献",
]


# ---- カテゴリ keyword テーブル ----------------------------------------
# keyword は大小区別せず部分一致で照合 (日本語は case-insensitive に影響しない)
_CATEGORY_KEYWORDS: dict[str, list[str]] = {
    "papers": [
        "論文", "paper", "掲載", "採録", "published", "査読",
        "journal", "原著", "筆頭著者",
    ],
    "funding": [
        "科研費", "助成金", "JST", "NEDO", "AMED", "採択", "PI", "代表",
    ],
    "international": [
        "国際会議", "international", "海外", "招へい", "招待講演",
        "invited", "国際共同研究",
    ],
    "oss": [
        "OSS", "GitHub", "オープンソース", "公開", "release", "実装公開",
    ],
    "awards": [
        "受賞", "best", "優秀", "奨励賞", "表彰", "fellow",
    ],
    "societies": [
        "学会", "IEEE", "IEEJ", "APS", "ACM", "IEE", "論文誌",
    ],
    "patents": [
        "特許", "patent", "出願", "登録済",
    ],
    "invited_talks": [
        "招待講演", "招待", "plenary", "keynote", "基調講演",
    ],
}

# 注: missing 時の具体 suggestion (max 3)
_MISSING_SUGGESTIONS: dict[str, str] = {
    "papers": "論文業績の記述が薄い。筆頭著者 / 査読付き / journal 名 / 年を列挙。",
    "funding": "獲得資金の記述が無い。科研費・財団助成等、PI / 分担の別を含めて列挙。",
    "international": "国際交流・招へい記録が無い。国際共著者 / 海外機関滞在 / 招待講演を足す。",
    "oss": "OSS・公開成果が無い。GitHub URL や release 実績を明示すると効果的。",
    "awards": "受賞・表彰が無い。奨励賞・若手賞等、小さいものでも記述価値あり。",
    "societies": "学会活動が無い。主要学会 (IEEE / IEEJ 等) の活動を足す。",
    "patents": "特許・実装成果が無い。該当分野なら明示。",
    "invited_talks": "招待講演が無い。分野外のシニアから声がかかる機会は信頼の証。",
}


def _find_section_range(text: str) -> tuple[bool, list[int] | None]:
    """研究遂行能力系の見出しを検出し、その範囲 [start, end] を返す.

    Returns:
        (section_detected, [start, end] or None)
          start は見出し行の開始位置、end は次の大見出しまで or text 末尾。
    """
    if not text:
        return False, None

    # 最初にマッチした見出しを採用 (出現順)
    best_start: int | None = None
    for kw in _SECTION_HEADINGS:
        idx = text.find(kw)
        if idx < 0:
            continue
        if best_start is None or idx < best_start:
            best_start = idx

    if best_start is None:
        return False, None

    # 次の大見出しを検索 (best_start の後ろで最初にヒットしたもの)
    next_idx: int | None = None
    for kw in _NEXT_SECTION_MARKERS:
        # section_heading 自身の直後から探索
        search_from = best_start + 1
        pos = text.find(kw, search_from)
        if pos < 0:
            continue
        if next_idx is None or pos < next_idx:
            next_idx = pos

    end = next_idx if next_idx is not None else len(text)
    return True, [best_start, end]


def _count_categories(segment: str) -> dict[str, int]:
    """segment に対して各カテゴリの keyword ヒット数を集計する.

    日本語 keyword は case-sensitive に、英字 keyword は case-insensitive に
    部分一致で数える。
    """
    counts: dict[str, int] = {}
    if segment is None:
        segment = ""
    segment_lower = segment.lower()

    for cat, kws in _CATEGORY_KEYWORDS.items():
        total = 0
        for kw in kws:
            # ASCII のみの keyword は lower 比較
            if all(ord(c) < 128 for c in kw):
                total += segment_lower.count(kw.lower())
            else:
                total += segment.count(kw)
        counts[cat] = total
    return counts


def grant_writing_applicant_credentials_check(text: str) -> dict:
    """研究遂行能力セクションに業績要素が記載されているか実測。

    論文/資金/国際交流/OSS/受賞/学会/特許/招待講演 の 8 カテゴリを
    keyword 照合で粗く検出する。中安豪 (2019) スタイルの新様式攻略に基づく。

    Args:
        text: 申請書本文 (全文)。

    Returns:
        dict: score / score_max / comments / observations / hint / source
    """
    if text is None:
        text = ""

    # ---- section detection ----
    section_detected, section_range = _find_section_range(text)

    if section_detected and section_range is not None:
        segment = text[section_range[0]:section_range[1]]
    else:
        segment = text  # fallback: whole text

    # ---- category counts ----
    credentials = _count_categories(segment)

    covered = [cat for cat, n in credentials.items() if n >= 1]
    missing = [cat for cat, n in credentials.items() if n == 0]
    total_cat = len(covered)

    # ---- scoring ----
    if not section_detected and total_cat == 0:
        score = 2.0
    else:
        score = round((total_cat / 8) * 10, 1)

    # clamp [0, 10]
    if score < 0:
        score = 0.0
    if score > 10:
        score = 10.0

    # ---- comments ----
    comments: list[str] = []

    if not section_detected:
        comments.append(
            "研究遂行能力の見出し (「研究遂行能力」「業績」等) が無い。"
            "新様式では 2 頁割当てで必須の欄。"
        )

    # missing カテゴリの suggestion (最大 3 件)
    suggestion_order = [
        "papers", "funding", "international", "oss",
        "awards", "societies", "invited_talks", "patents",
    ]
    missing_suggestions_added = 0
    for cat in suggestion_order:
        if missing_suggestions_added >= 3:
            break
        if cat in missing:
            msg = _MISSING_SUGGESTIONS.get(cat)
            if msg:
                comments.append(msg)
                missing_suggestions_added += 1

    # all good
    if total_cat >= 6:
        comments.append("業績の多面性が十分。身上調査書として成立。")

    # 2-5 本に整える
    if len(comments) < 2:
        comments.append(
            "score は 8 カテゴリ中の被覆数に比例。"
            "missing 自体が罰則ではないが、分野相応かは body で確認。"
        )
    if len(comments) > 5:
        comments = comments[:5]

    observations = {
        "section_detected": section_detected,
        "section_range": section_range,
        "credentials": credentials,
        "covered_categories": covered,
        "missing_categories": missing,
        "total_category_count": total_cat,
    }

    return {
        "score": float(score),
        "score_max": 10,
        "comments": comments,
        "observations": observations,
        "hint": _HINT,
        "source": _SOURCE,
    }
