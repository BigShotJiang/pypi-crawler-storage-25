"""Jグランツ API 連携ツール群 (grant_writing モジュール内蔵).

デジタル庁公開 jGrants API (https://api.jgrants-portal.go.jp/exp/v1/public)
に直接アクセスし、公募探索 → 要領取得 → Phase 1 intake への受け渡しを
skill 内で完結させる。

Upstream 実装: https://github.com/digital-go-jp/jgrants-mcp-server (MIT)
API 利用規約: https://www.jgrants-portal.go.jp/open-api

本モジュールは vendor ではなく公開 API への独自再実装。stdlib (urllib) のみを
使用し追加のハード依存なし。markdown 変換は markitdown / pymupdf が
導入されていれば利用、未導入なら base64/text にフォールバックする。

環境変数:
    JGRANTS_API_BASE_URL : API base URL (default 公開 API)
    JGRANTS_FILES_DIR    : 添付ファイル保存 root (default ./jgrants_files)
"""
from __future__ import annotations

import base64
import json
import os
import pathlib
import re
import urllib.parse
import urllib.request
from datetime import datetime, timezone

DEFAULT_API_BASE = "https://api.jgrants-portal.go.jp/exp/v1/public"


def _api_base() -> str:
    return os.environ.get("JGRANTS_API_BASE_URL", DEFAULT_API_BASE).rstrip("/")


def _files_root() -> pathlib.Path:
    p = pathlib.Path(os.environ.get("JGRANTS_FILES_DIR", "./jgrants_files"))
    p.mkdir(parents=True, exist_ok=True)
    return p.resolve()


_UNSAFE_FILENAME = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def _safe_filename(name: str) -> str:
    s = _UNSAFE_FILENAME.sub("_", name).strip(" .")
    return s or "unnamed"


def _safe_subdir(root: pathlib.Path, subsidy_id: str) -> pathlib.Path:
    sid = re.sub(r"[^A-Za-z0-9_\-]", "", subsidy_id)[:18] or "unknown"
    sub = (root / sid).resolve()
    if not str(sub).startswith(str(root)):
        raise ValueError("path traversal blocked")
    sub.mkdir(parents=True, exist_ok=True)
    return sub


def _http_get_json(url: str, timeout: float = 30.0) -> dict:
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 (public gov API)
        body = r.read()
    return json.loads(body.decode("utf-8"))


def _parse_yen(raw) -> int:
    if raw in (None, ""):
        return 0
    s = str(raw)
    s = re.sub(r"[,\s円￥]", "", s)
    m = re.search(r"-?\d+", s)
    return int(m.group(0)) if m else 0


def _limit_band(yen: int) -> str:
    if yen <= 0:
        return "unknown"
    if yen <= 1_000_000:
        return "~100万"
    if yen <= 10_000_000:
        return "~1000万"
    if yen <= 100_000_000:
        return "~1億"
    return "1億+"


# ------------------------------------------------------------------
# Tools
# ------------------------------------------------------------------
def grant_writing_jgrants_ping() -> dict:
    """Jグランツ公開 API への疎通確認。

    /subsidies に軽量クエリを投げて応答があるかだけ見る。
    ネットワーク/API 障害の一次切り分け用。
    """
    url = _api_base() + "/subsidies?" + urllib.parse.urlencode(
        {"keyword": "補助金", "acceptance": "1",
         "sort": "created_date", "order": "DESC"}
    )
    try:
        data = _http_get_json(url, timeout=10.0)
    except Exception as e:
        return {"status": "error", "api_base": _api_base(), "detail": str(e)}
    return {
        "status": "ok",
        "api_base": _api_base(),
        "sample_count": len(data.get("result") or []),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def grant_writing_search_subsidies(
    keyword: str,
    industry: str | None = None,
    target_area_search: str | None = None,
    target_number_of_employees: str | None = None,
    use_purpose: str | None = None,
    sort: str = "acceptance_end_datetime",
    order: str = "ASC",
    acceptance: int = 1,
) -> dict:
    """Jグランツ公募一覧を keyword で検索。

    Phase 0 (opportunity discovery) の主役。結果から subsidy_id を選び
    `grant_writing_get_subsidy_detail` で公募要領を取得 → Phase 1 intake
    の素材にする。

    Args:
        keyword: 2 文字以上必須 (例: "電磁気" "電源" "研究開発")
        industry: 業種 (例: "学術研究、専門・技術サービス業")
        target_area_search: 対象地域 (例: "大阪府" "全国")
        target_number_of_employees: "5名以下" / "20名以下" / ...
        use_purpose: 利用目的 (例: "新たな事業を行いたい")
        sort: acceptance_end_datetime / acceptance_start_datetime / created_date
        order: ASC / DESC
        acceptance: 0=全件 / 1=受付中のみ (default)

    Returns:
        dict: count, result[{id,title,subsidy_max_limit,acceptance_start/end,...}]
    """
    if not keyword or len(keyword) < 2:
        return {"error": "keyword must be 2+ characters"}
    params: dict[str, str] = {
        "keyword": keyword,
        "sort": sort,
        "order": order,
        "acceptance": str(int(acceptance)),
    }
    for k, v in (
        ("industry", industry),
        ("target_area_search", target_area_search),
        ("target_number_of_employees", target_number_of_employees),
        ("use_purpose", use_purpose),
    ):
        if v:
            params[k] = v
    url = _api_base() + "/subsidies?" + urllib.parse.urlencode(params)
    try:
        data = _http_get_json(url)
    except Exception as e:
        return {"error": str(e), "url": url}
    items = data.get("result") or []
    compact = [
        {
            "id": it.get("id"),
            "title": it.get("title") or it.get("name"),
            "subsidy_max_limit": it.get("subsidy_max_limit"),
            "acceptance_start": it.get("acceptance_start_datetime"),
            "acceptance_end": it.get("acceptance_end_datetime"),
            "target_area_search": it.get("target_area_search"),
            "target_industry": it.get("target_industry"),
            "target_number_of_employees": it.get("target_number_of_employees"),
        }
        for it in items
    ]
    return {"count": len(compact), "query": params, "result": compact}


def grant_writing_get_subsidy_detail(
    subsidy_id: str,
    save_files: bool = True,
) -> dict:
    """補助金詳細を取得し、添付 (要領・手引・様式) をローカル保存。

    save_files=True のとき、API レスポンスに含まれる base64 添付
    (application_guidelines / outline_of_grant / application_form) を
    JGRANTS_FILES_DIR/{subsidy_id}/ に書き出す。保存後は
    `grant_writing_get_subsidy_file_content` で中身を読み取れる。

    Args:
        subsidy_id: 18 文字以下の補助金 ID
        save_files: 添付をローカル保存するか (default True)

    Returns:
        dict: 詳細フィールド (base64 は返さない) + _saved_files + _files_dir
    """
    if not subsidy_id or len(subsidy_id) > 18:
        return {"error": "subsidy_id must be 1-18 chars"}
    url = _api_base() + f"/subsidies/id/{urllib.parse.quote(subsidy_id)}"
    try:
        data = _http_get_json(url)
    except Exception as e:
        return {"error": str(e), "url": url}
    result = data.get("result")
    rec = result[0] if isinstance(result, list) and result else result
    if not rec or not isinstance(rec, dict):
        return {"error": "not found", "subsidy_id": subsidy_id, "url": url}

    saved: list[dict] = []
    if save_files:
        try:
            subdir = _safe_subdir(_files_root(), subsidy_id)
        except Exception as e:
            return {"error": f"cannot prepare save dir: {e}"}
        for bucket in ("application_guidelines", "outline_of_grant", "application_form"):
            for entry in (rec.get(bucket) or []):
                if not isinstance(entry, dict):
                    continue
                name = _safe_filename(str(entry.get("name") or "unnamed"))
                b64 = entry.get("data") or entry.get("file_data")
                if not b64:
                    continue
                try:
                    blob = base64.b64decode(b64)
                except Exception:
                    continue
                path = subdir / name
                try:
                    path.write_bytes(blob)
                except OSError as e:
                    saved.append({"bucket": bucket, "name": name,
                                  "error": f"write failed: {e}"})
                    continue
                saved.append({"bucket": bucket, "name": name,
                              "path": str(path), "bytes": len(blob)})

    slim = {k: v for k, v in rec.items()
            if k not in ("application_guidelines", "outline_of_grant", "application_form")}
    slim["_saved_files"] = saved
    slim["_files_dir"] = str(_files_root()) if save_files else None
    return slim


def grant_writing_get_subsidy_overview(
    keyword: str = "補助金",
    acceptance: int = 1,
    output_format: str = "json",
) -> dict | str:
    """受付中補助金の統計 (締切月別・金額帯別) を client-side で集計。

    Jグランツ公開 API には統計エンドポイントが無いため、/subsidies を
    広く叩いて Python 側で集計する。keyword が広いほど母集団が増える。

    Args:
        keyword: 検索 keyword (default "補助金" — できるだけ広く取る)
        acceptance: 0=全件 / 1=受付中のみ (default)
        output_format: "json" (dict) または "csv" (str)
    """
    base = grant_writing_search_subsidies(
        keyword=keyword, acceptance=acceptance,
        sort="acceptance_end_datetime", order="ASC",
    )
    if "error" in base:
        return base
    items = base.get("result", [])
    by_month: dict[str, int] = {}
    by_band: dict[str, int] = {}
    for it in items:
        end = (it.get("acceptance_end") or "")[:7]
        if end:
            by_month[end] = by_month.get(end, 0) + 1
        band = _limit_band(_parse_yen(it.get("subsidy_max_limit")))
        by_band[band] = by_band.get(band, 0) + 1
    overview = {
        "total": len(items),
        "by_acceptance_end_month": dict(sorted(by_month.items())),
        "by_subsidy_limit_band": by_band,
        "query": base.get("query"),
    }
    if output_format == "csv":
        lines = ["section,key,count"]
        for k, v in overview["by_acceptance_end_month"].items():
            lines.append(f"month,{k},{v}")
        for k, v in overview["by_subsidy_limit_band"].items():
            lines.append(f"limit_band,{k},{v}")
        return "\n".join(lines)
    return overview


def grant_writing_get_subsidy_file_content(
    subsidy_id: str,
    filename: str,
    return_format: str = "markdown",
) -> dict:
    """`grant_writing_get_subsidy_detail(save_files=True)` で保存済みの
    添付ファイルを読み出す。

    markdown 変換は markitdown が導入されていればそれを使用、PDF なら
    pymupdf にフォールバック、いずれも無ければ base64/text を案内する。

    Args:
        subsidy_id: 補助金 ID
        filename: subdir 内の実ファイル名
        return_format: "markdown" (default) / "base64" / "text"
    """
    if return_format not in ("markdown", "base64", "text"):
        return {"error": "return_format must be markdown|base64|text"}
    try:
        subdir = _safe_subdir(_files_root(), subsidy_id)
    except Exception as e:
        return {"error": str(e)}
    path = (subdir / _safe_filename(filename)).resolve()
    if not str(path).startswith(str(subdir)):
        return {"error": "path traversal blocked"}
    if not path.exists():
        return {
            "error": "file not found; call grant_writing_get_subsidy_detail first",
            "expected_path": str(path),
        }
    blob = path.read_bytes()

    if return_format == "base64":
        return {"format": "base64", "path": str(path),
                "content": base64.b64encode(blob).decode("ascii")}

    if return_format == "text":
        try:
            return {"format": "text", "path": str(path),
                    "content": blob.decode("utf-8")}
        except UnicodeDecodeError:
            return {"error": "binary file — use markdown or base64",
                    "path": str(path)}

    # markdown
    try:
        from markitdown import MarkItDown  # type: ignore

        md = MarkItDown().convert(str(path))
        return {"format": "markdown", "path": str(path),
                "converter": "markitdown", "content": md.text_content}
    except ImportError:
        pass
    except Exception as e:
        return {"error": f"markitdown failed: {e}", "path": str(path)}

    if path.suffix.lower() == ".pdf":
        try:
            import pymupdf  # type: ignore

            with pymupdf.open(str(path)) as doc:
                parts = [page.get_text() for page in doc]
            return {"format": "markdown", "path": str(path),
                    "converter": "pymupdf",
                    "content": "\n\n".join(parts)}
        except ImportError:
            pass
        except Exception as e:
            return {"error": f"pymupdf failed: {e}", "path": str(path)}

    return {
        "error": "markdown unavailable — `pip install markitdown` or retry with "
                 "return_format='base64' / 'text'",
        "path": str(path),
    }
