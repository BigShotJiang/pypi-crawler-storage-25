"""Plan B T22: \\uline overflow risk detector (grant_writing_check_uline_overflow_risk).

ulem パッケージの `\\uline` / `\\underline` / `\\uwave` / `\\uuline` 等は
**和文テキストの行分割に非対応**。日本語の長い範囲に下線を引くと、
行送り幅を超えた際に右端からはみ出す、or 段落境界で破綻する。

本ツールは tex ソースから長すぎる下線指定 (既定 30 字超 or 改行含む) を
検出し、以下の 3 段階対策を comments で提示する:

1. **短い単位に分割** (パッケージ変更不要、最短手)
   例: `\\uline{重要}キーワード\\uline{〇〇}`
2. **パッケージ差し替え** (和文対応パッケージへ)
   - jumoline.sty (宮坂昌之) — pLaTeX で最実用、character-by-character 処理
   - uline--.sty (吉永哲巳) — 和文・欧文両対応、下線/上線/二重線/打ち消し/波線
   - udline.sty — 装飾下線含む複数行対応
   - y-ulem.sty — 行分割 + 数式内下線対応
3. **`\\mbox{...}` でラップ** — 改行禁止で一塊扱い
   (短い範囲のみ、overflow リスクは残る)

出典: 大石他『下線に関するマクロ比較』、奥村 TeX Forum 1716、TeX Wiki
(TeX が苦手とする処理)。
"""

from __future__ import annotations

import pathlib
import re

_UNDERLINE_MACROS = [
    "uline",
    "underline",
    "uwave",
    "uuline",
    "sout",
    "dashuline",
    "dotuline",
    "xout",
]

_RE_OPEN = re.compile(
    r"\\(" + "|".join(_UNDERLINE_MACROS) + r")\{"
)
# Strip LaTeX comments (% to EOL, but not \%)
_RE_COMMENT = re.compile(r"(?<!\\)%[^\n]*")


def _scan_balanced_arg(text: str, start: int) -> tuple[str, int]:
    """text[start] が `{` の直後に位置すると仮定し、balanced `{...}` の
    閉じ括弧までスキャンして content と新しい index を返す。

    `\\{` / `\\}` / `\\\\` 等のエスケープは skip、
    ネスト括弧は depth でカウント。
    """
    depth = 1
    i = start
    n = len(text)
    while i < n and depth > 0:
        c = text[i]
        if c == "\\" and i + 1 < n:
            # エスケープ: \ の次の 1 文字を一緒に skip
            i += 2
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return text[start:i], i + 1
        i += 1
    # 閉じ括弧未検出
    return text[start:i], i


def grant_writing_check_uline_overflow_risk(
    tex_path: str,
    max_chars: int = 30,
) -> dict:
    """\\uline{...} 等の下線範囲が長すぎて行送りからはみ出すリスクを検出。

    ulem の下線系マクロは和文の行分割に非対応。本ツールは tex ソースから
    下線指定を抽出し、内容が `max_chars` 字超 or 改行を含む箇所を flag。

    Args:
        tex_path: 対象 tex ファイルパス (絶対 or cwd 相対)。
        max_chars: 下線内容の警告字数閾値。既定 30 字 (≒ 1 行の約 1/3)。

    Returns:
        dict with score / comments / observations / hint / source:
            - observations.total_underlines: 全下線指定数
            - observations.risky_count: はみ出しリスクあり件数
            - observations.risky_findings: list[{macro, pos, char_count,
              line_count, content_head}]
            - observations.max_chars_threshold: 使用した閾値
    """
    if tex_path is None:
        return {
            "score": 0.0,
            "score_max": 10,
            "comments": ["tex_path が None。ファイルパスを渡してください。"],
            "observations": {"error": "tex_path is None"},
            "hint": "",
            "source": "",
        }

    p = pathlib.Path(tex_path)
    if not p.exists():
        return {
            "score": 0.0,
            "score_max": 10,
            "comments": [f"ファイルが見つかりません: {tex_path}"],
            "observations": {"error": "file_not_found", "path": str(p)},
            "hint": "",
            "source": "",
        }

    raw = p.read_text(encoding="utf-8", errors="replace")
    # コメントを事前に除去 (コメントアウトされた \uline は対象外)
    text = _RE_COMMENT.sub("", raw)

    findings: list[dict] = []
    total = 0
    for m in _RE_OPEN.finditer(text):
        total += 1
        macro_name = m.group(1)
        content, _end = _scan_balanced_arg(text, m.end())
        char_count = len(content)
        line_count = content.count("\n") + 1
        if char_count > max_chars or line_count >= 2:
            findings.append({
                "macro": macro_name,
                "pos": m.start(),
                "char_count": char_count,
                "line_count": line_count,
                "content_head": content[:60]
                + ("..." if len(content) > 60 else ""),
            })

    risky = len(findings)

    # ---- score ----
    if total == 0:
        score = 10.0
    else:
        score = round((1 - risky / total) * 10, 1)

    # ---- comments (PRIMARY) ----
    comments: list[str] = []
    if risky > 0:
        for f in findings[:3]:
            comments.append(
                f"\\{f['macro']}{{...}} が {f['char_count']} 字 "
                f"(閾値 {max_chars} 字)、行送りはみ出しリスク: "
                f"「{f['content_head']}」"
            )
        if risky > 3:
            comments.append(
                f"他 {risky - 3} 件の長い下線指定あり。"
                "risky_findings で全件確認を。"
            )
        comments.append(
            "対策優先順位: "
            "(1) 短い単位に分割 (\\uline{重要}キーワード\\uline{〇〇}) — "
            "パッケージ変更不要で最短手。"
            "(2) jumoline.sty / uline--.sty / udline.sty に差し替え — "
            "和文の行分割に対応。"
            "(3) \\mbox{...} でラップ — 改行禁止 (短い範囲のみ、overflow "
            "リスクは残る)。"
        )
    else:
        if total > 0:
            comments.append(
                f"下線 {total} 箇所、いずれも {max_chars} 字以下 "
                "(改行含まず)。ulem 単体で安全な範囲。"
            )
        else:
            comments.append("下線指定なし。overflow リスクなし。")
        comments.append(
            "参考: 和文で長い下線が必要になった場合は jumoline.sty "
            "(pLaTeX 向け) or uline--.sty (和洋両対応) への差し替えを推奨。"
        )

    return {
        "score": float(score),
        "score_max": 10,
        "comments": comments,
        "observations": {
            "file": str(p),
            "total_underlines": total,
            "risky_count": risky,
            "risky_findings": findings[:20],
            "max_chars_threshold": max_chars,
        },
        "hint": (
            "ulem の \\uline は和文の行分割に非対応。長い範囲は行送りから "
            "はみ出すか、段落境界で破綻する。"
            "jumoline / uline-- / udline パッケージに差し替えるか、"
            "短い単位に分割して回避するのが実用的。"
            "score は risky 比率の粗い温度計。閾値 max_chars は文書の "
            "版面幅で調整 (A4 本文 1 行 ≒ 40-48 字、下線 1 行に収めたいなら "
            "30 字目安)。"
        ),
        "source": (
            "ulem (Donald Arseneau) / jumoline (宮坂昌之) / "
            "uline-- (吉永哲巳) / udline (菅原) — "
            "大石他『下線に関するマクロ比較』、奥村 TeX Forum 1716、"
            "TeX Wiki 『TeX が苦手とする処理』"
        ),
    }
