"""Plan B T19: 冒頭 5W1H 充足率診断 (grant_writing_5w1h_coverage).

skill.md 定量閾値「5W1H 充足率 5/6 以上」/ 木下『理科系の作文技術』
原則 2 (重点先行) に基づく粗い温度計。

冒頭 scan_chars 字に 5W1H (誰/何/いつ/どこ/なぜ/どう) の手がかりが
揃っているかを keyword で診断する。

設計方針:
- score は 0-10 の粗い温度計。coverage_count / 6 を線形スケール。
- PRIMARY OUTPUT は comments (missing axis に対する助言文)。
- observations は raw measurement。自動化した numeric な正誤判定には使わない。
- keyword 照合は粗い判定であり、「申請者」が冒頭にあっても実際に役割が
  書かれているかは別問題 (T12 / skill.md T1 と併用する)。
"""

from __future__ import annotations

import re


# ------------------------------------------------------------------
# 5W1H 手がかり keyword
# ------------------------------------------------------------------
# who: 人物 or 組織
_WHO_PATTERNS: list[str] = [
    r"申請者",
    r"研究代表者",
    r"私",
    r"筆者",
    r"共同研究者",
    r"[一-龥]{1,8}教授",
    r"[一-龥]{1,8}博士",
    r"[一-龥]{1,8}社",
]

# what: 名詞系の具体テーマ語
_WHAT_PATTERNS: list[str] = [
    r"電磁界",
    r"AI",
    r"解析",
    r"設計",
    r"シミュレーション",
    r"OSS",
    r"LLM",
    r"最適化",
    r"制御",
    r"計測",
    r"実証",
]

# when: 時間軸マーカー
_WHEN_PATTERNS: list[str] = [
    r"令和\d+",
    r"令和[一二三四五六七八九十]+",
    r"R\d+",
    r"\d{4}年",
    r"本研究期間",
    r"\d+年以内",
    r"短期",
    r"中期",
    r"長期",
]

# where: 場所・locus
_WHERE_PATTERNS: list[str] = [
    r"大学",
    r"研究室",
    r"工場",
    r"現場",
    r"国内",
    r"国際",
    r"日本",
    r"海外",
]

# why: 動機・背景
_WHY_PATTERNS: list[str] = [
    r"なぜ",
    r"理由",
    r"課題",
    r"限界",
    r"必要性",
    r"重要",
    r"背景",
]

# how: 手法・アプローチ
_HOW_PATTERNS: list[str] = [
    r"[一-龥ぁ-んァ-ヶa-zA-Z0-9]{1,20}を用いて",
    r"[一-龥ぁ-んァ-ヶa-zA-Z0-9]{1,20}により",
    r"[一-龥ぁ-んァ-ヶa-zA-Z0-9]{1,20}によって",
    r"[一-龥ぁ-んァ-ヶa-zA-Z0-9]{1,20}を通じて",
    r"手法",
    r"アプローチ",
    r"方策",
]


_AXIS_DEFS: list[tuple[str, list[str]]] = [
    ("who", _WHO_PATTERNS),
    ("what", _WHAT_PATTERNS),
    ("when", _WHEN_PATTERNS),
    ("where", _WHERE_PATTERNS),
    ("why", _WHY_PATTERNS),
    ("how", _HOW_PATTERNS),
]


# axis → 助言文 (missing 時のコメント)
_MISSING_ADVICE: dict[str, str] = {
    "who": (
        "誰が (申請者/共同研究者/〜教授) 担当するかが冒頭で不明。"
        "研究者像を明示。"
    ),
    "what": (
        "何を対象とするか (具体テーマ: 電磁界解析/AI 自律設計 等) が"
        "冒頭に無い。分野キーワードを足す。"
    ),
    "when": (
        "いつ (年度/研究期間) が不在。"
        "「令和6-8年度」等の時間軸を冒頭で示す。"
    ),
    "where": (
        "どこで (大学/研究室/国際/現場) 行うかの locus が不在。"
    ),
    "why": (
        "なぜ (背景/課題/限界/必要性) の動機が冒頭で不鮮明。"
        "Hook の対立構造と連動させる。"
    ),
    "how": (
        "どう (手法/アプローチ/〜を用いて) の方法論が冒頭に無い。"
    ),
}


def _find_matches(head: str, patterns: list[str]) -> list[str]:
    """Return de-duplicated list of matched keyword strings for given patterns."""
    seen: list[str] = []
    for pat in patterns:
        for m in re.finditer(pat, head):
            hit = m.group(0)
            if hit and hit not in seen:
                seen.append(hit)
    return seen


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
def grant_writing_5w1h_coverage(text: str, scan_chars: int = 500) -> dict:
    """冒頭 scan_chars 字に 5W1H (誰/何/いつ/どこ/なぜ/どう) の手がかりが
    揃っているかを keyword で診断。skill.md 定量閾値「5W1H 充足率 5/6 以上」。

    引数:
        text: 申請書本文 (全文または冒頭段落)
        scan_chars: 冒頭として解析する字数 (既定 500)

    返り値:
        dict: score / score_max / comments / observations / hint / source
    """
    if text is None:
        text = ""
    head = text[:scan_chars]

    # ---- observations ----
    coverage: dict[str, list[str]] = {}
    for axis, patterns in _AXIS_DEFS:
        coverage[axis] = _find_matches(head, patterns)

    covered_axes = [axis for axis, hits in coverage.items() if len(hits) >= 1]
    missing_axes = [axis for axis, hits in coverage.items() if len(hits) == 0]
    coverage_count = len(covered_axes)

    observations = {
        "scan_chars_analyzed": len(head),
        "coverage": coverage,
        "covered_axes": covered_axes,
        "missing_axes": missing_axes,
        "coverage_count": coverage_count,
    }

    # ---- score ----
    score = round(coverage_count / 6 * 10, 1)

    # ---- comments (PRIMARY OUTPUT) ----
    comments: list[str] = []

    if coverage_count == 6:
        comments.append(
            "冒頭 5W1H 全軸カバー。申請書として情報密度は十分。"
        )
    elif coverage_count >= 5:
        comments.append(
            f"冒頭 5W1H は {coverage_count}/6 軸カバー、概ね良好。"
            "missing 軸があれば補強。"
        )
    else:
        # missing 軸について助言 (最大 3 件)
        for axis in missing_axes[:3]:
            comments.append(_MISSING_ADVICE[axis])

    # warn for very low coverage
    if coverage_count <= 3 and coverage_count < 6:
        comments.append(
            f"5W1H 充足率が {coverage_count}/6 と低い "
            "(skill.md 警告閾値 ≤3/6)。冒頭段落を書き直すレベルで"
            "情報密度を上げることを推奨。"
        )

    # 残り missing があれば (>=5/6 で肯定コメント出した後) 追記
    if coverage_count >= 5 and missing_axes:
        for axis in missing_axes[:2]:
            comments.append(_MISSING_ADVICE[axis])

    # 入力が短すぎる場合のフォールバック
    if len(head) < 30 and len(comments) < 2:
        comments.append(
            f"解析対象テキストが短い ({len(head)} 字)。"
            "5W1H 充足を評価するには冒頭 100 字以上が望ましい。"
        )

    # 2-5 comments 担保
    comments = comments[:5]
    if len(comments) < 2:
        comments.append(
            "score は粗い keyword 判定。最終確認は skill.md 定量閾値"
            "と comments を照合し人間判断で補完。"
        )

    hint = (
        "keyword 照合だけの粗い判定。「申請者」が冒頭にあっても実際に役割が"
        "書かれているとは限らない (T12 併用推奨)。"
        "keyword ヒット数だけ追わない — 5W1H の『中身』は comments と "
        "skill.md T1 で判定。"
    )

    return {
        "score": float(score),
        "score_max": 10,
        "comments": comments,
        "observations": observations,
        "hint": hint,
        "source": (
            "skill.md 定量閾値 (5W1H 充足率 5/6 以上) / "
            "木下原則 2 (重点先行)"
        ),
    }
