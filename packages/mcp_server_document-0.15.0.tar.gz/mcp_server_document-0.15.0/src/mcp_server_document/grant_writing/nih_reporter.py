"""NIH RePORTER 連携ツール (grant_writing モジュール内蔵).

米国 NIH の助成課題データベース。国際共著/共同研究候補の裏取り、
米国側研究動向の benchmarking に使う。認証不要 (public API)。

API doc: https://api.reporter.nih.gov/
主 endpoint: POST https://api.reporter.nih.gov/v2/projects/search

環境変数 NIH_REPORTER_BASE で base URL 上書き可。
"""
from __future__ import annotations

import json
import os
import urllib.request
from datetime import datetime, timezone

DEFAULT_BASE = "https://api.reporter.nih.gov"


def _base() -> str:
    return os.environ.get("NIH_REPORTER_BASE", DEFAULT_BASE).rstrip("/")


def _http_post_json(url: str, body: dict, timeout: float = 30.0) -> dict:
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        url, data=data, method="POST",
        headers={"Accept": "application/json",
                 "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310
        return json.loads(r.read().decode("utf-8"))


def grant_writing_nih_reporter_ping() -> dict:
    """NIH RePORTER 疎通確認 (最小クエリで 1 件だけ取る)."""
    try:
        data = _http_post_json(
            _base() + "/v2/projects/search",
            {"criteria": {"fiscal_years": [2024]},
             "limit": 1, "offset": 0},
            timeout=10.0,
        )
        return {
            "status": "ok",
            "base": _base(),
            "total": (data.get("meta") or {}).get("total"),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        return {"status": "error", "base": _base(), "detail": str(e)}


def grant_writing_nih_reporter_search(
    text_search: str | None = None,
    fiscal_years: list[int] | None = None,
    pi_names: list[str] | None = None,
    org_names: list[str] | None = None,
    activity_codes: list[str] | None = None,
    limit: int = 20,
    offset: int = 0,
) -> dict:
    """NIH RePORTER projects/search を叩く。

    Args:
        text_search: タイトル・abstract・terms 横断の自由文検索
        fiscal_years: 会計年度リスト (例: [2023, 2024])
        pi_names: PI 名リスト (例: ["Smith, John"])
        org_names: 組織名リスト (例: ["Stanford University"])
        activity_codes: activity code リスト (例: ["R01", "R21"])
        limit: 最大 500 (default 20)
        offset: 0 start

    Returns:
        dict: meta (total/offset/limit), results[] (compact view).
    """
    criteria: dict = {}
    if text_search:
        criteria["advanced_text_search"] = {
            "operator": "Or",
            "search_field": "all",
            "search_text": text_search,
        }
    if fiscal_years:
        criteria["fiscal_years"] = list(fiscal_years)
    if pi_names:
        criteria["pi_names"] = [{"any_name": n} for n in pi_names]
    if org_names:
        criteria["org_names"] = list(org_names)
    if activity_codes:
        criteria["activity_codes"] = list(activity_codes)

    body = {
        "criteria": criteria,
        "limit": max(1, min(limit, 500)),
        "offset": max(0, offset),
    }
    url = _base() + "/v2/projects/search"
    try:
        data = _http_post_json(url, body)
    except Exception as e:
        return {"error": str(e), "url": url}

    results = data.get("results") or []
    compact = [
        {
            "project_num": r.get("project_num") or r.get("core_project_num"),
            "title": r.get("project_title"),
            "pi": ", ".join(
                pi.get("full_name", "")
                for pi in (r.get("principal_investigators") or [])
            ) or None,
            "org": (r.get("organization") or {}).get("org_name"),
            "fiscal_year": r.get("fiscal_year"),
            "award_amount": r.get("award_amount"),
            "activity_code": r.get("activity_code"),
        }
        for r in results
    ]
    return {
        "meta": data.get("meta"),
        "query": body,
        "result": compact,
    }
