"""Plan B T10 — 木下原則1 目標規定文 (タグライン) 検出.

木下是雄『理科系の作文技術』原則 1 (p.28-30) に基づき、
冒頭 scan_chars 字の範囲で定型タグライン語尾を持つ文を列挙する。
申請書では Hook / Vision / タグラインがこれに該当する。
"""

from __future__ import annotations

import re
from typing import Optional


_SOURCE = "木下『理科系の作文技術』原則 1 (目標規定文) / skill.md T1-Hook 強度"

_HINT = (
    "score は位置ベースの粗い値。内容の強度 (主張が明確か) は別。"
    "comments と skill.md Case 1-3 のタグライン例を照合して判断。"
)

# タグライン語尾 regex (文末で評価)
_RE_DECLARATIVE = re.compile(r"(を明らかに|を示す|を構築|を確立|を実現|を体系化)する$")
_RE_PURPOSE = re.compile(r"(を目的とする|を目指す)$")
_RE_CHALLENGE = re.compile(r"(に挑む|を打ち立てる|を取り戻す|を拓く|に臨む)$")

# 文分割: 。 (全角) / ．(全角ピリオド)
_SENT_SPLIT = re.compile(r"[。．]")


def _classify(sentence: str) -> Optional[str]:
    """タグラインの型を判定。該当無しは None。"""
    s = sentence.strip()
    if not s:
        return None
    # 優先順位: challenge > declarative > purpose (強度順だが検出自体は独立)
    if _RE_CHALLENGE.search(s):
        return "challenge"
    if _RE_DECLARATIVE.search(s):
        return "declarative"
    if _RE_PURPOSE.search(s):
        return "purpose"
    return None


def grant_writing_tagline_identify(text: str, scan_chars: int = 500) -> dict:
    """木下原則1「目標規定文」の位置・長さ・型を検出。

    冒頭 scan_chars 字の範囲で定型タグライン語尾を持つ文を列挙。

    Args:
        text: 申請書本文 (先頭部分)。
        scan_chars: 検索対象とする冒頭の字数 (default: 500)。

    Returns:
        dict: score / score_max / comments / observations / hint / source
    """
    if text is None:
        text = ""
    scan_chars_used = int(scan_chars)
    head = text[:scan_chars_used]

    # 文分割しつつ、各文の元テキスト上の開始位置を保持
    candidates: list[dict] = []
    pos = 0  # head 中の走査カーソル
    sentence_idx = 0
    for raw in _SENT_SPLIT.split(head):
        # raw の head 中の開始位置は現在の pos
        start = pos
        # 次文のためのカーソル更新 (+1 は区切り文字 。/．)
        pos = start + len(raw) + 1
        sentence = raw.strip()
        if not sentence:
            sentence_idx += 1
            continue
        t = _classify(sentence)
        if t is not None:
            candidates.append(
                {
                    "sentence_idx": sentence_idx,
                    "char_pos": start,
                    "len": len(sentence),
                    "type": t,
                    "text": sentence,
                }
            )
        sentence_idx += 1

    earliest_sentence_idx: Optional[int] = (
        candidates[0]["sentence_idx"] if candidates else None
    )
    tagline_count_in_scan = len(candidates)

    # Scoring
    if earliest_sentence_idx == 0:
        score = 10.0
    elif earliest_sentence_idx is not None and earliest_sentence_idx <= 2:
        score = 7.0
    elif tagline_count_in_scan >= 1:
        score = 4.0
    else:
        score = 0.0

    # Comments
    comments: list[str] = []
    if tagline_count_in_scan == 0:
        comments.append(
            f"冒頭 scan_chars={scan_chars_used}字以内に目標規定文が無い。"
            "第一文で「〜を明らかにする」「〜を打ち立てる」相当の断言を置く "
            "(木下 原則 1)。"
        )
    else:
        first = candidates[0]
        types_present = {c["type"] for c in candidates}

        if first["sentence_idx"] == 0 and first["type"] == "challenge":
            comments.append("第一文が challenge 型タグライン。強度十分。")

        # purpose-only check: すべてが purpose 型
        if types_present == {"purpose"}:
            comments.append(
                "「〜を目的とする」型の弱いタグライン。"
                "challenge 型 (例: 「国産 OSS で国際標準の一角を打ち立てる」) "
                "に書き換えると Hook が強くなる (木下 原則 1)。"
            )

        if tagline_count_in_scan >= 2:
            comments.append(
                f"タグライン候補が {tagline_count_in_scan} 件ある。"
                "最も短く・強い一文を第一文に。"
                "残りは削る or 補足文に降格。"
            )

        # 位置が遅い場合のガイド
        if first["sentence_idx"] is not None and first["sentence_idx"] > 0:
            comments.append(
                f"最早のタグラインが第 {first['sentence_idx']+1} 文目。"
                "第一文への繰り上げを検討 (木下 原則 1 / skill.md T1-Hook)。"
            )

    # source 参照を最低 1 つに含める
    if not any(("木下" in c) or ("skill.md" in c) for c in comments):
        comments.append(f"参考: {_SOURCE}")

    observations = {
        "scan_chars_used": scan_chars_used,
        "candidates": candidates,
        "earliest_sentence_idx": earliest_sentence_idx,
        "tagline_count_in_scan": tagline_count_in_scan,
    }

    return {
        "score": score,
        "score_max": 10,
        "comments": comments,
        "observations": observations,
        "hint": _HINT,
        "source": _SOURCE,
    }
