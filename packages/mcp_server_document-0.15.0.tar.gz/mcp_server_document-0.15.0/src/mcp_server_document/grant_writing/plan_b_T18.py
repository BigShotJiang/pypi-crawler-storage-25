"""Plan B T18: 段落長分布診断 (grant_writing_paragraph_length_distribution).

skill.md 定量閾値『段落 ≤12 行』の実測化 / 木下『理科系の作文技術』
原則 3 (1 パラグラフ 1 主張) に基づく粗い温度計。

設計方針:
- score は 0-10 の粗い温度計。閾値超過段落の比率から算出。
- PRIMARY OUTPUT は comments (人間レビュアー風の助言文)。
- observations は raw measurement。段落の長短は論理構造にも依るため、
  score を 10 に最適化するゲームには陥らないこと。
"""

from __future__ import annotations

import re


# ------------------------------------------------------------------
# LaTeX preamble / comment stripping
# ------------------------------------------------------------------
def _strip_latex_preamble(text: str) -> str:
    """tex source から preamble / comments / \\end{document} 後を除去。

    - ``\\begin{document}`` より前を削除 (preamble / ``%`` header)
    - ``\\end{document}`` 以降を削除
    - 行頭〜文中の ``%`` 以降行末まで (LaTeX コメント) を削除。
      ただし ``\\%`` (escaped percent) は保護する。
    """
    if text is None:
        return ""

    # document env 検出
    begin_doc = text.find(r"\begin{document}")
    end_doc = text.find(r"\end{document}")
    if begin_doc >= 0:
        body_start = begin_doc + len(r"\begin{document}")
        if end_doc > begin_doc:
            body = text[body_start:end_doc]
        else:
            body = text[body_start:]
    else:
        body = text

    # Strip % comments (not \%)
    body = re.sub(r"(?<!\\)%[^\n]*", "", body)
    return body


def _is_tex_source(text: str) -> bool:
    """``\\documentclass`` or ``\\begin{document}`` を含めば tex 扱い。"""
    if not text:
        return False
    return bool(re.search(r"\\(documentclass|begin\{document\})", text))


# ------------------------------------------------------------------
# 段落分割
# ------------------------------------------------------------------
def _split_paragraphs(text: str) -> tuple[list[str], str]:
    """段落分割マーカーを優先順で試して分割する。

    Returns:
        (paragraphs, separator_detected)
          separator_detected は "\\par" / "\\n\\n" / "<single_line>" のいずれか。
    """
    if text is None:
        text = ""

    # 1. \par (LaTeX) を最優先
    if r"\par" in text:
        parts = re.split(r"\\par", text)
        sep = r"\par"
    # 2. 空行区切り (\n\n or \n  \n 等)
    elif re.search(r"\n\s*\n", text):
        parts = re.split(r"\n\s*\n", text)
        sep = "\n\n"
    else:
        # 3. 区切りマーカー無し → 全文 1 塊
        parts = [text] if text.strip() else []
        sep = "<single_line>"

    # 空段落除去
    paragraphs = [p.strip() for p in parts if p and p.strip()]
    return paragraphs, sep


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------
def grant_writing_paragraph_length_distribution(
    text: str,
    max_lines: int = 12,
    max_chars: int = 500,
) -> dict:
    """段落の長さ分布を実測。12 行超 or 500 字超の段落を flag。

    skill.md の『段落 ≤12 行』ルール実測化。

    引数:
        text: 申請書本文 (全文)
        max_lines: 1 段落の許容最大行数 (既定 12)
        max_chars: 1 段落の許容最大文字数 (既定 500)

    返り値:
        dict: score / score_max / comments / observations / hint / source
    """
    if text is None:
        text = ""

    # tex 判定: \documentclass or \begin{document} で tex 扱い
    preamble_stripped = False
    if _is_tex_source(text):
        text = _strip_latex_preamble(text)
        preamble_stripped = True

    paragraphs_raw, separator = _split_paragraphs(text or "")

    # ---- observations ----
    paragraphs_obs: list[dict] = []
    long_count = 0
    total_chars = 0
    total_lines = 0

    for idx, p in enumerate(paragraphs_raw, start=1):
        char_count = len(p)
        line_count = p.count("\n") + 1
        over_lines = line_count > max_lines
        over_chars = char_count > max_chars

        if over_lines and over_chars:
            status = "BOTH_OVER"
        elif over_lines:
            status = "TOO_LONG_LINES"
        elif over_chars:
            status = "TOO_LONG_CHARS"
        else:
            status = "OK"

        if status != "OK":
            long_count += 1

        head_text = p[:40]

        paragraphs_obs.append({
            "idx": idx,
            "char_count": char_count,
            "line_count": line_count,
            "status": status,
            "head_text": head_text,
        })

        total_chars += char_count
        total_lines += line_count

    total_paragraphs = len(paragraphs_obs)
    avg_char_count = (
        round(total_chars / total_paragraphs, 1) if total_paragraphs else 0.0
    )
    avg_line_count = (
        round(total_lines / total_paragraphs, 1) if total_paragraphs else 0.0
    )

    observations = {
        "total_paragraphs": total_paragraphs,
        "paragraphs": paragraphs_obs,
        "long_paragraphs_count": long_count,
        "avg_char_count": avg_char_count,
        "avg_line_count": avg_line_count,
        "paragraph_separator_detected": separator,
        "preamble_stripped": preamble_stripped,
    }

    # ---- score ----
    if total_paragraphs == 0:
        score = 0.0
    else:
        ok_count = total_paragraphs - long_count
        score = round((ok_count / total_paragraphs) * 10, 1)

    # ---- comments (PRIMARY OUTPUT) ----
    comments: list[str] = []

    if total_paragraphs == 0:
        comments.append("段落が検出されない")
        comments.append(
            "解析対象テキストが空、または段落として認識できる内容が無い。"
            "申請書本文を渡しているか確認すること。"
        )
    else:
        # 区切りマーカー不在 (1 段落のみ、かつ separator が <single_line>)
        if separator == "<single_line>" and total_paragraphs == 1:
            comments.append(
                "段落分割マーカー (\\par or 空行) が検出されず、全文が 1 塊。"
                "申請書は段落分割で可読性を確保。"
            )

        # 長すぎる段落の列挙 (最大 3 件)
        long_paragraphs = [p for p in paragraphs_obs if p["status"] != "OK"]
        for p in long_paragraphs[:3]:
            comments.append(
                f"段落 {p['idx']} ({p['line_count']} 行 / {p['char_count']} 字) "
                f"が長い: 「{p['head_text']}...」。分割か圧縮を検討。"
            )

        # 全て OK かつ 3 段落以上 → 肯定
        if long_count == 0 and total_paragraphs >= 3:
            comments.append(
                f"全 {total_paragraphs} 段落が閾値内。読点疲労のリスクなし。"
            )
        elif long_count == 0 and total_paragraphs < 3:
            # 少数段落で全 OK の場合の補足
            comments.append(
                f"検出された {total_paragraphs} 段落は閾値内だが、"
                "段落数が少ない。申請書として論理ブロックが十分に分かれているか確認。"
            )

    # 2-5 comments に収める
    if len(comments) < 2:
        comments.append(
            "score は上限超過段落の比率。段落内の論理構造も併せて確認すること。"
        )
    comments = comments[:5]

    hint = (
        "score は上限超過段落の比率。"
        "実際の読みやすさは段落内の論理構造による。"
    )
    source = (
        "skill.md 定量閾値 (段落 ≤12 行) / "
        "木下原則 3 (1 パラグラフ 1 主張)"
    )

    return {
        "score": float(score),
        "score_max": 10,
        "comments": comments,
        "observations": observations,
        "hint": hint,
        "source": source,
    }
