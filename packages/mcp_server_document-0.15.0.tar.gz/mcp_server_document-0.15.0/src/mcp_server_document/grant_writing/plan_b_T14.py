"""Plan B T14 — 申請書スケジュール記述の論理整合チェック.

年度/月/四半期マーカーの連続性、フェーズ重複、マイルストーン存在、
終期成果物の有無を regex ベースで検査する。審査員が「完遂像」を
読み取れるかどうかを定量化する粗いツール。
"""

from __future__ import annotations

import re


_SOURCE = "grant-writing tool (2026-04-23 新規) — 申請書スケジュール論理整合"

_HINT = (
    "regex ベースで表組みや Gantt チャートの本文ラベルのみ解析。"
    "comments を起点に原典で確認、特に年度連続性は数字の書き方ゆれ "
    "(R6 vs 令和6年度 vs 2024年度) で取りこぼしがあり得る。"
)

# ---- 年度マーカー regex --------------------------------------------------
# 令和 N 年度 (任意スペース可)
_RE_REIWA = re.compile(r"令和\s*([0-9]{1,2})\s*年度")
# 西暦 4 桁 年度
_RE_SEIREKI = re.compile(r"([12][0-9]{3})\s*年度")
# 相対 R{N}
_RE_REL_R = re.compile(r"(?<![A-Za-z])R([0-9]{1,2})(?![0-9])")
# 相対 Y{N}
_RE_REL_Y = re.compile(r"(?<![A-Za-z])Y([0-9]{1,2})(?![0-9])")
# 四半期
_RE_QUARTER = re.compile(r"(?<![A-Za-z])Q([1-4])(?![0-9])")
# 月 M{N}
_RE_MONTH = re.compile(r"(?<![A-Za-z])M([0-9]{1,2})(?![0-9])")

# ---- フェーズ regex ------------------------------------------------------
_PHASE_PATTERNS = [
    # フェーズ N
    re.compile(r"フェーズ\s*([1-9])"),
    # 第 N フェーズ
    re.compile(r"第\s*([0-9]+)\s*フェーズ"),
    # Phase N
    re.compile(r"Phase\s*([0-9]+)", re.IGNORECASE),
    # Step N
    re.compile(r"Step\s*([0-9]+)", re.IGNORECASE),
]

# ---- マイルストーン語彙 --------------------------------------------------
_MILESTONE_KEYWORDS = [
    "中間報告",
    "成果発表",
    "論文投稿",
    "完成",
    "実装完了",
    "実証実験",
]

# ---- 終期成果物語彙 ------------------------------------------------------
_END_DELIVERABLE_KEYWORDS = _MILESTONE_KEYWORDS + ["成果", "報告書", "公開"]

# 終期判定のスキャン窓 (末尾 N 字)
_END_WINDOW = 300


def _to_seireki(kind: str, value: int) -> int | None:
    """年度マーカーを西暦 (seireki) に正規化。
    令和 N 年 ≡ 2018 + N、R6 も令和 6 と同一視。
    relative_Y / quarter / month は年度判定に使わないので None。
    """
    if kind == "reiwa" or kind == "relative_R":
        return 2018 + value
    if kind == "seireki":
        return value
    return None


def _collect_year_markers(text: str) -> list[dict]:
    """text 全体から年度マーカーを収集 (出現順)."""
    markers: list[dict] = []

    def _add(text_, kind_, value_, pos_):
        markers.append({
            "text": text_,
            "kind": kind_,
            "value": value_,
            "normalized_year": _to_seireki(kind_, value_),
            "pos": pos_,
        })

    for m in _RE_REIWA.finditer(text):
        _add(m.group(0), "reiwa", int(m.group(1)), m.start())
    for m in _RE_SEIREKI.finditer(text):
        _add(m.group(0), "seireki", int(m.group(1)), m.start())
    for m in _RE_REL_R.finditer(text):
        _add(m.group(0), "relative_R", int(m.group(1)), m.start())
    for m in _RE_REL_Y.finditer(text):
        _add(m.group(0), "relative_Y", int(m.group(1)), m.start())
    for m in _RE_QUARTER.finditer(text):
        markers.append(
            {
                "text": m.group(0),
                "kind": "quarter",
                "value": int(m.group(1)),
                "pos": m.start(),
            }
        )
    for m in _RE_MONTH.finditer(text):
        markers.append(
            {
                "text": m.group(0),
                "kind": "month",
                "value": int(m.group(1)),
                "pos": m.start(),
            }
        )

    markers.sort(key=lambda d: d["pos"])
    return markers


def _check_year_continuity(markers: list[dict]) -> bool:
    """年度マーカー群が連続整数 (西暦正規化後) かを判定.

    令和・西暦・R6 などの書き方揺れを西暦に正規化してから
    単一集合で連続性を検査する (2026-04-23 以降)。
    - 正規化できるマーカーが 0 or 1 件なら検査対象外 (→ True)。
    - relative_Y は ambiguous のため normalized_year が None、
      年度連続性の検査からは除外する。
    """
    vals = sorted({
        m["normalized_year"] for m in markers
        if m.get("normalized_year") is not None
    })
    if len(vals) < 2:
        return True
    expected = list(range(vals[0], vals[-1] + 1))
    return vals == expected


def _collect_phase_tokens(text: str) -> list[dict]:
    """phase_tokens を収集 (出現順, 重複位置は 1 回のみ)."""
    seen_positions: set[int] = set()
    tokens: list[dict] = []
    for pat in _PHASE_PATTERNS:
        for m in pat.finditer(text):
            if m.start() in seen_positions:
                continue
            seen_positions.add(m.start())
            tokens.append({"text": m.group(0), "pos": m.start()})
    tokens.sort(key=lambda d: d["pos"])
    return tokens


def _distinct_phase_numbers(tokens: list[dict]) -> int:
    """phase_tokens から抽出した distinct なフェーズ番号の個数."""
    numbers: set[int] = set()
    num_re = re.compile(r"([0-9]+)")
    for t in tokens:
        mm = num_re.search(t["text"])
        if mm:
            numbers.add(int(mm.group(1)))
    return len(numbers)


def _find_milestones(text: str) -> list[str]:
    """本文に含まれる milestone 語彙を重複無しで列挙."""
    found: list[str] = []
    for kw in _MILESTONE_KEYWORDS:
        if kw in text and kw not in found:
            found.append(kw)
    return found


def _end_deliverable_present(text: str) -> bool:
    """末尾 _END_WINDOW 字以内に成果物語が出現するか."""
    if not text:
        return False
    tail = text[-_END_WINDOW:]
    for kw in _END_DELIVERABLE_KEYWORDS:
        if kw in tail:
            return True
    return False


def _year_span(markers: list[dict]) -> int:
    """年度マーカーの最大 - 最小 + 1 (西暦正規化後). 無ければ 0."""
    values = [m["normalized_year"] for m in markers
              if m.get("normalized_year") is not None]
    if not values:
        return 0
    return max(values) - min(values) + 1


def grant_writing_schedule_consistency_check(text: str) -> dict:
    """申請書のスケジュール記述の論理整合を検査。

    年度/月/四半期マーカーの連続性、フェーズ重複、マイルストーン存在、
    終期成果物の有無。

    Args:
        text: 申請書本文。

    Returns:
        dict: score / score_max / comments / observations / hint / source
    """
    if text is None:
        text = ""

    year_markers = _collect_year_markers(text)
    year_continuity = _check_year_continuity(year_markers)
    phase_tokens = _collect_phase_tokens(text)
    milestones = _find_milestones(text)
    end_present = _end_deliverable_present(text)
    phases_total = _distinct_phase_numbers(phase_tokens)
    span = _year_span(year_markers)

    # -------- Scoring --------
    score = 5.0
    if len(year_markers) >= 2 and year_continuity:
        score += 2.0
    if len(milestones) >= 2:
        score += 2.0
    if end_present:
        score += 1.0
    if len(year_markers) >= 2 and not year_continuity:
        score -= 2.0
    if len(year_markers) == 0:
        score -= 1.0

    # 完全無検出ケースの強い降格
    if (
        len(year_markers) == 0
        and len(phase_tokens) == 0
        and len(milestones) == 0
    ):
        score = 2.0

    # clamp [0, 10]
    if score < 0:
        score = 0.0
    if score > 10:
        score = 10.0

    # -------- Comments --------
    comments: list[str] = []

    if len(year_markers) == 0 and len(phase_tokens) == 0:
        comments.append(
            "スケジュール記述が検出されない。"
            "年度マーカー (「令和 6 年度」「2026 年度」「R6」等) と"
            "フェーズ区分を明示。"
        )

    if len(year_markers) >= 2 and not year_continuity:
        year_vals = sorted(
            {
                m["value"]
                for m in year_markers
                if m["kind"] in ("reiwa", "seireki")
            }
        )
        comments.append(
            f"年度マーカーに連続性が無い (検出: {year_vals})。"
            "1 年度の抜けは審査員の混乱を招くので補う。"
        )

    if len(milestones) < 2:
        comments.append(
            "マイルストーン語 (中間報告/成果発表/論文投稿/完成/実証実験) が不足。"
            "最低 2 件は明示。"
        )

    if not end_present:
        comments.append(
            "終期 (最後の年度) に成果物 (報告書/公開/論文/実装完了 等) の記述が無い。"
            "審査員は完遂像を求める。"
        )

    # all good
    if (
        len(year_markers) >= 2
        and year_continuity
        and len(milestones) >= 2
        and end_present
    ):
        comments.append(
            "年度連続性・マイルストーン・終期成果物いずれも整合。"
        )

    # 2-5 本に整える
    if not comments:
        comments.append(
            "スケジュール記述に決定的な欠落は検出されず。詳細は observations を確認。"
        )
    if len(comments) > 5:
        comments = comments[:5]

    observations = {
        "year_markers": year_markers,
        "year_continuity": year_continuity,
        "phase_tokens": phase_tokens,
        "milestone_keywords_found": milestones,
        "end_deliverable_present": end_present,
        "phases_total": phases_total,
        "year_span": span,
    }

    return {
        "score": float(score),
        "score_max": 10,
        "comments": comments,
        "observations": observations,
        "hint": _HINT,
        "source": _SOURCE,
    }
