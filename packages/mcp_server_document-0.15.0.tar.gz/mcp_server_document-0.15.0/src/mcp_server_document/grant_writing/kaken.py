"""KAKEN (NII OpenSearch) 連携ツール群 (grant_writing モジュール内蔵).

国立情報学研究所 (NII) の KAKEN 科研費採択課題データベースへのアクセス。
科研費申請書執筆における:
    - 同じ小区分の採択課題を列挙 → Hook/Vision の当たり調査
    - PI 名 / erad 番号 で自分の過去採択を引く → 研究遂行能力欄
    - 類似テーマの先行採択 → 先行研究の濃度確認

を skill 内で完結させる。

Endpoints:
    Projects   : https://kaken.nii.ac.jp/opensearch/    (format=xml のみ)
    Researchers: https://nrid.nii.ac.jp/opensearch/     (format=json OK)

認証: CiNii で取得した appid が必要 (KAKEN/NRID は CiNii と appid 共用)。
環境変数 `KAKEN_APPID` に設定する。未設定時はエラー dict を返す。
appid 取得: https://support.nii.ac.jp/ja/cinii/api/developer

主要パラメータ (NII 公式仕様 KAKEN_API_parameters_document より):
    kw  : 自由文 (課題名・概要・キーワード横断)
    qa  : 課題名のみ
    qf  : 研究キーワードのみ
    qg  : 研究者氏名
    qm  : 研究者番号 (erad 8 桁)
    qe  : 研究機関
    qc  : 研究種目 (例: 基盤研究(C), 若手研究)
    s1  : 年度 下限
    s2  : 年度 上限
    o1  : 年度範囲の解釈 (1=開始年度一致, 2=終了年度一致,
           3=範囲と重複する課題を拾う, 4=範囲内に完全包含)
    rw  : 1 ページ件数 (仕様上 20/50/100/200/500 のみ許容)
    st  : 開始 index (1 始まり)
    format: projects は html5/xml、researchers は html5/json のみ
"""
from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

PROJECTS_BASE = "https://kaken.nii.ac.jp/opensearch/"
RESEARCHERS_BASE = "https://nrid.nii.ac.jp/opensearch/"
ALLOWED_RW = (20, 50, 100, 200, 500)


def _appid() -> str | None:
    v = os.environ.get("KAKEN_APPID", "").strip()
    return v or None


def _no_appid() -> dict:
    return {
        "error": "KAKEN_APPID is not set",
        "hint": "Register at https://support.nii.ac.jp/ja/cinii/api/developer "
                "and set the issued appid to env var KAKEN_APPID. "
                "The same appid is valid for KAKEN and NRID.",
    }


def _clamp_rw(rw: int) -> int:
    """rw を KAKEN 許容値 {20, 50, 100, 200, 500} にクランプ (最近値)."""
    return min(ALLOWED_RW, key=lambda x: abs(x - rw))


def _http_get(url: str, timeout: float = 30.0) -> bytes:
    req = urllib.request.Request(
        url, headers={"User-Agent": "Mozilla/5.0 (grant-writing-mcp)"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310
        return r.read()


def _build_url(base: str, params: dict[str, str]) -> str:
    return base + "?" + urllib.parse.urlencode(
        {k: v for k, v in params.items() if v is not None and v != ""}
    )


# ------------------------------------------------------------------
# Tools
# ------------------------------------------------------------------
def grant_writing_kaken_ping() -> dict:
    """KAKEN API の appid 疎通確認。

    projects 側を `format=xml&rw=20&s1=2024&s2=2024&o1=3` で軽く叩き、
    totalResults を取り出して返す。appid 未設定・期限切れ・scope 不正を
    切り分ける一次ツール。
    """
    appid = _appid()
    if not appid:
        return _no_appid()
    url = _build_url(PROJECTS_BASE, {
        "appid": appid, "format": "xml",
        "s1": "2024", "s2": "2024", "o1": "3",
        "rw": "20",
    })
    try:
        body = _http_get(url, timeout=10.0)
        root = ET.fromstring(body)
    except Exception as e:
        return {"status": "error", "api_base": PROJECTS_BASE, "detail": str(e)}
    total_el = root.find("totalResults")
    total = int(total_el.text) if total_el is not None and total_el.text else None
    return {
        "status": "ok" if total and total > 0 else "auth_ok_but_empty",
        "projects_base": PROJECTS_BASE,
        "researchers_base": RESEARCHERS_BASE,
        "total_results_sample": total,
        "sample_query": "s1=2024&s2=2024&o1=3 (2024 年度活動中の採択課題)",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def grant_writing_kaken_search_projects(
    kw: str = "",
    qa: str | None = None,
    qf: str | None = None,
    institution: str | None = None,
    grant_type: str | None = None,
    year_from: int | None = None,
    year_to: int | None = None,
    year_scope: int = 3,
    rw: int = 20,
    st: int = 1,
) -> dict:
    """KAKEN 科研費採択課題を検索 (format=xml で叩いて dict に変換)。

    Args:
        kw: 自由文検索 (課題名・概要・キーワード横断)。空文字で kw 条件なし。
        qa: 課題名のみ (kw と併用可、AND)
        qf: 研究キーワードのみ
        institution: 研究機関 (例: "近畿大学") — API 上は qe
        grant_type: 研究種目 (例: "基盤研究(C)") — API 上は qc
        year_from: 年度 下限 (API 上は s1)
        year_to: 年度 上限 (API 上は s2)
        year_scope: 年度範囲の解釈 (API 上は o1):
            1=開始年度一致, 2=終了年度一致, 3=範囲と重複, 4=範囲に完全包含。
            default 3 (範囲と重複する課題を拾う)。
        rw: 1 ページ件数。KAKEN 仕様上 {20,50,100,200,500} のみなので
            近い値にクランプされる。
        st: 開始インデックス (1 始まり)。

    Returns:
        dict: totalResults, itemsPerPage, startIndex, result[] (compact view).

    Notes:
        - format=json は projects 側では無効 (silently fall back で 0 件扱い)。
          本実装は xml → ET で dict 化してから返す。
    """
    appid = _appid()
    if not appid:
        return _no_appid()
    params: dict[str, str] = {
        "appid": appid,
        "format": "xml",
        "rw": str(_clamp_rw(max(1, rw))),
        "st": str(max(1, st)),
    }
    if kw:
        params["kw"] = kw
    if qa:
        params["qa"] = qa
    if qf:
        params["qf"] = qf
    if institution:
        params["qe"] = institution
    if grant_type:
        params["qc"] = grant_type
    if year_from is not None:
        params["s1"] = str(year_from)
    if year_to is not None:
        params["s2"] = str(year_to)
    if year_from is not None or year_to is not None:
        params["o1"] = str(year_scope)
    url = _build_url(PROJECTS_BASE, params)
    try:
        body = _http_get(url)
        root = ET.fromstring(body)
    except ET.ParseError as e:
        return {"error": f"xml parse: {e}", "url": url.replace(appid, "***")}
    except Exception as e:
        return {"error": str(e), "url": url.replace(appid, "***")}

    total_el = root.find("totalResults")
    total = int(total_el.text) if total_el is not None and total_el.text else 0

    items = [_xml_to_project_dict(g) for g in root.findall("grantAward")]
    return {
        "totalResults": total,
        "itemsPerPage": len(items),
        "startIndex": st,
        "query": {k: v for k, v in params.items() if k != "appid"},
        "result": items,
    }


def grant_writing_kaken_search_researchers(
    qm: str = "",
    qg: str = "",
    rw: int = 20,
    st: int = 1,
) -> dict:
    """KAKEN 研究者 (NRID) 検索。

    Args:
        qm: erad 研究者番号 (8 桁、例: "12345678")。指定時は氏名検索 (qg) より優先。
            古い引数形状を保つため、qm に非数字が渡された場合は自動で qg に振替える。
        qg: 氏名 (例: "菅原賢悟")
        rw: 1 ページ件数 (KAKEN 仕様上 20/50/100/200/500 にクランプ)
        st: 開始インデックス (1 始まり)

    Returns:
        dict: totalResults + researchers[] の compact view

    Notes:
        - NRID 側は format=json が仕様上サポートされている。
        - 氏名検索 qg は部分一致で複数候補が返るため、erad 番号が分かるなら qm を
          優先するのが安全。
    """
    appid = _appid()
    if not appid:
        return _no_appid()
    # Back-compat: old callers pass qm for both erad numbers AND names.
    # If qm looks non-numeric, dispatch to qg.
    if qm and not qm.isdigit() and not qg:
        qg, qm = qm, ""

    params: dict[str, str] = {
        "appid": appid,
        "format": "json",
        "rw": str(_clamp_rw(max(1, rw))),
        "st": str(max(1, st)),
    }
    if qm:
        params["qm"] = qm
    if qg:
        params["qg"] = qg
    url = _build_url(RESEARCHERS_BASE, params)
    try:
        body = _http_get(url)
        text = body.decode("utf-8-sig", errors="replace")
        data = json.loads(text)
    except Exception as e:
        return {"error": str(e), "url": url.replace(appid, "***")}

    items = data.get("researchers") or data.get("result") or []
    compact = [_compact_researcher(it) for it in items]
    return {
        "totalResults": data.get("totalResults"),
        "itemsPerPage": data.get("itemsPerPage") or len(compact),
        "startIndex": data.get("startIndex") or st,
        "query": {k: v for k, v in params.items() if k != "appid"},
        "result": compact,
    }


# ------------------------------------------------------------------
# XML → dict helpers (projects 側専用)
# ------------------------------------------------------------------
def _xml_text(elem, path: str) -> str | None:
    """Find child path under elem, return stripped text or None."""
    if elem is None:
        return None
    child = elem.find(path)
    if child is None or child.text is None:
        return None
    txt = child.text.strip()
    return txt or None


def _xml_findall_text(elem, path: str) -> list[str]:
    if elem is None:
        return []
    return [c.text.strip() for c in elem.findall(path)
            if c is not None and c.text and c.text.strip()]


def _xml_to_project_dict(g) -> dict:
    """Convert <grantAward> element into a flat dict.

    Actual KAKEN XML shape (2026-03-17 spec):
      <grantAward id="..." awardNumber="...">
        <identifier type="nationalAwardNumber">
          <normalizedValue>JP24K15774</normalizedValue>
        </identifier>
        <summary xml:lang="ja">
          <title>...</title>
          <category niiCode="...">基盤研究(C)</category>
          <review_section>小区分xxx:yyy</review_section>
          <institution>近畿大学</institution>
          <member role="principal_investigator" eradCode="...">
            <personalName><fullName>...</fullName></personalName>
          </member>
          <projectStatus fiscalYear="2024" statusCode="granted"/>
          <keywordList><keyword>...</keyword></keywordList>
        </summary>
        <urlList><url>...</url></urlList>
      </grantAward>
    """
    summary = g.find("summary")
    # Principal investigator (first member with role=principal_investigator)
    pi_name = pi_erad = None
    if summary is not None:
        for mem in summary.findall("member"):
            if mem.get("role") == "principal_investigator":
                pi_erad = (mem.get("eradCode")
                           or _xml_text(mem, "enriched/researcherNumber"))
                pi_name = _xml_text(mem, "personalName/fullName")
                break

    status = summary.find("projectStatus") if summary is not None else None
    start_year = status.get("fiscalYear") if status is not None else None
    identifier = _xml_text(g, "identifier/normalizedValue")
    url_el = g.find("urlList/url")
    url = url_el.text.strip() if url_el is not None and url_el.text else None

    return {
        "id": g.get("id"),
        "award_number": g.get("awardNumber") or identifier,
        "title": _xml_text(summary, "title") if summary is not None else None,
        "pi_name": pi_name,
        "pi_erad": pi_erad,
        "institution": _xml_text(summary, "institution")
                       if summary is not None else None,
        "grant_type": _xml_text(summary, "category")
                      if summary is not None else None,
        "review_section": _xml_text(summary, "review_section")
                          if summary is not None else None,
        "fiscal_year": start_year,
        "status": status.get("statusCode") if status is not None else None,
        "keywords": (_xml_findall_text(summary, "keywordList/keyword")
                     if summary is not None else []),
        "url": url,
    }


def _human_readable(node, lang_priority=("ja", "en", "ja-Kana")) -> str | None:
    """Pull humanReadableValue (list-of-dicts) into a single string by lang priority.

    Example node:
      {"humanReadableValue": [
          {"text": "菅原 賢悟", "lang": "ja"},
          {"text": "Sugahara Kengo", "lang": "en"},
       ]}
    """
    if node is None:
        return None
    if isinstance(node, list) and node:
        node = node[0]
    if isinstance(node, dict):
        hrv = node.get("humanReadableValue")
        if isinstance(hrv, list):
            by_lang = {h.get("lang"): h.get("text") for h in hrv
                       if isinstance(h, dict) and h.get("text")}
            for lang in lang_priority:
                if lang in by_lang:
                    return by_lang[lang]
            if by_lang:
                return next(iter(by_lang.values()))
        return node.get("value") or node.get("$") or node.get("text")
    return node


def _compact_researcher(it: dict) -> dict:
    """Flatten NRID researcher JSON into a hint-sized dict.

    Keeps: erad, Japanese name, current affiliation, past-project count,
    and a short list of kakenhi project ids for cross-reference.
    """
    if not isinstance(it, dict):
        return {"_raw": it}

    erad_list = it.get("id:person:erad") or []
    erad = erad_list[0] if isinstance(erad_list, list) and erad_list else None

    name = _human_readable(it.get("name"))

    affil_current = None
    current = it.get("affiliations:current")
    if isinstance(current, list) and current:
        first_cur = current[0]
        if isinstance(first_cur, dict):
            affil_current = _human_readable(first_cur.get("affiliation:institution"))

    related = it.get("relation:relatedResource") or []
    project_ids = [r.get("id:project:kakenhi") for r in related
                   if isinstance(r, dict) and r.get("id:project:kakenhi")]

    return {
        "erad": erad,
        "name": name,
        "affiliation_current": affil_current,
        "kakenhi_project_count": len(project_ids),
        "kakenhi_project_ids": project_ids[:20],
    }
