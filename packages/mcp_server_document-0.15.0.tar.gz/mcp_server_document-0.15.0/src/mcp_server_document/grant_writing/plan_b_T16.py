"""T16: grant_writing_health_report — Plan B 診断の統合レポート。

Plan B Tier 1 の 7 ツール + 既存の bedrock lint を束ね、
修正優先度付きで summary を返す。申請書レビュー時の「入口」として使う。
"""
from __future__ import annotations

from .plan_b_T8 import grant_writing_hook_strength
from .plan_b_T9 import grant_writing_concrete_scene_density
from .plan_b_T10 import grant_writing_tagline_identify
from .plan_b_T11 import grant_writing_continuity_check
from .plan_b_T12 import grant_writing_collaborator_roles_check
from .plan_b_T13 import grant_writing_budget_logic_check
from .plan_b_T14 import grant_writing_schedule_consistency_check
# Tier 2 (v0.11.0)
from .plan_b_T18 import grant_writing_paragraph_length_distribution
from .plan_b_T19 import grant_writing_5w1h_coverage
from .plan_b_T20 import grant_writing_applicant_credentials_check
from .plan_b_T21 import grant_writing_challenge_4_strategies


def _severity_from_score(score: float) -> str:
    if score is None:
        return "UNKNOWN"
    if score < 4:
        return "CRITICAL"
    if score < 6:
        return "HIGH"
    if score < 8:
        return "MEDIUM"
    return "LOW"


def grant_writing_health_report(
    text: str,
    applicant_name: str = "",
    skip: str = "",
) -> dict:
    """Plan B Tier 1 の 7 tool を束ねた統合レポート。

    申請書の全体像を 1 コールで把握するための入口 tool。各 subscore に
    severity (CRITICAL/HIGH/MEDIUM/LOW) を付け、修正優先度付きの
    priority_issues リストを返す。

    Args:
        text: 対象申請書の本文。
        applicant_name: T12 collaborator_roles_check に渡す申請者名 (空文字可)。
        skip: カンマ区切りで除外する T 番号 (例: "T13,T14" で予算/スケジュール診断をスキップ)。
              予算・スケジュールセクションが別ファイルの場合に有用。

    Returns:
        dict:
          - overall_score: 0-10 の粗い総合スコア
          - overall_severity: CRITICAL/HIGH/MEDIUM/LOW
          - detailed_scores: 各 tool の score
          - priority_issues: severity 順にソートされた issue list
          - summary_comment: 1 文の overall 判定
          - hint / source
    """
    skip_set = {s.strip().upper() for s in skip.split(",") if s.strip()}

    tools_to_run: list[tuple[str, str, callable, dict]] = [
        ("T8", "hook_strength", grant_writing_hook_strength, {}),
        ("T9", "concrete_scene_density", grant_writing_concrete_scene_density, {}),
        ("T10", "tagline_identify", grant_writing_tagline_identify, {}),
        ("T11", "continuity_check", grant_writing_continuity_check, {}),
        ("T12", "collaborator_roles_check", grant_writing_collaborator_roles_check,
         {"applicant_name": applicant_name}),
        ("T13", "budget_logic_check", grant_writing_budget_logic_check, {}),
        ("T14", "schedule_consistency_check", grant_writing_schedule_consistency_check, {}),
        # Tier 2
        ("T18", "paragraph_length_distribution",
         grant_writing_paragraph_length_distribution, {}),
        ("T19", "5w1h_coverage", grant_writing_5w1h_coverage, {}),
        ("T20", "applicant_credentials_check",
         grant_writing_applicant_credentials_check, {}),
        ("T21", "challenge_4_strategies",
         grant_writing_challenge_4_strategies, {}),
    ]

    detailed_scores: dict[str, float] = {}
    detailed_results: dict[str, dict] = {}
    priority_issues: list[dict] = []

    for tid, name, func, kwargs in tools_to_run:
        if tid in skip_set:
            continue
        try:
            r = func(text, **kwargs) if kwargs else func(text)
        except Exception as e:
            priority_issues.append({
                "tool": tid,
                "name": name,
                "severity": "CRITICAL",
                "reason": f"tool crashed: {e}",
                "comments": [],
            })
            continue

        score = r.get("score")
        detailed_scores[tid] = score
        detailed_results[tid] = r
        severity = _severity_from_score(score)

        # Only push to priority_issues if not LOW (LOW = acknowledgment, no fix needed)
        if severity != "LOW":
            priority_issues.append({
                "tool": tid,
                "name": name,
                "severity": severity,
                "score": score,
                "comments": r.get("comments", [])[:3],  # top-3 advisor comments
            })

    # Sort priority_issues by severity (CRITICAL > HIGH > MEDIUM > UNKNOWN)
    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "UNKNOWN": 3, "LOW": 4}
    priority_issues.sort(key=lambda x: (sev_rank.get(x["severity"], 99),
                                          -1 * (x.get("score") or 0)))

    # Overall = simple mean (excluding None scores)
    valid_scores = [s for s in detailed_scores.values() if s is not None]
    overall_score = (round(sum(valid_scores) / len(valid_scores), 1)
                     if valid_scores else 0.0)
    overall_severity = _severity_from_score(overall_score)

    # Summary comment
    n_critical = sum(1 for i in priority_issues if i["severity"] == "CRITICAL")
    n_high = sum(1 for i in priority_issues if i["severity"] == "HIGH")
    if n_critical >= 2:
        summary = (f"CRITICAL 課題が {n_critical} 件。"
                   "Hook/タグライン/予算/共同研究者のいずれかが根本的に欠けている可能性。"
                   "priority_issues の CRITICAL から順に対応。")
    elif n_critical == 1:
        summary = (f"CRITICAL 課題が 1 件 ({priority_issues[0]['name']})。"
                   "まずここを直すと申請書の印象が大きく変わる。")
    elif n_high >= 2:
        summary = (f"HIGH 課題が {n_high} 件。致命傷は無いが、"
                   "修正で採択確度が上がる余地がある。")
    elif n_high == 1:
        summary = (f"HIGH 課題が 1 件 ({priority_issues[0]['name']})。"
                   "それ以外は概ね整合。")
    else:
        summary = ("CRITICAL / HIGH 課題なし。申請書の骨格は整っている。"
                   "最終パスは tool を閉じて全文音読し、著者の声で最終判定。")

    return {
        "overall_score": overall_score,
        "score_max": 10,
        "overall_severity": overall_severity,
        "summary_comment": summary,
        "detailed_scores": detailed_scores,
        "priority_issues": priority_issues,
        "tools_run": list(detailed_scores.keys()),
        "tools_skipped": sorted(skip_set),
        "hint": (
            "overall_score は参考値。priority_issues の CRITICAL / HIGH を "
            "一つずつ読み、skill.md の該当セクションと照合して対応。"
            "全件 LOW に潰そうとする最適化ゲームに陥らない。"
            "budget/schedule セクションが別ファイルの場合は skip='T13,T14' を指定。"
        ),
        "source": (
            "Plan B 統合レポート (2026-04-23 v0.10.0) — "
            "T8 Hook / T9 具体密度 / T10 タグライン / T11 継続性 / "
            "T12 共同研究者 / T13 予算 / T14 スケジュール を束ねる。"
        ),
    }
