"""mcp-server-document — unified MCP server for academic document authoring.

Sub-modules:
  grant_writing  - 科研費 / JSPS / 助成金 申請書
  paper_writing  - Journal papers (IEEE / IEEJ / APS / Elsevier)
  presentation   - Research-talk slides (IEEJ SA / IEEE conference)
  diagram        - raster→Excalidraw pipeline + HTTP canvas bridge
  document_meta  - Cross-cutting helpers (deadline, diff, templates, lint)

Entry point: `mcp-server-document` console script (stdio MCP transport).
"""

__version__ = "0.9.0"
