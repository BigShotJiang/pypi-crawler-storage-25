import os
import math
import pandas as pd
from tqdm import tqdm
from typing import Optional
from dateutil import parser
from datetime import datetime, date, time
from openpyxl.utils import get_column_letter
from openpyxl import load_workbook, Workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import PatternFill, Font, Border, Side, Alignment

# ── Layout constants ──────────────────────────────────────────────────────────
_DATA_ROW_HEIGHT   = 48.75
_HEADER_ROW_HEIGHT = 38
_DEFAULT_COL_WIDTH = 21
_TITLE_COL_WIDTH   = 60
_ID_COL_WIDTH      = 12
_DATE_COL_WIDTH    = 22
_TOTAL_STEPS       = 9

# Characters that Excel interprets as formula prefixes
_FORMULA_CHARS = ('=', '+', '-', '@')

# Excel sheet-name forbidden characters
_INVALID_SHEET_CHARS = set('[]:*?/\\')


def format(
    input_path: Optional[str] = None,
    dataframe: Optional[pd.DataFrame] = None,
    output_path: Optional[str] = None,
    input_sheet: Optional[str] = None,
    output_sheet: Optional[str] = None,
) -> None:
    """
    Format Excel/CSV files or DataFrames with consistent styling and data cleaning.

    Args:
        input_path:   Path to input .xlsx or .csv file  [mutually exclusive with 'dataframe']
        dataframe:    Pandas DataFrame to format         [mutually exclusive with 'input_path']
        output_path:  Path for output .xlsx file         [required]
        input_sheet:  Sheet name to read from Excel input [optional]
        output_sheet: Name for output sheet              [default: "Sheet"]
    """

    # =========================================================================
    # HELPER FUNCTIONS
    # =========================================================================

    def clean_cell_value(value):
        """
        Normalise a cell string for safe, consistent Excel storage:
          - Remove illegal XML control characters
          - Normalise \\r\\n and \\r to \\n  (Excel intra-cell line-break)
          - Replace non-breaking spaces (\\xa0) with regular spaces
          - Strip leading / trailing whitespace
          - Return None for strings that are empty after cleaning
        Non-string values are returned unchanged.
        """
        if not isinstance(value, str):
            return value
        value = ILLEGAL_CHARACTERS_RE.sub("", value)
        value = value.replace("\r\n", "\n").replace("\r", "\n")
        value = value.replace("\xa0", " ")
        value = value.strip()
        return value if value else None

    def is_date(value):
        return isinstance(value, (datetime, date, time))

    def is_numeric(value):
        # Explicitly exclude bool: isinstance(True, int) is True in Python
        return isinstance(value, (int, float)) and not isinstance(value, bool)

    def write_df_to_ws(ws, df):
        """Write a DataFrame into a worksheet, protecting formula-like strings."""
        for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=True), start=1):
            for c_idx, value in enumerate(row, start=1):
                # Convert pandas NaN to None — NaN written as float is invalid XML
                # and causes Excel to display #NUM! errors or fail to open the file.
                if isinstance(value, float) and math.isnan(value):
                    value = None
                cell = ws.cell(row=r_idx, column=c_idx)
                cell.value = value
                if isinstance(value, str) and value and value[0] in _FORMULA_CHARS:
                    cell.data_type = 's'

    # =========================================================================
    # INPUT VALIDATION
    # =========================================================================

    if input_path is not None and dataframe is not None:
        raise ValueError("Provide either 'input_path' or 'dataframe', not both.")

    if input_path is None and dataframe is None:
        raise ValueError("Either 'input_path' or 'dataframe' must be provided.")

    if output_path is None:
        raise ValueError("The 'output_path' must be specified.")

    if not str(output_path).lower().endswith('.xlsx'):
        raise ValueError("The 'output_path' must be an .xlsx file.")

    output_dir = os.path.dirname(os.path.abspath(str(output_path)))
    if not os.path.isdir(output_dir):
        raise FileNotFoundError(f"Output directory does not exist: '{output_dir}'")

    if input_path is not None and not os.path.exists(input_path):
        raise FileNotFoundError(f"The Input File: '{input_path}' does not exist.")

    if output_sheet is not None:
        output_sheet = output_sheet.strip()
        if not output_sheet:
            raise ValueError("'output_sheet' must not be blank or whitespace-only.")
        bad_chars = _INVALID_SHEET_CHARS & set(output_sheet)
        if bad_chars:
            raise ValueError(
                f"'output_sheet' contains invalid Excel characters: {bad_chars}. "
                "Sheet names cannot contain [ ] : * ? / \\"
            )
        if len(output_sheet) > 31:
            raise ValueError(
                f"'output_sheet' is {len(output_sheet)} characters; Excel allows at most 31."
            )

    # =========================================================================
    # FILE LOADING & DATA PREPARATION
    # =========================================================================

    wb: Workbook
    ws = None  # assigned in every branch below; declared here to satisfy static analysis

    if input_path is not None:
        file_extension = os.path.splitext(input_path)[1].lower()

        # ── EXCEL ──────────────────────────────────────────────────────────
        if file_extension == '.xlsx':
            wb = load_workbook(input_path)

            if input_sheet is not None:
                if input_sheet not in wb.sheetnames:
                    raise ValueError(
                        f"Sheet '{input_sheet}' not found. "
                        f"Available: {', '.join(wb.sheetnames)}"
                    )
                ws = wb[input_sheet]
            else:
                ws = wb.active

            for sheet_name in list(wb.sheetnames):
                if sheet_name != ws.title:
                    del wb[sheet_name]

            # Minimal load-time clean: remove illegal chars that would corrupt the
            # XML on save. Full normalisation (whitespace / \r / \xa0) happens in
            # Step 1 so the progress bar reflects the work accurately.
            for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
                for cell in row:
                    if isinstance(cell.value, str):
                        cleaned = ILLEGAL_CHARACTERS_RE.sub("", cell.value)
                        if cleaned != cell.value:
                            cell.value = cleaned
                        if cell.value and cell.value[0] in _FORMULA_CHARS:
                            cell.data_type = 's'

        # ── CSV ────────────────────────────────────────────────────────────
        elif file_extension == '.csv':
            df = pd.read_csv(input_path)
            if df.empty:
                raise ValueError(f"The CSV file '{input_path}' is empty.")

            wb = Workbook()
            ws = wb.active
            write_df_to_ws(ws, df)

        else:
            raise ValueError(
                f"Unsupported file extension '{file_extension}'. "
                "Input must be .xlsx or .csv."
            )

    # ── DATAFRAME ──────────────────────────────────────────────────────────
    elif dataframe is not None:
        if dataframe.empty:
            raise ValueError("The provided DataFrame is empty.")

        wb = Workbook()
        ws = wb.active
        write_df_to_ws(ws, dataframe)

    # =========================================================================
    # SHEET NAMING
    # =========================================================================

    ws.title = output_sheet if output_sheet else "Sheet"

    # =========================================================================
    # HEADER PROCESSING
    # =========================================================================

    # max_row == 1 means only a header row exists; no data to format.
    if ws.max_row < 2:
        raise ValueError("The worksheet has no data rows. Cannot format.")

    # Build lowercased header list for column-name matching.
    # The actual header cells in the workbook are NOT modified here.
    header_row = []
    for idx, cell in enumerate(ws[1], start=1):
        if isinstance(cell.value, str) and cell.value.strip():
            header_row.append(cell.value.lower().strip())
        elif cell.value is not None:
            header_row.append(str(cell.value).lower().strip())
        else:
            header_row.append(f"unnamed_column_{idx}")

    # =========================================================================
    # COLUMN CONFIGURATION  (all lowercase to match normalised headers)
    # =========================================================================

    # created_at is intentionally in both date_columns AND columns_formats
    date_columns = {
        'start_date', 'start_time', 'end_date', 'end_time',
        'date of posting', 'date', 'start date', 'start time',
        'end date', 'end time', 'created_at',
    }
    id_columns = {
        'id', 'int id', 'internal_id', 'internal id',
        'session_id', 'session id', 'display_id', 'display id',
        'abstract_id', 'abstract id',
    }
    title_columns = {
        'abstract', 'title', 'tweet text', 'abstract title', 'session title',
        'abstract_title', 'session_title', 'old abstract', 'old title',
        'full abstract', 'full_abstract_text', 'full abstract text',
        'old session title', 'old abstract title',
    }
    url_columns = {'abstract link', 'url', 'link', 'abstract_link', 'ferma link', 'tweet url'}

    # =========================================================================
    # FORMATTING PIPELINE
    # =========================================================================

    unmatched_columns: set = set()

    # Snapshot dimensions once so dynamic ws.max_row/max_column changes mid-pipeline
    # (e.g. cells set to None shrinking the reported range) don't skip rows/columns.
    _max_row = ws.max_row
    _max_col = ws.max_column

    with tqdm(total=_TOTAL_STEPS, desc="Formatting Progress") as pbar:

        # ─────────────────────────────────────────────────────────────────────
        # Step 1: Full cell-value normalisation
        #   • Illegal XML characters
        #   • \r\n / \r  →  \n
        #   • \xa0 (non-breaking space)  →  regular space
        #   • Strip leading / trailing whitespace
        #   • Empty string  →  None
        # ─────────────────────────────────────────────────────────────────────
        try:
            for row in ws.iter_rows(min_row=1, max_row=_max_row, min_col=1, max_col=_max_col):
                for cell in row:
                    if isinstance(cell.value, str):
                        cleaned = clean_cell_value(cell.value)
                        if cleaned != cell.value:
                            cell.value = cleaned
                        if isinstance(cell.value, str) and cell.value and cell.value[0] in _FORMULA_CHARS:
                            cell.data_type = 's'
        except Exception as e:
            print(f"Step 1 – cell normalisation error: {e}")
        finally:
            pbar.update(1)

        # ─────────────────────────────────────────────────────────────────────
        # Step 2: Sort by priority and apply conditional row colouring
        #
        # Sorting order:  Very High → High → Internal → Medium → Low → Not Relevant
        # Colours:
        #   Very High    – Light Blue  (A5B3F7)
        #   High         – Teal        (39C7A5)
        #   Medium       – Yellow      (FFCA42)
        #   Low          – Pink        (EA4970)
        #   Not Relevant – Light Grey  (A2A2A7)
        #   Internal     – no fill
        # ─────────────────────────────────────────────────────────────────────
        try:
            if 'priority' in header_row and _max_row >= 2:
                priority_col_index = header_row.index('priority') + 1

                priority_order   = ['Very High', 'High', 'Internal', 'Medium', 'Low', 'Not Relevant']
                priority_sort_map = {p: i for i, p in enumerate(priority_order)}

                colors = {
                    'Very High':    'A5B3F7',
                    'High':         '39C7A5',
                    'Medium':       'FFCA42',
                    'Low':          'EA4970',
                    'Not Relevant': 'A2A2A7',
                    'Internal':     None,
                }

                # Sorting destroys merged-cell integrity — skip sort if any merges exist
                if ws.merged_cells.ranges:
                    pass
                else:
                    import copy

                    # Skip sort if any data cell contains a formula — row-relative
                    # references (=A5+B5) are not updated when rows move positions.
                    has_formulas = any(
                        cell.data_type == 'f'
                        for row in ws.iter_rows(min_row=2, max_row=_max_row, min_col=1, max_col=_max_col)
                        for cell in row
                    )

                    extracted_rows = []
                    if not has_formulas:
                        for row in ws.iter_rows(min_row=2, max_row=_max_row, min_col=1, max_col=_max_col, values_only=False):
                            row_data = []
                            for cell in row:
                                row_data.append({
                                    'value': cell.value,
                                    'data_type': cell.data_type,
                                    # copy.copy gives an independent StyleArray so that
                                    # in-place mutations by Steps 3-9 (font/fill/border)
                                    # don't corrupt this captured snapshot.
                                    '_style': copy.copy(cell._style),
                                    'hyperlink': copy.copy(cell.hyperlink) if cell.hyperlink else None,
                                    'comment': cell.comment
                                })
                            extracted_rows.append(row_data)

                    if extracted_rows:
                        def _priority_key(r):
                            val = r[priority_col_index - 1]['value']
                            if val is None:
                                return float('inf')
                            normalized = str(val).strip().title()
                            return priority_sort_map.get(normalized, float('inf'))

                        extracted_rows.sort(key=_priority_key)
                        for row_idx, row_data in enumerate(extracted_rows, start=2):
                            for col_idx, cell_data in enumerate(row_data, start=1):
                                c = ws.cell(row=row_idx, column=col_idx)
                                c.value      = cell_data['value']
                                c.data_type  = cell_data['data_type']
                                c._style     = cell_data['_style']
                                c.hyperlink  = cell_data['hyperlink']
                                c.comment    = cell_data['comment']

                # Apply priority fill colours (works whether or not we sorted)
                for row_idx in range(2, _max_row + 1):
                    priority_cell      = ws.cell(row=row_idx, column=priority_col_index)
                    priority_raw       = priority_cell.value
                    priority_normalized = str(priority_raw).strip().title() if priority_raw is not None else None
                    color = colors.get(priority_normalized)
                    if color:
                        priority_cell.fill = PatternFill(
                            start_color=color, end_color=color, fill_type="solid"
                        )

        except Exception as e:
            print(f"Step 2 – sort/colour formatting error: {e}")
        finally:
            pbar.update(1)

        # ─────────────────────────────────────────────────────────────────────
        # Step 3: Data row formatting
        #   Font: Manrope 10pt  |  Row height: 48.75
        # ─────────────────────────────────────────────────────────────────────
        try:
            data_font = Font(name="Manrope", size=10)
            for row_idx in range(2, _max_row + 1):
                ws.row_dimensions[row_idx].height = _DATA_ROW_HEIGHT
            for row in ws.iter_rows(min_row=2, max_row=_max_row, min_col=1, max_col=_max_col):
                for cell in row:
                    cell.font = data_font
        except Exception as e:
            print(f"Step 3 – data row formatting error: {e}")
        finally:
            pbar.update(1)

        # ─────────────────────────────────────────────────────────────────────
        # Step 4: Column alignment
        #   Center (center/center): ID columns, 'priority', all-numeric columns
        #   Right  (right/bottom):  Date columns, all-date columns
        #   Left   (left/top):      Everything else  [default]
        # ─────────────────────────────────────────────────────────────────────
        try:
            center_alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            left_alignment   = Alignment(horizontal="left",   vertical="top",    wrap_text=True)
            date_alignment   = Alignment(horizontal="right",  vertical="bottom", wrap_text=True)

            for col_index, col_cells in enumerate(
                ws.iter_cols(min_row=2, max_row=_max_row, min_col=1, max_col=_max_col),
                start=1,
            ):
                col_name        = header_row[col_index - 1] if col_index - 1 < len(header_row) else ""
                non_none_values = [c.value for c in col_cells if c.value is not None]

                if col_name in id_columns or col_name == 'priority':
                    alignment = center_alignment
                elif col_name in date_columns:
                    alignment = date_alignment
                elif non_none_values and all(is_numeric(v) for v in non_none_values):
                    alignment = center_alignment
                elif non_none_values and all(is_date(v) for v in non_none_values):
                    alignment = date_alignment
                else:
                    alignment = left_alignment

                for c in col_cells:
                    c.alignment = alignment

        except Exception as e:
            print(f"Step 4 – column alignment error: {e}")
        finally:
            pbar.update(1)

        # ─────────────────────────────────────────────────────────────────────
        # Step 5: Column widths
        #   Title columns: 60  |  ID columns: 12  |  Date columns: 22  |  Default: 21
        # ─────────────────────────────────────────────────────────────────────
        try:
            column_width_map = {
                **dict.fromkeys(title_columns, _TITLE_COL_WIDTH),
                **dict.fromkeys(id_columns,    _ID_COL_WIDTH),
                **dict.fromkeys(date_columns,  _DATE_COL_WIDTH),
            }
            for col_index in range(1, _max_col + 1):
                col_letter = get_column_letter(col_index)
                col_name   = header_row[col_index - 1] if col_index - 1 < len(header_row) else ""
                ws.column_dimensions[col_letter].width = column_width_map.get(col_name, _DEFAULT_COL_WIDTH)
        except Exception as e:
            print(f"Step 5 – column width error: {e}")
        finally:
            pbar.update(1)

        # ─────────────────────────────────────────────────────────────────────
        # Step 6: Hyperlink formatting
        #   Font: Manrope 10pt, blue (0000FF), underline single
        # ─────────────────────────────────────────────────────────────────────
        try:
            hyperlink_font = Font(name="Manrope", size=10, color="0000FF", underline="single")
            hyperlink_col_indices = [
                header_row.index(name) + 1
                for name in url_columns
                if name in header_row
            ]
            for col_index in hyperlink_col_indices:
                # iter_cols returns a tuple of cells per column; unpack the single column
                for col_cells in ws.iter_cols(
                    min_row=2, max_row=_max_row, min_col=col_index, max_col=col_index
                ):
                    for c in col_cells:
                        if c.value and isinstance(c.value, str):
                            url_value = c.value.strip()
                            if url_value.startswith(('http://', 'https://')):
                                try:
                                    c.hyperlink = url_value
                                    c.font = hyperlink_font
                                except Exception:
                                    pass
        except Exception as e:
            print(f"Step 6 – hyperlink formatting error: {e}")
        finally:
            pbar.update(1)

        # ─────────────────────────────────────────────────────────────────────
        # Step 7: Date / time formatting
        #
        # Parsing strategy:
        #   1. Already a datetime  → use as-is
        #   2. Bare date object    → promote to datetime at midnight
        #   3. String              → try strptime with known format, fall back to dateutil
        # ─────────────────────────────────────────────────────────────────────
        try:
            columns_formats = {
                'date':            {'initial': "%Y-%m-%d %H:%M:%S", 'desired': 'dddd, dd mmmm yyyy'},
                'start_time':      {'initial': "%Y-%m-%d %H:%M:%S", 'desired': 'hh:mm am/pm'},
                'end_time':        {'initial': "%Y-%m-%d %H:%M:%S", 'desired': 'hh:mm am/pm'},
                'start time':      {'initial': "%Y-%m-%d %H:%M:%S", 'desired': 'hh:mm am/pm'},
                'end time':        {'initial': "%Y-%m-%d %H:%M:%S", 'desired': 'hh:mm am/pm'},
                'start_date':      {'initial': '%Y-%m-%d %H:%M:%S', 'desired': 'yyyy-mm-dd hh:mm:ss'},
                'end_date':        {'initial': '%Y-%m-%d %H:%M:%S', 'desired': 'yyyy-mm-dd hh:mm:ss'},
                'start date':      {'initial': '%Y-%m-%d %H:%M:%S', 'desired': 'yyyy-mm-dd hh:mm:ss'},
                'end date':        {'initial': '%Y-%m-%d %H:%M:%S', 'desired': 'yyyy-mm-dd hh:mm:ss'},
                'date of posting': {'initial': "%Y-%m-%d %H:%M:%S", 'desired': 'dd-mm-yyyy'},
                'created_at':      {'initial': "%Y-%m-%d %H:%M:%S", 'desired': 'dd-mm-yyyy'},
            }

            for column_name, fmt in columns_formats.items():
                if column_name not in header_row:
                    continue

                column_index   = header_row.index(column_name) + 1
                initial_format = fmt['initial']
                desired_format = fmt['desired']

                for col_cells in ws.iter_cols(
                    min_row=2, max_row=_max_row,
                    min_col=column_index, max_col=column_index,
                ):
                    for cell in col_cells:
                        # Use 'is not None' to avoid skipping 0 (valid date serial)
                        if cell.value is None:
                            continue
                        try:
                            if isinstance(cell.value, datetime):
                                dt = cell.value
                            elif isinstance(cell.value, date):
                                # Promote bare date → datetime (midnight) for uniform handling
                                dt = datetime(cell.value.year, cell.value.month, cell.value.day)
                            else:
                                raw = str(cell.value)
                                try:
                                    dt = datetime.strptime(raw, initial_format)
                                except ValueError:
                                    dt = parser.parse(raw)
                            cell.value         = dt
                            cell.number_format = desired_format
                        except Exception:
                            unmatched_columns.add(column_name)

        except Exception as e:
            print(f"Step 7 – date formatting error: {e}")
        finally:
            pbar.update(1)

        # ─────────────────────────────────────────────────────────────────────
        # Step 8: Borders (thin, all sides, all cells)
        # ─────────────────────────────────────────────────────────────────────
        try:
            border = Border(
                left=Side(style="thin"), right=Side(style="thin"),
                top=Side(style="thin"),  bottom=Side(style="thin"),
            )
            for row in ws.iter_rows(min_row=1, max_row=_max_row, min_col=1, max_col=_max_col):
                for cell in row:
                    cell.border = border
        except Exception as e:
            print(f"Step 8 – border formatting error: {e}")
        finally:
            pbar.update(1)

        # ─────────────────────────────────────────────────────────────────────
        # Step 9: Header row formatting
        #   Font: Playfair Display Black, 11pt, bold, white (FFFFFF)
        #   Fill: Blue (1E41EB)  |  Alignment: center/center, wrap
        #   Row height: 38
        # ─────────────────────────────────────────────────────────────────────
        try:
            header_font      = Font(name="Playfair Display Black", size=11, bold=True, color="FFFFFF")
            header_alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            header_fill      = PatternFill(start_color="1E41EB", end_color="1E41EB", fill_type="solid")

            for cell in ws[1]:
                cell.font      = header_font
                cell.alignment = header_alignment
                cell.fill      = header_fill

            ws.row_dimensions[1].height = _HEADER_ROW_HEIGHT

        except Exception as e:
            print(f"Step 9 – header formatting error: {e}")
        finally:
            pbar.update(1)

    # =========================================================================
    # SAVE
    # =========================================================================

    wb.save(output_path)

    if unmatched_columns:
        print(f"• Unmatched Date Formats: {list(unmatched_columns)}")