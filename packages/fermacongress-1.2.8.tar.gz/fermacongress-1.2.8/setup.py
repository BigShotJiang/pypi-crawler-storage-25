from setuptools import setup, find_packages

setup(
    name='FermaCongress',
    version='1.2.8',
    author='Ferma Congress Team',
    author_email='hema.murapaka@zoomrx.com',
    license='MIT',
    url = 'https://www.zoomrx.com/ferma/',
    packages=find_packages(),
    python_requires='>=3.7'
)