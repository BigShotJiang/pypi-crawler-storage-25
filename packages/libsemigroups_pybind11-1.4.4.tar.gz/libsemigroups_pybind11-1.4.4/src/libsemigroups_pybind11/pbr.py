# Copyright (c) 2024 Joseph Edwards
#
# Distributed under the terms of the GPL license version 3.
#
# The full license is in the file LICENSE, distributed with this software.

"""This page contains the documentation for the ``pbr`` subpackage, that
contains helper functions for the :any:`PBR` class.
"""

from _libsemigroups_pybind11 import pbr_one as one  # pylint: disable=unused-import
