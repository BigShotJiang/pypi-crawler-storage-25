# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

Use `uv` for all package management:

```bash
uv sync                        # Install basic dependencies
uv sync --all-extras --dev     # Install all dependencies including dev tools
```

| Task | Command |
|------|---------|
| Run | `python main.py <input_file> [--output out.py] [--iterations N] [--debug]` |
| Test | `make test` → `uv run pytest tests/` |
| Lint | `make lint` → `uv run ruff check .` |
| Format | `make format` → `uv run black . && uv run ruff check . --fix` |
| Typecheck | `make typecheck` → `uv run mypy . --ignore-missing-imports` |
| Single test | `uv run pytest tests/test_transformers.py::TestName -v` |

## Architecture

Noctyra is an AST-based Python deobfuscation/transformation framework. It parses a Python source file, runs a pipeline of AST transformers iteratively until no changes occur (or a fixed iteration count), then formats and writes the result.

**Execution flow:**

```
main.py → ast.parse() → TransformerPipeline → black.format_str() → output file
```

**TransformerPipeline** (`transformers/pipeline.py`) runs five transformers in sequence each iteration:

1. **ConstsTransformer** (`constants.py`) — constant folding, encoding/compression calls (base64, zlib, brotli, etc.)
2. **BasicFunctions** (`functions.py`) — `exec()` unrolling, evaluation of `ord`, `chr`, `int`, `str`, `bytes`, etc.
3. **BasicAttributes** (`attributes.py`) — string/bytes method resolution (`.decode`, `.join`, `.hex`, etc.) when all arguments are constant
4. **LCTransformer** (`listcomp.py`) — folds list comprehensions and generators into literal lists
5. **ConditionSimplifier** (`condsimplifier.py`) — simplifies comparisons and chained boolean expressions

**SafeEval** (`transformers/safe_eval.py`) is the core evaluation engine used by most transformers. It walks AST nodes to evaluate constant expressions safely, with hard resource limits (100,000 bytes max allocation, ±100,000 numeric range, whitelist of allowed operators/functions).

**SharedUtils** (`utils/shared.py`) holds maps reused across transformers: operator functions, safe built-ins, and encoding/compression handlers (including third-party: brotli, zstd, blosc).

## Key constraints

- **Python ≥ 3.14** required (uses newer AST APIs).
- SafeEval is intentionally restricted — never expand it without considering bypass risks. For untrusted input, run in an external sandbox.
- Transformers must be **idempotent**: applying them twice should produce the same result as once.
- Pre-commit hooks run ruff (lint + format) and mypy automatically on commit.
