"""Tests for scrape tool (wait-with-fallback)."""
import pytest
import respx

from scraping_mcp.config import Settings
from scraping_mcp.http_client import build_client
from scraping_mcp.errors import McpToolError
from scraping_mcp.tools.scrape import scrape_impl


@pytest.fixture
def settings(monkeypatch, mock_api_key):
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    monkeypatch.setenv("SCRAPING_BASE_URL", "http://api.test")
    return Settings()


@pytest.mark.asyncio
async def test_scrape_happy_single_poll(settings):
    """POST → первый polling цикл сразу finished."""
    http = build_client(settings)
    with respx.mock:
        respx.post("http://api.test/v1/scrape").respond(202, json={"task_id": "abc-1"})
        respx.get("http://api.test/v1/scrape/abc-1").respond(200, json={
            "task_id": "abc-1",
            "status": "finished",
            "result": {"markdown": "# OK"},
        })
        result = await scrape_impl(http, settings, url="https://example.com",
                                    format="markdown", cookies=None, timeout_s=60)
    assert result["status"] == "finished"
    assert result["result"]["markdown"] == "# OK"
    await http.aclose()


@pytest.mark.asyncio
async def test_scrape_timeout_returns_pending(settings, monkeypatch):
    """Timeout_s истёк до finished → {status: pending, task_id}."""
    http = build_client(settings)
    # Ускоряем тест: минимальный интервал поллинга
    monkeypatch.setattr(settings, "poll_interval_scrape_s", 0.01)

    with respx.mock:
        respx.post("http://api.test/v1/scrape").respond(202, json={"task_id": "abc-2"})
        # Всегда возвращает "running" — polling никогда не увидит finished
        respx.get("http://api.test/v1/scrape/abc-2").respond(200, json={
            "task_id": "abc-2",
            "status": "running",
        })
        result = await scrape_impl(http, settings, url="https://slow.com",
                                    format="markdown", cookies=None, timeout_s=1)  # 1 sec timeout
    assert result["status"] == "pending"
    assert result["task_id"] == "abc-2"
    assert result["elapsed_s"] >= 1
    await http.aclose()


@pytest.mark.asyncio
async def test_scrape_submit_unauthorized_raises(settings):
    http = build_client(settings)
    with respx.mock:
        respx.post("http://api.test/v1/scrape").respond(401)
        with pytest.raises(McpToolError) as exc:
            await scrape_impl(http, settings, url="https://x/", format="markdown",
                              cookies=None, timeout_s=60)
    assert exc.value.code == "invalid_api_key"
    await http.aclose()


@pytest.mark.asyncio
async def test_scrape_submit_insufficient_balance_raises(settings):
    http = build_client(settings)
    with respx.mock:
        respx.post("http://api.test/v1/scrape").respond(
            402, json={"error": {"code": "insufficient_balance",
                                  "details": {"required": 1, "available": 0}}}
        )
        with pytest.raises(McpToolError) as exc:
            await scrape_impl(http, settings, url="https://x/", format="markdown",
                              cookies=None, timeout_s=60)
    assert exc.value.code == "insufficient_balance"
    await http.aclose()


@pytest.mark.asyncio
async def test_scrape_poll_failed_raises(settings):
    """Worker failed → tool возвращает {status: failed, error}."""
    http = build_client(settings)
    with respx.mock:
        respx.post("http://api.test/v1/scrape").respond(202, json={"task_id": "abc-5"})
        respx.get("http://api.test/v1/scrape/abc-5").respond(200, json={
            "task_id": "abc-5", "status": "failed",
            "error": "L3 timeout",
        })
        result = await scrape_impl(http, settings, url="https://x/",
                                    format="markdown", cookies=None, timeout_s=60)
    assert result["status"] == "failed"
    assert "L3 timeout" in result["error"]
    await http.aclose()
