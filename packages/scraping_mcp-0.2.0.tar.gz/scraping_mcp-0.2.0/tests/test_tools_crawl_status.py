"""Tests for get_crawl_status tool (+ items fan-out для total > 50)."""
import pytest
import respx

from scraping_mcp.config import Settings
from scraping_mcp.http_client import build_client
from scraping_mcp.errors import McpToolError
from scraping_mcp.tools.crawl import get_crawl_status_impl


@pytest.fixture
def settings(monkeypatch, mock_api_key):
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    monkeypatch.setenv("SCRAPING_BASE_URL", "http://api.test")
    return Settings()


@pytest.mark.asyncio
async def test_get_crawl_status_small_batch_inline_items(settings):
    """total=2, include_items=True → items в одном GET, без дополнительного fan-out."""
    http = build_client(settings)
    body = {
        "crawl_id": "cid-1",
        "status": "finished",
        "total": 2, "succeeded": 2, "failed": 0,
        "cookies_supplied": False,
        "submitted_at": "2026-04-23T00:00:00Z",
        "items": [
            {"task_id": "t1", "url": "https://a/", "status": "finished",
             "cost": 1, "layer_used": "L1"},
            {"task_id": "t2", "url": "https://b/", "status": "finished",
             "cost": 1, "layer_used": "L1"},
        ],
    }
    with respx.mock:
        respx.get("http://api.test/v1/crawl/cid-1", params={"include_items": "true"}).respond(200, json=body)
        result = await get_crawl_status_impl(http, "cid-1", include_items=True)
    assert result["status"] == "finished"
    assert len(result["items"]) == 2
    await http.aclose()


@pytest.mark.asyncio
async def test_get_crawl_status_large_batch_fans_out_items(settings):
    """total=60 + include_items=True → items endpoint пагинирован cursor'ом до всех."""
    http = build_client(settings)
    status_body = {
        "crawl_id": "cid-2",
        "status": "finished",
        "total": 60, "succeeded": 60, "failed": 0,
        "cookies_supplied": False,
        "submitted_at": "2026-04-23T00:00:00Z",
        # items NOT present — phase-3.1 omits inline items когда total > 50
    }
    # Page 1: 50 items, next_cursor=50
    page1 = {"items": [{"task_id": f"t{i}", "url": f"https://{i}/",
                         "status": "finished", "cost": 1} for i in range(50)],
             "next_cursor": 50}
    page2 = {"items": [{"task_id": f"t{i}", "url": f"https://{i}/",
                         "status": "finished", "cost": 1} for i in range(50, 60)],
             "next_cursor": None}
    with respx.mock:
        respx.get("http://api.test/v1/crawl/cid-2", params={"include_items": "true"}).respond(200, json=status_body)
        # Более специфичный маршрут (с cursor) регистрируем первым — respx 0.21 матчит
        # первый подходящий маршрут; маршрут без cursor иначе поглощал бы все запросы.
        respx.get("http://api.test/v1/crawl/cid-2/items", params={"limit": "200", "cursor": "50"}).respond(200, json=page2)
        respx.get("http://api.test/v1/crawl/cid-2/items", params={"limit": "200"}).respond(200, json=page1)
        result = await get_crawl_status_impl(http, "cid-2", include_items=True)
    assert result["total"] == 60
    assert len(result["items"]) == 60
    await http.aclose()


@pytest.mark.asyncio
async def test_get_crawl_status_without_items(settings):
    """include_items=False → items поле отсутствует."""
    http = build_client(settings)
    body = {
        "crawl_id": "cid-3",
        "status": "running",
        "total": 100, "succeeded": 30, "failed": 2,
        "cookies_supplied": False,
        "submitted_at": "2026-04-23T00:00:00Z",
    }
    with respx.mock:
        respx.get("http://api.test/v1/crawl/cid-3", params={"include_items": "false"}).respond(200, json=body)
        result = await get_crawl_status_impl(http, "cid-3", include_items=False)
    assert result["total"] == 100
    assert "items" not in result or result.get("items") is None
    await http.aclose()


@pytest.mark.asyncio
async def test_get_crawl_status_not_found(settings):
    http = build_client(settings)
    with respx.mock:
        respx.get("http://api.test/v1/crawl/xxx").respond(404)
        with pytest.raises(McpToolError) as exc:
            await get_crawl_status_impl(http, "xxx", include_items=True)
    assert exc.value.code == "not_found"
    await http.aclose()


@pytest.mark.asyncio
async def test_get_crawl_status_fan_out_exceeds_cap(settings):
    """Сервер всегда возвращает non-None cursor → fan-out должен упасть с upstream_error."""
    from scraping_mcp.tools.crawl import MAX_ITEMS_PAGES

    http = build_client(settings)
    status_body = {
        "crawl_id": "cid-cap",
        "status": "finished",
        "total": 5000, "succeeded": 5000, "failed": 0,
        "cookies_supplied": False,
        "submitted_at": "2026-04-23T00:00:00Z",
    }
    # Страница items всегда возвращает непустой cursor — бесконечная пагинация
    endless_page = {
        "items": [{"task_id": "t0", "url": "https://x/", "status": "finished", "cost": 1}],
        "next_cursor": "never-ends",
    }
    with respx.mock:
        respx.get("http://api.test/v1/crawl/cid-cap", params={"include_items": "true"}).respond(200, json=status_body)
        # respx матчит любой GET на /items (независимо от cursor-параметра)
        respx.get("http://api.test/v1/crawl/cid-cap/items").respond(200, json=endless_page)
        with pytest.raises(McpToolError) as exc:
            await get_crawl_status_impl(http, "cid-cap", include_items=True)
    assert exc.value.code == "upstream_error"
    assert exc.value.data["crawl_id"] == "cid-cap"
    assert exc.value.data["max_pages"] == MAX_ITEMS_PAGES
    await http.aclose()
