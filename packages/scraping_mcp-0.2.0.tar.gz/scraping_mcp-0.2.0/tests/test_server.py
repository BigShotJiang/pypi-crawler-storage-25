"""Tests for server bootstrap — регистрация tools + CLI entry point."""
import sys
from unittest.mock import patch

import pytest

from scraping_mcp.config import Settings
from scraping_mcp.server import create_server


# ---------------------------------------------------------------------------
# Фикстуры
# ---------------------------------------------------------------------------


@pytest.fixture
def settings(monkeypatch, mock_api_key):
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    return Settings()


# ---------------------------------------------------------------------------
# Тест 1: create_server регистрирует ровно 5 tools
# ---------------------------------------------------------------------------


def test_create_server_registers_five_tools(settings):
    """create_server → 5 зарегистрированных tools в FastMCP registry."""
    server = create_server(settings)
    # FastMCP хранит tools в _tool_manager._tools (dict name→Tool)
    tools = server._tool_manager
    assert hasattr(tools, "_tools"), "FastMCP API изменилось — адаптировать тест"
    names = set(tools._tools.keys())
    assert {"scrape", "crawl", "get_scrape_status", "get_crawl_status", "get_balance"}.issubset(names), (
        f"Ожидались 5 tools, зарегистрировано: {names}"
    )


# ---------------------------------------------------------------------------
# Тест 2: main() при отсутствии SCRAPING_API_KEY → stderr + exit 1
# ---------------------------------------------------------------------------


def test_main_missing_api_key_exits(monkeypatch, capsys):
    """Отсутствие SCRAPING_API_KEY → сообщение в stderr + SystemExit(1)."""
    monkeypatch.delenv("SCRAPING_API_KEY", raising=False)
    # Перезагружаем модуль чтобы не было кэша Settings
    from scraping_mcp.__main__ import main  # noqa: PLC0415

    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 1
    captured = capsys.readouterr()
    assert "SCRAPING_API_KEY" in captured.err


# ---------------------------------------------------------------------------
# Тест 3: main() с валидным env → вызывает server.run()
# ---------------------------------------------------------------------------


def test_main_starts_server_with_valid_env(monkeypatch, mock_api_key):
    """Валидный env → create_server() + server.run() вызываются."""
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    from scraping_mcp.__main__ import main  # noqa: PLC0415

    with patch("scraping_mcp.__main__.create_server") as mock_create:
        mock_server = mock_create.return_value
        main()
        mock_create.assert_called_once()
        mock_server.run.assert_called_once()
