"""Общие pytest-фикстуры для packages/mcp тестов."""
import pytest


@pytest.fixture
def mock_api_key() -> str:
    return "fc_live_test_" + "x" * 32


@pytest.fixture
def mock_base_url() -> str:
    return "http://localhost:8000"
