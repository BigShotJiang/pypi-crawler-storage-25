"""Tests for crawl tool (wait-with-fallback + items collection)."""
import pytest
import respx

from scraping_mcp.config import Settings
from scraping_mcp.http_client import build_client
from scraping_mcp.errors import McpToolError
from scraping_mcp.tools.crawl import crawl_impl


@pytest.fixture
def settings(monkeypatch, mock_api_key):
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    monkeypatch.setenv("SCRAPING_BASE_URL", "http://api.test")
    return Settings()


@pytest.mark.asyncio
async def test_crawl_happy_small_batch(settings, monkeypatch):
    monkeypatch.setattr(settings, "poll_interval_crawl_s", 0.01)
    http = build_client(settings)
    with respx.mock:
        respx.post("http://api.test/v1/crawl").respond(202, json={
            "crawl_id": "cid-1", "status": "pending", "total": 2,
            "credits_debited": 2, "submitted_at": "2026-04-23T00:00:00Z",
        })
        # Polls for status
        respx.get("http://api.test/v1/crawl/cid-1", params={"include_items": "true"}).respond(200, json={
            "crawl_id": "cid-1", "status": "finished",
            "total": 2, "succeeded": 2, "failed": 0,
            "cookies_supplied": False, "submitted_at": "2026-04-23T00:00:00Z",
            "items": [
                {"task_id": "t1", "url": "https://a/", "status": "finished", "cost": 1},
                {"task_id": "t2", "url": "https://b/", "status": "finished", "cost": 1},
            ],
        })
        result = await crawl_impl(http, settings,
                                   urls=["https://a/", "https://b/"],
                                   cookies=None, timeout_s=600)
    assert result["status"] == "finished"
    assert result["succeeded"] == 2
    assert len(result["items"]) == 2
    await http.aclose()


@pytest.mark.asyncio
async def test_crawl_timeout_returns_pending(settings, monkeypatch):
    monkeypatch.setattr(settings, "poll_interval_crawl_s", 0.01)
    http = build_client(settings)
    with respx.mock:
        respx.post("http://api.test/v1/crawl").respond(202, json={
            "crawl_id": "cid-2", "status": "pending", "total": 50,
            "credits_debited": 50, "submitted_at": "2026-04-23T00:00:00Z",
        })
        # Polls always "running"
        respx.get("http://api.test/v1/crawl/cid-2", params={"include_items": "true"}).respond(200, json={
            "crawl_id": "cid-2", "status": "running",
            "total": 50, "succeeded": 10, "failed": 0,
            "cookies_supplied": False, "submitted_at": "2026-04-23T00:00:00Z",
        })
        result = await crawl_impl(http, settings,
                                   urls=[f"https://{i}/" for i in range(50)],
                                   cookies=None, timeout_s=1)
    assert result["status"] == "pending"
    assert result["crawl_id"] == "cid-2"
    assert result["total"] == 50
    assert result["succeeded"] == 10
    assert result["elapsed_s"] >= 1
    await http.aclose()


@pytest.mark.asyncio
async def test_crawl_submit_insufficient_balance(settings):
    http = build_client(settings)
    with respx.mock:
        respx.post("http://api.test/v1/crawl").respond(
            402, json={"error": {"code": "insufficient_balance",
                                  "details": {"required": 100, "available": 5}}},
        )
        with pytest.raises(McpToolError) as exc:
            await crawl_impl(http, settings,
                             urls=[f"https://{i}/" for i in range(100)],
                             cookies=None, timeout_s=600)
    assert exc.value.code == "insufficient_balance"
    await http.aclose()


@pytest.mark.asyncio
async def test_crawl_with_cookies_forwards_in_body(settings, monkeypatch):
    monkeypatch.setattr(settings, "poll_interval_crawl_s", 0.01)
    http = build_client(settings)
    cookies = [{"name": "session", "value": "sss", "domain": ".x.com"}]
    with respx.mock:
        route = respx.post("http://api.test/v1/crawl").respond(202, json={
            "crawl_id": "cid-3", "status": "pending", "total": 1,
            "credits_debited": 1, "submitted_at": "2026-04-23T00:00:00Z",
        })
        respx.get("http://api.test/v1/crawl/cid-3", params={"include_items": "true"}).respond(200, json={
            "crawl_id": "cid-3", "status": "finished",
            "total": 1, "succeeded": 1, "failed": 0,
            "cookies_supplied": True, "submitted_at": "2026-04-23T00:00:00Z",
            "items": [{"task_id": "t", "url": "https://x.com/", "status": "finished", "cost": 1}],
        })
        await crawl_impl(http, settings, urls=["https://x.com/"],
                         cookies=cookies, timeout_s=600)
    # Request body должен содержать cookies
    import json
    submit_body = json.loads(route.calls.last.request.content)
    assert submit_body["cookies"] == cookies
    await http.aclose()
