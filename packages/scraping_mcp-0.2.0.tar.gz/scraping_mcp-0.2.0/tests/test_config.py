"""Tests for scraping_mcp.config — env-var-based Settings."""
import pytest
from pydantic import ValidationError


def test_settings_requires_api_key(monkeypatch):
    """Отсутствие SCRAPING_API_KEY → ValidationError (fail-fast)."""
    from scraping_mcp.config import Settings
    monkeypatch.delenv("SCRAPING_API_KEY", raising=False)
    with pytest.raises(ValidationError):
        Settings()


def test_settings_loads_from_env(monkeypatch, mock_api_key):
    from scraping_mcp.config import Settings
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    monkeypatch.setenv("SCRAPING_BASE_URL", "https://api.example.com")
    s = Settings()
    assert s.api_key == mock_api_key
    assert s.base_url == "https://api.example.com"


def test_settings_defaults(monkeypatch, mock_api_key):
    """Defaults: localhost base_url, 60s scrape, 600s crawl, 30s request."""
    from scraping_mcp.config import Settings
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    monkeypatch.delenv("SCRAPING_BASE_URL", raising=False)
    monkeypatch.delenv("SCRAPING_SCRAPE_TIMEOUT_S", raising=False)
    s = Settings()
    assert s.base_url == "http://localhost:8000"
    assert s.scrape_timeout_s == 60
    assert s.crawl_timeout_s == 600
    assert s.request_timeout_s == 30
    assert s.poll_interval_scrape_s == 1.5
    assert s.poll_interval_crawl_s == 2.5


def test_settings_case_insensitive(monkeypatch, mock_api_key):
    """Env vars case-insensitive (MCP client configs могут путать case)."""
    from scraping_mcp.config import Settings
    monkeypatch.setenv("scraping_api_key", mock_api_key)
    s = Settings()
    assert s.api_key == mock_api_key
