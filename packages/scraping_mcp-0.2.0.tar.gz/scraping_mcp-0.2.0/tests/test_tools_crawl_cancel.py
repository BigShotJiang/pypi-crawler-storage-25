"""Tests for cancel_crawl tool — DELETE /v1/crawl/{id} wrapper."""
import pytest
import respx

from scraping_mcp.config import Settings
from scraping_mcp.errors import McpToolError
from scraping_mcp.http_client import build_client
from scraping_mcp.tools.crawl import cancel_crawl_impl


@pytest.fixture
def settings(monkeypatch, mock_api_key):
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    monkeypatch.setenv("SCRAPING_BASE_URL", "http://api.test")
    return Settings()


@pytest.mark.asyncio
async def test_cancel_crawl_happy(settings):
    http = build_client(settings)
    with respx.mock:
        respx.delete("http://api.test/v1/crawl/cid-1").respond(200, json={
            "status": "cancelled",
            "cancelled_urls": 3,
            "inflight_urls": 1,
            "refunded_credits": 3,
        })
        res = await cancel_crawl_impl(http, "cid-1")
    assert res["status"] == "cancelled"
    assert res["refunded_credits"] == 3
    await http.aclose()


@pytest.mark.asyncio
async def test_cancel_crawl_not_found_raises(settings):
    http = build_client(settings)
    with respx.mock:
        respx.delete("http://api.test/v1/crawl/missing").respond(
            404, json={"error": {"code": "not_found", "message": "no such crawl"}},
        )
        with pytest.raises(McpToolError) as exc:
            await cancel_crawl_impl(http, "missing")
    assert exc.value.code == "not_found"
    await http.aclose()
