"""Tests for get_scrape_status tool."""
import pytest
import respx

from scraping_mcp.config import Settings
from scraping_mcp.http_client import build_client
from scraping_mcp.errors import McpToolError
from scraping_mcp.tools.scrape import get_scrape_status_impl


@pytest.fixture
def settings(monkeypatch, mock_api_key):
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    monkeypatch.setenv("SCRAPING_BASE_URL", "http://api.test")
    return Settings()


@pytest.mark.asyncio
async def test_get_scrape_status_finished(settings):
    http = build_client(settings)
    body = {
        "task_id": "abc-123",
        "status": "finished",
        "result": {"markdown": "# Example"},
    }
    with respx.mock:
        respx.get("http://api.test/v1/scrape/abc-123").respond(200, json=body)
        result = await get_scrape_status_impl(http, "abc-123")
    assert result["status"] == "finished"
    assert result["result"]["markdown"] == "# Example"
    await http.aclose()


@pytest.mark.asyncio
async def test_get_scrape_status_pending(settings):
    http = build_client(settings)
    body = {"task_id": "abc-123", "status": "pending"}
    with respx.mock:
        respx.get("http://api.test/v1/scrape/abc-123").respond(200, json=body)
        result = await get_scrape_status_impl(http, "abc-123")
    assert result["status"] == "pending"
    await http.aclose()


@pytest.mark.asyncio
async def test_get_scrape_status_not_found(settings):
    http = build_client(settings)
    with respx.mock:
        respx.get("http://api.test/v1/scrape/xxx").respond(404)
        with pytest.raises(McpToolError) as exc:
            await get_scrape_status_impl(http, "xxx")
    assert exc.value.code == "not_found"
    await http.aclose()
