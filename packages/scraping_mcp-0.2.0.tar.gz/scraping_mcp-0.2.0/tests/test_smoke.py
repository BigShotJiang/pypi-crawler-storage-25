"""Smoke-test: package импортируется, version задана."""
import scraping_mcp


def test_package_imports():
    assert scraping_mcp.__version__ == "0.2.0"


def test_version_is_0_2_0():
    import scraping_mcp
    assert scraping_mcp.__version__ == "0.2.0"
