"""Tests for the new map tool — POST /v1/map wrapper."""
import pytest
import respx

from scraping_mcp.config import Settings
from scraping_mcp.errors import McpToolError
from scraping_mcp.http_client import build_client
from scraping_mcp.tools.map import map_impl


@pytest.fixture
def settings(monkeypatch, mock_api_key):
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    monkeypatch.setenv("SCRAPING_BASE_URL", "http://api.test")
    return Settings()


@pytest.mark.asyncio
async def test_map_happy(settings):
    http = build_client(settings)
    with respx.mock:
        respx.post("http://api.test/v1/map").respond(200, json={
            "url": "https://e.com/", "links": ["https://e.com/a", "https://e.com/b"],
            "total": 2, "source": "sitemap", "cached": False, "cached_at": None,
        })
        result = await map_impl(
            http, url="https://e.com", max_urls=5000,
            include_subdomains=False,
        )
    assert result["total"] == 2
    assert "https://e.com/a" in result["links"]
    await http.aclose()


@pytest.mark.asyncio
async def test_map_passes_max_urls_in_body(settings):
    http = build_client(settings)
    with respx.mock:
        route = respx.post("http://api.test/v1/map").respond(200, json={
            "url": "https://e.com/", "links": [], "total": 0,
            "source": "sitemap", "cached": False, "cached_at": None,
        })
        await map_impl(http, url="https://e.com", max_urls=42, include_subdomains=True)
    import json
    sent = json.loads(route.calls.last.request.content)
    assert sent["limit"] == 42
    assert sent["include_subdomains"] is True
    assert sent["url"] == "https://e.com"
    await http.aclose()


@pytest.mark.asyncio
async def test_map_502_raises_mcp_error(settings):
    http = build_client(settings)
    with respx.mock:
        respx.post("http://api.test/v1/map").respond(
            502, json={"error": {"code": "map_failed", "message": "dead"}},
        )
        with pytest.raises(McpToolError):
            await map_impl(
                http, url="https://e.com", max_urls=5000, include_subdomains=False,
            )
    await http.aclose()
