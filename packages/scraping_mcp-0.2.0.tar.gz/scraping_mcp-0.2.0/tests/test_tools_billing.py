"""Tests for get_balance tool."""
import pytest
import respx

from scraping_mcp.config import Settings
from scraping_mcp.http_client import build_client
from scraping_mcp.errors import McpToolError
from scraping_mcp.tools.billing import get_balance_impl


@pytest.fixture
def settings(monkeypatch, mock_api_key):
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    monkeypatch.setenv("SCRAPING_BASE_URL", "http://api.test")
    return Settings()


@pytest.mark.asyncio
async def test_get_balance_happy(settings):
    http = build_client(settings)
    with respx.mock:
        respx.get("http://api.test/v1/billing/balance").respond(200, json={"balance": 42})
        result = await get_balance_impl(http)
    assert result == {"balance": 42}
    await http.aclose()


@pytest.mark.asyncio
async def test_get_balance_unauthorized_raises(settings):
    http = build_client(settings)
    with respx.mock:
        respx.get("http://api.test/v1/billing/balance").respond(401)
        with pytest.raises(McpToolError) as exc:
            await get_balance_impl(http)
    assert exc.value.code == "invalid_api_key"
    await http.aclose()
