"""Tests for errors.map_api_error — REST → MCP error mapping."""
import httpx
import pytest

from scraping_mcp.errors import map_api_error, McpToolError


def _resp(status: int, json_body: dict | None = None) -> httpx.Response:
    return httpx.Response(status, json=json_body or {})


def test_401_maps_to_invalid_api_key():
    err = map_api_error(_resp(401))
    assert isinstance(err, McpToolError)
    assert err.code == "invalid_api_key"
    assert "SCRAPING_API_KEY" in err.message


def test_402_maps_to_insufficient_balance_with_details():
    body = {"error": {"code": "insufficient_balance", "details": {"required": 5, "available": 2}}}
    err = map_api_error(_resp(402, body))
    assert err.code == "insufficient_balance"
    assert err.data["details"]["required"] == 5
    assert err.data["details"]["available"] == 2


def test_403_maps_to_forbidden():
    err = map_api_error(_resp(403))
    assert err.code == "forbidden"


def test_404_maps_to_not_found():
    err = map_api_error(_resp(404))
    assert err.code == "not_found"


def test_409_maps_to_already_terminal():
    body = {"error": {"code": "already_terminal", "message": "Crawl is finished"}}
    err = map_api_error(_resp(409, body))
    assert err.code == "already_terminal"


def test_422_maps_to_invalid_input():
    body = {"detail": "urls must contain 1..500 items"}
    err = map_api_error(_resp(422, body))
    assert err.code == "invalid_input"
    assert "urls must contain" in err.message


def test_500_maps_to_server_error():
    err = map_api_error(_resp(500))
    assert err.code == "server_error"
