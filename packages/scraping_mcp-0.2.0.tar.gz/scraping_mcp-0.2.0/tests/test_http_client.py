"""Tests for http_client — async httpx wrapper."""
import pytest
import respx
import httpx

from scraping_mcp.config import Settings
from scraping_mcp.http_client import build_client
from scraping_mcp import __version__


@pytest.fixture
def settings(monkeypatch, mock_api_key):
    monkeypatch.setenv("SCRAPING_API_KEY", mock_api_key)
    monkeypatch.setenv("SCRAPING_BASE_URL", "http://api.test")
    return Settings()


@pytest.mark.asyncio
async def test_client_sends_bearer_header(settings):
    client = build_client(settings)
    with respx.mock:
        route = respx.get("http://api.test/v1/billing/balance").respond(200, json={"balance": 10})
        resp = await client.get("/v1/billing/balance")
        assert resp.status_code == 200
        # Verify Authorization header was sent
        captured = route.calls.last.request
        assert captured.headers["authorization"] == f"Bearer {settings.api_key}"
    await client.aclose()


@pytest.mark.asyncio
async def test_client_user_agent(settings):
    client = build_client(settings)
    with respx.mock:
        route = respx.get("http://api.test/x").respond(200)
        await client.get("/x")
        ua = route.calls.last.request.headers["user-agent"]
        assert ua == f"scraping-mcp/{__version__}"
    await client.aclose()


@pytest.mark.asyncio
async def test_client_base_url(settings):
    """base_url prepended к относительным path."""
    client = build_client(settings)
    with respx.mock:
        respx.get("http://api.test/v1/scrape/abc").respond(200)
        resp = await client.get("/v1/scrape/abc")
    assert resp.status_code == 200
    await client.aclose()
