# Changelog

## [0.2.0] - 2026-04-25

### Added
- `map(url, max_urls?, include_subdomains?)` tool — POST /v1/map wrapper.
  Returns sitemap-derived URL list with optional subdomain inclusion.
- `cancel_crawl(crawl_id)` tool — DELETE /v1/crawl/{id} wrapper.
  Cancels pending URLs of a crawl batch and triggers compensating refund.

### Changed
- README updated with full 7-tool list and Hosted MCP alternative pointer.

### Notes
- Stdio package now feature-parity with hosted MCP at `https://api.scraping.io/mcp/`.

## [0.1.0] - 2026-04-23

### Added
- Initial stdio MCP server with 5 tools: `scrape`, `get_scrape_status`,
  `crawl`, `get_crawl_status`, `get_balance`.
- Wait-with-fallback polling for `scrape` and `crawl` (returns
  `{status: "pending", task_id}` on timeout — agent calls `*_status` later).
- Configuration via env vars: `SCRAPING_API_KEY`, `SCRAPING_BASE_URL`,
  `SCRAPING_SCRAPE_TIMEOUT_S`, `SCRAPING_CRAWL_TIMEOUT_S`,
  `SCRAPING_REQUEST_TIMEOUT_S`.
- Published to PyPI as `scraping-mcp` (manual release).
