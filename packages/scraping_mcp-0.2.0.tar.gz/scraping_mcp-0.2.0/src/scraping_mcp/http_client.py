"""Async HTTP-клиент для обращения к Scraping REST API.

Настраивает Bearer-авторизацию, User-Agent, connection-level retry, request
timeout. Один AsyncClient на весь lifecycle процесса — pool переиспользуется.
"""
import httpx

from scraping_mcp import __version__
from scraping_mcp.config import Settings


def build_client(settings: Settings) -> httpx.AsyncClient:
    """Построить httpx.AsyncClient с Bearer auth + retry + timeout.

    Caller owns aclose(): клиент не закрывается внутри build_client;
    вызывающий код обязан вызвать await http.aclose() при завершении.

    - Authorization Bearer header из settings.api_key на каждый request.
    - User-Agent identified the MCP server version (полезно для server-side logs).
    - `transport.retries=1` ретраит только connection-level ошибки (DNS,
      connection reset), не 5xx/4xx и не HTTP response — безопасно для POST
      (request не успел дойти до сервера при retry).
    - Timeout 30s на read+connect+pool. Tool-level таймауты (60s scrape,
      600s crawl) накладываются сверху через polling-loop.
    """
    return httpx.AsyncClient(
        base_url=settings.base_url,
        timeout=httpx.Timeout(settings.request_timeout_s),
        headers={
            "Authorization": f"Bearer {settings.api_key}",
            "User-Agent": f"scraping-mcp/{__version__}",
            "Accept": "application/json",
        },
        transport=httpx.AsyncHTTPTransport(retries=1),
    )
