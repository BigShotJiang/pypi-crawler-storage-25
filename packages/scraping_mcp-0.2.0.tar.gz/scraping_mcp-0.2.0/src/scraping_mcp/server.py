"""MCP server bootstrap — регистрирует все 5 tools через FastMCP.

Точка сборки: создаёт FastMCP-инстанс, строит HTTP-клиент из Settings,
передаёт оба объекта в каждый tool-модуль через его функцию register().
"""
from mcp.server.fastmcp import FastMCP

from scraping_mcp.config import Settings
from scraping_mcp.http_client import build_client
from scraping_mcp.tools import billing, crawl, map as map_tool, scrape


def create_server(settings: Settings) -> FastMCP:
    """Создаёт FastMCP server с 5 зарегистрированными tools.

    Caller не должен закрывать http-клиент вручную: FastMCP lifecycle
    управляет shutdown через lifespan; при вызове server.run() клиент
    живёт до конца процесса (приемлемо для stdio-transport).
    """
    server = FastMCP("scraping")
    http = build_client(settings)

    # Каждый модуль получает http + settings через closure
    billing.register(server, http, settings)
    scrape.register(server, http, settings)
    crawl.register(server, http, settings)
    map_tool.register(server, http, settings)

    return server
