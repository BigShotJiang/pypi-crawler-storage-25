"""Tools для MCP-сервера: scrape, crawl, billing."""
