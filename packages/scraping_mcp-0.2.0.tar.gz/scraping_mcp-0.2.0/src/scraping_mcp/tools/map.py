"""map tool — wrapper для POST /v1/map.

Возвращает {url, links, total, source, cached}. 1 credit per call (на REST-стороне).
"""
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

from scraping_mcp.errors import map_api_error


async def map_impl(
    http: httpx.AsyncClient,
    *,
    url: str,
    max_urls: int = 5000,
    include_subdomains: bool = False,
) -> dict[str, Any]:
    """POST /v1/map → returns {url, links, total, source}.

    max_urls маппится в MapRequest.limit на REST-стороне.
    """
    body: dict[str, Any] = {
        "url": url,
        "limit": max_urls,
        "include_subdomains": include_subdomains,
    }
    resp = await http.post("/v1/map", json=body)
    if resp.status_code >= 400:
        raise map_api_error(resp)
    return resp.json()


def register(server: FastMCP, http: httpx.AsyncClient, settings) -> None:
    """Регистрирует map-tool в FastMCP server'е."""

    @server.tool(
        name="map",
        description=(
            "Build a URL list of a site (sitemap.xml + robots.txt + recursive "
            "indices, with crawl-depth=1 fallback). Cheap (1 credit). "
            "Args: url (str), max_urls (int, default 5000), include_subdomains (bool)."
        ),
    )
    async def map_(
        url: str,
        max_urls: int = 5000,
        include_subdomains: bool = False,
    ) -> dict[str, Any]:
        return await map_impl(
            http, url=url, max_urls=max_urls,
            include_subdomains=include_subdomains,
        )
