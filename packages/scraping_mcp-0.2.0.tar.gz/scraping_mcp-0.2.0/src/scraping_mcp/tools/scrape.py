"""Scrape tools: scrape (wait-with-fallback) + get_scrape_status.

Task 8: добавлена scrape_impl с wait-with-fallback polling.
"""
import asyncio
import time
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

from scraping_mcp.errors import map_api_error


async def get_scrape_status_impl(
    http: httpx.AsyncClient,
    task_id: str,
) -> dict[str, Any]:
    """GET /v1/scrape/{task_id} → status/result/error."""
    resp = await http.get(f"/v1/scrape/{task_id}")
    if resp.status_code >= 400:
        raise map_api_error(resp)
    return resp.json()


async def scrape_impl(
    http: httpx.AsyncClient,
    settings,
    *,
    url: str,
    format: str = "markdown",
    cookies: list[dict] | None = None,
    timeout_s: int = 60,
) -> dict[str, Any]:
    """Submit POST /v1/scrape → poll GET /v1/scrape/{task_id} до finished
    или timeout_s. Wait-with-fallback: если timeout истёк — вернуть
    {status: pending, task_id, elapsed_s}. Ошибки REST → raise McpToolError.
    """
    body: dict[str, Any] = {"url": url, "format": format}
    if cookies:
        body["cookies"] = cookies

    # Отправляем задачу на скрапинг
    resp = await http.post("/v1/scrape", json=body)
    if resp.status_code >= 400:
        raise map_api_error(resp)

    submit = resp.json()
    task_id = submit["task_id"]

    started = time.monotonic()
    poll_interval = settings.poll_interval_scrape_s

    # Polling loop: проверяем статус каждые poll_interval секунд
    while True:
        # Ждём перед polling-запросом: даём worker'у стартовать
        await asyncio.sleep(poll_interval)

        resp = await http.get(f"/v1/scrape/{task_id}")
        if resp.status_code >= 400:
            raise map_api_error(resp)
        state = resp.json()
        status = state.get("status")

        # Terminal статусы — возвращаем результат немедленно
        if status in ("finished", "failed"):
            return state

        elapsed = time.monotonic() - started
        if elapsed >= timeout_s:
            # Fallback: timeout истёк — агент может позже опросить get_scrape_status
            return {
                "status": "pending",
                "task_id": task_id,
                "elapsed_s": round(elapsed, 1),
            }


def register(server: FastMCP, http: httpx.AsyncClient, settings) -> None:
    """Регистрирует scrape-related tools (scrape + get_scrape_status).

    Заменяет версию из Task 6 — добавляет tool scrape с wait-with-fallback.
    """

    @server.tool(
        name="get_scrape_status",
        description=(
            "Check the status of a scrape task (previously returned by the "
            "`scrape` tool when it timed out). "
            "Returns {status, result?, error?}."
        ),
    )
    async def get_scrape_status(task_id: str) -> dict[str, Any]:
        return await get_scrape_status_impl(http, task_id)

    @server.tool(
        name="scrape",
        description=(
            "Scrape a single URL. Polls until finished or timeout_s. "
            "If timeout exceeded, returns {status: 'pending', task_id} — "
            "agent can retrieve result later via get_scrape_status. "
            "Args: url (str), format ('markdown'), cookies (optional list), "
            "timeout_s (default 60)."
        ),
    )
    async def scrape(
        url: str,
        format: str = "markdown",
        cookies: list[dict] | None = None,
        timeout_s: int = 60,
    ) -> dict[str, Any]:
        return await scrape_impl(
            http, settings,
            url=url, format=format, cookies=cookies, timeout_s=timeout_s,
        )
