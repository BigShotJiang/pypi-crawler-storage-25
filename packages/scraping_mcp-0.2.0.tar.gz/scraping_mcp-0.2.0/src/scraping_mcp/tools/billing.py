"""get_balance tool — wrapper для GET /v1/billing/balance."""
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

from scraping_mcp.errors import map_api_error


async def get_balance_impl(http: httpx.AsyncClient) -> dict[str, Any]:
    """Вызов REST /v1/billing/balance. Raises McpToolError на 4xx/5xx."""
    resp = await http.get("/v1/billing/balance")
    if resp.status_code >= 400:
        raise map_api_error(resp)
    return resp.json()


def register(server: FastMCP, http: httpx.AsyncClient, settings) -> None:
    """Регистрирует get_balance tool в server'е."""

    @server.tool(
        name="get_balance",
        description="Current user credit balance. Returns {balance: int}.",
    )
    async def get_balance() -> dict[str, Any]:
        return await get_balance_impl(http)
