"""Crawl tools: crawl (wait-with-fallback) + get_crawl_status.

В Task 7 — только get_crawl_status_impl + items fan-out для total > 50.
В Task 9 — добавлена crawl_impl с wait-with-fallback polling.
"""
import asyncio
import time
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

from scraping_mcp.errors import map_api_error, McpToolError


ITEMS_PAGE_LIMIT = 200   # max per-page лимит REST (см. phase-3.1 spec)
INLINE_ITEMS_THRESHOLD = 50
# максимум страниц items fan-out; 100 * 200 = 20 000 элементов —
# защита от зависания при некорректном cursor
MAX_ITEMS_PAGES = 100


async def _fetch_all_items(
    http: httpx.AsyncClient,
    crawl_id: str,
) -> list[dict[str, Any]]:
    """Курсорная пагинация /items до полного списка."""
    items: list[dict[str, Any]] = []
    cursor: int | None = None
    for _ in range(MAX_ITEMS_PAGES):
        params: dict[str, Any] = {"limit": ITEMS_PAGE_LIMIT}
        if cursor is not None:
            params["cursor"] = cursor
        resp = await http.get(f"/v1/crawl/{crawl_id}/items", params=params)
        if resp.status_code >= 400:
            raise map_api_error(resp)
        page = resp.json()
        items.extend(page.get("items", []))
        cursor = page.get("next_cursor")
        if cursor is None:
            break
    else:
        raise McpToolError(
            code="upstream_error",
            message="items pagination exceeded MAX_ITEMS_PAGES cap",
            data={"crawl_id": crawl_id, "max_pages": MAX_ITEMS_PAGES},
        )
    return items


async def get_crawl_status_impl(
    http: httpx.AsyncClient,
    crawl_id: str,
    include_items: bool = True,
) -> dict[str, Any]:
    """GET /v1/crawl/{id}. Если include_items=True и total > 50, дополнительно
    fan-out'им /items endpoint до полного списка."""
    resp = await http.get(
        f"/v1/crawl/{crawl_id}",
        params={"include_items": "true" if include_items else "false"},
    )
    if resp.status_code >= 400:
        raise map_api_error(resp)
    body = resp.json()

    if include_items and body.get("total", 0) > INLINE_ITEMS_THRESHOLD:
        # items явно не пришли inline (phase-3.1: сервер не включает их при total > 50).
        # Делаем fan-out сами.
        body["items"] = await _fetch_all_items(http, crawl_id)

    return body


TERMINAL_STATUSES = {"finished", "partial_failed", "failed", "cancelled"}


async def cancel_crawl_impl(
    http: httpx.AsyncClient,
    crawl_id: str,
) -> dict[str, Any]:
    """DELETE /v1/crawl/{id} → {status, cancelled_urls, inflight_urls, refunded_credits}."""
    resp = await http.delete(f"/v1/crawl/{crawl_id}")
    if resp.status_code >= 400:
        raise map_api_error(resp)
    return resp.json()


async def crawl_impl(
    http: httpx.AsyncClient,
    settings,
    *,
    urls: list[str],
    cookies: list[dict] | None = None,
    timeout_s: int = 600,
) -> dict[str, Any]:
    """Submit POST /v1/crawl → poll GET /v1/crawl/{id}?include_items=true до
    terminal или timeout_s. Wait-with-fallback: при timeout возвращает
    {status: 'pending', crawl_id, counters, elapsed_s} без исключения."""
    body: dict[str, Any] = {"urls": urls}
    if cookies:
        body["cookies"] = cookies

    resp = await http.post("/v1/crawl", json=body)
    if resp.status_code >= 400:
        raise map_api_error(resp)
    submit = resp.json()
    crawl_id = submit["crawl_id"]

    started = time.monotonic()
    poll_interval = settings.poll_interval_crawl_s

    while True:
        await asyncio.sleep(poll_interval)

        state = await get_crawl_status_impl(http, crawl_id, include_items=True)
        status = state.get("status")

        if status in TERMINAL_STATUSES:
            return state

        elapsed = time.monotonic() - started
        if elapsed >= timeout_s:
            return {
                "status": "pending",
                "crawl_id": crawl_id,
                "total": state.get("total", len(urls)),
                "succeeded": state.get("succeeded", 0),
                "failed": state.get("failed", 0),
                "elapsed_s": round(elapsed, 1),
            }


def register(server: FastMCP, http: httpx.AsyncClient, settings) -> None:
    """Регистрирует crawl tools (crawl + get_crawl_status).

    Заменяет Task 7 версию — добавляет crawl tool.
    """

    @server.tool(
        name="get_crawl_status",
        description=(
            "Check the status of a crawl batch (previously returned by the "
            "`crawl` tool). Optionally include items (full per-URL results). "
            "Returns {status, total, succeeded, failed, items?}."
        ),
    )
    async def get_crawl_status(
        crawl_id: str,
        include_items: bool = True,
    ) -> dict[str, Any]:
        return await get_crawl_status_impl(http, crawl_id, include_items)

    @server.tool(
        name="crawl",
        description=(
            "Batch-scrape a list of URLs (up to 500). Polls until finished or "
            "timeout_s. On timeout returns {status: 'pending', crawl_id, "
            "counters} — agent can retrieve results later via get_crawl_status. "
            "Args: urls (list[str]), cookies (optional list), "
            "timeout_s (default 600)."
        ),
    )
    async def crawl(
        urls: list[str],
        cookies: list[dict] | None = None,
        timeout_s: int = 600,
    ) -> dict[str, Any]:
        return await crawl_impl(
            http, settings,
            urls=urls, cookies=cookies, timeout_s=timeout_s,
        )

    @server.tool(
        name="cancel_crawl",
        description=(
            "Cancel a running crawl batch. All pending URLs are cancelled and "
            "credits refunded. Running URLs complete naturally. Returns "
            "{status, cancelled_urls, inflight_urls, refunded_credits}."
        ),
    )
    async def cancel_crawl(crawl_id: str) -> dict[str, Any]:
        return await cancel_crawl_impl(http, crawl_id)
