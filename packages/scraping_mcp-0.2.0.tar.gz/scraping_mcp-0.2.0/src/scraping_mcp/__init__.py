"""scraping-mcp — MCP server for Scraping (REST API wrapper for LLM agents)."""
__version__ = "0.2.0"
