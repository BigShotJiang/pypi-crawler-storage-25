"""Env-var конфигурация scraping-mcp сервера.

Fail-fast: отсутствие SCRAPING_API_KEY поднимает ValidationError на startup.
Все таймауты переопределяются через env для explicit tuning (например,
пользователь с быстрой сетью может снизить request_timeout_s).
"""
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=None,           # не читаем .env — только process env
        case_sensitive=False,
    )

    api_key: str = Field(..., alias="SCRAPING_API_KEY")
    base_url: str = Field(
        default="http://localhost:8000",
        alias="SCRAPING_BASE_URL",
    )
    scrape_timeout_s: int = Field(default=60, alias="SCRAPING_SCRAPE_TIMEOUT_S")
    crawl_timeout_s: int = Field(default=600, alias="SCRAPING_CRAWL_TIMEOUT_S")
    request_timeout_s: int = Field(default=30, alias="SCRAPING_REQUEST_TIMEOUT_S")
    poll_interval_scrape_s: float = 1.5
    poll_interval_crawl_s: float = 2.5
