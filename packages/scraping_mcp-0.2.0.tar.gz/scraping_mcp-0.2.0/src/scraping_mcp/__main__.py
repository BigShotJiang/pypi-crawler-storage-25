"""Entry point для `python -m scraping_mcp` / `scraping-mcp` CLI.

Валидирует конфиг fail-fast; всё логирование идёт в stderr
(stdout зарезервирован для stdio-JSON-RPC транспорта MCP).
"""
import logging
import sys

from pydantic import ValidationError

from scraping_mcp import __version__
from scraping_mcp.config import Settings
from scraping_mcp.server import create_server


def main() -> None:
    # Logging → stderr (stdout занят stdio-transport'ом MCP-JSON-RPC)
    logging.basicConfig(
        stream=sys.stderr,
        level=logging.INFO,
        format="[scraping-mcp] %(levelname)s %(message)s",
    )
    log = logging.getLogger(__name__)

    try:
        settings = Settings()
    except ValidationError as e:
        print(
            f"[scraping-mcp] configuration error:\n{e}\n\n"
            "Set SCRAPING_API_KEY env var in your MCP client config.",
            file=sys.stderr,
        )
        sys.exit(1)

    log.info("starting scraping-mcp/%s", __version__)
    log.info("base_url=%s", settings.base_url)

    server = create_server(settings)
    server.run()  # stdio transport (default FastMCP)


if __name__ == "__main__":
    main()
