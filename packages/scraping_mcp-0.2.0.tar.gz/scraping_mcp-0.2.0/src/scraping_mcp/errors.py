"""Mapping REST API-ошибок в MCP-tool errors.

Каждый 4xx/5xx REST response транслируется в explicit MCP error с
machine-readable code + human-readable message + optional data (для
программной обработки агентом — например insufficient_balance с полями
required/available).
"""
from dataclasses import dataclass
from typing import Any

import httpx


@dataclass
class McpToolError(Exception):
    """MCP-совместимая ошибка из tool-handler'а.

    Raised в tool'ах; FastMCP framework оборачивает в JSON-RPC error response
    с is_error=true. Агент получает code+message+data и может обработать.
    """

    code: str
    message: str
    data: dict[str, Any] | None = None

    def __str__(self) -> str:
        return f"{self.code}: {self.message}"


_HTTP_TO_MCP: dict[int, tuple[str, str | None]] = {
    401: (
        "invalid_api_key",
        "API key invalid or missing. Set SCRAPING_API_KEY env var. "
        "Create a key at https://api.scraping.io/dashboard/keys.",
    ),
    402: ("insufficient_balance", None),  # message вычисляется из body
    403: (
        "forbidden",
        "API key revoked or lacks permission for this operation.",
    ),
    404: (
        "not_found",
        "Task or crawl not found, or belongs to another user.",
    ),
    409: ("already_terminal", None),
    422: ("invalid_input", None),
    400: ("invalid_input", None),
}


def map_api_error(resp: httpx.Response) -> McpToolError:
    """Convert REST error response into MCP ToolError."""
    try:
        body = resp.json() if resp.content else {}
    except ValueError:
        body = {}

    error_detail = body.get("error") or body.get("detail") or {}

    generic = _HTTP_TO_MCP.get(resp.status_code)
    if generic:
        code, default_msg = generic
        if default_msg:
            message = default_msg
        elif isinstance(error_detail, str):
            message = error_detail
        elif isinstance(error_detail, dict):
            message = error_detail.get("message") or str(error_detail) or resp.reason_phrase
        else:
            message = resp.reason_phrase
        return McpToolError(
            code=code,
            message=message,
            data=error_detail if isinstance(error_detail, dict) else None,
        )

    # Fallback: 5xx или неожиданный код
    return McpToolError(
        code="server_error",
        message=f"Scraping API returned {resp.status_code}: {resp.reason_phrase}",
        data=error_detail if isinstance(error_detail, dict) else None,
    )
