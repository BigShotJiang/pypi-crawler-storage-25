// Unit tests for MCAConfig
import { MCAConfig } from '../../src/config/settings';
import { ConfigurationError } from '../../src/utils/exceptions';

describe('MCAConfig', () => {
  beforeEach(() => {
    delete process.env.MCA_SERVICE_NAME;
    delete process.env.MCA_MODEL_ID;
    delete process.env.MCA_MODEL_VERSION;
    delete process.env.MCA_TEAM_NAME;
    delete process.env.MCA_MODEL_TYPE;
    delete process.env.MCA_OTEL_ENDPOINT;
    delete process.env.MCA_STRICT_VALIDATION;
    delete process.env.MCA_REGISTRY_URL;
    delete process.env.MCA_REGISTRY_TOKEN;
    delete process.env.MCA_REGISTRY_REFRESH_INTERVAL;
  });

  describe('initialization', () => {
    it('should initialize with minimal config', () => {
      const config = MCAConfig.create({ serviceName: 'test-service', strictValidation: false });
      expect(config.serviceName).toBe('test-service');
      expect(config.collectorEndpoint).toBe('http://localhost:4318');
      expect(config.modelType).toBe('internal');
    });

    it('should initialize with full config', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        modelId: 'mdl-001',
        modelVersion: '1.0',
        teamName: 'clinical-ai',
        modelType: 'internal',
        collectorEndpoint: 'http://localhost:4318',
        strictValidation: true,
      });

      expect(config.serviceName).toBe('test-service');
      expect(config.modelId).toBe('mdl-001');
      expect(config.modelVersion).toBe('1.0');
      expect(config.teamName).toBe('clinical-ai');
      expect(config.modelType).toBe('internal');
    });

    it('should load from environment variables', () => {
      process.env.MCA_SERVICE_NAME = 'env-service';
      process.env.MCA_MODEL_ID = 'mdl-env';
      process.env.MCA_MODEL_VERSION = '2.0';
      process.env.MCA_TEAM_NAME = 'env-team';

      const config = MCAConfig.create({});
      expect(config.serviceName).toBe('env-service');
      expect(config.modelId).toBe('mdl-env');
      expect(config.modelVersion).toBe('2.0');
      expect(config.teamName).toBe('env-team');
    });

    it('should prioritize kwargs over environment variables', () => {
      process.env.MCA_SERVICE_NAME = 'env-service';

      const config = MCAConfig.create({ serviceName: 'kwargs-service', strictValidation: false });
      expect(config.serviceName).toBe('kwargs-service');
    });
  });

  describe('validation', () => {
    it('should throw error if serviceName is missing', () => {
      expect(() => MCAConfig.create({})).toThrow(ConfigurationError);
      expect(() => MCAConfig.create({})).toThrow(/serviceName is required/);
    });

    it('should throw error if internal model missing required attributes in strict mode', () => {
      expect(() => MCAConfig.create({ serviceName: 'test', strictValidation: true })).toThrow(
        ConfigurationError
      );
      expect(() => MCAConfig.create({ serviceName: 'test', strictValidation: true })).toThrow(
        /modelId is required/
      );
    });

    it('should not throw error if strict validation is disabled', () => {
      expect(() => MCAConfig.create({ serviceName: 'test', strictValidation: false })).not.toThrow();
    });

    it('should enforce HTTPS for registry URL', () => {
      expect(() =>
        MCAConfig.create({
          serviceName: 'test',
          strictValidation: false,
          registryUrl: 'http://example.com',
        })
      ).toThrow(ConfigurationError);
      expect(() =>
        MCAConfig.create({
          serviceName: 'test',
          strictValidation: false,
          registryUrl: 'http://example.com',
        })
      ).toThrow(/must use HTTPS/);
    });

    it('should allow HTTP for localhost registry URL', () => {
      expect(() =>
        MCAConfig.create({
          serviceName: 'test',
          strictValidation: false,
          registryUrl: 'http://localhost:8080',
        })
      ).not.toThrow();

      expect(() =>
        MCAConfig.create({
          serviceName: 'test',
          strictValidation: false,
          registryUrl: 'http://127.0.0.1:8080',
        })
      ).not.toThrow();
    });
  });

  describe('toResourceAttributes', () => {
    it('should convert config to resource attributes', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        modelId: 'mdl-001',
        modelVersion: '1.0',
        teamName: 'clinical-ai',
        modelType: 'internal',
      });

      const attrs = config.toResourceAttributes();
      expect(attrs['service.name']).toBe('test-service');
      expect(attrs['model.id']).toBe('mdl-001');
      expect(attrs['model.version']).toBe('1.0');
      expect(attrs['team.name']).toBe('clinical-ai');
      expect(attrs['model.type']).toBe('internal');
    });

    it('should include only provided attributes', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const attrs = config.toResourceAttributes();
      expect(attrs['service.name']).toBe('test-service');
      expect(attrs['model.type']).toBe('internal');
      expect(attrs['model.id']).toBeUndefined();
      expect(attrs['model.version']).toBeUndefined();
      expect(attrs['team.name']).toBeUndefined();
    });
  });
});
