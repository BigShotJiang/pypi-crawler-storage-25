// Unit tests for MCAClient
import { MCAClient } from '../../src/core/client';
import { ConfigurationError } from '../../src/utils/exceptions';

const mockSpan = {
  setAttribute: jest.fn(),
  setStatus: jest.fn(),
  end: jest.fn(),
  recordException: jest.fn(),
  addEvent: jest.fn(),
};

const mockCounter = { add: jest.fn() };
const mockHistogram = { record: jest.fn() };
const mockGauge = { record: jest.fn() };

jest.mock('../../src/core/providers', () => ({
  setupMeterProvider: jest.fn(() => ({
    getMeter: jest.fn(() => ({
      createCounter: jest.fn(() => mockCounter),
      createHistogram: jest.fn(() => mockHistogram),
      createGauge: jest.fn(() => mockGauge),
    })),
    forceFlush: jest.fn(() => Promise.resolve()),
    shutdown: jest.fn(() => Promise.resolve()),
  })),
  setupTracerProvider: jest.fn(() => ({
    getTracer: jest.fn(() => ({
      startSpan: jest.fn(() => mockSpan),
    })),
    forceFlush: jest.fn(() => Promise.resolve()),
    shutdown: jest.fn(() => Promise.resolve()),
  })),
  setupLoggerProvider: jest.fn(() => ({
    getLogger: jest.fn(() => ({})),
    forceFlush: jest.fn(() => Promise.resolve()),
    shutdown: jest.fn(() => Promise.resolve()),
  })),
  shutdownProviders: jest.fn(() => Promise.resolve(true)),
}));

jest.mock('@opentelemetry/api', () => ({
  ...jest.requireActual('@opentelemetry/api'),
  trace: {
    getActiveSpan: jest.fn(() => mockSpan),
    setSpan: jest.fn((_ctx: any, _span: any) => _ctx),
  },
  context: {
    active: jest.fn(() => ({})),
    with: jest.fn((_ctx: any, fn: any) => fn()),
  },
  SpanStatusCode: {
    OK: 1,
    ERROR: 2,
  },
}));

describe('MCAClient', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('initialization', () => {
    it('should initialize with minimal config', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(client).toBeInstanceOf(MCAClient);
      expect(client.meter).toBeDefined();
      expect(client.tracer).toBeDefined();
      expect(client.logger).toBeDefined();
    });

    it('should initialize with full config', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        modelId: 'mdl-001',
        modelVersion: '1.0',
        teamName: 'clinical-ai',
        modelType: 'internal',
        collectorEndpoint: 'http://localhost:4318',
      });

      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should throw error if serviceName is missing', async () => {
      await expect(MCAClient.create({} as any)).rejects.toThrow(ConfigurationError);
    });
  });

  describe('recordPrediction', () => {
    it('should record prediction with latency', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.recordPrediction({ latency: 0.15 });

      // If no error thrown, test passes
      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should record prediction with custom attributes', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.recordPrediction({
        latency: 0.15,
        customAttr: 'value',
      });

      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should record prediction without latency', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.recordPrediction();

      expect(client).toBeInstanceOf(MCAClient);
    });
  });

  describe('recordMetric', () => {
    it('should record custom metric', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.recordMetric('custom.metric', 42);

      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should record metric with attributes', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.recordMetric('custom.metric', 42, { label: 'test' });

      expect(client).toBeInstanceOf(MCAClient);
    });
  });

  describe('shutdown', () => {
    it('should shutdown gracefully', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const result = await client.shutdown();

      expect(result).toBe(true);
    });

    it('should respect timeout parameter', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const result = await client.shutdown(5000);

      expect(result).toBe(true);
    });
  });

  describe('accessors', () => {
    it('should provide access to meter', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(client.meter).toBeDefined();
    });

    it('should provide access to tracer', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(client.tracer).toBeDefined();
    });

    it('should provide access to logger', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(client.logger).toBeDefined();
    });

    it('should provide access to thresholds', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(client.thresholdsConfig).toBeDefined();
      expect(typeof client.thresholdsConfig).toBe('object');
    });
  });

  describe('flush', () => {
    it('should flush all providers successfully', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const result = await client.flush();
      expect(result).toBe(true);
    });

    it('should respect timeout parameter', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const result = await client.flush(5000);
      expect(result).toBe(true);
    });

    it('should return false if already shut down', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.shutdown();
      const result = await client.flush();
      expect(result).toBe(false);
    });
  });

  describe('Agentic AI tracking', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    describe('recordGoalStarted', () => {
      it('should create goal and return goal ID', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const goalId = client.recordGoalStarted('Research diabetes treatments', 'research');

        expect(goalId).toBeTruthy();
        expect(typeof goalId).toBe('string');
        expect(mockCounter.add).toHaveBeenCalledWith(1, { goal_type: 'research' });
      });

      it('should sanitize long descriptions', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const longDesc = 'A'.repeat(300);
        const goalId = client.recordGoalStarted(longDesc);

        expect(goalId).toBeTruthy();
      });

      it('should use default type if not provided', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const goalId = client.recordGoalStarted('Some goal');

        expect(goalId).toBeTruthy();
        expect(mockCounter.add).toHaveBeenCalledWith(1, { goal_type: 'general' });
      });
    });

    describe('recordGoalCompleted', () => {
      it('should complete goal with success status', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const goalId = client.recordGoalStarted('Test goal');
        client.recordGoalCompleted(goalId, 'success');

        expect(mockSpan.setStatus).toHaveBeenCalledWith({ code: 1 }); // OK
        expect(mockSpan.end).toHaveBeenCalled();
        expect(mockCounter.add).toHaveBeenCalledWith(1, { goal_status: 'success' });
      });

      it('should complete goal with failure status', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const goalId = client.recordGoalStarted('Test goal');
        client.recordGoalCompleted(goalId, 'failure');

        expect(mockSpan.setStatus).toHaveBeenCalledWith(
          expect.objectContaining({ code: 2 }) // ERROR
        );
        expect(mockCounter.add).toHaveBeenCalledWith(1, { goal_status: 'failure' });
      });

      it('should throw error for invalid goal ID', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        expect(() => client.recordGoalCompleted('invalid-id')).toThrow();
      });

      it('should throw error for invalid status', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const goalId = client.recordGoalStarted('Test goal');

        expect(() => client.recordGoalCompleted(goalId, 'invalid' as any)).toThrow();
      });
    });

    describe('trackTool', () => {
      it('should track successful tool execution', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const result = await client.trackTool(
          'search_db',
          async () => 'result',
          undefined,
          { query: 'test' }
        );

        expect(result).toBe('result');
        expect(mockSpan.setAttribute).toHaveBeenCalledWith('genai.agent.tool.success', true);
        expect(mockCounter.add).toHaveBeenCalledWith(
          1,
          expect.objectContaining({ status: 'success' })
        );
      });

      it('should track failed tool execution', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const error = new Error('Tool failed');

        await expect(
          client.trackTool('search_db', async () => {
            throw error;
          })
        ).rejects.toThrow('Tool failed');

        expect(mockSpan.setAttribute).toHaveBeenCalledWith('genai.agent.tool.success', false);
        expect(mockSpan.recordException).toHaveBeenCalledWith(error);
        expect(mockCounter.add).toHaveBeenCalledWith(
          1,
          expect.objectContaining({ status: 'error' })
        );
      });

      it('should sanitize long tool names', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const longName = 'A'.repeat(200);
        await client.trackTool(longName, async () => 'result');

        expect(mockSpan.setAttribute).toHaveBeenCalled();
      });
    });

    describe('recordHumanIntervention', () => {
      it('should record human intervention', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordHumanIntervention('Need clarification', 45.2, 'clarification');

        expect(mockCounter.add).toHaveBeenCalledWith(
          1,
          expect.objectContaining({ intervention_type: 'clarification' })
        );
        expect(mockSpan.addEvent).toHaveBeenCalledWith(
          'human_intervention',
          expect.objectContaining({ wait_time_seconds: 45.2 })
        );
      });

      it('should use default type if not provided', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordHumanIntervention('Need help', 10);

        expect(mockCounter.add).toHaveBeenCalledWith(
          1,
          expect.objectContaining({ intervention_type: 'input' })
        );
      });
    });

    describe('recordPolicyViolation', () => {
      it('should record policy violation', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordPolicyViolation('data_access_unauthorized');

        expect(mockCounter.add).toHaveBeenCalledWith(
          1,
          { policy_type: 'data_access_unauthorized' }
        );
        expect(mockSpan.addEvent).toHaveBeenCalledWith(
          'policy_violation',
          expect.objectContaining({ severity: 'high' })
        );
      });
    });
  });

  describe('Advanced tracking methods', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    describe('recordError', () => {
      it('should record error with span', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const error = new Error('Test error');
        const message = client.recordError(error, 0.5, 'pred-123');

        expect(message).toBeTruthy();
        expect(mockSpan.recordException).toHaveBeenCalledWith(error);
        expect(mockSpan.setStatus).toHaveBeenCalledWith(
          expect.objectContaining({ code: 2 }) // ERROR
        );
        expect(mockCounter.add).toHaveBeenCalledTimes(2); // predictions + errors counter
      });

      it('should generate prediction ID if not provided', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const error = new Error('Test error');
        const message = client.recordError(error);

        expect(message).toBeTruthy();
      });

      it('should sanitize error message', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const error = new Error('Error with api_key=secret123');
        const message = client.recordError(error);

        expect(message).toContain('api_key=***');
        expect(message).not.toContain('secret123');
      });

      it('should handle string throws safely', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const message = client.recordError('Something went wrong');

        expect(message).toBe('Something went wrong');
        expect(mockSpan.recordException).toHaveBeenCalled();
      });

      it('should handle null/undefined throws safely', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const message = client.recordError(null);

        expect(message).toBe('Unknown error');
        expect(mockSpan.recordException).toHaveBeenCalled();
      });

      it('should handle primitive throws safely', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const message = client.recordError(404);

        expect(message).toBe('404');
        expect(mockSpan.recordException).toHaveBeenCalled();
      });
    });

    describe('recordEvaluation', () => {
      it('should record MAE', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordEvaluation({ mae: 0.15 });

        expect(mockHistogram.record).toHaveBeenCalledWith(
          0.15,
          expect.objectContaining({ dataset: 'validation' })
        );
      });

      it('should record RMSE', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordEvaluation({ rmse: 0.23 });

        expect(mockHistogram.record).toHaveBeenCalledWith(
          0.23,
          expect.objectContaining({ dataset: 'validation' })
        );
      });

      it('should use custom dataset', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordEvaluation({ mae: 0.15, dataset: 'test' });

        expect(mockHistogram.record).toHaveBeenCalledWith(
          0.15,
          expect.objectContaining({ dataset: 'test' })
        );
      });
    });

    describe('recordCounter', () => {
      it('should record custom counter', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordCounter('custom.cache_hits', 5, { cache: 'redis' });

        expect(mockCounter.add).toHaveBeenCalledWith(5, { cache: 'redis' });
      });

      it('should use default value of 1', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordCounter('custom.events');

        expect(mockCounter.add).toHaveBeenCalledWith(1, undefined);
      });
    });

    describe('recordGauge', () => {
      it('should record gauge value with .record() method', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordGauge('custom.queue_size', 42, { queue: 'processing' });

        expect(mockGauge.record).toHaveBeenCalledWith(42, { queue: 'processing' });
      });
    });
  });

  describe('Configuration', () => {
    it('should support filterSystemMetrics config', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        filterSystemMetrics: false,
        strictValidation: false,
      });

      expect(client).toBeInstanceOf(MCAClient);
    });
  });
});
