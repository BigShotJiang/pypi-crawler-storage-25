# Changelog

All notable changes to the MCA SDK Node.js implementation will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.1] - 2026-03-24

### Fixed - Critical Stability & Memory Leaks

**Phase 1: Critical Stability Fixes**
- **Event Loop Hang in flush():** Fixed dangling timeout preventing Node.js graceful exit. Now captures timer reference and clears it in finally block.
- **Catastrophic Crash on Non-Error Throws:** Added `normalizeError()` helper to safely handle string, primitive, and null throws. Prevents hard crashes when non-Error values are thrown.
- **Concurrent Map Mutation in shutdown():** Fixed traversal skip bug by snapshotting goal IDs before iteration. Prevents orphaned goals during shutdown.

**Phase 2: Memory Leak Prevention**
- **Unbounded Memory Leak in Dynamic Metric Caches:** Added `MAX_DYNAMIC_METRICS` limit (1000) to prevent OOM from dynamic metric names. Drops new metrics with warning when limit reached.
- **Memory Leak for Phantom Goals:** Fixed tool state tracking to validate goal existence before caching. Prevents indefinite memory leak from nonexistent goals.
- **Leaked Spans on Telemetry Exceptions:** Moved `span.end()` to finally block in `trackTool()`. Guarantees span closure even if telemetry instructions throw.

**Phase 3: Telemetry Correctness & Type Safety**
- **Corrupted Metric Semantics for recordGauge:** Fixed to use proper `createGauge()` with `.record()` method instead of Counter. Prevents nonsensical cumulative values for absolute gauge readings.
- **Type Safety with Attributes:** Enforced strict `Attributes` type from `@opentelemetry/api` instead of `Record<string, any>`. Prevents nested object serialization errors.
- **Unsafe String Operations in Error Sanitization:** Updated `sanitizeErrorMessage()` to handle undefined/null gracefully. Returns "Unknown error" instead of throwing TypeError.

### Changed
- `recordError()` signature now accepts `unknown` instead of `Error` to safely handle any thrown value
- `recordGauge()` now uses OpenTelemetry Gauge for proper absolute value semantics
- All type interfaces now use strict `Attributes` type for better compile-time safety
- Dynamic metric cache helpers now return `undefined` when limit reached instead of creating unbounded maps

### Added
- `normalizeError()` private helper for robust error handling
- `getOrCreateCounter()` and `getOrCreateGauge()` helpers with memory bounds checking
- Additional test cases for string, null, and primitive error throws (3 new tests)

## [0.2.0] - 2026-03-24

### Added

**Agentic AI Tracking (Parity with Python SDK v0.8.0+):**
- `recordGoalStarted(description, type, attributes)` - Start tracking an agent goal with unique ID
- `recordGoalCompleted(goalId, status, attributes)` - Complete goal tracking with success/failure/partial status
- `trackTool<T>(toolName, fn, goalId, attributes)` - Track tool execution with automatic span creation and error handling
- `recordHumanIntervention(reason, waitTime, type, timestamp, attributes)` - Track human intervention events
- `recordPolicyViolation(policyType)` - Track policy violation events
- Background cleanup thread for stale goals (1-hour timeout with automatic completion)
- Metric instruments: `agentic.goals_started_total`, `agentic.goals_completed_total`, `agentic.goals_failed_total`, `agentic.goal_duration_seconds`, `agentic.tool_calls_total`, `agentic.tool_latency_seconds`, `agentic.human_interventions_total`, `agentic.policy_violations_total`

**Advanced Tracking Methods:**
- `flush(timeoutMs)` - Force flush all telemetry providers mid-lifecycle (useful for batch processing)
- `recordError(error, latency, predictionId, attributes)` - Record errors with full span and OTel semantic conventions
- `recordEvaluation({ mae, rmse, dataset, attributes })` - Record model evaluation metrics
- `recordCounter(name, value, attributes)` - Record custom counter metrics with instrument caching
- `recordGauge(name, value, attributes)` - Record gauge-like metrics (using Counter for synchronous behavior)
- Metric instruments: `model.errors_total`, `model.mae`, `model.rmse`

**Metric Filtering (Parity with Python SDK v0.8.4):**
- `filterSystemMetrics` configuration option (default: true) to drop expensive system metrics
- Drops `process.*`, `nodejs.*`, `system.*`, `http.client.*`, `rpc.*`, `test.*`, `asyncio.*`, `otel.sdk.*` metrics
- Implemented using OpenTelemetry Views with `Aggregation.Drop()`

### Changed
- Constructor now creates all metric instruments at initialization (cached for performance)
- `shutdown()` now closes active goals with failure status and stops background cleanup thread
- Error messages are now sanitized to mask `api_key`, `token`, and `password` patterns
- Span hierarchy properly maintained using `context.with()` for async operations

### Fixed
- Proper TypeScript type safety with `Attributes` type from `@opentelemetry/api` instead of `Record<string, any>`
- Undefined/null attribute values are now filtered before setting on spans

### Security
- Error sanitization prevents credential leakage in error messages
- Background cleanup interval uses `.unref()` to prevent blocking Node.js exit

## [0.1.0] - 2024-XX-XX

### Added
- Initial Node.js SDK implementation with basic features:
  - OpenTelemetry-based metrics, logs, and traces
  - OTLP/HTTP export to collector (port 4318)
  - Registry client with caching and background refresh
  - TypeScript support with full type definitions
  - `recordPrediction()` method
  - `recordMetric()` method
  - Multi-source configuration (constructor > env > YAML)
  - HTTPS enforcement for production endpoints
  - `withMCAClient()` context manager
