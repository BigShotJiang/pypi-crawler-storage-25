# Testing Node.js MCA SDK in Google Workbench

## Prerequisites
- Google Workbench instance with Node.js 18+ installed
- Docker and Docker Compose available
- Repository cloned to Workbench

## Step 1: Start OTel Collector

```bash
cd /home/coder/emms/sdk/mca-prototype
docker-compose up -d otel-collector

# Verify collector is running
curl http://localhost:13133/
# Should return: Alive!

# Check collector logs
docker-compose logs otel-collector
```

## Step 2: Install Node.js SDK Dependencies

```bash
cd /home/coder/emms/sdk/mca-sdk-nodejs
npm install
npm run build
```

## Step 3: Run Unit Tests

```bash
# Run all unit tests
npm test

# Run with coverage
npm run test:coverage

# Expected output:
# Test Suites: 4 passed, 4 total
# Tests:       41 passed, 41 total
# Coverage:    ~74%
```

## Step 4: Create Integration Test Script

Create `test-integration.ts` in `mca-sdk-nodejs/`:

```typescript
import { withMCAClient } from './src';

async function testIntegration() {
  console.log('Starting Node.js MCA SDK Integration Test...\n');

  await withMCAClient(
    {
      serviceName: 'nodejs-test-model',
      modelId: 'mdl-nodejs-001',
      modelVersion: '1.0.0',
      teamName: 'test-team',
      modelType: 'internal',
      collectorEndpoint: 'http://localhost:4318',
      strictValidation: false,
    },
    async (client) => {
      console.log('✓ MCAClient initialized successfully');

      // Test 1: Record prediction with latency
      await client.recordPrediction({
        latency: 0.123,
        model_version: 'v1.0',
        prediction_id: 'pred-001',
      });
      console.log('✓ Recorded prediction with latency');

      // Test 2: Record prediction without latency
      await client.recordPrediction({
        prediction_id: 'pred-002',
        custom_attribute: 'test-value',
      });
      console.log('✓ Recorded prediction without latency');

      // Test 3: Record custom metric
      await client.recordMetric('custom.test_metric', 42, {
        test_label: 'integration',
      });
      console.log('✓ Recorded custom metric');

      // Test 4: Multiple rapid predictions
      for (let i = 0; i < 5; i++) {
        await client.recordPrediction({
          latency: Math.random() * 0.5,
          prediction_id: `pred-batch-${i}`,
        });
      }
      console.log('✓ Recorded 5 batch predictions');

      console.log('\n⏳ Waiting 10 seconds for metrics to export...');
      await new Promise(resolve => setTimeout(resolve, 10000));
    }
  );

  console.log('✓ Client shutdown successfully\n');
  console.log('Integration test completed!');
}

testIntegration().catch(console.error);
```

## Step 5: Run Integration Test

```bash
# Compile TypeScript
npm run build

# Run integration test
npx ts-node test-integration.ts

# Expected output:
# Starting Node.js MCA SDK Integration Test...
# ✓ MCAClient initialized successfully
# ✓ Recorded prediction with latency
# ✓ Recorded prediction without latency
# ✓ Recorded custom metric
# ✓ Recorded 5 batch predictions
# ⏳ Waiting 10 seconds for metrics to export...
# ✓ Client shutdown successfully
# Integration test completed!
```

## Step 6: Verify Telemetry Data

### Check OTel Collector Logs
```bash
docker-compose logs otel-collector | grep -i "nodejs-test-model"
docker-compose logs otel-collector | grep -i "model.predictions"

# Look for:
# - OTLP/HTTP requests received
# - Metrics exported
# - No errors
```

### Query Prometheus (if configured)
```bash
curl -s http://localhost:9090/api/v1/query?query=model_predictions_total | jq .

# Expected: Counter showing prediction count
```

### Check Debug Exporter Output
```bash
docker-compose logs otel-collector | grep "model.predictions_total"

# Should show:
# - Metric name: model.predictions_total
# - Value: incremented count
# - Attributes: service.name, model.id, etc.
```

## Step 7: API Parity Validation with Python SDK

Run both SDKs side-by-side to verify equivalent behavior:

### Python SDK Test
```bash
cd /home/coder/emms/sdk/mca-prototype
python3 << 'EOF'
from mca_sdk import MCAClient

client = MCAClient(
    service_name="python-test-model",
    model_id="mdl-python-001",
    model_version="1.0.0",
    team_name="test-team",
    model_type="internal",
    otel_endpoint="http://localhost:4318",
    strict_validation=False
)

client.record_prediction(latency=0.123, prediction_id="pred-py-001")
print("✓ Python SDK prediction recorded")

client.shutdown()
print("✓ Python SDK shutdown complete")
EOF
```

### Node.js SDK Test (already done in Step 5)

### Compare Outputs
```bash
# Check that both SDKs produce similar OTLP payloads
docker-compose logs otel-collector | grep "python-test-model" | tail -20
docker-compose logs otel-collector | grep "nodejs-test-model" | tail -20

# Verify:
# ✓ Same metric names (model.predictions_total, model.latency_seconds)
# ✓ Same resource attributes (service.name, model.id, model.version, team.name)
# ✓ Similar payload structure
```

## Step 8: Performance Validation

Create `test-performance.ts`:

```typescript
import { MCAClient } from './src';

async function testPerformance() {
  const client = await MCAClient.create({
    serviceName: 'perf-test',
    modelId: 'mdl-perf',
    modelVersion: '1.0',
    teamName: 'test',
    modelType: 'internal',
    collectorEndpoint: 'http://localhost:4318',
    strictValidation: false,
  });

  const iterations = 1000;
  const start = Date.now();

  for (let i = 0; i < iterations; i++) {
    await client.recordPrediction({ latency: Math.random() * 0.1 });
  }

  const duration = Date.now() - start;
  const avgLatency = duration / iterations;

  console.log(`\nPerformance Test Results:`);
  console.log(`- Total predictions: ${iterations}`);
  console.log(`- Total time: ${duration}ms`);
  console.log(`- Average latency: ${avgLatency.toFixed(2)}ms per prediction`);
  console.log(`- Throughput: ${(iterations / (duration / 1000)).toFixed(0)} predictions/sec`);

  // NFR1 requirement: SDK overhead <50ms (p95 <100ms)
  if (avgLatency < 50) {
    console.log(`✓ PASS: Average latency ${avgLatency.toFixed(2)}ms < 50ms target`);
  } else {
    console.log(`✗ FAIL: Average latency ${avgLatency.toFixed(2)}ms exceeds 50ms target`);
  }

  await client.shutdown();
}

testPerformance().catch(console.error);
```

```bash
npx ts-node test-performance.ts

# Expected output (should meet NFR1):
# Performance Test Results:
# - Total predictions: 1000
# - Total time: ~3000ms
# - Average latency: ~3ms per prediction
# - Throughput: ~333 predictions/sec
# ✓ PASS: Average latency 3ms < 50ms target
```

## Step 9: Context Manager Test

```typescript
import { withMCAClient } from './src';

async function testContextManager() {
  console.log('Testing context manager (withMCAClient)...');

  // Test automatic shutdown on success
  await withMCAClient(
    {
      serviceName: 'context-test',
      modelId: 'mdl-ctx',
      modelVersion: '1.0',
      teamName: 'test',
      collectorEndpoint: 'http://localhost:4318',
      strictValidation: false,
    },
    async (client) => {
      await client.recordPrediction({ latency: 0.1 });
      console.log('✓ Prediction recorded inside context');
    }
  );
  console.log('✓ Client automatically shut down');

  // Test automatic shutdown on error
  try {
    await withMCAClient(
      {
        serviceName: 'context-test-error',
        collectorEndpoint: 'http://localhost:4318',
        strictValidation: false,
      },
      async (client) => {
        await client.recordPrediction({ latency: 0.1 });
        throw new Error('Simulated error');
      }
    );
  } catch (error: any) {
    console.log(`✓ Error caught: ${error.message}`);
    console.log('✓ Client still shut down despite error');
  }

  console.log('\nContext manager test completed!');
}

testContextManager().catch(console.error);
```

## Step 10: Validate All Acceptance Criteria

### AC #1: Basic Prediction Recording
```typescript
const client = await MCAClient.create({
  serviceName: 'test',
  modelId: 'mdl-001',
  strictValidation: false,
  collectorEndpoint: 'http://localhost:4318',
});

await client.recordPrediction({ latency: 0.15 });
// ✓ Verify: model.predictions_total counter incremented
```

### AC #2: Custom Attributes
```typescript
await client.recordPrediction({
  latency: 0.15,
  customAttr: 'value',
  anotherAttr: 123,
});
// ✓ Verify: Attributes included in OTLP payload
```

### AC #3: Shutdown with Flush
```typescript
const result = await client.shutdown();
// ✓ Verify: Returns true, all telemetry flushed
```

### AC #4: Async/Await Patterns
```typescript
await Promise.all([
  client.recordPrediction({ latency: 0.1 }),
  client.recordPrediction({ latency: 0.2 }),
  client.recordPrediction({ latency: 0.3 }),
]);
// ✓ Verify: No event loop blocking, all predictions recorded
```

## Troubleshooting

### Issue: "Cannot connect to collector"
```bash
# Check collector is running
docker-compose ps otel-collector

# Check collector endpoint
curl http://localhost:4318/

# Restart collector
docker-compose restart otel-collector
```

### Issue: "No metrics appearing"
```bash
# Check export interval (5 seconds by default)
# Wait at least 10 seconds after recording metrics

# Check collector config
cat mca-prototype/config/otel-collector-config.yaml

# Verify OTLP receiver on port 4318
docker-compose logs otel-collector | grep "4318"
```

### Issue: "Tests timing out"
```bash
# Increase Jest timeout in jest.config.js
testTimeout: 30000  # 30 seconds

# Or in specific test:
test('name', async () => { ... }, 30000);
```

## Success Criteria Checklist

- [ ] All 41 unit tests passing
- [ ] Integration test connects to OTel Collector on port 4318
- [ ] Metrics visible in collector logs (model.predictions_total, model.latency_seconds)
- [ ] Custom attributes included in telemetry payloads
- [ ] Shutdown flushes all pending data
- [ ] No event loop blocking (async/await works correctly)
- [ ] Performance meets NFR1 (<50ms overhead per prediction)
- [ ] API parity with Python SDK (same metric names, attributes, behavior)
- [ ] Context manager (withMCAClient) automatically shuts down client
- [ ] Background registry refresh works (if registry URL provided)

## Next Steps

1. Run integration tests in Workbench
2. Validate telemetry data in collector logs
3. Compare with Python SDK output
4. Performance test to verify NFR1 compliance
5. Update story status to "review" in sprint-status.yaml
6. Create PR with changes
