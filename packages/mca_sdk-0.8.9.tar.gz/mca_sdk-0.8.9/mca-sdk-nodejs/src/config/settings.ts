// Multi-source configuration loading for MCA SDK
import * as fs from 'fs';
import * as yaml from 'js-yaml';
import { MCAClientConfig, ModelType } from '../types';
import { ConfigurationError } from '../utils/exceptions';

export class MCAConfig {
  serviceName: string;
  modelId?: string;
  modelVersion?: string;
  teamName?: string;
  modelType: ModelType;
  collectorEndpoint: string;
  strictValidation: boolean;
  registryUrl?: string;
  registryToken?: string;
  refreshIntervalSecs: number;
  filterSystemMetrics: boolean;

  private constructor(config: Partial<MCAClientConfig> = {}, yamlConfig: any = null) {
    const env = process.env;

    this.serviceName =
      config.serviceName ||
      env.MCA_SERVICE_NAME ||
      yamlConfig?.serviceName ||
      '';

    this.modelId =
      config.modelId || env.MCA_MODEL_ID || yamlConfig?.modelId;

    this.modelVersion =
      config.modelVersion || env.MCA_MODEL_VERSION || yamlConfig?.modelVersion;

    this.teamName =
      config.teamName || env.MCA_TEAM_NAME || yamlConfig?.teamName;

    this.modelType =
      (config.modelType || env.MCA_MODEL_TYPE || yamlConfig?.modelType || 'internal') as ModelType;

    this.collectorEndpoint =
      config.collectorEndpoint ||
      env.MCA_OTEL_ENDPOINT ||
      yamlConfig?.collectorEndpoint ||
      'http://localhost:4318';

    this.strictValidation =
      config.strictValidation !== undefined
        ? config.strictValidation
        : env.MCA_STRICT_VALIDATION === 'true'
        ? true
        : yamlConfig?.strictValidation !== undefined
        ? yamlConfig.strictValidation
        : true;

    this.registryUrl =
      config.registryUrl || env.MCA_REGISTRY_URL || yamlConfig?.registryUrl;

    this.registryToken =
      config.registryToken || env.MCA_REGISTRY_TOKEN || yamlConfig?.registryToken;

    this.refreshIntervalSecs =
      config.refreshIntervalSecs ||
      parseInt(env.MCA_REGISTRY_REFRESH_INTERVAL || '600') ||
      yamlConfig?.refreshIntervalSecs ||
      600;

    this.filterSystemMetrics =
      config.filterSystemMetrics !== undefined
        ? config.filterSystemMetrics
        : env.MCA_FILTER_SYSTEM_METRICS === 'false'
        ? false
        : yamlConfig?.filterSystemMetrics !== undefined
        ? yamlConfig.filterSystemMetrics
        : true;

    this.validate();
  }

  static create(config: Partial<MCAClientConfig> = {}): MCAConfig {
    let yamlConfig = null;

    if (config.configFilePath) {
      try {
        const fileContent = fs.readFileSync(config.configFilePath, 'utf8');
        yamlConfig = yaml.load(fileContent) as any;
      } catch (error: any) {
        throw new ConfigurationError(
          `Failed to load YAML configuration from ${config.configFilePath}: ${error.message}`
        );
      }
    }

    return new MCAConfig(config, yamlConfig);
  }

  private validate(): void {
    if (!this.serviceName) {
      throw new ConfigurationError(
        'serviceName is required. Set via MCAClient({ serviceName: "..." }) ' +
        'or environment variable MCA_SERVICE_NAME'
      );
    }

    if (this.modelType === 'internal') {
      if (this.strictValidation) {
        if (!this.modelId) {
          throw new ConfigurationError(
            'modelId is required for internal models. ' +
            'Set via modelId parameter or MCA_MODEL_ID environment variable'
          );
        }
        if (!this.modelVersion) {
          throw new ConfigurationError(
            'modelVersion is required for internal models. ' +
            'Set via modelVersion parameter or MCA_MODEL_VERSION environment variable'
          );
        }
        if (!this.teamName) {
          throw new ConfigurationError(
            'teamName is required for internal models. ' +
            'Set via teamName parameter or MCA_TEAM_NAME environment variable'
          );
        }
      }
    }

    if (this.registryUrl) {
      const isLocalhost =
        this.registryUrl.startsWith('http://localhost') ||
        this.registryUrl.startsWith('http://127.0.0.1');

      if (!isLocalhost && !this.registryUrl.startsWith('https://')) {
        throw new ConfigurationError(
          'Registry URL must use HTTPS for non-localhost endpoints. ' +
          `Got: ${this.registryUrl}`
        );
      }
    }
  }

  toResourceAttributes(): Record<string, string> {
    const attrs: Record<string, string> = {
      'service.name': this.serviceName,
    };

    if (this.modelId) attrs['model.id'] = this.modelId;
    if (this.modelVersion) attrs['model.version'] = this.modelVersion;
    if (this.teamName) attrs['team.name'] = this.teamName;
    attrs['model.type'] = this.modelType;

    return attrs;
  }
}
