// TypeScript type definitions for MCA SDK Node.js
import { Attributes } from '@opentelemetry/api';

export type ModelType = 'internal' | 'vendor' | 'generative';

export interface MCAClientConfig {
  serviceName: string;
  modelId?: string;
  modelVersion?: string;
  teamName?: string;
  modelType?: ModelType;
  collectorEndpoint?: string;
  strictValidation?: boolean;
  registryUrl?: string;
  registryToken?: string;
  refreshIntervalSecs?: number;
  configFilePath?: string;
  filterSystemMetrics?: boolean;
}

export interface RecordPredictionOptions {
  inputData?: any;
  outputData?: any;
  latency?: number;
  [key: string]: any;
}

export interface MetricAttributes {
  [key: string]: string | number | boolean;
}

export interface ModelConfig {
  modelId: string;
  modelVersion: string;
  modelType: ModelType;
  teamName: string;
  thresholds?: Record<string, number>;
  [key: string]: any;
}

// Agentic AI tracking types
export type GoalStatus = 'success' | 'failure' | 'partial';

export interface GoalStartOptions {
  description: string;
  type?: string;
  attributes?: Attributes; // Enforce OTel Attributes type
}

export interface GoalCompletionOptions {
  goalId: string;
  status?: GoalStatus;
  attributes?: Attributes; // Enforce OTel Attributes type
}

export interface ErrorRecordingOptions {
  error: Error;
  latency?: number;
  predictionId?: string;
  attributes?: Attributes; // Enforce OTel Attributes type
}

export interface EvaluationOptions {
  mae?: number;
  rmse?: number;
  dataset?: string;
  attributes?: Attributes; // Enforce OTel Attributes type
}
