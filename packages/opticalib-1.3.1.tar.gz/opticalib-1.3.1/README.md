# OptiCalib : adaptive OPTics package for deformable mirrors CALibration

![GitHub Actions Workflow Status](https://img.shields.io/github/actions/workflow/status/ArcetriAdaptiveOptics/opticalib/tests.yml)

`Adaptive Optics Group, INAF - Osservatorio Astrofisico di Arcetri`  

- [Pietro Ferraiuolo](mailto:pietro.ferraiuolo@inaf.it)

- [Marco Xompero](mailto:marco.xompero@inaf.it)

OptiCalib is a python package which first goal is to make easy deformable mirror's calibration in the laboratory (and not only).

It was born as a general extrapolation of the software built for the control and calibration of the `ELT @ M4` adaptive mirror and it's calibration tower, `OTT` (`Optical Test Tower`).

## Description

The `OPTICALIB` package serves two main purposes:

- Making connection to the hardware (interferometers, DMs, ...) easy;

- Providing routines for Deformable Mirrors calibrations.

The latests, stable, version can be installed from pypi:

```bash
pip install opticalib
```

The in-development version can be installed directly from this repository:

```bash
pip install git+"https://github.com/ArcetriAdaptiveOptics/opticalib.git"
```

**But do expect some bugs!**

Upon installation, the software will create an entry point script called `calpy`, which is usefull to set up a specific experiment's environment. Let's say we have an optical bench composed of an interferometer 4D PhaseCam6110 and an Alpao Deformable mirror, say DM820. We can create the experiment's environment just like:

```bash
calpy -f ~/alpao_experiment --create
```

This will create, in the `~/alpao_experiment` folder, the package's data folder tree, together with a configuration file in the `SysConfig` folder. The [configuration file](./opticalib/core/_configurations/configuration.yaml), documented in [configuration documentation](./opticalib/core/_configurations/DOCS.md), is where all devices must be specified.

### Example usage

Once done with the configuration, we can then start using out instruments:

```bash
calpy -f ~/alpao_experiment
```

```python
# The `calpy` function will automatically import opticalib (with `opt` 
# as alias), as well as the `opticalib.dmutils` as dmutils

interf = opt.PhaseCam(6110) # set in the configuration file
dm = opt.AlpaoDm(820)       # set in the configuration file

# Having the bench set up and the configuration file set, we can acquire
# an Influence Function by just doing

tn = dmutils.iff_module.iffDataAcquisition(dm, interf) # Optional paramenters
# are `modesList, modesAmplitude, template`, which if not specified are 
# read from the configuration file
```

## Documentation

For the API references, check [Opticalib API PDF](docs/opticalib.pdf)
(work in progress...), while for configuration details check
[configuration documentation](./opticalib/core/_configurations/DOCS.md).

## Simulator data without Git LFS

Simulator data is no longer shipped inside the repository or Python package.
All files used by the simulator are fetched on demand and cached locally.

### Recommended distribution model

1. Keep all simulator assets out of the repository and out of the package.
2. Publish those files in an HTTP-accessible location (GitHub Release assets,
   object storage, institutional web server, Zenodo, ...).
3. Let opticalib download missing files on-demand to a local cache directory:
   `~/.opticalib/OPTData/SimData` (or your configured OPTData path).

### User configuration

By default, opticalib looks for simulator files under this base URL:

- `https://github.com/ArcetriAdaptiveOptics/opticalib/releases/download/simdata-v1`

To use a custom endpoint, set:

```bash
export OPTICALIB_SIMDATA_BASE_URL="https://your-host/path/to/simdata"
```

You can also override one specific file URL:

```bash
export OPTICALIB_SIMDATA_URL_M4_DATA_H5="https://your-host/m4_data.h5"
```

### Optional prefetch

You can pre-download all known simulator files:

```python
from opticalib.simulator import prefetch_simdata

prefetch_simdata()
```

This avoids runtime downloads when simulators are instantiated.

The repository intentionally does not include the `opticalib/simulator/_API/SimData`
payload anymore.
