"""
This module contains the high-level classes for the use of interferometer devices.

Author(s)
---------
- Pietro Ferraiuolo : pietro.ferraiuolo@inaf.it

"""

import os as _os
import numpy as _np
import time as _time
import shutil as _sh
import subprocess as _sb

from . import _API as _api
from opticalib import typings as _ot
from opticalib.core import root as _fn
from opticalib.ground import osutils as _osu
from opticalib.ground.logger import SystemLogger as _SL
from opticalib.analyzer import modeRebinner as _modeRebinner

global _folds
_folds = _fn.folders
_confReader = _fn.ConfSettingReader4D
_OPDIMG = _folds.OPD_IMAGES_ROOT_FOLDER


class _4DInterferometer(_api.BaseWavefrontSensor):
    """
    Class for the 4D Laser Interferometer.
    """

    def __init__(self, ip: str = None, port: int = None):
        """The constructor"""
        global _folds

        if (ip and port) is None:         
            from opticalib.core.read_config import getInterfConfig 

            config = getInterfConfig(self._name)
            ip = config["ip"]
            port = config["port"]
            _fn._updateInterfPaths(config["Paths"])
        self.ip = ip
        self.port = port
        _folds._update_interf_paths()
        self._logger.info(
            f"Wavefront Sensor {self._name} initialized on address {self.ip}:{self.port}"
        )
        self._i4d = _api.I4D(self.ip, self.port)
        self._ic = _osu._InterferometerConverter()
        _folds._update_interf_paths()

    def acquire_map(
        self, nframes: int = 1, delay: int | float = 0, rebin: int = 1
    ) -> _ot.ImageData:
        """
        Acquires the interferometer image and returns it as a masked array.

        Parameters
        ----------
        nframes: int
            Number of frames to be averaged that produce the measurement.
        delay: int
            Delay between images in seconds.
        rebin: int
            Rebin factor for the image.

        Returns
        -------
        masked_ima: ImageData
            Interferometer image.
        """
        if nframes == 1:
            self._logger.info("Acquiring single frame.")
            width, height, _, data_array = self._i4d.takeSingleMeasurement()
            masked_ima = self._fromDataArrayToMaskedArray(
                width, height, data_array * 632.8e-9
            )
            masked_ima = _modeRebinner(masked_ima, rebin)
        else:
            self._logger.info(f"Acquiring {nframes} frames with {delay}s delay.")
            image_list = []
            for __ in range(nframes):
                width, height, _, data_array = self._i4d.takeSingleMeasurement()
                masked_ima = self._fromDataArrayToMaskedArray(
                    width, height, data_array * 632.8e-9
                )
                image_list.append(masked_ima)
                _time.sleep(delay)
            images = _np.ma.dstack(image_list)
            masked_ima = _np.ma.mean(images, 2)
            masked_ima = _modeRebinner(masked_ima, rebin)
        return masked_ima

    def acquireFullFrame(self, **kwargs:dict[str,_ot.Any]) -> _ot.ImageData:
        """
        Wrapper for the consecutive execution of `acquire_mapo` and `intoFullFrame`.

        Parameters
        ----------
        **kwargs: dict
            Additional keyword arguments to be passed to `acquire_map`.

        Returns
        -------
        _ot.ImageData
            The full frame image data.
        """
        img = self.acquire_map(**kwargs)
        full_frame = self.intoFullFrame(img)
        return full_frame

    def acquire_detector(
        self, nframes: int = 1, delay: int | float = 0
    ) -> _ot.ImageData:
        """
        Parameters
        ----------
        nframes: int
            number of frames
        delay: int | flaot [s]
            delay between images

        Returns
        -------
        data2d: numpy masked array
                detector interferometer image
        """
        self.acquire_map()
        if nframes == 1:
            data, height, _, width = self._i4d.getFringeAmplitudeData()
            data2d = _np.reshape(data, (width, height))
        else:
            image_list = []
            for __ in range(nframes):
                data, height, _, width = self._i4d.getFringeAmplitudeData()
                data2d_t = _np.reshape(data, (width, height))
                image_list.append(data2d_t)
                _time.sleep(delay)
            images = _np.ma.dstack(image_list)
            data2d = _np.ma.mean(images, 2)
        return data2d

    def get_interferogram(self, index: int, rebin: int = 1) -> _ot.ImageData:
        """
        Acquires the interferogram at the specified index.

        Parameters
        ----------
        index: int
            Index of the interferogram to acquire.

        Returns
        -------
        data: numpy array
            Interferogram data.
        """
        json_data = self._i4d.getInterferogram(index)
        data = _np.array(json_data["Data"], dtype=float)
        # width = json_data["Width"]
        # height = json_data["Height"]
        # masked_ima = self._fromDataArrayToMaskedArray(
        #     width, height, data #* 632.8e-9
        # )
        # if rebin > 1:
        #     masked_ima = _modeRebinner(masked_ima, rebin)
        return data

    def capture(self, numberOfFrames: int, folder_name: str = None) -> str:
        """
        Acquires raw phasemaps with ther interferometer, with the set
        frequency.

        Parameters
        ----------
        numberOfFrames: int
            Number of frames to acquire
        folder_name: str, optional
            Name of the folder where to saave.

            If ``None``, a tacking number is generated.

        Returns
        -------
        folder_name: string
            Name of folder measurements
        """
        if folder_name is None:
            folder_name = _osu.newtn()
        print(folder_name)

        self._logger.info(
            f"Capturing {numberOfFrames} frames into folder '{folder_name}'."
        )
        fold4d = _os.path.join(_folds.CAPTURE_FOLDER_NAME_4D_PC, folder_name)
        self._i4d.burstFramesToSpecificDirectory(fold4d, numberOfFrames)
        self.saveConfiguration(_os.path.join(fold4d, "SoftwareSettings.4dini"))
        self.copy4DSettings(
            _os.path.join(_folds.CAPTURE_FOLDER_NAME_LOCAL_PC, folder_name),
            iscapture=True,
        )
        return folder_name

    def produce(
        self, tn: str | list[str], load_interf_config: str | bool = False
    ) -> None:
        """
        Converts the interferometer's ``.rawframe`` files of a ``capture`` into
        full ``.4D`` surface maps.

        Parameters
        ----------
        tn: str
            Tracking number (or name) of the ``capture`` data folder measurements
            to convert
        """
        if not isinstance(tn, list):
            tn = [tn]
        for t in tn:
            self._logger.info(f"Producing measurements in TN = {t}.")
            produce4d = _os.path.join(_folds.PRODUCE_FOLDER_NAME_4D_PC, t)
            capture4d = _os.path.join(_folds.CAPTURE_FOLDER_NAME_4D_PC, t)
            capture_local = _os.path.join(_folds.CAPTURE_FOLDER_NAME_LOCAL_PC, t)
            produce_local = _os.path.join(_folds.PRODUCE_FOLDER_NAME_LOCAL_PC, t)
            dest_data_fold = _os.path.join(_folds.OPD_IMAGES_ROOT_FOLDER, t)

            if load_interf_config:
                if isinstance(load_interf_config, str):
                    conf2load = load_interf_config
                else:
                    conf2load = _os.path.join(
                        capture4d, 'SoftwareSettings.4dini'
                    )
                self._logger.info(f"Loading configuration file `{conf2load}`")
                self.loadConfiguration(conf2load)

            self._i4d.convertRawFramesInDirectoryToMeasurementsInDestinationDirectory(
                produce4d,
                capture4d,
            )
            _sh.move(produce_local, _folds.OPD_IMAGES_ROOT_FOLDER)
            self._rename4D(t)
            try:
                _sh.copy(
                    _os.path.join(capture_local, "SoftwareSettings.4dini"),
                    dest_data_fold,
                )
            except Exception as e:
                print(e)
            self.copy4DSettings(dest=dest_data_fold, src=capture_local, iscapture=False)

    from contextlib import contextmanager

    @contextmanager
    def triggered(self):
        """
        Context handler for entering triggered mode.

        On enter, set the interferometer to triggered, while on exit returns to
        triggered false
        """
        try:
            self.setTriggerMode(True)
            yield
        finally:
            self.setTriggerMode(False)

    del contextmanager

    def setTriggerMode(self, enable: bool) -> None:
        """
        Enables or disables the triggered mode of the interferometer.

        Parameters
        ----------
        enable: bool
            If True, enables triggered mode; if False, disables it.
        """
        self._i4d.setTriggerMode(1 if enable is True else 0)
        if enable:
            self._logger.warning("Triggered mode enabled, waiting for TTL.")
            print("Triggered mode enabled, waiting for TTL")
        else:
            self._logger.warning("Triggered mode disabled.")
            print("Triggered mode disabled")

    def saveConfiguration(self, newConfigurationPath: str) -> None:
        """
        Saves the current configuration of the interferometer to a file.

        Parameters
        ----------
        newConfigurationPath: str
            file path for configuration to save
        filename: str
            name of the configuration file (optional). If None, the original file
            name is used
        """
        self._i4d.saveConfiguration(newConfigurationPath)
        self._logger.info(f"Configuration file saved to '{newConfigurationPath}'.")

    def loadConfiguration(self, conffile: str) -> None:
        """
        Read and loads the configuration file of the interferometer.

        Parameters
        ----------
        conffile: str
            name of the configuration file to load
        """
        self._i4d.loadConfiguration(conffile)
        self._logger.info(f"Configuration file '{conffile}' loaded.")

    def copy4DSettings(
        self,
        dest: str,
        src: str = None,
        copied_name: str = "CameraSettings.ini",
        iscapture=True,
    ) -> None:
        """
        Copies the interferometer settings file to the specified destination.


        """
        # TODO: add check to read copied name from conf.yaml
        destination = _os.path.join(dest, copied_name)
        source = src if src is not None else _folds.SETTINGS_CONF_FILE
        source = _os.path.join(source, copied_name) if iscapture is False else source
        _sh.copy(source, destination)
        self._logger.info(
            f"Copied 4D interferometer settings to folder '{destination}'."
        )

    @staticmethod
    def getCameraSettings(tn: str = None) -> list[int]:
        """
        Reads che actual interferometer settings from its configuration file.

        Return
        ------
        output: list
        list of camera settings: [width_pixel, height_pixel, offset_x, offset_y]
        """
        if not tn is None:
            path = _osu.findTracknum(tn, complete_path=True)
            try:
                file_path = _os.path.join(path, _fn.COPIED_SETTINGS_CONF_FILE)
                setting_reader = _fn.ConfSettingReader4D(file_path)
            except Exception as e:
                print(f"Error: {e}")
                file_path = _os.path.join(path, "4DSettings.ini")
                setting_reader = _fn.ConfSettingReader4D(file_path)
        else:
            file_path = _folds.SETTINGS_CONF_FILE
            setting_reader = _confReader(file_path)
        width_pixel = setting_reader.getImageWidhtInPixels()
        height_pixel = setting_reader.getImageHeightInPixels()
        offset_x = setting_reader.getOffsetX()
        offset_y = setting_reader.getOffsetY()
        return [width_pixel, height_pixel, offset_x, offset_y]

    @staticmethod
    def getFrameRate(tn: str = None) -> float:
        """
        Reads the frame rate the interferometer is working at.

        Return
        ------
        frame_rate: float
            Frame rate of the interferometer
        """
        if not tn is None:
            path = _osu.findTracknum(tn, complete_path=True)
            try:
                file_path = _os.path.join(path, _fn.COPIED_SETTINGS_CONF_FILE)
                setting_reader = _fn.ConfSettingReader4D(file_path)
            except Exception as e:
                print(f"Error: {e}")
                file_path = _os.path.join(path, "4DSettings.ini")
                setting_reader = _fn.ConfSettingReader4D(file_path)
        else:
            file_path = _folds.SETTINGS_CONF_FILE
            setting_reader = _confReader(file_path)
        frame_rate = setting_reader.getFrameRate()
        return frame_rate

    def intoFullFrame(self, img: _ot.ImageData) -> _ot.ImageData:
        """
        The function fits the passed frame (expected cropped) into the
        full interferometer frame (2048x2048), after reading the cropping
        parameters.

        Parameters
        ----------
        img: ImageData
            The image to be fitted into the full frame.

        Return
        ------
        output: ImageData
            The output image, in the interferometer full frame.
        """
        off = (self.getCameraSettings())[2:4]
        off = _np.flip(off)
        nfullpix = _np.array([2048, 2048])
        fullimg = _np.full(nfullpix, _np.nan)  # was   _np.zeros(nfullpix)
        fullmask = _np.ones(nfullpix)
        offx = off[0]
        offy = off[1]
        sx = _np.shape(img)[0]  # croppar[2]
        sy = _np.shape(img)[1]  # croppar[3]
        fullimg[offx : offx + sx, offy : offy + sy] = img.data
        fullmask[offx : offx + sx, offy : offy + sy] = img.mask
        fullimg = _np.ma.masked_array(fullimg, fullmask)
        return fullimg

    def _fromDataArrayToMaskedArray(
        self, width: int, height: int, data_array: _ot.MatrixLike
    ) -> _ot.ImageData:
        """
        Converts the data array to a masked array.

        Parameters
        ----------
        width: int
            Width of the image.
        height: int
            Height of the image.
        data_array: MatrixLike
            Data array to be converted.

        Returns
        -------
        masked_ima: ImageData
            Masked image.
        """
        data = _np.reshape(data_array, (height, width))
        idx, idy = _np.where(_np.isnan(data))
        mask = _np.zeros((data.shape[0], data.shape[1]))
        mask[idx, idy] = 1
        data[idx, idy] = 0.0  # Patch to prevent nan values
        masked_ima = _np.ma.masked_array(data, mask=mask.astype(bool))
        return masked_ima

    def _rename4D(self, folder: str) -> None:
        """
        Renames the produced 'x.4D' files into '0000x.4D'

        Parameters
        ----------
        folder : str
            The folder where the 4D data is stored.
        """
        fold = _os.path.join(_OPDIMG, folder)
        files = _os.listdir(fold)
        for file in files:
            if file.endswith(".4D"):
                num_str = file.split(".")[0]
                if num_str.isdigit():
                    num = int(num_str)
                    new_name = f"{num:05d}.4D"
                    old_file = _os.path.join(fold, file)
                    new_file = _os.path.join(fold, new_name)
                    _os.rename(old_file, new_file)

    def __repr__(self) -> str:
        return f"{self._name}(ip={self.ip}, port={self.port})"


class AccuFiz(_4DInterferometer):
    """
    Class for the AccuFiz Laser Interferometer.
    """

    def __init__(
        self, model: _ot.Optional[str | int] = None, ip: str = None, port: int = None
    ):
        """The constructor"""
        self._name = "AccuFiz" + str(model)
        self._logger = _SL(__class__)
        super().__init__(ip, port)


class PhaseCam(_4DInterferometer):
    """
    Class for the 4D Twyman-Green PhaseCam Laser Interferometer.
    """

    def __init__(
        self, model: _ot.Optional[str | int] = None, ip: str = None, port: int = None
    ):
        """The constructor"""
        self._name = "PhaseCam" + str(model)
        self._logger = _SL(__class__)
        super().__init__(ip, port)


class Processer4D(_4DInterferometer):
    """
    This class is used to process data of 4D interferometers, without
    the need to connect to the actual hardware device.

    The 4D software is loaded through a Virtual Machine (VM) that runs
    on a dedicated computer, over dedicated IP and Ports, allowing
    for multiple processers concurrently.

    The processers need to be defined in the `configuration.yaml` file
    just like any other `INTERFEROMETER` device.

    Parameters
    ----------
    nth: int
        The processer number.
    ip: str
        The IP address of the processer.
    port: int
        The port number of the processer.
    """

    def __init__(self, nth: int | str = 1, ip: str = None, port: int = None):
        """
        This class is used to process data of 4D interferometers, without
        the need to connect to the actual hardware device.

        The 4D software is loaded through a Virtual Machine (VM) that runs
        on a dedicated computer, over dedicated IP and Ports, allowing
        for multiple processers concurrently.

        The processers need to be defined in the `configuration.yaml` file
        just like any other `INTERFEROMETER` device.

        Parameters
        ----------
        nth: int
            The processer number.
        ip: str
            The IP address of the processer.
        port: int
            The port number of the processer.
        """
        self._name = f"4DProcesser{nth}"
        self._logger = _SL(__class__)
        super().__init__(ip, port)
        self._processer = True

    # Disabled acquisition-related methods
    def acquire_map(self, *_, **__):
        raise AttributeError(
            "acquire_map is not available in Processer4D (processing only)."
        )

    def acquire_detector(self, *_, **__):
        raise AttributeError(
            "acquire_detector is not available in Processer4D (processing only)."
        )

    def capture(self, *_, **__):
        raise AttributeError(
            "capture is not available in Processer4D (processing only)."
        )

    def setTriggerMode(self, *_, **__):
        raise AttributeError(
            "setTriggerMode is not available in Processer4D (processing only)."
        )

    def get_interferogram(self, *_, **__):
        raise AttributeError(
            "get_interferogram is not available in Processer4D (processing only)."
        )

    def acquireFullFrame(self, *_, **__):
        raise AttributeError(
            "acquireFullFrame is not available in Processer4D (processing only)."
        )
