"""
Module containing the class which computes the flattening command for a deformable
mirror, given an imput shape and a (filtered) interaction cube.

Author(s)
---------
- Pietro Ferraiuolo : written in 2024

Description
-----------
From the loaded tracking number (tn) the interaction cube will be loaded (and
filtered, if it's not already) from which the interaction matrix will be computed.
If an image to shape is provided on class instance, then the reconstructor will
be automatically computed, while if not, the load_img2shape methos is available
to upload a shape from which compute the reconstructor.

How to Use it
=============
Instancing the class only with the tn of the interaction cube

```python
from opticalib.dmutils import flattening as flt
tn = '20240906_110000' # example tn
f = flt.Flattening(tn)
# say we have acquired an image
img = interf.acquire_map()
f.load_image2shape(img)
f.computeRecMat()
'Computing reconstruction matrix...'
```

all is ready to compute the flat command, by simply running the method

```python
flatCmd = f.computeFlatCmd()
```

Update : all the steps above have been wrapped into the `applyFlatCommand` method,
which will also save the flat command and the images used for the computation in a
dedicated folder in the flat root folder.

"""

import os as _os
import numpy as _np
from opticalib import typings as _ot
from . import iff_processing as _ifp
from opticalib.ground import osutils as _osu
from opticalib.core.root import folders as _fn
from opticalib.ground import computerec as _crec
from ..ground.logger import SystemLogger as _SL
from ..analyzer.images_processing import modeRebinner as _rebin

_ts = _osu.newtn


class Flattening:
    """
    Class for computing and applying flattening commands to deformable mirrors.

    Overview
    --------
    This class manages the process of flattening a deformable mirror using an interaction cube
    and a reference shape (typically acquired from an interferometer). It supports loading and filtering
    interaction cubes, aligning and processing images, computing reconstruction matrices, and generating
    the appropriate command to flatten the mirror surface.

    Key Features
    ------------
    - Loads and filters interaction cubes based on Zernike modes.
    - Aligns input images to the interaction cube mask for accurate command computation.
    - Computes the reconstruction matrix using SVD, with options to discard modes or set thresholds.
    - Calculates the flattening command for a given shape and applies it to the deformable mirror.
    - Saves all relevant data (commands, images, metadata) for traceability and reproducibility.

    Public Methods
    --------------
    - applyFlatCommand(dm, interf, modes2flat, nframes=5, modes2discard=None):
        Acquires images, computes and applies the flattening command, and saves results.
    - computeFlatCmd(n_modes):
        Computes the flattening command for the loaded shape and selected modes.
    - loadImage2Shape(img, compute=None):
        Loads a new image to flatten and optionally computes the reconstruction matrix.
    - computeRecMat(threshold=None):
        Computes the reconstruction matrix for the loaded image.
    - filterIntCube(zernModes=None):
        Filters the interaction cube by removing specified Zernike modes.
    - loadNewTn(tn):
        Loads a new tracking number and updates internal data.

    Usage Example
    -------------
        >>> f = Flattening('20240906_110000')
        >>> img = interf.acquire_map()
        >>> f.loadImage2Shape(img)
        >>> f.computeRecMat()
        >>> flatCmd = f.computeFlatCmd(10)
        >>> f.applyFlatCommand(dm, interf, modes2flat=10)
    """

    def __init__(
        self,
        tn: str,
        dm: _ot.Optional[_ot.DeformableMirrorDevice] = None,
        interf: _ot.Optional[_ot.InterferometerDevice] = None,
    ) -> None:
        """The Constructor"""
        self.tn = tn
        self._oldtn = tn

        self._dm = dm
        self._interf = interf
        self._logger = _SL(__class__)

        self._path = _os.path.join(_ifp._intMatFold, self.tn)

        ## Flat related attributes
        self.shape2flat: _ot.ImageData = None
        self.flatCmd = None
        self.rebin = None
        self.filtered = False
        self.filteredModes = None
        self._lastFlatImg: _ot.ImageData = None
        self._intCube = self._loadIntCube()
        self._cmdMat = self._loadCmdMat()
        self._rec = self._loadReconstructor()
        self._recMat = None
        self._frameCenter = None
        self._flatOffset = None
        self._cavityOffset = None
        # self._synthFlat = None
        # self._flatResidue = None
        # self._flatteningModes = None

    @property
    def RM(self) -> _ot.MatrixLike:
        """
        Reconstruction matrix property.
        """
        return self._recMat

    @property
    def CM(self) -> _ot.MatrixLike:
        """
        Command matrix property.
        """
        return self._cmdMat

    @property
    def IM(self) -> _ot.MatrixLike:
        """
        Interaction cube property.
        """
        return self._rec._intMat

    @property
    def analysisMask(self) -> _ot.MaskData:
        """
        Analysis mask property.
        """
        return self._rec._analysisMask

    @property
    def meta(self) -> dict[str, _ot.Any]:
        """
        Metadata property.
        """
        return self._rec._intMatCube.header

    def closedLoopFlattening(
        self, iterations: int | None = None, **kwargs: dict[str, _ot.Any]
    ) -> None:
        """
        Computes, applies and saves the computed flat command to the DM in
        closed loop, until an input to stop is provided.

        The parameters are the same of

        Parameters
        ----------
        iterations : int, optional
            It is the number of flattening iterations to perform. If not provided,
            the loop will stop at the user's input.
        kwargs: dict
            The arguments for the `applyFlatCommand` function:
            - dm : DeformableMirrorDevice
                Deformable mirror object.
            - interf : InterferometerDevice
                Interferometer object to acquire phasemaps.
            - modes2flat : int | ArrayLike
                Modes to flatten.
            - modes2discard : int, optional
                Number of modes to discard when computing the reconstruction matrix. Default is 3.
            - nframes : int, optional
                Number of frames to average for phasemap acquisition. Default is 5.
        """
        if iterations is not None:
            self._logger.info(
                f"Starting closed-loop flattening for {iterations} iterations."
            )
            for _ in range(iterations):
                self.applyFlatCommand(**kwargs)
        else:
            import sys
            import threading
            import msvcrt
            import tty
            import termios

            def _listen_for_keypress(stop_event: _ot.Any):
                """Listen for any keypress to stop the loop."""
                try:
                    # Windows alternative
                    while not stop_event.is_set():
                        if msvcrt.kbhit():
                            stop_event.set()
                except ImportError:
                    # Unix/Linux alternative
                    fd = sys.stdin.fileno()
                    old_settings = termios.tcgetattr(fd)
                    try:
                        tty.setraw(fd)
                        while not stop_event.is_set():
                            if sys.stdin.read(1):
                                stop_event.set()
                    finally:
                        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

            stop_event = threading.Event()
            listener_thread = threading.Thread(
                target=_listen_for_keypress, args=(stop_event,), daemon=True
            )
            listener_thread.start()

            iteration = 0
            while not stop_event.is_set():
                self._logger.info(f"Closed-loop flattening iteration {iteration}")
                self.applyFlatCommand(**kwargs)
                iteration += 1

            self._logger.info("Closed-loop flattening stopped by user.")

    def applyFlatCommand(
        self,
        dm: _ot.Optional[_ot.DeformableMirrorDevice] = None,
        interf: _ot.Optional[_ot.InterferometerDevice] = None,
        img: _ot.Optional[_ot.ImageData] = None,
        modes2flat: _ot.Optional[int | _ot.ArrayLike] = None,
        modes2discard: _ot.Optional[int] = None,
        nframes: int = 5,
        save: bool = True,
        **setshape_kwargs: dict[str, _ot.Any],
    ) -> _ot.Optional[str]:
        """
        Computes, applies and (optionally) saves the computed flat command to
        the DM, given the calibration's TN.

        Parameters
        ----------
        dm : DeformableMirrorDevice, optional
            Deformable mirror object.
        interf : InterferometerDevice, optional
            Interferometer object to acquire phasemaps.
        img : ImageData, optional
            Image to flatten. If not provided, it will acquired using the provided
            interferometer.
        modes2flat : int | ArrayLike, optional
            Modes to flatten.
        modes2discard : int, optional
            Number of modes to discard when computing the reconstruction matrix. Default is 3.
        nframes : int, optional
            Number of frames to average for phasemap acquisition. Default is 5.
        save : bool, optional
            Whether to save the computed flat command and related data. Default is True.
        setshape_kwargs : dict, optional
            Additional keyword arguments to pass to the DM's `set_shape` method when applying the command.

        Returns
        -------
        tn : str, optional
            Tracking number of the saved flattening data. Returns ``None``
            when ``save=False``.
        """
        # if `DM` is not present, register the one provided
        if dm is None:
            if self._dm is None:
                self._logger.error(
                    "Deformable mirror device must be provided either as an argument or during class instantiation."
                )
                raise ValueError(
                    "Deformable mirror device must be provided either as an argument or during class instantiation."
                )
        else:
            self._dm = dm

        # if `Interf` is not present, register the one provided
        if interf is None:
            if self._interf is None:
                self._logger.error(
                    "Interferometer device must be provided either as an argument or during class instantiation."
                )
                raise ValueError(
                    "Interferometer device must be provided either as an argument or during class instantiation."
                )
            else:
                interf = self._interf

        else:
            self._interf = interf

        if modes2flat is None:
            modes2flat = self._dm.nActs

        self._logger.info("Acquiring starting image from interferometer...")

        if img is None:
            self._startImg = interf.acquire_map(nframes)
            img2pass = _rebin(self._startImg, self.rebin)
        else:
            self._startImg = img2pass = img.copy()

        self.loadImage2Shape(img2pass)
        self.computeRecMat(modes2discard)
        deltacmd = self.computeFlatCmd(modes2flat)
        cmd = self._dm.get_shape()  # TODO: check if this is correct for DP

        # handle diverse DM set_shape args
        _ = setshape_kwargs.pop("differential", None)
        self._logger.info(f"Applying flat command to the {self._dm._name}")
        self._dm.set_shape(deltacmd, differential=True, **setshape_kwargs)

        self._lastFlatImg = interf.acquire_map(nframes)

        fold = None
        if save:
            header = {}
            header["CALDATA"] = (self.tn, "calibration data used")
            header["MDISCAR"] = (
                0 if modes2discard is None else modes2discard,
                "modes discarded in reconstructor",
            )
            header["DMNAME"] = (self._dm._name, "deformable mirror name")
            header["INTERF"] = (interf._name, "interferometer used")
            modes2flat = (
                _np.arange(modes2flat) if isinstance(modes2flat, int) else modes2flat
            )
            fold = self.saveFlatData(cmd, header, modes2flat)
            print(f"Flat command saved in .../{'/'.join(fold.split('/')[-2:])}")
            self._logger.info(f"Flat command and images saved in {fold}.")
            return fold.split("/")[-1]

        self._logger.info("Flat command applied without saving data.")
        return None

    def load_flat_command(
        self, tn: str, apply: bool = False, **setshape_kwargs: dict[str, _ot.Any]
    ) -> _ot.ArrayLike:
        """
        Loads a previously computed flat command from the given tracking number.

        Parameters
        ----------
        tn : str
            Tracking number of the flattening data to load.
        apply : bool, optional
            Whether to apply the loaded flat command to the DM. Default is False.
        setshape_kwargs : dict, optional
            Additional keyword arguments to pass to the DM's `set_shape` method
            when applying the command.

        Returns
        -------
        flat_cmd : ArrayLike, optional
            The loaded flat command, if not applied.
        """
        path = _os.path.join(_fn.FLAT_ROOT_FOLDER, tn)
        flat_cmd = _osu.load_fits(_os.path.join(path, "flatPosition.fits"))
        if apply:
            if self._dm is None:
                self._logger.error(
                    "Deformable mirror device must be registered in the class to apply the loaded flat command."
                )
                raise ValueError(
                    "Deformable mirror device must be registered in the class to apply the loaded flat command."
                )
            self._logger.info(f"Applying loaded flat command from {tn} to the DM...")
            self._dm.set_shape(flat_cmd, **setshape_kwargs)
        else:
            return flat_cmd

    def computeFlatCmd(self, modes2flat: int | _ot.ArrayLike) -> _ot.ArrayLike:
        """
        Compute the command to apply to flatten the input shape.

        Parameters
        ----------
        modes2flat : int | ArrayLike
            Number of modes used to compute the flat command. If int, it will
            compute the first modes2flat of the command matrix. If list, it will
            compute the flat command for the given modes.

        Returns
        -------
        flat_cmd : ndarray
            Flat command.
        """
        self._logger.info("Computing flat command...")
        img = _np.ma.masked_array(self.shape2flat, mask=self._getMasterMask())
        _cmd = -_np.dot(img.compressed(), self._recMat)
        cmdMat = self._cmdMat.copy()
        if isinstance(modes2flat, int):
            flat_cmd = cmdMat[:, :modes2flat] @ _cmd[:modes2flat]
        elif isinstance(modes2flat, (_np.ndarray, list)):
            _cmdMat = _np.zeros((cmdMat.shape[0], len(modes2flat)))
            _scmd = _np.zeros(len(modes2flat))
            for i, mode in enumerate(modes2flat):
                _cmdMat.T[i] = cmdMat.T[mode]
                _scmd[i] = _cmd[mode]
            flat_cmd = _cmdMat @ _scmd
        else:
            self._logger.error(
                f"`modes2flat` must be either an int or a list of int: {type(modes2flat)}"
            )
            raise TypeError(
                f"`modes2flat` must be either an int or a list of int: {type(modes2flat)}"
            )
        self.flatCmd = flat_cmd.copy()
        return flat_cmd

    def loadImage2Shape(self, img: _ot.ImageData) -> None:
        """
        (Re)Loader for the image to flatten.

        Parameters
        ----------
        img : ImageData
            Image to flatten.
        """
        if self._cavityOffset is not None:
            self._logger.info("Subtracting the cavity offset from loaded image...")
            img = img - self._cavityOffset
        self.shape2flat = self._alignImgAndCubeMasks(img)
        self._rec = self._rec.loadShape2Flat(self.shape2flat)
        self._logger.info("Image to shape loaded to Reconstructor class.")

    def computeRecMat(self, threshold: _ot.Optional[int | float] = None):
        """
        Compute the reconstruction matrix for the loaded image.

        Parameters
        ----------
        threshold : int | float, optional
            If not None, it can be either the number of modes to discard from the
            reconstruction matrix computation (int) or the threshold value to discard
            computed eigenvalues for the reconstruction (float). Default is None.
        """
        self._logger.info("Starting reconstruction matrix computation...")
        self._recMat = self._rec.run(sv_threshold=threshold)

    def load_cavity_offset(self, cavity_offset: str | _ot.ImageData) -> None:
        """
        Load a cavity offset to subtract from the loaded image before computing
        the flat command.

        Parameters
        ----------
        cavity_offset : ImageData or str
            Cavity offset to subtract from the loaded image. Can be either the
            image itself or the path to a FITS file to load.
        """
        if isinstance(cavity_offset, str):
            cavity_offset = _osu.load_fits(cavity_offset)
        self._cavityOffset = cavity_offset.copy()
        self._logger.info("Cavity offset loaded.")

    def getSVDmatrices(self) -> tuple[_ot.ArrayLike, _ot.ArrayLike, _ot.ArrayLike]:
        """
        Returns the U, S, Vt matrices from the SVD decomposition of the interaction
        matrix.

        Returns
        -------
        U : ndarray
            Left singular vectors.
        S : ndarray
            Singular values.
        Vt : ndarray
            Right singular vectors (transposed).
        """
        return self._rec._intMat_U, self._rec._intMat_S, self._rec._intMat_Vt

    def plotEigenvalues(self, **plotkwargs: dict[str, _ot.Any]) -> None:
        """
        Plots the eigenvalues of the interaction matrix.
        """
        import matplotlib.pyplot as plt

        if self._rec._intMat_S is None:
            try:
                self.computeRecMat()
            except Exception as e:
                self._logger.error(
                    f"Error computing reconstruction matrix for eigenvalue plot: {e}"
                )
                raise ValueError("Reconstruction matrix not computed yet.") from e

        xlim = plotkwargs.pop("xlim", None)
        ylim = plotkwargs.pop("ylim", None)

        plt.figure()
        plt.semilogy(self._rec._intMat_S, "o-", **plotkwargs)
        plt.title("Eigenvalues of the interaction matrix")
        plt.xlabel("Mode number")
        plt.ylabel("Eigenvalue")
        plt.xlim(xlim)
        plt.ylim(ylim)
        plt.grid()
        plt.show()

    def plotEigenvectors(
        self, modeid: int, out: bool = False, **imshowkwargs: dict[str, _ot.Any]
    ) -> None:
        """
        Plots the eigenvectors of the SVD of the interaction matrix.

        Parameters:
        -----------
        modeid: int
            The eigenvector (mode) id to show.
        **imshowkwargs: dict
            All the arguments that can go to the `plt.imshow` function.
        """
        import matplotlib.pyplot as plt

        if self._rec._intMat_Vt is None:
            raise ValueError("Reconstruction matrix not computed yet.")

        mask = self._getMasterMask()
        img = _np.ma.masked_array(mask * 0.0, mask=mask)
        mode = (self._rec._intMat_Vt).T
        img[img.mask == 0] = mode[:, modeid]

        xlim = imshowkwargs.pop("xlim", None)
        ylim = imshowkwargs.pop("ylim", None)

        plt.figure()
        plt.imshow(img, **imshowkwargs)
        plt.xlabel("X [px]")
        plt.ylabel("Y [px]")
        plt.title(f"Eigenvector of Mode {modeid}")
        plt.xlim(xlim)
        plt.ylim(ylim)
        plt.colorbar()
        plt.show()

        if out:
            return img

    def filterIntCube(
        self,
        zernModes: _ot.Optional[list[int] | _ot.ArrayLike] = None,
        mode: str = "global",
    ) -> "Flattening":
        """
        Filter the interaction cube with the given zernike modes

        Parameters
        ----------
        zernModes : list of int | ArrayLike, optional
            Zernike modes to filter out this cube (if it's not already filtered).
            Default modes are [1,2,3] -> piston/tip/tilt.
        """
        if self.filtered and all(
            [x == y for x, y in zip(self.filteredModes, zernModes)]
        ):
            self._logger.warning("Cube already filtered, skipping...")
            print(f"Cube already filtered, of {self.filteredModes}.")
            return
        else:
            print("Filtering cube...")
            self._oldCube = self._intCube.copy()
            zern2fit = zernModes if zernModes is not None else [1, 2, 3]
            self._logger.info(f"Filtering cube of zernike modes {zern2fit}...")
            self._intCube, new_tn = _ifp.filterZernikeCube(self.tn, zern2fit, mode=mode)
            self.loadNewTn(new_tn)
            self.filtered = True
            self.filteredModes = zern2fit
        return self

    def loadNewTn(self, tn: str) -> None:
        """
        Load a new tracking number for the flattening.

        Parameters
        ----------
        tn : str
            Tracking number of the new data.
        """
        self.__update_tn(tn)
        self._reloadClass(tn)

    def saveFlatData(
        self,
        cmd: _ot.ArrayLike,
        header: _ot.Header | dict[str, _ot.Any],
        modes2flat: _ot.ArrayLike,
    ) -> str:
        """
        Saves flattening data information:
        - Starting Surface Map
        - Flattened Surface Map
        - Flat Command
        - Delta Command

        Parameters
        ----------
        cmd : ArrayLike
            Starting surface command.
        header : Header | dict[str, Any]
            Header information to save with the data.
        modes2flat : ArrayLike
            Modes that have been flattened, to save with the data.

        Returns
        -------
        path : str
            Path where the data have been saved.
        """
        files = [
            "flatPosition.fits",
            "flatDeltaCommand.fits",
            "imgstart.fits",
            "imgflat.fits",
            "modes2flat.fits",
        ]
        imgstart = self._startImg.copy()
        imgflat = self._lastFlatImg.copy()
        deltacmd = self.flatCmd.copy()
        data = [cmd, deltacmd, imgstart, imgflat, modes2flat]

        optionals = {
            "_last_cmd": "flatCommand.fits",
            "_bias_cmd": "BiasCommand.fits",
            "_bias_force": "BiasForces.fits",
        }

        for op, file in optionals.items():
            if hasattr(self._dm, op):
                data.append(getattr(self._dm, op).copy())
                files.append(file)

        if hasattr(self._dm, "get_force"):
            force = self._dm.get_force()
            files.append("flatTotalForces.fits")
            data.append(force)

        path = _osu.create_data_folder(_fn.FLAT_ROOT_FOLDER)

        for file, dat in zip(files, data):
            _osu.save_fits(_os.path.join(path, file), dat, header=header)

        return path

    def _reloadClass(self, tn: str) -> None:
        """
        Reload function for the interaction cube

        Parameters
        ----------
        tn : str
            Tracking number of the new data.
        zernModes : list, optional
            Zernike modes to filter out this cube (if it's not already filtered).
            Default modes are [1,2,3] -> piston/tip/tilt.
        """
        self._cmdMat = self._loadCmdMat()
        self._rec = self._rec.loadInteractionCube(tn=tn)

    def _getMasterMask(self) -> _ot.ImageData:
        """
        Creates the intersection mask of the interaction cube.
        """
        self._logger.info("Creating master mask from interaction cube...")
        cubeMask = _np.sum(self._intCube.mask.astype(int), axis=2)
        master_mask = _np.zeros(cubeMask.shape, dtype=_np.bool_)
        master_mask[_np.where(cubeMask > 0)] = True
        return master_mask

    def _alignImgAndCubeMasks(self, img: _ot.ImageData) -> _ot.ImageData:
        """
        Aligns the image mask with the interaction cube mask.

        Parameters
        ----------
        img : ImageData
            Image to align with the interaction cube mask.

        Returns
        -------
        aligned_img : ImageData
            Aligned image.
        """
        self._logger.info("Aligning image and cube masks...")
        cubemask = self._getMasterMask()
        pad_shape = (
            (cubemask.shape[0] - img.shape[0]) // 2,
            (cubemask.shape[1] - img.shape[1]) // 2,
        )
        if not any([x <= 0 for x in pad_shape]):
            img = _np.ma.masked_array(
                _np.pad(img.data, pad_shape), mask=~_np.pad(~img.mask, pad_shape)
            )
        if img.shape != cubemask.shape:
            self._logger.info("Padding image to match cube mask shape...")
            xdiff = cubemask.shape[1] - img.shape[1]
            ydiff = cubemask.shape[0] - img.shape[0]
            nimg = _np.pad(img.data, ((ydiff, 0), (0, xdiff)))
            nmask = _np.pad(~img.mask, ((ydiff, 0), (0, xdiff)))
            img = _np.ma.masked_array(nimg, mask=~nmask)
        xci, yci = self.__get_mask_center(img.mask)
        xcm, ycm = self.__get_mask_center(cubemask)
        roll = (xcm - xci, ycm - yci)
        img = _np.roll(img, roll, axis=(0, 1))
        if self.filteredModes is not None:
            self._logger.info(
                "Removing Zernike modes from the image to match the loaded calibration..."
            )
            from opticalib.ground.modal_decomposer import ZernikeFitter

            zfit = ZernikeFitter(cubemask)
            self._logger.info(f"Filtered modes: {self.filteredModes}")
            img = zfit.removeZernike(img, self.filteredModes)
        return img

    def _loadIntCube(self) -> _ot.CubeData:
        """
        Interaction cube loader

        Return
        ------
        intCube : CubeData
            The interaction cube data array.
        """
        intCube = _osu.load_fits(_os.path.join(self._path, _ifp._CUBE_FILE))
        rebin = intCube.header.get("REBIN", 1)
        filtered = intCube.header.get("FILTERED", False)
        fittedModes = eval(intCube.header.get("ZREMOVED", "None"))
        self.rebin = rebin
        self.filtered = filtered
        self.filteredModes = fittedModes
        return intCube

    def _loadCmdMat(self) -> _ot.MatrixLike:
        """
        Command matrix loader. It loads the saved command matrix of the loaded
        cube.

        Returns
        -------
        cmdMat : MatrixLike
            Command matrix of the cube, saved in the tn path.
        """
        cmdMat = _osu.load_fits(_os.path.join(self._path, _ifp._MATRIX_FILE))
        return cmdMat

    def _loadReconstructor(self) -> _ot.Reconstructor:
        """
        Builds the reconstructor object off the input cube

        Returns
        -------
        rec : Reconstructor
            Reconstructor class.
        """
        rec = _crec.ComputeReconstructor(interaction_matrix_cube=self._intCube)
        return rec

    def _loadFrameCenter(self):
        """
        Center frame loader, useful for image registration.

        Returns
        -------
        frame_center : TYPE
            DESCRIPTION.

        """
        frame_center = _osu.load_fits("data")
        return frame_center

    def _registerShape(self, shape: tuple[int, int]) -> _ot.ImageData:
        xxx = None
        dp = _ifp.findFrameOffset(self.tn, xxx)
        # cannot work. we should create a dedicated function, not necessarily linked to IFF or flattening
        return dp

    def __get_mask_center(self, mask: _ot.MaskData) -> tuple[int, int]:
        """
        Computes the center of the mask, which is used to align images and cubes.

        Parameters
        ----------
        mask : MaskData
            Mask of the image or cube.

        Returns
        -------
        y_center, x_center : tuple
            Coordinates of the center of the mask.
        """
        ys, xs = _np.where(~mask)
        y_center = (ys.min() + ys.max()) // 2
        x_center = (xs.min() + xs.max()) // 2
        return y_center, x_center

    def __update_tn(self, tn: str) -> None:
        """
        Updates the tn and cube path if the tn is to change

        Parameters
        ----------
        tn : str
            New tracking number.
        """
        self.tn = tn
        self._path = _os.path.join(_ifp._intMatFold, self.tn)

    def __repr__(self) -> str:
        """
        String representation of the class instance.
        """
        tn = self.tn
        filtered = self.filteredModes if self.filtered else False
        r = self.rebin
        return f"Flattening(tn={tn}, filtered={filtered}, rebin={r})"
