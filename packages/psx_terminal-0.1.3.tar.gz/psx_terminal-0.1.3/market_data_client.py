#!/usr/bin/env python3
"""
PSX Market Data Client - Using psx-terminal Library

Demonstrates how to use the installed psx-terminal package to fetch and display
L1 quotes and trade data without the curses-based visualization.

This script uses the published psx-terminal library (pip install psx-terminal)
rather than local source imports.

Usage:
    python market_data_client.py EFERT          # Get quotes and trades for EFERT
    python market_data_client.py EFERT --trades # Show only trades
    python market_data_client.py EFERT --quotes # Show only quotes
    python market_data_client.py --search ABAN  # Search for symbols
"""

import argparse
import sys
from datetime import datetime

# Import from the installed psx-terminal package
try:
    from psx_terminal.feed_parser import fetch_quotes, fetch_trades
    from psx_terminal.main import SymbolManager
except ImportError as e:
    print("Error: psx-terminal package not installed.")
    print("Install with: pip install psx-terminal")
    print(f"Import error: {e}")
    sys.exit(1)


def format_timestamp():
    """Return current timestamp in HH:MM:SS format."""
    return datetime.now().strftime("%H:%M:%S")


def display_quotes(symbol: str, market: str = "REG", limit: int = None) -> None:
    """Fetch and display L1 bid/ask quotes for a symbol."""
    print(f"\n{'='*60}")
    print(f"L1 QUOTES: {symbol} ({market})")
    print(f"{'='*60}")
    print(f"Fetched at: {format_timestamp()}\n")

    try:
        quotes = fetch_quotes(symbol, market)

        if not quotes:
            print(f"No quotes available for {symbol}")
            return

        # Display header
        print(f"{'Time':<10} {'Bid':<12} {'Ask':<12} {'Spread':<10}")
        print("-" * 44)

        # Display quotes (limit to last N if specified)
        display_list = quotes[-limit:] if limit else quotes

        for quote in display_list:
            print(f"{quote.time:<10} {quote.bid:<12.2f} {quote.ask:<12.2f} {quote.spread:<10.4f}")

        print(f"\nTotal quotes: {len(quotes)}")

        # Show current session status
        if quotes:
            latest = quotes[-1]
            if latest.is_end_of_session:
                print("Status: Session closed")
            else:
                print(f"Latest: bid={latest.bid:.2f}, ask={latest.ask:.2f}, spread={latest.spread:.4f}")

    except Exception as e:
        print(f"Error fetching quotes: {e}")


def display_trades(symbol: str, market: str = "REG", limit: int = None) -> None:
    """Fetch and display trade data (time & sales) for a symbol."""
    print(f"\n{'='*60}")
    print(f"TRADE TAPE: {symbol} ({market})")
    print(f"{'='*60}")
    print(f"Fetched at: {format_timestamp()}\n")

    try:
        trades = fetch_trades(symbol, market)

        if not trades:
            print(f"No trades available for {symbol}")
            return

        # Display header
        print(f"{'Time':<10} {'Price':<12} {'Volume':<10}")
        print("-" * 32)

        # Display trades (limit to last N if specified)
        display_list = trades[-limit:] if limit else trades

        for trade in display_list:
            print(f"{trade.time:<10} {trade.price:<12.2f} {trade.volume:<10,}")

        print(f"\nTotal trades: {len(trades)}")

        # Calculate statistics
        if trades:
            total_volume = sum(t.volume for t in trades)
            avg_price = sum(t.price * t.volume for t in trades) / total_volume if total_volume > 0 else 0
            min_price = min(t.price for t in trades)
            max_price = max(t.price for t in trades)

            print(f"\nStatistics:")
            print(f"  Volume traded: {total_volume:,}")
            print(f"  Price range: {min_price:.2f} - {max_price:.2f}")
            print(f"  VWAP: {avg_price:.2f}")

    except Exception as e:
        print(f"Error fetching trades: {e}")


def search_symbols(query: str) -> None:
    """Search for symbols matching the query."""
    print(f"\n{'='*60}")
    print(f"SYMBOL SEARCH: '{query}'")
    print(f"{'='*60}\n")

    try:
        symbol_manager = SymbolManager()
        symbol_manager.load()

        results = symbol_manager.search(query)

        if not results:
            print(f"No symbols found matching '{query}'")
            return

        print(f"{'Symbol':<15} {'Name':<35} {'Market':<8}")
        print("-" * 58)

        for s in results:
            symbol = s.get("symbol", "")
            name = s.get("symbolName", "")[:33]
            market = s.get("market", "")
            print(f"{symbol:<15} {name:<35} {market:<8}")

        print(f"\nFound {len(results)} matching symbols")

    except Exception as e:
        print(f"Error searching symbols: {e}")


def display_market_snapshot(symbol: str, market: str = "REG") -> None:
    """Display a combined snapshot of quotes and recent trades."""
    print(f"\n{'='*60}")
    print(f"MARKET SNAPSHOT: {symbol} ({market})")
    print(f"{'='*60}")
    print(f"Fetched at: {format_timestamp()}\n")

    try:
        # Get latest quote
        quotes = fetch_quotes(symbol, market)
        trades = fetch_trades(symbol, market)

        if quotes:
            latest_quote = quotes[-1]
            print(f"Current Bid/Ask:")
            print(f"  Bid: {latest_quote.bid:.2f}")
            print(f"  Ask: {latest_quote.ask:.2f}")
            print(f"  Spread: {latest_quote.spread:.4f}")
            print(f"  Quotes count: {len(quotes)}")
        else:
            print("No quotes available")

        if trades:
            print(f"\nRecent Trades (last 5):")
            print(f"{'Time':<10} {'Price':<12} {'Volume':<10}")
            print("-" * 32)
            for trade in trades[-5:]:
                print(f"{trade.time:<10} {trade.price:<12.2f} {trade.volume:<10,}")

            # Volume and price statistics
            total_volume = sum(t.volume for t in trades)
            avg_price = sum(t.price * t.volume for t in trades) / total_volume if total_volume > 0 else 0

            print(f"\nTrade Statistics:")
            print(f"  Total volume: {total_volume:,}")
            print(f"  VWAP: {avg_price:.2f}")
            print(f"  Total trades: {len(trades)}")
        else:
            print("No trades available")

    except Exception as e:
        print(f"Error fetching market data: {e}")


def main():
    parser = argparse.ArgumentParser(
        description="PSX Market Data Client - Uses installed psx-terminal library",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python market_data_client.py EFERT              # Full snapshot (quotes + trades)
  python market_data_client.py EFERT --quotes     # L1 quotes only
  python market_data_client.py EFERT --trades     # Trade data only
  python market_data_client.py EFERT --limit 10   # Last 10 records
  python market_data_client.py --search ABAN      # Search for symbols

Note: Requires 'pip install psx-terminal' to be installed.
        """
    )

    parser.add_argument(
        "symbol",
        nargs="?",
        help="Symbol to fetch data for (e.g., EFERT, ABAN)",
    )
    parser.add_argument(
        "--search",
        metavar="QUERY",
        help="Search for symbols matching the query",
    )
    parser.add_argument(
        "--quotes",
        action="store_true",
        help="Show only L1 bid/ask quotes",
    )
    parser.add_argument(
        "--trades",
        action="store_true",
        help="Show only trade data",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Limit results to last N records",
    )
    parser.add_argument(
        "--market",
        default="REG",
        choices=["REG", "ODL"],
        help="Market segment (REG=Regular, ODL=Odd Lot)",
    )

    args = parser.parse_args()

    # Handle symbol search
    if args.search:
        search_symbols(args.search)
        return

    # Require symbol for data fetching
    if not args.symbol:
        parser.print_help()
        sys.exit(1)

    symbol = args.symbol.upper()

    # Determine what to display
    show_quotes = args.quotes or not args.trades  # Default: show quotes
    show_trades = args.trades or not args.quotes  # Default: show trades

    # If user specified both --quotes and --trades, show both
    if args.quotes and args.trades:
        show_quotes = True
        show_trades = True

    # Display requested data
    if show_quotes:
        display_quotes(symbol, args.market, args.limit)

    if show_trades:
        display_trades(symbol, args.market, args.limit)

    # If neither flag specified, show full snapshot
    if not (args.quotes or args.trades):
        # We already showed quotes and trades above, so we're good
        pass


if __name__ == "__main__":
    main()
