"""
feed_parser.py — Minimal parsers for the AhleTrade PSX HTTP feed.

Endpoints:
  PriceVolume  →  HH:MM:SS;bid;ask;|   (L1 best bid/ask snapshots)
  BuySell      →  HH:MM:SS;price;vol;| (trade tape / time & sales)

See FEED_API.md for full documentation.
"""

from urllib.request import urlopen
from dataclasses import dataclass
from typing import Iterator

BASE_URL = "http://feed.ahletrade.com/HTTPFeedServer/FeedFetcher"


def _fetch(identifier: str, symbol: str, market: str = "REG") -> str:
    url = f"{BASE_URL}?action=Market&identifier={identifier}&market={market}&symbol={symbol}"
    with urlopen(url, timeout=10) as r:
        return r.read().decode()


def _records(raw: str) -> Iterator[list[str]]:
    """Split raw response into field lists, skipping empty/sentinel records."""
    for record in raw.split("|"):
        parts = record.strip().split(";")
        if len(parts) >= 3 and parts[0]:
            yield parts


@dataclass
class Quote:
    time: str   # HH:MM:SS
    bid: float
    ask: float

    @property
    def spread(self) -> float:
        return round(self.ask - self.bid, 4)

    @property
    def is_end_of_session(self) -> bool:
        return self.bid == 0.0 and self.ask == 0.0


@dataclass
class Trade:
    time: str   # HH:MM:SS
    price: float
    volume: int


def fetch_quotes(symbol: str, market: str = "REG") -> list[Quote]:
    """Return all L1 bid/ask snapshots for the current session."""
    raw = _fetch("PriceVolume", symbol, market)
    quotes = []
    for p in _records(raw):
        try:
            # Ensure fields are properly stripped and converted
            time_str = p[0].strip()
            bid = float(p[1].strip())
            ask = float(p[2].strip())
            quotes.append(Quote(time_str, bid, ask))
        except (ValueError, IndexError):
            # Skip records with invalid data
            continue
    return quotes


def fetch_trades(symbol: str, market: str = "REG") -> list[Trade]:
    """Return all trade ticks for the current session, excluding heartbeats."""
    raw = _fetch("BuySell", symbol, market)
    trades = []
    prev = None
    for p in _records(raw):
        try:
            # Ensure fields are properly stripped and converted
            time_str = p[0].strip()
            price = float(p[1].strip())
            # Handle volume as float first, then convert to int (handles '0.0' strings)
            volume = int(round(float(p[2].strip())))
            
            t = Trade(time_str, price, volume)
            # Heartbeat detection: same price+volume repeated after a time gap
            if prev and t.price == prev.price and t.volume == prev.volume:
                continue
            trades.append(t)
            prev = t
        except (ValueError, IndexError) as e:
            # Skip records with invalid data
            continue
    return trades


if __name__ == "__main__":
    import sys
    symbol = sys.argv[1] if len(sys.argv) > 1 else "EFERT"

    print(f"=== Quotes ({symbol}) ===")
    quotes = fetch_quotes(symbol)
    for q in quotes[-5:]:
        print(f"  {q.time}  bid={q.bid}  ask={q.ask}  spread={q.spread}")

    print(f"\n=== Trades ({symbol}) ===")
    trades = fetch_trades(symbol)
    for t in trades[-5:]:
        print(f"  {t.time}  price={t.price}  vol={t.volume}")
    print(f"\nTotal quotes: {len(quotes)}  |  Total trades: {len(trades)}")
