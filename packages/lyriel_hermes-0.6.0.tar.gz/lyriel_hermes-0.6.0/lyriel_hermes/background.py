"""Background turn invocation. Runs the agent's LLM for a single turn
without touching the user's main session or surfacing anything to
their chat.

Used by inbox.py to handle Lyriel plan rounds autonomously: the
agent receives the plan-round dispatch, calls lyriel_plan_reply via
its normal tool dispatch (stay-silent or contribute), and returns.
The user's main conversation is unaffected; they only see the final
plan_locked / plan_cancelled notification, never the rounds.

Implementation note: replicates the AIAgent construction from
hermes_cli.oneshot._run_agent WITHOUT the oneshot-CLI global side
effects:
  - _run_agent calls logging.disable(CRITICAL), which would silence
    the entire gateway process. We don't touch logging.
  - _run_agent sets HERMES_YOLO_MODE=1 and HERMES_ACCEPT_HOOKS=1
    process-wide, auto-approving every dangerous-command prompt and
    shell hook. We don't set those — the plugin doesn't need shell
    or destructive tools, and the user shouldn't lose hook gating
    because a plan round fired in the background.
  - _run_agent redirects stdout/stderr to /dev/null. We rely on
    quiet_mode + nulled streaming callbacks instead, which is what
    keeps the gateway's normal logging working.

Threading: called from the inbox poll loop's daemon thread. Each
background turn blocks the loop until the LLM completes — this is
intentional for v0 simplicity (plans are infrequent and sequential
is easier to reason about than concurrent agent invocations).
Memory writes from concurrent AIAgent instances would be a real
race; staying sequential dodges it.

Memory: AIAgent loads memory via the user's configured provider
(file-based or remote). Same provider across invocations = the
background turn sees the user's persistent memory. Session-scoped
chat history is per-session_id; we pass None for now, so background
turns get a fresh session_id and see persistent memory but not the
user's current chat scroll. Acceptable for v0; revisit if plan
decisions need recent chat context.
"""

from __future__ import annotations

import logging
import threading

from . import api, pending

logger = logging.getLogger(__name__)

# Wall-clock cap on background turn duration. If the LLM hangs longer
# than this (free-tier rate limits, provider stalls, network), we
# abandon the worker thread and let the inbox loop continue polling.
# The abandoned worker keeps running and either eventually completes
# (response is silently discarded) or dies — either way the inbox
# loop is unblocked, which is the property we need.
#
# 90s is generous for normal turns (most LLM tool calls return in
# 2-30s) and tight enough that a hung turn doesn't lock the loop
# for the entire long-poll window.
BACKGROUND_TURN_TIMEOUT_S = 180.0


# Prepended to every plan-round dispatch before handing to the LLM.
# Tight wording — every additional token is paid for on every plan
# round and matters at scale.
BACKGROUND_PROMPT_PREFIX = (
    "[Lyriel background plan turn — automated, no user present.\n\n"
    "CRITICAL: You MUST call the lyriel_plan_reply tool to respond. "
    "Text-only responses do nothing — the substrate ignores them, "
    "the round times out, and the plan stalls. The tool call IS "
    "the response. There is no other way to participate in this "
    "round.\n\n"
    "Your user is NOT watching this turn. Do NOT ask clarifying "
    "questions. Use what you already know about them (calendar, "
    "preferences, dietary, location, budget). If a constraint is "
    "missing, accept wide constraints and let other participants "
    "narrow.\n\n"
    "Call lyriel_plan_reply now. Pass stay_silent=true if you "
    "genuinely have nothing to add. Keep `content` concise — "
    "every token costs your user money.]\n\n"
)


def run_background_turn(prompt: str) -> str | None:
    """Run a single agent turn with `prompt`, capped at
    BACKGROUND_TURN_TIMEOUT_S wall-clock seconds. Returns the agent's
    text response (often empty or short — the real work happens via
    the lyriel_plan_reply tool call), or None on error or timeout.

    All errors are logged + swallowed. A failed background turn means
    the round goes unanswered; Lyriel's server-side timeout takes
    over from there.

    The wall-clock timeout exists because agent.chat() can hang
    indefinitely when the underlying LLM provider stalls (free-tier
    rate limits, network issues, model crashes). Without a timeout,
    a hung turn locks the entire inbox poll loop — no further
    dispatches get claimed, no further polls happen, and the agent
    appears dead. We run the actual turn on a worker thread and
    join with a timeout; if it doesn't finish in time, we abandon
    the worker and return None.
    """
    logger.info("background turn: starting (prompt_len=%d)", len(prompt))
    result: list[str | None] = [None]
    exception: list[BaseException | None] = [None]

    def _worker() -> None:
        try:
            result[0] = _do_background_turn(prompt)
        except BaseException as e:  # noqa: BLE001
            exception[0] = e

    worker = threading.Thread(
        target=_worker,
        daemon=True,
        name="lyriel-bg-turn",
    )
    import time as _time  # local import to avoid touching module top
    started = _time.time()
    worker.start()
    worker.join(timeout=BACKGROUND_TURN_TIMEOUT_S)
    elapsed = _time.time() - started
    if worker.is_alive():
        logger.error(
            "background turn: exceeded %.0fs timeout (waited %.1fs); "
            "abandoning worker thread (it will finish in the background; "
            "the inbox loop is unblocked). Likely cause: LLM provider stall.",
            BACKGROUND_TURN_TIMEOUT_S,
            elapsed,
        )
        return None
    if exception[0] is not None:
        logger.error(
            "background turn: worker raised after %.1fs: %s",
            elapsed,
            exception[0],
        )
        return None
    logger.info(
        "background turn: completed in %.1fs (result_len=%d)",
        elapsed,
        len(result[0] or ""),
    )
    return result[0]


def _do_background_turn(prompt: str) -> str | None:
    """Actual blocking implementation. Called only from the worker
    thread spawned by run_background_turn — never the inbox loop
    directly, so its blocking is bounded by the join timeout above.
    """
    try:
        from hermes_cli.config import load_config
        from hermes_cli.runtime_provider import resolve_runtime_provider
        from hermes_cli.tools_config import _get_platform_tools
        from run_agent import AIAgent
    except ImportError as e:
        logger.error("background turn: Hermes runtime not importable: %s", e)
        return None

    try:
        cfg = load_config()
    except Exception as e:  # noqa: BLE001
        logger.error("background turn: load_config failed: %s", e)
        return None

    model_cfg = cfg.get("model") or {}
    if isinstance(model_cfg, str):
        cfg_model = model_cfg
    else:
        cfg_model = model_cfg.get("default") or model_cfg.get("model") or ""

    try:
        runtime = resolve_runtime_provider(
            requested=None,
            target_model=cfg_model or None,
        )
    except Exception as e:  # noqa: BLE001
        logger.error("background turn: resolve_runtime_provider failed: %s", e)
        return None

    try:
        toolsets_list = sorted(_get_platform_tools(cfg, "cli"))
    except Exception as e:  # noqa: BLE001
        logger.error("background turn: failed to resolve toolsets: %s", e)
        return None

    try:
        agent = AIAgent(
            api_key=runtime.get("api_key"),
            base_url=runtime.get("base_url"),
            provider=runtime.get("provider"),
            api_mode=runtime.get("api_mode"),
            model=cfg_model,
            enabled_toolsets=toolsets_list,
            quiet_mode=True,
            platform="lyriel-background",
            credential_pool=runtime.get("credential_pool"),
        )
        # Defensive: kill streaming callbacks so the agent never tries
        # to render to a terminal that isn't there. quiet_mode handles
        # most of this; explicit None covers everything else.
        agent.suppress_status_output = True
        agent.stream_delta_callback = None
        agent.tool_gen_callback = None
        agent.thinking_callback = None
        agent.reasoning_callback = None
        agent.status_callback = None
    except Exception as e:  # noqa: BLE001
        logger.error("background turn: failed to build AIAgent: %s", e)
        return None

    try:
        return agent.chat(prompt) or ""
    except Exception as e:  # noqa: BLE001
        logger.error("background turn: agent.chat failed: %s", e)
        return None


def auto_post_stay_silent(plan_id: str) -> None:
    """Fallback for unreliable tool-calling models.

    When the background-turn LLM generates text without invoking
    lyriel_plan_reply, the round would stall on the server because
    no contribution was posted. This function looks up the pending
    callback for plan_id and POSTs stay_silent=true directly via
    the same callback URL the tool would have used.

    The agent loses ONE round of contribution; the plan keeps moving.
    Better than stalling indefinitely on a model that won't call the
    tool. Cohort-friendly degradation for free-tier OpenRouter models
    (nemotron, deepseek-v4-flash) where tool-call reliability is
    iffy under directive prompts.

    Errors are logged + swallowed — the caller's loop must continue
    polling regardless.
    """
    entry = pending.take_plan(plan_id)
    if entry is None:
        logger.warning(
            "auto stay_silent: no pending callback for plan_id=%s; "
            "either already replied this round or callback expired",
            plan_id,
        )
        return
    try:
        api.send_plan_callback(
            callback_url=entry.callback_url,
            callback_token=entry.callback_token,
            content="",
            stay_silent=True,
        )
        logger.info(
            "auto stay_silent: posted for plan_id=%s (LLM did not call "
            "lyriel_plan_reply; substrate will advance to next round)",
            plan_id,
        )
    except api.LyrielApiError as e:
        # Token was already consumed (rare; only if the tool DID fire
        # but mark_round_replied failed for some reason). Don't restore;
        # we don't want a retry loop on a dead callback.
        logger.error(
            "auto stay_silent for plan_id=%s rejected by substrate "
            "(status=%s): %s",
            plan_id,
            e.status,
            e,
        )
    except Exception as e:  # noqa: BLE001
        logger.error("auto stay_silent for plan_id=%s failed: %s", plan_id, e)
