"""HTTP client for Lyriel's substrate API. Stdlib only.

Three operations:
  - long_poll_inbox(): GET /api/inbox with Bearer auth; returns parsed dispatches
  - send_ask(to, prompt): POST /api/asks; returns ask_id
  - send_callback(callback_url, callback_token, response): POST the per-ask
    callback URL embedded in an inbound dispatch envelope

The Lyriel API key is read from env (LYRIEL_API_KEY); the base URL is read
from env (LYRIEL_BASE_URL) so the user can point at localhost during dev or
https://lyriel.ai in production.
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any
from urllib import error as urllib_error
from urllib import request as urllib_request


class LyrielApiError(Exception):
    """Raised when Lyriel returns a non-2xx or the network fails."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


def base_url() -> str:
    return os.environ.get("LYRIEL_BASE_URL", "https://lyriel.ai").rstrip("/")


def api_key() -> str:
    key = os.environ.get("LYRIEL_API_KEY", "").strip()
    if not key:
        raise LyrielApiError(
            "LYRIEL_API_KEY is not set. Add it to ~/.hermes/.env or export it."
        )
    return key


def _request(
    method: str,
    url: str,
    *,
    headers: dict[str, str] | None = None,
    body: dict[str, Any] | None = None,
    timeout: float = 30.0,
) -> tuple[int, str]:
    merged_headers = {"content-type": "application/json", **(headers or {})}
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib_request.Request(url, data=data, headers=merged_headers, method=method)
    try:
        with urllib_request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode("utf-8")
    except urllib_error.HTTPError as e:
        return e.code, e.read().decode("utf-8", errors="replace")


def long_poll_inbox(timeout: float = 30.0) -> list[dict[str, Any]]:
    """Long-poll Lyriel inbox. Returns a list of dispatch dicts; empty on
    timeout. Each dispatch has keys: id, ask_id, direction, prompt, created_at.
    """
    url = f"{base_url()}/api/inbox"
    status, body = _request(
        "GET",
        url,
        headers={"authorization": f"Bearer {api_key()}"},
        timeout=timeout,
    )
    if status != 200:
        raise LyrielApiError(f"Inbox poll failed ({status}): {body[:200]}", status)
    try:
        parsed = json.loads(body)
    except json.JSONDecodeError as e:
        raise LyrielApiError(f"Inbox response was not JSON: {e}") from e
    return list(parsed.get("dispatches", []))


def send_ask(to: str, prompt: str) -> dict[str, Any]:
    """POST /api/asks. Returns {"ask_id": str, "status": str, ...}.

    `to` may be supplied with or without leading @ — the API accepts both.
    """
    url = f"{base_url()}/api/asks"
    status, body = _request(
        "POST",
        url,
        headers={"authorization": f"Bearer {api_key()}"},
        body={"to": to.lstrip("@"), "prompt": prompt},
    )
    if status not in (200, 202):
        raise LyrielApiError(f"send_ask failed ({status}): {body[:300]}", status)
    try:
        return json.loads(body)
    except json.JSONDecodeError as e:
        raise LyrielApiError(f"send_ask response was not JSON: {e}") from e


def send_callback(callback_url: str, callback_token: str, response: str) -> dict[str, Any]:
    """POST the per-ask callback URL with the response.

    The Bearer token is the single-use one embedded in the inbound dispatch.
    Lyriel returns 200 on first success, 200 idempotent on duplicate, 401 on
    invalid token, 410 if the ask is already in a terminal state.
    """
    status, body = _request(
        "POST",
        callback_url,
        headers={"authorization": f"Bearer {callback_token}"},
        body={"response": response},
    )
    if status not in (200, 410):
        raise LyrielApiError(f"callback failed ({status}): {body[:300]}", status)
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        # Some non-2xx-but-acceptable paths may return plain text — surface
        # raw body for diagnostics rather than throw a second error.
        return {"raw": body, "status": status}


# ─── Plan endpoints ──────────────────────────────────────────────────────


def send_plan(
    participants: list[str],
    description: str,
    max_messages: int | None = None,
) -> dict[str, Any]:
    """POST /api/plans. Initiates a group plan. Returns {"plan_id": str, ...}.

    `participants` is a list of Lyriel handles (with or without leading @).
    """
    url = f"{base_url()}/api/plans"
    body: dict[str, Any] = {
        "participants": [p.lstrip("@") for p in participants],
        "description": description,
    }
    if max_messages is not None:
        body["max_messages"] = int(max_messages)
    status, resp_body = _request(
        "POST",
        url,
        headers={"authorization": f"Bearer {api_key()}"},
        body=body,
    )
    if status not in (200, 202):
        raise LyrielApiError(f"send_plan failed ({status}): {resp_body[:300]}", status)
    try:
        return json.loads(resp_body)
    except json.JSONDecodeError as e:
        raise LyrielApiError(f"send_plan response was not JSON: {e}") from e


def send_plan_callback(
    callback_url: str,
    callback_token: str,
    content: str,
    stay_silent: bool = False,
) -> dict[str, Any]:
    """POST the per-round plan callback URL with this participant's
    contribution (or a stay-silent signal).
    """
    body: dict[str, Any] = {"content": content}
    if stay_silent:
        body["stay_silent"] = True
    status, resp_body = _request(
        "POST",
        callback_url,
        headers={"authorization": f"Bearer {callback_token}"},
        body=body,
    )
    if status not in (200, 409):
        raise LyrielApiError(f"plan callback failed ({status}): {resp_body[:300]}", status)
    try:
        return json.loads(resp_body)
    except json.JSONDecodeError:
        return {"raw": resp_body, "status": status}


def update_profile(bio: str | None = None) -> dict[str, Any]:
    """PATCH /api/me/profile. Currently only `bio` is patchable.

    Pass bio="" to clear the field. Returns the updated profile shape:
    {"ok": True, "profile": {"bio": "<trimmed bio or null>"}}.
    """
    url = f"{base_url()}/api/me/profile"
    body: dict[str, Any] = {}
    if bio is not None:
        body["bio"] = bio
    status, resp_body = _request(
        "PATCH",
        url,
        headers={"authorization": f"Bearer {api_key()}"},
        body=body,
    )
    if status != 200:
        raise LyrielApiError(f"update_profile failed ({status}): {resp_body[:300]}", status)
    try:
        return json.loads(resp_body)
    except json.JSONDecodeError as e:
        raise LyrielApiError(f"update_profile response was not JSON: {e}") from e


def cancel_plan(plan_id: str, reason: str | None = None) -> dict[str, Any]:
    """POST /api/plans/:id/cancel. Initiator-only. Aborts in-flight
    rounds, broadcasts a plan_cancelled envelope to participants, and
    returns the cancelled plan. Returns 409 if the plan already locked
    or was already cancelled.
    """
    url = f"{base_url()}/api/plans/{plan_id}/cancel"
    body: dict[str, Any] = {}
    if reason:
        body["reason"] = reason
    status, resp_body = _request(
        "POST",
        url,
        headers={"authorization": f"Bearer {api_key()}"},
        body=body,
    )
    if status != 200:
        raise LyrielApiError(f"cancel_plan failed ({status}): {resp_body[:300]}", status)
    try:
        return json.loads(resp_body)
    except json.JSONDecodeError as e:
        raise LyrielApiError(f"cancel_plan response was not JSON: {e}") from e


def lock_plan(plan_id: str, summary: str, details: dict[str, Any] | None = None) -> dict[str, Any]:
    """POST /api/plans/:id/lock. Initiator-only. Uses the Lyriel API key
    (not a callback token — locking is initiator-driven, not envelope-driven).
    """
    url = f"{base_url()}/api/plans/{plan_id}/lock"
    body: dict[str, Any] = {"summary": summary}
    if details:
        body["details"] = details
    status, resp_body = _request(
        "POST",
        url,
        headers={"authorization": f"Bearer {api_key()}"},
        body=body,
    )
    if status != 200:
        raise LyrielApiError(f"lock_plan failed ({status}): {resp_body[:300]}", status)
    try:
        return json.loads(resp_body)
    except json.JSONDecodeError as e:
        raise LyrielApiError(f"lock_plan response was not JSON: {e}") from e
