"""Lyriel plugin for Hermes.

Wires Lyriel (https://lyriel.ai) into the Hermes runtime as a native
integration so the user has one agent, one chat, and full agent
context — regardless of which messaging platform their Hermes
gateway routes through.

Three pieces wire up at register():

  1. A background daemon thread that long-polls Lyriel's /api/inbox
     and surfaces each dispatch into the user's session. CLI mode
     uses inject_message; gateway mode routes through whichever
     platform Hermes has enabled (Telegram, Discord, Signal, Slack,
     etc.) using Hermes's own send pipeline. No platform-specific
     code in this plugin.

  2. Five LLM tools — lyriel_send_ask, lyriel_reply, and three plan
     tools — so the user drives Lyriel in natural language ("ping
     noor about dinner thursday", "reply yes thursday works") and
     the agent's LLM translates to substrate calls.

  3. Implicit pending-callback state: when the poll loop surfaces an
     inbound ask, the callback URL + single-use token from the
     sealed envelope are stashed under the ask_id. The lyriel_reply
     tool reads this map when the user wants to respond.

Required env (declared in plugin.yaml's requires_env):
  LYRIEL_API_KEY  — your lyk_... key from https://lyriel.ai/me/agent
Optional env:
  LYRIEL_BASE_URL — defaults to https://lyriel.ai; override for dev

Optional config in ~/.hermes/config.yaml (gateway-mode surfacing):
  plugins.entries.lyriel.surface_chat_id   — chat id Lyriel pushes
                                              into on whichever
                                              platform is enabled
  plugins.entries.lyriel.surface_platform  — pin a specific platform
                                              when multiple are
                                              enabled (optional)
  plugins.entries.lyriel.telegram_chat_id  — legacy alias for
                                              surface_chat_id +
                                              surface_platform=telegram
  gateway.telegram.home_chat_id            — final Telegram-specific
                                              fallback

CLI-mode users don't need any config beyond LYRIEL_API_KEY — the
plugin surfaces directly into the active conversation.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def register(ctx) -> None:
    """Plugin entry point. Called once at Hermes boot when
    plugins.enabled in config.yaml includes 'lyriel'.
    """
    # Import here, not at module top, so `discover_plugins()` can import
    # the plugin module to read its metadata without triggering Hermes's
    # gateway internals (which the surfacing module touches).
    from . import inbox
    from .tools import (
        LYRIEL_PLAN_CANCEL_SCHEMA,
        LYRIEL_PLAN_LOCK_SCHEMA,
        LYRIEL_PLAN_REPLY_SCHEMA,
        LYRIEL_PLAN_SEND_SCHEMA,
        LYRIEL_REPLY_SCHEMA,
        LYRIEL_SEND_ASK_SCHEMA,
        LYRIEL_UPDATE_BIO_SCHEMA,
        handle_lyriel_plan_cancel,
        handle_lyriel_plan_lock,
        handle_lyriel_plan_reply,
        handle_lyriel_plan_send,
        handle_lyriel_reply,
        handle_lyriel_send_ask,
        handle_lyriel_update_bio,
    )

    # LLM tools so the user can drive Lyriel in natural language.
    ctx.register_tool(
        name="lyriel_send_ask",
        toolset="lyriel",
        schema=LYRIEL_SEND_ASK_SCHEMA,
        handler=handle_lyriel_send_ask,
        requires_env=["LYRIEL_API_KEY"],
        emoji="🪶",
        description=(
            "Send a Lyriel ask to another verified user. "
            "Used when the user says things like 'ping @noor about X'."
        ),
    )
    ctx.register_tool(
        name="lyriel_reply",
        toolset="lyriel",
        schema=LYRIEL_REPLY_SCHEMA,
        handler=handle_lyriel_reply,
        requires_env=["LYRIEL_API_KEY"],
        emoji="🪶",
        description=(
            "Reply to a pending Lyriel ask. Used when the user is "
            "responding to a 🪶 Lyriel ask surface message."
        ),
    )

    # Group-plan tools — the wedge. Distinct from 1:1 asks because plans
    # are multi-participant, multi-round, and agent-mediated negotiation.
    ctx.register_tool(
        name="lyriel_plan_send",
        toolset="lyriel",
        schema=LYRIEL_PLAN_SEND_SCHEMA,
        handler=handle_lyriel_plan_send,
        requires_env=["LYRIEL_API_KEY"],
        emoji="🪶",
        description=(
            "Start a Lyriel group plan across multiple participants. "
            "Used when the user wants to coordinate something with two "
            "or more other Lyriel handles."
        ),
    )
    ctx.register_tool(
        name="lyriel_plan_reply",
        toolset="lyriel",
        schema=LYRIEL_PLAN_REPLY_SCHEMA,
        handler=handle_lyriel_plan_reply,
        requires_env=["LYRIEL_API_KEY"],
        emoji="🪶",
        description=(
            "Contribute the user's context (or stay silent) on an "
            "ongoing Lyriel group plan."
        ),
    )
    ctx.register_tool(
        name="lyriel_plan_lock",
        toolset="lyriel",
        schema=LYRIEL_PLAN_LOCK_SCHEMA,
        handler=handle_lyriel_plan_lock,
        requires_env=["LYRIEL_API_KEY"],
        emoji="🪶",
        description=(
            "Lock a Lyriel group plan with a final outcome. Initiator-only."
        ),
    )
    ctx.register_tool(
        name="lyriel_plan_cancel",
        toolset="lyriel",
        schema=LYRIEL_PLAN_CANCEL_SCHEMA,
        handler=handle_lyriel_plan_cancel,
        requires_env=["LYRIEL_API_KEY"],
        emoji="🪶",
        description=(
            "Cancel an in-flight Lyriel group plan. Initiator-only."
        ),
    )

    # Profile-level: agent can write the user's public Lyriel bio
    # directly when prompted. This is NOT a network action — it's
    # account-management, like updating your own display name — so it
    # stays on-thesis even though it's invoked from the agent.
    ctx.register_tool(
        name="lyriel_update_bio",
        toolset="lyriel",
        schema=LYRIEL_UPDATE_BIO_SCHEMA,
        handler=handle_lyriel_update_bio,
        requires_env=["LYRIEL_API_KEY"],
        emoji="🪶",
        description=(
            "Write or update the user's Lyriel bio. The bio is set on "
            "their profile directly — never paste it back to them."
        ),
    )

    # Background inbox poller. Daemon thread — dies cleanly with Hermes.
    # Pass ctx so the loop can use ctx.inject_message for CLI-mode
    # surfacing (proactive notification path when running under
    # `hermes` CLI rather than the gateway with Telegram connected).
    try:
        inbox.start(ctx)
    except Exception as e:  # noqa: BLE001
        logger.error(
            "Lyriel plugin: failed to start inbox poll loop: %s. "
            "Tools registered but you won't receive proactive surfacing.",
            e,
        )
        return

    logger.info(
        "Lyriel plugin registered: 7 tools (ask, reply, plan_send, "
        "plan_reply, plan_lock, plan_cancel, update_bio) + inbox "
        "poll loop on daemon thread"
    )
