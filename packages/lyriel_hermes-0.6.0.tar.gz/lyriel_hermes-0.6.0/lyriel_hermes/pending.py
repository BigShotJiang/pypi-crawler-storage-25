"""In-process state shared between the inbox poll loop and the LLM tools.

Two maps, both lost on Hermes restart (same v0 limitation as the
standalone bridge — acceptable for the spine validation slice).

  pending_callbacks: ask_id → callback URL + single-use Bearer token
    Populated by the inbox poll loop when it claims an inbound
    dispatch (direction='dispatch'). The lyriel_reply tool looks up
    the entry when the user wants to respond, POSTs the callback,
    and removes it.

  absorbed_responses: ask_id → True
    Populated by the lyriel_send_ask tool when it detects a
    synchronous-completion case (the recipient is an in-process
    agent like @lyriel that returns instantly). The tool inlines
    the response into its own result so the LLM's confirmation
    turn naturally surfaces it. The inbox poll loop checks this
    set before surfacing a forward dispatch; if the ask_id is
    present, the dispatch is claimed but NOT re-surfaced to the
    user (otherwise the user sees the reply twice — once inline,
    once via the surface path).

    Entries expire after 60 seconds. After that, if a forward
    arrives, it surfaces normally (the user has presumably moved on
    and a late reply IS new information).
"""

from __future__ import annotations

import re
import threading
import time
from typing import NamedTuple


class PendingCallback(NamedTuple):
    callback_url: str
    callback_token: str
    received_at: float
    prompt_excerpt: str  # short snippet so the LLM can disambiguate


_lock = threading.Lock()
_pending: dict[str, PendingCallback] = {}
_absorbed: dict[str, float] = {}  # ask_id → timestamp the tool absorbed it
_pending_plans: dict[str, PendingCallback] = {}  # plan_id → current-round callback

_ABSORBED_TTL_S = 60.0

# The sealed-ask envelope (see web/src/lib/server/agents/prompt.ts) embeds
# the callback in plain text: `POST <url>` then `Bearer <token>`. Asks
# use lct_<...> tokens; plans use plt_<...> tokens — we accept either.
_RE_CALLBACK_URL = re.compile(r"POST\s+(https?://\S+)")
_RE_CALLBACK_TOKEN = re.compile(r"Bearer\s+((?:lct|plt)_\S+)")
_RE_ASK_TEXT = re.compile(r'The ask:\s*"""\s*(.+?)\s*"""', re.DOTALL)
_RE_PLAN_DESCRIPTION = re.compile(r'THE PLAN:\s*"""\s*(.+?)\s*"""', re.DOTALL)


def remember(ask_id: str, prompt: str) -> bool:
    """Extract the callback from the sealed-ask prompt and remember it
    under ask_id. Returns True on success, False if the prompt didn't
    contain a parseable callback (defensive; shouldn't happen for real
    dispatch direction envelopes).
    """
    url_m = _RE_CALLBACK_URL.search(prompt)
    tok_m = _RE_CALLBACK_TOKEN.search(prompt)
    if not url_m or not tok_m:
        return False
    ask_m = _RE_ASK_TEXT.search(prompt)
    excerpt = (ask_m.group(1).strip() if ask_m else prompt[:80]).strip()
    with _lock:
        _pending[ask_id] = PendingCallback(
            callback_url=url_m.group(1).rstrip(",.;"),
            callback_token=tok_m.group(1).rstrip(",.;"),
            received_at=time.time(),
            prompt_excerpt=excerpt[:200],
        )
    return True


def take(ask_id: str) -> PendingCallback | None:
    """Atomically pop the pending entry for ask_id. None if no such entry."""
    with _lock:
        return _pending.pop(ask_id, None)


def restore(ask_id: str, entry: PendingCallback) -> None:
    """Put an entry back (used after a failed callback POST so the user
    can retry without losing the mapping)."""
    with _lock:
        _pending[ask_id] = entry


def list_pending() -> dict[str, PendingCallback]:
    """Snapshot of currently pending entries. Read-only copy."""
    with _lock:
        return dict(_pending)


def mark_absorbed(ask_id: str) -> None:
    """Record that the lyriel_send_ask tool has already inlined the
    response for this ask into the LLM's tool result. The inbox poll
    will suppress the forward surface to avoid showing the reply twice.
    """
    with _lock:
        _absorbed[ask_id] = time.time()
        _prune_absorbed_locked()


def was_absorbed(ask_id: str) -> bool:
    """True if the tool already handled this ask within the TTL window."""
    with _lock:
        _prune_absorbed_locked()
        return ask_id in _absorbed


def _prune_absorbed_locked() -> None:
    """Drop expired entries. Caller must hold _lock."""
    cutoff = time.time() - _ABSORBED_TTL_S
    expired = [aid for aid, ts in _absorbed.items() if ts < cutoff]
    for aid in expired:
        del _absorbed[aid]


# ─── Plan-specific helpers ────────────────────────────────────────────────
#
# Plans are multi-round: each round Lyriel sends a fresh envelope with a
# fresh single-use callback token. We always overwrite the stored entry
# for a plan_id — the previous round's token is dead anyway (server
# consumed it OR will reject it once a new one is issued).


def remember_plan(plan_id: str, prompt: str) -> bool:
    """Extract the callback from a plan envelope prompt and store it under
    plan_id, replacing any prior round's entry. Returns True if extraction
    succeeded.
    """
    url_m = _RE_CALLBACK_URL.search(prompt)
    tok_m = _RE_CALLBACK_TOKEN.search(prompt)
    if not url_m or not tok_m:
        return False
    desc_m = _RE_PLAN_DESCRIPTION.search(prompt)
    excerpt = (desc_m.group(1).strip() if desc_m else prompt[:80]).strip()
    with _lock:
        _pending_plans[plan_id] = PendingCallback(
            callback_url=url_m.group(1).rstrip(",.;"),
            callback_token=tok_m.group(1).rstrip(",.;"),
            received_at=time.time(),
            prompt_excerpt=excerpt[:200],
        )
    return True


def take_plan(plan_id: str) -> PendingCallback | None:
    """Atomically pop the pending plan entry for plan_id. None if no entry."""
    with _lock:
        return _pending_plans.pop(plan_id, None)


def peek_plan(plan_id: str) -> PendingCallback | None:
    """Look up without consuming. Used by lock tool which doesn't need the
    callback (POSTs to /api/plans/:id/lock with API key, not single-use
    token) but wants to verify the plan exists in this session."""
    with _lock:
        return _pending_plans.get(plan_id)


def list_pending_plans() -> dict[str, PendingCallback]:
    """Snapshot of currently pending plan entries. Read-only copy."""
    with _lock:
        return dict(_pending_plans)


def forget_plan(plan_id: str) -> None:
    """Drop the pending entry for plan_id (used after the plan locks —
    no further callbacks expected)."""
    with _lock:
        _pending_plans.pop(plan_id, None)


# ─── Background-turn tool-call tracking ──────────────────────────────────
#
# When the inbox loop runs a background turn for a plan round, we need
# to know AFTER the LLM call whether the agent actually invoked
# lyriel_plan_reply. Less reliable tool-calling models (free-tier
# nemotron, deepseek-v4-flash, etc.) often generate text without
# calling the tool, which leaves the round stalled on the server side.
#
# The plugin's lyriel_plan_reply handler calls mark_round_replied on
# success. The inbox loop then checks was_round_replied_recently after
# run_background_turn returns; if False, it auto-posts stay_silent so
# the substrate moves on to the next round instead of stalling.

_round_replied: dict[str, float] = {}  # plan_id → timestamp of last reply
_ROUND_REPLIED_WINDOW_S = 60.0


def mark_round_replied(plan_id: str) -> None:
    """Record that lyriel_plan_reply was just invoked for plan_id.
    Called from the tool handler on successful callback POST.
    """
    with _lock:
        _round_replied[plan_id] = time.time()


def was_round_replied_recently(plan_id: str) -> bool:
    """True if lyriel_plan_reply was invoked for plan_id within the
    last _ROUND_REPLIED_WINDOW_S seconds. Used by the inbox loop to
    decide whether to auto-post stay_silent.
    """
    with _lock:
        ts = _round_replied.get(plan_id)
        if ts is None:
            return False
        if time.time() - ts > _ROUND_REPLIED_WINDOW_S:
            del _round_replied[plan_id]
            return False
        return True


def clear_round_replied(plan_id: str) -> None:
    """Drop the per-round tracker for plan_id. Called when the plan
    locks/cancels so we don't accumulate dead entries.
    """
    with _lock:
        _round_replied.pop(plan_id, None)
