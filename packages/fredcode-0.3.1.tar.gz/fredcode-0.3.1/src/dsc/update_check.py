"""PyPI update notice + `fred update` self-update.

Two surfaces:

  - `kickoff()` spawns a daemon thread that GETs the PyPI JSON for
    `fredcode` and writes the result to a cache file. Called from the
    REPL path on launch. Returns immediately; failures are silent.
  - `maybe_print_notice(console)` reads the cache and prints one dim
    line above the banner if a newer version is available. All
    suppression gates live here (TTY, NO_COLOR, CI, FRED_NO_UPDATE_CHECK,
    dev install, missing/stale cache).

The shape is the npm pattern: today reads yesterday's cache; today's
fetch lands for tomorrow. A single network success suppresses notices
for 24h even if subsequent fetches fail.

`fred update` (the subcommand) calls `detect_install_method()` and
`prompt_and_run_upgrade()` synchronously — no caching, no threading,
network requests are the user's intent.
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, Optional

from rich.console import Console

from dsc import __version__

InstallMethod = Literal["pip", "pipx", "uv", "uv-tool", "brew", "dev", "unknown"]

CACHE_PATH = Path.home() / ".config" / "fred" / "update-check.json"
CACHE_TTL_S = 24 * 60 * 60
PYPI_URL = "https://pypi.org/pypi/fredcode/json"
PYPI_TIMEOUT_S = 2.5
DIST_NAME = "fredcode"

_thread_started = threading.Event()


# ---------- public surface -------------------------------------------------


def kickoff() -> None:
    """Fire the background PyPI fetch. No-op if already started or suppressed.

    Idempotent: a module-level Event guards against double-spawn within
    the same process. The daemon thread is silent on every failure mode
    (network, malformed JSON, slow, OS errors) — there is no path that
    surfaces an error to the caller.
    """
    if _thread_started.is_set():
        return
    if _should_suppress_fetch():
        return
    _thread_started.set()
    t = threading.Thread(
        target=_fetch_worker, name="fredcode-update-check", daemon=True
    )
    t.start()


def maybe_print_notice(console: Console) -> None:
    """Print one dim line above the banner if cache says we're behind."""
    if _should_suppress_notice():
        return
    cache = _load_cache()
    if cache is None:
        return
    latest = cache.get("latest")
    current_at_fetch = cache.get("current_at_fetch")
    if not isinstance(latest, str) or not isinstance(current_at_fetch, str):
        return
    # If the user has upgraded between sessions, the cache's
    # "current_at_fetch" no longer matches; let the daemon refresh.
    if current_at_fetch != __version__:
        return
    if not _is_newer(latest, __version__):
        return
    method = detect_install_method()
    cmd = upgrade_command(method)
    cmd_str = " ".join(cmd) if cmd else "pip install --upgrade fredcode"
    console.print(
        f"[dim]fredcode {latest} available "
        f"(you have {__version__}) — run `{cmd_str}`[/]"
    )


def detect_install_method() -> InstallMethod:
    """Best-effort detection of how the running Fred was installed.

    Priority order, first hit wins:
      1. Editable install (PEP 660 `direct_url.json` with editable=true)
      2. INSTALLER marker == "pipx"
      3. INSTALLER marker == "uv" — disambiguate uv-tool vs uv-pip via prefix
      4. Homebrew prefix
      5. INSTALLER marker == "pip" or absent → "pip"
      6. PackageNotFoundError → "unknown"
    """
    try:
        from importlib.metadata import PackageNotFoundError, distribution
    except ImportError:  # pragma: no cover — Python <3.8
        return "unknown"
    try:
        dist = distribution(DIST_NAME)
    except PackageNotFoundError:
        return "unknown"
    # Dev install — pip writes direct_url.json with dir_info.editable=true
    try:
        durl = dist.read_text("direct_url.json")
        if durl:
            data = json.loads(durl)
            if data.get("dir_info", {}).get("editable") is True:
                return "dev"
    except (OSError, json.JSONDecodeError):
        pass
    installer = ""
    try:
        raw = dist.read_text("INSTALLER") or ""
        installer = raw.strip().lower()
    except OSError:
        pass
    if installer == "pipx":
        return "pipx"
    if installer == "uv":
        # `uv tool install` lives under ~/.local/share/uv/tools/ — the
        # right upgrade is `uv tool upgrade`. `uv pip install` lives in
        # an arbitrary venv; right upgrade is `uv pip install -U`.
        if "/uv/tools/" in sys.prefix or "\\uv\\tools\\" in sys.prefix:
            return "uv-tool"
        return "uv"
    prefix = sys.prefix
    if (
        prefix.startswith("/opt/homebrew/Cellar/")
        or prefix.startswith("/usr/local/Cellar/")
        or prefix.startswith("/home/linuxbrew/.linuxbrew/Cellar/")
    ):
        return "brew"
    return "pip"


def upgrade_command(method: InstallMethod) -> Optional[list[str]]:
    """argv for the upgrade. None for dev/unknown (caller should print
    a fallback message instead of executing)."""
    if method == "pip":
        return [sys.executable, "-m", "pip", "install", "--upgrade", "fredcode"]
    if method == "pipx":
        return ["pipx", "upgrade", "fredcode"]
    if method == "uv":
        return ["uv", "pip", "install", "--upgrade", "fredcode"]
    if method == "uv-tool":
        return ["uv", "tool", "upgrade", "fredcode"]
    if method == "brew":
        # No fredcode formula yet — fall back to pip in a fresh venv.
        return None
    return None


def fetch_latest(*, force: bool = False) -> Optional[str]:
    """Synchronous PyPI fetch for `fred update`. Returns the version
    string or None on any error. `force=True` ignores the cache; otherwise
    a fresh enough cache short-circuits the network call."""
    if not force:
        cache = _load_cache()
        if cache and isinstance(cache.get("latest"), str):
            fetched_at = cache.get("fetched_at")
            if isinstance(fetched_at, str):
                age = _age_seconds(fetched_at)
                if age is not None and age < CACHE_TTL_S:
                    return cache["latest"]
    return _fetch_latest_pypi()


def prompt_and_run_upgrade(
    method: InstallMethod,
    latest: Optional[str],
    *,
    assume_yes: bool,
    no_run: bool,
    console: Optional[Console] = None,
) -> int:
    """Print current/latest/command, optionally prompt y/N, exec on confirm.

    Returns an exit code if it returns at all — most success paths
    `os.execvp` and never return.
    """
    if console is None:
        console = Console()
    console.print(f"fredcode [bold]{__version__}[/] (installed via {method})")
    if latest:
        if _is_newer(latest, __version__):
            console.print(f"Latest on PyPI: [bold green]{latest}[/]")
        elif latest == __version__:
            console.print(f"Latest on PyPI: [bold]{latest}[/] — already up to date.")
            return 0
        else:
            # local newer than PyPI (dev/prerelease) — not an error.
            console.print(f"Latest on PyPI: [dim]{latest}[/] (local is ahead)")
            return 0
    else:
        console.print("[dim]Latest on PyPI: (couldn't reach pypi.org)[/]")
    cmd = upgrade_command(method)
    if cmd is None:
        if method == "dev":
            console.print(
                "[yellow]dev install[/] — pull the repo and run "
                "`pip install -e .` to refresh."
            )
        elif method == "brew":
            console.print(
                "[yellow]Homebrew install detected[/], but a fredcode formula "
                "isn't published yet. Try `pip install --upgrade fredcode` in a "
                "fresh venv, or wait for the tap."
            )
        else:
            console.print(
                "[yellow]unknown install method[/] — try "
                "`pip install --upgrade fredcode`."
            )
        return 1
    cmd_str = " ".join(cmd)
    console.print(f"\nWill run: [bold]{cmd_str}[/]")
    if no_run:
        return 0
    if not assume_yes:
        try:
            answer = console.input("Run it? (y/N): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]aborted.[/]")
            return 1
        if answer not in ("y", "yes"):
            console.print("[dim]aborted.[/]")
            return 1
    # Replace the current process. On success this never returns.
    try:
        os.execvp(cmd[0], cmd)
    except OSError as e:
        console.print(f"[red]Could not exec {cmd[0]}:[/] {e}")
        return 1
    return 0  # pragma: no cover — execvp doesn't return on success


# ---------- private --------------------------------------------------------


def _should_suppress_fetch() -> bool:
    """Cheap gates that also cover suppress_notice — we never even fetch
    if the user has opted out, so there's no PyPI traffic from CI runners."""
    if os.environ.get("FRED_NO_UPDATE_CHECK"):
        return True
    if os.environ.get("CI"):
        return True
    if detect_install_method() == "dev":
        return True
    return False


def _should_suppress_notice() -> bool:
    if not sys.stdout.isatty():
        return True
    if os.environ.get("NO_COLOR"):
        return True
    if _should_suppress_fetch():
        return True
    return False


def _fetch_worker() -> None:
    """Daemon-thread body. Silent on every error."""
    if __debug__:
        # Regression guard: truststore must have injected before we
        # touched httpx. truststore.inject_into_ssl() patches the
        # ssl.SSLContext class (not create_default_context). If a future
        # refactor moves _inject_ssl() out of dsc/__init__.py, this fires
        # loudly in tests instead of producing mysterious cert failures
        # in the daemon thread.
        import ssl
        assert "truststore" in ssl.SSLContext.__module__, (
            "truststore.inject_into_ssl() must run before update_check fetch"
        )
    latest = _fetch_latest_pypi()
    if latest:
        _save_cache(latest)


def _fetch_latest_pypi() -> Optional[str]:
    try:
        import httpx
        with httpx.Client(timeout=PYPI_TIMEOUT_S) as client:
            resp = client.get(PYPI_URL)
        if resp.status_code != 200:
            return None
        version = resp.json().get("info", {}).get("version")
        return version if isinstance(version, str) else None
    except Exception:
        return None


def _load_cache() -> Optional[dict]:
    try:
        return json.loads(CACHE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _save_cache(latest: str) -> None:
    try:
        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": 1,
            "latest": latest,
            "fetched_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "current_at_fetch": __version__,
        }
        tmp = CACHE_PATH.with_suffix(CACHE_PATH.suffix + ".tmp")
        tmp.write_text(json.dumps(payload), encoding="utf-8")
        os.replace(tmp, CACHE_PATH)
    except OSError:
        return


def _age_seconds(iso_utc: str) -> Optional[float]:
    """Parse 'YYYY-MM-DDTHH:MM:SSZ' and return seconds since now (UTC).
    Returns None on any parse error. Negative values (clock skew, future
    timestamp) are treated as 'fresh' by callers — we just return them."""
    try:
        dt = datetime.strptime(iso_utc, "%Y-%m-%dT%H:%M:%SZ").replace(
            tzinfo=timezone.utc
        )
        return time.time() - dt.timestamp()
    except (ValueError, TypeError):
        return None


def _is_newer(latest: str, current: str) -> bool:
    """PEP 440 comparison. False on any parse error (don't nag if we
    can't reliably compare)."""
    try:
        from packaging.version import InvalidVersion, Version
    except ImportError:  # pragma: no cover — packaging is a hard dep
        return False
    try:
        return Version(latest) > Version(current)
    except InvalidVersion:
        return False
