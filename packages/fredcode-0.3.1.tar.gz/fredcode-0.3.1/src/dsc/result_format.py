"""Per-tool result formatters: produce (header_summary, body_preview).

`header_summary` is the one-line title shown in the result Panel header
(e.g. `view · src/dsc/cli.py · 163 lines`). `body_preview` is the first
~3 lines of relevant content. The full result is fed to the model
unchanged; this only affects the human display.
"""
from __future__ import annotations

import re

PREVIEW_LINES = 3

_VIEW_RANGE = re.compile(r"\[showing lines \d+-\d+ of (\d+)\]")
_BASH_EXIT = re.compile(r"\A\[exit (-?\d+)\]\n(.*)", re.DOTALL)


def format_result(name: str, args: dict, result: str) -> tuple[str, str]:
    fn = _FORMATTERS.get(name, _generic)
    return fn(args, result)


def _truncate(lines: list[str], total_for_msg: int | None = None) -> str:
    n = total_for_msg if total_for_msg is not None else len(lines)
    head = "\n".join(lines[:PREVIEW_LINES])
    if n > PREVIEW_LINES:
        return head + f"\n…  +{n - PREVIEW_LINES} more lines (use /last to re-show full)"
    return head


def _generic(args: dict, result: str) -> tuple[str, str]:
    if not result:
        return "(empty)", ""
    lines = result.splitlines()
    summary = f"{len(lines)} line{'s' if len(lines) != 1 else ''}"
    return summary, _truncate(lines)


def _fmt_view(args: dict, result: str) -> tuple[str, str]:
    if result.startswith("Error:"):
        first = result.splitlines()[0]
        return first, result
    path = args.get("path", "?")
    lines = result.splitlines()
    m = _VIEW_RANGE.search(result)
    total = int(m.group(1)) if m else len(lines)
    if result.startswith("Directory:"):
        summary = f"{path} · {len(lines)} entr{'ies' if len(lines) != 1 else 'y'}"
    else:
        summary = f"{path} · {total} line{'s' if total != 1 else ''}"
    return summary, _truncate(lines, total_for_msg=total)


def _fmt_bash(args: dict, result: str) -> tuple[str, str]:
    cmd = (args.get("command") or "").strip()
    if len(cmd) > 50:
        cmd = cmd[:50] + "…"
    m = _BASH_EXIT.match(result)
    if m:
        code, body = m.group(1), m.group(2)
        head = f"exit {code} · {cmd}" if cmd else f"exit {code}"
    else:
        body, head = result, f"$ {cmd}" if cmd else "$"
    body_lines = body.splitlines()
    n = len(body_lines)
    # Show "N lines" except when the body is the empty-output marker.
    if n > 0 and not (n == 1 and body_lines[0].startswith("[no output]")):
        summary = f"{head} · {n} line{'s' if n != 1 else ''}"
    else:
        summary = head
    return summary, _truncate(body_lines)


def _fmt_grep(args: dict, result: str) -> tuple[str, str]:
    pattern = args.get("pattern", "?")
    if result.startswith("Error:") or result.startswith("No matches"):
        return result.splitlines()[0], result
    lines = [l for l in result.splitlines() if l.strip()]
    files = len({l.split(":", 1)[0] for l in lines if ":" in l})
    summary = (
        f'{len(lines)} match{"es" if len(lines) != 1 else ""} '
        f'in {files} file{"s" if files != 1 else ""} for "{pattern}"'
    )
    return summary, _truncate(lines)


def _fmt_glob(args: dict, result: str) -> tuple[str, str]:
    pattern = args.get("pattern", "?")
    if result.startswith("Error:") or result.startswith("No files"):
        return result.splitlines()[0], result
    lines = [l for l in result.splitlines() if l.strip()]
    summary = f'{len(lines)} file{"s" if len(lines) != 1 else ""} matching "{pattern}"'
    return summary, _truncate(lines)


def _fmt_str_replace(args: dict, result: str) -> tuple[str, str]:
    return f"{args.get('path', '?')}", result


def _fmt_create_file(args: dict, result: str) -> tuple[str, str]:
    return f"{args.get('path', '?')}", result


def _fmt_todo(args: dict, result: str) -> tuple[str, str]:
    todos = args.get("todos") or []
    summary = f"{len(todos)} item{'s' if len(todos) != 1 else ''}"
    return summary, result


def _fmt_web_search(args: dict, result: str) -> tuple[str, str]:
    if result.startswith("Error:"):
        return result.splitlines()[0], result
    from dsc.web_pricing import estimate_search_microcents, fmt_dollars

    q = (args.get("query") or "").strip()
    if len(q) > 50:
        q = q[:50] + "…"
    lines = result.splitlines()
    n = sum(1 for line in lines if line.startswith("- ["))
    cost = fmt_dollars(estimate_search_microcents(
        search_depth=args.get("search_depth") or "basic",
    ))
    base = f'{n} result{"s" if n != 1 else ""}'
    summary = f'{base} · "{q}" · {cost}' if q else f"{base} · {cost}"
    return summary, _truncate(lines)


def _fmt_web_fetch(args: dict, result: str) -> tuple[str, str]:
    if result.startswith("Error:"):
        return result.splitlines()[0], result
    from dsc.web_pricing import estimate_extract_microcents, fmt_dollars

    urls = args.get("urls") or []
    head = result.splitlines()[0] if result else ""
    m = re.match(r"\[ok (\d+)/(\d+) URLs\]", head)
    if m:
        ok, total = m.group(1), m.group(2)
        base = f"{ok}/{total} URLs extracted"
    else:
        base = f"{len(urls)} URL{'s' if len(urls) != 1 else ''}"
    cost = fmt_dollars(estimate_extract_microcents(
        urls=len(urls),
        extract_depth=args.get("extract_depth") or "basic",
    ))
    summary = f"{base} · {cost}"
    return summary, _truncate(result.splitlines())


_FORMATTERS = {
    "view": _fmt_view,
    "bash": _fmt_bash,
    "grep": _fmt_grep,
    "glob": _fmt_glob,
    "str_replace": _fmt_str_replace,
    "create_file": _fmt_create_file,
    "todo_write": _fmt_todo,
    "web_search": _fmt_web_search,
    "web_fetch": _fmt_web_fetch,
}
