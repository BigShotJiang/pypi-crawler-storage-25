"""Credentials store + LoginFlow for `fred login`.

PKCE + localhost-callback by default (RFC 7636 / 8252). `--device-code`
fallback for headless / SSH (RFC 8628). Browser-side auth happens at
`https://app.fredcode.net/cli/authorize`; the server hands back a
one-time code in the redirect, which we exchange for a `fred_live_*`
key.

Credentials live at `~/.config/fred/credentials.json` (mode 0600). On
macOS the api_key is also mirrored to Keychain via the optional
`keyring` extra.
"""
from __future__ import annotations

import base64
import hashlib
import http.server
import json
import os
import secrets
import socketserver
import sys
import threading
import time
import urllib.parse
import webbrowser
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Optional

import httpx

# Optional keyring import — guarded so missing extra never breaks imports.
try:  # pragma: no cover — import fence
    import keyring as _keyring  # type: ignore[import-not-found]
except ImportError:  # pragma: no cover
    _keyring = None  # type: ignore[assignment]

DEFAULT_AUTH_BASE_URL = "https://app.fredcode.net"
DEFAULT_CRED_PATH = Path.home() / ".config" / "fred" / "credentials.json"
LEGACY_CRED_PATH = Path.home() / ".config" / "dsc" / "credentials.json"
LOOPBACK_PORT = 41257  # fixed so users can register the redirect_uri once
KEYRING_SERVICE = "fredcli"
LOGIN_TIMEOUT_SECONDS = 600
POLL_INTERVAL_SECONDS = 5


@dataclass
class Credentials:
    """Persisted credentials. version=1 is the current schema."""

    version: int
    api_key: str
    email: str
    base_url: str
    fetched_at: str

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> "Credentials":
        return cls(
            version=int(data.get("version", 1)),
            api_key=data["api_key"],
            email=data["email"],
            base_url=data["base_url"],
            fetched_at=data["fetched_at"],
        )


# --------------------------------------------------------------------------
# Persistence
# --------------------------------------------------------------------------

def _ensure_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def load_credentials(path: Path | None = None) -> Optional[Credentials]:
    """Return credentials or None. Warns + chmods if file mode is too open.

    If the new ~/.config/fred/credentials.json doesn't exist but the legacy
    ~/.config/dsc/credentials.json does, migrate it transparently."""
    p = path or DEFAULT_CRED_PATH
    if not p.exists():
        # Back-compat for users who logged in under the old binary name.
        if path is None and LEGACY_CRED_PATH.exists():
            try:
                _ensure_dir(p)
                LEGACY_CRED_PATH.replace(p)
                print(
                    f"fred: migrated credentials from {LEGACY_CRED_PATH} to {p}",
                    file=sys.stderr,
                )
            except OSError:
                # Fall back to reading the legacy path in place.
                p = LEGACY_CRED_PATH
        else:
            return None
    if not p.exists():
        return None
    try:
        st_mode = os.stat(p).st_mode & 0o777
    except OSError:
        st_mode = 0
    if st_mode and st_mode != 0o600:
        print(f"fred: tightening permissions on {p} (was {oct(st_mode)})", file=sys.stderr)
        try:
            os.chmod(p, 0o600)
        except OSError:
            pass
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"fred:could not read credentials at {p}: {e}", file=sys.stderr)
        return None
    try:
        creds = Credentials.from_json(data)
    except (KeyError, ValueError) as e:
        print(f"fred:malformed credentials at {p}: {e}", file=sys.stderr)
        return None
    # If api_key was stored blank (because it lives in keyring), pull it back.
    if not creds.api_key and _keyring is not None:
        try:
            stored = _keyring.get_password(KEYRING_SERVICE, creds.email)
            if stored:
                creds.api_key = stored
        except Exception:  # pragma: no cover — keyring backend issue
            pass
    return creds if creds.api_key else None


def save_credentials(creds: Credentials, path: Path | None = None) -> None:
    """Write credentials with mode 0600. If keyring is present, mirror the
    api_key into the OS keychain and store an empty string in the file."""
    p = path or DEFAULT_CRED_PATH
    _ensure_dir(p)

    api_key_for_file = creds.api_key
    if _keyring is not None:
        try:
            _keyring.set_password(KEYRING_SERVICE, creds.email, creds.api_key)
            api_key_for_file = ""  # file alone is useless if keyring present
        except Exception:  # pragma: no cover — keyring backend issue
            pass

    payload = asdict(creds)
    payload["api_key"] = api_key_for_file

    # Write atomically with restrictive umask so the inode is created 0600.
    old_umask = os.umask(0o077)
    try:
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        os.chmod(tmp, 0o600)
        tmp.replace(p)
    finally:
        os.umask(old_umask)


def delete_credentials(path: Path | None = None) -> Credentials | None:
    """Remove the credentials file (and keyring entry). Returns the previous
    credentials if any, so callers can revoke server-side."""
    p = path or DEFAULT_CRED_PATH
    creds = load_credentials(p)
    if p.exists():
        try:
            p.unlink()
        except OSError as e:
            print(f"fred:could not remove {p}: {e}", file=sys.stderr)
    if creds and _keyring is not None:
        try:
            _keyring.delete_password(KEYRING_SERVICE, creds.email)
        except Exception:  # pragma: no cover
            pass
    return creds


# --------------------------------------------------------------------------
# PKCE
# --------------------------------------------------------------------------

def _gen_pkce_pair() -> tuple[str, str]:
    """Return (verifier, challenge) per RFC 7636. SHA-256 method."""
    verifier = secrets.token_urlsafe(64)[:96]  # 43–128 chars
    challenge_bytes = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(challenge_bytes).rstrip(b"=").decode("ascii")
    return verifier, challenge


# --------------------------------------------------------------------------
# Localhost callback handler
# --------------------------------------------------------------------------

class _CallbackHandler(http.server.BaseHTTPRequestHandler):
    """One-shot handler that captures the redirect from the browser."""

    captured: dict[str, str] = {}
    done_event: threading.Event = threading.Event()

    def do_GET(self) -> None:  # noqa: N802 — required name
        if not self.path.startswith("/callback"):
            self.send_response(404)
            self.end_headers()
            return
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        type(self).captured = {k: v[0] for k, v in params.items() if v}
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(
            (
                "<!doctype html><html><body style='font-family:system-ui;padding:40px;text-align:center'>"
                "<h2>You can close this tab.</h2>"
                "<p>Return to your terminal — Fred is finishing the login.</p>"
                "</body></html>"
            ).encode("utf-8")
        )
        type(self).done_event.set()

    def log_message(self, *_args: Any, **_kwargs: Any) -> None:
        # Silence the default access log — it would corrupt the CLI UI.
        return


# --------------------------------------------------------------------------
# LoginFlow
# --------------------------------------------------------------------------

class LoginError(RuntimeError):
    pass


class LoginFlow:
    """Drives the full login dance. `auth_base_url` defaults to fredcode.net
    but accepts an override for staging / local-dev."""

    def __init__(self, auth_base_url: str | None = None, port: int = LOOPBACK_PORT) -> None:
        self.auth_base_url = (
            auth_base_url
            or os.environ.get("FRED_AUTH_URL")
            or os.environ.get("DSC_AUTH_URL")
            or DEFAULT_AUTH_BASE_URL
        ).rstrip("/")
        self.port = port

    # -- localhost flow -----------------------------------------------------

    def login_browser(self) -> Credentials:
        verifier, challenge = _gen_pkce_pair()
        redirect_uri = f"http://localhost:{self.port}/callback"

        # Step 1: ask the server for a request_id.
        with httpx.Client(timeout=15.0) as client:
            resp = client.post(
                f"{self.auth_base_url}/api/cli/start",
                json={"codeChallenge": challenge, "redirectUri": redirect_uri},
            )
        if resp.status_code != 200:
            raise LoginError(f"Could not start login: {resp.status_code} {resp.text[:200]}")
        request_id = resp.json()["requestId"]
        authorize_url = resp.json().get(
            "authorizeUrl", f"{self.auth_base_url}/cli/authorize?request_id={request_id}"
        )

        # Step 2: spin up the localhost listener.
        _CallbackHandler.captured = {}
        _CallbackHandler.done_event = threading.Event()

        class _ReuseAddrServer(socketserver.TCPServer):
            allow_reuse_address = True  # avoid TIME_WAIT flakiness on retries

        with _ReuseAddrServer(("127.0.0.1", self.port), _CallbackHandler) as httpd:
            server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
            server_thread.start()

            # Step 3: open browser.
            print(f"Opening {authorize_url}")
            try:
                webbrowser.open(authorize_url)
            except webbrowser.Error:
                print("(could not auto-open browser; copy the URL above into one)")

            # Step 4: wait for callback.
            ok = _CallbackHandler.done_event.wait(timeout=LOGIN_TIMEOUT_SECONDS)
            httpd.shutdown()
            if not ok:
                raise LoginError(f"Login timed out after {LOGIN_TIMEOUT_SECONDS // 60} minutes.")

        captured = _CallbackHandler.captured
        if "request_id" not in captured or "one_time_code" not in captured:
            raise LoginError(f"Callback was missing parameters: {captured}")
        if captured["request_id"] != request_id:
            raise LoginError("request_id mismatch — possible cross-site interference; aborting.")

        # Step 5: exchange.
        return self._exchange(request_id, verifier, captured["one_time_code"])

    # -- device-code flow ---------------------------------------------------

    def login_device_code(self) -> Credentials:
        # We reuse the same /start endpoint with a sentinel redirect_uri so
        # the server still validates loopback shape. Then we poll /poll.
        verifier, challenge = _gen_pkce_pair()
        redirect_uri = "http://localhost:0/headless"

        with httpx.Client(timeout=15.0) as client:
            resp = client.post(
                f"{self.auth_base_url}/api/cli/start",
                json={"codeChallenge": challenge, "redirectUri": redirect_uri},
            )
        if resp.status_code != 200:
            raise LoginError(f"Could not start login: {resp.status_code} {resp.text[:200]}")
        body = resp.json()
        request_id = body["requestId"]
        activate_url = f"{self.auth_base_url}/activate?request_id={request_id}"
        print(f"Visit {activate_url} on any device and approve this login.")
        print(f"Request ID: {request_id}")

        deadline = time.monotonic() + LOGIN_TIMEOUT_SECONDS
        with httpx.Client(timeout=15.0) as client:
            while time.monotonic() < deadline:
                time.sleep(POLL_INTERVAL_SECONDS)
                pr = client.post(
                    f"{self.auth_base_url}/api/cli/poll",
                    json={"requestId": request_id, "codeVerifier": verifier},
                )
                if pr.status_code == 200:
                    pj = pr.json()
                    status = pj.get("status")
                    if status == "ready":
                        return Credentials(
                            version=1,
                            api_key=pj["apiKey"],
                            email=pj.get("email", ""),
                            base_url=pj.get("baseUrl", "https://api.fredcode.net/v1"),
                            fetched_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                        )
                    if status == "authorization_pending":
                        continue
                    if status == "slow_down":
                        time.sleep(int(pj.get("interval", POLL_INTERVAL_SECONDS * 2)))
                        continue
                if pr.status_code == 410:
                    raise LoginError("Login request expired before approval.")
        raise LoginError(f"Login timed out after {LOGIN_TIMEOUT_SECONDS // 60} minutes.")

    # -- helpers ------------------------------------------------------------

    def _exchange(self, request_id: str, verifier: str, one_time_code: str) -> Credentials:
        with httpx.Client(timeout=15.0) as client:
            resp = client.post(
                f"{self.auth_base_url}/api/cli/exchange",
                json={
                    "requestId": request_id,
                    "codeVerifier": verifier,
                    "oneTimeCode": one_time_code,
                },
            )
        if resp.status_code != 200:
            try:
                err = resp.json().get("error", resp.text[:200])
            except Exception:
                err = resp.text[:200]
            raise LoginError(f"Exchange failed: {err}")
        body = resp.json()
        whoami = self._whoami(body["apiKey"])
        return Credentials(
            version=1,
            api_key=body["apiKey"],
            email=whoami.get("email") or "",
            base_url=body.get("baseUrl", "https://api.fredcode.net/v1"),
            fetched_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        )

    def _whoami(self, api_key: str) -> dict[str, Any]:
        try:
            with httpx.Client(timeout=10.0) as client:
                resp = client.get(
                    f"{self.auth_base_url}/api/cli/whoami",
                    headers={"Authorization": f"Bearer {api_key}"},
                )
            if resp.status_code == 200:
                return resp.json()
        except httpx.HTTPError:
            pass
        return {}


# --------------------------------------------------------------------------
# Server-side revocation (used by `fred logout`)
# --------------------------------------------------------------------------

def revoke_remote(creds: Credentials, auth_base_url: str | None = None) -> bool:
    """Best-effort revoke. Returns True on 2xx, False otherwise. Never
    raises — logout should always succeed locally even if the server is
    unreachable."""
    base = (
        auth_base_url
        or os.environ.get("FRED_AUTH_URL")
        or os.environ.get("DSC_AUTH_URL")
        or DEFAULT_AUTH_BASE_URL
    ).rstrip("/")
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.post(
                f"{base}/api/cli/revoke",
                headers={"Authorization": f"Bearer {creds.api_key}"},
                json={},
            )
        return 200 <= resp.status_code < 300
    except httpx.HTTPError:
        return False


# --------------------------------------------------------------------------
# Public errors
# --------------------------------------------------------------------------

class InsufficientCreditsError(RuntimeError):
    """Raised by the client when the proxy returns 402."""

    def __init__(self, topup_url: str | None = None) -> None:
        self.topup_url = topup_url or "https://app.fredcode.net/billing"
        super().__init__(
            f"Out of credits. Top up at {self.topup_url} or run `dsc whoami` to check your balance."
        )


class WebResearchDisabledError(RuntimeError):
    """Raised when the proxy returns 403 web_research_disabled — the user
    hasn't toggled web research on in their console settings."""

    def __init__(self, settings_url: str | None = None) -> None:
        self.settings_url = settings_url or "https://app.fredcode.net/settings"
        super().__init__(
            f"Web research is disabled. Enable it at {self.settings_url}."
        )
