"""Tests for the slash-command dropdown completer."""
from __future__ import annotations

from prompt_toolkit.document import Document

from dsc.slash_commands import SLASH_COMMANDS, SlashCommandCompleter


class TestSlashCompleter:
    def test_empty_slash_yields_all_commands(self):
        c = SlashCommandCompleter()
        completions = list(
            c.get_completions(Document("/"), complete_event=None)
        )
        assert {comp.text.strip() for comp in completions} == {
            cmd.name for cmd in SLASH_COMMANDS
        }

    def test_prefix_filter_narrows(self):
        c = SlashCommandCompleter()
        docs = list(
            c.get_completions(Document("/m"), complete_event=None)
        )
        assert {comp.text.strip() for comp in docs} == {
            "/mcp",
            "/mode",
            "/model",
        }

    def test_no_completion_after_space(self):
        c = SlashCommandCompleter()
        assert list(
            c.get_completions(Document("/help "), complete_event=None)
        ) == []

    def test_no_completion_for_non_slash_input(self):
        c = SlashCommandCompleter()
        assert list(
            c.get_completions(Document("hello"), complete_event=None)
        ) == []

    def test_on_open_fires_once_per_partial(self):
        seen: list[int] = []
        c = SlashCommandCompleter(on_open=lambda n: seen.append(n))
        list(c.get_completions(Document("/"), complete_event=None))
        # Same partial — should NOT fire again.
        list(c.get_completions(Document("/"), complete_event=None))
        list(c.get_completions(Document("/m"), complete_event=None))
        assert seen == [len(SLASH_COMMANDS), 3]

    def test_completion_text_has_trailing_space(self):
        c = SlashCommandCompleter()
        completions = list(
            c.get_completions(Document("/h"), complete_event=None)
        )
        assert {comp.text.strip() for comp in completions} == {"/help", "/hooks"}
        for comp in completions:
            assert comp.text.endswith(" ")

    def test_completion_replaces_typed_prefix(self):
        c = SlashCommandCompleter()
        completions = list(
            c.get_completions(Document("/hel"), complete_event=None)
        )
        assert len(completions) == 1
        # start_position is negative len of typed text so Enter/Tab
        # replaces "/hel" with "/help " end-to-end.
        assert completions[0].start_position == -len("/hel")
        assert completions[0].text == "/help "

    def test_case_insensitive(self):
        c = SlashCommandCompleter()
        upper = list(c.get_completions(Document("/HE"), complete_event=None))
        lower = list(c.get_completions(Document("/he"), complete_event=None))
        assert {comp.text for comp in upper} == {comp.text for comp in lower}
