"""System prompt act-mode includes web research; plan-mode does not."""
from __future__ import annotations

from dsc.system_prompt import build
from dsc.tools.registry import default_registry


def test_act_template_contains_web_research_section() -> None:
    out = build(default_registry(), today="2026-05-01", mode="act")
    assert "# Web research" in out
    assert "web_search" in out
    assert "web_fetch" in out
    assert "Cite sources" in out


def test_plan_template_excludes_web_research_section() -> None:
    out = build(default_registry(), today="2026-05-01", mode="plan")
    assert "# Web research" not in out
    # Tools are still in the catalog though — the model can SEE them.
    assert "web_search" in out
    assert "web_fetch" in out


def test_act_template_mentions_per_call_pricing() -> None:
    out = build(default_registry(), today="2026-05-01", mode="act")
    assert "$0.020" in out
