"""Renderer / TurnState / lifecycle glyph tests.

These tests don't make network calls. They drive _LiveBuffer with synthetic
streaming events and assert the resulting TurnState shape, then exercise
the tool_done lifecycle via Renderer methods.
"""
from __future__ import annotations

import io

import pytest
from rich.console import Console

from dsc.client import ToolCall
from dsc.render import Renderer, _glyph_for, _waiting_verb
from dsc.turn_state import CallStatus


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return Console(file=buf, force_terminal=False, width=120, color_system=None), buf


class TestGlyphTable:
    @pytest.mark.parametrize(
        "status,expected_glyph,expected_color",
        [
            (CallStatus.QUEUED, "◯", "grey50"),
            (CallStatus.PERMISSION, "?", "yellow"),
            (CallStatus.DONE_OK, "✓", "green"),
            (CallStatus.DONE_ERROR, "✗", "red"),
            (CallStatus.DENIED, "⊘", "red"),
        ],
    )
    def test_static_glyphs(self, status, expected_glyph, expected_color):
        glyph, color = _glyph_for(status, "")
        assert glyph == expected_glyph
        assert color == expected_color

    def test_running_uses_spinner_frame(self):
        glyph, color = _glyph_for(CallStatus.RUNNING, "⠹")
        assert glyph == "⠹"
        assert color == "cyan"

    def test_running_falls_back_when_no_spinner(self):
        glyph, _ = _glyph_for(CallStatus.RUNNING, "")
        assert glyph == "⠋"


class TestWaitingVerb:
    def test_short_wait(self):
        assert _waiting_verb(2.0) == "thinking"

    def test_medium_wait(self):
        assert _waiting_verb(8.0) == "still thinking"

    def test_long_wait(self):
        assert _waiting_verb(30.0) == "taking a while"


class TestLiveBufferEvents:
    def _setup(self):
        r = Renderer(console=_silent_console(), stream=False)
        cm = r.assistant_turn(iteration=0, max_iters=11)
        buf = cm.__enter__()
        return r, cm, buf

    def test_reasoning_event_accumulates(self):
        r, cm, buf = self._setup()
        try:
            buf.handle("reasoning", "Let me think")
            buf.handle("reasoning", " about this.")
            assert r._turn.reasoning == "Let me think about this."
            assert r._turn.waiting_first_token is False
            assert r._turn.reasoning_done is False
        finally:
            cm.__exit__(None, None, None)

    def test_text_after_reasoning_marks_reasoning_done(self):
        r, cm, buf = self._setup()
        try:
            buf.handle("reasoning", "thinking…")
            assert r._turn.reasoning_done is False
            assert r._turn.reasoning_committed is False
            buf.handle("text", "I'll do X.")
            assert r._turn.reasoning_done is True
            assert r._turn.reasoning_duration_s is not None
            assert r._turn.text == "I'll do X."
            # Reasoning Panel should have been committed once on the first
            # text event — even with no live region (stream=False), the flag
            # flips so future events don't double-commit.
            assert r._turn.reasoning_committed is True
        finally:
            cm.__exit__(None, None, None)

    def test_tool_call_lifecycle_through_streaming(self):
        r, cm, buf = self._setup()
        try:
            buf.handle("tool_call_start", {"index": 0, "id": "call_1", "name": "view"})
            buf.handle("tool_call_args_delta", {"index": 0, "chunk": '{"path":'})
            buf.handle("tool_call_args_delta", {"index": 0, "chunk": '"src/x.py"}'})
            cs = r._turn.calls[0]
            assert cs.name == "view"
            assert cs.call_id == "call_1"
            assert cs.args_str == '{"path":"src/x.py"}'
            assert cs.status == CallStatus.QUEUED
        finally:
            cm.__exit__(None, None, None)

    def test_two_tool_calls_independent_indices(self):
        r, cm, buf = self._setup()
        try:
            buf.handle("tool_call_start", {"index": 0, "id": "a", "name": "view"})
            buf.handle("tool_call_start", {"index": 1, "id": "b", "name": "grep"})
            buf.handle("tool_call_args_delta", {"index": 1, "chunk": '{"pattern":"foo"}'})
            buf.handle("tool_call_args_delta", {"index": 0, "chunk": '{"path":"y.py"}'})
            assert r._turn.calls[0].name == "view"
            assert r._turn.calls[0].args_str == '{"path":"y.py"}'
            assert r._turn.calls[1].name == "grep"
            assert r._turn.calls[1].args_str == '{"pattern":"foo"}'
        finally:
            cm.__exit__(None, None, None)


class TestToolStatusAndDone:
    def test_find_call_by_id(self):
        r = Renderer(console=_silent_console(), stream=False)
        with r.assistant_turn(iteration=0, max_iters=11) as buf:
            buf.handle("tool_call_start", {"index": 0, "id": "abc", "name": "view"})
            cs = r.find_call("abc")
            assert cs is not None
            assert cs.name == "view"
            assert r.find_call("nope") is None

    def test_tool_done_renders_card_and_records_recent(self):
        console, out = _captured_console()
        r = Renderer(console=console, stream=False)
        with r.assistant_turn(iteration=0, max_iters=11) as buf:
            buf.handle("tool_call_start", {"index": 0, "id": "xyz", "name": "view"})
            cs = r.find_call("xyz")
            r.tool_status(cs, CallStatus.RUNNING)
            tc = ToolCall(
                id="xyz", name="view",
                arguments={"path": "src/x.py"}, raw_arguments='{"path":"src/x.py"}',
            )
            r.tool_done(cs, CallStatus.DONE_OK, tc, "  1\thello\n  2\tworld\n")
        rendered = out.getvalue()
        assert "view" in rendered
        assert "src/x.py" in rendered
        assert "✓" in rendered
        assert len(r.recent_results) == 1
        title, full = r.recent_results[0]
        assert "view" in title
        assert "hello" in full

    def test_tool_done_synthesizes_when_streaming_missed_call(self):
        # If the model emits a tool_call without us seeing tool_call_start
        # (shouldn't happen, but defensive), tool_done still prints.
        console, out = _captured_console()
        r = Renderer(console=console, stream=False)
        with r.assistant_turn(iteration=0, max_iters=11):
            tc = ToolCall(id="m", name="grep",
                          arguments={"pattern": "x"}, raw_arguments='{}')
            r.tool_done(None, CallStatus.DONE_OK, tc, "no matches")
        assert "grep" in out.getvalue()

    def test_tool_status_accepts_streaming_lines_count(self):
        # P1.3: bash drain thread pushes a running line count onto the
        # CallState via tool_status(..., lines=N). The final result-card
        # title surfaces it.
        r = Renderer(console=_silent_console(), stream=False)
        with r.assistant_turn(iteration=0, max_iters=11) as buf:
            buf.handle("tool_call_start", {"index": 0, "id": "b", "name": "bash"})
            cs = r.find_call("b")
            r.tool_status(cs, CallStatus.RUNNING, lines=10)
            assert cs.lines == 10
            r.tool_status(cs, CallStatus.RUNNING, lines=42)
            assert cs.lines == 42

    def test_tool_status_lines_default_does_not_clobber(self):
        r = Renderer(console=_silent_console(), stream=False)
        with r.assistant_turn(iteration=0, max_iters=11) as buf:
            buf.handle("tool_call_start", {"index": 0, "id": "b", "name": "bash"})
            cs = r.find_call("b")
            r.tool_status(cs, CallStatus.RUNNING, lines=5)
            r.tool_status(cs, CallStatus.RUNNING)  # no `lines` kwarg
            assert cs.lines == 5  # untouched


class TestUsageAccumulation:
    def test_session_counters_accumulate(self):
        r = Renderer(console=_silent_console(), stream=False)
        r.show_usage(
            {"prompt_tokens": 1000, "completion_tokens": 500,
             "prompt_tokens_details": {"cached_tokens": 200}},
            "deepseek-v4-flash",
        )
        r.show_usage(
            {"prompt_tokens": 2000, "completion_tokens": 100,
             "prompt_tokens_details": {"cached_tokens": 0}},
            "deepseek-v4-flash",
        )
        assert r.session_in == 3000
        assert r.session_out == 600
        assert r.session_cached == 200
        assert r.session_turns == 2
        # Cost is positive and reflects two turns
        assert r.session_cost > 0

    def test_show_usage_handles_missing_usage(self):
        r = Renderer(console=_silent_console(), stream=False)
        r.show_usage(None, "deepseek-v4-flash")
        assert r.session_turns == 0

    def test_unknown_model_falls_back_to_default_rates(self):
        r = Renderer(console=_silent_console(), stream=False)
        r.show_usage({"prompt_tokens": 1000, "completion_tokens": 0}, "unknown-model")
        assert r.session_cost > 0  # used default rates, didn't crash

    def test_cost_summary_format(self):
        r = Renderer(console=_silent_console(), stream=False)
        r.show_usage({"prompt_tokens": 1000, "completion_tokens": 500},
                     "deepseek-v4-flash")
        s = r.cost_summary()
        assert "1 iteration" in s
        assert "1,000" in s
        assert "$" in s


class TestShowTodos:
    def _fake_todos(self):
        from dsc.tools.todo import TodoItem
        return [
            TodoItem(id="1", content="design schema", status="completed"),
            TodoItem(id="2", content="implement endpoint", status="in_progress"),
            TodoItem(id="3", content="write tests", status="pending"),
        ]

    def test_renders_all_three_glyphs(self, monkeypatch):
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False)
        monkeypatch.setattr("dsc.tools.todo.get_todos", self._fake_todos)
        r.show_todos()
        out = buf.getvalue()
        assert "☑" in out
        assert "◐" in out
        assert "☐" in out
        assert "design schema" in out
        assert "implement endpoint" in out
        assert "write tests" in out
        assert "Todos" in out

    def test_empty_todos_prints_nothing(self, monkeypatch):
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False)
        monkeypatch.setattr("dsc.tools.todo.get_todos", lambda: [])
        r.show_todos()
        assert buf.getvalue() == ""

    def test_escapes_brackets_in_content(self, monkeypatch):
        from dsc.tools.todo import TodoItem
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False)
        monkeypatch.setattr(
            "dsc.tools.todo.get_todos",
            lambda: [TodoItem(id="1", content="fix [bug] in parser", status="pending")],
        )
        r.show_todos()
        out = buf.getvalue()
        # Brackets should be visible (not consumed as Rich markup tags).
        assert "[bug]" in out


class TestStreamingOverflow:
    """Regression coverage for the rich.Live overflow-spam bug.

    With the old `vertical_overflow="visible"` setting, a streaming response
    taller than the terminal viewport caused each refresh frame to be
    appended to scrollback rather than overwriting in place — a 60-line
    reply produced ~90 duplicate copies of the header. The fix switches to
    `vertical_overflow="ellipsis"` + `transient=True` and commits the full
    body once via console.print after Live exits.
    """

    def test_tall_streaming_response_commits_full_body_to_scrollback(self):
        # Drive the actual stream=True / Live path against a force_terminal
        # console with a small viewport (24 rows). The old config (visible
        # overflow + no post-exit commit) left only the clipped tail of a
        # tall response in scrollback — users couldn't scroll up to read
        # the top. The fix commits the full body via console.print after
        # Live exits.
        buf = io.StringIO()
        console = Console(
            file=buf, force_terminal=True, width=80, height=24,
            color_system=None,
        )
        r = Renderer(console=console, stream=True)
        with r.assistant_turn(iteration=0, max_iters=11) as live_buf:
            live_buf.handle("reasoning", "long deliberation about the answer")
            for i in range(60):
                live_buf.handle("text", f"Line {i} of streaming response.\n\n")
        out = buf.getvalue()
        # Both the first AND last body lines must appear in the captured
        # output. Pre-fix, only the tail (clipped to 24 rows) survived in
        # scrollback because the live region kept overwriting in place.
        assert "Line 0 of streaming response" in out
        assert "Line 59 of streaming response" in out
        # Reasoning persistence: the full thinking content AND its duration
        # marker should both survive in scrollback. Pre-fix only the dim
        # `▶ thought for X.Xs` one-liner was kept; the deliberation text
        # was lost.
        assert "long deliberation about the answer" in out
        assert "thought for" in out

    def test_live_region_uses_ellipsis_overflow(self):
        # Lock the configuration so a future change can't silently revert
        # to vertical_overflow="visible" (the bug-causing setting).
        import inspect
        from dsc import render
        src = inspect.getsource(render.Renderer.assistant_turn)
        assert 'vertical_overflow="ellipsis"' in src
        assert 'vertical_overflow="visible"' not in src


class TestReasoningPersistence:
    """The reasoning Panel commits to scrollback exactly once per iteration.

    Pre-fix: the streaming Panel was REPLACED by a one-line
    `▶ thought for X.Xs` marker the moment text arrived, and only that
    marker survived in scrollback after Live exited. Users lost the
    full thinking content and saw a flashing collapse.

    Post-fix: on the first event meaning "reasoning is done" (text /
    tool_call_start / stream end), the full Panel is printed to scrollback
    above the live region via Rich's `live.console.print` pattern. The
    one-line marker is gone. Idempotent via `TurnState.reasoning_committed`.
    """

    def _stream_console(self):
        buf = io.StringIO()
        console = Console(
            file=buf, force_terminal=True, width=80, height=24,
            color_system=None,
        )
        return console, buf

    def test_reasoning_panel_commits_when_text_arrives(self):
        console, buf = self._stream_console()
        r = Renderer(console=console, stream=True)
        with r.assistant_turn(iteration=0, max_iters=11) as live_buf:
            live_buf.handle("reasoning", "weighing options carefully")
            live_buf.handle("text", "Here is my answer.")
        out = buf.getvalue()
        # Full reasoning text + duration marker live in scrollback, body too.
        assert "weighing options carefully" in out
        assert "thought for" in out
        # Panel comes BEFORE body in output order.
        assert out.index("weighing options carefully") < out.index("Here is my answer")

    def test_reasoning_panel_commits_when_tool_call_arrives_with_no_text(self):
        # Model went straight from thinking to tool calls — no body text.
        # The reasoning panel must still commit, triggered by tool_call_start.
        console, buf = self._stream_console()
        r = Renderer(console=console, stream=True)
        with r.assistant_turn(iteration=0, max_iters=11) as live_buf:
            live_buf.handle("reasoning", "deciding which tool to call")
            live_buf.handle(
                "tool_call_start",
                {"index": 0, "id": "c1", "name": "view"},
            )
        out = buf.getvalue()
        assert "deciding which tool to call" in out
        # Exactly one panel — the tool_call_start trigger fired before
        # render_final could fire the same trigger again.
        assert out.count("thought for") == 1

    def test_reasoning_panel_commits_when_stream_ends_with_only_reasoning(self):
        # No text, no tool calls — just thinking. render_final fires the
        # commit on context-manager exit.
        console, buf = self._stream_console()
        r = Renderer(console=console, stream=True)
        with r.assistant_turn(iteration=0, max_iters=11) as live_buf:
            live_buf.handle("reasoning", "pondering quietly")
        out = buf.getvalue()
        assert "pondering quietly" in out
        assert "thought for" in out

    def test_reasoning_committed_only_once_under_multiple_triggers(self):
        # All three triggers fire (text, tool_call_start, stream end).
        # The flag must guarantee a single commit.
        console, buf = self._stream_console()
        r = Renderer(console=console, stream=True)
        with r.assistant_turn(iteration=0, max_iters=11) as live_buf:
            live_buf.handle("reasoning", "thinking once")
            live_buf.handle("text", "First answer.")
            live_buf.handle(
                "tool_call_start",
                {"index": 0, "id": "c2", "name": "grep"},
            )
        out = buf.getvalue()
        # If the panel committed multiple times, the duration marker would
        # appear more than once.
        assert out.count("thought for") == 1

    def test_reasoning_skipped_when_show_thinking_false(self):
        # User opted out of thinking display — no panel, no marker, even
        # if the model streams reasoning.
        console, buf = self._stream_console()
        r = Renderer(console=console, stream=True, show_thinking=False)
        with r.assistant_turn(iteration=0, max_iters=11) as live_buf:
            live_buf.handle("reasoning", "this should never appear")
            live_buf.handle("text", "answer")
        out = buf.getvalue()
        assert "this should never appear" not in out
        assert "thought for" not in out
        assert "thinking" not in out
        # Body still shows.
        assert "answer" in out

    def test_reasoning_skipped_in_headless_mode(self):
        # Subagents render headless; the parent's `subagent_card` summarizes
        # the child's reasoning. The child must NOT commit a panel to its
        # own console (which is the parent's console in production).
        console, buf = self._stream_console()
        r = Renderer(console=console, stream=True, headless=True)
        with r.assistant_turn(iteration=0, max_iters=11) as live_buf:
            live_buf.handle("reasoning", "subagent thinking")
            live_buf.handle("text", "subagent body")
        out = buf.getvalue()
        # Nothing emitted — headless renderers don't print panels or body.
        assert "subagent thinking" not in out
        assert "thought for" not in out
        # And the headless_buffer wasn't polluted with reasoning content
        # (it's only used for tool-call cards via `_render_tool_card`).
        assert all("subagent thinking" not in s for s in r.headless_buffer)

    def test_render_final_drops_tool_call_lines(self):
        # The post-Live commit must NOT include in-flight tool-call lines.
        # Only the result Panel from `tool_done` should represent the call
        # in scrollback — leaving stale `◯ queued` lines above DONE panels
        # is the ux regression we're locking against.
        console, buf = self._stream_console()
        r = Renderer(console=console, stream=True)
        with r.assistant_turn(iteration=0, max_iters=11) as live_buf:
            live_buf.handle(
                "tool_call_start",
                {"index": 0, "id": "x1", "name": "bash"},
            )
            live_buf.handle(
                "tool_call_args_delta",
                {"index": 0, "chunk": '{"command":"ls"}'},
            )
        # The Live region rendered the in-flight call line during streaming.
        # After exit, render_final returns body-only — but the body is empty
        # here. Verify the captured output (which includes everything Rich
        # emitted) doesn't contain the call line in a position that would
        # outlive the live region. Stronger check: render_final's renderable
        # must not yield the call line when invoked directly.
        from rich.console import Group
        from rich.text import Text
        final = live_buf.render_final()
        assert isinstance(final, Text), (
            f"render_final must drop tool-call lines and return Text() "
            f"when no body was streamed; got {type(final).__name__}"
        )

    def test_keyboard_interrupt_mid_reasoning_persists_what_streamed(self):
        # If the user hits ^C while reasoning is streaming, the partial
        # thinking text should still survive in scrollback. The `with`
        # block exits via the exception path; render_final hasn't been
        # called by the parent, but `_maybe_commit_reasoning` should have
        # been invoked by the agent loop's caller before re-raising.
        # Here we exercise the renderer-level guarantee: if an exception
        # propagates through the context manager, a subsequent caller of
        # render_final still commits the partial reasoning panel.
        console, buf = self._stream_console()
        r = Renderer(console=console, stream=True)
        try:
            with r.assistant_turn(iteration=0, max_iters=11) as live_buf:
                live_buf.handle("reasoning", "partial thought interrupted")
                # Render the final frame ourselves before re-raising,
                # mirroring what `session.py` does on KeyboardInterrupt
                # (it prints an error after Live exits).
                live_buf.render_final()
                raise KeyboardInterrupt()
        except KeyboardInterrupt:
            pass
        out = buf.getvalue()
        assert "partial thought interrupted" in out
        assert "thought for" in out
