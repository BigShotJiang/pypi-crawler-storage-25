"""Tests for the web_fetch tool."""
from __future__ import annotations

import httpx
import pytest
import respx
from pydantic import ValidationError

from dsc.client import DSClient
from dsc.tools._web_client import reset_active_client, set_active_client
from dsc.tools.web_fetch import HARD_BYTE_CAP, WebFetchArgs, consume_last_stats, run

PROXY_URL = "https://api.fredcode.net/v1/web/extract"


@pytest.fixture
def client_in_context():
    c = DSClient(api_key="dsc_live_test", base_url="https://api.fredcode.net/v1")
    token = set_active_client(c)
    yield c
    reset_active_client(token)
    consume_last_stats()


@pytest.fixture
def fresh_stats():
    consume_last_stats()
    yield
    consume_last_stats()


@respx.mock
def test_happy_path_single_url(client_in_context, fresh_stats) -> None:
    raw = "Some markdown body" * 100  # ~1.7KB
    respx.post(PROXY_URL).mock(
        return_value=httpx.Response(
            200,
            json={
                "results": [
                    {"url": "https://docs.example.com/page", "raw_content": raw}
                ],
                "failed_results": [],
                "response_time": 0.3,
            },
            headers={"x-fred-web-cost-microcents": "20000", "x-fred-web-credits": "1"},
        )
    )
    out = run(WebFetchArgs(urls=["https://docs.example.com/page"]))
    assert out.startswith("[ok 1/1 URLs]")
    assert "--- [1] https://docs.example.com/page ---" in out

    stats = consume_last_stats()
    assert stats["ok"] is True
    assert stats["success_count"] == 1
    assert stats["failed_count"] == 0
    assert stats["urls_requested"] == 1
    assert stats["total_bytes"] == len(raw.encode())
    assert stats["cost_billed_microcents"] == 20_000


@respx.mock
def test_partial_failure(client_in_context, fresh_stats) -> None:
    respx.post(PROXY_URL).mock(
        return_value=httpx.Response(
            200,
            json={
                "results": [
                    {"url": "https://a.example/", "raw_content": "ok content"}
                ],
                "failed_results": [
                    {"url": "https://b.example/", "error": "404 not found"}
                ],
                "response_time": 0.2,
            },
        )
    )
    out = run(WebFetchArgs(urls=["https://a.example/", "https://b.example/"]))
    assert "[ok 1/2 URLs]" in out
    assert "[failed] https://b.example/: 404 not found" in out

    stats = consume_last_stats()
    assert stats["success_count"] == 1
    assert stats["failed_count"] == 1


@respx.mock
def test_truncation_at_third_url(client_in_context, fresh_stats) -> None:
    big = "x" * 40_000
    results = [
        {"url": f"https://e/{i}", "raw_content": big} for i in range(5)
    ]
    respx.post(PROXY_URL).mock(
        return_value=httpx.Response(
            200,
            json={"results": results, "failed_results": [], "response_time": 0.4},
        )
    )
    out = run(WebFetchArgs(urls=[f"https://e/{i}" for i in range(5)]))
    assert "truncated at URL" in out
    stats = consume_last_stats()
    assert stats["truncated"] is True
    assert stats["truncated_at_url"] is not None
    assert stats["truncated_at_url"] <= 5
    assert stats["bytes_returned"] <= HARD_BYTE_CAP + 100


@respx.mock
def test_proxy_403_disabled(client_in_context, fresh_stats) -> None:
    respx.post(PROXY_URL).mock(
        return_value=httpx.Response(
            403,
            json={
                "error": {
                    "type": "web_research_disabled",
                    "settings_url": "https://app.fredcode.net/settings",
                }
            },
        )
    )
    out = run(WebFetchArgs(urls=["https://x/"]))
    assert "web research is disabled" in out
    stats = consume_last_stats()
    assert stats["error_class"] == "web_research_disabled"


def test_args_validation_url_count() -> None:
    with pytest.raises(ValidationError):
        WebFetchArgs(urls=[])
    with pytest.raises(ValidationError):
        WebFetchArgs(urls=[f"https://e/{i}" for i in range(21)])
