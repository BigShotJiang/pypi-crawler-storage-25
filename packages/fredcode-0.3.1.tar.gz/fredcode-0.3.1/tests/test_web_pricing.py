"""Tests for web research pricing estimates (display-only on the CLI)."""
from __future__ import annotations

import pytest

from dsc.web_pricing import (
    estimate_extract_microcents,
    estimate_search_microcents,
    fmt_dollars,
)


def test_search_basic_costs_one_credit() -> None:
    # 1 credit @ $0.008 upstream * 2.5 margin = $0.020 = 20_000 microcents.
    assert estimate_search_microcents(search_depth="basic") == 20_000


def test_search_advanced_costs_two_credits() -> None:
    assert estimate_search_microcents(search_depth="advanced") == 40_000


def test_search_default_is_basic() -> None:
    assert estimate_search_microcents() == 20_000


@pytest.mark.parametrize(
    ("urls", "expected"),
    [(1, 20_000), (5, 20_000), (6, 40_000), (10, 40_000), (11, 60_000)],
)
def test_extract_basic_batches_by_five(urls: int, expected: int) -> None:
    assert estimate_extract_microcents(urls=urls) == expected


def test_extract_advanced_doubles_the_cost() -> None:
    assert estimate_extract_microcents(urls=20, extract_depth="advanced") == 4 * 40_000


def test_extract_zero_urls_clamped_to_one_batch() -> None:
    # Defensive: caller passes 0 by accident; we still bill for 1 batch
    # (the proxy would reject it before any debit anyway).
    assert estimate_extract_microcents(urls=0) == 20_000


def test_fmt_dollars() -> None:
    assert fmt_dollars(20_000) == "$0.020"
    assert fmt_dollars(40_000) == "$0.040"
    assert fmt_dollars(0) == "$0.000"
    assert fmt_dollars(1_500_000) == "$1.500"
