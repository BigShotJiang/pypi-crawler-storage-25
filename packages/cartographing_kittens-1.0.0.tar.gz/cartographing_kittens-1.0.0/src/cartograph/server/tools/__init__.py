"""Cartograph MCP server tools."""
