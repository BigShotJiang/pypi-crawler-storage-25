# BPMN Reporting Decorator

A Pythonic decorator to track function execution and report events (STARTED, COMPLETED, ERROR) in the background.

## Features

- **Non-blocking**: Uses `asyncio.create_task` to fire events while your code runs.
- **Async & Sync**: Works with both `async def` and standard `def` functions.
- **Masking**: Built-in support for Mustache-based payload transformation.
- **Error Tracking**: Automatically reports exceptions before re-raising them.

## Usage

### 1. Basic Setup

Wrap any function to track its lifecycle.

```python
import asyncio
from bpmn_reporting import bpmn_element

@bpmn_element(id="User_Task_01", process_id="Order_Process")
async def my_business_logic(data):
    # Do work here
    return {"status": "processed"}


# Execute
if __name__ == "__main__":
    asyncio.run(my_business_logic({"id": 123}))
```

### 2. Masking & Transformations

Use mask_params to remove sensitive data or reformat payloads using Mustache templates or functions.

```python
@bpmn_element(
    id="Process_Payment",
    mask_params={
        "password": None,  # Removes field from reporting
        "total": "{{amount}} {{ccy}}",  # Recomputes field using Mustache
        "user": lambda p: p['email']  # Recomputes using a function
    }
)
async def process_payment(payload):
    # original payload: {"password": "123", "amount": 10, "ccy": "EUR", "email": "mario@test.com"}
    return {"tx_id": "ABC-123"}
```

## Configuration

Set the following environment variables in your local .env or Azure Function App settings:

| Variable                  | Required | Description                                | Default |
|---------------------------|----------|--------------------------------------------|---------|
| REPORTING_SERVER	         | true     | Base URL of the reporting API	             |         |
| REPORTING_PROCESS_ID	     |          | Default Process ID if not set in decorator |         |
| REPORTING_PROCESS_VERSION |          | Version of the process                     | 1.0     |
| REPORTING_PROCESS_DEBUG   |          | Set to true to see event logs	             | false   |

## Testing

```
python3 -m pytest tests/
```

