import pytest
from src.bpmn_reporting.bpmn_parser  import get_process_data, list_processes

@pytest.fixture
def sample_bpmn():
    """Fixture providing a standard Zeebe BPMN XML string."""
    return '''<?xml version="1.0" encoding="UTF-8"?>
    <bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" 
                      xmlns:zeebe="http://camunda.org/schema/zeebe/1.0">
      <bpmn:process id="Process_Test_123" isExecutable="true">
        <bpmn:extensionElements>
          <zeebe:versionTag value="2.1.0" />
          <zeebe:properties>
            <zeebe:property name="bounded-context" value="shipping-test" />
            <zeebe:property name="retention-time" value="30" />
          </zeebe:properties>
        </bpmn:extensionElements>
      </bpmn:process>
    </bpmn:definitions>'''

def test_get_process_data_parsing(sample_bpmn):
    """Verify that XML attributes and extension elements are parsed correctly."""
    data = get_process_data(sample_bpmn, "shipping.bpmn")

    assert data.processId == "Process_Test_123"
    assert data.processVersion == "2.1.0"
    assert data.boundedContext == "shipping-test"
    assert data.retentionTime == "30"

def test_list_processes_directory_scan(tmp_path, sample_bpmn):
    """Verify scanning a directory for multiple .bpmn files."""
    # Create a temporary directory using pytest's tmp_path fixture
    bpmn_dir = tmp_path / "bpmn"
    bpmn_dir.mkdir()

    # Create a test file
    file_path = bpmn_dir / "sensor_data.bpmn"
    file_path.write_text(sample_bpmn)

    results = list_processes(str(bpmn_dir))

    assert len(results) == 1
    assert results[0].fileName == "sensor_data.bpmn"
    assert results[0].processId == "Process_Test_123"

def test_missing_process_element_raises_error():
    """Ensure a ValueError is raised if the process tag is missing."""
    invalid_xml = "<bpmn:definitions xmlns:bpmn='http://www.omg.org/spec/BPMN/20100524/MODEL'></bpmn:definitions>"
    with pytest.raises(ValueError, match="No bpmn:process found"):
        get_process_data(invalid_xml, "bad_file.bpmn")