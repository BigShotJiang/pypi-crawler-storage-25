import os
from unittest import mock
import respx
from httpx import Response
import pytest
from datetime import datetime
from src.bpmn_reporting.api import register_process, heartbeat_process, register, heartbeat
from src.bpmn_reporting.bpmn_parser import ProcessData


@pytest.fixture
def mock_data():
    return ProcessData(
        processId="Process_04x10xy",
        fileName="wind_anomaly.bpmn",
        processDiagram="<xml/>",
        processVersion="1.0",
        boundedContext="wind-anomaly",
        retentionTime="7",
        eventTime=datetime(2026, 4, 15, 12, 0, 0)
    )


@pytest.mark.asyncio
@respx.mock
async def test_register_process_success(mock_data):
    os.environ["REPORTING_SERVER"] = "http://mock-server"

    expected_data = {"status": "created", "id": "123"}

    route = respx.post(f"{os.environ['REPORTING_SERVER']}/reporting-service/rest/api/definition").mock(
        return_value=Response(200, json=expected_data)
    )

    result = await register_process(mock_data)

    assert result == expected_data

    assert route.called


@pytest.mark.asyncio
@respx.mock
async def test_heartbeat_process_success(mock_data):
    os.environ["REPORTING_SERVER"] = "http://mock-server"

    expected_data = {"status": "created", "id": "123"}

    route = respx.post(f"{os.environ['REPORTING_SERVER']}/reporting-service/rest/api/definition/heart-beat").mock(
        return_value=Response(200, json=expected_data)
    )

    result = await heartbeat_process(mock_data)

    assert result == expected_data

    assert route.called


@pytest.mark.asyncio
@respx.mock
async def test_register_folder_success(tmp_path):
    os.environ["REPORTING_SERVER"] = "http://mock-server"
    bpmn_dir = tmp_path / "bpmn"
    bpmn_dir.mkdir()

    expected_data = {"status": "created", "id": "123"}

    route = respx.post(url=f"{os.environ['REPORTING_SERVER']}/reporting-service/rest/api/definition").mock(
        return_value=Response(200, json=expected_data))

    with mock.patch("src.bpmn_reporting.api.list_processes") as mock_list:
        m1 = mock.MagicMock()
        m1.fileName = "one.bpmn"
        m1.processId = "1"
        m1.processVersion = "1.0"
        m1.boundedContext = "ctx"
        m1.retentionTime = "7"
        m1.processDiagram = "<xml/>"
        m1.eventTime.isoformat.return_value = "2026-01-01"

        mock_list.return_value = [m1]

        # When
        results = await register(str(bpmn_dir))

        # Then
        assert results[0] == expected_data
        assert route.call_count == 1


@pytest.mark.asyncio
@respx.mock
async def test_heartbeat_folder_success(tmp_path):
    os.environ["REPORTING_SERVER"] = "http://mock-server"
    bpmn_dir = tmp_path / "bpmn"
    bpmn_dir.mkdir()

    expected_data = {"status": "created", "id": "123"}

    route = respx.post(url=f"{os.environ['REPORTING_SERVER']}/reporting-service/rest/api/definition/heart-beat").mock(
        return_value=Response(200, json=expected_data))

    with mock.patch("src.bpmn_reporting.api.list_processes") as mock_list:
        m1 = mock.MagicMock()
        m1.fileName = "one.bpmn"
        m1.processId = "1"
        m1.processVersion = "1.0"
        m1.boundedContext = "ctx"
        m1.retentionTime = "7"
        m1.processDiagram = "<xml/>"
        m1.eventTime.isoformat.return_value = "2026-01-01"

        mock_list.return_value = [m1]

        # When
        results = await heartbeat(str(bpmn_dir))

        # Then
        assert results[0] == expected_data
        assert route.call_count == 1
