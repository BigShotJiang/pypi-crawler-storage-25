import pytest
from src.bpmn_reporting.utils import _serialize_payload, mask_password, mask_binary


def test_serialize_none():
    assert _serialize_payload(None) is None

def test_serialize_string():
    assert _serialize_payload("hello") == "hello"

def test_serialize_payload():
    assert _serialize_payload({"a": 1}) == '{"a": 1}'

def test_serialize_payload_with_static():
    mask_static = {"secret": "****"}
    payload_static = {"user": "bob", "secret": "1234"}
    assert _serialize_payload(payload_static, mask_static) == '{"user": "bob", "secret": "****"}'

def test_serialize_payload_with_func():
    mask = {"age": lambda v: "adult" if v >= 18 else "minor"}
    payload = {"name": "Alice", "age": 25}
    assert _serialize_payload(payload, mask) == '{"name": "Alice", "age": "adult"}'

def test_serialize_payload_with_nested():
    mask = {"id": "X"}
    payload = {"order": {"id": 99, "total": 50}}
    assert _serialize_payload(payload, mask) == '{"order": {"id": "X", "total": 50}}'

def test_serialize_payload_with_remove():
    mask = {"x": None}
    payload = {"a": 1, "x": "secret"}
    assert _serialize_payload(payload, mask) == '{"a": 1}'

def test_serialize_payload_with_template():
    mask = {"summary": "User {{user}} has ID {{id}}"}
    payload = {"user": "mario", "id": 123, "summary": "original"}
    assert _serialize_payload(payload, mask) == '{"user": "mario", "id": 123, "summary": "User mario has ID 123"}'

def test_mask_password_none():
    assert mask_password(None) is None

def test_mask_password_empty():
    assert mask_password("") == "*****"

def test_mask_password():
    assert mask_password("secret") == "*****"

def test_mask_binary_none():
    assert mask_binary(None) is None

def test_mask_binary_empty():
    assert mask_binary([]) == "bytes [0]"

def test_mask_binary():
    assert mask_binary([1, 2, 3]) == "bytes [3]"