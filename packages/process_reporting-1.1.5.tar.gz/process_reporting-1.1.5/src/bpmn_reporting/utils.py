import inspect
from typing import Optional, Any, Callable, Union, Dict
import pystache
import uuid
import os
import httpx
import logging
from datetime import datetime, timezone
from dataclasses import asdict
import json
from typing import Any, Optional, Sized

import logging

from .models import ReportEvent, BpmnElementOptions, ReportStatus

logging.getLogger("httpx").setLevel(logging.WARNING)

http_client = httpx.AsyncClient()


def _get_payload(func, args, kwargs):
    sig = inspect.signature(func)
    bound_args = sig.bind(*args, **kwargs)
    bound_args.apply_defaults()

    return bound_args.arguments


async def _publish_event(event: ReportEvent, options: BpmnElementOptions):
    event.elementId = options.id

    if options.process_id:
        event.processId = options.process_id

    event.startEvent = options.start_event is True
    event.endEvent = options.end_event is True

    event.executionId = str(uuid.uuid4())

    if event.startEvent:
        event.referenceType = os.environ.get("REPORTING_EVENT_CATEGORY")

    elif event.endEvent and event.status == ReportStatus.COMPLETED:
        event.status = ReportStatus.PROCESS_COMPLETED

    if event.transactionId:
        parent_transaction_id = event.transactionId.split(':')[0]
        event.transactionId = parent_transaction_id

    return await fire_event(event)


async def fire_event(event: ReportEvent):
    base_url = os.environ.get("REPORTING_SERVER", "")
    url = f"{base_url}/reporting-service/rest/api/report"

    if not event.processId:
        event.processId = os.environ.get("REPORTING_PROCESS_ID", "")

    # Set metadata and defaults
    event.eventTime = datetime.now().isoformat()
    event.processVersion = os.environ.get("REPORTING_PROCESS_VERSION", "1.0")
    event.startedBy = event.startedBy or 'system'

    # Optional debug logging
    if os.environ.get("REPORTING_PROCESS_DEBUG") == 'true':
        print(f"[DEBUG] Event: {event}")
        return None

    # Prepare JSON payload (stripping None values)
    payload = {k: v for k, v in asdict(event).items() if v is not None}

    # Asynchronous POST request using httpx
    try:
        response = await http_client.post(url, json=payload)
        response.raise_for_status()
        return response.json()
    except Exception as e:

        logging.error(
            f"Unable to post Process Event [{event.processId}/{event.elementId}] [{url}] Error: {e}"
        )
        return None


def _parse_expression(expression: Union[str, Callable, None], payload: Any) -> Optional[str]:
    if not expression or payload is None:
        return None

    # Handle Array/List context
    context = payload
    if isinstance(payload, list):
        context = {"items": payload}

    if callable(expression):
        return expression(context)

    if isinstance(expression, str):
        return pystache.render(expression, context)

    return None


import json


def _serialize_payload(payload: Any, mask_properties: dict = None):
    if not payload:
        return payload

    if isinstance(payload, str):
        return payload

    if not mask_properties:
        return json.dumps(payload)

    context = payload

    def replacer(data):
        if isinstance(data, dict):
            new_dict = {}
            for k, v in data.items():
                if k in mask_properties:
                    mask = mask_properties[k]

                    if mask is None:
                        continue

                    if callable(mask):
                        new_dict[k] = mask(v)
                    elif isinstance(mask, str):
                        new_dict[k] = pystache.render(mask, context)
                    else:
                        new_dict[k] = mask
                else:
                    new_dict[k] = replacer(v)
            return new_dict
        elif isinstance(data, list):
            return [replacer(i) for i in data]
        return data

    return json.dumps(replacer(payload))


def mask_password(pwd: Optional[str]) -> Optional[str]:
    return '*****' if pwd is not None else None


def mask_binary(binary: Optional[Sized]) -> Any:
    if binary is not None:
        return f"bytes [{len(binary)}]"
    return binary
