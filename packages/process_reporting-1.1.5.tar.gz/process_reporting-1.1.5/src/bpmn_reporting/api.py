import os
import httpx
import asyncio
from datetime import datetime
from typing import Optional
from .bpmn_parser import ProcessData, list_processes

async def register(folder_path: Optional[str] = None):

    if folder_path is None:
        folder_path = os.path.join(os.getcwd(), 'bpmn')

    process_list = list_processes(folder_path)

    tasks = [register_process(data) for data in process_list]

    return await asyncio.gather(*tasks)

async def register_process(data: ProcessData):

    server_url = os.getenv('REPORTING_SERVER')
    if not server_url:
        print("Error: REPORTING_SERVER environment variable is not set.")
        raise EnvironmentError("REPORTING_SERVER environment variable is not set.")

    url = f"{server_url}/reporting-service/rest/api/definition"

    payload = {
        "processId": data.processId,
        "fileName": data.fileName,
        "processDiagram": data.processDiagram,
        "processVersion": data.processVersion,
        "boundedContext": data.boundedContext,
        "retentionTime": data.retentionTime,
        "eventTime": data.eventTime.isoformat()
    }

    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(url, json=payload)
            response.raise_for_status()
            print(f"Process [{data.fileName}] successfully registered.")
            return response.json()
        except httpx.HTTPStatusError as e:
            print(f"Unable to register Process! Status: {e.response.status_code}")
            raise e
        except Exception as e:
            print(f"Unable to register Process! Error: {e}")
            raise e

async def heartbeat(folder_path: Optional[str] = None):

    if folder_path is None:
        folder_path = os.path.join(os.getcwd(), 'bpmn')

    process_list = list_processes(folder_path)

    tasks = [heartbeat_process(data) for data in process_list]

    return await asyncio.gather(*tasks)

async def heartbeat_process(data: ProcessData):
    server_url = os.getenv('REPORTING_SERVER')
    if not server_url:
        print("Error: REPORTING_SERVER environment variable is not set.")
        raise EnvironmentError("REPORTING_SERVER environment variable is not set.")

    url = f"{server_url}/reporting-service/rest/api/definition/heart-beat"

    payload = {
        "processId": data.processId,
        "processVersion": data.processVersion,
        "eventTime": datetime.now().isoformat()
    }

    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(url, json=payload)
            response.raise_for_status()
            print(f"Heartbeat from process [{data.fileName}] successfully sent.")
            return response.json()
        except Exception as e:
            print(f"Unable to send a process heartbeat! Error: {e}")
            raise e
