import functools
import asyncio
from dataclasses import replace

from .models import BpmnElementOptions, ReportEvent, ReportStatus
from .utils import _get_payload, _parse_expression, _serialize_payload, _publish_event


def bpmn_element(**ops):
    options = BpmnElementOptions(**ops)

    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            tasks = []

            payload = _get_payload(func, args, kwargs)

            retry_count = 0
            multiple_instance_index = _parse_expression(options.multiple_instance, payload)
            instance_id = _parse_expression(options.instance_id_expression or '{{ item.metadata.instanceId }}', payload)
            started_by = _parse_expression(options.started_by_expression or '{{ item.metadata.startedBy }}', payload)
            reference_id = _parse_expression(options.key_expression, payload)

            event = ReportEvent(
                status=ReportStatus.STARTED,
                payload=_serialize_payload(payload, options.mask_params),
                transactionId=instance_id,
                referenceId=reference_id,
                multipleInstanceIndex=(multiple_instance_index or '0') + '.' + str(retry_count),
                startedBy=started_by
            )

            # Fire STARTED event
            task = asyncio.create_task(_publish_event(event, options))

            tasks.append(task)

            try:
                # Execute the original function
                if asyncio.iscoroutinefunction(func):
                    result = await func(*args, **kwargs)
                else:
                    result = func(*args, **kwargs)

                event = replace(event, status=ReportStatus.COMPLETED, payload=_serialize_payload(result, options.mask_params))

                # Fire COMPLETED event
                task = asyncio.create_task(_publish_event(event, options))

                tasks.append(task)

                return result

            except Exception as e:

                event = replace(event, status=ReportStatus.ERROR, payload=None, errorMessage=str(e))

                task = asyncio.create_task(_publish_event(event, options))

                tasks.append(task)

                raise

            finally:
                await asyncio.gather(*tasks)

        return wrapper

    return decorator
