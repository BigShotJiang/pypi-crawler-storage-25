import os
import xml.etree.ElementTree as ET
from datetime import datetime
from dataclasses import dataclass
from typing import List

@dataclass
class ProcessData:
    processId: str
    fileName: str
    processDiagram: str
    processVersion: str
    boundedContext: str
    retentionTime: str
    eventTime: datetime = datetime.now()

def list_processes(file_dir: str = './bpmn') -> List[ProcessData]:
    processes = []

    # Filter for .bpmn files
    files = [f for f in os.listdir(file_dir) if f.endswith('.bpmn')]

    for file_name in files:
        file_path = os.path.join(file_dir, file_name)
        with open(file_path, 'r', encoding='utf-8') as f:
            diagram = f.read()

        # Extract data and add to list
        data = get_process_data(diagram, file_name)
        processes.append(data)

    return processes

def get_process_data(process_diagram: str, file_name: str) -> ProcessData:
    # Environment fallbacks
    default_version = os.getenv('REPORTING_PROCESS_VERSION', '1.0')
    default_ttl = os.getenv('REPORTING_PROCESS_TTL', '7')

    # Define the namespaces from your XML
    ns = {
        'bpmn': 'http://www.omg.org/spec/BPMN/20100524/MODEL',
        'zeebe': 'http://camunda.org/schema/zeebe/1.0'
    }

    root = ET.fromstring(process_diagram)

    # 1. Find the process element
    # In your XML: <bpmn:process id="Process_04x10xy" ...>
    process_element = root.find('.//bpmn:process', ns)

    if process_element is None:
        raise ValueError(f"No bpmn:process found in {file_name}")

    process_id = process_element.get('id')

    # 2. Extract Version Tag (Zeebe specific)
    # <zeebe:versionTag value="1.0" />
    version_tag = process_element.find('.//zeebe:versionTag', ns)
    found_version = version_tag.get('value') if version_tag is not None else default_version

    # 3. Extract Zeebe Custom Properties
    # <zeebe:property name="foo" value="bar" />
    properties = {}
    for prop in process_element.findall('.//zeebe:property', ns):
        name = prop.get('name')
        value = prop.get('value')
        if name:
            properties[name] = value

    return ProcessData(
        processId=process_id,
        fileName=file_name,
        processDiagram=process_diagram,
        processVersion=properties.get('version', found_version),
        boundedContext=properties.get('bounded-context', file_name.replace('.bpmn', '').lower()),
        retentionTime=properties.get('retention-time', default_ttl),
        eventTime=datetime.now()
    )