"""Unit tests configuration module."""
