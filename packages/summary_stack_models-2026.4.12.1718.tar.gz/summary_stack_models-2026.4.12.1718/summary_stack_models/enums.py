"""Shared enumerations for Summary Stack."""

from enum import Enum


class SourceType(str, Enum):
    """Supported source types for content processing.

    These types are detected by SummaryStackConverter based on:
    - URL patterns (youtube, general web URLs)
    - File extensions (pdf, audio, video, etc.)
    - Content analysis (text vs markdown)
    """

    # Web sources
    URL = "url"
    YOUTUBE = "youtube"

    # Document formats
    PDF = "pdf"
    DOCUMENT = "document"  # docx, doc
    PRESENTATION = "presentation"  # pptx
    SPREADSHEET = "spreadsheet"  # xlsx, xls, csv
    NOTEBOOK = "notebook"  # ipynb
    EBOOK = "ebook"  # epub

    # Media formats
    AUDIO = "audio"  # mp3, wav, m4a, ogg, flac
    VIDEO = "video"  # mp4, avi, mov, mkv, webm
    IMAGE = "image"  # jpg, jpeg, png, gif, webp

    # Text formats
    TEXT = "text"  # txt
    MARKDOWN = "markdown"  # md
    DATA = "data"  # json, xml

    # Fallback
    UNKNOWN = "unknown"


class DocumentType(str, Enum):
    """Types of documents for specialized processing."""

    RESEARCH = "research"  # Papers, studies, academic content
    TECHNICAL = "technical"  # Documentation, specs, procedures
    BUSINESS = "business"  # Reports, strategies, metrics
    MARKETING = "marketing"  # Campaigns, positioning, audience insights
    GENERAL = "general"  # Default catch-all


class SubscriptionTier(str, Enum):
    """User subscription tiers for quota and feature access.

    These tiers determine:
    - Monthly generation limits
    - Allowed source types

    Note: BYOM (Bring Your Own Model) is a feature available to pro users,
    not a separate tier. Pro users can optionally provide their own API keys.
    """

    FREE = "free"  # Limited generations, basic source types only
    PRO = "pro"  # Unlimited generations, all source types, BYOM eligible


class CredentialType(str, Enum):
    """Credential type discriminator for flexible credential storage.

    Uses namespaced format: category.provider (e.g., 'ai.openai', 'integration.readwise')
    This allows flexible JSONB config/secrets per type without DB migrations.
    """

    # AI Providers (LLM/model providers)
    AI_OPENAI = "ai.openai"
    AI_ANTHROPIC = "ai.anthropic"
    AI_GOOGLE = "ai.google"
    AI_OPENROUTER = "ai.openrouter"
    AI_GROK = "ai.grok"
    AI_AZURE_FOUNDRY = "ai.azure-foundry"
    AI_AWS_BEDROCK = "ai.aws-bedrock"

    # Integrations (content sources, webhooks)
    INTEGRATION_READWISE = "integration.readwise"

    @classmethod
    def ai_types(cls) -> frozenset["CredentialType"]:
        """Return all AI provider credential types."""
        return frozenset(
            {
                cls.AI_OPENAI,
                cls.AI_ANTHROPIC,
                cls.AI_GOOGLE,
                cls.AI_OPENROUTER,
                cls.AI_GROK,
                cls.AI_AZURE_FOUNDRY,
                cls.AI_AWS_BEDROCK,
            }
        )

    @classmethod
    def integration_types(cls) -> frozenset["CredentialType"]:
        """Return all integration credential types."""
        return frozenset(
            {
                cls.INTEGRATION_READWISE,
            }
        )

    def is_ai_type(self) -> bool:
        """Check if this credential type is an AI provider."""
        return self in self.ai_types()

    def is_integration_type(self) -> bool:
        """Check if this credential type is an integration."""
        return self in self.integration_types()


# Human-readable display names for credential types
CREDENTIAL_TYPE_DISPLAY_NAMES: dict[CredentialType, str] = {
    CredentialType.AI_OPENAI: "OpenAI",
    CredentialType.AI_ANTHROPIC: "Anthropic",
    CredentialType.AI_GOOGLE: "Google AI",
    CredentialType.AI_OPENROUTER: "OpenRouter",
    CredentialType.AI_GROK: "xAI (Grok)",
    CredentialType.AI_AZURE_FOUNDRY: "Azure AI Foundry",
    CredentialType.AI_AWS_BEDROCK: "AWS Bedrock",
    CredentialType.INTEGRATION_READWISE: "Readwise Reader",
}


def is_ai_credential(credential_type: str) -> bool:
    """Check if a credential type string is an AI provider."""
    return credential_type.startswith("ai.")


def is_integration_credential(credential_type: str) -> bool:
    """Check if a credential type string is an integration."""
    return credential_type.startswith("integration.")


class Environment(str, Enum):
    """Valid deployment environments for API keys.

    Values match the database CHECK constraint exactly:
    ['local', 'dev', 'staging', 'prod']
    """

    LOCAL = "local"
    DEV = "dev"
    STAGING = "staging"
    PROD = "prod"

    @classmethod
    def normalize(cls, env: str) -> "Environment":
        """Normalize environment string to enum value.

        Handles common aliases like 'production' -> PROD, 'development' -> DEV.
        Defaults to LOCAL for unknown values.
        """
        env_lower = env.lower()
        if env_lower in ("production", "prod"):
            return cls.PROD
        if env_lower in ("development", "dev"):
            return cls.DEV
        if env_lower == "staging":
            return cls.STAGING
        return cls.LOCAL


class IntegrationStatus(str, Enum):
    """Integration connection status."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"
