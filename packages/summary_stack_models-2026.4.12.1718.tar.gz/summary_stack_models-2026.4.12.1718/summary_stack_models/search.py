"""List response models for Summary Stack."""

from pydantic import BaseModel

from .summary_stack_list_item import SummaryStackListItem


class StackListResponse(BaseModel):
    """Paginated list of stacks for GET /stacks."""

    items: list[SummaryStackListItem]
    total: int
    limit: int
    offset: int
