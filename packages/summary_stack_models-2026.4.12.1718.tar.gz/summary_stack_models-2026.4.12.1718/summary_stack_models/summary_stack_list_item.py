"""SummaryStack reference model with optional search context."""

from datetime import datetime

from pydantic import BaseModel, Field

from .enums import SourceType


class SummaryStackListItem(BaseModel):
    """SummaryStack reference with optional search context.

    Core fields are always present for display. Search fields (similarity,
    matching_chunks) are populated when returned from corpus search.
    Enhanced content fields provide richer context for LLM synthesis.
    """

    # Core identity (always present)
    summary_stack_id: str = Field(description="UUID identifier")
    title: str = Field(description="Document title")
    uri: str = Field(description="Original source URL or file path")
    source_type: SourceType = Field(description="Source type (url, pdf)")
    source_domain: str | None = Field(default=None, description="Domain for URLs")
    thumbnail_url: str | None = Field(default=None, description="Generated thumbnail URL")
    word_count: int | None = Field(default=None, description="Total word count")
    created_at: datetime = Field(description="Creation timestamp")

    # Content for display (truncated)
    summary: str = Field(description="Executive summary (first 200 chars)")

    # Enhanced content for LLM (populated by search)
    executive_summary_full: str | None = Field(default=None, description="Full executive summary prose")
    key_insights: list[str] = Field(default_factory=list, description="Key insights from executive summary bullets")

    # Search context (populated by corpus search)
    similarity: float | None = Field(default=None, description="Vector similarity score (0-1)")
    matching_chunks: list[str] = Field(default_factory=list, description="Relevant text chunks from vector search")
    search_source: str | None = Field(default=None, description="Search source: 'rag' for vector search, 'graph' for knowledge graph")
