"""Web citation model for research results."""

from pydantic import BaseModel, Field


class WebCitation(BaseModel):
    """A citation from web research."""

    url: str = Field(description="URL of the source")
    title: str = Field(description="Title of the source")
    snippet: str = Field(description="Relevant snippet from the source")
    source: str = Field(default="gpt_researcher", description="Source of the citation")


__all__ = ["WebCitation"]
