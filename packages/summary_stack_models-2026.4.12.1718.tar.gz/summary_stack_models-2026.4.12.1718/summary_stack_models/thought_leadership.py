"""Pydantic models for Thought Leadership feature."""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class ExplorationStatus(str, Enum):
    """Exploration workflow status."""

    IDEA = "idea"
    DRAFT = "draft"
    REVIEW = "review"
    PUBLISHED = "published"


# Valid status transitions
VALID_STATUS_TRANSITIONS: dict[ExplorationStatus, list[ExplorationStatus]] = {
    ExplorationStatus.IDEA: [ExplorationStatus.DRAFT],
    ExplorationStatus.DRAFT: [ExplorationStatus.REVIEW, ExplorationStatus.IDEA],
    ExplorationStatus.REVIEW: [ExplorationStatus.PUBLISHED, ExplorationStatus.DRAFT],
    ExplorationStatus.PUBLISHED: [ExplorationStatus.DRAFT],
}


def is_valid_status_transition(current: ExplorationStatus, new: ExplorationStatus) -> bool:
    """Check if a status transition is valid."""
    if current == new:
        return True
    return new in VALID_STATUS_TRANSITIONS.get(current, [])


# ============================================================================
# RESEARCH BRIEF MODELS
# ============================================================================


class Citation(BaseModel):
    """IEEE-format citation."""

    ieee_citation: str = Field(..., description="IEEE format citation string")
    url: str | None = Field(None, description="Source URL")
    accessed_at: str | None = Field(None, description="ISO date string when accessed")


class OutlineSection(BaseModel):
    """Research outline section."""

    section: str = Field(..., description="Section title")
    notes: str | None = Field(None, description="Section notes")


class ResearchBrief(BaseModel):
    """Research brief structure for exploration."""

    thesis: str | None = Field(None, description="Main argument/thesis statement")
    key_points: list[str] = Field(default_factory=list, description="Key points to cover")
    target_audience: str | None = Field(None, description="Who this is for")
    tone: str | None = Field(None, description="Writing tone: professional/conversational/technical")
    outline: list[OutlineSection] = Field(default_factory=list, description="Content outline")
    citations: list[Citation] = Field(default_factory=list, description="IEEE citations")
    freeform_notes: str | None = Field(None, description="Additional thoughts")


class ResearchBriefUpdate(BaseModel):
    """Partial update for research brief - all fields optional for merge."""

    thesis: str | None = None
    key_points: list[str] | None = None
    target_audience: str | None = None
    tone: str | None = None
    outline: list[OutlineSection] | None = None
    citations: list[Citation] | None = None
    freeform_notes: str | None = None


# ============================================================================
# THOUGHT LEADERSHIP ITEM MODELS
# ============================================================================


class ThoughtLeadershipItemCreate(BaseModel):
    """Request model for creating a thought leadership item."""

    title: str = Field(..., min_length=1, max_length=200, description="Topic title")
    description: str | None = Field(None, max_length=2000, description="Topic description")
    system_prompt: str | None = Field(None, description="Custom system prompt for AI assistant")


class ThoughtLeadershipItemUpdate(BaseModel):
    """Request model for updating a thought leadership item."""

    title: str | None = Field(None, min_length=1, max_length=200)
    description: str | None = Field(None, max_length=2000)
    conversation_summary: dict | None = Field(None, description="Auto-generated summary JSONB")
    system_prompt: str | None = Field(None, description="Custom system prompt for AI assistant")


class ThoughtLeadershipItemResponse(BaseModel):
    """Response model for thought leadership items."""

    id: str
    user_id: str
    title: str
    description: str | None
    conversation_summary: dict | None = None
    system_prompt: str | None = None
    created_at: datetime
    updated_at: datetime


# ============================================================================
# THOUGHT LEADERSHIP STACK MODELS
# ============================================================================


class ThoughtLeadershipStackCreate(BaseModel):
    """Request model for adding a stack to thought leadership item."""

    summary_stack_id: str = Field(..., description="UUID of the summary stack")


class ThoughtLeadershipStackResponse(BaseModel):
    """Response model for thought leadership stack association."""

    thought_leadership_id: str
    summary_stack_id: str
    added_at: datetime


# ============================================================================
# EXPLORATION MODELS
# ============================================================================


class ThoughtLeadershipExplorationCreate(BaseModel):
    """Request model for creating an exploration."""

    title: str = Field(..., min_length=1, max_length=200, description="Exploration title")
    output_type: str = Field(default="blog_post", description="Output format (MVP: blog_post only)")
    system_prompt: str | None = Field(None, description="Custom system prompt for AI assistant")


class ThoughtLeadershipExplorationUpdate(BaseModel):
    """Request model for updating an exploration."""

    title: str | None = Field(None, min_length=1, max_length=200)
    status: ExplorationStatus | None = None
    content: dict | None = Field(None, description="Structured content sections")
    content_markdown: str | None = Field(None, description="Rendered full markdown")
    system_prompt: str | None = Field(None, description="Custom system prompt for AI assistant")


class StatusHistoryEntry(BaseModel):
    """Single entry in status history."""

    status: str
    timestamp: str


class ThoughtLeadershipExplorationResponse(BaseModel):
    """Response model for explorations."""

    id: str
    user_id: str
    thought_leadership_id: str
    title: str
    output_type: str
    status: ExplorationStatus
    status_history: list[StatusHistoryEntry]
    research_brief: ResearchBrief | None = None
    content: dict | None = None
    content_markdown: str | None = None
    system_prompt: str | None = None
    created_at: datetime
    updated_at: datetime


# ============================================================================
# CONVERSATION JUNCTION MODELS
# ============================================================================


class ThoughtLeadershipConversationCreate(BaseModel):
    """Request model for linking conversation to thought leadership item."""

    conversation_id: str = Field(..., description="UUID of the conversation")


class ThoughtLeadershipConversationResponse(BaseModel):
    """Response model for thought leadership conversation link."""

    thought_leadership_id: str
    conversation_id: str
    user_id: str
    linked_at: datetime


class ThoughtLeadershipExplorationConversationResponse(BaseModel):
    """Response model for exploration conversation link."""

    thought_leadership_exploration_id: str
    conversation_id: str
    user_id: str
    linked_at: datetime
