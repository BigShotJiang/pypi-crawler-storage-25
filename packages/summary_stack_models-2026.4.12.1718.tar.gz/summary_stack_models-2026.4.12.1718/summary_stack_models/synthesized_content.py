"""SynthesizedContent model for LLM-generated narrative sections."""

from pydantic import BaseModel, Field


class SynthesizedContent(BaseModel):
    """LLM-generated narrative sections for content synthesis.

    Stage 5 output: expands executive summary into human-readable narrative prose.
    Used by progressive_summarization agent and downstream consumers like Obsidian.
    """

    overview: str = Field(description="2-3 paragraph narrative intro - what is this, why it matters")
    key_takeaways: str = Field(description="Actionable insights as flowing prose with implications")
    core_ideas: str = Field(description="Concepts as interconnected knowledge web")
    evidence_intro: str = Field(description="1-2 sentences introducing the excerpts section")
