"""Graph search models for knowledge graph entity results."""

from pydantic import BaseModel, Field

from .summary_stack_list_item import SummaryStackListItem


class GraphEntity(BaseModel):
    """An entity (person, company, concept, etc.) found in the knowledge graph."""

    name: str = Field(description="Entity name (e.g., 'Apple Inc', 'Tim Cook')")
    summary: str | None = Field(default=None, description="AI-generated entity summary")
    labels: list[str] = Field(
        default_factory=list,
        description="Entity classifications (e.g., ['Person', 'Executive', 'BoardMember'])",
    )


class GraphSearchResult(BaseModel):
    """A graph entity and the SummaryStack sources that mention it."""

    entity: GraphEntity
    related_stacks: list[SummaryStackListItem] = Field(
        default_factory=list,
        description="SummaryStack items that mention this entity (hydrated)",
    )
