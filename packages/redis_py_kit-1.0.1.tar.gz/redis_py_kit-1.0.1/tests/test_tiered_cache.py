import fakeredis
import fakeredis.aioredis
import pytest

from redis_kit.cache.async_cache import AsyncCache
from redis_kit.cache.async_tiered import AsyncTieredCache
from redis_kit.cache.cache import Cache
from redis_kit.cache.tiered import TieredCache


class TestTieredCacheGet:
    def setup_method(self):
        self.client = fakeredis.FakeRedis(decode_responses=False)
        self.l2 = Cache(self.client, prefix="test", ttl_jitter=0)

    def teardown_method(self):
        self.client.flushall()
        self.client.close()

    def _make(self, **kwargs):
        return TieredCache(self.l2, local_maxsize=100, local_ttl=60, **kwargs)

    def test_get_from_l2_backfills_l1(self):
        cache = self._make()
        self.l2.set("user:1", {"name": "Alice"})
        # First get: L1 miss, L2 hit, backfill L1
        assert cache.get("user:1") == {"name": "Alice"}
        # Second get: L1 hit
        assert cache.get("user:1") == {"name": "Alice"}
        assert cache.local_size == 1

    def test_get_nonexistent_returns_none(self):
        cache = self._make()
        assert cache.get("nonexistent") is None

    def test_negative_cache(self):
        cache = self._make(negative_ttl=60)
        # First miss writes negative marker
        assert cache.get("missing") is None
        assert cache.local_size == 1
        # Now add to L2, but L1 negative cache prevents L2 lookup
        self.l2.set("missing", "found")
        assert cache.get("missing") is None  # Still negative cached

    def test_l1_hit_skips_l2(self):
        cache = self._make()
        cache.set("key", "value", ttl=3600)
        # Delete from L2 directly
        self.l2.delete("key")
        # L1 still has it
        assert cache.get("key") == "value"

    def test_get_cached_none_value_not_treated_as_miss(self):
        """Cached None in L2 must be returned as None, not trigger negative caching."""
        cache = self._make(negative_ttl=60)
        self.l2.set("key", None)
        # First get: L1 miss, L2 hit (value is None)
        assert cache.get("key") is None
        # L1 should have the actual None value, not a negative marker
        # Proof: deleting from L2 must still return None (served from L1)
        self.l2.delete("key")
        assert cache.get("key") is None
        # And L2 must NOT be re-queried as a miss (no negative backfill either)
        assert cache.local_size == 1


class TestTieredCacheSet:
    def setup_method(self):
        self.client = fakeredis.FakeRedis(decode_responses=False)
        self.l2 = Cache(self.client, prefix="test", ttl_jitter=0)

    def teardown_method(self):
        self.client.flushall()
        self.client.close()

    def _make(self, **kwargs):
        return TieredCache(self.l2, local_maxsize=100, local_ttl=60, **kwargs)

    def test_set_writes_both_layers(self):
        cache = self._make()
        cache.set("key", "value", ttl=3600)
        assert cache.get("key") == "value"  # L1
        assert self.l2.get("key") == "value"  # L2

    def test_delete_removes_both_layers(self):
        cache = self._make()
        cache.set("key", "value")
        cache.delete("key")
        assert cache.get("key") is None
        assert self.l2.get("key") is None


class TestTieredCacheRemember:
    def setup_method(self):
        self.client = fakeredis.FakeRedis(decode_responses=False)
        self.l2 = Cache(self.client, prefix="test", ttl_jitter=0)

    def teardown_method(self):
        self.client.flushall()
        self.client.close()

    def _make(self, **kwargs):
        return TieredCache(self.l2, local_maxsize=100, local_ttl=60, **kwargs)

    def test_remember_cache_miss(self):
        cache = self._make()
        call_count = 0

        def factory():
            nonlocal call_count
            call_count += 1
            return {"name": "Alice"}

        result = cache.remember("user:1", factory, ttl=3600)
        assert result == {"name": "Alice"}
        assert call_count == 1
        # Second call: L1 hit
        result = cache.remember("user:1", factory, ttl=3600)
        assert result == {"name": "Alice"}
        assert call_count == 1

    def test_remember_l2_hit(self):
        cache = self._make()
        self.l2.set("user:1", {"name": "Bob"})
        call_count = 0

        def factory():
            nonlocal call_count
            call_count += 1
            return {"name": "Alice"}

        result = cache.remember("user:1", factory, ttl=3600)
        assert result == {"name": "Bob"}
        assert call_count == 0

    def test_remember_cached_none_skips_factory(self):
        """remember() must return cached None from L2 without calling factory."""
        cache = self._make()
        self.l2.set("key", None)
        call_count = 0

        def factory():
            nonlocal call_count
            call_count += 1
            return "should-not-be-called"

        result = cache.remember("key", factory, ttl=3600)
        assert result is None
        assert call_count == 0


class TestTieredCacheBatch:
    def setup_method(self):
        self.client = fakeredis.FakeRedis(decode_responses=False)
        self.l2 = Cache(self.client, prefix="test", ttl_jitter=0)

    def teardown_method(self):
        self.client.flushall()
        self.client.close()

    def _make(self, **kwargs):
        return TieredCache(self.l2, local_maxsize=100, local_ttl=60, **kwargs)

    def test_get_many_mixed(self):
        cache = self._make()
        cache.set("a", 1)  # In both L1 and L2
        self.l2.set("b", 2)  # Only in L2
        result = cache.get_many(["a", "b", "c"])
        assert result == {"a": 1, "b": 2, "c": None}
        # b should now be in L1
        assert cache.local_size == 3  # a + b + c (c is negative cached)

    def test_set_many(self):
        cache = self._make()
        cache.set_many({"a": 1, "b": 2}, ttl=3600)
        assert cache.get("a") == 1
        assert cache.get("b") == 2
        assert self.l2.get("a") == 1
        assert self.l2.get("b") == 2

    def test_get_many_preserves_cached_none(self):
        """get_many should correctly backfill L1 with None (not _NEGATIVE) for cached None values."""
        cache = self._make()
        cache.set("null_key", None, ttl=60)
        cache.clear_local()
        result = cache.get_many(["null_key"])
        assert result["null_key"] is None
        # A subsequent single get() should also return None correctly
        val = cache.get("null_key")
        assert val is None


class TestTieredCacheLocalManagement:
    def setup_method(self):
        self.client = fakeredis.FakeRedis(decode_responses=False)
        self.l2 = Cache(self.client, prefix="test", ttl_jitter=0)

    def teardown_method(self):
        self.client.flushall()
        self.client.close()

    def _make(self, **kwargs):
        return TieredCache(self.l2, local_maxsize=100, local_ttl=60, **kwargs)

    def test_invalidate_local(self):
        cache = self._make()
        cache.set("key", "value")
        cache.invalidate_local("key")
        # L1 cleared, but L2 still has it
        assert self.l2.get("key") == "value"
        # Next get will go to L2 and backfill
        assert cache.get("key") == "value"

    def test_clear_local(self):
        cache = self._make()
        cache.set("a", 1)
        cache.set("b", 2)
        cache.clear_local()
        assert cache.local_size == 0

    def test_local_size(self):
        cache = self._make()
        assert cache.local_size == 0
        cache.set("a", 1)
        assert cache.local_size == 1


class TestAsyncTieredCache:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.client = fakeredis.aioredis.FakeRedis(decode_responses=False)
        self.l2 = AsyncCache(self.client, prefix="test", ttl_jitter=0)
        yield

    def _make(self, **kwargs):
        return AsyncTieredCache(self.l2, local_maxsize=100, local_ttl=60, **kwargs)

    @pytest.mark.asyncio
    async def test_get_backfills_l1(self):
        cache = self._make()
        await self.l2.set("key", "value")
        assert await cache.get("key") == "value"
        assert cache.local_size == 1

    @pytest.mark.asyncio
    async def test_set_writes_both(self):
        cache = self._make()
        await cache.set("key", "value", ttl=3600)
        assert await cache.get("key") == "value"
        assert await self.l2.get("key") == "value"

    @pytest.mark.asyncio
    async def test_delete(self):
        cache = self._make()
        await cache.set("key", "value")
        await cache.delete("key")
        assert await cache.get("key") is None

    @pytest.mark.asyncio
    async def test_negative_cache(self):
        cache = self._make(negative_ttl=60)
        assert await cache.get("missing") is None
        await self.l2.set("missing", "found")
        assert await cache.get("missing") is None  # Negative cached

    @pytest.mark.asyncio
    async def test_get_cached_none_value_not_treated_as_miss(self):
        """Cached None in L2 must be returned as None, not trigger negative caching."""
        cache = self._make(negative_ttl=60)
        await self.l2.set("key", None)
        assert await cache.get("key") is None
        # L1 should hold the None value; deleting from L2 still returns None
        await self.l2.delete("key")
        assert await cache.get("key") is None
        assert cache.local_size == 1


class TestAsyncTieredCacheFull:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.client = fakeredis.aioredis.FakeRedis(decode_responses=False)
        self.l2 = AsyncCache(self.client, prefix="test", ttl_jitter=0)
        yield

    def _make(self, **kwargs):
        return AsyncTieredCache(self.l2, local_maxsize=100, local_ttl=60, **kwargs)

    @pytest.mark.asyncio
    async def test_get_many(self):
        cache = self._make()
        await cache.set("a", 1)
        await self.l2.set("b", 2)
        result = await cache.get_many(["a", "b", "c"])
        assert result["a"] == 1
        assert result["b"] == 2
        assert result["c"] is None

    @pytest.mark.asyncio
    async def test_set_many(self):
        cache = self._make()
        await cache.set_many({"x": 10, "y": 20}, ttl=3600)
        assert await cache.get("x") == 10
        assert await cache.get("y") == 20

    @pytest.mark.asyncio
    async def test_remember(self):
        cache = self._make()
        result = await cache.remember("key", lambda: {"v": 1}, ttl=3600)
        assert result == {"v": 1}
        result2 = await cache.remember("key", lambda: {"v": 2}, ttl=3600)
        assert result2 == {"v": 1}

    @pytest.mark.asyncio
    async def test_remember_cached_none_skips_factory(self):
        """remember() must return cached None from L2 without calling factory."""
        cache = self._make()
        await self.l2.set("key", None)
        call_count = 0

        def factory():
            nonlocal call_count
            call_count += 1
            return "should-not-be-called"

        result = await cache.remember("key", factory, ttl=3600)
        assert result is None
        assert call_count == 0

    @pytest.mark.asyncio
    async def test_local_management(self):
        cache = self._make()
        await cache.set("key", "val")
        assert cache.local_size == 1
        cache.invalidate_local("key")
        assert cache.local_size == 0
        cache.clear_local()
