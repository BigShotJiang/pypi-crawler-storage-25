# redis-py-kit

**Enterprise-grade Python Redis toolkit with sync/async dual-mode API.**

[![PyPI](https://img.shields.io/pypi/v/redis-py-kit.svg)](https://pypi.org/project/redis-py-kit/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Status](https://img.shields.io/badge/status-Production%2FStable-brightgreen.svg)](https://pypi.org/project/redis-py-kit/)

## Features

| Module | Description |
|--------|-------------|
| [Cache](modules/cache.md) | Get/Set/Delete, TTL, batch operations, `@cached` decorator, TTL jitter |
| [Tiered Cache](modules/tiered-cache.md) | L1 local LRU + L2 Redis, read-through, negative caching |
| [Distributed Lock](modules/lock.md) | Basic lock, reentrant lock, read-write lock, watchdog auto-renewal |
| [Message Queue](modules/queue.md) | PubSub, DelayQueue, ReliableQueue |
| [Streams](modules/streams.md) | Consumer groups, auto/manual ACK, dead-letter recovery |
| [Bloom Filter](modules/bloom.md) | SHA-256 multi-hash, pipeline bit operations |
| [Counter](modules/counter.md) | Atomic INCR/DECR, BoundCounter, ID generator |
| [Session](modules/session.md) | Redis Hash session store, CRUD, TTL refresh |
| [Rate Limiter](modules/ratelimit.md) | Token bucket, sliding window, `@rate_limit` decorator |
| [Repository](modules/repository.md) | Dataclass entity storage, versioning, soft delete, audit, history |
| [Observability](modules/observability.md) | MetricsCollector, OpenTelemetry integration |

## Quick Install

```bash
pip install redis-py-kit
```

## Quick Example

```python
from redis_kit import ConnectionManager, Cache

conn = ConnectionManager(url="redis://localhost:6379/0")
cache = Cache(conn.sync_client, prefix="myapp:cache")

cache.set("user:1", {"name": "Alice"}, ttl="2h30m")
user = cache.get("user:1")
```
