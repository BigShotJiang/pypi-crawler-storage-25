from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

from redis_kit.ratelimit._lua import SLIDING_WINDOW_SCRIPT
from redis_kit.ratelimit._result import RateLimitResult

if TYPE_CHECKING:
    import redis.asyncio


class AsyncSlidingWindowLimiter:
    """Async sliding window rate limiter backed by Redis Sorted Set + Lua script."""

    def __init__(
        self,
        client: redis.asyncio.Redis,
        prefix: str = "redis_kit:rl:sw",
        limit: int = 100,
        window: int = 60,
    ) -> None:
        self._client = client
        self._prefix = prefix
        self._limit = limit
        self._window = window
        self._script = self._client.register_script(SLIDING_WINDOW_SCRIPT)

    def _make_key(self, key: str) -> str:
        return f"{self._prefix}:{key}"

    async def acquire(self, key: str) -> RateLimitResult:
        full_key = self._make_key(key)
        member = uuid.uuid4().hex
        window_ms = self._window * 1000
        ttl_ms = window_ms + 1000

        result = await self._script(
            keys=[full_key],
            args=[self._limit, window_ms, member, ttl_ms],
        )
        return RateLimitResult(
            allowed=bool(result[0]),
            limit=int(result[1]),
            remaining=int(result[2]),
            retry_after=int(result[3]) / 1000.0,
            reset_at=int(result[4]) / 1000.0,
        )

    async def reset(self, key: str) -> None:
        await self._client.delete(self._make_key(key))
