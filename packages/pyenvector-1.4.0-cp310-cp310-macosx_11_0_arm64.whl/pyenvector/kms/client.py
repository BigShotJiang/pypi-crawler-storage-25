# ========================================================================================
#  Copyright (C) 2025 CryptoLab Inc. All rights reserved.
#
#  This software is proprietary and confidential.
#  Unauthorized use, modification, reproduction, or redistribution is strictly prohibited.
#
#  Commercial use is permitted only under a separate, signed agreement with CryptoLab Inc.
#
#  For licensing inquiries or permission requests, please contact: pypi@cryptolab.co.kr
# ========================================================================================

"""gRPC client for enVector Key Management Services.

Wraps the managed KMS gateway behind a single ``KMSClient`` facade.
The gRPC channel is created lazily on first use and can be closed via
:meth:`close`.
"""

import secrets
import time
from typing import Dict, List, Optional

import grpc

from pyenvector.api.connection import Connection
from pyenvector.errors import EnvectorTransportError, KeyManagementError
from pyenvector.proto_gen.v2.common import common_message_pb2 as common_pb2
from pyenvector.proto_gen.v2.common import type_pb2
from pyenvector.proto_gen.v2.kms import kms_api_pb2 as kms_pb2
from pyenvector.proto_gen.v2.kms import kms_api_pb2_grpc as kms_grpc
from pyenvector.proto_gen.v2.kms import kms_message_pb2 as kms_msg_pb2
from pyenvector.utils.logging_config import logger


def _make_request_header():
    """Build a minimal ES2 RequestHeader for KMS RPCs."""
    return common_pb2.RequestHeader(
        id=secrets.token_hex(8),
        timestamp=int(time.time()),
    )


def _check_response(response, rpc_name: str):
    """Raise on non-Success return_code inside an ES2.ResponseHeader."""
    header = response.header
    rc = header.return_code
    # ReturnCode.Success == 1 in the proto enum.
    if rc != type_pb2.Success:
        err_msg = header.error_message if header.HasField("error_message") else ""
        raise KeyManagementError(
            f"KMS {rpc_name} failed (return_code={rc}): {err_msg}",
            return_code=rc,
        )


class KMSClient:
    """Client for the managed enVector KMS gateway.

    All gRPC services are accessed through a single gateway address.

    Parameters
    ----------
    address : str
        ``host:port`` of the KMS API Gateway (gRPC).
    secure : bool, optional
        Use TLS channels. Defaults to ``False``.
    """

    def __init__(
        self,
        address: str,
        secure: bool = False,
        access_token: Optional[str] = None,
    ):
        self._address = address
        self._secure = secure
        self._access_token = access_token

        self._conn: Optional[Connection] = None
        self._keygen_stub: Optional[kms_grpc.KeyManagerServiceStub] = None
        self._topk_stub: Optional[kms_grpc.TopKServiceStub] = None
        self._grpc_metadata = []
        if self._access_token:
            self._grpc_metadata.append(("authorization", f"Bearer {self._access_token}"))

    # ------------------------------------------------------------------
    # Connection (single gateway)
    # ------------------------------------------------------------------

    def _ensure_connected(self):
        if self._conn is None:
            self._conn = Connection(self._address, secure=self._secure)
            if not self._conn.is_connected():
                raise EnvectorTransportError(f"Cannot connect to KMS at {self._address}")
            channel = self._conn.get_channel()
            self._keygen_stub = kms_grpc.KeyManagerServiceStub(channel)
            self._topk_stub = kms_grpc.TopKServiceStub(channel)
            logger.debug("Connected to KMS at %s", self._address)

    def _ensure_keygen(self):
        try:
            self._ensure_connected()
        except EnvectorTransportError as exc:
            raise EnvectorTransportError(f"Cannot connect to KeyManagerService at {self._address}") from exc

    def _ensure_topk(self):
        try:
            self._ensure_connected()
        except EnvectorTransportError as exc:
            raise EnvectorTransportError(f"Cannot connect to TopKService at {self._address}") from exc

    def _rpc_kwargs(self):
        if not self._grpc_metadata:
            return {}
        return {"metadata": self._grpc_metadata}

    # ------------------------------------------------------------------
    # KeyManagerService RPCs
    # ------------------------------------------------------------------

    def generate_key(
        self,
        key_id: str,
        metadata_encryption: Optional[bool] = None,
        preset: Optional[str] = None,
        eval_mode: Optional[str] = None,
    ) -> Dict[str, object]:
        """Generate the KMS-managed key bundle for ``key_id``."""
        self._ensure_keygen()
        request_kwargs = {
            "header": _make_request_header(),
            "key_id": key_id,
        }
        if metadata_encryption is not None:
            request_kwargs["metadata_encryption_enabled"] = metadata_encryption
        if preset is not None:
            request_kwargs["preset"] = preset
        if eval_mode is not None:
            request_kwargs["eval_mode"] = eval_mode
        request = kms_pb2.GenerateKeyRequest(**request_kwargs)
        try:
            response = self._keygen_stub.GenerateKey(request, **self._rpc_kwargs())
        except grpc.RpcError as exc:
            raise EnvectorTransportError(f"GenerateKey RPC failed: {exc}") from exc
        _check_response(response, "GenerateKey")
        return {
            "key_id": response.key_id,
            "version": response.version,
            "status": kms_msg_pb2.KeyGenStatus.Name(response.status),
        }

    def get_key_status(self, key_id: str) -> Dict[str, object]:
        """Poll the status of an async key generation job."""
        self._ensure_keygen()
        request = kms_pb2.GetKeyStatusRequest(
            header=_make_request_header(),
            key_id=key_id,
        )
        try:
            response = self._keygen_stub.GetKeyStatus(request, **self._rpc_kwargs())
        except grpc.RpcError as exc:
            raise EnvectorTransportError(f"GetKeyStatus RPC failed: {exc}") from exc
        _check_response(response, "GetKeyStatus")
        return {
            "key_id": response.key_id,
            "status": kms_msg_pb2.KeyGenStatus.Name(response.status),
        }

    def get_key_details(self, key_id: str) -> Dict[str, object]:
        """Return version metadata for ``key_id``.

        The response includes the version number, state, key type, and audit
        metadata for each stored version.
        """
        self._ensure_keygen()
        request = kms_pb2.GetKeyDetailsRequest(
            header=_make_request_header(),
            key_id=key_id,
        )
        try:
            response = self._keygen_stub.GetKeyDetails(request, **self._rpc_kwargs())
        except grpc.RpcError as exc:
            raise EnvectorTransportError(f"GetKeyDetails RPC failed: {exc}") from exc
        _check_response(response, "GetKeyDetails")
        return {
            "key_id": response.key_id,
            "versions": [
                {
                    "version": item.version,
                    "state": kms_msg_pb2.KeyState.Name(item.state),
                    "key_type": kms_msg_pb2.KeyType.Name(item.key_type),
                    "created_at": item.created_at,
                    "updated_at": item.updated_at,
                    "actor": item.actor,
                }
                for item in response.versions
            ],
        }

    def wait_for_key(
        self,
        key_id: str,
        timeout: float = 120,
        poll_interval: float = 1.0,
    ) -> Dict[str, object]:
        """Poll ``get_key_status`` until READY, FAILED, or timeout.

        Raises
        ------
        TimeoutError
            If the key does not reach a terminal state within ``timeout``.
        KeyManagementError
            If key generation reaches a FAILED state.
        """
        deadline = time.monotonic() + timeout
        while True:
            status = self.get_key_status(key_id)
            status_str = str(status.get("status", ""))
            if "READY" in status_str:
                return status
            if "FAILED" in status_str:
                raise KeyManagementError(f"Key generation failed for {key_id}: {status}")
            if time.monotonic() >= deadline:
                raise TimeoutError(f"Key {key_id} did not become ready within {timeout}s (last status: {status_str})")
            time.sleep(poll_interval)

    # ------------------------------------------------------------------
    # Key download
    # ------------------------------------------------------------------

    def download_enc_key(self, key_id: str) -> bytes:
        """Download the raw wrapped EncKey for ``key_id`` via KMS gRPC."""
        return self._download_key(key_id, kms_pb2.KEY_FILE_TYPE_ENC_KEY)

    def download_eval_key(self, key_id: str) -> bytes:
        """Download the raw wrapped EvalKey for ``key_id`` via KMS gRPC."""
        return self._download_key(key_id, kms_pb2.KEY_FILE_TYPE_EVAL_KEY)

    def _download_key(self, key_id: str, file_type: int) -> bytes:
        """Download a key file via server-streaming gRPC and reassemble its chunks."""
        self._ensure_keygen()
        request = kms_pb2.DownloadKeyRequest(
            header=_make_request_header(),
            key_id=key_id,
            file_type=file_type,
        )
        try:
            response_iter = self._keygen_stub.DownloadKey(request, **self._rpc_kwargs())
        except grpc.RpcError as exc:
            raise EnvectorTransportError(f"DownloadKey RPC failed: {exc}") from exc

        chunks: List[bytes] = []
        saw_response = False
        try:
            for response in response_iter:
                saw_response = True
                _check_response(response, "DownloadKey")
                if response.content:
                    chunks.append(response.content)
                if response.eof:
                    break
        except grpc.RpcError as exc:
            raise EnvectorTransportError(f"DownloadKey RPC failed: {exc}") from exc

        if not saw_response:
            return b""
        return b"".join(chunks)

    # ------------------------------------------------------------------
    # Metadata Encrypt/Decrypt RPCs (via TopKService)
    # ------------------------------------------------------------------

    def encrypt_metadata(
        self,
        key_id: str,
        plaintext_metadata: List[str],
    ) -> List[bytes]:
        """Encrypt plaintext metadata strings via KMS.

        The metadata key remains inside KMS. Clients send plaintext and
        receive ciphertext bytes.
        """
        self._ensure_topk()
        request = kms_pb2.EncryptMetadataRequest(
            header=_make_request_header(),
            key_id=key_id,
            plaintext_metadata=plaintext_metadata,
        )
        try:
            response = self._topk_stub.EncryptMetadata(request, **self._rpc_kwargs())
        except grpc.RpcError as exc:
            raise EnvectorTransportError(f"EncryptMetadata RPC failed: {exc}") from exc
        _check_response(response, "EncryptMetadata")
        return list(response.encrypted_metadata)

    def decrypt_metadata(
        self,
        key_id: str,
        encrypted_metadata: List[bytes],
    ) -> List[str]:
        """Decrypt metadata ciphertexts via KMS.

        The metadata key remains inside KMS. Clients send ciphertext and
        receive plaintext strings.
        """
        self._ensure_topk()
        request = kms_pb2.DecryptMetadataRequest(
            header=_make_request_header(),
            key_id=key_id,
            encrypted_metadata=encrypted_metadata,
        )
        try:
            response = self._topk_stub.DecryptMetadata(request, **self._rpc_kwargs())
        except grpc.RpcError as exc:
            raise EnvectorTransportError(f"DecryptMetadata RPC failed: {exc}") from exc
        _check_response(response, "DecryptMetadata")
        return list(response.plaintext_metadata)

    def topk(
        self,
        key_id: str,
        encrypted_scores: list,
        k: int,
        score_threshold: Optional[float] = None,
        shard_indices: Optional[List[int]] = None,
    ) -> List["kms_msg_pb2.TopKResult"]:
        """Decrypt encrypted scores via KMS and return ranked TopK results.

        ``shard_indices`` can be provided to restrict evaluation to a subset
        of shards when the caller already knows the search partition.
        """
        self._ensure_topk()
        kwargs = {
            "header": _make_request_header(),
            "key_id": key_id,
            "encrypted_scores": encrypted_scores,
            "k": k,
        }
        if score_threshold is not None:
            kwargs["score_threshold"] = score_threshold
        if shard_indices:
            kwargs["shard_indices"] = shard_indices
        request = kms_pb2.TopKRequest(**kwargs)
        try:
            response = self._topk_stub.TopK(request, **self._rpc_kwargs())
        except grpc.RpcError as exc:
            raise EnvectorTransportError(f"TopK RPC failed: {exc}") from exc
        _check_response(response, "TopK")
        return list(response.results)

    def transition_state(
        self,
        key_id: str,
        *,
        version: Optional[int] = None,
        new_state: int,
        reason: str,
    ):
        """Transition the latest key version to a new lifecycle state.

        .. note::
            ``version`` is reserved for future per-version targeting and is
            not yet supported. Passing a non-None value raises
            ``NotImplementedError``.
        """
        if version is not None:
            raise NotImplementedError(
                "Per-version state transition is not yet supported. "
                "Omit the version argument to transition the latest key version."
            )
        self._ensure_keygen()
        request = kms_pb2.TransitionStateRequest(
            header=_make_request_header(),
            key_id=key_id,
            new_state=new_state,
            reason=reason,
        )
        try:
            response = self._keygen_stub.TransitionState(request, **self._rpc_kwargs())
        except grpc.RpcError as exc:
            raise EnvectorTransportError(f"TransitionState RPC failed: {exc}") from exc
        _check_response(response, "TransitionState")
        return True

    def delete_key(self, key_id: str, reason: str):
        """Schedule a key for deletion via the managed gateway."""
        self._ensure_keygen()
        request = kms_pb2.DeleteRequest(
            header=_make_request_header(),
            key_id=key_id,
            reason=reason,
        )
        try:
            response = self._keygen_stub.Delete(request, **self._rpc_kwargs())
        except grpc.RpcError as exc:
            raise EnvectorTransportError(f"Delete RPC failed: {exc}") from exc
        _check_response(response, "Delete")
        return True

    # ------------------------------------------------------------------
    # Health checks
    # ------------------------------------------------------------------

    def health_check_keygen(self) -> bool:
        """Health check for KeyManagerService."""
        self._ensure_keygen()
        request = common_pb2.HeartbeatRequest(header=_make_request_header())
        try:
            response = self._keygen_stub.Health(request, **self._rpc_kwargs())
            return response.header.return_code == type_pb2.Success
        except grpc.RpcError:
            return False

    def health_check_topk(self) -> bool:
        """Health check for TopKService."""
        self._ensure_topk()
        request = common_pb2.HeartbeatRequest(header=_make_request_header())
        try:
            response = self._topk_stub.Health(request, **self._rpc_kwargs())
            return response.header.return_code == type_pb2.Success
        except grpc.RpcError:
            return False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self):
        """Close the gRPC channel."""
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
        self._conn = None
        self._keygen_stub = None
        self._topk_stub = None
        logger.debug("KMSClient connection closed")

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False
