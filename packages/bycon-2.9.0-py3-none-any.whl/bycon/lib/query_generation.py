import re
import humps

# ------------------------------- bycon imports -------------------------------#

from bycon_helpers import (
    ByconError,
    ByconH,
    ByconMongo,
    days_from_iso8601duration,
    prdbug,
    prjsonnice
)
from config import BYC, BYC_DBS, BYC_PARS
from genome_utils import ChroNames, Cytobands, GeneInfo, VariantTypes
from parameter_parsing import ByconFilters
from schema_parsing import RecordsHierarchy

################################################################################
################################################################################
################################################################################


class ByconQuery:
    """
    Bycon queries are collected as an object with per data collection query objects,
    ready to be run against the respective entity databases.
    The definition against per-collection in contrast to per-entity is due to the
    incongruency of collection use, e.g. the utilization of the "analyses" collection
    for both "analysis" and "run" entities.

    Query object:

    ```
    entity_queries:
        __entity__:
            query: { __query__ }
            collection: __collection__
        ...

    expand: True/False                          | Flag to terminate collection
                                                | of further query items, e.g.
                                                | after creating an id query

    ```
    """

    def __init__(self, dataset_id=False):
        self.response_types = BYC.get("entity_defaults", {})
        if dataset_id is False:
            self.ds_id = BYC["BYC_DATASET_IDS"][0]
        else:
            self.ds_id = dataset_id

        self.argument_definitions = BYC.get("argument_definitions", {}).get("$defs", {})
        self.cytoband_definitions = BYC.get("cytobands", [])
        self.ChroNames            = ChroNames()
        self.RecordsHierarchy     = RecordsHierarchy()

        self.requested_entity   = BYC.get("request_entity_id", False)
        self.response_entity    = BYC.get("response_entity", {})
        self.response_entity_id = BYC.get("response_entity_id", "")

        # TODO: call the variant type definition from inside this class since
        # e.g. multivars ... need this for each instance
        self.variant_request_type       = None
        self.variant_par_names          = []
        self.request_profiles           = BYC.get("request_profiles", {}).get("$defs", {})
        self.variant_type_definitions   = BYC.get("variant_type_definitions", {})
        self.VariantTypes               = VariantTypes()

        self.limit              = BYC_PARS.get("limit")
        self.skip               = BYC_PARS.get("skip")
        self.test_mode_count    = BYC_PARS.get("test_mode_count", 5)
        self.filters            = ByconFilters().get_filters()
        prdbug(f"ByconQuery self.filters: {self.filters}")

        self.queries    = {"expand": True, "entities": {}}
        self.id_queries = {}

        self.__set_variant_par_names()
        self.__queries_for_test_mode()
        self.__update_queries_from_id_values()
        self.__query_from_hoid()
        self.__query_from_variant_pars()
        self.__query_from_filters()
        self.__query_from_geoquery()


    # -------------------------------------------------------------------------#
    # ----------------------------- public ------------------------------------#
    # -------------------------------------------------------------------------#

    def recordsQuery(self):
        prdbug(f"...recordsQuery: {self.queries}")
        return self.queries


    # -------------------------------------------------------------------------#

    def variantsQuery(self):
        if len(q := self.queries.get("entities", {}).get("genomicVariant", {}).get("query", [])) < 1:
            return False
        if len(q) == 1:
            return q[0]
        return {"$and": q}


    # -------------------------------------------------------------------------#

    def analysesQuery(self):
        if len(q := self.queries.get("entities", {}).get("analysis", {}).get("query", [])) < 1:
            return False
        if len(q) == 1:
            return q[0]
        return {"$and": q}


    # -------------------------------------------------------------------------#

    def biosamplesQuery(self):
        if len(q := self.queries.get("entities", {}).get("biosample", {}).get("query", [])) < 1:
            return False
        if len(q) == 1:
            return q[0]
        return {"$and": q}


    # -------------------------------------------------------------------------#

    def individualsQuery(self):
        if len(q := self.queries.get("entities", {}).get("individual", {}).get("query", [])) < 1:
            return False
        if len(q) == 1:
            return q[0]
        return {"$and": q}


    # -------------------------------------------------------------------------#
    # ----------------------------- private -----------------------------------#
    # -------------------------------------------------------------------------#

    def __set_variant_par_names(self):
        for a_k, a_d in self.argument_definitions.items():
            if a_d.get("is_variant_par") or a_d.get("is_vqs_par"):
                self.variant_par_names.append(a_k)
            for u_id in self.RecordsHierarchy.upstream("GenomicVariant"):
                self.variant_par_names.append(u_id)


    # -------------------------------------------------------------------------#

    def __update_queries_from_id_values(self):
        if self.queries.get("expand") is False:
            return
        argdefs = self.argument_definitions
        for p_k, id_v_s in BYC_PARS.items():
            if not p_k.endswith("_ids"):
                continue
            if not (entity := argdefs[p_k].get("byc_entity")):
                continue
            q = False
            f_key = f"{entity}_id"

            if len(id_v_s) < 1:
                continue
            elif len(id_v_s) == 1:
                q_v = id_v_s[0]
            elif len(id_v_s) > 1:
                q_v =  {"$in": id_v_s}
            
            q = [{"id": q_v}]
            # if not "genomicVariant" in entity:
            self.id_queries.update({f_key: q_v})

            self.__update_queries_for_entity(q, entity)

        # BYC.update({"AGGREGATE_VARIANT_RESULTS": False})


    # -------------------------------------------------------------------------#

    def __queries_for_test_mode(self):
        if BYC["TEST_MODE"] is False:
            return
        if self.queries.get("expand") is False:
            return

        e = self.response_entity_id
        if (c := BYC_DBS.get("collections", {}).get(e, "___none___")) not in ByconMongo(self.ds_id).collectionList():
            return

        pipeline = [
            {"$sample": {"size": self.test_mode_count}},
            {"$project": {"_id": 0, "id": 1}}
        ]
        rs = ByconMongo(self.ds_id).resultListFromPipeline(c, pipeline)
        q = [{"id": {"$in": list(s.get("id", "___none___") for s in rs)}}]
        prdbug(f"... test mode query: {q}")

        self.queries["entities"].update(
            {self.response_entity_id: {"query": q, "collection": c}}
        )
        self.queries.update({"expand": False})


    # -------------------------------------------------------------------------#
    # -------------------------------------------------------------------------#
    # -------------------------------------------------------------------------#

    def __query_from_variant_pars(self):
        if self.queries.get("expand") is False:
            return
        self.variant_multi_pars = BYC_PARS.get("variant_multi_pars", [])

        e = "genomicVariant"
        if not (c := BYC_DBS.get("collections", {}).get(e)):
            return

        # new preprocessing which results in a list of variant queries
        self.__preprocess_variant_pars()
        if not (v_queries := self.__loop_multivars()):
            return

        self.queries["entities"].update({e: {"query": v_queries, "collection": c}})


    # -------------------------------------------------------------------------#

    def __preprocess_variant_pars(self):
        v_m_ps = BYC_PARS.get("variant_multi_pars", [])

        v_p_s = self.variant_par_names
        # standard pars
        s_q_p_0 = {}
        if v_s_s := v_p_s & BYC_PARS.keys():
            for v_p in v_s_s:
                s_q_p_0.update({v_p: BYC_PARS.get(v_p)})
        if len(s_q_p_0.keys()) > 0:
            v_m_ps.append(s_q_p_0)

        vips = []
        for v in v_m_ps:
            vp = {}

            if v_s_s := v_p_s & v.keys():
                for v_p in v_s_s:
                    vp.update({v_p: v.get(v_p)})
                if len(vp.keys()) > 0:
                    vips.append(self.__parse_variant_parameters(vp))

        self.variant_multi_pars = vips


    # -------------------------------------------------------------------------#

    def __parse_variant_parameters(self, variant_pars):
        # value checks
        v_p_c = {}
        pop_list = []
        for p_k, v_p in variant_pars.items():
            v_p_k = humps.decamelize(p_k)
            if "variant_type" in v_p_k:
                v_s_c = self.VariantTypes.variantStateChildren(v_p)
                v_p_c.update({v_p_k: {"$in": v_s_c}})
                continue
            if "reference_name" in v_p_k or "mate_name" in v_p_k:
                v_p_c.update({v_p_k: self.ChroNames.refseq(v_p)})
                continue

            # VQS - TODO (remapping to be transferred ...)
            if "reference_accession" in v_p_k:
                v_p_c.update({"reference_name": self.ChroNames.refseq(v_p)})
                pop_list.append(p_k)
                continue
            if "adjacency_accession" in v_p_k:
                v_p_c.update({"mate_name": self.ChroNames.refseq(v_p)})
                pop_list.append(p_k)
                continue
            if "breakpoint_range" in v_p_k:
                if len(v_p) == 1:
                    v_p.append(v_p[0] + 1)
                v_p_c.update({"start": [v_p[0]], "end": [v_p[1]]})
                pop_list.append(p_k)
                continue
            if "adjacency_range" in v_p_k:
                if len(v_p) == 1:
                    v_p.append(v_p[0] + 1)
                v_p_c.update({"mate_start": [v_p[0]], "mate_end": [v_p[1]]})
                pop_list.append(p_k)
                continue
            # VQS
            if "copy_change" in v_p_k:
                v_s_c = self.VariantTypes.variantStateChildren(v_p)
                v_p_c.update({"variant_type": {"$in": v_s_c}})
                pop_list.append(p_k)
                continue
            # VQS
            if "sequence_length" in v_p_k:
                if len(v_p) == 1:
                    v_p.append(v_p[0] + 1)
                v_p_c.update(
                    {"variant_min_length": v_p[0], "variant_max_length": v_p[1]}
                )
                pop_list.append(p_k)
                continue

            v_p_c.update({v_p_k: v_p})

        for p_l in pop_list:
            variant_pars.pop(p_l, None)

        return v_p_c


    # -------------------------------------------------------------------------#

    def __loop_multivars(self):

        # TODO: proper self.queries handling

        queries = []

        for v_pars in self.variant_multi_pars:
            if not (variant_request_type := self.__get_variant_request_type(v_pars)):
                continue

            # a bit verbose for now...
            if "variantFusionRequest" in variant_request_type:
                # prdbug(v_pars)
                if q := self.__create_variantFusionRequest_query(v_pars):
                    # prdbug(q)
                    queries.append(q)
                    continue
            if "GeneIdRequest" in variant_request_type:
                if q := self.__create_geneVariantRequest_query(v_pars):
                    queries = [*queries, *q]
                    continue
            if "cytoBandRequest" in variant_request_type:
                if q := self.__create_cytoBandRequest_query(v_pars):
                    queries.append(q)
                    continue
            if "variantQueryDigestsRequest" in variant_request_type:
                if q := self.__create_variantQueryDigestsRequest_query(v_pars):
                    queries.append(q)
                    continue
            if "aminoacidChangeRequest" in variant_request_type:
                if q := self.__create_aminoacidChangeRequest_query(v_pars):
                    queries.append(q)
                    continue
            if "genomicAlleleShortFormRequest" in variant_request_type:
                if q := self.__create_genomicAlleleShortFormRequest_query(v_pars):
                    queries.append(q)
                    continue
            if "variantBracketRequest" in variant_request_type:
                if q := self.__create_variantBracketRequest_query(v_pars):
                    queries.append(q)
                    continue
            if "variantRangeRequest" in variant_request_type:
                if q := self.__create_variantRangeRequest_query(v_pars):
                    queries.append(q)
                    continue
            if "BV2alleleRequest" in variant_request_type:
                if q := self.__create_variantAlleleRequest_query(v_pars):
                    queries.append(q)
                    continue
            if "variantTypeFilteredRequest" in variant_request_type:
                if q := self.__create_variantTypeRequest_query(v_pars):
                    queries.append(q)
                    continue

            if self.id_queries.items():
                # upstream ids are added to all queries if existing so here
                # creating only a dummy one if no other query type existed
                queries.append({})
                continue

        prdbug(f"__loop_multivars id_queries: {self.id_queries}")
        for i, v_p_c in enumerate(queries):
            for id_k, id_q in self.id_queries.items():
                prdbug(f"Updating variant query {i} with id query for {id_k}: {id_q}")
                queries[i].update({id_k: id_q})

        prdbug(f"__loop_multivars queries: {queries}")

        return queries


    ################################################################################

    def __get_variant_request_type(self, v_pars):
        """
        This method guesses the type of variant request, based on the complete
        fulfillment of the required parameters (all of `all_of`, one if `one_of`).
        In case of multiple types the one with most matched parameters is prefered.
        This may be changed to using a pre-defined request type and using this as
        completeness check only.
        TODO: Verify by schema ...
        TODO: This is all a bit too complex; probbaly better to just do it as a
              stack of dedicated tests and including a "defined to fail" query
              which is only removed after a successfull type match.
        """

        prdbug(f"Checking variant request type for {v_pars.get('request_profile_id')}")

        variant_request_type = None

        brts    = self.request_profiles
        brts_k  = brts.keys()
        # prdbug(f'...brts_k: {brts_k}')

        # Already hard-coding some types here - if conditions are met only
        # the respective types will be evaluated since only this key is used
        if "mate_name" in v_pars:
            brts_k = ["variantFusionRequest"]
        elif "start" in v_pars and "end" in v_pars:
            if len(v_pars.get("start", [])) == 1 and len(v_pars.get("end", [])) == 1:
                brts_k = ["variantRangeRequest"]
            elif len(v_pars["start"]) == 2 and len(v_pars["end"]) == 2:
                brts_k = ["variantBracketRequest"]
        elif "aminoacid_change" in v_pars:
            brts_k = ["aminoacidChangeRequest"]
        elif "genomic_allele_short_form" in v_pars:
            brts_k = ["genomicAlleleShortFormRequest"]
        elif "gene_id" in v_pars:
            brts_k = ["GeneIdRequest"]
        elif "cyto_bands" in v_pars:
            brts_k = ["cytoBandRequest"]
        elif "variant_query_digests" in v_pars:
            brts_k = ["variantQueryDigestsRequest"]
        elif "variant_type" in v_pars and len(self.filters) > 0:
            brts_k = ["variantTypeFilteredRequest"]

        vrt_matches = []
        for vrt in brts_k:
            matched_par_no = 0
            needed_par_no = 0
            if "any_of" in brts[vrt]:
                needed_par_no = 1
                for any_of in brts[vrt]["any_of"]:
                    if any_of in v_pars:
                        matched_par_no += 1
                        continue
            if "one_of" in brts[vrt]:
                one_par_no = 0
                needed_par_no = 1
                for one_of in brts[vrt]["one_of"]:
                    if one_of in v_pars:
                        one_par_no += 1
                if one_par_no == 1:
                    matched_par_no += 1
                    continue
            if "all_of" in brts[vrt]:
                needed_par_no += len(brts[vrt]["all_of"])
                for required in brts[vrt]["all_of"]:
                    if required in v_pars:
                        matched_par_no += 1
            if matched_par_no >= needed_par_no:
                vrt_matches.append({"type": vrt, "par_no": matched_par_no})
            prdbug(f"...{vrt}: {matched_par_no} of {needed_par_no}")

        if len(vrt_matches) > 0:
            vrt_matches = sorted(vrt_matches, key=lambda k: k["par_no"], reverse=True)
            variant_request_type = vrt_matches[0]["type"]
        elif len(self.id_queries.keys()) > 0:
            variant_request_type = "UpstreamIdRequest"

        prdbug(f"...variant_request_type: {variant_request_type}")
        return variant_request_type


    # -------------------------------------------------------------------------#

    def __create_geneVariantRequest_query(self, v_pars):
        # query database for gene and use coordinates to create range query
        # or fork of to analyses collection for priority genes
        gene_id = v_pars.get("gene_id", [])
        prdbug(f"...GeneIdRequest gene_id: {gene_id}")
        queries = []
        for g in gene_id:
            g = g.upper()
            # TODO: error report/warning
            if not (gene_data := GeneInfo().returnGene(g)):
                continue
            gene = gene_data[0]
            # Since this is a pre-processor to the range request
            v_pars.update(
                {
                    "reference_name": f"{gene["location"][0].get('sequence_id', '___none___')}",
                    "start": [gene["location"][0].get("start", 0)],
                    "end": [gene["location"][0].get("end", 1)],
                }
            )
            q_t = self.__create_variantRangeRequest_query(v_pars)
            prdbug(f"...GeneIdRequest query result: {q_t}")
            queries.append(q_t)

        if len(queries) < 1:
            return False

        return queries


    # -------------------------------------------------------------------------#

    def __create_variantQueryDigestsRequest_query(self, v_pars):
        # query database for gene and use coordinates to create range query
        # http://progenetix.test/beacon/biosamples/?datasetIds=progenetix&filters=NCIT:C3058&variantQueryDigests=9:21000001-21975098--21967753-24000000:DEL,8:120000000-125000000--121000000-126000000:DUP&debugMode=
        # http://progenetix.test/services/sampleplots/?datasetIds=progenetix&filters=NCIT:C3058&variantQueryDigests=8:1-23000000--26000000-120000000:DUP,9:21000001-21975098--21967753-24000000:DEL&debugMode=
        a_d = self.argument_definitions
        vqd_pat = re.compile(a_d["variant_query_digests"]["items"]["pattern"])

        vd_s = v_pars.get("variant_query_digests", "___none___")
        if not vqd_pat.match(vd_s):
            prdbug(f"!!! no match {vd_s}")
            return False
        chro, start, end, change = vqd_pat.match(vd_s).group(1, 2, 3, 4)
        v_pars.update(
            {
                "reference_name": self.ChroNames.refseq(chro),
                "start": list(map(int, re.split("-", start))),
            }
        )
        if end:
            v_pars.update({"end": list(map(int, re.split("-", end)))})
        else:
            v_pars.pop("end", None)

        v_pars.pop("variant_query_digests", None)

        # TODO: This overrides potentially a global variant_type; so right now
        # one has to leave the type out and use a global (or none), or provide
        # a type w/ each digest
        if change:
            if ">" in change:
                ref, alt = change.split(">")
                v_pars.update({"reference_bases": ref, "alternate_bases": alt})
                self.variant_request_type = "BV2alleleRequest"
                return self.__create_variantAlleleRequest_query(v_pars)
            else:
                v_pars.update(
                    {
                        "variant_type": {
                            "$in": self.VariantTypes.variantStateChildren(change)
                        }
                    }
                )

        if len(v_pars.get("start", [])) == 2:
            if len(v_pars.get("end", [])) == 2:
                self.variant_request_type = "variantBracketRequest"
                prdbug(
                    f"...variantQueryDigestsRequest for variantBracketRequest: {v_pars}"
                )
                return self.__create_variantBracketRequest_query(v_pars)
        elif len(v_pars.get("start", [])) == 1:
            if len(v_pars.get("end", [])) == 1:
                self.variant_request_type = "variantRangeRequest"
                return self.__create_variantRangeRequest_query(v_pars)
        else:
            prdbug(f"!!! variantQueryDigestsRequest: {v_pars}")
            return False
        # TODO: Allele query...


    # -------------------------------------------------------------------------#

    def __create_cytoBandRequest_query(self, v_pars):
        # query database for cytoband(s) and use coordinates to create range query
        vp = v_pars

        if not (cb_s := vp.get("cyto_bands")):
            return False

        CB = Cytobands()
        cbs, chro, start, end = CB.bandsFromCytostring(cb_s)
        sequence_id = self.ChroNames.refseq(chro)
        v_pars.update({"reference_name": sequence_id, "start": [start], "end": [end]})
        self.variant_request_type = "variantRangeRequest"

        return self.__create_variantRangeRequest_query(v_pars)


    # -------------------------------------------------------------------------#

    def __create_aminoacidChangeRequest_query(self, v_pars):
        vp = v_pars
        if "aminoacid_change" not in vp:
            return
        v_p_defs = self.argument_definitions
        v_q = {
            v_p_defs["aminoacid_change"]["db_key"]: vp.get(
                "aminoacid_change", "___none___"
            )
        }

        return v_q


    # -------------------------------------------------------------------------#

    def __create_genomicAlleleShortFormRequest_query(self, v_pars):
        vp = v_pars
        if "genomic_allele_short_form" not in vp:
            return

        v_p_defs = self.argument_definitions
        v_q = {
            v_p_defs["genomic_allele_short_form"]["db_key"]: vp.get(
                "genomic_allele_short_form", "___none___"
            )
        }

        return v_q


    # -------------------------------------------------------------------------#

    def __create_variantTypeRequest_query(self, v_pars):
        v_p_defs = self.argument_definitions
        vp = v_pars
        if "variant_type" not in vp:
            return
        v_q = self.__create_in_query_for_parameter(
            "variant_type", v_p_defs["variant_type"]["db_key"], vp
        )

        return v_q


    # -------------------------------------------------------------------------#

    def __create_variantFusionRequest_query(self, v_pars):
        vp = v_pars
        v_p_defs = self.argument_definitions

        # here we use the db fields of "mate_..." for all positional parameters
        # since the match is against the `adjoined_sequences` variant format
        try:
            v_q = {
                "$and": [
                    {
                        "adjoined_sequences.0.sequence_id": vp["reference_name"],
                        "$or": [
                            {
                                "adjoined_sequences.0.start.0": {"$lt": vp["end"][-1]},
                                "adjoined_sequences.0.start.1": {
                                    "$gte": vp["start"][0]
                                },
                            },
                            {
                                "adjoined_sequences.0.end.0": {"$lt": vp["end"][-1]},
                                "adjoined_sequences.0.end.1": {"$gte": vp["start"][0]},
                            },
                        ],
                    },
                    {
                        "adjoined_sequences.1.sequence_id": vp["mate_name"],
                        "$or": [
                            {
                                "adjoined_sequences.1.start.0": {"$lt": vp["mate_end"]},
                                "adjoined_sequences.1.start.1": {
                                    "$gte": vp["mate_start"]
                                },
                            },
                            {
                                "adjoined_sequences.1.end.0": {"$lt": vp["mate_end"]},
                                "adjoined_sequences.1.end.1": {
                                    "$gte": vp["mate_start"]
                                },
                            },
                        ],
                    },
                ]
            }
        except Exception as e:
            prdbug(e)

        if l_q := self.__request_variant_size_limits(v_pars):
            v_q.update(l_q)

        p_n = "variant_type"
        if p_n in vp:
            v_q.update(
                self.__create_in_query_for_parameter(p_n, v_p_defs[p_n]["db_key"], vp)
            )

        return v_q


    # -------------------------------------------------------------------------#

    def __create_variantRangeRequest_query(self, v_pars):
        vp = v_pars
        v_p_defs = self.argument_definitions

        v_q = {
            v_p_defs["reference_name"]["db_key"]: vp.get(
                "reference_name", "___none___"
            ),
            v_p_defs["start"]["db_key"]: {"$lt": int(vp["end"][-1])},
            v_p_defs["end"]["db_key"]: {"$gt": int(vp["start"][0])},
        }

        if l_q := self.__request_variant_size_limits(v_pars):
            v_q.update(l_q)

        p_n = "variant_type"
        if p_n in vp:
            v_q.update(
                self.__create_in_query_for_parameter(p_n, v_p_defs[p_n]["db_key"], vp)
            )
        if "alternate_bases" in vp:
            # the N wildcard stands for any length alt bases so can be ignored
            if vp["alternate_bases"] == "N":
                v_q.update({v_p_defs["alternate_bases"]["db_key"]: {"$regex": "."}})
            else:
                v_q.update(
                    {v_p_defs["alternate_bases"]["db_key"]: vp["alternate_bases"]}
                )

        return v_q


    # -------------------------------------------------------------------------#

    def __request_variant_size_limits(self, v_pars):
        vp = v_pars
        v_p_defs = self.argument_definitions
        l_k = v_p_defs["variant_max_length"]["db_key"]
        s_q = {l_k: {}}

        p_n = "variant_min_length"
        if minl := vp.get(p_n):
            s_q[l_k].update({"$gte": minl})
        p_n = "variant_max_length"
        if maxl := vp.get(p_n):
            s_q[l_k].update({"$lte": maxl})

        if s_q[l_k].keys():
            return s_q

        return None


    # -------------------------------------------------------------------------#

    def __create_variantBracketRequest_query(self, v_pars):
        vp = v_pars
        v_p_defs = self.argument_definitions

        v_q = {
            v_p_defs["reference_name"]["db_key"]: vp["reference_name"],
            v_p_defs["start"]["db_key"]: {
                "$gte": sorted(vp["start"])[0],
                "$lt": sorted(vp["start"])[-1],
            },
            v_p_defs["end"]["db_key"]: {
                "$gte": sorted(vp["end"])[0],
                "$lt": sorted(vp["end"])[-1],
            },
        }

        if v_t := self.__create_in_query_for_parameter(
            "variant_type", v_p_defs["variant_type"]["db_key"], vp
        ):
            v_q.update(v_t)

        return v_q


    # -------------------------------------------------------------------------#

    def __create_variantAlleleRequest_query(self, v_pars):
        """ """
        vp = v_pars
        v_p_defs = self.argument_definitions
        # TODO: Regexes for ref or alt with wildcard characters
        # TODO: figure out VCF vs. VRS normalization
        v_q = {
            v_p_defs["reference_name"]["db_key"]: vp["reference_name"],
            v_p_defs["start"]["db_key"]: int(vp["start"][0]),
        }
        for p in ["reference_bases", "alternate_bases"]:
            qv = vp.get(p)
            if not qv:
                continue
            if "N" in vp[p]:
                qv = qv.replace("N", ".")
                v_q.update({v_p_defs[p]["db_key"]: {"$regex": qv}})
            else:
                v_q.update({v_p_defs[p]["db_key"]: qv})

        return v_q


    # -------------------------------------------------------------------------#

    def __create_in_query_for_parameter(self, par, qpar, q_pars):

        if not isinstance(q_pars[par], list):
            return {qpar: q_pars[par]}
        try:
            q_pars[par][0]
        except IndexError:
            return {}

        if len(q_pars[par]) > 1:
            return {qpar: {"$in": q_pars[par]}}

        return {qpar: q_pars[par][0]}


    # -------------------------------------------------------------------------#
    # -------------------------------------------------------------------------#
    # -------------------------------------------------------------------------#

    def __query_from_filters(self):
        if self.queries.get("expand") is False:
            return
        if len(self.filters) < 1:
            return

        m_d = self.ds_id
        if not (m_c := BYC_DBS.get("collections", {}).get("filteringTerm")):
            ByconError().addError("No filtering term collection defined!")
            return
        self.filter_collection = ByconMongo(m_d).openMongoColl(m_c)
        entity_filters_lists = self.__assemble_filter_lists()

        for f_entity, field_queries in entity_filters_lists.items():
            f_s_l = []
            for f_field, f_query_vals in field_queries.items():
                if len(f_query_vals) == 1:
                    f_s_l.append({f_field: f_query_vals[0]})
                else:
                    for f_q_v in f_query_vals:
                        f_s_l.append({f_field: f_q_v})

            self.__update_queries_for_entity(f_s_l, f_entity)


    # -------------------------------------------------------------------------#

    def __assemble_filter_lists(self):
        f_lists = {}

        for f in self.filters:
            f = self.__substitute_filter_id(f)
            f_val, f_neg = self.__get_filter_value_and_negation(f)
            f_desc = f.get(
                "includeDescendantTerms", BYC_PARS.get("include_descendant_terms")
            )
            if (f_info := self.__filter_info_from_collationed_filter(f_val)) is False:
                f_info = self.__filter_info_from_filter_definitions(f_val)
            if f_info is False:
                BYC["WARNINGS"].append(
                    f"No filter query could be created for value {f_val}!!!"
                )
                continue

            f_id = f_info.get("id")

            if f_neg is True:
                f_info.update({"is_negated": True})

            f_entity = f_info.get("entity")
            if f_entity not in f_lists.keys():
                f_lists.update({f_entity: {}})

            f_field = f_info.get("db_key", "id")
            if f_field not in f_lists[f_entity].keys():
                f_lists[f_entity].update({f_field: []})

            # TODO: needs a general solution for alphanumerics; so far for the
            # iso age and followup_time w/ pre-calculated days field...
            # TODO: The whole negation is a bit non-standard since the logic
            # of "excluded" versus "not found" is complex. To be revised...
            if "alphanumeric" in f_info.get("type", "ontology"):
                prdbug(f"__query_from_filters ... alphanumeric: {f_id}")
                if re.match(r"^(\w+):?([<>=]+?)?(\w[\w.]+?)$", f_id):
                    f_class, comp, val = re.match(
                        r"^(\w+):?([<>=]+?)?(\w[\w.]+?)$", f_id
                    ).group(1, 2, 3)
                    if "iso8601duration" in f_info.get("format", "___none___"):
                        val = days_from_iso8601duration(val)
                    f_lists[f_entity][f_field].append(
                        self.__mongo_comparator_query(comp, val)
                    )
                else:
                    f_lists[f_entity][f_field].append(f_id)
            elif f_desc is True:
                if f_neg is True:
                    f_lists[f_entity][f_field].append({"$nin": f_info.get("child_terms", f_id)})
                else:
                    f_lists[f_entity][f_field].append({"$in": f_info.get("child_terms", f_id)})
            else:
                if f_neg is True:
                    f_lists[f_entity][f_field].append({"$nin": [f_id]})
                else:
                    f_lists[f_entity][f_field].append(f_id)

        return f_lists


    # -------------------------------------------------------------------------#

    def __substitute_filter_id(self, f):
        f.update({"id": f.get("id", "___none___").replace("PMID:", "pubmed:")})
        return f


    # -------------------------------------------------------------------------#

    def __get_filter_value_and_negation(self, f):
        f_val = f.get("id")
        f_neg = f.get("excluded", False)
        if re.compile(r"^!").match(f_val):
            f_neg = True
            f_val = re.sub(r"^!", "", f_val)
        f_val = re.sub(r"^!", "", f_val)
        return f_val, f_neg


    # -------------------------------------------------------------------------#

    def __filter_info_from_collationed_filter(self, f_val):
        prdbug(f"...__filter_info_from_collationed_filter: {self.filter_collection}")
        if (f_info := self.filter_collection.find_one(
            {"id": f_val},
            {
                "_id": 0,
                "id": 1,
                "label": 1,
                "type": 1,
                "format": 1,
                "db_key": 1,
                "entity": 1,
                "child_terms": 1,
            },
        )):
            return f_info

        return False

    # -------------------------------------------------------------------------#

    def __filter_info_from_filter_definitions(self, f_val):
        f_d_s = BYC.get("filter_definitions", {}).get("$defs", {})

        prdbug(f"...__filter_info_from_filter_definitions: {f_val}")

        for f_d in f_d_s.values():
            if f_d.get("collationed", False) is True:
                continue
            f_re = re.compile(f_d.get("pattern", "___none___"))
            prdbug(f"pattern check: {f_d.get('pattern', '___none___')} <> {f_val}")
            if f_re.match(f_val):
                f_val = re.sub(r'^__\w+__\:', "", f_val)
                f_info = {
                    "id": f_val,
                    "scope": f_d.get("scope", "biosamples"),
                    "entity": f_d.get("entity", "biosample"),
                    "db_key": f_d["db_key"],
                    "type": f_d.get("type", "ontology"),
                    "format": f_d.get("format", "___none___"),
                    "child_terms": [f_val],
                }
                return f_info

        return False

    # -------------------------------------------------------------------------#

    def __query_from_geoquery(self, entity="biosample"):
        geo_q = GeoQuery().get_geoquery()
        if not geo_q:
            return
        self.__update_queries_for_entity([geo_q], entity)

    # -------------------------------------------------------------------------#

    def __query_from_hoid(self):
        """
        This non-standard (_i.e._ not Beacon spec'd) type of query generation retrieves
        the query parameters and values from a handover object, _i.e._ the stored results
        of a previous query.
        These query values can be combined with additional parameters.
        """
        if not (accessid := BYC_PARS.get("accessid")):
            return

        m_d = BYC_DBS["housekeeping_db"]
        m_c = BYC_DBS.get("collections", {}).get("handover")

        ho_coll = ByconMongo(m_d).openMongoColl(m_c)
        if not (h_o := ho_coll.find_one({"id": accessid})):
            return

        t_v = h_o["target_values"]
        t_e = h_o["entity_id"]

        t_v = ByconH().paginated_list(t_v, self.skip, self.limit)
        if len(t_v) < 1:
            return
        h_o_q = [{"id": {"$in": t_v}}]
        self.__update_queries_for_entity(h_o_q, t_e)

    # -------------------------------------------------------------------------#

    def __update_queries_for_entity(self, query, entity):
        # TODO: This is now for using generally query lists and aggregate
        # by multiple queries & intersection of matched ids during execution
        e = entity
        if not (c := BYC_DBS.get("collections", {}).get(e)):
            return
        q_e = self.queries.get("entities")

        if type(query) is not list:
            query = [query]
        if e not in q_e:
            q_e.update({e: {"query": query, "collection": c}})
        else:
            q_e[e]["query"] = [*q_e[e]["query"], *query]

        self.queries.update({"entities": q_e})

    # -------------------------------------------------------------------------#

    def __mongo_comparator_query(self, comparator, value):
        mongo_comps = {">": "$gt", ">=": "$gte", "<": "$lt", "<=": "$lte", "=": "$eq"}
        c = mongo_comps.get(comparator, "$eq")
        return {c: value}


################################################################################
################################################################################
################################################################################


class GeoQuery:
    """
    This class is used to generate a query for the geolocation data.
    It is an extension of the standard BeaconQuery process.
    """

    def __init__(self, geo_root="geo_location"):
        self.argument_definitions = BYC.get("argument_definitions", {}).get(
            "parameters", {}
        )

        # this is a remnant of geo objects in different nestings...
        self.geo_root = geo_root
        self.geo_dot_keys = {"properties": "properties", "geometry": "geometry"}
        if len(self.geo_root) > 0:
            for k, v in self.geo_dot_keys.items():
                self.geo_dot_keys[k] = ".".join([self.geo_root, v])

        self.geo_pars = {
            "city": None,
            "country": None,
            "iso3166alpha2": None,
            "iso3166alpha3": None,
            "geo_latitude": None,
            "geo_longitude": None,
            "geo_distance": None,
        }

        self.__get_geo_pars()

        self.query = {"expand": True, "geo_query": {}}

        self.__geo_city_query()
        self.__geo_geo_longlat_query()

    # -------------------------------------------------------------------------#
    # ----------------------------- public ------------------------------------#
    # -------------------------------------------------------------------------#

    def get_geoquery(self):
        return self.query.get("geo_query", {})

    # -------------------------------------------------------------------------#

    def get_geopars(self):
        return self.geo_pars

    # -------------------------------------------------------------------------#
    # ----------------------------- private -----------------------------------#
    # -------------------------------------------------------------------------#

    def __get_geo_pars(self):
        """
        This method retrieves the geolocation parameters from the general
        parameters object.
        """
        g_k_s = list(self.geo_pars.keys())

        for p_k, p_v_s in BYC_PARS.items():
            if not p_k in g_k_s:
                continue
            self.geo_pars.update({p_k: p_v_s})

        # remove all keys with empty values
        for g_k in g_k_s:
            if not self.geo_pars.get(g_k):
                self.geo_pars.pop(g_k, None)

        if len(self.geo_pars) == 1 and "geo_distance" in self.geo_pars:
            self.geo_pars = {}

        prdbug(f"...__get_geo_pars: {self.geo_pars}")

    # -------------------------------------------------------------------------#

    def __geo_geo_longlat_query(self):
        if self.query.get("expand") is not True:
            return

        for g_k in ["geo_latitude", "geo_longitude", "geo_distance"]:
            if not self.geo_pars.get(g_k):
                return

        geoq_l = [
            {
                self.geo_dot_keys["geometry"]: {
                    "$near": {
                        "$geometry": {
                            "type": "Point",
                            "coordinates": [
                                self.geo_pars.get("geo_longitude"),
                                self.geo_pars.get("geo_latitude"),
                            ],
                        },
                        "$maxDistance": self.geo_pars.get("geo_distance"),
                    }
                }
            }
        ]

        self.query.update(
            {"geo_query": mongo_and_or_query_from_list(geoq_l), "expand": False}
        )

    # -------------------------------------------------------------------------#

    def __geo_city_query(self):
        if self.query.get("expand") is not True:
            return
        if len(city_v := self.geo_pars.get("city", "")) < 1:
            return

        geoq_l = [
            {
                f"{self.geo_dot_keys['properties']}.city": re.compile(
                    r"^" + str(city_v), re.IGNORECASE
                )
            }
        ]

        for g_k in ["country", "iso3166alpha3", "iso3166alpha2"]:
            if len(g_v := self.geo_pars.get(g_k, "")) < 1:
                continue

            geoq_l.append(
                {
                    f"{self.geo_dot_keys['properties']}.{g_k}": re.compile(
                        r"^" + str(g_v) + r"$", re.IGNORECASE
                    )
                }
            )

        self.query.update(
            {"geo_query": mongo_and_or_query_from_list(geoq_l), "expand": False}
        )


################################################################################
################################################################################
################################################################################


class CollationQuery:
    def __init__(self):
        self.collection = "collations"
        self.dataset_id = BYC["BYC_DATASET_IDS"][0]
        self.test_mode_count = BYC_PARS.get("test_mode_count", 5)
        self.filters = BYC_PARS.get("filters", [])
        self.collation_types = BYC_PARS.get("collation_types", [])
        self.query = False

        self.__coll_test_mode_query()
        self.__coll_query()

        if self.query is False:
            self.query = {"id": "___undefined___"}

    # -------------------------------------------------------------------------#
    # ----------------------------- public ------------------------------------#
    # -------------------------------------------------------------------------#

    def getQuery(self):
        return self.query

    # -------------------------------------------------------------------------#
    # ---------------------------- private ------------------------------------#
    # -------------------------------------------------------------------------#

    def __coll_query(self):
        if type(self.query) is dict:
            return

        q_list = []
        if len(self.filters) > 0:
            q_list.append({"id": {"$in": self.filters}})
        if len(self.collation_types) > 0:
            if "all" in self.collation_types[0]:
                self.collation_types = []
            q_list.append({"collation_type": {"$in": self.collation_types}})
        if len(q_list) < 1:
            return
        self.query = mongo_and_or_query_from_list(q_list)

    # -------------------------------------------------------------------------#

    def __coll_test_mode_query(self):
        if BYC["TEST_MODE"] is not True:
            return
        if self.dataset_id not in ByconMongo().databaseList():
            ByconError().addError(f"db `{self.dataset_id}` does not exist")
            self.query = {"_id": "___undefined___"}
            return
        try:
            pipeline = [
                {"$sample": {"size": self.test_mode_count}},
                {"$project": {"_id": 0, "id": 1}}
            ]
            rs = ByconMongo(self.dataset_id).resultListFromPipeline("collations", pipeline)
            prdbug(f"...__coll_test_mode_query result\n\n{rs}")
            ids = list(s["id"] for s in rs)
            self.query = {"id": {"$in": ids}}
        except Exception as e:
            ByconError().addError(e)
            self.query = {"_id": "___undefined___"}


################################################################################
################################################################################
################################################################################


def mongo_and_or_query_from_list(query, logic="AND"):
    if type(query) is not list:
        return query
    if len(query) == 1:
        return query[0]
    elif len(query) > 1:
        if "OR" in logic.upper():
            return {"$or": query}
        return {"$and": query}
    else:
        return {}
