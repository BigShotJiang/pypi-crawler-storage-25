from pymongo import MongoClient
from bycon import BYC, BYC_DBS, print_json_response
from lib.service_response_generation import ByconServiceResponse

def dbstats():
    """
    This service endpoint provides statistic information about the resource's
    datasets.

    #### Examples
    
    * <https://progenetix.org/services/dbstats/>
    * <https://progenetix.org/services/dbstats/examplez>
    """

    m_h = BYC_DBS["mongodb_host"]
    m_d = BYC_DBS["housekeeping_db"]
    m_c = BYC_DBS.get("collections", {}).get("info")

    stats_coll = MongoClient(host=m_h)[m_d][m_c]
    results = []
    stats = stats_coll.find({}, {"_id": 0 }).sort("date", -1).limit(1)
    stat = list(stats)[0]
    for ds_id, ds_vs in stat["datasets"].items():
        if len(BYC["BYC_DATASET_IDS"]) > 0:
            if not ds_id in BYC["BYC_DATASET_IDS"]:
                continue
        results.append( {"dataset_id": ds_id, "counts":ds_vs["counts"]} )

    ByconServiceResponse().print_populated_response(results)
