"""Tool definitions and execution for the MahanAI agent."""

from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any

from mahanai import colors as C

_JSON_BAD_BACKSLASH = re.compile(r'\\(?!["\\/bfnrtu]|u[0-9a-fA-F]{4})')


def repair_invalid_json_escapes(raw: str) -> str:
    s = raw
    for _ in range(128):
        try:
            json.loads(s)
            return s
        except json.JSONDecodeError:
            nxt = _JSON_BAD_BACKSLASH.sub(r"\\\\", s)
            if nxt == s:
                return s
            s = nxt
    return s


def normalize_tool_arguments_json(arguments: str) -> str:
    """Parse model tool arguments and re-serialize as valid JSON for the API and executor."""
    raw = (arguments or "").strip() or "{}"
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError:
        try:
            obj = json.loads(repair_invalid_json_escapes(raw))
        except json.JSONDecodeError:
            return "{}"
    if not isinstance(obj, dict):
        return "{}"
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": (
                "Execute a shell command now (the user sees ⚡Running: in the terminal). "
                "Do not only show commands in chat—this tool must be called to run them. "
                "On Windows the default shell is usually cmd.exe (COMSPEC), not PowerShell; "
                "use cmd syntax or call powershell -NoProfile -Command \"...\" explicitly."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "Full command line to execute.",
                    },
                    "cwd": {
                        "type": "string",
                        "description": "Optional working directory (absolute or relative to cwd).",
                    },
                    "timeout_seconds": {
                        "type": "integer",
                        "description": "Max seconds to wait (default 120).",
                    },
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the full text of a file (UTF-8).",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file.",
                    },
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Create or overwrite a file with UTF-8 text.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file.",
                    },
                    "content": {
                        "type": "string",
                        "description": "Full file contents.",
                    },
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_directory",
            "description": "List files and subdirectories in a path (non-recursive).",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Directory path (default: current working directory).",
                    },
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "append_file",
            "description": "Append UTF-8 text to a file (creates the file if missing).",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string"},
                    "content": {"type": "string"},
                },
                "required": ["path", "content"],
            },
        },
    },
]

# ── Approval helpers ───────────────────────────────────────────────────────────

_HIGH_RISK_PATTERNS = [
    re.compile(r"\brm\s+.*(-\s*rf\b|-\s*fr\b|--no-preserve-root)"),
    re.compile(r"\brmdir(\.exe)?\b.*\s/s\b"),
    re.compile(r"\brd(\.exe)?\b.*\s/s\b"),
    re.compile(r"\bdel(\.exe)?\b.*\s/s\b"),
    re.compile(r"\berase(\.exe)?\b.*\s/s\b"),
    re.compile(r"\bformat\s+"),
    re.compile(r"\bshutdown\b"),
    re.compile(r"\breboot\b"),
    re.compile(r"\blogoff\b"),
    re.compile(r"\bhalt\b"),
    re.compile(r"\bpoweroff\b"),
    re.compile(r"\binit\s+0\b"),
    re.compile(r"\bdiskpart\b"),
    re.compile(r"\bmkfs"),
    re.compile(r"\bdd\s+if="),
    re.compile(r":\(\)\s*\{\s*:"),
    re.compile(r"remove-item.*-recurse.*-force"),
]


def _is_high_risk(cmd: str) -> bool:
    low = cmd.strip().lower()
    return any(p.search(low) for p in _HIGH_RISK_PATTERNS)


def _command_category(cmd: str) -> str:
    first = cmd.strip().split()[0].lower().rstrip(".exe") if cmd.strip() else ""
    if first == "git":
        return "git"
    if first == "gh":
        return "github"
    return "normal"


def _command_prefix(cmd: str) -> str:
    return cmd.strip().split()[0].lower() if cmd.strip() else ""


def _read_input(prompt: str) -> str:
    try:
        return input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return ""


def _approve_command(cmd: str) -> tuple[bool, str]:
    """
    Show an approval prompt for a shell command.
    Returns (approved, denial_message_for_ai).
    """
    from mahanai.config import load_always_allowed, add_always_allowed_command

    category = _command_category(cmd)
    prefix = _command_prefix(cmd)
    high_risk = _is_high_risk(cmd)

    # Always-Allow only applies to normal (non-git, non-gh) commands
    if category == "normal" and not high_risk:
        always = load_always_allowed()
        if prefix in always.get("command_prefixes", []):
            return True, ""

    # ── Build prompt ──────────────────────────────────────────────────────────
    cat_label = {
        "git":    "Git Command",
        "github": "GitHub Command",
        "normal": "Shell Command",
    }[category]

    risk_tag = f"  {C.ERR}[DESTRUCTIVE]{C.RST}" if high_risk else ""
    print(f"\n{C.WARN}  {cat_label}{C.RST}{risk_tag}")
    print(f"  {C.DIM}{cmd}{C.RST}")

    if category in ("git", "github"):
        print(f"  {C.OK}[A]{C.RST} Allow    {C.ERR}[D]{C.RST} Deny")
        ans = _read_input("  > ")
        approved = ans.lower() in ("a", "allow")
    else:
        # Normal: Allow / Always Allow / Deny
        always_label = f"Always Allow ({prefix})" if not high_risk else "Always Allow (disabled for destructive)"
        if high_risk:
            print(f"  {C.OK}[A]{C.RST} Allow    {C.ERR}[D]{C.RST} Deny")
            ans = _read_input("  > ")
            approved = ans.lower() in ("a", "allow")
        else:
            print(f"  {C.OK}[A]{C.RST} Allow    {C.DIM}[W] {always_label}{C.RST}    {C.ERR}[D]{C.RST} Deny")
            ans = _read_input("  > ").lower()
            if ans in ("w", "always allow", "always"):
                add_always_allowed_command(prefix)
                print(f"  {C.OK}'{prefix}' commands will always be allowed.{C.RST}")
                return True, ""
            approved = ans in ("a", "allow")

    if approved:
        return True, ""

    # Denied — let user send a message to the AI
    msg = _read_input(f"  {C.DIM}Instruction for AI (Enter to skip):{C.RST} ")
    return False, msg or "Command was denied by the user."


def _approve_file_op(op: str, display_path: str) -> tuple[bool, str]:
    """
    Show an approval prompt for a file operation.
    Returns (approved, denial_message_for_ai).
    """
    from mahanai.config import load_always_allowed, add_always_allowed_file_op

    always = load_always_allowed()
    if op in always.get("file_ops", []):
        return True, ""

    op_labels = {
        "read_file":      "Read File",
        "write_file":     "Write / Create File",
        "append_file":    "Append to File",
        "list_directory": "List Directory",
    }
    label = op_labels.get(op, op)

    print(f"\n{C.WARN}  {label}{C.RST}")
    print(f"  {C.DIM}{display_path}{C.RST}")
    print(f"  {C.OK}[A]{C.RST} Allow    {C.DIM}[W] Always Allow ({label}){C.RST}    {C.ERR}[D]{C.RST} Deny")

    ans = _read_input("  > ").lower()

    if ans in ("w", "always allow", "always"):
        add_always_allowed_file_op(op)
        print(f"  {C.OK}'{label}' will always be allowed.{C.RST}")
        return True, ""

    if ans in ("a", "allow"):
        return True, ""

    msg = _read_input(f"  {C.DIM}Instruction for AI (Enter to skip):{C.RST} ")
    return False, msg or "File operation was denied by the user."


# ── Tool implementations ───────────────────────────────────────────────────────

def _resolve_path(base: Path, raw: str) -> Path:
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = (base / p).resolve()
    else:
        p = p.resolve()
    return p


def run_command(base: Path, args: dict[str, object]) -> str:
    cmd = str(args.get("command", "")).strip()
    if not cmd:
        return json.dumps({"error": "empty command"})
    cwd_raw = args.get("cwd")
    timeout = int(args.get("timeout_seconds") or 120)
    cwd = base
    if isinstance(cwd_raw, str) and cwd_raw.strip():
        cwd = _resolve_path(base, cwd_raw)

    approved, denial_msg = _approve_command(cmd)
    if not approved:
        return json.dumps({
            "exit_code": -1,
            "error": "user_denied",
            "message": denial_msg,
            "command": cmd,
            "output": denial_msg,
            "cwd": str(cwd),
        })

    print(f"\n{C.OK}⚡Running:{C.RST} {cmd}", flush=True)
    try:
        proc = subprocess.run(
            cmd,
            shell=True,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=max(1, timeout),
            env=os.environ.copy(),
        )
        out = (proc.stdout or "") + (proc.stderr or "")
        if len(out) > 100_000:
            out = out[:100_000] + "\n… [truncated]"
        return json.dumps({"exit_code": proc.returncode, "output": out, "cwd": str(cwd)})
    except subprocess.TimeoutExpired:
        return json.dumps({"error": f"timed out after {timeout}s", "command": cmd})
    except OSError as e:
        return json.dumps({"error": str(e), "command": cmd})


def read_file(base: Path, args: dict[str, object]) -> str:
    raw_path = str(args.get("path", ""))
    path = _resolve_path(base, raw_path)

    approved, denial_msg = _approve_file_op("read_file", str(path))
    if not approved:
        return json.dumps({"error": "user_denied", "message": denial_msg, "path": str(path)})

    if not path.is_file():
        return json.dumps({"error": "not a file", "path": str(path)})
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        if len(text) > 200_000:
            text = text[:200_000] + "\n… [truncated]"
        return json.dumps({"path": str(path), "content": text})
    except OSError as e:
        return json.dumps({"error": str(e), "path": str(path)})


def write_file(base: Path, args: dict[str, object]) -> str:
    raw_path = str(args.get("path", ""))
    path = _resolve_path(base, raw_path)
    content = str(args.get("content", ""))

    approved, denial_msg = _approve_file_op("write_file", str(path))
    if not approved:
        return json.dumps({"error": "user_denied", "message": denial_msg, "path": str(path)})

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return json.dumps({"ok": True, "path": str(path), "bytes": len(content.encode("utf-8"))})
    except OSError as e:
        return json.dumps({"error": str(e), "path": str(path)})


def append_file(base: Path, args: dict[str, object]) -> str:
    raw_path = str(args.get("path", ""))
    path = _resolve_path(base, raw_path)
    content = str(args.get("content", ""))

    approved, denial_msg = _approve_file_op("append_file", str(path))
    if not approved:
        return json.dumps({"error": "user_denied", "message": denial_msg, "path": str(path)})

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(content)
        return json.dumps({"ok": True, "path": str(path), "appended_bytes": len(content.encode("utf-8"))})
    except OSError as e:
        return json.dumps({"error": str(e), "path": str(path)})


def list_directory(base: Path, args: dict[str, object]) -> str:
    raw = args.get("path")
    path = base if not isinstance(raw, str) or not raw.strip() else _resolve_path(base, raw)

    approved, denial_msg = _approve_file_op("list_directory", str(path))
    if not approved:
        return json.dumps({"error": "user_denied", "message": denial_msg, "path": str(path)})

    if not path.is_dir():
        return json.dumps({"error": "not a directory", "path": str(path)})
    try:
        entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        truncated = len(entries) > 500
        rows = [
            {"name": p.name, "type": "dir" if p.is_dir() else "file"}
            for p in entries[:500]
        ]
        return json.dumps({"path": str(path), "entries": rows, "truncated": truncated})
    except OSError as e:
        return json.dumps({"error": str(e), "path": str(path)})


def execute_tool(name: str, arguments_json: str, workspace: Path) -> str:
    canon = normalize_tool_arguments_json(arguments_json)
    if canon == "{}" and (arguments_json or "").strip() not in ("", "{}"):
        return json.dumps(
            {
                "error": "could not parse tool arguments as JSON",
                "raw": (arguments_json or "")[:500],
            }
        )
    try:
        args = json.loads(canon)
    except json.JSONDecodeError as e:
        return json.dumps({"error": f"invalid JSON arguments: {e}"})

    if name == "run_command":
        return run_command(workspace, args)
    if name == "read_file":
        return read_file(workspace, args)
    if name == "write_file":
        return write_file(workspace, args)
    if name == "append_file":
        return append_file(workspace, args)
    if name == "list_directory":
        return list_directory(workspace, args)
    return json.dumps({"error": f"unknown tool: {name}"})
