"""SDK exception hierarchy."""


class AuthSDKError(Exception):
    """Base error for the SDK."""


class HTTPError(AuthSDKError):
    """Raised when an HTTP call to the auth server fails."""

    def __init__(self, message: str, status_code: int | None = None, body=None):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class AuthenticationError(AuthSDKError):
    """Raised when credentials are rejected by the auth server."""


class InvalidTokenError(AuthSDKError):
    """Raised when a JWT cannot be validated."""


class TokenExpiredError(InvalidTokenError):
    """Raised when a JWT signature is valid but the token has expired."""
