"""Django REST Framework authentication class backed by the SDK verifier.

Settings (read lazily so importing without Django/DRF is harmless):
    AUTH_SDK_JWKS_URL       (str)  JWKS endpoint, e.g. https://tokens.../.well-known/jwks.json
    AUTH_SDK_ALGORITHMS     (list) default ["RS256"]
    AUTH_SDK_LOCAL_SECRET   (str)  optional fallback PEM/secret
    AUTH_SDK_AUDIENCE       (str)  optional aud check
    AUTH_SDK_HEADER_PREFIXES (list) default ["token", "bearer"]
    AUTH_SDK_COOKIE_NAME    (str)  optional cookie fallback (e.g. "access_token")
    AUTH_SDK_REQUIRED_TOKEN_TYPE (str) optional ("access" / "refresh")

The ``authenticate`` method returns a lightweight ``SDKUser`` that exposes the
JWT payload, roles, and identifiers without requiring a database lookup. If
your app also needs a Django user, subclass and override ``get_user``.
"""

from __future__ import annotations

from typing import Any

try:
    from django.conf import settings
    from rest_framework import authentication, exceptions
except ImportError as exc:  # pragma: no cover - runtime guard
    raise ImportError(
        "django and djangorestframework are required for the django_drf integration. "
        "Install with: pip install boolean-auth-sdk[django]"
    ) from exc

from ..exceptions import InvalidTokenError, TokenExpiredError
from ..types import Role
from ..verifier import JWTVerifier


class SDKUser:
    """In-memory user proxy populated from the JWT payload."""

    is_authenticated = True
    is_anonymous = False
    is_active = True

    def __init__(self, payload: dict[str, Any]):
        self.payload = payload
        self.user_id = (
            payload.get("user_id")
            or payload.get("sub")
            or payload.get("id")
        )
        self.username = (
            payload.get("username")
            or payload.get("preferred_username")
            or payload.get("user_name")
            or payload.get("email")
            or self.user_id
        )
        self.email = payload.get("email") or payload.get("Email")
        self.app_id = payload.get("app_id")
        self.session_uuid = payload.get("session_uuid")
        self.roles = [Role.from_any(r) for r in (payload.get("roles") or [])]

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        return f"SDKUser(user_id={self.user_id!r})"


class JWTAuthentication(authentication.BaseAuthentication):
    """DRF authentication that validates JWTs via JWKS with local fallback."""

    _verifier: JWTVerifier | None = None

    def __init__(self) -> None:
        self.header_prefixes = {
            p.lower()
            for p in getattr(settings, "AUTH_SDK_HEADER_PREFIXES", ["token", "bearer"])
        }
        self.cookie_name = getattr(settings, "AUTH_SDK_COOKIE_NAME", None)
        self.required_token_type = getattr(settings, "AUTH_SDK_REQUIRED_TOKEN_TYPE", None)

    @classmethod
    def _get_verifier(cls) -> JWTVerifier:
        if cls._verifier is None:
            cls._verifier = JWTVerifier(
                jwks_url=getattr(settings, "AUTH_SDK_JWKS_URL", None),
                algorithms=getattr(settings, "AUTH_SDK_ALGORITHMS", ["RS256"]),
                audience=getattr(settings, "AUTH_SDK_AUDIENCE", None),
                local_secret=getattr(settings, "AUTH_SDK_LOCAL_SECRET", None),
            )
        return cls._verifier

    def authenticate(self, request):  # type: ignore[override]
        token = self._extract_token(request)
        if not token:
            return None

        try:
            payload = self._get_verifier().verify(
                token,
                expected_token_type=self.required_token_type,
            )
        except TokenExpiredError as exc:
            raise exceptions.AuthenticationFailed("Token expired") from exc
        except InvalidTokenError as exc:
            raise exceptions.AuthenticationFailed(str(exc)) from exc

        user = self.get_user(payload, token)
        return user, token

    def authenticate_header(self, request):  # type: ignore[override]
        return "Bearer"

    # ------------------------------------------------------------ overridable

    def get_user(self, payload: dict[str, Any], token: str):
        """Return the request user. Override to map to a Django model."""
        return SDKUser(payload)

    def _extract_token(self, request) -> str | None:
        header = request.META.get("HTTP_AUTHORIZATION", "")
        if header:
            parts = header.split()
            if len(parts) == 2 and parts[0].lower() in self.header_prefixes:
                return parts[1]
        if self.cookie_name:
            return request.COOKIES.get(self.cookie_name)
        return None


class JWTRefreshAuthentication(JWTAuthentication):
    """Same as :class:`JWTAuthentication` but enforces ``token_type == "refresh"``."""

    def __init__(self) -> None:
        super().__init__()
        self.required_token_type = "refresh"
