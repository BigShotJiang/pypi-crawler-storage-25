"""Lightweight value objects returned by the SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class TokenPair:
    """Pair of JWT tokens returned by login/refresh endpoints."""

    access_token: str
    refresh_token: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> "TokenPair":
        return cls(
            access_token=data.get("access_token") or data.get("access") or "",
            refresh_token=data.get("refresh_token") or data.get("refresh"),
            raw=data,
        )


@dataclass
class Role:
    role_code: str | None = None
    role_name: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_any(cls, value: Any) -> "Role":
        if isinstance(value, dict):
            return cls(
                role_code=value.get("role_code") or value.get("code"),
                role_name=value.get("role_name") or value.get("name"),
                raw=value,
            )
        return cls(role_code=str(value), role_name=str(value), raw={"value": value})


@dataclass
class UserProfile:
    """Generic user profile returned by /user/me/ or /user/by-cuil/."""

    user_id: str | None
    email: str | None
    username: str | None
    first_name: str | None
    last_name: str | None
    cuil: str | None
    roles: list[Role] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> "UserProfile":
        if not isinstance(data, dict):
            raise ValueError("UserProfile.from_response expects a dict payload")

        cuil = (
            data.get("cuil")
            or data.get("CUIL")
            or data.get("cuit")
            or data.get("CUIT")
        )
        user_id = (
            data.get("user_id")
            or data.get("id")
            or data.get("sub")
            or cuil
        )
        username = (
            data.get("username")
            or data.get("preferred_username")
            or data.get("user_name")
        )

        return cls(
            user_id=str(user_id) if user_id is not None else None,
            email=data.get("email") or data.get("Email"),
            username=str(username) if username else None,
            first_name=data.get("first_name") or data.get("Nombre") or data.get("given_name"),
            last_name=data.get("last_name") or data.get("Apellido") or data.get("family_name"),
            cuil=str(cuil) if cuil else None,
            roles=[Role.from_any(r) for r in (data.get("roles") or [])],
            raw=data,
        )
