"""JWT verification using JWKS with optional local-key fallback."""

from __future__ import annotations

import logging
from typing import Any

import jwt
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from jwt import PyJWKClient
from jwt.exceptions import PyJWKClientError

from .exceptions import InvalidTokenError, TokenExpiredError

logger = logging.getLogger(__name__)


DEFAULT_JWKS_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json",
}


class JWTVerifier:
    """Validates JWTs issued by cidi-auth / auth.back.

    Resolution order:
      1. Fetch signing key from JWKS (``jwks_url``) and verify.
      2. If JWKS fetch fails (network/Cloudflare/etc.) and ``local_secret`` is
         provided, validate against the local key. RS* keys can be passed as
         a private PEM (the public key is derived automatically).
    """

    def __init__(
        self,
        jwks_url: str | None = None,
        *,
        algorithms: list[str] | None = None,
        audience: str | list[str] | None = None,
        leeway: float = 0,
        local_secret: str | bytes | None = None,
        jwks_headers: dict[str, str] | None = None,
        verify_aud: bool = False,
    ) -> None:
        if not jwks_url and not local_secret:
            raise ValueError("Either jwks_url or local_secret must be provided")

        self.jwks_url = jwks_url
        self.algorithms = algorithms or ["RS256"]
        self.audience = audience
        self.leeway = leeway
        self.local_secret = local_secret
        self.verify_aud = verify_aud
        self.jwks_headers = {**DEFAULT_JWKS_HEADERS, **(jwks_headers or {})}
        self._jwks_client: PyJWKClient | None = None

    # ----------------------------------------------------------------- public

    def verify(self, token: str, *, expected_token_type: str | None = None) -> dict[str, Any]:
        payload = self._verify_with_jwks(token) if self.jwks_url else None
        if payload is None and self.local_secret:
            payload = self._verify_locally(token)
        if payload is None:
            raise InvalidTokenError("No verification mechanism succeeded")

        if expected_token_type:
            actual = payload.get("token_type") or payload.get("type")
            if actual != expected_token_type:
                raise InvalidTokenError(
                    f"Token is of type {actual!r}, expected {expected_token_type!r}"
                )
        return payload

    # ---------------------------------------------------------------- helpers

    def _get_jwks_client(self) -> PyJWKClient:
        if self._jwks_client is None or self._jwks_client.uri != self.jwks_url:
            logger.debug("Initializing PyJWKClient for %s", self.jwks_url)
            self._jwks_client = PyJWKClient(self.jwks_url, headers=self.jwks_headers)
        return self._jwks_client

    def _verify_with_jwks(self, token: str) -> dict[str, Any] | None:
        try:
            signing_key = self._get_jwks_client().get_signing_key_from_jwt(token)
        except PyJWKClientError as exc:
            logger.warning("JWKS lookup failed: %s", exc)
            return None
        except Exception as exc:  # network / SSL / cloudflare
            logger.warning("JWKS request errored: %s", exc)
            return None

        return self._decode(token, signing_key.key)

    def _verify_locally(self, token: str) -> dict[str, Any]:
        secret = self.local_secret
        algorithm = self.algorithms[0] if self.algorithms else "RS256"

        if (
            algorithm.startswith("RS")
            and isinstance(secret, str)
            and "PRIVATE KEY" in secret
        ):
            try:
                private_key = serialization.load_pem_private_key(
                    secret.encode("utf-8"),
                    password=None,
                    backend=default_backend(),
                )
                secret = private_key.public_key().public_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PublicFormat.SubjectPublicKeyInfo,
                )
            except Exception as exc:
                raise InvalidTokenError(
                    f"Could not derive public key from local secret: {exc}"
                ) from exc

        return self._decode(token, secret)

    def _decode(self, token: str, key: Any) -> dict[str, Any]:
        try:
            return jwt.decode(
                token,
                key,
                algorithms=self.algorithms,
                audience=self.audience,
                leeway=self.leeway,
                options={"verify_aud": self.verify_aud and self.audience is not None},
            )
        except jwt.ExpiredSignatureError as exc:
            raise TokenExpiredError("Token expired") from exc
        except jwt.InvalidTokenError as exc:
            raise InvalidTokenError(f"Invalid token: {exc}") from exc
