"""Boolean Auth SDK - Python client for cidi-auth and auth.back services."""

from .client import AuthClient
from .verifier import JWTVerifier
from .types import TokenPair, UserProfile, Role
from .exceptions import (
    AuthSDKError,
    AuthenticationError,
    InvalidTokenError,
    TokenExpiredError,
    HTTPError,
)

__all__ = [
    "AuthClient",
    "JWTVerifier",
    "TokenPair",
    "UserProfile",
    "Role",
    "AuthSDKError",
    "AuthenticationError",
    "InvalidTokenError",
    "TokenExpiredError",
    "HTTPError",
]

__version__ = "0.1.0"
