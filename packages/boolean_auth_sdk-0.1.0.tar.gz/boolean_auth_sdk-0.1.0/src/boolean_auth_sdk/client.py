"""HTTP client for cidi-auth and auth.back authentication services."""

from __future__ import annotations

import logging
from typing import Any

import requests

from .exceptions import AuthenticationError, HTTPError
from .types import TokenPair, UserProfile

logger = logging.getLogger(__name__)


DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
)


class AuthClient:
    """Client for cidi-auth (CIDI cookie flow) and auth.back (user/password flow).

    Both backends expose a compatible REST surface under ``/v1/`` so a single
    client can target either service depending on ``base_url``.
    """

    def __init__(
        self,
        base_url: str,
        *,
        app_id: int | str | None = None,
        timeout: float = 10.0,
        session: requests.Session | None = None,
        token_header_scheme: str = "Token",
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        if not base_url:
            raise ValueError("base_url is required")
        self.base_url = base_url.rstrip("/")
        self.app_id = app_id
        self.timeout = timeout
        self.token_header_scheme = token_header_scheme
        self._session = session or requests.Session()
        self._default_headers = {
            "Accept": "application/json",
            "User-Agent": DEFAULT_USER_AGENT,
        }
        if extra_headers:
            self._default_headers.update(extra_headers)

    # ------------------------------------------------------------------ HTTP

    def _url(self, path: str) -> str:
        if not path.startswith("/"):
            path = "/" + path
        return f"{self.base_url}{path}"

    def _request(
        self,
        method: str,
        path: str,
        *,
        token: str | None = None,
        json_body: Any = None,
        extra_headers: dict[str, str] | None = None,
    ) -> Any:
        headers = dict(self._default_headers)
        if extra_headers:
            headers.update(extra_headers)
        if token:
            headers["Authorization"] = f"{self.token_header_scheme} {token}"

        try:
            response = self._session.request(
                method,
                self._url(path),
                json=json_body,
                headers=headers,
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise HTTPError(f"Request to {path} failed: {exc}") from exc

        if response.status_code in (401, 403):
            raise AuthenticationError(
                _extract_error(response) or f"Authentication failed ({response.status_code})"
            )
        if not (200 <= response.status_code < 300):
            raise HTTPError(
                _extract_error(response) or f"HTTP {response.status_code}",
                status_code=response.status_code,
                body=_safe_json(response),
            )

        if response.status_code == 204 or not response.content:
            return None
        return _safe_json(response)

    # ----------------------------------------------------------------- Auth

    def login_with_cidi(self, cookie: str, app_id: int | str | None = None) -> TokenPair:
        """Exchange a CIDI HashCookie for JWT tokens (cidi-auth flow)."""
        effective_app_id = app_id if app_id is not None else self.app_id
        if effective_app_id is None:
            raise ValueError("app_id is required for CIDI login")
        data = self._request(
            "POST",
            "/v1/auth/login/",
            json_body={"cookie": cookie, "app_id": int(effective_app_id)},
        )
        return TokenPair.from_response(data or {})

    def login_with_credentials(self, username: str, password: str) -> TokenPair:
        """Login with username/password (auth.back flow)."""
        data = self._request(
            "POST",
            "/v1/auth/login/",
            json_body={"username": username, "password": password},
        )
        return TokenPair.from_response(data or {})

    def refresh(self, refresh_token: str) -> TokenPair:
        """Use a refresh token (sent in Authorization header) to obtain new tokens."""
        data = self._request("POST", "/v1/auth/refresh/", token=refresh_token, json_body={})
        return TokenPair.from_response(data or {})

    def logout(self, access_token: str) -> None:
        """Invalidate the current session on the auth server."""
        self._request("POST", "/v1/auth/logout/", token=access_token, json_body={})

    # ----------------------------------------------------------------- User

    def me(self, access_token: str) -> UserProfile:
        data = self._request("GET", "/v1/user/me/", token=access_token)
        return UserProfile.from_response(data or {})

    def find_by_cuil(self, cuil: str, access_token: str) -> UserProfile:
        cleaned = str(cuil).replace("-", "").replace(" ", "")
        if len(cleaned) != 11 or not cleaned.isdigit():
            raise ValueError("CUIL must be 11 digits")
        data = self._request(
            "POST",
            "/v1/user/by-cuil/",
            token=access_token,
            json_body={"cuil": cleaned},
        )
        # Some backends wrap the user under "data"
        payload = data.get("data") if isinstance(data, dict) and "data" in data else data
        return UserProfile.from_response(payload or {})


def _safe_json(response: requests.Response) -> Any:
    try:
        return response.json()
    except ValueError:
        return response.text


def _extract_error(response: requests.Response) -> str | None:
    body = _safe_json(response)
    if isinstance(body, dict):
        return (
            body.get("detail")
            or body.get("error")
            or body.get("message")
        )
    if isinstance(body, str) and body:
        return body
    return None
