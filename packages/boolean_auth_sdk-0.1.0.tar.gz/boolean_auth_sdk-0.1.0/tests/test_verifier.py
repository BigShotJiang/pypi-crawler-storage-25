import time

import jwt
import pytest
import responses

from boolean_auth_sdk import (
    JWTVerifier,
    InvalidTokenError,
    TokenExpiredError,
)


JWKS_URL = "https://tokens.example.com/.well-known/jwks.json"


def _sign(payload, private_pem, kid="test-key-1"):
    return jwt.encode(payload, private_pem, algorithm="RS256", headers={"kid": kid})


@responses.activate
def test_verify_with_jwks(rsa_keypair, jwks_payload):
    responses.add(responses.GET, JWKS_URL, json=jwks_payload, status=200)
    token = _sign({"user_id": 1, "exp": int(time.time()) + 60}, rsa_keypair["private_pem"])

    v = JWTVerifier(jwks_url=JWKS_URL)
    payload = v.verify(token)
    assert payload["user_id"] == 1


@responses.activate
def test_token_type_check(rsa_keypair, jwks_payload):
    responses.add(responses.GET, JWKS_URL, json=jwks_payload, status=200)
    token = _sign(
        {"user_id": 1, "exp": int(time.time()) + 60, "token_type": "access"},
        rsa_keypair["private_pem"],
    )
    v = JWTVerifier(jwks_url=JWKS_URL)
    with pytest.raises(InvalidTokenError):
        v.verify(token, expected_token_type="refresh")


@responses.activate
def test_expired_token(rsa_keypair, jwks_payload):
    responses.add(responses.GET, JWKS_URL, json=jwks_payload, status=200)
    token = _sign({"user_id": 1, "exp": int(time.time()) - 10}, rsa_keypair["private_pem"])
    v = JWTVerifier(jwks_url=JWKS_URL)
    with pytest.raises(TokenExpiredError):
        v.verify(token)


@responses.activate
def test_jwks_failure_falls_back_to_local(rsa_keypair):
    responses.add(responses.GET, JWKS_URL, status=403)
    token = _sign({"user_id": 1, "exp": int(time.time()) + 60}, rsa_keypair["private_pem"])

    v = JWTVerifier(jwks_url=JWKS_URL, local_secret=rsa_keypair["private_pem"])
    payload = v.verify(token)
    assert payload["user_id"] == 1


def test_local_only_with_public_pem(rsa_keypair):
    token = _sign({"user_id": 1, "exp": int(time.time()) + 60}, rsa_keypair["private_pem"])
    v = JWTVerifier(local_secret=rsa_keypair["public_pem"])
    payload = v.verify(token)
    assert payload["user_id"] == 1


def test_requires_jwks_or_local():
    with pytest.raises(ValueError):
        JWTVerifier()
