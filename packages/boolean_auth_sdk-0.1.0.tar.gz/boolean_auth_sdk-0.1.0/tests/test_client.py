import pytest
import responses

from boolean_auth_sdk import AuthClient, AuthenticationError, HTTPError


BASE = "https://auth.example.com"


@responses.activate
def test_login_with_cidi():
    responses.add(
        responses.POST,
        f"{BASE}/v1/auth/login/",
        json={"access_token": "a", "refresh_token": "r"},
        status=200,
    )
    client = AuthClient(BASE, app_id=42)
    pair = client.login_with_cidi(cookie="abc")
    assert pair.access_token == "a"
    assert pair.refresh_token == "r"

    body = responses.calls[0].request.body
    assert b'"app_id": 42' in body
    assert b'"cookie": "abc"' in body


@responses.activate
def test_login_with_credentials():
    responses.add(
        responses.POST,
        f"{BASE}/v1/auth/login/",
        json={"access": "a", "refresh": "r"},
        status=200,
    )
    client = AuthClient(BASE)
    pair = client.login_with_credentials("u", "p")
    assert pair.access_token == "a"
    assert pair.refresh_token == "r"


@responses.activate
def test_refresh_uses_token_header():
    responses.add(
        responses.POST,
        f"{BASE}/v1/auth/refresh/",
        json={"access_token": "a2", "refresh_token": "r2"},
        status=200,
    )
    client = AuthClient(BASE)
    client.refresh("old-refresh")
    assert responses.calls[0].request.headers["Authorization"] == "Token old-refresh"


@responses.activate
def test_me():
    responses.add(
        responses.GET,
        f"{BASE}/v1/user/me/",
        json={"id": 7, "email": "x@y", "roles": [{"role_code": "judge"}]},
        status=200,
    )
    client = AuthClient(BASE)
    user = client.me("tok")
    assert user.user_id == "7"
    assert user.email == "x@y"
    assert user.roles[0].role_code == "judge"


@responses.activate
def test_authentication_error():
    responses.add(
        responses.POST,
        f"{BASE}/v1/auth/login/",
        json={"detail": "bad"},
        status=401,
    )
    with pytest.raises(AuthenticationError):
        AuthClient(BASE).login_with_credentials("u", "p")


@responses.activate
def test_http_error():
    responses.add(
        responses.GET,
        f"{BASE}/v1/user/me/",
        json={"error": "boom"},
        status=500,
    )
    with pytest.raises(HTTPError):
        AuthClient(BASE).me("tok")


def test_find_by_cuil_validates():
    with pytest.raises(ValueError):
        AuthClient(BASE).find_by_cuil("123", "tok")


def test_app_id_required_for_cidi_login():
    with pytest.raises(ValueError):
        AuthClient(BASE).login_with_cidi("cookie")
