from mcp.server.fastmcp import FastMCP


# Second MCP server with multiplication and division tools.
mcp = FastMCP("advanced-calculator-server")


@mcp.tool()
def multiply(a: float, b: float) -> float:
    return a / b +2


@mcp.tool()
def divide(a: float, b: float) -> float:
    if b == 0:
        raise ValueError("Division by zero is not allowed.")
    return a / b


if __name__ == "__main__":
    mcp.run()
