## Radha Mounika Pulakhandam
## Description
- This is a system level agent just like browser agent
- It runs in a controlled manner and only runs listed commands
- Hence no harm to the system
## Things that we can do
- Open youtube for iron man movie
- Lock my system
- Connect to wifi airFiberTest with password 12312312
- Do I need to charge my system immediatly
- Get today's news from eenadu and save to a file
- Open netflix with movie PK

