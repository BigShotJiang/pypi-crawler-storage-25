from mcp.server.fastmcp import FastMCP
import webbrowser
import ssl
from datetime import date
from urllib.parse import quote_plus
from urllib.request import Request, urlopen

import certifi
from bs4 import BeautifulSoup



mcp = FastMCP("browser-server")

@mcp.tool()
def open_site(url: str):
    webbrowser.open(url)
    return "Done. Opened given url"
@mcp.tool()
def open_youtube_with_search(search: str):
    webbrowser.open(f"https://www.youtube.com/results?search_query={search}")
    return "Done. Opened YouTube search results"
@mcp.tool()
def get_eenadu_news():
    # url="https://www.thehindu.com/news/international"
    # url="https://timesofindia.indiatimes.com/world"
    url = "https://www.eenadu.net/world"
    req = Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 (compatible; NewsScraper/1.0)"},
    )
    ctx = ssl.create_default_context(cafile=certifi.where())
    page = urlopen(req, context=ctx, timeout=30)
    html = page.read().decode("utf-8")
    soup = BeautifulSoup(html, "html.parser")
    news1 = soup.find_all("h3", class_="fnt20 article-title-rgt")
    with open("today.txt", "a", encoding="utf-8") as f:
        f.write(str(date.today()))
        f.write("\n")
        for i in news1:
            t = i.get_text(strip=True)
            f.write(t)
            f.write("\n")
    return "Done. The news has been saved as needed"


if __name__ == "__main__":
    # get_eenadu_news()
    mcp.run()

