from mcp.server.fastmcp import FastMCP
import webbrowser
import os
import subprocess
import psutil
mcp = FastMCP("system-server")

@mcp.tool()
def lock_screen():
    # os.system('pmset displaysleepnow')
    # https://stackoverflow.com/questions/54973241/applescript-application-is-not-allowed-to-send-keystrokes
    # execution error: System Events got an error: osascript is not allowed to send keystrokes. (1002)
    subprocess.run(["./lock.sh"])
    return "Done. Locked the screen"

@mcp.tool()
def connect_to_wifi(wifi_name: str, wifi_password: str):
    subprocess.run(["./connectToWifi.sh", wifi_name, wifi_password])
    return "Done. Connecting to given wifi"

@mcp.tool()
def get_battery_level():
    battery = psutil.sensors_battery()
    if battery:
        return f"Battery level: {battery.percent}%"
    return "No battery found"
@mcp.tool()
def shutdown():
    subprocess.run(["sudo", "/sbin/shutdown", "-h", "now"])
    return "Shutting down..."
if __name__ == "__main__":
    # lock_screen()
    # print(get_battery_level())
    # connect_to_wifi("oo", "123456788")
    # shutdown()
    mcp.run()