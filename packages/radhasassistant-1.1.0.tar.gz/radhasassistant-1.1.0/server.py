from mcp.server.fastmcp import FastMCP


# Minimal MCP server with two calculator tools.
mcp = FastMCP("calculator-server")


@mcp.tool()
def add(a: float, b: float) -> float:
    return a + b


@mcp.tool()
def subtract(a: float, b: float) -> float:
    return a - b


if __name__ == "__main__":
    mcp.run()
