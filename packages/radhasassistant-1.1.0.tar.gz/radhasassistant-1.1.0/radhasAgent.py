import asyncio
import json
import os
import getpass
import textwrap
from pathlib import Path
from contextlib import AsyncExitStack
from dataclasses import dataclass

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.types import CallToolResult
from openai import OpenAI
from dotenv import load_dotenv


def format_mcp_tool_result(tool_result: CallToolResult) -> str:
    """Serialize MCP CallToolResult for the model; content may be empty."""
    chunks: list[str] = []
    for block in tool_result.content:
        btype = getattr(block, "type", None)
        if btype == "text":
            chunks.append(block.text)
        else:
            chunks.append(block.model_dump_json())
    if tool_result.structuredContent:
        chunks.append(json.dumps(tool_result.structuredContent))
    out = "\n".join(chunks) if chunks else ""
    if tool_result.isError:
        return out if out else "Tool execution failed (no message from server)."
    return out if out else "Tool completed successfully (no text returned)."


@dataclass
class ManagedMCPClient:
    server: StdioServerParameters
    tools: list[dict]
    session: ClientSession | None = None
    _stack: AsyncExitStack | None = None

    async def connect(self) -> None:
        stack = AsyncExitStack()
        await stack.__aenter__()
        self._stack = stack
        read_stream, write_stream = await stack.enter_async_context(
            stdio_client(self.server)
        )
        self.session = await stack.enter_async_context(
            ClientSession(read_stream, write_stream)
        )
        await self.session.initialize()

    async def close(self) -> None:
        if self._stack is not None:
            await self._stack.__aexit__(None, None, None)
            self._stack = None
            self.session = None


async def main() -> None:
    load_dotenv()
    base_dir = Path(__file__).resolve().parent
    try:
        api_key = getpass.getpass("Enter OpenAI API key (input hidden): ").strip()
    except (EOFError, KeyboardInterrupt):
        raise
    except Exception:
        # Some terminals cannot disable echo; fall back to env var instead of visible input.
        api_key = ""
    if not api_key:
        api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "OpenAI API key is required. Set OPENAI_API_KEY in your environment/.env "
            "if hidden prompt input is not supported in your terminal."
        )
    ai = OpenAI(api_key=api_key)

    # Core math server: add/subtract
    math_client = ManagedMCPClient(
        server=StdioServerParameters(command="python3", args=[str(base_dir / "server.py")]),
        tools=[
            {
                "type": "function",
                "name": "add",
                "description": "Add two numbers",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "a": {"type": "number"},
                        "b": {"type": "number"},
                    },
                    "required": ["a", "b"],
                },
            },
            {
                "type": "function",
                "name": "subtract",
                "description": "Subtract b from a",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "a": {"type": "number"},
                        "b": {"type": "number"},
                    },
                    "required": ["a", "b"],
                },
            },
        ],
    )
    browser_client = ManagedMCPClient(
        server=StdioServerParameters(command="python3", args=[str(base_dir / "browserServer.py")]),
        tools=[
            {
                "type": "function",
                "name": "open_site",
                "description": "Open a URL in the user's default web browser.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "Full URL to open (e.g. https://example.com)",
                        },
                    },
                    "required": ["url"],
                },
            },
            {
                "type": "function",
                "name": "open_youtube_with_search",
                "description": "Open YouTube search results in the user's default browser. Prefer this over pasting links when the user wants to watch or search YouTube.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "search": {"type": "string"},
                    },
                    "required": ["search"],
                },
            },
            {
                "type":"function",
                "name":"get_eenadu_news",
                "description":"get todays news and save to today.txt"
            }
        ],
    )

    # Second math server: multiply/divide
    advanced_math_client = ManagedMCPClient(
        server=StdioServerParameters(command="python3", args=[str(base_dir / "server_advanced.py")]),
        tools=[
            {
                "type": "function",
                "name": "multiply",
                "description": "Multiply two numbers",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "a": {"type": "number"},
                        "b": {"type": "number"},
                    },
                    "required": ["a", "b"],
                },
            },
            {
                "type": "function",
                "name": "divide",
                "description": "Divide a by b",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "a": {"type": "number"},
                        "b": {"type": "number"},
                    },
                    "required": ["a", "b"],
                },
            },
        ],
    )
    system_client = ManagedMCPClient(
        server=StdioServerParameters(command="python3", args=[str(base_dir / "systemServer.py")]),
        tools=[
            {
                "type": "function",
                "name": "lock_screen",
                "description": "This tool would be helpful to lock your system"
            },
            {
                "type": "function",
                "name": "connect_to_wifi",
                "description":"This tool would be helpful in connecting wifi",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "wifi_name": {"type": "string"},
                        "wifi_password": {"type": "string"},
                    },
                    "required": ["wifi_name", "wifi_password"],
                },
            },
            {
                "type": "function",
                "name": "get_battery_level",
                "description":"this tool would be helpful in getting the current battery level"
            }
        ],
    )   


    clients = [math_client ,browser_client,system_client]
    tool_to_client: dict[str, ManagedMCPClient] = {}
    for c in clients:
        for tool in c.tools:
            tool_to_client[tool["name"]] = c

    for c in clients:
        await c.connect()

    all_tools = [tool for c in clients for tool in c.tools]
    print("\nCapabilities")
    print("-" * 72)
    for tool in all_tools:
        desc = tool.get("description", "No description")
        wrapped = textwrap.fill(
            desc,
            width=72,
            initial_indent=f"- {tool['name']:<22} ",
            subsequent_indent=" " * 26,
        )
        print(wrapped)
    print("-" * 72)
    print("Chatbot ready. Type 'exit' to quit.")

    try:
        while True:
            user_text = input("\nYou: ").strip()
            if user_text.lower() in {"exit", "quit"}:
                break
            if not user_text:
                continue

            first = ai.responses.create(
                model="gpt-5.4-mini",
                instructions=(
                    "If the user wants a website opened or a YouTube search launched, "
                    "call open_site or open_youtube_with_search so the browser opens locally. "
                    "Do not satisfy those requests with only a plain-text or markdown link."
                    "If the user wants to connect to a WiFi network, call connect_to_wifi so the system connects to the network."
                    "If the user wants to lock the screen, call lock_screen so the system locks the screen."
                ),
                input=user_text,
                tools=all_tools,
            )

            fn_call = next(
                (item for item in first.output if item.type == "function_call"),
                None,
            )
            if fn_call is None:
                print("Assistant:", first.output_text)
                continue

            client = tool_to_client.get(fn_call.name)
            if client is None or client.session is None:
                print("Assistant: Tool routing error.")
                continue

            args = json.loads(fn_call.arguments)
            tool_result = await client.session.call_tool(fn_call.name, args)
            tool_output = format_mcp_tool_result(tool_result)

            if(tool_output.startswith("Done")):
                print("Assistant :",tool_output )
                continue
            second = ai.responses.create(
                model="gpt-5.4-mini",
                previous_response_id=first.id,
                input=[
                    {
                        "type": "function_call_output",
                        "call_id": fn_call.call_id,
                        "output": tool_output,
                    }
                ],
            )
            print("Assistant:", second.output_text)
    finally:
        # Multiple stdio clients nest AnyIO cancel scopes on this task; teardown must be
        # LIFO (last connected first) or anyio raises during stdio_client shutdown.
        for c in reversed(clients):
            await c.close()


def cli() -> None:
    asyncio.run(main())


if __name__ == "__main__":
    cli()
