from importlib.metadata import version

__version__ = version("helix-memory")
