# Changelog

## 0.1.0

**Initial release.**

### Added

- **ULIDField** – custom Tortoise ORM field generating time-sortable ULID primary keys stored as UUID in the database.
- **TimestampedModel** – abstract base model with ULID PK, `created_at`, and `updated_at`.
- **OrganizationScopedModel** – abstract base model that auto-filters queries by `organization_id` from `vanty-auth`'s `AuthContext`. Includes `unscoped` manager for bypassing the filter.
- **OrganizationManager** – Tortoise ORM manager that reads `organization_id` from the active `AuthContext` and applies it to every queryset. Fail-closed: returns empty results when no context is available.
- **SecurityScannerBlockerMiddleware** – ASGI middleware that blocks common vulnerability scanner paths (`.env`, `wp-admin`, `.git`, etc.) with a 403 response.
- **Rate limiting** – `create_limiter()` factory wrapping `slowapi` with support for in-memory, Redis, and Memcached backends.
- **TaskIQ integration** – broker factory, `AuthContextTaskMiddleware` for propagating auth context into background tasks, and `send_with_context()` helper.
- **CoreSettings** – pydantic-settings configuration for blocked patterns, rate limit storage, and defaults.
