"""Vanty Core — framework for building Vanty Apps.

Provides the ``AppConfig`` base class, the ``AppRegistry`` lifecycle owner,
the typed event bus, ULID-keyed Tortoise base models, the security
middleware, and the TaskIQ broker factory.

Other Vanty packages (``vanty-auth``, ``vanty-payments``, ``vanty-mail``,
``vanty-crm``, ``vanty-content``, ``vanty-ai``, ``vanty-cli``,
``vanty-ai-utils``) are Vanty Apps installed through the registry.
"""

from vanty_core.apps import (
    AppConfig,
    AppRegistry,
    AppRegistryError,
    RegistryNotReady,
    current_broker,
    current_registry,
)

__all__ = [
    "AppConfig",
    "AppRegistry",
    "AppRegistryError",
    "RegistryNotReady",
    "current_broker",
    "current_registry",
]
