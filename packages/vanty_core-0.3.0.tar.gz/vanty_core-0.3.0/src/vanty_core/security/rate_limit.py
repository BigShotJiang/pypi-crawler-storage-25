from __future__ import annotations

from slowapi import Limiter
from slowapi.util import get_remote_address


def create_limiter(
    storage_uri: str | None = None,
    default_limits: list[str] | None = None,
    key_func=None,
) -> Limiter:
    return Limiter(
        key_func=key_func or get_remote_address,
        default_limits=default_limits or ["60/minute"],
        storage_uri=storage_uri or "memory://",
    )
