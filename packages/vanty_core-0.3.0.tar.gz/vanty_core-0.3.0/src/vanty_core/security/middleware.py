from __future__ import annotations

BLOCKED_PATTERNS = [
    "/.env",
    "/wp-admin",
    "/wp-login",
    "/.git",
    "/phpmyadmin",
    "/xmlrpc.php",
    "/administrator",
    "/config.php",
    "/wp-content",
    "/wp-includes",
    "/.well-known/security.txt",
    "/cgi-bin",
    "/vendor",
    "/.svn",
    "/.hg",
    "/.DS_Store",
]


class SecurityScannerBlockerMiddleware:
    def __init__(self, app, *, blocked_patterns: list[str] | None = None) -> None:
        self.app = app
        self.patterns = blocked_patterns or BLOCKED_PATTERNS

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] == "http":
            path: str = scope.get("path", "")
            if any(path.startswith(p) or path.endswith(p) for p in self.patterns):
                await self._send_403(send)
                return
        await self.app(scope, receive, send)

    @staticmethod
    async def _send_403(send) -> None:
        await send(
            {
                "type": "http.response.start",
                "status": 403,
                "headers": [(b"content-type", b"text/plain")],
            }
        )
        await send({"type": "http.response.body", "body": b"Forbidden"})
