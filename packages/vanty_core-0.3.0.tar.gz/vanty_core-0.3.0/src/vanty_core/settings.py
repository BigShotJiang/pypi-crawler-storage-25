from __future__ import annotations

from pydantic_settings import BaseSettings


class CoreSettings(BaseSettings):
    model_config = {"env_prefix": "VANTY_CORE_"}

    blocked_patterns: list[str] | None = None
    rate_limit_storage_uri: str = "memory://"
    rate_limit_default: str = "60/minute"
