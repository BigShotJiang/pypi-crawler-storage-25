"""Pluggable resolver for the current organization id.

vanty-core defines the ``OrganizationScopedModel`` and ``OrganizationManager``
without knowing how the host gets the current organization. Apps that own
auth (``vanty-auth``) install their resolver during ``AppConfig.on_configure``
by calling ``set_organization_resolver(callable)``.

The resolver returns ``str | None``; ``None`` means there is no
organization in the current async context (anonymous request, background
job not running under an envelope).
"""

from __future__ import annotations

from collections.abc import Callable

type OrganizationResolver = Callable[[], str | None]


def _no_resolver() -> str | None:
    return None


_resolver: OrganizationResolver = _no_resolver


def set_organization_resolver(resolver: OrganizationResolver | None) -> None:
    """Install a callable returning the current organization id (or None).

    Pass ``None`` to clear the resolver (useful in tests)."""
    global _resolver
    _resolver = resolver if resolver is not None else _no_resolver


def get_current_organization_id() -> str | None:
    return _resolver()
