from __future__ import annotations

from tortoise.manager import Manager
from tortoise.queryset import QuerySet

from vanty_core.db.context import get_current_organization_id


class OrganizationManager(Manager):
    """Default manager for ``OrganizationScopedModel``.

    Filters every queryset by the organization id resolved through
    ``vanty_core.db.context.get_current_organization_id``. When no
    organization is active the manager returns an empty queryset so unscoped
    reads are not silently allowed; use ``Model.unscoped`` for cross-tenant
    work.
    """

    def get_queryset(self) -> QuerySet:
        qs = super().get_queryset()
        org_id = get_current_organization_id()
        if org_id is None:
            return qs.filter(id=None)
        return qs.filter(organization_id=org_id)
