from __future__ import annotations

from typing import Any

import ulid
from tortoise.fields import Field
from tortoise.models import Model


def new_ulid() -> str:
    return str(ulid.ULID().to_uuid())


class ULIDField(Field[str]):
    SQL_TYPE = "UUID"
    allows_generated = True

    def __init__(self, *, primary_key: bool = False, **kwargs: Any) -> None:
        if primary_key:
            kwargs.setdefault("default", new_ulid)
        super().__init__(primary_key=primary_key, **kwargs)

    def to_db_value(self, value: Any, instance: type[Model] | Model) -> str | None:
        if value is None:
            return None
        if hasattr(value, "to_uuid"):
            return str(value.to_uuid())
        return str(value)

    def to_python_value(self, value: Any) -> str | None:
        if value is None:
            return None
        return str(value)
