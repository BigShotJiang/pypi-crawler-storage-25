from __future__ import annotations

from tortoise import fields
from tortoise.manager import Manager
from tortoise.models import Model

from vanty_core.db.context import get_current_organization_id
from vanty_core.db.fields import ULIDField
from vanty_core.db.managers import OrganizationManager


class TimestampedModel(Model):
    id = ULIDField(primary_key=True)
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        abstract = True


class OrganizationScopedModel(TimestampedModel):
    organization_id = fields.UUIDField(db_index=True)

    unscoped = Manager()

    class Meta:
        abstract = True
        manager = OrganizationManager()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        meta_info = getattr(cls, "_meta", None)
        if meta_info and not getattr(meta_info, "abstract", False):
            if type(meta_info.manager) is Manager:
                meta_info.manager = OrganizationManager()

    async def save(self, *args, **kwargs):
        if not self.organization_id:
            org_id = get_current_organization_id()
            if org_id:
                self.organization_id = org_id
        await super().save(*args, **kwargs)
