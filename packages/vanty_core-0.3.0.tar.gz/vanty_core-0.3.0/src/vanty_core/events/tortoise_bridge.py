"""Bridge Tortoise ORM signals into Vanty domain events.

Tortoise emits low-level `pre_save`, `post_save`, `pre_delete`, `post_delete`
signals on individual model classes (registered via `Model.register_listener`).
Often we want to translate those into *domain* events the rest of the app
cares about (for instance, every time a `User` row is inserted, publish
`vanty_auth.user.signed_up`).

Usage::

    from tortoise.signals import Signals

    bridge_tortoise_signal(
        model=User,
        signal=Signals.post_save,
        event_factory=lambda instance, created, **_: (
            UserSignedUp(user_id=instance.id, email=instance.email)
            if created
            else None
        ),
    )

The factory may return `None` to skip publishing for a particular row event
(e.g. only emit on `created=True`). Returns the registered callback so callers
can clean up via `Model._listeners[signal].remove(callback)` during teardown.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from tortoise.signals import Signals

from vanty_core.events.bus import EventBus, get_default_bus


def bridge_tortoise_signal(
    *,
    model: type,
    signal: Signals,
    event_factory: Callable[..., Any | None],
    bus: EventBus | None = None,
) -> Callable[..., Any]:
    """Connect a Tortoise signal to the event bus.

    `model` must be a Tortoise model class (it must expose `register_listener`).
    Returns the registered async callback so callers can disconnect later.
    """
    target_bus = bus or get_default_bus()

    if signal in (Signals.post_save, Signals.pre_save):
        async def _callback(
            sender: type,
            instance: Any,
            created: bool,
            using_db: Any,
            update_fields: Any,
        ) -> None:
            domain_event = event_factory(
                instance=instance,
                sender=sender,
                created=created,
                using_db=using_db,
                update_fields=update_fields,
            )
            if domain_event is None:
                return
            await target_bus.publish(domain_event)
    else:
        async def _callback(  # type: ignore[no-redef]
            sender: type,
            instance: Any,
            using_db: Any,
        ) -> None:
            domain_event = event_factory(
                instance=instance,
                sender=sender,
                using_db=using_db,
            )
            if domain_event is None:
                return
            await target_bus.publish(domain_event)

    model.register_listener(signal, _callback)
    return _callback
