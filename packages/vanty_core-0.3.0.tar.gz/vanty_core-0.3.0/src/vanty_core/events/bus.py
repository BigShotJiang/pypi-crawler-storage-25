"""In-process async event bus implementation.

Design goals:

- Typed: handlers subscribe to a concrete dataclass type, not a string.
- Concurrent: multiple handlers for the same event run with `asyncio.gather`,
  handler errors are isolated and logged (do not break the publisher).
- Observable: every publish opens a Logfire span; each handler invocation
  opens a child span tagged with the handler module + name.
- Optional background dispatch: handlers can declare `dispatch="background"`
  to be enqueued onto a TaskIQ task instead of awaited inline. If TaskIQ is
  not installed, background handlers fall back to inline execution.
- Sync wrapper: `publish_sync` schedules a publish onto the running loop
  when called from sync code, or starts a short-lived loop otherwise. Useful
  for Tortoise signal handlers and Stripe webhook handlers that may be
  invoked from sync code paths.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import threading
from collections.abc import Awaitable, Callable, Iterable
from dataclasses import dataclass, field
from typing import Any, ClassVar, Literal, TypeVar, get_type_hints

logger = logging.getLogger("vanty_core.events")

EventT = TypeVar("EventT")
EventName = str

DispatchMode = Literal["inline", "background"]

EventHandler = Callable[[EventT], Awaitable[None] | None]


class EventDispatchError(RuntimeError):
    """Raised when event dispatch fails in a way the caller should know about.

    Individual handler errors are caught and logged; this exception is only
    raised for misconfiguration (unknown event class, invalid handler signature).
    """


@dataclass(frozen=True)
class EventSpec:
    """Metadata about a registered event class."""

    name: EventName
    cls: type
    description: str | None = None


@dataclass
class _Subscription:
    handler: EventHandler[Any]
    dispatch: DispatchMode
    handler_name: str
    handler_module: str


@dataclass
class EventRegistry:
    """Registry of known event classes keyed by both name and class."""

    _by_name: dict[EventName, EventSpec] = field(default_factory=dict)
    _by_cls: dict[type, EventSpec] = field(default_factory=dict)

    def register(self, name: EventName, cls: type, *, description: str | None = None) -> EventSpec:
        existing = self._by_name.get(name)
        if existing is not None and existing.cls is not cls:
            raise EventDispatchError(
                f"event name {name!r} already registered for {existing.cls.__module__}.{existing.cls.__qualname__}"
            )
        spec = EventSpec(name=name, cls=cls, description=description)
        self._by_name[name] = spec
        self._by_cls[cls] = spec
        return spec

    def get_by_name(self, name: EventName) -> EventSpec | None:
        return self._by_name.get(name)

    def get_by_cls(self, cls: type) -> EventSpec | None:
        return self._by_cls.get(cls)

    def list(self) -> list[EventSpec]:
        return sorted(self._by_name.values(), key=lambda s: s.name)


class EventBus:
    """Async pub/sub bus.

    The bus owns the handler registry but delegates event class registration
    to the shared module-level registry so that `@event` decorators don't
    need a bus reference at import time.
    """

    _registry: ClassVar[EventRegistry] = EventRegistry()

    def __init__(self, *, name: str = "default") -> None:
        self.name = name
        self._handlers: dict[type, list[_Subscription]] = {}
        self._lock = threading.Lock()
        self._background_dispatcher: Callable[[Callable[[], Awaitable[None]]], Any] | None = None

    @classmethod
    def registry(cls) -> EventRegistry:
        return cls._registry

    def set_background_dispatcher(
        self, dispatcher: Callable[[Callable[[], Awaitable[None]]], Any] | None
    ) -> None:
        """Plug in a background runner (e.g. TaskIQ broker.kick).

        The dispatcher receives a zero-arg coroutine factory. If `None`,
        background-marked handlers fall back to inline execution.
        """
        self._background_dispatcher = dispatcher

    def subscribe(
        self,
        event_cls: type[EventT],
        handler: EventHandler[EventT],
        *,
        dispatch: DispatchMode = "inline",
    ) -> Callable[[], None]:
        """Register a handler. Returns an unsubscribe callable."""
        spec = self._registry.get_by_cls(event_cls)
        if spec is None:
            raise EventDispatchError(
                f"event class {event_cls.__module__}.{event_cls.__qualname__} not registered with @event"
            )
        sub = _Subscription(
            handler=handler,
            dispatch=dispatch,
            handler_name=getattr(handler, "__qualname__", repr(handler)),
            handler_module=getattr(handler, "__module__", "<unknown>"),
        )
        with self._lock:
            self._handlers.setdefault(event_cls, []).append(sub)

        def _unsubscribe() -> None:
            with self._lock:
                subs = self._handlers.get(event_cls)
                if not subs:
                    return
                self._handlers[event_cls] = [s for s in subs if s is not sub]

        return _unsubscribe

    def unsubscribe(self, event_cls: type[EventT], handler: EventHandler[EventT]) -> None:
        with self._lock:
            subs = self._handlers.get(event_cls)
            if not subs:
                return
            self._handlers[event_cls] = [s for s in subs if s.handler is not handler]

    def clear(self, event_cls: type | None = None) -> None:
        """Remove all handlers (for tests)."""
        with self._lock:
            if event_cls is None:
                self._handlers.clear()
            else:
                self._handlers.pop(event_cls, None)

    def list_handlers(self, event_cls: type | None = None) -> list[_Subscription]:
        with self._lock:
            if event_cls is None:
                return [s for subs in self._handlers.values() for s in subs]
            return list(self._handlers.get(event_cls, []))

    async def publish(self, event: Any) -> None:
        """Dispatch `event` to every subscribed handler concurrently.

        Handler exceptions are logged and suppressed so a single buggy handler
        cannot break the publisher.
        """
        spec = self._registry.get_by_cls(type(event))
        if spec is None:
            raise EventDispatchError(
                f"event instance of {type(event).__module__}.{type(event).__qualname__} "
                "not registered with @event"
            )
        with self._lock:
            subs = list(self._handlers.get(type(event), []))
        if not subs:
            return

        with _logfire_span("vanty_core.event.publish", event_name=spec.name, handler_count=len(subs)):
            await asyncio.gather(*(self._invoke(sub, event, spec) for sub in subs))

    def publish_sync(self, event: Any) -> None:
        """Schedule `event` from sync code.

        If a running loop is detected (e.g. inside a sync Tortoise signal
        handler within an async task), the publish is scheduled on that loop.
        Otherwise a short-lived loop runs it to completion.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(self.publish(event))
            return
        loop.create_task(self.publish(event))

    async def _invoke(self, sub: _Subscription, event: Any, spec: EventSpec) -> None:
        if sub.dispatch == "background" and self._background_dispatcher is not None:
            try:
                self._background_dispatcher(lambda: self._call_handler(sub, event, spec))
                return
            except Exception:
                logger.exception(
                    "vanty_core.events.background_dispatch_failed",
                    extra={"event": spec.name, "handler": sub.handler_name},
                )

        await self._call_handler(sub, event, spec)

    async def _call_handler(self, sub: _Subscription, event: Any, spec: EventSpec) -> None:
        with _logfire_span(
            "vanty_core.event.handler",
            event_name=spec.name,
            handler=f"{sub.handler_module}.{sub.handler_name}",
        ):
            try:
                result = sub.handler(event)
                if inspect.isawaitable(result):
                    await result
            except Exception:
                logger.exception(
                    "vanty_core.events.handler_error",
                    extra={"event": spec.name, "handler": sub.handler_name},
                )


_default_bus = EventBus(name="default")


def get_default_bus() -> EventBus:
    return _default_bus


def set_default_bus(bus: EventBus) -> None:
    global _default_bus
    _default_bus = bus


def event(
    name: EventName,
    *,
    description: str | None = None,
) -> Callable[[type[EventT]], type[EventT]]:
    """Class decorator: register a dataclass as a domain event.

    The decorator does not turn the class into a dataclass automatically — the
    caller declares it as a `@dataclass` (or any class). The decorator only
    records `(name, cls)` in the shared registry so the bus knows which name
    to log and lets handlers subscribe by class.

    Example:

        @event("user.signed_up")
        @dataclass(frozen=True)
        class UserSignedUp:
            user_id: UUID
            email: str
    """

    def _decorator(cls: type[EventT]) -> type[EventT]:
        get_type_hints(cls)
        EventBus.registry().register(name, cls, description=description)
        cls.__vanty_event_name__ = name
        return cls

    return _decorator


def on[EventT](
    event_cls: type[EventT],
    *,
    bus: EventBus | None = None,
    dispatch: DispatchMode = "inline",
) -> Callable[[EventHandler[EventT]], EventHandler[EventT]]:
    """Decorator to subscribe a function to an event class.

    Example:

        @on(UserSignedUp)
        async def _send_welcome(evt: UserSignedUp) -> None:
            await mail_service.send_welcome(evt.email)
    """

    def _decorator(handler: EventHandler[EventT]) -> EventHandler[EventT]:
        target = bus or get_default_bus()
        target.subscribe(event_cls, handler, dispatch=dispatch)
        return handler

    return _decorator


async def publish(event: Any, *, bus: EventBus | None = None) -> None:
    target = bus or get_default_bus()
    await target.publish(event)


def publish_sync(event: Any, *, bus: EventBus | None = None) -> None:
    target = bus or get_default_bus()
    target.publish_sync(event)


def subscribe[EventT](
    event_cls: type[EventT],
    handler: EventHandler[EventT],
    *,
    bus: EventBus | None = None,
    dispatch: DispatchMode = "inline",
) -> Callable[[], None]:
    target = bus or get_default_bus()
    return target.subscribe(event_cls, handler, dispatch=dispatch)


def unsubscribe[EventT](
    event_cls: type[EventT],
    handler: EventHandler[EventT],
    *,
    bus: EventBus | None = None,
) -> None:
    target = bus or get_default_bus()
    target.unsubscribe(event_cls, handler)


def clear_handlers(event_cls: type | None = None, *, bus: EventBus | None = None) -> None:
    target = bus or get_default_bus()
    target.clear(event_cls)


def get_event_spec(event_cls: type) -> EventSpec | None:
    return EventBus.registry().get_by_cls(event_cls)


def list_events() -> list[EventSpec]:
    return EventBus.registry().list()


def list_handlers(event_cls: type | None = None, *, bus: EventBus | None = None) -> list[_Subscription]:
    target = bus or get_default_bus()
    return target.list_handlers(event_cls)


def _logfire_span(name: str, **attrs: Any) -> Any:
    """Open a Logfire span if logfire is installed; otherwise a no-op context."""
    try:
        import logfire  # type: ignore
    except ImportError:
        return _NullSpan()
    return logfire.span(name, **attrs)


class _NullSpan:
    def __enter__(self) -> _NullSpan:
        return self

    def __exit__(self, *args: object) -> None:
        return None


def _ensure_iterable[EventT](value: Iterable[EventT] | EventT) -> Iterable[EventT]:
    if isinstance(value, Iterable) and not isinstance(value, (str, bytes)):
        return value
    return (value,)
