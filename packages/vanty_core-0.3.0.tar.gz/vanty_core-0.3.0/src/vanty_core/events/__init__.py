"""Typed in-process event bus for Vanty Apps.

Every Vanty App (``vanty-auth``, ``vanty-payments``, ``vanty-ai``,
``vanty-crm``, ``vanty-mail``, ``vanty-content``, plus host-local apps)
publishes typed domain events from its ``events.py`` module. Other apps
subscribe with the ``@on(EventClass)`` decorator from their ``signals.py``
or service code.

The bus is in-process and async-first. Slow handlers can opt into background
dispatch via TaskIQ when configured. Tortoise post-save signals can be
bridged into domain events using ``bridge_tortoise_signal``.
"""

from vanty_core.events.bus import (
    EventBus,
    EventDispatchError,
    EventHandler,
    EventName,
    EventRegistry,
    EventSpec,
    clear_handlers,
    event,
    get_default_bus,
    get_event_spec,
    list_events,
    list_handlers,
    on,
    publish,
    publish_sync,
    set_default_bus,
    subscribe,
    unsubscribe,
)
from vanty_core.events.tortoise_bridge import bridge_tortoise_signal

__all__ = [
    "EventBus",
    "EventDispatchError",
    "EventHandler",
    "EventName",
    "EventRegistry",
    "EventSpec",
    "bridge_tortoise_signal",
    "clear_handlers",
    "event",
    "get_default_bus",
    "get_event_spec",
    "list_events",
    "list_handlers",
    "on",
    "publish",
    "publish_sync",
    "set_default_bus",
    "subscribe",
    "unsubscribe",
]
