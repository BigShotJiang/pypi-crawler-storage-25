"""AppConfig — composition root + registration entry for a Vanty app.

A Vanty app subclasses ``AppConfig`` in ``<pkg>/apps.py``. The subclass:

* Declares static metadata (label, version, dotted paths to router/events/etc.)
  as class attributes.
* Constructs its services in ``__init__(settings)`` and exposes them as
  instance attributes.
* Implements lifecycle hooks for cross-cutting wiring.

Apps never call ``Tortoise.init`` or ``app.include_router`` themselves — the
``AppRegistry`` does. Apps never import each other's services — they emit and
subscribe to typed events on the shared bus.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar

if TYPE_CHECKING:
    from vanty_core.apps.registry import AppRegistry


class AppConfig:
    """Base class for every Vanty app's composition root.

    Subclass this in ``<pkg>/apps.py`` and override the metadata class
    attributes plus ``__init__`` (to construct services) and any lifecycle
    hooks you need.
    """

    name: ClassVar[str] = ""
    """Importable Python package name, e.g. ``vanty_mail``."""

    label: ClassVar[str] = ""
    """Short, unique, URL-safe identifier reused as router prefix and event
    namespace prefix, e.g. ``mail``."""

    version: ClassVar[str] = "0.0.0"

    depends_on: ClassVar[tuple[str, ...]] = ()
    """Tuple of labels this app depends on. Used for topological install
    ordering only. Apps still never import each other's services."""

    models_module: ClassVar[str | None] = None
    """Dotted path to the Tortoise models module, e.g.
    ``vanty_mail.db.models``. Aggregated by the registry into a single
    ``Tortoise.init`` call."""

    router_attr: ClassVar[str | None] = None
    """``module:attribute`` pointing at the public ``APIRouter``."""

    admin_router_attr: ClassVar[str | None] = None
    """``module:attribute`` pointing at the admin ``APIRouter`` (mounted with
    the registry's admin dependencies)."""

    events_module: ClassVar[str | None] = None
    """Dotted path to the events module. Imported eagerly so ``@event``
    decorators populate the bus registry."""

    signals_module: ClassVar[str | None] = None
    """Dotted path to a module exposing ``install() -> None`` that registers
    Tortoise signal bridges. Called from ``on_ready``."""

    tasks_module: ClassVar[str | None] = None
    """Dotted path to a module declaring TaskIQ tasks. Imported eagerly."""

    cli_app_attr: ClassVar[str | None] = None
    """``module:attribute`` pointing at a ``typer.Typer`` sub-app. Aggregated
    by ``vanty-cli`` under ``vanty <label> ...``."""

    def __init__(self, settings: Any | None = None) -> None:
        """Construct services and bind them as attributes.

        Subclasses MUST override this and assign each service as
        ``self.<service_name>``. No I/O, no ORM queries, no HTTP calls.
        """
        self.settings = settings

    # ------------------------------------------------------------------
    # Lifecycle hooks — called by AppRegistry in this exact order.
    # ------------------------------------------------------------------

    def on_configure(self, registry: AppRegistry) -> None:
        """Sync. Runs after every app is instantiated, before ORM init.

        Use for: registering plugins, strategies, custom RBAC roles.
        Do NOT: query the ORM, make HTTP calls, subscribe to other apps'
        events (use ``on_ready`` for that).
        """

    async def on_ready(self, registry: AppRegistry) -> None:
        """Async. Runs after every app's ``on_configure``, before ORM init.

        Use for: subscribing to other apps' events with ``on(EventCls)``,
        installing Tortoise signal bridges via ``signals.install()``.
        Do NOT: query the ORM (schema not ready).
        """

    async def on_startup(self, registry: AppRegistry) -> None:
        """Async. Runs after ``Tortoise.init`` and broker startup.

        Use for: warming caches, seeding defaults, loading secrets from DB.
        Do NOT: kick off long-running tasks (use the broker for that).
        """

    async def on_shutdown(self, registry: AppRegistry) -> None:
        """Async. Runs before broker stop and ``Tortoise.close_connections``.

        Use for: flushing buffers, closing external HTTP clients.
        Do NOT: write to the ORM (assume the connection is dying).
        """
