"""The Vanty App pattern: AppConfig + AppRegistry.

A Vanty App is a Python package whose ``apps.py`` exposes a single
``AppConfig`` subclass. The host wires every installed app through one
``AppRegistry`` per process.

Example host bootstrap::

    import os
    from fastapi import Depends, FastAPI
    from vanty_core.apps import AppRegistry
    from vanty_auth import AuthContextMiddleware
    from apps.core.dependencies import require_superuser

    registry = AppRegistry(
        database_url=os.environ["DATABASE_URL"],
        broker_url=os.environ.get("BROKER_URL"),
    )
    for label in ("vanty_auth", "vanty_payments", "vanty_mail",
                  "vanty_crm", "vanty_content"):
        registry.install(label)

    app = FastAPI(lifespan=registry.lifespan)
    app.add_middleware(AuthContextMiddleware)
    registry.mount(app, admin_dependencies=[Depends(require_superuser)])
"""

from vanty_core.apps.config import AppConfig
from vanty_core.apps.context import (
    RegistryNotReady,
    current_broker,
    current_registry,
)
from vanty_core.apps.registry import AppRegistry, AppRegistryError

__all__ = [
    "AppConfig",
    "AppRegistry",
    "AppRegistryError",
    "RegistryNotReady",
    "current_broker",
    "current_registry",
]
