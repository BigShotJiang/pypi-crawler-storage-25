"""AppRegistry — owns ORM, broker, and lifecycle for every installed Vanty app.

The host instantiates exactly one ``AppRegistry`` per process, calls
``install(...)`` for each app, then mounts routers and yields control to
FastAPI's lifespan.

Construction sequence (driven by ``lifespan``):

1. Import every app's ``events_module``, ``signals_module``, ``tasks_module``.
2. Topologically sort apps by ``depends_on``.
3. Call every app's ``on_configure`` (sync).
4. Call every app's ``on_ready`` (async).
5. ``await Tortoise.init(db_url=..., modules={"models": [...]})``.
6. ``await Tortoise.generate_schemas(safe=True)``.
7. Start TaskIQ broker.
8. Call every app's ``on_startup`` (async).
9. Yield (FastAPI serves traffic).
10. Reverse: ``on_shutdown`` → broker stop → ``Tortoise.close_connections``.
"""

from __future__ import annotations

import importlib
from collections.abc import AsyncIterator, Iterable, Iterator
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

from tortoise import Tortoise

from vanty_core.apps.config import AppConfig
from vanty_core.apps.context import _bind, _unbind
from vanty_core.tasks.broker import create_broker

if TYPE_CHECKING:
    from fastapi import FastAPI
    from taskiq import AsyncBroker


class AppRegistryError(RuntimeError):
    pass


class AppRegistry:
    """Single source of truth for installed apps + cross-cutting infrastructure."""

    def __init__(self, *, database_url: str, broker_url: str | None = None) -> None:
        if not database_url:
            raise AppRegistryError("AppRegistry requires a non-empty database_url")
        self.database_url = database_url
        self._broker: AsyncBroker = create_broker(broker_url)
        self._apps: dict[str, AppConfig] = {}
        self._sorted: list[AppConfig] | None = None
        self._orm_initialized = False
        self._broker_started = False
        _bind(self, self._broker)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def broker(self) -> AsyncBroker:
        return self._broker

    def install(
        self,
        app: type[AppConfig] | AppConfig | str,
        *,
        settings: Any | None = None,
    ) -> AppConfig:
        """Register an app.

        Accepts:

        * A subclass of ``AppConfig`` (instantiated with ``settings``).
        * An already-constructed ``AppConfig`` instance.
        * A dotted package name like ``"vanty_mail"`` — the registry imports
          ``<pkg>.apps`` and finds the single ``AppConfig`` subclass defined
          there.
        """
        cfg = self._resolve(app, settings)
        if cfg.label in self._apps:
            raise AppRegistryError(f"app with label {cfg.label!r} already installed")
        if not cfg.label:
            raise AppRegistryError(f"{type(cfg).__name__} must define a non-empty label")
        self._apps[cfg.label] = cfg
        self._sorted = None
        return cfg

    def get(self, label: str) -> AppConfig:
        try:
            return self._apps[label]
        except KeyError as exc:
            raise AppRegistryError(f"no app installed with label {label!r}") from exc

    def has(self, label: str) -> bool:
        return label in self._apps

    def __contains__(self, label: str) -> bool:
        return label in self._apps

    def __iter__(self) -> Iterator[AppConfig]:
        return iter(self._sort())

    def model_modules(self) -> list[str]:
        return [c.models_module for c in self._sort() if c.models_module]

    def cli_apps(self) -> list[tuple[str, Any]]:
        out: list[tuple[str, Any]] = []
        for cfg in self._sort():
            if not cfg.cli_app_attr:
                continue
            out.append((cfg.label, _import_attr(cfg.cli_app_attr)))
        return out

    def mount(
        self,
        app: FastAPI,
        *,
        include_public: bool = True,
        include_admin: bool = True,
        admin_dependencies: Iterable[Any] = (),
    ) -> None:
        """Include every app's public and/or admin routers on the FastAPI app.

        Public routers mount as-is (their prefix is part of the router).
        Admin routers mount with ``dependencies=list(admin_dependencies)``,
        which is where the host plugs in ``Depends(require_superuser)`` or
        equivalent. Pass ``include_admin=False`` when the host wraps each
        app's admin router under its own host-local prefix.
        """
        admin_deps = list(admin_dependencies)
        for cfg in self._sort():
            if include_public and cfg.router_attr:
                app.include_router(_import_attr(cfg.router_attr))
            if include_admin and cfg.admin_router_attr:
                app.include_router(
                    _import_attr(cfg.admin_router_attr),
                    dependencies=admin_deps,
                )
        app.state.registry = self

    @asynccontextmanager
    async def lifespan(self, app: FastAPI) -> AsyncIterator[None]:
        await self._startup(app)
        try:
            yield
        finally:
            await self._shutdown()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _startup(self, app: FastAPI) -> None:
        sorted_apps = self._sort()

        for cfg in sorted_apps:
            for attr in ("events_module", "signals_module", "tasks_module"):
                mod_name = getattr(cfg, attr, None)
                if mod_name:
                    importlib.import_module(mod_name)

        for cfg in sorted_apps:
            cfg.on_configure(self)

        for cfg in sorted_apps:
            await cfg.on_ready(self)

        if not self._orm_initialized:
            await Tortoise.init(
                db_url=self.database_url,
                modules={"models": self.model_modules()},
                _enable_global_fallback=True,
            )
            await Tortoise.generate_schemas(safe=True)
            self._orm_initialized = True

        if not self._broker_started:
            startup = getattr(self._broker, "startup", None)
            if callable(startup):
                await startup()
            self._broker_started = True

        for cfg in sorted_apps:
            await cfg.on_startup(self)

        app.state.registry = self

    async def _shutdown(self) -> None:
        for cfg in reversed(self._sort()):
            try:
                await cfg.on_shutdown(self)
            except Exception:
                pass

        if self._broker_started:
            shutdown = getattr(self._broker, "shutdown", None)
            if callable(shutdown):
                try:
                    await shutdown()
                except Exception:
                    pass
            self._broker_started = False

        if self._orm_initialized:
            try:
                await Tortoise.close_connections()
            except Exception:
                pass
            self._orm_initialized = False

        _unbind()

    def _resolve(
        self,
        app_ref: type[AppConfig] | AppConfig | str,
        settings: Any | None,
    ) -> AppConfig:
        if isinstance(app_ref, AppConfig):
            return app_ref
        if isinstance(app_ref, type) and issubclass(app_ref, AppConfig):
            return app_ref(settings) if settings is not None else app_ref()
        if isinstance(app_ref, str):
            return self._resolve_string(app_ref, settings)
        raise AppRegistryError(
            f"cannot install {app_ref!r}; expected AppConfig subclass, instance, or dotted name"
        )

    def _resolve_string(self, app_ref: str, settings: Any | None) -> AppConfig:
        if ":" in app_ref:
            cls = _import_attr(app_ref)
            if not (isinstance(cls, type) and issubclass(cls, AppConfig)):
                raise AppRegistryError(f"{app_ref} is not an AppConfig subclass")
            return cls(settings) if settings is not None else cls()

        candidates = [f"{app_ref}.apps", app_ref] if "." not in app_ref else [f"{app_ref}.apps", app_ref]
        last_err: Exception | None = None
        for mod_name in candidates:
            try:
                module = importlib.import_module(mod_name)
            except ImportError as exc:
                last_err = exc
                continue
            cls = _find_appconfig(module)
            if cls is not None:
                return cls(settings) if settings is not None else cls()
        raise AppRegistryError(
            f"could not locate an AppConfig subclass for {app_ref!r}"
            + (f" (last import error: {last_err})" if last_err else "")
        )

    def _sort(self) -> list[AppConfig]:
        if self._sorted is not None:
            return self._sorted
        self._sorted = _topo_sort(self._apps)
        return self._sorted


def _import_attr(dotted: str) -> Any:
    if ":" in dotted:
        mod_name, attr = dotted.split(":", 1)
    else:
        mod_name, _, attr = dotted.rpartition(".")
        if not mod_name or not attr:
            raise AppRegistryError(f"invalid dotted attribute reference: {dotted!r}")
    module = importlib.import_module(mod_name)
    try:
        return getattr(module, attr)
    except AttributeError as exc:
        raise AppRegistryError(f"{mod_name!r} has no attribute {attr!r}") from exc


def _find_appconfig(module: Any) -> type[AppConfig] | None:
    found: list[type[AppConfig]] = []
    for name in dir(module):
        obj = getattr(module, name, None)
        if not isinstance(obj, type):
            continue
        if obj is AppConfig:
            continue
        if not issubclass(obj, AppConfig):
            continue
        if obj.__module__ != module.__name__:
            continue
        found.append(obj)
    if not found:
        return None
    if len(found) > 1:
        names = ", ".join(c.__name__ for c in found)
        raise AppRegistryError(
            f"module {module.__name__!r} defines multiple AppConfig subclasses: {names}"
        )
    return found[0]


def _topo_sort(apps: dict[str, AppConfig]) -> list[AppConfig]:
    in_degree: dict[str, int] = dict.fromkeys(apps, 0)
    edges: dict[str, list[str]] = {label: [] for label in apps}
    for label, cfg in apps.items():
        for dep in cfg.depends_on:
            if dep not in apps:
                raise AppRegistryError(
                    f"app {label!r} depends on {dep!r} which is not installed"
                )
            edges[dep].append(label)
            in_degree[label] += 1

    ready = [label for label, degree in in_degree.items() if degree == 0]
    ready.sort()
    ordered: list[str] = []
    while ready:
        label = ready.pop(0)
        ordered.append(label)
        for downstream in edges[label]:
            in_degree[downstream] -= 1
            if in_degree[downstream] == 0:
                ready.append(downstream)
        ready.sort()

    if len(ordered) != len(apps):
        remaining = [label for label, degree in in_degree.items() if degree > 0]
        raise AppRegistryError(f"cyclic depends_on involving: {remaining}")

    return [apps[label] for label in ordered]
