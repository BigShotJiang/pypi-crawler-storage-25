"""Process-global access to the active AppRegistry and broker.

There is exactly one AppRegistry per process. ``tasks.py`` modules in every
Vanty app import ``current_broker()`` at module scope, so the registry must
be constructed before those modules are imported.

The host application is responsible for instantiating ``AppRegistry`` first
and only then calling ``registry.install(...)`` for each app — that order
guarantees ``current_broker()`` is resolvable when ``tasks.py`` runs.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from taskiq import AsyncBroker

    from vanty_core.apps.registry import AppRegistry


_REGISTRY: AppRegistry | None = None
_BROKER: AsyncBroker | None = None


class RegistryNotReady(RuntimeError):
    pass


def current_registry() -> AppRegistry:
    if _REGISTRY is None:
        raise RegistryNotReady(
            "No AppRegistry has been constructed in this process. "
            "Construct AppRegistry(database_url=..., broker_url=...) "
            "before importing modules that call current_registry()."
        )
    return _REGISTRY


def current_broker() -> AsyncBroker:
    if _BROKER is None:
        raise RegistryNotReady(
            "No AppRegistry has been constructed in this process. "
            "Construct AppRegistry(...) before importing tasks.py modules."
        )
    return _BROKER


def _bind(registry: AppRegistry, broker: AsyncBroker) -> None:
    global _REGISTRY, _BROKER
    _REGISTRY = registry
    _BROKER = broker


def _unbind() -> None:
    global _REGISTRY, _BROKER
    _REGISTRY = None
    _BROKER = None
