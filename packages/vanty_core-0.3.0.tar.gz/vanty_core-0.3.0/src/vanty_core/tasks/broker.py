from __future__ import annotations

from taskiq import InMemoryBroker


def create_broker(broker_url: str | None = None):
    if broker_url:
        from taskiq_aio_pika import AioPikaBroker

        return AioPikaBroker(broker_url)
    return InMemoryBroker()
