"""TaskIQ integration for Vanty Apps.

The broker is created and owned by ``AppRegistry``. Apps reach it via
``current_broker()`` at module scope inside ``<pkg>/tasks.py``::

    from vanty_core.apps import current_broker
    broker = current_broker()

    @broker.task
    async def sync_remote_thing(thing_id: str) -> None: ...
"""

from vanty_core.apps.context import current_broker
from vanty_core.tasks.broker import create_broker

__all__ = ["create_broker", "current_broker"]
