from __future__ import annotations

from slowapi import Limiter

from vanty_core.security.rate_limit import create_limiter


class TestCreateLimiter:
    def test_returns_limiter(self):
        limiter = create_limiter()
        assert isinstance(limiter, Limiter)

    def test_default_storage_is_memory(self):
        limiter = create_limiter()
        assert limiter is not None

    def test_custom_storage_uri(self):
        limiter = create_limiter(storage_uri="memory://")
        assert isinstance(limiter, Limiter)

    def test_custom_default_limits(self):
        limiter = create_limiter(default_limits=["10/minute", "100/hour"])
        assert isinstance(limiter, Limiter)

    def test_custom_key_func(self):
        limiter = create_limiter(key_func=lambda _: "fixed-key")
        assert isinstance(limiter, Limiter)
