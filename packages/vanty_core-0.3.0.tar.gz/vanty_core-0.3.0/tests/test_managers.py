from __future__ import annotations

from uuid import uuid4

import pytest

from tests.models import ScopedWidget
from vanty_core.db import (
    get_current_organization_id,
    set_organization_resolver,
)


async def _create_scoped(name: str, organization_id: str) -> ScopedWidget:
    w = ScopedWidget(name=name, organization_id=organization_id)
    await w.save(using_db=ScopedWidget._meta.db)
    return w


@pytest.fixture(autouse=True)
def _clear_resolver():
    set_organization_resolver(None)
    yield
    set_organization_resolver(None)


@pytest.mark.usefixtures("init_db")
class TestOrganizationManager:
    async def test_no_resolver_returns_empty(self):
        org_id = str(uuid4())
        await _create_scoped("hidden", org_id)
        results = await ScopedWidget.filter()
        assert len(results) == 0

    async def test_with_resolver_returns_matching(self):
        org_id = str(uuid4())
        other_org = str(uuid4())
        await _create_scoped("mine", org_id)
        await _create_scoped("theirs", other_org)

        set_organization_resolver(lambda: org_id)
        results = await ScopedWidget.filter()
        assert len(results) == 1
        assert results[0].name == "mine"

    async def test_unscoped_bypasses_filter(self):
        org_id = str(uuid4())
        await _create_scoped("visible", org_id)
        results = await ScopedWidget.unscoped.all()
        assert any(w.name == "visible" for w in results)

    async def test_get_current_organization_id_default(self):
        assert get_current_organization_id() is None
