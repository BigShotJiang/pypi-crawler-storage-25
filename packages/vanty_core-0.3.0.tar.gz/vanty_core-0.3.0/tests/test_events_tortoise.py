"""Test the Tortoise -> domain event bridge."""

from __future__ import annotations

from dataclasses import dataclass

import pytest
from tortoise.signals import Signals

from tests.models import Widget
from vanty_core.events import (
    EventBus,
    bridge_tortoise_signal,
    event,
    set_default_bus,
)


@event("tests.widget_created")
@dataclass(frozen=True)
class WidgetCreated:
    widget_id: str
    name: str


@pytest.mark.integration
async def test_tortoise_bridge_publishes_domain_event(init_db):
    bus = EventBus(name="bridge-test")
    set_default_bus(bus)
    received: list[WidgetCreated] = []

    async def handler(evt: WidgetCreated) -> None:
        received.append(evt)

    bus.subscribe(WidgetCreated, handler)

    def factory(*, instance, sender, created, **kwargs):
        if not created:
            return None
        return WidgetCreated(widget_id=str(instance.id), name=instance.name)

    callback = bridge_tortoise_signal(
        model=Widget,
        signal=Signals.post_save,
        event_factory=factory,
        bus=bus,
    )

    widget = await Widget.create(name="bridge")
    assert len(received) == 1
    assert received[0].name == "bridge"

    widget.name = "bridge-renamed"
    await widget.save()
    assert len(received) == 1, "update should not publish"

    Widget._listeners[Signals.post_save].pop(callback, None)
