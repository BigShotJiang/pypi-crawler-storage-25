"""Unit tests for the vanty-core events bus."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from uuid import UUID

import pytest

from vanty_core.events import (
    EventBus,
    EventDispatchError,
    clear_handlers,
    event,
    get_default_bus,
    list_events,
    on,
    publish,
    set_default_bus,
    subscribe,
)


@event("tests.user_signed_up")
@dataclass(frozen=True)
class UserSignedUpForTests:
    user_id: UUID
    email: str


@event("tests.payment_completed", description="A payment landed")
@dataclass(frozen=True)
class PaymentCompletedForTests:
    amount_cents: int
    currency: str


@pytest.fixture(autouse=True)
def _isolate_bus():
    """Each test gets a fresh bus so subscriptions don't bleed across tests."""
    original = get_default_bus()
    fresh = EventBus(name=f"test-{id(original)}")
    set_default_bus(fresh)
    yield
    set_default_bus(original)


async def test_event_class_registered_with_metadata() -> None:
    names = {spec.name for spec in list_events()}
    assert "tests.user_signed_up" in names
    assert "tests.payment_completed" in names


async def test_handler_receives_event() -> None:
    received: list[UserSignedUpForTests] = []

    @on(UserSignedUpForTests)
    async def _handler(evt: UserSignedUpForTests) -> None:
        received.append(evt)

    await publish(UserSignedUpForTests(user_id=UUID(int=1), email="a@example.com"))
    assert len(received) == 1
    assert received[0].email == "a@example.com"


async def test_multiple_handlers_run_concurrently() -> None:
    order: list[str] = []

    async def slow(evt: UserSignedUpForTests) -> None:
        await asyncio.sleep(0.05)
        order.append("slow")

    async def fast(evt: UserSignedUpForTests) -> None:
        order.append("fast")

    subscribe(UserSignedUpForTests, slow)
    subscribe(UserSignedUpForTests, fast)

    await publish(UserSignedUpForTests(user_id=UUID(int=2), email="b@example.com"))
    assert order == ["fast", "slow"]


async def test_handler_error_is_isolated() -> None:
    received: list[str] = []

    @on(UserSignedUpForTests)
    async def boom(evt: UserSignedUpForTests) -> None:
        raise RuntimeError("kaboom")

    @on(UserSignedUpForTests)
    async def survivor(evt: UserSignedUpForTests) -> None:
        received.append(evt.email)

    await publish(UserSignedUpForTests(user_id=UUID(int=3), email="c@example.com"))
    assert received == ["c@example.com"]


async def test_publish_unknown_event_raises() -> None:
    @dataclass
    class Untyped:
        x: int

    with pytest.raises(EventDispatchError):
        await publish(Untyped(x=1))


async def test_subscribe_unknown_event_raises() -> None:
    @dataclass
    class Untyped2:
        x: int

    with pytest.raises(EventDispatchError):
        subscribe(Untyped2, lambda evt: None)  # type: ignore[arg-type]


async def test_unsubscribe_via_returned_callable() -> None:
    received: list[str] = []

    async def handler(evt: PaymentCompletedForTests) -> None:
        received.append(evt.currency)

    cancel = subscribe(PaymentCompletedForTests, handler)
    await publish(PaymentCompletedForTests(amount_cents=100, currency="USD"))
    cancel()
    await publish(PaymentCompletedForTests(amount_cents=200, currency="EUR"))

    assert received == ["USD"]


async def test_clear_handlers_for_event() -> None:
    received: list[str] = []

    @on(PaymentCompletedForTests)
    async def handler(evt: PaymentCompletedForTests) -> None:
        received.append(evt.currency)

    clear_handlers(PaymentCompletedForTests)
    await publish(PaymentCompletedForTests(amount_cents=100, currency="GBP"))
    assert received == []


async def test_sync_handler_works() -> None:
    received: list[str] = []

    @on(PaymentCompletedForTests)
    def sync_handler(evt: PaymentCompletedForTests) -> None:
        received.append(evt.currency)

    await publish(PaymentCompletedForTests(amount_cents=42, currency="JPY"))
    assert received == ["JPY"]


async def test_background_dispatch_falls_back_when_no_dispatcher() -> None:
    bus = EventBus(name="bg-test")
    received: list[str] = []

    @event("tests.bg_event")
    @dataclass(frozen=True)
    class BgEvent:
        v: str

    async def handler(evt: BgEvent) -> None:
        received.append(evt.v)

    bus.subscribe(BgEvent, handler, dispatch="background")
    await bus.publish(BgEvent(v="hello"))
    assert received == ["hello"]


async def test_background_dispatch_uses_dispatcher_when_configured() -> None:
    bus = EventBus(name="bg-test-2")
    captured: list[object] = []

    def fake_dispatcher(coro_factory):
        captured.append(coro_factory)

    bus.set_background_dispatcher(fake_dispatcher)

    @event("tests.bg_event_2")
    @dataclass(frozen=True)
    class BgEvent2:
        v: str

    received: list[str] = []

    async def handler(evt: BgEvent2) -> None:
        received.append(evt.v)

    bus.subscribe(BgEvent2, handler, dispatch="background")
    await bus.publish(BgEvent2(v="hello"))

    assert len(captured) == 1
    assert received == []
