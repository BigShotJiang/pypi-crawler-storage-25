from __future__ import annotations

import re

import pytest

from tests.models import Widget

UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


@pytest.mark.usefixtures("init_db")
class TestTimestampedModel:
    async def test_create_generates_ulid_pk(self):
        w = await Widget.create(name="test")
        assert UUID_RE.match(w.id)

    async def test_pk_is_string(self):
        w = await Widget.create(name="test")
        assert isinstance(w.id, str)

    async def test_created_at_populated(self):
        w = await Widget.create(name="test")
        assert w.created_at is not None

    async def test_updated_at_populated(self):
        w = await Widget.create(name="test")
        assert w.updated_at is not None

    async def test_ordering_matches_insertion_order(self):
        w1 = await Widget.create(name="first")
        w2 = await Widget.create(name="second")
        w3 = await Widget.create(name="third")
        assert w1.id < w2.id < w3.id

    async def test_fetch_by_pk(self):
        w = await Widget.create(name="fetch-me")
        fetched = await Widget.get(id=w.id)
        assert fetched.name == "fetch-me"
