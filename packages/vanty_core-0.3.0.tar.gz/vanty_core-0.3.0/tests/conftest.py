from __future__ import annotations

import pytest
from tortoise import Tortoise


@pytest.fixture
async def init_db():
    await Tortoise.init(
        db_url="sqlite://:memory:",
        modules={"models": ["tests.models"]},
    )
    await Tortoise.generate_schemas()
    yield
    await Tortoise.close_connections()
