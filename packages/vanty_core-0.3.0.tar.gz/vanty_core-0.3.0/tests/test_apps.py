from __future__ import annotations

import pytest
from fastapi import FastAPI

from vanty_core.apps import (
    AppConfig,
    AppRegistry,
    AppRegistryError,
    RegistryNotReady,
    current_broker,
    current_registry,
)
from vanty_core.apps.context import _unbind


@pytest.fixture(autouse=True)
def _reset_registry():
    _unbind()
    yield
    _unbind()


class _AlphaApp(AppConfig):
    name = "alpha"
    label = "alpha"


class _BetaApp(AppConfig):
    name = "beta"
    label = "beta"
    depends_on = ("alpha",)


class _GammaApp(AppConfig):
    name = "gamma"
    label = "gamma"
    depends_on = ("beta",)


class TestAppRegistryConstruction:
    def test_requires_database_url(self):
        with pytest.raises(AppRegistryError):
            AppRegistry(database_url="")

    def test_binds_current_registry_and_broker(self):
        reg = AppRegistry(database_url="sqlite://:memory:")
        assert current_registry() is reg
        assert current_broker() is reg.broker

    def test_unbound_raises(self):
        with pytest.raises(RegistryNotReady):
            current_registry()
        with pytest.raises(RegistryNotReady):
            current_broker()


class TestInstall:
    def test_install_class(self):
        reg = AppRegistry(database_url="sqlite://:memory:")
        cfg = reg.install(_AlphaApp)
        assert isinstance(cfg, _AlphaApp)
        assert reg.has("alpha")
        assert reg.get("alpha") is cfg

    def test_install_instance(self):
        reg = AppRegistry(database_url="sqlite://:memory:")
        instance = _AlphaApp()
        cfg = reg.install(instance)
        assert cfg is instance

    def test_install_duplicate_label_raises(self):
        reg = AppRegistry(database_url="sqlite://:memory:")
        reg.install(_AlphaApp)
        with pytest.raises(AppRegistryError):
            reg.install(_AlphaApp)

    def test_install_unknown_dependency_raises(self):
        reg = AppRegistry(database_url="sqlite://:memory:")
        reg.install(_BetaApp)
        with pytest.raises(AppRegistryError):
            list(reg)


class TestTopologicalSort:
    def test_dependency_order(self):
        reg = AppRegistry(database_url="sqlite://:memory:")
        reg.install(_GammaApp)
        reg.install(_AlphaApp)
        reg.install(_BetaApp)
        labels = [c.label for c in reg]
        assert labels == ["alpha", "beta", "gamma"]


class TestLifespan:
    async def test_runs_hooks_in_order(self, monkeypatch):
        async def _noop_init(*args, **kwargs):
            return None

        async def _noop_close():
            return None

        async def _noop_generate(*args, **kwargs):
            return None

        from vanty_core.apps import registry as registry_mod

        monkeypatch.setattr(registry_mod.Tortoise, "init", _noop_init)
        monkeypatch.setattr(registry_mod.Tortoise, "close_connections", _noop_close)
        monkeypatch.setattr(registry_mod.Tortoise, "generate_schemas", _noop_generate)

        reg = AppRegistry(database_url="sqlite://:memory:")
        events: list[str] = []

        class TrackedApp(AppConfig):
            name = "tracked"
            label = "tracked"

            def on_configure(self, registry):
                events.append("configure")

            async def on_ready(self, registry):
                events.append("ready")

            async def on_startup(self, registry):
                events.append("startup")

            async def on_shutdown(self, registry):
                events.append("shutdown")

        reg.install(TrackedApp)
        app = FastAPI()
        async with reg.lifespan(app):
            assert events == ["configure", "ready", "startup"]
            assert app.state.registry is reg
        assert events == ["configure", "ready", "startup", "shutdown"]
