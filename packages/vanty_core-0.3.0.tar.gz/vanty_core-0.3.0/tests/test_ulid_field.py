from __future__ import annotations

import re
from uuid import UUID

import ulid

from vanty_core.db.fields import ULIDField, new_ulid

PK = True

UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")


class TestNewUlid:
    def test_returns_uuid_formatted_string(self):
        value = new_ulid()
        assert UUID_RE.match(value)

    def test_parseable_as_uuid(self):
        value = new_ulid()
        UUID(value)

    def test_unique(self):
        values = {new_ulid() for _ in range(100)}
        assert len(values) == 100

    def test_lexicographically_sortable(self):
        values = [new_ulid() for _ in range(50)]
        assert values == sorted(values)


class TestULIDField:
    def test_default_set_for_pk(self):
        field = ULIDField(primary_key=True)
        assert field.default is not None

    def test_no_default_for_non_pk(self):
        field = ULIDField()
        assert field.default is None

    def test_sql_type(self):
        field = ULIDField(primary_key=True)
        assert field.SQL_TYPE == "UUID"

    def test_to_db_value_none(self):
        field = ULIDField(primary_key=True)
        assert field.to_db_value(None, None) is None

    def test_to_db_value_string(self):
        field = ULIDField(primary_key=True)
        val = "01924b5e-4b3a-7c9d-8f1e-2a3b4c5d6e7f"
        assert field.to_db_value(val, None) == val

    def test_to_db_value_ulid_object(self):
        field = ULIDField(primary_key=True)
        u = ulid.ULID()
        result = field.to_db_value(u, None)
        assert UUID_RE.match(result)
        assert result == str(u.to_uuid())

    def test_to_python_value_none(self):
        field = ULIDField(primary_key=True)
        assert field.to_python_value(None) is None

    def test_to_python_value_string(self):
        field = ULIDField(primary_key=True)
        val = "01924b5e-4b3a-7c9d-8f1e-2a3b4c5d6e7f"
        assert field.to_python_value(val) == val

    def test_to_python_value_uuid(self):
        field = ULIDField(primary_key=True)
        u = UUID("01924b5e-4b3a-7c9d-8f1e-2a3b4c5d6e7f")
        result = field.to_python_value(u)
        assert isinstance(result, str)
