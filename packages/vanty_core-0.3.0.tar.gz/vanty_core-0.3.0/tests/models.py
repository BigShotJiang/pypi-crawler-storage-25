"""Concrete models for testing abstract base classes."""

from __future__ import annotations

from tortoise import fields

from vanty_core.db.models import OrganizationScopedModel, TimestampedModel


class Widget(TimestampedModel):
    name = fields.CharField(max_length=100)

    class Meta:
        table = "widget"


class ScopedWidget(OrganizationScopedModel):
    name = fields.CharField(max_length=100)

    class Meta:
        table = "scoped_widget"
