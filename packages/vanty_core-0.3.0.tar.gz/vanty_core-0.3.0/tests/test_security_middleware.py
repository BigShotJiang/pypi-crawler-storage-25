from __future__ import annotations

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from vanty_core.security.middleware import BLOCKED_PATTERNS, SecurityScannerBlockerMiddleware


@pytest.fixture
def app():
    application = FastAPI()
    application.add_middleware(SecurityScannerBlockerMiddleware)

    @application.get("/")
    async def root():
        return {"status": "ok"}

    @application.get("/api/data")
    async def data():
        return {"data": [1, 2, 3]}

    return application


@pytest.fixture
def client(app):
    return TestClient(app)


class TestSecurityScannerBlockerMiddleware:
    def test_normal_request_passes(self, client):
        response = client.get("/")
        assert response.status_code == 200

    def test_api_request_passes(self, client):
        response = client.get("/api/data")
        assert response.status_code == 200

    @pytest.mark.parametrize("path", BLOCKED_PATTERNS[:8])
    def test_blocked_patterns_return_403(self, client, path):
        response = client.get(path)
        assert response.status_code == 403
        assert response.text == "Forbidden"

    def test_blocked_suffix(self, client):
        response = client.get("/some/path/.env")
        assert response.status_code == 403

    def test_custom_patterns(self):
        application = FastAPI()
        application.add_middleware(SecurityScannerBlockerMiddleware, blocked_patterns=["/custom-blocked"])

        @application.get("/")
        async def root():
            return {"ok": True}

        @application.get("/.env")
        async def env():
            return {"ok": True}

        c = TestClient(application)
        assert c.get("/").status_code == 200
        assert c.get("/custom-blocked").status_code == 403
        assert c.get("/.env").status_code == 200  # Not in custom list
