from .dependency import *
from .core import *
from .EDA import *

def get_df_val_predicted(df_general,
                         df_general_date_index,
                         max_depth, 
                         learn_period,
                         model='br3_act',
                         date_start=datetime.now().date(), 
                         date_end=datetime.now().date() + timedelta(days=1),
                         jupyter_widget=True,
                         disable_widget=False,
                         ):
    
    '''
    SYNOPSYS: Функция генерации датафрейма с прогнозными объёмами энергопотребления под указанный горизонт планирования,
    адаптированная под валидационные расчеты (имитация отсутствия данных 'ActCons' и 'ActGen' после 7 утра, 
    оффлайн доступ к прогнозу погоды и данным Balancing Market)

    KEYWORD ARGUMENTS:
    df_general -- актуальная генеральная совокупность ко дню прогноза
    df_general_date_index –– глобальная генеральная совокупность, индексированная по дате
    max_depth -- максимальная глубина решающего дерева регрессора
    learn_period -- период обучения модели (размер тренировочной выборки)
    model -- тип модели (по умолчанию br3_act: [ActCons, ActGen, Price])
    date_start -- дата от начала старта прогноза (по умолчанию – текущий день)
    date_end -- дата окончания прогноза (по умолчанию – сутки вперёд)
    jupyter_widget -- использование notebook-виджета для Jupyter (по умолчанию True)
    disable_widget -- отключение виджета tqdm

    WARNING:
    get_br_feature(date) и get_weather(date) переопределены внутри функции для работы в offline-режиме

    RETURNS:
    df_predict : pandas.core.frame.DataFrame
    
    EXAMPLE:
    # генерация прогнозных объемов потребления ЭЭ на сутки вперед
    >>> get_df_predicted(df_general, df_general_date_index, max_depth, learn_period, model)

    # генерация прогнозных объемов потребления ЭЭ от указанной даты на сутки вперед
    >>> get_df_predicted(df_general, df_general_date_index, max_depth, learn_period, model, date_start=datetime(2024, 5, 12).date())

    # генерация прогнозных объемов потребления ЭЭ от текущего дня до указанной даты
    >>> get_df_predicted(df_general, df_general_date_index, max_depth, learn_period, model, date_end=datetime(2024, 6, 15).date())

    # генерация прогнозных объемов потребления ЭЭ от одной до другой указанной даты
    >>> get_df_predicted(df_general, df_general_date_index, max_depth, learn_period, model, 
                         date_start=datetime(2024, 5, 14).date(), date_end=datetime(2024, 5, 16).date())

    # генерация прогнозных объемов потребления ЭЭ на двое суток вперед
    >>> get_df_predicted(df_general, df_general_date_index, max_depth, learn_period, model, 
                         date_end=datetime.now().date() + timedelta(days=2))
    '''

    if jupyter_widget:
        from tqdm.notebook import trange
    else:
        from tqdm import trange

    def get_br_feature(date):
        return get_empty_daily_df(date).merge(df_general_date_index[['PredCons', 'ActCons', 'PredGen',  'ActGen', 'Price']], 
                                              how='left', on='Date')
    
    def get_weather(date):
        return get_empty_daily_df(date).merge(df_general_date_index.Temperature, how='left', on='Date').tail(24)
    
    # генерируем пустой датафрейм под итоговый результат
    df_predicted = pd.DataFrame()
    
    for date in trange((date_end - date_start).days + 1, desc=f"days progress", disable=disable_widget):  # виджет процесса расчёта по суткам
    
        # генерируем пустой суточный датафрейм с погодными и календарными признаками
        df_predicted_daily = add_date_scalar(get_weather(date_start + timedelta(days=date)))
        
        # разделяем логику обучения (текущие сутки с учётом БР, последующие - без учёта БР)
        if date == 0:
            
            if model == 'br3_act':
                # удаляем столбцы с прогнозными значениями генерации и потребления БР СО ЕЭС
                df_general = df_general.drop(columns=['PredCons', 'PredGen'])
                 # выгружаем данные (прогнозные и часть актуальных) с балансирующего рынка на текущие сутки
                df_predicted_daily = df_predicted_daily.merge(get_br_feature(date_start), on='Date')
            elif model == 'br2_act':
                # удаляем столбцы с прогнозными значениями генерации и потребления БР СО ЕЭС и 1 признак: `Price`
                df_general = df_general.drop(columns=['PredCons', 'PredGen', 'Price'])
                 # выгружаем данные (прогнозные и часть актуальных) с балансирующего рынка на текущие сутки
                df_predicted_daily = df_predicted_daily.merge(get_br_feature(date_start).drop(columns='Price'), on='Date')
            
            # обнуляем весь факт с 8:00 в df_predicted_daily (ФИЧА ИСКЛЮЧИТЕЛЬНО ДЛЯ ВАЛИДАТОРА!)
            # чтобы сместить доступный час, поменяй параметр time(hour=8)
            df_predicted_daily.loc[df_predicted_daily.Date >= datetime.combine(date_start, time(hour=8)),
                                   ['ActCons', 'ActGen']] = 0
            
            # восстанавливаем пропуски ActCons и ActGen данными из столбцов PredCons и PredGen
            df_predicted_daily = act_pred_reverse(df_predicted_daily)
            
        elif date == 1:

            if model == 'br3_act':
                df_general = df_general.drop(columns=['ActCons', 'ActGen', 'Price'])
            elif model == 'br2_act':
                df_general = df_general.drop(columns=['ActCons', 'ActGen'])

        # добавляем последние 168 (24 · 7) строк от df_general для генерации временного лага
        df_predicted_daily = pd.concat([df_general.tail(168), df_predicted_daily])

        # генерируем временной лаг (1 полная неделя)
        df_predicted_daily = prepareData(df_predicted_daily)

        # получаем прогнозные значения на текущие сутки
        df_predicted_daily = predict_volume(df_general, 
                                            df_predicted_daily, 
                                            max_depth, 
                                            learn_period)

        # добавляем полученные прогнозные значения в итоговый прогнозный фрейм
        df_predicted = pd.concat([df_predicted, df_predicted_daily])

        # пополняем генеральную совокупность текущими сутками (+24 строки) для планирования следующего дня
        df_general = pd.concat([df_general, df_predicted_daily])

    df_predicted.rename(columns = {'Volume':'Predicted'}, inplace = True)

    # убрать .tail(24) если необходимо получить прогноз на несколько дней
    return df_predicted[['Date', 'Predicted']].tail(24*(date_end - date_start).days)


def get_df_validate(df_general, df_general_date_index, max_depth, learn_period, model, date_start, date_end, logging=True, jupyter_widget=True):

    '''
    SYNOPSYS: Функция валиации модели. Возвращает валидационный фрейм с прогнозными значениями

    KEYWORD ARGUMENTS:
    df_general -- валидируемая генеральная совокупность
    df_general_date_index –– глобальная генеральная совокупность, индексированная по дате
    max_depth -- максимальная глубина решающего дерева регрессора
    learn_period -- период обучения модели (размер тренировочной выборки)
    model -- тип модели (по умолчанию br3_act: [ActCons, ActGen, Price])
    date_start -- дата от начала старта валидации
    date_end -- дата окончания валидации
    logging -- вывод сообщения в консоль о выбранном периоде валидации модели (по умолчанию True)
    jupyter_widget -- использование notebook-виджета для Jupyter (по умолчанию True)

    RETURNS:
    df_validate_result : pandas.core.frame.DataFrame
    
    EXAMPLE:
    >>> get_df_validate(df_general, max_depth, learn_period, model='br3_act', 
                        date_start=datetime(2025, 1, 1),
                        date_end=datetime(2025, 11, 1))

    Валидация br3_act за период: 2025-01-01 01:00:00 – 2025-11-01 00:00:00
    '''
    if jupyter_widget:
        from tqdm.notebook import trange
    else:
        from tqdm import trange
    
    # определяем размер валидационной выборки
    df_validate = df_general[(df_general.Date > datetime.combine(date_start, time(hour=0))) & 
                             (df_general.Date < datetime.combine(date_end, time(hour=1)))]
    
    df_validate.reset_index(drop=True, inplace=True)

    # оповещение о периоде валидации
    if logging:
        print(f'Валидация {model} за период: {df_validate.iloc[0, 0]} – {df_validate.iloc[-1, 0]}')
    
    # итоговый валидационный датафрейм с прогнозными значениями
    df_validate_result = pd.DataFrame()

    # посуточная валидация для выбранного интервала (с виджетом процесса)
    for i in trange(int((df_validate.shape[0]) / 24), desc=f"days progress (period: {learn_period}, max_depth: {max_depth})"):
        
        # формируем дату прогноза
        idate = df_validate.iloc[0].Date + timedelta(days=i)
        
        # ограничиваем размер генеральной совокупности (до -2 суток до даты прогноза)
        df_general_cut = df_general[df_general.Date < idate - timedelta(days=1)]
        
        # выполняем прогноз на указанную дату (с учетом -1 суток)
        df_predicted = get_df_val_predicted(df_general_cut,
                                            df_general_date_index,
                                            max_depth,
                                            learn_period,
                                            model, 
                                            date_start=idate.date()-timedelta(days=1), 
                                            date_end=idate.date(),
                                            disable_widget=True)
            
        # пополняем валидационный фрейм прогнозными значениями
        df_validate_result = pd.concat([df_validate_result, df_validate.merge(df_predicted, how='left', on='Date')])
        df_validate_result.dropna(inplace=True)

    # для визуального контроля модели
    if model == 'br3_act':
        df_validate_result = df_validate_result.drop(columns=['PredCons', 'PredGen'])
    elif model == 'br2_act':
        df_validate_result = df_validate_result.drop(columns=['PredCons', 'PredGen', 'Price'])
    
    return df_validate_result


def get_df_validate_with_loss(df_validate_result, df_RSV_vs_BR_rate):   
    
    '''
    SYNOPSYS: Добавление столбца `loss` с потерями на БР в результирующий датафрейм

    KEYWORD ARGUMENTS:
    df_validate_result -- датафрейм с результатами валидации
    df_RSV_vs_BR_rate -- датафрейм с ценами трансляции

    WARNING:
    Перед передачей аргумента df_validate_result обязательно сделать поверхностную копию датафрейма!
    
    RETURNS:
    df_validate_result : pandas.core.frame.DataFrame
    
    EXAMPLE:
    # Валидация
    >>> get_df_validate_with_loss(df_validate_result.copy(), df_RSV_vs_BR_rate).tail(6)

    Date	            Month	Volume	    Predicted	    Temp    A_gr_P	P_gr_A	diff_cons	loss
    2025-10-31 19:00:00	10	    3048.447	3111.348001	    5.3	    81.71	0.03	-62.901001	1.887030
    2025-10-31 20:00:00	10	    2990.510	3076.723773	    4.6	    0.00	126.69	-86.213773	10922.422939
    2025-10-31 21:00:00	10	    2934.933	3026.825067	    4.0	    0.00	520.23	-91.892067	47805.010082
    2025-10-31 22:00:00	10	    2880.025	2925.862016	    3.6	    0.00	712.90	-45.837016	32677.209003
    2025-10-31 23:00:00	10	    2755.676	2812.551380	    3.6	    0.00	545.83	-56.875380	31044.288899
    2025-11-01 00:00:00	11	    2636.455	2698.748793	    4.0	    0.00	832.01	-62.293793	51829.058486

    '''
    
    # добавляем в итоговую таблицу штрафные тарифы БР
    df_validate_result = df_validate_result.merge(df_RSV_vs_BR_rate, how='left', on='Date')
    df_validate_result = df_validate_result[['Date', 'Month', 'Volume', 'Predicted', 'Temperature', 'A_gr_P', 'P_gr_A']]

    # оцениваем размер "потерь" от работы на БР
    df_validate_result['diff_cons'] = df_validate_result.Volume - df_validate_result.Predicted
    df_validate_result['loss'] = np.where(df_validate_result.diff_cons > 0, 
                                          df_validate_result.diff_cons * df_validate_result.A_gr_P, 
                                          abs(df_validate_result.diff_cons) * df_validate_result.P_gr_A)
    return df_validate_result


def draw_diff_predict_vs_fact(df_validate_result, fontsize=12, font='Palatino Linotype', save_fig_dir=False):
    
    '''
    SYNOPSYS: Вывод результатов валидации в форме таблицы и графика

    KEYWORD ARGUMENTS:
    df_validate_result -- датафрейм с результатами валидации
    fontsize -- размер шрифта на диаграмме
    font -- шрифт, используемый на графике (установить False для дефолтного шрифта)
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)
    
    WARNING:
    - df_validate_result должен обязательно содержать столбцы Volume и Predict!
    - наличие столбцов 'loss' и 'Month' опционально

    RETURNS:
    None
    
    EXAMPLES:
    >>> diff_predict_vs_fact(df_validate_result)

    MAE: 35.857 [MW]
    MAPE: 1.342%

    Средние потери: 4949.67 руб/час 
    Медианные потери: 340.21 руб/час 
    Суммарные потери за период: [2025-01-01 ÷ 2025-12-01]: 39676523.28 руб

    January 2025	MAPE: 1.476%	Mean loss: 3821.03 RUR/h	Sum loss: 2839025.00 RUR
    February 2025	MAPE: 1.011%	Mean loss: 2114.15 RUR/h	Sum loss: 1420707.55 RUR
    March 2025	    MAPE: 1.083%	Mean loss: 1369.30 RUR/h	Sum loss: 1018761.97 RUR
    April 2025	    MAPE: 1.493%	Mean loss: 2838.11 RUR/h	Sum loss: 2043438.50 RUR
    May 2025	    MAPE: 1.485%	Mean loss: 10300.61 RUR/h	Sum loss: 7663655.54 RUR
    June 2025	    MAPE: 1.516%	Mean loss: 4921.48 RUR/h	Sum loss: 3543462.65 RUR
    July 2025	    MAPE: 1.434%	Mean loss: 4082.00 RUR/h	Sum loss: 3037008.62 RUR
    August 2025	    MAPE: 1.604%	Mean loss: 4594.90 RUR/h	Sum loss: 3418608.39 RUR
    September 2025	MAPE: 1.436%	Mean loss: 12467.14 RUR/h	Sum loss: 8976337.36 RUR
    October 2025	MAPE: 1.034%	Mean loss: 3105.82 RUR/h	Sum loss: 2310731.69 RUR
    November 2025	MAPE: 1.163%	Mean loss: 4708.94 RUR/h	Sum loss: 3390436.23 RUR
    '''  
    
    df_validate = df_validate_result.copy()
    
    # добавление новых столбцов (для расчёта усреднённой погрешности)
    df_validate.insert(df_validate.shape[1], 'MAPE', 
                       MAPE(df_validate.Predicted, df_validate.Volume)*100)

    df_validate['Error'] = abs((df_validate.Volume - df_validate.Predicted)*100 / df_validate.Volume)

    df_validate.reset_index(drop=True, inplace=True)

    if font:
        plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = fontsize
    fig, df_volume = plt.subplots(figsize=(16,5.5))
    df_error = df_volume.twinx()

    df_volume.plot(df_validate.Volume, label='Факт')
    df_volume.plot(df_validate.Predicted, label='Прогноз')
    df_error.plot(df_validate.Error, label='Absolute percentage error, %', color='#2ca02c')
    df_error.plot(df_validate.MAPE, '-.b', label='MAPE, %')
    
    # Создаем отдельные легенды для каждого набора осей
    lines_volume, labels_volume = df_volume.get_legend_handles_labels()
    lines_error, labels_error = df_error.get_legend_handles_labels()

    # Объединяем линии и метки легенды
    lines = lines_volume + lines_error
    labels = labels_volume + labels_error
    
    # Находим индекс линии 'Error, %' и удаляем её из списков
    try:
        error_index = labels.index('Absolute percentage error, %')
        del lines[error_index]
        del labels[error_index]
    except ValueError:
        print("Линия 'Error, %' не найдена в легенде.")
    
    df_volume.legend(lines, labels, loc='upper right')
    df_volume.set_xlim(0, df_validate.shape[0]-1)
    df_volume.set_ylim(df_validate.Volume.min() - 100, df_validate.Volume.max() + 100)
    df_volume.set_ylabel('Объём, МВт·ч', fontsize = fontsize+2)
    df_volume.set_xlabel('Часы', fontsize = fontsize+2)
    if df_validate.shape[0] == 24:
        df_volume.set_xticks(ticks=np.arange(0, df_validate.shape[0], step=1))

    if df_validate.shape[0] == 24:
        df_error.set_ylim(0, 5)
    else:
        df_error.set_ylim(0, 10)
    df_error.set_ylabel('Абсолютная процентная ошибка, %', fontsize = fontsize+2, color='g')

    title = 'Результат тестирования модели'
    plt.title(f'{title} ({df_validate.iloc[0].Date.date()} – {df_validate.iloc[-1].Date.date()})', fontsize = fontsize+2)
    
    print(f'MAE: {MAE(df_validate.Predicted, df_validate.Volume):.3f} [MW]',
          f'MAPE: {MAPE(df_validate.Predicted, df_validate.Volume):.3%}', sep='\n')

    if 'loss' in df_validate.columns:    
        print(f'\nСредние потери: {round(df_validate.loss.mean(), 2)} руб/час',          
              f'\nМедианные потери: {round(df_validate.loss.median(), 2)} руб/час',
              f'\nСуммарные потери за период: [{df_validate.iloc[0].Date.date()} ÷ {df_validate.iloc[-1].Date.date()}]:', 
              f'{round(df_validate.loss.sum(), 2)} руб', end='\n\n')
    
    if 'Month' in df_validate.columns:      
        df_validate.Month = df_validate.Date.apply(lambda x: f"{x.month_name()} {x.year}")
        list_months = list(df_validate.Month.unique())[:-1]  # исключаем месяц с одним "нулевым" часом

        for month in list_months:

            df_month = df_validate[df_validate.Month == month]

            mean_loss_message, sum_loss_message = '', ''
            if 'loss' in df_validate.columns: 
                mean_loss_message = f'Mean loss: {df_month.loss.mean():.2f} RUR/h'
                sum_loss_message = f'Sum loss: {df_month.loss.sum():.2f} RUR'

            print(f'{month}',
                  f'MAPE: {MAPE(df_month.Predicted, df_month.Volume):.3%}',
                  mean_loss_message,
                  sum_loss_message,
                  sep='\t')
    
    plt.tight_layout()

    def save_fig_to_png(plt, path, filename):
        if type(path) == bool:
            path = 'pictures'
        if not os.path.exists(path):
            os.makedirs(path)
        plt.savefig(f'{path}/{filename}.png', dpi = 300, transparent = True)
    
    if save_fig_dir:
        save_fig_to_png(plt, save_fig_dir, f'predict_vs_fact({df_validate.iloc[0].Date.date()} – {df_validate.iloc[-1].Date.date()})')

    plt.show()    


def Grid_Search(df_general,
                df_general_date_index,
                max_depth_grid,  # tuple type
                learn_period_grid,  # tuple type
                model, 
                date_start, 
                date_end,
                export_path=None,
                jupyter_widget=True):
    
    '''
    SYNOPSYS: Сеточный поиск оптимальных периода обучения и глубины дерева

    KEYWORD ARGUMENTS:
    df_general -- валидируемая генеральная совокупность
    df_general_date_index –– глобальная генеральная совокупность, индексированная по дате
    max_depth_grid -- диапазон поиска максимальной глубины решающего дерева регрессора
    learn_period_grid -- диапазон поиска периода обучения модели (размер тренировочной выборки)
    model -- тип модели
    date_start -- дата от начала старта валидации
    date_end -- дата окончания валидации
    export_path -- директория экспорта промежуточных расчётов в csv-формате
    jupyter_widget -- использование notebook-виджета для Jupyter (по умолчанию True)

    RETURNS:
    df_search_result : pandas.core.frame.DataFrame
    
    EXAMPLE:
    >>> Grid_Search(df_general,
                    df_general_date_index,
                    max_depth_grid=(5, 7),
                    learn_period_grid=(4, 7),
                    model='br3_act',
                    date_start=datetime(2025, 1, 1), 
                    date_end=datetime(2025, 11, 1))

    Валидация br3_act за период: 2025-01-01 01:00:00 – 2025-11-01 00:00:00
    
    period	max_depth	MAPE
    4	    5	        0.014033
    4	    6	        0.013729
    4	    7	        0.013998
    5	    5	        0.013865
    5	    6	        0.013620
    5	    7	        0.013783
    6	    5	        0.013730
    6	    6	        0.013719
    6	    7	        0.013917
    7	    5	        0.013757
    7	    6	        0.013695
    7	    7	        0.013869
    '''
    
    if jupyter_widget:
        from tqdm.notebook import trange
    else:
        from tqdm import trange

    print(f'GridSearch {model} for period: {datetime.combine(date_start, time(hour=1))} – {date_end}')

    # создаём пустой датафрейм под реультаты поиска
    df_search_result = pd.DataFrame(columns=['period', 'max_depth', 'MAPE'])

    # индекс узла сетки итогового датафрейма
    index = 0  

    # выбираем или создаём директорию под результаты валидации
    if export_path and not os.path.exists(export_path):
        os.makedirs(export_path)

    # формируем сетку гиперпараметров
    for learn_period in trange(learn_period_grid[0], learn_period_grid[1]+1, desc=f"total progress"):
        for max_depth in range(max_depth_grid[0], max_depth_grid[1]+1):

            df_validate_result = get_df_validate(df_general, df_general_date_index,
                                                 max_depth, learn_period, model, 
                                                 date_start,
                                                 date_end,
                                                 logging=False,
                                                 jupyter_widget=jupyter_widget)

            # экспорт промежуточного результата
            if export_path:
                file_path = f'{export_path}/GS_Predicted_{model}({learn_period}y,{max_depth})_{date_start.date()}_{date_end.date()}.csv'
                df_validate_result.to_csv(file_path, index=False)
            
            # заполнение итогового датафрейма метриками (MAPE) и параметрами (learn_period, max_depth) модели
            df_search_result.loc[index] = (learn_period,
                                           max_depth,
                                           MAPE(df_validate_result.Predicted, df_validate_result.Volume))
            index += 1

    return df_search_result


def search_result_highlighting(df_search_result):

    '''
    SYNOPSYS: Подсветка результатов поиска датафрейма 'df_search_result'
    '''
    
    search_result = df_search_result.copy()    
    search_result = search_result.style.format({'MAPE': '{:.3%}',
                                                }).background_gradient(cmap=sns.color_palette("vlag", as_cmap=True))

    n = df_search_result.MAPE.idxmin()
    print(f'Best results (MAPE: {df_search_result.loc[n].MAPE:.3%}) obtained for the parameters: ',
          f'Period: {df_search_result.loc[n].period}',
          f'max_depth: {df_search_result.loc[n].max_depth}', sep='\n')

    return search_result