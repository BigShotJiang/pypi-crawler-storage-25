// Concinno Config GUI — enterprise single-page frontend.
//
// Design principles:
//   - English only (browser translate handles the rest)
//   - Deterministic sort (shared SORT_KEY with Python feature_readme)
//   - No save button — change → POST → status stamp
//   - Live auto-refresh via 3s digest poll so LLM-side edits propagate
//   - Per-feature ? tooltip with plain-English explanation + example
//   - Two-layer ZIQ control:
//       * feature-level ziq_opt_out toggle (header)
//       * param-level manual_pinned 🔒 (each param row)
//   - Clickable facet badges + active-chip bar
//
(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));
  const status = $("#status");

  function setStatus(msg, kind = "info") {
    status.textContent = msg;
    status.className = `status ${kind}`;
  }

  async function fetchJSON(url, opts = {}) {
    const r = await fetch(url, {
      headers: { "content-type": "application/json" },
      ...opts,
    });
    if (!r.ok) throw new Error(`${r.status} ${r.statusText}: ${url}`);
    return r.json();
  }

  function escapeHtml(s) {
    return String(s ?? "").replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  // ── Tabs ──────────────────────────────────────────────
  $$("nav.tabs button[data-tab]").forEach((btn) => {
    btn.addEventListener("click", () => {
      $$("nav.tabs button[data-tab]").forEach((b) => b.classList.remove("active"));
      $$("section.tab").forEach((s) => s.classList.remove("active"));
      btn.classList.add("active");
      $(`#tab-${btn.dataset.tab}`).classList.add("active");
      loadTab(btn.dataset.tab);
    });
  });

  // ── Facet state ──────────────────────────────────────
  const facets = { category: null, flag: null, effect: null };

  function renderFacetChips() {
    const host = $("#active-facets");
    host.innerHTML = "";
    const active = [
      facets.category && { k: "category", v: facets.category, label: `category = ${facets.category}` },
      facets.flag && { k: "flag", v: facets.flag, label: `flag = ${facets.flag}` },
      facets.effect && { k: "effect", v: facets.effect, label: `effect = ${facets.effect}` },
    ].filter(Boolean);
    for (const a of active) {
      const chip = document.createElement("span");
      chip.className = "chip";
      chip.innerHTML = `${escapeHtml(a.label)} <button type="button" aria-label="remove">×</button>`;
      chip.querySelector("button").addEventListener("click", () => {
        facets[a.k] = null;
        renderFeatures();
      });
      host.appendChild(chip);
    }
  }

  // ── Features list ────────────────────────────────────
  let featuresCache = [];
  let lastDigest = null;

  const SORT_FNS = {
    "category-name": (a, b) =>
      (a.category || "zz").localeCompare(b.category || "zz") ||
      a.name.localeCompare(b.name),
    "name": (a, b) => a.name.localeCompare(b.name),
    "non-default-first": (a, b) => nonDefaultScore(b) - nonDefaultScore(a) || a.name.localeCompare(b.name),
    "ziq-first": (a, b) => (b.ziq_effective ? 1 : 0) - (a.ziq_effective ? 1 : 0) || a.name.localeCompare(b.name),
    "effect-scope": (a, b) => {
      const order = { immediate: 0, process_restart: 1, session_restart: 2 };
      return (order[a.effect_scope] ?? 9) - (order[b.effect_scope] ?? 9) || a.name.localeCompare(b.name);
    },
  };

  function nonDefaultScore(f) {
    let s = f.enabled === false ? 2 : 0;
    for (const p of Object.values(f.params || {})) if (p.is_modified) s += 1;
    if (f.ziq_opt_out) s += 1;
    return s;
  }

  function renderFeatures() {
    const filter = $("#filter").value.toLowerCase().trim();
    const onlyNonDefault = $("#only-non-default").checked;
    const sortKey = $("#sort").value;
    renderFacetChips();
    const list = $("#features-list");
    list.innerHTML = "";
    const filtered = featuresCache.filter((f) => {
      if (facets.category && f.category !== facets.category) return false;
      if (facets.flag === "ziq" && !f.ziq_autotunable) return false;
      if (facets.flag === "cosmetic" && !f.cosmetic) return false;
      if (facets.effect && f.effect_scope !== facets.effect) return false;
      if (filter) {
        const hay = `${f.name} ${f.category} ${f.description || ""} ${f.example || ""}`.toLowerCase();
        if (!hay.includes(filter)) return false;
      }
      if (onlyNonDefault && nonDefaultScore(f) === 0) return false;
      return true;
    });
    filtered.sort(SORT_FNS[sortKey] || SORT_FNS["category-name"]);
    for (const f of filtered) list.appendChild(renderFeatureCard(f));
    setStatus(`${filtered.length} / ${featuresCache.length} features`);
  }

  function renderFeatureCard(f) {
    const card = document.createElement("div");
    card.className = "feature";
    card.dataset.name = f.name;
    const scope = f.effect_scope || "immediate";
    const ziqToggle = f.ziq_autotunable
      ? `<label class="ziq-toggle" title="When ON, ZIQ may auto-tune this feature's params (skipping ones you pinned 🔒). When OFF, the whole feature is opaque to ZIQ.">
           <input type="checkbox" data-feature="${f.name}" data-key="ziq_opt_out" data-invert="1" ${f.ziq_opt_out ? "" : "checked"}>
           <span>ZIQ</span>
         </label>`
      : "";
    const exampleBlock = f.example
      ? `<div class="help-tooltip">${escapeHtml(f.example)}</div>`
      : `<div class="help-tooltip">${escapeHtml(f.description || "No extended description.")}</div>`;
    card.innerHTML = `
      <header class="fhead">
        <label class="toggle">
          <input type="checkbox" data-feature="${f.name}" data-key="enabled" ${f.enabled ? "checked" : ""}>
          <code>${f.name}</code>
        </label>
        <span class="badge cat" data-facet="category" data-val="${escapeHtml(f.category || "")}">${escapeHtml(f.category || "?")}</span>
        ${f.ziq_autotunable ? '<span class="badge ziq" data-facet="flag" data-val="ziq">ZIQ-tunable</span>' : ""}
        ${f.cosmetic ? '<span class="badge cosmetic" data-facet="flag" data-val="cosmetic">cosmetic</span>' : ""}
        <span class="badge effect-${scope.replace("_","-")}" data-facet="effect" data-val="${scope}">${scope}</span>
        ${nonDefaultScore(f) > 0 ? '<span class="badge non-default">modified</span>' : ""}
        ${ziqToggle}
        <button type="button" class="help-btn" aria-label="help">?</button>
      </header>
      <p class="desc">${escapeHtml(f.description || "")}</p>
      <div class="params"></div>
      ${exampleBlock}`;
    // Toggle (enabled)
    card.querySelector('input[data-key="enabled"]').addEventListener("change", (e) => {
      patchFeature(f.name, "enabled", e.target.checked, false);
    });
    // ZIQ toggle (writes ziq_opt_out as the *inverse* of the checked state)
    const ziqBox = card.querySelector('input[data-key="ziq_opt_out"]');
    if (ziqBox) {
      ziqBox.addEventListener("change", (e) => {
        patchFeature(f.name, "ziq_opt_out", !e.target.checked, false);
      });
    }
    // Badge facet clicks
    card.querySelectorAll(".badge[data-facet]").forEach((b) => {
      b.addEventListener("click", () => {
        const k = b.dataset.facet; const v = b.dataset.val;
        facets[k] = facets[k] === v ? null : v;
        renderFeatures();
      });
    });
    // Params
    const paramsDiv = card.querySelector(".params");
    for (const [pname, p] of Object.entries(f.params || {})) {
      paramsDiv.appendChild(renderParam(f.name, pname, p, f));
    }
    return card;
  }

  function renderParam(featureName, pname, p, feat) {
    const div = document.createElement("div");
    div.className = "param";
    const cur = (p.current === null || p.current === undefined) ? p.default : p.current;
    let input = "";
    if (p.type === "bool") {
      input = `<input type="checkbox" ${cur ? "checked" : ""} data-feature="${featureName}" data-key="${pname}" data-ptype="bool">`;
    } else if (p.options && Array.isArray(p.options)) {
      input = `<select data-feature="${featureName}" data-key="${pname}" data-ptype="str" title="${pname}">` +
        p.options.map((o) => `<option value="${escapeHtml(o)}"${o === cur ? " selected" : ""}>${escapeHtml(o)}</option>`).join("") +
        `</select>`;
    } else if (p.type === "int" || p.type === "float") {
      const step = p.type === "float" ? "any" : "1";
      const minA = (p.min !== null && p.min !== undefined) ? ` min="${p.min}"` : "";
      const maxA = (p.max !== null && p.max !== undefined) ? ` max="${p.max}"` : "";
      input = `<input type="number" step="${step}"${minA}${maxA} value="${cur ?? ""}" data-feature="${featureName}" data-key="${pname}" data-ptype="${p.type}">`;
    } else {
      input = `<input type="text" value="${escapeHtml(cur ?? "")}" data-feature="${featureName}" data-key="${pname}" data-ptype="str">`;
    }
    const meta = [
      p.default !== null && p.default !== undefined ? `default=<code>${escapeHtml(p.default)}</code>` : "",
      p.recommended !== undefined ? `rec=<code>${escapeHtml(p.recommended)}</code>` : "",
      (p.min !== null && p.min !== undefined) ? `≥${p.min}` : "",
      (p.max !== null && p.max !== undefined) ? `≤${p.max}` : "",
    ].filter(Boolean).join(" · ");
    const pinIcon = p.manual_pinned ? "🔒" : "🔄";
    const pinTitle = p.manual_pinned
      ? "Pinned: ZIQ will not override this param. Click to unpin."
      : "Unpinned: ZIQ may auto-tune this param (if feature ZIQ is on).";
    const pinButton = feat.ziq_autotunable
      ? `<button type="button" class="pin-btn" data-feature="${featureName}" data-key="${pname}" data-pinned="${p.manual_pinned ? 1 : 0}" title="${pinTitle}">${pinIcon}</button>`
      : "";
    div.innerHTML = `<label><code>${pname}</code> <small>${p.type || ""}</small></label>${input}<span class="meta">${meta}${p.is_modified ? " · <span class='dirty'>modified</span>" : ""}</span>${pinButton}`;
    const ctrl = div.querySelector("input, select");
    const debounced = p.type === "int" || p.type === "float" || (p.type !== "bool" && (!p.options || !p.options.length));
    ctrl.addEventListener(debounced ? "input" : "change", (e) => {
      const ptype = e.target.dataset.ptype;
      let val = e.target.type === "checkbox" ? e.target.checked : e.target.value;
      if (ptype === "int") val = parseInt(val, 10);
      else if (ptype === "float") val = parseFloat(val);
      patchFeature(featureName, pname, val, debounced);
    });
    const pinBtn = div.querySelector(".pin-btn");
    if (pinBtn) {
      pinBtn.addEventListener("click", () => {
        const now = pinBtn.dataset.pinned === "1";
        patchFeature(featureName, `${pname}__pinned`, !now, false);
      });
    }
    return div;
  }

  // ── Save (debounced for text/num) ────────────────────
  const debounceTimers = new Map();

  async function postFeature(name, key, value, force) {
    return fetchJSON(`/api/features/${name}`, {
      method: "POST",
      body: JSON.stringify({ key, value, force }),
    });
  }

  async function handleRiskConfirm(name, key, value, warnings) {
    if (!$("#confirm-risky").checked) {
      const retry = await postFeature(name, key, value, true);
      setStatus(retry.applied ? "saved (forced)" : "blocked", retry.applied ? "ok" : "err");
      return;
    }
    const ok = confirm(`Risk warnings — apply anyway?\n\n${warnings.join("\n")}`);
    if (!ok) { setStatus("change declined", "warn"); return; }
    const retry = await postFeature(name, key, value, true);
    setStatus(retry.applied ? "saved (forced)" : "blocked", retry.applied ? "ok" : "err");
  }

  async function doSave(name, key, value) {
    setStatus(`saving ${name}.${key}…`);
    try {
      const res = await postFeature(name, key, value, false);
      if (!res.applied) {
        await handleRiskConfirm(name, key, value, res.warnings || []);
      } else {
        const ts = new Date().toLocaleTimeString();
        const warnSuf = (res.warnings || []).length ? " (with warnings)" : "";
        setStatus(`${name}.${key} saved${warnSuf} @ ${ts}`, "ok");
      }
      await loadFeatures(false);
    } catch (err) {
      setStatus(`Error: ${err.message}`, "err");
    }
  }

  function patchFeature(name, key, value, debounce) {
    const dkey = `${name}/${key}`;
    if (debounce) {
      if (debounceTimers.has(dkey)) clearTimeout(debounceTimers.get(dkey));
      debounceTimers.set(dkey, setTimeout(() => {
        debounceTimers.delete(dkey);
        doSave(name, key, value);
      }, 400));
    } else {
      doSave(name, key, value);
    }
  }

  async function loadFeatures(showStatus = true) {
    try {
      const data = await fetchJSON("/api/features");
      featuresCache = data.features || [];
      renderFeatures();
      if (showStatus) setStatus(`${featuresCache.length} features loaded`);
    } catch (err) {
      setStatus(`Error: ${err.message}`, "err");
    }
  }

  $("#filter").addEventListener("input", renderFeatures);
  $("#sort").addEventListener("change", renderFeatures);
  $("#only-non-default").addEventListener("change", renderFeatures);

  // ── Harness ─────────────────────────────────────────
  let harnessCache = [];

  async function loadHarness() {
    try {
      const data = await fetchJSON("/api/harness/settings");
      harnessCache = data.files || [];
      renderHarness();
    } catch (err) { setStatus(`Error: ${err.message}`, "err"); }
  }

  function renderHarness() {
    const filter = ($("#harness-filter").value || "").toLowerCase().trim();
    const bucket = $("#harness-bucket").value;
    const host = $("#harness-list"); host.innerHTML = "";
    let total = 0;
    for (const f of harnessCache) {
      const div = document.createElement("div");
      div.className = "harness-file";
      const present = f.present ? "present" : "absent";
      const perms = f.permissions || { allow: [], deny: [], ask: [] };
      const render = (name, rules) => {
        const shown = (filter ? rules.filter((r) => String(r).toLowerCase().includes(filter)) : rules);
        total += shown.length;
        return `<details${name === "allow" ? " open" : ""}>
          <summary>${name} (${shown.length}/${rules.length})</summary>
          <ul>${shown.map((r) => `<li><code>${escapeHtml(r)}</code></li>`).join("") || "<li class='muted'>(none)</li>"}</ul>
        </details>`;
      };
      div.innerHTML = `
        <h3><code>${escapeHtml(f.path)}</code> <span class="badge">${present}</span></h3>
        ${(bucket === "all" || bucket === "allow") ? render("allow", perms.allow) : ""}
        ${(bucket === "all" || bucket === "deny") ? render("deny", perms.deny) : ""}
        ${(bucket === "all" || bucket === "ask") ? render("ask", perms.ask) : ""}`;
      host.appendChild(div);
    }
    setStatus(`${total} rule(s) shown across ${harnessCache.length} file(s)`);
  }

  $("#harness-filter").addEventListener("input", renderHarness);
  $("#harness-bucket").addEventListener("change", renderHarness);

  // ── ZIQ ─────────────────────────────────────────────
  async function loadZIQ() {
    try {
      const data = await fetchJSON("/api/ziq/posterior");
      const sum = $("#ziq-summary");
      const host = $("#ziq-overrides");
      if (!data.present) {
        sum.innerHTML = `<p class="hint">ZIQ posterior file not present. Online tuning has not written any overrides yet.</p>`;
        host.innerHTML = "";
        return;
      }
      const overrides = data.overrides || [];
      sum.innerHTML = `<p><strong>${overrides.length}</strong> override(s) in <code>~/.concinno/ziq_posterior.json</code></p>`;
      if (!overrides.length) {
        host.innerHTML = `<p class="hint">No per-feature overrides yet.</p>`;
        return;
      }
      // Join against current feature params so the table shows
      // ZIQ value vs manual value side-by-side.
      const cur = new Map((featuresCache || []).map((f) => [f.name, f]));
      host.innerHTML =
        `<table class="ziq-table">
          <thead><tr><th>Feature</th><th>Key</th><th>ZIQ value</th><th>Current value</th><th>Pinned</th></tr></thead>
          <tbody>${overrides.map((o) => {
            const feat = cur.get(o.feature);
            const p = feat && feat.params ? feat.params[o.key] : null;
            const curVal = p ? (p.current === null || p.current === undefined ? p.default : p.current) : "—";
            const pinned = p && p.manual_pinned ? "🔒" : "🔄";
            return `<tr>
              <td><code>${escapeHtml(o.feature)}</code></td>
              <td><code>${escapeHtml(o.key)}</code></td>
              <td><code>${escapeHtml(JSON.stringify(o.ziq_value))}</code></td>
              <td><code>${escapeHtml(JSON.stringify(curVal))}</code></td>
              <td>${pinned}</td>
            </tr>`;
          }).join("")}</tbody>
        </table>`;
      setStatus(`${overrides.length} ZIQ override(s) loaded`);
    } catch (err) { setStatus(`Error: ${err.message}`, "err"); }
  }

  // ── State ───────────────────────────────────────────
  async function loadState() {
    try {
      const data = await fetchJSON("/api/concinno/state");
      const host = $("#state-panels"); host.innerHTML = "";
      const panels = [
        ["Release authorization", fmtPre(data.release_authorization)],
        ["Toast notifications", fmtKV({
          "Enabled": data.toast_enabled, "App ID": data.toast_app_id,
        })],
        ["Locale", fmtKV({ "Current": data.locale })],
        ["Handoff mode", fmtKV({ "Current": data.handoff_mode })],
      ];
      for (const [title, body] of panels) {
        const p = document.createElement("div");
        p.className = "state-panel";
        p.innerHTML = `<h3>${escapeHtml(title)}</h3>${body}`;
        host.appendChild(p);
      }
      setStatus("runtime state loaded");
    } catch (err) { setStatus(`Error: ${err.message}`, "err"); }
  }

  function fmtPre(v) {
    if (v === undefined || v === null) return `<p class="hint">(absent)</p>`;
    if (typeof v === "string") return `<pre>${escapeHtml(v)}</pre>`;
    return `<pre>${escapeHtml(JSON.stringify(v, null, 2))}</pre>`;
  }

  function fmtKV(kv) {
    return `<dl class="kv">${Object.entries(kv).map(([k, v]) => {
      const val = (v === null || v === undefined) ? "(unset)" : String(v);
      return `<dt>${escapeHtml(k)}</dt><dd><code>${escapeHtml(val)}</code></dd>`;
    }).join("")}</dl>`;
  }

  // ── Tab dispatch ─────────────────────────────────────
  function loadTab(tab) {
    switch (tab) {
      case "features": return loadFeatures();
      case "harness": return loadHarness();
      case "ziq": return Promise.all([loadFeatures(false), loadZIQ()]);
      case "state": return loadState();
    }
  }

  // ── Live polling: re-fetch active tab when digest changes ──
  async function tick() {
    try {
      const d = await fetchJSON("/api/features/digest");
      if (lastDigest !== null && d.digest !== lastDigest) {
        // Something mutated: refresh active tab.
        const active = $$("nav.tabs button.active")[0];
        if (active) loadTab(active.dataset.tab);
      }
      lastDigest = d.digest;
      $("#live-indicator").classList.add("on");
    } catch {
      $("#live-indicator").classList.remove("on");
    }
  }
  setInterval(tick, 3000);
  tick();

  loadFeatures();
})();
