"""FastAPI backend for the concinno config GUI.

@module concinno.gui.server
@responsibility Expose a tiny localhost-only REST surface over
    ``FEATURE_META`` (read + patch), ``~/.concinno/*.json`` (read +
    atomic write via ``concinno.feature_config.set_feature``), the
    Claude harness permission files (read-only, surfaced so the
    operator sees the full two-layer gate state), and the ZIQ
    posterior file (read-only).

Design notes:

* All routes live under ``/api/…`` — the single-page frontend is
  served from ``/`` as static files. No templating, no React build —
  Vanilla JS fetches JSON and renders.
* Listens on loopback by default. ``--host 0.0.0.0`` is allowed but
  gated behind an explicit CLI flag; emits a stderr warning and
  refuses when the process detects it is running as a non-local user.
* Writes go through ``concinno.feature_config.set_feature`` so the
  origin sidecar (``~/.concinno/preset_origins.json``) records the
  change as ``("gui", <session>)`` — keeps audit parity with
  ``concinno preset`` CLI writes.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

try:
    from fastapi import FastAPI, HTTPException
    from fastapi.responses import JSONResponse
    from fastapi.staticfiles import StaticFiles
except ImportError as _err:  # pragma: no cover — optional dep
    raise ImportError(
        "concinno.gui requires FastAPI. Install with "
        "`pip install 'concinno[gui]'`."
    ) from _err


STATIC_DIR = Path(__file__).parent / "static"

# ── Effect-scope registry ────────────────────────────────────────
#
# For each FEATURE_META key, annotate how quickly a config change
# propagates so the GUI can warn the operator. Kept here (not in
# FEATURE_META itself) to avoid churning every per-feature entry —
# the GUI registry is the SSOT, with ``immediate`` as the pragmatic
# default (guards / gates / per-tool config are re-read on every
# subprocess spawn).
#
# ``session_restart`` — the value is captured once at SessionStart
# hook time (so rendering, inject templates, or session summary
# snapshots). User must close + reopen Claude Code.
#
# ``process_restart`` — long-lived daemons (scheduler, the GUI itself,
# concinno-daemon) cache the value at boot. User must restart the
# specific daemon.
#
# ``immediate`` — each PreToolUse / subprocess reads config fresh.
# ``update_file`` invalidates the in-process singleton, so the next
# Config.feature() call in any new subprocess picks up the change.

_SESSION_RESTART_FEATURES = frozenset({
    "session_switches",
    "session_summary",
    "prompt_guard",
    "streak_ux",
    "language_enforce",
    "cognitive_anchor",
    "deny_marker",
    "token_display",
})

_PROCESS_RESTART_FEATURES = frozenset({
    # Reserved for features that only live inside long-running daemons.
    # Currently none — GUI itself re-reads per request via get_config().
})


def _effect_scope(feature_name: str) -> str:
    if feature_name in _SESSION_RESTART_FEATURES:
        return "session_restart"
    if feature_name in _PROCESS_RESTART_FEATURES:
        return "process_restart"
    return "immediate"


def _harness_settings_files() -> list[Path]:
    home = Path.home()
    cwd = Path.cwd()
    return [
        home / ".claude" / "settings.json",
        home / ".claude" / "settings.local.json",
        cwd / ".claude" / "settings.json",
        cwd / ".claude" / "settings.local.json",
    ]


def _read_json_soft(p: Path) -> dict[str, Any] | None:
    if not p.is_file():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def _ziq_posterior_path() -> Path:
    return Path.home() / ".concinno" / "ziq_posterior.json"


def _feature_entry(name: str, meta: dict[str, Any], cfg) -> dict[str, Any]:
    """Build a single feature dict for the ``/api/features`` response.

    Added fields vs pre-2.23 shape:
      * ``example`` — plain-English explanation + scenario for the ? tooltip
      * ``ziq_opt_out`` — True when the operator has flipped ZIQ auto-tune
        off for this feature (takes precedence over ``ziq_autotunable``
        meta flag)
      * ``ziq_effective`` — derived: ``ziq_autotunable and not ziq_opt_out``
      * params[p].manual_pinned — operator has explicitly locked this
        param to the current value (ZIQ skips it)
      * params[p].is_modified — current value differs from default
    """
    from concinno.gui.feature_examples import example_for

    entry: dict[str, Any] = {
        "name": name,
        "category": meta.get("category"),
        "description": meta.get("description"),
        "example": example_for(name),
        "ziq_autotunable": meta.get("ziq_autotunable", False),
        "cosmetic": meta.get("cosmetic", False),
        "effect_scope": _effect_scope(name),
        "params": {},
    }
    try:
        entry["enabled"] = bool(cfg.feature(name, "enabled"))
    except Exception:
        entry["enabled"] = None
    try:
        opt_out = cfg.feature(name, "ziq_opt_out")
    except Exception:
        opt_out = None
    entry["ziq_opt_out"] = bool(opt_out) if opt_out is not None else False
    entry["ziq_effective"] = bool(
        entry["ziq_autotunable"] and not entry["ziq_opt_out"]
    )
    for pname, pmeta in meta.get("params", {}).items():
        try:
            current = cfg.feature(name, pname)
        except Exception:
            current = None
        default = pmeta.get("default")
        # manual_pinned is a sidecar key: features.<name>.<pname>__pinned
        try:
            pinned = cfg.feature(name, f"{pname}__pinned")
        except Exception:
            pinned = None
        # Auto-pin heuristic: if operator set a value != default, treat
        # that as an implicit manual lock unless they explicitly cleared
        # the pin. Mirrors switches.md "user explicit > opt-out > ZIQ".
        is_modified = (
            current is not None and current != default
        )
        manual_pinned = bool(pinned) if pinned is not None else is_modified
        entry["params"][pname] = {
            "type": pmeta.get("type"),
            "default": default,
            "current": current,
            "min": pmeta.get("min"),
            "max": pmeta.get("max"),
            "options": pmeta.get("options"),
            "recommended": pmeta.get("recommended"),
            "risk_low": pmeta.get("risk_low"),
            "risk_high": pmeta.get("risk_high"),
            "risk_off": pmeta.get("risk_off"),
            "is_modified": is_modified,
            "manual_pinned": manual_pinned,
        }
    return entry


def _fresh_config():
    """Invalidate the in-process Config singleton then re-read from disk.

    Ensures the GUI surfaces LLM-side writes to ``~/.concinno/*.json``
    and ``~/.claude/hooks/cc_config.json`` without waiting for a GUI
    process restart.
    """
    from concinno.core.config import get_config, reset_config
    reset_config()
    return get_config()


def _register_feature_routes(app: "FastAPI") -> None:
    @app.get("/api/features")
    def list_features() -> JSONResponse:
        from concinno.feature_config import FEATURE_META
        cfg = _fresh_config()
        return JSONResponse({
            "features": [_feature_entry(n, m, cfg) for n, m in FEATURE_META.items()],
        })

    @app.get("/api/features/digest")
    def get_digest() -> JSONResponse:
        return JSONResponse(_config_digest())

    @app.get("/api/features/{name}")
    def get_feature(name: str) -> JSONResponse:
        from concinno.feature_config import FEATURE_META

        if name not in FEATURE_META:
            raise HTTPException(status_code=404, detail=f"unknown feature: {name}")
        return JSONResponse(_feature_entry(name, FEATURE_META[name], _fresh_config()))

    @app.post("/api/features/{name}")
    def set_feature_value(name: str, body: dict[str, Any]) -> JSONResponse:
        """Body: ``{"key": "enabled", "value": true, "force": false}``"""
        from concinno.feature_config import set_feature

        key = body.get("key")
        value = body.get("value")
        force = bool(body.get("force", False))
        if not isinstance(key, str) or not key:
            raise HTTPException(status_code=400, detail="`key` required (str)")
        warnings = set_feature(name, key, value, force=force, origin=("gui",))
        applied = not (warnings and not force)
        return JSONResponse({
            "applied": applied, "warnings": warnings,
            "feature": name, "key": key, "value": value,
        })


def _register_harness_routes(app: "FastAPI") -> None:
    @app.get("/api/harness/settings")
    def list_harness_settings() -> JSONResponse:
        out: list[dict[str, Any]] = []
        for p in _harness_settings_files():
            data = _read_json_soft(p)
            if data is None:
                out.append({"path": str(p), "present": p.is_file(), "permissions": None})
                continue
            perms = data.get("permissions", {})
            out.append({
                "path": str(p),
                "present": True,
                "permissions": {
                    "allow": perms.get("allow", []),
                    "deny": perms.get("deny", []),
                    "ask": perms.get("ask", []),
                },
            })
        return JSONResponse({"files": out})


def _register_ziq_routes(app: "FastAPI") -> None:
    @app.get("/api/ziq/posterior")
    def get_ziq_posterior() -> JSONResponse:
        p = _ziq_posterior_path()
        if not p.is_file():
            return JSONResponse({"present": False, "posterior": {},
                                 "overrides": []})
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            return JSONResponse(
                {"present": True, "posterior": {}, "error": str(e),
                 "overrides": []},
            )
        # Decompose into per-feature override rows for the GUI table.
        overrides: list[dict[str, Any]] = []
        if isinstance(data, dict):
            for feat_name, rec in data.items():
                if isinstance(rec, dict):
                    for key, val in rec.items():
                        overrides.append({
                            "feature": feat_name, "key": key,
                            "ziq_value": val,
                        })
        return JSONResponse({
            "present": True, "posterior": data, "overrides": overrides,
        })


def _config_digest() -> dict[str, Any]:
    """Return a cheap change signal for frontend polling.

    Hashes every ``~/.concinno/*.json`` file's mtime so any config
    mutation — whether from this GUI, the LLM-side singleton, or a
    direct `jq` edit — flips the digest and the frontend re-fetches.
    """
    import hashlib
    h = hashlib.blake2b(digest_size=8)
    candidates: list[Path] = [_ziq_posterior_path()]
    concinno_dir = Path.home() / ".concinno"
    if concinno_dir.is_dir():
        for p in sorted(concinno_dir.glob("*.json")):
            candidates.append(p)
    cc_hooks = Path.home() / ".claude" / "hooks" / "cc_config.json"
    candidates.append(cc_hooks)
    mtime = 0.0
    for p in candidates:
        try:
            st = p.stat()
            h.update(f"{p}:{st.st_mtime_ns}".encode("utf-8"))
            mtime = max(mtime, st.st_mtime)
        except FileNotFoundError:
            h.update(f"{p}:absent".encode("utf-8"))
    return {"digest": h.hexdigest(), "mtime": mtime}


def _register_state_routes(app: "FastAPI") -> None:
    @app.get("/api/concinno/state")
    def get_concinno_state() -> JSONResponse:
        from concinno.release_authorization import describe_current_config

        state: dict[str, Any] = {"release_authorization": describe_current_config()}
        try:
            from concinno.core.config import get_config
            c = get_config()
            state["toast_enabled"] = c.toast_enabled
            state["toast_app_id"] = c.toast_app_id
        except Exception:
            pass
        try:
            from concinno.core.notify import _get_locale
            state["locale"] = _get_locale()
        except Exception:
            pass
        try:
            from concinno.handoff_engine import get_handoff_mode
            state["handoff_mode"] = get_handoff_mode()
        except Exception:
            pass
        return JSONResponse(state)


def create_app() -> "FastAPI":
    app = FastAPI(
        title="Concinno Config GUI",
        description=(
            "Visual control over FEATURE_META switches + user config files. "
            "Pair with ~/.claude/rules/switches.md two-layer gate SOP."
        ),
        version="0.1.0",
    )
    _register_feature_routes(app)
    _register_harness_routes(app)
    _register_ziq_routes(app)
    _register_state_routes(app)
    if STATIC_DIR.is_dir():
        app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")
    return app


def run(host: str = "127.0.0.1", port: int = 8400, reload: bool = False) -> None:
    """Block on uvicorn until SIGINT."""
    try:
        import uvicorn
    except ImportError as err:  # pragma: no cover
        raise ImportError(
            "concinno.gui needs uvicorn. Install with "
            "`pip install 'concinno[gui]'`."
        ) from err

    # Loopback default; refuse 0.0.0.0 unless explicit operator consent
    if host not in ("127.0.0.1", "localhost") and not os.environ.get(
        "CONCINNO_GUI_ALLOW_PUBLIC_BIND"
    ):
        raise SystemExit(
            f"concinno gui refuses host={host!r}; set env "
            "CONCINNO_GUI_ALLOW_PUBLIC_BIND=1 to override (loopback-only "
            "by default — this UI exposes config-mutation endpoints)."
        )
    uvicorn.run(
        "concinno.gui.server:create_app",
        host=host,
        port=port,
        reload=reload,
        factory=True,
        log_level="info",
    )
