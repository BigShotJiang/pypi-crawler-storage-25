"""Test basic IO against a xrootd server fixture"""

from __future__ import annotations

import asyncio
import io
import os
import time

import fsspec
import pytest

from fsspec_xrootd.xrootd import (
    XRootDFile,
    XRootDFileSystem,
    _chunks_to_vectors,
    _vectors_to_chunks,
)

TESTDATA1 = "apple\nbanana\norange\ngrape"
TESTDATA2 = "red\ngreen\nyellow\nblue"
sleep_time = 0.2
expiry_time = 0.1


def test_invalid_server():
    with pytest.raises(ValueError):
        fsspec.core.url_to_fs("root://")


def test_invalid_parameters():
    with pytest.raises(TypeError):
        fsspec.filesystem(protocol="root")


def test_async_impl():
    cls = fsspec.get_filesystem_class(protocol="root")
    assert cls == XRootDFileSystem
    assert cls.async_impl, "XRootDFileSystem should have async_impl=True"


def test_broken_server():
    with pytest.raises(OSError):
        # try to connect on the wrong port should fail
        with fsspec.open("root://localhost:12345/", "rt", timeout=5) as f:
            _ = f.read()


def test_path_parsing():
    fs, _, (path,) = fsspec.get_fs_token_paths("root://server.com")
    assert fs.protocol == "root"
    assert path == "/"
    fs, _, (path,) = fsspec.get_fs_token_paths("root://server.com/")
    assert path == "/"
    fs, _, (path,) = fsspec.get_fs_token_paths("root://server.com/blah")
    assert path == "blah"
    fs, _, (path,) = fsspec.get_fs_token_paths("root://server.com//blah")
    assert path == "/blah"
    fs, _, paths = fsspec.get_fs_token_paths([
        "root://server.com//blah",
        "root://server.com//more",
        "root://server.com/dir/",
        "root://serv.er//dir/",
    ])
    assert paths == [
        "/blah",
        "/more",
        "dir",
        "/dir",
    ]
    # get_fs_token_paths will expand glob patterns if '*', '?', or '[' are present
    # so we need to test parameter parsing using a different method
    fs, path = fsspec.url_to_fs("root://server.com//blah?param1=1&param2=2")
    assert path == "/blah?param1=1&param2=2"


def test_pickle(localserver, clear_server):
    import pickle

    remoteurl, localpath = localserver

    fs, _, (path,) = fsspec.get_fs_token_paths(remoteurl)
    assert fs.ls(path) == []
    fs = pickle.loads(pickle.dumps(fs))
    assert fs.ls(path) == []
    time.sleep(1)


def test_read_xrd(localserver, clear_server):
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)

    from XRootD import client

    with client.File() as f:
        status, _ = f.open(remoteurl + "/testfile.txt")
        if not status.ok:
            raise RuntimeError(status)
        status, res = f.read()
        if not status.ok:
            raise RuntimeError(status)
        assert res.decode("ascii") == TESTDATA1
        f.close()


def test_read_fsspec(localserver, clear_server):
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)

    with fsspec.open(remoteurl + "/testfile.txt", "rt") as f:
        assert f.read() == TESTDATA1
        f.seek(0)
        assert f.readline() == "apple\n"
        f.seek(0)
        lns = f.readlines()
        assert lns[2] == "orange\n"
        f.seek(1)
        assert f.read(1) == "p"

    with fsspec.open(remoteurl + "/testfile.txt", "rb") as f:
        assert f.readuntil(b"e") == b"apple"

    fs, token, path = fsspec.get_fs_token_paths(remoteurl + "/testfile.txt", "rt")
    assert fs.read_block(path[0], 0, 4) == b"appl"


def test_write_fsspec(localserver, clear_server):
    remoteurl, localpath = localserver
    with fsspec.open(remoteurl + "/testfile.txt", "wt") as f:
        f.write(TESTDATA1)
        f.flush()
    with open(localpath + "/testfile.txt") as f:
        assert f.read() == TESTDATA1


def test_write_rpb_fsspec(localserver, clear_server):
    """Test writing with r+b as in uproot"""
    remoteurl, _ = localserver
    fs, _, (prefix,) = fsspec.get_fs_token_paths(remoteurl)
    filename = "test.bin"
    fs.touch(prefix + "/" + filename)
    with fsspec.open(remoteurl + "/" + filename, "r+b") as f:
        f.write(b"Hello, this is a test file for r+b mode.")
        f.flush()
    with fsspec.open(remoteurl + "/" + filename, "r+b") as f:
        assert f.read() == b"Hello, this is a test file for r+b mode."
    with fsspec.open(remoteurl + "/" + filename, "r+b") as f:
        f.seek(len(b"Hello, this is a "))
        f.write(b"REPLACED ")
        f.flush()
    with fsspec.open(remoteurl + "/" + filename, "r+b") as f:
        assert f.read() == b"Hello, this is a REPLACED  for r+b mode."


def test_upload_chunk_final_does_not_close_recursively():
    payload = b"payload"
    writes = []

    class DummyStatus:
        ok = True
        message = ""

    class DummyFile:
        def write(self, data, offset, size, timeout=None):
            writes.append((data, offset, size, timeout))
            return DummyStatus(), size

    file_obj = XRootDFile.__new__(XRootDFile)
    file_obj.buffer = io.BytesIO(payload)
    file_obj.buffer.seek(0, io.SEEK_END)
    file_obj.offset = 0
    file_obj.metaOffset = 0
    file_obj.timeout = 1
    file_obj._myFile = DummyFile()
    file_obj.close = lambda: (_ for _ in ()).throw(AssertionError("close() called"))

    assert file_obj._upload_chunk(final=True) is True
    assert writes == [(payload, 0, len(payload), 1)]


@pytest.mark.parametrize("start, end", [(None, None), (None, 10), (1, None), (1, 10)])
def test_read_bytes_fsspec(localserver, clear_server, start, end):
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)

    fs, _, (prefix,) = fsspec.get_fs_token_paths(remoteurl)
    data = fs.read_bytes(prefix + "/testfile.txt", start=start, end=end)
    assert data == TESTDATA1.encode("utf-8")[start:end]


def test_append_fsspec(localserver, clear_server):
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)
    with fsspec.open(remoteurl + "/testfile.txt", "at") as f:
        f.write(TESTDATA2)
        f.flush()
    with open(localpath + "/testfile.txt") as f:
        assert f.read() == TESTDATA1 + TESTDATA2


@pytest.mark.parametrize("cache_expiry", [0, expiry_time])
def test_mk_and_rm_dir_fsspec(localserver, cache_expiry, clear_server):
    remoteurl, localpath = localserver
    os.makedirs(localpath + "/Folder1")
    os.makedirs(localpath + "/Folder2")
    with open(localpath + "/Folder1/testfile1.txt", "w") as fout:
        fout.write(TESTDATA2)
    with open(localpath + "/Folder2/testfile2.txt", "w") as fout:
        fout.write(TESTDATA2)
    fs, token, path = fsspec.get_fs_token_paths(
        remoteurl, "rt", storage_options={"listings_expiry_time": cache_expiry}
    )
    time.sleep(sleep_time)

    assert set(fs.ls(path[0], False)) == {"Folder1", "Folder2"}
    fs.mkdir(path[0] + "/Folder3/Folder33")
    time.sleep(sleep_time)
    assert set(fs.ls(path[0], False)) == {
        "Folder1",
        "Folder2",
        "Folder3",
    }

    with pytest.raises(OSError):
        fs.mkdir(path[0] + "/Folder4/Folder44", False)
    fs.mkdirs(path[0] + "/Folder4/Folder44")
    time.sleep(sleep_time)
    assert set(fs.ls(path[0], False)) == {
        "Folder1",
        "Folder2",
        "Folder3",
        "Folder4",
    }
    fs.mkdirs(path[0] + "/Folder4", True)
    time.sleep(sleep_time)
    with pytest.raises(OSError):
        fs.mkdirs(path[0] + "/Folder4", False)
    fs.rm(path[0] + "/Folder4", True)
    time.sleep(sleep_time)
    assert set(fs.ls(path[0], False)) == {
        "Folder1",
        "Folder2",
        "Folder3",
    }

    with pytest.raises(OSError):
        fs.rm(path[0] + "/Folder3", False)
    with pytest.raises(OSError):
        fs.rmdir(path[0] + "/Folder3")


def test_touch_modified(localserver, clear_server):
    remoteurl, localpath = localserver
    time.sleep(sleep_time)
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)
    fs, token, path = fsspec.get_fs_token_paths(
        remoteurl, "rt", storage_options={"listings_expiry_time": expiry_time}
    )
    t1 = fs.modified(path[0] + "/testfile.txt")
    assert fs.read_block(path[0] + "/testfile.txt", 0, 4) == b"appl"
    time.sleep(1)
    fs.touch(path[0] + "/testfile.txt", False)
    t2 = fs.modified(path[0] + "/testfile.txt")
    assert fs.read_block(path[0] + "/testfile.txt", 0, 4) == b"appl"
    time.sleep(1)
    fs.touch(path[0] + "/testfile.txt", True)
    t3 = fs.modified(path[0] + "/testfile.txt")
    assert fs.read_block(path[0] + "/testfile.txt", 0, 4) == b""
    assert t1 < t2 and t2 < t3


def test_touch_nonexistent(localserver, clear_server):
    remoteurl, localpath = localserver
    fs, token, path = fsspec.get_fs_token_paths(
        remoteurl, "rt", storage_options={"listings_expiry_time": expiry_time}
    )
    filename = path[0] + "/non-existent-file.bin"
    fs.touch(filename)
    assert fs.exists(filename)


def test_dir_cache(localserver, clear_server):
    remoteurl, localpath = localserver
    fs, token, path = fsspec.get_fs_token_paths(
        remoteurl, "rt", storage_options={"listings_expiry_time": expiry_time}
    )
    fs.mkdir(path[0] + "/Folder1")
    fs.mkdir(path[0] + "/Folder2")
    time.sleep(sleep_time)
    dirs = fs.ls(path[0], True)
    dirs_cached = fs._ls_from_cache(path[0])
    assert dirs == dirs_cached


@pytest.mark.parametrize("cache_expiry", [0, expiry_time])
def test_info(localserver, cache_expiry, clear_server):
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)
    fs, token, path = fsspec.get_fs_token_paths(
        remoteurl, "rt", storage_options={"listings_expiry_time": cache_expiry}
    )
    time.sleep(sleep_time)
    assert fs.info(path[0] + "/testfile.txt") in fs.ls(path[0], True)
    _ = fs.ls(path[0], True)
    assert fs.info(path[0] + "/testfile.txt") in fs.ls(path[0], True)


@pytest.mark.parametrize("cache_expiry", [0, expiry_time])
def test_walk_find(localserver, cache_expiry, clear_server):
    remoteurl, localpath = localserver
    fs, token, path = fsspec.get_fs_token_paths(
        remoteurl, "rt", storage_options={"listings_expiry_time": cache_expiry}
    )
    os.makedirs(localpath + "/WalkFolder")
    os.makedirs(localpath + "/WalkFolder/InnerFolder")
    with open(localpath + "/WalkFolder/testfile1.txt", "w") as fout:
        fout.write(TESTDATA2)
    with open(localpath + "/WalkFolder/InnerFolder/testfile2.txt", "w") as fout:
        fout.write(TESTDATA2)
    out = fs.walk(path[0] + "/WalkFolder")
    listing = []
    for item in out:
        listing.append(item)
    assert listing == [
        (path[0] + "/WalkFolder", ["InnerFolder"], ["testfile1.txt"]),
        (path[0] + "/WalkFolder/InnerFolder", [], ["testfile2.txt"]),
    ]
    # unable to use sets here^, would rather
    out = fs.find(path[0] + "/WalkFolder")
    listing = []
    for item in out:
        listing.append(item)
    assert set(listing) == {
        path[0] + "/WalkFolder/InnerFolder/testfile2.txt",
        path[0] + "/WalkFolder/testfile1.txt",
    }


@pytest.mark.parametrize("cache_expiry", [0, expiry_time])
def test_du(localserver, cache_expiry, clear_server):
    remoteurl, localpath = localserver
    os.makedirs(localpath + "/WalkFolder")
    os.makedirs(localpath + "/WalkFolder/InnerFolder")
    with open(localpath + "/WalkFolder/testfile1.txt", "w") as fout:
        fout.write(TESTDATA2)
    with open(localpath + "/WalkFolder/InnerFolder/testfile2.txt", "w") as fout:
        fout.write(TESTDATA2)
    fs, token, path = fsspec.get_fs_token_paths(
        remoteurl, "rt", storage_options={"listings_expiry_time": cache_expiry}
    )
    assert fs.du(path[0] + "/WalkFolder", False) == {
        path[0] + "/WalkFolder/InnerFolder/testfile2.txt": 21,
        path[0] + "/WalkFolder/testfile1.txt": 21,
    }
    assert fs.du(path[0] + "/WalkFolder", True) == 42


@pytest.mark.parametrize("cache_expiry", [0, expiry_time])
def test_glob(localserver, cache_expiry, clear_server):
    remoteurl, localpath = localserver
    os.makedirs(localpath + "/WalkFolder")
    with open(localpath + "/WalkFolder/testfile1.txt", "w") as fout:
        fout.write(TESTDATA2)
    with open(localpath + "/WalkFolder/testfile2.txt", "w") as fout:
        fout.write(TESTDATA2)
    time.sleep(sleep_time)
    fs, token, path = fsspec.get_fs_token_paths(
        remoteurl, "rt", storage_options={"listings_expiry_time": cache_expiry}
    )
    assert set(fs.glob(path[0] + "/WalkFolder/*.txt")) == {
        path[0] + "/WalkFolder/testfile1.txt",
        path[0] + "/WalkFolder/testfile2.txt",
    }


@pytest.mark.parametrize("cache_expiry", [0, expiry_time])
def test_cat(localserver, cache_expiry, clear_server):
    remoteurl, localpath = localserver
    os.makedirs(localpath + "/WalkFolder")
    with open(localpath + "/WalkFolder/testfile1.txt", "w") as fout:
        fout.write(TESTDATA1)
    with open(localpath + "/testfile2.txt", "w") as fout:
        fout.write(TESTDATA2)
    time.sleep(sleep_time)
    fs, token, path = fsspec.get_fs_token_paths(
        remoteurl, "rt", storage_options={"listings_expiry_time": cache_expiry}
    )
    assert fs.cat_file(path[0] + "/testfile2.txt", 4, 9) == b"green"

    paths = [
        path[0] + "/testfile2.txt",
        path[0] + "/WalkFolder/testfile1.txt",
        path[0] + "/testfile2.txt",
    ]
    starts = [4, 6, 4]
    ends = [9, 12, 10]
    assert fs.cat_ranges(paths, starts, ends, batch_size=100) == [
        b"green",
        b"banana",
        b"green\n",
    ]


def test_chunks_to_vectors():
    assert _chunks_to_vectors([(0, 10), (10, 30), (30, 35)], 100, 15) == [
        [(0, 10), (10, 15), (25, 5), (30, 5)]
    ]
    assert _chunks_to_vectors([(0, 10), (10, 30), (30, 35)], 2, 100) == [
        [(0, 10), (10, 20)],
        [(30, 5)],
    ]


def test_vectors_to_chunks(localserver, clear_server):
    from dataclasses import dataclass

    @dataclass
    class MockVectorReadInfo:
        offset: int
        length: int
        buffer: bytes

    res = [
        MockVectorReadInfo(0, 10, b"0" * 10),
        MockVectorReadInfo(10, 10, b"0" * 10),
        MockVectorReadInfo(20, 10, b"0" * 10),
        MockVectorReadInfo(30, 10, b"0" * 10),
    ]

    assert _vectors_to_chunks([(0, 10), (10, 30), (30, 40)], [res]) == [
        b"0" * 10,
        b"0" * 20,
        b"0" * 10,
    ]


def test_glob_full_names(localserver, clear_server):
    remoteurl, localpath = localserver
    os.makedirs(localpath + "/WalkFolder")
    with open(localpath + "/WalkFolder/testfile1.txt", "w") as fout:
        fout.write(TESTDATA1)
    with open(localpath + "/WalkFolder/testfile2.txt", "w") as fout:
        fout.write(TESTDATA2)
    time.sleep(sleep_time)

    full_names = [
        f.full_name for f in fsspec.open_files(remoteurl + "/WalkFolder/*.txt")
    ]

    for name in full_names:
        with fsspec.open(name) as f:
            assert f.read() in [bytes(data, "utf-8") for data in [TESTDATA1, TESTDATA2]]


@pytest.mark.parametrize("protocol_prefix", ["", "simplecache::"])
def test_cache(localserver, clear_server, protocol_prefix):
    data = TESTDATA1 * int(1e7 / len(TESTDATA1))  # bigger than the chunk size
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(data)

    with fsspec.open(protocol_prefix + remoteurl + "/testfile.txt", "rb") as f:
        contents = f.read()
        assert contents == data.encode("utf-8")


def test_cache_directory(localserver, clear_server, tmp_path):
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)

    cache_directory = tmp_path / "cache"
    with fsspec.open(
        "simplecache::" + remoteurl + "/testfile.txt",
        "rb",
        simplecache={"cache_storage": str(cache_directory)},
    ) as f:
        contents = f.read()
        assert contents == TESTDATA1.encode("utf-8")

    assert len(os.listdir(cache_directory)) == 1
    with open(cache_directory / os.listdir(cache_directory)[0], "rb") as f:
        contents = f.read()
        assert contents == TESTDATA1.encode("utf-8")


def test_close_while_reading(localserver, clear_server):
    remoteurl, localpath = localserver
    data = TESTDATA1 * int(1e8 / len(TESTDATA1))
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(data)

    fs, _, (path,) = fsspec.get_fs_token_paths(remoteurl + "/testfile.txt")

    async def reader():
        tic = time.monotonic()
        await fs._cat_file(path, start=0, end=None)
        toc = time.monotonic()
        return tic, toc

    async def closer():
        await asyncio.sleep(0.001)
        tic = time.monotonic()
        await fs._readonly_filehandle_cache._close(path, 1)
        toc = time.monotonic()
        return tic, toc

    async def run():
        (read_start, read_stop), (close_start, close_stop) = await asyncio.gather(
            reader(), closer()
        )
        assert read_start < close_start < read_stop
        assert read_start < close_stop < read_stop

    asyncio.run(run())


def test_mv(localserver, clear_server):
    """mv() should move a file and invalidate the cache."""
    remoteurl, localpath = localserver
    with open(localpath + "/src.txt", "w") as fout:
        fout.write(TESTDATA1)

    fs, _, (prefix,) = fsspec.get_fs_token_paths(remoteurl)
    src = prefix + "/src.txt"
    dst = prefix + "/dst.txt"

    fs.mv(src, dst)
    time.sleep(sleep_time)

    assert not fs.exists(src)
    assert fs.exists(dst)
    # Use open() rather than cat() to avoid the _cat_file start/end signature issue
    with fsspec.open(remoteurl + "/dst.txt", "rb") as f:
        assert f.read() == TESTDATA1.encode()


def test_mv_directory(localserver, clear_server):
    """mv() should move a directory."""
    remoteurl, localpath = localserver
    os.makedirs(localpath + "/srcdir")
    with open(localpath + "/srcdir/file.txt", "w") as fout:
        fout.write(TESTDATA1)

    fs, _, (prefix,) = fsspec.get_fs_token_paths(remoteurl)
    src = prefix + "/srcdir"
    dst = prefix + "/dstdir"

    fs.mv(src, dst)
    time.sleep(sleep_time)

    assert not fs.exists(src)
    assert fs.exists(dst)
    assert fs.exists(dst + "/file.txt")


def test_chmod(localserver, clear_server):
    """chmod() should change the mode of a file."""
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)

    fs, _, (prefix,) = fsspec.get_fs_token_paths(remoteurl)
    path = prefix + "/testfile.txt"

    fs.chmod(path, 0o644)
    info = fs.info(path)
    # The server returns mode bits; check at least that the call succeeded
    # and that the info dict contains a 'mode' key.
    assert "mode" in info


def test_checksum(localserver, clear_server):
    """checksum() should return a (algorithm, value) tuple.

    Skipped when the server does not support checksum queries (e.g. the
    minimal test server started by the fixture).
    """
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)

    fs, _, (prefix,) = fsspec.get_fs_token_paths(remoteurl)
    path = prefix + "/testfile.txt"

    try:
        alg, value = fs.checksum(path, "adler32")
    except OSError as e:
        if "not supported" in str(e).lower():
            pytest.skip(f"XRootD server does not support checksum queries: {e}")
        raise

    assert alg.lower() == "adler32"
    assert len(value) > 0
    # Value should be a valid hex string
    int(value, 16)


def test_ls_on_file(localserver, clear_server):
    """ls() called on a file path should return a single-entry list, not raise."""
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)

    fs, _, (prefix,) = fsspec.get_fs_token_paths(remoteurl)
    path = prefix + "/testfile.txt"

    # detail=True
    entries = fs.ls(path, detail=True)
    assert len(entries) == 1
    assert entries[0]["type"] == "file"

    # detail=False
    names = fs.ls(path, detail=False)
    assert len(names) == 1


def test_info_dict_fields(localserver, clear_server):
    """info() and ls() entries should include mtime, mode, uid, gid, nlink."""
    remoteurl, localpath = localserver
    with open(localpath + "/testfile.txt", "w") as fout:
        fout.write(TESTDATA1)

    fs, _, (prefix,) = fsspec.get_fs_token_paths(remoteurl)
    path = prefix + "/testfile.txt"

    info = fs.info(path)
    for field in ("mtime", "mode", "uid", "gid", "nlink"):
        assert field in info, f"Missing field: {field}"

    assert isinstance(info["mtime"], (int, float))
    assert info["mtime"] > 0
    assert isinstance(info["mode"], int)
    assert info["mode"] > 0

    # ls() entries should also carry these fields
    ls_entries = fs.ls(prefix, detail=True)
    file_entry = next(e for e in ls_entries if e["name"].endswith("testfile.txt"))
    for field in ("mtime", "mode", "uid", "gid", "nlink"):
        assert field in file_entry, f"ls entry missing field: {field}"
    assert file_entry["mtime"] > 0
