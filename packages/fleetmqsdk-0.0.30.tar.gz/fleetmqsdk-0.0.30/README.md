# FleetMQ Python SDK

The FleetMQ Python SDK lets your application send and receive data through the FleetMQ Node running on the same device. Communication uses ZMQ sockets under the hood — the SDK handles all socket setup and port negotiation automatically.

## Installation

```bash
pip install fleetmqsdk
```

## Quick Start

```python
import fleetmqsdk
import time

fleetmq = fleetmqsdk.FleetMQ.connect()

# Publish a string message
fleetmq.publish("my-topic", "Hello World!")

# Receive a message (returns None if nothing available)
msg = fleetmq.receive("my-topic")

fleetmq.close()
```

---

## Initialization

### `FleetMQ.connect(logPort, reqPort, pullPort, publisherRateHz, sdkType)`

Creates a FleetMQ client, connects to the FleetMQ Node, fetches the device config, and sets up all publishers and subscribers defined in that config. Blocks until the config is received. All parameters are optional.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `logPort` | `str` | `"5550"` | Port used for log forwarding |
| `reqPort` | `str` | `"5558"` | RPC port for config and publisher/subscriber provisioning |
| `pullPort` | `str` | `"5557"` | Push/pull port for config and metrics delivery |
| `publisherRateHz` | `float` | `200` | Max publish rate in Hz. Clamped to 20–200 |

`reqPort` and `pullPort` do not normally need to be changed. Only set them if you have a port conflict on your machine — if you do, the corresponding port flags on the FleetMQ Node must be set to match.

```python
fleetmq = fleetmqsdk.FleetMQ.connect()
```

`FleetMQ.connect()` also works as a context manager, which handles cleanup automatically:

```python
with fleetmqsdk.FleetMQ.connect() as fleetmq:
    fleetmq.publish("my-topic", "Hello World!")
```

---

## Publishing

### `publish(topic, data)`

Publishes a string message to the given topic. The publisher for this topic must already exist (created via `init()` or a config that includes it).

If the publisher does not exist, a warning is logged and the call returns silently.

```python
fleetmq.publish("vehicle/telemetry", "speed=42.5")
```

### `publishBytes(topic, data)`

Publishes raw bytes to the given topic.

```python
import struct

data = struct.pack('>HBI f B', header, version, timestamp, temperature, flags)
fleetmq.publishBytes("vehicle/sensors", data)
```

**Publisher behaviour:** Publishers buffer the latest message and send at the configured rate (`publisherRateHz`). If you call `publish` faster than the rate allows, only the most recent value is sent — older values are dropped. This is intentional for sensor/telemetry data where only the latest reading matters.

---

## Subscribing

### `receive(topic)`

Returns the next available string message for the topic, or `None` if no message is ready. Non-blocking.

```python
msg = fleetmq.receive("operator/commands")
if msg is not None:
    print(f"Received: {msg}")
```

### `receiveBytes(topic)`

Returns the next available message as `bytes`, or `None` if nothing is available.

```python
import struct

raw = fleetmq.receiveBytes("vehicle/sensors")
if raw is not None:
    header, version, timestamp, temperature, flags = struct.unpack('>HBI f B', raw)
```

---

## Metrics and Events

### `pullMetricsAndEvents()`

Returns `(metrics, event)`:
- `metrics` — list of `FleetMQMetric` objects, or `None`
- `event` — a `FleetMQEvent` object if an event occurred, or `None`

Call this periodically (e.g. in a background thread) to monitor connection quality and adapt your application's behaviour. Metrics include one-way latency between your device and each peer, which your SDK can use to make real-time decisions — for example, reducing publish frequency, switching to a lower-fidelity data stream, or surfacing connection quality indicators in your UI.

```python
metrics, event = fleetmq.pullMetricsAndEvents()

if metrics:
    for m in metrics:
        print(f"{m.type}: {m.value} (peer={m.peer}, ts={m.timestamp})")

if event:
    print(f"Event: {event.type} = {event.value}")
```

#### `FleetMQMetric` fields

| Field | Description |
|-------|-------------|
| `type` | Metric type string |
| `value` | Metric value |
| `peer` | Peer device the metric relates to |
| `timestamp` | Timestamp of the metric |

#### `FleetMQEvent` fields

| Field | Description |
|-------|-------------|
| `type` | Event type string |
| `value` | Event value |
| `timestamp` | Timestamp of the event |

#### `FleetMQEventLatencyGate` fields (subtype of `FleetMQEvent`)

| Field | Description |
|-------|-------------|
| `gated` | `True` if the connection is currently gated |
| `latency_ms` | Current latency in milliseconds |
| `threshold_ms` | Latency threshold that triggered the gate |
| `reason` | Human-readable reason string |

**Latency gate behaviour:** A latency gate event is fired when the round-trip latency between your device and a peer crosses a configured threshold. When `gated` is `True`, the FleetMQ Node has paused data flow on that connection to protect against sending stale data over a degraded link. When `gated` is `False`, the connection has recovered and data flow has resumed. Use these events to update your UI or trigger application-level responses — for example, alerting the operator that the connection is degraded or suppressing controls that depend on low-latency feedback.

---

## Cleanup

### `close()`

Closes all publisher and subscriber sockets and flushes any buffered logs. Call this before your process exits.

```python
fleetmq.close()
```

---

## Full Example

The example below shows a typical two-threaded pattern: one thread publishing, one receiving, with a background thread polling metrics.

```python
import fleetmqsdk
import time
from threading import Thread, Event

stop = Event()

def publisher(fleetmq, topic):
    while not stop.is_set():
        fleetmq.publish(topic, "Hello World!")
        time.sleep(1)

def subscriber(fleetmq, topic):
    while not stop.is_set():
        msg = fleetmq.receive(topic)
        if msg is not None:
            print(f"Received: {msg}")

def metrics_poller(fleetmq):
    while not stop.is_set():
        metrics, event = fleetmq.pullMetricsAndEvents()
        if metrics:
            for m in metrics:
                print(f"Metric: {m.type} = {m.value}")
        if event:
            print(f"Event: {event.type} = {event.value}")

fleetmq = fleetmqsdk.FleetMQ.connect()

threads = [
    Thread(target=publisher, args=(fleetmq, "my-device/data")),
    Thread(target=subscriber, args=(fleetmq, "peer-device/data")),
    Thread(target=metrics_poller, args=(fleetmq,)),
]

for t in threads:
    t.start()

try:
    while any(t.is_alive() for t in threads):
        for t in threads:
            t.join(timeout=0.01)
except KeyboardInterrupt:
    stop.set()

fleetmq.close()
```

### Binary data example

```python
import fleetmqsdk
import struct

fleetmq = fleetmqsdk.FleetMQ.connect()

# Pack sensor data: header (uint16), version (uint8), timestamp (uint32), temp (float), flags (uint8)
payload = struct.pack('>HBI f B', 0x0001, 1, 1685000000, 36.7, 0b10101010)
fleetmq.publishBytes("vehicle/sensors", payload)

raw = fleetmq.receiveBytes("vehicle/sensors")
if raw:
    header, version, timestamp, temp, flags = struct.unpack('>HBI f B', raw)

fleetmq.close()
```

---

## Notes

- `receive()` and `receiveBytes()` return `None` immediately if no message is available — loop or use a thread to poll continuously.
- Topic names must exactly match what is configured in the FleetMQ dashboard. A mismatch will result in a warning log and a no-op.
