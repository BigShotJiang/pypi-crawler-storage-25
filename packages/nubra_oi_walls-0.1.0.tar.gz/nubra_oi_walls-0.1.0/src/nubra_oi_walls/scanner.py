"""Options wall proximity scanner for the Nubra Python SDK."""

from __future__ import annotations

import os
from typing import Any, Dict, Iterable, List, Sequence, Tuple

DEFAULT_ENV_NAME = "UAT"
ENV_VAR_NAME = "NUBRA_OI_WALLS_ENV"

DEFAULT_OI_MODE = "oi"
DEFAULT_MIN_WALL_OI = 0
DEFAULT_NORMALIZE = False
DEFAULT_MULTI_WALL_TOP_N = 1
DEFAULT_EXCHANGE = "NSE"

# If a symbol is rejected by the API, map it to the correct Nubra name here.
SYMBOL_OVERRIDES = {}

# Exchange routing for common NSE and BSE index or stock underlyings.
STOCK_EXCHANGE_MAP = {
    "NIFTY": "NSE",
    "BANKNIFTY": "NSE",
    "FINNIFTY": "NSE",
    "MIDCPNIFTY": "NSE",
    "RELIANCE": "NSE",
    "HDFCBANK": "NSE",
    "INFY": "NSE",
    "TCS": "NSE",
    "WIPRO": "NSE",
    "ICICIBANK": "NSE",
    "AXISBANK": "NSE",
    "SBIN": "NSE",
    "TATAMOTORS": "NSE",
    "BAJFINANCE": "NSE",
    "SENSEX": "BSE",
    "BANKEX": "BSE",
}


def _resolve_nubra_env() -> Any:
    """Resolve the target Nubra environment from process configuration."""
    try:
        from nubra_python_sdk.start_sdk import NubraEnv
    except ImportError as exc:
        raise RuntimeError(
            "nubra-sdk is required to run scans. Install it with "
            "`pip install nubra_oi_walls` or `pip install nubra-sdk`."
        ) from exc

    env_name = os.getenv(ENV_VAR_NAME, DEFAULT_ENV_NAME).strip().upper()
    if env_name == "UAT":
        return NubraEnv.UAT
    if env_name == "PROD":
        return NubraEnv.PROD

    raise ValueError(
        "Unsupported Nubra environment {!r}. Use 'UAT' or 'PROD' via {}.".format(
            env_name,
            ENV_VAR_NAME,
        )
    )


def _create_market_data_client(nubra_client: Any | None = None) -> Any:
    """Create or wrap an authenticated Nubra MarketData client."""
    try:
        from nubra_python_sdk.marketdata.market_data import MarketData
        from nubra_python_sdk.start_sdk import InitNubraSdk
    except ImportError as exc:
        raise RuntimeError(
            "nubra-sdk is required to run scans. Install it with "
            "`pip install nubra_oi_walls` or `pip install nubra-sdk`."
        ) from exc

    if nubra_client is None:
        nubra_client = InitNubraSdk(_resolve_nubra_env(), env_creds=True)

    return MarketData(nubra_client)


def _normalize_symbol(symbol: Any) -> str:
    """Return a clean uppercase symbol string."""
    return str(symbol).strip().upper()


def get_oi_value(option_data: Any, mode: str) -> float:
    """Return the OI metric used for ranking a strike."""
    if mode == "oic":
        value = getattr(option_data, "open_interest_change", None)
        return abs(value) if value is not None else 0.0

    value = getattr(option_data, "open_interest", None)
    return float(value) if value is not None else 0.0


def get_top_wall_candidates(
    ce_chain: Sequence[Any],
    pe_chain: Sequence[Any],
    mode: str,
    top_n: int,
) -> Dict[str, List[Dict[str, Any]]]:
    """Return the top call and put wall candidates with rank metadata."""
    top_calls = sorted(ce_chain, key=lambda item: get_oi_value(item, mode), reverse=True)[:top_n]
    top_puts = sorted(pe_chain, key=lambda item: get_oi_value(item, mode), reverse=True)[:top_n]

    return {
        "calls": [
            {
                "wall_side": "CALL",
                "rank": index + 1,
                "option": option_data,
                "oi": get_oi_value(option_data, mode),
            }
            for index, option_data in enumerate(top_calls)
        ],
        "puts": [
            {
                "wall_side": "PUT",
                "rank": index + 1,
                "option": option_data,
                "oi": get_oi_value(option_data, mode),
            }
            for index, option_data in enumerate(top_puts)
        ],
    }


def find_dominant_wall(
    ce_chain: Sequence[Any],
    pe_chain: Sequence[Any],
    mode: str,
    top_n: int,
) -> Dict[str, Any]:
    """
    Identify the dominant call or put wall.

    When top_n == 1, the single strongest wall wins.
    When top_n > 1, the strongest N walls from each side are returned so the
    nearest strong wall can be resolved against the current price later.
    """
    if not ce_chain or not pe_chain:
        raise ValueError("Option chain must contain both CE and PE strikes.")

    candidate_groups = get_top_wall_candidates(ce_chain, pe_chain, mode, top_n)
    call_candidates = candidate_groups["calls"]
    put_candidates = candidate_groups["puts"]

    best_call = call_candidates[0]
    best_put = put_candidates[0]
    call_oi = best_call["oi"]
    put_oi = best_put["oi"]

    if top_n == 1:
        if call_oi >= put_oi:
            return {
                "wall_strike": best_call["option"].strike_price,
                "wall_type": "CALL",
                "wall_oi": call_oi,
                "call_wall_strike": best_call["option"].strike_price,
                "call_wall_oi": call_oi,
                "put_wall_strike": best_put["option"].strike_price,
                "put_wall_oi": put_oi,
                "call_candidates": call_candidates,
                "put_candidates": put_candidates,
            }

        return {
            "wall_strike": best_put["option"].strike_price,
            "wall_type": "PUT",
            "wall_oi": put_oi,
            "call_wall_strike": best_call["option"].strike_price,
            "call_wall_oi": call_oi,
            "put_wall_strike": best_put["option"].strike_price,
            "put_wall_oi": put_oi,
            "call_candidates": call_candidates,
            "put_candidates": put_candidates,
        }

    all_candidates = [(item["wall_side"], item["option"], item["oi"]) for item in call_candidates] + [
        (item["wall_side"], item["option"], item["oi"]) for item in put_candidates
    ]
    return {
        "_candidates": all_candidates,
        "call_wall_strike": best_call["option"].strike_price,
        "call_wall_oi": call_oi,
        "put_wall_strike": best_put["option"].strike_price,
        "put_wall_oi": put_oi,
        "call_candidates": call_candidates,
        "put_candidates": put_candidates,
    }


def resolve_multi_wall(wall_data: Dict[str, Any], current_price: int) -> Dict[str, Any]:
    """Resolve the nearest strong wall when multi-wall mode is enabled."""
    if "_candidates" not in wall_data:
        return wall_data

    candidates = wall_data["_candidates"]
    nearest = min(
        candidates,
        key=lambda item: (abs(item[1].strike_price - current_price), -item[2]),
    )

    wall_type, option_data, wall_oi = nearest
    wall_data["wall_strike"] = option_data.strike_price
    wall_data["wall_type"] = wall_type
    wall_data["wall_oi"] = wall_oi
    del wall_data["_candidates"]
    return wall_data


def fmt_price(paise: int) -> str:
    """Format paise as a rupee display string."""
    return "Rs {:,.2f}".format(paise / 100)


def fmt_oi(value: float) -> str:
    """Return a human-readable open-interest string."""
    if value >= 10_000_000:
        return "{:.2f} Cr".format(value / 10_000_000)
    if value >= 100_000:
        return "{:.1f} L".format(value / 100_000)
    return "{:,}".format(int(value))


def build_bar(pct: float, width: int = 10) -> str:
    """Build a simple ASCII bar where fuller means farther from the wall."""
    filled = min(width, max(0, int(pct)))
    return "[" + ("#" * filled) + ("-" * (width - filled)) + "]"


def fmt_ltp(price: float) -> str:
    """Format an LTP value without currency symbols or thousands separators."""
    return "{:.2f}".format(price)


def fmt_strike(price: float) -> str:
    """Format a strike for compact tabular display."""
    return "{:.2f}".format(price).rstrip("0").rstrip(".")


def build_wall_candidate_rows(
    symbol: str,
    current_price: int,
    wall_data: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Build flattened call and put wall candidate rows for display or DataFrame conversion."""
    rows: List[Dict[str, Any]] = []
    call_candidates = wall_data.get("call_candidates", [])
    put_candidates = wall_data.get("put_candidates", [])
    selected_wall_type = wall_data["wall_type"]
    selected_wall_strike = wall_data["wall_strike"]

    max_rank = max(len(call_candidates), len(put_candidates))
    for rank in range(1, max_rank + 1):
        rank_rows: List[Dict[str, Any]] = []
        for candidates in (put_candidates, call_candidates):
            if len(candidates) < rank:
                continue

            candidate = candidates[rank - 1]
            strike_price = candidate["option"].strike_price
            rank_rows.append(
                {
                    "symbol": symbol,
                    "ltp": round(current_price / 100, 2),
                    "wall_side": candidate["wall_side"],
                    "rank": candidate["rank"],
                    "strike": strike_price / 100,
                    "oi": candidate["oi"],
                    "dist_pct": round(abs(current_price - strike_price) / current_price * 100, 2),
                    "selected": (
                        candidate["wall_side"] == selected_wall_type and strike_price == selected_wall_strike
                    ),
                }
            )

        rank_rows.sort(key=lambda row: 0 if row["selected"] else 1)
        rows.extend(rank_rows)

    return rows


def flatten_wall_candidates(results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Flatten scanner results into display-friendly wall candidate rows."""
    flattened_rows: List[Dict[str, Any]] = []

    for result in results:
        if "wall_candidates" in result:
            flattened_rows.extend(result["wall_candidates"])
            continue

        fallback_rows = [
            {
                "symbol": result["symbol"],
                "ltp": round(result["price"], 2),
                "wall_side": "PUT",
                "rank": 1,
                "strike": result["put_wall_strike"],
                "oi": result["put_wall_oi"],
                "dist_pct": round(abs(result["price"] - result["put_wall_strike"]) / result["price"] * 100, 2),
                "selected": result["wall_type"] == "PUT",
            },
            {
                "symbol": result["symbol"],
                "ltp": round(result["price"], 2),
                "wall_side": "CALL",
                "rank": 1,
                "strike": result["call_wall_strike"],
                "oi": result["call_wall_oi"],
                "dist_pct": round(abs(result["price"] - result["call_wall_strike"]) / result["price"] * 100, 2),
                "selected": result["wall_type"] == "CALL",
            },
        ]
        fallback_rows.sort(key=lambda row: 0 if row["selected"] else 1)
        flattened_rows.extend(fallback_rows)

    return flattened_rows


def summarize_results(results: List[Dict[str, Any]], normalize: bool = False) -> List[Dict[str, Any]]:
    """Build summary rows for classic single-wall ranking output."""
    summary_rows: List[Dict[str, Any]] = []

    for index, result in enumerate(results, 1):
        strength = (
            "{:.2f}%".format(result["norm_strength"] * 100)
            if normalize and result["norm_strength"] is not None
            else fmt_oi(result["wall_oi"])
        )
        summary_rows.append(
            {
                "rank": index,
                "symbol": result["symbol"],
                "ltp": fmt_price(result["price_paise"]),
                "wall_type": result["wall_type"],
                "wall_strike": "Rs {:,.2f}".format(result["wall_strike"]),
                "strength": strength,
                "proximity": "{:.2f}%".format(result["proximity_pct"]),
                "bias": "Bullish" if result["wall_type"] == "PUT" else "Bearish",
            }
        )

    return summary_rows


def _validate_inputs(
    stocks: Iterable[Any],
    mode: str,
    top_n: int,
    exchange: str,
) -> Tuple[List[str], str, int, str]:
    """Validate and normalize public scan inputs."""
    if stocks is None:
        raise TypeError("stocks must be an iterable of symbol strings.")
    if isinstance(stocks, (str, bytes)):
        raise TypeError("stocks must be a list or iterable of symbol strings, not a single string.")

    cleaned_stocks = [_normalize_symbol(symbol) for symbol in stocks if str(symbol).strip()]
    normalized_mode = mode.strip().lower()
    normalized_exchange = exchange.strip().upper()

    if normalized_mode not in {"oi", "oic"}:
        raise ValueError("mode must be 'oi' or 'oic'.")

    if top_n < 1:
        raise ValueError("top_n must be at least 1.")

    if not normalized_exchange:
        raise ValueError("exchange must be a non-empty string.")

    return cleaned_stocks, normalized_mode, top_n, normalized_exchange


def _scan_wall_proximity_records(
    stocks: List[str],
    mode: str = DEFAULT_OI_MODE,
    normalize: bool = DEFAULT_NORMALIZE,
    min_wall_oi: float = DEFAULT_MIN_WALL_OI,
    top_n: int = DEFAULT_MULTI_WALL_TOP_N,
    exchange: str = DEFAULT_EXCHANGE,
    market_data: Any | None = None,
    nubra_client: Any | None = None,
) -> List[Dict[str, Any]]:
    """
    Fetch option chains for the provided underlyings and rank dominant walls by proximity.

    By default, the Nubra SDK is initialized with env_creds=True and uses the
    environment from NUBRA_OI_WALLS_ENV. Supported values are UAT and PROD.

    If you already have an authenticated Nubra SDK client or MarketData object,
    pass nubra_client=... or market_data=... to reuse that session instead of
    triggering a fresh login flow.

    No minimum wall OI filter is applied. The min_wall_oi argument is retained
    only for backward compatibility.
    """
    cleaned_stocks, normalized_mode, top_n, normalized_exchange = _validate_inputs(
        stocks=stocks,
        mode=mode,
        top_n=top_n,
        exchange=exchange,
    )
    _ = min_wall_oi
    if not cleaned_stocks:
        return []

    if market_data is not None and nubra_client is not None:
        raise ValueError("Pass either market_data or nubra_client, not both.")

    if market_data is None:
        market_data = _create_market_data_client(nubra_client=nubra_client)
    results = []

    for symbol in cleaned_stocks:
        try:
            api_symbol = SYMBOL_OVERRIDES.get(symbol, symbol)
            symbol_exchange = STOCK_EXCHANGE_MAP.get(symbol, normalized_exchange)
            response = market_data.option_chain(api_symbol, exchange=symbol_exchange)
            chain = response.chain

            current_price = getattr(chain, "current_price", None)
            if current_price is None:
                continue

            ce_chain = getattr(chain, "ce", None) or []
            pe_chain = getattr(chain, "pe", None) or []
            if not ce_chain or not pe_chain:
                continue

            wall_data = find_dominant_wall(ce_chain, pe_chain, normalized_mode, top_n)
            wall_data = resolve_multi_wall(wall_data, current_price)

            wall_strike = wall_data["wall_strike"]
            wall_type = wall_data["wall_type"]
            wall_oi = wall_data["wall_oi"]

            total_oi = sum(get_oi_value(item, normalized_mode) for item in list(ce_chain) + list(pe_chain))
            norm_strength = wall_oi / total_oi if (normalize and total_oi > 0) else None
            proximity_pct = abs(current_price - wall_strike) / current_price * 100
            bias = "SUPPORT (bullish)" if wall_type == "PUT" else "RESISTANCE (bearish)"
            wall_candidates = build_wall_candidate_rows(symbol, current_price, wall_data)

            results.append(
                {
                    "symbol": symbol,
                    "exchange": symbol_exchange,
                    "price_paise": current_price,
                    "price": current_price / 100,
                    "call_wall_strike": wall_data["call_wall_strike"] / 100,
                    "call_wall_oi": wall_data["call_wall_oi"],
                    "put_wall_strike": wall_data["put_wall_strike"] / 100,
                    "put_wall_oi": wall_data["put_wall_oi"],
                    "wall_strike": wall_strike / 100,
                    "wall_type": wall_type,
                    "wall_oi": wall_oi,
                    "norm_strength": round(norm_strength, 4) if norm_strength is not None else None,
                    "proximity_pct": round(proximity_pct, 4),
                    "bias": bias,
                    "expiry": getattr(chain, "expiry", None) or "N/A",
                    "wall_candidates": wall_candidates,
                }
            )

        except Exception as exc:
            _ = exc
            continue

    results.sort(key=lambda row: row["proximity_pct"])

    return results


def _require_pandas() -> Any:
    """Load pandas lazily so import errors are actionable."""
    try:
        import pandas as pd
    except ImportError as exc:
        raise RuntimeError(
            "pandas is required for nubra_oi_walls DataFrame output. "
            "Install it with `pip install nubra_oi_walls` or `pip install pandas`."
        ) from exc

    return pd


def _to_summary_dataframe(results: List[Dict[str, Any]], normalize: bool = False) -> Any:
    """Convert internal scan results into the classic summary DataFrame."""
    pd = _require_pandas()
    summary_rows = summarize_results(results, normalize=normalize)
    dataframe_rows = [
        {
            "Stock": row["symbol"],
            "LTP": row["ltp"],
            "Wall Type": row["wall_type"],
            "Wall Strike": row["wall_strike"],
            "Strength": row["strength"],
            "Proximity": row["proximity"],
            "Bias": row["bias"],
        }
        for row in summary_rows
    ]
    df = pd.DataFrame(
        dataframe_rows,
        columns=["Stock", "LTP", "Wall Type", "Wall Strike", "Strength", "Proximity", "Bias"],
    )
    df.index = pd.RangeIndex(start=1, stop=len(df) + 1, step=1, name="#")
    return df


def _to_candidate_dataframe(results: List[Dict[str, Any]]) -> Any:
    """Convert internal scan results into the expanded multi-wall DataFrame."""
    pd = _require_pandas()
    wall_rows = flatten_wall_candidates(results)
    dataframe_rows = [
        {
            "symbol": row["symbol"],
            "ltp": fmt_ltp(row["ltp"]),
            "wall_side": row["wall_side"],
            "rank": row["rank"],
            "strike": fmt_strike(row["strike"]),
            "oi": fmt_oi(row["oi"]),
            "dist_pct": "{:.2f}".format(row["dist_pct"]),
            "selected": "yes" if row["selected"] else "no",
        }
        for row in wall_rows
    ]
    df = pd.DataFrame(
        dataframe_rows,
        columns=["symbol", "ltp", "wall_side", "rank", "strike", "oi", "dist_pct", "selected"],
    )
    df.index = pd.Index([""] * len(df))
    return df


def run_wall_proximity_scan(
    stocks: List[str],
    normalize: bool = DEFAULT_NORMALIZE,
    min_wall_oi: float = DEFAULT_MIN_WALL_OI,
    top_n: int = 1,
    exchange: str = DEFAULT_EXCHANGE,
    market_data: Any | None = None,
    nubra_client: Any | None = None,
) -> Any:
    """Return the classic single-wall proximity ranking as a pandas DataFrame."""
    if top_n != 1:
        raise ValueError("run_wall_proximity_scan only supports top_n=1. Use run_multi_wall_proximity_scan for top_n > 1.")

    results = _scan_wall_proximity_records(
        stocks=stocks,
        mode=DEFAULT_OI_MODE,
        normalize=normalize,
        min_wall_oi=min_wall_oi,
        top_n=1,
        exchange=exchange,
        market_data=market_data,
        nubra_client=nubra_client,
    )
    return _to_summary_dataframe(results, normalize=normalize)


def run_multi_wall_proximity_scan(
    stocks: List[str],
    normalize: bool = DEFAULT_NORMALIZE,
    min_wall_oi: float = DEFAULT_MIN_WALL_OI,
    top_n: int = 3,
    exchange: str = DEFAULT_EXCHANGE,
    market_data: Any | None = None,
    nubra_client: Any | None = None,
) -> Any:
    """Return the expanded multi-wall candidates as a pandas DataFrame."""
    results = _scan_wall_proximity_records(
        stocks=stocks,
        mode=DEFAULT_OI_MODE,
        normalize=normalize,
        min_wall_oi=min_wall_oi,
        top_n=top_n,
        exchange=exchange,
        market_data=market_data,
        nubra_client=nubra_client,
    )
    return _to_candidate_dataframe(results)
