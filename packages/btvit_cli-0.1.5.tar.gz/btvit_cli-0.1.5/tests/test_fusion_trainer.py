from pathlib import Path
from types import SimpleNamespace

import pytest
import torch

from src.model.axis_model import AxisViTModel
from src.training.fusion_trainer import FusionTrainer, resolve_axis_checkpoints


def _make_fusion_config(tmp_path: Path, freeze_encoders: bool = True):
    fusion_root = tmp_path / "fusion"
    return SimpleNamespace(
        model=SimpleNamespace(
            input_shape=[16, 368],
            patch_size=[16, 16],
            num_classes=1,
            dim=32,
            depth=1,
            heads=1,
            mlp_dim=64,
            channels=1,
            dim_head=32,
            dropout=0.1,
            emb_dropout=0.1,
            rope_min_freq=1.0,
            rope_max_freq=10000.0,
            rope_p_zero_freqs=0.0,
        ),
        training=SimpleNamespace(
            common=SimpleNamespace(device="cpu"),
            fusion=SimpleNamespace(
                epochs=2,
                learning_rate=1e-3,
                weight_decay=0.0,
                optimizer="AdamW",
                scheduler="",
                scheduler_params={},
                batch_size=2,
                freeze_encoders=freeze_encoders,
            ),
        ),
        multi_axis=SimpleNamespace(
            active_axes=["x", "y", "z"],
            fusion_head=SimpleNamespace(type="linear", hidden_dim=32, dropout=0.1),
        ),
        monitoring=SimpleNamespace(
            fusion=SimpleNamespace(
                early_stopping={"enabled": False},
                model_selection={"metric": "val_auc", "mode": "max"},
            ),
            verbose=False,
        ),
        experiment=SimpleNamespace(
            name="exp",
            save_dir=str(tmp_path),
            checkpoint_dir=str(fusion_root / "checkpoints"),
            result_dir=str(fusion_root / "results"),
            log_dir=str(fusion_root / "logs"),
        ),
    )


def _save_axis_checkpoint(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    model = AxisViTModel(
        input_shape=(16, 368),
        patch_size=(16, 16),
        dim=32,
        depth=1,
        heads=1,
        mlp_dim=64,
        channels=1,
        dim_head=32,
        dropout=0.1,
        emb_dropout=0.1,
        rope_min_freq=1.0,
        rope_max_freq=10000.0,
        rope_p_zero_freqs=0.0,
    )
    torch.save({"model_state_dict": model.state_dict()}, path)


def test_fusion_stage_loads_axis_checkpoints_and_freezes_encoders(tmp_path):
    config = _make_fusion_config(tmp_path, freeze_encoders=True)
    checkpoint_paths = {}
    for axis in ("x", "y", "z"):
        checkpoint_path = tmp_path / f"axis-{axis}.pth"
        _save_axis_checkpoint(checkpoint_path)
        checkpoint_paths[axis] = str(checkpoint_path)

    trainer = FusionTrainer(config, axis_checkpoint_paths=checkpoint_paths)

    assert all(not parameter.requires_grad for parameter in trainer.encoders["x"].parameters())
    assert all(not parameter.requires_grad for parameter in trainer.encoders["y"].parameters())
    assert all(not parameter.requires_grad for parameter in trainer.encoders["z"].parameters())


def test_fusion_stage_fails_when_axis_checkpoint_missing(tmp_path):
    with pytest.raises(FileNotFoundError):
        resolve_axis_checkpoints(str(tmp_path), experiment_name="exp")
