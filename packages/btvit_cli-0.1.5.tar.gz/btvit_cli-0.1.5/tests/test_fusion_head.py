import torch

from src.model.fusion_head import PatientFusionHead


def test_patient_fusion_head_supports_linear_and_mlp():
    linear = PatientFusionHead(input_dim=96, head_type="linear")
    mlp = PatientFusionHead(input_dim=96, head_type="mlp", hidden_dim=32, dropout=0.1)
    x = torch.randn(4, 96)

    assert linear(x).shape == (4, 1)
    assert mlp(x).shape == (4, 1)
