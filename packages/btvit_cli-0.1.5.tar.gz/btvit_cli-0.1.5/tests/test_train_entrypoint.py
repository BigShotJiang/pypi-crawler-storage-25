import unittest
from types import SimpleNamespace
from unittest.mock import patch

import train
from typer.testing import CliRunner

from src.cli.main import app


class TrainEntrypointTest(unittest.TestCase):
    @patch("src.cli.train_impl.train_axis", return_value={"mode": "axis"}, create=True)
    @patch("src.cli.train_impl.train_fusion", return_value={"mode": "fusion"}, create=True)
    def test_dispatch_training_routes_to_axis_stage_trainer(self, fusion_mock, axis_mock):
        config = SimpleNamespace(
            multi_axis=SimpleNamespace(enabled=False),
        )
        args = SimpleNamespace(stage="axis", axis="x")
        splitter = object()
        logger = object()

        result = train.dispatch_training(splitter, config, args, logger)

        self.assertEqual(result, {"mode": "axis"})
        axis_mock.assert_called_once_with(splitter, config, args, logger, axis="x")
        fusion_mock.assert_not_called()

    @patch("src.cli.train_impl.train_axis", return_value={"mode": "axis"}, create=True)
    @patch("src.cli.train_impl.train_fusion", return_value={"mode": "fusion"}, create=True)
    def test_dispatch_training_routes_to_fusion_stage_trainer(self, fusion_mock, axis_mock):
        config = SimpleNamespace(
            multi_axis=SimpleNamespace(enabled=True),
        )
        args = SimpleNamespace(stage="fusion", axis=None)
        splitter = object()
        logger = object()

        result = train.dispatch_training(splitter, config, args, logger)

        self.assertEqual(result, {"mode": "fusion"})
        fusion_mock.assert_called_once_with(splitter, config, args, logger)
        axis_mock.assert_not_called()

    @patch("src.cli.train_impl.export_prediction_ready_testset")
    @patch("src.cli.train_impl.DataLoaderManager")
    @patch("src.training.trainer.Trainer")
    def test_train_with_split_exports_testset_after_split(self, trainer_cls, data_manager_cls, export_mock):
        splitter = SimpleNamespace(
            train_patients=["P1"],
            val_patients=["P2"],
            test_patients=["P3"],
            labels={"P3": 1},
            organizer=object(),
            split_data=lambda **kwargs: {"method": "stratified"},
        )
        config = SimpleNamespace(
            train_split=SimpleNamespace(
                train_split_csv_path="",
                use_csv_direct=False,
                export_split_info=False,
                train_ratio=0.8,
                val_ratio=0.1,
                test_ratio=0.1,
                random_seed=42,
                method="stratified",
            ),
            experiment=SimpleNamespace(name="exp1", result_dir="/tmp/results"),
            training=SimpleNamespace(batch_size=2, num_workers=0),
            data=SimpleNamespace(pin_memory=False, enable_memory_preload=False, preload_batch_size=None, preload_verbose=False, patch_size=[16, 16]),
        )
        args = SimpleNamespace(data_path="/tmp/data", label_path="/tmp/label.csv", experiment_name=None, pre_model=None, load_weights_only=False, strict_load=False, freeze_layers=None, freeze_ratio=None)
        logger = SimpleNamespace(info=lambda *a, **k: None, warning=lambda *a, **k: None, error=lambda *a, **k: None)

        data_manager = data_manager_cls.return_value
        data_manager.get_dataset_info.return_value = {
            "train": {"patients": 1, "samples": 1, "positive_samples": 1, "negative_samples": 0},
            "val": {"patients": 1, "samples": 1, "positive_samples": 0, "negative_samples": 1},
            "test": {"patients": 1, "samples": 0, "positive_samples": 0, "negative_samples": 0},
        }
        class EmptyDataset:
            samples = []

            def __len__(self):
                return 0

        train_loader = SimpleNamespace(dataset=SimpleNamespace(samples=[]))
        val_loader = object()
        test_loader = SimpleNamespace(dataset=EmptyDataset())
        data_manager.get_train_dataloader.return_value = train_loader
        data_manager.get_val_dataloader.return_value = val_loader
        data_manager.get_test_dataloader.return_value = test_loader

        trainer = trainer_cls.return_value
        trainer.train.return_value = (["train"], ["val"])

        result = train.train_with_split(splitter, config, args, logger)

        self.assertEqual(result["type"], "single_split")
        export_mock.assert_called_once_with(
            experiment_dir="/tmp",
            experiment_name="exp1",
            test_patients=["P3"],
            labels={"P3": 1},
            organizer=splitter.organizer,
            source_data_path="/tmp/data",
            active_axes=["x", "y", "z"],
            logger=logger,
        )


class TrainCliValidationTest(unittest.TestCase):
    def test_axis_stage_requires_axis_option(self):
        runner = CliRunner()

        result = runner.invoke(app, ["train", "--config", "cfg", "--stage", "axis"])

        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("--axis", result.output)


if __name__ == "__main__":
    unittest.main()
