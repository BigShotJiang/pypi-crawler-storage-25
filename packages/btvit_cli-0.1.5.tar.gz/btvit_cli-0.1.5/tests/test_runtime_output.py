import tempfile
import unittest
from pathlib import Path

from src.cli.train_impl import configure_stage_runtime
from src.utils.config import load_config
from src.utils.logger import get_logger
from src.utils.runtime_output import (
    _mode_arrow,
    _short_metric_name,
)
from src.training.epoch_progress_tracker import EpochProgressTracker


class RuntimeOutputTest(unittest.TestCase):
    def test_logger_can_run_without_console_output_and_still_write_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            logger = get_logger("silent_test", log_dir=tmpdir, console=False)
            logger.info("hello")

            log_files = list(Path(tmpdir).glob("*.log"))
            contents = log_files[0].read_text(encoding="utf-8") if log_files else ""

            self.assertEqual(len(log_files), 1)
            self.assertIn("hello", contents)

    def test_same_logger_name_different_dirs_do_not_reuse_previous_file_handler(self):
        with tempfile.TemporaryDirectory() as tmpdir_a, tempfile.TemporaryDirectory() as tmpdir_b:
            logger_a = get_logger("shared_name", log_dir=tmpdir_a, console=False)
            logger_a.info("from_a")

            logger_b = get_logger("shared_name", log_dir=tmpdir_b, console=False)
            logger_b.info("from_b")

            files_a = list(Path(tmpdir_a).glob("*.log"))
            files_b = list(Path(tmpdir_b).glob("*.log"))
            contents_a = files_a[0].read_text(encoding="utf-8") if files_a else ""
            contents_b = files_b[0].read_text(encoding="utf-8") if files_b else ""

            self.assertEqual(len(files_a), 1)
            self.assertEqual(len(files_b), 1)
            self.assertIn("from_a", contents_a)
            self.assertIn("from_b", contents_b)

    def test_epoch_progress_tracker_can_be_disabled(self):
        tracker = EpochProgressTracker(total_epochs=3, verbose=False)
        try:
            self.assertTrue(tracker.bar.disable)
        finally:
            tracker.close()

    def test_logger_config_output_uses_effective_monitoring_and_hides_legacy_experiment_monitor_fields(self):
        config = load_config("configs/test")
        configure_stage_runtime(config, type("Args", (), {"stage": "axis", "axis": "x"})())

        with tempfile.TemporaryDirectory() as tmpdir:
            logger = get_logger("config_test", log_dir=tmpdir, console=False)
            logger.log_config(config)

            log_files = list(Path(tmpdir).glob("*.log"))
            contents = log_files[0].read_text(encoding="utf-8") if log_files else ""

            self.assertNotIn("monitor_metric:", contents)
            self.assertNotIn("monitor_mode:", contents)
            self.assertIn("early_stopping:", contents)
            self.assertIn("model_selection:", contents)


class RuntimeOutputFormattingTest(unittest.TestCase):
    def test_mode_arrow_max(self):
        self.assertEqual(_mode_arrow("max"), "\u2191")

    def test_mode_arrow_min(self):
        self.assertEqual(_mode_arrow("min"), "\u2193")

    def test_short_metric_name_known(self):
        self.assertEqual(_short_metric_name("val_accuracy"), "val_acc")
        self.assertEqual(_short_metric_name("predict_accuracy"), "predict_acc")
        self.assertEqual(_short_metric_name("val_auc"), "val_auc")
        self.assertEqual(_short_metric_name("val_loss"), "val_loss")
        self.assertEqual(_short_metric_name("val_f1"), "val_f1")

    def test_short_metric_name_unknown_passthrough(self):
        self.assertEqual(_short_metric_name("custom_metric"), "custom_metric")

    def test_tracker_update_train_progress(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        try:
            tracker.update_train_progress(5, 10, 0.2166)
            postfix = tracker.bar.postfix
            self.assertIn("train", postfix)
        finally:
            tracker.close()

    def test_tracker_update_val_progress(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        try:
            tracker.update_val_progress(3, 10, 0.1890)
            postfix = tracker.bar.postfix
            self.assertIn("val", postfix)
        finally:
            tracker.close()

    def test_tracker_finish_epoch_with_esp_ms(self):
        es_config = {"enabled": True, "metric": "val_auc", "mode": "max", "patience": 50, "min_delta": 0.0001}
        ms_config = {"metric": "predict_accuracy", "mode": "max"}
        tracker = EpochProgressTracker(
            total_epochs=500, verbose=False,
            early_stopping_config=es_config,
            model_selection_config=ms_config,
        )
        try:
            tracker.finish_epoch(
                17, lr=0.00065,
                best_epoch=1, best_metric=0.5556,
                validated=True,
                esp_counter=14, esp_metric_value=0.4522,
            )
            postfix = tracker.bar.postfix
            self.assertIn("val_auc", postfix)
            self.assertIn("predict_accuracy", postfix)
            self.assertIn("best:1", postfix)
        finally:
            tracker.close()

    def test_tracker_min_mode_format(self):
        es_config = {"enabled": True, "metric": "val_loss", "mode": "min", "patience": 10, "min_delta": 0.0001}
        tracker = EpochProgressTracker(
            total_epochs=100, verbose=False,
            early_stopping_config=es_config,
        )
        try:
            tracker.finish_epoch(
                5, lr=0.0001,
                best_epoch=3, best_metric=0.1890,
                validated=True,
                esp_counter=3, esp_metric_value=0.2166,
            )
            postfix = tracker.bar.postfix
            self.assertIn("val_loss", postfix)
        finally:
            tracker.close()

    def test_tracker_patience_hidden_when_esp_disabled(self):
        ms_config = {"metric": "predict_accuracy", "mode": "max"}
        tracker = EpochProgressTracker(
            total_epochs=10, verbose=False,
            model_selection_config=ms_config,
        )
        try:
            tracker.finish_epoch(
                1, lr=0.001,
                best_epoch=1, best_metric=0.5556,
                validated=True,
            )
            postfix = tracker.bar.postfix
            self.assertNotIn("patience(", postfix)
            self.assertIn("predict_accuracy", postfix)
        finally:
            tracker.close()


if __name__ == "__main__":
    unittest.main()
