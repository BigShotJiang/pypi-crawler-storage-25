import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np
import torch

from src.cli.predict_impl import build_prediction_rows
from src.prediction.patient_predictor import PatientPredictor


class _DummyAxisModel(torch.nn.Module):
    def forward(self, images):
        values = images.reshape(images.shape[0], -1).mean(dim=1, keepdim=True)
        return (values - 0.25) * 4.0

    def extract_features(self, images):
        values = images.reshape(images.shape[0], -1).mean(dim=1, keepdim=True)
        return values.repeat(1, 4)


class _DummyFusionHead(torch.nn.Module):
    def forward(self, features):
        return features.mean(dim=1, keepdim=True) * 2.0 - 0.5


class DualOutputSmokeTest(unittest.TestCase):
    def _make_png(self, path: Path, value: int) -> None:
        image = np.full((16, 368), value, dtype=np.uint8)
        cv2.imwrite(str(path), image)

    def test_dual_output_patient_pipeline_runs_on_temp_data(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            axis_paths = {}
            for axis, value in (("x", 96), ("y", 160), ("z", 224)):
                axis_dir = root / f"data-{axis}"
                axis_dir.mkdir()
                axis_paths[axis] = str(axis_dir)

                for index in range(2):
                    if axis == "x":
                        filename = f"P001_{index}_0_0.png"
                    elif axis == "y":
                        filename = f"P001_0_{index}_0.png"
                    else:
                        filename = f"P001_0_0_{index}.png"
                    self._make_png(axis_dir / filename, value)

            predictor = PatientPredictor.__new__(PatientPredictor)
            predictor.mode = "both"
            predictor.active_axes = ["x", "y", "z"]
            predictor.voting_weights = {"x": 0.2, "y": 0.3, "z": 0.5}
            predictor.weighted_vote_threshold = 0.5
            predictor.fusion_nn_threshold = 0.5
            predictor.device = torch.device("cpu")
            predictor.verbose = False
            predictor.axis_models = {axis: _DummyAxisModel() for axis in predictor.active_axes}
            predictor.fusion_head = _DummyFusionHead()
            predictor.image_processor = type("ImageProcessorProxy", (), {})()
            predictor.image_processor.load_image = lambda image_path: cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
            predictor.image_processor.normalize_image = (
                lambda image: image.astype(np.float32) / 255.0
            )

            result = PatientPredictor.predict_patient(predictor, "P001", axis_data_paths=axis_paths)
            rows = build_prediction_rows([result], {"P001": 1})

        self.assertEqual(rows[0]["patient_id"], "P001")
        self.assertIn("weighted_vote_prob", rows[0])
        self.assertIn("fusion_nn_prob", rows[0])
        self.assertTrue(rows[0]["weighted_vote_pass"])
        self.assertTrue(rows[0]["fusion_nn_pass"])


if __name__ == "__main__":
    unittest.main()
