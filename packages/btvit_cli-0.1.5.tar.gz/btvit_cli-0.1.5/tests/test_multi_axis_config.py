import tempfile
import textwrap
import unittest
from pathlib import Path

from src.utils.config import load_config


class MultiAxisConfigTest(unittest.TestCase):
    def write_yaml(self, root: Path, name: str, content: str) -> None:
        (root / name).write_text(textwrap.dedent(content).strip() + "\n", encoding="utf-8")

    def test_load_config_reads_stage_training_and_dual_output_blocks(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir)
            self.write_yaml(config_dir, "model_config.yaml", "model:\n  input_shape: [16, 368]\n")
            self.write_yaml(config_dir, "data_config.yaml", "data:\n  label_path: dataset/label.csv\n")
            self.write_yaml(
                config_dir,
                "training_config.yaml",
                """
                training:
                  common:
                    device: cpu
                    num_workers: 0
                    mixed_precision: false
                    gradient_clip_val: 0.0
                    accumulate_grad_batches: 1
                  axis:
                    epochs: 6
                    batch_size: 32
                    learning_rate: 0.001
                    weight_decay: 0.01
                    optimizer: AdamW
                    scheduler: CosineAnnealingLR
                    scheduler_params: {T_max: 6, eta_min: 1.0e-6}
                  fusion:
                    epochs: 3
                    batch_size: 8
                    learning_rate: 0.01
                    weight_decay: 0.0
                    optimizer: AdamW
                    scheduler: CosineAnnealingLR
                    scheduler_params: {T_max: 3, eta_min: 1.0e-6}
                    freeze_encoders: true
                """,
            )
            self.write_yaml(config_dir, "experiment_config.yaml", "name: demo\n")
            self.write_yaml(
                config_dir,
                "multi_axis_config.yaml",
                """
                multi_axis:
                  axis_data_paths:
                    x: dataset/data-x
                    y: dataset/data-y
                    z: dataset/data-z
                  active_axes: [x, y, z]
                  patient_pooling:
                    image_feature_pooling: mean
                    image_probability_pooling: mean
                  weighted_vote:
                    enabled: true
                    weights: {x: 0.2, y: 0.2, z: 0.6}
                  fusion_head:
                    enabled: true
                    type: linear
                    hidden_dim: 128
                    dropout: 0.1
                """,
            )
            self.write_yaml(
                config_dir,
                "monitoring_config.yaml",
                """
                monitoring:
                  early_stopping:
                    enabled: false
                    metric: val_auc
                    mode: max
                    patience: 5
                    min_delta: 0.001
                  model_selection:
                    metric: predict_accuracy
                    mode: max
                  predict_threshold: 0.55
                  verbose: true
                """,
            )

            config = load_config(str(config_dir))

        self.assertEqual(config.training.common.device, "cpu")
        self.assertEqual(config.training.axis.batch_size, 32)
        self.assertTrue(config.training.fusion.freeze_encoders)
        self.assertEqual(config.multi_axis.patient_pooling.image_feature_pooling, "mean")
        self.assertEqual(config.multi_axis.weighted_vote.weights["z"], 0.6)
        self.assertEqual(config.multi_axis.fusion_head.type, "linear")
        self.assertEqual(config.monitoring.model_selection["metric"], "predict_accuracy")
        self.assertFalse(config.monitoring.early_stopping["enabled"])
        self.assertEqual(config.monitoring.prediction.weighted_vote_threshold, 0.55)
        self.assertEqual(config.monitoring.prediction.fusion_nn_threshold, 0.55)
        self.assertTrue(config.monitoring.verbose)


if __name__ == "__main__":
    unittest.main()
