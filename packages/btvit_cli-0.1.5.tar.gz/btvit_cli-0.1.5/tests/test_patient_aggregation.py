import numpy as np
import pytest

from src.prediction.aggregation import (
    aggregate_patient_feature_mean,
    aggregate_patient_probability_mean,
    weighted_vote_patient_probability,
)


def test_mean_aggregation_for_patient_probabilities_and_features():
    probabilities = [0.2, 0.6, 0.8]
    features = [np.array([1.0, 3.0]), np.array([3.0, 5.0])]

    assert aggregate_patient_probability_mean(probabilities) == pytest.approx(0.5333333)
    np.testing.assert_allclose(aggregate_patient_feature_mean(features), np.array([2.0, 4.0]))


def test_weighted_vote_patient_probability_normalizes_weights():
    axis_probabilities = {"x": 0.1, "y": 0.5, "z": 0.9}
    weights = {"x": 1.0, "y": 1.0, "z": 2.0}

    result = weighted_vote_patient_probability(axis_probabilities, weights)

    assert result == pytest.approx(0.6)
