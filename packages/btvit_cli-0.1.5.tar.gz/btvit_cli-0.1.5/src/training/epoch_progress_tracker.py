"""Global epoch-level TQDM progress bar for training loops."""

from tqdm import tqdm


class EpochProgressTracker:
    """Owns a single tqdm bar spanning all epochs.

    Inner batch loops report progress via *update_train_progress* /
    *update_val_progress* so that only one bar is visible at a time.
    """

    def __init__(
        self,
        total_epochs: int,
        initial: int = 0,
        early_stopping_config: dict | None = None,
        model_selection_config: dict | None = None,
        verbose: bool = True,
    ):
        self.bar = tqdm(
            total=total_epochs,
            initial=initial,
            disable=not verbose,
            dynamic_ncols=True,
            unit="epoch",
        )

        # Internal state
        self._epochs_completed: int = initial
        self._state: str = "idle"
        self._train_progress: float = 0.0
        self._val_progress: float = 0.0
        self._current_loss: float = 0.0
        self._val_loss: float = 0.0
        self._best_epoch: int | None = None
        self._best_metric: float | None = None

        # Early stopping fields
        es = early_stopping_config or {}
        self._early_stopping_enabled: bool = bool(es.get("enabled", False))
        self._esp_patience: int = int(es.get("patience", 0))
        self._esp_metric_name: str = str(es.get("metric", ""))
        self._esp_direction: str = "\u2191" if es.get("mode", "max") == "max" else "\u2193"
        self._esp_counter: int | None = None
        self._esp_metric_value: float | None = None
        self._esp_reason: str = ""

        # Model selection fields
        ms = model_selection_config or {}
        self._ms_metric_name: str = str(ms.get("metric", ""))
        self._ms_direction: str = "\u2191" if ms.get("mode", "max") == "max" else "\u2193"

        # Decimal places for metric display
        min_delta = float(es.get("min_delta", 0.0001)) if es else 0.0001
        self._decimal_places: int = self._compute_decimal_places(min_delta)

        self._refresh_postfix()

    # ------------------------------------------------------------------
    # Static helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_decimal_places(min_delta: float) -> int:
        """Return the number of decimal places needed to display *min_delta*."""
        if min_delta <= 0:
            return 4
        places = 0
        while min_delta < 1 and places < 8:
            min_delta *= 10
            places += 1
        return max(places, 1)

    def _format_lr(self, lr: float) -> str:
        if abs(lr) < 0.001 and lr != 0.0:
            return f"{lr:.1e}"
        return f"{lr:.4f}"

    # ------------------------------------------------------------------
    # Progress updates
    # ------------------------------------------------------------------

    def update_train_progress(self, batch_idx: int, total_batches: int, avg_loss: float):
        self._state = "train"
        self._train_progress = (batch_idx + 1) / total_batches * 100 if total_batches else 0
        self._current_loss = avg_loss
        self._refresh_postfix()

    def update_val_progress(self, batch_idx: int, total_batches: int, avg_val_loss: float):
        self._state = "val"
        self._val_progress = (batch_idx + 1) / total_batches * 100 if total_batches else 0
        self._val_loss = avg_val_loss
        self._refresh_postfix()

    def finish_epoch(
        self,
        epoch: int,
        lr: float = 0.0,
        best_epoch: int | None = None,
        best_metric: float | None = None,
        validated: bool = True,
        esp_counter: int | None = None,
        esp_metric_value: float | None = None,
    ):
        if validated and best_epoch is not None and best_metric is not None:
            self._best_epoch = best_epoch
            self._best_metric = best_metric
        self._esp_counter = esp_counter
        self._esp_metric_value = esp_metric_value
        self._state = "idle"
        self._current_lr = lr
        self._refresh_postfix()
        self._epochs_completed += 1
        self.bar.update(1)

    def mark_early_stopped(self, epoch: int, reason: str):
        self._esp_reason = f"STOPPED@{epoch}: {reason}"
        self._refresh_postfix()

    def close(self):
        self.bar.close()

    # ------------------------------------------------------------------
    # Postfix formatting
    # ------------------------------------------------------------------

    def _refresh_postfix(self):
        parts: list[str] = []

        # State
        if self._state == "train":
            parts.append(f"state:train[train:{self._train_progress:.0f}%]")
        elif self._state == "val":
            parts.append(f"state:val[val:{self._val_progress:.0f}%]")
        else:
            parts.append("state:idle")

        # Losses
        if self._current_loss > 0:
            parts.append(f"loss:{self._current_loss:.{self._decimal_places}f}")
        if self._val_loss > 0:
            parts.append(f"val_loss:{self._val_loss:.{self._decimal_places}f}")

        # Early stopping patience
        if self._early_stopping_enabled:
            esp_tag = f"esp-( {self._esp_metric_name}/{self._esp_direction})"
            if self._esp_counter is not None:
                esp_tag += f":{self._esp_counter}/{self._esp_patience}"
            if self._esp_metric_value is not None:
                esp_tag += f"={self._esp_metric_value:.{self._decimal_places}f}"
            parts.append(esp_tag)

        # Model selection
        if self._ms_metric_name and self._best_metric is not None:
            dp = self._decimal_places
            parts.append(
                f"MS-({self._ms_metric_name}/{self._ms_direction})"
                f":{self._best_metric:.{dp}f}"
            )

        # Learning rate
        lr = getattr(self, "_current_lr", None)
        if lr is not None:
            parts.append(f"lr:{self._format_lr(lr)}")

        # Best epoch
        if self._best_epoch is not None:
            parts.append(f"best:{self._best_epoch}")

        # Early stop reason
        if self._esp_reason:
            parts.append(self._esp_reason)

        self.bar.set_postfix_str(" ".join(parts))
