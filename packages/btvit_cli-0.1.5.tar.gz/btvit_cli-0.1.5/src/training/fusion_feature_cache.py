from typing import Mapping

import torch

from src.prediction.aggregation import aggregate_patient_feature_mean


def build_patient_feature_cache(dataset, encoders: Mapping[str, torch.nn.Module], device: str = "cpu"):
    device_obj = torch.device(device)
    feature_rows = {}

    for encoder in encoders.values():
        encoder.to(device_obj)
        encoder.eval()

    with torch.no_grad():
        for sample in dataset:
            patient_id = sample["patient_id"]
            label = int(sample["label"].item())
            row = {"label": label}

            for axis, images in sample["axis_images"].items():
                encoder = encoders[axis]
                image_batch = images.to(device_obj)
                features = encoder.extract_features(image_batch).detach().cpu().numpy()
                row[axis] = aggregate_patient_feature_mean(features)

            feature_rows[patient_id] = row

    return feature_rows
