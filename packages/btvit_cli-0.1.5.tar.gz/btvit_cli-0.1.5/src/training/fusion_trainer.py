import os
from typing import Dict, Iterable, Mapping

import torch
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

from src.model.axis_model import AxisViTModel
from src.model.fusion_head import PatientFusionHead
from src.training.fusion_feature_cache import build_patient_feature_cache
from src.utils.logger import get_logger
from src.utils.metrics import MetricsCalculator


def resolve_axis_checkpoints(
    save_dir: str,
    experiment_name: str,
    overrides: Mapping[str, str | None] | None = None,
    active_axes: Iterable[str] | None = None,
) -> Dict[str, str]:
    active_axes = list(active_axes or ("x", "y", "z"))
    overrides = dict(overrides or {})
    resolved_paths: Dict[str, str] = {}

    for axis in active_axes:
        checkpoint_path = overrides.get(axis) or os.path.join(
            save_dir,
            experiment_name,
            f"axis-{axis}",
            "checkpoints",
            "best_model.pth",
        )
        if not os.path.exists(checkpoint_path):
            raise FileNotFoundError(f"missing axis checkpoint for {axis}: {checkpoint_path}")
        resolved_paths[axis] = checkpoint_path

    return resolved_paths


class FusionTrainer:
    def __init__(self, config, axis_checkpoint_paths: Mapping[str, str], logger=None, save_checkpoints: bool = True):
        self.config = config
        self.axis_checkpoint_paths = dict(axis_checkpoint_paths)
        self.logger = logger or get_logger("FusionTrainer", config.experiment.log_dir, console=False)
        self.save_checkpoints = save_checkpoints

        common_training = getattr(config.training, "common", config.training)
        self.fusion_training = getattr(config.training, "fusion", config.training)
        self.monitoring = getattr(config.monitoring, "fusion", getattr(config, "monitoring", None))
        self.active_axes = list(getattr(config.multi_axis, "active_axes", ["x", "y", "z"]))
        self.device = torch.device(getattr(common_training, "device", "cpu"))
        self.freeze_encoders = bool(getattr(self.fusion_training, "freeze_encoders", True))
        if not self.freeze_encoders:
            raise NotImplementedError("Fusion-stage encoder finetuning is not implemented yet")

        os.makedirs(config.experiment.checkpoint_dir, exist_ok=True)
        os.makedirs(config.experiment.result_dir, exist_ok=True)
        os.makedirs(config.experiment.log_dir, exist_ok=True)

        self.encoders = self._load_encoders()
        feature_dim = int(getattr(config.model, "dim", 512))
        fusion_head_config = getattr(config.multi_axis, "fusion_head", None)
        head_type = getattr(fusion_head_config, "type", "linear")
        hidden_dim = int(getattr(fusion_head_config, "hidden_dim", 256))
        dropout = float(getattr(fusion_head_config, "dropout", 0.2))
        self.model = PatientFusionHead(
            input_dim=feature_dim * len(self.active_axes),
            head_type=head_type,
            hidden_dim=hidden_dim,
            dropout=dropout,
        ).to(self.device)
        self.criterion = torch.nn.BCEWithLogitsLoss()
        self.optimizer = self._create_optimizer()
        self.scheduler = self._create_scheduler()
        self.best_metric = float("-inf")
        self.best_epoch = 0

    def _build_encoder(self) -> AxisViTModel:
        return AxisViTModel(
            input_shape=tuple(self.config.model.input_shape),
            patch_size=tuple(self.config.model.patch_size),
            num_classes=getattr(self.config.model, "num_classes", 1),
            dim=getattr(self.config.model, "dim", 512),
            depth=getattr(self.config.model, "depth", 6),
            heads=getattr(self.config.model, "heads", 8),
            mlp_dim=getattr(self.config.model, "mlp_dim", 2048),
            channels=getattr(self.config.model, "channels", 1),
            dim_head=getattr(self.config.model, "dim_head", 64),
            dropout=getattr(self.config.model, "dropout", 0.1),
            emb_dropout=getattr(self.config.model, "emb_dropout", 0.1),
            rope_min_freq=getattr(self.config.model, "rope_min_freq", 1.0),
            rope_max_freq=getattr(self.config.model, "rope_max_freq", 10000.0),
            rope_p_zero_freqs=getattr(self.config.model, "rope_p_zero_freqs", 0.0),
        )

    def _load_checkpoint_state(self, checkpoint_path: str):
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        if isinstance(checkpoint, dict) and "model_state_dict" in checkpoint:
            return checkpoint["model_state_dict"]
        return checkpoint

    def _load_encoders(self):
        encoders = {}
        for axis in self.active_axes:
            encoder = self._build_encoder()
            encoder.load_state_dict(self._load_checkpoint_state(self.axis_checkpoint_paths[axis]), strict=False)
            encoder.to(self.device)
            encoder.eval()
            for parameter in encoder.parameters():
                parameter.requires_grad = False
            encoders[axis] = encoder
        return encoders

    def _create_optimizer(self):
        optimizer_name = getattr(self.fusion_training, "optimizer", "AdamW")
        learning_rate = float(getattr(self.fusion_training, "learning_rate", 1e-3))
        weight_decay = float(getattr(self.fusion_training, "weight_decay", 0.0))
        parameters = [parameter for parameter in self.model.parameters() if parameter.requires_grad]

        if optimizer_name == "Adam":
            return optim.Adam(parameters, lr=learning_rate, weight_decay=weight_decay)
        if optimizer_name == "SGD":
            return optim.SGD(parameters, lr=learning_rate, weight_decay=weight_decay)
        return optim.AdamW(parameters, lr=learning_rate, weight_decay=weight_decay)

    def _create_scheduler(self):
        scheduler_name = str(getattr(self.fusion_training, "scheduler", "") or "")
        scheduler_params = dict(getattr(self.fusion_training, "scheduler_params", {}) or {})
        epochs = int(getattr(self.fusion_training, "epochs", 1))

        if not scheduler_name:
            return None
        if scheduler_name == "CosineAnnealingLR":
            scheduler_params.setdefault("T_max", epochs)
            return optim.lr_scheduler.CosineAnnealingLR(self.optimizer, **scheduler_params)
        if scheduler_name == "StepLR":
            scheduler_params.setdefault("step_size", max(1, epochs // 3))
            scheduler_params.setdefault("gamma", 0.1)
            return optim.lr_scheduler.StepLR(self.optimizer, **scheduler_params)
        return None

    def _feature_rows_to_dataset(self, feature_rows):
        features = []
        labels = []
        for patient_id in sorted(feature_rows.keys()):
            row = feature_rows[patient_id]
            parts = [torch.tensor(row[axis], dtype=torch.float32) for axis in self.active_axes]
            features.append(torch.cat(parts, dim=0))
            labels.append(float(row["label"]))

        feature_tensor = torch.stack(features, dim=0) if features else torch.empty(0, 0)
        label_tensor = torch.tensor(labels, dtype=torch.float32)
        return TensorDataset(feature_tensor, label_tensor)

    def _evaluate_loader(self, data_loader, tracker=None):
        self.model.eval()
        metrics_calculator = MetricsCalculator()
        total_loss = 0.0
        num_batches = len(data_loader)

        with torch.no_grad():
            for batch_idx, (features, labels) in enumerate(data_loader):
                features = features.to(self.device)
                labels = labels.to(self.device).unsqueeze(1)

                outputs = self.model(features)
                loss = self.criterion(outputs, labels)

                total_loss += loss.item()
                metrics_calculator.update(outputs, labels)

                if tracker is not None:
                    tracker.update_val_progress(batch_idx, num_batches, total_loss / (batch_idx + 1))

        metrics = metrics_calculator.compute()
        metrics["loss"] = total_loss / num_batches if num_batches else 0.0
        return metrics

    def save_checkpoint(self, epoch: int, metric: float, is_best: bool = False):
        if not self.save_checkpoints:
            return

        checkpoint = {
            "epoch": epoch,
            "metric": metric,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "scheduler_state_dict": self.scheduler.state_dict() if self.scheduler else None,
            "axis_checkpoint_paths": self.axis_checkpoint_paths,
            "config": self.config,
        }
        checkpoint_path = os.path.join(self.config.experiment.checkpoint_dir, f"checkpoint_epoch_{epoch}.pth")
        torch.save(checkpoint, checkpoint_path)

        latest_path = os.path.join(self.config.experiment.checkpoint_dir, "latest_model.pth")
        torch.save(checkpoint, latest_path)

        if is_best:
            best_path = os.path.join(self.config.experiment.checkpoint_dir, "best_model.pth")
            torch.save(checkpoint, best_path)

    def train(self, train_dataset, val_dataset):
        from .epoch_progress_tracker import EpochProgressTracker

        train_rows = build_patient_feature_cache(train_dataset, self.encoders, device=str(self.device))
        val_rows = build_patient_feature_cache(val_dataset, self.encoders, device=str(self.device))

        train_loader = DataLoader(
            self._feature_rows_to_dataset(train_rows),
            batch_size=int(getattr(self.fusion_training, "batch_size", 8)),
            shuffle=True,
        )
        val_loader = DataLoader(
            self._feature_rows_to_dataset(val_rows),
            batch_size=int(getattr(self.fusion_training, "batch_size", 8)),
            shuffle=False,
        )

        model_selection = getattr(self.monitoring, "model_selection", {})
        if not isinstance(model_selection, dict):
            model_selection = dict(model_selection or {})
        selected_metric = model_selection.get("metric", "auc")

        verbose = bool(getattr(getattr(self.config, "monitoring", None), "verbose", False))
        tracker = EpochProgressTracker(
            total_epochs=int(getattr(self.fusion_training, "epochs", 1)),
            early_stopping_config=None,
            model_selection_config=model_selection if isinstance(model_selection, dict) else {},
            verbose=verbose,
        )

        train_history = []
        val_history = []
        for epoch in range(1, int(getattr(self.fusion_training, "epochs", 1)) + 1):
            self.model.train()
            total_loss = 0.0
            batch_count = len(train_loader)

            for batch_idx, (features, labels) in enumerate(train_loader):
                features = features.to(self.device)
                labels = labels.to(self.device).unsqueeze(1)

                self.optimizer.zero_grad()
                outputs = self.model(features)
                loss = self.criterion(outputs, labels)
                loss.backward()
                self.optimizer.step()

                total_loss += loss.item()

                if tracker is not None:
                    tracker.update_train_progress(batch_idx, batch_count, total_loss / (batch_idx + 1))

            if self.scheduler is not None:
                self.scheduler.step()

            train_metrics = {"loss": total_loss / batch_count if batch_count else 0.0}
            val_metrics = self._evaluate_loader(val_loader, tracker)
            train_history.append(train_metrics)
            val_history.append(val_metrics)

            current_metric = float(val_metrics.get(selected_metric, 0.0))
            is_best = current_metric >= self.best_metric
            if is_best:
                self.best_metric = current_metric
                self.best_epoch = epoch
            self.save_checkpoint(epoch, current_metric, is_best=is_best)

            current_lr = self.optimizer.param_groups[0]['lr']
            tracker.finish_epoch(
                epoch, lr=current_lr,
                best_epoch=self.best_epoch, best_metric=self.best_metric,
            )

        tracker.close()
        return train_history, val_history

    def evaluate(self, dataset):
        data_loader = DataLoader(
            self._feature_rows_to_dataset(build_patient_feature_cache(dataset, self.encoders, device=str(self.device))),
            batch_size=int(getattr(self.fusion_training, "batch_size", 8)),
            shuffle=False,
        )
        return self._evaluate_loader(data_loader)
