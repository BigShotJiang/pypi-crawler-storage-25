from torch import nn


class PatientFusionHead(nn.Module):
    def __init__(self, input_dim: int, head_type: str = "linear", hidden_dim: int = 256, dropout: float = 0.2):
        super().__init__()
        self.input_dim = int(input_dim)
        self.head_type = str(head_type)

        if self.head_type == "linear":
            self.head = nn.Sequential(
                nn.LayerNorm(self.input_dim),
                nn.Linear(self.input_dim, 1),
            )
        elif self.head_type == "mlp":
            self.head = nn.Sequential(
                nn.LayerNorm(self.input_dim),
                nn.Linear(self.input_dim, int(hidden_dim)),
                nn.GELU(),
                nn.Dropout(float(dropout)),
                nn.Linear(int(hidden_dim), 1),
            )
        else:
            raise ValueError(f"unsupported fusion head type: {head_type}")

    def forward(self, x):
        return self.head(x)
