import glob
import os
from typing import Dict, Iterable, List, Mapping, Optional

import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

from ..data.preprocessing import ImageProcessor, LabelProcessor
from ..model.axis_model import AxisViTModel
from ..model.fusion_head import PatientFusionHead
from ..prediction.aggregation import (
    aggregate_patient_feature_mean,
    aggregate_patient_probability_mean,
    weighted_vote_patient_probability,
)
from ..utils.config import load_config
from ..utils.runtime_output import create_prediction_progress


def _safe_auc(targets: List[int], probabilities: List[float]) -> float:
    if len(set(targets)) < 2:
        return float("nan")
    try:
        return float(roc_auc_score(targets, probabilities))
    except Exception:
        return float("nan")


class PatientPredictor:
    def __init__(
        self,
        axis_checkpoint_paths: Mapping[str, str],
        fusion_checkpoint_path: Optional[str] = None,
        *,
        mode: str = "both",
        config_path: Optional[str] = None,
        weighted_vote_threshold: Optional[float] = None,
        fusion_nn_threshold: Optional[float] = None,
        device: Optional[str] = None,
        verbose: bool = False,
    ):
        self.mode = str(mode).strip().lower()
        if self.mode not in {"weighted_vote", "fusion_nn", "both"}:
            raise ValueError("mode must be one of: weighted_vote, fusion_nn, both")

        self.axis_checkpoint_paths = {
            axis: path for axis, path in dict(axis_checkpoint_paths).items() if path
        }
        if not self.axis_checkpoint_paths:
            raise ValueError("axis_checkpoint_paths is required for patient prediction")

        self.fusion_checkpoint_path = fusion_checkpoint_path
        if self.mode in {"fusion_nn", "both"} and not self.fusion_checkpoint_path:
            raise ValueError("fusion checkpoint is required for fusion_nn or both modes")

        self.verbose = bool(verbose)
        self.checkpoints = self._load_checkpoints()
        self.config = self._resolve_config(config_path)
        self.active_axes = list(getattr(self.config.multi_axis, "active_axes", list(self.axis_checkpoint_paths.keys())))
        self.voting_weights = dict(
            getattr(getattr(self.config.multi_axis, "weighted_vote", None), "weights", None)
            or getattr(self.config.multi_axis, "voting_weights", {})
            or {axis: 1.0 for axis in self.active_axes}
        )
        prediction_monitoring = getattr(getattr(self.config, "monitoring", None), "prediction", None)
        self.weighted_vote_threshold = float(
            weighted_vote_threshold
            if weighted_vote_threshold is not None
            else getattr(prediction_monitoring, "weighted_vote_threshold", getattr(self.config.monitoring, "predict_threshold", 0.5))
        )
        self.fusion_nn_threshold = float(
            fusion_nn_threshold
            if fusion_nn_threshold is not None
            else getattr(prediction_monitoring, "fusion_nn_threshold", getattr(self.config.monitoring, "predict_threshold", 0.5))
        )

        requested_device = device or getattr(getattr(self.config.training, "common", self.config.training), "device", "cpu")
        if requested_device == "cuda" and not torch.cuda.is_available():
            requested_device = "cpu"
        self.device = torch.device(requested_device)
        self.image_processor = ImageProcessor(patch_size=tuple(self.config.model.patch_size))
        self.axis_models = self._load_axis_models()
        self.fusion_head = self._load_fusion_head() if self.mode in {"fusion_nn", "both"} else None

    def _load_checkpoints(self) -> Dict[str, object]:
        checkpoints: Dict[str, object] = {}
        for axis, checkpoint_path in self.axis_checkpoint_paths.items():
            checkpoints[f"axis:{axis}"] = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        if self.fusion_checkpoint_path:
            checkpoints["fusion"] = torch.load(self.fusion_checkpoint_path, map_location="cpu", weights_only=False)
        return checkpoints

    def _resolve_config(self, config_path: Optional[str]):
        if config_path:
            return load_config(config_path)

        checkpoint_candidates = []
        if "fusion" in self.checkpoints:
            checkpoint_candidates.append(self.checkpoints["fusion"])
        checkpoint_candidates.extend(self.checkpoints.values())

        for checkpoint in checkpoint_candidates:
            if isinstance(checkpoint, dict):
                checkpoint_config = checkpoint.get("config") or checkpoint.get("config_snapshot")
                if checkpoint_config is not None:
                    return checkpoint_config

        raise ValueError("prediction checkpoints do not contain config snapshot; please provide --config")

    def _build_axis_model(self) -> AxisViTModel:
        return AxisViTModel(
            input_shape=tuple(self.config.model.input_shape),
            patch_size=tuple(self.config.model.patch_size),
            num_classes=getattr(self.config.model, "num_classes", 1),
            dim=getattr(self.config.model, "dim", 512),
            depth=getattr(self.config.model, "depth", 6),
            heads=getattr(self.config.model, "heads", 8),
            mlp_dim=getattr(self.config.model, "mlp_dim", 2048),
            channels=getattr(self.config.model, "channels", 1),
            dim_head=getattr(self.config.model, "dim_head", 64),
            dropout=getattr(self.config.model, "dropout", 0.1),
            emb_dropout=getattr(self.config.model, "emb_dropout", 0.1),
            rope_min_freq=getattr(self.config.model, "rope_min_freq", 1.0),
            rope_max_freq=getattr(self.config.model, "rope_max_freq", 10000.0),
            rope_p_zero_freqs=getattr(self.config.model, "rope_p_zero_freqs", 0.0),
        )

    def _load_axis_models(self) -> Dict[str, AxisViTModel]:
        axis_models = {}
        for axis in self.active_axes:
            if axis not in self.axis_checkpoint_paths:
                raise FileNotFoundError(f"missing axis checkpoint path for axis {axis}")
            checkpoint = self.checkpoints[f"axis:{axis}"]
            state_dict = checkpoint.get("model_state_dict", checkpoint) if isinstance(checkpoint, dict) else checkpoint

            model = self._build_axis_model().to(self.device)
            model.load_state_dict(state_dict, strict=False)
            model.eval()
            axis_models[axis] = model
        return axis_models

    def _load_fusion_head(self):
        checkpoint = self.checkpoints.get("fusion")
        if checkpoint is None:
            return None

        fusion_head_config = getattr(self.config.multi_axis, "fusion_head", None)
        input_dim = int(getattr(self.config.model, "dim", 512)) * len(self.active_axes)
        fusion_head = PatientFusionHead(
            input_dim=input_dim,
            head_type=getattr(fusion_head_config, "type", "linear"),
            hidden_dim=int(getattr(fusion_head_config, "hidden_dim", 256)),
            dropout=float(getattr(fusion_head_config, "dropout", 0.2)),
        ).to(self.device)
        state_dict = checkpoint.get("model_state_dict", checkpoint) if isinstance(checkpoint, dict) else checkpoint
        fusion_head.load_state_dict(state_dict, strict=False)
        fusion_head.eval()
        return fusion_head

    def _load_axis_image(self, image_path: str) -> torch.Tensor:
        image = self.image_processor.load_image(image_path)
        image = self.image_processor.normalize_image(image)
        image = np.asarray(image, dtype=np.float32).reshape(1, image.shape[0], image.shape[1])
        return torch.from_numpy(image)

    def _collect_patient_axis_images(self, patient_id: str, axis_data_paths: Dict[str, str]) -> Dict[str, List[str]]:
        axis_images = {}
        for axis in self.active_axes:
            pattern = os.path.join(axis_data_paths[axis], f"{patient_id}_*.png")
            axis_images[axis] = sorted(glob.glob(pattern))
        return axis_images

    def _predict_axis_outputs(self, image_paths: Iterable[str], axis: str):
        tensors = [self._load_axis_image(image_path) for image_path in image_paths]
        image_batch = torch.stack(tensors, dim=0).to(self.device)
        model = self.axis_models[axis]

        with torch.no_grad():
            logits = model(image_batch)
            probabilities = torch.sigmoid(logits).detach().cpu().numpy().reshape(-1)
            features = model.extract_features(image_batch).detach().cpu().numpy()

        return (
            aggregate_patient_probability_mean(probabilities),
            aggregate_patient_feature_mean(features),
        )

    def predict_patient(self, patient_id: str, axis_data_paths: Dict[str, str]) -> Dict[str, object]:
        axis_images = self._collect_patient_axis_images(patient_id, axis_data_paths)
        missing_axes = [axis for axis in self.active_axes if not axis_images.get(axis)]
        if missing_axes:
            raise ValueError(f"patient {patient_id} is missing required axes: {', '.join(missing_axes)}")

        axis_probabilities = {}
        axis_features = {}
        axis_image_counts = {}

        for axis in self.active_axes:
            axis_probability, axis_feature = self._predict_axis_outputs(axis_images[axis], axis)
            axis_probabilities[axis] = axis_probability
            axis_features[axis] = axis_feature
            axis_image_counts[axis] = len(axis_images[axis])

        result = {
            "patient_id": patient_id,
            "axis_image_counts": axis_image_counts,
        }

        if self.mode in {"weighted_vote", "both"}:
            weighted_vote_prob = weighted_vote_patient_probability(axis_probabilities, self.voting_weights)
            result["weighted_vote_prob"] = float(weighted_vote_prob)
            result["weighted_vote_pred"] = int(weighted_vote_prob >= self.weighted_vote_threshold)

        if self.mode in {"fusion_nn", "both"}:
            feature_parts = [torch.tensor(axis_features[axis], dtype=torch.float32) for axis in self.active_axes]
            fusion_input = torch.cat(feature_parts, dim=0).unsqueeze(0).to(self.device)
            with torch.no_grad():
                fusion_logits = self.fusion_head(fusion_input)
                fusion_probability = float(torch.sigmoid(fusion_logits).item())
            result["fusion_nn_prob"] = fusion_probability
            result["fusion_nn_pred"] = int(fusion_probability >= self.fusion_nn_threshold)

        return result

    def _build_summary_metrics(self, results: List[Dict[str, object]], label_path: Optional[str]) -> Dict[str, object]:
        summary: Dict[str, object] = {
            "patient_count": len(results),
        }

        if self.mode in {"weighted_vote", "both"}:
            weighted_vote_probs = [float(result["weighted_vote_prob"]) for result in results]
            weighted_vote_preds = [int(result["weighted_vote_pred"]) for result in results]
            summary["weighted_vote_positive_count"] = int(sum(weighted_vote_preds))
            summary["weighted_vote_mean_prob"] = float(np.mean(weighted_vote_probs)) if weighted_vote_probs else 0.0

        if self.mode in {"fusion_nn", "both"}:
            fusion_probs = [float(result["fusion_nn_prob"]) for result in results]
            fusion_preds = [int(result["fusion_nn_pred"]) for result in results]
            summary["fusion_nn_positive_count"] = int(sum(fusion_preds))
            summary["fusion_nn_mean_prob"] = float(np.mean(fusion_probs)) if fusion_probs else 0.0

        if not label_path or not os.path.exists(label_path):
            return summary

        label_processor = LabelProcessor(label_path)
        labels_by_patient = {result["patient_id"]: label_processor.get_label(result["patient_id"]) for result in results}
        labeled_results = [result for result in results if labels_by_patient.get(result["patient_id"]) is not None]
        if not labeled_results:
            return summary

        targets = [int(labels_by_patient[result["patient_id"]]) for result in labeled_results]

        if self.mode in {"weighted_vote", "both"}:
            weighted_vote_probs = [float(result["weighted_vote_prob"]) for result in labeled_results]
            weighted_vote_preds = [int(result["weighted_vote_pred"]) for result in labeled_results]
            summary["weighted_vote_accuracy"] = float(accuracy_score(targets, weighted_vote_preds))
            summary["weighted_vote_f1"] = float(f1_score(targets, weighted_vote_preds, zero_division=0))
            summary["weighted_vote_auc"] = _safe_auc(targets, weighted_vote_probs)

        if self.mode in {"fusion_nn", "both"}:
            fusion_probs = [float(result["fusion_nn_prob"]) for result in labeled_results]
            fusion_preds = [int(result["fusion_nn_pred"]) for result in labeled_results]
            summary["fusion_nn_accuracy"] = float(accuracy_score(targets, fusion_preds))
            summary["fusion_nn_f1"] = float(f1_score(targets, fusion_preds, zero_division=0))
            summary["fusion_nn_auc"] = _safe_auc(targets, fusion_probs)

        return summary

    def predict_batch(
        self,
        patient_ids: List[str],
        axis_data_paths: Dict[str, str],
        label_path: Optional[str] = None,
    ):
        progress_bar = create_prediction_progress(total_steps=len(patient_ids), verbose=self.verbose)
        results = []
        try:
            for patient_id in patient_ids:
                results.append(self.predict_patient(patient_id, axis_data_paths))
                progress_bar.update(1)
        finally:
            progress_bar.close()

        return results, self._build_summary_metrics(results, label_path)
