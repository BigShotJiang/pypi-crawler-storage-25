"""Typer command for training."""

from typing import Optional

import typer

from src.cli.train_runner import execute_train_args


def execute_train(**kwargs):
    return execute_train_args(kwargs)


def train_command(
    config_path: str = typer.Option(
        ...,
        "--config",
        help="YAML配置目录路径。目录内应包含训练所需的全部配置文件。",
    ),
    stage: str = typer.Option(
        ...,
        "--stage",
        help="训练阶段。支持 axis 或 fusion。",
    ),
    axis: Optional[str] = typer.Option(
        None,
        "--axis",
        help="当 --stage axis 时必须指定训练轴：x、y 或 z。",
    ),
    data_path: Optional[str] = typer.Option(
        None,
        "--data",
        help="训练数据目录覆盖项。axis 阶段默认使用 multi_axis_config.yaml 中所选轴的路径。",
    ),
    label_path: Optional[str] = typer.Option(
        None,
        "--label",
        help="标签CSV路径覆盖项。支持 patient_id,label 或 0,1 表头。未提供时使用配置文件中的路径。",
    ),
    experiment_name: Optional[str] = typer.Option(
        None,
        "--experiment-name",
        help="实验名称覆盖项。若提供，将覆盖 experiment_config.yaml 中的名称。",
    ),
    random_seed: Optional[int] = typer.Option(
        None,
        "--random-seed",
        help="随机种子覆盖项，仅保留 stratified 训练主线。",
    ),
    epochs: Optional[int] = typer.Option(None, help="训练轮数覆盖项。"),
    batch_size: Optional[int] = typer.Option(None, "--batch-size", help="批次大小覆盖项。"),
    device: Optional[str] = typer.Option(None, help="训练设备覆盖项，如 cpu 或 cuda。"),
    verbose: bool = typer.Option(False, "--verbose", help="显示详细终端日志；未指定时仅保留 tqdm 动态进度。"),
    resume: bool = typer.Option(
        False,
        "--resume",
        help="恢复训练，默认从 latest_model.pth 继续。",
    ),
    disable_memory_preload: bool = typer.Option(
        False,
        "--disable-memory-preload",
        help="关闭默认启用的 memory preload。",
    ),
    preload_batch_size: Optional[int] = typer.Option(
        None,
        "--preload-batch-size",
        help="预加载批次大小覆盖项。",
    ),
    train_split_csv: Optional[str] = typer.Option(
        None,
        "--train-split-csv",
        help="预分割CSV路径，仅用于 stratified 训练主线。",
    ),
    csv_split_seed: Optional[int] = typer.Option(
        None,
        "--csv-split-seed",
        help="CSV重新划分随机种子。",
    ),
    use_csv_direct: bool = typer.Option(
        False,
        "--use-csv-direct",
        help="直接使用CSV中的 split 结果，不进行重新划分。",
    ),
    pre_model: Optional[str] = typer.Option(None, "--pre-model", help="预训练模型路径。"),
    axis_checkpoint_x: Optional[str] = typer.Option(None, "--axis-checkpoint-x", help="fusion 阶段的 x 轴 checkpoint 覆盖项。"),
    axis_checkpoint_y: Optional[str] = typer.Option(None, "--axis-checkpoint-y", help="fusion 阶段的 y 轴 checkpoint 覆盖项。"),
    axis_checkpoint_z: Optional[str] = typer.Option(None, "--axis-checkpoint-z", help="fusion 阶段的 z 轴 checkpoint 覆盖项。"),
    freeze_layers: Optional[str] = typer.Option(None, "--freeze-layers", help="冻结层配置。"),
    freeze_ratio: Optional[float] = typer.Option(None, "--freeze-ratio", help="冻结比例。"),
    load_weights_only: bool = typer.Option(False, "--load-weights-only", help="仅加载模型权重。"),
    strict_load: bool = typer.Option(False, "--strict-load", help="严格加载预训练权重。"),
    loss_type: Optional[str] = typer.Option(
        None,
        "--loss-type",
        help="损失函数类型: bce, focal, bce_label_smoothing。",
    ),
    focal_alpha: Optional[float] = typer.Option(
        None,
        "--focal-alpha",
        help="Focal Loss alpha (与 --loss-type focal 配合使用)。",
    ),
    focal_gamma: Optional[float] = typer.Option(
        None,
        "--focal-gamma",
        help="Focal Loss gamma (与 --loss-type focal 配合使用)。",
    ),
    label_smoothing: Optional[float] = typer.Option(
        None,
        "--label-smoothing",
        help="标签平滑系数 (与 --loss-type bce_label_smoothing 配合使用)。",
    ),
    pos_weight: Optional[float] = typer.Option(
        None,
        "--pos-weight",
        help="正样本权重。-1=自动计算, >0=手动指定。",
    ),
):
    """训练模型，支持 axis 与 fusion 两个阶段。"""
    normalized_stage = stage.strip().lower()
    normalized_axis = axis.strip().lower() if axis else None

    if normalized_stage not in {"axis", "fusion"}:
        typer.echo("Error: --stage must be one of: axis, fusion")
        raise typer.Exit(code=2)

    if normalized_stage == "axis" and normalized_axis is None:
        typer.echo("Error: --axis is required when --stage axis")
        raise typer.Exit(code=2)

    if normalized_stage == "fusion" and normalized_axis is not None:
        typer.echo("Error: --axis can only be used when --stage axis")
        raise typer.Exit(code=2)

    execute_train(
        config_path=config_path,
        stage=normalized_stage,
        axis=normalized_axis,
        data_path=data_path,
        label_path=label_path,
        experiment_name=experiment_name,
        random_seed=random_seed,
        epochs=epochs,
        batch_size=batch_size,
        device=device,
        verbose=verbose,
        resume="latest" if resume else None,
        disable_memory_preload=disable_memory_preload,
        preload_batch_size=preload_batch_size,
        train_split_csv=train_split_csv,
        csv_split_seed=csv_split_seed,
        use_csv_direct=use_csv_direct,
        pre_model=pre_model,
        axis_checkpoint_x=axis_checkpoint_x,
        axis_checkpoint_y=axis_checkpoint_y,
        axis_checkpoint_z=axis_checkpoint_z,
        freeze_layers=freeze_layers,
        freeze_ratio=freeze_ratio,
        load_weights_only=load_weights_only,
        strict_load=strict_load,
        loss_type=loss_type,
        focal_alpha=focal_alpha,
        focal_gamma=focal_gamma,
        label_smoothing=label_smoothing,
        pos_weight=pos_weight,
    )
