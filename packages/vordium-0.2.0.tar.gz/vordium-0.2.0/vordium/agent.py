import os
import asyncio
import requests
from web3 import Web3
from .config import RPC_URL, CHAIN_ID, FAUCET_URL, EXPLORER_URL, AGENT_REGISTRY
from .wallet import Wallet


REGISTRY_ABI = [
    {"inputs": [{"type": "string"}, {"type": "string"}, {"type": "address"}], "name": "registerAgent", "outputs": [{"type": "uint256"}], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [{"type": "address"}], "name": "isRegisteredAgent", "outputs": [{"type": "bool"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"type": "address"}], "name": "getAgentByWallet", "outputs": [{"components": [{"type": "uint256", "name": "id"}, {"type": "string", "name": "name"}, {"type": "string", "name": "strategyType"}, {"type": "address", "name": "owner"}, {"type": "address", "name": "agentWallet"}, {"type": "uint256", "name": "registeredAt"}, {"type": "bool", "name": "active"}, {"type": "uint256", "name": "totalTrades"}, {"type": "uint256", "name": "totalVolume"}], "type": "tuple"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"type": "address"}, {"type": "uint256"}], "name": "recordTrade", "outputs": [], "stateMutability": "nonpayable", "type": "function"},
]


class Agent:
    """
    Vordium AI Agent

    Usage:
        agent = Agent()
        print(agent.address)
        print(agent.balance)
        await agent.run()
    """

    def __init__(self, private_key: str = None):
        self._w3 = Web3(Web3.HTTPProvider(RPC_URL))

        if private_key:
            self._wallet = Wallet.from_key(private_key)
        elif os.getenv('VORDIUM_PRIVATE_KEY'):
            self._wallet = Wallet.from_key(os.getenv('VORDIUM_PRIVATE_KEY'))
        else:
            self._wallet = Wallet.create()
            print("New agent wallet created!")
            print(f"Address:     {self._wallet.address}")
            print(f"Private Key: {self._wallet.private_key}")
            print("Save this to your .env file:")
            print(f"VORDIUM_PRIVATE_KEY={self._wallet.private_key}")

    @property
    def address(self) -> str:
        return self._wallet.address

    @property
    def private_key(self) -> str:
        return self._wallet.private_key

    @property
    def balance(self) -> float:
        raw = self._w3.eth.get_balance(self.address)
        return float(self._w3.from_wei(raw, 'ether'))

    @property
    def block(self) -> int:
        return self._w3.eth.block_number

    def fund(self) -> bool:
        """Get free testnet VORD from faucet."""
        try:
            response = requests.post(
                f"{FAUCET_URL}/api/faucet",
                json={"address": self.address},
                timeout=30
            )
            if response.status_code == 200:
                print("Funded with 100 VORD")
                return True
            print(f"Faucet: {response.text}")
            return False
        except Exception as e:
            print(f"Faucet error: {e}")
            return False

    def send(self, to: str, amount: float) -> str:
        """Send VORD to an address."""
        nonce = self._w3.eth.get_transaction_count(self.address)
        tx = {
            'to': Web3.to_checksum_address(to),
            'value': self._w3.to_wei(amount, 'ether'),
            'gas': 21000,
            'gasPrice': self._w3.eth.gas_price,
            'nonce': nonce,
            'chainId': CHAIN_ID
        }
        signed = self._w3.eth.account.sign_transaction(tx, self.private_key)
        raw = getattr(signed, 'raw_transaction', None) or signed.rawTransaction
        tx_hash = self._w3.eth.send_raw_transaction(raw)
        tx_hex = tx_hash.hex()
        self._w3.eth.wait_for_transaction_receipt(tx_hash)
        print(f"Sent {amount} VORD")
        print(f"TX: {EXPLORER_URL}/tx/{tx_hex}")
        return tx_hex

    def is_healthy(self) -> bool:
        try:
            return self._w3.is_connected() and self.block > 0
        except Exception:
            return False

    async def run(self, strategy=None, interval: float = 1.0):
        """Run agent autonomously."""
        print(f"\nAgent: {self.address}")
        print(f"Balance: {self.balance} VORD")
        print(f"Block: {self.block:,}")
        status = 'Healthy' if self.is_healthy() else 'Unhealthy'
        print(f"Status: {status}")
        print("\nRunning... (Ctrl+C to stop)\n")

        while True:
            try:
                if strategy:
                    await strategy(self)
                else:
                    print(f"Block {self.block:,} | {self.balance:.4f} VORD")
                await asyncio.sleep(interval)
            except KeyboardInterrupt:
                print("\nAgent stopped.")
                break
            except Exception as e:
                print(f"Error: {e}")
                await asyncio.sleep(5)

    def register_on_chain(self, name: str, strategy_type: str = "trading") -> str:
        """Register this agent on the AgentRegistry contract."""
        registry = self._w3.eth.contract(
            address=Web3.to_checksum_address(AGENT_REGISTRY),
            abi=REGISTRY_ABI,
        )
        nonce = self._w3.eth.get_transaction_count(self.address)
        tx = registry.functions.registerAgent(
            name, strategy_type, self.address
        ).build_transaction({
            'from': self.address,
            'chainId': CHAIN_ID,
            'gas': 300000,
            'gasPrice': self._w3.eth.gas_price,
            'nonce': nonce,
        })
        signed = self._w3.eth.account.sign_transaction(tx, self.private_key)
        raw = getattr(signed, 'raw_transaction', None) or signed.rawTransaction
        tx_hash = self._w3.eth.send_raw_transaction(raw)
        tx_hex = tx_hash.hex()
        self._w3.eth.wait_for_transaction_receipt(tx_hash)
        print("Agent registered on-chain!")
        print(f"TX: {EXPLORER_URL}/tx/{tx_hex}")
        return tx_hex

    def is_registered(self) -> bool:
        """Check if this agent's wallet is registered on-chain."""
        registry = self._w3.eth.contract(
            address=Web3.to_checksum_address(AGENT_REGISTRY),
            abi=REGISTRY_ABI,
        )
        return registry.functions.isRegisteredAgent(self.address).call()

    def get_registration(self):
        """Fetch on-chain agent registration details, or None if not registered."""
        registry = self._w3.eth.contract(
            address=Web3.to_checksum_address(AGENT_REGISTRY),
            abi=REGISTRY_ABI,
        )
        data = registry.functions.getAgentByWallet(self.address).call()
        if data[0] == 0:
            return None
        return {
            "id": data[0], "name": data[1], "strategy_type": data[2],
            "owner": data[3], "agent_wallet": data[4],
            "registered_at": data[5], "active": data[6],
            "total_trades": data[7], "total_volume": data[8],
        }

    def __repr__(self):
        return f"Agent(address={self.address})"
