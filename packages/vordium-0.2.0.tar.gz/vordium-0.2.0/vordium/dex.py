"""Vordex DEX client for Vordium AI agents."""
from web3 import Web3
from .config import (
    ROUTER_ADDRESS, WVORD_ADDRESS, USDC_ADDRESS, PAIR_ADDRESS,
    CHAIN_ID, EXPLORER_URL,
)

ROUTER_ABI = [
    {"inputs": [{"type": "uint256"}, {"type": "uint256"}, {"type": "address[]"}, {"type": "address"}, {"type": "uint256"}], "name": "swapExactTokensForTokens", "outputs": [{"type": "uint256[]"}], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [{"type": "uint256"}, {"type": "uint256"}, {"type": "uint256"}], "name": "getAmountOut", "outputs": [{"type": "uint256"}], "stateMutability": "pure", "type": "function"},
]

PAIR_ABI = [
    {"inputs": [], "name": "getReserves", "outputs": [{"type": "uint112"}, {"type": "uint112"}, {"type": "uint32"}], "stateMutability": "view", "type": "function"},
    {"inputs": [], "name": "token0", "outputs": [{"type": "address"}], "stateMutability": "view", "type": "function"},
]

ERC20_ABI = [
    {"inputs": [{"type": "address"}, {"type": "uint256"}], "name": "approve", "outputs": [{"type": "bool"}], "stateMutability": "nonpayable", "type": "function"},
    {"inputs": [{"type": "address"}, {"type": "address"}], "name": "allowance", "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
    {"inputs": [{"type": "address"}], "name": "balanceOf", "outputs": [{"type": "uint256"}], "stateMutability": "view", "type": "function"},
]


class Vordex:
    """Vordex DEX client bound to an Agent."""

    def __init__(self, agent):
        self.agent = agent
        self.w3 = agent._w3
        self.router = self.w3.eth.contract(
            address=Web3.to_checksum_address(ROUTER_ADDRESS), abi=ROUTER_ABI
        )
        self.pair = self.w3.eth.contract(
            address=Web3.to_checksum_address(PAIR_ADDRESS), abi=PAIR_ABI
        )

    def _reserves(self):
        r0, r1, _ = self.pair.functions.getReserves().call()
        token0 = self.pair.functions.token0().call()
        is_wvord_0 = token0.lower() == WVORD_ADDRESS.lower()
        return r0, r1, is_wvord_0

    def price(self) -> float:
        """Current mid price: USDC per WVORD (via 1 WVORD quote)."""
        r0, r1, is_wvord_0 = self._reserves()
        wvord_r = r0 if is_wvord_0 else r1
        usdc_r = r1 if is_wvord_0 else r0
        amt_out = self.router.functions.getAmountOut(10 ** 18, wvord_r, usdc_r).call()
        return amt_out / 1e6

    def get_quote(self, token_in: str, amount: float) -> float:
        """Quote a swap output for `amount` of `token_in` ('WVORD' or 'USDC')."""
        r0, r1, is_wvord_0 = self._reserves()
        token_in = token_in.upper()
        if token_in == "WVORD":
            r_in = r0 if is_wvord_0 else r1
            r_out = r1 if is_wvord_0 else r0
            amt_in = int(amount * 1e18)
            decimals_out = 6
        else:
            r_in = r1 if is_wvord_0 else r0
            r_out = r0 if is_wvord_0 else r1
            amt_in = int(amount * 1e6)
            decimals_out = 18
        amt_out = self.router.functions.getAmountOut(amt_in, r_in, r_out).call()
        return amt_out / (10 ** decimals_out)

    def swap(self, token_in: str, token_out: str, amount: float, slippage: float = 0.005) -> str:
        """Execute a swap. Approves router first if needed. Returns tx hash."""
        token_in = token_in.upper()
        token_out = token_out.upper()

        addr_in = WVORD_ADDRESS if token_in == "WVORD" else USDC_ADDRESS
        addr_out = WVORD_ADDRESS if token_out == "WVORD" else USDC_ADDRESS

        decimals_in = 18 if token_in == "WVORD" else 6
        decimals_out = 6 if token_out == "USDC" else 18

        amt_in = int(amount * 10 ** decimals_in)
        quote = self.get_quote(token_in, amount)
        amt_out_min = int(quote * (1 - slippage) * 10 ** decimals_out)

        token = self.w3.eth.contract(
            address=Web3.to_checksum_address(addr_in), abi=ERC20_ABI
        )
        allowance = token.functions.allowance(
            self.agent.address, Web3.to_checksum_address(ROUTER_ADDRESS)
        ).call()

        if allowance < amt_in:
            nonce = self.w3.eth.get_transaction_count(self.agent.address)
            approve_tx = token.functions.approve(
                Web3.to_checksum_address(ROUTER_ADDRESS), 2 ** 256 - 1
            ).build_transaction({
                "from": self.agent.address,
                "chainId": CHAIN_ID,
                "gas": 100000,
                "gasPrice": self.w3.eth.gas_price,
                "nonce": nonce,
            })
            signed = self.w3.eth.account.sign_transaction(approve_tx, self.agent.private_key)
            raw = getattr(signed, "raw_transaction", None) or signed.rawTransaction
            tx = self.w3.eth.send_raw_transaction(raw)
            self.w3.eth.wait_for_transaction_receipt(tx)
            print(f"Approved {token_in}")

        deadline = self.w3.eth.get_block("latest")["timestamp"] + 300
        nonce = self.w3.eth.get_transaction_count(self.agent.address)
        swap_tx = self.router.functions.swapExactTokensForTokens(
            amt_in,
            amt_out_min,
            [Web3.to_checksum_address(addr_in), Web3.to_checksum_address(addr_out)],
            self.agent.address,
            deadline,
        ).build_transaction({
            "from": self.agent.address,
            "chainId": CHAIN_ID,
            "gas": 300000,
            "gasPrice": self.w3.eth.gas_price,
            "nonce": nonce,
        })
        signed = self.w3.eth.account.sign_transaction(swap_tx, self.agent.private_key)
        raw = getattr(signed, "raw_transaction", None) or signed.rawTransaction
        tx_hash = self.w3.eth.send_raw_transaction(raw)
        self.w3.eth.wait_for_transaction_receipt(tx_hash)

        hash_hex = tx_hash.hex()
        print(f"Swapped {amount} {token_in} -> {token_out}")
        print(f"TX: {EXPLORER_URL}/tx/{hash_hex}")
        return hash_hex
