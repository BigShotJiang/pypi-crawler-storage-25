"""Unit tests for starspace_cli.config — no network."""
from __future__ import annotations

from pathlib import Path

import pytest

from starspace_cli.config import (
    ensure_project_config_gitignored,
    write_project_config,
)


@pytest.fixture
def fake_git_repo(tmp_path: Path) -> Path:
    """A tmpdir that looks like a git checkout."""
    (tmp_path / ".git").mkdir()
    return tmp_path


def test_ensure_gitignored_creates_gitignore_when_missing(fake_git_repo: Path) -> None:
    config_path = write_project_config(
        "ws-id", "ak_test", base_url=None, root=fake_git_repo
    )
    result = ensure_project_config_gitignored(config_path)

    assert result is not None
    gitignore_path, line = result
    assert gitignore_path == fake_git_repo / ".gitignore"
    assert line == ".starspace/"
    assert gitignore_path.read_text() == ".starspace/\n"


def test_ensure_gitignored_appends_to_existing_gitignore(fake_git_repo: Path) -> None:
    gi = fake_git_repo / ".gitignore"
    gi.write_text("node_modules/\n*.log\n")
    config_path = write_project_config("ws", "ak", None, root=fake_git_repo)

    result = ensure_project_config_gitignored(config_path)
    assert result is not None
    contents = gi.read_text()
    assert contents.endswith(".starspace/\n")
    # Pre-existing rules are still there.
    assert "node_modules/" in contents
    assert "*.log" in contents


def test_ensure_gitignored_is_idempotent(fake_git_repo: Path) -> None:
    gi = fake_git_repo / ".gitignore"
    gi.write_text(".starspace/\n")
    config_path = write_project_config("ws", "ak", None, root=fake_git_repo)

    assert ensure_project_config_gitignored(config_path) is None
    assert gi.read_text() == ".starspace/\n"


def test_ensure_gitignored_recognizes_equivalent_rule_forms(fake_git_repo: Path) -> None:
    """`.starspace`, `.starspace/`, and `/.starspace/` all cover the dir."""
    gi = fake_git_repo / ".gitignore"
    gi.write_text("# comment\n.starspace\n")
    config_path = write_project_config("ws", "ak", None, root=fake_git_repo)
    assert ensure_project_config_gitignored(config_path) is None


def test_ensure_gitignored_handles_file_without_trailing_newline(
    fake_git_repo: Path,
) -> None:
    gi = fake_git_repo / ".gitignore"
    gi.write_text("node_modules/")  # no trailing \n
    config_path = write_project_config("ws", "ak", None, root=fake_git_repo)

    assert ensure_project_config_gitignored(config_path) is not None
    text = gi.read_text()
    assert text == "node_modules/\n.starspace/\n"


def test_ensure_gitignored_skips_when_not_in_git_repo(tmp_path: Path) -> None:
    """Outside a git checkout, init must not invent a .gitignore file."""
    config_path = write_project_config("ws", "ak", None, root=tmp_path)
    assert ensure_project_config_gitignored(config_path) is None
    assert not (tmp_path / ".gitignore").exists()
