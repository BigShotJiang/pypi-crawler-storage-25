"""`starspace init` - set up a workspace config interactively.

Prompts for workspace_id + API key, validates the API key against the
/whoami endpoint, then writes the config to ~/.config/starspace/config.json
(or ./.starspace/config.json with --project). Base URL defaults to
api.starspace.run silently; override with --base-url or STARSPACE_BASE_URL
for self-hosted / staging.
"""

from __future__ import annotations

from typing import Optional

import typer

from starspace_cli import output
from starspace_cli.client import DEFAULT_BASE_URL, StarSpaceClient
from starspace_cli.config import (
    ensure_project_config_gitignored,
    global_config_path,
    project_config_path,
    write_global_config,
    write_project_config,
)


def init(
    project: bool = typer.Option(
        False,
        "--project",
        help="Write config to ./.starspace/config.json instead of the global ~/.config/starspace/config.json.",
    ),
    workspace_id: Optional[str] = typer.Option(None, help="Workspace UUID. Skips the prompt if provided."),
    api_key: Optional[str] = typer.Option(None, help="Workspace API key (ak_…). Skips the prompt if provided."),
    base_url: Optional[str] = typer.Option(
        None,
        "--base-url",
        help=f"Override the StarSpace API base URL. Default: {DEFAULT_BASE_URL}",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite an existing config file without prompting."),
):
    """Initialize StarSpace CLI configuration."""

    target_path = project_config_path() if project else global_config_path()
    output.info(f"Writing config to: {target_path}")

    if target_path.exists() and not force:
        # Always require interactive confirmation for overwrite. In --json mode
        # the user should pass --force; without it we still abort safely.
        typer.confirm(
            f"Config already exists at {target_path}. Overwrite?",
            abort=True,
        )

    if not workspace_id:
        workspace_id = typer.prompt("Workspace ID")
    workspace_id = workspace_id.strip()
    if not workspace_id:
        raise output.fail("workspace ID cannot be empty", exit_code=1)

    if not api_key:
        api_key = typer.prompt("API key (ak_…)", hide_input=True)
    api_key = api_key.strip()
    if not api_key.startswith("ak_"):
        output.info("Warning: API key does not start with 'ak_'. Proceeding anyway.")

    # Default base URL is api.starspace.run. Users override only via the
    # --base-url flag or STARSPACE_BASE_URL env var; we don't prompt because
    # 99% of users are on the hosted product and the prompt is just friction.
    if base_url is None:
        base_url = DEFAULT_BASE_URL

    if base_url == DEFAULT_BASE_URL:
        base_url_to_persist: Optional[str] = None
    else:
        base_url_to_persist = base_url or None

    output.info("Validating API key against /whoami...")
    client = StarSpaceClient(api_key=api_key, base_url=base_url)
    info = client.whoami()  # StarSpaceError bubbles to main()

    returned_workspace = info.get("workspace_id")
    if returned_workspace and returned_workspace != workspace_id:
        raise output.fail(
            f"this API key belongs to workspace {returned_workspace}, "
            f"not {workspace_id}. Use the matching key or update the workspace ID.",
            exit_code=1,
        )

    tier = info.get("tier", "free")
    key_prefix = info.get("key_prefix", "")
    output.info(f"  ✓ key validated - tier: {tier}, prefix: {key_prefix}")

    gitignore_update: Optional[tuple] = None
    if project:
        path = write_project_config(workspace_id, api_key, base_url_to_persist)
        # The config file holds a workspace API key. If we're inside a git
        # repo and .starspace/ isn't already ignored, append the rule so a
        # casual `git add .` can't leak the key.
        gitignore_update = ensure_project_config_gitignored(path)
    else:
        path = write_global_config(workspace_id, api_key, base_url_to_persist)

    extra_lines = []
    if gitignore_update is not None:
        gitignore_path, line = gitignore_update
        extra_lines.append(
            f"Added '{line}' to {gitignore_path} (config contains your API key)."
        )

    result_payload = {
        "config_path": str(path),
        "workspace_id": workspace_id,
        "tier": tier,
        "key_prefix": key_prefix,
        "scope": "project" if project else "global",
    }
    if gitignore_update is not None:
        gitignore_path, line = gitignore_update
        result_payload["gitignore_updated"] = {
            "path": str(gitignore_path),
            "line": line,
        }

    human_lines = [f"Config written to {path}"]
    if extra_lines:
        human_lines.append("")
        human_lines.extend(extra_lines)
    human_lines.extend([
        "",
        "Next steps:",
        "  starspace push                 # upload your codebase",
        "  starspace connect claude       # generate Claude Desktop config snippet",
        "  starspace doctor               # diagnostics if anything looks wrong",
    ])

    output.result(result_payload, human="\n".join(human_lines))
