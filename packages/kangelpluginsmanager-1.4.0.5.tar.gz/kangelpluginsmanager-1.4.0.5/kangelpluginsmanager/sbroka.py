
import json
import os

from org.telegram.messenger import UserConfig
from client_utils import send_document, get_last_fragment
from ui.alert import AlertDialogBuilder
from ui.bulletin import BulletinHelper

from .methods import _normalize_requirements_list, _tr, log


def normalize_collection_plugins(raw_plugins):
    result = []
    seen = set()
    for item in raw_plugins or []:
        plugin_id = ""
        if isinstance(item, dict):
            plugin_id = str(item.get("id") or item.get("plugin_id") or "").strip()
        else:
            text = str(item or "").strip()
            if text.startswith("tg://kpm_install?plugin="):
                plugin_id = text.split("=", 1)[-1].strip()
            else:
                plugin_id = text
        if plugin_id and plugin_id not in seen:
            seen.add(plugin_id)
            result.append(plugin_id)
    return result


def build_collection_payload(metadata, plugin_ids):
    clean_metadata = {
        "name": str((metadata or {}).get("name") or "").strip(),
        "author": str((metadata or {}).get("author") or "").strip(),
        "description": str((metadata or {}).get("description") or "").strip(),
        "icon": str((metadata or {}).get("icon") or "").strip(),
    }
    normalized_ids = normalize_collection_plugins(plugin_ids)
    return {
        "metadata": clean_metadata,
        "plugins": [f"tg://kpm_install?plugin={pid}" for pid in normalized_ids],
        "format": "kpm_collection_v2",
    }


def load_collection_file(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        collection = json.load(f)
    metadata = dict(collection.get("metadata") or {})
    plugin_ids = normalize_collection_plugins(
        collection.get("plugins") or collection.get("links") or []
    )
    return metadata, plugin_ids, collection


def export_collection(plugin_instance, metadata, plugin_ids):
    try:
        collection = build_collection_payload(metadata, plugin_ids)
        collection_name = collection["metadata"].get("name") or "kpm_collection"
        safe_name = "".join(ch if ch.isalnum() or ch in "-_ " else "_" for ch in collection_name).strip() or "kpm_collection"
        file_path = os.path.join(plugin_instance.plugins_dir, f"{safe_name}.kpm")
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(collection, f, ensure_ascii=False, indent=4)

        current_account = UserConfig.selectedAccount
        user_id = UserConfig.getInstance(current_account).getClientUserId()
        send_document(user_id, file_path, caption=_tr("collection_exported"))
        BulletinHelper.show_success(_tr("collection_exported"))
    except Exception as e:
        log(f"[KPM] Export collection error: {e}")
        BulletinHelper.show_error(_tr("collection_error").format(e))


def import_collection(plugin_instance, file_path):
    try:
        metadata, plugin_ids, _collection = load_collection_file(file_path)
        plugin_instance._show_import_collection_designer(metadata, plugin_ids)
    except Exception as e:
        log(f"[KPM] Import collection error: {e}")
        BulletinHelper.show_error(_tr("collection_error").format(e))
