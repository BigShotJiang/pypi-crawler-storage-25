from games import _2DGame, RGBA

class TesteInput(_2DGame):
    def __init__(self):
        super().__init__(800, 600, "Teste de Input - Tiago")
        
        # Criar os objetos iniciais
        self.quadrado = self.draw_rectangle(375, 275, 50, 50, RGBA(255, 0, 0))
        self.instrucoes = self.draw_text("Setas para mover | Espaco para mudar cor", 
                                       "Arial", 20, 20, 560, RGBA(255, 255, 255))
        
        # Variáveis de controle de cor (começa vermelho)
        self.__cores = [RGBA(255, 0, 0), RGBA(0, 255, 0), RGBA(0, 0, 255), RGBA(255, 255, 0)]
        self.__indice_cor = 0

    def animation(self):
        # 1. TESTE DO PRESSED (Movimento contínuo)
        velocidade = 5
        if self.pressed("up"):
            self.quadrado[self.Y['RECTANGLES']] += velocidade
        if self.pressed("down"):
            self.quadrado[self.Y['RECTANGLES']] -= velocidade
        if self.pressed("left"):
            self.quadrado[self.X['RECTANGLES']] -= velocidade
        if self.pressed("right"):
            self.quadrado[self.X['RECTANGLES']] += velocidade

        # 2. TESTE DO CLICKED (Troca de cor única por clique)
        if self.clicked("space"):
            self.__indice_cor = (self.__indice_cor + 1) % len(self.__cores)
            # Atualiza a cor do retângulo no motor
            self.quadrado[self.COLOR['RECTANGLES']] = self.__cores[self.__indice_cor]
            print(f"Cor alterada para o índice: {self.__indice_cor}")

        # 3. TESTE DE COMBO (Sair do jogo)
        if self.pressed('ctrl+q'):
            self.close()

if __name__ == "__main__":
    app = TesteInput()
    #app.create_exe()
    app.create_exe()