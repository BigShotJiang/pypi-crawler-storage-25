from setuptools import setup, find_packages

setup(
    name="games-tiagoplays",
    version="0.0.1",
    author="TiagoPlays",
    description="A powerful and simple 2D game engine for Python with hardware acceleration (OpenGL) and one-click .exe generation.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pygame",
        "PyOpenGL",
        "PyInstaller"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6'
)