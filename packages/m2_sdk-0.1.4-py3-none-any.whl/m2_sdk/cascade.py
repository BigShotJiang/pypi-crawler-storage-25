"""Resource builder for Magento 2 REST API.

Provides a fluent cascade API that mirrors Magento's deeply nested REST paths.

Key design points:
- Path navigation via attribute access: ``client.products.media``
- Path parameters via calling: ``client.products(sku="X")``
- Filters feel natural: ``.filter(status="1")`` or ``.where("price", ">=", 100)``
- Terminal methods accept body inline: ``.post({"sku": "NEW"})``
- All searchCriteria plumbing is hidden internally

Usage::

    # List
    client.products().where("status", "==", "1").limit(10).get()

    # Get
    client.products(sku="TEST-001").get()

    # Nested
    client.products(sku="TEST-001").media.get()
    client.products(sku="TEST-001").media(id=42).get()
    client.orders(id=5).comments.post({"comment": "shipped"})

    # Create / Update
    client.products().post({"sku": "NEW", "name": "Widget"})
    client.products(sku="X").put({"price": 29.99})

    # Typed
    client.orders().where("status", "==", "pending").typed(OrderSearchResult).get()

    # Async
    await client.products().filter(status="1").aget()
"""

from __future__ import annotations

import re
from collections.abc import AsyncIterator, Iterator
from typing import TYPE_CHECKING, Any, TypeVar
from urllib.parse import quote

from pydantic import BaseModel

if TYPE_CHECKING:
    from m2_sdk.client import M2Client

T = TypeVar("T", bound=BaseModel)

_PATH_PARAM_RE = re.compile(r"\{(\w+)\}")


def _encode_path_value(value: str | int) -> str:
    """URL-encode a path segment value (handles SKUs with /, +, spaces)."""
    return quote(str(value), safe="")


# Human-readable condition operators → Magento conditionType
_OP_MAP: dict[str, str] = {
    "==": "eq",
    "=": "eq",
    "!=": "neq",
    ">": "gt",
    "<": "lt",
    ">=": "gteq",
    "<=": "lteq",
    "like": "like",
    "in": "finset",
    "finset": "finset",
}


class ResourceBuilder:
    """Fluent cascade builder for Magento REST API.

    Supports deeply nested resources, search criteria building,
    typed responses, and both sync/async execution.
    """

    def __init__(self, client: M2Client, path: str = "") -> None:
        self._client = client
        self._path = path
        self._params: dict[str, Any] = {}
        self._body: dict[str, Any] | None = None
        self._response_model: type[BaseModel] | None = None

    def _clone(self, path: str | None = None) -> ResourceBuilder:
        """Copy the builder so derived paths preserve filters, typing, and body."""
        clone = ResourceBuilder(self._client, self._path if path is None else path)
        clone._params = dict(self._params)
        clone._body = None if self._body is None else dict(self._body)
        clone._response_model = self._response_model
        return clone

    # ------------------------------------------------------------------
    # Path navigation
    # ------------------------------------------------------------------

    def __getattr__(self, name: str) -> ResourceBuilder:
        """Append path segment for sub-resource navigation.

        ``client.products.media`` → ``/products/media``
        ``client.orders(id=5).comments`` → ``/orders/5/comments``
        """
        if name.startswith("_"):
            raise AttributeError(name)
        segment = self._client._normalize_resource_segment(name)
        return self._clone(f"{self._path}/{segment}")

    def __call__(self, *path_args: str | int, **path_kwargs: str | int) -> ResourceBuilder:
        """Fill path parameters.

        Keyword args fill named placeholders::

            client.products(sku="X")              → /products/X
            client.products("X").media(id=42)     → /products/X/media/42

        Positional args fill placeholders in order::

            client.products("X").media(42)         → /products/X/media/42
        """
        new_path = self._path

        for key, value in path_kwargs.items():
            placeholder = "{" + key + "}"
            if placeholder in new_path:
                new_path = new_path.replace(placeholder, _encode_path_value(value), 1)
            else:
                new_path = f"{new_path}/{_encode_path_value(value)}"

        if path_args:
            for arg in path_args:
                m = _PATH_PARAM_RE.search(new_path)
                new_path = (
                    new_path.replace(m.group(0), _encode_path_value(arg), 1)
                    if m
                    else f"{new_path}/{_encode_path_value(arg)}"
                )

        return self._clone(new_path)

    # ------------------------------------------------------------------
    # Filter / query building
    # ------------------------------------------------------------------

    def filter(self, **kwargs: Any) -> ResourceBuilder:
        """Add equality filters (simple and readable).

        ``client.products().filter(status="1", type_id="simple").get()``

        Use ``%`` for LIKE::

            client.products().filter(name="%Widget%").get()
        """
        for field, value in kwargs.items():
            if value is not None:
                self._add_filter(field, value, self._detect_condition(value))
        return self

    def where(self, field: str, op_or_value: str, value: str | None = None) -> ResourceBuilder:
        """Add a filter with explicit condition.

        Three-argument form — field, operator, value::

            client.products().where("price", ">=", "100").get()
            client.orders().where("created_at", ">=", "2024-01-01").get()
            client.products().where("name", "like", "%Laptop%").get()
            client.products().where("status", "!=", "2").get()

        Two-argument form — field, value (equality)::

            client.products().where("status", "1").get()

        Supported operators: ``==``, ``=``, ``!=``, ``>``, ``<``, ``>=``, ``<=``,
        ``like``, ``in``, ``finset``
        """
        if value is not None:
            # Three-arg: field, op, value
            condition = _OP_MAP.get(op_or_value, op_or_value)
            self._add_filter(field, value, condition)
        else:
            # Two-arg: field, value (equality)
            self._add_filter(field, op_or_value, self._detect_condition(op_or_value))
        return self

    def sort_by(self, field: str, direction: str = "asc") -> ResourceBuilder:
        """Set sort order::

        client.products().sort_by("price", "desc").get()
        """
        self._params["searchCriteria[sortOrders][0][field]"] = field
        self._params["searchCriteria[sortOrders][0][direction]"] = direction.upper()
        return self

    def limit(self, count: int) -> ResourceBuilder:
        """Set page size::

        client.products().limit(50).get()
        """
        self._params["searchCriteria[pageSize]"] = str(count)
        return self

    def page(self, num: int) -> ResourceBuilder:
        """Set page number (1-based)::

        client.products().page(2).limit(25).get()
        """
        self._params["searchCriteria[currentPage]"] = str(num)
        return self

    # ------------------------------------------------------------------
    # Request body
    # ------------------------------------------------------------------

    def body(self, data: dict[str, Any]) -> ResourceBuilder:
        """Set request body (alternative to passing it to post/put)::

        client.products().body({"sku": "NEW"}).post()
        # Same as:
        client.products().post({"sku": "NEW"})
        """
        self._body = data
        return self

    # ------------------------------------------------------------------
    # Response typing
    # ------------------------------------------------------------------

    def typed(self, model_cls: type[T]) -> ResourceBuilder:
        """Set pydantic model for typed response::

        result = client.products().filter(status="1").typed(ProductSearchResult).get()
        """
        self._response_model = model_cls
        return self

    # ------------------------------------------------------------------
    # Raw query params (non-searchCriteria endpoints)
    # ------------------------------------------------------------------

    def params(self, **kwargs: Any) -> ResourceBuilder:
        """Set raw query parameters (bypasses SearchCriteria)::

        client.inventory().params(showArchived="true").get()
        """
        self._params.update(kwargs)
        return self

    def iter_pages(self, page_size: int | None = None, start_page: int = 1) -> Iterator[Any]:
        """Iterate paginated responses one page at a time."""
        builder = self._clone()
        size = page_size or int(builder._params.get("searchCriteria[pageSize]", 100))
        current_page = int(builder._params.get("searchCriteria[currentPage]", start_page))
        fetched = 0

        while True:
            page_builder = builder._clone()
            page_builder.limit(size)
            page_builder.page(current_page)
            page = page_builder.get()
            items = self._extract_items(page)

            yield page

            if not items:
                break

            fetched += len(items)
            total_count = self._extract_total_count(page)
            if total_count is not None and fetched >= total_count:
                break
            if total_count is None and len(items) < size:
                break

            current_page += 1

    async def aiter_pages(
        self,
        page_size: int | None = None,
        start_page: int = 1,
    ) -> AsyncIterator[Any]:
        """Async iterator over paginated responses one page at a time."""
        builder = self._clone()
        size = page_size or int(builder._params.get("searchCriteria[pageSize]", 100))
        current_page = int(builder._params.get("searchCriteria[currentPage]", start_page))
        fetched = 0

        while True:
            page_builder = builder._clone()
            page_builder.limit(size)
            page_builder.page(current_page)
            page = await page_builder.aget()
            items = self._extract_items(page)

            yield page

            if not items:
                break

            fetched += len(items)
            total_count = self._extract_total_count(page)
            if total_count is not None and fetched >= total_count:
                break
            if total_count is None and len(items) < size:
                break

            current_page += 1

    # ------------------------------------------------------------------
    # Sync execution
    # ------------------------------------------------------------------

    def get(self, **path_kwargs: str | int) -> Any:
        """Execute GET. Fills remaining path params from kwargs."""
        if path_kwargs:
            return self(**path_kwargs).get()
        return self._parse(self._client.request("GET", self._path, params=self._params))

    def post(self, data: dict[str, Any] | None = None, **path_kwargs: str | int) -> Any:
        """Execute POST. Body as first arg or via ``.body()``."""
        if path_kwargs:
            return self(**path_kwargs).post(data)
        body = data if data is not None else self._body
        return self._parse(
            self._client.request("POST", self._path, params=self._params, json_data=body)
        )

    def put(self, data: dict[str, Any] | None = None, **path_kwargs: str | int) -> Any:
        """Execute PUT."""
        if path_kwargs:
            return self(**path_kwargs).put(data)
        body = data if data is not None else self._body
        return self._parse(
            self._client.request("PUT", self._path, params=self._params, json_data=body)
        )

    def patch(self, data: dict[str, Any] | None = None, **path_kwargs: str | int) -> Any:
        """Execute PATCH."""
        if path_kwargs:
            return self(**path_kwargs).patch(data)
        body = data if data is not None else self._body
        return self._parse(
            self._client.request("PATCH", self._path, params=self._params, json_data=body)
        )

    def delete(self, **path_kwargs: str | int) -> Any:
        """Execute DELETE."""
        if path_kwargs:
            return self(**path_kwargs).delete()
        return self._parse(self._client.request("DELETE", self._path, params=self._params))

    # ------------------------------------------------------------------
    # Async execution
    # ------------------------------------------------------------------

    async def aget(self, **path_kwargs: str | int) -> Any:
        """Async GET."""
        if path_kwargs:
            return await self(**path_kwargs).aget()
        return self._parse(await self._client.async_request("GET", self._path, params=self._params))

    async def apost(self, data: dict[str, Any] | None = None, **path_kwargs: str | int) -> Any:
        """Async POST."""
        if path_kwargs:
            return await self(**path_kwargs).apost(data)
        body = data if data is not None else self._body
        return self._parse(
            await self._client.async_request(
                "POST", self._path, params=self._params, json_data=body
            )
        )

    async def aput(self, data: dict[str, Any] | None = None, **path_kwargs: str | int) -> Any:
        """Async PUT."""
        if path_kwargs:
            return await self(**path_kwargs).aput(data)
        body = data if data is not None else self._body
        return self._parse(
            await self._client.async_request("PUT", self._path, params=self._params, json_data=body)
        )

    async def apatch(self, data: dict[str, Any] | None = None, **path_kwargs: str | int) -> Any:
        """Async PATCH."""
        if path_kwargs:
            return await self(**path_kwargs).apatch(data)
        body = data if data is not None else self._body
        return self._parse(
            await self._client.async_request(
                "PATCH", self._path, params=self._params, json_data=body
            )
        )

    async def adelete(self, **path_kwargs: str | int) -> Any:
        """Async DELETE."""
        if path_kwargs:
            return await self(**path_kwargs).adelete()
        return self._parse(
            await self._client.async_request("DELETE", self._path, params=self._params)
        )

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _add_filter(self, field: str, value: str, condition: str) -> None:
        """Add a single filter to searchCriteria params."""
        idx = self._next_filter_index()
        prefix = f"searchCriteria[filterGroups][0][filters][{idx}]"
        self._params[f"{prefix}[field]"] = field
        self._params[f"{prefix}[value]"] = str(value)
        self._params[f"{prefix}[conditionType]"] = condition

    def _next_filter_index(self) -> int:
        idx = 0
        while f"searchCriteria[filterGroups][0][filters][{idx}][field]" in self._params:
            idx += 1
        return idx

    @staticmethod
    def _detect_condition(value: Any) -> str:
        """Auto-detect condition type from value pattern."""
        s = str(value)
        if "%" in s or "*" in s:
            return "like"
        return "eq"

    def _parse(self, response: Any) -> Any:
        """Parse response, applying typed model if set."""
        raw = response if isinstance(response, dict) else self._client._parse_json(response)
        if self._response_model is not None:
            return self._response_model.model_validate(raw)
        return raw

    @staticmethod
    def _extract_items(page: Any) -> list[Any]:
        """Extract page items from dict or typed search result."""
        if isinstance(page, dict):
            items = page.get("items", [])
            return items if isinstance(items, list) else []

        items = getattr(page, "items", [])
        return items if isinstance(items, list) else []

    @staticmethod
    def _extract_total_count(page: Any) -> int | None:
        """Extract total count from dict or typed search result."""
        if isinstance(page, dict):
            total_count = page.get("total_count")
            return int(total_count) if total_count is not None else None

        total_count = getattr(page, "total_count", None)
        return int(total_count) if total_count is not None else None

    def __repr__(self) -> str:
        filters = sum(
            1
            for k in self._params
            if k.startswith("searchCriteria[filterGroups]") and k.endswith("[field]")
        )
        parts = [f"ResourceBuilder({self._path!r}"]
        if filters:
            parts.append(f"filters={filters}")
        if self._params.get("searchCriteria[pageSize]"):
            parts.append(f"limit={self._params['searchCriteria[pageSize]']}")
        if self._body:
            parts.append("body=set")
        return ", ".join(parts) + ")"
