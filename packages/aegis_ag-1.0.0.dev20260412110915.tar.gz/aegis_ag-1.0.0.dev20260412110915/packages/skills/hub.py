"""Searchable skill-package discovery for local Aegis installs."""

from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path
from typing import Any, Mapping

from .runtime import SkillDefinition, load_skill_package_definition


@dataclass(frozen=True, slots=True)
class SkillHubEntry:
    skill_id: str
    display_name: str
    summary: str
    source_id: str
    source_label: str
    skill_path: str
    entry_path: str
    provenance: str
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def reference(self) -> str:
        return f"{self.source_id}:{self.skill_id}"


@dataclass(frozen=True, slots=True)
class SkillHubSource:
    source_id: str
    label: str
    root: Path


class SkillHub:
    """Search local skill shelves and resolve installable skill packages."""

    def __init__(self, sources: tuple[SkillHubSource, ...] | None = None) -> None:
        self._sources = sources or default_skill_hub_sources()

    @property
    def sources(self) -> tuple[SkillHubSource, ...]:
        return self._sources

    def list(self) -> tuple[SkillHubEntry, ...]:
        entries: list[SkillHubEntry] = []
        for source in self._sources:
            if not source.root.exists():
                continue
            for skill_md in source.root.rglob("SKILL.md"):
                if ".git" in skill_md.parts:
                    continue
                if "__pycache__" in skill_md.parts:
                    continue
                try:
                    definition = load_skill_package_definition(skill_md)
                except Exception:
                    continue
                entries.append(_entry_from_definition(definition, source=source))
        entries.sort(key=lambda item: (item.source_label.lower(), item.display_name.lower(), item.skill_id))
        return tuple(entries)

    def search(self, query: str, *, limit: int = 12) -> tuple[SkillHubEntry, ...]:
        tokens = tuple(token for token in _normalize_query(query).split() if token)
        if not tokens:
            return self.list()[:limit]
        scored: list[tuple[int, str, SkillHubEntry]] = []
        for entry in self.list():
            haystack = " ".join(
                (
                    entry.skill_id,
                    entry.reference,
                    entry.display_name,
                    entry.summary,
                    str(entry.metadata.get("source_kind") or ""),
                )
            ).lower()
            if not all(token in haystack for token in tokens):
                continue
            score = 0
            if _normalize_query(entry.skill_id) == " ".join(tokens):
                score += 6
            if _normalize_query(entry.display_name) == " ".join(tokens):
                score += 5
            if all(token in _normalize_query(entry.display_name) for token in tokens):
                score += 3
            if all(token in _normalize_query(entry.summary) for token in tokens):
                score += 1
            scored.append((score, entry.reference, entry))
        scored.sort(key=lambda item: (-item[0], item[1]))
        return tuple(item[2] for item in scored[:limit])

    def resolve(self, reference: str) -> SkillHubEntry | None:
        candidate = reference.strip()
        if not candidate:
            return None
        path_candidate = Path(candidate).expanduser()
        if path_candidate.exists():
            definition = load_skill_package_definition(path_candidate)
            return _entry_from_definition(
                definition,
                source=SkillHubSource(
                    source_id="path",
                    label="Path",
                    root=path_candidate.resolve().parent if path_candidate.is_file() else path_candidate.resolve(),
                ),
            )
        lowered = candidate.lower()
        for entry in self.list():
            if lowered in {
                entry.reference.lower(),
                entry.skill_id.lower(),
                entry.display_name.lower(),
            }:
                return entry
        return None


def default_skill_hub_sources() -> tuple[SkillHubSource, ...]:
    configured = os.environ.get("AEGIS_SKILL_PATHS", "").strip()
    if configured:
        sources: list[SkillHubSource] = []
        for index, raw_path in enumerate(configured.split(os.pathsep)):
            path = Path(raw_path).expanduser()
            if not raw_path.strip():
                continue
            sources.append(
                SkillHubSource(
                    source_id=f"custom-{index + 1}",
                    label=path.name or f"custom-{index + 1}",
                    root=path,
                )
            )
        return tuple(sources)

    home = Path.home()
    candidates = (
        SkillHubSource("codex", "Codex", home / ".codex" / "skills"),
        SkillHubSource("agents", "Agents", home / ".agents" / "skills"),
        SkillHubSource("orchestra", "Orchestra", home / ".orchestra" / "skills"),
        SkillHubSource("skills", "Skills", home / "skills"),
        SkillHubSource("local-workbench", "Local Workbench", home / "local-workbench" / "skills"),
    )
    return tuple(source for source in candidates if source.root.exists())


def _entry_from_definition(definition: SkillDefinition, *, source: SkillHubSource) -> SkillHubEntry:
    entry_path = Path(definition.entry_path or definition.provenance or "").expanduser()
    skill_path = entry_path.parent if entry_path.name == "SKILL.md" else entry_path
    metadata = dict(definition.metadata)
    metadata.setdefault("source_kind", "skill-package")
    return SkillHubEntry(
        skill_id=definition.skill_id,
        display_name=definition.display_name,
        summary=definition.summary,
        source_id=source.source_id,
        source_label=source.label,
        skill_path=str(skill_path),
        entry_path=str(entry_path),
        provenance=definition.provenance,
        metadata=metadata,
    )


def _normalize_query(value: str) -> str:
    return " ".join(value.lower().replace("-", " ").replace("_", " ").split())
