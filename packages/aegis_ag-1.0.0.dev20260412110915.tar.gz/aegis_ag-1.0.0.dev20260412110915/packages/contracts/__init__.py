"""Shared runtime contracts for Aegis.

This package is intentionally dependency-light and side-effect-free. It defines
the stable data shapes that the kernel, modules, and surfaces can share while
developing in parallel.
"""

from .inventory import CONTRACT_SURFACES
from .runtime import (
    AgentRunState,
    AgentRunStep,
    ArtifactRecord,
    ContextBundle,
    EventEnvelope,
    ExecutionResult,
    GoalNode,
    MemoryRecord,
    PlanDraft,
    PlanStep,
    ProfileState,
    SessionContinuityState,
    SessionState,
)

__all__ = [
    "ArtifactRecord",
    "AgentRunState",
    "AgentRunStep",
    "CONTRACT_SURFACES",
    "ContextBundle",
    "EventEnvelope",
    "ExecutionResult",
    "GoalNode",
    "MemoryRecord",
    "PlanDraft",
    "PlanStep",
    "ProfileState",
    "SessionContinuityState",
    "SessionState",
]
