"""Built-in tool definitions and handlers.

Keeping built-ins here keeps the executable tool surface package-owned while
allowing thin app surfaces to bind only the dependencies they actually provide.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
import json
import shutil
import subprocess
from typing import Any
from urllib.parse import quote_plus, urlparse
from urllib.request import Request, urlopen

from packages.contracts.runtime import ExecutionResult
from packages.cron import CronRuntime

from .runtime import ToolDefinition, ToolInvocation, ToolRuntime, ToolSideEffectMetadata


@dataclass(frozen=True, slots=True)
class BuiltinToolDependencies:
    cwd: Path
    cron_runtime: CronRuntime | None = None
    web_user_agent: str = "Aegis/1.0 (+https://github.com/agentic-in/aegis)"


def register_builtin_tools(
    runtime: ToolRuntime,
    *,
    enabled_overrides: Mapping[str, bool],
    dependencies: BuiltinToolDependencies,
) -> None:
    for definition in builtin_tool_definitions(enabled_overrides):
        runtime.register_tool(definition, handler=_handler_for_tool(definition, dependencies=dependencies))


def builtin_tool_definitions(enabled_overrides: Mapping[str, bool]) -> tuple[ToolDefinition, ...]:
    definitions = (
        ToolDefinition(
            tool_id="tool.shell.command",
            display_name="Shell Command",
            version="1.0.0",
            description="Run a local shell command inside the current workspace when the operator explicitly asks for it.",
            schema={
                "type": "object",
                "required": ["command"],
                "properties": {"command": {"type": "string"}},
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="high",
                approval_class="strict",
                writes_state=True,
                reads_state=True,
                categories=("shell", "workspace"),
                notes="Reserved for explicit operator-directed shell execution.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.workspace.search",
            display_name="Workspace Search",
            version="1.0.0",
            description="Search the current workspace quickly for files or lines that match a query.",
            schema={
                "type": "object",
                "required": ["query"],
                "properties": {"query": {"type": "string"}},
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="low",
                approval_class="standard",
                reads_state=True,
                categories=("search", "workspace"),
                notes="Uses fast local search to surface nearby code and notes.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.web.search",
            display_name="Web Search",
            version="1.0.0",
            description="Search the public web for a query and summarize the first useful results.",
            schema={
                "type": "object",
                "required": ["query"],
                "properties": {"query": {"type": "string"}},
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                touches_network=True,
                categories=("search", "web"),
                notes="Uses a lightweight public search endpoint for fast discovery.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.web.fetch",
            display_name="Web Fetch",
            version="1.0.0",
            description="Fetch a specific URL and extract the readable text from that page.",
            schema={
                "type": "object",
                "required": ["url"],
                "properties": {"url": {"type": "string"}},
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                touches_network=True,
                categories=("fetch", "web"),
                notes="Reads a specific public URL and returns a text-first extraction.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.cron.manage",
            display_name="Cron Jobs",
            version="1.0.0",
            description="Create, list, inspect, pause, resume, remove, and run built-in scheduled jobs.",
            schema={
                "type": "object",
                "required": ["action"],
                "properties": {
                    "action": {"type": "string"},
                    "job_id": {"type": "string"},
                    "name": {"type": "string"},
                    "schedule": {"type": "string"},
                    "job_kind": {"type": "string"},
                    "message": {"type": "string"},
                    "query": {"type": "string"},
                    "prompt": {"type": "string"},
                    "profile_id": {"type": "string"},
                    "clone_id": {"type": "string"},
                },
            },
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("cron", "automation"),
                notes="Built-in recurring job management for the active Aegis surface.",
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        ToolDefinition(
            tool_id="tool.provider.test",
            display_name="Provider Test Probe",
            version="1.0.0",
            description="Run an operator-facing provider probe through the shared runtime.",
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                touches_network=True,
                touches_secrets=True,
                categories=("provider", "network"),
                notes="Used by health and born validation flows.",
            ),
            metadata={"surface": "cli", "kind": "operator"},
            execution={
                "kind": "structured_result",
                "summary_template": "Provider Test Probe remains governed by the shared runtime.",
            },
        ),
        ToolDefinition(
            tool_id="tool.goal.update",
            display_name="Goal Update",
            version="1.0.0",
            description="Apply an operator-approved goal mutation inside the durable goal graph.",
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("goal", "state"),
                notes="Used for inspectable goal edits from the operator path.",
            ),
            metadata={"surface": "cli", "kind": "operator"},
            execution={
                "kind": "structured_result",
                "summary_template": "Goal Update remains governed by the shared runtime.",
            },
        ),
        ToolDefinition(
            tool_id="tool.memory.correct",
            display_name="Memory Correction",
            version="1.0.0",
            description="Correct an existing durable memory record with lineage preserved.",
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("memory", "correction"),
                notes="Keeps durable corrections explicit and auditable.",
            ),
            metadata={"surface": "cli", "kind": "operator"},
            execution={
                "kind": "structured_result",
                "summary_template": "Memory Correction remains governed by the shared runtime.",
            },
        ),
        ToolDefinition(
            tool_id="tool.memory.delete",
            display_name="Memory Deletion",
            version="1.0.0",
            description="Delete a durable memory record through governed operator flow.",
            side_effects=ToolSideEffectMetadata(
                risk_class="high",
                approval_class="strict",
                writes_state=True,
                reads_state=True,
                categories=("memory", "deletion"),
                notes="Deletion requires explicit operator intent.",
            ),
            metadata={"surface": "cli", "kind": "operator"},
            execution={
                "kind": "structured_result",
                "summary_template": "Memory Deletion remains governed by the shared runtime.",
            },
        ),
    )
    return tuple(
        replace(definition, enabled=enabled_overrides.get(definition.tool_id, definition.enabled))
        for definition in definitions
    )


def _handler_for_tool(definition: ToolDefinition, *, dependencies: BuiltinToolDependencies):
    if definition.tool_id == "tool.shell.command":
        return lambda invocation: _run_shell_command(invocation, cwd=dependencies.cwd)
    if definition.tool_id == "tool.workspace.search":
        return lambda invocation: _run_workspace_search(invocation, cwd=dependencies.cwd)
    if definition.tool_id == "tool.web.search":
        return lambda invocation: _run_web_search(invocation, user_agent=dependencies.web_user_agent)
    if definition.tool_id == "tool.web.fetch":
        return lambda invocation: _run_web_fetch(invocation, user_agent=dependencies.web_user_agent)
    if definition.tool_id == "tool.cron.manage":
        return lambda invocation: _run_cron_action(invocation, runtime=dependencies.cron_runtime)
    return None


def _run_shell_command(invocation: ToolInvocation, *, cwd: Path) -> Mapping[str, Any]:
    command = str(invocation.arguments.get("command") or "").strip()
    if not command:
        raise ValueError("tool.shell.command requires a 'command' argument")
    completed = subprocess.run(
        command,
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=20,
    )
    body = "\n".join(part for part in (completed.stdout.strip(), completed.stderr.strip()) if part).strip()
    summary = _truncate(body) or f"command exited with status {completed.returncode}"
    if completed.returncode != 0:
        raise RuntimeError(summary)
    return {
        "execution_id": invocation.invocation_id,
        "summary": summary,
        "outcome": "success",
        "side_effects": ("shell", "workspace"),
    }


def _run_workspace_search(invocation: ToolInvocation, *, cwd: Path) -> Mapping[str, Any]:
    query = str(invocation.arguments.get("query") or "").strip()
    if not query:
        raise ValueError("tool.workspace.search requires a 'query' argument")
    rg_path = shutil.which("rg")
    if rg_path is None:
        raise RuntimeError("workspace search requires rg to be installed")
    completed = subprocess.run(
        [rg_path, "-n", "--no-heading", "--smart-case", "--max-count", "12", query, str(cwd)],
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=20,
    )
    body = completed.stdout.strip() or completed.stderr.strip()
    if completed.returncode not in {0, 1}:
        raise RuntimeError(body or f"workspace search failed with status {completed.returncode}")
    summary = _truncate(body) or f"no workspace matches for query: {query}"
    return {
        "execution_id": invocation.invocation_id,
        "summary": summary,
        "outcome": "success",
        "side_effects": ("search", "workspace"),
    }


def _run_web_search(invocation: ToolInvocation, *, user_agent: str) -> Mapping[str, Any]:
    query = str(invocation.arguments.get("query") or "").strip()
    if not query:
        raise ValueError("tool.web.search requires a 'query' argument")
    request = Request(
        f"https://api.duckduckgo.com/?q={quote_plus(query)}&format=json&no_html=1&skip_disambig=1",
        headers={"User-Agent": user_agent},
    )
    with urlopen(request, timeout=20) as response:  # noqa: S310
        payload = json.loads(response.read().decode("utf-8"))
    lines: list[str] = []
    abstract = str(payload.get("AbstractText") or "").strip()
    abstract_url = str(payload.get("AbstractURL") or "").strip()
    if abstract:
        lines.append(abstract if not abstract_url else f"{abstract} ({abstract_url})")
    answer = str(payload.get("Answer") or "").strip()
    if answer and answer not in lines:
        lines.append(answer)
    related = payload.get("RelatedTopics", [])
    if isinstance(related, list):
        for item in related:
            if not isinstance(item, Mapping):
                continue
            text = str(item.get("Text") or "").strip()
            url = str(item.get("FirstURL") or "").strip()
            if text:
                lines.append(text if not url else f"{text} ({url})")
            if len(lines) >= 3:
                break
    summary = _truncate("\n".join(lines) or f"no web results for query: {query}")
    return {
        "execution_id": invocation.invocation_id,
        "summary": summary,
        "outcome": "success",
        "side_effects": ("search", "web"),
    }


def _run_web_fetch(invocation: ToolInvocation, *, user_agent: str) -> Mapping[str, Any]:
    raw_url = str(invocation.arguments.get("url") or "").strip()
    url = _normalized_url(raw_url)
    if url is None:
        raise ValueError("tool.web.fetch requires a valid 'url' argument")
    request = Request(
        url,
        headers={
            "User-Agent": user_agent,
            "Accept": "text/html,application/xhtml+xml,text/plain,application/json;q=0.9,*/*;q=0.8",
        },
    )
    with urlopen(request, timeout=20) as response:  # noqa: S310
        payload = response.read(350_000)
        content_type = response.headers.get_content_type()
        charset = response.headers.get_content_charset() or "utf-8"
        resolved_url = response.geturl()
    title, excerpt = _extract_web_text(payload, content_type=content_type, charset=charset)
    lines: list[str] = []
    if title:
        lines.append(title)
    if excerpt:
        lines.append(excerpt)
    lines.append(f"source: {resolved_url}")
    summary = _truncate("\n".join(lines), limit=1600)
    return {
        "execution_id": invocation.invocation_id,
        "summary": summary,
        "outcome": "success",
        "side_effects": ("fetch", "web"),
    }


def _run_cron_action(invocation: ToolInvocation, *, runtime: CronRuntime | None) -> ExecutionResult:
    if runtime is None:
        raise RuntimeError("cron runtime is not configured")
    action = str(invocation.arguments.get("action") or "").strip().lower()
    if not action:
        raise ValueError("tool.cron.manage requires an 'action' argument")
    if action == "list":
        jobs = runtime.list_jobs(
            profile_id=_optional_string(invocation.arguments.get("profile_id")),
            clone_id=_optional_string(invocation.arguments.get("clone_id")),
        )
        summary = "\n".join(
            f"{job.job_id} | {job.status} | {job.name} | {job.schedule_text} | {job.action_kind}"
            for job in jobs
        ) or "<empty>"
        return ExecutionResult(
            execution_id=invocation.invocation_id,
            session_id=invocation.session_id,
            outcome="success",
            summary=summary,
            side_effects=("cron", "automation"),
        )
    if action == "create":
        name = _optional_string(invocation.arguments.get("name")) or "Aegis job"
        schedule = _optional_string(invocation.arguments.get("schedule"))
        job_kind = _optional_string(invocation.arguments.get("job_kind"))
        if not schedule or not job_kind:
            raise ValueError("cron create requires 'schedule' and 'job_kind'")
        payload = {
            key: value
            for key, value in (
                ("message", _optional_string(invocation.arguments.get("message"))),
                ("query", _optional_string(invocation.arguments.get("query"))),
                ("prompt", _optional_string(invocation.arguments.get("prompt"))),
            )
            if value is not None
        }
        job = runtime.create_job(
            name=name,
            schedule_text=schedule,
            action_kind=job_kind,
            payload=payload,
            profile_id=_optional_string(invocation.arguments.get("profile_id")),
            clone_id=_optional_string(invocation.arguments.get("clone_id")),
        )
        return ExecutionResult(
            execution_id=invocation.invocation_id,
            session_id=invocation.session_id,
            outcome="success",
            summary=(
                f"created {job.job_id}\n"
                f"name: {job.name}\n"
                f"schedule: {job.schedule_text}\n"
                f"job_kind: {job.action_kind}\n"
                f"next_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}"
            ),
            side_effects=("cron", "automation"),
        )
    job_id = _optional_string(invocation.arguments.get("job_id"))
    if not job_id:
        raise ValueError(f"cron action '{action}' requires 'job_id'")
    if action == "inspect":
        job = runtime.inspect_job(job_id)
        return ExecutionResult(
            execution_id=invocation.invocation_id,
            session_id=invocation.session_id,
            outcome="success",
            summary=(
                f"{job.job_id}\n"
                f"name: {job.name}\n"
                f"status: {job.status}\n"
                f"schedule: {job.schedule_text}\n"
                f"job_kind: {job.action_kind}\n"
                f"next_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}\n"
                f"last_summary: {job.last_summary or '<none>'}"
            ),
            side_effects=("cron", "automation"),
        )
    if action == "pause":
        job = runtime.pause_job(job_id)
        summary = f"{job.job_id}\nstatus: {job.status}"
    elif action == "resume":
        job = runtime.resume_job(job_id)
        summary = f"{job.job_id}\nstatus: {job.status}\nnext_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}"
    elif action == "remove":
        job = runtime.remove_job(job_id)
        summary = f"{job.job_id}\nstatus: removed"
    else:
        raise ValueError(f"unsupported cron action: {action}")
    return ExecutionResult(
        execution_id=invocation.invocation_id,
        session_id=invocation.session_id,
        outcome="success",
        summary=summary,
        side_effects=("cron", "automation"),
    )


def _optional_string(value: Any) -> str | None:
    if value is None:
        return None
    resolved = str(value).strip()
    return resolved or None


def _truncate(value: str, *, limit: int = 1200) -> str:
    compact = value.strip()
    if len(compact) <= limit:
        return compact
    return compact[: max(0, limit - 1)].rstrip() + "…"


def _normalized_url(value: str) -> str | None:
    candidate = value.strip().strip("\"'")
    if not candidate:
        return None
    parsed = urlparse(candidate)
    if not parsed.scheme:
        candidate = f"https://{candidate}"
        parsed = urlparse(candidate)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return None
    return candidate


def _extract_web_text(payload: bytes, *, content_type: str, charset: str) -> tuple[str, str]:
    decoded = payload.decode(charset, errors="replace")
    if content_type in {"text/html", "application/xhtml+xml"} or content_type.endswith("+html"):
        parser = _HTMLTextExtractor()
        parser.feed(decoded)
        parser.close()
        return parser.title, _truncate(parser.text, limit=1400)
    return "", _truncate(_compact_text(decoded), limit=1400)


def _compact_text(value: str) -> str:
    return " ".join(unescape(value).split())


class _HTMLTextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._blocked_depth = 0
        self._in_title = False
        self._title_parts: list[str] = []
        self._text_parts: list[str] = []

    @property
    def title(self) -> str:
        return " ".join(self._title_parts).strip()

    @property
    def text(self) -> str:
        return " ".join(self._text_parts).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "noscript"}:
            self._blocked_depth += 1
            return
        if tag == "title":
            self._in_title = True

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript"} and self._blocked_depth > 0:
            self._blocked_depth -= 1
            return
        if tag == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        if self._blocked_depth > 0:
            return
        text = _compact_text(data)
        if not text:
            return
        if self._in_title:
            self._title_parts.append(text)
        else:
            self._text_parts.append(text)
