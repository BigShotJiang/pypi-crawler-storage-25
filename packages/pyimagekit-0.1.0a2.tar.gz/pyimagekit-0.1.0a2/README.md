# PyImageKit

A Python library providing a unified interface for handling images across multiple formats (`bytes`, OpenCV `cv2`, Pillow `Image`) and performing common image processing tasks.

## Installation

```bash
pip install pyimagekit
```

To include OCR support for document uprighting, install with the optional dependency:

```bash
pip install "pyimagekit[pytesseract]"
```

## Quick Start

`pyimagekit` centers around the `SmartImage` class, which allows you to seamlessly load, transform, and export images. It implements a fluent interface so operations can be chained.

```python
from pyimagekit import SmartImage

# 1. Load an image
with open("document.jpg", "rb") as f:
    img = SmartImage.from_bytes(f.read())

# Alternatively:
# img = SmartImage.from_cv2(cv2_image)
# img = SmartImage.from_pillow(pil_image)

# 2. Process the image
processed_img = (
    img.resize(width=800)
       .rotate(90)
       .ensure_document_portrait()
)

# 3. Export the processed image
jpeg_bytes = processed_img.to_bytes(format="JPEG", quality=85)
base64_str = processed_img.to_base64(format="PNG")
cv2_mat = processed_img.to_cv2()
pillow_img = processed_img.to_pillow()
```

## Features

The `SmartImage` class currently supports the following operations:

- **Loading:** `from_bytes`, `from_cv2`, `from_pillow`
- **Exporting:** `to_cv2`, `to_pillow`, `to_bytes`, `to_base64`
- **Transformations:** `resize`, `crop`, `rotate`, `sharpen_v1`, `sharpen_v2`, `adjust_quality`, `apply` (for custom functions)
- **Document Processing:** `unwarp_document`, `ensure_document_upright`, `ensure_document_portrait`, `ensure_document_landscape`

## License

MIT License