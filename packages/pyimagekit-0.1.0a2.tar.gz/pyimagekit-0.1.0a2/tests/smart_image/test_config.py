import pytest
from pyimagekit import (
    SmartImage,
    ImageTooLarge,
)

with open("tests/images/1.jpg", "rb") as f:
    image = f.read()


def test_config_params_max_size_exceed():

    with pytest.raises(ImageTooLarge):
        SmartImage.validate_size(image_bytes=image, max_size_mb=0.01)


def test_config_params_max_size_inlimit():
    assert SmartImage.validate_size(image_bytes=image, max_size_mb=2)