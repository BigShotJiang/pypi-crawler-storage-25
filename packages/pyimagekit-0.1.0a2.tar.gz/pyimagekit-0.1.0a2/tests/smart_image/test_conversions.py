import numpy as np
from PIL import Image
from pyimagekit import SmartImage

from sample import service, BYTES_IMAGE


def test_conversion_on_demand(service: SmartImage):
    # Verify cv2 and Pillow objects exist
    cv2_img = service.to_cv2()
    pil_img = service.to_pillow()

    assert isinstance(cv2_img, np.ndarray)
    assert isinstance(pil_img, Image.Image)
    assert isinstance(service.to_base64(), str)
    assert isinstance(service.to_bytes(), bytes)

    # cv2 -> pillow -> cv2 should preserve image data (within compression/rounding tolerance)
    pil_from_cv2 = SmartImage.cv2_to_pillow(cv2_img)
    cv2_from_pil = SmartImage.pillow_to_cv2(pil_from_cv2)
    np.testing.assert_allclose(cv2_img, cv2_from_pil, atol=10, rtol=0)

    # bytes -> pillow should produce a visually similar image
    pil_from_bytes = SmartImage.bytes_to_pillow(BYTES_IMAGE)
    np.testing.assert_allclose(np.array(pil_img), np.array(pil_from_bytes), atol=10, rtol=0)

    # pillow -> bytes should round-trip back to an image similar to the original bytes.
    # Allow for some compression/rounding delta.
    bytes_from_pillow = SmartImage.pillow_to_bytes(pil_img)
    cv2_from_bytes = SmartImage.bytes_to_cv2(bytes_from_pillow)
    diff = np.abs(cv2_img.astype(np.int16) - cv2_from_bytes.astype(np.int16))
    assert diff.mean() < 1
    assert diff.max() <= 16
