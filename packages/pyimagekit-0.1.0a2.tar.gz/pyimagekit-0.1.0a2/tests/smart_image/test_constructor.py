import pytest
import numpy as np
from pyimagekit import SmartImage, ImageEmpty, InvalidImage

from sample import INVALID_IMAGE, EMPTY_IMAGE, VALID_IMAGE, CV2_IMAGE, PILLOW_IMAGE


def test_invalid_image():
    with pytest.raises(InvalidImage):
        SmartImage.from_bytes(image_bytes=INVALID_IMAGE)


def test_empty_image():
    with pytest.raises(ImageEmpty):
        SmartImage.from_bytes(image_bytes=EMPTY_IMAGE)


def test_valid_image_from_bytes():
    # should construct successfully from raw bytes
    img = SmartImage.from_bytes(image_bytes=VALID_IMAGE)
    assert isinstance(img, SmartImage)


def test_from_cv2_and_pillow_constructors(tmp_path):
    smart1 = SmartImage.from_cv2(CV2_IMAGE)
    assert isinstance(smart1, SmartImage)

    smart2 = SmartImage.from_pillow(PILLOW_IMAGE)
    assert isinstance(smart2, SmartImage)

    # ensure round-trip conversions produce usable bytes
    assert smart1.to_bytes() and smart2.to_bytes()


def test_cv2_and_pillow_empty_raises():

    # empty cv2 array
    with pytest.raises(ImageEmpty):
        SmartImage.from_cv2(np.array([]))

    # None pillow
    with pytest.raises(ImageEmpty):
        SmartImage.from_pillow(None)
