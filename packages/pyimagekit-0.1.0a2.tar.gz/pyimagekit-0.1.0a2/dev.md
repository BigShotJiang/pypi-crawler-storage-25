**To local install package while developing**
(Install package)
uv pip install .[dev] (Locally and also install the development dependencies)
uv pip install -e .[dev] (In editable mode and also install the development dependencies)
uv pip install -e .[dev,pytesseract] (In editable mode and also install the development and optional dependencies)

**How to publish package using uv**

[building-your-package](https://docs.astral.sh/uv/guides/package/#building-your-package)

[packaging-projects](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

**Package stats**
[PyPiStats](https://pypistats.org)

**test**
uv run --python 3.9 pytest
uv run --python 3.10 pytest
... so on













## Development & Release Workflow

### 1. Testing (TestPyPI)
Use this when you want to verify the package builds correctly and can be installed via pip.

* **Version:** Update `version` in `pyproject.toml` to an alpha/beta (e.g., `0.1.0a1`).
* **Branch:** `test`
* **Commands:**
    ```bash
    # 1. Commit your changes
    git add .
    git commit -m "feat: <description of change>"

    # 2. Create the test tag
    git tag v0.0.1a1-test

    # 3. Push the branch first (if code already pushed then no need)
    git push origin test

    # 4. Push the tag to GitHub
    git push origin v0.0.1a1-test
    ```
    *Result: Automatically builds and publishes to [TestPyPI](https://test.pypi.org/).*

---

### 2. Official Release (PyPI)
Use this only when the code is stable and ready for public use.

* **Version:** Update `version` in `pyproject.toml` to a stable version (e.g., `0.1.0`).
* **Branch:** `main` (Merge from `test` first).
* **Commands:**
    ```bash
    # 1. Merge changes into main
    git checkout main
    git merge test
    
    # 2. Tag the version (Must match pyproject.toml)
    git tag v0.1.0
    
    # 3. Push code and tags
    git push origin main --tags
    ```
    *Result: Automatically builds and publishes to [PyPI](https://pypi.org/).*

---

### 3. Commit Message Standards
We follow **Conventional Commits** to keep the history clean:

| Prefix      | Use Case                    | Example                                  |
| :---------- | :-------------------------- | :--------------------------------------- |
| `feat:`     | A new feature               | `feat: add opencv-based blurring`        |
| `fix:`      | A bug fix                   | `fix: resolve numpy overflow in scaling` |
| `docs:`     | Documentation changes       | `docs: update dev.md with release flow`  |
| `chore:`    | Maintenance/Version bump    | `chore: bump version to 0.1.0`           |
| `refactor:` | Code cleanup (no new logic) | `refactor: simplify internal loop`       |

---

### Local Sanity Check
Always run a local build before pushing to ensure `hatchling` (the build backend) is happy:
```bash
uv build
```
*Verify that the `.whl` and `.tar.gz` files appear in the `dist/` folder.*