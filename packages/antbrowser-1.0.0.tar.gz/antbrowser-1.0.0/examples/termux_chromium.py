"""Example for Android / Termux using a local Chromium binary."""

from antbrowser import AntBrowser


def main() -> None:
    workspace = "/data/data/com.termux/files/home/.ant-browser-workspace"
    with AntBrowser(workspace=workspace) as browser:
        core = browser.ensure_termux_chromium_core()
        print("Registered core:", core)
        print("Runtime info:", browser.runtime.info())


if __name__ == "__main__":
    main()
