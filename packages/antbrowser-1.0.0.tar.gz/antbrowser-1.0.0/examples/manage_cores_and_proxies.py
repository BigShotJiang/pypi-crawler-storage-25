"""Example showing browser core and proxy catalog management."""

from antbrowser import AntBrowser


def main() -> None:
    with AntBrowser(workspace="C:/tmp/ant-workspace") as browser:
        print("Core candidates:", browser.discover_system_cores())

        proxy = browser.save_proxy(
            {
                "proxyName": "Local Proxy",
                "proxyConfig": "http://127.0.0.1:7890",
                "groupName": "local",
            }
        )
        print("Saved proxy:", proxy)
        print("Proxy groups:", browser.proxies.groups())
        print("Proxy validate:", browser.proxies.validate(proxy_config=proxy["proxyConfig"]))


if __name__ == "__main__":
    main()
