"""Higher-level builder example for random environments and anti-detect settings."""

from antbrowser import AntBrowser


def main() -> None:
    with AntBrowser(workspace="C:/tmp/ant-workspace") as browser:
        result = (
            browser.new_profile("buyer-random")
            .random_environment(name_prefix="Buyer Random")
            .hardware(
                hardware_concurrency=8,
                device_memory=16,
                webgl_vendor="Intel",
                webgl_renderer="Intel Iris Xe",
            )
            .anti_detect("strict")
            .create(auto_launch=True, run_mode="headless")
        )

        print(result)


if __name__ == "__main__":
    main()
