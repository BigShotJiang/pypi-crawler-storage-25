"""Basic Ant Browser Python SDK workflow example."""

from antbrowser import AntBrowser


def main() -> None:
    with AntBrowser(workspace="C:/tmp/ant-workspace") as browser:
        print("Runtime:", browser.runtime.info())
        print("Discovered cores:", browser.discover_system_cores())


if __name__ == "__main__":
    main()
