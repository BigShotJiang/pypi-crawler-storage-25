"""Setuptools hook for platform-specific daemon-embedded wheels."""

from __future__ import annotations

import os

from setuptools import setup

try:
    from wheel.bdist_wheel import bdist_wheel as _bdist_wheel
except Exception:  # pragma: no cover - build-time fallback
    _bdist_wheel = None


def _embed_daemon_enabled() -> bool:
    """Return whether the current wheel build should be marked as platform-specific."""

    return os.environ.get("ANTBROWSER_EMBED_DAEMON", "").strip() == "1"


if _bdist_wheel is not None:

    class bdist_wheel(_bdist_wheel):
        """Force platform wheel tags when a daemon binary is bundled into the package."""

        def finalize_options(self) -> None:
            super().finalize_options()
            if _embed_daemon_enabled():
                self.root_is_pure = False
                plat_name = os.environ.get("ANTBROWSER_PLAT_NAME", "").strip()
                if plat_name:
                    self.plat_name_supplied = True
                    self.plat_name = plat_name

        def get_tag(self):  # type: ignore[override]
            if _embed_daemon_enabled():
                _, _, plat = super().get_tag()
                return "py3", "none", plat
            return super().get_tag()


    setup(cmdclass={"bdist_wheel": bdist_wheel})
else:  # pragma: no cover - build-time fallback
    setup()
