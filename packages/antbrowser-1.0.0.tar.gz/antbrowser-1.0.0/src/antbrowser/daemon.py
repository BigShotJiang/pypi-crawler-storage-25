"""Daemon discovery and lifecycle helpers for the Ant Browser SDK."""

from __future__ import annotations

import json
import os
import pathlib
import shutil
import signal
import stat
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Optional


DEFAULT_API_HEADER = "X-Ant-Api-Key"


@dataclass
class DaemonMetadata:
    """Structured view of workspace/runtime/daemon.json."""

    pid: int
    base_url: str
    api_key: str
    api_header: str
    version: str
    workspace: str
    started_at: str
    host_mode: str

    @classmethod
    def from_payload(cls, payload: dict) -> "DaemonMetadata":
        """Build metadata from the daemon's JSON payload."""

        return cls(
            pid=int(payload.get("pid", 0) or 0),
            base_url=str(payload.get("baseUrl", "") or "").strip(),
            api_key=str(payload.get("apiKey", "") or "").strip(),
            api_header=str(payload.get("apiHeader", DEFAULT_API_HEADER) or DEFAULT_API_HEADER).strip(),
            version=str(payload.get("version", "") or "").strip(),
            workspace=str(payload.get("workspace", "") or "").strip(),
            started_at=str(payload.get("startedAt", "") or "").strip(),
            host_mode=str(payload.get("hostMode", "") or "").strip(),
        )


class DaemonManager:
    """Find, validate, or launch a local Ant Browser daemon for one workspace."""

    def __init__(
        self,
        workspace: Optional[str] = None,
        daemon_path: Optional[str] = None,
        ready_timeout: float = 30.0,
        auto_start: bool = True,
    ) -> None:
        self.workspace = self._resolve_workspace(workspace)
        self.daemon_path = daemon_path
        self.ready_timeout = ready_timeout
        self.auto_start = auto_start

    def ensure_metadata(self) -> DaemonMetadata:
        """Return healthy daemon metadata, launching a daemon when necessary."""

        metadata = self._load_metadata()
        if metadata and self._healthcheck(metadata):
            return metadata
        if not self.auto_start:
            raise RuntimeError("No healthy ant-browser-daemon is running for this workspace")
        return self._start_daemon()

    def shutdown(self, metadata: Optional[DaemonMetadata] = None, timeout: float = 10.0) -> None:
        """Request daemon shutdown through the runtime control endpoint."""

        active = metadata or self._load_metadata()
        if active is None:
            return
        request = urllib.request.Request(
            url=self._join_url(active.base_url, "/api/runtime/shutdown"),
            method="POST",
            headers={
                "Accept": "application/json",
                active.api_header: active.api_key,
            },
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            if response.status >= 400:
                raise RuntimeError(f"Daemon shutdown failed with HTTP {response.status}")

    def _start_daemon(self) -> DaemonMetadata:
        """Spawn a daemon process and wait for its ready metadata."""

        ready_fd, ready_path = tempfile.mkstemp(prefix="ant-browser-ready-", suffix=".json")
        os.close(ready_fd)
        ready_file = pathlib.Path(ready_path)
        existing_metadata = self._load_metadata()
        if existing_metadata and not self._healthcheck(existing_metadata):
            self._cleanup_unhealthy_daemon(existing_metadata)
        try:
            command, command_cwd = self._discover_daemon_command()
            command = command + [
                "--workspace",
                self.workspace,
                "--port",
                "0",
                "--api-key",
                "auto",
                "--ready-json",
                str(ready_file),
            ]
            creationflags = 0
            if os.name == "nt":
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            process = subprocess.Popen(
                command,
                cwd=command_cwd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
                creationflags=creationflags,
            )
            deadline = time.time() + self.ready_timeout
            while time.time() < deadline:
                if process.poll() is not None:
                    raise RuntimeError(self._daemon_start_failure(process))
                metadata = self._load_metadata(ready_file)
                if metadata and self._healthcheck(metadata):
                    return metadata
                metadata = self._load_metadata()
                if metadata and self._healthcheck(metadata):
                    return metadata
                time.sleep(0.2)
            raise RuntimeError(self._daemon_timeout_message(process))
        finally:
            if ready_file.exists():
                ready_file.unlink()

    def _discover_daemon_command(self) -> tuple[list[str], Optional[str]]:
        """Resolve the daemon launch command from env, package-local files, PATH, or repo source."""

        if self.daemon_path:
            return [self.daemon_path], None

        env_path = os.environ.get("ANT_BROWSER_DAEMON_BIN", "").strip()
        if env_path:
            return [env_path], None

        suffix = ".exe" if os.name == "nt" else ""
        package_root = pathlib.Path(__file__).resolve().parent
        local_candidate = package_root / "bin" / f"ant-browser-daemon{suffix}"
        if local_candidate.exists():
            return [self._prepare_packaged_daemon_binary(local_candidate)], None

        path_candidate = shutil.which(f"ant-browser-daemon{suffix}")
        if path_candidate:
            return [path_candidate], None

        path_candidate = shutil.which("ant-browser-daemon")
        if path_candidate:
            return [path_candidate], None

        for candidate_root in [package_root] + list(package_root.parents):
            if (candidate_root / "go.mod").exists() and (candidate_root / "cmd" / "ant-browser-daemon").exists():
                go_binary = shutil.which("go")
                if go_binary:
                    return [go_binary, "run", "./cmd/ant-browser-daemon"], str(candidate_root)

        raise RuntimeError(
            "Unable to find ant-browser-daemon. Set ANT_BROWSER_DAEMON_BIN, install the daemon binary on PATH, "
            "or run the SDK from the source repository with Go installed."
        )

    def _prepare_packaged_daemon_binary(self, source_path: pathlib.Path) -> str:
        """Materialize a wheel-bundled daemon into the workspace so POSIX installs stay executable."""

        if os.name == "nt":
            return str(source_path)

        return self._materialize_packaged_daemon_binary(source_path)

    def _materialize_packaged_daemon_binary(self, source_path: pathlib.Path) -> str:
        """Copy a packaged daemon into the workspace runtime directory and restore execute bits."""

        runtime_bin_dir = pathlib.Path(self.workspace) / "runtime" / "bin"
        runtime_bin_dir.mkdir(parents=True, exist_ok=True)
        target_path = runtime_bin_dir / source_path.name

        if self._needs_binary_refresh(source_path, target_path):
            shutil.copy2(source_path, target_path)

        current_mode = target_path.stat().st_mode
        target_path.chmod(current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        return str(target_path)

    @staticmethod
    def _needs_binary_refresh(source_path: pathlib.Path, target_path: pathlib.Path) -> bool:
        """Decide whether the workspace copy should be refreshed from the packaged daemon."""

        if not target_path.exists():
            return True

        source_stat = source_path.stat()
        target_stat = target_path.stat()
        return (
            int(source_stat.st_size) != int(target_stat.st_size)
            or int(source_stat.st_mtime) > int(target_stat.st_mtime)
        )

    def _load_metadata(self, path: Optional[pathlib.Path] = None) -> Optional[DaemonMetadata]:
        """Read daemon metadata from an explicit path or the workspace runtime file."""

        metadata_path = path or pathlib.Path(self.workspace) / "runtime" / "daemon.json"
        if not metadata_path.exists():
            return None
        text = metadata_path.read_text(encoding="utf-8").strip()
        if not text:
            return None
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            return None
        return DaemonMetadata.from_payload(payload)

    def _cleanup_unhealthy_daemon(self, metadata: DaemonMetadata) -> None:
        """Try to stop a same-workspace unhealthy daemon before starting a replacement process."""

        if metadata.pid <= 0 or not self._process_exists(metadata.pid):
            return

        if self._request_shutdown(metadata, timeout=2.0) and self._wait_for_process_exit(metadata.pid, timeout=5.0):
            return

        if not self._process_looks_like_ant_browser_daemon(metadata.pid):
            return

        self._terminate_process(metadata.pid)
        self._wait_for_process_exit(metadata.pid, timeout=5.0)

    def _healthcheck(self, metadata: DaemonMetadata) -> bool:
        """Probe `/api/health` and `/api/runtime/info` to make sure metadata is current."""

        if not metadata.base_url:
            return False
        health_url = self._join_url(metadata.base_url, "/api/health")
        info_url = self._join_url(metadata.base_url, "/api/runtime/info")
        headers = {
            "Accept": "application/json",
            metadata.api_header: metadata.api_key,
        }
        try:
            self._request_json(health_url, headers=headers)
            runtime_info = self._request_json(info_url, headers=headers)
        except (OSError, urllib.error.URLError, urllib.error.HTTPError, ValueError):
            return False
        runtime_workspace = str(runtime_info.get("workspace", "") or "").strip()
        return runtime_workspace in ("", metadata.workspace)

    def _request_shutdown(self, metadata: DaemonMetadata, timeout: float) -> bool:
        """Best-effort runtime shutdown request used before falling back to process termination."""

        if not metadata.base_url or not metadata.api_key:
            return False
        request = urllib.request.Request(
            url=self._join_url(metadata.base_url, "/api/runtime/shutdown"),
            method="POST",
            headers={
                "Accept": "application/json",
                metadata.api_header: metadata.api_key,
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return response.status < 400
        except (OSError, urllib.error.URLError, urllib.error.HTTPError):
            return False

    def _process_exists(self, pid: int) -> bool:
        """Return whether a PID still exists from the current user's point of view."""

        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
        except OSError:
            return False
        return True

    def _wait_for_process_exit(self, pid: int, timeout: float) -> bool:
        """Wait until a process disappears so restart logic does not race the old daemon."""

        deadline = time.time() + timeout
        while time.time() < deadline:
            if not self._process_exists(pid):
                return True
            time.sleep(0.2)
        return not self._process_exists(pid)

    def _terminate_process(self, pid: int) -> None:
        """Terminate a verified daemon process using the strongest safe method available."""

        if pid <= 0:
            return
        try:
            os.kill(pid, signal.SIGTERM)
            return
        except OSError:
            pass

        if os.name == "nt":
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(pid), "/T", "/F"],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            except OSError:
                return
            return

        sigkill = getattr(signal, "SIGKILL", None)
        if sigkill is None:
            return
        try:
            os.kill(pid, sigkill)
        except OSError:
            return

    def _process_looks_like_ant_browser_daemon(self, pid: int) -> bool:
        """Avoid killing unrelated reused PIDs by matching the live command line when possible."""

        if pid <= 0:
            return False

        if os.name == "nt":
            try:
                output = subprocess.check_output(
                    ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                    text=True,
                    stderr=subprocess.DEVNULL,
                )
            except (OSError, subprocess.SubprocessError):
                return False
            text = output.lower()
            return "ant-browser-daemon" in text

        cmdline_path = pathlib.Path("/proc") / str(pid) / "cmdline"
        if not cmdline_path.exists():
            return False
        try:
            raw = cmdline_path.read_bytes()
        except OSError:
            return False
        text = raw.replace(b"\x00", b" ").decode("utf-8", errors="ignore").lower()
        return "ant-browser-daemon" in text or "cmd/ant-browser-daemon" in text

    @staticmethod
    def _daemon_start_failure(process: subprocess.Popen) -> str:
        """Turn early child-process exits into a useful startup error instead of a generic timeout."""

        stderr_output = ""
        if process.stderr is not None:
            try:
                stderr_output = process.stderr.read().strip()
            except OSError:
                stderr_output = ""

        message = f"ant-browser-daemon exited before ready (exit_code={process.returncode})"
        if stderr_output:
            message += f": {stderr_output}"
        return message

    def _daemon_timeout_message(self, process: subprocess.Popen) -> str:
        """Describe timeout failures with a hint about existing daemons and workspace reuse."""

        if process.poll() is not None:
            return self._daemon_start_failure(process)
        return (
            "Timed out waiting for ant-browser-daemon to become ready. "
            "A previous daemon may still be holding the workspace or launch port."
        )

    @staticmethod
    def _resolve_workspace(workspace: Optional[str]) -> str:
        """Normalize the SDK workspace path."""

        value = (workspace or "").strip()
        if not value:
            value = os.path.join(os.getcwd(), ".antbrowser-workspace")
        return os.path.abspath(value)

    @staticmethod
    def _join_url(base_url: str, path: str) -> str:
        """Build a stable absolute URL for daemon control endpoints."""

        return base_url.rstrip("/") + "/" + path.lstrip("/")

    @staticmethod
    def _request_json(url: str, headers: dict) -> dict:
        """Execute a small JSON GET request without adding a dependency on requests."""

        request = urllib.request.Request(url=url, method="GET", headers=headers)
        with urllib.request.urlopen(request, timeout=5.0) as response:
            payload = json.loads(response.read().decode("utf-8") or "{}")
            if isinstance(payload, dict) and payload.get("ok", True) is False:
                raise ValueError(str(payload.get("error", "daemon returned ok=false")))
            return payload
