"""Higher-level builders for fingerprint, stealth, and profile workflows."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, Iterable, Optional, Union

if TYPE_CHECKING:
    from .client import AntBrowser


_FINGERPRINT_PREFIXES = {
    "seed": "--fingerprint",
    "brand": "--fingerprint-brand",
    "platform": "--fingerprint-platform",
    "language": "--lang",
    "timezone": "--timezone",
    "resolution": "--window-size",
    "color_depth": "--fingerprint-color-depth",
    "hardware_concurrency": "--fingerprint-hardware-concurrency",
    "device_memory": "--fingerprint-device-memory",
    "canvas_noise": "--fingerprint-canvas-noise",
    "webgl_vendor": "--fingerprint-webgl-vendor",
    "webgl_renderer": "--fingerprint-webgl-renderer",
    "audio_noise": "--fingerprint-audio-noise",
    "fonts": "--fingerprint-fonts",
    "webrtc_policy": "--webrtc-ip-handling-policy",
    "do_not_track": "--fingerprint-do-not-track",
    "media_devices": "--fingerprint-media-devices",
    "touch_points": "--fingerprint-touch-points",
}


def _normalize_bool(value: Optional[bool]) -> Optional[str]:
    """Convert Python booleans into daemon-friendly lowercase strings."""

    if value is None:
        return None
    return "true" if value else "false"


def _normalize_string_list(values: Iterable[str]) -> list[str]:
    """Drop empty strings while preserving order."""

    output: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if text:
            output.append(text)
    return output


def _clone_dict(value: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Return a shallow copy for mutation-safe builder updates."""

    return dict(value or {})


@dataclass
class FingerprintBuilder:
    """Build or override daemon fingerprint args with Python-friendly setters."""

    values: Dict[str, Any] = field(default_factory=dict)
    extra_args: list[str] = field(default_factory=list)

    def seed(self, value: str) -> "FingerprintBuilder":
        self.values["seed"] = str(value).strip()
        return self

    def brand(self, value: str) -> "FingerprintBuilder":
        self.values["brand"] = str(value).strip()
        return self

    def platform(self, value: str) -> "FingerprintBuilder":
        self.values["platform"] = str(value).strip()
        return self

    def locale(self, language: str, timezone: Optional[str] = None) -> "FingerprintBuilder":
        self.values["language"] = str(language).strip()
        if timezone is not None:
            self.values["timezone"] = str(timezone).strip()
        return self

    def resolution(self, width: int, height: int) -> "FingerprintBuilder":
        self.values["resolution"] = f"{int(width)},{int(height)}"
        return self

    def color_depth(self, value: int) -> "FingerprintBuilder":
        self.values["color_depth"] = str(int(value))
        return self

    def hardware(
        self,
        *,
        hardware_concurrency: Optional[Union[int, str]] = None,
        device_memory: Optional[Union[int, str]] = None,
        webgl_vendor: Optional[str] = None,
        webgl_renderer: Optional[str] = None,
        media_devices: Optional[str] = None,
        touch_points: Optional[Union[int, str]] = None,
    ) -> "FingerprintBuilder":
        if hardware_concurrency is not None:
            self.values["hardware_concurrency"] = str(hardware_concurrency).strip()
        if device_memory is not None:
            self.values["device_memory"] = str(device_memory).strip()
        if webgl_vendor is not None:
            self.values["webgl_vendor"] = str(webgl_vendor).strip()
        if webgl_renderer is not None:
            self.values["webgl_renderer"] = str(webgl_renderer).strip()
        if media_devices is not None:
            self.values["media_devices"] = str(media_devices).strip()
        if touch_points is not None:
            self.values["touch_points"] = str(touch_points).strip()
        return self

    def noise(
        self,
        *,
        canvas_noise: Optional[bool] = None,
        audio_noise: Optional[bool] = None,
        do_not_track: Optional[bool] = None,
    ) -> "FingerprintBuilder":
        if canvas_noise is not None:
            self.values["canvas_noise"] = _normalize_bool(canvas_noise)
        if audio_noise is not None:
            self.values["audio_noise"] = _normalize_bool(audio_noise)
        if do_not_track is not None:
            self.values["do_not_track"] = _normalize_bool(do_not_track)
        return self

    def fonts(self, value: str) -> "FingerprintBuilder":
        self.values["fonts"] = str(value).strip()
        return self

    def webrtc_policy(self, value: str) -> "FingerprintBuilder":
        self.values["webrtc_policy"] = str(value).strip()
        return self

    def extra(self, *args: str) -> "FingerprintBuilder":
        self.extra_args.extend(_normalize_string_list(args))
        return self

    def build_args(self, base_args: Optional[Iterable[str]] = None) -> list[str]:
        """Return fingerprint args, optionally overriding an existing base args list."""

        extras = list(base_args or [])
        overrides: Dict[str, str] = {}
        for key, prefix in _FINGERPRINT_PREFIXES.items():
            value = self.values.get(key)
            if value is None or str(value).strip() == "":
                continue
            overrides[prefix] = f"{prefix}={value}"

        kept: list[str] = []
        for arg in _normalize_string_list(extras):
            matched = False
            for prefix in _FINGERPRINT_PREFIXES.values():
                if arg == prefix or arg.startswith(prefix + "="):
                    matched = True
                    if prefix not in overrides:
                        overrides[prefix] = arg
                    break
            if not matched:
                kept.append(arg)

        ordered = [overrides[prefix] for prefix in _FINGERPRINT_PREFIXES.values() if prefix in overrides]
        return ordered + kept + _normalize_string_list(self.extra_args)

    @classmethod
    def from_args(cls, args: Iterable[str]) -> "FingerprintBuilder":
        """Seed a builder from an existing daemon fingerprint arg list."""

        builder = cls()
        for arg in _normalize_string_list(args):
            for key, prefix in _FINGERPRINT_PREFIXES.items():
                if arg.startswith(prefix + "="):
                    builder.values[key] = arg.split("=", 1)[1].strip()
                    break
            else:
                builder.extra_args.append(arg)
        return builder


@dataclass
class StealthBuilder:
    """Build daemon stealth config payloads with fluent anti-detect helpers."""

    config: Dict[str, Any] = field(default_factory=dict)

    def user_agent(self, value: str) -> "StealthBuilder":
        self.config["userAgent"] = str(value).strip()
        return self

    def language(self, value: str) -> "StealthBuilder":
        self.config["acceptLanguage"] = str(value).strip()
        return self

    def platform(self, value: str) -> "StealthBuilder":
        self.config["platform"] = str(value).strip()
        return self

    def brand(self, value: str) -> "StealthBuilder":
        self.config["brand"] = str(value).strip()
        return self

    def webrtc_policy(self, value: str) -> "StealthBuilder":
        self.config["webrtcPolicy"] = str(value).strip()
        return self

    def hardware(
        self,
        *,
        hardware_concurrency: Optional[Union[int, str]] = None,
        device_memory: Optional[Union[int, str]] = None,
        webgl_vendor: Optional[str] = None,
        webgl_renderer: Optional[str] = None,
        media_devices: Optional[str] = None,
        touch_points: Optional[Union[int, str]] = None,
    ) -> "StealthBuilder":
        if hardware_concurrency is not None:
            self.config["hardwareConcurrency"] = str(hardware_concurrency).strip()
        if device_memory is not None:
            self.config["deviceMemory"] = str(device_memory).strip()
        if webgl_vendor is not None:
            self.config["webglVendor"] = str(webgl_vendor).strip()
        if webgl_renderer is not None:
            self.config["webglRenderer"] = str(webgl_renderer).strip()
        if media_devices is not None:
            self.config["mediaDevices"] = str(media_devices).strip()
        if touch_points is not None:
            self.config["touchPoints"] = str(touch_points).strip()
        return self

    def noise(self, *, canvas_noise: Optional[bool] = None, audio_noise: Optional[bool] = None) -> "StealthBuilder":
        if canvas_noise is not None:
            self.config["canvasNoise"] = bool(canvas_noise)
        if audio_noise is not None:
            self.config["audioNoise"] = bool(audio_noise)
        return self

    def fonts(self, value: str) -> "StealthBuilder":
        self.config["fonts"] = str(value).strip()
        return self

    def mask_permissions(self, enabled: bool = True) -> "StealthBuilder":
        self.config["maskPermissions"] = bool(enabled)
        return self

    def mask_webdriver(self, enabled: bool = True) -> "StealthBuilder":
        automation = _clone_dict(self.config.get("automationMask"))
        automation["webdriver"] = bool(enabled)
        self.config["automationMask"] = automation
        return self

    def automation_globals(self, *values: str) -> "StealthBuilder":
        automation = _clone_dict(self.config.get("automationMask"))
        automation["automationGlobals"] = _normalize_string_list(values)
        self.config["automationMask"] = automation
        return self

    def chrome_runtime_shim(self, enabled: bool = True) -> "StealthBuilder":
        automation = _clone_dict(self.config.get("automationMask"))
        automation["chromeRuntimeShim"] = bool(enabled)
        self.config["automationMask"] = automation
        return self

    def poison(
        self,
        *,
        canvas_mode: Optional[str] = None,
        webgl_mode: Optional[str] = None,
        audio_mode: Optional[str] = None,
        seed_mode: Optional[str] = None,
        seed_salt: Optional[str] = None,
    ) -> "StealthBuilder":
        poison = _clone_dict(self.config.get("fingerprintPoison"))
        if canvas_mode is not None:
            poison["canvasMode"] = str(canvas_mode).strip()
        if webgl_mode is not None:
            poison["webglMode"] = str(webgl_mode).strip()
        if audio_mode is not None:
            poison["audioMode"] = str(audio_mode).strip()
        if seed_mode is not None:
            poison["seedMode"] = str(seed_mode).strip()
        if seed_salt is not None:
            poison["seedSalt"] = str(seed_salt)
        self.config["fingerprintPoison"] = poison
        return self

    def balanced(self) -> "StealthBuilder":
        """Apply a practical default anti-detect configuration."""

        return (
            self.mask_permissions(True)
            .mask_webdriver(True)
            .chrome_runtime_shim(True)
            .noise(canvas_noise=True, audio_noise=True)
            .poison(
                canvas_mode="session_stable",
                webgl_mode="session_stable",
                audio_mode="session_stable",
                seed_mode="instance_stable",
            )
        )

    def strict(self) -> "StealthBuilder":
        """Apply a stronger anti-detect preset with broader masking."""

        return self.balanced().automation_globals(
            "cdc_adoQpoasnfa76pfcZLmcfl_",
            "__playwright__binding__",
            "__pwInitScripts",
            "__webdriver_script_fn",
            "_selenium",
            "_phantom",
        )

    def build(self) -> Dict[str, Any]:
        """Return the stealth config payload."""

        payload: Dict[str, Any] = {}
        for key, value in self.config.items():
            if value is None:
                continue
            if isinstance(value, dict):
                nested = {nested_key: nested_value for nested_key, nested_value in value.items() if nested_value not in (None, "", [])}
                if nested:
                    payload[key] = nested
                continue
            if value == "" or value == []:
                continue
            payload[key] = value
        return payload

    @classmethod
    def from_config(cls, config: Optional[Dict[str, Any]]) -> "StealthBuilder":
        """Seed a builder from an existing daemon stealth config payload."""

        return cls(config=_clone_dict(config))


class ProfileBuilder:
    """Fluent profile workflow builder for more ergonomic automation scripts."""

    def __init__(self, browser: "AntBrowser", profile_name: str = "") -> None:
        self.browser = browser
        self.profile_name = str(profile_name).strip()
        self.profile: Dict[str, Any] = {
            "profileName": self.profile_name,
            "userDataDir": "",
            "coreId": "",
            "fingerprintArgs": [],
            "proxyId": "",
            "proxyConfig": "",
            "launchArgs": [],
            "tags": [],
            "keywords": [],
        }
        self.fingerprint_builder = FingerprintBuilder()
        self.fingerprint_explicit = False
        self.stealth_builder = StealthBuilder()
        self.stealth_enabled: Optional[bool] = None
        self.random_environment_enabled = False
        self.random_name_prefix = "AI Random"

    def name(self, value: str) -> "ProfileBuilder":
        self.profile_name = str(value).strip()
        self.profile["profileName"] = self.profile_name
        return self

    def core(self, core_id: str) -> "ProfileBuilder":
        self.profile["coreId"] = str(core_id).strip()
        return self

    def proxy(self, *, proxy_id: str = "", proxy_config: str = "") -> "ProfileBuilder":
        self.profile["proxyId"] = str(proxy_id).strip()
        self.profile["proxyConfig"] = str(proxy_config).strip()
        return self

    def user_data_dir(self, value: str) -> "ProfileBuilder":
        self.profile["userDataDir"] = str(value).strip()
        return self

    def tags(self, *values: str) -> "ProfileBuilder":
        self.profile["tags"] = _normalize_string_list(values)
        return self

    def keywords(self, *values: str) -> "ProfileBuilder":
        self.profile["keywords"] = _normalize_string_list(values)
        return self

    def launch_args(self, *values: str) -> "ProfileBuilder":
        self.profile["launchArgs"] = _normalize_string_list(values)
        return self

    def fingerprint(self, builder: FingerprintBuilder) -> "ProfileBuilder":
        self.fingerprint_builder = builder
        self.fingerprint_explicit = True
        return self

    def random_environment(self, *, name_prefix: str = "AI Random") -> "ProfileBuilder":
        self.random_environment_enabled = True
        self.random_name_prefix = str(name_prefix).strip() or "AI Random"
        return self

    def hardware(
        self,
        *,
        hardware_concurrency: Optional[Union[int, str]] = None,
        device_memory: Optional[Union[int, str]] = None,
        webgl_vendor: Optional[str] = None,
        webgl_renderer: Optional[str] = None,
        media_devices: Optional[str] = None,
        touch_points: Optional[Union[int, str]] = None,
        mirror_to_stealth: bool = True,
    ) -> "ProfileBuilder":
        self.fingerprint_explicit = True
        self.fingerprint_builder.hardware(
            hardware_concurrency=hardware_concurrency,
            device_memory=device_memory,
            webgl_vendor=webgl_vendor,
            webgl_renderer=webgl_renderer,
            media_devices=media_devices,
            touch_points=touch_points,
        )
        if mirror_to_stealth:
            self.stealth(
                self.stealth_builder.hardware(
                    hardware_concurrency=hardware_concurrency,
                    device_memory=device_memory,
                    webgl_vendor=webgl_vendor,
                    webgl_renderer=webgl_renderer,
                    media_devices=media_devices,
                    touch_points=touch_points,
                ),
                enabled=True,
            )
        return self

    def poison(
        self,
        *,
        canvas_mode: str = "session_stable",
        webgl_mode: str = "session_stable",
        audio_mode: str = "session_stable",
        seed_mode: str = "instance_stable",
        seed_salt: str = "",
    ) -> "ProfileBuilder":
        self.stealth_enabled = True
        self.stealth_builder.poison(
            canvas_mode=canvas_mode,
            webgl_mode=webgl_mode,
            audio_mode=audio_mode,
            seed_mode=seed_mode,
            seed_salt=seed_salt,
        )
        return self

    def anti_detect(self, mode: str = "balanced") -> "ProfileBuilder":
        self.stealth_enabled = True
        if str(mode).strip().lower() == "strict":
            self.stealth_builder.strict()
        else:
            self.stealth_builder.balanced()
        return self

    def stealth(self, builder: Optional[StealthBuilder] = None, *, enabled: bool = True) -> "ProfileBuilder":
        if builder is not None:
            self.stealth_builder = builder
        self.stealth_enabled = bool(enabled)
        return self

    def create(
        self,
        *,
        launch_code: str = "",
        auto_launch: bool = False,
        run_mode: str = "headless",
        start_urls: Optional[list[str]] = None,
        skip_default_start_urls: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Create the profile workflow, including randomization and stealth application."""

        if self.random_environment_enabled:
            return self._create_random(
                launch_code=launch_code,
                auto_launch=auto_launch,
                run_mode=run_mode,
                start_urls=start_urls,
                skip_default_start_urls=skip_default_start_urls,
            )
        return self._create_direct(
            launch_code=launch_code,
            auto_launch=auto_launch,
            run_mode=run_mode,
            start_urls=start_urls,
            skip_default_start_urls=skip_default_start_urls,
        )

    def _create_direct(
        self,
        *,
        launch_code: str,
        auto_launch: bool,
        run_mode: str,
        start_urls: Optional[list[str]],
        skip_default_start_urls: Optional[bool],
    ) -> Dict[str, Any]:
        """Create a direct profile without server-side random fingerprint generation."""

        profile = self._build_profile_payload()
        start = self.browser._build_start_payload(
            run_mode=run_mode,
            launch_args=None,
            start_urls=start_urls,
            skip_default_start_urls=skip_default_start_urls,
        )
        if not auto_launch:
            start = None
        return self.browser.profiles.create(profile, launch_code=launch_code, auto_launch=auto_launch, start=start)

    def _create_random(
        self,
        *,
        launch_code: str,
        auto_launch: bool,
        run_mode: str,
        start_urls: Optional[list[str]],
        skip_default_start_urls: Optional[bool],
    ) -> Dict[str, Any]:
        """Create a server-randomized profile, then apply local overrides and stealth if needed."""

        create_payload = {
            "profileName": self.profile_name,
            "namePrefix": self.random_name_prefix,
            "userDataDir": self.profile.get("userDataDir", ""),
            "coreId": self.profile.get("coreId", ""),
            "proxyId": self.profile.get("proxyId", ""),
            "proxyConfig": self.profile.get("proxyConfig", ""),
            "launchArgs": list(self.profile.get("launchArgs", [])),
            "tags": list(self.profile.get("tags", [])),
            "keywords": list(self.profile.get("keywords", [])),
            "launchCode": launch_code,
            "autoLaunch": False,
        }
        response = self.browser.instances.create_random(create_payload)
        instance = response.get("instance", {})
        profile_snapshot = dict(instance.get("profile", {}))
        profile_id = response.get("profileId") or instance.get("profileId") or profile_snapshot.get("profileId", "")
        agent_id = response.get("agentId") or instance.get("agentId") or profile_snapshot.get("agentId", "")
        if not profile_id or not agent_id:
            raise RuntimeError("random instance creation did not return profileId/agentId")

        updated = False
        if self.fingerprint_explicit:
            profile_snapshot["fingerprintArgs"] = self.fingerprint_builder.build_args(instance.get("fingerprintArgs", []))
            updated = True
        if self.stealth_enabled is not None:
            profile_snapshot["stealthEnabled"] = self.stealth_enabled
            profile_snapshot["stealthConfig"] = self.stealth_builder.build()
            updated = True

        if updated:
            profile_payload = self.browser._normalize_profile_for_write(profile_snapshot)
            self.browser.profiles.update(profile_id, profile_payload)

        started = None
        if auto_launch:
            started = self.browser.start_instance(
                agent_id,
                run_mode=run_mode,
                start_urls=start_urls,
                skip_default_start_urls=skip_default_start_urls,
            )

        if started is not None:
            response["started"] = started
        response["instance"] = self.browser.instances.get(agent_id).get("instance", instance)
        return response

    def _build_profile_payload(self) -> Dict[str, Any]:
        """Assemble the final profile payload for daemon profile APIs."""

        payload = dict(self.profile)
        if self.fingerprint_explicit:
            payload["fingerprintArgs"] = self.fingerprint_builder.build_args(payload.get("fingerprintArgs", []))
        else:
            payload["fingerprintArgs"] = list(payload.get("fingerprintArgs", []))
        if self.stealth_enabled is not None:
            payload["stealthEnabled"] = self.stealth_enabled
            payload["stealthConfig"] = self.stealth_builder.build()
        return payload
