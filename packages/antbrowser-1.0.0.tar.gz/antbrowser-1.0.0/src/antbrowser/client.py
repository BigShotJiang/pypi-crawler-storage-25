"""HTTP client and high-level helpers for the Ant Browser daemon."""

from __future__ import annotations

import json
import pathlib
import shutil
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union

from .builders import FingerprintBuilder, ProfileBuilder, StealthBuilder
from .daemon import DaemonManager, DaemonMetadata


class AntBrowserError(RuntimeError):
    """Base exception for SDK failures."""


class AntBrowserHTTPError(AntBrowserError):
    """Raised when the daemon returns an HTTP or business-layer error."""


@dataclass
class _Connection:
    """Concrete daemon connection settings used by the HTTP client."""

    base_url: str
    api_key: str
    api_header: str


class _HTTPClient:
    """Tiny JSON-over-HTTP helper shared by raw and high-level API wrappers."""

    def __init__(self, connection: _Connection, timeout: float = 15.0) -> None:
        self.connection = connection
        self.timeout = timeout

    def request_json(
        self,
        path: str,
        *,
        method: str = "GET",
        query: Optional[Dict[str, Any]] = None,
        body: Any = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Perform a JSON request and normalize daemon errors into exceptions."""

        url = self._build_url(path, query)
        data = None
        headers = {
            "Accept": "application/json",
            self.connection.api_header: self.connection.api_key,
        }
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"

        request = urllib.request.Request(url=url, method=method.upper(), data=data, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=timeout or self.timeout) as response:
                payload = self._decode_payload(response.read())
        except urllib.error.HTTPError as error:
            payload = self._decode_payload(error.read())
            message = str(payload.get("error", f"HTTP {error.code}"))
            raise AntBrowserHTTPError(message) from error
        except urllib.error.URLError as error:
            raise AntBrowserHTTPError(str(error.reason)) from error

        if isinstance(payload, dict) and payload.get("ok", True) is False:
            raise AntBrowserHTTPError(str(payload.get("error", "daemon returned ok=false")))
        return payload

    def _build_url(self, path: str, query: Optional[Dict[str, Any]]) -> str:
        """Compose a request URL from the daemon base URL, path, and query parameters."""

        normalized = path if path.startswith("/") else "/" + path
        url = self.connection.base_url.rstrip("/") + normalized
        if not query:
            return url
        pairs = []
        for key, value in query.items():
            if value is None or value == "":
                continue
            pairs.append((key, str(value)))
        if not pairs:
            return url
        return url + "?" + urllib.parse.urlencode(pairs)

    @staticmethod
    def _decode_payload(raw: bytes) -> Dict[str, Any]:
        """Decode JSON responses and gracefully fall back for empty bodies."""

        text = raw.decode("utf-8") if raw else ""
        if not text.strip():
            return {}
        payload = json.loads(text)
        if isinstance(payload, dict):
            return payload
        return {"ok": True, "value": payload}


class BaseNamespace:
    """Small helper base class for namespaced raw endpoints."""

    def __init__(self, http: _HTTPClient) -> None:
        self._http = http


class RuntimeAPI(BaseNamespace):
    """Raw runtime control endpoints."""

    def info(self) -> Dict[str, Any]:
        return self._http.request_json("/api/runtime/info")

    def shutdown(self) -> Dict[str, Any]:
        return self._http.request_json("/api/runtime/shutdown", method="POST")


class ProfilesAPI(BaseNamespace):
    """Raw profile CRUD endpoints."""

    def list(self) -> Dict[str, Any]:
        return self._http.request_json("/api/profiles")

    def get(self, profile_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/profiles/{profile_id}")

    def create(
        self,
        profile: Dict[str, Any],
        *,
        launch_code: str = "",
        auto_launch: bool = False,
        start: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        return self._http.request_json(
            "/api/profiles",
            method="POST",
            body={
                "profile": profile,
                "launchCode": launch_code,
                "autoLaunch": auto_launch,
                "start": start,
            },
        )

    def update(
        self,
        profile_id: str,
        profile: Dict[str, Any],
        *,
        launch_code: str = "",
        auto_launch: bool = False,
        start: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/profiles/{profile_id}",
            method="PUT",
            body={
                "profile": profile,
                "launchCode": launch_code,
                "autoLaunch": auto_launch,
                "start": start,
            },
        )

    def delete(self, profile_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/profiles/{profile_id}", method="DELETE")


class InstancesAPI(BaseNamespace):
    """Raw agent instance endpoints."""

    def list(self) -> Dict[str, Any]:
        return self._http.request_json("/api/agent/instances")

    def get(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}")

    def create(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return self._http.request_json("/api/agent/instances", method="POST", body=payload)

    def create_random(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return self._http.request_json("/api/agent/instances/random", method="POST", body=payload)

    def start(self, agent_id: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/start",
            method="POST",
            body=payload or {},
        )

    def stop(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/stop", method="POST")


class PageAPI(BaseNamespace):
    """Raw page interaction endpoints."""

    def goto(self, agent_id: str, url: str, **extra: Any) -> Dict[str, Any]:
        payload = {"url": url}
        payload.update(extra)
        return self._http.request_json(f"/api/agent/instances/{agent_id}/page/goto", method="POST", body=payload)

    def click(self, agent_id: str, selector: str, **extra: Any) -> Dict[str, Any]:
        payload = {"selector": selector}
        payload.update(extra)
        return self._http.request_json(f"/api/agent/instances/{agent_id}/page/click", method="POST", body=payload)

    def eval(self, agent_id: str, expression: str, **extra: Any) -> Dict[str, Any]:
        payload = {"expression": expression}
        payload.update(extra)
        return self._http.request_json(f"/api/agent/instances/{agent_id}/page/eval", method="POST", body=payload)

    def screenshot(self, agent_id: str, **payload: Any) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/page/screenshot",
            method="POST",
            body=payload,
        )


class NetworkAPI(BaseNamespace):
    """Raw network interception endpoints."""

    def enable(self, agent_id: str, **payload: Any) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/network/intercept/enable",
            method="POST",
            body=payload,
        )

    def disable(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/network/intercept/disable",
            method="POST",
            body={},
        )

    def set_rules(self, agent_id: str, rules: list[Dict[str, Any]]) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/network/intercept/rules",
            method="POST",
            body={"rules": rules},
        )

    def get_rules(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/network/intercept/rules")


class InspectAPI(BaseNamespace):
    """Raw inspect endpoints."""

    def network_records(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/inspect/network/records")


class TLSAPI(BaseNamespace):
    """Raw TLS inspect endpoints."""

    def capabilities(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/inspect/tls/capabilities")

    def prepare(self, agent_id: str, **payload: Any) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/inspect/tls/prepare",
            method="POST",
            body=payload,
        )

    def status(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/inspect/tls/status")

    def records(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/inspect/tls/records")

    def clear(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/inspect/tls/clear",
            method="POST",
            body={},
        )


class LeaseAPI(BaseNamespace):
    """Raw lease management endpoints."""

    def get(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/lease")

    def acquire(self, agent_id: str, *, owner_id: str, ttl_sec: int = 120, force: bool = False) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/lease/acquire",
            method="POST",
            body={"ownerId": owner_id, "ttlSec": ttl_sec, "force": force},
        )

    def renew(self, agent_id: str, *, lease_token: str, ttl_sec: int = 120) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/lease/renew",
            method="POST",
            body={"leaseToken": lease_token, "ttlSec": ttl_sec},
        )

    def release(self, agent_id: str, *, lease_token: str) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/lease/release",
            method="POST",
            body={"leaseToken": lease_token},
        )


class ConsoleAPI(BaseNamespace):
    """Raw console collection endpoints."""

    def enable(self, agent_id: str, *, target_id: str = "") -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/console/enable",
            method="POST",
            body={"targetId": target_id} if target_id else {},
        )

    def disable(self, agent_id: str, *, target_id: str = "") -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/console/disable",
            method="POST",
            body={"targetId": target_id} if target_id else {},
        )

    def records(self, agent_id: str, *, target_id: str = "") -> Dict[str, Any]:
        query = {"targetId": target_id} if target_id else None
        return self._http.request_json(f"/api/agent/instances/{agent_id}/console/records", query=query)


class StorageAPI(BaseNamespace):
    """Raw cookies and web storage endpoints."""

    def cookies_get(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/storage/cookies")

    def cookies_set(self, agent_id: str, cookies: list[Dict[str, Any]]) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/storage/cookies/set",
            method="POST",
            body={"cookies": cookies},
        )

    def cookies_clear(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/storage/cookies/clear", method="POST", body={})

    def local_storage_get(self, agent_id: str, *, target_id: str = "") -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/storage/local-storage",
            query={"targetId": target_id} if target_id else None,
        )

    def local_storage_set(self, agent_id: str, items: Dict[str, Any], *, target_id: str = "") -> Dict[str, Any]:
        body: Dict[str, Any] = {"items": items}
        if target_id:
            body["targetId"] = target_id
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/storage/local-storage/set",
            method="POST",
            body=body,
        )

    def local_storage_clear(self, agent_id: str, keys: Optional[list[str]] = None, *, target_id: str = "") -> Dict[str, Any]:
        body: Dict[str, Any] = {"keys": keys or []}
        if target_id:
            body["targetId"] = target_id
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/storage/local-storage/clear",
            method="POST",
            body=body,
        )

    def session_storage_get(self, agent_id: str, *, target_id: str = "") -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/storage/session-storage",
            query={"targetId": target_id} if target_id else None,
        )

    def session_storage_set(self, agent_id: str, items: Dict[str, Any], *, target_id: str = "") -> Dict[str, Any]:
        body: Dict[str, Any] = {"items": items}
        if target_id:
            body["targetId"] = target_id
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/storage/session-storage/set",
            method="POST",
            body=body,
        )

    def session_storage_clear(self, agent_id: str, keys: Optional[list[str]] = None, *, target_id: str = "") -> Dict[str, Any]:
        body: Dict[str, Any] = {"keys": keys or []}
        if target_id:
            body["targetId"] = target_id
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/storage/session-storage/clear",
            method="POST",
            body=body,
        )


class DownloadsAPI(BaseNamespace):
    """Raw download tracking endpoints."""

    def enable(self, agent_id: str, *, download_dir: str = "") -> Dict[str, Any]:
        body = {"downloadDir": download_dir} if download_dir else {}
        return self._http.request_json(f"/api/agent/instances/{agent_id}/downloads/enable", method="POST", body=body)

    def list(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/downloads")

    def save(self, agent_id: str, download_id: str, *, destination_path: str, overwrite: bool = False) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/downloads/{download_id}/save",
            method="POST",
            body={"destinationPath": destination_path, "overwrite": overwrite},
        )


class TasksAPI(BaseNamespace):
    """Raw async task endpoints."""

    def run(self, agent_id: str, *, kind: str, params: Optional[Dict[str, Any]] = None, ttl_sec: int = 600) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/task/run",
            method="POST",
            body={"kind": kind, "params": params or {}, "ttlSec": ttl_sec},
        )

    def get(self, task_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/tasks/{task_id}")

    def cancel(self, task_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/tasks/{task_id}/cancel", method="POST", body={})


class TargetsAPI(BaseNamespace):
    """Raw browser target management endpoints."""

    def list(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/targets")

    def open(self, agent_id: str, *, url: str) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/targets/open",
            method="POST",
            body={"url": url},
        )

    def activate(self, agent_id: str, target_id: str) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/targets/{target_id}/activate",
            method="POST",
            body={},
        )

    def close(self, agent_id: str, target_id: str) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/targets/{target_id}/close",
            method="POST",
            body={},
        )


class ExposeAPI(BaseNamespace):
    """Raw page expose endpoints."""

    def request(self, agent_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/page/expose",
            method="POST",
            body=body,
        )


class StealthAPI(BaseNamespace):
    """Raw stealth endpoints."""

    def get(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/agent/instances/{agent_id}/stealth")

    def enable(self, agent_id: str, **payload: Any) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/stealth/enable",
            method="POST",
            body=payload,
        )

    def disable(self, agent_id: str) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/stealth/disable",
            method="POST",
            body={},
        )

    def preview(self, agent_id: str, **payload: Any) -> Dict[str, Any]:
        return self._http.request_json(
            f"/api/agent/instances/{agent_id}/stealth/preview",
            method="POST",
            body=payload,
        )


class CoresAPI(BaseNamespace):
    """Raw browser core management endpoints."""

    def list(self) -> Dict[str, Any]:
        return self._http.request_json("/api/cores")

    def get(self, core_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/cores/{core_id}")

    def save(self, core: Dict[str, Any]) -> Dict[str, Any]:
        return self._http.request_json("/api/cores", method="POST", body=core)

    def delete(self, core_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/cores/{core_id}", method="DELETE")

    def set_default(self, core_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/cores/{core_id}/default", method="POST", body={})

    def validate(self, core_path: str) -> Dict[str, Any]:
        return self._http.request_json("/api/cores/validate", method="POST", body={"corePath": core_path})

    def extended_info(self) -> Dict[str, Any]:
        return self._http.request_json("/api/cores/extended-info")

    def scan(self) -> Dict[str, Any]:
        return self._http.request_json("/api/cores/scan", method="POST", body={})

    def discover(self) -> Dict[str, Any]:
        return self._http.request_json("/api/cores/discover")


class ProxiesAPI(BaseNamespace):
    """Raw proxy catalog management endpoints."""

    def list(self) -> Dict[str, Any]:
        return self._http.request_json("/api/proxies")

    def get(self, proxy_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/proxies/{proxy_id}")

    def save(self, proxy: Dict[str, Any]) -> Dict[str, Any]:
        return self._http.request_json("/api/proxies", method="POST", body=proxy)

    def update(self, proxy_id: str, proxy: Dict[str, Any]) -> Dict[str, Any]:
        return self._http.request_json(f"/api/proxies/{proxy_id}", method="PUT", body=proxy)

    def delete(self, proxy_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/proxies/{proxy_id}", method="DELETE")

    def replace(self, items: list[Dict[str, Any]]) -> Dict[str, Any]:
        return self._http.request_json("/api/proxies", method="PUT", body={"items": items})

    def groups(self) -> Dict[str, Any]:
        return self._http.request_json("/api/proxies/groups")

    def validate(self, *, proxy_config: str = "", proxy_id: str = "") -> Dict[str, Any]:
        return self._http.request_json(
            "/api/proxies/validate",
            method="POST",
            body={"proxyConfig": proxy_config, "proxyId": proxy_id},
        )

    def fetch_clash(self, url: str) -> Dict[str, Any]:
        return self._http.request_json("/api/proxies/fetch-clash", method="POST", body={"url": url})

    def test_speed(self, proxy_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/proxies/{proxy_id}/test-speed", method="POST", body={})

    def check_ip_health(self, proxy_id: str) -> Dict[str, Any]:
        return self._http.request_json(f"/api/proxies/{proxy_id}/check-ip-health", method="POST", body={})


class RawClient:
    """1:1 raw daemon client that mirrors the HTTP surface without hiding fields."""

    def __init__(self, http: _HTTPClient) -> None:
        self._http = http
        self.runtime = RuntimeAPI(http)
        self.profiles = ProfilesAPI(http)
        self.instances = InstancesAPI(http)
        self.page = PageAPI(http)
        self.network = NetworkAPI(http)
        self.inspect = InspectAPI(http)
        self.tls = TLSAPI(http)
        self.lease = LeaseAPI(http)
        self.console = ConsoleAPI(http)
        self.storage = StorageAPI(http)
        self.downloads = DownloadsAPI(http)
        self.tasks = TasksAPI(http)
        self.targets = TargetsAPI(http)
        self.expose = ExposeAPI(http)
        self.stealth = StealthAPI(http)
        self.cores = CoresAPI(http)
        self.proxies = ProxiesAPI(http)

    def request_json(
        self,
        path: str,
        *,
        method: str = "GET",
        query: Optional[Dict[str, Any]] = None,
        body: Any = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Expose the underlying generic request helper for unmapped endpoints."""

        return self._http.request_json(path, method=method, query=query, body=body, timeout=timeout)


class AntBrowser:
    """High-level SDK entry point with daemon auto-start and common workflow helpers."""

    def __init__(
        self,
        *,
        workspace: Optional[str] = None,
        base_url: Optional[str] = None,
        api_key: str = "",
        api_header: str = "X-Ant-Api-Key",
        daemon_path: Optional[str] = None,
        auto_start: bool = True,
        timeout: float = 15.0,
    ) -> None:
        self._daemon_manager: Optional[DaemonManager] = None
        self._daemon_metadata: Optional[DaemonMetadata] = None

        if base_url:
            connection = _Connection(base_url=base_url.strip(), api_key=api_key.strip(), api_header=api_header.strip())
        else:
            self._daemon_manager = DaemonManager(
                workspace=workspace,
                daemon_path=daemon_path,
                auto_start=auto_start,
            )
            self._daemon_metadata = self._daemon_manager.ensure_metadata()
            connection = _Connection(
                base_url=self._daemon_metadata.base_url,
                api_key=self._daemon_metadata.api_key,
                api_header=self._daemon_metadata.api_header,
            )

        self._http = _HTTPClient(connection, timeout=timeout)
        self.raw = RawClient(self._http)
        self.runtime = self.raw.runtime
        self.profiles = self.raw.profiles
        self.instances = self.raw.instances
        self.page = self.raw.page
        self.network = self.raw.network
        self.inspect = self.raw.inspect
        self.tls = self.raw.tls
        self.lease = self.raw.lease
        self.console = self.raw.console
        self.storage = self.raw.storage
        self.downloads = self.raw.downloads
        self.tasks = self.raw.tasks
        self.targets = self.raw.targets
        self.expose = self.raw.expose
        self.stealth = self.raw.stealth
        self.cores = self.raw.cores
        self.proxies = self.raw.proxies

    def __enter__(self) -> "AntBrowser":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def new_fingerprint(self) -> FingerprintBuilder:
        """Create a fluent fingerprint builder for environment and hardware args."""

        return FingerprintBuilder()

    def new_stealth(self) -> StealthBuilder:
        """Create a fluent stealth builder for anti-detect and poison settings."""

        return StealthBuilder()

    def new_profile(self, profile_name: str = "") -> ProfileBuilder:
        """Create a fluent profile builder for Playwright-style profile setup."""

        return ProfileBuilder(self, profile_name=profile_name)

    def raw_request(
        self,
        path: str,
        *,
        method: str = "GET",
        query: Optional[Dict[str, Any]] = None,
        body: Any = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Expose a direct raw request helper for endpoints not wrapped yet."""

        return self.raw.request_json(path, method=method, query=query, body=body, timeout=timeout)

    def create_profile(
        self,
        profile: Dict[str, Any],
        *,
        launch_code: str = "",
        auto_launch: bool = False,
        run_mode: str = "headless",
        start: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create a profile using a high-level default run mode."""

        start_payload = self._merge_run_mode(start, run_mode)
        return self.profiles.create(profile, launch_code=launch_code, auto_launch=auto_launch, start=start_payload)

    def start_instance(
        self,
        agent_id: str,
        *,
        run_mode: str = "headless",
        launch_args: Optional[list[str]] = None,
        start_urls: Optional[list[str]] = None,
        skip_default_start_urls: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Start an existing agent instance with Python-friendly defaults."""

        payload = self._build_start_payload(
            run_mode=run_mode,
            launch_args=launch_args,
            start_urls=start_urls,
            skip_default_start_urls=skip_default_start_urls,
        )
        return self.instances.start(agent_id, payload=payload)

    def launch(
        self,
        *,
        code: str = "",
        key: str = "",
        agent_id: str = "",
        profile_id: str = "",
        profile_name: str = "",
        keyword: str = "",
        run_mode: str = "headless",
        launch_args: Optional[list[str]] = None,
        start_urls: Optional[list[str]] = None,
        skip_default_start_urls: Optional[bool] = None,
        tls_inspect: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Launch a profile or instance by selector with headless-friendly defaults."""

        payload = self._build_start_payload(
            run_mode=run_mode,
            launch_args=launch_args,
            start_urls=start_urls,
            skip_default_start_urls=skip_default_start_urls,
        )
        payload.update(
            {
                "code": code,
                "key": key,
                "agentId": agent_id,
                "profileId": profile_id,
                "profileName": profile_name,
                "keyword": keyword,
            }
        )
        if tls_inspect is not None:
            payload["tlsInspect"] = tls_inspect
        return self.raw_request("/api/launch", method="POST", body=payload)

    def shutdown_daemon(self) -> Dict[str, Any]:
        """Request daemon shutdown through the runtime API."""

        return self.runtime.shutdown()

    def discover_system_cores(self) -> list[Dict[str, Any]]:
        """Return the daemon's best-effort system browser core candidates."""

        return list(self.cores.discover().get("items", []))

    def ensure_core(
        self,
        core_path: str,
        *,
        core_name: Optional[str] = None,
        core_id: str = "",
        is_default: bool = False,
    ) -> Dict[str, Any]:
        """Validate and save a browser core with a Python-friendly convenience wrapper."""

        validation = self.cores.validate(core_path)
        result = validation.get("result", {})
        if not result.get("valid", False):
            raise AntBrowserHTTPError(str(result.get("message", "invalid core path")))

        path_value = pathlib.Path(core_path)
        if core_name is None:
            core_name = path_value.name or "Browser Core"
        response = self.cores.save(
            {
                "coreId": core_id,
                "coreName": core_name,
                "corePath": core_path,
                "isDefault": is_default,
            }
        )
        if "core" in response:
            return response["core"]
        items = response.get("items", [])
        if items:
            return items[-1]
        raise AntBrowserHTTPError("daemon did not return saved core payload")

    def ensure_termux_chromium_core(
        self,
        *,
        executable_path: Optional[str] = None,
        core_name: str = "Termux Chromium",
        is_default: bool = True,
    ) -> Dict[str, Any]:
        """Register the local Termux Chromium binary as a browser core."""

        chromium_path = executable_path or shutil.which("chromium") or shutil.which("chromium-browser")
        if not chromium_path:
            raise AntBrowserHTTPError("unable to find chromium on PATH; install it in Termux or pass executable_path")
        return self.ensure_core(chromium_path, core_name=core_name, is_default=is_default)

    def save_proxy(self, proxy: Dict[str, Any]) -> Dict[str, Any]:
        """Save one proxy node and return the saved proxy payload."""

        response = self.proxies.save(proxy)
        return response.get("proxy", response)

    def import_clash_subscription(
        self,
        url: str,
        *,
        group_name: Optional[str] = None,
        replace: bool = False,
    ) -> Dict[str, Any]:
        """Fetch a Clash subscription and return the normalized import preview payload."""

        preview = self.proxies.fetch_clash(url)
        if group_name is not None:
            preview["suggestedGroup"] = group_name
        preview["replaceRecommended"] = replace
        return preview

    def create_random_instance(
        self,
        *,
        profile_name: str = "",
        name_prefix: str = "AI Random",
        core_id: str = "",
        proxy_id: str = "",
        proxy_config: str = "",
        launch_args: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
        keywords: Optional[list[str]] = None,
        launch_code: str = "",
        auto_launch: bool = False,
        run_mode: str = "headless",
        start_urls: Optional[list[str]] = None,
        skip_default_start_urls: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Create a randomized instance using the daemon's built-in random fingerprint generator."""

        payload = {
            "profileName": profile_name,
            "namePrefix": name_prefix,
            "coreId": core_id,
            "proxyId": proxy_id,
            "proxyConfig": proxy_config,
            "launchArgs": list(launch_args or []),
            "tags": list(tags or []),
            "keywords": list(keywords or []),
            "launchCode": launch_code,
            "autoLaunch": False,
        }
        response = self.instances.create_random(payload)
        if auto_launch:
            agent_id = response.get("agentId") or response.get("instance", {}).get("agentId")
            if agent_id:
                response["started"] = self.start_instance(
                    agent_id,
                    run_mode=run_mode,
                    start_urls=start_urls,
                    skip_default_start_urls=skip_default_start_urls,
                )
        return response

    def preview_stealth(
        self,
        *,
        agent_id: Optional[str] = None,
        fingerprint: Optional[Union[FingerprintBuilder, List[str]]] = None,
        stealth: Optional[Union[StealthBuilder, Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Preview the stealth payload either from an existing instance or explicit builders."""

        fingerprint_args = self._resolve_preview_fingerprint_args(agent_id=agent_id, fingerprint=fingerprint)
        stealth_config = self._resolve_stealth_config(stealth)
        if not agent_id:
            raise AntBrowserHTTPError("agent_id is required for stealth preview in the current daemon API")
        return self.stealth.preview(agent_id, fingerprintArgs=fingerprint_args, stealthConfig=stealth_config)

    def enable_stealth(
        self,
        agent_id: str,
        *,
        stealth: Optional[Union[StealthBuilder, Dict[str, Any]]] = None,
        strict: bool = False,
    ) -> Dict[str, Any]:
        """Enable stealth on an instance using either a builder or a strict preset."""

        config = self._resolve_stealth_config(stealth)
        if strict and not config:
            config = StealthBuilder().strict().build()
        return self.stealth.enable(agent_id, **config)

    @staticmethod
    def _merge_run_mode(start: Optional[Dict[str, Any]], run_mode: str) -> Optional[Dict[str, Any]]:
        """Apply the high-level run mode default to an optional start payload."""

        payload = dict(start or {})
        if run_mode and "runMode" not in payload:
            payload["runMode"] = run_mode
        return payload or None

    @staticmethod
    def _build_start_payload(
        *,
        run_mode: str,
        launch_args: Optional[list[str]],
        start_urls: Optional[list[str]],
        skip_default_start_urls: Optional[bool],
    ) -> Dict[str, Any]:
        """Construct the common start payload shared by launch and instance-start helpers."""

        payload: Dict[str, Any] = {
            "runMode": run_mode,
            "launchArgs": list(launch_args or []),
            "startUrls": list(start_urls or []),
        }
        if skip_default_start_urls is None:
            payload["skipDefaultStartURLs"] = run_mode == "headless" and not start_urls
        else:
            payload["skipDefaultStartURLs"] = skip_default_start_urls
        return payload

    @staticmethod
    def _resolve_stealth_config(stealth: Optional[Union[StealthBuilder, Dict[str, Any]]]) -> Dict[str, Any]:
        """Normalize stealth builder inputs into the daemon config payload shape."""

        if stealth is None:
            return {}
        if isinstance(stealth, StealthBuilder):
            return stealth.build()
        return dict(stealth)

    def _resolve_preview_fingerprint_args(
        self,
        *,
        agent_id: Optional[str],
        fingerprint: Optional[Union[FingerprintBuilder, List[str]]],
    ) -> list[str]:
        """Build preview fingerprint args from either a builder or an existing instance snapshot."""

        if isinstance(fingerprint, FingerprintBuilder):
            return fingerprint.build_args()
        if isinstance(fingerprint, list):
            return list(fingerprint)
        if agent_id:
            instance = self.instances.get(agent_id).get("instance", {})
            return list(instance.get("fingerprintArgs", []))
        return []

    @staticmethod
    def _normalize_profile_for_write(profile: Dict[str, Any]) -> Dict[str, Any]:
        """Strip runtime-only fields from a daemon profile snapshot before writing it back."""

        allowed = {
            "profileName",
            "userDataDir",
            "coreId",
            "fingerprintArgs",
            "stealthEnabled",
            "stealthConfig",
            "proxyId",
            "proxyConfig",
            "launchArgs",
            "tags",
            "keywords",
            "groupId",
        }
        payload: Dict[str, Any] = {}
        for key in allowed:
            if key in profile:
                payload[key] = profile[key]
        return payload
