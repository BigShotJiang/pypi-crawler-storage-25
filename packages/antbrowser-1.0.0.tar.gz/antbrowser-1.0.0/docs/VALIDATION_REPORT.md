# SDK Validation Report

- Workspace: `D:\tmp\antbrowser-sdk-validation`
- Generated At: `2026-04-10 12:54:50`

| Module | Status | Detail |
| --- | --- | --- |
| `runtime` | `PASS` | {"hostMode": "daemon", "platform": "windows", "workspace": "D:\\tmp\\antbrowser-sdk-validation"} |
| `builders` | `PASS` | fingerprint_args=11, stealth_keys=['audioNoise', 'automationMask', 'canvasNoise', 'deviceMemory', 'fingerprintPoison'] |
| `cores` | `PASS` | saved_core=e847eae2-d316-405b-88a9-e89f3d449272, discovered_candidates=0 |
| `proxies` | `PASS` | saved_proxy=33c85abd-9393-43d2-8b18-dc60135516e0, speed_ok=True, ip_ok=True |
| `profiles` | `PASS` | direct_agent=agent-000016, random_agent=agent-000017 |
| `instances` | `PASS` | started_agent=agent-000016, launch_url=https://example.com |
| `lease` | `PASS` | lease_token=08d774c9... |
| `stealth` | `PASS` | preview+enable+disable completed |
| `page` | `PASS` | title=Example Domain |
| `targets` | `PASS` | opened_target=5AE5994BF25EE44A3C76F1DBCA99372C |
| `storage` | `PASS` | cookies/localStorage/sessionStorage verified |
| `console` | `PASS` | console_records=1 |
| `downloads` | `PASS` | download_dir=D:\tmp\antbrowser-sdk-validation\downloads |
| `network` | `PASS` | rules=1 |
| `inspect` | `PASS` | inspect_records=1, query_count=0 |
| `expose` | `PASS` | snapshot+evaluate completed |
| `tasks` | `PASS` | task_id=20f83fa0-955d-406f-83c1-493c069f10d3 |
| `tls` | `PASS` | capabilities+prepare+status+clear completed |
