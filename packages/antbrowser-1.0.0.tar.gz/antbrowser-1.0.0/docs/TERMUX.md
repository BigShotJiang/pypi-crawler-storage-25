# Android / Termux Guide

## Positioning

Android/Termux 不是桌面 Chrome 场景，而是：

- `Chromium-only`
- 推荐 daemon + Python SDK 模式
- `corePath` 推荐直接指向 `chromium` 可执行文件
- PyPI 平台 wheel 目标为 `android_24_arm64_v8a`

## Recommended Environment

在 Termux 里准备：

```bash
pkg update
pkg install python golang chromium
```

可选：

```bash
python -m pip install --upgrade pip
```

如果你的 Python / pip 已经支持 Android wheel tag，也可以直接从 PyPI 安装 Android wheel：

```bash
python -m pip install antbrowser
```

当前 Android wheel 的发布定位是：

- API level: `24`
- ABI: `arm64-v8a`
- 主要面向 Termux 的真实手机环境

## Install from This Repository

直接运行：

```bash
bash packages/ant-browser-py/scripts/install_termux.sh
```

这个脚本会：

1. 构建 `ant-browser-daemon`
2. 把 binary 放到 `packages/ant-browser-py/src/antbrowser/bin/`
3. 以 editable 模式安装 Python 包

如果你是从 PyPI 安装 Android wheel，SDK 会在首次启动 daemon 前把 wheel 内嵌的 `ant-browser-daemon`
复制到 `workspace/runtime/bin/` 并补执行权限，然后再拉起它。

## Register Termux Chromium

```python
from antbrowser import AntBrowser

browser = AntBrowser(workspace="/data/data/com.termux/files/home/.ant-browser-workspace")
core = browser.ensure_termux_chromium_core()
print(core)
```

如果你想手工指定：

```python
browser.ensure_core(
    "/data/data/com.termux/files/usr/bin/chromium",
    core_name="Termux Chromium",
    is_default=True,
)
```

## Typical Workflow

```python
from antbrowser import AntBrowser

with AntBrowser(workspace="/data/data/com.termux/files/home/.ant-browser-workspace") as browser:
    browser.ensure_termux_chromium_core()

    created = browser.create_profile(
        {
            "profileName": "termux-demo",
            "proxyId": "__direct__",
            "fingerprintArgs": [],
            "launchArgs": [],
        },
        run_mode="headless",
    )

    profile = created["profile"]
    started = browser.start_instance(profile["agentId"], run_mode="headless")
    print(browser.page.goto(started["agentId"], "https://example.com"))
```

## Notes

- Android 默认按 `Chromium` 处理，不再假设存在 Chrome 安装目录。
- `corePath` 现在支持直接传可执行文件路径。
- 如果你在 Termux 里通过 PATH 安装了 Chromium，`GET /api/cores/discover` 通常也能发现它。

## Current Caveats

- native hooks 仅 Windows 支持
- Android 环境下某些 TLS/注入链路是否完整，还要受具体 Chromium 包构建方式影响
- 如果 Chromium 缺少某些桌面参数，建议优先用 raw API 细调启动参数
- Android wheel 当前只发布 `arm64-v8a`；`x86_64` 仍需要额外 Android NDK / cgo 交叉链路
