# Ant Browser Python / Daemon API

本文档说明两层接口：

- Python SDK：`antbrowser`
- Daemon HTTP API：`ant-browser-daemon`

## Runtime

### Python

```python
from antbrowser import AntBrowser

browser = AntBrowser(workspace="C:/tmp/ant-workspace")
info = browser.runtime.info()
```

补充说明：

- Windows / Linux / Android 平台 wheel 都可以内嵌 `ant-browser-daemon`
- 在 Linux / Android 上，SDK 会先把 wheel 内嵌 daemon 复制到 `workspace/runtime/bin/`，再补执行权限后启动

高层 builder 入口：

```python
browser.new_fingerprint()
browser.new_stealth()
browser.new_profile("shop-a")
```

### HTTP

- `GET /api/runtime/info`
- `POST /api/runtime/shutdown`

`/api/runtime/info` 返回：

- `hostMode`
- `platform`
- `arch`
- `installRoot`
- `stateRoot`
- `workspace`
- `capabilities`

## Cores

### Python

```python
browser.cores.list()
browser.cores.discover()
browser.cores.validate("C:/Program Files/Google/Chrome/Application")
browser.ensure_core("C:/Program Files/Google/Chrome/Application", core_name="Local Chrome", is_default=True)
```

### HTTP

- `GET /api/cores`
- `POST /api/cores`
- `GET /api/cores/{coreId}`
- `DELETE /api/cores/{coreId}`
- `POST /api/cores/{coreId}/default`
- `POST /api/cores/validate`
- `GET /api/cores/extended-info`
- `POST /api/cores/scan`
- `GET /api/cores/discover`

`POST /api/cores` 请求体：

```json
{
  "coreId": "",
  "coreName": "Local Chrome",
  "corePath": "C:/Program Files/Google/Chrome/Application",
  "isDefault": true
}
```

`POST /api/cores/validate` 请求体：

```json
{
  "corePath": "C:/Program Files/Google/Chrome/Application"
}
```

说明：

- `corePath` 既可以是目录，也可以直接是浏览器可执行文件路径。
- Android/Termux 推荐传 `chromium` 可执行文件路径。
- Android PyPI wheel 当前按 `android_24_arm64_v8a` 发布。

## Proxies

### Python

```python
browser.proxies.list()
browser.proxies.groups()
browser.proxies.validate(proxy_config="http://127.0.0.1:7890")
browser.save_proxy({
    "proxyName": "Local Proxy",
    "proxyConfig": "http://127.0.0.1:7890",
    "groupName": "local"
})
```

### HTTP

- `GET /api/proxies`
- `POST /api/proxies`
- `PUT /api/proxies`
- `GET /api/proxies/groups`
- `GET /api/proxies/{proxyId}`
- `PUT /api/proxies/{proxyId}`
- `DELETE /api/proxies/{proxyId}`
- `POST /api/proxies/validate`
- `POST /api/proxies/fetch-clash`
- `POST /api/proxies/{proxyId}/test-speed`
- `POST /api/proxies/{proxyId}/check-ip-health`

`PUT /api/proxies` 用于整表替换：

```json
{
  "items": [
    {
      "proxyId": "proxy-a",
      "proxyName": "Proxy A",
      "proxyConfig": "http://127.0.0.1:8080",
      "groupName": "default"
    }
  ]
}
```

`POST /api/proxies/validate` 请求体：

```json
{
  "proxyId": "",
  "proxyConfig": "http://127.0.0.1:7890"
}
```

`POST /api/proxies/fetch-clash` 请求体：

```json
{
  "url": "https://example.com/subscription.yaml"
}
```

说明：

- `test-speed` 和 `check-ip-health` 返回顶层 `ok=true`，真实结果在 `result` 字段里。
- 内置代理 `__direct__` / `__local__` 不允许删除。

## Profiles / Instances / Page

这些能力继续沿用已有 daemon API；Python SDK 已封装：

- `browser.profiles.*`
- `browser.instances.*`
- `browser.page.*`
- `browser.network.*`
- `browser.inspect.*`
- `browser.tls.*`
- `browser.stealth.*`

## High-Level Builders

### `FingerprintBuilder`

```python
fingerprint = (
    browser.new_fingerprint()
    .platform("windows")
    .locale("en-US", "America/New_York")
    .resolution(1920, 1080)
    .hardware(
        hardware_concurrency=8,
        device_memory=16,
        webgl_vendor="Intel",
        webgl_renderer="Intel Iris Xe",
    )
    .noise(canvas_noise=True, audio_noise=True, do_not_track=True)
)

args = fingerprint.build_args()
```

### `StealthBuilder`

```python
stealth = (
    browser.new_stealth()
    .strict()
    .hardware(hardware_concurrency=8, device_memory=16)
    .poison(
        canvas_mode="session_stable",
        webgl_mode="session_stable",
        audio_mode="session_stable",
        seed_mode="instance_stable",
    )
)

config = stealth.build()
```

### `ProfileBuilder`

```python
result = (
    browser.new_profile("buyer-a")
    .core("core-local-chrome")
    .proxy(proxy_id="__direct__")
    .hardware(
        hardware_concurrency=8,
        device_memory=16,
        webgl_vendor="Intel",
        webgl_renderer="Intel Iris Xe",
    )
    .anti_detect("strict")
    .create(auto_launch=True, run_mode="headless")
)
```

随机环境：

```python
result = (
    browser.new_profile("buyer-random")
    .random_environment(name_prefix="Buyer Random")
    .hardware(hardware_concurrency=8, device_memory=16)
    .anti_detect("strict")
    .create(auto_launch=True, run_mode="headless")
)
```

说明：

- `random_environment()` 先走 daemon 内建随机指纹，再叠加 builder 里的硬件/防检测覆盖。
- `.hardware()` 默认会同时覆盖 fingerprint args 和 stealth config，减少环境不一致。
- `.anti_detect("strict")` 会启用更强的自动化痕迹抹除和稳定投毒。

## Termux Convenience

如果你在 Termux 里安装了 Chromium：

```python
from antbrowser import AntBrowser

browser = AntBrowser(workspace="/data/data/com.termux/files/home/.ant-browser-workspace")
core = browser.ensure_termux_chromium_core()
print(core)
```

如果你的环境支持 Android wheel tag，也可以直接：

```bash
python -m pip install antbrowser
```
