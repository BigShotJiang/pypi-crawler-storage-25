# Ant Browser Python SDK Tutorial

## 1. What You Get

这个交付物包含三层：

1. `ant-browser-daemon`
2. `antbrowser` Python SDK
3. 平台 bundle / Termux 安装脚本

推荐思路：

- Win/Linux：优先使用 bundle 中打好的 daemon
- 源码联调：直接让 SDK 回退到 `go run ./cmd/ant-browser-daemon`
- Termux：用 `install_termux.sh`

## 2. Quick Start on Windows / Linux

### Step 1: 准备一个 workspace

workspace 会保存：

- `config.yaml`
- `data/app.db`
- `runtime/daemon.json`

例如：

- Windows: `C:\tmp\ant-workspace`
- Linux: `/tmp/ant-workspace`

### Step 2: 写一个最小脚本

```python
from antbrowser import AntBrowser

with AntBrowser(workspace="C:/tmp/ant-workspace") as browser:
    print(browser.runtime.info())
```

### Step 3: 注册本机 Chrome / Chromium 内核

```python
from antbrowser import AntBrowser

with AntBrowser(workspace="C:/tmp/ant-workspace") as browser:
    for item in browser.discover_system_cores():
        print(item)
```

如果自动发现不到：

```python
with AntBrowser(workspace="C:/tmp/ant-workspace") as browser:
    browser.ensure_core(
        "C:/Program Files/Google/Chrome/Application",
        core_name="Local Chrome",
        is_default=True,
    )
```

Linux 也可以直接传可执行文件：

```python
browser.ensure_core("/usr/bin/chromium", core_name="System Chromium", is_default=True)
```

## 3. 创建实例并无头打开页面

```python
from antbrowser import AntBrowser

with AntBrowser(workspace="C:/tmp/ant-workspace") as browser:
    profile_resp = browser.create_profile(
        {
            "profileName": "demo-headless",
            "coreId": "",
            "fingerprintArgs": [],
            "launchArgs": [],
            "proxyId": "__direct__",
        },
        run_mode="headless",
    )

    profile = profile_resp["profile"]
    agent_resp = browser.start_instance(profile["agentId"], run_mode="headless")
    browser.page.goto(agent_resp["agentId"], "https://example.com")
    print(browser.page.eval(agent_resp["agentId"], "document.title"))
```

## 3.1 使用更高层的 builder 风格

```python
from antbrowser import AntBrowser

with AntBrowser(workspace="C:/tmp/ant-workspace") as browser:
    result = (
        browser.new_profile("buyer-random")
        .random_environment(name_prefix="Buyer Random")
        .hardware(
            hardware_concurrency=8,
            device_memory=16,
            webgl_vendor="Intel",
            webgl_renderer="Intel Iris Xe",
        )
        .anti_detect("strict")
        .create(auto_launch=True, run_mode="headless")
    )

    agent_id = result["agentId"]
    browser.page.goto(agent_id, "https://example.com")
    print(browser.page.eval(agent_id, "document.title"))
```

这个写法更适合后续脚本化：

- `random_environment()`：随机实例环境
- `hardware()`：硬件参数
- `anti_detect()`：防检测预设
- `poison()`：稳定投毒

## 4. 管理代理池

```python
from antbrowser import AntBrowser

with AntBrowser(workspace="C:/tmp/ant-workspace") as browser:
    browser.save_proxy(
        {
            "proxyName": "Local Proxy",
            "proxyConfig": "http://127.0.0.1:7890",
            "groupName": "local",
        }
    )

    print(browser.proxies.list())
    print(browser.proxies.validate(proxy_config="http://127.0.0.1:7890"))
```

导入 Clash 订阅预览：

```python
preview = browser.import_clash_subscription("https://example.com/subscription.yaml")
print(preview)
```

## 5. 打包平台 bundle

在仓库根目录执行：

```powershell
python packages/ant-browser-py/scripts/build_bundle.py --target windows-amd64
python packages/ant-browser-py/scripts/build_bundle.py --target linux-amd64
python packages/ant-browser-py/scripts/build_bundle.py --target android-arm64
```

产物会输出到：

`publish/output/python-sdk/<target>/`

## 5.1 构建可上传 PyPI 的平台 wheel

```powershell
python packages/ant-browser-py/scripts/build_pypi_artifacts.py
```

输出到：

`packages/ant-browser-py/dist/`

当前会生成：

- Windows 内嵌 daemon wheel
- Linux x86_64 内嵌 daemon wheel
- Linux aarch64 内嵌 daemon wheel
- Android arm64-v8a 内嵌 daemon wheel
- 一个 source distribution

Android wheel 目前默认：

- tag: `android_24_arm64_v8a`
- 目标环境：Termux / Android arm64-v8a
- 发布基线：Android 7.0+ / API 24

## 6. 运行真实验收

```powershell
$env:PYTHONPATH="C:\Users\19917\Desktop\Ant-Browser-master\packages\ant-browser-py\src"
python packages/ant-browser-py/scripts/validate_sdk.py
```

默认会：

- 自动拉起 daemon
- 尝试注册本机 Chrome / Chromium
- 真实验证 `runtime / cores / proxies / profiles / instances / lease / stealth / page / targets / storage / console / downloads / network / inspect / expose / tasks / tls`
- 生成 `docs/VALIDATION_REPORT.md`

如果你还想在发布前检查 Android wheel 本身的 tag 和内嵌 daemon 结构：

```powershell
python packages/ant-browser-py/scripts/validate_android_artifacts.py
```

这会额外生成：

- `docs/ANDROID_RELEASE_REPORT.md`

如果你想把“真实验收 + 构建平台 wheel + twine check”一次跑完：

```powershell
python packages/ant-browser-py/scripts/release_prep.py
```

## 7. What Is Still Platform-Specific

- Windows 才支持 native hooks
- Linux / Android 更推荐 Chromium
- Android/Termux 视为 `Chromium-only`
- Android wheel 当前只发 `arm64-v8a`
- Python SDK 是同步 API，便于脚本与批处理使用
