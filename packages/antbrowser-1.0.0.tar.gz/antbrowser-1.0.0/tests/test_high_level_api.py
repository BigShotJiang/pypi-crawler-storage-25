"""Tests for the higher-level Playwright-style Python helpers."""

import pathlib
import sys

import unittest

SRC_DIR = pathlib.Path(__file__).resolve().parents[1] / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from antbrowser import FingerprintBuilder, ProfileBuilder, StealthBuilder


class _FakeProfilesAPI:
    def __init__(self) -> None:
        self.updated = []
        self.created = []

    def create(self, profile, **kwargs):
        self.created.append((profile, kwargs))
        return {"ok": True, "profile": profile, "kwargs": kwargs}

    def update(self, profile_id, profile, **kwargs):
        self.updated.append((profile_id, profile, kwargs))
        return {"ok": True, "profileId": profile_id, "profile": profile, "kwargs": kwargs}


class _FakeInstancesAPI:
    def __init__(self) -> None:
        self.random_payloads = []
        self.get_calls = []

    def create_random(self, payload):
        self.random_payloads.append(payload)
        return {
            "ok": True,
            "agentId": "agent-random",
            "profileId": "profile-random",
            "instance": {
                "agentId": "agent-random",
                "profileId": "profile-random",
                "fingerprintArgs": [
                    "--fingerprint=12345",
                    "--fingerprint-platform=windows",
                    "--fingerprint-hardware-concurrency=4",
                    "--fingerprint-device-memory=8",
                ],
                "profile": {
                    "profileId": "profile-random",
                    "profileName": "AI Random agent-random",
                    "userDataDir": "",
                    "coreId": "",
                    "fingerprintArgs": [
                        "--fingerprint=12345",
                        "--fingerprint-platform=windows",
                        "--fingerprint-hardware-concurrency=4",
                        "--fingerprint-device-memory=8",
                    ],
                    "proxyId": "",
                    "proxyConfig": "",
                    "launchArgs": [],
                    "tags": [],
                    "keywords": [],
                    "groupId": "",
                    "stealthEnabled": False,
                    "stealthConfig": {},
                },
            },
        }

    def get(self, agent_id):
        self.get_calls.append(agent_id)
        return {
            "ok": True,
            "instance": {
                "agentId": agent_id,
                "profileId": "profile-random",
                "fingerprintArgs": [
                    "--fingerprint=12345",
                    "--fingerprint-platform=windows",
                    "--fingerprint-hardware-concurrency=8",
                    "--fingerprint-device-memory=16",
                ],
            },
        }


class _FakeBrowser:
    def __init__(self):
        self.profiles = _FakeProfilesAPI()
        self.instances = _FakeInstancesAPI()
        self.start_calls = []

    def _build_start_payload(self, **kwargs):
        return {"startPayload": kwargs}

    def start_instance(self, agent_id, **kwargs):
        self.start_calls.append((agent_id, kwargs))
        return {"ok": True, "agentId": agent_id, "kwargs": kwargs}

    @staticmethod
    def _normalize_profile_for_write(profile):
        allowed = {
            "profileName",
            "userDataDir",
            "coreId",
            "fingerprintArgs",
            "stealthEnabled",
            "stealthConfig",
            "proxyId",
            "proxyConfig",
            "launchArgs",
            "tags",
            "keywords",
            "groupId",
        }
        return {key: value for key, value in profile.items() if key in allowed}


class HighLevelBuilderTest(unittest.TestCase):
    def test_fingerprint_builder_builds_expected_args(self):
        args = (
            FingerprintBuilder()
            .platform("windows")
            .locale("en-US", "America/New_York")
            .resolution(1920, 1080)
            .hardware(hardware_concurrency=8, device_memory=16, webgl_vendor="Intel")
            .noise(canvas_noise=True, audio_noise=False, do_not_track=True)
            .build_args()
        )

        self.assertIn("--fingerprint-platform=windows", args)
        self.assertIn("--lang=en-US", args)
        self.assertIn("--timezone=America/New_York", args)
        self.assertIn("--window-size=1920,1080", args)
        self.assertIn("--fingerprint-hardware-concurrency=8", args)
        self.assertIn("--fingerprint-device-memory=16", args)
        self.assertIn("--fingerprint-canvas-noise=true", args)

    def test_stealth_builder_strict_emits_poison_and_masks(self):
        config = StealthBuilder().strict().hardware(hardware_concurrency=8, device_memory=16).build()

        self.assertTrue(config["maskPermissions"])
        self.assertEqual(config["hardwareConcurrency"], "8")
        self.assertEqual(config["deviceMemory"], "16")
        self.assertEqual(config["fingerprintPoison"]["canvasMode"], "session_stable")
        self.assertTrue(config["automationMask"]["chromeRuntimeShim"])

    def test_profile_builder_random_environment_applies_overrides_before_start(self):
        fake = _FakeBrowser()
        response = (
            ProfileBuilder(fake, "demo")
            .random_environment(name_prefix="Demo")
            .hardware(hardware_concurrency=8, device_memory=16)
            .anti_detect("strict")
            .create(auto_launch=True, run_mode="headless")
        )

        self.assertEqual(fake.instances.random_payloads[0]["namePrefix"], "Demo")
        self.assertEqual(fake.profiles.updated[0][0], "profile-random")
        updated_profile = fake.profiles.updated[0][1]
        self.assertIn("--fingerprint-hardware-concurrency=8", updated_profile["fingerprintArgs"])
        self.assertTrue(updated_profile["stealthEnabled"])
        self.assertEqual(updated_profile["stealthConfig"]["fingerprintPoison"]["seedMode"], "instance_stable")
        self.assertEqual(fake.start_calls[0][0], "agent-random")
        self.assertIn("instance", response)


if __name__ == "__main__":
    unittest.main()
