"""Tests for Android release artifact helpers."""

from __future__ import annotations

import pathlib
import sys
import tempfile
import unittest
import zipfile


SCRIPT_DIR = pathlib.Path(__file__).resolve().parents[1] / "scripts"
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from validate_android_artifacts import validate_android_wheel  # noqa: E402


class AndroidReleaseValidationTest(unittest.TestCase):
    """Keep the Android artifact validator covered with a tiny synthetic wheel."""

    def test_validate_android_wheel_accepts_embedded_arm64_daemon(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            wheel_path = pathlib.Path(temp_dir) / "antbrowser-1.0.0-py3-none-android_24_arm64_v8a.whl"
            with zipfile.ZipFile(wheel_path, "w") as archive:
                archive.writestr("antbrowser/bin/ant-browser-daemon", self.make_aarch64_elf_header())

            records = list(validate_android_wheel(wheel_path, api_level=24, abi="arm64-v8a"))
            failed = [record for record in records if record.status != "PASS"]
            self.assertEqual([], failed)

    def test_validate_android_wheel_accepts_data_purelib_layout(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            wheel_path = pathlib.Path(temp_dir) / "antbrowser-1.0.0-py3-none-android_24_arm64_v8a.whl"
            with zipfile.ZipFile(wheel_path, "w") as archive:
                archive.writestr(
                    "antbrowser-1.0.0.data/purelib/antbrowser/bin/ant-browser-daemon",
                    self.make_aarch64_elf_header(),
                )

            records = list(validate_android_wheel(wheel_path, api_level=24, abi="arm64-v8a"))
            failed = [record for record in records if record.status != "PASS"]
            self.assertEqual([], failed)

    @staticmethod
    def make_aarch64_elf_header() -> bytes:
        """Create the smallest possible ELF64 little-endian AArch64 header for validator tests."""

        header = bytearray(64)
        header[:4] = b"\x7fELF"
        header[4] = 2
        header[5] = 1
        header[18] = 0xB7
        header[19] = 0x00
        return bytes(header)


if __name__ == "__main__":
    unittest.main()
