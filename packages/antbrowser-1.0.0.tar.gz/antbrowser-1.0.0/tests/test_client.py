"""Small smoke tests for the Python SDK helper logic."""

import pathlib
import sys
import tempfile
import unittest
from unittest import mock

SRC_DIR = pathlib.Path(__file__).resolve().parents[1] / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from antbrowser.client import AntBrowser
from antbrowser.daemon import DaemonManager, DaemonMetadata


class ClientHelpersTest(unittest.TestCase):
    """Keep a couple of pure-Python helpers covered without requiring a live daemon."""

    def test_build_start_payload_defaults_to_skip_default_urls_in_headless_mode(self) -> None:
        payload = AntBrowser._build_start_payload(
            run_mode="headless",
            launch_args=None,
            start_urls=None,
            skip_default_start_urls=None,
        )
        self.assertEqual(payload["runMode"], "headless")
        self.assertTrue(payload["skipDefaultStartURLs"])

    def test_daemon_metadata_from_payload_normalizes_fields(self) -> None:
        metadata = DaemonMetadata.from_payload(
            {
                "pid": 123,
                "baseUrl": "http://127.0.0.1:19876",
                "apiKey": "secret",
                "apiHeader": "X-Ant-Api-Key",
                "version": "1.2.3",
                "workspace": "/tmp/ant",
                "startedAt": "2026-04-09T00:00:00Z",
                "hostMode": "daemon",
            }
        )
        self.assertEqual(metadata.pid, 123)
        self.assertEqual(metadata.host_mode, "daemon")

    def test_packaged_daemon_is_materialized_into_workspace_on_posix(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = pathlib.Path(temp_dir) / "workspace"
            package_bin = pathlib.Path(temp_dir) / "package-bin"
            package_bin.mkdir(parents=True, exist_ok=True)
            source_path = package_bin / "ant-browser-daemon"
            source_path.write_bytes(b"daemon-binary")

            manager = DaemonManager(workspace=str(workspace), auto_start=False)
            prepared = pathlib.Path(manager._materialize_packaged_daemon_binary(source_path))

            self.assertNotEqual(prepared, source_path)
            self.assertTrue(prepared.exists())
            self.assertEqual(prepared.read_bytes(), b"daemon-binary")
            self.assertEqual(prepared.parent, workspace / "runtime" / "bin")

    def test_cleanup_unhealthy_daemon_terminates_matching_process_after_failed_shutdown(self) -> None:
        manager = DaemonManager(workspace="C:/tmp/antbrowser-test", auto_start=False)
        metadata = DaemonMetadata(
            pid=456,
            base_url="http://127.0.0.1:19876",
            api_key="secret",
            api_header="X-Ant-Api-Key",
            version="1.0.0",
            workspace="C:/tmp/antbrowser-test",
            started_at="2026-04-10T00:00:00Z",
            host_mode="daemon",
        )

        with (
            mock.patch.object(manager, "_process_exists", return_value=True),
            mock.patch.object(manager, "_request_shutdown", return_value=False),
            mock.patch.object(manager, "_process_looks_like_ant_browser_daemon", return_value=True),
            mock.patch.object(manager, "_terminate_process") as terminate,
            mock.patch.object(manager, "_wait_for_process_exit", return_value=True) as wait_exit,
        ):
            manager._cleanup_unhealthy_daemon(metadata)

        terminate.assert_called_once_with(456)
        wait_exit.assert_called_once_with(456, timeout=5.0)

    def test_daemon_start_failure_reports_child_stderr(self) -> None:
        process = mock.Mock()
        process.returncode = 23
        process.stderr.read.return_value = "workspace is already in use"

        message = DaemonManager._daemon_start_failure(process)

        self.assertIn("exit_code=23", message)
        self.assertIn("workspace is already in use", message)


if __name__ == "__main__":
    unittest.main()
