"""
Work Assistant MCP Server

프로세스 조회, 회사 정보 질의, 프로세스 실행을 위한 MCP 도구 모음.
Agent가 사용자 요청을 분석하고 필요한 도구를 선택해서 호출합니다. 

보안 모델:
- service_role_key를 사용하지 않음
- 사용자의 JWT를 그대로 사용하여 Supabase에 접근
- RLS 정책이 사용자의 tenant_id를 검증하여 데이터 접근 제어

사용자 요청 유형별 처리 흐름:
1. 문서 업로드 + 프로세스 생성/추출 요청 → create_pdf2bpmn_workitem 도구 호출 (파일 형식 무관)
2. 문서 없이 프로세스 생성 요청 → start_process_consulting 도구 호출 (확정 시 generate_process)
3. 문서가 있어도 컨설팅 요청이면 → start_process_consulting 도구 호출 (확정 시 generate_process)
4. 문서 업로드 + 표/정리/테이블/요약/설명/마크다운 요청 → pdf2markdown 도구 호출
5. 프로세스 실행 요청 → get_process_list → get_process_detail → get_form_fields → execute_process
6. 질문/조회 요청 → get_process_list → get_instance_list → get_todolist 또는 get_organization
"""

import asyncio
import base64
import io
import os
import json
import re
import time
import traceback
import uuid
import logging
import threading
import httpx
from pathlib import Path
from contextlib import contextmanager
from typing import Optional, List, Dict, Any
from fastmcp import FastMCP

# 파일 로깅 설정 (즉시 flush)
log_file = os.path.join(os.path.dirname(__file__), 'mcp_debug.log')

# 핸들러에 즉시 flush 설정
file_handler = logging.FileHandler(log_file, encoding='utf-8')
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(file_handler)

# Supabase 설정 (환경변수는 mcp_config.json의 env에서 전달됨)
SUPABASE_URL = os.getenv("SUPABASE_URL", "")
# 변경: service_role_key 대신 anon_key 사용 (RLS가 적용됨)
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY", "")

# 기본 인증 정보 (환경변수에서 읽어옴 - mcp.json의 env에서 설정 가능)
# 환경변수에 설정되어 있으면 파라미터보다 우선 사용됨
ENV_USER_JWT = os.getenv("user_jwt", "")
ENV_TENANT_ID = os.getenv("tenant_id", "")
ENV_USER_EMAIL = os.getenv("user_email", "")  # 현재 사용자 이메일 (Cursor 등 외부 MCP 클라이언트용)


def get_effective_credentials(user_jwt: Optional[str] = None, tenant_id: Optional[str] = None) -> tuple[str, str]:
    """
    환경변수 우선, 없으면 파라미터 사용.
    - MCP 클라이언트가 None을 전달해도 안전하게 처리합니다.
    """
    param_jwt = user_jwt or ""
    param_tenant = tenant_id or ""
    effective_jwt = ENV_USER_JWT if ENV_USER_JWT else param_jwt
    effective_tenant = ENV_TENANT_ID if ENV_TENANT_ID else param_tenant
    return effective_jwt, effective_tenant

# 백엔드 API 설정 (프로세스 실행용)
# API_BASE_URL은 tenant_id를 기반으로 동적 생성: https://{tenant_id}.process-gpt.io
def get_api_base_url(tenant_id: str) -> str:
    """테넌트 ID를 기반으로 API Base URL을 동적으로 생성"""
    return f"https://{tenant_id}.process-gpt.io"


DEFAULT_OPENAI_BASE_URL = "https://api.openai.com/v1"
TEXT_FILE_EXTENSIONS = {
    ".txt", ".md", ".csv", ".json", ".log", ".yaml", ".yml", ".xml", ".html", ".htm",
    ".py", ".js", ".ts", ".tsx", ".jsx", ".sql", ".ini", ".cfg"
}


def _get_markdown_base_url() -> str:
    return (os.getenv("OCR_BASE_URL") or os.getenv("LLM_BASE_URL") or DEFAULT_OPENAI_BASE_URL).strip()


def _get_markdown_model() -> str:
    model = (os.getenv("OCR_MODEL") or os.getenv("LLM_MODEL") or "").strip()
    if not model:
        raise ValueError("OCR_MODEL 또는 LLM_MODEL 환경 변수가 필요합니다.")
    return model


def _get_bool_env(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _get_int_env(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None or not value.strip():
        return default
    try:
        return int(value)
    except Exception:
        return default


def _get_float_env(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None or not value.strip():
        return default
    try:
        return float(value)
    except Exception:
        return default


def _is_ocr_enabled() -> bool:
    return _get_bool_env("ENABLE_OCR", True)


def _ocr_always_if_images() -> bool:
    return _get_bool_env("OCR_ALWAYS_IF_IMAGES", True)


def _get_ocr_engine() -> str:
    return (os.getenv("OCR_ENGINE") or "tesseract").strip().lower()


def _get_ocr_dpi() -> int:
    return max(72, _get_int_env("OCR_DPI", 200))


def _get_ocr_max_image_pixels() -> int:
    return max(512 * 512, _get_int_env("OCR_MAX_IMAGE_PIXELS", 2000 * 2000))


def _get_synap_ocr_base_url() -> str:
    return (os.getenv("SYNAP_OCR_BASE_URL") or "").strip().rstrip("/")


def _get_synap_ocr_api_key() -> str:
    return (os.getenv("SYNAP_OCR_API_KEY") or "").strip()


def _get_synap_ocr_poll_interval_sec() -> float:
    return max(0.2, _get_float_env("SYNAP_OCR_POLL_INTERVAL_SEC", 1.0))


def _get_synap_ocr_timeout_sec() -> float:
    return max(5.0, _get_float_env("SYNAP_OCR_TIMEOUT_SEC", 120.0))


MAX_SANDBOX_OUTPUT = max(2000, _get_int_env("EXECUTE_PYTHON_MAX_OUTPUT", 10000))
SANDBOX_TIMEOUT_SEC = max(1, _get_int_env("EXECUTE_PYTHON_TIMEOUT_SEC", 300))
MAX_SANDBOX_CODE_CHARS = max(4000, _get_int_env("EXECUTE_PYTHON_MAX_CODE_CHARS", 500000))
_MUPDF_LOG_SUPPRESSED = False
_STDOUT_REDIRECT_LOCK = threading.Lock()


@contextmanager
def _redirect_c_stdout_to_stderr():
    """
    C extension(MuPDF 등)이 fd=1(stdout)에 직접 쓰는 로그를 fd=2(stderr)로 우회한다.
    stdio JSON-RPC는 stdout을 프로토콜 채널로 사용하므로, 비JSON 출력이 섞이지 않게 보호한다.
    """
    with _STDOUT_REDIRECT_LOCK:
        saved_stdout_fd = None
        try:
            try:
                os.sys.stdout.flush()
            except Exception:
                pass
            try:
                os.sys.stderr.flush()
            except Exception:
                pass

            try:
                saved_stdout_fd = os.dup(1)
                os.dup2(2, 1)
            except Exception:
                saved_stdout_fd = None

            yield
        finally:
            if saved_stdout_fd is not None:
                try:
                    os.dup2(saved_stdout_fd, 1)
                except Exception:
                    pass
                try:
                    os.close(saved_stdout_fd)
                except Exception:
                    pass


def _suppress_mupdf_logging(fitz_module: Any) -> None:
    """
    MuPDF C 라이브러리 경고가 stdout/stderr로 쏟아져 stdio JSON-RPC를 오염시키는 것을 방지한다.
    사용 가능한 API가 환경마다 다를 수 있어 방어적으로 시도한다.
    """
    global _MUPDF_LOG_SUPPRESSED
    if _MUPDF_LOG_SUPPRESSED:
        return
    tools = getattr(fitz_module, "TOOLS", None)
    if tools is None:
        return

    for name in ("mupdf_display_errors", "mupdf_display_warnings"):
        fn = getattr(tools, name, None)
        if not callable(fn):
            continue
        try:
            fn(False)
        except TypeError:
            try:
                fn(0)
            except Exception:
                continue
        except Exception:
            continue
    _MUPDF_LOG_SUPPRESSED = True


def _build_openai_compatible_headers(api_key: str) -> Dict[str, str]:
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    site_url = (os.getenv("LLM_SITE_URL") or "").strip()
    app_name = (os.getenv("LLM_APP_NAME") or "").strip()
    if site_url:
        headers["HTTP-Referer"] = site_url
    if app_name:
        headers["X-Title"] = app_name
    return headers


def _is_pdf_file(file_name: str, file_type: Optional[str]) -> bool:
    name = (file_name or "").lower()
    mime = (file_type or "").lower()
    return name.endswith(".pdf") or mime == "application/pdf" or mime.endswith("/pdf")


def _is_direct_text_file(file_name: str, file_type: Optional[str]) -> bool:
    name = (file_name or "").lower()
    mime = (file_type or "").lower()
    return mime.startswith("text/") or any(name.endswith(ext) for ext in TEXT_FILE_EXTENSIONS)


def _normalize_uploaded_files(
    *,
    file_url: Optional[str],
    file_name: Optional[str],
    file_path: Optional[str] = None,
    file_id: Optional[str] = None,
    file_type: Optional[str] = None,
    file_size: Optional[Any] = None,
    files: Optional[Any] = None,
) -> List[Dict[str, Any]]:
    def _build_file_entry(
        *,
        item_url: Optional[str],
        item_name: Optional[str],
        item_path: Optional[str] = None,
        item_id: Optional[str] = None,
        item_type: Optional[str] = None,
        item_size: Optional[Any] = None,
    ) -> Optional[Dict[str, Any]]:
        if not item_url or not item_name:
            return None

        effective_path = item_path
        if not effective_path:
            if "/files/" in item_url:
                effective_path = item_url.split("/files/")[-1]
            else:
                effective_path = item_url.split("/")[-1]

        generated_id = item_id if item_id else generate_uuid()
        return {
            "id": generated_id,
            "path": effective_path,
            "fullPath": item_url,
            "publicUrl": item_url,
            "fileUrl": item_url,
            "originalFileName": item_name,
            "fileName": item_name,
            "fileType": item_type,
            "fileSize": item_size,
        }

    parsed_files_input: List[Dict[str, Any]] = []
    if isinstance(files, list):
        parsed_files_input = [f for f in files if isinstance(f, dict)]
    elif isinstance(files, str):
        try:
            parsed = json.loads(files)
            if isinstance(parsed, list):
                parsed_files_input = [f for f in parsed if isinstance(f, dict)]
            elif isinstance(parsed, dict):
                parsed_files_input = [parsed]
        except Exception:
            logger.warning("[normalize_uploaded_files] files 문자열 JSON 파싱 실패")
    elif isinstance(files, dict):
        parsed_files_input = [files]

    normalized_files: List[Dict[str, Any]] = []
    primary = _build_file_entry(
        item_url=file_url,
        item_name=file_name,
        item_path=file_path,
        item_id=file_id,
        item_type=file_type,
        item_size=file_size,
    )
    if primary:
        normalized_files.append(primary)

    for item in parsed_files_input:
        item_url = item.get("publicUrl") or item.get("fileUrl") or item.get("fullPath") or item.get("url")
        item_name = item.get("originalFileName") or item.get("fileName") or item.get("name")
        file_entry = _build_file_entry(
            item_url=item_url,
            item_name=item_name,
            item_path=item.get("path"),
            item_id=item.get("id"),
            item_type=item.get("fileType"),
            item_size=item.get("fileSize"),
        )
        if file_entry:
            normalized_files.append(file_entry)

    deduped_files: List[Dict[str, Any]] = []
    seen_keys = set()
    for item in normalized_files:
        key = (item.get("publicUrl"), item.get("fileName"))
        if key in seen_keys:
            continue
        seen_keys.add(key)
        deduped_files.append(item)

    return deduped_files


async def _download_file_bytes(file_url: str) -> bytes:
    async with httpx.AsyncClient(timeout=60.0, follow_redirects=True, verify=False) as client:
        response = await client.get(file_url)
        response.raise_for_status()
        return response.content


def _merge_text_lines(base_text: str, extra_text: str) -> str:
    base_lines = [line.strip() for line in (base_text or "").splitlines() if line.strip()]
    extra_lines = [line.strip() for line in (extra_text or "").splitlines() if line.strip()]
    if not extra_lines:
        return (base_text or "").strip()

    seen = set(base_lines)
    merged = list(base_lines)
    for line in extra_lines:
        if line not in seen:
            merged.append(line)
            seen.add(line)
    return "\n".join(merged).strip()


def _page_has_images(page: Any) -> bool:
    try:
        return bool(getattr(page, "images", None)) and len(page.images) > 0
    except Exception:
        return False


async def _wait_for_synap_completion(
    *,
    base_url: str,
    api_key: str,
    fid: str,
    timeout_sec: float,
    poll_interval_sec: float,
) -> Dict[str, Any]:
    deadline = time.time() + timeout_sec
    last_payload: Dict[str, Any] = {}

    async with httpx.AsyncClient(timeout=timeout_sec) as client:
        while time.time() < deadline:
            response = await client.post(
                f"{base_url}/filestatus/{fid}",
                json={"api_key": api_key},
            )
            response.raise_for_status()
            payload = response.json()
            last_payload = payload if isinstance(payload, dict) else {}
            result = last_payload.get("result") or {}
            status = str(result.get("filestatus") or "").upper()

            if status == "SUCCESS":
                return result
            if status and status not in {"RUNNING", "QUEUED", "PENDING"}:
                raise RuntimeError(f"Synap OCR failed with status={status}: {payload}")

            await asyncio.sleep(poll_interval_sec)

    raise TimeoutError(f"Timed out waiting for Synap OCR completion: {last_payload}")


async def _extract_text_with_synap(file_name: str, file_bytes: bytes, page_count: int) -> Dict[int, str]:
    base_url = _get_synap_ocr_base_url()
    api_key = _get_synap_ocr_api_key()
    if not base_url or not api_key:
        logger.warning("[pdf2markdown] Synap OCR is enabled but SYNAP_OCR_BASE_URL or SYNAP_OCR_API_KEY is missing.")
        return {}

    timeout_sec = _get_synap_ocr_timeout_sec()
    poll_interval_sec = _get_synap_ocr_poll_interval_sec()
    fid: Optional[str] = None
    try:
        async with httpx.AsyncClient(timeout=timeout_sec) as client:
            upload_response = await client.post(
                f"{base_url}/da",
                data={"api_key": api_key, "type": "upload"},
                files={"file": (file_name, file_bytes, "application/octet-stream")},
            )
            upload_response.raise_for_status()
            upload_body = upload_response.json()
            fid = str(((upload_body.get("result") or {}).get("fid") or "")).strip()
            if not fid:
                raise ValueError(f"Synap upload response missing fid: {upload_body}")

            status_result = await _wait_for_synap_completion(
                base_url=base_url,
                api_key=api_key,
                fid=fid,
                timeout_sec=timeout_sec,
                poll_interval_sec=poll_interval_sec,
            )
            total_pages = int((status_result or {}).get("total_pages") or page_count or 0)
            result_pages = total_pages or page_count
            texts: Dict[int, str] = {}

            for page_index in range(1, result_pages + 1):
                page_response = await client.post(
                    f"{base_url}/result/{fid}",
                    headers={"Content-Type": "application/json"},
                    json={"api_key": api_key, "page_index": page_index, "type": "text"},
                )
                page_response.raise_for_status()
                page_text = (page_response.text or "").strip()
                if page_text:
                    texts[page_index] = page_text
            return texts
    except Exception as exc:
        logger.warning(f"[pdf2markdown] Synap OCR failed, falling back to page OCR path: {exc}")
        return {}
    finally:
        if fid:
            try:
                async with httpx.AsyncClient(timeout=timeout_sec) as client:
                    await client.post(f"{base_url}/delete/{fid}", json={"api_key": api_key})
            except Exception:
                pass


def _render_pdf_page_image(file_bytes: bytes, page_index: int):
    image = None

    try:
        with _redirect_c_stdout_to_stderr():
            import fitz  # type: ignore
            from PIL import Image  # type: ignore
            _suppress_mupdf_logging(fitz)

            with fitz.open(stream=file_bytes, filetype="pdf") as doc:
                if page_index < 0 or page_index >= doc.page_count:
                    return None
                page = doc.load_page(page_index)
                zoom = max(1.0, _get_ocr_dpi() / 72.0)
                mat = fitz.Matrix(zoom, zoom)
                pix = page.get_pixmap(matrix=mat, alpha=False)
                if pix.width * pix.height > _get_ocr_max_image_pixels():
                    scale = (_get_ocr_max_image_pixels() / float(pix.width * pix.height)) ** 0.5
                    mat = fitz.Matrix(zoom * scale, zoom * scale)
                    pix = page.get_pixmap(matrix=mat, alpha=False)
                image = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
    except Exception:
        image = None

    if image is not None:
        return image

    try:
        from PIL import Image  # type: ignore
        import pdfplumber

        with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
            if page_index < 0 or page_index >= len(pdf.pages):
                return None
            page = pdf.pages[page_index]
            page_image = page.to_image(resolution=_get_ocr_dpi())
            image = getattr(page_image, "original", None)
            if image is None:
                bio = io.BytesIO()
                page_image.save(bio, format="PNG")
                bio.seek(0)
                image = Image.open(bio)
            return image
    except Exception:
        return None


def _ocr_with_tesseract(image) -> str:
    try:
        import pytesseract  # type: ignore
    except Exception:
        return ""

    try:
        return (pytesseract.image_to_string(image, lang="kor+eng") or "").strip()
    except Exception:
        return ""


async def _ocr_with_openai_vision(image) -> str:
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        return ""

    try:
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        encoded = base64.b64encode(buffer.getvalue()).decode("utf-8")
    except Exception:
        return ""

    payload = {
        "model": _get_markdown_model(),
        "temperature": 0,
        "max_tokens": 4000,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            "You are an OCR engine. Extract ALL readable Korean/English text from the image. "
                            "Preserve line breaks, numbers, currency units, and table labels as faithfully as possible. "
                            "Output plain text only."
                        ),
                    },
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{encoded}"}},
                ],
            }
        ],
    }

    async with httpx.AsyncClient(timeout=120.0) as client:
        response = await client.post(
            f"{_get_markdown_base_url().rstrip('/')}/chat/completions",
            headers=_build_openai_compatible_headers(api_key),
            json=payload,
        )
        response.raise_for_status()
        return _extract_chat_completion_text(response.json())


async def _extract_text_from_page_image(file_bytes: bytes, page_index: int) -> str:
    image = _render_pdf_page_image(file_bytes, page_index)
    if image is None:
        return ""

    engine = _get_ocr_engine()
    if engine == "synap":
        # Synap 모드에서는 문서 전체 OCR 결과만 사용합니다.
        # 다른 OCR 엔진(OpenAI Vision/Tesseract)으로 섞지 않습니다.
        return ""
    if engine == "openai_vision":
        return await _ocr_with_openai_vision(image)
    return _ocr_with_tesseract(image)


async def _extract_pdf_content(file_name: str, file_bytes: bytes) -> str:
    import pdfplumber

    result_lines: List[str] = [f"FILE_NAME: {file_name}"]
    with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
        total_pages = len(pdf.pages)
        result_lines.append(f"TOTAL_PAGES: {total_pages}")
        result_lines.append(f"EXTRACTED_PAGES: 1-{total_pages}" if total_pages > 0 else "EXTRACTED_PAGES: none")

        synap_page_texts: Dict[int, str] = {}
        if _is_ocr_enabled() and _get_ocr_engine() == "synap":
            synap_page_texts = await _extract_text_with_synap(file_name, file_bytes, total_pages)

        for page_index, page in enumerate(pdf.pages, start=1):
            result_lines.append(f"\n=== Page {page_index} ===")
            text = (page.extract_text() or "").strip()
            synap_text = synap_page_texts.get(page_index, "")
            if synap_text:
                text = _merge_text_lines(text, synap_text)
            if (
                _is_ocr_enabled()
                and _get_ocr_engine() != "synap"
                and _ocr_always_if_images()
                and _page_has_images(page)
            ):
                ocr_text = await _extract_text_from_page_image(file_bytes, page_index - 1)
                if ocr_text:
                    text = _merge_text_lines(text, ocr_text)
            if text:
                result_lines.append(text)
            else:
                result_lines.append("(추출된 텍스트 없음)")
            tables = page.extract_tables() or []
            for table_index, table in enumerate(tables, start=1):
                result_lines.append(f"\n--- Table {table_index} ---")
                for row in table:
                    cleaned = [str(cell).strip() if cell is not None else "" for cell in row]
                    result_lines.append(" | ".join(cleaned))

    return "\n".join(result_lines).strip()


def _extract_text_file_content(file_name: str, file_bytes: bytes) -> str:
    decoded_text = ""
    for encoding in ("utf-8", "utf-8-sig", "cp949", "latin-1"):
        try:
            decoded_text = file_bytes.decode(encoding)
            break
        except Exception:
            continue
    decoded_text = decoded_text.strip()
    if not decoded_text:
        decoded_text = "(텍스트를 추출하지 못했습니다.)"
    return f"FILE_NAME: {file_name}\n\n{decoded_text}"


async def _extract_document_content(file_name: str, file_type: Optional[str], file_bytes: bytes) -> str:
    if _is_pdf_file(file_name, file_type):
        return await _extract_pdf_content(file_name, file_bytes)
    if _is_direct_text_file(file_name, file_type):
        return _extract_text_file_content(file_name, file_bytes)
    return (
        f"FILE_NAME: {file_name}\n"
        f"FILE_TYPE: {file_type or 'unknown'}\n"
        "지원되지 않는 바이너리 문서 형식이라 직접 텍스트를 추출하지 못했습니다."
    )


def _extract_chat_completion_text(payload: Dict[str, Any]) -> str:
    choices = payload.get("choices") or []
    if not choices:
        return ""
    message = choices[0].get("message") or {}
    content = message.get("content")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                parts.append(str(item.get("text") or ""))
        return "".join(parts).strip()
    return str(content or "").strip()


async def _generate_markdown_from_documents(
    *,
    user_request: str,
    file_summaries: List[Dict[str, Any]],
    extra_instruction: Optional[str] = None,
) -> str:
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
    if not api_key:
        raise ValueError("OPENAI_API_KEY가 설정되지 않아 맞춤 마크다운 생성을 수행할 수 없습니다.")

    document_blocks: List[str] = []
    for index, item in enumerate(file_summaries, start=1):
        document_blocks.append(
            f"[문서 {index}]\n"
            f"- 파일명: {item.get('fileName')}\n"
            f"- 파일형식: {item.get('fileType') or 'unknown'}\n"
            f"- 추출결과:\n{item.get('extracted_text')}"
        )

    user_prompt = (
        f"사용자 요청:\n{user_request.strip()}\n\n"
        f"문서 추출 결과:\n\n{chr(10).join(document_blocks)}"
    )
    if extra_instruction:
        user_prompt += f"\n\n추가 요청사항:\n{extra_instruction.strip()}"

    payload = {
        "model": _get_markdown_model(),
        "temperature": 0.1,
        "max_tokens": 4000,
        "messages": [
            {
                "role": "system",
                "content": (
                    "당신은 문서 기반 결과물을 최종 마크다운으로 작성하는 전문 어시스턴트입니다.\n"
                    "- 반드시 최종 결과 마크다운만 출력하세요.\n"
                    "- 사용자의 요청 형식에 맞춰 제목, 표, 목록, 주석을 적절히 구성하세요.\n"
                    "- 문서의 숫자, 통화 단위, 날짜, 고유명사, 표 항목은 가능한 한 원문 그대로 빠짐없이 반영하세요.\n"
                    "- 문서에 없는 사실은 단정하지 말고 '정보 부족', '추정'처럼 명시하세요.\n"
                    "- 사용자가 한글을 원하거나 한국어 요청이면 한국어로 작성하세요.\n"
                    "- 페이지 누락, 일부 페이지 손상, OCR 누락 같은 경고는 문서 추출 결과에 명시적 근거가 있을 때만 적으세요.\n"
                    "- 근거 없이 '일부 페이지가 누락되었다' 같은 추정을 쓰지 마세요.\n"
                    "- 애매한 숫자는 억지로 보정하지 말고 비워두거나 정보 부족이라고 적으세요.\n"
                    "- 'JSON', '도구 결과', '분석 과정' 같은 메타 설명은 쓰지 마세요."
                ),
            },
            {"role": "user", "content": user_prompt},
        ],
    }

    base_url = _get_markdown_base_url().rstrip("/")
    async with httpx.AsyncClient(timeout=180.0) as client:
        response = await client.post(
            f"{base_url}/chat/completions",
            headers=_build_openai_compatible_headers(api_key),
            json=payload,
        )
        response.raise_for_status()
        result = _extract_chat_completion_text(response.json())
        if not result:
            raise ValueError("LLM 응답에서 마크다운 본문을 추출하지 못했습니다.")
        return result


def _build_pdf2markdown_fallback(
    *,
    user_request: str,
    file_summaries: List[Dict[str, Any]],
    reason: str,
) -> str:
    primary_name = file_summaries[0].get("fileName") if file_summaries else "문서"
    sections = [
        f"# {primary_name} 문서 추출 결과",
        "",
        f"> 맞춤 마크다운 생성에 실패하여 추출 원문을 함께 제공합니다. 사유: {reason}",
        "",
        "## 사용자 요청",
        user_request.strip() or "(요청 없음)",
        "",
    ]
    for index, item in enumerate(file_summaries, start=1):
        sections.extend(
            [
                f"## 추출 문서 {index}: {item.get('fileName')}",
                f"- 파일 형식: {item.get('fileType') or 'unknown'}",
                "",
                "```text",
                str(item.get("extracted_text") or "").strip(),
                "```",
                "",
            ]
        )
    return "\n".join(sections).strip()

# FastMCP 서버 생성
mcp = FastMCP(
    "work-assistant",
    instructions=f"""업무 지원 도구 서버입니다.

[사용자/인증]
- 환경변수 user_email: {ENV_USER_EMAIL if ENV_USER_EMAIL else '(설정되지 않음)'}
- 실행 계열 도구 전에 사용자 식별이 필요하면 get_current_user를 먼저 호출하세요.
- 모든 도구는 user_jwt, tenant_id를 생략할 수 있습니다(환경변수 자동 로드).

[핵심 라우팅]
- 문서 업로드 + 프로세스 생성/추출 요청이면 파일 형식과 무관하게 create_pdf2bpmn_workitem 호출
- 문서 없이 프로세스 생성 요청이면 start_process_consulting -> (확정 후) generate_process
- 문서가 있어도 컨설팅 요청이면 start_process_consulting -> (확정 후) generate_process
- 문서 업로드 + 표/정리/테이블/요약/설명/마크다운 요청이면 pdf2markdown 호출
- 파일 + 문서 질문/요약/설명 요청이면 pdf2markdown 우선, 복잡한 비교/검증/집계는 execute_python
- 파일만 업로드되었거나, 파일은 있지만 요청 의도가 모호할 때 ask_user 사용
- 실행 요청은 get_process_list -> get_process_detail -> get_form_fields -> execute_process

[ask_user 최소화 규칙]
- ask_user는 마지막 수단입니다.
- 필수 입력 누락, 대상 파일 불명확, 생성/실행 판별 불가일 때만 사용하세요.
- 질문은 간결하게 하고 suggestions는 최소한으로 제공합니다.

[실행 전 검증]
- execute_process 전 definition.roles의 endpoint/default를 확인하세요.
- 담당자 미배정 role이 있으면 실행하지 말고 수정 링크를 안내하세요:
  https://{{tenant_id}}.process-gpt.io/definitions/{{process_id}}?edit=true

[이벤트 트리거 도구]
- start_process_consulting/generate_process는 트리거 전용입니다.
- 호출 후에는 추가 설명 없이 도구 결과(JSON)만 반환하세요.
"""
)


def get_supabase_headers(user_jwt: Optional[str]) -> dict:
    """
    Supabase API 호출용 헤더 생성
    
    변경: service_role_key 대신 user_jwt 사용
    - apikey: anon_key (Supabase 프로젝트 식별용)
    - Authorization: user_jwt (사용자 인증, RLS 적용)
    """
    effective_jwt = user_jwt or ""
    # 디버깅: user_jwt 전달 여부 및 내용 확인
    if effective_jwt:
        logger.info(f"[RLS] user_jwt 전달됨: {effective_jwt[:50]}... (길이: {len(effective_jwt)})")
        # JWT 페이로드 디코딩 (디버깅용)
        try:
            import base64
            parts = effective_jwt.split('.')
            if len(parts) >= 2:
                # 패딩 추가
                payload = parts[1] + '=' * (4 - len(parts[1]) % 4)
                decoded = base64.urlsafe_b64decode(payload).decode('utf-8')
                logger.info(f"[RLS] JWT 페이로드: {decoded}")
        except Exception as e:
            logger.warning(f"[RLS] JWT 디코딩 실패: {e}")
    else:
        logger.warning("[RLS] ⚠️ user_jwt가 비어있음! RLS가 제대로 작동하지 않을 수 있습니다.")
    
    return {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {effective_jwt}",
        "Content-Type": "application/json",
        "Prefer": "return=representation"
    }


def generate_uuid() -> str:
    """UUID 생성"""
    return str(uuid.uuid4())


# =============================================================================
# 도구 0: 사용자에게 질문 (Human in the Loop)
# =============================================================================
@mcp.tool()
async def ask_user(
    question: str,
    context: Optional[str] = None,
    missing_fields: Optional[List[str]] = None,
    suggestions: Optional[List[str]] = None,
    allow_skip: Optional[bool] = False,
    # 프론트엔드/클라이언트가 모든 도구에 공통 파라미터를 전달해도 validation 오류가 나지 않도록 수용
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,
    user_email: Optional[str] = None
) -> str:
    """
    사용자에게 추가 정보가 꼭 필요할 때만 질문합니다.
    도구 선택/실행이 가능한 상황에서는 ask_user를 남발하지 마세요.
    question은 짧고 명확하게 작성하고, suggestions는 최소한으로 제공합니다.

    Args:
        question: 사용자에게 보여줄 질문
        context: 질문 배경 설명
        missing_fields: 누락된 입력 항목 목록
        suggestions: 빠른 선택지 목록
        allow_skip: 건너뛰기 허용 여부
    """
    response = {
        "user_request_type": "ask_user",
        "question": question,
        "waiting_for_user_input": True
    }
    
    if context:
        response["context"] = context
    if missing_fields:
        response["missing_fields"] = missing_fields
    if suggestions:
        response["suggestions"] = suggestions
    if bool(allow_skip):
        response["allow_skip"] = allow_skip
        
    logger.info(f"[ask_user] 사용자에게 질문: {question}")
    if missing_fields:
        logger.info(f"[ask_user] 누락된 필드: {missing_fields}")
    
    return json.dumps(response, ensure_ascii=False)


# =============================================================================
# 도구 0.5: 현재 사용자 정보 조회
# =============================================================================
@mcp.tool()
async def get_current_user(
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    email: Optional[str] = None,
    # 공통 파라미터(호환성용)
    user_uid: Optional[str] = None,
    user_email: Optional[str] = None
) -> str:
    """
    현재 사용자 식별 정보를 조회합니다.
    execute_process 전에 user_uid/user_email 확보가 필요할 때 사용합니다.
    email 미지정 시 파라미터 또는 환경변수 user_email을 사용합니다.
    """
    # 환경변수 우선 사용
    user_jwt, tenant_id = get_effective_credentials(user_jwt, tenant_id)
    
    # 이메일: 파라미터(email) > 공통 파라미터(user_email) > 환경변수
    target_email = (email or user_email) if (email or user_email) else ENV_USER_EMAIL
    
    if not target_email:
        return json.dumps({
            "error": "사용자 이메일이 필요합니다. 환경변수 user_email을 설정하거나 email 파라미터를 전달해주세요.",
            "hint": "mcp.json의 env에 user_email을 추가하세요."
        }, ensure_ascii=False)
    
    if not user_jwt or not tenant_id:
        return json.dumps({"error": "user_jwt와 tenant_id가 필요합니다."}, ensure_ascii=False)
    
    try:
        # users 테이블에서 이메일로 사용자 정보 조회
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{SUPABASE_URL}/rest/v1/users",
                headers=get_supabase_headers(user_jwt),
                params={
                    "tenant_id": f"eq.{tenant_id}",
                    "email": f"eq.{target_email}",
                    "select": "id,email,username,role,profile,is_admin,is_agent"
                }
            )
            response.raise_for_status()
            data = response.json()
            
            if data and len(data) > 0:
                user_data = data[0]
                user_info = {
                    "user_uid": user_data.get("id"),
                    "user_email": user_data.get("email"),
                    "username": user_data.get("username"),
                    "role": user_data.get("role", "user"),
                    "profile": user_data.get("profile"),
                    "is_admin": user_data.get("is_admin", False),
                    "is_agent": user_data.get("is_agent", False)
                }
                logger.info(f"[get_current_user] 사용자 정보 조회 성공: {target_email} -> {user_info.get('username')}")
                return json.dumps(user_info, ensure_ascii=False, indent=2)
            else:
                return json.dumps({
                    "error": f"이메일 '{target_email}'에 해당하는 사용자를 찾을 수 없습니다.",
                    "hint": "users 테이블에 해당 이메일의 사용자가 등록되어 있는지 확인하세요."
                }, ensure_ascii=False)
                
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            return json.dumps({"error": "인증 실패: JWT가 유효하지 않거나 만료되었습니다."}, ensure_ascii=False)
        elif e.response.status_code == 403:
            return json.dumps({"error": "접근 거부: 해당 테넌트에 대한 권한이 없습니다."}, ensure_ascii=False)
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        logger.error(f"[get_current_user] 오류: {e}")
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# =============================================================================
# 도구 1: 프로세스 컨설팅 시작 (프론트엔드 위임)
# =============================================================================
@mcp.tool()
async def start_process_consulting(
    user_message: str,
    image_analysis_result: Optional[str] = None,
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,
    user_email: Optional[str] = None
) -> str:
    """
    프로세스 생성 컨설팅 시작 이벤트를 트리거합니다.
    문서 없이 프로세스 생성 요청이거나, 문서가 있어도 사용자가 "컨설팅"을 요청한 경우에 호출합니다.
    생성 요청의 첫 단계에서 호출하며, 호출 후에는 결과 JSON만 반환하세요.
    실제 컨설팅 화면/내용 생성은 프론트엔드가 담당합니다.
    """
    return json.dumps({
        "user_request_type": "start_process_consulting",
        "user_message": user_message,
        "image_analysis_result": image_analysis_result or ""
    }, ensure_ascii=False)


# =============================================================================
# 도구 2: 프로세스 생성 (프론트엔드 위임)
# =============================================================================
@mcp.tool()
async def generate_process(
    user_message: str, 
    image_analysis_result: Optional[str] = None,
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,
    user_email: Optional[str] = None
) -> str:
    """
    프로세스 생성 확정 이벤트를 트리거합니다.
    반드시 start_process_consulting 이후, 사용자가 생성 확정을 표현했을 때만 호출하세요.
    호출 후에는 추가 도구 호출 없이 결과 JSON만 반환합니다.
    """
    return json.dumps({
        "user_request_type": "generate_process",
        "user_message": user_message,
        "image_analysis_result": image_analysis_result or ""
    }, ensure_ascii=False)


# =============================================================================
# 도구 2: 프로세스 목록 조회
# =============================================================================
@mcp.tool()
async def get_process_list(
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,  # 에이전트 일관성을 위해 추가 (미사용)
    user_email: Optional[str] = None  # 에이전트 일관성을 위해 추가 (미사용)
) -> str:
    """
    현재 테넌트의 프로세스 정의 목록(id, name)을 조회합니다.
    사용자가 기존 프로세스에 대해 질문하거나 실행 요청했을 때 대상 프로세스 식별용으로 사용합니다.
    """
    # 환경변수 우선 사용
    user_jwt, tenant_id = get_effective_credentials(user_jwt, tenant_id)
    if not user_jwt or not tenant_id:
        return json.dumps({"error": "user_jwt와 tenant_id가 필요합니다."}, ensure_ascii=False)
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{SUPABASE_URL}/rest/v1/proc_def",
                headers=get_supabase_headers(user_jwt),
                params={
                    "tenant_id": f"eq.{tenant_id}",
                    "select": "id,name"
                }
            )
            response.raise_for_status()
            data = response.json()
            return json.dumps(data, ensure_ascii=False, indent=2)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            return json.dumps({"error": "인증 실패: JWT가 유효하지 않거나 만료되었습니다."}, ensure_ascii=False)
        elif e.response.status_code == 403:
            return json.dumps({"error": "접근 거부: 해당 테넌트에 대한 권한이 없습니다."}, ensure_ascii=False)
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# =============================================================================
# 도구 3: 프로세스 상세 조회
# =============================================================================
@mcp.tool()
async def get_process_detail(
    process_id: str,
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,  # 에이전트 일관성을 위해 추가 (미사용)
    user_email: Optional[str] = None  # 에이전트 일관성을 위해 추가 (미사용)
) -> str:
    """
    특정 프로세스 정의(definition)를 조회합니다.
    실행 전 activity_id/form_key 추출과 역할 담당자(endpoint/default) 검증에 사용합니다.
    """
    # 환경변수 우선 사용
    user_jwt, tenant_id = get_effective_credentials(user_jwt, tenant_id)
    if not user_jwt or not tenant_id:
        return json.dumps({"error": "user_jwt와 tenant_id가 필요합니다."}, ensure_ascii=False)
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{SUPABASE_URL}/rest/v1/proc_def",
                headers=get_supabase_headers(user_jwt),
                params={
                    "tenant_id": f"eq.{tenant_id}",
                    "id": f"eq.{process_id}",
                    "select": "id,name,definition"
                }
            )
            response.raise_for_status()
            data = response.json()
            
            if data and len(data) > 0:
                return json.dumps(data[0], ensure_ascii=False, indent=2)
            else:
                return json.dumps({"error": "프로세스를 찾을 수 없습니다."}, ensure_ascii=False)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            return json.dumps({"error": "인증 실패: JWT가 유효하지 않거나 만료되었습니다."}, ensure_ascii=False)
        elif e.response.status_code == 403:
            return json.dumps({"error": "접근 거부: 해당 테넌트에 대한 권한이 없습니다."}, ensure_ascii=False)
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# =============================================================================
# 도구 4: 폼 필드 조회
# =============================================================================
@mcp.tool()
async def get_form_fields(
    form_key: str,
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,  # 에이전트 일관성을 위해 추가 (미사용)
    user_email: Optional[str] = None  # 에이전트 일관성을 위해 추가 (미사용)
) -> str:
    """
    form_key에 해당하는 폼 정의(fields_json 포함)를 조회합니다.
    execute_process 전에 필수 입력 항목과 타입을 확인할 때 사용합니다.
    """
    # 환경변수 우선 사용
    user_jwt, tenant_id = get_effective_credentials(user_jwt, tenant_id)
    if not user_jwt or not tenant_id:
        return json.dumps({"error": "user_jwt와 tenant_id가 필요합니다."}, ensure_ascii=False)
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{SUPABASE_URL}/rest/v1/form_def",
                headers=get_supabase_headers(user_jwt),
                params={
                    "tenant_id": f"eq.{tenant_id}",
                    "id": f"eq.{form_key}"
                }
            )
            response.raise_for_status()
            data = response.json()
            
            if data and len(data) > 0:
                return json.dumps(data[0], ensure_ascii=False, indent=2)
            else:
                return json.dumps({"error": "폼을 찾을 수 없습니다."}, ensure_ascii=False)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            return json.dumps({"error": "인증 실패: JWT가 유효하지 않거나 만료되었습니다."}, ensure_ascii=False)
        elif e.response.status_code == 403:
            return json.dumps({"error": "접근 거부: 해당 테넌트에 대한 권한이 없습니다."}, ensure_ascii=False)
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# =============================================================================
# 도구 5: 프로세스 실행
# =============================================================================
@mcp.tool()
async def execute_process(
    process_definition_id: str,
    activity_id: str,
    form_key: str,
    form_values: Dict[str, Any],
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,
    user_email: Optional[str] = None,
    username: Optional[str] = None
) -> str:
    """
    기존 프로세스 인스턴스를 실행합니다.
    process_definition_id/activity_id/form_key/form_values를 받아 백엔드 실행 API를 호출하고 결과를 반환합니다.
    호출 전에 get_process_detail로 담당자 배정과 첫 액티비티 정보를 검증해야 합니다.
    """
    # 환경변수 우선 사용
    user_jwt, tenant_id = get_effective_credentials(user_jwt, tenant_id)
    if not user_jwt or not tenant_id:
        return json.dumps({"error": "user_jwt와 tenant_id가 필요합니다."}, ensure_ascii=False)
    if not user_uid or not user_email:
        return json.dumps({"error": "user_uid와 user_email이 필요합니다."}, ensure_ascii=False)
    
    try:
        # process_instance_id 생성
        process_instance_id = f"{process_definition_id}.{generate_uuid()}"
        
        # username 기본값 처리 (없으면 email 사용)
        effective_username = username if username else user_email
        
        # role_mappings 초기화 (항상 서버에서 자동 생성)
        role_mappings = None
        
        # role_mappings가 비어있으면 프로세스 정의에서 자동 생성
        if not role_mappings:
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    # 프로세스 정의 조회 (user_jwt 사용)
                    response = await client.get(
                        f"{SUPABASE_URL}/rest/v1/proc_def",
                        headers=get_supabase_headers(user_jwt),
                        params={
                            "tenant_id": f"eq.{tenant_id}",
                            "id": f"eq.{process_definition_id}",
                            "select": "definition"
                        }
                    )
                    response.raise_for_status()
                    data = response.json()
                    
                    if data and len(data) > 0:
                        definition = data[0].get("definition", {})
                        roles = definition.get("roles", [])
                        activities = definition.get("activities", [])
                        logger.info(f"roles: {roles}")
                        logger.info(f"activities 개수: {len(activities)}")
                        
                        # 첫 번째 액티비티의 role 찾기
                        first_activity = None
                        for act in activities:
                            if act.get("id") == activity_id:
                                first_activity = act
                                break
                        
                        first_activity_role = first_activity.get("role") if first_activity else None
                        
                        # 역할 매핑 생성 (ProcessGPTExecute.vue 참고)
                        role_mappings = []
                        for role in roles:
                            role_name = role.get("name")
                            role_default = role.get("default", [])
                            role_endpoint = role.get("endpoint", [])
                            
                            # endpoint 값 결정
                            if role_name == first_activity_role:
                                # 첫 번째 액티비티의 role에 현재 사용자 매핑
                                endpoint_value = user_uid
                            elif role_default:
                                # default 값이 있으면 사용
                                endpoint_value = role_default if isinstance(role_default, list) else [role_default]
                            elif role_endpoint:
                                # endpoint 값이 있으면 사용
                                endpoint_value = role_endpoint if isinstance(role_endpoint, list) else [role_endpoint]
                            else:
                                endpoint_value = ""
                            
                            role_mapping = {
                                "name": role_name,
                                "endpoint": endpoint_value,
                                "resolutionRule": role.get("resolutionRule"),
                                "default": role_default if role_default else ""
                            }
                            role_mappings.append(role_mapping)                        
                    else:
                        logger.warning("프로세스 정의를 찾을 수 없음")
            except Exception as e:
                # 역할 매핑 조회 실패 시 빈 배열로 진행
                logger.error(f"역할 매핑 생성 오류: {e}")
                role_mappings = []
        
        logger.info(f"최종 role_mappings: {role_mappings}")
        
        # 입력 데이터 구성
        input_data = {
            "process_definition_id": process_definition_id.lower(),
            "process_instance_id": process_instance_id,
            "activity_id": activity_id,
            "form_values": {
                form_key: form_values
            },
            "role_mappings": role_mappings,
            "answer": "",
            "user_id": user_uid,
            "username": effective_username,
            "email": user_email,
            "tenant_id": tenant_id,
            "version_tag": "major",
            "version": None,
            "source_list": []
        }
        
        api_base_url = get_api_base_url(tenant_id)
        logger.info(f"API 호출 URL: {api_base_url}/completion/complete")
        logger.info(f"API 호출 input_data: {json.dumps(input_data, ensure_ascii=False, default=str)}")
        
        # API 호출 (백엔드 API는 별도 인증 사용)
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                f"{api_base_url}/completion/complete",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {user_jwt}"  # 백엔드에도 JWT 전달
                },
                json={"input": input_data}
            )
            logger.info(f"API 응답 status_code: {response.status_code}")
            logger.info(f"API 응답 body: {response.text[:500] if response.text else 'empty'}")
            
            response.raise_for_status()
            result = response.json()
            
            # 성공 응답에 process_instance_id 추가
            if isinstance(result, dict):
                result["process_instance_id"] = process_instance_id
                result["message"] = f"프로세스 '{process_definition_id}'가 성공적으로 실행되었습니다."
            
            logger.info(f"========== execute_process 성공 ==========")
            return json.dumps(result, ensure_ascii=False, indent=2)
            
    except httpx.HTTPStatusError as e:
        logger.error(f"API 호출 실패: {e.response.status_code}")
        logger.error(f"API 에러 응답: {e.response.text}")
        if e.response.status_code == 401:
            return json.dumps({"error": "인증 실패: JWT가 유효하지 않거나 만료되었습니다."}, ensure_ascii=False)
        elif e.response.status_code == 403:
            return json.dumps({"error": "접근 거부: 해당 테넌트에 대한 권한이 없습니다."}, ensure_ascii=False)
        return json.dumps({
            "error": f"API 호출 실패: {e.response.status_code}",
            "detail": e.response.text
        }, ensure_ascii=False)
    except Exception as e:
        logger.error(f"execute_process 예외 발생: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# =============================================================================
# 도구 6: 인스턴스 목록 조회
# =============================================================================
@mcp.tool()
async def get_instance_list(
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,
    process_id: Optional[str] = None,
    user_email: Optional[str] = None  # 에이전트 일관성을 위해 추가 (미사용)
) -> str:
    """
    사용자 참여 인스턴스 목록을 조회합니다.
    process_id를 주면 특정 프로세스로 필터링하며, 반환된 proc_inst_id는 get_todolist 입력으로 사용합니다.
    """
    # 환경변수 우선 사용
    user_jwt, tenant_id = get_effective_credentials(user_jwt, tenant_id)
    if not user_jwt or not tenant_id:
        return json.dumps({"error": "user_jwt와 tenant_id가 필요합니다."}, ensure_ascii=False)
    if not user_uid:
        return json.dumps({"error": "user_uid가 필요합니다."}, ensure_ascii=False)
    
    try:
        params = {
            "tenant_id": f"eq.{tenant_id}",
            "participants": f"cs.{{{user_uid}}}"  # contains user_uid
        }
        
        if process_id:
            params["proc_def_id"] = f"eq.{process_id}"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{SUPABASE_URL}/rest/v1/bpm_proc_inst",
                headers=get_supabase_headers(user_jwt),
                params=params
            )
            response.raise_for_status()
            data = response.json()
            return json.dumps(data, ensure_ascii=False, indent=2)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            return json.dumps({"error": "인증 실패: JWT가 유효하지 않거나 만료되었습니다."}, ensure_ascii=False)
        elif e.response.status_code == 403:
            return json.dumps({"error": "접근 거부: 해당 테넌트에 대한 권한이 없습니다."}, ensure_ascii=False)
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# =============================================================================
# 도구 7: 할 일 목록 조회 (실행 결과 포함)
# =============================================================================
@mcp.tool()
async def get_todolist(
    instance_ids: List[str],
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,  # 에이전트 일관성을 위해 추가 (미사용)
    user_email: Optional[str] = None  # 에이전트 일관성을 위해 추가 (미사용)
) -> str:
    """
    instance_ids의 활동 목록과 각 활동 output(실행 결과)을 조회합니다.
    실행 결과/진행 상태 확인의 최종 단계에서 사용합니다.
    """
    # 환경변수 우선 사용
    user_jwt, tenant_id = get_effective_credentials(user_jwt, tenant_id)
    if not user_jwt or not tenant_id:
        return json.dumps({"error": "user_jwt와 tenant_id가 필요합니다."}, ensure_ascii=False)
    
    try:
        if not instance_ids:
            return json.dumps({"error": "instance_ids가 비어있습니다."}, ensure_ascii=False)
        
        # instance_ids를 쉼표로 구분된 문자열로 변환
        ids_filter = ",".join([f'"{id}"' for id in instance_ids])
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{SUPABASE_URL}/rest/v1/todolist",
                headers=get_supabase_headers(user_jwt),
                params={
                    "tenant_id": f"eq.{tenant_id}",
                    "proc_inst_id": f"in.({ids_filter})",
                    "order": "start_date.asc"
                }
            )
            response.raise_for_status()
            todos = response.json()
            
            # 프로세스별, 인스턴스별로 그룹화
            result = {}
            for todo in todos:
                def_id = todo.get("proc_def_id", "unknown")
                inst_id = todo.get("proc_inst_id", "unknown")
                
                if def_id not in result:
                    result[def_id] = {"processDefinitionId": def_id, "instances": {}}
                
                if inst_id not in result[def_id]["instances"]:
                    result[def_id]["instances"][inst_id] = {"instanceId": inst_id, "activities": []}
                
                result[def_id]["instances"][inst_id]["activities"].append({
                    "activityId": todo.get("activity_id"),
                    "activityName": todo.get("activity_name"),
                    "status": todo.get("status"),
                    "startDate": todo.get("start_date"),
                    "endDate": todo.get("end_date"),
                    "userId": todo.get("user_id"),
                    "output": todo.get("output")  # 실행 결과
                })
            
            return json.dumps(result, ensure_ascii=False, indent=2)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            return json.dumps({"error": "인증 실패: JWT가 유효하지 않거나 만료되었습니다."}, ensure_ascii=False)
        elif e.response.status_code == 403:
            return json.dumps({"error": "접근 거부: 해당 테넌트에 대한 권한이 없습니다."}, ensure_ascii=False)
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# =============================================================================
# 도구 8: PDF/문서 to Markdown 생성
# =============================================================================
@mcp.tool()
async def pdf2markdown(
    user_request: str,
    file_url: str,
    file_name: str,
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,
    user_email: Optional[str] = None,
    file_path: Optional[str] = None,
    file_id: Optional[str] = None,
    files: Optional[Any] = None,
    file_type: Optional[str] = None,
    file_size: Optional[Any] = None,
    description: Optional[str] = None,
    username: Optional[str] = None
) -> str:
    """
    첨부 문서를 읽어 사용자 요청(질문/요약/정리/표/테이블/번역/설명/마크다운)에 맞는 최종 마크다운을 생성합니다.
    문서 기반 마크다운 생성 전용 도구이며, 문서 + 프로세스 생성/추출 요청에는 사용하지 않습니다.
    문서 + 프로세스 생성/추출 요청은 반드시 create_pdf2bpmn_workitem을 사용하세요.
    다중 첨부가 있으면 files 배열 전체를 전달하세요.
    """
    normalized_files = _normalize_uploaded_files(
        file_url=file_url,
        file_name=file_name,
        file_path=file_path,
        file_id=file_id,
        file_type=file_type,
        file_size=file_size,
        files=files,
    )
    if not normalized_files:
        return "첨부 파일 정보를 확인하지 못했습니다. 파일 URL과 파일명을 다시 확인해주세요."

    file_summaries: List[Dict[str, Any]] = []
    extraction_failures: List[str] = []

    for item in normalized_files:
        item_name = str(item.get("fileName") or item.get("originalFileName") or "unknown")
        item_type = item.get("fileType")
        item_url = str(item.get("publicUrl") or item.get("fileUrl") or "")
        if not item_url:
            extraction_failures.append(f"- {item_name}: 파일 URL이 없습니다.")
            continue

        try:
            file_bytes = await _download_file_bytes(item_url)
            extracted_text = await _extract_document_content(item_name, item_type, file_bytes)
            file_summaries.append(
                {
                    "fileName": item_name,
                    "fileType": item_type,
                    "extracted_text": extracted_text,
                }
            )
        except Exception as e:
            logger.error(f"[pdf2markdown] 파일 처리 실패 ({item_name}): {e}")
            extraction_failures.append(f"- {item_name}: {str(e)}")

    if not file_summaries:
        failure_text = "\n".join(extraction_failures) if extraction_failures else "추출 가능한 문서가 없습니다."
        return (
            "# 문서 처리 실패\n\n"
            "첨부 문서에서 텍스트를 추출하지 못했습니다.\n\n"
            "## 확인 내용\n"
            f"{failure_text}"
        )

    if extraction_failures:
        file_summaries.append(
            {
                "fileName": "추출 실패 파일",
                "fileType": "meta",
                "extracted_text": "다음 파일은 추출에 실패했습니다.\n" + "\n".join(extraction_failures),
            }
        )

    try:
        return await _generate_markdown_from_documents(
            user_request=user_request,
            file_summaries=file_summaries,
            extra_instruction=description,
        )
    except Exception as e:
        logger.error(f"[pdf2markdown] LLM 마크다운 생성 실패: {e}")
        return _build_pdf2markdown_fallback(
            user_request=user_request,
            file_summaries=file_summaries,
            reason=str(e),
        )

# =============================================================================
# 도구 10: PDF to BPMN 워크아이템 생성
# =============================================================================
@mcp.tool()
async def create_pdf2bpmn_workitem(
    pdf_file_url: str,
    pdf_file_name: str,
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,
    user_email: Optional[str] = None,
    pdf_file_path: Optional[str] = None,
    pdf_file_id: Optional[str] = None,
    files: Optional[Any] = None,
    description: Optional[str] = None,
    username: Optional[str] = None,
    room_id: Optional[str] = None,
) -> str:
    """
    문서 파일을 BPMN으로 변환하기 위한 workitem을 생성합니다.
    문서 업로드 + 프로세스 생성/추출 요청이면 파일 형식(PDF/HWP/HWPX/DOCX 등)과 무관하게 이 도구를 사용합니다.
    문서 질의/요약/표/테이블/정리/마크다운 요청에는 사용하지 않습니다(이 경우 pdf2markdown 사용).
    단일/다중 파일을 모두 지원하고, files가 있으면 전체를 전달해야 합니다.
    """
    # 환경변수 우선 사용
    user_jwt, tenant_id = get_effective_credentials(user_jwt, tenant_id)
    if not user_jwt or not tenant_id:
        return json.dumps({"error": "user_jwt와 tenant_id가 필요합니다."}, ensure_ascii=False)
    if not user_uid or not user_email:
        return json.dumps({"error": "user_uid와 user_email이 필요합니다."}, ensure_ascii=False)
    
    try:
        # 워크아이템 ID 생성
        workitem_id = generate_uuid()
        
        # username 기본값 처리
        effective_username = username if username else user_email
        
        def _build_file_entry(
            *,
            file_url: Optional[str],
            file_name: Optional[str],
            file_path: Optional[str] = None,
            file_id: Optional[str] = None,
            file_type: Optional[str] = None,
            file_size: Optional[Any] = None
        ) -> Optional[Dict[str, Any]]:
            if not file_url or not file_name:
                return None

            effective_path = file_path
            if not effective_path:
                if "/files/" in file_url:
                    effective_path = file_url.split("/files/")[-1]
                else:
                    effective_path = file_url.split("/")[-1]
            effective_path = str(effective_path or "").rstrip("?")

            return {
                "id": file_id if file_id else generate_uuid(),
                "path": effective_path,
                "fullPath": file_url,
                "publicUrl": file_url,
                "fileUrl": file_url,
                "originalFileName": file_name,
                "fileName": file_name,
                "fileType": file_type,
                "fileSize": file_size
            }

        parsed_files_input: List[Dict[str, Any]] = []
        if isinstance(files, list):
            parsed_files_input = [f for f in files if isinstance(f, dict)]
        elif isinstance(files, str):
            try:
                parsed = json.loads(files)
                if isinstance(parsed, list):
                    parsed_files_input = [f for f in parsed if isinstance(f, dict)]
                elif isinstance(parsed, dict):
                    parsed_files_input = [parsed]
            except Exception:
                logger.warning("[create_pdf2bpmn_workitem] files 문자열 JSON 파싱 실패")
                parsed_files_input = []
        elif isinstance(files, dict):
            parsed_files_input = [files]

        incoming_files_len = len(parsed_files_input)
        normalized_files: List[Dict[str, Any]] = []

        primary_file = _build_file_entry(
            file_url=pdf_file_url,
            file_name=pdf_file_name,
            file_path=pdf_file_path,
            file_id=pdf_file_id
        )
        if primary_file:
            normalized_files.append(primary_file)

        for item in parsed_files_input:
            item_url = (
                item.get("publicUrl")
                or item.get("fileUrl")
                or item.get("fullPath")
                or item.get("url")
            )
            item_name = (
                item.get("originalFileName")
                or item.get("fileName")
                or item.get("name")
            )
            file_entry = _build_file_entry(
                file_url=item_url,
                file_name=item_name,
                file_path=item.get("path"),
                file_id=item.get("id"),
                file_type=item.get("fileType"),
                file_size=item.get("fileSize")
            )
            if file_entry:
                normalized_files.append(file_entry)

        # 중복 제거: (publicUrl + fileName) 기준
        deduped_files: List[Dict[str, Any]] = []
        seen_keys = set()
        for f in normalized_files:
            key = (f.get("publicUrl"), f.get("fileName"))
            if key in seen_keys:
                continue
            seen_keys.add(key)
            deduped_files.append(f)

        if not deduped_files:
            return json.dumps({"error": "유효한 파일 정보가 없습니다."}, ensure_ascii=False)

        primary = deduped_files[0]

        input_data = {
            # 하위 호환: 기존 단일 파일 파서 유지
            "path": primary.get("path"),
            "id": primary.get("id"),
            "fullPath": primary.get("fullPath"),
            "originalFileName": primary.get("originalFileName"),
            "publicUrl": primary.get("publicUrl"),
            # 다중 파일 전달
            "file": {
                "id": primary.get("id"),
                "path": primary.get("path"),
                "fullPath": primary.get("fullPath"),
                "publicUrl": primary.get("publicUrl"),
                "fileUrl": primary.get("fileUrl"),
                "fileName": primary.get("fileName"),
                "originalFileName": primary.get("originalFileName"),
                "fileType": primary.get("fileType"),
                "fileSize": primary.get("fileSize"),
            },
            "files": deduped_files,
            "fileCount": len(deduped_files),
            "room_id": room_id or "",
            "tenant_id": tenant_id or "",
        }

        # 쿼리 구성 (업로드된 파일 정보 포함; 원본 확장자 무관)
        query = f"""[Description]
첨부된 문서를 분석하여 BPMN 프로세스를 생성합니다. (원본 파일이 PDF가 아니어도 내부에서 PDF로 변환될 수 있습니다.)

[Instruction]
1. 첨부된 문서를 분석하세요. (필요 시 PDF로 변환 후 분석)
2. 문서 내용에서 업무 프로세스를 추출하세요.
3. BPMN 형식의 프로세스 정의를 생성하세요.

[InputData]
{json.dumps(input_data, ensure_ascii=False)}"""

        if description:
            query = f"{query}\n\n[추가 요청사항]\n{description}"
        
        # 워크아이템 데이터 구성
        workitem_data = {
            "id": workitem_id,
            "user_id": user_uid,
            "username": effective_username,
            "tenant_id": tenant_id,
            "proc_inst_id": uuid.uuid4().hex,
            "root_proc_inst_id": None,
            # NOTE: todolist INSERT 후 sync_task_execution_on_insert() 트리거가
            # task_execution_properties(proc_def_id/proc_inst_id/activity_id NOT NULL)에
            # NEW 값을 그대로 적재합니다. pdf2bpmn 워크아이템은 고정값으로 채웁니다.
            "proc_def_id": "pdf2bpmn",
            "activity_id": "Activity_pdf2bpmn",
            "activity_name": "pdf2bpmn",
            "status": "IN_PROGRESS",
            "tool": "formHandler:defaultform",
            "description": query,
            "query": query,
            "duration": 0,
            "start_date": None,  # 서버에서 자동 설정
            "due_date": None,
            "agent_mode": "DRAFT",
            "agent_orch": "pdf2bpmn",
            "adhoc": False,
            "output": None,
        }
        
        logger.info(f"[create_pdf2bpmn_workitem] 워크아이템 생성 시작: {workitem_id}")
        logger.info(
            "[create_pdf2bpmn_workitem] 호출 인자 files 개수: %s",
            incoming_files_len
        )
        logger.info(f"[create_pdf2bpmn_workitem] 파일 개수: {len(deduped_files)}")
        logger.info(
            "[create_pdf2bpmn_workitem] 파일 목록: %s",
            [f.get("fileName") for f in deduped_files]
        )
        if incoming_files_len == 0:
            logger.warning(
                "[create_pdf2bpmn_workitem] files 인자가 비어 있습니다. "
                "메인 에이전트가 [InputData].files를 전달하지 않았을 수 있습니다."
            )
        
        # Supabase에 워크아이템 저장
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{SUPABASE_URL}/rest/v1/todolist",
                headers=get_supabase_headers(user_jwt),
                json=workitem_data
            )
            response.raise_for_status()
            
            logger.info(f"[create_pdf2bpmn_workitem] 워크아이템 생성 성공: {workitem_id}")
            
            return json.dumps({
                "success": True,
                "workitem_id": workitem_id,
                "message": f"PDF to BPMN 워크아이템이 생성되었습니다. 파일 {len(deduped_files)}개",
                "status": "IN_PROGRESS",
                "agent_orch": "pdf2bpmn",
                "pdf_file_url": pdf_file_url,
                "incoming_files_arg_count": incoming_files_len,
                "file_count": len(deduped_files),
                "files": deduped_files
            }, ensure_ascii=False, indent=2)
            
    except httpx.HTTPStatusError as e:
        logger.error(f"[create_pdf2bpmn_workitem] HTTP 오류: {e.response.status_code}")
        logger.error(f"[create_pdf2bpmn_workitem] 응답: {e.response.text}")
        if e.response.status_code == 401:
            return json.dumps({"error": "인증 실패: JWT가 유효하지 않거나 만료되었습니다."}, ensure_ascii=False)
        elif e.response.status_code == 403:
            return json.dumps({"error": "접근 거부: 해당 테넌트에 대한 권한이 없습니다."}, ensure_ascii=False)
        return json.dumps({
            "error": f"워크아이템 생성 실패: {e.response.status_code}",
            "detail": e.response.text
        }, ensure_ascii=False)
    except Exception as e:
        logger.error(f"[create_pdf2bpmn_workitem] 예외 발생: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# =============================================================================
# 도구 9: 이미지 분석 (Vision API)
# =============================================================================


# =============================================================================
# 도구 10: 조직도 조회
# =============================================================================
@mcp.tool()
async def get_organization(
    user_jwt: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_uid: Optional[str] = None,  # 에이전트 일관성을 위해 추가 (미사용)
    user_email: Optional[str] = None  # 에이전트 일관성을 위해 추가 (미사용)
) -> str:
    """
    테넌트 조직도(부서/팀/구성원 구조)를 조회합니다.
    조직/팀 구성 질문에 대해 단독으로 호출하면 됩니다.
    """
    # 환경변수 우선 사용
    user_jwt, tenant_id = get_effective_credentials(user_jwt, tenant_id)
    if not user_jwt or not tenant_id:
        return json.dumps({"error": "user_jwt와 tenant_id가 필요합니다."}, ensure_ascii=False)
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(
                f"{SUPABASE_URL}/rest/v1/configuration",
                headers=get_supabase_headers(user_jwt),
                params={
                    "tenant_id": f"eq.{tenant_id}",
                    "key": "eq.organization"
                }
            )
            response.raise_for_status()
            data = response.json()
            
            if data and len(data) > 0:
                value = data[0].get("value", {})
                chart = value.get("chart", value) if isinstance(value, dict) else value
                return json.dumps(chart, ensure_ascii=False, indent=2)
            else:
                return json.dumps({"error": "조직도 정보를 찾을 수 없습니다."}, ensure_ascii=False)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            return json.dumps({"error": "인증 실패: JWT가 유효하지 않거나 만료되었습니다."}, ensure_ascii=False)
        elif e.response.status_code == 403:
            return json.dumps({"error": "접근 거부: 해당 테넌트에 대한 권한이 없습니다."}, ensure_ascii=False)
        return json.dumps({"error": str(e)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)


# =============================================================================
# 메인 진입점
# =============================================================================
def main():
    """MCP 서버 실행"""
    mcp.run()


if __name__ == "__main__":
    main()
