from distutils.core import setup
from setuptools import find_packages

with open('README.rst', 'r', encoding="utf-8") as f:
    long_description = f.read()

# warning!
# for pymongo==4.7.3 and mongo version 7.0
# if you want to use old version, switch branch to mongo4

setup(name='fast_web_core',
      version='6.0.4',
      description='fast web core for zsodata v6',
      long_description=long_description,
      long_description_content_type='text/plain',
      author='zsodata',
      author_email='team@zso.io',
      url='https://zso.io',
      install_requires=[
      ],
      python_requires='>=3.9',
      license='BSD License',
      packages=find_packages(),
      platforms=['all'],
      include_package_data=True,
      classifiers=[
          'Development Status :: 4 - Beta',
          'Intended Audience :: Developers',
          'License :: OSI Approved :: BSD License',
          'Operating System :: OS Independent',
          'Programming Language :: Python :: 3',
          'Programming Language :: Python :: 3.9',
          'Programming Language :: Python :: 3.10',
          'Programming Language :: Python :: 3.11',
          'Programming Language :: Python :: 3.12',
          'Topic :: Software Development :: Libraries :: Python Modules',
      ],
      keywords='fastapi web core framework async mongodb redis',
      project_urls={
          'Source': 'https://zso.io',
      },
      )
