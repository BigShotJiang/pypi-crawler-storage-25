Fast Web Core
=============

注意事项
--------

**MongoDB 依赖版本要求：**

- pymongo == 4.7.3
- MongoDB 版本：7.0

如需使用旧版本，请切换到分支：``mongo4``

主要特性
--------

- 异步 MongoDB 支持
- 异步 Redis 支持

安装指南
--------

1. 卸载旧版本（如果已安装）::

   pip uninstall fast-web-core

2. 安装或升级到最新版本::

   pip install --upgrade fast-web-core -i https://pypi.python.org/simple

3. 验证安装::

   pip show fast-web-core

项目依赖
--------

核心依赖（必需）
~~~~~~~~~~~~~~~~

**Web 框架：**

- fastapi == 0.136.0
- starlette == 0.49.1
- uvicorn == 0.34.3

**工具库：**

- python-dotenv == 1.2.2

**数据验证：**

- pydantic == 2.12.3

**重试机制：**

- tenacity == 9.1.2

可选依赖
~~~~~~~~

**MongoDB：**

- pymongo == 4.13.0
- motor == 3.7.1

**Redis：**

- redis == 5.2.1

**RabbitMQ：**

- aio-pika == 9.6.2

**阿里云 OSS：**

- oss2 == 2.19.1
