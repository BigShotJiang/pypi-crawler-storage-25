# encoding: utf-8
"""
日志过滤器模块
提供用于在日志中注入 trace_id 的 Filter 类
"""
import logging
from ..context.context_vars import trace_id_context


class TraceIdFilter(logging.Filter):
    """
    日志过滤器：注入 trace_id 到日志记录中

    用法:
        在 logging.json 配置中：
        {
            "filters": {
                "trace_id": {
                    "()": "fast_web_core.lib.log_filter.TraceIdFilter"
                }
            },
            "handlers": {
                "default": {
                    "filters": ["trace_id"],
                    ...
                }
            }
        }

        在日志格式中使用：
        "fmt": "[%(asctime)s] [%(levelname)s] [%(trace_id)s] [%(name)s]: %(message)s"
    """

    def filter(self, record: logging.LogRecord) -> bool:
        # 从 contextvars 获取 trace_id，如果没有则使用空字符串
        record.trace_id = trace_id_context.get()
        return True
