# -*- coding: utf-8 -*-
import json
import logging
from typing import List, Optional, Dict
from fast_web_core.lib import cfg
from fast_web_core.client.async_redis_client import AsyncRedis
from fast_web_core.model.items import AuthUser, AuthApp, AuthAdmin

logger = logging.getLogger(__name__)


class AuthCachePool:
    def __init__(self, redis_url: str = None, redis_db: int = None):
        self.redis_url = redis_url or cfg.get('AUTH_REDIS_URL', None)
        self.redis_db = redis_db or cfg.get('AUTH_REDIS_DB', None)
        self.series_prefix = cfg.get('AUTH_SERIES_PREFIX', 'fast')

        self.rds = AsyncRedis(redis_uri=redis_url, redis_db=self.redis_db).client

    # TODO 待完善
    async def get_cached_app(self, access_token: str) -> Optional[AuthApp]:
        rs = await self.rds.get(f'{self.series_prefix}:share:access:{access_token}')
        if rs:
            js_app = json.loads(rs)
            # 容错
            if isinstance(js_app, str):
                js_app = json.loads(js_app)
            # 特征验证（user 对象需要有 id 字段）
            if js_app and js_app.get('team_id', None):
                auth_app = AuthApp(**js_app)
                return auth_app

        return None

    # TODO 待完善
    async def get_cached_user(self, access_token: str) -> Optional[AuthUser]:
        rs = await self.rds.get(f'{self.series_prefix}:share:access:{access_token}')
        if rs:
            js_user = json.loads(rs)
            # 容错
            if isinstance(js_user, str):
                js_user = json.loads(js_user)
            # 特征验证（user 对象需要有 id 字段）
            if js_user and js_user.get('id', None) is not None:
                user = AuthUser(**js_user)
                return user

        return None

    # TODO 待完善
    async def get_cached_admin(self, access_token: str) -> Optional[AuthAdmin]:
        rs = await self.rds.get(f'{self.series_prefix}:share:access:{access_token}')
        if rs:
            js_admin = json.loads(rs)
            # 容错
            if isinstance(js_admin, str):
                js_admin = json.loads(js_admin)
            # 特征验证（admin 对象需要有 id 字段）
            if js_admin and js_admin.get('id', None) is not None:
                admin = AuthAdmin(**js_admin)
                return admin

        return None

    async def get_cached_access_dict(self, access_token: str) -> Optional[Dict]:
        rs = await self.rds.get(f'{self.series_prefix}:share:access:{access_token}')
        if rs:
            item = json.loads(rs)
            # 容错
            if isinstance(item, str):
                item = json.loads(item)
            return item

        return None

    async def has_access(self, access_token: str) -> bool:
        return await self.rds.exists(f'{self.series_prefix}:share:access:{access_token}')

    async def has_permission(self, access_token: str, permission: str) -> bool:
        return await self.rds.sismember(f'{self.series_prefix}:share:permissions:{access_token}', permission)
