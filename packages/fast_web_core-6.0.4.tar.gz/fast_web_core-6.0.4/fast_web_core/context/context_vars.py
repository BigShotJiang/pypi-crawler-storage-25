# -*- coding: utf-8 -*-
import contextvars

# TODO 待完善
# # 团队 CODE 环境变量
# team_code_context = contextvars.ContextVar('team_code', default='')

# 链路追踪 ID 环境变量
trace_id_context = contextvars.ContextVar('trace_id', default='')

# # 非主线程的事件循环环境变量
# event_loop_context = contextvars.ContextVar('event_loop')
