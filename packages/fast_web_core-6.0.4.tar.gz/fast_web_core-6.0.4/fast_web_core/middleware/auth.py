import uuid
import traceback
from typing import List

from fastapi import FastAPI
from starlette.requests import Request
from starlette.responses import StreamingResponse, JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from ..auth.share_auth import ShareAuth
from ..exception.exceptions import NoAuthException
from ..lib import logger
from ..model.handler import ErrCode
from ..context.context_vars import trace_id_context

# 固定白名单
WHITELIST = [
]

LOGGER = logger.get('鉴权中间件')


class AuthMiddleware(BaseHTTPMiddleware):
    """ 鉴权中间件 """

    def __init__(self, app: FastAPI, whitelist: List[str] = None):
        if whitelist:
            WHITELIST.extend(whitelist)
        super().__init__(app)
        self.share_auth = ShareAuth()
        self.share_auth.reload(app.routes, WHITELIST)

    async def dispatch(self, request: Request, next_func) -> Response:
        """
        接口鉴权 + 链路追踪
        :param request:
        :param next_func:
        :return:
        """
        # 链路追踪
        trace_id = request.headers.get('X-Trace-ID', '')
        if not trace_id:
            trace_id = str(uuid.uuid4())[:8]
        request.state.trace_id = trace_id
        trace_id_context.set(trace_id)

        try:
            # 权限检查
            rs = await self.share_auth.auth_check(request)
            if rs:
                resp: StreamingResponse = await next_func(request)
                resp.headers['X-Trace-ID'] = trace_id
                return resp

            return JSONResponse(
                content={'success': False, 'msg': '无权访问', 'code': ErrCode.ERROR},
                status_code=403,
                headers={'X-Trace-ID': trace_id}
            )
        except NoAuthException as na_ex:
            return JSONResponse(
                content={'success': False, 'msg': na_ex.message, 'code': ErrCode.ERROR},
                status_code=401,
                headers={'X-Trace-ID': trace_id}
            )
        except Exception as ex:
            LOGGER.error(f'[traceId={trace_id}] {traceback.format_exc()}')
            return JSONResponse(
                content={'success': False, 'msg': f'服务异常 [traceId={trace_id}]', 'code': ErrCode.ERROR},
                status_code=500,
                headers={'X-Trace-ID': trace_id}
            )
        finally:
            # 清理
            # tenant_context.set(None)
            trace_id_context.set(None)
