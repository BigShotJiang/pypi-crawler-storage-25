# from typing import List
# from fastapi import FastAPI
# from fastapi.middleware.cors import CORSMiddleware
# from starlette.middleware import Middleware
#
#
# def register_middleware(app: FastAPI, middlewares: List[Middleware] = []):
#     # 默认支持跨域
#     middlewares.append(Middleware(CORSMiddleware, allow_credentials=True, allow_origins=['*'], allow_methods=["*"], allow_headers=["*"]))
#
#     if middlewares:
#         for middleware in middlewares:
#             app.user_middleware.insert(0, middleware)
