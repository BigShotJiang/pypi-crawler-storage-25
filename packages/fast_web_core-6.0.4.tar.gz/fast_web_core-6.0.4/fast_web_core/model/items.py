from typing import Optional

from pydantic import BaseModel, Field

from ..lib import time as time_lib


class BaseData(BaseModel):
    """
    通用基础数据模型
    """
    # mongodb主键
    _id: str = None
    # 插入时间
    gen_time: int = Field(
        default_factory=time_lib.current_timestamp10
    )


class AuthUser(BaseData):
    """
    用户鉴权模型
    """
    # 用户ID，用户主键
    id: Optional[int] = None
    # 用户编号
    sn: Optional[str] = None
    # 用户账号
    account: Optional[str] = None
    # 用户昵称
    nickname: Optional[str] = None
    # 性别: [0=保密,1=男,2=女]
    gender: Optional[int] = None
    # 用户头像
    avatar: Optional[str] = None
    # 电话
    mobile: Optional[str] = None
    # 邮箱
    email: Optional[str] = None
    # 登录方式: [1=网页登录,3=开放平台,5=三方对接]
    login_type: Optional[int] = None
    # 最后登录IP
    last_login_ip: Optional[str] = None
    # 最后登录时间
    last_login_time: Optional[str] = None

    # 是否团队管理员: [1=是,0=否]
    is_team_admin: Optional[int] = 0
    # 团队主键,团队编号
    team_id: Optional[str] = None
    # 团队编码
    team_code: Optional[str] = None
    # 团队名称
    team_name: Optional[str] = None
    # 团队简称
    team_alias: Optional[str] = None
    # 团队状态: [1=正常,2=停用,3=到期]
    team_status: Optional[int] = 1

    def to_log(self):
        return f'{self.nickname}({self.account})'


class AuthApp(BaseData):
    # 应用id
    app_id: Optional[str] = None
    # 应用名称
    app_name: Optional[str] = None
    # 应用logo
    logo: Optional[str] = None
    # 团队主键,团队编号
    team_id: Optional[int] = None
    # 团队编码
    team_code: Optional[str] = None
    # 团队名称
    team_name: Optional[str] = None
    # 团队简称
    team_alias: Optional[str] = None


class AuthAdmin(BaseData):
    """
    TODO 待完善
    管理员鉴权模型
    """
    # 用户ID，用户主键
    id: Optional[int] = None
    # 用户账号
    username: Optional[str] = None
    # 用户昵称
    nickname: Optional[str] = None
    # 用户头像
    avatar: Optional[str] = None
    # 电话
    mobile: Optional[str] = None
    # 邮箱
    email: Optional[str] = None
    # 最后登录IP
    last_login_ip: Optional[str] = None
    # 最后登录时间
    last_login_time: Optional[str] = None

    def to_log(self):
        return f'{self.nickname}'
