"""
Stability Scorer — A-F Grading & Flakiness Detection
======================================================

Pattern Source: Agnox Flakiness Detective

Features:
  - A-F stability scoring based on historical pass rate
  - Flakiness score (0-100) with verdict badges
  - Performance degradation detection (🐌 slow badge)
  - History tracking via local JSON file
"""

import json
import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Constants (aligned with Agnox's scoring)
# ---------------------------------------------------------------------------
class StabilityGrade(str, Enum):
    A = "A"  # >= 95%
    B = "B"  # >= 80%
    C = "C"  # >= 65%
    D = "D"  # >= 50%
    F = "F"  # < 50%
    UNGRADED = "UNGRADED"  # insufficient data


class FlakinessVerdict(str, Enum):
    STABLE = "Stable"              # 0-20
    MILDLY_FLAKY = "Mildly Flaky"  # 21-45
    FLAKY = "Flaky"                # 46-70
    HIGHLY_UNSTABLE = "Highly Unstable"  # 71-100


MIN_RUNS_FOR_GRADING = 5  # minimum runs before assigning a grade
SLOW_THRESHOLD_MULTIPLIER = 2.0  # 2x average = slow
SLOW_THRESHOLD_ABS_MS = 500  # absolute regression threshold


@dataclass
class TestRecord:
    """Single test execution record."""
    test_name: str
    passed: bool
    duration_seconds: float
    timestamp: float
    error_hash: Optional[str] = None


@dataclass
class TestStability:
    """Stability metrics for a single test."""
    test_name: str
    grade: StabilityGrade
    pass_rate: float        # 0.0 - 1.0
    flakiness_score: int    # 0-100
    verdict: FlakinessVerdict
    total_runs: int
    recent_failures: int    # in last 20 runs
    avg_duration: float     # seconds
    is_slow: bool           # performance degradation detected
    trend: str              # "improving", "stable", "degrading"


class StabilityScorer:
    """
    Track and score test stability over time.

    Uses a local JSON file for persistence.
    Each test gets an entry with its last N executions.
    """

    MAX_HISTORY = 20  # Agnox uses last 20 executions

    def __init__(self, history_file: Optional[Path] = None):
        self.history_file = history_file or Path(".failscope/stability.json")
        self.history: dict[str, list[dict]] = self._load_history()

    def _load_history(self) -> dict:
        if self.history_file.exists():
            try:
                return json.loads(self.history_file.read_text())
            except (json.JSONDecodeError, OSError):
                return {}
        return {}

    def _save_history(self):
        self.history_file.parent.mkdir(parents=True, exist_ok=True)
        self.history_file.write_text(json.dumps(self.history, indent=2))

    def record(self, test_name: str, passed: bool, duration: float, error_hash: Optional[str] = None):
        """Record a test execution result."""
        record = {
            "passed": passed,
            "duration": duration,
            "timestamp": time.time(),
            "error_hash": error_hash,
        }

        if test_name not in self.history:
            self.history[test_name] = []

        self.history[test_name].append(record)

        # Keep only last N runs
        if len(self.history[test_name]) > self.MAX_HISTORY:
            self.history[test_name] = self.history[test_name][-self.MAX_HISTORY:]

        self._save_history()

    def score(self, test_name: str, current_duration: Optional[float] = None) -> TestStability:
        """Calculate stability metrics for a test."""
        records = self.history.get(test_name, [])
        total_runs = len(records)

        if total_runs < MIN_RUNS_FOR_GRADING:
            passes = sum(1 for r in records if r["passed"])
            pass_rate = passes / total_runs if total_runs > 0 else 0.0
            durations = [r["duration"] for r in records if r["duration"] > 0]
            avg_duration = sum(durations) / len(durations) if durations else 0.0
            recent_failures = sum(1 for r in records if not r["passed"])
            return TestStability(
                test_name=test_name,
                grade=StabilityGrade.UNGRADED,
                pass_rate=pass_rate,
                flakiness_score=0,
                verdict=FlakinessVerdict.STABLE,
                total_runs=total_runs,
                recent_failures=recent_failures,
                avg_duration=avg_duration,
                is_slow=False,
                trend="insufficient_data",
            )

        # Calculate pass rate
        passes = sum(1 for r in records if r["passed"])
        pass_rate = passes / total_runs

        # Calculate grade
        grade = self._calculate_grade(pass_rate)

        # Calculate flakiness score (0-100)
        flakiness_score = self._calculate_flakiness(records)
        verdict = self._get_verdict(flakiness_score)

        # Calculate duration metrics
        durations = [r["duration"] for r in records if r["duration"] > 0]
        avg_duration = sum(durations) / len(durations) if durations else 0.0

        # Performance degradation detection
        is_slow = False
        if current_duration and avg_duration > 0:
            is_slow = (
                current_duration > avg_duration * SLOW_THRESHOLD_MULTIPLIER
                or current_duration - avg_duration > SLOW_THRESHOLD_ABS_MS / 1000
            )

        # Trend analysis
        trend = self._detect_trend(records)

        # Recent failures
        recent = records[-10:] if len(records) >= 10 else records
        recent_failures = sum(1 for r in recent if not r["passed"])

        return TestStability(
            test_name=test_name,
            grade=grade,
            pass_rate=pass_rate,
            flakiness_score=flakiness_score,
            verdict=verdict,
            total_runs=total_runs,
            recent_failures=recent_failures,
            avg_duration=avg_duration,
            is_slow=is_slow,
            trend=trend,
        )

    def _calculate_grade(self, pass_rate: float) -> StabilityGrade:
        """A-F grading aligned with Agnox's system."""
        if pass_rate >= 0.95:
            return StabilityGrade.A
        elif pass_rate >= 0.80:
            return StabilityGrade.B
        elif pass_rate >= 0.65:
            return StabilityGrade.C
        elif pass_rate >= 0.50:
            return StabilityGrade.D
        else:
            return StabilityGrade.F

    def _calculate_flakiness(self, records: list[dict]) -> int:
        """
        Calculate flakiness score (0-100).

        Factors:
        - Pass/fail alternation frequency (high = flaky)
        - Unique error hashes (many = environmental)
        - Recent vs historical stability
        """
        if len(records) < 2:
            return 0

        # Factor 1: Status alternation (0-40 points)
        alternations = 0
        for i in range(1, len(records)):
            if records[i]["passed"] != records[i - 1]["passed"]:
                alternations += 1
        max_alternations = len(records) - 1
        alternation_score = int((alternations / max_alternations) * 40)

        # Factor 2: Failure rate (0-30 points)
        failures = sum(1 for r in records if not r["passed"])
        failure_rate = failures / len(records)
        # Flakiness peaks at 50% failure rate (not 100%)
        failure_score = int(min(failure_rate * 2, 1.0) * 30)

        # Factor 3: Unique error hashes (0-30 points)
        error_hashes = set(r.get("error_hash") for r in records if r.get("error_hash"))
        if failures > 0:
            hash_diversity = len(error_hashes) / max(failures, 1)
            hash_score = int(min(hash_diversity, 1.0) * 30)
        else:
            hash_score = 0

        return min(alternation_score + failure_score + hash_score, 100)

    def _get_verdict(self, score: int) -> FlakinessVerdict:
        """Map score to verdict (Agnox's scale)."""
        if score <= 20:
            return FlakinessVerdict.STABLE
        elif score <= 45:
            return FlakinessVerdict.MILDLY_FLAKY
        elif score <= 70:
            return FlakinessVerdict.FLAKY
        else:
            return FlakinessVerdict.HIGHLY_UNSTABLE

    def _detect_trend(self, records: list[dict]) -> str:
        """Detect if test stability is improving or degrading."""
        if len(records) < 6:
            return "insufficient_data"

        mid = len(records) // 2
        first_half = records[:mid]
        second_half = records[mid:]

        first_rate = sum(1 for r in first_half if r["passed"]) / len(first_half)
        second_rate = sum(1 for r in second_half if r["passed"]) / len(second_half)

        diff = second_rate - first_rate
        if diff > 0.1:
            return "improving"
        elif diff < -0.1:
            return "degrading"
        return "stable"

    def get_summary(self) -> dict:
        """Get stability summary for all tracked tests."""
        summary = {
            "total_tests": len(self.history),
            "grades": {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0, "UNGRADED": 0},
            "flaky_tests": [],
            "slow_tests": [],
        }

        for test_name in self.history:
            stability = self.score(test_name)
            summary["grades"][stability.grade.value] += 1

            if stability.flakiness_score > 45:
                summary["flaky_tests"].append({
                    "name": test_name,
                    "score": stability.flakiness_score,
                    "verdict": stability.verdict.value,
                })

        return summary
