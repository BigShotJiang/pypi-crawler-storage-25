from __future__ import annotations

import asyncio
import contextlib
import importlib
import inspect
import json
import platform
import sys
import time
import urllib.parse
from collections.abc import Awaitable, Callable, Iterable, Mapping
from pathlib import Path
from types import ModuleType
from typing import Any

import aiohttp

from .cog import Cog, CommandDefinition, ListenerDefinition, SlashCommandDefinition
from .context import Context, SlashContext
from .errors import (
    CogError,
    ExtensionAlreadyLoaded,
    ExtensionNotFound,
    ExtensionNotLoaded,
    GatewayError,
    HTTPException,
    NoEntryPointError,
)
from .intents import Intents
from .logging import Logger, get_logger

DISCORD_API_BASE = "https://discord.com/api/v10"
DISCORD_GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"
DEFAULT_INTENTS = Intents.for_commands()
VALID_STATUSES = {"online", "idle", "dnd", "invisible"}


class Bot:
    def __init__(
        self,
        prefix: str | Iterable[str],
        intents: int | Intents | None = None,
        *,
        status: str = "online",
        status_text: str | None = None,
        auto_sync_commands: bool = True,
        enable_logging: bool = False,
        log_level: str | int = "INFO",
        logger: Logger | None = None,
        reconnect: bool = True,
        reconnect_delay: float = 5.0,
        max_reconnects: int | None = None,
        extensions: Iterable[str] | None = None,
    ) -> None:
        self.prefixes = self._normalize_prefixes(prefix)
        self.prefix = self.prefixes[0] if len(self.prefixes) == 1 else self.prefixes
        self.intents = self._coerce_intents(intents if intents is not None else DEFAULT_INTENTS.copy())
        self.status = self._validate_status(status)
        self.status_text = status_text
        self.auto_sync_commands = auto_sync_commands
        self.reconnect = reconnect
        self.reconnect_delay = reconnect_delay
        self.max_reconnects = max_reconnects
        self.token: str | None = None
        self.user: Mapping[str, Any] | None = None
        self.application_id: str | None = None
        self.session: aiohttp.ClientSession | None = None
        self.ws: aiohttp.ClientWebSocketResponse | None = None
        self.sequence: int | None = None
        self.session_id: str | None = None
        self._events: dict[str, list[ListenerDefinition]] = {}
        self._commands: dict[str, CommandDefinition] = {}
        self._aliases: dict[str, str] = {}
        self._slash_commands: dict[str, SlashCommandDefinition] = {}
        self._cogs: dict[str, Cog] = {}
        self._extensions: dict[str, ModuleType] = {}
        self._startup_extensions = list(extensions or ())
        self._startup_loaded = False
        self._extension_stack: list[str] = []
        self._heartbeat_interval: float | None = None
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._heartbeat_ack = True
        self._last_heartbeat_sent_at: float | None = None
        self._gateway_started_at: float | None = None
        self._tasks: set[asyncio.Task[Any]] = set()
        self._ready = asyncio.Event()
        self._closing = False
        self.latency: float = 0.0
        self.logger = logger or get_logger("suneord", enabled=enable_logging, level=log_level)
        self.http = self.http_request

    @property
    def commands(self) -> dict[str, Callable[..., Awaitable[Any]]]:
        return {name: command.callback for name, command in self._commands.items()}

    @property
    def slash_commands(self) -> dict[str, dict[str, Any]]:
        return {
            name: {
                "callback": command.callback,
                "name": command.name,
                "description": command.description,
                "guild_id": command.guild_id,
                "cog": command.cog,
            }
            for name, command in self._slash_commands.items()
        }

    @property
    def cogs(self) -> dict[str, Cog]:
        return dict(self._cogs)

    @property
    def extensions(self) -> tuple[str, ...]:
        return tuple(self._extensions)

    @property
    def is_ready(self) -> bool:
        return self._ready.is_set()

    @property
    def is_closed(self) -> bool:
        return self._closing

    async def setup_hook(self) -> None:
        return None

    def event(self, coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
        return self.add_listener(coro, name=coro.__name__)

    def add_listener(
        self,
        coro: Callable[..., Awaitable[Any]],
        *,
        name: str | None = None,
        cog: Cog | None = None,
    ) -> Callable[..., Awaitable[Any]]:
        if not inspect.iscoroutinefunction(coro):
            raise TypeError("Event handler must be async.")
        event_name = (name or coro.__name__).lower()
        if not event_name.startswith("on_"):
            event_name = f"on_{event_name}"
        listener = ListenerDefinition(
            callback=coro,
            event_name=event_name,
            cog=cog,
            extension=self._current_extension,
        )
        self._events.setdefault(event_name, []).append(listener)
        return coro

    def remove_listener(self, coro: Callable[..., Awaitable[Any]], *, name: str | None = None) -> None:
        event_name = (name or coro.__name__).lower()
        if not event_name.startswith("on_"):
            event_name = f"on_{event_name}"
        listeners = self._events.get(event_name, [])
        remaining = [listener for listener in listeners if listener.callback is not coro]
        if remaining:
            self._events[event_name] = remaining
        else:
            self._events.pop(event_name, None)

    def command(
        self,
        name: str | None = None,
        *,
        aliases: Iterable[str] | None = None,
        description: str | None = None,
    ) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
        def decorator(coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
            self.add_command(coro, name=name, aliases=aliases, description=description)
            return coro

        return decorator

    def add_command(
        self,
        coro: Callable[..., Awaitable[Any]],
        *,
        name: str | None = None,
        aliases: Iterable[str] | None = None,
        description: str | None = None,
        cog: Cog | None = None,
    ) -> Callable[..., Awaitable[Any]]:
        if not inspect.iscoroutinefunction(coro):
            raise TypeError("Command handler must be async.")
        command_name = (name or coro.__name__).lower()
        alias_tuple = tuple(alias.lower() for alias in (aliases or ()))
        if command_name in self._commands or command_name in self._aliases:
            raise CogError(f"Command '{command_name}' is already registered.")
        for alias in alias_tuple:
            if alias in self._aliases or alias in self._commands:
                raise CogError(f"Alias '{alias}' is already registered.")
        definition = CommandDefinition(
            callback=coro,
            name=command_name,
            aliases=alias_tuple,
            description=description,
            cog=cog,
            extension=self._current_extension,
        )
        self._commands[command_name] = definition
        for alias in alias_tuple:
            self._aliases[alias] = command_name
        return coro

    def slash_command(
        self,
        *,
        name: str,
        description: str,
        guild_id: str | None = None,
    ) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
        def decorator(coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
            self.add_slash_command(coro, name=name, description=description, guild_id=guild_id)
            return coro

        return decorator

    def add_slash_command(
        self,
        coro: Callable[..., Awaitable[Any]],
        *,
        name: str,
        description: str,
        guild_id: str | None = None,
        cog: Cog | None = None,
    ) -> Callable[..., Awaitable[Any]]:
        if not inspect.iscoroutinefunction(coro):
            raise TypeError("Slash command handler must be async.")
        command_name = name.lower()
        if command_name in self._slash_commands:
            raise CogError(f"Slash command '{command_name}' is already registered.")
        self._slash_commands[command_name] = SlashCommandDefinition(
            callback=coro,
            name=command_name,
            description=description,
            guild_id=guild_id,
            cog=cog,
            extension=self._current_extension,
        )
        return coro

    def walk_commands(self) -> list[CommandDefinition]:
        return list(self._commands.values())

    def walk_slash_commands(self) -> list[SlashCommandDefinition]:
        return list(self._slash_commands.values())

    def get_command(self, name: str) -> Callable[..., Awaitable[Any]] | None:
        command_name = self._aliases.get(name.lower(), name.lower())
        command = self._commands.get(command_name)
        return None if command is None else command.callback

    def get_command_definition(self, name: str) -> CommandDefinition | None:
        command_name = self._aliases.get(name.lower(), name.lower())
        return self._commands.get(command_name)

    def get_slash_command(self, name: str) -> Mapping[str, Any] | None:
        command = self._slash_commands.get(name.lower())
        if command is None:
            return None
        return {
            "callback": command.callback,
            "name": command.name,
            "description": command.description,
            "guild_id": command.guild_id,
            "cog": command.cog,
        }

    def get_cog(self, name: str) -> Cog | None:
        return self._cogs.get(name)

    def remove_command(self, name: str) -> Callable[..., Awaitable[Any]] | None:
        command_name = self._aliases.pop(name.lower(), name.lower())
        definition = self._commands.pop(command_name, None)
        if definition is None:
            return None
        for alias in definition.aliases:
            self._aliases.pop(alias, None)
        return definition.callback

    def remove_slash_command(self, name: str) -> Mapping[str, Any] | None:
        command = self._slash_commands.pop(name.lower(), None)
        if command is None:
            return None
        return {
            "callback": command.callback,
            "name": command.name,
            "description": command.description,
            "guild_id": command.guild_id,
            "cog": command.cog,
        }

    async def add_cog(self, cog: Cog) -> Cog:
        cog_name = cog.qualified_name
        if cog_name in self._cogs:
            raise CogError(f"Cog '{cog_name}' is already loaded.")
        cog.bot = self
        setattr(cog, "__suneord_extension__", self._current_extension)
        self._cogs[cog_name] = cog
        try:
            for command in cog.walk_commands():
                self.add_command(
                    command.callback,
                    name=command.name,
                    aliases=command.aliases,
                    description=command.description,
                    cog=cog,
                )
            for slash in cog.walk_slash_commands():
                self.add_slash_command(
                    slash.callback,
                    name=slash.name,
                    description=slash.description,
                    guild_id=slash.guild_id,
                    cog=cog,
                )
            for listener in cog.walk_listeners():
                self.add_listener(listener.callback, name=listener.event_name, cog=cog)
            await self._maybe_await(cog.cog_load())
        except Exception:
            await self._remove_cog_registrations(cog, call_hook=False)
            self._cogs.pop(cog_name, None)
            raise
        return cog

    async def remove_cog(self, name: str) -> Cog | None:
        cog = self._cogs.pop(name, None)
        if cog is None:
            return None
        await self._remove_cog_registrations(cog, call_hook=True)
        return cog

    async def load_extension(self, name: str) -> ModuleType:
        if name in self._extensions:
            raise ExtensionAlreadyLoaded(f"Extension '{name}' is already loaded.")
        try:
            module = importlib.import_module(name)
        except ModuleNotFoundError as exc:
            raise ExtensionNotFound(f"Extension '{name}' was not found.") from exc

        setup = getattr(module, "setup", None)
        if setup is None:
            raise NoEntryPointError(f"Extension '{name}' does not define setup(bot).")

        self._extension_stack.append(name)
        try:
            result = setup(self)
            if inspect.isawaitable(result):
                await result
        except Exception:
            with contextlib.suppress(Exception):
                await self._purge_extension(name)
            sys.modules.pop(name, None)
            raise
        finally:
            self._extension_stack.pop()

        self._extensions[name] = module
        self.logger.info("Loaded extension {}", name)
        return module

    async def unload_extension(self, name: str) -> None:
        module = self._extensions.pop(name, None)
        if module is None:
            raise ExtensionNotLoaded(f"Extension '{name}' is not loaded.")
        await self._purge_extension(name)
        teardown = getattr(module, "teardown", None)
        if teardown is not None:
            result = teardown(self)
            if inspect.isawaitable(result):
                await result
        sys.modules.pop(name, None)
        importlib.invalidate_caches()
        self.logger.info("Unloaded extension {}", name)

    async def reload_extension(self, name: str) -> ModuleType:
        await self.unload_extension(name)
        return await self.load_extension(name)

    async def load_extensions_from(
        self,
        directory: str | Path,
        *,
        package: str | None = None,
        recursive: bool = False,
    ) -> list[str]:
        path = Path(directory)
        if not path.is_absolute() and package is None:
            package = ".".join(path.parts)
        if path.is_absolute() and package is None:
            raise ValueError("package must be provided when loading extensions from an absolute path.")
        pattern = "**/*.py" if recursive else "*.py"
        loaded: list[str] = []
        for file in sorted(path.glob(pattern)):
            if file.name == "__init__.py" or file.name.startswith("_"):
                continue
            relative = file.with_suffix("").relative_to(path)
            module_name = ".".join(part for part in (package, *relative.parts) if part)
            await self.load_extension(module_name)
            loaded.append(module_name)
        return loaded

    def add_startup_extension(self, name: str) -> None:
        if name not in self._startup_extensions:
            self._startup_extensions.append(name)

    async def wait_until_ready(self) -> None:
        await self._ready.wait()

    def enable_logging(self) -> None:
        self.logger.enable()

    def disable_logging(self) -> None:
        self.logger.disable()

    def run(self, token: str) -> None:
        try:
            asyncio.run(self.start(token))
        except KeyboardInterrupt:
            pass

    async def start(self, token: str) -> None:
        self.token = token
        self._ready.clear()
        self._closing = False
        headers = {
            "Authorization": f"Bot {token}",
            "User-Agent": f"suneord (python aiohttp; {platform.system().lower()})",
        }
        async with aiohttp.ClientSession(
            headers=headers,
            json_serialize=lambda data: json.dumps(data, ensure_ascii=False),
        ) as session:
            self.session = session
            try:
                await self._load_startup_extensions()
                await self.setup_hook()
                attempts = 0
                while not self._closing:
                    try:
                        await self._connect_gateway()
                    except asyncio.CancelledError:
                        raise
                    except Exception as exc:
                        if self._closing:
                            break
                        if not self.reconnect:
                            raise
                        attempts += 1
                        if self.max_reconnects is not None and attempts > self.max_reconnects:
                            raise
                        self.logger.error(
                            "Gateway disconnected, retrying in {}s",
                            self.reconnect_delay,
                            exc_info=exc,
                        )
                        await self._cleanup_gateway()
                        await asyncio.sleep(self.reconnect_delay)
                        continue
                    else:
                        if self._closing or not self.reconnect:
                            break
                        attempts = 0
                        self.logger.warning("Gateway connection closed, reconnecting in {}s", self.reconnect_delay)
                        await self._cleanup_gateway()
                        await asyncio.sleep(self.reconnect_delay)
            finally:
                await self.close()

    async def close(self) -> None:
        self._closing = True
        self._ready.clear()
        await self._cleanup_gateway()
        if self._tasks:
            tasks = tuple(self._tasks)
            for task in tasks:
                task.cancel()
            for task in tasks:
                with contextlib.suppress(asyncio.CancelledError):
                    await task
            self._tasks.clear()
        if self.session is not None and not self.session.closed:
            await self.session.close()
        self.session = None

    async def http_request(self, method: str, path: str, *, retries: int = 3, **kwargs: Any) -> Any:
        if self.session is None:
            raise RuntimeError("HTTP session is not started.")

        url = path if path.startswith("https://") else f"{DISCORD_API_BASE}{path}"
        for attempt in range(retries + 1):
            async with self.session.request(method, url, **kwargs) as response:
                if response.status == 429:
                    payload = await response.json(content_type=None)
                    retry_after = float(payload.get("retry_after", 1))
                    self.logger.warning("Rate limited on {} {}, retry_after={}s", method, path, retry_after)
                    if attempt >= retries:
                        raise HTTPException(response.status, str(payload), payload)
                    await asyncio.sleep(retry_after)
                    continue
                if response.status >= 400:
                    body = await response.text()
                    raise HTTPException(response.status, body)
                if response.content_type == "application/json":
                    return await response.json()
                return await response.text()
        raise RuntimeError("HTTP request exhausted all retry attempts.")

    async def send_message(
        self,
        channel_id: str,
        content: str | None = None,
        *,
        embed: Any | None = None,
        embeds: list[Any] | None = None,
        tts: bool = False,
        allowed_mentions: Mapping[str, Any] | None = None,
    ) -> Any:
        payload = self._build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            allowed_mentions=allowed_mentions,
        )
        if tts:
            payload["tts"] = True
        return await self.http_request("POST", f"/channels/{channel_id}/messages", json=payload)

    async def edit_message(
        self,
        channel_id: str,
        message_id: str,
        *,
        content: str | None = None,
        embed: Any | None = None,
        embeds: list[Any] | None = None,
        allowed_mentions: Mapping[str, Any] | None = None,
    ) -> Any:
        payload = self._build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            allowed_mentions=allowed_mentions,
        )
        return await self.http_request("PATCH", f"/channels/{channel_id}/messages/{message_id}", json=payload)

    async def delete_message(self, channel_id: str, message_id: str) -> None:
        await self.http_request("DELETE", f"/channels/{channel_id}/messages/{message_id}")

    async def fetch_message(self, channel_id: str, message_id: str) -> Any:
        return await self.http_request("GET", f"/channels/{channel_id}/messages/{message_id}")

    async def fetch_messages(
        self,
        channel_id: str,
        *,
        limit: int = 50,
        before: str | None = None,
        after: str | None = None,
        around: str | None = None,
    ) -> Any:
        params: dict[str, Any] = {"limit": limit}
        if before is not None:
            params["before"] = before
        if after is not None:
            params["after"] = after
        if around is not None:
            params["around"] = around
        return await self.http_request("GET", f"/channels/{channel_id}/messages", params=params)

    async def bulk_delete_messages(self, channel_id: str, message_ids: Iterable[str]) -> None:
        messages = list(message_ids)
        if not messages:
            return
        await self.http_request("POST", f"/channels/{channel_id}/messages/bulk-delete", json={"messages": messages})

    async def pin_message(self, channel_id: str, message_id: str) -> None:
        await self.http_request("PUT", f"/channels/{channel_id}/pins/{message_id}")

    async def unpin_message(self, channel_id: str, message_id: str) -> None:
        await self.http_request("DELETE", f"/channels/{channel_id}/pins/{message_id}")

    async def fetch_channel(self, channel_id: str) -> Any:
        return await self.http_request("GET", f"/channels/{channel_id}")

    async def fetch_guild(self, guild_id: str) -> Any:
        return await self.http_request("GET", f"/guilds/{guild_id}")

    async def fetch_guild_member(self, guild_id: str, user_id: str) -> Any:
        return await self.http_request("GET", f"/guilds/{guild_id}/members/{user_id}")

    async def fetch_user(self, user_id: str) -> Any:
        return await self.http_request("GET", f"/users/{user_id}")

    async def fetch_me(self) -> Any:
        return await self.http_request("GET", "/users/@me")

    async def create_dm(self, user_id: str) -> Any:
        return await self.http_request("POST", "/users/@me/channels", json={"recipient_id": user_id})

    async def send_dm(
        self,
        user_id: str,
        content: str | None = None,
        *,
        embed: Any | None = None,
        embeds: list[Any] | None = None,
        tts: bool = False,
        allowed_mentions: Mapping[str, Any] | None = None,
    ) -> Any:
        channel = await self.create_dm(user_id)
        return await self.send_message(
            channel["id"],
            content=content,
            embed=embed,
            embeds=embeds,
            tts=tts,
            allowed_mentions=allowed_mentions,
        )

    async def add_reaction(self, channel_id: str, message_id: str, emoji: str) -> None:
        encoded = urllib.parse.quote(emoji)
        await self.http_request("PUT", f"/channels/{channel_id}/messages/{message_id}/reactions/{encoded}/@me")

    async def remove_reaction(self, channel_id: str, message_id: str, emoji: str, user_id: str = "@me") -> None:
        encoded = urllib.parse.quote(emoji)
        await self.http_request("DELETE", f"/channels/{channel_id}/messages/{message_id}/reactions/{encoded}/{user_id}")

    async def trigger_typing(self, channel_id: str) -> None:
        await self.http_request("POST", f"/channels/{channel_id}/typing")

    async def change_nickname(self, guild_id: str, nick: str | None) -> Any:
        return await self.http_request("PATCH", f"/guilds/{guild_id}/members/@me", json={"nick": nick})

    async def kick_member(self, guild_id: str, user_id: str, *, reason: str | None = None) -> None:
        headers = {"X-Audit-Log-Reason": reason} if reason else None
        await self.http_request("DELETE", f"/guilds/{guild_id}/members/{user_id}", headers=headers)

    async def ban_member(
        self,
        guild_id: str,
        user_id: str,
        *,
        delete_message_seconds: int = 0,
        reason: str | None = None,
    ) -> None:
        headers = {"X-Audit-Log-Reason": reason} if reason else None
        await self.http_request(
            "PUT",
            f"/guilds/{guild_id}/bans/{user_id}",
            headers=headers,
            json={"delete_message_seconds": delete_message_seconds},
        )

    async def unban_member(self, guild_id: str, user_id: str, *, reason: str | None = None) -> None:
        headers = {"X-Audit-Log-Reason": reason} if reason else None
        await self.http_request("DELETE", f"/guilds/{guild_id}/bans/{user_id}", headers=headers)

    async def sync_application_commands(self) -> None:
        if self.application_id is None:
            raise RuntimeError("Application ID is not available yet.")

        global_commands = []
        guild_commands: dict[str, list[dict[str, Any]]] = {}

        for command in self._slash_commands.values():
            payload = {
                "name": command.name,
                "description": command.description,
                "type": 1,
            }
            if command.guild_id is None:
                global_commands.append(payload)
            else:
                guild_commands.setdefault(command.guild_id, []).append(payload)

        await self.http_request("PUT", f"/applications/{self.application_id}/commands", json=global_commands)
        for guild_id, commands in guild_commands.items():
            await self.http_request("PUT", f"/applications/{self.application_id}/guilds/{guild_id}/commands", json=commands)

    async def set_presence(self, *, status: str | None = None, text: str | None = None) -> None:
        if status is not None:
            self.status = self._validate_status(status)
        self.status_text = text
        if self.ws is not None:
            await self.ws.send_json({"op": 3, "d": self._presence_payload()})

    def create_task(self, coro: Awaitable[Any], *, name: str | None = None) -> asyncio.Task[Any]:
        task = asyncio.create_task(coro, name=name)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        task.add_done_callback(self._task_done_callback)
        return task

    def dispatch(self, event_name: str, *args: Any) -> None:
        normalized = event_name.lower()
        if not normalized.startswith("on_"):
            normalized = f"on_{normalized}"
        listeners = tuple(self._events.get(normalized, ()))
        for listener in listeners:
            self.create_task(self._run_listener(listener, *args), name=f"listener:{normalized}")

    async def _connect_gateway(self) -> None:
        if self.session is None:
            raise RuntimeError("HTTP session is not started.")
        async with self.session.ws_connect(DISCORD_GATEWAY_URL) as ws:
            self.ws = ws
            self._gateway_started_at = time.perf_counter()
            self.logger.info("Connected to Discord gateway")
            await self._gateway_loop()

    async def _cleanup_gateway(self) -> None:
        self._ready.clear()
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._heartbeat_task
            self._heartbeat_task = None
        if self.ws is not None and not self.ws.closed:
            await self.ws.close()
        self.ws = None
        self._heartbeat_interval = None
        self._heartbeat_ack = True
        self._last_heartbeat_sent_at = None

    async def _gateway_loop(self) -> None:
        if self.ws is None:
            raise RuntimeError("Gateway websocket is not started.")
        async for message in self.ws:
            if message.type == aiohttp.WSMsgType.TEXT:
                await self._handle_gateway_payload(json.loads(message.data))
                continue
            if message.type == aiohttp.WSMsgType.CLOSED:
                return
            if message.type == aiohttp.WSMsgType.ERROR:
                raise GatewayError("Discord gateway websocket error.")

    async def _handle_gateway_payload(self, payload: Mapping[str, Any]) -> None:
        op = payload.get("op")
        event_name = payload.get("t")
        data = payload.get("d")
        self.sequence = payload.get("s", self.sequence)

        if op == 10:
            self._heartbeat_interval = data["heartbeat_interval"] / 1000
            await self._start_heartbeat()
            await self._identify()
            await self._send_heartbeat()
            return

        if op == 11:
            self._heartbeat_ack = True
            if self._last_heartbeat_sent_at is not None:
                self.latency = time.perf_counter() - self._last_heartbeat_sent_at
            return

        if op == 0 and event_name is not None:
            await self._dispatch(event_name, data)
            return

        if op == 7:
            raise GatewayError("Discord gateway requested reconnect.")

        if op == 9:
            raise GatewayError("Discord gateway invalid session.")

    async def _dispatch(self, event_name: str, data: Mapping[str, Any]) -> None:
        if event_name == "READY":
            self.session_id = data["session_id"]
            self.user = data["user"]
            application = data.get("application", {})
            self.application_id = application.get("id") or data["user"].get("id")
            if self._gateway_started_at is not None:
                self.latency = time.perf_counter() - self._gateway_started_at
            if self.auto_sync_commands and self._slash_commands:
                await self.sync_application_commands()
            self._ready.set()
            self.logger.success("Gateway ready as {}", self.user.get("username", "unknown"))

        self.dispatch(f"on_{event_name.lower()}", *self._build_event_args(event_name, data))

        if event_name == "MESSAGE_CREATE":
            await self._process_message(data)
        elif event_name == "INTERACTION_CREATE":
            await self._process_interaction(data)

    def _build_event_args(self, event_name: str, data: Mapping[str, Any]) -> tuple[Any, ...]:
        if event_name == "READY":
            return ()
        return (data,)

    async def _process_message(self, message: Mapping[str, Any]) -> None:
        author = message.get("author", {})
        if author.get("bot"):
            return

        content = message.get("content", "")
        prefix = self._match_prefix(content)
        if prefix is None:
            return

        parts = content[len(prefix) :].strip().split()
        if not parts:
            return

        command_key = parts[0].lower()
        command_name = self._aliases.get(command_key, command_key)
        command = self._commands.get(command_name)
        if command is None:
            return

        ctx = Context(
            self,
            message=message,
            command_name=command.name,
            args=parts[1:],
            command=command.callback,
            cog=command.cog,
        )
        self.dispatch("on_command", ctx)
        self.create_task(self._invoke_message_command(command, ctx), name=f"command:{command.name}")

    async def _invoke_message_command(self, command: CommandDefinition, ctx: Context) -> None:
        try:
            await command.callback(ctx, *ctx.args)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            await self._handle_command_error("on_command_error", ctx, command.cog, exc)
        else:
            self.dispatch("on_command_completion", ctx)

    async def _process_interaction(self, interaction: Mapping[str, Any]) -> None:
        if interaction.get("type") != 2:
            return
        data = interaction.get("data", {})
        command_name = data.get("name", "").lower()
        command = self._slash_commands.get(command_name)
        if command is None:
            return

        ctx = SlashContext(
            self,
            interaction=interaction,
            command_name=command.name,
            command=command.callback,
            cog=command.cog,
        )
        self.dispatch("on_slash_command", ctx)
        self.create_task(self._invoke_slash_command(command, ctx), name=f"slash:{command.name}")

    async def _invoke_slash_command(self, command: SlashCommandDefinition, ctx: SlashContext) -> None:
        try:
            await command.callback(ctx)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            await self._handle_command_error("on_slash_command_error", ctx, command.cog, exc)
        else:
            self.dispatch("on_slash_command_completion", ctx)

    async def _handle_command_error(self, event_name: str, ctx: Context | SlashContext, cog: Cog | None, error: Exception) -> None:
        handled = False
        active_error = error
        if cog is not None:
            try:
                await cog.cog_command_error(ctx, active_error)
                handled = True
            except Exception as cog_error:
                if cog_error is not active_error:
                    active_error = cog_error
        if event_name in self._events:
            self.dispatch(event_name, ctx, active_error)
            handled = True
        if not handled:
            self.logger.exception("Unhandled command error in {}", ctx.command_name, exc_info=active_error)

    async def _run_listener(self, listener: ListenerDefinition, *args: Any) -> None:
        try:
            await listener.callback(*args)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            if listener.event_name != "on_error" and "on_error" in self._events:
                self.dispatch("on_error", listener.event_name, exc, *args)
                return
            self.logger.exception("Unhandled listener error in {}", listener.event_name, exc_info=exc)

    async def _start_heartbeat(self) -> None:
        if self._heartbeat_interval is None:
            return
        if self._heartbeat_task is not None and not self._heartbeat_task.done():
            return
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def _heartbeat_loop(self) -> None:
        assert self._heartbeat_interval is not None
        while True:
            await asyncio.sleep(self._heartbeat_interval)
            if not self._heartbeat_ack:
                raise GatewayError("Discord gateway heartbeat was not acknowledged.")
            await self._send_heartbeat()

    async def _send_heartbeat(self) -> None:
        if self.ws is None:
            return
        self._heartbeat_ack = False
        self._last_heartbeat_sent_at = time.perf_counter()
        await self.ws.send_json({"op": 1, "d": self.sequence})

    async def _identify(self) -> None:
        if self.ws is None or self.token is None:
            raise RuntimeError("Bot is not ready to identify.")
        await self.ws.send_json(
            {
                "op": 2,
                "d": {
                    "token": self.token,
                    "intents": int(self.intents),
                    "properties": {
                        "os": platform.system().lower(),
                        "browser": "suneord",
                        "device": "suneord",
                    },
                    "presence": self._presence_payload(),
                },
            }
        )

    def _presence_payload(self) -> dict[str, Any]:
        activities: list[dict[str, Any]] = []
        if self.status_text:
            activities.append({"name": "Custom Status", "type": 4, "state": self.status_text})
        return {
            "since": None,
            "activities": activities,
            "status": self.status,
            "afk": False,
        }

    def _build_message_payload(
        self,
        *,
        content: str | None = None,
        embed: Any | None = None,
        embeds: list[Any] | None = None,
        allowed_mentions: Mapping[str, Any] | None = None,
        message_reference: Mapping[str, Any] | None = None,
        flags: int | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if content is not None:
            payload["content"] = content
        if embed is not None:
            payload["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds:
            payload["embeds"] = [item.to_dict() if hasattr(item, "to_dict") else item for item in embeds]
        if allowed_mentions is not None:
            payload["allowed_mentions"] = dict(allowed_mentions)
        if message_reference is not None:
            payload["message_reference"] = dict(message_reference)
        if flags is not None:
            payload["flags"] = flags
        return payload

    def _validate_status(self, status: str) -> str:
        lowered = status.lower()
        if lowered not in VALID_STATUSES:
            raise ValueError("status must be one of: online, idle, dnd, invisible")
        return lowered

    def _coerce_intents(self, intents: int | Intents) -> Intents:
        if isinstance(intents, Intents):
            return intents.copy()
        return Intents(intents)

    def _normalize_prefixes(self, prefix: str | Iterable[str]) -> tuple[str, ...]:
        if isinstance(prefix, str):
            prefixes = (prefix,)
        else:
            prefixes = tuple(prefix)
        if not prefixes:
            raise ValueError("At least one prefix must be provided.")
        return tuple(sorted(prefixes, key=len, reverse=True))

    def _match_prefix(self, content: str) -> str | None:
        for prefix in self.prefixes:
            if content.startswith(prefix):
                return prefix
        return None

    @property
    def _current_extension(self) -> str | None:
        return self._extension_stack[-1] if self._extension_stack else None

    async def _load_startup_extensions(self) -> None:
        if self._startup_loaded:
            return
        for extension in self._startup_extensions:
            await self.load_extension(extension)
        self._startup_loaded = True

    async def _remove_cog_registrations(self, cog: Cog, *, call_hook: bool) -> None:
        if call_hook:
            await self._maybe_await(cog.cog_unload())

        for command_name, command in list(self._commands.items()):
            if command.cog is cog:
                self.remove_command(command_name)
        for slash_name, command in list(self._slash_commands.items()):
            if command.cog is cog:
                self.remove_slash_command(slash_name)
        for event_name, listeners in list(self._events.items()):
            remaining = [listener for listener in listeners if listener.cog is not cog]
            if remaining:
                self._events[event_name] = remaining
            else:
                self._events.pop(event_name, None)

    async def _purge_extension(self, name: str) -> None:
        for cog_name, cog in list(self._cogs.items()):
            if getattr(cog, "__suneord_extension__", None) == name:
                await self.remove_cog(cog_name)
        for command_name, command in list(self._commands.items()):
            if command.extension == name and command.cog is None:
                self.remove_command(command_name)
        for slash_name, command in list(self._slash_commands.items()):
            if command.extension == name and command.cog is None:
                self.remove_slash_command(slash_name)
        for event_name, listeners in list(self._events.items()):
            remaining = [listener for listener in listeners if listener.extension != name]
            if remaining:
                self._events[event_name] = remaining
            else:
                self._events.pop(event_name, None)

    def _task_done_callback(self, task: asyncio.Task[Any]) -> None:
        with contextlib.suppress(asyncio.CancelledError):
            exception = task.exception()
            if exception is not None:
                self.logger.exception("Background task failed", exc_info=exception)

    async def _maybe_await(self, value: Any) -> Any:
        if inspect.isawaitable(value):
            return await value
        return value
