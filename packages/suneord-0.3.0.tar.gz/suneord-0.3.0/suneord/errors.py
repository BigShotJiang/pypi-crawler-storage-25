from __future__ import annotations

from typing import Any


class SuneordError(Exception):
    """Base exception for the library."""


class HTTPException(SuneordError):
    """Raised when the Discord API returns an error response."""

    def __init__(self, status: int, message: str, payload: Any | None = None) -> None:
        super().__init__(f"Discord API error {status}: {message}")
        self.status = status
        self.message = message
        self.payload = payload


class GatewayError(SuneordError):
    """Raised when the Discord gateway closes or becomes invalid."""


class CommandError(SuneordError):
    """Base exception for command related failures."""


class CommandNotFound(CommandError):
    """Raised when a command lookup fails."""


class CommandInvokeError(CommandError):
    """Raised when a command callback raises an exception."""

    def __init__(self, original: Exception) -> None:
        super().__init__(f"Command raised an exception: {original}")
        self.original = original


class CheckFailure(CommandError):
    """Raised when a command check fails."""


class ExtensionError(SuneordError):
    """Base exception for extension loading failures."""


class ExtensionAlreadyLoaded(ExtensionError):
    """Raised when an extension is already loaded."""


class ExtensionNotLoaded(ExtensionError):
    """Raised when an extension is not loaded."""


class ExtensionNotFound(ExtensionError):
    """Raised when the target extension cannot be imported."""


class NoEntryPointError(ExtensionError):
    """Raised when an extension does not provide setup(bot)."""


class CogError(SuneordError):
    """Raised when cog registration fails."""
