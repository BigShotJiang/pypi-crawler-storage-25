from __future__ import annotations

from collections.abc import Awaitable, Callable, Iterable
from typing import Any

from .cog import Cog, command, listener, slash_command


class Commands:
    def __init__(self, bot: Any) -> None:
        self.bot = bot

    def command(
        self,
        name: str | None = None,
        *,
        aliases: Iterable[str] | None = None,
        description: str | None = None,
    ) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
        return self.bot.command(name=name, aliases=aliases, description=description)

    def slash_command(
        self,
        *,
        name: str,
        description: str,
        guild_id: str | None = None,
    ) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
        return self.bot.slash_command(name=name, description=description, guild_id=guild_id)

    def event(self, coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
        return self.bot.event(coro)

    async def add_cog(self, cog: Cog) -> Cog:
        return await self.bot.add_cog(cog)

    async def load_extension(self, name: str) -> Any:
        return await self.bot.load_extension(name)


__all__ = ["Cog", "Commands", "command", "listener", "slash_command"]
