from __future__ import annotations

import sys
import threading
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, TextIO


LEVELS = {
    "TRACE": 5,
    "DEBUG": 10,
    "INFO": 20,
    "SUCCESS": 25,
    "WARNING": 30,
    "ERROR": 40,
    "CRITICAL": 50,
}

LEVEL_COLORS = {
    "TRACE": "\033[38;5;244m",
    "DEBUG": "\033[36m",
    "INFO": "\033[34m",
    "SUCCESS": "\033[32m",
    "WARNING": "\033[33m",
    "ERROR": "\033[31m",
    "CRITICAL": "\033[1;31m",
}
RESET_COLOR = "\033[0m"


@dataclass(slots=True)
class LogRecord:
    timestamp: datetime
    level_name: str
    level_no: int
    name: str
    message: str
    extra: dict[str, Any]
    exception: str | None = None


class _Sink:
    def write(self, record: LogRecord) -> None:
        raise NotImplementedError

    def close(self) -> None:
        return None


class ConsoleSink(_Sink):
    def __init__(self, stream: TextIO | None = None, *, use_colors: bool = True) -> None:
        self.stream = stream or sys.stdout
        self.use_colors = use_colors

    def write(self, record: LogRecord) -> None:
        line = _format_record(record, use_colors=self.use_colors)
        self.stream.write(f"{line}\n")
        self.stream.flush()


class FileSink(_Sink):
    def __init__(self, path: str | Path, *, encoding: str = "utf-8") -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._file = self.path.open("a", encoding=encoding)

    def write(self, record: LogRecord) -> None:
        line = _format_record(record, use_colors=False)
        self._file.write(f"{line}\n")
        self._file.flush()

    def close(self) -> None:
        self._file.close()


@dataclass(slots=True)
class _LoggerCore:
    enabled: bool = True
    level: int = LEVELS["INFO"]
    sinks: dict[int, _Sink] = field(default_factory=dict)
    next_sink_id: int = 1
    lock: threading.RLock = field(default_factory=threading.RLock)


class Logger:
    """A small structured logger inspired by sink-based loggers."""

    def __init__(
        self,
        name: str = "suneord",
        *,
        enabled: bool = True,
        level: str | int = "INFO",
        core: _LoggerCore | None = None,
        extra: dict[str, Any] | None = None,
        autoconfigure: bool = True,
    ) -> None:
        self.name = name
        self._core = core or _LoggerCore(enabled=enabled, level=_coerce_level(level))
        self._extra = dict(extra or {})
        if core is None:
            self._core.enabled = enabled
            self._core.level = _coerce_level(level)
            if autoconfigure and enabled:
                self.add_console()

    @property
    def enabled(self) -> bool:
        return self._core.enabled

    @property
    def level(self) -> int:
        return self._core.level

    def set_level(self, level: str | int) -> None:
        self._core.level = _coerce_level(level)

    def enable(self) -> None:
        self._core.enabled = True

    def disable(self) -> None:
        self._core.enabled = False

    def bind(self, **extra: Any) -> "Logger":
        merged = dict(self._extra)
        merged.update(extra)
        return type(self)(self.name, core=self._core, extra=merged, autoconfigure=False)

    def add_console(self, *, use_colors: bool = True, stream: TextIO | None = None) -> int:
        return self.add_sink(ConsoleSink(stream=stream, use_colors=use_colors))

    def add_file(self, path: str | Path, *, encoding: str = "utf-8") -> int:
        return self.add_sink(FileSink(path, encoding=encoding))

    def add_sink(self, sink: _Sink) -> int:
        with self._core.lock:
            sink_id = self._core.next_sink_id
            self._core.next_sink_id += 1
            self._core.sinks[sink_id] = sink
            return sink_id

    def remove_sink(self, sink_id: int) -> None:
        with self._core.lock:
            sink = self._core.sinks.pop(sink_id, None)
        if sink is not None:
            sink.close()

    def is_enabled_for(self, level: str | int) -> bool:
        level_no = _coerce_level(level)
        return self.enabled and level_no >= self.level

    def log(
        self,
        level: str | int,
        message: str,
        *args: Any,
        extra: dict[str, Any] | None = None,
        exc_info: BaseException | bool | None = None,
        **format_kwargs: Any,
    ) -> None:
        if not self.enabled:
            return

        level_name, level_no = _normalize_level(level)
        if level_no < self.level:
            return

        rendered = message.format(*args, **format_kwargs) if args or format_kwargs else message
        merged_extra = dict(self._extra)
        if extra:
            merged_extra.update(extra)
        exception = _render_exception(exc_info)
        record = LogRecord(
            timestamp=datetime.now(timezone.utc),
            level_name=level_name,
            level_no=level_no,
            name=self.name,
            message=rendered,
            extra=merged_extra,
            exception=exception,
        )

        with self._core.lock:
            sinks = tuple(self._core.sinks.values())
        for sink in sinks:
            sink.write(record)

    def trace(self, message: str, *args: Any, **kwargs: Any) -> None:
        self.log("TRACE", message, *args, **kwargs)

    def debug(self, message: str, *args: Any, **kwargs: Any) -> None:
        self.log("DEBUG", message, *args, **kwargs)

    def info(self, message: str, *args: Any, **kwargs: Any) -> None:
        self.log("INFO", message, *args, **kwargs)

    def success(self, message: str, *args: Any, **kwargs: Any) -> None:
        self.log("SUCCESS", message, *args, **kwargs)

    def warning(self, message: str, *args: Any, **kwargs: Any) -> None:
        self.log("WARNING", message, *args, **kwargs)

    def error(self, message: str, *args: Any, **kwargs: Any) -> None:
        self.log("ERROR", message, *args, **kwargs)

    def critical(self, message: str, *args: Any, **kwargs: Any) -> None:
        self.log("CRITICAL", message, *args, **kwargs)

    def exception(self, message: str, *args: Any, **kwargs: Any) -> None:
        kwargs["exc_info"] = True
        self.log("ERROR", message, *args, **kwargs)


def get_logger(
    name: str = "suneord",
    *,
    enabled: bool = True,
    level: str | int = "INFO",
) -> Logger:
    return Logger(name=name, enabled=enabled, level=level)


def _coerce_level(level: str | int) -> int:
    if isinstance(level, int):
        return level
    normalized = level.upper()
    if normalized not in LEVELS:
        valid = ", ".join(LEVELS)
        raise ValueError(f"Unknown log level '{level}'. Valid levels: {valid}")
    return LEVELS[normalized]


def _normalize_level(level: str | int) -> tuple[str, int]:
    if isinstance(level, int):
        for name, value in LEVELS.items():
            if value == level:
                return name, value
        return str(level), level
    normalized = level.upper()
    return normalized, _coerce_level(normalized)


def _render_exception(exc_info: BaseException | bool | None) -> str | None:
    if exc_info in (None, False):
        return None
    if exc_info is True:
        return traceback.format_exc().rstrip()
    return "".join(traceback.format_exception(type(exc_info), exc_info, exc_info.__traceback__)).rstrip()


def _format_record(record: LogRecord, *, use_colors: bool) -> str:
    timestamp = record.timestamp.isoformat(timespec="seconds")
    level = f"{record.level_name:<8}"
    if use_colors and record.level_name in LEVEL_COLORS:
        level = f"{LEVEL_COLORS[record.level_name]}{level}{RESET_COLOR}"
    parts = [timestamp, level, record.name, record.message]
    if record.extra:
        extras = " ".join(f"{key}={value!r}" for key, value in sorted(record.extra.items()))
        parts.append(extras)
    line = " | ".join(parts)
    if record.exception:
        line = f"{line}\n{record.exception}"
    return line
