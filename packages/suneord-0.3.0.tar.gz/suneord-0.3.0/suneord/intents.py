from __future__ import annotations

from dataclasses import dataclass


INTENT_FLAGS = {
    "guilds": 1 << 0,
    "guild_members": 1 << 1,
    "guild_moderation": 1 << 2,
    "guild_emojis_and_stickers": 1 << 3,
    "guild_integrations": 1 << 4,
    "guild_webhooks": 1 << 5,
    "guild_invites": 1 << 6,
    "guild_voice_states": 1 << 7,
    "guild_presences": 1 << 8,
    "guild_messages": 1 << 9,
    "guild_message_reactions": 1 << 10,
    "guild_message_typing": 1 << 11,
    "direct_messages": 1 << 12,
    "direct_message_reactions": 1 << 13,
    "direct_message_typing": 1 << 14,
    "message_content": 1 << 15,
    "guild_scheduled_events": 1 << 16,
    "auto_moderation_configuration": 1 << 20,
    "auto_moderation_execution": 1 << 21,
    "guild_message_polls": 1 << 24,
    "direct_message_polls": 1 << 25,
}

PRIVILEGED_INTENTS = {"guild_members", "guild_presences", "message_content"}
DEFAULT_INTENT_NAMES = (
    "guilds",
    "guild_messages",
    "guild_message_reactions",
    "guild_message_typing",
    "direct_messages",
    "direct_message_reactions",
    "direct_message_typing",
)
COMMAND_INTENT_NAMES = DEFAULT_INTENT_NAMES + ("message_content",)


@dataclass(slots=True)
class IntentInfo:
    name: str
    bit: int
    privileged: bool = False


class Intents:
    """Bitfield helper for Discord gateway intents."""

    __slots__ = ("value",)

    def __init__(self, value: int = 0) -> None:
        self.value = int(value)

    def __repr__(self) -> str:
        enabled = ", ".join(name for name, state in self.to_dict().items() if state)
        return f"Intents(value={self.value}, enabled=[{enabled}])"

    def __int__(self) -> int:
        return self.value

    def __index__(self) -> int:
        return self.value

    def __or__(self, other: int | "Intents") -> "Intents":
        return type(self)(self.value | int(other))

    def __and__(self, other: int | "Intents") -> "Intents":
        return type(self)(self.value & int(other))

    def __xor__(self, other: int | "Intents") -> "Intents":
        return type(self)(self.value ^ int(other))

    def __ior__(self, other: int | "Intents") -> "Intents":
        self.value |= int(other)
        return self

    def __iand__(self, other: int | "Intents") -> "Intents":
        self.value &= int(other)
        return self

    def __ixor__(self, other: int | "Intents") -> "Intents":
        self.value ^= int(other)
        return self

    def __getattr__(self, name: str) -> bool:
        if name in INTENT_FLAGS:
            return self.has(name)
        raise AttributeError(name)

    def __setattr__(self, name: str, value: bool | int) -> None:
        if name == "value":
            object.__setattr__(self, name, int(value))
            return
        if name in INTENT_FLAGS:
            self.set(name, bool(value))
            return
        object.__setattr__(self, name, value)

    @classmethod
    def none(cls) -> "Intents":
        return cls(0)

    @classmethod
    def default(cls) -> "Intents":
        return cls.from_names(*DEFAULT_INTENT_NAMES)

    @classmethod
    def for_commands(cls) -> "Intents":
        return cls.from_names(*COMMAND_INTENT_NAMES)

    @classmethod
    def all(cls) -> "Intents":
        value = 0
        for bit in INTENT_FLAGS.values():
            value |= bit
        return cls(value)

    @classmethod
    def privileged(cls) -> "Intents":
        return cls.from_names(*PRIVILEGED_INTENTS)

    @classmethod
    def from_names(cls, *names: str) -> "Intents":
        intents = cls.none()
        intents.enable(*names)
        return intents

    @classmethod
    def describe(cls) -> tuple[IntentInfo, ...]:
        return tuple(
            IntentInfo(name=name, bit=bit, privileged=name in PRIVILEGED_INTENTS)
            for name, bit in INTENT_FLAGS.items()
        )

    def copy(self) -> "Intents":
        return type(self)(self.value)

    def to_int(self) -> int:
        return self.value

    def to_dict(self) -> dict[str, bool]:
        return {name: self.has(name) for name in INTENT_FLAGS}

    def has(self, name: str) -> bool:
        bit = self._resolve(name)
        return bool(self.value & bit)

    def enable(self, *names: str) -> "Intents":
        for name in names:
            self.value |= self._resolve(name)
        return self

    def disable(self, *names: str) -> "Intents":
        for name in names:
            self.value &= ~self._resolve(name)
        return self

    def set(self, name: str, enabled: bool) -> "Intents":
        if enabled:
            return self.enable(name)
        return self.disable(name)

    def is_privileged(self, name: str) -> bool:
        normalized = name.lower()
        self._resolve(normalized)
        return normalized in PRIVILEGED_INTENTS

    def enabled_privileged(self) -> tuple[str, ...]:
        return tuple(name for name in PRIVILEGED_INTENTS if self.has(name))

    def _resolve(self, name: str) -> int:
        normalized = name.lower()
        if normalized not in INTENT_FLAGS:
            valid = ", ".join(sorted(INTENT_FLAGS))
            raise ValueError(f"Unknown intent '{name}'. Valid intents: {valid}")
        return INTENT_FLAGS[normalized]
