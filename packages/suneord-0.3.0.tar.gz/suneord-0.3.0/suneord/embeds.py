from __future__ import annotations

import copy
from datetime import datetime, timezone
from typing import Any

from .colors import Colors, Colour, coerce_colour


class Embed:
    def __init__(
        self,
        *,
        title: str | None = None,
        description: str | None = None,
        colour: int | Colour | None = None,
        color: int | Colour | None = None,
        url: str | None = None,
    ) -> None:
        self.title = title
        self.description = description
        self.colour = coerce_colour(colour if colour is not None else color)
        self.url = url
        self.fields: list[dict[str, Any]] = []
        self.author: dict[str, Any] | None = None
        self.footer: dict[str, Any] | None = None
        self.thumbnail: dict[str, Any] | None = None
        self.image: dict[str, Any] | None = None
        self.timestamp: datetime | None = None

    @classmethod
    def success(cls, description: str, *, title: str = "Success") -> "Embed":
        return cls(title=title, description=description, colour=Colors.SUCCESS)

    @classmethod
    def info(cls, description: str, *, title: str = "Info") -> "Embed":
        return cls(title=title, description=description, colour=Colors.INFO)

    @classmethod
    def warning(cls, description: str, *, title: str = "Warning") -> "Embed":
        return cls(title=title, description=description, colour=Colors.WARNING)

    @classmethod
    def error(cls, description: str, *, title: str = "Error") -> "Embed":
        return cls(title=title, description=description, colour=Colors.ERROR)

    def set_title(self, title: str | None) -> "Embed":
        self.title = title
        return self

    def set_description(self, description: str | None) -> "Embed":
        self.description = description
        return self

    def set_color(self, color: int | Colour | None) -> "Embed":
        self.colour = coerce_colour(color)
        return self

    def set_colour(self, colour: int | Colour | None) -> "Embed":
        return self.set_color(colour)

    def set_url(self, url: str | None) -> "Embed":
        self.url = url
        return self

    def set_timestamp(self, timestamp: datetime | None = None) -> "Embed":
        self.timestamp = timestamp or datetime.now(timezone.utc)
        return self

    def set_author(
        self,
        *,
        name: str | None = None,
        url: str | None = None,
        icon_url: str | None = None,
    ) -> "Embed":
        self.author = {}
        if name is not None:
            self.author["name"] = name
        if url is not None:
            self.author["url"] = url
        if icon_url is not None:
            self.author["icon_url"] = icon_url
        return self

    def set_footer(self, *, text: str | None = None, icon_url: str | None = None) -> "Embed":
        self.footer = {}
        if text is not None:
            self.footer["text"] = text
        if icon_url is not None:
            self.footer["icon_url"] = icon_url
        return self

    def set_thumbnail(self, *, url: str | None = None) -> "Embed":
        self.thumbnail = {"url": url} if url is not None else None
        return self

    def set_image(self, *, url: str | None = None) -> "Embed":
        self.image = {"url": url} if url is not None else None
        return self

    def add_field(self, *, name: str, value: str, inline: bool = True) -> "Embed":
        self.fields.append({"name": name, "value": value, "inline": inline})
        return self

    def insert_field_at(self, index: int, *, name: str, value: str, inline: bool = True) -> "Embed":
        self.fields.insert(index, {"name": name, "value": value, "inline": inline})
        return self

    def remove_field(self, index: int) -> "Embed":
        self.fields.pop(index)
        return self

    def clear_fields(self) -> "Embed":
        self.fields.clear()
        return self

    def clear_footer(self) -> "Embed":
        self.footer = None
        return self

    def clear_author(self) -> "Embed":
        self.author = None
        return self

    def clear_image(self) -> "Embed":
        self.image = None
        return self

    def clear_thumbnail(self) -> "Embed":
        self.thumbnail = None
        return self

    def clear(self) -> "Embed":
        self.title = None
        self.description = None
        self.colour = None
        self.url = None
        self.fields.clear()
        self.author = None
        self.footer = None
        self.thumbnail = None
        self.image = None
        self.timestamp = None
        return self

    def copy(self) -> "Embed":
        return copy.deepcopy(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Embed":
        embed = cls(
            title=data.get("title"),
            description=data.get("description"),
            color=data.get("color"),
            url=data.get("url"),
        )
        embed.author = data.get("author")
        embed.footer = data.get("footer")
        embed.thumbnail = data.get("thumbnail")
        embed.image = data.get("image")
        embed.fields = list(data.get("fields", []))
        timestamp = data.get("timestamp")
        if isinstance(timestamp, datetime):
            embed.timestamp = timestamp
        elif isinstance(timestamp, str):
            embed.timestamp = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        return embed

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if self.title is not None:
            payload["title"] = self.title
        if self.description is not None:
            payload["description"] = self.description
        if self.colour is not None:
            payload["color"] = int(self.colour)
        if self.url is not None:
            payload["url"] = self.url
        if self.author:
            payload["author"] = self.author
        if self.footer:
            payload["footer"] = self.footer
        if self.thumbnail:
            payload["thumbnail"] = self.thumbnail
        if self.image:
            payload["image"] = self.image
        if self.fields:
            payload["fields"] = self.fields
        if self.timestamp is not None:
            payload["timestamp"] = self.timestamp.isoformat()
        return payload
