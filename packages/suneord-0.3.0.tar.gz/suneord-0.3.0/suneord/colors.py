from __future__ import annotations

import random


class Colour(int):
    """Discord embed colour helper."""

    def __new__(cls, value: int) -> "Colour":
        intval = int(value)
        if not 0 <= intval <= 0xFFFFFF:
            raise ValueError("Colour value must be between 0x000000 and 0xFFFFFF.")
        return int.__new__(cls, intval)

    @property
    def value(self) -> int:
        return int(self)

    def to_hex(self) -> str:
        return f"#{self.value:06X}"

    def to_rgb(self) -> tuple[int, int, int]:
        return ((self.value >> 16) & 0xFF, (self.value >> 8) & 0xFF, self.value & 0xFF)

    @classmethod
    def from_hex(cls, value: str) -> "Colour":
        normalized = value.strip().removeprefix("#").removeprefix("0x").removeprefix("0X")
        return cls(int(normalized, 16))

    @classmethod
    def from_rgb(cls, red: int, green: int, blue: int) -> "Colour":
        for component in (red, green, blue):
            if not 0 <= component <= 255:
                raise ValueError("RGB components must be between 0 and 255.")
        return cls((red << 16) | (green << 8) | blue)

    @classmethod
    def random(cls, seed: int | None = None) -> "Colour":
        generator = random.Random(seed)
        return cls(generator.randint(0, 0xFFFFFF))


Color = Colour


def coerce_colour(value: int | Colour | None) -> int | None:
    if value is None:
        return None
    return Colour(int(value)).value


class Colors:
    RED = Colour(0xED4245)
    ORANGE = Colour(0xFAA61A)
    YELLOW = Colour(0xFEE75C)
    GREEN = Colour(0x57F287)
    MINT = Colour(0x3BA55C)
    BLUE = Colour(0x3498DB)
    CYAN = Colour(0x1ABC9C)
    BLURPLE = Colour(0x5865F2)
    PURPLE = Colour(0x9B59B6)
    PINK = Colour(0xEB459E)
    WHITE = Colour(0xFFFFFF)
    BLACK = Colour(0x2B2D31)
    GRAY = Colour(0x95A5A6)
    GREY = GRAY
    SUCCESS = GREEN
    WARNING = YELLOW
    ERROR = RED
    INFO = BLUE
