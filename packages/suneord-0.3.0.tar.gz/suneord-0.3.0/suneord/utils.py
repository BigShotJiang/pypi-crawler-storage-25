from __future__ import annotations

import inspect
from collections.abc import Awaitable, Iterable
from datetime import datetime, timezone
from typing import Any


DISCORD_EPOCH = 1420070400000


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def format_dt(dt: datetime, style: str = "f") -> str:
    timestamp = int(dt.timestamp())
    return f"<t:{timestamp}:{style}>"


def snowflake_time(snowflake: int | str) -> datetime:
    value = int(snowflake)
    unix_ms = ((value >> 22) + DISCORD_EPOCH) / 1000
    return datetime.fromtimestamp(unix_ms, tz=timezone.utc)


async def maybe_await(value: Any) -> Any:
    if inspect.isawaitable(value):
        return await value
    return value


def chunked(iterable: Iterable[Any], size: int) -> list[list[Any]]:
    if size <= 0:
        raise ValueError("size must be greater than 0")
    items = list(iterable)
    return [items[index : index + size] for index in range(0, len(items), size)]
