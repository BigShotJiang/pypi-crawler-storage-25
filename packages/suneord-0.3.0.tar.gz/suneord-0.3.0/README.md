# suneord

`suneord` is an async-first Discord bot framework built directly on top of Discord HTTP and Gateway APIs.

The project now includes:

- message commands with aliases and multiple prefixes
- slash commands
- class-based cogs
- extension loading and reloading
- structured optional logging with console and file sinks
- `Intents` bitfield helpers
- `Colors` and richer `Embed` helpers
- context helpers like `send_success()`, `reply_error()`, `typing()`, `send_dm()`, `history()`
- direct REST helpers for messages, members, pins, DMs, bans, and presence

## Installation

```bash
pip install .
```

## Quick Start

```python
import suneord
from suneord import Bot, Colors, Embed, Intents

intents = Intents.for_commands()
intents.guild_members = True

bot = Bot(
    prefix=("!", "?"),
    intents=intents,
    status="idle",
    status_text="watching the server",
    enable_logging=True,
)

bot.logger.add_file("logs/bot.log")


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user['username']}")


@bot.command(aliases=("p",), description="Show gateway latency")
async def ping(ctx):
    embed = Embed(
        title="Pong",
        description=f"Latency: {round(bot.latency * 1000)} ms",
        colour=Colors.GREEN,
    )
    embed.add_field(name="Author", value=ctx.author.display_name or "Unknown")
    embed.add_field(name="Channel", value=ctx.channel.mention)
    await ctx.reply(embed=embed, mention_author=False)


@bot.command(description="Send a styled success message")
async def ok(ctx):
    await ctx.reply_success("Everything is working.")


bot.run("TOKEN")
```

## Cogs

```python
from suneord import Colors, Embed
from suneord.ext.commands import Cog, command, listener


class Utility(Cog):
    @listener()
    async def on_ready(self):
        print("Utility cog loaded")

    @command(description="Show your avatar")
    async def avatar(self, ctx):
        embed = Embed(
            title=ctx.author.display_name or ctx.author.name,
            colour=Colors.BLURPLE,
        )
        embed.set_image(url=str(ctx.author.avatar))
        await ctx.reply(embed=embed, mention_author=False)


async def setup(bot):
    await bot.add_cog(Utility())
```

Load the extension:

```python
await bot.load_extension("bot.cogs.utility")
```

Or load a whole directory:

```python
await bot.load_extensions_from("bot/cogs", package="bot.cogs")
```

## Slash Commands

```python
from suneord import Bot

bot = Bot(prefix="!")


@bot.slash_command(name="ping", description="Show latency")
async def ping(ctx):
    await ctx.reply_info(f"Pong: {round(bot.latency * 1000)} ms", ephemeral=True)
```

## Intents

```python
from suneord import Intents

intents = Intents.default()
intents.message_content = True
intents.guild_members = True

bot = Bot(prefix="!", intents=intents)
```

Useful constructors:

- `Intents.none()`
- `Intents.default()`
- `Intents.for_commands()`
- `Intents.privileged()`
- `Intents.all()`

## Colors And Embeds

```python
from suneord import Colors, Embed

embed = (
    Embed(title="Build Status", colour=Colors.INFO)
    .set_description("Deployment finished successfully.")
    .add_field(name="Region", value="eu-central")
    .set_footer(text="suneord")
)
```

Available presets include `Colors.RED`, `Colors.GREEN`, `Colors.BLURPLE`, `Colors.INFO`, `Colors.WARNING`, and `Colors.ERROR`.

## Logging

Logging is optional. If you do not enable it, the framework stays silent.

```python
from suneord import Bot

bot = Bot(prefix="!", enable_logging=True, log_level="DEBUG")

bot.logger.debug("debug line")
bot.logger.info("connected")
bot.logger.success("commands synced")
bot.logger.warning("slow heartbeat")
bot.logger.error("api request failed")
bot.logger.add_file("logs/runtime.log")
```

You can also provide your own configured logger:

```python
from suneord import Bot, Logger

logger = Logger("mybot", enabled=True, level="INFO", autoconfigure=False)
logger.add_console()
logger.add_file("logs/mybot.log")

bot = Bot(prefix="!", logger=logger)
```

## Main API

`Bot`:

- `command()`
- `slash_command()`
- `event()`
- `add_cog()`
- `remove_cog()`
- `load_extension()`
- `reload_extension()`
- `load_extensions_from()`
- `wait_until_ready()`
- `set_presence()`
- `sync_application_commands()`
- `send_message()`
- `edit_message()`
- `delete_message()`
- `fetch_message()`
- `fetch_messages()`
- `bulk_delete_messages()`
- `pin_message()`
- `unpin_message()`
- `create_dm()`
- `send_dm()`
- `fetch_channel()`
- `fetch_guild()`
- `fetch_guild_member()`
- `fetch_user()`
- `fetch_me()`
- `add_reaction()`
- `remove_reaction()`
- `trigger_typing()`
- `change_nickname()`
- `kick_member()`
- `ban_member()`
- `unban_member()`
- `create_task()`

`Context`:

- `send()`
- `reply()`
- `respond()`
- `edit()`
- `delete()`
- `fetch_message()`
- `history()`
- `pin()`
- `unpin()`
- `react()`
- `typing()`
- `send_dm()`
- `send_success()`
- `send_info()`
- `send_warning()`
- `send_error()`
- `reply_success()`
- `reply_info()`
- `reply_warning()`
- `reply_error()`

`SlashContext`:

- `reply()`
- `send()`
- `respond()`
- `followup()`
- `defer()`
- `edit()`
- `delete()`
- `fetch_original_response()`
- `react()`
- `typing()`
- `send_dm()`
- `subcommand_path`
- `options`

## Notes

- Prefix commands need the Message Content intent enabled in the Discord Developer Portal.
- Privileged intents must also be enabled in your application settings.
- Slash commands are synced automatically on startup by default.
- If you leak your bot token, rotate it immediately.

## License

MIT
