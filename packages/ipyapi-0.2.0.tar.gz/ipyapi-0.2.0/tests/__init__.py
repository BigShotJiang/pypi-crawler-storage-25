"""Tests for ipyapi."""
