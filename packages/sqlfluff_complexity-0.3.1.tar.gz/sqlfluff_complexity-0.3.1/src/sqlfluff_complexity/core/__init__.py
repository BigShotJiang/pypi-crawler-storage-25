"""Shared complexity analysis primitives."""
