import os
import sys
import threading
from llama_cpp import Llama
from .progress import ProgressTracker, make_assembly_bar, make_generation_bar


# Context setup to silence llama.cpp's verbose tensor/metadata dumps
class SuppressOutput:
    def __enter__(self):
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr
        sys.stdout = open(os.devnull, 'w')
        sys.stderr = open(os.devnull, 'w')

    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.stdout.close()
        sys.stderr.close()
        sys.stdout = self._original_stdout
        sys.stderr = self._original_stderr


def get_model_path(tracker=None):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(base_dir, "models", "qwen.gguf")

    if os.path.exists(model_path):
        return model_path

    if tracker:
        tracker.update(10)

    os.makedirs(os.path.dirname(model_path), exist_ok=True)

    try:
        import tinymentor_model_part1
        parts = [tinymentor_model_part1.get_part_path()]

        i = 2
        while True:
            try:
                mod = __import__(f"tinymentor_model_part{i}")
                parts.append(mod.get_part_path())
                i += 1
            except ImportError:
                break

        if tracker:
            tracker.update(25)

        # Calculate total size for assembly progress bar
        total_size = sum(os.path.getsize(p) for p in parts)
        assembly_bar = make_assembly_bar(total_size)

        with open(model_path, "wb") as outfile:
            for part in parts:
                with open(part, "rb") as infile:
                    chunk = infile.read()
                    outfile.write(chunk)
                    if assembly_bar:
                        assembly_bar.update(len(chunk))

        if assembly_bar:
            assembly_bar.close()

    except Exception as e:
        print(f"Error assembling model: {e}")

    return model_path


MODEL = None
_model_lock = threading.Lock()


def preload_model():
    """Background thread function to preload the model into RAM."""
    get_model(_show_progress=False)


def get_model(_show_progress=True):
    global MODEL
    if MODEL is not None:
        return MODEL

    with _model_lock:
        if MODEL is not None:
            return MODEL

        tracker = ProgressTracker() if _show_progress else None

        model_path = get_model_path(tracker)
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model not found at {model_path}")

        if tracker:
            tracker.update(40)

        with SuppressOutput():
            MODEL = Llama(
                model_path=model_path,
                n_ctx=1024,
                n_threads=8,
                n_batch=128,
                verbose=False,
                use_mmap=True,
                use_mlock=False
            )

        if tracker:
            tracker.update(55)

        # Warm up
        with SuppressOutput():
            MODEL("hello", max_tokens=5)

        if tracker:
            tracker.close()

        return MODEL


def generate_response(prompt: str, max_tokens: int = 50, temperature: float = 0.2):
    model = get_model()

    gen_bar = make_generation_bar(max_tokens)

    with SuppressOutput():
        output = model(
            prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            echo=False
        )

    # Simulate token count from actual output for the bar
    generated_text = output['choices'][0]['text'].strip()
    token_count = len(generated_text.split())
    if gen_bar:
        gen_bar.update(min(token_count, max_tokens))
        gen_bar.close()

    return generated_text


# Start background preload upon import
threading.Thread(target=preload_model, daemon=True).start()
