import os
from .memory import get_last_qa, get_full_memory
from .classifier import classify_topic, generate_filename

def approve():
    """
    Learning workflow:
    1. Get last Q&A
    2. Classify topic
    3. Create folder if missing
    4. Generate markdown filename
    5. Save markdown
    6. Merge similar topics / avoid duplicates
    7. Update approved dataset if >= 50 answers
    """
    last_qa = get_last_qa()
    if not last_qa:
        print("No recent Q&A to approve.")
        return
        
    question = last_qa["question"]
    answer = last_qa["answer"]
    
    topic_path = classify_topic(question)
    base_dir = os.path.dirname(__file__)
    full_topic_dir = os.path.join(base_dir, "md", topic_path)
    
    os.makedirs(full_topic_dir, exist_ok=True)
    
    filename = generate_filename(question)
    filepath = os.path.join(full_topic_dir, filename)
    
    # Avoid duplicates/Merge
    if os.path.exists(filepath):
        with open(filepath, "r") as f:
            existing_content = f.read()
        if question in existing_content:
            print(f"Already learned: {filepath}")
        else:
            with open(filepath, "a") as f:
                f.write(f"\n\n## {question}\n\n{answer}\n")
            print(f"Merged into existing note: {filepath}")
    else:
        with open(filepath, "w") as f:
            f.write(f"# Notes on {topic_path}\n\n## {question}\n\n{answer}\n")
        print(f"Learned and saved to: {filepath}")
        
    # Check for dataset creation
    _check_dataset_threshold(base_dir)

def _check_dataset_threshold(base_dir):
    """
    Begin dataset creation after 50 approved Q&A
    """
    # Count approved files or answers
    count = 0
    md_dir = os.path.join(base_dir, "md")
    for root, _, files in os.walk(md_dir):
        for file in files:
            if file.endswith(".md"):
                count += 1
                
    if count >= 50:
        training_dir = os.path.join(base_dir, "training")
        os.makedirs(training_dir, exist_ok=True)
        dataset_path = os.path.join(training_dir, "approved_dataset.md")
        if not os.path.exists(dataset_path):
            with open(dataset_path, "w") as f:
                f.write("# TinyMentor Approved Dataset\n\nDataset creation initiated.\n")
            print("Reached 50 approved notes. Started approved_dataset.md for future fine-tuning.")
