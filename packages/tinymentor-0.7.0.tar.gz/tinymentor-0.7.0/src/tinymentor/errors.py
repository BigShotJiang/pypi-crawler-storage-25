import traceback
import sys

def solve_error(tb_str: str = None) -> str:
    """
    Detect errors such as ModuleNotFoundError, PIP errors, notebook errors, etc.
    """
    if tb_str is None:
        try:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            if exc_type is not None:
                tb_str = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
            else:
                return ""
        except Exception:
            return ""

    detected_errors = []
    error_types = [
        "ModuleNotFoundError", "ImportError", "TypeError", 
        "KeyError", "IndexError", "ValueError"
    ]
    
    for err in error_types:
        if err in tb_str:
            detected_errors.append(err)
            
    if "pip" in tb_str.lower():
        detected_errors.append("pip error")
        
    if "ipython" in tb_str.lower() or "jupyter" in tb_str.lower():
        detected_errors.append("notebook error")
        
    if "api" in tb_str.lower() or "requests.exceptions" in tb_str:
        detected_errors.append("API error")
        
    if detected_errors:
        return f"Detected Errors: {', '.join(detected_errors)}\nTraceback context:\n{tb_str}"
    
    return ""
