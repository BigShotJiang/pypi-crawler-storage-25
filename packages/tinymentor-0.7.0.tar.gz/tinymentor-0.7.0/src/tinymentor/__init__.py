from .ask import ask
from .learning import approve
import threading
from .model import get_model

# Background preload
threading.Thread(target=get_model, daemon=True).start()

__all__ = ["ask", "approve"]
