from .memory import remember
from .errors import solve_error
from .model import generate_response, get_model
from .progress import ProgressTracker

CACHE = {}

def ask(question: str, traceback: str = None, max_tokens: int = 50):
    """
    Main Ask Workflow:
    Pure GenAI coding assistant without retrieval.
    Handles tracebacks if provided.
    """
    if question in CACHE:
        return CACHE[question]

    # Ensure model is loaded (shows progress if first call)
    get_model()

    tracker = ProgressTracker()
    tracker.update(70)

    error_context = ""
    if traceback:
        error_info = solve_error(traceback)
        if error_info:
            error_context = f"\n\nContext from traceback:\n{error_info}"

    prompt = f"""You are a GenAI coding assistant.
Answer with:
1. code only
2. minimum explanation

{error_context}

Question:
{question}
"""

    tracker.update(85)

    try:
        answer = generate_response(prompt, max_tokens=max_tokens)
    except Exception as e:
        tracker.close()
        answer = f"Error during generation: {e}"
        print(answer)
        return

    tracker.update(100)
    tracker.close()

    # Memory
    remember(question, answer)
    CACHE[question] = answer

    print("\n" + answer)
    return answer
