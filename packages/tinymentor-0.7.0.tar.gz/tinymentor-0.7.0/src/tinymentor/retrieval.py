import os

retrieval_cache = {}

def search_notes(question: str) -> list:
    """
    Recursively search markdown files in the md/ directory.
    Uses TF-IDF and cosine similarity to return the top 3 matches.
    Caches results.
    """
    if question in retrieval_cache:
        return retrieval_cache[question]

    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity
    except ImportError:
        return []

    base_dir = os.path.join(os.path.dirname(__file__), "md")
    if not os.path.exists(base_dir):
        return []
        
    documents = []
    file_paths = []
    
    for root, _, files in os.walk(base_dir):
        for file in files:
            if file.endswith(".md"):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()
                        documents.append(f"{file} {content}")
                        file_paths.append(file_path)
                except Exception:
                    pass
                    
    if not documents:
        return []
        
    documents.append(question)
    
    vectorizer = TfidfVectorizer(stop_words='english')
    try:
        tfidf_matrix = vectorizer.fit_transform(documents)
    except ValueError:
        return []
        
    cosine_similarities = cosine_similarity(tfidf_matrix[-1], tfidf_matrix[:-1]).flatten()
    
    # Get top 3 indices
    related_docs_indices = cosine_similarities.argsort()[:-4:-1]
    
    top_3 = []
    total_chars = 0
    for idx in related_docs_indices:
        if cosine_similarities[idx] > 0.0:
            path = file_paths[idx]
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
                # Limit size to fit within max_context_chars
                if total_chars + len(content) > 2000:
                    content = content[:2000 - total_chars] + "..."
                
                if content:
                    top_3.append(content)
                    total_chars += len(content)
                
                if total_chars >= 2000:
                    break
                
    retrieval_cache[question] = top_3
    return top_3
