def classify_topic(question: str) -> str:
    """
    Auto-classify topic to decide where to save.
    Returns a string like 'genai/rag' or 'debugging/python'.
    """
    q_lower = question.lower()
    
    if "rag" in q_lower:
        return "genai/rag"
    elif "embed" in q_lower:
        return "genai/embeddings"
    elif "prompt" in q_lower:
        return "genai/prompt_engineering"
    elif "vector" in q_lower:
        return "genai/vector_db"
    elif "llm" in q_lower:
        return "genai/llm"
        
    elif "module" in q_lower or "import" in q_lower:
        return "debugging/python"
    elif "notebook" in q_lower or "jupyter" in q_lower:
        return "debugging/notebook"
    elif "pip" in q_lower or "install" in q_lower:
        return "debugging/pip"
    elif "api" in q_lower:
        return "debugging/api"
        
    elif "javascript" in q_lower or "js" in q_lower:
        return "coding/javascript"
    elif "sql" in q_lower:
        return "coding/sql"
        
    return "coding/python"

def generate_filename(question: str) -> str:
    """
    Generate a safe, short filename based on the question.
    """
    words = [w for w in question.lower().split() if w.isalnum()]
    if not words:
        return "note.md"
    return "_".join(words[:4]) + ".md"
