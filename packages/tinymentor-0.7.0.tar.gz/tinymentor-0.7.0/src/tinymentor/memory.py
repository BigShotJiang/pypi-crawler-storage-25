import os
import json

MEMORY_FILE = os.path.join(os.path.dirname(__file__), "memory", "session.json")

def _load_memory():
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE, "r") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return []
    return []

def _save_memory(memory):
    os.makedirs(os.path.dirname(MEMORY_FILE), exist_ok=True)
    with open(MEMORY_FILE, "w") as f:
        json.dump(memory, f, indent=2)

def remember(question: str, answer: str):
    """
    Keep only the last 10 questions. Overwrite oldest.
    """
    memory = _load_memory()
    memory.append({"question": question, "answer": answer})
    if len(memory) > 10:
        memory = memory[-10:]
    _save_memory(memory)

def get_last_qa():
    memory = _load_memory()
    if memory:
        return memory[-1]
    return None

def get_full_memory():
    return _load_memory()
