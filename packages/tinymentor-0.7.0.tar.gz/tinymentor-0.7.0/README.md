# tinymentor

A notebook-first AI coding assistant focused on:
- GenAI coding questions
- Debugging
- Code generation
- Retrieval
- Learning from approved answers
- Future fine-tuning

Fully local, offline, and simple to use.

## Usage

```python
from tinymentor import ask, approve

ask("Why ModuleNotFoundError happens?")
approve()
```
