"""
Discovery script: run candidate queries against the live pipeline to find new benchmark test cases.
Prints top-5 article IDs + names so we can pick cases to add to intelligence_eval.py.

Run: uv run python discover_test_cases.py
"""

from __future__ import annotations
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(".env")

from rag007 import AgenticRAG, _make_azure_embed_fn  # noqa: E402

embed_fn = _make_azure_embed_fn()

de = AgenticRAG(
    "onetrade_articles_de",
    embed_fn=embed_fn,
    boost_fn=lambda m: (
        (1.2 if m.get("is_own_brand") else 1.0)
        * max(0.1, min(3.0, (m.get("sales_l12m") or 0) / 500_000))
    ),
)
fr = AgenticRAG(
    "onetrade_articles_fr",
    embed_fn=embed_fn,
    boost_fn=lambda m: (
        (1.2 if m.get("is_own_brand") else 1.0)
        * max(0.1, min(3.0, (m.get("sales_l12m") or 0) / 500_000))
    ),
)

DE_CANDIDATES = [
    # Swiss German synonyms
    "Velo Kette",  # bicycle chain (Velo = Swiss German for Fahrrad)
    "Pneu Flicken",  # puncture repair (Pneu = Swiss German for Reifen)
    "Keller abdichten",  # basement waterproofing
    # Compound word splits
    "Wasser Hahn",  # tap/faucet (compound: Wasserhahn)
    "Wand Farbe weiß",  # wall paint white
    "Stein Bohrer",  # masonry drill bit
    # Intent / problem description
    "WC Spülung tropft",  # leaky toilet flush → repair parts
    "Fenster Dichtung erneuern",  # window seal replacement
    "Fliesen kleben Boden",  # tiling the floor → adhesive
    "Schimmel Bad entfernen",  # mold removal bathroom
    "Holz Außen schützen",  # outdoor wood protection → Holzlasur
    "Kabel verlegen Wand",  # laying cable in wall → conduit/cable
    # Abbreviations
    "SDS Plus Bohrer",  # SDS+ drill bit type
    "PE-X Rohr 16mm",  # cross-linked PE pipe
    "HT Rohr DN100",  # high-temp drain pipe
    "M10 Sechskantschraube",  # M10 hex bolt
    # Swiss German specific construction terms
    "Maurerkelle Metall",  # masonry trowel
    "Abbruchhammer Meißel",  # demolition hammer chisel
    "Kies Körnung 8/16",  # gravel size 8-16mm
    "Gewebeschlauch Wasser",  # reinforced water hose
]

FR_CANDIDATES = [
    # Swiss French synonyms
    "robinet mélangeur lavabo",  # mixer tap (mitigeur in standard FR)
    "sac poubelle noir 100L",  # black trash bag
    "gaine technique PVC",  # PVC conduit
    # Intent queries
    "fuite chasse d eau",  # toilet tank leak
    "mur humide cave",  # damp basement wall
    "planche terrasse composite",  # composite decking boards
    "carrelage sol antidérapant",  # non-slip floor tiles
    "peinture extérieure façade",  # exterior facade paint
    # Abbreviations
    "PE-X tube 16mm",  # PE-X pipe
    "cable électrique 3G1.5",  # 3-core 1.5mm² electrical cable
    "chevron 45x145",  # roof rafter dimension
    # Problem descriptions
    "siphon douche bouché",  # clogged shower drain
    "joints fenêtre étancher",  # window weatherstripping
    "fixation béton ancrage",  # concrete anchor bolt
    "colle PVC tuyau pression",  # PVC pressure pipe adhesive
]


def run_discovery(rag: AgenticRAG, queries: list[str], lang_label: str) -> None:
    print(f"\n{'=' * 70}")
    print(f"  {lang_label} DISCOVERY RESULTS")
    print(f"{'=' * 70}")
    for q in queries:
        try:
            _, docs = rag.retrieve_documents(q)
            ids = [
                str(d.metadata.get("article_id", d.metadata.get("id", "")))
                for d in docs[:5]
            ]
            names = [
                str(d.metadata.get("article_name", d.metadata.get("title", "")))[:40]
                for d in docs[:5]
            ]
            print(f"\n  Query: {q!r}")
            for i, (aid, name) in enumerate(zip(ids, names)):
                print(f"    [{i + 1}] {aid:12s}  {name}")
        except Exception as e:
            print(f"\n  Query: {q!r}  → ERROR: {e}")


if __name__ == "__main__":
    import concurrent.futures

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        f_de = ex.submit(run_discovery, de, DE_CANDIDATES, "DE")
        f_fr = ex.submit(run_discovery, fr, FR_CANDIDATES, "FR")
        f_de.result()
        f_fr.result()
    print("\nDone. Review results above and add useful cases to intelligence_eval.py.")
