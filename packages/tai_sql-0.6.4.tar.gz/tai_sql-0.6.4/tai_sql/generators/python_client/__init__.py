import os
import jinja2
from typing import List, Optional, Dict, Any, ClassVar
from pathlib import Path

from tai_sql import pm, Table, View
from ..base import BaseGenerator


class PythonClientGenerator(BaseGenerator):
    """
    Generador unificado de cliente Python para base de datos.
    
    Combina la generación de modelos SQLAlchemy, DAOs (sync + async) y DTOs
    en una estructura de dominios: una carpeta por tabla/vista con model.py,
    dao_sync.py, dao_async.py y dtos.py.
    
    Siempre genera ambos modos (sync y async).
    """

    _jinja_env: ClassVar[jinja2.Environment] = None

    def __init__(
        self,
        output_dir: str | list[str],
        max_depth: int = 5,
        logger_name: str = 'tai-sql',
        pool_size: Optional[int] = None,
        max_overflow: Optional[int] = None,
        pool_timeout: Optional[int] = None,
        pool_pre_ping: Optional[bool] = None,
        pool_recycle: Optional[int] = None,
        ssl: Optional[bool] = None,
        sqlalchemy_logs: Optional[bool] = None,
        import_prefix: str = '..',
    ):
        super().__init__(output_dir)
        self.max_depth = max_depth
        self.logger_name = logger_name
        self.import_prefix = import_prefix
        self._pool_size = pool_size
        self._max_overflow = max_overflow
        self._pool_timeout = pool_timeout
        self._pool_pre_ping = pool_pre_ping
        self._pool_recycle = pool_recycle
        self._ssl = ssl
        self._sqlalchemy_logs = sqlalchemy_logs

    # ── Jinja2 ────────────────────────────────────────────────────────────

    @property
    def jinja_env(self) -> jinja2.Environment:
        if self._jinja_env is None:
            templates_dir = os.path.join(os.path.dirname(__file__), 'templates')
            self._jinja_env = jinja2.Environment(
                loader=jinja2.FileSystemLoader(templates_dir),
                trim_blocks=True,
                lstrip_blocks=True,
            )
            self._jinja_env.filters['repr'] = repr

            def transform_refs(text: str, context: dict) -> str:
                result = text
                for trigger_ref, actual_var in context.items():
                    result = result.replace(trigger_ref, actual_var)
                return result

            self._jinja_env.filters['transform_refs'] = transform_refs
        return self._jinja_env

    # ── Connection params ─────────────────────────────────────────────────

    @property
    def connection_params(self) -> Dict:
        params = pm.db.provider.get_connection_params().copy()
        overrides = {
            'pool_size': self._pool_size,
            'max_overflow': self._max_overflow,
            'pool_timeout': self._pool_timeout,
            'pool_pre_ping': self._pool_pre_ping,
            'pool_recycle': self._pool_recycle,
            'ssl': self._ssl,
            'sqlalchemy_logs': self._sqlalchemy_logs,
        }
        for key, value in overrides.items():
            if value is not None:
                params[key] = value
        return params

    # ── Output paths ──────────────────────────────────────────────────────

    def schema_dir_for(self, output_dir: str) -> Path:
        return Path(output_dir) / pm.db.schema_name

    @property
    def schema_dir(self) -> Path:
        return self.schema_dir_for(self.config.output_dir)

    def domain_dir_for(self, model: Table | View, output_dir: str) -> Path:
        return self.schema_dir_for(output_dir) / model.tablename

    def domain_dir(self, model: Table | View) -> Path:
        return self.schema_dir / model.tablename

    # ── Encryption helpers ────────────────────────────────────────────────

    @property
    def has_encrypted_columns(self) -> bool:
        return any(
            any(hasattr(col, 'encrypt') and col.encrypt for col in model.columns.values())
            for model in self.models
        )

    def validate_encryption_setup(self):
        if not self.has_encrypted_columns:
            return
        secret_key = os.getenv(pm.db.secret_key_name)
        if not secret_key:
            raise ValueError(
                f"Se encontraron columnas con encrypt=True pero "
                f"la variable de entorno '{pm.db.secret_key_name}' no está definida."
            )
        if len(secret_key) < 32:
            raise ValueError(
                f"La clave secreta en '{pm.db.secret_key_name}' debe tener al menos 32 caracteres."
            )
        try:
            import base64
            from cryptography.fernet import Fernet
            Fernet(base64.urlsafe_b64encode(secret_key.encode()[:32].ljust(32, b'0')))
        except ImportError:
            raise ImportError(
                "La librería 'cryptography' no está instalada. "
                "Para usar columnas encriptadas: pip install cryptography"
            )
        except Exception as e:
            raise ValueError(f"Error al validar la clave secreta: {e}")

    # ── Model analysis helpers ────────────────────────────────────────────

    def _model_has_encrypt(self, model: Table | View) -> bool:
        return any(
            hasattr(col, 'encrypt') and col.encrypt
            for col in model.columns.values()
        )

    def _model_has_calculated(self, model: Table | View) -> bool:
        return any(
            hasattr(col, 'is_calculated') and col.is_calculated
            for col in model.columns.values()
        )

    def _all_models_data(self, mode: str = 'sync') -> List[Dict[str, Any]]:
        return [model.info(mode) for model in self.models]

    # ── Generate ──────────────────────────────────────────────────────────

    def generate(self) -> str:
        self.validate_encryption_setup()

        primary_result = None
        for output_dir in self.config.output_dirs:
            result = self._generate_to(output_dir)
            if primary_result is None:
                primary_result = result

        return primary_result

    def _generate_to(self, output_dir: str) -> str:
        """Genera el cliente Python en un directorio de salida específico."""
        schema_dir = self.schema_dir_for(output_dir)
        schema_dir.mkdir(parents=True, exist_ok=True)

        # 1. _base.py
        self._generate_base(schema_dir)

        # 2. _session.py
        self._generate_session(schema_dir)

        # 3. _shared/
        self._generate_shared(schema_dir)

        # 4. Per-domain files
        all_models_sync = self._all_models_data('sync')
        all_models_async = self._all_models_data('async')

        for i, model in enumerate(self.models):
            domain = self.domain_dir_for(model, output_dir)
            domain.mkdir(parents=True, exist_ok=True)

            model_info_sync = all_models_sync[i]
            model_info_async = all_models_async[i]
            model_info = model.info()

            self._generate_domain_model(domain, model, model_info)
            self._generate_domain_dtos(domain, model_info, all_models_sync)
            self._generate_domain_dao(domain, model_info_sync, all_models_sync, is_async=False)
            self._generate_domain_dao(domain, model_info_async, all_models_async, is_async=True)
            self._generate_domain_init(domain, model_info)

        # Remove stale domain directories (models removed from schema)
        self._cleanup_stale_domains(schema_dir)

        # 5. Facade __init__.py
        self._generate_facade(schema_dir, all_models_sync)

        return str(schema_dir)

    # ── Individual generators ─────────────────────────────────────────────

    def _generate_base(self, schema_dir: Path) -> None:
        template = self.jinja_env.get_template('base.py.jinja2')
        has_dict = any(
            col.type == 'dict'
            for model in self.models
            for col in model.columns.values()
        )
        code = template.render(
            has_dict=has_dict,
            has_encrypted_columns=self.has_encrypted_columns,
            secret_key_name=pm.db.secret_key_name,
        )
        (schema_dir / '_base.py').write_text(code, encoding='utf-8')

    def _generate_session(self, schema_dir: Path) -> None:
        template = self.jinja_env.get_template('session.py.jinja2')
        connection_params = self.connection_params
        code = template.render(
            provider=pm.db.provider,
            connection_params=connection_params,
            logger_name=self.logger_name,
        )
        (schema_dir / '_session.py').write_text(code, encoding='utf-8')

    def _generate_shared(self, schema_dir: Path) -> None:
        shared_dir = schema_dir / '_shared'
        shared_dir.mkdir(parents=True, exist_ok=True)

        utils_dir = shared_dir / 'utils'
        utils_dir.mkdir(parents=True, exist_ok=True)

        # Pre-compute whether any vector+encoder columns exist (needed by multiple templates)
        all_models_data = self._all_models_data()
        has_vector_encoders = any(
            col.get('type') == 'vector' and col.get('has_encoder') and col.get('encoder_config')
            for m in all_models_data
            for col in m.get('columns', [])
        )

        # _shared/__init__.py
        init_template = self.jinja_env.get_template('shared/__init__.py.jinja2')
        (shared_dir / '__init__.py').write_text(init_template.render(), encoding='utf-8')

        # _shared/utils/__init__.py
        utils_init = self.jinja_env.get_template('shared/utils/__init__.py.jinja2')
        (utils_dir / '__init__.py').write_text(utils_init.render(has_vector_encoders=has_vector_encoders), encoding='utf-8')

        # _shared/utils/funcs.py
        funcs_template = self.jinja_env.get_template('shared/utils/funcs.py.jinja2')
        model_imports = [
            {'domain': m.tablename, 'name': m._name}
            for m in self.models
        ]
        funcs_code = funcs_template.render(
            logger_name=self.logger_name,
            schema_name=pm.db.schema_name,
            models=all_models_data,
            model_imports=model_imports,
            shared_import_prefix='.' + self.import_prefix,
        )
        (utils_dir / 'funcs.py').write_text(funcs_code, encoding='utf-8')

        # _shared/utils/rls.py
        rls_template = self.jinja_env.get_template('shared/utils/rls.py.jinja2')
        rls_code = rls_template.render(
            logger_name=self.logger_name,
            schema_name=pm.db.schema_name,
        )
        (utils_dir / 'rls.py').write_text(rls_code, encoding='utf-8')

        # _shared/utils/encoders.py — only when vector+encoder columns exist
        encoders_path = utils_dir / 'encoders.py'
        if has_vector_encoders:
            encoders_template = self.jinja_env.get_template('shared/utils/encoders.py.jinja2')
            encoders_code = encoders_template.render(models=all_models_data)
            encoders_path.write_text(encoders_code, encoding='utf-8')
        elif encoders_path.exists():
            encoders_path.unlink()

        # _shared/aggregation.py
        agg_template = self.jinja_env.get_template('shared/aggregation.py.jinja2')
        agg_code = agg_template.render(
            logger_name=self.logger_name,
        )
        (shared_dir / 'aggregation.py').write_text(agg_code, encoding='utf-8')

    def _generate_domain_model(self, domain: Path, model: Table | View, model_info: dict) -> None:
        template = self.jinja_env.get_template('domain/model.py.jinja2')
        code = template.render(
            model=model_info,
            is_view=model.is_view,
            is_postgres=pm.db.provider.drivername == 'postgresql',
            schema_name=pm.db.schema_name,
            encrypt=self._model_has_encrypt(model),
            has_calculated=self._model_has_calculated(model),
            import_prefix=self.import_prefix,
        )
        (domain / 'model.py').write_text(code, encoding='utf-8')

    def _generate_domain_dtos(
        self, domain: Path, model_info: dict, all_models: list
    ) -> None:
        template = self.jinja_env.get_template('domain/dtos.py.jinja2')
        code = template.render(
            model=model_info,
            models=all_models,
            schema_name=pm.db.schema_name,
            max_depth=self.max_depth,
            import_prefix=self.import_prefix,
        )
        (domain / 'dtos.py').write_text(code, encoding='utf-8')

    def _generate_domain_dao(
        self,
        domain: Path,
        model_info: dict,
        all_models: list,
        is_async: bool,
    ) -> None:
        template = self.jinja_env.get_template('domain/dao.py.jinja2')
        prefix = 'Async' if is_async else 'Sync'
        code = template.render(
            model=model_info,
            models=all_models,
            schema_name=pm.db.schema_name,
            max_depth=self.max_depth,
            logger_name=self.logger_name,
            is_async=is_async,
            prefix=prefix,
            session_type='AsyncSession' if is_async else 'Session',
            session_manager_var='async_session_manager' if is_async else 'sync_session_manager',
            session_manager_class='AsyncSessionManager' if is_async else 'SyncSessionManager',
            def_keyword='async def' if is_async else 'def',
            await_keyword='await ' if is_async else '',
            with_keyword='async with' if is_async else 'with',
            error_handler_name='async_error_handler' if is_async else 'sync_error_handler',
            import_prefix=self.import_prefix,
        )
        filename = 'dao_async.py' if is_async else 'dao_sync.py'
        (domain / filename).write_text(code, encoding='utf-8')

    def _generate_domain_init(self, domain: Path, model_info: dict) -> None:
        template = self.jinja_env.get_template('domain/__init__.py.jinja2')
        code = template.render(model=model_info)
        (domain / '__init__.py').write_text(code, encoding='utf-8')

    def _generate_facade(self, schema_dir: Path, all_models: list) -> None:
        template = self.jinja_env.get_template('facade.py.jinja2')
        enums = [enum.info() for enum in self.enums]
        code = template.render(
            models=all_models,
            enums=enums,
            schema_name=pm.db.schema_name,
        )
        (schema_dir / '__init__.py').write_text(code, encoding='utf-8')

    # ── Validation ────────────────────────────────────────────────────────

    def _cleanup_stale_domains(self, schema_dir: Path) -> None:
        """Remove domain directories that no longer correspond to any model."""
        import shutil
        current_tablenames = {model.tablename for model in self.models}
        reserved = {'_shared', '_base.py', '_session.py', '__init__.py'}
        for entry in schema_dir.iterdir():
            if entry.name in reserved or entry.name.startswith('_'):
                continue
            if entry.is_dir() and entry.name not in current_tablenames:
                shutil.rmtree(entry)

    def validate_configuration(self) -> bool:
        if not pm.db.provider:
            raise ValueError("No se ha configurado un provider. Usa datasource() primero.")
        if not pm.db.provider.source_input_type:
            raise ValueError("El provider no tiene source_input_type configurado.")
        if not self.models:
            raise ValueError("No se encontraron modelos para generar.")
        return True

    def __str__(self) -> str:
        return f"PythonClientGenerator(output_dir={self.config.output_dir})"

    def __repr__(self) -> str:
        return self.__str__()
