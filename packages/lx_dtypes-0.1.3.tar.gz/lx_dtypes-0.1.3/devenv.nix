{
  pkgs,
  lib,
  config,
  inputs,
  baseBuildInputs,
  ...
}:
let
  # Pin to specific Python 3.12 version to match pyproject.toml
  python = pkgs.python312; # known devenv issue with python3Packages since python3Full was deprecated
  uvPackage = pkgs.uv;

  buildInputs = with pkgs; [
    python312
    stdenv.cc.cc
    openssh
    pkg-config
    protobuf
    libglvnd
  ];
  runtimePackages = with pkgs; [
    stdenv.cc.cc
    ffmpeg-headless.bin
    tesseract
    uvPackage
    libglvnd
    glib
    zlib
    ollama.out
  ];

  _module.args.buildInputs = baseBuildInputs;

  SYNC_CMD = "uv sync --extra dev --extra docs --frozen --python .devenv/state/venv";  
  DJANGO_APP_NAME = "lx_dtypes.django";
  DJANGO_APP_LABEL = "lx_dtypes_django";
  DJANGO_APP_DIR = "./lx_dtypes/contrib/${DJANGO_APP_NAME}";

in
{

  # A dotenv file was found, while dotenv integration is currently not enabled.
  dotenv.enable = true;
  dotenv.disableHint = true;

  packages = lib.unique (runtimePackages ++ buildInputs);
  outputs =
    lib.optionalAttrs (inputs ? pyproject-nix) (
      let
        python_package = pkgs.callPackage ./python-package.nix { };
        kb_package = pkgs.callPackage ./package.nix { };
        app_package = pkgs.callPackage ./app-package.nix {
          inherit kb_package python_package;
        };
      in
      {
        python = python_package;
        kb = kb_package;
        app = app_package;
      }
    );
  env = {
    # include runtimePackages as well so runtime native libs (e.g. zlib) are on LD_LIBRARY_PATH
    LD_LIBRARY_PATH =
      lib.makeLibraryPath (buildInputs ++ runtimePackages)
      + ":/run/opengl-driver/lib:/run/opengl-driver-32/lib";
    LX_DTYPES_EDITOR_KB_REGISTRY = "../lx-terminology-editor/.published/kb_registry.json";
  };

  languages.python = {
    enable = true;
    package = python;
    uv = {
      enable = true;
      package = uvPackage;
      sync.enable = true;
    };
  };

  scripts = {
    export-nix-vars.exec = ''
      cat > .devenv-vars.json << EOF
      {
      }
      EOF
      echo "Exported Nix variables to .devenv-vars.json"
    '';

    env-setup.exec = ''
      # Ensure runtimePackages are included in the library path here too
      export LD_LIBRARY_PATH="${
        with pkgs; lib.makeLibraryPath (buildInputs ++ runtimePackages)
      }:/run/opengl-driver/lib:/run/opengl-driver-32/lib"
    '';

    hello.package = pkgs.zsh;
    hello.exec = "uv run python hello.py";
    pyshell.exec = "uv run python manage.py shell";
    mkmigrations.exec = "uv run python manage.py makemigrations ${DJANGO_APP_LABEL}";
    migrate.exec = "uv run python manage.py migrate";
    runserver.exec = "uv run python manage.py runserver";
    resetdb.exec = "rm -f db.sqlite3";
    resetmigrations.exec = ''
      rm -rf ${DJANGO_APP_DIR}/migrations/
      uv run python manage.py makemigrations ${DJANGO_APP_LABEL}
    '';

    mp.exec = "uv run python -m mypy lx_dtypes";
    pc.exec = "pre-commit run --all-files";

    mkdocs.exec = ''
      uv run make -C docs clean
      uv run make -C docs html
      uv run make -C docs linkcheck
      tar -czf docs_build.tar.gz -C docs _build/html
    '';
    uvsnc.exec = ''
      ${SYNC_CMD}
    '';
  };

  tasks = {

    "env:clean" = {
      description = "Remove the uv virtual environment and lock file for a clean sync";
      exec = ''
        echo "Removing uv virtual environment: .devenv/state/venv"
        rm -rf .devenv/state/venv
        echo "Removing uv lock file: uv.lock"
        rm -f uv.lock
        echo "Environment cleaned. Re-enter the shell (e.g., 'exit' then 'devenv up') to trigger uv sync."
      '';
    };

  };

  processes = {
  };

  enterShell = ''

    export SYNC_CMD="${SYNC_CMD}"
    source .devenv/state/venv/bin/activate

    # Ensure dependencies are synced using uv
    # Check if venv exists. If not, run sync verbosely. If it exists, sync quietly.
    if [ ! -d ".devenv/state/venv" ]; then
       echo "Virtual environment not found. Running initial uv sync..."
       $SYNC_CMD || echo "Error: Initial uv sync failed. Please check network and pyproject.toml."
    else
       # Sync quietly if venv exists
       echo "Syncing Python dependencies with uv..."
       $SYNC_CMD --quiet || echo "Warning: uv sync failed. Environment might be outdated."
    fi

    # Activate Python virtual environment managed by uv
    ACTIVATED=false
    if [ -f ".devenv/state/venv/bin/activate" ]; then
      source .devenv/state/venv/bin/activate
      ACTIVATED=true
      echo "Virtual environment activated."
    else
      echo "Warning: uv virtual environment activation script not found. Run 'devenv task run env:clean' and re-enter shell."
    fi

    env-setup

    use_editor_kb() {
      export LX_DTYPES_KB_REGISTRY="$LX_DTYPES_EDITOR_KB_REGISTRY"
      echo "Using editor-published KB registry: $LX_DTYPES_KB_REGISTRY"
    }

    use_packaged_kb() {
      unset LX_DTYPES_KB_REGISTRY
      echo "Using packaged/default KB resolution."
    }

    show_kb_mode() {
      if [ -n "$LX_DTYPES_KB_REGISTRY" ]; then
        echo "KB mode: registry"
        echo "LX_DTYPES_KB_REGISTRY=$LX_DTYPES_KB_REGISTRY"
      else
        echo "KB mode: packaged/default"
      fi
      echo "LX_DTYPES_EDITOR_KB_REGISTRY=$LX_DTYPES_EDITOR_KB_REGISTRY"
    }
  '';

  enterTest = ''
    nvcc -V
    pytest --maxfail=1 --disable-warnings -q
  '';
}
