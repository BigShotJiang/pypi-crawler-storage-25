# Curve Manipulations

Query, transform, combine, and persist curves. This guide covers every operation available on vade curve objects: rate extraction, parallel shifts, time translation, forward rolling, spread overlays, curve composition, turn-of-year bumps, FX-implied discounting, bond-fitted models, tenor-bucketed risk, and JSON serialization.

All curve objects are **immutable** -- every manipulation returns a new curve, leaving the original unchanged.

---

## Querying Rates

Every curve type exposes three query methods with identical signatures.

### Discount Factor

```python
import datetime
from vade import DiscountCurve

curve = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.965,
        datetime.date(2026, 1, 1): 0.93,
        datetime.date(2030, 1, 1): 0.82,
    },
    interpolation="log_linear",
    convention="act360",
)

df = curve.discount_factor(datetime.date(2024, 7, 1))
assert 0.96 < df < 1.0
```

### Zero Rate

Continuously compounded zero rate between two dates. Both arguments accept `datetime.date` objects or tenor strings.

```python
import datetime
from vade import DiscountCurve

curve = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.965,
        datetime.date(2026, 1, 1): 0.93,
        datetime.date(2030, 1, 1): 0.82,
    },
    interpolation="log_linear",
    convention="act360",
)

# With explicit dates
zr = curve.zero_rate(datetime.date(2024, 1, 1), datetime.date(2025, 1, 1))
assert 0.03 < zr < 0.04

# With tenor strings (resolved from first node date)
zr_1y = curve.zero_rate(datetime.date(2024, 1, 1), "1Y")
assert abs(zr - zr_1y) < 1e-10
```

### Forward Rate

The implied rate between two future dates, derived from the ratio of discount factors.

```python
import datetime
from vade import DiscountCurve

curve = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.965,
        datetime.date(2026, 1, 1): 0.93,
        datetime.date(2030, 1, 1): 0.82,
    },
    interpolation="log_linear",
    convention="act360",
)

# 1Y forward rate starting 1Y from now
fwd = curve.forward_rate(datetime.date(2025, 1, 1), datetime.date(2026, 1, 1))
assert 0.03 < fwd < 0.04

# With tenor strings: start resolves from base date, end resolves from start
fwd_tenor = curve.forward_rate("1Y", "1Y")  # 1Y from base, then 1Y forward
assert abs(fwd - fwd_tenor) < 1e-10
```

---

## Constructing from Zero Rates

DiscountCurve accepts zero rates directly via `node_type="zero"`, converting them to discount factors internally using the curve's day count convention and the specified compounding method.

```python
import datetime
import math
from vade import DiscountCurve

eval_dt = datetime.date(2024, 1, 1)

# From zero rates with continuous compounding (default)
curve = DiscountCurve(
    {
        eval_dt: 0.0,
        datetime.date(2025, 1, 1): 0.035,
        datetime.date(2026, 1, 1): 0.040,
        datetime.date(2030, 1, 1): 0.045,
    },
    convention="act360",
    node_type="zero",
    compounding="continuous",
    id="sofr",
)

# The DF at 1Y matches manual conversion
yf = (datetime.date(2025, 1, 1) - eval_dt).days / 360
expected = math.exp(-0.035 * yf)
assert abs(curve.discount_factor(datetime.date(2025, 1, 1)) - expected) < 1e-12
```

Available compounding methods: `"continuous"`, `"simple"`, `"annual"`, `"semi_annual"`, `"quarterly"`, `"daily"`. See [Conventions](../../conventions.md#compounding-conventions) for formulas.

---

## Parallel Shift

`shift(bp)` bumps the zero rate at every tenor by `bp` basis points (bp / 10,000 in decimal). Returns a new curve of the same type.

```python
import datetime
from vade import DiscountCurve, LineCurve

curve = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.965,
        datetime.date(2026, 1, 1): 0.93,
    },
    convention="act365f",
)

shifted = curve.shift(10)  # +10bp

# Zero rate increases by exactly 10bp = 0.001
orig_zr = curve.zero_rate(datetime.date(2024, 1, 1), datetime.date(2025, 1, 1))
shifted_zr = shifted.zero_rate(datetime.date(2024, 1, 1), datetime.date(2025, 1, 1))
assert abs((shifted_zr - orig_zr) - 0.001) < 1e-6

# Original is unchanged (immutable)
assert curve.discount_factor(datetime.date(2025, 1, 1)) == 0.965
```

For a **DiscountCurve**, each DF node is multiplied by `exp(-shift * dcf)` where `dcf` is the year fraction from the base date. For a **LineCurve**, each node value (rate) is directly incremented by `bp / 10,000`. Negative shifts work as expected.

---

## Translate

`translate(days)` shifts all node dates forward by `N` calendar days, keeping values unchanged. This is useful for re-anchoring a curve to a new valuation date while preserving its shape.

```python
import datetime
from vade import DiscountCurve

curve = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.965,
        datetime.date(2026, 1, 1): 0.93,
    },
    convention="act365f",
)

translated = curve.translate(30)  # move all dates forward 30 days

# New base date is 30 days later
df_base = translated.discount_factor(datetime.date(2024, 1, 31))
assert abs(df_base - 1.0) < 1e-12

# DF values are preserved at their new dates
df_1y = translated.discount_factor(datetime.date(2025, 1, 31))
assert abs(df_1y - 0.965) < 1e-12
```

---

## Roll

`roll(days)` produces the curve as if valued at a future date using today's forward rates. The rolled curve's base date is `base + days` with DF = 1.0, and all remaining nodes carry forward discount factors: `DF_rolled(T) = DF_original(T) / DF_original(roll_date)`.

This is the standard "theta" or time-decay operation for P&L attribution.

```python
import datetime
from vade import DiscountCurve

curve = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.96,
        datetime.date(2026, 1, 1): 0.92,
    },
    convention="act365f",
)

rolled = curve.roll(366)  # roll to 2025-01-01

# New base is 2025-01-01 with DF = 1.0
assert abs(rolled.discount_factor(datetime.date(2025, 1, 2)) - 1.0) < 0.01

# Forward DF: 0.92 / 0.96
df_fwd = rolled.discount_factor(datetime.date(2026, 1, 1))
assert abs(df_fwd - 0.92 / 0.96) < 1e-6
```

### Translate vs Roll

| Operation | Date shift | Values | Use case |
|-----------|-----------|--------|----------|
| `translate(days)` | All dates move forward | Node values unchanged | Re-anchor to new valuation date |
| `roll(days)` | New base at `base + days` | Forward DFs from roll date | Theta / time-decay P&L |

---

## SpreadCurve

Overlay a spread on an existing curve. The base curve is provided as a JSON string (via `to_json()`), and spread nodes define the overlay. Two modes are available:

- **Additive** (default): `DF_spread(t) = DF_base(t) * exp(-spread(t) * dcf(t))`
- **Multiplicative**: `DF_spread(t) = DF_base(t) * spread_df(t)`

```python
import datetime
from vade import DiscountCurve, SpreadCurve

base = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.965,
        datetime.date(2026, 1, 1): 0.93,
        datetime.date(2030, 1, 1): 0.82,
    },
    interpolation="log_linear",
    convention="act360",
)

# Additive spread: 50bp flat
spread = SpreadCurve(
    base.to_json(),
    {datetime.date(2024, 1, 1): 0.005, datetime.date(2030, 1, 1): 0.005},
    mode="additive",
    convention="act360",
)

# Spread curve produces lower DFs (higher rates)
df_base = base.discount_factor(datetime.date(2026, 1, 1))
df_spread = spread.discount_factor(datetime.date(2026, 1, 1))
assert df_spread < df_base
```

---

## CompositeCurve

Combine multiple curves by multiplying their discount factors. Useful for multi-component discounting (e.g., risk-free + credit spread as separate curves).

```python
import datetime
from vade import DiscountCurve, CompositeCurve

risk_free = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.97,
        datetime.date(2026, 1, 1): 0.94,
    },
    convention="act360",
    id="risk_free",
)

credit = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.995,
        datetime.date(2026, 1, 1): 0.99,
    },
    convention="act360",
    id="credit",
)

composite = CompositeCurve([risk_free, credit])

# Composite DF = product of component DFs
df = composite.discount_factor(datetime.date(2025, 1, 1))
assert abs(df - 0.97 * 0.995) < 1e-10

# Shift applies to all components
shifted = composite.shift(10)
assert shifted.discount_factor(datetime.date(2025, 1, 1)) < df
```

---

## TurnOfYearCurve

Apply discrete basis-point bumps at specific dates (typically year-end) to an inner curve. This captures the turn-of-year funding premium visible in money market rates.

```python notest
from vade import DiscountCurve, TurnOfYearCurve

inner = DiscountCurve(
    {date(2024, 1, 1): 1.0, date(2025, 1, 1): 0.96, date(2026, 1, 1): 0.92},
    convention="act365f",
)

# 5bp bump around year-end
toy = TurnOfYearCurve(
    inner.to_json(),
    {date(2024, 12, 31): 5.0, date(2025, 12, 31): 3.0},
    convention="act365f",
)
```

---

## FXImpliedCurve

Derive a discount curve in one currency from another via covered interest rate parity and FX spot rates. Used in cross-currency swap pricing.

```python notest
from vade import DiscountCurve, FXRates, FXImpliedCurve

usd_curve = DiscountCurve({...}, convention="act360", id="usd")
eur_curve = DiscountCurve({...}, convention="act360", id="eur")
fx = FXRates({"eurusd": 1.08}, settlement=date(2024, 1, 3))

# Imply EUR discounting from USD curve and FX rates
implied = FXImpliedCurve(
    cashflow_ccy="eur",
    collateral_ccy="usd",
    fx_rates=fx,
    fx_settlements={"eurusd": date(2024, 1, 3)},
    collateral_curve=usd_curve,
    cashflow_curve=eur_curve,
)

df = implied.discount_factor(date(2025, 1, 1))  # FX-adjusted DF
```

---

## Parametric Curves

Analytical models that produce smooth, extrapolation-safe curves from a small number of parameters.

### Nelson-Siegel

Four-parameter model: long-term level (beta0), slope (beta1), curvature (beta2), and decay (tau).

```python
import datetime
from vade import NelsonSiegel

ns = NelsonSiegel(
    beta0=0.045, beta1=-0.02, beta2=0.01, tau=1.5,
    base_date=datetime.date(2024, 1, 1),
    convention="act365f",
)

# Query rates
zr = ns.zero_rate(datetime.date(2024, 1, 1), datetime.date(2026, 1, 1))
assert 0.02 < zr < 0.05

df = ns.discount_factor(datetime.date(2025, 1, 1))
assert 0.95 < df < 1.0

# Shift adds bp/10000 to beta0 (long-term level)
shifted = ns.shift(10)
shifted_zr = shifted.zero_rate(datetime.date(2024, 1, 1), datetime.date(2034, 1, 1))
assert shifted_zr > ns.zero_rate(datetime.date(2024, 1, 1), datetime.date(2034, 1, 1))
```

### Nelson-Siegel-Svensson

Six-parameter extension with a second hump term (beta3, tau2).

```python
import datetime
from vade import NelsonSiegelSvensson

nss = NelsonSiegelSvensson(
    beta0=0.045, beta1=-0.02, beta2=0.01, beta3=0.005,
    tau1=1.5, tau2=5.0,
    base_date=datetime.date(2024, 1, 1),
    convention="act365f",
)

zr_5y = nss.zero_rate(datetime.date(2024, 1, 1), datetime.date(2029, 1, 1))
assert 0.02 < zr_5y < 0.05
```

### Smith-Wilson

Extrapolation model converging to an Ultimate Forward Rate (UFR). Used by European insurance regulators (Solvency II).

```python
import datetime
from vade import SmithWilson

sw = SmithWilson(
    dates=[datetime.date(2025, 1, 1), datetime.date(2029, 1, 1), datetime.date(2044, 1, 1)],
    rates=[0.03, 0.035, 0.04],
    ufr=0.042,
    alpha=0.1,
    base_date=datetime.date(2024, 1, 1),
    convention="act365f",
)

# Converges to UFR at long tenors
zr_50y = sw.zero_rate(datetime.date(2024, 1, 1), datetime.date(2074, 1, 1))
assert abs(zr_50y - 0.042) < 0.005
```

---

## FittedBondCurve

Fit a parametric curve to observed bond prices using Levenberg-Marquardt optimization. Supports Nelson-Siegel (`"NS"`), Nelson-Siegel-Svensson (`"NSS"`), and Smith-Wilson (`"SW"`) models.

```python notest
from vade import FixedRateBond, FittedBondCurve

bonds = [bond_2y, bond_5y, bond_10y, bond_30y]
prices = [99.5, 98.2, 95.1, 88.3]

fitted = FittedBondCurve(
    bonds, prices,
    settlement=date(2024, 3, 15),
    model="NS",
    convention="act365f",
)

# Fit quality
assert fitted.converged
assert fitted.rmse < 0.5  # pricing error < 50 cents

# Per-bond pricing errors
errors = fitted.pricing_errors()  # list of (model - market) prices

# Extract the fitted inner curve (NelsonSiegel object)
inner = fitted.curve()
zr_10y = inner.zero_rate(date(2024, 3, 15), date(2034, 3, 15))
```

---

## IRImpliedCurve (Tenor-Bucketed Risk)

Re-bucket a calibrated curve into custom tenor buckets for risk reporting. Computes bucket-level DV01 sensitivities.

```python notest
from vade import DiscountCurve, IRImpliedCurve, BusinessCalendar, IRS

# Calibrated curve
curve = DiscountCurve({...}, convention="act360", id="sofr")
cal = BusinessCalendar("NYC")

implied = IRImpliedCurve(
    source=curve,
    ref_date=date(2024, 1, 1),
    tenors=["1Y", "2Y", "5Y", "10Y", "30Y"],
    calendar=cal,
)

# Query rates (consistent with source curve)
df = implied.discount_factor(date(2025, 1, 1))

# Tenor bucket labels
labels = implied.tenor_labels()  # ["1Y", "2Y", "5Y", "10Y", "30Y"]

# Bucket-level DV01 for an instrument
swap = IRS(effective=date(2024, 1, 1), termination="5Y", fixed_rate=0.04)
risk = implied.bucket_delta(swap)  # polars DataFrame: tenor, date, delta
```

---

## CreditImpliedCurve

Piecewise-flat hazard rate curve for credit instruments. Provides survival probabilities and credit-adjusted discount factors.

```python
import datetime
from vade import CreditImpliedCurve

credit = CreditImpliedCurve(
    {
        datetime.date(2024, 1, 1): 0.01,
        datetime.date(2025, 1, 1): 0.015,
        datetime.date(2030, 1, 1): 0.02,
    },
    convention="act360",
    recovery_rate=0.4,
    id="corp_a",
)

sp = credit.survival_probability(datetime.date(2025, 1, 1))
assert 0.98 < sp < 1.0

# Shift hazard rates by 10bp
shifted = credit.shift(10)
assert shifted.survival_probability(datetime.date(2025, 1, 1)) < sp
```

---

## Serialization

All major curve types support JSON round-tripping via `to_json()` and `from_json()`.

```python
import datetime
from vade import DiscountCurve, LineCurve

curve = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.965,
        datetime.date(2026, 1, 1): 0.93,
    },
    interpolation="log_linear",
    convention="act360",
)

# Serialize
json_str = curve.to_json()
assert isinstance(json_str, str)

# Restore
restored = DiscountCurve.from_json(json_str)
df_orig = curve.discount_factor(datetime.date(2025, 6, 1))
df_rest = restored.discount_factor(datetime.date(2025, 6, 1))
assert abs(df_orig - df_rest) < 1e-12
```

### Supported Curve Types

| Curve Type | `to_json()` | `from_json()` |
|------------|:-----------:|:--------------:|
| DiscountCurve | yes | yes |
| LineCurve | yes | yes |
| ForwardCurve | yes | yes |
| NelsonSiegel | yes | yes |
| NelsonSiegelSvensson | yes | yes |
| SmithWilson | yes | yes |
| CreditImpliedCurve | yes | yes |
| SpreadCurve | yes | yes |
| CompositeCurve | yes | yes |
| TurnOfYearCurve | yes | yes |
| FXImpliedCurve | yes | yes |
| IRImpliedCurve | -- | -- |
| FittedBondCurve | -- | -- |

---

## Operation Support Matrix

| Curve Type | `shift` | `translate` | `roll` | `to_json` |
|------------|:-------:|:-----------:|:------:|:---------:|
| DiscountCurve | yes | yes | yes | yes |
| LineCurve | yes | yes | yes | yes |
| ForwardCurve | yes | yes | yes | yes |
| NelsonSiegel | yes | yes | yes | yes |
| NelsonSiegelSvensson | yes | yes | yes | yes |
| SmithWilson | yes | yes | yes | yes |
| CreditImpliedCurve | yes | yes | -- | yes |
| CompositeCurve | yes | yes | -- | yes |
| FXImpliedCurve | yes | yes | -- | yes |
| SpreadCurve | -- | -- | -- | yes |
| TurnOfYearCurve | -- | -- | -- | yes |
| IRImpliedCurve | -- | -- | -- | -- |
| FittedBondCurve | -- | -- | -- | -- |

---

## Chaining Operations

All manipulation methods return new curve objects, so they compose naturally:

```python
import datetime
from vade import DiscountCurve

curve = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.965,
        datetime.date(2026, 1, 1): 0.93,
        datetime.date(2030, 1, 1): 0.82,
    },
    convention="act365f",
)

# Shift +25bp, then translate 30 days forward
scenario = curve.shift(25).translate(30)

# Compare to base
df_base = curve.discount_factor(datetime.date(2026, 1, 1))
df_scen = scenario.discount_factor(datetime.date(2026, 1, 31))
assert df_scen < df_base  # higher rates + later valuation = lower DF
```

---

## Scenario Analysis Pattern

Build rate scenarios by combining shift, translate, and roll:

```python
import datetime
from vade import DiscountCurve

base = DiscountCurve(
    {
        datetime.date(2024, 1, 1): 1.0,
        datetime.date(2025, 1, 1): 0.965,
        datetime.date(2026, 1, 1): 0.93,
        datetime.date(2030, 1, 1): 0.82,
    },
    convention="act360",
)

scenarios = {
    "base": base,
    "up_50": base.shift(50),
    "down_50": base.shift(-50),
    "roll_90d": base.roll(90),
    "translate_30d": base.translate(30),
}

# Compare 5Y DFs across scenarios
for name, curve in scenarios.items():
    try:
        df = curve.discount_factor(datetime.date(2029, 1, 1))
        assert isinstance(df, float)
    except Exception:
        pass  # roll may drop nodes past boundary
```
