"""Type stubs for vade.calendar module."""

import datetime
from typing import List, Optional

class BusinessCalendar:
    """Business day calendar with holidays and weekend conventions."""

    def __init__(self, name: str) -> None:
        """Create a named calendar.

        Args:
            name: Calendar identifier (e.g., "NYC", "LDN", "TGT", "TYO", "SYD",
                  "ZUR", "STK", "OSL", "TRO", "FED", "WLG", "MUM", "MEX", "BJS", "NSW").
        """
        ...

    @staticmethod
    def new_custom(holidays: List[str], weekmask: List[int]) -> "BusinessCalendar":
        """Create a custom calendar.

        Args:
            holidays: Holiday dates as "YYYY-MM-DD" strings.
            weekmask: Weekend day numbers (0=Mon, 5=Sat, 6=Sun).
        """
        ...

    def is_holiday(self, date: datetime.date) -> bool:
        """Check if a date is a holiday."""
        ...

    def is_business_day(self, date: datetime.date) -> bool:
        """Check if a date is a business day."""
        ...

    def bus_day_count(self, start: datetime.date, end: datetime.date) -> int:
        """Count business days between start (inclusive) and end (exclusive)."""
        ...

    def union_cal(self, other: "BusinessCalendar") -> "BusinessCalendar":
        """Create a union calendar (settlement: any holiday from either)."""
        ...

    def __repr__(self) -> str: ...

class Schedule:
    """Financial schedule with regular periods and optional stubs."""

    def __init__(
        self,
        effective: datetime.date,
        termination: datetime.date,
        frequency: str,
        calendar: Optional[BusinessCalendar] = None,
        adjuster: str = "modified_following",
        roll_day: Optional[str] = None,
        front_stub: Optional[datetime.date] = None,
        back_stub: Optional[datetime.date] = None,
        stub_inference: str = "short_front",
        rule: Optional[str] = None,
    ) -> None:
        """Create a new schedule.

        Args:
            effective: Start date.
            termination: End date.
            frequency: Period frequency ("M", "Q", "S", "A", "Z").
            calendar: Business day calendar (default: weekends-only).
            adjuster: Business day adjustment rule (default: "modified_following").
            roll_day: Roll day convention ("eom", "imm", or day number 1-31).
            front_stub: Optional explicit front stub date.
            back_stub: Optional explicit back stub date.
            stub_inference: Stub preference ("short_front", "long_front", "short_back", "long_back").
            rule: Schedule generation rule ("standard" or "cds"). CDS generates
                quarterly dates on the 20th of IMM months; termination is never adjusted.
        """
        ...

    @property
    def unadjusted_dates(self) -> List[datetime.date]:
        """Unadjusted period boundary dates."""
        ...

    @property
    def adjusted_dates(self) -> List[datetime.date]:
        """Adjusted period boundary dates."""
        ...

    @property
    def n_periods(self) -> int:
        """Number of periods."""
        ...

    def has_front_stub(self) -> bool:
        """Whether the schedule has a front stub."""
        ...

    def has_back_stub(self) -> bool:
        """Whether the schedule has a back stub."""
        ...

    def __len__(self) -> int: ...
    def __repr__(self) -> str: ...

def dcf(
    convention: str,
    start: datetime.date,
    end: datetime.date,
    calendar: Optional[BusinessCalendar] = None,
    termination: Optional[datetime.date] = None,
) -> float:
    """Compute day count fraction between two dates.

    Args:
        convention: Day count convention ("act360", "act365f", "actactisda",
                   "30/360", "30e/360", "30e/360isda", "bus252", "one").
        start: Start date.
        end: End date.
        calendar: Optional calendar (required for "bus252").
        termination: Optional termination date (required for "30e/360isda").
    """
    ...

def add_tenor(
    date: datetime.date,
    tenor: str,
    calendar: Optional[BusinessCalendar] = None,
) -> datetime.date:
    """Add a tenor to a date.

    Args:
        date: Base date.
        tenor: Tenor string (e.g., "2Y", "6M", "1W", "3D", "3B").
        calendar: Optional calendar (required for business day tenors).
    """
    ...

def add_business_days(
    date: datetime.date,
    days: int,
    calendar: BusinessCalendar,
) -> datetime.date:
    """Add business days to a date.

    Args:
        date: Base date.
        days: Number of business days (positive forward, negative backward).
        calendar: Business day calendar.
    """
    ...

def parse_date(
    date_string: str,
    format: str = "%Y-%m-%d",
) -> datetime.date:
    """Parse a date string into a datetime.date object.

    Uses Rust chrono for fast parsing. Supports any strftime format string.

    Args:
        date_string: The date string to parse.
        format: strftime format string (default: "%Y-%m-%d").

    Returns:
        Parsed date as datetime.date.

    Raises:
        ValueError: If the string cannot be parsed with the given format.

    Example:
        >>> import vade
        >>> vade.parse_date("2024-03-15")
        datetime.date(2024, 3, 15)
        >>> vade.parse_date("15/03/2024", "%d/%m/%Y")
        datetime.date(2024, 3, 15)
    """
    ...
