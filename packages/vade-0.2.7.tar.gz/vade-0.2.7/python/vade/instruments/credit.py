"""Credit instrument classes: bonds, CDS, AssetSwap, CallableBond."""
from __future__ import annotations

import datetime
from typing import Any, Optional, Union

from vade._vade_rs.instruments import (
    PyBondInstrument,
    CreditDefaultSwap as _PyCDS,
    PyAssetSwap,
    PyCallableBond,
)
from vade.instruments._helpers import (
    _parse_frequency,
    _parse_modifier,
    _parse_termination,
    _merge_spec_params,
    _resolve_curves_from_context,
    _resolve_fixings,
)
from vade.cashflows.dataframe import cashflows_to_polars

class FixedRateBond:
    """Fixed Rate Bond with full analytics suite.

    Construct with spec or explicit parameters::

        bond = FixedRateBond(
            spec="us_treasury",
            effective=date(2024, 1, 15),
            termination="10Y",
            coupon=0.04,
        )
    """

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        coupon: float = 0.0,
        frequency: str = "s",
        settlement_days: int = 1,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "actactisda",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "none",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        params = _merge_spec_params(spec, {
            "coupon": coupon,
            "frequency": frequency,
            "settlement_days": settlement_days,
            "ex_div_days": ex_div_days,
            "calendar": calendar,
            "currency": currency,
            "convention": convention,
            "accrued_convention": accrued_convention,
            "face_value": face_value,
            "modifier": modifier,
        })
        params.update(extra_kwargs)

        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PyBondInstrument(
            variant="fixed_rate_bond",
            effective=effective,
            termination=term_date,
            coupon=params.get("coupon", 0.0),
            frequency=_parse_frequency(params.get("frequency", "s")),
            settlement_days=params.get("settlement_days", 1),
            ex_div_days=params.get("ex_div_days", 0),
            calendar=params.get("calendar"),
            currency=params.get("currency", "USD"),
            convention=params.get("convention", "actactisda"),
            accrued_convention=params.get("accrued_convention"),
            face_value=params.get("face_value", 100.0),
            modifier=_parse_modifier(params.get("modifier", "none")),
        )
        self._disc_curve_id = disc_curve_id
        self._index = index
        self._inner.set_eval_date(datetime.date.today())

    def price(self, curves=None, *, solver=None, ctx=None, settlement: Optional[datetime.date] = None):
        """Clean price."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.price(curves, settlement)

    def dirty_price(self, curves=None, *, solver=None, ctx=None, settlement: Optional[datetime.date] = None):
        """Dirty price (clean + accrued)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dirty_price(curves, settlement)

    def accrued_interest(self, settlement: datetime.date) -> float:
        """Accrued interest at settlement date."""
        return self._inner.accrued_interest(settlement)

    def accrued_days(self, settlement: datetime.date) -> int:
        """Number of accrued days at settlement using the bond's accrued day-count convention."""
        return self._inner.accrued_days(settlement)

    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Yield to maturity from clean price."""
        return self._inner.ytm(clean_price, settlement, convention)

    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Price from yield to maturity."""
        return self._inner.price_from_ytm(ytm, settlement, convention)

    def duration(self, curves=None, *, solver=None, ctx=None, metric: str = "modified",
                 settlement: Optional[datetime.date] = None) -> float:
        """Duration (macaulay or modified)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.duration(curves, metric, settlement)

    def convexity(self, curves=None, *, solver=None, ctx=None,
                  settlement: Optional[datetime.date] = None) -> float:
        """Convexity."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.convexity(curves, settlement)

    def duration_from_ytm(self, ytm: float, settlement: datetime.date,
                          metric: str = "modified", convention: str = "periodic") -> float:
        """Analytical duration from yield to maturity.

        Does not require a discount curve. Uses analytical formula.

        Args:
            ytm: Yield to maturity as decimal (e.g. 0.05 for 5%).
            settlement: Settlement date for cashflow filtering and accrual.
            metric: "macaulay" or "modified" (default).
            convention: Compounding convention for discounting. Default "periodic"
                uses coupon frequency (1+ytm/freq)^(-n).
        """
        return self._inner.duration_from_ytm(ytm, settlement, metric, convention)

    def convexity_from_ytm(self, ytm: float, settlement: datetime.date,
                           convention: str = "periodic") -> float:
        """Analytical convexity from yield to maturity.

        Does not require a discount curve. Uses analytical formula.

        Args:
            ytm: Yield to maturity as decimal.
            settlement: Settlement date.
            convention: Compounding convention. Default "periodic".
        """
        return self._inner.convexity_from_ytm(ytm, settlement, convention)

    def dv01(self, curves=None, *, solver=None, ctx=None) -> float:
        """Dollar value of a basis point."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dv01(curves)

    def z_spread(self, curves=None, *, solver=None, ctx=None, price: Optional[float] = None,
                 settlement: Optional[datetime.date] = None, compounding: str = "annual") -> float:
        """Z-spread over the discount curve.

        Args:
            compounding: Compounding convention for the spread. One of
                "continuous", "annual" (default), "semi_annual", "quarterly", "daily", "simple".
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for z_spread")
        return self._inner.z_spread(curves, price, settlement, compounding)

    def asw_spread(self, curves=None, *, solver=None, ctx=None, price: Optional[float] = None,
                   method: str = "par_par", settlement: Optional[datetime.date] = None) -> float:
        """Asset swap spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for asw_spread")
        return self._inner.asw_spread(curves, price, method, settlement)

    def cs01(self, curves=None, *, solver=None, ctx=None) -> float:
        """Credit spread sensitivity (1bp)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.cs01(curves)

    def price_yield_sensitivity(self, curves=None, *, solver=None, ctx=None) -> float:
        """Price-yield sensitivity."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.price_yield_sensitivity(curves)

    def rate(self, curves=None, *, solver=None, ctx=None):
        """Par rate (clean price for solver)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None,
            future_only: bool = True, eval_date=None):
        """Net present value (dirty price).

        Args:
            future_only: If True (default), exclude cashflows with payment before eval_date.
                Matches QuantLib includeSettlementDateFlows=false convention.
            eval_date: Reference date for future_only filtering. Defaults to effective date.
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves, future_only, eval_date)

    def cashflows(self, curves=None, *, solver=None, ctx=None,
                  future_only: bool = False, eval_date=None):
        """Cashflows as Polars DataFrame.

        Args:
            future_only: If True, exclude cashflows with payment <= eval_date.
            eval_date: Cutoff date for future_only (defaults to eval_date set at construction).
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves, future_only, eval_date)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        """Spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.spread(curves)

    def analytic_delta(self, curves=None, *, solver=None, ctx=None):
        """Analytic delta."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.analytic_delta(curves)

    def i_spread(self, settlement: datetime.date, swap_curve=None) -> float:
        """I-spread: YTM minus interpolated swap zero rate at maturity."""
        return self._inner.i_spread(settlement, swap_curve)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "FixedRateBond(...)"


class Bill:
    """Zero-coupon bill (Treasury bill).

    Construct with spec or explicit parameters::

        bill = Bill(
            spec="us_tbill",
            effective=date(2024, 1, 15),
            termination="6M",
        )
    """

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        settlement_days: int = 1,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "act360",
        face_value: float = 100.0,
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        params = _merge_spec_params(spec, {
            "settlement_days": settlement_days,
            "calendar": calendar,
            "currency": currency,
            "convention": convention,
            "face_value": face_value,
        })
        params.update(extra_kwargs)

        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PyBondInstrument(
            variant="bill",
            effective=effective,
            termination=term_date,
            settlement_days=params.get("settlement_days", 1),
            calendar=params.get("calendar"),
            currency=params.get("currency", "USD"),
            convention=params.get("convention", "act360"),
            face_value=params.get("face_value", 100.0),
        )
        self._disc_curve_id = disc_curve_id
        self._index = index
        self._inner.set_eval_date(datetime.date.today())

    def price(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.price(curves)

    def dirty_price(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dirty_price(curves)

    def accrued_interest(self, settlement: datetime.date) -> float:
        """Accrued interest at settlement date (always 0 for bills)."""
        return self._inner.accrued_interest(settlement)

    def accrued_days(self, settlement: datetime.date) -> int:
        """Number of accrued days at settlement (always 0 for bills)."""
        return self._inner.accrued_days(settlement)

    def ytm(self, clean_price: float, settlement: datetime.date) -> float:
        return self._inner.ytm(clean_price, settlement)

    def rate(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None,
            future_only: bool = True, eval_date=None):
        """Net present value (dirty price).

        Args:
            future_only: If True (default), exclude cashflows with payment before eval_date.
                Matches QuantLib includeSettlementDateFlows=false convention.
            eval_date: Reference date for future_only filtering. Defaults to effective date.
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves, future_only, eval_date)

    def cashflows(self, curves=None, *, solver=None, ctx=None,
                  future_only: bool = False, eval_date=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves, future_only, eval_date)
        return cashflows_to_polars(rows)

    def i_spread(self, settlement: datetime.date, swap_curve=None) -> float:
        """I-spread: YTM minus interpolated swap zero rate at maturity."""
        return self._inner.i_spread(settlement, swap_curve)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "Bill(...)"


class FloatRateNote:
    """Floating Rate Note (FRN).

    Construct with spec or explicit parameters::

        frn = FloatRateNote(
            spec="usd_frn",
            effective=date(2024, 1, 15),
            termination="5Y",
            spread=0.005,
            index="EURIBOR_6M",
            fixings={date(2024, 1, 15): 0.035, ...},
        )

    Historical fixings are applied at construction and used for past coupon
    accrual. Future coupons use forward rates from the pricing curve.
    """

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        spread: float = 0.0,
        frequency: str = "q",
        settlement_days: int = 2,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "act360",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "mf",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        fixings: Optional[dict] = None,
        fixing_lag: Optional[int] = None,
        **extra_kwargs: Any,
    ):
        params = _merge_spec_params(spec, {
            "spread": spread,
            "frequency": frequency,
            "settlement_days": settlement_days,
            "ex_div_days": ex_div_days,
            "calendar": calendar,
            "currency": currency,
            "convention": convention,
            "accrued_convention": accrued_convention,
            "face_value": face_value,
            "modifier": modifier,
        })
        params.update(extra_kwargs)

        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PyBondInstrument(
            variant="float_rate_note",
            effective=effective,
            termination=term_date,
            spread=params.get("spread", 0.0),
            frequency=_parse_frequency(params.get("frequency", "q")),
            settlement_days=params.get("settlement_days", 2),
            ex_div_days=params.get("ex_div_days", 0),
            calendar=params.get("calendar"),
            currency=params.get("currency", "USD"),
            convention=params.get("convention", "act360"),
            accrued_convention=params.get("accrued_convention"),
            face_value=params.get("face_value", 100.0),
            modifier=_parse_modifier(params.get("modifier", "mf")),
            fixing_lag=fixing_lag,
        )
        self._disc_curve_id = disc_curve_id
        self._index = index
        self._inner.set_eval_date(datetime.date.today())

        # Apply fixings: explicit > module-level by index name
        resolved = fixings
        if resolved is None and index is not None:
            resolved = _resolve_fixings(index)
        if resolved:
            self._inner.set_fixings(resolved)

    def set_fixings(self, fixings: dict) -> None:
        """Apply historical index fixings (date → rate) to floating periods.

        The rate should be the index rate only (e.g. EURIBOR); spread is
        added internally.
        """
        self._inner.set_fixings(fixings)

    def price(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.price(curves)

    def dirty_price(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dirty_price(curves)

    def accrued_interest(self, settlement: datetime.date) -> float:
        """Accrued interest at settlement date."""
        return self._inner.accrued_interest(settlement)

    def accrued_days(self, settlement: datetime.date) -> int:
        """Number of accrued days at settlement using the bond's accrued day-count convention."""
        return self._inner.accrued_days(settlement)

    def rate(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None,
            future_only: bool = True, eval_date=None):
        """Net present value (dirty price).

        Args:
            future_only: If True (default), exclude cashflows with payment before eval_date.
                Matches QuantLib includeSettlementDateFlows=false convention.
            eval_date: Reference date for future_only filtering. Defaults to effective date.
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves, future_only, eval_date)

    def cashflows(self, curves=None, *, solver=None, ctx=None,
                  future_only: bool = False, eval_date=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves, future_only, eval_date)
        return cashflows_to_polars(rows)

    def analytic_delta(self, curves=None, *, solver=None, ctx=None):
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.analytic_delta(curves)

    def i_spread(self, settlement: datetime.date, swap_curve=None) -> float:
        """I-spread: YTM minus interpolated swap zero rate at maturity."""
        return self._inner.i_spread(settlement, swap_curve)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "FloatRateNote(...)"


class ZeroCouponBond:
    """Zero-coupon bond (capital market) with OID accrued interest.

    Distinct from Bill (money market). Uses compound discounting for pricing
    and the OID constant-yield method for accrued interest.

    Construct with explicit parameters::

        zcb = ZeroCouponBond(
            effective=date(2024, 1, 15),
            termination="10Y",
            issue_price=70.0,
        )
    """

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        issue_price: float = 100.0,
        frequency: str = "s",
        settlement_days: int = 1,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "actactisda",
        face_value: float = 100.0,
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ):
        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PyBondInstrument(
            variant="zero_coupon_bond",
            effective=effective,
            termination=term_date,
            frequency=_parse_frequency(frequency),
            settlement_days=settlement_days,
            calendar=calendar,
            currency=currency,
            convention=convention,
            face_value=face_value,
            issue_price=issue_price,
        )
        self._disc_curve_id = disc_curve_id
        self._index = index
        self._inner.set_eval_date(datetime.date.today())

    def price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Clean price."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.price(curves, settlement)

    def dirty_price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Dirty price (clean + accrued)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dirty_price(curves, settlement)

    def accrued_interest(self, settlement: datetime.date) -> float:
        """OID accrued interest at settlement date (compound method)."""
        return self._inner.accrued_interest(settlement)

    def accrued_days(self, settlement: datetime.date) -> int:
        """Number of accrued days at settlement using the bond's accrued day-count convention."""
        return self._inner.accrued_days(settlement)

    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Yield to maturity from clean price."""
        return self._inner.ytm(clean_price, settlement, convention)

    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Price from yield to maturity (compound discounting)."""
        return self._inner.price_from_ytm(ytm, settlement, convention)

    def duration(self, curves=None, *, solver=None, ctx=None, metric: str = "modified", settlement=None) -> float:
        """Duration (macaulay or modified)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.duration(curves, metric, settlement)

    def convexity(self, curves=None, *, solver=None, ctx=None, settlement=None) -> float:
        """Convexity."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.convexity(curves, settlement)

    def duration_from_ytm(self, ytm: float, settlement: datetime.date,
                          metric: str = "modified", convention: str = "periodic") -> float:
        """Analytical duration from yield to maturity."""
        return self._inner.duration_from_ytm(ytm, settlement, metric, convention)

    def convexity_from_ytm(self, ytm: float, settlement: datetime.date,
                           convention: str = "periodic") -> float:
        """Analytical convexity from yield to maturity."""
        return self._inner.convexity_from_ytm(ytm, settlement, convention)

    def z_spread(self, curves=None, *, solver=None, ctx=None, price=None, settlement=None, compounding: str = "annual") -> float:
        """Z-spread over the discount curve."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for z_spread")
        return self._inner.z_spread(curves, price, settlement, compounding)

    def rate(self, curves=None, *, solver=None, ctx=None):
        """Par rate (clean price for solver)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None,
            future_only: bool = True, eval_date=None):
        """Net present value (dirty price).

        Args:
            future_only: If True (default), exclude cashflows with payment before eval_date.
                Matches QuantLib includeSettlementDateFlows=false convention.
            eval_date: Reference date for future_only filtering. Defaults to effective date.
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves, future_only, eval_date)

    def cashflows(self, curves=None, *, solver=None, ctx=None,
                  future_only: bool = False, eval_date=None):
        """Cashflows as Polars DataFrame.

        Args:
            future_only: If True, exclude cashflows with payment <= eval_date.
            eval_date: Cutoff date for future_only (defaults to eval_date set at construction).
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves, future_only, eval_date)
        return cashflows_to_polars(rows)

    def i_spread(self, settlement: datetime.date, swap_curve=None) -> float:
        """I-spread: YTM minus interpolated swap zero rate at maturity."""
        return self._inner.i_spread(settlement, swap_curve)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "ZeroCouponBond(...)"


class StepUpBond:
    """Step-up bond with different coupon rates per period.

    Coupon rates are specified as a list of (date, rate) tuples. Each rate
    applies from its date until the next date. Rate at period start wins
    if a rate change falls mid-period.

    Construct with explicit parameters::

        bond = StepUpBond(
            effective=date(2024, 1, 15),
            termination="5Y",
            coupon_rates=[
                (date(2024, 1, 15), 0.02),
                (date(2026, 1, 15), 0.03),
            ],
            frequency="s",
        )
    """

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        coupon_rates: Optional[list] = None,
        frequency: str = "s",
        settlement_days: int = 1,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "actactisda",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "none",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ):
        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")
        if coupon_rates is None or len(coupon_rates) == 0:
            raise ValueError("coupon_rates is required (list of (date, rate) tuples)")

        term_date = _parse_termination(effective, termination)

        self._inner = PyBondInstrument(
            variant="step_up_bond",
            effective=effective,
            termination=term_date,
            coupon_rates=coupon_rates,
            frequency=_parse_frequency(frequency),
            settlement_days=settlement_days,
            ex_div_days=ex_div_days,
            calendar=calendar,
            currency=currency,
            convention=convention,
            accrued_convention=accrued_convention,
            face_value=face_value,
            modifier=_parse_modifier(modifier),
        )
        self._disc_curve_id = disc_curve_id
        self._index = index
        self._inner.set_eval_date(datetime.date.today())

    def price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Clean price."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.price(curves, settlement)

    def dirty_price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Dirty price (clean + accrued)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dirty_price(curves, settlement)

    def accrued_interest(self, settlement: datetime.date) -> float:
        """Accrued interest at settlement date."""
        return self._inner.accrued_interest(settlement)

    def accrued_days(self, settlement: datetime.date) -> int:
        """Number of accrued days at settlement using the bond's accrued day-count convention."""
        return self._inner.accrued_days(settlement)

    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Yield to maturity from clean price."""
        return self._inner.ytm(clean_price, settlement, convention)

    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Price from yield to maturity."""
        return self._inner.price_from_ytm(ytm, settlement, convention)

    def duration(self, curves=None, *, solver=None, ctx=None, metric: str = "modified", settlement=None) -> float:
        """Duration (macaulay or modified)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.duration(curves, metric, settlement)

    def convexity(self, curves=None, *, solver=None, ctx=None, settlement=None) -> float:
        """Convexity."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.convexity(curves, settlement)

    def duration_from_ytm(self, ytm: float, settlement: datetime.date,
                          metric: str = "modified", convention: str = "periodic") -> float:
        """Analytical duration from yield to maturity."""
        return self._inner.duration_from_ytm(ytm, settlement, metric, convention)

    def convexity_from_ytm(self, ytm: float, settlement: datetime.date,
                           convention: str = "periodic") -> float:
        """Analytical convexity from yield to maturity."""
        return self._inner.convexity_from_ytm(ytm, settlement, convention)

    def dv01(self, curves=None, *, solver=None, ctx=None) -> float:
        """Dollar value of a basis point."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dv01(curves)

    def z_spread(self, curves=None, *, solver=None, ctx=None, price=None, settlement=None, compounding: str = "annual") -> float:
        """Z-spread over the discount curve."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for z_spread")
        return self._inner.z_spread(curves, price, settlement, compounding)

    def asw_spread(self, curves=None, *, solver=None, ctx=None, price=None, method: str = "par_par", settlement=None) -> float:
        """Asset swap spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for asw_spread")
        return self._inner.asw_spread(curves, price, method, settlement)

    def rate(self, curves=None, *, solver=None, ctx=None):
        """Par rate (clean price for solver)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None,
            future_only: bool = True, eval_date=None):
        """Net present value (dirty price).

        Args:
            future_only: If True (default), exclude cashflows with payment before eval_date.
                Matches QuantLib includeSettlementDateFlows=false convention.
            eval_date: Reference date for future_only filtering. Defaults to effective date.
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves, future_only, eval_date)

    def cashflows(self, curves=None, *, solver=None, ctx=None,
                  future_only: bool = False, eval_date=None):
        """Cashflows as Polars DataFrame.

        Args:
            future_only: If True, exclude cashflows with payment <= eval_date.
            eval_date: Cutoff date for future_only (defaults to eval_date set at construction).
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves, future_only, eval_date)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        """Spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.spread(curves)

    def analytic_delta(self, curves=None, *, solver=None, ctx=None):
        """Analytic delta."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.analytic_delta(curves)

    def i_spread(self, settlement: datetime.date, swap_curve=None) -> float:
        """I-spread: YTM minus interpolated swap zero rate at maturity."""
        return self._inner.i_spread(settlement, swap_curve)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "StepUpBond(...)"


class AmortizingBond:
    """Bond with declining notional and periodic principal repayments.

    The amortization schedule specifies principal repayment amounts at
    specific dates. Dates must coincide with coupon payment dates.
    Any remaining notional redeems at maturity.

    Construct with explicit parameters::

        bond = AmortizingBond(
            effective=date(2024, 1, 15),
            termination="5Y",
            coupon=0.05,
            amortization_schedule=[
                (date(2025, 7, 15), 20.0),
                (date(2026, 1, 15), 20.0),
                (date(2026, 7, 15), 20.0),
            ],
            frequency="s",
        )
    """

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        coupon: float = 0.0,
        amortization_schedule: Optional[list] = None,
        frequency: str = "s",
        settlement_days: int = 1,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "actactisda",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "none",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ):
        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")
        if amortization_schedule is None or len(amortization_schedule) == 0:
            raise ValueError("amortization_schedule is required (list of (date, amount) tuples)")

        term_date = _parse_termination(effective, termination)

        self._inner = PyBondInstrument(
            variant="amortizing_bond",
            effective=effective,
            termination=term_date,
            coupon=coupon,
            amortization_schedule=amortization_schedule,
            frequency=_parse_frequency(frequency),
            settlement_days=settlement_days,
            ex_div_days=ex_div_days,
            calendar=calendar,
            currency=currency,
            convention=convention,
            accrued_convention=accrued_convention,
            face_value=face_value,
            modifier=_parse_modifier(modifier),
        )
        self._disc_curve_id = disc_curve_id
        self._index = index
        self._inner.set_eval_date(datetime.date.today())

    def price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Clean price."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.price(curves, settlement)

    def dirty_price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Dirty price (clean + accrued)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dirty_price(curves, settlement)

    def accrued_interest(self, settlement: datetime.date) -> float:
        """Accrued interest at settlement date."""
        return self._inner.accrued_interest(settlement)

    def accrued_days(self, settlement: datetime.date) -> int:
        """Number of accrued days at settlement using the bond's accrued day-count convention."""
        return self._inner.accrued_days(settlement)

    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Yield to maturity from clean price."""
        return self._inner.ytm(clean_price, settlement, convention)

    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Price from yield to maturity."""
        return self._inner.price_from_ytm(ytm, settlement, convention)

    def duration(self, curves=None, *, solver=None, ctx=None, metric: str = "modified", settlement=None) -> float:
        """Duration (macaulay or modified)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.duration(curves, metric, settlement)

    def convexity(self, curves=None, *, solver=None, ctx=None, settlement=None) -> float:
        """Convexity."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.convexity(curves, settlement)

    def duration_from_ytm(self, ytm: float, settlement: datetime.date,
                          metric: str = "modified", convention: str = "periodic") -> float:
        """Analytical duration from yield to maturity."""
        return self._inner.duration_from_ytm(ytm, settlement, metric, convention)

    def convexity_from_ytm(self, ytm: float, settlement: datetime.date,
                           convention: str = "periodic") -> float:
        """Analytical convexity from yield to maturity."""
        return self._inner.convexity_from_ytm(ytm, settlement, convention)

    def dv01(self, curves=None, *, solver=None, ctx=None) -> float:
        """Dollar value of a basis point."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dv01(curves)

    def z_spread(self, curves=None, *, solver=None, ctx=None, price=None, settlement=None, compounding: str = "annual") -> float:
        """Z-spread over the discount curve."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for z_spread")
        return self._inner.z_spread(curves, price, settlement, compounding)

    def asw_spread(self, curves=None, *, solver=None, ctx=None, price=None, method: str = "par_par", settlement=None) -> float:
        """Asset swap spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for asw_spread")
        return self._inner.asw_spread(curves, price, method, settlement)

    def rate(self, curves=None, *, solver=None, ctx=None):
        """Par rate (clean price for solver)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None,
            future_only: bool = True, eval_date=None):
        """Net present value (dirty price).

        Args:
            future_only: If True (default), exclude cashflows with payment before eval_date.
                Matches QuantLib includeSettlementDateFlows=false convention.
            eval_date: Reference date for future_only filtering. Defaults to effective date.
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves, future_only, eval_date)

    def cashflows(self, curves=None, *, solver=None, ctx=None,
                  future_only: bool = False, eval_date=None):
        """Cashflows as Polars DataFrame.

        Args:
            future_only: If True, exclude cashflows with payment <= eval_date.
            eval_date: Cutoff date for future_only (defaults to eval_date set at construction).
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves, future_only, eval_date)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        """Spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.spread(curves)

    def analytic_delta(self, curves=None, *, solver=None, ctx=None):
        """Analytic delta."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.analytic_delta(curves)

    def i_spread(self, settlement: datetime.date, swap_curve=None) -> float:
        """I-spread: YTM minus interpolated swap zero rate at maturity."""
        return self._inner.i_spread(settlement, swap_curve)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "AmortizingBond(...)"


class PIKBond:
    """Payment-in-kind bond where accrued interest compounds into notional.

    The pik_fraction parameter controls how much interest compounds (1.0 =
    full PIK, 0.0 = all cash). Default is 1.0 (full PIK) per D-14.

    Construct with explicit parameters::

        bond = PIKBond(
            effective=date(2024, 1, 15),
            termination="5Y",
            coupon=0.06,
            pik_fraction=1.0,
            frequency="s",
        )
    """

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        coupon: float = 0.0,
        pik_fraction: float = 1.0,
        frequency: str = "s",
        settlement_days: int = 1,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "actactisda",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "none",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ):
        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PyBondInstrument(
            variant="pik_bond",
            effective=effective,
            termination=term_date,
            coupon=coupon,
            pik_fraction=pik_fraction,
            frequency=_parse_frequency(frequency),
            settlement_days=settlement_days,
            ex_div_days=ex_div_days,
            calendar=calendar,
            currency=currency,
            convention=convention,
            accrued_convention=accrued_convention,
            face_value=face_value,
            modifier=_parse_modifier(modifier),
        )
        self._disc_curve_id = disc_curve_id
        self._index = index
        self._inner.set_eval_date(datetime.date.today())

    def price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Clean price."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.price(curves, settlement)

    def dirty_price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Dirty price (clean + accrued)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dirty_price(curves, settlement)

    def accrued_interest(self, settlement: datetime.date) -> float:
        """Accrued interest at settlement date."""
        return self._inner.accrued_interest(settlement)

    def accrued_days(self, settlement: datetime.date) -> int:
        """Number of accrued days at settlement using the bond's accrued day-count convention."""
        return self._inner.accrued_days(settlement)

    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Yield to maturity from clean price."""
        return self._inner.ytm(clean_price, settlement, convention)

    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Price from yield to maturity."""
        return self._inner.price_from_ytm(ytm, settlement, convention)

    def duration(self, curves=None, *, solver=None, ctx=None, metric: str = "modified", settlement=None) -> float:
        """Duration (macaulay or modified)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.duration(curves, metric, settlement)

    def convexity(self, curves=None, *, solver=None, ctx=None, settlement=None) -> float:
        """Convexity."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.convexity(curves, settlement)

    def duration_from_ytm(self, ytm: float, settlement: datetime.date,
                          metric: str = "modified", convention: str = "periodic") -> float:
        """Analytical duration from yield to maturity."""
        return self._inner.duration_from_ytm(ytm, settlement, metric, convention)

    def convexity_from_ytm(self, ytm: float, settlement: datetime.date,
                           convention: str = "periodic") -> float:
        """Analytical convexity from yield to maturity."""
        return self._inner.convexity_from_ytm(ytm, settlement, convention)

    def dv01(self, curves=None, *, solver=None, ctx=None) -> float:
        """Dollar value of a basis point."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dv01(curves)

    def z_spread(self, curves=None, *, solver=None, ctx=None, price=None, settlement=None, compounding: str = "annual") -> float:
        """Z-spread over the discount curve."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for z_spread")
        return self._inner.z_spread(curves, price, settlement, compounding)

    def asw_spread(self, curves=None, *, solver=None, ctx=None, price=None, method: str = "par_par", settlement=None) -> float:
        """Asset swap spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for asw_spread")
        return self._inner.asw_spread(curves, price, method, settlement)

    def rate(self, curves=None, *, solver=None, ctx=None):
        """Par rate (clean price for solver)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None,
            future_only: bool = True, eval_date=None):
        """Net present value (dirty price).

        Args:
            future_only: If True (default), exclude cashflows with payment before eval_date.
                Matches QuantLib includeSettlementDateFlows=false convention.
            eval_date: Reference date for future_only filtering. Defaults to effective date.
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves, future_only, eval_date)

    def cashflows(self, curves=None, *, solver=None, ctx=None,
                  future_only: bool = False, eval_date=None):
        """Cashflows as Polars DataFrame.

        Args:
            future_only: If True, exclude cashflows with payment <= eval_date.
            eval_date: Cutoff date for future_only (defaults to eval_date set at construction).
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves, future_only, eval_date)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        """Spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.spread(curves)

    def analytic_delta(self, curves=None, *, solver=None, ctx=None):
        """Analytic delta."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.analytic_delta(curves)

    def i_spread(self, settlement: datetime.date, swap_curve=None) -> float:
        """I-spread: YTM minus interpolated swap zero rate at maturity."""
        return self._inner.i_spread(settlement, swap_curve)

    def notional_schedule(self):
        """List of (date, notional) pairs showing notional growth over time."""
        return self._inner.notional_schedule()

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "PIKBond(...)"


class SubPeriodFRN:
    """Sub-Period Floating Rate Note with compounded fixings.

    Each coupon period contains multiple sub-period fixings that are
    compounded into the coupon rate: coupon = Product(1 + r_i * dcf_i) - 1 + spread.

    Args:
        fixing_frequency: Sub-period fixing frequency. One of ``"d"`` (daily/business-day),
            ``"m"`` (monthly), ``"q"`` (quarterly), ``"s"`` (semi-annual), ``"a"`` (annual).
            Use ``"d"`` for overnight-rate bonds (ESTR, SOFR, SONIA) to compound at true
            business-day frequency, matching QuantLib's OvernightLeg behavior.

    Construct with explicit parameters::

        frn = SubPeriodFRN(
            effective=date(2024, 1, 15),
            termination="2Y",
            spread=0.001,
            frequency="q",
            fixing_frequency="m",
        )

    For overnight-rate compounding::

        frn = SubPeriodFRN(
            effective=date(2024, 1, 15),
            termination="1Y",
            spread=0.0,
            frequency="a",
            fixing_frequency="d",
            calendar="tgt",
        )
    """

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        spread: float = 0.0,
        frequency: str = "q",
        fixing_frequency: str = "m",
        settlement_days: int = 2,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "act360",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "mf",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        fixings: Optional[dict] = None,
        fixing_lag: Optional[int] = None,
    ):
        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")

        term_date = _parse_termination(effective, termination)

        self._inner = PyBondInstrument(
            variant="sub_period_frn",
            effective=effective,
            termination=term_date,
            spread=spread,
            frequency=_parse_frequency(frequency),
            fixing_frequency=_parse_frequency(fixing_frequency),
            settlement_days=settlement_days,
            ex_div_days=ex_div_days,
            calendar=calendar,
            currency=currency,
            convention=convention,
            accrued_convention=accrued_convention,
            face_value=face_value,
            modifier=_parse_modifier(modifier),
            fixing_lag=fixing_lag,
        )
        self._disc_curve_id = disc_curve_id
        self._index = index
        self._inner.set_eval_date(datetime.date.today())

        resolved = fixings
        if resolved is None and index is not None:
            resolved = _resolve_fixings(index)
        if resolved:
            self._inner.set_fixings(resolved)

    def price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Clean price."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.price(curves, settlement)

    def dirty_price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Dirty price (clean + accrued)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dirty_price(curves, settlement)

    def accrued_interest(self, settlement: datetime.date) -> float:
        """Accrued interest at settlement date."""
        return self._inner.accrued_interest(settlement)

    def accrued_days(self, settlement: datetime.date) -> int:
        """Number of accrued days at settlement using the bond's accrued day-count convention."""
        return self._inner.accrued_days(settlement)

    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Yield to maturity from clean price."""
        return self._inner.ytm(clean_price, settlement, convention)

    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Price from yield to maturity."""
        return self._inner.price_from_ytm(ytm, settlement, convention)

    def duration(self, curves=None, *, solver=None, ctx=None, metric: str = "modified", settlement=None) -> float:
        """Duration (macaulay or modified)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.duration(curves, metric, settlement)

    def convexity(self, curves=None, *, solver=None, ctx=None, settlement=None) -> float:
        """Convexity."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.convexity(curves, settlement)

    def duration_from_ytm(self, ytm: float, settlement: datetime.date,
                          metric: str = "modified", convention: str = "periodic") -> float:
        """Analytical duration from yield to maturity."""
        return self._inner.duration_from_ytm(ytm, settlement, metric, convention)

    def convexity_from_ytm(self, ytm: float, settlement: datetime.date,
                           convention: str = "periodic") -> float:
        """Analytical convexity from yield to maturity."""
        return self._inner.convexity_from_ytm(ytm, settlement, convention)

    def dv01(self, curves=None, *, solver=None, ctx=None) -> float:
        """Dollar value of a basis point."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dv01(curves)

    def z_spread(self, curves=None, *, solver=None, ctx=None, price=None, settlement=None, compounding: str = "annual") -> float:
        """Z-spread over the discount curve."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for z_spread")
        return self._inner.z_spread(curves, price, settlement, compounding)

    def asw_spread(self, curves=None, *, solver=None, ctx=None, price=None, method: str = "par_par", settlement=None) -> float:
        """Asset swap spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for asw_spread")
        return self._inner.asw_spread(curves, price, method, settlement)

    def rate(self, curves=None, *, solver=None, ctx=None):
        """Par rate (clean price for solver)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None,
            future_only: bool = True, eval_date=None):
        """Net present value (dirty price).

        Args:
            future_only: If True (default), exclude cashflows with payment before eval_date.
                Matches QuantLib includeSettlementDateFlows=false convention.
            eval_date: Reference date for future_only filtering. Defaults to effective date.
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves, future_only, eval_date)

    def cashflows(self, curves=None, *, solver=None, ctx=None,
                  future_only: bool = False, eval_date=None):
        """Cashflows as Polars DataFrame.

        Args:
            future_only: If True, exclude cashflows with payment <= eval_date.
            eval_date: Cutoff date for future_only (defaults to eval_date set at construction).
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves, future_only, eval_date)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        """Spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.spread(curves)

    def analytic_delta(self, curves=None, *, solver=None, ctx=None):
        """Analytic delta."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.analytic_delta(curves)

    def i_spread(self, settlement: datetime.date, swap_curve=None) -> float:
        """I-spread: YTM minus interpolated swap zero rate at maturity."""
        return self._inner.i_spread(settlement, swap_curve)

    def sub_period_schedule(self):
        """Return detailed sub-period schedule for each coupon period."""
        return self._inner.sub_period_schedule()

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "SubPeriodFRN(...)"


class CappedFloatRateNote:
    """Capped and/or Floored Floating Rate Note.

    Supports standard FRN (single fixing per period) and sub-period FRN
    (multiple fixings compounded). Cap/floor options priced via Black-76
    or Bachelier model.

    Args:
        fixing_frequency: Optional sub-period fixing frequency. One of ``"d"`` (daily/business-day),
            ``"m"`` (monthly), ``"q"`` (quarterly), ``"s"`` (semi-annual), ``"a"`` (annual), or
            ``None`` for standard single-fixing FRN. Use ``"d"`` for overnight-rate compounding.

    Construct with explicit parameters::

        capped = CappedFloatRateNote(
            effective=date(2024, 1, 15),
            termination="5Y",
            spread=0.001,
            frequency="q",
            cap_rate=0.05,
            vol=0.20,
        )

        # With sub-period compounding and collar:
        collared = CappedFloatRateNote(
            effective=date(2024, 1, 15),
            termination="5Y",
            spread=0.001,
            frequency="q",
            fixing_frequency="m",
            cap_rate=0.05,
            floor_rate=0.01,
            vol=0.20,
            vol_model="black76",
        )
    """

    def __init__(
        self,
        *,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        spread: float = 0.0,
        frequency: str = "q",
        fixing_frequency: Optional[str] = None,
        cap_rate: Optional[float] = None,
        floor_rate: Optional[float] = None,
        vol: Optional[float] = None,
        vol_model: str = "black76",
        settlement_days: int = 2,
        ex_div_days: int = 0,
        calendar: Optional[str] = None,
        currency: str = "USD",
        convention: str = "act360",
        accrued_convention: Optional[str] = None,
        face_value: float = 100.0,
        modifier: str = "mf",
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
        fixings: Optional[dict] = None,
        fixing_lag: Optional[int] = None,
    ):
        if effective is None:
            raise ValueError("effective date is required")
        if termination is None:
            raise ValueError("termination date or tenor is required")
        if vol is None:
            raise ValueError("vol is required for CappedFloatRateNote (no silent fallback to intrinsic)")
        if cap_rate is None and floor_rate is None:
            raise ValueError("at least one of cap_rate or floor_rate must be provided")

        term_date = _parse_termination(effective, termination)

        fix_freq = _parse_frequency(fixing_frequency) if fixing_frequency is not None else None

        self._inner = PyBondInstrument(
            variant="capped_floored",
            effective=effective,
            termination=term_date,
            spread=spread,
            frequency=_parse_frequency(frequency),
            fixing_frequency=fix_freq,
            cap_rate=cap_rate,
            floor_rate=floor_rate,
            vol=vol,
            vol_model=vol_model,
            settlement_days=settlement_days,
            ex_div_days=ex_div_days,
            calendar=calendar,
            currency=currency,
            convention=convention,
            accrued_convention=accrued_convention,
            face_value=face_value,
            modifier=_parse_modifier(modifier),
            fixing_lag=fixing_lag,
        )
        self._disc_curve_id = disc_curve_id
        self._index = index
        self._inner.set_eval_date(datetime.date.today())

        resolved = fixings
        if resolved is None and index is not None:
            resolved = _resolve_fixings(index)
        if resolved:
            self._inner.set_fixings(resolved)

    def price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Clean price."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.price(curves, settlement)

    def dirty_price(self, curves=None, *, solver=None, ctx=None, settlement=None):
        """Dirty price (clean + accrued)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dirty_price(curves, settlement)

    def accrued_interest(self, settlement: datetime.date) -> float:
        """Accrued interest at settlement date."""
        return self._inner.accrued_interest(settlement)

    def accrued_days(self, settlement: datetime.date) -> int:
        """Number of accrued days at settlement using the bond's accrued day-count convention."""
        return self._inner.accrued_days(settlement)

    def ytm(self, clean_price: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Yield to maturity from clean price."""
        return self._inner.ytm(clean_price, settlement, convention)

    def price_from_ytm(self, ytm: float, settlement: datetime.date, convention: str = "periodic") -> float:
        """Price from yield to maturity."""
        return self._inner.price_from_ytm(ytm, settlement, convention)

    def duration(self, curves=None, *, solver=None, ctx=None, metric: str = "modified", settlement=None) -> float:
        """Duration (macaulay or modified)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.duration(curves, metric, settlement)

    def convexity(self, curves=None, *, solver=None, ctx=None, settlement=None) -> float:
        """Convexity."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.convexity(curves, settlement)

    def duration_from_ytm(self, ytm: float, settlement: datetime.date,
                          metric: str = "modified", convention: str = "periodic") -> float:
        """Analytical duration from yield to maturity."""
        return self._inner.duration_from_ytm(ytm, settlement, metric, convention)

    def convexity_from_ytm(self, ytm: float, settlement: datetime.date,
                           convention: str = "periodic") -> float:
        """Analytical convexity from yield to maturity."""
        return self._inner.convexity_from_ytm(ytm, settlement, convention)

    def dv01(self, curves=None, *, solver=None, ctx=None) -> float:
        """Dollar value of a basis point."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.dv01(curves)

    def z_spread(self, curves=None, *, solver=None, ctx=None, price=None, settlement=None, compounding: str = "annual") -> float:
        """Z-spread over the discount curve."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for z_spread")
        return self._inner.z_spread(curves, price, settlement, compounding)

    def asw_spread(self, curves=None, *, solver=None, ctx=None, price=None, method: str = "par_par", settlement=None) -> float:
        """Asset swap spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        if price is None:
            raise ValueError("price is required for asw_spread")
        return self._inner.asw_spread(curves, price, method, settlement)

    def rate(self, curves=None, *, solver=None, ctx=None):
        """Par rate (clean price for solver)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None,
            future_only: bool = True, eval_date=None):
        """Net present value (dirty price).

        Args:
            future_only: If True (default), exclude cashflows with payment before eval_date.
                Matches QuantLib includeSettlementDateFlows=false convention.
            eval_date: Reference date for future_only filtering. Defaults to effective date.
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves, future_only, eval_date)

    def cashflows(self, curves=None, *, solver=None, ctx=None,
                  future_only: bool = False, eval_date=None):
        """Cashflows as Polars DataFrame.

        Args:
            future_only: If True, exclude cashflows with payment <= eval_date.
            eval_date: Cutoff date for future_only (defaults to eval_date set at construction).
        """
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves, future_only, eval_date)
        return cashflows_to_polars(rows)

    def spread(self, curves=None, *, solver=None, ctx=None):
        """Spread."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.spread(curves)

    def analytic_delta(self, curves=None, *, solver=None, ctx=None):
        """Analytic delta."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.analytic_delta(curves)

    def i_spread(self, settlement: datetime.date, swap_curve=None) -> float:
        """I-spread: YTM minus interpolated swap zero rate at maturity."""
        return self._inner.i_spread(settlement, swap_curve)

    def sub_period_schedule(self):
        """Return detailed sub-period schedule (None if no sub-periods)."""
        return self._inner.sub_period_schedule()

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            return solver.get_curve_by_id(self._disc_curve_id)
        return solver.get_curve(0)

    def __repr__(self):
        return "CappedFloatRateNote(...)"


class CreditDefaultSwap:
    """Credit Default Swap with hazard rate curve pricing.

    Construct with explicit parameters or a spec template::

        cds = CreditDefaultSwap(
            spec="us_ig_cds",
            effective=date(2024, 1, 1),
            termination="5Y",
            notional=10_000_000.0,
        )
    """

    def __init__(
        self,
        *,
        spec: Optional[str] = None,
        effective: Optional[datetime.date] = None,
        termination: Any = None,
        frequency: str = "q",
        notional: float = 10_000_000.0,
        recovery_rate: float = 0.4,
        fixed_rate: float = 100.0,
        convention: str = "act360",
        currency: str = "USD",
        premium_accrued: bool = True,
        modifier: str = "mf",
        stub: str = "shortfront",
        trade_date: Optional[datetime.date] = None,
        tenor: Optional[str] = None,
        **extra_kwargs: Any,
    ):
        params = _merge_spec_params(spec, {
            "frequency": frequency,
            "notional": notional,
            "recovery_rate": recovery_rate,
            "fixed_rate": fixed_rate,
            "convention": convention,
            "currency": currency,
            "premium_accrued": premium_accrued,
            "modifier": modifier,
            "stub": stub,
        })
        params.update(extra_kwargs)

        if trade_date is not None:
            # CDS trade_date + tenor construction path
            if tenor is None:
                raise ValueError("When trade_date is provided, tenor must also be provided")
            if effective is not None or termination is not None:
                raise ValueError("Cannot specify both trade_date and effective/termination")
            self._inner = _PyCDS(
                trade_date=trade_date,
                tenor=tenor,
                notional=params.get("notional", 10_000_000.0),
                recovery_rate=params.get("recovery_rate", 0.4),
                fixed_rate=params.get("fixed_rate", 100.0),
                convention=params.get("convention", "act360"),
                currency=params.get("currency", "USD"),
                premium_accrued=params.get("premium_accrued", True),
            )
        else:
            # Existing effective + termination construction path
            if effective is None:
                raise ValueError("effective date is required")
            if termination is None:
                raise ValueError("termination date or tenor is required")

            term_date = _parse_termination(effective, termination)

            self._inner = _PyCDS(
                effective=effective,
                termination=term_date,
                frequency=_parse_frequency(params.get("frequency", "q")),
                notional=params.get("notional", 10_000_000.0),
                recovery_rate=params.get("recovery_rate", 0.4),
                fixed_rate=params.get("fixed_rate", 100.0),
                convention=params.get("convention", "act360"),
                currency=params.get("currency", "USD"),
                premium_accrued=params.get("premium_accrued", True),
                modifier=_parse_modifier(params.get("modifier", "mf")),
                stub=params.get("stub", "shortfront"),
            )

    def rate(self, disc_curve, credit_curve):
        """Compute par spread in basis points."""
        return self._inner.rate(disc_curve, credit_curve)

    def npv(self, disc_curve, credit_curve):
        """Compute NPV from protection buyer's perspective."""
        return self._inner.npv(disc_curve, credit_curve)

    def spread(self, disc_curve, credit_curve):
        """Compute spread (par spread - fixed rate) in basis points."""
        return self._inner.spread(disc_curve, credit_curve)

    def cashflows(self, disc_curve, credit_curve):
        """Return cashflows as a Polars DataFrame."""
        rows = self._inner.cashflows(disc_curve, credit_curve)
        return cashflows_to_polars(rows)

    def accrued(self, today=None):
        """Compute accrued premium."""
        if today is None:
            today = datetime.date.today()
        return self._inner.accrued(today)

    def analytic_rec_risk(self, disc_curve, credit_curve):
        """Recovery rate sensitivity of NPV."""
        return self._inner.analytic_rec_risk(disc_curve, credit_curve)

    def jtd(self, today=None):
        """Jump-to-default: (1-R)*N - accrued."""
        if today is None:
            today = datetime.date.today()
        return self._inner.jtd(today)

    def ead(self):
        """Exposure at default: (1-R)*N."""
        return self._inner.ead()

    def upfront(self, disc_curve, credit_curve):
        """Big Bang upfront payment as percentage of notional."""
        return self._inner.upfront(disc_curve, credit_curve)

    def to_upfront_spread(self, disc_curve, credit_curve):
        """Convert par spread to upfront + coupon format."""
        return self._inner.to_upfront_spread(disc_curve, credit_curve)

    def __repr__(self):
        return "CreditDefaultSwap(...)"


# Alias
CDS = CreditDefaultSwap

class AssetSwap:
    """Asset swap instrument for computing par and non-par (market value) spreads.

    The asset swap spread is the spread over a floating rate that makes the
    swap NPV zero, given the bond's cashflows and a discount curve.

    Par asset swap::

        asw = AssetSwap(
            bond=FixedRateBond(effective=date(2024, 1, 15), termination="5Y", coupon=0.04),
            asw_type="par",
        )
        spread = asw.rate(curves=curve)

    Non-par (market value) asset swap::

        asw = AssetSwap(
            bond=FixedRateBond(effective=date(2024, 1, 15), termination="5Y", coupon=0.04),
            asw_type="non_par",
            dirty_price=102.5,
        )
        spread = asw.rate(curves=curve)
    """

    def __init__(
        self,
        bond,
        *,
        asw_type: str = "par",
        dirty_price: Optional[float] = None,
        spread: Optional[float] = None,
        disc_curve_id: Optional[str] = None,
        index: Optional[str] = None,
    ):
        if not hasattr(bond, '_inner'):
            raise ValueError("bond must be a vade bond instrument (FixedRateBond, FloatRateNote, etc.)")

        self._bond = bond
        self._inner = PyAssetSwap(
            bond=bond._inner,
            asw_type=asw_type,
            dirty_price=dirty_price,
            spread=spread,
        )
        self._disc_curve_id = disc_curve_id or getattr(bond, '_disc_curve_id', None)
        self._index = index

    def rate(self, curves=None, *, solver=None, ctx=None):
        """Fair asset swap spread (the spread over floating that makes NPV = 0)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None):
        """NPV of the asset swap (zero at fair spread, non-zero with fixed spread)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves)

    def cashflows(self, curves=None, *, solver=None, ctx=None):
        """Bond leg cashflows."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves)
        return cashflows_to_polars(rows)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            disc = solver.get_curve_by_id(self._disc_curve_id)
            return disc
        return solver.get_curve(0)

    def __repr__(self):
        return "AssetSwap(...)"


class CallableBond:
    """Callable/puttable bond priced via Hull-White trinomial tree.

    Wraps any vade bond instrument with a call schedule (and optional put schedule)
    to compute tree-based prices, OAS, and option-adjusted risk measures.

    Example::

        bond = FixedRateBond(effective=date(2024, 1, 1), termination="5Y", coupon=0.04)
        cb = CallableBond(
            bond=bond,
            call_schedule=[(date(2026, 1, 1), 100.0), (date(2027, 1, 1), 100.0)],
        )
        price = cb.tree_price(curves=curve, a=0.1, sigma=0.01)
        spread = cb.oas(curves=curve, market_price=99.5, a=0.1, sigma=0.01)
    """

    def __init__(
        self,
        bond,
        *,
        call_schedule: list[tuple],
        put_schedule: list[tuple] | None = None,
        disc_curve_id: str | None = None,
        index: str | None = None,
    ):
        if not hasattr(bond, '_inner'):
            raise ValueError("bond must be a vade bond instrument (FixedRateBond, FloatRateNote, etc.)")
        self._bond = bond
        call_sched = [(d, p) for d, p in call_schedule]
        put_sched = [(d, p) for d, p in put_schedule] if put_schedule else None
        self._inner = PyCallableBond(
            bond=bond._inner,
            call_schedule=call_sched,
            put_schedule=put_sched,
        )
        self._disc_curve_id = disc_curve_id or getattr(bond, '_disc_curve_id', None)
        self._index = index

    def tree_price(self, curves=None, *, a: float, sigma: float, spread: float = 0.0, solver=None, ctx=None) -> float:
        """Price using Hull-White trinomial tree."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.tree_price(curves, a, sigma, spread)

    def oas(self, curves=None, *, market_price: float, a: float, sigma: float, solver=None, ctx=None) -> float:
        """Compute option-adjusted spread via Brent root-finding."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.oas(curves, market_price, a, sigma)

    def effective_duration(self, curves=None, *, a: float, sigma: float, oas: float = 0.0, bump: float = 0.0001, solver=None, ctx=None) -> float:
        """Effective duration via bump-and-reprice on OAS."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.effective_duration(curves, a, sigma, oas, bump)

    def effective_convexity(self, curves=None, *, a: float, sigma: float, oas: float = 0.0, bump: float = 0.0001, solver=None, ctx=None) -> float:
        """Effective convexity via bump-and-reprice on OAS."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.effective_convexity(curves, a, sigma, oas, bump)

    def vega(self, curves=None, *, a: float, sigma: float, oas: float = 0.0, bump: float = 0.0001, solver=None, ctx=None) -> float:
        """Sensitivity to Hull-White sigma via bump-and-reprice."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.vega(curves, a, sigma, oas, bump)

    def accrued_interest(self, settlement: datetime.date) -> float:
        """Accrued interest of the underlying bond at settlement date."""
        return self._bond.accrued_interest(settlement)

    def accrued_days(self, settlement: datetime.date) -> int:
        """Number of accrued days of the underlying bond at settlement."""
        return self._bond.accrued_days(settlement)

    def rate(self, curves=None, *, solver=None, ctx=None):
        """Par rate of underlying bond (delegates to bond)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.rate(curves)

    def npv(self, curves=None, *, solver=None, ctx=None):
        """NPV of underlying bond (delegates to bond)."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        return self._inner.npv(curves)

    def cashflows(self, curves=None, *, solver=None, ctx=None):
        """Cashflows of underlying bond."""
        if solver is not None:
            curves = self._resolve_curves_from_solver(solver)
        elif ctx is not None and curves is None:
            curves = _resolve_curves_from_context(ctx, self._disc_curve_id)
        rows = self._inner.cashflows(curves)
        return cashflows_to_polars(rows)

    def _resolve_curves_from_solver(self, solver):
        if self._disc_curve_id:
            disc = solver.get_curve_by_id(self._disc_curve_id)
            return disc
        return solver.get_curve(0)

    def __repr__(self):
        return "CallableBond(...)"



__all__ = [
    "FixedRateBond",
    "Bill",
    "FloatRateNote",
    "ZeroCouponBond",
    "StepUpBond",
    "AmortizingBond",
    "PIKBond",
    "SubPeriodFRN",
    "CappedFloatRateNote",
    "CreditDefaultSwap", "CDS",
    "AssetSwap",
    "CallableBond",
]
