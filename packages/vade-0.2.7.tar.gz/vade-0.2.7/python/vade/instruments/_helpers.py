"""Shared helper functions for instrument construction."""
from __future__ import annotations

import datetime
from typing import Any, Optional

from vade.instruments.specs import get_spec
from vade.cashflows.dataframe import cashflows_to_polars


def _parse_frequency(s: str) -> str:
    """Normalize frequency string."""
    mapping = {
        "d": "d", "daily": "d",
        "a": "a", "annual": "a", "1y": "a", "12m": "a",
        "s": "s", "semiannual": "s", "semi_annual": "s", "6m": "s",
        "q": "q", "quarterly": "q", "3m": "q",
        "m": "m", "monthly": "m", "1m": "m",
        "z": "z", "zero": "z", "zerocoupon": "z", "zero_coupon": "z",
    }
    return mapping.get(s.lower(), s)


def _parse_modifier(s: str) -> str:
    """Normalize modifier string."""
    mapping = {
        "mf": "mf", "modified_following": "mf", "mod_following": "mf",
        "f": "following", "following": "following",
        "p": "preceding", "preceding": "preceding",
        "mp": "modified_preceding", "modified_preceding": "modified_preceding",
        "none": "actual", "actual": "actual",
    }
    return mapping.get(s.lower(), s)


def _parse_termination(effective: datetime.date, termination: Any) -> datetime.date:
    """Parse termination as date or tenor string."""
    if isinstance(termination, datetime.date):
        return termination
    if isinstance(termination, str):
        # Parse tenor string like "5Y", "6M", "1Y"
        s = termination.upper().strip()
        if s.endswith("Y"):
            years = int(s[:-1])
            year = effective.year + years
            try:
                return effective.replace(year=year)
            except ValueError:
                # Feb 29 -> Feb 28
                return effective.replace(year=year, day=28)
        elif s.endswith("M"):
            months = int(s[:-1])
            month = effective.month + months
            year = effective.year + (month - 1) // 12
            month = (month - 1) % 12 + 1
            try:
                return effective.replace(year=year, month=month)
            except ValueError:
                import calendar as cal_mod
                last_day = cal_mod.monthrange(year, month)[1]
                return effective.replace(year=year, month=month, day=min(effective.day, last_day))
        elif s.endswith("W"):
            weeks = int(s[:-1])
            return effective + datetime.timedelta(weeks=weeks)
        elif s.endswith("D"):
            days = int(s[:-1])
            return effective + datetime.timedelta(days=days)
    raise ValueError(f"Cannot parse termination: {termination}")


def _merge_spec_params(spec_name: Optional[str], kwargs: dict) -> dict:
    """Merge spec defaults with user-provided kwargs."""
    if spec_name is None:
        return dict(kwargs)
    defaults = get_spec(spec_name)
    merged = {**defaults, **kwargs}
    return merged


def _resolve_curves_from_context(ctx, disc_id, forecast_id=None):
    """Extract curve(s) from MarketContext by ID.

    Returns single curve or [forecast, disc] list matching
    existing _resolve_curves_from_solver() return convention.
    """
    disc = ctx.curve(disc_id)
    if forecast_id and forecast_id != disc_id:
        forecast = ctx.curve(forecast_id)
        return [forecast, disc]
    return disc


def _resolve_fixings(index_name, explicit_fixings=None, ctx=None):
    """3-tier fixing resolution: explicit > ctx > module-level.

    Returns dict[date, float] or None.
    """
    if explicit_fixings is not None:
        return explicit_fixings
    if ctx is not None and index_name:
        ctx_fixings = ctx.fixings.get(index_name)
        if ctx_fixings is not None:
            return ctx_fixings
    if index_name:
        import vade.fixings as _mod_fixings
        return _mod_fixings.get(index_name)
    return None


def _resolve_xccy_from_context(ctx, leg1_disc_id, leg1_fcast_id, leg2_disc_id, leg2_fcast_id):
    """Extract 4 curves + fx_rates from MarketContext for cross-currency instruments."""
    l1d = ctx.curve(leg1_disc_id)
    l1f = ctx.curve(leg1_fcast_id)
    l2d = ctx.curve(leg2_disc_id)
    l2f = ctx.curve(leg2_fcast_id)
    fx = ctx.fx_rates
    if fx is None:
        raise ValueError("ctx.fx_rates is required for cross-currency pricing")
    return l1d, l1f, l2d, l2f, fx


__all__ = [
    "_parse_frequency",
    "_parse_modifier",
    "_parse_termination",
    "_merge_spec_params",
    "_resolve_curves_from_context",
    "_resolve_fixings",
    "_resolve_xccy_from_context",
]
