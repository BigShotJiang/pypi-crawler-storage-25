"""Vade: Production-grade interest rate curve toolkit."""

from importlib.metadata import version as _pkg_version
__version__ = _pkg_version("vade")

# Register Rust submodules in sys.modules so they can be imported directly.
# This is required for PyO3 submodules registered via add_submodule().
import sys as _sys
import vade._vade_rs as _rs

_sys.modules["vade._vade_rs.autodiff"] = _rs.autodiff
_sys.modules["vade._vade_rs.calendar"] = _rs.calendar
_sys.modules["vade._vade_rs.curves"] = _rs.curves
_sys.modules["vade._vade_rs.cashflows"] = _rs.cashflows
_sys.modules["vade._vade_rs.instruments"] = _rs.instruments
_sys.modules["vade._vade_rs.solver"] = _rs.solver
_sys.modules["vade._vade_rs.fx"] = _rs.fx
_sys.modules["vade._vade_rs.numerical"] = _rs.numerical

# --- Market Curves (curves + FX) ---
from vade.marketcurves import (  # noqa: E402
    DiscountCurve, LineCurve, CompositeCurve, FXImpliedCurve, CreditImpliedCurve,
    NelsonSiegel, NelsonSiegelSvensson, SmithWilson,
    IRImpliedCurve, ForwardCurve, SpreadCurve, TurnOfYearCurve,
    FittedBondCurve,
    FXRates, FXForwards, FXPair,
)

# --- Cashflows ---
from vade.cashflows import FixedLeg, FloatLeg  # noqa: E402

# --- Instruments ---
from vade.instruments import (  # noqa: E402
    InterestRateSwap, IRS,
    ForwardRateAgreement, FRA,
    ZeroCouponSwap, ZCS,
    SingleBasisSwap, SBS,
    OvernightIndexedSwap, OIS,
    Deposit,
    IRFuture,
    CapFloor,
    FixedRateBond,
    Bill,
    FloatRateNote,
    ZeroCouponBond,
    StepUpBond,
    AmortizingBond,
    PIKBond,
    SubPeriodFRN,
    CappedFloatRateNote,
    CDS, XCS, FXForward, NDF, NDIRS, NDXCS,
    CreditDefaultSwap, CrossCurrencySwap,
    AssetSwap,
    CallableBond,
)

# --- Solver ---
from vade.solver import Solver, SolverResult, bootstrap  # noqa: E402

# --- Autodiff ---
from vade.autodiff import Dual, Dual2  # noqa: E402

# --- Calendar ---
from vade.calendar import Schedule, BusinessCalendar, dcf, add_tenor, add_business_days, parse_date, previous_imm_cds_date, next_imm_cds_date  # noqa: E402

# --- Numerical ---
from vade.numerical import brent_solve, newton_raphson_solve, discount_factor, rate_from_df, convert_rate  # noqa: E402

# --- Fixings ---
from vade import fixings  # noqa: E402

# --- Context ---
from vade.context import MarketContext, FixingStore, eval_date  # noqa: E402

__all__ = [
    # Curves
    "DiscountCurve", "LineCurve", "CompositeCurve", "FXImpliedCurve",
    "CreditImpliedCurve", "NelsonSiegel", "NelsonSiegelSvensson", "SmithWilson",
    "IRImpliedCurve", "ForwardCurve", "SpreadCurve", "TurnOfYearCurve",
    "FittedBondCurve",
    # FX
    "FXRates", "FXForwards", "FXPair",
    # Cashflows
    "FixedLeg", "FloatLeg",
    # Instruments (short aliases)
    "IRS", "FRA", "ZCS", "SBS", "OIS",
    "Deposit", "IRFuture", "CapFloor",
    "FixedRateBond", "Bill", "FloatRateNote",
    "ZeroCouponBond", "StepUpBond",
    "AmortizingBond", "PIKBond",
    "SubPeriodFRN", "CappedFloatRateNote",
    "AssetSwap",
    "CallableBond",
    "CDS", "XCS", "FXForward", "NDF", "NDIRS", "NDXCS",
    # Instruments (long-form aliases)
    "InterestRateSwap", "ForwardRateAgreement", "ZeroCouponSwap",
    "SingleBasisSwap", "OvernightIndexedSwap",
    "CreditDefaultSwap", "CrossCurrencySwap",
    # Solver
    "Solver", "SolverResult", "bootstrap",
    # Autodiff
    "Dual", "Dual2",
    # Calendar
    "Schedule", "BusinessCalendar", "dcf", "add_tenor", "add_business_days", "parse_date",
    "previous_imm_cds_date", "next_imm_cds_date",
    # Numerical
    "brent_solve", "newton_raphson_solve", "discount_factor", "rate_from_df", "convert_rate",
    # Context
    "MarketContext", "FixingStore", "eval_date",
    # Submodules
    "fixings",
]
