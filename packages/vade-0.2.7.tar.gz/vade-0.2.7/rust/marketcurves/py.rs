use std::collections::HashMap;

use chrono::{Duration, NaiveDate};
use indexmap::IndexMap;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use crate::autodiff::dual::{Dual, Dual2};
use crate::autodiff::enums::Number;
use crate::calendar::adjuster::Adjuster;
use crate::calendar::cal::BusinessCalendar;
use crate::calendar::convention::DayCountConvention;
use crate::calendar::py::PyBusinessCalendar;
use crate::calendar::tenor::Tenor;
use crate::marketcurves::curve::{CurveQuery, DiscountCurve, LineCurve};
use crate::marketcurves::credit::CreditImpliedCurve;
use crate::marketcurves::composite::{CompositeCurve, CompositeCurveType};
use crate::marketcurves::forward_curve::ForwardCurve;
use crate::marketcurves::spread_curve::{CurveContainer, SpreadCurve, SpreadMode};
use crate::marketcurves::turn_of_year::TurnOfYearCurve;
use crate::marketcurves::fx_implied::FXImpliedCurve;
use crate::marketcurves::implied::IRImpliedCurve;
use crate::marketcurves::fitted::{FittedBondCurve, FittedCurveInner, FittingModel};
use crate::marketcurves::nelson_siegel::{NelsonSiegel, NelsonSiegelSvensson};
use crate::marketcurves::smith_wilson::SmithWilson;
use crate::instruments::py::PyBondInstrument;
use crate::marketcurves::interpolation::Interpolator;
use crate::marketcurves::interpolation::natural_cubic::NaturalCubicInterpolator;
use crate::marketcurves::interpolation::log_cubic::LogCubicInterpolator;
use crate::marketcurves::interpolation::hermite::HermiteInterpolator;
use crate::marketcurves::interpolation::monotone_cubic::MonotoneCubicInterpolator;
use crate::marketcurves::interpolation::convex_monotone::ConvexMonotoneInterpolator;
use crate::marketcurves::nodes::Nodes;
use crate::marketcurves::spline::SplineEndpoint;
use crate::marketcurves::transforms::*;
use crate::numerical::compounding as comp;
use crate::calendar::convention::DcfOptions;
use crate::marketcurves::fx::py::PyFXRates;

// ---- String-to-enum parsing helpers ----

fn parse_interpolation(s: &str) -> PyResult<String> {
    let normalized = s.to_lowercase().replace([' ', '-'], "_");
    match normalized.as_str() {
        "log_linear" | "loglinear" => Ok("log_linear".to_string()),
        "linear" => Ok("linear".to_string()),
        "linear_zero_rate" | "linearzerorate" => Ok("linear_zero_rate".to_string()),
        "flat_forward" | "flatforward" => Ok("flat_forward".to_string()),
        "flat_backward" | "flatbackward" => Ok("flat_backward".to_string()),
        "spline" => Ok("spline".to_string()),
        "natural_cubic" | "naturalcubic" => Ok("natural_cubic".to_string()),
        "log_cubic" | "logcubic" => Ok("log_cubic".to_string()),
        "hermite" => Ok("hermite".to_string()),
        "monotone_cubic" | "monotonecubic" => Ok("monotone_cubic".to_string()),
        "convex_monotone" | "convexmonotone" | "hagan_west" | "haganwest" => Ok("convex_monotone".to_string()),
        _ => Err(PyValueError::new_err(format!(
            "Unknown interpolation: '{}'. Use: 'log_linear', 'linear', 'linear_zero_rate', \
             'flat_forward', 'flat_backward', 'spline', 'natural_cubic', 'log_cubic', \
             'hermite', 'monotone_cubic', 'convex_monotone'",
            s
        ))),
    }
}

fn parse_day_count(s: &str) -> PyResult<DayCountConvention> {
    match s.to_lowercase().replace([' ', '_', '-'], "").as_str() {
        "act360" | "actual360" => Ok(DayCountConvention::Act360),
        "act365f" | "act365fixed" | "actual365fixed" => Ok(DayCountConvention::Act365F),
        "act365.25" | "act36525" => Ok(DayCountConvention::Act365_25),
        "act364" | "actual364" => Ok(DayCountConvention::Act364),
        "actactisda" | "actualactual" | "actact" => Ok(DayCountConvention::ActActISDA),
        "30/360" | "30360" | "thirty360" => Ok(DayCountConvention::Thirty360),
        "30e/360" | "30e360" | "thirtye360" => Ok(DayCountConvention::ThirtyE360),
        "30e/360isda" | "30e360isda" => Ok(DayCountConvention::ThirtyE360ISDA),
        "bus252" | "bus/252" => Ok(DayCountConvention::Bus252),
        "one" | "1" | "1/1" => Ok(DayCountConvention::One),
        _ => Err(PyValueError::new_err(format!(
            "Unknown day count convention: '{}'. Use: 'act360', 'act365f', 'actactisda', '30/360', etc.",
            s
        ))),
    }
}

fn parse_adjuster(s: &str) -> PyResult<Adjuster> {
    match s.to_lowercase().as_str() {
        "actual" | "none" => Ok(Adjuster::Actual),
        "following" | "fol" => Ok(Adjuster::Following),
        "modified_following" | "modfollowing" | "mod_following" | "mf" => {
            Ok(Adjuster::ModifiedFollowing)
        }
        "preceding" | "pre" => Ok(Adjuster::Preceding),
        "modified_preceding" | "modpreceding" | "mod_preceding" | "mp" => {
            Ok(Adjuster::ModifiedPreceding)
        }
        _ => Err(PyValueError::new_err(format!(
            "Unknown adjuster: '{}'. Use: 'actual', 'following', 'modified_following', 'preceding', 'modified_preceding'",
            s
        ))),
    }
}

fn parse_endpoint(s: &str) -> PyResult<SplineEndpoint> {
    SplineEndpoint::from_str(s).map_err(|e| PyValueError::new_err(e))
}

// ---- Helper: Number -> Py<PyAny> ----

fn number_to_py(py: Python<'_>, n: Number) -> PyResult<Py<PyAny>> {
    match n {
        Number::F64(f) => Ok(f.into_pyobject(py).expect("f64 to py").into_any().unbind()),
        Number::Dual(d) => Ok(Py::new(py, d)?.into_any()),
        Number::Dual2(d) => Ok(Py::new(py, d)?.into_any()),
    }
}

// ---- Helper: parse a single Number from Python (float, Dual, or Dual2) ----

fn parse_number(obj: &Bound<'_, PyAny>) -> PyResult<Number> {
    if let Ok(d) = obj.extract::<Dual>() {
        return Ok(Number::Dual(d));
    }
    if let Ok(d2) = obj.extract::<Dual2>() {
        return Ok(Number::Dual2(d2));
    }
    if let Ok(f) = obj.extract::<f64>() {
        return Ok(Number::F64(f));
    }
    Err(PyValueError::new_err(
        "Parameter must be float, Dual, or Dual2",
    ))
}

// ---- Helper: parse nodes from Python ----

fn parse_nodes(nodes: &Bound<'_, PyAny>) -> PyResult<Nodes> {
    if let Ok(dict) = nodes.cast::<pyo3::types::PyDict>() {
        return parse_nodes_from_dict(dict);
    }

    if let Ok(tuple) = nodes.cast::<pyo3::types::PyTuple>() {
        if tuple.len() == 2 {
            let dates_obj = tuple.get_item(0)?;
            let values_obj = tuple.get_item(1)?;
            return parse_nodes_from_lists(&dates_obj, &values_obj);
        }
    }

    if let Ok(list) = nodes.cast::<pyo3::types::PyList>() {
        if list.len() == 2 {
            let dates_obj = list.get_item(0)?;
            let values_obj = list.get_item(1)?;
            return parse_nodes_from_lists(&dates_obj, &values_obj);
        }
    }

    Err(PyValueError::new_err(
        "nodes must be a dict {date: value, ...} or a tuple/list of (dates, values)",
    ))
}

fn parse_nodes_from_dict(dict: &Bound<'_, pyo3::types::PyDict>) -> PyResult<Nodes> {
    if dict.is_empty() {
        return Err(PyValueError::new_err("nodes dict must not be empty"));
    }

    let first_value = dict.values().get_item(0)?;

    if first_value.is_instance_of::<Dual>() {
        let mut map = IndexMap::new();
        for (k, v) in dict.iter() {
            let date: NaiveDate = k.extract()?;
            let dual: Dual = v.extract()?;
            map.insert(date, dual);
        }
        Ok(Nodes::from_dual_map(map))
    } else if first_value.is_instance_of::<Dual2>() {
        let mut map = IndexMap::new();
        for (k, v) in dict.iter() {
            let date: NaiveDate = k.extract()?;
            let dual2: Dual2 = v.extract()?;
            map.insert(date, dual2);
        }
        Ok(Nodes::from_dual2_map(map))
    } else {
        let mut map = IndexMap::new();
        for (k, v) in dict.iter() {
            let date: NaiveDate = k.extract()?;
            let val: f64 = v.extract().map_err(|_| {
                PyValueError::new_err("Node value must be float, Dual, or Dual2")
            })?;
            map.insert(date, val);
        }
        Ok(Nodes::from_f64_map(map))
    }
}

fn parse_nodes_from_lists(dates_obj: &Bound<'_, PyAny>, values_obj: &Bound<'_, PyAny>) -> PyResult<Nodes> {
    let dates: Vec<NaiveDate> = dates_obj.extract()?;
    if dates.is_empty() {
        return Err(PyValueError::new_err("dates list must not be empty"));
    }

    let first_val = values_obj.get_item(0)?;

    if first_val.is_instance_of::<Dual>() {
        let values: Vec<Dual> = values_obj.extract()?;
        if dates.len() != values.len() {
            return Err(PyValueError::new_err("dates and values must have the same length"));
        }
        let map: IndexMap<NaiveDate, Dual> = dates.into_iter().zip(values).collect();
        Ok(Nodes::from_dual_map(map))
    } else if first_val.is_instance_of::<Dual2>() {
        let values: Vec<Dual2> = values_obj.extract()?;
        if dates.len() != values.len() {
            return Err(PyValueError::new_err("dates and values must have the same length"));
        }
        let map: IndexMap<NaiveDate, Dual2> = dates.into_iter().zip(values).collect();
        Ok(Nodes::from_dual2_map(map))
    } else {
        let values: Vec<f64> = values_obj.extract()?;
        if dates.len() != values.len() {
            return Err(PyValueError::new_err("dates and values must have the same length"));
        }
        let map: IndexMap<NaiveDate, f64> = dates.into_iter().zip(values).collect();
        Ok(Nodes::from_f64_map(map))
    }
}

// ---- Helper: parse date or tenor string ----

fn parse_date_or_tenor(
    arg: &Bound<'_, PyAny>,
    base_date: NaiveDate,
    calendar: &Option<BusinessCalendar>,
    modifier: &Adjuster,
) -> PyResult<NaiveDate> {
    if let Ok(date) = arg.extract::<NaiveDate>() {
        return Ok(date);
    }
    if let Ok(s) = arg.extract::<String>() {
        let tenor = Tenor::parse(&s).map_err(|e| PyValueError::new_err(e))?;
        let raw = tenor.add_to(base_date, calendar.as_ref())
            .map_err(|e| PyValueError::new_err(e))?;
        if let Some(cal) = calendar {
            Ok(modifier.adjust(raw, cal))
        } else {
            Ok(raw)
        }
    } else {
        Err(PyValueError::new_err(
            "Expected a date or a tenor string (e.g. '1Y', '6M')",
        ))
    }
}

// ---- Helper: build interpolator ----

fn build_interpolator(
    interp_str: &str,
    nodes: &Nodes,
    t: Option<Vec<NaiveDate>>,
    endpoints: &SplineEndpoint,
    log_transform: bool,
) -> PyResult<Interpolator> {
    match interp_str {
        "spline" => {
            let local_method = if log_transform {
                Interpolator::LogLinear
            } else {
                Interpolator::FlatForward
            };
            let t_ref = t.as_deref();
            Ok(Interpolator::build_spline(
                nodes,
                t_ref,
                endpoints,
                local_method,
                log_transform,
            ))
        }
        "natural_cubic" => Ok(Interpolator::NaturalCubic(NaturalCubicInterpolator::build(nodes))),
        "log_cubic" => Ok(Interpolator::LogCubic(LogCubicInterpolator::build(nodes))),
        "hermite" => Ok(Interpolator::Hermite(HermiteInterpolator::build(nodes))),
        "monotone_cubic" => Ok(Interpolator::MonotoneCubic(MonotoneCubicInterpolator::build(nodes))),
        "convex_monotone" => Ok(Interpolator::ConvexMonotone(ConvexMonotoneInterpolator)),
        _ => Interpolator::from_str(interp_str).map_err(|e| PyValueError::new_err(e)),
    }
}

// ---- Helper: convert zero rate nodes to discount factor nodes ----

fn convert_zero_rates_to_dfs(
    nodes: Nodes,
    conv: &DayCountConvention,
    compounding: &str,
) -> PyResult<Nodes> {
    // Validate compounding string upfront.
    comp::discount_factor(0.0, 1.0, compounding).map_err(|e| PyValueError::new_err(e))?;

    let dcf_opts = DcfOptions::default();

    match nodes {
        Nodes::F64(map) => {
            if map.is_empty() {
                return Err(PyValueError::new_err("nodes must not be empty"));
            }
            let base_date = *map.keys().next().unwrap();
            let mut df_map = IndexMap::new();
            for (date, rate) in &map {
                if *date == base_date {
                    // First node: DF = 1.0 regardless of rate value.
                    df_map.insert(*date, 1.0);
                } else {
                    let yf = conv.dcf(base_date, *date, &dcf_opts).map_err(|e| {
                        PyValueError::new_err(format!(
                            "Failed to compute year fraction for {}: {}", date, e
                        ))
                    })?;
                    let df = comp::discount_factor(*rate, yf, compounding).map_err(|e| {
                        PyValueError::new_err(e)
                    })?;
                    df_map.insert(*date, df);
                }
            }
            Ok(Nodes::F64(df_map))
        }
        Nodes::Dual(_) | Nodes::Dual2(_) => {
            Err(PyValueError::new_err(
                "node_type='zero' is only supported for float nodes, not Dual/Dual2"
            ))
        }
    }
}

// ---- PyDiscountCurve ----

#[pyclass(name = "DiscountCurve", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyDiscountCurve {
    pub inner: DiscountCurve,
}

#[pymethods]
impl PyDiscountCurve {
    #[new]
    #[pyo3(signature = (nodes, /, interpolation="log_linear", id="curve", convention="act360", modifier="modified_following", calendar=None, t=None, endpoints="not_a_knot", node_type="df", compounding="continuous"))]
    fn new(
        nodes: &Bound<'_, PyAny>,
        interpolation: &str,
        id: &str,
        convention: &str,
        modifier: &str,
        calendar: Option<&PyBusinessCalendar>,
        t: Option<Vec<NaiveDate>>,
        endpoints: &str,
        node_type: &str,
        compounding: &str,
    ) -> PyResult<Self> {
        let mut parsed_nodes = parse_nodes(nodes)?;
        let interp_str = parse_interpolation(interpolation)?;
        let conv = parse_day_count(convention)?;
        let adj = parse_adjuster(modifier)?;
        let ep = parse_endpoint(endpoints)?;

        // Convert zero rate nodes to discount factors if requested.
        let nt = node_type.to_lowercase();
        match nt.as_str() {
            "df" | "discount_factor" | "discount_factors" => {
                // Default path: nodes are already discount factors.
                parsed_nodes.ensure_first_df_one();
            }
            "zero" | "zero_rate" | "zero_rates" => {
                parsed_nodes.sort_keys();
                parsed_nodes = convert_zero_rates_to_dfs(parsed_nodes, &conv, compounding)?;
            }
            _ => {
                return Err(PyValueError::new_err(format!(
                    "Unknown node_type: '{}'. Use: 'df' or 'zero'.",
                    node_type
                )));
            }
        }

        parsed_nodes.sort_keys();

        let interpolator = build_interpolator(&interp_str, &parsed_nodes, t, &ep, true)?;

        let curve = DiscountCurve {
            nodes: parsed_nodes,
            interpolator,
            convention: conv,
            modifier: adj,
            calendar: calendar.map(|c| c.inner.clone()),
            id: id.to_string(),
        };

        Ok(PyDiscountCurve { inner: curve })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(
        &self,
        py: Python<'_>,
        start: &Bound<'_, PyAny>,
        end: &Bound<'_, PyAny>,
    ) -> PyResult<Py<PyAny>> {
        let first_date = self.inner.nodes.first_key();
        let start_date = parse_date_or_tenor(start, first_date, &self.inner.calendar, &self.inner.modifier)?;
        let end_date = parse_date_or_tenor(end, start_date, &self.inner.calendar, &self.inner.modifier)?;
        let result = self.inner.zero_rate(start_date, end_date);
        number_to_py(py, result)
    }

    fn forward_rate(
        &self,
        py: Python<'_>,
        start: &Bound<'_, PyAny>,
        end: &Bound<'_, PyAny>,
    ) -> PyResult<Py<PyAny>> {
        let first_date = self.inner.nodes.first_key();
        let start_date = parse_date_or_tenor(start, first_date, &self.inner.calendar, &self.inner.modifier)?;
        let end_date = parse_date_or_tenor(end, start_date, &self.inner.calendar, &self.inner.modifier)?;
        let result = self.inner.forward_rate(start_date, end_date);
        number_to_py(py, result)
    }

    fn shift(&self, bp: f64) -> Self {
        Self { inner: shift_discount_curve(&self.inner, bp) }
    }

    fn translate(&self, days: i64) -> Self {
        Self { inner: translate_discount_curve(&self.inner, days) }
    }

    fn roll(&self, days: i64) -> Self {
        Self { inner: roll_discount_curve(&self.inner, days) }
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        DiscountCurve::from_json(s)
            .map(|inner| Self { inner })
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn __repr__(&self) -> String {
        format!("DiscountCurve(id='{}', nodes={})", self.inner.id, self.inner.nodes.len())
    }
}

// ---- PyLineCurve ----

#[pyclass(name = "LineCurve", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyLineCurve {
    pub inner: LineCurve,
}

#[pymethods]
impl PyLineCurve {
    #[new]
    #[pyo3(signature = (nodes, /, interpolation="linear", id="curve", convention="act360", modifier="modified_following", calendar=None, t=None, endpoints="not_a_knot"))]
    fn new(
        nodes: &Bound<'_, PyAny>,
        interpolation: &str,
        id: &str,
        convention: &str,
        modifier: &str,
        calendar: Option<&PyBusinessCalendar>,
        t: Option<Vec<NaiveDate>>,
        endpoints: &str,
    ) -> PyResult<Self> {
        let mut parsed_nodes = parse_nodes(nodes)?;
        let interp_str = parse_interpolation(interpolation)?;
        let conv = parse_day_count(convention)?;
        let adj = parse_adjuster(modifier)?;
        let ep = parse_endpoint(endpoints)?;

        parsed_nodes.sort_keys();

        let interpolator = build_interpolator(&interp_str, &parsed_nodes, t, &ep, false)?;

        let curve = LineCurve {
            nodes: parsed_nodes,
            interpolator,
            convention: conv,
            modifier: adj,
            calendar: calendar.map(|c| c.inner.clone()),
            id: id.to_string(),
        };

        Ok(PyLineCurve { inner: curve })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(
        &self,
        py: Python<'_>,
        start: &Bound<'_, PyAny>,
        end: &Bound<'_, PyAny>,
    ) -> PyResult<Py<PyAny>> {
        let first_date = self.inner.nodes.first_key();
        let start_date = parse_date_or_tenor(start, first_date, &self.inner.calendar, &self.inner.modifier)?;
        let end_date = parse_date_or_tenor(end, start_date, &self.inner.calendar, &self.inner.modifier)?;
        let result = self.inner.zero_rate(start_date, end_date);
        number_to_py(py, result)
    }

    fn forward_rate(
        &self,
        py: Python<'_>,
        start: &Bound<'_, PyAny>,
        end: &Bound<'_, PyAny>,
    ) -> PyResult<Py<PyAny>> {
        let first_date = self.inner.nodes.first_key();
        let start_date = parse_date_or_tenor(start, first_date, &self.inner.calendar, &self.inner.modifier)?;
        let end_date = parse_date_or_tenor(end, start_date, &self.inner.calendar, &self.inner.modifier)?;
        let result = self.inner.forward_rate(start_date, end_date);
        number_to_py(py, result)
    }

    fn shift(&self, bp: f64) -> Self {
        Self { inner: shift_line_curve(&self.inner, bp) }
    }

    fn translate(&self, days: i64) -> Self {
        Self { inner: translate_line_curve(&self.inner, days) }
    }

    fn roll(&self, days: i64) -> Self {
        Self { inner: roll_line_curve(&self.inner, days) }
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        LineCurve::from_json(s)
            .map(|inner| Self { inner })
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn __repr__(&self) -> String {
        format!("LineCurve(id='{}', nodes={})", self.inner.id, self.inner.nodes.len())
    }
}

// ---- PyCreditImpliedCurve ----

#[pyclass(name = "CreditImpliedCurve", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyCreditImpliedCurve {
    pub inner: CreditImpliedCurve,
}

#[pymethods]
impl PyCreditImpliedCurve {
    #[new]
    #[pyo3(signature = (nodes, convention="act360", recovery_rate=0.4, id="credit_curve"))]
    fn new(
        nodes: &Bound<'_, PyAny>,
        convention: &str,
        recovery_rate: f64,
        id: &str,
    ) -> PyResult<Self> {
        let mut parsed_nodes = parse_nodes(nodes)?;
        parsed_nodes.sort_keys();
        let conv = parse_day_count(convention)?;
        Ok(PyCreditImpliedCurve {
            inner: CreditImpliedCurve::new(parsed_nodes, conv, recovery_rate, id.to_string()),
        })
    }

    fn survival_probability(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.survival_probability(date);
        number_to_py(py, result)
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.zero_rate(start, end);
        number_to_py(py, result)
    }

    fn forward_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.forward_rate(start, end);
        number_to_py(py, result)
    }

    fn shift(&self, bp: f64) -> Self {
        Self { inner: shift_credit_curve(&self.inner, bp) }
    }

    fn translate(&self, days: i64) -> Self {
        Self { inner: translate_credit_curve(&self.inner, days) }
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        let inner: CreditImpliedCurve = serde_json::from_str(s)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    #[getter]
    fn id(&self) -> String {
        self.inner.id.clone()
    }

    #[getter]
    fn recovery_rate(&self) -> f64 {
        self.inner.recovery_rate
    }

    fn __repr__(&self) -> String {
        format!(
            "CreditImpliedCurve(id='{}', nodes={}, recovery_rate={})",
            self.inner.id,
            self.inner.nodes.len(),
            self.inner.recovery_rate
        )
    }
}

// ---- PyCompositeCurve ----

#[pyclass(name = "CompositeCurve", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyCompositeCurve {
    pub inner: CompositeCurve,
}

#[pymethods]
impl PyCompositeCurve {
    #[new]
    #[pyo3(signature = (curves, id=None))]
    fn new(curves: Vec<Bound<'_, PyAny>>, id: Option<String>) -> PyResult<Self> {
        let curve_id = id.unwrap_or_else(|| "composite".to_string());

        if curves.is_empty() {
            return Err(PyValueError::new_err("curves list must not be empty"));
        }

        // Detect type from first element
        let first = &curves[0];
        if first.extract::<PyRef<'_, PyDiscountCurve>>().is_ok() {
            let mut disc_curves = Vec::new();
            for c in &curves {
                let dc = c.extract::<PyRef<'_, PyDiscountCurve>>()
                    .map_err(|_| PyValueError::new_err("All curves in CompositeCurve must be the same type (DiscountCurve)"))?;
                disc_curves.push(dc.inner.clone());
            }
            Ok(PyCompositeCurve {
                inner: CompositeCurve::new_discount(disc_curves, curve_id),
            })
        } else if first.extract::<PyRef<'_, PyLineCurve>>().is_ok() {
            let mut line_curves = Vec::new();
            for c in &curves {
                let lc = c.extract::<PyRef<'_, PyLineCurve>>()
                    .map_err(|_| PyValueError::new_err("All curves in CompositeCurve must be the same type (LineCurve)"))?;
                line_curves.push(lc.inner.clone());
            }
            Ok(PyCompositeCurve {
                inner: CompositeCurve::new_line(line_curves, curve_id),
            })
        } else {
            Err(PyValueError::new_err(
                "curves must contain DiscountCurve or LineCurve objects",
            ))
        }
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.zero_rate(start, end);
        number_to_py(py, result)
    }

    fn forward_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.forward_rate(start, end);
        number_to_py(py, result)
    }

    fn shift(&self, bp: f64) -> Self {
        Self { inner: shift_composite_curve(&self.inner, bp) }
    }

    fn translate(&self, days: i64) -> Self {
        Self { inner: translate_composite_curve(&self.inner, days) }
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        let inner: CompositeCurve = serde_json::from_str(s)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn __repr__(&self) -> String {
        let n = match &self.inner.curves {
            CompositeCurveType::Discount(v) => v.len(),
            CompositeCurveType::Line(v) => v.len(),
        };
        format!("CompositeCurve(id='{}', n_curves={})", self.inner.id, n)
    }
}

// ---- PyFXImpliedCurve ----

#[pyclass(name = "FXImpliedCurve", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyFXImpliedCurve {
    pub inner: FXImpliedCurve,
}

#[pymethods]
impl PyFXImpliedCurve {
    #[new]
    #[pyo3(signature = (cashflow_ccy, collateral_ccy, fx_rates, fx_settlements, collateral_curve, cashflow_curve, id=None))]
    fn new(
        cashflow_ccy: &str,
        collateral_ccy: &str,
        fx_rates: &PyFXRates,
        fx_settlements: HashMap<String, NaiveDate>,
        collateral_curve: &PyDiscountCurve,
        cashflow_curve: &PyDiscountCurve,
        id: Option<String>,
    ) -> PyResult<Self> {
        let curve_id = id.unwrap_or_else(|| format!("proxy_{}_{}", cashflow_ccy, collateral_ccy));
        Ok(PyFXImpliedCurve {
            inner: FXImpliedCurve::new(
                cashflow_ccy.to_string(),
                collateral_ccy.to_string(),
                fx_rates.inner.clone(),
                fx_settlements,
                collateral_curve.inner.clone(),
                cashflow_curve.inner.clone(),
                curve_id,
            ),
        })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.zero_rate(start, end);
        number_to_py(py, result)
    }

    fn forward_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.forward_rate(start, end);
        number_to_py(py, result)
    }

    fn shift(&self, bp: f64) -> Self {
        Self { inner: shift_fx_implied_curve(&self.inner, bp) }
    }

    fn translate(&self, days: i64) -> Self {
        Self { inner: translate_fx_implied_curve(&self.inner, days) }
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        let inner: FXImpliedCurve = serde_json::from_str(s)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn __repr__(&self) -> String {
        format!(
            "FXImpliedCurve(cashflow='{}', collateral='{}', id='{}')",
            self.inner.cashflow_ccy, self.inner.collateral_ccy, self.inner.id
        )
    }
}

// ---- PyNelsonSiegel ----

#[pyclass(name = "NelsonSiegel", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyNelsonSiegel {
    pub inner: NelsonSiegel,
}

#[pymethods]
impl PyNelsonSiegel {
    #[new]
    #[pyo3(signature = (beta0, beta1, beta2, tau, base_date, convention="act365f", id=""))]
    fn new(
        beta0: &Bound<'_, PyAny>,
        beta1: &Bound<'_, PyAny>,
        beta2: &Bound<'_, PyAny>,
        tau: &Bound<'_, PyAny>,
        base_date: NaiveDate,
        convention: &str,
        id: &str,
    ) -> PyResult<Self> {
        let beta0 = parse_number(beta0)?;
        let beta1 = parse_number(beta1)?;
        let beta2 = parse_number(beta2)?;
        let tau = parse_number(tau)?;
        let conv = parse_day_count(convention)?;
        Ok(Self {
            inner: NelsonSiegel::new(beta0, beta1, beta2, tau, conv, base_date, id.to_string()),
        })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.zero_rate(start, end);
        number_to_py(py, result)
    }

    fn forward_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.forward_rate(start, end);
        number_to_py(py, result)
    }

    /// Shift: add bp/10000 to beta0 (parallel bump).
    fn shift(&self, bp: f64) -> Self {
        let shift_decimal = Number::F64(bp / 10_000.0);
        let new_beta0 = &self.inner.beta0 + &shift_decimal;
        Self {
            inner: NelsonSiegel::new(
                new_beta0,
                self.inner.beta1.clone(),
                self.inner.beta2.clone(),
                self.inner.tau.clone(),
                self.inner.convention,
                self.inner.base_date,
                self.inner.id.clone(),
            ),
        }
    }

    /// Translate: shift base_date forward by N days.
    fn translate(&self, days: i64) -> Self {
        let new_base = self.inner.base_date + Duration::days(days);
        Self {
            inner: NelsonSiegel::new(
                self.inner.beta0.clone(),
                self.inner.beta1.clone(),
                self.inner.beta2.clone(),
                self.inner.tau.clone(),
                self.inner.convention,
                new_base,
                self.inner.id.clone(),
            ),
        }
    }

    /// Roll: shift base_date forward (same as translate for parametric curves).
    fn roll(&self, days: i64) -> Self {
        self.translate(days)
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        let inner: NelsonSiegel = serde_json::from_str(s)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn __repr__(&self) -> String {
        format!("NelsonSiegel(id='{}')", self.inner.id)
    }
}

// ---- PyNelsonSiegelSvensson ----

#[pyclass(name = "NelsonSiegelSvensson", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyNelsonSiegelSvensson {
    pub inner: NelsonSiegelSvensson,
}

#[pymethods]
impl PyNelsonSiegelSvensson {
    #[new]
    #[pyo3(signature = (beta0, beta1, beta2, beta3, tau1, tau2, base_date, convention="act365f", id=""))]
    fn new(
        beta0: &Bound<'_, PyAny>,
        beta1: &Bound<'_, PyAny>,
        beta2: &Bound<'_, PyAny>,
        beta3: &Bound<'_, PyAny>,
        tau1: &Bound<'_, PyAny>,
        tau2: &Bound<'_, PyAny>,
        base_date: NaiveDate,
        convention: &str,
        id: &str,
    ) -> PyResult<Self> {
        let beta0 = parse_number(beta0)?;
        let beta1 = parse_number(beta1)?;
        let beta2 = parse_number(beta2)?;
        let beta3 = parse_number(beta3)?;
        let tau1 = parse_number(tau1)?;
        let tau2 = parse_number(tau2)?;
        let conv = parse_day_count(convention)?;
        Ok(Self {
            inner: NelsonSiegelSvensson::new(
                beta0, beta1, beta2, beta3, tau1, tau2, conv, base_date, id.to_string(),
            ),
        })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.zero_rate(start, end);
        number_to_py(py, result)
    }

    fn forward_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.forward_rate(start, end);
        number_to_py(py, result)
    }

    /// Shift: add bp/10000 to beta0 (parallel bump).
    fn shift(&self, bp: f64) -> Self {
        let shift_decimal = Number::F64(bp / 10_000.0);
        let new_beta0 = &self.inner.beta0 + &shift_decimal;
        Self {
            inner: NelsonSiegelSvensson::new(
                new_beta0,
                self.inner.beta1.clone(),
                self.inner.beta2.clone(),
                self.inner.beta3.clone(),
                self.inner.tau1.clone(),
                self.inner.tau2.clone(),
                self.inner.convention,
                self.inner.base_date,
                self.inner.id.clone(),
            ),
        }
    }

    /// Translate: shift base_date forward by N days.
    fn translate(&self, days: i64) -> Self {
        let new_base = self.inner.base_date + Duration::days(days);
        Self {
            inner: NelsonSiegelSvensson::new(
                self.inner.beta0.clone(),
                self.inner.beta1.clone(),
                self.inner.beta2.clone(),
                self.inner.beta3.clone(),
                self.inner.tau1.clone(),
                self.inner.tau2.clone(),
                self.inner.convention,
                new_base,
                self.inner.id.clone(),
            ),
        }
    }

    /// Roll: shift base_date forward (same as translate for parametric curves).
    fn roll(&self, days: i64) -> Self {
        self.translate(days)
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        let inner: NelsonSiegelSvensson = serde_json::from_str(s)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn __repr__(&self) -> String {
        format!("NelsonSiegelSvensson(id='{}')", self.inner.id)
    }
}

// ---- PySmithWilson ----

#[pyclass(name = "SmithWilson", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PySmithWilson {
    pub inner: SmithWilson,
}

#[pymethods]
impl PySmithWilson {
    #[new]
    #[pyo3(signature = (dates, rates, ufr, alpha, base_date, convention="act365f", id=""))]
    fn new(
        dates: Vec<NaiveDate>,
        rates: Vec<f64>,
        ufr: f64,
        alpha: f64,
        base_date: NaiveDate,
        convention: &str,
        id: &str,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;
        Ok(Self {
            inner: SmithWilson::new(dates, rates, ufr, alpha, conv, base_date, id.to_string()),
        })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.zero_rate(start, end);
        number_to_py(py, result)
    }

    fn forward_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.forward_rate(start, end);
        number_to_py(py, result)
    }

    /// Shift: adjust all zeta-implied rates by bp/10000 and recompute.
    /// For SmithWilson, we recreate with shifted rates.
    fn shift(&self, bp: f64) -> PyResult<Self> {
        let shift_decimal = bp / 10_000.0;
        // Recover approximate rates from zeta + reshift
        // Simpler approach: reconstruct from shifted zero rates at original maturities
        let base = self.inner.base_date;
        let new_rates: Vec<f64> = self.inner.maturities.iter().map(|&u| {
            let df = self.inner.discount_factor(base + Duration::days((u * 365.25) as i64));
            let df_f64 = match df {
                Number::F64(v) => v,
                _ => unreachable!(),
            };
            let orig_rate = if u.abs() < 1e-14 { 0.0 } else { -df_f64.ln() / u };
            orig_rate + shift_decimal
        }).collect();

        let dates: Vec<NaiveDate> = self.inner.maturities.iter().map(|&u| {
            base + Duration::days((u * 365.25) as i64)
        }).collect();

        Ok(Self {
            inner: SmithWilson::new(
                dates,
                new_rates,
                self.inner.ufr,
                self.inner.alpha,
                self.inner.convention,
                base,
                self.inner.id.clone(),
            ),
        })
    }

    /// Translate: shift base_date and maturity dates forward by N days.
    fn translate(&self, days: i64) -> Self {
        let new_base = self.inner.base_date + Duration::days(days);
        let dates: Vec<NaiveDate> = self.inner.maturities.iter().map(|&u| {
            self.inner.base_date + Duration::days((u * 365.25) as i64) + Duration::days(days)
        }).collect();
        // Recover rates at original maturities
        let rates: Vec<f64> = self.inner.maturities.iter().map(|&u| {
            let df = self.inner.discount_factor(
                self.inner.base_date + Duration::days((u * 365.25) as i64)
            );
            let df_f64 = match df {
                Number::F64(v) => v,
                _ => unreachable!(),
            };
            if u.abs() < 1e-14 { 0.0 } else { -df_f64.ln() / u }
        }).collect();

        Self {
            inner: SmithWilson::new(
                dates,
                rates,
                self.inner.ufr,
                self.inner.alpha,
                self.inner.convention,
                new_base,
                self.inner.id.clone(),
            ),
        }
    }

    /// Roll: shift base_date forward (same as translate for SmithWilson).
    fn roll(&self, days: i64) -> Self {
        self.translate(days)
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        let inner: SmithWilson = serde_json::from_str(s)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn __repr__(&self) -> String {
        format!("SmithWilson(id='{}', ufr={}, alpha={})", self.inner.id, self.inner.ufr, self.inner.alpha)
    }
}

// ---- PyForwardCurve ----

#[pyclass(name = "ForwardCurve", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyForwardCurve {
    pub inner: ForwardCurve,
}

#[pymethods]
impl PyForwardCurve {
    #[new]
    #[pyo3(signature = (nodes, /, interpolation="flat_forward", id="forward_curve", convention="act365f", modifier="modified_following", calendar=None, t=None, endpoints="not_a_knot"))]
    fn new(
        nodes: &Bound<'_, PyAny>,
        interpolation: &str,
        id: &str,
        convention: &str,
        modifier: &str,
        calendar: Option<&PyBusinessCalendar>,
        t: Option<Vec<NaiveDate>>,
        endpoints: &str,
    ) -> PyResult<Self> {
        let mut parsed_nodes = parse_nodes(nodes)?;
        let interp_str = parse_interpolation(interpolation)?;
        let conv = parse_day_count(convention)?;
        let _adj = parse_adjuster(modifier)?;
        let ep = parse_endpoint(endpoints)?;

        // No ensure_first_df_one -- forward rates, not DFs
        parsed_nodes.sort_keys();

        let interpolator = build_interpolator(&interp_str, &parsed_nodes, t, &ep, false)?;

        let mut curve = ForwardCurve::new(
            parsed_nodes,
            interpolator,
            conv,
            id.to_string(),
        );
        if let Some(c) = calendar {
            curve.calendar = Some(c.inner.clone());
        }

        Ok(PyForwardCurve { inner: curve })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(
        &self,
        py: Python<'_>,
        start: &Bound<'_, PyAny>,
        end: &Bound<'_, PyAny>,
    ) -> PyResult<Py<PyAny>> {
        let first_date = self.inner.nodes.first_key();
        let start_date = parse_date_or_tenor(start, first_date, &self.inner.calendar, &self.inner.modifier)?;
        let end_date = parse_date_or_tenor(end, start_date, &self.inner.calendar, &self.inner.modifier)?;
        let result = self.inner.zero_rate(start_date, end_date);
        number_to_py(py, result)
    }

    fn forward_rate(
        &self,
        py: Python<'_>,
        start: &Bound<'_, PyAny>,
        end: &Bound<'_, PyAny>,
    ) -> PyResult<Py<PyAny>> {
        let first_date = self.inner.nodes.first_key();
        let start_date = parse_date_or_tenor(start, first_date, &self.inner.calendar, &self.inner.modifier)?;
        let end_date = parse_date_or_tenor(end, start_date, &self.inner.calendar, &self.inner.modifier)?;
        let result = self.inner.forward_rate(start_date, end_date);
        number_to_py(py, result)
    }

    fn to_json(&self) -> PyResult<String> {
        Ok(self.inner.to_json())
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        ForwardCurve::from_json(s)
            .map(|inner| Self { inner })
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn __repr__(&self) -> String {
        format!("ForwardCurve(id='{}', nodes={})", self.inner.id, self.inner.nodes.len())
    }
}

// ---- PySpreadCurve ----

#[pyclass(name = "SpreadCurve", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PySpreadCurve {
    pub inner: SpreadCurve,
}

fn parse_spread_mode(s: &str) -> PyResult<SpreadMode> {
    match s.to_lowercase().as_str() {
        "additive" | "add" => Ok(SpreadMode::Additive),
        "multiplicative" | "mult" | "mul" => Ok(SpreadMode::Multiplicative),
        _ => Err(PyValueError::new_err(format!(
            "Unknown spread mode: '{}'. Use: 'additive' or 'multiplicative'",
            s
        ))),
    }
}

/// Parse a JSON string into a CurveContainer (DiscountCurve, LineCurve, or ForwardCurve).
/// The JSON must contain a "type" field or be directly deserializable.
fn parse_curve_container_json(json: &str) -> PyResult<CurveContainer> {
    // Try DiscountCurve first
    if let Ok(c) = DiscountCurve::from_json(json) {
        return Ok(CurveContainer::Discount(c));
    }
    // Try LineCurve
    if let Ok(c) = LineCurve::from_json(json) {
        return Ok(CurveContainer::Line(c));
    }
    // Try ForwardCurve
    if let Ok(c) = ForwardCurve::from_json(json) {
        return Ok(CurveContainer::Forward(c));
    }
    Err(PyValueError::new_err(
        "Could not parse base curve JSON. Must be a valid DiscountCurve, LineCurve, or ForwardCurve JSON."
    ))
}

#[pymethods]
impl PySpreadCurve {
    #[new]
    #[pyo3(signature = (base_json, spread_nodes, /, mode="additive", spread_interpolation="linear", convention="act365f", id="spread_curve"))]
    fn new(
        base_json: &str,
        spread_nodes: &Bound<'_, PyAny>,
        mode: &str,
        spread_interpolation: &str,
        convention: &str,
        id: &str,
    ) -> PyResult<Self> {
        let base = parse_curve_container_json(base_json)?;
        let spread_mode = parse_spread_mode(mode)?;
        let conv = parse_day_count(convention)?;

        let mut parsed_nodes = parse_nodes(spread_nodes)?;
        parsed_nodes.sort_keys();

        let interp_str = parse_interpolation(spread_interpolation)?;
        let ep = SplineEndpoint::NotAKnot;
        let interpolator = build_interpolator(&interp_str, &parsed_nodes, None, &ep, false)?;

        let spread_line = LineCurve {
            nodes: parsed_nodes,
            interpolator,
            convention: conv,
            modifier: Adjuster::ModifiedFollowing,
            calendar: None,
            id: format!("{}_spread", id),
        };

        let curve = SpreadCurve::new(base, spread_line, spread_mode, conv, id.to_string());
        Ok(PySpreadCurve { inner: curve })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(
        &self,
        py: Python<'_>,
        start: NaiveDate,
        end: NaiveDate,
    ) -> PyResult<Py<PyAny>> {
        let result = self.inner.zero_rate(start, end);
        number_to_py(py, result)
    }

    fn forward_rate(
        &self,
        py: Python<'_>,
        start: NaiveDate,
        end: NaiveDate,
    ) -> PyResult<Py<PyAny>> {
        let result = self.inner.forward_rate(start, end);
        number_to_py(py, result)
    }

    fn to_json(&self) -> PyResult<String> {
        Ok(self.inner.to_json())
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        SpreadCurve::from_json(s)
            .map(|inner| Self { inner })
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn __repr__(&self) -> String {
        let mode_str = match &self.inner.mode {
            SpreadMode::Additive => "additive",
            SpreadMode::Multiplicative => "multiplicative",
        };
        format!("SpreadCurve(id='{}', mode='{}')", self.inner.id, mode_str)
    }
}

// ---- PyTurnOfYearCurve ----

#[pyclass(name = "TurnOfYearCurve", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyTurnOfYearCurve {
    pub inner: TurnOfYearCurve,
}

#[pymethods]
impl PyTurnOfYearCurve {
    #[new]
    #[pyo3(signature = (inner_json, bumps, /, convention="act365f", calendar=None, id="toy_curve"))]
    fn new(
        inner_json: &str,
        bumps: HashMap<NaiveDate, f64>,
        convention: &str,
        calendar: Option<&PyBusinessCalendar>,
        id: &str,
    ) -> PyResult<Self> {
        let inner_curve = parse_curve_container_json(inner_json)?;
        let conv = parse_day_count(convention)?;
        let cal = calendar.map(|c| c.inner.clone());

        let bumps_vec: Vec<(NaiveDate, f64)> = bumps.into_iter().collect();

        let curve = TurnOfYearCurve::new(inner_curve, bumps_vec, conv, cal, id.to_string());
        Ok(PyTurnOfYearCurve { inner: curve })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(
        &self,
        py: Python<'_>,
        start: NaiveDate,
        end: NaiveDate,
    ) -> PyResult<Py<PyAny>> {
        let result = self.inner.zero_rate(start, end);
        number_to_py(py, result)
    }

    fn forward_rate(
        &self,
        py: Python<'_>,
        start: NaiveDate,
        end: NaiveDate,
    ) -> PyResult<Py<PyAny>> {
        let result = self.inner.forward_rate(start, end);
        number_to_py(py, result)
    }

    fn to_json(&self) -> PyResult<String> {
        Ok(self.inner.to_json())
    }

    #[staticmethod]
    fn from_json(s: &str) -> PyResult<Self> {
        TurnOfYearCurve::from_json(s)
            .map(|inner| Self { inner })
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn __repr__(&self) -> String {
        format!(
            "TurnOfYearCurve(id='{}', bumps={})",
            self.inner.id,
            self.inner.bumps.len()
        )
    }
}

// ---- PyIRImpliedCurve ----

#[pyclass(name = "IRImpliedCurve", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyIRImpliedCurve {
    pub inner: IRImpliedCurve,
}

#[pymethods]
impl PyIRImpliedCurve {
    #[new]
    #[pyo3(signature = (source, ref_date, tenors, calendar, convention = "act365f"))]
    fn new(
        source: &Bound<'_, PyAny>,
        ref_date: NaiveDate,
        tenors: Vec<String>,
        calendar: &PyBusinessCalendar,
        convention: &str,
    ) -> PyResult<Self> {
        let conv = parse_day_count(convention)?;

        // Extract the source curve as a CurveQuery
        let source_curve: Box<dyn CurveQuery> = if let Ok(dc) = source.extract::<PyRef<'_, PyDiscountCurve>>() {
            Box::new(dc.inner.clone())
        } else if let Ok(lc) = source.extract::<PyRef<'_, PyLineCurve>>() {
            Box::new(lc.inner.clone())
        } else {
            return Err(PyValueError::new_err(
                "source must be a DiscountCurve or LineCurve",
            ));
        };

        let curve = IRImpliedCurve::from_curve(
            &*source_curve, ref_date, &tenors, &calendar.inner, conv,
        ).map_err(|e| PyValueError::new_err(e))?;

        Ok(PyIRImpliedCurve { inner: curve })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        number_to_py(py, self.inner.discount_factor(date))
    }

    fn zero_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        number_to_py(py, self.inner.zero_rate(start, end))
    }

    fn forward_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        number_to_py(py, self.inner.forward_rate(start, end))
    }

    /// Compute bucket-level DV01 risk. Returns Polars DataFrame with columns: tenor, date, delta.
    fn bucket_delta(&mut self, py: Python<'_>, instrument: &Bound<'_, PyAny>) -> PyResult<Py<PyAny>> {
        use crate::instruments::py::extract_instrument;
        // Try direct extraction first, then unwrap _inner for Python wrapper classes
        let inst = match extract_instrument(instrument) {
            Ok(i) => i,
            Err(_) => {
                let inner = instrument.getattr("_inner")?;
                extract_instrument(&inner)?
            }
        };

        let results = self.inner.bucket_delta(|curve| {
            inst.npv(curve, curve, None, None, None)
        });

        // Convert Vec<(String, NaiveDate, f64)> to Polars DataFrame
        let tenor_col: Vec<&str> = results.iter().map(|(t, _, _)| t.as_str()).collect();
        let date_col: Vec<NaiveDate> = results.iter().map(|(_, d, _)| *d).collect();
        let delta_col: Vec<f64> = results.iter().map(|(_, _, v)| *v).collect();

        let polars = py.import("polars")?;
        let dict = pyo3::types::PyDict::new(py);
        dict.set_item("tenor", tenor_col.into_pyobject(py)?)?;
        dict.set_item("date", date_col.into_pyobject(py)?)?;
        dict.set_item("delta", delta_col.into_pyobject(py)?)?;
        let df = polars.call_method1("DataFrame", (dict,))?;
        Ok(df.into())
    }

    fn tenor_labels(&self) -> Vec<String> {
        self.inner.tenor_labels.clone()
    }

    fn __repr__(&self) -> String {
        format!(
            "IRImpliedCurve(id='{}', tenors={:?})",
            self.inner.id,
            self.inner.tenor_labels
        )
    }
}

// ---- PyFittedBondCurve ----

#[pyclass(name = "FittedBondCurve", module = "vade._vade_rs.curves", from_py_object)]
#[derive(Clone)]
pub struct PyFittedBondCurve {
    pub inner: FittedBondCurve,
}

/// Extract a BondInstrument from a Python bond object.
/// Python bond classes (FixedRateBond, ZeroCouponBond, etc.) store `_inner: PyBondInstrument`.
fn extract_bond_instrument(obj: &Bound<'_, PyAny>) -> PyResult<crate::instruments::BondInstrument> {
    // Try to get _inner attribute (Python-level bond wrappers)
    if let Ok(inner_attr) = obj.getattr("_inner") {
        if let Ok(pbi) = inner_attr.extract::<PyRef<'_, PyBondInstrument>>() {
            return Ok(pbi.inner.clone());
        }
    }
    // Try direct extraction (if user passes PyBondInstrument directly)
    if let Ok(pbi) = obj.extract::<PyRef<'_, PyBondInstrument>>() {
        return Ok(pbi.inner.clone());
    }
    Err(PyValueError::new_err(
        "Each bond must be a FixedRateBond, ZeroCouponBond, Bill, FloatRateNote, StepUpBond, AmortizingBond, PIKBond, SubPeriodFRN, CappedFloatRateNote, or PyBondInstrument"
    ))
}

#[pymethods]
impl PyFittedBondCurve {
    #[new]
    #[pyo3(signature = (bonds, clean_prices, settlement, model="NS", *, convention="act365f", base_date=None, weights=None, initial_params=None, max_iter=None, func_tol=None, ufr=None, alpha=None, id=""))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        bonds: Vec<Bound<'_, PyAny>>,
        clean_prices: Vec<f64>,
        settlement: NaiveDate,
        model: &str,
        convention: &str,
        base_date: Option<NaiveDate>,
        weights: Option<Vec<f64>>,
        initial_params: Option<Vec<f64>>,
        max_iter: Option<usize>,
        func_tol: Option<f64>,
        ufr: Option<f64>,
        alpha: Option<f64>,
        id: &str,
    ) -> PyResult<Self> {
        // Parse model string
        let fitting_model = match model.to_uppercase().as_str() {
            "NS" => FittingModel::NelsonSiegel,
            "NSS" => FittingModel::NelsonSiegelSvensson,
            "SW" => {
                let u = ufr.ok_or_else(|| PyValueError::new_err("ufr is required for SmithWilson model"))?;
                let a = alpha.ok_or_else(|| PyValueError::new_err("alpha is required for SmithWilson model"))?;
                FittingModel::SmithWilson { ufr: u, alpha: a }
            }
            _ => return Err(PyValueError::new_err(format!(
                "model must be 'NS', 'NSS', or 'SW', got '{}'", model
            ))),
        };

        // Extract bond instruments
        let bond_instruments: Vec<crate::instruments::BondInstrument> = bonds
            .iter()
            .map(|b| extract_bond_instrument(b))
            .collect::<PyResult<Vec<_>>>()?;

        let conv = parse_day_count(convention)?;
        let base = base_date.unwrap_or(settlement);

        let fitted = FittedBondCurve::fit(
            &bond_instruments,
            &clean_prices,
            settlement,
            fitting_model,
            conv,
            base,
            weights.as_deref(),
            initial_params.as_deref(),
            max_iter,
            func_tol,
            id.to_string(),
        );

        Ok(Self { inner: fitted })
    }

    fn discount_factor(&self, py: Python<'_>, date: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.discount_factor(date);
        number_to_py(py, result)
    }

    fn zero_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.zero_rate(start, end);
        number_to_py(py, result)
    }

    fn forward_rate(&self, py: Python<'_>, start: NaiveDate, end: NaiveDate) -> PyResult<Py<PyAny>> {
        let result = self.inner.forward_rate(start, end);
        number_to_py(py, result)
    }

    #[getter]
    fn rmse(&self) -> f64 {
        self.inner.fit_result.rmse
    }

    #[getter]
    fn converged(&self) -> bool {
        self.inner.fit_result.converged
    }

    #[getter]
    fn iterations(&self) -> usize {
        self.inner.fit_result.iterations
    }

    #[getter]
    fn objective(&self) -> f64 {
        self.inner.fit_result.objective
    }

    fn pricing_errors(&self) -> Vec<f64> {
        self.inner.fit_result.pricing_errors.clone()
    }

    /// Return the inner fitted curve as a Python object (NelsonSiegel, NelsonSiegelSvensson, or SmithWilson).
    fn curve(&self, py: Python<'_>) -> PyResult<Py<PyAny>> {
        match &self.inner.curve {
            FittedCurveInner::NS(ns) => {
                let obj = PyNelsonSiegel { inner: ns.clone() };
                Ok(obj.into_pyobject(py).map_err(|e| PyValueError::new_err(e.to_string()))?.into_any().unbind())
            }
            FittedCurveInner::NSS(nss) => {
                let obj = PyNelsonSiegelSvensson { inner: nss.clone() };
                Ok(obj.into_pyobject(py).map_err(|e| PyValueError::new_err(e.to_string()))?.into_any().unbind())
            }
            FittedCurveInner::SW(sw) => {
                let obj = PySmithWilson { inner: sw.clone() };
                Ok(obj.into_pyobject(py).map_err(|e| PyValueError::new_err(e.to_string()))?.into_any().unbind())
            }
        }
    }

    fn __repr__(&self) -> String {
        let model = match &self.inner.curve {
            FittedCurveInner::NS(_) => "NS",
            FittedCurveInner::NSS(_) => "NSS",
            FittedCurveInner::SW(_) => "SW",
        };
        format!(
            "FittedBondCurve(model='{}', rmse={:.6}, converged={})",
            model, self.inner.fit_result.rmse, self.inner.fit_result.converged
        )
    }
}

// ---- Module registration ----

pub fn register_module(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyDiscountCurve>()?;
    m.add_class::<PyLineCurve>()?;
    m.add_class::<PyCreditImpliedCurve>()?;
    m.add_class::<PyCompositeCurve>()?;
    m.add_class::<PyFXImpliedCurve>()?;
    m.add_class::<PyNelsonSiegel>()?;
    m.add_class::<PyNelsonSiegelSvensson>()?;
    m.add_class::<PySmithWilson>()?;
    m.add_class::<PyForwardCurve>()?;
    m.add_class::<PySpreadCurve>()?;
    m.add_class::<PyTurnOfYearCurve>()?;
    m.add_class::<PyIRImpliedCurve>()?;
    m.add_class::<PyFittedBondCurve>()?;
    Ok(())
}
