use std::collections::HashMap;
use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::convention::DcfOptions;
use crate::cashflows::leg::{FixedLeg, FloatLeg};
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;
use crate::marketcurves::fx::pair::FXPair;
use crate::marketcurves::fx::rates::FXRates;

/// Interest Rate Swap: FixedLeg + FloatLeg.
///
/// Sign convention: positive notional = pay leg.
/// IRS composes a fixed leg (pay fixed) and float leg (receive float),
/// or vice versa depending on notional signs.
#[derive(Clone, Serialize, Deserialize)]
pub struct InterestRateSwap {
    pub fixed_leg: FixedLeg,
    pub float_leg: FloatLeg,
    // NDIRS-specific (all None for plain IRS)
    #[serde(default)]
    pub settlement_currency: Option<String>,
    #[serde(default)]
    pub pair: Option<FXPair>,
    #[serde(default)]
    pub fx_fixings: Option<HashMap<NaiveDate, f64>>,
}

impl InterestRateSwap {
    /// Construct from pre-built legs.
    pub fn new(fixed_leg: FixedLeg, float_leg: FloatLeg) -> Self {
        Self {
            fixed_leg,
            float_leg,
            settlement_currency: None,
            pair: None,
            fx_fixings: None,
        }
    }

    /// Construct an NDIRS (non-deliverable interest rate swap).
    pub fn new_ndirs(
        fixed_leg: FixedLeg,
        float_leg: FloatLeg,
        settlement_currency: String,
        pair: FXPair,
        fx_fixings: Option<HashMap<NaiveDate, f64>>,
    ) -> Self {
        Self {
            fixed_leg,
            float_leg,
            settlement_currency: Some(settlement_currency),
            pair: Some(pair),
            fx_fixings,
        }
    }

    /// Check if this instrument is configured as an NDIRS.
    pub fn is_ndirs(&self) -> bool {
        self.settlement_currency.is_some()
    }

    /// Par rate: the fixed rate that makes NPV = 0.
    ///
    /// rate = float_npv / (fixed_analytic_delta * (-100.0))
    ///
    /// Uses forecast_curve for float rate computation, disc_curve for discounting.
    /// Excludes notional exchanges (they cancel for single-currency swaps).
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let float_npv = self.float_leg_coupon_npv(forecast_curve, disc_curve);
        let fixed_ad = self.fixed_leg.analytic_delta(disc_curve);
        &float_npv / &(&fixed_ad * (-100.0))
    }

    /// NPV = fixed_leg_npv + float_leg_npv (coupon only, excluding notional exchanges).
    ///
    /// For single-currency IRS, notional exchanges cancel and are excluded.
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let fixed_npv = self.fixed_leg_coupon_npv(disc_curve);
        let float_npv = self.float_leg_coupon_npv(forecast_curve, disc_curve);
        fixed_npv + float_npv
    }

    /// Fixed leg coupon NPV only (excluding notional exchanges).
    pub fn fixed_leg_coupon_npv(&self, disc_curve: &dyn CurveQuery) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.fixed_leg.periods {
            total = total + p.npv(disc_curve);
        }
        total
    }

    /// Float leg coupon NPV only (excluding notional exchanges), dual-curve.
    pub fn float_leg_coupon_npv(
        &self,
        forecast_curve: &dyn CurveQuery,
        disc_curve: &dyn CurveQuery,
    ) -> Number {
        let mut total = Number::F64(0.0);
        for p in &self.float_leg.periods {
            total = total + p.npv_dual_curve(forecast_curve, disc_curve, None);
        }
        total
    }

    /// Cashflow rows from both legs.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        let mut rows = self.fixed_leg.cashflows(disc_curve);
        if let (Some(fc), Some(_dc)) = (forecast_curve, disc_curve) {
            // For float leg, use the forecast curve for rate and disc curve for DF
            // Since cashflows method uses single curve, we pass forecast curve
            rows.extend(self.float_leg.cashflows(Some(fc), None));
        } else {
            rows.extend(self.float_leg.cashflows(None, None));
        }
        rows.sort_by_key(|r| r.payment);
        rows
    }

    /// Spread in percentage on the float leg that makes NPV = 0.
    pub fn spread(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        // spread = npv / (float_analytic_delta * (-100))
        let npv = self.npv(disc_curve, forecast_curve);
        let float_ad = self.float_leg.analytic_delta_disc(disc_curve);
        &npv / &(&float_ad * (-100.0))
    }

    // -----------------------------------------------------------------------
    // NDIRS-specific methods
    // -----------------------------------------------------------------------

    /// Get FX rate for a period's payment date: use known fixing if available,
    /// else IRP implied forward: fwd = spot * DF_settlement(T) / DF_restricted(T).
    fn fx_for_date(
        &self,
        payment_date: NaiveDate,
        spot: &Number,
        settle_disc: &dyn CurveQuery,
        restricted_disc: &dyn CurveQuery,
    ) -> Number {
        if let Some(fixings) = &self.fx_fixings {
            if let Some(&fx) = fixings.get(&payment_date) {
                return Number::F64(fx);
            }
        }
        // IRP implied forward: fwd = spot * DF_settle / DF_restricted
        let df_s = settle_disc.discount_factor(payment_date);
        let df_r = restricted_disc.discount_factor(payment_date);
        &(spot * &df_s) / &df_r
    }

    /// NDIRS NPV: convert-then-discount in settlement currency.
    ///
    /// For each period: compute restricted-currency cashflow, convert to settlement
    /// currency via FX rate, then discount with settlement discount curve.
    ///
    /// disc_curve = settlement discount, forecast_curve = restricted forecast,
    /// leg2_disc_curve = restricted discount (for FX forward derivation).
    pub fn ndirs_npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        leg2_disc_curve: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        let pair = self.pair.as_ref().expect("NDIRS requires pair");
        let spot = fx_rates.rate(pair);
        let mut total = Number::F64(0.0);

        // Fixed leg: each period's restricted-ccy cashflow -> convert -> discount
        for p in &self.fixed_leg.periods {
            let restricted_cf = Number::F64(p.cashflow());
            let fx = self.fx_for_date(p.payment, &spot, disc_curve, leg2_disc_curve);
            let settle_cf = &restricted_cf / &fx;
            let df = disc_curve.discount_factor(p.payment);
            total = total + &settle_cf * &df;
        }

        // Float leg: forecast rate from restricted curve, then convert + discount
        for p in &self.float_leg.periods {
            let rate = p.rate(forecast_curve, None);
            let dcf = p.convention
                .dcf(p.start, p.end, &DcfOptions::default())
                .unwrap();
            // cashflow = rate * (-notional * dcf) -- rate is decimal from rfr_rate
            let restricted_cf = &rate * (-p.notional * dcf);
            let fx = self.fx_for_date(p.payment, &spot, disc_curve, leg2_disc_curve);
            let settle_cf = &restricted_cf / &fx;
            let df = disc_curve.discount_factor(p.payment);
            total = total + &settle_cf * &df;
        }

        total
    }

    /// NDIRS par rate: the fixed rate that makes settlement-currency NPV = 0.
    ///
    /// rate = float_npv_converted / (fixed_analytic_delta_converted * -100)
    pub fn ndirs_rate(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        leg2_disc_curve: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        let pair = self.pair.as_ref().expect("NDIRS requires pair");
        let spot = fx_rates.rate(pair);

        // Float leg converted NPV
        let mut float_npv = Number::F64(0.0);
        for p in &self.float_leg.periods {
            let rate = p.rate(forecast_curve, None);
            let dcf = p.convention
                .dcf(p.start, p.end, &DcfOptions::default())
                .unwrap();
            let restricted_cf = &rate * (-p.notional * dcf);
            let fx = self.fx_for_date(p.payment, &spot, disc_curve, leg2_disc_curve);
            let settle_cf = &restricted_cf / &fx;
            let df = disc_curve.discount_factor(p.payment);
            float_npv = float_npv + &settle_cf * &df;
        }

        // Fixed leg converted analytic delta: -notional * dcf / 10000, converted and discounted
        let mut fixed_ad = Number::F64(0.0);
        for p in &self.fixed_leg.periods {
            let dcf = p.convention
                .dcf(p.start, p.end, &DcfOptions::default())
                .unwrap();
            let ad = -p.notional * dcf / 10000.0;
            let fx = self.fx_for_date(p.payment, &spot, disc_curve, leg2_disc_curve);
            let settle_ad = &Number::F64(ad) / &fx;
            let df = disc_curve.discount_factor(p.payment);
            fixed_ad = fixed_ad + &settle_ad * &df;
        }

        &float_npv / &(&fixed_ad * (-100.0))
    }

    /// NDIRS cashflows: base IRS cashflows plus settlement conversion info.
    pub fn ndirs_cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
        leg2_disc_curve: Option<&dyn CurveQuery>,
        fx_rates: Option<&FXRates>,
    ) -> Vec<CashflowRow> {
        let settle_ccy = self.settlement_currency.as_deref().unwrap_or("???");
        // Get base IRS cashflows first
        let mut rows = self.cashflows(disc_curve, forecast_curve);

        // If all curves + fx_rates available, add settlement conversion info
        if let (Some(dc), Some(l2d), Some(fxr)) = (disc_curve, leg2_disc_curve, fx_rates) {
            let pair = self.pair.as_ref().expect("NDIRS requires pair");
            let spot = fxr.rate(pair);
            for row in &mut rows {
                let fx = self.fx_for_date(row.payment, &spot, dc, l2d);
                let fx_f64 = match &fx {
                    Number::F64(f) => *f,
                    Number::Dual(d) => d.real,
                    Number::Dual2(d) => d.real,
                };
                let settle_cf = &row.cashflow / &fx;
                row.settlement_amount = Some(settle_cf);
                row.fx_rate = Some(fx_f64);
                row.settlement_currency_label = Some(settle_ccy.to_string());
            }
        }

        rows
    }

    /// NDIRS spread: the spread on the float leg that makes settlement-currency NPV = 0.
    ///
    /// spread = npv / (float_analytic_delta_converted * -100)
    pub fn ndirs_spread(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
        leg2_disc_curve: &dyn CurveQuery,
        fx_rates: &FXRates,
    ) -> Number {
        let npv = self.ndirs_npv(disc_curve, forecast_curve, leg2_disc_curve, fx_rates);
        let pair = self.pair.as_ref().expect("NDIRS requires pair");
        let spot = fx_rates.rate(pair);

        let mut float_ad = Number::F64(0.0);
        for p in &self.float_leg.periods {
            // analytic_delta uses disc_curve (settlement) for discounting
            let ad = p.analytic_delta(disc_curve);
            let fx = self.fx_for_date(p.payment, &spot, disc_curve, leg2_disc_curve);
            float_ad = float_ad + &ad / &fx;
        }

        &npv / &(&float_ad * (-100.0))
    }

    /// Pillar date: last period end date of the swap.
    pub fn pillar_date(&self) -> NaiveDate {
        self.float_leg.periods.last()
            .map(|p| p.end)
            .unwrap_or_else(|| self.fixed_leg.periods.last().unwrap().end)
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
    use crate::cashflows::amortization::Amortization;
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::schedule::{Schedule, StubInference};
    use crate::calendar::cal::BusinessCalendar;
    use crate::calendar::adjuster::Adjuster;
    use crate::calendar::frequency::Frequency;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
            (ymd(2028, 1, 1), 0.88),
            (ymd(2029, 1, 1), 0.85),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    pub fn make_test_irs() -> InterestRateSwap {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let schedule = Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            Frequency::SemiAnnual,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        ).unwrap();

        let fixed_leg = FixedLeg::new(
            &schedule,
            3.0, // 3% fixed rate
            1_000_000.0,
            DayCountConvention::Act365F,
            "USD".to_string(),
            None,
            Amortization::None,
        );

        let float_leg = FloatLeg::new(
            &schedule,
            0.0, // no spread
            -1_000_000.0, // receive (negative notional)
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "USD".to_string(),
            None,
            Amortization::None,
        );

        InterestRateSwap::new(fixed_leg, float_leg)
    }

    #[test]
    fn test_irs_rate_returns_par_rate() {
        let curve = test_curve();
        let irs = make_test_irs();
        let rate = irs.rate(&curve, &curve);
        if let Number::F64(r) = rate {
            // Par rate should be positive and in reasonable range (percentage)
            assert!(r > 0.0, "Par rate should be positive, got {r}");
            assert!(r < 20.0, "Par rate should be < 20%, got {r}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_irs_npv_at_par_rate_near_zero() {
        let curve = test_curve();
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let schedule = Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            Frequency::SemiAnnual,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        ).unwrap();

        // First get the par rate
        let irs_for_rate = make_test_irs();
        let par_rate = match irs_for_rate.rate(&curve, &curve) {
            Number::F64(r) => r,
            _ => panic!("Expected F64"),
        };

        // Build IRS at par rate
        let fixed_leg = FixedLeg::new(
            &schedule,
            par_rate, // use par rate
            1_000_000.0,
            DayCountConvention::Act365F,
            "USD".to_string(),
            None,
            Amortization::None,
        );
        let float_leg = FloatLeg::new(
            &schedule,
            0.0,
            -1_000_000.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "USD".to_string(),
            None,
            Amortization::None,
        );
        let irs = InterestRateSwap::new(fixed_leg, float_leg);
        let npv = irs.npv(&curve, &curve);
        if let Number::F64(v) = npv {
            assert!(
                v.abs() < 1e-6,
                "NPV at par rate should be ~0, got {v}"
            );
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_irs_spread() {
        let curve = test_curve();
        let irs = make_test_irs();
        let spread = irs.spread(&curve, &curve);
        if let Number::F64(s) = spread {
            assert!(s.is_finite(), "Spread should be finite, got {s}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_irs_cashflows() {
        let curve = test_curve();
        let irs = make_test_irs();
        let rows = irs.cashflows(Some(&curve), Some(&curve));
        assert!(!rows.is_empty(), "Should have cashflow rows");
        // Should have both fixed and float period types
        let has_fixed = rows.iter().any(|r| r.period_type == "Fixed");
        let has_float = rows.iter().any(|r| r.period_type == "Float");
        assert!(has_fixed, "Should have fixed periods");
        assert!(has_float, "Should have float periods");
    }

    #[test]
    fn test_irs_pillar_date() {
        let irs = make_test_irs();
        let pillar = irs.pillar_date();
        assert_eq!(pillar, ymd(2026, 1, 1));
    }

    // -----------------------------------------------------------------------
    // NDIRS tests
    // -----------------------------------------------------------------------

    use crate::marketcurves::fx::pair::FXPair;
    use crate::marketcurves::fx::rates::FXRates;

    /// Extract the real f64 value from any Number variant.
    fn number_real(n: &Number) -> f64 {
        match n {
            Number::F64(f) => *f,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        }
    }

    /// USD curve (settlement): lower rates (higher DF)
    fn usd_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
            (ymd(2028, 1, 1), 0.88),
            (ymd(2029, 1, 1), 0.85),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "usd".to_string(),
        )
    }

    /// BRL curve (restricted): higher rates (lower DF) -- materially different from USD
    fn brl_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.88),
            (ymd(2026, 1, 1), 0.77),
            (ymd(2027, 1, 1), 0.67),
            (ymd(2028, 1, 1), 0.58),
            (ymd(2029, 1, 1), 0.50),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "brl".to_string(),
        )
    }

    fn test_fx_rates() -> FXRates {
        let pair = FXPair::new("usd", "brl");
        FXRates::new(vec![(pair, 5.0)], ymd(2024, 1, 1))
    }

    pub fn make_test_ndirs() -> InterestRateSwap {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let schedule = Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            Frequency::SemiAnnual,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        ).unwrap();

        let fixed_leg = FixedLeg::new(
            &schedule,
            10.0, // 10% fixed rate (BRL-like)
            1_000_000.0,
            DayCountConvention::Act365F,
            "BRL".to_string(),
            None,
            Amortization::None,
        );

        let float_leg = FloatLeg::new(
            &schedule,
            0.0,
            -1_000_000.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "BRL".to_string(),
            None,
            Amortization::None,
        );

        InterestRateSwap::new_ndirs(
            fixed_leg,
            float_leg,
            "USD".to_string(),
            FXPair::new("usd", "brl"),
            None,
        )
    }

    #[test]
    fn test_ndirs_rate_returns_finite() {
        let usd = usd_curve();
        let brl = brl_curve();
        let fxr = test_fx_rates();
        let ndirs = make_test_ndirs();

        let rate = ndirs.ndirs_rate(&usd, &brl, &brl, &fxr);
        let r = number_real(&rate);
        assert!(r.is_finite(), "NDIRS rate should be finite, got {r}");
        assert!(r > 0.0, "NDIRS rate should be positive, got {r}");
        assert!(r < 50.0, "NDIRS rate should be reasonable, got {r}");
    }

    #[test]
    fn test_ndirs_npv_at_par_rate_near_zero() {
        let usd = usd_curve();
        let brl = brl_curve();
        let fxr = test_fx_rates();
        let ndirs = make_test_ndirs();

        // Get the par rate
        let par_rate = number_real(&ndirs.ndirs_rate(&usd, &brl, &brl, &fxr));

        // Rebuild NDIRS at par rate
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let schedule = Schedule::try_new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            Frequency::SemiAnnual,
            cal,
            Adjuster::ModifiedFollowing,
            None,
            None,
            None,
            StubInference::ShortFront,
        ).unwrap();

        let fixed_leg = FixedLeg::new(
            &schedule,
            par_rate,
            1_000_000.0,
            DayCountConvention::Act365F,
            "BRL".to_string(),
            None,
            Amortization::None,
        );
        let float_leg = FloatLeg::new(
            &schedule,
            0.0,
            -1_000_000.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            "BRL".to_string(),
            None,
            Amortization::None,
        );
        let ndirs_par = InterestRateSwap::new_ndirs(
            fixed_leg,
            float_leg,
            "USD".to_string(),
            FXPair::new("usd", "brl"),
            None,
        );

        let npv = ndirs_par.ndirs_npv(&usd, &brl, &brl, &fxr);
        let v = number_real(&npv);
        assert!(
            v.abs() < 1e-4,
            "NDIRS NPV at par rate should be ~0, got {v}"
        );
    }

    #[test]
    fn test_ndirs_cashflows_have_settlement_fields() {
        let usd = usd_curve();
        let brl = brl_curve();
        let fxr = test_fx_rates();
        let ndirs = make_test_ndirs();

        let rows = ndirs.ndirs_cashflows(
            Some(&usd), Some(&brl), Some(&brl), Some(&fxr),
        );
        assert!(!rows.is_empty(), "Should have cashflow rows");

        for row in &rows {
            assert!(
                row.settlement_amount.is_some(),
                "settlement_amount should be Some for NDIRS"
            );
            assert!(
                row.fx_rate.is_some(),
                "fx_rate should be Some for NDIRS"
            );
            assert_eq!(
                row.settlement_currency_label.as_deref(),
                Some("USD"),
                "settlement_currency_label should be 'USD'"
            );
            // FX rate should be positive and reasonable (around 5.0 for USDBRL)
            let fx = row.fx_rate.unwrap();
            assert!(fx > 0.0 && fx < 100.0, "FX rate should be reasonable, got {fx}");
        }
    }

    #[test]
    fn test_ndirs_spread_returns_finite() {
        let usd = usd_curve();
        let brl = brl_curve();
        let fxr = test_fx_rates();
        let ndirs = make_test_ndirs();

        let spread = ndirs.ndirs_spread(&usd, &brl, &brl, &fxr);
        let s = number_real(&spread);
        assert!(s.is_finite(), "NDIRS spread should be finite, got {s}");
    }

    #[test]
    fn test_ndirs_serde_backward_compat() {
        // Serialize a plain IRS (no ND fields), deserialize, verify it works
        let irs = make_test_irs();
        let json = serde_json::to_string(&irs).unwrap();
        let deserialized: InterestRateSwap = serde_json::from_str(&json).unwrap();
        assert!(!deserialized.is_ndirs(), "Plain IRS should not be NDIRS");
        assert!(deserialized.settlement_currency.is_none());
        assert!(deserialized.pair.is_none());
        assert!(deserialized.fx_fixings.is_none());
    }

    #[test]
    fn test_ndirs_is_ndirs_helper() {
        let irs = make_test_irs();
        assert!(!irs.is_ndirs(), "Plain IRS should return false");

        let ndirs = make_test_ndirs();
        assert!(ndirs.is_ndirs(), "NDIRS should return true");
    }

    #[test]
    fn test_ndirs_different_curves_different_result() {
        // Using the same curve for everything should give a different result
        // than using different USD/BRL curves -- proves 3-curve model matters
        let usd = usd_curve();
        let brl = brl_curve();
        let fxr = test_fx_rates();
        let ndirs = make_test_ndirs();

        let rate_3curve = number_real(&ndirs.ndirs_rate(&usd, &brl, &brl, &fxr));
        let rate_1curve = number_real(&ndirs.ndirs_rate(&usd, &usd, &usd, &fxr));

        assert!(
            (rate_3curve - rate_1curve).abs() > 0.1,
            "3-curve and 1-curve rates should differ materially: 3c={rate_3curve}, 1c={rate_1curve}"
        );
    }
}
