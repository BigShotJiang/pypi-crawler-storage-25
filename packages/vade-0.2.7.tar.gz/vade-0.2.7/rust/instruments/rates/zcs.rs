use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::cashflows::leg::{ZeroFixedLeg, ZeroFloatLeg};
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;

/// Zero Coupon Swap: ZeroFixedLeg + ZeroFloatLeg.
///
/// Single-period swap with compounded fixed rate vs compounded floating rate.
#[derive(Clone, Serialize, Deserialize)]
pub struct ZeroCouponSwap {
    pub fixed_leg: ZeroFixedLeg,
    pub float_leg: ZeroFloatLeg,
}

impl ZeroCouponSwap {
    /// Construct from pre-built zero-coupon legs.
    pub fn new(fixed_leg: ZeroFixedLeg, float_leg: ZeroFloatLeg) -> Self {
        Self { fixed_leg, float_leg }
    }

    /// Par rate: the compounded fixed rate that makes NPV = 0.
    ///
    /// rate = float_npv / (fixed_analytic_delta * (-100.0))
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let float_npv = self.float_leg.npv(forecast_curve, None);
        let fixed_ad = self.fixed_leg.analytic_delta(disc_curve);
        &float_npv / &(&fixed_ad * (-100.0))
    }

    /// NPV = fixed_leg_npv + float_leg_npv.
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let fixed_npv = self.fixed_leg.npv(disc_curve);
        let float_npv = self.float_leg.npv(forecast_curve, None);
        fixed_npv + float_npv
    }

    /// Fixed leg NPV only.
    pub fn fixed_leg_npv(&self, disc_curve: &dyn CurveQuery) -> Number {
        self.fixed_leg.npv(disc_curve)
    }

    /// Float leg NPV only.
    pub fn float_leg_npv(&self, forecast_curve: &dyn CurveQuery) -> Number {
        self.float_leg.npv(forecast_curve, None)
    }

    /// Cashflow rows from both legs.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        forecast_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        let mut rows = self.fixed_leg.cashflows(disc_curve);
        rows.extend(self.float_leg.cashflows(forecast_curve, None));
        rows.sort_by_key(|r| r.payment);
        rows
    }

    /// Spread: same as rate for ZCS.
    pub fn spread(
        &self,
        disc_curve: &dyn CurveQuery,
        forecast_curve: &dyn CurveQuery,
    ) -> Number {
        self.rate(disc_curve, forecast_curve)
    }

    /// Pillar date: end date of the swap.
    pub fn pillar_date(&self) -> NaiveDate {
        self.float_leg.period.end
    }
}

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::cashflows::fixing::{FixingMethod, SpreadMethod};
    use crate::calendar::convention::DayCountConvention;
    use crate::calendar::cal::BusinessCalendar;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.97),
            (ymd(2026, 1, 1), 0.94),
            (ymd(2027, 1, 1), 0.91),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    pub fn make_test_zcs() -> ZeroCouponSwap {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let fixed_leg = ZeroFixedLeg::new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            ymd(2026, 1, 1),
            3.0, // 3% compounded rate
            1_000_000.0,
            DayCountConvention::Act365F,
            "USD".to_string(),
        );
        let float_leg = ZeroFloatLeg::new(
            ymd(2024, 1, 1),
            ymd(2026, 1, 1),
            ymd(2026, 1, 1),
            -1_000_000.0,
            0.0,
            DayCountConvention::Act365F,
            FixingMethod::RFRPaymentDelay,
            SpreadMethod::NoneSimple,
            cal,
            "USD".to_string(),
        );
        ZeroCouponSwap::new(fixed_leg, float_leg)
    }

    #[test]
    fn test_zcs_rate() {
        let curve = test_curve();
        let zcs = make_test_zcs();
        let rate = zcs.rate(&curve, &curve);
        if let Number::F64(r) = rate {
            assert!(r.is_finite(), "ZCS rate should be finite, got {r}");
            assert!(r > 0.0, "ZCS rate should be positive, got {r}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_zcs_npv() {
        let curve = test_curve();
        let zcs = make_test_zcs();
        let npv = zcs.npv(&curve, &curve);
        if let Number::F64(v) = npv {
            assert!(v.is_finite(), "ZCS NPV should be finite, got {v}");
        } else {
            panic!("Expected F64");
        }
    }

    #[test]
    fn test_zcs_pillar_date() {
        let zcs = make_test_zcs();
        assert_eq!(zcs.pillar_date(), ymd(2026, 1, 1));
    }

    #[test]
    fn test_zcs_cashflows() {
        let curve = test_curve();
        let zcs = make_test_zcs();
        let rows = zcs.cashflows(Some(&curve), Some(&curve));
        assert!(!rows.is_empty(), "ZCS should have cashflow rows");
    }
}
