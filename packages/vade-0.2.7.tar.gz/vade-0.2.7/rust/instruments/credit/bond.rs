use std::collections::HashMap;
use chrono::NaiveDate;
use serde::{Serialize, Deserialize};

use crate::autodiff::enums::Number;
use crate::calendar::adjuster::Adjuster;
use crate::calendar::cal::BusinessCalendar;
use crate::calendar::convention::{DayCountConvention, DcfOptions};
use crate::calendar::dateroll::add_business_days;
use crate::calendar::frequency::Frequency;
use crate::calendar::schedule::{Schedule, StubInference};
use crate::cashflows::period::CashflowRow;
use crate::marketcurves::curve::CurveQuery;
use crate::models::black::{black76_caplet, bachelier_caplet, VolModel};
use crate::numerical::brent;
use crate::numerical::compounding;

// ---------------------------------------------------------------------------
// Data structs
// ---------------------------------------------------------------------------

/// A coupon period for a fixed-rate bond.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BondCouponPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub dcf: f64, // precomputed day count fraction
}

/// A coupon period for a floating-rate note.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BondFloatPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub dcf: f64,
    pub fixing_rate: Option<f64>, // known fixing or None for forward
}

// ---------------------------------------------------------------------------
// BondVariant
// ---------------------------------------------------------------------------

/// The bond variants: fixed-rate, bill, floating-rate note, zero-coupon, step-up.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum BondVariant {
    FixedRate(FixedRateBondData),
    Bill(BillData),
    FloatRateNote(FloatRateNoteData),
    ZeroCoupon(ZeroCouponBondData),
    StepUp(StepUpBondData),
    Amortizing(AmortizingBondData),
    PIK(PIKBondData),
    SubPeriodFRN(SubPeriodFRNData),
    CappedFloored(CappedFlooredData),
}

/// Data for a fixed-rate bond.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FixedRateBondData {
    pub coupon: f64,          // annual coupon rate as decimal (0.04 = 4%)
    pub frequency: Frequency, // coupon frequency
    pub periods: Vec<BondCouponPeriod>,
}

/// Data for a zero-coupon bill.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BillData {
    pub maturity: NaiveDate,
    pub face_value: f64,
}

/// Data for a floating-rate note.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FloatRateNoteData {
    pub spread: f64,           // spread over index rate as decimal
    pub frequency: Frequency,
    pub periods: Vec<BondFloatPeriod>,
    /// Business days before accrual start for rate fixing (default 2 for EURIBOR/LIBOR).
    pub fixing_lag: i32,
}

/// Data for a zero-coupon bond (distinct from Bill: uses compound discounting, OID accrued).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ZeroCouponBondData {
    pub issue_price: f64,
    pub frequency: Frequency,
}

/// A coupon period for a step-up bond (varying coupon rate per period).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct StepUpCouponPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub dcf: f64,
    pub coupon_rate: f64,
}

/// Data for a step-up bond with per-period varying coupon rates.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct StepUpBondData {
    pub frequency: Frequency,
    pub periods: Vec<StepUpCouponPeriod>,
}

/// A coupon period for an amortizing bond (declining notional with principal repayments).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct AmortizingCouponPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub dcf: f64,
    pub notional: f64,            // remaining notional at start of this period
    pub principal_repayment: f64,  // principal repaid at end of this period (0.0 if none)
    pub coupon_rate: f64,          // fixed coupon rate (same every period)
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct AmortizingBondData {
    pub coupon: f64,
    pub frequency: Frequency,
    pub periods: Vec<AmortizingCouponPeriod>,
    pub final_redemption: f64,  // face_value - sum(principal_repayments)
}

/// A coupon period for a PIK bond (growing notional via interest compounding).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PIKCouponPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub dcf: f64,
    pub notional: f64,      // notional at start of this period
    pub coupon_rate: f64,
    pub pik_fraction: f64,  // fraction that compounds (same all periods per D-08)
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PIKBondData {
    pub coupon: f64,
    pub frequency: Frequency,
    pub pik_fraction: f64,
    pub periods: Vec<PIKCouponPeriod>,
    pub final_notional: f64,  // grown notional at maturity for redemption
}

/// A sub-period within a coupon period for sub-period FRN.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SubPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub dcf: f64,
    pub fixing_rate: Option<f64>,
}

/// A coupon period for a sub-period FRN containing multiple sub-periods.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SubPeriodCouponPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub sub_periods: Vec<SubPeriod>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SubPeriodFRNData {
    pub spread: f64,
    pub frequency: Frequency,
    pub fixing_frequency: Frequency,
    pub periods: Vec<SubPeriodCouponPeriod>,
}

/// A coupon period for a capped/floored FRN. Can be standard (single fixing) or sub-period.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CappedFlooredCouponPeriod {
    pub start: NaiveDate,
    pub end: NaiveDate,
    pub payment: NaiveDate,
    pub dcf: f64,                        // overall period dcf
    pub sub_periods: Option<Vec<SubPeriod>>,  // None = standard FRN, Some = sub-period
    pub fixing_rate: Option<f64>,         // for standard FRN (no sub-periods)
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CappedFlooredData {
    pub spread: f64,
    pub frequency: Frequency,
    pub fixing_frequency: Option<Frequency>,
    pub cap_rate: Option<f64>,     // decimal (0.05 = 5%)
    pub floor_rate: Option<f64>,   // decimal (0.01 = 1%)
    pub vol: f64,                  // flat scalar vol (decimal)
    pub vol_model: VolModel,
    pub periods: Vec<CappedFlooredCouponPeriod>,
}

// ---------------------------------------------------------------------------
// Cashflow types (Phase 19: cashflow-driven analytics)
// ---------------------------------------------------------------------------

/// Kind of bond cashflow: coupon payment or principal redemption.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum CashflowKind {
    Coupon,
    Redemption,
    Principal,    // amortizing bond principal repayment (D-09)
    PIKAccrual,   // non-cash PIK notional growth, informational only (D-10)
}

/// A minimal bond cashflow: payment date, amount (AD-aware), and kind.
#[derive(Clone, Debug)]
pub struct BondCashflow {
    pub payment: NaiveDate,
    pub amount: Number,
    pub kind: CashflowKind,
}

/// Compute compounded rate from sub-periods using forward rates from curve.
/// Per D-01: coupon = Product(1 + r_i * dcf_i) - 1
/// Per D-04: spread applied after compounding
fn compounded_sub_period_rate(
    sub_periods: &[SubPeriod],
    curve: Option<&dyn CurveQuery>,
    spread: f64,
) -> f64 {
    let mut product = 1.0;
    for sp in sub_periods {
        let rate = sp.fixing_rate.unwrap_or_else(|| {
            let c = curve.expect("SubPeriodFRN needs curve for unfixed forward rates");
            let fwd = c.forward_rate(sp.start, sp.end);
            match fwd {
                Number::F64(r) => r,
                Number::Dual(d) => d.real,
                Number::Dual2(d) => d.real,
            }
        });
        product *= 1.0 + rate * sp.dcf;
    }
    (product - 1.0) + spread
}

impl BondVariant {
    /// Find the accrual period (start, end) that contains `settlement`.
    ///
    /// Uses binary search on the sorted period `end` dates: O(log n).
    /// Returns `None` for Bill (no coupon) or if settlement falls outside
    /// all periods.
    fn find_accrual_period(&self, settlement: NaiveDate) -> Option<(NaiveDate, NaiveDate)> {
        macro_rules! bsearch_periods {
            ($periods:expr) => {{
                let idx = $periods.partition_point(|p| p.end <= settlement);
                if idx < $periods.len() && settlement >= $periods[idx].start {
                    return Some(($periods[idx].start, $periods[idx].end));
                }
            }};
        }
        match self {
            BondVariant::FixedRate(d) => { bsearch_periods!(&d.periods); }
            BondVariant::FloatRateNote(d) => { bsearch_periods!(&d.periods); }
            BondVariant::StepUp(d) => { bsearch_periods!(&d.periods); }
            BondVariant::Amortizing(d) => { bsearch_periods!(&d.periods); }
            BondVariant::PIK(d) => { bsearch_periods!(&d.periods); }
            BondVariant::SubPeriodFRN(d) => { bsearch_periods!(&d.periods); }
            BondVariant::CappedFloored(d) => { bsearch_periods!(&d.periods); }
            BondVariant::Bill(_) | BondVariant::ZeroCoupon(_) => {}
        }
        None
    }

    /// Find the index of the period containing `settlement` via binary search.
    /// Returns `None` if settlement falls outside all periods.
    fn find_period_index(&self, settlement: NaiveDate) -> Option<usize> {
        macro_rules! bsearch {
            ($periods:expr) => {{
                let idx = $periods.partition_point(|p| p.end <= settlement);
                if idx < $periods.len() && settlement >= $periods[idx].start {
                    return Some(idx);
                }
            }};
        }
        match self {
            BondVariant::FixedRate(d) => { bsearch!(&d.periods); }
            BondVariant::FloatRateNote(d) => { bsearch!(&d.periods); }
            BondVariant::StepUp(d) => { bsearch!(&d.periods); }
            BondVariant::Amortizing(d) => { bsearch!(&d.periods); }
            BondVariant::PIK(d) => { bsearch!(&d.periods); }
            BondVariant::SubPeriodFRN(d) => { bsearch!(&d.periods); }
            BondVariant::CappedFloored(d) => { bsearch!(&d.periods); }
            BondVariant::Bill(_) | BondVariant::ZeroCoupon(_) => {}
        }
        None
    }

    /// Generate a uniform cashflow vector for any bond variant.
    ///
    /// Analytics methods consume this vector generically instead of
    /// per-variant match arms. The `curve` parameter is only needed
    /// for FloatRateNote (to compute forward rates for unfixed periods).
    pub fn bond_cashflows(
        &self,
        settlement: NaiveDate,
        face_value: f64,
        termination: NaiveDate,
        curve: Option<&dyn CurveQuery>,
    ) -> Vec<BondCashflow> {
        match self {
            BondVariant::FixedRate(data) => {
                let freq = data.frequency.periods_per_annum();
                let coupon_payment = data.coupon * face_value / freq;
                let mut cfs: Vec<BondCashflow> = data.periods.iter()
                    .filter(|p| p.payment > settlement)
                    .map(|p| BondCashflow {
                        payment: p.payment,
                        amount: Number::F64(coupon_payment),
                        kind: CashflowKind::Coupon,
                    })
                    .collect();
                if termination > settlement {
                    cfs.push(BondCashflow {
                        payment: termination,
                        amount: Number::F64(face_value),
                        kind: CashflowKind::Redemption,
                    });
                }
                cfs
            }
            BondVariant::Bill(_) => {
                if termination > settlement {
                    vec![BondCashflow {
                        payment: termination,
                        amount: Number::F64(face_value),
                        kind: CashflowKind::Redemption,
                    }]
                } else {
                    vec![]
                }
            }
            BondVariant::FloatRateNote(data) => {
                let mut cfs: Vec<BondCashflow> = data.periods.iter()
                    .filter(|p| p.payment > settlement)
                    .map(|p| {
                        let rate = p.fixing_rate.unwrap_or_else(|| {
                            let curve = curve.expect("FRN needs curve for forward rates");
                            let fwd = curve.forward_rate(p.start, p.end);
                            match fwd {
                                Number::F64(r) => r + data.spread,
                                Number::Dual(d) => d.real + data.spread,
                                Number::Dual2(d) => d.real + data.spread,
                            }
                        });
                        BondCashflow {
                            payment: p.payment,
                            amount: Number::F64(rate * face_value * p.dcf),
                            kind: CashflowKind::Coupon,
                        }
                    })
                    .collect();
                if termination > settlement {
                    cfs.push(BondCashflow {
                        payment: termination,
                        amount: Number::F64(face_value),
                        kind: CashflowKind::Redemption,
                    });
                }
                cfs
            }
            BondVariant::ZeroCoupon(_) => {
                // Single redemption cashflow at termination (identical to Bill)
                if termination > settlement {
                    vec![BondCashflow {
                        payment: termination,
                        amount: Number::F64(face_value),
                        kind: CashflowKind::Redemption,
                    }]
                } else {
                    vec![]
                }
            }
            BondVariant::StepUp(data) => {
                let freq = data.frequency.periods_per_annum();
                let mut cfs: Vec<BondCashflow> = data.periods.iter()
                    .filter(|p| p.payment > settlement)
                    .map(|p| BondCashflow {
                        payment: p.payment,
                        amount: Number::F64(p.coupon_rate * face_value / freq),
                        kind: CashflowKind::Coupon,
                    })
                    .collect();
                if termination > settlement {
                    cfs.push(BondCashflow {
                        payment: termination,
                        amount: Number::F64(face_value),
                        kind: CashflowKind::Redemption,
                    });
                }
                cfs
            }
            BondVariant::Amortizing(data) => {
                let mut cfs = Vec::new();
                for p in &data.periods {
                    if p.payment > settlement {
                        // Coupon on remaining notional (D-04: dcf-based)
                        let coupon_amount = p.coupon_rate * p.notional * p.dcf;
                        cfs.push(BondCashflow {
                            payment: p.payment,
                            amount: Number::F64(coupon_amount),
                            kind: CashflowKind::Coupon,
                        });
                        // Principal repayment (if any)
                        if p.principal_repayment > 0.0 {
                            cfs.push(BondCashflow {
                                payment: p.payment,
                                amount: Number::F64(p.principal_repayment),
                                kind: CashflowKind::Principal,
                            });
                        }
                    }
                }
                // Final redemption (remainder)
                if termination > settlement {
                    cfs.push(BondCashflow {
                        payment: termination,
                        amount: Number::F64(data.final_redemption),
                        kind: CashflowKind::Redemption,
                    });
                }
                cfs
            }
            BondVariant::PIK(data) => {
                let mut cfs = Vec::new();
                for p in &data.periods {
                    if p.payment > settlement {
                        // Cash coupon = (1 - pik_fraction) portion (D-11: PIKAccrual excluded)
                        let total_interest = p.coupon_rate * p.notional * p.dcf;
                        let cash_coupon = total_interest * (1.0 - p.pik_fraction);
                        if cash_coupon > 0.0 {
                            cfs.push(BondCashflow {
                                payment: p.payment,
                                amount: Number::F64(cash_coupon),
                                kind: CashflowKind::Coupon,
                            });
                        }
                    }
                }
                // Final redemption at grown notional
                if termination > settlement {
                    cfs.push(BondCashflow {
                        payment: termination,
                        amount: Number::F64(data.final_notional),
                        kind: CashflowKind::Redemption,
                    });
                }
                cfs
            }
            BondVariant::SubPeriodFRN(data) => {
                let mut cfs = Vec::new();
                for period in &data.periods {
                    if period.payment > settlement {
                        let compounded_rate = compounded_sub_period_rate(
                            &period.sub_periods, curve, data.spread,
                        );
                        let period_dcf: f64 = period.sub_periods.iter().map(|sp| sp.dcf).sum();
                        let cashflow = compounded_rate * face_value * period_dcf;
                        cfs.push(BondCashflow {
                            payment: period.payment,
                            amount: Number::F64(cashflow),
                            kind: CashflowKind::Coupon,
                        });
                    }
                }
                if termination > settlement {
                    cfs.push(BondCashflow {
                        payment: termination,
                        amount: Number::F64(face_value),
                        kind: CashflowKind::Redemption,
                    });
                }
                cfs
            }
            BondVariant::CappedFloored(data) => {
                let act365f = DayCountConvention::Act365F;
                let mut cfs = Vec::new();
                for period in &data.periods {
                    if period.payment > settlement {
                        // Compute effective rate (compounded if sub-period, simple if standard)
                        let effective_rate = if let Some(ref sub_periods) = period.sub_periods {
                            compounded_sub_period_rate(sub_periods, curve, data.spread)
                        } else {
                            let rate = period.fixing_rate.unwrap_or_else(|| {
                                let c = curve.expect("CappedFloored needs curve for forward rates");
                                let fwd = c.forward_rate(period.start, period.end);
                                match fwd {
                                    Number::F64(r) => r,
                                    Number::Dual(d) => d.real,
                                    Number::Dual2(d) => d.real,
                                }
                            });
                            rate + data.spread
                        };

                        // Time-to-expiry for Black-76/Bachelier (per Pitfall 3: from settlement)
                        let t = act365f.dcf(settlement, period.start, &DcfOptions::default()).unwrap_or(0.0);

                        let mut adjusted_rate = effective_rate;
                        if t > 0.0 {
                            // Future period: option pricing
                            if let Some(cap) = data.cap_rate {
                                let caplet = match data.vol_model {
                                    VolModel::Black76 => black76_caplet(
                                        &Number::F64(effective_rate), cap, data.vol, t, true,
                                    ),
                                    VolModel::Bachelier => bachelier_caplet(
                                        &Number::F64(effective_rate), cap, data.vol, t, true,
                                    ),
                                };
                                let caplet_val = match caplet {
                                    Number::F64(v) => v,
                                    Number::Dual(d) => d.real,
                                    Number::Dual2(d) => d.real,
                                };
                                adjusted_rate -= caplet_val;
                            }
                            if let Some(floor) = data.floor_rate {
                                let floorlet = match data.vol_model {
                                    VolModel::Black76 => black76_caplet(
                                        &Number::F64(effective_rate), floor, data.vol, t, false,
                                    ),
                                    VolModel::Bachelier => bachelier_caplet(
                                        &Number::F64(effective_rate), floor, data.vol, t, false,
                                    ),
                                };
                                let floorlet_val = match floorlet {
                                    Number::F64(v) => v,
                                    Number::Dual(d) => d.real,
                                    Number::Dual2(d) => d.real,
                                };
                                adjusted_rate += floorlet_val;
                            }
                        } else {
                            // Past/current period: intrinsic cap/floor
                            if let Some(cap) = data.cap_rate {
                                adjusted_rate = adjusted_rate.min(cap);
                            }
                            if let Some(floor) = data.floor_rate {
                                adjusted_rate = adjusted_rate.max(floor);
                            }
                        }

                        let cashflow = adjusted_rate * face_value * period.dcf;
                        cfs.push(BondCashflow {
                            payment: period.payment,
                            amount: Number::F64(cashflow),
                            kind: CashflowKind::Coupon,
                        });
                    }
                }
                if termination > settlement {
                    cfs.push(BondCashflow {
                        payment: termination,
                        amount: Number::F64(face_value),
                        kind: CashflowKind::Redemption,
                    });
                }
                cfs
            }
        }
    }

    /// Coupon frequency as periods per annum.
    pub fn frequency(&self) -> f64 {
        match self {
            BondVariant::FixedRate(d) => d.frequency.periods_per_annum(),
            BondVariant::Bill(_) => 1.0,
            BondVariant::FloatRateNote(d) => d.frequency.periods_per_annum(),
            BondVariant::ZeroCoupon(d) => d.frequency.periods_per_annum(),
            BondVariant::StepUp(d) => d.frequency.periods_per_annum(),
            BondVariant::Amortizing(d) => d.frequency.periods_per_annum(),
            BondVariant::PIK(d) => d.frequency.periods_per_annum(),
            BondVariant::SubPeriodFRN(d) => d.frequency.periods_per_annum(),
            BondVariant::CappedFloored(d) => d.frequency.periods_per_annum(),
        }
    }
}

// ---------------------------------------------------------------------------
// BondInstrument
// ---------------------------------------------------------------------------

/// Bond instrument supporting fixed-rate bonds, bills, and floating-rate notes.
///
/// Provides full analytics: clean/dirty price, accrued interest, YTM,
/// duration, convexity, DV01, Z-spread, ASW spread, CS01.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BondInstrument {
    pub variant: BondVariant,
    pub effective: NaiveDate,
    pub termination: NaiveDate,
    pub settlement_days: i32,
    pub ex_div_days: i32,
    pub calendar: BusinessCalendar,
    pub currency: String,
    pub convention: DayCountConvention,
    pub accrued_convention: DayCountConvention,
    pub face_value: f64,
    pub modifier: Adjuster,
    /// Evaluation date used as default settlement for all analytics.
    /// Set to today at construction from Python; methods use this when
    /// no explicit settlement is passed.
    pub eval_date: NaiveDate,
}

impl BondInstrument {
    /// Construct a fixed-rate bond, generating the coupon schedule internally.
    pub fn new_fixed_rate(
        effective: NaiveDate,
        termination: NaiveDate,
        coupon: f64,
        frequency: Frequency,
        settlement_days: i32,
        ex_div_days: i32,
        calendar: BusinessCalendar,
        currency: String,
        convention: DayCountConvention,
        accrued_convention: DayCountConvention,
        face_value: f64,
        modifier: Adjuster,
    ) -> Self {
        let schedule = Schedule::try_new(
            effective,
            termination,
            frequency,
            calendar.clone(),
            modifier,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .expect("Failed to generate bond schedule");

        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();
        let periods: Vec<BondCouponPeriod> = (0..n)
            .map(|i| {
                let dcf = convention
                    .dcf(dates[i], dates[i + 1], &DcfOptions::default())
                    .unwrap();
                BondCouponPeriod {
                    start: dates[i],
                    end: dates[i + 1],
                    payment: dates[i + 1],
                    dcf,
                }
            })
            .collect();

        BondInstrument {
            variant: BondVariant::FixedRate(FixedRateBondData {
                coupon,
                frequency,
                periods,
            }),
            effective,
            termination,
            settlement_days,
            ex_div_days,
            calendar,
            currency,
            convention,
            accrued_convention,
            face_value,
            modifier,
            eval_date: effective,
        }
    }

    /// Construct a zero-coupon bill.
    pub fn new_bill(
        effective: NaiveDate,
        termination: NaiveDate,
        settlement_days: i32,
        calendar: BusinessCalendar,
        currency: String,
        convention: DayCountConvention,
        face_value: f64,
    ) -> Self {
        BondInstrument {
            variant: BondVariant::Bill(BillData {
                maturity: termination,
                face_value,
            }),
            effective,
            termination,
            settlement_days,
            ex_div_days: 0,
            calendar,
            currency,
            convention,
            accrued_convention: convention,
            face_value,
            modifier: Adjuster::Following,
            eval_date: effective,
        }
    }

    /// Construct a floating-rate note.
    pub fn new_float_rate_note(
        effective: NaiveDate,
        termination: NaiveDate,
        spread: f64,
        frequency: Frequency,
        settlement_days: i32,
        ex_div_days: i32,
        calendar: BusinessCalendar,
        currency: String,
        convention: DayCountConvention,
        accrued_convention: DayCountConvention,
        face_value: f64,
        modifier: Adjuster,
    ) -> Self {
        let schedule = Schedule::try_new(
            effective,
            termination,
            frequency,
            calendar.clone(),
            modifier,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .expect("Failed to generate FRN schedule");

        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();
        let periods: Vec<BondFloatPeriod> = (0..n)
            .map(|i| {
                let dcf = convention
                    .dcf(dates[i], dates[i + 1], &DcfOptions::default())
                    .unwrap();
                BondFloatPeriod {
                    start: dates[i],
                    end: dates[i + 1],
                    payment: dates[i + 1],
                    dcf,
                    fixing_rate: None,
                }
            })
            .collect();

        BondInstrument {
            variant: BondVariant::FloatRateNote(FloatRateNoteData {
                spread,
                frequency,
                periods,
                fixing_lag: 2, // default: T-2 (standard IBOR convention)
            }),
            effective,
            termination,
            settlement_days,
            ex_div_days,
            calendar,
            currency,
            convention,
            accrued_convention,
            face_value,
            modifier,
            eval_date: effective,
        }
    }

    /// Construct a zero-coupon bond (compound discounting, OID accrued interest).
    pub fn new_zero_coupon(
        effective: NaiveDate,
        termination: NaiveDate,
        issue_price: f64,
        frequency: Frequency,
        settlement_days: i32,
        calendar: BusinessCalendar,
        currency: String,
        convention: DayCountConvention,
        face_value: f64,
    ) -> Self {
        BondInstrument {
            variant: BondVariant::ZeroCoupon(ZeroCouponBondData {
                issue_price,
                frequency,
            }),
            effective,
            termination,
            settlement_days,
            ex_div_days: 0,
            calendar,
            currency,
            convention,
            accrued_convention: convention,
            face_value,
            modifier: Adjuster::Actual,
            eval_date: effective,
        }
    }

    /// Construct a step-up bond with per-period varying coupon rates.
    ///
    /// `coupon_rates` is a list of (date, rate) pairs. For each schedule period,
    /// the applicable rate is the last dated rate whose date <= period start (D-09 logic).
    pub fn new_step_up(
        effective: NaiveDate,
        termination: NaiveDate,
        mut coupon_rates: Vec<(NaiveDate, f64)>,
        frequency: Frequency,
        settlement_days: i32,
        ex_div_days: i32,
        calendar: BusinessCalendar,
        currency: String,
        convention: DayCountConvention,
        accrued_convention: DayCountConvention,
        face_value: f64,
        modifier: Adjuster,
    ) -> Self {
        // Sort dated rates by date ascending
        coupon_rates.sort_by_key(|(d, _)| *d);

        let schedule = Schedule::try_new(
            effective,
            termination,
            frequency,
            calendar.clone(),
            modifier,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .expect("Failed to generate step-up bond schedule");

        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();
        let periods: Vec<StepUpCouponPeriod> = (0..n)
            .map(|i| {
                let period_start = dates[i];
                let period_end = dates[i + 1];
                let dcf = convention
                    .dcf(period_start, period_end, &DcfOptions::default())
                    .unwrap();
                // D-09: find applicable rate -- last dated_rate where date <= period_start
                let coupon_rate = coupon_rates
                    .iter()
                    .filter(|(d, _)| *d <= period_start)
                    .last()
                    .map(|(_, r)| *r)
                    .unwrap_or(0.0);
                StepUpCouponPeriod {
                    start: period_start,
                    end: period_end,
                    payment: period_end,
                    dcf,
                    coupon_rate,
                }
            })
            .collect();

        BondInstrument {
            variant: BondVariant::StepUp(StepUpBondData {
                frequency,
                periods,
            }),
            effective,
            termination,
            settlement_days,
            ex_div_days,
            calendar,
            currency,
            convention,
            accrued_convention,
            face_value,
            modifier,
            eval_date: effective,
        }
    }

    /// Construct an amortizing bond with declining notional and principal repayments.
    ///
    /// `amortization_schedule`: dated amount pairs `(date, principal_repayment_amount)`.
    /// Dates must coincide with coupon payment dates (D-02).
    /// Remainder at maturity = face_value - sum(repayments) (D-03).
    pub fn new_amortizing(
        effective: NaiveDate,
        termination: NaiveDate,
        coupon: f64,
        mut amortization_schedule: Vec<(NaiveDate, f64)>,
        frequency: Frequency,
        settlement_days: i32,
        ex_div_days: i32,
        calendar: BusinessCalendar,
        currency: String,
        convention: DayCountConvention,
        accrued_convention: DayCountConvention,
        face_value: f64,
        modifier: Adjuster,
    ) -> Self {
        // Sort amortization schedule by date (D-01)
        amortization_schedule.sort_by_key(|(d, _)| *d);

        let schedule = Schedule::try_new(
            effective,
            termination,
            frequency,
            calendar.clone(),
            modifier,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .expect("Failed to generate amortizing bond schedule");

        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();
        let mut remaining_notional = face_value;
        let mut periods = Vec::with_capacity(n);

        for i in 0..n {
            let period_start = dates[i];
            let period_end = dates[i + 1];
            let dcf = convention
                .dcf(period_start, period_end, &DcfOptions::default())
                .unwrap();
            // Check if any amortization date matches this period end (D-02)
            let principal_repayment = amortization_schedule
                .iter()
                .filter(|(d, _)| *d == period_end)
                .map(|(_, amt)| *amt)
                .sum::<f64>();

            periods.push(AmortizingCouponPeriod {
                start: period_start,
                end: period_end,
                payment: period_end,
                dcf,
                notional: remaining_notional,
                principal_repayment,
                coupon_rate: coupon,
            });

            remaining_notional -= principal_repayment;
        }

        let final_redemption = remaining_notional; // D-03: remainder redeems at maturity

        BondInstrument {
            variant: BondVariant::Amortizing(AmortizingBondData {
                coupon,
                frequency,
                periods,
                final_redemption,
            }),
            effective,
            termination,
            settlement_days,
            ex_div_days,
            calendar,
            currency,
            convention,
            accrued_convention,
            face_value,
            modifier,
            eval_date: effective,
        }
    }

    /// Construct a PIK bond with growing notional via interest compounding.
    ///
    /// `pik_fraction`: fraction of interest that compounds into notional (0.0-1.0).
    /// 1.0 = full PIK, 0.0 = regular fixed-rate bond, 0.5 = half PIK (D-07).
    /// PIK rate = coupon rate (D-06). pik_fraction is constant across all periods (D-08).
    pub fn new_pik(
        effective: NaiveDate,
        termination: NaiveDate,
        coupon: f64,
        pik_fraction: f64,
        frequency: Frequency,
        settlement_days: i32,
        ex_div_days: i32,
        calendar: BusinessCalendar,
        currency: String,
        convention: DayCountConvention,
        accrued_convention: DayCountConvention,
        face_value: f64,
        modifier: Adjuster,
    ) -> Self {
        let schedule = Schedule::try_new(
            effective,
            termination,
            frequency,
            calendar.clone(),
            modifier,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .expect("Failed to generate PIK bond schedule");

        let dates = schedule.adjusted_dates();
        let n = schedule.n_periods();
        let mut notional = face_value;
        let mut periods = Vec::with_capacity(n);

        for i in 0..n {
            let period_start = dates[i];
            let period_end = dates[i + 1];
            let dcf = convention
                .dcf(period_start, period_end, &DcfOptions::default())
                .unwrap();

            periods.push(PIKCouponPeriod {
                start: period_start,
                end: period_end,
                payment: period_end,
                dcf,
                notional,
                coupon_rate: coupon,
                pik_fraction,
            });

            // D-05: N_{i+1} = N_i + coupon_rate * N_i * dcf_i * pik_fraction
            let pik_interest = coupon * notional * dcf * pik_fraction;
            notional += pik_interest;
        }

        let final_notional = notional;

        BondInstrument {
            variant: BondVariant::PIK(PIKBondData {
                coupon,
                frequency,
                pik_fraction,
                periods,
                final_notional,
            }),
            effective,
            termination,
            settlement_days,
            ex_div_days,
            calendar,
            currency,
            convention,
            accrued_convention,
            face_value,
            modifier,
            eval_date: effective,
        }
    }

    /// Construct a sub-period floating-rate note.
    ///
    /// Generates a coupon schedule at `frequency` and within each coupon period,
    /// generates a sub-period schedule at `fixing_frequency`.
    pub fn new_sub_period_frn(
        effective: NaiveDate,
        termination: NaiveDate,
        spread: f64,
        frequency: Frequency,
        fixing_frequency: Frequency,
        settlement_days: i32,
        ex_div_days: i32,
        calendar: BusinessCalendar,
        currency: String,
        convention: DayCountConvention,
        accrued_convention: DayCountConvention,
        face_value: f64,
        modifier: Adjuster,
    ) -> Self {
        let coupon_schedule = Schedule::try_new(
            effective,
            termination,
            frequency,
            calendar.clone(),
            modifier,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .expect("Failed to generate coupon schedule");

        let coupon_dates = coupon_schedule.adjusted_dates();
        let n = coupon_schedule.n_periods();

        let periods: Vec<SubPeriodCouponPeriod> = (0..n)
            .map(|i| {
                let period_start = coupon_dates[i];
                let period_end = coupon_dates[i + 1];

                let sub_schedule = Schedule::try_new(
                    period_start,
                    period_end,
                    fixing_frequency,
                    calendar.clone(),
                    modifier,
                    None,
                    None,
                    None,
                    StubInference::ShortFront,
                )
                .expect("Failed to generate sub-period schedule");
                let sub_dates = sub_schedule.adjusted_dates();
                let sub_n = sub_schedule.n_periods();

                let sub_periods: Vec<SubPeriod> = (0..sub_n)
                    .map(|j| {
                        let s = sub_dates[j];
                        let e = sub_dates[j + 1];
                        let dcf = convention
                            .dcf(s, e, &DcfOptions::default())
                            .unwrap();
                        SubPeriod {
                            start: s,
                            end: e,
                            dcf,
                            fixing_rate: None,
                        }
                    })
                    .collect();

                SubPeriodCouponPeriod {
                    start: period_start,
                    end: period_end,
                    payment: period_end,
                    sub_periods,
                }
            })
            .collect();

        BondInstrument {
            variant: BondVariant::SubPeriodFRN(SubPeriodFRNData {
                spread,
                frequency,
                fixing_frequency,
                periods,
            }),
            effective,
            termination,
            settlement_days,
            ex_div_days,
            calendar,
            currency,
            convention,
            accrued_convention,
            face_value,
            modifier,
            eval_date: effective,
        }
    }

    /// Construct a capped/floored floating-rate note.
    ///
    /// At least one of `cap_rate` or `floor_rate` must be `Some`.
    /// If `fixing_frequency` is `Some` and differs from `frequency`,
    /// sub-period compounding is used per coupon period.
    pub fn new_capped_floored(
        effective: NaiveDate,
        termination: NaiveDate,
        spread: f64,
        frequency: Frequency,
        fixing_frequency: Option<Frequency>,
        cap_rate: Option<f64>,
        floor_rate: Option<f64>,
        vol: f64,
        vol_model: VolModel,
        settlement_days: i32,
        ex_div_days: i32,
        calendar: BusinessCalendar,
        currency: String,
        convention: DayCountConvention,
        accrued_convention: DayCountConvention,
        face_value: f64,
        modifier: Adjuster,
    ) -> Self {
        assert!(
            cap_rate.is_some() || floor_rate.is_some(),
            "CappedFloored requires at least one of cap_rate or floor_rate"
        );

        let coupon_schedule = Schedule::try_new(
            effective,
            termination,
            frequency,
            calendar.clone(),
            modifier,
            None,
            None,
            None,
            StubInference::ShortFront,
        )
        .expect("Failed to generate capped/floored coupon schedule");

        let coupon_dates = coupon_schedule.adjusted_dates();
        let n = coupon_schedule.n_periods();

        let use_sub_periods = fixing_frequency
            .map(|ff| ff != frequency)
            .unwrap_or(false);

        let periods: Vec<CappedFlooredCouponPeriod> = (0..n)
            .map(|i| {
                let period_start = coupon_dates[i];
                let period_end = coupon_dates[i + 1];
                let dcf = convention
                    .dcf(period_start, period_end, &DcfOptions::default())
                    .unwrap();

                let sub_periods = if use_sub_periods {
                    let ff = fixing_frequency.unwrap();
                    let sub_schedule = Schedule::try_new(
                        period_start,
                        period_end,
                        ff,
                        calendar.clone(),
                        modifier,
                        None,
                        None,
                        None,
                        StubInference::ShortFront,
                    )
                    .expect("Failed to generate sub-period schedule for capped/floored");
                    let sub_dates = sub_schedule.adjusted_dates();
                    let sub_n = sub_schedule.n_periods();
                    Some(
                        (0..sub_n)
                            .map(|j| {
                                let s = sub_dates[j];
                                let e = sub_dates[j + 1];
                                let sub_dcf = convention
                                    .dcf(s, e, &DcfOptions::default())
                                    .unwrap();
                                SubPeriod {
                                    start: s,
                                    end: e,
                                    dcf: sub_dcf,
                                    fixing_rate: None,
                                }
                            })
                            .collect(),
                    )
                } else {
                    None
                };

                CappedFlooredCouponPeriod {
                    start: period_start,
                    end: period_end,
                    payment: period_end,
                    dcf,
                    sub_periods,
                    fixing_rate: None,
                }
            })
            .collect();

        BondInstrument {
            variant: BondVariant::CappedFloored(CappedFlooredData {
                spread,
                frequency,
                fixing_frequency,
                cap_rate,
                floor_rate,
                vol,
                vol_model,
                periods,
            }),
            effective,
            termination,
            settlement_days,
            ex_div_days,
            calendar,
            currency,
            convention,
            accrued_convention,
            face_value,
            modifier,
            eval_date: effective,
        }
    }

    /// Sub-period schedule: returns detailed sub-period info for SubPeriodFRN and CappedFloored variants.
    ///
    /// Returns None for non-sub-period variants.
    /// For SubPeriodFRN: returns (period_start, period_end, payment, [(sub_start, sub_end, dcf, fixing_rate)]).
    /// For CappedFloored with sub-periods: same structure.
    pub fn sub_period_schedule(
        &self,
    ) -> Option<Vec<(NaiveDate, NaiveDate, NaiveDate, Vec<(NaiveDate, NaiveDate, f64, Option<f64>)>)>>
    {
        match &self.variant {
            BondVariant::SubPeriodFRN(data) => {
                Some(
                    data.periods
                        .iter()
                        .map(|p| {
                            let sub_info: Vec<(NaiveDate, NaiveDate, f64, Option<f64>)> = p
                                .sub_periods
                                .iter()
                                .map(|sp| (sp.start, sp.end, sp.dcf, sp.fixing_rate))
                                .collect();
                            (p.start, p.end, p.payment, sub_info)
                        })
                        .collect(),
                )
            }
            BondVariant::CappedFloored(data) => {
                // Only return sub-period info if any period has sub-periods
                let has_sub = data.periods.iter().any(|p| p.sub_periods.is_some());
                if !has_sub {
                    return None;
                }
                Some(
                    data.periods
                        .iter()
                        .map(|p| {
                            let sub_info: Vec<(NaiveDate, NaiveDate, f64, Option<f64>)> =
                                match &p.sub_periods {
                                    Some(sps) => sps
                                        .iter()
                                        .map(|sp| (sp.start, sp.end, sp.dcf, sp.fixing_rate))
                                        .collect(),
                                    None => vec![],
                                };
                            (p.start, p.end, p.payment, sub_info)
                        })
                        .collect(),
                )
            }
            _ => None,
        }
    }

    /// Notional schedule: returns (date, notional) pairs for PIK and Amortizing bonds.
    ///
    /// For PIK bonds, shows the growing notional at each period start plus final notional.
    /// For Amortizing bonds, shows the declining notional at each period start plus final redemption.
    /// For other variants, returns a single entry at face value.
    pub fn notional_schedule(&self) -> Vec<(NaiveDate, f64)> {
        match &self.variant {
            BondVariant::PIK(data) => {
                let mut schedule: Vec<(NaiveDate, f64)> = data.periods.iter()
                    .map(|p| (p.start, p.notional))
                    .collect();
                schedule.push((self.termination, data.final_notional));
                schedule
            }
            BondVariant::Amortizing(data) => {
                let mut schedule: Vec<(NaiveDate, f64)> = data.periods.iter()
                    .map(|p| (p.start, p.notional))
                    .collect();
                schedule.push((self.termination, data.final_redemption));
                schedule
            }
            _ => vec![(self.effective, self.face_value)],
        }
    }

    // -----------------------------------------------------------------------
    // Core pricing methods
    // -----------------------------------------------------------------------

    /// Settlement date = trade_date + settlement_days business days.
    pub fn settlement_date(&self, trade_date: NaiveDate) -> NaiveDate {
        add_business_days(trade_date, self.settlement_days, &self.calendar)
    }

    /// Apply historical fixings to floating-rate periods.
    ///
    /// For FloatRateNote, SubPeriodFRN, and CappedFloored variants, sets
    /// `fixing_rate` on each period whose start date has a matching entry
    /// in the fixings map. The fixing value should be the index rate (e.g.
    /// EURIBOR 6M), *not* including the spread — spread is added at pricing time.
    pub fn set_fixings(&mut self, fixings: &HashMap<NaiveDate, f64>) {
        let cal = self.calendar.clone();
        let settlement_lag = self.settlement_days;
        match &mut self.variant {
            BondVariant::FloatRateNote(data) => {
                let lag = data.fixing_lag;
                for period in &mut data.periods {
                    let fixing_date = add_business_days(period.start, -lag, &cal);
                    if let Some(&rate) = fixings.get(&fixing_date) {
                        period.fixing_rate = Some(rate + data.spread);
                    }
                }
            }
            BondVariant::SubPeriodFRN(data) => {
                for period in &mut data.periods {
                    for sp in &mut period.sub_periods {
                        let fixing_date = add_business_days(sp.start, -settlement_lag, &cal);
                        if let Some(&rate) = fixings.get(&fixing_date) {
                            sp.fixing_rate = Some(rate);
                        }
                    }
                }
            }
            BondVariant::CappedFloored(data) => {
                for period in &mut data.periods {
                    if let Some(ref mut sub_periods) = period.sub_periods {
                        for sp in sub_periods.iter_mut() {
                            let fixing_date = add_business_days(sp.start, -settlement_lag, &cal);
                            if let Some(&rate) = fixings.get(&fixing_date) {
                                sp.fixing_rate = Some(rate);
                            }
                        }
                    } else {
                        let fixing_date = add_business_days(period.start, -settlement_lag, &cal);
                        if let Some(&rate) = fixings.get(&fixing_date) {
                            period.fixing_rate = Some(rate + data.spread);
                        }
                    }
                }
            }
            _ => {}
        }
    }

    /// Set the evaluation date used as default for all analytics.
    pub fn set_eval_date(&mut self, date: NaiveDate) {
        self.eval_date = date;
    }

    /// Check if settlement is in the ex-dividend period for a given coupon period.
    pub fn is_ex_dividend(&self, settlement: NaiveDate) -> bool {
        if self.ex_div_days == 0 {
            return false;
        }
        match &self.variant {
            BondVariant::FixedRate(data) => {
                // Find the next coupon after settlement
                for period in &data.periods {
                    if period.end > settlement {
                        // ex-div boundary = coupon_date - ex_div_days business days
                        let ex_div_date = add_business_days(
                            period.end,
                            -self.ex_div_days,
                            &self.calendar,
                        );
                        return settlement >= ex_div_date;
                    }
                }
                false
            }
            BondVariant::StepUp(data) => {
                for period in &data.periods {
                    if period.end > settlement {
                        let ex_div_date = add_business_days(
                            period.end,
                            -self.ex_div_days,
                            &self.calendar,
                        );
                        return settlement >= ex_div_date;
                    }
                }
                false
            }
            BondVariant::Amortizing(data) => {
                for period in &data.periods {
                    if period.end > settlement {
                        let ex_div_date = add_business_days(
                            period.end,
                            -self.ex_div_days,
                            &self.calendar,
                        );
                        return settlement >= ex_div_date;
                    }
                }
                false
            }
            BondVariant::PIK(data) => {
                for period in &data.periods {
                    if period.end > settlement {
                        let ex_div_date = add_business_days(
                            period.end,
                            -self.ex_div_days,
                            &self.calendar,
                        );
                        return settlement >= ex_div_date;
                    }
                }
                false
            }
            BondVariant::ZeroCoupon(_) => false,
            _ => false,
        }
    }

    /// Accrued interest at a given settlement date.
    ///
    /// Uses the bond's `accrued_convention` to compute the day-count fraction,
    /// matching QuantLib behaviour:
    ///   `accrued = rate × notional × dcf(period_start, settlement)`
    ///
    /// For ex-div period: accrued minus the full period coupon (goes negative).
    /// For Bill: always 0.
    /// For ZeroCoupon: OID compound accrued using `convention`.
    pub fn accrued_interest(&self, settlement: NaiveDate) -> f64 {
        let opts = DcfOptions {
            calendar: Some(&self.calendar),
            termination: Some(self.termination),
        };
        match &self.variant {
            BondVariant::FixedRate(data) => {
                let idx = match self.variant.find_period_index(settlement) {
                    Some(i) => i, None => return 0.0,
                };
                let period = &data.periods[idx];
                let accrued_dcf = self.accrued_convention
                    .dcf(period.start, settlement, &opts).unwrap();
                let accrued = data.coupon * self.face_value * accrued_dcf;
                if self.is_ex_dividend(settlement) {
                    let full_dcf = self.accrued_convention
                        .dcf(period.start, period.end, &opts).unwrap();
                    accrued - data.coupon * self.face_value * full_dcf
                } else {
                    accrued
                }
            }
            BondVariant::Bill(_) => 0.0,
            BondVariant::FloatRateNote(data) => {
                let idx = match self.variant.find_period_index(settlement) {
                    Some(i) => i, None => return 0.0,
                };
                let period = &data.periods[idx];
                let rate = period.fixing_rate.unwrap_or(data.spread);
                let accrued_dcf = self.accrued_convention
                    .dcf(period.start, settlement, &opts).unwrap();
                rate * self.face_value * accrued_dcf
            }
            BondVariant::ZeroCoupon(data) => {
                if settlement <= self.effective || settlement >= self.termination {
                    return 0.0;
                }
                let total_dcf = self.accrued_convention.dcf(self.effective, self.termination, &opts).unwrap();
                let elapsed_dcf = self.accrued_convention.dcf(self.effective, settlement, &opts).unwrap();
                let y = (self.face_value / data.issue_price).powf(1.0 / total_dcf) - 1.0;
                self.face_value * (1.0 + y).powf(elapsed_dcf) - data.issue_price
            }
            BondVariant::StepUp(data) => {
                let idx = match self.variant.find_period_index(settlement) {
                    Some(i) => i, None => return 0.0,
                };
                let period = &data.periods[idx];
                let accrued_dcf = self.accrued_convention
                    .dcf(period.start, settlement, &opts).unwrap();
                let accrued = period.coupon_rate * self.face_value * accrued_dcf;
                if self.is_ex_dividend(settlement) {
                    let full_dcf = self.accrued_convention
                        .dcf(period.start, period.end, &opts).unwrap();
                    accrued - period.coupon_rate * self.face_value * full_dcf
                } else {
                    accrued
                }
            }
            BondVariant::Amortizing(data) => {
                let idx = match self.variant.find_period_index(settlement) {
                    Some(i) => i, None => return 0.0,
                };
                let period = &data.periods[idx];
                let accrued_dcf = self.accrued_convention
                    .dcf(period.start, settlement, &opts).unwrap();
                let accrued = period.coupon_rate * period.notional * accrued_dcf;
                if self.is_ex_dividend(settlement) {
                    let full_dcf = self.accrued_convention
                        .dcf(period.start, period.end, &opts).unwrap();
                    accrued - period.coupon_rate * period.notional * full_dcf
                } else {
                    accrued
                }
            }
            BondVariant::PIK(data) => {
                let idx = match self.variant.find_period_index(settlement) {
                    Some(i) => i, None => return 0.0,
                };
                let period = &data.periods[idx];
                let accrued_dcf = self.accrued_convention
                    .dcf(period.start, settlement, &opts).unwrap();
                let cash_rate = period.coupon_rate * (1.0 - period.pik_fraction);
                let accrued = cash_rate * period.notional * accrued_dcf;
                if self.is_ex_dividend(settlement) {
                    let full_dcf = self.accrued_convention
                        .dcf(period.start, period.end, &opts).unwrap();
                    accrued - cash_rate * period.notional * full_dcf
                } else {
                    accrued
                }
            }
            BondVariant::SubPeriodFRN(data) => {
                let idx = match self.variant.find_period_index(settlement) {
                    Some(i) => i, None => return 0.0,
                };
                let period = &data.periods[idx];
                let rate = compounded_sub_period_rate(&period.sub_periods, None, data.spread);
                let accrued_dcf = self.accrued_convention
                    .dcf(period.start, settlement, &opts).unwrap();
                rate * self.face_value * accrued_dcf
            }
            BondVariant::CappedFloored(data) => {
                let idx = match self.variant.find_period_index(settlement) {
                    Some(i) => i, None => return 0.0,
                };
                let period = &data.periods[idx];
                let effective_rate = if let Some(ref sub_periods) = period.sub_periods {
                    compounded_sub_period_rate(sub_periods, None, data.spread)
                } else {
                    period.fixing_rate.unwrap_or(data.spread)
                };
                let mut adjusted_rate = effective_rate;
                if let Some(cap) = data.cap_rate {
                    adjusted_rate = adjusted_rate.min(cap);
                }
                if let Some(floor) = data.floor_rate {
                    adjusted_rate = adjusted_rate.max(floor);
                }
                let accrued_dcf = self.accrued_convention
                    .dcf(period.start, settlement, &opts).unwrap();
                adjusted_rate * self.face_value * accrued_dcf
            }
        }
    }

    /// Number of accrued days at settlement, computed using `accrued_convention`.
    ///
    /// Mirrors QuantLib `BondFunctions::accruedDays(bond, settlement)`:
    /// finds the coupon period containing `settlement` and returns the
    /// convention-adjusted day count from the period start to
    /// `min(settlement, period_end)`.
    pub fn accrued_days(&self, settlement: NaiveDate) -> i64 {
        let opts = DcfOptions {
            calendar: Some(&self.calendar),
            termination: Some(self.termination),
        };
        match &self.variant {
            BondVariant::Bill(_) => 0,
            BondVariant::ZeroCoupon(_) => {
                if settlement <= self.effective || settlement >= self.termination {
                    return 0;
                }
                self.accrued_convention
                    .day_count(self.effective, settlement, &opts)
                    .unwrap_or(0)
            }
            // All coupon-bearing variants share the same period-search logic.
            _ => {
                if let Some((start, end)) = self.variant.find_accrual_period(settlement) {
                    let end_date = if settlement < end { settlement } else { end };
                    self.accrued_convention
                        .day_count(start, end_date, &opts)
                        .unwrap_or(0)
                } else {
                    0
                }
            }
        }
    }

    /// Raw present value: sum of DF(payment) × cashflow, discounted from the
    /// curve origin. Used internally by `npv()` and `dirty_price()`.
    fn raw_pv(&self, curve: &dyn CurveQuery, settlement: NaiveDate, eval_date: Option<NaiveDate>) -> Number {
        let cfs = self.variant.bond_cashflows(settlement, self.face_value, self.termination, Some(curve));
        let mut total = Number::F64(0.0);
        for cf in &cfs {
            if let Some(ed) = eval_date {
                if cf.payment < ed {
                    continue;
                }
            }
            let df = curve.discount_factor(cf.payment);
            total = total + df * cf.amount.clone();
        }
        total
    }

    /// Dirty price discounted to settlement date (market convention).
    /// AD-aware (returns Number).
    ///
    /// `dirty_price = sum(CF_i × DF(CF_i)) / DF(settlement)`
    ///
    /// This rebases discounting from the curve origin to the settlement date,
    /// matching QuantLib `BondFunctions::dirtyPrice()`.
    ///
    /// When `settlement` is `None`, uses `self.effective` (where DF ≈ 1.0).
    pub fn dirty_price(&self, curve: &dyn CurveQuery, settlement: Option<NaiveDate>, eval_date: Option<NaiveDate>) -> Number {
        let settlement = settlement.unwrap_or(self.effective);
        let raw = self.raw_pv(curve, settlement, eval_date);
        let df_settle = curve.discount_factor(settlement);
        raw / df_settle
    }

    /// Clean price = dirty_price - accrued_interest.
    ///
    /// When `settlement` is `Some(date)`, uses that date for both dirty price
    /// and accrued interest. When `None`, uses `self.effective`.
    pub fn price(&self, curve: &dyn CurveQuery, settlement: Option<NaiveDate>) -> Number {
        let settlement_date = settlement.unwrap_or(self.effective);
        let dirty = self.dirty_price(curve, Some(settlement_date), None);
        let accrued = self.accrued_interest(settlement_date);
        dirty - accrued
    }

    /// Compute the stub fraction for the first remaining coupon period.
    ///
    /// Returns `dcf(settlement, first_end) / dcf(first_start, first_end)`
    /// using the bond's `accrued_convention`. Call once per settlement,
    /// then use `stub + period_offset` for subsequent periods.
    fn ytm_stub_fraction(
        &self,
        settlement: NaiveDate,
        first_period_start: NaiveDate,
        first_period_end: NaiveDate,
    ) -> f64 {
        let opts = DcfOptions {
            calendar: Some(&self.calendar),
            termination: Some(self.termination),
        };
        let remaining_dcf = self.accrued_convention
            .dcf(settlement, first_period_end, &opts).unwrap();
        let full_dcf = self.accrued_convention
            .dcf(first_period_start, first_period_end, &opts).unwrap();
        if full_dcf > 0.0 { remaining_dcf / full_dcf } else { 1.0 }
    }

    /// YTM discount factor for period count `n` at given yield and frequency.
    fn ytm_df(ytm: f64, n: f64, freq: f64, convention: &str) -> f64 {
        if convention == "periodic"
            || !["continuous", "annual", "semi_annual", "quarterly", "daily", "simple"]
                .contains(&convention)
        {
            (1.0 + ytm / freq).powf(-n)
        } else {
            let t = n / freq;
            compounding::discount_factor(ytm, t, convention).unwrap()
        }
    }

    /// Price from YTM using standard bond pricing formula.
    ///
    /// Discounts each cashflow based on the compounding convention:
    /// - "periodic" (default): (1 + ytm/freq)^(-n)
    /// - "annual": (1 + ytm)^(-t) where t = n/freq (year fraction)
    /// - "semi_annual": (1 + ytm/2)^(-2*t)
    /// - "continuous": exp(-ytm * t)
    ///
    /// The fractional first period uses the bond's `accrued_convention` to
    /// compute the stub, matching QuantLib behaviour.
    pub fn price_from_ytm(&self, ytm: f64, settlement: NaiveDate, convention: &str) -> f64 {
        match &self.variant {
            BondVariant::FixedRate(data) => {
                let freq = data.frequency.periods_per_annum();
                let coupon_payment = data.coupon * self.face_value / freq;
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut total = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let df = Self::ytm_df(ytm, n, freq, convention);
                    total += coupon_payment * df;
                    if period.end == self.termination {
                        total += self.face_value * df;
                    }
                }
                total
            }
            BondVariant::Bill(_) => {
                let opts = DcfOptions {
                    calendar: Some(&self.calendar),
                    termination: Some(self.termination),
                };
                let dcf = self.accrued_convention
                    .dcf(settlement, self.termination, &opts).unwrap();
                if convention == "periodic"
                    || !["continuous", "annual", "semi_annual", "quarterly", "daily", "simple"]
                        .contains(&convention)
                {
                    self.face_value / (1.0 + ytm * dcf)
                } else {
                    self.face_value * compounding::discount_factor(ytm, dcf, convention).unwrap()
                }
            }
            BondVariant::FloatRateNote(_) => {
                self.face_value
            }
            BondVariant::ZeroCoupon(data) => {
                let opts = DcfOptions {
                    calendar: Some(&self.calendar),
                    termination: Some(self.termination),
                };
                let dcf = self.accrued_convention
                    .dcf(settlement, self.termination, &opts).unwrap();
                let freq = data.frequency.periods_per_annum();
                if convention == "periodic"
                    || !["continuous", "annual", "semi_annual", "quarterly", "daily", "simple"]
                        .contains(&convention)
                {
                    self.face_value / (1.0 + ytm / freq).powf(freq * dcf)
                } else {
                    self.face_value * compounding::discount_factor(ytm, dcf, convention).unwrap()
                }
            }
            BondVariant::StepUp(data) => {
                let freq = data.frequency.periods_per_annum();
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut total = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let coupon_payment = period.coupon_rate * self.face_value / freq;
                    let df = Self::ytm_df(ytm, n, freq, convention);
                    total += coupon_payment * df;
                    if period.end == self.termination {
                        total += self.face_value * df;
                    }
                }
                total
            }
            BondVariant::Amortizing(data) => {
                let freq = data.frequency.periods_per_annum();
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut total = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let coupon_payment = period.coupon_rate * period.notional / freq;
                    let df = Self::ytm_df(ytm, n, freq, convention);
                    total += coupon_payment * df;
                    if period.principal_repayment > 0.0 {
                        total += period.principal_repayment * df;
                    }
                    if period.end == self.termination {
                        total += data.final_redemption * df;
                    }
                }
                total
            }
            BondVariant::PIK(data) => {
                let freq = data.frequency.periods_per_annum();
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut total = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let cash_coupon = period.coupon_rate * period.notional / freq * (1.0 - period.pik_fraction);
                    let df = Self::ytm_df(ytm, n, freq, convention);
                    if cash_coupon > 0.0 {
                        total += cash_coupon * df;
                    }
                    if period.end == self.termination {
                        total += data.final_notional * df;
                    }
                }
                total
            }
            BondVariant::SubPeriodFRN(_) | BondVariant::CappedFloored(_) => {
                self.face_value
            }
        }
    }

    // -----------------------------------------------------------------------
    // Analytics
    // -----------------------------------------------------------------------

    /// Yield to maturity: solve for ytm such that price_from_ytm(ytm) = clean_price.
    ///
    /// The `convention` parameter controls the compounding convention used:
    /// "periodic" (default), "annual", "semi_annual", or "continuous".
    pub fn ytm(&self, clean_price: f64, settlement: NaiveDate, convention: &str) -> f64 {
        let accrued = self.accrued_interest(settlement);
        let dirty_target = clean_price + accrued;

        // Use Brent on [-0.1, 1.0]
        let result = brent(
            |y| self.price_from_ytm(y, settlement, convention) - dirty_target,
            -0.1,
            1.0,
            1e-12,
            200,
        );

        match result {
            Ok(y) => y,
            Err(_) => {
                // Fallback: try wider bracket
                brent(
                    |y| self.price_from_ytm(y, settlement, convention) - dirty_target,
                    -0.5,
                    5.0,
                    1e-10,
                    500,
                )
                .unwrap_or(0.0)
            }
        }
    }

    /// Macaulay or modified duration.
    ///
    /// Uses finite difference: bump ytm by +/- 1bp and compute dP/dy.
    /// When `settlement` is `Some(date)`, uses that date for analytics.
    /// When `None`, uses `self.effective` (preserving original behavior).
    pub fn duration(&self, curve: &dyn CurveQuery, metric: &str, settlement: Option<NaiveDate>) -> f64 {
        let settlement = settlement.unwrap_or(self.eval_date);
        let dirty = match self.dirty_price(curve, Some(settlement), None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        if dirty.abs() < 1e-12 { return 0.0; }

        let accrued = self.accrued_interest(settlement);
        let clean = dirty - accrued;
        let ytm_val = self.ytm(clean, settlement, "periodic");
        let freq = self.variant.frequency();

        let bump = 0.0001;
        let p_up = self.price_from_ytm(ytm_val + bump, settlement, "periodic");
        let p_down = self.price_from_ytm(ytm_val - bump, settlement, "periodic");

        let mod_dur = -(p_up - p_down) / (2.0 * bump * dirty);

        match metric {
            "modified" => mod_dur,
            "macaulay" => mod_dur * (1.0 + ytm_val / freq),
            _ => mod_dur,
        }
    }

    /// Convexity: d2P/dy2 / P using finite difference.
    ///
    /// When `settlement` is `Some(date)`, uses that date for analytics.
    /// When `None`, uses `self.effective` (preserving original behavior).
    pub fn convexity(&self, curve: &dyn CurveQuery, settlement: Option<NaiveDate>) -> f64 {
        let settlement = settlement.unwrap_or(self.eval_date);
        let dirty = match self.dirty_price(curve, Some(settlement), None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        if dirty.abs() < 1e-12 { return 0.0; }

        let accrued = self.accrued_interest(settlement);
        let clean = dirty - accrued;
        let ytm_val = self.ytm(clean, settlement, "periodic");

        let bump = 0.0001;
        let p_up = self.price_from_ytm(ytm_val + bump, settlement, "periodic");
        let p_down = self.price_from_ytm(ytm_val - bump, settlement, "periodic");
        let p_mid = self.price_from_ytm(ytm_val, settlement, "periodic");

        (p_up + p_down - 2.0 * p_mid) / (bump * bump * dirty)
    }

    /// Analytical Macaulay or modified duration from yield to maturity.
    ///
    /// Uses the bond's `accrued_convention` for the stub fraction,
    /// matching QuantLib behaviour.
    pub fn duration_from_ytm(&self, ytm: f64, settlement: NaiveDate, metric: &str, convention: &str) -> f64 {
        match &self.variant {
            BondVariant::FixedRate(data) => {
                let freq = data.frequency.periods_per_annum();
                let coupon_payment = data.coupon * self.face_value / freq;
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut weighted_sum = 0.0;
                let mut price = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let t_years = n / freq;
                    let df = Self::ytm_df(ytm, n, freq, convention);

                    weighted_sum += t_years * coupon_payment * df;
                    price += coupon_payment * df;
                    if period.end == self.termination {
                        weighted_sum += t_years * self.face_value * df;
                        price += self.face_value * df;
                    }
                }
                if price.abs() < 1e-12 { return 0.0; }
                let mac_dur = weighted_sum / price;
                match metric { "macaulay" => mac_dur, _ => mac_dur / (1.0 + ytm / freq) }
            }
            BondVariant::Bill(_) => {
                let opts = DcfOptions { calendar: Some(&self.calendar), termination: Some(self.termination) };
                let dcf = self.accrued_convention.dcf(settlement, self.termination, &opts).unwrap();
                match metric { "macaulay" => dcf, _ => dcf / (1.0 + ytm * dcf) }
            }
            BondVariant::ZeroCoupon(data) => {
                let opts = DcfOptions { calendar: Some(&self.calendar), termination: Some(self.termination) };
                let dcf = self.accrued_convention.dcf(settlement, self.termination, &opts).unwrap();
                let freq = data.frequency.periods_per_annum();
                match metric { "macaulay" => dcf, _ => dcf / (1.0 + ytm / freq) }
            }
            BondVariant::StepUp(data) => {
                let freq = data.frequency.periods_per_annum();
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut weighted_sum = 0.0;
                let mut price = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let t_years = n / freq;
                    let coupon_payment = period.coupon_rate * self.face_value / freq;
                    let df = Self::ytm_df(ytm, n, freq, convention);

                    weighted_sum += t_years * coupon_payment * df;
                    price += coupon_payment * df;
                    if period.end == self.termination {
                        weighted_sum += t_years * self.face_value * df;
                        price += self.face_value * df;
                    }
                }
                if price.abs() < 1e-12 { return 0.0; }
                let mac_dur = weighted_sum / price;
                match metric { "macaulay" => mac_dur, _ => mac_dur / (1.0 + ytm / freq) }
            }
            BondVariant::Amortizing(data) => {
                let freq = data.frequency.periods_per_annum();
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut weighted_sum = 0.0;
                let mut price = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let t_years = n / freq;
                    let coupon_payment = period.coupon_rate * period.notional / freq;
                    let df = Self::ytm_df(ytm, n, freq, convention);

                    weighted_sum += t_years * coupon_payment * df;
                    price += coupon_payment * df;
                    if period.principal_repayment > 0.0 {
                        weighted_sum += t_years * period.principal_repayment * df;
                        price += period.principal_repayment * df;
                    }
                    if period.end == self.termination {
                        weighted_sum += t_years * data.final_redemption * df;
                        price += data.final_redemption * df;
                    }
                }
                if price.abs() < 1e-12 { return 0.0; }
                let mac_dur = weighted_sum / price;
                match metric { "macaulay" => mac_dur, _ => mac_dur / (1.0 + ytm / freq) }
            }
            BondVariant::PIK(data) => {
                let freq = data.frequency.periods_per_annum();
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut weighted_sum = 0.0;
                let mut price = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let t_years = n / freq;
                    let cash_coupon = period.coupon_rate * period.notional / freq * (1.0 - period.pik_fraction);
                    let df = Self::ytm_df(ytm, n, freq, convention);

                    if cash_coupon > 0.0 {
                        weighted_sum += t_years * cash_coupon * df;
                        price += cash_coupon * df;
                    }
                    if period.end == self.termination {
                        weighted_sum += t_years * data.final_notional * df;
                        price += data.final_notional * df;
                    }
                }
                if price.abs() < 1e-12 { return 0.0; }
                let mac_dur = weighted_sum / price;
                match metric { "macaulay" => mac_dur, _ => mac_dur / (1.0 + ytm / freq) }
            }
            BondVariant::FloatRateNote(_)
            | BondVariant::SubPeriodFRN(_)
            | BondVariant::CappedFloored(_) => 0.0,
        }
    }

    /// Analytical convexity from yield to maturity.
    ///
    /// Uses the bond's `accrued_convention` for the stub fraction.
    pub fn convexity_from_ytm(&self, ytm: f64, settlement: NaiveDate, convention: &str) -> f64 {
        match &self.variant {
            BondVariant::FixedRate(data) => {
                let freq = data.frequency.periods_per_annum();
                let coupon_payment = data.coupon * self.face_value / freq;
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut conv_sum = 0.0;
                let mut price = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let t_years = n / freq;
                    let df = Self::ytm_df(ytm, n, freq, convention);

                    if convention == "continuous" {
                        conv_sum += t_years * t_years * coupon_payment * df;
                    } else {
                        conv_sum += n * (n + 1.0) * coupon_payment * df;
                    }
                    price += coupon_payment * df;
                    if period.end == self.termination {
                        if convention == "continuous" {
                            conv_sum += t_years * t_years * self.face_value * df;
                        } else {
                            conv_sum += n * (n + 1.0) * self.face_value * df;
                        }
                        price += self.face_value * df;
                    }
                }
                if price.abs() < 1e-12 { return 0.0; }
                if convention == "continuous" { conv_sum / price }
                else { conv_sum / (freq * freq * price * (1.0 + ytm / freq).powi(2)) }
            }
            BondVariant::Bill(_) => {
                let opts = DcfOptions { calendar: Some(&self.calendar), termination: Some(self.termination) };
                let dcf = self.accrued_convention.dcf(settlement, self.termination, &opts).unwrap();
                if convention == "continuous" { dcf * dcf }
                else { dcf * (dcf + 1.0) / (1.0 + ytm * dcf).powi(2) }
            }
            BondVariant::ZeroCoupon(data) => {
                let opts = DcfOptions { calendar: Some(&self.calendar), termination: Some(self.termination) };
                let dcf = self.accrued_convention.dcf(settlement, self.termination, &opts).unwrap();
                let freq = data.frequency.periods_per_annum();
                let n = dcf * freq;
                if convention == "continuous" { dcf * dcf }
                else { n * (n + 1.0) / (freq * freq * (1.0 + ytm / freq).powi(2)) }
            }
            BondVariant::StepUp(data) => {
                let freq = data.frequency.periods_per_annum();
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut conv_sum = 0.0;
                let mut price = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let t_years = n / freq;
                    let coupon_payment = period.coupon_rate * self.face_value / freq;
                    let df = Self::ytm_df(ytm, n, freq, convention);

                    if convention == "continuous" { conv_sum += t_years * t_years * coupon_payment * df; }
                    else { conv_sum += n * (n + 1.0) * coupon_payment * df; }
                    price += coupon_payment * df;
                    if period.end == self.termination {
                        if convention == "continuous" { conv_sum += t_years * t_years * self.face_value * df; }
                        else { conv_sum += n * (n + 1.0) * self.face_value * df; }
                        price += self.face_value * df;
                    }
                }
                if price.abs() < 1e-12 { return 0.0; }
                if convention == "continuous" { conv_sum / price }
                else { conv_sum / (freq * freq * price * (1.0 + ytm / freq).powi(2)) }
            }
            BondVariant::Amortizing(data) => {
                let freq = data.frequency.periods_per_annum();
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut conv_sum = 0.0;
                let mut price = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let t_years = n / freq;
                    let coupon_payment = period.coupon_rate * period.notional / freq;
                    let df = Self::ytm_df(ytm, n, freq, convention);

                    if convention == "continuous" { conv_sum += t_years * t_years * coupon_payment * df; }
                    else { conv_sum += n * (n + 1.0) * coupon_payment * df; }
                    price += coupon_payment * df;
                    if period.principal_repayment > 0.0 {
                        if convention == "continuous" { conv_sum += t_years * t_years * period.principal_repayment * df; }
                        else { conv_sum += n * (n + 1.0) * period.principal_repayment * df; }
                        price += period.principal_repayment * df;
                    }
                    if period.end == self.termination {
                        if convention == "continuous" { conv_sum += t_years * t_years * data.final_redemption * df; }
                        else { conv_sum += n * (n + 1.0) * data.final_redemption * df; }
                        price += data.final_redemption * df;
                    }
                }
                if price.abs() < 1e-12 { return 0.0; }
                if convention == "continuous" { conv_sum / price }
                else { conv_sum / (freq * freq * price * (1.0 + ytm / freq).powi(2)) }
            }
            BondVariant::PIK(data) => {
                let freq = data.frequency.periods_per_annum();
                let first_idx = data.periods.partition_point(|p| p.end <= settlement);
                if first_idx >= data.periods.len() { return 0.0; }
                let fp = &data.periods[first_idx];
                let stub = self.ytm_stub_fraction(settlement, fp.start, fp.end);

                let mut conv_sum = 0.0;
                let mut price = 0.0;
                for (i, period) in data.periods.iter().enumerate().skip(first_idx) {
                    let n = stub + (i - first_idx) as f64;
                    let t_years = n / freq;
                    let cash_coupon = period.coupon_rate * period.notional / freq * (1.0 - period.pik_fraction);
                    let df = Self::ytm_df(ytm, n, freq, convention);

                    if cash_coupon > 0.0 {
                        if convention == "continuous" { conv_sum += t_years * t_years * cash_coupon * df; }
                        else { conv_sum += n * (n + 1.0) * cash_coupon * df; }
                        price += cash_coupon * df;
                    }
                    if period.end == self.termination {
                        if convention == "continuous" { conv_sum += t_years * t_years * data.final_notional * df; }
                        else { conv_sum += n * (n + 1.0) * data.final_notional * df; }
                        price += data.final_notional * df;
                    }
                }
                if price.abs() < 1e-12 { return 0.0; }
                if convention == "continuous" { conv_sum / price }
                else { conv_sum / (freq * freq * price * (1.0 + ytm / freq).powi(2)) }
            }
            BondVariant::FloatRateNote(_)
            | BondVariant::SubPeriodFRN(_)
            | BondVariant::CappedFloored(_) => 0.0,
        }
    }

    /// DV01: modified_duration * dirty_price / 10000.
    pub fn dv01(&self, curve: &dyn CurveQuery) -> f64 {
        let _settlement = self.effective;
        let dirty = match self.dirty_price(curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let mod_dur = self.duration(curve, "modified", None);
        mod_dur * dirty / 10000.0
    }

    /// Z-spread: find z such that discounting at curve rates + z matches clean_price.
    ///
    /// When `settlement` is `Some(date)`, uses that date for accrued interest and DCF base.
    /// When `None`, uses `self.effective` (preserving original behavior).
    pub fn z_spread(&self, curve: &dyn CurveQuery, clean_price: f64, settlement: Option<NaiveDate>, compounding: &str) -> f64 {
        let settlement = settlement.unwrap_or(self.eval_date);
        let accrued = self.accrued_interest(settlement);
        let dirty_target = clean_price + accrued;

        // FRN/SubPeriodFRN/CappedFloored z_spread is not supported
        match &self.variant {
            BondVariant::FloatRateNote(_)
            | BondVariant::SubPeriodFRN(_)
            | BondVariant::CappedFloored(_) => return 0.0,
            _ => {}
        }

        // Bill: analytic solution (preserve current behavior)
        if matches!(&self.variant, BondVariant::Bill(_)) {
            let df = match curve.discount_factor(self.termination) {
                Number::F64(v) => v,
                Number::Dual(d) => d.real,
                Number::Dual2(d) => d.real,
            };
            let t = self
                .convention
                .dcf(settlement, self.termination, &DcfOptions::default())
                .unwrap();
            return if t > 0.0 && df > 0.0 {
                let implied_df = dirty_target / (self.face_value * df);
                compounding::rate_from_df(implied_df, t, compounding).unwrap_or(0.0)
            } else {
                0.0
            };
        }

        // Generic Brent solve for coupon bonds using cashflow vector
        let cfs = self.variant.bond_cashflows(settlement, self.face_value, self.termination, None);
        if cfs.is_empty() {
            return 0.0;
        }

        let result = brent(
            |z| {
                let mut total = 0.0;
                for cf in &cfs {
                    let df = match curve.discount_factor(cf.payment) {
                        Number::F64(v) => v,
                        Number::Dual(d) => d.real,
                        Number::Dual2(d) => d.real,
                    };
                    let t = self
                        .convention
                        .dcf(settlement, cf.payment, &DcfOptions::default())
                        .unwrap();
                    let amount = match &cf.amount {
                        Number::F64(v) => *v,
                        Number::Dual(d) => d.real,
                        Number::Dual2(d) => d.real,
                    };
                    total += amount * df * compounding::discount_factor(z, t, compounding).unwrap();
                }
                total - dirty_target
            },
            -0.05,
            0.50,
            1e-12,
            200,
        );

        result.unwrap_or(0.0)
    }

    /// Asset swap spread (par-par or market-value method).
    ///
    /// Delegates to AssetSwapInstrument for all bond variants.
    ///
    /// When `settlement` is `Some(date)`, uses that date for accrued interest and cashflow filtering.
    /// When `None`, uses `self.effective` (preserving original behavior).
    pub fn asw_spread(
        &self,
        curve: &dyn CurveQuery,
        clean_price: f64,
        method: &str,
        settlement: Option<NaiveDate>,
    ) -> f64 {
        use super::asset_swap::{AssetSwapInstrument, AssetSwapType};

        let asw_type = match method {
            "par_par" => AssetSwapType::Par,
            "market_value" => AssetSwapType::MarketValue,
            _ => return 0.0,
        };

        let settlement_date = settlement.unwrap_or(self.eval_date);
        let dirty_price = if asw_type == AssetSwapType::MarketValue {
            Some(clean_price + self.accrued_interest(settlement_date))
        } else {
            None
        };

        let asw = AssetSwapInstrument::new(
            self.clone(),
            asw_type,
            dirty_price,
            None,
        );

        // rate() returns Number; extract f64 for backward compatibility
        match asw.rate(curve, curve) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        }
    }

    /// CS01: sensitivity to 1bp credit spread.
    ///
    /// Analytical approximation: sum(t_i * DF_i * CF_i) / 10000.
    pub fn cs01(&self, curve: &dyn CurveQuery) -> f64 {
        // Bill, FRN, SubPeriodFRN, CappedFloored return 0.0
        match &self.variant {
            BondVariant::Bill(_)
            | BondVariant::FloatRateNote(_)
            | BondVariant::SubPeriodFRN(_)
            | BondVariant::CappedFloored(_) => return 0.0,
            _ => {}
        }

        let cfs = self.variant.bond_cashflows(self.effective, self.face_value, self.termination, None);
        let mut total = 0.0;
        for cf in &cfs {
            let df = match curve.discount_factor(cf.payment) {
                Number::F64(v) => v,
                Number::Dual(d) => d.real,
                Number::Dual2(d) => d.real,
            };
            let t = self
                .convention
                .dcf(self.effective, cf.payment, &DcfOptions::default())
                .unwrap();
            let amount = match &cf.amount {
                Number::F64(v) => *v,
                Number::Dual(d) => d.real,
                Number::Dual2(d) => d.real,
            };
            total += t * df * amount;
        }
        total / 10000.0
    }

    /// Price-yield sensitivity: dP/dy for 1bp yield change.
    pub fn price_yield_sensitivity(&self, curve: &dyn CurveQuery) -> f64 {
        let settlement = self.effective;
        let clean = match self.price(curve, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let ytm_val = self.ytm(clean, settlement, "periodic");
        let bump = 0.0001;
        let p_up = self.price_from_ytm(ytm_val + bump, settlement, "periodic");
        let p_down = self.price_from_ytm(ytm_val - bump, settlement, "periodic");
        (p_up - p_down) / (2.0 * bump)
    }

    /// I-spread: YTM minus interpolated swap zero rate at maturity.
    ///
    /// Computes dirty price from the curve, derives clean price, solves for YTM,
    /// then subtracts the zero rate from settlement to termination.
    pub fn i_spread(&self, settlement: NaiveDate, curve: &dyn CurveQuery) -> f64 {
        let dirty = self.dirty_price(curve, Some(settlement), None);
        let dirty_f64 = match dirty {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let accrued = self.accrued_interest(settlement);
        let clean = dirty_f64 - accrued;
        let ytm_val = self.ytm(clean, settlement, "periodic");
        let swap_rate = match curve.zero_rate(settlement, self.termination) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        ytm_val - swap_rate
    }

    // -----------------------------------------------------------------------
    // Solver integration
    // -----------------------------------------------------------------------

    /// Returns model clean price (for solver: target = market clean price).
    pub fn rate(
        &self,
        disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
    ) -> Number {
        self.price(disc_curve, None)
    }

    /// Returns dirty price (standard NPV).
    ///
    /// When `future_only` is true, cashflows with payment strictly before `eval_date` are excluded.
    /// When `eval_date` is None and `future_only` is true, uses `self.eval_date` (defaults to today).
    pub fn npv(
        &self,
        disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
        future_only: bool,
        eval_date: Option<NaiveDate>,
    ) -> Number {
        let ed = if future_only {
            Some(eval_date.unwrap_or(self.eval_date))
        } else {
            None
        };
        // NPV is present value at curve origin, not rebased to settlement.
        self.raw_pv(disc_curve, self.effective, ed)
    }

    /// Return coupon + principal cashflow rows.
    pub fn cashflows(
        &self,
        disc_curve: Option<&dyn CurveQuery>,
        _forecast_curve: Option<&dyn CurveQuery>,
    ) -> Vec<CashflowRow> {
        match &self.variant {
            BondVariant::FixedRate(data) => {
                let freq = data.frequency.periods_per_annum();
                let coupon_payment = data.coupon * self.face_value / freq;
                let mut rows = Vec::new();

                for period in &data.periods {
                    let (df, npv) = match disc_curve {
                        Some(c) => {
                            let d = c.discount_factor(period.payment);
                            let n = &d * coupon_payment;
                            (Some(d), Some(n))
                        }
                        None => (None, None),
                    };

                    rows.push(CashflowRow {
                        period_type: "Fixed".to_string(),
                        start: period.start,
                        end: period.end,
                        payment: period.payment,
                        currency: self.currency.clone(),
                        notional: self.face_value,
                        fixing_rate: None,
                        rate: data.coupon,
                        spread: 0.0,
                        dcf: period.dcf,
                        cashflow: Number::F64(coupon_payment),
                        df,
                        npv,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                    });
                }

                // Principal redemption
                let (df_r, npv_r) = match disc_curve {
                    Some(c) => {
                        let d = c.discount_factor(self.termination);
                        let n = &d * self.face_value;
                        (Some(d), Some(n))
                    }
                    None => (None, None),
                };
                rows.push(CashflowRow {
                    period_type: "Cashflow".to_string(),
                    start: self.termination,
                    end: self.termination,
                    payment: self.termination,
                    currency: self.currency.clone(),
                    notional: self.face_value,
                    fixing_rate: None,
                    rate: 0.0,
                    spread: 0.0,
                    dcf: 0.0,
                    cashflow: Number::F64(self.face_value),
                    df: df_r,
                    npv: npv_r,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                });

                rows
            }
            BondVariant::Bill(_) => {
                let (df, npv) = match disc_curve {
                    Some(c) => {
                        let d = c.discount_factor(self.termination);
                        let n = &d * self.face_value;
                        (Some(d), Some(n))
                    }
                    None => (None, None),
                };
                vec![CashflowRow {
                    period_type: "Cashflow".to_string(),
                    start: self.effective,
                    end: self.termination,
                    payment: self.termination,
                    currency: self.currency.clone(),
                    notional: self.face_value,
                    fixing_rate: None,
                    rate: 0.0,
                    spread: 0.0,
                    dcf: self
                        .convention
                        .dcf(
                            self.effective,
                            self.termination,
                            &DcfOptions::default(),
                        )
                        .unwrap(),
                    cashflow: Number::F64(self.face_value),
                    df,
                    npv,
                settlement_amount: None,
                fx_rate: None,
                settlement_currency_label: None,
                }]
            }
            BondVariant::FloatRateNote(data) => {
                let mut rows = Vec::new();
                for period in &data.periods {
                    // Use fixing if set, otherwise project forward rate from curve + spread
                    let rate = period.fixing_rate.unwrap_or_else(|| {
                        if let Some(c) = disc_curve {
                            let fwd = c.forward_rate(period.start, period.end);
                            match fwd {
                                Number::F64(r) => r + data.spread,
                                Number::Dual(d) => d.real + data.spread,
                                Number::Dual2(d) => d.real + data.spread,
                            }
                        } else {
                            data.spread
                        }
                    });
                    let cf = rate * self.face_value * period.dcf;
                    let (df, npv) = match disc_curve {
                        Some(c) => {
                            let d = c.discount_factor(period.payment);
                            let n = &d * cf;
                            (Some(d), Some(n))
                        }
                        None => (None, None),
                    };
                    rows.push(CashflowRow {
                        period_type: "Float".to_string(),
                        start: period.start,
                        end: period.end,
                        payment: period.payment,
                        currency: self.currency.clone(),
                        notional: self.face_value,
                        fixing_rate: Some(Number::F64(rate - data.spread)),
                        rate,
                        spread: data.spread,
                        dcf: period.dcf,
                        cashflow: Number::F64(cf),
                        df,
                        npv,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                    });
                }
                // Redemption
                let (df_r, npv_r) = match disc_curve {
                    Some(c) => {
                        let d = c.discount_factor(self.termination);
                        let n = &d * self.face_value;
                        (Some(d), Some(n))
                    }
                    None => (None, None),
                };
                rows.push(CashflowRow {
                    period_type: "Cashflow".to_string(),
                    start: self.termination,
                    end: self.termination,
                    payment: self.termination,
                    currency: self.currency.clone(),
                    notional: self.face_value,
                    fixing_rate: None,
                    rate: 0.0,
                    spread: 0.0,
                    dcf: 0.0,
                    cashflow: Number::F64(self.face_value),
                    df: df_r,
                    npv: npv_r,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                });
                rows
            }
            BondVariant::ZeroCoupon(_) => {
                // Single redemption cashflow (same structure as Bill)
                let (df, npv) = match disc_curve {
                    Some(c) => {
                        let d = c.discount_factor(self.termination);
                        let n = &d * self.face_value;
                        (Some(d), Some(n))
                    }
                    None => (None, None),
                };
                vec![CashflowRow {
                    period_type: "Cashflow".to_string(),
                    start: self.effective,
                    end: self.termination,
                    payment: self.termination,
                    currency: self.currency.clone(),
                    notional: self.face_value,
                    fixing_rate: None,
                    rate: 0.0,
                    spread: 0.0,
                    dcf: self
                        .convention
                        .dcf(
                            self.effective,
                            self.termination,
                            &DcfOptions::default(),
                        )
                        .unwrap(),
                    cashflow: Number::F64(self.face_value),
                    df,
                    npv,
                settlement_amount: None,
                fx_rate: None,
                settlement_currency_label: None,
                }]
            }
            BondVariant::StepUp(data) => {
                let freq = data.frequency.periods_per_annum();
                let mut rows = Vec::new();

                for period in &data.periods {
                    let coupon_payment = period.coupon_rate * self.face_value / freq;
                    let (df, npv) = match disc_curve {
                        Some(c) => {
                            let d = c.discount_factor(period.payment);
                            let n = &d * coupon_payment;
                            (Some(d), Some(n))
                        }
                        None => (None, None),
                    };

                    rows.push(CashflowRow {
                        period_type: "StepUp".to_string(),
                        start: period.start,
                        end: period.end,
                        payment: period.payment,
                        currency: self.currency.clone(),
                        notional: self.face_value,
                        fixing_rate: None,
                        rate: period.coupon_rate,
                        spread: 0.0,
                        dcf: period.dcf,
                        cashflow: Number::F64(coupon_payment),
                        df,
                        npv,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                    });
                }

                // Principal redemption
                let (df_r, npv_r) = match disc_curve {
                    Some(c) => {
                        let d = c.discount_factor(self.termination);
                        let n = &d * self.face_value;
                        (Some(d), Some(n))
                    }
                    None => (None, None),
                };
                rows.push(CashflowRow {
                    period_type: "Cashflow".to_string(),
                    start: self.termination,
                    end: self.termination,
                    payment: self.termination,
                    currency: self.currency.clone(),
                    notional: self.face_value,
                    fixing_rate: None,
                    rate: 0.0,
                    spread: 0.0,
                    dcf: 0.0,
                    cashflow: Number::F64(self.face_value),
                    df: df_r,
                    npv: npv_r,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                });

                rows
            }
            BondVariant::Amortizing(data) => {
                let mut rows = Vec::new();

                for period in &data.periods {
                    // Coupon row: coupon on remaining notional
                    let coupon_amount = period.coupon_rate * period.notional * period.dcf;
                    let (df, npv) = match disc_curve {
                        Some(c) => {
                            let d = c.discount_factor(period.payment);
                            let n = &d * coupon_amount;
                            (Some(d), Some(n))
                        }
                        None => (None, None),
                    };

                    rows.push(CashflowRow {
                        period_type: "Amortizing".to_string(),
                        start: period.start,
                        end: period.end,
                        payment: period.payment,
                        currency: self.currency.clone(),
                        notional: period.notional,
                        fixing_rate: None,
                        rate: period.coupon_rate,
                        spread: 0.0,
                        dcf: period.dcf,
                        cashflow: Number::F64(coupon_amount),
                        df,
                        npv,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                    });

                    // Principal repayment row (if any)
                    if period.principal_repayment > 0.0 {
                        let (df_p, npv_p) = match disc_curve {
                            Some(c) => {
                                let d = c.discount_factor(period.payment);
                                let n = &d * period.principal_repayment;
                                (Some(d), Some(n))
                            }
                            None => (None, None),
                        };
                        rows.push(CashflowRow {
                            period_type: "Principal".to_string(),
                            start: period.start,
                            end: period.end,
                            payment: period.payment,
                            currency: self.currency.clone(),
                            notional: period.notional,
                            fixing_rate: None,
                            rate: 0.0,
                            spread: 0.0,
                            dcf: 0.0,
                            cashflow: Number::F64(period.principal_repayment),
                            df: df_p,
                            npv: npv_p,
                            settlement_amount: None,
                            fx_rate: None,
                            settlement_currency_label: None,
                        });
                    }
                }

                // Final redemption
                let (df_r, npv_r) = match disc_curve {
                    Some(c) => {
                        let d = c.discount_factor(self.termination);
                        let n = &d * data.final_redemption;
                        (Some(d), Some(n))
                    }
                    None => (None, None),
                };
                rows.push(CashflowRow {
                    period_type: "Cashflow".to_string(),
                    start: self.termination,
                    end: self.termination,
                    payment: self.termination,
                    currency: self.currency.clone(),
                    notional: data.final_redemption,
                    fixing_rate: None,
                    rate: 0.0,
                    spread: 0.0,
                    dcf: 0.0,
                    cashflow: Number::F64(data.final_redemption),
                    df: df_r,
                    npv: npv_r,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                });

                rows
            }
            BondVariant::PIK(data) => {
                let mut rows = Vec::new();

                for period in &data.periods {
                    let total_interest = period.coupon_rate * period.notional * period.dcf;
                    let cash_coupon = total_interest * (1.0 - period.pik_fraction);
                    let pik_interest = total_interest * period.pik_fraction;

                    // Cash coupon row
                    if cash_coupon > 0.0 {
                        let (df, npv) = match disc_curve {
                            Some(c) => {
                                let d = c.discount_factor(period.payment);
                                let n = &d * cash_coupon;
                                (Some(d), Some(n))
                            }
                            None => (None, None),
                        };
                        rows.push(CashflowRow {
                            period_type: "PIK".to_string(),
                            start: period.start,
                            end: period.end,
                            payment: period.payment,
                            currency: self.currency.clone(),
                            notional: period.notional,
                            fixing_rate: None,
                            rate: period.coupon_rate,
                            spread: 0.0,
                            dcf: period.dcf,
                            cashflow: Number::F64(cash_coupon),
                            df,
                            npv,
                        settlement_amount: None,
                        fx_rate: None,
                        settlement_currency_label: None,
                        });
                    }

                    // PIKAccrual row (informational, D-10)
                    if pik_interest > 0.0 {
                        rows.push(CashflowRow {
                            period_type: "PIKAccrual".to_string(),
                            start: period.start,
                            end: period.end,
                            payment: period.payment,
                            currency: self.currency.clone(),
                            notional: period.notional,
                            fixing_rate: None,
                            rate: period.coupon_rate,
                            spread: 0.0,
                            dcf: period.dcf,
                            cashflow: Number::F64(pik_interest),
                            df: None,
                            npv: None, // Non-cash -- no NPV
                            settlement_amount: None,
                            fx_rate: None,
                            settlement_currency_label: None,
                        });
                    }
                }

                // Final redemption at grown notional
                let (df_r, npv_r) = match disc_curve {
                    Some(c) => {
                        let d = c.discount_factor(self.termination);
                        let n = &d * data.final_notional;
                        (Some(d), Some(n))
                    }
                    None => (None, None),
                };
                rows.push(CashflowRow {
                    period_type: "Cashflow".to_string(),
                    start: self.termination,
                    end: self.termination,
                    payment: self.termination,
                    currency: self.currency.clone(),
                    notional: data.final_notional,
                    fixing_rate: None,
                    rate: 0.0,
                    spread: 0.0,
                    dcf: 0.0,
                    cashflow: Number::F64(data.final_notional),
                    df: df_r,
                    npv: npv_r,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                });

                rows
            }
            BondVariant::SubPeriodFRN(data) => {
                let mut rows = Vec::new();
                for period in &data.periods {
                    let rate = compounded_sub_period_rate(&period.sub_periods, disc_curve, data.spread);
                    let period_dcf: f64 = period.sub_periods.iter().map(|sp| sp.dcf).sum();
                    let cf = rate * self.face_value * period_dcf;
                    let (df, npv) = match disc_curve {
                        Some(c) => {
                            let d = c.discount_factor(period.payment);
                            let n = &d * cf;
                            (Some(d), Some(n))
                        }
                        None => (None, None),
                    };
                    rows.push(CashflowRow {
                        period_type: "SubPeriodFloat".to_string(),
                        start: period.start,
                        end: period.end,
                        payment: period.payment,
                        currency: self.currency.clone(),
                        notional: self.face_value,
                        fixing_rate: None,
                        rate,
                        spread: data.spread,
                        dcf: period_dcf,
                        cashflow: Number::F64(cf),
                        df,
                        npv,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                    });
                }
                // Redemption
                let (df_r, npv_r) = match disc_curve {
                    Some(c) => {
                        let d = c.discount_factor(self.termination);
                        let n = &d * self.face_value;
                        (Some(d), Some(n))
                    }
                    None => (None, None),
                };
                rows.push(CashflowRow {
                    period_type: "Cashflow".to_string(),
                    start: self.termination,
                    end: self.termination,
                    payment: self.termination,
                    currency: self.currency.clone(),
                    notional: self.face_value,
                    fixing_rate: None,
                    rate: 0.0,
                    spread: 0.0,
                    dcf: 0.0,
                    cashflow: Number::F64(self.face_value),
                    df: df_r,
                    npv: npv_r,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                });
                rows
            }
            BondVariant::CappedFloored(data) => {
                let mut rows = Vec::new();
                for period in &data.periods {
                    let effective_rate = if let Some(ref sub_periods) = period.sub_periods {
                        compounded_sub_period_rate(sub_periods, disc_curve, data.spread)
                    } else {
                        period.fixing_rate.unwrap_or_else(|| {
                            if let Some(c) = disc_curve {
                                let fwd = c.forward_rate(period.start, period.end);
                                match fwd {
                                    Number::F64(r) => r + data.spread,
                                    Number::Dual(d) => d.real + data.spread,
                                    Number::Dual2(d) => d.real + data.spread,
                                }
                            } else {
                                data.spread
                            }
                        })
                    };
                    let mut adjusted_rate = effective_rate;
                    if let Some(cap) = data.cap_rate {
                        adjusted_rate = adjusted_rate.min(cap);
                    }
                    if let Some(floor) = data.floor_rate {
                        adjusted_rate = adjusted_rate.max(floor);
                    }
                    let cf = adjusted_rate * self.face_value * period.dcf;
                    let (df, npv) = match disc_curve {
                        Some(c) => {
                            let d = c.discount_factor(period.payment);
                            let n = &d * cf;
                            (Some(d), Some(n))
                        }
                        None => (None, None),
                    };
                    rows.push(CashflowRow {
                        period_type: "CappedFloored".to_string(),
                        start: period.start,
                        end: period.end,
                        payment: period.payment,
                        currency: self.currency.clone(),
                        notional: self.face_value,
                        fixing_rate: period.fixing_rate.map(Number::F64),
                        rate: adjusted_rate,
                        spread: data.spread,
                        dcf: period.dcf,
                        cashflow: Number::F64(cf),
                        df,
                        npv,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                    });
                }
                // Redemption
                let (df_r, npv_r) = match disc_curve {
                    Some(c) => {
                        let d = c.discount_factor(self.termination);
                        let n = &d * self.face_value;
                        (Some(d), Some(n))
                    }
                    None => (None, None),
                };
                rows.push(CashflowRow {
                    period_type: "Cashflow".to_string(),
                    start: self.termination,
                    end: self.termination,
                    payment: self.termination,
                    currency: self.currency.clone(),
                    notional: self.face_value,
                    fixing_rate: None,
                    rate: 0.0,
                    spread: 0.0,
                    dcf: 0.0,
                    cashflow: Number::F64(self.face_value),
                    df: df_r,
                    npv: npv_r,
                    settlement_amount: None,
                    fx_rate: None,
                    settlement_currency_label: None,
                });
                rows
            }
        }
    }

    /// Z-spread equivalent for solver integration.
    pub fn spread(
        &self,
        disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
    ) -> Number {
        let clean = match self.price(disc_curve, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        Number::F64(self.z_spread(disc_curve, clean, None, "continuous"))
    }

    /// Pillar date: termination date.
    pub fn pillar_date(&self) -> NaiveDate {
        self.termination
    }

    /// Analytic delta: sum of -DCF_i * DF(payment_i) * notional / 10000 for each coupon.
    pub fn analytic_delta(
        &self,
        disc_curve: &dyn CurveQuery,
        _forecast_curve: &dyn CurveQuery,
    ) -> Number {
        match &self.variant {
            BondVariant::FixedRate(data) => {
                let mut total = Number::F64(0.0);
                for period in &data.periods {
                    let df = disc_curve.discount_factor(period.payment);
                    total = total + df * (-self.face_value * period.dcf / 10000.0);
                }
                total
            }
            BondVariant::Bill(_) => {
                let dcf = self
                    .convention
                    .dcf(
                        self.effective,
                        self.termination,
                        &DcfOptions::default(),
                    )
                    .unwrap();
                let df = disc_curve.discount_factor(self.termination);
                df * (-self.face_value * dcf / 10000.0)
            }
            BondVariant::FloatRateNote(data) => {
                let mut total = Number::F64(0.0);
                for period in &data.periods {
                    let df = disc_curve.discount_factor(period.payment);
                    total = total + df * (-self.face_value * period.dcf / 10000.0);
                }
                total
            }
            BondVariant::ZeroCoupon(_) => {
                // No coupons -- use same approach as Bill
                let dcf = self
                    .convention
                    .dcf(
                        self.effective,
                        self.termination,
                        &DcfOptions::default(),
                    )
                    .unwrap();
                let df = disc_curve.discount_factor(self.termination);
                df * (-self.face_value * dcf / 10000.0)
            }
            BondVariant::StepUp(data) => {
                let mut total = Number::F64(0.0);
                for period in &data.periods {
                    let df = disc_curve.discount_factor(period.payment);
                    total = total + df * (-self.face_value * period.dcf / 10000.0);
                }
                total
            }
            BondVariant::Amortizing(data) => {
                let mut total = Number::F64(0.0);
                for period in &data.periods {
                    let df = disc_curve.discount_factor(period.payment);
                    total = total + df * (-period.notional * period.dcf / 10000.0);
                }
                total
            }
            BondVariant::PIK(data) => {
                let mut total = Number::F64(0.0);
                for period in &data.periods {
                    let df = disc_curve.discount_factor(period.payment);
                    total = total + df * (-period.notional * period.dcf / 10000.0);
                }
                total
            }
            BondVariant::SubPeriodFRN(data) => {
                let mut total = Number::F64(0.0);
                for period in &data.periods {
                    let period_dcf: f64 = period.sub_periods.iter().map(|sp| sp.dcf).sum();
                    let df = disc_curve.discount_factor(period.payment);
                    total = total + df * (-self.face_value * period_dcf / 10000.0);
                }
                total
            }
            BondVariant::CappedFloored(data) => {
                let mut total = Number::F64(0.0);
                for period in &data.periods {
                    let df = disc_curve.discount_factor(period.payment);
                    total = total + df * (-self.face_value * period.dcf / 10000.0);
                }
                total
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Test helper
// ---------------------------------------------------------------------------

#[cfg(test)]
pub mod tests {
    use super::*;
    use crate::marketcurves::curve::DiscountCurve;
    use crate::marketcurves::interpolation::Interpolator;
    use crate::marketcurves::nodes::Nodes;
    use indexmap::IndexMap;

    fn ymd(y: i32, m: u32, d: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, d).unwrap()
    }

    fn test_curve() -> DiscountCurve {
        // Flat ~3% continuously compounded curve
        let nodes = Nodes::from_f64_map(IndexMap::from_iter(vec![
            (ymd(2024, 1, 1), 1.0),
            (ymd(2025, 1, 1), 0.9704),
            (ymd(2026, 1, 1), 0.9418),
            (ymd(2027, 1, 1), 0.9139),
            (ymd(2028, 1, 1), 0.8869),
            (ymd(2029, 1, 1), 0.8607),
        ]));
        DiscountCurve::new(
            nodes,
            Interpolator::LogLinear,
            DayCountConvention::Act365F,
            "test".to_string(),
        )
    }

    fn make_test_bond() -> BondInstrument {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        BondInstrument::new_fixed_rate(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            0.04, // 4% coupon
            Frequency::SemiAnnual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        )
    }

    pub fn make_test_bond_instrument() -> BondInstrument {
        make_test_bond()
    }

    #[test]
    fn test_fixed_rate_bond_price() {
        let curve = test_curve();
        let bond = make_test_bond();
        let price = bond.price(&curve, None);
        match price {
            Number::F64(p) => {
                // 4% coupon on ~3% curve should price above par
                assert!(
                    p > 100.0 && p < 110.0,
                    "Price should be in range 100-110, got {p}"
                );
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_fixed_rate_bond_accrued() {
        let bond = make_test_bond();
        // Accrued halfway through first period
        // First period: 2024-01-01 to 2024-07-01 (semiannual)
        let settlement = ymd(2024, 4, 1); // ~3 months in
        let accrued = bond.accrued_interest(settlement);
        // Expected: (days_from_start / days_in_period) * coupon * face / freq
        // ~ 0.5 * 0.04 * 100 / 2 = ~1.0
        assert!(
            accrued > 0.0 && accrued < 2.5,
            "Accrued should be reasonable, got {accrued}"
        );
    }

    #[test]
    fn test_fixed_rate_bond_ytm_roundtrip() {
        let bond = make_test_bond();
        let settlement = ymd(2024, 1, 1);
        // Compute price from ytm=4%
        let price_at_4pct = bond.price_from_ytm(0.04, settlement, "periodic");
        // Solve ytm from that price
        let ytm_solved = bond.ytm(price_at_4pct, settlement, "periodic");
        assert!(
            (ytm_solved - 0.04).abs() < 1e-6,
            "YTM roundtrip failed: expected 0.04, got {ytm_solved}"
        );
    }

    #[test]
    fn test_fixed_rate_bond_duration() {
        let curve = test_curve();
        let bond = make_test_bond();

        let mac_dur = bond.duration(&curve, "macaulay", None);
        let mod_dur = bond.duration(&curve, "modified", None);

        // Macaulay duration should be less than maturity (5 years)
        assert!(
            mac_dur > 0.0 && mac_dur < 5.0,
            "Macaulay duration should be in (0, 5), got {mac_dur}"
        );

        // Modified duration = Macaulay / (1 + y/freq)
        // Modified should be smaller than Macaulay
        assert!(
            mod_dur > 0.0 && mod_dur <= mac_dur,
            "Modified duration {mod_dur} should be <= Macaulay {mac_dur}"
        );
    }

    #[test]
    fn test_bill_price() {
        let curve = test_curve();
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let bill = BondInstrument::new_bill(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            100.0,
        );
        let price = bill.dirty_price(&curve, None, None);
        match price {
            Number::F64(p) => {
                // Bill price = face * DF(maturity) = 100 * 0.9704 = 97.04
                assert!(
                    (p - 97.04).abs() < 0.1,
                    "Bill price should be ~97.04, got {p}"
                );
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_bill_ytm() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let bill = BondInstrument::new_bill(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            100.0,
        );
        // Price the bill at discount
        let ytm = bill.ytm(97.0, ymd(2024, 1, 1), "periodic");
        // ytm should be positive (discount price)
        assert!(
            ytm > 0.0 && ytm < 0.1,
            "Bill YTM should be positive and reasonable, got {ytm}"
        );
    }

    #[test]
    fn test_frn_price() {
        let curve = test_curve();
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let frn = BondInstrument::new_float_rate_note(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            0.0, // 0bp spread
            Frequency::SemiAnnual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        );
        let price = frn.dirty_price(&curve, None, None);
        match price {
            Number::F64(p) => {
                // FRN with 0 spread on flat curve should price near par
                // The exact price depends on forward rate calculation
                assert!(
                    p > 80.0 && p < 120.0,
                    "FRN price should be near par, got {p}"
                );
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_bond_instrument_enum_dispatch() {
        use crate::instruments::Instrument;

        let curve = test_curve();
        let bond = make_test_bond();
        let inst = Instrument::Bond(bond);

        let rate = inst.rate(&curve, &curve, None, None, None);
        match rate {
            Number::F64(r) => assert!(r.is_finite(), "Bond rate should be finite, got {r}"),
            _ => panic!("Expected F64"),
        }

        let npv = inst.npv(&curve, &curve, None, None, None);
        match npv {
            Number::F64(v) => assert!(v.is_finite(), "Bond NPV should be finite, got {v}"),
            _ => panic!("Expected F64"),
        }

        let cfs = inst.cashflows(Some(&curve), Some(&curve), None, None, None);
        assert!(!cfs.is_empty(), "Bond should have cashflows");

        let spread = inst.spread(&curve, &curve, None, None, None);
        match spread {
            Number::F64(s) => assert!(s.is_finite(), "Bond spread should be finite, got {s}"),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_ex_dividend_handling() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let bond = BondInstrument::new_fixed_rate(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.04,
            Frequency::SemiAnnual,
            0,
            7, // 7 business days ex-div
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        );

        // Normal accrued (well before coupon date)
        let accrued_normal = bond.accrued_interest(ymd(2024, 4, 1));
        assert!(accrued_normal > 0.0, "Normal accrued should be positive");

        // Near coupon date (within ex-div period)
        // The first coupon is around 2024-07-01
        // 7 business days before = ~June 20
        // In ex-div: accrued should be negative (current coupon subtracted)
        let accrued_exdiv = bond.accrued_interest(ymd(2024, 6, 25));
        // The accrued in ex-div period = regular_accrued - full_period_coupon
        // This should be negative
        assert!(
            accrued_exdiv < accrued_normal,
            "Ex-div accrued ({accrued_exdiv}) should be less than normal ({accrued_normal})"
        );
    }

    #[test]
    fn test_z_spread_zero_on_par() {
        let curve = test_curve();
        let bond = make_test_bond();
        // Get model price
        let model_price = match bond.price(&curve, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        // Z-spread at model price should be near zero
        let z = bond.z_spread(&curve, model_price, None, "continuous");
        assert!(
            z.abs() < 0.001,
            "Z-spread at model price should be near 0, got {z}"
        );
    }

    // -----------------------------------------------------------------------
    // Convention tests (Task 1)
    // -----------------------------------------------------------------------

    fn make_5pct_bond() -> BondInstrument {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        BondInstrument::new_fixed_rate(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            0.05, // 5% coupon
            Frequency::SemiAnnual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        )
    }

    #[test]
    fn test_price_from_ytm_periodic_unchanged() {
        // Periodic convention should match existing behavior exactly
        let bond = make_5pct_bond();
        let settlement = ymd(2024, 1, 1);
        let price = bond.price_from_ytm(0.05, settlement, "periodic");
        // At par coupon = ytm, price should be near face value
        assert!(
            (price - 100.0).abs() < 1.0,
            "Periodic price at ytm=coupon should be near par, got {price}"
        );
    }

    #[test]
    fn test_price_from_ytm_annual() {
        let bond = make_5pct_bond();
        let settlement = ymd(2024, 1, 1);
        let price_periodic = bond.price_from_ytm(0.05, settlement, "periodic");
        let price_annual = bond.price_from_ytm(0.05, settlement, "annual");
        // Annual convention uses (1+ytm)^(-t) which for freq=2 gives different
        // discounting than (1+ytm/2)^(-n). For same ytm, annual gives lower price.
        assert!(
            (price_periodic - price_annual).abs() > 0.01,
            "Annual and periodic prices should differ: periodic={price_periodic}, annual={price_annual}"
        );
    }

    #[test]
    fn test_price_from_ytm_semi_annual() {
        let bond = make_5pct_bond();
        let settlement = ymd(2024, 1, 1);
        let price_periodic = bond.price_from_ytm(0.05, settlement, "periodic");
        let price_semi = bond.price_from_ytm(0.05, settlement, "semi_annual");
        // For a semi-annual bond, "semi_annual" convention (1+ytm/2)^(-2t) should
        // give the same result as "periodic" (1+ytm/freq)^(-n) when freq=2.
        assert!(
            (price_periodic - price_semi).abs() < 1e-10,
            "Semi-annual should match periodic for semi-annual bond: periodic={price_periodic}, semi={price_semi}"
        );
    }

    #[test]
    fn test_price_from_ytm_continuous() {
        let bond = make_5pct_bond();
        let settlement = ymd(2024, 1, 1);
        let price_periodic = bond.price_from_ytm(0.05, settlement, "periodic");
        let price_continuous = bond.price_from_ytm(0.05, settlement, "continuous");
        // Continuous discounting exp(-ytm*t) gives the lowest price for same ytm
        assert!(
            price_continuous < price_periodic,
            "Continuous price should be lower than periodic: continuous={price_continuous}, periodic={price_periodic}"
        );
    }

    #[test]
    fn test_ytm_convention_roundtrip() {
        let bond = make_5pct_bond();
        let settlement = ymd(2024, 1, 1);
        let target_ytm = 0.05;

        for conv in &["periodic", "annual", "semi_annual", "continuous"] {
            let price = bond.price_from_ytm(target_ytm, settlement, conv);
            let solved_ytm = bond.ytm(price, settlement, conv);
            assert!(
                (solved_ytm - target_ytm).abs() < 1e-10,
                "YTM roundtrip failed for convention '{conv}': expected {target_ytm}, got {solved_ytm}"
            );
        }
    }

    // -----------------------------------------------------------------------
    // Settlement threading tests (Task 2)
    // -----------------------------------------------------------------------

    #[test]
    fn test_duration_settlement_none_matches_default() {
        let curve = test_curve();
        let bond = make_test_bond();
        let dur_none = bond.duration(&curve, "modified", None);
        let dur_explicit = bond.duration(&curve, "modified", Some(ymd(2024, 1, 1)));
        assert!(
            (dur_none - dur_explicit).abs() < 1e-12,
            "duration(None) should match duration(Some(effective)): none={dur_none}, explicit={dur_explicit}"
        );
    }

    #[test]
    fn test_duration_with_explicit_settlement() {
        let curve = test_curve();
        let bond = make_test_bond();
        // Duration at effective
        let dur_effective = bond.duration(&curve, "modified", None);
        // Duration at a later settlement (6 months later -- within first coupon period)
        let dur_later = bond.duration(&curve, "modified", Some(ymd(2024, 7, 1)));
        // Duration should differ when settlement changes (shorter remaining life = lower duration)
        assert!(
            (dur_effective - dur_later).abs() > 0.01,
            "Duration should change with different settlement: effective={dur_effective}, later={dur_later}"
        );
    }

    #[test]
    fn test_convexity_settlement_none_matches_default() {
        let curve = test_curve();
        let bond = make_test_bond();
        let conv_none = bond.convexity(&curve, None);
        let conv_explicit = bond.convexity(&curve, Some(ymd(2024, 1, 1)));
        assert!(
            (conv_none - conv_explicit).abs() < 1e-10,
            "convexity(None) should match convexity(Some(effective)): none={conv_none}, explicit={conv_explicit}"
        );
    }

    #[test]
    fn test_z_spread_with_settlement() {
        let curve = test_curve();
        let bond = make_test_bond();
        // Z-spread at model price with None should be near 0
        let model_price = match bond.price(&curve, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let z_none = bond.z_spread(&curve, model_price, None, "continuous");
        assert!(
            z_none.abs() < 0.001,
            "Z-spread at model price (None) should be near 0, got {z_none}"
        );
        // Z-spread with explicit effective should match None
        let z_explicit = bond.z_spread(&curve, model_price, Some(ymd(2024, 1, 1)), "continuous");
        assert!(
            (z_none - z_explicit).abs() < 0.001,
            "Z-spread(None) should match Z-spread(Some(effective)): none={z_none}, explicit={z_explicit}"
        );
    }

    #[test]
    fn test_dirty_price_with_settlement() {
        let curve = test_curve();
        let bond = make_test_bond();
        // dirty_price with None should match dirty_price with Some(effective)
        let dp_none = match bond.dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let dp_explicit = match bond.dirty_price(&curve, Some(ymd(2024, 1, 1)), None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        assert!(
            (dp_none - dp_explicit).abs() < 1e-12,
            "dirty_price(None) should match dirty_price(Some(effective)): none={dp_none}, explicit={dp_explicit}"
        );
        // dirty_price with later settlement should differ (fewer cashflows)
        let dp_later = match bond.dirty_price(&curve, Some(ymd(2025, 1, 1)), None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        assert!(
            (dp_none - dp_later).abs() > 0.1,
            "dirty_price should differ with later settlement: none={dp_none}, later={dp_later}"
        );
    }

    // -----------------------------------------------------------------------
    // ZeroCouponBond tests
    // -----------------------------------------------------------------------

    fn make_zcb() -> BondInstrument {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        BondInstrument::new_zero_coupon(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            85.0, // issue_price
            Frequency::SemiAnnual,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            100.0,
        )
    }

    #[test]
    fn test_zcb_cashflows_single_redemption() {
        let zcb = make_zcb();
        let cfs = zcb.variant.bond_cashflows(ymd(2024, 1, 1), 100.0, zcb.termination, None);
        assert_eq!(cfs.len(), 1, "ZCB should have exactly 1 cashflow (redemption)");
        assert!(matches!(cfs[0].kind, CashflowKind::Redemption));
        match &cfs[0].amount {
            Number::F64(v) => assert!((v - 100.0).abs() < 1e-12),
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_zcb_accrued_oid() {
        let zcb = make_zcb();
        // At effective, accrued = 0
        assert_eq!(zcb.accrued_interest(ymd(2024, 1, 1)), 0.0);
        // At termination, accrued = 0
        assert_eq!(zcb.accrued_interest(ymd(2029, 1, 1)), 0.0);
        // Midlife: OID accrued should be positive
        let accrued = zcb.accrued_interest(ymd(2026, 7, 1));
        assert!(accrued > 0.0, "OID accrued should be positive, got {accrued}");
        // OID accrued uses compound method, grows over time
        // At midlife (~2.5 years into 5-year bond), should be meaningful
        assert!(accrued < 50.0, "OID accrued should be reasonable, got {accrued}");
    }

    #[test]
    fn test_zcb_oid_formula() {
        // Verify OID formula: face * (1+y)^elapsed - issue_price
        // where y = (face/issue_price)^(1/total_dcf) - 1
        let zcb = make_zcb();
        let settlement = ymd(2026, 7, 1);
        let total_dcf = DayCountConvention::Act365F.dcf(ymd(2024, 1, 1), ymd(2029, 1, 1), &DcfOptions::default()).unwrap();
        let elapsed_dcf = DayCountConvention::Act365F.dcf(ymd(2024, 1, 1), settlement, &DcfOptions::default()).unwrap();
        let y = (100.0_f64 / 85.0).powf(1.0 / total_dcf) - 1.0;
        let expected = 100.0 * (1.0 + y).powf(elapsed_dcf) - 85.0;
        let actual = zcb.accrued_interest(settlement);
        assert!((actual - expected).abs() < 1e-10, "OID accrued mismatch: expected {expected}, got {actual}");
    }

    #[test]
    fn test_zcb_price_from_ytm_compound() {
        let zcb = make_zcb();
        let settlement = ymd(2024, 1, 1);
        // Compound: face / (1 + ytm/freq)^(freq * dcf)
        let price = zcb.price_from_ytm(0.03, settlement, "periodic");
        let dcf = DayCountConvention::Act365F.dcf(settlement, ymd(2029, 1, 1), &DcfOptions::default()).unwrap();
        let expected = 100.0 / (1.0 + 0.03 / 2.0_f64).powf(2.0 * dcf);
        assert!((price - expected).abs() < 1e-10, "ZCB compound price: expected {expected}, got {price}");
    }

    #[test]
    fn test_zcb_price_from_ytm_not_simple_interest() {
        // ZCB uses compound discounting, NOT simple interest like Bill
        let zcb = make_zcb();
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let bill = BondInstrument::new_bill(
            ymd(2024, 1, 1), ymd(2029, 1, 1), 0, cal,
            "USD".to_string(), DayCountConvention::Act365F, 100.0,
        );
        let settlement = ymd(2024, 1, 1);
        let zcb_price = zcb.price_from_ytm(0.03, settlement, "periodic");
        let bill_price = bill.price_from_ytm(0.03, settlement, "periodic");
        assert!((zcb_price - bill_price).abs() > 0.01,
            "ZCB and Bill should differ: zcb={zcb_price}, bill={bill_price}");
    }

    #[test]
    fn test_zcb_ytm_roundtrip() {
        let zcb = make_zcb();
        let settlement = ymd(2024, 1, 1);
        let target_ytm = 0.035;
        let price = zcb.price_from_ytm(target_ytm, settlement, "periodic");
        let solved = zcb.ytm(price, settlement, "periodic");
        assert!((solved - target_ytm).abs() < 1e-6, "ZCB YTM roundtrip: expected {target_ytm}, got {solved}");
    }

    #[test]
    fn test_zcb_frequency() {
        let zcb = make_zcb();
        assert!((zcb.variant.frequency() - 2.0).abs() < 1e-12, "ZCB frequency should be 2.0 (semi-annual)");
    }

    #[test]
    fn test_zcb_is_ex_dividend_false() {
        let zcb = make_zcb();
        assert!(!zcb.is_ex_dividend(ymd(2026, 1, 1)), "ZCB should never be ex-dividend");
    }

    // -----------------------------------------------------------------------
    // StepUpBond tests
    // -----------------------------------------------------------------------

    fn make_step_up() -> BondInstrument {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        BondInstrument::new_step_up(
            ymd(2024, 1, 1),
            ymd(2029, 1, 1),
            vec![
                (ymd(2024, 1, 1), 0.03),  // 3% initially
                (ymd(2026, 1, 1), 0.04),  // steps to 4%
                (ymd(2028, 1, 1), 0.05),  // steps to 5%
            ],
            Frequency::SemiAnnual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        )
    }

    #[test]
    fn test_step_up_varying_rates() {
        let bond = make_step_up();
        match &bond.variant {
            BondVariant::StepUp(data) => {
                // First few periods should have 3% rate
                assert!((data.periods[0].coupon_rate - 0.03).abs() < 1e-12, "First period should be 3%");
                // Period starting on or after 2026-01-01 should have 4%
                let mid_period = data.periods.iter().find(|p| p.start >= ymd(2026, 1, 1) && p.start < ymd(2028, 1, 1));
                if let Some(p) = mid_period {
                    assert!((p.coupon_rate - 0.04).abs() < 1e-12, "Mid periods should be 4%, got {}", p.coupon_rate);
                }
                // Period starting on or after 2028-01-01 should have 5%
                let late_period = data.periods.iter().find(|p| p.start >= ymd(2028, 1, 1));
                if let Some(p) = late_period {
                    assert!((p.coupon_rate - 0.05).abs() < 1e-12, "Late periods should be 5%, got {}", p.coupon_rate);
                }
            }
            _ => panic!("Expected StepUp variant"),
        }
    }

    #[test]
    fn test_step_up_cashflows_varying() {
        let bond = make_step_up();
        let cfs = bond.variant.bond_cashflows(ymd(2024, 1, 1), 100.0, bond.termination, None);
        // Should have coupons + redemption
        assert!(cfs.len() > 1, "StepUp should have multiple cashflows");
        // Last should be redemption
        assert!(matches!(cfs.last().unwrap().kind, CashflowKind::Redemption));
        // Coupon amounts should vary
        let coupon_amounts: Vec<f64> = cfs.iter()
            .filter(|cf| matches!(cf.kind, CashflowKind::Coupon))
            .map(|cf| match &cf.amount { Number::F64(v) => *v, _ => 0.0 })
            .collect();
        assert!(coupon_amounts.len() >= 2);
        // First and last coupon should differ (3% vs 5%)
        let first = coupon_amounts[0];
        let last = coupon_amounts[coupon_amounts.len() - 1];
        assert!((first - last).abs() > 0.01, "Step-up coupons should differ: first={first}, last={last}");
    }

    #[test]
    fn test_step_up_accrued_interest() {
        let bond = make_step_up();
        let settlement = ymd(2024, 4, 1);
        let accrued = bond.accrued_interest(settlement);
        assert!(accrued > 0.0, "StepUp accrued should be positive, got {accrued}");
        // Should use 3% rate for first period
        // ~3 months in 6-month period: ~0.5 * 0.03 * 100 / 2 = ~0.75
        assert!(accrued < 2.0, "StepUp accrued should be reasonable, got {accrued}");
    }

    #[test]
    fn test_step_up_price_from_ytm_roundtrip() {
        let bond = make_step_up();
        let settlement = ymd(2024, 1, 1);
        let target_ytm = 0.04;
        let price = bond.price_from_ytm(target_ytm, settlement, "periodic");
        let solved = bond.ytm(price, settlement, "periodic");
        assert!((solved - target_ytm).abs() < 1e-6,
            "StepUp YTM roundtrip: expected {target_ytm}, got {solved}");
    }

    #[test]
    fn test_step_up_frequency() {
        let bond = make_step_up();
        assert!((bond.variant.frequency() - 2.0).abs() < 1e-12);
    }

    // -----------------------------------------------------------------------
    // I-spread test
    // -----------------------------------------------------------------------

    #[test]
    fn test_i_spread_fixed_rate() {
        let curve = test_curve();
        let bond = make_test_bond();
        let settlement = ymd(2024, 1, 1);
        let ispread = bond.i_spread(settlement, &curve);
        // I-spread = YTM - swap_rate; for a bond priced off its own curve, should be modest
        assert!(ispread.is_finite(), "I-spread should be finite, got {ispread}");
    }

    // -----------------------------------------------------------------------
    // AmortizingBond tests (Phase 21)
    // -----------------------------------------------------------------------

    fn make_amortizing_bond() -> BondInstrument {
        // 3 semiannual periods, face=100, coupon=0.05
        // Amortization: 30 at period 1 end (2024-07-01), 20 at period 2 end (2025-01-01)
        // Final redemption = 100 - 30 - 20 = 50
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        BondInstrument::new_amortizing(
            ymd(2024, 1, 1),
            ymd(2025, 7, 1),
            0.05,
            vec![
                (ymd(2024, 7, 1), 30.0),
                (ymd(2025, 1, 1), 20.0),
            ],
            Frequency::SemiAnnual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        )
    }

    #[test]
    fn test_amortizing_construction() {
        let bond = make_amortizing_bond();
        match &bond.variant {
            BondVariant::Amortizing(data) => {
                assert_eq!(data.periods.len(), 3, "Should have 3 periods");
                // Period 1: notional = 100
                assert!((data.periods[0].notional - 100.0).abs() < 1e-12);
                assert!((data.periods[0].principal_repayment - 30.0).abs() < 1e-12);
                // Period 2: notional = 70
                assert!((data.periods[1].notional - 70.0).abs() < 1e-12);
                assert!((data.periods[1].principal_repayment - 20.0).abs() < 1e-12);
                // Period 3: notional = 50
                assert!((data.periods[2].notional - 50.0).abs() < 1e-12);
                assert!((data.periods[2].principal_repayment - 0.0).abs() < 1e-12);
                // Final redemption = 50
                assert!((data.final_redemption - 50.0).abs() < 1e-12);
            }
            _ => panic!("Expected Amortizing variant"),
        }
    }

    #[test]
    fn test_amortizing_cashflows() {
        let bond = make_amortizing_bond();
        let cfs = bond.variant.bond_cashflows(ymd(2024, 1, 1), bond.face_value, bond.termination, None);
        // Should have: 3 coupons + 2 principal + 1 redemption = 6 cashflows
        let coupons: Vec<&BondCashflow> = cfs.iter().filter(|c| matches!(c.kind, CashflowKind::Coupon)).collect();
        let principals: Vec<&BondCashflow> = cfs.iter().filter(|c| matches!(c.kind, CashflowKind::Principal)).collect();
        let redemptions: Vec<&BondCashflow> = cfs.iter().filter(|c| matches!(c.kind, CashflowKind::Redemption)).collect();

        assert_eq!(coupons.len(), 3, "Should have 3 coupon cashflows");
        assert_eq!(principals.len(), 2, "Should have 2 principal cashflows");
        assert_eq!(redemptions.len(), 1, "Should have 1 redemption cashflow");

        // Principal amounts
        match &principals[0].amount { Number::F64(v) => assert!((v - 30.0).abs() < 1e-12), _ => panic!() }
        match &principals[1].amount { Number::F64(v) => assert!((v - 20.0).abs() < 1e-12), _ => panic!() }

        // Final redemption = 50
        match &redemptions[0].amount { Number::F64(v) => assert!((v - 50.0).abs() < 1e-12), _ => panic!() }

        // Coupon amounts should decline: period 1 > period 2 > period 3
        let c1 = match &coupons[0].amount { Number::F64(v) => *v, _ => panic!() };
        let c2 = match &coupons[1].amount { Number::F64(v) => *v, _ => panic!() };
        let c3 = match &coupons[2].amount { Number::F64(v) => *v, _ => panic!() };
        assert!(c1 > c2, "Coupon 1 ({c1}) should be > Coupon 2 ({c2})");
        assert!(c2 > c3, "Coupon 2 ({c2}) should be > Coupon 3 ({c3})");
    }

    #[test]
    fn test_amortizing_dirty_price() {
        let curve = test_curve();
        let bond = make_amortizing_bond();
        let dp = bond.dirty_price(&curve, None, None);
        match dp {
            Number::F64(v) => {
                assert!(v > 50.0 && v < 150.0, "Dirty price should be reasonable, got {v}");
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_amortizing_accrued() {
        let bond = make_amortizing_bond();
        // At midpoint of period 2 (after first principal repayment of 30)
        // Period 2: start=2024-07-01, end=2025-01-01
        let settlement = ymd(2024, 10, 1); // ~3 months into period 2
        let accrued = bond.accrued_interest(settlement);
        // Should use notional=70, not 100
        // period_coupon = 0.05 * 70 / 2 = 1.75
        // accrued = fraction * 1.75
        assert!(accrued > 0.0, "Accrued should be positive, got {accrued}");
        // Max for the period = 1.75, should be less than that
        assert!(accrued < 1.8, "Accrued should use notional=70, got {accrued}");
    }

    #[test]
    fn test_amortizing_ytm_roundtrip() {
        let bond = make_amortizing_bond();
        let settlement = ymd(2024, 1, 1);
        let target_ytm = 0.05;
        let price = bond.price_from_ytm(target_ytm, settlement, "periodic");
        let solved = bond.ytm(price, settlement, "periodic");
        assert!(
            (solved - target_ytm).abs() < 1e-6,
            "Amortizing YTM roundtrip: expected {target_ytm}, got {solved}"
        );
    }

    // -----------------------------------------------------------------------
    // PIKBond tests (Phase 21)
    // -----------------------------------------------------------------------

    fn make_pik_bond() -> BondInstrument {
        // Full PIK bond: face=100, coupon=0.06, pik_fraction=1.0, 2 semiannual periods
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        BondInstrument::new_pik(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.06,
            1.0, // full PIK
            Frequency::SemiAnnual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        )
    }

    #[test]
    fn test_pik_construction() {
        let bond = make_pik_bond();
        match &bond.variant {
            BondVariant::PIK(data) => {
                assert_eq!(data.periods.len(), 2, "Should have 2 periods");
                // Period 1: notional = 100
                assert!((data.periods[0].notional - 100.0).abs() < 1e-12);
                // Period 2: notional = 100 + 0.06 * 100 * dcf1 (grown by PIK)
                let dcf1 = data.periods[0].dcf;
                let expected_n2 = 100.0 + 0.06 * 100.0 * dcf1;
                assert!(
                    (data.periods[1].notional - expected_n2).abs() < 1e-6,
                    "Period 2 notional should be {expected_n2}, got {}",
                    data.periods[1].notional
                );
                // Final notional should be grown after period 2
                let dcf2 = data.periods[1].dcf;
                let expected_final = expected_n2 + 0.06 * expected_n2 * dcf2;
                assert!(
                    (data.final_notional - expected_final).abs() < 1e-6,
                    "Final notional should be {expected_final}, got {}",
                    data.final_notional
                );
            }
            _ => panic!("Expected PIK variant"),
        }
    }

    #[test]
    fn test_pik_cashflows() {
        let bond = make_pik_bond();
        let cfs = bond.variant.bond_cashflows(ymd(2024, 1, 1), bond.face_value, bond.termination, None);
        // Full PIK: no cash coupons, only redemption
        let coupons: Vec<&BondCashflow> = cfs.iter().filter(|c| matches!(c.kind, CashflowKind::Coupon)).collect();
        let pik_accruals: Vec<&BondCashflow> = cfs.iter().filter(|c| matches!(c.kind, CashflowKind::PIKAccrual)).collect();
        let redemptions: Vec<&BondCashflow> = cfs.iter().filter(|c| matches!(c.kind, CashflowKind::Redemption)).collect();

        assert_eq!(coupons.len(), 0, "Full PIK should have no cash coupons");
        assert_eq!(pik_accruals.len(), 0, "PIKAccrual should NOT be in bond_cashflows");
        assert_eq!(redemptions.len(), 1, "Should have 1 redemption");

        // Redemption should be at grown notional
        match &bond.variant {
            BondVariant::PIK(data) => {
                match &redemptions[0].amount {
                    Number::F64(v) => assert!(
                        (v - data.final_notional).abs() < 1e-6,
                        "Redemption should be at final_notional {}, got {v}",
                        data.final_notional
                    ),
                    _ => panic!(),
                }
            }
            _ => panic!(),
        }
    }

    #[test]
    fn test_pik_dirty_price() {
        let curve = test_curve();
        let bond = make_pik_bond();
        let dp = bond.dirty_price(&curve, None, None);
        match dp {
            Number::F64(v) => {
                // PIK bond with full PIK: dirty price = PV(final_notional)
                // final_notional > 100, so price should reflect that
                assert!(v > 90.0, "PIK dirty price should be > 90, got {v}");
            }
            _ => panic!("Expected F64"),
        }
    }

    #[test]
    fn test_pik_notional_schedule() {
        let bond = make_pik_bond();
        let schedule = bond.notional_schedule();
        // Should have entries: period1 start, period2 start, termination
        assert!(schedule.len() >= 3, "Notional schedule should have at least 3 entries, got {}", schedule.len());
        // First entry should be face value
        assert!((schedule[0].1 - 100.0).abs() < 1e-12);
        // Last entry should be final_notional (grown)
        match &bond.variant {
            BondVariant::PIK(data) => {
                assert!((schedule.last().unwrap().1 - data.final_notional).abs() < 1e-6);
            }
            _ => panic!(),
        }
    }

    #[test]
    fn test_partial_pik() {
        // pik_fraction=0.5: 50% compounds, 50% paid as cash
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let bond = BondInstrument::new_pik(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.06,
            0.5, // partial PIK
            Frequency::SemiAnnual,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act365F,
            DayCountConvention::Act365F,
            100.0,
            Adjuster::ModifiedFollowing,
        );

        let cfs = bond.variant.bond_cashflows(ymd(2024, 1, 1), bond.face_value, bond.termination, None);
        let coupons: Vec<&BondCashflow> = cfs.iter().filter(|c| matches!(c.kind, CashflowKind::Coupon)).collect();
        let redemptions: Vec<&BondCashflow> = cfs.iter().filter(|c| matches!(c.kind, CashflowKind::Redemption)).collect();

        // Partial PIK: should have cash coupons (50% of interest)
        assert_eq!(coupons.len(), 2, "Partial PIK should have 2 cash coupons");
        assert_eq!(redemptions.len(), 1, "Should have 1 redemption");

        // Cash coupon should be 50% of total interest
        match &bond.variant {
            BondVariant::PIK(data) => {
                let total_interest_p1 = 0.06 * data.periods[0].notional * data.periods[0].dcf;
                let expected_cash = total_interest_p1 * 0.5;
                match &coupons[0].amount {
                    Number::F64(v) => assert!(
                        (v - expected_cash).abs() < 1e-6,
                        "Cash coupon should be {expected_cash}, got {v}"
                    ),
                    _ => panic!(),
                }
                // Notional growth should be less than full PIK
                assert!(
                    data.final_notional < 106.5, // rough upper bound for partial PIK
                    "Partial PIK final notional should be less than full PIK"
                );
                assert!(
                    data.final_notional > 100.0,
                    "Partial PIK final notional should be > face"
                );
            }
            _ => panic!(),
        }
    }

    #[test]
    fn test_pik_ytm_roundtrip() {
        let bond = make_pik_bond();
        let settlement = ymd(2024, 1, 1);
        let target_ytm = 0.06;
        let price = bond.price_from_ytm(target_ytm, settlement, "periodic");
        let solved = bond.ytm(price, settlement, "periodic");
        assert!(
            (solved - target_ytm).abs() < 1e-6,
            "PIK YTM roundtrip: expected {target_ytm}, got {solved}"
        );
    }

    #[test]
    fn test_price_with_settlement() {
        let curve = test_curve();
        let bond = make_test_bond();
        // price with None should match price with Some(effective)
        let p_none = match bond.price(&curve, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let p_explicit = match bond.price(&curve, Some(ymd(2024, 1, 1))) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        assert!(
            (p_none - p_explicit).abs() < 1e-12,
            "price(None) should match price(Some(effective)): none={p_none}, explicit={p_explicit}"
        );
    }

    // -----------------------------------------------------------------------
    // SubPeriodFRN tests
    // -----------------------------------------------------------------------

    fn make_sub_period_frn() -> BondInstrument {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        BondInstrument::new_sub_period_frn(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.001, // 10bp spread
            Frequency::Quarterly,
            Frequency::Monthly,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act360,
            DayCountConvention::Act360,
            100.0,
            Adjuster::ModifiedFollowing,
        )
    }

    #[test]
    fn test_sub_period_frn_construction() {
        let bond = make_sub_period_frn();
        match &bond.variant {
            BondVariant::SubPeriodFRN(data) => {
                // 1Y quarterly = 4 coupon periods
                assert_eq!(data.periods.len(), 4, "Expected 4 coupon periods, got {}", data.periods.len());
                // Each coupon period should have ~3 sub-periods (monthly in quarterly)
                for (i, period) in data.periods.iter().enumerate() {
                    assert!(
                        period.sub_periods.len() >= 2 && period.sub_periods.len() <= 4,
                        "Period {i} should have 2-4 sub-periods, got {}",
                        period.sub_periods.len()
                    );
                }
            }
            _ => panic!("Expected SubPeriodFRN variant"),
        }
    }

    #[test]
    fn test_sub_period_frn_compounding() {
        let mut bond = make_sub_period_frn();
        // Set fixing rates manually to verify compounding formula
        if let BondVariant::SubPeriodFRN(ref mut data) = bond.variant {
            for sp in &mut data.periods[0].sub_periods {
                sp.fixing_rate = Some(0.03); // 3% flat
            }
        }

        if let BondVariant::SubPeriodFRN(ref data) = bond.variant {
            let period = &data.periods[0];
            // Manual compounding: Product(1 + 0.03 * dcf_i) - 1 + spread
            let mut product = 1.0;
            for sp in &period.sub_periods {
                product *= 1.0 + 0.03 * sp.dcf;
            }
            let expected_rate = (product - 1.0) + data.spread;
            let computed = compounded_sub_period_rate(&period.sub_periods, None, data.spread);
            assert!(
                (computed - expected_rate).abs() < 1e-12,
                "Compounding mismatch: expected {expected_rate}, got {computed}"
            );
        }
    }

    #[test]
    fn test_sub_period_frn_bond_cashflows() {
        let mut bond = make_sub_period_frn();
        // Set all fixing rates so we don't need a curve
        if let BondVariant::SubPeriodFRN(ref mut data) = bond.variant {
            for period in &mut data.periods {
                for sp in &mut period.sub_periods {
                    sp.fixing_rate = Some(0.03);
                }
            }
        }

        let cfs = bond.variant.bond_cashflows(ymd(2024, 1, 1), bond.face_value, bond.termination, None);
        let coupons: Vec<_> = cfs.iter().filter(|c| matches!(c.kind, CashflowKind::Coupon)).collect();
        let redemptions: Vec<_> = cfs.iter().filter(|c| matches!(c.kind, CashflowKind::Redemption)).collect();

        assert_eq!(coupons.len(), 4, "Expected 4 coupons for 1Y quarterly, got {}", coupons.len());
        assert_eq!(redemptions.len(), 1, "Expected 1 redemption");

        // All coupons should be positive
        for cf in &coupons {
            match cf.amount {
                Number::F64(v) => assert!(v > 0.0, "Coupon should be positive, got {v}"),
                _ => panic!("Expected F64"),
            }
        }
    }

    #[test]
    fn test_sub_period_frn_ytm_roundtrip() {
        let mut bond = make_sub_period_frn();
        if let BondVariant::SubPeriodFRN(ref mut data) = bond.variant {
            for period in &mut data.periods {
                for sp in &mut period.sub_periods {
                    sp.fixing_rate = Some(0.03);
                }
            }
        }

        let curve = test_curve();
        let settlement = ymd(2024, 1, 1);
        let dp = match bond.dirty_price(&curve, Some(settlement), None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        // SubPeriodFRN price_from_ytm returns face_value (simplified)
        // Just verify dirty_price is reasonable
        assert!(dp > 80.0 && dp < 120.0, "SubPeriodFRN dirty price should be near par, got {dp}");
    }

    #[test]
    fn test_sub_period_frn_sub_period_schedule() {
        let bond = make_sub_period_frn();
        let sched = bond.sub_period_schedule();
        assert!(sched.is_some(), "SubPeriodFRN should return sub-period schedule");
        let sched = sched.unwrap();
        assert_eq!(sched.len(), 4, "Expected 4 coupon period entries");
        for (i, (start, end, _payment, sub_info)) in sched.iter().enumerate() {
            assert!(start < end, "Period {i}: start should be before end");
            assert!(!sub_info.is_empty(), "Period {i}: should have sub-period info");
            for (j, (s, e, dcf, _fixing)) in sub_info.iter().enumerate() {
                assert!(s < e, "Period {i} sub {j}: start should be before end");
                assert!(*dcf > 0.0, "Period {i} sub {j}: dcf should be positive");
            }
        }
    }

    // -----------------------------------------------------------------------
    // CappedFloored tests
    // -----------------------------------------------------------------------

    fn make_capped_frn() -> BondInstrument {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        BondInstrument::new_capped_floored(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.001,
            Frequency::Quarterly,
            None, // standard FRN (no sub-periods)
            Some(0.05), // cap at 5%
            None,
            0.20, // 20% vol
            VolModel::Black76,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act360,
            DayCountConvention::Act360,
            100.0,
            Adjuster::ModifiedFollowing,
        )
    }

    fn make_floored_frn() -> BondInstrument {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        BondInstrument::new_capped_floored(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.001,
            Frequency::Quarterly,
            None,
            None,
            Some(0.01), // floor at 1%
            0.20,
            VolModel::Black76,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act360,
            DayCountConvention::Act360,
            100.0,
            Adjuster::ModifiedFollowing,
        )
    }

    #[test]
    fn test_capped_floored_cap_reduces_coupon() {
        let curve = test_curve();
        let capped = make_capped_frn();

        // Compare with uncapped FRN
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let uncapped = BondInstrument::new_float_rate_note(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.001,
            Frequency::Quarterly,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act360,
            DayCountConvention::Act360,
            100.0,
            Adjuster::ModifiedFollowing,
        );

        let capped_dp = match capped.dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let uncapped_dp = match uncapped.dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };

        // Cap reduces value (issuer benefits from cap, holder loses)
        assert!(
            capped_dp <= uncapped_dp + 0.01, // allow tiny numerical tolerance
            "Capped FRN dirty price ({capped_dp}) should be <= uncapped ({uncapped_dp})"
        );
    }

    #[test]
    fn test_capped_floored_floor_increases_coupon() {
        let curve = test_curve();
        let floored = make_floored_frn();

        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let unfloored = BondInstrument::new_float_rate_note(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.001,
            Frequency::Quarterly,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act360,
            DayCountConvention::Act360,
            100.0,
            Adjuster::ModifiedFollowing,
        );

        let floored_dp = match floored.dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let unfloored_dp = match unfloored.dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };

        // Floor increases value (holder benefits from floor)
        assert!(
            floored_dp >= unfloored_dp - 0.01,
            "Floored FRN dirty price ({floored_dp}) should be >= unfloored ({unfloored_dp})"
        );
    }

    #[test]
    fn test_capped_floored_collar() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let collar = BondInstrument::new_capped_floored(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.001,
            Frequency::Quarterly,
            None,
            Some(0.05), // cap at 5%
            Some(0.01), // floor at 1%
            0.20,
            VolModel::Black76,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act360,
            DayCountConvention::Act360,
            100.0,
            Adjuster::ModifiedFollowing,
        );

        let curve = test_curve();
        let collar_dp = match collar.dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let capped_dp = match make_capped_frn().dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let floored_dp = match make_floored_frn().dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };

        // Collar should be between capped-only and floored-only
        let lower = capped_dp.min(floored_dp) - 0.1;
        let upper = capped_dp.max(floored_dp) + 0.1;
        assert!(
            collar_dp >= lower && collar_dp <= upper,
            "Collar ({collar_dp}) should be between capped ({capped_dp}) and floored ({floored_dp})"
        );
    }

    #[test]
    fn test_capped_floored_with_sub_periods() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let capped_sub = BondInstrument::new_capped_floored(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.001,
            Frequency::Quarterly,
            Some(Frequency::Monthly), // sub-period compounding
            Some(0.05),
            None,
            0.20,
            VolModel::Black76,
            0,
            0,
            cal.clone(),
            "USD".to_string(),
            DayCountConvention::Act360,
            DayCountConvention::Act360,
            100.0,
            Adjuster::ModifiedFollowing,
        );

        // Verify it has sub-periods
        match &capped_sub.variant {
            BondVariant::CappedFloored(data) => {
                assert!(data.fixing_frequency.is_some());
                for period in &data.periods {
                    assert!(period.sub_periods.is_some(), "Should have sub-periods");
                    let sps = period.sub_periods.as_ref().unwrap();
                    assert!(sps.len() >= 2, "Should have multiple sub-periods");
                }
            }
            _ => panic!("Expected CappedFloored variant"),
        }

        let curve = test_curve();
        let dp = match capped_sub.dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        assert!(dp > 80.0 && dp < 120.0, "CappedFloored with sub-periods price should be reasonable, got {dp}");
    }

    #[test]
    fn test_capped_floored_vol_model_difference() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        let black76 = BondInstrument::new_capped_floored(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.001,
            Frequency::Quarterly,
            None,
            Some(0.05),
            None,
            0.20,
            VolModel::Black76,
            0,
            0,
            cal.clone(),
            "USD".to_string(),
            DayCountConvention::Act360,
            DayCountConvention::Act360,
            100.0,
            Adjuster::ModifiedFollowing,
        );

        let bachelier = BondInstrument::new_capped_floored(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.001,
            Frequency::Quarterly,
            None,
            Some(0.05),
            None,
            0.005, // Bachelier vol is in absolute terms (50bp)
            VolModel::Bachelier,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act360,
            DayCountConvention::Act360,
            100.0,
            Adjuster::ModifiedFollowing,
        );

        let curve = test_curve();
        let black76_dp = match black76.dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };
        let bachelier_dp = match bachelier.dirty_price(&curve, None, None) {
            Number::F64(v) => v,
            Number::Dual(d) => d.real,
            Number::Dual2(d) => d.real,
        };

        // They should produce different values (different models, different vol conventions)
        assert!(
            (black76_dp - bachelier_dp).abs() > 1e-6,
            "Black76 ({black76_dp}) and Bachelier ({bachelier_dp}) should differ"
        );
    }

    #[test]
    #[should_panic(expected = "CappedFloored requires at least one of cap_rate or floor_rate")]
    fn test_capped_floored_requires_strike() {
        let cal = BusinessCalendar::new_custom(vec![], vec![5, 6]);
        BondInstrument::new_capped_floored(
            ymd(2024, 1, 1),
            ymd(2025, 1, 1),
            0.001,
            Frequency::Quarterly,
            None,
            None, // no cap
            None, // no floor -- should panic
            0.20,
            VolModel::Black76,
            0,
            0,
            cal,
            "USD".to_string(),
            DayCountConvention::Act360,
            DayCountConvention::Act360,
            100.0,
            Adjuster::ModifiedFollowing,
        );
    }
}
