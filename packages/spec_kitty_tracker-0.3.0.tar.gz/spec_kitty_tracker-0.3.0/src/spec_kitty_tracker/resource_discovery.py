# DEPRECATED: Use spec_kitty_tracker.discovery instead.
#
# This module is a thin backward-compatibility shim.  All functional
# resource discovery is now handled by the registry-based discoverers
# in ``spec_kitty_tracker.discovery.providers``.

from spec_kitty_tracker.discovery.types import DiscoveredResource, DiscoveryResult
from spec_kitty_tracker.discovery import discover_resources

__all__ = [
    "DiscoveredResource",
    "DiscoveryResult",
    "discover_resources",
]
