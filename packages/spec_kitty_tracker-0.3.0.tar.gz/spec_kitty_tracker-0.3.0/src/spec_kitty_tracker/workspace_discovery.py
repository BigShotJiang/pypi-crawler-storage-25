# DEPRECATED: Use spec_kitty_tracker.discovery instead.
#
# This module is a thin backward-compatibility shim.  All functional
# workspace discovery is now handled by the registry-based discoverers
# in ``spec_kitty_tracker.discovery.providers``.

from spec_kitty_tracker.discovery.types import DiscoveredWorkspace, DiscoveryResult
from spec_kitty_tracker.discovery import discover_workspaces

__all__ = [
    "DiscoveredWorkspace",
    "DiscoveryResult",
    "discover_workspaces",
]
