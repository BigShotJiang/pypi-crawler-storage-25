"""Discovery package: public entry points and type re-exports."""

from __future__ import annotations

from spec_kitty_tracker.discovery import providers as _providers  # noqa: F401
from spec_kitty_tracker.discovery.registry import (
    get_resource_discoverer,
    get_workspace_discoverer,
)
from spec_kitty_tracker.discovery.types import (
    DiscoveredResource,
    DiscoveredWorkspace,
    DiscoveryResult,
)
from spec_kitty_tracker.nango import NangoConnectionContext

__all__ = [
    "DiscoveredResource",
    "DiscoveredWorkspace",
    "DiscoveryResult",
    "discover_resources",
    "discover_workspaces",
]


async def discover_workspaces(
    provider: str,
    nango_ctx: NangoConnectionContext,
) -> DiscoveryResult[DiscoveredWorkspace]:
    """Discover workspaces for *provider* via the registered factory."""
    factory = get_workspace_discoverer(provider)
    discoverer = factory(nango_ctx)
    return await discoverer.discover()


async def discover_resources(
    provider: str,
    workspace: DiscoveredWorkspace,
    nango_ctx: NangoConnectionContext,
) -> DiscoveryResult[DiscoveredResource]:
    """Discover resources for *provider* within *workspace*."""
    factory = get_resource_discoverer(provider)
    discoverer = factory(nango_ctx)
    return await discoverer.discover(workspace)
