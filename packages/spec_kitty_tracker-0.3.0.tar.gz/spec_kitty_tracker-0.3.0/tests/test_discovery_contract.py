"""Contract conformance tests for all registered discovery providers.

Validates that every provider's workspace and resource discovery output
conforms to the shared contract: field presence, types, serializability,
and DiscoveryResult envelope shape.

These tests are provider-agnostic -- they do NOT assert provider-specific
field values, only structural conformance.
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import patch

import httpx
import pytest

from spec_kitty_tracker.discovery import (
    discover_resources,
    discover_workspaces,
)
from spec_kitty_tracker.discovery.registry import (
    registered_resource_providers,
    registered_workspace_providers,
)
from spec_kitty_tracker.discovery.types import (
    DiscoveredResource,
    DiscoveredWorkspace,
    DiscoveryResult,
)
from spec_kitty_tracker.nango import NangoConnectionContext

from discovery_helpers import (
    assert_all_metadata_serializable,
    assert_json_serializable,
    assert_valid_resource,
    assert_valid_workspace,
    assert_workspace_context_serializable,
)


# ---------------------------------------------------------------------------
# Mock transport
# ---------------------------------------------------------------------------


class RoutingMockTransport(httpx.AsyncBaseTransport):
    """Returns canned responses based on URL pattern matching."""

    def __init__(
        self,
        routes: dict[str, tuple[int, Any, dict[str, str] | None]],
    ) -> None:
        self._routes = routes

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        url_str = str(request.url)
        path = request.url.raw_path.decode("ascii")

        for pattern, (status, body, extra_headers) in self._routes.items():
            if pattern in url_str or pattern in path:
                headers: dict[str, str] = {"content-type": "application/json"}
                if extra_headers:
                    headers.update(extra_headers)
                return httpx.Response(
                    status_code=status,
                    content=json.dumps(body).encode(),
                    headers=headers,
                )
        raise ValueError(f"No mock route for {url_str} (path={path})")

    async def aclose(self) -> None:
        pass


# ---------------------------------------------------------------------------
# Per-provider mock route configurations and workspace factories
# ---------------------------------------------------------------------------

# Each entry maps a provider name to:
#   workspace_routes:  mock routes needed for workspace discovery
#   resource_routes:   mock routes needed for resource discovery
#   make_workspace:    callable returning a workspace to feed into resource discovery


def _linear_workspace_routes() -> dict[str, tuple[int, Any, dict[str, str] | None]]:
    return {
        "/graphql": (
            200,
            {
                "data": {
                    "organization": {
                        "id": "org-uuid-1",
                        "name": "Acme Engineering",
                        "urlKey": "acme-eng",
                    }
                }
            },
            None,
        ),
    }


def _linear_resource_routes() -> dict[str, tuple[int, Any, dict[str, str] | None]]:
    return {
        "/graphql": (
            200,
            {
                "data": {
                    "teams": {
                        "nodes": [
                            {"id": "team-uuid-1", "key": "ENG", "name": "Engineering"},
                            {"id": "team-uuid-2", "key": "DES", "name": "Design"},
                        ]
                    }
                }
            },
            None,
        ),
    }


def _linear_workspace() -> DiscoveredWorkspace:
    return DiscoveredWorkspace(
        id="org-uuid-1",
        name="acme-eng",
        display="Acme Engineering",
        kind="workspace",
        provider="linear",
        provider_context={"org_id": "org-uuid-1", "url_key": "acme-eng"},
    )


def _jira_workspace_routes() -> dict[str, tuple[int, Any, dict[str, str] | None]]:
    return {
        "/oauth/token/accessible-resources": (
            200,
            [
                {
                    "id": "cloud-abc",
                    "name": "My Site",
                    "url": "https://mysite.atlassian.net",
                },
            ],
            None,
        ),
    }


def _jira_resource_routes() -> dict[str, tuple[int, Any, dict[str, str] | None]]:
    return {
        "/rest/api/3/project/search": (
            200,
            {
                "values": [
                    {"id": "10001", "key": "PROJ", "name": "My Project"},
                    {"id": "10002", "key": "ENG", "name": "Engineering"},
                ],
                "isLast": True,
            },
            None,
        ),
    }


def _jira_workspace() -> DiscoveredWorkspace:
    return DiscoveredWorkspace(
        id="cloud-abc",
        name="My Site",
        display="https://mysite.atlassian.net",
        kind="site",
        provider="jira",
        provider_context={"cloud_id": "cloud-abc"},
    )


def _github_workspace_routes() -> dict[str, tuple[int, Any, dict[str, str] | None]]:
    return {
        "/user/orgs": (
            200,
            [
                {"id": 100, "login": "acme", "description": "Acme Corp"},
            ],
            None,
        ),
        "/user": (
            200,
            {"id": 42, "login": "octocat", "name": "The Octocat"},
            None,
        ),
    }


def _github_resource_routes() -> dict[str, tuple[int, Any, dict[str, str] | None]]:
    return {
        "/orgs/acme/repos": (
            200,
            [
                {
                    "id": 1,
                    "name": "hello-world",
                    "full_name": "acme/hello-world",
                    "owner": {"login": "acme"},
                    "default_branch": "main",
                    "html_url": "https://github.com/acme/hello-world",
                    "visibility": "public",
                },
            ],
            None,
        ),
    }


def _github_workspace() -> DiscoveredWorkspace:
    return DiscoveredWorkspace(
        id="100",
        name="acme",
        display="Acme Corp",
        kind="org",
        provider="github",
        provider_context={
            "workspace_type": "org",
            "login": "acme",
            "account_id": "100",
        },
    )


def _gitlab_workspace_routes() -> dict[str, tuple[int, Any, dict[str, str] | None]]:
    return {
        "/api/v4/groups": (
            200,
            [
                {
                    "id": 42,
                    "full_path": "acme/engineering",
                    "full_name": "Acme / Engineering",
                    "web_url": "https://gitlab.com/groups/acme/engineering",
                },
            ],
            None,
        ),
    }


def _gitlab_resource_routes() -> dict[str, tuple[int, Any, dict[str, str] | None]]:
    return {
        "/api/v4/groups/42/projects": (
            200,
            [
                {
                    "id": 101,
                    "name_with_namespace": "Acme / Eng / Backend",
                    "path_with_namespace": "acme/eng/backend",
                    "web_url": "https://gitlab.com/acme/eng/backend",
                    "namespace": {"id": 42, "full_path": "acme/engineering"},
                },
            ],
            None,
        ),
    }


def _gitlab_workspace() -> DiscoveredWorkspace:
    return DiscoveredWorkspace(
        id="42",
        name="acme/engineering",
        display="Acme / Engineering",
        kind="group",
        provider="gitlab",
        provider_context={
            "group_id": "42",
            "full_path": "acme/engineering",
            "web_url": "https://gitlab.com/groups/acme/engineering",
        },
    )


# ---------------------------------------------------------------------------
# Provider config registry
# ---------------------------------------------------------------------------

PROVIDER_CONFIG: dict[
    str,
    dict[str, Any],
] = {
    "linear": {
        "workspace_routes": _linear_workspace_routes,
        "resource_routes": _linear_resource_routes,
        "make_workspace": _linear_workspace,
        "transport_patch_target": "spec_kitty_tracker.discovery.providers.linear.NangoProxyTransport",
    },
    "jira": {
        "workspace_routes": _jira_workspace_routes,
        "resource_routes": _jira_resource_routes,
        "make_workspace": _jira_workspace,
        "transport_patch_target": "spec_kitty_tracker.discovery.providers.jira.NangoProxyTransport",
    },
    "github": {
        "workspace_routes": _github_workspace_routes,
        "resource_routes": _github_resource_routes,
        "make_workspace": _github_workspace,
        "transport_patch_target": "spec_kitty_tracker.discovery.providers.github.NangoProxyTransport",
    },
    "gitlab": {
        "workspace_routes": _gitlab_workspace_routes,
        "resource_routes": _gitlab_resource_routes,
        "make_workspace": _gitlab_workspace,
        "transport_patch_target": "spec_kitty_tracker.discovery.providers.gitlab.NangoProxyTransport",
    },
}

ALL_PROVIDERS = list(PROVIDER_CONFIG.keys())


def _make_context(provider: str) -> NangoConnectionContext:
    return NangoConnectionContext(
        connection_id=f"conn-{provider}",
        provider_config_key=f"{provider}-test",
        nango_secret_key="sk-test",
    )


# ---------------------------------------------------------------------------
# T036: Parametrized contract conformance tests
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("provider", ALL_PROVIDERS)
class TestWorkspaceContractConformance:
    """Validate workspace discovery contract across all providers."""

    async def test_workspace_discovery_returns_valid_workspaces(
        self, provider: str
    ) -> None:
        config = PROVIDER_CONFIG[provider]
        routes = config["workspace_routes"]()
        mock = RoutingMockTransport(routes)
        ctx = _make_context(provider)

        with patch(config["transport_patch_target"], return_value=mock):
            result = await discover_workspaces(provider, ctx)

        assert len(result.items) >= 1, f"{provider}: expected at least 1 workspace"
        for ws in result.items:
            assert_valid_workspace(ws)

    async def test_workspace_provider_context_serializable(
        self, provider: str
    ) -> None:
        config = PROVIDER_CONFIG[provider]
        routes = config["workspace_routes"]()
        mock = RoutingMockTransport(routes)
        ctx = _make_context(provider)

        with patch(config["transport_patch_target"], return_value=mock):
            result = await discover_workspaces(provider, ctx)

        for ws in result.items:
            assert_workspace_context_serializable(ws)


@pytest.mark.parametrize("provider", ALL_PROVIDERS)
class TestResourceContractConformance:
    """Validate resource discovery contract across all providers."""

    async def test_resource_discovery_returns_valid_resources(
        self, provider: str
    ) -> None:
        config = PROVIDER_CONFIG[provider]
        routes = config["resource_routes"]()
        mock = RoutingMockTransport(routes)
        ctx = _make_context(provider)
        workspace = config["make_workspace"]()

        with patch(config["transport_patch_target"], return_value=mock):
            result = await discover_resources(provider, workspace, ctx)

        assert len(result.items) >= 1, f"{provider}: expected at least 1 resource"
        for res in result.items:
            assert_valid_resource(res)

    async def test_resource_metadata_serializable(
        self, provider: str
    ) -> None:
        config = PROVIDER_CONFIG[provider]
        routes = config["resource_routes"]()
        mock = RoutingMockTransport(routes)
        ctx = _make_context(provider)
        workspace = config["make_workspace"]()

        with patch(config["transport_patch_target"], return_value=mock):
            result = await discover_resources(provider, workspace, ctx)

        for res in result.items:
            assert_all_metadata_serializable(res)


# ---------------------------------------------------------------------------
# T037: Verify DiscoveryResult shape
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("provider", ALL_PROVIDERS)
class TestDiscoveryResultShape:
    """Validate the DiscoveryResult envelope shape for all providers."""

    async def test_workspace_result_is_discovery_result(
        self, provider: str
    ) -> None:
        config = PROVIDER_CONFIG[provider]
        routes = config["workspace_routes"]()
        mock = RoutingMockTransport(routes)
        ctx = _make_context(provider)

        with patch(config["transport_patch_target"], return_value=mock):
            result = await discover_workspaces(provider, ctx)

        assert isinstance(result, DiscoveryResult)
        assert isinstance(result.items, list)
        assert isinstance(result.truncated, bool)

    async def test_resource_result_is_discovery_result(
        self, provider: str
    ) -> None:
        config = PROVIDER_CONFIG[provider]
        routes = config["resource_routes"]()
        mock = RoutingMockTransport(routes)
        ctx = _make_context(provider)
        workspace = config["make_workspace"]()

        with patch(config["transport_patch_target"], return_value=mock):
            result = await discover_resources(provider, workspace, ctx)

        assert isinstance(result, DiscoveryResult)
        assert isinstance(result.items, list)
        assert isinstance(result.truncated, bool)

    async def test_workspace_not_truncated_with_small_result(
        self, provider: str
    ) -> None:
        """When fewer results than page limit, truncated should be False."""
        config = PROVIDER_CONFIG[provider]
        routes = config["workspace_routes"]()
        mock = RoutingMockTransport(routes)
        ctx = _make_context(provider)

        with patch(config["transport_patch_target"], return_value=mock):
            result = await discover_workspaces(provider, ctx)

        # Our mock data returns a small number of items, well below any page limit
        assert result.truncated is False

    async def test_resource_not_truncated_with_small_result(
        self, provider: str
    ) -> None:
        """When fewer results than page limit, truncated should be False."""
        config = PROVIDER_CONFIG[provider]
        routes = config["resource_routes"]()
        mock = RoutingMockTransport(routes)
        ctx = _make_context(provider)
        workspace = config["make_workspace"]()

        with patch(config["transport_patch_target"], return_value=mock):
            result = await discover_resources(provider, workspace, ctx)

        assert result.truncated is False


# ---------------------------------------------------------------------------
# T038: Registry completeness
# ---------------------------------------------------------------------------


class TestRegistryCompleteness:
    """Verify all 4 providers are registered in both registries."""

    def test_all_providers_registered_for_workspaces(self) -> None:
        ws_providers = registered_workspace_providers()
        expected = {"linear", "jira", "github", "gitlab"}
        assert ws_providers >= expected, (
            f"Missing workspace providers: {expected - ws_providers}"
        )

    def test_all_providers_registered_for_resources(self) -> None:
        rs_providers = registered_resource_providers()
        expected = {"linear", "jira", "github", "gitlab"}
        assert rs_providers >= expected, (
            f"Missing resource providers: {expected - rs_providers}"
        )

    def test_workspace_and_resource_providers_match(self) -> None:
        """Every workspace provider should also have a resource provider."""
        ws_providers = registered_workspace_providers()
        rs_providers = registered_resource_providers()
        expected = {"linear", "jira", "github", "gitlab"}
        for provider in expected:
            assert provider in ws_providers, f"{provider} missing from workspace registry"
            assert provider in rs_providers, f"{provider} missing from resource registry"
