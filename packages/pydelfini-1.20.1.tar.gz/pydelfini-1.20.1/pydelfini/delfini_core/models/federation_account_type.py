from enum import Enum


class FederationAccountType(str, Enum):
    ACCOUNT = "Account"

    def __str__(self) -> str:
        return str(self.value)
