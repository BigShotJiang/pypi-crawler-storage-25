from enum import Enum


class FederationGroupType(str, Enum):
    GROUP = "Group"

    def __str__(self) -> str:
        return str(self.value)
