from typing import Any
from typing import cast
from typing import Dict
from typing import List
from typing import Type
from typing import TypeVar

from attrs import define as _attrs_define


T = TypeVar("T", bound="PrqlModule")


@_attrs_define
class PrqlModule:
    """PrqlModule model

    Attributes:
        href (str):
        label (str):
        name (str):
        tags (List[str]):
    """

    href: str
    label: str
    name: str
    tags: List[str]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a dict"""
        href = self.href
        label = self.label
        name = self.name
        tags = self.tags

        field_dict: Dict[str, Any] = {}
        field_dict.update(
            {
                "href": href,
                "label": label,
                "name": name,
                "tags": tags,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        """Create an instance of :py:class:`PrqlModule` from a dict"""
        d = src_dict.copy()
        href = d.pop("href")

        label = d.pop("label")

        name = d.pop("name")

        tags = cast(List[str], d.pop("tags"))

        prql_module = cls(
            href=href,
            label=label,
            name=name,
            tags=tags,
        )

        return prql_module
