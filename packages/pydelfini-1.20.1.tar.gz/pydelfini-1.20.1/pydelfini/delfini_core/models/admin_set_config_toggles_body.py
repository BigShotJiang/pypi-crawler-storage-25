from typing import Any
from typing import Dict
from typing import Type
from typing import TypeVar
from typing import Union

from attrs import define as _attrs_define

from ..types import UNSET
from ..types import Unset


T = TypeVar("T", bound="AdminSetConfigTogglesBody")


@_attrs_define
class AdminSetConfigTogglesBody:
    """AdminSetConfigTogglesBody model

    Attributes:
        unique_user_email (Union[Unset, bool]):
    """

    unique_user_email: Union[Unset, bool] = UNSET

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a dict"""
        unique_user_email = self.unique_user_email

        field_dict: Dict[str, Any] = {}
        field_dict.update({})
        if unique_user_email is not UNSET:
            field_dict["unique_user_email"] = unique_user_email

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        """Create an instance of :py:class:`AdminSetConfigTogglesBody` from a dict"""
        d = src_dict.copy()
        unique_user_email = d.pop("unique_user_email", UNSET)

        admin_set_config_toggles_body = cls(
            unique_user_email=unique_user_email,
        )

        return admin_set_config_toggles_body
