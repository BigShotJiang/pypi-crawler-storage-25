"""Tests for the Claude Agent SDK integration.

Uses lightweight fakes for claude_agent_sdk types so tests run without the
real Claude Agent SDK or CLI installed.
"""

import sys
import types
from dataclasses import dataclass, field
from typing import Any
from unittest.mock import AsyncMock, Mock

import pytest


# ---------------------------------------------------------------------------
# Fake claude_agent_sdk module hierarchy injected before importing integration
# ---------------------------------------------------------------------------


def _install_fake_claude_sdk():
    """Install a minimal fake ``claude_agent_sdk`` package into sys.modules."""

    @dataclass
    class TextBlock:
        type: str = "text"
        text: str = ""

    @dataclass
    class ToolUseBlock:
        type: str = "tool_use"
        name: str = ""
        id: str = ""
        input: dict = field(default_factory=dict)

    @dataclass
    class ToolResultBlock:
        type: str = "tool_result"
        tool_use_id: str = ""
        content: Any = None
        is_error: bool = False

    @dataclass
    class ThinkingBlock:
        type: str = "thinking"
        thinking: str = ""

    @dataclass
    class UserMessage:
        content: list = field(default_factory=list)
        session_id: str = ""

    @dataclass
    class AssistantMessage:
        content: list = field(default_factory=list)
        session_id: str = ""
        model: str = ""

    @dataclass
    class SystemMessage:
        subtype: str = ""
        data: dict = field(default_factory=dict)

    @dataclass
    class RateLimitInfo:
        status: str = "allowed"
        rate_limit_type: str = "five_hour"
        utilization: float = 0.0

    @dataclass
    class RateLimitEvent:
        rate_limit_info: RateLimitInfo = field(default_factory=RateLimitInfo)
        uuid: str = ""
        session_id: str = ""

    @dataclass
    class StreamEvent:
        uuid: str = ""
        session_id: str = ""
        event: dict = field(default_factory=dict)
        parent_tool_use_id: str = None

    @dataclass
    class ResultMessage:
        subtype: str = "success"
        duration_ms: int = 100
        duration_api_ms: int = 80
        is_error: bool = False
        num_turns: int = 1
        session_id: str = "test-session"
        stop_reason: str = "end_turn"
        total_cost_usd: float = 0.001
        usage: dict = field(default_factory=dict)
        model_usage: dict = None
        errors: list = None
        permission_denials: list = None
        result: str = None
        structured_output: Any = None
        uuid: str = None

    @dataclass
    class HookMatcher:
        matcher: str = None
        hooks: list = field(default_factory=list)
        timeout: float = None

    @dataclass
    class ToolPermissionContext:
        signal: Any = None
        suggestions: list = field(default_factory=list)
        tool_use_id: str = None
        agent_id: str = None

    @dataclass
    class PermissionResultAllow:
        behavior: str = "allow"
        updated_input: dict = None
        updated_permissions: list = None

    @dataclass
    class PermissionResultDeny:
        behavior: str = "deny"
        message: str = ""
        interrupt: bool = False

    @dataclass
    class ClaudeAgentOptions:
        tools: list = None
        allowed_tools: list = field(default_factory=list)
        system_prompt: str = None
        mcp_servers: dict = field(default_factory=dict)
        permission_mode: str = None
        can_use_tool: Any = None
        hooks: dict = None
        stderr: Any = None
        model: str = None
        cwd: str = None
        cli_path: str = None
        env: dict = field(default_factory=dict)
        extra_args: dict = field(default_factory=dict)
        include_partial_messages: bool = False
        agents: dict = None
        max_turns: int = None
        max_budget_usd: float = None
        disallowed_tools: list = field(default_factory=list)
        permission_prompt_tool_name: str = None
        continue_conversation: bool = False
        resume: str = None
        session_id: str = None
        debug_stderr: Any = None
        user: str = None
        fork_session: bool = False
        setting_sources: list = None
        sandbox: dict = None
        plugins: list = field(default_factory=list)
        betas: list = field(default_factory=list)
        add_dirs: list = field(default_factory=list)
        settings: str = None
        max_buffer_size: int = None
        max_thinking_tokens: int = None
        thinking: dict = None
        effort: str = None
        output_format: dict = None
        enable_file_checkpointing: bool = False
        task_budget: dict = None
        fallback_model: str = None

    class ClaudeSDKClient:
        def __init__(self, options=None, transport=None):
            if options is None:
                options = ClaudeAgentOptions()
            self.options = options
            self._custom_transport = transport
            self._transport = None
            self._query = None

        async def connect(self, prompt=None):
            pass

        async def query(self, prompt, session_id="default"):
            pass

        async def receive_messages(self):
            return
            yield

        async def receive_response(self):
            async for msg in self.receive_messages():
                yield msg
                if isinstance(msg, ResultMessage):
                    return

        async def disconnect(self):
            pass

        async def __aenter__(self):
            await self.connect()
            return self

        async def __aexit__(self, *args):
            await self.disconnect()
            return False

    async def query_func(*, prompt, options=None, transport=None):
        return
        yield

    # Build the fake module tree
    fake_types = types.ModuleType("claude_agent_sdk.types")
    for name, obj in [
        ("TextBlock", TextBlock),
        ("ToolUseBlock", ToolUseBlock),
        ("ToolResultBlock", ToolResultBlock),
        ("ThinkingBlock", ThinkingBlock),
        ("UserMessage", UserMessage),
        ("AssistantMessage", AssistantMessage),
        ("SystemMessage", SystemMessage),
        ("RateLimitInfo", RateLimitInfo),
        ("RateLimitEvent", RateLimitEvent),
        ("StreamEvent", StreamEvent),
        ("ResultMessage", ResultMessage),
        ("HookMatcher", HookMatcher),
        ("ToolPermissionContext", ToolPermissionContext),
        ("PermissionResultAllow", PermissionResultAllow),
        ("PermissionResultDeny", PermissionResultDeny),
        ("ClaudeAgentOptions", ClaudeAgentOptions),
    ]:
        setattr(fake_types, name, obj)

    fake_sdk = types.ModuleType("claude_agent_sdk")
    fake_sdk.types = fake_types
    fake_sdk.ClaudeSDKClient = ClaudeSDKClient
    fake_sdk.ClaudeAgentOptions = ClaudeAgentOptions
    fake_sdk.query = query_func
    fake_sdk.ResultMessage = ResultMessage
    fake_sdk.AssistantMessage = AssistantMessage
    fake_sdk.UserMessage = UserMessage

    sys.modules["claude_agent_sdk"] = fake_sdk
    sys.modules["claude_agent_sdk.types"] = fake_types

    return {
        "TextBlock": TextBlock,
        "ToolUseBlock": ToolUseBlock,
        "ToolResultBlock": ToolResultBlock,
        "UserMessage": UserMessage,
        "AssistantMessage": AssistantMessage,
        "ResultMessage": ResultMessage,
        "StreamEvent": StreamEvent,
        "RateLimitEvent": RateLimitEvent,
        "RateLimitInfo": RateLimitInfo,
        "HookMatcher": HookMatcher,
        "ToolPermissionContext": ToolPermissionContext,
        "PermissionResultAllow": PermissionResultAllow,
        "PermissionResultDeny": PermissionResultDeny,
        "ClaudeAgentOptions": ClaudeAgentOptions,
        "ClaudeSDKClient": ClaudeSDKClient,
        "query": query_func,
    }


SDK = _install_fake_claude_sdk()

from zeroeval.observability.integrations.claude_agent.integration import (
    ClaudeAgentIntegration,
    ClientSpanState,
    TurnState,
    _apply_state_to_span,
    _extract_message_data,
    _summarize_prompt,
    _wrap_can_use_tool,
    _wrap_hook_callback,
    _wrap_options,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_tracer():
    tracer = Mock()
    span = Mock()
    span.attributes = {}
    span.session_id = None
    tracer.start_span.return_value = span
    return tracer, span


# ---------------------------------------------------------------------------
# Unit 1: Registration
# ---------------------------------------------------------------------------


class TestRegistration:
    def test_is_available(self):
        assert ClaudeAgentIntegration.is_available() is True

    def test_is_available_when_missing(self, monkeypatch):
        saved = sys.modules.pop("claude_agent_sdk")
        try:
            assert ClaudeAgentIntegration.is_available() is False
        finally:
            sys.modules["claude_agent_sdk"] = saved

    def test_setup_patches_query_and_client(self):
        tracer, _ = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)
        integration.setup()

        import claude_agent_sdk as sdk

        assert getattr(sdk.query, "__ze_patched__", False) is True
        assert getattr(sdk.ClaudeSDKClient.connect, "__ze_patched__", False) is True
        assert getattr(sdk.ClaudeSDKClient.query, "__ze_patched__", False) is True
        assert (
            getattr(sdk.ClaudeSDKClient.receive_messages, "__ze_patched__", False)
            is True
        )
        assert getattr(sdk.ClaudeSDKClient.disconnect, "__ze_patched__", False) is True

        integration.teardown()

    def test_teardown_restores_originals(self):
        tracer, _ = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        import claude_agent_sdk as sdk

        original_query = sdk.query

        integration.setup()
        assert sdk.query is not original_query

        integration.teardown()
        assert sdk.query is original_query


# ---------------------------------------------------------------------------
# Unit 2: query() wrapper
# ---------------------------------------------------------------------------


class TestQueryWrapper:
    @pytest.mark.asyncio
    async def test_string_prompt_creates_span_with_result(self):
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        assistant = SDK["AssistantMessage"](
            content=[SDK["TextBlock"](text="Hello!")],
            session_id="s1",
        )
        result = SDK["ResultMessage"](
            session_id="s1",
            total_cost_usd=0.005,
            num_turns=1,
        )

        async def fake_query(*, prompt, options=None, transport=None):
            yield assistant
            yield result

        wrapped = integration._wrap_query(fake_query)

        messages = []
        async for msg in wrapped(prompt="Hi there"):
            messages.append(msg)

        assert len(messages) == 2
        assert messages[0] is assistant
        assert messages[1] is result

        tracer.start_span.assert_called_once()
        call_kwargs = tracer.start_span.call_args.kwargs
        assert call_kwargs["kind"] == "agent"
        assert call_kwargs["attributes"]["integration"] == "claude_agent_sdk"

        tracer.end_span.assert_called_once_with(span)
        span.set_io.assert_called_once()
        assert span.attributes["claude_session_id"] == "s1"
        assert "session_id" not in span.attributes
        assert span.session_id == "s1"
        assert span.attributes["total_cost_usd"] == 0.005

        call_kwargs = tracer.start_span.call_args.kwargs
        assert call_kwargs["is_new_trace"] is True

    @pytest.mark.asyncio
    async def test_error_during_iteration_records_error_span(self):
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        async def failing_query(*, prompt, options=None, transport=None):
            yield SDK["AssistantMessage"](content=[], session_id="s1")
            raise RuntimeError("connection lost")

        wrapped = integration._wrap_query(failing_query)

        with pytest.raises(RuntimeError, match="connection lost"):
            async for _ in wrapped(prompt="test"):
                pass

        span.set_error.assert_called_once()
        tracer.end_span.assert_called_once_with(span)

    @pytest.mark.asyncio
    async def test_stream_events_enrich_span(self):
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        stream_evt = SDK["StreamEvent"](
            uuid="u1", session_id="s1", event={"type": "content_block_delta"}
        )
        result = SDK["ResultMessage"](session_id="s1")

        async def fake_query(*, prompt, options=None, transport=None):
            yield stream_evt
            yield stream_evt
            yield result

        wrapped = integration._wrap_query(fake_query)
        async for _ in wrapped(prompt="test"):
            pass

        assert span.attributes["stream_event_count"] == 2

    @pytest.mark.asyncio
    async def test_tool_use_blocks_captured(self):
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        assistant = SDK["AssistantMessage"](
            content=[
                SDK["ToolUseBlock"](name="Bash", id="tu1"),
                SDK["TextBlock"](text="Running command"),
            ],
            session_id="s1",
        )
        result = SDK["ResultMessage"](session_id="s1")

        async def fake_query(*, prompt, options=None, transport=None):
            yield assistant
            yield result

        wrapped = integration._wrap_query(fake_query)
        async for _ in wrapped(prompt="test"):
            pass

        assert len(span.attributes["tool_uses"]) == 1
        assert span.attributes["tool_uses"][0]["name"] == "Bash"

    @pytest.mark.asyncio
    async def test_rate_limit_event_captured(self):
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        rl = SDK["RateLimitEvent"](
            rate_limit_info=SDK["RateLimitInfo"](
                status="allowed_warning", utilization=0.85
            ),
            session_id="s1",
        )
        result = SDK["ResultMessage"](session_id="s1")

        async def fake_query(*, prompt, options=None, transport=None):
            yield rl
            yield result

        wrapped = integration._wrap_query(fake_query)
        async for _ in wrapped(prompt="test"):
            pass

        assert len(span.attributes["rate_limit_events"]) == 1
        assert span.attributes["rate_limit_events"][0]["status"] == "allowed_warning"


# ---------------------------------------------------------------------------
# Unit 3: ClaudeSDKClient wrappers
# ---------------------------------------------------------------------------


class TestClientWrappers:
    @pytest.mark.asyncio
    async def test_client_query_and_receive_creates_span(self):
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        client = SDK["ClaudeSDKClient"]()

        original_connect = AsyncMock()
        wrapped_connect = integration._wrap_client_connect(original_connect)
        await wrapped_connect(client, prompt=None)

        original_query = AsyncMock()
        wrapped_query = integration._wrap_client_query(original_query)
        await wrapped_query(client, "What is 2+2?", "default")

        tracer.start_span.assert_called_once()

        assistant = SDK["AssistantMessage"](
            content=[SDK["TextBlock"](text="4")], session_id="default"
        )
        result = SDK["ResultMessage"](session_id="default", total_cost_usd=0.002)

        messages_to_yield = [assistant, result]

        async def fake_receive(self_arg):
            for m in messages_to_yield:
                yield m

        wrapped_receive = integration._wrap_receive_messages(fake_receive)
        received = []
        async for msg in wrapped_receive(client):
            received.append(msg)

        assert len(received) == 2
        tracer.end_span.assert_called_once_with(span)
        span.set_io.assert_called_once()
        assert span.attributes["total_cost_usd"] == 0.002
        assert span.attributes["claude_session_id"] == "default"
        assert span.session_id == "default"

        call_kwargs = tracer.start_span.call_args.kwargs
        assert call_kwargs["is_new_trace"] is True

    @pytest.mark.asyncio
    async def test_connect_with_prompt_creates_span(self):
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        client = SDK["ClaudeSDKClient"]()

        original_connect = AsyncMock()
        wrapped_connect = integration._wrap_client_connect(original_connect)
        await wrapped_connect(client, prompt="Hello")

        tracer.start_span.assert_called_once()
        original_connect.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_disconnect_closes_pending_spans(self):
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        client = SDK["ClaudeSDKClient"]()

        original_connect = AsyncMock()
        wrapped_connect = integration._wrap_client_connect(original_connect)
        await wrapped_connect(client, prompt=None)

        original_query = AsyncMock()
        wrapped_query = integration._wrap_client_query(original_query)
        await wrapped_query(client, "test", "default")

        original_disconnect = AsyncMock()
        wrapped_disconnect = integration._wrap_disconnect(original_disconnect)
        await wrapped_disconnect(client)

        tracer.end_span.assert_called_once_with(span)
        assert span.attributes.get("interrupted") is True
        original_disconnect.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_two_sequential_turns_create_two_spans(self):
        tracer = Mock()
        span1 = Mock()
        span1.attributes = {}
        span2 = Mock()
        span2.attributes = {}
        tracer.start_span.side_effect = [span1, span2]

        integration = ClaudeAgentIntegration(tracer)
        client = SDK["ClaudeSDKClient"]()

        original_connect = AsyncMock()
        await integration._wrap_client_connect(original_connect)(client, prompt=None)

        original_query = AsyncMock()
        wq = integration._wrap_client_query(original_query)
        await wq(client, "Turn 1", "default")

        result1 = SDK["ResultMessage"](session_id="default")

        async def fake_receive_1(self_arg):
            yield SDK["AssistantMessage"](content=[], session_id="default")
            yield result1

        wr = integration._wrap_receive_messages(fake_receive_1)
        async for _ in wr(client):
            pass

        tracer.end_span.assert_called_once_with(span1)
        tracer.end_span.reset_mock()

        await wq(client, "Turn 2", "default")

        result2 = SDK["ResultMessage"](session_id="default")

        async def fake_receive_2(self_arg):
            yield SDK["AssistantMessage"](content=[], session_id="default")
            yield result2

        wr2 = integration._wrap_receive_messages(fake_receive_2)
        async for _ in wr2(client):
            pass

        tracer.end_span.assert_called_once_with(span2)


# ---------------------------------------------------------------------------
# Unit 4: Enrichment helpers
# ---------------------------------------------------------------------------


class TestEnrichment:
    def test_summarize_prompt_string(self):
        assert _summarize_prompt("Hello world") == "Hello world"

    def test_summarize_prompt_async_iterable(self):
        assert _summarize_prompt(object()) == "<async-iterable>"

    def test_extract_message_captures_user_text(self):
        state = TurnState()
        msg = SDK["UserMessage"](
            content=[SDK["TextBlock"](text="Hi there")], session_id="s1"
        )
        _extract_message_data(msg, state)
        assert state.prompt_summary == "Hi there"
        assert state.claude_session_id == "s1"

    def test_extract_message_captures_assistant_tool_use(self):
        state = TurnState()
        msg = SDK["AssistantMessage"](
            content=[
                SDK["ToolUseBlock"](name="Read", id="tu1"),
                SDK["TextBlock"](text="Reading file"),
            ],
            session_id="s1",
        )
        _extract_message_data(msg, state)
        assert len(state.tool_uses) == 1
        assert state.tool_uses[0]["name"] == "Read"
        assert state.assistant_text == "Reading file"

    def test_apply_state_to_span(self):
        span = Mock()
        span.attributes = {}
        span.session_id = None
        state = TurnState(
            prompt_summary="test prompt",
            assistant_text="test output",
            claude_session_id="s1",
            tool_uses=[{"name": "Bash", "id": "tu1"}],
            result_meta={"total_cost_usd": 0.01, "num_turns": 2},
        )
        _apply_state_to_span(span, state)

        span.set_io.assert_called_once_with(
            input_data="test prompt", output_data="test output"
        )
        assert span.attributes["claude_session_id"] == "s1"
        assert "session_id" not in span.attributes
        assert span.session_id == "s1"
        assert span.attributes["total_cost_usd"] == 0.01
        assert span.attributes["num_turns"] == 2

    def test_apply_state_to_span_no_claude_session(self):
        """When no Claude session is emitted, session_id is not overwritten."""
        span = Mock()
        span.attributes = {}
        span.session_id = "original-ze-session"
        state = TurnState(
            prompt_summary="test prompt",
            assistant_text="output",
        )
        _apply_state_to_span(span, state)

        assert "claude_session_id" not in span.attributes
        assert "session_id" not in span.attributes
        assert span.session_id == "original-ze-session"

    @pytest.mark.asyncio
    async def test_wrap_can_use_tool_preserves_allow(self):
        state = TurnState()
        allow = SDK["PermissionResultAllow"]()

        async def user_callback(tool_name, input_data, context):
            return allow

        wrapped = _wrap_can_use_tool(user_callback, state)
        ctx = SDK["ToolPermissionContext"](tool_use_id="tu1", agent_id="a1")
        result = await wrapped("Bash", {"command": "ls"}, ctx)

        assert result is allow
        assert len(state.permission_decisions) == 1
        assert state.permission_decisions[0]["tool_name"] == "Bash"
        assert state.permission_decisions[0]["behavior"] == "allow"

    @pytest.mark.asyncio
    async def test_wrap_can_use_tool_preserves_deny(self):
        state = TurnState()
        deny = SDK["PermissionResultDeny"](message="blocked")

        async def user_callback(tool_name, input_data, context):
            return deny

        wrapped = _wrap_can_use_tool(user_callback, state)
        ctx = SDK["ToolPermissionContext"]()
        result = await wrapped("Bash", {}, ctx)

        assert result is deny
        assert state.permission_decisions[0]["behavior"] == "deny"

    @pytest.mark.asyncio
    async def test_wrap_can_use_tool_propagates_exception(self):
        state = TurnState()

        async def bad_callback(tool_name, input_data, context):
            raise ValueError("boom")

        wrapped = _wrap_can_use_tool(bad_callback, state)
        with pytest.raises(ValueError, match="boom"):
            await wrapped("Bash", {}, SDK["ToolPermissionContext"]())

    @pytest.mark.asyncio
    async def test_wrap_hook_callback_preserves_output(self):
        state = TurnState()

        async def user_hook(input_data, tool_use_id, context):
            return {"hookSpecificOutput": {"hookEventName": "PreToolUse"}}

        wrapped = _wrap_hook_callback(user_hook, state)
        result = await wrapped(
            {"hook_event_name": "PreToolUse", "tool_name": "Bash"}, "tu1", {}
        )

        assert result == {"hookSpecificOutput": {"hookEventName": "PreToolUse"}}
        assert len(state.hook_events) == 1
        assert state.hook_events[0]["event_name"] == "PreToolUse"

    def test_wrap_options_no_callbacks_returns_same(self):
        opts = SDK["ClaudeAgentOptions"]()
        state = TurnState()
        result = _wrap_options(opts, state)
        assert result is opts

    def test_wrap_options_with_can_use_tool(self):
        async def cb(t, i, c):
            return SDK["PermissionResultAllow"]()

        opts = SDK["ClaudeAgentOptions"](can_use_tool=cb)
        state = TurnState()
        result = _wrap_options(opts, state)
        assert result is not opts
        assert result.can_use_tool is not cb


class TestClientSpanState:
    def test_push_and_pop(self):
        css = ClientSpanState()
        span = Mock()
        state = TurnState()
        css.push_turn("s1", span, state)

        pair = css.pop_turn("s1")
        assert pair == (span, state)
        assert css.pop_turn("s1") is None

    def test_peek_fallback(self):
        css = ClientSpanState()
        span = Mock()
        state = TurnState()
        css.push_turn("s1", span, state)

        pair = css.peek_turn(None)
        assert pair == (span, state)

    def test_close_all_ends_spans(self):
        tracer = Mock()
        css = ClientSpanState()
        span = Mock()
        span.attributes = {}
        css.push_turn("s1", span, TurnState(prompt_summary="test"))
        css.close_all(tracer)

        tracer.end_span.assert_called_once_with(span)
        assert span.attributes["interrupted"] is True
        assert len(css.pending_turns) == 0


# ---------------------------------------------------------------------------
# Bug fix regression tests
# ---------------------------------------------------------------------------


class TestBugFixes:
    @pytest.mark.asyncio
    async def test_client_query_wraps_options_per_turn(self):
        """Bug 1: _wrap_client_query must call _wrap_options for each turn."""
        tracer = Mock()
        span1 = Mock()
        span1.attributes = {}
        span2 = Mock()
        span2.attributes = {}
        tracer.start_span.side_effect = [span1, span2]

        integration = ClaudeAgentIntegration(tracer)
        allow = SDK["PermissionResultAllow"]()
        call_log = []

        async def user_can_use_tool(tool_name, input_data, context):
            call_log.append(tool_name)
            return allow

        opts = SDK["ClaudeAgentOptions"](can_use_tool=user_can_use_tool)
        client = SDK["ClaudeSDKClient"](options=opts)

        original_connect = AsyncMock()
        await integration._wrap_client_connect(original_connect)(client, prompt=None)

        original_query = AsyncMock()
        wq = integration._wrap_client_query(original_query)

        await wq(client, "Turn 1", "default")
        wrapped_opts_1 = client.options
        assert wrapped_opts_1.can_use_tool is not user_can_use_tool

        result1 = SDK["ResultMessage"](session_id="default")

        async def fake_receive_1(self_arg):
            yield SDK["AssistantMessage"](content=[], session_id="default")
            yield result1

        wr = integration._wrap_receive_messages(fake_receive_1)
        async for _ in wr(client):
            pass

        await wq(client, "Turn 2", "default")
        wrapped_opts_2 = client.options
        assert wrapped_opts_2.can_use_tool is not user_can_use_tool
        assert wrapped_opts_2.can_use_tool is not wrapped_opts_1.can_use_tool

    @pytest.mark.asyncio
    async def test_wrap_options_stderr_not_wrapped(self):
        """Bug 2: stderr with no telemetry should not cause needless copy."""

        def my_stderr(line: str) -> None:
            pass

        opts = SDK["ClaudeAgentOptions"](stderr=my_stderr)
        state = TurnState()
        result = _wrap_options(opts, state)
        assert result is opts

    @pytest.mark.asyncio
    async def test_span_ended_on_early_generator_close(self):
        """Bug 3: span must be ended when consumer breaks out of async for."""
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        assistant = SDK["AssistantMessage"](
            content=[SDK["TextBlock"](text="Hello!")],
            session_id="s1",
        )
        result = SDK["ResultMessage"](session_id="s1")

        async def fake_query(*, prompt, options=None, transport=None):
            yield assistant
            yield result

        wrapped = integration._wrap_query(fake_query)

        gen = wrapped(prompt="Hi")
        msg = await gen.__anext__()
        assert isinstance(msg, SDK["AssistantMessage"])
        await gen.aclose()

        tracer.end_span.assert_called_once_with(span)

    @pytest.mark.asyncio
    async def test_receive_messages_span_ended_on_early_generator_close(self):
        """Bug 4: receive_messages span must be ended when consumer breaks out."""
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        client = SDK["ClaudeSDKClient"]()

        original_connect = AsyncMock()
        await integration._wrap_client_connect(original_connect)(client, prompt=None)

        original_query = AsyncMock()
        wq = integration._wrap_client_query(original_query)
        await wq(client, "Hello", "default")

        assistant = SDK["AssistantMessage"](
            content=[SDK["TextBlock"](text="Hi!")],
            session_id="default",
        )
        result = SDK["ResultMessage"](session_id="default")

        async def fake_receive(self_arg):
            yield assistant
            yield result

        wrapped_receive = integration._wrap_receive_messages(fake_receive)

        gen = wrapped_receive(client)
        msg = await gen.__anext__()
        assert isinstance(msg, SDK["AssistantMessage"])
        await gen.aclose()

        tracer.end_span.assert_called_once_with(span)


# ---------------------------------------------------------------------------
# Unit 6: Hybrid tracing model
# ---------------------------------------------------------------------------


class TestHybridTracingModel:
    """Verify the clean hybrid model: each turn/query is its own trace,
    turns in the same Claude conversation share a ZeroEval session via
    the ``claude_session_id`` attribute."""

    @pytest.mark.asyncio
    async def test_query_forces_new_trace(self):
        """query() passes is_new_trace=True to start_span."""
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        result = SDK["ResultMessage"](session_id="cs1")

        async def fake_query(*, prompt, options=None, transport=None):
            yield result

        wrapped = integration._wrap_query(fake_query)
        async for _ in wrapped(prompt="test"):
            pass

        call_kwargs = tracer.start_span.call_args.kwargs
        assert call_kwargs["is_new_trace"] is True

    @pytest.mark.asyncio
    async def test_client_turn_forces_new_trace(self):
        """ClaudeSDKClient.query() passes is_new_trace=True to start_span."""
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        client = SDK["ClaudeSDKClient"]()
        original_connect = AsyncMock()
        await integration._wrap_client_connect(original_connect)(client, prompt=None)

        original_query = AsyncMock()
        wq = integration._wrap_client_query(original_query)
        await wq(client, "Hello", "default")

        call_kwargs = tracer.start_span.call_args.kwargs
        assert call_kwargs["is_new_trace"] is True

    @pytest.mark.asyncio
    async def test_sequential_turns_share_session_via_claude_id(self):
        """Two turns with the same Claude session_id both late-bind
        span.session_id to that value."""
        tracer = Mock()
        span1 = Mock()
        span1.attributes = {}
        span1.session_id = "ze-fallback"
        span2 = Mock()
        span2.attributes = {}
        span2.session_id = "ze-fallback"
        tracer.start_span.side_effect = [span1, span2]

        integration = ClaudeAgentIntegration(tracer)
        client = SDK["ClaudeSDKClient"]()

        original_connect = AsyncMock()
        await integration._wrap_client_connect(original_connect)(client, prompt=None)

        original_query = AsyncMock()
        wq = integration._wrap_client_query(original_query)

        await wq(client, "Turn 1", "default")

        async def fake_receive_1(self_arg):
            yield SDK["AssistantMessage"](content=[], session_id="claude-conv-abc")
            yield SDK["ResultMessage"](session_id="claude-conv-abc")

        wr = integration._wrap_receive_messages(fake_receive_1)
        async for _ in wr(client):
            pass

        assert span1.session_id == "claude-conv-abc"
        assert span1.attributes["claude_session_id"] == "claude-conv-abc"
        assert "session_id" not in span1.attributes

        await wq(client, "Turn 2", "default")

        async def fake_receive_2(self_arg):
            yield SDK["AssistantMessage"](content=[], session_id="claude-conv-abc")
            yield SDK["ResultMessage"](session_id="claude-conv-abc")

        wr2 = integration._wrap_receive_messages(fake_receive_2)
        async for _ in wr2(client):
            pass

        assert span2.session_id == "claude-conv-abc"
        assert span2.attributes["claude_session_id"] == "claude-conv-abc"

    @pytest.mark.asyncio
    async def test_no_claude_session_preserves_ze_session(self):
        """If no Claude session_id is ever emitted, the ZeroEval session
        assigned at start_span time is preserved."""
        tracer, span = _make_tracer()
        span.session_id = "original-ze-session"
        integration = ClaudeAgentIntegration(tracer)

        assistant = SDK["AssistantMessage"](content=[], session_id="")
        result = SDK["ResultMessage"](session_id="")

        async def fake_query(*, prompt, options=None, transport=None):
            yield assistant
            yield result

        wrapped = integration._wrap_query(fake_query)
        async for _ in wrapped(prompt="test"):
            pass

        assert span.session_id == "original-ze-session"
        assert "claude_session_id" not in span.attributes

    @pytest.mark.asyncio
    async def test_connect_with_prompt_forces_new_trace(self):
        """connect(prompt=...) also passes is_new_trace=True."""
        tracer, span = _make_tracer()
        integration = ClaudeAgentIntegration(tracer)

        client = SDK["ClaudeSDKClient"]()
        original_connect = AsyncMock()
        await integration._wrap_client_connect(original_connect)(client, prompt="Hello")

        call_kwargs = tracer.start_span.call_args.kwargs
        assert call_kwargs["is_new_trace"] is True
