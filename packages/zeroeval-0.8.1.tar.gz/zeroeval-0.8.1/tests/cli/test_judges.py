from __future__ import annotations

import json
from unittest.mock import patch, call

from .conftest import run_cli, stub_api_response


class TestJudgesList:
    def test_basic_list(self):
        resp = {"automations": [{"id": "j1", "name": "quality"}]}
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli("--output", "json", "--project-id", "p1", "judges", "list")
        assert result.exit_code == 0
        data = result.json()
        assert isinstance(data, list)
        assert data[0]["id"] == "j1"


class TestJudgesGet:
    def test_get_by_id(self):
        resp = {"id": "j1", "name": "quality", "sample_rate": 1.0}
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli("--output", "json", "--project-id", "p1", "judges", "get", "j1")
        assert result.exit_code == 0


class TestJudgesEvaluations:
    def test_basic_evaluations(self):
        resp = {"evaluations": [{"id": "e1"}], "total": 1, "limit": 100, "offset": 0}
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli("--output", "json", "--project-id", "p1", "judges", "evaluations", "j1")
        assert result.exit_code == 0
        data = result.json()
        assert isinstance(data, list)


class TestJudgesCreate:
    def test_create_binary_judge(self):
        resp = {"id": "j-new", "name": "test_judge", "evaluation_type": "binary"}
        with patch("requests.request", return_value=stub_api_response(201, resp)) as mock:
            result = run_cli(
                "--output", "json", "--project-id", "p1",
                "judges", "create",
                "--name", "test_judge",
                "--prompt", "Evaluate if the output is correct",
            )
        assert result.exit_code == 0
        sent_body = mock.call_args.kwargs.get("json", {})
        assert sent_body["name"] == "test_judge"
        assert sent_body["filter"]["object_type"] == "span"
        assert sent_body["filter"]["properties"]["kind"] == "llm"
        assert sent_body["evaluation_type"] == "binary"

    def test_create_scored_judge(self):
        resp = {"id": "j-new", "name": "scored_judge", "evaluation_type": "scored"}
        with patch("requests.request", return_value=stub_api_response(201, resp)) as mock:
            result = run_cli(
                "--output", "json", "--project-id", "p1",
                "judges", "create",
                "--name", "scored_judge",
                "--prompt", "Score the output",
                "--evaluation-type", "scored",
                "--score-min", "1",
                "--score-max", "5",
                "--pass-threshold", "3",
            )
        assert result.exit_code == 0
        sent_body = mock.call_args.kwargs.get("json", {})
        assert sent_body["evaluation_type"] == "scored"
        assert sent_body["score_min"] == 1.0
        assert sent_body["score_max"] == 5.0
        assert sent_body["pass_threshold"] == 3.0

    def test_create_requires_prompt(self):
        result = run_cli(
            "--output", "json", "--project-id", "p1",
            "judges", "create", "--name", "no_prompt_judge",
        )
        assert result.exit_code != 0

    def test_create_with_tags(self):
        resp = {"id": "j-new", "name": "tagged"}
        with patch("requests.request", return_value=stub_api_response(201, resp)) as mock:
            result = run_cli(
                "--output", "json", "--project-id", "p1",
                "judges", "create",
                "--name", "tagged",
                "--prompt", "Evaluate",
                "--tag", "env=prod,staging",
                "--tag", "team=ml",
                "--tag-match", "any",
            )
        assert result.exit_code == 0
        sent_body = mock.call_args.kwargs.get("json", {})
        tags = sent_body["filter"]["properties"]["tags"]
        assert tags["env"] == ["prod", "staging"]
        assert tags["team"] == ["ml"]
        assert sent_body["filter"]["properties"]["tagMatchMode"] == "any"


class TestJudgesFeedback:
    def test_feedback_thumbs_up(self):
        resp = {"id": "fb1", "thumbs_up": True}
        with patch("requests.request", return_value=stub_api_response(200, resp)) as mock:
            result = run_cli(
                "--output", "json", "--project-id", "p1",
                "judges", "feedback", "create",
                "--span-id", "sp1",
                "--thumbs-up",
                "--reason", "Looks correct",
            )
        assert result.exit_code == 0
        sent_body = mock.call_args.kwargs.get("json", {})
        assert sent_body["thumbs_up"] is True
        assert sent_body["reason"] == "Looks correct"

    def test_feedback_requires_thumbs(self):
        result = run_cli(
            "--output", "json", "--project-id", "p1",
            "judges", "feedback", "create",
            "--span-id", "sp1",
        )
        assert result.exit_code != 0
