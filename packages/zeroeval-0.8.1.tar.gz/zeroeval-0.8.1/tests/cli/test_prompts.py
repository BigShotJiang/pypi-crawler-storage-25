from __future__ import annotations

import json
from unittest.mock import patch

from .conftest import run_cli, stub_api_response


class TestPromptsList:
    def test_basic_list(self):
        resp = [{"id": "task1", "name": "support-triage", "slug": "support-triage"}]
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli("--output", "json", "--project-id", "p1", "prompts", "list")
        assert result.exit_code == 0
        data = result.json()
        assert isinstance(data, list)


class TestPromptsGet:
    def test_get_by_slug(self):
        resp = {"prompt": "support-triage", "version": 3, "content": "Evaluate..."}
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli("--output", "json", "prompts", "get", "support-triage")
        assert result.exit_code == 0

    def test_get_with_version(self):
        resp = {"prompt": "support-triage", "version": 2, "content": "..."}
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli(
                "--output", "json", "prompts", "get", "support-triage", "--version", "2",
            )
        assert result.exit_code == 0


class TestPromptsVersions:
    def test_list_versions(self):
        resp = [{"version": 1}, {"version": 2}]
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli(
                "--output", "json", "--project-id", "p1",
                "prompts", "versions", "support-triage",
            )
        assert result.exit_code == 0
        data = result.json()
        assert len(data) == 2


class TestPromptsTags:
    def test_list_tags(self):
        resp = [{"tag": "production", "version": 3}]
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli(
                "--output", "json", "--project-id", "p1",
                "prompts", "tags", "support-triage",
            )
        assert result.exit_code == 0


class TestPromptsFeedback:
    def test_create_thumbs_up(self):
        resp = {"id": "fb1", "thumbs_up": True}
        with patch("requests.request", return_value=stub_api_response(200, resp)) as mock:
            result = run_cli(
                "--output", "json",
                "prompts", "feedback", "create",
                "--prompt-slug", "support-triage",
                "--completion-id", "c1",
                "--thumbs-up",
            )
        assert result.exit_code == 0
        sent_body = mock.call_args.kwargs.get("json", {})
        assert sent_body["thumbs_up"] is True

    def test_create_thumbs_down_with_reason(self):
        resp = {"id": "fb2", "thumbs_up": False}
        with patch("requests.request", return_value=stub_api_response(200, resp)) as mock:
            result = run_cli(
                "--output", "json",
                "prompts", "feedback", "create",
                "--prompt-slug", "support-triage",
                "--completion-id", "c2",
                "--thumbs-down",
                "--reason", "Bad response",
            )
        assert result.exit_code == 0
        sent_body = mock.call_args.kwargs.get("json", {})
        assert sent_body["thumbs_up"] is False
        assert sent_body["reason"] == "Bad response"

    def test_requires_thumbs_direction(self):
        result = run_cli(
            "--output", "json",
            "prompts", "feedback", "create",
            "--prompt-slug", "slug",
            "--completion-id", "c1",
        )
        assert result.exit_code != 0
