from __future__ import annotations

from unittest.mock import patch

from .conftest import run_cli, stub_api_response


class TestSessionsList:
    def test_basic_list(self):
        with patch("requests.request", return_value=stub_api_response(200, [{"id": "s1"}])):
            result = run_cli("--output", "json", "--project-id", "p1", "sessions", "list")
        assert result.exit_code == 0
        data = result.json()
        assert isinstance(data, list)

    def test_with_date_filters(self):
        with patch("requests.request", return_value=stub_api_response(200, [])) as mock:
            result = run_cli(
                "--output", "json", "--project-id", "p1",
                "sessions", "list", "--start-date", "2025-01-01", "--end-date", "2025-02-01",
            )
        assert result.exit_code == 0
        call_kwargs = mock.call_args
        assert "start_date" in str(call_kwargs)


class TestSessionsGet:
    def test_get_by_id(self):
        with patch("requests.request", return_value=stub_api_response(200, {"id": "s1", "name": "test"})):
            result = run_cli("--output", "json", "--project-id", "p1", "sessions", "get", "s1")
        assert result.exit_code == 0


class TestTracesList:
    def test_basic_list(self):
        with patch("requests.request", return_value=stub_api_response(200, [{"id": "t1"}])):
            result = run_cli("--output", "json", "--project-id", "p1", "traces", "list")
        assert result.exit_code == 0

    def test_traces_spans(self):
        with patch("requests.request", return_value=stub_api_response(200, [{"id": "sp1"}])):
            result = run_cli("--output", "json", "--project-id", "p1", "traces", "spans", "t1")
        assert result.exit_code == 0


class TestSpansList:
    def test_basic_list(self):
        with patch("requests.request", return_value=stub_api_response(200, [{"id": "sp1"}])):
            result = run_cli("--output", "json", "--project-id", "p1", "spans", "list")
        assert result.exit_code == 0

    def test_get_by_id(self):
        with patch("requests.request", return_value=stub_api_response(200, {"id": "sp1"})):
            result = run_cli("--output", "json", "--project-id", "p1", "spans", "get", "sp1")
        assert result.exit_code == 0
