from __future__ import annotations

from unittest.mock import patch, call

from .conftest import run_cli, stub_api_response


class TestOptimizePromptList:
    def test_basic_list(self):
        resp = [{"id": "run1", "status": "succeeded"}]
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli(
                "--output",
                "json",
                "--project-id",
                "p1",
                "optimize",
                "prompt",
                "list",
                "task1",
            )
        assert result.exit_code == 0
        data = result.json()
        assert isinstance(data, list)


class TestOptimizePromptGet:
    def test_get_run(self):
        resp = {"id": "run1", "status": "succeeded", "candidate_prompt": "improved..."}
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli(
                "--output",
                "json",
                "--project-id",
                "p1",
                "optimize",
                "prompt",
                "get",
                "task1",
                "run1",
            )
        assert result.exit_code == 0


class TestOptimizePromptStart:
    def test_start_run(self):
        resp = {"id": "run-new", "status": "queued"}
        with patch(
            "requests.request", return_value=stub_api_response(201, resp)
        ) as mock:
            result = run_cli(
                "--output",
                "json",
                "--project-id",
                "p1",
                "optimize",
                "prompt",
                "start",
                "task1",
                "--optimizer-type",
                "quick_refine",
            )
        assert result.exit_code == 0
        sent_body = mock.call_args.kwargs.get("json", {})
        assert sent_body["optimizer_type"] == "quick_refine"


class TestOptimizePromptPromote:
    def test_promote_with_yes_flag(self):
        resp = {"adopted": True}
        with patch("requests.request", return_value=stub_api_response(200, resp)):
            result = run_cli(
                "--output",
                "json",
                "--project-id",
                "p1",
                "optimize",
                "prompt",
                "promote",
                "task1",
                "run1",
                "--yes",
            )
        assert result.exit_code == 0

    def test_promote_requires_yes_in_text_mode(self):
        with patch("requests.request", return_value=stub_api_response(200, {})):
            with patch("builtins.input", return_value="n"):
                result = run_cli(
                    "--project-id",
                    "p1",
                    "optimize",
                    "prompt",
                    "promote",
                    "task1",
                    "run1",
                )
        assert result.exit_code == 2

    def test_promote_requires_yes_in_json_mode(self):
        with (
            patch("requests.request", return_value=stub_api_response(200, {})),
            patch("builtins.input", return_value="n"),
        ):
            result = run_cli(
                "--output",
                "json",
                "--project-id",
                "p1",
                "optimize",
                "prompt",
                "promote",
                "task1",
                "run1",
            )
        assert result.exit_code == 2


class TestOptimizeJudgeList:
    def test_resolves_task_id_from_judge(self):
        judge_resp = {"id": "j1", "task_id": "task-judge-1", "name": "quality"}
        runs_resp = [{"id": "run1", "status": "succeeded"}]
        responses = [
            stub_api_response(200, judge_resp),
            stub_api_response(200, runs_resp),
        ]
        with patch("requests.request", side_effect=responses):
            result = run_cli(
                "--output",
                "json",
                "--project-id",
                "p1",
                "optimize",
                "judge",
                "list",
                "j1",
            )
        assert result.exit_code == 0

    def test_fails_if_judge_has_no_task(self):
        judge_resp = {"id": "j1", "task_id": None, "name": "no-task"}
        with patch("requests.request", return_value=stub_api_response(200, judge_resp)):
            result = run_cli(
                "--output",
                "json",
                "--project-id",
                "p1",
                "optimize",
                "judge",
                "list",
                "j1",
            )
        assert result.exit_code == 2


class TestOptimizeJudgePromote:
    def test_promote_with_yes(self):
        judge_resp = {"id": "j1", "task_id": "task-j1"}
        adopt_resp = {"adopted": True}
        responses = [
            stub_api_response(200, judge_resp),
            stub_api_response(200, adopt_resp),
        ]
        with patch("requests.request", side_effect=responses):
            result = run_cli(
                "--output",
                "json",
                "--project-id",
                "p1",
                "optimize",
                "judge",
                "promote",
                "j1",
                "run1",
                "--yes",
            )
        assert result.exit_code == 0
