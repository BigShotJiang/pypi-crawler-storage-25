"""Tests for prompt metadata propagation to manual spans.

Ensures that once ze.prompt() or the OpenAI integration registers prompt
metadata for a trace, all subsequent spans in the same trace inherit
the metadata in their attributes automatically.
"""
import pytest

from zeroeval.observability import span, artifact_span
from zeroeval.observability.tracer import Tracer
from zeroeval.observability.prompt_context import (
    set_prompt_metadata,
    get_prompt_metadata,
    clear_prompt_metadata,
)


SAMPLE_METADATA = {
    "task": "support-ops-copilot",
    "variables": {},
    "zeroeval": {
        "task": "support-ops-copilot",
        "prompt_slug": "support-ops-copilot",
        "prompt_version": 1,
        "prompt_version_id": "pv-uuid-123",
        "content_hash": "abc123",
    },
}


@pytest.mark.core
def test_child_span_inherits_prompt_metadata(tracer: Tracer):
    """A child span created after prompt metadata is registered should carry
    `attributes.task` and `attributes.zeroeval`."""
    with span(name="root") as root_span:
        set_prompt_metadata(root_span.trace_id, SAMPLE_METADATA)

        with span(name="child", kind="llm") as child_span:
            pass

    tracer.flush()
    writer = tracer._writer
    child = next(s for s in writer.spans if s["name"] == "child")

    assert child["attributes"]["task"] == "support-ops-copilot"
    assert child["attributes"]["zeroeval"]["prompt_version_id"] == "pv-uuid-123"


@pytest.mark.core
def test_active_span_updated_when_metadata_set_mid_span(tracer: Tracer):
    """When prompt metadata is set while a span is already active, the currently
    active span should also receive the metadata (mirrors the demo pattern where
    resolve-ticket starts before ze.prompt runs)."""
    with span(name="root") as root_span:
        assert "task" not in root_span.attributes

        set_prompt_metadata(root_span.trace_id, SAMPLE_METADATA)
        for key, val in SAMPLE_METADATA.items():
            if key not in root_span.attributes:
                root_span.attributes[key] = val

        assert root_span.attributes["task"] == "support-ops-copilot"

    tracer.flush()
    writer = tracer._writer
    root = next(s for s in writer.spans if s["name"] == "root")
    assert root["attributes"]["task"] == "support-ops-copilot"


@pytest.mark.core
def test_prompt_metadata_cleared_between_traces(tracer: Tracer):
    """Prompt metadata for one trace must not leak into the next trace."""
    with span(name="trace1-root") as s1:
        set_prompt_metadata(s1.trace_id, SAMPLE_METADATA)
        with span(name="trace1-child") as c1:
            pass

    with span(name="trace2-root") as s2:
        with span(name="trace2-child") as c2:
            pass

    tracer.flush()
    writer = tracer._writer

    t1_child = next(s for s in writer.spans if s["name"] == "trace1-child")
    assert t1_child["attributes"]["task"] == "support-ops-copilot"

    t2_child = next(s for s in writer.spans if s["name"] == "trace2-child")
    assert "task" not in t2_child["attributes"]


@pytest.mark.core
def test_explicit_attributes_override_prompt_context(tracer: Tracer):
    """Span-level explicit attributes take precedence over inherited prompt
    metadata."""
    with span(name="root") as root_span:
        set_prompt_metadata(root_span.trace_id, SAMPLE_METADATA)

        with span(name="override", kind="llm", attributes={"task": "custom-task"}) as child:
            pass

    tracer.flush()
    writer = tracer._writer
    child = next(s for s in writer.spans if s["name"] == "override")
    assert child["attributes"]["task"] == "custom-task"


@pytest.mark.core
def test_prompt_context_module_isolation():
    """Low-level prompt_context module: set/get/clear lifecycle."""
    tid = "test-trace-id-isolation"

    assert get_prompt_metadata(tid) is None

    set_prompt_metadata(tid, SAMPLE_METADATA)
    md = get_prompt_metadata(tid)
    assert md is not None
    assert md["task"] == "support-ops-copilot"

    clear_prompt_metadata(tid)
    assert get_prompt_metadata(tid) is None


@pytest.mark.core
def test_demo_shape_full_flow(tracer: Tracer):
    """Reproduce the demo shape: root span -> ze.prompt sets context ->
    auto OpenAI span (simulated) -> manual card span. Both non-root spans
    should carry prompt metadata."""
    with span(name="resolve-ticket") as root:
        set_prompt_metadata(root.trace_id, SAMPLE_METADATA)
        for key, val in SAMPLE_METADATA.items():
            if key not in root.attributes:
                root.attributes[key] = val

        with span(name="openai.chat.completions.create", kind="llm",
                   attributes={
                       "task": "support-ops-copilot",
                       "zeroeval": SAMPLE_METADATA["zeroeval"],
                       "variables": {},
                   }):
            pass

        with span(name="generate-customer-card", kind="llm",
                   tags={"has_customer_card": "true"}):
            pass

    tracer.flush()
    writer = tracer._writer

    openai_span = next(s for s in writer.spans if s["name"] == "openai.chat.completions.create")
    card_span = next(s for s in writer.spans if s["name"] == "generate-customer-card")

    assert openai_span["attributes"]["task"] == "support-ops-copilot"
    assert openai_span["attributes"]["zeroeval"]["prompt_version_id"] == "pv-uuid-123"

    assert card_span["attributes"]["task"] == "support-ops-copilot"
    assert card_span["attributes"]["zeroeval"]["prompt_version_id"] == "pv-uuid-123"
    assert card_span["tags"]["has_customer_card"] == "true"


@pytest.mark.core
def test_artifact_attributes_coexist_with_prompt_metadata(tracer: Tracer):
    """Manual spans can carry custom completion_artifact_* attributes while
    still inheriting prompt metadata (task, zeroeval.prompt_version_id)."""
    with span(name="resolve-ticket") as root:
        set_prompt_metadata(root.trace_id, SAMPLE_METADATA)
        for key, val in SAMPLE_METADATA.items():
            if key not in root.attributes:
                root.attributes[key] = val

        with span(name="final-decision", kind="llm",
                   attributes={
                       "completion_artifact_type": "final_decision",
                       "completion_artifact_role": "primary",
                       "completion_artifact_label": "Final Decision",
                   },
                   tags={"judge_target": "support_ops_final_decision"}):
            pass

        with span(name="generate-customer-card", kind="llm",
                   attributes={
                       "completion_artifact_type": "customer_card",
                       "completion_artifact_role": "secondary",
                       "completion_artifact_label": "Customer Card",
                   },
                   tags={"has_customer_card": "true"}):
            pass

    tracer.flush()
    writer = tracer._writer

    decision = next(s for s in writer.spans if s["name"] == "final-decision")
    card = next(s for s in writer.spans if s["name"] == "generate-customer-card")

    assert decision["attributes"]["task"] == "support-ops-copilot"
    assert decision["attributes"]["zeroeval"]["prompt_version_id"] == "pv-uuid-123"
    assert decision["attributes"]["completion_artifact_type"] == "final_decision"
    assert decision["attributes"]["completion_artifact_role"] == "primary"
    assert decision["tags"]["judge_target"] == "support_ops_final_decision"

    assert card["attributes"]["task"] == "support-ops-copilot"
    assert card["attributes"]["zeroeval"]["prompt_version_id"] == "pv-uuid-123"
    assert card["attributes"]["completion_artifact_type"] == "customer_card"
    assert card["attributes"]["completion_artifact_role"] == "secondary"
    assert card["tags"]["has_customer_card"] == "true"


@pytest.mark.core
def test_artifact_span_helper_produces_correct_attributes(tracer: Tracer):
    """artifact_span helper writes completion_artifact_* attributes and
    defaults to kind=llm."""
    with artifact_span(
        name="test-artifact",
        artifact_type="final_decision",
        role="primary",
        label="Final Decision",
        tags={"judge_target": "test"},
    ):
        pass

    tracer.flush()
    writer = tracer._writer
    art = next(s for s in writer.spans if s["name"] == "test-artifact")

    assert art["kind"] == "llm"
    assert art["attributes"]["completion_artifact_type"] == "final_decision"
    assert art["attributes"]["completion_artifact_role"] == "primary"
    assert art["attributes"]["completion_artifact_label"] == "Final Decision"
    assert art["tags"]["judge_target"] == "test"


@pytest.mark.core
def test_artifact_span_helper_inherits_prompt_metadata(tracer: Tracer):
    """artifact_span inherits prompt metadata from the trace context just
    like a regular span does."""
    with span(name="root") as root:
        set_prompt_metadata(root.trace_id, SAMPLE_METADATA)
        for key, val in SAMPLE_METADATA.items():
            if key not in root.attributes:
                root.attributes[key] = val

        with artifact_span(
            name="decision",
            artifact_type="final_decision",
            role="primary",
        ):
            pass

    tracer.flush()
    writer = tracer._writer
    decision = next(s for s in writer.spans if s["name"] == "decision")

    assert decision["attributes"]["task"] == "support-ops-copilot"
    assert decision["attributes"]["zeroeval"]["prompt_version_id"] == "pv-uuid-123"
    assert decision["attributes"]["completion_artifact_type"] == "final_decision"
    assert decision["attributes"]["completion_artifact_role"] == "primary"


@pytest.mark.core
def test_artifact_span_helper_merges_extra_attributes(tracer: Tracer):
    """User-provided attributes are merged with artifact attributes;
    artifact keys take precedence."""
    with artifact_span(
        name="merged",
        artifact_type="report",
        role="secondary",
        label="Report",
        attributes={"model": "gpt-5", "provider": "openai"},
    ):
        pass

    tracer.flush()
    writer = tracer._writer
    merged = next(s for s in writer.spans if s["name"] == "merged")

    assert merged["attributes"]["model"] == "gpt-5"
    assert merged["attributes"]["provider"] == "openai"
    assert merged["attributes"]["completion_artifact_type"] == "report"
    assert merged["attributes"]["completion_artifact_role"] == "secondary"
    assert merged["attributes"]["completion_artifact_label"] == "Report"


@pytest.mark.core
def test_artifact_span_helper_label_defaults_to_name(tracer: Tracer):
    """When label is omitted, artifact_span uses the span name."""
    with artifact_span(name="my-artifact", artifact_type="summary", role="primary"):
        pass

    tracer.flush()
    writer = tracer._writer
    art = next(s for s in writer.spans if s["name"] == "my-artifact")

    assert art["attributes"]["completion_artifact_label"] == "my-artifact"
