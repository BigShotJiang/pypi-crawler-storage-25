import pytest

from zeroeval.observability.signals import emit_signal, set_signal
from zeroeval.observability.span import Span


@pytest.mark.core
def test_emit_signal_defaults_to_current_span_without_immediate_send(monkeypatch):
    span = Span(name="task:test")
    sent = {"called": False}

    monkeypatch.setattr(
        "zeroeval.observability.signals.tracer.get_current_span",
        lambda: span,
    )
    monkeypatch.setattr(
        "zeroeval.observability.signals.tracer.get_current_trace",
        lambda: None,
    )
    monkeypatch.setattr(
        "zeroeval.observability.signals._send_signals_immediately",
        lambda *args, **kwargs: sent.__setitem__("called", True),
    )

    assert emit_signal("retrieval_hit", True) is True
    assert sent["called"] is False
    assert span.signals["retrieval_hit"].signal_type == "boolean"
    assert span.signals["retrieval_hit"].value == "true"


@pytest.mark.core
def test_emit_signal_falls_back_to_trace_and_sends_immediately(monkeypatch):
    payload = {}

    monkeypatch.setattr(
        "zeroeval.observability.signals.tracer.get_current_span",
        lambda: None,
    )
    monkeypatch.setattr(
        "zeroeval.observability.signals.tracer.get_current_trace",
        lambda: "trace-123",
    )
    monkeypatch.setattr(
        "zeroeval.observability.signals._send_signals_immediately",
        lambda entity_type, entity_id, signals, signal_types=None: payload.update(
            {
                "entity_type": entity_type,
                "entity_id": entity_id,
                "signals": signals,
                "signal_types": signal_types,
            }
        )
        or True,
    )

    assert emit_signal("phase", "retrieval") is True
    assert payload["entity_type"] == "trace"
    assert payload["entity_id"] == "trace-123"
    assert payload["signals"] == {"phase": "retrieval"}


@pytest.mark.core
def test_set_signal_supports_categorical_without_double_write(monkeypatch):
    span = Span(name="task:test")
    sent = {"called": False}

    monkeypatch.setattr(
        "zeroeval.observability.signals._send_signals_immediately",
        lambda *args, **kwargs: sent.__setitem__("called", True),
    )

    assert (
        set_signal(
            span,
            {"phase": "retrieval"},
            immediate=False,
            signal_types={"phase": "categorical"},
        )
        is True
    )
    assert sent["called"] is False
    assert span.signals["phase"].signal_type == "categorical"
    assert span.signals["phase"].value == "retrieval"
