import pytest

from zeroeval.observability import span
from zeroeval.observability.tracer import Tracer


@pytest.mark.core
def test_decorator_success(tracer: Tracer):
    """Tests that the @span decorator wraps a function and records a span."""

    @span(name="my_decorated_function")
    def my_func(a, b):
        return a + b

    result = my_func(1, 2)

    tracer.flush()

    assert result == 3
    mock_writer = tracer._writer
    assert len(mock_writer.spans) == 1

    s = mock_writer.spans[0]
    assert s["name"] == "my_decorated_function"
    assert s["status"] == "ok"
    assert s["input_data"] == {"a": 1, "b": 2}
    assert s["output_data"] == 3


@pytest.mark.core
def test_decorator_exception(tracer: Tracer):
    """Tests that the @span decorator correctly records an exception."""

    @span(name="my_failing_function")
    def my_func():
        raise ValueError("This is a test error")

    with pytest.raises(ValueError, match="This is a test error"):
        my_func()

    tracer.flush()

    mock_writer = tracer._writer
    assert len(mock_writer.spans) == 1

    s = mock_writer.spans[0]
    assert s["name"] == "my_failing_function"
    assert s["status"] == "error"
    assert s["error_code"] == "ValueError"
    assert s["error_message"] == "This is a test error"
    assert "Traceback" in s["error_stack"]


@pytest.mark.core
@pytest.mark.asyncio
async def test_decorator_async_success(tracer: Tracer):
    """Tests that the @span decorator correctly wraps an async function."""

    @span(name="my_async_function")
    async def my_async_func(a, b):
        return a + b

    result = await my_async_func(3, 4)

    tracer.flush()

    assert result == 7
    mock_writer = tracer._writer
    assert len(mock_writer.spans) == 1

    s = mock_writer.spans[0]
    assert s["name"] == "my_async_function"
    assert s["status"] == "ok"
    assert s["output_data"] == 7


@pytest.mark.core
def test_decorator_redacts_captured_values(tracer: Tracer):
    tracer.configure(redaction={"enabled": True})

    @span(name="redacted_function")
    def my_func(user_email, payload):
        return {
            "phone": "+1 (415) 555-1234",
            "secret": "Bearer eyJhbGciOiJIUzI1NiJ9.payload.signature",
            "payload": payload,
        }

    my_func(
        "alice@example.com",
        {"ssn": "123-45-6789", "notes": "card 4242 4242 4242 4242"},
    )

    tracer.flush()

    s = tracer._writer.spans[0]
    assert s["input_data"]["user_email"] == "[REDACTED_EMAIL_A]"
    assert s["input_data"]["payload"]["ssn"] == "[REDACTED_SSN_A]"
    assert s["input_data"]["payload"]["notes"] == "card [REDACTED_CARD_A]"
    assert s["output_data"]["phone"] == "[REDACTED_PHONE_A]"
    assert s["output_data"]["secret"] == "Bearer [REDACTED_SECRET_A]"
    assert s["attributes"]["zeroeval_redaction"]["enabled"] is True
