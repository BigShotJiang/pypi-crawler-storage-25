import logging
import os
import re
import subprocess
import sys
import uuid
from unittest.mock import Mock

import pytest

from zeroeval.observability import span
from zeroeval.observability.redaction import RedactionReferenceContext, Redactor
from zeroeval.observability.writer import SpanBackendWriter

TOKEN_RE = re.compile(r"\[REDACTED_[A-Z]+(?:_[A-Z0-9]+)?\]")


@pytest.mark.core
def test_redact_attributes_is_noop_under_ingestion_only_policy():
    redactor = Redactor(
        {
            "enabled": True,
            "custom_patterns": [r"customer-\d+"],
        }
    )

    value = {
        "email": "alice@example.com",
        "phone": "+1 (415) 555-1234",
        "notes": "SSN 123-45-6789",
        "authorization": "Bearer top-secret-token",
    }

    reference_context = RedactionReferenceContext()
    sanitized, summary = redactor.redact_attributes(value, context=reference_context)

    assert sanitized is value
    assert summary["count"] == 0


@pytest.mark.core
def test_redaction_env_toggle(monkeypatch):
    monkeypatch.setenv("ZEROEVAL_REDACT_PII", "true")

    assert Redactor().enabled is True


@pytest.mark.core
def test_manual_span_set_io_redacts_values(tracer):
    tracer.configure(redaction={"enabled": True})

    with span(name="manual-redaction") as current_span:
        current_span.set_io(
            input_data={
                "messages": [{"role": "user", "content": "email alice@example.com"}],
                "authorization": "Bearer abc123",
            },
            output_data='{"phone":"+1 (415) 555-1234","ip":"10.0.0.1"}',
        )

    tracer.flush()

    stored_span = tracer._writer.spans[0]
    assert (
        stored_span["input_data"]["messages"][0]["content"]
        == "email [REDACTED_EMAIL_A]"
    )
    assert stored_span["input_data"]["authorization"] == "Bearer [REDACTED_SECRET_A]"
    assert '"phone": "[REDACTED_PHONE_A]"' in stored_span["output_data"]
    assert stored_span["attributes"]["zeroeval_redaction"]["enabled"] is True


@pytest.mark.core
def test_disabled_redaction_preserves_manual_strings(tracer):
    tracer.configure(redaction={"enabled": False})

    with span(name="manual-raw") as current_span:
        current_span.set_io(
            input_data="alice@example.com",
            output_data="Bearer top-secret-token",
        )

    tracer.flush()

    stored_span = tracer._writer.spans[0]
    assert stored_span["input_data"] == "alice@example.com"
    assert stored_span["output_data"] == "Bearer top-secret-token"


@pytest.mark.core
def test_writer_redacts_logs_and_payload(monkeypatch, caplog, tracer):
    tracer.configure(redaction={"enabled": True})
    monkeypatch.setenv("ZEROEVAL_API_KEY", "sk_ze_supersecret")

    posted = {}

    class Response:
        status_code = 200
        reason = "OK"
        headers = {"content-type": "application/json"}
        text = '{"echo":"alice@example.com"}'
        elapsed = Mock(total_seconds=lambda: 0.01)

        def json(self):
            return {"echo": "alice@example.com"}

        def raise_for_status(self):
            return None

    def fake_post(endpoint, headers, json, timeout):
        posted["endpoint"] = endpoint
        posted["headers"] = headers
        posted["json"] = json
        posted["timeout"] = timeout
        return Response()

    monkeypatch.setattr("requests.post", fake_post)

    writer = SpanBackendWriter()
    raw_span = {
        "name": "writer-redaction",
        "kind": "llm",
        "session_id": "alice@example.com",
        "session_name": None,
        "trace_id": str(uuid.uuid4()),
        "span_id": str(uuid.uuid4()),
        "parent_id": None,
        "start_time": 1.0,
        "end_time": 2.0,
        "duration_ms": 1000.0,
        "attributes": {
            "messages": [{"role": "user", "content": "email alice@example.com"}],
            "authorization": "Bearer top-secret-token",
        },
        "tags": {"email": "alice@example.com"},
        "trace_tags": {},
        "session_tags": {},
        "signals": {},
        "ab_choices": [],
        "input_data": "customer alice@example.com",
        "output_data": "Call +1 (415) 555-1234",
        "code": None,
        "code_filepath": None,
        "code_lineno": None,
        "error_code": None,
        "error_message": "authorization: Bearer top-secret-token",
        "error_stack": None,
        "status": "error",
    }

    with caplog.at_level(logging.DEBUG):
        result = writer.write([raw_span])

    assert result["success"] is True
    sent_payload = posted["json"][0]

    assert "[REDACTED_EMAIL]" in str(sent_payload.get("input_data", ""))
    assert "[REDACTED_PHONE]" in str(sent_payload.get("output_data", ""))
    assert sent_payload["attributes"]["authorization"] == "Bearer top-secret-token"
    assert sent_payload["tags"]["email"] == "alice@example.com"
    assert sent_payload["error_message"] == "authorization: Bearer top-secret-token"
    assert "sk_ze_supersecret" not in caplog.text


@pytest.mark.core
def test_same_email_uses_same_token_within_span(tracer):
    tracer.configure(redaction={"enabled": True})

    with span(
        name="same-email",
        attributes={"contact": "alice@example.com"},
        tags={"owner_email": "alice@example.com"},
    ) as current_span:
        current_span.set_io(
            input_data={"email": "alice@example.com"},
            output_data="Processed alice@example.com",
        )
        current_span.set_error("ValueError", "alice@example.com failed")

    tracer.flush()

    stored_span = tracer._writer.spans[0]
    assert stored_span["attributes"]["contact"] == "alice@example.com"
    assert stored_span["tags"]["owner_email"] == "alice@example.com"
    assert stored_span["input_data"]["email"] == "[REDACTED_EMAIL_A]"
    assert stored_span["output_data"] == "Processed [REDACTED_EMAIL_A]"
    assert stored_span["error_message"] == "alice@example.com failed"


@pytest.mark.core
def test_parent_child_spans_share_redaction_tokens(tracer):
    tracer.configure(redaction={"enabled": True})

    with span(name="parent", attributes={"email": "alice@example.com"}), span(
        name="child", attributes={"email": "alice@example.com"}
    ) as current_span:
        current_span.set_io(output_data="alice@example.com")

    tracer.flush()

    parent = next(item for item in tracer._writer.spans if item["name"] == "parent")
    child = next(item for item in tracer._writer.spans if item["name"] == "child")

    assert parent["attributes"]["email"] == "alice@example.com"
    assert child["attributes"]["email"] == "alice@example.com"
    assert child["output_data"] == "[REDACTED_EMAIL_A]"


@pytest.mark.core
def test_different_emails_get_distinct_tokens_in_trace(tracer):
    tracer.configure(redaction={"enabled": True})

    with span(
        name="different-emails", attributes={"primary": "alice@example.com"}
    ) as current_span:
        current_span.set_io(output_data="bob@example.com")

    tracer.flush()

    stored_span = tracer._writer.spans[0]
    assert stored_span["attributes"]["primary"] == "alice@example.com"
    assert stored_span["output_data"] == "[REDACTED_EMAIL_A]"


@pytest.mark.core
def test_same_email_restarts_token_sequence_across_traces(tracer):
    tracer.configure(redaction={"enabled": True})

    with span(name="trace-one") as s1:
        s1.set_io(input_data="alice@example.com")
    tracer.flush()
    first = tracer._writer.spans[-1]["input_data"]

    with span(name="trace-two", session_id="new-session") as s2:
        s2.set_io(input_data="alice@example.com")
    tracer.flush()
    second = tracer._writer.spans[-1]["input_data"]

    assert first == "[REDACTED_EMAIL_A]"
    assert second == "[REDACTED_EMAIL_A]"


@pytest.mark.core
def test_writer_preserves_existing_placeholder_tokens(monkeypatch, tracer):
    tracer.configure(redaction={"enabled": True})
    trace_id = str(uuid.uuid4())
    context = tracer.get_redaction_context(trace_id)
    assert context is not None
    email_token = context.get_placeholder("email", "alice@example.com")

    posted = {}

    class Response:
        status_code = 200
        reason = "OK"
        headers = {}
        text = "ok"
        elapsed = Mock(total_seconds=lambda: 0.01)

        def json(self):
            return {"ok": True}

        def raise_for_status(self):
            return None

    def fake_post(endpoint, headers, json, timeout):
        posted["json"] = json
        return Response()

    monkeypatch.setattr("requests.post", fake_post)

    writer = SpanBackendWriter()
    raw_span = {
        "name": "writer-stable-placeholder",
        "kind": "llm",
        "session_id": None,
        "session_name": None,
        "trace_id": trace_id,
        "span_id": str(uuid.uuid4()),
        "parent_id": None,
        "start_time": 1.0,
        "end_time": 2.0,
        "duration_ms": 1000.0,
        "attributes": {"email": email_token},
        "tags": {},
        "trace_tags": {},
        "session_tags": {},
        "signals": {},
        "ab_choices": [],
        "input_data": email_token,
        "output_data": "alice@example.com",
        "code": None,
        "code_filepath": None,
        "code_lineno": None,
        "error_code": None,
        "error_message": None,
        "error_stack": None,
        "status": "ok",
    }

    writer.write([raw_span])

    sent = posted["json"][0]
    assert sent["attributes"]["email"] == email_token
    assert sent["input_data"] == email_token
    assert sent["output_data"] == email_token


@pytest.mark.core
def test_example_shows_repeated_placeholder_tokens():
    sdk_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    result = subprocess.run(
        [sys.executable, "examples/pii_redaction.py"],
        cwd=sdk_root,
        env={**os.environ, "PYTHONPATH": "src"},
        capture_output=True,
        text=True,
        check=True,
    )

    email_tokens = TOKEN_RE.findall(result.stdout)
    assert email_tokens.count("[REDACTED_EMAIL_A]") >= 2
    assert "alice@example.com" in result.stdout
