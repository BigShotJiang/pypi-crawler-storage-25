import os
from contextlib import contextmanager

import pytest

from zeroeval.core.artifacts import InMemoryArtifactSink, RunArtifactRecorder
from zeroeval.core.dataset_class import Dataset
from zeroeval.core.execution import CheckpointConfig, ExecutionConfig, ResumeConfig
from zeroeval.core.kernel import ExecutionEngine, ExecutionRequest, KernelHooks
from zeroeval.core.eval import Eval
from zeroeval.core.task import task


@pytest.mark.core
def test_execution_engine_preserves_row_order_and_retry_count():
    attempts = {}

    def flaky(row):
        row_id = row["row_id"]
        attempts[row_id] = attempts.get(row_id, 0) + 1
        if row_id == "2" and attempts[row_id] == 1:
            raise TimeoutError("transient")
        return {"prediction": f"ok_{row_id}"}

    flushed = []
    engine = ExecutionEngine(
        result_flusher=lambda rows: flushed.extend(rows),
        trace_flusher=lambda: None,
    )
    request = ExecutionRequest(
        task_name="flaky",
        task_func=flaky,
        rows=[{"row_id": "1"}, {"row_id": "2"}, {"row_id": "3"}],
        execution=ExecutionConfig(workers=2, max_in_flight=2),
        checkpoint=CheckpointConfig(flush_every_rows=1, flush_every_seconds=0.5),
        completed_row_ids=set(),
    )
    summary = engine.execute(request)
    assert [r["row_id"] for r in summary.rows] == ["1", "2", "3"]
    assert summary.retry_attempts_total == 1
    assert len(flushed) == 3


@pytest.mark.core
def test_run_artifact_recorder_sequence_and_event_types():
    sink = InMemoryArtifactSink()
    recorder = RunArtifactRecorder(eval_id="eval_1", sinks=[sink])
    recorder.record("run_started", {"planned_rows": 2})
    recorder.record("sample_started", {"row_id": "1"})
    recorder.record("sample_completed", {"row_id": "1"})
    recorder.record("run_completed", {"rows": 1})
    assert [event.seq for event in sink.events] == [1, 2, 3, 4]
    assert [event.event_type for event in sink.events] == [
        "run_started",
        "sample_started",
        "sample_completed",
        "run_completed",
    ]


@pytest.mark.core
def test_dataset_eval_emits_artifacts_and_consistency(monkeypatch):
    os.environ["ZEROEVAL_ARTIFACT_V1"] = "true"
    os.environ["ZEROEVAL_DUAL_WRITE_COMPARE"] = "true"
    try:
        @task(outputs=["prediction"])
        def solve(row):
            return {"prediction": row["x"]}

        ds = Dataset("local_ds", data=[{"row_id": "1", "x": "ok"}])
        monkeypatch.setattr(
            "zeroeval.core.eval.Eval._ensure_experiment_exists",
            lambda self: None,
        )
        monkeypatch.setattr(
            "zeroeval.core.eval.Eval._update_backend_status",
            lambda self, status: None,
        )
        monkeypatch.setattr(
            "zeroeval.core.eval.Eval._submit_result_batch",
            lambda self, rows: None,
        )
        monkeypatch.setattr(
            "zeroeval.core.eval.Eval.load_existing_result_row_ids",
            lambda self, repetition=None: set(),
        )

        @contextmanager
        def _noop_span(name=None):
            class _Span:
                trace_id = None

                def set_error(self, **kwargs):
                    return None

            yield _Span()

        monkeypatch.setattr(
            "zeroeval.observability.decorators.span",
            _noop_span,
        )

        run = ds.eval(
            solve,
            eval_id="eval_local",
            resume=ResumeConfig(mode="fresh"),
            checkpoint=CheckpointConfig(enabled=False),
            execution=ExecutionConfig(workers=1, max_in_flight=1),
        )
        events = run.get_artifact_events()
        assert any(e["event_type"] == "run_started" for e in events)
        assert any(e["event_type"] == "sample_completed" for e in events)
        assert any(e["event_type"] == "run_completed" for e in events)
        assert run.validate_artifact_consistency() == []
    finally:
        os.environ.pop("ZEROEVAL_ARTIFACT_V1", None)
        os.environ.pop("ZEROEVAL_DUAL_WRITE_COMPARE", None)


@pytest.mark.core
def test_kernel_hooks_receive_expected_payloads():
    seen = {"started": 0, "completed": 0}
    hooks = KernelHooks(
        on_sample_started=lambda payload: seen.__setitem__("started", seen["started"] + 1),
        on_sample_completed=lambda payload: seen.__setitem__("completed", seen["completed"] + 1),
    )
    engine = ExecutionEngine(
        result_flusher=lambda rows: None,
        hooks=hooks,
    )
    request = ExecutionRequest(
        task_name="hooked",
        task_func=lambda row: {"prediction": row["row_id"]},
        rows=[{"row_id": "1"}, {"row_id": "2"}],
        execution=ExecutionConfig(workers=1, max_in_flight=1),
        checkpoint=CheckpointConfig(enabled=False),
        completed_row_ids=set(),
    )
    engine.execute(request)
    assert seen == {"started": 2, "completed": 2}


@pytest.mark.core
def test_eval_validate_artifact_consistency_detects_bad_sequences():
    run = Eval(
        dataset_name="d",
        dataset_id="",
        dataset_version_id="",
        task_name="t",
        task_code="",
        rows=[{"row_id": "1"}],
        outputs=["prediction"],
        experiment_id="eval_123",
    )
    sink = InMemoryArtifactSink()
    recorder = RunArtifactRecorder(eval_id="eval_123", sinks=[sink])
    run._artifact_memory_sink = sink
    run._artifact_recorder = recorder
    # Create a gap in sequence manually.
    recorder.seq = 1
    recorder.record("sample_completed", {"row_id": "1"})
    recorder.seq = 3
    recorder.record("run_completed", {})
    errors = run.validate_artifact_consistency()
    assert "non_monotonic_event_sequence" in errors

