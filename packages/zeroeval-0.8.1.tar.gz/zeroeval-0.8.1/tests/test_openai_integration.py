from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

import pytest

from zeroeval.observability.integrations.openai.integration import OpenAIIntegration


@pytest.mark.asyncio
async def test_async_zeroeval_routing_restores_api_key_without_base_url(
    monkeypatch,
):
    monkeypatch.setenv("ZEROEVAL_API_KEY", "proxy-api-key")
    monkeypatch.setenv("ZEROEVAL_API_URL", "https://api.zeroeval.local")

    tracer = Mock()
    span = Mock()
    span.attributes = {}
    tracer.start_span.return_value = span

    integration = OpenAIIntegration(tracer)

    resource = SimpleNamespace(_client=SimpleNamespace(api_key="original-api-key"))
    legacy_response = SimpleNamespace(parse=lambda: None)

    original = AsyncMock(return_value=legacy_response)
    wrapped = integration._wrap_chat_completion_async()(original)

    result = await wrapped(
        resource,
        model="zeroeval/gpt-4o-mini",
        messages=[{"role": "user", "content": "hello"}],
    )

    assert result is legacy_response
    assert resource._client.api_key == "original-api-key"
    assert original.await_args.kwargs["model"] == "gpt-4o-mini"
    assert span.attributes["provider"] == "zeroeval"
    span.set_io.assert_called_once()
    tracer.end_span.assert_called_once_with(span)


def test_sync_zeroeval_routing_restores_api_key_without_base_url(monkeypatch):
    monkeypatch.setenv("ZEROEVAL_API_KEY", "proxy-api-key")
    monkeypatch.setenv("ZEROEVAL_API_URL", "https://api.zeroeval.local")

    tracer = Mock()
    span = Mock()
    span.attributes = {}
    tracer.start_span.return_value = span

    integration = OpenAIIntegration(tracer)

    resource = SimpleNamespace(_client=SimpleNamespace(api_key="original-api-key"))
    legacy_response = SimpleNamespace(parse=lambda: None)

    original = Mock(return_value=legacy_response)
    wrapped = integration._wrap_chat_completion_sync(resource)(original)

    result = wrapped(
        model="zeroeval/gpt-4o-mini",
        messages=[{"role": "user", "content": "hello"}],
    )

    assert result is legacy_response
    assert resource._client.api_key == "original-api-key"
    assert original.call_args.kwargs["model"] == "gpt-4o-mini"
    assert span.attributes["provider"] == "zeroeval"
    span.set_io.assert_called_once()
    tracer.end_span.assert_called_once_with(span)
