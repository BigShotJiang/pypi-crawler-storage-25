"""
Streaming terminal display for eval execution.

Prints one line per event as it happens — no cursor movement, no redraws.
Works in TTY, pipes, captures, CI, and AI agent terminals.

Automatically disabled when ZEROEVAL_DISPLAY=0.
"""

from __future__ import annotations

import os
import sys
import threading
import time
from typing import Any


def should_show_display(display_arg: bool | None) -> bool:
    if display_arg is True:
        return True
    if display_arg is False:
        return False
    env = os.environ.get("ZEROEVAL_DISPLAY", "").lower()
    if env in ("0", "false", "no", "off"):
        return False
    return True


def _ts(elapsed: float) -> str:
    m, s = divmod(int(elapsed), 60)
    return f"{m:02d}:{s:02d}"


class EvalDisplay:
    """Streaming terminal display for a single eval execution."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._dataset_name = ""
        self._subset_name = ""
        self._task_name = ""
        self._planned = 0
        self._workers = 0
        self._retries = 0
        self._model = ""

        self._completed = 0
        self._failed = 0
        self._retried = 0
        self._errors: list[tuple[str, str, str]] = []
        self._start_time = 0.0
        self._scoring_start_time = 0.0
        self._scorer_totals: dict[str, int] = {}
        self._scorer_counts: dict[str, int] = {}
        self._scorer_last_printed: dict[str, int] = {}

    def set_config(
        self,
        *,
        dataset_name: str,
        subset_name: str | None,
        task_name: str,
        planned_rows: int,
        workers: int,
        retries: int,
        parameters: dict[str, Any] | None = None,
    ) -> None:
        self._dataset_name = dataset_name
        self._subset_name = subset_name or ""
        self._task_name = task_name
        self._planned = planned_rows
        self._workers = workers
        self._retries = retries
        self._model = (parameters or {}).get("model", "")

    def on_run_started(self, _payload: dict[str, Any]) -> None:
        self._start_time = time.monotonic()
        self._print_header()

    def on_sample_completed(self, payload: dict[str, Any]) -> None:
        row = payload.get("row", {})
        row_id = str(payload.get("row_id", "?"))
        with self._lock:
            self._completed += 1
            if row.get("_attempt", 1) > 1:
                self._retried += 1
            n = self._completed
        elapsed = time.monotonic() - self._start_time
        pad = len(str(self._planned))
        print(f"  [{_ts(elapsed)}] ok  {n:>{pad}}/{self._planned}  {row_id}", flush=True)

    def on_sample_failed(self, payload: dict[str, Any]) -> None:
        row = payload.get("row", {})
        row_id = str(payload.get("row_id", "?"))
        error_code = row.get("_error_code", "Error")
        error_msg = str(row.get("_error", ""))[:120]
        with self._lock:
            self._completed += 1
            self._failed += 1
            if len(self._errors) < 50:
                self._errors.append((row_id, error_code, error_msg))
            n = self._completed
        elapsed = time.monotonic() - self._start_time
        pad = len(str(self._planned))
        print(f"  [{_ts(elapsed)}] ERR {n:>{pad}}/{self._planned}  {row_id}  {error_code}: {error_msg}", flush=True)

    def on_run_completed(self, _payload: dict[str, Any]) -> None:
        self._print_finish(failed=False)

    def on_run_failed(self, _payload: dict[str, Any]) -> None:
        self._print_finish(failed=True)

    # -- Scoring phase -------------------------------------------------------

    def start_scoring(self, scorer_names: list[str]) -> None:
        self._scoring_start_time = time.monotonic()
        print(f"  Scoring: {', '.join(scorer_names)} ...", flush=True)

    def scorer_started(self, name: str, *, mode: str, total: int | None = None) -> None:
        if total is not None:
            self._scorer_totals[name] = total
        self._scorer_counts[name] = 0
        self._scorer_last_printed[name] = 0
        suffix = f" · {total} items" if total is not None else ""
        print(f"    {name} ({mode}) started{suffix}", flush=True)

    def scorer_progress(self, name: str, completed: int, *, force: bool = False) -> None:
        total = self._scorer_totals.get(name)
        self._scorer_counts[name] = completed
        last_printed = self._scorer_last_printed.get(name, 0)

        should_print = force
        if not should_print:
            if completed <= 3:
                should_print = True
            elif total is not None and completed == total:
                should_print = True
            elif completed - last_printed >= 100:
                should_print = True

        if not should_print:
            return

        self._scorer_last_printed[name] = completed
        elapsed = time.monotonic() - (self._scoring_start_time or self._start_time or time.monotonic())
        if total is not None:
            pad = len(str(total))
            print(
                f"    [{_ts(elapsed)}] {name}  {completed:>{pad}}/{total}",
                flush=True,
            )
        else:
            print(f"    [{_ts(elapsed)}] {name}  {completed}", flush=True)

    def scorer_done(self, name: str) -> None:
        print(f"    {name} done", flush=True)

    def finish_scoring(self) -> None:
        pass

    # -- Summary -------------------------------------------------------------

    def show_summary(
        self,
        *,
        metrics: dict[str, Any],
        health: dict[str, Any],
        eval_id: str | None,
    ) -> None:
        elapsed = time.monotonic() - self._start_time if self._start_time else 0
        total = health.get("total_count", self._planned)
        success = health.get("success_count", 0)
        errors = health.get("error_count", 0)
        rate = total / elapsed if elapsed > 0 else 0

        print(flush=True)
        print("  Results", flush=True)

        display_metrics = {
            k: v for k, v in metrics.items()
            if not k.startswith("_") and isinstance(v, (int, float))
        }
        if display_metrics:
            max_key = max(len(k) for k in display_metrics)
            for key, value in display_metrics.items():
                fmt = f"{value:.4f}" if isinstance(value, float) else str(value)
                print(f"    {key:<{max_key}}  {fmt}", flush=True)

        print(flush=True)
        print(f"  {total} rows  {elapsed:.0f}s  {rate:.1f} rows/s", flush=True)
        print(f"  ok {success}  errors {errors}", flush=True)

        if eval_id:
            short = eval_id if len(eval_id) <= 36 else eval_id[:36]
            print(f"  eval {short}", flush=True)

        if self._errors:
            print(flush=True)
            print(f"  Errors ({len(self._errors)}):", flush=True)
            for row_id, code, msg in self._errors[:10]:
                print(f"    {row_id}  {code}  {msg}", flush=True)
            remaining = len(self._errors) - 10
            if remaining > 0:
                print(f"    ... and {remaining} more", flush=True)

        print(flush=True)

    # -- Internal ------------------------------------------------------------

    def _print_header(self) -> None:
        print(flush=True)
        print("  zeroeval", flush=True)
        print(flush=True)
        title = f"  {self._dataset_name}"
        if self._subset_name:
            title += f" / {self._subset_name}"
        title += f" · {self._planned} rows"
        print(title, flush=True)
        meta = f"  task  {self._task_name}"
        if self._model:
            meta += f"    model {self._model}"
        print(meta, flush=True)
        parts = []
        if self._workers > 1:
            parts.append(f"workers {self._workers}")
        if self._retries > 1:
            parts.append(f"retries {self._retries}")
        if parts:
            print(f"  {'    '.join(parts)}", flush=True)
        print(flush=True)

    def _print_finish(self, *, failed: bool) -> None:
        elapsed = time.monotonic() - self._start_time if self._start_time else 0
        rate = self._completed / elapsed if elapsed > 0 else 0
        status = "FAILED" if failed else "Complete"
        ok = self._completed - self._failed
        print(flush=True)
        print(
            f"  {status}  {self._completed}/{self._planned}  "
            f"{rate:.1f} rows/s  {elapsed:.0f}s  "
            f"ok {ok}  errors {self._failed}  retried {self._retried}",
            flush=True,
        )
        print(flush=True)
