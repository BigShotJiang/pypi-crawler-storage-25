from __future__ import annotations

import concurrent.futures
import json
import random
import time
import traceback
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Callable, Optional

from .interfaces import ExecutionRequest, ExecutionSummary, ResultFlusher, TraceFlusher


@dataclass(slots=True)
class KernelHooks:
    """Lifecycle hooks emitted during execution for adapters/artifacts."""

    on_run_started: Callable[[dict[str, Any]], None] | None = None
    on_sample_started: Callable[[dict[str, Any]], None] | None = None
    on_sample_completed: Callable[[dict[str, Any]], None] | None = None
    on_sample_failed: Callable[[dict[str, Any]], None] | None = None
    on_run_completed: Callable[[dict[str, Any]], None] | None = None
    on_run_failed: Callable[[dict[str, Any]], None] | None = None


def _noop_span():
    @contextmanager
    def _span(*_args, **_kwargs):
        class _Span:
            trace_id = None

            def set_error(self, **_kwargs):
                return None

        yield _Span()

    return _span


def _preview_payload(payload: Any, *, max_chars: int = 2000) -> str:
    try:
        rendered = json.dumps(payload, default=str, ensure_ascii=False)
    except Exception:
        rendered = repr(payload)
    if len(rendered) <= max_chars:
        return rendered
    return f"{rendered[: max_chars - 1]}…"


def _start_task_span(
    span_factory: Callable[..., Any],
    *,
    task_name: str,
    row_id: str,
    attempt: int,
):
    try:
        return span_factory(
            name=f"task:{task_name}",
            kind="task",
            attributes={
                "task_name": task_name,
                "row_id": row_id,
                "retry_attempt": attempt,
            },
        )
    except TypeError:
        # Preserve compatibility with simple/no-op span factories used in tests.
        return span_factory(name=f"task:{task_name}")


class ExecutionEngine:
    """
    Backend-agnostic execution kernel.

    It handles concurrency, retry, ordering, and checkpoint flush cadence.
    """

    def __init__(
        self,
        *,
        result_flusher: ResultFlusher,
        trace_flusher: TraceFlusher | None = None,
        span_factory: Callable[..., Any] | None = None,
        hooks: KernelHooks | None = None,
    ):
        self._result_flusher = result_flusher
        self._trace_flusher = trace_flusher
        self._span_factory = span_factory or _noop_span()
        self._hooks = hooks or KernelHooks()

    def execute(self, request: ExecutionRequest) -> ExecutionSummary:
        execution = request.execution
        checkpoint = request.checkpoint

        retry_attempts_total = 0
        result_rows: list[dict[str, Any]] = []
        pending_rows: list[dict[str, Any]] = []
        last_flush_at = time.monotonic()

        if self._hooks.on_run_started:
            self._hooks.on_run_started(
                {"task_name": request.task_name, "planned_rows": len(request.rows)}
            )

        def _is_retryable(exc: Exception) -> bool:
            return exc.__class__.__name__ in execution.retry.retry_on

        def _backoff_delay(attempt: int) -> float:
            delay = execution.retry.base_delay_s
            if execution.retry.exponential:
                delay = min(
                    execution.retry.max_delay_s,
                    execution.retry.base_delay_s * (2 ** max(0, attempt - 1)),
                )
            if execution.retry.jitter:
                delay *= random.uniform(0.85, 1.15)
            return max(0.0, delay)

        def _flush_pending_if_due(force: bool = False) -> None:
            nonlocal pending_rows, last_flush_at
            if not checkpoint.enabled or not pending_rows:
                return
            now = time.monotonic()
            should_flush = force or (
                len(pending_rows) >= checkpoint.flush_every_rows
                or (now - last_flush_at) >= checkpoint.flush_every_seconds
            )
            if not should_flush:
                return
            to_flush = pending_rows
            if not checkpoint.persist_errors:
                to_flush = [r for r in pending_rows if not r.get("_error")]
            if to_flush:
                self._result_flusher(to_flush)
            pending_rows = []
            last_flush_at = now

        def _execute_single_row(actual_data: dict[str, Any]) -> dict[str, Any]:
            nonlocal retry_attempts_total
            row = actual_data.copy()
            row_id = str(row.get("row_id"))

            if request.completed_row_ids and row_id in request.completed_row_ids:
                row["_skipped"] = True
                return row

            if self._hooks.on_sample_started:
                self._hooks.on_sample_started({"row_id": row_id})

            last_error: Optional[Exception] = None
            attempts = max(1, execution.retry.max_attempts)
            for attempt in range(1, attempts + 1):
                row["_attempt"] = attempt
                with _start_task_span(
                    self._span_factory,
                    task_name=request.task_name,
                    row_id=row_id,
                    attempt=attempt,
                ) as current_span:
                    try:
                        if current_span and hasattr(current_span, "set_io"):
                            current_span.set_io(
                                input_data=_preview_payload(row),
                            )
                        task_output = request.task_func(row)
                        row.update(task_output)
                        if current_span and hasattr(current_span, "set_io"):
                            current_span.set_io(
                                output_data=_preview_payload(task_output),
                            )
                        if current_span and hasattr(current_span, "trace_id"):
                            row["_trace_id"] = current_span.trace_id
                        row.pop("_error", None)
                        row.pop("_error_code", None)
                        if self._hooks.on_sample_completed:
                            self._hooks.on_sample_completed({"row_id": row_id, "row": row})
                        return row
                    except Exception as e:  # noqa: BLE001
                        last_error = e
                        if current_span:
                            current_span.set_error(
                                code=e.__class__.__name__,
                                message=str(e),
                                stack=traceback.format_exc(),
                            )
                        if current_span and hasattr(current_span, "trace_id"):
                            row["_trace_id"] = current_span.trace_id
                        row["_error"] = str(e)
                        row["_error_code"] = e.__class__.__name__

                if attempt < attempts and _is_retryable(last_error):
                    retry_attempts_total += 1
                    time.sleep(_backoff_delay(attempt))
                    continue
                break

            if self._hooks.on_sample_failed:
                self._hooks.on_sample_failed({"row_id": row_id, "row": row})

            if last_error is not None and execution.failure.on_row_error == "stop":
                raise last_error
            return row

        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=execution.workers) as executor:
                future_to_idx: dict[concurrent.futures.Future, int] = {}
                emit_idx = 0
                buffered: dict[int, dict[str, Any]] = {}

                for idx, row in enumerate(request.rows):
                    while len(future_to_idx) >= execution.max_in_flight:
                        done, _ = concurrent.futures.wait(
                            list(future_to_idx.keys()),
                            return_when=concurrent.futures.FIRST_COMPLETED,
                        )
                        for future in done:
                            done_idx = future_to_idx.pop(future)
                            buffered[done_idx] = future.result(timeout=execution.timeout_s)
                        while emit_idx in buffered:
                            out_row = buffered.pop(emit_idx)
                            result_rows.append(out_row)
                            pending_rows.append(out_row)
                            emit_idx += 1
                        _flush_pending_if_due()

                    future = executor.submit(_execute_single_row, row)
                    future_to_idx[future] = idx

                while future_to_idx:
                    done, _ = concurrent.futures.wait(
                        list(future_to_idx.keys()),
                        return_when=concurrent.futures.FIRST_COMPLETED,
                    )
                    for future in done:
                        done_idx = future_to_idx.pop(future)
                        buffered[done_idx] = future.result(timeout=execution.timeout_s)
                    while emit_idx in buffered:
                        out_row = buffered.pop(emit_idx)
                        result_rows.append(out_row)
                        pending_rows.append(out_row)
                        emit_idx += 1
                    _flush_pending_if_due()

            _flush_pending_if_due(force=True)
            if self._trace_flusher:
                self._trace_flusher()
            if self._hooks.on_run_completed:
                self._hooks.on_run_completed({"rows": len(result_rows)})
            return ExecutionSummary(rows=result_rows, retry_attempts_total=retry_attempts_total)
        except Exception as e:  # noqa: BLE001
            try:
                _flush_pending_if_due(force=True)
            except Exception:
                pass
            if self._trace_flusher:
                self._trace_flusher()
            if self._hooks.on_run_failed:
                self._hooks.on_run_failed({"error": str(e), "rows": len(result_rows)})
            raise

