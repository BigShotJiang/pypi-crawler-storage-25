from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal

RunEventType = Literal[
    "run_started",
    "sample_started",
    "sample_completed",
    "sample_failed",
    "metrics_computed",
    "run_completed",
    "run_failed",
]


@dataclass(slots=True)
class RunArtifactEvent:
    artifact_version: str
    eval_id: str
    seq: int
    event_type: RunEventType
    ts: str
    payload: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def utc_now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat()

