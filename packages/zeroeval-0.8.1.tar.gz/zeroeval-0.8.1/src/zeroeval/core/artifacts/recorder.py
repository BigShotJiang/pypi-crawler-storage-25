from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .schema import RunArtifactEvent, RunEventType, utc_now_iso
from .sinks import ArtifactSink


@dataclass(slots=True)
class RunArtifactRecorder:
    eval_id: str
    artifact_version: str = "run_artifact.v1"
    seq: int = 0
    sinks: list[ArtifactSink] = field(default_factory=list)

    def record(self, event_type: RunEventType, payload: dict[str, Any] | None = None) -> None:
        self.seq += 1
        event = RunArtifactEvent(
            artifact_version=self.artifact_version,
            eval_id=self.eval_id,
            seq=self.seq,
            event_type=event_type,
            ts=utc_now_iso(),
            payload=payload or {},
        )
        for sink in self.sinks:
            sink.write_event(event)

