def experiment(*args, **kwargs):
    raise NotImplementedError(
        "The legacy @experiment decorator was removed. "
        "Use @task + Dataset.eval(...) + Eval.eval/score."
    )