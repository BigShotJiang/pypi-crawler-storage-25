class Experiment:
    """Removed legacy API. Use Dataset.eval(...) and Eval APIs."""

    def __init__(self, *args, **kwargs):
        raise NotImplementedError(
            "Experiment was removed. Use Dataset.eval(...) and Eval.eval/score."
        )


class ExperimentResult:
    """Removed legacy API. Use Eval rows/results via Dataset.eval(...)."""

    def __init__(self, *args, **kwargs):
        raise NotImplementedError(
            "ExperimentResult was removed. Use Eval rows/results instead."
        )
