import logging
import os
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional

import requests

from .init import _validate_init

if TYPE_CHECKING:
    from .dataset_class import Dataset

logger = logging.getLogger("zeroeval")


class DatasetReader(ABC):
    @abstractmethod
    def pull_by_name(
        self, dataset_name: str, version_number: Optional[int] = None
    ) -> "Dataset":
        pass


class DatasetBackendReader(DatasetReader):
    """Reads datasets from ZeroEval using the Hub API (data preview endpoint)."""

    def __init__(self):
        self.base_url = os.environ.get(
            "ZEROEVAL_API_URL", "https://api.zeroeval.com"
        ).rstrip("/")
        self._api_key: Optional[str] = None
        self._headers: Optional[dict[str, str]] = None
        self._org_id: Optional[str] = None

    def _ensure_auth_setup(self):
        if self._api_key is None:
            self._api_key = os.environ.get("ZEROEVAL_API_KEY")
            if not self._api_key:
                raise ValueError("ZEROEVAL_API_KEY environment variable not set")
        if self._headers is None:
            self._headers = {"Authorization": f"Bearer {self._api_key}"}

    def _resolve_org_id(self) -> str:
        if self._org_id:
            return self._org_id
        self._ensure_auth_setup()
        resp = requests.get(
            f"{self.base_url}/organizations/my", headers=self._headers
        )
        resp.raise_for_status()
        orgs = resp.json()
        if not orgs:
            raise ValueError("No organizations found for this API key")
        self._org_id = orgs[0]["id"]
        return self._org_id

    def pull_by_name(
        self,
        dataset_name: str,
        version_number: Optional[int] = None,
        subset: Optional[str] = None,
    ) -> "Dataset":
        if not _validate_init():
            raise ValueError(
                "ZeroEval SDK not initialized. Call ze.init(api_key=...) first."
            )
        self._ensure_auth_setup()
        org_id = self._resolve_org_id()

        from .dataset_class import Dataset

        # 1) Fetch dataset metadata
        info_resp = requests.get(
            f"{self.base_url}/v1/datasets/{org_id}/{dataset_name}",
            headers=self._headers,
        )
        if info_resp.status_code == 404:
            raise ValueError(
                f"Dataset '{dataset_name}' not found in your organization."
            )
        info_resp.raise_for_status()
        info = info_resp.json()

        # 2) Determine ref (default: main, or resolve version_number → version ID)
        ref = "main"
        if version_number is not None:
            versions_resp = requests.get(
                f"{self.base_url}/v1/datasets/{org_id}/{dataset_name}/versions",
                headers=self._headers,
            )
            versions_resp.raise_for_status()
            versions = versions_resp.json()
            match = next(
                (v for v in versions if v["version_number"] == version_number),
                None,
            )
            if not match:
                raise ValueError(
                    f"Version {version_number} not found for dataset '{dataset_name}'"
                )
            ref = match["id"]

        # 3) Resolve subset candidates
        candidate_subsets: list[str] = []
        if subset:
            candidate_subsets.append(subset)
        else:
            candidate_subsets.append("default")
            available_subsets = info.get("subsets") or []
            if isinstance(available_subsets, list):
                for s in available_subsets:
                    if isinstance(s, str) and s and s not in candidate_subsets:
                        candidate_subsets.append(s)

        # 4) Paginate through data preview for the first valid subset
        all_rows: list[dict] = []
        selected_subset: Optional[str] = None
        limit = 10000

        for subset_name in candidate_subsets:
            all_rows = []
            total_rows = None
            offset = 0
            subset_missing = False

            while True:
                data_resp = requests.get(
                    f"{self.base_url}/v1/datasets/{org_id}/{dataset_name}/data/{ref}",
                    params={"subset": subset_name, "limit": limit, "offset": offset},
                    headers=self._headers,
                )
                if data_resp.status_code == 404:
                    subset_missing = True
                    break
                data_resp.raise_for_status()
                data = data_resp.json()

                all_rows.extend(data["rows"])
                if total_rows is None:
                    total_rows = data.get("total_rows", len(data["rows"]))
                if len(all_rows) >= total_rows:
                    break
                offset = len(all_rows)

            if not subset_missing:
                selected_subset = subset_name
                break

        if selected_subset is None:
            attempted = ", ".join(candidate_subsets) if candidate_subsets else "none"
            raise ValueError(
                f"No data found for dataset '{dataset_name}' "
                f"(attempted subsets: {attempted}, "
                f"version: {version_number or 'latest'})"
            )

        # 5) Build Dataset object
        dataset = Dataset(
            info["slug"],
            data=all_rows,
            description=info.get("description"),
        )
        dataset._backend_id = info["id"]
        dataset._subset_name = selected_subset
        dataset._source_row_count = len(all_rows)

        # Set version metadata from the latest version if available
        if version_number is not None and ref != "main":
            dataset._version_id = ref
            dataset._version_number = version_number

        return dataset

