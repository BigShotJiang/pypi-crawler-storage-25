from __future__ import annotations

from typing import Optional, Union

from zeroeval.observability.signals import emit_signal, emit_signals
from zeroeval.observability.span import Span

SignalValue = Union[str, bool, int, float]


def task_emit_signal(
    name: str,
    value: SignalValue,
    *,
    target: Union[Span, str, None] = None,
    signal_type: Optional[str] = None,
    immediate: Optional[bool] = None,
) -> bool:
    """Task-oriented wrapper around `zeroeval.emit_signal()`."""
    return emit_signal(
        name,
        value,
        target=target,
        signal_type=signal_type,
        immediate=immediate,
    )


def task_emit_signals(
    signals: dict[str, SignalValue],
    *,
    target: Union[Span, str, None] = None,
    signal_types: dict[str, str] | None = None,
    immediate: Optional[bool] = None,
) -> bool:
    """Task-oriented wrapper around `zeroeval.emit_signals()`."""
    return emit_signals(
        signals,
        target=target,
        signal_types=signal_types,
        immediate=immediate,
    )
