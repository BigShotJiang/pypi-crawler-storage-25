from __future__ import annotations

from dataclasses import dataclass, field
from os import cpu_count
from typing import Any


def _default_workers() -> int:
    cores = cpu_count() or 4
    return max(1, min(32, cores * 4))


@dataclass(slots=True)
class RetryPolicy:
    """Retry policy for per-row task execution."""

    max_attempts: int = 3
    base_delay_s: float = 1.0
    max_delay_s: float = 30.0
    exponential: bool = True
    jitter: bool = True
    retry_on: tuple[str, ...] = (
        "TimeoutError",
        "ConnectionError",
        "RateLimitError",
    )

    def __post_init__(self):
        self.max_attempts = max(1, int(self.max_attempts))
        self.base_delay_s = max(0.0, float(self.base_delay_s))
        self.max_delay_s = max(self.base_delay_s, float(self.max_delay_s))
        if not isinstance(self.retry_on, tuple) or not all(
            isinstance(name, str) and name for name in self.retry_on
        ):
            raise ValueError(
                "RetryPolicy.retry_on must be a non-empty tuple of exception names."
            )


@dataclass(slots=True)
class FailurePolicy:
    """Failure gates used to compute run health."""

    on_row_error: str = "continue"  # continue | stop
    min_success_rate: float = 0.90
    max_error_rate: float = 0.10

    def __post_init__(self):
        if self.on_row_error not in ("continue", "stop"):
            raise ValueError(
                "FailurePolicy.on_row_error must be either 'continue' or 'stop'."
            )
        self.min_success_rate = min(1.0, max(0.0, float(self.min_success_rate)))
        self.max_error_rate = min(1.0, max(0.0, float(self.max_error_rate)))


@dataclass(slots=True)
class ExecutionConfig:
    """Execution runtime controls with safe defaults."""

    workers: int = field(default_factory=_default_workers)
    max_in_flight: int | None = None
    timeout_s: float = 90.0
    retry: RetryPolicy = field(default_factory=RetryPolicy)
    failure: FailurePolicy = field(default_factory=FailurePolicy)

    def __post_init__(self):
        if self.max_in_flight is None:
            self.max_in_flight = self.workers * 4
        self.workers = max(1, int(self.workers))
        self.max_in_flight = max(1, int(self.max_in_flight))
        self.timeout_s = max(0.1, float(self.timeout_s))


@dataclass(slots=True)
class CheckpointConfig:
    """Checkpoint cadence for incremental backend persistence."""

    enabled: bool = True
    flush_every_rows: int = 50
    flush_every_seconds: float = 10.0
    persist_errors: bool = True

    def __post_init__(self):
        self.flush_every_rows = max(1, int(self.flush_every_rows))
        self.flush_every_seconds = max(0.5, float(self.flush_every_seconds))


@dataclass(slots=True)
class ResumeConfig:
    """Resume behavior for partial runs."""

    mode: str = "auto"  # auto | force | fresh
    eval_id: str | None = None  # Optional public eval identifier.
    skip_completed: bool = True
    retry_errors: bool = False

    def __post_init__(self):
        if self.mode not in ("auto", "force", "fresh"):
            raise ValueError(
                "ResumeConfig.mode must be one of: 'auto', 'force', 'fresh'."
            )


@dataclass(slots=True)
class EvalHealth:
    """Computed run health summary."""

    success_count: int
    error_count: int
    skipped_count: int
    total_count: int
    success_rate: float
    error_rate: float
    retry_success_rate: float
    status: str
    extra: dict[str, Any] = field(default_factory=dict)

