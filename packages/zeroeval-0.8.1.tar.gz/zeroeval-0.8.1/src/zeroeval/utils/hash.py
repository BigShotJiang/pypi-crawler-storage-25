from __future__ import annotations

import hashlib
import json
from typing import Any, Optional


def _normalize_newlines(text: str) -> str:
    # Convert CRLF and CR to LF
    if "\r" not in text:
        return text
    return text.replace("\r\n", "\n").replace("\r", "\n")


def _strip_trailing_whitespace(text: str) -> str:
    # Remove trailing whitespace on each line
    return "\n".join(line.rstrip() for line in text.split("\n"))


def normalize_prompt_text(text: str) -> str:
    """
    Normalize prompt content prior to hashing.

    Rules:
    - Convert CRLF/CR to LF
    - Strip trailing whitespace on each line
    - Strip leading/trailing whitespace overall
    - Do not modify {{variable}} tokens
    """
    if not isinstance(text, str):
        text = str(text)
    normalized = _normalize_newlines(text)
    normalized = _strip_trailing_whitespace(normalized)
    normalized = normalized.strip()
    return normalized


def canonical_prompt_hash(
    *,
    content: str,
    model_id: Optional[str] = None,
    evaluation_type: Optional[str] = None,
    score_min: Optional[float] = None,
    score_max: Optional[float] = None,
    pass_threshold: Optional[float] = None,
    temperature: Optional[float] = None,
    structured_criteria: Optional[list[dict[str, Any]]] = None,
) -> str:
    """
    Canonical prompt hash format shared with backend:
    content + model_id + evaluation settings + structured criteria.
    """
    normalized_content = normalize_prompt_text(content)
    payload = {
        "content": normalized_content,
        "model_id": model_id,
        "evaluation_type": evaluation_type,
        "score_min": score_min,
        "score_max": score_max,
        "pass_threshold": pass_threshold,
        "temperature": temperature,
        "structured_criteria": structured_criteria,
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()


