from __future__ import annotations

import argparse
import warnings

from .commands import (
    register_auth_commands,
    register_datasets_commands,
    register_evals_commands,
    register_judges_commands,
    register_optimize_commands,
    register_prompts_commands,
    register_sessions_commands,
    register_spans_commands,
    register_spec_commands,
    register_traces_commands,
)
from .context import CLIContext
from .errors import EXIT_SUCCESS, CLIError
from .output import emit_error, emit_success
from .runner import run_script
from .setup import setup


def _cmd_setup(args: argparse.Namespace, ctx: CLIContext):
    setup()
    return {"ok": True}


def _cmd_run(args: argparse.Namespace, ctx: CLIContext):
    warnings.warn(
        "`zeroeval run` is deprecated and will be removed in a future release. "
        "Execute your script directly with `python your_script.py`.",
        DeprecationWarning,
        stacklevel=2,
    )
    run_script(args.script)
    return {"ok": True, "deprecated": True}


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="zeroeval CLI — monitoring, judges, prompts, optimization",
    )
    parser.add_argument(
        "--output",
        choices=["text", "json"],
        default="text",
        help="Output format.",
    )
    parser.add_argument(
        "--api-base-url",
        default=None,
        help="Override ZeroEval API base URL.",
    )
    parser.add_argument(
        "--project-id",
        default=None,
        help="Project context override.",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress non-essential logs.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=60.0,
        help="Request timeout in seconds.",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    p_setup = subparsers.add_parser("setup", help="Interactive API key setup")
    p_setup.set_defaults(handler=_cmd_setup)

    p_run = subparsers.add_parser(
        "run",
        help="Deprecated: run a Python script with ZeroEval",
    )
    p_run.add_argument("script", help="Path to the Python script to run")
    p_run.set_defaults(handler=_cmd_run)

    register_auth_commands(subparsers)
    register_datasets_commands(subparsers)
    register_evals_commands(subparsers)
    register_judges_commands(subparsers)
    register_optimize_commands(subparsers)
    register_prompts_commands(subparsers)
    register_sessions_commands(subparsers)
    register_spans_commands(subparsers)
    register_spec_commands(subparsers)
    register_traces_commands(subparsers)
    return parser


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()
    ctx = CLIContext(
        output=args.output,
        api_base_url=args.api_base_url,
        project_id=args.project_id,
        quiet=args.quiet,
        timeout=args.timeout,
    )

    try:
        payload = args.handler(args, ctx)
        if payload is not None:
            emit_success(ctx, payload)
        return EXIT_SUCCESS
    except CLIError as err:
        emit_error(err, output=args.output)
        return err.exit_code