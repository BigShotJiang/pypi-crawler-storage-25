from __future__ import annotations

import os
from dataclasses import dataclass

from .config import load_config


@dataclass
class CLIContext:
    output: str
    api_base_url: str | None
    project_id: str | None
    quiet: bool
    timeout: float

    def __post_init__(self) -> None:
        if not self.project_id:
            self.project_id = os.getenv("ZEROEVAL_PROJECT_ID")
        if not self.project_id:
            self.project_id = load_config().get("project_id")

