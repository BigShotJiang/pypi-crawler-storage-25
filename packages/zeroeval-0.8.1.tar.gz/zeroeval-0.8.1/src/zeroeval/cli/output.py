from __future__ import annotations

import json
import sys
from typing import Any

from .context import CLIContext
from .errors import EXIT_USER_ERROR, CLIError


def emit_success(ctx: CLIContext, payload: Any) -> None:
    if ctx.output == "json":
        print(json.dumps(payload, indent=2, default=str))
        return

    if isinstance(payload, (dict, list)):
        print(json.dumps(payload, indent=2, default=str))
    else:
        print(str(payload))


def emit_error(err: CLIError, output: str = "text") -> None:
    if output == "json":
        print(
            json.dumps(
                {
                    "error": {
                        "message": err.message,
                        "details": err.details,
                        "exit_code": err.exit_code,
                    }
                },
                indent=2,
                default=str,
            ),
            file=sys.stderr,
        )
        return

    print(f"Error: {err.message}", file=sys.stderr)
    if err.details is not None:
        print(json.dumps(err.details, indent=2, default=str), file=sys.stderr)


def confirm_or_abort(ctx: CLIContext, message: str, *, yes: bool) -> None:
    if yes:
        return
    try:
        answer = input(f"{message} [y/N] ")
    except (EOFError, KeyboardInterrupt):
        raise CLIError("Aborted.", exit_code=EXIT_USER_ERROR)
    if answer.strip().lower() not in ("y", "yes"):
        raise CLIError("Aborted.", exit_code=EXIT_USER_ERROR)
