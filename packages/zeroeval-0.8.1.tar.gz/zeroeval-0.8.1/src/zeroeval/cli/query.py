from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from .errors import EXIT_USER_ERROR, CLIError


@dataclass
class FilterExpr:
    field: str
    op: str
    value: Any


def parse_where_clauses(raw_clauses: list[str] | None) -> list[FilterExpr]:
    if not raw_clauses:
        return []
    parsed: list[FilterExpr] = []
    for raw in raw_clauses:
        raw = raw.strip()
        if " in " in raw:
            field, value = raw.split(" in ", 1)
            parsed.append(FilterExpr(field.strip(), "in", _parse_literal(value.strip())))
            continue
        if "~" in raw:
            field, value = raw.split("~", 1)
            parsed.append(FilterExpr(field.strip(), "~", _parse_literal(value.strip())))
            continue
        if "=" in raw:
            field, value = raw.split("=", 1)
            parsed.append(FilterExpr(field.strip(), "=", _parse_literal(value.strip())))
            continue
        raise CLIError(
            f"Invalid --where clause: '{raw}'. Supported operators: '=', '~', 'in'.",
            exit_code=EXIT_USER_ERROR,
        )
    return parsed


def apply_query(
    rows: Any,
    *,
    where: list[str] | None = None,
    select: str | None = None,
    order: str | None = None,
) -> Any:
    if not isinstance(rows, list):
        return rows

    filtered = _apply_where(rows, parse_where_clauses(where))
    ordered = _apply_order(filtered, order)
    projected = _apply_select(ordered, select)
    return projected


def _apply_where(rows: list[dict[str, Any]], expressions: list[FilterExpr]) -> list[dict[str, Any]]:
    if not expressions:
        return rows

    def match_expr(row: dict[str, Any], expr: FilterExpr) -> bool:
        left = _get_path_value(row, expr.field)
        right = expr.value

        if expr.op == "=":
            return _coerce_compare(left) == _coerce_compare(right)
        if expr.op == "~":
            return str(right).lower() in str(left).lower()
        if expr.op == "in":
            if not isinstance(right, list):
                raise CLIError(
                    f"'in' operator expects a JSON list in --where '{expr.field} in [...]'.",
                    exit_code=EXIT_USER_ERROR,
                )
            norm_right = {_coerce_compare(v) for v in right}
            return _coerce_compare(left) in norm_right
        return False

    output: list[dict[str, Any]] = []
    for row in rows:
        if all(match_expr(row, expr) for expr in expressions):
            output.append(row)
    return output


def _apply_select(rows: list[dict[str, Any]], select: str | None) -> list[dict[str, Any]]:
    if not select:
        return rows
    fields = [f.strip() for f in select.split(",") if f.strip()]
    if not fields:
        return rows
    projected: list[dict[str, Any]] = []
    for row in rows:
        out: dict[str, Any] = {}
        for field in fields:
            out[field] = _get_path_value(row, field)
        projected.append(out)
    return projected


def _apply_order(rows: list[dict[str, Any]], order: str | None) -> list[dict[str, Any]]:
    if not order:
        return rows
    parts = order.split(":", 1)
    field = parts[0].strip()
    direction = parts[1].strip().lower() if len(parts) > 1 else "asc"
    reverse = direction == "desc"
    return sorted(rows, key=lambda r: _sort_key(_get_path_value(r, field)), reverse=reverse)


def _sort_key(v: Any) -> Any:
    if v is None:
        return (1, "")
    return (0, str(v))


def _coerce_compare(value: Any) -> Any:
    if isinstance(value, str):
        text = value.strip()
        if text.lower() in {"true", "false"}:
            return text.lower() == "true"
        if text.isdigit():
            return int(text)
        try:
            return float(text)
        except ValueError:
            return text
    return value


def _parse_literal(raw: str) -> Any:
    raw = raw.strip()
    if not raw:
        return ""
    # quoted strings
    if (raw.startswith('"') and raw.endswith('"')) or (raw.startswith("'") and raw.endswith("'")):
        return raw[1:-1]
    # json payloads, numbers, booleans, arrays
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return raw


def _get_path_value(item: Any, path: str) -> Any:
    current = item
    for part in path.split("."):
        if isinstance(current, str):
            try:
                current = json.loads(current)
            except Exception:
                return None
        if isinstance(current, dict):
            current = current.get(part)
        else:
            return None
    return current

