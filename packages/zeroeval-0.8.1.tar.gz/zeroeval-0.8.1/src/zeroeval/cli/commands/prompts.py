from __future__ import annotations

import argparse
import json
from typing import Any

from ..context import CLIContext
from ..http import ZeroEvalAPI, require_project_id
from ..query import apply_query


def _api(args: argparse.Namespace, ctx: CLIContext) -> ZeroEvalAPI:
    return ZeroEvalAPI(base_url=ctx.api_base_url, timeout=ctx.timeout)


def cmd_prompts_list(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    rows = _api(args, ctx).list_tuning_tasks(project_id)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_prompts_get(args: argparse.Namespace, ctx: CLIContext):
    row = _api(args, ctx).get_prompt_by_slug(
        args.prompt_slug,
        version=args.version,
        tag=args.tag,
    )
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def cmd_prompts_versions(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    rows = _api(args, ctx).list_prompt_versions(project_id, args.prompt_slug)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_prompts_tags(args: argparse.Namespace, ctx: CLIContext):
    project_id = require_project_id(ctx.project_id)
    rows = _api(args, ctx).list_prompt_tags(project_id, args.prompt_slug)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_prompts_feedback_create(args: argparse.Namespace, ctx: CLIContext):
    thumbs_up = args.thumbs_up
    body: dict[str, Any] = {"thumbs_up": thumbs_up}
    if args.reason is not None:
        body["reason"] = args.reason
    if args.expected_output is not None:
        body["expected_output"] = args.expected_output
    if args.judge_id is not None:
        body["judge_id"] = args.judge_id
    if args.expected_score is not None:
        body["expected_score"] = args.expected_score
    if args.score_direction is not None:
        body["score_direction"] = args.score_direction
    if args.criteria_feedback is not None:
        body["criteria_feedback"] = json.loads(args.criteria_feedback)
    if args.metadata is not None:
        body["metadata"] = json.loads(args.metadata)
    return _api(args, ctx).create_prompt_completion_feedback(
        args.prompt_slug,
        args.completion_id,
        body,
    )


def register_prompts_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]):
    prompts = subparsers.add_parser("prompts", help="Prompt and tuning task commands")
    prompts_sub = prompts.add_subparsers(dest="prompts_command", required=True)

    p_list = prompts_sub.add_parser("list", help="List prompts (task-centric view)")
    p_list.add_argument("--where", action="append", default=[])
    p_list.add_argument("--select", default=None)
    p_list.add_argument("--order", default=None)
    p_list.set_defaults(handler=cmd_prompts_list)

    p_get = prompts_sub.add_parser("get", help="Get prompt by slug")
    p_get.add_argument("prompt_slug")
    p_get.add_argument("--version", type=int, default=None)
    p_get.add_argument("--tag", default=None)
    p_get.add_argument("--where", action="append", default=[])
    p_get.add_argument("--select", default=None)
    p_get.add_argument("--order", default=None)
    p_get.set_defaults(handler=cmd_prompts_get)

    p_versions = prompts_sub.add_parser("versions", help="List prompt versions")
    p_versions.add_argument("prompt_slug")
    p_versions.add_argument("--where", action="append", default=[])
    p_versions.add_argument("--select", default=None)
    p_versions.add_argument("--order", default=None)
    p_versions.set_defaults(handler=cmd_prompts_versions)

    p_tags = prompts_sub.add_parser("tags", help="List prompt tags")
    p_tags.add_argument("prompt_slug")
    p_tags.add_argument("--where", action="append", default=[])
    p_tags.add_argument("--select", default=None)
    p_tags.add_argument("--order", default=None)
    p_tags.set_defaults(handler=cmd_prompts_tags)

    p_feedback = prompts_sub.add_parser("feedback", help="Prompt feedback commands")
    feedback_sub = p_feedback.add_subparsers(dest="prompts_feedback_command", required=True)

    p_feedback_create = feedback_sub.add_parser("create", help="Create prompt completion feedback")
    p_feedback_create.add_argument("--prompt-slug", required=True)
    p_feedback_create.add_argument("--completion-id", required=True)
    thumbs = p_feedback_create.add_mutually_exclusive_group(required=True)
    thumbs.add_argument("--thumbs-up", action="store_true", default=False)
    thumbs.add_argument("--thumbs-down", action="store_true", default=False)
    p_feedback_create.add_argument("--reason", default=None)
    p_feedback_create.add_argument("--expected-output", default=None)
    p_feedback_create.add_argument("--judge-id", default=None)
    p_feedback_create.add_argument("--expected-score", type=float, default=None)
    p_feedback_create.add_argument(
        "--score-direction",
        choices=["too_high", "too_low"],
        default=None,
    )
    p_feedback_create.add_argument("--criteria-feedback", default=None)
    p_feedback_create.add_argument("--metadata", default=None)
    p_feedback_create.set_defaults(handler=cmd_prompts_feedback_create)
