from __future__ import annotations

import argparse

from ..context import CLIContext
from ..http import ZeroEvalAPI
from ..query import apply_query


def _api(args: argparse.Namespace, ctx: CLIContext) -> ZeroEvalAPI:
    return ZeroEvalAPI(base_url=ctx.api_base_url, timeout=ctx.timeout)


def cmd_datasets_list(args: argparse.Namespace, ctx: CLIContext):
    rows = _api(args, ctx).list_datasets(limit=args.limit, offset=args.offset)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_datasets_get(args: argparse.Namespace, ctx: CLIContext):
    row = _api(args, ctx).get_dataset(dataset=args.dataset)
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def cmd_datasets_versions(args: argparse.Namespace, ctx: CLIContext):
    rows = _api(args, ctx).list_dataset_versions(dataset=args.dataset)
    return apply_query(rows, where=args.where, select=args.select, order=args.order)


def cmd_datasets_ingest(args: argparse.Namespace, ctx: CLIContext):
    row = _api(args, ctx).get_dataset_latest_ingest_job(
        dataset=args.dataset,
        ref_name=args.ref_name,
    )
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def cmd_datasets_upload_status(args: argparse.Namespace, ctx: CLIContext):
    row = _api(args, ctx).get_dataset_latest_upload_session(dataset=args.dataset)
    return apply_query([row], where=args.where, select=args.select, order=args.order)


def cmd_datasets_rows(args: argparse.Namespace, ctx: CLIContext):
    payload = _api(args, ctx).get_dataset_rows(
        dataset=args.dataset,
        version=args.version,
        subset=args.subset,
        limit=args.limit,
        offset=args.offset,
    )
    if isinstance(payload, dict) and isinstance(payload.get("rows"), list):
        payload = dict(payload)
        payload["rows"] = apply_query(
            payload["rows"],
            where=args.where,
            select=args.select,
            order=args.order,
        )
    else:
        payload = apply_query(payload, where=args.where, select=args.select, order=args.order)
    return payload


def register_datasets_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]):
    datasets = subparsers.add_parser("datasets", help="Dataset inspection commands")
    ds_sub = datasets.add_subparsers(dest="datasets_command", required=True)

    p_list = ds_sub.add_parser("list", help="List datasets")
    p_list.add_argument("--limit", type=int, default=100)
    p_list.add_argument("--offset", type=int, default=0)
    p_list.add_argument("--where", action="append", default=[])
    p_list.add_argument("--select", default=None)
    p_list.add_argument("--order", default=None)
    p_list.set_defaults(handler=cmd_datasets_list)

    p_get = ds_sub.add_parser("get", help="Get dataset metadata")
    p_get.add_argument("dataset", help="Dataset name")
    p_get.add_argument("--where", action="append", default=[])
    p_get.add_argument("--select", default=None)
    p_get.add_argument("--order", default=None)
    p_get.set_defaults(handler=cmd_datasets_get)

    p_versions = ds_sub.add_parser("versions", help="List dataset versions")
    p_versions.add_argument("dataset", help="Dataset name")
    p_versions.add_argument("--where", action="append", default=[])
    p_versions.add_argument("--select", default=None)
    p_versions.add_argument("--order", default=None)
    p_versions.set_defaults(handler=cmd_datasets_versions)

    p_ingest = ds_sub.add_parser("ingest", help="Get latest dataset ingest status")
    p_ingest.add_argument("dataset", help="Dataset name")
    p_ingest.add_argument("--ref-name", default="refs/heads/main")
    p_ingest.add_argument("--where", action="append", default=[])
    p_ingest.add_argument("--select", default=None)
    p_ingest.add_argument("--order", default=None)
    p_ingest.set_defaults(handler=cmd_datasets_ingest)

    p_upload_status = ds_sub.add_parser("upload-status", help="Get latest dataset upload session status")
    p_upload_status.add_argument("dataset", help="Dataset name")
    p_upload_status.add_argument("--where", action="append", default=[])
    p_upload_status.add_argument("--select", default=None)
    p_upload_status.add_argument("--order", default=None)
    p_upload_status.set_defaults(handler=cmd_datasets_upload_status)

    p_rows = ds_sub.add_parser("rows", help="Fetch dataset rows")
    p_rows.add_argument("dataset", help="Dataset name")
    p_rows.add_argument("--version", type=int, default=None, help="Dataset version number")
    p_rows.add_argument("--subset", default=None, help="Optional subset name")
    p_rows.add_argument("--limit", type=int, default=100)
    p_rows.add_argument("--offset", type=int, default=0)
    p_rows.add_argument("--where", action="append", default=[])
    p_rows.add_argument("--select", default=None)
    p_rows.add_argument("--order", default=None)
    p_rows.set_defaults(handler=cmd_datasets_rows)

