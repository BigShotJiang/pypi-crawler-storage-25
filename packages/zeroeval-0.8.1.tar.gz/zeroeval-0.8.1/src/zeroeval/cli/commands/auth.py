from __future__ import annotations

import argparse
import os

from ..config import get_config_path, load_config, save_config
from ..context import CLIContext
from ..errors import EXIT_USER_ERROR, CLIError
from ..setup import _resolve_project_from_key


def cmd_auth_set(args: argparse.Namespace, ctx: CLIContext):
    config = load_config()

    api_key = args.api_key
    if args.api_key_env:
        env_value = os.getenv(args.api_key_env)
        if not env_value:
            raise CLIError(
                f"Environment variable '{args.api_key_env}' is not set.",
                exit_code=EXIT_USER_ERROR,
            )
        api_key = env_value

    if api_key:
        config["api_key"] = api_key
    if args.api_base_url:
        config["api_base_url"] = args.api_base_url
    if not api_key and not args.api_base_url:
        raise CLIError(
            "Provide at least one of --api-key, --api-key-env, or --api-base-url.",
            exit_code=EXIT_USER_ERROR,
        )

    project_info = None
    resolved = False
    resolve_key = api_key or config.get("api_key")
    if resolve_key and (api_key or args.api_base_url):
        try:
            project_info = _resolve_project_from_key(
                resolve_key, config.get("api_base_url")
            )
            resolved = True
        except Exception:
            pass
        if project_info:
            config["project_id"] = project_info["project_id"]
            config["project_name"] = project_info.get("project_name", "")
        elif resolved:
            config.pop("project_id", None)
            config.pop("project_name", None)

    path = save_config(config)
    result: dict = {
        "ok": True,
        "config_path": str(path),
        "configured": {
            "api_key": bool(config.get("api_key")),
            "api_base_url": bool(config.get("api_base_url")),
            "project_id": bool(config.get("project_id")),
        },
    }
    if project_info:
        result["project_id"] = project_info["project_id"]
        result["project_name"] = project_info.get("project_name", "")
    return result


def cmd_auth_show(args: argparse.Namespace, ctx: CLIContext):
    config = load_config()
    api_key = config.get("api_key")
    if api_key and args.redact:
        if len(api_key) <= 8:
            api_key = "*" * len(api_key)
        else:
            api_key = f"{api_key[:6]}...{api_key[-4:]}"
    return {
        "config_path": str(get_config_path()),
        "configured": {
            "api_key": bool(config.get("api_key")),
            "api_base_url": bool(config.get("api_base_url")),
            "project_id": bool(config.get("project_id")),
        },
        "values": {
            "api_key": api_key,
            "api_base_url": config.get("api_base_url"),
            "project_id": config.get("project_id"),
            "project_name": config.get("project_name"),
        },
    }


def cmd_auth_clear(args: argparse.Namespace, ctx: CLIContext):
    config = load_config()
    if args.api_key_only:
        config.pop("api_key", None)
        config.pop("project_id", None)
        config.pop("project_name", None)
    else:
        config = {}
    path = save_config(config)
    return {
        "ok": True,
        "config_path": str(path),
        "cleared": "api_key" if args.api_key_only else "all",
    }


def register_auth_commands(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
):
    auth = subparsers.add_parser(
        "auth", help="Non-interactive global auth configuration"
    )
    auth_sub = auth.add_subparsers(dest="auth_command", required=True)

    p_set = auth_sub.add_parser("set", help="Set global CLI auth config")
    p_set.add_argument("--api-key", default=None, help="ZeroEval API key value")
    p_set.add_argument(
        "--api-key-env",
        default=None,
        help="Read API key from this environment variable name",
    )
    p_set.add_argument(
        "--api-base-url", default=None, help="Optional default API base URL"
    )
    p_set.set_defaults(handler=cmd_auth_set)

    p_show = auth_sub.add_parser("show", help="Show global CLI auth config")
    p_show.add_argument("--redact", action="store_true", help="Redact API key output")
    p_show.set_defaults(handler=cmd_auth_show)

    p_clear = auth_sub.add_parser("clear", help="Clear global CLI auth config")
    p_clear.add_argument(
        "--api-key-only", action="store_true", help="Clear only API key"
    )
    p_clear.set_defaults(handler=cmd_auth_clear)
