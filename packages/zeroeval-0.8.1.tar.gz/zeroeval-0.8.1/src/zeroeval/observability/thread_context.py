"""
Automatic ContextVar propagation across threads.

Python's ContextVar does not propagate to new threading.Thread or
ThreadPoolExecutor workers. This module patches Thread.start() and
ThreadPoolExecutor.submit() to snapshot the current context at spawn
time and restore it inside the worker, so ze.span nesting works
transparently across thread boundaries.

This is the same approach used by OpenTelemetry's Python SDK.
"""

import contextvars
import logging
import threading
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)

_original_thread_start = threading.Thread.start
_original_executor_submit = ThreadPoolExecutor.submit
_installed = False


def _patched_thread_start(self):
    original_run = self.run
    ctx = contextvars.copy_context()

    def wrapped_run(*_args, **_kwargs):
        ctx.run(original_run)

    self.run = wrapped_run
    _original_thread_start(self)


def _patched_executor_submit(self, fn, /, *args, **kwargs):
    ctx = contextvars.copy_context()
    return _original_executor_submit(self, ctx.run, fn, *args, **kwargs)


def install_thread_context_hooks():
    """Patch threading primitives to propagate ContextVar across threads."""
    global _installed
    if _installed:
        return
    threading.Thread.start = _patched_thread_start
    ThreadPoolExecutor.submit = _patched_executor_submit
    _installed = True
    logger.debug("Thread context propagation hooks installed")


def uninstall_thread_context_hooks():
    """Restore original threading primitives."""
    global _installed
    if not _installed:
        return
    threading.Thread.start = _original_thread_start
    ThreadPoolExecutor.submit = _original_executor_submit
    _installed = False
    logger.debug("Thread context propagation hooks uninstalled")
