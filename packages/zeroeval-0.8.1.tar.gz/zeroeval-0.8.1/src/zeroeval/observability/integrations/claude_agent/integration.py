"""
Claude Agent SDK integration for ZeroEval tracing.

Patches the public ``claude_agent_sdk.query`` function and
``claude_agent_sdk.ClaudeSDKClient`` class to emit ZeroEval spans
for each top-level Claude agent turn.

**Hybrid tracing model:**

- Each ``query()`` call or ``ClaudeSDKClient.query()`` turn becomes its own
  ZeroEval **trace** (``is_new_trace=True``).
- The Claude conversation ID (emitted in SDK messages) is stored as the
  span attribute ``claude_session_id`` and used as the ZeroEval
  ``session_id`` so that all turns in the same Claude conversation are
  grouped under one session.

Only public API surfaces are patched — no private ``_internal`` modules.
"""

import logging
import time
from collections import defaultdict
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Callable, Optional

from ..base import Integration

logger = logging.getLogger(__name__)

_ZE_CLIENT_STATE = "__ze_claude_state__"


@dataclass
class TurnState:
    """Accumulates telemetry for a single Claude agent turn."""

    prompt_summary: str = ""
    claude_session_id: Optional[str] = None
    assistant_text: str = ""
    tool_uses: list[dict[str, Any]] = field(default_factory=list)
    tool_results: list[dict[str, Any]] = field(default_factory=list)
    stream_event_count: int = 0
    first_stream_event_time: Optional[float] = None
    rate_limit_events: list[dict[str, Any]] = field(default_factory=list)
    permission_decisions: list[dict[str, Any]] = field(default_factory=list)
    hook_events: list[dict[str, Any]] = field(default_factory=list)
    result_meta: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Message enrichment helpers
# ---------------------------------------------------------------------------


def _summarize_prompt(prompt: Any) -> str:
    if isinstance(prompt, str):
        return prompt[:500]
    return "<async-iterable>"


def _extract_message_data(message: Any, state: TurnState) -> None:
    """Extract telemetry from a typed Claude Agent SDK message."""
    try:
        from claude_agent_sdk.types import (
            AssistantMessage,
            RateLimitEvent,
            ResultMessage,
            StreamEvent,
            ToolResultBlock,
            ToolUseBlock,
            UserMessage,
        )
    except ImportError:
        return

    if isinstance(message, UserMessage):
        if not state.prompt_summary:
            for block in getattr(message, "content", []):
                if hasattr(block, "text"):
                    state.prompt_summary = block.text[:500]
                    break
        if hasattr(message, "session_id") and message.session_id:
            state.claude_session_id = message.session_id

    elif isinstance(message, AssistantMessage):
        if hasattr(message, "session_id") and message.session_id:
            state.claude_session_id = message.session_id
        for block in getattr(message, "content", []):
            if isinstance(block, ToolUseBlock):
                state.tool_uses.append(
                    {
                        "name": getattr(block, "name", "unknown"),
                        "id": getattr(block, "id", None),
                    }
                )
            elif isinstance(block, ToolResultBlock):
                state.tool_results.append(
                    {
                        "tool_use_id": getattr(block, "tool_use_id", None),
                        "is_error": getattr(block, "is_error", False),
                    }
                )
            elif hasattr(block, "text"):
                state.assistant_text += block.text

    elif isinstance(message, StreamEvent):
        state.stream_event_count += 1
        if state.first_stream_event_time is None:
            state.first_stream_event_time = time.time()
        if hasattr(message, "session_id") and message.session_id:
            state.claude_session_id = message.session_id

    elif isinstance(message, RateLimitEvent):
        info = getattr(message, "rate_limit_info", None)
        if info:
            state.rate_limit_events.append(
                {
                    "status": getattr(info, "status", None),
                    "type": getattr(info, "rate_limit_type", None),
                    "utilization": getattr(info, "utilization", None),
                }
            )
        if hasattr(message, "session_id") and message.session_id:
            state.claude_session_id = message.session_id

    elif isinstance(message, ResultMessage):
        if hasattr(message, "session_id") and message.session_id:
            state.claude_session_id = message.session_id
        state.result_meta = {
            "duration_ms": getattr(message, "duration_ms", None),
            "total_cost_usd": getattr(message, "total_cost_usd", None),
            "num_turns": getattr(message, "num_turns", None),
            "stop_reason": getattr(message, "stop_reason", None),
            "is_error": getattr(message, "is_error", False),
            "usage": getattr(message, "usage", None),
            "model_usage": getattr(message, "model_usage", None),
        }
        errors = getattr(message, "errors", None)
        if errors:
            state.result_meta["errors"] = errors
        denials = getattr(message, "permission_denials", None)
        if denials:
            state.result_meta["permission_denials"] = denials


def _apply_state_to_span(span: Any, state: TurnState) -> None:
    """Transfer accumulated TurnState onto a ZeroEval span."""
    input_summary = state.prompt_summary or "<unknown>"
    output_summary = state.assistant_text[:2000] if state.assistant_text else ""
    span.set_io(input_data=input_summary, output_data=output_summary)

    if state.claude_session_id:
        span.attributes["claude_session_id"] = state.claude_session_id
        span.session_id = state.claude_session_id
    if state.tool_uses:
        span.attributes["tool_uses"] = state.tool_uses
    if state.tool_results:
        span.attributes["tool_results"] = state.tool_results
    if state.stream_event_count:
        span.attributes["stream_event_count"] = state.stream_event_count
    if state.first_stream_event_time is not None:
        span.attributes["first_stream_event_time"] = state.first_stream_event_time
    if state.rate_limit_events:
        span.attributes["rate_limit_events"] = state.rate_limit_events
    if state.permission_decisions:
        span.attributes["permission_decisions"] = state.permission_decisions
    if state.hook_events:
        span.attributes["hook_events"] = state.hook_events

    for key, value in state.result_meta.items():
        if value is not None:
            span.attributes[key] = value


# ---------------------------------------------------------------------------
# Options wrapping helpers
# ---------------------------------------------------------------------------


def _wrap_can_use_tool(original_callback: Any, state: TurnState) -> Callable:
    """Wrap a user's can_use_tool callback to capture permission decisions."""

    @wraps(original_callback)
    async def wrapper(tool_name, input_data, context):
        result = await original_callback(tool_name, input_data, context)
        try:
            decision = {
                "tool_name": tool_name,
                "tool_use_id": getattr(context, "tool_use_id", None),
                "agent_id": getattr(context, "agent_id", None),
                "behavior": getattr(result, "behavior", "unknown"),
            }
            state.permission_decisions.append(decision)
        except Exception:
            pass
        return result

    return wrapper


def _wrap_hook_callback(original_callback: Any, state: TurnState) -> Callable:
    """Wrap a single hook callback to capture hook event metadata."""

    @wraps(original_callback)
    async def wrapper(input_data, tool_use_id, context):
        result = await original_callback(input_data, tool_use_id, context)
        try:
            event_name = None
            if isinstance(input_data, dict):
                event_name = input_data.get("hook_event_name")
            state.hook_events.append(
                {
                    "event_name": event_name,
                    "tool_name": input_data.get("tool_name")
                    if isinstance(input_data, dict)
                    else None,
                }
            )
        except Exception:
            pass
        return result

    return wrapper


def _wrap_options(options: Any, state: TurnState) -> Any:
    """Return a copy of ClaudeAgentOptions with wrapped callbacks for enrichment."""
    try:
        from dataclasses import replace as dc_replace
        from claude_agent_sdk.types import HookMatcher

        needs_replace = False
        kwargs: dict[str, Any] = {}

        if options.can_use_tool:
            kwargs["can_use_tool"] = _wrap_can_use_tool(options.can_use_tool, state)
            needs_replace = True

        if options.hooks:
            wrapped_hooks: dict[str, list] = {}
            for event, matchers in options.hooks.items():
                wrapped_matchers = []
                for matcher in matchers:
                    wrapped_cbs = [
                        _wrap_hook_callback(cb, state) for cb in matcher.hooks
                    ]
                    wrapped_matchers.append(
                        HookMatcher(
                            matcher=matcher.matcher,
                            hooks=wrapped_cbs,
                            timeout=matcher.timeout,
                        )
                    )
                wrapped_hooks[event] = wrapped_matchers
            kwargs["hooks"] = wrapped_hooks
            needs_replace = True

        if needs_replace:
            return dc_replace(options, **kwargs)
        return options
    except Exception:
        return options


# ---------------------------------------------------------------------------
# Per-client state for ClaudeSDKClient instrumentation
# ---------------------------------------------------------------------------


@dataclass
class ClientSpanState:
    """Tracks pending turn spans for one ClaudeSDKClient instance."""

    pending_turns: dict[str, list[tuple[Any, TurnState]]] = field(
        default_factory=lambda: defaultdict(list)
    )
    original_options: Any = None

    def push_turn(self, session_id: str, span: Any, state: TurnState) -> None:
        self.pending_turns[session_id].append((span, state))

    def peek_turn(self, session_id: Optional[str]) -> Optional[tuple[Any, TurnState]]:
        if session_id and self.pending_turns.get(session_id):
            return self.pending_turns[session_id][-1]
        for turns in self.pending_turns.values():
            if turns:
                return turns[-1]
        return None

    def pop_turn(self, session_id: Optional[str]) -> Optional[tuple[Any, TurnState]]:
        if session_id and self.pending_turns.get(session_id):
            pair = self.pending_turns[session_id].pop()
            if not self.pending_turns[session_id]:
                del self.pending_turns[session_id]
            return pair
        for sid, turns in list(self.pending_turns.items()):
            if turns:
                pair = turns.pop()
                if not turns:
                    del self.pending_turns[sid]
                return pair
        return None

    def close_all(self, tracer: Any) -> None:
        for sid, turns in list(self.pending_turns.items()):
            for span, state in turns:
                try:
                    _apply_state_to_span(span, state)
                    span.attributes["interrupted"] = True
                    tracer.end_span(span)
                except Exception:
                    pass
        self.pending_turns.clear()


# ---------------------------------------------------------------------------
# Integration class
# ---------------------------------------------------------------------------


class ClaudeAgentIntegration(Integration):
    """
    First-party integration for the Claude Agent SDK.

    Patches ``claude_agent_sdk.query`` and ``ClaudeSDKClient`` methods
    to automatically emit one ZeroEval **trace** per agent turn/query.
    The Claude conversation ID is captured as ``claude_session_id`` and
    used as the ZeroEval session so that related turns group together.
    """

    PACKAGE_NAME = "claude_agent_sdk"

    def setup(self) -> None:
        try:
            import claude_agent_sdk
            from claude_agent_sdk import ClaudeSDKClient

            logger.debug("[ClaudeAgent] Setting up integration")

            self._patch_method(claude_agent_sdk, "query", self._wrap_query)

            self._patch_method(ClaudeSDKClient, "connect", self._wrap_client_connect)
            self._patch_method(ClaudeSDKClient, "query", self._wrap_client_query)
            self._patch_method(
                ClaudeSDKClient, "receive_messages", self._wrap_receive_messages
            )
            self._patch_method(ClaudeSDKClient, "disconnect", self._wrap_disconnect)

            logger.info("[ClaudeAgent] Integration setup complete")
        except Exception as e:
            logger.error(f"[ClaudeAgent] Failed to setup integration: {e}")
            raise

    # ------------------------------------------------------------------
    # query() wrapper  (Unit 2)
    # ------------------------------------------------------------------

    def _wrap_query(self, original: Callable) -> Callable:
        integration = self

        @wraps(original)
        async def wrapper(*, prompt, options=None, transport=None):
            from claude_agent_sdk.types import ResultMessage

            state = TurnState(prompt_summary=_summarize_prompt(prompt))
            wrapped_options = (
                _wrap_options(options, state) if options is not None else None
            )

            span = integration.tracer.start_span(
                name="claude_agent.query",
                kind="agent",
                attributes={"integration": "claude_agent_sdk"},
                tags={"integration": "claude_agent_sdk"},
                is_new_trace=True,
            )
            error = None
            try:
                async for message in original(
                    prompt=prompt, options=wrapped_options, transport=transport
                ):
                    _extract_message_data(message, state)
                    yield message
                    if isinstance(message, ResultMessage):
                        break
            except Exception as exc:
                error = exc
                raise
            finally:
                try:
                    _apply_state_to_span(span, state)
                except Exception:
                    pass
                try:
                    if error is not None:
                        span.set_error(
                            code=error.__class__.__name__,
                            message=str(error),
                        )
                except Exception:
                    pass
                try:
                    integration.tracer.end_span(span)
                except Exception:
                    pass

        return wrapper

    # ------------------------------------------------------------------
    # ClaudeSDKClient wrappers  (Unit 3)
    # ------------------------------------------------------------------

    def _wrap_client_connect(self, original: Callable) -> Callable:
        integration = self

        @wraps(original)
        async def wrapper(client_self, prompt=None):
            if not hasattr(client_self, _ZE_CLIENT_STATE):
                css = ClientSpanState()
                css.original_options = getattr(client_self, "options", None)
                setattr(client_self, _ZE_CLIENT_STATE, css)

            css: ClientSpanState = getattr(client_self, _ZE_CLIENT_STATE)

            if prompt is not None:
                state = TurnState(prompt_summary=_summarize_prompt(prompt))

                if css.original_options is not None:
                    client_self.options = _wrap_options(css.original_options, state)

                span = integration.tracer.start_span(
                    name="claude_agent.turn",
                    kind="agent",
                    attributes={"integration": "claude_agent_sdk"},
                    tags={"integration": "claude_agent_sdk"},
                    is_new_trace=True,
                )
                css.push_turn("default", span, state)

            error = None
            try:
                return await original(client_self, prompt)
            except Exception as exc:
                error = exc
                raise
            finally:
                if error is not None and prompt is not None:
                    closed = css.pop_turn("default")
                    if closed:
                        span, state = closed
                        try:
                            _apply_state_to_span(span, state)
                        except Exception:
                            pass
                        try:
                            span.set_error(
                                code=error.__class__.__name__,
                                message=str(error),
                            )
                        except Exception:
                            pass
                        try:
                            integration.tracer.end_span(span)
                        except Exception:
                            pass

        return wrapper

    def _wrap_client_query(self, original: Callable) -> Callable:
        integration = self

        @wraps(original)
        async def wrapper(client_self, prompt, session_id="default"):
            if not hasattr(client_self, _ZE_CLIENT_STATE):
                css = ClientSpanState()
                css.original_options = getattr(client_self, "options", None)
                setattr(client_self, _ZE_CLIENT_STATE, css)

            css: ClientSpanState = getattr(client_self, _ZE_CLIENT_STATE)
            state = TurnState(prompt_summary=_summarize_prompt(prompt))

            if css.original_options is not None:
                client_self.options = _wrap_options(css.original_options, state)

            span = integration.tracer.start_span(
                name="claude_agent.turn",
                kind="agent",
                attributes={"integration": "claude_agent_sdk"},
                tags={"integration": "claude_agent_sdk"},
                is_new_trace=True,
            )
            css.push_turn(session_id, span, state)

            error = None
            try:
                return await original(client_self, prompt, session_id)
            except Exception as exc:
                error = exc
                raise
            finally:
                if error is not None:
                    closed = css.pop_turn(session_id)
                    if closed:
                        span, state = closed
                        try:
                            _apply_state_to_span(span, state)
                        except Exception:
                            pass
                        try:
                            span.set_error(
                                code=error.__class__.__name__,
                                message=str(error),
                            )
                        except Exception:
                            pass
                        try:
                            integration.tracer.end_span(span)
                        except Exception:
                            pass

        return wrapper

    def _wrap_receive_messages(self, original: Callable) -> Callable:
        integration = self

        @wraps(original)
        async def wrapper(client_self):
            from claude_agent_sdk.types import ResultMessage

            css: Optional[ClientSpanState] = getattr(
                client_self, _ZE_CLIENT_STATE, None
            )

            error = None
            try:
                async for message in original(client_self):
                    if css is not None:
                        sid = getattr(message, "session_id", None)
                        pair = css.peek_turn(sid)
                        if pair:
                            _, state = pair
                            _extract_message_data(message, state)

                        if isinstance(message, ResultMessage):
                            result_sid = getattr(message, "session_id", None)
                            closed = css.pop_turn(result_sid)
                            if closed:
                                span, state = closed
                                try:
                                    _apply_state_to_span(span, state)
                                    integration.tracer.end_span(span)
                                except Exception:
                                    pass

                    yield message
            except Exception as exc:
                error = exc
                raise
            finally:
                if css is not None:
                    closed = css.pop_turn(None)
                    if closed:
                        span, state = closed
                        try:
                            _apply_state_to_span(span, state)
                        except Exception:
                            pass
                        try:
                            if error is not None:
                                span.set_error(
                                    code=error.__class__.__name__,
                                    message=str(error),
                                )
                        except Exception:
                            pass
                        try:
                            integration.tracer.end_span(span)
                        except Exception:
                            pass

        return wrapper

    def _wrap_disconnect(self, original: Callable) -> Callable:
        integration = self

        @wraps(original)
        async def wrapper(client_self):
            css: Optional[ClientSpanState] = getattr(
                client_self, _ZE_CLIENT_STATE, None
            )
            if css is not None:
                css.close_all(integration.tracer)

            return await original(client_self)

        return wrapper
