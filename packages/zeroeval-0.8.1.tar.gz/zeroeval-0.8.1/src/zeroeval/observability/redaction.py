import ipaddress
import json
import os
import re
from dataclasses import dataclass, field
from re import Pattern
from typing import Any, Optional, TypedDict, Union


class RedactionConfig(TypedDict, total=False):
    enabled: bool
    redact_inputs: bool
    redact_outputs: bool
    sensitive_keys: list[str]
    custom_patterns: list[Union[Pattern[str], str]]


@dataclass(frozen=True)
class CompiledRedactionConfig:
    enabled: bool = False
    redact_inputs: bool = True
    redact_outputs: bool = True
    sensitive_keys: tuple[str, ...] = ()
    custom_patterns: tuple[Pattern[str], ...] = ()


@dataclass
class RedactionReferenceContext:
    references: dict[str, dict[str, str]] = field(default_factory=dict)
    counters: dict[str, int] = field(default_factory=dict)

    def get_placeholder(self, kind: str, normalized_value: str) -> str:
        per_kind = self.references.setdefault(kind, {})
        if normalized_value in per_kind:
            return per_kind[normalized_value]
        index = self.counters.get(kind, 0)
        self.counters[kind] = index + 1
        placeholder = f"[REDACTED_{kind.upper()}_{_index_to_label(index)}]"
        per_kind[normalized_value] = placeholder
        return placeholder


DEFAULT_SENSITIVE_KEYS = (
    "access_token",
    "api_key",
    "apikey",
    "authorization",
    "auth_token",
    "bearer",
    "client_secret",
    "cookie",
    "email",
    "id_token",
    "jwt",
    "national_id",
    "password",
    "phone",
    "proxy_authorization",
    "refresh_token",
    "secret",
    "session_token",
    "set_cookie",
    "ssn",
    "token",
    "x_api_key",
)

MESSAGE_LIKE_KEYS = {
    "arguments",
    "contents",
    "input_data",
    "input_messages",
    "messages",
    "output_data",
    "output_text",
    "system_prompt_template",
}

PLACEHOLDERS = {
    "card": "[REDACTED_CARD]",
    "custom": "[REDACTED_SECRET]",
    "email": "[REDACTED_EMAIL]",
    "ip": "[REDACTED_IP]",
    "phone": "[REDACTED_PHONE]",
    "secret": "[REDACTED_SECRET]",
    "session": "[REDACTED_SESSION]",
    "ssn": "[REDACTED_SSN]",
}

PLACEHOLDER_RE = re.compile(r"\[REDACTED_[A-Z]+(?:_[A-Z0-9]+)?\]")
EMAIL_RE = re.compile(r"\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b", re.IGNORECASE)
PHONE_RE = re.compile(r"(?:(?<=\D)|^)(?:\+?\d[\d(). \-]{8,}\d)(?:(?=\D)|$)")
SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
PAN_RE = re.compile(r"\b(?:\d[ -]?){13,19}\b")
BEARER_RE = re.compile(r"(?i)\bBearer\s+([A-Za-z0-9\-._~+/]+=*[A-Za-z0-9\-._~+/=]*)")
JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_\-]*\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\b")
API_KEY_RE = re.compile(
    r"\b(?:sk|pk|rk|ghp|gho|github_pat|xox[baprs]|AIzaSy)[A-Za-z0-9_\-]{8,}\b"
)
AUTH_HEADER_RE = re.compile(
    r"(?i)\b(authorization|proxy-authorization)\s*:\s*([^\r\n]+)"
)
COOKIE_HEADER_RE = re.compile(r"(?i)\b(cookie|set-cookie)\s*:\s*([^\r\n]+)")
IPV4_RE = re.compile(
    r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b"
)
IPV6_RE = re.compile(
    r"\b(?:[A-F0-9]{1,4}:){2,7}[A-F0-9]{1,4}\b",
    re.IGNORECASE,
)


def _index_to_label(index: int) -> str:
    label = ""
    value = index
    while True:
        value, remainder = divmod(value, 26)
        label = chr(ord("A") + remainder) + label
        if value == 0:
            return label
        value -= 1


def _normalize_key(key: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(key).strip().lower()).strip("_")


def _coerce_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _looks_like_json(text: str) -> bool:
    stripped = text.strip()
    if len(stripped) < 2:
        return False
    return (stripped[0] == "{" and stripped[-1] == "}") or (
        stripped[0] == "[" and stripped[-1] == "]"
    )


def _luhn_valid(value: str) -> bool:
    digits = "".join(ch for ch in value if ch.isdigit())
    if len(digits) < 13 or len(digits) > 19:
        return False
    total = 0
    parity = len(digits) % 2
    for idx, char in enumerate(digits):
        digit = int(char)
        if idx % 2 == parity:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    return total % 10 == 0


def build_redaction_config(
    config: Optional[dict[str, Any]] = None,
) -> CompiledRedactionConfig:
    data = dict(config or {})
    sensitive_keys = set(DEFAULT_SENSITIVE_KEYS)
    sensitive_keys.update(
        _normalize_key(key) for key in data.get("sensitive_keys", []) if key
    )
    custom_patterns = []
    for pattern in data.get("custom_patterns", []):
        if isinstance(pattern, str):
            custom_patterns.append(re.compile(pattern, re.IGNORECASE))
        else:
            custom_patterns.append(pattern)
    return CompiledRedactionConfig(
        enabled=_coerce_bool(
            data.get("enabled", os.environ.get("ZEROEVAL_REDACT_PII"))
        ),
        redact_inputs=bool(data.get("redact_inputs", True)),
        redact_outputs=bool(data.get("redact_outputs", True)),
        sensitive_keys=tuple(sorted(sensitive_keys)),
        custom_patterns=tuple(custom_patterns),
    )


def config_to_dict(config: CompiledRedactionConfig) -> dict[str, Any]:
    return {
        "enabled": config.enabled,
        "redact_inputs": config.redact_inputs,
        "redact_outputs": config.redact_outputs,
        "sensitive_keys": list(config.sensitive_keys),
        "custom_patterns": list(config.custom_patterns),
    }


def merge_redaction_summaries(*summaries: Optional[dict[str, Any]]) -> dict[str, Any]:
    enabled = False
    count = 0
    types = set()
    for summary in summaries:
        if not summary:
            continue
        enabled = enabled or bool(summary.get("enabled"))
        count += int(summary.get("count", 0) or 0)
        types.update(summary.get("types", []))
    return {"enabled": enabled, "count": count, "types": sorted(types)}


def attach_redaction_metadata(
    attributes: Optional[dict[str, Any]], summary: Optional[dict[str, Any]]
) -> dict[str, Any]:
    attrs = dict(attributes or {})
    if not summary or not summary.get("enabled"):
        return attrs
    existing = attrs.get("zeroeval_redaction")
    merged = (
        merge_redaction_summaries(existing, summary)
        if isinstance(existing, dict)
        else merge_redaction_summaries(summary)
    )
    if merged["count"] > 0 or existing:
        attrs["zeroeval_redaction"] = merged
    return attrs


class Redactor:
    def __init__(self, config: Optional[dict[str, Any]] = None):
        self.config = build_redaction_config(config)

    @property
    def enabled(self) -> bool:
        return self.config.enabled

    def redact_input(
        self, value: Any, context: Optional[RedactionReferenceContext] = None
    ) -> tuple[Any, dict[str, Any]]:
        return self._sanitize_context(
            value, self.config.redact_inputs, "input_data", context
        )

    def redact_output(
        self, value: Any, context: Optional[RedactionReferenceContext] = None
    ) -> tuple[Any, dict[str, Any]]:
        return self._sanitize_context(
            value, self.config.redact_outputs, "output_data", context
        )

    def redact_attributes(
        self, value: Any, context: Optional[RedactionReferenceContext] = None
    ) -> tuple[Any, dict[str, Any]]:
        return value, self._summary(0)

    def redact_tags(
        self, value: Any, context: Optional[RedactionReferenceContext] = None
    ) -> tuple[Any, dict[str, Any]]:
        return value, self._summary(0)

    def redact_error(
        self, value: Any, context: Optional[RedactionReferenceContext] = None
    ) -> tuple[Any, dict[str, Any]]:
        return value, self._summary(0)

    def redact_session_name(
        self,
        value: Any,
        derived_from_session_id: bool = False,
        context: Optional[RedactionReferenceContext] = None,
    ) -> tuple[Any, dict[str, Any]]:
        return value, self._summary(0)

    def redact_for_logging(
        self, value: Any, context: Optional[RedactionReferenceContext] = None
    ) -> Any:
        if not self.enabled:
            return value
        return self._sanitize_value(value, context=context)[0]

    def redact_span_payload(
        self,
        span: dict[str, Any],
        context: Optional[RedactionReferenceContext] = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        if not self.enabled:
            return span, self._summary(0)
        redacted = dict(span)
        input_data, input_summary = self.redact_input(
            redacted.get("input_data"), context=context
        )
        output_data, output_summary = self.redact_output(
            redacted.get("output_data"), context=context
        )
        total_summary = merge_redaction_summaries(input_summary, output_summary)
        redacted["attributes"] = attach_redaction_metadata(
            redacted.get("attributes"), total_summary
        )
        redacted["input_data"] = input_data
        redacted["output_data"] = output_data
        return redacted, total_summary

    def _sanitize_context(
        self,
        value: Any,
        context_enabled: bool,
        key: Optional[str] = None,
        context: Optional[RedactionReferenceContext] = None,
    ) -> tuple[Any, dict[str, Any]]:
        if value is None or not self.enabled or not context_enabled:
            return value, self._summary(0)
        return self._sanitize_value(value, key=key, context=context)

    def _sanitize_value(
        self,
        value: Any,
        key: Optional[str] = None,
        parse_json_strings: bool = True,
        context: Optional[RedactionReferenceContext] = None,
    ) -> tuple[Any, dict[str, Any]]:
        if value is None or isinstance(value, (bool, int, float)):
            return value, self._summary(0)
        if isinstance(value, str):
            return self._sanitize_string(
                value,
                key=key,
                parse_json_strings=parse_json_strings,
                context=context,
            )
        if isinstance(value, bytes):
            try:
                decoded = value.decode("utf-8")
            except UnicodeDecodeError:
                kind = self._kind_for_key(key)
                return self._issue_placeholder(
                    kind, repr(value), context
                ), self._summary(1, {kind})
            return self._sanitize_string(
                decoded,
                key=key,
                parse_json_strings=parse_json_strings,
                context=context,
            )
        if isinstance(value, dict):
            sanitized: dict[Any, Any] = {}
            count = 0
            types = set()
            for item_key, item_value in value.items():
                normalized_key = _normalize_key(item_key)
                if self._should_force_redact_key(normalized_key):
                    sanitized_value, summary = self._redact_for_key(
                        item_value, self._kind_for_key(normalized_key), context
                    )
                else:
                    sanitized_value, summary = self._sanitize_value(
                        item_value, key=normalized_key, context=context
                    )
                sanitized[item_key] = sanitized_value
                count += summary["count"]
                types.update(summary["types"])
            return sanitized, self._summary(count, types)
        if isinstance(value, list):
            count = 0
            types = set()
            sanitized_list = []
            for item in value:
                sanitized_item, summary = self._sanitize_value(
                    item, key=key, context=context
                )
                sanitized_list.append(sanitized_item)
                count += summary["count"]
                types.update(summary["types"])
            return sanitized_list, self._summary(count, types)
        if isinstance(value, tuple):
            sanitized_list, summary = self._sanitize_value(
                list(value), key=key, context=context
            )
            return tuple(sanitized_list), summary
        if isinstance(value, set):
            count = 0
            types = set()
            sanitized_set = set()
            for item in value:
                sanitized_item, summary = self._sanitize_value(
                    item, key=key, context=context
                )
                sanitized_set.add(sanitized_item)
                count += summary["count"]
                types.update(summary["types"])
            return sanitized_set, self._summary(count, types)
        if hasattr(value, "model_dump"):
            return self._sanitize_value(value.model_dump(), key=key, context=context)
        if hasattr(value, "dict"):
            try:
                return self._sanitize_value(value.dict(), key=key, context=context)
            except TypeError:
                pass
        if hasattr(value, "__dict__"):
            return self._sanitize_value(
                {
                    item_key: item_value
                    for item_key, item_value in vars(value).items()
                    if not str(item_key).startswith("_")
                },
                key=key,
                context=context,
            )
        return self._sanitize_string(
            str(value), key=key, parse_json_strings=False, context=context
        )

    def _sanitize_string(
        self,
        value: str,
        key: Optional[str] = None,
        parse_json_strings: bool = True,
        context: Optional[RedactionReferenceContext] = None,
    ) -> tuple[Any, dict[str, Any]]:
        if PLACEHOLDER_RE.fullmatch(value):
            return value, self._summary(0)
        normalized_key = _normalize_key(key) if key else None
        if parse_json_strings and _looks_like_json(value):
            try:
                parsed = json.loads(value)
            except (TypeError, ValueError):
                parsed = None
            if parsed is not None:
                sanitized_value, summary = self._sanitize_value(
                    parsed,
                    key=normalized_key,
                    parse_json_strings=False,
                    context=context,
                )
                if summary["count"] > 0:
                    return json.dumps(sanitized_value, ensure_ascii=False), summary
                return value, summary
        if self._should_force_redact_key(normalized_key):
            return self._redact_for_key(
                value, self._kind_for_key(normalized_key), context
            )

        redacted_value = value
        count = 0
        types = set()

        def replace(
            pattern: Pattern[str],
            kind: str,
            *,
            extractor: Optional[Any] = None,
            formatter: Optional[Any] = None,
            validator: Optional[Any] = None,
        ) -> None:
            nonlocal redacted_value, count, types

            def repl(match: re.Match[str]) -> str:
                nonlocal count, types
                matched = match.group(0)
                if PLACEHOLDER_RE.fullmatch(matched):
                    return matched
                if validator and not validator(matched):
                    return matched
                raw_value = extractor(match) if extractor else matched
                placeholder = self._issue_placeholder(kind, raw_value, context)
                count += 1
                types.add(kind)
                return formatter(match, placeholder) if formatter else placeholder

            redacted_value = pattern.sub(repl, redacted_value)

        replace(
            AUTH_HEADER_RE,
            "secret",
            extractor=lambda match: self._secret_body(match.group(2)),
            formatter=lambda match, placeholder: f"{match.group(1)}: {placeholder}",
        )
        replace(
            COOKIE_HEADER_RE,
            "secret",
            extractor=lambda match: match.group(2).strip(),
            formatter=lambda match, placeholder: f"{match.group(1)}: {placeholder}",
        )
        replace(
            BEARER_RE,
            "secret",
            extractor=lambda match: match.group(1),
            formatter=lambda _match, placeholder: f"Bearer {placeholder}",
        )
        replace(JWT_RE, "secret")
        replace(API_KEY_RE, "secret")
        replace(PAN_RE, "card", validator=_luhn_valid)
        replace(SSN_RE, "ssn")
        replace(EMAIL_RE, "email")
        replace(IPV4_RE, "ip")
        replace(IPV6_RE, "ip")
        replace(PHONE_RE, "phone")
        for pattern in self.config.custom_patterns:
            replace(pattern, "custom")
        return redacted_value, self._summary(count, types)

    def _redact_for_key(
        self,
        value: Any,
        kind: str,
        context: Optional[RedactionReferenceContext],
    ) -> tuple[Any, dict[str, Any]]:
        if isinstance(value, str):
            sanitized, summary = self._sanitize_string(
                value, parse_json_strings=False, context=context
            )
            if summary["count"] > 0 or PLACEHOLDER_RE.search(value):
                return sanitized, summary
            return self._issue_placeholder(kind, value, context), self._summary(
                1, {kind}
            )
        if isinstance(value, bytes):
            return self._issue_placeholder(kind, repr(value), context), self._summary(
                1, {kind}
            )
        return self._issue_placeholder(
            kind, self._stable_text(value), context
        ), self._summary(1, {kind})

    def _issue_placeholder(
        self,
        kind: str,
        raw_value: Any,
        context: Optional[RedactionReferenceContext],
    ) -> str:
        text = str(raw_value).strip()
        if PLACEHOLDER_RE.fullmatch(text):
            return text
        normalized = self._normalize_value(kind, text)
        if not normalized:
            return PLACEHOLDERS[kind]
        if context is None:
            return PLACEHOLDERS[kind]
        return context.get_placeholder(kind, normalized)

    def _normalize_value(self, kind: str, value: str) -> str:
        trimmed = value.strip()
        if kind == "email":
            return trimmed.lower()
        if kind == "phone":
            digits = "".join(ch for ch in trimmed if ch.isdigit())
            return digits
        if kind in {"ssn", "card"}:
            return "".join(ch for ch in trimmed if ch.isdigit())
        if kind == "ip":
            try:
                return str(ipaddress.ip_address(trimmed))
            except ValueError:
                return trimmed
        if kind == "secret":
            return self._secret_body(trimmed)
        return trimmed

    def _secret_body(self, value: str) -> str:
        trimmed = value.strip()
        header_match = re.match(
            r"(?i)^(authorization|proxy-authorization|cookie|set-cookie)\s*:\s*(.*)$",
            trimmed,
        )
        if header_match:
            trimmed = header_match.group(2).strip()
        bearer_match = re.match(r"(?i)^Bearer\s+(.*)$", trimmed)
        if bearer_match:
            return bearer_match.group(1).strip()
        return trimmed

    def _stable_text(self, value: Any) -> str:
        try:
            return json.dumps(value, sort_keys=True, default=str)
        except TypeError:
            return str(value)

    def _should_force_redact_key(self, key: Optional[str]) -> bool:
        if not key:
            return False
        normalized = _normalize_key(key)
        if normalized in MESSAGE_LIKE_KEYS:
            return False
        if normalized in self.config.sensitive_keys:
            return True
        return bool(
            "password" in normalized
            or "secret" in normalized
            or "token" in normalized
            or "authorization" in normalized
            or "cookie" in normalized
            or normalized.endswith("_email")
            or normalized.endswith("_phone")
        )

    def _kind_for_key(self, key: Optional[str]) -> str:
        normalized = _normalize_key(key)
        if "email" in normalized:
            return "email"
        if "phone" in normalized or normalized in {"mobile", "telephone"}:
            return "phone"
        if "ssn" in normalized or "national_id" in normalized:
            return "ssn"
        if "card" in normalized or "credit" in normalized or "pan" in normalized:
            return "card"
        if normalized == "session_name":
            return "session"
        if normalized.endswith("_ip") or normalized == "ip":
            return "ip"
        return "secret"

    def _summary(self, count: int, types: Optional[set[str]] = None) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "count": count,
            "types": sorted(types or set()),
        }
