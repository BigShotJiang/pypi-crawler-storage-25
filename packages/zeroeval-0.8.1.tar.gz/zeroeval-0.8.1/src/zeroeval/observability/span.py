import time
import traceback
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional, Union

from .redaction import attach_redaction_metadata, merge_redaction_summaries

_UNSET = object()


@dataclass
class Signal:
    """Represents a signal that can be attached to entities."""

    name: str
    value: Union[str, bool, int, float]
    signal_type: str = "boolean"  # "boolean", "numerical", or "categorical"

    def __post_init__(self):
        if self.signal_type not in {"boolean", "numerical", "categorical"}:
            self.signal_type = self._infer_signal_type(self.value)
        self.value = self._normalize_signal_value(self.value, self.signal_type)

    @staticmethod
    def _infer_signal_type(value: Union[str, bool, int, float]) -> str:
        if isinstance(value, bool):
            return "boolean"
        if isinstance(value, (int, float)):
            return "numerical"
        str_val = str(value).strip().lower()
        if str_val in ("true", "false"):
            return "boolean"
        return "categorical"

    @staticmethod
    def _normalize_signal_value(
        value: Union[str, bool, int, float], signal_type: str
    ) -> str:
        if signal_type == "boolean":
            if isinstance(value, bool):
                return "true" if value else "false"
            str_val = str(value).strip().lower()
            return (
                "true"
                if str_val == "true"
                else "false"
                if str_val == "false"
                else str(value)
            )
        if signal_type == "numerical":
            return str(value)
        return str(value)


@dataclass
class Span:
    """
    Represents a traced operation with OpenTelemetry-compatible attributes.
    """

    # Required fields first
    name: str

    # Optional fields with defaults
    kind: str = (
        "generic"  # Type of span: generic, llm, tts, http, database, vector_store, etc.
    )
    session_id: Optional[str] = None
    session_name: Optional[str] = None
    trace_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    span_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    parent_id: Optional[str] = None
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None
    attributes: dict[str, Any] = field(default_factory=dict)
    # Fields for tracking execution
    input_data: Optional[str] = None
    output_data: Optional[str] = None
    code: Optional[str] = None  # Added code field
    code_filepath: Optional[str] = None
    code_lineno: Optional[int] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    error_stack: Optional[str] = None
    status: str = "ok"
    tags: dict[str, str] = field(default_factory=dict)
    # Optional tags that should be applied to the owning trace and/or session when this
    # span is ingested. These will be processed by the backend ingestion service.
    trace_tags: dict[str, str] = field(default_factory=dict)
    session_tags: dict[str, str] = field(default_factory=dict)
    # Signals attached to this span
    signals: dict[str, Any] = field(default_factory=dict)
    # AB test choices made in this span's context
    ab_choices: list[dict[str, Any]] = field(default_factory=list)
    # Image/screenshot attachments for visual evaluation
    attachments: list[dict[str, Any]] = field(default_factory=list)
    redactor: Any = field(default=None, repr=False, compare=False)
    redaction_context: Any = field(default=None, repr=False, compare=False)

    @property
    def duration_ms(self) -> Optional[float]:
        """Get the span duration in milliseconds, if completed."""
        if self.end_time is None:
            return None

        return (self.end_time - self.start_time) * 1000

    def set_error(self, code: str, message: str, stack: Optional[str] = None) -> None:
        """Set error information for the span."""
        self.error_code = code
        self.error_message = message
        self.error_stack = stack
        self.status = "error"

    def set_io(self, input_data: Any = _UNSET, output_data: Any = _UNSET) -> None:
        """Set input/output data for the span, without overwriting existing values."""
        summary = None
        if input_data is not _UNSET:
            if self.redactor:
                input_data, input_summary = self.redactor.redact_input(
                    input_data, context=self.redaction_context
                )
                summary = merge_redaction_summaries(summary, input_summary)
            self.input_data = input_data
        if output_data is not _UNSET:
            if self.redactor:
                output_data, output_summary = self.redactor.redact_output(
                    output_data, context=self.redaction_context
                )
                summary = merge_redaction_summaries(summary, output_summary)
            self.output_data = output_data
        self.attributes = attach_redaction_metadata(self.attributes, summary)

    def set_code(self, code: str) -> None:
        """Set the code that was executed in this span."""
        self.code = code

    def set_code_context(self, filepath: str, lineno: int) -> None:
        """Set the file path and line number for the span's execution context."""
        self.code_filepath = filepath
        self.code_lineno = lineno

    def set_signal(
        self,
        name: str,
        value: Union[str, bool, int, float],
        signal_type: Optional[str] = None,
    ) -> None:
        """Set a signal for this span."""
        self.signals[name] = Signal(
            name=name,
            value=value,
            signal_type=signal_type or Signal._infer_signal_type(value),
        )

    def add_screenshot(
        self,
        base64_data: str,
        viewport: str = "desktop",
        width: Optional[int] = None,
        height: Optional[int] = None,
        label: Optional[str] = None,
    ) -> None:
        """
        Attach a screenshot to this span for visual evaluation.

        Screenshots are uploaded to S3 during span ingestion and can be
        evaluated by LLM judges configured for visual evaluation.

        Args:
            base64_data: Base64 encoded image data. Can be:
                - Raw base64 string (MIME type will be detected)
                - Data URL format: "data:image/jpeg;base64,/9j/4AAQ..."
            viewport: Viewport type (e.g., "desktop", "mobile", "tablet")
            width: Image width in pixels (optional)
            height: Image height in pixels (optional)
            label: Human-readable label for the screenshot (optional)

        Example:
            span.add_screenshot(
                base64_data="data:image/png;base64,iVBORw0KGgo...",
                viewport="mobile",
                width=375,
                height=812,
                label="Homepage - iPhone"
            )
        """
        attachment = {
            "type": "screenshot",
            "base64": base64_data,
            "viewport": viewport,
        }

        if width is not None:
            attachment["width"] = width
        if height is not None:
            attachment["height"] = height
        if label is not None:
            attachment["label"] = label

        self.attachments.append(attachment)

    def add_image(
        self,
        base64_data: str,
        label: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> None:
        """
        Attach a generic image to this span for visual evaluation.

        Images are uploaded to S3 during span ingestion and can be
        evaluated by LLM judges configured for visual evaluation.

        Args:
            base64_data: Base64 encoded image data. Can be:
                - Raw base64 string (MIME type will be detected)
                - Data URL format: "data:image/jpeg;base64,/9j/4AAQ..."
            label: Human-readable label for the image (optional)
            metadata: Additional metadata dict (optional)

        Example:
            span.add_image(
                base64_data=image_bytes_base64,
                label="Generated chart",
                metadata={"chart_type": "bar", "data_points": 10}
            )
        """
        attachment = {
            "type": "image",
            "base64": base64_data,
        }

        if label is not None:
            attachment["label"] = label
        if metadata is not None:
            reserved_keys = {"type", "base64", "label"}
            for key, value in metadata.items():
                if key not in reserved_keys:
                    attachment[key] = value

        self.attachments.append(attachment)

    def to_dict(self) -> dict[str, Any]:
        """Convert the span to a dictionary representation."""
        # Convert signals to a serializable format
        signals_dict = {}
        for name, signal in self.signals.items():
            if hasattr(signal, "value") and hasattr(signal, "signal_type"):
                signals_dict[name] = {
                    "name": signal.name,
                    "value": signal.value,
                    "type": signal.signal_type,
                }
            else:
                # Handle legacy signal format or simple values
                signals_dict[name] = signal

        # Copy attributes and add attachments if present
        attributes = dict(self.attributes)
        if self.attachments:
            attributes["attachments"] = self.attachments

        span_dict = {
            "name": self.name,
            "kind": self.kind,
            "session_id": self.session_id,
            "session_name": self.session_name,
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "parent_id": self.parent_id,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "attributes": attributes,
            "tags": {k: str(v) for k, v in self.tags.items()},
            "trace_tags": {k: str(v) for k, v in self.trace_tags.items()},
            "session_tags": {k: str(v) for k, v in self.session_tags.items()},
            "signals": signals_dict,
            "ab_choices": self.ab_choices,
            "input_data": self.input_data,
            "output_data": self.output_data,
            "code": self.code,  # Added code field
            "code_filepath": self.code_filepath,
            "code_lineno": self.code_lineno,
            "error_code": self.error_code,
            "error_message": self.error_message,
            "error_stack": self.error_stack,
            "status": self.status,
        }

        return span_dict

    def end(self, error: Optional[Exception] = None) -> None:
        """End the span, calculating duration and capturing errors."""
        if self.end_time:
            return  # Span already ended

        self.end_time = time.time()

        if error:
            self.set_error(
                code=type(error).__name__,
                message=str(error),
                stack="".join(traceback.format_exception(error)),
            )
