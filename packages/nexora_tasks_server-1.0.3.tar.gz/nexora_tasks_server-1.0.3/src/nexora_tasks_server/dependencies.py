"""FastAPI dependency injection for authentication and framework access."""

from typing import Literal, Optional, Tuple

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request, status
from pydantic import BaseModel, ConfigDict, Field, field_validator

from nexora_tasks.errors import AUTH_INVALID, AUTH_REQUIRED, METADATA_REQUIRED, problem_json_dict
from nexora_tasks_server.auth import constant_time_key_in
from nexora_tasks_server.framework import NexoraTasks
from nexora_tasks.models.task_definition import TaskDefinition

# M-12: process-wide fallback for the framework instance. Retained for
# backwards compatibility (proxy bootstrap, legacy CLI paths) but the
# preferred binding is now per-app: ``set_framework_for_app(app, framework)``
# writes to ``app.state.framework`` so two FastAPI apps in the same process
# (e.g. the proxy + a temp framework) cannot stomp on each other, and tests
# can override via ``app.dependency_overrides[get_framework]``.
_framework_instance: Optional[NexoraTasks] = None


def set_framework_instance(framework: NexoraTasks) -> None:
    """Set the process-wide framework instance.

    Backwards-compatible entry point. New code SHOULD call
    :func:`set_framework_for_app` instead so the binding is scoped to a
    specific FastAPI app and survives test overrides.

    Args:
        framework: NexoraTasks instance to use for dependency injection
    """
    global _framework_instance
    _framework_instance = framework


def set_framework_for_app(app: FastAPI, framework: NexoraTasks) -> None:
    """Bind ``framework`` to a specific FastAPI application.

    The framework is stored on ``app.state.framework`` and resolved by
    :func:`get_framework`. Tests that build their own ``FastAPI`` instance
    can simply override ``app.dependency_overrides[get_framework]`` instead
    of mutating any module-level singleton.

    Args:
        app: FastAPI application to bind the framework to.
        framework: NexoraTasks instance to expose to dependencies.
    """
    app.state.framework = framework
    # Mirror to the legacy global so paths that don't have a Request handle
    # (background tasks, CLI bootstrap) still resolve correctly.
    set_framework_instance(framework)


def get_framework(request: Request = None) -> NexoraTasks:  # type: ignore[assignment]
    """Resolve the active NexoraTasks instance for dependency injection.

    Resolution order (DI-aware first, legacy last):
    1. ``request.app.state.framework`` — preferred, app-scoped binding.
    2. ``_framework_instance`` — process-wide fallback set by
       :func:`set_framework_instance`.

    Args:
        request: FastAPI request, injected automatically when invoked via
            ``Depends(get_framework)``. ``None`` is tolerated for non-HTTP
            callers (background tasks, scripts).

    Returns:
        NexoraTasks instance.

    Raises:
        RuntimeError: If no framework has been bound to either scope.

    Notes:
        The ``Request = None`` default (rather than ``Optional[Request]``) is
        deliberate: FastAPI rejects ``Optional[Request]`` parameter
        annotations because Pydantic cannot generate a schema for
        ``starlette.requests.Request``. Declaring ``Request`` directly lets
        FastAPI inject the active request at runtime, while the ``= None``
        default keeps the function callable from non-HTTP contexts.
    """
    if request is not None:
        framework = getattr(request.app.state, "framework", None)
        if framework is not None:
            return framework
    if _framework_instance is None:
        raise RuntimeError(
            "Framework instance not set. Call set_framework_for_app(app, framework) "
            "during app construction (preferred) or set_framework_instance(framework) "
            "for the legacy global."
        )
    return _framework_instance


class AuthenticatedRequest(BaseModel):
    """Request context after successful authentication, containing key type and metadata."""

    api_key: str = Field(..., description="The verified API key value")
    key_type: Literal["regular", "admin"] = Field(..., description="Key type: regular or admin")
    user_id: Optional[str] = Field(None, description="User identifier (required for regular keys)")
    app_id: Optional[str] = Field(None, description="Application identifier (required for regular keys)")
    environment_id: str = Field(
        default="default",
        description="Resolved environment ID (from API key binding or X-Environment header)",
    )

    model_config = ConfigDict(frozen=True)

    @field_validator("user_id", "app_id", mode="before")
    @classmethod
    def validate_metadata(cls, v: Optional[str], info) -> Optional[str]:
        """Validate metadata fields based on key type."""
        if v == "":
            return None
        return v

    def model_post_init(self, __context: Optional[object]) -> None:
        """Validate that regular keys have required metadata."""
        if self.key_type == "regular":
            if not self.user_id:
                raise ValueError("user_id is required for regular API keys")
            if not self.app_id:
                raise ValueError("app_id is required for regular API keys")


async def get_authenticated_request(
    request: Request,
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
    x_environment: Optional[str] = Header(None, alias="X-Environment"),
    framework: NexoraTasks = Depends(get_framework),
) -> AuthenticatedRequest:
    """Authenticate request and return AuthenticatedRequest context.

    This FastAPI dependency validates the API key and extracts metadata from the request.
    It implements the authentication flow:
    1. Validate API key header
    2. Check key type (admin first, then regular, then environment-bound keys)
    3. Extract metadata (query params first, then headers)
    4. Validate metadata for regular keys
    5. Resolve environment from API key binding or X-Environment header
    6. Return AuthenticatedRequest

    Args:
        request: FastAPI request object (for accessing query params and headers)
        x_api_key: API key from X-API-Key header
        x_environment: Optional environment override from X-Environment header
        framework: NexoraTasks instance (dependency injection)

    Returns:
        AuthenticatedRequest with api_key, key_type, user_id, app_id, environment_id

    Raises:
        HTTPException: 401 if API key missing/invalid, 400 if metadata missing for regular key
    """
    # Step 1: Validate API key header
    if not x_api_key:
        from nexora_tasks.logging import logger
        from nexora_tasks_server.observability.metrics import api_requests_total

        logger.info("auth.failed", reason="missing_key", endpoint=str(request.url.path))
        problem = problem_json_dict(
            status_code=status.HTTP_401_UNAUTHORIZED,
            title="Unauthorized",
            detail="Missing API key",
            code=AUTH_REQUIRED,
        )
        # Increment metrics for auth failure
        api_requests_total.add(1, {"http.method": request.method, "http.route": str(request.url.path), "http.status_code": "401"})
        # FastAPI HTTPException accepts dict for detail
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=problem,
        )

    # Step 2: Check key type (admin first, then regular, then environment-bound)
    key_type: Literal["regular", "admin"]
    environment_id: str = "default"

    env_registry = framework.environment_registry

    # F-5: framework.match_api_key hashes the incoming candidate and
    # compares against startup-hashed digests; the plaintext legacy
    # lists are never stored on the framework instance any more.
    _match = framework.match_api_key(x_api_key)
    is_system_admin = _match == "admin"
    is_legacy_regular = _match == "regular"

    if is_system_admin:
        # System-level admin key: use X-Environment header or default
        key_type = "admin"
        environment_id = x_environment or "default"
    elif is_legacy_regular:
        # Legacy regular key (not bound to any environment): default
        key_type = "regular"
        # Check if this key is also bound to an environment
        env = env_registry.find_by_api_key(x_api_key)
        if env:
            environment_id = env.id
        else:
            environment_id = x_environment or "default"
    else:
        # Key not in legacy lists — check environment registry
        env = env_registry.find_by_api_key(x_api_key)
        env_admin = env_registry.find_by_admin_key(x_api_key) if not env else None

        if env:
            key_type = "regular"
            environment_id = env.id
        elif env_admin:
            key_type = "admin"
            environment_id = env_admin.id
        else:
            from nexora_tasks.logging import logger
            from nexora_tasks_server.observability.metrics import api_requests_total

            logger.info("auth.failed", reason="invalid_key", endpoint=str(request.url.path))
            problem = problem_json_dict(
                status_code=status.HTTP_401_UNAUTHORIZED,
                title="Unauthorized",
                detail="Invalid API key",
                code=AUTH_INVALID,
            )
            # Increment metrics for auth failure
            api_requests_total.add(1, {"http.method": request.method, "http.route": str(request.url.path), "http.status_code": "401"})
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=problem,
            )

    # If X-Environment header provided for env-bound key, validate it matches.
    # Only SYSTEM-LEVEL admin keys (those in framework.admin_api_keys) may
    # override the resolved environment. Environment-bound "admin" keys — keys
    # registered as admin within a single environment via the environment
    # registry — cannot cross environment boundaries.
    if x_environment and environment_id != "default" and x_environment != environment_id:
        if not is_system_admin:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=problem_json_dict(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    title="Bad Request",
                    detail=f"X-Environment header '{x_environment}' doesn't match API key's bound environment '{environment_id}'",
                    code="ENVIRONMENT_MISMATCH",
                ),
            )

    # Step 3: Extract metadata (query params first, then headers)
    user_id: Optional[str] = request.query_params.get("user_id")
    app_id: Optional[str] = request.query_params.get("app_id")

    # Fallback to headers if not in query params
    if not user_id:
        user_id = request.headers.get("X-User-Id")
    if not app_id:
        app_id = request.headers.get("X-App-Id")

    # Step 4: Validate metadata for regular keys
    if key_type == "regular":
        if not user_id or not app_id:
            from nexora_tasks.logging import logger
            from nexora_tasks_server.observability.metrics import api_requests_total

            logger.info("auth.failed", reason="missing_metadata", endpoint=str(request.url.path))
            problem = problem_json_dict(
                status_code=status.HTTP_400_BAD_REQUEST,
                title="Bad Request",
                detail="Missing required metadata (user_id or app_id) for regular API key",
                code=METADATA_REQUIRED,
            )
            # Increment metrics for bad request
            api_requests_total.add(1, {"http.method": request.method, "http.route": str(request.url.path), "http.status_code": "400"})
            # FastAPI HTTPException accepts dict for detail
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=problem,
            )

    # Step 5: Create and return AuthenticatedRequest
    auth_request = AuthenticatedRequest(
        api_key=x_api_key,
        key_type=key_type,
        user_id=user_id,
        app_id=app_id,
        environment_id=environment_id,
    )

    # Log successful authentication
    from nexora_tasks.logging import logger

    logger.info(
        "auth.succeeded",
        key_type=key_type,
        environment_id=environment_id,
        endpoint=str(request.url.path),
    )

    # Increment metrics
    from nexora_tasks_server.observability.metrics import api_requests_total

    api_requests_total.add(1, {"http.method": request.method, "http.route": str(request.url.path), "http.status_code": "200"})

    return auth_request


# Error codes for task resolution
TASK_NOT_FOUND = "TASK_NOT_FOUND"
TASK_ID_REQUIRED = "TASK_ID_REQUIRED"


class TaskContext(BaseModel):
    """Context for task-specific operations with resolved TaskDefinition."""
    
    task_definition: Optional[TaskDefinition] = Field(None, description="Resolved task definition")
    task_id: Optional[str] = Field(None, description="Task identifier from query params")
    version: Optional[str] = Field(None, description="Task version from query params")
    
    model_config = ConfigDict(arbitrary_types_allowed=True)


async def get_task_context(
    request: Request,
    task_id: Optional[str] = Query(None, description="Task identifier"),
    version: Optional[str] = Query(None, description="Task version (defaults to latest)"),
    task_version: Optional[str] = Query(None, description="Task version (alias for version)"),
    framework: NexoraTasks = Depends(get_framework),
) -> TaskContext:
    """Resolve task from query parameters.
    
    Resolves the TaskDefinition based on task_id and version.
    
    Args:
        request: FastAPI request object
        task_id: Optional task identifier from query params
        version: Optional task version from query params
        task_version: Optional task version (alias for version, for backward compatibility)
        framework: NexoraTasks instance
        
    Returns:
        TaskContext with resolved task definition
        
    Raises:
        HTTPException: If task not found or task_id required but not provided
    """
    await framework.task_registry.ensure_loaded()

    # Use task_version if version is not provided (for backward compatibility)
    resolved_version = version or task_version
    
    # If multiple tasks registered, task_id is required
    if framework.task_registry.count_tasks() > 1 and not task_id:
        from nexora_tasks.logging import logger
        
        logger.info("task_resolution.failed", reason="task_id_required", endpoint=str(request.url.path))
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=problem_json_dict(
                status_code=status.HTTP_400_BAD_REQUEST,
                title="Bad Request",
                detail="task_id query parameter is required when multiple tasks are registered",
                code=TASK_ID_REQUIRED,
            ),
        )
    
    # Try to resolve task
    task_def = framework.get_task(task_id, resolved_version)
    
    # If task_id was explicitly provided but task not found, error
    if task_id and not task_def:
        from nexora_tasks.logging import logger
        
        version_msg = f" version '{resolved_version}'" if resolved_version else ""
        logger.info("task_resolution.failed", reason="not_found", task_id=task_id, version=resolved_version)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Task '{task_id}'{version_msg} not found",
                code=TASK_NOT_FOUND,
            ),
        )
    
    return TaskContext(
        task_definition=task_def,
        task_id=task_id,
        version=resolved_version,
    )


async def require_task(
    task_context: TaskContext = Depends(get_task_context),
) -> TaskDefinition:
    """Require a resolved task definition.
    
    This dependency wraps get_task_context and ensures a task is resolved.
    Use this for endpoints that require a task to operate.
    
    Args:
        task_context: Resolved TaskContext from get_task_context
        
    Returns:
        TaskDefinition (guaranteed to be non-None)
        
    Raises:
        HTTPException: If no task could be resolved
    """
    if task_context.task_definition is None:
        # In single-task mode with a registered task function, this shouldn't happen
        # but we handle it for robustness
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=problem_json_dict(
                status_code=status.HTTP_400_BAD_REQUEST,
                title="Bad Request",
                detail="No task could be resolved. Ensure task_id is provided or a task is registered.",
                code=TASK_NOT_FOUND,
            ),
        )
    
    return task_context.task_definition


def get_task_database(task_def: Optional[TaskDefinition], framework: NexoraTasks):
    """Get the database for a task.
    
    Always returns the framework-level database since artifacts, threads,
    webhooks, and schedules should be stored at the framework level,
    not isolated per-task.
    
    Args:
        task_def: TaskDefinition if in multi-task mode (ignored)
        framework: NexoraTasks instance
        
    Returns:
        Database instance at framework level
    """
    # Always use framework database - artifacts, threads, webhooks, schedules
    # are stored at framework level, not per-task
    return framework.database


def get_task_file_storage(task_def: Optional[TaskDefinition], framework: NexoraTasks):
    """Get the file storage for a task.
    
    Always returns the framework-level file storage since all files
    should be stored at the framework level, not per-task.
    
    Args:
        task_def: TaskDefinition if in multi-task mode (ignored)
        framework: NexoraTasks instance
        
    Returns:
        FileStorage instance at framework level
    """
    # Always use framework file storage
    return framework.file_storage


async def get_task_function(task_def: Optional[TaskDefinition], framework: NexoraTasks):
    """Get the task function (from TaskDefinition).
    
    If task_def is provided but doesn't have a loaded function, attempts to lazy-load it.
    This handles cases where a non-latest version's task function wasn't loaded on startup.
    
    Args:
        task_def: TaskDefinition for the task
        framework: NexoraTasks instance
        
    Returns:
        Task function callable or None if not found
    """
    if task_def:
        task_function = task_def.get_task_function()
        if task_function:
            return task_function
        
        # In worker mode, the task function runs in the worker subprocess.
        # Return a placeholder so the API doesn't 503.
        # The ExecutionEngine will route to the worker instead of calling this.
        if framework.execution_mode == "worker" and framework.worker_manager.has_worker(task_def.full_id):
            def _worker_placeholder(*args, **kwargs):
                raise RuntimeError(
                    "This placeholder should never be called directly. "
                    "ExecutionEngine routes to worker subprocess."
                )
            return _worker_placeholder
        
        # Lazy load: task definition exists but function not loaded
        # This can happen if we're accessing a non-latest version that wasn't fully loaded
        try:
            from nexora_tasks_server.services.task_loader import TaskLoader
            from pathlib import Path
            import json

            from nexora_tasks.models.task_definition import TaskMetadata
            from nexora_tasks_server.utils.registry_paths import resolve_path_for_deployed_artifact

            task_storage = framework.task_storage
            task_loader = TaskLoader(task_storage)
            data_root = Path(framework._base_path)
            base_path = resolve_path_for_deployed_artifact(data_root, task_def.base_path)
            code_path = resolve_path_for_deployed_artifact(data_root, task_def.code_path)

            entry_point: Optional[str] = None
            # Prefer metadata next to deployment, then under code/ (SDK packages use
            # task_metadata.json inside the extracted code directory).
            for metadata_path in (
                base_path / "metadata.json",
                base_path / "task_metadata.json",
                code_path.parent / "metadata.json",
                code_path.parent / "task_metadata.json",
                code_path / "metadata.json",
                code_path / "task_metadata.json",
            ):
                if metadata_path.is_file():
                    with open(metadata_path, "r", encoding="utf-8") as f:
                        metadata_dict = json.load(f)
                    entry_point = TaskMetadata.model_validate(metadata_dict).entry_point
                    break

            if not entry_point:
                entry_point = task_def.entry_point

            if entry_point and code_path.exists():
                task_function = await task_loader._load_task_function(str(code_path), entry_point)
                task_def.set_task_function(task_function)
                return task_function
        except Exception as e:
            from nexora_tasks.logging import logger
            logger.warning(
                "task_function.lazy_load_failed",
                task_id=task_def.task_id,
                version=task_def.version,
                error=str(e),
                exc_info=True,
            )
    
    return None

