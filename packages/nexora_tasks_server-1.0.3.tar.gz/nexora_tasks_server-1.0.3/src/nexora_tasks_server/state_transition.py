"""Thread state-transition helper (M-13 / C-10 / Z-1).

Centralises the *six* near-identical state-transition ladders that
``ExecutionEngine._execute_via_worker`` and ``_execute_in_process`` used to
inline (running, succeeded, failed, timeout, worker-crashed, in-process
failed). Each path:

1. validates the transition,
2. mutates the in-memory ``Thread`` (state / finished_at / error),
3. persists to the database,
4. updates the OTel state-gauge / error counters,
5. records execution duration,
6. emits a structured log entry,
7. publishes the matching webhook event.

The pure ``StateTransition.apply()`` contract is exposed separately so it
can be unit-tested in isolation (see ``tests/unit/test_state_transition.py``)
and used by both the worker and in-process execution paths. The
``apply_terminal_transition()`` coroutine wraps the whole side-effect
ladder so callers cannot accidentally drift them apart again.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, FrozenSet, Optional

from nexora_tasks.logging import logger
from nexora_tasks.models.thread import Thread
from nexora_tasks.models.thread_error import ThreadError
from nexora_tasks.thread_state import ThreadState
from nexora_tasks_server.observability.metrics import (
    thread_errors_total,
    thread_execution_duration,
)
from nexora_tasks_server.utils.metrics_helpers import update_thread_state_gauge

if TYPE_CHECKING:  # pragma: no cover — typing only
    from nexora_tasks_server.framework import NexoraTasks


class InvalidStateTransition(ValueError):
    """Raised when ``StateTransition.validate`` rejects a (from, to) pair."""


# ---------------------------------------------------------------------------
# Transition table
# ---------------------------------------------------------------------------
#
# The thread lifecycle is::
#
#                    create_thread()
#                          │
#                          ▼
#                       QUEUED ───────────────► STOPPED
#                          │                      ▲
#                          ▼                      │
#                       RUNNING ─────────────────┤
#                       │  │  │ │                 │
#       SUCCEEDED ◄─────┘  │  │ └──► EXPIRED      │
#                          │  │                   │
#                  FAILED ◄┘  └──► TIMEOUT────────┘
#                          │
#                       PAUSED ◄──► RUNNING
#
# Terminal states (no out-edges from the engine's perspective):
#   SUCCEEDED, FAILED, TIMEOUT, EXPIRED, STOPPED.
#
# This table is the *authoritative* source of truth for transitions that
# the execution engine drives. Recovery / admin code may (intentionally)
# step outside it (e.g. requeuing a STOPPED thread from the API): such
# operators are out of scope here and don't go through ``StateTransition``.

_VALID_TRANSITIONS: Dict[ThreadState, FrozenSet[ThreadState]] = {
    ThreadState.QUEUED: frozenset({
        ThreadState.RUNNING,
        ThreadState.STOPPED,
        ThreadState.EXPIRED,
        ThreadState.FAILED,
    }),
    ThreadState.RUNNING: frozenset({
        ThreadState.SUCCEEDED,
        ThreadState.FAILED,
        ThreadState.TIMEOUT,
        ThreadState.STOPPED,
        ThreadState.PAUSED,
    }),
    ThreadState.PAUSED: frozenset({
        ThreadState.RUNNING,
        ThreadState.STOPPED,
        ThreadState.FAILED,
    }),
    # Terminal states — engine never transitions out of these.
    ThreadState.SUCCEEDED: frozenset(),
    ThreadState.FAILED: frozenset(),
    ThreadState.TIMEOUT: frozenset(),
    ThreadState.EXPIRED: frozenset(),
    ThreadState.STOPPED: frozenset(),
}


_TERMINAL_STATES: FrozenSet[ThreadState] = frozenset({
    ThreadState.SUCCEEDED,
    ThreadState.FAILED,
    ThreadState.TIMEOUT,
    ThreadState.EXPIRED,
    ThreadState.STOPPED,
})


# Mapping from terminal state → webhook event type. Centralised so worker
# and in-process paths emit identical event names.
_EVENT_TYPE_FOR_STATE: Dict[ThreadState, str] = {
    ThreadState.RUNNING: "thread.running",
    ThreadState.SUCCEEDED: "thread.succeeded",
    ThreadState.FAILED: "thread.failed",
    ThreadState.TIMEOUT: "thread.timeout",
    ThreadState.STOPPED: "thread.stopped",
    ThreadState.EXPIRED: "thread.expired",
    ThreadState.PAUSED: "thread.paused",
}


def _coerce_state(state: Any) -> ThreadState:
    """Coerce a raw value (string / enum) into a ``ThreadState``.

    ``Thread.state`` is declared with ``use_enum_values=True`` so the
    in-memory representation is a *string* after Pydantic validation. The
    transition helper deals exclusively in enum members internally.
    """
    if isinstance(state, ThreadState):
        return state
    return ThreadState(state)


@dataclass(frozen=True)
class StateTransition:
    """Description of a single thread state transition.

    Pure value object — does not touch the database, metrics, or events.
    Use ``apply()`` to mutate a ``Thread`` once and ``validate()`` to
    cheaply check legality without mutating anything.
    """

    from_state: ThreadState
    to_state: ThreadState
    error: Optional[ThreadError] = None
    finished_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Pure helpers
    # ------------------------------------------------------------------

    @staticmethod
    def is_terminal(state: ThreadState | str) -> bool:
        """Return ``True`` if ``state`` is a terminal lifecycle state."""
        return _coerce_state(state) in _TERMINAL_STATES

    @staticmethod
    def event_type_for(state: ThreadState | str) -> Optional[str]:
        """Return the webhook event type for a target ``state`` (or ``None``)."""
        return _EVENT_TYPE_FOR_STATE.get(_coerce_state(state))

    @classmethod
    def validate(cls, from_state: ThreadState | str, to_state: ThreadState | str) -> None:
        """Raise ``InvalidStateTransition`` if the transition is not allowed.

        Always allows the no-op ``X → X`` transition (the engine occasionally
        re-asserts the same state after a stop-race check); apart from that
        the transition must appear in ``_VALID_TRANSITIONS``.
        """
        src = _coerce_state(from_state)
        dst = _coerce_state(to_state)
        if src == dst:
            return
        allowed = _VALID_TRANSITIONS.get(src, frozenset())
        if dst not in allowed:
            raise InvalidStateTransition(
                f"Invalid thread state transition: {src.value} -> {dst.value}"
            )

    @classmethod
    def apply(
        cls,
        thread: Thread,
        to_state: ThreadState | str,
        *,
        error: Optional[ThreadError] = None,
        finished_at: Optional[datetime] = None,
    ) -> "StateTransition":
        """Mutate ``thread`` in place to ``to_state`` and return the descriptor.

        Validates the transition first. If the target is a terminal state
        and ``finished_at`` is omitted the current UTC time is stamped.
        Sets ``thread.error`` only when ``error`` is provided.
        """
        dst = _coerce_state(to_state)
        src = _coerce_state(thread.state)

        cls.validate(src, dst)

        if dst in _TERMINAL_STATES and finished_at is None:
            finished_at = datetime.now(timezone.utc)

        thread.state = dst
        if finished_at is not None:
            thread.finished_at = finished_at
        if error is not None:
            thread.error = error

        return cls(
            from_state=src,
            to_state=dst,
            error=error,
            finished_at=finished_at,
        )


# ---------------------------------------------------------------------------
# Side-effect ladder
# ---------------------------------------------------------------------------


@dataclass
class TransitionContext:
    """Inputs the side-effect ladder needs around a transition.

    ``execution_mode`` is included in the structured log line only when set.
    The worker path passes ``"worker"`` to preserve the existing log shape;
    the in-process path leaves it as ``None`` so the key is omitted (matching
    the legacy code).
    """

    framework: "NexoraTasks"
    task_id: str = "unknown"
    execution_mode: Optional[str] = None
    extra_log_fields: Dict[str, Any] = field(default_factory=dict)


async def _persist_thread(framework: "NexoraTasks", thread: Thread) -> None:
    """Persist a thread, swallowing failures with a structured log line.

    DB update failures must not break execution flow — the original code
    has the same behaviour inline; we preserve it here.
    """
    try:
        await framework.database.update_thread(thread)
    except Exception:  # pragma: no cover — exercised via integration tests
        logger.exception(
            "thread.execution.db_update_failed",
            thread_id=thread.id,
        )


async def _publish_lifecycle_event(
    framework: "NexoraTasks",
    thread: Thread,
    event_type: str,
    log_event: str,
) -> None:
    """Publish a webhook event, swallowing failures.

    Matches the original inline blocks: each transition's webhook publish
    was wrapped in its own try/except in ``_execute_via_worker`` /
    ``_execute_in_process``. Centralising it removes 6× duplication and
    guarantees identical drop policy across paths.
    """
    publisher = getattr(framework, "event_publisher", None)
    if publisher is None:
        return
    try:
        await publisher.publish(
            event_type=event_type,
            thread_id=thread.id,
            thread=thread,
            metadata=thread.metadata,
        )
    except Exception:
        logger.exception(log_event, thread_id=thread.id)


async def apply_terminal_transition(
    thread: Thread,
    to_state: ThreadState,
    ctx: TransitionContext,
    *,
    error: Optional[ThreadError] = None,
    error_type_label: Optional[str] = None,
    log_event_override: Optional[str] = None,
    log_extra: Optional[Dict[str, Any]] = None,
    event_type_override: Optional[str] = None,
) -> StateTransition:
    """Apply a terminal transition and run its full side-effect ladder.

    Ladder (in order):

    1. ``StateTransition.apply`` — mutate state / finished_at / error.
    2. Persist thread to DB.
    3. ``update_thread_state_gauge``.
    4. ``thread_errors_total`` if the target is FAILED or TIMEOUT.
    5. ``thread_execution_duration`` histogram.
    6. Structured log line.
    7. Lifecycle webhook event.

    Parameters
    ----------
    error_type_label:
        Label written into ``thread_errors_total`` when the target is
        FAILED/TIMEOUT. Defaults to ``error.exception_type`` then
        ``"Unknown"``.
    log_event_override:
        Override the default log event name (``thread.execution.completed``
        for SUCCEEDED / ``thread.execution.failed`` otherwise). The worker
        WorkerManager-level error path uses ``thread.execution.worker_error``.
    log_extra:
        Extra structured-log key/values appended after the canonical fields.
    event_type_override:
        Override the webhook event type — used for the worker-crash path
        which fires ``thread.failed`` even though it is an outer exception
        rather than an in-band failed status.
    """
    transition = StateTransition.apply(thread, to_state, error=error)

    await _persist_thread(ctx.framework, thread)

    update_thread_state_gauge(
        transition.from_state, transition.to_state, task_id=ctx.task_id,
    )

    if to_state in (ThreadState.FAILED, ThreadState.TIMEOUT):
        if error_type_label is not None:
            error_type = error_type_label
        elif error is not None and getattr(error, "exception_type", None):
            error_type = error.exception_type
        else:
            error_type = "Unknown"
        thread_errors_total.add(1, {"task_id": ctx.task_id, "error_type": error_type})

    if thread.started_at and thread.finished_at:
        duration = (thread.finished_at - thread.started_at).total_seconds()
        thread_execution_duration.record(duration, {"task_id": ctx.task_id})
    else:
        duration = None

    state_value = transition.to_state.value
    if log_event_override is not None:
        log_event = log_event_override
    elif to_state == ThreadState.SUCCEEDED:
        log_event = "thread.execution.completed"
    else:
        _err_msg = (log_extra or {}).get("error_message") or (
            error.message if error else ""
        )
        log_event = (
            f"thread.execution.failed: {_err_msg}"
            if _err_msg
            else "thread.execution.failed"
        )

    log_kwargs: Dict[str, Any] = {
        "thread_id": thread.id,
        "state": state_value,
    }
    if ctx.execution_mode is not None:
        log_kwargs["execution_mode"] = ctx.execution_mode
    if duration is not None:
        log_kwargs["duration_seconds"] = duration
    if log_extra:
        log_kwargs.update(log_extra)
    log_kwargs.update(ctx.extra_log_fields)

    if to_state == ThreadState.SUCCEEDED:
        logger.info(log_event, **log_kwargs)
    else:
        logger.error(log_event, **log_kwargs)

    event_type = event_type_override or StateTransition.event_type_for(to_state)
    if event_type is not None:
        await _publish_lifecycle_event(
            ctx.framework,
            thread,
            event_type=event_type,
            log_event=f"thread.execution.{to_state.value}_event_failed",
        )

    return transition
