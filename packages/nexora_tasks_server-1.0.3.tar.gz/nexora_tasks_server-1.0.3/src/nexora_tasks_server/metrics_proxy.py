"""OTel metric instruments for the proxy."""

from opentelemetry import metrics

_meter = metrics.get_meter("nexora_tasks_proxy")

proxy_requests_total = _meter.create_counter(
    "nexora_tasks.proxy.requests.total",
    unit="1",
    description="Proxied requests (attributes: server_id, http.method, http.status_code).",
)

proxy_request_latency = _meter.create_histogram(
    "nexora_tasks.proxy.request.latency",
    unit="s",
    description="Proxied request latency per upstream server (attributes: server_id).",
)

proxy_upstream_errors_total = _meter.create_counter(
    "nexora_tasks.proxy.upstream.errors.total",
    unit="1",
    description="Upstream proxy errors (attributes: server_id, reason).",
)

proxy_tasktype_requests_total = _meter.create_counter(
    "nexora_tasks.proxy.tasktype.requests.total",
    unit="1",
    description="Proxied requests per task type (attributes: task_type, server_id, http.status_code).",
)

proxy_server_health_checks_total = _meter.create_counter(
    "nexora_tasks.proxy.server.health_checks.total",
    unit="1",
    description="Proxy server health checks (attributes: server_id, status).",
)
