"""Load balancing strategies for selecting target servers."""

import random
import threading
from abc import ABC, abstractmethod
from contextlib import asynccontextmanager
from typing import AsyncIterator, Dict, List, Optional

from nexora_tasks_server.proxy_registry import ServerEntry, TaskTypeGroup


class LoadBalancer(ABC):
    """Abstract base class for load balancing strategies."""

    @abstractmethod
    def select_server(
        self,
        servers: List[ServerEntry],
        task_type: str,
        sticky_key: Optional[str] = None,
    ) -> Optional[ServerEntry]:
        """Select a server from the list.

        Args:
            servers: List of available servers
            task_type: Task type identifier
            sticky_key: Optional sticky routing key (for sticky strategies)

        Returns:
            Selected ServerEntry or None if no servers available
        """
        pass


class RoundRobinBalancer(LoadBalancer):
    """Round-robin load balancing strategy."""

    def __init__(self) -> None:
        """Initialize round-robin balancer."""
        self._counters: Dict[str, int] = {}  # task_type -> counter
        # M-20: serialize the read-modify-write of the counter so concurrent
        # callers (asyncio tasks plus thread-pool workers) cannot race and
        # observe the same counter value, which would otherwise route both to
        # the same server and defeat round-robin distribution.
        self._lock = threading.Lock()

    def select_server(
        self,
        servers: List[ServerEntry],
        task_type: str,
        sticky_key: Optional[str] = None,
    ) -> Optional[ServerEntry]:
        """Select next server in round-robin order.

        Args:
            servers: List of available servers
            task_type: Task type identifier
            sticky_key: Ignored for round-robin

        Returns:
            Selected ServerEntry or None if no servers available
        """
        # Filter to healthy servers (draining servers have status != "healthy")
        available = [s for s in servers if s.status == "healthy"]
        if not available:
            return None

        # Atomic RMW: read counter, pick slot, write back under one lock so the
        # whole select+increment is observed as a single step by other callers.
        with self._lock:
            counter = self._counters.get(task_type, 0)
            selected = available[counter % len(available)]
            self._counters[task_type] = counter + 1

        return selected


class LeastConnectionsBalancer(LoadBalancer):
    """Least-connections load balancing strategy."""

    def __init__(self) -> None:
        """Initialize least-connections balancer."""
        self._active_connections: Dict[str, int] = {}  # server_id -> active connections

    def select_server(
        self,
        servers: List[ServerEntry],
        task_type: str,
        sticky_key: Optional[str] = None,
    ) -> Optional[ServerEntry]:
        """Select server with fewest active connections.

        Args:
            servers: List of available servers
            task_type: Task type identifier
            sticky_key: Ignored for least-connections

        Returns:
            Selected ServerEntry or None if no servers available
        """
        # Filter to healthy servers (draining servers have status != "healthy")
        available = [s for s in servers if s.status == "healthy"]
        if not available:
            return None

        # Respect max_concurrent if set
        candidates = []
        for server in available:
            active = self._active_connections.get(server.id, 0)
            if server.max_concurrent is None or active < server.max_concurrent:
                candidates.append((server, active))
        
        if not candidates:
            return None
        
        # Select server with minimum active connections
        selected_server, _ = min(candidates, key=lambda x: x[1])
        return selected_server

    def increment_connections(self, server_id: str) -> None:
        """Increment active connection count for a server.

        Args:
            server_id: Server identifier
        """
        self._active_connections[server_id] = self._active_connections.get(server_id, 0) + 1

    def decrement_connections(self, server_id: str) -> None:
        """Decrement active connection count for a server.

        Args:
            server_id: Server identifier
        """
        current = self._active_connections.get(server_id, 0)
        if current > 0:
            self._active_connections[server_id] = current - 1

    @asynccontextmanager
    async def acquire_slot(self, server_id: str) -> AsyncIterator[None]:
        """Reserve an in-flight slot for the duration of a request.

        M-18: callers that manually paired ``increment_connections`` /
        ``decrement_connections`` were prone to leak a slot whenever the body
        raised before the matching decrement ran. The counter then drifted up
        forever, eventually pushing the server above ``max_concurrent`` and
        out of the candidate pool. This context manager guarantees the
        decrement happens via ``finally`` regardless of exit reason, so the
        counter only ever reflects truly in-flight requests.

        Usage::

            async with lb.acquire_slot(server.id):
                await issue_request(server)

        Args:
            server_id: Server identifier whose in-flight counter to track.
        """
        self.increment_connections(server_id)
        try:
            yield
        finally:
            self.decrement_connections(server_id)


class RandomBalancer(LoadBalancer):
    """Random load balancing strategy."""

    def select_server(
        self,
        servers: List[ServerEntry],
        task_type: str,
        sticky_key: Optional[str] = None,
    ) -> Optional[ServerEntry]:
        """Select a random server.

        Args:
            servers: List of available servers
            task_type: Task type identifier
            sticky_key: Ignored for random

        Returns:
            Selected ServerEntry or None if no servers available
        """
        # Filter to healthy servers (draining servers have status != "healthy")
        available = [s for s in servers if s.status == "healthy"]
        if not available:
            return None

        return random.choice(available)


class StickyBalancer(LoadBalancer):
    """Sticky load balancing strategy using a routing key."""

    def __init__(self) -> None:
        """Initialize sticky balancer."""
        self._sticky_map: Dict[str, str] = {}  # sticky_key -> server_id

    def select_server(
        self,
        servers: List[ServerEntry],
        task_type: str,
        sticky_key: Optional[str] = None,
    ) -> Optional[ServerEntry]:
        """Select server based on sticky key.

        Args:
            servers: List of available servers
            task_type: Task type identifier
            sticky_key: Sticky routing key (e.g., client ID)

        Returns:
            Selected ServerEntry or None if no servers available
        """
        # Filter to healthy servers (draining servers have status != "healthy")
        available = [s for s in servers if s.status == "healthy"]
        if not available:
            return None

        # If sticky key provided, try to use previously assigned server
        if sticky_key:
            assigned_id = self._sticky_map.get(sticky_key)
            if assigned_id:
                assigned = next((s for s in available if s.id == assigned_id), None)
                if assigned:
                    return assigned
        
        # No sticky assignment or assigned server unavailable - select new one.
        # bug-23: ``available[0]`` always picked the first healthy server,
        # so cold-start traffic and rebalancing storms after a server
        # restart all stampeded onto the same node. Pick deterministically
        # but uniformly via ``hash(sticky_key)`` when a key is present, and
        # fall through to the first server only when there is no key at
        # all (anonymous traffic). The map write below records the choice
        # so subsequent calls with the same key get the same server.
        if sticky_key:
            selected = available[hash(sticky_key) % len(available)]
        else:
            selected = available[0]

        # Store sticky mapping
        if sticky_key:
            self._sticky_map[sticky_key] = selected.id

        return selected


class LoadBalancerFactory:
    """Factory for creating load balancer instances."""

    @staticmethod
    def create(strategy: str) -> LoadBalancer:
        """Create a load balancer instance.

        Args:
            strategy: Strategy name (round-robin, least-connections, random, sticky)

        Returns:
            LoadBalancer instance

        Raises:
            ValueError: If strategy is not recognized
        """
        strategies = {
            "round-robin": RoundRobinBalancer,
            "least-connections": LeastConnectionsBalancer,
            "random": RandomBalancer,
            "sticky": StickyBalancer,
        }
        
        balancer_class = strategies.get(strategy)
        if not balancer_class:
            raise ValueError(f"Unknown load balancing strategy: {strategy}")
        
        return balancer_class()

