"""FastAPI error response helpers for the Nexora Tasks Server.

Re-exports all error constants from the SDK and adds FastAPI-specific response builders.
"""

from typing import Any, Optional

from fastapi import Request, status
from fastapi.responses import JSONResponse

# Re-export ALL constants from SDK
from nexora_tasks.errors import *  # noqa: F401,F403
from nexora_tasks.errors import problem_json_dict


def problem_json_response(
    status_code: int,
    title: str,
    detail: Optional[str] = None,
    type: Optional[str] = None,
    instance: Optional[str] = None,
    **extensions: Any,
) -> JSONResponse:
    """Create a Problem+JSON response (RFC 7807).

    Args:
        status_code: HTTP status code
        title: Short, human-readable summary of the problem type
        detail: Human-readable explanation specific to this occurrence
        type: URI reference that identifies the problem type
        instance: URI reference that identifies the specific occurrence
        **extensions: Additional problem members

    Returns:
        JSONResponse with Problem+JSON format
    """
    problem = problem_json_dict(
        status_code=status_code,
        title=title,
        detail=detail,
        type=type,
        instance=instance,
        **extensions,
    )

    return JSONResponse(status_code=status_code, content=problem)


async def problem_json_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Exception handler that returns Problem+JSON format."""
    status_code = getattr(exc, "status_code", status.HTTP_500_INTERNAL_SERVER_ERROR)
    title = getattr(exc, "title", "Internal Server Error")
    detail = str(exc) if exc else None

    instance = str(request.url) if hasattr(request, "url") else request.path if hasattr(request, "path") else "/unknown"

    return problem_json_response(
        status_code=status_code,
        title=title,
        detail=detail,
        instance=instance,
    )
