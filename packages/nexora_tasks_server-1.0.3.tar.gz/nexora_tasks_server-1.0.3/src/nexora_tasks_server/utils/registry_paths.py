"""Normalize paths loaded from persisted task_registry.json."""

from pathlib import Path
from typing import Optional


def _strip_relative_noise(s: str) -> str:
    t = s.strip()
    while t.startswith("./"):
        t = t[2:]
    return t


def resolve_registry_stored_path(data_dir: Optional[Path], stored: Optional[str]) -> Optional[str]:
    """Resolve a path string from the registry against the server data directory.

    Registry files may contain relative paths. Some older entries prefix segments with
    ``data/`` (e.g. ``data/tasks/{id}/{ver}``) even though ``data_dir`` is already the
    runtime data root (e.g. ``/data``). Joining would produce ``/data/data/tasks/...``.
    When only the layout without the extra ``data/`` segment exists, that path is used.
    """
    if stored is None or data_dir is None:
        return stored
    s = _strip_relative_noise(stored)
    if not s:
        return stored
    if s.startswith("http://") or s.startswith("https://"):
        return stored
    raw = Path(s)
    if raw.is_absolute():
        return str(raw.resolve())
    joined = (data_dir / raw).resolve()
    if raw.parts and raw.parts[0] == "data" and len(raw.parts) > 1:
        stripped = (data_dir / Path(*raw.parts[1:])).resolve()
        if stripped.exists() and not joined.exists():
            return str(stripped)
        if joined.exists():
            return str(joined)
        return str(stripped)
    return str(joined)


def resolve_path_for_deployed_artifact(data_root: Path, stored: str) -> Path:
    """Resolve a filesystem path for lazy-loading task code or metadata.

    Tries, in order: path as given if it exists; registry rules under ``data_root``;
    ``data_root / relative`` for non-absolute stored paths.
    """
    s = _strip_relative_noise(stored)
    direct = Path(s)
    if direct.exists():
        return direct.resolve()
    via_registry = resolve_registry_stored_path(data_root, s)
    if via_registry:
        p = Path(via_registry)
        if p.exists():
            return p.resolve()
    rel = Path(s)
    if not rel.is_absolute():
        candidate = (data_root / rel).resolve()
        if candidate.exists():
            return candidate
    return Path(via_registry) if via_registry else direct
