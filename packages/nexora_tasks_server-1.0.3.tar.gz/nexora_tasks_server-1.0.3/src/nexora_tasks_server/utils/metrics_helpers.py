"""Helper utilities for thread state metric updates (OTel)."""

from nexora_tasks.logging import logger
from nexora_tasks.thread_state import ThreadState
from nexora_tasks_server.observability.metrics import (
    threads_current,
    threads_total,
)


def update_thread_state_gauge(
    previous_state: ThreadState | str,
    new_state: ThreadState | str,
    task_id: str = "unknown",
) -> None:
    """Update threads.current up-down counter when a thread state transitions."""
    try:
        prev = previous_state.value if hasattr(previous_state, "value") else str(previous_state)
        new = new_state.value if hasattr(new_state, "value") else str(new_state)
        if prev == new:
            return
        threads_current.add(-1, {"state": prev, "task_id": task_id})
        threads_current.add(1, {"state": new, "task_id": task_id})
    except Exception as e:  # pragma: no cover — metric updates must not crash callers
        logger.exception("metrics.update_thread_state_gauge_failed", error=str(e))


async def restore_thread_metrics_from_db(database) -> None:
    """Restore thread-state up-down counter values from the database on startup.

    Sums per (state, task_id) and increments the up-down counter by that count
    so the post-restart point matches the pre-restart point.
    """
    try:
        try:
            all_threads = await database.query_threads({})
        except Exception:
            logger.warning(
                "metrics.restore.could_not_query_all_threads",
                error="query_threads may require filters",
            )
            return

        state_task_counts: dict[tuple[str, str], int] = {}
        total = 0
        for thread in all_threads:
            state = thread.state.value if hasattr(thread.state, "value") else str(thread.state)
            task_id = (thread.metadata or {}).get("task_id", "unknown") \
                if hasattr(thread, "metadata") else "unknown"
            state_task_counts[(state, task_id)] = state_task_counts.get((state, task_id), 0) + 1
            total += 1

        for (state, task_id), count in state_task_counts.items():
            threads_current.add(count, {"state": state, "task_id": task_id})
            threads_total.add(count, {"state": state, "task_id": task_id})

        logger.info(
            "metrics.restored_from_db",
            total_threads=total,
            state_counts={f"{s}:{t}": c for (s, t), c in state_task_counts.items()},
        )
    except Exception as e:
        logger.exception("metrics.restore.failed", error=str(e))
