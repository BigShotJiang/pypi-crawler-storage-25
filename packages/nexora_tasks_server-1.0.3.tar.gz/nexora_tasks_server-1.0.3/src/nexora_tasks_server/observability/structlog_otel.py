"""Structlog → OpenTelemetry log bridge.

A structlog processor that reads the currently-active OTel span context and
emits an OTel ``LogRecord`` for every structlog event. The event dict is
returned unchanged so any subsequent renderer (e.g. JSON-to-stdout) is
unaffected.

The processor is a no-op when no real ``LoggerProvider`` is registered
(``NoOpLoggerProvider`` is the global default until ``init_otel(...,
enable_logs=True)`` runs).

Attribute mapping
-----------------
- ``event`` is used as the OTel ``Body``.
- ``level`` is mapped to ``SeverityNumber``.
- The set of structlog correlation keys ``thread_id``, ``task_id``,
  ``exec_id``, ``request_id``, ``schedule_id``, ``run_id``, ``webhook_id``,
  ``delivery_id``, ``task_version`` is namespaced as
  ``nexora_tasks.<key>``.
- All other event-dict keys land in ``Attributes`` verbatim.
- ``trace_id``, ``span_id``, ``trace_flags`` come from the active span.
"""

from __future__ import annotations

import time
from typing import Any, Dict

from opentelemetry import trace
from opentelemetry._logs import (
    LogRecord,
    SeverityNumber,
    get_logger_provider,
)
from opentelemetry._logs import NoOpLoggerProvider


_LOGGER_NAME = "nexora_tasks.structlog"

_LEVEL_TO_SEVERITY: Dict[str, SeverityNumber] = {
    "debug": SeverityNumber.DEBUG,
    "info": SeverityNumber.INFO,
    "warning": SeverityNumber.WARN,
    "warn": SeverityNumber.WARN,
    "error": SeverityNumber.ERROR,
    "critical": SeverityNumber.FATAL,
}


def _get_provider_or_none():
    provider = get_logger_provider()
    if provider is None or isinstance(provider, NoOpLoggerProvider):
        return None
    return provider


def _build_attributes(event_dict: Dict[str, Any]) -> Dict[str, Any]:
    attributes: Dict[str, Any] = {}
    for key, value in event_dict.items():
        if key in ("event", "level", "timestamp", "@timestamp"):
            continue
        attributes[key] = value
    return attributes


def otel_bridge(_logger, _method_name, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Structlog processor: emit one OTel ``LogRecord`` per event."""
    provider = _get_provider_or_none()
    if provider is None:
        return event_dict

    span = trace.get_current_span()
    ctx = span.get_span_context() if span is not None else None
    trace_id = ctx.trace_id if ctx and ctx.is_valid else 0
    span_id = ctx.span_id if ctx and ctx.is_valid else 0
    trace_flags = ctx.trace_flags if ctx and ctx.is_valid else 0

    level = str(event_dict.get("level", "info")).lower()
    severity = _LEVEL_TO_SEVERITY.get(level, SeverityNumber.INFO)
    body = event_dict.get("event", "")

    now_ns = time.time_ns()
    record = LogRecord(
        timestamp=now_ns,
        observed_timestamp=now_ns,
        trace_id=trace_id,
        span_id=span_id,
        trace_flags=trace_flags,
        severity_text=level.upper(),
        severity_number=severity,
        body=body,
        attributes=_build_attributes(event_dict),
    )

    logger = provider.get_logger(_LOGGER_NAME)
    logger.emit(record)
    return event_dict
