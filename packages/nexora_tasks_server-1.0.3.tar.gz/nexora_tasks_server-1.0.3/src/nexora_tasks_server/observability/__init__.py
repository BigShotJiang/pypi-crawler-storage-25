"""Observability package — OTel bootstrap and helpers."""

from .otel import init_otel

__all__ = ["init_otel"]
