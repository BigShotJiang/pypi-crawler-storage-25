"""OpenTelemetry bootstrap for nexora-tasks services.

Single public entry point: ``init_otel``. Reads standard OTEL_* env vars,
builds a Resource, configures an OTLP/gRPC span exporter behind a
BatchSpanProcessor, and registers the global tracer provider. Optionally
attaches FastAPI middleware. Idempotent. No-ops if OTEL_SDK_DISABLED=true.
"""

from __future__ import annotations

import os
from typing import Any, Optional

from opentelemetry.context import Context
from opentelemetry.sdk.trace import Span, SpanProcessor

_initialized: bool = False


class _ThreadIdSpanProcessor(SpanProcessor):
    """Stamp ``thread.id`` + ``task.id`` on every span from structlog contextvars.

    Group J spec requires ``resource.attributes.thread.id`` for trace
    correlation. We stamp the value as a span attribute here; the collector's
    ``groupbyattrs`` processor lifts it to the ResourceSpans level.
    """

    def on_start(self, span: Span, parent_context: Optional[Context] = None) -> None:
        try:
            from structlog.contextvars import get_contextvars

            ctx = get_contextvars()
            tid = ctx.get("thread_id")
            if tid:
                span.set_attribute("thread.id", str(tid))
            task_id = ctx.get("task_id")
            if task_id:
                span.set_attribute("task.id", str(task_id))
        except Exception:
            pass

    def on_end(self, span) -> None:  # noqa: D401
        return

    def shutdown(self) -> None:
        return

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


def init_otel(
    service_name: str,
    service_namespace: str = "nexora-tasks",
    instrument_fastapi_app: Optional[Any] = None,
    enable_logs: bool = True,
    enable_metrics: bool = True,
) -> None:
    """Initialize OpenTelemetry traces for this process.

    Args:
        service_name: Resource ``service.name`` (e.g. ``nexora-tasks-server``,
            ``nexora-tasks-worker``).
        service_namespace: Resource ``service.namespace`` shared across all
            modules in the org. Defaults to ``nexora-tasks``.
        instrument_fastapi_app: Optional FastAPI/Starlette ``app`` instance.
            When provided, the OTel FastAPI middleware is attached so HTTP
            requests become root spans automatically.
        enable_logs: When ``True`` and ``LOG_DESTINATION`` is ``otlp`` or
            ``both``, registers an OTLP ``LoggerProvider`` for structured logs.
        enable_metrics: When ``True``, registers an OTLP ``MeterProvider`` with
            a ``PeriodicExportingMetricReader``.

    Behavior:
        * No-op if ``OTEL_SDK_DISABLED=true``.
        * Idempotent — repeated calls return immediately.
        * Failures during init are logged and swallowed; the global no-op
          provider remains in place.
    """
    global _initialized
    if _initialized:
        if instrument_fastapi_app is not None:
            _try_instrument_fastapi(instrument_fastapi_app)
        return

    if os.getenv("OTEL_SDK_DISABLED", "").lower() in ("true", "1"):
        _initialized = True
        return

    try:
        from opentelemetry import trace
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
            OTLPSpanExporter,
        )
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor

        resource_attrs = {
            "service.name": service_name,
            "service.namespace": service_namespace,
            "service.version": os.getenv("SERVICE_VERSION", "0.0.0"),
            "deployment.environment": os.getenv(
                "DEPLOYMENT_ENV", "development"
            ),
        }
        resource = Resource.create(resource_attrs)
        provider = TracerProvider(resource=resource)

        # MUST be registered before the exporter processor so attributes are
        # set on every span before BatchSpanProcessor reads them.
        provider.add_span_processor(_ThreadIdSpanProcessor())

        endpoint = os.getenv(
            "OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317"
        )
        exporter = OTLPSpanExporter(endpoint=endpoint, insecure=True)
        provider.add_span_processor(BatchSpanProcessor(exporter))

        trace.set_tracer_provider(provider)

        # ── Logs pipeline ──
        log_destination = os.getenv("LOG_DESTINATION", "stdout").lower()
        if (
            enable_logs
            and log_destination in ("otlp", "both")
            and os.getenv("OTEL_SDK_DISABLED", "").lower() != "true"
        ):
            from opentelemetry._logs import set_logger_provider
            from opentelemetry.sdk._logs import LoggerProvider
            from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
            from opentelemetry.exporter.otlp.proto.grpc._log_exporter import (
                OTLPLogExporter,
            )

            log_provider = LoggerProvider(resource=resource)
            log_provider.add_log_record_processor(
                BatchLogRecordProcessor(OTLPLogExporter())
            )
            set_logger_provider(log_provider)

        if enable_metrics:
            _init_metrics(resource)

        _try_instrument_httpx()
        _try_instrument_elasticsearch()
        if instrument_fastapi_app is not None:
            _try_instrument_fastapi(instrument_fastapi_app)

        _initialized = True
    except Exception as exc:  # pragma: no cover - defensive
        try:
            from nexora_tasks.logging import logger

            logger.warning("otel.init_failed", error=str(exc))
        except Exception:
            pass
        _initialized = True  # don't keep trying on every call


def _init_metrics(resource: Any) -> None:
    """Register a global MeterProvider exporting OTLP/gRPC to the Collector."""
    from opentelemetry import metrics as otel_metrics
    from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (
        OTLPMetricExporter,
    )
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader

    endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")
    interval_ms_raw = os.getenv("OTEL_METRIC_EXPORT_INTERVAL", "60000")
    try:
        interval_ms = int(interval_ms_raw)
    except ValueError:
        interval_ms = 60000

    exporter = OTLPMetricExporter(endpoint=endpoint, insecure=True)
    periodic_reader = PeriodicExportingMetricReader(
        exporter=exporter,
        export_interval_millis=interval_ms,
    )

    # The admin reader MUST be passed into the MeterProvider constructor —
    # appending to ``provider._sdk_config.metric_readers`` post-construction
    # leaves the reader unregistered, and ``get_metrics_data()`` then raises
    # "Cannot call collect on a MetricReader until it is registered on a
    # MeterProvider", returning ``None`` and producing empty admin payloads.
    from nexora_tasks_server.observability.metrics import (
        get_or_create_admin_reader,
    )
    admin_reader = get_or_create_admin_reader()

    provider = MeterProvider(
        resource=resource,
        metric_readers=[periodic_reader, admin_reader],
    )
    otel_metrics.set_meter_provider(provider)

    # Warm up named counters so they appear in the Prometheus scrape from
    # the moment the server is healthy, before any real event has fired.
    from nexora_tasks_server.observability.metrics import warmup_counters
    try:
        warmup_counters()
    except Exception:
        pass


def _try_instrument_httpx() -> None:
    try:
        from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor

        HTTPXClientInstrumentor().instrument()
    except Exception:
        pass


def _try_instrument_elasticsearch() -> None:
    try:
        from opentelemetry.instrumentation.elasticsearch import (
            ElasticsearchInstrumentor,
        )

        ElasticsearchInstrumentor().instrument()
    except Exception:
        pass


def _fastapi_server_request_hook(span: Any, scope: dict) -> None:
    """Force a meaningful server-span name for OTel auto-instrumentation.

    FastAPI's instrumentation occasionally emits a server span with an empty
    ``name`` when the matched route is not yet attached to the ASGI scope at
    span-creation time. Group J trace correlation assertions rely on the
    server span carrying the HTTP method + path; fall back to those scope
    keys to guarantee a non-empty span name.
    """
    try:
        if span is None or not span.is_recording():
            return
        method = scope.get("method", "")
        route = scope.get("route", None)
        path = getattr(route, "path", None) or scope.get("path", "")
        if method and path:
            span.update_name(f"{method} {path}")
    except Exception:
        pass


def _try_instrument_fastapi(app: Any) -> None:
    try:
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

        FastAPIInstrumentor.instrument_app(
            app, server_request_hook=_fastapi_server_request_hook
        )
    except Exception:
        pass
