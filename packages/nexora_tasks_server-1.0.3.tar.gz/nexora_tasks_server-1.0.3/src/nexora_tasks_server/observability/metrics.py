"""OTel metric instrument definitions for nexora-tasks-server.

Every metric the server emits is defined exactly once in this module.
Call sites import the instrument and call ``add()`` (counters/up-down) or
``record()`` (histograms) with attributes.

Naming follows OTel conventions: dotted, namespaced under ``nexora_tasks.*``.
The Collector's Prometheus exporter translates ``.`` to ``_`` and prefixes the
configured namespace, so ``nexora_tasks.tasks.executions`` becomes
``nexora_tasks_nexora_tasks_tasks_executions`` on the scrape endpoint —
operators querying via Prometheus should consult the rename table in
``docs/server/observability.md``.
"""

from opentelemetry import metrics
from opentelemetry.sdk.metrics.export import InMemoryMetricReader

METER_NAME = "nexora_tasks_server"

_meter = metrics.get_meter(METER_NAME)

_reader: InMemoryMetricReader | None = None


def get_or_create_admin_reader() -> InMemoryMetricReader:
    """Return the singleton admin InMemoryMetricReader, creating it on first
    call. The caller is responsible for passing the returned reader into the
    ``MeterProvider`` constructor's ``metric_readers`` list — appending after
    construction is unsupported by the OTel SDK and silently disables the
    reader (``collect`` raises ``"Cannot call collect on a MetricReader until
    it is registered on a MeterProvider"``)."""
    global _reader
    if _reader is None:
        _reader = InMemoryMetricReader()
    return _reader


def get_admin_reader() -> InMemoryMetricReader | None:
    return _reader


def install_admin_reader() -> InMemoryMetricReader:
    """Backwards-compatible shim. Prefer ``get_or_create_admin_reader`` and
    pass the result into the ``MeterProvider`` constructor. This shim no
    longer mutates an existing provider — it just returns the singleton."""
    return get_or_create_admin_reader()

# ─── Thread execution ───────────────────────────────────────────
threads_total = _meter.create_counter(
    "nexora_tasks.threads.total",
    unit="1",
    description="Total number of threads created (attributes: state, task_id).",
)

thread_execution_duration = _meter.create_histogram(
    "nexora_tasks.thread.execution.duration",
    unit="s",
    description="Thread execution wall time (attributes: task_id).",
)

threads_current = _meter.create_up_down_counter(
    "nexora_tasks.threads.current",
    unit="1",
    description="Current number of threads in each state (attributes: state, task_id).",
)

thread_queue_duration = _meter.create_histogram(
    "nexora_tasks.thread.queue.duration",
    unit="s",
    description="Time a thread spent in QUEUED before execution started (attributes: task_id).",
)

thread_errors_total = _meter.create_counter(
    "nexora_tasks.thread.errors.total",
    unit="1",
    description="Thread execution errors (attributes: task_id, error_type).",
)

# ─── Workers ────────────────────────────────────────────────────
workers_active = _meter.create_up_down_counter(
    "nexora_tasks.workers.active",
    unit="1",
    description="Current number of active worker subprocesses.",
)

workers_idle = _meter.create_up_down_counter(
    "nexora_tasks.workers.idle",
    unit="1",
    description="Current number of idle workers (no pending executions).",
)

worker_startup_duration = _meter.create_histogram(
    "nexora_tasks.worker.startup.duration",
    unit="s",
    description="Time from worker spawn to ready signal (attributes: task_id).",
)

worker_restarts_total = _meter.create_counter(
    "nexora_tasks.worker.restarts.total",
    unit="1",
    description="Worker subprocess restarts (attributes: task_id).",
)

worker_pending_executions = _meter.create_up_down_counter(
    "nexora_tasks.worker.pending.executions",
    unit="1",
    description="Pending executions per worker (attributes: task_id).",
)

# ─── API requests ───────────────────────────────────────────────
api_requests_total = _meter.create_counter(
    "nexora_tasks.api.requests.total",
    unit="1",
    description="Total API requests (attributes: http.method, http.route, http.status_code).",
)

api_request_duration = _meter.create_histogram(
    "nexora_tasks.api.request.duration",
    unit="s",
    description="API request duration (attributes: http.method, http.route, http.status_code).",
)

# ─── Library / registry ─────────────────────────────────────────
library_initializations_total = _meter.create_counter(
    "nexora_tasks.library.initializations.total",
    unit="1",
    description="Total library initializations.",
)

task_function_registrations_total = _meter.create_counter(
    "nexora_tasks.task.function.registrations.total",
    unit="1",
    description="Total task function registrations (attributes: task_id).",
)

# ─── Artifacts ──────────────────────────────────────────────────
artifacts_created_total = _meter.create_counter(
    "nexora_tasks.artifacts.created.total",
    unit="1",
    description="Total artifacts created (attributes: kind).",
)

artifacts_deleted_total = _meter.create_counter(
    "nexora_tasks.artifacts.deleted.total",
    unit="1",
    description="Total artifacts deleted.",
)

artifacts_archived_total = _meter.create_counter(
    "nexora_tasks.artifacts.archived.total",
    unit="1",
    description="Total artifacts archived.",
)

# ─── File storage ───────────────────────────────────────────────
file_uploads_total = _meter.create_counter(
    "nexora_tasks.file.uploads.total",
    unit="1",
    description="Total file uploads (presigned URL requests + direct uploads).",
)

file_downloads_total = _meter.create_counter(
    "nexora_tasks.file.downloads.total",
    unit="1",
    description="Total file downloads.",
)

file_upload_duration = _meter.create_histogram(
    "nexora_tasks.file.upload.duration",
    unit="s",
    description="File upload duration in seconds.",
)

file_download_duration = _meter.create_histogram(
    "nexora_tasks.file.download.duration",
    unit="s",
    description="File download duration in seconds.",
)

# ─── Thread log buffer ──────────────────────────────────────────
thread_log_buffer_evictions_total = _meter.create_counter(
    "nexora_tasks.thread.log_buffer.evictions.total",
    unit="1",
    description="Per-thread log buffers evicted to respect global cap (attributes: reason).",
)

# ─── Schedules ──────────────────────────────────────────────────
schedule_runs_total = _meter.create_counter(
    "nexora_tasks.schedule.runs.total",
    unit="1",
    description="Total scheduled runs triggered (attributes: schedule_id, state).",
)

schedules_active = _meter.create_up_down_counter(
    "nexora_tasks.schedules.active",
    unit="1",
    description="Current number of active schedules.",
)

schedule_tick_errors_total = _meter.create_counter(
    "nexora_tasks.schedule.tick.errors.total",
    unit="1",
    description="Scheduler tick failures (attributes: schedule_id, reason).",
)

# ─── Webhooks ───────────────────────────────────────────────────
webhook_deliveries_total = _meter.create_counter(
    "nexora_tasks.webhook.deliveries.total",
    unit="1",
    description="Total webhook delivery attempts (attributes: webhook_id, status).",
)

webhook_delivery_duration = _meter.create_histogram(
    "nexora_tasks.webhook.delivery.duration",
    unit="s",
    description="Webhook delivery duration in seconds.",
)

# C-3: drop / DLQ accounting. Every silent drop must increment a counter
# so operators can alert on event loss. Distinguish queue saturation
# (publisher backpressure) from handler exceptions (delivery code blew
# up) so the symptom can be triaged without log scraping.
webhook_events_dropped_total = _meter.create_counter(
    "nexora_tasks.webhook.events.dropped.total",
    unit="1",
    description=(
        "Webhook events dropped without delivery (attributes: reason — "
        "'queue_full' = backpressure overflow exhausted DLQ, "
        "'handler_exception' = handler retries exhausted, "
        "'dlq_failure' = DLQ persistence itself failed)."
    ),
)

webhook_events_requeued_total = _meter.create_counter(
    "nexora_tasks.webhook.events.requeued.total",
    unit="1",
    description=(
        "Webhook events requeued after handler exception "
        "(attributes: attempt — 1, 2, 3...). Caps at MAX_HANDLER_RETRIES "
        "before a drop is recorded."
    ),
)

webhook_dlq_writes_total = _meter.create_counter(
    "nexora_tasks.webhook.dlq.writes.total",
    unit="1",
    description=(
        "Webhook events successfully recovered into the DLQ buffer "
        "after a publish-time QueueFull. Each increment means an event "
        "survived backpressure rather than being dropped."
    ),
)

webhook_dlq_size = _meter.create_up_down_counter(
    "nexora_tasks.webhook.dlq.size",
    unit="1",
    description=(
        "Current count of events held in the in-memory DLQ buffer. "
        "Sustained growth indicates the handler cannot keep up; alert "
        "if it approaches the configured DLQ capacity."
    ),
)

# ─── Database ───────────────────────────────────────────────────
db_operation_duration = _meter.create_histogram(
    "nexora_tasks.db.operation.duration",
    unit="s",
    description="Database operation duration (attributes: operation, resource).",
)

# ─── Metadata endpoint ──────────────────────────────────────────
metadata_requests_total = _meter.create_counter(
    "nexora_tasks.metadata.requests.total",
    unit="1",
    description="Total metadata endpoint requests (attributes: status).",
)

metadata_response_duration = _meter.create_histogram(
    "nexora_tasks.metadata.response.duration",
    unit="s",
    description="Metadata endpoint response duration in seconds.",
)


def warmup_counters() -> None:
    """Emit a zero increment on counters that operators/SLOs query by name.

    OTLP/Prom exporters only expose a counter once the SDK has seen at least
    one observation. Tasks that monitor by absolute counter names (J08 spec:
    ``nexora_tasks_worker_restarts_total``, ``nexora_tasks_schedule_runs_total``,
    ``nexora_tasks_webhook_deliveries_total``) need the series to exist
    immediately after startup so alert rules and scrape assertions don't
    flake before the first real event fires.

    Idempotent: each call adds 0, which leaves the counter monotonic and
    semantically unchanged.
    """
    worker_restarts_total.add(0, {"task_id": ""})
    schedule_runs_total.add(0, {"schedule_id": "", "state": "ok"})
    webhook_deliveries_total.add(0, {"webhook_id": "", "status": "success"})
