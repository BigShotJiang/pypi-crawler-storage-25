"""FastAPI lifespan handlers for the Nexora Tasks server (M-11).

Replaces the six legacy ``@app.on_event`` hooks (deprecated since
FastAPI 0.110) with a single ``@asynccontextmanager`` ``lifespan(app)``
factory. Each startup phase is split into a small, individually
testable coroutine so failures are isolated and ordered cleanly:

  startup:
    1. discover_tasks         — multi-task mode + zip discovery
    2. load_registry          — re-hydrate task registry from disk
    3. start_workers          — boot worker subprocesses (worker mode)
    4. load_schedules         — re-hydrate APScheduler + thread metrics
    5. recover_queued_threads — resume orphaned queued threads

  shutdown:
    - stop_all_workers        — drain + stop worker subprocesses

Each phase logs its own structured event and is best-effort: a single
failing phase MUST NOT prevent the server from starting (matches the
prior ``@app.on_event`` behaviour).
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, AsyncIterator

from fastapi import FastAPI

from nexora_tasks.thread_state import ThreadState

if TYPE_CHECKING:
    from nexora_tasks_server.framework import NexoraTasks


async def _discover_tasks(framework: "NexoraTasks") -> None:
    """Enable multi-task mode and discover task definitions."""
    from nexora_tasks.logging import logger

    try:
        await framework.enable_multi_task_mode()
        logger.info(
            "server.startup.multi_task_mode_enabled",
            tasks_registered=framework.task_registry.count(),
        )
    except Exception as e:
        logger.error(
            "server.startup.task_discovery_failed",
            error=str(e),
            exc_info=True,
        )


async def _load_registry(framework: "NexoraTasks") -> None:
    """Re-hydrate the task registry from its on-disk state file."""
    from nexora_tasks.logging import logger

    try:
        await framework.task_registry.ensure_loaded()
        logger.info(
            "server.startup.registry_loaded",
            task_count=framework.task_registry.count(),
        )
    except Exception as e:
        logger.error(
            "server.startup.registry_load_failed",
            error=str(e),
            exc_info=True,
        )


async def _start_workers(framework: "NexoraTasks") -> None:
    """Boot worker subprocesses for every deployed task (worker mode only)."""
    from nexora_tasks.logging import logger

    if framework.execution_mode != "worker":
        logger.info("server.startup.workers_skipped", reason="in-process mode")
        return

    all_tasks = framework.task_registry.list_all()
    if not all_tasks:
        logger.info("server.startup.workers_skipped", reason="no tasks deployed")
        return

    started = 0
    failed = 0
    for task_def in all_tasks:
        if not getattr(task_def, "venv_path", None):
            logger.warning(
                "server.startup.worker_skip_no_venv",
                task_id=task_def.task_id,
                version=task_def.version,
            )
            continue

        try:
            await framework.worker_manager.start_worker(task_def)
            started += 1
        except Exception as e:
            logger.error(
                "server.startup.worker_start_failed",
                task_id=task_def.task_id,
                version=task_def.version,
                error=str(e),
                exc_info=True,
            )
            failed += 1

    logger.info(
        "server.startup.workers_started",
        started=started,
        failed=failed,
        total=len(all_tasks),
    )

    await framework.worker_manager.start_health_monitor(interval=30.0)


async def _stop_workers(framework: "NexoraTasks") -> None:
    """Drain and stop every worker subprocess."""
    from nexora_tasks.logging import logger

    if framework._worker_manager and framework.worker_manager.workers:
        logger.info(
            "server.shutdown.stopping_workers",
            worker_count=len(framework.worker_manager.workers),
        )
        await framework.worker_manager.stop_all(drain=True, timeout=30)
        logger.info("server.shutdown.workers_stopped")


async def _load_schedules(framework: "NexoraTasks") -> None:
    """Restore thread metrics + load active schedules into APScheduler."""
    from nexora_tasks.logging import logger

    try:
        from nexora_tasks_server.services.run_service import RunService
        from nexora_tasks_server.services.scheduler_service import ScheduleService
        from nexora_tasks_server.services.thread_service import ThreadService

        database = framework.database

        if database:
            try:
                from nexora_tasks_server.utils.metrics_helpers import (
                    restore_thread_metrics_from_db,
                )
                await restore_thread_metrics_from_db(database)
            except Exception as e:
                logger.warning(
                    "server.startup.metrics_restore_failed",
                    error=str(e),
                    exc_info=True,
                )

        scheduler = framework.scheduler
        idempotency_store = framework.idempotency_store
        thread_service = ThreadService(
            database=database,
            idempotency_store=idempotency_store,
            execution_engine=framework.execution_engine,
        )
        run_service = RunService(
            database=database,
            thread_service=thread_service,
        )
        schedule_service = ScheduleService(
            database=database,
            scheduler=scheduler,
            run_service=run_service,
            framework=framework,
        )

        loaded_count = await schedule_service.load_active_schedules()
        logger.info(
            "server.startup.schedules_loaded",
            count=loaded_count,
        )
    except Exception as e:
        logger.error(
            "server.startup.schedule_loading_failed",
            error=str(e),
            exc_info=True,
        )


async def _recover_queued_threads(framework: "NexoraTasks") -> None:
    """Recover and resume orphaned ``state=queued`` threads."""
    from nexora_tasks.logging import logger

    try:
        database = framework.database
        if not database:
            return

        queued_threads = await database.query_threads({"state": "queued", "limit": 100})

        if not queued_threads:
            logger.info("server.startup.no_queued_threads")
            return

        logger.info(
            "server.startup.recovering_queued_threads",
            count=len(queued_threads),
        )

        if not hasattr(framework, "task_registry") or framework.task_registry is None:
            logger.warning("server.startup.no_task_registry_for_recovery")
            return

        recovered = 0
        for thread in queued_threads:
            try:
                metadata = thread.metadata or {}
                task_id = metadata.get("task_id")
                task_version = metadata.get("task_version")

                if not task_id:
                    logger.warning(
                        "server.startup.thread_no_task_id",
                        thread_id=thread.id,
                    )
                    continue

                task_def = framework.task_registry.get(task_id, task_version)
                if not task_def:
                    task_def = framework.task_registry.get_latest_version(task_id)

                if not task_def:
                    logger.warning(
                        "server.startup.task_not_found_for_recovery",
                        thread_id=thread.id,
                        task_id=task_id,
                    )
                    continue

                from nexora_tasks_server.utils.metrics_helpers import (
                    update_thread_state_gauge,
                )

                task_function = task_def.get_task_function()
                if not task_function:
                    logger.warning(
                        "server.startup.task_function_not_found",
                        thread_id=thread.id,
                        task_id=task_id,
                    )
                    continue

                async def _resume_thread(t, tf, td):
                    try:
                        if framework.concurrency_manager:
                            await framework.concurrency_manager.wait_for_slot(t.id)

                        t.state = ThreadState.RUNNING
                        await database.update_thread(t)
                        update_thread_state_gauge("queued", "running")

                        engine = framework.execution_engine
                        finished = await engine.execute_task(t, tf, td)
                        await database.update_thread(finished)

                        logger.info(
                            "server.startup.thread_recovered",
                            thread_id=t.id,
                            state=finished.state.value,
                        )
                    except Exception as e:
                        logger.error(
                            "server.startup.thread_recovery_failed",
                            thread_id=t.id,
                            error=str(e),
                        )
                        t.state = ThreadState.FAILED
                        await database.update_thread(t)
                    finally:
                        if framework.concurrency_manager:
                            await framework.concurrency_manager.release_slot(t.id)

                asyncio.create_task(_resume_thread(thread, task_function, task_def))
                recovered += 1

            except Exception as e:
                logger.error(
                    "server.startup.thread_recovery_error",
                    thread_id=thread.id,
                    error=str(e),
                )

        logger.info(
            "server.startup.recovery_complete",
            recovered=recovered,
            total=len(queued_threads),
        )
    except Exception as e:
        logger.error(
            "server.startup.queue_recovery_failed",
            error=str(e),
            exc_info=True,
        )


def build_lifespan(framework: "NexoraTasks"):
    """Return a FastAPI ``lifespan`` async context manager bound to a framework.

    The returned callable matches FastAPI's expected signature
    ``Callable[[FastAPI], AsyncContextManager[None]]`` and replaces the
    deprecated ``@app.on_event("startup"|"shutdown")`` decorators.
    """

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        # Startup phases — order matters: tasks → registry → workers
        # (workers need registry) → schedules (need DB) → orphan recovery.
        await _discover_tasks(framework)
        await _load_registry(framework)
        await _start_workers(framework)
        await _load_schedules(framework)
        await _recover_queued_threads(framework)

        yield

        # Shutdown — currently only worker drain. Add additional shutdown
        # phases above this comment to keep ordering explicit.
        await _stop_workers(framework)

    return lifespan


def build_proxy_lifespan(health_checker, health_check_interval: int):
    """Return a ``lifespan`` for the proxy server (M-11).

    Migrates the proxy's ``@app.on_event("startup")`` /
    ``@app.on_event("shutdown")`` pair to a single async context manager.
    """

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        from nexora_tasks.logging import logger

        health_checker.start()
        logger.info(
            "proxy.server.started",
            health_check_interval=health_check_interval,
        )
        try:
            yield
        finally:
            health_checker.stop()
            logger.info("proxy.server.stopped")

    return lifespan
