"""Event and data filtering logic for webhook delivery."""

from typing import Any, Dict, List, Optional

from nexora_tasks.models.webhook import Webhook
from nexora_tasks.models.webhook_scoping import WebhookScope


def matches_scope(webhook_scope: Optional[WebhookScope], event_metadata: Dict[str, Any], thread_id: Optional[str] = None) -> bool:
    """Check if event matches webhook scope.

    Args:
        webhook_scope: Webhook scope configuration (None matches all)
        event_metadata: Event metadata (containing user_id, app_id, tenant_id, etc.)
        thread_id: Thread identifier (for thread-scoped matching)

    Returns:
        True if event matches scope, False otherwise
    """
    # If no scope specified, match all events
    if not webhook_scope:
        return True

    # Thread-scoped webhooks only match events for that specific thread
    if webhook_scope.thread_id:
        return thread_id == webhook_scope.thread_id

    # Check other scope fields (AND logic - all specified fields must match)
    if webhook_scope.tenant_id and event_metadata.get("tenant_id") != webhook_scope.tenant_id:
        return False
    if webhook_scope.user_id and event_metadata.get("user_id") != webhook_scope.user_id:
        return False
    if webhook_scope.app_id and event_metadata.get("app_id") != webhook_scope.app_id:
        return False
    if webhook_scope.schedule_id and event_metadata.get("schedule_id") != webhook_scope.schedule_id:
        return False

    return True


def matches_event_type(webhook: Webhook, event_type: str) -> bool:
    """Check if event type matches webhook event filters.

    bug-29: precedence is now explicit and order-independent —
    ``exclude`` always wins. The matrix:

        include unset, exclude unset → match
        include set,   exclude unset → match iff event_type in include
        include unset, exclude set   → match iff event_type not in exclude
        include set,   exclude set   → match iff (event_type in include
                                                  AND event_type not in exclude)

    The model historically forbade both fields being set at once, but
    the filter must still behave defensively if a malformed Webhook
    document slips through (legacy ES record, manual DB edit, race
    between schema migration and code rollout). Defensive AND-of-both
    semantics is safer than silently ignoring exclude.

    Args:
        webhook: Webhook instance with event filters
        event_type: Event type to check (e.g., "thread.succeeded")

    Returns:
        True if event type matches filters, False otherwise
    """
    # If no event filters at all, match every event.
    if not webhook.events:
        return True

    include = webhook.events.include
    exclude = webhook.events.exclude

    # Exclude wins: any event explicitly listed in exclude is dropped,
    # regardless of whether include also lists it.
    if exclude and event_type in exclude:
        return False

    # If include is set, the event must be in the allowlist.
    if include:
        return event_type in include

    # No include allowlist + not excluded → deliver.
    return True


def should_deliver_webhook(
    webhook: Webhook,
    event_type: str,
    event_metadata: Dict[str, Any],
    thread_id: Optional[str] = None,
) -> bool:
    """Check if webhook should receive event based on scope and event filters.

    Args:
        webhook: Webhook instance to check
        event_type: Event type (e.g., "thread.succeeded")
        event_metadata: Event metadata (for scope matching)
        thread_id: Thread identifier (for thread-scoped matching)

    Returns:
        True if webhook should receive event, False otherwise
    """
    # Skip disabled webhooks
    if not webhook.enabled:
        return False

    # Environment scope: webhook only receives events from its own environment.
    # Fall back to "default" on both sides so pre-env-scoping data stays routable.
    webhook_env = getattr(webhook, "environment_id", None) or "default"
    event_env = event_metadata.get("environment_id") or "default"
    if webhook_env != event_env:
        return False

    # Check task_id filter (if webhook has task_id set, event must match)
    if webhook.task_id:
        event_task_id = event_metadata.get("task_id")
        if event_task_id != webhook.task_id:
            return False

    # Check task_version filter (if webhook has task_version set, event must match)
    if webhook.task_version:
        event_task_version = event_metadata.get("task_version")
        if event_task_version != webhook.task_version:
            return False

    # Check scope matching (more restrictive)
    if not matches_scope(webhook.scope, event_metadata, thread_id):
        return False

    # Check event type matching
    if not matches_event_type(webhook, event_type):
        return False

    return True

