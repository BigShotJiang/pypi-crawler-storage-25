"""Event publisher for webhook system using async in-memory queue.

C-3 invariant: events MUST NOT be silently dropped. The publisher offers
two safety nets between the producer (``execution.py``) and the
consumer (``delivery_engine.process_event``):

  1. **Backpressure escape hatch on QueueFull.** When the primary queue
     refuses ``put_nowait`` we fall back to ``put`` with a bounded
     timeout. If that also fails we hand the event to a bounded
     in-memory DLQ buffer rather than logging-and-forgetting. Every
     branch increments a Prometheus counter so operators can alert.
  2. **Handler exception → requeue with cap.** When the handler raises,
     we requeue the event with an exponential backoff up to
     ``MAX_HANDLER_RETRIES`` attempts. Past the cap the event is moved
     to the DLQ and the dropped counter increments — no more "log and
     continue".

The DLQ is a *fail-soft* in-memory ring (default 10× the main queue
size). Operators should drain it to durable storage in the
``set_dlq_handler`` callback when running in production. Callers that
do not register a handler still get observability through the metrics
and structured logs.
"""

import asyncio
from collections import deque
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Deque, Dict, List, Optional

from nexora_tasks.logging import logger
from nexora_tasks_server.observability.metrics import (
    webhook_dlq_size,
    webhook_dlq_writes_total,
    webhook_events_dropped_total,
    webhook_events_requeued_total,
)


# Bounded retry / backoff parameters for handler-exception requeue.
# Kept conservative so a poisoned event cannot loop forever — after
# ``MAX_HANDLER_RETRIES`` attempts the event is moved to the DLQ.
MAX_HANDLER_RETRIES = 3
HANDLER_RETRY_BACKOFF_BASE = 0.5  # seconds, doubles per attempt

# Timeout for the fallback ``await put`` when ``put_nowait`` raises
# QueueFull. 5s is long enough to ride out a brief consumer hiccup but
# short enough that the producer (execution path) is not blocked
# indefinitely.
QUEUE_FULL_FALLBACK_TIMEOUT_SECONDS = 5.0


class WebhookEvent:
    """Webhook event model for event publishing."""

    def __init__(
        self,
        event_type: str,
        thread_id: Optional[str] = None,
        run_id: Optional[str] = None,
        thread: Optional[Any] = None,
        metadata: Optional[Dict[str, Any]] = None,
        timestamp: Optional[datetime] = None,
    ) -> None:
        """Initialize webhook event.

        Args:
            event_type: Event type (e.g., "thread.succeeded", "thread.failed")
            thread_id: Thread identifier (if applicable)
            run_id: Run identifier (if applicable)
            thread: Thread instance (if applicable)
            metadata: Event metadata
            timestamp: Event timestamp (defaults to now)
        """
        self.event_type = event_type
        self.thread_id = thread_id
        self.run_id = run_id
        self.thread = thread
        self.metadata = metadata or {}
        self.timestamp = timestamp or datetime.now(timezone.utc)
        # Internal handler-retry counter. Not part of the wire contract —
        # only inspected by ``_process_events`` to enforce the cap.
        self._handler_attempts: int = 0


# Type alias: an async callable that receives an event the publisher
# could not deliver (DLQ fallback). Operators register one to drain to
# durable storage (ES index, file log, S3, …).
DLQHandler = Callable[[WebhookEvent, str], Awaitable[None]]


class EventPublisher:
    """Event publisher with async in-memory queue + bounded DLQ buffer.

    The DLQ buffer is intentionally a ``deque`` (not an ``asyncio.Queue``)
    so it can be inspected from sync test code and survives consumer
    death. Tests assert against ``dlq_snapshot()``; production code
    should set a DLQ handler that drains it externally.
    """

    def __init__(
        self,
        queue_size: int = 1000,
        dlq_capacity: Optional[int] = None,
    ) -> None:
        """Initialize event publisher.

        Args:
            queue_size: Maximum primary queue size (default: 1000).
            dlq_capacity: Maximum events held in the in-memory DLQ
                ring buffer. Defaults to ``10 × queue_size`` so a
                short consumer hiccup is absorbed without loss. The
                ring overwrites the oldest entry when full and emits
                a metric — losing OLD events is preferable to losing
                NEW ones at publish time.
        """
        self._queue: asyncio.Queue[WebhookEvent] = asyncio.Queue(maxsize=queue_size)
        self._processor_task: Optional[asyncio.Task[None]] = None
        self._running = False
        self._event_handler: Optional[Callable[[WebhookEvent], Awaitable[None]]] = None
        self._dlq_handler: Optional[DLQHandler] = None
        self._dlq_capacity = dlq_capacity if dlq_capacity is not None else max(queue_size * 10, 100)
        self._dlq: Deque[tuple[WebhookEvent, str]] = deque(maxlen=self._dlq_capacity)

    async def publish(
        self,
        event_type: str,
        thread_id: Optional[str] = None,
        run_id: Optional[str] = None,
        thread: Optional[Any] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Publish an event to the queue.

        Drop policy (C-3): if the primary queue is full, fall back to
        a bounded ``await put`` (5s). If that also times out, persist
        the event to the in-memory DLQ buffer and increment the
        dropped/dlq counters. NEVER raise — the producer is on the
        execution hot path and must not be blocked or crashed by
        webhook backpressure.
        """
        # Auto-start processor if handler is set but not running
        if self._event_handler and not self._running:
            await self.start()

        event = WebhookEvent(
            event_type=event_type,
            thread_id=thread_id,
            run_id=run_id,
            thread=thread,
            metadata=metadata,
        )

        # Fast path: queue has room.
        try:
            self._queue.put_nowait(event)
            logger.debug(
                "webhook.event.published",
                event_type=event_type,
                thread_id=thread_id,
                queue_size=self._queue.qsize(),
            )
            return
        except asyncio.QueueFull:
            pass

        # Slow path: brief blocking put — gives the consumer a chance to
        # catch up without losing the event.
        try:
            await asyncio.wait_for(
                self._queue.put(event),
                timeout=QUEUE_FULL_FALLBACK_TIMEOUT_SECONDS,
            )
            logger.warning(
                "webhook.event.queue_full_recovered",
                event_type=event_type,
                thread_id=thread_id,
                queue_size=self._queue.qsize(),
            )
            return
        except asyncio.TimeoutError:
            pass

        # DLQ: persist into the bounded buffer so a downstream drain can
        # rescue the event. Always increments the dropped counter — by
        # the time we're here the event has missed its synchronous
        # delivery window even if the buffer accepts it.
        await self._send_to_dlq(event, reason="queue_full")

    def set_event_handler(self, handler: Callable[[WebhookEvent], Awaitable[None]]) -> None:
        """Set event handler for processing events.

        Args:
            handler: Async callable that processes WebhookEvent instances
        """
        self._event_handler = handler
        # Auto-start processor if not already running (non-blocking)
        if not self._running:
            try:
                loop = asyncio.get_running_loop()
                if loop.is_running():
                    # If loop is running, create task
                    asyncio.create_task(self.start())
            except RuntimeError:
                # No running event loop, will start when first event is published
                pass

    def set_dlq_handler(self, handler: DLQHandler) -> None:
        """Register a callback to drain DLQ events to durable storage.

        The handler signature is ``async (event, reason) -> None``. It
        is invoked on EACH DLQ deposit (queue overflow, handler retries
        exhausted). If the handler itself raises, the event still lands
        in the in-memory DLQ buffer and a ``dlq_failure`` counter
        increments — we never lose the event because the rescue code
        blew up.
        """
        self._dlq_handler = handler

    async def start(self) -> None:
        """Start the background event processor."""
        if self._running:
            return

        self._running = True
        self._processor_task = asyncio.create_task(self._process_events())
        logger.info("webhook.event_publisher.started")

    async def stop(self) -> None:
        """Stop the background event processor."""
        if not self._running:
            return

        self._running = False
        if self._processor_task:
            self._processor_task.cancel()
            try:
                await self._processor_task
            except asyncio.CancelledError:
                pass
        logger.info("webhook.event_publisher.stopped")

    async def _process_events(self) -> None:
        """Background task to process events from queue.

        Handler-exception policy (C-3): on raise, requeue with
        exponential backoff up to ``MAX_HANDLER_RETRIES`` attempts.
        Past the cap, hand the event to the DLQ. CancelledError is
        always re-raised so ``stop()`` works.
        """
        while self._running:
            try:
                # Wait for event with timeout to allow periodic checks
                try:
                    event = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

                if not self._event_handler:
                    logger.debug(
                        "webhook.event.no_handler",
                        event_type=event.event_type,
                        thread_id=event.thread_id,
                    )
                    continue

                try:
                    await self._event_handler(event)
                except asyncio.CancelledError:
                    # Propagate cancellation immediately — no requeue,
                    # no DLQ. The shutdown path owns the event.
                    raise
                except Exception as e:
                    event._handler_attempts += 1
                    logger.error(
                        "webhook.event_processing.failed",
                        event_type=event.event_type,
                        thread_id=event.thread_id,
                        attempt=event._handler_attempts,
                        max_attempts=MAX_HANDLER_RETRIES,
                        error=str(e),
                        error_type=type(e).__name__,
                    )

                    if event._handler_attempts >= MAX_HANDLER_RETRIES:
                        # Cap reached — DLQ.
                        await self._send_to_dlq(event, reason="handler_exception")
                    else:
                        # Schedule requeue after backoff. We don't await
                        # the sleep inline — that would block the
                        # processor and starve newer events. Spawn a
                        # task that sleeps then re-enqueues.
                        webhook_events_requeued_total.add(
                            1,
                            {
                                "attempt": str(event._handler_attempts),
                                "event_type": event.event_type,
                            },
                        )
                        asyncio.create_task(self._requeue_after_backoff(event))

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(
                    "webhook.event_processor.error",
                    error=str(e),
                    error_type=type(e).__name__,
                )

    async def _requeue_after_backoff(self, event: WebhookEvent) -> None:
        """Sleep for the backoff window then put the event back on the
        primary queue. Falls through to DLQ if the queue has filled up
        in the meantime — we MUST NOT block the requeue path forever
        because that would starve other retries."""
        backoff = HANDLER_RETRY_BACKOFF_BASE * (2 ** (event._handler_attempts - 1))
        try:
            await asyncio.sleep(backoff)
        except asyncio.CancelledError:
            # Shutdown happened while we were sleeping — drop into DLQ
            # so a restart can pick it up.
            await self._send_to_dlq(event, reason="handler_exception")
            raise

        try:
            self._queue.put_nowait(event)
            logger.info(
                "webhook.event.requeued",
                event_type=event.event_type,
                thread_id=event.thread_id,
                attempt=event._handler_attempts,
            )
        except asyncio.QueueFull:
            # Queue is full again — DLQ rather than blocking forever.
            await self._send_to_dlq(event, reason="handler_exception")

    async def _send_to_dlq(self, event: WebhookEvent, reason: str) -> None:
        """Persist an event we cannot deliver to the DLQ ring + invoke
        the registered DLQ handler. Always increments
        ``webhook_events_dropped_total`` because, at this point, the
        synchronous delivery contract has been broken — the DLQ is best
        effort recovery, not a green path."""
        webhook_events_dropped_total.add(
            1,
            {"reason": reason, "event_type": event.event_type},
        )
        logger.error(
            "webhook.event.dropped",
            event_type=event.event_type,
            thread_id=event.thread_id,
            reason=reason,
            queue_size=self._queue.qsize(),
            dlq_size=len(self._dlq),
        )

        # Buffer first — the DLQ ring is the only loss-bound we can
        # guarantee. The handler may fail; the buffer cannot.
        before_len = len(self._dlq)
        self._dlq.append((event, reason))
        if len(self._dlq) > before_len:
            webhook_dlq_size.add(1, {"reason": reason})
        webhook_dlq_writes_total.add(1, {"reason": reason})

        if self._dlq_handler is not None:
            try:
                await self._dlq_handler(event, reason)
            except Exception as e:
                webhook_events_dropped_total.add(
                    1,
                    {"reason": "dlq_failure", "event_type": event.event_type},
                )
                logger.error(
                    "webhook.event.dlq_handler_failed",
                    event_type=event.event_type,
                    thread_id=event.thread_id,
                    reason=reason,
                    error=str(e),
                    error_type=type(e).__name__,
                )

    def dlq_snapshot(self) -> List[tuple[WebhookEvent, str]]:
        """Return a snapshot of currently-buffered DLQ events.

        Used by tests and admin endpoints. Returns a list copy so
        callers can iterate without racing the producer.
        """
        return list(self._dlq)

    def clear_dlq(self) -> int:
        """Drain the DLQ buffer and return the number of events
        removed. Operators call this from an admin task once the
        events have been persisted to durable storage."""
        cleared = len(self._dlq)
        if cleared:
            webhook_dlq_size.add(-cleared)
        self._dlq.clear()
        return cleared

    @property
    def queue_size(self) -> int:
        """Get current queue size."""
        return self._queue.qsize()

    @property
    def dlq_size(self) -> int:
        """Get current count of events held in the DLQ ring."""
        return len(self._dlq)

    @property
    def is_running(self) -> bool:
        """Check if processor is running."""
        return self._running
