"""HMAC signature generation for webhook security.

M-21: signature MUST work over the original ``bytes`` regardless of
encoding. The previous implementation round-tripped the body through
``decode('utf-8', errors='replace')`` and then re-encoded it. For any
body containing non-UTF-8 bytes (binary payloads, latin-1 strings,
broken UTF-8 sequences), each invalid byte was replaced with
U+FFFD before signing — which means:

  1. Two distinct binary bodies could produce the SAME signature.
  2. A consumer that signs the raw bytes it received (the obvious
     thing) would see a signature mismatch — even though we both
     intended to sign the same payload.

The fix is to operate on bytes natively: concatenate
``f"{timestamp}.".encode('ascii') + body`` and HMAC the result. Callers
that hand us ``str`` are accepted via UTF-8 with ``surrogateescape`` so
Latin-1 round-trips are stable.
"""

import hashlib
import hmac
import time
from typing import Tuple, Union


def _coerce_body_to_bytes(body: Union[bytes, bytearray, memoryview, str]) -> bytes:
    """Normalise ``body`` to ``bytes`` without losing information.

    ``bytes`` / ``bytearray`` / ``memoryview`` → returned as-is. ``str``
    is encoded with ``surrogateescape`` so a string round-tripped from
    raw bytes (e.g. ``raw.decode('latin-1')``) signs identically to
    the original. UTF-8 strings encode normally.

    Anything else raises ``TypeError`` — silent type coercion is how
    binary-body bugs survive code review.
    """
    if isinstance(body, (bytes, bytearray)):
        return bytes(body)
    if isinstance(body, memoryview):
        return body.tobytes()
    if isinstance(body, str):
        return body.encode("utf-8", errors="surrogateescape")
    raise TypeError(
        f"body must be bytes/bytearray/memoryview/str, got {type(body).__name__}"
    )


def generate_signature(secret: str, timestamp: int, body: Union[bytes, str]) -> str:
    """Generate HMAC SHA-256 signature over ``<timestamp>.<body_bytes>``.

    Args:
        secret: HMAC secret (should start with 'whsec_' prefix).
        timestamp: Unix timestamp (seconds since epoch).
        body: Raw request body bytes. ``str`` is also accepted and
            encoded with surrogateescape so Latin-1 round-trips
            preserve their bytes (M-21).

    Returns:
        Hexadecimal signature string.

    Raises:
        ValueError: If ``secret`` is empty/whitespace.
        TypeError: If ``body`` is not bytes-like or str.
    """
    if not secret or not secret.strip():
        raise ValueError("Secret must be non-empty")

    # Remove 'whsec_' prefix if present (for compatibility)
    secret_key = secret.removeprefix("whsec_") if secret.startswith("whsec_") else secret

    body_bytes = _coerce_body_to_bytes(body)

    # Build the signature payload natively in bytes. The timestamp is
    # ASCII-clean by definition (digits + '.'); the body bytes are
    # appended verbatim so binary payloads sign correctly.
    signature_payload = f"{timestamp}.".encode("ascii") + body_bytes

    # Generate HMAC SHA-256 signature
    signature = hmac.new(
        secret_key.encode("utf-8"),
        signature_payload,
        hashlib.sha256,
    ).hexdigest()

    return signature


def generate_signature_header(secret: str, body: Union[bytes, str]) -> Tuple[int, str]:
    """Generate signature header value with timestamp.

    The header value matches the format documented in
    ``docs/features/webhooks.md`` and ``docs/api/webhooks.md``:

        X-Webhook-Signature: sha256=<hex>

    The timestamp is returned alongside so the dispatcher can emit a
    paired ``X-Webhook-Timestamp`` header for replay-protection. The
    signature is computed over ``<timestamp>.<body>`` so consumers that
    care about replay can verify the timestamp is recent.

    Args:
        secret: HMAC secret
        body: Raw request body bytes

    Returns:
        Tuple of (timestamp, signature_header_value)
        signature_header_value format: ``sha256=<hex>``
    """
    timestamp = int(time.time())
    signature = generate_signature(secret, timestamp, body)
    header_value = f"sha256={signature}"
    return timestamp, header_value


def verify_signature(secret: str, timestamp: int, body: Union[bytes, str], signature: str) -> bool:
    """Verify HMAC signature.

    Args:
        secret: HMAC secret
        timestamp: Unix timestamp from signature header
        body: Raw request body bytes
        signature: Signature to verify (hexadecimal)

    Returns:
        True if signature is valid, False otherwise
    """
    try:
        expected_signature = generate_signature(secret, timestamp, body)
        return hmac.compare_digest(expected_signature, signature)
    except Exception:
        return False

