"""Webhook delivery engine for async HTTP delivery."""

import asyncio
import json
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import httpx
from structlog.contextvars import bind_contextvars, unbind_contextvars

from nexora_tasks_server.delivery.event_publisher import WebhookEvent
from nexora_tasks_server.delivery.payload_builder import build_webhook_payload
from nexora_tasks_server.delivery.signature import generate_signature_header
from nexora_tasks.logging import logger
from nexora_tasks_server.observability.metrics import (
    webhook_delivery_duration,
    webhook_deliveries_total,
)
from nexora_tasks.models.webhook import Webhook, WebhookDelivery
from nexora_tasks_server.repositories.webhook_db import WebhookDeliveryRepository, WebhookRepository
from nexora_tasks_server.services.webhook_service import (
    WebhookService,
    resolve_and_validate_webhook_url,
    validate_webhook_url_async,
)


class DeliveryEngine:
    """Async webhook delivery engine."""

    def __init__(
        self,
        webhook_service: WebhookService,
        delivery_repository: WebhookDeliveryRepository,
        database: Optional[Any] = None,
        file_storage: Optional[Any] = None,
        timeout_seconds: int = 10,
        webhook_repository: Optional[WebhookRepository] = None,
    ) -> None:
        """Initialize delivery engine.

        Args:
            webhook_service: WebhookService for finding matching webhooks
            delivery_repository: WebhookDeliveryRepository for storing delivery records
            database: Database instance for loading artifacts (optional)
            file_storage: File storage instance for download URLs (optional)
            timeout_seconds: Default timeout for HTTP requests (default: 10)
            webhook_repository: Optional WebhookRepository injected to disable a
                webhook on 410 Gone. When omitted, the engine falls back to
                ``StorageFactory.from_env()`` (legacy behaviour) — composition
                roots SHOULD inject the framework's shared repository so DI
                overrides are honoured (M-10, bug-18).
        """
        self.webhook_service = webhook_service
        self.delivery_repository = delivery_repository
        self.database = database
        self.file_storage = file_storage
        self.timeout_seconds = timeout_seconds
        self._webhook_repository = webhook_repository
        self._http_client: Optional[httpx.AsyncClient] = None

    async def _get_http_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client with connection pooling.

        TLS verification is configurable via env vars so on-prem deployments
        can pin a custom CA bundle or (rarely) disable verification:

        - ``WEBHOOK_TLS_VERIFY=false`` disables certificate verification
          entirely. Only useful for local development against self-signed
          targets — never set in production.
        - ``WEBHOOK_CA_BUNDLE=/path/to/ca.pem`` points at a custom CA bundle.
          Takes precedence over ``WEBHOOK_TLS_VERIFY`` when set.

        When neither var is set the default (`verify=True`) is used, which
        validates against the system CA store.

        Returns:
            httpx.AsyncClient instance
        """
        if self._http_client is None:
            import os

            ca_bundle = os.environ.get("WEBHOOK_CA_BUNDLE", "").strip()
            tls_verify_env = os.environ.get("WEBHOOK_TLS_VERIFY", "").strip().lower()
            env_name = os.environ.get("ENV", "").strip().lower()

            if ca_bundle:
                verify: Any = ca_bundle
            elif tls_verify_env in ("0", "false", "no", "off"):
                # TLS verification opt-out is forbidden in production and staging.
                if env_name in ("production", "staging"):
                    raise SystemExit(
                        "TLS verify cannot be disabled in production/staging "
                        "(WEBHOOK_TLS_VERIFY=false). "
                        "Use WEBHOOK_CA_BUNDLE to pin a custom CA bundle instead."
                    )
                verify = False
                logger.warning(
                    "webhook.tls_verify_disabled",
                    message=(
                        "Webhook TLS verification disabled via WEBHOOK_TLS_VERIFY. "
                        "Outbound deliveries will accept any certificate."
                    ),
                )
            else:
                verify = True

            self._http_client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout_seconds, connect=5.0),
                limits=httpx.Limits(max_connections=100),
                verify=verify,
            )
        return self._http_client

    async def close(self) -> None:
        """Close HTTP client and cleanup resources."""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

    async def process_event(self, event: WebhookEvent) -> None:
        """Process a webhook event and deliver to matching webhooks.

        Args:
            event: WebhookEvent instance to process
        """
        # Get matching webhooks (from webhook repository)
        # This now includes schedule webhooks since they're stored as real webhook records
        # with scope.schedule_id and source='schedule'
        matching_webhooks = await self.webhook_service.get_matching_webhooks(
            event_type=event.event_type,
            thread_id=event.thread_id,
            run_id=event.run_id,
            metadata=event.metadata,
        )

        if not matching_webhooks:
            logger.debug(
                "webhook.no_matching_webhooks",
                event_type=event.event_type,
                thread_id=event.thread_id,
            )
            return

        # Deduplicate webhooks by URL to avoid sending duplicate HTTP requests
        # If multiple webhooks point to the same URL, only deliver once (use first webhook)
        seen_urls: Dict[str, Webhook] = {}
        for webhook in matching_webhooks:
            if webhook.url not in seen_urls:
                seen_urls[webhook.url] = webhook
            else:
                logger.debug(
                    "webhook.deduplicated",
                    webhook_id=webhook.id,
                    url=webhook.url,
                    event_type=event.event_type,
                    thread_id=event.thread_id,
                )

        # Deliver to each unique webhook URL
        for webhook in seen_urls.values():
            await self._deliver_to_webhook(webhook, event)

    async def _deliver_to_webhook(self, webhook: Webhook, event: WebhookEvent) -> None:
        """Deliver event to a specific webhook.

        Args:
            webhook: Webhook instance to deliver to
            event: WebhookEvent instance to deliver
        """
        from nexora_tasks.utils.id_generator import generate_delivery_id
        delivery_id = generate_delivery_id()
        start_time = time.time()

        # E-5: Bind webhook_id + delivery_id into structlog contextvars so
        # every log line emitted by this delivery carries the correlation
        # keys automatically. The try/finally ensures we unbind even on
        # exception; the wrapper function ``_run`` below contains all of
        # the actual delivery logic.
        bound_keys: List[str] = []
        try:
            bind_contextvars(webhook_id=webhook.id, delivery_id=delivery_id)
            bound_keys = ["webhook_id", "delivery_id"]
            await self._deliver_to_webhook_inner(webhook, event, delivery_id, start_time)
        finally:
            if bound_keys:
                unbind_contextvars(*bound_keys)

    # Maximum delivery attempts (1 initial + N-1 retries) on transient errors.
    MAX_DELIVERY_ATTEMPTS = 3
    # Exponential backoff base (seconds): attempt 1→1s, 2→2s, 3→4s …
    RETRY_BACKOFF_BASE = 1.0
    # bug-19: HTTP status codes that indicate a *transient* failure and
    # should be retried with backoff. 5xx is server side; 408 is the
    # endpoint telling us the request timed out (we should retry); 429
    # is rate limiting (back off and retry). Any other 4xx is the
    # endpoint *rejecting* the payload — retrying will not change the
    # outcome and would amplify load on a misconfigured receiver.
    TRANSIENT_STATUS_CODES = frozenset({408, 429})

    async def _deliver_to_webhook_inner(
        self,
        webhook: Webhook,
        event: WebhookEvent,
        delivery_id: str,
        start_time: float,
    ) -> None:
        """Inner body of webhook delivery, called with correlation IDs bound."""

        # Build payload with data filtering
        payload = await self._build_payload(webhook, event, delivery_id=delivery_id)

        logger.info(
            "webhook.delivery.started",
            webhook_id=webhook.id,
            delivery_id=delivery_id,
            event_type=event.event_type,
            thread_id=event.thread_id,
        )

        # bug-5 / M-5: resolve DNS once *here* and pin the validated IP
        # for the actual request. The previous flow validated the URL,
        # then handed ``httpx`` a hostname which it resolved a second
        # time — a DNS-rebinding attacker could return a public IP for
        # the validation pass and 169.254.169.254 (or a private host)
        # for the connection pass. ``resolve_and_validate_webhook_url``
        # closes that window by returning the hostname + the IP we
        # already validated; the caller swaps the URL host for the IP
        # and preserves ``Host`` / SNI so vhost routing and TLS cert
        # checks still work.
        try:
            original_host, pinned_ip = await resolve_and_validate_webhook_url(webhook.url)
        except ValueError as ssrf_err:
            delivery = WebhookDelivery(
                id=delivery_id,
                webhook_id=webhook.id,
                event_type=event.event_type,
                event_payload=payload,
                thread_id=event.thread_id,
                run_id=event.run_id,
                timestamp=datetime.now(timezone.utc),
                status="failed",
                delivery_url=webhook.url,
                error=f"SSRF check failed: {ssrf_err}",
                response_time_ms=int((time.time() - start_time) * 1000),
            )
            webhook_deliveries_total.add(1, {"webhook_id": webhook.id, "status": "failed"})
            logger.warning(
                "webhook.delivery.ssrf_blocked",
                webhook_id=webhook.id,
                delivery_id=delivery_id,
                url=webhook.url,
                error=str(ssrf_err),
            )
            try:
                await self.delivery_repository.create_delivery(delivery)
            except Exception as persist_err:
                webhook_deliveries_total.add(1, {"webhook_id": webhook.id, "status": "persist_failed"})
                logger.error(
                    "webhook.delivery.persist_failed",
                    webhook_id=webhook.id,
                    delivery_id=delivery_id,
                    error=str(persist_err),
                    exc_info=True,
                )
            return

        # Get HTTP client
        client = await self._get_http_client()

        # Prepare static headers (signature re-generated per attempt for fresh timestamp).
        base_headers = {
            "Content-Type": "application/json",
            "X-Webhook-Event": event.event_type,
            "X-Webhook-ID": webhook.id,
            "X-Webhook-Delivery-ID": delivery_id,
        }
        if webhook.api_key:
            base_headers["X-API-Key"] = webhook.api_key

        body_bytes = json.dumps(payload, sort_keys=True).encode('utf-8')
        http_timeout = httpx.Timeout(webhook.timeout_seconds or self.timeout_seconds, connect=5.0)

        # bug-5 / M-5: build the pinned URL — same scheme + path, but the
        # netloc points at the pre-validated IP. We add a ``Host`` header
        # so virtual-hosting endpoints route correctly, and pass
        # ``sni_hostname`` via the request extensions so TLS SNI and cert
        # validation use the original DNS name (httpx wraps an IPv6 IP
        # literal in brackets, but for safety we do it explicitly).
        _parsed = httpx.URL(webhook.url)
        _ip_for_url = f"[{pinned_ip}]" if ":" in pinned_ip else pinned_ip
        _pinned_url = _parsed.copy_with(host=_ip_for_url)
        # Preserve any existing Host header (env-bound proxies may set
        # one) but always default to the original hostname.
        _host_header = original_host
        if _parsed.port is not None:
            _host_header = f"{original_host}:{_parsed.port}"
        # We pass these through unchanged on every retry attempt below.
        base_headers["Host"] = _host_header
        # Request extensions consumed by httpcore for TLS SNI selection.
        _request_extensions: Dict[str, Any] = {"sni_hostname": original_host}

        for attempt in range(self.MAX_DELIVERY_ATTEMPTS):
            from nexora_tasks.utils.id_generator import generate_delivery_id
            attempt_delivery_id = delivery_id if attempt == 0 else generate_delivery_id()

            # Fresh signature per attempt (new timestamp).
            timestamp, signature_header = generate_signature_header(webhook.secret, body_bytes)
            headers = {
                **base_headers,
                "X-Webhook-Signature": signature_header,
                "X-Webhook-Timestamp": str(timestamp),
                "X-Webhook-Delivery-ID": attempt_delivery_id,
            }

            attempt_start = time.time()
            delivery = WebhookDelivery(
                id=attempt_delivery_id,
                webhook_id=webhook.id,
                event_type=event.event_type,
                event_payload=payload,
                thread_id=event.thread_id,
                run_id=event.run_id,
                timestamp=datetime.now(timezone.utc),
                status="failed",  # updated below on success/5xx
                delivery_url=webhook.url,
            )
            # bug-19: classify the attempt outcome into one of three
            # buckets — terminal-success, terminal-failure (no retry),
            # transient (retry with backoff). The classification logic
            # is colocated below so the retry/backoff flow is single-pass.
            transient_reason: Optional[str] = None  # set => retry
            try:
                response = await client.post(
                    _pinned_url,
                    content=body_bytes,
                    headers=headers,
                    timeout=http_timeout,
                    extensions=_request_extensions,
                )

                response_time_ms = int((time.time() - attempt_start) * 1000)
                delivery.status_code = response.status_code
                delivery.response_time_ms = response_time_ms
                try:
                    _body_text = response.text or ""
                    delivery.response_body_truncated = _body_text[:8192] + ("<truncated>" if len(_body_text) > 8192 else "")
                except Exception:
                    delivery.response_body_truncated = None

                if response.status_code >= 500 or response.status_code in self.TRANSIENT_STATUS_CODES:
                    # 5xx + 408 + 429 → transient. Persist this
                    # attempt's failure record, then retry with backoff.
                    delivery.status = "failed"
                    delivery.error = f"Transient HTTP {response.status_code}"
                    webhook_deliveries_total.add(1, {"webhook_id": webhook.id, "status": "failed"})
                    transient_reason = f"http_{response.status_code}"
                    logger.warning(
                        "webhook.delivery.transient_will_retry",
                        webhook_id=webhook.id,
                        delivery_id=attempt_delivery_id,
                        attempt=attempt + 1,
                        max_attempts=self.MAX_DELIVERY_ATTEMPTS,
                        status_code=response.status_code,
                    )
                    # Persist this attempt record before sleeping.
                    try:
                        await self.delivery_repository.create_delivery(delivery)
                    except Exception as persist_err:
                        logger.error(
                            "webhook.delivery.persist_failed",
                            webhook_id=webhook.id,
                            delivery_id=attempt_delivery_id,
                            error=str(persist_err),
                        )
                else:
                    # All other status codes (2xx + non-transient 4xx) are
                    # treated as terminal-success: the endpoint either
                    # accepted the payload (2xx) or definitively rejected
                    # it (4xx) — retrying a 400/401/403/404 would just
                    # hammer a misconfigured receiver.
                    delivery.status = "success"
                    webhook_deliveries_total.add(1, {"webhook_id": webhook.id, "status": "success"})
                    # bug-20: tag the success duration so dashboards can
                    # split success vs failure latency histograms.
                    webhook_delivery_duration.record(
                        time.time() - start_time,
                        {
                            "webhook_id": webhook.id,
                            "status": "success",
                            "transient": "false",
                        },
                    )

                    # Handle 410 Gone - disable webhook automatically
                    if response.status_code == 410:
                        logger.warning(
                            "webhook.disabled_410_gone",
                            webhook_id=webhook.id,
                            delivery_id=attempt_delivery_id,
                        )
                        webhook.enabled = False
                        webhook.updated_at = datetime.now(timezone.utc)
                        # bug-18 / M-10: prefer the injected repository so DI
                        # overrides (test fixtures, composition root) are
                        # honoured. Fall back to env only if no repository was
                        # injected at construction time.
                        webhook_repo = self._webhook_repository
                        if webhook_repo is None:
                            from nexora_tasks_server.storage_factory import StorageFactory
                            webhook_repo = StorageFactory.from_env().create_webhook_repository()
                        await webhook_repo.update_webhook(webhook)

                    logger.info(
                        "webhook.delivery.completed",
                        webhook_id=webhook.id,
                        delivery_id=attempt_delivery_id,
                        status="success",
                        status_code=response.status_code,
                        response_time_ms=response_time_ms,
                    )
                    # Persist success record.
                    try:
                        await self.delivery_repository.create_delivery(delivery)
                    except Exception as persist_err:
                        webhook_deliveries_total.add(1, {"webhook_id": webhook.id, "status": "persist_failed"})
                        logger.error(
                            "webhook.delivery.persist_failed",
                            webhook_id=webhook.id,
                            delivery_id=attempt_delivery_id,
                            error=str(persist_err),
                            exc_info=True,
                        )
                    return  # delivered successfully (terminal)

            except httpx.TimeoutException:
                response_time_ms = int((time.time() - attempt_start) * 1000)
                delivery.status = "failed"
                delivery.error = "Request timeout"
                delivery.response_time_ms = response_time_ms
                webhook_deliveries_total.add(1, {"webhook_id": webhook.id, "status": "failed"})
                # bug-19: treat client-side timeout as transient — the
                # endpoint may be transiently slow, not permanently dead.
                transient_reason = "timeout"
                logger.warning(
                    "webhook.delivery.timeout_will_retry",
                    webhook_id=webhook.id,
                    delivery_id=attempt_delivery_id,
                    attempt=attempt + 1,
                    max_attempts=self.MAX_DELIVERY_ATTEMPTS,
                )

            except (httpx.ConnectError, httpx.ReadError, httpx.WriteError, httpx.RemoteProtocolError) as e:
                # bug-19: connection-level errors are transient by
                # definition — DNS hiccup, TCP reset, partial write,
                # protocol violation from a load balancer in flux.
                response_time_ms = int((time.time() - attempt_start) * 1000)
                delivery.status = "failed"
                delivery.error = str(e)
                delivery.response_time_ms = response_time_ms
                webhook_deliveries_total.add(1, {"webhook_id": webhook.id, "status": "failed"})
                transient_reason = type(e).__name__
                logger.warning(
                    "webhook.delivery.connection_will_retry",
                    webhook_id=webhook.id,
                    delivery_id=attempt_delivery_id,
                    attempt=attempt + 1,
                    max_attempts=self.MAX_DELIVERY_ATTEMPTS,
                    error=str(e),
                    error_type=type(e).__name__,
                )

            except httpx.RequestError as e:
                # Other RequestError subclasses (e.g. InvalidURL,
                # UnsupportedProtocol, TooManyRedirects) are
                # *configuration* errors — retrying does not help.
                response_time_ms = int((time.time() - attempt_start) * 1000)
                delivery.status = "failed"
                delivery.error = str(e)
                delivery.response_time_ms = response_time_ms
                webhook_deliveries_total.add(1, {"webhook_id": webhook.id, "status": "failed"})
                logger.error(
                    "webhook.delivery.failed",
                    webhook_id=webhook.id,
                    delivery_id=attempt_delivery_id,
                    error=str(e),
                    error_type=type(e).__name__,
                    status_code=None,
                )

            except Exception as e:
                response_time_ms = int((time.time() - attempt_start) * 1000)
                delivery.status = "failed"
                delivery.error = str(e)
                delivery.response_time_ms = response_time_ms
                webhook_deliveries_total.add(1, {"webhook_id": webhook.id, "status": "failed"})
                logger.error(
                    "webhook.delivery.failed",
                    webhook_id=webhook.id,
                    delivery_id=attempt_delivery_id,
                    error=str(e),
                    error_type=type(e).__name__,
                    status_code=None,
                )

            # bug-19: shared retry / persist tail for both transient
            # status codes (handled above without raising) and
            # transient transport errors caught in the except blocks.
            if transient_reason and attempt < self.MAX_DELIVERY_ATTEMPTS - 1:
                # Transport-level transients still need their delivery
                # record persisted so operators can audit retry storms.
                # The status-code branch already persisted before
                # setting transient_reason, so we only persist here for
                # the transport branches. We detect that by looking at
                # delivery.status_code: transport errors leave it None.
                if delivery.status_code is None:
                    try:
                        await self.delivery_repository.create_delivery(delivery)
                    except Exception as persist_err:
                        logger.error(
                            "webhook.delivery.persist_failed",
                            webhook_id=webhook.id,
                            delivery_id=attempt_delivery_id,
                            error=str(persist_err),
                        )
                backoff = self.RETRY_BACKOFF_BASE * (2 ** attempt)
                await asyncio.sleep(backoff)
                continue  # retry

            # Either non-transient failure or final attempt exhausted —
            # persist the terminal failure record and stop.
            # C-2: best-effort persist.
            if delivery.status_code is None:
                # Transport-error path — record not yet written.
                try:
                    await self.delivery_repository.create_delivery(delivery)
                except Exception as persist_err:
                    webhook_deliveries_total.add(1, {"webhook_id": webhook.id, "status": "persist_failed"})
                    logger.error(
                        "webhook.delivery.persist_failed",
                        webhook_id=webhook.id,
                        delivery_id=attempt_delivery_id,
                        error=str(persist_err),
                        exc_info=True,
                    )
            # bug-20: record delivery duration on EVERY terminal outcome
            # — success AND retry-exhausted failure — so the histogram
            # reflects real wall time (including all retries) rather
            # than only the green path. Without this, p99 latency
            # graphs are dominated by lucky deliveries and operators
            # cannot see retry storms.
            webhook_delivery_duration.record(
                time.time() - start_time,
                {
                    "webhook_id": webhook.id,
                    "status": "failed",
                    "transient": "true" if transient_reason else "false",
                },
            )
            if transient_reason:
                logger.error(
                    "webhook.delivery.retries_exhausted",
                    webhook_id=webhook.id,
                    delivery_id=attempt_delivery_id,
                    attempt=attempt + 1,
                    max_attempts=self.MAX_DELIVERY_ATTEMPTS,
                    last_error=delivery.error,
                    last_status_code=delivery.status_code,
                    transient_reason=transient_reason,
                )
            return  # terminal — stop the for-loop

    async def _build_payload(
        self,
        webhook: Webhook,
        event: WebhookEvent,
        delivery_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build webhook payload from event with data filtering applied.

        Args:
            webhook: Webhook instance (contains data_filters)
            event: WebhookEvent instance

        Returns:
            Filtered payload dictionary
        """
        # Load artifacts if thread_id is available and database is available
        artifacts: Optional[List[Any]] = None
        if event.thread_id and self.database:
            try:
                artifacts = await self.database.get_thread_artifacts(event.thread_id)
            except Exception as e:
                logger.warning(
                    "webhook.payload.artifacts_load_failed",
                    thread_id=event.thread_id,
                    error=str(e),
                )

        # Build payload with data filtering
        payload = build_webhook_payload(
            event_type=event.event_type,
            timestamp=event.timestamp.isoformat().replace("+00:00", "Z"),
            thread_id=event.thread_id,
            run_id=event.run_id,
            thread=event.thread,
            metadata=event.metadata,
            artifacts=artifacts,
            data_filters=webhook.data_filters,
            file_storage=self.file_storage,
            delivery_id=delivery_id,
            webhook_id=webhook.id,
        )

        return payload

