"""Nexora Tasks Server version information.

The server package has its own version, independent of the SDK. The sidebar
(and `/health`) surface this value so operators can tell which server build
they are running regardless of the SDK wheel installed alongside it.
"""

from importlib.metadata import version, PackageNotFoundError
import tomllib
from pathlib import Path


def _get_version() -> str:
    """Resolve the server package version.

    Lookup order (first hit wins):

    1. ``pyproject.toml`` at the server package root (development / source).
    2. Installed distribution metadata for ``nexora-tasks-server``.
    3. Literal fallback ``"dev"``.
    """
    try:
        # packages/server/src/nexora_tasks_server/version.py
        # → packages/server/pyproject.toml is 3 levels up.
        pyproject_path = Path(__file__).resolve().parents[3] / "pyproject.toml"
        if pyproject_path.exists():
            with open(pyproject_path, "rb") as f:
                data = tomllib.load(f)
                ver = data.get("project", {}).get("version")
                if ver:
                    return ver
    except Exception:
        pass

    try:
        return version("nexora-tasks-server")
    except PackageNotFoundError:
        pass

    return "dev"


__version__ = _get_version()
VERSION = __version__


def get_server_version() -> str:
    """Return the server package version string."""
    return __version__


def get_version_info() -> dict:
    """Return a dict describing the server version, for diagnostic endpoints."""
    return {
        "version": __version__,
        "name": "nexora-tasks-server",
    }
