"""OpenAPI metadata (description + tag list) for the Nexora Tasks API.

Extracted from ``server.py`` (M-11) so ``create_server`` stays small.
Pure data — no runtime side effects.
"""

from __future__ import annotations

from typing import Any, Dict, List


API_DESCRIPTION = """
## Overview

Nexora Tasks is a production-ready platform for building, deploying, and managing tasks in Python and Node.js.
Tasks are packaged, deployed, and executed in isolated subprocess workers with full lifecycle control.

## Task Execution

- **Deploy** task packages (zip) via the Admin API or `task deploy` CLI
- **Execute** tasks by creating threads — each thread runs a task with inputs and produces outputs
- **Monitor** progress in real-time via polling or webhooks
- **Control** running threads: pause, resume, stop, retry

## Execution Modes

- `sync` — wait for completion and return results in the response
- `async` — return immediately with a thread ID, poll `GET /threads/{id}` for results

## Authentication

All endpoints require an `X-API-Key` header:
- **API keys**: Thread and resource operations (also require `X-App-Id` and `X-User-Id` headers)
- **Admin keys**: Full access including task deployment, credentials, and settings

**Public endpoints** (no authentication):
- `GET /health` — Health check
- `GET /task/metadata` — Task schema discovery

> **Metrics:** the in-app Prometheus endpoint has been removed. Metrics are
> exported via OTLP to the OpenTelemetry Collector; scrape the Collector at
> ``http://otel-collector:8889/metrics``.

## Error Handling

All errors follow [RFC 7807 Problem Details](https://tools.ietf.org/html/rfc7807) format.
"""


OPENAPI_TAGS: List[Dict[str, Any]] = [
    {
        "name": "health",
        "description": "Health check and monitoring. Includes server health status.",
    },
    {
        "name": "threads",
        "description": "Thread execution management. Create, list, stop, pause, resume, and retry task executions. "
                       "Threads are the primary execution unit — each thread runs a task with specific inputs and produces outputs.",
    },
    {
        "name": "artifacts",
        "description": "Artifact management. Query, download, archive, and delete task input/output artifacts. "
                       "Artifacts can be text, JSON, or file references.",
    },
    {
        "name": "files",
        "description": "File storage operations. Upload and download files used as task inputs or outputs.",
    },
    {
        "name": "schedules",
        "description": "Schedule management. Create and manage recurring task executions using cron expressions.",
    },
    {
        "name": "runs",
        "description": "Schedule run history. View individual execution runs triggered by schedules.",
    },
    {
        "name": "webhooks",
        "description": "Webhook configuration and delivery tracking. "
                       "Subscribe to thread lifecycle events (created, succeeded, failed, etc.) with HMAC-SHA256 signed payloads.",
    },
    {
        "name": "admin-tasks",
        "description": "**Admin only.** Task definition management. Deploy, list, download, and undeploy task packages (zip).",
    },
    {
        "name": "admin-credentials",
        "description": "**Admin only.** Credential vault and task configuration. "
                       "Manage encrypted secrets and per-task configuration values.",
    },
    {
        "name": "admin-settings",
        "description": "**Admin only.** System settings. Configure thread concurrency limits and other runtime parameters.",
    },
    {
        "name": "metadata",
        "description": "Task metadata discovery. Get deployed task schemas, capabilities, and version information.",
    },
    {
        "name": "proxy-admin",
        "description": "**Admin only.** Proxy server management. Enroll, update, and remove backend task servers.",
    },
    {
        "name": "proxy-discovery",
        "description": "Proxy server discovery. List enrolled servers and their capabilities.",
    },
    {
        "name": "admin-environments",
        "description": "**Admin only.** Environment management for multi-environment deployments. "
                       "Create and manage environments (dev, staging, prod), bind API keys, "
                       "activate task versions, promote across environments, and rollback.",
    },
    {
        "name": "admin-metrics",
        "description": "**Admin only.** Server and task metrics in JSON format. "
                       "Provides thread counts, execution duration statistics, worker status, "
                       "and error breakdowns from the in-process Prometheus registry.",
    },
    {
        "name": "admin-health",
        "description": "**Admin only.** Detailed server health check with subsystem statuses "
                       "for database, storage, scheduler, workers, and observability.",
    },
]
