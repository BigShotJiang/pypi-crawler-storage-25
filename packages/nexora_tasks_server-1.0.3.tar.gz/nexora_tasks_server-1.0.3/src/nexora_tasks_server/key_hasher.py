"""API key hashing helpers.

F-5: the plain ``framework.api_keys`` / ``framework.admin_api_keys``
lists previously kept every configured key as a plaintext string for the
life of the process. A dump of process memory (or a core file) would
surface every key in the clear.

We instead hash each key once at startup using HMAC-SHA256 over a fixed
server-local salt and keep only the digests in memory. Verification
hashes the incoming candidate and compares against the stored digests
with :func:`hmac.compare_digest`, which is both timing-safe and
considerably faster than PBKDF2 on the request path (API keys are
high-entropy random tokens, so a fast hash is sufficient — rainbow /
brute-force attacks against 32-byte random keys are infeasible).

The salt is fixed per build; we do *not* use a per-key random salt
because we need O(N) comparison against N stored hashes without knowing
which one a given candidate might be.
"""

from __future__ import annotations

import hashlib
import hmac
from typing import Iterable, List


# Fixed per-build pepper. Not a real secret — the point is simply to make
# ``hash_key("abc")`` not collide with SHA-256("abc") from a generic
# rainbow table. Changing this value invalidates previously stored
# hashes, but framework-level hashes are in-memory only (rebuilt every
# startup from the env vars), so this is safe to change at any time.
_KEY_HASH_SALT = b"nexora-tasks-api-key-salt-v1"


def hash_key(plaintext: str) -> bytes:
    """Return the 32-byte HMAC-SHA256 digest of an API key plaintext."""
    return hmac.new(_KEY_HASH_SALT, plaintext.encode("utf-8"), hashlib.sha256).digest()


def hash_keys(plaintexts: Iterable[str]) -> List[bytes]:
    """Hash an iterable of plaintext keys, dropping empty/None entries."""
    return [hash_key(k) for k in plaintexts if k]


def constant_time_hash_in(candidate: str, stored_hashes: Iterable[bytes]) -> bool:
    """Timing-safe membership check of ``candidate`` against pre-hashed keys.

    Always iterates the full list (no early return) so the comparison
    time does not reveal which hash (if any) matched, and uses
    :func:`hmac.compare_digest` for the per-hash comparison.
    """
    candidate_hash = hash_key(candidate)
    matched = False
    for stored in stored_hashes:
        if hmac.compare_digest(candidate_hash, stored):
            matched = True
    return matched
