"""Inline FastAPI dev-server bootstrap (formerly in SDK CLI ``run.py``).

C-7 cycle break — moving this module to the server package removes the
last hard ``from nexora_tasks_server.*`` import from the SDK source tree.
The SDK CLI imports :func:`run_dev_server` lazily and reports a clear
``ImportError`` message when the server package is not installed.
"""

from __future__ import annotations

import asyncio
import os
import sys
import traceback
from pathlib import Path
from typing import Callable, Optional

from nexora_tasks_server.framework import NexoraTasks
from nexora_tasks_server.repositories.file_db import FileDatabase
from nexora_tasks_server.scheduler.scheduler import Scheduler
from nexora_tasks_server.server import create_server
from nexora_tasks_server.storage.local import LocalFileStorage


def run_dev_server(
    task_dir: Path,
    task_function: Optional[Callable] = None,
    port: int = 3000,
    open_browser: bool = False,
    api_keys: Optional[list] = None,
    admin_api_keys: Optional[list] = None,
) -> None:
    """Boot a local FastAPI dev server with the supplied task deployed.

    This is the function that used to live inline in
    ``nexora_tasks.cli.commands.run.run_task`` (lines 203-308 pre-refactor).
    All server imports are now contained here so the SDK never depends on
    ``nexora_tasks_server`` at import time.

    Args:
        task_dir: Directory containing the task source (``task.yaml``,
            entry-point module, ``.env`` etc.). Used to derive the data dir
            (``test-data/data``) when ``BASE_PATH`` / ``DATA_DIR`` are not
            set.
        task_function: Already-loaded task callable (used by ``LocalRunner``);
            currently unused inside this function but kept in the signature
            so future deployment paths can register the function in-process
            without re-importing.
        port: TCP port for ``uvicorn.run`` (default ``3000``).
        open_browser: Open the Web UI in the default browser shortly after
            startup. Disabled by default since most invocations are tests.
        api_keys: List of regular API keys (defaults from env: ``API_KEYS``
            CSV → fallback ``["dev-key"]``).
        admin_api_keys: Same as ``api_keys`` but for admin keys (env:
            ``ADMIN_API_KEYS`` CSV → fallback ``["admin-key"]``).
    """
    import uvicorn

    if api_keys is None:
        api_keys = [k.strip() for k in os.getenv("API_KEYS", "dev-key").split(",") if k.strip()]
    if admin_api_keys is None:
        admin_api_keys = [
            k.strip() for k in os.getenv("ADMIN_API_KEYS", "admin-key").split(",") if k.strip()
        ]

    print("Initializing database and storage...")
    # Honour BASE_PATH / DATA_DIR env vars so tests (e.g. graceful-shutdown
    # durability test) can isolate multiple server instances.
    _base_path_env = os.environ.get("BASE_PATH") or os.environ.get("DATA_DIR")
    if _base_path_env:
        data_dir = Path(_base_path_env)
        test_data_dir = data_dir.parent
    else:
        test_data_dir = task_dir / "test-data"
        data_dir = test_data_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    database = FileDatabase(base_path=str(data_dir))
    file_storage = LocalFileStorage(base_path=str(data_dir / "storage"))
    scheduler = Scheduler()

    print(f"  Test data directory: {test_data_dir}")
    print(f"  Data directory: {data_dir}")
    print()

    print("Initializing Nexora Tasks...")
    framework = NexoraTasks(
        api_keys=api_keys,
        admin_api_keys=admin_api_keys,
        database=database,
        file_storage=file_storage,
        scheduler=scheduler,
        base_path=str(test_data_dir),
    )

    print("Deploying task from source...")

    async def deploy_and_run():
        try:
            task_def = await framework.deploy_dev_task(str(task_dir))
            print(f"  ✓ Task deployed: {task_def.task_id}:{task_def.version}")
            return task_def
        except Exception as e:
            print(f"ERROR: Deployment failed: {e}")
            traceback.print_exc()
            sys.exit(1)

    asyncio.run(deploy_and_run())
    print()

    print("=" * 70)
    print("Local Development Server Started!")
    print("=" * 70)
    print()
    print(f"  Server URL:  http://localhost:{port}")
    print(f"  Web UI:      http://localhost:{port}/ui")
    print(f"  API Docs:    http://localhost:{port}/docs")
    print(f"  Health:      http://localhost:{port}/health")
    print(f"  Metrics:     http://localhost:{port}/metrics")
    print()
    print("Authentication:")
    print(f"  API Key:     {api_keys[0]}")
    print(f"  Admin Key:   {admin_api_keys[0]}")
    print()
    print("✓ Task deployed and ready to test!")

    print("Quick Test via API:")
    print(f'  curl -X POST http://localhost:{port}/threads \\')
    print(f'    -H "X-API-Key: {api_keys[0]}" \\')
    print('    -H "X-User-Id: dev-user" \\')
    print('    -H "X-App-Id: local-dev" \\')
    print('    -H "Content-Type: application/json" \\')
    print('    -d \'{"mode": "sync", "inputs": [{"kind": "text", "text": "Hello World"}]}\'')
    print()
    print("Or open the Web UI to test your task:")
    print(f"  → http://localhost:{port}/ui")
    print()
    print("Press Ctrl+C to stop the server")
    print("=" * 70)
    print()

    if open_browser:
        import threading
        import time
        import webbrowser

        def open_ui():
            time.sleep(1.5)
            url = f"http://localhost:{port}/ui"
            print(f"Opening browser: {url}")
            webbrowser.open(url)

        threading.Thread(target=open_ui, daemon=True).start()

    app = create_server(framework, port=port)
    uvicorn.run(app, host="0.0.0.0", port=port)
