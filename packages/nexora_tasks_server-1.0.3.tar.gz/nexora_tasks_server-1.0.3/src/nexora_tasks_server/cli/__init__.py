"""Server-side CLI helpers callable from the SDK CLI when both packages are installed.

The SDK exposes ``task run`` (see ``nexora_tasks.cli.commands.run``) which
historically inlined the entire FastAPI bootstrap (``NexoraTasks`` ctor,
``FileDatabase``, ``LocalFileStorage``, ``Scheduler``, ``create_server``,
``uvicorn.run``) inside ``run.py:203-308``. That violated the SDK-server
layering and forced a hard ``nexora_tasks_server`` import even when the
SDK was used standalone.

The bootstrap now lives here (``run_inline``) and the SDK CLI imports it
behind a ``try/except ImportError`` guard, surfacing a clear "install the
server package to use task run" message when the server is absent.
"""
