"""Webhook service for managing webhook business logic."""

import ipaddress
import os
import secrets
import socket
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Optional
from urllib.parse import urlparse

from nexora_tasks.logging import logger
from nexora_tasks.models.pagination import Pagination
from nexora_tasks.models.webhook import (
    Webhook,
    WebhookCreateRequest,
    WebhookDelivery,
    WebhookDeliveryListResponse,
    WebhookListResponse,
    WebhookUpdateRequest,
)
from nexora_tasks.models.webhook_scoping import WebhookScope
from nexora_tasks_server.repositories.webhook_db import (
    WebhookDeliveryRepository,
    WebhookRepository,
)


# ── SSRF protection ────────────────────────────────────────────────────────

# Cloud metadata service IPs that must always be blocked (defence in depth).
_METADATA_IPS = frozenset(
    {
        "169.254.169.254",   # AWS / GCP / Azure / DigitalOcean / Alibaba
        "fd00:ec2::254",     # AWS IPv6 metadata
        "100.100.100.200",   # Alibaba Cloud
    }
)


def _allow_internal_urls() -> bool:
    """Whether the SSRF check is disabled via env var."""
    val = os.environ.get("WEBHOOK_ALLOW_INTERNAL_URLS", "").strip().lower()
    return val in ("1", "true", "yes", "on")


def _check_ips_for_ssrf(hostname: str, resolved_ips: set) -> None:
    """Reject ``resolved_ips`` if any of them target an unsafe address.

    Cloud metadata IPs are always blocked. The IP-class checks
    (private/loopback/etc.) honor ``WEBHOOK_ALLOW_INTERNAL_URLS``.
    """
    if not resolved_ips:
        raise ValueError(f"Webhook URL hostname could not be resolved: {hostname}")

    for ip_str in resolved_ips:
        if ip_str in _METADATA_IPS:
            raise ValueError(
                f"Webhook URL resolves to a blocked cloud metadata address ({ip_str})"
            )

    if _allow_internal_urls():
        return

    for ip_str in resolved_ips:
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            raise ValueError(f"Webhook URL resolves to an unparseable address: {ip_str}")

        if (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_reserved
            or ip.is_unspecified
        ):
            raise ValueError(
                f"Webhook URL must point to a public address (got {ip_str} for {hostname})"
            )


def _parse_webhook_url(url: str) -> str:
    """Validate the URL syntax and return the hostname for resolution.

    Raises ``ValueError`` for empty input, unsupported scheme, or missing
    hostname. Does NOT perform DNS resolution — callers run that step
    separately so it can be off-loaded to a thread.
    """
    if not url or not url.strip():
        raise ValueError("Webhook URL must be non-empty")

    parsed = urlparse(url.strip())
    if parsed.scheme not in ("http", "https"):
        raise ValueError("Webhook URL must start with http:// or https://")
    if not parsed.hostname:
        raise ValueError("Webhook URL must have a hostname")
    return parsed.hostname


def validate_webhook_url(url: str) -> None:
    """Synchronous SSRF validator (DNS resolution blocks the caller).

    Use :func:`validate_webhook_url_async` from any async context. This
    sync variant exists for the dispatch path inside the delivery engine,
    which already runs the HTTP call in an executor, and for tests.

    Performs the following checks:

    1. URL must parse with an http/https scheme and a hostname.
    2. Hostname must resolve to at least one IP via ``getaddrinfo``.
    3. None of the resolved IPs may be private, loopback, link-local,
       multicast, reserved, or unspecified (both IPv4 and IPv6).
    4. Cloud metadata service IPs are always blocked.

    Set ``WEBHOOK_ALLOW_INTERNAL_URLS=true`` to disable the IP-class checks
    for on-prem / development scenarios. The literal metadata IP block is
    NEVER bypassed.

    Raises:
        ValueError: If the URL is invalid or targets a non-public address.
    """
    hostname = _parse_webhook_url(url)
    try:
        addrinfo = socket.getaddrinfo(hostname, None)
    except socket.gaierror as e:
        raise ValueError(f"Webhook URL hostname could not be resolved: {hostname}") from e
    resolved_ips = {info[4][0] for info in addrinfo}
    _check_ips_for_ssrf(hostname, resolved_ips)


async def validate_webhook_url_async(url: str) -> None:
    """Async SSRF validator that off-loads DNS resolution to a thread.

    Same semantics as :func:`validate_webhook_url`, but safe to call from
    inside FastAPI request handlers without blocking the event loop on
    DNS lookups (which can take seconds for unreachable hosts).
    """
    import asyncio

    hostname = _parse_webhook_url(url)
    try:
        addrinfo = await asyncio.to_thread(socket.getaddrinfo, hostname, None)
    except socket.gaierror as e:
        raise ValueError(f"Webhook URL hostname could not be resolved: {hostname}") from e
    resolved_ips = {info[4][0] for info in addrinfo}
    _check_ips_for_ssrf(hostname, resolved_ips)


async def resolve_and_validate_webhook_url(url: str) -> tuple[str, str]:
    """Resolve ``url`` once, run the SSRF check on the IP, and pin it.

    bug-5 / M-5: between :func:`validate_webhook_url_async` and the
    subsequent ``httpx`` request, ``httpx`` re-resolves DNS — a DNS
    rebinding attacker can return a public IP for the SSRF check and
    a private/metadata IP for the actual connect. By returning the
    validated IP here and asking the caller to send the request to
    that IP (with the original ``Host`` header so virtual hosting and
    TLS SNI still work), we close the rebinding window.

    Returns:
        ``(hostname, resolved_ip)`` — the original hostname (for the
        ``Host`` header / TLS SNI) and the IP literal the caller must
        connect to.

    Raises:
        ValueError: same conditions as :func:`validate_webhook_url_async`.
    """
    import asyncio

    hostname = _parse_webhook_url(url)
    try:
        addrinfo = await asyncio.to_thread(socket.getaddrinfo, hostname, None)
    except socket.gaierror as e:
        raise ValueError(f"Webhook URL hostname could not be resolved: {hostname}") from e
    resolved_ips = {info[4][0] for info in addrinfo}
    _check_ips_for_ssrf(hostname, resolved_ips)

    # Pick the first IP deterministically. ``getaddrinfo`` already returned
    # the OS-preferred order (typically IPv6 first, then IPv4) — we don't
    # want to randomise it because that would hide DNS misconfiguration.
    # All resolved IPs were validated, so any of them is safe to pin.
    pinned_ip = next(iter(addrinfo))[4][0]
    return hostname, pinned_ip


# Log the opt-out exactly once at import time so operators know if SSRF is off.
if _allow_internal_urls():
    logger.warning(
        "webhook.ssrf_protection_disabled",
        env_var="WEBHOOK_ALLOW_INTERNAL_URLS",
        message=(
            "Webhook SSRF protection disabled — webhooks may target internal "
            "addresses. Cloud metadata IPs remain blocked."
        ),
    )

if TYPE_CHECKING:
    pass


def generate_webhook_secret() -> str:
    """Generate a secure webhook secret.

    Returns:
        Base64-encoded secret string prefixed with 'whsec_'
    """
    # Generate 32 bytes of random data
    random_bytes = secrets.token_bytes(32)
    # Encode as base64url (safe for URLs)
    import base64

    secret_b64 = base64.urlsafe_b64encode(random_bytes).decode("ascii")
    # Prefix with 'whsec_' for identification
    return f"whsec_{secret_b64}"


class WebhookService:
    """Service layer for webhook management operations."""

    def __init__(
        self,
        webhook_repository: WebhookRepository,
        delivery_repository: WebhookDeliveryRepository,
    ) -> None:
        """Initialize WebhookService.

        Args:
            webhook_repository: WebhookRepository implementation
            delivery_repository: WebhookDeliveryRepository implementation
        """
        self.webhook_repository = webhook_repository
        self.delivery_repository = delivery_repository

    def validate_url(self, url: str) -> None:
        """Validate webhook URL format and reject SSRF targets (sync).

        DNS resolution blocks the caller; do not use from inside an
        ``async def`` route handler. ``validate_url_async`` exists for
        that case.
        """
        validate_webhook_url(url)

    async def validate_url_async(self, url: str) -> None:
        """Async SSRF validator that off-loads DNS resolution to a thread."""
        await validate_webhook_url_async(url)

    async def create_webhook(
        self,
        request: WebhookCreateRequest,
        created_by: Optional[str] = None,
        source: str = "manual",
        user_id: Optional[str] = None,
        app_id: Optional[str] = None,
        environment_id: str = "default",
    ) -> Webhook:
        """Create a new webhook.

        Args:
            request: Webhook creation request
            created_by: User/app identifier that created webhook
            source: Webhook source type: 'manual', 'thread', or 'schedule'

        Returns:
            Created Webhook instance with generated secret

        Raises:
            ValueError: If URL validation fails
        """
        # Validate URL
        await self.validate_url_async(request.url)

        # Generate webhook ID
        from nexora_tasks.utils.id_generator import generate_webhook_id
        webhook_id = generate_webhook_id()

        # Generate secret
        secret = generate_webhook_secret()

        # Create webhook
        now = datetime.now(timezone.utc)
        webhook = Webhook(
            id=webhook_id,
            url=request.url,
            secret=secret,
            enabled=request.enabled,
            events=request.events,
            data_filters=request.data_filters,
            scope=request.scope,
            timeout_seconds=request.timeout_seconds or 10,
            api_key=request.api_key,
            task_id=request.task_id,
            task_version=request.task_version,
            source=source,
            created_at=now,
            updated_at=now,
            created_by=created_by,
            created_by_user_id=user_id,
            created_by_app_id=app_id,
            environment_id=environment_id,
            metadata={},
        )

        # Store webhook
        await self.webhook_repository.create_webhook(webhook)

        logger.info(
            "webhook.created",
            webhook_id=webhook_id,
            url=request.url,
            enabled=request.enabled,
            source=source,
            created_by=created_by,
        )

        return webhook

    async def get_webhook(self, webhook_id: str) -> Optional[Webhook]:
        """Get a webhook by ID.

        Args:
            webhook_id: Webhook identifier

        Returns:
            Webhook instance if found, None otherwise
        """
        return await self.webhook_repository.get_webhook(webhook_id)

    async def list_webhooks(
        self,
        is_enabled: Optional[bool] = None,
        task_id: Optional[str] = None,
        task_version: Optional[str] = None,
        source: Optional[str] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
        offset: Optional[int] = None,
    ) -> WebhookListResponse:
        """List webhooks with optional filtering.

        Args:
            is_enabled: Filter by enabled status
            task_id: Filter by task ID
            task_version: Filter by task version
            source: Filter by webhook source (manual, thread, schedule)
            limit: Maximum number of results (default: 50)
            cursor: Pagination cursor
            offset: Offset for pagination (alternative to cursor)

        Returns:
            WebhookListResponse with paginated results
        """
        filters: Dict[str, Any] = {}
        if is_enabled is not None:
            filters["is_enabled"] = is_enabled
        if task_id is not None:
            filters["task_id"] = task_id
        if task_version is not None:
            filters["task_version"] = task_version
        if source is not None:
            filters["source"] = source

        # Get all webhooks (before pagination)
        webhooks = await self.webhook_repository.list_webhooks(filters)

        # Apply cursor-based pagination
        limit = limit or 50
        
        if cursor:
            # Decode cursor (Base64 JSON with webhook_id and created_at)
            import base64
            import json as json_lib
            
            try:
                cursor_data = json_lib.loads(base64.b64decode(cursor).decode())
                cursor_webhook_id = cursor_data.get("webhook_id")
                cursor_created_at = cursor_data.get("created_at")
                
                # Filter webhooks after cursor
                if cursor_created_at:
                    from datetime import datetime
                    cursor_time = datetime.fromisoformat(cursor_created_at.replace("Z", "+00:00"))
                    webhooks = [w for w in webhooks if w.created_at < cursor_time]
            except (ValueError, KeyError, TypeError):
                # Invalid cursor, return empty
                webhooks = []
        
        # Offset-based pagination fallback
        elif offset is not None:
            webhooks = webhooks[offset:]
        
        # Apply limit
        has_more = len(webhooks) > limit
        webhooks = webhooks[:limit]
        
        # Generate next cursor if has_more
        next_cursor = None
        if has_more and webhooks:
            import base64
            import json as json_lib
            
            last_webhook = webhooks[-1]
            cursor_data = {
                "webhook_id": last_webhook.id,
                "created_at": last_webhook.created_at.isoformat().replace("+00:00", "Z"),
            }
            next_cursor = base64.b64encode(json_lib.dumps(cursor_data).encode()).decode()
        
        pagination = Pagination(
            cursor=next_cursor,
            has_more=has_more,
            total=None,
        )

        return WebhookListResponse(items=webhooks, pagination=pagination)

    async def update_webhook(
        self,
        webhook_id: str,
        request: WebhookUpdateRequest,
    ) -> Webhook:
        """Update an existing webhook.

        Args:
            webhook_id: Webhook identifier
            request: Webhook update request (partial)

        Returns:
            Updated Webhook instance

        Raises:
            ValueError: If webhook not found or validation fails
        """
        webhook = await self.webhook_repository.get_webhook(webhook_id)
        if not webhook:
            raise ValueError(f"Webhook {webhook_id} not found")

        # Validate URL if provided
        if request.url:
            await self.validate_url_async(request.url)

        # Apply updates
        if request.url is not None:
            webhook.url = request.url
        if request.enabled is not None:
            webhook.enabled = request.enabled
        if request.events is not None:
            webhook.events = request.events
        if request.data_filters is not None:
            webhook.data_filters = request.data_filters
        if request.scope is not None:
            webhook.scope = request.scope
        if request.timeout_seconds is not None:
            webhook.timeout_seconds = request.timeout_seconds
        if request.api_key is not None:
            webhook.api_key = request.api_key
        if request.task_id is not None:
            webhook.task_id = request.task_id
        if request.task_version is not None:
            webhook.task_version = request.task_version

        # Update timestamp
        webhook.updated_at = datetime.now(timezone.utc)

        # Store updated webhook
        await self.webhook_repository.update_webhook(webhook)

        logger.info(
            "webhook.updated",
            webhook_id=webhook_id,
            enabled=webhook.enabled,
        )

        return webhook

    async def delete_webhook(self, webhook_id: str) -> None:
        """Delete a webhook.

        Args:
            webhook_id: Webhook identifier to delete

        Raises:
            ValueError: If webhook not found
        """
        webhook = await self.webhook_repository.get_webhook(webhook_id)
        if not webhook:
            raise ValueError(f"Webhook {webhook_id} not found")

        await self.webhook_repository.delete_webhook(webhook_id)

        logger.info("webhook.deleted", webhook_id=webhook_id)

    async def create_ad_hoc_webhook(
        self,
        url: str,
        thread_id: str,
        events: Optional[List[str]] = None,
        created_by: Optional[str] = None,
        api_key: Optional[str] = None,
        user_id: Optional[str] = None,
        app_id: Optional[str] = None,
        environment_id: str = "default",
    ) -> Webhook:
        """Create an ad-hoc webhook with thread-scoped scope.

        Args:
            url: Webhook delivery URL
            thread_id: Thread identifier for scoping
            events: Optional list of event types (default: all events)
            created_by: User/app identifier that created webhook
            api_key: Optional X-API-Key header for webhook delivery requests

        Returns:
            Created Webhook instance with thread-scoped scope

        Raises:
            ValueError: If URL validation fails
        """
        # Validate URL
        await self.validate_url_async(url)

        # Create event filters if events specified
        event_filters = None
        if events:
            from nexora_tasks.models.webhook import EventFilters

            event_filters = EventFilters(include=events)

        # Create thread-scoped scope
        scope = WebhookScope(thread_id=thread_id)

        # Create webhook request
        request = WebhookCreateRequest(
            url=url,
            events=event_filters,
            scope=scope,
            enabled=True,
            timeout_seconds=10,
            api_key=api_key,
        )

        # Create webhook with source='thread'
        return await self.create_webhook(
            request,
            created_by=created_by,
            source="thread",
            user_id=user_id,
            app_id=app_id,
            environment_id=environment_id,
        )

    async def create_schedule_webhook(
        self,
        url: str,
        schedule_id: str,
        events: Optional[List[str]] = None,
        created_by: Optional[str] = None,
        api_key: Optional[str] = None,
        user_id: Optional[str] = None,
        app_id: Optional[str] = None,
        environment_id: str = "default",
    ) -> Webhook:
        """Create a webhook for a schedule with schedule-scoped scope.

        Args:
            url: Webhook delivery URL
            schedule_id: Schedule identifier for scoping
            events: Optional list of event types (default: all events)
            created_by: User/app identifier that created webhook
            api_key: Optional X-API-Key header for webhook delivery requests

        Returns:
            Created Webhook instance with schedule-scoped scope

        Raises:
            ValueError: If URL validation fails
        """
        # Validate URL
        await self.validate_url_async(url)

        # Create event filters if events specified
        event_filters = None
        if events:
            from nexora_tasks.models.webhook import EventFilters

            event_filters = EventFilters(include=events)

        # Create schedule-scoped scope
        scope = WebhookScope(schedule_id=schedule_id)

        # Create webhook request
        request = WebhookCreateRequest(
            url=url,
            events=event_filters,
            scope=scope,
            enabled=True,
            timeout_seconds=10,
            api_key=api_key,
        )

        # Create webhook with source='schedule'
        return await self.create_webhook(
            request,
            created_by=created_by,
            source="schedule",
            user_id=user_id,
            app_id=app_id,
            environment_id=environment_id,
        )

    async def regenerate_secret(self, webhook_id: str) -> Webhook:
        """Regenerate webhook secret.

        Args:
            webhook_id: Webhook identifier

        Returns:
            Updated Webhook instance with new secret

        Raises:
            ValueError: If webhook not found
        """
        webhook = await self.webhook_repository.get_webhook(webhook_id)
        if not webhook:
            raise ValueError(f"Webhook {webhook_id} not found")

        # Generate new secret
        webhook.secret = generate_webhook_secret()
        webhook.updated_at = datetime.now(timezone.utc)

        # Store updated webhook
        await self.webhook_repository.update_webhook(webhook)

        logger.info("webhook.secret_regenerated", webhook_id=webhook_id)

        return webhook

    async def get_matching_webhooks(
        self,
        event_type: str,
        thread_id: Optional[str] = None,
        run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> List[Webhook]:
        """Get webhooks that match an event based on scope and event filters.

        Args:
            event_type: Event type (e.g., "thread.succeeded")
            thread_id: Thread identifier (if applicable)
            run_id: Run identifier (if applicable)
            metadata: Event metadata (for scope matching)

        Returns:
            List of matching Webhook instances
        """
        from nexora_tasks_server.delivery.filter import should_deliver_webhook

        # Get all enabled webhooks
        all_webhooks = await self.webhook_repository.list_webhooks(filters={"is_enabled": True})

        matching_webhooks: List[Webhook] = []
        event_metadata = metadata or {}

        for webhook in all_webhooks:
            if should_deliver_webhook(webhook, event_type, event_metadata, thread_id):
                matching_webhooks.append(webhook)

        return matching_webhooks

    async def list_deliveries(
        self,
        webhook_id: str,
        status: Optional[str] = None,
        thread_id: Optional[str] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
        offset: Optional[int] = None,
    ) -> WebhookDeliveryListResponse:
        """List delivery records for a webhook.

        Args:
            webhook_id: Webhook identifier
            status: Filter by delivery status ("success" | "failed")
            thread_id: Filter by thread ID
            limit: Maximum number of results (default: 50)
            cursor: Pagination cursor
            offset: Offset for pagination (alternative to cursor)

        Returns:
            WebhookDeliveryListResponse with paginated results
        """
        filters: Dict[str, Any] = {}
        if status:
            filters["status"] = status
        if thread_id:
            filters["thread_id"] = thread_id

        # Get all deliveries (before pagination)
        deliveries = await self.delivery_repository.list_deliveries(webhook_id, filters)

        # Apply cursor-based pagination
        limit = limit or 50
        
        if cursor:
            # Decode cursor (Base64 JSON with delivery_id and timestamp)
            import base64
            import json as json_lib
            
            try:
                cursor_data = json_lib.loads(base64.b64decode(cursor).decode())
                cursor_delivery_id = cursor_data.get("delivery_id")
                cursor_timestamp = cursor_data.get("timestamp")
                
                # Filter deliveries after cursor
                if cursor_timestamp:
                    from datetime import datetime
                    cursor_time = datetime.fromisoformat(cursor_timestamp.replace("Z", "+00:00"))
                    deliveries = [d for d in deliveries if d.timestamp < cursor_time]
            except (ValueError, KeyError, TypeError):
                # Invalid cursor, return empty
                deliveries = []
        
        # Offset-based pagination fallback
        elif offset is not None:
            deliveries = deliveries[offset:]
        
        # Apply limit
        has_more = len(deliveries) > limit
        deliveries = deliveries[:limit]
        
        # Generate next cursor if has_more
        next_cursor = None
        if has_more and deliveries:
            import base64
            import json as json_lib
            
            last_delivery = deliveries[-1]
            cursor_data = {
                "delivery_id": last_delivery.id,
                "timestamp": last_delivery.timestamp.isoformat().replace("+00:00", "Z"),
            }
            next_cursor = base64.b64encode(json_lib.dumps(cursor_data).encode()).decode()
        
        pagination = Pagination(
            cursor=next_cursor,
            has_more=has_more,
            total=None,
        )

        return WebhookDeliveryListResponse(items=deliveries, pagination=pagination)

    async def get_delivery(self, webhook_id: str, delivery_id: str) -> Optional[WebhookDelivery]:
        """Get a delivery record by ID.

        Args:
            webhook_id: Webhook identifier
            delivery_id: Delivery identifier

        Returns:
            WebhookDelivery instance if found, None otherwise
        """
        return await self.delivery_repository.get_delivery(webhook_id, delivery_id)

