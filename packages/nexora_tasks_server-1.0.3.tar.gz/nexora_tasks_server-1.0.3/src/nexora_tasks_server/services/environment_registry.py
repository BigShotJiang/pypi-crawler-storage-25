"""Environment registry for managing environments and task activations.

Handles CRUD for environments, API key → environment resolution, task version
activation per environment, and promotion with linear path enforcement.

Persisted as JSON files under {data_dir}/environments/.
"""

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from nexora_tasks.logging import logger
from nexora_tasks.models.environment import (
    Environment,
    EnvironmentActivation,
    EnvironmentSettings,
    EnvironmentSummary,
    PromotionRecord,
)


class EnvironmentRegistry:
    """Manages environments, API key mapping, task activations, and promotions.

    Data layout on disk:
        {data_dir}/environments/
            registry.json          — list of Environment objects
            activations.json       — {env_id: {task_id: EnvironmentActivation}}
            promotions.json        — list of PromotionRecord objects
    """

    def __init__(self, data_dir: str) -> None:
        self._data_dir = Path(data_dir) / "environments"
        self._data_dir.mkdir(parents=True, exist_ok=True)

        self._registry_file = self._data_dir / "registry.json"
        self._activations_file = self._data_dir / "activations.json"
        self._promotions_file = self._data_dir / "promotions.json"

        # In-memory state
        self._environments: Dict[str, Environment] = {}
        self._key_to_env: Dict[str, str] = {}  # API key → environment_id
        self._admin_key_to_env: Dict[str, str] = {}  # Admin key → environment_id
        self._activations: Dict[str, Dict[str, EnvironmentActivation]] = {}  # env_id → {task_id → activation}
        self._promotions: List[PromotionRecord] = []

        self._loaded = False

    # ── Lifecycle ────────────────────────────────────────────────────────────

    async def ensure_loaded(self) -> None:
        """Load state from disk if not already loaded."""
        if self._loaded:
            return
        await self._load()
        self._loaded = True

    async def ensure_default_environment(self) -> Environment:
        """Ensure a ``default`` environment exists and return it.

        The ``default`` environment is the binding target for legacy,
        unscoped API keys and for admin operations that do not specify
        ``X-Environment``. Fresh installs would otherwise have no
        environment at all, making any activation/promotion flow raise.
        """
        await self.ensure_loaded()
        existing = self._environments.get("default")
        if existing is not None:
            return existing

        default_env = Environment(
            id="default",
            name="Default Environment",
            description="Auto-created default environment for unscoped keys.",
            status="active",
            promotion_order=0,
            api_keys=[],
            admin_api_keys=[],
            settings=EnvironmentSettings(),
        )
        self._environments[default_env.id] = default_env
        await self._save_registry()
        logger.info("environment_registry.default_created")
        return default_env

    async def validate_consistency(self) -> List[str]:
        """Verify that every key-to-environment binding points at a live environment.

        Returns the list of API keys whose binding references an environment
        that no longer exists. Under normal use the lists are populated
        from each environment's own ``api_keys``/``admin_api_keys`` fields
        and should stay consistent, but manual edits to the JSON files or
        partial failures during delete can leave dangling entries. The
        caller logs a warning; we do not raise because a dangling key is
        not a reason to refuse startup — the request-time resolver will
        simply fall through to ``AUTH_INVALID``.
        """
        await self.ensure_loaded()
        dangling: List[str] = []
        for key, env_id in list(self._key_to_env.items()):
            if env_id not in self._environments:
                dangling.append(key)
                del self._key_to_env[key]
        for key, env_id in list(self._admin_key_to_env.items()):
            if env_id not in self._environments:
                dangling.append(key)
                del self._admin_key_to_env[key]
        return dangling

    async def _load(self) -> None:
        """Load all state from JSON files."""
        # Load environments
        if self._registry_file.exists():
            try:
                with open(self._registry_file) as f:
                    data = json.load(f)
                for env_dict in data:
                    env = Environment.model_validate(env_dict)
                    self._environments[env.id] = env
                    for key in env.api_keys:
                        self._key_to_env[key] = env.id
                    for key in env.admin_api_keys:
                        self._admin_key_to_env[key] = env.id
                logger.info("environment_registry.loaded", count=len(self._environments))
            except Exception as e:
                logger.error("environment_registry.load_failed", error=str(e), exc_info=True)

        # Load activations
        if self._activations_file.exists():
            try:
                with open(self._activations_file) as f:
                    data = json.load(f)
                for env_id, task_map in data.items():
                    self._activations[env_id] = {}
                    for task_id, act_dict in task_map.items():
                        self._activations[env_id][task_id] = EnvironmentActivation.model_validate(act_dict)
            except Exception as e:
                logger.error("environment_registry.activations_load_failed", error=str(e), exc_info=True)

        # Load promotions
        if self._promotions_file.exists():
            try:
                with open(self._promotions_file) as f:
                    data = json.load(f)
                self._promotions = [PromotionRecord.model_validate(p) for p in data]
            except Exception as e:
                logger.error("environment_registry.promotions_load_failed", error=str(e), exc_info=True)

    async def _save_registry(self) -> None:
        """Persist environment registry to disk."""
        data = [env.model_dump(mode="json") for env in self._environments.values()]
        with open(self._registry_file, "w") as f:
            json.dump(data, f, indent=2, default=str)

    async def _save_activations(self) -> None:
        """Persist activations to disk."""
        data = {}
        for env_id, task_map in self._activations.items():
            data[env_id] = {
                task_id: act.model_dump(mode="json") for task_id, act in task_map.items()
            }
        with open(self._activations_file, "w") as f:
            json.dump(data, f, indent=2, default=str)

    async def _save_promotions(self) -> None:
        """Persist promotion records to disk."""
        data = [p.model_dump(mode="json") for p in self._promotions]
        with open(self._promotions_file, "w") as f:
            json.dump(data, f, indent=2, default=str)

    # ── Environment CRUD ────────────────────────────────────────────────────

    async def create(self, env: Environment) -> Environment:
        """Create a new environment.

        Args:
            env: Environment to create.

        Returns:
            Created Environment.

        Raises:
            ValueError: If environment ID already exists or API key is already bound.
        """
        await self.ensure_loaded()

        if env.id in self._environments:
            raise ValueError(f"Environment '{env.id}' already exists")

        # Check for API key conflicts
        for key in env.api_keys:
            if key in self._key_to_env:
                raise ValueError(
                    f"API key already bound to environment '{self._key_to_env[key]}'"
                )
        for key in env.admin_api_keys:
            if key in self._admin_key_to_env:
                raise ValueError(
                    f"Admin API key already bound to environment '{self._admin_key_to_env[key]}'"
                )

        # Use promotion_order as provided by the admin (no auto-assignment from name)

        self._environments[env.id] = env
        for key in env.api_keys:
            self._key_to_env[key] = env.id
        for key in env.admin_api_keys:
            self._admin_key_to_env[key] = env.id

        await self._save_registry()

        logger.info("environment_registry.created", environment_id=env.id)
        return env

    async def get(self, env_id: str) -> Optional[Environment]:
        """Get an environment by ID."""
        await self.ensure_loaded()
        return self._environments.get(env_id)

    async def list_all(self) -> List[Environment]:
        """List all environments."""
        await self.ensure_loaded()
        return list(self._environments.values())

    async def list_summaries(self) -> List[EnvironmentSummary]:
        """List environment summaries with active task counts."""
        await self.ensure_loaded()
        summaries = []
        for env in self._environments.values():
            active_tasks = len(self._activations.get(env.id, {}))
            summaries.append(
                EnvironmentSummary(
                    id=env.id,
                    name=env.name,
                    status=env.status,
                    active_tasks=active_tasks,
                    created_at=env.created_at,
                )
            )
        return summaries

    async def update(self, env_id: str, name: Optional[str] = None,
                     description: Optional[str] = None,
                     settings: Optional[EnvironmentSettings] = None,
                     env_status: Optional[str] = None,
                     promotion_order: Optional[int] = None) -> Environment:
        """Update an environment's mutable properties.

        Raises:
            ValueError: If environment not found.
        """
        await self.ensure_loaded()

        env = self._environments.get(env_id)
        if not env:
            raise ValueError(f"Environment '{env_id}' not found")

        # Create updated copy
        update_data = {}
        if name is not None:
            update_data["name"] = name
        if description is not None:
            update_data["description"] = description
        if settings is not None:
            update_data["settings"] = settings
        if env_status is not None:
            update_data["status"] = env_status
        if promotion_order is not None:
            update_data["promotion_order"] = promotion_order

        updated = env.model_copy(update=update_data)
        self._environments[env_id] = updated
        await self._save_registry()

        logger.info("environment_registry.updated", environment_id=env_id)
        return updated

    async def delete(self, env_id: str) -> bool:
        """Delete an environment.

        Raises:
            ValueError: If environment is 'default' (cannot delete).
        """
        await self.ensure_loaded()

        if env_id == "default":
            raise ValueError("Cannot delete the 'default' environment")

        env = self._environments.pop(env_id, None)
        if not env:
            return False

        # Clean up key mappings
        for key in env.api_keys:
            self._key_to_env.pop(key, None)
        for key in env.admin_api_keys:
            self._admin_key_to_env.pop(key, None)

        # Clean up activations
        self._activations.pop(env_id, None)

        await self._save_registry()
        await self._save_activations()

        logger.info("environment_registry.deleted", environment_id=env_id)
        return True

    # ── API Key Management ──────────────────────────────────────────────────

    def find_by_api_key(self, api_key: str) -> Optional[Environment]:
        """Find environment by regular API key. Returns None if not bound."""
        env_id = self._key_to_env.get(api_key)
        if env_id:
            return self._environments.get(env_id)
        return None

    def find_by_admin_key(self, api_key: str) -> Optional[Environment]:
        """Find environment by admin API key. Returns None if not bound."""
        env_id = self._admin_key_to_env.get(api_key)
        if env_id:
            return self._environments.get(env_id)
        return None

    async def add_api_key(self, env_id: str, api_key: str, key_type: str = "regular") -> None:
        """Add an API key to an environment.

        Args:
            env_id: Environment to add the key to.
            api_key: The API key string.
            key_type: 'regular' or 'admin'.

        Raises:
            ValueError: If env not found or key already bound.
        """
        await self.ensure_loaded()

        env = self._environments.get(env_id)
        if not env:
            raise ValueError(f"Environment '{env_id}' not found")

        if key_type == "admin":
            if api_key in self._admin_key_to_env:
                raise ValueError(f"Admin key already bound to '{self._admin_key_to_env[api_key]}'")
            updated_keys = list(env.admin_api_keys) + [api_key]
            self._environments[env_id] = env.model_copy(update={"admin_api_keys": updated_keys})
            self._admin_key_to_env[api_key] = env_id
        else:
            if api_key in self._key_to_env:
                raise ValueError(f"API key already bound to '{self._key_to_env[api_key]}'")
            updated_keys = list(env.api_keys) + [api_key]
            self._environments[env_id] = env.model_copy(update={"api_keys": updated_keys})
            self._key_to_env[api_key] = env_id

        await self._save_registry()
        logger.info("environment_registry.key_added", environment_id=env_id, key_type=key_type)

    async def remove_api_key(self, env_id: str, api_key: str) -> bool:
        """Remove an API key from an environment.

        Returns:
            True if key was found and removed.
        """
        await self.ensure_loaded()

        env = self._environments.get(env_id)
        if not env:
            raise ValueError(f"Environment '{env_id}' not found")

        removed = False

        if api_key in env.api_keys:
            updated_keys = [k for k in env.api_keys if k != api_key]
            self._environments[env_id] = env.model_copy(update={"api_keys": updated_keys})
            self._key_to_env.pop(api_key, None)
            removed = True
        elif api_key in env.admin_api_keys:
            updated_keys = [k for k in env.admin_api_keys if k != api_key]
            self._environments[env_id] = env.model_copy(update={"admin_api_keys": updated_keys})
            self._admin_key_to_env.pop(api_key, None)
            removed = True

        if removed:
            await self._save_registry()
            logger.info("environment_registry.key_removed", environment_id=env_id)

        return removed

    # ── Task Activation ─────────────────────────────────────────────────────

    async def activate_task(
        self, env_id: str, task_id: str, version: str, activated_by: Optional[str] = None
    ) -> EnvironmentActivation:
        """Activate a specific task version in an environment.

        If the task was previously active with a different version, that version
        is recorded as `previous_version` for rollback support.

        Args:
            env_id: Target environment.
            task_id: Task to activate.
            version: Version to make active.
            activated_by: Who performed the activation.

        Returns:
            The EnvironmentActivation record.

        Raises:
            ValueError: If environment not found or environment is suspended.
        """
        await self.ensure_loaded()

        env = self._environments.get(env_id)
        if not env:
            raise ValueError(f"Environment '{env_id}' not found")
        if env.status == "suspended":
            raise ValueError(f"Environment '{env_id}' is suspended")

        # Record previous version for rollback
        previous_version = None
        if env_id in self._activations and task_id in self._activations[env_id]:
            previous_version = self._activations[env_id][task_id].version

        activation = EnvironmentActivation(
            environment_id=env_id,
            task_id=task_id,
            version=version,
            activated_at=datetime.now(timezone.utc),
            activated_by=activated_by,
            previous_version=previous_version,
        )

        if env_id not in self._activations:
            self._activations[env_id] = {}
        self._activations[env_id][task_id] = activation

        await self._save_activations()

        logger.info(
            "environment_registry.task_activated",
            environment_id=env_id,
            task_id=task_id,
            version=version,
            previous_version=previous_version,
        )
        return activation

    async def deactivate_task(self, env_id: str, task_id: str) -> bool:
        """Deactivate a task in an environment.

        Returns:
            True if the task was active and is now deactivated.
        """
        await self.ensure_loaded()

        if env_id in self._activations and task_id in self._activations[env_id]:
            del self._activations[env_id][task_id]
            await self._save_activations()
            logger.info("environment_registry.task_deactivated", environment_id=env_id, task_id=task_id)
            return True
        return False

    async def get_active_version(self, env_id: str, task_id: str) -> Optional[str]:
        """Get the active version of a task in an environment.

        Returns:
            Version string if active, None otherwise.
        """
        await self.ensure_loaded()
        activation = self._activations.get(env_id, {}).get(task_id)
        return activation.version if activation else None

    async def get_activation(self, env_id: str, task_id: str) -> Optional[EnvironmentActivation]:
        """Get the full activation record for a task in an environment."""
        await self.ensure_loaded()
        return self._activations.get(env_id, {}).get(task_id)

    async def list_activations(self, env_id: str) -> List[EnvironmentActivation]:
        """List all task activations for an environment."""
        await self.ensure_loaded()
        return list(self._activations.get(env_id, {}).values())

    async def rollback_task(
        self, env_id: str, task_id: str, rolled_back_by: Optional[str] = None,
    ) -> Optional[EnvironmentActivation]:
        """Rollback a task to its previous version in an environment.

        Uses the `previous_version` field from the current activation.

        Returns:
            New EnvironmentActivation with the rolled-back version, or None if no previous version.

        Raises:
            ValueError: If environment or task not found.
        """
        await self.ensure_loaded()

        current = self._activations.get(env_id, {}).get(task_id)
        if not current:
            raise ValueError(f"Task '{task_id}' is not active in environment '{env_id}'")

        if not current.previous_version:
            return None

        # Activate the previous version (the current becomes the new "previous")
        return await self.activate_task(
            env_id=env_id,
            task_id=task_id,
            version=current.previous_version,
            activated_by=rolled_back_by,
        )

    # ── Promotion ───────────────────────────────────────────────────────────

    async def promote(
        self,
        task_id: str,
        version: str,
        source_env: str,
        target_env: str,
        promoted_by: Optional[str] = None,
    ) -> PromotionRecord:
        """Promote a task version from one environment to another.

        Enforces linear promotion order: dev → staging → pre-prod → prod.
        The version must be active in the source environment.

        Args:
            task_id: Task to promote.
            version: Version to promote.
            source_env: Source environment ID (must have this version active).
            target_env: Target environment ID.
            promoted_by: Who performed the promotion.

        Returns:
            PromotionRecord for audit trail.

        Raises:
            ValueError: If promotion path is invalid or version not active in source.
        """
        await self.ensure_loaded()

        # Validate environments exist
        source = self._environments.get(source_env)
        target = self._environments.get(target_env)
        if not source:
            raise ValueError(f"Source environment '{source_env}' not found")
        if not target:
            raise ValueError(f"Target environment '{target_env}' not found")

        # Enforce linear promotion order using the integer promotion_order field
        if source.promotion_order is not None and target.promotion_order is not None:
            if target.promotion_order <= source.promotion_order:
                raise ValueError(
                    f"Cannot promote from '{source_env}' (order={source.promotion_order}) "
                    f"to '{target_env}' (order={target.promotion_order}). "
                    f"Promotion must follow the linear path (lower → higher order)."
                )
            # Check that there's no gap — find any environments with order between source and target
            skipped = sorted(
                [
                    env
                    for env in self._environments.values()
                    if env.promotion_order is not None
                    and source.promotion_order < env.promotion_order < target.promotion_order
                ],
                key=lambda e: e.promotion_order,
            )
            if skipped:
                skipped_names = " → ".join(f"{e.id}(order={e.promotion_order})" for e in skipped)
                raise ValueError(
                    f"Cannot skip environments in the promotion path. "
                    f"Must promote through: {skipped_names} first."
                )
        elif source.promotion_order is not None or target.promotion_order is not None:
            # One environment has a promotion order, the other doesn't — reject
            raise ValueError(
                f"Both environments must participate in the promotion pipeline "
                f"(have promotion_order set). '{source_env}' order={source.promotion_order}, "
                f"'{target_env}' order={target.promotion_order}."
            )
        else:
            # Neither environment has promotion_order — allow direct promotion
            pass

        # Validate version is active in source
        source_activation = self._activations.get(source_env, {}).get(task_id)
        if not source_activation or source_activation.version != version:
            active_version = source_activation.version if source_activation else "none"
            raise ValueError(
                f"Version '{version}' is not active in '{source_env}' "
                f"(active: {active_version})"
            )

        # Activate in target
        await self.activate_task(
            env_id=target_env,
            task_id=task_id,
            version=version,
            activated_by=promoted_by,
        )

        # Record promotion
        record = PromotionRecord(
            id=str(uuid.uuid4()),
            task_id=task_id,
            version=version,
            source_environment=source_env,
            target_environment=target_env,
            promoted_at=datetime.now(timezone.utc),
            promoted_by=promoted_by,
        )
        self._promotions.append(record)
        await self._save_promotions()

        logger.info(
            "environment_registry.promoted",
            task_id=task_id,
            version=version,
            source=source_env,
            target=target_env,
        )
        return record

    async def list_promotions(
        self,
        task_id: Optional[str] = None,
        environment_id: Optional[str] = None,
        limit: int = 50,
    ) -> List[PromotionRecord]:
        """List promotion records, optionally filtered.

        Args:
            task_id: Filter by task.
            environment_id: Filter by target environment.
            limit: Maximum number of records to return.

        Returns:
            List of PromotionRecord, newest first.
        """
        await self.ensure_loaded()

        records = self._promotions
        if task_id:
            records = [r for r in records if r.task_id == task_id]
        if environment_id:
            records = [r for r in records if r.target_environment == environment_id]

        # Newest first
        records = sorted(records, key=lambda r: r.promoted_at, reverse=True)
        return records[:limit]

    # ── Environment Variables ────────────────────────────────────────────────

    async def get_env_vars(self, env_id: str) -> Dict[str, str]:
        """Get environment variables for an environment.

        Returns the ``env_vars`` from the environment's ``EnvironmentSettings``.
        Returns an empty dict when the environment does not exist or has no
        variables configured.
        """
        await self.ensure_loaded()
        env = self._environments.get(env_id)
        if not env:
            return {}
        return dict(env.settings.env_vars)

    # ── Helpers ──────────────────────────────────────────────────────────

    def has_environments(self) -> bool:
        """Check if any environments are configured (beyond default)."""
        return any(env_id != "default" for env_id in self._environments)

    def environment_count(self) -> int:
        """Return number of configured environments."""
        return len(self._environments)
