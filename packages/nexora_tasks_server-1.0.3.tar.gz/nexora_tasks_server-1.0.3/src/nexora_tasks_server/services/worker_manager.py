"""WorkerManager — manages the lifecycle of all worker subprocesses.

Responsibilities:
- Spawn worker subprocesses using each task's venv Python binary
- Route execution requests to the correct worker
- Handle RPC requests from workers (artifact operations)
- Monitor worker health (ping/pong, auto-restart on crash)
- Graceful shutdown with drain
"""

import asyncio
import json
import os
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from nexora_tasks.logging import logger
from nexora_tasks_server.observability.metrics import (
    worker_pending_executions,
    worker_restarts_total,
    worker_startup_duration,
    workers_active,
    workers_idle,
)
from nexora_tasks.worker.protocol import (
    MSG_EXECUTION_COMPLETE,
    MSG_LOG,
    MSG_PONG,
    MSG_PROGRESS,
    MSG_READY,
    MSG_RPC_REQUEST,
    RPC_GET_INPUT_ARTIFACTS,
    RPC_IS_CANCELLED,
    RPC_PUBLISH_OUTPUT_ARTIFACTS,
    STATUS_FAILED,
    STATUS_SUCCEEDED,
    STATUS_TIMEOUT,
    build_cancel_msg,
    build_execute_msg,
    build_pause_msg,
    build_ping_msg,
    build_resume_msg,
    build_rpc_response_msg,
    build_shutdown_msg,
    send_message_async,
)

if TYPE_CHECKING:
    from nexora_tasks_server.framework import NexoraTasks
    from nexora_tasks.models.task_definition import TaskDefinition


@dataclass
class WorkerHandle:
    """Tracks a running worker subprocess."""
    task_def: "TaskDefinition"
    process: asyncio.subprocess.Process
    ready_event: asyncio.Event = field(default_factory=asyncio.Event)
    reader_task: Optional[asyncio.Task] = None
    stderr_task: Optional[asyncio.Task] = None
    pending_executions: Dict[str, asyncio.Future] = field(default_factory=dict)
    # Reverse index: thread_id → exec_id, used to reject double-dispatch of
    # the same thread to the same worker. Without it, retry/resume races can
    # run the task body twice in parallel and corrupt artifacts.
    pending_thread_ids: Dict[str, str] = field(default_factory=dict)
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    restart_count: int = 0
    last_pong: Optional[datetime] = None
    # Recent stderr lines (startup failures, require() errors) for diagnostics
    stderr_tail: deque = field(default_factory=lambda: deque(maxlen=120))
    # Set when the process exits before MSG_READY; also sets ready_event to unblock start_worker
    startup_error: Optional[str] = None


class WorkerManager:
    """Manages worker subprocess lifecycle and communication."""

    def __init__(self, framework: "NexoraTasks", log_buffer=None) -> None:
        self.framework = framework
        self.workers: Dict[str, WorkerHandle] = {}  # key: "task_id:version"
        self._health_task: Optional[asyncio.Task] = None
        self._shutting_down = False
        # Throttle progress updates: max 1 DB write per second per thread
        self._progress_last_update: Dict[str, float] = {}  # thread_id -> monotonic timestamp
        # Thread log buffer for observability API
        self._log_buffer = log_buffer

    async def start_worker(self, task_def: "TaskDefinition") -> None:
        """Start a worker subprocess for a task definition.
        
        Args:
            task_def: The task definition to start a worker for
            
        Raises:
            RuntimeError: If worker fails to start or doesn't send ready message
        """
        full_id = task_def.full_id
        
        # Stop existing worker if any (force redeploy case)
        if full_id in self.workers:
            await self.stop_worker(full_id, drain=False)
        
        runtime = getattr(task_def, 'runtime', 'python')
        
        if runtime == 'node':
            # ─── Node.js runtime ─────────────────────────────────
            import shutil
            node_bin = shutil.which('node')
            if not node_bin:
                raise RuntimeError(
                    f"Node.js not found on PATH for task {full_id}. "
                    f"Install Node.js to run JavaScript/TypeScript tasks."
                )
            
            # node-runner.js is bundled with the SDK package (nexora_tasks.worker)
            import nexora_tasks.worker as _sdk_worker
            sdk_worker_dir = Path(_sdk_worker.__file__).parent
            runner_js = sdk_worker_dir / "node-runner.js"
            
            # Fallback: look alongside this server module
            if not runner_js.exists():
                base_dir = Path(__file__).parent.parent
                runner_js = base_dir / "worker" / "node-runner.js"
            
            # Fallback for local dev mode: look in sdk-js source
            if not runner_js.exists():
                base_dir = Path(__file__).parent.parent
                dev_runner = base_dir.parent.parent.parent / "sdk-js" / "src" / "node-runner.js"
                if dev_runner.exists():
                    runner_js = dev_runner
                    
            if not runner_js.exists():
                raise RuntimeError(f"Node runner not found: {runner_js}")
            
            logger.info(
                "worker_manager.starting_worker",
                task_id=task_def.task_id,
                version=task_def.version,
                runtime="node",
                node_bin=node_bin,
                code_path=task_def.code_path,
                entry_point=task_def.entry_point,
            )
            
            # Auto npm install
            task_path = Path(task_def.code_path)
            if (task_path / "package.json").exists() and not (task_path / "node_modules").exists():
                logger.info("worker_manager.npm_install", path=str(task_path))
                npm_bin = shutil.which("npm") or "npm"
                install_proc = await asyncio.create_subprocess_exec(
                    npm_bin, "install",
                    cwd=task_def.code_path,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await install_proc.communicate()
                if install_proc.returncode != 0:
                    logger.error("worker_manager.npm_install.failed", error=stderr.decode())
                    raise RuntimeError(f"npm install failed in {task_path}. {stderr.decode()}")

            # Spawn Node.js subprocess
            # Ensure code_path is absolute (it may be stored as relative)
            abs_code_path = str(Path(task_def.code_path).resolve())
            process = await asyncio.create_subprocess_exec(
                node_bin, str(runner_js),
                "--code-path", abs_code_path,
                "--entry-point", task_def.entry_point,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=abs_code_path,
            )
        else:
            # ─── Python runtime (default) ────────────────────────
            # Resolve venv Python path
            import sys
            venv_path = Path(task_def.venv_path)
            if venv_path.is_file() and venv_path.name.startswith("python"):
                venv_python = venv_path
            else:
                venv_python = venv_path / "bin" / "python"
                
            if not venv_python.exists():
                raise RuntimeError(
                    f"Worker venv python not found: {venv_python}. "
                    f"Task may need redeployment."
                )
            
            # Check that the worker module exists in the venv
            # (it's installed as part of nexora-tasks-py)
            check_proc = await asyncio.create_subprocess_exec(
                str(venv_python), "-c", "import nexora_tasks.worker",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
            _, check_stderr = await check_proc.communicate()
            if check_proc.returncode != 0:
                raise RuntimeError(
                    f"Worker module not available in task venv for {full_id}. "
                    f"The task may need redeployment with the latest framework. "
                    f"Falling back to in-process execution. "
                    f"Error: {check_stderr.decode()[:200]}"
                )
            
            logger.info(
                "worker_manager.starting_worker",
                task_id=task_def.task_id,
                version=task_def.version,
                runtime="python",
                venv_python=str(venv_python),
                code_path=task_def.code_path,
                entry_point=task_def.entry_point,
            )
            
            # Spawn Python subprocess
            process = await asyncio.create_subprocess_exec(
                str(venv_python), "-m", "nexora_tasks.worker",
                "--code-path", task_def.code_path,
                "--entry-point", task_def.entry_point,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        
        handle = WorkerHandle(task_def=task_def, process=process)
        self.workers[full_id] = handle

        # Start reading stdout (protocol) and stderr (logs) in background
        handle.reader_task = asyncio.create_task(
            self._read_worker_output(handle),
            name=f"worker-reader-{full_id}",
        )
        handle.stderr_task = asyncio.create_task(
            self._read_worker_stderr(handle),
            name=f"worker-stderr-{full_id}",
        )

        # Wait for ready message (15s timeout for module loading)
        _spawn_time = time.monotonic()
        try:
            await asyncio.wait_for(handle.ready_event.wait(), timeout=15.0)
        except asyncio.TimeoutError:
            await self._cleanup_failed_worker_start(handle, full_id)
            tail = "\n".join(handle.stderr_tail)[-2500:] if handle.stderr_tail else ""
            extra = f"\n--- worker stderr (tail) ---\n{tail}" if tail.strip() else ""
            raise RuntimeError(
                f"Worker for {full_id} failed to start within 15s. "
                f"Check task code and dependencies.{extra}"
            ) from None

        if handle.startup_error:
            await self._cleanup_failed_worker_start(handle, full_id)
            raise RuntimeError(handle.startup_error)

        # Record startup latency and increment active workers
        _startup_duration = time.monotonic() - _spawn_time
        worker_startup_duration.record(_startup_duration, {"task_id": task_def.task_id})
        workers_active.add(1)
        workers_idle.add(1)  # new worker starts idle (no pending executions)

        logger.info(
            "worker_manager.worker_started",
            task_id=task_def.task_id,
            version=task_def.version,
            pid=process.pid,
            startup_seconds=round(_startup_duration, 3),
        )

    def _dec_pending(self, task_id: str, handle: WorkerHandle) -> None:
        """Decrement pending executions gauge and update idle status."""
        worker_pending_executions.add(-1, {"task_id": task_id})
        if len(handle.pending_executions) == 0:
            workers_idle.add(1)

    async def _cleanup_failed_worker_start(self, handle: WorkerHandle, full_id: str) -> None:
        """Cancel reader tasks, reap process, remove handle after a failed start."""
        if handle.reader_task and not handle.reader_task.done():
            handle.reader_task.cancel()
            try:
                await handle.reader_task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
        if handle.stderr_task and not handle.stderr_task.done():
            handle.stderr_task.cancel()
            try:
                await handle.stderr_task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
        proc = handle.process
        if proc.returncode is None:
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                pass
        self.workers.pop(full_id, None)

    async def stop_worker(self, full_id: str, drain: bool = True) -> None:
        """Stop a worker subprocess.
        
        Args:
            full_id: Task full_id (task_id:version)
            drain: If True, wait for active executions to finish
        """
        handle = self.workers.get(full_id)
        if not handle:
            return
        
        logger.info(
            "worker_manager.stopping_worker",
            full_id=full_id,
            pid=handle.process.pid,
            drain=drain,
            active_executions=len(handle.pending_executions),
        )
        
        try:
            # Send shutdown message
            if handle.process.stdin and not handle.process.stdin.is_closing():
                await send_message_async(
                    handle.process.stdin,
                    build_shutdown_msg(drain=drain),
                )
        except (BrokenPipeError, ConnectionResetError):
            pass  # Worker already dead
        
        # Wait for process to exit
        try:
            await asyncio.wait_for(handle.process.wait(), timeout=30 if drain else 5)
        except asyncio.TimeoutError:
            logger.warning(
                "worker_manager.force_kill",
                full_id=full_id,
                pid=handle.process.pid,
            )
            handle.process.kill()
            await handle.process.wait()
        
        # Cancel reader tasks
        if handle.reader_task and not handle.reader_task.done():
            handle.reader_task.cancel()
        if handle.stderr_task and not handle.stderr_task.done():
            handle.stderr_task.cancel()
        
        # Fail any pending executions
        for exec_id, future in handle.pending_executions.items():
            if not future.done():
                future.set_exception(RuntimeError("Worker stopped"))
        
        workers_active.add(-1)
        # Also decrement idle if it was idle
        if not handle.pending_executions:
            workers_idle.add(-1)
        del self.workers[full_id]

        logger.info(
            "worker_manager.worker_stopped",
            full_id=full_id,
        )

    async def stop_all(self, drain: bool = True, timeout: float = 30) -> None:
        """Stop all workers (called during server shutdown).
        
        Args:
            drain: If True, wait for active executions to finish
            timeout: Max time to wait for all workers to stop
        """
        self._shutting_down = True
        
        if self._health_task and not self._health_task.done():
            self._health_task.cancel()
        
        if not self.workers:
            return
        
        logger.info(
            "worker_manager.stopping_all",
            worker_count=len(self.workers),
            drain=drain,
        )
        
        # Stop all workers concurrently
        stop_tasks = [
            self.stop_worker(full_id, drain=drain)
            for full_id in list(self.workers.keys())
        ]
        
        try:
            await asyncio.wait_for(
                asyncio.gather(*stop_tasks, return_exceptions=True),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.error("worker_manager.stop_all_timeout")
            # Force kill any remaining
            for handle in list(self.workers.values()):
                handle.process.kill()

    async def execute(
        self,
        task_def: "TaskDefinition",
        thread_id: str,
        params: Dict[str, Any],
        metadata: Dict[str, Any],
        env_vars: Dict[str, str],
        secrets: Dict[str, str],
        timeout_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Send an execution request to the appropriate worker.
        
        Args:
            task_def: Task definition to execute
            thread_id: Thread identifier
            params: Task parameters
            metadata: Thread metadata
            env_vars: Resolved environment variables
            secrets: Resolved secrets
            timeout_seconds: Optional execution timeout
            
        Returns:
            Execution result dict with status, error, etc.
            
        Raises:
            RuntimeError: If no worker is available for the task
        """
        full_id = task_def.full_id
        handle = self.workers.get(full_id)
        
        if not handle:
            raise RuntimeError(f"No worker available for {full_id}")
        
        if handle.process.returncode is not None:
            # Worker process has exited — try to restart
            logger.warning(
                "worker_manager.worker_dead_restarting",
                full_id=full_id,
                returncode=handle.process.returncode,
            )
            await self._restart_worker(handle)
            handle = self.workers.get(full_id)
            if not handle:
                raise RuntimeError(f"Failed to restart worker for {full_id}")
        
        # A-4: refuse to dispatch the same thread twice in parallel.
        # Two API paths (retry + resume, or retry + retry) could otherwise
        # both invoke execute() for the same thread_id — they'd get
        # different exec_ids but run the task body concurrently and the
        # second execution_complete would clobber the first's result.
        existing_exec = handle.pending_thread_ids.get(thread_id)
        if existing_exec is not None:
            raise RuntimeError(
                f"Thread {thread_id} is already executing on worker {full_id} "
                f"(exec_id={existing_exec}); refusing duplicate dispatch."
            )

        exec_id = str(uuid.uuid4())
        future: asyncio.Future = asyncio.get_running_loop().create_future()
        was_idle = len(handle.pending_executions) == 0
        handle.pending_executions[exec_id] = future
        handle.pending_thread_ids[thread_id] = exec_id
        worker_pending_executions.add(1, {"task_id": task_def.task_id})
        if was_idle:
            workers_idle.add(-1)
        
        # Propagate trace context to worker subprocess
        from nexora_tasks_server.tracing import get_trace_parent_header
        trace_ctx = None
        trace_parent = get_trace_parent_header()
        if trace_parent:
            trace_ctx = {"traceparent": trace_parent}

        # Send execute message
        msg = build_execute_msg(
            exec_id=exec_id,
            thread_id=thread_id,
            params=params,
            metadata=metadata,
            env_vars=env_vars,
            secrets=secrets,
            trace_context=trace_ctx,
        )
        
        try:
            await send_message_async(handle.process.stdin, msg)
        except (BrokenPipeError, ConnectionResetError) as e:
            handle.pending_executions.pop(exec_id, None)
            handle.pending_thread_ids.pop(thread_id, None)
            self._dec_pending(task_def.task_id, handle)
            raise RuntimeError(f"Worker pipe broken for {full_id}: {e}")

        # Wait for result
        try:
            if timeout_seconds:
                result = await asyncio.wait_for(future, timeout=timeout_seconds)
            else:
                result = await future
            handle.pending_thread_ids.pop(thread_id, None)
            self._dec_pending(task_def.task_id, handle)
            return result
        except asyncio.TimeoutError:
            handle.pending_executions.pop(exec_id, None)
            handle.pending_thread_ids.pop(thread_id, None)
            self._dec_pending(task_def.task_id, handle)
            # Send cancel to the worker
            try:
                await send_message_async(
                    handle.process.stdin,
                    build_cancel_msg(thread_id),
                )
            except (BrokenPipeError, ConnectionResetError):
                pass
            return {
                "status": STATUS_TIMEOUT,
                "thread_id": thread_id,
                "error": {
                    "message": f"Task execution timed out after {timeout_seconds}s",
                    "type": "TimeoutError",
                    "traceback": "",
                },
            }

    def cancel_execution(self, task_def: "TaskDefinition", thread_id: str) -> bool:
        """Send cancel signal to a worker for a specific thread.
        
        Args:
            task_def: Task definition
            thread_id: Thread to cancel
            
        Returns:
            True if cancel was sent, False if worker not found
        """
        handle = self.workers.get(task_def.full_id)
        if not handle or handle.process.returncode is not None:
            return False
        
        try:
            asyncio.create_task(
                send_message_async(handle.process.stdin, build_cancel_msg(thread_id))
            )
            return True
        except (BrokenPipeError, ConnectionResetError):
            return False

    def pause_execution(self, task_def: "TaskDefinition", thread_id: str) -> bool:
        """Send pause signal to a worker for a specific thread.
        
        Args:
            task_def: Task definition
            thread_id: Thread to pause
            
        Returns:
            True if pause was sent, False if worker not found
        """
        handle = self.workers.get(task_def.full_id)
        if not handle or handle.process.returncode is not None:
            return False
        
        try:
            asyncio.create_task(
                send_message_async(handle.process.stdin, build_pause_msg(thread_id))
            )
            return True
        except (BrokenPipeError, ConnectionResetError):
            return False

    def resume_execution(self, task_def: "TaskDefinition", thread_id: str) -> bool:
        """Send resume signal to a worker for a specific thread.
        
        Args:
            task_def: Task definition
            thread_id: Thread to resume
            
        Returns:
            True if resume was sent, False if worker not found
        """
        handle = self.workers.get(task_def.full_id)
        if not handle or handle.process.returncode is not None:
            return False
        
        try:
            asyncio.create_task(
                send_message_async(handle.process.stdin, build_resume_msg(thread_id))
            )
            return True
        except (BrokenPipeError, ConnectionResetError):
            return False

    def has_worker(self, full_id: str) -> bool:
        """Check if a worker is running for the given task."""
        handle = self.workers.get(full_id)
        return handle is not None and handle.process.returncode is None

    def get_worker_info(self) -> List[Dict[str, Any]]:
        """Get status info for all workers."""
        info = []
        for full_id, handle in self.workers.items():
            info.append({
                "full_id": full_id,
                "task_id": handle.task_def.task_id,
                "version": handle.task_def.version,
                "pid": handle.process.pid,
                "alive": handle.process.returncode is None,
                "restart_count": handle.restart_count,
                "active_executions": len(handle.pending_executions),
                "started_at": handle.started_at.isoformat(),
            })
        return info

    # ─────────────────────────────────────────────────────────────
    # Internal: message dispatch
    # ─────────────────────────────────────────────────────────────

    async def _read_worker_output(self, handle: WorkerHandle) -> None:
        """Continuously read stdout from worker and dispatch messages."""
        full_id = handle.task_def.full_id
        
        try:
            async for raw_line in handle.process.stdout:
                if not raw_line:
                    break
                
                line = raw_line.decode("utf-8").strip()
                if not line:
                    continue
                
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    # Not a protocol message — log it
                    logger.debug("worker_manager.non_protocol_output", full_id=full_id, line=line[:200])
                    continue
                
                msg_type = msg.get("type")
                
                if msg_type == MSG_READY:
                    handle.ready_event.set()
                    logger.debug("worker_manager.worker_ready", full_id=full_id, pid=msg.get("pid"))
                
                elif msg_type == MSG_EXECUTION_COMPLETE:
                    exec_id = msg.get("id")
                    thread_id = msg.get("thread_id")
                    future = handle.pending_executions.pop(exec_id, None)
                    if thread_id:
                        handle.pending_thread_ids.pop(thread_id, None)
                    if future and not future.done():
                        future.set_result(msg)
                    # Clean up progress throttle entry
                    self._progress_last_update.pop(thread_id, None)
                    # Mark thread complete in log buffer (starts purge timer)
                    if thread_id and self._log_buffer:
                        self._log_buffer.mark_thread_complete(thread_id)
                
                elif msg_type == MSG_RPC_REQUEST:
                    asyncio.create_task(self._handle_rpc(handle, msg))
                
                elif msg_type == MSG_LOG:
                    # Forward worker log to main structlog
                    level = msg.get("level", "info")
                    event = msg.get("event", "worker.log")
                    source = msg.get("source", "worker")
                    data = msg.get("data", {})
                    data["worker_full_id"] = full_id
                    data["worker_thread_id"] = msg.get("thread_id")
                    getattr(logger, level, logger.info)(event, **data)
                    
                    # Push to thread log buffer for observability API
                    thread_id = msg.get("thread_id")
                    if thread_id and self._log_buffer:
                        from nexora_tasks.models.log_models import LogEntry
                        self._log_buffer.append(thread_id, LogEntry(
                            timestamp=datetime.now(timezone.utc),
                            level=level,
                            event=event,
                            message=data.get("message"),
                            source=source,
                            thread_id=thread_id,
                            data={k: v for k, v in data.items() if k not in ("message", "worker_full_id", "worker_thread_id")},
                        ))
                
                elif msg_type == MSG_PROGRESS:
                    asyncio.create_task(self._handle_progress(msg))
                
                elif msg_type == MSG_PONG:
                    handle.last_pong = datetime.now(timezone.utc)
        
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(
                "worker_manager.reader_error",
                full_id=full_id,
                error=str(e),
            )
        
        # Worker stdout closed — process has exited or is exiting
        if not self._shutting_down and full_id in self.workers:
            returncode = handle.process.returncode
            if not handle.ready_event.is_set():
                # Exited before MSG_READY: unblock start_worker (do not restart here;
                # restarting would pop the handle while start_worker still waits).
                tail = "\n".join(handle.stderr_tail)[-4000:] if handle.stderr_tail else ""
                handle.startup_error = (
                    f"Worker process exited during startup (exit code {returncode})."
                    + (f"\n{tail}" if tail.strip() else "")
                )
                handle.ready_event.set()
                logger.warning(
                    "worker_manager.worker_exited_before_ready",
                    full_id=full_id,
                    returncode=returncode,
                )
                return
            logger.warning(
                "worker_manager.worker_exited",
                full_id=full_id,
                pid=handle.process.pid,
                returncode=returncode,
            )
            asyncio.create_task(self._restart_worker(handle))

    async def _read_worker_stderr(self, handle: WorkerHandle) -> None:
        """Read stderr from worker and forward as log messages.
        
        stderr contains print()/logging output from task code
        (stdout is redirected to stderr in the worker subprocess).
        Lines are forwarded to both structlog and the ThreadLogBuffer.
        """
        full_id = handle.task_def.full_id
        
        try:
            async for raw_line in handle.process.stderr:
                if not raw_line:
                    break
                line = raw_line.decode("utf-8").rstrip()
                if line:
                    handle.stderr_tail.append(line)
                    logger.info(
                        "worker.stderr",
                        full_id=full_id,
                        message=line,
                    )
                    # Push to log buffer — associate with current thread
                    # (stderr doesn't carry thread_id natively; use the
                    #  worker's single active execution if available)
                    if self._log_buffer and handle.pending_executions:
                        # Best-effort thread association: use first active thread
                        # Note: MSG_LOG from CapturedStdout has proper thread_id;
                        # this stderr path is a fallback for non-protocol output.
                        for exec_id, future in handle.pending_executions.items():
                            if not future.done():
                                from nexora_tasks.models.log_models import LogEntry
                                # We don't have the thread_id on exec futures,
                                # so we skip direct stderr buffering when MSG_LOG
                                # is available (CapturedStdout handles it).
                                # This path catches raw stderr from non-Python output.
                                break
        except asyncio.CancelledError:
            pass
        except Exception:
            pass

    async def _handle_progress(self, msg: Dict[str, Any]) -> None:
        """Handle a progress message from a worker.
        
        Updates the thread's progress in the database and publishes
        a thread.progress event. Throttled to max 1 DB write per second
        per thread to avoid overwhelming the database.
        
        Args:
            msg: Progress message with thread_id, value, message
        """
        thread_id = msg.get("thread_id", "")
        value = msg.get("value", 0.0)
        message = msg.get("message", "")
        
        if not thread_id:
            return
        
        # Throttle: skip DB update if last update was less than 250ms ago
        now = time.monotonic()
        last = self._progress_last_update.get(thread_id, 0.0)
        if now - last < 0.25:
            return
        self._progress_last_update[thread_id] = now
        
        try:
            thread = await self.framework.database.get_thread(thread_id)
            if thread:
                thread.progress = value
                thread.progress_message = message
                await self.framework.database.update_thread(thread)
            
            # Publish progress event
            if self.framework.event_publisher:
                await self.framework.event_publisher.publish(
                    event_type="thread.progress",
                    thread_id=thread_id,
                    metadata={"progress": value, "progress_message": message},
                )
        except Exception as e:
            logger.debug(
                "worker_manager.progress_update_failed",
                thread_id=thread_id,
                error=str(e),
            )

    async def _handle_rpc(self, handle: WorkerHandle, msg: Dict[str, Any]) -> None:
        """Process an RPC request from a worker and send the response."""
        request_id = msg.get("id", "")
        method = msg.get("method", "")
        args = msg.get("args", {})
        full_id = handle.task_def.full_id
        
        try:
            result = await self._dispatch_rpc(handle, method, args)
            response = build_rpc_response_msg(request_id, result=result)
        except Exception as e:
            logger.error(
                "worker_manager.rpc_error",
                full_id=full_id,
                method=method,
                error=str(e),
            )
            response = build_rpc_response_msg(
                request_id,
                error={"message": str(e), "type": type(e).__name__},
            )
        
        try:
            await send_message_async(handle.process.stdin, response)
        except (BrokenPipeError, ConnectionResetError):
            logger.warning(
                "worker_manager.rpc_response_pipe_broken",
                full_id=full_id,
                request_id=request_id,
            )

    async def _dispatch_rpc(
        self, handle: WorkerHandle, method: str, args: Dict[str, Any]
    ) -> Any:
        """Dispatch an RPC call to the appropriate framework service.
        
        Args:
            handle: Worker handle
            method: RPC method name
            args: Method arguments
            
        Returns:
            RPC result to send back to worker
        """
        if method == RPC_GET_INPUT_ARTIFACTS:
            thread_id = args["thread_id"]
            artifacts = await self.framework.database.get_thread_artifacts(thread_id)
            return [a.model_dump(mode="json") for a in artifacts]
        
        elif method == RPC_PUBLISH_OUTPUT_ARTIFACTS:
            thread_id = args["thread_id"]
            artifacts_data = args.get("artifacts", [])
            
            from nexora_tasks_server.artefact_backends import resolve_backend
            from nexora_tasks_server.services.artifact_service import ArtifactService
            from nexora_tasks.models.artifact import Artifact
            from datetime import datetime, timezone

            artifact_service = ArtifactService(
                database=self.framework.database,
                file_storage=self.framework.file_storage,
                backend=resolve_backend(
                    self.framework.database,
                    file_storage=self.framework.file_storage,
                ),
            )
            
            now = datetime.now(timezone.utc)
            for art_data in artifacts_data:
                art_data["thread_id"] = thread_id
                art_data["direction"] = "output"
                artifact = Artifact(**art_data)
                if not artifact.created_at:
                    artifact.created_at = now
                await artifact_service.create_artifact(artifact)
            
            return {"ok": True}
        
        elif method == RPC_IS_CANCELLED:
            thread_id = args["thread_id"]
            from nexora_tasks.thread_state import ThreadState
            thread = await self.framework.database.get_thread(thread_id)
            return thread is not None and thread.state == ThreadState.STOPPED
        
        else:
            raise ValueError(f"Unknown RPC method: {method}")

    async def _restart_worker(self, handle: WorkerHandle) -> None:
        """Restart a crashed worker.
        
        Args:
            handle: The worker handle for the crashed worker
        """
        full_id = handle.task_def.full_id
        
        if self._shutting_down:
            return
        
        # Limit restart attempts
        max_restarts = 5
        if handle.restart_count >= max_restarts:
            logger.error(
                "worker_manager.max_restarts_exceeded",
                full_id=full_id,
                restart_count=handle.restart_count,
            )
            # Fail all pending executions
            for exec_id, future in handle.pending_executions.items():
                if not future.done():
                    future.set_exception(RuntimeError(
                        f"Worker {full_id} exceeded max restarts ({max_restarts})"
                    ))
            self.workers.pop(full_id, None)
            return
        
        # Clean up old handle
        if handle.reader_task and not handle.reader_task.done():
            handle.reader_task.cancel()
        if handle.stderr_task and not handle.stderr_task.done():
            handle.stderr_task.cancel()
        
        # Fail pending executions from crashed worker
        for exec_id, future in handle.pending_executions.items():
            if not future.done():
                future.set_exception(RuntimeError(f"Worker {full_id} crashed, restarting"))
        
        self.workers.pop(full_id, None)
        
        # Back off briefly
        backoff = min(2 ** handle.restart_count, 10)
        logger.info(
            "worker_manager.restarting_worker",
            full_id=full_id,
            restart_count=handle.restart_count + 1,
            backoff_seconds=backoff,
        )
        await asyncio.sleep(backoff)
        
        # Restart
        try:
            await self.start_worker(handle.task_def)
            # Update restart count
            new_handle = self.workers.get(full_id)
            if new_handle:
                new_handle.restart_count = handle.restart_count + 1
            worker_restarts_total.add(1, {"task_id": handle.task_def.task_id})
        except Exception as e:
            logger.error(
                "worker_manager.restart_failed",
                full_id=full_id,
                error=str(e),
            )

    # ─────────────────────────────────────────────────────────────
    # Health monitoring
    # ─────────────────────────────────────────────────────────────

    async def start_health_monitor(self, interval: float = 30.0) -> None:
        """Start periodic health checks for all workers.
        
        Args:
            interval: Seconds between health checks
        """
        self._health_task = asyncio.create_task(
            self._health_loop(interval),
            name="worker-health-monitor",
        )

    async def _health_loop(self, interval: float) -> None:
        """Periodic health check loop."""
        try:
            while not self._shutting_down:
                await asyncio.sleep(interval)
                
                for full_id, handle in list(self.workers.items()):
                    if handle.process.returncode is not None:
                        # Already dead — restart handler will pick it up
                        continue
                    
                    try:
                        await send_message_async(
                            handle.process.stdin,
                            build_ping_msg(),
                        )
                    except (BrokenPipeError, ConnectionResetError):
                        logger.warning(
                            "worker_manager.health_ping_failed",
                            full_id=full_id,
                        )
        except asyncio.CancelledError:
            pass
