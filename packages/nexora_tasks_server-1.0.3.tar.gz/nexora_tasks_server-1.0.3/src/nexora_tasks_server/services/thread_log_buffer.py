"""Thread log buffer — in-memory ring buffer for per-thread log entries.

Provides real-time log storage and WebSocket streaming support.
Used as the primary log source when Elasticsearch is not available,
and as a real-time buffer for WebSocket streaming even when ES is active.

Thread lifecycle:
1. Logs are appended via ``append()`` during thread execution.
2. WebSocket clients subscribe via ``subscribe()`` / ``unsubscribe()``.
3. When execution completes, ``mark_thread_complete()`` starts a purge timer.
4. After ``purge_delay_seconds``, the buffer for that thread is removed.
"""

import asyncio
import os
import time
from collections import OrderedDict, deque
from datetime import datetime, timezone
from typing import Any, Deque, Dict, List, Optional, Set

from nexora_tasks.models.log_models import LogEntry

try:  # pragma: no cover - metric import is best-effort, never break buffer
    from nexora_tasks_server.observability.metrics import thread_log_buffer_evictions_total
except Exception:  # pragma: no cover
    thread_log_buffer_evictions_total = None  # type: ignore


def _default_max_threads() -> int:
    """Read ``LOG_BUFFER_MAX_THREADS`` from the environment.

    Parsed lazily so tests can ``monkeypatch.setenv`` between constructions.
    """
    raw = os.getenv("LOG_BUFFER_MAX_THREADS", "1000")
    try:
        value = int(raw)
        return value if value > 0 else 1000
    except ValueError:
        return 1000


class ThreadLogBuffer:
    """Thread-safe in-memory ring buffer for per-thread log entries.

    Features:
    - Fixed capacity per thread (oldest entries evicted when full)
    - WebSocket subscriber queues for real-time streaming
    - Automatic purge after thread completion
    - Deduplication by (timestamp, event, message) within a short window
    """

    def __init__(
        self,
        max_entries_per_thread: int = 1000,
        purge_delay_seconds: float = 300.0,
        file_sink: Optional[Any] = None,
        max_threads: Optional[int] = None,
    ) -> None:
        """Initialize the log buffer.

        Args:
            max_entries_per_thread: Maximum log entries kept per thread.
                When exceeded, oldest entries are evicted (ring buffer).
            purge_delay_seconds: Seconds to wait after thread completion
                before purging its logs from memory.
            file_sink: Optional FileLogSink for persistent log storage.
                When provided, each entry is also written to disk.
            max_threads: Global cap on the number of per-thread buffers
                kept in memory. When a new thread would push us past the
                cap, the oldest COMPLETED thread is evicted; if none are
                completed, the oldest by insertion time is evicted. Defaults
                to the ``LOG_BUFFER_MAX_THREADS`` env var (fallback 1000).
        """
        self._max_entries = max_entries_per_thread
        self._purge_delay = purge_delay_seconds
        self._file_sink = file_sink
        self._max_threads = max_threads if max_threads is not None else _default_max_threads()

        # Per-thread log ring buffers. Ordered so we can evict oldest first.
        self._buffers: "OrderedDict[str, Deque[LogEntry]]" = OrderedDict()

        # Thread IDs whose execution has completed — candidates for eviction
        # first, since their logs are already being purged soon anyway.
        self._completed_threads: "OrderedDict[str, None]" = OrderedDict()

        # Per-thread WebSocket subscriber queues
        self._subscribers: Dict[str, Set[asyncio.Queue]] = {}

        # Pending purge tasks
        self._purge_tasks: Dict[str, asyncio.Task] = {}

        # Deduplication: (thread_id, timestamp_str, event, message) -> last_seen
        self._recent_entries: Dict[str, float] = {}
        self._dedup_window_seconds = 0.5

    # ─────────────────────────────────────────────────────────────
    # Eviction helpers
    # ─────────────────────────────────────────────────────────────

    def _evict_one(self) -> Optional[str]:
        """Evict a single per-thread buffer to make room.

        Priority:
        1. Oldest completed thread (logs already scheduled for purge).
        2. Oldest buffer by insertion time (live thread — last resort).

        Returns the evicted thread_id, or None if nothing could be evicted.
        """
        victim: Optional[str] = None
        reason = "oldest_completed"

        if self._completed_threads:
            # OrderedDict preserves insertion order, so popitem(last=False)
            # gives us the oldest completed thread.
            victim, _ = self._completed_threads.popitem(last=False)
        elif self._buffers:
            reason = "oldest_live"
            victim = next(iter(self._buffers.keys()))

        if victim is None:
            return None

        # Cancel any pending purge task and drop buffer state.
        purge_task = self._purge_tasks.pop(victim, None)
        if purge_task and not purge_task.done():
            purge_task.cancel()
        self._buffers.pop(victim, None)
        self._subscribers.pop(victim, None)
        self._completed_threads.pop(victim, None)

        if thread_log_buffer_evictions_total is not None:
            try:
                thread_log_buffer_evictions_total.add(1, {"reason": reason})
            except Exception:
                pass
        return victim

    # ─────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────

    def append(self, thread_id: str, entry: LogEntry) -> None:
        """Append a log entry for a thread.

        If the buffer exceeds ``max_entries_per_thread``, the oldest
        entry is evicted. Active WebSocket subscribers are notified.

        Args:
            thread_id: Thread identifier.
            entry: Log entry to append.
        """
        # Deduplication check
        dedup_key = f"{thread_id}:{entry.timestamp.isoformat()}:{entry.event}:{entry.message or ''}"
        now = time.monotonic()
        last_seen = self._recent_entries.get(dedup_key)
        if last_seen is not None and (now - last_seen) < self._dedup_window_seconds:
            return  # Skip duplicate
        self._recent_entries[dedup_key] = now

        # Periodic cleanup of dedup cache (every ~100 entries)
        if len(self._recent_entries) > 5000:
            cutoff = now - self._dedup_window_seconds * 2
            self._recent_entries = {
                k: v for k, v in self._recent_entries.items() if v > cutoff
            }

        # Ensure thread_id is set on the entry
        if entry.thread_id is None:
            entry = entry.model_copy(update={"thread_id": thread_id})

        # Append to ring buffer. Before allocating a NEW buffer, enforce the
        # global max_threads cap — evict the oldest completed (or live) thread
        # if we are already at the limit. This guards against the unbounded
        # growth that would otherwise occur with 10k concurrent threads.
        if thread_id not in self._buffers:
            while len(self._buffers) >= self._max_threads:
                evicted = self._evict_one()
                if evicted is None:
                    break  # Safety: no candidate available
            self._buffers[thread_id] = deque(maxlen=self._max_entries)
        self._buffers[thread_id].append(entry)

        # Notify WebSocket subscribers (fire-and-forget)
        for queue in self._subscribers.get(thread_id, set()):
            try:
                queue.put_nowait(entry)
            except asyncio.QueueFull:
                pass  # Drop rather than block

        # Persist to disk if file sink is attached
        if self._file_sink is not None:
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._file_sink.append(thread_id, entry))
            except RuntimeError:
                pass  # No running loop (e.g. in synchronous tests)

    def get_entries(
        self,
        thread_id: str,
        level: Optional[str] = None,
        source: Optional[str] = None,
        after: Optional[datetime] = None,
        before: Optional[datetime] = None,
        search: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> tuple[List[LogEntry], int]:
        """Retrieve log entries for a thread with optional filters.

        Args:
            thread_id: Thread identifier.
            level: Filter by log level (debug, info, warning, error).
            source: Filter by source (server, worker, stderr, stdout).
            after: Only include entries after this timestamp.
            before: Only include entries before this timestamp.
            search: Full-text search across event and message fields.
            limit: Maximum entries to return.
            offset: Number of entries to skip.

        Returns:
            Tuple of (filtered entries, total matching count).
        """
        buffer = self._buffers.get(thread_id)
        if not buffer:
            return [], 0

        entries = list(buffer)

        # Apply filters
        if level:
            entries = [e for e in entries if e.level == level]
        if source and source != "all":
            entries = [e for e in entries if e.source == source]
        if after:
            entries = [e for e in entries if e.timestamp > after]
        if before:
            entries = [e for e in entries if e.timestamp < before]
        if search:
            search_lower = search.lower()
            entries = [
                e
                for e in entries
                if search_lower in (e.event or "").lower()
                or search_lower in (e.message or "").lower()
            ]

        total = len(entries)
        return entries[offset : offset + limit], total

    def subscribe(self, thread_id: str) -> asyncio.Queue:
        """Subscribe to real-time log entries for a thread.

        Returns an asyncio.Queue that will receive ``LogEntry`` objects
        as they are appended. Use with WebSocket endpoints.

        Args:
            thread_id: Thread identifier to subscribe to.

        Returns:
            asyncio.Queue that receives LogEntry objects.
        """
        if thread_id not in self._subscribers:
            self._subscribers[thread_id] = set()

        queue: asyncio.Queue = asyncio.Queue(maxsize=500)
        self._subscribers[thread_id].add(queue)
        return queue

    def unsubscribe(self, thread_id: str, queue: asyncio.Queue) -> None:
        """Unsubscribe from real-time log entries.

        Args:
            thread_id: Thread identifier.
            queue: The queue returned by ``subscribe()``.
        """
        subs = self._subscribers.get(thread_id)
        if subs:
            subs.discard(queue)
            if not subs:
                del self._subscribers[thread_id]

    def mark_thread_complete(self, thread_id: str) -> None:
        """Mark a thread as complete, scheduling log buffer purge.

        After ``purge_delay_seconds``, the buffer for this thread is
        removed from memory. Active WebSocket subscribers are sent a
        sentinel ``None`` value to signal stream end.

        Args:
            thread_id: Thread identifier.
        """
        # Track as completed for eviction prioritization.
        if thread_id in self._buffers:
            self._completed_threads[thread_id] = None

        # Notify subscribers that the thread is done
        for queue in self._subscribers.get(thread_id, set()):
            try:
                queue.put_nowait(None)  # Sentinel: stream ended
            except asyncio.QueueFull:
                pass

        # Cancel any existing purge task for this thread
        existing_task = self._purge_tasks.pop(thread_id, None)
        if existing_task and not existing_task.done():
            existing_task.cancel()

        # Schedule purge
        try:
            loop = asyncio.get_running_loop()
            task = loop.create_task(
                self._purge_after_delay(thread_id),
                name=f"log-purge-{thread_id}",
            )
            self._purge_tasks[thread_id] = task
        except RuntimeError:
            # No running loop — purge immediately (e.g., in tests)
            self._buffers.pop(thread_id, None)

    def get_buffered_thread_ids(self) -> List[str]:
        """Return all thread IDs currently in the buffer."""
        return list(self._buffers.keys())

    def has_entries(self, thread_id: str) -> bool:
        """Check if there are buffered entries for a thread."""
        return thread_id in self._buffers and len(self._buffers[thread_id]) > 0

    # ─────────────────────────────────────────────────────────────
    # Internal
    # ─────────────────────────────────────────────────────────────

    async def _purge_after_delay(self, thread_id: str) -> None:
        """Wait and then remove the buffer for a completed thread."""
        try:
            await asyncio.sleep(self._purge_delay)
        except asyncio.CancelledError:
            return

        self._buffers.pop(thread_id, None)
        self._subscribers.pop(thread_id, None)
        self._purge_tasks.pop(thread_id, None)
        self._completed_threads.pop(thread_id, None)
