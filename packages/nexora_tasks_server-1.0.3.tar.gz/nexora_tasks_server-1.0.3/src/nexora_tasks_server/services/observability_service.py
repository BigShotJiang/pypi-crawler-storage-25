"""Observability service — unified API for querying logs, metrics, and events.

Abstracts the difference between Elasticsearch (full history)
and the in-memory ThreadLogBuffer (recent/active threads) backends.
"""

import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional

from nexora_tasks.logging import logger
from nexora_tasks.models.log_models import (
    APMTraceSpan,
    AllTasksMetrics,
    DetailedHealth,
    LogEntry,
    MetricsSummary,
    TaskMetrics,
    ThreadEvent,
    ThreadEventsResponse,
    ThreadLogsResponse,
    ThreadTracesResponse,
    WorkerInfo,
    WorkersResponse,
)
from nexora_tasks.thread_state import ThreadState

if TYPE_CHECKING:
    from nexora_tasks.models.thread import Thread
    from nexora_tasks_server.framework import NexoraTasks
    from nexora_tasks_server.services.thread_log_buffer import ThreadLogBuffer

TraceSpanLayer = Literal["framework", "infrastructure", "application"]

# Module-level state for OTel exporter sub-status (J14). The last_export
# timestamp is sticky across calls so a brief collector blip doesn't erase
# the "we did successfully export at some point" signal.
_LAST_SUCCESSFUL_EXPORT_TS: Optional[str] = None


def _probe_otel_collector() -> tuple[bool, Optional[str], int]:
    """Probe the configured OTLP collector via TCP and report health.

    Returns ``(reachable, last_successful_export_iso, queue_size)``.

    ``reachable`` reflects a live TCP connect to the host:port parsed from
    ``OTEL_EXPORTER_OTLP_ENDPOINT``. On success, ``_LAST_SUCCESSFUL_EXPORT_TS``
    is bumped to "now" (UTC ISO). ``queue_size`` is reported as 0 because the
    OTel BatchSpanProcessor queue depth is not exposed via a public API; the
    field is kept on the response so callers can assert its shape (int).
    """
    import os
    import socket
    from urllib.parse import urlparse

    global _LAST_SUCCESSFUL_EXPORT_TS

    endpoint = os.environ.get(
        "OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317"
    )
    parsed = urlparse(endpoint if "://" in endpoint else f"http://{endpoint}")
    host = parsed.hostname or "localhost"
    port = parsed.port or (4317 if (parsed.scheme or "http") in ("http", "grpc") else 4318)

    reachable = False
    try:
        with socket.create_connection((host, port), timeout=2.0):
            reachable = True
    except OSError:
        reachable = False

    if reachable:
        _LAST_SUCCESSFUL_EXPORT_TS = datetime.now(timezone.utc).isoformat()

    return reachable, _LAST_SUCCESSFUL_EXPORT_TS, 0


def classify_waterfall_span_layer(
    name: str,
    scope_name: Optional[str],
    attributes: Optional[Dict[str, Any]],
) -> TraceSpanLayer:
    """Classify an OTel span for the thread trace waterfall UI.

    Heuristic only (no extra span attributes required from task authors):

    - **framework**: Nexora Tasks server/worker instrumentation (``task_execution``,
      ``worker.*``, tracers whose scope mentions ``nexora_tasks``).
    - **infrastructure**: Auto-instrumentation (OpenTelemetry ``instrumentation.*``
      scopes), HTTP spans, generic DB client spans (``db.system``), and short
      Elasticsearch verb names often emitted by clients.
    - **application**: Everything else (typical hand-crafted spans from task code).
    """
    n = (name or "").strip()
    ln = n.lower()
    scope = (scope_name or "").lower()
    attrs = attributes if isinstance(attributes, dict) else {}

    def _attr(*keys: str) -> Any:
        for k in keys:
            if k in attrs:
                return attrs[k]
        return None

    if "nexora_tasks" in scope or "nexora_tasks_server" in scope:
        return "framework"

    if n == "task_execution" or ln.startswith("worker."):
        return "framework"

    if "opentelemetry.instrumentation" in scope:
        return "infrastructure"

    if _attr("http.request.method", "http_request_method"):
        return "infrastructure"

    if any(n.startswith(pref + " ") for pref in ("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD")):
        return "infrastructure"

    if "http receive" in ln or "http send" in ln:
        return "infrastructure"

    db_sys = str(_attr("db.system", "db_system") or "").lower()
    if db_sys in ("elasticsearch", "redis", "postgresql", "mysql", "mongodb", "sqlite"):
        return "infrastructure"

    if len(n) <= 12 and ln in ("index", "get", "search", "bulk", "mget", "update", "delete", "count"):
        return "infrastructure"

    if ln == "span":
        return "infrastructure"

    return "application"


def _otel_scope_name(src: Dict[str, Any]) -> Optional[str]:
    scope = src.get("scope")
    if isinstance(scope, dict):
        name = scope.get("name")
        if name:
            return str(name)
    flat = src.get("scope.name")
    if flat:
        return str(flat)
    return None


def _source_to_service_name(source: str) -> str:
    return {
        "server": "nexora-tasks-server",
        "worker": "nexora-tasks-worker",
        "stdout": "nexora-tasks-worker",
        "stderr": "nexora-tasks-worker",
    }.get(source, "nexora-tasks-server")


def _service_name_to_source(service_name: Optional[str]) -> str:
    if service_name == "nexora-tasks-worker":
        return "worker"
    return "server"


class ObservabilityService:
    """Unified API for querying observability data.

    Routes log queries to Elasticsearch or the in-memory buffer
    depending on backend availability, and reads metrics directly
    from the in-process Prometheus registry.
    """

    def __init__(
        self,
        framework: "NexoraTasks",
    ) -> None:
        self._framework = framework
        self._server_start_time = time.monotonic()

    @property
    def _log_buffer(self) -> "ThreadLogBuffer":
        return self._framework.log_buffer

    # ─────────────────────────────────────────────────────────────
    # Thread Logs
    # ─────────────────────────────────────────────────────────────

    async def get_thread_logs(
        self,
        thread_id: str,
        level: Optional[str] = None,
        source: Optional[str] = None,
        after: Optional[datetime] = None,
        before: Optional[datetime] = None,
        search: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> ThreadLogsResponse:
        """Get logs for a thread.

        If Elasticsearch is available, queries logs-generic.otel-default index with
        thread_id filter. When that index has no rows (common if the OTel Collector
        is not shipping app logs), falls back to the in-memory buffer and then to
        the on-disk JSONL sink (same order as file-backed deployments).
        """
        file_sink = getattr(self._log_buffer, "_file_sink", None)

        # Try Elasticsearch first when configured
        if self._has_elasticsearch():
            try:
                es_resp = await self._get_logs_from_es(
                    thread_id, level, source, after, before, search, limit, offset
                )
                if es_resp.total > 0 or len(es_resp.entries) > 0:
                    return es_resp
                # ES returned no documents — continue to buffer / file (restart-safe)
            except Exception as e:
                logger.warning(
                    "observability.es_logs_failed",
                    thread_id=thread_id,
                    error=str(e),
                )

        # In-memory ring buffer (live execution + recent history before purge)
        entries, total = self._log_buffer.get_entries(
            thread_id=thread_id,
            level=level,
            source=source,
            after=after,
            before=before,
            search=search,
            limit=limit,
            offset=offset,
        )

        # If buffer is empty, try file-based persistent log sink
        if total == 0 and file_sink is not None:
            try:
                entries, total = await file_sink.get_entries(
                    thread_id=thread_id,
                    level=level,
                    source=source,
                    after=after,
                    before=before,
                    search=search,
                    limit=limit,
                    offset=offset,
                )
            except Exception as e:
                logger.warning(
                    "observability.file_sink_logs_failed",
                    thread_id=thread_id,
                    error=str(e),
                )

        return ThreadLogsResponse(
            thread_id=thread_id,
            entries=entries,
            total=total,
            has_more=(offset + limit) < total,
        )

    # ─────────────────────────────────────────────────────────────
    # Thread Events (derived from Thread model)
    # ─────────────────────────────────────────────────────────────

    def get_thread_events(self, thread: "Thread") -> ThreadEventsResponse:
        """Derive lifecycle events from a Thread model.

        Events are always available, regardless of logging backend.
        """
        events: List[ThreadEvent] = []

        # Created
        events.append(ThreadEvent(
            timestamp=thread.created_at,
            type="state_change",
            data={"state": "queued", "message": "Thread created"},
        ))

        # Started
        if thread.started_at:
            events.append(ThreadEvent(
                timestamp=thread.started_at,
                type="state_change",
                data={
                    "state": "running",
                    "message": "Execution started",
                    "queue_duration_seconds": thread.queue_duration_seconds,
                },
            ))

        # Progress (current snapshot if available)
        if thread.progress is not None and thread.progress > 0:
            events.append(ThreadEvent(
                timestamp=thread.started_at or thread.created_at,
                type="progress",
                data={
                    "value": thread.progress,
                    "message": thread.progress_message or "",
                },
            ))

        # Error
        if thread.error:
            timestamp = thread.finished_at or thread.started_at or thread.created_at
            events.append(ThreadEvent(
                timestamp=timestamp,
                type="error",
                data={
                    "error_type": thread.error.exception_type,
                    "error_message": thread.error.message,
                    "traceback": thread.error.stack_trace[:500] if thread.error.stack_trace else "",
                },
            ))

        # Finished
        if thread.finished_at:
            state_str = thread.state if isinstance(thread.state, str) else thread.state.value if hasattr(thread.state, "value") else str(thread.state)
            events.append(ThreadEvent(
                timestamp=thread.finished_at,
                type="state_change",
                data={
                    "state": state_str,
                    "message": f"Thread {state_str}",
                    "execution_duration_seconds": thread.execution_duration_seconds,
                    "total_duration_seconds": thread.total_duration_seconds,
                },
            ))

        # Retry info
        if thread.attempt and thread.attempt > 1:
            events.append(ThreadEvent(
                timestamp=thread.created_at,
                type="retry",
                data={"attempt": thread.attempt},
            ))

        # Schedule info
        if thread.schedule_id:
            events.append(ThreadEvent(
                timestamp=thread.created_at,
                type="schedule_triggered",
                data={
                    "schedule_id": thread.schedule_id,
                    "run_id": thread.run_id,
                },
            ))

        # Sort by timestamp
        events.sort(key=lambda e: e.timestamp)

        return ThreadEventsResponse(
            thread_id=thread.id,
            events=events,
        )

    # ─────────────────────────────────────────────────────────────
    # OTel traces (Elasticsearch via OTel Collector `mapping.mode: otel`)
    # ─────────────────────────────────────────────────────────────

    def _elasticsearch_client(self) -> Optional[Any]:
        db = self._framework.database
        if db is None:
            return None
        return getattr(db, "_client", None)

    @staticmethod
    def _is_elasticsearch_otel_index_missing(exc: BaseException) -> bool:
        """True when the OTel traces backing index/data stream does not exist yet.

        Elasticsearch only creates ``traces-generic.otel-default`` after the
        collector successfully ingests spans. Until then, ``_search`` raises
        ``index_not_found_exception`` — treat as empty traces, not an error.
        """
        try:
            from elasticsearch import NotFoundError as ESNotFoundError
        except ImportError:
            ESNotFoundError = None  # type: ignore[misc,assignment]

        if ESNotFoundError is not None and isinstance(exc, ESNotFoundError):
            body = exc.body if isinstance(getattr(exc, "body", None), dict) else {}
            err = body.get("error")
            if isinstance(err, dict):
                if err.get("type") == "index_not_found_exception":
                    return True
                for cause in err.get("root_cause") or ():
                    if isinstance(cause, dict) and cause.get("type") == "index_not_found_exception":
                        return True
            return False

        text = str(exc).lower()
        return "index_not_found_exception" in text and "no such index" in text

    async def get_thread_traces(self, thread_id: str) -> ThreadTracesResponse:
        """Load OTel trace spans for a thread from Elasticsearch.

        Queries the OTel Collector ES exporter index (default
        ``traces-generic.otel-default``) for documents whose
        ``attributes.nexora_tasks.thread_id`` matches ``thread_id``,
        resolves the ``trace_id``, then loads all spans sharing that id and
        builds a waterfall. Field paths are lowercase because the Collector
        is configured with ``mapping.mode: otel`` (matches the ES OTel
        data-stream template's dynamic_templates).
        """
        import os

        if not self._has_elasticsearch():
            return ThreadTracesResponse(
                query_supported=False,
                found=False,
                message=(
                    "OTel traces are read from Elasticsearch. Set "
                    "STORAGE_TYPE=elasticsearch and ensure the OTel Collector "
                    "is exporting to the same cluster (default index "
                    "traces-generic.otel-default)."
                ),
            )

        es = self._elasticsearch_client()
        if es is None:
            return ThreadTracesResponse(
                query_supported=False,
                found=False,
                message="Elasticsearch client is not available on this database backend.",
            )

        index_pattern = os.environ.get(
            "OTEL_TRACES_INDEX",
            "traces-generic.otel-default",
        ).strip()

        attr_clause = {
            "term": {"attributes.nexora_tasks.thread_id": thread_id}
        }

        missing_index_msg = (
            "The OTel traces index does not exist yet (no spans have been indexed). "
            "It is created when the OpenTelemetry Collector first exports traces to "
            f"Elasticsearch — e.g. call /health or run a thread, then retry. Index: {index_pattern}."
        )

        try:
            first = await es.search(
                index=index_pattern,
                body={
                    "size": 1,
                    "sort": [{"@timestamp": "desc"}],
                    "query": {"bool": {"must": [attr_clause]}},
                },
            )
        except Exception as e:
            if self._is_elasticsearch_otel_index_missing(e):
                logger.debug(
                    "observability.otel_traces_index_not_yet_created",
                    index=index_pattern,
                )
                return ThreadTracesResponse(
                    query_supported=True,
                    found=False,
                    message=missing_index_msg,
                )
            logger.warning("observability.otel_trace_lookup_failed", error=str(e))
            return ThreadTracesResponse(
                query_supported=True,
                found=False,
                message=f"Could not query OTel index ({index_pattern}): {e}",
            )

        hits = first.get("hits", {}).get("hits", [])
        if not hits:
            return ThreadTracesResponse(
                query_supported=True,
                found=False,
                message=(
                    "No OTel spans tagged with nexora_tasks.thread_id for this "
                    "thread. Check that the OTel Collector is up and exporting "
                    "to traces-generic.otel-default."
                ),
            )

        src0 = hits[0].get("_source", {})
        trace_id = src0.get("trace_id") or src0.get("trace", {}).get("id")
        if not trace_id:
            return ThreadTracesResponse(
                query_supported=True,
                found=False,
                message="Matched OTel document has no trace_id.",
            )

        try:
            full = await es.search(
                index=index_pattern,
                body={
                    "size": 500,
                    "sort": [{"@timestamp": "asc"}],
                    "query": {"term": {"trace_id": trace_id}},
                },
            )
        except Exception as e:
            if self._is_elasticsearch_otel_index_missing(e):
                logger.debug(
                    "observability.otel_traces_index_not_yet_created",
                    index=index_pattern,
                    trace_id=trace_id,
                )
                return ThreadTracesResponse(
                    query_supported=True,
                    found=False,
                    trace_id=trace_id,
                    message=missing_index_msg,
                )
            logger.warning("observability.otel_trace_fetch_failed", error=str(e))
            return ThreadTracesResponse(
                query_supported=True,
                found=False,
                trace_id=trace_id,
                message=f"Could not load spans for trace: {e}",
            )

        all_hits = full.get("hits", {}).get("hits", [])
        spans = self._build_otel_waterfall(all_hits)
        return ThreadTracesResponse(
            query_supported=True,
            found=bool(spans),
            trace_id=trace_id,
            spans=spans,
            message=None if spans else "Trace id resolved but no spans parsed.",
        )

    def _build_otel_waterfall(self, hits: List[Dict[str, Any]]) -> List[APMTraceSpan]:
        raw: List[Dict[str, Any]] = []
        for h in hits:
            src = h.get("_source", {})
            sid = src.get("span_id")
            if not sid:
                continue
            parent = src.get("parent_span_id") or None
            duration_ns = int(src.get("duration") or 0)
            duration_us = duration_ns // 1000
            t_us = self._otel_timestamp_us(src)
            name = str(src.get("name") or "span")
            kind_raw = str(src.get("kind") or "Internal")
            # Treat root spans (no parent) as transactions for UI parity.
            kind = "transaction" if not parent else "span"
            attrs = src.get("attributes")
            if not isinstance(attrs, dict):
                attrs = {}
            scope_nm = _otel_scope_name(src)
            layer = classify_waterfall_span_layer(name, scope_nm, attrs)
            raw.append(
                {
                    "id": sid,
                    "parent_id": parent,
                    "name": name,
                    "kind": kind,
                    "subtype": kind_raw,
                    "duration_us": duration_us,
                    "ts_us": t_us,
                    "layer": layer,
                }
            )

        if not raw:
            return []

        times = [x["ts_us"] for x in raw if x.get("ts_us")]
        trace_start_us = min(times) if times else 0

        by_id = {x["id"]: x for x in raw}
        depth_cache: Dict[str, int] = {}

        def depth_for(nid: str) -> int:
            if nid in depth_cache:
                return depth_cache[nid]
            node = by_id.get(nid)
            if not node:
                depth_cache[nid] = 0
                return 0
            pid = node.get("parent_id")
            if not pid or pid not in by_id:
                depth_cache[nid] = 0
                return 0
            depth_cache[nid] = 1 + depth_for(pid)
            return depth_cache[nid]

        for nid in list(by_id.keys()):
            depth_for(nid)

        out: List[APMTraceSpan] = []
        for x in raw:
            d_us = x["duration_us"]
            ts_us = x["ts_us"] or trace_start_us
            out.append(
                APMTraceSpan(
                    id=x["id"],
                    parent_id=x.get("parent_id"),
                    name=x["name"],
                    kind=x["kind"],
                    subtype=x.get("subtype"),
                    duration_ms=round(d_us / 1000.0, 3),
                    start_offset_ms=round((ts_us - trace_start_us) / 1000.0, 3),
                    depth=depth_cache.get(x["id"], 0),
                    layer=x.get("layer", "application"),
                )
            )

        out.sort(key=lambda s: (s.start_offset_ms, s.depth, s.name))
        return out

    @staticmethod
    def _otel_timestamp_us(src: Dict[str, Any]) -> int:
        """Parse @timestamp to epoch microseconds (UTC)."""
        ts = src.get("@timestamp")
        if not ts:
            return 0
        if isinstance(ts, datetime):
            dt = ts if ts.tzinfo else ts.replace(tzinfo=timezone.utc)
            return int(dt.timestamp() * 1_000_000)
        s = str(ts)
        try:
            if s.endswith("Z"):
                s = s[:-1] + "+00:00"
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return int(dt.timestamp() * 1_000_000)
        except Exception:
            return 0

    # ─────────────────────────────────────────────────────────────
    # Metrics (from Prometheus registry)
    # ─────────────────────────────────────────────────────────────

    def get_metrics_summary(self) -> MetricsSummary:
        """Get server-wide metrics overview from the OTel InMemoryMetricReader."""
        from nexora_tasks_server.observability.metrics import get_admin_reader

        threads_data: Dict[str, Any] = {}
        workers_data: Dict[str, Any] = {}
        api_data: Dict[str, Any] = {}
        db_data: Dict[str, Any] = {}

        reader = get_admin_reader()
        data = reader.get_metrics_data() if reader else None
        for rm in (data.resource_metrics if data else []):
            for sm in rm.scope_metrics:
                for metric in sm.metrics:
                    name = metric.name
                    for dp in metric.data.data_points:
                        val = int(getattr(dp, "value", 0)) if hasattr(dp, "value") else int(getattr(dp, "count", 0))
                        if name == "nexora_tasks.threads.total":
                            state = dp.attributes.get("state", "unknown")
                            threads_data[state] = threads_data.get(state, 0) + val
                        elif name == "nexora_tasks.threads.current":
                            state = dp.attributes.get("state", "unknown")
                            threads_data[f"current_{state}"] = threads_data.get(f"current_{state}", 0) + val
                        elif name == "nexora_tasks.workers.active":
                            workers_data["active"] = val
                        elif name == "nexora_tasks.workers.idle":
                            workers_data["idle"] = val
                        elif name == "nexora_tasks.worker.restarts.total":
                            workers_data["total_restarts"] = workers_data.get("total_restarts", 0) + val
                        elif name == "nexora_tasks.api.requests.total":
                            api_data["total_requests"] = api_data.get("total_requests", 0) + val
                        elif name == "nexora_tasks.db.operation.duration":
                            op = dp.attributes.get("operation", "unknown")
                            db_data[f"{op}_count"] = db_data.get(f"{op}_count", 0) + int(getattr(dp, "count", 0))

        uptime = time.monotonic() - self._server_start_time

        return MetricsSummary(
            threads=threads_data,
            workers=workers_data,
            api=api_data,
            database=db_data,
            uptime_seconds=round(uptime, 1),
            collected_at=datetime.now(timezone.utc),
        )

    def get_task_metrics(self, task_id: str) -> TaskMetrics:
        """Get metrics for a specific task from the OTel InMemoryMetricReader."""
        from nexora_tasks_server.observability.metrics import get_admin_reader

        threads_data: Dict[str, Any] = {}
        execution_data: Dict[str, Any] = {}
        queue_data: Dict[str, Any] = {}
        errors_data: Dict[str, Any] = {}
        worker_data: Dict[str, Any] = {}

        reader = get_admin_reader()
        data = reader.get_metrics_data() if reader else None
        for rm in (data.resource_metrics if data else []):
            for sm in rm.scope_metrics:
                for metric in sm.metrics:
                    name = metric.name
                    for dp in metric.data.data_points:
                        if dp.attributes.get("task_id") != task_id:
                            continue
                        if name == "nexora_tasks.threads.total":
                            state = dp.attributes.get("state", "unknown")
                            threads_data[state] = int(getattr(dp, "value", 0))
                        elif name == "nexora_tasks.threads.current":
                            state = dp.attributes.get("state", "unknown")
                            threads_data[f"current_{state}"] = int(getattr(dp, "value", 0))
                        elif name == "nexora_tasks.thread.execution.duration":
                            execution_data["sum_seconds"] = getattr(dp, "sum", 0)
                            execution_data["count"] = int(getattr(dp, "count", 0))
                            execution_data.setdefault("buckets", {})
                            bounds = list(getattr(dp, "explicit_bounds", []))
                            counts = list(getattr(dp, "bucket_counts", []))
                            cumulative = 0
                            for i, bound in enumerate(bounds):
                                cumulative += counts[i] if i < len(counts) else 0
                                execution_data["buckets"][str(bound)] = cumulative
                            if counts:
                                cumulative += counts[len(bounds)] if len(bounds) < len(counts) else 0
                                execution_data["buckets"]["+Inf"] = cumulative
                        elif name == "nexora_tasks.thread.queue.duration":
                            queue_data["sum_seconds"] = getattr(dp, "sum", 0)
                            queue_data["count"] = int(getattr(dp, "count", 0))
                        elif name == "nexora_tasks.thread.errors.total":
                            error_type = dp.attributes.get("error_type", "unknown")
                            errors_data[error_type] = int(getattr(dp, "value", 0))
                        elif name == "nexora_tasks.worker.startup.duration":
                            worker_data["startup_sum_seconds"] = getattr(dp, "sum", 0)
                            worker_data["startup_count"] = int(getattr(dp, "count", 0))
                        elif name == "nexora_tasks.worker.restarts.total":
                            worker_data["restarts"] = int(getattr(dp, "value", 0))
                        elif name == "nexora_tasks.worker.pending.executions":
                            worker_data["pending_executions"] = int(getattr(dp, "value", 0))

        # Compute averages
        if execution_data.get("count", 0) > 0:
            execution_data["avg_seconds"] = round(
                execution_data.get("sum_seconds", 0) / execution_data["count"], 3
            )
        if queue_data.get("count", 0) > 0:
            queue_data["avg_seconds"] = round(
                queue_data.get("sum_seconds", 0) / queue_data["count"], 3
            )

        return TaskMetrics(
            task_id=task_id,
            threads=threads_data,
            execution=execution_data,
            queue=queue_data,
            errors=errors_data,
            worker=worker_data,
        )

    def get_all_tasks_metrics(self) -> AllTasksMetrics:
        """Get metrics for all tasks."""
        from nexora_tasks_server.observability.metrics import get_admin_reader

        task_ids: set = set()
        reader = get_admin_reader()
        data = reader.get_metrics_data() if reader else None
        for rm in (data.resource_metrics if data else []):
            for sm in rm.scope_metrics:
                for metric in sm.metrics:
                    if metric.name in (
                        "nexora_tasks.threads.total",
                        "nexora_tasks.threads.current",
                    ):
                        for dp in metric.data.data_points:
                            tid = dp.attributes.get("task_id")
                            if tid:
                                task_ids.add(tid)

        tasks = [self.get_task_metrics(tid) for tid in sorted(task_ids)]
        return AllTasksMetrics(
            tasks=tasks,
            collected_at=datetime.now(timezone.utc),
        )

    # ─────────────────────────────────────────────────────────────
    # Workers
    # ─────────────────────────────────────────────────────────────

    def get_workers_info(self) -> WorkersResponse:
        """Get worker subprocess status from WorkerManager."""
        now = datetime.now(timezone.utc)
        workers = []

        for info in self._framework.worker_manager.get_worker_info():
            started = datetime.fromisoformat(info["started_at"]) if isinstance(info["started_at"], str) else info["started_at"]
            uptime = (now - started).total_seconds() if started else 0
            workers.append(WorkerInfo(
                full_id=info["full_id"],
                task_id=info["task_id"],
                version=info["version"],
                pid=info["pid"],
                alive=info["alive"],
                restart_count=info["restart_count"],
                active_executions=info["active_executions"],
                started_at=started,
                uptime_seconds=round(uptime, 1),
                last_pong=info.get("last_pong"),
            ))

        active = sum(1 for w in workers if w.alive)
        idle = sum(1 for w in workers if w.alive and w.active_executions == 0)

        return WorkersResponse(
            workers=workers,
            total_active=active,
            total_idle=idle,
            collected_at=now,
        )

    # ─────────────────────────────────────────────────────────────
    # Detailed Health
    # ─────────────────────────────────────────────────────────────

    async def get_detailed_health(self) -> DetailedHealth:
        """Get detailed server health including all subsystem statuses."""
        from nexora_tasks.version import VERSION

        uptime = time.monotonic() - self._server_start_time
        health = DetailedHealth(
            status="healthy",
            version=VERSION,
            uptime_seconds=round(uptime, 1),
        )

        # Database health
        try:
            db = self._framework.database
            db_type = type(db).__name__
            health.database = {"type": db_type, "status": "connected"}
        except Exception as e:
            health.database = {"status": "error", "error": str(e)}
            health.status = "degraded"

        # Storage health
        try:
            storage = self._framework.file_storage
            storage_type = type(storage).__name__
            health.storage = {"type": storage_type, "status": "connected"}
        except Exception as e:
            health.storage = {"status": "error", "error": str(e)}
            health.status = "degraded"

        # Scheduler health
        try:
            scheduler = self._framework.scheduler
            health.scheduler = {
                "status": "running" if scheduler else "not_configured",
            }
        except Exception:
            health.scheduler = {"status": "not_configured"}

        # Worker summary
        worker_info = self.get_workers_info()
        health.workers = {
            "total_active": worker_info.total_active,
            "total_idle": worker_info.total_idle,
            "total_workers": len(worker_info.workers),
        }

        # Observability config + OTel exporter sub-status (Group J spec J14).
        import os
        collector_reachable, last_export_ts, queue_size = _probe_otel_collector()
        health.observability = {
            "log_buffer_max_entries": int(os.environ.get("LOG_BUFFER_MAX_ENTRIES", "1000")),
            "database_type": os.environ.get("STORAGE_TYPE", "file"),
            "metrics_enabled": True,
            "tracing_enabled": bool(os.environ.get("ELASTIC_APM_SERVER_URL")),
            "collector_reachable": collector_reachable,
            "exporter_healthy": collector_reachable,
            "last_successful_export": last_export_ts,
            "queue_size": queue_size,
        }

        return health

    # ─────────────────────────────────────────────────────────────
    # Internal: Elasticsearch helpers
    # ─────────────────────────────────────────────────────────────

    def _has_elasticsearch(self) -> bool:
        """Check if Elasticsearch backend is available."""
        import os
        return os.environ.get("STORAGE_TYPE", "file").lower() == "elasticsearch"

    async def _get_logs_from_es(
        self,
        thread_id: str,
        level: Optional[str] = None,
        source: Optional[str] = None,
        after: Optional[datetime] = None,
        before: Optional[datetime] = None,
        search: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> ThreadLogsResponse:
        """Query thread logs from the OTel-managed logs-generic.otel-default index.

        Records are written by the OTel Collector with ECS mapping. This method
        reshapes them back into the existing ``LogEntry`` / ``ThreadLogsResponse``
        contract so the ``/threads/{id}/logs`` endpoint response is unchanged.
        """
        db = self._framework.database

        must = [{"term": {"attributes.nexora_tasks.thread_id": thread_id}}]
        if level:
            must.append({"term": {"severity_text": level.upper()}})
        if source and source != "all":
            must.append({"term": {"resource.attributes.service.name": _source_to_service_name(source)}})
        if search:
            must.append({"multi_match": {"query": search, "fields": ["body.text", "attributes.message"]}})

        time_range: Dict[str, Any] = {}
        if after:
            time_range["gte"] = after.isoformat()
        if before:
            time_range["lte"] = before.isoformat()
        if time_range:
            must.append({"range": {"@timestamp": time_range}})

        query = {"bool": {"must": must}}

        es = self._elasticsearch_client()
        if es is None:
            raise RuntimeError("Elasticsearch client not available")

        result = await es.search(
            index="logs-generic.otel-default",
            body={
                "query": query,
                "sort": [{"@timestamp": "asc"}],
                "size": limit,
                "from": offset,
            },
        )

        entries = []
        for hit in result["hits"]["hits"]:
            src = hit["_source"]
            attrs = src.get("attributes", {}) or {}
            tf = attrs.get("nexora_tasks", {}) or {}
            body = src.get("body", {}) or {}
            body_text = body.get("text", "") if isinstance(body, dict) else str(body)
            entries.append(LogEntry(
                timestamp=src.get("@timestamp"),
                level=str(src.get("severity_text", "INFO")).lower(),
                event=body_text,
                message=attrs.get("message"),
                source=_service_name_to_source(
                    ((src.get("resource") or {}).get("attributes") or {}).get("service.name")
                ),
                thread_id=tf.get("thread_id"),
                data={k: v for k, v in attrs.items() if k != "nexora_tasks"},
            ))

        total = result["hits"]["total"]
        total_count = total["value"] if isinstance(total, dict) else total

        return ThreadLogsResponse(
            thread_id=thread_id,
            entries=entries,
            total=total_count,
            has_more=(offset + limit) < total_count,
        )
