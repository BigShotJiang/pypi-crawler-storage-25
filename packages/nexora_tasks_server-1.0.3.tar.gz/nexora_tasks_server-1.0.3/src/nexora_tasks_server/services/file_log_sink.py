"""File-based persistent log sink for thread log entries.

Writes per-thread JSONL files so that log history survives the in-memory
ring buffer purge and server restarts. Used whenever the sink is enabled
(see ``NexoraTasks`` / ``THREAD_LOG_DISABLE_FILE_SINK``), including as a
fallback when Elasticsearch log queries return no documents.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import aiofiles

from nexora_tasks.logging import logger
from nexora_tasks.models.log_models import LogEntry


class FileLogSink:
    """Append-only JSONL log sink, one file per thread.

    Logs are stored at ``{data_dir}/threads/{thread_id}/logs.jsonl``.
    Each line is a JSON-serialised ``LogEntry``.
    """

    def __init__(self, data_dir: str = "data") -> None:
        self._data_dir = Path(data_dir)

    def _log_path(self, thread_id: str) -> Path:
        return self._data_dir / "threads" / thread_id / "logs.jsonl"

    async def append(self, thread_id: str, entry: LogEntry) -> None:
        """Append a single log entry to the thread's JSONL file."""
        path = self._log_path(thread_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            async with aiofiles.open(path, "a") as f:
                await f.write(entry.model_dump_json() + "\n")
        except Exception as exc:
            logger.warning(
                "file_log_sink.append_failed",
                thread_id=thread_id,
                error=str(exc),
            )

    async def get_entries(
        self,
        thread_id: str,
        level: Optional[str] = None,
        source: Optional[str] = None,
        after: Optional[datetime] = None,
        before: Optional[datetime] = None,
        search: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Tuple[List[LogEntry], int]:
        """Read and filter log entries from the thread's JSONL file.

        Returns:
            Tuple of (filtered entries page, total matching count).
        """
        path = self._log_path(thread_id)
        if not path.exists():
            return [], 0

        entries: List[LogEntry] = []
        try:
            async with aiofiles.open(path, "r") as f:
                async for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entries.append(LogEntry.model_validate_json(line))
                    except Exception:
                        continue
        except Exception as exc:
            logger.warning(
                "file_log_sink.read_failed",
                thread_id=thread_id,
                error=str(exc),
            )
            return [], 0

        if level:
            entries = [e for e in entries if e.level == level]
        if source and source != "all":
            entries = [e for e in entries if e.source == source]
        if after:
            entries = [e for e in entries if e.timestamp > after]
        if before:
            entries = [e for e in entries if e.timestamp < before]
        if search:
            search_lower = search.lower()
            entries = [
                e
                for e in entries
                if search_lower in (e.event or "").lower()
                or search_lower in (e.message or "").lower()
            ]

        total = len(entries)
        return entries[offset : offset + limit], total
