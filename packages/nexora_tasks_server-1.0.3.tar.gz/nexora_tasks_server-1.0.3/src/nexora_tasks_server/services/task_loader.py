"""Task loader service for dynamic task function loading using uv."""

import asyncio
import importlib.util
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional, Tuple

from nexora_tasks.logging import logger
from nexora_tasks.models.task_definition import TaskDefinition, TaskMetadata
from nexora_tasks_server.repositories.file_db import FileDatabase
from nexora_tasks_server.repositories.task_storage import TaskStorage
from nexora_tasks_server.storage.local import LocalFileStorage
from nexora_tasks.utils.task_packaging import (
    TaskPackageError,
    TaskPackageValidator,
    extract_zip_async,
    calculate_zip_hash_async,
)


class TaskLoaderError(Exception):
    """Exception raised for task loading errors."""
    pass


class TaskLoader:
    """Service for loading task functions from deployed code.
    
    Handles:
    - Zip extraction
    - Virtual environment creation using uv
    - Dependency installation
    - Dynamic task function loading
    """
    
    def __init__(self, task_storage: TaskStorage, framework_path: Optional[str] = None) -> None:
        """Initialize TaskLoader.
        
        Args:
            task_storage: TaskStorage repository for path management
            framework_path: Optional path to local nexora-tasks source for development.
                           If provided, nexora-tasks will be installed from this path
                           instead of PyPI.
        """
        self.task_storage = task_storage
        self.framework_path = framework_path
    
    async def load_from_zip(self, zip_path: str) -> TaskDefinition:
        """Load a task from a zip file.
        
        This is the main entry point for loading a new task.
        
        Args:
            zip_path: Path to the task definition zip file
            
        Returns:
            TaskDefinition with loaded task function
            
        Raises:
            TaskLoaderError: If loading fails at any step
        """
        zip_path = Path(zip_path)
        
        # Validate zip package
        validator = TaskPackageValidator(str(zip_path))
        is_valid, error = validator.validate()
        if not is_valid:
            raise TaskLoaderError(f"Invalid task package: {error}")
        
        # Get metadata
        try:
            metadata = validator.get_metadata()
        except TaskPackageError as e:
            raise TaskLoaderError(f"Failed to read metadata: {e}")
        
        task_id = metadata.name
        version = metadata.version
        
        logger.info(
            "task_loader.loading",
            zip_path=str(zip_path),
            task_id=task_id,
            version=version,
        )
        
        # Create directories
        paths = await self.task_storage.create_task_directories(task_id, version)
        code_path = paths["code_path"]
        venv_path = paths["venv_path"]
        data_path = paths["data_path"]
        storage_path = paths["storage_path"]
        
        # Extract zip to code directory
        await extract_zip_async(str(zip_path), code_path)
        
        # Runtime-specific setup
        runtime = getattr(metadata, 'runtime', 'python')
        
        if runtime == 'node':
            # Node.js: install npm dependencies instead of venv
            await self._install_node_dependencies(code_path)
        else:
            # Python: create virtual environment + install pip deps
            await self._create_venv(venv_path)
            await self._install_dependencies(code_path, venv_path)
        
        # Calculate zip hash
        zip_hash = await calculate_zip_hash_async(str(zip_path))
        
        # Create TaskDefinition
        task_def = TaskDefinition.from_metadata(
            metadata=metadata,
            base_path=Path(paths["base_path"]),
            zip_path=str(zip_path),
            zip_hash=zip_hash,
        )
        
        # Load task function (skip in worker mode and for node tasks)
        import os
        execution_mode = os.environ.get("TASK_EXECUTION_MODE", "worker")
        runtime = getattr(metadata, 'runtime', 'python')
        if runtime == 'node':
            # Node tasks are loaded by node-runner.js, not Python
            logger.info(
                "task_loader.skipping_python_load",
                task_id=task_id,
                version=version,
                reason="node_runtime",
            )
        elif execution_mode != "worker":
            task_function = await self._load_task_function(code_path, metadata.entry_point)
            task_def.set_task_function(task_function)
        else:
            logger.info(
                "task_loader.skipping_inprocess_load",
                task_id=task_id,
                version=version,
                reason="worker_mode",
            )
        
        # Note: Database and file storage are now managed at the framework level,
        # not per-task. Tasks share the same storage.
        
        logger.info(
            "task_loader.loaded",
            task_id=task_id,
            version=version,
            entry_point=metadata.entry_point,
        )
        
        return task_def
    
    async def load_existing(
        self,
        task_id: str,
        version: str,
        metadata: TaskMetadata,
        deployed_at: Optional[datetime] = None,
    ) -> TaskDefinition:
        """Load an already-deployed task (for server restart).
        
        Args:
            task_id: Task identifier
            version: Task version
            metadata: TaskMetadata from stored metadata
            deployed_at: Optional deployment timestamp to preserve
            
        Returns:
            TaskDefinition with loaded task function
            
        Raises:
            TaskLoaderError: If loading fails
        """
        base_path = self.task_storage.get_task_base_path(task_id, version)
        code_path = self.task_storage.get_code_path(task_id, version)
        data_path = self.task_storage.get_data_path(task_id, version)
        storage_path = self.task_storage.get_storage_path(task_id, version)
        
        # Check if code exists
        if not await self.task_storage.code_exists(task_id, version):
            raise TaskLoaderError(f"Task code not found for {task_id}:{version}")
        
        # Create TaskDefinition with preserved deployed_at
        task_def = TaskDefinition.from_metadata(
            metadata=metadata,
            base_path=base_path,
            deployed_at=deployed_at,
        )
        
        # Load task function (skip in worker mode — worker loads it independently)
        import os
        execution_mode = os.environ.get("TASK_EXECUTION_MODE", "worker")
        if execution_mode != "worker":
            task_function = await self._load_task_function(str(code_path), metadata.entry_point)
            task_def.set_task_function(task_function)
        else:
            logger.info(
                "task_loader.skipping_inprocess_load",
                task_id=task_id,
                version=version,
                reason="worker_mode",
            )
        
        # Note: Database and file storage are now managed at the framework level,
        # not per-task. Tasks share the same storage.
        
        logger.info(
            "task_loader.loaded_existing",
            task_id=task_id,
            version=version,
        )
        
        return task_def
    
    async def _create_venv(self, venv_path: str) -> None:
        """Create a virtual environment using uv.
        
        Args:
            venv_path: Path for the virtual environment
            
        Raises:
            TaskLoaderError: If venv creation fails
        """
        venv_path = Path(venv_path)
        
        # Skip if venv already exists
        if (venv_path / "bin" / "python").exists():
            logger.debug(
                "task_loader.venv_exists",
                venv_path=str(venv_path),
            )
            return
        
        logger.info(
            "task_loader.creating_venv",
            venv_path=str(venv_path),
        )
        
        try:
            process = await asyncio.create_subprocess_exec(
                "uv", "venv", str(venv_path),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                raise TaskLoaderError(
                    f"Failed to create venv: {stderr.decode()}"
                )
            
            logger.info(
                "task_loader.venv_created",
                venv_path=str(venv_path),
            )
            
        except FileNotFoundError:
            raise TaskLoaderError("uv not found. Please install uv: https://docs.astral.sh/uv/")
        except Exception as e:
            raise TaskLoaderError(f"Failed to create venv: {e}")
    
    async def _install_dependencies(self, code_path: str, venv_path: str) -> None:
        """Install dependencies using uv.
        
        Always installs the nexora-tasks SDK into the task venv (when
        ``framework_path`` is set) so that the worker subprocess can
        ``import nexora_tasks.worker``.  Task-level dependencies
        (pyproject.toml / requirements.txt) are installed afterwards.
        
        Args:
            code_path: Path to the extracted code
            venv_path: Path to the virtual environment
            
        Raises:
            TaskLoaderError: If installation fails
        """
        # Resolve to absolute paths - required because subprocess may change cwd
        code_path = Path(code_path).resolve()
        venv_path = Path(venv_path).resolve()
        venv_python = str(venv_path / "bin" / "python")
        
        try:
            # ── 1. Install the nexora-tasks SDK into the task venv ──────
            # This MUST happen unconditionally (before the early-return for
            # tasks without their own dependencies) because the worker
            # subprocess needs ``nexora_tasks.worker`` to be importable.
            if self.framework_path:
                logger.info(
                    "task_loader.installing_local_framework",
                    framework_path=self.framework_path,
                )
                framework_cmd = [
                    "uv", "pip", "install", "-e", self.framework_path,
                    "--python", venv_python,
                ]
                process = await asyncio.create_subprocess_exec(
                    *framework_cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(code_path),
                )
                stdout, stderr = await process.communicate()
                
                if process.returncode != 0:
                    raise TaskLoaderError(
                        f"Failed to install local nexora-tasks: {stderr.decode()}"
                    )

            # ── 2. Install task-level dependencies ───────────────────────
            # Check for pyproject.toml or requirements.txt
            pyproject = code_path / "pyproject.toml"
            requirements = code_path / "requirements.txt"
            uv_lock = code_path / "uv.lock"
            
            if pyproject.exists():
                # Use uv pip install with pyproject.toml
                if uv_lock.exists():
                    # Use uv sync for reproducible installs
                    cmd = ["uv", "sync", "--directory", str(code_path)]
                else:
                    # Install from pyproject.toml
                    cmd = ["uv", "pip", "install", "-e", str(code_path), "--python", venv_python]
            elif requirements.exists():
                # Install from requirements.txt
                cmd = ["uv", "pip", "install", "-r", str(requirements), "--python", venv_python]
            else:
                logger.info(
                    "task_loader.no_task_dependencies",
                    code_path=str(code_path),
                )
                return
            
            logger.info(
                "task_loader.installing_dependencies",
                code_path=str(code_path),
                command=" ".join(cmd),
            )
            
            # Now install task dependencies
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(code_path),
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                raise TaskLoaderError(
                    f"Failed to install dependencies: {stderr.decode()}"
                )
            
            logger.info(
                "task_loader.dependencies_installed",
                code_path=str(code_path),
            )
            
        except FileNotFoundError:
            raise TaskLoaderError("uv not found. Please install uv: https://docs.astral.sh/uv/")
        except TaskLoaderError:
            raise
        except Exception as e:
            raise TaskLoaderError(f"Failed to install dependencies: {e}")

    async def _install_node_dependencies(self, code_path: str) -> None:
        """Install Node.js dependencies using npm.
        
        Also copies the worker-context.js SDK into the task directory
        so it can be required by node-runner.js.
        
        Args:
            code_path: Path to the extracted code
            
        Raises:
            TaskLoaderError: If npm install fails
        """
        import shutil
        
        code_path = Path(code_path).resolve()
        package_json = code_path / "package.json"
        
        if not package_json.exists():
            logger.info(
                "task_loader.node_no_package_json",
                code_path=str(code_path),
            )
            return
        
        # Check if npm is available
        npm_bin = shutil.which("npm")
        if not npm_bin:
            raise TaskLoaderError(
                "npm not found. Please install Node.js to deploy JavaScript tasks."
            )
        
        logger.info(
            "task_loader.node_installing_dependencies",
            code_path=str(code_path),
        )
        
        try:
            process = await asyncio.create_subprocess_exec(
                npm_bin, "install",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(code_path),
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                raise TaskLoaderError(
                    f"npm install failed: {stderr.decode()}"
                )
            
            logger.info(
                "task_loader.node_dependencies_installed",
                code_path=str(code_path),
            )
            
        except FileNotFoundError:
            raise TaskLoaderError("npm not found. Please install Node.js.")
        except TaskLoaderError:
            raise
        except Exception as e:
            raise TaskLoaderError(f"Failed to install Node.js dependencies: {e}")
    
    def _clear_conflicting_modules(self, code_path: str = None) -> None:
        """Clear task CODE modules to prevent namespace collisions.
        
        Only clears modules loaded from task /code/ directories — these are
        task-specific source files (e.g., task.py, lib/utils.py) that could
        collide when multiple tasks share the same module names.
        
        Modules from task /venv/ site-packages are NEVER cleared. C extensions
        like lxml cannot be safely reloaded — clearing and re-importing them
        from a different path creates incompatible C types in the same process
        (e.g., "Cannot convert lxml.etree.X to lxml.etree.X").
        
        Args:
            code_path: Optional path to the current task's code directory.
                      Modules from this path will NOT be cleared.
        """
        modules_to_remove = []
        
        for module_name in list(sys.modules.keys()):
            mod = sys.modules.get(module_name)
            if mod is None:
                continue
            mod_file = getattr(mod, '__file__', None)
            if not mod_file:
                continue
            # Only clear modules from task CODE directories, not from venv
            # site-packages. The /code/ segment is the task's source directory;
            # /venv/ contains installed packages (including C extensions).
            is_task_code = False
            if "/tasks/" in mod_file or "/task_definitions/" in mod_file:
                # Must be from a /code/ subdirectory, NOT from /venv/
                if "/code/" in mod_file and "/venv/" not in mod_file and "/site-packages/" not in mod_file:
                    is_task_code = True
            
            if not is_task_code:
                continue
            
            # Keep modules from the current task being loaded
            if code_path and mod_file.startswith(str(code_path)):
                continue
            modules_to_remove.append(module_name)
        
        for module_name in modules_to_remove:
            del sys.modules[module_name]
        
        if modules_to_remove:
            logger.debug(
                "task_loader.cleared_conflicting_modules",
                count=len(modules_to_remove),
                modules=modules_to_remove[:10],  # Log first 10 to avoid log spam
            )
    
    def _preload_c_extensions(self) -> None:
        """Pre-import C extensions from the main environment.
        
        C extensions like lxml compile types at the C level. If two copies of
        the same C extension are loaded from different paths in the same process,
        the C types become incompatible even though they have the same Python name.
        
        By pre-importing them BEFORE the venv site-packages is consulted,
        we ensure sys.modules caches the framework's version, and subsequent
        imports return the cached version rather than loading from the venv.
        """
        # Known C extensions that cause dual-loading issues
        c_extensions = [
            "lxml",
            "lxml.etree",
            "lxml.objectify",
            "lxml.html",
        ]
        
        for module_name in c_extensions:
            if module_name not in sys.modules:
                try:
                    __import__(module_name)
                except ImportError:
                    # Not available in the main environment — task's venv
                    # will provide it (no conflict since there's only one copy)
                    pass
    
    async def _load_task_function(self, code_path: str, entry_point: str) -> Callable:
        """Dynamically load the task function from code.
        
        ISOLATION: Task-specific paths are TEMPORARILY added to sys.path during
        module loading, then REMOVED afterwards. The loaded module and all its
        module-level imports survive path removal because Python caches module
        objects in sys.modules and function objects retain references to their
        module's __globals__ dict.
        
        This prevents sys.path accumulation: after deploying N tasks, sys.path
        only contains the server's own paths.
        
        Args:
            code_path: Path to the extracted code directory
            entry_point: Entry point in format 'module:function'
            
        Returns:
            The loaded task function
            
        Raises:
            TaskLoaderError: If loading fails
        """
        if ":" not in entry_point:
            raise TaskLoaderError(f"Invalid entry_point format: {entry_point}. Expected 'module:function'")
        
        module_path, func_name = entry_point.rsplit(":", 1)
        code_path = Path(code_path)
        
        # Clear potentially conflicting modules before loading to prevent
        # namespace collisions between tasks with same module names
        self._clear_conflicting_modules(code_path=str(code_path))
        
        # Derive venv path from code_path: code_path is {base}/code, venv is {base}/venv
        venv_path = code_path.parent / "venv"
        
        # Build task-specific paths to TEMPORARILY add to sys.path
        paths_to_add = []
        
        venv_site_packages = venv_path / "lib" / f"python{sys.version_info.major}.{sys.version_info.minor}" / "site-packages"
        if venv_site_packages.exists():
            paths_to_add.append(str(venv_site_packages))
        
        paths_to_add.append(str(code_path))
        
        # TEMPORARILY add paths at front of sys.path
        for p in reversed(paths_to_add):
            sys.path.insert(0, p)
        
        # Pre-import C extensions from the MAIN environment to prevent the
        # venv from loading a second copy. C extensions like lxml cannot
        # coexist with different installations in the same process.
        self._preload_c_extensions()
        
        logger.debug(
            "task_loader.paths_temporarily_added",
            paths=paths_to_add,
        )
        
        try:
            # Convert module path to file path
            module_parts = module_path.split(".")
            module_file = code_path / "/".join(module_parts[:-1] if len(module_parts) > 1 else []) / f"{module_parts[-1]}.py"
            
            if not module_file.exists():
                # Try as a package
                module_file = code_path / "/".join(module_parts) / "__init__.py"
            
            if not module_file.exists():
                # Try direct path
                module_file = code_path / f"{module_path.replace('.', '/')}.py"
            
            if not module_file.exists():
                raise TaskLoaderError(f"Module file not found: {module_path}")
            
            # Load module (triggers all module-level imports)
            spec = importlib.util.spec_from_file_location(module_path, module_file)
            if spec is None or spec.loader is None:
                raise TaskLoaderError(f"Could not load module spec: {module_path}")
            
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_path] = module
            spec.loader.exec_module(module)
            
            # Get function
            if not hasattr(module, func_name):
                raise TaskLoaderError(f"Function '{func_name}' not found in module '{module_path}'")
            
            task_function = getattr(module, func_name)
            
            if not callable(task_function):
                raise TaskLoaderError(f"'{func_name}' is not callable")
            
            # Validate signature
            import inspect
            sig = inspect.signature(task_function)
            if len(sig.parameters) < 1:
                raise TaskLoaderError(f"Task function must accept at least one parameter (context)")
            
            logger.info(
                "task_loader.function_loaded",
                entry_point=entry_point,
                module_path=str(module_file),
            )
            
            return task_function
            
        except TaskLoaderError:
            raise
        except Exception as e:
            logger.error(
                "task_loader.function_load_failed",
                code_path=str(code_path),
                entry_point=entry_point,
                error=str(e),
                exc_info=True,
            )
            raise TaskLoaderError(f"Failed to load task function: {e}")
        finally:
            # REMOVE task paths from sys.path — module is already loaded and cached
            # in sys.modules, so imports will continue to work.
            for p in paths_to_add:
                try:
                    sys.path.remove(p)
                except ValueError:
                    pass
            
            logger.debug(
                "task_loader.paths_removed",
                paths=paths_to_add,
            )
    
    async def unload_task(self, task_def: TaskDefinition) -> None:
        """Unload a task and cleanup.
        
        Removes all modules loaded from the task's code directory from sys.modules
        to ensure fresh imports on redeployment.
        
        Args:
            task_def: TaskDefinition to unload
        """
        code_path = task_def.code_path
        
        # Find and remove all modules loaded from this task's code directory
        modules_to_remove = []
        for module_name, module in sys.modules.items():
            if module is None:
                continue
            module_file = getattr(module, '__file__', None)
            if module_file and code_path and module_file.startswith(code_path):
                modules_to_remove.append(module_name)
        
        for module_name in modules_to_remove:
            del sys.modules[module_name]
        
        logger.info(
            "task_loader.unloaded",
            task_id=task_def.task_id,
            version=task_def.version,
            modules_removed=len(modules_to_remove),
        )
    
    async def verify_dependencies(self, task_def: TaskDefinition) -> Tuple[bool, Optional[str]]:
        """Verify that task dependencies are properly installed.
        
        Args:
            task_def: TaskDefinition to verify
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        venv_python = Path(task_def.venv_path) / "bin" / "python"
        
        if not venv_python.exists():
            return False, "Virtual environment not found"
        
        # Try importing the task module
        try:
            process = await asyncio.create_subprocess_exec(
                str(venv_python), "-c",
                f"import {task_def.entry_point.rsplit(':', 1)[0]}",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                return False, f"Import failed: {stderr.decode()}"
            
            return True, None
            
        except Exception as e:
            return False, f"Verification failed: {e}"

