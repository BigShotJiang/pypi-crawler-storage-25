"""Router registration for the Nexora Tasks server (M-11).

Extracted from ``server.py`` to keep ``create_server`` small and to give
each functional area an explicit, ordered registration site. Imports are
performed lazily inside the function so module import order matches the
historical behaviour of the inline ``app.include_router`` calls.
"""

from __future__ import annotations

from fastapi import FastAPI


def register_routers(app: FastAPI) -> None:
    """Register every API router on the given FastAPI ``app`` (M-11).

    Order matches the original ``create_server`` registration sequence
    so route precedence (e.g. ``/threads/{id}/artifacts`` before
    ``/threads/{id}``) is preserved.
    """
    # Threads + artifacts must register before any catch-all route.
    from nexora_tasks_server.api import artifacts, threads

    app.include_router(threads.router)
    app.include_router(artifacts.router)

    # Public metadata for service discovery.
    from nexora_tasks_server.api import metadata

    app.include_router(metadata.router)

    # File storage (downloads + uploads).
    from nexora_tasks_server.api import files

    app.include_router(files.router)
    app.include_router(files.uploads_router)

    # Schedule management + run history.
    from nexora_tasks_server.api import runs, schedules

    app.include_router(schedules.router)
    app.include_router(runs.router)

    # Webhook configuration + delivery tracking.
    from nexora_tasks_server.api import webhooks

    app.include_router(webhooks.router)

    # Admin task management.
    from nexora_tasks_server.api import admin_tasks

    app.include_router(admin_tasks.router)
    app.include_router(admin_tasks.deployments_router)

    # Admin credentials + task configuration.
    from nexora_tasks_server.api import credentials as credentials_api

    app.include_router(credentials_api.router)

    # Admin settings.
    from nexora_tasks_server.api import settings as settings_api

    app.include_router(settings_api.router)

    # Admin environments + promotions.
    from nexora_tasks_server.api import admin_environments

    app.include_router(admin_environments.router)
    app.include_router(admin_environments.promotions_router)

    # Observability (thread logs, events, websocket).
    from nexora_tasks_server.api import observability

    app.include_router(observability.router)

    # Admin metrics + admin health.
    from nexora_tasks_server.api import admin_health, admin_metrics

    app.include_router(admin_metrics.router)
    app.include_router(admin_health.router)

    # UI router last (public, may include catch-all static routes).
    from nexora_tasks_server.ui import router as ui_router

    app.include_router(ui_router)
