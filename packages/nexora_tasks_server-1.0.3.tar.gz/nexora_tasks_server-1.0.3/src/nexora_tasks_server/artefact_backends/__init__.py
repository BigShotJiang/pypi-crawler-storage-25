"""Artefact backend strategy package.

Pluggable backends behind ``ArtifactService``. The default ``LocalArtefactBackend``
wraps the existing ``Database`` + ``FileStorage`` plumbing. ``PlatformArtefactBackend``
(added in Phase 2) talks to the standalone ``artefact-platform`` service via its
Python SDK.

Selection happens through :func:`factory.resolve_backend` from environment +
per-app metadata.
"""

from nexora_tasks_server.artefact_backends.protocol import ArtefactBackend
from nexora_tasks_server.artefact_backends.local import LocalArtefactBackend
from nexora_tasks_server.artefact_backends.factory import resolve_backend

__all__ = ["ArtefactBackend", "LocalArtefactBackend", "resolve_backend"]
