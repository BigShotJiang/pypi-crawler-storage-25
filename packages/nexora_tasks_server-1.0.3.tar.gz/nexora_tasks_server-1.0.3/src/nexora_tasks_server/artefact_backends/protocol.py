"""ArtefactBackend protocol.

Defines the artifact-CRUD surface that ``ArtifactService`` delegates to.
Backends absorb persistence + (in later phases) blob bytes + scope lifecycle.

Phase 1 covers the artifact-data plane only; file bytes still flow through
``FileStorage`` directly. Phase 3 widens this protocol to include file ops
and thread/scope lifecycle hooks.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Protocol, runtime_checkable

from nexora_tasks.models.artifact import Artifact


@runtime_checkable
class ArtefactBackend(Protocol):
    """Async artifact persistence surface.

    Implementations:
    - ``LocalArtefactBackend`` — wraps ``Database`` (FileDatabase or ES).
    - ``PlatformArtefactBackend`` — wraps ``artefact_platform.AsyncClient`` (Phase 2).
    """

    async def create_artifact(self, artifact: Artifact) -> None:
        """Persist a new artifact. Mutates ``artifact`` in place if backend assigns ids."""
        ...

    async def get_artifact(self, artifact_id: str) -> Optional[Artifact]:
        """Return an artifact by id, or ``None`` if missing."""
        ...

    async def get_thread_artifacts(self, thread_id: str) -> List[Artifact]:
        """Return all artifacts attached to a thread (any direction, any state)."""
        ...

    async def query_artifacts(self, filters: Dict[str, Any]) -> List[Artifact]:
        """Cross-thread query. Filter shape mirrors ``Database.query_artifacts``."""
        ...

    async def delete_artifact(self, artifact_id: str) -> None:
        """Hard-delete an artifact record. Raises if missing."""
        ...

    async def get_download_url(
        self, artifact: Artifact, expires_in: int = 900
    ) -> Optional[str]:
        """Return a backend-native presigned download URL, or ``None`` to fall back.

        ``LocalArtefactBackend`` returns ``None`` so ``ArtifactService`` falls
        back to the existing ``FileStorage.get_signed_url`` path.
        ``PlatformArtefactBackend`` returns the platform-issued ``presigned_url``
        so blobs hosted on the platform can be downloaded directly.
        """
        ...
