"""Thread → platform scope lifecycle hooks.

TF threads map 1:1 to platform scopes (``kind="thread"``). Local backend ops
are no-ops; only platform backend executes API calls.

Hook points (wired in Phase 3):
- thread create  → ``on_thread_create`` (creates scope)
- terminal state → ``on_thread_close``  (closes scope; artefacts become read-only)
- thread delete  → ``on_thread_delete`` (deletes scope; soft-deletes artefacts)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from nexora_tasks_server.artefact_backends.mapping import thread_id_to_scope_id

if TYPE_CHECKING:
    from nexora_tasks_server.artefact_backends.protocol import ArtefactBackend


async def on_thread_create(backend: "ArtefactBackend", thread_id: str) -> None:
    client = _platform_client(backend)
    if client is None:
        return
    scope_id = thread_id_to_scope_id(thread_id)
    try:
        await client.scopes.create(
            kind="thread",
            owner=scope_id,
            idempotency_key=f"tf-create-{scope_id}",
        )
    except Exception as exc:  # idempotent — scope may already exist
        if not _is_conflict(exc):
            raise


async def on_thread_close(backend: "ArtefactBackend", thread_id: str) -> None:
    client = _platform_client(backend)
    if client is None:
        return
    scope_id = thread_id_to_scope_id(thread_id)
    try:
        await client.scopes.close(scope_id, idempotency_key=f"tf-close-{scope_id}")
    except Exception as exc:
        if not _is_already_closed(exc) and not _is_not_found(exc):
            raise


async def on_thread_delete(backend: "ArtefactBackend", thread_id: str) -> None:
    client = _platform_client(backend)
    if client is None:
        return
    scope_id = thread_id_to_scope_id(thread_id)
    try:
        await client.scopes.delete(scope_id)
    except Exception as exc:
        if not _is_not_found(exc):
            raise


def _platform_client(backend: "ArtefactBackend"):
    """Return the platform AsyncClient if backend is platform-backed, else None."""
    return getattr(backend, "client", None) if _is_platform_backend(backend) else None


def _is_platform_backend(backend: object) -> bool:
    return type(backend).__name__ == "PlatformArtefactBackend"


def _is_conflict(exc: BaseException) -> bool:
    return getattr(exc, "http_status", None) == 409


def _is_already_closed(exc: BaseException) -> bool:
    return type(exc).__name__ in {"ScopeClosed", "ScopeDeleted"}


def _is_not_found(exc: BaseException) -> bool:
    return type(exc).__name__ in {"ScopeNotFound"} or getattr(exc, "http_status", None) == 404
