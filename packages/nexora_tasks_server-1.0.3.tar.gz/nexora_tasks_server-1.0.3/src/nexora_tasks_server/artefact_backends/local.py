"""LocalArtefactBackend — wraps the in-process Database for artifact CRUD.

This is a thin pass-through. Behavior parity with pre-adapter code is the only
contract here; all logic stays in ``ArtifactService``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from nexora_tasks.models.artifact import Artifact

if TYPE_CHECKING:
    from nexora_tasks_server.interfaces.database import Database


class LocalArtefactBackend:
    """Backend that persists artifacts via the local ``Database`` interface."""

    def __init__(self, database: "Database") -> None:
        self._database = database

    @property
    def database(self) -> "Database":
        """Underlying database — exposed for migrations / smoke tests only."""
        return self._database

    async def create_artifact(self, artifact: Artifact) -> None:
        await self._database.create_artifact(artifact)

    async def get_artifact(self, artifact_id: str) -> Optional[Artifact]:
        return await self._database.get_artifact(artifact_id)

    async def get_thread_artifacts(self, thread_id: str) -> List[Artifact]:
        return await self._database.get_thread_artifacts(thread_id)

    async def query_artifacts(self, filters: Dict[str, Any]) -> List[Artifact]:
        return await self._database.query_artifacts(filters)

    async def delete_artifact(self, artifact_id: str) -> None:
        await self._database.delete_artifact(artifact_id)

    async def get_download_url(
        self, artifact: Artifact, expires_in: int = 900
    ) -> Optional[str]:
        # Local backend defers to ArtifactService.file_storage.get_signed_url.
        return None
