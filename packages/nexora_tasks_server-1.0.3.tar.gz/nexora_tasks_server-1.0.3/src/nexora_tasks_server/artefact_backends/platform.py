"""PlatformArtefactBackend — wraps ``artefact_platform.AsyncClient``.

Implements the ``ArtefactBackend`` Protocol against a remote artefact-platform
deployment. Two-phase blob upload is delegated to the SDK's
``upload_blob`` helper. Scope ops live in ``scope_lifecycle``.

Phase 5 surface: structured + blob artefact CRUD with real two-phase upload
of file/binary/log/table kinds via ``upload_blob``. Bytes are sourced from
the supplied ``FileStorage`` (TF's local blob layer) and pushed to platform;
the platform-issued artefact id replaces ``artifact.file_ref`` so subsequent
downloads route via the platform's ``presigned_url``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from nexora_tasks.models.artifact import Artifact

from nexora_tasks_server.artefact_backends.mapping import (
    LABEL_TF_ARTIFACT_ID,
    artifact_to_create_kwargs,
    artifact_to_upload_kwargs,
    platform_to_artifact,
    thread_id_to_scope_id,
)

if TYPE_CHECKING:
    from artefact_platform import AsyncClient

    from nexora_tasks_server.interfaces.storage import FileStorage


_FILE_KINDS = {"file", "binary", "log", "table"}


class PlatformArtefactBackend:
    """Backend that persists artefacts via remote artefact-platform API.

    The TF Artifact id is round-tripped through ``labels.tf_artifact_id`` so
    callers that hold the original id can still resolve via
    :meth:`get_artifact`. A reverse-lookup index keeps id↔platform_id.

    For blob-backed kinds the constructor's ``file_storage`` provides the
    plaintext bytes that the platform's two-phase upload encrypts and stores.
    """

    def __init__(
        self,
        client: "AsyncClient",
        file_storage: Optional["FileStorage"] = None,
    ) -> None:
        self._client = client
        self._file_storage = file_storage
        # Soft cache: TF id → platform id. Populated on create + on read paths.
        # Survives only for the lifetime of this backend instance.
        self._id_index: Dict[str, str] = {}

    @property
    def client(self) -> "AsyncClient":
        return self._client

    # ------------------------------------------------------------------
    # ArtefactBackend Protocol
    # ------------------------------------------------------------------

    async def create_artifact(self, artifact: Artifact) -> None:
        is_blob = artifact.kind in _FILE_KINDS or bool(artifact.file_ref)
        if is_blob:
            platform_art = await self._upload_blob_artifact(artifact)
        else:
            kwargs = artifact_to_create_kwargs(artifact)
            platform_art = await self._client.artefacts.create(**kwargs)

        if artifact.id:
            self._id_index[artifact.id] = platform_art.id

        # Mirror platform-derived blob metadata back onto the in-memory artifact
        # so callers see the post-upload sha256 / size / platform-hosted ref.
        if is_blob and platform_art.blob_ref:
            artifact.size = (
                platform_art.blob_ref.get("size_bytes")
                or platform_art.blob_ref.get("size")
                or artifact.size
            )
            artifact.sha256 = platform_art.blob_ref.get("sha256") or artifact.sha256
            # Replace the local file_ref with the platform artefact id so future
            # lookups round-trip through the SDK; the original local ref is
            # preserved in labels via mapping.LABEL_TF_FILE_REF.
            artifact.file_ref = platform_art.id

    async def _upload_blob_artifact(self, artifact: Artifact) -> Any:
        if not self._file_storage:
            raise RuntimeError(
                "PlatformArtefactBackend requires file_storage for blob-kind artefacts"
            )
        data = await self._file_storage.download(artifact.file_ref)
        kwargs = artifact_to_upload_kwargs(artifact)
        return await self._client.artefacts.upload_blob(data, **kwargs)

    async def get_artifact(self, artifact_id: str) -> Optional[Artifact]:
        platform_id = self._id_index.get(artifact_id, artifact_id)
        try:
            platform_art = await self._client.artefacts.get(platform_id)
        except Exception as exc:  # SDK raises ArtefactNotFound (404)
            if _is_not_found(exc):
                return None
            raise
        tf_art = platform_to_artifact(platform_art)
        if tf_art.id:
            self._id_index[tf_art.id] = platform_art.id
        return tf_art

    async def get_thread_artifacts(self, thread_id: str) -> List[Artifact]:
        scope = thread_id_to_scope_id(thread_id)
        results: List[Artifact] = []
        cursor: Optional[str] = None
        while True:
            page = await self._client.artefacts.list(scope_id=scope, cursor=cursor, limit=100)
            for p in page.items:
                tf_art = platform_to_artifact(p)
                if tf_art.id:
                    self._id_index[tf_art.id] = p.id
                results.append(tf_art)
            cursor = page.next_cursor
            if not cursor:
                break
        return results

    async def query_artifacts(self, filters: Dict[str, Any]) -> List[Artifact]:
        # Phase 2: only thread_id filter pushes down. Other filters applied client-side
        # after fetch — same surface as the local backend's query semantics.
        thread_id = filters.get("thread_id")
        if thread_id:
            results = await self.get_thread_artifacts(thread_id)
        else:
            page = await self._client.artefacts.list(limit=100)
            results = [platform_to_artifact(p) for p in page.items]

        return [a for a in results if _matches_filters(a, filters)]

    async def delete_artifact(self, artifact_id: str) -> None:
        platform_id = self._id_index.get(artifact_id, artifact_id)
        await self._client.artefacts.delete(platform_id, hard=True)
        self._id_index.pop(artifact_id, None)

    async def get_download_url(
        self, artifact: Artifact, expires_in: int = 900
    ) -> Optional[str]:
        """Return the platform-issued ``presigned_url`` for blob-backed artefacts.

        ``expires_in`` is informational here — the platform controls TTL via
        its own ``presigned_url_expires_at`` field. Returns ``None`` when the
        artefact has no blob (caller falls back to local FileStorage).
        """
        platform_id = self._id_index.get(artifact.id, artifact.file_ref or artifact.id)
        try:
            platform_art = await self._client.artefacts.get(platform_id)
        except Exception as exc:
            if _is_not_found(exc):
                return None
            raise
        return platform_art.presigned_url


def _is_not_found(exc: BaseException) -> bool:
    name = type(exc).__name__
    return name in {"ArtefactNotFound", "ScopeNotFound"} or getattr(exc, "http_status", None) == 404


def _matches_filters(art: Artifact, filters: Dict[str, Any]) -> bool:
    for key, want in filters.items():
        if key == "thread_id":
            if art.thread_id != want:
                return False
        elif key == "kind":
            if art.kind != want:
                return False
        elif key == "ref":
            if art.ref != want:
                return False
        elif key == "archived":
            if art.archived != want:
                return False
        else:
            actual = art.labels.get(key) if art.labels else None
            if actual != want:
                return False
    return True
