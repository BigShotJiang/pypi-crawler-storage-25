"""Backend resolution factory.

Reads ``ARTEFACT_BACKEND`` env (default ``local``) and per-app override
(``app.artefact_backend``). When ``platform``, constructs an
``AsyncClient`` from ``ARTEFACT_PLATFORM_URL`` + tenant key (per-app
``app.artefact_platform_tenant_key`` falling back to
``ARTEFACT_PLATFORM_DEFAULT_TENANT_KEY``).

Platform clients are cached per ``(api_url, key_hash)`` to share connections
across requests for the same tenant.
"""

from __future__ import annotations

import hashlib
import os
from typing import TYPE_CHECKING, Dict, Optional, Tuple

from nexora_tasks_server.artefact_backends.local import LocalArtefactBackend
from nexora_tasks_server.artefact_backends.protocol import ArtefactBackend

if TYPE_CHECKING:
    from artefact_platform import AsyncClient

    from nexora_tasks_server.interfaces.database import Database
    from nexora_tasks_server.interfaces.storage import FileStorage
    from nexora_tasks_server.repositories.file_db import App


ENV_BACKEND = "ARTEFACT_BACKEND"
ENV_PLATFORM_URL = "ARTEFACT_PLATFORM_URL"
ENV_PLATFORM_DEFAULT_KEY = "ARTEFACT_PLATFORM_DEFAULT_TENANT_KEY"

_BACKEND_LOCAL = "local"
_BACKEND_PLATFORM = "platform"


# (api_url, sha256(api_key)) → AsyncClient — connection pool reuse
_client_cache: Dict[Tuple[str, str], "AsyncClient"] = {}


def resolve_backend(
    database: "Database",
    file_storage: Optional["FileStorage"] = None,
    app: Optional["App"] = None,
) -> ArtefactBackend:
    """Return the artefact backend for the given app context.

    Resolution order: per-app override > env > default (local).

    ``file_storage`` is required only for the platform backend with file-kind
    artefacts — it is the source of bytes for two-phase ``upload_blob`` calls.
    """
    mode = _resolve_mode(app)
    if mode == _BACKEND_PLATFORM:
        return _build_platform_backend(app, file_storage)
    return LocalArtefactBackend(database)


def _resolve_mode(app: Optional["App"]) -> str:
    if app is not None:
        per_app = getattr(app, "artefact_backend", None)
        if per_app:
            return per_app.lower()
    return os.getenv(ENV_BACKEND, _BACKEND_LOCAL).lower()


def _build_platform_backend(
    app: Optional["App"],
    file_storage: Optional["FileStorage"],
) -> ArtefactBackend:
    from nexora_tasks_server.artefact_backends.platform import PlatformArtefactBackend

    api_url = os.getenv(ENV_PLATFORM_URL)
    if not api_url:
        raise RuntimeError(
            f"{ENV_PLATFORM_URL} must be set when ARTEFACT_BACKEND=platform"
        )
    api_key = _resolve_tenant_key(app)
    if not api_key:
        raise RuntimeError(
            "No tenant key resolved for platform backend "
            f"(set {ENV_PLATFORM_DEFAULT_KEY} or app.artefact_platform_tenant_key)"
        )
    client = _get_or_create_client(api_url, api_key)
    return PlatformArtefactBackend(client, file_storage=file_storage)


def _resolve_tenant_key(app: Optional["App"]) -> Optional[str]:
    if app is not None:
        per_app = getattr(app, "artefact_platform_tenant_key", None)
        if per_app:
            return _unwrap_secret(per_app)
    return os.getenv(ENV_PLATFORM_DEFAULT_KEY)


def _unwrap_secret(value: object) -> str:
    """Support pydantic SecretStr or plain str without importing pydantic here."""
    getter = getattr(value, "get_secret_value", None)
    if callable(getter):
        return getter()
    return str(value)


def _get_or_create_client(api_url: str, api_key: str) -> "AsyncClient":
    from artefact_platform import AsyncClient

    key_hash = hashlib.sha256(api_key.encode("utf-8")).hexdigest()[:16]
    cache_key = (api_url, key_hash)
    if cache_key not in _client_cache:
        _client_cache[cache_key] = AsyncClient(api_url=api_url, api_key=api_key)
    return _client_cache[cache_key]


def _reset_client_cache_for_tests() -> None:
    """Test helper — clears the per-tenant client cache."""
    _client_cache.clear()
