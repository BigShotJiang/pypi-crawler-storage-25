"""Bidirectional mapping between TF ``Artifact`` and platform ``Artefact``.

TF kinds (15) → platform types (1:1 for most). Bundle is special: maps to
``storage_kind="bundle"`` not a type. ``rich_text`` flattens to ``text`` with
``labels.format="rich"``.

TF thread_id ↔ platform scope_id: ``scope_id = f"thr_{thread_id}"``.
TF id ↔ platform id: separate (server-generated each side); we round-trip the
TF id through ``labels.tf_artifact_id`` so reverse lookups can recover it.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, Optional

from nexora_tasks.models.artifact import Artifact

if TYPE_CHECKING:
    from artefact_platform.models.artefact import Artefact as PlatformArtefact


# TF kind → platform type. Excludes ``bundle`` (special-cased: storage_kind).
KIND_TO_TYPE: Dict[str, str] = {
    "text": "text",
    "rich_text": "text",
    "url": "url",
    "file": "file",
    "binary": "binary",
    "json": "json",
    "log": "log",
    "metrics": "metrics",
    "table": "table",
    "http_request": "http_request",
    "http_response": "http_response",
    "geo": "geo",
    "patch": "patch",
    "provenance": "provenance",
}

# Reverse table — platform type → TF kind. ``rich_text`` recovered via labels.
TYPE_TO_KIND: Dict[str, str] = {v: k for k, v in KIND_TO_TYPE.items() if k != "rich_text"}

LABEL_FORMAT = "format"
LABEL_DIRECTION = "direction"
LABEL_TF_ARTIFACT_ID = "tf_artifact_id"
LABEL_TF_KIND = "tf_kind"
LABEL_APP_ID = "app_id"
LABEL_TASK_ID = "task_id"
LABEL_TASK_VERSION = "task_version"
LABEL_ARCHIVED = "archived"
LABEL_ARCHIVED_AT = "archived_at"
LABEL_MEDIA_TYPE = "media_type"
LABEL_EXPLAIN = "explain"
LABEL_TF_FILE_REF = "tf_file_ref"


def thread_id_to_scope_id(thread_id: str) -> str:
    """``thr_<id>`` — TF thread → platform scope id."""
    return f"thr_{thread_id}" if not thread_id.startswith("thr_") else thread_id


def scope_id_to_thread_id(scope_id: str) -> str:
    """Reverse of :func:`thread_id_to_scope_id`."""
    return scope_id[4:] if scope_id.startswith("thr_") else scope_id


def kind_to_type(kind: str) -> str:
    """Map TF kind → platform type. Raises on unknown kind (bundle handled upstream)."""
    if kind == "bundle":
        # Bundle is platform storage_kind, not a type. Caller must route to bundles API.
        raise ValueError("kind='bundle' is handled via platform storage_kind, not type mapping")
    if kind not in KIND_TO_TYPE:
        raise ValueError(f"unknown TF artifact kind: {kind!r}")
    return KIND_TO_TYPE[kind]


def type_to_kind(type_: str, labels: Optional[Dict[str, str]] = None) -> str:
    """Map platform type → TF kind. Uses ``labels.format`` to recover ``rich_text``."""
    if type_ == "text" and labels and labels.get(LABEL_FORMAT) == "rich":
        return "rich_text"
    if type_ in TYPE_TO_KIND:
        return TYPE_TO_KIND[type_]
    if type_ == "text":
        return "text"
    raise ValueError(f"unknown platform artefact type: {type_!r}")


def _build_labels(art: Artifact) -> Dict[str, str]:
    """Stringify TF labels + structural fields that have no platform column."""
    labels: Dict[str, str] = {}
    for k, v in (art.labels or {}).items():
        labels[str(k)] = str(v) if not isinstance(v, str) else v
    if art.kind == "rich_text":
        labels[LABEL_FORMAT] = "rich"
    if art.direction:
        labels[LABEL_DIRECTION] = art.direction
    if art.id:
        labels[LABEL_TF_ARTIFACT_ID] = art.id
    labels[LABEL_TF_KIND] = art.kind
    if art.task_id:
        labels[LABEL_TASK_ID] = art.task_id
    if art.task_version:
        labels[LABEL_TASK_VERSION] = art.task_version
    if art.media_type:
        labels[LABEL_MEDIA_TYPE] = art.media_type
    if art.explain:
        labels[LABEL_EXPLAIN] = art.explain
    if art.archived:
        labels[LABEL_ARCHIVED] = "true"
        if art.archived_at:
            labels[LABEL_ARCHIVED_AT] = art.archived_at.isoformat()
    if art.file_ref:
        labels[LABEL_TF_FILE_REF] = art.file_ref
    return labels


def _build_data(art: Artifact) -> Dict[str, Any]:
    """Flatten TF inline payload (text/value/url) into platform structured ``data``."""
    data: Dict[str, Any] = {}
    if art.text is not None:
        data["text"] = art.text
    if art.value is not None:
        data["value"] = art.value
    if art.url is not None:
        data["url"] = art.url
    return data


def artifact_to_create_kwargs(art: Artifact) -> Dict[str, Any]:
    """Build kwargs for ``AsyncArtefactsResource.create`` (structured artefacts only).

    For blob-backed kinds (``file``, ``binary``, ``log``, ``table`` with file_ref),
    use :func:`artifact_to_upload_kwargs` instead.
    """
    if not art.thread_id:
        raise ValueError("Artifact.thread_id required for platform create")
    return {
        "type": kind_to_type(art.kind),
        "scope_id": thread_id_to_scope_id(art.thread_id),
        "ref": art.ref,
        "data": _build_data(art) or None,
        "labels": _build_labels(art),
    }


def artifact_to_upload_kwargs(art: Artifact) -> Dict[str, Any]:
    """Build kwargs for ``AsyncArtefactsResource.upload_blob`` (file-backed kinds)."""
    if not art.thread_id:
        raise ValueError("Artifact.thread_id required for platform upload")
    return {
        "type": kind_to_type(art.kind),
        "scope_id": thread_id_to_scope_id(art.thread_id),
        "ref": art.ref,
        "content_type": art.media_type,
        "labels": _build_labels(art),
    }


def platform_to_artifact(p: "PlatformArtefact") -> Artifact:
    """Map platform Artefact → TF Artifact for read paths."""
    labels = dict(p.labels or {})
    kind = type_to_kind(p.type, labels)

    tf_id = labels.pop(LABEL_TF_ARTIFACT_ID, p.id)
    direction = labels.pop(LABEL_DIRECTION, None)
    media_type = labels.pop(LABEL_MEDIA_TYPE, None)
    explain = labels.pop(LABEL_EXPLAIN, None)
    task_id = labels.pop(LABEL_TASK_ID, None)
    task_version = labels.pop(LABEL_TASK_VERSION, None)
    archived_str = labels.pop(LABEL_ARCHIVED, None)
    archived_at_str = labels.pop(LABEL_ARCHIVED_AT, None)
    labels.pop(LABEL_TF_KIND, None)
    labels.pop(LABEL_FORMAT, None)

    archived = (archived_str == "true") or bool(p.archived)
    archived_at: Optional[datetime] = None
    if archived_at_str:
        try:
            archived_at = datetime.fromisoformat(archived_at_str)
        except ValueError:
            archived_at = None
    elif p.archived_at:
        archived_at = p.archived_at

    data = p.data or {}
    text = data.get("text") if kind in ("text", "rich_text") else None
    value = data.get("value") if "value" in data else None
    url = data.get("url") if "url" in data else None

    file_ref: Optional[str] = labels.pop(LABEL_TF_FILE_REF, None)
    size: Optional[int] = None
    sha256: Optional[str] = None
    if p.blob_ref:
        size = p.blob_ref.get("size_bytes") or p.blob_ref.get("size")
        sha256 = p.blob_ref.get("sha256")
        if not file_ref:
            file_ref = p.blob_ref.get("file_ref") or p.id

    created_at = p.created_at if isinstance(p.created_at, datetime) else datetime.now(timezone.utc)

    return Artifact(
        id=tf_id,
        thread_id=scope_id_to_thread_id(p.scope_id),
        kind=kind,
        media_type=media_type,
        ref=p.ref,
        explain=explain,
        size=size,
        sha256=sha256,
        file_ref=file_ref,
        url=url,
        value=value,
        text=text,
        labels=labels,
        created_at=created_at,
        archived=archived,
        archived_at=archived_at,
        task_id=task_id,
        task_version=task_version,
        direction=direction,
    )
