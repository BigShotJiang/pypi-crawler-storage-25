"""Application-level middleware registration (M-11, M-15, M-17).

Extracted from ``server.py`` so ``create_server`` stays small. Registers:

  1. Request tracking — request_id + api_request_duration histogram.
  2. Rate limiting    — slowapi, per-API-key with IP fallback (M-15).
  3. CORS             — env-driven origins, never wildcard (M-17).
  4. Tracing init     — Elastic APM (no-op if not configured).

``register_middleware`` is the single composition point so adding a
new layer is a one-line change.
"""

from __future__ import annotations

import os
from typing import Any, Iterable, List, Optional

from fastapi import FastAPI, Request


# ──────────────────────────────────────────────────────────────────────
# Request tracing + duration (preserved verbatim from original server.py)
# ──────────────────────────────────────────────────────────────────────


def register_request_tracking(app: FastAPI) -> None:
    """Attach the request-id + api_request_duration middleware.

    Behaviour matches the original ``server.py`` middleware byte-for-byte:

      - Every request gets an ``X-Request-ID`` (incoming or generated).
      - structlog contextvars are bound for the request lifetime.
      - ``/health`` and ``/ui/*`` skip the duration histogram.
      - The histogram label uses the matched route template
        (e.g. ``/webhooks/{webhook_id}``) — NOT the expanded URL —
        because per-resource paths previously exploded Prometheus
        cardinality and stalled the event loop on heavy delete traffic.
    """
    import asyncio
    import time
    import uuid as _uuid

    import structlog

    @app.middleware("http")
    async def track_api_request_duration(request: Request, call_next):
        request_id = request.headers.get("X-Request-ID") or str(_uuid.uuid4())
        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(request_id=request_id)

        if request.url.path in ["/health"] or request.url.path.startswith("/ui"):
            response = await call_next(request)
            response.headers["X-Request-ID"] = request_id
            return response

        start_time = time.time()
        try:
            response = await call_next(request)
        except asyncio.CancelledError:
            raise
        duration_seconds = time.time() - start_time

        from nexora_tasks_server.observability.metrics import api_request_duration

        route = request.scope.get("route")
        endpoint_label = getattr(route, "path", None) or str(request.url.path)
        status_code = str(response.status_code)
        api_request_duration.record(
            duration_seconds,
            {
                "http.method": request.method,
                "http.route": endpoint_label,
                "http.status_code": status_code,
            },
        )
        response.headers["X-Request-ID"] = request_id
        return response


# ──────────────────────────────────────────────────────────────────────
# CORS (M-17)
# ──────────────────────────────────────────────────────────────────────


def _parse_csv_env(name: str, default: Iterable[str] = ()) -> List[str]:
    """Read a comma-separated env var and split into a clean list."""
    raw = os.environ.get(name, "")
    items = [item.strip() for item in raw.split(",") if item.strip()]
    return items or list(default)


def get_cors_origins() -> List[str]:
    """Return the configured CORS allow-list (M-17).

    Sourced from the ``CORS_ORIGINS`` env var (comma-separated). Falls
    back to a safe localhost-only allow-list for development. Wildcard
    (``*``) is intentionally NOT a default — operators must opt in
    explicitly via env if they need it (and we still discourage it).
    """
    return _parse_csv_env(
        "CORS_ORIGINS",
        default=("http://localhost:3000", "http://127.0.0.1:3000"),
    )


def register_cors(app: FastAPI, origins: Optional[List[str]] = None) -> None:
    """Attach ``CORSMiddleware`` with env-driven origins (M-17).

    `allow_credentials=True` is required for the UI to send the
    `X-API-Key` header; this is incompatible with `allow_origins=["*"]`
    in any modern browser, which is the second reason we never default
    to wildcard.
    """
    from fastapi.middleware.cors import CORSMiddleware

    allow_origins = origins if origins is not None else get_cors_origins()
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allow_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
        allow_headers=[
            "Authorization",
            "Content-Type",
            "X-API-Key",
            "X-App-Id",
            "X-User-Id",
            "X-Request-ID",
            "X-Environment",
        ],
    )


# ──────────────────────────────────────────────────────────────────────
# Rate limiting (M-15)
# ──────────────────────────────────────────────────────────────────────


def get_default_rate_limit() -> str:
    """Default rate limit applied to every endpoint (M-15).

    Sourced from ``RATE_LIMIT_DEFAULT`` env var. Defaults to 100/minute
    per API key. Operators can tighten or loosen without a code change.
    """
    return os.environ.get("RATE_LIMIT_DEFAULT", "100/minute")


def get_admin_rate_limit() -> str:
    """Stricter limit reserved for admin reveal/credential routes (M-15).

    Not yet wired by default — endpoints that want it should apply
    ``@limiter.limit(get_admin_rate_limit())`` explicitly. The brief
    calls out admin reveal at 10/minute as the canonical example.
    """
    return os.environ.get("RATE_LIMIT_ADMIN", "10/minute")


def _api_key_or_ip(request: Request) -> str:
    """Identify a caller by ``X-API-Key`` first, falling back to IP.

    Per-key buckets prevent a single noisy tenant from starving a
    shared NAT egress IP, while the IP fallback ensures unauthenticated
    probes are still bounded.
    """
    api_key = request.headers.get("X-API-Key")
    if api_key:
        return f"key:{api_key}"
    from slowapi.util import get_remote_address

    return f"ip:{get_remote_address(request)}"


def _rate_limit_disabled() -> bool:
    """Allow operators / tests to disable the limiter via env."""
    return os.environ.get("RATE_LIMIT_DISABLED", "").lower() in (
        "1", "true", "yes", "on",
    )


def register_rate_limit(app: FastAPI) -> None:
    """Attach a slowapi rate limiter and 429 handler (M-15).

    No-op when ``RATE_LIMIT_DISABLED=1`` (used by integration tests
    that intentionally burst the API). Also no-op if ``slowapi`` is
    not installed — the server still boots in trimmed test installs.
    """
    if _rate_limit_disabled():
        return

    try:
        from slowapi import Limiter
        from slowapi.errors import RateLimitExceeded
        from slowapi.middleware import SlowAPIMiddleware
    except ImportError:
        from nexora_tasks.logging import logger

        logger.warning("server.middleware.slowapi_not_installed")
        return

    limiter = Limiter(
        key_func=_api_key_or_ip,
        default_limits=[get_default_rate_limit()],
    )
    app.state.limiter = limiter

    async def _rate_limit_handler(request: Request, exc: Any):
        from fastapi.responses import JSONResponse

        return JSONResponse(
            status_code=429,
            content={
                "type": "about:blank",
                "title": "Too Many Requests",
                "status": 429,
                "detail": f"Rate limit exceeded: {getattr(exc, 'detail', '')}",
            },
            headers={"Retry-After": "60"},
        )

    app.add_exception_handler(RateLimitExceeded, _rate_limit_handler)
    app.add_middleware(SlowAPIMiddleware)


# ──────────────────────────────────────────────────────────────────────
# Composite registration
# ──────────────────────────────────────────────────────────────────────


def register_middleware(app: FastAPI) -> None:
    """Register all middleware in the documented order (M-11, M-15, M-17).

    FastAPI executes middleware in reverse-registration order, so the
    first registered runs *last*. We register:

        1. request tracking  (innermost → runs last, sees final response)
        2. rate limit        (returns 429 before tracking work)
        3. CORS              (outermost → handles preflight first, no
                              auth/rate evaluation on OPTIONS)

    This keeps `X-Request-ID` set even on rate-limited requests while
    still letting CORS preflight succeed without tripping the limiter.
    """
    register_request_tracking(app)
    register_rate_limit(app)
    register_cors(app)

    # Elastic APM tracing — no-op if not configured.
    from nexora_tasks_server.tracing import init_tracing

    init_tracing(app)
