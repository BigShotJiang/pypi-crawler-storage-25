"""``/health`` endpoint registration (M-11).

Extracted from ``server.py`` so ``create_server`` stays small. Behaviour
is identical to the previous inline implementation: a single ``/health``
route returning required + optional component status, with a 5 ms
timeout per optional component.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from nexora_tasks.version import VERSION as SDK_VERSION
from nexora_tasks_server.version import VERSION

if TYPE_CHECKING:
    from nexora_tasks_server.framework import NexoraTasks


def _iso_timestamp() -> str:
    """Return an ISO-8601 timestamp with millisecond precision + Z suffix."""
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def register_health(app: FastAPI, framework: "NexoraTasks") -> None:
    """Register the public ``/health`` endpoint (M-11).

    Required components (cause 503 if missing):
      - Library initialised
      - Task function registered (count == 0 => warning, still 200)

    Optional components (reported, never 503):
      - Database / file storage / scheduler — each behind a 5 ms timeout
        so a slow dependency cannot stall a load-balancer probe.
    """

    @app.get("/health", tags=["health"])
    async def health_check() -> Dict[str, Any]:
        import asyncio

        if not framework._initialized:
            return JSONResponse(
                status_code=503,
                content={
                    "status": "unavailable",
                    "timestamp": _iso_timestamp(),
                    "version": VERSION,
                    "sdk_version": SDK_VERSION,
                    "reason": "Library not initialized",
                },
            )

        if framework.task_registry.count() == 0:
            return {
                "status": "ok",
                "timestamp": _iso_timestamp(),
                "version": VERSION,
                "sdk_version": SDK_VERSION,
                "warning": "No tasks registered",
            }

        health_status: Dict[str, Any] = {
            "status": "ok",
            "timestamp": _iso_timestamp(),
            "version": VERSION,
            "sdk_version": SDK_VERSION,
        }

        timeout_seconds = 0.005  # 5 ms per optional component

        # Database
        if framework.database is not None:
            try:
                async def check_database():
                    if hasattr(framework.database, "check_connection"):
                        return await framework.database.check_connection()
                    return True

                await asyncio.wait_for(check_database(), timeout=timeout_seconds)
                health_status["database"] = "available"
            except asyncio.TimeoutError:
                health_status["database"] = "timeout"
            except Exception:
                health_status["database"] = "unavailable"
        else:
            health_status["database"] = "not_configured"

        # File storage
        if framework.file_storage is not None:
            try:
                async def check_file_storage():
                    if hasattr(framework.file_storage, "check_connection"):
                        return await framework.file_storage.check_connection()
                    return True

                await asyncio.wait_for(check_file_storage(), timeout=timeout_seconds)
                health_status["file_storage"] = "available"
            except asyncio.TimeoutError:
                health_status["file_storage"] = "timeout"
            except Exception:
                health_status["file_storage"] = "unavailable"
        else:
            health_status["file_storage"] = "not_configured"

        # Scheduler
        if framework.scheduler is not None:
            try:
                async def check_scheduler():
                    if hasattr(framework.scheduler, "is_running"):
                        return framework.scheduler.is_running()
                    return True

                await asyncio.wait_for(check_scheduler(), timeout=timeout_seconds)
                if hasattr(framework.scheduler, "is_running"):
                    health_status["scheduler"] = (
                        "running" if framework.scheduler.is_running() else "stopped"
                    )
                else:
                    health_status["scheduler"] = "available"
            except asyncio.TimeoutError:
                health_status["scheduler"] = "timeout"
            except Exception:
                health_status["scheduler"] = "unavailable"
        else:
            health_status["scheduler"] = "not_configured"

        return health_status
