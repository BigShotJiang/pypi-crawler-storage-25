"""Elasticsearch repositories package."""

from nexora_tasks_server.repositories.elasticsearch.client import ElasticsearchClientFactory
from nexora_tasks_server.repositories.elasticsearch.base import ElasticsearchRepository
from nexora_tasks_server.repositories.elasticsearch.locks import (
    ElasticsearchDistributedLock,
    LockAcquisitionError,
)
from nexora_tasks_server.repositories.elasticsearch.database import ElasticsearchDatabase
from nexora_tasks_server.repositories.elasticsearch.webhook_db import (
    ElasticsearchWebhookRepository,
    ElasticsearchWebhookDeliveryRepository,
)
from nexora_tasks_server.repositories.elasticsearch.task_registry_store import ElasticsearchTaskRegistryStore
from nexora_tasks_server.repositories.elasticsearch.deployment_tracker import ElasticsearchDeploymentTracker
from nexora_tasks_server.repositories.elasticsearch.idempotency import ElasticsearchIdempotencyStore
from nexora_tasks_server.repositories.elasticsearch.index_manager import (
    ensure_all_index_templates,
    ensure_all_indices,
    ensure_indices_on_startup,
)

__all__ = [
    "ElasticsearchClientFactory",
    "ElasticsearchRepository",
    "ElasticsearchDistributedLock",
    "LockAcquisitionError",
    "ElasticsearchDatabase",
    "ElasticsearchWebhookRepository",
    "ElasticsearchWebhookDeliveryRepository",
    "ElasticsearchTaskRegistryStore",
    "ElasticsearchDeploymentTracker",
    "ElasticsearchIdempotencyStore",
    "ensure_all_index_templates",
    "ensure_all_indices",
    "ensure_indices_on_startup",
]
