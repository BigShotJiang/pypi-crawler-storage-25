"""Elasticsearch index mappings and composable templates for all data types.

Defines the schema for each Elasticsearch index used by nexora-tasks.

## Dynamic mapping policy

Every business index is created with ``"dynamic": "strict"`` so Elasticsearch
rejects documents with unknown top-level fields. This prevents silent schema
drift and mapping explosion caused by permissive dynamic mapping. Nested
free-form dicts that we explicitly do not want to index (``input``, ``output``,
``metadata``, ``labels``, ``error.details``, etc.) are marked with
``"enabled": False`` — they are still stored in ``_source`` but not indexed,
so they never contribute new fields to the mapping.

Observability indexes (``-logs-*``, ``-metrics-*``) use ``"dynamic": "false"``
instead of ``"strict"`` because log shippers deliberately carry variable
``data`` payloads — rejecting them would drop log events. Unknown fields are
stored in ``_source`` but not indexed, and a ``total_fields.limit: 2000`` cap
+ ``dynamic_templates`` prevents runaway field growth.

See ``docs/server/elasticsearch-indexes.md`` for the full reference.
"""

# ---------------------------------------------------------------------------
# Shared settings
# ---------------------------------------------------------------------------

DEFAULT_INDEX_SETTINGS = {
    "number_of_shards": 1,
    "number_of_replicas": 1,
}

# ---------------------------------------------------------------------------
# Business indexes (strict dynamic mapping)
# ---------------------------------------------------------------------------

# Thread index mappings
THREAD_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "id": {"type": "keyword"},
        "name": {"type": "keyword"},
        "state": {"type": "keyword"},
        # First-class field on Thread (also mirrored under metadata for legacy clients)
        "environment_id": {"type": "keyword"},
        "mode": {"type": "keyword"},
        "created_at": {"type": "date"},
        "started_at": {"type": "date"},
        "finished_at": {"type": "date"},
        "schedule_id": {"type": "keyword"},
        "run_id": {"type": "keyword"},
        "parent_thread_id": {"type": "keyword"},
        "attempt": {"type": "integer"},
        "progress": {"type": "float"},
        "progress_message": {"type": "text"},
        "metadata": {
            "type": "object",
            "dynamic": "false",
            "properties": {
                "app_id": {"type": "keyword"},
                "user_id": {"type": "keyword"},
                "task_id": {"type": "keyword"},
                "task_version": {"type": "keyword"},
                "environment_id": {"type": "keyword"},
            },
        },
        "params": {"type": "object", "enabled": False},
        "inputs": {"type": "object", "enabled": False},
        "outputs": {"type": "object", "enabled": False},
        "error": {
            "type": "object",
            "dynamic": "false",
            "properties": {
                "code": {"type": "keyword"},
                "message": {"type": "text"},
                "exception_type": {"type": "keyword"},
                "stack_trace": {"type": "text", "index": False},
                "details": {"type": "object", "enabled": False},
            },
        },
    },
}

# Artifact index mappings
ARTIFACT_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "id": {"type": "keyword"},
        "thread_id": {"type": "keyword"},
        "ref": {"type": "keyword"},
        "kind": {"type": "keyword"},
        "direction": {"type": "keyword"},
        "media_type": {"type": "keyword"},
        "size": {"type": "long"},
        "sha256": {"type": "keyword"},
        "file_ref": {"type": "keyword"},
        "filename": {"type": "keyword"},
        "explain": {"type": "text"},
        "url": {"type": "keyword"},
        "text": {"type": "text", "index": False},
        "task_id": {"type": "keyword"},
        "task_version": {"type": "keyword"},
        "created_at": {"type": "date"},
        "archived": {"type": "boolean"},
        "archived_at": {"type": "date"},
        "value": {"type": "object", "enabled": False},
        "labels": {"type": "object", "enabled": False},
    },
}

# Schedule index mappings
SCHEDULE_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "id": {"type": "keyword"},
        "environment_id": {"type": "keyword"},
        "name": {"type": "text", "fields": {"keyword": {"type": "keyword"}}},
        "state": {"type": "keyword"},
        "cron": {"type": "keyword"},
        "timezone": {"type": "keyword"},
        "task_id": {"type": "keyword"},
        "task_version": {"type": "keyword"},
        "concurrency_policy": {"type": "keyword"},
        "max_attempts": {"type": "integer"},
        "created_at": {"type": "date"},
        "updated_at": {"type": "date"},
        "last_run_at": {"type": "date"},
        "next_run_at": {"type": "date"},
        "run_count": {"type": "integer"},
        "inputs_template": {"type": "object", "enabled": False},
        "params": {"type": "object", "enabled": False},
        "metadata": {"type": "object", "enabled": False},
        "webhooks": {"type": "object", "enabled": False},
    },
}

# Run index mappings
RUN_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "run_id": {"type": "keyword"},
        "schedule_id": {"type": "keyword"},
        "thread_id": {"type": "keyword"},
        "state": {"type": "keyword"},
        "attempt": {"type": "integer"},
        "max_attempts": {"type": "integer"},
        "scheduled_for_local": {"type": "date"},
        "scheduled_for_utc": {"type": "date"},
        "created_at": {"type": "date"},
        "started_at": {"type": "date"},
        "finished_at": {"type": "date"},
        "threads": {"type": "keyword"},
        "error": {"type": "text"},
        "labels": {"type": "object", "enabled": False},
        "metrics": {"type": "object", "enabled": False},
    },
}

# Webhook index mappings
WEBHOOK_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "id": {"type": "keyword"},
        "url": {"type": "keyword"},
        "events": {"type": "object", "enabled": False},
        "data_filters": {"type": "object", "enabled": False},
        "scope": {"type": "object", "enabled": False},
        "task_id": {"type": "keyword"},
        "task_version": {"type": "keyword"},
        "enabled": {"type": "boolean"},
        "secret": {"type": "keyword"},
        "api_key": {"type": "keyword"},
        "timeout_seconds": {"type": "integer"},
        "source": {"type": "keyword"},
        "created_at": {"type": "date"},
        "updated_at": {"type": "date"},
        "created_by": {"type": "keyword"},
        "created_by_user_id": {"type": "keyword"},
        "created_by_app_id": {"type": "keyword"},
        "environment_id": {"type": "keyword"},
        "headers": {"type": "object", "enabled": False},
        "metadata": {"type": "object", "enabled": False},
    },
}

# Webhook delivery index mappings
DELIVERY_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "id": {"type": "keyword"},
        "webhook_id": {"type": "keyword"},
        "thread_id": {"type": "keyword"},
        "run_id": {"type": "keyword"},
        "event_type": {"type": "keyword"},
        "event": {"type": "keyword"},
        "status": {"type": "keyword"},
        "status_code": {"type": "integer"},
        "http_status": {"type": "integer"},
        "timestamp": {"type": "date"},
        "attempt": {"type": "integer"},
        "response_time_ms": {"type": "integer"},
        "duration_ms": {"type": "integer"},
        "delivery_url": {"type": "keyword"},
        "request": {"type": "object", "enabled": False},
        "response": {"type": "object", "enabled": False},
        "event_payload": {"type": "object", "enabled": False},
        "error": {"type": "text"},
        # C-7: first 8 KB of the response body, captured for debugging.
        # `enabled: false` keeps it in `_source` but excluded from the
        # search index so it cannot blow up the term dictionary.
        "response_body_truncated": {"type": "text", "index": False},
    },
}

# Task definition index mappings
TASK_DEFINITION_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "task_id": {"type": "keyword"},
        "version": {"type": "keyword"},
        "full_id": {"type": "keyword"},
        "name": {"type": "text", "fields": {"keyword": {"type": "keyword"}}},
        "description": {"type": "text"},
        "runtime": {"type": "keyword"},
        "entry_point": {"type": "keyword"},
        "sdk_version": {"type": "keyword"},
        "registered_at": {"type": "date"},
        "deployed_at": {"type": "date"},
        "is_latest": {"type": "boolean"},
        "code_path": {"type": "keyword"},
        "venv_path": {"type": "keyword"},
        "zip_path": {"type": "keyword"},
        "zip_hash": {"type": "keyword"},
        "input_schema": {"type": "object", "enabled": False},
        "output_schema": {"type": "object", "enabled": False},
        "config_schema": {"type": "object", "enabled": False},
        "requirements": {"type": "object", "enabled": False},
        "credentials": {"type": "keyword"},
    },
}

# Deployment record index mappings
DEPLOYMENT_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "zip_path": {"type": "keyword"},
        "zip_hash": {"type": "keyword"},
        "task_id": {"type": "keyword"},
        "version": {"type": "keyword"},
        "status": {"type": "keyword"},
        "deployed_at": {"type": "date"},
        "error": {"type": "text"},
    },
}

# Idempotency key index mappings
IDEMPOTENCY_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "hash_key": {"type": "keyword"},
        "thread_id": {"type": "keyword"},
        "created_at": {"type": "date"},
    },
}

# Credential index mappings (encrypted values)
CREDENTIAL_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "name": {"type": "keyword"},
        "encrypted_value": {"type": "binary"},
        "description": {"type": "text"},
        "tags": {"type": "keyword"},
        "created_at": {"type": "date"},
        "updated_at": {"type": "date"},
        "expires_at": {"type": "date"},
    },
}

# Task configuration index mappings
CONFIG_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "task_id": {"type": "keyword"},
        "version": {"type": "keyword"},
        "encrypted_values": {"type": "binary"},
        "updated_at": {"type": "date"},
        "environment_id": {"type": "keyword"},
    },
}

# File metadata index mappings (standalone file uploads)
FILE_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "file_ref": {"type": "keyword"},
        "filename": {"type": "keyword"},
        "media_type": {"type": "keyword"},
        "size": {"type": "long"},
        "sha256": {"type": "keyword"},
        "created_at": {"type": "date"},
        "updated_at": {"type": "date"},
        "created_by": {"type": "keyword"},
        "labels": {"type": "object", "enabled": False},
    },
}

# Distributed lock index mappings
LOCK_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "owner": {"type": "keyword"},
        "acquired_at": {"type": "date"},
        "expires_at": {"type": "date"},
        "heartbeat_at": {"type": "date"},
        "context": {"type": "object", "enabled": False},
    },
}

# System settings index mappings
SETTINGS_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "key": {"type": "keyword"},
        "value": {"type": "object", "enabled": False},
        "updated_at": {"type": "date"},
        "updated_by": {"type": "keyword"},
    },
}

# Environment index mappings (multi-environment support)
ENVIRONMENT_MAPPINGS = {
    "dynamic": "strict",
    "properties": {
        "id": {"type": "keyword"},
        "name": {"type": "keyword"},
        "description": {"type": "text"},
        "status": {"type": "keyword"},
        "promotion_order": {"type": "integer"},
        "created_at": {"type": "date"},
        "api_keys": {"type": "keyword"},
        "admin_api_keys": {"type": "keyword"},
        "settings": {"type": "object", "enabled": False},
        "task_activations": {"type": "object", "enabled": False},
    },
}


# ---------------------------------------------------------------------------
# Index + template registry
# ---------------------------------------------------------------------------

INDEX_SUFFIXES = {
    "threads": "threads",
    "artifacts": "artifacts",
    "schedules": "schedules",
    "runs": "runs",
    "webhooks": "webhooks",
    "deliveries": "deliveries",
    "tasks": "tasks",
    "deployments": "deployments",
    "idempotency": "idempotency",
    "credentials": "credentials",
    "config": "config",
    "files": "files",
    "locks": "locks",
    "settings": "settings",
    "environments": "environments",
}

# All business index mappings by suffix (used by ensure_all_indices).
# Observability indexes (logs, metrics) are NOT included here — they are
# created on-demand by log/metric shippers and their mapping is applied via
# composable templates, see ``INDEX_TEMPLATES`` below.
ALL_MAPPINGS = {
    "threads": THREAD_MAPPINGS,
    "artifacts": ARTIFACT_MAPPINGS,
    "schedules": SCHEDULE_MAPPINGS,
    "runs": RUN_MAPPINGS,
    "webhooks": WEBHOOK_MAPPINGS,
    "deliveries": DELIVERY_MAPPINGS,
    "tasks": TASK_DEFINITION_MAPPINGS,
    "deployments": DEPLOYMENT_MAPPINGS,
    "idempotency": IDEMPOTENCY_MAPPINGS,
    "credentials": CREDENTIAL_MAPPINGS,
    "config": CONFIG_MAPPINGS,
    "files": FILE_MAPPINGS,
    "locks": LOCK_MAPPINGS,
    "settings": SETTINGS_MAPPINGS,
    "environments": ENVIRONMENT_MAPPINGS,
}


def build_index_templates(prefix: str) -> dict:
    """Build the set of composable index templates for time-series indexes.

    Metrics are now shipped via OTel Collector to the ``metrics-generic.otel-default``
    data stream, which is backed by Elasticsearch's built-in OTel template. No
    custom index templates are required.

    Args:
        prefix: Index name prefix (usually from ``ELASTICSEARCH_INDEX_PREFIX``).

    Returns:
        Empty dict — all legacy custom templates have been removed.
    """
    return {}
