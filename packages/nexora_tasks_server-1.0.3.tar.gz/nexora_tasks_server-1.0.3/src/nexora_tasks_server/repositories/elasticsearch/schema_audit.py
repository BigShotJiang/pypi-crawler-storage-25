"""Static audit: persisted Elasticsearch documents vs strict mappings.

After large refactors, Pydantic ``model_dump()`` shapes can gain top-level fields
that are not declared under ``mappings.properties`` while ``dynamic`` is
``strict`` — Elasticsearch then rejects writes with
``strict_dynamic_mapping_exception``.

This module compares **root** keys of representative documents (built the same
way as repository ``_to_doc`` methods, or inline dicts where stores build
documents without a shared serializer) against
``nexora_tasks_server.repositories.elasticsearch.mappings.ALL_MAPPINGS``.

Run manually::

    uv run python -m nexora_tasks_server.repositories.elasticsearch.schema_audit

Or rely on ``packages/server/tests/test_es_mapping_schema_audit.py`` in CI.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List
from unittest.mock import MagicMock

from nexora_tasks.models.artifact import Artifact
from nexora_tasks.models.schedule import ConcurrencyPolicy, Run, RunState, Schedule, ScheduleState
from nexora_tasks.models.thread import Thread
from nexora_tasks.models.thread_error import ThreadError
from nexora_tasks.thread_state import ThreadState


@dataclass(frozen=True)
class SchemaDriftFinding:
    """One mismatch between a serialized document and the strict mapping."""

    index_suffix: str
    case_name: str
    message: str


def _strict_root_properties(mapping: Dict[str, Any]) -> Dict[str, Any]:
    return (mapping or {}).get("properties") or {}


def _audit_root_keys(
    *,
    index_suffix: str,
    case_name: str,
    mapping: Dict[str, Any],
    doc: Dict[str, Any],
) -> List[SchemaDriftFinding]:
    props = _strict_root_properties(mapping)
    if not props:
        return [
            SchemaDriftFinding(
                index_suffix,
                case_name,
                "mapping has no properties — cannot audit strict root keys",
            )
        ]
    findings: List[SchemaDriftFinding] = []
    for key in doc:
        if key not in props:
            findings.append(
                SchemaDriftFinding(
                    index_suffix,
                    case_name,
                    f"document root key {key!r} is not declared in mapping.properties",
                )
            )
    return findings


def _mock_repo(repo_cls: type, index_prefix: str = "nexora-tasks") -> Any:
    return repo_cls(MagicMock(), index_prefix)


def _sample_thread_doc() -> Dict[str, Any]:
    from nexora_tasks_server.repositories.elasticsearch.database import _ThreadRepository

    repo = _mock_repo(_ThreadRepository)
    thread = Thread(
        id="audit-thread-1",
        name="audit",
        state=ThreadState.QUEUED,
        environment_id="staging",
        metadata={
            "user_id": "u1",
            "app_id": "a1",
            "task_id": "t1",
            "task_version": "1.0.0",
            "environment_id": "staging",
        },
        params={"mode": "echo"},
        error=ThreadError(
            code="E_TEST",
            message="boom",
            exception_type="RuntimeError",
            stack_trace="tb",
            details={"hint": "x"},
        ),
        progress=0.5,
        progress_message="working",
        inputs=[
            Artifact(
                id="in1",
                thread_id="audit-thread-1",
                kind="text",
                ref="input",
                text="hi",
                labels={"environment_id": "staging"},
                created_at=datetime.now(timezone.utc),
            )
        ],
        outputs=[],
        created_at=datetime.now(timezone.utc),
        started_at=datetime.now(timezone.utc),
        finished_at=None,
        schedule_id="sch1",
        run_id="sch1_run_2026-01-01T00:00:00.000000Z",
        attempt=1,
    )
    return repo._to_doc(thread)


def _sample_artifact_doc() -> Dict[str, Any]:
    from nexora_tasks_server.repositories.elasticsearch.database import _ArtifactRepository

    repo = _mock_repo(_ArtifactRepository)
    art = Artifact(
        id="art1",
        thread_id="audit-thread-1",
        kind="json",
        ref="out",
        value={"k": 1},
        task_id="hello",
        task_version="0.1.0",
        direction="output",
        labels={"environment_id": "staging"},
        created_at=datetime.now(timezone.utc),
    )
    return repo._to_doc(art)


def _sample_schedule_doc() -> Dict[str, Any]:
    from nexora_tasks_server.repositories.elasticsearch.database import _ScheduleRepository

    repo = _mock_repo(_ScheduleRepository)
    now = datetime.now(timezone.utc)
    sch = Schedule(
        id="sch-audit-1",
        cron="0 9 * * *",
        timezone="UTC",
        state=ScheduleState.ACTIVE,
        environment_id="staging",
        task_id="hello-world",
        task_version="0.1.0",
        inputs_template=[],
        params={},
        metadata={"environment_id": "staging"},
        webhooks=None,
        concurrency_policy=ConcurrencyPolicy.ALLOW,
        max_attempts=3,
        created_at=now,
        updated_at=now,
    )
    return repo._to_doc(sch)


def _sample_run_doc() -> Dict[str, Any]:
    from nexora_tasks_server.repositories.elasticsearch.database import _RunRepository

    repo = _mock_repo(_RunRepository)
    now = datetime.now(timezone.utc)
    run = Run(
        schedule_id="sch1",
        run_id="sch1_run_2026-01-01T12:00:00.000000Z",
        scheduled_for_local=now,
        scheduled_for_utc=now,
        state=RunState.PENDING,
        attempt=1,
        max_attempts=3,
        threads=["t1"],
        metrics={"ms": 1},
        labels={"batch": "1"},
        created_at=now,
        started_at=None,
        finished_at=None,
    )
    return repo._to_doc(run)


def _sample_webhook_doc() -> Dict[str, Any]:
    from nexora_tasks_server.repositories.elasticsearch.webhook_db import _WebhookRepo
    from nexora_tasks.models.webhook import EventFilters, Webhook

    repo = _mock_repo(_WebhookRepo)
    now = datetime.now(timezone.utc)
    wh = Webhook(
        id="wh1",
        url="https://example.com/hook",
        events=EventFilters(include=["thread.completed"]),
        data_filters=None,
        scope=None,
        task_id="t",
        task_version="1",
        enabled=True,
        secret="s",
        api_key=None,
        timeout_seconds=30,
        source="manual",
        created_at=now,
        updated_at=now,
        created_by="admin",
        created_by_user_id="u",
        created_by_app_id="a",
        environment_id="staging",
        metadata={},
    )
    return repo._to_doc(wh)


def _sample_delivery_doc() -> Dict[str, Any]:
    from nexora_tasks_server.repositories.elasticsearch.webhook_db import _DeliveryRepo
    from nexora_tasks.models.webhook import WebhookDelivery

    repo = _mock_repo(_DeliveryRepo)
    now = datetime.now(timezone.utc)
    d = WebhookDelivery(
        id="d1",
        webhook_id="wh1",
        thread_id="t1",
        run_id=None,
        event_type="thread.completed",
        event_payload={"thread_id": "t1"},
        timestamp=now,
        status="success",
        status_code=200,
        response_time_ms=12,
        error=None,
        delivery_url="https://example.com/hook",
        response_body_truncated=None,
    )
    return repo._to_doc(d)


def _sample_task_definition_doc() -> Dict[str, Any]:
    from nexora_tasks_server.repositories.elasticsearch.task_registry_store import _TaskDefRepo

    repo = _mock_repo(_TaskDefRepo)

    # ``TaskDefinition`` in the SDK does not match every attribute ``_TaskDefRepo._to_doc``
    # reads (legacy ``input_schema`` vs ``input_schemas``). Use a minimal stub so the
    # audit tracks the serializer, not Pydantic field drift inside the SDK model.
    class _TaskDefAuditStub:
        task_id = "hello-world"
        version = "0.1.0"
        name = "Hello"
        description = "d"
        is_latest = True
        input_schema = [{"ref": "input", "kind": "text"}]
        output_schema = [{"kind": "json"}]
        config_schema = {"type": "object"}
        credentials = "cred-ref"
        code_path = "/tmp/code"
        venv_path = "/tmp/venv"
        sdk_version = "0.5.0"

    return repo._to_doc(_TaskDefAuditStub())  # type: ignore[arg-type]


def _sample_deployment_doc() -> Dict[str, Any]:
    from nexora_tasks_server.repositories.elasticsearch.deployment_tracker import _DeploymentRepo
    from nexora_tasks.models.task_definition import DeploymentRecord

    repo = _mock_repo(_DeploymentRepo)
    rec = DeploymentRecord(
        zip_path="/tmp/x.zip",
        zip_hash="sha256:abc",
        task_id="t",
        version="1",
        status="deployed",
        deployed_at=datetime.now(timezone.utc),
        error=None,
    )
    return repo._to_doc(rec)


def _sample_idempotency_doc() -> Dict[str, Any]:
    # Mirrors ``_IdempotencyRepo.upsert`` (``idempotency.py``).
    return {
        "hash_key": "a" * 64,
        "thread_id": "audit-thread-idem-1",
        "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }


def _sample_credential_doc() -> Dict[str, Any]:
    # Mirrors ``ElasticsearchCredentialStore.create_or_update`` final ``doc``.
    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    exp = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat().replace("+00:00", "Z")
    return {
        "name": "audit-credential",
        "encrypted_value": base64.b64encode(b"cipher-bytes").decode(),
        "description": "audit",
        "tags": ["tier-1", "audit"],
        "created_at": now,
        "updated_at": now,
        "expires_at": exp,
    }


def _sample_config_doc() -> Dict[str, Any]:
    # Mirrors ``ElasticsearchConfigurationService.set_config`` document body.
    return {
        "task_id": "hello-world",
        "version": "0.1.0",
        "encrypted_values": base64.b64encode(b"{}").decode(),
        "updated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }


def _sample_file_doc() -> Dict[str, Any]:
    # Mirrors ``ElasticsearchFileMetadataStore.save`` for a new file (no prior doc).
    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    return {
        "file_ref": "audit-file-ref-1",
        "filename": "notes.txt",
        "media_type": "text/plain",
        "size": 42,
        "sha256": "a" * 64,
        "created_at": now,
        "updated_at": now,
        "created_by": "audit-user",
        "labels": {"purpose": "schema-audit"},
    }


def _sample_lock_doc() -> Dict[str, Any]:
    # Mirrors ``ElasticsearchDistributedLock.acquire`` initial ``lock_doc``.
    now = datetime.now(timezone.utc)
    expires = now + timedelta(seconds=120)

    def _iso_z(dt: datetime) -> str:
        return dt.isoformat().replace("+00:00", "Z")

    return {
        "owner": "audit-worker-1",
        "acquired_at": _iso_z(now),
        "expires_at": _iso_z(expires),
        "heartbeat_at": _iso_z(now),
        "context": {"reason": "schema_audit"},
    }


def _sample_settings_doc() -> Dict[str, Any]:
    # Mirrors ``ElasticsearchSettingsStore.update_settings`` document body.
    from nexora_tasks_server.repositories.elasticsearch.settings_store import (
        ElasticsearchSettingsStore,
    )

    now = datetime.now(timezone.utc)
    return {
        "key": ElasticsearchSettingsStore.SETTINGS_KEY,
        "value": {"max_concurrent_threads": 8},
        "updated_at": now.isoformat(),
        "updated_by": "audit-admin",
    }


def _sample_environment_doc() -> Dict[str, Any]:
    # Mirrors a persisted ``Environment`` JSON shape (file registry today; ES index
    # is provisioned for the same contract via ``ENVIRONMENT_MAPPINGS``).
    from nexora_tasks.models.environment import (
        Environment,
        EnvironmentActivation,
        EnvironmentSettings,
    )

    env = Environment(
        id="audit-env",
        name="Audit environment",
        description="schema audit sample",
        api_keys=["tf-key-regular-audit"],
        admin_api_keys=["tf-key-admin-audit"],
        settings=EnvironmentSettings(max_concurrent_threads=4, env_vars={"AUDIT": "1"}),
        created_at=datetime.now(timezone.utc),
        status="active",
        promotion_order=0,
    )
    doc = env.model_dump(mode="json")
    act = EnvironmentActivation(
        environment_id="audit-env",
        task_id="hello-world",
        version="0.1.0",
        activated_at=datetime.now(timezone.utc),
        activated_by="audit",
        previous_version=None,
    )
    doc["task_activations"] = {"hello-world": act.model_dump(mode="json")}
    return doc


def strict_mapping_audit_cases() -> List[tuple[str, str, Dict[str, Any], Callable[[], Dict[str, Any]]]]:
    """Return ``(index_suffix, case_name, mapping, sample_doc_builder)`` for each strict index.

    Kept in lockstep with ``ALL_MAPPINGS``: missing or extra suffixes raise ``RuntimeError``.
    """
    from nexora_tasks_server.repositories.elasticsearch.mappings import ALL_MAPPINGS

    cases: List[tuple[str, str, Dict[str, Any], Callable[[], Dict[str, Any]]]] = [
        ("threads", "thread_full", ALL_MAPPINGS["threads"], _sample_thread_doc),
        ("artifacts", "artifact_json", ALL_MAPPINGS["artifacts"], _sample_artifact_doc),
        ("schedules", "schedule_active", ALL_MAPPINGS["schedules"], _sample_schedule_doc),
        ("runs", "run_pending", ALL_MAPPINGS["runs"], _sample_run_doc),
        ("webhooks", "webhook_manual", ALL_MAPPINGS["webhooks"], _sample_webhook_doc),
        ("deliveries", "delivery_success", ALL_MAPPINGS["deliveries"], _sample_delivery_doc),
        ("tasks", "task_definition_full", ALL_MAPPINGS["tasks"], _sample_task_definition_doc),
        ("deployments", "deployment_deployed", ALL_MAPPINGS["deployments"], _sample_deployment_doc),
        ("idempotency", "idempotency_set", ALL_MAPPINGS["idempotency"], _sample_idempotency_doc),
        ("credentials", "credential_full", ALL_MAPPINGS["credentials"], _sample_credential_doc),
        ("config", "config_encrypted", ALL_MAPPINGS["config"], _sample_config_doc),
        ("files", "file_metadata", ALL_MAPPINGS["files"], _sample_file_doc),
        ("locks", "lock_acquired", ALL_MAPPINGS["locks"], _sample_lock_doc),
        ("settings", "settings_system", ALL_MAPPINGS["settings"], _sample_settings_doc),
        ("environments", "environment_with_activations", ALL_MAPPINGS["environments"], _sample_environment_doc),
    ]

    case_suffixes = {c[0] for c in cases}
    if case_suffixes != set(ALL_MAPPINGS):
        raise RuntimeError(
            "schema_audit cases must cover exactly ALL_MAPPINGS keys; "
            f"cases={sorted(case_suffixes)!r} all={sorted(ALL_MAPPINGS)!r}"
        )
    if len(case_suffixes) != len(cases):
        raise RuntimeError("schema_audit registry must have exactly one case per index suffix")
    return cases


def collect_strict_mapping_findings_for_suffix(index_suffix: str) -> List[SchemaDriftFinding]:
    """Run the audit for a single ``ALL_MAPPINGS`` suffix (for parametrized tests)."""
    for suffix, case_name, mapping, builder in strict_mapping_audit_cases():
        if suffix == index_suffix:
            doc = builder()
            return _audit_root_keys(
                index_suffix=suffix,
                case_name=case_name,
                mapping=mapping,
                doc=doc,
            )
    raise KeyError(f"no strict mapping audit case for index suffix {index_suffix!r}")


def collect_strict_mapping_findings() -> List[SchemaDriftFinding]:
    """Run all built-in audit cases. Empty list means no drift detected."""
    out: List[SchemaDriftFinding] = []
    for suffix, case_name, mapping, builder in strict_mapping_audit_cases():
        doc = builder()
        out.extend(
            _audit_root_keys(
                index_suffix=suffix,
                case_name=case_name,
                mapping=mapping,
                doc=doc,
            )
        )
    return out


def main() -> int:
    findings = collect_strict_mapping_findings()
    for f in findings:
        print(f"[{f.index_suffix}/{f.case_name}] {f.message}")
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
