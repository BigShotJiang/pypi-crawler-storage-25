"""Elasticsearch index management utilities.

Provides functions to create and manage ES indices and composable index
templates at startup. The templates ensure that time-series indexes (logs,
metrics) created on-the-fly by the shippers inherit the correct schema
without having to create them explicitly.
"""

import os
from typing import Optional

from nexora_tasks.logging import logger


async def ensure_all_index_templates(
    client: "AsyncElasticsearch",
    index_prefix: Optional[str] = None,
) -> int:
    """Create (or update) all composable index templates.

    Composable index templates are applied automatically by Elasticsearch to
    any index whose name matches the template's ``index_patterns``. This
    means daily rollover indexes such as ``{prefix}-logs-2026.04.13`` inherit
    their mapping/settings the moment they are first written to — no explicit
    ``indices.create`` call needed.

    ``put_index_template`` is idempotent: calling it again with the same body
    simply updates the template in place, so it is safe to run on every
    startup.

    Args:
        client: AsyncElasticsearch client instance.
        index_prefix: Index name prefix (default from
            ``ELASTICSEARCH_INDEX_PREFIX`` env var).

    Returns:
        Number of templates created/updated.
    """
    from nexora_tasks_server.repositories.elasticsearch.mappings import (
        build_index_templates,
    )

    prefix = index_prefix or os.getenv("ELASTICSEARCH_INDEX_PREFIX", "nexora-tasks")
    templates = build_index_templates(prefix)

    applied = 0
    for name, body in templates.items():
        try:
            await client.indices.put_index_template(name=name, body=body)
            applied += 1
            logger.info(
                "elasticsearch.index_template.applied",
                template=name,
                patterns=body.get("index_patterns"),
            )
        except Exception as e:
            logger.error(
                "elasticsearch.index_template.apply_failed",
                template=name,
                error=str(e),
            )
            # Don't raise — continue with other templates

    logger.info(
        "elasticsearch.index_templates.initialized",
        total_templates=len(templates),
        applied=applied,
        prefix=prefix,
    )

    return applied


async def ensure_all_indices(
    client: "AsyncElasticsearch",
    index_prefix: Optional[str] = None,
    force_create: bool = False,
) -> int:
    """Create all Elasticsearch business indices with their mappings.

    This function creates every static business index listed in
    ``ALL_MAPPINGS`` if it does not already exist. Useful for initializing a
    fresh ES cluster or ensuring indices are ready before the application
    starts processing requests. Time-series indexes (logs, metrics) are
    intentionally NOT created here — they are created on first write and
    inherit their schema from composable index templates (see
    ``ensure_all_index_templates``).

    Args:
        client: AsyncElasticsearch client instance.
        index_prefix: Index name prefix (default from
            ``ELASTICSEARCH_INDEX_PREFIX`` env var).
        force_create: Reserved for future use; currently unused.

    Returns:
        Number of indices created.
    """
    from nexora_tasks_server.repositories.elasticsearch.mappings import (
        ALL_MAPPINGS,
        DEFAULT_INDEX_SETTINGS,
    )

    prefix = index_prefix or os.getenv("ELASTICSEARCH_INDEX_PREFIX", "nexora-tasks")

    created_count = 0

    for suffix, mapping in ALL_MAPPINGS.items():
        index_name = f"{prefix}-{suffix}"

        try:
            exists = await client.indices.exists(index=index_name)

            if not exists:
                # ES Python client ≥9.0 removed `body`; pass fields directly.
                await client.indices.create(
                    index=index_name,
                    mappings=mapping,
                    settings=DEFAULT_INDEX_SETTINGS,
                )
                created_count += 1

                logger.info(
                    "elasticsearch.index.created",
                    index=index_name,
                )
            else:
                logger.debug(
                    "elasticsearch.index.exists",
                    index=index_name,
                )

        except Exception as e:
            # Index might have been created by another worker (race condition)
            if "resource_already_exists_exception" in str(e):
                logger.debug(
                    "elasticsearch.index.already_created",
                    index=index_name,
                )
            else:
                logger.error(
                    "elasticsearch.index.create_failed",
                    index=index_name,
                    error=str(e),
                )
                # Don't raise - continue creating other indices

    logger.info(
        "elasticsearch.indices.initialized",
        total_indices=len(ALL_MAPPINGS),
        created=created_count,
        prefix=prefix,
    )

    return created_count


async def ensure_indices_on_startup() -> int:
    """Create all ES indices and templates on server startup if enabled.

    Checks the ``ELASTICSEARCH_CREATE_INDICES_ON_STARTUP`` environment
    variable. If set to ``true``, ``1``, or ``yes``, this function:

    1. Creates all composable index templates (``-logs-*``, ``-metrics-*``)
       so that time-series indexes inherit the correct schema when they
       are first written to.
    2. Creates all static business indexes (threads, artifacts, etc.) with
       their explicit mappings.

    Templates are applied *before* static indexes to keep behavior
    consistent in environments where daily rollover indexes might be
    auto-created mid-startup.

    Environment Variables:
        ELASTICSEARCH_CREATE_INDICES_ON_STARTUP: ``true``/``1``/``yes`` to
            enable (default: disabled).
        STORAGE_TYPE: Must be ``elasticsearch`` for this to run.
        ELASTICSEARCH_HOSTS / ELASTICSEARCH_CLOUD_ID: Connection settings.
        ELASTICSEARCH_INDEX_PREFIX: Name prefix (default ``nexora-tasks``).

    Returns:
        Total number of resources (templates + indices) created/updated,
        or 0 if disabled or not applicable.
    """
    enabled = os.getenv("ELASTICSEARCH_CREATE_INDICES_ON_STARTUP", "").lower()
    if enabled not in ("true", "1", "yes"):
        logger.debug(
            "elasticsearch.indices.startup_creation_disabled",
            message="Set ELASTICSEARCH_CREATE_INDICES_ON_STARTUP=true to enable",
        )
        return 0

    storage_type = os.getenv("STORAGE_TYPE", "file")
    if storage_type != "elasticsearch":
        logger.debug(
            "elasticsearch.indices.startup_creation_skipped",
            reason="STORAGE_TYPE is not elasticsearch",
            storage_type=storage_type,
        )
        return 0

    try:
        from nexora_tasks_server.repositories.elasticsearch.client import (
            ElasticsearchClientFactory,
        )

        client = ElasticsearchClientFactory.from_env()

        # 1. Apply composable templates FIRST so daily indexes inherit them.
        templates_applied = await ensure_all_index_templates(client)

        # 2. Create static business indexes.
        indices_created = await ensure_all_indices(client)

        return templates_applied + indices_created

    except Exception as e:
        logger.error(
            "elasticsearch.indices.startup_creation_failed",
            error=str(e),
        )
        return 0
