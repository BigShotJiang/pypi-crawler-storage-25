"""S3 repositories package."""

from nexora_tasks_server.repositories.s3.task_storage import S3TaskStorage

__all__ = [
    "S3TaskStorage",
]
