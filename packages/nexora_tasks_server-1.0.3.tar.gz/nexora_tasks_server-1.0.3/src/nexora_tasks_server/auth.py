"""API key authentication middleware/dependency for FastAPI."""

import hmac
from typing import Iterable, Literal, Optional

from fastapi import Header, HTTPException, status

from nexora_tasks.errors import AUTH_INVALID, AUTH_REQUIRED, problem_json_dict


def constant_time_key_in(candidate: str, keys: Optional[Iterable[str]]) -> bool:
    """Timing-safe membership test for an API key.

    Compares ``candidate`` against every key in ``keys`` using
    ``hmac.compare_digest`` so that the comparison time does not leak
    information about which key (if any) matched. Always iterates the full
    list to avoid a short-circuit on first mismatch.
    """
    if not keys:
        return False
    matched = False
    candidate_bytes = candidate.encode("utf-8")
    for key in keys:
        if hmac.compare_digest(candidate_bytes, key.encode("utf-8")):
            matched = True
    return matched


async def verify_api_key(
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
    api_keys: Optional[list[str]] = None,
    admin_api_keys: Optional[list[str]] = None,
) -> tuple[str, Literal["regular", "admin"]]:
    """Verify API key from X-API-Key header.

    This function is kept for backward compatibility. The primary authentication
    method is `get_authenticated_request()` dependency function.

    Args:
        x_api_key: API key from X-API-Key header
        api_keys: List of valid regular API keys
        admin_api_keys: List of valid admin API keys (checked first)

    Returns:
        Tuple of (verified_api_key, key_type) where key_type is "regular" or "admin"

    Raises:
        HTTPException: If API key is missing or invalid (Problem+JSON format)
    """
    if not x_api_key:
        problem = problem_json_dict(
            status_code=status.HTTP_401_UNAUTHORIZED,
            title="Unauthorized",
            detail="Missing API key",
            code=AUTH_REQUIRED,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=problem,
        )

    # Check admin keys first (admin precedence)
    if constant_time_key_in(x_api_key, admin_api_keys):
        return x_api_key, "admin"

    # Check regular keys
    if constant_time_key_in(x_api_key, api_keys):
        return x_api_key, "regular"

    # Invalid key
    problem = problem_json_dict(
        status_code=status.HTTP_401_UNAUTHORIZED,
        title="Unauthorized",
        detail="Invalid API key",
        code=AUTH_INVALID,
    )
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=problem,
    )

