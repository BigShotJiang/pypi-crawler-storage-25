"""Concrete :class:`ArtifactPublisher` backed by :class:`ArtifactService`.

The SDK's :class:`nexora_tasks.context.TaskContext` historically reached
into ``nexora_tasks_server.services.artifact_service.ArtifactService``,
creating an SDK → server import cycle (C-7). After the refactor the SDK
declares an :class:`nexora_tasks.protocols.artifact_publisher.ArtifactPublisher`
Protocol and the server registers this concrete implementation on each
:class:`nexora_tasks_server.framework.NexoraTasks` instance.

The implementation is intentionally a thin pass-through to ``ArtifactService``
so that the existing server validation, metrics and logging behaviour is
preserved 1:1 with the pre-refactor inline code path.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from nexora_tasks_server.services.artifact_service import ArtifactService

if TYPE_CHECKING:
    from nexora_tasks.models.artifact import Artifact
    from nexora_tasks_server.interfaces.database import Database
    from nexora_tasks_server.interfaces.storage import FileStorage


class ArtifactServicePublisher:
    """Adapter that satisfies :class:`ArtifactPublisher` via ``ArtifactService``.

    Constructed once per :class:`NexoraTasks` instance using the framework's
    database and file_storage. ``TaskContext.publish_output_artifacts`` calls
    :meth:`create_artifact` per output artifact, identical to the legacy
    inline ``ArtifactService(...).create_artifact(...)`` it replaces.
    """

    def __init__(
        self,
        database: "Database",
        file_storage: Optional["FileStorage"] = None,
    ) -> None:
        """Initialise the publisher.

        Args:
            database: Backing :class:`Database` implementation (mandatory —
                artifact persistence cannot proceed without it).
            file_storage: Optional :class:`FileStorage` used by
                ``ArtifactService`` to compute SHA256 / size for file-kind
                artifacts. ``None`` is permitted (matches the legacy code
                path which falls back to caller-supplied digests).
        """
        from nexora_tasks_server.artefact_backends import resolve_backend
        self._service = ArtifactService(
            database=database,
            file_storage=file_storage,
            backend=resolve_backend(database, file_storage=file_storage),
        )

    async def create_artifact(self, artifact: "Artifact") -> "Artifact":
        """Persist the artifact via the wrapped :class:`ArtifactService`.

        Args:
            artifact: A populated :class:`Artifact` whose ``thread_id``,
                ``direction`` and ``created_at`` were already set by
                :meth:`TaskContext.publish_output_artifacts`.

        Returns:
            The persisted artifact (instance returned by
            :meth:`ArtifactService.create_artifact`).
        """
        return await self._service.create_artifact(artifact)
