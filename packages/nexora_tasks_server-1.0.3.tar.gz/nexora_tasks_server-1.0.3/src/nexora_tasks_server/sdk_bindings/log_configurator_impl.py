"""Concrete :class:`LogConfigurator` exposing the OTel structlog bridge.

This adapter converts the server's existing ``otel_bridge`` structlog
processor (defined in
:mod:`nexora_tasks_server.observability.structlog_otel`) into the SDK's
Protocol shape. The :class:`nexora_tasks_server.framework.NexoraTasks`
calls :func:`nexora_tasks.logging.set_log_configurator` exactly once at
process startup with an instance of this class so subsequent
``configure_logging`` invocations splice the OTel bridge into the structlog
pipeline.

Standalone SDK installs (no server runtime) never see this class; the
SDK falls back to a no-op processor list, closing the C-7 cycle.
"""

from __future__ import annotations

from typing import List

from nexora_tasks.protocols.log_configurator import StructlogProcessor
from nexora_tasks_server.observability.structlog_otel import otel_bridge


class OtelBridgeConfigurator:
    """Returns the server's OTel ``LogRecord`` bridge as a structlog processor.

    The bridge is a free function (not bound to any instance state) so the
    configurator is effectively a singleton — but each
    :class:`NexoraTasks` constructs its own to keep ownership explicit.
    """

    def build_processors(self) -> List[StructlogProcessor]:
        """Return the OTel bridge processor list (single processor)."""
        return [otel_bridge]
