"""Server-side implementations of SDK Protocols (C-7 cycle break).

This package provides concrete implementations of the abstractions declared
in :mod:`nexora_tasks.protocols`. The :class:`nexora_tasks_server.framework.NexoraTasks`
instantiates these and either:

* attaches them to itself (e.g. ``framework._artifact_publisher``) so the
  SDK's :class:`nexora_tasks.context.TaskContext` can resolve them without
  ever importing ``nexora_tasks_server``;
* registers them on a SDK module-level slot (e.g. via
  :func:`nexora_tasks.logging.set_log_configurator`).

Layering rule (enforced by tests/sdk-standalone CI job):
``packages/sdk-python/src/`` MUST NOT import ``nexora_tasks_server.*``.
``packages/server/src/`` is free to import ``nexora_tasks.*``.
"""

from nexora_tasks_server.sdk_bindings.artifact_publisher_impl import (
    ArtifactServicePublisher,
)
from nexora_tasks_server.sdk_bindings.log_configurator_impl import (
    OtelBridgeConfigurator,
)

__all__ = [
    "ArtifactServicePublisher",
    "OtelBridgeConfigurator",
]
