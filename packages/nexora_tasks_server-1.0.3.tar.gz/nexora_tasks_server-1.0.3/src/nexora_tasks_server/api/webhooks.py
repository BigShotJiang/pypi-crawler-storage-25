"""Webhook API endpoints."""

from typing import Any, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Response, status

from nexora_tasks_server.access_filter import AccessFilter
from nexora_tasks_server.dependencies import AuthenticatedRequest, get_authenticated_request, get_framework
from nexora_tasks.errors import WEBHOOK_INVALID_URL, WEBHOOK_NOT_FOUND, problem_json_dict
from nexora_tasks.logging import logger
from nexora_tasks_server.observability.metrics import api_requests_total
from nexora_tasks.models.webhook import (
    Webhook,
    WebhookCreateRequest,
    WebhookDelivery,
    WebhookDeliveryListResponse,
    WebhookListResponse,
    WebhookUpdateRequest,
)
from nexora_tasks_server.services.webhook_service import WebhookService

router = APIRouter(prefix="/webhooks", tags=["webhooks"])


def get_webhook_service(
    framework: "NexoraTasks" = Depends(get_framework),
) -> WebhookService:
    """Get WebhookService instance with dependencies from framework.

    Args:
        framework: NexoraTasks instance injected via FastAPI dependency

    Returns:
        WebhookService instance using storage-factory-backed repositories
    """
    return WebhookService(
        webhook_repository=framework.webhook_repository,
        delivery_repository=framework.webhook_delivery_repository,
    )


@router.post("", status_code=status.HTTP_201_CREATED, response_model=Webhook)
async def create_webhook(
    request: WebhookCreateRequest,
    x_environment: Optional[str] = Header(None, alias="X-Environment"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    webhook_service: WebhookService = Depends(get_webhook_service),
) -> Webhook:
    """Create a new webhook subscription.

    The webhook is scoped to an environment. Precedence for the effective
    env is: request body ``environment_id`` > ``X-Environment`` header >
    API-key binding. Non-admin callers may not target an env other than
    their bound one.

    Args:
        request: Webhook creation request
        x_environment: Optional environment header (used when body doesn't set one)
        auth: Authenticated request context
        webhook_service: WebhookService instance

    Returns:
        Created Webhook instance with generated secret

    Raises:
        HTTPException: 400 if validation fails or env mismatch
    """
    # ── Environment resolution (same pattern as POST /threads) ───────
    is_system_admin_key = auth.key_type == "admin" and auth.environment_id == "default"
    effective_env = request.environment_id or x_environment or auth.environment_id
    if (
        effective_env != auth.environment_id
        and auth.environment_id != "default"
        and not is_system_admin_key
    ):
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/webhooks", "http.status_code": "400"})
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=problem_json_dict(
                status_code=status.HTTP_400_BAD_REQUEST,
                title="Bad Request",
                detail=(
                    f"environment_id '{effective_env}' does not match the "
                    f"API key's bound environment '{auth.environment_id}'"
                ),
                code="ENVIRONMENT_MISMATCH",
            ),
        )

    try:
        # Determine created_by from auth context
        created_by = auth.user_id or auth.app_id

        webhook = await webhook_service.create_webhook(
            request,
            created_by=created_by,
            user_id=auth.user_id,
            app_id=auth.app_id,
            environment_id=effective_env,
        )

        # Log webhook creation
        logger.info(
            "webhook.created",
            webhook_id=webhook.id,
            url=webhook.url,
            enabled=webhook.enabled,
            created_by=created_by,
        )

        api_requests_total.add(1, {"http.method": "POST", "http.route": "/webhooks", "http.status_code": "201"})
        return webhook

    except ValueError as e:
        error_msg = str(e)
        if "url" in error_msg.lower():
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/webhooks", "http.status_code": "400"})
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=problem_json_dict(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    title="Bad Request",
                    detail=error_msg,
                    code=WEBHOOK_INVALID_URL,
                ),
            )
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/webhooks", "http.status_code": "400"})
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=problem_json_dict(
                status_code=status.HTTP_400_BAD_REQUEST,
                title="Bad Request",
                detail=error_msg,
                code="VALIDATION_FAILED",
            ),
        )


@router.get("", response_model=WebhookListResponse)
async def list_webhooks(
    is_enabled: Optional[bool] = Query(None, description="Filter by enabled status"),
    task_id: Optional[str] = Query(None, description="Filter by task ID"),
    task_version: Optional[str] = Query(None, description="Filter by task version"),
    source: Optional[str] = Query(None, description="Filter by webhook source (manual, thread, schedule)"),
    environment_id: Optional[str] = Query(
        None,
        description="Filter by environment_id. Falls back to X-Environment header / API key binding.",
    ),
    limit: Optional[int] = Query(None, ge=1, le=1000, description="Page size"),
    cursor: Optional[str] = Query(None, description="Pagination cursor"),
    offset: Optional[int] = Query(None, ge=0, description="Offset for pagination"),
    x_environment: Optional[str] = Header(None, alias="X-Environment"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    webhook_service: WebhookService = Depends(get_webhook_service),
) -> WebhookListResponse:
    """List webhooks with optional filtering.

    Environment filter precedence: query param > ``X-Environment`` header >
    API-key binding. Admin keys with none of the three see all envs.
    """
    logger.debug(
        "webhooks.list.env_resolved",
        query=environment_id,
        header=x_environment,
        key_binding=auth.environment_id,
        key_type=auth.key_type,
    )
    response = await webhook_service.list_webhooks(
        is_enabled=is_enabled,
        task_id=task_id,
        task_version=task_version,
        source=source,
        limit=limit,
        cursor=cursor,
        offset=offset,
    )

    # Apply access filtering — strip out webhooks the caller cannot see.
    # AccessFilter already honours auth.environment_id, which reflects the
    # X-Environment header and the key binding. To give admins an explicit
    # cross-env OR per-env override via the query param, we post-filter here.
    response.items = AccessFilter.filter_webhooks(response.items, auth)
    effective_env = environment_id or x_environment
    if effective_env and auth.key_type == "admin":
        response.items = [w for w in response.items if getattr(w, "environment_id", None) == effective_env]

    api_requests_total.add(1, {"http.method": "GET", "http.route": "/webhooks", "http.status_code": "200"})
    return response


@router.get("/{webhook_id}", response_model=Webhook)
async def get_webhook(
    webhook_id: str,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    webhook_service: WebhookService = Depends(get_webhook_service),
) -> Webhook:
    """Get webhook details by ID.

    Args:
        webhook_id: Webhook identifier
        auth: Authenticated request context
        webhook_service: WebhookService instance

    Returns:
        Webhook instance

    Raises:
        HTTPException: 404 if webhook not found
    """
    webhook = await webhook_service.get_webhook(webhook_id)

    if not webhook:
        api_requests_total.add(1, {"http.method": "GET", "http.route": "/webhooks/{webhook_id}", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Webhook {webhook_id} not found",
                code=WEBHOOK_NOT_FOUND,
            ),
        )

    AccessFilter.ensure_can_access_webhook(webhook, auth, webhook_id=webhook_id)

    api_requests_total.add(1, {"http.method": "GET", "http.route": "/webhooks/{webhook_id}", "http.status_code": "200"})
    return webhook


@router.patch("/{webhook_id}", response_model=Webhook)
async def update_webhook(
    webhook_id: str,
    request: WebhookUpdateRequest,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    webhook_service: WebhookService = Depends(get_webhook_service),
) -> Webhook:
    """Update webhook configuration (partial update).

    Args:
        webhook_id: Webhook identifier
        request: Webhook update request (partial)
        auth: Authenticated request context
        webhook_service: WebhookService instance

    Returns:
        Updated Webhook instance

    Raises:
        HTTPException: 400 if validation fails, 404 if webhook not found
    """
    # Pre-fetch and access-check before permitting the update.
    existing = await webhook_service.get_webhook(webhook_id)
    if not existing:
        api_requests_total.add(1, {"http.method": "PATCH", "http.route": "/webhooks/{webhook_id}", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Webhook {webhook_id} not found",
                code=WEBHOOK_NOT_FOUND,
            ),
        )
    AccessFilter.ensure_can_access_webhook(existing, auth, webhook_id=webhook_id)

    try:
        webhook = await webhook_service.update_webhook(webhook_id, request)

        api_requests_total.add(1, {"http.method": "PATCH", "http.route": "/webhooks/{webhook_id}", "http.status_code": "200"})
        return webhook

    except ValueError as e:
        error_msg = str(e)
        if "not found" in error_msg.lower():
            api_requests_total.add(1, {"http.method": "PATCH", "http.route": "/webhooks/{webhook_id}", "http.status_code": "404"})
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=problem_json_dict(
                    status_code=status.HTTP_404_NOT_FOUND,
                    title="Not Found",
                    detail=error_msg,
                    code=WEBHOOK_NOT_FOUND,
                ),
            )
        api_requests_total.add(1, {"http.method": "PATCH", "http.route": "/webhooks/{webhook_id}", "http.status_code": "400"})
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=problem_json_dict(
                status_code=status.HTTP_400_BAD_REQUEST,
                title="Bad Request",
                detail=error_msg,
                code=WEBHOOK_INVALID_URL if "url" in error_msg.lower() else "VALIDATION_FAILED",
            ),
        )


@router.delete("/{webhook_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_webhook(
    webhook_id: str,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    webhook_service: WebhookService = Depends(get_webhook_service),
) -> Response:
    """Delete webhook and stop all deliveries.

    Args:
        webhook_id: Webhook identifier
        auth: Authenticated request context
        webhook_service: WebhookService instance

    Returns:
        204 No Content

    Raises:
        HTTPException: 404 if webhook not found
    """
    # Access check before delete
    existing = await webhook_service.get_webhook(webhook_id)
    if not existing:
        api_requests_total.add(1, {"http.method": "DELETE", "http.route": "/webhooks/{webhook_id}", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Webhook {webhook_id} not found",
                code=WEBHOOK_NOT_FOUND,
            ),
        )
    AccessFilter.ensure_can_access_webhook(existing, auth, webhook_id=webhook_id)

    try:
        await webhook_service.delete_webhook(webhook_id)

        api_requests_total.add(1, {"http.method": "DELETE", "http.route": "/webhooks/{webhook_id}", "http.status_code": "204"})
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    except ValueError as e:
        error_msg = str(e)
        api_requests_total.add(1, {"http.method": "DELETE", "http.route": "/webhooks/{webhook_id}", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=error_msg,
                code=WEBHOOK_NOT_FOUND,
            ),
        )


@router.post("/{webhook_id}:regenerate-secret", response_model=Webhook)
async def regenerate_webhook_secret(
    webhook_id: str,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    webhook_service: WebhookService = Depends(get_webhook_service),
) -> Webhook:
    """Regenerate webhook secret.

    Args:
        webhook_id: Webhook identifier
        auth: Authenticated request context
        webhook_service: WebhookService instance

    Returns:
        Updated Webhook instance with new secret

    Raises:
        HTTPException: 404 if webhook not found
    """
    # Access check before allowing secret regeneration
    existing = await webhook_service.get_webhook(webhook_id)
    if not existing:
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/webhooks/{webhook_id}:regenerate-secret", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Webhook {webhook_id} not found",
                code=WEBHOOK_NOT_FOUND,
            ),
        )
    AccessFilter.ensure_can_access_webhook(existing, auth, webhook_id=webhook_id)

    try:
        webhook = await webhook_service.regenerate_secret(webhook_id)

        api_requests_total.add(1, {"http.method": "POST", "http.route": "/webhooks/{webhook_id}:regenerate-secret", "http.status_code": "200"})
        return webhook

    except ValueError as e:
        error_msg = str(e)
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/webhooks/{webhook_id}:regenerate-secret", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=error_msg,
                code=WEBHOOK_NOT_FOUND,
            ),
        )


@router.get("/{webhook_id}/deliveries", response_model=WebhookDeliveryListResponse)
async def list_webhook_deliveries(
    webhook_id: str,
    delivery_status: Optional[str] = Query(None, alias="status", description="Filter by delivery status"),
    thread_id: Optional[str] = Query(None, description="Filter by thread ID"),
    limit: Optional[int] = Query(None, ge=1, le=1000, description="Page size"),
    cursor: Optional[str] = Query(None, description="Pagination cursor"),
    offset: Optional[int] = Query(None, ge=0, description="Offset for pagination"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    webhook_service: WebhookService = Depends(get_webhook_service),
) -> WebhookDeliveryListResponse:
    """List delivery history for a webhook.

    Args:
        webhook_id: Webhook identifier
        status: Filter by delivery status ("success" | "failed")
        thread_id: Filter by thread ID
        limit: Page size (1-1000, default: 50)
        cursor: Pagination cursor
        offset: Offset for pagination (alternative to cursor)
        auth: Authenticated request context
        webhook_service: WebhookService instance

    Returns:
        WebhookDeliveryListResponse with paginated results
    """
    # Verify access to parent webhook before listing its deliveries
    parent_webhook = await webhook_service.get_webhook(webhook_id)
    if not parent_webhook:
        api_requests_total.add(1, {"http.method": "GET", "http.route": "/webhooks/{webhook_id}/deliveries", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Webhook {webhook_id} not found",
                code=WEBHOOK_NOT_FOUND,
            ),
        )
    AccessFilter.ensure_can_access_webhook(parent_webhook, auth, webhook_id=webhook_id)

    response = await webhook_service.list_deliveries(
        webhook_id=webhook_id,
        status=delivery_status,
        thread_id=thread_id,
        limit=limit,
        cursor=cursor,
        offset=offset,
    )

    api_requests_total.add(1, {"http.method": "GET", "http.route": "/webhooks/{webhook_id}/deliveries", "http.status_code": "200"})
    return response


@router.get("/{webhook_id}/deliveries/{delivery_id}", response_model=WebhookDelivery)
async def get_webhook_delivery(
    webhook_id: str,
    delivery_id: str,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    webhook_service: WebhookService = Depends(get_webhook_service),
) -> WebhookDelivery:
    """Get delivery details by ID.

    Args:
        webhook_id: Webhook identifier
        delivery_id: Delivery identifier
        auth: Authenticated request context
        webhook_service: WebhookService instance

    Returns:
        WebhookDelivery instance

    Raises:
        HTTPException: 404 if delivery not found
    """
    # Verify access to parent webhook before returning a delivery
    parent_webhook = await webhook_service.get_webhook(webhook_id)
    if not parent_webhook:
        api_requests_total.add(1, {"http.method": "GET", "http.route": "/webhooks/{webhook_id}/deliveries/{delivery_id}", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Webhook {webhook_id} not found",
                code=WEBHOOK_NOT_FOUND,
            ),
        )
    AccessFilter.ensure_can_access_webhook(parent_webhook, auth, webhook_id=webhook_id)

    delivery = await webhook_service.get_delivery(webhook_id, delivery_id)

    if not delivery:
        api_requests_total.add(1, {"http.method": "GET", "http.route": "/webhooks/{webhook_id}/deliveries/{delivery_id}", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Delivery {delivery_id} not found for webhook {webhook_id}",
                code="DELIVERY_NOT_FOUND",
            ),
        )

    api_requests_total.add(1, {"http.method": "GET", "http.route": "/webhooks/{webhook_id}/deliveries/{delivery_id}", "http.status_code": "200"})
    return delivery

