"""Schedule API endpoints for managing cron-based schedules."""

import os
from typing import Any, List, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query, status

from nexora_tasks_server.access_filter import AccessFilter
from nexora_tasks_server.dependencies import (
    AuthenticatedRequest,
    TaskContext,
    get_authenticated_request,
    get_framework,
    get_task_context,
    get_task_database,
)
from nexora_tasks.errors import (
    SCHEDULE_INVALID_CRON,
    SCHEDULE_INVALID_TIMEZONE,
    SCHEDULE_NOT_FOUND,
    problem_json_dict,
)
from nexora_tasks.logging import logger
from nexora_tasks_server.observability.metrics import api_requests_total
from nexora_tasks.models.schedule import Schedule, ScheduleCreateRequest, ScheduleUpdateRequest, ScheduleListResponse
from nexora_tasks_server.repositories.file_db import FileDatabase
from nexora_tasks_server.services.scheduler_service import ScheduleService

router = APIRouter(prefix="/schedules", tags=["schedules"])

# Keep strong refs to background fire-now tasks so the event loop doesn't
# garbage-collect them before they finish executing.
_FIRE_NOW_TASKS: set = set()


async def get_schedule_service(
    task_context: TaskContext = Depends(get_task_context),
    framework: Any = Depends(get_framework),
) -> ScheduleService:
    """Get ScheduleService instance with dependencies.
    
    Uses task-specific database in multi-task mode.
    
    Args:
        task_context: Resolved task context with optional TaskDefinition
        framework: NexoraTasks instance
        
    Returns:
        ScheduleService instance
    """
    # Get database (task-specific in multi-task mode)
    task_def = task_context.task_definition
    database = get_task_database(task_def, framework) 
    
    # Shared APScheduler wrapper (lazy singleton on ``NexoraTasks``).
    scheduler = framework.scheduler

    # Create run service
    from nexora_tasks_server.services.run_service import RunService
    from nexora_tasks_server.services.thread_service import ThreadService
    
    idempotency_store = framework.idempotency_store
    thread_service = ThreadService(
        database=database,
        idempotency_store=idempotency_store,
        execution_engine=framework.execution_engine,
        # M-10: pass through the framework's shared StorageFactory so DI
        # overrides apply to ad-hoc webhook repositories created here.
        storage_factory=framework.storage_factory,
    )
    
    run_service = RunService(
        database=database,
        thread_service=thread_service,
    )
    
    return ScheduleService(
        database=database,
        scheduler=scheduler,
        run_service=run_service,
        framework=framework,
        # M-10: pass the framework's shared StorageFactory so the schedule
        # service does not have to fall back to from_env() inside hot paths
        # (webhook creation, lock manager).
        storage_factory=framework.storage_factory,
    )


@router.post("", status_code=status.HTTP_201_CREATED, response_model=Schedule)
async def create_schedule(
    request: ScheduleCreateRequest,
    x_environment: Optional[str] = Header(None, alias="X-Environment"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    schedule_service: ScheduleService = Depends(get_schedule_service),
    task_context: TaskContext = Depends(get_task_context),
) -> Schedule:
    """Create a new schedule.
    
    Args:
        request: Schedule creation request
        auth: Authenticated request context
        schedule_service: ScheduleService instance
        task_context: Task context for auto-populating task_id/version
        
    Returns:
        Created Schedule instance
        
    Raises:
        HTTPException: 400 if validation fails
    """
    try:
        # Auto-populate task_id and task_version from task context if not provided
        # This ensures threads created from this schedule will have task metadata
        if task_context.task_definition:
            if not request.task_id:
                request.task_id = task_context.task_definition.task_id
            if not request.task_version:
                request.task_version = task_context.task_definition.version

        # ── Environment resolution ────────────────────────────────────
        # Precedence: request body > X-Environment > API key binding.
        is_system_admin_key = auth.key_type == "admin" and auth.environment_id == "default"
        effective_env = request.environment_id or x_environment or auth.environment_id
        if (
            effective_env != auth.environment_id
            and auth.environment_id != "default"
            and not is_system_admin_key
        ):
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/schedules", "http.status_code": "400"})
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=problem_json_dict(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    title="Bad Request",
                    detail=(
                        f"environment_id '{effective_env}' does not match the "
                        f"API key's bound environment '{auth.environment_id}'"
                    ),
                    code="ENVIRONMENT_MISMATCH",
                ),
            )
        request.environment_id = effective_env

        # Stamp ownership metadata for access control.
        request.metadata = dict(request.metadata or {})
        if auth.user_id:
            request.metadata["user_id"] = auth.user_id
        if auth.app_id:
            request.metadata["app_id"] = auth.app_id
        request.metadata["environment_id"] = effective_env

        schedule = await schedule_service.create_schedule(request)
        
        # Metrics
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/schedules", "http.status_code": "201"})
        
        return schedule
    except ValueError as e:
        error_msg = str(e)
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/schedules", "http.status_code": "400"})
        
        # Determine error code
        if "cron" in error_msg.lower():
            code = SCHEDULE_INVALID_CRON
        elif "timezone" in error_msg.lower():
            code = SCHEDULE_INVALID_TIMEZONE
        else:
            code = "SCHEDULE_VALIDATION_ERROR"
        
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=problem_json_dict(
                status_code=status.HTTP_400_BAD_REQUEST,
                title="Bad Request",
                detail=error_msg,
                code=code,
            ),
        )


@router.get("", response_model=ScheduleListResponse)
async def list_schedules(
    state: Optional[str] = Query(None, description="Filter by schedule state"),
    task_id: Optional[str] = Query(None, description="Filter by task definition ID"),
    task_version: Optional[str] = Query(None, description="Filter by task version"),
    environment_id: Optional[str] = Query(
        None,
        description="Filter by environment_id. Falls back to X-Environment header / key binding.",
    ),
    limit: Optional[int] = Query(50, ge=1, le=1000, description="Maximum number of results"),
    cursor: Optional[str] = Query(None, description="Cursor for pagination"),
    offset: Optional[int] = Query(None, ge=0, description="Offset for pagination"),
    x_environment: Optional[str] = Header(None, alias="X-Environment"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> ScheduleListResponse:
    """List schedules with filtering and pagination.
    
    Args:
        state: Filter by schedule state
        task_id: Filter by task definition ID
        task_version: Filter by task version
        limit: Maximum number of results
        cursor: Cursor for pagination
        offset: Offset for pagination (alternative to cursor)
        auth: Authenticated request context
        framework: NexoraTasks instance
        
    Returns:
        ScheduleListResponse with paginated results
    """
    logger.debug(
        "schedules.list.env_resolved",
        query=environment_id,
        header=x_environment,
        key_binding=auth.environment_id,
        key_type=auth.key_type,
    )
    filters: dict[str, Any] = {}
    if state is not None:
        filters["state"] = state
    if task_id is not None:
        filters["task_id"] = task_id
    if task_version is not None:
        filters["task_version"] = task_version
    if limit is not None:
        filters["limit"] = limit
    if cursor is not None:
        filters["cursor"] = cursor
    if offset is not None:
        filters["offset"] = offset
    
    # Use framework database directly to list schedules across all tasks
    database = framework.database 
    
    # Query schedules using the database
    from nexora_tasks_server.services.scheduler_service import ScheduleService
    from nexora_tasks_server.services.run_service import RunService
    from nexora_tasks_server.services.thread_service import ThreadService
    
    idempotency_store = framework.idempotency_store
    thread_service = ThreadService(
        database=database,
        idempotency_store=idempotency_store,
        execution_engine=framework.execution_engine,
        # M-10: pass through the framework's shared StorageFactory so DI
        # overrides apply to ad-hoc webhook repositories created here.
        storage_factory=framework.storage_factory,
    )
    run_service = RunService(
        database=database,
        thread_service=thread_service,
    )
    
    schedule_service = ScheduleService(
        database=database,
        scheduler=framework.scheduler,
        run_service=run_service,
        framework=None,  # Not needed for listing
    )
    
    response = await schedule_service.list_schedules(filters)

    # Apply access filtering based on metadata
    response.items = AccessFilter.filter_resources(response.items, auth)

    # Additional env filter: admin keys can slice cross-env lists via query/header.
    effective_env = environment_id or x_environment
    if effective_env and auth.key_type == "admin":
        filtered: List[Schedule] = []
        for s in response.items:
            s_env = (
                getattr(s, "environment_id", None)
                or (s.metadata or {}).get("environment_id")
                or "default"
            )
            if s_env == effective_env:
                filtered.append(s)
        response.items = filtered

    # Metrics
    api_requests_total.add(1, {"http.method": "GET", "http.route": "/schedules", "http.status_code": "200"})

    return response


@router.get("/{schedule_id}", response_model=Schedule)
async def get_schedule(
    schedule_id: str,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> Schedule:
    """Get schedule by ID.
    
    Args:
        schedule_id: Schedule identifier
        auth: Authenticated request context
        framework: NexoraTasks instance
        
    Returns:
        Schedule instance
        
    Raises:
        HTTPException: 404 if schedule not found
    """
    # Use framework database directly
    database = framework.database 
    schedule = await database.get_schedule(schedule_id)
    
    if not schedule:
        api_requests_total.add(1, {"http.method": "GET", "http.route": "/schedules/{schedule_id}", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Schedule Not Found",
                detail=f"Schedule {schedule_id} not found",
                code=SCHEDULE_NOT_FOUND,
            ),
        )

    AccessFilter.ensure_can_access(schedule, auth, "Schedule", schedule_id)

    # Metrics
    api_requests_total.add(1, {"http.method": "GET", "http.route": "/schedules/{schedule_id}", "http.status_code": "200"})

    return schedule


@router.patch("/{schedule_id}", response_model=Schedule)
async def update_schedule(
    schedule_id: str,
    request: ScheduleUpdateRequest,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> Schedule:
    """Update a schedule.
    
    Args:
        schedule_id: Schedule identifier
        request: Schedule update request
        auth: Authenticated request context
        framework: NexoraTasks instance
        
    Returns:
        Updated Schedule instance
        
    Raises:
        HTTPException: 400 if validation fails, 404 if schedule not found
    """
    # Use framework database directly
    database = framework.database 
    
    # Create schedule service
    from nexora_tasks_server.services.run_service import RunService
    from nexora_tasks_server.services.thread_service import ThreadService
    
    idempotency_store = framework.idempotency_store
    thread_service = ThreadService(
        database=database,
        idempotency_store=idempotency_store,
        execution_engine=framework.execution_engine,
        # M-10: pass through the framework's shared StorageFactory so DI
        # overrides apply to ad-hoc webhook repositories created here.
        storage_factory=framework.storage_factory,
    )
    run_service = RunService(
        database=database,
        thread_service=thread_service,
    )
    schedule_service = ScheduleService(
        database=database,
        scheduler=framework.scheduler,
        run_service=run_service,
        framework=None,
        storage_factory=framework.storage_factory,
    )
    
    # Pre-fetch and access-check before allowing the update.
    existing = await schedule_service.get_schedule(schedule_id)
    if not existing:
        api_requests_total.add(1, {"http.method": "PATCH", "http.route": "/schedules/{schedule_id}", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Schedule Not Found",
                detail=f"Schedule {schedule_id} not found",
                code=SCHEDULE_NOT_FOUND,
            ),
        )
    AccessFilter.ensure_can_access(existing, auth, "Schedule", schedule_id)

    try:
        schedule = await schedule_service.update_schedule(schedule_id, request)
        
        # Metrics
        api_requests_total.add(1, {"http.method": "PATCH", "http.route": "/schedules/{schedule_id}", "http.status_code": "200"})
        
        return schedule
    except ValueError as e:
        error_msg = str(e)
        
        if "not found" in error_msg.lower():
            api_requests_total.add(1, {"http.method": "PATCH", "http.route": "/schedules/{schedule_id}", "http.status_code": "404"})
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=problem_json_dict(
                    status_code=status.HTTP_404_NOT_FOUND,
                    title="Schedule Not Found",
                    detail=error_msg,
                    code=SCHEDULE_NOT_FOUND,
                ),
            )
        
        # Determine error code
        if "cron" in error_msg.lower():
            code = SCHEDULE_INVALID_CRON
        elif "timezone" in error_msg.lower():
            code = SCHEDULE_INVALID_TIMEZONE
        else:
            code = "SCHEDULE_VALIDATION_ERROR"
        
        api_requests_total.add(1, {"http.method": "PATCH", "http.route": "/schedules/{schedule_id}", "http.status_code": "400"})
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=problem_json_dict(
                status_code=status.HTTP_400_BAD_REQUEST,
                title="Bad Request",
                detail=error_msg,
                code=code,
            ),
        )


@router.post("/{schedule_id}:cancel", response_model=Schedule)
async def cancel_schedule(
    schedule_id: str,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> Schedule:
    """Cancel a schedule permanently.
    
    Args:
        schedule_id: Schedule identifier
        auth: Authenticated request context
        framework: NexoraTasks instance
        
    Returns:
        Canceled Schedule instance
        
    Raises:
        HTTPException: 404 if schedule not found
    """
    # Use framework database directly
    database = framework.database 
    
    # Create schedule service
    from nexora_tasks_server.services.run_service import RunService
    from nexora_tasks_server.services.thread_service import ThreadService
    
    idempotency_store = framework.idempotency_store
    thread_service = ThreadService(
        database=database,
        idempotency_store=idempotency_store,
        execution_engine=framework.execution_engine,
        # M-10: pass through the framework's shared StorageFactory so DI
        # overrides apply to ad-hoc webhook repositories created here.
        storage_factory=framework.storage_factory,
    )
    run_service = RunService(
        database=database,
        thread_service=thread_service,
    )
    schedule_service = ScheduleService(
        database=database,
        scheduler=framework.scheduler,
        run_service=run_service,
        framework=None,
        storage_factory=framework.storage_factory,
    )
    
    # Pre-fetch and access-check before allowing the cancel.
    existing = await schedule_service.get_schedule(schedule_id)
    if not existing:
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/schedules/{schedule_id}:cancel", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Schedule Not Found",
                detail=f"Schedule {schedule_id} not found",
                code=SCHEDULE_NOT_FOUND,
            ),
        )
    AccessFilter.ensure_can_access(existing, auth, "Schedule", schedule_id)

    try:
        schedule = await schedule_service.cancel_schedule(schedule_id)
        
        # Metrics
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/schedules/{schedule_id}:cancel", "http.status_code": "200"})
        
        return schedule
    except ValueError as e:
        error_msg = str(e)
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/schedules/{schedule_id}:cancel", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Schedule Not Found",
                detail=error_msg,
                code=SCHEDULE_NOT_FOUND,
            ),
        )


@router.post("/{schedule_id}:fire-now")
async def fire_schedule_now(
    schedule_id: str,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> dict:
    """Test-only endpoint that fires a schedule's tick callback immediately,
    bypassing the cron wait. Returns ``{"fired": true, "schedule_id": ...}``.

    Gated by ``TASK_FRAMEWORK_TEST_ENDPOINTS=1``. When the env var is unset
    the route returns 404 — the same response a non-existent endpoint would
    produce — so callers cannot fingerprint the gate.

    Why this exists:
      Real cron firing is minute-granular. End-to-end tests that need to
      assert "schedule → real worker → thread → observability" cannot afford
      a 60-second wait per scenario. This endpoint invokes the same
      ``trigger_run`` callback the APScheduler tick would have invoked.
    """
    if os.getenv("TASK_FRAMEWORK_TEST_ENDPOINTS") != "1":
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)

    database = framework.database

    from nexora_tasks_server.services.run_service import RunService
    from nexora_tasks_server.services.thread_service import ThreadService

    idempotency_store = framework.idempotency_store
    thread_service = ThreadService(
        database=database,
        idempotency_store=idempotency_store,
        execution_engine=framework.execution_engine,
        # M-10: pass through the framework's shared StorageFactory so DI
        # overrides apply to ad-hoc webhook repositories created here.
        storage_factory=framework.storage_factory,
    )
    run_service = RunService(database=database, thread_service=thread_service)
    schedule_service = ScheduleService(
        database=database,
        scheduler=framework.scheduler,
        run_service=run_service,
        framework=framework,
        storage_factory=framework.storage_factory,
    )

    existing = await schedule_service.get_schedule(schedule_id)
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Schedule Not Found",
                detail=f"Schedule {schedule_id} not found",
                code=SCHEDULE_NOT_FOUND,
            ),
        )
    AccessFilter.ensure_can_access(existing, auth, "Schedule", schedule_id)

    job = framework.scheduler.get_job(schedule_id) if framework.scheduler else None
    if job is None:
        # Schedule exists in the database but is not currently registered with
        # APScheduler — likely paused or cancelled. Re-register transiently to
        # build the trigger_run callback, but only if it's ACTIVE; otherwise
        # the test is asserting noop semantics, mirror cron's silent skip.
        from nexora_tasks.models.schedule import ScheduleState
        if existing.state != ScheduleState.ACTIVE:
            return {"fired": False, "schedule_id": schedule_id, "reason": "not_active"}
        await schedule_service._add_schedule_to_scheduler(existing)
        job = framework.scheduler.get_job(schedule_id)
        if job is None:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Schedule is active but no APScheduler job is registered",
            )

    # APScheduler Job exposes the registered callable on `.func`. Match the
    # real cron tick semantics: APScheduler runs the callback in its own
    # executor and never awaits the user task to completion before scheduling
    # the next tick. We do the same with create_task so fire-now returns
    # immediately, otherwise a slow task (e.g. sleep 30s) blocks the HTTP
    # request past the client's timeout and breaks D06/D07-style tests that
    # expect to poll run state while the task is still running.
    import asyncio  # noqa: PLC0415
    from datetime import datetime, timezone  # noqa: PLC0415

    callback = job.func

    # D09: Synchronously acquire the same per-tick lock the cron callback
    # would acquire, so the HTTP response can report whether THIS server
    # won the race. Without this, two servers fire-now the same tick and
    # both return fired=True even though only one actually creates the run.
    # File-storage mode (lock_manager is None) reports fired=True
    # unconditionally — single-process, no race to lose.
    lock_acquired = True
    fire_now_acquired = False
    lock_manager = None
    try:
        lock_manager = framework.storage_factory.lock_manager
    except Exception:
        lock_manager = None

    if lock_manager is not None:
        tick_ts = datetime.now(timezone.utc).replace(microsecond=0)
        lock_key = f"schedule:{schedule_id}:{tick_ts.isoformat()}"
        try:
            lock_acquired = await lock_manager.acquire(
                lock_key, ttl_seconds=60, wait=False
            )
        except Exception as exc:
            logger.warning(
                "fire_now.lock_acquire_failed",
                schedule_id=schedule_id,
                error=str(exc),
            )
            lock_acquired = False
        fire_now_acquired = lock_acquired

    if not lock_acquired:
        return {
            "fired": False,
            "schedule_id": schedule_id,
            "reason": "lock_lost",
        }

    async def _fire_and_log() -> None:
        try:
            await callback(_fire_now_acquired_lock=fire_now_acquired)
        except Exception as e:  # pragma: no cover - background logging only
            logger.error(
                "fire_now.callback_failed",
                schedule_id=schedule_id,
                error=str(e),
                exc_info=True,
            )

    task = asyncio.create_task(_fire_and_log())
    _FIRE_NOW_TASKS.add(task)
    task.add_done_callback(_FIRE_NOW_TASKS.discard)

    return {"fired": True, "schedule_id": schedule_id}

