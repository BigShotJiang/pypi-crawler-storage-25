"""Thread management API endpoints.

Provides endpoints for creating, listing, and managing thread executions.
A thread represents a single execution of a task with inputs, outputs, and state.

In multi-task mode, use the `task_id` and `version` query parameters to specify
which task to execute. If only one task is registered, these parameters are optional.

For POST /threads (create), the task_id/version determine which task function to run.
For GET/POST operations on existing threads, the task_id helps locate the thread faster
when multiple task databases exist.
"""

import asyncio
from typing import Any, Optional, Tuple

from fastapi import APIRouter, Depends, Header, HTTPException, Query, status

from nexora_tasks_server.dependencies import (
    AuthenticatedRequest,
    TaskContext,
    get_authenticated_request,
    get_framework,
    get_task_context,
    get_task_database,
    get_task_file_storage,
    get_task_function,
)
from nexora_tasks.errors import (
    THREAD_INVALID_STATE,
    THREAD_NOT_FOUND,
    VALIDATION_FAILED,
    problem_json_dict,
)
from nexora_tasks.logging import logger
from nexora_tasks_server.observability.metrics import api_requests_total
from nexora_tasks.models.artifact_schema import ArtifactSchema, validate_artifact_against_schema, validate_artifact_against_schemas
from nexora_tasks.models.thread import Thread
from nexora_tasks.models.thread_create_request import ThreadCreateRequest
from nexora_tasks.models.thread_list_response import ThreadListResponse
from nexora_tasks.models.thread_query_filters import ThreadQueryFilters
from nexora_tasks.models.thread_retry_request import ThreadRetryRequest
from nexora_tasks_server.repositories.file_db import FileDatabase

from nexora_tasks_server.services.thread_service import ThreadService

router = APIRouter(prefix="/threads", tags=["threads"])


def get_thread_service(
    task_context: TaskContext = Depends(get_task_context),
    framework: Any = Depends(get_framework),
) -> ThreadService:
    """Get ThreadService instance with dependencies.
    
    Uses task-specific database in multi-task mode, or framework database in single-task mode.
    
    Args:
        task_context: Resolved task context with optional TaskDefinition
        framework: NexoraTasks instance
        
    Returns:
        ThreadService instance
    """
    # Get database from framework (uses StorageFactory - either ES or file-based)
    # The framework.database property lazily creates the appropriate database
    task_def = task_context.task_definition
    database = get_task_database(task_def, framework)
    
    # Fall back to framework.database if get_task_database returns None
    # This ensures we always use the configured storage backend
    if database is None:
        database = framework.database
    
    # Debug logging to trace database type
    logger.info(
        "threads.get_thread_service.database",
        database_type=type(database).__name__ if database else "None",
        has_database=database is not None,
    )
    
    idempotency_store = framework.idempotency_store

    # Get execution engine from the framework
    execution_engine = framework.execution_engine

    return ThreadService(
        database=database,
        idempotency_store=idempotency_store,
        execution_engine=execution_engine,
        concurrency_manager=getattr(framework, "concurrency_manager", None),
        # M-10: route ad-hoc webhook repository creation through the framework's
        # shared StorageFactory so DI / test overrides are honoured (no env
        # re-read in the create-thread path).
        storage_factory=framework.storage_factory,
    )


async def _find_thread_across_databases(
    thread_id: str,
    framework: Any,
    user_id: Optional[str],
    app_id: Optional[str],
    is_admin: bool,
    environment_id: str = "default",
    is_system_admin: bool = False,
) -> Tuple[Optional[Any], Optional[ThreadService]]:
    """Fan-out lookup across all task databases in parallel (perf-H-4).

    Instead of the previous O(T×V) sequential loop that opened one database
    at a time, this function fires all get_thread() coroutines concurrently
    via asyncio.gather and returns the first non-None result.

    Args:
        thread_id: Thread identifier to find
        framework: NexoraTasks instance
        user_id: Requesting user ID (for access checks)
        app_id: Requesting app ID (for access checks)
        is_admin: Whether the request has admin privileges
        environment_id: Current environment
        is_system_admin: Whether this is a cross-environment admin

    Returns:
        (thread, thread_service) tuple — both None if not found.
    """
    task_defs = list(framework.task_registry.list_all())

    # Build (task_def, database, service) tuples (filter out missing dbs).
    candidates = []
    for task_def in task_defs:
        db = get_task_database(task_def, framework)
        if db:
            svc = ThreadService(
                database=db,
                idempotency_store=framework.idempotency_store,
                execution_engine=framework.execution_engine,
            )
            candidates.append(svc)

    # Add the shared framework database if present (covers orphaned threads).
    if framework.database:
        candidates.append(
            ThreadService(
                database=framework.database,
                idempotency_store=framework.idempotency_store,
                execution_engine=framework.execution_engine,
            )
        )

    if not candidates:
        return None, None

    async def _try(svc: ThreadService) -> Optional[Any]:
        try:
            return await svc.get_thread(
                thread_id=thread_id,
                user_id=user_id,
                app_id=app_id,
                is_admin=is_admin,
                environment_id=environment_id,
                is_system_admin=is_system_admin,
            )
        except Exception:
            return None

    results = await asyncio.gather(*(_try(s) for s in candidates))
    for svc, result in zip(candidates, results):
        if result is not None:
            return result, svc
    return None, None


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_thread(
    request: ThreadCreateRequest,
    allow_unactivated: bool = Query(
        False,
        description=(
            "Bypass the activation gate. Only system-level admin keys may use this. "
            "Intended for debugging unactivated versions; the UI never sets it."
        ),
    ),
    x_environment: str | None = Header(None, alias="X-Environment"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    task_context: TaskContext = Depends(get_task_context),
    thread_service: ThreadService = Depends(get_thread_service),
    framework: Any = Depends(get_framework),
):
    """Create and execute a thread.
    
    Creates a new thread to execute a task with the provided inputs. The thread will
    be executed synchronously (waiting for completion) or asynchronously (returning 
    immediately) based on the `mode` field in the request body.
    
    **Multi-Task Mode**: When multiple tasks are registered, you must specify:
    - `task_id` (query param): Required to identify which task to execute
    - `version` (query param): Optional, defaults to latest version
    
    **Single-Task Mode**: When only one task is registered, `task_id` is optional.
    
    Args:
        request: Thread creation request with inputs, mode, and optional params
        auth: Authenticated request context with user_id/app_id
        task_context: Resolved task context with TaskDefinition
        thread_service: ThreadService instance
        framework: NexoraTasks instance
        
    Returns:
        - 201 Created: Sync mode - Thread executed and completed
        - 202 Accepted: Async mode - Thread queued for execution
        
    Raises:
        HTTPException: 
            - 400 Bad Request: Validation error or task_id required but not provided
            - 409 Conflict: Idempotency key already used
            - 503 Service Unavailable: Task function not registered
    """
    # Get task function from task definition (multi-task) or framework (single-task)
    task_def = task_context.task_definition
    task_function = await get_task_function(task_def, framework)
    
    # Python tasks must have a registered function in memory.
    # Other runtimes (node, etc.) execute via sub-process runner and don't need a python function.
    runtime = getattr(task_def, "runtime", "python") if task_def else "python"
    
    if runtime == "python" and not task_function:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=problem_json_dict(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                title="Service Unavailable",
                detail="Task function not registered",
            ),
        )

    # Get input schemas from task definition (multi-task) or framework (single-task)
    input_schemas = []
    if task_def:
        # Convert dict schemas to ArtifactSchema objects
        input_schemas = [
            ArtifactSchema.model_validate(s) if isinstance(s, dict) else s
            for s in task_def.input_schemas
        ]
    else:
        # Fallback to framework schemas
        input_schemas = getattr(framework, "input_schemas", None) or []
        if not input_schemas:
            # Fallback to singular for backward compatibility
            input_schema_singular = getattr(framework, "input_schema", None)
            input_schemas = [input_schema_singular] if input_schema_singular is not None else []
    
    if input_schemas:
        # Validate each input artifact dict (use model_dump to get dicts if needed)
        try:
            for art in request.inputs:
                # Convert Pydantic Artifact to dict when necessary
                art_dict = art.model_dump() if hasattr(art, "model_dump") else dict(art)
                validate_artifact_against_schemas(art_dict, input_schemas)
        except ValueError as validation_error:
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads", "http.status_code": "400"})
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=problem_json_dict(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    title="Bad Request",
                    detail=f"Input artifact validation failed: {str(validation_error)}",
                    code=VALIDATION_FAILED,
                ),
            )

    # ── Environment resolution ────────────────────────────────────────
    # Precedence: request body > X-Environment header > auth (key binding).
    # We also guard against callers asking for an env they're not allowed to
    # target, so the body can only disagree with the binding for system admins.
    is_system_admin_key = auth.key_type == "admin" and auth.environment_id == "default"
    if request.environment_id:
        effective_env = request.environment_id
    elif x_environment:
        effective_env = x_environment
    else:
        effective_env = auth.environment_id

    if (
        effective_env != auth.environment_id
        and auth.environment_id != "default"
        and not is_system_admin_key
    ):
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads", "http.status_code": "400"})
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=problem_json_dict(
                status_code=status.HTTP_400_BAD_REQUEST,
                title="Bad Request",
                detail=(
                    f"environment_id '{effective_env}' does not match the "
                    f"API key's bound environment '{auth.environment_id}'"
                ),
                code="ENVIRONMENT_MISMATCH",
            ),
        )

    # ── Activation gate ───────────────────────────────────────────────
    # Named environments (anything other than "default") always enforce the
    # activation gate — a task with no active version in that env is blocked.
    # The "default" env stays permissive when it has no activations at all,
    # preserving backward compat for single-task / legacy setups that never
    # set up per-env activation. System admins may bypass via
    # ?allow_unactivated=true.
    if task_def and effective_env:
        env_registry = getattr(framework, "environment_registry", None)
        if env_registry is not None:
            env_activations = await env_registry.list_activations(effective_env)
            gate_active = effective_env != "default" or bool(env_activations)
            if gate_active:
                active_version = await env_registry.get_active_version(
                    effective_env, task_def.task_id
                )
                # When caller omits version, default to the env-active version
                # rather than the registry's "latest deployed". Latest can diverge
                # from active after rollback or staged promotion.
                if task_context.version is None and active_version:
                    if active_version != task_def.version:
                        resolved_active = framework.get_task(
                            task_def.task_id, active_version
                        )
                        if resolved_active is not None:
                            task_def = resolved_active
                            task_function = await get_task_function(task_def, framework)
                requested_version = task_context.version or task_def.version
                if active_version != requested_version:
                    if not (allow_unactivated and is_system_admin_key):
                        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads", "http.status_code": "409"})
                        raise HTTPException(
                            status_code=status.HTTP_409_CONFLICT,
                            detail=problem_json_dict(
                                status_code=status.HTTP_409_CONFLICT,
                                title="Conflict",
                                detail=(
                                    f"Task '{task_def.task_id}' version "
                                    f"'{requested_version}' is not activated in "
                                    f"environment '{effective_env}'"
                                    + (
                                        f" (active: '{active_version}')"
                                        if active_version
                                        else " (no active version)"
                                    )
                                    + ". Activate it on the Environment page first, "
                                    "or pick a different version."
                                ),
                                code="TASK_NOT_ACTIVATED_IN_ENV",
                            ),
                        )

    try:
        thread = await thread_service.create_thread(
            request=request,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
            task_function=task_function,
            task_definition=task_def,
            requested_version=task_context.version,  # Pass the requested version
            environment_id=effective_env,
        )

        # Group J: stamp thread.id + task.id on the server span so the
        # groupbyattrs Collector processor lifts them to resource attributes
        # (lets trace queries by resource.attributes.thread.id find this
        # span, including in async mode where no per-request obs context
        # wraps the handler).
        try:
            from opentelemetry import trace as _otel_trace

            _span = _otel_trace.get_current_span()
            if _span is not None and _span.is_recording():
                _span.set_attribute("thread.id", str(thread.id))
                _span.set_attribute("task.id", str(task_context.task_id))
        except Exception:
            pass

        # Log thread creation
        logger.info(
            "thread.created",
            thread_id=thread.id,
            mode=request.mode,
            user_id=auth.user_id,
            app_id=auth.app_id,
            state=str(thread.state),
            task_id=task_context.task_id,
            task_version=task_context.version,
        )

        # For async mode, return 202 Accepted
        if request.mode == "async":
            import json

            from fastapi.responses import JSONResponse

            api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads", "http.status_code": "202"})
            return JSONResponse(
                status_code=status.HTTP_202_ACCEPTED,
                content=json.loads(thread.model_dump_json(exclude_none=True)),
            )

        # For sync mode, return 201 Created
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads", "http.status_code": "201"})
        return thread
    except ValueError as e:
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads", "http.status_code": "400"})
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=problem_json_dict(
                status_code=status.HTTP_400_BAD_REQUEST,
                title="Bad Request",
                detail=str(e),
                code=VALIDATION_FAILED,
            ),
        )


@router.get("", response_model=ThreadListResponse)
async def list_threads(
    state: str | None = Query(None, description="Filter by thread state"),
    name: str | None = Query(None, description="Filter by thread name (exact match or prefix with * suffix)"),
    user_id: str | None = Query(None, description="Filter by user_id"),
    app_id: str | None = Query(None, description="Filter by app_id"),
    schedule_id: str | None = Query(None, description="Filter by schedule_id"),
    run_id: str | None = Query(None, description="Filter by run_id"),
    task_id: str | None = Query(None, description="Filter by task_id"),
    task_version: str | None = Query(None, description="Filter by task_version"),
    worker_full_id: str | None = Query(
        None,
        description="Filter by dedicated worker slot (metadata.worker_full_id, e.g. my_task:1.0.0). Prefix with * for prefix match",
    ),
    environment_id: str | None = Query(
        None,
        description="Filter by environment_id. If omitted, falls back to the X-Environment header / API key binding.",
    ),
    created_after: str | None = Query(None, description="Filter threads created after (ISO 8601 UTC)"),
    created_before: str | None = Query(None, description="Filter threads created before (ISO 8601 UTC)"),
    started_after: str | None = Query(None, description="Filter threads started after (ISO 8601 UTC)"),
    finished_before: str | None = Query(None, description="Filter threads finished before (ISO 8601 UTC)"),
    limit: int | None = Query(50, ge=1, le=1000, description="Maximum number of results"),
    cursor: str | None = Query(None, description="Cursor for pagination"),
    offset: int | None = Query(None, ge=0, description="Offset for pagination"),
    x_environment: str | None = Header(None, alias="X-Environment"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> ThreadListResponse:
    """List threads with filtering and pagination.

    In multi-task mode, aggregates threads from all task databases unless task_id is specified.

    Environment filter precedence (first non-empty wins): ``environment_id`` query param,
    ``X-Environment`` header, API-key binding. Admin keys with none of the three see all
    environments.

    Args:
        state: Filter by thread state
        user_id: Filter by user_id
        app_id: Filter by app_id
        schedule_id: Filter by schedule_id
        run_id: Filter by run_id
        task_id: Filter by task_id (limits search to specific task)
        task_version: Filter by task_version
        worker_full_id: Filter by worker subprocess slot (task_id:version in metadata)
        environment_id: Filter by environment_id (overrides X-Environment header and key binding)
        created_after: Filter threads created after
        created_before: Filter threads created before
        started_after: Filter threads started after
        finished_before: Filter threads finished before
        limit: Maximum number of results
        cursor: Cursor for pagination
        offset: Offset for pagination
        x_environment: Optional ``X-Environment`` header (used when the query param is not set)
        auth: Authenticated request context
        framework: NexoraTasks instance

    Returns:
        ThreadListResponse with paginated results
    """
    from datetime import datetime
    from nexora_tasks.models.pagination import Pagination

    # Resolve effective environment filter.
    # Precedence: explicit query param > X-Environment header > API-key binding (for non-admin keys).
    # Admin keys with no explicit env filter see all environments.
    effective_environment_id: str | None
    if environment_id:
        effective_environment_id = environment_id
    elif x_environment:
        effective_environment_id = x_environment
    elif auth.key_type != "admin":
        effective_environment_id = auth.environment_id
    else:
        effective_environment_id = None

    logger.debug(
        "threads.list.env_resolved",
        query=environment_id,
        header=x_environment,
        key_binding=auth.environment_id,
        key_type=auth.key_type,
        effective=effective_environment_id,
    )

    # Parse datetime strings
    filters = ThreadQueryFilters(
        state=state,
        name=name,
        user_id=user_id,
        app_id=app_id,
        schedule_id=schedule_id,
        run_id=run_id,
        task_id=task_id,
        task_version=task_version,
        worker_full_id=worker_full_id,
        environment_id=effective_environment_id,
        created_after=datetime.fromisoformat(created_after.replace("Z", "+00:00")) if created_after else None,
        created_before=datetime.fromisoformat(created_before.replace("Z", "+00:00")) if created_before else None,
        started_after=datetime.fromisoformat(started_after.replace("Z", "+00:00")) if started_after else None,
        finished_before=datetime.fromisoformat(finished_before.replace("Z", "+00:00")) if finished_before else None,
        limit=limit,
        cursor=cursor,
        offset=offset,
    )

    all_threads = []

    # Whether this request is allowed to see across environments.
    # Only admin keys with no explicit env filter get the cross-env view.
    cross_env_admin = (auth.key_type == "admin") and effective_environment_id is None

    # If task_id is provided, search in that specific task's database(s)
    if task_id:
        # If version is also provided, search only that version
        if task_version:
            task_def = framework.get_task(task_id, task_version)
            if task_def:
                database = get_task_database(task_def, framework)
                if database:
                    thread_service = ThreadService(
                        database=database,
                        idempotency_store=framework.idempotency_store,
                        execution_engine=framework.execution_engine,
                    )
                    response = await thread_service.list_threads(
                        filters=filters,
                        user_id=auth.user_id,
                        app_id=auth.app_id,
                        is_admin=auth.key_type == "admin",
                        environment_id=effective_environment_id,
                        is_system_admin=cross_env_admin,
                    )
                    api_requests_total.add(1, {"http.method": "GET", "http.route": "/threads", "http.status_code": "200"})
                    return response
        else:
            # Search all versions of the task
            for task_def in framework.task_registry.list_by_task(task_id):
                database = get_task_database(task_def, framework)
                if database:
                    thread_service = ThreadService(
                        database=database,
                        idempotency_store=framework.idempotency_store,
                        execution_engine=framework.execution_engine,
                    )
                    response = await thread_service.list_threads(
                        filters=filters,
                        user_id=auth.user_id,
                        app_id=auth.app_id,
                        is_admin=auth.key_type == "admin",
                        environment_id=effective_environment_id,
                        is_system_admin=cross_env_admin,
                    )
                    all_threads.extend(response.items)
    elif framework.database:
        # Use framework database directly (all tasks share the same database)
        thread_service = ThreadService(
            database=framework.database,
            idempotency_store=framework.idempotency_store,
            execution_engine=framework.execution_engine,
        )
        response = await thread_service.list_threads(
            filters=filters,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
            environment_id=effective_environment_id,
            is_system_admin=cross_env_admin,
        )
        api_requests_total.add(1, {"http.method": "GET", "http.route": "/threads", "http.status_code": "200"})
        return response
    
    # Sort by created_at descending and apply limit
    all_threads.sort(key=lambda t: t.created_at, reverse=True)
    limited_threads = all_threads[:limit] if limit else all_threads
    
    api_requests_total.add(1, {"http.method": "GET", "http.route": "/threads", "http.status_code": "200"})
    return ThreadListResponse(
        items=limited_threads,
        pagination=Pagination(
            cursor=None,
            has_more=len(all_threads) > len(limited_threads),
            total=len(all_threads),
        ),
    )


# Register /threads/{thread_id}/artifacts endpoint BEFORE /{thread_id} route
# This ensures FastAPI matches the more specific route first
# Import here to ensure artifacts module is loaded and endpoint is registered
from nexora_tasks_server.api import artifacts  # noqa: F401


@router.get("/{thread_id}", response_model=Thread)
async def get_thread(
    thread_id: str,
    task_id: Optional[str] = Query(None, description="Task identifier (optional, helps locate thread faster)"),
    version: Optional[str] = Query(None, description="Task version (optional)"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> Thread:
    """Get thread by ID.
    
    In multi-task mode, if task_id/version are not provided, searches across all task databases.
    
    Args:
        thread_id: Thread identifier
        task_id: Optional task identifier to narrow search
        version: Optional task version
        auth: Authenticated request context
        framework: NexoraTasks instance
        
    Returns:
        Thread instance
        
    Raises:
        HTTPException: 404 if thread not found or not accessible
    """
    thread = None

    # Fast path: task_id provided → search only in that task's database (O(1))
    if task_id:
        task_def = framework.get_task(task_id, version)
        if task_def:
            database = get_task_database(task_def, framework)
            thread_service = ThreadService(
                database=database,
                idempotency_store=framework.idempotency_store,
                execution_engine=framework.execution_engine,
            )
            thread = await thread_service.get_thread(
                thread_id=thread_id,
                user_id=auth.user_id,
                app_id=auth.app_id,
                is_admin=auth.key_type == "admin",
                environment_id=auth.environment_id,
                is_system_admin=(auth.key_type == "admin" and auth.environment_id == "default"),
            )

    # Slow path: fan-out across all task databases in parallel (perf-H-4)
    if not thread:
        thread, _ = await _find_thread_across_databases(
            thread_id=thread_id,
            framework=framework,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
            environment_id=auth.environment_id,
            is_system_admin=(auth.key_type == "admin" and auth.environment_id == "default"),
        )

    if not thread:
        api_requests_total.add(1, {"http.method": "GET", "http.route": "/threads/{thread_id}", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Thread {thread_id} not found",
                code=THREAD_NOT_FOUND,
            ),
        )

    api_requests_total.add(1, {"http.method": "GET", "http.route": "/threads/{thread_id}", "http.status_code": "200"})
    return thread


@router.post("/{thread_id}:stop", response_model=Thread, status_code=status.HTTP_202_ACCEPTED)
async def stop_thread(
    thread_id: str,
    task_id: Optional[str] = Query(None, description="Task identifier (optional, helps locate thread faster)"),
    version: Optional[str] = Query(None, description="Task version (optional)"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> Thread:
    """Stop a running thread.
    
    In multi-task mode, if task_id/version are not provided, searches across all task databases.
    
    Args:
        thread_id: Thread identifier
        task_id: Optional task identifier to narrow search
        version: Optional task version
        auth: Authenticated request context
        framework: NexoraTasks instance
        
    Returns:
        Updated Thread instance
        
    Raises:
        HTTPException: 404 if thread not found, 400 if invalid state
    """
    # Find the thread service that contains this thread
    thread_service = None
    thread = None
    
    # If task_id is provided, search in that specific task's database
    if task_id:
        task_def = framework.get_task(task_id, version)
        if task_def:
            database = get_task_database(task_def, framework) 
            thread_service = ThreadService(
                database=database,
                idempotency_store=framework.idempotency_store,
                execution_engine=framework.execution_engine,
            )
            thread = await thread_service.get_thread(
                thread_id=thread_id,
                user_id=auth.user_id,
                app_id=auth.app_id,
                is_admin=auth.key_type == "admin",
                environment_id=auth.environment_id,
                is_system_admin=(auth.key_type == "admin" and auth.environment_id == "default"),
            )
    
    # Slow path: parallel fan-out across all task databases (perf-H-4)
    if not thread:
        thread, _svc = await _find_thread_across_databases(
            thread_id=thread_id,
            framework=framework,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
            environment_id=auth.environment_id,
            is_system_admin=(auth.key_type == "admin" and auth.environment_id == "default"),
        )
        if _svc:
            thread_service = _svc

    if not thread or not thread_service:
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:stop", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Thread {thread_id} not found",
                code=THREAD_NOT_FOUND,
            ),
        )
    
    try:
        thread = await thread_service.stop_thread(
            thread_id=thread_id,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
        )

        # Log thread stop
        logger.info(
            "thread.stopped",
            thread_id=thread_id,
            stopped_by_user_id=auth.user_id,
            stopped_by_app_id=auth.app_id,
            state=str(thread.state),
        )

        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:stop", "http.status_code": "202"})
        return thread
    except ValueError as e:
        error_msg = str(e)
        if "not found" in error_msg.lower():
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:stop", "http.status_code": "404"})
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=problem_json_dict(
                    status_code=status.HTTP_404_NOT_FOUND,
                    title="Not Found",
                    detail=error_msg,
                    code=THREAD_NOT_FOUND,
                ),
            )
        else:
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:stop", "http.status_code": "400"})
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=problem_json_dict(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    title="Bad Request",
                    detail=error_msg,
                    code=THREAD_INVALID_STATE,
                ),
            )


@router.post("/{thread_id}:pause", response_model=Thread, status_code=status.HTTP_202_ACCEPTED)
async def pause_thread(
    thread_id: str,
    task_id: Optional[str] = Query(None, description="Task identifier (optional, helps locate thread faster)"),
    version: Optional[str] = Query(None, description="Task version (optional)"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> Thread:
    """Pause a running thread.
    
    The pause is cooperative — the task function must call context.check_pause()
    at safe checkpoint locations for the pause to take effect.
    
    Args:
        thread_id: Thread identifier
        task_id: Optional task identifier to narrow search
        version: Optional task version
        auth: Authenticated request context
        framework: NexoraTasks instance
        
    Returns:
        Updated Thread instance with state=paused
        
    Raises:
        HTTPException: 404 if thread not found, 400 if invalid state
    """
    thread_service = None
    thread = None
    
    if task_id:
        task_def = framework.get_task(task_id, version)
        if task_def:
            database = get_task_database(task_def, framework)
            thread_service = ThreadService(
                database=database,
                idempotency_store=framework.idempotency_store,
                execution_engine=framework.execution_engine,
            )
            thread = await thread_service.get_thread(
                thread_id=thread_id,
                user_id=auth.user_id,
                app_id=auth.app_id,
                is_admin=auth.key_type == "admin",
                environment_id=auth.environment_id,
                is_system_admin=(auth.key_type == "admin" and auth.environment_id == "default"),
            )
    
    # Parallel fan-out (perf-H-4)
    if not thread:
        thread, _svc = await _find_thread_across_databases(
            thread_id=thread_id,
            framework=framework,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
            environment_id=auth.environment_id,
            is_system_admin=(auth.key_type == "admin" and auth.environment_id == "default"),
        )
        if _svc:
            thread_service = _svc

    if not thread or not thread_service:
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:pause", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Thread {thread_id} not found",
                code=THREAD_NOT_FOUND,
            ),
        )
    
    try:
        thread = await thread_service.pause_thread(
            thread_id=thread_id,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
        )

        logger.info(
            "thread.paused",
            thread_id=thread_id,
            paused_by_user_id=auth.user_id,
            paused_by_app_id=auth.app_id,
            state=str(thread.state),
        )

        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:pause", "http.status_code": "202"})
        return thread
    except ValueError as e:
        error_msg = str(e)
        if "not found" in error_msg.lower():
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:pause", "http.status_code": "404"})
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=problem_json_dict(
                    status_code=status.HTTP_404_NOT_FOUND,
                    title="Not Found",
                    detail=error_msg,
                    code=THREAD_NOT_FOUND,
                ),
            )
        else:
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:pause", "http.status_code": "400"})
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=problem_json_dict(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    title="Bad Request",
                    detail=error_msg,
                    code=THREAD_INVALID_STATE,
                ),
            )


@router.post("/{thread_id}:resume", response_model=Thread, status_code=status.HTTP_202_ACCEPTED)
async def resume_thread(
    thread_id: str,
    task_id: Optional[str] = Query(None, description="Task identifier (optional, helps locate thread faster)"),
    version: Optional[str] = Query(None, description="Task version (optional)"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> Thread:
    """Resume a paused thread.
    
    Args:
        thread_id: Thread identifier
        task_id: Optional task identifier to narrow search
        version: Optional task version
        auth: Authenticated request context
        framework: NexoraTasks instance
        
    Returns:
        Updated Thread instance with state=running
        
    Raises:
        HTTPException: 404 if thread not found, 400 if invalid state
    """
    thread_service = None
    thread = None
    
    if task_id:
        task_def = framework.get_task(task_id, version)
        if task_def:
            database = get_task_database(task_def, framework)
            thread_service = ThreadService(
                database=database,
                idempotency_store=framework.idempotency_store,
                execution_engine=framework.execution_engine,
            )
            thread = await thread_service.get_thread(
                thread_id=thread_id,
                user_id=auth.user_id,
                app_id=auth.app_id,
                is_admin=auth.key_type == "admin",
                environment_id=auth.environment_id,
                is_system_admin=(auth.key_type == "admin" and auth.environment_id == "default"),
            )
    
    # Parallel fan-out (perf-H-4)
    if not thread:
        thread, _svc = await _find_thread_across_databases(
            thread_id=thread_id,
            framework=framework,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
            environment_id=auth.environment_id,
            is_system_admin=(auth.key_type == "admin" and auth.environment_id == "default"),
        )
        if _svc:
            thread_service = _svc

    if not thread or not thread_service:
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:resume", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Thread {thread_id} not found",
                code=THREAD_NOT_FOUND,
            ),
        )
    
    try:
        thread = await thread_service.resume_thread(
            thread_id=thread_id,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
        )

        logger.info(
            "thread.resumed",
            thread_id=thread_id,
            resumed_by_user_id=auth.user_id,
            resumed_by_app_id=auth.app_id,
            state=str(thread.state),
        )

        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:resume", "http.status_code": "202"})
        return thread
    except ValueError as e:
        error_msg = str(e)
        if "not found" in error_msg.lower():
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:resume", "http.status_code": "404"})
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=problem_json_dict(
                    status_code=status.HTTP_404_NOT_FOUND,
                    title="Not Found",
                    detail=error_msg,
                    code=THREAD_NOT_FOUND,
                ),
            )
        else:
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:resume", "http.status_code": "400"})
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=problem_json_dict(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    title="Bad Request",
                    detail=error_msg,
                    code=THREAD_INVALID_STATE,
                ),
            )


@router.post("/{thread_id}:retry", response_model=Thread, status_code=status.HTTP_201_CREATED)
async def retry_thread(
    thread_id: str,
    request: ThreadRetryRequest,
    task_id: Optional[str] = Query(None, description="Task identifier (optional, helps locate thread faster)"),
    version: Optional[str] = Query(None, description="Task version (optional)"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    framework: Any = Depends(get_framework),
) -> Thread:
    """Retry a failed thread.
    
    In multi-task mode, if task_id/version are not provided, searches across all task databases.
    
    Args:
        thread_id: Original thread identifier
        request: Retry request options
        task_id: Optional task identifier to narrow search
        version: Optional task version
        auth: Authenticated request context
        framework: NexoraTasks instance
        
    Returns:
        New Thread instance (new attempt)
        
    Raises:
        HTTPException: 404 if thread not found, 400 if invalid state
    """
    # Find the thread service and task definition that contains this thread
    thread_service = None
    thread = None
    task_def = None
    
    # If task_id is provided, search in that specific task's database
    if task_id:
        task_def = framework.get_task(task_id, version)
        if task_def:
            database = get_task_database(task_def, framework) 
            thread_service = ThreadService(
                database=database,
                idempotency_store=framework.idempotency_store,
                execution_engine=framework.execution_engine,
            )
            thread = await thread_service.get_thread(
                thread_id=thread_id,
                user_id=auth.user_id,
                app_id=auth.app_id,
                is_admin=auth.key_type == "admin",
                environment_id=auth.environment_id,
                is_system_admin=(auth.key_type == "admin" and auth.environment_id == "default"),
            )
    
    # Parallel fan-out across all task databases (perf-H-4)
    if not thread:
        thread, _svc = await _find_thread_across_databases(
            thread_id=thread_id,
            framework=framework,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
            environment_id=auth.environment_id,
            is_system_admin=(auth.key_type == "admin" and auth.environment_id == "default"),
        )
        if _svc:
            thread_service = _svc
            # task_def will be resolved below from thread metadata if still None

    if not thread or not thread_service:
        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:retry", "http.status_code": "404"})
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Thread {thread_id} not found",
                code=THREAD_NOT_FOUND,
            ),
        )
    
    # If task_def is None, look up from thread's metadata
    # This happens when thread was found in shared database
    if not task_def and thread.metadata:
        original_task_id = thread.metadata.get("task_id")
        original_task_version = thread.metadata.get("task_version")
        if original_task_id:
            task_def = framework.get_task(original_task_id, original_task_version)
            logger.debug(
                "thread.retry.resolved_task_from_metadata",
                thread_id=thread_id,
                task_id=original_task_id,
                task_version=original_task_version,
                found=task_def is not None,
            )
    
    # Get task function from task definition (multi-task) or framework (single-task)
    task_function = await get_task_function(task_def, framework)
    
    if not task_function:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=problem_json_dict(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                title="Service Unavailable",
                detail="Task function not registered",
            ),
        )

    try:
        thread = await thread_service.retry_thread(
            thread_id=thread_id,
            request=request,
            user_id=auth.user_id,
            app_id=auth.app_id,
            is_admin=auth.key_type == "admin",
            task_function=task_function,
            task_definition=task_def,
        )

        # Log thread retry
        logger.info(
            "thread.retried",
            original_thread_id=thread_id,
            new_thread_id=thread.id,
            retried_by_user_id=auth.user_id,
            retried_by_app_id=auth.app_id,
            attempt=thread.attempt,
            task_id=task_def.task_id if task_def else None,
            task_version=task_def.version if task_def else None,
        )

        api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:retry", "http.status_code": "201"})
        return thread
    except ValueError as e:
        error_msg = str(e)
        if "not found" in error_msg.lower():
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:retry", "http.status_code": "404"})
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=problem_json_dict(
                    status_code=status.HTTP_404_NOT_FOUND,
                    title="Not Found",
                    detail=error_msg,
                    code=THREAD_NOT_FOUND,
                ),
            )
        else:
            api_requests_total.add(1, {"http.method": "POST", "http.route": "/threads/{thread_id}:retry", "http.status_code": "400"})
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=problem_json_dict(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    title="Bad Request",
                    detail=error_msg,
                    code=THREAD_INVALID_STATE,
                ),
            )

