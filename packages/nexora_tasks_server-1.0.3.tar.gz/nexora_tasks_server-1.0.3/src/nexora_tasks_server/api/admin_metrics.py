"""Admin metrics API — server-wide and per-task metrics (admin keys only).

Provides JSON representations of metrics from the in-process Prometheus
registry, enabling the UI to display dashboards without requiring
external monitoring tools.
"""

from typing import Optional

from fastapi import APIRouter, Depends, Query

from nexora_tasks.models.log_models import (
    AllTasksMetrics,
    MetricsSummary,
    TaskMetrics,
    WorkersResponse,
)
from nexora_tasks_server.dependencies import get_framework
from nexora_tasks_server.framework import NexoraTasks
from nexora_tasks_server.middleware.admin_auth import get_admin_authenticated_request
from nexora_tasks_server.services.observability_service import ObservabilityService

router = APIRouter(prefix="/admin/metrics", tags=["admin-metrics"])


def _get_observability_service(
    framework: NexoraTasks = Depends(get_framework),
) -> ObservabilityService:
    """Get or create the ObservabilityService singleton."""
    if not hasattr(framework, "_observability_service"):
        framework._observability_service = ObservabilityService(framework)
    return framework._observability_service


@router.get(
    "/summary",
    response_model=MetricsSummary,
    summary="Get server-wide metrics summary",
    description=(
        "Returns a JSON overview of server metrics read directly from the "
        "in-process Prometheus registry.\n\n"
        "Includes:\n"
        "- **threads**: Total and current counts by state\n"
        "- **workers**: Active/idle counts and restart totals\n"
        "- **api**: Total API request count\n"
        "- **database**: Operation counts by type\n"
        "- **uptime_seconds**: Server uptime\n\n"
        "This endpoint reads the same data as ``GET /metrics`` (Prometheus format) "
        "but returns it as structured JSON for UI consumption."
    ),
)
async def get_metrics_summary(
    admin_key: str = Depends(get_admin_authenticated_request),
    service: ObservabilityService = Depends(_get_observability_service),
) -> MetricsSummary:
    """Get server-wide metrics overview (admin only)."""
    return service.get_metrics_summary()


@router.get(
    "/tasks",
    response_model=AllTasksMetrics,
    summary="Get metrics for all tasks",
    description=(
        "Returns per-task metrics for all registered tasks, including "
        "thread counts, execution durations, queue times, error breakdowns, "
        "and worker statistics."
    ),
)
async def get_all_tasks_metrics(
    admin_key: str = Depends(get_admin_authenticated_request),
    service: ObservabilityService = Depends(_get_observability_service),
) -> AllTasksMetrics:
    """Get metrics for all registered tasks (admin only)."""
    return service.get_all_tasks_metrics()


@router.get(
    "/tasks/{task_id}",
    response_model=TaskMetrics,
    summary="Get metrics for a specific task",
    description=(
        "Returns detailed metrics for a single task, including:\n\n"
        "- **threads**: Total and current counts by state\n"
        "- **execution**: Duration statistics (sum, count, avg, histogram buckets)\n"
        "- **queue**: Queue wait time statistics\n"
        "- **errors**: Error counts by type\n"
        "- **worker**: Startup duration, restarts, pending executions"
    ),
)
async def get_task_metrics(
    task_id: str,
    admin_key: str = Depends(get_admin_authenticated_request),
    service: ObservabilityService = Depends(_get_observability_service),
) -> TaskMetrics:
    """Get metrics for a specific task (admin only)."""
    return service.get_task_metrics(task_id)


@router.get(
    "/workers",
    response_model=WorkersResponse,
    summary="Get worker subprocess status",
    description=(
        "Returns the current status of all worker subprocesses, including "
        "PID, alive status, active execution count, restart count, "
        "uptime, and last health check time."
    ),
)
async def get_workers_status(
    admin_key: str = Depends(get_admin_authenticated_request),
    service: ObservabilityService = Depends(_get_observability_service),
) -> WorkersResponse:
    """Get worker subprocess status (admin only)."""
    return service.get_workers_info()
