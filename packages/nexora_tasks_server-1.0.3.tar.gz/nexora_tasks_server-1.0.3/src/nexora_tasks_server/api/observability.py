"""Observability API — thread logs, events, and live log streaming.

Provides REST and WebSocket endpoints for inspecting thread execution
logs and lifecycle events without requiring external tools.
"""

from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, WebSocket, WebSocketDisconnect, status

from nexora_tasks.models.log_models import (
    ThreadEventsResponse,
    ThreadLogsResponse,
    ThreadTracesResponse,
)
from nexora_tasks_server.dependencies import (
    AuthenticatedRequest,
    get_authenticated_request,
    get_framework,
)
from nexora_tasks_server.framework import NexoraTasks
from nexora_tasks_server.services.observability_service import ObservabilityService

router = APIRouter(tags=["threads"])


def _get_observability_service(
    framework: NexoraTasks = Depends(get_framework),
) -> ObservabilityService:
    """Get or create the ObservabilityService singleton."""
    if not hasattr(framework, "_observability_service"):
        framework._observability_service = ObservabilityService(framework)
    return framework._observability_service


@router.get(
    "/threads/{thread_id}/logs",
    response_model=ThreadLogsResponse,
    summary="Get thread execution logs",
    description=(
        "Retrieve structured log entries for a thread execution.\n\n"
        "Logs include:\n"
        "- **server** lifecycle events (started, config resolved, completed/failed)\n"
        "- **worker** structured events from the task execution\n"
        "- **stdout** captured print() / console.log() output from task code\n\n"
        "When Elasticsearch is the database backend, full log history is available. "
        "With the file-based backend, logs are served from an in-memory buffer "
        "(last 1000 entries per thread)."
    ),
)
async def get_thread_logs(
    thread_id: str,
    level: Optional[str] = Query(
        None,
        description="Filter by log level: debug, info, warning, error",
    ),
    source: Optional[str] = Query(
        None,
        description="Filter by source: server, worker, stdout, stderr, or 'all' for no filter",
    ),
    after: Optional[datetime] = Query(
        None,
        description="Only return entries after this ISO 8601 timestamp",
    ),
    before: Optional[datetime] = Query(
        None,
        description="Only return entries before this ISO 8601 timestamp",
    ),
    search: Optional[str] = Query(
        None,
        description="Full-text search across event name and message fields",
    ),
    limit: int = Query(100, ge=1, le=1000, description="Maximum entries to return"),
    offset: int = Query(0, ge=0, description="Number of entries to skip"),
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    service: ObservabilityService = Depends(_get_observability_service),
    framework: NexoraTasks = Depends(get_framework),
) -> ThreadLogsResponse:
    """Get execution logs for a specific thread."""
    # Verify thread exists
    thread = await framework.database.get_thread(thread_id)
    if not thread:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Thread {thread_id} not found",
        )

    return await service.get_thread_logs(
        thread_id=thread_id,
        level=level,
        source=source,
        after=after,
        before=before,
        search=search,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/threads/{thread_id}/events",
    response_model=ThreadEventsResponse,
    summary="Get thread lifecycle events",
    description=(
        "Returns a timeline of lifecycle events for a thread, derived from "
        "the thread's timestamps and state transitions.\n\n"
        "Events include:\n"
        "- **state_change**: queued → running → succeeded/failed/stopped/timeout\n"
        "- **progress**: progress value changes\n"
        "- **error**: error details when execution fails\n"
        "- **retry**: retry attempt information\n"
        "- **schedule_triggered**: schedule and run metadata\n\n"
        "This endpoint is always available — no Elasticsearch dependency."
    ),
)
async def get_thread_events(
    thread_id: str,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    service: ObservabilityService = Depends(_get_observability_service),
    framework: NexoraTasks = Depends(get_framework),
) -> ThreadEventsResponse:
    """Get lifecycle events for a specific thread."""
    thread = await framework.database.get_thread(thread_id)
    if not thread:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Thread {thread_id} not found",
        )

    return service.get_thread_events(thread)


@router.get(
    "/threads/{thread_id}/traces",
    response_model=ThreadTracesResponse,
    summary="Get OTel trace waterfall for a thread",
    description=(
        "Queries Elasticsearch for OpenTelemetry spans whose "
        "``Attributes.nexora_tasks.thread_id`` matches the thread, then "
        "loads all spans for that ``TraceId``. Requires "
        "``STORAGE_TYPE=elasticsearch`` and the OTel Collector exporting to "
        "the same cluster (default index ``traces-generic.otel-default``; "
        "override via ``OTEL_TRACES_INDEX``). Returns an empty ``found`` "
        "result with a message when traces are not available."
    ),
)
async def get_thread_traces(
    thread_id: str,
    auth: AuthenticatedRequest = Depends(get_authenticated_request),
    service: ObservabilityService = Depends(_get_observability_service),
    framework: NexoraTasks = Depends(get_framework),
) -> ThreadTracesResponse:
    """OTel waterfall for thread execution (Elasticsearch + OTel Collector)."""
    thread = await framework.database.get_thread(thread_id)
    if not thread:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Thread {thread_id} not found",
        )

    return await service.get_thread_traces(thread_id)


@router.websocket("/threads/{thread_id}/logs/stream")
async def stream_thread_logs(
    websocket: WebSocket,
    thread_id: str,
    framework: NexoraTasks = Depends(get_framework),
):
    """Live-stream thread execution logs via WebSocket.

    **Authentication**: Pass API key as a query parameter `api_key`.

    **Protocol**:
    1. Client connects with ``ws://host/threads/{id}/logs/stream?api_key=xxx``
    2. Server sends existing buffered entries as backfill
    3. Server streams new log entries as JSON objects in real-time
    4. Server sends ``{"type": "stream_end"}`` when thread completes
    5. Connection closes automatically

    **Message format**: Each message is a JSON-serialized ``LogEntry``.
    """
    # Authenticate via query parameter
    api_key = websocket.query_params.get("api_key")
    if not api_key:
        await websocket.close(code=4001, reason="Missing api_key query parameter")
        return

    # Validate API key. Legacy lists go through the hashed match path
    # (F-5); environment-registry lookups remain dict-based against
    # plaintext keys (env-registry hashing is a follow-up).
    is_valid = (
        framework.match_api_key(api_key) is not None
        or framework.environment_registry.find_by_api_key(api_key) is not None
        or framework.environment_registry.find_by_admin_key(api_key) is not None
    )
    if not is_valid:
        await websocket.close(code=4003, reason="Invalid API key")
        return

    # Verify thread exists
    thread = await framework.database.get_thread(thread_id)
    if not thread:
        await websocket.close(code=4004, reason=f"Thread {thread_id} not found")
        return

    await websocket.accept()

    log_buffer = framework.log_buffer

    # Send existing entries as backfill
    existing_entries, _ = log_buffer.get_entries(thread_id, limit=1000)
    for entry in existing_entries:
        try:
            await websocket.send_json(entry.model_dump(mode="json"))
        except Exception:
            return

    # Subscribe for real-time entries
    queue = log_buffer.subscribe(thread_id)

    try:
        while True:
            # Wait for next log entry
            entry = await queue.get()

            if entry is None:
                # Stream ended (thread completed)
                await websocket.send_json({"type": "stream_end", "thread_id": thread_id})
                break

            await websocket.send_json(entry.model_dump(mode="json"))
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        log_buffer.unsubscribe(thread_id, queue)
        try:
            await websocket.close()
        except Exception:
            pass
