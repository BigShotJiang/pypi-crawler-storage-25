"""Admin health API — detailed health check with subsystem statuses.

Extends the basic ``GET /health`` endpoint with comprehensive information
about database, storage, scheduler, workers, and observability configuration.
"""

from fastapi import APIRouter, Depends

from nexora_tasks.models.log_models import DetailedHealth
from nexora_tasks_server.dependencies import get_framework
from nexora_tasks_server.framework import NexoraTasks
from nexora_tasks_server.middleware.admin_auth import get_admin_authenticated_request
from nexora_tasks_server.services.observability_service import ObservabilityService

router = APIRouter(prefix="/admin", tags=["admin-health"])


def _get_observability_service(
    framework: NexoraTasks = Depends(get_framework),
) -> ObservabilityService:
    """Get or create the ObservabilityService singleton."""
    if not hasattr(framework, "_observability_service"):
        framework._observability_service = ObservabilityService(framework)
    return framework._observability_service


@router.get(
    "/health",
    response_model=DetailedHealth,
    summary="Detailed server health check",
    description=(
        "Returns comprehensive health information about all server subsystems.\n\n"
        "Includes:\n"
        "- **database**: Backend type and connection status\n"
        "- **storage**: File storage type and status\n"
        "- **scheduler**: APScheduler status\n"
        "- **workers**: Active/idle worker counts\n"
        "- **observability**: Log buffer config, metrics, tracing status\n\n"
        "The overall ``status`` field is 'healthy' when all subsystems are operational, "
        "or 'degraded' if any subsystem reports an error."
    ),
)
async def get_detailed_health(
    admin_key: str = Depends(get_admin_authenticated_request),
    service: ObservabilityService = Depends(_get_observability_service),
) -> DetailedHealth:
    """Get detailed server health status (admin only)."""
    return await service.get_detailed_health()
