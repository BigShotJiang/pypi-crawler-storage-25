"""Admin API for environment management.

Provides endpoints to create, list, update, and delete environments,
manage API key bindings, activate/deactivate task versions per environment,
promote tasks across environments, and rollback to previous versions.
"""

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from nexora_tasks.logging import logger
from nexora_tasks.models.environment import (
    ActivateTaskRequest,
    AddApiKeyRequest,
    CreateEnvironmentRequest,
    Environment,
    EnvironmentActivation,
    EnvironmentSummary,
    PromoteTaskRequest,
    PromotionRecord,
    UpdateEnvironmentRequest,
)
from nexora_tasks_server.dependencies import get_framework
from nexora_tasks_server.framework import NexoraTasks
from nexora_tasks_server.middleware.admin_auth import get_admin_authenticated_request

router = APIRouter(prefix="/admin/environments", tags=["admin-environments"])

# Promotions live at the top of the admin namespace because they describe a
# *cross-environment* relationship (source → target) and may be filtered by
# task or by environment via query params; nesting them under
# `/admin/environments/promotions` invited callers to think they were
# "promotions FOR a specific environment", which they are not.
promotions_router = APIRouter(prefix="/admin", tags=["admin-environments"])


# ── Environment CRUD ────────────────────────────────────────────────────────


@router.post("", status_code=201, response_model=Environment)
async def create_environment(
    request: CreateEnvironmentRequest,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> Environment:
    """Create a new environment.

    Environments provide isolated namespaces for task execution. Each environment
    has its own API keys, task activations, configuration, and data.

    Standard environment IDs (dev, staging, pre-prod, prod) are automatically
    assigned a promotion order for the linear promotion path.
    """
    env_registry = framework.environment_registry

    env = Environment(
        id=request.id,
        name=request.name,
        description=request.description,
        api_keys=request.api_keys,
        admin_api_keys=request.admin_api_keys,
        settings=request.settings,
        promotion_order=request.promotion_order,
    )

    try:
        created = await env_registry.create(env)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))

    logger.info("admin.environment.created", environment_id=created.id, by=admin_key[:8])
    return created


@router.get("", response_model=List[EnvironmentSummary])
async def list_environments(
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> List[EnvironmentSummary]:
    """List all environments with summary information."""
    env_registry = framework.environment_registry
    return await env_registry.list_summaries()


@router.get("/{environment_id}", response_model=Environment)
async def get_environment(
    environment_id: str,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> Environment:
    """Get full details for a specific environment."""
    env_registry = framework.environment_registry
    env = await env_registry.get(environment_id)
    if not env:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Environment '{environment_id}' not found",
        )
    return env


@router.put("/{environment_id}", response_model=Environment)
async def update_environment(
    environment_id: str,
    request: UpdateEnvironmentRequest,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> Environment:
    """Update an environment's name, description, settings, or status."""
    env_registry = framework.environment_registry

    try:
        updated = await env_registry.update(
            env_id=environment_id,
            name=request.name,
            description=request.description,
            settings=request.settings,
            env_status=request.status,
            promotion_order=request.promotion_order,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    return updated


@router.delete("/{environment_id}", status_code=204)
async def delete_environment(
    environment_id: str,
    cascade: bool = False,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> None:
    """Delete an environment.

    The ``default`` environment cannot be deleted. If the environment still owns
    resources (schedules, webhooks, activations, files), the request is rejected
    with 409 unless ``cascade=true`` is passed, in which case all owned resources
    are removed first. Threads stay intact as an audit trail.
    """
    env_registry = framework.environment_registry

    # Count owned resources for the precheck / cascade report.
    schedules_to_remove: list = []
    webhooks_to_remove: list = []
    try:
        if framework.database is not None:
            all_schedules = await framework.database.query_schedules({})
            for s in all_schedules:
                env_id = (
                    getattr(s, "environment_id", None)
                    or (s.metadata or {}).get("environment_id")
                    or "default"
                )
                if env_id == environment_id:
                    schedules_to_remove.append(s)
        if getattr(framework, "webhook_repository", None) is not None:
            all_webhooks = await framework.webhook_repository.list_webhooks(filters={})
            for wh in all_webhooks:
                if getattr(wh, "environment_id", None) == environment_id:
                    webhooks_to_remove.append(wh)
    except Exception:
        # Best-effort precheck; if we can't enumerate, fall through to delete().
        pass

    activations = await env_registry.list_activations(environment_id)

    owned_count = len(schedules_to_remove) + len(webhooks_to_remove) + len(activations)
    if owned_count > 0 and not cascade:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "message": (
                    f"Environment '{environment_id}' owns {owned_count} resource(s). "
                    "Re-send the request with ?cascade=true to remove them."
                ),
                "schedules": len(schedules_to_remove),
                "webhooks": len(webhooks_to_remove),
                "activations": len(activations),
            },
        )

    if cascade:
        for s in schedules_to_remove:
            try:
                await framework.database.delete_schedule(s.id)
            except Exception:
                pass
        for wh in webhooks_to_remove:
            try:
                await framework.webhook_repository.delete_webhook(wh.id)
            except Exception:
                pass
        for act in activations:
            try:
                await env_registry.deactivate_task(environment_id, act.task_id)
            except Exception:
                pass

    try:
        deleted = await env_registry.delete(environment_id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Environment '{environment_id}' not found",
        )


# ── API Key Management ──────────────────────────────────────────────────────


@router.post("/{environment_id}/keys", status_code=201)
async def add_api_key(
    environment_id: str,
    request: AddApiKeyRequest,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> dict:
    """Add an API key binding to an environment.

    Each API key can only be bound to one environment. The key_type determines
    whether this is a regular key (data access) or admin key (environment management).
    """
    env_registry = framework.environment_registry

    try:
        await env_registry.add_api_key(environment_id, request.api_key, request.key_type)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))

    return {"status": "added", "environment_id": environment_id, "key_type": request.key_type}


@router.delete("/{environment_id}/keys/{api_key}", status_code=204)
async def remove_api_key(
    environment_id: str,
    api_key: str,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> None:
    """Remove an API key binding from an environment."""
    env_registry = framework.environment_registry

    try:
        removed = await env_registry.remove_api_key(environment_id, api_key)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    if not removed:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"API key not found in environment '{environment_id}'",
        )


# ── Task Activation ─────────────────────────────────────────────────────────


@router.get("/{environment_id}/tasks", response_model=List[EnvironmentActivation])
async def list_active_tasks(
    environment_id: str,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> List[EnvironmentActivation]:
    """List all active task versions in an environment."""
    env_registry = framework.environment_registry

    env = await env_registry.get(environment_id)
    if not env:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Environment '{environment_id}' not found",
        )

    return await env_registry.list_activations(environment_id)


@router.post(
    "/{environment_id}/tasks/{task_id}:activate",
    status_code=200,
    response_model=EnvironmentActivation,
)
async def activate_task(
    environment_id: str,
    task_id: str,
    request: ActivateTaskRequest,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> EnvironmentActivation:
    """Activate a specific task version in an environment.

    The task version must already be deployed globally on the server.
    If a different version was previously active, it is recorded for rollback.
    """
    env_registry = framework.environment_registry

    # Validate task version exists in the global registry
    task_def = framework.task_registry.get(task_id, request.version)
    if not task_def:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Task '{task_id}' version '{request.version}' not found in global registry",
        )

    try:
        activation = await env_registry.activate_task(
            env_id=environment_id,
            task_id=task_id,
            version=request.version,
            activated_by=admin_key[:8],
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    logger.info(
        "admin.environment.task_activated",
        environment_id=environment_id,
        task_id=task_id,
        version=request.version,
    )
    return activation


@router.delete("/{environment_id}/tasks/{task_id}:deactivate", status_code=204)
async def deactivate_task(
    environment_id: str,
    task_id: str,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> None:
    """Deactivate a task in an environment.

    The task will no longer be available for execution in this environment.
    """
    env_registry = framework.environment_registry
    deactivated = await env_registry.deactivate_task(environment_id, task_id)
    if not deactivated:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Task '{task_id}' is not active in environment '{environment_id}'",
        )


@router.post(
    "/{environment_id}/tasks/{task_id}:rollback",
    status_code=200,
    response_model=EnvironmentActivation,
)
async def rollback_task(
    environment_id: str,
    task_id: str,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> EnvironmentActivation:
    """Rollback a task to its previously active version in an environment.

    Uses the version that was replaced during the last activation.
    Returns 404 if no previous version is available.
    """
    env_registry = framework.environment_registry

    try:
        activation = await env_registry.rollback_task(
            env_id=environment_id,
            task_id=task_id,
            rolled_back_by=admin_key[:8],
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    if not activation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No previous version available for rollback of '{task_id}' in '{environment_id}'",
        )

    logger.info(
        "admin.environment.task_rolled_back",
        environment_id=environment_id,
        task_id=task_id,
        version=activation.version,
    )
    return activation


# ── Promotion ───────────────────────────────────────────────────────────────


@router.post(
    "/{target_environment_id}/tasks/{task_id}:promote",
    status_code=200,
    response_model=PromotionRecord,
)
async def promote_task(
    target_environment_id: str,
    task_id: str,
    request: PromoteTaskRequest,
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> PromotionRecord:
    """Promote a task version from one environment to another.

    The version must be active in the source environment. Promotion follows
    the linear path: dev → staging → pre-prod → prod. Skipping environments
    is not allowed.

    This does NOT copy task code — it enables the same globally-deployed version
    in the target environment.
    """
    env_registry = framework.environment_registry

    try:
        record = await env_registry.promote(
            task_id=task_id,
            version=request.version,
            source_env=request.source_environment,
            target_env=target_environment_id,
            promoted_by=admin_key[:8],
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    logger.info(
        "admin.environment.task_promoted",
        task_id=task_id,
        version=request.version,
        source=request.source_environment,
        target=target_environment_id,
    )
    return record


@promotions_router.get("/promotions", response_model=List[PromotionRecord])
async def list_promotions(
    task_id: Optional[str] = Query(None, description="Filter by task ID"),
    environment_id: Optional[str] = Query(None, description="Filter by target environment"),
    limit: int = Query(50, ge=1, le=200, description="Maximum records to return"),
    admin_key: str = Depends(get_admin_authenticated_request),
    framework: NexoraTasks = Depends(get_framework),
) -> List[PromotionRecord]:
    """List promotion history, optionally filtered by task or environment.

    Returns records sorted newest-first.
    """
    env_registry = framework.environment_registry
    return await env_registry.list_promotions(
        task_id=task_id,
        environment_id=environment_id,
        limit=limit,
    )
