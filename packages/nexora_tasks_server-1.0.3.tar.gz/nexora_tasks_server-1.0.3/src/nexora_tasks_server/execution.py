"""Task execution engine for managing task lifecycle and state."""

import asyncio
import inspect
import os
import sys
import threading
import traceback
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, AsyncIterator, Callable, Dict, List, Optional

from structlog.contextvars import bind_contextvars, unbind_contextvars

from nexora_tasks.context import TaskContext
from nexora_tasks.logging import logger


@contextmanager
def _bound_correlation_ids(**ids: Optional[str]):
    """Bind non-empty IDs into structlog contextvars for the duration of work.

    E-5: ``request_id`` is bound globally by middleware for HTTP-originated
    logs, but any log emitted from a background path (worker IPC callback,
    scheduler tick, webhook delivery) would otherwise carry no correlation
    keys at all. Wrapping the entry points in this context manager ensures
    that thread_id / task_id / exec_id / schedule_id / run_id / webhook_id /
    delivery_id travel with every structured log line emitted downstream.

    Also stamps ``thread.id`` / ``task.id`` on the currently-active OTel span
    (the FastAPI/route span that started before this binding). The
    ``_ThreadIdSpanProcessor`` covers spans created AFTER the bind; the
    direct stamp here covers ancestors that already started.
    """
    bound: List[str] = []
    try:
        kv = {k: v for k, v in ids.items() if v is not None and v != ""}
        if kv:
            bind_contextvars(**kv)
            bound = list(kv.keys())
            try:
                from opentelemetry import trace as _otel_trace

                _span = _otel_trace.get_current_span()
                if _span is not None and _span.is_recording():
                    if "thread_id" in kv:
                        _span.set_attribute("thread.id", str(kv["thread_id"]))
                    if "task_id" in kv:
                        _span.set_attribute("task.id", str(kv["task_id"]))
            except Exception:
                pass
        yield
    finally:
        if bound:
            unbind_contextvars(*bound)
from nexora_tasks_server.observability.metrics import (
    thread_queue_duration,
    threads_current,
    threads_total,
)
from nexora_tasks.models.thread import Thread
from nexora_tasks.models.thread_error import ThreadError
from nexora_tasks.thread_state import ThreadState
from nexora_tasks_server.state_transition import (
    StateTransition,
    TransitionContext,
    apply_terminal_transition,
)
from nexora_tasks_server.tracing import begin_transaction, end_transaction, label as apm_label
from nexora_tasks_server.utils.metrics_helpers import update_thread_state_gauge

if TYPE_CHECKING:
    from nexora_tasks_server.framework import NexoraTasks


class ExecutionEngine:
    """Task execution engine managing task lifecycle and state."""

    def __init__(self, framework: "NexoraTasks", timeout_seconds: Optional[int] = None) -> None:
        """Initialize execution engine.

        Args:
            framework: NexoraTasks instance
            timeout_seconds: Optional timeout for task execution (default: None, no timeout)
        """
        self.framework = framework
        self.timeout_seconds = timeout_seconds
        # Configurable max_workers: 0 or unset = Python default (min(32, cpu_count + 4))
        max_workers = int(os.getenv("TASK_EXECUTOR_MAX_WORKERS", "0")) or None
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        # Registry to track active TaskContext instances by thread_id
        self._active_contexts: Dict[str, TaskContext] = {}
        # Locks for thread-safe sys.path manipulation during task execution.
        # ``_import_thread_lock`` guards the sync path (run on the thread pool);
        # ``_import_async_lock`` serialises concurrent async tasks within a
        # single event loop so a second async task cannot mutate ``sys.path``
        # between the first task's setup and its first ``await`` (M-4 / bug-4).
        # The async lock is initialised lazily inside ``_with_path_async`` so
        # ``ExecutionEngine`` can be constructed outside a running event loop.
        self._import_thread_lock = threading.Lock()
        self._import_async_lock: Optional[asyncio.Lock] = None

    def _get_async_path_lock(self) -> asyncio.Lock:
        """Return the lazily-initialised async sys.path lock.

        Tests sometimes construct ``ExecutionEngine`` via ``__new__`` to
        bypass the real ``NexoraTasks`` wiring (see
        ``tests/test_execution_cancel.py``); using ``getattr`` here keeps
        those code paths working without forcing every test fixture to
        seed a fresh attribute.
        """
        lock = getattr(self, "_import_async_lock", None)
        if lock is None:
            lock = asyncio.Lock()
            self._import_async_lock = lock
        return lock

    @asynccontextmanager
    async def _with_path_async(self, code_path: Optional[str]) -> AsyncIterator[None]:
        """Async context manager guarding ``sys.path`` for a coroutine task.

        M-4 / bug-4 — the original code only locked the *sync* path with
        ``threading.Lock``. Concurrent async tasks in the same event loop
        could (and did, intermittently) interleave their ``sys.path``
        manipulation: task A pushes its paths, yields at its first
        ``await`` before its module imports finish, task B pushes/pops
        its own, leaving A's view of ``sys.path`` corrupted on resume.

        Holding an ``asyncio.Lock`` for the entire async task body
        serialises async task execution. That is acceptable for the
        in-process path (which is dev / fallback only — real workloads
        run in worker subprocesses with their own ``sys.path``).
        """
        lock = self._get_async_path_lock()
        async with lock:
            added_paths = self._setup_task_paths(code_path)
            self._clear_task_modules(code_path)
            try:
                yield
            finally:
                self._teardown_task_paths(added_paths)
    
    def _setup_task_paths(self, code_path: Optional[str]) -> List[str]:
        """Add task-specific paths to front of sys.path.
        
        Args:
            code_path: Path to the task's code directory
            
        Returns:
            List of paths that were added (for later removal)
        """
        if not code_path:
            return []
        
        added: List[str] = []
        code_path_obj = Path(code_path)
        venv_sp = (
            code_path_obj.parent / "venv" / "lib"
            / f"python{sys.version_info.major}.{sys.version_info.minor}"
            / "site-packages"
        )
        
        if venv_sp.exists():
            sp_str = str(venv_sp)
            sys.path.insert(0, sp_str)
            added.append(sp_str)
        
        cp_str = str(code_path_obj)
        sys.path.insert(0, cp_str)
        added.append(cp_str)
        
        return added

    def _teardown_task_paths(self, added_paths: List[str]) -> None:
        """Remove task-specific paths from sys.path.
        
        Args:
            added_paths: Paths previously added by _setup_task_paths
        """
        for p in added_paths:
            try:
                sys.path.remove(p)
            except ValueError:
                pass

    def _clear_task_modules(self, code_path: Optional[str]) -> None:
        """Clear task CODE modules from sys.modules to ensure correct lazy imports.
        
        Only clears modules loaded from task /code/ directories — these are
        task-specific source files (e.g., task.py, lib/utils.py) that could
        collide when multiple tasks share the same module names.
        
        Modules from task /venv/ site-packages are NEVER cleared. C extensions
        like lxml cannot be safely reloaded — clearing and re-importing them
        from a different path creates incompatible C types in the same process
        (e.g., "Cannot convert lxml.etree.X to lxml.etree.X").
        
        Args:
            code_path: Path to the current task's code directory.
                      Modules from this path will NOT be cleared.
        """
        for name in list(sys.modules.keys()):
            mod = sys.modules.get(name)
            if mod is None:
                continue
            mod_file = getattr(mod, '__file__', None)
            if not mod_file:
                continue
            # Only clear modules from task CODE directories, not from venv
            # site-packages. The /code/ segment is the task's source directory;
            # /venv/ contains installed packages (including C extensions).
            is_task_code = False
            if "/tasks/" in mod_file or "/task_definitions/" in mod_file:
                # Must be from a /code/ subdirectory, NOT from /venv/
                if "/code/" in mod_file and "/venv/" not in mod_file and "/site-packages/" not in mod_file:
                    is_task_code = True
            
            if not is_task_code:
                continue
            
            # Keep modules from the current task
            if code_path and mod_file.startswith(str(code_path)):
                continue
            del sys.modules[name]

    def _execute_sync_isolated(
        self, task_function: Callable, context: "TaskContext", code_path: Optional[str]
    ) -> Any:
        """Execute a sync task function with sys.path isolation.
        
        Uses threading.Lock to prevent concurrent tasks from stomping on
        each other's path setup.
        
        Args:
            task_function: The sync task function to execute
            context: TaskContext for the execution
            code_path: Path to the task's code directory
            
        Returns:
            Result from the task function
        """
        with self._import_thread_lock:
            added = self._setup_task_paths(code_path)
            self._clear_task_modules(code_path)
        try:
            return task_function(context)
        finally:
            with self._import_thread_lock:
                self._teardown_task_paths(added)

    async def execute_task(self, thread: Thread, task_function: Callable, task_definition: Optional[Any] = None) -> Thread:
        """Execute a task function with the given thread.

        Args:
            thread: Thread instance to execute
            task_function: Task function to execute (may be None in worker mode)
            task_definition: Optional TaskDefinition (for multi-task mode, to provide output schemas)

        Returns:
            Updated Thread instance with execution results
        """
        # E-5: Bind correlation IDs into structlog contextvars for the full
        # execution lifetime. Every downstream log line (including any fired
        # from inside the worker IPC callback or from task code via the
        # server's logger) will carry these keys automatically.
        _task_id_meta = (thread.metadata or {}).get("task_id") if thread.metadata else None
        with _bound_correlation_ids(
            thread_id=thread.id,
            task_id=_task_id_meta,
        ):
            return await self._execute_task_inner(thread, task_function, task_definition)

    async def _execute_task_inner(self, thread: Thread, task_function: Callable, task_definition: Optional[Any] = None) -> Thread:
        """Internal implementation of execute_task, called with correlation IDs already bound."""
        # Check if we should use worker mode
        # Python tasks need a venv_path, Node tasks do not.
        runtime = getattr(task_definition, "runtime", "python") if task_definition else "python"
        has_env = True
        if runtime == "python" and task_definition is not None:
            has_env = bool(getattr(task_definition, "venv_path", None))
            
        use_worker = (
            self.framework.execution_mode == "worker"
            and task_definition is not None
            and has_env
            and self.framework.worker_manager.has_worker(task_definition.full_id)
        )

        # Schedule-triggered threads (RunService) default to in-process execution so
        # cron ticks are not blocked on worker subprocess IPC from the scheduler loop.
        # Opt in with TASK_SCHEDULE_USE_WORKER=1/true/yes.
        schedule_tick = bool((thread.metadata or {}).get("_schedule_tick_execution"))
        if (
            schedule_tick
            and runtime == "python"
            and os.environ.get("TASK_SCHEDULE_USE_WORKER", "").lower() not in ("1", "true", "yes")
        ):
            use_worker = False

        # Non-Python tasks MUST run via worker — they cannot be executed in-process
        if runtime != "python" and not use_worker:
            raise RuntimeError(
                f"No worker available for {runtime} task '{getattr(task_definition, 'full_id', '?')}'. "
                f"The worker process may have failed to start. Check server logs for details."
            )
        
        # Extract task_id for per-task metrics and tracing
        _task_id = (thread.metadata or {}).get("task_id", "unknown")

        # Start APM transaction for task execution
        begin_transaction("task_execution", thread_id=thread.id, task_id=_task_id)

        # Transition to running state. We only set started_at the FIRST
        # time this transition happens so that retries/reruns preserve the
        # original queue-to-start latency (queue_duration_seconds is a
        # computed field that reads started_at - created_at).
        previous_state = thread.state
        thread.state = ThreadState.RUNNING
        if thread.started_at is None:
            thread.started_at = datetime.now(timezone.utc)

        # Stamp execution mode and dedicated worker identity (UI + GET /threads filters)
        md = dict(thread.metadata or {})
        if use_worker and task_definition is not None:
            md["worker_full_id"] = task_definition.full_id
            wm = getattr(self.framework, "worker_manager", None)
            if wm is not None:
                handle = wm.workers.get(task_definition.full_id)
                proc = getattr(handle, "process", None) if handle is not None else None
                pid = getattr(proc, "pid", None) if proc is not None else None
                if pid:
                    md["worker_pid"] = pid
            md["execution_mode"] = "worker"
        else:
            md["execution_mode"] = "in-process"
            md.pop("worker_full_id", None)
            md.pop("worker_pid", None)
        thread.metadata = md

        # Record queue-to-start latency
        if thread.created_at and thread.started_at:
            queue_time = (thread.started_at - thread.created_at).total_seconds()
            thread_queue_duration.record(queue_time, {"task_id": _task_id})

        # Persist running state immediately so the API reflects the executing state
        try:
            # Update thread in database to reflect the RUNNING transition
            await self.framework.database.update_thread(thread)
        except Exception:
            # Log but continue execution; DB update failures should not block task execution
            logger.exception("thread.execution.db_update_failed", thread_id=thread.id)

        # Update gauge for state transition (decrement previous, increment running)
        update_thread_state_gauge(previous_state, thread.state, task_id=_task_id)

        # C-3: publish thread.running event so webhook subscribers can observe
        # the start of execution. Documented in docs/features/webhooks.md and
        # docs/api/webhooks.md but was previously never fired.
        if self.framework.event_publisher is not None:
            try:
                await self.framework.event_publisher.publish(
                    event_type="thread.running",
                    thread_id=thread.id,
                    thread=thread,
                    metadata=thread.metadata,
                )
            except Exception:
                logger.exception(
                    "thread.execution.running_event_publish_failed",
                    thread_id=thread.id,
                )

        # Logging
        state_value = thread.state.value if hasattr(thread.state, "value") else str(thread.state)
        logger.info(
            "thread.execution.started",
            thread_id=thread.id,
            state=state_value,
            execution_mode="worker" if use_worker else "in-process",
        )

        # Push to thread log buffer for observability API
        if hasattr(self.framework, '_log_buffer') and self.framework._log_buffer:
            from nexora_tasks.models.log_models import LogEntry
            self.framework._log_buffer.append(thread.id, LogEntry(
                timestamp=thread.started_at,
                level="info",
                event="thread.execution.started",
                source="server",
                thread_id=thread.id,
                data={"execution_mode": "worker" if use_worker else "in-process"},
            ))

        # Publish thread.started event
        if self.framework.event_publisher:
            try:
                await self.framework.event_publisher.publish(
                    event_type="thread.started",
                    thread_id=thread.id,
                    thread=thread,
                    metadata=thread.metadata,
                )
            except Exception:
                logger.exception("thread.execution.started_event_failed", thread_id=thread.id)

        # Resolve task configuration (env vars and secrets)
        resolved_env_vars: Dict[str, str] = {}
        resolved_secrets: Dict[str, str] = {}
        
        if task_definition and self.framework.configuration_service:
            try:
                # Get runtime env overrides from thread params if present
                runtime_overrides = thread.params.get("_env_overrides")
                
                # Pass environment_id so env-scoped config is resolved
                env_id_for_config = (thread.metadata or {}).get("environment_id")
                
                resolved_config = await self.framework.configuration_service.resolve_configuration(
                    task_def=task_definition,
                    runtime_overrides=runtime_overrides,
                    validate=False,  # Don't fail, let task handle missing config
                    environment_id=env_id_for_config,
                )
                resolved_env_vars = resolved_config.env_vars
                resolved_secrets = resolved_config.secrets
                
                logger.debug(
                    "thread.execution.config_resolved",
                    thread_id=thread.id,
                    env_count=len(resolved_env_vars),
                    secret_count=len(resolved_secrets),
                )
                # Push config resolution to log buffer
                if hasattr(self.framework, '_log_buffer') and self.framework._log_buffer:
                    from nexora_tasks.models.log_models import LogEntry
                    self.framework._log_buffer.append(thread.id, LogEntry(
                        timestamp=datetime.now(timezone.utc),
                        level="info",
                        event="thread.execution.config_resolved",
                        source="server",
                        thread_id=thread.id,
                        data={"env_count": len(resolved_env_vars), "secret_count": len(resolved_secrets)},
                    ))
            except Exception as e:
                logger.warning(
                    "thread.execution.config_resolution_failed",
                    thread_id=thread.id,
                    error=str(e),
                )

        # ── Merge per-environment variables ─────────────────────────────
        # Environment-level env_vars serve as a base layer; task-specific
        # config values from ConfigurationService override them.
        env_id = (thread.metadata or {}).get("environment_id")
        if env_id and hasattr(self.framework, "environment_registry"):
            try:
                env_level_vars = await self.framework.environment_registry.get_env_vars(env_id)
                if env_level_vars:
                    # env_level_vars are the *base*; task config overrides them
                    processed_env_vars = {}
                    
                    for k, v in env_level_vars.items():
                        if isinstance(v, dict) and v.get("is_vault_ref"):
                            vault_key = v.get("vault_key")
                            if vault_key:
                                try:
                                    vault_val = await self.framework.credential_service.get_value(vault_key)
                                    if vault_val is not None:
                                        # Never override a secret already defined in task config
                                        if k not in resolved_secrets:
                                            resolved_secrets[k] = vault_val
                                except Exception as e:
                                    logger.warning(
                                        "thread.execution.env_vault_resolve_failed",
                                        thread_id=thread.id,
                                        key=k,
                                        vault_key=vault_key,
                                        error=str(e),
                                    )
                        else:
                            # Handle plain string, or backward compatible dict with "value"
                            if isinstance(v, dict):
                                processed_env_vars[k] = str(v.get("value", ""))
                            else:
                                processed_env_vars[k] = str(v)

                    processed_env_vars.update(resolved_env_vars)
                    resolved_env_vars = processed_env_vars
                    
                    logger.debug(
                        "thread.execution.env_vars_merged",
                        thread_id=thread.id,
                        environment_id=env_id,
                        env_level_count=len(env_level_vars),
                        merged_count=len(resolved_env_vars),
                        env_secrets_count=sum(1 for v in env_level_vars.values() if isinstance(v, dict) and v.get("is_vault_ref")),
                    )
            except Exception as e:
                logger.warning(
                    "thread.execution.env_vars_merge_failed",
                    thread_id=thread.id,
                    environment_id=env_id,
                    error=str(e),
                )
        
        # Route to worker or in-process execution
        if use_worker:
            return await self._execute_via_worker(
                thread, task_definition, resolved_env_vars, resolved_secrets,
                previous_state, _task_id,
            )
        else:
            return await self._execute_in_process(
                thread, task_function, task_definition,
                resolved_env_vars, resolved_secrets,
                previous_state, _task_id,
            )

    async def _execute_via_worker(
        self,
        thread: Thread,
        task_definition: Any,
        resolved_env_vars: Dict[str, str],
        resolved_secrets: Dict[str, str],
        previous_state: Any,
        _task_id: str = "unknown",
    ) -> Thread:
        """Execute task via worker subprocess.

        State transitions, DB updates, events, and metrics are handled here
        in the main process via :func:`apply_terminal_transition`. Only the
        task function call runs in the worker.
        """
        ctx = TransitionContext(
            framework=self.framework,
            task_id=_task_id,
            execution_mode="worker",
        )

        try:
            result = await self.framework.worker_manager.execute(
                task_def=task_definition,
                thread_id=thread.id,
                params=thread.params,
                metadata=thread.metadata,
                env_vars=resolved_env_vars,
                secrets=resolved_secrets,
                timeout_seconds=self.timeout_seconds,
            )

            status = result.get("status")

            # Check database state before marking success (prevent race condition with stop)
            db_thread = await self.framework.database.get_thread(thread.id)
            if db_thread and db_thread.state == ThreadState.STOPPED:
                logger.info(
                    "thread.execution.cancelled",
                    thread_id=thread.id,
                    message="Thread was stopped during worker execution, preserving STOPPED state",
                )
                return db_thread

            if status == "succeeded":
                # Re-read from DB to preserve progress updates written by _handle_progress
                fresh_thread = await self.framework.database.get_thread(thread.id)
                if fresh_thread:
                    thread = fresh_thread
                await apply_terminal_transition(thread, ThreadState.SUCCEEDED, ctx)

            elif status == "timeout":
                error_info = result.get("error", {})
                fresh_thread = await self.framework.database.get_thread(thread.id)
                if fresh_thread:
                    thread = fresh_thread
                err = ThreadError(
                    message=error_info.get("message", "Task execution timed out"),
                    exception_type="TimeoutError",
                    stack_trace=error_info.get("traceback", ""),
                )
                await apply_terminal_transition(
                    thread,
                    ThreadState.TIMEOUT,
                    ctx,
                    error=err,
                    error_type_label="TimeoutError",
                    log_extra={"error": "TimeoutError"},
                )

            else:  # failed
                error_info = result.get("error", {})
                fresh_thread = await self.framework.database.get_thread(thread.id)
                if fresh_thread:
                    thread = fresh_thread
                err = ThreadError(
                    message=error_info.get("message", "Task execution failed in worker"),
                    exception_type=error_info.get("type", "RuntimeError"),
                    stack_trace=error_info.get("traceback", ""),
                )
                await apply_terminal_transition(
                    thread,
                    ThreadState.FAILED,
                    ctx,
                    error=err,
                    error_type_label=error_info.get("type", "RuntimeError"),
                    log_extra={
                        "error": error_info.get("type", "Unknown"),
                        "error_message": error_info.get("message", ""),
                    },
                )

        except Exception as exc:
            # WorkerManager-level error (pipe broken, worker dead, etc.)
            db_thread = await self.framework.database.get_thread(thread.id)
            if db_thread and db_thread.state == ThreadState.STOPPED:
                return db_thread

            # Classify the error code so callers (and tests) can distinguish
            # worker crash events from normal task exceptions.
            _exc_msg = str(exc).lower()
            _error_code = (
                "WORKER_CRASHED"
                if "crashed" in _exc_msg or "restarting" in _exc_msg
                else "WORKER_ERROR"
            )
            err = ThreadError(
                message=f"Worker execution error: {str(exc)}",
                exception_type=type(exc).__name__,
                code=_error_code,
                stack_trace=traceback.format_exc(),
            )
            await apply_terminal_transition(
                thread,
                ThreadState.FAILED,
                ctx,
                error=err,
                error_type_label=type(exc).__name__,
                log_event_override="thread.execution.worker_error",
                log_extra={"error": str(exc)},
                event_type_override="thread.failed",
            )

        # End APM transaction for worker execution path
        _result = thread.state.value if hasattr(thread.state, "value") else str(thread.state)
        end_transaction(f"task.{_task_id}", result=_result)

        return thread

    async def _execute_in_process(
        self,
        thread: Thread,
        task_function: Callable,
        task_definition: Optional[Any],
        resolved_env_vars: Dict[str, str],
        resolved_secrets: Dict[str, str],
        previous_state: Any,
        _task_id: str = "unknown",
    ) -> Thread:
        """Execute task in-process (legacy mode, used for dev and fallback).

        State transitions, DB updates, events, and metrics are dispatched
        through :func:`apply_terminal_transition`. This is the original
        execution path with sys.path manipulation.
        """
        ctx = TransitionContext(framework=self.framework, task_id=_task_id)

        # Create context with resolved configuration
        context = TaskContext(
            thread_id=thread.id,
            metadata=thread.metadata,
            params=thread.params,
            framework=self.framework,
            task_definition=task_definition,
            env_vars=resolved_env_vars,
            secrets=resolved_secrets,
        )

        # Register context for cancellation propagation
        self._active_contexts[thread.id] = context

        try:
            # Resolve code_path for import isolation
            code_path = getattr(task_definition, 'code_path', None) if task_definition else None

            # Check if task function is async or sync
            if inspect.iscoroutinefunction(task_function):
                # Async: hold an asyncio.Lock for the entire task body so
                # concurrent in-process async tasks cannot interleave
                # sys.path mutations (M-4 / bug-4). The single-threaded event
                # loop alone is NOT sufficient: an async task can yield at
                # any ``await`` between _setup_task_paths and the first
                # import inside task_function.
                async with self._with_path_async(code_path):
                    if self.timeout_seconds:
                        result = await asyncio.wait_for(
                            task_function(context),
                            timeout=self.timeout_seconds,
                        )
                    else:
                        result = await task_function(context)
            else:
                # Sync: may run on thread pool, need thread lock for path setup.
                loop = asyncio.get_running_loop()
                if self.timeout_seconds:
                    result = await asyncio.wait_for(
                        loop.run_in_executor(
                            self._executor,
                            self._execute_sync_isolated,
                            task_function, context, code_path,
                        ),
                        timeout=self.timeout_seconds,
                    )
                else:
                    result = await loop.run_in_executor(
                        self._executor,
                        self._execute_sync_isolated,
                        task_function, context, code_path,
                    )

            # Check database state before marking success (prevent race condition with stop)
            db_thread = await self.framework.database.get_thread(thread.id)
            if db_thread and db_thread.state == ThreadState.STOPPED:
                logger.info(
                    "thread.execution.cancelled",
                    thread_id=thread.id,
                    message="Thread was stopped during execution, preserving STOPPED state",
                )
                # Use the database thread state instead of marking as succeeded.
                # The stop_thread() method already published thread.stopped event.
                thread = db_thread
            else:
                await apply_terminal_transition(thread, ThreadState.SUCCEEDED, ctx)

        except asyncio.TimeoutError:
            db_thread = await self.framework.database.get_thread(thread.id)
            if db_thread and db_thread.state == ThreadState.STOPPED:
                logger.info(
                    "thread.execution.cancelled",
                    thread_id=thread.id,
                    message="Thread was stopped during execution (timeout), preserving STOPPED state",
                )
                thread = db_thread
            else:
                err = ThreadError(
                    message="Task execution timed out",
                    exception_type="TimeoutError",
                    stack_trace="",
                )
                await apply_terminal_transition(
                    thread,
                    ThreadState.TIMEOUT,
                    ctx,
                    error=err,
                    error_type_label="TimeoutError",
                    log_extra={"error": "TimeoutError"},
                )

        except (asyncio.CancelledError, KeyboardInterrupt, SystemExit):
            # C-6: never swallow cancel/interrupt/exit. Catching these via
            # ``except BaseException`` previously coerced them into a FAILED
            # thread state, suppressed graceful-shutdown propagation, and
            # masked Ctrl-C in the foreground worker. Unregister the active
            # context so cancel_context() does not see a stale entry, then
            # re-raise to let the runtime tear the task down cleanly.
            context._completed = True
            self._active_contexts.pop(thread.id, None)
            raise
        except Exception as exc:
            db_thread = await self.framework.database.get_thread(thread.id)
            if db_thread and db_thread.state == ThreadState.STOPPED:
                logger.info(
                    "thread.execution.cancelled",
                    thread_id=thread.id,
                    message="Thread was stopped during execution (exception), preserving STOPPED state",
                )
                thread = db_thread
            else:
                err = ThreadError(
                    message=str(exc),
                    exception_type=type(exc).__name__,
                    stack_trace=traceback.format_exc(),
                )
                await apply_terminal_transition(
                    thread,
                    ThreadState.FAILED,
                    ctx,
                    error=err,
                    error_type_label=type(exc).__name__,
                    log_extra={
                        "error": type(exc).__name__,
                        "error_message": str(exc),
                    },
                )

        # Mark context as completed and unregister
        context._completed = True
        self._active_contexts.pop(thread.id, None)

        # End APM transaction for in-process execution path
        _result = thread.state.value if hasattr(thread.state, "value") else str(thread.state)
        end_transaction(f"task.{_task_id}", result=_result)

        return thread

    def cancel_context(self, thread_id: str) -> bool:
        """Cancel an active TaskContext by thread_id.
        
        In worker mode, sends a cancel message to the appropriate worker.
        In in-process mode, sets the cancelled flag on the TaskContext.
        
        Args:
            thread_id: Thread identifier
            
        Returns:
            True if context was found and cancelled, False otherwise
        """
        # Try in-process cancellation first
        context = self._active_contexts.get(thread_id)
        if context:
            # Set cancelled flag using object.__setattr__ to bypass Pydantic restrictions
            object.__setattr__(context, "_cancelled", True)
            logger.info(
                "thread.execution.cancellation_propagated",
                thread_id=thread_id,
                mode="in-process",
            )
            return True
        
        # Try worker cancellation — broadcast cancel to all workers; each
        # worker checks its own active_contexts and ignores the request if
        # the thread isn't running there. (bug-24: a previous loop scanning
        # ``handle.pending_executions`` here did nothing — exec_id cannot be
        # mapped back to thread_id from the parent process — and was removed.)
        if self.framework.execution_mode == "worker" and self.framework._worker_manager:
            for full_id, handle in self.framework.worker_manager.workers.items():
                self.framework.worker_manager.cancel_execution(handle.task_def, thread_id)
            
            logger.info(
                "thread.execution.cancellation_propagated",
                thread_id=thread_id,
                mode="worker",
            )
            return True
        
        return False

    def pause_context(self, thread_id: str) -> bool:
        """Pause an active TaskContext by thread_id.
        
        In worker mode, sends a pause message to the appropriate worker.
        In in-process mode, sets the paused flag on the TaskContext.
        
        Args:
            thread_id: Thread identifier
            
        Returns:
            True if context was found and paused, False otherwise
        """
        # Try in-process pause first
        context = self._active_contexts.get(thread_id)
        if context:
            object.__setattr__(context, "_paused", True)
            logger.info(
                "thread.execution.pause_propagated",
                thread_id=thread_id,
                mode="in-process",
            )
            return True
        
        # Broadcast pause to all workers
        if self.framework.execution_mode == "worker" and self.framework._worker_manager:
            for full_id, handle in self.framework.worker_manager.workers.items():
                self.framework.worker_manager.pause_execution(handle.task_def, thread_id)
            
            logger.info(
                "thread.execution.pause_propagated",
                thread_id=thread_id,
                mode="worker",
            )
            return True
        
        return False

    def resume_context(self, thread_id: str) -> bool:
        """Resume a paused TaskContext by thread_id.
        
        In worker mode, sends a resume message to the appropriate worker.
        In in-process mode, clears the paused flag on the TaskContext.
        
        Args:
            thread_id: Thread identifier
            
        Returns:
            True if context was found and resumed, False otherwise
        """
        # Try in-process resume first
        context = self._active_contexts.get(thread_id)
        if context:
            object.__setattr__(context, "_paused", False)
            logger.info(
                "thread.execution.resume_propagated",
                thread_id=thread_id,
                mode="in-process",
            )
            return True
        
        # Broadcast resume to all workers
        if self.framework.execution_mode == "worker" and self.framework._worker_manager:
            for full_id, handle in self.framework.worker_manager.workers.items():
                self.framework.worker_manager.resume_execution(handle.task_def, thread_id)
            
            logger.info(
                "thread.execution.resume_propagated",
                thread_id=thread_id,
                mode="worker",
            )
            return True
        
        return False

    def create_thread(
        self,
        thread_id: str,
        metadata: dict[str, Any],
        params: dict[str, Any],
        name: Optional[str] = None,
    ) -> Thread:
        """Create a new thread for execution.

        Args:
            thread_id: Unique thread identifier
            metadata: Thread metadata
            params: Task-specific parameters
            name: Optional thread name for display and grouping

        Returns:
            New Thread instance in QUEUED state
        """
        thread = Thread(
            id=thread_id,
            name=name,
            state=ThreadState.QUEUED,
            metadata=metadata,
            params=params,
            created_at=datetime.now(timezone.utc),
        )

        # Metrics - increment counter for thread creation (only place threads_total is incremented)
        state_value = thread.state.value if hasattr(thread.state, 'value') else str(thread.state)
        _task_id = (metadata or {}).get("task_id", "unknown")
        threads_total.add(1, {"state": state_value, "task_id": _task_id})

        # Update gauge to reflect new queued thread
        threads_current.add(1, {"state": state_value, "task_id": _task_id})

        return thread

