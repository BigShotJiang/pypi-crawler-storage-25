"""Concurrency policy handler for enforcing run concurrency rules."""

from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any, AsyncIterator, Optional

from nexora_tasks.logging import logger
from nexora_tasks.models.schedule import ConcurrencyPolicy, Run, RunState, Schedule

if TYPE_CHECKING:
    from nexora_tasks_server.interfaces.database import Database
    from nexora_tasks_server.services.artifact_service import ArtifactService
    from nexora_tasks_server.services.thread_service import ThreadService


class ConcurrencyPolicyHandler:
    """Handler for enforcing concurrency policies."""

    # Per-schedule lock TTL: long enough that a slow REPLACE (which
    # cancels the predecessor's threads/artifacts) can complete before
    # the lock expires, short enough that a crashed worker doesn't
    # wedge the schedule for minutes.
    _POLICY_LOCK_TTL_SECONDS = 60
    _POLICY_LOCK_WAIT_TIMEOUT_SECONDS = 30.0

    def __init__(
        self,
        database: "Database",
        artifact_service: Optional["ArtifactService"] = None,
        thread_service: Optional["ThreadService"] = None,
        lock_manager: Optional[Any] = None,
    ) -> None:
        """Initialize ConcurrencyPolicyHandler.

        Args:
            database: Database implementation
            artifact_service: Optional ArtifactService for deleting artifacts
            thread_service: Optional ThreadService for stopping threads
            lock_manager: Optional ``ElasticsearchDistributedLock`` used to
                serialise FORBID/REPLACE policy checks across replicas.
                Without it the read-then-enforce sequence has a TOCTOU
                window where two concurrent ticks can both observe "no
                running run" and double-spawn (C-5). File storage mode
                passes None — there is only one process so the in-memory
                run state is consistent.
        """
        self.database = database
        self.artifact_service = artifact_service
        self.thread_service = thread_service
        self.lock_manager = lock_manager

    @asynccontextmanager
    async def _serialise_policy_check(
        self, schedule_id: str
    ) -> AsyncIterator[None]:
        """Serialise FORBID/REPLACE read-then-enforce across replicas.

        Reuses the existing ``ElasticsearchDistributedLock`` module so the
        critical section spans both the running-run query AND the
        side-effect that follows (skip new run, or stop predecessor).

        If no lock manager is configured (file storage / single-process
        mode) we fall through without locking.
        """
        if self.lock_manager is None:
            yield
            return

        lock_key = f"schedule:{schedule_id}"
        acquired = False
        try:
            acquired = await self.lock_manager.acquire(
                lock_key,
                ttl_seconds=self._POLICY_LOCK_TTL_SECONDS,
                wait=True,
                wait_timeout=self._POLICY_LOCK_WAIT_TIMEOUT_SECONDS,
            )
            if not acquired:
                # Another replica is currently enforcing policy for this
                # schedule. Bail out — the current tick will be re-driven
                # at the next cron firing if needed.
                logger.warning(
                    "schedule.run.concurrency.lock_unavailable",
                    schedule_id=schedule_id,
                    lock_key=lock_key,
                )
            yield acquired  # type: ignore[misc] - sentinel for caller to inspect
        finally:
            if acquired:
                try:
                    await self.lock_manager.release(lock_key)
                except Exception as e:  # noqa: BLE001
                    logger.warning(
                        "schedule.run.concurrency.lock_release_failed",
                        schedule_id=schedule_id,
                        lock_key=lock_key,
                        error=str(e),
                    )

    async def check_and_enforce(
        self,
        schedule: Schedule,
        new_run: Run,
    ) -> bool:
        """Check concurrency policy and enforce if needed.

        Args:
            schedule: Schedule instance
            new_run: New run to be created

        Returns:
            True if run should proceed, False if run should be skipped
        """
        policy = schedule.concurrency_policy

        if policy == ConcurrencyPolicy.ALLOW:
            # No checking, proceed directly
            return True

        elif policy == ConcurrencyPolicy.FORBID:
            # C-5: serialise read+enforce. Without this lock two ticks
            # firing within the TOCTOU window both observe "no running
            # run" and double-spawn.
            async with self._serialise_policy_check(schedule.id) as acquired:
                if self.lock_manager is not None and not acquired:
                    # Could not acquire — treat as conflict, skip new run.
                    await self._enforce_forbid(new_run)
                    return False
                if await self._has_running_run(schedule.id):
                    # Skip new run
                    await self._enforce_forbid(new_run)
                    return False
                # No running run, proceed
                return True

        elif policy == ConcurrencyPolicy.REPLACE:
            # C-5: serialise read+enforce so two concurrent ticks don't
            # both see the SAME predecessor and try to stop it twice
            # (or worse, both spawn a new run alongside it).
            async with self._serialise_policy_check(schedule.id) as acquired:
                if self.lock_manager is not None and not acquired:
                    # Could not acquire — skip this tick to be safe; the
                    # holder of the lock is already enforcing policy.
                    await self._enforce_forbid(new_run)
                    return False
                running_run = await self._get_running_run(schedule.id)
                if running_run:
                    # Stop previous run and delete artifacts
                    await self._enforce_replace(running_run)
                # Always proceed with new run
                return True

        else:
            # Unknown policy, log warning and proceed
            logger.warning(
                "schedule.run.concurrency.unknown_policy",
                schedule_id=schedule.id,
                policy=policy.value if hasattr(policy, 'value') else str(policy),
            )
            return True

    async def _has_running_run(self, schedule_id: str) -> bool:
        """Check if schedule has a running run.
        
        Args:
            schedule_id: Schedule identifier
            
        Returns:
            True if running run exists, False otherwise
        """
        running_run = await self.database.get_running_run_by_schedule(schedule_id)
        return running_run is not None

    async def _get_running_run(self, schedule_id: str) -> Optional[Run]:
        """Get the currently running run for a schedule.
        
        Args:
            schedule_id: Schedule identifier
            
        Returns:
            Running Run instance if found, None otherwise
        """
        return await self.database.get_running_run_by_schedule(schedule_id)

    async def _enforce_forbid(self, run: Run) -> None:
        """Enforce forbid policy by skipping the run.
        
        Args:
            run: Run instance to skip
        """
        run.state = RunState.SKIPPED
        run.finished_at = run.created_at  # Set finished_at to created_at for skipped runs
        await self.database.update_run(run)
        
        # Logging
        logger.info(
            "schedule.run.skipped",
            schedule_id=run.schedule_id,
            run_id=run.run_id,
            reason="forbid_policy_conflict",
        )

    async def _enforce_replace(self, previous_run: Run) -> None:
        """Enforce replace policy by stopping previous run and deleting artifacts.
        
        Args:
            previous_run: Previous run instance to stop
        """
        # Stop previous run
        previous_run.state = RunState.STOPPED
        from datetime import datetime, timezone
        
        previous_run.finished_at = datetime.now(timezone.utc)
        await self.database.update_run(previous_run)
        
        # Stop threads synchronously
        if self.thread_service:
            for thread_id in previous_run.threads:
                try:
                    thread = await self.database.get_thread(thread_id)
                    if thread:
                        # Handle both enum and string values (due to use_enum_values=True)
                        thread_state = thread.state.value if hasattr(thread.state, 'value') else str(thread.state)
                        if thread_state in ["queued", "running"]:
                            await self.thread_service.stop_thread(
                                thread_id=thread_id,
                                user_id=None,
                                app_id=None,
                                is_admin=False,
                            )
                except Exception as e:
                    logger.warning(
                        "schedule.run.replace.thread_stop_failed",
                        schedule_id=previous_run.schedule_id,
                        run_id=previous_run.run_id,
                        thread_id=thread_id,
                        error=str(e),
                    )
        
        # Delete artifacts synchronously
        if self.artifact_service:
            for thread_id in previous_run.threads:
                try:
                    artifacts = await self.database.get_thread_artifacts(thread_id)
                    for artifact in artifacts:
                        await self.artifact_service.delete_artifact(
                            artifact_id=artifact.id,
                            user_id=None,
                            app_id=None,
                            is_admin=False,
                        )
                except Exception as e:
                    logger.warning(
                        "schedule.run.replace.artifact_delete_failed",
                        schedule_id=previous_run.schedule_id,
                        run_id=previous_run.run_id,
                        thread_id=thread_id,
                        error=str(e),
                    )
        
        # Logging
        logger.info(
            "schedule.run.replaced",
            schedule_id=previous_run.schedule_id,
            previous_run_id=previous_run.run_id,
            reason="replace_policy",
        )

