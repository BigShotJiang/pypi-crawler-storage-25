"""Distributed tracing — OpenTelemetry-backed façade.

This module preserves the public API (``init_tracing``, ``begin_transaction``,
``end_transaction``, ``label``, ``capture_span``, ``get_trace_parent_header``,
``set_custom_context``) so existing call sites in ``execution.py``,
``worker_manager.py`` and elsewhere don't change. Internally it dispatches to
the OpenTelemetry API.

Domain attributes are namespaced as ``nexora_tasks.<name>`` per the
project's semantic conventions registry.

The façade itself will be removed in a follow-up cleanup PR; new code should
call ``opentelemetry.trace.get_tracer(__name__)`` directly.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Any, Dict, Optional

from opentelemetry import context as otel_context
from opentelemetry import trace
from opentelemetry.trace import Span, Status, StatusCode

from nexora_tasks_server.observability import init_otel

_NAMESPACE = "nexora_tasks"
_TRACER_NAME = "nexora_tasks_server.tracing"

# Stack of active spans started by begin_transaction, so end_transaction can
# close them and capture_span can attach as a child of the most recent.
# Each entry is (span, context_token) so we can detach the context on end.
_active_spans: list[tuple[Span, object]] = []


def init_tracing(app=None) -> None:
    """Initialize tracing for the server process.

    Thin wrapper around ``init_otel`` that supplies the server's
    ``service_name`` and attaches the FastAPI middleware when an app is
    provided.
    """
    init_otel(
        service_name=os.getenv(
            "OTEL_SERVICE_NAME", "nexora-tasks-server"
        ),
        service_namespace=os.getenv(
            "OTEL_SERVICE_NAMESPACE", "nexora-tasks"
        ),
        instrument_fastapi_app=app,
        enable_logs=True,
        enable_metrics=True,
    )


def _tracer():
    return trace.get_tracer(_TRACER_NAME)


def _disabled() -> bool:
    return os.getenv("OTEL_SDK_DISABLED", "").lower() in ("true", "1")


def begin_transaction(transaction_type: str, name: str = "", **labels) -> None:
    """Begin a new top-level span and push it on the active stack.

    The span name defaults to ``transaction_type`` when ``name`` is empty.
    All ``labels`` are stored as ``nexora_tasks.<key>`` attributes.
    """
    if _disabled():
        return
    span_name = name or transaction_type
    span = _tracer().start_span(span_name)
    span.set_attribute(f"{_NAMESPACE}.transaction_type", transaction_type)
    for key, value in labels.items():
        span.set_attribute(f"{_NAMESPACE}.{key}", _coerce(value))
    token = otel_context.attach(trace.set_span_in_context(span))
    _active_spans.append((span, token))


_SUCCESS_RESULTS = frozenset({"success", "succeeded", "ok"})


def end_transaction(name: str, result: str = "success") -> None:
    """End the most recently begun transaction span.

    ``name`` is recorded as ``nexora_tasks.transaction_name``; ``result``
    is mapped to ``Status.OK`` for any of ``{"success", "succeeded", "ok"}``
    and ``Status.ERROR`` otherwise. Server callsites pass thread states
    ("succeeded"); the broader set keeps backwards compat with literal
    "success" used in tests.
    """
    if _disabled() or not _active_spans:
        return
    span, token = _active_spans.pop()
    span.set_attribute(f"{_NAMESPACE}.transaction_name", name)
    span.set_attribute(f"{_NAMESPACE}.result", result)
    if result in _SUCCESS_RESULTS:
        span.set_status(Status(StatusCode.OK))
    else:
        span.set_status(Status(StatusCode.ERROR, description=result))
    span.end()
    otel_context.detach(token)


@contextmanager
def capture_span(name: str, span_type: str = "custom", **extra):
    """Context manager for a child span under the current active span.

    Falls back to a no-op generator when OTel is disabled.
    """
    if _disabled():
        yield
        return
    with _tracer().start_as_current_span(name) as span:
        span.set_attribute(f"{_NAMESPACE}.span_type", span_type)
        for key, value in extra.items():
            span.set_attribute(f"{_NAMESPACE}.{key}", _coerce(value))
        yield


def get_trace_parent_header() -> Optional[str]:
    """Return the current W3C ``traceparent`` header for cross-process propagation."""
    if _disabled():
        return None
    span = trace.get_current_span()
    ctx = span.get_span_context() if span else None
    if not ctx or not ctx.is_valid:
        # Fall back to the most recent transaction span if available
        if _active_spans:
            ctx = _active_spans[-1][0].get_span_context()
        else:
            return None
    sampled_flag = "01" if ctx.trace_flags.sampled else "00"
    return (
        f"00-{format(ctx.trace_id, '032x')}"
        f"-{format(ctx.span_id, '016x')}-{sampled_flag}"
    )


def set_custom_context(data: Dict[str, Any]) -> None:
    """Attach custom attributes to the current span.

    Keys are namespaced as ``nexora_tasks.<key>``.
    """
    if _disabled():
        return
    span = trace.get_current_span()
    if not span or not span.get_span_context().is_valid:
        if _active_spans:
            span = _active_spans[-1][0]
        else:
            return
    for key, value in (data or {}).items():
        span.set_attribute(f"{_NAMESPACE}.{key}", _coerce(value))


def label(**labels) -> None:
    """Add labels to the current transaction span as ``nexora_tasks.<key>``."""
    if _disabled():
        return
    span = trace.get_current_span()
    if not span or not span.get_span_context().is_valid:
        if _active_spans:
            span = _active_spans[-1][0]
        else:
            return
    for key, value in labels.items():
        span.set_attribute(f"{_NAMESPACE}.{key}", _coerce(value))


def get_apm_client():
    """Compatibility shim — returns ``None``. Use ``opentelemetry.trace`` directly."""
    return None


def _coerce(value: Any) -> Any:
    """Coerce attribute values to OTel-supported primitive types."""
    if isinstance(value, (str, bool, int, float)):
        return value
    if value is None:
        return ""
    return str(value)
