"""Proxy server creation and integration (M-11).

Migrated to a single ``lifespan`` async context manager — the legacy
``@app.on_event("startup")`` / ``@app.on_event("shutdown")`` pair is
deprecated in FastAPI ≥ 0.110.
"""

import os
from typing import Any, Optional

from fastapi import FastAPI

from nexora_tasks.version import VERSION as SDK_VERSION
from nexora_tasks_server.health import HealthChecker
from nexora_tasks_server.lifecycle import build_proxy_lifespan
from nexora_tasks_server.proxy_registry import ServiceRegistry
from nexora_tasks_server.version import VERSION


def create_proxy_server(
    registry: Optional[ServiceRegistry] = None,
    health_check_interval: int = 10,
    admin_api_keys: Optional[list[str]] = None,
    **options: Any,
) -> FastAPI:
    """Create FastAPI proxy server application.

    Args:
        registry: ServiceRegistry instance (creates new if None)
        health_check_interval: Health check interval in seconds
        admin_api_keys: List of admin API keys for authentication
        **options: Additional options

    Returns:
        FastAPI application instance configured as proxy server
    """
    if registry is None:
        persistence_file = os.getenv("PROXY_REGISTRY_FILE", None)
        registry = ServiceRegistry(persistence_file=persistence_file)

    health_checker = HealthChecker(
        registry=registry,
        default_interval_seconds=health_check_interval,
    )

    openapi_tags = [
        {
            "name": "proxy-admin",
            "description": "**Admin only.** Server enrollment management. Enroll, update, and remove backend task servers.",
        },
        {
            "name": "proxy-discovery",
            "description": "Server discovery. List enrolled servers and aggregate OpenAPI specifications.",
        },
    ]

    app = FastAPI(
        title="Nexora Tasks Proxy",
        version=VERSION,
        openapi_version="3.1.0",
        description="Centralized proxy server for forwarding client requests to enrolled Nexora Tasks servers. "
                    "Provides a single entry point with automatic routing based on server ID or task type.",
        openapi_tags=openapi_tags,
        license_info={"name": "MIT", "identifier": "MIT"},
        contact={"name": "Nexora Tasks"},
        lifespan=build_proxy_lifespan(health_checker, health_check_interval),
    )

    app.state.registry = registry
    app.state.health_checker = health_checker

    # Elastic APM tracing — no-op if not configured.
    from nexora_tasks_server.tracing import init_tracing

    init_tracing(app)

    @app.get("/health")
    async def health_check() -> dict[str, Any]:
        """Proxy health check endpoint."""
        from datetime import datetime, timezone

        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        return {
            "status": "ok",
            "timestamp": timestamp,
            "version": VERSION,
            "sdk_version": SDK_VERSION,
            "type": "proxy",
        }

    # Admin API router — admin endpoints are proxy-only and MUST NOT be
    # forwarded to backend task servers.
    from nexora_tasks_server.api import proxy_admin
    from nexora_tasks_server.dependencies import set_framework_for_app
    from nexora_tasks_server.framework import NexoraTasks

    if admin_api_keys:
        # Bind to this app's state so concurrent FastAPI apps don't share a
        # module-level global (M-12).
        temp_framework = NexoraTasks(
            api_keys=["dummy"],
            admin_api_keys=admin_api_keys,
        )
        set_framework_for_app(app, temp_framework)

    app.include_router(proxy_admin.router)

    from nexora_tasks_server.api import proxy_discovery

    app.include_router(proxy_discovery.router)

    from nexora_tasks import ui

    app.include_router(ui.router)

    # Catch-all proxy router LAST — must come after all specific routes.
    from nexora_tasks_server.api import proxy

    app.include_router(proxy.router)

    return app
