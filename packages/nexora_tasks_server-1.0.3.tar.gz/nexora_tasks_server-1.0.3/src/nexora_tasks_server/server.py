"""FastAPI server creation and startup with OpenAPI 3.1.0 specification (M-11).

The original 727-line ``create_server`` god-function has been decomposed
into single-responsibility helpers (lifecycle / routers / middleware /
health) so this entry point can stay small and inspectable. Behaviour
is preserved end-to-end:

  - 6× deprecated ``@app.on_event`` hooks → single ``lifespan`` async
    context manager (see ``lifecycle.build_lifespan``).
  - Every ``app.include_router`` call lives in ``routers.register_routers``.
  - CORS + rate limit + request tracking + tracing live in
    ``app_middleware.register_middleware`` (M-15, M-17).
  - ``/health`` definition lives in ``health_endpoints.register_health``.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI

from nexora_tasks_server.app_middleware import register_middleware
from nexora_tasks_server.health_endpoints import register_health
from nexora_tasks_server.lifecycle import build_lifespan
from nexora_tasks_server.openapi_meta import API_DESCRIPTION, OPENAPI_TAGS
from nexora_tasks_server.routers import register_routers
from nexora_tasks_server.version import VERSION

if TYPE_CHECKING:
    from nexora_tasks_server.framework import NexoraTasks


def _docs_disabled() -> bool:
    """Return True if OpenAPI/Swagger surfaces should be hidden (F-7).

    Production hides ``/docs``, ``/redoc``, and ``/openapi.json`` so the
    API surface is not enumerable without auth. Override by setting
    ``TASK_FRAMEWORK_DOCS=1`` if Swagger is desired in production
    (e.g. behind a private network).
    """
    deploy_env = os.environ.get("TASK_FRAMEWORK_ENV", "").lower()
    force_docs = os.environ.get("TASK_FRAMEWORK_DOCS", "").lower() in (
        "1", "true", "yes", "on",
    )
    return deploy_env in ("production", "prod") and not force_docs


def create_server(
    framework: "NexoraTasks",
    port: int = 3000,
    host: str = "0.0.0.0",
    **options: Any,
) -> FastAPI:
    """Create the FastAPI application.

    Composition root only — every concern (lifespan / routers /
    middleware / health) lives in its own module and is wired in below.

    Args:
        framework: NexoraTasks instance.
        port: Server port (default: 3000).
        host: Server host (default: 0.0.0.0).
        **options: Reserved for forward-compatible flags (currently unused).

    Returns:
        Configured FastAPI application.
    """
    # Bind framework to app.state (preferred, override-friendly) and mirror
    # to the legacy global for non-HTTP callers (M-12). Must run before any
    # router import that captures ``Depends(get_framework)`` at definition.
    from nexora_tasks_server.dependencies import set_framework_for_app

    docs_disabled = _docs_disabled()
    app = FastAPI(
        title="Nexora Tasks API",
        version=VERSION,
        openapi_version="3.1.0",
        description=API_DESCRIPTION,
        openapi_tags=OPENAPI_TAGS,
        license_info={"name": "MIT", "identifier": "MIT"},
        contact={"name": "Nexora Tasks"},
        docs_url=None if docs_disabled else "/docs",
        redoc_url=None if docs_disabled else "/redoc",
        openapi_url=None if docs_disabled else "/openapi.json",
        lifespan=build_lifespan(framework),
    )

    # M-12: bind framework to this FastAPI app's state. Tests can scope an
    # override via ``app.dependency_overrides[get_framework]`` and two apps
    # in the same process don't stomp on each other through a shared global.
    set_framework_for_app(app, framework)

    register_middleware(app)
    register_health(app, framework)
    register_routers(app)

    return app


def main() -> None:
    """Entry point for the nexora-tasks server.

    Referenced by pyproject.toml [project.scripts]:
        task-server = "nexora_tasks_server.server:main"

    Also callable via:
        python -m nexora_tasks_server.server
        uv run task-server
    """
    import uvicorn

    from nexora_tasks_server.framework import NexoraTasks

    port = int(os.environ.get("PORT", "3000"))
    host = os.environ.get("HOST", "0.0.0.0")
    log_level = os.environ.get("LOG_LEVEL", "INFO").lower()
    base_path = os.environ.get("BASE_PATH", os.environ.get("DATA_DIR", "."))

    api_keys_str = os.environ.get("API_KEYS", "")
    admin_api_keys_str = os.environ.get("ADMIN_API_KEYS", "")
    api_keys = [k.strip() for k in api_keys_str.split(",") if k.strip()]
    admin_api_keys = [k.strip() for k in admin_api_keys_str.split(",") if k.strip()]

    if not api_keys:
        print("ERROR: API_KEYS environment variable is required (comma-separated list)")
        raise SystemExit(1)
    if not admin_api_keys:
        print("ERROR: ADMIN_API_KEYS environment variable is required (comma-separated list)")
        raise SystemExit(1)

    framework = NexoraTasks(
        api_keys=api_keys,
        admin_api_keys=admin_api_keys,
        base_path=base_path,
    )
    app = create_server(framework, port=port, host=host)

    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level=log_level,
        access_log=True,
    )


if __name__ == "__main__":
    main()
