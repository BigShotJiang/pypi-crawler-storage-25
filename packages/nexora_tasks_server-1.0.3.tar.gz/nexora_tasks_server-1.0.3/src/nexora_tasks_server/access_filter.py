"""Access control filtering for resources based on authentication metadata.

The filter enforces two layers of scoping:

1. **Environment scoping** — every resource is bound to an environment via either
   ``metadata['environment_id']`` (generic resources) or a first-class
   ``environment_id`` field (webhooks). System-level admin keys (those configured
   via ``ADMIN_API_KEYS`` and resolved with ``environment_id == 'default'``) bypass
   environment scoping. Environment-bound admin keys can only see resources in
   their bound environment.

2. **User/app scoping** — non-admin (regular) keys can only see resources whose
   ``user_id`` and ``app_id`` (in metadata, or first-class fields for webhooks)
   match the authenticated request.

For resources that the caller may not access, ``ensure_can_access`` raises
``HTTPException(404)`` rather than 403 to avoid leaking the existence of
resources the caller cannot see.
"""

from typing import Any, Dict, List, Optional

from fastapi import HTTPException, status

from nexora_tasks.errors import problem_json_dict
from nexora_tasks_server.dependencies import AuthenticatedRequest


def _extract_metadata(resource: Any) -> Optional[Dict[str, Any]]:
    """Extract a metadata dict from either a dict or a Pydantic model.

    Args:
        resource: Resource as a dict, BaseModel, or any object with a
            ``metadata`` attribute.

    Returns:
        Metadata dictionary, or ``None`` if no metadata could be extracted.
    """
    if resource is None:
        return None

    # dict-shaped
    if isinstance(resource, dict):
        meta = resource.get("metadata")
        if isinstance(meta, dict):
            return meta
        return None

    # Pydantic model or generic object
    meta = getattr(resource, "metadata", None)
    if isinstance(meta, dict):
        return meta

    # Fall back to model_dump() for safety
    if hasattr(resource, "model_dump"):
        try:
            dump = resource.model_dump()
            meta = dump.get("metadata") if isinstance(dump, dict) else None
            if isinstance(meta, dict):
                return meta
        except Exception:
            pass

    return None


def _is_system_admin(auth: AuthenticatedRequest) -> bool:
    """Check whether ``auth`` represents a system-level admin (cross-env)."""
    return auth.key_type == "admin" and auth.environment_id == "default"


def _resource_matches(
    resource: Any,
    auth: AuthenticatedRequest,
) -> bool:
    """Return True if the (generic) resource is visible to ``auth``.

    bug-12: never return True when both sides of an identity check are
    ``None``. Two ``None``s comparing equal previously meant an env-bound
    admin (``auth.environment_id == None`` for legacy/test fixtures) or a
    regular key with missing metadata could see resources whose own
    ``environment_id`` was unset. We now require both sides to be a
    non-None string before they're allowed to match.
    """
    metadata = _extract_metadata(resource)
    if metadata is None:
        # No metadata means we cannot prove ownership — deny for non-system-admins.
        return _is_system_admin(auth)

    resource_env = metadata.get("environment_id")
    resource_user = metadata.get("user_id")
    resource_app = metadata.get("app_id")

    if auth.key_type == "admin":
        # System-level admin: bypass everything.
        if _is_system_admin(auth):
            return True
        # Environment-bound admin: see everything in their env, but never
        # match resources whose env is missing/None against an admin whose
        # env is missing/None (bug-12 — refuse the None==None coincidence).
        if resource_env is None or auth.environment_id is None:
            return False
        return resource_env == auth.environment_id

    # Regular key: must match all three. Reject any None==None coincidence
    # (bug-12) — every field on both sides must be a real string.
    if (
        resource_env is None
        or resource_user is None
        or resource_app is None
        or auth.environment_id is None
        or auth.user_id is None
        or auth.app_id is None
    ):
        return False
    return (
        resource_env == auth.environment_id
        and resource_user == auth.user_id
        and resource_app == auth.app_id
    )


class AccessFilter:
    """Utility class for filtering resources based on authentication metadata."""

    # ── Generic resources (metadata-based) ────────────────────────────────────

    @staticmethod
    def filter_resources(
        resources: List[Any],
        auth: AuthenticatedRequest,
    ) -> List[Any]:
        """Filter a list of resources, returning only those accessible to ``auth``.

        Resources may be dicts or Pydantic models — both are supported. Resources
        without a ``metadata`` dict are dropped for non-system-admin callers.

        Args:
            resources: Iterable of resources (dicts or models).
            auth: Authenticated request context.

        Returns:
            New list containing only the resources visible to ``auth``.
        """
        from nexora_tasks.logging import logger

        if _is_system_admin(auth):
            logger.info(
                "access_control.filtered",
                key_type=auth.key_type,
                user_id=auth.user_id,
                app_id=auth.app_id,
                environment_id=auth.environment_id,
                filtered_count=len(resources),
                total_count=len(resources),
                bypass="system_admin",
            )
            return list(resources)

        filtered = [r for r in resources if _resource_matches(r, auth)]

        logger.info(
            "access_control.filtered",
            key_type=auth.key_type,
            user_id=auth.user_id,
            app_id=auth.app_id,
            environment_id=auth.environment_id,
            filtered_count=len(filtered),
            total_count=len(resources),
        )

        return filtered

    @staticmethod
    def check_resource_access(
        resource: Any,
        auth: AuthenticatedRequest,
    ) -> bool:
        """Return True if ``resource`` is accessible to ``auth``."""
        if _is_system_admin(auth):
            return True
        return _resource_matches(resource, auth)

    @staticmethod
    def ensure_can_access(
        resource: Any,
        auth: AuthenticatedRequest,
        resource_kind: str = "Resource",
        resource_id: Optional[str] = None,
    ) -> None:
        """Raise HTTPException(404) if ``resource`` is not accessible to ``auth``.

        Uses 404 rather than 403 so callers cannot probe for the existence of
        resources they cannot see.

        Args:
            resource: Resource to check.
            auth: Authenticated request context.
            resource_kind: Human-readable resource type used in the error detail.
            resource_id: Optional identifier for the error detail.

        Raises:
            HTTPException: 404 if the access check fails.
        """
        if AccessFilter.check_resource_access(resource, auth):
            return

        ident = f" '{resource_id}'" if resource_id else ""
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"{resource_kind}{ident} not found",
                code="RESOURCE_NOT_FOUND",
            ),
        )

    # ── Webhook-specific (first-class fields, not metadata) ───────────────────

    @staticmethod
    def _webhook_matches(webhook: Any, auth: AuthenticatedRequest) -> bool:
        """Return True if ``webhook`` is visible to ``auth``.

        bug-12: same None==None hardening as ``_resource_matches`` —
        require all identity fields to be real strings on both sides
        before allowing equality to grant access.
        """
        if webhook is None:
            return False

        if isinstance(webhook, dict):
            wh_env = webhook.get("environment_id")
            wh_user = webhook.get("created_by_user_id")
            wh_app = webhook.get("created_by_app_id")
        else:
            wh_env = getattr(webhook, "environment_id", None)
            wh_user = getattr(webhook, "created_by_user_id", None)
            wh_app = getattr(webhook, "created_by_app_id", None)

        if auth.key_type == "admin":
            if _is_system_admin(auth):
                return True
            # Env-bound admin: refuse None==None coincidence.
            if wh_env is None or auth.environment_id is None:
                return False
            return wh_env == auth.environment_id

        # Regular key: every identity field must be a real string on both sides.
        if (
            wh_env is None
            or wh_user is None
            or wh_app is None
            or auth.environment_id is None
            or auth.user_id is None
            or auth.app_id is None
        ):
            return False
        return (
            wh_env == auth.environment_id
            and wh_user == auth.user_id
            and wh_app == auth.app_id
        )

    @staticmethod
    def filter_webhooks(
        webhooks: List[Any],
        auth: AuthenticatedRequest,
    ) -> List[Any]:
        """Filter a list of webhooks by access rules."""
        from nexora_tasks.logging import logger

        if _is_system_admin(auth):
            logger.info(
                "access_control.webhooks_filtered",
                key_type=auth.key_type,
                filtered_count=len(webhooks),
                total_count=len(webhooks),
                bypass="system_admin",
            )
            return list(webhooks)

        filtered = [w for w in webhooks if AccessFilter._webhook_matches(w, auth)]
        logger.info(
            "access_control.webhooks_filtered",
            key_type=auth.key_type,
            user_id=auth.user_id,
            app_id=auth.app_id,
            environment_id=auth.environment_id,
            filtered_count=len(filtered),
            total_count=len(webhooks),
        )
        return filtered

    @staticmethod
    def check_webhook_access(webhook: Any, auth: AuthenticatedRequest) -> bool:
        """Return True if ``webhook`` is accessible to ``auth``."""
        if _is_system_admin(auth):
            return True
        return AccessFilter._webhook_matches(webhook, auth)

    @staticmethod
    def ensure_can_access_webhook(
        webhook: Any,
        auth: AuthenticatedRequest,
        webhook_id: Optional[str] = None,
    ) -> None:
        """Raise HTTPException(404) if the webhook is not accessible to ``auth``."""
        if AccessFilter.check_webhook_access(webhook, auth):
            return

        ident = f" '{webhook_id}'" if webhook_id else ""
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=problem_json_dict(
                status_code=status.HTTP_404_NOT_FOUND,
                title="Not Found",
                detail=f"Webhook{ident} not found",
                code="WEBHOOK_NOT_FOUND",
            ),
        )
