"""Per-user admin authentication primitives.

2.16.0 introduces per-user admin accounts on top of the legacy global
``RDD_ADMIN_PIN``:

  * Operators can be flagged ``is_admin`` on ``operator_preferences``.
  * The first time an admin operator performs an admin action, they
    pick their own password — stored as a PBKDF2-HMAC-SHA256 hash with
    a per-user random salt.
  * Subsequent admin actions verify a short-lived session token (set
    as a ``rdd_admin_session`` HttpOnly cookie) signed with the server
    settings ``settings_secret_key``.

The hash + token primitives intentionally avoid any third-party
dependencies — only the Python standard library — so a fresh
``pip install remote-desktop-dashboard`` brings nothing new.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import time
from dataclasses import dataclass

# PBKDF2 parameters. 200_000 iterations is fast enough on modern
# hardware (~80ms on a laptop) and slow enough to make offline brute
# force expensive against a 4+ character password. 16-byte salt is the
# OWASP-recommended minimum.
_PBKDF2_ROUNDS = 200_000
_PBKDF2_SALT_BYTES = 16
_PBKDF2_KEY_BYTES = 32
_HASH_PREFIX = "pbkdf2_sha256"


def hash_password(password: str) -> str:
    """Return a hash string in the format ``pbkdf2_sha256$rounds$salt_b64$hash_b64``.

    Note the salt is fresh per call — never reuse hashes.
    """
    if not isinstance(password, str):
        raise TypeError("password must be a string")
    pw = password.encode("utf-8")
    salt = os.urandom(_PBKDF2_SALT_BYTES)
    dk = hashlib.pbkdf2_hmac("sha256", pw, salt, _PBKDF2_ROUNDS, _PBKDF2_KEY_BYTES)
    return "${prefix}${rounds}${salt}${dk}".format(
        prefix=_HASH_PREFIX,
        rounds=_PBKDF2_ROUNDS,
        salt=base64.urlsafe_b64encode(salt).decode("ascii"),
        dk=base64.urlsafe_b64encode(dk).decode("ascii"),
    ).lstrip("$")


def verify_password(password: str, stored_hash: str) -> bool:
    """Constant-time verification. False on any malformed hash."""
    if not stored_hash or not isinstance(stored_hash, str):
        return False
    parts = stored_hash.split("$")
    if len(parts) != 4 or parts[0] != _HASH_PREFIX:
        return False
    try:
        rounds = int(parts[1])
        salt = base64.urlsafe_b64decode(parts[2].encode("ascii"))
        expected = base64.urlsafe_b64decode(parts[3].encode("ascii"))
    except Exception:
        return False
    pw = (password or "").encode("utf-8")
    actual = hashlib.pbkdf2_hmac("sha256", pw, salt, rounds, len(expected))
    return hmac.compare_digest(actual, expected)


# ----- Session tokens -----------------------------------------------------

SESSION_COOKIE_NAME = "rdd_admin_session"
# 12 hours — long enough for a normal work shift, short enough that a
# stolen cookie has a finite lifespan.
SESSION_TTL_SECONDS = 12 * 60 * 60


@dataclass
class AdminSession:
    operator: str       # canonical display name of the admin
    issued_at: int      # unix seconds
    expires_at: int     # unix seconds


def _signing_key() -> bytes:
    """Derive a signing key from the server settings secret.

    Same secret the rest of the dashboard uses for signing — see
    ``services/settings_store.py``. Hashing it down to 32 bytes avoids
    any key-length surprises in HMAC.
    """
    from remote_desktop_dashboard.config import get_settings

    secret = (get_settings().settings_secret_key or "").encode("utf-8")
    if not secret:
        secret = b"rdd-no-secret-set"
    return hashlib.sha256(b"rdd-admin-session|" + secret).digest()


def _b64url_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def _b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode((s + pad).encode("ascii"))


def issue_session(operator: str, *, ttl_seconds: int = SESSION_TTL_SECONDS) -> str:
    """Return a signed session token for ``operator``.

    Token layout: ``<payload_b64url>.<signature_b64url>`` where payload
    is a compact JSON dict and signature is HMAC-SHA256 over the payload
    using ``_signing_key()``.
    """
    now = int(time.time())
    payload = {
        "op": operator,
        "iat": now,
        "exp": now + int(ttl_seconds),
        "v":   1,
    }
    body = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    sig  = hmac.new(_signing_key(), body, hashlib.sha256).digest()
    return f"{_b64url_encode(body)}.{_b64url_encode(sig)}"


def verify_session(token: str | None) -> AdminSession | None:
    """Verify a token and return an ``AdminSession`` or None.

    Returns None for empty / malformed / expired / bad-signature tokens.
    Constant-time on the signature comparison.
    """
    if not token or "." not in token:
        return None
    body_b64, sig_b64 = token.rsplit(".", 1)
    try:
        body = _b64url_decode(body_b64)
        sig  = _b64url_decode(sig_b64)
    except Exception:
        return None

    expected = hmac.new(_signing_key(), body, hashlib.sha256).digest()
    if not hmac.compare_digest(sig, expected):
        return None
    try:
        payload = json.loads(body.decode("utf-8"))
    except Exception:
        return None
    op  = str(payload.get("op", "")).strip()
    exp = int(payload.get("exp", 0))
    iat = int(payload.get("iat", 0))
    if not op or exp <= int(time.time()):
        return None
    return AdminSession(operator=op, issued_at=iat, expires_at=exp)
