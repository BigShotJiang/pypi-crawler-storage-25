"""Self-signed TLS cert for HTTPS mode on the LAN.

A single cert is generated on first --https run into the data folder. It is
issued as both a CA *and* a leaf (BasicConstraints CA=True) so Chrome/Edge
will accept it as a trusted root after a one-time install on each client
PC. SubjectAlternativeName covers ``localhost``, ``127.0.0.1``, the machine
hostname, and every detected LAN IPv4 so the same cert works regardless of
which URL the operator types.

This is the only practical way to get a real lock icon on a LAN service:
public CAs (Let's Encrypt etc.) can't issue certs for ``192.168.x.x`` or
local hostnames, and a plain HTTP service shows "Not Secure" forever.

The pair is generated once and reused — that way the user only installs the
cert into "Trusted Root Certification Authorities" once per client PC. If
the LAN IPs change later the operator can delete ``dashboard-cert.pem`` and
``dashboard-key.pem`` and the next start will regenerate them.
"""

from __future__ import annotations

import datetime as _dt
import ipaddress
import socket
from pathlib import Path


CERT_FILENAME = "dashboard-cert.pem"
KEY_FILENAME = "dashboard-key.pem"


def _detect_san_entries() -> tuple[list[str], list[str]]:
    """Return ``(dns_names, ip_strings)`` to populate the cert SAN."""
    dns: list[str] = ["localhost"]
    ips: list[str] = ["127.0.0.1"]

    hostname = ""
    try:
        hostname = socket.gethostname()
    except OSError:
        pass
    if hostname and hostname not in dns:
        dns.append(hostname)

    try:
        for entry in socket.getaddrinfo(hostname or "", None, family=socket.AF_INET):
            ip = entry[4][0]
            if ip and ip not in ips:
                ips.append(ip)
    except OSError:
        pass

    # Outbound-probe trick: tells us which interface IP would be used to
    # reach the internet. No packet is actually sent for SOCK_DGRAM.
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            if ip and ip not in ips:
                ips.append(ip)
    except OSError:
        pass

    return dns, ips


def ensure_self_signed_cert(data_dir: Path) -> tuple[Path, Path]:
    """Return ``(cert_path, key_path)``, generating both if missing."""
    data_dir.mkdir(parents=True, exist_ok=True)
    cert_path = data_dir / CERT_FILENAME
    key_path = data_dir / KEY_FILENAME
    if cert_path.exists() and key_path.exists():
        return cert_path, key_path

    # Import lazily so the module loads cheaply when HTTPS isn't enabled.
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID

    dns_names, ip_strs = _detect_san_entries()
    san_entries: list = [x509.DNSName(n) for n in dns_names]
    for ip in ip_strs:
        try:
            san_entries.append(x509.IPAddress(ipaddress.ip_address(ip)))
        except ValueError:
            continue

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = issuer = x509.Name(
        [
            x509.NameAttribute(NameOID.COMMON_NAME, "Remote Desktop Dashboard"),
            x509.NameAttribute(
                NameOID.ORGANIZATION_NAME, "Remote Desktop Dashboard LAN CA"
            ),
        ]
    )
    now = _dt.datetime.now(_dt.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - _dt.timedelta(days=1))
        .not_valid_after(now + _dt.timedelta(days=365 * 10))
        .add_extension(
            x509.BasicConstraints(ca=True, path_length=None), critical=True
        )
        .add_extension(x509.SubjectAlternativeName(san_entries), critical=False)
        .sign(key, hashes.SHA256())
    )

    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(
        key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
    # Keys are sensitive. On POSIX, restrict to owner. On Windows, default
    # NTFS ACLs from the data folder already restrict to the running user.
    try:
        key_path.chmod(0o600)
    except OSError:
        pass
    return cert_path, key_path


def public_cert_bytes(data_dir: Path) -> bytes:
    """Read the PEM cert (no key) for the ``/server/cert.crt`` endpoint."""
    cert_path, _ = ensure_self_signed_cert(data_dir)
    return cert_path.read_bytes()


def public_cert_path(data_dir: Path) -> Path:
    """Return the cert path, generating it if missing."""
    cert_path, _ = ensure_self_signed_cert(data_dir)
    return cert_path
