"""
Launch direct RDP sessions via msrdc.exe (Windows App client).

Windows365.exe is the cloud/subscription shell — bench connections use msrdc.exe
in the same package folder.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import tempfile
from functools import lru_cache
from pathlib import Path
from urllib.parse import quote

from remote_desktop_dashboard.config import get_settings

logger = logging.getLogger(__name__)
CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _encode_rdp_component(value: str) -> str:
    return quote(value, safe="")


def _windows_apps_roots() -> list[Path]:
    local = os.environ.get("LOCALAPPDATA", "")
    prog = os.environ.get("ProgramFiles", r"C:\Program Files")
    prog_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    return [
        Path(prog) / "WindowsApps",
        Path(local) / "Microsoft" / "WindowsApps",
        Path(prog_x86) / "WindowsApps",
    ]


def _resolve_to_msrdc(path: Path) -> Path | None:
    """If path is Windows365.exe, use msrdc.exe beside it; else keep msrdc paths."""
    if not path.is_file():
        return None
    name = path.name.lower()
    if name in ("msrdc.exe", "msrdcw.exe"):
        return path
    if name == "windows365.exe":
        for sibling in ("msrdc.exe", "msrdcw.exe"):
            candidate = path.parent / sibling
            if candidate.is_file():
                logger.info("Resolved Windows365.exe -> %s", candidate)
                return candidate
    return None


def _collect_msrdc_candidates() -> list[Path]:
    """All msrdc.exe paths, best match first (Windows365 bundle, then Remote Desktop)."""
    local = os.environ.get("LOCALAPPDATA", "")
    prog = os.environ.get("ProgramFiles", r"C:\Program Files")

    ordered_patterns = [
        "MicrosoftCorporationII.Windows365_*/msrdc.exe",
        "MicrosoftCorporationII.Windows365_*/msrdcw.exe",
        "Microsoft.RemoteDesktop_*/msrdc.exe",
        "Microsoft.RemoteDesktop_*/msrdcw.exe",
    ]
    found: list[Path] = []
    seen: set[str] = set()

    def add(path: Path | None) -> None:
        if path is None:
            return
        key = str(path).lower()
        if key not in seen and path.is_file():
            seen.add(key)
            found.append(path)

    settings = get_settings()
    if settings.msrdc_path:
        add(_resolve_to_msrdc(Path(settings.msrdc_path)))

    for fixed in (
        Path(prog) / "Remote Desktop" / "msrdc.exe",
        Path(prog) / "Remote Desktop" / "msrdcw.exe",
        Path(local) / "Microsoft" / "WindowsApps" / "msrdc.exe",
        Path(local) / "Microsoft" / "WindowsApps" / "msrdcw.exe",
    ):
        add(fixed if fixed.is_file() else None)

    for root in _windows_apps_roots():
        if not root.is_dir():
            continue
        for pattern in ordered_patterns:
            for hit in root.glob(pattern):
                add(hit)

    for cmd in ("msrdc",):
        try:
            result = subprocess.run(
                ["where.exe", cmd],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=CREATE_NO_WINDOW,
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    line = line.strip()
                    if line:
                        add(_resolve_to_msrdc(Path(line)) or Path(line))
        except Exception:
            pass

    return found


@lru_cache(maxsize=1)
def find_msrdc_exe() -> Path | None:
    """Locate msrdc.exe for direct bench RDP (never Windows365.exe)."""
    if sys.platform != "win32":
        return None
    candidates = _collect_msrdc_candidates()
    if candidates:
        logger.info("Using msrdc for direct connect: %s", candidates[0])
        return candidates[0]
    return None


def find_rdp_client() -> tuple[Path, str] | None:
    exe = find_msrdc_exe()
    return (exe, "msrdc") if exe else None


def _sanitize_rdp_value(value: str) -> str:
    """Strip control characters that would let DB-sourced values inject
    extra ``.rdp`` directives.

    The ``.rdp`` file format uses ``\\r\\n`` as a line separator, so a
    hostname or username containing a newline could smuggle in additional
    settings (e.g. ``alternate shell:s:cmd.exe /c calc``). Tampering with
    the DB is already required to reach this — but DB writes happen from
    multiple code paths and we'd rather be safe.
    """
    if value is None:
        return ""
    # Strip CR/LF/NUL outright; tab and other low control chars too.
    return "".join(ch for ch in str(value) if ch >= " ").strip()


def build_rdp_file_content(
    host: str,
    port: int | None = None,
    username: str | None = None,
    domain: str | None = None,
) -> str:
    settings = get_settings()
    port = port or settings.rdp_port
    domain = domain or settings.rdp_default_domain or None
    host = _sanitize_rdp_value(host)
    username = _sanitize_rdp_value(username) if username else None
    domain = _sanitize_rdp_value(domain) if domain else None

    lines = [
        f"full address:s:{host}:{port}",
        "authentication level:i:2",
        # Device redirection. Users asked for clipboard + audio enabled by
        # default so copy/paste and bench sounds Just Work.
        "redirectclipboard:i:1",
        # Audio: 0 = play on local computer, 2 = no sound.
        "audiomode:i:0",
        # Mic redirection — useful for screen-shared sessions.
        "audiocapturemode:i:1",
        # Video-capture (webcam) redirection.
        "camerastoredirect:s:*",
        # Don't auto-mount the operator's local drives by default (security
        # surface). Operators can still flip this manually if they need it.
        "drivestoredirect:s:",
        "redirectprinters:i:0",
        "redirectsmartcards:i:1",
        "screen mode id:i:2",
        "use multimon:i:0",
        "desktopwidth:i:0",
        "desktopheight:i:0",
        "autoreconnection enabled:i:1",
        "negotiate security layer:i:1",
        "bandwidthautodetect:i:1",
        "networkautodetect:i:1",
        "connection type:i:7",
    ]

    if settings.rdp_prompt_credentials:
        lines.append("prompt for credentials:i:1")
    else:
        # Only use when Windows has saved creds for this host (Credential Manager)
        lines.append("prompt for credentials:i:0")

    if username:
        if "\\" in username:
            user_only = username.split("\\", 1)[-1]
            dom = username.split("\\", 1)[0]
            lines.append(f"username:s:{user_only}")
            if not domain:
                domain = dom
        else:
            lines.append(f"username:s:{username}")

    if domain:
        lines.append(f"domain:s:{domain}")

    return "\r\n".join(lines) + "\r\n"


def _write_temp_rdp(host: str, port: int | None, username: str | None, domain: str | None) -> str:
    content = build_rdp_file_content(host, port, username, domain)
    tmp = tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".rdp",
        prefix="rdd_",
        delete=False,
        encoding="utf-8",
    )
    tmp.write(content)
    tmp.close()
    return tmp.name


def _launch_msrdc(exe: Path, rdp_path: str) -> None:
    """Start a direct RDP session (not the Windows365 subscription UI)."""
    rdp_abs = str(Path(rdp_path).resolve())
    attempts: list[list[str]] = [
        [str(exe), rdp_abs],
    ]
    last_error: Exception | None = None
    for args in attempts:
        try:
            subprocess.Popen(
                args,
                shell=False,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=CREATE_NO_WINDOW,
            )
            logger.info("Launched msrdc: %s", " ".join(args))
            return
        except Exception as exc:
            last_error = exc

    # Fallback: open .rdp with default handler (often msrdc if Windows App is default)
    try:
        os.startfile(rdp_abs)  # noqa: S606
        logger.info("Launched via shell association: %s", rdp_abs)
        return
    except Exception as exc:
        last_error = exc

    if last_error:
        raise last_error


def launch_rdp_on_windows(
    host: str,
    port: int | None = None,
    username: str | None = None,
    domain: str | None = None,
) -> tuple[str, str]:
    if sys.platform != "win32":
        raise OSError("RDP launch is only supported on Windows")

    settings = get_settings()
    path = _write_temp_rdp(host, port, username, domain)
    client_pref = settings.preferred_rdp_client.lower()
    msrdc = find_msrdc_exe()

    if client_pref in ("windows_app", "msrdc", "windows365", "auto") and msrdc:
        _launch_msrdc(msrdc, path)
        return "windows_app", path

    if client_pref in ("windows_app", "msrdc", "windows365"):
        raise FileNotFoundError(
            "msrdc.exe not found for direct connect. Set RDD_MSRDC_PATH to msrdc.exe in your "
            "Windows365 folder, e.g.:\n"
            "C:\\Program Files\\WindowsApps\\MicrosoftCorporationII.Windows365_*\\msrdc.exe"
        )

    subprocess.Popen(
        ["mstsc.exe", path],
        shell=False,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=CREATE_NO_WINDOW,
    )
    return "mstsc", path


def build_rdp_uri(
    host: str,
    port: int | None = None,
    username: str | None = None,
    domain: str | None = None,
) -> str:
    """Build an ``rdp://full%20address=...`` URI that Windows hands
    directly to mstsc.exe (no file download, no extra prompt beyond the
    one-time "Open Remote Desktop Connection?" browser handoff).

    Used as the **primary** launch path from 2.13+ — the browser invokes
    this URI; Windows opens mstsc directly to the login screen. We
    include the subset of RDP settings that the ``rdp://`` scheme is
    documented to honour, so clipboard / audio / smartcard redirection
    are configured to match the operators' expectations even though
    they're using direct-URI launch.
    """
    settings = get_settings()
    port = port or settings.rdp_port
    domain = domain or settings.rdp_default_domain or None

    # Same defence-in-depth as the .rdp file path.
    host = _sanitize_rdp_value(host)
    username = _sanitize_rdp_value(username) if username else None
    domain = _sanitize_rdp_value(domain) if domain else None

    full_address = f"s:{host}:{port}"
    parts = [f"full%20address={_encode_rdp_component(full_address)}"]
    # The supported parameter set for rdp:// per Microsoft's URI spec.
    # Values use the same ``i:`` / ``s:`` / ``b:`` prefixes as a .rdp
    # file. We mirror the same defaults as ``build_rdp_file_content``.
    parts.append("audiomode=i:0")
    parts.append("redirectclipboard=i:1")
    parts.append("redirectprinters=i:0")
    parts.append("redirectsmartcards=i:1")
    parts.append("bandwidthautodetect=i:1")
    parts.append("networkautodetect=i:1")
    parts.append("connection%20type=i:7")
    parts.append("screen%20mode%20id=i:2")
    parts.append("authentication%20level=i:2")
    if settings.rdp_prompt_credentials:
        parts.append("prompt%20for%20credentials=i:1")
        parts.append("promptcredentialonce=i:1")
    if username:
        if domain and "\\" not in username:
            user_val = f"s:{domain}\\{username}"
        else:
            user_val = f"s:{username}"
        parts.append(f"username={_encode_rdp_component(user_val)}")
    return "rdp://" + "&".join(parts)


def build_mstsc_command(host: str, port: int | None = None) -> str:
    settings = get_settings()
    port = port or settings.rdp_port
    if port == 3389:
        return f"mstsc /v:{host}"
    return f"mstsc /v:{host}:{port}"


def build_launch_uris(
    host: str,
    port: int | None = None,
    username: str | None = None,
    domain: str | None = None,
) -> dict[str, str]:
    """Return the URIs the dashboard hands back to the browser.

    From 2.13+ the dashboard's primary launch path is the ``rdp://``
    URI scheme: the browser hands the URI to the OS, which routes it
    directly to ``mstsc.exe`` (built-in on every Windows install). The
    user sees the RDP login screen open straight away — no .rdp file
    appears in their Downloads folder, no dashboard-side modal flashes
    on screen.

    The ``client`` field is purely informational for the UI toast.
    """
    settings = get_settings()
    port = port or settings.rdp_port
    msrdc = find_msrdc_exe()
    # Report "mstsc" by default — that's what each user's .rdp will open
    # with unless they've changed their default association. Only switch
    # to "windows_app" when the admin explicitly opts in AND msrdc is
    # findable on the server (the only case where server-side launch
    # would have worked anyway).
    pref = (settings.preferred_rdp_client or "").lower()
    if pref in ("windows_app", "msrdc", "windows365") and msrdc:
        client = "windows_app"
    else:
        client = "mstsc"
    exe_path = str(msrdc) if msrdc else ""
    rdp = build_rdp_uri(host, port, username, domain)
    return {
        "primary_uri": rdp,
        "fallback_uri": rdp,
        "windows_app_uri": rdp,
        "rdp_uri": rdp,
        "mstsc_command": build_mstsc_command(host, port),
        "powershell_command": (
            f'Start-Process mstsc -ArgumentList "/v:{host}"'
            if not exe_path
            else f'Start-Process -FilePath "{exe_path}" -ArgumentList \'"{host}"\''
        ),
        "client": client,
        "msrdc_found": bool(msrdc),
        "msrdc_path": exe_path,
    }


def local_launch_url(
    host: str,
    port: int | None = None,
    username: str | None = None,
    domain: str | None = None,
) -> str | None:
    """URL to the optional 127.0.0.1 helper.

    Returns ``None`` when the launcher is disabled (the default in 2.13+
    — see ``services.local_launcher`` for the reasoning). Callers
    forward the value verbatim to the browser, which skips the
    cross-origin fetch when it's null.
    """
    settings = get_settings()
    if not settings.local_launcher_enabled:
        return None
    port = port or settings.rdp_port
    q = f"host={quote(host, safe='')}&port={port}"
    if username:
        q += f"&username={quote(username, safe='')}"
    if domain:
        q += f"&domain={quote(domain, safe='')}"
    return f"http://127.0.0.1:{settings.local_launcher_port}/connect?{q}"
