"""WebSocket connection manager for live dashboard updates.

This is the only fan-out point between the FastAPI app and the dashboards
opened by every operator on the LAN. A single ``broadcast`` call has to
deliver to potentially hundreds of WebSockets without blocking the
event loop or letting one slow client wedge everyone else.

Design choices:

- ``payload`` is encoded **once** per broadcast and reused for every
  socket. Each send is its own ``asyncio.create_task`` and we
  ``gather`` them so a slow consumer can't slow the fast ones.
- Sends have a per-socket timeout (``send_timeout_seconds``) so a
  half-open TCP connection eventually drops out of the set instead of
  pinning broadcast latency to ``min(N, 30s)``.
- The connection set uses a plain ``set`` so disconnects are O(1).
- We do **not** hold the lock across the ``await send_text`` calls.
  Holding it serialises every operator's update behind every other
  operator's update — the whole point of fan-out is parallelism.
"""

import asyncio
import json
import logging
from typing import Any

from fastapi import WebSocket


logger = logging.getLogger(__name__)


class ConnectionManager:
    # Per-socket send timeout. Past this the socket is considered dead;
    # better to drop one client than wedge the broadcast.
    send_timeout_seconds: float = 3.0

    def __init__(self) -> None:
        self._connections: set[WebSocket] = set()
        self._lock = asyncio.Lock()

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        async with self._lock:
            self._connections.add(websocket)

    async def disconnect(self, websocket: WebSocket) -> None:
        async with self._lock:
            self._connections.discard(websocket)

    @property
    def client_count(self) -> int:
        """Number of currently connected dashboards. Cheap O(1)."""
        return len(self._connections)

    async def broadcast(self, message: dict[str, Any]) -> None:
        # Encode once, send many. Cheap when the payload is shared.
        payload = json.dumps(message, default=str)

        # Snapshot under the lock, fan out without it. Holding the lock
        # across await means a single slow client serialises every
        # broadcast — exactly the wedge we want to avoid.
        async with self._lock:
            targets = tuple(self._connections)
        if not targets:
            return

        async def _send_one(ws: WebSocket) -> WebSocket | None:
            try:
                await asyncio.wait_for(
                    ws.send_text(payload), timeout=self.send_timeout_seconds
                )
                return None
            except asyncio.TimeoutError:
                logger.warning("WebSocket send timed out; dropping client")
                return ws
            except Exception:
                return ws

        results = await asyncio.gather(
            *(_send_one(ws) for ws in targets), return_exceptions=False
        )
        dead = [ws for ws in results if ws is not None]
        if dead:
            async with self._lock:
                for ws in dead:
                    self._connections.discard(ws)


manager = ConnectionManager()
