"""Machine ORM model."""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from remote_desktop_dashboard.database import Base


class Machine(Base):
    __tablename__ = "machines"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    hostname: Mapped[str] = mapped_column(String(255))
    ip_address: Mapped[str] = mapped_column(String(45))

    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
    board: Mapped[str | None] = mapped_column(String(255), nullable=True)
    access_note: Mapped[str | None] = mapped_column(String(255), nullable=True)

    is_online: Mapped[bool] = mapped_column(Boolean, default=False)
    last_seen: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    local_user: Mapped[str | None] = mapped_column(String(128), nullable=True)
    rdp_users: Mapped[str] = mapped_column(Text, default="[]")
    windows_app_users: Mapped[str] = mapped_column(Text, default="[]")

    mobaxterm_user: Mapped[str | None] = mapped_column(String(128), nullable=True)
    com_port_user: Mapped[str | None] = mapped_column(String(128), nullable=True)
    etgui_user: Mapped[str | None] = mapped_column(String(128), nullable=True)
    camera_user: Mapped[str | None] = mapped_column(String(128), nullable=True)
    camera_tools: Mapped[str] = mapped_column(Text, default="[]")

    # Dashboard session lock (who is remoting in via this dashboard)
    locked_by: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    lock_heartbeat_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    lock_rdp_username: Mapped[str | None] = mapped_column(String(256), nullable=True)
    lock_client_ip: Mapped[str | None] = mapped_column(String(45), nullable=True)

    # 2.16.0: shared-session participants. JSON-encoded list of
    # ``{"operator": ..., "rdp_username": ..., "client_ip": ...}`` dicts.
    # The primary lock owner is in ``locked_by``; everyone listed here is
    # an *additional* operator the admin has waved through so they can
    # RDP into the same machine concurrently. Empty/NULL means "lock is
    # exclusive to ``locked_by``".
    lock_shared: Mapped[str | None] = mapped_column(Text, nullable=True)

    agent_version: Mapped[str | None] = mapped_column(String(32), nullable=True)
    raw_report: Mapped[str | None] = mapped_column(Text, nullable=True)

    bench_agent_version: Mapped[str | None] = mapped_column(String(32), nullable=True)
    bench_agent_last_seen: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    bench_agent_applied: Mapped[str | None] = mapped_column(Text, nullable=True)
    bench_agent_error: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    @property
    def lock_shared_with(self) -> list[str]:
        """Flat list of operator names sharing the current lock.

        Used by the MachineRead schema (``from_attributes=True``). The
        underlying storage is the JSON text column ``lock_shared``; this
        property hides that detail from the API layer.
        """
        import json as _json
        raw = (self.lock_shared or "").strip()
        if not raw:
            return []
        try:
            parsed = _json.loads(raw)
        except Exception:
            return []
        if not isinstance(parsed, list):
            return []
        out: list[str] = []
        for s in parsed:
            if isinstance(s, dict):
                op = (s.get("operator") or "").strip()
            else:
                op = str(s).strip()
            if op:
                out.append(op)
        return out
