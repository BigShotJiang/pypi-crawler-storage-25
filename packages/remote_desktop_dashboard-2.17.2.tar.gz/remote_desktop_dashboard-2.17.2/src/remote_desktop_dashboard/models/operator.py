"""Operator preferences \u2014 remembers each operator's last-used RDP details
so they don't have to retype them every time.

Keyed by operator display-name (case-insensitive). This is not a security
boundary; it's a convenience store. The dashboard itself has no operator
authentication (anyone on the LAN can hit it), so do not treat these rows
as authoritative identity.
"""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, String, func
from sqlalchemy.orm import Mapped, mapped_column

from remote_desktop_dashboard.database import Base


class OperatorPreference(Base):
    __tablename__ = "operator_preferences"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name_key: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(128))
    rdp_username: Mapped[str | None] = mapped_column(String(256), nullable=True)
    rdp_domain: Mapped[str | None] = mapped_column(String(128), nullable=True)
    use_hostname: Mapped[str | None] = mapped_column(String(8), nullable=True)

    # 2.16.0 — per-user admin accounts.
    # ``is_admin`` is a flag the existing admin (or anyone with the
    # bootstrap RDD_ADMIN_PIN) sets to designate this operator as an
    # admin. ``admin_password_hash`` is a salted PBKDF2 hash of the
    # password the operator picks the very first time they perform an
    # admin action — that's why we don't store any plaintext password
    # anywhere. ``admin_password_set_at`` records when they last
    # changed it, purely for audit.
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    admin_password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    admin_password_set_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    last_used_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
