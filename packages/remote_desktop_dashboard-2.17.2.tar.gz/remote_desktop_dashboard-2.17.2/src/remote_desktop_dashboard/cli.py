"""CLI entry points for remote-desktop-dashboard and seeding."""

import argparse
import json
import os
import shutil
import sys
import threading
import webbrowser
from pathlib import Path
from typing import Any, Optional

import uvicorn


def _acquire_singleton_lock(lock_path: Path) -> Optional[Any]:
    """Acquire an OS-level exclusive file lock or return None if already held.

    Used so the Scheduled-Task self-heal trigger (every 5 min) is a no-op
    when the dashboard is already running. The returned handle MUST stay
    open for the lifetime of the process; the OS releases on exit.

    The lock always targets byte 0 of the file. On Windows ``msvcrt.locking``
    is a mandatory per-handle byte-range lock, so opening a second handle
    and locking the same byte fails immediately (LK_NBLCK is non-blocking).
    """
    try:
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        # r+b on existing file, fall through to creating it. Use binary so
        # seek positions are byte offsets (not encoded characters).
        if lock_path.exists():
            f = open(lock_path, "r+b")
        else:
            f = open(lock_path, "w+b")
    except OSError:
        return None
    try:
        if sys.platform == "win32":
            import msvcrt

            f.seek(0)
            # Ensure at least 1 byte exists so we can lock it.
            data = f.read(1)
            if not data:
                f.write(b"\x00")
                f.flush()
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        return None
    try:
        # Truncate AFTER locking so a failed acquire doesn't blow away the PID
        # that the previous instance wrote.
        f.seek(0)
        f.truncate(0)
        f.write(str(os.getpid()).encode("ascii"))
        f.write(b"\n")
        f.flush()
    except OSError:
        pass
    return f

from remote_desktop_dashboard import __version__
from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.database import SessionLocal, init_db
from remote_desktop_dashboard.crud.machine import (
    create_machine,
    get_machine_by_name,
    list_machines,
    upsert_machine,
)
from remote_desktop_dashboard.schemas.machine import MachineCreate

_PKG_DATA = Path(__file__).resolve().parent / "data"
_BUNDLED_MACHINES = _PKG_DATA / "machines.json"
_BUNDLED_EXAMPLE = _PKG_DATA / "machines.example.json"


def _resolve_seed_file(path: Path) -> Path | None:
    if path.is_file():
        return path.resolve()
    cwd_candidate = Path.cwd() / path
    if cwd_candidate.is_file():
        return cwd_candidate.resolve()
    if _BUNDLED_MACHINES.is_file():
        return _BUNDLED_MACHINES
    if _BUNDLED_EXAMPLE.is_file():
        return _BUNDLED_EXAMPLE
    return None


def _load_seed_entries(path: Path) -> list[dict]:
    resolved = _resolve_seed_file(path)
    if resolved is None:
        print(
            f"File not found: {path}\n"
            "Bundled machines.json is missing from the package.",
            file=sys.stderr,
        )
        sys.exit(1)
    if resolved in (_BUNDLED_MACHINES, _BUNDLED_EXAMPLE):
        print(f"Using bundled: {resolved.name}")
    return json.loads(resolved.read_text(encoding="utf-8"))


def init_example_file() -> Path:
    source = _BUNDLED_MACHINES if _BUNDLED_MACHINES.is_file() else _BUNDLED_EXAMPLE
    if not source.is_file():
        print("Bundled machines template is missing from the package.", file=sys.stderr)
        sys.exit(1)
    dest_dir = Path.cwd() / "data"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / "machines.json"
    shutil.copy2(source, dest)
    print(f"Created: {dest}")
    print("Edit hostnames and IP addresses, then run:")
    print("  remote-desktop-dashboard-seed")
    return dest


def _seed_from_entries(entries: list[dict]) -> int:
    init_db()
    db = SessionLocal()
    created = 0
    try:
        for item in entries:
            name = item["name"].upper()
            if get_machine_by_name(db, name):
                continue
            create_machine(
                db,
                MachineCreate(
                    name=name,
                    hostname=item["hostname"],
                    ip_address=item["ip_address"],
                ),
            )
            created += 1
        return created
    finally:
        db.close()


def ensure_database_seeded() -> int:
    """Seed ATC1-ATC10 from bundled machines.json when the database is empty."""
    settings = get_settings()
    if not settings.auto_seed:
        return 0
    init_db()
    db = SessionLocal()
    try:
        if list_machines(db):
            return 0
    finally:
        db.close()
    if not _BUNDLED_MACHINES.is_file():
        return 0
    entries = json.loads(_BUNDLED_MACHINES.read_text(encoding="utf-8"))
    created = _seed_from_entries(entries)
    if created:
        print(f"Seeded {created} machine(s) from bundled machines.json (ATC1-ATC10).")
    return created


def _browser_url(host: str, port: int, scheme: str = "http") -> str:
    browse_host = "127.0.0.1" if host in ("0.0.0.0", "::", "") else host
    return f"{scheme}://{browse_host}:{port}/"


def _list_lan_urls(port: int, scheme: str = "http") -> list[str]:
    """Return every LAN URL this PC is reachable on (best-effort)."""
    import socket

    urls: list[str] = []
    seen: set[str] = set()
    try:
        hostname = socket.gethostname()
    except OSError:
        hostname = ""
    try:
        for entry in socket.getaddrinfo(hostname or "", None, family=socket.AF_INET):
            ip = entry[4][0]
            if not ip or ip.startswith("127.") or ip in seen:
                continue
            seen.add(ip)
            urls.append(f"{scheme}://{ip}:{port}/")
    except OSError:
        pass
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            if ip and not ip.startswith("127.") and ip not in seen:
                seen.add(ip)
                urls.append(f"{scheme}://{ip}:{port}/")
    except OSError:
        pass
    if hostname:
        urls.append(f"{scheme}://{hostname}:{port}/")
    return urls


def _schedule_browser_open(url: str) -> None:
    threading.Timer(1.5, lambda: webbrowser.open(url)).start()


def _prepare_install_layout() -> None:
    from remote_desktop_dashboard.services.bootstrap import bootstrap_install_layout

    bootstrap_install_layout()
    get_settings.cache_clear()


def main() -> None:
    """CLI entry: server, install-autostart, uninstall-autostart, service-status."""
    sub = sys.argv[1] if len(sys.argv) > 1 else ""
    if sub == "install-autostart":
        from remote_desktop_dashboard.services.autostart import install_autostart

        install_autostart()
        return
    if sub == "uninstall-autostart":
        from remote_desktop_dashboard.services.autostart import uninstall_autostart

        uninstall_autostart()
        return
    if sub in ("service-status", "status"):
        from remote_desktop_dashboard.services.autostart import service_status

        service_status()
        return
    run_server()


def run_server() -> None:
    parser = argparse.ArgumentParser(
        prog="remote-desktop-dashboard",
        description="Start the Remote Desktop Dashboard web server",
    )
    parser.add_argument("--host", help="Bind host (default: RDD_HOST or 0.0.0.0)")
    parser.add_argument("--port", type=int, help="Bind port (default: RDD_PORT or 8080)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not open the dashboard in your default browser",
    )
    parser.add_argument(
        "--no-seed",
        action="store_true",
        help="Do not auto-seed ATC1-ATC10 when the database is empty",
    )
    parser.add_argument(
        "--no-poller",
        action="store_true",
        help="Disable background remote polling (UI stays fast; no session data)",
    )
    parser.add_argument(
        "--no-reachability",
        action="store_true",
        help="Disable all TCP reachability checks (fastest UI)",
    )
    parser.add_argument(
        "--https",
        action="store_true",
        help=(
            "Serve over HTTPS using a self-signed cert (auto-generated in "
            "the data folder). Clients download the cert from /api/v1/"
            "server/cert.crt and install it once per PC to get a real "
            "green lock."
        ),
    )
    parser.add_argument(
        "--cert",
        dest="cert_file",
        help="Path to a TLS cert (PEM). Implies --https. If omitted, a "
        "self-signed cert is auto-generated in the data folder.",
    )
    parser.add_argument(
        "--key",
        dest="key_file",
        help="Path to the TLS private key (PEM). Required with --cert.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    args, _unknown = parser.parse_known_args()

    import os

    if args.no_poller:
        os.environ["RDD_POLLER_ENABLED"] = "false"
    if args.no_reachability:
        os.environ["RDD_REACHABILITY_CHECK"] = "false"
        os.environ["RDD_REACHABILITY_BACKGROUND"] = "false"
        os.environ["RDD_REACHABILITY_ON_API"] = "false"

    # HTTPS opt-in. CLI flags win over env so an admin can override the
    # default at startup without editing admin.env.
    if args.https or args.cert_file:
        os.environ["RDD_HTTPS_ENABLED"] = "true"
    if args.cert_file:
        os.environ["RDD_HTTPS_CERT_FILE"] = args.cert_file
    if args.key_file:
        os.environ["RDD_HTTPS_KEY_FILE"] = args.key_file

    _prepare_install_layout()
    # Clear the cached Settings so the env vars we just set take effect.
    get_settings.cache_clear()
    settings = get_settings()
    host = args.host or settings.host
    port = args.port or settings.port
    reload = args.reload or settings.reload
    open_browser = settings.open_browser and not args.no_browser
    https_enabled = bool(settings.https_enabled)
    scheme = "https" if https_enabled else "http"

    from remote_desktop_dashboard.config import resolve_env_files
    from remote_desktop_dashboard.paths import resolve_data_dir, resolve_database_file

    data_dir = resolve_data_dir()

    # Single-instance gate. Lets the Scheduled Task self-heal trigger be safe
    # to fire while we're already running. --reload (developer mode) skips this
    # because uvicorn forks a child worker.
    lock_handle = None
    if not reload:
        lock_handle = _acquire_singleton_lock(data_dir / "dashboard.lock")
        if lock_handle is None:
            print(
                "Another dashboard instance is already running for this data "
                f"folder ({data_dir}). Exiting cleanly.",
                file=sys.stderr,
            )
            return

    if not args.no_seed:
        ensure_database_seeded()

    db_file = resolve_database_file()
    env_files = resolve_env_files()
    print(f"Data folder:  {data_dir}")
    print(f"User config:  {data_dir / '.env'}")
    print(f"Admin config: {data_dir / 'admin.env'}")
    print(f"Database:     {db_file}")
    if env_files:
        print(f"Loading:      {', '.join(env_files)}")

    # Resolve TLS material when HTTPS is on. A user-supplied cert/key takes
    # precedence; otherwise we generate a self-signed pair into the data
    # folder (reused on next start).
    cert_path: Optional[str] = None
    key_path: Optional[str] = None
    if https_enabled:
        from remote_desktop_dashboard.services import tls as _tls

        if settings.https_cert_file and settings.https_key_file:
            cert_path = settings.https_cert_file
            key_path = settings.https_key_file
            print(f"TLS cert:     {cert_path}")
            print(f"TLS key:      {key_path}  (provided)")
        else:
            c, k = _tls.ensure_self_signed_cert(data_dir)
            cert_path, key_path = str(c), str(k)
            print(f"TLS cert:     {cert_path}  (self-signed, auto-generated)")
            print(f"TLS key:      {key_path}")

    # Print every URL the dashboard is reachable on so the operator knows
    # exactly what to give other PCs (a regular mistake: typing 127.0.0.1
    # on a different PC, which always points back at that PC, not the
    # server). This is the same info as the Share modal in the UI.
    print()
    print("Open the dashboard at:")
    print(f"  {scheme}://localhost:{port}/    (on this PC)")
    if host in ("0.0.0.0", "::", ""):
        for url in _list_lan_urls(port, scheme):
            print(f"  {url}    (from other PCs on the same LAN)")
        print(
            "  ^ If other PCs can't reach those URLs, allow inbound TCP "
            f"{port} in Windows Firewall on this PC and make sure they "
            "are on the same LAN/subnet."
        )
    else:
        print(
            f"  WARNING: --host {host} means this dashboard is NOT reachable "
            "from other PCs on the LAN. Restart without --host (or with "
            "--host 0.0.0.0) to share it."
        )
    if https_enabled:
        print()
        print(
            "HTTPS is ON. To remove the browser's \"Not secure / your "
            "connection is not private\" warning on each client PC, install "
            "the cert ONCE:"
        )
        print(
            f"  1. Download from {scheme}://<this-pc>:{port}/api/v1/server/cert.crt"
        )
        print(
            "  2. Open it -> Install Certificate -> Local Machine -> Place all "
            'in "Trusted Root Certification Authorities".'
        )
    print()

    if open_browser:
        _schedule_browser_open(_browser_url(host, port, scheme))

    try:
        uvicorn.run(
            "remote_desktop_dashboard.main:app",
            host=host,
            port=port,
            reload=reload,
            ssl_certfile=cert_path,
            ssl_keyfile=key_path,
        )
    finally:
        if lock_handle is not None:
            try:
                lock_handle.close()
            except OSError:
                pass


def seed_machines() -> None:
    parser = argparse.ArgumentParser(
        description="Seed ATC machines into the database",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  remote-desktop-dashboard-seed\n"
            "  remote-desktop-dashboard-seed --init-example\n"
            "  remote-desktop-dashboard-seed --file data\\machines.json"
        ),
    )
    parser.add_argument(
        "--file",
        type=Path,
        help="JSON file (default: ./data/machines.json, else bundled machines.json)",
    )
    parser.add_argument(
        "--init-example",
        action="store_true",
        help="Copy bundled machines.json to ./data/machines.json",
    )
    parser.add_argument("--name", help="Single machine name (e.g. ATC1)")
    parser.add_argument("--hostname", help="Hostname for single machine")
    parser.add_argument("--ip", dest="ip_address", help="IP address for single machine")
    parser.add_argument(
        "--skip-update",
        action="store_true",
        help="Do not update hostname/IP when the machine name already exists",
    )
    args = parser.parse_args()

    if args.init_example:
        init_example_file()
        return

    _prepare_install_layout()
    init_db()
    db = SessionLocal()
    created = 0
    updated = 0
    skipped = 0
    try:
        entries: list[dict] = []
        if args.file or (not args.name and not args.hostname):
            seed_path = args.file or Path("data/machines.json")
            entries = _load_seed_entries(seed_path)
        elif args.name and args.hostname and args.ip_address:
            entries = [
                {
                    "name": args.name,
                    "hostname": args.hostname,
                    "ip_address": args.ip_address,
                }
            ]
        else:
            parser.print_help()
            sys.exit(1)

        for item in entries:
            name = item["name"].upper()
            payload = MachineCreate(
                name=name,
                hostname=item["hostname"],
                ip_address=item["ip_address"],
            )
            if args.skip_update and get_machine_by_name(db, name):
                print(f"Skip (exists): {name}")
                skipped += 1
                continue
            if args.skip_update:
                create_machine(db, payload)
                print(f"Created: {name}")
                created += 1
            else:
                _machine, action = upsert_machine(db, payload)
                if action == "created":
                    print(f"Created: {name}")
                    created += 1
                else:
                    print(f"Updated: {name} -> {payload.hostname} / {payload.ip_address}")
                    updated += 1
        print(
            f"Done. Created {created}, updated {updated}, skipped {skipped}. "
            f"Total: {len(list_machines(db))}"
        )
    finally:
        db.close()


if __name__ == "__main__":
    main()
