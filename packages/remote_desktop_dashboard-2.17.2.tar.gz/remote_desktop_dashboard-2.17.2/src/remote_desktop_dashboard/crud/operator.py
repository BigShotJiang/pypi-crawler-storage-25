"""Operator preference CRUD."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from remote_desktop_dashboard.models.operator import OperatorPreference


def _key(name: str) -> str:
    return (name or "").strip().lower()


def get_operator_pref(db: Session, name: str) -> OperatorPreference | None:
    k = _key(name)
    if not k:
        return None
    stmt = select(OperatorPreference).where(OperatorPreference.name_key == k)
    return db.execute(stmt).scalar_one_or_none()


def upsert_operator_pref(
    db: Session,
    *,
    display_name: str,
    rdp_username: str | None = None,
    rdp_domain: str | None = None,
    use_hostname: bool | None = None,
) -> OperatorPreference:
    """Create or update an operator's stored RDP defaults. Caller commits."""
    k = _key(display_name)
    pref = db.execute(
        select(OperatorPreference).where(OperatorPreference.name_key == k)
    ).scalar_one_or_none()
    if pref is None:
        pref = OperatorPreference(
            name_key=k,
            display_name=display_name.strip(),
        )
        db.add(pref)
    else:
        pref.display_name = display_name.strip()

    if rdp_username is not None:
        pref.rdp_username = rdp_username.strip() or None
    if rdp_domain is not None:
        pref.rdp_domain = rdp_domain.strip() or None
    if use_hostname is not None:
        pref.use_hostname = "1" if use_hostname else "0"
    return pref


def list_operator_prefs(db: Session, limit: int = 50) -> list[OperatorPreference]:
    stmt = (
        select(OperatorPreference)
        .order_by(OperatorPreference.last_used_at.desc())
        .limit(limit)
    )
    return list(db.execute(stmt).scalars())


# ----- 2.16.0 — per-user admin accounts -----------------------------------

def list_admin_operators(db: Session) -> list[OperatorPreference]:
    stmt = (
        select(OperatorPreference)
        .where(OperatorPreference.is_admin.is_(True))
        .order_by(OperatorPreference.display_name)
    )
    return list(db.execute(stmt).scalars())


def has_any_admin_user(db: Session) -> bool:
    """True iff at least one operator has ``is_admin=True``.

    Used by the bootstrap check: while no admin user exists yet, the
    legacy global ``RDD_ADMIN_PIN`` (or freshly-promoted operator) is
    the only path to admin-level actions.
    """
    return bool(list_admin_operators(db))


def set_admin_flag(
    db: Session, *, display_name: str, is_admin: bool
) -> OperatorPreference:
    """Mark an operator as admin (or revoke). Auto-creates the prefs row.

    Caller commits. Clearing the flag does NOT clear the password hash —
    we keep it so re-promoting them later doesn't force them through the
    first-time password set again. (They can change it any time once
    re-promoted.)
    """
    pref = upsert_operator_pref(db, display_name=display_name)
    pref.is_admin = bool(is_admin)
    return pref


def set_admin_password(
    db: Session, *, display_name: str, password: str
) -> OperatorPreference:
    """Store a freshly-hashed admin password. Caller commits."""
    from datetime import datetime, timezone

    from remote_desktop_dashboard.services.admin_auth import hash_password

    if not password or len(password) < 4:
        raise ValueError("Admin password must be at least 4 characters.")
    pref = upsert_operator_pref(db, display_name=display_name)
    if not pref.is_admin:
        raise ValueError(f"{display_name} is not designated as an admin.")
    pref.admin_password_hash = hash_password(password)
    pref.admin_password_set_at = datetime.now(timezone.utc)
    return pref


def verify_admin_password(
    db: Session, *, display_name: str, password: str
) -> bool:
    """Verify a login attempt. Constant-time."""
    from remote_desktop_dashboard.services.admin_auth import verify_password

    pref = get_operator_pref(db, display_name)
    if pref is None or not pref.is_admin or not pref.admin_password_hash:
        # Run a dummy verify so timing is roughly constant regardless of
        # whether the operator exists.
        verify_password("", "x" * 60)
        return False
    return verify_password(password, pref.admin_password_hash)
