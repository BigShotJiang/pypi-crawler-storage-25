"""Machine lock CRUD for dashboard remote sessions."""

from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.models.machine import Machine

settings = get_settings()


class LockError(Exception):
    def __init__(self, message: str, locked_by: str | None = None) -> None:
        super().__init__(message)
        self.locked_by = locked_by


def normalize_operator(operator: str) -> str:
    return operator.strip()


def operators_match(a: str, b: str) -> bool:
    return normalize_operator(a).casefold() == normalize_operator(b).casefold()


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _aware(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def is_lock_expired(machine: Machine) -> bool:
    """Expire stale locks quickly when heartbeats stop (abandoned browser tab)."""
    if not machine.locked_by:
        return True
    now = _now()
    hb = _aware(machine.lock_heartbeat_at)
    if hb is not None:
        return (now - hb).total_seconds() > settings.lock_heartbeat_grace_seconds
    locked_at = _aware(machine.locked_at)
    if locked_at is None:
        return True
    return (now - locked_at).total_seconds() > settings.lock_timeout_seconds


def clear_lock(machine: Machine) -> None:
    machine.locked_by = None
    machine.locked_at = None
    machine.lock_heartbeat_at = None
    machine.lock_rdp_username = None
    machine.lock_client_ip = None
    machine.lock_shared = None


# ----- 2.16.0 — shared sessions -------------------------------------------

import json as _json


def get_lock_shared(machine: Machine) -> list[dict]:
    """Return the parsed ``lock_shared`` JSON list (always a list)."""
    raw = (machine.lock_shared or "").strip()
    if not raw:
        return []
    try:
        data = _json.loads(raw)
        if isinstance(data, list):
            return [d for d in data if isinstance(d, dict)]
    except Exception:
        pass
    return []


def add_shared_operator(
    db: Session,
    machine: Machine,
    operator: str,
    rdp_username: str | None = None,
    client_ip: str | None = None,
) -> Machine:
    """Add ``operator`` to the lock's shared-participant list.

    Admin action: the primary lock owner stays in ``locked_by`` and
    everyone listed here is an additional operator who can RDP into the
    same machine concurrently. Idempotent: if the operator is already
    listed (or IS the primary owner), this is a no-op.
    """
    operator = normalize_operator(operator)
    if not operator:
        raise LockError("Operator name is required")
    if not machine.locked_by:
        raise LockError("Machine is not locked — nothing to share")
    if operators_match(machine.locked_by, operator):
        # The primary owner already has access; sharing is a no-op.
        return machine

    shared = get_lock_shared(machine)
    if any(operators_match(s.get("operator", ""), operator) for s in shared):
        # Already shared with this operator — refresh credentials maybe.
        for s in shared:
            if operators_match(s.get("operator", ""), operator):
                if rdp_username:
                    s["rdp_username"] = rdp_username.strip()
                if client_ip:
                    s["client_ip"] = client_ip.strip()
    else:
        shared.append({
            "operator": operator,
            "rdp_username": (rdp_username or "").strip(),
            "client_ip": (client_ip or "").strip(),
        })
    machine.lock_shared = _json.dumps(shared)
    db.commit()
    db.refresh(machine)
    return machine


def remove_shared_operator(db: Session, machine: Machine, operator: str) -> Machine:
    shared = [
        s for s in get_lock_shared(machine)
        if not operators_match(s.get("operator", ""), operator)
    ]
    machine.lock_shared = _json.dumps(shared) if shared else None
    db.commit()
    db.refresh(machine)
    return machine


def is_lock_participant(machine: Machine, operator: str) -> bool:
    """True if ``operator`` is the primary owner OR in the shared list."""
    if not machine.locked_by or is_lock_expired(machine):
        return False
    if operators_match(machine.locked_by, operator):
        return True
    return any(
        operators_match(s.get("operator", ""), operator)
        for s in get_lock_shared(machine)
    )


def refresh_expired_locks(db: Session, *, remote_firewall: bool = True) -> list[Machine]:
    from remote_desktop_dashboard.config import get_settings
    from remote_desktop_dashboard.crud.machine import list_machines
    from remote_desktop_dashboard.services.dashboard import bench_host
    from remote_desktop_dashboard.services.rdp_guard import (
        clear_rdp_guard,
        schedule_clear_rdp_guard,
    )

    released: list[Machine] = []
    prefer_ip = get_settings().poll_prefer_ip
    for machine in list_machines(db):
        if machine.locked_by and is_lock_expired(machine):
            allow: list[str] = []
            if machine.lock_client_ip:
                allow.append(machine.lock_client_ip)
            host = bench_host(machine, prefer_ip=prefer_ip)
            if remote_firewall:
                try:
                    clear_rdp_guard(host, allow)
                except Exception:
                    pass
            else:
                schedule_clear_rdp_guard(host, allow)
            clear_lock(machine)
            released.append(machine)
    if released:
        db.commit()
    return released


def is_locked_by_other(machine: Machine, operator: str) -> bool:
    if not machine.locked_by or is_lock_expired(machine):
        return False
    if operators_match(machine.locked_by, operator):
        return False
    # 2.16.0: shared participants are NOT "locked by other" — they can
    # also reconnect/heartbeat against this lock.
    if any(
        operators_match(s.get("operator", ""), operator)
        for s in get_lock_shared(machine)
    ):
        return False
    return True


def acquire_lock(
    db: Session,
    machine: Machine,
    operator: str,
    rdp_username: str | None = None,
    force: bool = False,
    client_ip: str | None = None,
    *,
    skip_expired_refresh: bool = False,
) -> Machine:
    """Atomically reserve a bench for ``operator``.

    SAFETY: previously this was a classic check-then-act — two operators
    could both pass ``is_locked_by_other`` and the last commit would
    silently overwrite the first reservation. Now the actual change is
    a single ``UPDATE machines SET locked_by=... WHERE id=... AND
    (locked_by IS NULL OR locked_by = me OR lock_heartbeat_at < cutoff)``
    so SQLite serialises the contending writes; only one wins, the
    other gets a ``LockError``. Works the same on SQLite (WAL) and
    PostgreSQL.
    """
    from datetime import timedelta

    from sqlalchemy import func, or_, update

    from remote_desktop_dashboard.config import get_settings

    operator = normalize_operator(operator)
    if not operator:
        raise LockError("Operator name is required")

    if not skip_expired_refresh:
        refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)

    settings = get_settings()
    now = _now()
    cutoff = now - timedelta(seconds=max(15, settings.lock_heartbeat_grace_seconds))

    values: dict = {
        "locked_by": operator,
        "locked_at": now,
        "lock_heartbeat_at": now,
    }
    if rdp_username:
        values["lock_rdp_username"] = rdp_username.strip()
    if client_ip:
        values["lock_client_ip"] = client_ip.strip()

    if force:
        # Admin force-acquire: no WHERE predicate on ownership.
        stmt = update(Machine).where(Machine.id == machine.id).values(**values)
    else:
        # Race-free predicate. Acquire iff the row is currently:
        #   (a) unlocked, OR
        #   (b) already locked by *me* (re-claim / no-op reconnect), OR
        #   (c) locked but heartbeat is older than the grace window
        #       (effectively expired but not yet cleaned up).
        # Case-insensitive operator match keeps "Alice Smith" and
        # "alice smith" treated as the same person (matches
        # ``operators_match``), so a tab refresh or a different-case
        # reconnect doesn't 409.
        stmt = (
            update(Machine)
            .where(Machine.id == machine.id)
            .where(
                or_(
                    Machine.locked_by.is_(None),
                    func.lower(Machine.locked_by) == operator.casefold(),
                    Machine.lock_heartbeat_at == None,  # noqa: E711
                    Machine.lock_heartbeat_at < cutoff,
                )
            )
            .values(**values)
        )

    # ``synchronize_session=False`` keeps SQLAlchemy from trying to
    # re-evaluate the WHERE predicate against the Python session — that
    # path can't compare timezone-aware Python datetimes against
    # SQLite's naive strings. The DB-level check is the one that
    # matters for race-safety; ``db.refresh()`` below repopulates the
    # in-memory object from the row.
    result = db.execute(stmt.execution_options(synchronize_session=False))
    db.commit()
    if result.rowcount == 0:
        # Someone else won the race. Reload to surface the real owner.
        db.refresh(machine)
        raise LockError(
            f"Machine is in use by {machine.locked_by}. They must click Release first.",
            locked_by=machine.locked_by,
        )
    db.refresh(machine)
    return machine


def admin_force_release(db: Session, machine: Machine) -> Machine:
    """Clear lock regardless of operator (admin action)."""
    clear_lock(machine)
    db.commit()
    db.refresh(machine)
    return machine


def heartbeat_lock(db: Session, machine: Machine, operator: str) -> Machine:
    operator = normalize_operator(operator)
    if not machine.locked_by:
        raise LockError("Machine is not locked")
    if not operators_match(machine.locked_by, operator):
        raise LockError(
            f"Machine is locked by {machine.locked_by}",
            locked_by=machine.locked_by,
        )
    machine.lock_heartbeat_at = _now()
    db.commit()
    db.refresh(machine)
    return machine


def release_lock(db: Session, machine: Machine, operator: str) -> Machine:
    operator = normalize_operator(operator)
    if not machine.locked_by:
        return machine
    if not operators_match(machine.locked_by, operator):
        raise LockError(
            f"Only {machine.locked_by} can release this lock",
            locked_by=machine.locked_by,
        )
    clear_lock(machine)
    db.commit()
    db.refresh(machine)
    return machine
