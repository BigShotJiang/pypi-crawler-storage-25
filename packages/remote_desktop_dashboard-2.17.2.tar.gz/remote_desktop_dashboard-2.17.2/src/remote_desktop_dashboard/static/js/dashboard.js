(function () {
  "use strict";

  const STORAGE_OPERATOR = "rdd_operator";
  const STORAGE_RDP_USER = "rdd_rdp_username";
  const STORAGE_RDP_DOMAIN = "rdd_rdp_domain";
  const STORAGE_USE_IP   = "rdd_use_ip";
  const HEARTBEAT_MS = 30000;

  // -- Top bar refs ---------------------------------------------------------
  const wsStatus      = document.getElementById("ws-status");
  const lastUpdate    = document.getElementById("last-update");
  const statusUpdated = document.getElementById("status-updated");
  const machineCount  = document.getElementById("machine-count");
  const operatorInput = document.getElementById("operator-name");
  const operatorList  = document.getElementById("operator-list");
  const rdpUserInput  = document.getElementById("rdp-username");
  const rdpDomainInput= document.getElementById("rdp-domain");
  const useIpInput    = document.getElementById("use-ip");
  const toastEl       = document.getElementById("toast");
  const serverBanner  = document.getElementById("server-banner");

  // -- Tab panels -----------------------------------------------------------
  const tabButtons     = document.querySelectorAll(".tab[data-tab]");
  const tabPanels      = document.querySelectorAll(".tab-panel[data-panel]");
  const statusRowsEl   = document.getElementById("status-rows");
  const inventoryRowsEl= document.getElementById("inventory-rows");
  const auditRowsEl    = document.getElementById("audit-rows");
  const detailPanelEl  = document.getElementById("detail-panel");

  // -- Audit filters --------------------------------------------------------
  const auditActionFilter   = document.getElementById("audit-action-filter");
  const auditMachineFilter  = document.getElementById("audit-machine-filter");
  const auditOperatorFilter = document.getElementById("audit-operator-filter");
  const auditRefreshBtn     = document.getElementById("audit-refresh");

  // -- Drawers --------------------------------------------------------------
  const manageDrawer   = document.getElementById("manage-drawer");
  const settingsDrawer = document.getElementById("settings-drawer");
  const toggleManageBtn  = document.getElementById("toggle-manage");
  const toggleSettingsBtn= document.getElementById("toggle-settings");

  let machines = [];
  let activeTab = "status";
  let selectedMachine = null;
  let auditCache = [];
  let serverMeta = {
    monitor_configured: true,
    users_can_connect: true,
    users_can_manage_machines: false,
    users_can_release_own_lock: true,
  };
  let heartbeatTimers = {};
  const pollingMachines = new Set();

  operatorInput.value = localStorage.getItem(STORAGE_OPERATOR) || "";
  rdpUserInput.value = localStorage.getItem(STORAGE_RDP_USER) || "";
  if (rdpDomainInput) {
    rdpDomainInput.value = localStorage.getItem(STORAGE_RDP_DOMAIN) || "";
  }
  if (useIpInput) {
    useIpInput.checked = localStorage.getItem(STORAGE_USE_IP) === "1";
    useIpInput.addEventListener("change", function () {
      localStorage.setItem(STORAGE_USE_IP, useIpInput.checked ? "1" : "0");
    });
  }

  function bindAutosave(el) {
    if (!el) return;
    el.addEventListener("input", function () {
      savePrefs();
      if (machines.length) render(machines);
    });
    el.addEventListener("change", savePrefs);
    el.addEventListener("blur", savePrefs);
  }
  bindAutosave(operatorInput);
  bindAutosave(rdpUserInput);
  bindAutosave(rdpDomainInput);

  // -- Operator preferences: auto-fill RDP user/domain from server -----------
  let operatorLookupTimer = null;
  async function lookupOperatorPrefs(name) {
    const trimmed = (name || "").trim();
    if (!trimmed) return;
    try {
      const res = await fetch("/api/v1/operators/" + encodeURIComponent(trimmed));
      if (!res.ok) return;
      const data = await res.json();
      if (!data || !data.known) return;
      // Only auto-fill empty fields so we never clobber what the user just typed.
      if (rdpUserInput && !rdpUserInput.value.trim() && data.rdp_username) {
        rdpUserInput.value = data.rdp_username;
        savePrefs();
      }
      if (rdpDomainInput && !rdpDomainInput.value.trim() && data.rdp_domain) {
        rdpDomainInput.value = data.rdp_domain;
        savePrefs();
      }
      if (useIpInput && data.use_hostname !== null && data.use_hostname !== undefined) {
        useIpInput.checked = data.use_hostname === false;
        localStorage.setItem(STORAGE_USE_IP, useIpInput.checked ? "1" : "0");
      }
    } catch (_) { /* network blip; ignore */ }
  }
  operatorInput.addEventListener("input", function () {
    if (operatorLookupTimer) clearTimeout(operatorLookupTimer);
    operatorLookupTimer = setTimeout(function () {
      lookupOperatorPrefs(operatorInput.value);
    }, 450);
  });
  operatorInput.addEventListener("blur", function () {
    lookupOperatorPrefs(operatorInput.value);
  });

  async function loadOperatorList() {
    if (!operatorList) return;
    try {
      const res = await fetch("/api/v1/operators?limit=50");
      if (!res.ok) return;
      const arr = await res.json();
      operatorList.innerHTML = arr
        .map(function (o) { return '<option value="' + escapeHtml(o.display_name) + '"></option>'; })
        .join("");
    } catch (_) {}
  }

  function savePrefs() {
    localStorage.setItem(STORAGE_OPERATOR, operatorInput.value.trim());
    localStorage.setItem(STORAGE_RDP_USER, rdpUserInput.value.trim());
    if (rdpDomainInput) {
      localStorage.setItem(STORAGE_RDP_DOMAIN, rdpDomainInput.value.trim());
    }
  }

  function getOperator() {
    return operatorInput.value.trim();
  }

  function normalizeOp(name) {
    return (name || "").trim().toLowerCase();
  }

  function operatorsMatch(a, b) {
    const x = normalizeOp(a);
    const y = normalizeOp(b);
    return x !== "" && x === y;
  }

  function enrichMachine(m) {
    const op = normalizeOp(getOperator());
    const locked = !!(m.is_locked && m.locked_by);
    const lockedBy = locked ? normalizeOp(m.locked_by) : "";
    const mine = locked && op && lockedBy === op;
    m._mine = mine;
    m.lock_available = !locked || mine;
    return m;
  }

  function getRdpDomain() {
    return rdpDomainInput ? rdpDomainInput.value.trim() : "";
  }

  function getRdpUser() {
    return rdpUserInput.value.trim();
  }

  function getRdpUsername() {
    const u = getRdpUser();
    if (!u) return null;
    const d = getRdpDomain();
    if (d && !u.includes("\\") && !u.includes("/") && !u.includes("@")) {
      return d + "\\" + u;
    }
    return u;
  }

  function missingRequiredFields() {
    const missing = [];
    if (!operatorInput.value.trim()) missing.push("Your name");
    if (rdpDomainInput && !rdpDomainInput.value.trim()) missing.push("RDP domain");
    if (!rdpUserInput.value.trim()) missing.push("RDP username");
    return missing;
  }

  function focusFirstMissing() {
    if (!operatorInput.value.trim()) {
      operatorInput.focus();
      return;
    }
    if (rdpDomainInput && !rdpDomainInput.value.trim()) {
      rdpDomainInput.focus();
      return;
    }
    if (!rdpUserInput.value.trim()) {
      rdpUserInput.focus();
    }
  }

  function wsUrl() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    return proto + "//" + location.host + "/ws/dashboard";
  }

  function showToast(msg, isError) {
    toastEl.textContent = msg;
    toastEl.className = "toast" + (isError ? " toast-error" : "");
    setTimeout(function () {
      toastEl.className = "toast hidden";
    }, 5000);
  }

  const launchModal = document.getElementById("launch-modal");
  const launchTarget = document.getElementById("launch-target");
  const launchHint = document.getElementById("launch-hint");
  const launchCopyRdp = document.getElementById("launch-copy-rdp");
  const launchTryLocal = document.getElementById("launch-try-local");
  const launchCopyMstsc = document.getElementById("launch-copy-mstsc");
  const launchDownloadRdp = document.getElementById("launch-download-rdp");
  const launchClose = document.getElementById("launch-close");
  const launchBackdrop = document.getElementById("launch-backdrop");
  const useIpCheckbox = document.getElementById("use-ip");

  let lastLaunchData = null;

  function hideLaunchModal() {
    launchModal.className = "modal hidden";
    lastLaunchData = null;
  }

  function showLaunchModal(data) {
    lastLaunchData = data;
    launchTarget.textContent = data.machine_name + " (" + data.target_host + ")";
    launchHint.textContent =
      data.message ||
      "Launch on this PC, or download .rdp (uses each PC's own Windows App / msrdc).";
    if (launchCopyRdp) {
      launchCopyRdp.dataset.uri = data.launch_uri || data.rdp_uri || "";
    }
    if (launchDownloadRdp && data.rdp_download_url) {
      launchDownloadRdp.href = data.rdp_download_url;
      launchDownloadRdp.classList.remove("hidden");
    } else if (launchDownloadRdp) {
      launchDownloadRdp.classList.add("hidden");
    }
    launchModal.className = "modal";
  }

  function mergeMachineUpdate(updated) {
    if (!updated || !updated.name) return;
    const idx = machines.findIndex(function (m) {
      return m.name === updated.name;
    });
    if (idx >= 0) {
      machines[idx] = updated;
    } else {
      machines.push(updated);
    }
    render(machines);
  }

  // Open native mstsc for the operator's PC (the machine running the
  // browser).
  //
  // Two-step launch:
  //   1) Fire the registered ``rdp://`` protocol handler via a hidden
  //      iframe. The iframe doesn't navigate the main page, so even
  //      when the handler is missing nothing visibly happens — that
  //      was the root cause of "goes blank and blocked" in 2.17.x.
  //   2) If the browser still has focus ~2.5s later (handler didn't
  //      catch), download the ``.rdp`` file with a hidden anchor click
  //      using the ``download`` attribute. Windows file association
  //      then opens mstsc when the user clicks the downloaded item.
  function openRemoteDesktop(data) {
    const rdpUri = (data && (data.rdp_uri || data.launch_uri)) || null;
    const rdpUrl = (data && data.rdp_download_url) || null;
    const targetHost = (data && data.target_host) || "bench";
    const machineName = (data && data.machine_name) || "session";

    if (rdpUri) {
      try {
        const iframe = document.createElement("iframe");
        iframe.setAttribute("aria-hidden", "true");
        iframe.style.cssText =
          "position:absolute;left:-9999px;top:-9999px;width:0;height:0;border:0;visibility:hidden";
        iframe.src = rdpUri;
        document.body.appendChild(iframe);
        setTimeout(function () {
          try { iframe.remove(); } catch (_) {}
        }, 5000);
      } catch (_) {}
    }

    showToast("Opening Remote Desktop to " + targetHost + "…", false);

    // Fallback path: download the .rdp file (attachment, not inline) so
    // the browser hands it to Windows mstsc via the default file
    // association. No iframe blocking, no blank page.
    watchForExternalLaunch(2500, function () {
      if (!rdpUrl) {
        showToast(
          "Could not start Remote Desktop. Check your browser's pop-up / handler settings.",
          true
        );
        return;
      }
      try {
        const a = document.createElement("a");
        a.href = rdpUrl;
        a.download = machineName + ".rdp";
        a.rel = "noopener";
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        setTimeout(function () { try { a.remove(); } catch (_) {} }, 1000);
        showToast(
          "Click the downloaded " + machineName + ".rdp file to open Remote Desktop.",
          false
        );
      } catch (err) {
        showToast("Could not download .rdp file: " + err.message, true);
      }
    });
  }

  // ----------------------------------------------------------------
  // 2.16.0 — admin session state (per-user accounts)
  // ----------------------------------------------------------------
  // Cached snapshot of GET /admin/me. Updated whenever an admin action
  // succeeds/fails so the in-use popup can show the right buttons.
  let adminMeCache = {
    admin: false,
    operator: null,
    needs_password_set: false,
    any_admin_exists: false,
    legacy_pin_configured: false,
  };

  async function refreshAdminMe() {
    try {
      const r = await fetch("/api/v1/admin/me", { credentials: "same-origin" });
      if (!r.ok) return adminMeCache;
      adminMeCache = await r.json();
    } catch (_) {}
    // Reflect new admin status in body class / Admin button label.
    // ``syncAdminUi`` is declared further down the same closure with
    // ``function`` so it is hoisted and safe to call from here.
    try { syncAdminUi(); } catch (_) {}
    return adminMeCache;
  }
  refreshAdminMe();

  function escapeHtmlSafe(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  // Generic dismissable centred modal. Returns the root element so
  // callers can wire up handlers after insertion.
  function buildModal(id, innerHtml) {
    const old = document.getElementById(id);
    if (old) old.remove();
    const root = document.createElement("div");
    root.id = id;
    root.className = "rdd-modal-backdrop";
    root.innerHTML = '<div class="rdd-modal-card" role="dialog">' + innerHtml + '</div>';
    document.body.appendChild(root);
    // Click outside the card closes it.
    root.addEventListener("click", function (ev) {
      if (ev.target === root) root.remove();
    });
    return root;
  }

  // ----- Admin login modal ----------------------------------------
  async function ensureAdminLoggedIn() {
    await refreshAdminMe();
    if (adminMeCache.admin && !adminMeCache.needs_password_set) {
      return adminMeCache;
    }
    return new Promise(function (resolve) {
      // 2.17.2: admin identity = RDP / Windows login name. The "Your
      // name" topbar field is freeform and easily impersonated; the
      // RDP username is the actual Windows account the operator uses
      // to sign in to the bench, so we key admin off that.
      const rdpUser = getRdpUser();
      const hasAnyAdmin = adminMeCache.any_admin_exists;
      const pinConfigured = adminMeCache.legacy_pin_configured;
      const isFirstPasswordSet =
        adminMeCache.admin && adminMeCache.needs_password_set;

      const title = isFirstPasswordSet
        ? "Set your admin password"
        : hasAnyAdmin
          ? "Admin sign in"
          : "Become the first admin";

      const inner =
        '<div class="rdd-modal-head"><h3>' + escapeHtmlSafe(title) + '</h3>' +
          '<button type="button" class="rdd-modal-x" aria-label="Close">&times;</button>' +
        '</div>' +
        '<div class="rdd-modal-body">' +
          '<form id="admin-login-form" class="rdd-form">' +
            '<label>RDP / Windows login name' +
              '<input id="adm-op" type="text" autocomplete="username" required ' +
                ' placeholder="e.g. alice or DOMAIN\\alice"' +
                ' value="' + escapeHtmlSafe(rdpUser || adminMeCache.operator || "") + '">' +
            '</label>' +
            (isFirstPasswordSet
              ? ''
              : hasAnyAdmin
                ? '<label>Password' +
                    '<input id="adm-pw" type="password" autocomplete="current-password" required>' +
                  '</label>' +
                  (pinConfigured
                    ? '<details class="rdd-form-aside"><summary>Lost password? Use admin PIN.</summary>' +
                        '<label>Admin PIN' +
                          '<input id="adm-pin" type="password" autocomplete="off">' +
                        '</label>' +
                      '</details>'
                    : '')
                : '<label>Admin PIN (one-time bootstrap)' +
                    '<input id="adm-pin" type="password" autocomplete="off" required>' +
                  '</label>') +
            (isFirstPasswordSet || !hasAnyAdmin
              ? '<label>Choose your password' +
                  '<input id="adm-newpw" type="password" autocomplete="new-password" minlength="4" required>' +
                '</label>' +
                '<label>Confirm password' +
                  '<input id="adm-newpw2" type="password" autocomplete="new-password" minlength="4" required>' +
                '</label>'
              : '') +
            '<div class="rdd-form-actions">' +
              '<button type="submit" class="btn btn-primary">' +
                (isFirstPasswordSet
                  ? "Set password"
                  : hasAnyAdmin ? "Sign in" : "Bootstrap admin") +
              '</button>' +
              '<button type="button" class="btn btn-link rdd-modal-cancel">Cancel</button>' +
            '</div>' +
            '<p class="rdd-form-err muted small" id="adm-err"></p>' +
          '</form>' +
        '</div>';

      const root = buildModal("admin-login-modal", inner);

      function close(result) {
        root.remove();
        resolve(result);
      }
      root.querySelector(".rdd-modal-x").addEventListener("click", function () {
        close(null);
      });
      root.querySelector(".rdd-modal-cancel").addEventListener("click", function () {
        close(null);
      });

      const form = root.querySelector("#admin-login-form");
      const errBox = root.querySelector("#adm-err");

      form.addEventListener("submit", async function (ev) {
        ev.preventDefault();
        errBox.textContent = "";
        const operator = (root.querySelector("#adm-op").value || "").trim();
        const pwField = root.querySelector("#adm-pw");
        const pinField = root.querySelector("#adm-pin");
        const newpwField = root.querySelector("#adm-newpw");
        const newpw2Field = root.querySelector("#adm-newpw2");
        const password = pwField ? pwField.value : "";
        const adminPin = pinField ? pinField.value : "";
        const newPassword = newpwField ? newpwField.value : "";
        const confirmPassword = newpw2Field ? newpw2Field.value : "";

        if (newpwField && newPassword !== confirmPassword) {
          errBox.textContent = "Passwords don't match.";
          return;
        }

        try {
          // Step 1: if not yet logged in, sign in or bootstrap.
          if (!isFirstPasswordSet) {
            const body = { operator: operator };
            if (hasAnyAdmin && password) body.password = password;
            if (adminPin) body.admin_pin = adminPin;
            const r = await fetch("/api/v1/admin/login", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(body),
              credentials: "same-origin",
            });
            const d = await r.json();
            if (!r.ok) {
              errBox.textContent = (d && d.detail) || "Sign-in failed.";
              return;
            }
            // Refresh local cache before any password-set step.
            await refreshAdminMe();
          }

          // Step 2: if the caller (now) needs to set a password, do so.
          if (newpwField) {
            const r2 = await fetch("/api/v1/admin/set-password", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ new_password: newPassword }),
              credentials: "same-origin",
            });
            const d2 = await r2.json();
            if (!r2.ok) {
              errBox.textContent = (d2 && d2.detail) || "Could not set password.";
              return;
            }
            await refreshAdminMe();
          }

          showToast(
            "Signed in as " + (adminMeCache.operator || operator) + ".",
            false
          );
          close(adminMeCache);
        } catch (e) {
          errBox.textContent = "Network error: " + e.message;
        }
      });

      // Focus first empty input.
      const focusEl = root.querySelector("input:placeholder-shown") ||
                      root.querySelector("input");
      if (focusEl) setTimeout(function () { focusEl.focus(); }, 50);
    });
  }

  // ----- Locked-by-other (in-use) modal ----------------------------
  async function showLockedByOtherModal(ctx) {
    // ctx: { name, locked_by, lock_rdp_username, shared_with: [], action }
    await refreshAdminMe();
    const isAdmin = !!adminMeCache.admin;
    const sharedText = (ctx.shared_with && ctx.shared_with.length)
      ? "Already shared with: " + ctx.shared_with.join(", ")
      : "";

    const inner =
      '<div class="rdd-modal-head"><h3>' + escapeHtmlSafe(ctx.name) +
        ' is in use by ' + escapeHtmlSafe(ctx.locked_by) +
      '</h3><button type="button" class="rdd-modal-x" aria-label="Close">&times;</button></div>' +
      '<div class="rdd-modal-body">' +
        '<p class="rdd-form-info">' +
          'Pick how you want to proceed. Force takeover boots them out; ' +
          'sharing keeps them in and adds you alongside.' +
        '</p>' +
        (sharedText
          ? '<p class="muted small">' + escapeHtmlSafe(sharedText) + '</p>'
          : '') +
        '<div class="rdd-lock-actions">' +
          '<button type="button" class="btn btn-warning" id="lock-action-force">' +
            'Force takeover (kick ' + escapeHtmlSafe(ctx.locked_by) + ')' +
          '</button>' +
          '<button type="button" class="btn btn-primary' +
            (isAdmin ? '' : ' rdd-disabled') + '" id="lock-action-share"' +
            (isAdmin ? '' : ' disabled title="Admin only"') + '>' +
            'Share session ' + (isAdmin ? '' : '(admin only)') +
          '</button>' +
          (isAdmin
            ? ''
            : '<button type="button" class="btn btn-link" id="lock-action-as-admin">' +
                'Sign in as admin to share…' +
              '</button>') +
          '<button type="button" class="btn btn-link rdd-modal-cancel">Cancel</button>' +
        '</div>' +
        '<p class="muted xsmall">Force takeover is logged in audit history. ' +
        'The previous user will be kicked the next time the bench agent ' +
        'polls (a few seconds).</p>' +
      '</div>';

    const root = buildModal("locked-by-other-modal", inner);
    root.querySelector(".rdd-modal-x").addEventListener("click", function () {
      root.remove();
    });
    root.querySelector(".rdd-modal-cancel").addEventListener("click", function () {
      root.remove();
    });

    root.querySelector("#lock-action-force").addEventListener("click", async function () {
      root.remove();
      await forceTakeover(ctx.name);
    });
    const shareBtn = root.querySelector("#lock-action-share");
    if (isAdmin && shareBtn) {
      shareBtn.addEventListener("click", async function () {
        root.remove();
        await shareSession(ctx.name);
      });
    }
    const asAdminBtn = root.querySelector("#lock-action-as-admin");
    if (asAdminBtn) {
      asAdminBtn.addEventListener("click", async function () {
        root.remove();
        const me = await ensureAdminLoggedIn();
        if (me && me.admin) {
          // Re-show the popup now that they're an admin.
          showLockedByOtherModal(ctx);
        }
      });
    }
  }

  async function forceTakeover(name) {
    const op = getOperator();
    if (!op) {
      showToast("Enter your name first.", true);
      return;
    }
    showToast("Forcing takeover of " + name + "…", false);
    try {
      const r = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/force-takeover",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({
            operator: op,
            rdp_username: getRdpUsername(),
            use_hostname: !useIpCheckbox || !useIpCheckbox.checked,
          }),
        }
      );
      const d = await r.json();
      if (!r.ok) {
        showToast((d && d.detail && (d.detail.message || d.detail)) || "Takeover failed", true);
        return;
      }
      mergeMachineUpdate(d);
      // Now actually launch RDP, the normal way.
      connectMachine(name);
    } catch (e) {
      showToast("Takeover failed: " + e.message, true);
    }
  }

  async function shareSession(name) {
    const op = getOperator();
    if (!op) { showToast("Enter your name first.", true); return; }
    showToast("Adding you as a shared participant on " + name + "…", false);
    try {
      const r = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/share-session",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({
            operator: op,
            rdp_username: getRdpUsername(),
          }),
        }
      );
      const d = await r.json();
      if (!r.ok) {
        if (r.status === 403 || r.status === 401) {
          showToast("Admin sign-in required to share a session.", true);
          await ensureAdminLoggedIn();
          return;
        }
        showToast((d && d.detail) || "Share failed", true);
        return;
      }
      mergeMachineUpdate(d);
      showToast(
        "You are now sharing " + name + " with " + (d.locked_by || "the current user") + ".",
        false
      );
      // Now launch RDP for the shared participant.
      connectMachine(name);
    } catch (e) {
      showToast("Share failed: " + e.message, true);
    }
  }

  // True when the user/dashboard window lost focus during the launch
  // window — strong signal that an external app (mstsc) opened on top.
  function watchForExternalLaunch(timeoutMs, onTimeoutWithoutLaunch) {
    let launched = false;
    function markLaunched() { launched = true; }
    function onVisibility() {
      if (document.visibilityState === "hidden") launched = true;
    }
    window.addEventListener("blur", markLaunched, { once: true });
    document.addEventListener("visibilitychange", onVisibility);
    setTimeout(function () {
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("blur", markLaunched);
      if (!launched && typeof onTimeoutWithoutLaunch === "function") {
        onTimeoutWithoutLaunch();
      }
    }, timeoutMs);
  }

  async function tryLocalLaunch(url, timeoutMs) {
    if (!url) return null;
    const ms = timeoutMs || 3000;
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, ms);
    try {
      const r = await fetch(url, { method: "GET", mode: "cors", signal: ctrl.signal });
      clearTimeout(timer);
      if (!r.ok) return null;
      return r.json().catch(function () {
        return { ok: true, client: "unknown" };
      });
    } catch (e) {
      clearTimeout(timer);
      return null;
    }
  }

  function launchToast(client, target) {
    const dest = target ? " to " + target : "";
    // All clients are valid — mstsc is the universal default, msrdc is
    // an opt-in newer client. Don't shame either of them.
    showToast("Opening Remote Desktop" + dest + "…", false);
  }

  // Kept for the modal's "Open again" button if a user dismissed the
  // download prompt. Not called automatically from connect() anymore.
  async function launchRemoteSession(data) {
    showLaunchModal(data);
    return false;
  }

  function applyPermissionsUi() {
    // Manage / Settings buttons are only useful for admins (they perform
    // PIN-gated actions). We show them only when Admin mode is on; see
    // syncAdminUi() which actually toggles visibility via the body class.
    if (toggleManageBtn) {
      toggleManageBtn.title = "Manage machines (admin only)";
    }
    if (toggleSettingsBtn) {
      toggleSettingsBtn.title = "Server settings (admin only)";
    }
  }

  function updateServerBanner(meta) {
    if (!serverBanner) return;
    if (!meta || meta.monitor_configured !== false) {
      serverBanner.className = "server-banner hidden";
      serverBanner.textContent = "";
      return;
    }
    serverBanner.className = "server-banner";
    serverBanner.innerHTML =
      "<strong>Bench monitoring is not configured.</strong> " +
      "Open <strong>Settings</strong> and save the service account (admin.env is on the server).";
  }

  function on(el, event, fn) {
    if (el) el.addEventListener(event, fn);
  }

  on(launchTryLocal, "click", async function () {
    if (!lastLaunchData) return;
    if (lastLaunchData.local_launch_url) {
      const result = await tryLocalLaunch(lastLaunchData.local_launch_url);
      if (result && result.ok !== false) {
        launchToast(result.client || lastLaunchData.client, lastLaunchData.target_host);
        hideLaunchModal();
        return;
      }
    }
    showToast(
      "Could not launch Windows App on this PC. Install Microsoft Windows App or use Download .rdp.",
      true
    );
  });

  on(launchCopyRdp, "click", function () {
    if (!lastLaunchData) return;
    const uri = launchCopyRdp.dataset.uri || lastLaunchData.launch_uri || lastLaunchData.rdp_uri;
    if (!uri) return;
    navigator.clipboard.writeText(uri).then(function () {
      showToast("Copied RDP link", false);
    });
  });

  on(launchCopyMstsc, "click", function () {
    if (!lastLaunchData || !lastLaunchData.mstsc_command) return;
    navigator.clipboard.writeText(lastLaunchData.mstsc_command).then(function () {
      showToast("Copied: " + lastLaunchData.mstsc_command, false);
    });
  });

  on(launchClose, "click", hideLaunchModal);
  on(launchBackdrop, "click", hideLaunchModal);

  function fmt(value, fallback) {
    if (value === null || value === undefined || value === "") {
      return fallback || "\u2014";
    }
    if (Array.isArray(value)) {
      return value.length ? value.join(", ") : fallback || "\u2014";
    }
    return String(value);
  }

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }

  function updateSummary(list) {
    const online = list.filter(function (m) { return m.is_online; }).length;
    const locked = list.filter(function (m) { return m.is_locked; }).length;
    const offline = list.length - online;
    if (machineCount) {
      // Mini summary chips, color-coded.
      machineCount.innerHTML =
        '<span style="color: var(--text)">' + list.length + ' machines</span>' +
        ' \u2022 <span style="color: var(--success)">' + online + ' online</span>' +
        ' \u2022 <span style="color: var(--warn)">' + locked + ' in use</span>' +
        ' \u2022 <span style="color: var(--danger)">' + offline + ' offline</span>';
    }
  }

  function rowOptional(label, value) {
    if (value === null || value === undefined || value === "") return "";
    if (Array.isArray(value) && !value.length) return "";
    return row(label, value, true);
  }

  function row(label, value, active) {
    const display = fmt(value, "\u2014");
    const cls =
      "row-value" + (display === "\u2014" ? " empty" : active ? " active" : "");
    return (
      '<div class="row"><span class="row-label">' +
      escapeHtml(label) +
      '</span><span class="' +
      cls +
      '">' +
      escapeHtml(display) +
      "</span></div>"
    );
  }

  function lockBadge(m) {
    if (!m.is_locked || !m.locked_by) return "";
    const mine = m._mine || operatorsMatch(m.locked_by, getOperator());
    const shared = Array.isArray(m.lock_shared_with) ? m.lock_shared_with : [];
    let html =
      '<div class="lock-badge' +
      (mine ? " lock-mine" : "") +
      '">In use: <strong>' +
      escapeHtml(m.locked_by) +
      "</strong>";
    if (shared.length) {
      // 2.16.0: show the shared-session participants alongside the
      // primary lock owner so anyone on the dashboard can see who is
      // currently allowed on this bench at the same time.
      html +=
        '<span class="machine-shared-badge" title="Sharing with ' +
        escapeHtml(shared.join(", ")) +
        '">+' + shared.length + ' shared</span>';
    }
    html += "</div>";
    return html;
  }

  function actionButtons(m) {
    const mine = !!m._mine;
    const locked = !!(m.is_locked && m.locked_by);
    const lockedByOther = locked && !mine;
    const name = escapeHtml(m.name);

    // Label stays "Connect" even when mine — clicking again just
    // re-downloads the .rdp so the user can relaunch. Saying "Reconnect"
    // next to "Release" was confusing.
    const connectLabel = "Connect";
    const connectDisabled = lockedByOther;
    const connectTitle = lockedByOther
      ? "In use by " + escapeHtml(m.locked_by) + ". They must release first."
      : mine
      ? "Relaunch Remote Desktop to your reserved bench"
      : "Reserve and open Remote Desktop on " + m.name;

    const releaseDisabled = !mine;
    const releaseTitle = mine
      ? "Release your lock on " + m.name
      : locked
      ? "Locked by " + escapeHtml(m.locked_by) + " — admin only can force release"
      : "No active lock to release";

    let html = '<div class="card-actions">';
    html +=
      '<button type="button" class="btn btn-primary' +
      (connectDisabled ? " is-inactive" : "") +
      '" data-action="connect" data-name="' +
      name +
      '" aria-disabled="' +
      (connectDisabled ? "true" : "false") +
      '" title="' +
      connectTitle +
      '">' +
      connectLabel +
      "</button>";
    html +=
      '<button type="button" class="btn btn-secondary' +
      (releaseDisabled ? " is-inactive" : "") +
      '" data-action="release" data-name="' +
      name +
      '" aria-disabled="' +
      (releaseDisabled ? "true" : "false") +
      '" title="' +
      releaseTitle +
      '">Release</button>';
    html += "</div>";
    return html;
  }

  function statusDotClass(label) {
    if (label === "in_use") return "in_use";
    if (label === "online" || label === "reachable") return "online";
    if (label === "unknown") return "unknown";
    return "offline";
  }

  function formatTtl(seconds) {
    if (seconds === null || seconds === undefined) return "\u2014";
    if (seconds <= 0) return "0s";
    if (seconds < 60) return seconds + "s";
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return m + "m " + s + "s";
  }

  // SVG icons used by row-action buttons (kept tiny so the row stays compact).
  const ICON_RDP =
    '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
      '<rect x="2" y="4" width="20" height="14" rx="2"/>' +
      '<line x1="8" y1="22" x2="16" y2="22"/>' +
      '<line x1="12" y1="18" x2="12" y2="22"/>' +
    '</svg>';
  const ICON_RESERVE =
    '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
      '<polyline points="20 6 9 17 4 12"/>' +
    '</svg>';
  const ICON_RELEASE =
    '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M3 12a9 9 0 1 0 3-6.7"/>' +
      '<polyline points="3 4 3 10 9 10"/>' +
    '</svg>';

  function rowActionsHtml(m) {
    const mine = !!m._mine;
    const locked = !!(m.is_locked && m.locked_by);
    const lockedByOther = locked && !mine;
    const name = escapeHtml(m.name);

    // RDP button: reserve + open Remote Desktop. Same label whether
    // the bench is currently yours or free — clicking just re-launches
    // your session. "Reconnect" alongside "Release" confused users.
    const rdpDisabled = lockedByOther;
    const rdpLabel = "RDP";
    const rdpTitle = lockedByOther
      ? "In use by " + escapeHtml(m.locked_by) + " — they must release first"
      : mine
        ? "Relaunch Remote Desktop to your reserved bench"
        : "Reserve and open Remote Desktop";

    // Reserve: lock without launching RDP.
    const reserveDisabled = locked;  // already mine or someone else's
    const reserveTitle = mine
      ? "Already reserved by you"
      : lockedByOther
        ? "In use by " + escapeHtml(m.locked_by)
        : "Lock this bench under your name (no RDP yet)";

    // Release: only the lock owner can.
    const releaseDisabled = !mine;
    const releaseTitle = mine
      ? "Release your lock on " + escapeHtml(m.name)
      : locked
        ? "Only " + escapeHtml(m.locked_by) + " or an admin can release this"
        : "No active lock";

    const parts = [];
    parts.push(
      '<button type="button" class="btn btn-rdp btn-sm" data-action="connect" data-name="' + name + '"' +
        (rdpDisabled ? ' disabled' : '') +
        ' title="' + rdpTitle + '">' +
        ICON_RDP + '<span>' + rdpLabel + '</span></button>'
    );
    parts.push(
      '<button type="button" class="btn btn-reserve btn-sm" data-action="reserve" data-name="' + name + '"' +
        (reserveDisabled ? ' disabled' : '') +
        ' title="' + reserveTitle + '">' +
        ICON_RESERVE + '<span>Reserve</span></button>'
    );
    parts.push(
      '<button type="button" class="btn btn-release btn-sm" data-action="release" data-name="' + name + '"' +
        (releaseDisabled ? ' disabled' : '') +
        ' title="' + releaseTitle + '">' +
        ICON_RELEASE + '<span>Release</span></button>'
    );
    if (lockedByOther) {
      parts.push(
        '<button type="button" class="btn btn-secondary btn-sm admin-only" data-action="admin-release" data-name="' +
          name + '" title="Admin force release">Force</button>'
      );
    }
    return '<div class="row-actions">' + parts.join("") + "</div>";
  }

  async function reserveMachine(name) {
    const missing = missingRequiredFields();
    if (missing.length) {
      showToast("Required: " + missing.join(", "), true);
      focusFirstMissing();
      return;
    }
    const op = getOperator();
    savePrefs();
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/reserve",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            operator: op,
            rdp_username: getRdpUsername(),
            use_hostname: !useIpCheckbox || !useIpCheckbox.checked,
          }),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Reserve failed", true);
        return;
      }
      mergeMachineUpdate(data);
      startHeartbeat(name);
      showToast("Reserved " + name + " under your name. Click RDP to launch.", false);
    } catch (err) {
      showToast("Reserve failed: " + err, true);
    }
  }

  function statusDotHtml(m) {
    const label = m.status_label || (m.is_online ? "online" : "offline");
    return '<span class="status-dot ' + statusDotClass(label) + '" title="' + escapeHtml(m.status_display || "") + '"></span>';
  }

  function renderStatusTable(list) {
    if (!statusRowsEl) return;
    if (!list.length) {
      statusRowsEl.innerHTML =
        '<tr class="empty"><td colspan="6" class="muted">No machines registered. Open the manage drawer to add one.</td></tr>';
      return;
    }
    const op = getOperator();
    statusRowsEl.innerHTML = list.map(function (m) {
      const reservedCellClass = m.is_locked ? "cell-reserved busy" : "cell-reserved free";
      const reservedText = m.is_locked
        ? escapeHtml(m.locked_by || "(unknown)") + (m._mine ? " (you)" : "")
        : "Free";
      const rdpUser = m.is_locked
        ? escapeHtml(m.lock_rdp_username || m.locked_by || "")
        : (m.logged_in_users && m.logged_in_users.length
            ? escapeHtml(m.logged_in_users[0])
            : '<span class="muted">\u2014</span>');
      const ttl = m.is_locked ? formatTtl(m.lock_ttl_seconds) : "\u2014";
      const ttlCls = m.is_locked && m.lock_ttl_seconds !== null && m.lock_ttl_seconds < 15
        ? "cell-ttl warning" : "cell-ttl";
      const desc = m.description ? '<div class="desc">' + escapeHtml(m.description) + '</div>' : "";
      const selected = selectedMachine === m.name ? " selected" : "";
      const statusLabel = m.status_label || (m.is_online ? "online" : "offline");
      const stripeCls = " row-" + statusDotClass(statusLabel);
      return (
        '<tr data-name="' + escapeHtml(m.name) + '" class="row-machine' + stripeCls + selected + '">' +
          '<td><div class="cell-machine">' +
            '<div class="name">' + statusDotHtml(m) + escapeHtml(m.name) + '</div>' +
            desc +
          '</div></td>' +
          '<td><span class="cell-host">' + escapeHtml(m.hostname || "") + '</span></td>' +
          '<td>' + rdpUser + '</td>' +
          '<td><span class="' + reservedCellClass + '">' + reservedText + '</span></td>' +
          '<td><span class="' + ttlCls + '">' + escapeHtml(ttl) + '</span></td>' +
          '<td class="actions-col">' + rowActionsHtml(m) + '</td>' +
        '</tr>'
      );
    }).join("");
    if (statusUpdated) {
      const now = new Date();
      statusUpdated.textContent = "Updated " + now.toLocaleTimeString();
    }
  }

  function renderInventoryTable(list) {
    if (!inventoryRowsEl) return;
    if (!list.length) {
      inventoryRowsEl.innerHTML = '<tr class="empty"><td colspan="7" class="muted">No machines yet.</td></tr>';
      return;
    }
    inventoryRowsEl.innerHTML = list.map(function (m) {
      const com = m.com_port_user
        ? escapeHtml(m.com_port_user)
        : '<span class="muted">\u2014</span>';
      const agentPill = m.bench_agent_online
        ? '<span class="status-pill online" title="' + escapeHtml(m.bench_agent_version || "") + '">online</span>'
        : (m.bench_agent_last_seen
            ? '<span class="status-pill offline" title="Last heartbeat">' +
                escapeHtml(m.bench_agent_last_seen_relative || "stale") +
              '</span>'
            : '<span class="muted small">not installed</span>');
      return (
        '<tr data-name="' + escapeHtml(m.name) + '">' +
          '<td><div class="cell-machine">' +
            '<div class="name">' + escapeHtml(m.name) + '</div>' +
            (m.description ? '<div class="desc">' + escapeHtml(m.description) + '</div>' : "") +
          '</div></td>' +
          '<td><span class="cell-host">' + escapeHtml(m.hostname || "") + '</span></td>' +
          '<td><span class="cell-host">' + escapeHtml(m.ip_address || "") + '</span></td>' +
          '<td>' + (m.board ? escapeHtml(m.board) : '<span class="muted">\u2014</span>') + '</td>' +
          '<td>' + (m.access_note ? escapeHtml(m.access_note) : '<span class="muted">\u2014</span>') + '</td>' +
          '<td>' + com + '</td>' +
          '<td>' + agentPill + '</td>' +
        '</tr>'
      );
    }).join("");
  }

  function renderDetailPanel(name) {
    if (!detailPanelEl) return;
    if (!name) {
      detailPanelEl.innerHTML = '<div class="detail-empty muted small">Select a machine to see details.</div>';
      return;
    }
    const m = machines.find(function (x) { return x.name === name; });
    if (!m) {
      detailPanelEl.innerHTML = '<div class="detail-empty muted small">Machine not found.</div>';
      return;
    }
    const reserved = m.is_locked
      ? '<span class="detail-state busy">In use by ' + escapeHtml(m.locked_by || "?") + (m._mine ? " (you)" : "") + "</span>"
      : '<span class="detail-state free">Free</span>';
    const sessionUsers = (m.logged_in_users && m.logged_in_users.length)
      ? escapeHtml(m.logged_in_users.join(", "))
      : (m.is_reachable ? '<span class="muted">None / no active logons</span>' : '<span class="muted">unreachable</span>');
    const ttl = m.is_locked ? formatTtl(m.lock_ttl_seconds) : "\u2014";
    const agentLine = m.bench_agent_online
      ? '<span class="status-pill online">agent v' + escapeHtml(m.bench_agent_version || "?") + " online</span>"
      : (m.bench_agent_last_seen
          ? '<span class="status-pill offline">agent ' +
              escapeHtml(m.bench_agent_last_seen_relative || "stale") +
            '</span>'
          : '<span class="muted">agent not installed</span>');
    detailPanelEl.innerHTML =
      '<div class="detail-head">' +
        '<div><div class="machine-id">' + escapeHtml(m.name) + '</div>' +
          (m.description ? '<div class="muted small">' + escapeHtml(m.description) + '</div>' : "") +
        '</div>' +
        statusDotHtml(m) +
      '</div>' +
      '<div class="detail-section"><h4>Status</h4><div class="kv">' + reserved +
        (m.is_locked ? ' \u2022 Auto-release in <strong>' + escapeHtml(ttl) + '</strong>' : '') +
      '</div></div>' +
      '<div class="detail-section"><h4>Host</h4><div class="kv">' +
        '<div><code>' + escapeHtml(m.hostname || "") + '</code></div>' +
        '<div><code>' + escapeHtml(m.ip_address || "") + '</code></div>' +
      '</div></div>' +
      (m.board
        ? '<div class="detail-section"><h4>Board</h4><div class="kv">' + escapeHtml(m.board) + '</div></div>'
        : "") +
      (m.access_note
        ? '<div class="detail-section"><h4>Access</h4><div class="kv">' + escapeHtml(m.access_note) + '</div></div>'
        : "") +
      '<div class="detail-section"><h4>RDP sessions</h4><div class="kv">' + sessionUsers + '</div></div>' +
      (m.com_port_user
        ? '<div class="detail-section"><h4>COM ports</h4><div class="kv">' + escapeHtml(m.com_port_user) + '</div></div>'
        : "") +
      '<div class="detail-section"><h4>Bench agent</h4><div class="kv">' + agentLine + '</div></div>' +
      '<div class="detail-actions">' + rowActionsHtml(m).replace(/btn-sm/g, "") + '</div>' +
      '<div class="detail-section admin-only">' +
        '<h4>Admin tools</h4>' +
        '<div class="form-actions">' +
          '<button type="button" class="btn btn-secondary btn-sm" data-action="emergency-restore" data-name="' + escapeHtml(m.name) + '" ' +
            'title="Tell the bench agent to remove the custom firewall lock and re-enable built-in Remote Desktop rules.">' +
            'Restore native RDP' +
          '</button>' +
          (m.is_locked ? '<button type="button" class="btn btn-secondary btn-sm" data-action="admin-release" data-name="' + escapeHtml(m.name) + '">Force release</button>' : '') +
          '<button type="button" class="btn btn-secondary btn-sm" data-action="kick-others" data-name="' + escapeHtml(m.name) + '">Kick other RDP sessions</button>' +
        '</div>' +
      '</div>';
  }

  // ---- Audit log -----------------------------------------------------------
  async function loadAndRenderAudit() {
    if (!auditRowsEl) return;
    const qs = new URLSearchParams();
    if (auditActionFilter && auditActionFilter.value) qs.set("action", auditActionFilter.value);
    if (auditMachineFilter && auditMachineFilter.value.trim()) qs.set("machine", auditMachineFilter.value.trim().toUpperCase());
    if (auditOperatorFilter && auditOperatorFilter.value.trim()) qs.set("operator", auditOperatorFilter.value.trim());
    qs.set("limit", "300");
    auditRowsEl.innerHTML = '<tr class="empty"><td colspan="6" class="muted">Loading audit\u2026</td></tr>';
    try {
      const res = await fetch("/api/v1/audit?" + qs.toString());
      if (!res.ok) {
        auditRowsEl.innerHTML = '<tr class="empty"><td colspan="6" class="muted">Audit fetch failed.</td></tr>';
        return;
      }
      auditCache = await res.json();
      if (!auditCache.length) {
        auditRowsEl.innerHTML = '<tr class="empty"><td colspan="6" class="muted">No audit events match these filters.</td></tr>';
        return;
      }
      auditRowsEl.innerHTML = auditCache.map(function (e) {
        const ts = e.created_at ? new Date(e.created_at).toLocaleString() : "";
        const actionCls = "audit-action-pill " + escapeHtml(e.action || "");
        return (
          "<tr>" +
            '<td class="audit-ts-col">' + escapeHtml(ts) + "</td>" +
            '<td><span class="' + actionCls + '">' + escapeHtml(e.action || "") + "</span></td>" +
            "<td>" + (e.machine_name ? escapeHtml(e.machine_name) : '<span class="muted">\u2014</span>') + "</td>" +
            "<td>" + (e.operator ? escapeHtml(e.operator) : '<span class="muted">\u2014</span>') + "</td>" +
            "<td>" + (e.detail ? escapeHtml(e.detail) : '<span class="muted">\u2014</span>') + "</td>" +
            '<td class="audit-ip-col">' + (e.client_ip ? escapeHtml(e.client_ip) : '<span class="muted">\u2014</span>') + "</td>" +
          "</tr>"
        );
      }).join("");
    } catch (err) {
      auditRowsEl.innerHTML = '<tr class="empty"><td colspan="6" class="muted">Network error.</td></tr>';
    }
  }

  // ---- Tab switching -------------------------------------------------------
  function setActiveTab(name) {
    activeTab = name;
    tabButtons.forEach(function (b) {
      const active = b.dataset.tab === name;
      b.classList.toggle("active", active);
      b.setAttribute("aria-selected", active ? "true" : "false");
    });
    tabPanels.forEach(function (p) {
      p.classList.toggle("hidden", p.dataset.panel !== name);
    });
    if (name === "audit") {
      loadAndRenderAudit();
    } else if (name === "inventory") {
      renderInventoryTable(machines);
    }
  }
  tabButtons.forEach(function (b) {
    b.addEventListener("click", function () { setActiveTab(b.dataset.tab); });
  });

  function render(list) {
    machines = list.map(enrichMachine);
    machines.sort(function (a, b) {
      return a.name.localeCompare(b.name, undefined, { numeric: true });
    });
    updateSummary(machines);
    renderStatusTable(machines);
    if (activeTab === "inventory") renderInventoryTable(machines);
    if (selectedMachine) renderDetailPanel(selectedMachine);
    if (lastUpdate) lastUpdate.textContent = "Updated " + new Date().toLocaleTimeString();
    syncHeartbeatsFromState();
  }

  // Re-tick TTL & "agent online" every 1s using last known machines snapshot.
  setInterval(function () {
    if (!machines.length) return;
    // Decrement TTL purely on the client until next push from server.
    machines.forEach(function (m) {
      if (m.is_locked && typeof m.lock_ttl_seconds === "number" && m.lock_ttl_seconds > 0) {
        m.lock_ttl_seconds = Math.max(0, m.lock_ttl_seconds - 1);
      }
    });
    if (activeTab === "status") renderStatusTable(machines);
    if (selectedMachine) renderDetailPanel(selectedMachine);
  }, 1000);

  // ---- Status table row clicks (selection + delegated buttons) -----------
  if (statusRowsEl) {
    statusRowsEl.addEventListener("click", function (ev) {
      const btn = ev.target.closest("button[data-action]");
      if (btn) return; // button handler below picks it up
      const row = ev.target.closest("tr.row-machine");
      if (!row) return;
      selectedMachine = row.dataset.name;
      renderStatusTable(machines);
      renderDetailPanel(selectedMachine);
    });
  }
  if (auditRefreshBtn) auditRefreshBtn.addEventListener("click", loadAndRenderAudit);
  [auditActionFilter, auditMachineFilter, auditOperatorFilter].forEach(function (el) {
    if (el) el.addEventListener("change", loadAndRenderAudit);
  });

  function syncHeartbeatsFromState() {
    const op = getOperator();
    const mine = new Set();
    if (op) {
      machines.forEach(function (m) {
        if (m._mine || (m.is_locked && operatorsMatch(m.locked_by, op))) {
          mine.add(m.name);
        }
      });
    }
    mine.forEach(function (name) {
      if (!heartbeatTimers[name]) startHeartbeat(name);
    });
    Object.keys(heartbeatTimers).forEach(function (name) {
      if (!mine.has(name)) stopHeartbeat(name);
    });
  }

  function setWsStatus(state, text) {
    if (!wsStatus) return;
    wsStatus.className = "status-pill status-" + state;
    wsStatus.textContent = text;
  }

  function sendHeartbeat(name) {
    const op = getOperator();
    if (!op) return;
    fetch("/api/v1/machines/" + encodeURIComponent(name) + "/lock/heartbeat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ operator: op }),
    }).catch(function () {});
  }

  function startHeartbeat(name) {
    stopHeartbeat(name);
    sendHeartbeat(name);
    heartbeatTimers[name] = setInterval(function () {
      sendHeartbeat(name);
    }, HEARTBEAT_MS);
  }

  function stopHeartbeat(name) {
    if (heartbeatTimers[name]) {
      clearInterval(heartbeatTimers[name]);
      delete heartbeatTimers[name];
    }
  }

  function stopAllHeartbeats() {
    Object.keys(heartbeatTimers).forEach(stopHeartbeat);
  }

  function showGuardStatus(name, guard) {
    if (!guard) return;
    if (guard.status === "agent") {
      showToast(
        "Access on " + name +
          " is enforced by the bench agent (Remote Desktop Users group + session kicks).",
        false
      );
      return;
    }
    if (!guard.enabled) {
      return;
    }
    if (guard.status === "skipped" || guard.status === "no_client_ip") {
      const reason =
        guard.reason ||
        "Add your PC's LAN IP to RDD_RDP_GUARD_EXTRA_IPS in admin.env, or set RDD_RDP_GUARD_ENABLED=false to silence this.";
      showToast(
        "Heads up: dashboard lock is active, but the direct-RDP block was skipped. " +
          reason,
        true
      );
      return;
    }
    if (guard.status === "pending" || guard.status === "running") {
      setTimeout(function () { pollGuardStatus(name, 1); }, 3000);
      return;
    }
  }

  async function pollGuardStatus(name, attempt) {
    const MAX_ATTEMPTS = 30;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/guard"
      );
      if (!res.ok) {
        if (attempt < MAX_ATTEMPTS) {
          setTimeout(function () { pollGuardStatus(name, attempt + 1); }, 3000);
        }
        return;
      }
      const g = await res.json();
      if (g.status === "ok") {
        showToast(
          "RDP locked on " +
            name +
            " — only " +
            (g.allow_ips || []).join(", ") +
            " can RDP.",
          false
        );
        return;
      }
      if (g.status === "failed" || g.status === "error") {
        showToast(
          "Direct-RDP block could not be applied on " +
            name +
            " (remote netsh blocked or monitor account isn't local admin). " +
            "The dashboard lock still prevents others from connecting through this dashboard. " +
            "To silence this warning, set RDD_RDP_GUARD_ENABLED=false in admin.env.",
          true
        );
        return;
      }
      if (attempt < MAX_ATTEMPTS) {
        setTimeout(function () { pollGuardStatus(name, attempt + 1); }, 3000);
      } else {
        showToast(
          "Direct-RDP block on " +
            name +
            " is still running on the server. The dashboard lock is active either way.",
          false
        );
      }
    } catch (e) {
      if (attempt < MAX_ATTEMPTS) {
        setTimeout(function () { pollGuardStatus(name, attempt + 1); }, 3000);
      }
    }
  }

  const inFlightConnects = new Set();

  function userMatchesActiveSession(machine) {
    // Compare ONLY against Windows account names — the operator's typed
    // "name" (e.g. "Naveen Kennedy") is a display label and is not what
    // qwinsta reports. We match the rdp_user the operator entered
    // (e.g. "nkennedy") with and without a DOMAIN\ prefix.
    const rdpUser = (rdpUserInput.value || "").trim().toLowerCase();
    if (!rdpUser) return null;
    const candidates = new Set([rdpUser]);
    const domain = getRdpDomain().toLowerCase();
    if (domain) candidates.add(domain + "\\" + rdpUser);

    const users = (machine.logged_in_users || []).map(function (u) {
      return (u || "").trim().toLowerCase();
    });
    for (const u of users) {
      // Strip DOMAIN\ prefix on the session side too — qwinsta sometimes
      // returns "DOMAIN\user" and sometimes just "user".
      const bare = u.includes("\\") ? u.split("\\").pop() : u;
      if (candidates.has(u) || candidates.has(bare)) return u;
    }
    return null;
  }

  async function connectMachine(name) {
    const missing = missingRequiredFields();
    if (missing.length) {
      showToast("Required: " + missing.join(", "), true);
      focusFirstMissing();
      return;
    }
    if (inFlightConnects.has(name)) {
      return;
    }
    const op = getOperator();
    const existing = machines.find(function (x) {
      return x.name === name;
    });

    if (existing && (existing.logged_in_users || []).length) {
      const match = userMatchesActiveSession(existing);
      if (match) {
        showToast(
          "You already have an active session on " +
            name +
            " (logged in as " +
            match +
            "). Reconnecting will join it.",
          false
        );
      } else if (!(existing.is_locked && existing._mine)) {
        const activeUsers = existing.logged_in_users.join(", ");
        const ok = window.confirm(
          name +
            " currently has active session(s): " +
            activeUsers +
            ".\n\nConnect anyway? You'll share the bench with " +
            activeUsers +
            "."
        );
        if (!ok) return;
      }
    }

    if (existing && existing.is_locked && existing.locked_by && !existing._mine) {
      // 2.16.0: instead of a hard toast that ends the interaction,
      // open the structured in-use modal so the operator can choose
      // Force takeover (any role) or Share session (admin only).
      const sharedList = (existing.lock_shared_with || []).slice();
      showLockedByOtherModal({
        name: name,
        locked_by: existing.locked_by,
        lock_rdp_username: existing.lock_rdp_username || "",
        shared_with: sharedList,
        action: "connect",
      });
      return;
    }
    savePrefs();
    inFlightConnects.add(name);
    showToast("Connecting to " + name + "…", false);
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/connect",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            operator: op,
            rdp_username: getRdpUsername(),
            use_hostname: !useIpCheckbox || !useIpCheckbox.checked,
          }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        // 2.16.0: structured 409 with locked_by_other → show the role-aware
        // popup so the operator can pick Force takeover / Share session.
        const detail = data && data.detail;
        if (
          res.status === 409 &&
          detail && typeof detail === "object" &&
          detail.code === "locked_by_other"
        ) {
          showLockedByOtherModal({
            name: name,
            locked_by: detail.locked_by || "",
            lock_rdp_username: detail.lock_rdp_username || "",
            shared_with: detail.shared_with || [],
            action: detail.action || "connect",
          });
          return;
        }
        showToast(
          (detail && (detail.message || (typeof detail === "string" ? detail : null))) ||
            "Cannot connect",
          true
        );
        return;
      }
      if (data.machine) mergeMachineUpdate(data.machine);
      else loadDashboard();
      startHeartbeat(name);
      showGuardStatus(name, data.guard);

      lastLaunchData = data;
      openRemoteDesktop(data);
    } catch (e) {
      showToast("Connection failed: " + e.message, true);
    } finally {
      inFlightConnects.delete(name);
    }
  }

  function setMachinePolling(name, active) {
    if (active) {
      pollingMachines.add(name);
    } else {
      pollingMachines.delete(name);
    }
    if (machines.length) {
      render(machines);
    }
  }

  async function pollMachine(name) {
    const op = getOperator();
    const q = op ? "?operator=" + encodeURIComponent(op) : "";
    setMachinePolling(name, true);
    showToast("Refreshing session for " + name + "…", false);
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, 90000);
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/poll-now" + q,
        { method: "POST", signal: ctrl.signal }
      );
      clearTimeout(timer);
      const data = await res.json();
      if (!res.ok) {
        showToast(data.detail || "Poll failed", true);
        return;
      }
      if (data.machine) mergeMachineUpdate(data.machine);
      if (data.ok) {
        showToast("Session updated for " + name, false);
      } else {
        showToast(data.error || "Poll failed — check Server settings credentials", true);
      }
      loadDashboard();
    } catch (e) {
      clearTimeout(timer);
      if (e.name === "AbortError") {
        showToast("Poll still running — live update when ready", false);
      } else {
        showToast("Poll failed: " + e.message, true);
      }
    } finally {
      setMachinePolling(name, false);
    }
  }


  async function adminReleaseMachine(name) {
    const me = await ensureAdminLoggedIn();
    if (!me || !me.admin) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/admin-release",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({}),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Admin release failed", true);
        return;
      }
      showToast("Lock released on " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Admin release failed", true);
    }
  }


  async function emergencyRestoreRdp(name) {
    const me = await ensureAdminLoggedIn();
    if (!me || !me.admin) return;
    const ok = window.confirm(
      "Emergency restore of native RDP on " + name + "?\n\n" +
      "This tells the bench agent to:\n" +
      "  \u2022 Remove its custom firewall lock rule on TCP 3389\n" +
      "  \u2022 Re-enable the built-in Windows \u201cRemote Desktop\u201d rules\n" +
      "  \u2022 Release the dashboard lock\n\n" +
      "RDP on " + name + " will revert to its default Windows behaviour. " +
      "Use this only if something is wrong and you need to get RDP back."
    );
    if (!ok) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/emergency-restore-rdp",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({}),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Emergency restore failed.", true);
        return;
      }
      showToast(
        "Restore queued for " + name +
          ". Agent will revert within ~5s on next poll.",
        false
      );
      // Show the manual fallback in the diagnostic modal so admin has it
      // handy if the agent is offline.
      showDiagModal({
        machine_name: name,
        verdict: "Emergency restore queued",
        dashboard_view: {},
        config: {},
        smb_ok: true,
        config_present: true,
        log_present: true,
        log_tail: [
          "Restore queued. Agent will apply on next poll.",
          "",
          "If the agent is offline, run this on the bench (elevated PowerShell):",
          "",
          (data.manual_powershell || ""),
        ],
      });
    } catch (err) {
      showToast("Network error: " + err, true);
    }
  }

  async function kickOthersMachine(name) {
    if (
      !window.confirm(
        "Log off everyone connected to " +
          name +
          " except the current lock owner?\n\n" +
          "This only works if the bench agent is installed and running on " +
          name +
          "."
      )
    )
      return;
    const me = await ensureAdminLoggedIn();
    if (!me || !me.admin) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/kick-others",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({}),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Kick request failed", true);
        return;
      }
      showToast(
        "Kick requested on " + name + " — unauthorized sessions will be logged off shortly.",
        false
      );
      loadDashboard();
    } catch (e) {
      showToast("Kick request failed", true);
    }
  }

  async function releaseMachine(name) {
    const op = getOperator();
    if (!op) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/release",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ operator: op }),
        }
      );
      if (!res.ok) {
        const data = await res.json();
        showToast(data.detail || "Release failed", true);
        return;
      }
      stopHeartbeat(name);
      showToast("Released " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Release failed", true);
    }
  }

  function loadDashboard() {
    const op = getOperator();
    const q = op ? "?operator=" + encodeURIComponent(op) : "";
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, 20000);
    return fetch("/api/v1/dashboard/fast" + q, { signal: ctrl.signal })
      .then(function (r) {
        clearTimeout(timer);
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        if (data.monitor_configured !== undefined) {
          serverMeta.monitor_configured = data.monitor_configured;
          serverMeta.monitor_hint = data.monitor_hint;
          serverMeta.admin_pin_required = data.admin_pin_required;
          if (data.users_can_connect !== undefined) {
            serverMeta.users_can_connect = data.users_can_connect;
          }
          if (data.users_can_manage_machines !== undefined) {
            serverMeta.users_can_manage_machines = data.users_can_manage_machines;
          }
          updateServerBanner(serverMeta);
          applyPermissionsUi();
        }
        if (data.machines) {
          render(data.machines);
          setWsStatus("ok", "Live");
        }
      })
      .catch(function (err) {
        clearTimeout(timer);
        if (err.name === "AbortError") {
          setWsStatus("err", "Slow");
          if (statusRowsEl) statusRowsEl.innerHTML =
            '<tr class="empty"><td colspan="6" class="muted">Server is taking too long to respond. Try refreshing.</td></tr>';
        } else {
          setWsStatus("err", "Offline");
          if (statusRowsEl) statusRowsEl.innerHTML =
            '<tr class="empty"><td colspan="6" class="muted">Cannot reach the dashboard server.</td></tr>';
        }
      });
  }

  const settingsForm = document.getElementById("settings-form");
  const setDomain = document.getElementById("set-domain");
  const setUsername = document.getElementById("set-username");
  const setPassword = document.getElementById("set-password");
  const setTestHost = document.getElementById("set-test-host");
  const setTestBtn = document.getElementById("set-test-btn");
  const settingsStatus = document.getElementById("settings-status");
  // PIN field has been removed from Settings as of 2.10.1; the cached admin
  // PIN from sessionStorage (set via the Admin sign-in modal) is sent instead.
  const setAdminPin = null;
  const setPinRow = null;
  const machineForm = document.getElementById("machine-form");
  const editMachineId = document.getElementById("edit-machine-id");
  const mfName = document.getElementById("mf-name");
  const mfHostname = document.getElementById("mf-hostname");
  const mfIp = document.getElementById("mf-ip");
  const mfDescription = document.getElementById("mf-description");
  const mfBoard = document.getElementById("mf-board");
  const mfAccess = document.getElementById("mf-access");
  const mfCancel = document.getElementById("mf-cancel");
  const machineAdminList = document.getElementById("machine-admin-list");

  // ---- Drawers (Manage Machines + Settings) ------------------------------
  async function openDrawer(drawer) {
    if (!drawer) return;
    if (drawer === manageDrawer || drawer === settingsDrawer) {
      const me = await ensureAdminLoggedIn();
      if (!me || !me.admin) {
        showToast("Sign in as admin to open this panel.", true);
        return;
      }
      syncAdminUi();
    }
    drawer.classList.remove("hidden");
    drawer.setAttribute("aria-hidden", "false");
    if (drawer === manageDrawer) refreshAdminMachineList();
    if (drawer === settingsDrawer) {
      loadMonitorSettings();
      loadBenchAgents();
      loadAdminUsers();
    }
  }
  function closeDrawer(drawer) {
    if (!drawer) return;
    drawer.classList.add("hidden");
    drawer.setAttribute("aria-hidden", "true");
  }
  if (toggleManageBtn) toggleManageBtn.addEventListener("click", function () { openDrawer(manageDrawer); });
  if (toggleSettingsBtn) toggleSettingsBtn.addEventListener("click", function () { openDrawer(settingsDrawer); });
  document.addEventListener("click", function (ev) {
    if (ev.target.matches("[data-close-drawer]")) {
      const d = ev.target.closest(".drawer");
      if (d) closeDrawer(d);
    }
  });
  document.addEventListener("keydown", function (ev) {
    if (ev.key === "Escape") {
      [manageDrawer, settingsDrawer].forEach(function (d) {
        if (d && !d.classList.contains("hidden")) closeDrawer(d);
      });
    }
  });

  // Render the existing-machines list inside the Manage drawer.
  function refreshAdminMachineList() {
    if (!machineAdminList) return;
    if (!machines.length) {
      machineAdminList.innerHTML = '<p class="muted small">No machines yet. Add one above.</p>';
      return;
    }
    machineAdminList.innerHTML = machines.map(function (m) {
      return (
        '<div class="admin-row">' +
          '<div>' +
            '<div class="name">' + escapeHtml(m.name) + '</div>' +
            '<div class="meta">' + escapeHtml(m.hostname || "") + ' \u2022 ' + escapeHtml(m.ip_address || "") +
              (m.description ? ' \u2022 ' + escapeHtml(m.description) : "") +
            '</div>' +
          '</div>' +
          '<div class="row-actions">' +
            '<button type="button" class="btn btn-secondary btn-sm" data-action="edit" data-id="' + m.id + '" data-name="' + escapeHtml(m.name) + '">Edit</button>' +
            '<button type="button" class="btn btn-danger btn-sm" data-action="delete" data-name="' + escapeHtml(m.name) + '">Delete</button>' +
          '</div>' +
        '</div>'
      );
    }).join("");
  }

  // Legacy guard UI has been removed in 2.10.1 — the bench agent does the
  // hard lock locally now. The legacy guard endpoints still exist on the
  // server for back-compat but no UI surfaces them.

  const benchCopyCmdBtn = document.getElementById("bench-copy-cmd-btn");
  const benchDownloadBtn = document.getElementById("bench-download-installer-btn");
  const benchRefreshBtn = document.getElementById("bench-refresh-btn");
  const benchInstallCmdEl = document.getElementById("bench-install-cmd");
  const benchAgentListEl = document.getElementById("bench-agent-list");
  const benchUrlsEl = document.getElementById("bench-urls");
  const benchInstallerUrlEl = document.getElementById("bench-installer-url");
  const benchAgentUrlEl = document.getElementById("bench-agent-url");

  async function fetchInstallCommand() {
    const res = await fetch("/api/v1/agent/install-command", {
      credentials: "same-origin",
    });
    const data = await res.json().catch(function () { return {}; });
    if (!res.ok) {
      return { error: data.detail || "Could not get install command.", status: res.status };
    }
    return { data: data };
  }

  if (benchCopyCmdBtn) {
    benchCopyCmdBtn.addEventListener("click", async function () {
      const me = await ensureAdminLoggedIn();
      if (!me || !me.admin) return;

      let result = await fetchInstallCommand();
      if (result.error && result.status === 403) {
        showToast("Sign in as admin to reveal the install command.", true);
        return;
      }
      if (result.error) {
        showToast(result.error, true);
        return;
      }
      const data = result.data;
      if (benchInstallCmdEl) {
        benchInstallCmdEl.textContent = data.command;
        benchInstallCmdEl.classList.remove("hidden");
      }
      if (benchUrlsEl && data.installer_url && data.agent_url) {
        benchInstallerUrlEl.textContent = "installer:  " + data.installer_url;
        benchAgentUrlEl.textContent = "agent:      " + data.agent_url;
        benchUrlsEl.classList.remove("hidden");
      }
      try {
        await navigator.clipboard.writeText(data.command);
        showToast("Install command copied. Paste into elevated PowerShell on each bench.", false);
      } catch (err) {
        showToast("Could not access clipboard — select and copy the text shown below.", true);
      }
    });
  }

  if (benchDownloadBtn) {
    benchDownloadBtn.addEventListener("click", async function () {
      const me = await ensureAdminLoggedIn();
      if (!me || !me.admin) return;
      const result = await fetchInstallCommand();
      if (result.error) {
        showToast(result.error, true);
        return;
      }
      const url = result.data.installer_url;
      if (!url) {
        showToast("Installer URL not available.", true);
        return;
      }
      window.open(url, "_blank");
    });
  }

  async function loadBenchAgents() {
    if (!benchAgentListEl) return;
    benchAgentListEl.innerHTML = '<div class="muted small">Loading agents…</div>';
    try {
      // One round trip for the whole fleet. Used to be one fetch per
      // machine — slow and DB-heavy with many benches and many open
      // dashboards. The aggregate endpoint returns the same per-machine
      // shape so the rendering below is unchanged.
      const aggRes = await fetch("/api/v1/agents/status");
      const aggData = aggRes.ok ? await aggRes.json() : { agents: [] };
      const results = Array.isArray(aggData.agents) ? aggData.agents : [];
      const html = results
        .filter(function (x) { return x; })
        .map(function (s) {
          const cls = "agent-pill" +
            (s.online ? " online" : "") +
            (s.error ? " error" : "");
          let metaParts = [];
          if (!s.installed) {
            metaParts.push("not installed yet");
          } else {
            metaParts.push(
              s.online
                ? "online (" + Math.round(s.last_seen_seconds_ago || 0) + "s ago)"
                : "offline (last " + Math.round(s.last_seen_seconds_ago || 0) + "s ago)"
            );
            if (s.version) metaParts.push("v" + s.version);
            if (s.applied_users && s.applied_users.length) {
              metaParts.push("allow: " + s.applied_users.join(", "));
            }
          }
          if (s.error) metaParts.push("error: " + s.error);
          const installBtn =
            '<button type="button" class="btn btn-sm btn-primary" ' +
            'data-action="push-install" data-name="' + escapeHtml(s.machine_name) + '">' +
            (s.installed ? "Reinstall" : "Push install") + "</button>";
          const diagBtn =
            '<button type="button" class="btn btn-sm btn-secondary" ' +
            'data-action="diagnose" data-name="' + escapeHtml(s.machine_name) + '">' +
            "Diagnose</button>";
          const uninstallBtn = s.installed
            ? '<button type="button" class="btn btn-sm btn-secondary" ' +
              'data-action="push-uninstall" data-name="' + escapeHtml(s.machine_name) + '">' +
              "Remove</button>"
            : "";
          return (
            '<div class="' + cls + '">' +
              '<span class="agent-name">' + escapeHtml(s.machine_name) + "</span>" +
              '<span class="agent-meta">' + escapeHtml(metaParts.join(" · ")) + "</span>" +
              '<div class="agent-actions">' + installBtn + diagBtn + uninstallBtn + "</div>" +
            "</div>"
          );
        })
        .join("");
      benchAgentListEl.innerHTML = html ||
        '<div class="muted small">No machines configured.</div>';
    } catch (err) {
      benchAgentListEl.innerHTML =
        '<div class="muted small">Could not load agent status.</div>';
    }
  }

  const adminUsersListEl = document.getElementById("admin-users-list");
  const adminPromoteForm = document.getElementById("admin-promote-form");
  const adminPromoteName = document.getElementById("admin-promote-name");
  const adminPromoteFlag = document.getElementById("admin-promote-flag");
  const adminPasswordForm = document.getElementById("admin-password-form");
  const adminCurrentPw = document.getElementById("admin-current-pw");
  const adminNewPw = document.getElementById("admin-new-pw");

  async function loadAdminUsers() {
    if (!adminUsersListEl) return;
    if (!isAdmin()) {
      adminUsersListEl.innerHTML =
        '<p class="muted small">Sign in as admin to manage accounts.</p>';
      return;
    }
    adminUsersListEl.innerHTML = '<p class="muted small">Loading…</p>';
    try {
      const res = await fetch("/api/v1/admin/users", { credentials: "same-origin" });
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        adminUsersListEl.innerHTML =
          '<p class="muted small">' + escapeHtml(data.detail || "Could not load admins.") + "</p>";
        return;
      }
      const admins = data.admins || [];
      if (!admins.length) {
        adminUsersListEl.innerHTML =
          '<p class="muted small">No admin accounts yet. Promote an operator below.</p>';
        return;
      }
      adminUsersListEl.innerHTML = admins
        .map(function (a) {
          const meta = a.has_password ? "password set" : "needs password on first sign-in";
          const label = a.name + " (RDP login)";
          return (
            '<div class="admin-row">' +
              '<span class="name">' + escapeHtml(label) + "</span>" +
              '<span class="meta">' + escapeHtml(meta) + "</span>" +
              '<button type="button" class="btn btn-sm btn-secondary admin-revoke-btn" ' +
                'data-operator="' + escapeHtml(a.name) + '">Revoke</button>' +
            "</div>"
          );
        })
        .join("");
    } catch (_) {
      adminUsersListEl.innerHTML =
        '<p class="muted small">Network error loading admin accounts.</p>';
    }
  }

  if (adminUsersListEl) {
    adminUsersListEl.addEventListener("click", async function (ev) {
      const btn = ev.target.closest(".admin-revoke-btn");
      if (!btn) return;
      const operator = btn.dataset.operator || "";
      if (!operator) return;
      if (!window.confirm("Revoke admin access for " + operator + "?")) return;
      try {
        const res = await fetch("/api/v1/admin/users", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({ operator: operator, is_admin: false }),
        });
        const data = await res.json().catch(function () { return {}; });
        if (!res.ok) {
          showToast(data.detail || "Could not revoke admin.", true);
          return;
        }
        showToast("Revoked admin for " + operator, false);
        loadAdminUsers();
      } catch (err) {
        showToast("Network error: " + err, true);
      }
    });
  }

  if (adminPromoteForm) {
    adminPromoteForm.addEventListener("submit", async function (ev) {
      ev.preventDefault();
      const me = await ensureAdminLoggedIn();
      if (!me || !me.admin) return;
      const operator = (adminPromoteName && adminPromoteName.value || "").trim();
      if (!operator) {
        showToast("Enter an operator name.", true);
        return;
      }
      const isAdminFlag = adminPromoteFlag ? adminPromoteFlag.checked : true;
      try {
        const res = await fetch("/api/v1/admin/users", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({ operator: operator, is_admin: isAdminFlag }),
        });
        const data = await res.json().catch(function () { return {}; });
        if (!res.ok) {
          showToast(data.detail || "Save failed.", true);
          return;
        }
        showToast(
          isAdminFlag ? "Granted admin to " + operator : "Updated " + operator,
          false
        );
        if (adminPromoteName) adminPromoteName.value = "";
        loadAdminUsers();
      } catch (err) {
        showToast("Network error: " + err, true);
      }
    });
  }

  if (adminPasswordForm) {
    adminPasswordForm.addEventListener("submit", async function (ev) {
      ev.preventDefault();
      const me = await ensureAdminLoggedIn();
      if (!me || !me.admin) return;
      const current = adminCurrentPw ? adminCurrentPw.value : "";
      const newPw = adminNewPw ? adminNewPw.value : "";
      if (!newPw || newPw.length < 4) {
        showToast("New password must be at least 4 characters.", true);
        return;
      }
      try {
        const res = await fetch("/api/v1/admin/set-password", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({
            current_password: current,
            new_password: newPw,
          }),
        });
        const data = await res.json().catch(function () { return {}; });
        if (!res.ok) {
          showToast(data.detail || "Password update failed.", true);
          return;
        }
        if (adminCurrentPw) adminCurrentPw.value = "";
        if (adminNewPw) adminNewPw.value = "";
        showToast("Password updated.", false);
        await refreshAdminMe();
      } catch (err) {
        showToast("Network error: " + err, true);
      }
    });
  }

  // ---- Admin mode -----------------------------------------------------------
  function isAdmin() {
    return !!(adminMeCache && adminMeCache.admin);
  }
  function syncAdminUi() {
    document.body.classList.toggle("admin-mode", isAdmin());
    const btn = document.getElementById("toggle-admin");
    if (btn) {
      btn.setAttribute("aria-pressed", isAdmin() ? "true" : "false");
      btn.title = isAdmin() ? "Sign out of admin mode" : "Sign in as admin";
      const label = btn.querySelector(".admin-label");
      const who = (adminMeCache && adminMeCache.operator) || "";
      if (label) {
        label.textContent = isAdmin()
          ? (who ? "Admin: " + who : "Admin: ON")
          : "Admin";
      }
    }
    if (selectedMachine) renderDetailPanel(selectedMachine);
  }

  const toggleAdminBtn = document.getElementById("toggle-admin");

  if (toggleAdminBtn) {
    toggleAdminBtn.addEventListener("click", async function () {
      if (isAdmin()) {
        try {
          await fetch("/api/v1/admin/logout", {
            method: "POST", credentials: "same-origin",
          });
        } catch (_) {}
        await refreshAdminMe();
        syncAdminUi();
        showToast("Signed out of admin mode.", false);
        return;
      }
      // 2.16.0: per-user admin accounts. Open the new login modal; it
      // handles bootstrap (no admins yet), normal login, and first-time
      // password set in one place.
      const me = await ensureAdminLoggedIn();
      if (me && me.admin) {
        syncAdminUi();
      }
    });
  }

  // ---- Share modal (how to open this dashboard from other PCs on the LAN) --
  const shareModal        = document.getElementById("share-modal");
  const toggleShareBtn    = document.getElementById("toggle-share");
  const shareIpsEl        = document.getElementById("share-ips");
  const shareIpSelect     = document.getElementById("share-ip-select");
  const shareDownloadEl   = document.getElementById("share-download-shortcut");
  const shareCopyLinkBtn  = document.getElementById("share-copy-link");
  const shareLinkPreview  = document.getElementById("share-link-preview");

  function shortcutUrlFor(ip) {
    if (!ip) return "/api/v1/server/shortcut";
    return "/api/v1/server/shortcut?ip=" + encodeURIComponent(ip);
  }

  function updateShareSelection(ip, port, scheme) {
    const target = ip || (location.hostname || "this-pc");
    const usePort = port || 8080;
    const useScheme = scheme || "http";
    const url = useScheme + "://" + target + ":" + usePort + "/";
    if (shareDownloadEl) shareDownloadEl.href = shortcutUrlFor(ip);
    if (shareLinkPreview) shareLinkPreview.textContent = "Shortcut opens: " + url;
    if (shareCopyLinkBtn) shareCopyLinkBtn.dataset.url = url;
  }

  async function openShareModal() {
    if (!shareModal) return;
    shareModal.classList.remove("hidden");
    if (shareIpsEl) shareIpsEl.innerHTML = "<li class='muted small'>Detecting\u2026</li>";
    if (shareIpSelect) shareIpSelect.innerHTML = "<option>Detecting\u2026</option>";
    try {
      const res = await fetch("/api/v1/server/info");
      if (!res.ok) throw new Error("HTTP " + res.status);
      const info = await res.json();
      const port = info.port || 8080;
      const scheme = info.scheme || (info.https_enabled ? "https" : "http");
      const ips = (info.lan_ips || []).slice();
      if (info.hostname && !ips.includes(info.hostname)) {
        ips.push(info.hostname);
      }

      // Port label + firewall command line for the One-time step.
      const portLabel = document.getElementById("share-port-label");
      if (portLabel) portLabel.textContent = String(port);
      const fwCmd = document.getElementById("share-firewall-cmd");
      if (fwCmd) {
        fwCmd.textContent =
          'New-NetFirewallRule -DisplayName "Remote Desktop Dashboard" ' +
          '-Direction Inbound -Protocol TCP -LocalPort ' + port +
          ' -Action Allow -Profile Any';
      }
      // Show/hide the HTTPS cert-install card depending on server mode.
      const httpsCard = document.getElementById("share-https-card");
      const stepUrls = document.getElementById("share-step-urls");
      const httpsStep = document.querySelector("#share-https-card .share-step-num");
      // Step numbering: 1 shortcut, 2 firewall, 3 HTTPS (optional), 4 URLs
      if (httpsCard) {
        if (info.https_enabled) {
          httpsCard.classList.remove("hidden");
          if (httpsStep) httpsStep.textContent = "3";
          if (stepUrls) stepUrls.textContent = "4";
        } else {
          httpsCard.classList.add("hidden");
          if (stepUrls) stepUrls.textContent = "3";
        }
      }

      if (shareIpSelect) {
        shareIpSelect.innerHTML = ips
          .map(function (ip) { return "<option value=\"" + escapeHtml(ip) + "\">" + escapeHtml(ip) + "</option>"; })
          .join("") || "<option value=\"\">(none detected)</option>";
        shareIpSelect.value = ips[0] || "";
        updateShareSelection(shareIpSelect.value, port, scheme);
        shareIpSelect.onchange = function () { updateShareSelection(shareIpSelect.value, port, scheme); };
      }
      if (shareIpsEl) {
        const items = ips.map(function (ip) {
          const url = scheme + "://" + ip + ":" + port + "/";
          return "<li><code>" + escapeHtml(url) + "</code>" +
            " <button type=\"button\" class=\"btn btn-ghost btn-xs share-ip-copy\" data-url=\"" + escapeHtml(url) + "\">Copy</button></li>";
        });
        shareIpsEl.innerHTML = items.length
          ? items.join("")
          : "<li class='muted small'>No LAN IPs detected on this server.</li>";
      }
    } catch (_) {
      if (shareIpsEl) shareIpsEl.innerHTML = "<li class='muted small'>Could not detect LAN IPs.</li>";
    }
  }
  function closeShareModal() {
    if (shareModal) shareModal.classList.add("hidden");
  }
  if (toggleShareBtn) toggleShareBtn.addEventListener("click", openShareModal);
  document.addEventListener("click", function (ev) {
    if (ev.target.matches("[data-close-share]")) closeShareModal();
    const copyBtn = ev.target.closest(".share-ip-copy");
    if (copyBtn) {
      const u = copyBtn.dataset.url;
      if (u) navigator.clipboard.writeText(u).then(function () { showToast("Copied " + u, false); });
    }
  });
  if (shareCopyLinkBtn) {
    shareCopyLinkBtn.addEventListener("click", function () {
      const u = shareCopyLinkBtn.dataset.url || "";
      if (!u) return;
      navigator.clipboard.writeText(u).then(function () { showToast("Copied " + u, false); });
    });
  }

  async function pushInstallAgent(name) {
    const me = await ensureAdminLoggedIn();
    if (!me || !me.admin) return;
    showToast("Installing agent on " + name + "… (uses your monitor service account)", false);
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/agent/install",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({}),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || data.error || "Install failed.", true);
        return;
      }
      const steps = (data.steps || [])
        .map(function (s) { return (s.ok ? "OK " : "FAIL ") + s.step; })
        .join(" -> ");
      if (data.ok) {
        showToast("Agent installed on " + name + ". " + steps, false);
      } else {
        showToast(
          (data.error || "Push install failed.") + "\n" + steps,
          true
        );
      }
      setTimeout(loadBenchAgents, 8000);
    } catch (err) {
      showToast("Network error pushing install: " + err, true);
    }
  }

  async function pushUninstallAgent(name) {
    const me = await ensureAdminLoggedIn();
    if (!me || !me.admin) return;
    if (!window.confirm("Remove the bench agent from " + name + "?")) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/agent/uninstall",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({}),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || data.error || "Uninstall failed.", true);
        return;
      }
      showToast(
        data.ok ? "Agent removed from " + name : (data.error || "Uninstall partial."),
        !data.ok
      );
      setTimeout(loadBenchAgents, 1500);
    } catch (err) {
      showToast("Network error uninstalling: " + err, true);
    }
  }

  async function diagnoseAgent(name) {
    const me = await ensureAdminLoggedIn();
    if (!me || !me.admin) return;
    showToast("Diagnosing " + name + "…", false);
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/agent/diagnostics",
        { credentials: "same-origin" }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Diagnostics failed.", true);
        return;
      }
      showDiagModal(data);
    } catch (err) {
      showToast("Network error during diagnostics: " + err, true);
    }
  }

  function showDiagModal(d) {
    let modal = document.getElementById("diag-modal");
    if (!modal) {
      const html =
        '<div id="diag-modal" class="modal hidden" role="dialog" aria-modal="true">' +
          '<div class="modal-backdrop" data-action="close-diag"></div>' +
          '<div class="modal-box diag-box">' +
            '<div class="diag-head">' +
              '<h2 id="diag-title">Agent diagnostics</h2>' +
              '<span class="diag-time" id="diag-time"></span>' +
            "</div>" +
            '<div id="diag-summary" class="diag-summary"></div>' +
            '<div id="diag-body"></div>' +
            '<div class="form-actions diag-actions">' +
              '<button type="button" class="btn btn-secondary" id="diag-copy-btn">Copy report</button>' +
              '<button type="button" class="btn btn-secondary" id="diag-rerun-btn">Run again</button>' +
              '<button type="button" class="btn btn-ghost" data-action="close-diag">Close</button>' +
            "</div>" +
          "</div>" +
        "</div>";
      document.body.insertAdjacentHTML("beforeend", html);
      modal = document.getElementById("diag-modal");
      modal.addEventListener("click", function (ev) {
        if (ev.target.dataset.action === "close-diag") {
          modal.classList.add("hidden");
        }
      });
    }

    const title = document.getElementById("diag-title");
    title.textContent = "Agent diagnostics — " + d.machine_name;
    const timeEl = document.getElementById("diag-time");
    if (timeEl) {
      const now = new Date();
      timeEl.textContent =
        "Captured " +
        now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    }

    const dv = d.dashboard_view || {};
    const cfg = d.config || {};

    // ----- Summary banner with a single colour-coded line per check.
    // Showing all checks (even passing ones) makes it obvious WHAT is
    // working; the old modal silently omitted "good" rows so it looked
    // like nothing had been measured. The summary is a quick
    // traffic-light scan; the table below has the details.
    function statusPill(state, label) {
      return (
        '<span class="diag-pill diag-pill-' + state + '">' +
          escapeHtml(label) +
        "</span>"
      );
    }
    const summaryBits = [];
    if (dv.online) {
      summaryBits.push(
        statusPill("ok", "Agent ONLINE — heartbeat " + (dv.seconds_ago ?? "?") +
          "s ago (v" + (dv.bench_agent_version || "?") + ")")
      );
    } else if (dv.last_seen) {
      summaryBits.push(
        statusPill(
          "warn",
          "Agent STALE — last heartbeat " + (dv.seconds_ago ?? "?") + "s ago"
        )
      );
    } else {
      summaryBits.push(statusPill("error", "Agent NEVER heard from"));
    }
    summaryBits.push(statusPill(d.smb_ok ? "ok" : "error",
      d.smb_ok ? "SMB OK" : "SMB FAIL"));
    summaryBits.push(statusPill(d.config_present ? "ok" : "error",
      d.config_present ? "config.json OK" : "config.json missing"));
    summaryBits.push(statusPill(d.log_present ? "ok" : "warn",
      d.log_present ? "bench-agent.log OK" : "bench-agent.log missing"));
    if (d.task_state) {
      summaryBits.push(statusPill(
        d.task_state.toLowerCase() === "running" ||
        d.task_state.toLowerCase() === "ready"
          ? "ok"
          : "warn",
        "Task: " + d.task_state
      ));
    }
    document.getElementById("diag-summary").innerHTML =
      summaryBits.join(" ") +
      '<div class="diag-verdict"><strong>Verdict:</strong> ' +
      escapeHtml(d.verdict || "(no verdict)") +
      "</div>";

    // ----- Full row-by-row breakdown. Always show every row; empty
    // values render as a muted em-dash so the user can tell the field
    // was checked and just had nothing to report (previously the empty
    // rows were hidden, which made the modal look like only the
    // verdict was filled in).
    function row(k, v, hint) {
      const value = (v === null || v === undefined || v === "") ? "—" : String(v);
      return (
        '<tr><th>' + escapeHtml(k) + '</th><td>' +
          (value === "—" ? '<span class="diag-empty">—</span>' : escapeHtml(value)) +
          (hint ? '<div class="diag-hint">' + escapeHtml(hint) + '</div>' : '') +
        '</td></tr>'
      );
    }

    let html = '<table class="diag-table">';
    html += row("Verdict", d.verdict);
    html += row("Dashboard sees agent",
      dv.online
        ? "ONLINE (heartbeat " + (dv.seconds_ago ?? "?") + "s ago, v" +
          (dv.bench_agent_version || "?") + ")"
        : dv.last_seen
          ? "STALE (last heartbeat " + (dv.seconds_ago ?? "?") + "s ago)"
          : "NEVER heard from",
      dv.online ? null
        : "If the agent installed cleanly, give it 10s; the dashboard polls every heartbeat."
    );
    html += row("SMB to bench", d.smb_ok ? "OK" : "FAIL",
      d.smb_ok ? null : (d.smb_error || "Can't reach \\\\host\\IPC$ as the monitor account.")
    );
    html += row("config.json present", d.config_present ? "YES" : "NO",
      d.config_present ? null : d.config_error
    );
    html += row("config dashboard_url", cfg.dashboard_url);
    html += row(
      "config machine_name",
      cfg.machine_name
        ? cfg.machine_name + (cfg.machine_name === d.machine_name ? "  ✓" : "  ✗ MISMATCH")
        : null,
      cfg.machine_name && cfg.machine_name !== d.machine_name
        ? "Re-run Push install to fix the recorded name."
        : null
    );
    html += row("bench-agent.log present", d.log_present ? "YES" : "NO",
      d.log_present ? null : d.log_error
    );
    html += row("Scheduled task state",
      d.task_state || (d.task_error ? "ERROR: " + d.task_error : null)
    );
    html += row("Task last run",    d.task_last_run);
    html += row("Task last result", d.task_last_result);
    html += row("Task next run",    d.task_next_run);
    html += "</table>";

    if (d.log_tail && d.log_tail.length) {
      html +=
        '<h3 class="diag-subhead">bench-agent.log (last ' + d.log_tail.length + " lines)</h3>" +
        '<pre class="diag-log">' + escapeHtml(d.log_tail.join("\n")) + "</pre>";
    } else {
      html +=
        '<h3 class="diag-subhead">bench-agent.log</h3>' +
        '<p class="muted small">No log lines fetched. ' +
          'Either the file isn\'t on the bench yet, or the monitor account couldn\'t read it.</p>';
    }

    document.getElementById("diag-body").innerHTML = html;

    // Wire up Copy / Run again — bound after each render so we can
    // reference the freshly-shown report.
    const copyBtn = document.getElementById("diag-copy-btn");
    if (copyBtn) {
      copyBtn.onclick = function () {
        const lines = [];
        lines.push("Remote Desktop Dashboard — agent diagnostics");
        lines.push("Machine: " + d.machine_name);
        lines.push("Host: " + (d.host || "?"));
        lines.push("Captured: " + new Date().toISOString());
        lines.push("");
        lines.push("Verdict: " + (d.verdict || "(none)"));
        lines.push("Agent online (dashboard view): " + (dv.online ? "yes" : "no"));
        lines.push("Heartbeat age (s): " + (dv.seconds_ago ?? "?"));
        lines.push("Agent version: " + (dv.bench_agent_version || "?"));
        lines.push("SMB OK: " + (d.smb_ok ? "yes" : "no"));
        if (d.smb_error) lines.push("SMB error: " + d.smb_error);
        lines.push("config.json present: " + (d.config_present ? "yes" : "no"));
        if (d.config_error) lines.push("config error: " + d.config_error);
        if (cfg.dashboard_url) lines.push("config dashboard_url: " + cfg.dashboard_url);
        if (cfg.machine_name)  lines.push("config machine_name: "  + cfg.machine_name);
        lines.push("bench-agent.log present: " + (d.log_present ? "yes" : "no"));
        if (d.log_error) lines.push("log error: " + d.log_error);
        lines.push("Task state: "       + (d.task_state || "?"));
        lines.push("Task last run: "    + (d.task_last_run || "?"));
        lines.push("Task last result: " + (d.task_last_result || "?"));
        lines.push("Task next run: "    + (d.task_next_run || "?"));
        if (d.log_tail && d.log_tail.length) {
          lines.push("");
          lines.push("--- bench-agent.log tail ---");
          for (const ln of d.log_tail) lines.push(ln);
        }
        const text = lines.join("\n");
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(function () {
            showToast("Report copied to clipboard.", false);
          });
        } else {
          showToast("Clipboard API not available.", true);
        }
      };
    }
    const rerunBtn = document.getElementById("diag-rerun-btn");
    if (rerunBtn) {
      rerunBtn.onclick = function () { diagnoseAgent(d.machine_name); };
    }

    modal.classList.remove("hidden");
  }

  if (benchAgentListEl) {
    benchAgentListEl.addEventListener("click", function (ev) {
      const btn = ev.target.closest("button[data-action]");
      if (!btn) return;
      const action = btn.dataset.action;
      const name = btn.dataset.name;
      if (!name) return;
      if (action === "push-install") pushInstallAgent(name);
      else if (action === "push-uninstall") pushUninstallAgent(name);
      else if (action === "diagnose") diagnoseAgent(name);
    });
  }

  if (benchRefreshBtn) {
    benchRefreshBtn.addEventListener("click", loadBenchAgents);
  }

  function loadMonitorSettings() {
    fetch("/api/v1/settings/monitor")
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        if (setDomain) setDomain.value = data.domain || "";
        if (setUsername) setUsername.value = data.username || "";
        if (setPassword) setPassword.value = "";
        if (settingsStatus) {
          settingsStatus.textContent = data.configured
            ? "Monitoring account is configured."
            : "Save the service account below to enable session details.";
        }
        if (data.monitor_configured !== undefined) {
          serverMeta.monitor_configured = data.configured;
          updateServerBanner(serverMeta);
        }
      })
      .catch(function () {});
  }

  if (settingsForm) {
    settingsForm.addEventListener("submit", async function (ev) {
      ev.preventDefault();
      const me = await ensureAdminLoggedIn();
      if (!me || !me.admin) return;
      const body = {
        domain: setDomain ? setDomain.value.trim() : "",
        username: setUsername ? setUsername.value.trim() : "",
        password: setPassword && setPassword.value ? setPassword.value : null,
      };
      try {
        const res = await fetch("/api/v1/settings/monitor", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify(body),
        });
        const data = await res.json().catch(function () {
          return {};
        });
        if (!res.ok) {
          showToast(data.detail || "Save failed", true);
          return;
        }
        serverMeta.monitor_configured = true;
        updateServerBanner(serverMeta);
        if (setPassword) setPassword.value = "";
        if (settingsStatus) settingsStatus.textContent = "Saved (encrypted on server).";
        showToast("Server credentials saved", false);
        loadDashboard();
      } catch (e) {
        showToast("Save failed", true);
      }
    });
  }

  if (setTestBtn) {
    setTestBtn.addEventListener("click", async function () {
      const host = setTestHost ? setTestHost.value.trim() : "";
      if (!host) {
        showToast("Enter a bench IP or hostname to test", true);
        return;
      }
      setTestBtn.disabled = true;
      if (settingsStatus) settingsStatus.textContent = "Testing (up to 60s)…";
      const ctrl = new AbortController();
      const timer = setTimeout(function () {
        ctrl.abort();
      }, 70000);
      const me = await ensureAdminLoggedIn();
      if (!me || !me.admin) {
        setTestBtn.disabled = false;
        return;
      }
      try {
        const res = await fetch("/api/v1/settings/monitor/test", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          signal: ctrl.signal,
          body: JSON.stringify({ host: host }),
        });
        clearTimeout(timer);
        const data = await res.json();
        if (!res.ok) {
          showToast(data.detail || "Test failed", true);
          return;
        }
        if (settingsStatus) settingsStatus.textContent = data.message || "";
        showToast(data.ok ? "Test OK" : data.message || "Test failed", !data.ok);
      } catch (e) {
        clearTimeout(timer);
        if (e.name === "AbortError") {
          showToast("Test timed out — server may still be busy; wait and retry", true);
        } else {
          showToast("Test failed: " + e.message, true);
        }
      } finally {
        setTestBtn.disabled = false;
      }
    });
  }

  function resetMachineForm() {
    editMachineId.value = "";
    mfName.value = "";
    mfName.disabled = false;
    mfHostname.value = "";
    mfIp.value = "";
    if (mfDescription) mfDescription.value = "";
    if (mfBoard) mfBoard.value = "";
    if (mfAccess) mfAccess.value = "";
  }

  function fillMachineForm(m) {
    editMachineId.value = String(m.id);
    mfName.value = m.name;
    mfName.disabled = true;
    mfHostname.value = m.hostname || "";
    mfIp.value = m.ip_address || "";
    if (mfDescription) mfDescription.value = m.description || "";
    if (mfBoard) mfBoard.value = m.board || "";
    if (mfAccess) mfAccess.value = m.access_note || "";
    mfHostname.focus();
  }

  if (mfCancel) mfCancel.addEventListener("click", resetMachineForm);

  async function adminHeaders() {
    const me = await ensureAdminLoggedIn();
    if (!me || !me.admin) {
      throw new Error("Admin sign-in required");
    }
    return { "Content-Type": "application/json" };
  }

  if (machineForm) machineForm.addEventListener("submit", async function (ev) {
    ev.preventDefault();
    const payload = {
      name: mfName.value.trim().toUpperCase(),
      hostname: mfHostname.value.trim(),
      ip_address: mfIp.value.trim(),
      description: mfDescription ? mfDescription.value.trim() : null,
      board: mfBoard ? mfBoard.value.trim() : null,
      access_note: mfAccess ? mfAccess.value.trim() : null,
    };
    const id = editMachineId.value;
    try {
      const headers = await adminHeaders();
      let res;
      if (id) {
        res = await fetch("/api/v1/machines/" + id, {
          method: "PATCH",
          headers,
          credentials: "same-origin",
          body: JSON.stringify({
            hostname: payload.hostname,
            ip_address: payload.ip_address,
            description: payload.description,
            board: payload.board,
            access_note: payload.access_note,
          }),
        });
      } else {
        res = await fetch("/api/v1/machines", {
          method: "POST",
          headers,
          credentials: "same-origin",
          body: JSON.stringify(payload),
        });
      }
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok) {
        showToast(data.detail || "Save failed", true);
        return;
      }
      showToast(id ? "Updated " + payload.name : "Created " + payload.name, false);
      resetMachineForm();
      loadDashboard();
    } catch (e) {
      showToast("Save failed", true);
    }
  });

  async function deleteMachineByName(name) {
    if (!confirm("Delete machine " + name + " from the dashboard?")) return;
    try {
      const headers = await adminHeaders();
      const res = await fetch(
        "/api/v1/machines/by-name/" + encodeURIComponent(name),
        { method: "DELETE", headers, credentials: "same-origin" }
      );
      if (!res.ok) {
        const data = await res.json().catch(function () {
          return {};
        });
        showToast(data.detail || "Delete failed", true);
        return;
      }
      showToast("Deleted " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Delete failed", true);
    }
  }

  function handleMachineAction(ev) {
    const btn = ev.target.closest("button[data-action]");
    if (!btn) return;
    const name = btn.getAttribute("data-name");
    const action = btn.getAttribute("data-action");
    if (btn.disabled || btn.getAttribute("aria-disabled") === "true") {
      const tip = btn.getAttribute("title");
      if (tip) showToast(tip, true);
      return;
    }
    if (action === "connect") connectMachine(name);
    if (action === "reserve") reserveMachine(name);
    if (action === "release") releaseMachine(name);
    if (action === "admin-release") adminReleaseMachine(name);
    if (action === "kick-others") kickOthersMachine(name);
    if (action === "emergency-restore") emergencyRestoreRdp(name);
    if (action === "delete") deleteMachineByName(name);
    if (action === "edit") {
      const m = machines.find(function (x) { return x.name === name; });
      if (m) {
        fillMachineForm(m);
        openDrawer(manageDrawer);
      }
    }
  }
  if (statusRowsEl)    statusRowsEl.addEventListener("click", handleMachineAction);
  if (detailPanelEl)   detailPanelEl.addEventListener("click", handleMachineAction);
  if (machineAdminList) machineAdminList.addEventListener("click", handleMachineAction);

  window.addEventListener("beforeunload", stopAllHeartbeats);

  // 2.14+ — keep a single ping-timer reference outside the closure so
  // each reconnect REPLACES the previous one. Previously every retry
  // appended a fresh ``setInterval``, so after a long uptime the
  // browser was sending pings for every dead socket it had ever
  // opened — wasteful and a memory leak.
  let _wsPingTimer = null;
  function connect() {
    if (_wsPingTimer) {
      clearInterval(_wsPingTimer);
      _wsPingTimer = null;
    }
    const socket = new WebSocket(wsUrl());
    socket.onopen = function () {
      setWsStatus("ok", "Live");
    };
    socket.onmessage = function (event) {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "machines_update" && Array.isArray(data.machines)) {
          render(data.machines);
          setWsStatus("ok", "Live");
        }
      } catch (e) {
        /* ignore malformed websocket payloads */
      }
    };
    socket.onclose = function () {
      if (_wsPingTimer) {
        clearInterval(_wsPingTimer);
        _wsPingTimer = null;
      }
      setWsStatus("warn", "Reconnecting…");
      setTimeout(connect, 3000);
    };
    socket.onerror = function () {
      setWsStatus("warn", "Reconnecting…");
    };
    _wsPingTimer = setInterval(function () {
      if (socket.readyState === WebSocket.OPEN) {
        try { socket.send("ping"); } catch (_) {}
      }
    }, 25000);
  }

  function refreshIntervalMs() {
    const op = getOperator();
    const mine = machines.some(function (m) {
      return m.is_locked && m.locked_by === op;
    });
    return mine ? 8000 : 20000;
  }

  let refreshTimer = null;
  function scheduleRefresh() {
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = setInterval(function () {
      loadDashboard();
      scheduleRefresh();
    }, refreshIntervalMs());
  }

  function loadHealth() {
    const verEl = document.getElementById("app-version");
    fetch("/health")
      .then(function (r) {
        return r.json();
      })
      .then(function (h) {
        if (verEl && h.version) verEl.textContent = "v" + h.version;
        if (h.monitor_configured !== undefined) {
          serverMeta.monitor_configured = h.monitor_configured;
          serverMeta.monitor_hint = h.monitor_hint;
          serverMeta.admin_pin_required = h.admin_pin_required;
        }
        if (h.users_can_connect !== undefined) {
          serverMeta.users_can_connect = h.users_can_connect;
        }
        if (h.users_can_manage_machines !== undefined) {
          serverMeta.users_can_manage_machines = h.users_can_manage_machines;
        }
        updateServerBanner(serverMeta);
        applyPermissionsUi();
      })
      .catch(function () {});
  }

  if (statusRowsEl) {
    statusRowsEl.innerHTML = '<tr class="empty"><td colspan="6" class="muted">Loading machines\u2026</td></tr>';
  }
  setWsStatus("warn", "Connecting\u2026");
  syncAdminUi();
  loadHealth();
  loadOperatorList();
  loadDashboard().finally(function () {
    setTimeout(connect, 1500);
    scheduleRefresh();
  });
})();
