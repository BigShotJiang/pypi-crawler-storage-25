"""SQLAlchemy engine and session factory."""

from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from remote_desktop_dashboard.paths import resolve_database_url

connect_args: dict = {"check_same_thread": False, "timeout": 30}

# pool_pre_ping handles the "connection dropped while idle" failure that
# bites long-running uvicorn workers under sporadic load. Safe with all
# drivers, near-zero overhead for SQLite (file handle health check).
engine = create_engine(
    resolve_database_url(),
    connect_args=connect_args,
    pool_pre_ping=True,
)

from sqlalchemy import event  # noqa: E402


@event.listens_for(engine, "connect")
def _sqlite_pragma(dbapi_conn, _connection_record) -> None:
    """Configure SQLite for many concurrent readers + occasional writers.

    - ``WAL`` journal_mode lets readers proceed without blocking writers,
      which is the whole game when dozens of dashboards are polling and
      bench agents are heartbeating at the same time.
    - ``synchronous=NORMAL`` is the recommended pairing with WAL — full
      crash safety for committed transactions, ~5x faster than FULL.
    - ``busy_timeout`` makes any locked SQLite call wait up to 30s
      instead of immediately raising ``OperationalError: locked``.
    - ``temp_store=MEMORY`` keeps sort/temp work off disk.
    - ``mmap_size`` lets SQLite memory-map the DB for read-mostly
      access, dramatically lowering syscall overhead under load.
    - ``foreign_keys=ON`` because we declare FK constraints in models.
    """
    cursor = dbapi_conn.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA synchronous=NORMAL")
    cursor.execute("PRAGMA busy_timeout=30000")
    cursor.execute("PRAGMA temp_store=MEMORY")
    cursor.execute("PRAGMA mmap_size=268435456")
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()


SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    from remote_desktop_dashboard import models  # noqa: F401
    from remote_desktop_dashboard.services.bootstrap import upgrade_database_schema

    Base.metadata.create_all(bind=engine)
    upgrade_database_schema(engine)
