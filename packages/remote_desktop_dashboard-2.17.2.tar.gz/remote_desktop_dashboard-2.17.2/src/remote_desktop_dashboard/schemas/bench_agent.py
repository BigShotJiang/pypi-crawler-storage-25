"""Pydantic schemas for the bench-side agent."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class BenchAccessResponse(BaseModel):
    """Returned to the bench agent on every poll."""

    machine_name: str
    locked: bool
    locked_by: str | None = None
    allow_users: list[str] = Field(default_factory=list)
    allow_ips: list[str] = Field(default_factory=list)
    firewall_lock: bool = True
    kick_other_sessions: bool = True
    poll_seconds: int = 5
    server_version: str = ""
    # When true, the agent should remove its custom firewall lock rule and
    # re-enable the built-in Windows "Remote Desktop" rules, as a one-shot
    # break-glass triggered by an admin. The server sends this exactly once
    # (next poll resets it). Field defaults False for old agents.
    restore_native_rdp: bool = False


class BenchSession(BaseModel):
    """One row of qwinsta output, reported by the agent (>=2.2.0)."""

    kind: str | None = None  # "rdp" or "console"
    user: str | None = None
    state: str | None = None
    id: int | None = None


class BenchHeartbeat(BaseModel):
    """Sent by the bench agent every poll."""

    agent_version: str
    applied_users: list[str] = Field(default_factory=list)
    applied_ips: list[str] = Field(default_factory=list)
    firewall_mode: str | None = None
    current_rdp_users: list[str] = Field(default_factory=list)
    # New in 2.12.0 / agent 2.2.0: console session users and full per-
    # session breakdown so the dashboard can show externally-initiated
    # RDPs (someone bypassing the dashboard) and console activity.
    local_users: list[str] = Field(default_factory=list)
    sessions: list[BenchSession] = Field(default_factory=list)
    error: str | None = None
    os: str | None = None
    hostname: str | None = None


class BenchAgentStatus(BaseModel):
    """Used by the UI to show one machine's agent state."""

    machine_name: str
    installed: bool
    version: str | None = None
    last_seen: datetime | None = None
    last_seen_seconds_ago: float | None = None
    online: bool
    applied_users: list[str] = Field(default_factory=list)
    error: str | None = None
