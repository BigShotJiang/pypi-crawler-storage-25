"""REST API routes."""

import asyncio
import hmac
import json
import logging
import sys

from remote_desktop_dashboard import __version__
import threading

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, Response, status
from fastapi.responses import Response
from sqlalchemy.orm import Session

from remote_desktop_dashboard.api.deps import verify_agent_key, verify_bench_agent_token
from remote_desktop_dashboard.crud.lock import (
    LockError,
    acquire_lock,
    admin_force_release,
    heartbeat_lock,
    is_locked_by_other,
    refresh_expired_locks,
    release_lock,
)
from remote_desktop_dashboard.crud.machine import (
    apply_status_report,
    create_machine,
    delete_machine,
    get_machine,
    get_machine_by_name,
    list_machines,
    refresh_online_flags,
    update_machine,
)
from remote_desktop_dashboard.database import get_db
from remote_desktop_dashboard.agent.monitor import MonitorSnapshot
from remote_desktop_dashboard.schemas.machine import (
    AdminReleaseRequest,
    ConnectRequest,
    ConnectResponse,
    LockHeartbeatRequest,
    MachineCreate,
    MachineRead,
    MachineStatusReport,
    MachineUpdate,
)
from remote_desktop_dashboard.schemas.settings import (
    MonitorSettingsRead,
    MonitorSettingsTest,
    MonitorSettingsWrite,
)
from remote_desktop_dashboard.services.connection_manager import manager
from remote_desktop_dashboard.services.dashboard import (
    bench_host,
    machines_payload,
    to_dashboard_machine,
)
from remote_desktop_dashboard.services.rdp_guard import (
    apply_rdp_guard,
    schedule_clear_rdp_guard,
)

logger = logging.getLogger(__name__)


_GUARD_RESULTS: dict[str, dict] = {}

# Machines for which an admin has explicitly requested a one-time kick of any
# unauthorized RDP sessions. Consumed (and cleared) by the next bench-agent
# /access poll so the agent kicks exactly once — kicking is never automatic.
_KICK_PENDING: set[str] = set()
_KICK_LOCK = threading.Lock()


def _run_guard(machine_name: str, host: str, allow_ips: list[str]) -> None:
    """Apply RDP guard in the background and record the result for later inspection."""
    import threading
    import time as _time

    started = _time.monotonic()
    _GUARD_RESULTS[machine_name] = {
        "host": host,
        "allow_ips": allow_ips,
        "applied": None,
        "status": "running",
        "started_at": started,
    }

    def _worker() -> None:
        try:
            ok = apply_rdp_guard(host, allow_ips)
            elapsed = _time.monotonic() - started
            _GUARD_RESULTS[machine_name] = {
                "host": host,
                "allow_ips": allow_ips,
                "applied": bool(ok),
                "status": "ok" if ok else "failed",
                "elapsed_seconds": round(elapsed, 1),
                "error": None
                if ok
                else (
                    "Remote 'netsh advfirewall' on this bench is timing out or "
                    "refusing the monitor account. The dashboard lock is still active "
                    "(prevents others from connecting through this dashboard). "
                    "To silence this warning, set RDD_RDP_GUARD_ENABLED=false in admin.env."
                ),
            }
        except Exception as exc:
            elapsed = _time.monotonic() - started
            logger.warning("RDP guard worker crashed for %s: %s", machine_name, exc)
            _GUARD_RESULTS[machine_name] = {
                "host": host,
                "allow_ips": allow_ips,
                "applied": False,
                "status": "error",
                "elapsed_seconds": round(elapsed, 1),
                "error": str(exc),
            }

    threading.Thread(target=_worker, name=f"rdd-guard-{machine_name}", daemon=True).start()
from remote_desktop_dashboard.services.rdp_launch import (
    build_launch_uris,
    build_rdp_file_content,
    local_launch_url,
)
from remote_desktop_dashboard.config import get_settings, permissions_dict
from remote_desktop_dashboard.services.reachability_cache import get_cached_reachability

router = APIRouter(prefix="/api/v1")


@router.get("/server/shortcut")
def api_server_shortcut(request: Request, ip: str | None = None) -> Response:
    """Return a tiny HTML "launcher" file pointing at this dashboard.

    Users drop this on their desktop and double-click — the file opens in
    their default browser, which redirects them to the dashboard. The
    query parameter ``?ip=<lan-ip>`` selects which LAN URL to use.

    Why HTML and not a Windows ``.url`` Internet Shortcut?
    Chrome and Edge SmartScreen flag ``.url`` downloads as harmful because
    the ``URL=`` field can launch executables via custom URI schemes.
    A plain static HTML file with a ``<meta refresh>`` is never flagged
    and gives identical UX: double-click → browser opens → dashboard.
    """
    import socket

    settings = get_settings()
    target_ip = (ip or "").strip()
    if not target_ip:
        # Fall back to the host the client used to reach us.
        target_ip = request.url.hostname or socket.gethostname()
    port = int(request.url.port or settings.port or 8080)
    scheme = "https" if settings.https_enabled else "http"
    url = f"{scheme}://{target_ip}:{port}/"
    title = "Remote Desktop Dashboard"
    # Inline a small self-contained HTML page. Auto-redirects after 0.4s
    # to give the browser time to render the page first (so a slow
    # network/auth prompt doesn't show a blank window). Also offers a
    # manual link as fallback.
    safe_url = (
        url.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
    body = (
        "<!doctype html>\n"
        "<html lang=\"en\">\n<head>\n"
        "<meta charset=\"utf-8\">\n"
        f"<title>{title}</title>\n"
        f"<meta http-equiv=\"refresh\" content=\"0;url={safe_url}\">\n"
        "<style>\n"
        "  html,body{height:100%;margin:0;font-family:Segoe UI,Arial,sans-serif;"
        "background:#0f172a;color:#e2e8f0}\n"
        "  .wrap{display:flex;flex-direction:column;align-items:center;"
        "justify-content:center;height:100%;text-align:center;padding:24px}\n"
        "  a{color:#5eead4;font-size:1.1rem;text-decoration:none;"
        "background:rgba(94,234,212,.1);padding:12px 22px;border-radius:10px;"
        "border:1px solid rgba(94,234,212,.35);display:inline-block;margin-top:18px}\n"
        "  .muted{color:#94a3b8;font-size:.9rem;margin-top:14px}\n"
        "</style>\n</head>\n<body>\n"
        "<div class=\"wrap\">\n"
        f"  <h1>Opening {title}…</h1>\n"
        f"  <a href=\"{safe_url}\">Click here if it doesn't open automatically</a>\n"
        f"  <p class=\"muted\">Redirecting to <code>{safe_url}</code></p>\n"
        "</div>\n"
        f"<script>setTimeout(function(){{location.replace('{safe_url}');}},400);</script>\n"
        "</body>\n</html>\n"
    )
    filename = "Open Remote Desktop Dashboard.html"
    return Response(
        content=body,
        media_type="text/html; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-store",
        },
    )


@router.get("/server/cert.crt")
def api_server_cert() -> Response:
    """Download the dashboard's self-signed cert for one-time client install.

    Only meaningful when ``https_enabled`` is true. The endpoint always
    returns 404 in HTTP mode so the Share modal can hide the prompt.
    Install the downloaded file on each client PC into "Trusted Root
    Certification Authorities" (Windows ``certmgr.msc`` → Trusted Root →
    Import) and browsers stop showing the "Not secure / your connection
    is not private" warning.
    """
    settings = get_settings()
    if not settings.https_enabled:
        raise HTTPException(status_code=404, detail="HTTPS is not enabled")

    from remote_desktop_dashboard.services import tls as _tls

    try:
        body = _tls.public_cert_bytes(settings.config_directory)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Cert read failed: {exc}") from exc
    return Response(
        content=body,
        media_type="application/x-x509-ca-cert",
        headers={
            "Content-Disposition": 'attachment; filename="remote-desktop-dashboard.crt"',
            "Cache-Control": "no-store",
        },
    )


@router.get("/server/info")
def api_server_info(request: Request) -> dict:
    """Used by the Share modal to tell the user the LAN URLs other PCs can use."""
    import socket

    settings = get_settings()
    port = int(getattr(request.url, "port", None) or settings.port or 8080)
    scheme = "https" if settings.https_enabled else "http"
    lan_ips: list[str] = []
    try:
        hostname = socket.gethostname()
        try:
            ips = socket.getaddrinfo(hostname, None, family=socket.AF_INET)
            for entry in ips:
                ip = entry[4][0]
                if ip and not ip.startswith("127.") and ip not in lan_ips:
                    lan_ips.append(ip)
        except OSError:
            pass
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80))
                ip = s.getsockname()[0]
                if ip and not ip.startswith("127.") and ip not in lan_ips:
                    lan_ips.append(ip)
        except OSError:
            pass
    except Exception:
        pass
    return {
        "hostname": socket.gethostname(),
        "port": port,
        "scheme": scheme,
        "https_enabled": bool(settings.https_enabled),
        "lan_ips": lan_ips,
        "lan_urls": [f"{scheme}://{ip}:{port}/" for ip in lan_ips],
    }


def _machine_or_404(db: Session, machine_name: str):
    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return machine


def _is_loopback(ip: str) -> bool:
    ip = (ip or "").strip().lower()
    return ip in ("127.0.0.1", "::1", "localhost") or ip.startswith("127.")


def _server_lan_ip_for(target: str) -> str:
    """Server's outbound LAN IP toward `target` — when dashboard is on the same PC as the RDP client."""
    import socket

    target = (target or "").strip()
    if not target:
        return ""
    candidates: list[tuple[str, int]] = []
    try:
        ip = socket.gethostbyname(target)
        candidates.append((ip, get_settings().rdp_port))
    except OSError:
        pass
    candidates.append(("8.8.8.8", 80))
    for host, port in candidates:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.connect((host, port))
                ip = s.getsockname()[0]
            finally:
                s.close()
            if ip and not _is_loopback(ip):
                return ip
        except OSError:
            continue
    return ""


def _client_ip(request: Request) -> str:
    """Client IP for RDP firewall allow rules (must match the PC running Windows App)."""
    for header in ("X-Forwarded-For", "X-Real-IP", "CF-Connecting-IP"):
        raw = request.headers.get(header)
        if raw:
            ip = raw.split(",")[0].strip()
            if ip and not _is_loopback(ip):
                return ip
    if request.client and request.client.host:
        host = request.client.host.strip()
        return host
    return ""


def _prepare_machines(
    db: Session, *, check_reachability: bool = False, refresh_locks: bool = True
):
    refresh_online_flags(db)
    if refresh_locks:
        refresh_expired_locks(db, remote_firewall=False)
    machines = list_machines(db)
    settings = get_settings()
    do_check = check_reachability and settings.reachability_check
    if do_check and settings.reachability_check:
        reachability = get_cached_reachability(machines, allow_refresh=True)
    else:
        reachability = get_cached_reachability(machines, allow_refresh=False)
    return machines, reachability


@router.get("/machines", response_model=list[MachineRead])
def api_list_machines(db: Session = Depends(get_db)) -> list[MachineRead]:
    machines, _ = _prepare_machines(db)
    return [MachineRead.model_validate(m) for m in machines]


@router.get("/machines/{machine_id}", response_model=MachineRead)
def api_get_machine(machine_id: int, db: Session = Depends(get_db)) -> MachineRead:
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return MachineRead.model_validate(machine)


@router.post("/machines", response_model=MachineRead, status_code=status.HTTP_201_CREATED)
async def api_create_machine(
    data: MachineCreate,
    request: Request,
    admin_pin: str | None = Query(None),
    x_admin_pin: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> MachineRead:
    _require_manage_machines(admin_pin, x_admin_pin, request)
    existing = get_machine_by_name(db, data.name)
    if existing:
        raise HTTPException(status_code=409, detail="Machine name already exists")
    machine = create_machine(db, data)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.patch("/machines/{machine_id}", response_model=MachineRead)
async def api_update_machine(
    machine_id: int,
    data: MachineUpdate,
    request: Request,
    admin_pin: str | None = Query(None),
    x_admin_pin: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> MachineRead:
    _require_manage_machines(admin_pin, x_admin_pin, request)
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    machine = update_machine(db, machine, data)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.delete("/machines/{machine_id}", status_code=status.HTTP_204_NO_CONTENT)
async def api_delete_machine(
    machine_id: int,
    request: Request,
    admin_pin: str | None = Query(None),
    x_admin_pin: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> None:
    _require_manage_machines(admin_pin, x_admin_pin, request)
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    delete_machine(db, machine)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))


@router.delete("/machines/by-name/{machine_name}", status_code=status.HTTP_204_NO_CONTENT)
async def api_delete_machine_by_name(
    machine_name: str,
    request: Request,
    admin_pin: str | None = Query(None),
    x_admin_pin: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> None:
    _require_manage_machines(admin_pin, x_admin_pin, request)
    machine = _machine_or_404(db, machine_name)
    delete_machine(db, machine)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))


@router.post(
    "/machines/{machine_name}/status",
    response_model=MachineRead,
    dependencies=[Depends(verify_agent_key)],
)
async def api_post_status(
    machine_name: str,
    report: MachineStatusReport,
    db: Session = Depends(get_db),
) -> MachineRead:
    report.machine_name = machine_name.upper()
    try:
        machine = apply_status_report(db, report)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.get("/dashboard/fast")
def api_dashboard_fast(
    operator: str | None = None,
    x_admin_pin: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> dict:
    """Dashboard with cached online/offline (never blocks on TCP refresh)."""
    refresh_online_flags(db)
    refresh_expired_locks(db, remote_firewall=False)
    machines = list_machines(db)
    reach = get_cached_reachability(machines, allow_refresh=False)
    return {
        **_dashboard_meta(admin=_is_admin_request(x_admin_pin)),
        "machines": [
            to_dashboard_machine(m, operator, reach.get(m.name, False)).model_dump(mode="json")
            for m in machines
        ],
    }


def _locked_by_other_detail(machine, action: str = "connect") -> dict:
    """Build the 2.16.0 structured 409 payload returned when an
    operator's connect / reserve hits a machine already locked by
    someone else. The dashboard JS reads ``code`` and ``can_*`` flags
    to render the role-aware "in use" modal (Force takeover for
    everyone, Share session for admins).
    """
    from remote_desktop_dashboard.crud.lock import get_lock_shared
    shared = get_lock_shared(machine)
    return {
        "code": "locked_by_other",
        "action": action,
        "message": (
            f"Machine is in use by {machine.locked_by}. "
            "Force takeover to disconnect them, or ask an admin to "
            "add you as a shared participant."
        ),
        "locked_by": machine.locked_by,
        "lock_rdp_username": machine.lock_rdp_username,
        "shared_with": [s.get("operator", "") for s in shared if s.get("operator")],
        "can_force_takeover": True,
        "can_share_session_if_admin": True,
    }


def _verify_admin_pin(
    pin: str | None,
    header_pin: str | None = None,
    request: Request | None = None,
) -> None:
    """Verify that the caller is an admin.

    2.16.0: the dashboard now supports per-user admin accounts with
    their own passwords (see ``services/admin_auth.py``). Authentication
    is accepted from any of the following, in order:

      1. A valid ``rdd_admin_session`` HttpOnly cookie issued by the
         ``/admin/login`` endpoint (preferred — no plaintext on the
         wire after the initial login).
      2. The legacy global ``RDD_ADMIN_PIN`` via the ``X-Admin-PIN``
         header (back-compat for pre-2.16 clients and as the bootstrap
         path while no admin user exists yet).
      3. The same PIN via the legacy ``?admin_pin=`` query parameter
         (still accepted for old scripts).

    Uses ``hmac.compare_digest`` so a remote attacker can't probe the
    PIN one character at a time via response timing.

    If a ``Request`` is supplied we look for a session cookie on it —
    that is the path you want for any modern endpoint. Old endpoints
    that pre-date this signature still work because the new arg is
    optional.
    """
    from remote_desktop_dashboard.services.admin_auth import (
        SESSION_COOKIE_NAME,
        verify_session,
    )

    # 1) Session cookie (per-user admin).
    if request is not None:
        token = request.cookies.get(SESSION_COOKIE_NAME)
        if token and verify_session(token):
            return

    # 2 + 3) Legacy global PIN. Still required as the bootstrap before
    # any admin user exists.
    required = (get_settings().admin_pin or "").strip()
    if not required:
        return
    supplied = next(
        (v.strip() for v in (pin, header_pin) if v and v.strip()),
        "",
    )
    if not supplied or not hmac.compare_digest(supplied, required):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid admin credentials. Sign in or supply the admin PIN.",
        )


def _require_users_can_connect() -> None:
    if not get_settings().users_can_connect:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Connecting is disabled in admin.env (RDD_USERS_CAN_CONNECT=false).",
        )


def _require_manage_machines(
    admin_pin: str | None = None,
    header_pin: str | None = None,
    request: Request | None = None,
) -> None:
    if get_settings().users_can_manage_machines:
        return
    _verify_admin_pin(admin_pin, header_pin, request)
    if not (get_settings().admin_pin or "").strip():
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Machine management requires admin.env (RDD_USERS_CAN_MANAGE_MACHINES or RDD_ADMIN_PIN).",
        )


def _dashboard_meta(admin: bool = False) -> dict:
    """Per-load metadata returned alongside ``/dashboard`` payloads.

    The on-disk paths (``config_dir``, ``user_env_file``,
    ``admin_env_file``) are sensitive enough that we don't want to leak
    them to every LAN client. They're only included when the caller has
    proven admin (via the ``X-Admin-PIN`` header in the request).
    """
    from remote_desktop_dashboard.services.monitor_credentials import (
        credentials_hint,
        monitor_credentials_source,
        resolve_monitor_credentials,
    )

    settings = get_settings()
    creds = resolve_monitor_credentials()
    out: dict = {
        "monitor_configured": creds is not None,
        "monitor_hint": None if creds else credentials_hint(),
        "monitor_source": monitor_credentials_source(),
        "poller_enabled": settings.poller_enabled,
        "admin_pin_required": settings.admin_pin_required,
        **permissions_dict(),
    }
    required_pin = (settings.admin_pin or "").strip()
    if admin or not required_pin:
        data_dir = settings.config_directory
        out["config_dir"] = str(data_dir)
        out["user_env_file"] = str(data_dir / ".env")
        out["admin_env_file"] = str(data_dir / "admin.env")
    return out


def _is_admin_request(x_admin_pin: str | None) -> bool:
    """Helper for endpoints that want to *enrich* the response for an
    authenticated admin without rejecting non-admins."""
    required = (get_settings().admin_pin or "").strip()
    supplied = (x_admin_pin or "").strip()
    if not required or not supplied:
        return False
    return hmac.compare_digest(supplied, required)


@router.get("/dashboard")
def api_dashboard(
    operator: str | None = None,
    x_admin_pin: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> dict:
    machines, reachability = _prepare_machines(db, check_reachability=False)
    return {
        **_dashboard_meta(admin=_is_admin_request(x_admin_pin)),
        "machines": [
            to_dashboard_machine(m, operator, reachability.get(m.name, False)).model_dump(
                mode="json"
            )
            for m in machines
        ],
    }


@router.post("/machines/{machine_name}/connect", response_model=ConnectResponse)
async def api_connect(
    machine_name: str,
    body: ConnectRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> ConnectResponse:
    _require_users_can_connect()
    machine = _machine_or_404(db, machine_name)
    refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)
    if is_locked_by_other(machine, body.operator):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=_locked_by_other_detail(machine, action="connect"),
        )
    client_ip = _client_ip(request)
    # 2.16.0: a shared participant ISN'T the primary lock owner, so
    # ``acquire_lock`` (which only allows the existing owner or an
    # unlocked machine) would reject them. Detect that case and skip
    # the acquire — the share-session endpoint already authorised them
    # and the bench-agent /access endpoint returns their RDP username
    # in ``allow_users``. We still refresh ``lock_client_ip`` for the
    # primary owner via the explicit heartbeat path.
    from remote_desktop_dashboard.crud.lock import (
        add_shared_operator,
        is_lock_participant,
        operators_match,
    )
    is_shared_participant = (
        machine.locked_by is not None
        and not operators_match(machine.locked_by, body.operator)
        and is_lock_participant(machine, body.operator)
    )
    if is_shared_participant:
        # Update the shared participant's recorded RDP username + IP so
        # the bench agent's allow_users / allow_ips stay accurate when
        # the operator changes browsers / network.
        try:
            add_shared_operator(
                db,
                machine,
                body.operator,
                rdp_username=body.rdp_username,
                client_ip=client_ip or None,
            )
        except LockError:
            pass
    else:
        try:
            acquire_lock(
                db,
                machine,
                body.operator,
                body.rdp_username,
                client_ip=client_ip or None,
                skip_expired_refresh=True,
            )
        except LockError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=str(exc),
            ) from exc

    # Remember this operator's RDP username + domain so the UI can prefill
    # next time they type their operator name.
    from remote_desktop_dashboard.crud.operator import upsert_operator_pref
    from remote_desktop_dashboard.crud.audit import log_event
    _dom, _, _user = (body.rdp_username or "").partition("\\")
    if not _user:
        _user, _dom = body.rdp_username, ""
    upsert_operator_pref(
        db,
        display_name=body.operator,
        rdp_username=_user.strip() or None,
        rdp_domain=_dom.strip() or None,
        use_hostname=body.use_hostname,
    )
    log_event(
        db,
        action="connect",
        machine_name=machine.name,
        operator=body.operator,
        client_ip=client_ip,
        detail=f"RDP user {body.rdp_username}",
    )
    db.commit()

    settings = get_settings()
    guard_host = bench_host(machine, prefer_ip=settings.poll_prefer_ip)
    allow_ips: list[str] = []
    if client_ip and not _is_loopback(client_ip):
        allow_ips.append(client_ip)
    elif settings.rdp_guard_fallback_to_server_ip:
        fallback = _server_lan_ip_for(guard_host)
        if fallback:
            logger.info(
                "RDP guard: client IP is loopback; using dashboard server LAN IP %s as allow.",
                fallback,
            )
            allow_ips.append(fallback)
    if machine.lock_client_ip and machine.lock_client_ip not in allow_ips:
        allow_ips.append(machine.lock_client_ip)
    from remote_desktop_dashboard.services.settings_store import is_rdp_guard_enabled
    from datetime import datetime, timezone
    guard_enabled = is_rdp_guard_enabled()

    # If the bench agent has heartbeated recently, it is enforcing access
    # locally (via Remote Desktop Users group + session kicks). The legacy
    # remote-netsh firewall guard is redundant and we skip it.
    agent_online = False
    if machine.bench_agent_last_seen is not None:
        last = machine.bench_agent_last_seen
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        ago = (datetime.now(timezone.utc) - last).total_seconds()
        agent_online = ago <= max(15, settings.bench_agent_offline_grace_seconds)

    guard_info: dict = {
        "enabled": guard_enabled,
        "host": guard_host,
        "allow_ips": list(allow_ips),
        "applied": None,
        "status": "pending" if guard_enabled and allow_ips else "skipped",
    }
    if agent_online:
        guard_info["status"] = "agent"
        guard_info["reason"] = (
            "Bench agent is enforcing access locally on the bench "
            "(local Windows Firewall rule on TCP 3389 + Remote Desktop Users "
            "group + session kicks). Legacy remote firewall guard skipped."
        )
        logger.info("RDP guard skipped for %s — bench agent online.", machine.name)
    elif guard_enabled and allow_ips:
        _GUARD_RESULTS.pop(machine.name, None)
        _run_guard(machine.name, guard_host, allow_ips)
    elif guard_enabled:
        guard_info["status"] = "no_client_ip"
        guard_info["reason"] = (
            "Dashboard server could not determine a usable client IP "
            f"(client={client_ip or '<empty>'}). Set RDD_RDP_GUARD_EXTRA_IPS "
            "in admin.env to your PC's LAN address, or open the dashboard "
            f"at http://<server-lan-ip>:{settings.port}."
        )
        logger.warning("RDP guard skipped: %s", guard_info["reason"])

    target = machine.hostname if body.use_hostname else machine.ip_address
    domain = None
    username = body.rdp_username
    if username and "\\" in username:
        domain, _, username = username.partition("\\")

    uris = build_launch_uris(target, username=username, domain=domain)
    launch_url = local_launch_url(target, username=username, domain=domain)

    db.refresh(machine)
    reachability = get_cached_reachability([machine], allow_refresh=False)
    row = to_dashboard_machine(
        machine, body.operator, reachability.get(machine.name, False)
    )
    machines, reach_all = _prepare_machines(db, check_reachability=False)
    asyncio.create_task(
        manager.broadcast(
            machines_payload(machines, body.operator, reachability=reach_all)
        )
    )

    client = uris["client"]
    # 2.13+ launch: the dashboard JS hands ``rdp_uri`` to the OS via a
    # hidden iframe, so the bench's login screen opens directly without
    # the .rdp file appearing in the operator's Downloads folder. We
    # keep ``rdp_download_url`` populated as a manual fallback only.
    msg = (
        f"Opening Remote Desktop to {target}. The RDP login screen will "
        "open in a moment — sign in with your Windows credentials."
    )

    if agent_online:
        msg += " Bench agent is enforcing exclusive access on the bench."
    elif guard_enabled and not allow_ips:
        msg += (
            " Direct RDP blocking needs your PC's IP in admin.env "
            "(RDD_RDP_GUARD_EXTRA_IPS) when the dashboard is opened on localhost."
        )
    elif guard_enabled:
        msg += " Direct RDP from other PCs is being blocked on the bench (may take a few seconds)."

    # Always include the operator in the .rdp manual-fallback URL so the
    # lock-ownership check in ``download_session_rdp`` works. Previously
    # the param was omitted when no rdp_username was supplied, which
    # turned the lock check into a no-op.
    from urllib.parse import quote as _q

    rdp_dl = (
        f"/api/v1/machines/{machine.name}/session.rdp"
        f"?operator={_q(body.operator, safe='')}"
    )

    return ConnectResponse(
        machine_name=machine.name,
        locked_by=body.operator,
        launch_uri=uris["primary_uri"],
        fallback_uri=uris["fallback_uri"],
        windows_app_uri=uris["rdp_uri"],
        rdp_uri=uris["rdp_uri"],
        mstsc_command=uris["mstsc_command"],
        powershell_command=uris["powershell_command"],
        local_launch_url=launch_url,
        rdp_download_url=rdp_dl,
        client=client,
        target_host=target,
        message=msg,
        machine=row.model_dump(mode="json"),
        guard=guard_info,
    )


@router.get("/machines/{machine_name}/guard")
def api_get_guard_status(machine_name: str) -> dict:
    """Return the latest RDP guard result for a machine (after Connect)."""
    return _GUARD_RESULTS.get(machine_name, {"status": "unknown"})


@router.get("/machines/{machine_name}/session.rdp")
def download_session_rdp(
    machine_name: str,
    operator: str | None = Query(None),
    use_hostname: bool = Query(True),
    rdp_username: str | None = Query(None),
    admin_pin: str | None = Query(None),
    x_admin_pin: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> Response:
    """Download a manual .rdp file fallback.

    The normal launch flow (2.13+) uses the ``rdp://`` URI scheme so
    nothing is downloaded. This endpoint stays as a manual fallback for
    operators who explicitly want a file (e.g. to drop on a desktop).

    SECURITY: an empty ``operator`` used to skip the lock check entirely,
    so anyone on the LAN could hand-craft this URL to bypass a
    reservation. We now require ``operator`` AND verify the caller
    actually owns the lock (or has the admin PIN).
    """
    machine = _machine_or_404(db, machine_name)
    refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)

    op = (operator or "").strip()
    if not op:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "operator is required so we can verify you hold the lock. "
                "Open the dashboard and click Connect instead of fetching "
                "this URL directly."
            ),
        )
    # Operator must hold the lock OR be an admin.
    if is_locked_by_other(machine, op):
        admin_supplied = (admin_pin or x_admin_pin or "").strip()
        admin_required = (get_settings().admin_pin or "").strip()
        is_admin = (
            bool(admin_required)
            and bool(admin_supplied)
            and hmac.compare_digest(admin_supplied, admin_required)
        )
        if not is_admin:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    f"Machine is reserved by {machine.locked_by}. "
                    "Connect through the dashboard."
                ),
            )

    target = machine.hostname if use_hostname else machine.ip_address
    domain = None
    username = rdp_username or machine.lock_rdp_username
    if username and "\\" in username:
        domain, _, username = username.partition("\\")
    content = build_rdp_file_content(target, username=username, domain=domain)
    filename = f"{machine.name}.rdp"
    return Response(
        content=content,
        # ``application/x-rdp`` is the MIME type Windows ships with the
        # .rdp file association; browsers hand it directly to mstsc on
        # most Windows installs. We use ``attachment`` (not ``inline``)
        # because inline causes Chrome/Edge to block the response inside
        # iframes — which is what the user reported as "blank and
        # blocked" in 2.17.x. Attachment downloads cleanly and the
        # default Windows file association then opens mstsc.
        media_type="application/x-rdp",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/machines/{machine_name}/poll-now")
async def api_poll_now(
    machine_name: str,
    operator: str | None = Query(None),
    db: Session = Depends(get_db),
) -> dict:
    """Poll one machine in the background (does not block the HTTP worker)."""
    machine = _machine_or_404(db, machine_name)
    if not get_settings().poller_enabled:
        raise HTTPException(
            status_code=400,
            detail="Poller is disabled. Start server without --no-poller.",
        )
    if sys.platform != "win32":
        raise HTTPException(status_code=400, detail="Polling requires a Windows server.")

    from remote_desktop_dashboard.services.monitor_credentials import resolve_monitor_credentials
    from remote_desktop_dashboard.services.poller import poll_single_machine

    if resolve_monitor_credentials() is None:
        raise HTTPException(
            status_code=400,
            detail=(
                "Server monitor credentials not set. Open Server settings and save "
                "domain, username, and password."
            ),
        )

    limit = get_settings().poll_timeout_seconds + 10.0
    try:
        ok, err = await asyncio.wait_for(
            asyncio.to_thread(poll_single_machine, machine.name),
            timeout=limit,
        )
    except asyncio.TimeoutError:
        raise HTTPException(
            status_code=504,
            detail=f"Poll timed out after {int(limit)}s — bench may be slow or unreachable.",
        ) from None

    db.refresh(machine)
    machines, reachability = _prepare_machines(db, check_reachability=False)
    row = to_dashboard_machine(
        machine, operator, reachability.get(machine.name, False)
    )
    await manager.broadcast(machines_payload(machines, operator, reachability))
    return {
        "ok": ok,
        "status": "done",
        "error": err,
        "machine": row.model_dump(mode="json"),
    }


@router.post("/machines/{machine_name}/lock/heartbeat", response_model=MachineRead)
async def api_lock_heartbeat(
    machine_name: str,
    body: LockHeartbeatRequest,
    db: Session = Depends(get_db),
) -> MachineRead:
    machine = _machine_or_404(db, machine_name)
    try:
        machine = heartbeat_lock(db, machine, body.operator)
    except LockError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, body.operator, reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/lock/reserve", response_model=MachineRead)
async def api_lock_reserve(
    machine_name: str,
    body: ConnectRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> MachineRead:
    """Reserve a bench without launching an RDP session.

    Same locking semantics as /connect: the operator claims the machine and
    becomes its lock owner. Useful when the operator wants to grab a bench
    now and connect later (e.g. they're walking to it, or scheduling work).
    No RDP launcher payload is returned.
    """
    from remote_desktop_dashboard.crud.audit import log_event
    from remote_desktop_dashboard.crud.operator import upsert_operator_pref

    _require_users_can_connect()
    machine = _machine_or_404(db, machine_name)
    refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)
    if is_locked_by_other(machine, body.operator):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=_locked_by_other_detail(machine, action="reserve"),
        )
    client_ip = _client_ip(request)
    try:
        acquire_lock(
            db,
            machine,
            body.operator,
            body.rdp_username,
            client_ip=client_ip or None,
            skip_expired_refresh=True,
        )
    except LockError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    _dom, _, _user = (body.rdp_username or "").partition("\\")
    if not _user:
        _user, _dom = body.rdp_username, ""
    upsert_operator_pref(
        db,
        display_name=body.operator,
        rdp_username=_user.strip() or None,
        rdp_domain=_dom.strip() or None,
        use_hostname=body.use_hostname,
    )
    log_event(
        db,
        action="reserve",
        machine_name=machine.name,
        operator=body.operator,
        client_ip=client_ip,
        detail="Reserved without launching RDP",
    )
    db.commit()
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, body.operator, reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/lock/release", response_model=MachineRead)
async def api_lock_release(
    machine_name: str,
    body: LockHeartbeatRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> MachineRead:
    from remote_desktop_dashboard.crud.audit import log_event

    machine = _machine_or_404(db, machine_name)
    settings = get_settings()
    if not settings.users_can_release_own_lock:
        _verify_admin_pin(body.admin_pin, None, request)
    allow: list[str] = []
    if machine.lock_client_ip:
        allow.append(machine.lock_client_ip)
    try:
        machine = release_lock(db, machine, body.operator)
    except LockError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    log_event(
        db,
        action="release",
        machine_name=machine.name,
        operator=body.operator,
        client_ip=_client_ip(request),
        detail="Operator released own lock",
    )
    db.commit()
    schedule_clear_rdp_guard(bench_host(machine, prefer_ip=settings.poll_prefer_ip), allow)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/lock/force-takeover", response_model=MachineRead)
async def api_force_takeover(
    machine_name: str,
    body: ConnectRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> MachineRead:
    """Forcefully take over a machine locked by someone else.

    Any operator can do this — there is no admin gate. The previous lock
    owner is recorded in the audit log and their RDP session WILL be
    kicked by the bench agent on its next poll (because the new
    ``locked_by`` becomes ``body.operator`` and the agent enforces
    "only allow_users may RDP").

    Frontend uses this when a Connect attempt returns the 2.16.0
    structured 409 and the operator clicks "Force takeover".
    """
    from remote_desktop_dashboard.crud.audit import log_event
    from remote_desktop_dashboard.crud.operator import upsert_operator_pref

    _require_users_can_connect()
    machine = _machine_or_404(db, machine_name)
    refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)

    prior_owner = machine.locked_by
    client_ip = _client_ip(request)

    try:
        # ``force=True`` skips the ownership predicate so the lock changes
        # hands regardless of who held it. We do NOT call this from the
        # normal Connect path; it's explicitly opt-in from the modal.
        acquire_lock(
            db,
            machine,
            body.operator,
            body.rdp_username,
            force=True,
            client_ip=client_ip or None,
            skip_expired_refresh=True,
        )
    except LockError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    # Keep operator prefs fresh.
    _dom, _, _user = (body.rdp_username or "").partition("\\")
    if not _user:
        _user, _dom = body.rdp_username, ""
    upsert_operator_pref(
        db,
        display_name=body.operator,
        rdp_username=_user.strip() or None,
        rdp_domain=_dom.strip() or None,
        use_hostname=body.use_hostname,
    )
    log_event(
        db,
        action="force_takeover",
        machine_name=machine.name,
        operator=body.operator,
        client_ip=client_ip,
        detail=f"Took over from {prior_owner or '(none)'}",
    )
    db.commit()
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/lock/share-session", response_model=MachineRead)
async def api_share_session(
    machine_name: str,
    body: dict,
    request: Request,
    x_admin_pin: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> MachineRead:
    """Admin: add an operator to a locked machine's shared-participant list.

    Both the primary lock owner AND every shared operator can RDP into
    the machine concurrently — the bench-agent firewall + group-sync
    receives all their usernames in ``allow_users`` and treats them as
    legitimate. This is the **admin-only** alternative to force takeover
    so two engineers can collaborate on the same bench without one
    kicking the other.
    """
    from remote_desktop_dashboard.crud.audit import log_event
    from remote_desktop_dashboard.crud.lock import add_shared_operator

    body = body or {}
    _verify_admin_pin(body.get("admin_pin"), x_admin_pin, request)

    operator = (body.get("operator") or "").strip()
    if not operator:
        raise HTTPException(status_code=400, detail="operator is required")
    rdp_username = (body.get("rdp_username") or "").strip() or None

    machine = _machine_or_404(db, machine_name)
    refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)
    if not machine.locked_by:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Machine is not locked — nothing to share.",
        )

    client_ip = _client_ip(request)
    try:
        machine = add_shared_operator(
            db, machine, operator,
            rdp_username=rdp_username, client_ip=client_ip,
        )
    except LockError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    log_event(
        db,
        action="share_session",
        machine_name=machine.name,
        operator=operator,
        client_ip=client_ip,
        detail=f"Shared with {machine.locked_by}",
    )
    db.commit()
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/lock/admin-release", response_model=MachineRead)
async def api_admin_release(
    machine_name: str,
    body: AdminReleaseRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> MachineRead:
    """Admin: clear lock and RDP firewall rules without being the lock owner."""
    from remote_desktop_dashboard.crud.audit import log_event

    _verify_admin_pin(body.admin_pin, None, request)
    machine = _machine_or_404(db, machine_name)
    settings = get_settings()
    allow: list[str] = []
    if machine.lock_client_ip:
        allow.append(machine.lock_client_ip)
    schedule_clear_rdp_guard(bench_host(machine, prefer_ip=settings.poll_prefer_ip), allow)
    prior_owner = machine.locked_by
    machine = admin_force_release(db, machine)
    log_event(
        db,
        action="admin_release",
        machine_name=machine.name,
        operator=prior_owner,
        client_ip=_client_ip(request),
        detail="Admin force-released lock",
    )
    db.commit()
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/kick-others")
async def api_kick_others(
    machine_name: str,
    body: AdminReleaseRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict:
    """Admin: request a one-time kick of any RDP sessions not held by the lock owner.

    This never happens automatically. An admin must explicitly call this; the
    bench agent then logs off unauthorized sessions on its next poll, once.
    Requires the bench agent to be running on the target machine.
    """
    _verify_admin_pin(body.admin_pin, None, request)
    machine = _machine_or_404(db, machine_name)
    if not machine.locked_by:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Machine is not locked — nobody is authorized, so there is "
            "no 'others' to kick. Lock it first if you want exclusive access.",
        )
    from remote_desktop_dashboard.crud.audit import log_event

    with _KICK_LOCK:
        _KICK_PENDING.add(machine.name)
    log_event(
        db,
        action="kick_others",
        machine_name=machine.name,
        operator=machine.locked_by,
        client_ip=_client_ip(request),
        detail="Admin queued one-time kick of unauthorized sessions",
    )
    db.commit()
    logger.info(
        "Admin requested one-time session kick on %s (lock owner: %s)",
        machine.name,
        machine.locked_by,
    )
    return {
        "machine_name": machine.name,
        "kick_requested": True,
        "allow_users": _allow_users_for_lock(machine),
        "note": "Unauthorized sessions will be logged off on the next bench "
        "agent poll. Requires the bench agent to be installed and running.",
    }


@router.get("/settings/monitor", response_model=MonitorSettingsRead)
def api_get_monitor_settings(db: Session = Depends(get_db)) -> MonitorSettingsRead:
    from remote_desktop_dashboard.services.monitor_credentials import (
        monitor_credentials_source,
    )
    from remote_desktop_dashboard.services.settings_store import get_monitor_credentials_dict

    source = monitor_credentials_source()
    if source == "database":
        data = get_monitor_credentials_dict(db) or {}
        return MonitorSettingsRead(
            configured=True,
            domain=data.get("domain", ""),
            username=data.get("username", ""),
            password_set=True,
            source=source,
        )
    if source == "environment":
        s = get_settings()
        return MonitorSettingsRead(
            configured=True,
            domain=s.monitor_domain,
            username=s.monitor_username,
            password_set=bool(s.monitor_password),
            source=source,
        )
    return MonitorSettingsRead(configured=False, source="none")


@router.put("/settings/monitor", response_model=MonitorSettingsRead)
def api_save_monitor_settings(
    body: MonitorSettingsWrite,
    request: Request,
    db: Session = Depends(get_db),
) -> MonitorSettingsRead:
    from remote_desktop_dashboard.services.settings_store import save_monitor_credentials

    _verify_admin_pin(body.admin_pin, None, request)
    try:
        save_monitor_credentials(
            db,
            domain=body.domain,
            username=body.username,
            password=body.password,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return api_get_monitor_settings(db)


@router.post("/settings/monitor/test")
async def api_test_monitor_settings(
    body: MonitorSettingsTest,
    request: Request,
) -> dict:
    from remote_desktop_dashboard.services.monitor_credentials import (
        resolve_monitor_credentials,
    )
    from remote_desktop_dashboard.services.remote_users import probe_logged_in_users

    _verify_admin_pin(body.admin_pin, None, request)
    if resolve_monitor_credentials() is None:
        raise HTTPException(
            status_code=400,
            detail="Save monitor credentials first (Server settings).",
        )
    host = body.host.strip()
    limit = get_settings().settings_test_timeout_seconds + 3.0

    def _run() -> MonitorSnapshot:
        snap = probe_logged_in_users(host)
        return MonitorSnapshot(
            local_user=snap.local_user,
            rdp_users=snap.rdp_users,
            raw=snap.raw,
        )

    try:
        snap = await asyncio.wait_for(asyncio.to_thread(_run), timeout=limit)
    except asyncio.TimeoutError:
        return {
            "ok": False,
            "message": (
                f"Timed out after {int(limit)}s. Check IP, firewall, and that the service "
                "account can run remote tasklist on that bench."
            ),
        }
    except Exception as exc:
        return {"ok": False, "message": str(exc)}
    proc_n = snap.raw.get("process_count", 0) if isinstance(snap.raw, dict) else 0
    session_err = snap.raw.get("session_error") if isinstance(snap.raw, dict) else None
    return {
        "ok": True,
        "message": (
            f"OK — {proc_n} processes, local_user={snap.local_user!r}, "
            f"rdp_users={snap.rdp_users!r}, windows_app={snap.windows_app_users!r}, "
            f"mobaxterm={snap.mobaxterm_user!r}"
        ),
        "local_user": snap.local_user,
        "rdp_users": snap.rdp_users,
        "windows_app_users": snap.windows_app_users,
        "mobaxterm_user": snap.mobaxterm_user,
        "session_error": session_err,
    }


@router.get("/settings/rdp-guard")
def api_get_rdp_guard_setting() -> dict:
    """Return whether the firewall RDP guard is enabled (env + runtime override)."""
    from remote_desktop_dashboard.services.settings_store import (
        get_rdp_guard_runtime_override,
        is_rdp_guard_enabled,
    )

    return {
        "enabled": is_rdp_guard_enabled(),
        "env_default": bool(get_settings().rdp_guard_enabled),
        "override": get_rdp_guard_runtime_override(),
    }


@router.put("/settings/rdp-guard")
def api_set_rdp_guard_setting(body: dict, db: Session = Depends(get_db)) -> dict:
    """Admin-only: persistently enable/disable the RDP firewall guard at runtime."""
    from remote_desktop_dashboard.services.settings_store import (
        clear_rdp_guard_runtime_override,
        get_rdp_guard_runtime_override,
        is_rdp_guard_enabled,
        set_rdp_guard_runtime_override,
    )

    _verify_admin_pin(body.get("admin_pin"))
    if "enabled" in body and body["enabled"] is not None:
        set_rdp_guard_runtime_override(db, bool(body["enabled"]))
    else:
        clear_rdp_guard_runtime_override(db)
    return {
        "enabled": is_rdp_guard_enabled(),
        "env_default": bool(get_settings().rdp_guard_enabled),
        "override": get_rdp_guard_runtime_override(),
    }


# ---------------------------------------------------------------------------
# Bench-side agent (Option B): manages local "Remote Desktop Users" group.
# ---------------------------------------------------------------------------

def _allow_users_for_lock(machine) -> list[str]:
    """Who is currently allowed to RDP this bench (per the dashboard lock)?

    Only **Windows account names** belong in this list — the agent compares
    these against ``qwinsta`` output (e.g. ``LAB\\nkennedy``). The operator's
    *display name* (``locked_by``, e.g. ``Naveen Kennedy``) is **not** a
    Windows username and must never be put in this list: it can never match
    a real session, and if rdp_username is blank it would be the only entry
    and the agent would log everyone off.

    For redundancy we emit both the full form (``LAB\\nkennedy``) and the
    bare form (``nkennedy``) so the agent's bare-match logic and any
    direct match both succeed.

    2.16.0: the lock can now have shared participants — admin-waved
    additional operators who can RDP concurrently. Their RDP usernames
    are also included in the allow list so the bench-agent firewall /
    kicker does NOT log them off.
    """
    from remote_desktop_dashboard.crud.lock import get_lock_shared

    def _expand(rdp: str, out: list[str]) -> None:
        rdp = (rdp or "").strip()
        if not rdp:
            return
        if rdp not in out:
            out.append(rdp)
        if "\\" in rdp:
            bare = rdp.split("\\", 1)[-1].strip()
            if bare and bare.lower() != rdp.lower() and bare not in out:
                out.append(bare)

    out: list[str] = []
    _expand(machine.lock_rdp_username or "", out)
    for s in get_lock_shared(machine):
        _expand(s.get("rdp_username", ""), out)
    return out


def _allow_ips_for_lock_shared_extras(machine) -> list[str]:
    """Pull the client IPs of any shared participants so the bench firewall
    rule lets them through alongside the primary lock owner's IP."""
    from remote_desktop_dashboard.crud.lock import get_lock_shared
    out: list[str] = []
    for s in get_lock_shared(machine):
        ip = (s.get("client_ip") or "").strip()
        if ip and not _is_loopback(ip) and ip not in out:
            out.append(ip)
    return out


def _allow_ips_for_lock(machine) -> list[str]:
    """Which source IPs are allowed to RDP this bench under the current lock?

    Used by the bench agent's local firewall rule. Must include the actual PC
    that the lock owner is RDPing from. Extras from admin.env are always added
    (e.g. a hard-coded jumphost). The dashboard server's own LAN IP is added
    as a safety net so the operator can never lock themselves out via the
    monitor-credential machinery.
    """
    settings = get_settings()
    target = (machine.hostname or machine.ip_address or "").strip()

    ips: list[str] = []
    saved = (machine.lock_client_ip or "").strip()
    if saved and not _is_loopback(saved):
        ips.append(saved)
    elif settings.rdp_guard_fallback_to_server_ip and target:
        # Fall back to the dashboard server's LAN IP toward the bench. This
        # matters when the operator runs both the dashboard AND mstsc from the
        # same PC: lock_client_ip ends up as 127.0.0.1, but RDP traffic still
        # leaves over the LAN NIC.
        fallback = _server_lan_ip_for(target)
        if fallback:
            ips.append(fallback)

    for extra in (settings.rdp_guard_extra_ips or "").split(","):
        s = extra.strip()
        if s and not _is_loopback(s) and s not in ips:
            ips.append(s)

    # Shared-session participants' IPs (2.16.0).
    for s in _allow_ips_for_lock_shared_extras(machine):
        if s not in ips:
            ips.append(s)

    return ips


@router.get(
    "/machines/{machine_name}/access",
    dependencies=[Depends(verify_bench_agent_token)],
)
def api_bench_access(machine_name: str, db: Session = Depends(get_db)) -> dict:
    """Bench agent polls this endpoint to learn who is allowed to RDP right now."""
    from remote_desktop_dashboard.schemas.bench_agent import BenchAccessResponse
    from remote_desktop_dashboard import __version__

    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    settings = get_settings()
    # IMPORTANT: never let the *bench agent's* poll do remote-firewall
    # cleanup. ``refresh_expired_locks(db)`` defaults ``remote_firewall``
    # to True, which fires a synchronous remote command (`8s timeout
    # each, sometimes serialised`) for every expired lock anywhere on
    # the fleet. With multiple benches polling concurrently — exactly
    # the scenario the user reported in 2.14.x — that turns into a
    # request thread holding the DB session for tens of seconds while
    # the bench agent's 15s HTTP timeout fires.
    #
    # The background poller (``services/poller.py``) already does the
    # remote-firewall cleanup at its own pace; we just need the DB
    # cleanup here so the agent gets a fresh ``locked`` reading.
    refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)
    locked = bool(machine.locked_by)
    with _KICK_LOCK:
        kick_requested = machine.name in _KICK_PENDING
        _KICK_PENDING.discard(machine.name)
    # One-shot break-glass: admin asked us to restore native RDP on this bench.
    # Override locked/firewall_lock so the agent removes its custom firewall rule
    # and re-enables the built-in Remote Desktop rules.
    with _RESTORE_LOCK:
        restore_requested = machine.name in _RESTORE_PENDING
        _RESTORE_PENDING.discard(machine.name)
    if restore_requested:
        effective_locked = False
        effective_locked_by = None
        allow_users: list[str] = []
        allow_ips: list[str] = []
        firewall_lock = False
        kick_other = False
    else:
        effective_locked = locked
        effective_locked_by = machine.locked_by
        allow_users = _allow_users_for_lock(machine) if locked else []
        allow_ips = _allow_ips_for_lock(machine) if locked else []
        firewall_lock = bool(settings.bench_agent_firewall_lock)
        kick_other = locked and (
            kick_requested or settings.bench_agent_kick_other_sessions
        )
    return BenchAccessResponse(
        machine_name=machine.name,
        locked=effective_locked,
        locked_by=effective_locked_by,
        allow_users=allow_users,
        allow_ips=allow_ips,
        firewall_lock=firewall_lock,
        kick_other_sessions=kick_other,
        poll_seconds=max(2, int(settings.bench_agent_poll_seconds)),
        server_version=__version__,
        restore_native_rdp=restore_requested,
    ).model_dump(mode="json")


@router.post(
    "/machines/{machine_name}/agent/heartbeat",
    dependencies=[Depends(verify_bench_agent_token)],
)
def api_bench_heartbeat(
    machine_name: str,
    body: "dict",
    db: Session = Depends(get_db),
) -> dict:
    """Bench agent reports what it has applied locally.

    The heartbeat is also the most authoritative source of "is this
    machine alive, and who is using it right now" — far more reliable
    than the dashboard's TCP probe, which can be blocked by firewalls
    or intermittently slow. So we treat every heartbeat as proof of life:
    the machine is marked online and ``last_seen`` is bumped here, not
    only in the WMI poller path. That fixes the long-standing bug where
    a fully-functional bench would show red because TCP 3389 was
    unreachable from the dashboard.

    We also persist the active sessions reported by ``qwinsta`` so the
    dashboard surfaces an external RDP user (e.g. someone bypassing the
    dashboard) even when the poller is disabled.
    """
    import json as _json
    from datetime import datetime, timezone

    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")

    now = datetime.now(timezone.utc)
    machine.bench_agent_version = (body.get("agent_version") or "")[:32] or None
    machine.bench_agent_last_seen = now

    applied = body.get("applied_users") or []
    if not isinstance(applied, list):
        applied = []
    machine.bench_agent_applied = _json.dumps(applied)
    err = body.get("error")
    machine.bench_agent_error = (err or "")[:500] or None

    # Heartbeat == proof of life. This is what fixes red/offline when
    # the agent is fine but the poller can't TCP-probe 3389.
    machine.is_online = True
    machine.last_seen = now

    # External-session visibility. Whoever the agent sees logged in
    # right now (including users who bypassed the dashboard and RDPed
    # directly) becomes the dashboard's view of "current sessions".
    rdp_users = body.get("current_rdp_users") or []
    local_users = body.get("local_users") or []
    if isinstance(rdp_users, list):
        # Skip blanks and de-dupe, keeping first-seen order.
        seen: set[str] = set()
        clean: list[str] = []
        for u in rdp_users:
            if not isinstance(u, str):
                continue
            uu = u.strip()
            if not uu or uu.lower() in seen:
                continue
            seen.add(uu.lower())
            clean.append(uu)
        machine.rdp_users = _json.dumps(clean)
    if isinstance(local_users, list) and local_users:
        # Console session — only one user at a time, take the first.
        first = next(
            (u for u in local_users if isinstance(u, str) and u.strip()),
            None,
        )
        if first:
            machine.local_user = first.strip()
    elif isinstance(local_users, list) and not local_users:
        # Agent explicitly reports nobody at the console -> clear it,
        # but only if we previously had a value (avoid pointless writes).
        if machine.local_user:
            machine.local_user = None

    db.commit()

    # Push live agent status to every dashboard tab. Without this,
    # ``bench_agent_last_seen`` only updates in the DB while the UI
    # keeps showing "stale" until the poller's next broadcast — which
    # is exactly what users reported after Connect/Release.
    _maybe_broadcast_agent_heartbeat(machine.name)

    return {"ok": True}


# Throttle WS fan-out: at most one broadcast per machine every 8s.
_AGENT_WS_LAST_BROADCAST: dict[str, float] = {}
_AGENT_WS_BROADCAST_INTERVAL = 8.0


def _maybe_broadcast_agent_heartbeat(machine_name: str) -> None:
    import time

    now = time.monotonic()
    last = _AGENT_WS_LAST_BROADCAST.get(machine_name, 0.0)
    if now - last < _AGENT_WS_BROADCAST_INTERVAL:
        return
    _AGENT_WS_LAST_BROADCAST[machine_name] = now

    async def _do_broadcast() -> None:
        from remote_desktop_dashboard.database import SessionLocal
        from remote_desktop_dashboard.services.reachability_cache import (
            get_cached_reachability,
        )

        db = SessionLocal()
        try:
            from remote_desktop_dashboard.crud.machine import list_machines

            machines = list_machines(db)
            reach = get_cached_reachability(machines, allow_refresh=False)
            payload = machines_payload(machines, reachability=reach)
            await manager.broadcast(payload)
        finally:
            db.close()

    try:
        asyncio.get_running_loop()
        asyncio.create_task(_do_broadcast())
    except RuntimeError:
        pass


def _bench_status_for(machine, settings) -> dict:
    """Shared status-shape builder used by both the per-machine endpoint
    and the bulk endpoint below. Keeping this in one place so the UI's
    two read paths can never drift apart."""
    import json as _json
    from datetime import datetime, timezone
    from remote_desktop_dashboard.schemas.bench_agent import BenchAgentStatus

    ago: float | None = None
    online = False
    if machine.bench_agent_last_seen is not None:
        last = machine.bench_agent_last_seen
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        ago = max(0.0, (datetime.now(timezone.utc) - last).total_seconds())
        online = ago <= max(15, settings.bench_agent_offline_grace_seconds)
    applied: list[str] = []
    try:
        if machine.bench_agent_applied:
            parsed = _json.loads(machine.bench_agent_applied)
            if isinstance(parsed, list):
                applied = [str(x) for x in parsed]
    except Exception:
        applied = []
    return BenchAgentStatus(
        machine_name=machine.name,
        installed=bool(machine.bench_agent_last_seen),
        version=machine.bench_agent_version,
        last_seen=machine.bench_agent_last_seen,
        last_seen_seconds_ago=ago,
        online=online,
        applied_users=applied,
        error=machine.bench_agent_error,
    ).model_dump(mode="json")


@router.get("/machines/{machine_name}/agent/status")
def api_bench_status(machine_name: str, db: Session = Depends(get_db)) -> dict:
    """UI reads this to show 'Agent: connected 8s ago' badges."""
    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return _bench_status_for(machine, get_settings())


@router.get("/agents/status")
def api_bench_status_all(db: Session = Depends(get_db)) -> dict:
    """Return agent status for every machine in one request.

    Replaces the old per-machine N HTTP calls the bench-agents panel used
    to make. With 50+ machines that was 50+ round trips and an equal
    number of DB sessions; now it's exactly one. Important for scale on
    busy LANs where dozens of dashboards might be open at once.
    """
    settings = get_settings()
    machines = list_machines(db)
    return {
        "agents": [_bench_status_for(m, settings) for m in machines],
    }


@router.post("/machines/{machine_name}/agent/install")
def api_push_install_agent(
    machine_name: str,
    request: Request,
    body: dict | None = None,
    x_admin_pin: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> dict:
    """Push-install the bench agent from this dashboard to the bench (one-click).

    Uses saved monitor credentials to SMB-copy the agent and register a SYSTEM
    scheduled task on the bench. Admin PIN required.
    """
    from remote_desktop_dashboard.services.bench_agent_push import push_install

    body = body or {}
    _verify_admin_pin(body.get("admin_pin"), x_admin_pin, request)

    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")

    base_url = str(request.base_url).rstrip("/")
    target = (machine.hostname or machine.ip_address or "").strip()
    if not target:
        raise HTTPException(status_code=400, detail="Machine has no hostname/IP set.")

    # If the dashboard was opened on localhost, the bench can't call back.
    # Prefer the server-side LAN IP in that case.
    if any(part in base_url for part in ("//localhost", "//127.0.0.1", "//[::1]")):
        server_ip = _server_lan_ip_for(target)
        if server_ip:
            from urllib.parse import urlparse, urlunparse
            u = urlparse(base_url)
            base_url = urlunparse(u._replace(netloc=f"{server_ip}:{u.port or 8080}"))

    settings = get_settings()
    if not (settings.bench_agent_token or "").strip():
        raise HTTPException(
            status_code=400,
            detail="Set RDD_BENCH_AGENT_TOKEN in admin.env first, then restart.",
        )

    result = push_install(target, machine.name, base_url)

    # Pre-mark the bench as having an agent so the next Connect skips the
    # legacy firewall guard immediately, even before the real first heartbeat
    # arrives (~5 s race). A real heartbeat from the running agent will
    # overwrite this value within seconds.
    if result.ok:
        from datetime import datetime, timezone
        machine.bench_agent_last_seen = datetime.now(timezone.utc)
        machine.bench_agent_version = f"pushed-{__version__}"
        machine.bench_agent_applied = "[]"
        machine.bench_agent_error = None
        db.commit()

    return {
        "ok": result.ok,
        "host": result.host,
        "steps": result.steps,
        "error": result.error,
        "dashboard_url": base_url,
    }


@router.get("/machines/{machine_name}/agent/diagnostics")
def api_bench_diagnostics(
    machine_name: str,
    request: Request,
    admin_pin: str | None = Query(None),
    x_admin_pin: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> dict:
    """Read the bench's config, log, and scheduled-task state to figure out
    why the agent isn't reporting in. Requires admin PIN (accepted via
    ``X-Admin-PIN`` header or, for back-compat, ``?admin_pin=``)."""
    from remote_desktop_dashboard.services.bench_agent_push import diagnose
    from datetime import datetime, timezone

    _verify_admin_pin(admin_pin, x_admin_pin, request)

    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    target = (machine.hostname or machine.ip_address or "").strip()
    if not target:
        raise HTTPException(status_code=400, detail="Machine has no hostname/IP set.")

    # Pre-compute how stale the dashboard's view is so ``diagnose`` can
    # weigh "a heartbeat just arrived" against "Task Scheduler is still
    # showing an old non-zero LastResult". Otherwise the verdict turns
    # red even when the agent is provably alive.
    heartbeat_age: float | None = None
    if machine.bench_agent_last_seen is not None:
        last = machine.bench_agent_last_seen
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        heartbeat_age = (datetime.now(timezone.utc) - last).total_seconds()

    rpt = diagnose(target, machine.name, heartbeat_age_seconds=heartbeat_age)

    dashboard_view = {
        "bench_agent_version": machine.bench_agent_version,
        "last_seen": machine.bench_agent_last_seen.isoformat() if machine.bench_agent_last_seen else None,
        "seconds_ago": round(heartbeat_age, 1) if heartbeat_age is not None else None,
        "online": (
            heartbeat_age is not None
            and heartbeat_age <= max(15, get_settings().bench_agent_offline_grace_seconds)
        ),
        "applied_users": json.loads(machine.bench_agent_applied) if machine.bench_agent_applied else [],
        "error": machine.bench_agent_error,
    }

    payload = rpt.to_dict()
    payload["dashboard_view"] = dashboard_view
    return payload


@router.post("/machines/{machine_name}/agent/uninstall")
def api_push_uninstall_agent(
    machine_name: str,
    request: Request,
    body: dict | None = None,
    db: Session = Depends(get_db),
) -> dict:
    from remote_desktop_dashboard.services.bench_agent_push import uninstall

    body = body or {}
    _verify_admin_pin(body.get("admin_pin"), None, request)

    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    target = (machine.hostname or machine.ip_address or "").strip()
    if not target:
        raise HTTPException(status_code=400, detail="Machine has no hostname/IP set.")
    result = uninstall(target)
    if result.ok:
        machine.bench_agent_version = None
        machine.bench_agent_applied = None
        machine.bench_agent_error = None
        db.commit()
    return {
        "ok": result.ok,
        "host": result.host,
        "steps": result.steps,
        "error": result.error,
    }


@router.get("/agent/install-command")
def api_bench_install_command(
    request: Request,
    admin_pin: str | None = Query(None),
    x_admin_pin: str | None = Header(default=None),
) -> dict:
    """Return the one-liner PowerShell install command for the bench agent.

    Accepts the PIN via ``X-Admin-PIN`` header (preferred — keeps the
    PIN out of URL logs) or ``?admin_pin=`` for back-compat with older
    UIs that haven't been refreshed yet.
    """
    _verify_admin_pin(admin_pin, x_admin_pin, request)
    settings = get_settings()
    token = (settings.bench_agent_token or "").strip()
    if not token:
        raise HTTPException(
            status_code=400,
            detail="Set RDD_BENCH_AGENT_TOKEN in admin.env first, then restart the server.",
        )
    base = str(request.base_url).rstrip("/")
    installer_url = f"{base}/agent/install.ps1?token={token}"
    agent_url = f"{base}/agent/bench_agent.ps1"
    pwsh = (
        f"$ErrorActionPreference='Stop'; "
        f"$base='{base}'; "
        f"$token='{token}'; "
        f"iwr \"$base/agent/install.ps1?token=$token\" "
        f"-UseBasicParsing | iex"
    )
    return {
        "base_url": base,
        "installer_url": installer_url,
        "agent_url": agent_url,
        "command": f"powershell -ExecutionPolicy Bypass -NoProfile -Command \"{pwsh}\"",
    }


# ---------------------------------------------------------------------------
# Admin mode + emergency RDP restore (2.10.1)
# ---------------------------------------------------------------------------


@router.post("/admin/verify")
def api_admin_verify(body: "dict") -> dict:
    """Used by the UI to switch into Admin mode without exposing the PIN.

    The browser sends the PIN once, we check it against the configured admin
    PIN, and on success the browser caches an opaque session token. Admin
    actions still re-validate the PIN on every call server-side; this endpoint
    only controls UI visibility.
    """
    pin = (body or {}).get("admin_pin")
    _verify_admin_pin(pin)
    return {"ok": True, "admin": True}


# =========================================================================
# 2.16.0 — per-user admin accounts (login + password + user management)
# =========================================================================

def _set_admin_cookie(response, token: str) -> None:
    from remote_desktop_dashboard.services.admin_auth import (
        SESSION_COOKIE_NAME, SESSION_TTL_SECONDS,
    )
    response.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=token,
        max_age=SESSION_TTL_SECONDS,
        httponly=True,
        # SameSite=Lax so a normal cross-tab nav (admin link in
        # bookmark) still presents the cookie, while preventing
        # cross-site form submissions from drive-by sites.
        samesite="lax",
        # We can't unconditionally set ``secure=True`` because the
        # dashboard frequently runs over plain HTTP on the LAN. When
        # HTTPS is on, the reverse proxy / uvicorn-with-cert layer is
        # responsible for tagging the cookie secure.
        secure=False,
        path="/",
    )


def _clear_admin_cookie(response) -> None:
    from remote_desktop_dashboard.services.admin_auth import SESSION_COOKIE_NAME
    response.delete_cookie(SESSION_COOKIE_NAME, path="/")


@router.get("/admin/me")
def api_admin_me(request: Request, db: Session = Depends(get_db)) -> dict:
    """Who am I? Reports the active admin session (if any) so the UI
    can show "Logged in as Alice" vs "Sign in" without making the user
    re-type their password every time the page reloads."""
    from remote_desktop_dashboard.crud.operator import (
        get_operator_pref, has_any_admin_user,
    )
    from remote_desktop_dashboard.services.admin_auth import (
        SESSION_COOKIE_NAME, verify_session,
    )

    token = request.cookies.get(SESSION_COOKIE_NAME)
    session = verify_session(token) if token else None
    out: dict = {
        "admin": False,
        "operator": None,
        "needs_password_set": False,
        "any_admin_exists": has_any_admin_user(db),
        "legacy_pin_configured": bool((get_settings().admin_pin or "").strip()),
    }
    if session is None:
        return out
    pref = get_operator_pref(db, session.operator)
    if pref is None or not pref.is_admin:
        # Designation revoked while their cookie was still alive.
        return out
    out.update({
        "admin": True,
        "operator": pref.display_name,
        "needs_password_set": not pref.admin_password_hash,
    })
    return out


@router.post("/admin/login")
def api_admin_login(
    body: dict,
    response: Response,
    db: Session = Depends(get_db),
) -> dict:
    """Sign in to an admin account.

    Body: ``{"operator": "Alice", "password": "..."}``. Returns
    ``{"ok": True}`` and sets the session cookie on success. On a
    fresh dashboard with no admins yet, supply ``"admin_pin"`` instead
    of ``password`` to bootstrap yourself as the first admin — your
    next call will be ``/admin/set-password``.
    """
    from remote_desktop_dashboard.crud.operator import (
        get_operator_pref, has_any_admin_user, set_admin_flag,
        verify_admin_password,
    )
    from remote_desktop_dashboard.services.admin_auth import issue_session

    body = body or {}
    operator = (body.get("operator") or "").strip()
    password = body.get("password") or ""
    bootstrap_pin = body.get("admin_pin")

    if not operator:
        raise HTTPException(status_code=400, detail="operator is required")

    # Bootstrap path: legacy PIN OR no admins yet. Promote the operator
    # to admin (without a password); they MUST call /admin/set-password
    # next.
    if bootstrap_pin or not has_any_admin_user(db):
        try:
            _verify_admin_pin(bootstrap_pin)
        except HTTPException:
            # Re-raise as 401 so the UI can show "wrong PIN/password".
            raise HTTPException(
                status_code=401,
                detail="Invalid admin PIN.",
            )
        pref = set_admin_flag(db, display_name=operator, is_admin=True)
        db.commit()
        token = issue_session(pref.display_name)
        _set_admin_cookie(response, token)
        return {
            "ok": True,
            "operator": pref.display_name,
            "needs_password_set": not pref.admin_password_hash,
            "bootstrap": True,
        }

    # Normal login: verify the per-user password.
    pref = get_operator_pref(db, operator)
    if pref is None or not pref.is_admin:
        # Same 401 either way so we don't leak which operators exist.
        raise HTTPException(status_code=401, detail="Invalid username or password.")
    if not pref.admin_password_hash:
        # Designated admin who has never set a password — we cannot let
        # them in with an empty password.
        raise HTTPException(
            status_code=401,
            detail=(
                "This admin account has no password yet. Use the admin "
                "PIN to log in once, then set a password."
            ),
        )
    if not verify_admin_password(db, display_name=operator, password=password):
        raise HTTPException(status_code=401, detail="Invalid username or password.")

    token = issue_session(pref.display_name)
    _set_admin_cookie(response, token)
    return {
        "ok": True,
        "operator": pref.display_name,
        "needs_password_set": False,
        "bootstrap": False,
    }


@router.post("/admin/logout")
def api_admin_logout(response: Response) -> dict:
    _clear_admin_cookie(response)
    return {"ok": True}


@router.post("/admin/set-password")
def api_admin_set_password(
    body: dict,
    request: Request,
    response: Response,
    db: Session = Depends(get_db),
) -> dict:
    """First-time password set OR change password.

    Body:
      ``{"new_password": "..."}``                 — only valid if the caller has no
                                                    password yet (first-attempt set).
      ``{"current_password": "...", "new_password": "..."}``
                                                  — change my password.
      ``{"admin_pin": "...", "operator": "...", "new_password": "..."}``
                                                  — admin-PIN bootstrap path
                                                    (e.g. password reset for a
                                                    designated admin who lost theirs).

    Returns the freshly-issued session token cookie so the caller is
    logged in afterwards.
    """
    from remote_desktop_dashboard.crud.operator import (
        get_operator_pref, set_admin_password, verify_admin_password,
    )
    from remote_desktop_dashboard.services.admin_auth import (
        SESSION_COOKIE_NAME, issue_session, verify_session,
    )

    body = body or {}
    new_password = (body.get("new_password") or "").strip()
    if len(new_password) < 4:
        raise HTTPException(
            status_code=400,
            detail="New password must be at least 4 characters.",
        )

    # Resolve target operator either from the live session OR from the
    # admin-PIN bootstrap path.
    token = request.cookies.get(SESSION_COOKIE_NAME)
    session = verify_session(token) if token else None
    operator: str | None = None

    if session is not None:
        operator = session.operator
        pref = get_operator_pref(db, operator)
        if pref is None or not pref.is_admin:
            raise HTTPException(status_code=403, detail="Not an admin.")

        # If a password was already set, REQUIRE current_password.
        if pref.admin_password_hash:
            current = body.get("current_password") or ""
            if not verify_admin_password(
                db, display_name=operator, password=current
            ):
                raise HTTPException(
                    status_code=401, detail="Current password is incorrect."
                )
    else:
        # No session — admin-PIN bootstrap (or initial first-set after
        # an admin-PIN login that we never gave a password to).
        pin = body.get("admin_pin")
        target = (body.get("operator") or "").strip()
        if not target:
            raise HTTPException(
                status_code=400, detail="operator is required without an active session.",
            )
        try:
            _verify_admin_pin(pin)
        except HTTPException:
            raise HTTPException(status_code=401, detail="Invalid admin PIN.")
        pref = get_operator_pref(db, target)
        if pref is None or not pref.is_admin:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"{target} is not designated as an admin. "
                    "Promote them first under Admin -> Manage admins."
                ),
            )
        operator = pref.display_name

    set_admin_password(db, display_name=operator, password=new_password)
    db.commit()

    fresh_token = issue_session(operator)
    _set_admin_cookie(response, fresh_token)
    return {"ok": True, "operator": operator}


@router.get("/admin/users")
def api_admin_list_users(
    request: Request,
    db: Session = Depends(get_db),
) -> dict:
    """List all admin operators. Admin-only."""
    from remote_desktop_dashboard.crud.operator import list_admin_operators

    _verify_admin_pin(None, None, request)
    rows = list_admin_operators(db)
    return {
        "admins": [
            {
                "name": r.display_name,
                "has_password": bool(r.admin_password_hash),
                "password_set_at": (
                    r.admin_password_set_at.isoformat()
                    if r.admin_password_set_at else None
                ),
            }
            for r in rows
        ]
    }


@router.post("/admin/users")
def api_admin_set_user(
    body: dict,
    request: Request,
    db: Session = Depends(get_db),
) -> dict:
    """Designate / un-designate an operator as admin. Admin-only.

    Body: ``{"operator": "Bob", "is_admin": true}``.
    """
    from remote_desktop_dashboard.crud.operator import set_admin_flag

    _verify_admin_pin(None, None, request)
    body = body or {}
    operator = (body.get("operator") or "").strip()
    if not operator:
        raise HTTPException(status_code=400, detail="operator is required")
    is_admin = bool(body.get("is_admin", True))
    pref = set_admin_flag(db, display_name=operator, is_admin=is_admin)
    db.commit()
    return {
        "ok": True,
        "operator": pref.display_name,
        "is_admin": pref.is_admin,
        "has_password": bool(pref.admin_password_hash),
    }


# In-process one-shot flag set by /emergency-restore and consumed by the
# next bench-agent /access poll. Keyed by machine name. The flag instructs
# the agent to wipe the custom firewall rule AND re-enable the built-in
# "Remote Desktop" rules even if the firewall_lock setting is otherwise on.
_RESTORE_PENDING: set[str] = set()
_RESTORE_LOCK = threading.Lock()


@router.post("/machines/{machine_name}/emergency-restore-rdp")
def api_emergency_restore(
    machine_name: str,
    body: AdminReleaseRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> dict:
    """Admin-only break-glass: tell the bench agent to remove the custom
    firewall lock rule and re-enable the built-in Remote Desktop rules.

    Use this when something went wrong and an admin needs to get RDP back to
    its native, dashboard-unmanaged behaviour on a specific bench. The lock
    is released as a side effect. Requires admin PIN.
    """
    from remote_desktop_dashboard.crud.audit import log_event

    _verify_admin_pin(body.admin_pin, None, request)
    machine = _machine_or_404(db, machine_name)

    # Release any active dashboard lock.
    if machine.locked_by:
        prior_owner = machine.locked_by
        machine = admin_force_release(db, machine)
    else:
        prior_owner = None

    # Queue the one-shot restore signal for the next agent poll.
    with _RESTORE_LOCK:
        _RESTORE_PENDING.add(machine.name)

    log_event(
        db,
        action="emergency_restore_rdp",
        machine_name=machine.name,
        operator=prior_owner,
        client_ip=_client_ip(request),
        detail="Admin asked bench agent to restore native Windows RDP rules.",
    )
    db.commit()

    # Build a manual PowerShell fallback the admin can paste on the bench
    # if the agent is offline. Pure stdlib commands; no third-party deps.
    manual = (
        "# Run on the bench in elevated PowerShell to restore native RDP:\r\n"
        "Remove-NetFirewallRule -DisplayName 'RDD-Bench-Agent-RDP-Allow' "
        "-ErrorAction SilentlyContinue;\r\n"
        "foreach ($n in 'RemoteDesktop-UserMode-In-TCP',"
        "'RemoteDesktop-UserMode-In-UDP',"
        "'RemoteDesktop-UserMode-In-TCP-WS',"
        "'RemoteDesktop-UserMode-In-TCP-WSS') "
        "{ Enable-NetFirewallRule -Name $n -ErrorAction SilentlyContinue };\r\n"
        "Stop-ScheduledTask -TaskName 'RDD-Bench-Agent' -ErrorAction SilentlyContinue;\r\n"
        "Unregister-ScheduledTask -TaskName 'RDD-Bench-Agent' -Confirm:$false "
        "-ErrorAction SilentlyContinue;"
    )

    return {
        "machine_name": machine.name,
        "restore_queued": True,
        "manual_powershell": manual,
        "note": (
            "Queued. The bench agent will remove the custom firewall lock rule "
            "and re-enable the built-in Remote Desktop rules within ~5 seconds "
            "on its next poll. If the agent is offline, paste manual_powershell "
            "into an elevated PowerShell on the bench."
        ),
    }


# ---------------------------------------------------------------------------
# Operator preferences + Audit log (2.10.0)
# ---------------------------------------------------------------------------


@router.get("/operators/{name}")
def api_operator_get(name: str, db: Session = Depends(get_db)) -> dict:
    """Return saved RDP defaults for an operator name (case-insensitive)."""
    from remote_desktop_dashboard.crud.operator import get_operator_pref
    from remote_desktop_dashboard.schemas.operator import OperatorPreferenceRead

    pref = get_operator_pref(db, name)
    if pref is None:
        return {
            "display_name": name,
            "rdp_username": None,
            "rdp_domain": None,
            "use_hostname": None,
            "last_used_at": None,
            "known": False,
        }
    data = OperatorPreferenceRead.model_validate(pref).model_dump(mode="json")
    use_hostname = pref.use_hostname
    data["use_hostname"] = (
        True if use_hostname == "1" else False if use_hostname == "0" else None
    )
    data["known"] = True
    return data


@router.put("/operators/{name}")
def api_operator_put(
    name: str,
    body: "dict",
    db: Session = Depends(get_db),
) -> dict:
    """Save RDP defaults for an operator name. Body keys: rdp_username,
    rdp_domain, use_hostname. Missing keys are left unchanged."""
    from remote_desktop_dashboard.crud.operator import upsert_operator_pref

    display = (body.get("display_name") or name).strip()
    if not display:
        raise HTTPException(status_code=400, detail="display_name is required")

    use_hostname = body.get("use_hostname")
    if isinstance(use_hostname, str):
        use_hostname = use_hostname.lower() in ("1", "true", "yes")
    elif use_hostname is not None and not isinstance(use_hostname, bool):
        use_hostname = bool(use_hostname)

    upsert_operator_pref(
        db,
        display_name=display,
        rdp_username=body.get("rdp_username"),
        rdp_domain=body.get("rdp_domain"),
        use_hostname=use_hostname,
    )
    db.commit()
    return {"ok": True}


@router.get("/operators")
def api_operators_list(
    limit: int = Query(50, ge=1, le=500),
    db: Session = Depends(get_db),
) -> list[dict]:
    """List recent operators (most-recent first). Used for autocomplete."""
    from remote_desktop_dashboard.crud.operator import list_operator_prefs

    prefs = list_operator_prefs(db, limit=limit)
    out: list[dict] = []
    for p in prefs:
        out.append({
            "display_name": p.display_name,
            "rdp_username": p.rdp_username,
            "rdp_domain": p.rdp_domain,
            "last_used_at": p.last_used_at.isoformat() if p.last_used_at else None,
        })
    return out


@router.get("/audit")
def api_audit_list(
    machine: str | None = Query(None),
    action: str | None = Query(None),
    operator: str | None = Query(None),
    limit: int = Query(200, ge=1, le=1000),
    db: Session = Depends(get_db),
) -> list[dict]:
    """Audit log feed for the Audit Log tab. Newest first."""
    from remote_desktop_dashboard.crud.audit import list_events
    from remote_desktop_dashboard.schemas.audit import AuditEventRead

    events = list_events(
        db,
        machine_name=machine,
        action=action,
        operator=operator,
        limit=limit,
    )
    return [AuditEventRead.model_validate(e).model_dump(mode="json") for e in events]
