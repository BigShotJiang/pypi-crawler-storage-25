"""API dependencies.

All token / PIN comparisons use ``hmac.compare_digest`` so a remote
attacker cannot probe secrets one byte at a time via response timing.
"""

import hmac

from fastapi import Header, HTTPException, status

from remote_desktop_dashboard.config import get_settings


def _ct_eq(supplied: str | None, expected: str) -> bool:
    """Constant-time equality. Safe with ``None`` and stripped strings."""
    s = (supplied or "").strip()
    e = (expected or "").strip()
    if not s or not e:
        return False
    return hmac.compare_digest(s, e)


def verify_agent_key(
    x_api_key: str | None = Header(default=None),
    x_bench_token: str | None = Header(default=None),
    authorization: str | None = Header(default=None),
) -> None:
    """Authenticate the legacy ``/machines/{name}/status`` endpoint.

    Previously this was a no-op when ``RDD_AGENT_API_KEY`` was empty,
    which meant *anyone on the LAN* could forge "Bob is logged in on
    ATC5" and pollute the dashboard. From 2.13+ the endpoint requires
    **either** the legacy agent API key OR the bench-agent token. If
    neither is configured the endpoint is locked (503) so a
    misconfiguration can't accidentally leave it open.
    """
    settings = get_settings()
    legacy = (settings.agent_api_key or "").strip()
    bench = (settings.bench_agent_token or "").strip()
    if not legacy and not bench:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Telemetry ingestion is disabled. Set RDD_BENCH_AGENT_TOKEN "
                "(or RDD_AGENT_API_KEY for legacy agents) in admin.env."
            ),
        )
    bearer = ""
    if authorization and authorization.lower().startswith("bearer "):
        bearer = authorization.split(None, 1)[1].strip()
    if legacy and _ct_eq(x_api_key, legacy):
        return
    if bench and (_ct_eq(x_bench_token, bench) or _ct_eq(bearer, bench)):
        return
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or missing agent credentials.",
    )


def verify_bench_agent_token(
    authorization: str | None = Header(default=None),
    x_bench_token: str | None = Header(default=None),
) -> None:
    """Bench agent uses a separate token in ``X-Bench-Token`` or
    ``Authorization: Bearer ...``."""
    settings = get_settings()
    expected = (settings.bench_agent_token or "").strip()
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Bench agent disabled: set RDD_BENCH_AGENT_TOKEN in admin.env.",
        )
    bearer = ""
    if authorization and authorization.lower().startswith("bearer "):
        bearer = authorization.split(None, 1)[1].strip()
    if _ct_eq(x_bench_token, expected) or _ct_eq(bearer, expected):
        return
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid bench agent token.",
    )
