"""FastAPI application factory."""

import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Header, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from remote_desktop_dashboard import __version__
from remote_desktop_dashboard.api.routes import router as api_router
from remote_desktop_dashboard.api.websocket import router as ws_router
from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.database import init_db
from remote_desktop_dashboard.services.local_launcher import start_local_launcher, stop_local_launcher
from remote_desktop_dashboard.services.poller import set_event_loop, start_poller, stop_poller
from remote_desktop_dashboard.services.reachability_cache import (
    start_reachability_refresher,
    stop_reachability_refresher,
)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    from remote_desktop_dashboard.config import get_settings
    from remote_desktop_dashboard.services.bootstrap import bootstrap_install_layout

    bootstrap_install_layout()
    get_settings.cache_clear()
    init_db()
    set_event_loop(asyncio.get_running_loop())
    start_local_launcher()
    start_reachability_refresher()
    start_poller()
    yield
    stop_poller()
    stop_reachability_refresher()
    stop_local_launcher()


class _NoCacheMiddleware(BaseHTTPMiddleware):
    """Make sure the dashboard HTML/CSS/JS reflect the deployed version immediately."""

    async def dispatch(self, request, call_next):
        response = await call_next(request)
        path = request.url.path
        if path == "/" or path.startswith("/static/") or path.endswith((".html", ".css", ".js")):
            response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
            response.headers["X-App-Version"] = __version__
        return response


def create_app() -> FastAPI:
    settings = get_settings()
    static_dir = settings.resolved_static_dir

    app = FastAPI(
        title="Remote Desktop Dashboard",
        description=(
            "Agentless bench monitoring from one Windows server — "
            "no per-machine agents required"
        ),
        version=__version__,
        lifespan=lifespan,
    )

    app.add_middleware(_NoCacheMiddleware)
    app.include_router(api_router)
    app.include_router(ws_router)

    if static_dir.is_dir():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

        @app.get("/")
        async def index() -> FileResponse:
            return FileResponse(
                static_dir / "index.html",
                headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0"},
            )

    @app.get("/favicon.ico", include_in_schema=False)
    async def favicon():
        from fastapi.responses import Response as _Response

        favicon_file = static_dir / "favicon.ico"
        if favicon_file.is_file():
            return FileResponse(favicon_file)
        return _Response(status_code=204)

    _AGENT_DATA = Path(__file__).resolve().parent / "data"

    @app.get("/agent/bench_agent.ps1", include_in_schema=False)
    async def serve_bench_agent():
        from fastapi.responses import Response as _Response

        agent_file = _AGENT_DATA / "bench_agent.ps1"
        if not agent_file.is_file():
            return _Response(status_code=404, content="bench_agent.ps1 not bundled")
        return FileResponse(
            agent_file,
            media_type="text/plain",
            headers={"Cache-Control": "no-store, no-cache, must-revalidate"},
        )

    @app.get("/operator/install-rdp-handler.ps1", include_in_schema=False)
    async def serve_rdp_handler_installer(request: Request):
        """Per-operator installer that registers ``rdp:`` to native mstsc.exe.

        Operators download and run this once on their own PC (no admin
        elevation, HKCU only). After that, every dashboard Connect
        opens mstsc directly to the RDP login screen — no .rdp file
        appears in their Downloads folder, no Windows App / msrdc
        dependency.

        We TEMPLATE the dashboard's own URL into ``-DashboardUrl`` at
        the top of the script so the installer can:
          (a) pop the dashboard tab right back to the foreground after
              the registry write succeeds, and
          (b) attach ``?rdp-handler-ready=1`` so the dashboard JS sets
              its localStorage flag and dismisses the setup banner
              forever.

        That makes the whole workflow a single PowerShell command
        from the operator's POV.
        """
        from fastapi.responses import Response as _Response, PlainTextResponse

        script = _AGENT_DATA / "install-rdp-handler.ps1"
        if not script.is_file():
            return _Response(
                status_code=404,
                content="install-rdp-handler.ps1 not bundled",
            )

        # Echo back the URL the operator actually hit, not the one in
        # the server config — that way it works for ``localhost``, for
        # ``http://10.x.y.z:8080``, and for HTTPS without any extra
        # config on the server side. ``request.base_url`` already
        # contains scheme://host[:port]/.
        dashboard_url = str(request.base_url).rstrip("/") + "/"

        # PowerShell single-quoted strings escape ' as ''. We don't
        # interpolate anything else.
        ps_url = dashboard_url.replace("'", "''")

        raw = script.read_text(encoding="utf-8")
        # Override the script's default ``$DashboardUrl = ''`` so the
        # operator doesn't have to pass anything. We rewrite the
        # CmdletBinding param block in-place.
        templated = raw.replace(
            "[string]$DashboardUrl = ''",
            f"[string]$DashboardUrl = '{ps_url}'",
            1,
        )

        return PlainTextResponse(
            content=templated,
            media_type="text/plain; charset=utf-8",
            headers={
                "Cache-Control": "no-store, no-cache, must-revalidate",
                "Content-Disposition": 'attachment; filename="install-rdp-handler.ps1"',
            },
        )

    @app.get("/agent/install.ps1", include_in_schema=False)
    async def serve_bench_installer(request: Request, token: str | None = None):
        """Render the PowerShell installer with this server's base URL and the shared token."""
        from fastapi.responses import Response as _Response
        from starlette.responses import PlainTextResponse

        s = get_settings()
        expected = (s.bench_agent_token or "").strip()
        if not expected:
            return PlainTextResponse(
                "RDD_BENCH_AGENT_TOKEN is not set on the dashboard server.",
                status_code=503,
            )
        if token != expected:
            return PlainTextResponse(
                "Invalid token. Pass ?token=<RDD_BENCH_AGENT_TOKEN> on the URL.",
                status_code=401,
            )
        ps_file = _AGENT_DATA / "bench_install.ps1"
        if not ps_file.is_file():
            return _Response(status_code=404, content="installer not bundled")
        body = ps_file.read_text(encoding="utf-8")
        base_url = str(request.base_url).rstrip("/")
        body = body.replace("{{DASHBOARD_URL}}", base_url)
        body = body.replace("{{TOKEN}}", expected)
        return PlainTextResponse(
            body,
            media_type="text/plain",
            headers={"Cache-Control": "no-store"},
        )

    @app.get("/health")
    async def health(x_admin_pin: str | None = Header(default=None)) -> dict:
        """Lightweight health probe.

        2.13+ scrubs the on-disk paths (``config_dir``, ``.env`` /
        ``admin.env`` / ``database_file``) from the anonymous response —
        anyone on the LAN could previously map the dashboard's
        filesystem layout via this endpoint. Pass the admin PIN via
        ``X-Admin-PIN`` to see the full diagnostic payload.
        """
        import hmac as _hmac

        from remote_desktop_dashboard.services.poller import get_poller_stats

        s = get_settings()
        from remote_desktop_dashboard.services.rdp_launch import find_msrdc_exe

        from remote_desktop_dashboard.services.monitor_credentials import (
            credentials_hint,
            resolve_monitor_credentials,
        )

        msrdc = find_msrdc_exe()
        creds = resolve_monitor_credentials()
        from remote_desktop_dashboard.paths import resolve_database_file, resolve_data_dir

        from remote_desktop_dashboard.config import permissions_dict

        required_pin = (s.admin_pin or "").strip()
        supplied_pin = (x_admin_pin or "").strip()
        is_admin = bool(
            required_pin
            and supplied_pin
            and _hmac.compare_digest(supplied_pin, required_pin)
        )
        out: dict = {
            "status": "ok",
            "version": __version__,
            "poller": get_poller_stats(),
            "poller_enabled": s.poller_enabled,
            "reachability_check": s.reachability_check,
            "monitor_configured": creds is not None,
            "monitor_hint": None if creds else credentials_hint(),
            "local_launcher_enabled": s.local_launcher_enabled,
            "local_launcher_port": s.local_launcher_port,
            "msrdc_on_server": str(msrdc) if msrdc else None,
            "agentless": True,
            **permissions_dict(),
        }
        if is_admin or not required_pin:
            # No admin PIN configured = single-trust deployment, so the
            # info isn't sensitive. With a PIN set we only show paths to
            # the verified admin.
            data_dir = s.config_directory
            out.update(
                {
                    "data_dir": str(resolve_data_dir()),
                    "config_dir": str(data_dir),
                    "user_env_file": str(data_dir / ".env"),
                    "admin_env_file": str(data_dir / "admin.env"),
                    "database_file": str(resolve_database_file()),
                }
            )
        return out

    return app


app = create_app()
