"""Backend API operations for Traigent Cloud Client.

This module contains methods for interacting with the backend API endpoints,
including session creation, status updates, and configuration run management.
"""

# Traceability: CONC-Layer-Infra CONC-Quality-Reliability FUNC-CLOUD-HYBRID FUNC-AGENTS REQ-CLOUD-009 REQ-AGNT-013

import time
from typing import TYPE_CHECKING, Any, cast
from urllib.parse import urlparse

from traigent.cloud.auth import AuthenticationError
from traigent.cloud.client import CloudServiceError
from traigent.cloud.models import (
    AgentExecutionRequest,
    AgentExecutionResponse,
    AgentOptimizationRequest,
    AgentOptimizationResponse,
    DatasetSubsetIndices,
    NextTrialRequest,
    NextTrialResponse,
    OptimizationSessionStatus,
    SessionCreationRequest,
    SessionCreationResponse,
    TrialResultSubmission,
    TrialSuggestion,
)
from traigent.config.backend_config import BackendConfig
from traigent.utils.env_config import is_backend_offline
from traigent.utils.exceptions import MetricExtractionError
from traigent.utils.logging import get_logger
from traigent.utils.validation import validate_numeric_metric

# Optional aiohttp dependency handling
try:
    import aiohttp

    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False

    class _AiohttpPlaceholder:
        """Minimal placeholder to satisfy type references when aiohttp missing."""

        class ClientConnectorError(RuntimeError):
            pass

        class ClientError(RuntimeError):
            pass

        _AIOHTTP_MISSING_MSG = "aiohttp is not installed"

        class ClientTimeout:  # pragma: no cover - placeholder
            def __init__(self, *args: Any, **kwargs: Any) -> None:
                raise RuntimeError(_AiohttpPlaceholder._AIOHTTP_MISSING_MSG)

        class TCPConnector:  # pragma: no cover - placeholder
            def __init__(self, *args: Any, **kwargs: Any) -> None:
                raise RuntimeError(_AiohttpPlaceholder._AIOHTTP_MISSING_MSG)

        class ClientSession:  # pragma: no cover - placeholder
            def __init__(self, *args: Any, **kwargs: Any) -> None:
                raise RuntimeError(_AiohttpPlaceholder._AIOHTTP_MISSING_MSG)

    aiohttp = _AiohttpPlaceholder()

# Content-Type header for JSON requests
_JSON_CONTENT_TYPE = "application/json"

if TYPE_CHECKING:
    from traigent.cloud.backend_client import BackendIntegratedClient

logger = get_logger(__name__)


class ApiOperations:
    """Handles backend API operations."""

    def __init__(self, client: "BackendIntegratedClient"):
        """Initialize API operations handler.

        Args:
            client: Parent BackendIntegratedClient instance
        """
        self.client = client

    def validate_and_sanitize_url(self, url: str) -> str:
        """Validate and sanitize URL to prevent injection attacks.

        Args:
            url: URL to validate

        Returns:
            Sanitized URL

        Raises:
            ValueError: If URL is invalid or uses unsafe scheme
        """
        if not url:
            raise ValueError("URL cannot be empty") from None

        # Strip whitespace to prevent CVE-2023-24329 bypass on older Python
        url = url.strip()

        # Parse URL
        parsed = urlparse(url)

        # Validate scheme
        allowed_schemes = {"http", "https"}
        if parsed.scheme not in allowed_schemes:
            raise ValueError(
                f"URL scheme must be one of {allowed_schemes}, got {parsed.scheme}"
            )

        # Validate host
        if not parsed.netloc:
            raise ValueError("URL must have a valid host")

        # Check for localhost/private IPs only in development
        if parsed.hostname:
            hostname = parsed.hostname.lower()
            # Allow localhost for development but provide helpful context
            if hostname in ["localhost", "127.0.0.1", "::1"]:
                logger.info(f"🔧 Using local backend URL: {url}")
                logger.info("💡 Traigent is configured for local development mode")
            # Block other private IP ranges
            elif (
                hostname.startswith("192.168.")
                or hostname.startswith("10.")
                or hostname.startswith("172.")
            ):
                logger.warning(f"Using private IP address: {hostname}")

        # Reconstruct clean URL without fragments or unnecessary components
        clean_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
        if parsed.query:
            clean_url += f"?{parsed.query}"

        return clean_url.rstrip("/")

    def map_to_backend_status(self, status: str) -> str:
        """Map Traigent status values to backend-expected values.

        Traigent uses lowercase (pending, completed, failed)
        Backend expects uppercase (CREATED, ACTIVE, COMPLETED, FAILED, PRUNED)

        Note: PRUNED is a success case (early stopping for efficiency).
        CANCELLED indicates the trial was abandoned before execution.
        """
        status_mapping = {
            "pending": "ACTIVE",
            "running": "ACTIVE",
            "in_progress": "ACTIVE",
            "completed": "COMPLETED",
            "failed": "FAILED",
            "not_started": "CREATED",
            # Pruned is early stopping (success case)
            "pruned": "PRUNED",
            # Cancelled means trial didn't execute
            "cancelled": "CANCELLED",
            # Also handle if already uppercase
            "PENDING": "ACTIVE",
            "IN_PROGRESS": "ACTIVE",
            "COMPLETED": "COMPLETED",
            "FAILED": "FAILED",
            "CREATED": "CREATED",
            "ACTIVE": "ACTIVE",
            "PRUNED": "PRUNED",
            "CANCELLED": "CANCELLED",
        }
        return status_mapping.get(status, status.upper())

    def sanitize_error_message(self, error_message: str | None) -> str | None:
        """Sanitize error message for transmission.

        Args:
            error_message: Raw error message

        Returns:
            Sanitized error message or None
        """
        if not error_message:
            return None

        # Remove sensitive information patterns
        import re

        # Remove potential secrets/tokens
        sanitized = re.sub(
            r"(api[_-]?key|token|secret|password)[\s=:]+[\w-]+",
            "[REDACTED]",
            error_message,
            flags=re.IGNORECASE,
        )

        # Remove file paths that might contain user info
        sanitized = re.sub(r"/home/[\w/.-]+", "[PATH]", sanitized)
        sanitized = re.sub(r"/Users/[\w/.-]+", "[PATH]", sanitized)

        # Truncate if too long
        max_length = 1000
        if len(sanitized) > max_length:
            sanitized = sanitized[:max_length] + "... [truncated]"

        return sanitized

    async def create_traigent_session_via_api(
        self, session_request: SessionCreationRequest
    ) -> tuple[str, str, str]:
        """Create a Traigent optimization session using the new session endpoints.

        Returns:
            Tuple of (session_id, experiment_id, experiment_run_id)
        """
        # Skip cloud session creation if backend is offline
        # Note: is_backend_offline() returns True if TRAIGENT_OFFLINE_MODE=true
        if is_backend_offline():
            logger.debug("Backend offline: using local session IDs")
            return (
                f"mock_session_{int(time.time())}",
                f"mock_exp_{int(time.time())}",
                f"mock_run_{int(time.time())}",
            )

        if not AIOHTTP_AVAILABLE:
            logger.warning("aiohttp not available, using fallback IDs")
            return (
                f"session_{int(time.time())}",
                f"exp_{int(time.time())}",
                f"run_{int(time.time())}",
            )

        try:
            max_trials_value = self._resolve_max_trials(session_request)
            session_payload = self._build_session_payload(
                session_request, max_trials_value
            )
            connector = self._build_connector()
            headers = await self.client.auth_manager.augment_headers(
                {"Content-Type": _JSON_CONTENT_TYPE}
            )
            return await self._post_session_creation(
                session_payload, headers, connector
            )
        except aiohttp.ClientConnectorError as e:
            self._handle_connector_error(e)
        except aiohttp.ClientError as e:
            self._handle_client_error(e)
        except Exception as e:
            self._handle_generic_session_exception(e)
        raise CloudServiceError("Unexpected session creation failure")

    def _resolve_max_trials(self, session_request: SessionCreationRequest) -> int:
        """Resolve max trials with logging when falling back to default."""

        value = session_request.max_trials
        if value is None:
            logger.debug("max_trials is None in session_request, using default 10")
            return 10
        return value

    def _build_session_payload(
        self, session_request: SessionCreationRequest, max_trials: int
    ) -> dict[str, Any]:
        """Build the payload sent to the cloud session creation endpoint."""

        metadata = session_request.metadata or {}
        evaluation_set = metadata.get("evaluation_set", "default")

        return {
            "problem_statement": session_request.function_name,
            "dataset": {
                "examples": [],  # Privacy mode - no actual data sent
                "metadata": session_request.dataset_metadata,
            },
            "search_space": session_request.configuration_space,
            "optimization_config": {
                "algorithm": "grid",
                "max_trials": max_trials,
                "optimization_goal": (
                    session_request.objectives[0]
                    if session_request.objectives
                    else "maximize"
                ),
            },
            "metadata": {
                "function_name": session_request.function_name,
                "evaluation_set": evaluation_set,
                **metadata,
            },
        }

    def _build_connector(self) -> Any | None:
        """Create an aiohttp connector when custom transport settings are required."""

        return None

    async def _post_session_creation(
        self,
        payload: dict[str, Any],
        headers: dict[str, str],
        connector: Any | None,
    ) -> tuple[str, str, str]:
        """Send the session creation request and handle responses."""

        async with cast(Any, aiohttp).ClientSession(connector=connector) as session:
            api_base = (
                self.client.backend_config.api_base_url
                or BackendConfig.get_backend_api_url()
            )
            url = f"{api_base}/sessions"
            timeout = cast(Any, aiohttp).ClientTimeout(total=30)

            async with session.post(
                url,
                json=payload,
                headers=headers,
                timeout=timeout,
            ) as response:
                if response.status == 201:
                    return await self._parse_session_response(response)

                error_msg = await response.text()
                self._handle_session_error(response.status, error_msg)

        raise CloudServiceError("Unexpected session creation failure")

    async def _parse_session_response(self, response: Any) -> tuple[str, str, str]:
        """Parse the JSON success payload returned by the session endpoint."""

        result = await response.json()
        session_id = result.get("session_id")
        experiment_id = result.get("metadata", {}).get("experiment_id", session_id)
        experiment_run_id = result.get("metadata", {}).get(
            "experiment_run_id", session_id
        )

        logger.info(
            f"✅ Created Traigent session: {session_id} "
            f"(exp: {experiment_id}, run: {experiment_run_id})"
        )
        return session_id, experiment_id, experiment_run_id

    def _handle_session_error(self, status_code: int, error_msg: str) -> None:
        """Raise structured exceptions for non-success HTTP responses.

        All logging is DEBUG — user-facing warnings are emitted by
        ``BackendSessionManager.handle_session_creation_result()``.
        """
        if status_code in (401, 403):
            logger.debug("Backend auth failed: %s", status_code)
            raise AuthenticationError(f"Authentication failed ({status_code})")

        if status_code in (500, 502, 503, 504):
            logger.debug("Backend HTTP error: %s", status_code)
            raise CloudServiceError(f"Backend HTTP {status_code}")

        logger.debug("Backend session error: %s - %s", status_code, error_msg[:200])
        raise CloudServiceError(f"Session creation failed: HTTP {status_code}")

    def _handle_connector_error(self, error: aiohttp.ClientConnectorError) -> None:
        """Handle aiohttp connector errors — DEBUG only."""
        logger.debug("Backend connection failed: %s", error)
        raise CloudServiceError("Backend unavailable (connection failed)") from error

    def _handle_client_error(self, error: aiohttp.ClientError) -> None:
        """Handle generic aiohttp client errors — DEBUG only."""
        logger.debug("Network error connecting to backend: %s", error)
        raise CloudServiceError(f"Network error: {error}") from error

    def _handle_generic_session_exception(self, error: Exception) -> None:
        """Handle unexpected exceptions during session creation — DEBUG only."""
        logger.debug("Unexpected error creating session: %s", error)
        raise CloudServiceError(f"Session creation failed: {error}") from error

    async def update_config_run_status(self, config_run_id: str, status: str) -> bool:
        """Update configuration run status in the backend.

        Args:
            config_run_id: Configuration run ID (same as trial_id)
            status: Status to set (COMPLETED, FAILED, etc.)

        Returns:
            True if successful, False otherwise
        """
        if not AIOHTTP_AVAILABLE:
            return False

        try:
            connector = self._build_connector()

            # Prepare headers with API key
            headers = await self.client.auth_manager.augment_headers(
                {"Content-Type": _JSON_CONTENT_TYPE}
            )

            async with cast(Any, aiohttp).ClientSession(connector=connector) as session:
                api_base = (
                    self.client.backend_config.api_base_url
                    or BackendConfig.get_backend_api_url()
                )
                url = f"{api_base}/configuration-runs/{config_run_id}/status"
                status_data = {"status": status}

                async with session.put(
                    url,
                    json=status_data,
                    headers=headers,
                    timeout=cast(Any, aiohttp).ClientTimeout(total=10),
                ) as response:
                    if response.status in [200, 204]:
                        logger.debug(
                            f"Updated configuration run {config_run_id} status to {status}"
                        )
                        return True
                    else:
                        error_msg = await response.text()
                        logger.debug(
                            f"Failed to update config run status: {response.status} - {error_msg[:100]}"
                        )
                        return False

        except Exception as e:
            logger.debug(f"Error updating config run status: {e}")
            return False

    async def update_config_run_measures(
        self,
        config_run_id: str,
        metrics: dict[str, float],
        execution_time: float | None = None,
    ) -> bool:
        """Update configuration run measures in the backend.

        Args:
            config_run_id: Configuration run ID (same as trial_id)
            metrics: Metrics to convert to measures
            execution_time: Optional execution time in seconds

        Returns:
            True if successful, False otherwise
        """
        if not AIOHTTP_AVAILABLE or not metrics:
            return False

        try:
            # Convert metrics to backend measures format per Traigent schema
            # Map Traigent metrics to standard measure IDs
            mapped_metrics = {}

            # Standard Traigent measure mappings with strict validation
            if "accuracy" in metrics and metrics["accuracy"] is not None:
                try:
                    mapped_metrics["accuracy"] = validate_numeric_metric(
                        metrics["accuracy"],
                        field_name="accuracy",
                        trial_id=config_run_id,
                    )
                except MetricExtractionError as e:
                    logger.error(
                        f"Invalid 'accuracy' metric for config run {config_run_id}: {e.message}",
                        extra={
                            "hint": "Ensure your evaluation function returns numeric values for 'accuracy'. "
                            "Check that the value is not None, NaN, or Inf.",
                            "config_run_id": config_run_id,
                            "field": "accuracy",
                            "value": metrics["accuracy"],
                        },
                    )
                    return False

            if "score" in metrics and metrics["score"] is not None:
                try:
                    mapped_metrics["score"] = validate_numeric_metric(
                        metrics["score"],
                        field_name="score",
                        trial_id=config_run_id,
                    )
                except MetricExtractionError as e:
                    logger.error(
                        f"Invalid 'score' metric for config run {config_run_id}: {e.message}",
                        extra={
                            "hint": "Ensure your evaluation function returns numeric values for 'score'. "
                            "Check that the value is not None, NaN, or Inf.",
                            "config_run_id": config_run_id,
                            "field": "score",
                            "value": metrics["score"],
                        },
                    )
                    return False
            elif (
                "accuracy" in metrics and metrics["accuracy"] is not None
            ):  # Use accuracy as score if no explicit score
                mapped_metrics["score"] = mapped_metrics["accuracy"]

            # Include other standard measures if present
            for key in [
                "faithfulness",
                "relevance",
                "latency",
                "cost",
                "context_precision",
                "context_recall",
            ]:
                if key in metrics and metrics[key] is not None:
                    try:
                        mapped_metrics[key] = validate_numeric_metric(
                            metrics[key],
                            field_name=key,
                            trial_id=config_run_id,
                        )
                    except MetricExtractionError as e:
                        logger.error(
                            f"Invalid '{key}' metric for config run {config_run_id}: {e.message}",
                            extra={
                                "hint": f"Ensure your evaluation function returns numeric values for '{key}'. "
                                "Check that the value is not None, NaN, or Inf.",
                                "config_run_id": config_run_id,
                                "field": key,
                                "value": metrics[key],
                            },
                        )
                        return False

            # Include any other metrics as-is, ensuring they are numeric
            for key, value in metrics.items():
                if key not in mapped_metrics and value is not None:
                    try:
                        mapped_metrics[key] = validate_numeric_metric(
                            value,
                            field_name=key,
                            trial_id=config_run_id,
                        )
                    except MetricExtractionError as e:
                        logger.error(
                            f"Invalid '{key}' metric for config run {config_run_id}: {e.message}",
                            extra={
                                "hint": f"Ensure your evaluation function returns numeric values for '{key}'. "
                                "Check that the value is not None, NaN, or Inf. "
                                "Custom metrics must be numeric types (int, float).",
                                "config_run_id": config_run_id,
                                "field": key,
                                "value": value,
                            },
                        )
                        return False

            # Build measures data in schema-compliant array format
            # Per configuration_run_schema.json, measures must be array of MeasureResult objects
            # Type: dict[str, list[dict[str, float]] | None]
            measures_data: dict[str, list[dict[str, float]] | None]
            if mapped_metrics:
                measure_result = dict(mapped_metrics)
                measures_data = {"measures": [measure_result]}
            else:
                # Omit measures if empty (per schema - use null or omit when no results)
                measures_data = {"measures": None}

            # Add execution time to workflow_metadata when backend supports it
            # TODO: Once backend adds workflow_metadata field, send via that endpoint
            if execution_time is not None:
                logger.debug(
                    f"execution_time={execution_time} should be sent via workflow_metadata field "
                    f"(not yet supported by backend). Skipping for now."
                )

            connector = self._build_connector()

            # Prepare headers with API key
            headers = await self.client.auth_manager.augment_headers(
                {"Content-Type": _JSON_CONTENT_TYPE}
            )

            async with cast(Any, aiohttp).ClientSession(connector=connector) as session:
                api_base = (
                    self.client.backend_config.api_base_url
                    or BackendConfig.get_backend_api_url()
                )
                url = f"{api_base}/configuration-runs/{config_run_id}/measures"

                async with session.put(
                    url,
                    json=measures_data,
                    headers=headers,
                    timeout=cast(Any, aiohttp).ClientTimeout(total=10),
                ) as response:
                    if response.status == 200:
                        logger.debug(
                            f"Updated configuration run {config_run_id} with {len(mapped_metrics)} measures"
                        )
                        return True
                    else:
                        error_msg = await response.text()
                        logger.debug(
                            f"Failed to update config run measures: {response.status} - {error_msg[:100]}"
                        )
                        return False

        except Exception as e:
            logger.debug(f"Error updating config run measures: {e}")
            return False

    async def update_experiment_run_status_on_completion(
        self, experiment_run_id: str, status: str
    ) -> None:
        """Update experiment run status when session is finalized.

        Args:
            experiment_run_id: Experiment run ID
            status: Status to set (COMPLETED, FAILED, etc.)
        """
        if not AIOHTTP_AVAILABLE:
            logger.debug("aiohttp not available, skipping experiment run status update")
            return

        try:
            # Map SDK status to backend status using the standard mapping
            backend_status = self.map_to_backend_status(status)

            # Valid experiment run statuses that the backend should accept
            # Note: PRUNED and CANCELLED are valid trial outcomes that the backend
            # needs to support. If backend shows these as "UNKNOWN", the backend
            # needs to be updated to recognize these statuses.
            valid_statuses = [
                "COMPLETED",
                "FAILED",
                "RUNNING",
                "NOT_STARTED",
                "ACTIVE",
                "CREATED",
                "PRUNED",
                "CANCELLED",
            ]
            if backend_status not in valid_statuses:
                logger.warning(
                    f"Unexpected status '{status}' (mapped to '{backend_status}'), "
                    f"using COMPLETED as default"
                )
                backend_status = "COMPLETED"

            # Prepare headers with API key
            headers = await self.client.auth_manager.augment_headers(
                {"Content-Type": _JSON_CONTENT_TYPE}
            )

            connector = self._build_connector()

            async with cast(Any, aiohttp).ClientSession(connector=connector) as session:
                api_base = (
                    self.client.backend_config.api_base_url
                    or BackendConfig.get_backend_api_url()
                )
                url = f"{api_base}/experiment-runs/runs/{experiment_run_id}"

                async with session.put(
                    url,
                    json={"status": backend_status},
                    headers=headers,
                    timeout=cast(Any, aiohttp).ClientTimeout(total=10),
                ) as response:
                    if response.status in [200, 204]:
                        logger.info(
                            f"✅ Updated experiment run {experiment_run_id} to status {backend_status}"
                        )
                    else:
                        error_text = await response.text()
                        logger.warning(
                            f"Failed to update experiment run status (HTTP {response.status}): {error_text}"
                        )
        except Exception as e:
            logger.warning(f"Error updating experiment run status: {e}")

    # Cloud API Methods

    async def create_cloud_session(
        self, request: SessionCreationRequest
    ) -> SessionCreationResponse:
        """Create cloud session for optimization.

        Mock implementation for now - would connect to actual cloud API.
        """
        logger.debug("Creating cloud session (mock implementation)")

        # Mock response
        return SessionCreationResponse(
            session_id=f"cloud_session_{int(time.time())}",
            status=OptimizationSessionStatus.CREATED,
            optimization_strategy=request.optimization_strategy or {},
            metadata={
                "created_at": time.time(),
                "billing_tier": request.billing_tier,
            },
        )

    async def get_cloud_trial_suggestion(
        self, request: NextTrialRequest
    ) -> NextTrialResponse:
        """Get next trial suggestion from cloud optimizer.

        Mock implementation for now - would connect to actual cloud API.
        """
        logger.debug("Getting cloud trial suggestion (mock implementation)")

        # Mock response - no suggestion means optimization is complete
        suggestion = TrialSuggestion(
            trial_id=f"trial_{int(time.time())}",
            session_id=request.session_id,
            trial_number=1,
            config={"param": 0},
            dataset_subset=DatasetSubsetIndices(
                indices=[0],
                selection_strategy="mock",
                confidence_level=0.9,
                estimated_representativeness=0.9,
            ),
            exploration_type="exploration",
        )

        return NextTrialResponse(
            suggestion=suggestion,
            should_continue=True,
            session_status=OptimizationSessionStatus.ACTIVE,
            metadata={
                "mock": True,
                "session_id": request.session_id,
            },
        )

    async def submit_cloud_trial_results(
        self, submission: TrialResultSubmission
    ) -> None:
        """Submit trial results to cloud service.

        Mock implementation for now - would connect to actual cloud API.
        """
        logger.debug(f"Submitting cloud trial results for {submission.trial_id} (mock)")
        # Mock implementation - just log
        pass

    async def submit_agent_optimization(
        self, request: AgentOptimizationRequest
    ) -> AgentOptimizationResponse:
        """Submit agent for cloud optimization.

        Mock implementation for now - would connect to actual cloud API.
        """
        agent_name = getattr(request.agent_spec, "name", "unknown")
        logger.debug(f"Submitting agent optimization for {agent_name} (mock)")

        # Mock response
        return AgentOptimizationResponse(
            session_id=f"agent_session_{int(time.time())}",
            optimization_id=f"opt_{int(time.time())}",
            status="started",
            estimated_duration=300.0,
            next_steps=["await_results"],
        )

    async def execute_cloud_agent(
        self, request: AgentExecutionRequest
    ) -> AgentExecutionResponse:
        """Execute agent in cloud.

        Mock implementation for now - would connect to actual cloud API.
        """
        agent_name = getattr(request.agent_spec, "name", "unknown")
        logger.debug(f"Executing cloud agent {agent_name} (mock)")

        # Mock response
        return AgentExecutionResponse(
            output="Mock agent response",
            duration=1.5,
            tokens_used=50,
            cost=0.001,
            metadata={
                "status": "COMPLETED",
                "session_id": getattr(request.agent_spec, "id", "mock_session"),
            },
        )

    # Deprecated methods that should not be used

    async def create_backend_experiment_tracking(
        self, session_request: SessionCreationRequest
    ) -> tuple[str, str]:
        """DEPRECATED: This method should not be used anymore.

        The SDK should only use session endpoints.
        This method is kept for backward compatibility but should be removed.
        """
        logger.error(
            "⚠️ DEPRECATED: create_backend_experiment_tracking called. SDK should only use session endpoints!"
        )
        raise NotImplementedError(
            "SDK must use session endpoints only. Direct experiment creation is not allowed."
        )

    async def create_backend_agent_experiment(
        self,
        agent_spec: Any,
        dataset: Any,
        configuration_space: dict[str, Any],
        objectives: list[str],
        max_trials: int,
    ) -> tuple[str, str]:
        """DEPRECATED: This method should not be used anymore.

        The SDK should only use session endpoints.
        Backend handles agent and experiment creation internally.
        """
        logger.error(
            "⚠️ DEPRECATED: create_backend_agent_experiment called. SDK should only use session endpoints!"
        )
        raise NotImplementedError(
            "SDK must use session endpoints only. Direct agent/experiment creation is not allowed."
        )
