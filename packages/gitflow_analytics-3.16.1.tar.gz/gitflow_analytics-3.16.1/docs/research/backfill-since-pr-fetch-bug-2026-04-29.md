# Research: `--backfill-since` Not Fetching PRs Older Than ~2025-11-13

**Date**: 2026-04-29  
**Investigator**: Research Agent  
**Symptom**: `gfa fetch --backfill-since 2025-11-01` with 186 repos leaves `pull_request_cache` with PRs only from 2025-11-13 onward, despite the gate fix in `_get_incremental_fetch_date()`.

---

## Call Chain (Verified)

```
cli_fetch.py:fetch()
  → start_date is set to backfill_since_dt (2025-11-01) when it is earlier than the weeks window  [line 271]
  → data_fetcher.fetch_repository_data(start_date=start_date, ...)  [line 319]
      [commits only — no PR enrichment here]
  → orchestrator.enrich_repository_data(
        repo_config, commits_for_enrichment,
        since=start_date,            ← "since" arg = start_date = 2025-11-01
        backfill_since=backfill_since_dt  ← backfill_since = 2025-11-01
    )  [line 378-383]
      → github_integration.enrich_repository_with_prs(
            repo_name, commits,
            since=start_date,            ← 2025-11-01
            backfill_since=backfill_since_dt  ← 2025-11-01
        )  [orchestrator.py line 318-323]
          → _get_incremental_fetch_date(
                "github", since=2025-11-01,
                config, force_since=2025-11-01
            )  → returns 2025-11-01   [github_integration.py line 169-171]
          → fetch_since = 2025-11-01  ✓ correct
          → _get_cached_prs_bulk(repo_name, fetch_since=2025-11-01)
          → _get_pull_requests(repo, since=2025-11-01)  ✓ correct date reaches PyGitHub
```

`backfill_since_dt` IS correctly reaching `_get_pull_requests()`. The date is not being lost at any parameter-passing step.

---

## Root Cause Analysis — Three Distinct Bugs

### Bug 1 (PRIMARY): `_get_pull_requests` break condition silently stops too early

**File**: `src/gitflow_analytics/integrations/github_integration.py`  
**Lines**: 492–507

```python
for pr in repo.get_pulls(state="all", sort="updated", direction="desc"):
    if pr.updated_at < since:
        break                         # ← PROBLEM: stops entire pagination

    if pr.merged and pr.merged_at >= since:
        prs.append(pr)
    elif (
        not pr.merged
        and pr.state == "closed"
        and pr.closed_at
        and pr.closed_at >= since
    ):
        prs.append(pr)
```

**Mechanism of failure**:

GitHub's `get_pulls(sort="updated", direction="desc")` returns PRs in descending order of their `updated_at` timestamp. A PR can be "updated" by:
- Comments added after merge
- Labels changed
- Reviews added
- Status checks updating

This creates a specific failure scenario:

```
PR #A: merged 2025-10-15, but someone added a comment on 2025-11-14
       → updated_at=2025-11-14 >= since=2025-11-01 → NOT broken
       → merged_at=2025-10-15 < since=2025-11-01 → SKIPPED (correct)

PR #B: merged 2025-11-13, no activity after merge
       → updated_at=2025-11-13 >= since=2025-11-01 → NOT broken
       → merged_at=2025-11-13 >= since=2025-11-01 → INCLUDED

PR #C: merged 2025-11-12, no activity after merge
       → updated_at=2025-11-12 >= since=2025-11-01 → NOT broken
       → INCLUDED

... eventually ...

PR #N: merged 2025-10-28, no post-merge activity
       → updated_at=2025-10-28 < since=2025-11-01 → BREAK

[All PRs merged between 2025-11-01 and the last PR before PR #N are NEVER seen]
```

The early `break` at `pr.updated_at < since` means that once any PR with no post-merge activity is encountered, the entire pagination is aborted — regardless of how many unvisited PRs from the target window remain.

**Why 2025-11-13 specifically**: The user's data pattern suggests that the first PR with `updated_at < 2025-11-01` appeared in the pagination stream just after PRs whose `updated_at` was around 2025-11-13. PRs merged between 2025-11-01 and 2025-11-12 that had no post-merge activity triggered the `break` and terminated pagination, losing all PRs merged before those quiet ones but within the target window.

**Fix required**: Replace the hard `break` with a `continue` (or refactor to not rely on this signal). Since PRs are sorted by `updated_at` descending, there can be an interleaving: a recently-commented old PR can appear before a newer but quiet PR in the stream. The `break` is only safe when you know the remaining pages will all have `updated_at < since`. The correct approach:

```python
# Option A: continue instead of break (scan all, slower but correct)
if pr.updated_at < since:
    continue   # don't break — later pages may have post-since activity

# Option B: track a "pages_past_window" counter to limit over-scanning
# Option C: fetch by merged_at via GraphQL instead of REST sort=updated
```

Option A is safe because `cache_pr()` is idempotent and `_get_cached_prs_bulk` already deduplicated against the cache.

However, Option A means scanning ALL PRs for every backfill — expensive for repos with thousands of PRs. Option C (GraphQL with `mergedAt` filter) is the correct long-term fix.

---

### Bug 2 (SECONDARY): `_get_cached_prs_bulk` date filter uses `merged_at OR created_at`, not `updated_at`

**File**: `src/gitflow_analytics/integrations/github_integration.py`  
**Lines**: 368–379

```python
cached_results = (
    session.query(PullRequestCache)
    .filter(
        PullRequestCache.repo_path == repo_name,
        or_(
            PullRequestCache.merged_at >= since_naive,
            PullRequestCache.created_at >= since_naive,
        ),
    )
    .all()
)
```

This query correctly returns PRs merged or created on/after `since`. However, it means PRs that were merged BEFORE `since` (which `_get_pull_requests` skips due to `pr.merged_at >= since`) are also absent from the cache read. So even after Bug 1 is fixed, the cache lookup correctly returns nothing for pre-`since` PRs — but that is by design (the cache only stores PRs for the requested window, not all-time).

This is not directly a bug but confirms the cache layer is consistent with the fetch layer — both exclude pre-`since` PRs.

---

### Bug 3 (TERTIARY): `schema_manager.mark_date_processed` uses `since` not `fetch_since`

**File**: `src/gitflow_analytics/integrations/github_integration.py`  
**Line**: 194

```python
if prs:
    self.schema_manager.mark_date_processed("github", since, github_config)
```

`since` here is the `since` parameter of `enrich_repository_with_prs()`, which in the backfill path is `start_date` (= `backfill_since_dt`). `fetch_since` (the value actually passed to `_get_pull_requests`) is the same in backfill mode, so this is not wrong in this specific path. But it would be wrong if `force_since` were ever different from `since` — the checkpoint would record `since` rather than the date that was actually fetched. Minor inconsistency but not the cause of the current symptom.

---

## Summary Table

| Bug | Location | Lines | Impact |
|-----|----------|-------|--------|
| **Primary** | `_get_pull_requests()` | 493–494 | `break` on `updated_at < since` stops pagination before all target-window PRs are seen |
| Secondary | `_get_cached_prs_bulk()` | 374–378 | Cache query excludes pre-`since` PRs — consistent with fetch, not independently breaking |
| Tertiary | `enrich_repository_with_prs()` | 194 | Checkpoint records `since` not `fetch_since` — minor inconsistency, not root cause |

---

## Exact Root Cause Statement

The `break` at line 493 of `github_integration.py` terminates the PyGitHub `get_pulls()` pagination the moment any PR appears whose `updated_at` is older than `since`. Because GitHub sorts by `updated_at descending`, a PR with no post-merge activity can appear in the stream before PRs that WERE merged within the target window but also have no post-merge activity. The moment such a "quiet" pre-window PR appears, iteration stops and all remaining PRs in the window (which would appear on subsequent pages) are never fetched.

The `--backfill-since 2025-11-01` fix correctly threads the date to `_get_pull_requests()`. The problem is that `_get_pull_requests()` itself cannot fully paginate the window because of the break-on-`updated_at` early exit.

---

## Fix Recommendation

**Minimal fix** (safe, may scan more API pages for large repos):

```python
# github_integration.py, _get_pull_requests(), line 493
# BEFORE:
if pr.updated_at < since:
    break

# AFTER:
if pr.updated_at < since:
    continue  # cannot break — old updated_at PRs may interleave with newer ones
```

**Better fix** (add a pagination safety valve to limit over-scanning):

```python
pages_past_window = 0
MAX_PAGES_PAST_WINDOW = 5  # configurable

for pr in repo.get_pulls(state="all", sort="updated", direction="desc"):
    if pr.updated_at < since:
        pages_past_window += 1
        if pages_past_window > MAX_PAGES_PAST_WINDOW:
            break
        continue
    else:
        pages_past_window = 0  # reset when we re-enter the window
    ...
```

**Long-term fix**: Use the GitHub GraphQL API with a `mergedAt` date filter instead of REST `sort=updated`. This gives exact results without pagination issues.

---

## Files Referenced

- `/Users/masa/Projects/gitflow-analytics/src/gitflow_analytics/cli_fetch.py` — lines 119-131, 238-271, 349-404
- `/Users/masa/Projects/gitflow-analytics/src/gitflow_analytics/integrations/github_integration.py` — lines 63-134 (`_get_incremental_fetch_date`), 136-260 (`enrich_repository_with_prs`), 345-434 (`_get_cached_prs_bulk`), 475-519 (`_get_pull_requests`)
- `/Users/masa/Projects/gitflow-analytics/src/gitflow_analytics/integrations/orchestrator.py` — lines 285-330 (`enrich_repository_data`)
- `/Users/masa/Projects/gitflow-analytics/src/gitflow_analytics/core/data_fetcher.py` — lines 120-171 (`fetch_repository_data`)
