"""Health check diagnostics for the CLI.

Feature #33: /doctor command — self-diagnostics to verify the CLI
environment is properly configured.
"""

from __future__ import annotations

import importlib.metadata
import logging
import os
import platform
import shutil
import sys
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import urlopen

logger = logging.getLogger(__name__)


def _normalize_ollama_host(raw_host: str | None) -> str:
    """Normalize Ollama host configuration into an HTTP base URL."""
    host = (raw_host or "").strip() or "http://127.0.0.1:11434"
    if "://" not in host:
        host = f"http://{host}"
    parsed = urlparse(host)
    scheme = parsed.scheme or "http"
    netloc = parsed.netloc or parsed.path
    path = parsed.path if parsed.netloc else ""
    return f"{scheme}://{netloc}{path}".rstrip("/")


def _get_ollama_version() -> str | None:
    """Return the Ollama daemon version when the local API is reachable."""
    base_url = _normalize_ollama_host(os.environ.get("OLLAMA_HOST"))
    try:
        with urlopen(f"{base_url}/api/version", timeout=1.5) as response:
            import json

            payload = json.loads(response.read().decode("utf-8"))
    except (HTTPError, URLError, TimeoutError, OSError, RuntimeError, ValueError):
        return None

    version = payload.get("version")
    return str(version).strip() if version else None


# Models that have been verified end-to-end with the bog-agents tool-call
# stack on Ollama. Add to this list as new candidates are validated.
_OLLAMA_KNOWN_GOOD = (
    "gpt-oss",
    # `mistral-nemo`, `hermes3`, and `qwen2.5-coder` partially work via the
    # ToolCallParserMiddleware text-format recovery; not on the known-good
    # list because recovery is best-effort and depends on prompt shape.
)


def _is_known_good_ollama_model(model: str) -> bool:
    """Return True if `model` is on the validated Ollama tool-call list."""
    name = model.lower()
    return any(prefix in name for prefix in _OLLAMA_KNOWN_GOOD)


def _read_default_ollama_model() -> str | None:
    """Read the user's configured default model and return it iff it's Ollama.

    Returns the bare model identifier (without the ``ollama:`` prefix), or
    ``None`` if no default is set or the default isn't an Ollama model.
    """
    try:
        from bog_agents_cli.model_config import ModelConfig
    except ImportError:
        return None
    try:
        cfg = ModelConfig.load()
    except (OSError, ValueError):
        return None
    spec = cfg.default_model or cfg.recent_model
    if not spec:
        return None
    spec_lower = spec.lower()
    if spec_lower.startswith("ollama:"):
        return spec.split(":", 1)[1] or None
    return None


def _bedrock_credential_status() -> tuple[str, str]:
    """Probe AWS credentials for the Bedrock provider and report their state.

    Walks boto3's standard credential chain (env, profile, SSO, instance
    role) without making a network call. Catches the common failure modes
    a Bedrock user hits at the CLI:

    - boto3 not installed (transitive dep of langchain-aws — should never
      happen but reported gracefully).
    - No credentials anywhere — points the user to ``aws configure``.
    - SSO session expired (TokenRetrievalError) — points the user to
      ``aws sso login``.
    - Credentials present but access_key empty — points at the profile.

    Returns:
        (status, detail) tuple where status is "OK"/"WARN"/"FAIL" and
        detail is a human-readable one-liner suitable for the doctor table.
    """
    try:
        import boto3  # type: ignore[import-untyped]
    except ImportError:
        return "WARN", "boto3 not installed (transitive of langchain-aws)"

    # botocore raises TokenRetrievalError when an SSO token has expired.
    # Map it to a clean actionable message instead of a stack trace.
    try:
        from botocore.exceptions import (  # type: ignore[import-untyped]
            NoCredentialsError,
            TokenRetrievalError,
        )
    except ImportError:
        # Older botocore — fall back to generic Exception
        class TokenRetrievalError(Exception):  # type: ignore[no-redef]
            pass

        class NoCredentialsError(Exception):  # type: ignore[no-redef]
            pass

    # If the runtime credential probe already saw a failure this session,
    # reuse its classification instead of triggering yet another expensive
    # boto3 SSO refresh attempt (which would log another full traceback —
    # issue #53). The cache only stores negative results; on success the
    # runtime probe clears it so this branch falls through.
    try:
        from bog_agents_cli.model_config import _BEDROCK_PROBE_CACHE

        if _BEDROCK_PROBE_CACHE:
            for kind, (_ok, detail) in _BEDROCK_PROBE_CACHE.items():
                if "sso-expired" in kind:
                    return (
                        "FAIL",
                        f"AWS SSO token expired — run `aws sso login` ({detail})",
                    )
                if "no-credentials" in kind:
                    return "WARN", "no AWS credentials found — run `aws configure`"
                return "FAIL", f"AWS credential probe error: {detail}"
    except ImportError:
        pass

    try:
        session = boto3.Session()
        creds = session.get_credentials()
        if creds is None:
            return "WARN", "no AWS credentials found — run `aws configure`"
        # `get_frozen_credentials()` is what triggers SSO token refresh,
        # and where TokenRetrievalError surfaces if the SSO session expired.
        frozen = creds.get_frozen_credentials()
        if not frozen.access_key:
            return "WARN", "AWS credentials resolved but access_key is empty"
        method = getattr(creds, "method", "?")
        return "OK", f"AWS credentials valid (source: {method})"
    except TokenRetrievalError as exc:
        return "FAIL", f"AWS SSO token expired — run `aws sso login` ({exc})"
    except NoCredentialsError:
        return "WARN", "no AWS credentials found — run `aws configure`"
    except Exception as exc:
        return "FAIL", f"AWS credential probe error: {type(exc).__name__}: {exc}"


def run_doctor() -> str:
    """Run comprehensive health checks and return a diagnostic report.

    Returns:
        Formatted diagnostic report string.
    """
    checks: list[tuple[str, str, str]] = []  # (name, status, detail)

    # 1. Python version
    py_version = (
        f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    if sys.version_info >= (3, 11):
        checks.append(("Python Version", "OK", py_version))
    else:
        checks.append(("Python Version", "WARN", f"{py_version} (3.11+ recommended)"))

    # 2. Platform info
    checks.append(
        (
            "Platform",
            "INFO",
            f"{platform.system()} {platform.release()} ({platform.machine()})",
        )
    )

    # 3. Package versions — critical runtime deps that the CLI imports
    # eagerly. A `MISSING` result here usually means an incomplete pip
    # install; `pip install --upgrade --force-reinstall bog-agents-cli`
    # is the recovery hint.
    for pkg_name in [
        "bog-agents",
        "langchain",
        "langchain-core",
        "langgraph",
        "langgraph-sdk",
        "langsmith",
        "httpx",
        "textual",
    ]:
        try:
            dist = importlib.metadata.distribution(pkg_name)
            checks.append((f"Package: {pkg_name}", "OK", dist.version))
        except importlib.metadata.PackageNotFoundError:
            checks.append((f"Package: {pkg_name}", "MISSING", "Not installed"))

    # 4. Provider packages
    providers = [
        ("langchain-anthropic", "ANTHROPIC_API_KEY"),
        ("langchain-openai", "OPENAI_API_KEY"),
        ("langchain-google-genai", "GOOGLE_API_KEY"),
        ("langchain-ollama", None),
        # Bedrock uses AWS credentials, not a single API key — handled below.
        ("langchain-aws", "__BEDROCK__"),
    ]
    for pkg, env_key in providers:
        try:
            dist = importlib.metadata.distribution(pkg)
            if env_key is None:
                status = "OK"
                detail = f"v{dist.version} (local provider)"
            elif env_key == "__BEDROCK__":
                status, bedrock_detail = _bedrock_credential_status()
                # Surface the resolved region alongside credential state so
                # users immediately see whether AWS_DEFAULT_REGION (or
                # `[models.providers.bedrock] region`) is set up.
                try:
                    from bog_agents_cli.model_config import resolve_aws_region

                    region = resolve_aws_region(fallback=None)
                except Exception:  # best-effort doctor field
                    region = None
                region_part = f"region={region}" if region else "region=UNRESOLVED"
                detail = f"v{dist.version} ({bedrock_detail}; {region_part})"
            else:
                has_key = bool(os.environ.get(env_key))
                status = "OK" if has_key else "WARN"
                detail = f"v{dist.version}" + (
                    " (API key set)" if has_key else f" ({env_key} not set)"
                )
            checks.append((f"Provider: {pkg}", status, detail))
        except importlib.metadata.PackageNotFoundError:
            checks.append((f"Provider: {pkg}", "SKIP", "Not installed (optional)"))

    # 5. CLI tools
    for tool, purpose in [
        ("git", "Version control"),
        ("ollama", "Local model runtime"),
        ("rg", "Fast text search (ripgrep)"),
        ("ruff", "Python linter"),
        ("uv", "Package manager"),
        ("node", "Node.js runtime"),
    ]:
        path = shutil.which(tool)
        if path:
            checks.append((f"Tool: {tool}", "OK", f"Found at {path}"))
        else:
            checks.append((f"Tool: {tool}", "WARN", f"Not found ({purpose})"))

    ollama_version = _get_ollama_version()
    if ollama_version:
        checks.append(("Ollama daemon", "OK", f"Reachable (v{ollama_version})"))

        # If the configured default is an Ollama model, hint about which one
        # actually engages tool calling reliably. Most non-OpenAI-trained
        # models emit tool calls in a text format that bog-agents now tries
        # to recover via ToolCallParserMiddleware, but recovery isn't 100%.
        default_model = _read_default_ollama_model()
        if default_model and not _is_known_good_ollama_model(default_model):
            checks.append(
                (
                    "Ollama default model",
                    "WARN",
                    f"'{default_model}' may not engage tool calls cleanly. "
                    "Recommended: 'gpt-oss:20b' (OpenAI tool-call format). "
                    "ToolCallParserMiddleware will try to recover Mistral/"
                    "Hermes/qwen text-shaped tool calls automatically.",
                )
            )
    elif shutil.which("ollama"):
        checks.append(
            (
                "Ollama daemon",
                "WARN",
                f"Not reachable at {_normalize_ollama_host(os.environ.get('OLLAMA_HOST'))}",
            )
        )
    else:
        checks.append(("Ollama daemon", "SKIP", "ollama not installed"))

    # 6. Sandbox support
    system = platform.system().lower()
    if system == "linux":
        if shutil.which("bwrap"):
            checks.append(("Sandbox: bubblewrap", "OK", "Available"))
        else:
            checks.append(
                (
                    "Sandbox: bubblewrap",
                    "WARN",
                    "Not installed (apt install bubblewrap)",
                )
            )
    elif system == "darwin":
        if shutil.which("sandbox-exec"):
            checks.append(("Sandbox: seatbelt", "OK", "Available"))
        else:
            checks.append(("Sandbox: seatbelt", "WARN", "Not available"))

    # 7. Config directory
    config_dir = Path.home() / ".bog-agents"
    if config_dir.exists():
        hooks_file = config_dir / "hooks.json"
        config_file = config_dir / "config.toml"
        checks.append(("Config dir", "OK", str(config_dir)))
        if hooks_file.exists():
            checks.append(("Hooks config", "OK", str(hooks_file)))
        if config_file.exists():
            checks.append(("Config file", "OK", str(config_file)))
    else:
        checks.append(
            ("Config dir", "INFO", f"{config_dir} (will be created on first use)")
        )

    # 8. Environment variables
    env_checks = [
        "LANGSMITH_API_KEY",
        "LANGSMITH_PROJECT",
        "BOG_AGENTS_LANGSMITH_PROJECT",
    ]
    for env_var in env_checks:
        value = os.environ.get(env_var)
        if value:
            # Mask the value
            masked = value[:4] + "..." + value[-4:] if len(value) > 8 else "***"
            checks.append((f"Env: {env_var}", "OK", masked))
        else:
            checks.append((f"Env: {env_var}", "SKIP", "Not set"))

    # 9. MCP config
    mcp_config = Path.cwd() / ".mcp.json"
    if mcp_config.exists():
        checks.append(("MCP config", "OK", str(mcp_config)))
    else:
        checks.append(("MCP config", "SKIP", "No .mcp.json in current directory"))

    # 9b. MCP trust state — does the project's MCP config currently match a
    # trusted fingerprint? Surface this so users know whether stdio servers
    # would be approved on next launch or if they'll see a prompt.
    if mcp_config.exists():
        try:
            from bog_agents_cli.mcp_trust import (
                compute_config_fingerprint,
                is_project_mcp_trusted,
            )

            project_root = str(Path.cwd().resolve())
            fingerprint = compute_config_fingerprint([mcp_config])
            if is_project_mcp_trusted(project_root, fingerprint):
                checks.append(("MCP trust", "OK", "Trusted (fingerprint matches)"))
            else:
                checks.append(
                    (
                        "MCP trust",
                        "WARN",
                        "Untrusted — stdio servers will require approval on launch",
                    )
                )
        except Exception as e:  # diagnostic command must not crash
            checks.append(("MCP trust", "WARN", f"Could not evaluate trust: {e}"))

    # Format output
    lines = ["## Bog Agents Health Check\n"]

    ok_count = sum(1 for _, s, _ in checks if s == "OK")
    warn_count = sum(1 for _, s, _ in checks if s == "WARN")
    missing_count = sum(1 for _, s, _ in checks if s == "MISSING")

    for name, status, detail in checks:
        icon = {
            "OK": "  OK ",
            "WARN": "WARN",
            "MISSING": "FAIL",
            "INFO": "INFO",
            "SKIP": "SKIP",
        }.get(status, "????")
        lines.append(f"[{icon}] {name}: {detail}")

    lines.append("")
    lines.append(
        f"Summary: {ok_count} OK, {warn_count} warnings, {missing_count} missing"
    )

    if missing_count > 0:
        lines.append(
            "\nAction required: Install missing packages to resolve FAIL items."
        )
    elif warn_count > 0:
        lines.append(
            "\nSome optional components are missing. The CLI will work but with reduced functionality."
        )
    else:
        lines.append("\nAll checks passed! Your environment is fully configured.")

    return "\n".join(lines)
