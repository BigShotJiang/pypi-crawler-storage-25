"""Version information for `bog-agents-cli`."""

__version__ = "0.8.2"  # x-release-please-version
