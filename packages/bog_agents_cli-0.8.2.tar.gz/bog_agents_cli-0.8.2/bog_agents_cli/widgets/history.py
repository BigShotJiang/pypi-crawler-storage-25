"""Command history manager for input persistence."""

from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path


class HistoryManager:
    """Manages command history with file persistence.

    Uses append-only writes for concurrent safety. Multiple agents can
    safely write to the same history file without corruption.
    """

    def __init__(self, history_file: Path, max_entries: int = 1000) -> None:
        """Initialize the history manager.

        Args:
            history_file: Path to the JSON-lines history file
            max_entries: Maximum number of entries to keep. Default is
                1000 — large enough to survive a long working session but
                bounded so the file doesn't grow without limit.
        """
        self.history_file = history_file
        self.max_entries = max_entries
        self._entries: list[str] = []
        self._current_index: int = -1
        self._temp_input: str = ""
        self._query: str = ""
        self._load_history()

    def _load_history(self) -> None:
        """Load history from file."""
        if not self.history_file.exists():
            return

        try:
            with self.history_file.open("r", encoding="utf-8") as f:
                entries = []
                for raw_line in f:
                    line = raw_line.rstrip("\n\r")
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        entry = line
                    entries.append(entry if isinstance(entry, str) else str(entry))
                self._entries = entries[-self.max_entries :]
        except (OSError, UnicodeDecodeError):
            self._entries = []

    def _append_to_file(self, text: str) -> None:
        """Append a single entry to history file (concurrent-safe).

        ``flush`` + ``fsync`` so an immediate process crash after ``add()``
        does not lose the entry the user just submitted.
        """
        try:
            self.history_file.parent.mkdir(parents=True, exist_ok=True)
            with self.history_file.open("a", encoding="utf-8") as f:
                f.write(json.dumps(text) + "\n")
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    # fsync is not available on all platforms (e.g. some
                    # network filesystems). Best-effort.
                    pass
        except OSError:
            pass

    def _compact_history(self) -> None:
        """Rewrite history file to keep at most ``max_entries`` lines."""
        try:
            self.history_file.parent.mkdir(parents=True, exist_ok=True)
            with self.history_file.open("w", encoding="utf-8") as f:
                for entry in self._entries:
                    f.write(json.dumps(entry) + "\n")
                f.flush()
                try:
                    os.fsync(f.fileno())
                except OSError:
                    pass
        except OSError:
            pass

    def add(self, text: str) -> None:
        """Add a command to history.

        Slash commands and ordinary prompts are both recorded so the user
        can recall any prior input with the up arrow. The on-disk history
        is rewritten as soon as it exceeds ``max_entries`` so the file
        does not grow to twice the configured bound between compactions.

        Args:
            text: The command text to add
        """
        text = text.strip()
        if not text:
            return

        # Skip duplicates of the last entry
        if self._entries and self._entries[-1] == text:
            return

        self._entries.append(text)

        if len(self._entries) > self.max_entries:
            # Trim in-memory and rewrite the file in one shot. The full
            # rewrite is bounded by max_entries lines so it stays cheap.
            self._entries = self._entries[-self.max_entries :]
            self._compact_history()
        else:
            self._append_to_file(text)

        self.reset_navigation()

    def get_previous(self, current_input: str, *, query: str = "") -> str | None:
        """Get the previous history entry matching a substring query.

        The query is captured on the first call of a navigation session
        (when `_current_index == -1`) and reused for all subsequent calls until
        `reset_navigation`. Passing a different value on later calls has
        no effect.

        Args:
            current_input: Current input text. Saved only on the first call of a
                navigation session; ignored on subsequent calls.
            query: Substring to match against history entries.
                Captured once on the first call of a navigation session.

        Returns:
            Previous matching entry or `None`.
        """
        if not self._entries:
            return None

        # Save current input and capture query on first navigation
        if self._current_index == -1:
            self._temp_input = current_input
            self._current_index = len(self._entries)
            self._query = query.strip().lower()

        # Search backwards for matching entry
        for i in range(self._current_index - 1, -1, -1):
            if not self._query or self._query in self._entries[i].lower():
                self._current_index = i
                return self._entries[i]

        return None

    def get_next(self) -> str | None:
        """Get the next history entry matching the stored query.

        Uses the query captured by the most recent `get_previous` call.

        Returns:
            The next matching entry, or the original input when past the newest
                match.

                `None` if not currently navigating history.
        """
        if self._current_index == -1:
            return None

        # Search forwards for matching entry
        for i in range(self._current_index + 1, len(self._entries)):
            if not self._query or self._query in self._entries[i].lower():
                self._current_index = i
                return self._entries[i]

        # Return to original input at the end
        result = self._temp_input
        self.reset_navigation()
        return result

    @property
    def in_history(self) -> bool:
        """Whether currently navigating history entries."""
        return self._current_index >= 0

    def reset_navigation(self) -> None:
        """Reset navigation state."""
        self._current_index = -1
        self._temp_input = ""
        self._query = ""
