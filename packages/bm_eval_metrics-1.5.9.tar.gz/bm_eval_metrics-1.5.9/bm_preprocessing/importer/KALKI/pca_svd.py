from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "KALKI" / "pca_svd.py"
pca_svd = SourceCodeModule("bm_preprocessing.KALKI.pca_svd", _source_file)
