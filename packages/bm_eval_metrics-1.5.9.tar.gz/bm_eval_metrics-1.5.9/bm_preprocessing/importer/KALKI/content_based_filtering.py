from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "KALKI" / "content_based_filtering.py"
content_based_filtering = SourceCodeModule("bm_preprocessing.KALKI.content_based_filtering", _source_file)
