from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "KALKI" / "collaborative_filtering.py"
collaborative_filtering = SourceCodeModule("bm_preprocessing.KALKI.collaborative_filtering", _source_file)
