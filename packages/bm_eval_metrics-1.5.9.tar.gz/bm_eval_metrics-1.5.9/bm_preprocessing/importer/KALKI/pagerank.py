from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "KALKI" / "pagerank.py"
pagerank = SourceCodeModule("bm_preprocessing.KALKI.pagerank", _source_file)
