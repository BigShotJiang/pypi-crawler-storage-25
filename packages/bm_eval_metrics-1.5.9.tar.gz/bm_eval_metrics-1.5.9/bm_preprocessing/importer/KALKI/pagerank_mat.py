from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "KALKI" / "pagerank_mat.py"
pagerank_mat = SourceCodeModule("bm_preprocessing.KALKI.pagerank_mat", _source_file)
