from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "KALKI" / "pca.py"
pca = SourceCodeModule("bm_preprocessing.KALKI.pca", _source_file)
