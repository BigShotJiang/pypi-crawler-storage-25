from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "KALKI" / "svd.py"
svd = SourceCodeModule("bm_preprocessing.KALKI.svd", _source_file)
