from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "PY" / "vis_doc.py"
vis_doc = SourceCodeModule("bm_preprocessing.PY.vis_doc", _source_file)
