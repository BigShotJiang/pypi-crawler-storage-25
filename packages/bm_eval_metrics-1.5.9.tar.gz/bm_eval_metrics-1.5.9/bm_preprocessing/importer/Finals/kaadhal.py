from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "Finals" / "kaadhal.py"
kaadhal = SourceCodeModule("bm_preprocessing.Finals.kaadhal", _source_file)
