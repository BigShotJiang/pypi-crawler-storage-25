from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "Finals" / "vikram.py"
vikram = SourceCodeModule("bm_preprocessing.Finals.vikram", _source_file)
