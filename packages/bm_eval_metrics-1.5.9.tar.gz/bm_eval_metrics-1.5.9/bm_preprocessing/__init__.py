"""bm_preprocessing package."""

# Keep legacy module paths working, e.g. ``import bm_preprocessing.DM``.
import sys

from .importer import DM, IR, PY, Finals, KALKI

sys.modules[__name__ + ".DM"] = DM
sys.modules[__name__ + ".PY"] = PY
sys.modules[__name__ + ".IR"] = IR
sys.modules[__name__ + ".Finals"] = Finals
sys.modules[__name__ + ".KALKI"] = KALKI


__all__ = ["DM", "PY", "IR", "Finals", "KALKI"]
