# =========================================================
# VISUALIZATION CHEAT SHEET (Matplotlib, Seaborn, Plotly, NetworkX)
# =========================================================

import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import networkx as nx

# =========================================================
# SAMPLE DATA
# =========================================================
np.random.seed(42)

x = np.arange(1, 11)
y = np.random.randint(10, 100, size=10)

df = pd.DataFrame({
    "x": x,
    "y": y,
    "category": ["A", "B"] * 5
})

# =========================================================
# MATPLOTLIB
# =========================================================

# ---- BAR CHART ----
plt.figure()
plt.bar(x, y)
plt.title("Bar Chart")
plt.xlabel("X")
plt.ylabel("Y")
plt.show()

# ---- PIE CHART ----
plt.figure()
plt.pie(y, labels=x, autopct="%1.1f%%")
plt.title("Pie Chart")
plt.show()

# ---- HISTOGRAM ----
plt.figure()
plt.hist(y, bins=5)
plt.title("Histogram")
plt.show()

# ---- LINE CHART ----
plt.figure()
plt.plot(x, y, marker='o')
plt.title("Line Chart")
plt.show()

# ---- BOX PLOT ----
plt.figure()
plt.boxplot(y)
plt.title("Box Plot")
plt.show()

# ---- HEATMAP (imshow) ----
data = np.random.rand(5, 5)
plt.figure()
plt.imshow(data, cmap='viridis')
plt.colorbar()
plt.title("Heatmap (imshow)")
plt.show()


# =========================================================
# 2SEABORN
# =========================================================

# ---- BAR ----
sns.barplot(x="x", y="y", data=df)
plt.title("Seaborn Bar")
plt.show()

# ---- PIE (not native, use matplotlib) ----

# ---- HISTOGRAM ----
sns.histplot(df["y"], bins=5, kde=True)
plt.title("Seaborn Histogram")
plt.show()

# ---- LINE ----
sns.lineplot(x="x", y="y", data=df)
plt.title("Seaborn Line")
plt.show()

# ---- BOX ----
sns.boxplot(y="y", data=df)
plt.title("Seaborn Box")
plt.show()

# ---- HEATMAP ----
sns.heatmap(data, annot=True, cmap="coolwarm")
plt.title("Seaborn Heatmap")
plt.show()


# =========================================================
# PLOTLY (INTERACTIVE)
# =========================================================

# ---- BAR ----
fig = px.bar(df, x="x", y="y", title="Plotly Bar")
fig.show()

# ---- PIE ----
fig = px.pie(df, values="y", names="x", title="Plotly Pie")
fig.show()

# ---- HISTOGRAM ----
fig = px.histogram(df, x="y", nbins=5, title="Plotly Histogram")
fig.show()

# ---- LINE ----
fig = px.line(df, x="x", y="y", title="Plotly Line")
fig.show()

# ---- BOX ----
fig = px.box(df, y="y", title="Plotly Box")
fig.show()

# ---- HEATMAP ----
fig = px.imshow(data, title="Plotly Heatmap")
fig.show()


# =========================================================
#  NETWORKX (GRAPH VISUALIZATION)
# =========================================================

G = nx.DiGraph()
edges = [("A", "B"), ("A", "C"), ("B", "C"), ("C", "A")]
G.add_edges_from(edges)

plt.figure()
pos = nx.spring_layout(G)
nx.draw(G, pos, with_labels=True, node_size=1000, arrows=True)
plt.title("Network Graph")
plt.show()


# =========================================================
# MATPLOTLIB NUANCES / CONFIGURATION
# =========================================================

# ---- MULTIPLE PLOTS (SUBPLOTS) ----
fig, axs = plt.subplots(2, 2, figsize=(8, 6))

axs[0, 0].plot(x, y)
axs[0, 0].set_title("Line")

axs[0, 1].bar(x, y)
axs[0, 1].set_title("Bar")

axs[1, 0].hist(y)
axs[1, 0].set_title("Histogram")

axs[1, 1].boxplot(y)
axs[1, 1].set_title("Box")

plt.tight_layout()
plt.show()


# ---- MULTIPLE LINES ----
plt.figure()
plt.plot(x, y, label="Line1")
plt.plot(x, y[::-1], label="Line2")
plt.legend()
plt.title("Multiple Lines")
plt.show()


# ---- AXES CONFIG ----
plt.figure()
plt.plot(x, y)
plt.xlim(0, 12)
plt.ylim(0, 120)
plt.xticks(rotation=45)
plt.grid(True)
plt.title("Axis Config")
plt.show()


# ---- STYLE ----
plt.style.use("ggplot")


# =========================================================
# 🎛️ PARAMETERS CHEAT SHEET
# =========================================================

"""
MATPLOTLIB:
-----------
plt.plot(x, y, color='blue', linestyle='--', marker='o')
plt.bar(x, y, width=0.5)
plt.hist(data, bins=10)
plt.imshow(data, cmap='viridis')

COMMON PARAMS:
color, cmap, alpha, linewidth, linestyle, marker, label


SEABORN:
--------
sns.barplot(x=, y=, data=, palette=)
sns.histplot(data, bins=, kde=True)
sns.heatmap(data, annot=True, cmap=)

COMMON PARAMS:
palette, hue, style, size, linewidth


PLOTLY:
-------
px.bar(df, x=, y=, color=)
px.line(df, x=, y=)
px.imshow(data)

COMMON PARAMS:
title, color, labels, template


NETWORKX:
---------
nx.draw(G, pos, node_size=, node_color=, with_labels=True)

LAYOUTS:
spring_layout, circular_layout, shell_layout


GENERAL:
--------
figsize=(w, h)
title()
xlabel(), ylabel()
legend()
grid(True)
tight_layout()
"""