import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from matplotlib.gridspec import GridSpec

# ===== INPUT =====
pages = ["A", "B", "C", "D"]
A = np.array(
    [
        [0, 1, 1, 0],  # A -> B,C
        [0, 0, 1, 0],  # B -> C
        [1, 0, 0, 0],  # C -> A
        [0, 0, 1, 0],  # D -> C
    ],
    dtype=float,
)

d = 0.85
max_iter = 20
tol = 1e-8
n = len(pages)

# ===== STEP 1: TRANSITION MATRIX =====
S = np.zeros_like(A)

for j in range(n):
    out_degree = A[j].sum()
    if out_degree > 0:
        S[j] = A[j] / out_degree
    else:
        S[j] = np.ones(n) / n  # dangling node

S = S.T  # column-stochastic

# ===== STEP 2: GOOGLE MATRIX =====
M = d * S + (1 - d) / n * np.ones((n, n))

# ===== STEP 3: INITIAL RANK =====
r = np.ones(n) / n
history = [r.copy()]

# ===== STEP 4: ITERATIONS =====
for _ in range(max_iter):
    r_new = M @ r
    history.append(r_new.copy())

    diff = np.linalg.norm(r_new - r, 1)
    r = r_new

    if diff < tol:
        print(f"Converged after {_+1} iterations with diff={diff:.2e}")
        break

# ===== FINAL RESULT =====
final_df = pd.DataFrame({"Page": pages, "Final PR": r})
final_df = final_df.sort_values("Final PR", ascending=False)

print("\nFinal PageRank:")
print(final_df.round(6))

# ===== TABULATE ITERATIONS =====
history_arr = np.array(history)

iter_cols = [f"Iter_{i}" for i in range(history_arr.shape[0])]
iter_df = pd.DataFrame(history_arr.T, index=pages, columns=iter_cols)

print("\nPageRank Iterations Table:")
print(iter_df.round(6).to_string())

# ===== CONVERT FOR VISUALIZATION =====
pr = {pages[i]: r[i] for i in range(n)}

history_dict = []
for vec in history:
    history_dict.append({pages[i]: vec[i] for i in range(n)})

# ===== GRAPH =====
G = nx.DiGraph()
for i, src in enumerate(pages):
    for j, dst in enumerate(pages):
        if A[i, j] == 1:
            G.add_edge(src, dst)

# ===== VISUALIZATION =====
fig = plt.figure(figsize=(16, 10))
gs = GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)

ax_graph = fig.add_subplot(gs[:, :2])
ax_bar = fig.add_subplot(gs[0, 2])
ax_conv = fig.add_subplot(gs[1, 2])

# ── GRAPH ─────────────────────────────
pos = nx.spring_layout(G, seed=42, k=2.2)

pr_vals = np.array([pr[p] for p in G.nodes()])
den = (pr_vals.max() - pr_vals.min()) + 1e-9  # avoid zero division
pr_norm = (pr_vals - pr_vals.min()) / den
node_sizes = pr_norm * 3500 + 900

node_colors = [plt.cm.tab10(i / len(pages)) for i in range(len(G.nodes()))]

nx.draw_networkx_edges(
    G, pos, ax=ax_graph,
    arrows=True, arrowsize=22,
    connectionstyle="arc3,rad=0.12",
    width=1.8,
)

nx.draw_networkx_nodes(
    G, pos, ax=ax_graph,
    node_size=node_sizes,
    node_color=node_colors,
)

labels = {p: f"{p}\n{pr[p]:.4f}" for p in G.nodes()}
nx.draw_networkx_labels(
    G, pos, labels=labels, ax=ax_graph,
    font_size=10, font_weight="bold",
)

ax_graph.set_title("PageRank Graph (node size ∝ PR)", fontweight="bold")
ax_graph.axis("off")

# ── BAR CHART ─────────────────────────
sorted_pages = final_df["Page"].tolist()
sorted_prs = final_df["Final PR"].tolist()

bars = ax_bar.barh(sorted_pages, sorted_prs)

for bar, val in zip(bars, sorted_prs):
    ax_bar.text(
        bar.get_width() + 0.003,
        bar.get_y() + bar.get_height() / 2,
        f"{val:.4f}",
        va="center",
        fontsize=9,
    )

ax_bar.set_title("Final PR Ranking", fontweight="bold")
ax_bar.set_xlim(0, max(sorted_prs) * 1.25)
ax_bar.invert_yaxis()

# ── CONVERGENCE ───────────────────────
for p in pages:
    vals = [history_dict[i][p] for i in range(len(history_dict))]
    ax_conv.plot(
        range(len(vals)),
        vals,
        marker="o",
        linewidth=1.8,
        label=p,
    )

ax_conv.set_title("Convergence", fontweight="bold")
ax_conv.set_xlabel("Iteration")
ax_conv.set_ylabel("PageRank")
ax_conv.legend()
ax_conv.grid(True, alpha=0.3)

# ===== FINAL LAYOUT =====
fig.suptitle("PageRank Algorithm", fontsize=16, fontweight="bold")
plt.tight_layout()
plt.show()