import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd

# ===== INPUT =====
pages = ["A", "B", "C", "D"]
A = np.array(
    [
        [0, 1, 1, 0],  # A -> B,C
        [0, 0, 1, 0],  # B -> C
        [1, 0, 0, 0],  # C -> A
        [0, 0, 1, 0],  # D -> C
    ],
    dtype=float,
)

d = 0.85
max_iter = 20
tol = 1e-8
n = len(pages)

# ===== STEP 1: TRANSITION MATRIX (COLUMN STOCHASTIC) =====
S = np.zeros_like(A)

for j in range(n):
    out_degree = A[j].sum()
    if out_degree > 0:
        S[j] = A[j] / out_degree
    else:
        S[j] = np.ones(n) / n  # dangling node

S = S.T  # convert to column-stochastic

print("Transition Matrix S:")
print(pd.DataFrame(S, index=pages, columns=pages))

# ===== STEP 2: GOOGLE MATRIX =====
M = d * S + (1 - d) / n * np.ones((n, n))

print("\nGoogle Matrix M:")
print(pd.DataFrame(M, index=pages, columns=pages))

# ===== STEP 3: INITIAL RANK =====
r = np.ones(n) / n
history = [r.copy()]

print("\nInitial PageRank:")
print(pd.DataFrame({"Page": pages, "PR": r}))

# ===== STEP 4: ITERATIONS =====
for it in range(1, max_iter + 1):
    r_new = M @ r
    history.append(r_new.copy())

    print(f"\nIteration {it}")
    print(pd.DataFrame({"Page": pages, "PR": r_new.round(6)}))

    diff = np.linalg.norm(r_new - r, 1)
    r = r_new

    if diff < tol:
        break

# ===== FINAL RESULT =====
final_df = pd.DataFrame({"Page": pages, "Final PR": r})
final_df = final_df.sort_values("Final PR", ascending=False)

print("\nFinal PageRank:")
print(final_df.round(6))

# ===== GRAPH VISUALIZATION (NODE SIZE ∝ PageRank) =====
G = nx.DiGraph()
for i, src in enumerate(pages):
    for j, dst in enumerate(pages):
        if A[i, j] == 1:
            G.add_edge(src, dst)

plt.figure(figsize=(6, 4))
pos = nx.spring_layout(G, seed=42)

# --- Min-Max scaling for node sizes ---
pr_dict = {pages[i]: r[i] for i in range(n)}
pr_values = np.array([pr_dict[p] for p in G.nodes()])

min_size, max_size = 500, 5000
sizes = min_size + (pr_values - pr_values.min()) / (pr_values.max() - pr_values.min()) * (max_size - min_size)

nx.draw(G, pos, with_labels=True, node_size=sizes, arrows=True)
plt.title("Graph Visualization (node size ∝ PageRank)")
plt.show()

# ===== VISUALIZATION 2: CONVERGENCE =====
history_arr = np.array(history)

plt.figure()
for i, p in enumerate(pages):
    plt.plot(history_arr[:, i], label=p)

plt.xlabel("Iteration")
plt.ylabel("PageRank")
plt.title("PageRank Convergence")
plt.legend()
plt.grid()
plt.show()

# ===== VISUALIZATION 3: FINAL SCORES =====
plt.figure()
plt.bar(final_df["Page"], final_df["Final PR"])
plt.xlabel("Page")
plt.ylabel("PageRank Score")
plt.title("Final PageRank Ranking")
plt.grid()
plt.show()