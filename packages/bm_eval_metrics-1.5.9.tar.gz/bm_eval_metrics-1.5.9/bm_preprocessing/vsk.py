from __future__ import annotations
from groq import Groq

# ─── HYPERPARAMETERS ──────────────────────────────────────────────────────────
API_KEY    = "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"
MODEL_NAME = "openai/gpt-oss-120b"
TEMPERATURE = 0.2

SYSTEM_PROMPT = """
You are an expert Python engineer and code reviewer.

When given a query or task, you MUST respond with:
1. Production-ready Python code that is:
   - Fully error-proof (all exceptions handled gracefully)
   - Bug-free and logically correct
   - Edge-case covered (empty input, None, type mismatches, boundary values, etc.)
   - Clean, readable, and PEP-8 compliant
   - Well-structured with clear variable names and docstrings

2. A short "Changes / Config" section listing:
   - Any hyperparameters or constants the user should adjust
   - File paths, API keys, or environment variables needed
   - Optional improvements or flags

3. A brief explanation of what the code does and why key decisions were made.

Always wrap code in proper Python markdown code blocks.
Never leave placeholders like `pass` or `# TODO` unless explicitly asked.
""".strip()
# ─────────────────────────────────────────────────────────────────────────────


def parrot(query: str) -> str:
    """
    Send a query to Groq and stream the model response to the terminal,
    then return the full response text.

    Args:
        query: A non-empty string prompt/question.

    Returns:
        The model's response as a stripped string.

    Raises:
        ValueError: If query is not a non-empty string.
        groq.APIError: On API-level failures.
    """
    if not isinstance(query, str) or not query.strip():
        raise ValueError("query must be a non-empty string")

    client = Groq(api_key=API_KEY)

    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": query.strip()},
        ],
        temperature=TEMPERATURE,
    )

    content = response.choices[0].message.content
    result  = content.strip() if content else ""

    print(result)
    return result
