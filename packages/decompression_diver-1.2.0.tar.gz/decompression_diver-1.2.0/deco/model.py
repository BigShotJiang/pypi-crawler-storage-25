class DecompressionModel:
    """
        The decompression model interface is used to wrap the possible decompression algorithms.
        Simplest and basic information for the decompression is the immersion time and depth.
        More option could be added to take advantage of the diver consumption, water temperature ...
    """
    def append(self, time: int, depth: int, **options): pass
    def reset(self): pass
    def decompression_stop(self, **kwargs): pass
