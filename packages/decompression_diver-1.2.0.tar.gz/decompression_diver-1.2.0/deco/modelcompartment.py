# coding=utf-8
import math
from deco.model import DecompressionModel

PP_N2_AIR = 0.7902
PP_H2O_ALVEOLAIRE = 0.0627
PN2_ALVEOLAIRE_INITIAL = (PP_N2_AIR*(1-PP_H2O_ALVEOLAIRE))


class DecompressionModelCompartment(DecompressionModel):
    """
       Implementation de l'équation d'Haldane ou equation instantané:
          Cette équation est applicable si la pression ambiante ne varie pas (à profondeur constant !)
          P = P0 + (Pi-P0)(1-e^-kt)
       Ou selon Buhlmann
          P = P0 + (Pi-P0)(1-2^(-t/periode))
       ou
          P  pression finale du gaz inerte dans le compartiment
          P0 pression initiale du gaz inerte dans le compartiment
          Pi pression du gaz inerte respiré dans le compartiment
          t  temps d'exposition (ou intervalle)
          k  constante dependante de la periode


        Equation de Schreiner ou solution globale
           Cette équation est applicable lorsque la variation de la pression est constante.
            (vitesse de descente ou de remontée)
           P = Pio + R(t-1/k)-[Pio-Po-(R/k)]e^(-kt)
           ou
           P   pression finale du gaz inerte dans le compartiment
           Pio pression initiale du gaz inerte respiré moins la vapeur d'eau
           Po  pression du gaz inerte présente au départ dans le compartiement
           R   (ou c) variation de la pression du gaz respiré en fonction de la variation de la pression ambiante
               c'est simplement le taux de descente ou remontée multiplié par le pourentage de gaz inerte.
           t   temps d'exposition (ou intervalle)
           k   constante lié à la période du compartiement = ln2/période

           Donc en toute rigueur, on doit utiliser l'équiation d'Haldane pour l'évolution du plongeur au fond,
           et l'équation de schreiner pour la descente et la remontée.
    """
    def __init__(self, period: int, sc: float, gas_mixture: dict | None = None, p0: float = 0, t0: float = 0):
        """
        Build the decompression model with the compartment period and critical saturation threshold.
        :param period: the compartment period (seconds)
        :param sc: the critical saturation threshold
        :param gas_mixture: dictionary with gas percentages (e.g., {"N2": 0.68, "O2": 0.32} for Nitrox 32)
        :param p0: initial pressure
        :param t0: initial time
        """
        self.period = period
        self.sc = sc
        self.p0 = p0
        self.t0 = t0
        
        # Support pour différents mélanges gazeux
        if gas_mixture is None:
            # Air par défaut
            self.gas_mixture = {"N2": 0.7902, "O2": 0.2095, "Ar": 0.0003}
        else:
            self.gas_mixture = gas_mixture
            
        # Calculer le pourcentage d'azote (gaz inerte principal)
        self.pp_n2 = self.gas_mixture.get("N2", 0.7902)
        
        # Calculer la pression alvéolaire initiale pour ce mélange
        self.pn2_alveolaire_initial = self.pp_n2 * (1 - PP_H2O_ALVEOLAIRE)
        
        # Stocker l'historique de la plongée
        self.dive_profile = []
        # Initialiser à la tension atmosphérique (1 bar * fraction N2)
        self.current_tension = self.pp_n2 * 1.0  # Tension atmosphérique

    def append(self, time: int, depth: int, gas_mixture: dict | None = None, **options):
        """
        Ajouter un segment de plongée avec possibilité de changer de mélange gazeux
        :param time: temps en minutes
        :param depth: profondeur en mètres
        :param gas_mixture: mélange gazeux pour ce segment (optionnel)
        """
        # Si un nouveau mélange est spécifié, l'utiliser
        if gas_mixture is not None:
            self.gas_mixture = gas_mixture
            self.pp_n2 = self.gas_mixture.get("N2", 0.7902)
            self.pn2_alveolaire_initial = self.pp_n2 * (1 - PP_H2O_ALVEOLAIRE)
        
        return self._append(time, depth)

    def _append(self, time: int, depth: int):
        """
        Calcule la saturation à la volée du segment transmis.
        Cet algorithme fait intervenir une equation différentielle dP/dt
        :param time: temps en minutes
        :param depth: profondeur en mètres
        :return: tension calculée
        """
        # Convertir en secondes
        time_sec = time * 60
        
        # Calculer la pression absolue (profondeur + 1 atm)
        p_abs = (depth / 10) + 1  # 10m = 1 bar
        
        # Calculer la pression partielle d'azote à cette profondeur
        pn2_inspired = self.pp_n2 * p_abs
        
        # Utiliser l'équation d'Haldane pour calculer la nouvelle tension
        self.current_tension = self.haldane(
            self.current_tension, 
            pn2_inspired, 
            time_sec, 
            self.period
        )
        
        # Stocker le segment
        self.dive_profile.append({
            'time': time,
            'depth': depth,
            'tension': self.current_tension,
            'gas_mixture': self.gas_mixture.copy()
        })
        
        return self.current_tension

    def decompression_stop(self, **kwargs):
        """
        Calcule les paliers de décompression nécessaires
        :return: tuple (temps_total, profondeur_max, palier_12m, palier_9m, palier_6m, palier_3m, GPS)
        """
        if not self.dive_profile:
            return (0, 0, 0, 0, 0, 0, 'A')
        
        # Trouver la profondeur maximale
        max_depth = max(segment['depth'] for segment in self.dive_profile)
        
        # Calculer le temps total
        total_time = sum(segment['time'] for segment in self.dive_profile)
        
        # Calculer les paliers basés sur la tension actuelle
        # Ceci est une implémentation simplifiée - en réalité, il faudrait
        # calculer pour chaque compartiment et utiliser les seuils critiques
        decompression_stops = self._calculate_decompression_stops()
        
        return (total_time, max_depth, *decompression_stops, 'N')  # GPS simplifié

    def _calculate_decompression_stops(self):
        """
        Calcule les paliers de décompression basés sur la tension actuelle
        :return: tuple (palier_12m, palier_9m, palier_6m, palier_3m)
        """
        # Seuils de décompression simplifiés (en bar)
        # En réalité, ces seuils dépendent du modèle utilisé (Buhlmann, etc.)
        stop_12m = 0
        stop_9m = 0
        stop_6m = 0
        stop_3m = 0
        
        # Calculer les paliers basés sur la tension et les seuils critiques
        if self.current_tension > self.sc * 1.2:  # Seuil 12m
            stop_12m = int((self.current_tension - self.sc * 1.2) * 10)
        if self.current_tension > self.sc * 1.1:  # Seuil 9m
            stop_9m = int((self.current_tension - self.sc * 1.1) * 15)
        if self.current_tension > self.sc * 1.05:  # Seuil 6m
            stop_6m = int((self.current_tension - self.sc * 1.05) * 20)
        if self.current_tension > self.sc:  # Seuil 3m
            stop_3m = int((self.current_tension - self.sc) * 25)
        
        return (stop_12m, stop_9m, stop_6m, stop_3m)

    def reset(self):
        """Réinitialise le modèle"""
        self.current_tension = self.pp_n2 * 1.0  # Tension atmosphérique
        self.dive_profile = []

    def compute_haldane_period(self, t0: float, p0: float, ti: float, pi: float, iteration_per_min: float = 200):
        """
        L'équiation instantanée d'haldane ne fonctionne qu'avec des pressions constantes.
        Lorsque les pression varient, il est necessaire de découper la plongée en plusieurs sequence ou la pression ne
        varie pas, et donc de cumuler la charge d'azote de chaque itérations (c.f. doc belin)

        p0 pression initiale (msw meter-sub-water)
        pi pression respiré (msw meter-sub-water)
        t0 temps initial (secondes) = 0
        ti temps final (secondes)
        """
        tension = p0
        iteration_per_sec = iteration_per_min / 60.0
        nb_iter = (ti-t0)/iteration_per_sec
        step_pression = (pi-p0)/nb_iter
        for pos, t in enumerate(numpy.arange(t0, ti, iteration_per_sec)):
            pression_a_t = step_pression * pos
            tension = self.haldane(tension, pression_a_t, t, self.period)
        return tension

    @staticmethod
    def haldane(p0: float, pi: float, t: float, period: float):
        '''
        L'algotirhme de haldane est une simplification de l'équation de schreiner pour une pression constante.
        C'est une approximation valable pour les plongées à profondeur constante.

        p0 pression initiale (msw meter-sub-water)
        pi pression respiré (msw meter-sub-water)
        t temps d'exposition (ou intervalle)
        period période du compartiment (secondes)
        '''
        return p0 + (pi - p0) * (1 - math.pow(.5, t/period))
    
    def load_shreiner_func(self, p_abs: float, vitesse: float, period: float | None = None):
        '''
        Prepare un fonction de shreiner avec les valeurs initiales:
           pression absolue (en bar),
           vitesse de montee/descente (en bar/mn)
        retourne l'équation de shreiner permettant la calcule de la tension à un instant t de la montée/descente
        '''
        if period is None:
            period = self.period

        # Pression alvéolaire du gaz inerte correspond à la pression absolue moins la vapeur d'eau...
        p_alv = self.pp_n2 * (p_abs - PP_H2O_ALVEOLAIRE)
        # variation de la pression partielle en fonction de la vitesse
        r = self.pp_n2 * vitesse
        k = math.log(2) / period

        def f(time, p_i):
            assert time > 0
            return p_alv + r * (time - 1 / k) - (p_alv - p_i - r / k) * math.exp(-k * time)
        return f

    def get_gas_info(self):
        """
        Retourne les informations sur le mélange gazeux actuel
        :return: dict avec les informations du mélange
        """
        return {
            'mixture': self.gas_mixture,
            'nitrogen_percentage': self.pp_n2,
            'oxygen_percentage': self.gas_mixture.get('O2', 0.2095),
            'current_tension': self.current_tension
        }

    def switch_gas(self, new_gas_mixture: dict):
        """
        Change le mélange gazeux pendant la plongée
        :param new_gas_mixture: nouveau mélange gazeux
        """
        self.gas_mixture = new_gas_mixture
        self.pp_n2 = self.gas_mixture.get("N2", 0.7902)
        self.pn2_alveolaire_initial = self.pp_n2 * (1 - PP_H2O_ALVEOLAIRE)


# Exemples d'utilisation avec Nitrox
def create_nitrox_mixture(o2_percentage: float):
    """
    Crée un mélange Nitrox avec le pourcentage d'oxygène spécifié
    :param o2_percentage: pourcentage d'oxygène (ex: 32 pour Nitrox 32)
    :return: dict du mélange gazeux
    """
    n2_percentage = 100 - o2_percentage
    return {
        "N2": n2_percentage / 100,
        "O2": o2_percentage / 100,
        "Ar": 0.0003  # Argon résiduel
    }


# Exemples d'utilisation
if __name__ == "__main__":
    # Créer un modèle avec Nitrox 32
    nitrox_32 = create_nitrox_mixture(32)
    deco = DecompressionModelCompartment(
        period=60*60,  # 60 minutes
        sc=2.75,       # Seuil critique
        gas_mixture=nitrox_32
    )
    
    print("Mélange gazeux:", deco.get_gas_info())
    
    # Simuler une plongée avec Nitrox
    deco.append(0, 0)      # Surface
    deco.append(5, 30)     # Descente à 30m
    deco.append(20, 30)    # 20min à 30m
    
    # Changer pour Nitrox 50 pour la remontée
    nitrox_50 = create_nitrox_mixture(50)
    deco.append(0, 30, gas_mixture=nitrox_50)  # Changement de gaz
    deco.append(10, 15)    # Remontée à 15m
    deco.append(5, 6)      # Remontée à 6m
    
    # Calculer les paliers
    result = deco.decompression_stop()
    print("Résultat décompression:", result)
    print("Tension finale:", deco.current_tension)
