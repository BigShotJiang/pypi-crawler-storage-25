from deco import __version__
from deco.modelcompartment import DecompressionModelCompartment
import math

print("Module version: " + __version__)
print("PROFIL EN LIMITE DU SEUIL CRITIQUE (Sc)")

# Créer le modèle compartimentaire (60min, Sc=2.75)
deco = DecompressionModelCompartment(
    period=60*60,  # 60 minutes en secondes
    sc=2.75       # Seuil critique en bar
)

# Profondeur cible (48m comme dans l'exemple précédent)
target_depth = 48

print(f"Profondeur cible: {target_depth}m")
print(f"Seuil critique (Sc): {deco.sc} bar")

# Calculer la pression partielle d'azote à cette profondeur
p_abs = (target_depth / 10) + 1  # 5.8 bar à 48m
pp_n2_air = 0.7902
pn2_inspired = pp_n2_air * p_abs  # 4.58 bar

print(f"Pression absolue: {p_abs} bar")
print(f"Pression partielle N₂ inspirée: {pn2_inspired:.2f} bar")

# Calculer le temps nécessaire pour atteindre le Sc
# Utiliser l'équation d'Haldane inversée
# Sc = P0 + (Pi - P0) * (1 - 2^(-t/period))
# t = period * log2((Pi - P0) / (Pi - Sc))

# Tension initiale (surface)
p0 = pp_n2_air * 1.0  # 0.79 bar
period = 60 * 60  # 60 minutes en secondes

# Calcul du temps pour atteindre Sc
if pn2_inspired > deco.sc:
    time_to_sc = period * math.log2((pn2_inspired - p0) / (pn2_inspired - deco.sc))
    time_to_sc_minutes = int(time_to_sc / 60)  # Convertir en minutes entières
else:
    time_to_sc_minutes = 0

print(f"Temps pour atteindre Sc: {time_to_sc_minutes} minutes")

# Créer le profil de plongée
deco.append(time=0, depth=0)  # Surface
deco.append(5, target_depth)  # Descente rapide (5 min)
deco.append(time_to_sc_minutes, target_depth)  # Temps au fond pour atteindre Sc

# Vérifier la tension finale
final_tension = deco.current_tension
print(f"Tension finale: {final_tension:.3f} bar")
print(f"Différence avec Sc: {abs(final_tension - deco.sc):.3f} bar")

# Remontée
deco.append(10, 20)  # Remontée à 20m
deco.append(5, 6)    # Remontée à 6m

# Calculer les paliers
result = deco.decompression_stop()
print(f"\nRésultat décompression: {result}")

print("RETOUR EN SURFACE")
