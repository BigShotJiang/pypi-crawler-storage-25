import csv
import os
from deco.model import DecompressionModel

resources_path = os.path.join(os.path.split(__file__)[0], "resources")
mn90_csv_file = os.path.join(resources_path, "mn90.csv")
mn90_I_csv_file = os.path.join(resources_path, "mn90_I.csv")
mn90_II_csv_file = os.path.join(resources_path, "mn90_II.csv")


class TableMn90:
    def __init__(self, time, depth, step_12, step_9, step_6, step_3, gps):
        self.depth = depth
        self.time = time
        self.step_12 = step_12
        self.step_9 = step_9
        self.step_6 = step_6
        self.step_3 = step_3
        self.gps = gps

    pass

    def __str__(self):
        return "{}, {}, {}, {}, {}, {}, {}".format(self.time, self.depth, self.step_12, self.step_9, self.step_6,
                                                   self.step_3, self.gps)


class MN90:
    tables = []  # list of TableMn90 class
    tablesI = []  # list of { time: time , GPS:{ A: float, ... }
    tablesII = []  # dict of { depth: depth , residuals:{ "0.82": int, ... }

    def __init__(self):
        self._load_table_from_csv(mn90_csv_file)  #  tables de deco
        self._load_table1_from_csv(mn90_I_csv_file)  # tables azote résiduel
        self._load_table2_from_csv(mn90_II_csv_file)  # tables majorations

    def _load_table_from_csv(self, csv_path):
        with open(csv_path) as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                self.tables.append(TableMn90(int(row['time']), int(row['depth']), int(row['S12']), int(row['S9']),
                                             int(row['S6']), int(row['S3']), row['gps']))

    def _load_table1_from_csv(self, csv_path):
        with open(csv_path) as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                t = {"time": int(row['time']),
                     "gps": {
                         "A": float(row['A']),
                         "B": float(row['B']),
                         "C": float(row['C']),
                         "D": float(row['D']),
                         "E": float(row['E']),
                         "F": float(row['F']),
                         "G": float(row['G']),
                         "H": float(row['H']),
                         "I": float(row['I']),
                         "J": float(row['J']),
                         "K": float(row['K']),
                         "L": float(row['L']),
                         "M": float(row['M']),
                         "N": float(row['N']),
                         "O": float(row['O']),
                         "P": float(row['P'])
                     }}

                self.tablesI.append(t)

    def _load_table2_from_csv(self, csv_path):
        with open(csv_path) as csvfile:
            reader = csv.DictReader(csvfile)
            fieldnames = reader.fieldnames
            for row in reader:
                t = {"depth": int(row['depth']), "residuals": {}}
                for field in fieldnames:
                    try:
                        float(field)
                        t['residuals'][field] = int(row[field])
                    except ValueError:
                        pass
                self.tablesII.append(t)

    def _per_depth(self, depth: int):
        for row in self.tables:
            table_depth = int(row.depth)
            if table_depth == depth:
                yield row

    def _per_time(self, time: int, depth: int):
        for row in self._per_depth(depth):
            table_time = int(row.time)
            if table_time == time:
                yield row

    def choose_depth(self, depth: int):
        for row in self.tables:
            table_depth = int(row.depth)
            if depth <= table_depth:
                return table_depth
        raise ValueError("Too deep !")

    def choose_time(self, time: int, depth: int):
        for row in self._per_depth(depth):
            table_time = int(row.time)
            if time <= table_time:
                return table_time
        raise ValueError("Too long !")

    def residual_nitrogen(self, interval_time: int, gps: str):
        if interval_time < 15:
            raise ValueError("Too small ground interval ({}mn)".format(interval_time))
        elif gps not in "ABCDEFGHIJKLMNOP":
            raise ValueError("Bad GPS value ({})".format(gps))
        previous = 0
        for row in self.tablesI:
            if row['time'] == interval_time:
                return row['gps'].get(gps)
            elif row['time'] > interval_time:
                return previous
            previous = row['gps'].get(gps)
        return 0.81

    def residual_nitrogen_time(self, depth: int, residual: float):
        for row in self.tablesII:
            if depth <= row['depth']:
                for res, s in row['residuals'].items():
                    if residual <= float(res):
                        return s
        raise ValueError("No surcharge time found!")

    def decompression_stop(self, time: int, depth: int, surcharge=None):
        """
        Compute the decompression floor with the diving parameter time/depth + possible diving
        surcharge in minutes caused by a previous dive
        """
        if surcharge:
            time = time + surcharge
        selected_depth = self.choose_depth(depth)
        selected_time = self.choose_time(time, selected_depth)
        results = self._per_time(selected_time, selected_depth)
        results = next(results, None)
        if surcharge:
            results.gps = '*'
        if results:
            return selected_time, selected_depth, results.step_12, results.step_9, results.step_6, \
                   results.step_3, results.gps


class DecompressionModelTablesMn90(DecompressionModel):
    """
    MN90 Tables decompression model is based on static tables.
    Maximum depth and time is kept in memory to compute de decompression.
    """

    def __init__(self, **kwargs):
        self.decompression_model = MN90()
        self.maximum_depth = 0
        self.maximum_time = 0

    def append(self, time: int, depth: int, **options):
        if depth > self.maximum_depth:
            self.maximum_depth = depth
        if time > self.maximum_time:
            self.maximum_time = time

    def reset(self):
        self.maximum_time = 0
        self.maximum_depth = 0

    def decompression_stop(self, majoration: int = None):
        return self.decompression_model.decompression_stop(self.maximum_time, self.maximum_depth, majoration)

    def residual_nitrogen_time (self, interval: int, gps: str, depth: int = None):
        '''
        Computes time surcharge in minutes according to the given gps and interval.
        If depth not provided, the computation is performed with the current depth.
        '''
        if not depth:
            depth = self.maximum_depth
        return self.decompression_model.residual_nitrogen_time(depth, self.decompression_model.residual_nitrogen(interval, gps))
