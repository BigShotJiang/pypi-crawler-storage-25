from deco.modelcompartment import DecompressionModelCompartment
from deco.modelmn90 import DecompressionModelTablesMn90
from deco.modelbuhlmann import DecompressionModelBuhlmann



class DecompressionModelFactory:
    # Model list
    # MN90 based on MN90 tables
    MODEL_MN90 = "MN90"
    # SINGLE comompartiment: based on one compartiment passed in parameters
    MODEL_SINGLE_COMPARTIMENT = "COMPARTIMENT"
    # Haldane based on 5 Compatements
    MODEL_HALDANE = "HALDANE"
    # Bühlmann ZHL-16 model
    MODEL_BUHLMANN = "BUHLMANN"
    # ... TBC

    @staticmethod
    def create(model_name, **kwargs):
        if model_name is DecompressionModelFactory.MODEL_MN90:
            return DecompressionModelTablesMn90()
        if model_name is DecompressionModelFactory.MODEL_SINGLE_COMPARTIMENT:
            return DecompressionModelCompartment(**kwargs)
        if model_name is DecompressionModelFactory.MODEL_BUHLMANN:
            return DecompressionModelBuhlmann(**kwargs)
        # ... TBC



