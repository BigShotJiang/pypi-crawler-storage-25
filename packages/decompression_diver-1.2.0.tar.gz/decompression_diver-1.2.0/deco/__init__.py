"""Décompression : modèles MN90 et compartiments (Haldane / Schreiner)."""

__version__ = "1.0.0"
