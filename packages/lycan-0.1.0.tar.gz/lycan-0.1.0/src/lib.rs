mod ml_dsa;
mod ml_kem;
mod slh_dsa;
mod utils;

use pyo3::prelude::*;

/// Python bindings for RustCrypto algorithms.
#[pymodule]
fn lycan(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add("__version__", env!("CARGO_PKG_VERSION"))?;
    ml_kem::register(module)?;
    ml_dsa::register(module)?;
    slh_dsa::register(module)?;
    Ok(())
}
