use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyBytes;

pub(crate) fn invalid_length(name: &str, expected: usize, actual: usize) -> PyErr {
    PyValueError::new_err(format!(
        "{name} must be {expected} bytes, got {actual} bytes"
    ))
}

pub(crate) fn pybytes(py: Python<'_>, data: &[u8]) -> Py<PyBytes> {
    PyBytes::new(py, data).unbind()
}
