use crate::utils::{invalid_length, pybytes};
use ml_dsa::{
    Generate, KeyExport, Keypair, MlDsa44, MlDsa65, MlDsa87, Signature, SignatureEncoding,
    SigningKey, VerifyingKey, common::typenum::Unsigned,
};
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyBytes;

enum MlDsaSecretKey {
    MlDsa44(SigningKey<MlDsa44>),
    MlDsa65(SigningKey<MlDsa65>),
    MlDsa87(SigningKey<MlDsa87>),
}

impl MlDsaSecretKey {
    fn algorithm(&self) -> &'static str {
        match self {
            Self::MlDsa44(_) => "ML-DSA-44",
            Self::MlDsa65(_) => "ML-DSA-65",
            Self::MlDsa87(_) => "ML-DSA-87",
        }
    }

    fn seed(&self) -> Vec<u8> {
        match self {
            Self::MlDsa44(key) => key.to_bytes().as_slice().to_vec(),
            Self::MlDsa65(key) => key.to_bytes().as_slice().to_vec(),
            Self::MlDsa87(key) => key.to_bytes().as_slice().to_vec(),
        }
    }

    fn public_key(&self) -> Vec<u8> {
        match self {
            Self::MlDsa44(key) => key.verifying_key().to_bytes().as_slice().to_vec(),
            Self::MlDsa65(key) => key.verifying_key().to_bytes().as_slice().to_vec(),
            Self::MlDsa87(key) => key.verifying_key().to_bytes().as_slice().to_vec(),
        }
    }
}

#[pyclass(module = "lycan", name = "MlDsaSecretKey")]
struct PyMlDsaSecretKey {
    inner: MlDsaSecretKey,
}

#[pymethods]
impl PyMlDsaSecretKey {
    #[getter]
    fn algorithm(&self) -> &'static str {
        self.inner.algorithm()
    }

    fn public_key(&self, py: Python<'_>) -> Py<PyBytes> {
        pybytes(py, &self.inner.public_key())
    }

    #[pyo3(signature = (message, context=None))]
    fn sign(
        &self,
        py: Python<'_>,
        message: &[u8],
        context: Option<&[u8]>,
    ) -> PyResult<Py<PyBytes>> {
        let context = context.unwrap_or(b"");
        match &self.inner {
            MlDsaSecretKey::MlDsa44(key) => {
                let sig = key
                    .expanded_key()
                    .sign_deterministic(message, context)
                    .map_err(|_| PyValueError::new_err("ML-DSA signing failed"))?;
                Ok(pybytes(py, sig.to_bytes().as_ref()))
            }
            MlDsaSecretKey::MlDsa65(key) => {
                let sig = key
                    .expanded_key()
                    .sign_deterministic(message, context)
                    .map_err(|_| PyValueError::new_err("ML-DSA signing failed"))?;
                Ok(pybytes(py, sig.to_bytes().as_ref()))
            }
            MlDsaSecretKey::MlDsa87(key) => {
                let sig = key
                    .expanded_key()
                    .sign_deterministic(message, context)
                    .map_err(|_| PyValueError::new_err("ML-DSA signing failed"))?;
                Ok(pybytes(py, sig.to_bytes().as_ref()))
            }
        }
    }

    /// Export the 32-byte ML-DSA seed form. This creates an immutable Python bytes copy.
    fn to_seed(&self, py: Python<'_>) -> Py<PyBytes> {
        pybytes(py, &self.inner.seed())
    }

    fn __repr__(&self) -> String {
        format!("MlDsaSecretKey(algorithm='{}')", self.inner.algorithm())
    }
}

fn normalize_algorithm(algorithm: &str) -> PyResult<&'static str> {
    match algorithm.to_ascii_uppercase().replace('_', "-").as_str() {
        "ML-DSA-44" | "MLDSA44" => Ok("ML-DSA-44"),
        "ML-DSA-65" | "MLDSA65" => Ok("ML-DSA-65"),
        "ML-DSA-87" | "MLDSA87" => Ok("ML-DSA-87"),
        _ => Err(PyValueError::new_err(format!(
            "unsupported ML-DSA algorithm: {algorithm}; use one of ml_dsa_algorithms()"
        ))),
    }
}

fn public_key_44(public_key: &[u8]) -> PyResult<VerifyingKey<MlDsa44>> {
    let expected = <VerifyingKey<MlDsa44> as ml_dsa::KeySizeUser>::KeySize::USIZE;
    let public_key = public_key
        .try_into()
        .map_err(|_| invalid_length("public_key", expected, public_key.len()))?;
    Ok(VerifyingKey::<MlDsa44>::decode(&public_key))
}

fn public_key_65(public_key: &[u8]) -> PyResult<VerifyingKey<MlDsa65>> {
    let expected = <VerifyingKey<MlDsa65> as ml_dsa::KeySizeUser>::KeySize::USIZE;
    let public_key = public_key
        .try_into()
        .map_err(|_| invalid_length("public_key", expected, public_key.len()))?;
    Ok(VerifyingKey::<MlDsa65>::decode(&public_key))
}

fn public_key_87(public_key: &[u8]) -> PyResult<VerifyingKey<MlDsa87>> {
    let expected = <VerifyingKey<MlDsa87> as ml_dsa::KeySizeUser>::KeySize::USIZE;
    let public_key = public_key
        .try_into()
        .map_err(|_| invalid_length("public_key", expected, public_key.len()))?;
    Ok(VerifyingKey::<MlDsa87>::decode(&public_key))
}

#[pyfunction]
fn ml_dsa_algorithms() -> Vec<&'static str> {
    vec!["ML-DSA-44", "ML-DSA-65", "ML-DSA-87"]
}

#[pyfunction]
#[pyo3(signature = (algorithm="ML-DSA-65"))]
fn ml_dsa_keygen(py: Python<'_>, algorithm: &str) -> PyResult<(PyMlDsaSecretKey, Py<PyBytes>)> {
    match normalize_algorithm(algorithm)? {
        "ML-DSA-44" => {
            let secret_key = SigningKey::<MlDsa44>::generate();
            let public_key = secret_key.verifying_key().to_bytes();
            Ok((
                PyMlDsaSecretKey {
                    inner: MlDsaSecretKey::MlDsa44(secret_key),
                },
                pybytes(py, public_key.as_ref()),
            ))
        }
        "ML-DSA-65" => {
            let secret_key = SigningKey::<MlDsa65>::generate();
            let public_key = secret_key.verifying_key().to_bytes();
            Ok((
                PyMlDsaSecretKey {
                    inner: MlDsaSecretKey::MlDsa65(secret_key),
                },
                pybytes(py, public_key.as_ref()),
            ))
        }
        "ML-DSA-87" => {
            let secret_key = SigningKey::<MlDsa87>::generate();
            let public_key = secret_key.verifying_key().to_bytes();
            Ok((
                PyMlDsaSecretKey {
                    inner: MlDsaSecretKey::MlDsa87(secret_key),
                },
                pybytes(py, public_key.as_ref()),
            ))
        }
        _ => unreachable!(),
    }
}

#[pyfunction]
fn ml_dsa_secret_key_from_seed(algorithm: &str, seed: &[u8]) -> PyResult<PyMlDsaSecretKey> {
    let expected = 32;
    let seed = seed
        .try_into()
        .map_err(|_| invalid_length("seed", expected, seed.len()))?;
    match normalize_algorithm(algorithm)? {
        "ML-DSA-44" => Ok(PyMlDsaSecretKey {
            inner: MlDsaSecretKey::MlDsa44(SigningKey::<MlDsa44>::from_seed(&seed)),
        }),
        "ML-DSA-65" => Ok(PyMlDsaSecretKey {
            inner: MlDsaSecretKey::MlDsa65(SigningKey::<MlDsa65>::from_seed(&seed)),
        }),
        "ML-DSA-87" => Ok(PyMlDsaSecretKey {
            inner: MlDsaSecretKey::MlDsa87(SigningKey::<MlDsa87>::from_seed(&seed)),
        }),
        _ => unreachable!(),
    }
}

#[pyfunction]
#[pyo3(signature = (secret_key, message, context=None))]
fn ml_dsa_sign(
    py: Python<'_>,
    secret_key: &Bound<'_, PyAny>,
    message: &[u8],
    context: Option<&[u8]>,
) -> PyResult<Py<PyBytes>> {
    let secret_key = secret_key.extract::<PyRef<'_, PyMlDsaSecretKey>>()?;
    secret_key.sign(py, message, context)
}

#[pyfunction]
#[pyo3(signature = (algorithm, public_key, message, signature, context=None))]
fn ml_dsa_verify(
    algorithm: &str,
    public_key: &[u8],
    message: &[u8],
    signature: &[u8],
    context: Option<&[u8]>,
) -> PyResult<bool> {
    let context = context.unwrap_or(b"");
    match normalize_algorithm(algorithm)? {
        "ML-DSA-44" => {
            let public_key = public_key_44(public_key)?;
            let signature = Signature::<MlDsa44>::try_from(signature)
                .map_err(|_| PyValueError::new_err("invalid ML-DSA signature"))?;
            Ok(public_key.verify_with_context(message, context, &signature))
        }
        "ML-DSA-65" => {
            let public_key = public_key_65(public_key)?;
            let signature = Signature::<MlDsa65>::try_from(signature)
                .map_err(|_| PyValueError::new_err("invalid ML-DSA signature"))?;
            Ok(public_key.verify_with_context(message, context, &signature))
        }
        "ML-DSA-87" => {
            let public_key = public_key_87(public_key)?;
            let signature = Signature::<MlDsa87>::try_from(signature)
                .map_err(|_| PyValueError::new_err("invalid ML-DSA signature"))?;
            Ok(public_key.verify_with_context(message, context, &signature))
        }
        _ => unreachable!(),
    }
}

pub(crate) fn register(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_class::<PyMlDsaSecretKey>()?;
    module.add_function(wrap_pyfunction!(ml_dsa_algorithms, module)?)?;
    module.add_function(wrap_pyfunction!(ml_dsa_keygen, module)?)?;
    module.add_function(wrap_pyfunction!(ml_dsa_secret_key_from_seed, module)?)?;
    module.add_function(wrap_pyfunction!(ml_dsa_sign, module)?)?;
    module.add_function(wrap_pyfunction!(ml_dsa_verify, module)?)?;
    Ok(())
}
