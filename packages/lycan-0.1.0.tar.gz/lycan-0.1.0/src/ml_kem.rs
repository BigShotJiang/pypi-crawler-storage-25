use crate::utils::{invalid_length, pybytes};
use pyo3::exceptions::{PyTypeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::PyBytes;

use ml_kem::{
    Decapsulate, DecapsulationKey512, DecapsulationKey768, DecapsulationKey1024, Encapsulate,
    EncapsulationKey512, EncapsulationKey768, EncapsulationKey1024, KeyExport, KeySizeUser,
    MlKem512, MlKem768, MlKem1024,
    array::typenum::Unsigned,
    kem::{FromSeed, Kem},
    ml_kem_512, ml_kem_768, ml_kem_1024,
};

enum MlKemSecretKey {
    MlKem512(DecapsulationKey512),
    MlKem768(DecapsulationKey768),
    MlKem1024(DecapsulationKey1024),
}

impl MlKemSecretKey {
    fn algorithm(&self) -> &'static str {
        match self {
            Self::MlKem512(_) => "ML-KEM-512",
            Self::MlKem768(_) => "ML-KEM-768",
            Self::MlKem1024(_) => "ML-KEM-1024",
        }
    }

    fn seed(&self) -> Vec<u8> {
        match self {
            Self::MlKem512(key) => key.to_bytes().as_slice().to_vec(),
            Self::MlKem768(key) => key.to_bytes().as_slice().to_vec(),
            Self::MlKem1024(key) => key.to_bytes().as_slice().to_vec(),
        }
    }
}

#[pyclass(module = "lycan", name = "MlKemSecretKey")]
struct PyMlKemSecretKey {
    inner: MlKemSecretKey,
}

#[pymethods]
impl PyMlKemSecretKey {
    #[getter]
    fn algorithm(&self) -> &'static str {
        self.inner.algorithm()
    }

    fn decapsulate(&self, py: Python<'_>, ciphertext: &[u8]) -> PyResult<Py<PyBytes>> {
        match &self.inner {
            MlKemSecretKey::MlKem512(key) => {
                let expected = <MlKem512 as Kem>::CiphertextSize::USIZE;
                let ciphertext: ml_kem_512::Ciphertext = ciphertext
                    .try_into()
                    .map_err(|_| invalid_length("ciphertext", expected, ciphertext.len()))?;
                Ok(pybytes(py, key.decapsulate(&ciphertext).as_ref()))
            }
            MlKemSecretKey::MlKem768(key) => {
                let expected = <MlKem768 as Kem>::CiphertextSize::USIZE;
                let ciphertext: ml_kem_768::Ciphertext = ciphertext
                    .try_into()
                    .map_err(|_| invalid_length("ciphertext", expected, ciphertext.len()))?;
                Ok(pybytes(py, key.decapsulate(&ciphertext).as_ref()))
            }
            MlKemSecretKey::MlKem1024(key) => {
                let expected = <MlKem1024 as Kem>::CiphertextSize::USIZE;
                let ciphertext: ml_kem_1024::Ciphertext = ciphertext
                    .try_into()
                    .map_err(|_| invalid_length("ciphertext", expected, ciphertext.len()))?;
                Ok(pybytes(py, key.decapsulate(&ciphertext).as_ref()))
            }
        }
    }

    /// Export the compact ML-KEM seed form. This creates an immutable Python bytes copy.
    fn to_seed(&self, py: Python<'_>) -> Py<PyBytes> {
        PyBytes::new(py, &self.inner.seed()).unbind()
    }

    fn __repr__(&self) -> String {
        format!("MlKemSecretKey(algorithm='{}')", self.inner.algorithm())
    }
}

fn normalize_algorithm(algorithm: &str) -> PyResult<&'static str> {
    match algorithm.to_ascii_uppercase().replace('_', "-").as_str() {
        "ML-KEM-512" | "MLKEM512" => Ok("ML-KEM-512"),
        "ML-KEM-768" | "MLKEM768" => Ok("ML-KEM-768"),
        "ML-KEM-1024" | "MLKEM1024" => Ok("ML-KEM-1024"),
        _ => Err(PyValueError::new_err(format!(
            "unsupported ML-KEM algorithm: {algorithm}; use one of ml_kem_algorithms()"
        ))),
    }
}

fn parse_512_secret(seed: &[u8]) -> PyResult<DecapsulationKey512> {
    let expected = <MlKem512 as FromSeed>::SeedSize::USIZE;
    let seed = seed
        .try_into()
        .map_err(|_| invalid_length("secret_key", expected, seed.len()))?;
    Ok(DecapsulationKey512::from_seed(seed))
}

fn parse_768_secret(seed: &[u8]) -> PyResult<DecapsulationKey768> {
    let expected = <MlKem768 as FromSeed>::SeedSize::USIZE;
    let seed = seed
        .try_into()
        .map_err(|_| invalid_length("secret_key", expected, seed.len()))?;
    Ok(DecapsulationKey768::from_seed(seed))
}

fn parse_1024_secret(seed: &[u8]) -> PyResult<DecapsulationKey1024> {
    let expected = <MlKem1024 as FromSeed>::SeedSize::USIZE;
    let seed = seed
        .try_into()
        .map_err(|_| invalid_length("secret_key", expected, seed.len()))?;
    Ok(DecapsulationKey1024::from_seed(seed))
}

#[pyfunction]
fn ml_kem_algorithms() -> Vec<&'static str> {
    vec!["ML-KEM-512", "ML-KEM-768", "ML-KEM-1024"]
}

#[pyfunction]
#[pyo3(signature = (algorithm="ML-KEM-768"))]
fn ml_kem_keygen(py: Python<'_>, algorithm: &str) -> PyResult<(PyMlKemSecretKey, Py<PyBytes>)> {
    match normalize_algorithm(algorithm)? {
        "ML-KEM-512" => {
            let (secret_key, public_key) = MlKem512::generate_keypair();
            Ok((
                PyMlKemSecretKey {
                    inner: MlKemSecretKey::MlKem512(secret_key),
                },
                pybytes(py, public_key.to_bytes().as_ref()),
            ))
        }
        "ML-KEM-768" => {
            let (secret_key, public_key) = MlKem768::generate_keypair();
            Ok((
                PyMlKemSecretKey {
                    inner: MlKemSecretKey::MlKem768(secret_key),
                },
                pybytes(py, public_key.to_bytes().as_ref()),
            ))
        }
        "ML-KEM-1024" => {
            let (secret_key, public_key) = MlKem1024::generate_keypair();
            Ok((
                PyMlKemSecretKey {
                    inner: MlKemSecretKey::MlKem1024(secret_key),
                },
                pybytes(py, public_key.to_bytes().as_ref()),
            ))
        }
        _ => unreachable!(),
    }
}

#[pyfunction]
fn ml_kem_secret_key_from_seed(algorithm: &str, seed: &[u8]) -> PyResult<PyMlKemSecretKey> {
    match normalize_algorithm(algorithm)? {
        "ML-KEM-512" => Ok(PyMlKemSecretKey {
            inner: MlKemSecretKey::MlKem512(parse_512_secret(seed)?),
        }),
        "ML-KEM-768" => Ok(PyMlKemSecretKey {
            inner: MlKemSecretKey::MlKem768(parse_768_secret(seed)?),
        }),
        "ML-KEM-1024" => Ok(PyMlKemSecretKey {
            inner: MlKemSecretKey::MlKem1024(parse_1024_secret(seed)?),
        }),
        _ => unreachable!(),
    }
}

#[pyfunction]
#[pyo3(signature = (public_key, algorithm="ML-KEM-768"))]
fn ml_kem_encapsulate(
    py: Python<'_>,
    public_key: &[u8],
    algorithm: &str,
) -> PyResult<(Py<PyBytes>, Py<PyBytes>)> {
    match normalize_algorithm(algorithm)? {
        "ML-KEM-512" => {
            let expected = <EncapsulationKey512 as KeySizeUser>::KeySize::USIZE;
            let public_key = public_key
                .try_into()
                .map_err(|_| invalid_length("public_key", expected, public_key.len()))?;
            let public_key = EncapsulationKey512::new(&public_key)
                .map_err(|_| PyValueError::new_err("invalid public_key"))?;
            let (ciphertext, shared_secret) = public_key.encapsulate();
            Ok((
                pybytes(py, ciphertext.as_ref()),
                pybytes(py, shared_secret.as_ref()),
            ))
        }
        "ML-KEM-768" => {
            let expected = <EncapsulationKey768 as KeySizeUser>::KeySize::USIZE;
            let public_key = public_key
                .try_into()
                .map_err(|_| invalid_length("public_key", expected, public_key.len()))?;
            let public_key = EncapsulationKey768::new(&public_key)
                .map_err(|_| PyValueError::new_err("invalid public_key"))?;
            let (ciphertext, shared_secret) = public_key.encapsulate();
            Ok((
                pybytes(py, ciphertext.as_ref()),
                pybytes(py, shared_secret.as_ref()),
            ))
        }
        "ML-KEM-1024" => {
            let expected = <EncapsulationKey1024 as KeySizeUser>::KeySize::USIZE;
            let public_key = public_key
                .try_into()
                .map_err(|_| invalid_length("public_key", expected, public_key.len()))?;
            let public_key = EncapsulationKey1024::new(&public_key)
                .map_err(|_| PyValueError::new_err("invalid public_key"))?;
            let (ciphertext, shared_secret) = public_key.encapsulate();
            Ok((
                pybytes(py, ciphertext.as_ref()),
                pybytes(py, shared_secret.as_ref()),
            ))
        }
        _ => unreachable!(),
    }
}

#[pyfunction]
fn ml_kem_decapsulate(
    py: Python<'_>,
    secret_key: &Bound<'_, PyAny>,
    ciphertext: &[u8],
) -> PyResult<Py<PyBytes>> {
    let secret_key = secret_key.extract::<PyRef<'_, PyMlKemSecretKey>>()?;
    secret_key.decapsulate(py, ciphertext)
}

#[pyfunction]
fn ml_kem_512_keygen(py: Python<'_>) -> PyResult<(PyMlKemSecretKey, Py<PyBytes>)> {
    ml_kem_keygen(py, "ML-KEM-512")
}

#[pyfunction]
fn ml_kem_768_keygen(py: Python<'_>) -> PyResult<(PyMlKemSecretKey, Py<PyBytes>)> {
    ml_kem_keygen(py, "ML-KEM-768")
}

#[pyfunction]
fn ml_kem_1024_keygen(py: Python<'_>) -> PyResult<(PyMlKemSecretKey, Py<PyBytes>)> {
    ml_kem_keygen(py, "ML-KEM-1024")
}

#[pyfunction]
fn ml_kem_512_encapsulate(
    py: Python<'_>,
    public_key: &[u8],
) -> PyResult<(Py<PyBytes>, Py<PyBytes>)> {
    ml_kem_encapsulate(py, public_key, "ML-KEM-512")
}

#[pyfunction]
fn ml_kem_768_encapsulate(
    py: Python<'_>,
    public_key: &[u8],
) -> PyResult<(Py<PyBytes>, Py<PyBytes>)> {
    ml_kem_encapsulate(py, public_key, "ML-KEM-768")
}

#[pyfunction]
fn ml_kem_1024_encapsulate(
    py: Python<'_>,
    public_key: &[u8],
) -> PyResult<(Py<PyBytes>, Py<PyBytes>)> {
    ml_kem_encapsulate(py, public_key, "ML-KEM-1024")
}

#[pyfunction]
fn ml_kem_512_decapsulate(
    py: Python<'_>,
    secret_key: &Bound<'_, PyAny>,
    ciphertext: &[u8],
) -> PyResult<Py<PyBytes>> {
    let secret_key = secret_key.extract::<PyRef<'_, PyMlKemSecretKey>>()?;
    match &secret_key.inner {
        MlKemSecretKey::MlKem512(_) => secret_key.decapsulate(py, ciphertext),
        _ => Err(PyTypeError::new_err("secret_key must be an ML-KEM-512 key")),
    }
}

#[pyfunction]
fn ml_kem_768_decapsulate(
    py: Python<'_>,
    secret_key: &Bound<'_, PyAny>,
    ciphertext: &[u8],
) -> PyResult<Py<PyBytes>> {
    let secret_key = secret_key.extract::<PyRef<'_, PyMlKemSecretKey>>()?;
    match &secret_key.inner {
        MlKemSecretKey::MlKem768(_) => secret_key.decapsulate(py, ciphertext),
        _ => Err(PyTypeError::new_err("secret_key must be an ML-KEM-768 key")),
    }
}

#[pyfunction]
fn ml_kem_1024_decapsulate(
    py: Python<'_>,
    secret_key: &Bound<'_, PyAny>,
    ciphertext: &[u8],
) -> PyResult<Py<PyBytes>> {
    let secret_key = secret_key.extract::<PyRef<'_, PyMlKemSecretKey>>()?;
    match &secret_key.inner {
        MlKemSecretKey::MlKem1024(_) => secret_key.decapsulate(py, ciphertext),
        _ => Err(PyTypeError::new_err(
            "secret_key must be an ML-KEM-1024 key",
        )),
    }
}

#[pyfunction]
fn ml_kem_512_secret_key_from_seed(seed: &[u8]) -> PyResult<PyMlKemSecretKey> {
    ml_kem_secret_key_from_seed("ML-KEM-512", seed)
}

#[pyfunction]
fn ml_kem_768_secret_key_from_seed(seed: &[u8]) -> PyResult<PyMlKemSecretKey> {
    ml_kem_secret_key_from_seed("ML-KEM-768", seed)
}

#[pyfunction]
fn ml_kem_1024_secret_key_from_seed(seed: &[u8]) -> PyResult<PyMlKemSecretKey> {
    ml_kem_secret_key_from_seed("ML-KEM-1024", seed)
}

pub(crate) fn register(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_class::<PyMlKemSecretKey>()?;

    module.add_function(wrap_pyfunction!(ml_kem_algorithms, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_keygen, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_secret_key_from_seed, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_encapsulate, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_decapsulate, module)?)?;

    module.add_function(wrap_pyfunction!(ml_kem_512_keygen, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_512_encapsulate, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_512_decapsulate, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_512_secret_key_from_seed, module)?)?;

    module.add_function(wrap_pyfunction!(ml_kem_768_keygen, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_768_encapsulate, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_768_decapsulate, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_768_secret_key_from_seed, module)?)?;

    module.add_function(wrap_pyfunction!(ml_kem_1024_keygen, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_1024_encapsulate, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_1024_decapsulate, module)?)?;
    module.add_function(wrap_pyfunction!(ml_kem_1024_secret_key_from_seed, module)?)?;

    Ok(())
}
