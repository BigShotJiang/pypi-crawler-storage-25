use crate::utils::pybytes;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyBytes;
use slh_dsa::{
    ParameterSet, Sha2_128f, Sha2_128s, Sha2_192f, Sha2_192s, Sha2_256f, Sha2_256s, Shake128f,
    Shake128s, Shake192f, Shake192s, Shake256f, Shake256s, Signature, SigningKey, VerifyingKey,
};

enum SlhDsaSecretKey {
    Sha2_128s(SigningKey<Sha2_128s>),
    Sha2_128f(SigningKey<Sha2_128f>),
    Sha2_192s(SigningKey<Sha2_192s>),
    Sha2_192f(SigningKey<Sha2_192f>),
    Sha2_256s(SigningKey<Sha2_256s>),
    Sha2_256f(SigningKey<Sha2_256f>),
    Shake128s(SigningKey<Shake128s>),
    Shake128f(SigningKey<Shake128f>),
    Shake192s(SigningKey<Shake192s>),
    Shake192f(SigningKey<Shake192f>),
    Shake256s(SigningKey<Shake256s>),
    Shake256f(SigningKey<Shake256f>),
}

impl SlhDsaSecretKey {
    fn algorithm(&self) -> &'static str {
        match self {
            Self::Sha2_128s(_) => "SLH-DSA-SHA2-128s",
            Self::Sha2_128f(_) => "SLH-DSA-SHA2-128f",
            Self::Sha2_192s(_) => "SLH-DSA-SHA2-192s",
            Self::Sha2_192f(_) => "SLH-DSA-SHA2-192f",
            Self::Sha2_256s(_) => "SLH-DSA-SHA2-256s",
            Self::Sha2_256f(_) => "SLH-DSA-SHA2-256f",
            Self::Shake128s(_) => "SLH-DSA-SHAKE-128s",
            Self::Shake128f(_) => "SLH-DSA-SHAKE-128f",
            Self::Shake192s(_) => "SLH-DSA-SHAKE-192s",
            Self::Shake192f(_) => "SLH-DSA-SHAKE-192f",
            Self::Shake256s(_) => "SLH-DSA-SHAKE-256s",
            Self::Shake256f(_) => "SLH-DSA-SHAKE-256f",
        }
    }

    fn private_bytes(&self) -> Vec<u8> {
        match self {
            Self::Sha2_128s(key) => key.to_bytes().to_vec(),
            Self::Sha2_128f(key) => key.to_bytes().to_vec(),
            Self::Sha2_192s(key) => key.to_bytes().to_vec(),
            Self::Sha2_192f(key) => key.to_bytes().to_vec(),
            Self::Sha2_256s(key) => key.to_bytes().to_vec(),
            Self::Sha2_256f(key) => key.to_bytes().to_vec(),
            Self::Shake128s(key) => key.to_bytes().to_vec(),
            Self::Shake128f(key) => key.to_bytes().to_vec(),
            Self::Shake192s(key) => key.to_bytes().to_vec(),
            Self::Shake192f(key) => key.to_bytes().to_vec(),
            Self::Shake256s(key) => key.to_bytes().to_vec(),
            Self::Shake256f(key) => key.to_bytes().to_vec(),
        }
    }

    fn public_key(&self) -> Vec<u8> {
        match self {
            Self::Sha2_128s(key) => key.as_ref().to_bytes().to_vec(),
            Self::Sha2_128f(key) => key.as_ref().to_bytes().to_vec(),
            Self::Sha2_192s(key) => key.as_ref().to_bytes().to_vec(),
            Self::Sha2_192f(key) => key.as_ref().to_bytes().to_vec(),
            Self::Sha2_256s(key) => key.as_ref().to_bytes().to_vec(),
            Self::Sha2_256f(key) => key.as_ref().to_bytes().to_vec(),
            Self::Shake128s(key) => key.as_ref().to_bytes().to_vec(),
            Self::Shake128f(key) => key.as_ref().to_bytes().to_vec(),
            Self::Shake192s(key) => key.as_ref().to_bytes().to_vec(),
            Self::Shake192f(key) => key.as_ref().to_bytes().to_vec(),
            Self::Shake256s(key) => key.as_ref().to_bytes().to_vec(),
            Self::Shake256f(key) => key.as_ref().to_bytes().to_vec(),
        }
    }
}

#[pyclass(module = "lycan", name = "SlhDsaSecretKey")]
struct PySlhDsaSecretKey {
    inner: SlhDsaSecretKey,
}

#[pymethods]
impl PySlhDsaSecretKey {
    #[getter]
    fn algorithm(&self) -> &'static str {
        self.inner.algorithm()
    }

    fn public_key(&self, py: Python<'_>) -> Py<PyBytes> {
        pybytes(py, &self.inner.public_key())
    }

    #[pyo3(signature = (message, context=None))]
    fn sign(
        &self,
        py: Python<'_>,
        message: &[u8],
        context: Option<&[u8]>,
    ) -> PyResult<Py<PyBytes>> {
        let context = context.unwrap_or(b"");
        match &self.inner {
            SlhDsaSecretKey::Sha2_128s(key) => {
                sign_with_context::<Sha2_128s>(py, key, message, context)
            }
            SlhDsaSecretKey::Sha2_128f(key) => {
                sign_with_context::<Sha2_128f>(py, key, message, context)
            }
            SlhDsaSecretKey::Sha2_192s(key) => {
                sign_with_context::<Sha2_192s>(py, key, message, context)
            }
            SlhDsaSecretKey::Sha2_192f(key) => {
                sign_with_context::<Sha2_192f>(py, key, message, context)
            }
            SlhDsaSecretKey::Sha2_256s(key) => {
                sign_with_context::<Sha2_256s>(py, key, message, context)
            }
            SlhDsaSecretKey::Sha2_256f(key) => {
                sign_with_context::<Sha2_256f>(py, key, message, context)
            }
            SlhDsaSecretKey::Shake128s(key) => {
                sign_with_context::<Shake128s>(py, key, message, context)
            }
            SlhDsaSecretKey::Shake128f(key) => {
                sign_with_context::<Shake128f>(py, key, message, context)
            }
            SlhDsaSecretKey::Shake192s(key) => {
                sign_with_context::<Shake192s>(py, key, message, context)
            }
            SlhDsaSecretKey::Shake192f(key) => {
                sign_with_context::<Shake192f>(py, key, message, context)
            }
            SlhDsaSecretKey::Shake256s(key) => {
                sign_with_context::<Shake256s>(py, key, message, context)
            }
            SlhDsaSecretKey::Shake256f(key) => {
                sign_with_context::<Shake256f>(py, key, message, context)
            }
        }
    }

    /// Export the raw SLH-DSA signing key. This creates an immutable Python bytes copy.
    fn to_private_bytes(&self, py: Python<'_>) -> Py<PyBytes> {
        pybytes(py, &self.inner.private_bytes())
    }

    fn __repr__(&self) -> String {
        format!("SlhDsaSecretKey(algorithm='{}')", self.inner.algorithm())
    }
}

fn normalize_algorithm(algorithm: &str) -> PyResult<&'static str> {
    match algorithm.to_ascii_uppercase().replace('_', "-").as_str() {
        "SLH-DSA-SHA2-128S" | "SHA2-128S" => Ok("SLH-DSA-SHA2-128s"),
        "SLH-DSA-SHA2-128F" | "SHA2-128F" => Ok("SLH-DSA-SHA2-128f"),
        "SLH-DSA-SHA2-192S" | "SHA2-192S" => Ok("SLH-DSA-SHA2-192s"),
        "SLH-DSA-SHA2-192F" | "SHA2-192F" => Ok("SLH-DSA-SHA2-192f"),
        "SLH-DSA-SHA2-256S" | "SHA2-256S" => Ok("SLH-DSA-SHA2-256s"),
        "SLH-DSA-SHA2-256F" | "SHA2-256F" => Ok("SLH-DSA-SHA2-256f"),
        "SLH-DSA-SHAKE-128S" | "SHAKE-128S" => Ok("SLH-DSA-SHAKE-128s"),
        "SLH-DSA-SHAKE-128F" | "SHAKE-128F" => Ok("SLH-DSA-SHAKE-128f"),
        "SLH-DSA-SHAKE-192S" | "SHAKE-192S" => Ok("SLH-DSA-SHAKE-192s"),
        "SLH-DSA-SHAKE-192F" | "SHAKE-192F" => Ok("SLH-DSA-SHAKE-192f"),
        "SLH-DSA-SHAKE-256S" | "SHAKE-256S" => Ok("SLH-DSA-SHAKE-256s"),
        "SLH-DSA-SHAKE-256F" | "SHAKE-256F" => Ok("SLH-DSA-SHAKE-256f"),
        _ => Err(PyValueError::new_err(format!(
            "unsupported SLH-DSA algorithm: {algorithm}; use one of slh_dsa_algorithms()"
        ))),
    }
}

fn sign_with_context<P>(
    py: Python<'_>,
    key: &SigningKey<P>,
    message: &[u8],
    context: &[u8],
) -> PyResult<Py<PyBytes>>
where
    P: ParameterSet,
{
    let signature = key
        .try_sign_with_context(message, context, None)
        .map_err(|_| PyValueError::new_err("SLH-DSA signing failed"))?;
    Ok(pybytes(py, signature.to_bytes().as_ref()))
}

fn verify_with_context<P>(
    public_key: &[u8],
    message: &[u8],
    signature: &[u8],
    context: &[u8],
) -> PyResult<bool>
where
    P: ParameterSet,
{
    let public_key = VerifyingKey::<P>::try_from(public_key)
        .map_err(|_| PyValueError::new_err("invalid SLH-DSA public key"))?;
    let signature = Signature::<P>::try_from(signature)
        .map_err(|_| PyValueError::new_err("invalid SLH-DSA signature"))?;
    Ok(public_key
        .try_verify_with_context(message, context, &signature)
        .is_ok())
}

fn key_from_bytes<P>(private_key: &[u8]) -> PyResult<SigningKey<P>>
where
    P: ParameterSet,
{
    SigningKey::<P>::try_from(private_key)
        .map_err(|_| PyValueError::new_err("invalid SLH-DSA private key"))
}

fn keygen<P>(
    py: Python<'_>,
    wrap: impl FnOnce(SigningKey<P>) -> SlhDsaSecretKey,
) -> (PySlhDsaSecretKey, Py<PyBytes>)
where
    P: ParameterSet,
{
    let mut rng = getrandom::rand_core::UnwrapErr(getrandom::SysRng);
    let secret_key = SigningKey::<P>::new(&mut rng);
    let public_key = secret_key.as_ref().to_bytes();
    (
        PySlhDsaSecretKey {
            inner: wrap(secret_key),
        },
        pybytes(py, public_key.as_ref()),
    )
}

#[pyfunction]
fn slh_dsa_algorithms() -> Vec<&'static str> {
    vec![
        "SLH-DSA-SHA2-128s",
        "SLH-DSA-SHA2-128f",
        "SLH-DSA-SHA2-192s",
        "SLH-DSA-SHA2-192f",
        "SLH-DSA-SHA2-256s",
        "SLH-DSA-SHA2-256f",
        "SLH-DSA-SHAKE-128s",
        "SLH-DSA-SHAKE-128f",
        "SLH-DSA-SHAKE-192s",
        "SLH-DSA-SHAKE-192f",
        "SLH-DSA-SHAKE-256s",
        "SLH-DSA-SHAKE-256f",
    ]
}

#[pyfunction]
#[pyo3(signature = (algorithm="SLH-DSA-SHAKE-128f"))]
fn slh_dsa_keygen(py: Python<'_>, algorithm: &str) -> PyResult<(PySlhDsaSecretKey, Py<PyBytes>)> {
    Ok(match normalize_algorithm(algorithm)? {
        "SLH-DSA-SHA2-128s" => keygen::<Sha2_128s>(py, SlhDsaSecretKey::Sha2_128s),
        "SLH-DSA-SHA2-128f" => keygen::<Sha2_128f>(py, SlhDsaSecretKey::Sha2_128f),
        "SLH-DSA-SHA2-192s" => keygen::<Sha2_192s>(py, SlhDsaSecretKey::Sha2_192s),
        "SLH-DSA-SHA2-192f" => keygen::<Sha2_192f>(py, SlhDsaSecretKey::Sha2_192f),
        "SLH-DSA-SHA2-256s" => keygen::<Sha2_256s>(py, SlhDsaSecretKey::Sha2_256s),
        "SLH-DSA-SHA2-256f" => keygen::<Sha2_256f>(py, SlhDsaSecretKey::Sha2_256f),
        "SLH-DSA-SHAKE-128s" => keygen::<Shake128s>(py, SlhDsaSecretKey::Shake128s),
        "SLH-DSA-SHAKE-128f" => keygen::<Shake128f>(py, SlhDsaSecretKey::Shake128f),
        "SLH-DSA-SHAKE-192s" => keygen::<Shake192s>(py, SlhDsaSecretKey::Shake192s),
        "SLH-DSA-SHAKE-192f" => keygen::<Shake192f>(py, SlhDsaSecretKey::Shake192f),
        "SLH-DSA-SHAKE-256s" => keygen::<Shake256s>(py, SlhDsaSecretKey::Shake256s),
        "SLH-DSA-SHAKE-256f" => keygen::<Shake256f>(py, SlhDsaSecretKey::Shake256f),
        _ => unreachable!(),
    })
}

#[pyfunction]
fn slh_dsa_secret_key_from_bytes(
    algorithm: &str,
    private_key: &[u8],
) -> PyResult<PySlhDsaSecretKey> {
    Ok(match normalize_algorithm(algorithm)? {
        "SLH-DSA-SHA2-128s" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Sha2_128s(key_from_bytes::<Sha2_128s>(private_key)?),
        },
        "SLH-DSA-SHA2-128f" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Sha2_128f(key_from_bytes::<Sha2_128f>(private_key)?),
        },
        "SLH-DSA-SHA2-192s" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Sha2_192s(key_from_bytes::<Sha2_192s>(private_key)?),
        },
        "SLH-DSA-SHA2-192f" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Sha2_192f(key_from_bytes::<Sha2_192f>(private_key)?),
        },
        "SLH-DSA-SHA2-256s" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Sha2_256s(key_from_bytes::<Sha2_256s>(private_key)?),
        },
        "SLH-DSA-SHA2-256f" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Sha2_256f(key_from_bytes::<Sha2_256f>(private_key)?),
        },
        "SLH-DSA-SHAKE-128s" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Shake128s(key_from_bytes::<Shake128s>(private_key)?),
        },
        "SLH-DSA-SHAKE-128f" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Shake128f(key_from_bytes::<Shake128f>(private_key)?),
        },
        "SLH-DSA-SHAKE-192s" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Shake192s(key_from_bytes::<Shake192s>(private_key)?),
        },
        "SLH-DSA-SHAKE-192f" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Shake192f(key_from_bytes::<Shake192f>(private_key)?),
        },
        "SLH-DSA-SHAKE-256s" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Shake256s(key_from_bytes::<Shake256s>(private_key)?),
        },
        "SLH-DSA-SHAKE-256f" => PySlhDsaSecretKey {
            inner: SlhDsaSecretKey::Shake256f(key_from_bytes::<Shake256f>(private_key)?),
        },
        _ => unreachable!(),
    })
}

#[pyfunction]
#[pyo3(signature = (secret_key, message, context=None))]
fn slh_dsa_sign(
    py: Python<'_>,
    secret_key: &Bound<'_, PyAny>,
    message: &[u8],
    context: Option<&[u8]>,
) -> PyResult<Py<PyBytes>> {
    let secret_key = secret_key.extract::<PyRef<'_, PySlhDsaSecretKey>>()?;
    secret_key.sign(py, message, context)
}

#[pyfunction]
#[pyo3(signature = (algorithm, public_key, message, signature, context=None))]
fn slh_dsa_verify(
    algorithm: &str,
    public_key: &[u8],
    message: &[u8],
    signature: &[u8],
    context: Option<&[u8]>,
) -> PyResult<bool> {
    let context = context.unwrap_or(b"");
    match normalize_algorithm(algorithm)? {
        "SLH-DSA-SHA2-128s" => {
            verify_with_context::<Sha2_128s>(public_key, message, signature, context)
        }
        "SLH-DSA-SHA2-128f" => {
            verify_with_context::<Sha2_128f>(public_key, message, signature, context)
        }
        "SLH-DSA-SHA2-192s" => {
            verify_with_context::<Sha2_192s>(public_key, message, signature, context)
        }
        "SLH-DSA-SHA2-192f" => {
            verify_with_context::<Sha2_192f>(public_key, message, signature, context)
        }
        "SLH-DSA-SHA2-256s" => {
            verify_with_context::<Sha2_256s>(public_key, message, signature, context)
        }
        "SLH-DSA-SHA2-256f" => {
            verify_with_context::<Sha2_256f>(public_key, message, signature, context)
        }
        "SLH-DSA-SHAKE-128s" => {
            verify_with_context::<Shake128s>(public_key, message, signature, context)
        }
        "SLH-DSA-SHAKE-128f" => {
            verify_with_context::<Shake128f>(public_key, message, signature, context)
        }
        "SLH-DSA-SHAKE-192s" => {
            verify_with_context::<Shake192s>(public_key, message, signature, context)
        }
        "SLH-DSA-SHAKE-192f" => {
            verify_with_context::<Shake192f>(public_key, message, signature, context)
        }
        "SLH-DSA-SHAKE-256s" => {
            verify_with_context::<Shake256s>(public_key, message, signature, context)
        }
        "SLH-DSA-SHAKE-256f" => {
            verify_with_context::<Shake256f>(public_key, message, signature, context)
        }
        _ => unreachable!(),
    }
}

pub(crate) fn register(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_class::<PySlhDsaSecretKey>()?;
    module.add_function(wrap_pyfunction!(slh_dsa_algorithms, module)?)?;
    module.add_function(wrap_pyfunction!(slh_dsa_keygen, module)?)?;
    module.add_function(wrap_pyfunction!(slh_dsa_secret_key_from_bytes, module)?)?;
    module.add_function(wrap_pyfunction!(slh_dsa_sign, module)?)?;
    module.add_function(wrap_pyfunction!(slh_dsa_verify, module)?)?;
    Ok(())
}
