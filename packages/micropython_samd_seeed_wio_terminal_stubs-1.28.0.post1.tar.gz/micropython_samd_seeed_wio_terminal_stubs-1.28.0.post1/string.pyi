"""
Module: 'string' on micropython-v1.28.0-samd-SEEED_WIO_TERMINAL
"""

# MCU: {'variant': '', 'build': '', 'arch': 'armv7emsp', 'port': 'samd', 'board': 'SEEED_WIO_TERMINAL', 'board_id': 'SEEED_WIO_TERMINAL', 'mpy': 'v6.3', 'ver': '1.28.0', 'family': 'micropython', 'cpu': 'SAMD51P19A', 'version': '1.28.0'}
# Stubber: v1.28.0
from __future__ import annotations
from _typeshed import Incomplete
