"""Short-term memory backed by Neruva Records.

CrewAI's ShortTermMemory is for the active crew run. We back it with a
records namespace per crew, kind="short_term" so it's easy to filter
out vs long-term memories in the same project."""
from __future__ import annotations

from typing import Any, Optional

from neruva_crewai.storage import NeruvaStorage


class NeruvaShortTermMemory:
    """Drop-in replacement for crewai.memory.short_term.ShortTermMemory.

    Pass as `short_term_memory=` when building a Crew. Wraps NeruvaStorage
    with kind='short_term' and a per-crew namespace."""

    def __init__(
        self,
        namespace: str = "crew_short_term",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> None:
        self.storage = NeruvaStorage(
            namespace=namespace, kind="short_term",
            api_key=api_key, base_url=base_url, use_kg=False,
        )

    def save(self, value: Any, metadata: Optional[dict] = None,
             agent: Optional[str] = None) -> None:
        self.storage.save(value, metadata=metadata, agent=agent)

    def search(self, query: str, limit: int = 3,
               score_threshold: float = 0.0) -> list:
        return self.storage.search(query, limit=limit,
                                    score_threshold=score_threshold)

    def reset(self) -> None:
        self.storage.reset()
