"""CrewAI Storage backend backed by Neruva.

CrewAI's memory system uses a `Storage` abstract interface with three
methods: save / search / reset. We implement it on top of Neruva's
agent_remember + agent_recall, getting persistence + cross-run recall
for free.

For EntityMemory the same backend can opt-in to triple binding via
`use_kg=True` -- caller's metadata dict can include a `triples` list
that gets bound to the HD KG alongside the records write."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from neruva_crewai._client import NeruvaClient


class NeruvaStorage:
    """Implements CrewAI's `Storage` interface (save / search / reset).

    Not subclassed from crewai.memory.storage.interface.Storage because
    CrewAI's interface has shifted between versions. Duck-typed.

    Parameters
    ----------
    namespace : str
        Records namespace. One per crew / agent / domain.
    kind : str
        Records kind tag for filterability. Defaults to 'crew_memory'.
    api_key : str | None
        Neruva API key. Reads NERUVA_API_KEY from env if not provided.
    base_url : str | None
        Override the substrate URL. Defaults to https://api.neruva.io.
    use_kg : bool
        If True, EntityMemory-style triple binding is enabled. The
        metadata dict passed to save() can include a `triples` key with
        a [[s, p, o], ...] list which is bound to the HD KG.
    """

    def __init__(
        self,
        namespace: str,
        kind: str = "crew_memory",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        use_kg: bool = False,
    ) -> None:
        self._client = NeruvaClient(api_key=api_key, base_url=base_url)
        self.namespace = namespace
        self.kind = kind
        self.use_kg = bool(use_kg)

    # --- CrewAI Storage interface ----------------------------------

    def save(self, value: Any, metadata: Optional[Dict[str, Any]] = None,
             agent: Optional[str] = None, **_kw: Any) -> None:
        """Persist a memory. `value` is stringified into the record's
        text field; `metadata` flattens into tags (string-only) + an
        optional `triples` key for KG binding."""
        text = str(value)
        if not text.strip():
            return
        tags: List[str] = ["crewai", f"kind:{self.kind}"]
        if agent:
            tags.append(f"agent:{agent}")
        triples = None
        if metadata:
            triples = metadata.get("triples") if self.use_kg else None
            for k, v in metadata.items():
                if k == "triples":
                    continue
                if isinstance(v, (str, int, float, bool)):
                    tags.append(f"{k}:{v}")
        self._client.agent_remember(
            text=text,
            namespace=self.namespace,
            tags=tags,
            kind=self.kind,
            triples=triples,
        )

    def search(
        self,
        query: str,
        limit: int = 3,
        score_threshold: float = 0.0,
    ) -> List[Dict[str, Any]]:
        """Semantic recall. Returns [{context, score, metadata}, ...] in
        the shape CrewAI's downstream memory classes expect."""
        if not query or not query.strip():
            return []
        result = self._client.agent_recall(
            query=query,
            namespace=self.namespace,
            top_k=int(limit),
        )
        out: List[Dict[str, Any]] = []
        for r in result.get("records", []):
            score = float(r.get("score", 0.0))
            if score < float(score_threshold):
                continue
            out.append({
                "context": r.get("text", ""),
                "score": score,
                "metadata": {
                    "id": r.get("id"),
                    "kind": r.get("kind"),
                    "tags": r.get("tags") or [],
                    "ts": r.get("ts"),
                },
            })
        return out

    def reset(self) -> None:
        """CrewAI calls reset() to clear the memory. We deliberately
        no-op to prevent accidental wipes; explicit cleanup goes
        through records_forget with a predicate filter."""
        pass
