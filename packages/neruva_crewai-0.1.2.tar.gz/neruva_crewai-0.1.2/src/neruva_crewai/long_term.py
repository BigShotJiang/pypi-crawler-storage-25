"""Long-term memory backed by Neruva Records.

Persistent across crew runs. Same backend as short-term but with a
different kind tag for filterability + a separate namespace if
desired. Use this for 'remember what we learned in prior crew runs'."""
from __future__ import annotations

from typing import Any, Optional

from neruva_crewai.storage import NeruvaStorage


class NeruvaLongTermMemory:
    """Drop-in replacement for crewai.memory.long_term.LongTermMemory.

    Persists across process restarts via GCS. Cross-run recall via
    agent_recall semantic search."""

    def __init__(
        self,
        namespace: str = "crew_long_term",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> None:
        self.storage = NeruvaStorage(
            namespace=namespace, kind="long_term",
            api_key=api_key, base_url=base_url, use_kg=False,
        )

    def save(self, value: Any, metadata: Optional[dict] = None,
             agent: Optional[str] = None) -> None:
        self.storage.save(value, metadata=metadata, agent=agent)

    def search(self, query: str, limit: int = 3,
               score_threshold: float = 0.0) -> list:
        return self.storage.search(query, limit=limit,
                                    score_threshold=score_threshold)

    def reset(self) -> None:
        self.storage.reset()
