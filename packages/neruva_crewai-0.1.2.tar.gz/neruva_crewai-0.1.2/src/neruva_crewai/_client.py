"""Thin HTTP client around api.neruva.io. No substrate internals here --
just the REST shapes the LangChain wrappers need (agent_remember,
agent_recall, agent_context, records_query). Pure stdlib + httpx so we
don't drag in heavy deps."""
from __future__ import annotations

import os
from typing import Any, Optional

import httpx


DEFAULT_BASE_URL = "https://api.neruva.io"


class NeruvaClient:
    """Tiny synchronous client for the substrate endpoints used by the
    LangChain integration. Falls back to env vars NERUVA_API_KEY +
    NERUVA_URL so a chain can be constructed without explicit args."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout_s: float = 30.0,
    ) -> None:
        self.api_key = api_key or os.environ.get("NERUVA_API_KEY")
        if not self.api_key:
            raise RuntimeError(
                "NERUVA_API_KEY not provided -- pass api_key= or set the "
                "NERUVA_API_KEY env var. Get a key at app.neruva.io."
            )
        self.base_url = (
            base_url
            or os.environ.get("NERUVA_URL")
            or DEFAULT_BASE_URL
        ).rstrip("/")
        self._http = httpx.Client(timeout=timeout_s)

    def _post(self, path: str, body: dict) -> Any:
        r = self._http.post(
            self.base_url + path,
            headers={"Api-Key": self.api_key, "Content-Type": "application/json"},
            json=body,
        )
        if r.status_code >= 400:
            raise RuntimeError(f"POST {path} -> {r.status_code}: {r.text}")
        return r.json()

    def _get(self, path: str) -> Any:
        r = self._http.get(
            self.base_url + path,
            headers={"Api-Key": self.api_key},
        )
        if r.status_code >= 400:
            raise RuntimeError(f"GET {path} -> {r.status_code}: {r.text}")
        return r.json()

    # ---- agent_* federated endpoints ----------------------------------

    def agent_remember(
        self,
        text: str,
        namespace: Optional[str] = None,
        tags: Optional[list] = None,
        kind: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> dict:
        body: dict = {"text": text}
        if namespace: body["namespace"] = namespace
        if tags: body["tags"] = tags
        if kind: body["kind"] = kind
        if user_id: body["user_id"] = user_id
        return self._post("/v1/agent/remember", body)

    def agent_recall(
        self,
        query: str,
        namespace: Optional[str] = None,
        namespaces: Optional[list] = None,
        top_k: int = 10,
        user_id: Optional[str] = None,
    ) -> dict:
        body: dict = {"query": query, "top_k": top_k}
        if namespace: body["namespace"] = namespace
        if namespaces: body["namespaces"] = namespaces
        if user_id: body["user_id"] = user_id
        return self._post("/v1/agent/recall", body)

    def agent_context(
        self,
        question: str,
        namespace: Optional[str] = None,
        top_k: int = 10,
        max_chars: int = 4000,
        user_id: Optional[str] = None,
    ) -> dict:
        body: dict = {
            "question": question,
            "top_k": top_k,
            "max_chars": max_chars,
        }
        if namespace: body["namespace"] = namespace
        if user_id: body["user_id"] = user_id
        return self._post("/v1/agent/context", body)

    # ---- records ------------------------------------------------------

    def records_query(
        self,
        namespace: str,
        text: Optional[str] = None,
        top_k: int = 10,
        kinds: Optional[list] = None,
        user_id: Optional[str] = None,
    ) -> dict:
        body: dict = {"topK": top_k}
        if text: body["text"] = text
        if kinds: body["kind"] = kinds
        if user_id: body["userId"] = user_id
        return self._post(f"/v1/records/{namespace}/query", body)

    def records_timeline(
        self,
        namespace: str,
        limit: int = 50,
        kinds: Optional[list] = None,
    ) -> dict:
        qs = f"limit={int(limit)}"
        if kinds:
            qs += f"&kind={','.join(kinds)}"
        return self._get(f"/v1/records/{namespace}/timeline?{qs}")

    def close(self) -> None:
        self._http.close()
