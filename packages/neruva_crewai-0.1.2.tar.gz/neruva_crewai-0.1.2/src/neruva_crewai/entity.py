"""Entity memory backed by the Neruva HD knowledge graph.

CrewAI's EntityMemory tracks named entities + their relationships
across crew runs. We back this with the HD KG: entities become atoms,
relationships become bound (subject, predicate, object) triples on
selected KG shards. Sub-ms entity-relation queries via cosine cleanup.

Use the canonical hd_kg_extraction_prompt to have your own LLM extract
triples, then pass them in via metadata['triples'] when calling save()."""
from __future__ import annotations

from typing import Any, Optional

from neruva_crewai.storage import NeruvaStorage


class NeruvaEntityMemory:
    """Drop-in replacement for crewai.memory.entity.EntityMemory.

    Backed by HD KG (OPB engine) under the hood. Pass extracted
    triples via metadata['triples'] when saving; recall via semantic
    search across the entity store."""

    def __init__(
        self,
        namespace: str = "crew_entities",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> None:
        # use_kg=True enables triple binding from metadata
        self.storage = NeruvaStorage(
            namespace=namespace, kind="entity",
            api_key=api_key, base_url=base_url, use_kg=True,
        )

    def save(self, value: Any, metadata: Optional[dict] = None,
             agent: Optional[str] = None) -> None:
        """Save an entity. If metadata includes a 'triples' list (
        [[subject, predicate, object], ...]), those facts get bound to
        the HD KG alongside the records entry."""
        self.storage.save(value, metadata=metadata, agent=agent)

    def search(self, query: str, limit: int = 3,
               score_threshold: float = 0.0) -> list:
        return self.storage.search(query, limit=limit,
                                    score_threshold=score_threshold)

    def reset(self) -> None:
        self.storage.reset()
