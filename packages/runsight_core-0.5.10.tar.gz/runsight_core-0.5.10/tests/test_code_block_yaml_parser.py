"""
CodeBlock parser registration and achat token breakdown behavior.

These tests cover:
1. Parser: BLOCK_TYPE_REGISTRY includes "code" type
2. Parser: parse_workflow_yaml handles type: code → CodeBlock instance
3. Parser: CodeBlock with custom timeout_seconds and allowed_imports via YAML
4. Parser: CodeBlock with no `code` field → schema validation error
5. Parser: Direct builder test via BLOCK_TYPE_REGISTRY["code"] with mock BlockDef
6. achat: returns prompt_tokens, completion_tokens alongside total_tokens
7. achat: response.usage is None → defaults to 0 for all token fields
8. achat: response.usage exists but prompt_tokens/completion_tokens are None → default to 0
9. achat: backward-compat — callers using only content, cost_usd, total_tokens still work
"""

from unittest.mock import MagicMock

import pytest
from pydantic import ValidationError
from runsight_core import CodeBlock
from runsight_core.blocks._registry import BLOCK_BUILDER_REGISTRY as BLOCK_TYPE_REGISTRY
from runsight_core.workflow import Workflow
from runsight_core.yaml.parser import parse_workflow_yaml
from runsight_core.yaml.schema import BlockDef
from workflow_fixture_helpers import workflow_fixture_text

# ---------------------------------------------------------------------------
# 1. BLOCK_TYPE_REGISTRY includes "code"
# ---------------------------------------------------------------------------


class TestCodeBlockRegistration:
    def test_code_type_in_block_registry(self):
        """BLOCK_TYPE_REGISTRY must contain a 'code' builder."""
        assert "code" in BLOCK_TYPE_REGISTRY

    def test_code_builder_is_callable(self):
        """The 'code' builder must be callable."""
        assert callable(BLOCK_TYPE_REGISTRY["code"])


# ---------------------------------------------------------------------------
# 2. parse_workflow_yaml with type: code → CodeBlock
# ---------------------------------------------------------------------------


class TestCodeBlockParsing:
    def test_parse_code_block_returns_workflow(self):
        """parse_workflow_yaml with type: code must return a valid Workflow."""
        wf = parse_workflow_yaml(workflow_fixture_text("code-block-parser-basic.yaml"))
        assert isinstance(wf, Workflow)
        assert wf.name == "code_parser_workflow"

    def test_parsed_code_block_is_codeblock_instance(self):
        """The block built by the parser must be a CodeBlock instance."""
        wf = parse_workflow_yaml(workflow_fixture_text("code-block-parser-basic.yaml"))
        # Workflow stores blocks keyed by block_id
        block = wf.blocks.get("transform")
        assert block is not None
        assert isinstance(block, CodeBlock)

    def test_parsed_code_block_has_code(self):
        """The parsed CodeBlock must carry the code source from YAML."""
        wf = parse_workflow_yaml(workflow_fixture_text("code-block-parser-basic.yaml"))
        block = wf.blocks["transform"]
        assert hasattr(block, "code")
        assert "def main(data)" in block.code


# ---------------------------------------------------------------------------
# 3. CodeBlock with custom timeout and allowed_imports via YAML
# ---------------------------------------------------------------------------


class TestCodeBlockParsingOptions:
    def test_custom_timeout_seconds(self):
        """Parser must pass timeout_seconds from YAML to CodeBlock."""
        wf = parse_workflow_yaml(workflow_fixture_text("code-block-parser-custom-options.yaml"))
        block = wf.blocks["compute"]
        assert isinstance(block, CodeBlock)
        assert block.timeout_seconds == 10

    def test_custom_allowed_imports(self):
        """Parser must pass allowed_imports from YAML to CodeBlock."""
        wf = parse_workflow_yaml(workflow_fixture_text("code-block-parser-custom-options.yaml"))
        block = wf.blocks["compute"]
        assert isinstance(block, CodeBlock)
        assert block.allowed_imports == ["math"]


# ---------------------------------------------------------------------------
# 4. CodeBlock with missing `code` field → Pydantic ValidationError
# ---------------------------------------------------------------------------


class TestCodeBlockSchemaValidation:
    def test_missing_code_field_raises_validation_error(self):
        """type: code without a `code` field must fail at Pydantic schema level."""
        with pytest.raises((ValidationError, ValueError), match=r"(?i)code"):
            parse_workflow_yaml(workflow_fixture_text("code-block-parser-missing-code.yaml"))


# ---------------------------------------------------------------------------
# 5. Direct builder test: BLOCK_TYPE_REGISTRY["code"] with mock BlockDef
# ---------------------------------------------------------------------------


class TestCodeBlockDirectBuilder:
    def test_builder_returns_codeblock_instance(self):
        """Calling BLOCK_TYPE_REGISTRY['code'] with a mock BlockDef must return a CodeBlock."""
        block_def = MagicMock(spec=BlockDef)
        block_def.type = "code"
        block_def.code = "def main(data):\n    return {'x': 1}\n"
        block_def.timeout_seconds = 5
        block_def.allowed_imports = ["json"]

        builder = BLOCK_TYPE_REGISTRY["code"]
        result = builder("test_block", block_def, {}, MagicMock(), {})

        assert isinstance(result, CodeBlock)

    def test_builder_passes_code_field(self):
        """The builder must forward the code field from BlockDef to CodeBlock."""
        code_src = "def main(data):\n    return {}\n"
        block_def = MagicMock(spec=BlockDef)
        block_def.type = "code"
        block_def.code = code_src
        block_def.timeout_seconds = 30
        block_def.allowed_imports = []

        builder = BLOCK_TYPE_REGISTRY["code"]
        result = builder("cb_1", block_def, {}, MagicMock(), {})

        assert hasattr(result, "code")
        assert result.code == code_src


# ---------------------------------------------------------------------------
# 6. achat returns prompt_tokens + completion_tokens
# ---------------------------------------------------------------------------
