"""on_error modes on sub-workflow nodes.

WorkflowBlock accepts an ``on_error`` parameter and WorkflowBlockDef has an
``on_error`` field. These tests exercise the contract that:

  - WorkflowBlock.__init__ accepts ``on_error``
  - WorkflowBlockDef exposes an ``on_error`` field
  - WorkflowBlock.execute() catches child exceptions when configured to produce an
    ``exit_handle="error"`` result
  - child_status="failed" and child_error metadata are produced for caught failures

Expected behavior:
  1. ``raise`` propagates the child exception
  2. ``catch`` produces a normal BlockResult with exit_handle="error"
  3. Parent status and child status remain distinguishable in monitoring
  4. No alternate/legacy error-routing path for callable sub-workflows
"""

from __future__ import annotations

import pytest
from pydantic import ValidationError
from runsight_core.block_io import apply_block_output, build_block_context
from runsight_core.blocks.workflow_block import WorkflowBlock, WorkflowBlockDef
from runsight_core.state import BlockResult, WorkflowState
from runsight_core.workflow import Workflow


async def _exec(block, state, **extra_inputs):
    """Helper: build BlockContext, execute block, apply output to state."""
    ctx = build_block_context(block, state)
    if extra_inputs:
        ctx = ctx.model_copy(update={"inputs": {**ctx.inputs, **extra_inputs}})
    output = await block.execute(ctx)
    return apply_block_output(state, block.block_id, output)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FailingBlock:
    """Fake block that always raises during execute."""

    def __init__(self, block_id: str, *, error_msg: str = "child block failed"):
        self.block_id = block_id
        self.retry_config = None
        self.stateful = False
        self._error_msg = error_msg

    async def execute(self, ctx) -> WorkflowState:
        raise RuntimeError(self._error_msg)


def _build_child_workflow(name: str, block: object) -> Workflow:
    """Build a single-block child workflow for testing."""
    wf = Workflow(name=name)
    wf.add_block(block)
    wf.set_entry(block.block_id)
    return wf


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
class TestOnErrorModes:
    """All tests target WorkflowBlock on_error behavior."""

    async def test_on_error_raise_propagates_child_exception(self) -> None:
        """
        With on_error="raise" (explicit), the child exception propagates to
        the caller unchanged.
        """
        child_block = _FailingBlock("raise_error_step", error_msg="kaboom")
        child_workflow = _build_child_workflow("raise_error_child_workflow", child_block)

        wb = WorkflowBlock(
            block_id="raise_child_error_workflow_block",
            child_workflow=child_workflow,
            inputs={"topic": "shared_memory.parent_topic"},
            outputs={},
            on_error="raise",
        )

        parent_state = WorkflowState(
            shared_memory={"parent_topic": "testing"},
        )

        with pytest.raises(RuntimeError, match="kaboom"):
            await _exec(wb, parent_state)

    async def test_on_error_catch_returns_error_exit_handle(self) -> None:
        """
        With on_error="catch", child failure does not propagate. Instead,
        execute() returns a WorkflowState where the BlockResult for this block
        has exit_handle="error".
        """
        child_block = _FailingBlock("catch_error_step", error_msg="child exploded")
        child_workflow = _build_child_workflow("catch_error_child_workflow", child_block)

        wb = WorkflowBlock(
            block_id="caught_child_error_workflow_block",
            child_workflow=child_workflow,
            inputs={"topic": "shared_memory.parent_topic"},
            outputs={},
            on_error="catch",
        )

        parent_state = WorkflowState(
            shared_memory={"parent_topic": "testing"},
        )

        # Must NOT raise — the error is caught
        result_state = await _exec(wb, parent_state)

        br = result_state.results.get("caught_child_error_workflow_block")
        assert br is not None, "WorkflowBlock must store its own BlockResult even on catch"
        assert isinstance(br, BlockResult)
        assert br.exit_handle == "error", (
            f"exit_handle must be 'error' for caught child failure, got '{br.exit_handle}'"
        )

    async def test_on_error_catch_metadata_includes_child_status_failed(self) -> None:
        """
        With on_error="catch", BlockResult.metadata includes
        child_status="failed" so parent and child status are distinguishable.
        """
        child_block = _FailingBlock("metadata_status_failure_step")
        child_workflow = _build_child_workflow("metadata_status_child_workflow", child_block)

        wb = WorkflowBlock(
            block_id="child_status_metadata_workflow_block",
            child_workflow=child_workflow,
            inputs={"topic": "shared_memory.parent_topic"},
            outputs={},
            on_error="catch",
        )

        parent_state = WorkflowState(
            shared_memory={"parent_topic": "testing"},
        )

        result_state = await _exec(wb, parent_state)

        br = result_state.results["child_status_metadata_workflow_block"]
        assert br.metadata is not None, "metadata must be populated on catch"
        assert br.metadata.get("child_status") == "failed", (
            f"child_status must be 'failed', got '{br.metadata.get('child_status')}'"
        )

    async def test_on_error_catch_metadata_includes_error_message(self) -> None:
        """
        Metadata includes the error message so the parent workflow can inspect
        what went wrong without re-raising.
        """
        child_block = _FailingBlock("timeout_failure_step", error_msg="timeout reached")
        child_workflow = _build_child_workflow("error_message_child_workflow", child_block)

        wb = WorkflowBlock(
            block_id="child_error_metadata_workflow_block",
            child_workflow=child_workflow,
            inputs={"topic": "shared_memory.parent_topic"},
            outputs={},
            on_error="catch",
        )

        parent_state = WorkflowState(
            shared_memory={"parent_topic": "testing"},
        )

        result_state = await _exec(wb, parent_state)

        br = result_state.results["child_error_metadata_workflow_block"]
        assert br.metadata is not None
        assert "child_error" in br.metadata, "metadata must include 'child_error' key"
        assert "timeout reached" in br.metadata["child_error"], (
            f"child_error must contain the exception message, got '{br.metadata.get('child_error')}'"
        )

    async def test_on_error_catch_does_not_map_outputs(self) -> None:
        """
        When on_error="catch" and the child fails, output mapping must NOT
        happen (child state is incomplete/absent). The parent state should
        remain unchanged except for the WorkflowBlock's own BlockResult.
        """
        child_block = _FailingBlock("failing_writer_step", error_msg="writer crashed")
        child_workflow = _build_child_workflow("failed_output_mapping_child_workflow", child_block)

        wb = WorkflowBlock(
            block_id="failed_output_mapping_workflow_block",
            child_workflow=child_workflow,
            inputs={"topic": "shared_memory.parent_topic"},
            outputs={"results.analysis": "results.failing_writer_step"},
            on_error="catch",
        )

        parent_state = WorkflowState(
            shared_memory={"parent_topic": "testing"},
        )

        result_state = await _exec(wb, parent_state)

        # The child crashed, so "results.analysis" should NOT exist in parent
        assert "analysis" not in result_state.results, (
            "Output mapping must be skipped when child fails under on_error='catch'"
        )

        # But the WorkflowBlock's own result must exist
        br = result_state.results.get("failed_output_mapping_workflow_block")
        assert br is not None
        assert br.exit_handle == "error"

    async def test_on_error_default_is_raise(self) -> None:
        """
        When on_error is NOT specified, the default behavior must be
        identical to on_error="raise" — the child exception propagates.
        """
        child_block = _FailingBlock("default_raise_failure_step", error_msg="default should raise")
        child_workflow = _build_child_workflow("default_raise_child_workflow", child_block)

        # on_error not passed — should default to "raise"
        wb = WorkflowBlock(
            block_id="default_raise_workflow_block",
            child_workflow=child_workflow,
            inputs={"topic": "shared_memory.parent_topic"},
            outputs={},
        )

        parent_state = WorkflowState(
            shared_memory={"parent_topic": "testing"},
        )

        with pytest.raises(RuntimeError, match="default should raise"):
            await _exec(wb, parent_state)


class TestWorkflowBlockDefOnErrorField:
    """Schema tests for the on_error field on WorkflowBlockDef."""

    def test_workflow_block_def_accepts_on_error_raise(self) -> None:
        """WorkflowBlockDef must accept on_error='raise'."""
        block_def = WorkflowBlockDef(
            type="workflow",
            workflow_ref="on_error_raise_child_workflow",
            on_error="raise",
        )
        assert block_def.on_error == "raise"

    def test_workflow_block_def_accepts_on_error_catch(self) -> None:
        """WorkflowBlockDef must accept on_error='catch'."""
        block_def = WorkflowBlockDef(
            type="workflow",
            workflow_ref="on_error_catch_child_workflow",
            on_error="catch",
        )
        assert block_def.on_error == "catch"

    def test_workflow_block_def_default_on_error_is_raise(self) -> None:
        """When on_error is not specified, the default must be 'raise'."""
        block_def = WorkflowBlockDef(
            type="workflow",
            workflow_ref="default_on_error_child_workflow",
        )
        assert block_def.on_error == "raise"

    def test_workflow_block_def_rejects_invalid_on_error(self) -> None:
        """Invalid on_error values must be rejected by Pydantic.

        The field must exist and accept valid Literal values. An invalid
        value like "ignore" must be rejected with a validation error that
        mentions the allowed values, NOT rejected as an unknown extra field.
        """
        # First, confirm valid values are accepted (field exists)
        valid = WorkflowBlockDef(
            type="workflow",
            workflow_ref="invalid_on_error_child_workflow",
            on_error="raise",
        )
        assert valid.on_error == "raise"

        # Then confirm invalid value is rejected
        with pytest.raises(ValidationError, match="raise|catch"):
            WorkflowBlockDef(
                type="workflow",
                workflow_ref="invalid_on_error_child_workflow",
                on_error="ignore",
            )
