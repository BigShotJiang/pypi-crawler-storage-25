"""
Tests for WorkflowState data model.
"""

from runsight_core.state import BlockResult, WorkflowState


def test_workflow_state_initialization():
    """Verify WorkflowState initializes with empty defaults."""
    state = WorkflowState()
    assert state.execution_log == []
    assert state.shared_memory == {}
    assert state.results == {}
    assert state.metadata == {}
    assert state.total_cost_usd == 0.0
    assert state.total_tokens == 0


def test_workflow_state_immutability():
    """Verify model_copy creates a new instance."""
    state1 = WorkflowState(results={"a": BlockResult(output="output1")})
    state2 = state1.model_copy(update={"results": {"b": BlockResult(output="output2")}})

    # state1 unchanged (immutability)
    assert state1.results == {"a": BlockResult(output="output1")}
    assert state2.results == {"b": BlockResult(output="output2")}
    assert state1 is not state2


def test_workflow_state_model_fields():
    """Verify required workflow state fields exist."""
    fields = set(WorkflowState.model_fields.keys())
    required = {
        "execution_log",
        "shared_memory",
        "results",
        "metadata",
        "total_cost_usd",
        "total_tokens",
    }
    assert required.issubset(fields)


def test_workflow_state_with_all_fields():
    """Verify WorkflowState can be initialized with all fields."""
    state = WorkflowState(
        execution_log=[{"role": "system", "content": "Hello"}],
        shared_memory={"key": "value"},
        results={"block1": BlockResult(output="output1")},
        metadata={"blueprint_name": "review_blueprint"},
        total_cost_usd=0.05,
        total_tokens=100,
    )

    assert len(state.execution_log) == 1
    assert state.execution_log[0]["role"] == "system"
    assert state.shared_memory["key"] == "value"
    assert state.results["block1"].output == "output1"
    assert state.metadata["blueprint_name"] == "review_blueprint"
    assert state.total_cost_usd == 0.05
    assert state.total_tokens == 100


def test_workflow_state_model_copy_preserves_other_fields():
    """Verify model_copy with update preserves other fields."""
    state1 = WorkflowState(
        results={"a": BlockResult(output="output1")},
        metadata={"key": "value"},
        total_cost_usd=0.01,
        total_tokens=50,
    )
    state2 = state1.model_copy(
        update={"results": {"a": BlockResult(output="output1"), "b": BlockResult(output="output2")}}
    )

    # Original state unchanged
    assert state1.results == {"a": BlockResult(output="output1")}
    assert state1.metadata == {"key": "value"}
    assert state1.total_cost_usd == 0.01
    assert state1.total_tokens == 50

    # New state has updates and preserves metadata
    assert state2.results == {
        "a": BlockResult(output="output1"),
        "b": BlockResult(output="output2"),
    }
    assert state2.metadata == {"key": "value"}
    assert state2.total_cost_usd == 0.01
    assert state2.total_tokens == 50
