import logging
import os
import json
from typing import Any, Callable, Dict, List, Optional

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

# Import exceptions
from excel_mcp.exceptions import (
    ValidationError,
    WorkbookError,
    SheetError,
    DataError,
    FormattingError,
    CalculationError,
    PivotError,
    ChartError,
    ResponseTooLargeError,
)

# Import from excel_mcp package with consistent _impl suffixes
from excel_mcp.validation import (
    validate_formula_in_cell_operation as validate_formula_impl,
    validate_range_in_sheet_operation as validate_range_impl
)
from excel_mcp.calculations import inspect_formula as inspect_formula_impl
from excel_mcp.chart import (
    create_chart_from_series as create_chart_from_series_impl,
    create_chart_in_sheet as create_chart_impl,
    find_free_canvas_slots as find_free_canvas_impl,
    list_charts as list_charts_impl,
)
from excel_mcp.workbook import (
    apply_workbook_repairs as apply_workbook_repairs_impl,
    analyze_range_impact as analyze_range_impact_impl,
    audit_workbook as audit_workbook_impl,
    detect_circular_dependencies as detect_circular_dependencies_impl,
    delete_named_range as delete_named_range_impl,
    describe_sheet_layout as describe_sheet_layout_impl,
    diff_workbooks as diff_workbooks_impl,
    explain_formula_cell as explain_formula_cell_impl,
    get_workbook_info,
    inspect_conditional_format_rules as inspect_conditional_format_rules_impl,
    inspect_data_validation_rules as inspect_data_validation_rules_impl,
    inspect_named_range as inspect_named_range_impl,
    list_named_ranges as list_named_ranges_impl,
    plan_workbook_repairs as plan_workbook_repairs_impl,
    profile_workbook as profile_workbook_impl,
    remove_conditional_format_rules as remove_conditional_format_rules_impl,
    remove_data_validation_rules as remove_data_validation_rules_impl,
    require_worksheet,
)
from excel_mcp.data import (
    append_table_rows as append_table_rows_impl,
    describe_dataset as describe_dataset_impl,
    quick_read as quick_read_impl,
    read_as_table,
    search_cells,
    suggest_read_strategy as suggest_read_strategy_impl,
    update_rows_by_key as update_rows_by_key_impl,
    write_data,
)
from excel_mcp.query import (
    aggregate_table as aggregate_table_impl,
    bulk_aggregate_workbooks as bulk_aggregate_workbooks_impl,
    cross_workbook_lookup as cross_workbook_lookup_impl,
    bulk_filter_workbooks as bulk_filter_workbooks_impl,
    query_table as query_table_impl,
    union_tables as union_tables_impl,
)
from excel_mcp.pivot import create_pivot_table as create_pivot_table_impl
from excel_mcp.tables import (
    create_excel_table as create_table_impl,
    list_excel_tables as list_tables_impl,
    read_excel_table as read_excel_table_impl,
    upsert_excel_table_rows as upsert_excel_table_rows_impl,
)
from excel_mcp.sheet import (
    autofit_columns as autofit_columns_impl,
    copy_sheet,
    delete_sheet,
    get_sheet_protection as get_sheet_protection_impl,
    set_print_area as set_print_area_impl,
    set_print_titles as set_print_titles_impl,
    set_sheet_protection as set_sheet_protection_impl,
    rename_sheet,
    set_sheet_visibility,
    merge_range,
    unmerge_range,
    get_merged_ranges,
    set_auto_filter,
    set_freeze_panes,
    set_column_widths as set_column_widths_impl,
    set_row_heights as set_row_heights_impl,
    insert_row,
    insert_cols,
    delete_rows,
    delete_cols,
)

# Get project root directory path for log file path.
# When using the stdio transmission method,
# relative paths may cause log files to fail to create
# due to the client's running location and permission issues,
# resulting in the program not being able to run.
# Thus using os.path.join(ROOT_DIR, "excel-mcp.log") instead.

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LOG_FILE = os.path.join(ROOT_DIR, "excel-mcp.log")

# Initialize EXCEL_FILES_PATH variable without assigning a value
EXCEL_FILES_PATH = None

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        # Referring to https://github.com/modelcontextprotocol/python-sdk/issues/409#issuecomment-2816831318
        # The stdio mode server MUST NOT write anything to its stdout that is not a valid MCP message.
        logging.FileHandler(LOG_FILE)
    ],
)
logger = logging.getLogger("excel-mcp")
# Initialize FastMCP server
mcp = FastMCP(
    "sheetforge-mcp",
    host=os.environ.get("FASTMCP_HOST", "127.0.0.1"),
    port=int(os.environ.get("FASTMCP_PORT", "8017")),
    instructions="SheetForge MCP for manipulating Excel workbooks"
)

HANDLED_TOOL_ERRORS = (
    ValidationError,
    WorkbookError,
    SheetError,
    DataError,
    FormattingError,
    CalculationError,
    PivotError,
    ChartError,
    ResponseTooLargeError,
    ValueError,
    FileNotFoundError,
)

MCP_RESPONSE_CHAR_LIMIT = 50_000


def _extract_payload_parts(result: Any) -> tuple[Optional[str], Any, Dict[str, Any]]:
    if isinstance(result, dict):
        payload = dict(result)
        message = payload.pop("message", None)
        meta = {}
        for key in ("dry_run", "changes", "warnings", "preview"):
            if key in payload:
                meta[key] = payload.pop(key)
        data = payload or None
        return message, data, meta

    if isinstance(result, str):
        return result, None, {}

    return None, result, {}


def _serialize_json(payload: Dict[str, Any]) -> str:
    return json.dumps(payload, separators=(",", ":"), default=str)


def _response_size_hints(operation: str, payload: Dict[str, Any]) -> List[str]:
    hints: List[str] = []
    data = payload.get("data")
    data_dict = data if isinstance(data, dict) else {}

    if operation == "read_data_from_excel":
        if "cells" in data_dict:
            hints.append("use values_only=True to return a smaller 2D values array")
        hints.append("request a smaller range via start_cell/end_cell")
        hints.append("set max_rows to page through tall ranges")
        hints.append("set max_cols to page through wide ranges")
        if not data_dict.get("preview_only"):
            hints.append("use preview_only=True to limit the response to the first 10 rows")
        hints.append("use read_excel_as_table plus start_row/max_rows for tabular worksheet data")
    elif operation in {"quick_read", "read_excel_as_table", "read_excel_table", "query_table", "aggregate_table", "bulk_aggregate_workbooks", "bulk_filter_workbooks", "union_tables", "cross_workbook_lookup"}:
        if operation == "read_excel_table":
            hints.append("set max_rows to request a smaller page")
            hints.append("use start_row to continue from a later table row")
            hints.append("use start_col/end_col to request a narrower table column slice")
        elif operation == "query_table":
            hints.append("use select to return fewer columns")
            hints.append("use filters to narrow the matched rows before returning them")
            hints.append("use limit to cap the number of returned rows")
        elif operation == "aggregate_table":
            hints.append("use filters to narrow the matched source rows before grouping")
            hints.append("use limit to cap the number of returned groups")
        elif operation == "bulk_filter_workbooks":
            hints.append("use select to return fewer columns")
            hints.append("use filters to narrow the matched rows before returning them")
            hints.append("use limit to cap the number of returned rows")
            hints.append("set include_source_columns=False to trim provenance columns from every row")
            hints.append("reduce the number of filepaths per call when filtering many workbooks")
            hints.append("set source_sample_limit to trim per-workbook metadata")
        elif operation == "union_tables":
            hints.append("use select to return fewer columns")
            hints.append("use limit to cap the number of returned rows")
            hints.append("set include_source_columns=False to trim provenance columns from every row")
            hints.append("reduce the number of filepaths per call when unioning many workbooks")
            hints.append("set source_sample_limit to trim per-workbook metadata")
        elif operation == "cross_workbook_lookup":
            hints.append("use select to return fewer source columns")
            hints.append("use lookup_select to return fewer lookup columns")
            hints.append("use limit to cap the number of returned joined rows")
            hints.append("set include_lookup_source_columns=False to trim provenance columns from every row")
            hints.append("set include_lookup_match_count=False if per-row match counts are not needed")
            hints.append("reduce the number of lookup_filepaths per call when joining many workbooks")
            hints.append("set lookup_sample_limit to trim per-workbook metadata")
        elif operation == "bulk_aggregate_workbooks":
            hints.append("use filters to narrow the matched source rows before grouping")
            hints.append("use limit to cap the number of returned groups")
            hints.append("reduce the number of filepaths per call when aggregating many workbooks")
            hints.append("set source_sample_limit to trim per-workbook metadata")
        else:
            hints.append("set max_rows to request a smaller page")
            hints.append("use start_row to continue from a deeper row without rereading the top")
            hints.append("use start_col/end_col to request a narrower column slice")
        if operation in {"quick_read", "read_excel_as_table", "read_excel_table"} and "headers" in data_dict:
            hints.append("set include_headers=False for follow-up pages after the first")
        if data_dict.get("row_mode") == "objects":
            hints.append("switch to row_mode='arrays' for a smaller payload")
        if operation in {"read_excel_as_table", "read_excel_table"} and "sheet_name" in data_dict:
            hints.append("set compact=True to trim nonessential metadata")
    elif operation == "describe_dataset":
        hints.append("set sample_rows to inspect a smaller sample")
        hints.append("use suggest_read_strategy when you only need the recommended next tool")
    elif operation in {
        "profile_workbook",
        "audit_workbook",
        "plan_workbook_repairs",
        "apply_workbook_repairs",
        "diff_workbooks",
        "inspect_named_range",
        "inspect_data_validation_rules",
        "inspect_conditional_format_rules",
        "list_all_sheets",
        "list_tables",
        "list_charts",
    }:
        if operation in {"audit_workbook", "plan_workbook_repairs", "apply_workbook_repairs", "diff_workbooks"}:
            hints.append("set sample_limit to return a smaller audit sample")
        if operation == "diff_workbooks":
            hints.append("set include_cell_changes=False to skip cell-level diff sampling")
        hints.append("query a smaller workbook slice, such as one sheet or one table")
    elif operation == "explain_formula_cell":
        hints.append("set max_depth to a smaller number to shorten the upstream chain")
        hints.append("inspect a single formula cell at a time")

    if "changes" in payload:
        hints.append("set include_changes=False to omit detailed per-cell diffs")

    if not hints:
        hints.append("request a smaller slice of workbook data")

    deduped_hints: List[str] = []
    seen_hints = set()
    for hint in hints:
        if hint not in seen_hints:
            seen_hints.add(hint)
            deduped_hints.append(hint)
    return deduped_hints


def _raise_if_response_too_large(operation: str, payload: Dict[str, Any]) -> None:
    serialized = _serialize_json(payload)
    response_size = len(serialized)
    if response_size <= MCP_RESPONSE_CHAR_LIMIT:
        return

    hints = _response_size_hints(operation, payload)
    raise ResponseTooLargeError(
        (
            f"Result would be {response_size:,} characters, exceeding the "
            f"SheetForge MCP response limit of {MCP_RESPONSE_CHAR_LIMIT:,}."
        ),
        estimated_size=response_size,
        limit=MCP_RESPONSE_CHAR_LIMIT,
        hints=hints,
    )


def _success_response(
    operation: str,
    *,
    result: Any = None,
    message: Optional[str] = None,
    data: Any = None,
    **meta: Any,
) -> str:
    extracted_message, extracted_data, extracted_meta = _extract_payload_parts(result)
    if data is None:
        data = extracted_data

    payload = {
        "ok": True,
        "operation": operation,
        "message": message or extracted_message or f"{operation} completed",
        "data": data,
    }
    payload.update({key: value for key, value in extracted_meta.items() if value is not None})
    payload.update({key: value for key, value in meta.items() if value is not None})
    _raise_if_response_too_large(operation, payload)
    return _serialize_json(payload)


def _error_response(operation: str, error: Exception) -> str:
    error_payload = {
        "type": type(error).__name__,
        "message": str(error),
    }
    if isinstance(error, ResponseTooLargeError):
        error_payload["estimated_size"] = error.estimated_size
        error_payload["limit"] = error.limit
        if error.hints:
            error_payload["hints"] = error.hints

    return _serialize_json(
        {
            "ok": False,
            "operation": operation,
            "error": error_payload,
        }
    )


def _run_tool(operation: str, action: Callable[[], Any], *, message: Optional[str] = None) -> str:
    try:
        return _success_response(operation, result=action(), message=message)
    except HANDLED_TOOL_ERRORS as e:
        logger.error("%s failed: %s", operation, e)
        return _error_response(operation, e)
    except Exception as e:
        logger.exception("Unhandled error in %s", operation)
        return _error_response(operation, e)

def get_excel_path(filename: str) -> str:
    """Get full path to Excel file.
    
    Args:
        filename: Name of Excel file
        
    Returns:
        Full path to Excel file
    """
    # If filename is already an absolute path, return it
    if os.path.isabs(filename):
        return filename

    # Check if in SSE mode (EXCEL_FILES_PATH is not None)
    if EXCEL_FILES_PATH is None:
        # Must use absolute path
        raise ValueError(f"Invalid filename: {filename}, must be an absolute path when not in SSE mode")

    # In SSE mode, if it's a relative path, resolve it based on EXCEL_FILES_PATH
    return os.path.join(EXCEL_FILES_PATH, filename)

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Apply Formula",
        destructiveHint=True,
    ),
)
def apply_formula(
    filepath: str,
    sheet_name: str,
    cell: str,
    formula: str,
) -> str:
    """
    Apply Excel formula to cell.
    Excel formula will write to cell with verification.
    """
    def action() -> Any:
        full_path = get_excel_path(filepath)
        validation = validate_formula_impl(full_path, sheet_name, cell, formula)
        if isinstance(validation, dict) and "error" in validation:
            raise ValidationError(validation["error"])

        from excel_mcp.calculations import apply_formula as apply_formula_impl

        return apply_formula_impl(full_path, sheet_name, cell, formula)

    return _run_tool("apply_formula", action)

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Validate Formula Syntax",
        readOnlyHint=True,
    ),
)
def validate_formula_syntax(
    filepath: str,
    sheet_name: str,
    cell: str,
    formula: str,
) -> str:
    """Validate Excel formula syntax without applying it."""
    return _run_tool(
        "validate_formula_syntax",
        lambda: validate_formula_impl(get_excel_path(filepath), sheet_name, cell, formula),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Inspect Formula",
        readOnlyHint=True,
    ),
)
def inspect_formula(
    formula: str,
) -> str:
    """Inspect a formula string for functions, references, and risky signals."""
    return _run_tool(
        "inspect_formula",
        lambda: inspect_formula_impl(formula),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Format Range",
        destructiveHint=True,
    ),
)
def format_range(
    filepath: str,
    sheet_name: str,
    start_cell: str,
    end_cell: Optional[str] = None,
    bold: bool = False,
    italic: bool = False,
    underline: bool = False,
    font_size: Optional[int] = None,
    font_color: Optional[str] = None,
    bg_color: Optional[str] = None,
    border_style: Optional[str] = None,
    border_color: Optional[str] = None,
    number_format: Optional[str] = None,
    alignment: Optional[str] = None,
    wrap_text: bool = False,
    merge_cells: bool = False,
    protection: Optional[Dict[str, Any]] = None,
    conditional_format: Optional[Dict[str, Any]] = None,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Apply formatting to a range of cells. Colors accept RRGGBB, #RRGGBB, AARRGGBB, or #AARRGGBB."""
    def action() -> Any:
        full_path = get_excel_path(filepath)
        from excel_mcp.formatting import format_range as format_range_func

        return format_range_func(
            filepath=full_path,
            sheet_name=sheet_name,
            start_cell=start_cell,
            end_cell=end_cell,
            bold=bold,
            italic=italic,
            underline=underline,
            font_size=font_size,
            font_color=font_color,
            bg_color=bg_color,
            border_style=border_style,
            border_color=border_color,
            number_format=number_format,
            alignment=alignment,
            wrap_text=wrap_text,
            merge_cells=merge_cells,
            protection=protection,
            conditional_format=conditional_format,
            dry_run=dry_run,
            include_changes=include_changes,
        )

    return _run_tool("format_range", action)


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Format Multiple Ranges",
        destructiveHint=True,
    ),
)
def format_ranges(
    filepath: str,
    sheet_name: str,
    ranges: List[Dict[str, Any]],
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Apply formatting to multiple ranges in a single workbook pass. Colors accept RRGGBB, #RRGGBB, AARRGGBB, or #AARRGGBB."""
    def action() -> Any:
        full_path = get_excel_path(filepath)
        from excel_mcp.formatting import format_ranges as format_ranges_impl

        return format_ranges_impl(
            filepath=full_path,
            sheet_name=sheet_name,
            ranges=ranges,
            dry_run=dry_run,
            include_changes=include_changes,
        )

    return _run_tool("format_ranges", action)


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Read Range Formatting",
        readOnlyHint=True,
    ),
)
def read_range_formatting(
    filepath: str,
    sheet_name: str,
    range_ref: str,
    sample_limit: int = 10,
) -> str:
    """Read a compact formatting summary for a worksheet range."""
    def action() -> Any:
        full_path = get_excel_path(filepath)
        from excel_mcp.formatting import read_range_formatting as read_range_formatting_impl

        return read_range_formatting_impl(
            filepath=full_path,
            sheet_name=sheet_name,
            range_ref=range_ref,
            sample_limit=sample_limit,
        )

    return _run_tool("read_range_formatting", action)

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Read Data from Excel",
        readOnlyHint=True,
    ),
)
def read_data_from_excel(
    filepath: str,
    sheet_name: str,
    start_cell: str = "A1",
    end_cell: Optional[str] = None,
    max_rows: Optional[int] = None,
    max_cols: Optional[int] = None,
    cursor: Optional[str] = None,
    preview_only: bool = False,
    compact: bool = False,
    values_only: bool = False,
) -> str:
    """
    Read data from Excel worksheet with cell metadata including validation rules.
    
    Args:
        filepath: Path to Excel file
        sheet_name: Name of worksheet
        start_cell: Starting cell (default A1)
        end_cell: Ending cell (optional, auto-expands if not provided)
        max_rows: Optional maximum number of rows to return from the starting row
        max_cols: Optional maximum number of columns to return from the starting column
        cursor: Optional continuation token returned by an earlier range read
        preview_only: Whether to return preview only
        compact: Whether to omit default validation metadata for smaller responses
        values_only: Whether to return a 2D value grid without per-cell metadata
    
    Returns:  
    JSON string containing either structured cell data with validation metadata
    or a plain 2D value grid when values_only=True.
    """
    try:
        full_path = get_excel_path(filepath)
        from excel_mcp.data import read_excel_range_with_metadata
        effective_max_rows = max_rows
        if preview_only:
            preview_row_limit = 10
            effective_max_rows = (
                preview_row_limit
                if max_rows is None
                else min(max_rows, preview_row_limit)
            )
        result = read_excel_range_with_metadata(
            full_path,
            sheet_name,
            start_cell,
            end_cell,
            max_rows=effective_max_rows,
            max_cols=max_cols,
            cursor=cursor,
            compact=compact,
            values_only=values_only,
        )
        effective_values_only = "values" in result and "cells" not in result
        if not result:
            result = {"range": f"{start_cell}:{end_cell}" if end_cell else start_cell, "sheet_name": sheet_name}
            result["values" if values_only else "cells"] = []
            effective_values_only = values_only

        if preview_only:
            result["preview_only"] = True

        if effective_values_only:
            value_count = sum(len(row) for row in result["values"])
            message = f"Read {value_count} value(s) from '{sheet_name}'"
        else:
            message = f"Read {len(result['cells'])} cell(s) from '{sheet_name}'"

        return _success_response(
            "read_data_from_excel",
            result=result,
            message=message,
        )

    except HANDLED_TOOL_ERRORS as e:
        logger.error("read_data_from_excel failed: %s", e)
        return _error_response("read_data_from_excel", e)
    except Exception as e:
        logger.exception("Unhandled error in read_data_from_excel")
        return _error_response("read_data_from_excel", e)

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Read Excel as Table",
        readOnlyHint=True,
    ),
)
def read_excel_as_table(
    filepath: str,
    sheet_name: str,
    header_row: int = 1,
    start_row: Optional[int] = None,
    start_col: str = "A",
    end_col: Optional[str] = None,
    max_rows: Optional[int] = None,
    compact: bool = False,
    include_headers: bool = True,
    row_mode: str = "arrays",
    infer_schema: bool = False,
) -> str:
    """
    Read Excel data as a compact table with headers and rows or record objects.
    Much more context-efficient than read_data_from_excel for structured data,
    with optional inferred schema hints for downstream steps.
    """
    return _run_tool(
        "read_excel_as_table",
        lambda: read_as_table(
            get_excel_path(filepath),
            sheet_name,
            header_row=header_row,
            start_row=start_row,
            start_col=start_col,
            end_col=end_col,
            max_rows=max_rows,
            compact=compact,
            include_headers=include_headers,
            row_mode=row_mode,
            infer_schema=infer_schema,
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Quick Read",
        readOnlyHint=True,
    ),
)
def quick_read(
    filepath: str,
    sheet_name: Optional[str] = None,
    header_row: int = 1,
    start_row: Optional[int] = None,
    start_col: str = "A",
    end_col: Optional[str] = None,
    max_rows: Optional[int] = None,
    include_headers: bool = True,
    row_mode: str = "arrays",
    infer_schema: bool = False,
) -> str:
    """Read a compact table from an explicit sheet or the first workbook sheet.

    Can return either array rows or object-shaped records, plus optional schema
    hints inferred from the returned rows.
    """
    return _run_tool(
        "quick_read",
        lambda: quick_read_impl(
            get_excel_path(filepath),
            sheet_name=sheet_name,
            header_row=header_row,
            start_row=start_row,
            start_col=start_col,
            end_col=end_col,
            max_rows=max_rows,
            include_headers=include_headers,
            row_mode=row_mode,
            infer_schema=infer_schema,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Describe Dataset",
        readOnlyHint=True,
    ),
)
def describe_dataset(
    filepath: str,
    sheet_name: Optional[str] = None,
    table_name: Optional[str] = None,
    header_row: int = 1,
    sample_rows: int = 25,
) -> str:
    """Summarize a worksheet or native Excel table for agent-friendly orientation."""
    return _run_tool(
        "describe_dataset",
        lambda: describe_dataset_impl(
            get_excel_path(filepath),
            sheet_name=sheet_name,
            table_name=table_name,
            header_row=header_row,
            sample_rows=sample_rows,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Suggest Read Strategy",
        readOnlyHint=True,
    ),
)
def suggest_read_strategy(
    filepath: str,
    goal: Optional[str] = None,
    sheet_name: Optional[str] = None,
    table_name: Optional[str] = None,
    header_row: int = 1,
    sample_rows: int = 25,
) -> str:
    """Recommend the best SheetForge read tool for the requested workbook target."""
    return _run_tool(
        "suggest_read_strategy",
        lambda: suggest_read_strategy_impl(
            get_excel_path(filepath),
            goal=goal,
            sheet_name=sheet_name,
            table_name=table_name,
            header_row=header_row,
            sample_rows=sample_rows,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Query Table",
        readOnlyHint=True,
    ),
)
def query_table(
    filepath: str,
    sheet_name: Optional[str] = None,
    table_name: Optional[str] = None,
    header_row: int = 1,
    select: Optional[List[str]] = None,
    filters: Optional[List[Dict[str, Any]]] = None,
    sort_by: Optional[str] = None,
    sort_desc: bool = False,
    limit: Optional[int] = None,
    row_mode: str = "arrays",
    infer_schema: bool = False,
) -> str:
    """Filter, project, sort, and limit worksheet or table data. Filters support eq/neq/ne, comparisons, string matching, blank checks, and in/not_in with value or values."""
    return _run_tool(
        "query_table",
        lambda: query_table_impl(
            get_excel_path(filepath),
            sheet_name=sheet_name,
            table_name=table_name,
            header_row=header_row,
            select=select,
            filters=filters,
            sort_by=sort_by,
            sort_desc=sort_desc,
            limit=limit,
            row_mode=row_mode,
            infer_schema=infer_schema,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Bulk Filter Workbooks",
        readOnlyHint=True,
    ),
)
def bulk_filter_workbooks(
    filepaths: List[str],
    sheet_name: Optional[str] = None,
    table_name: Optional[str] = None,
    header_row: int = 1,
    select: Optional[List[str]] = None,
    filters: Optional[List[Dict[str, Any]]] = None,
    sort_by: Optional[str] = None,
    sort_desc: bool = False,
    limit: Optional[int] = None,
    schema_mode: str = "strict",
    source_sample_limit: int = 10,
    include_source_columns: bool = True,
    row_mode: str = "arrays",
    infer_schema: bool = False,
) -> str:
    """Filter comparable worksheet or table data across multiple workbooks. Uses the same filter operators and aliases as query_table."""
    return _run_tool(
        "bulk_filter_workbooks",
        lambda: bulk_filter_workbooks_impl(
            [get_excel_path(filepath) for filepath in filepaths],
            sheet_name=sheet_name,
            table_name=table_name,
            header_row=header_row,
            select=select,
            filters=filters,
            sort_by=sort_by,
            sort_desc=sort_desc,
            limit=limit,
            schema_mode=schema_mode,
            source_sample_limit=source_sample_limit,
            include_source_columns=include_source_columns,
            row_mode=row_mode,
            infer_schema=infer_schema,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Union Tables",
        readOnlyHint=True,
    ),
)
def union_tables(
    filepaths: List[str],
    sheet_name: Optional[str] = None,
    table_name: Optional[str] = None,
    header_row: int = 1,
    select: Optional[List[str]] = None,
    sort_by: Optional[str] = None,
    sort_desc: bool = False,
    limit: Optional[int] = None,
    schema_mode: str = "strict",
    source_sample_limit: int = 10,
    include_source_columns: bool = True,
    dedupe_on: Optional[List[str]] = None,
    row_mode: str = "arrays",
    infer_schema: bool = False,
) -> str:
    """Union comparable worksheet or table data across multiple workbook files."""
    return _run_tool(
        "union_tables",
        lambda: union_tables_impl(
            [get_excel_path(filepath) for filepath in filepaths],
            sheet_name=sheet_name,
            table_name=table_name,
            header_row=header_row,
            select=select,
            sort_by=sort_by,
            sort_desc=sort_desc,
            limit=limit,
            schema_mode=schema_mode,
            source_sample_limit=source_sample_limit,
            include_source_columns=include_source_columns,
            dedupe_on=dedupe_on,
            row_mode=row_mode,
            infer_schema=infer_schema,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Cross Workbook Lookup",
        readOnlyHint=True,
    ),
)
def cross_workbook_lookup(
    source_filepath: str,
    lookup_filepaths: List[str],
    source_key: str,
    source_sheet_name: Optional[str] = None,
    source_table_name: Optional[str] = None,
    lookup_sheet_name: Optional[str] = None,
    lookup_table_name: Optional[str] = None,
    source_header_row: int = 1,
    lookup_header_row: int = 1,
    lookup_key: Optional[str] = None,
    select: Optional[List[str]] = None,
    lookup_select: Optional[List[str]] = None,
    join_type: str = "left",
    match_mode: str = "first",
    lookup_sort_by: Optional[str] = None,
    lookup_sort_desc: bool = False,
    limit: Optional[int] = None,
    schema_mode: str = "strict",
    lookup_sample_limit: int = 10,
    include_lookup_source_columns: bool = True,
    include_lookup_match_count: bool = True,
    case_sensitive: bool = False,
    row_mode: str = "arrays",
    infer_schema: bool = False,
) -> str:
    """Enrich one workbook dataset from matching rows in one or more lookup workbooks."""
    return _run_tool(
        "cross_workbook_lookup",
        lambda: cross_workbook_lookup_impl(
            get_excel_path(source_filepath),
            [get_excel_path(filepath) for filepath in lookup_filepaths],
            source_sheet_name=source_sheet_name,
            source_table_name=source_table_name,
            lookup_sheet_name=lookup_sheet_name,
            lookup_table_name=lookup_table_name,
            source_header_row=source_header_row,
            lookup_header_row=lookup_header_row,
            source_key=source_key,
            lookup_key=lookup_key,
            select=select,
            lookup_select=lookup_select,
            join_type=join_type,
            match_mode=match_mode,
            lookup_sort_by=lookup_sort_by,
            lookup_sort_desc=lookup_sort_desc,
            limit=limit,
            schema_mode=schema_mode,
            lookup_sample_limit=lookup_sample_limit,
            include_lookup_source_columns=include_lookup_source_columns,
            include_lookup_match_count=include_lookup_match_count,
            case_sensitive=case_sensitive,
            row_mode=row_mode,
            infer_schema=infer_schema,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Aggregate Table",
        readOnlyHint=True,
    ),
)
def aggregate_table(
    filepath: str,
    sheet_name: Optional[str] = None,
    table_name: Optional[str] = None,
    header_row: int = 1,
    filters: Optional[List[Dict[str, Any]]] = None,
    group_by: Optional[List[str]] = None,
    metrics: Optional[List[Dict[str, Any]]] = None,
    sort_by: Optional[str] = None,
    sort_desc: bool = False,
    limit: Optional[int] = None,
    row_mode: str = "arrays",
    infer_schema: bool = False,
) -> str:
    """Compute grouped metrics over worksheet-shaped data or a native Excel table."""
    return _run_tool(
        "aggregate_table",
        lambda: aggregate_table_impl(
            get_excel_path(filepath),
            sheet_name=sheet_name,
            table_name=table_name,
            header_row=header_row,
            filters=filters,
            group_by=group_by,
            metrics=metrics,
            sort_by=sort_by,
            sort_desc=sort_desc,
            limit=limit,
            row_mode=row_mode,
            infer_schema=infer_schema,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Bulk Aggregate Workbooks",
        readOnlyHint=True,
    ),
)
def bulk_aggregate_workbooks(
    filepaths: List[str],
    sheet_name: Optional[str] = None,
    table_name: Optional[str] = None,
    header_row: int = 1,
    filters: Optional[List[Dict[str, Any]]] = None,
    group_by: Optional[List[str]] = None,
    metrics: Optional[List[Dict[str, Any]]] = None,
    sort_by: Optional[str] = None,
    sort_desc: bool = False,
    limit: Optional[int] = None,
    schema_mode: str = "strict",
    source_sample_limit: int = 10,
    row_mode: str = "arrays",
    infer_schema: bool = False,
) -> str:
    """Aggregate comparable worksheet or table data across multiple workbooks."""
    return _run_tool(
        "bulk_aggregate_workbooks",
        lambda: bulk_aggregate_workbooks_impl(
            [get_excel_path(filepath) for filepath in filepaths],
            sheet_name=sheet_name,
            table_name=table_name,
            header_row=header_row,
            filters=filters,
            group_by=group_by,
            metrics=metrics,
            sort_by=sort_by,
            sort_desc=sort_desc,
            limit=limit,
            schema_mode=schema_mode,
            source_sample_limit=source_sample_limit,
            row_mode=row_mode,
            infer_schema=infer_schema,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Read Excel Table",
        readOnlyHint=True,
    ),
)
def read_excel_table(
    filepath: str,
    table_name: str,
    sheet_name: Optional[str] = None,
    start_row: int = 1,
    start_col: Optional[str] = None,
    end_col: Optional[str] = None,
    max_rows: Optional[int] = None,
    compact: bool = False,
    include_headers: bool = True,
    row_mode: str = "arrays",
    infer_schema: bool = False,
) -> str:
    """Read a native Excel table by its table name.

    Supports compact table payloads, object-shaped record output, and optional
    inferred schema hints.
    """
    return _run_tool(
        "read_excel_table",
        lambda: read_excel_table_impl(
            get_excel_path(filepath),
            table_name,
            sheet_name=sheet_name,
            start_row=start_row,
            start_col=start_col,
            end_col=end_col,
            max_rows=max_rows,
            compact=compact,
            include_headers=include_headers,
            row_mode=row_mode,
            infer_schema=infer_schema,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Write Data to Excel",
        destructiveHint=True,
    ),
)
def write_data_to_excel(
    filepath: str,
    sheet_name: str,
    data: List[List],
    start_cell: str = "A1",
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """
    Write data to Excel worksheet.
    Excel formula will write to cell without any verification.

    PARAMETERS:  
    filepath: Path to Excel file
    sheet_name: Name of worksheet to write to
    data: List of lists containing data to write to the worksheet, sublists are assumed to be rows
    start_cell: Cell to start writing to, default is "A1"
  
    """
    return _run_tool(
        "write_data_to_excel",
        lambda: write_data(
            get_excel_path(filepath),
            sheet_name,
            data,
            start_cell,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Create Workbook",
        destructiveHint=True,
    ),
)
def create_workbook(filepath: str) -> str:
    """Create new Excel workbook."""
    def action() -> Any:
        full_path = get_excel_path(filepath)
        from excel_mcp.workbook import create_workbook as create_workbook_impl

        result = create_workbook_impl(full_path)
        result.pop("workbook", None)
        result["filepath"] = full_path
        return result

    return _run_tool("create_workbook", action)

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Create Worksheet",
        destructiveHint=True,
    ),
)
def create_worksheet(filepath: str, sheet_name: str) -> str:
    """Create new worksheet in workbook."""
    def action() -> Any:
        full_path = get_excel_path(filepath)
        from excel_mcp.workbook import create_sheet as create_worksheet_impl

        result = create_worksheet_impl(full_path, sheet_name)
        result["sheet_name"] = sheet_name
        return result

    return _run_tool("create_worksheet", action)

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Create Chart",
        destructiveHint=True,
    ),
)
def create_chart(
    filepath: str,
    sheet_name: str,
    chart_type: str,
    target_cell: Optional[str] = None,
    data_range: Optional[str] = None,
    title: str = "",
    x_axis: str = "",
    y_axis: str = "",
    style: Optional[Dict[str, Any]] = None,
    series: Optional[List[Dict[str, Any]]] = None,
    categories_range: Optional[str] = None,
    width: Optional[float] = None,
    height: Optional[float] = None,
    placement: Optional[Dict[str, Any]] = None,
) -> str:
    """Create chart in worksheet from a contiguous range or explicit series.

    This is the preferred chart authoring entry point; explicit-series calls are
    also still available via create_chart_from_series for backward compatibility.
    """
    def action() -> Any:
        return create_chart_impl(
            filepath=get_excel_path(filepath),
            sheet_name=sheet_name,
            data_range=data_range,
            chart_type=chart_type,
            target_cell=target_cell,
            title=title,
            x_axis=x_axis,
            y_axis=y_axis,
            style=style,
            series=series,
            categories_range=categories_range,
            width=width,
            height=height,
            placement=placement,
        )

    return _run_tool("create_chart", action)


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Create Chart From Series",
        destructiveHint=True,
    ),
)
def create_chart_from_series(
    filepath: str,
    sheet_name: str,
    chart_type: str,
    target_cell: Optional[str] = None,
    series: Optional[List[Dict[str, Any]]] = None,
    title: str = "",
    x_axis: str = "",
    y_axis: str = "",
    categories_range: Optional[str] = None,
    style: Optional[Dict[str, Any]] = None,
    width: Optional[float] = None,
    height: Optional[float] = None,
    placement: Optional[Dict[str, Any]] = None,
) -> str:
    """Create a chart from explicit series definitions for non-contiguous ranges."""
    def action() -> Any:
        return create_chart_from_series_impl(
            filepath=get_excel_path(filepath),
            sheet_name=sheet_name,
            chart_type=chart_type,
            target_cell=target_cell,
            series=series,
            title=title,
            x_axis=x_axis,
            y_axis=y_axis,
            categories_range=categories_range,
            style=style,
            width=width,
            height=height,
            placement=placement,
        )

    return _run_tool("create_chart_from_series", action)


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="List Charts",
        readOnlyHint=True,
    ),
)
def list_charts(filepath: str, sheet_name: Optional[str] = None) -> str:
    """List embedded charts in a workbook or worksheet."""
    def action() -> Any:
        return {"charts": list_charts_impl(get_excel_path(filepath), sheet_name=sheet_name)}

    return _run_tool("list_charts", action)


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Find Free Canvas",
        readOnlyHint=True,
    ),
)
def find_free_canvas(
    filepath: str,
    sheet_name: str,
    width: Optional[float] = None,
    height: Optional[float] = None,
    min_rows: Optional[int] = None,
    min_cols: Optional[int] = None,
    limit: int = 5,
    origin_cell: str = "A1",
    search_rows: Optional[int] = None,
    search_columns: Optional[int] = None,
    padding_rows: int = 0,
    padding_columns: int = 0,
) -> str:
    """Suggest free worksheet slots for charts or dashboard blocks."""
    def action() -> Any:
        return find_free_canvas_impl(
            filepath=get_excel_path(filepath),
            sheet_name=sheet_name,
            width=width,
            height=height,
            min_rows=min_rows,
            min_cols=min_cols,
            limit=limit,
            origin_cell=origin_cell,
            search_rows=search_rows,
            search_columns=search_columns,
            padding_rows=padding_rows,
            padding_columns=padding_columns,
        )

    return _run_tool("find_free_canvas", action)

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Create Pivot Table",
        destructiveHint=True,
    ),
)
def create_pivot_table(
    filepath: str,
    sheet_name: str,
    data_range: str,
    rows: List[str],
    values: List[str],
    columns: Optional[List[str]] = None,
    agg_func: str = "sum"
) -> str:
    """Create pivot table in worksheet."""
    return _run_tool(
        "create_pivot_table",
        lambda: create_pivot_table_impl(
            filepath=get_excel_path(filepath),
            sheet_name=sheet_name,
            data_range=data_range,
            rows=rows,
            values=values,
            columns=columns or [],
            agg_func=agg_func
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Create Table",
        destructiveHint=True,
    ),
)
def create_table(
    filepath: str,
    sheet_name: str,
    data_range: str,
    table_name: Optional[str] = None,
    table_style: str = "TableStyleMedium9"
) -> str:
    """Creates a native Excel table from a specified range of data."""
    return _run_tool(
        "create_table",
        lambda: create_table_impl(
            filepath=get_excel_path(filepath),
            sheet_name=sheet_name,
            data_range=data_range,
            table_name=table_name,
            table_style=table_style
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="List Excel Tables",
        readOnlyHint=True,
    ),
)
def list_tables(
    filepath: str,
    sheet_name: Optional[str] = None,
) -> str:
    """List native Excel tables for one worksheet or the whole workbook."""
    def action() -> Any:
        return {
            "sheet_name": sheet_name,
            "tables": list_tables_impl(get_excel_path(filepath), sheet_name=sheet_name),
        }

    return _run_tool("list_tables", action)

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Copy Worksheet",
        destructiveHint=True,
    ),
)
def copy_worksheet(
    filepath: str,
    source_sheet: str,
    target_sheet: str
) -> str:
    """Copy worksheet within workbook."""
    return _run_tool(
        "copy_worksheet",
        lambda: copy_sheet(get_excel_path(filepath), source_sheet, target_sheet),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Delete Worksheet",
        destructiveHint=True,
    ),
)
def delete_worksheet(
    filepath: str,
    sheet_name: str
) -> str:
    """Delete worksheet from workbook."""
    return _run_tool(
        "delete_worksheet",
        lambda: delete_sheet(get_excel_path(filepath), sheet_name),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Rename Worksheet",
        destructiveHint=True,
    ),
)
def rename_worksheet(
    filepath: str,
    old_name: str,
    new_name: str
) -> str:
    """Rename worksheet in workbook."""
    return _run_tool(
        "rename_worksheet",
        lambda: rename_sheet(get_excel_path(filepath), old_name, new_name),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Get Workbook Metadata",
        readOnlyHint=True,
    ),
)
def get_workbook_metadata(
    filepath: str,
    include_ranges: bool = False
) -> str:
    """Get metadata about workbook including sheets, ranges, etc."""
    return _run_tool(
        "get_workbook_metadata",
        lambda: get_workbook_info(get_excel_path(filepath), include_ranges=include_ranges),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Describe Sheet Layout",
        readOnlyHint=True,
    ),
)
def describe_sheet_layout(
    filepath: str,
    sheet_name: str,
    sample_limit: int = 10,
    free_canvas_rows: int = 8,
    free_canvas_cols: int = 6,
    free_canvas_limit: int = 3,
) -> str:
    """Return a structural worksheet layout summary for safe dashboard-style edits."""
    return _run_tool(
        "describe_sheet_layout",
        lambda: describe_sheet_layout_impl(
            get_excel_path(filepath),
            sheet_name=sheet_name,
            sample_limit=sample_limit,
            free_canvas_rows=free_canvas_rows,
            free_canvas_cols=free_canvas_cols,
            free_canvas_limit=free_canvas_limit,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Analyze Range Impact",
        readOnlyHint=True,
    ),
)
def analyze_range_impact(
    filepath: str,
    sheet_name: str,
    range_ref: str,
) -> str:
    """Inspect workbook structures that overlap a worksheet range before mutation."""
    return _run_tool(
        "analyze_range_impact",
        lambda: analyze_range_impact_impl(get_excel_path(filepath), sheet_name, range_ref),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Explain Formula Cell",
        readOnlyHint=True,
    ),
)
def explain_formula_cell(
    filepath: str,
    sheet_name: str,
    cell: str,
    max_depth: int = 3,
) -> str:
    """Explain a formula cell's direct references, upstream formula chain, and downstream dependents."""
    return _run_tool(
        "explain_formula_cell",
        lambda: explain_formula_cell_impl(
            get_excel_path(filepath),
            sheet_name,
            cell,
            max_depth=max_depth,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Detect Circular Dependencies",
        readOnlyHint=True,
    ),
)
def detect_circular_dependencies(
    filepath: str,
    sample_limit: int = 25,
) -> str:
    """Detect circular workbook formula dependencies, including self-references."""
    return _run_tool(
        "detect_circular_dependencies",
        lambda: detect_circular_dependencies_impl(
            get_excel_path(filepath),
            sample_limit=sample_limit,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Profile Workbook",
        readOnlyHint=True,
    ),
)
def profile_workbook(filepath: str) -> str:
    """Return a compact workbook inventory with sheets, tables, charts, and layout state."""
    return _run_tool(
        "profile_workbook",
        lambda: profile_workbook_impl(get_excel_path(filepath)),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Audit Workbook",
        readOnlyHint=True,
    ),
)
def audit_workbook(
    filepath: str,
    header_row: int = 1,
    sample_limit: int = 25,
) -> str:
    """Audit workbook structure for high-signal issues that affect agent workflows."""
    return _run_tool(
        "audit_workbook",
        lambda: audit_workbook_impl(
            get_excel_path(filepath),
            header_row=header_row,
            sample_limit=sample_limit,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Plan Workbook Repairs",
        readOnlyHint=True,
    ),
)
def plan_workbook_repairs(
    filepath: str,
    header_row: int = 1,
    sample_limit: int = 25,
) -> str:
    """Turn workbook audit findings into prioritized next steps for SheetForge workflows."""
    return _run_tool(
        "plan_workbook_repairs",
        lambda: plan_workbook_repairs_impl(
            get_excel_path(filepath),
            header_row=header_row,
            sample_limit=sample_limit,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Apply Workbook Repairs",
        destructiveHint=True,
    ),
)
def apply_workbook_repairs(
    filepath: str,
    repair_types: Optional[List[str]] = None,
    sheet_names: Optional[List[str]] = None,
    header_row: int = 1,
    sample_limit: int = 25,
    dry_run: bool = True,
) -> str:
    """Apply safe workbook repair actions with dry-run planning and before/after diff output."""
    return _run_tool(
        "apply_workbook_repairs",
        lambda: apply_workbook_repairs_impl(
            get_excel_path(filepath),
            repair_types=repair_types,
            sheet_names=sheet_names,
            header_row=header_row,
            sample_limit=sample_limit,
            dry_run=dry_run,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Diff Workbooks",
        readOnlyHint=True,
    ),
)
def diff_workbooks(
    before_filepath: str,
    after_filepath: str,
    sample_limit: int = 25,
    include_cell_changes: bool = True,
) -> str:
    """Diff two workbook files and report structural changes plus sampled cell-value changes."""
    return _run_tool(
        "diff_workbooks",
        lambda: diff_workbooks_impl(
            get_excel_path(before_filepath),
            get_excel_path(after_filepath),
            sample_limit=sample_limit,
            include_cell_changes=include_cell_changes,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Inspect Named Range",
        readOnlyHint=True,
    ),
)
def inspect_named_range(
    filepath: str,
    name: str,
    scope_sheet: Optional[str] = None,
) -> str:
    """Inspect a named range, including scope, destinations, and broken-reference signals."""
    return _run_tool(
        "inspect_named_range",
        lambda: inspect_named_range_impl(
            get_excel_path(filepath),
            name,
            scope_sheet=scope_sheet,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="List Named Ranges",
        readOnlyHint=True,
    ),
)
def list_named_ranges(filepath: str) -> str:
    """List workbook defined names and their destinations."""
    def action() -> Any:
        return {"named_ranges": list_named_ranges_impl(get_excel_path(filepath))}

    return _run_tool("list_named_ranges", action)


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Delete Named Range",
        destructiveHint=True,
    ),
)
def delete_named_range(
    filepath: str,
    name: str,
    scope_sheet: Optional[str] = None,
    dry_run: bool = False,
) -> str:
    """Delete a workbook-level or sheet-scoped named range."""
    return _run_tool(
        "delete_named_range",
        lambda: delete_named_range_impl(
            get_excel_path(filepath),
            name,
            scope_sheet=scope_sheet,
            dry_run=dry_run,
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Merge Cells",
        destructiveHint=True,
    ),
)
def merge_cells(
    filepath: str,
    sheet_name: str,
    start_cell: str,
    end_cell: str,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Merge a range of cells."""
    return _run_tool(
        "merge_cells",
        lambda: merge_range(
            get_excel_path(filepath),
            sheet_name,
            start_cell,
            end_cell,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Unmerge Cells",
        destructiveHint=True,
    ),
)
def unmerge_cells(
    filepath: str,
    sheet_name: str,
    start_cell: str,
    end_cell: str,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Unmerge a range of cells."""
    return _run_tool(
        "unmerge_cells",
        lambda: unmerge_range(
            get_excel_path(filepath),
            sheet_name,
            start_cell,
            end_cell,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Get Merged Cells",
        readOnlyHint=True,
    ),
)
def get_merged_cells(filepath: str, sheet_name: str) -> str:
    """Get merged cells in a worksheet."""
    def action() -> Any:
        return {"sheet_name": sheet_name, "ranges": get_merged_ranges(get_excel_path(filepath), sheet_name)}

    return _run_tool("get_merged_cells", action)


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Freeze Panes",
        destructiveHint=True,
    ),
)
def freeze_panes(
    filepath: str,
    sheet_name: str,
    cell: Optional[str] = None,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Set or clear worksheet freeze panes."""
    return _run_tool(
        "freeze_panes",
        lambda: set_freeze_panes(
            get_excel_path(filepath),
            sheet_name,
            cell,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Set Autofilter",
        destructiveHint=True,
    ),
)
def set_autofilter(
    filepath: str,
    sheet_name: str,
    range_ref: Optional[str] = None,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Set worksheet autofilter for an explicit or inferred range."""
    return _run_tool(
        "set_autofilter",
        lambda: set_auto_filter(
            get_excel_path(filepath),
            sheet_name,
            range_ref,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Set Worksheet Visibility",
        destructiveHint=True,
    ),
)
def set_worksheet_visibility(
    filepath: str,
    sheet_name: str,
    visibility: str,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Set worksheet visibility to visible, hidden, or veryHidden."""
    return _run_tool(
        "set_worksheet_visibility",
        lambda: set_sheet_visibility(
            get_excel_path(filepath),
            sheet_name,
            visibility,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Get Worksheet Protection",
        readOnlyHint=True,
    ),
)
def get_worksheet_protection(filepath: str, sheet_name: str) -> str:
    """Get worksheet protection status and option flags."""
    return _run_tool(
        "get_worksheet_protection",
        lambda: get_sheet_protection_impl(get_excel_path(filepath), sheet_name),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Set Worksheet Protection",
        destructiveHint=True,
    ),
)
def set_worksheet_protection(
    filepath: str,
    sheet_name: str,
    enabled: bool = True,
    password: Optional[str] = None,
    options: Optional[Dict[str, bool]] = None,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Enable or disable worksheet protection with optional capability flags."""
    return _run_tool(
        "set_worksheet_protection",
        lambda: set_sheet_protection_impl(
            get_excel_path(filepath),
            sheet_name,
            enabled=enabled,
            password=password,
            options=options,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Set Print Area",
        destructiveHint=True,
    ),
)
def set_print_area(
    filepath: str,
    sheet_name: str,
    range_ref: Optional[str] = None,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Set or clear worksheet print area."""
    return _run_tool(
        "set_print_area",
        lambda: set_print_area_impl(
            get_excel_path(filepath),
            sheet_name,
            range_ref=range_ref,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Set Print Titles",
        destructiveHint=True,
    ),
)
def set_print_titles(
    filepath: str,
    sheet_name: str,
    rows: Optional[str] = None,
    columns: Optional[str] = None,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Set, preserve, or clear repeating print title rows and columns."""
    return _run_tool(
        "set_print_titles",
        lambda: set_print_titles_impl(
            get_excel_path(filepath),
            sheet_name,
            rows=rows,
            columns=columns,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Set Column Widths",
        destructiveHint=True,
    ),
)
def set_column_widths(
    filepath: str,
    sheet_name: str,
    widths: Dict[str, float],
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Set explicit widths for one or more worksheet columns."""
    return _run_tool(
        "set_column_widths",
        lambda: set_column_widths_impl(
            get_excel_path(filepath),
            sheet_name,
            widths,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Autofit Columns",
        destructiveHint=True,
    ),
)
def autofit_columns(
    filepath: str,
    sheet_name: str,
    columns: Optional[List[str]] = None,
    min_width: float = 8.43,
    max_width: Optional[float] = None,
    padding: float = 2.0,
    dry_run: bool = False,
) -> str:
    """Auto-fit worksheet columns based on content width."""
    return _run_tool(
        "autofit_columns",
        lambda: autofit_columns_impl(
            get_excel_path(filepath),
            sheet_name,
            columns=columns,
            min_width=min_width,
            max_width=max_width,
            padding=padding,
            dry_run=dry_run,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Set Row Heights",
        destructiveHint=True,
    ),
)
def set_row_heights(
    filepath: str,
    sheet_name: str,
    heights: Dict[str, float],
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Set explicit heights for one or more worksheet rows."""
    return _run_tool(
        "set_row_heights",
        lambda: set_row_heights_impl(
            get_excel_path(filepath),
            sheet_name,
            heights,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Copy Range",
        destructiveHint=True,
    ),
)
def copy_range(
    filepath: str,
    sheet_name: str,
    source_start: str,
    source_end: str,
    target_start: str,
    target_sheet: Optional[str] = None,
    dry_run: bool = False,
) -> str:
    """Copy a range of cells to another location."""
    def action() -> Any:
        from excel_mcp.sheet import copy_range_operation

        return copy_range_operation(
            get_excel_path(filepath),
            sheet_name,
            source_start,
            source_end,
            target_start,
            target_sheet or sheet_name,
            dry_run=dry_run,
        )

    return _run_tool("copy_range", action)

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Delete Range",
        destructiveHint=True,
    ),
)
def delete_range(
    filepath: str,
    sheet_name: str,
    start_cell: str,
    end_cell: str,
    shift_direction: str = "up",
    dry_run: bool = False,
) -> str:
    """Delete a range of cells and shift remaining cells."""
    def action() -> Any:
        from excel_mcp.sheet import delete_range_operation

        return delete_range_operation(
            get_excel_path(filepath),
            sheet_name,
            start_cell,
            end_cell,
            shift_direction,
            dry_run=dry_run,
        )

    return _run_tool("delete_range", action)

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Validate Excel Range",
        readOnlyHint=True,
    ),
)
def validate_excel_range(
    filepath: str,
    sheet_name: str,
    start_cell: str,
    end_cell: Optional[str] = None
) -> str:
    """Validate if a range exists and is properly formatted."""
    range_str = start_cell if not end_cell else f"{start_cell}:{end_cell}"
    return _run_tool(
        "validate_excel_range",
        lambda: validate_range_impl(get_excel_path(filepath), sheet_name, range_str),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Get Data Validation Info",
        readOnlyHint=True,
    ),
)
def get_data_validation_info(
    filepath: str,
    sheet_name: str
) -> str:
    """
    Get all data validation rules in a worksheet.
    
    This tool helps identify which cell ranges have validation rules
    and what types of validation are applied.
    
    Args:
        filepath: Path to Excel file
        sheet_name: Name of worksheet
        
    Returns:
        JSON string containing all validation rules in the worksheet
    """
    try:
        full_path = get_excel_path(filepath)
        from excel_mcp.workbook import safe_workbook
        from excel_mcp.cell_validation import get_all_validation_ranges

        with safe_workbook(full_path) as wb:
            ws = require_worksheet(
                wb,
                sheet_name,
                error_cls=SheetError,
                operation="data validation inspection",
            )
            validations = get_all_validation_ranges(ws)

        return _success_response(
            "get_data_validation_info",
            data={
                "sheet_name": sheet_name,
                "validation_rules": validations,
            },
            message=(
                "No data validation rules found in this worksheet"
                if not validations
                else f"Found {len(validations)} validation rule(s) in '{sheet_name}'"
            ),
        )

    except HANDLED_TOOL_ERRORS as e:
        logger.error("get_data_validation_info failed: %s", e)
        return _error_response("get_data_validation_info", e)
    except Exception as e:
        logger.exception("Unhandled error in get_data_validation_info")
        return _error_response("get_data_validation_info", e)


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Inspect Data Validation Rules",
        readOnlyHint=True,
    ),
)
def inspect_data_validation_rules(
    filepath: str,
    sheet_name: str,
    broken_only: bool = False,
) -> str:
    """Inspect worksheet data validation rules with stable rule indexes."""
    return _run_tool(
        "inspect_data_validation_rules",
        lambda: inspect_data_validation_rules_impl(
            get_excel_path(filepath),
            sheet_name,
            broken_only=broken_only,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Remove Data Validation Rules",
        destructiveHint=True,
    ),
)
def remove_data_validation_rules(
    filepath: str,
    sheet_name: str,
    rule_indexes: Optional[List[int]] = None,
    broken_only: bool = False,
    dry_run: bool = False,
) -> str:
    """Remove worksheet data validation rules by index or remove all broken ones."""
    return _run_tool(
        "remove_data_validation_rules",
        lambda: remove_data_validation_rules_impl(
            get_excel_path(filepath),
            sheet_name,
            rule_indexes=rule_indexes,
            broken_only=broken_only,
            dry_run=dry_run,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Inspect Conditional Format Rules",
        readOnlyHint=True,
    ),
)
def inspect_conditional_format_rules(
    filepath: str,
    sheet_name: str,
    broken_only: bool = False,
) -> str:
    """Inspect worksheet conditional formatting rules with stable rule indexes."""
    return _run_tool(
        "inspect_conditional_format_rules",
        lambda: inspect_conditional_format_rules_impl(
            get_excel_path(filepath),
            sheet_name,
            broken_only=broken_only,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Remove Conditional Format Rules",
        destructiveHint=True,
    ),
)
def remove_conditional_format_rules(
    filepath: str,
    sheet_name: str,
    rule_indexes: Optional[List[int]] = None,
    broken_only: bool = False,
    dry_run: bool = False,
) -> str:
    """Remove worksheet conditional formatting rules by index or remove all broken ones."""
    return _run_tool(
        "remove_conditional_format_rules",
        lambda: remove_conditional_format_rules_impl(
            get_excel_path(filepath),
            sheet_name,
            rule_indexes=rule_indexes,
            broken_only=broken_only,
            dry_run=dry_run,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Insert Rows",
        destructiveHint=True,
    ),
)
def insert_rows(
    filepath: str,
    sheet_name: str,
    start_row: int,
    count: int = 1,
    dry_run: bool = False,
) -> str:
    """Insert one or more rows starting at the specified row."""
    return _run_tool(
        "insert_rows",
        lambda: insert_row(get_excel_path(filepath), sheet_name, start_row, count, dry_run=dry_run),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Insert Columns",
        destructiveHint=True,
    ),
)
def insert_columns(
    filepath: str,
    sheet_name: str,
    start_col: int,
    count: int = 1,
    dry_run: bool = False,
) -> str:
    """Insert one or more columns starting at the specified column."""
    return _run_tool(
        "insert_columns",
        lambda: insert_cols(get_excel_path(filepath), sheet_name, start_col, count, dry_run=dry_run),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Delete Rows",
        destructiveHint=True,
    ),
)
def delete_sheet_rows(
    filepath: str,
    sheet_name: str,
    start_row: int,
    count: int = 1,
    dry_run: bool = False,
) -> str:
    """Delete one or more rows starting at the specified row."""
    return _run_tool(
        "delete_sheet_rows",
        lambda: delete_rows(get_excel_path(filepath), sheet_name, start_row, count, dry_run=dry_run),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Delete Columns",
        destructiveHint=True,
    ),
)
def delete_sheet_columns(
    filepath: str,
    sheet_name: str,
    start_col: int,
    count: int = 1,
    dry_run: bool = False,
) -> str:
    """Delete one or more columns starting at the specified column."""
    return _run_tool(
        "delete_sheet_columns",
        lambda: delete_cols(get_excel_path(filepath), sheet_name, start_col, count, dry_run=dry_run),
    )

@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Search Cells",
        readOnlyHint=True,
    ),
)
def search_in_sheet(
    filepath: str,
    sheet_name: str,
    query: Any,
    exact: bool = True,
    max_results: int = 50,
) -> str:
    """
    Search for cells matching a value in a worksheet.
    """
    def action() -> Any:
        results = search_cells(get_excel_path(filepath), sheet_name, query, exact=exact, max_results=max_results)
        return {
            "sheet_name": sheet_name,
            "query": query,
            "exact": exact,
            "max_results": max_results,
            "matches": results,
        }

    return _run_tool("search_in_sheet", action)


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="List Sheets",
        readOnlyHint=True,
    ),
)
def list_all_sheets(filepath: str) -> str:
    """
    List all sheets in a workbook with row/column counts.
    Quick overview before reading data.
    """
    def action() -> Any:
        from excel_mcp.workbook import list_sheets

        return {"sheets": list_sheets(get_excel_path(filepath))}

    return _run_tool("list_all_sheets", action)


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Append Table Rows",
        destructiveHint=True,
    ),
)
def append_table_rows(
    filepath: str,
    sheet_name: str,
    rows: List[Dict[str, Any]],
    header_row: int = 1,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Append dictionary-shaped rows by matching worksheet headers."""
    return _run_tool(
        "append_table_rows",
        lambda: append_table_rows_impl(
            get_excel_path(filepath),
            sheet_name,
            rows,
            header_row=header_row,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Upsert Excel Table Rows",
        destructiveHint=True,
    ),
)
def upsert_excel_table_rows(
    filepath: str,
    table_name: str,
    key_column: str,
    rows: List[Dict[str, Any]],
    sheet_name: Optional[str] = None,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Update matching rows in a native Excel table and append missing keys."""
    return _run_tool(
        "upsert_excel_table_rows",
        lambda: upsert_excel_table_rows_impl(
            get_excel_path(filepath),
            table_name=table_name,
            key_column=key_column,
            rows=rows,
            sheet_name=sheet_name,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )


@mcp.tool(
    structured_output=False,
    annotations=ToolAnnotations(
        title="Update Rows by Key",
        destructiveHint=True,
    ),
)
def update_rows_by_key(
    filepath: str,
    sheet_name: str,
    key_column: str,
    updates: List[Dict[str, Any]],
    header_row: int = 1,
    dry_run: bool = False,
    include_changes: Optional[bool] = None,
) -> str:
    """Update existing table rows using a named key column."""
    return _run_tool(
        "update_rows_by_key",
        lambda: update_rows_by_key_impl(
            get_excel_path(filepath),
            sheet_name,
            key_column,
            updates,
            header_row=header_row,
            dry_run=dry_run,
            include_changes=include_changes,
        ),
    )


def run_sse():
    """Run Excel MCP server in SSE mode."""
    # Assign value to EXCEL_FILES_PATH in SSE mode
    global EXCEL_FILES_PATH
    EXCEL_FILES_PATH = os.environ.get("EXCEL_FILES_PATH", "./excel_files")
    # Create directory if it doesn't exist
    os.makedirs(EXCEL_FILES_PATH, exist_ok=True)
    
    try:
        logger.info(f"Starting Excel MCP server with SSE transport (files directory: {EXCEL_FILES_PATH})")
        mcp.run(transport="sse")
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server failed: {e}")
        raise
    finally:
        logger.info("Server shutdown complete")

def run_streamable_http():
    """Run Excel MCP server in streamable HTTP mode."""
    # Assign value to EXCEL_FILES_PATH in streamable HTTP mode
    global EXCEL_FILES_PATH
    EXCEL_FILES_PATH = os.environ.get("EXCEL_FILES_PATH", "./excel_files")
    # Create directory if it doesn't exist
    os.makedirs(EXCEL_FILES_PATH, exist_ok=True)
    
    try:
        logger.info(f"Starting Excel MCP server with streamable HTTP transport (files directory: {EXCEL_FILES_PATH})")
        mcp.run(transport="streamable-http")
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server failed: {e}")
        raise
    finally:
        logger.info("Server shutdown complete")

def run_stdio():
    """Run Excel MCP server in stdio mode."""
    # No need to assign EXCEL_FILES_PATH in stdio mode

    try:
        logger.info("Starting Excel MCP server with stdio transport")
        mcp.run(transport="stdio")
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server failed: {e}")
        raise
    finally:
        logger.info("Server shutdown complete")
