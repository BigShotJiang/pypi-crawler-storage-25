import os
from tempfile import mkstemp
from typing import TYPE_CHECKING

import click
from typing_extensions import Unpack, override

from pyinfra import logger
from pyinfra.api import QuoteString, StringCommand
from pyinfra.api.arguments import CONNECTOR_ARGUMENT_KEYS, pop_global_arguments
from pyinfra.api.exceptions import ConnectError, InventoryError, PyinfraError
from pyinfra.api.util import get_file_io, memoize
from pyinfra.progress import progress_spinner

from pyinfra.connectors.base import BaseConnector
from pyinfra.connectors.ssh import SSHConnector
from pyinfra.connectors.util import (
    extract_control_arguments,
    make_unix_command_for_host,
)


if TYPE_CHECKING:
    from pyinfra.api.arguments import ConnectorArguments
    from pyinfra.api.host import Host
    from pyinfra.api.state import State


@memoize
def show_warning() -> None:
    logger.warning("The @lxd connector is in beta!")


class LxdConnector(BaseConnector):
    has_copy = True
    has_get = True
    handles_execution = True
    lxd_cmd = "lxc"

    def __init__(self, state: "State", host: "Host"):
        super().__init__(state, host)
        self.ssh = SSHConnector(state, host)

    @override
    @staticmethod
    def make_names_data(name):
        try:
            hostname, container_name = name.split(":", 1)
        except (AttributeError, ValueError):  # failure to parse the name
            raise InventoryError("No ssh host or lxd container name provided!")

        if not container_name:
            raise InventoryError("No lxd  container name provided!")

        show_warning()

        yield (
            "@lxd/{0}:{1}".format(hostname, container_name),
            {"ssh_hostname": hostname, "lxd_container": container_name},
            ["@lxd"],
        )

    @override
    def connect(self) -> None:
        self.ssh.connect()

        global_arguments, _ = pop_global_arguments(self.state, self.host, {})
        arguments = {
            k: v for k, v in global_arguments.items() if k in CONNECTOR_ARGUMENT_KEYS
        }

        try:
            self.host.connector = self.ssh  # Fix the sudo_askpass_path file on the host
            with progress_spinner({f"{self.lxd_cmd} ls"}):
                status, _output = self.ssh.run_shell_command(
                    StringCommand(
                        self.lxd_cmd,
                        "ls",
                        self.host.data.lxd_container,
                        "--columns=ns",
                        "-f csv",
                        "|",
                        "grep",
                        "RUNNING",
                    ),
                    **arguments,
                )
                if not status:
                    raise IOError(_output.stderr)
        except PyinfraError as e:
            raise ConnectError(e.args[0])
        finally:
            self.host.connector = self  # Fix the sudo_askpass_path file on the host

        if not status:
            raise ConnectError(
                f"LXD container {self.host.data.lxd_container} is not running"
            )

        return True

    @override
    def disconnect(self) -> None:
        self.ssh.disconnect()

    @override
    def run_shell_command(
        self,
        command,
        print_output: bool = False,
        print_input: bool = False,
        **arguments: Unpack["ConnectorArguments"],
    ):
        local_arguments = extract_control_arguments(arguments)

        # We use CONNECTOR_ARGUMENT_KEYS for the local access
        for k in CONNECTOR_ARGUMENT_KEYS:
            if k in arguments:
                local_arguments[k] = arguments.pop(k)

        container_name = self.host.data.get("lxd_container")

        command = make_unix_command_for_host(
            self.state, self.host, command, **arguments
        )
        command = QuoteString(command)

        lxd_command = StringCommand(
            self.lxd_cmd,
            "exec",
            container_name,
            " -- ",
            "sh",
            "-c",
            command,
        )

        return self.ssh.run_shell_command(
            lxd_command,
            print_output=print_output,
            print_input=print_input,
            **local_arguments,
        )

    @override
    def put_file(
        self,
        filename_or_io,
        remote_filename,
        remote_temp_filename=None,
        print_output: bool = False,
        print_input: bool = False,
        **arguments: Unpack["ConnectorArguments"],
    ):
        """
        Upload a file/IO object to the target LXD container by copying it to a
        temporary location and then uploading it into the container using ``lxc file push``.
        From dockerssh.
        """

        fd, local_temp_filename = mkstemp()
        remote_temp_filename = remote_temp_filename or self.host.get_temp_filename(
            local_temp_filename
        )

        # Load our file or IO object and write it to the temporary file
        with get_file_io(filename_or_io) as file_io:
            with open(local_temp_filename, "wb") as temp_f:
                data = file_io.read()

                if isinstance(data, str):
                    data = data.encode()

                temp_f.write(data)

        # upload file to remote server
        ssh_status = self.ssh.put_file(local_temp_filename, remote_temp_filename)
        if not ssh_status:
            raise IOError("Failed to copy file over ssh")

        try:
            container_name = self.host.data.get("lxd_container")

            lxd_command = StringCommand(
                self.lxd_cmd,
                "file",
                "push",
                remote_temp_filename,
                f"{container_name}/{remote_filename}",
            )

            status, output = self.ssh.run_shell_command(
                lxd_command,
                print_output=print_output,
                print_input=print_input,
                **arguments,
            )
        finally:
            os.close(fd)
            os.remove(local_temp_filename)
            self.remote_remove(
                local_temp_filename,
                print_output=print_output,
                print_input=print_input,
                **arguments,
            )

        if not status:
            raise IOError(output.stderr)

        if print_output:
            click.echo(
                "{0}file uploaded to container: {1}".format(
                    self.host.print_prefix,
                    remote_filename,
                ),
                err=True,
            )

        return status

    @override
    def get_file(
        self,
        remote_filename,
        filename_or_io,
        remote_temp_filename=None,
        print_output: bool = False,
        print_input: bool = False,
        **arguments: Unpack["ConnectorArguments"],
    ):
        """
        Download a file from the target LXD container by copying it to a temporary
        location and then reading that into our final file/IO object.
        From dockerssh.
        """

        remote_temp_filename = remote_temp_filename or self.host.get_temp_filename(
            remote_filename
        )

        try:
            container_name = self.host.data.get("lxd_container")
            lxd_command = StringCommand(
                self.lxd_cmd,
                "file",
                "pull",
                f"{container_name}/{remote_filename}",
                remote_temp_filename,
            )

            status, output = self.ssh.run_shell_command(
                lxd_command,
                print_output=print_output,
                print_input=print_input,
                **arguments,
            )

            ssh_status = self.ssh.get_file(remote_temp_filename, filename_or_io)
        finally:
            self.remote_remove(
                remote_temp_filename,
                print_output=print_output,
                print_input=print_input,
                **arguments,
            )

        if not ssh_status:
            raise IOError("failed to copy file over ssh")

        if not status:
            raise IOError(output.stderr)

        if print_output:
            click.echo(
                "{0}file downloaded from container: {1}".format(
                    self.host.print_prefix,
                    remote_filename,
                ),
                err=True,
            )

        return status

    def remote_remove(
        self,
        filename,
        print_output: bool = False,
        print_input: bool = False,
        **arguments: Unpack["ConnectorArguments"],
    ):
        """
        Deletes a file on a remote machine over ssh.
        From dockerssh.
        """
        remove_status, output = self.ssh.run_shell_command(
            StringCommand("rm", "-f", filename),
            print_output=print_output,
            print_input=print_input,
            **arguments,
        )

        if not remove_status:
            raise IOError(output.stderr)
