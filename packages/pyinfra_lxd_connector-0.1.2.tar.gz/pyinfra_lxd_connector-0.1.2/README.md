# pyinfra-lxd-connector

Add an @lxd connector for pyinfra. It allows to run commands on LXD containers on a remote machine (via SSH).

## Installation

```shell
# With pip.
pip install pyinfra-lxd-connector

# With pipx.
pipx inject pyinfra pyinfra-lxd-connector

# With uv.
uv tool install pyinfra --with pyinfra-lxd-connector
```

## Usage

```
pyinfra @lxd/remotehost:container ...
```

## Support

If you have any feature requests, bug reports or security issues, please log them on our issue tracker.

## License

The pyinfra-lxd-connector code is released under MIT.
