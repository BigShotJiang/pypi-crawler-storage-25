# dissyslab/cli.py
"""
`dsl` — command-line entry point for DisSysLab.

After `pip install dissyslab`, users get a `dsl` command with
subcommands aimed at first-year undergraduates:

    dsl list                      list offices that ship with dissyslab
    dsl init <office> <folder>    copy a gallery office into <folder>
    dsl run <office_dir>          run a closed office end-to-end
    dsl build <office_dir>        generate app.py for an open office
    dsl doctor                    sanity-check Python, deps, and API key
    dsl --version                 print the installed dissyslab version

This module is intentionally small: it dispatches to the real
implementation elsewhere in the package. New subcommands should be
added as small handler functions below; keep the top-level
argument parsing boring and readable.
"""

from __future__ import annotations

import argparse
import importlib
import os
import runpy
import shutil
import sys
import traceback
from pathlib import Path
from typing import Callable


# ── Helpers ───────────────────────────────────────────────────────────────────

def _eprint(msg: str) -> None:
    """Print to stderr so tooling can separate progress from data output."""
    print(msg, file=sys.stderr)


def _require_dir(label: str, path_str: str) -> Path:
    p = Path(path_str)
    if not p.is_dir():
        _eprint(f"Error: {label} '{path_str}' is not a directory.")
        sys.exit(2)
    return p


def _package_version() -> str:
    try:
        from importlib.metadata import version
        return version("dissyslab")
    except Exception:
        # Running from a source checkout without an installed dist.
        return "unknown (source)"


def _packaged_gallery() -> Path:
    """Return a filesystem path to the gallery that ships inside the package.

    Works for normal `pip install dissyslab` installs and for editable
    (`pip install -e .`) installs alike, because importlib.resources
    resolves to the real on-disk location in both cases.
    """
    from importlib.resources import files
    trav = files("dissyslab") / "gallery"
    return Path(str(trav))


def _one_line_description(office_dir: Path) -> str:
    """Find a short one-line description for an office, or '' if none.

    Returns the first non-blank, non-heading line of README.md (or
    office.md as a fallback) that is not the `**Tags:**` line.
    """
    for candidate in ("README.md", "office.md"):
        f = office_dir / candidate
        if not f.is_file():
            continue
        try:
            for line in f.read_text(encoding="utf-8").splitlines():
                s = line.strip()
                if not s:
                    continue
                if s.startswith("#"):
                    continue
                if s.startswith("**Tags:**"):
                    continue
                # Strip simple markdown bold markers so the terminal
                # output reads naturally — e.g. `**Foo.**` → `Foo.`.
                cleaned = s.replace("**", "")
                return cleaned[:80]
        except OSError:
            continue
    return ""


def _read_tags(office_dir: Path) -> list[str]:
    """Read the `**Tags:**` line from an office's README.md.

    Convention (see dev/PATH_A_FRICTION_SEQUENCE.md, item #34): every
    gallery office has a single line of the form

        **Tags:** tag1, tag2, tag3

    just under the lead paragraph. Returns the tags in declared order
    with whitespace stripped, or [] if the line is absent.
    """
    f = office_dir / "README.md"
    if not f.is_file():
        return []
    try:
        for line in f.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if s.startswith("**Tags:**"):
                rest = s[len("**Tags:**"):].strip()
                return [t.strip() for t in rest.split(",") if t.strip()]
    except OSError:
        return []
    return []


# Curriculum-ordered concept groups for `dsl list`. Each office's
# group is determined by which concept tag it carries, scanned in the
# order below; the first match wins. (`starter` outranks
# `single-agent` so my_first_office lands under "Starter" rather
# than alongside the polling monitors.)
_CONCEPT_GROUPS: list[tuple[str, str]] = [
    ("starter", "Starter"),
    ("single-agent", "Single-agent monitors"),
    ("filter", "One-agent filter"),
    ("handoff", "Two-agent handoff"),
    ("feedback-loop", "Two-agent feedback loop"),
    ("live-stream", "Live streaming"),
    ("network-of-offices", "Networks of offices"),
]
_FALLBACK_GROUP = "Other"


def _group_for(tags: list[str]) -> str:
    """Return the curriculum group label for an office's tags.

    Priority is *most-specific concept wins* — `starter` outranks
    `single-agent`, `live-stream` outranks `two-agent`, etc. The
    priority order is encoded in `_CONCEPT_GROUPS`.
    """
    # `starter` is the only tag that should outrank `single-agent`.
    # Otherwise prefer the most specific concept tag the office carries.
    if "starter" in tags:
        return dict(_CONCEPT_GROUPS)["starter"]
    # Walk priority order in reverse so more-specific concepts win.
    for tag, label in reversed(_CONCEPT_GROUPS):
        if tag == "starter":
            continue
        if tag in tags:
            return label
    return _FALLBACK_GROUP


# ── Subcommand: run ───────────────────────────────────────────────────────────

def _explain_failure(command: str, exc: BaseException) -> str:
    """
    Convert a raw Python exception from `dsl run` / `dsl build` into a
    Path-A-friendly message with an actionable next step.

    Path A users don't know what `ModuleNotFoundError` or a 401 from
    Anthropic means. This mapper trades a pristine Python traceback for
    a line the student can actually do something with. Unknown errors
    fall through to a typed message + traceback so we never silently
    hide information (an empty `str(exc)` used to mean the user saw
    "dsl run failed:" with nothing after the colon).

    Set DSL_DEBUG=1 to append the full Python traceback to *any* message
    — useful when a friendly mapping fired but you want to see the raw
    exception underneath (e.g. for filing an issue).
    """
    message = _explain_failure_message(command, exc)
    if os.environ.get("DSL_DEBUG"):
        tb = "".join(
            traceback.format_exception(type(exc), exc, exc.__traceback__)
        )
        if "Full traceback:" not in message:
            message = f"{message}\n\nFull traceback:\n{tb}"
    return message


def _explain_failure_message(command: str, exc: BaseException) -> str:
    """The actual exception → user-message mapper. See _explain_failure."""
    msg = str(exc)

    # Missing Python module — almost always a stale-generated app.py or
    # a package the user forgot to install in this venv.
    if isinstance(exc, ModuleNotFoundError):
        name = exc.name or ""
        if name in {"components", "dsl"}:
            return (
                f"{command} failed: the office's app.py uses the old "
                f"'{name}' import path.\n"
                f"  Fix: regenerate with  dsl build <office_dir>\n"
                f"       or `dsl init` a fresh copy from the gallery."
            )
        if name in {
            "anthropic", "dotenv", "feedparser", "requests",
            "websocket", "bs4", "PIL", "numpy", "scipy",
        }:
            return (
                f"{command} failed: dependency '{name}' is not importable.\n"
                f"  Fix: pip install --upgrade dissyslab\n"
                f"       (or activate the venv where dissyslab is installed)"
            )
        if name == "dissyslab":
            return (
                f"{command} failed: dissyslab isn't installed in this Python "
                f"environment.\n"
                f"  Fix: compare `which dsl` and `which python` — they must "
                f"match.\n"
                f"       If you're using a venv, activate it first.\n"
                f"       See API_KEY_SETUP.md for details."
            )
        return (
            f"{command} failed: module '{name}' not found.\n"
            f"  The office may depend on a package not yet installed, or\n"
            f"  was generated by an older dissyslab version. Try `dsl doctor`."
        )

    # Anthropic auth / rate-limit errors bubble up as anthropic.APIError
    # subclasses; match on the message text so we don't have to import.
    lower = msg.lower()
    if "401" in msg and ("authentication" in lower or "invalid" in lower and "key" in lower):
        return (
            f"{command} failed: Anthropic rejected the API key (HTTP 401).\n"
            f"  Fix: run `dsl doctor` from the office folder to check .env,\n"
            f"       then re-copy your key from https://console.anthropic.com/\n"
            f"       See API_KEY_SETUP.md for the full checklist."
        )
    if "429" in msg or "rate limit" in lower:
        return (
            f"{command} failed: rate limited by an external API (HTTP 429).\n"
            f"  Fix: wait a minute and try again, or increase poll_interval\n"
            f"       in your office.md so the source polls less often."
        )
    # Two flavors of "no key": (1) our own code raising with the env-var
    # name visible, (2) the Anthropic SDK's own "Could not resolve
    # authentication method…" when the client is constructed with no key
    # at all. The second is what a brand-new student hits first.
    if (
        "anthropic_api_key" in lower
        and ("not set" in lower or "missing" in lower or "none" in lower)
    ) or "could not resolve authentication method" in lower:
        return (
            f"{command} failed: ANTHROPIC_API_KEY isn't set.\n"
            f"  Fix: create a .env file in the office folder:\n"
            f"         echo \"ANTHROPIC_API_KEY=<your-key>\" > .env\n"
            f"       See API_KEY_SETUP.md for the full walkthrough."
        )

    # Common file-not-found during app startup (e.g. missing app.py).
    if isinstance(exc, FileNotFoundError):
        missing = getattr(exc, "filename", None) or "(unknown)"
        return (
            f"{command} failed: file not found: {missing}\n"
            f"  If this is app.py, run `dsl build <office_dir>` first.\n"
            f"  If this is .env, see API_KEY_SETUP.md."
        )

    # Fall-through: unknown exception. Always show the type name (so the
    # message is non-empty even when str(exc) is empty), plus the full
    # traceback. The traceback is the most useful thing for debugging an
    # unknown error and the most useful thing to paste into a bug report.
    tb = "".join(
        traceback.format_exception(type(exc), exc, exc.__traceback__)
    )
    summary = str(exc).strip()
    head = (
        f"{command} failed: {type(exc).__name__}: {summary}"
        if summary
        else f"{command} failed: {type(exc).__name__} (no message)."
    )
    return f"{head}\n\nFull traceback:\n{tb}"


def cmd_run(args: argparse.Namespace) -> int:
    """Validate and run a closed office in-process via office_compiler."""
    office_dir = _require_dir("office_dir", args.office_dir)

    # Delegate to the existing office_compiler module, preserving its
    # argv contract (argv[1] is the office directory).
    sys.argv = ["dsl run", str(office_dir)]
    try:
        runpy.run_module(
            "dissyslab.office.office_compiler",
            run_name="__main__",
        )
    except SystemExit as e:
        # office_compiler uses sys.exit for clean user-facing errors.
        return int(e.code or 0)
    except Exception as exc:  # noqa: BLE001
        _eprint(_explain_failure("dsl run", exc))
        return 1
    return 0


# ── Subcommand: build ─────────────────────────────────────────────────────────

def cmd_build(args: argparse.Namespace) -> int:
    """Generate app.py for an (open or closed) office using make_office."""
    office_dir = _require_dir("office_dir", args.office_dir)

    sys.argv = ["dsl build", str(office_dir)]
    try:
        runpy.run_module(
            "dissyslab.office.make_office",
            run_name="__main__",
        )
    except SystemExit as e:
        return int(e.code or 0)
    except Exception as exc:  # noqa: BLE001
        _eprint(_explain_failure("dsl build", exc))
        return 1
    return 0


# ── Subcommand: list ──────────────────────────────────────────────────────────

def cmd_list(args: argparse.Namespace) -> int:
    """List the gallery offices that ship with the installed dissyslab.

    Output is grouped by curriculum concept (Starter → Single-agent
    monitors → … → Networks of offices) so a student can find an
    example by the question they're asking ("where's the simple
    one?") rather than by alphabetical name.
    """
    gallery = _packaged_gallery()
    if not gallery.is_dir():
        _eprint(
            "Could not find the gallery that ships with dissyslab.\n"
            "This is usually a packaging bug — please report it at\n"
            "https://github.com/kmchandy/DisSysLab/issues."
        )
        return 2

    offices = sorted(
        p for p in gallery.iterdir()
        if p.is_dir()
        and not p.name.startswith(".")
        and not p.name.startswith("__")  # skip __pycache__
    )
    if not offices:
        print("(no offices found — this dissyslab install may be incomplete)")
        return 0

    # Bucket offices by curriculum group. Within a group, sort
    # alphabetically by folder name.
    buckets: dict[str, list[Path]] = {}
    office_tags: dict[str, list[str]] = {}
    for p in offices:
        tags = _read_tags(p)
        office_tags[p.name] = tags
        buckets.setdefault(_group_for(tags), []).append(p)

    # Print groups in curriculum order. Any group not in the
    # curriculum (the `_FALLBACK_GROUP`) prints last.
    group_order = [label for _, label in _CONCEPT_GROUPS]
    if _FALLBACK_GROUP in buckets:
        group_order.append(_FALLBACK_GROUP)

    name_width = max(len(p.name) for p in offices)

    print("Offices shipped with dissyslab:")
    print()
    for group_label in group_order:
        group = buckets.get(group_label)
        if not group:
            continue
        print(f"  {group_label}")
        for p in group:
            hint = _one_line_description(p)
            tags = office_tags[p.name]
            tag_str = " ".join(f"[{t}]" for t in tags) if tags else ""
            line1 = f"    {p.name:<{name_width}}"
            if hint:
                line1 += f"  {hint}"
            print(line1)
            if tag_str:
                # Indent tags under the office name for scannability.
                pad = " " * (4 + name_width + 2)
                print(f"{pad}{tag_str}")
        print()

    print("To copy an office into your own folder:")
    print("  dsl init <office_name> <folder>")
    return 0


# ── Subcommand: init ──────────────────────────────────────────────────────────

def cmd_init(args: argparse.Namespace) -> int:
    """Copy a gallery office into a new folder the user owns."""
    gallery = _packaged_gallery()
    source = gallery / args.office_name

    if not source.is_dir():
        _eprint(f"Error: no office named '{args.office_name}' in the gallery.")
        _eprint("Run `dsl list` to see available offices.")
        return 2

    target = Path(args.target).resolve()
    if target.exists():
        _eprint(f"Error: target folder '{target}' already exists.")
        _eprint("Refusing to overwrite. Choose a different folder name.")
        return 2

    try:
        shutil.copytree(
            source,
            target,
            ignore=shutil.ignore_patterns(
                "__pycache__", "*.pyc", "__init__.py"
            ),
        )
    except OSError as exc:
        _eprint(f"Error copying office: {exc}")
        return 1

    print(f"Copied '{args.office_name}' to {target}")
    print()
    print("Next steps:")
    print(f"  cd {target}")
    print("  dsl run .")
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print()
        print("Tip: this office needs ANTHROPIC_API_KEY to run.")
        print("     Put it in a .env file in your office folder, or export")
        print("     it in your shell. Get a key at https://console.anthropic.com/")
    return 0


# ── Subcommand: doctor ────────────────────────────────────────────────────────

# Common user mistakes: saving .env in TextEdit (becomes RTF), or pasting
# shell commands into the file instead of KEY=VALUE lines. Detecting these
# saves students a lot of confused troubleshooting.
_SHELL_COMMAND_PREFIXES = (
    "export ", "set ", "unset ", "echo ", "source ",
    "grep ", "setenv ", "cat ", "#!",
)


def _diagnose_env_file() -> tuple[str, str]:
    """
    Inspect ./.env and return (status, detail).

    status is one of:
        "absent"         — no .env file (may still be fine if env var is set)
        "unreadable"     — exists but cannot be read
        "rtf"            — saved as RTF (TextEdit default)
        "shell"          — contains shell commands, not KEY=VALUE lines
        "no_key"         — well-formed but missing ANTHROPIC_API_KEY
        "empty_value"    — ANTHROPIC_API_KEY= with empty value
        "wrong_prefix"   — ANTHROPIC_API_KEY value doesn't start with sk-ant-
        "ok"             — well-formed .env with an Anthropic-shaped key

    detail is a one-line human-readable summary for the OK/FAIL line.
    """
    env_path = Path(".env")
    if not env_path.exists():
        return ("absent", "no .env in current directory")

    try:
        raw = env_path.read_bytes()
    except OSError as exc:
        return ("unreadable", f"exists but cannot be read ({exc.__class__.__name__})")

    # RTF files start with {\rtf (TextEdit's default for "plain" text on macOS
    # if the file was ever saved via rich-text format).
    if raw.startswith(b"{\\rtf"):
        return ("rtf", "saved as RTF (probably via TextEdit)")

    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return ("unreadable", "contains non-UTF-8 bytes")

    # Shell commands as contents — someone pasted their terminal history.
    shell_lines = [
        (i, stripped)
        for i, line in enumerate(text.splitlines(), 1)
        if (stripped := line.strip())
        and any(stripped.startswith(p) for p in _SHELL_COMMAND_PREFIXES)
    ]
    if shell_lines:
        first_line_num, first_line = shell_lines[0]
        preview = first_line[:50] + ("…" if len(first_line) > 50 else "")
        return ("shell", f"contains shell commands (line {first_line_num}: {preview})")

    # Look for ANTHROPIC_API_KEY= line.
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("ANTHROPIC_API_KEY"):
            if "=" not in stripped:
                return ("no_key", "malformed ANTHROPIC_API_KEY line (no '=')")
            _, _, value = stripped.partition("=")
            value = value.strip().strip('"').strip("'")
            if not value:
                return ("empty_value", "ANTHROPIC_API_KEY is set to empty string")
            if not value.startswith("sk-ant-"):
                return (
                    "wrong_prefix",
                    f"ANTHROPIC_API_KEY value starts with {value[:8]!r}, "
                    f"not 'sk-ant-'",
                )
            return ("ok", f"ANTHROPIC_API_KEY present (prefix {value[:7]}…, len {len(value)})")

    return ("no_key", "no ANTHROPIC_API_KEY line found")


def _env_file_advice(status: str) -> list[str]:
    """Human-readable fix suggestions for each bad .env status."""
    if status == "rtf":
        return [
            "Fix: TextEdit saves as RTF by default. Recreate as plain text:",
            "       rm .env",
            '       echo "ANTHROPIC_API_KEY=<paste-your-key>" > .env',
            "     Or open .env in VS Code / nano — not TextEdit.",
        ]
    if status == "shell":
        return [
            "Fix: .env should contain KEY=VALUE lines, not shell commands.",
            "     Recreate from scratch:",
            "       rm .env",
            '       echo "ANTHROPIC_API_KEY=<paste-your-key>" > .env',
        ]
    if status in ("no_key", "empty_value"):
        return [
            "Fix: add your Anthropic API key to .env:",
            '       echo "ANTHROPIC_API_KEY=<paste-your-key>" > .env',
            "     Get a key at https://console.anthropic.com/",
        ]
    if status == "wrong_prefix":
        return [
            "Fix: Anthropic keys start with 'sk-ant-'. Double-check you",
            "     copied the whole key from https://console.anthropic.com/",
        ]
    if status == "unreadable":
        return [
            "Fix: .env exists but can't be read. Check permissions, or",
            "     delete and recreate it:",
            "       rm .env",
            '       echo "ANTHROPIC_API_KEY=<paste-your-key>" > .env',
        ]
    if status == "absent":
        return [
            "Fix: no .env was found in the current directory. Either",
            "     create one here, or run `dsl doctor` from inside your",
            "     office folder. Quick create:",
            '       echo "ANTHROPIC_API_KEY=<paste-your-key>" > .env',
        ]
    return []


def cmd_doctor(args: argparse.Namespace) -> int:
    """Check Python, key deps, .env file format, and ANTHROPIC_API_KEY."""
    ok = True

    def check(label: str, cond: bool, detail: str = "") -> None:
        nonlocal ok
        mark = "OK" if cond else "FAIL"
        ok = ok and cond
        print(f"  [{mark}] {label}" + (f": {detail}" if detail else ""))

    print(f"dissyslab version: {_package_version()}")
    print(f"Python:            {sys.version.split()[0]}  ({sys.executable})")
    print()
    print("Dependencies:")
    for mod in ("anthropic", "dotenv", "feedparser", "requests",
                "websocket", "bs4", "PIL", "numpy", "scipy"):
        try:
            importlib.import_module(mod)
            check(mod, True)
        except Exception as exc:  # noqa: BLE001
            check(mod, False, f"not importable ({exc.__class__.__name__})")

    print()
    print("Local .env:")
    env_status, env_detail = _diagnose_env_file()
    env_ok = env_status in ("ok", "absent")
    check(".env format", env_ok, env_detail)
    # "absent" is not a hard failure *if* the key is in the environment;
    # we detect that below with the ANTHROPIC_API_KEY check.
    env_advice = _env_file_advice(env_status) if env_status not in ("ok", "absent") else []

    print()
    print("Credentials:")
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if key:
        # Never print the key itself; a length + prefix is enough.
        check("ANTHROPIC_API_KEY", True, f"set (prefix {key[:7]}…, len {len(key)})")
    else:
        check(
            "ANTHROPIC_API_KEY",
            False,
            "not set in environment (put it in .env or export in your shell)",
        )
        # If there's no key in the env AND no usable .env, nudge the student.
        if env_status == "absent":
            env_advice = _env_file_advice("absent")

    # Print fix suggestions after the table, so the check list stays scannable.
    if env_advice:
        print()
        for line in env_advice:
            print(f"  {line}")

    print()
    if ok:
        print("All checks passed.")
        return 0
    print("One or more checks failed. See above.")
    return 1


# ── Argument parser ───────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dsl",
        description=(
            "DisSysLab — build continuous offices of AI agents in plain English.\n"
            "See https://github.com/kmchandy/DisSysLab for docs."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"dissyslab {_package_version()}",
    )
    sub = parser.add_subparsers(dest="command", metavar="<command>")
    sub.required = True

    p_list = sub.add_parser(
        "list", help="list offices that ship with dissyslab"
    )
    p_list.set_defaults(handler=cmd_list)

    p_init = sub.add_parser(
        "init", help="copy a gallery office into a new folder"
    )
    p_init.add_argument(
        "office_name", help="name of the office (see `dsl list`)"
    )
    p_init.add_argument(
        "target", help="folder to create (must not exist)"
    )
    p_init.set_defaults(handler=cmd_init)

    p_run = sub.add_parser("run", help="run a closed office")
    p_run.add_argument("office_dir", help="path to an office directory")
    p_run.set_defaults(handler=cmd_run)

    p_build = sub.add_parser("build", help="generate app.py for an office")
    p_build.add_argument("office_dir", help="path to an office directory")
    p_build.set_defaults(handler=cmd_build)

    p_doc = sub.add_parser(
        "doctor",
        help="check Python, dependencies, and API key",
    )
    p_doc.set_defaults(handler=cmd_doctor)

    return parser


def main(argv: list[str] | None = None) -> int:
    # Load .env from the current working directory (or any ancestor) so that
    # students who follow the micro-course and put ANTHROPIC_API_KEY into a
    # .env file in their office folder actually get it picked up by `dsl run`.
    # This has to happen before any subcommand runs, because ai_agent.py and
    # friends read os.environ directly at call time. If no .env is found,
    # load_dotenv() is a no-op.
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass

    parser = build_parser()
    args = parser.parse_args(argv)
    handler: Callable[[argparse.Namespace], int] = args.handler
    return handler(args)


if __name__ == "__main__":
    raise SystemExit(main())
