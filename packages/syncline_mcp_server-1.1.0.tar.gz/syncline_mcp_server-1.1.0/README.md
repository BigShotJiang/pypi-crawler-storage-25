# Syncline MCP Server (Python)

<!--
mcp-name: com.kekwanu/syncline-mcp-server-python
-->

Official Model Context Protocol (MCP) server for Syncline - AI-powered meeting scheduling. Pure Python implementation with async support.

**📦 Other Implementations:**
[TypeScript (Node.js)](https://www.npmjs.com/package/@kekwanulabs/syncline-mcp-server) • [Go (High Performance)](https://www.npmjs.com/package/@kekwanulabs/syncline-mcp-server-go)

All implementations are functionally identical and maintained in sync. Choose the one that fits your environment best.

## What is MCP?

The Model Context Protocol (MCP) is an open protocol by Anthropic that enables AI models like Claude to securely interact with external tools and data sources. With Syncline's MCP server, Claude can autonomously schedule meetings, check availability, and manage calendars through natural conversation.

## Features

- **AI Auto-Scheduling**: Let Claude pick the optimal meeting time using Syncline's learning AI
- **Availability Checking**: Find all available slots across attendees
- **Calendar Status**: Verify user calendar connections
- **Manual Scheduling**: Book meetings at specific times
- **Context-Aware**: Support for 13 meeting contexts (investor_call, team_standup, etc.)
- **Smart Learning**: Every booking improves Syncline's AI accuracy
- **Async/Await**: Modern Python async architecture for optimal performance
- **Type-Safe**: Full type hints for better IDE support

## Installation

### Prerequisites

- Python 3.10 or higher
- A Syncline account with API key ([Get one here](https://syncline.run))
- Claude Desktop app

### 1. Install the MCP Server

```bash
pip install syncline-mcp-server
```

Or with pipx for isolated installation:

```bash
pipx install syncline-mcp-server
```

### 2. Configure Claude Desktop

Add the Syncline MCP server to your Claude Desktop configuration:

**macOS/Linux**: `~/Library/Application Support/Claude/claude_desktop_config.json`

**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "syncline": {
      "command": "syncline-mcp-server",
      "env": {
        "SYNCLINE_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

Alternatively, if using uvx (recommended for Python MCP servers):

```json
{
  "mcpServers": {
    "syncline": {
      "command": "uvx",
      "args": ["syncline-mcp-server"],
      "env": {
        "SYNCLINE_API_KEY": "your_api_key_here"
      }
    }
  }
}
```

### 3. Restart Claude Desktop

Restart Claude Desktop to load the MCP server. You should see "Syncline" appear in the MCP tools list.

## Usage

Once configured, Claude can use Syncline tools through natural conversation:

### Example 1: AI Auto-Scheduling

```
You: Schedule a 30-minute investor call with alice@example.com and bob@example.com
     sometime next week. Let the AI pick the best time.

Claude: I'll use Syncline's AI to find the optimal time for your investor call.
        [Uses schedule_auto tool]

        Perfect! I've scheduled your investor call for Tuesday, January 16th at 2:00 PM PST.

        Why this time was chosen:
        - Both attendees have high energy levels in early afternoon
        - No meetings immediately before/after (buffer time)
        - Fair timezone for all participants
        - Aligns with typical investor call patterns

        Calendar invites have been sent to all attendees.
```

### Example 2: Check Availability First

```
You: What times are available for a 1-hour meeting with alice@example.com
     next Monday?

Claude: Let me check availability for next Monday.
        [Uses find_availability tool]

        Here are the available slots for a 1-hour meeting on Monday, January 15th:

        - 9:00 AM - 10:00 AM
        - 11:30 AM - 12:30 PM
        - 2:00 PM - 3:00 PM
        - 4:00 PM - 5:00 PM

        Which time works best for you?

You: Book the 2 PM slot

Claude: Done! I've scheduled the meeting for Monday, January 15th at 2:00 PM.
        [Uses schedule_meeting tool]
```

### Example 3: Verify Calendar Connections

```
You: Can you check if alice@example.com has connected their calendar?

Claude: [Uses get_user_calendar_status tool]

        Yes, Alice has connected their Google Calendar.
        Last synced: 2 minutes ago
        Status: Active
```

## Available Tools (11)

### 1. `schedule_auto` (Recommended)

AI-powered scheduling that picks the optimal time automatically.

**When to use**: When you want the best possible time without manual selection.

**Parameters**:
- `attendees`: Array of email addresses (2-10)
- `duration_minutes`: Meeting length (e.g., 30, 60)
- `title`: Meeting title
- `context`: Meeting type (warm_intro, investor_call, team_standup, etc.)
- `description`: Optional agenda
- `natural_language_context`: Natural language description for Claude AI to determine meeting organizer (e.g., "Alice pitching to investor Bob")
- `force_organizer`: Override organizer detection by specifying an attendee email
- `earliest_date`: Optional start of search window (YYYY-MM-DD)
- `latest_date`: Optional end of search window (YYYY-MM-DD)
- `location`: Optional location (Zoom, Office, etc.)
- `preferred_link_type`: `auto`, `google_meet`, `teams`, `zoom`, or `none`

**Intelligent Organizer Detection**: The `natural_language_context` parameter enables Claude AI to determine who should create the calendar event based on social dynamics:

- "Alice pitching to investor" → Alice organizes (requesting time)
- "Get on Maria's calendar for office hours" → Maria organizes (hosting)
- "Interview candidate" → Company organizes (hiring)

Falls back to first attendee if not provided or Claude unavailable.

### 2. `find_availability`

Find all available time slots.

**When to use**: When you want to see options or give the user choice.

**Parameters**:
- `attendees`: Array of email addresses (2-10)
- `duration_minutes`: Meeting length
- `earliest_date`: Start of search window (YYYY-MM-DD)
- `latest_date`: End of search window (YYYY-MM-DD)

### 3. `schedule_meeting`

Schedule a meeting at a specific time.

**When to use**: When you already know the desired time.

**Parameters**:
- `attendees`: Array of email addresses (2-10)
- `start_time`: ISO 8601 timestamp
- `duration_minutes`: Meeting length
- `title`: Meeting title
- `description`: Optional agenda
- `location`: Optional location

### 4. `get_user_calendar_status`

Check if a user has connected their calendar.

**When to use**: Before attempting to schedule with new attendees.

**Parameters**:
- `email`: User's email address

### 5. `create_scheduling_request`

Start an async scheduling flow with full lifecycle tracking.

**When to use**: When attendees may not have connected calendars yet, when you need approval before booking, or when your agent needs webhook notifications at every stage. Use `schedule_auto` for simpler fire-and-forget scheduling where everyone is already connected.

**How it works**: The request progresses through stages: `created` → `awaiting_connection` (if someone needs to connect) → `proposed` (slots found) → `booked` or `failed`. In `auto_preferred` mode, Syncline books the best time automatically. In `approval_required` mode, it proposes top slots and waits for you to call `approve_scheduling_request`. Every state change fires a webhook.

**Parameters**:
- `attendees`: Array of email addresses (2-10)
- `duration_minutes`: Meeting length
- `title`: Meeting title
- `description`: Optional description
- `context`: Meeting context for scheduling intelligence
- `mode`: `auto_preferred` (default) or `approval_required`
- `earliest_date`: Optional earliest date (YYYY-MM-DD)
- `latest_date`: Optional latest date (YYYY-MM-DD)

### 6. `get_scheduling_request`

Check where a scheduling request is in its lifecycle.

**When to use**: To poll request progress, display status to your users, or check what action is needed next. Returns the current status, proposed time slots (if in `proposed` state), resolution details (if booked or failed), and the next required action.

**Parameters**:
- `request_id`: Scheduling request ID (sr_...)

### 7. `approve_scheduling_request`

Select and book one of the proposed time slots.

**When to use**: After a scheduling request reaches `proposed` status. Review the proposed slots from `get_scheduling_request`, then approve the one that works. Syncline creates calendar events for all attendees and fires a `scheduling_request.booked` webhook.

**Parameters**:
- `request_id`: Scheduling request ID
- `slot_index`: Zero-based index of the proposed slot to select

### 8. `decline_scheduling_request`

Reject all proposed slots and end the scheduling request.

**When to use**: When none of the proposed times work. The request moves to `failed` status. You can create a new request with different parameters (wider date range, shorter duration, etc.).

**Parameters**:
- `request_id`: Scheduling request ID
- `reason`: Optional reason for declining

### 9. `create_connection_session`

Generate a hosted link for a user to connect their Google or Microsoft calendar.

**When to use**: Before scheduling — call this to get a `connect_url`, then send it to your user. They open the branded connect page, choose their calendar provider, and grant access. Once connected, you can schedule meetings on their behalf. Optionally link to a scheduling request so scheduling auto-resumes after connection.

**Parameters**:
- `participant_email`: Email of the person to connect
- `request_id`: Optional — link to a scheduling request for auto-resume
- `provider`: Optional preferred provider (`google` or `microsoft`)

### 10. `set_scheduling_autonomy`

Control when Syncline auto-books vs asks for approval for a specific user.

**When to use**: To customize scheduling behavior per user. Choose a profile: `permissive` (auto-book most meetings), `balanced` (default), or `conservative` (propose most for approval). Set per-context rules like "auto-book coffee chats but propose investor calls." The confidence threshold controls how sure the AI must be before auto-booking. The system learns and adapts from outcomes over time.

**Parameters**:
- `email`: User's email
- `profile`: `permissive`, `balanced`, or `conservative`
- `context_rules`: Per-context rules (e.g., `{"coffee_chat": "auto", "investor_call": "propose"}`)
- `confidence_threshold`: Auto-book if confidence exceeds this (0-1, default 0.7)

### 11. `set_meeting_preferences`

Set a user's preferred video conferencing tool for all future meetings.

**When to use**: To configure which video link Syncline generates when booking meetings. `auto` infers from the user's calendar provider (Google users get Meet, Microsoft users get Teams). Set `zoom` and provide a personal Zoom link for Zoom users. Set `none` for in-person meetings.

**Parameters**:
- `email`: User's email
- `preferred_link_type`: `auto`, `google_meet`, `teams`, `zoom`, or `none`
- `zoom_link`: Personal Zoom link (if zoom preferred)
- `default_location`: Fallback location text (e.g., "Room 42") when no video link is used

## Meeting Contexts

Syncline's AI uses context to understand meeting priority and energy requirements:

- `warm_intro` - Introduction to someone you know
- `cold_outreach` - First contact with new person
- `investor_call` - Meeting with investors
- `client_demo` - Product demonstration
- `team_standup` - Daily team sync
- `one_on_one` - 1:1 meeting
- `interview` - Job interview
- `sales_call` - Sales conversation
- `strategy_session` - Strategic planning
- `brainstorm` - Creative ideation
- `review` - Performance or project review
- `casual_chat` - Informal catch-up
- `urgent` - Time-sensitive meeting

## Environment Variables

- `SYNCLINE_API_KEY` (required): Your Syncline API key
- `SYNCLINE_API_URL` (optional): Custom API endpoint (defaults to production)

## REST API vs MCP

**Use MCP when**:
- Building AI assistants or agents
- Want conversational scheduling interface
- Need autonomous decision-making
- Integrating with Claude or other AI models

**Use REST API when**:
- Building traditional web/mobile apps
- Need direct control over API calls
- Implementing custom UI workflows
- Prefer explicit programming

Both approaches use the same underlying Syncline infrastructure and share the same learning system.

## Troubleshooting

### "SYNCLINE_API_KEY environment variable is required"

Make sure you've added your API key to the Claude Desktop config file:

```json
"env": {
  "SYNCLINE_API_KEY": "sk_live_..."
}
```

### MCP Server Not Appearing in Claude Desktop

1. Check that the config file path is correct
2. Verify JSON syntax is valid (use a JSON validator)
3. Restart Claude Desktop completely
4. Check Claude's MCP logs for errors

### "User calendar not connected" errors

Users must connect their calendar before scheduling:
1. Send them to: https://syncline.run/developer
2. They'll authenticate with Google/Microsoft
3. Use `get_user_calendar_status` to verify connection

## Why Python?

The Python implementation offers:
- **Modern Async**: Built on asyncio for efficient I/O operations
- **Type Safety**: Full type hints for better development experience
- **Pythonic**: Idiomatic Python code that feels natural
- **Easy Integration**: Works seamlessly with Python AI/ML workflows

## Support

- Website: https://syncline.run
- Get API Key: https://syncline.run/developer
- Issues: https://github.com/KekwanuLabs/syncline/issues
- Email: support@syncline.run

## License

MIT

## About Syncline

Syncline is AI-powered meeting scheduling that learns from every booking to get smarter over time. Instead of basic slot-picking, Syncline weighs user preferences, energy patterns, timezone fairness, and meeting context to find the truly optimal time.

Built by developers, for developers. Schedule smarter, not harder.
