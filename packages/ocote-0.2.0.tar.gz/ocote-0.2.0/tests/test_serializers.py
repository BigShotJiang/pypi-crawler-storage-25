import ctypes
import unittest
import numpy as np

from ocote.serializers import (
    serialize,
    deserialize,
    schema,
    serialize_ctypes_array_of_structs,
    register_serializer,
    register_deserializer,
)


class Vec2(ctypes.Structure):
    _fields_ = [("x", ctypes.c_float), ("y", ctypes.c_float)]


class Particle(ctypes.Structure):
    _fields_ = [
        ("pos",           Vec2),
        ("mass",          ctypes.c_float),
        ("active",        ctypes.c_bool),
        ("tag",           ctypes.c_char_p),
        ("num_neighbors", ctypes.c_uint),
    ]


class Flags(ctypes.Structure):
    _fields_ = [
        ("visible",  ctypes.c_uint, 1),
        ("enabled",  ctypes.c_uint, 1),
        ("priority", ctypes.c_uint, 6),
    ]


class ColorUnion(ctypes.Union):
    _fields_ = [
        ("rgba", ctypes.c_uint32),
        ("r",    ctypes.c_uint8),
    ]


class _AnonInner(ctypes.Structure):
    _fields_ = [("ax", ctypes.c_int), ("ay", ctypes.c_int)]


class AnonOuter(ctypes.Structure):
    _anonymous_ = ("_inner",)
    _fields_    = [("_inner", _AnonInner), ("z", ctypes.c_int)]


class TestSerializeStruct(unittest.TestCase):
    def test_flat_fields(self):
        v = Vec2(x=1.5, y=2.5)
        d = serialize(v)
        self.assertEqual(d["__class__"], "Vec2")
        self.assertAlmostEqual(d["x"], 1.5, places=5)
        self.assertAlmostEqual(d["y"], 2.5, places=5)

    def test_nested_struct(self):
        p = Particle()
        p.pos.x = 3.0
        p.pos.y = 4.0
        p.mass = 1.0
        p.active = True
        p.tag = b"alpha"
        p.num_neighbors = 5
        d = serialize(p)
        self.assertAlmostEqual(d["pos"]["x"], 3.0, places=5)
        self.assertAlmostEqual(d["pos"]["y"], 4.0, places=5)
        self.assertTrue(d["active"])
        self.assertEqual(d["num_neighbors"], 5)

    def test_char_p_none(self):
        p = Particle()
        p.tag = None
        d = serialize(p)
        self.assertIsNone(d["tag"])


class TestBitfields(unittest.TestCase):
    def test_values(self):
        f = Flags()
        f.visible  = 1
        f.enabled  = 0
        f.priority = 42
        d = serialize(f)
        self.assertEqual(d["visible"],  1)
        self.assertEqual(d["enabled"],  0)
        self.assertEqual(d["priority"], 42)


class TestUnion(unittest.TestCase):
    def test_union_flag(self):
        c = ColorUnion()
        c.rgba = 0xFF
        d = serialize(c)
        self.assertTrue(d["__union__"])
        self.assertEqual(d["rgba"], 0xFF)

    def test_union_has_class(self):
        d = serialize(ColorUnion())
        self.assertEqual(d["__class__"], "ColorUnion")

class TestAnonymous(unittest.TestCase):
    def test_flattened(self):
        obj = AnonOuter()
        obj.ax = 10
        obj.ay = 20
        obj.z  = 30
        d = serialize(obj)
        self.assertEqual(d["ax"], 10)
        self.assertEqual(d["ay"], 20)
        self.assertEqual(d["z"],  30)



class TestArrays(unittest.TestCase):
    def test_numeric_as_list(self):
        arr = (ctypes.c_float * 4)(1.0, 2.0, 3.0, 4.0)
        out = serialize(arr)
        for got, exp in zip(out, [1.0, 2.0, 3.0, 4.0]):
            self.assertAlmostEqual(got, exp, places=5)

    def test_numeric_as_numpy(self):
        arr = (ctypes.c_float * 3)(5.0, 6.0, 7.0)
        out = serialize(arr, as_numpy=True)
        self.assertIsInstance(out, np.ndarray)
        self.assertEqual(out.dtype, np.float32)
        np.testing.assert_allclose(out, [5.0, 6.0, 7.0])

    def test_struct_array(self):
        arr = (Vec2 * 2)()
        arr[0].x, arr[0].y = 1.0, 2.0
        arr[1].x, arr[1].y = 3.0, 4.0
        out = serialize_ctypes_array_of_structs(arr, 2)
        self.assertAlmostEqual(out[0]["x"], 1.0, places=5)
        self.assertAlmostEqual(out[1]["y"], 4.0, places=5)

    def test_uint_array(self):
        arr = (ctypes.c_uint * 3)(10, 20, 30)
        out = serialize(arr)
        self.assertEqual(out, [10, 20, 30])


class TestPointers(unittest.TestCase):
    def test_deref(self):
        v = Vec2(x=9.0, y=8.0)
        ptr = ctypes.pointer(v)

        class Wrapper(ctypes.Structure):
            _fields_ = [("p", ctypes.POINTER(Vec2))]

        w = Wrapper()
        w.p = ptr
        d = serialize(w)
        self.assertAlmostEqual(d["p"]["x"], 9.0, places=5)

    def test_null_pointer(self):
        class Wrapper(ctypes.Structure):
            _fields_ = [("p", ctypes.POINTER(Vec2))]

        w = Wrapper()
        d = serialize(w)
        self.assertIsNone(d["p"])


class TestDeserialize(unittest.TestCase):
    def test_flat(self):
        v = deserialize({"x": 1.5, "y": 2.5}, Vec2)
        self.assertAlmostEqual(v.x, 1.5, places=5)
        self.assertAlmostEqual(v.y, 2.5, places=5)

    def test_nested(self):
        d = {
            "pos": {"x": 3.0, "y": 4.0},
            "mass": 1.0,
            "active": True,
            "tag": "beta",
            "num_neighbors": 2,
        }
        p = deserialize(d, Particle)
        self.assertAlmostEqual(p.pos.x, 3.0, places=5)
        self.assertAlmostEqual(p.mass,  1.0, places=5)
        self.assertTrue(p.active)
        self.assertEqual(p.tag, b"beta")

    def test_roundtrip(self):
        orig = Vec2(x=7.0, y=-3.0)
        back = deserialize(serialize(orig), Vec2)
        self.assertAlmostEqual(back.x, orig.x, places=5)
        self.assertAlmostEqual(back.y, orig.y, places=5)

    def test_missing_fields_default_zero(self):
        v = deserialize({"x": 1.0}, Vec2)
        self.assertAlmostEqual(v.x, 1.0, places=5)
        self.assertAlmostEqual(v.y, 0.0, places=5)

    def test_bad_target_raises(self):
        with self.assertRaises(TypeError):
            deserialize({}, int)


class TestSchema(unittest.TestCase):
    def test_basic_fields(self):
        s = schema(Vec2)
        names = [f["name"] for f in s["fields"]]
        self.assertIn("x", names)
        self.assertIn("y", names)
        self.assertEqual(s["__kind__"], "struct")

    def test_nested_schema(self):
        s = schema(Particle)
        pos = next(
            f for f in s["fields"] if f["name"] == "pos"
        )
        self.assertIn("schema", pos)
        self.assertEqual(pos["schema"]["__class__"], "Vec2")

    def test_bitfield_bits(self):
        s = schema(Flags)
        visible = next(
            f for f in s["fields"] if f["name"] == "visible"
        )
        self.assertEqual(visible["bits"], 1)

    def test_union_kind(self):
        self.assertEqual(schema(ColorUnion)["__kind__"], "union")

    def test_size_positive(self):
        self.assertGreater(schema(Particle)["__size__"], 0)


class TestNumpy(unittest.TestCase):
    def test_ndarray(self):
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        out = serialize(arr)
        for got, exp in zip(out, [1.0, 2.0, 3.0]):
            self.assertAlmostEqual(got, exp, places=5)

    def test_np_integer(self):
        out = serialize(np.int32(42))
        self.assertEqual(out, 42)
        self.assertIsInstance(out, int)

    def test_np_floating(self):
        out = serialize(np.float64(3.14))
        self.assertAlmostEqual(out, 3.14, places=5)
        self.assertIsInstance(out, float)


class TestRegistry(unittest.TestCase):
    def test_custom_serializer(self):
        class Point:
            def __init__(self, x, y):
                self.x, self.y = x, y

        @register_serializer(Point)
        def _(obj):
            return {"x": obj.x, "y": obj.y}

        self.assertEqual(serialize(Point(1, 2)), {"x": 1, "y": 2})

    def test_custom_deserializer(self):
        @register_deserializer(Vec2)
        def _(data, t):
            v = Vec2()
            v.x = data.get("x", 0.0)
            v.y = data.get("y", 0.0)
            return v

        v = deserialize({"x": 5.0, "y": 6.0}, Vec2)
        self.assertAlmostEqual(v.x, 5.0, places=5)
        self.assertAlmostEqual(v.y, 6.0, places=5)


if __name__ == "__main__":
    unittest.main()
