import ctypes
import numpy as np


_serializer_registry = {}
_deserializer_registry = {}


def register_serializer(type_):
    def decorator(fn):
        _serializer_registry[type_] = fn
        return fn
    return decorator


def register_deserializer(type_):
    def decorator(fn):
        _deserializer_registry[type_] = fn
        return fn
    return decorator


_CTYPES_INT_TYPES = (
    ctypes.c_bool,
    ctypes.c_byte,    ctypes.c_ubyte,
    ctypes.c_short,   ctypes.c_ushort,
    ctypes.c_int,     ctypes.c_uint,
    ctypes.c_long,    ctypes.c_ulong,
    ctypes.c_longlong, ctypes.c_ulonglong,
)

_CTYPES_FLOAT_TYPES = (
    ctypes.c_float,
    ctypes.c_double,
    ctypes.c_longdouble,
)

_CTYPES_CHAR_TYPES = (
    ctypes.c_char,
    ctypes.c_wchar,
)

_CTYPES_STR_TYPES = (
    ctypes.c_char_p,
    ctypes.c_wchar_p,
)

_CTYPES_SIMPLE = (
    *_CTYPES_INT_TYPES,
    *_CTYPES_FLOAT_TYPES,
    *_CTYPES_CHAR_TYPES,
    *_CTYPES_STR_TYPES,
)

_CTYPES_TO_NUMPY = {
    ctypes.c_float:     np.float32,
    ctypes.c_double:    np.float64,
    ctypes.c_byte:      np.int8,
    ctypes.c_ubyte:     np.uint8,
    ctypes.c_short:     np.int16,
    ctypes.c_ushort:    np.uint16,
    ctypes.c_int:       np.int32,
    ctypes.c_uint:      np.uint32,
    ctypes.c_long:      np.int64,
    ctypes.c_ulong:     np.uint64,
    ctypes.c_longlong:  np.int64,
    ctypes.c_ulonglong: np.uint64,
}

_NUMPY_TO_CTYPES = {v: k for k, v in _CTYPES_TO_NUMPY.items()}


def _ctype_of_array(arr):
    return arr._type_


def _is_numeric_array(arr):
    return _ctype_of_array(arr) in _CTYPES_TO_NUMPY


def _anonymous_fields(struct_type):
    anon = set(getattr(struct_type, "_anonymous_", ()))
    result = {}
    for name, *_ in struct_type._fields_:
        if name in anon:
            nested_type = dict(struct_type._fields_)[name]
            for sub, *_ in nested_type._fields_:
                result[sub] = (name, sub)
    return result


def _collect_fields(struct_type):
    anon = set(getattr(struct_type, "_anonymous_", ()))
    fields = []
    for entry in struct_type._fields_:
        fname = entry[0]
        if fname in anon:
            ftype = entry[1]
            for sub_entry in ftype._fields_:
                fields.append(sub_entry)
        else:
            fields.append(entry)
    return fields


def _is_pointer_type(obj):
    t = type(obj)
    return (
        hasattr(t, "_type_")
        and hasattr(t, "contents")
        and not isinstance(obj, ctypes.Array)
    )


def _deref_pointer(obj, depth, max_depth):
    if depth >= max_depth:
        return "<max depth>"
    try:
        contents = obj.contents
    except (ValueError, TypeError):
        return None
    return _serialize_value(contents, depth + 1, max_depth)


def _serialize_value(val, depth=0, max_depth=8):
    if val is None:
        return None

    if isinstance(val, ctypes.Structure):
        return _serialize_struct(val, depth, max_depth)

    if isinstance(val, ctypes.Union):
        return _serialize_union(val, depth, max_depth)

    if isinstance(val, ctypes.Array):
        return _serialize_array(val, depth, max_depth)

    if _is_pointer_type(val):
        return _deref_pointer(val, depth, max_depth)

    if isinstance(val, _CTYPES_STR_TYPES):
        raw = val.value
        if isinstance(raw, bytes):
            return raw.decode("utf-8", errors="replace")
        return raw

    if isinstance(val, _CTYPES_CHAR_TYPES):
        raw = val.value
        if isinstance(raw, bytes):
            return raw.decode("utf-8", errors="replace")
        return raw

    if isinstance(val, _CTYPES_SIMPLE):
        return val.value

    return val


def _serialize_struct(obj, depth=0, max_depth=8):
    out = {"__class__": type(obj).__name__}
    for entry in _collect_fields(type(obj)):
        fname = entry[0]
        raw = getattr(obj, fname)
        out[fname] = _serialize_value(raw, depth, max_depth)
    return out


def _serialize_union(obj, depth=0, max_depth=8):
    out = {
        "__class__": type(obj).__name__,
        "__union__": True,
    }
    for entry in obj._fields_:
        fname = entry[0]
        raw = getattr(obj, fname)
        out[fname] = _serialize_value(raw, depth, max_depth)
    return out


def _serialize_array(obj, depth=0, max_depth=8, as_numpy=False):
    if _is_numeric_array(obj):
        ctype = _ctype_of_array(obj)
        np_type = _CTYPES_TO_NUMPY[ctype]
        arr = np.ctypeslib.as_array(obj).astype(np_type)
        if as_numpy:
            return arr
        return arr.tolist()
    return [
        _serialize_value(item, depth, max_depth)
        for item in obj
    ]


def serialize(obj, max_depth=8, as_numpy=False):
    for type_, fn in _serializer_registry.items():
        if isinstance(obj, type_):
            return fn(obj)

    if isinstance(obj, ctypes.Structure):
        return _serialize_struct(obj, max_depth=max_depth)

    if isinstance(obj, ctypes.Union):
        return _serialize_union(obj, max_depth=max_depth)

    if isinstance(obj, ctypes.Array):
        return _serialize_array(
            obj, max_depth=max_depth, as_numpy=as_numpy
        )

    if _is_pointer_type(obj):
        return _deref_pointer(obj, 0, max_depth)

    raise TypeError(
        f"No serializer for {type(obj).__name__}"
    )


def serialize_ctypes_array_of_structs(arr, length=None):
    n = length if length is not None else len(arr)
    return [_serialize_struct(arr[i]) for i in range(n)]


def _ctypes_type_name(ftype):
    return getattr(ftype, "__name__", repr(ftype))


def schema(struct_type):
    is_union = issubclass(struct_type, ctypes.Union)
    fields_out = []
    source = (
        struct_type._fields_
        if is_union
        else _collect_fields(struct_type)
    )
    for entry in source:
        fname = entry[0]
        ftype = entry[1]
        bits  = entry[2] if len(entry) > 2 else None

        field_info = {
            "name":   fname,
            "type":   _ctypes_type_name(ftype),
            "size":   ctypes.sizeof(ftype),
            "offset": (
                getattr(
                    struct_type, fname
                ).offset if not is_union else 0
            ),
        }
        if bits is not None:
            field_info["bits"] = bits
        if (
            isinstance(ftype, type)
            and issubclass(ftype, (ctypes.Structure, ctypes.Union))
        ):
            field_info["schema"] = schema(ftype)
        fields_out.append(field_info)

    return {
        "__class__":  struct_type.__name__,
        "__kind__":   "union" if is_union else "struct",
        "__size__":   ctypes.sizeof(struct_type),
        "fields":     fields_out,
    }


def _python_to_ctype_value(ftype, val, bitfield=None):
    if val is None:
        return None

    if bitfield is not None:
        bits = bitfield

        if not isinstance(val, int):
            raise TypeError(
                f"bitfield value must be int, got {type(val).__name__}"
            )

        total_bits = ctypes.sizeof(ftype) * 8

        if bits > total_bits:
            raise ValueError(f"bitfield with {bits} exceeds total bit size {total_bits} bits")

        signed_types = (
            ctypes.c_byte,
            ctypes.c_short,
            ctypes.c_int,
            ctypes.c_long,
            ctypes.c_longlong,
        )

        is_signed = issubclass(ftype, signed_types)

        if is_signed:
            min_val = -(1 << (bits - 1))
            max_val = (1 << (bits - 1)) - 1

            if not (min_val <= val <= max_val):
                raise ValueError(
                    f"signed {bits}-bit field overflow: {val}"
                )

        else:
            max_val = (1 << bits) - 1

            if val < 0 or val > max_val:
                raise ValueError(
                    f"unsigned {bits}-bit field overflow: {val}"
                )

            val &= max_val

        return val

    if isinstance(ftype, type) and issubclass(
        ftype, (ctypes.Structure, ctypes.Union)
    ):
        return deserialize(val, ftype)

    if isinstance(ftype, type) and issubclass(ftype, ctypes.Array):
        elem_type = ftype._type_
        inst = ftype()

        for i, item in enumerate(val):
            inst[i] = _python_to_ctype_value(elem_type, item)

        return inst

    if isinstance(ftype, type) and issubclass(
        ftype, _CTYPES_STR_TYPES
    ):
        if isinstance(val, str):
            return val.encode()

        return val

    if isinstance(ftype, type) and issubclass(
        ftype, _CTYPES_CHAR_TYPES
    ):
        if isinstance(val, str):
            return val.encode()

        return val

    return val


def deserialize(data: dict, target_type):
    for type_, fn in _deserializer_registry.items():
        if issubclass(target_type, type_):
            return fn(data, target_type)

    if not (
        isinstance(target_type, type)
        and issubclass(
            target_type, (ctypes.Structure, ctypes.Union)
        )
    ):
        raise TypeError(
            f"Cannot deserialize into {target_type.__name__}"
        )

    inst = target_type()
    is_union = issubclass(target_type, ctypes.Union)
    source = (
        target_type._fields_
        if is_union
        else _collect_fields(target_type)
    )

    for entry in source:
        fname = entry[0]
        ftype = entry[1]
        if fname not in data:
            continue
        val = _python_to_ctype_value(ftype, data[fname])
        if val is not None:
            try:
                setattr(inst, fname, val)
            except TypeError:
                pass

    return inst

@register_serializer(np.ndarray)
def _(obj):
    return obj.tolist()


@register_serializer(np.integer)
def _(obj):
    return int(obj)


@register_serializer(np.floating)
def _(obj):
    return float(obj)
