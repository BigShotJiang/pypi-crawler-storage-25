"""Spline-smoothed surface normals from a gridded elevation array."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_utils.constants import WGS84, GeoEllipsoid
from scipy.interpolate import RectBivariateSpline

if TYPE_CHECKING:
    from numpy.typing import NDArray


def grid_normals_spline(
    lats: NDArray,
    lons: NDArray,
    alt_grid: NDArray,
    *,
    ellipsoid: GeoEllipsoid = WGS84,
) -> NDArray:
    """Compute unit surface normals in ECEF from a gridded elevation array.

    Fits a bicubic spline (RectBivariateSpline) to the elevation grid and
    evaluates analytic partial derivatives dz/dlat and dz/dlon. The spline
    removes step-noise from integer-meter DEM quantization that produces
    spurious normals with finite-difference gradients.

    Surface slopes are converted from degrees to ENU meters using the
    ellipsoid's meridional and prime-vertical radii of curvature at each
    grid point, so the result is geometrically correct across wide
    latitude ranges (no flat-Earth or single-reference-latitude
    approximations).

    Args:
        lats: 1D array of latitude values (degrees, row coordinates).
        lons: 1D array of longitude values (degrees, column coordinates).
        alt_grid: 2D elevation array in meters, shape (len(lats), len(lons)).
            NaN values are replaced with 0.
        ellipsoid: Geodetic reference ellipsoid. Defaults to WGS84.

    Returns:
        Unit normals in ECEF, shape (len(lats), len(lons), 3).
    """
    alt_clean = np.where(np.isnan(alt_grid), 0.0, alt_grid)
    spline = RectBivariateSpline(lats, lons, alt_clean, kx=3, ky=3)

    dh_dlat_deg = spline(lats, lons, dx=1, dy=0)
    dh_dlon_deg = spline(lats, lons, dx=0, dy=1)

    # Per-row ellipsoid geometry (broadcasts across longitude).
    lat_rad_col = np.radians(lats)[:, None]
    cos_lat_col = np.cos(lat_rad_col)
    m_lat_col = ellipsoid.m(lat_rad_col)
    n_lat_col = ellipsoid.n(lat_rad_col)

    # Meters per degree of arc along north and east at each grid point
    # (includes the +h term: arc length scales with ellipsoid radius + altitude).
    deg_to_rad = np.pi / 180.0
    m_per_deg_lat = (m_lat_col + alt_clean) * deg_to_rad
    m_per_deg_lon = (n_lat_col + alt_clean) * cos_lat_col * deg_to_rad

    slope_east = dh_dlon_deg / m_per_deg_lon
    slope_north = dh_dlat_deg / m_per_deg_lat

    # ENU unit normal: (-slope_east, -slope_north, 1) / magnitude
    nx = -slope_east
    ny = -slope_north
    nz = np.ones_like(nx)
    mag = np.sqrt(nx**2 + ny**2 + nz**2)
    nx /= mag
    ny /= mag
    nz /= mag

    # Rotate per-point ENU normal to ECEF.
    lat_grid, lon_grid = np.meshgrid(lats, lons, indexing="ij")
    lat_rad = np.radians(lat_grid)
    lon_rad = np.radians(lon_grid)
    sin_lat = np.sin(lat_rad)
    cos_lat = np.cos(lat_rad)
    sin_lon = np.sin(lon_rad)
    cos_lon = np.cos(lon_rad)

    ecef_x = -sin_lon * nx - sin_lat * cos_lon * ny + cos_lat * cos_lon * nz
    ecef_y = cos_lon * nx - sin_lat * sin_lon * ny + cos_lat * sin_lon * nz
    ecef_z = cos_lat * ny + sin_lat * nz

    return np.stack([ecef_x, ecef_y, ecef_z], axis=-1)
