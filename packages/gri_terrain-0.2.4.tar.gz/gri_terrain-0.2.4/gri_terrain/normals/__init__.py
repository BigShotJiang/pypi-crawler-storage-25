"""Surface-normal derivation from gridded elevation data."""

from .spline import grid_normals_spline

__all__ = ["grid_normals_spline"]
