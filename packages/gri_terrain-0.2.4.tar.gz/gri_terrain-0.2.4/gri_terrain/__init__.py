"""Terrain elevation data access for geolocation applications.

This package provides access to terrain elevation data from multiple sources:
- DTED (Digital Terrain Elevation Data) files
- GeoTIFF/COG (Cloud Optimized GeoTIFF) files
- Copernicus DEM (GLO-30/GLO-90) via AWS

Example:
    >>> from gri_terrain import CopernicusSource
    >>> source = CopernicusSource()
    >>> altitude = source.get_altitude(lat=40.0, lon=-105.0)

"""

from gri_terrain.intersect import ray_terrain
from gri_terrain.normals import grid_normals_spline
from gri_terrain.sources import (
    CopernicusSource,
    DTEDSource,
    GeoTiffSource,
    TerrainSource,
)

__all__ = [
    "CopernicusSource",
    "DTEDSource",
    "GeoTiffSource",
    "TerrainSource",
    "grid_normals_spline",
    "ray_terrain",
]
