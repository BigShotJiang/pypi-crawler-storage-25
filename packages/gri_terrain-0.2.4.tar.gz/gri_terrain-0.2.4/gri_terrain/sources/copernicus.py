"""Copernicus DEM source implementation via AWS S3."""

from __future__ import annotations

import logging
import urllib.request
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar

import numpy as np
from gri_utils import config
from tqdm import tqdm

from gri_terrain.sources.geotiff import GeoTiffSource

if TYPE_CHECKING:
    from gri_terrain.sources.tile_data import TileData

_log = logging.getLogger(__name__)

# Module defaults for Copernicus source
_DEFAULT_RESOLUTION = "30m"
_DEFAULT_MAX_CACHE_GB = 5.0


class CopernicusResolution(StrEnum):
    """Available Copernicus DEM resolutions."""

    GLO30 = "30m"
    GLO90 = "90m"


class CopernicusSource(GeoTiffSource):
    """Terrain source for Copernicus DEM via AWS S3.

    Accesses Copernicus GLO-30 (30m) or GLO-90 (90m) elevation data hosted on AWS
    as Cloud Optimized GeoTIFFs. Data is downloaded on demand and cached locally.

    Inherits from GeoTiffSource for all file reading and interpolation logic.
    This class handles tile URL generation, downloading, and cache management.

    The Copernicus DEM is free for commercial use with attribution:
    "(c) DLR e.V. 2010-2014 and (c) Airbus Defence and Space GmbH 2014-2018
    provided under COPERNICUS by the European Union and ESA; all rights reserved"

    Args:
        resolution: DEM resolution - GLO30 (30m) or GLO90 (90m).
            If None, uses config value or default (30m).
        cache_dir: Local directory for caching downloaded tiles.
            If None, uses config value or auto-resolves to /tmp or ~/.gri-cache.
        max_cache_size_gb: Maximum disk cache size in gigabytes.
            If None, uses config value or default (5.0).

    Example:
        >>> source = CopernicusSource(resolution=CopernicusResolution.GLO30)
        >>> alt = source.get_altitude(np.array([40.0]), np.array([-105.0]))

    """

    # HTTPS access URLs (no authentication required)
    _HTTPS_BASE_30M: ClassVar[str] = "https://copernicus-dem-30m.s3.amazonaws.com"
    _HTTPS_BASE_90M: ClassVar[str] = "https://copernicus-dem-90m.s3.amazonaws.com"

    def __init__(
        self,
        resolution: CopernicusResolution | str | None = None,
        cache_dir: str | Path | None = None,
        max_cache_size_gb: float | None = None,
    ) -> None:
        """Initialize Copernicus DEM source."""
        # Resolve resolution from config if not provided
        if resolution is None:
            res_str = config.get(
                "gri-terrain.copernicus.resolution",
                _DEFAULT_RESOLUTION,
            )
            resolution = CopernicusResolution(res_str)
        elif isinstance(resolution, str):
            try:
                resolution = CopernicusResolution(resolution)
            except ValueError:
                valid = [r.value for r in CopernicusResolution]
                msg = f"resolution must be one of {valid}, got '{resolution}'"
                raise ValueError(msg) from None
        self._resolution = resolution

        # Resolve cache directory from config if not provided
        if cache_dir is None:
            cache_dir = config.get_path("gri-terrain.copernicus.cache_dir")
        cache_path = self._resolve_cache_dir(cache_dir, resolution)
        cache_path.mkdir(parents=True, exist_ok=True)

        # Initialize parent with the cache directory. Must run before we set
        # our own cache-size attributes below, since the base class
        # initializes its own (memory-cache) budget.
        super().__init__(path=cache_path, glob_pattern="*.tif")

        # Resolve disk cache size from config if not provided. Stored under a
        # distinct attribute so it cannot collide with the base class's
        # in-memory tile budget (_max_cache_bytes).
        if max_cache_size_gb is None:
            max_cache_size_gb = float(
                config.get(
                    "gri-terrain.copernicus.max_cache_gb",
                    _DEFAULT_MAX_CACHE_GB,
                ),
            )
        self._max_disk_cache_bytes = int(max_cache_size_gb * 1024 * 1024 * 1024)

    @staticmethod
    def _resolve_cache_dir(cache_dir: str | Path | None, resolution: str) -> Path:
        """Resolve cache directory with fallback logic.

        Tries /tmp/.gri-cache/copernicus/{resolution}/ first, falls back to
        ~/.gri-cache/copernicus/{resolution}/ if /tmp is not writable.

        Args:
            cache_dir: User-specified cache directory, or None for default.
            resolution: Resolution string for subdirectory naming.

        Returns:
            Resolved cache directory path.

        """
        if cache_dir is not None:
            return Path(cache_dir)

        # Try /tmp first (S108: intentional use of /tmp for cache)
        tmp_cache = Path("/tmp/.gri-cache/copernicus") / resolution  # noqa: S108
        if CopernicusSource._is_writable_dir(tmp_cache):
            return tmp_cache

        # Fall back to home directory
        home_cache = Path.home() / ".gri-cache" / "copernicus" / resolution
        if CopernicusSource._is_writable_dir(home_cache):
            return home_cache

        msg = (
            f"Cannot create writable cache directory. Tried: {tmp_cache}, {home_cache}"
        )
        raise OSError(msg)

    @staticmethod
    def _is_writable_dir(path: Path) -> bool:
        """Test if a directory can be created and written to.

        Args:
            path: Directory path to test.

        Returns:
            True if directory exists or can be created and is writable.

        """
        try:
            path.mkdir(parents=True, exist_ok=True)
            test_file = path / ".write_test"
            test_file.touch()
            test_file.unlink()
        except OSError:
            return False
        return True

    def _load_tile(self, lat_tile: int, lon_tile: int) -> TileData | None:
        """Load tile data, downloading from AWS if needed.

        Args:
            lat_tile: Integer latitude of tile's southwest corner.
            lon_tile: Integer longitude of tile's southwest corner.

        Returns:
            TileData with elevation array and metadata, or None if no coverage.

        """
        # Build tile path and URL
        lat_char = "N" if lat_tile >= 0 else "S"
        lon_char = "E" if lon_tile >= 0 else "W"
        filename = f"{lat_char}{abs(lat_tile):02d}_{lon_char}{abs(lon_tile):03d}.tif"
        tile_path = self._path / filename

        # Download if not cached
        if not tile_path.exists():
            if self._resolution == CopernicusResolution.GLO30:
                base_url = self._HTTPS_BASE_30M
                res_code = "10"
            else:
                base_url = self._HTTPS_BASE_90M
                res_code = "30"

            tile_name = (
                f"Copernicus_DSM_COG_{res_code}_{lat_char}{abs(lat_tile):02d}_00_"
                f"{lon_char}{abs(lon_tile):03d}_00_DEM"
            )
            url = f"{base_url}/{tile_name}/{tile_name}.tif"

            try:
                self._download_tile(url, tile_path)
                self.mark_dirty()
            except urllib.request.HTTPError as e:
                # Tile doesn't exist on server (ocean, etc.)
                _log.debug("Tile not available: %s/%s (%s)", lat_tile, lon_tile, e)
                return None

        # Delegate to parent for actual file loading
        return super()._load_tile(lat_tile, lon_tile)

    def _download_tile(self, url: str, tile_path: Path) -> None:  # pragma: no cover
        """Download a tile from AWS to disk cache.

        Args:
            url: URL to download the tile from.
            tile_path: Local path to save the tile.

        Raises:
            urllib.error.HTTPError: If tile doesn't exist on server.
            OSError: If download or file write fails.

        """
        _log.info("Downloading tile from %s", url)

        # Download to temp file first, then rename for atomicity
        temp_path = tile_path.with_suffix(".tmp")
        try:
            urllib.request.urlretrieve(url, temp_path)  # noqa: S310
            file_size = temp_path.stat().st_size

            # Evict old tiles if needed
            self._evict_oldest_tiles(file_size)

            # Move temp file to final location
            temp_path.rename(tile_path)
            _log.debug(
                "Downloaded tile: %s (%.1f MB)",
                tile_path.name,
                file_size / 1e6,
            )
        except Exception:
            # Clean up temp file on failure
            if temp_path.exists():
                temp_path.unlink()
            raise

    def _get_disk_cache_size(self) -> int:
        """Get current disk cache size in bytes.

        Returns:
            Total size of all cached tiles in bytes.

        """
        total = 0
        for f in self._path.glob("*.tif"):
            total += f.stat().st_size
        return total

    def _evict_oldest_tiles(self, needed_bytes: int) -> None:
        """Evict oldest-accessed tiles to make room for new download.

        Args:
            needed_bytes: Number of bytes needed for new tile.

        """
        current_size = self._get_disk_cache_size()
        target_size = self._max_disk_cache_bytes - needed_bytes

        if current_size <= target_size:
            return

        # Get all tiles sorted by access time (oldest first)
        tiles = []
        for f in self._path.glob("*.tif"):
            stat = f.stat()
            tiles.append((stat.st_mtime, stat.st_size, f))
        tiles.sort()  # Sort by mtime ascending (oldest first)

        # Evict oldest tiles until we have enough space
        for _mtime, size, path in tiles:
            if current_size <= target_size:
                break

            _log.debug("Evicting cached tile: %s (%.1f MB)", path.name, size / 1e6)
            path.unlink()
            current_size -= size

        # Mark dirty since we removed files
        self.mark_dirty()

    def download_region(  # pragma: no cover
        self,
        lat_min: float,
        lat_max: float,
        lon_min: float,
        lon_max: float,
        *,
        show_progress: bool = True,
    ) -> int:
        """Download tiles for a region to disk cache.

        Downloads all tiles covering the specified bounding box for offline use.
        Unlike precache_region(), this only downloads to disk and does not load
        tiles into memory.

        Args:
            lat_min: Southern latitude bound in decimal degrees.
            lat_max: Northern latitude bound in decimal degrees.
            lon_min: Western longitude bound in decimal degrees.
            lon_max: Eastern longitude bound in decimal degrees.
            show_progress: Show tqdm progress bar. Default True.

        Returns:
            Number of tiles downloaded (excludes already-cached and unavailable tiles).

        """
        # Calculate tile range
        lat_tile_min = int(np.floor(lat_min))
        lat_tile_max = int(np.floor(lat_max))
        lon_tile_min = int(np.floor(lon_min))
        lon_tile_max = int(np.floor(lon_max))

        tiles_needed = [
            (lat, lon)
            for lat in range(lat_tile_min, lat_tile_max + 1)
            for lon in range(lon_tile_min, lon_tile_max + 1)
        ]

        downloaded = 0
        skipped = 0
        unavailable = 0

        iterator = tqdm(
            tiles_needed,
            desc=f"Downloading {self.name}",
            unit="tile",
            disable=not show_progress,
        )

        for lat_tile, lon_tile in iterator:
            # Build tile path and URL
            lat_char = "N" if lat_tile >= 0 else "S"
            lon_char = "E" if lon_tile >= 0 else "W"
            lat_str = f"{lat_char}{abs(lat_tile):02d}"
            lon_str = f"{lon_char}{abs(lon_tile):03d}"
            filename = f"{lat_str}_{lon_str}.tif"
            tile_path = self._path / filename

            # Skip if already cached
            if tile_path.exists():
                skipped += 1
                continue

            # Build URL
            if self._resolution == CopernicusResolution.GLO30:
                base_url = self._HTTPS_BASE_30M
                res_code = "10"
            else:
                base_url = self._HTTPS_BASE_90M
                res_code = "30"

            tile_name = (
                f"Copernicus_DSM_COG_{res_code}_{lat_char}{abs(lat_tile):02d}_00_"
                f"{lon_char}{abs(lon_tile):03d}_00_DEM"
            )
            url = f"{base_url}/{tile_name}/{tile_name}.tif"

            try:
                self._download_tile(url, tile_path)
                downloaded += 1
            except urllib.request.HTTPError:
                # Tile doesn't exist (ocean, etc.)
                unavailable += 1

        if downloaded > 0:
            self.mark_dirty()

        _log.info(
            "Download complete: %d downloaded, %d already cached, %d unavailable",
            downloaded,
            skipped,
            unavailable,
        )
        return downloaded

    @property
    def name(self) -> str:
        """Return source name."""
        # GLO30 -> "30", GLO90 -> "90"
        return f"Copernicus GLO-{self._resolution.value[:-1]}"
