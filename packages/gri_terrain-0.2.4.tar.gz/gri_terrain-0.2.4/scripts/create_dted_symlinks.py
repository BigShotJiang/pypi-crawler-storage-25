#!/usr/bin/env python3
"""Create symlinks to highest available DTED level for each tile.

This script scans DTED level directories (0, 1, 2) and creates a unified
'best' directory containing symlinks to the highest resolution data available
for each tile location.

Directory structure expected:
    /data/work/dted/
        0/          # DTED Level 0 (~900m resolution)
            e000/
                n05.dt0
            w106/
                n39.dt0
        1/          # DTED Level 1 (~90m resolution)
            ...
        2/          # DTED Level 2 (~30m resolution)
            ...

Output structure:
    /data/work/dted/
        best/       # Symlinks to highest available level
            e000/
                n05.dted -> ../../0/e000/n05.dt0
            w106/
                n39.dted -> ../../2/w106/n39.dt2  (if level 2 exists)

Usage:
    python create_dted_symlinks.py --dted-root /data/work/dted

    # Dry run to see what would be created
    python create_dted_symlinks.py --dted-root /data/work/dted --dry-run
"""

import argparse
import logging
import re
import shutil
import sys
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def _remove_directory(path: Path) -> None:
    """Remove a directory tree."""
    shutil.rmtree(path)


def parse_dted_filename(filename: str) -> tuple[str, int] | None:
    """Parse latitude and level from a DTED filename.

    Args:
        filename: The DTED filename (e.g., n39.dt2 or s10.dt0)

    Returns:
        Tuple of (lat_name, level) or None if parsing fails.
        lat_name is like "n39" or "s10"
    """
    pattern = r"([ns]\d{2})\.dt([012])"
    match = re.match(pattern, filename.lower())
    if not match:
        return None
    lat_name, level = match.groups()
    return lat_name, int(level)


def scan_level_directory(level_dir: Path) -> dict[str, dict[str, Path]]:
    """Scan a DTED level directory and return all tiles found.

    Args:
        level_dir: Path to a level directory (e.g., /data/work/dted/2)

    Returns:
        Dict mapping lon_dir -> lat_name -> file_path
        e.g., {"w106": {"n39": Path(".../w106/n39.dt2")}}
    """
    tiles: dict[str, dict[str, Path]] = {}

    if not level_dir.is_dir():
        return tiles

    for lon_dir in level_dir.iterdir():
        if not lon_dir.is_dir():
            continue
        # Validate lon_dir name (e000, w106, etc.)
        if not re.match(r"[ew]\d{3}", lon_dir.name.lower()):
            continue

        lon_name = lon_dir.name.lower()
        tiles[lon_name] = {}

        for dted_file in lon_dir.iterdir():
            if not dted_file.is_file():
                continue
            parsed = parse_dted_filename(dted_file.name)
            if parsed is None:
                continue
            lat_name, _level = parsed
            tiles[lon_name][lat_name] = dted_file

    return tiles


def _build_best_tiles_map(
    dted_root: Path,
) -> dict[str, dict[str, tuple[int, Path]]]:
    """Scan level directories and build map of best available tiles.

    Args:
        dted_root: Root DTED directory containing 0/, 1/, 2/ subdirectories.

    Returns:
        Dict mapping lon_dir -> lat_name -> (level, path) with highest level winning.
    """
    levels = [2, 1, 0]
    level_tiles: dict[int, dict[str, dict[str, Path]]] = {}

    for level in levels:
        level_dir = dted_root / str(level)
        level_tiles[level] = scan_level_directory(level_dir)
        tile_count = sum(len(lats) for lats in level_tiles[level].values())
        if tile_count > 0:
            logger.info("Level %d: found %d tiles", level, tile_count)

    best_tiles: dict[str, dict[str, tuple[int, Path]]] = {}
    for level in reversed(levels):  # Start with lowest priority (0)
        for lon_name, lat_tiles in level_tiles[level].items():
            if lon_name not in best_tiles:
                best_tiles[lon_name] = {}
            for lat_name, file_path in lat_tiles.items():
                best_tiles[lon_name][lat_name] = (level, file_path)

    return best_tiles


def _create_symlink_for_tile(
    link_path: Path,
    relative_source: Path,
    level: int,
    dted_root: Path,
    *,
    dry_run: bool,
) -> tuple[bool, bool]:
    """Create a single symlink for a tile.

    Args:
        link_path: Path for the symlink to create.
        relative_source: Relative path to the source file.
        level: DTED level of the source.
        dted_root: Root DTED directory (for logging).
        dry_run: If True, only log what would be done.

    Returns:
        Tuple of (created, error) booleans.
    """
    if dry_run:
        logger.debug(
            "[DRY RUN] %s -> %s (level %d)",
            link_path.relative_to(dted_root),
            relative_source,
            level,
        )
        return True, False
    try:
        link_path.symlink_to(relative_source)
    except OSError:
        logger.exception("Failed to create symlink %s", link_path)
        return False, True
    else:
        return True, False


def create_symlinks(
    dted_root: Path,
    *,
    dry_run: bool = False,
) -> tuple[int, int, int]:
    """Create symlinks in 'best' directory to highest available DTED level.

    Args:
        dted_root: Root DTED directory containing 0/, 1/, 2/ subdirectories.
        dry_run: If True, only log what would be done without making changes.

    Returns:
        Tuple of (created_count, skipped_count, error_count).
    """
    best_dir = dted_root / "best"

    if best_dir.exists():
        if dry_run:
            logger.info("[DRY RUN] Would remove existing directory: %s", best_dir)
        else:
            logger.info("Removing existing 'best' directory")
            _remove_directory(best_dir)

    best_tiles = _build_best_tiles_map(dted_root)
    total_tiles = sum(len(lats) for lats in best_tiles.values())
    logger.info("Total unique tile locations: %d", total_tiles)

    created = 0
    skipped = 0
    errors = 0

    for lon_name in sorted(best_tiles.keys()):
        lon_out_dir = best_dir / lon_name
        if not dry_run:
            lon_out_dir.mkdir(parents=True, exist_ok=True)

        for lat_name in sorted(best_tiles[lon_name].keys()):
            level, source_path = best_tiles[lon_name][lat_name]
            link_path = lon_out_dir / f"{lat_name}.dted"
            relative_source = (
                Path("..") / ".." / str(level) / lon_name / source_path.name
            )

            was_created, had_error = _create_symlink_for_tile(
                link_path,
                relative_source,
                level,
                dted_root,
                dry_run=dry_run,
            )
            if was_created:
                created += 1
            if had_error:
                errors += 1

    return created, skipped, errors


def main() -> int:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Create symlinks to highest available DTED level",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Create symlinks
    python create_dted_symlinks.py --dted-root /data/work/dted

    # Dry run to see what would be created
    python create_dted_symlinks.py --dted-root /data/work/dted --dry-run

    # Verbose output
    python create_dted_symlinks.py --dted-root /data/work/dted --verbose

Directory structure:
    The script expects DTED files organized by level:
        dted/0/e000/n05.dt0   (Level 0, ~900m)
        dted/1/e000/n05.dt1   (Level 1, ~90m)
        dted/2/e000/n05.dt2   (Level 2, ~30m)

    It creates:
        dted/best/e000/n05.dted -> ../../2/e000/n05.dt2
        """,
    )

    parser.add_argument(
        "--dted-root",
        type=Path,
        required=True,
        help="Root DTED directory containing 0/, 1/, 2/ subdirectories",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done without making changes",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose output",
    )

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Validate root directory
    if not args.dted_root.is_dir():
        logger.error("DTED root directory does not exist: %s", args.dted_root)
        return 1

    # Check that at least one level directory exists
    found_levels = [
        level for level in [0, 1, 2] if (args.dted_root / str(level)).is_dir()
    ]

    if not found_levels:
        logger.error(
            "No level directories (0/, 1/, 2/) found in %s",
            args.dted_root,
        )
        return 1

    # Run
    logger.info("=" * 60)
    logger.info("Creating DTED symlinks")
    logger.info("Root: %s", args.dted_root)
    logger.info("Found levels: %s", found_levels)
    if args.dry_run:
        logger.info("Mode: DRY RUN")
    logger.info("=" * 60)

    created, skipped, errors = create_symlinks(
        dted_root=args.dted_root,
        dry_run=args.dry_run,
    )

    logger.info("=" * 60)
    logger.info(
        "Complete: %d symlinks created, %d skipped, %d errors",
        created,
        skipped,
        errors,
    )

    return 0 if errors == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
