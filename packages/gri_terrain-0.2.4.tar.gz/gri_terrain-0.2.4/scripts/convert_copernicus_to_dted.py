#!/usr/bin/env python3
r"""Convert Copernicus DEM GLO-30 GeoTIFF files to DTED format.

This script converts Cloud Optimized GeoTIFF files from the Copernicus DEM
GLO-30 dataset (1 arc-second / ~30m) to standard DTED format. It produces
both DTED Level 1 and Level 2 from the same source data.

Conversion details:
    - GLO-30 (1 arc-second, 3600x3600 pixels) -> DTED Level 1 (3 arc-second, 1201x1201)
    - GLO-30 (1 arc-second, 3600x3600 pixels) -> DTED Level 2 (1 arc-second, 3601x3601)

The conversion requires bilinear interpolation because:
    - Copernicus uses pixel-centered (area) registration
    - DTED uses grid-registered (point) samples at exact degree boundaries
    - DTED tiles overlap by 1 sample at edges (hence 1201 and 3601, not 1200 and 3600)

To get edge samples, adjacent Copernicus tiles are loaded as needed.

Usage:
    # Convert GLO-30 to both DTED Level 1 and Level 2
    python convert_copernicus_to_dted.py --input-dir /data/work/glo30 \
        --output-dir /data/work/dted

    # Convert only DTED Level 1
    python convert_copernicus_to_dted.py --input-dir /data/work/glo30 \
        --output-dir /data/work/dted --level 1

Output structure:
    {output-dir}/1/{lon_dir}/{lat}.dt1  (e.g., dted/1/w106/n39.dt1)
    {output-dir}/2/{lon_dir}/{lat}.dt2  (e.g., dted/2/w106/n39.dt2)

After conversion, run create_dted_symlinks.py to update the 'best' directory.

Requirements:
    - rasterio
    - scipy (for interpolation)
"""

import argparse
import logging
import re
import sys
from pathlib import Path

import numpy as np
import rasterio
import rasterio.transform
from scipy.ndimage import map_coordinates

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# DTED grid sizes (samples per degree, including both edges)
DTED1_SIZE = 1201  # 3 arc-second spacing
DTED2_SIZE = 3601  # 1 arc-second spacing

# Copernicus GLO-30 pixel count per tile (no edge overlap)
GLO30_SIZE = 3600


def get_copernicus_filename(lat: int, lon: int, prefix: str = "10") -> str:
    """Generate Copernicus filename for a given lat/lon tile.

    Args:
        lat: Latitude of tile southwest corner (integer degrees).
        lon: Longitude of tile southwest corner (integer degrees).
        prefix: Resolution prefix ("10" for GLO-30, "30" for GLO-90).

    Returns:
        Filename like "Copernicus_DSM_COG_10_N39_00_W106_00_DEM.tif"
    """
    lat_hem = "N" if lat >= 0 else "S"
    lon_hem = "E" if lon >= 0 else "W"
    return (
        f"Copernicus_DSM_COG_{prefix}_{lat_hem}{abs(lat):02d}_00_"
        f"{lon_hem}{abs(lon):03d}_00_DEM.tif"
    )


def parse_copernicus_filename(filename: str) -> tuple[int, int] | None:
    """Parse latitude and longitude from a Copernicus DEM filename.

    Args:
        filename: The GeoTIFF filename.

    Returns:
        Tuple of (lat, lon) or None if parsing fails.
    """
    pattern = r"Copernicus_DSM_COG_\d+_([NS])(\d+)_00_([EW])(\d+)_00_DEM\.tif"
    match = re.match(pattern, filename)

    if not match:
        return None

    lat_hem, lat_val, lon_hem, lon_val = match.groups()

    lat = int(lat_val)
    if lat_hem == "S":
        lat = -lat

    lon = int(lon_val)
    if lon_hem == "W":
        lon = -lon

    return lat, lon


def get_dted_paths(
    lat: int,
    lon: int,
    output_dir: Path,
    levels: list[int],
) -> dict[int, Path]:
    """Generate DTED output paths for given lat/lon and levels.

    Args:
        lat: Latitude of tile southwest corner.
        lon: Longitude of tile southwest corner.
        output_dir: Base output directory.
        levels: List of DTED levels to generate paths for.

    Returns:
        Dict mapping level to output path.
    """
    lon_dir = f"e{abs(lon):03d}" if lon >= 0 else f"w{abs(lon):03d}"
    lat_name = f"n{abs(lat):02d}" if lat >= 0 else f"s{abs(lat):02d}"

    return {
        level: output_dir / str(level) / lon_dir / f"{lat_name}.dt{level}"
        for level in levels
    }


def load_tile(input_dir: Path, lat: int, lon: int) -> np.ndarray | None:
    """Load a Copernicus tile, returning None if it doesn't exist.

    Args:
        input_dir: Directory containing GeoTIFF files.
        lat: Latitude of tile.
        lon: Longitude of tile.

    Returns:
        2D numpy array of elevation data, or None if tile missing.
    """
    filename = get_copernicus_filename(lat, lon)
    filepath = input_dir / filename

    if not filepath.exists():
        return None

    with rasterio.open(filepath) as src:
        data = src.read(1)
        nodata = src.nodata
        if nodata is not None:
            data = np.where(data == nodata, np.nan, data)
        return data


def resample_row_to_size(row: np.ndarray, target_size: int) -> np.ndarray:
    """Resample a 1D array to a target size using linear interpolation.

    Used when neighbor tiles have different pixel counts (e.g., high latitude
    tiles with reduced longitude resolution).

    Args:
        row: Source 1D array.
        target_size: Desired output size.

    Returns:
        Resampled array of target_size.
    """
    if len(row) == target_size:
        return row

    # Linear interpolation: map target indices to source indices
    source_indices = np.linspace(0, len(row) - 1, target_size)
    return np.interp(source_indices, np.arange(len(row)), row)


def build_extended_tile(
    input_dir: Path,
    lat: int,
    lon: int,
) -> np.ndarray | None:
    """Build an extended tile with data from adjacent tiles for edge interpolation.

    Creates a (GLO30_SIZE + 1) x (GLO30_SIZE + 1) array by loading the primary
    tile and getting edge pixels from adjacent tiles (right, bottom, corner).

    Handles neighbor tiles with different pixel counts (e.g., high-latitude tiles
    with reduced longitude resolution) by resampling edge data.

    Args:
        input_dir: Directory containing GeoTIFF files.
        lat: Latitude of primary tile.
        lon: Longitude of primary tile.

    Returns:
        Extended array (3601x3601) or None if primary tile missing.
    """
    # Load primary tile
    primary = load_tile(input_dir, lat, lon)
    if primary is None:
        return None

    primary_rows, primary_cols = primary.shape

    # Create extended array matching primary tile size + 1
    extended = np.full((primary_rows + 1, primary_cols + 1), np.nan, dtype=np.float32)
    extended[:primary_rows, :primary_cols] = primary

    # Load right neighbor (lon + 1) for right edge column
    right = load_tile(input_dir, lat, lon + 1)
    if right is not None:
        # Right neighbor should have same row count, take first column
        if right.shape[0] == primary_rows:
            extended[:primary_rows, primary_cols] = right[:, 0]
        else:
            # Resample if row counts differ (shouldn't happen but be safe)
            extended[:primary_rows, primary_cols] = resample_row_to_size(
                right[:, 0],
                primary_rows,
            )

    # Load top neighbor (lat + 1) for top edge row
    # Note: In image coordinates, row 0 is north, last row is south
    # The top neighbor's last row (south edge) adjoins our first row (north edge)
    top = load_tile(input_dir, lat + 1, lon)
    if top is not None:
        # Get the bottom row of the top tile (its south edge = our north edge)
        top_bottom_row = top[-1, :]
        # Resample if column counts differ (common at high latitudes)
        extended[primary_rows, :primary_cols] = resample_row_to_size(
            top_bottom_row,
            primary_cols,
        )

    # Load top-right corner neighbor for corner pixel
    top_right = load_tile(input_dir, lat + 1, lon + 1)
    if top_right is not None:
        # Bottom-left pixel of top-right neighbor
        extended[primary_rows, primary_cols] = top_right[-1, 0]

    return extended


def interpolate_to_dted_grid(
    extended_data: np.ndarray,
    dted_size: int,
) -> np.ndarray:
    """Interpolate extended Copernicus data to DTED grid.

    Copernicus pixels are area-centered (pixel value represents an area).
    DTED samples are point values at exact grid coordinates.

    Both source and target cover the same 1x1 degree geographic extent.
    The extended_data array is (src_size+1) x (src_size+1) to allow
    interpolation at the edges.

    Args:
        extended_data: Extended tile data, size is (src_rows+1, src_cols+1).
        dted_size: Target DTED grid size (1201 for Level 1, 3601 for Level 2).

    Returns:
        Interpolated DTED grid (dted_size x dted_size).
    """
    # Source dimensions (the original tile size, not extended)
    src_rows = extended_data.shape[0] - 1
    src_cols = extended_data.shape[1] - 1

    # DTED sample points in normalized [0, 1] coordinates
    # Sample i is at i / (dted_size - 1), covering 0 to 1
    dted_row_coords = np.linspace(0, 1, dted_size)
    dted_col_coords = np.linspace(0, 1, dted_size)

    # Convert normalized DTED coordinates to source pixel indices
    # Source pixel i has center at (i + 0.5) / src_size in normalized coords
    # To find source index for normalized coord x: index = x * src_size - 0.5
    # The extended array shifts this by +0.5, so: ext_index = x * src_size
    row_indices = dted_row_coords * src_rows
    col_indices = dted_col_coords * src_cols

    # Create meshgrid for all sample points
    col_grid, row_grid = np.meshgrid(col_indices, row_indices)

    # Interpolate using map_coordinates (bilinear with order=1)
    coordinates = np.array([row_grid.ravel(), col_grid.ravel()])
    interpolated = map_coordinates(
        extended_data,
        coordinates,
        order=1,
        mode="constant",
        cval=np.nan,
    )

    return interpolated.reshape(dted_size, dted_size).astype(np.float32)


def write_dted(
    data: np.ndarray,
    output_path: Path,
    lat: int,
    lon: int,
) -> None:
    """Write elevation data to DTED format.

    Args:
        data: Elevation data array (1201x1201 or 3601x3601).
        output_path: Output file path.
        lat: Latitude of tile southwest corner.
        lon: Longitude of tile southwest corner.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)

    size = data.shape[0]

    # Convert to int16, handling NaN
    data_int16 = np.full(data.shape, -32767, dtype=np.int16)
    valid = ~np.isnan(data)
    data_int16[valid] = np.clip(np.round(data[valid]), -32766, 32767).astype(np.int16)

    # DTED transform: pixel size and origin
    # For grid-registered data, the transform maps pixel centers
    # Pixel (0,0) center should be at (lon, lat+1)
    pixel_size = 1.0 / (size - 1)

    transform = rasterio.transform.from_origin(
        west=lon,
        north=lat + 1,
        xsize=pixel_size,
        ysize=pixel_size,
    )

    # Create DTED file
    profile = {
        "driver": "DTED",
        "dtype": "int16",
        "nodata": -32767,
        "width": size,
        "height": size,
        "count": 1,
        "crs": "EPSG:4326",
        "transform": transform,
    }

    with rasterio.open(output_path, "w", **profile) as dst:
        dst.write(data_int16, 1)


def convert_tile(
    input_dir: Path,
    output_dir: Path,
    coords: tuple[int, int],
    levels: list[int],
    *,
    overwrite: bool = False,
) -> tuple[int, bool, str]:
    """Convert a single Copernicus tile to DTED format(s).

    Args:
        input_dir: Directory containing GeoTIFF files.
        output_dir: Base output directory for DTED files.
        coords: Tuple of (lat, lon) for the tile.
        levels: List of DTED levels to create (1, 2, or both).
        overwrite: Whether to overwrite existing files.

    Returns:
        Tuple of (level_count, success, message).
    """
    lat, lon = coords

    # Check which outputs need to be created
    output_paths = get_dted_paths(lat, lon, output_dir, levels)
    levels_to_create = []

    for level, path in output_paths.items():
        if path.exists() and not overwrite:
            continue
        levels_to_create.append(level)

    if not levels_to_create:
        return 0, True, "skipped (all exist)"

    # Build extended tile with edge data
    extended = build_extended_tile(input_dir, lat, lon)
    if extended is None:
        return 0, False, "primary tile not found"

    # Create each requested DTED level
    try:
        for level in levels_to_create:
            dted_size = DTED1_SIZE if level == 1 else DTED2_SIZE
            dted_data = interpolate_to_dted_grid(extended, dted_size)
            write_dted(dted_data, output_paths[level], lat, lon)

    except OSError as e:
        return 0, False, f"error: {e}"

    sizes = []
    for level in levels_to_create:
        size_kb = output_paths[level].stat().st_size / 1024
        sizes.append(f"L{level}:{size_kb:.0f}KB")

    return len(levels_to_create), True, f"converted ({', '.join(sizes)})"


def convert_directory(
    input_dir: Path,
    output_dir: Path,
    levels: list[int],
    *,
    overwrite: bool = False,
) -> tuple[int, int, int]:
    """Convert all GeoTIFF files in a directory to DTED.

    Args:
        input_dir: Directory containing Copernicus GeoTIFF files.
        output_dir: Base output directory for DTED files.
        levels: List of DTED levels to create.
        overwrite: Overwrite existing files.

    Returns:
        Tuple of (tiles_processed, total_files_created, failed_count).
    """
    # Find all GeoTIFF files and parse coordinates
    tif_files = sorted(input_dir.glob("*.tif"))
    logger.info("Found %d GeoTIFF files in %s", len(tif_files), input_dir)

    if not tif_files:
        return 0, 0, 0

    # Parse coordinates from filenames
    tiles = []
    for tif_path in tif_files:
        parsed = parse_copernicus_filename(tif_path.name)
        if parsed is None:
            logger.warning("Could not parse filename: %s", tif_path.name)
            continue
        tiles.append(parsed)

    logger.info("Processing %d tiles for DTED levels %s", len(tiles), levels)

    tiles_processed = 0
    files_created = 0
    failed = 0
    failed_tiles = []

    for i, (lat, lon) in enumerate(tiles, 1):
        count, success, message = convert_tile(
            input_dir=input_dir,
            output_dir=output_dir,
            coords=(lat, lon),
            levels=levels,
            overwrite=overwrite,
        )

        if success:
            tiles_processed += 1
            files_created += count
            if count > 0:
                logger.info(
                    "[%d/%d] N%02d E%03d: %s",
                    i,
                    len(tiles),
                    lat,
                    lon,
                    message,
                )
        else:
            failed += 1
            failed_tiles.append(f"{lat},{lon}: {message}")
            logger.error(
                "[%d/%d] N%02d E%03d: %s",
                i,
                len(tiles),
                lat,
                lon,
                message,
            )

        # Progress update every 500 tiles
        if i % 500 == 0:
            logger.info(
                "Progress: %d/%d tiles (%.1f%%)",
                i,
                len(tiles),
                100 * i / len(tiles),
            )

    if failed_tiles:
        failed_file = output_dir / "failed_conversions.txt"
        failed_file.write_text("\n".join(failed_tiles))
        logger.info("Failed tiles written to %s", failed_file)

    return tiles_processed, files_created, failed


def main() -> int:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Convert Copernicus GLO-30 GeoTIFFs to DTED format",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Convert GLO-30 to both DTED Level 1 and Level 2
    python convert_copernicus_to_dted.py \\
        --input-dir /data/work/glo30 \\
        --output-dir /data/work/dted

    # Convert only DTED Level 1
    python convert_copernicus_to_dted.py \\
        --input-dir /data/work/glo30 \\
        --output-dir /data/work/dted \\
        --level 1

Notes:
    - Source must be GLO-30 data (1 arc-second resolution)
    - Creates DTED Level 1 (3 arc-second) and/or Level 2 (1 arc-second)
    - Uses bilinear interpolation to convert from pixel-centered to grid-registered
    - Output: {output-dir}/{level}/{lon}/{lat}.dt{level}
    - After conversion, run create_dted_symlinks.py to update the 'best' directory
        """,
    )

    parser.add_argument(
        "--input-dir",
        type=Path,
        required=True,
        help="Directory containing Copernicus GLO-30 GeoTIFF files",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        required=True,
        help="Output directory for DTED files",
    )
    parser.add_argument(
        "--level",
        type=int,
        choices=[1, 2],
        action="append",
        dest="levels",
        help="DTED level(s) to create (default: both 1 and 2). Can be repeated.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing DTED files",
    )

    args = parser.parse_args()

    # Default to both levels if none specified
    levels = args.levels if args.levels else [1, 2]
    levels = sorted(set(levels))  # Remove duplicates and sort

    # Validate input directory
    if not args.input_dir.is_dir():
        logger.error("Input directory does not exist: %s", args.input_dir)
        return 1

    # Run conversion
    logger.info("=" * 60)
    logger.info("Converting Copernicus GLO-30 to DTED Level %s", levels)
    logger.info("Input: %s", args.input_dir)
    logger.info("Output: %s", args.output_dir)
    logger.info("=" * 60)

    tiles_processed, files_created, failed = convert_directory(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        levels=levels,
        overwrite=args.overwrite,
    )

    logger.info("=" * 60)
    logger.info(
        "Conversion complete: %d tiles processed, %d files created, %d failed",
        tiles_processed,
        files_created,
        failed,
    )

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
