"""Tests for TerrainSource base class behavior.

Uses DTEDSource as the concrete implementation for the realistic tests and a
tiny in-memory subclass for multi-tile eviction tests, since the fixture only
provides one real DTED tile.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from gri_terrain.sources.dted import DTEDSource
from gri_terrain.sources.terrain import TerrainSource
from gri_terrain.sources.tile_data import TileData

TEST_DATA_DIR = Path(__file__).parent.parent / "data" / "dted"


class SyntheticSource(TerrainSource):
    """Terrain source that fabricates flat tiles on demand.

    Used to exercise cache/eviction logic without relying on large real-world
    fixtures: we can generate as many distinct tiles as the test needs.
    """

    def __init__(self, tile_shape: tuple[int, int] = (64, 64)) -> None:
        """Initialize with a default small tile shape."""
        super().__init__()
        self._tile_shape = tile_shape
        self.load_count = 0

    @property
    def name(self) -> str:
        """Return source name."""
        return "Synthetic"

    def _load_tile(self, lat_tile: int, lon_tile: int) -> TileData | None:
        """Fabricate a flat tile at altitude = lat_tile * 100 + lon_tile."""
        self.load_count += 1
        data = np.full(self._tile_shape, float(lat_tile * 100 + lon_tile))
        return TileData(
            data=data,
            resolution_deg=1.0 / self._tile_shape[0],
            lats=[lat_tile],
            lons=[lon_tile],
        )


@pytest.fixture
def dted_source() -> DTEDSource:
    """DTEDSource pointing at the Colorado test tile."""
    return DTEDSource(TEST_DATA_DIR)


def test_precache_region_loads_covering_tiles(dted_source: DTEDSource) -> None:
    """precache_region returns the number of real tiles loaded."""
    # Colorado bbox that overlaps the single N39 W105 test tile.
    loaded = dted_source.precache_region(
        lat_min=39.1,
        lat_max=39.9,
        lon_min=-104.9,
        lon_max=-104.1,
    )
    assert loaded == 1

    # Subsequent lookup should hit the warm cache (same coordinate key).
    alt = dted_source.get_altitude(np.array([39.5]), np.array([-104.5]))
    assert not np.isnan(alt[0])


def test_precache_region_excludes_uncovered_tiles(dted_source: DTEDSource) -> None:
    """Tiles outside the source's coverage are not counted as loaded."""
    # Region covers one good tile and one with no DTED data (N40 W106).
    loaded = dted_source.precache_region(
        lat_min=39.5,
        lat_max=40.5,
        lon_min=-105.5,
        lon_max=-104.5,
    )
    # Only the N39 W105 tile has data in the fixture set.
    assert loaded == 1


def test_precache_region_raises_when_region_exceeds_cache_limit(
    dted_source: DTEDSource,
) -> None:
    """Oversized regions raise MemoryError before loading everything."""
    # Shrink the memory cache so a single tile already exceeds the budget.
    dted_source._max_cache_bytes = 1

    with pytest.raises(MemoryError, match="cache"):
        dted_source.precache_region(
            lat_min=39.0,
            lat_max=39.9,
            lon_min=-104.9,
            lon_max=-104.1,
        )


def test_clear_tile_removes_loaded_tile(dted_source: DTEDSource) -> None:
    """clear_tile drops a loaded tile from the cache and updates byte count."""
    # Load the tile into memory.
    dted_source.get_altitude(np.array([39.5]), np.array([-104.5]))
    assert (39, -105) in dted_source._tile_cache
    bytes_before = dted_source._cache_bytes
    assert bytes_before > 0

    dted_source.clear_tile(39, -105)

    assert (39, -105) not in dted_source._tile_cache
    assert dted_source._cache_bytes == 0


def test_clear_tile_removes_cached_miss(dted_source: DTEDSource) -> None:
    """clear_tile for an uncovered tile removes the cached None without error."""
    # Probing an uncovered region causes a None ("miss") to be cached.
    # floor(-106.5) == -107, so the key is (40, -107).
    dted_source.get_altitude(np.array([40.5]), np.array([-106.5]))
    assert (40, -107) in dted_source._tile_cache
    assert dted_source._tile_cache[(40, -107)] is None

    dted_source.clear_tile(40, -107)

    assert (40, -107) not in dted_source._tile_cache


def test_memory_cache_evicts_oldest_when_full() -> None:
    """Adding a third tile to a two-tile-limit cache evicts the oldest."""
    source = SyntheticSource(tile_shape=(32, 32))
    # Sized for exactly two tiles.
    bytes_per_tile = np.zeros((32, 32), dtype=np.float64).nbytes
    source._max_cache_bytes = 2 * bytes_per_tile

    # Load three distinct tiles in order; the first should be evicted.
    source.get_altitude(np.array([10.5]), np.array([20.5]))  # (10, 20)
    source.get_altitude(np.array([30.5]), np.array([40.5]))  # (30, 40)
    source.get_altitude(np.array([50.5]), np.array([60.5]))  # (50, 60)

    cache_keys = set(source._tile_cache)
    assert (10, 20) not in cache_keys, "oldest tile should have been evicted"
    assert (30, 40) in cache_keys
    assert (50, 60) in cache_keys
    assert source._cache_bytes == 2 * bytes_per_tile


def test_memory_cache_evicts_past_miss_entries() -> None:
    """Eviction skips cached None entries to find real tiles to evict."""
    source = SyntheticSource(tile_shape=(32, 32))
    bytes_per_tile = np.zeros((32, 32), dtype=np.float64).nbytes

    # Load a real tile.
    source.get_altitude(np.array([10.5]), np.array([20.5]))
    # Manually insert a stale miss entry before the tile in insertion order
    # by rebuilding the cache to put the None first.
    real_entry = source._tile_cache[(10, 20)]
    source._tile_cache.clear()
    source._tile_cache[(0, 0)] = None  # miss, first
    source._tile_cache[(10, 20)] = real_entry  # real tile, second

    # Shrink to force eviction; the loop must walk past the None to find bytes.
    source._max_cache_bytes = 1
    source.get_altitude(np.array([50.5]), np.array([60.5]))

    # The real tile and the miss are both gone; only the newly loaded tile remains.
    assert (10, 20) not in source._tile_cache
    assert (0, 0) not in source._tile_cache
    assert source._cache_bytes == bytes_per_tile


def test_unlimited_cache_never_evicts() -> None:
    """max_memory_cache_mb = 0 disables eviction entirely."""
    source = SyntheticSource(tile_shape=(16, 16))
    source._max_cache_bytes = 0  # unlimited

    for i in range(5):
        source.get_altitude(np.array([float(i) + 0.5]), np.array([float(i) + 0.5]))

    # All five loaded tiles remain.
    assert len({k for k, v in source._tile_cache.items() if v is not None}) == 5
