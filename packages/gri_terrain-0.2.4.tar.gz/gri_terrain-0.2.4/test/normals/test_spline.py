"""Tests for spline-based grid surface normals."""

from __future__ import annotations

import numpy as np
import pytest
from gri_utils.constants import WGS84, GeoEllipsoid

from gri_terrain import grid_normals_spline


def test_output_shape() -> None:
    """Result has shape (nlat, nlon, 3)."""
    lats = np.linspace(40.0, 40.1, 10)
    lons = np.linspace(-105.0, -104.9, 12)
    alt = np.zeros((10, 12))
    n = grid_normals_spline(lats, lons, alt)
    assert n.shape == (10, 12, 3)


def test_normals_are_unit_vectors() -> None:
    """Every normal has magnitude ~1."""
    lats = np.linspace(40.0, 40.1, 8)
    lons = np.linspace(-105.0, -104.9, 8)
    rng = np.random.default_rng(0)
    alt = rng.normal(1000.0, 50.0, (8, 8))
    n = grid_normals_spline(lats, lons, alt)
    magnitudes = np.linalg.norm(n, axis=-1)
    assert np.allclose(magnitudes, 1.0, atol=1e-10)


def test_flat_terrain_normals_point_radially_out() -> None:
    """On flat ground, ECEF normal at each point = local up (radial unit)."""
    lats = np.linspace(40.0, 40.1, 6)
    lons = np.linspace(-105.0, -104.9, 6)
    alt = np.full((6, 6), 1500.0)
    n = grid_normals_spline(lats, lons, alt)

    # Geodetic up in ECEF at (lat, lon):
    #   (cos(lat)*cos(lon), cos(lat)*sin(lon), sin(lat))
    for i, lat in enumerate(lats):
        for j, lon in enumerate(lons):
            lat_r = np.radians(lat)
            lon_r = np.radians(lon)
            expected = np.array(
                [
                    np.cos(lat_r) * np.cos(lon_r),
                    np.cos(lat_r) * np.sin(lon_r),
                    np.sin(lat_r),
                ],
            )
            assert n[i, j] == pytest.approx(expected, abs=1e-6)


def test_uniform_east_slope_tilts_normal_west() -> None:
    """Surface rising to the east tilts the ENU-space normal toward -east.

    Straddling the equator and prime meridian, local east aligns with ECEF +y,
    so the ECEF y-component of a west-tilted normal should be negative.
    """
    lats = np.linspace(-0.01, 0.01, 7)
    lons = np.linspace(-0.01, 0.01, 7)
    lon_grid, _ = np.meshgrid(lons, lats)
    alt = 1000.0 + 5000.0 * lon_grid

    n = grid_normals_spline(lats, lons, alt)

    # dz/deast = (5000 m/deg) / (N * cos(0) * pi/180)
    # At lat=0, N = a, so m_per_deg_east ~ 6378137 * pi/180 ~ 111320 m/deg
    # slope ~ 5000 / 111320 ~ 0.0449
    center = n[3, 3]
    assert center[1] < 0.0
    expected_slope = 5000.0 / (WGS84.a * np.pi / 180.0)
    # Normalized, small-slope approximation: nE ~ -slope / sqrt(1+slope^2)
    expected_ny = -expected_slope / np.sqrt(1 + expected_slope**2)
    assert center[1] == pytest.approx(expected_ny, rel=1e-3)


def test_high_latitude_east_slope_uses_per_point_cos_lat() -> None:
    """At 60 N, cos(lat) ~ 0.5 so a given dh/dlon yields ~2x the slope at equator.

    This is the key fix over a single-ref_lat model: scaling is per-point.
    """
    lats_high = np.linspace(59.99, 60.01, 5)
    lons = np.linspace(-0.01, 0.01, 5)
    # Build the same elevation grid (same dh/dlon in deg) at high lat:
    lon_grid, _ = np.meshgrid(lons, lats_high)
    alt = 1000.0 + 5000.0 * lon_grid

    n = grid_normals_spline(lats_high, lons, alt)
    center = n[2, 2]

    # At lat=60, meters per degree east = N(60)*cos(60)*pi/180
    lat_rad = np.radians(60.0)
    m_per_deg_east = WGS84.n(lat_rad) * np.cos(lat_rad) * np.pi / 180.0
    expected_slope = 5000.0 / m_per_deg_east  # ~0.0896, about twice the equator value

    # Project the ECEF normal onto the local east unit vector at (lat=60, lon=0):
    # east = (-sin(lon), cos(lon), 0) = (0, 1, 0) at lon=0.
    east_component = center[1]
    expected_east = -expected_slope / np.sqrt(1 + expected_slope**2)
    assert east_component == pytest.approx(expected_east, rel=1e-3)


def test_custom_ellipsoid_parameter_is_used() -> None:
    """Passing a different GeoEllipsoid changes the normals as predicted.

    A spherical ellipsoid (a=b) has N(lat)=M(lat)=a, so slopes differ from WGS84
    only by the ~0.5-1% M/N variation. Instead, a 2x-larger radius halves all
    arc-length-per-degree factors, doubling the slope and visibly changing the
    normal tilt.
    """
    lats = np.linspace(-0.01, 0.01, 5)
    lons = np.linspace(-0.01, 0.01, 5)
    lon_grid, _ = np.meshgrid(lons, lats)
    alt = 5000.0 * lon_grid  # pure east slope

    big = GeoEllipsoid(a=2 * WGS84.a, b=2 * WGS84.b)
    n_wgs = grid_normals_spline(lats, lons, alt)
    n_big = grid_normals_spline(lats, lons, alt, ellipsoid=big)

    # Bigger ellipsoid -> larger meters per degree -> smaller slope -> smaller tilt.
    # At center, the absolute east component of the normal should be smaller.
    assert abs(n_big[2, 2, 1]) < abs(n_wgs[2, 2, 1])
