"""Tests for ray-terrain intersection algorithm."""

from __future__ import annotations

import numpy as np
import pytest
from gri_utils.constants import ER_M
from gri_utils.conversion import lla_to_xyz, xyz_to_lla

from gri_terrain.intersect.ray import ray_terrain
from gri_terrain.sources import TerrainSource


class MockTerrain(TerrainSource):
    """Mock terrain source returning flat elevation."""

    def __init__(self, elevation_m: float = 0.0):
        """Initialize mock with constant elevation."""
        super().__init__()
        self._elevation_m = elevation_m

    @property
    def name(self) -> str:
        """Return source name."""
        return "MockTerrain"

    def _load_tile(
        self,
        lat_tile: int,
        lon_tile: int,
    ) -> None:
        """Not used - overrides get_altitude directly."""
        del lat_tile, lon_tile  # Unused

    def get_altitude(
        self,
        lat: np.ndarray,
        lon: np.ndarray,
        *,
        interpolation: str = "bicubic",
    ) -> np.ndarray:
        """Return constant elevation for all coordinates."""
        del lon, interpolation  # Unused
        lat = np.atleast_1d(np.asarray(lat, dtype=np.float64))
        return np.full_like(lat, self._elevation_m)


@pytest.mark.parametrize(
    ("start_alt_m", "terrain_alt_m", "expected_hit"),
    [
        (1000.0, 100.0, True),  # Above terrain, descending should hit
        (500.0, 1000.0, False),  # Below terrain, descending - no crossing
        (50000.0, 0.0, True),  # High altitude with fast descent
    ],
)
def test_vertical_ray_descending(start_alt_m, terrain_alt_m, expected_hit):
    """Vertical downward rays hit terrain only when crossing from above."""
    terrain = MockTerrain(elevation_m=terrain_alt_m)
    start_lla = np.array([45.0, 0.0, start_alt_m])
    origin = lla_to_xyz(start_lla)
    direction = -origin / np.linalg.norm(origin)  # Toward Earth center

    hit = ray_terrain(terrain, origin, direction)

    if expected_hit:
        assert hit is not None
        hit_lla = xyz_to_lla(hit)
        assert abs(hit_lla[0] - 45.0) < 0.1
        assert abs(hit_lla[1] - 0.0) < 0.1
    else:
        assert hit is None


def test_horizontal_ray_above_ceiling_misses():
    """Horizontal ray above terrain ceiling should miss (exits band ascending)."""
    terrain = MockTerrain(elevation_m=0.0)
    origin = lla_to_xyz(np.array([45.0, 0.0, 20000.0]))  # Above 9000m ceiling
    # Tangent direction (east)
    direction = np.array([-origin[1], origin[0], 0.0])
    direction = direction / np.linalg.norm(direction)

    hit = ray_terrain(terrain, origin, direction)

    # Should return None because we start above ceiling and aren't descending
    assert hit is None


def test_zero_direction_returns_none():
    """Zero direction vector should return None."""
    terrain = MockTerrain()
    origin = np.array([6378137.0, 0.0, 0.0])

    hit = ray_terrain(terrain, origin, np.array([0.0, 0.0, 0.0]))

    assert hit is None


def test_ascending_from_below_terrain():
    """Ray starting below terrain and ascending should hit surface."""
    terrain = MockTerrain(elevation_m=100.0)
    # Start at 45N, 0E, -200m (below terrain)
    start_lla = np.array([45.0, 0.0, -200.0])
    origin = lla_to_xyz(start_lla)
    direction = origin / np.linalg.norm(origin)  # Away from Earth center

    hit = ray_terrain(terrain, origin, direction)

    assert hit is not None
    hit_lla = xyz_to_lla(hit)
    assert abs(hit_lla[0] - 45.0) < 0.1
    assert abs(hit_lla[1] - 0.0) < 0.1
    assert abs(hit_lla[2] - 100.0) < 10.0  # Should hit near terrain level


def test_ray_from_deep_underground_to_equator():
    """Ray from deep underground toward equator hits at equatorial radius."""
    terrain = MockTerrain(elevation_m=0.0)
    # Start 1000km below equatorial surface, heading outward
    start_lla = np.array([0.0, 0.0, -1000000.0])  # 0N, 0E, -1000km altitude
    origin = lla_to_xyz(start_lla)
    direction = origin / np.linalg.norm(origin)  # Radially outward

    hit = ray_terrain(terrain, origin, direction)

    assert hit is not None
    hit_radius = np.linalg.norm(hit)
    assert abs(hit_radius - ER_M) < 100.0  # Within 100m of equatorial radius


def test_ray_from_deep_underground_to_high_latitude():
    """Ray from deep underground at high latitude hits near surface."""
    terrain = MockTerrain(elevation_m=0.0)
    # Start 1000km below surface at 85N, heading outward
    start_lla = np.array([85.0, 0.0, -1000000.0])
    origin = lla_to_xyz(start_lla)
    direction = origin / np.linalg.norm(origin)  # Radially outward

    hit = ray_terrain(terrain, origin, direction)

    assert hit is not None
    hit_lla = xyz_to_lla(hit)
    assert abs(hit_lla[0] - 85.0) < 0.1
    assert abs(hit_lla[2]) < 10.0  # Near terrain (0m)


def test_ray_from_high_satellite_to_equator():
    """Ray from geostationary orbit toward Earth center hits equatorial surface."""
    terrain = MockTerrain(elevation_m=0.0)
    geo_altitude = 35786000.0  # Geostationary altitude in meters
    start_lla = np.array([0.0, 0.0, geo_altitude])  # 0N, 0E, geostationary
    origin = lla_to_xyz(start_lla)
    direction = -origin / np.linalg.norm(origin)  # Toward Earth center

    hit = ray_terrain(terrain, origin, direction)

    assert hit is not None
    hit_radius = np.linalg.norm(hit)
    assert abs(hit_radius - ER_M) < 100.0


def test_ray_from_high_satellite_to_high_latitude():
    """Ray from high orbit at high latitude hits near surface."""
    terrain = MockTerrain(elevation_m=0.0)
    high_altitude = 10000000.0  # 10,000 km altitude
    start_lla = np.array([85.0, 0.0, high_altitude])
    origin = lla_to_xyz(start_lla)
    direction = -origin / np.linalg.norm(origin)  # Toward Earth center

    hit = ray_terrain(terrain, origin, direction)

    assert hit is not None
    hit_lla = xyz_to_lla(hit)
    assert abs(hit_lla[0] - 85.0) < 0.1
    assert abs(hit_lla[2]) < 1000.0  # Near terrain (within step_m)


def test_ray_descending_over_real_dted_tile():
    """Downward ray over Colorado exercises the tile-skip/exit branch.

    MockTerrain returns None from _load_tile, so the existing tests never
    enter the tile-skip path in _march. Using a real DTEDSource forces
    get_tile_at to return a TileData with an alt_max, which activates the
    tile-exit distance calculation.
    """
    from pathlib import Path  # noqa: PLC0415 - scoped

    from gri_terrain.sources.dted import DTEDSource  # noqa: PLC0415 - scoped

    dted = DTEDSource(Path(__file__).parent.parent / "data" / "dted")

    # Start 8 km above Denver, aim straight down.
    start_lla = np.array([39.7, -104.9, 8000.0])
    origin = lla_to_xyz(start_lla)
    direction = -origin / np.linalg.norm(origin)

    hit = ray_terrain(dted, origin, direction)

    assert hit is not None
    hit_lla = xyz_to_lla(hit)
    # Should land near Denver; elevation near the DTED-reported ground value.
    assert abs(hit_lla[0] - 39.7) < 0.1
    assert abs(hit_lla[1] - (-104.9)) < 0.1
    assert 1000 < hit_lla[2] < 2500  # Colorado ground elevation
