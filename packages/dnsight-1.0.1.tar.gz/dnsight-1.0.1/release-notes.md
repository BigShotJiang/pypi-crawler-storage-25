# v1.0.1 — 09 Apr 2026

## 📖 Documentation

- Update README to enhance badge visibility and add discussions section (#20) ([ab72e7c](https://github.com/dnsight/dnsight/commit/ab72e7cb7999f0f55b68e0cf873408ebb8ca3e1c)) ([#20](https://github.com/dnsight/dnsight/pull/20))
