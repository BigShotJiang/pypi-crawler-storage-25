from __future__ import annotations

import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path


PACKAGE_SRC = Path(__file__).resolve().parents[1] / "src"
if str(PACKAGE_SRC) not in sys.path:
    sys.path.insert(0, str(PACKAGE_SRC))

import myexp  # noqa: E402


class ProtocolTests(unittest.TestCase):
    def test_public_version_and_preferred_names_are_exported(self) -> None:
        self.assertEqual("0.2.0", myexp.__version__)
        self.assertTrue(hasattr(myexp, "params"))
        self.assertTrue(hasattr(myexp, "emit"))
        self.assertTrue(hasattr(myexp, "ExperimentTemplate"))
        self.assertTrue(hasattr(myexp, "run_experiment"))

    def test_runtime_json_parameters_override_local_defaults(self) -> None:
        argv = ["demo.scp.py", '{"seed": 2, "model": "runtime"}']

        self.assertTrue(myexp.is_exp_env(argv))
        self.assertEqual({"seed": 2, "model": "runtime"}, myexp.params({"seed": 1, "model": "local"}, argv))
        self.assertEqual({"seed": 1}, myexp.params({"seed": 1}, ["demo.scp.py"]))

    def test_runtime_parameter_diagnostics_reject_bad_json_and_shapes(self) -> None:
        with self.assertRaises(myexp.ParameterError) as non_json:
            myexp.params({"seed": 1}, ["demo.scp.py", "not-json"])
        self.assertIn("Runtime parameter argument must be a JSON object string", str(non_json.exception))

        with self.assertRaises(myexp.ParameterError) as invalid_json:
            myexp.params({"seed": 1}, ["demo.scp.py", "{bad"])
        self.assertIn("phase=parameter-loading", str(invalid_json.exception))
        self.assertIn("source=argv[1]", str(invalid_json.exception))

        with self.assertRaises(myexp.ParameterError) as invalid_shape:
            myexp.params({"seed": 1}, ["demo.scp.py", "[1, 2]"])
        self.assertIn("Runtime parameters must be a JSON object", str(invalid_shape.exception))

    def test_sidecar_result_takes_precedence_over_stdout_marker(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            result_path = Path(tmp) / "result.json"
            stdout = io.StringIO()
            with redirect_stdout(stdout):
                payload = myexp.emit({"metric": 7}, sidecar_path=result_path)

            self.assertEqual({"metric": 7}, json.loads(result_path.read_text(encoding="utf-8")))
            self.assertEqual("", stdout.getvalue())
            self.assertEqual(str(result_path), payload["sidecar_path"])
            self.assertFalse(payload["stdout_marker"])

    def test_stdout_marker_is_fallback_when_no_sidecar_exists(self) -> None:
        stdout = io.StringIO()
        with redirect_stdout(stdout):
            payload = myexp.emit({"metric": 3})

        text = stdout.getvalue()
        self.assertIn(myexp.RESULT_JSON_START, text)
        self.assertIn('"metric": 3', text)
        self.assertIn(myexp.RESULT_JSON_END, text)
        self.assertTrue(payload["stdout_marker"])

    def test_yaml_merge_hierarchy_options_and_pid_selection(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "bgConfig.yaml").write_text(
                """
model:
  name: base
option:
  $: ?model.name
  runtime:
    selected: true
  default:
    selected: false
metric: 1
choice: ?param.kind
choiceOption:
  $: ?choice
  runtime:
    nestedSelector: true
  default:
    nestedSelector: false
""".strip(),
                encoding="utf-8",
            )
            (root / "task.config.yaml").write_text("metric: 2\n---\nmetric: 5\n", encoding="utf-8")

            config = myexp.load_config(
                root / "bgConfig.yaml",
                root / "task.config.yaml",
                active_dynamic_yaml_id=1,
                params={"model__name": "runtime", "extra__value": 9, "param__kind": "runtime"},
                parse_options=True,
            )

            self.assertEqual(5, config["metric"])
            self.assertEqual("runtime", config["model"]["name"])
            self.assertEqual({"selected": True}, config["option"])
            self.assertEqual({"nestedSelector": True}, config["choiceOption"])
            self.assertEqual(9, config["extra"]["value"])

    def test_config_diagnostics_cover_missing_files_and_ambiguous_options(self) -> None:
        with self.assertRaises(myexp.ConfigError) as missing:
            myexp.load_config("missing-bg.yaml", "missing-task.yaml")
        self.assertIn("phase=config-load", str(missing.exception))

        with self.assertRaises(myexp.ConfigError) as ambiguous:
            myexp.parse_config_options_and_refs({"choice": "abc", "option": {"$": "?choice", "a.*": 1, ".*c": 2}})
        self.assertIn("matched multiple regex keys", str(ambiguous.exception))

        with self.assertRaises(myexp.ConfigError) as selector_cycle:
            myexp.parse_config_options_and_refs({"choice": "?choice", "option": {"$": "?choice", "runtime": 1}})
        self.assertIn("Option selector reference cycle", str(selector_cycle.exception))

        with self.assertRaises(myexp.ConfigError) as missing_selector:
            myexp.parse_config_options_and_refs({"option": {"$": "?missing.path", "default": 1}})
        self.assertIn("Reference path missing.path could not be resolved", str(missing_selector.exception))
        self.assertIn("path=option", str(missing_selector.exception))

    def test_conf_parse_does_not_mutate_input_config(self) -> None:
        config = {"model": {"name": "base"}, "metric": 1}

        parsed, ok, message = myexp.confParse(config, {"model__depth": 3})

        self.assertTrue(ok, message)
        self.assertEqual({"model": {"name": "base"}, "metric": 1}, config)
        self.assertEqual({"name": "base", "depth": 3}, parsed["model"])

    def test_parse_func_params_filters_unknown_arguments(self) -> None:
        def target(alpha, beta=2):
            return alpha + beta

        self.assertEqual({"alpha": 1}, myexp.filter_kwargs(target, {"alpha": 1, "gamma": 3}))

    def test_filter_kwargs_passes_all_arguments_to_var_keyword_targets(self) -> None:
        def only_kwargs(**kwargs):
            return kwargs

        def mixed(alpha, **kwargs):
            return alpha, kwargs

        args = {"alpha": 1, "gamma": 3}
        self.assertEqual(args, myexp.filter_kwargs(only_kwargs, args))
        self.assertEqual(args, myexp.filter_kwargs(mixed, args))

    def test_function_runner_emits_structured_skipped_result(self) -> None:
        stdout = io.StringIO()
        with redirect_stdout(stdout):
            result = myexp.run_experiment(
                lambda param: {"metric": param["metric"]},
                local_defaults={"metric": 1},
                should_run=lambda param: False,
            )
        self.assertEqual({"status": "skipped", "result": {}}, result)
        self.assertIn('"status": "skipped"', stdout.getvalue())

    def test_lifecycle_template_supports_new_hooks_and_yaml_config(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "bgConfig.yaml").write_text("metric: 1\n", encoding="utf-8")
            (root / "demo.config.yaml").write_text("metric: 2\n", encoding="utf-8")

            class DemoExperiment(myexp.ExperimentTemplate):
                def normalize_params(self, param: dict) -> dict:
                    param = dict(param)
                    param["metric"] = int(param["metric"]) + 1
                    return param

                def execute(self, config: dict) -> dict:
                    return {"metric": config["metric"]}

            result = DemoExperiment(
                workSpaceDir=root,
                taskConfigName="demo.config.yaml",
                local_defaults={"pid": 0, "metric": 4},
                isShowConfig=False,
            ).run()
            self.assertEqual({"metric": 5}, result)

    def test_compatibility_names_remain_supported(self) -> None:
        self.assertEqual({"seed": 2}, myexp.getParams({"seed": 2}))
        self.assertEqual("BCRCMain.config.yaml", myexp.getYamlConfName("BCRCMain.scp.py"))
        self.assertEqual({"alpha": 1}, myexp.parseFuncParams(lambda alpha: alpha, {"alpha": 1, "beta": 2}))

    def test_fixture_runs_local_and_injected_modes(self) -> None:
        fixture = Path(__file__).resolve().parent / "fixtures" / "minimal_exp.scp.py"
        env = dict(os.environ)
        env["PYTHONPATH"] = str(PACKAGE_SRC)
        local = subprocess.run([sys.executable, str(fixture)], env=env, text=True, capture_output=True, check=True)
        self.assertIn('"metric": 4', local.stdout)

        with tempfile.TemporaryDirectory() as tmp:
            result_path = Path(tmp) / "result.json"
            injected_env = dict(env)
            injected_env[myexp.RESULT_SIDECAR_ENV] = str(result_path)
            subprocess.run(
                [sys.executable, str(fixture), '{"pid": 0, "metric": 7}'],
                env=injected_env,
                text=True,
                capture_output=True,
                check=True,
            )
            self.assertEqual(8, json.loads(result_path.read_text(encoding="utf-8"))["metric"])
            self.assertEqual({"pid": 0, "metric": 7}, json.loads(result_path.read_text(encoding="utf-8"))["params"])


if __name__ == "__main__":
    unittest.main()
