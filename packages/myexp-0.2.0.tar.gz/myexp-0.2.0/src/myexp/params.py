from __future__ import annotations

import copy
import json
import os
import sys
from collections.abc import Mapping, Sequence
from typing import Any

from .errors import ParameterError

_RUNTIME_SIDECAR_ENV = "RESEARCH_LAB_RESULT_JSON"


def _argv(argv: Sequence[str] | None = None) -> Sequence[str]:
    return sys.argv if argv is None else argv


def _expects_runtime_json(argv: Sequence[str] | None) -> bool:
    return argv is not None or bool(os.environ.get(_RUNTIME_SIDECAR_ENV))


def _invalid_runtime_parameter(message: str) -> ParameterError:
    return ParameterError(
        message,
        phase="parameter-loading",
        path="$",
        source="argv[1]",
        guidance="Pass a JSON object as the first script argument, or run with no argument for local defaults.",
    )


def runtime_params(argv: Sequence[str] | None = None) -> dict[str, Any] | None:
    """Return runtime-injected JSON parameters, or None outside runtime execution."""

    values = _argv(argv)
    if len(values) < 2:
        return None
    raw_value = values[1]
    expects_json = _expects_runtime_json(argv)
    if not isinstance(raw_value, str):
        if expects_json:
            raise _invalid_runtime_parameter("Runtime parameter input must be a JSON string.")
        return None
    stripped = raw_value.lstrip()
    if not stripped:
        if expects_json:
            raise _invalid_runtime_parameter("Runtime parameter JSON argument must not be empty.")
        return None
    if stripped[0] not in "{[":
        if expects_json:
            raise _invalid_runtime_parameter("Runtime parameter argument must be a JSON object string.")
        return None
    try:
        parsed = json.loads(raw_value)
    except json.JSONDecodeError as exc:
        raise ParameterError(
            f"Invalid runtime parameter JSON: {exc.msg}",
            phase="parameter-loading",
            path="$",
            source="argv[1]",
            guidance="Pass a JSON object as the first script argument, or run with no argument for local defaults.",
        ) from exc
    except TypeError as exc:
        raise ParameterError(
            "Runtime parameter input must be a JSON string.",
            phase="parameter-loading",
            path="$",
            source="argv[1]",
            guidance="Pass a serialized JSON object as the first script argument.",
        ) from exc
    if not isinstance(parsed, dict):
        raise ParameterError(
            "Runtime parameters must be a JSON object.",
            phase="parameter-loading",
            path="$",
            source="argv[1]",
            guidance="Use an object such as {\"pid\": 0, \"metric\": 7}; arrays and scalars are not valid case parameters.",
        )
    return dict(parsed)


def in_runtime(argv: Sequence[str] | None = None) -> bool:
    """True when the first command-line argument is a valid runtime parameter object."""

    return runtime_params(argv) is not None


def params(
    local_defaults: Mapping[str, Any] | None = None,
    argv: Sequence[str] | None = None,
) -> dict[str, Any]:
    """Load experiment parameters with runtime JSON taking precedence over local defaults."""

    injected = runtime_params(argv)
    if injected is not None:
        return copy.deepcopy(injected)
    return copy.deepcopy(dict(local_defaults or {}))


def is_exp_env(argv: Sequence[str] | None = None) -> bool:
    return in_runtime(argv)


def get_params(
    defaults: Mapping[str, Any] | None = None,
    argv: Sequence[str] | None = None,
) -> dict[str, Any]:
    return params(defaults, argv)
