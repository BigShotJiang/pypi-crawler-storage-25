from __future__ import annotations

import copy
import os
from collections.abc import Callable, Mapping, MutableMapping, Sequence
from typing import Any

from .config import (
    config_name,
    deep_merge,
    filter_kwargs,
    load_config,
    load_config_simple,
    load_setting_from_yaml,
    nest_params,
    parse_config_options_and_refs,
    parse_config_refs,
    remove_none,
    unpack_params,
)
from .errors import MyExpError
from .lifecycle import ExperimentTemplate
from .params import get_params, in_runtime, is_exp_env, params
from .results import emit, emit_result


ExpTemplate = ExperimentTemplate


def isExpEnv() -> bool:
    return in_runtime()


def getParams(defaults: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return params(defaults)


def printResult(obj: Any) -> dict[str, Any]:
    return emit(obj)


def parseFuncParams(func: Callable[..., Any], args: Mapping[str, Any] | None) -> dict[str, Any]:
    return filter_kwargs(func, args)


def unpackAggrParam(param: MutableMapping[str, Any]) -> MutableMapping[str, Any]:
    return unpack_params(param)


def dictConv(base: MutableMapping[str, Any], updates: Mapping[str, Any]) -> None:
    deep_merge(base, updates)


def convParam2Setting(param: Mapping[str, Any]) -> dict[str, Any]:
    return nest_params(param)


def loadSettingFromYamlSimple(backgroundYamlFile: str | os.PathLike[str], varSettings: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return load_config_simple(backgroundYamlFile, varSettings)


def removeNoneSetting(param: MutableMapping[str, Any]) -> None:
    remove_none(param)


def loadSettingFromYaml(
    backgroundYamlFile: str | os.PathLike[str],
    dynamicYamlFile: str | os.PathLike[str],
    activeBackgroundYamlId: int = 0,
    activeDynamicYamlId: int = 0,
    param: Mapping[str, Any] | None = None,
    isOptionParse: bool = False,
) -> dict[str, Any]:
    return load_setting_from_yaml(
        backgroundYamlFile,
        dynamicYamlFile,
        activeBackgroundYamlId=activeBackgroundYamlId,
        activeDynamicYamlId=activeDynamicYamlId,
        param=param,
        isOptionParse=isOptionParse,
    )


def confParse(config: Mapping[str, Any], param: Mapping[str, Any]) -> tuple[dict[str, Any], bool, str]:
    parsed_config = copy.deepcopy(dict(config))
    try:
        merged = copy.deepcopy(dict(config))
        deep_merge(merged, nest_params(param), source="params")
        parsed_config = parse_config_options_and_refs(merged)
        return parsed_config, True, ""
    except MyExpError as exc:
        return parsed_config, False, str(exc)


def getYamlConfName(pyFileName: str) -> str:
    return config_name(pyFileName)


def parseConfigRef(config: Mapping[str, Any]) -> dict[str, Any]:
    return parse_config_refs(config)


parseFuncKwargs = filter_kwargs
unpackAggrParams = unpack_params
convParamToSetting = nest_params
