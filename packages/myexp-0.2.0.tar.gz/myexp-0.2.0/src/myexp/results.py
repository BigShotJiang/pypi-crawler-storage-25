from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .errors import ResultEmissionError


RESULT_JSON_START = "==>**ResultJson**<=="
RESULT_JSON_END = "==>**End**<=="
RESULT_SIDECAR_ENV = "RESEARCH_LAB_RESULT_JSON"


def _json_text(result: Any) -> str:
    if isinstance(result, str):
        return result
    try:
        return json.dumps(result, ensure_ascii=False, sort_keys=True)
    except TypeError as exc:
        raise ResultEmissionError(
            f"Result is not JSON serializable: {exc}",
            phase="result-emission",
            path="$",
            source="result",
            guidance="Return dictionaries, lists, strings, numbers, booleans, or None from the experiment.",
        ) from exc


def emit(
    result: Any,
    *,
    sidecar_path: str | os.PathLike[str] | None = None,
    force_stdout_marker: bool | None = None,
) -> dict[str, Any]:
    """Emit JSON result sidecar-first, with legacy stdout marker fallback."""

    raw_target = sidecar_path or os.environ.get(RESULT_SIDECAR_ENV, "")
    target = Path(raw_target).expanduser() if raw_target else None
    payload = _json_text(result)
    wrote_sidecar = False
    if target is not None:
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(payload, encoding="utf-8")
        except OSError as exc:
            raise ResultEmissionError(
                f"Could not write result sidecar: {exc}",
                phase="result-emission",
                path=str(target),
                source=RESULT_SIDECAR_ENV,
                guidance="Check that the result sidecar directory exists or is writable.",
            ) from exc
        wrote_sidecar = True

    emit_marker = (not wrote_sidecar) if force_stdout_marker is None else force_stdout_marker
    if emit_marker:
        print(RESULT_JSON_START)
        print(payload)
        print(RESULT_JSON_END)
    return {"sidecar_path": str(target) if wrote_sidecar and target is not None else None, "stdout_marker": bool(emit_marker)}


def emit_result(
    result: Any,
    *,
    sidecar_path: str | os.PathLike[str] | None = None,
    force_stdout_marker: bool | None = None,
) -> dict[str, Any]:
    return emit(result, sidecar_path=sidecar_path, force_stdout_marker=force_stdout_marker)
