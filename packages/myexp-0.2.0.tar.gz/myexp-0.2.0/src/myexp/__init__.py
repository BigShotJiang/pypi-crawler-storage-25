from __future__ import annotations

from .compat import (
    ExpTemplate,
    confParse,
    convParam2Setting,
    dictConv,
    getParams,
    getYamlConfName,
    isExpEnv,
    loadSettingFromYaml,
    loadSettingFromYamlSimple,
    parseConfigRef,
    parseFuncParams,
    printResult,
    removeNoneSetting,
    unpackAggrParam,
)
from .config import (
    config_name,
    deep_merge,
    filter_kwargs,
    load_config,
    load_config_simple,
    load_setting_from_yaml,
    load_setting_from_yaml_simple,
    nest_params,
    parse_config_options_and_refs,
    parse_config_refs,
    remove_none,
    unpack_params,
)
from .errors import ConfigError, MyExpError, ParameterError, ResultEmissionError
from .lifecycle import ExperimentTemplate, run_experiment
from .params import get_params, in_runtime, is_exp_env, params, runtime_params
from .results import RESULT_JSON_END, RESULT_JSON_START, RESULT_SIDECAR_ENV, emit, emit_result

__version__ = "0.2.0"

__all__ = [
    "ConfigError",
    "ExpTemplate",
    "ExperimentTemplate",
    "MyExpError",
    "ParameterError",
    "RESULT_JSON_END",
    "RESULT_JSON_START",
    "RESULT_SIDECAR_ENV",
    "ResultEmissionError",
    "__version__",
    "config_name",
    "confParse",
    "convParam2Setting",
    "deep_merge",
    "dictConv",
    "emit",
    "emit_result",
    "filter_kwargs",
    "getParams",
    "getYamlConfName",
    "get_params",
    "in_runtime",
    "isExpEnv",
    "is_exp_env",
    "loadConfig",
    "loadSettingFromYaml",
    "loadSettingFromYamlSimple",
    "load_config",
    "load_config_simple",
    "load_setting_from_yaml",
    "load_setting_from_yaml_simple",
    "nest_params",
    "params",
    "parseConfigRef",
    "parseFuncParams",
    "parse_config_options_and_refs",
    "parse_config_refs",
    "printResult",
    "removeNoneSetting",
    "remove_none",
    "run_experiment",
    "runtime_params",
    "unpackAggrParam",
    "unpack_params",
]

loadConfig = load_config
