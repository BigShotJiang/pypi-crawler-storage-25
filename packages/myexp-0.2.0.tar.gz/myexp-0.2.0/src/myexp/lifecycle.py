from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any, Callable, Mapping

from .config import config_name, load_config, nest_params, remove_none, unpack_params
from .params import in_runtime, params
from .results import emit


class ExperimentTemplate:
    """Lifecycle runner for YAML-backed experiments.

    Subclasses may use the concise 0.2.0 hooks (`setup`, `parameters`,
    `should_run`, `normalize_params`, `execute`) or the 0.1.0 hook names kept
    for FLDPCR2 compatibility (`setPakPath`, `getExpParam`, `expExecCond`,
    `modExpParam`, `execExp`).
    """

    def __init__(
        self,
        workSpaceDir: str | os.PathLike[str] = "",
        taskConfigName: str = "taskConfig.yaml",
        bgConfigName: str = "bgConfig.yaml",
        isShowConfig: bool = True,
        isForcePrintResults: bool = False,
        *,
        local_defaults: Mapping[str, Any] | None = None,
    ) -> None:
        self.workSpaceDir = str(workSpaceDir)
        self.bgConfigName = bgConfigName
        self.taskConfigName = taskConfigName
        self.isShowConfig = isShowConfig
        self.isForcePrintResults = isForcePrintResults
        self.local_defaults = copy.deepcopy(dict(local_defaults or {}))

    def setup(self) -> None:
        if type(self).setPakPath is not ExperimentTemplate.setPakPath:
            self.setPakPath()

    def parameters(self) -> dict[str, Any]:
        if type(self).getExpParam is not ExperimentTemplate.getExpParam:
            return self.getExpParam()
        return params(self.local_defaults)

    def should_run(self, run_params: dict[str, Any]) -> bool:
        if type(self).expExecCond is not ExperimentTemplate.expExecCond:
            return bool(self.expExecCond(run_params))
        return True

    def normalize_params(self, run_params: dict[str, Any]) -> dict[str, Any]:
        if type(self).modExpParam is not ExperimentTemplate.modExpParam:
            return self.modExpParam(run_params)
        return run_params

    def execute(self, config: dict[str, Any]) -> Any:
        if type(self).execExp is not ExperimentTemplate.execExp:
            return self.execExp(config)
        raise NotImplementedError("ExperimentTemplate subclasses must implement execute() or execExp().")

    def skipped_result(self, run_params: Mapping[str, Any]) -> dict[str, Any]:
        return {}

    def run(self) -> Any:
        self.setup()
        raw_params = self.parameters()
        if not self.should_run(raw_params):
            skipped = self.skipped_result(raw_params)
            if self.isForcePrintResults or _safe_in_runtime():
                emit(skipped)
            raise SystemExit(0)

        run_params = self.normalize_params(dict(raw_params))
        pid = int(run_params.pop("pid", 0))
        unpack_params(run_params)
        var_settings = nest_params(run_params)
        config = load_config(
            Path(self.workSpaceDir) / self.bgConfigName,
            Path(self.workSpaceDir) / self.taskConfigName,
            active_dynamic_yaml_id=pid,
            params=run_params,
            parse_options=True,
        )
        config.pop("optionRef", None)
        remove_none(config)
        if self.isShowConfig:
            _show_config(config, var_settings)
        result = self.execute(config)
        if self.isForcePrintResults or _safe_in_runtime():
            emit(result)
        return result

    # 0.1.0 compatibility hooks.
    def setPakPath(self) -> None:
        return None

    def getExpParam(self) -> dict[str, Any]:
        return params(self.local_defaults)

    def expExecCond(self, param: dict[str, Any]) -> bool:
        return True

    def modExpParam(self, param: dict[str, Any]) -> dict[str, Any]:
        return param

    def execExp(self, theConfig: dict[str, Any]) -> Any:
        raise NotImplementedError("Override execExp() or execute().")


def run_experiment(
    func: Callable[[dict[str, Any]], Any],
    *,
    local_defaults: Mapping[str, Any] | None = None,
    argv: list[str] | tuple[str, ...] | None = None,
    should_run: Callable[[dict[str, Any]], bool] | None = None,
    normalize: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    emit_output: bool = True,
) -> Any:
    """Minimal function-style runner for scripts that do not need YAML lifecycle config."""

    run_params = params(local_defaults, argv)
    if should_run is not None and not should_run(run_params):
        skipped = {"status": "skipped", "result": {}}
        if emit_output:
            emit(skipped)
        return skipped
    if normalize is not None:
        run_params = normalize(dict(run_params))
    result = func(run_params)
    if emit_output:
        emit(result)
    return result


def _show_config(config: Mapping[str, Any], var_settings: Mapping[str, Any]) -> None:
    print("完整参数内容信息如下：")
    for key in config:
        print({key: config[key]})
    if var_settings:
        print("其中，被本地参数修正的内容如下：")
        for key in var_settings:
            print({key: var_settings[key]})
    else:
        print("本地参数无修正内容。")


def _safe_in_runtime() -> bool:
    return in_runtime()


def default_config_name(script_file: str | os.PathLike[str]) -> str:
    return config_name(script_file)
