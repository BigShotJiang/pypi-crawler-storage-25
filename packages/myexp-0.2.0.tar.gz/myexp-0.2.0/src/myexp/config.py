from __future__ import annotations

import copy
import inspect
import os
import re
import warnings
from collections.abc import Callable, Mapping, MutableMapping, Sequence
from pathlib import Path
from typing import Any

import yaml

from .errors import ConfigError, ParameterError


def filter_kwargs(func: Callable[..., Any], args: Mapping[str, Any] | None) -> dict[str, Any]:
    """Return only keys accepted by func's signature."""

    if args is None:
        return {}
    signature = inspect.signature(func)
    if any(parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in signature.parameters.values()):
        return dict(args)
    return {parameter.name: args[parameter.name] for parameter in signature.parameters.values() if parameter.name in args}


def unpack_params(param: MutableMapping[str, Any]) -> MutableMapping[str, Any]:
    """Promote aggr_N mapping values into the top-level parameter mapping."""

    pattern = re.compile(r"^aggr_\d+$")
    promoted: dict[str, Any] = {}
    remove_keys: list[str] = []
    for key, value in list(param.items()):
        if pattern.match(str(key)):
            if not isinstance(value, Mapping):
                raise ParameterError(
                    "Aggregate parameter value must be a mapping.",
                    phase="parameter-normalization",
                    path=str(key),
                    source="params",
                    guidance="Use aggr_1={\"a__b\": value} rather than a scalar or list.",
                )
            remove_keys.append(str(key))
            promoted.update(value)
    for key in remove_keys:
        param.pop(key, None)
    param.update(promoted)
    return param


def deep_merge(base: MutableMapping[str, Any], updates: Mapping[str, Any], *, source: str = "updates") -> None:
    for key, value in updates.items():
        if isinstance(value, Mapping):
            child = base.get(key)
            if not isinstance(child, MutableMapping):
                child = {}
                base[key] = child
            deep_merge(child, value, source=source)
        else:
            base[key] = value


def nest_params(param: Mapping[str, Any]) -> dict[str, Any]:
    """Convert flat double-underscore parameter keys into nested config overrides."""

    nested: dict[str, Any] = {}
    for key, value in param.items():
        parts = str(key).split("__")
        if any(part == "" for part in parts):
            raise ParameterError(
                "Parameter key contains an empty hierarchy segment.",
                phase="parameter-normalization",
                path=str(key),
                source="params",
                guidance="Use exactly two underscores between hierarchy levels, for example model__name.",
            )
        cursor = nested
        for part in parts[:-1]:
            child = cursor.setdefault(part, {})
            if not isinstance(child, dict):
                raise ParameterError(
                    "Parameter hierarchy conflicts with an existing scalar value.",
                    phase="parameter-normalization",
                    path=str(key),
                    source="params",
                    guidance="Do not set both a scalar key and nested keys below that key.",
                )
            cursor = child
        cursor[parts[-1]] = value
    return nested


def remove_none(config: MutableMapping[str, Any]) -> None:
    remove_keys: list[str] = []
    for key, value in list(config.items()):
        if value is None:
            remove_keys.append(key)
        elif isinstance(value, MutableMapping):
            remove_none(value)
    for key in remove_keys:
        del config[key]


def config_name(script_name: str | os.PathLike[str]) -> str:
    name = Path(script_name).name
    if name.endswith(".scp.py"):
        return f"{name[:-7]}.config.yaml"
    return f"{name.split('.')[0]}.config.yaml"


def _read_yaml_documents(
    path: str | os.PathLike[str],
    *,
    required: bool,
    phase: str,
) -> list[Any]:
    yaml_path = Path(path)
    if not yaml_path.exists():
        if required:
            raise ConfigError(
                "Config file does not exist.",
                phase=phase,
                path=str(yaml_path),
                source="filesystem",
                guidance="Create the config file or pass the correct workSpaceDir/taskConfigName.",
            )
        return []
    try:
        with yaml_path.open("r", encoding="utf-8") as handle:
            return list(yaml.load_all(handle, Loader=yaml.FullLoader))
    except yaml.YAMLError as exc:
        raise ConfigError(
            f"YAML could not be parsed: {exc}",
            phase=phase,
            path=str(yaml_path),
            source="yaml",
            guidance="Fix YAML syntax before running the experiment.",
        ) from exc


def _document_at(documents: Sequence[Any], index: int, *, path: str | os.PathLike[str], phase: str) -> dict[str, Any]:
    if not documents:
        return {}
    if index < 0 or index >= len(documents):
        raise ConfigError(
            f"YAML document index {index} is out of range [0, {len(documents)}).",
            phase=phase,
            path=str(path),
            source="yaml",
            guidance="Check the pid value or active YAML document index.",
        )
    document = documents[index] or {}
    if not isinstance(document, Mapping):
        raise ConfigError(
            "YAML document must be a mapping.",
            phase=phase,
            path=str(path),
            source="yaml",
            guidance="Use key/value YAML at the selected document index.",
        )
    return copy.deepcopy(dict(document))


def _lookup(root: Mapping[str, Any], ref_path: str, *, phase: str, source_path: str) -> Any:
    target: Any = root
    if not ref_path:
        raise ConfigError(
            "Reference path is empty.",
            phase=phase,
            path=source_path,
            source="config-reference",
            guidance="Use references such as ?model.name.",
        )
    for part in ref_path.split("."):
        if isinstance(target, Mapping) and part in target:
            target = target[part]
        else:
            raise ConfigError(
                f"Reference path {ref_path} could not be resolved.",
                phase=phase,
                path=source_path,
                source="config-reference",
                guidance="Check the referenced key path after parameter overrides are applied.",
            )
    return target


def _resolve_selector(root: Mapping[str, Any], selector: Any, *, path: str, source: str) -> Any:
    seen: set[str] = set()
    while isinstance(selector, str) and selector.startswith("?"):
        ref_path = selector[1:]
        if ref_path in seen:
            raise ConfigError(
                f"Option selector reference cycle detected at {ref_path}.",
                phase="option-parse",
                path=path or "$",
                source=source,
                guidance="Break the selector cycle or replace one selector reference with a concrete value.",
            )
        seen.add(ref_path)
        selector = _lookup(root, ref_path, phase="option-parse", source_path=path or "$")
    return selector


def _is_deferred_selector_dependency(error: ConfigError) -> bool:
    return (
        error.phase == "option-parse"
        and error.source == "config-reference"
        and error.message.startswith("Reference path ")
        and " could not be resolved." in error.message
    )


def _select_options(node: Any, root: Mapping[str, Any], path: str, deferred_errors: list[ConfigError]) -> Any:
    if isinstance(node, dict):
        if "$" in node:
            selector = node["$"]
            ref_path = "<local>"
            if isinstance(selector, str):
                ref_path = selector[1:] if selector.startswith("?") else "<local>"
                try:
                    selector = _resolve_selector(root, selector, path=path or "$", source=ref_path)
                except ConfigError as exc:
                    if _is_deferred_selector_dependency(exc):
                        deferred_errors.append(exc)
                        return copy.deepcopy(node)
                    raise
            if not isinstance(selector, str):
                raise ConfigError(
                    "Option selector must resolve to a string.",
                    phase="option-parse",
                    path=path or "$",
                    source=ref_path,
                    guidance="Set the option selector source to a string value.",
                )
            if selector in node:
                return _select_options(copy.deepcopy(node[selector]), root, path, deferred_errors)
            regex_matches = [key for key in node if key not in {"$", "default"} and re.match(str(key), selector)]
            if len(regex_matches) > 1:
                raise ConfigError(
                    f"Option selector {selector!r} matched multiple regex keys: {regex_matches}.",
                    phase="option-parse",
                    path=path or "$",
                    source=ref_path,
                    guidance="Make option regex keys mutually exclusive or add an exact option key.",
                )
            if len(regex_matches) == 1:
                warnings.warn(f"Config path {path or '$'} has no exact option {selector}; matched regex {regex_matches[0]}.")
                return _select_options(copy.deepcopy(node[regex_matches[0]]), root, path, deferred_errors)
            if "default" in node:
                warnings.warn(f"Config path {path or '$'} has no option {selector}; using default.")
                return _select_options(copy.deepcopy(node["default"]), root, path, deferred_errors)
            raise ConfigError(
                f"Option selector {selector!r} did not match any option.",
                phase="option-parse",
                path=path or "$",
                source=ref_path,
                guidance="Add an exact option, a non-ambiguous regex option, or a default option.",
            )
        return {key: _select_options(value, root, f"{path}.{key}" if path else str(key), deferred_errors) for key, value in node.items()}
    if isinstance(node, list):
        return [_select_options(value, root, f"{path}[{index}]", deferred_errors) for index, value in enumerate(node)]
    return node


def _has_option_node(node: Any) -> bool:
    if isinstance(node, dict):
        if "$" in node:
            return True
        return any(_has_option_node(value) for value in node.values())
    if isinstance(node, list):
        return any(_has_option_node(value) for value in node)
    return False


def _resolve_refs(node: Any, root: Mapping[str, Any], path: str, stack: tuple[str, ...] = ()) -> Any:
    if isinstance(node, str) and node.startswith("?"):
        ref_path = node[1:]
        if ref_path in stack:
            raise ConfigError(
                f"Reference cycle detected at {ref_path}.",
                phase="reference-parse",
                path=path or "$",
                source="config-reference",
                guidance="Break the cycle by replacing one reference with a concrete value.",
            )
        target = copy.deepcopy(_lookup(root, ref_path, phase="reference-parse", source_path=path or "$"))
        return _resolve_refs(target, root, ref_path, stack + (ref_path,))
    if isinstance(node, dict):
        return {key: _resolve_refs(value, root, f"{path}.{key}" if path else str(key), stack) for key, value in node.items()}
    if isinstance(node, list):
        return [_resolve_refs(value, root, f"{path}[{index}]", stack) for index, value in enumerate(node)]
    return node


def parse_config_refs(config: Mapping[str, Any]) -> dict[str, Any]:
    root = copy.deepcopy(dict(config))
    return _resolve_refs(root, root, "")


def parse_config_options_and_refs(config: Mapping[str, Any]) -> dict[str, Any]:
    selected = copy.deepcopy(dict(config))
    deferred_errors: list[ConfigError] = []
    for _ in range(20):
        deferred_errors = []
        next_selected = _select_options(selected, selected, "", deferred_errors)
        if next_selected == selected:
            break
        selected = next_selected
    if _has_option_node(selected):
        if deferred_errors:
            raise deferred_errors[0]
        raise ConfigError(
            "One or more option selectors could not be resolved after dependent options were parsed.",
            phase="option-parse",
            path="$",
            source="config-option",
            guidance="Check selector references, option nesting, and parameter overrides.",
        )
    return _resolve_refs(selected, selected, "")


def load_config_simple(
    background_yaml_file: str | os.PathLike[str],
    var_settings: Mapping[str, Any] | None = None,
    *,
    required: bool = True,
) -> dict[str, Any]:
    documents = _read_yaml_documents(background_yaml_file, required=required, phase="config-load")
    config = _document_at(documents, 0, path=background_yaml_file, phase="config-load")
    deep_merge(config, dict(var_settings or {}), source="params")
    return config


def load_setting_from_yaml_simple(
    background_yaml_file: str | os.PathLike[str],
    var_settings: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    return load_config_simple(background_yaml_file, var_settings, required=False)


def load_config(
    background_yaml_file: str | os.PathLike[str],
    dynamic_yaml_file: str | os.PathLike[str] | None = None,
    *,
    active_background_yaml_id: int = 0,
    active_dynamic_yaml_id: int = 0,
    params: Mapping[str, Any] | None = None,
    parse_options: bool = False,
    require_background: bool = True,
    require_dynamic: bool = True,
) -> dict[str, Any]:
    background_docs = _read_yaml_documents(background_yaml_file, required=require_background, phase="config-load")
    config = _document_at(background_docs, active_background_yaml_id, path=background_yaml_file, phase="config-load")
    if dynamic_yaml_file is not None:
        dynamic_docs = _read_yaml_documents(dynamic_yaml_file, required=require_dynamic, phase="config-load")
        dynamic_config = _document_at(dynamic_docs, active_dynamic_yaml_id, path=dynamic_yaml_file, phase="config-load")
        deep_merge(config, dynamic_config, source=str(dynamic_yaml_file))

    runtime_params = dict(params or {})
    if runtime_params:
        deep_merge(config, nest_params(runtime_params), source="params")
    if parse_options:
        config = parse_config_options_and_refs(config)
    return config


def load_setting_from_yaml(
    background_yaml_file: str | os.PathLike[str],
    dynamic_yaml_file: str | os.PathLike[str],
    *,
    activeBackgroundYamlId: int = 0,
    activeDynamicYamlId: int = 0,
    param: Mapping[str, Any] | None = None,
    isOptionParse: bool = False,
) -> dict[str, Any]:
    return load_config(
        background_yaml_file,
        dynamic_yaml_file,
        active_background_yaml_id=activeBackgroundYamlId,
        active_dynamic_yaml_id=activeDynamicYamlId,
        params=param,
        parse_options=isOptionParse,
        require_background=False,
        require_dynamic=False,
    )
