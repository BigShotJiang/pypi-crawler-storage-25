from __future__ import annotations


class MyExpError(Exception):
    """Base error carrying enough context for script authors to fix protocol issues."""

    def __init__(
        self,
        message: str,
        *,
        phase: str,
        path: str | None = None,
        source: str | None = None,
        guidance: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.phase = phase
        self.path = path
        self.source = source
        self.guidance = guidance

    def __str__(self) -> str:
        details = [f"phase={self.phase}"]
        if self.path:
            details.append(f"path={self.path}")
        if self.source:
            details.append(f"source={self.source}")
        text = f"{self.message} ({', '.join(details)})"
        if self.guidance:
            text = f"{text}. guidance: {self.guidance}"
        return text


class ParameterError(MyExpError):
    """Raised when runtime or local parameters cannot be parsed safely."""


class ConfigError(MyExpError):
    """Raised when YAML config merge, option parsing, or reference resolution fails."""


class ResultEmissionError(MyExpError):
    """Raised when a result cannot be written to the sidecar or stdout marker."""
