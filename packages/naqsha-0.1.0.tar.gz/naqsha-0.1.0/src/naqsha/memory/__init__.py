"""Memory Port adapters."""
