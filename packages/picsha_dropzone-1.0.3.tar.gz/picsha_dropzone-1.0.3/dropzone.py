#!/usr/bin/env python3

import os
import sys
import time
import json
import argparse
import mimetypes
from pathlib import Path

try:
    import requests
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn
except ImportError:
    print("Missing required libraries. Please run: pip install -r requirements.txt")
    sys.exit(1)

console = Console()

def main():
    parser = argparse.ArgumentParser(description="Auto-summarizing Dropzone CLI for Picsha AI")
    parser.add_argument("directory", help="Directory containing files to process")
    parser.add_argument("-k", "--api-key", help="Picsha API Key (or set PICSHA_API_KEY env var)")
    parser.add_argument("-u", "--api-url", default="https://api.picsha.ai", help="Picsha API URL")
    
    args = parser.parse_args()
    
    api_key = args.api_key or os.environ.get("PICSHA_API_KEY")
    if not api_key:
        console.print("[red]Error: API key is required. Use --api-key or set PICSHA_API_KEY.[/red]")
        sys.exit(1)
        
    api_url = args.api_url.rstrip("/")
    target_dir = Path(args.directory).resolve()
    
    if not target_dir.is_dir():
        console.print(f"[red]Error: {target_dir} is not a directory or does not exist.[/red]")
        sys.exit(1)
        
    console.print(f"\n[blue]🚀 Initializing Picsha Dropzone in {target_dir}...[/blue]\n")
    console.print(f"[dim]Using API: {api_url}[/dim]")
    
    # Read directory
    files_to_process = []
    for item in target_dir.iterdir():
        if item.is_file():
            if item.name.startswith('.') or item.name.endswith('.json') or item.name == 'README.md':
                continue
            files_to_process.append(item)
            
    if not files_to_process:
        console.print("[yellow]No files found to process.[/yellow]")
        sys.exit(0)
        
    console.print(f"[green]Found {len(files_to_process)} files to process.[/green]\n")
    
    results = []
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=False
    ) as progress:
        for file_path in files_to_process:
            task = progress.add_task(f"Processing {file_path.name}...", total=None)
            filename = file_path.name
            mime_type, _ = mimetypes.guess_type(str(file_path))
            if not mime_type:
                mime_type = 'application/octet-stream'
                
            try:
                # Step 1: Upload
                progress.update(task, description=f"Uploading {filename}...")
                headers = {"Authorization": f"Bearer {api_key}"}
                
                with open(file_path, 'rb') as f:
                    files = {'file': (filename, f, mime_type)}
                    upload_res = requests.post(f"{api_url}/v1/assets", headers=headers, files=files)
                
                upload_res.raise_for_status()
                upload_data = upload_res.json()
                asset_id = upload_data.get('id') or (upload_data.get('asset', {}).get('id'))
                
                if not asset_id:
                    raise Exception("Upload succeeded but no asset ID was returned.")
                
                # Step 2: Trigger AI Analysis (Documents only)
                if not mime_type.startswith('image/'):
                    progress.update(task, description=f"Triggering document summary for {filename}...")
                    sum_res = requests.post(f"{api_url}/v1/assets/{asset_id}/summarize", headers=headers)
                    if sum_res.status_code not in (200, 201, 202, 404):
                        console.print(f"[yellow]Warning: Summarize endpoint returned {sum_res.status_code} for {filename}[/yellow]")
                    
                # Step 3: Poll for metadata
                progress.update(task, description=f"Analyzing {filename} (this may take a few seconds)...")
                asset_data = None
                
                for _ in range(30): # Poll up to 30 times (60s)
                    time.sleep(2)
                    check_res = requests.get(f"{api_url}/v1/assets/{asset_id}", headers=headers)
                    if not check_res.ok:
                        continue
                    
                    data = check_res.json()
                    asset_data = data.get('asset') or data
                    
                    ai_analysis = asset_data.get('aiAnalysis') or {}
                    
                    has_summary = bool(asset_data.get('summary')) or bool(ai_analysis.get('summaryShort'))
                    has_tags = bool(asset_data.get('metadata', {}).get('ai_tags')) or bool(ai_analysis.get('labels'))
                    
                    if has_summary or has_tags:
                        break
                        
                if not asset_data:
                    raise Exception("Timed out waiting for asset metadata to be populated.")
                    
                # Step 4: Save Sidecar
                metadata_dict = asset_data.get('metadata') or {}
                ai_analysis = asset_data.get('aiAnalysis') or {}
                
                labels = ai_analysis.get('labels', [])
                extracted_tags = [l.get('name') for l in labels] if labels and isinstance(labels[0], dict) else labels
                
                metadata = {
                    "id": asset_data.get('id'),
                    "filename": filename,
                    "title": asset_data.get('title') or filename,
                    "summary": asset_data.get('summary') or metadata_dict.get('ai_caption') or ai_analysis.get('summaryShort') or 'No summary generated.',
                    "tags": asset_data.get('tags') or metadata_dict.get('ai_tags') or extracted_tags or [],
                    "url": asset_data.get('url'),
                    "processedAt": time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
                }
                
                sidecar_path = target_dir / f"{filename}.json"
                with open(sidecar_path, 'w', encoding='utf-8') as sf:
                    json.dump(metadata, sf, indent=2)
                    
                results.append(metadata)
                progress.update(task, description=f"[green]✔ Processed {filename}[/green]")
                progress.stop_task(task)
                
            except Exception as e:
                progress.update(task, description=f"[red]✖ Failed to process {filename}: {str(e)}[/red]")
                progress.stop_task(task)
                
    # Step 5: Generate README
    console.print("\nGenerating README.md...")
    try:
        readme_path = target_dir / "README.md"
        with open(readme_path, 'w', encoding='utf-8') as f:
            f.write("# 📁 Dropzone Summary\n\n")
            f.write(f"Auto-generated by Picsha Dropzone on {time.strftime('%Y-%m-%d %H:%M:%S')}.\n\n")
            f.write("| File | Title | Summary | Tags | Link |\n")
            f.write("|------|-------|---------|------|------|\n")
            
            for res in results:
                link = f"[View]({res['url']})" if res.get('url') else "N/A"
                tags_str = ", ".join(res.get('tags', [])) if isinstance(res.get('tags'), list) else ""
                f.write(f"| `{res['filename']}` | **{res['title']}** | {res['summary']} | {tags_str} | {link} |\n")
                
        console.print("[green]✔ Generated README.md[/green]")
    except Exception as e:
        console.print(f"[red]✖ Failed to generate README.md: {str(e)}[/red]")
        
    console.print("\n[bold green]✨ Done! All files processed successfully.[/bold green]")

if __name__ == "__main__":
    main()
