"""Backend adapters that route carl training to external systems.

Each adapter implements :class:`UnifiedBackend`. The module-level registry
maps backend name → adapter instance. Built-in names:

* ``trl`` — default, uses the in-process CARLTrainer (always available).
* ``unsloth`` — launches Unsloth in a subprocess via a generated entrypoint.
* ``axolotl`` — pipes translated YAML to ``axolotl train -``.
* ``tinker`` — translates + records state; submission path pending API lock-in.
* ``atropos`` — shells out to the atropos CLI with a JSON config file.
* ``slime`` — launches THUDM/slime (Megatron-LM + SGLang) via a generated
  entrypoint. Requires ``carl-studio[slime]`` + user-built slime + Megatron.

Registration happens on first import. Override by calling
``register_adapter()`` with a custom implementation.
"""

from __future__ import annotations

from .atropos_adapter import AtroposAdapter
from .axolotl_adapter import AxolotlAdapter
from .connection import DEFAULT_TRAINING_SPEC, TrainingConnection
from .protocol import AdapterError, BackendJob, BackendStatus, UnifiedBackend
from .registry import get_adapter, list_adapters, register_adapter
from .slime_adapter import SlimeAdapter
from .tinker_adapter import TinkerAdapter
from .trl_adapter import TRLAdapter
from .unsloth_adapter import UnslothAdapter


_BUILTIN_ADAPTERS: tuple[UnifiedBackend, ...] = (
    TRLAdapter(),
    UnslothAdapter(),
    AxolotlAdapter(),
    TinkerAdapter(),
    AtroposAdapter(),
    SlimeAdapter(),
)


def _register_builtins() -> None:
    for adapter in _BUILTIN_ADAPTERS:
        register_adapter(adapter)


_register_builtins()


__all__ = [
    "AdapterError",
    "AtroposAdapter",
    "AxolotlAdapter",
    "BackendJob",
    "BackendStatus",
    "DEFAULT_TRAINING_SPEC",
    "SlimeAdapter",
    "TRLAdapter",
    "TinkerAdapter",
    "TrainingConnection",
    "UnifiedBackend",
    "UnslothAdapter",
    "get_adapter",
    "list_adapters",
    "register_adapter",
]
