"""CARL agent loop — agentic chat with tool use and proactive guidance.

Wires existing infrastructure (SourceIngester, WorkFrame, Python execution)
as callable tools via the Claude API tool use protocol.  The agent drives
the workflow: it recommends next steps, ingests files on mention, runs
analyses, and creates deliverables proactively.

Features:
  - Session persistence: save/resume conversations across invocations
  - Permission hooks: pre/post tool-use callbacks for consent gating
  - Cost tracking: per-turn cost accumulation with budget enforcement
  - Context compaction: automatic summarization at token threshold
  - Streaming: real-time token display via text_delta events
  - Corruption resilience: quarantine bad sessions on load
  - Budget pre-check: refuse turns that would exceed the budget cap
  - Tool timeouts: per-tool deadlines, hook isolation
  - Arg schema validation: typed errors surfaced back to the model
  - dispatch_cli: agent can invoke registered ``carl <cmd>`` ops
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Iterator, cast

from pydantic import BaseModel, Field, ValidationError as PydanticValidationError

from carl_studio.agent_state import CostLedger, SessionState
from carl_studio.knowledge_store import KnowledgeStore, _KNOWLEDGE_MAX_CHUNKS
from carl_studio.tool_dispatcher import (
    ToolDispatcher,
    _MAX_CONSECUTIVE_ALL_DENIED as _TD_MAX_CONSECUTIVE_ALL_DENIED,
)

if TYPE_CHECKING:  # pragma: no cover — typing only
    from carl_core.memory import MemoryItem, MemoryLayer, MemoryStore
    from carl_studio.constitution import Constitution, ConstitutionalRule

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Memory recall defaults
# ---------------------------------------------------------------------------
_MEMORY_RECALL_TOP_K = 3
_MEMORY_RECALL_MIN_SCORE = 0.15
_MEMORY_CONTENT_PREVIEW = 200
_MEMORY_ITEM_OUTPUT_CAP = 500

# Signal phrases that trigger an auto-remember of the user's utterance.
_AUTO_REMEMBER_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\bremember\b", re.IGNORECASE),
    re.compile(r"^\s*note\s*:", re.IGNORECASE),
    re.compile(r"\balways\b", re.IGNORECASE),
    re.compile(r"\bnever\b", re.IGNORECASE),
)

# ---------------------------------------------------------------------------
# Hard context bounds
# ---------------------------------------------------------------------------
_COMPACT_THRESHOLD = 140_000
_TOOL_RESULT_MAX = 8_000
_KEEP_RECENT = 10

# ---------------------------------------------------------------------------
# Session persistence schema version — sourced from carl_studio.sessions
# (v0.12 extraction). Re-exported here for back-compat with callers that
# imported via ``from carl_studio.chat_agent import _SESSION_SCHEMA_VERSION``.
# ---------------------------------------------------------------------------
from carl_studio.sessions import _SESSION_SCHEMA_VERSION

# ---------------------------------------------------------------------------
# Tool execution bounds
# ---------------------------------------------------------------------------
_DEFAULT_TOOL_TIMEOUT_S = 30.0
_TOOL_TIMEOUTS_S: dict[str, float] = {
    "run_analysis": 60.0,
    "ingest_source": 120.0,
    "dispatch_cli": 60.0,
}

# Shell metacharacters forbidden in dispatch_cli args — we never use shell=True
# but we reject them defensively so operators cannot social-engineer the model
# into requesting an expansion that carl itself would interpret.
_FORBIDDEN_SHELL_METAS: tuple[str, ...] = (
    ";", "&", "|", ">", "<", "`", "$(", "\n", "\r",
)

# Environment keys that the model should NEVER inherit via run_analysis. Any
# env var whose UPPERCASED name contains one of these substrings is stripped
# before spawning the subprocess. Explicit whitelist entries below survive.
_SENSITIVE_ENV_SUBSTRINGS: tuple[str, ...] = (
    "KEY",
    "TOKEN",
    "SECRET",
    "PASSWORD",
    "PASSPHRASE",
    "AUTHORIZATION",
    "BEARER",
    "API_KEY",
)

# Keys that always survive the sensitive-env scrub. They are infrastructure
# plumbing (PATH, HOME, LANG, ...) the child process needs to function.
_SAFE_ENV_ALLOWLIST: frozenset[str] = frozenset({
    "PATH", "HOME", "LANG", "PWD", "TMPDIR", "USER", "SHELL", "LC_ALL",
})


def _is_sensitive_env_key(key: str) -> bool:
    """Return True when ``key`` looks like a credential/secret env var.

    Membership in the explicit allowlist wins; otherwise any substring match
    in :data:`_SENSITIVE_ENV_SUBSTRINGS` marks the key as sensitive.
    """
    if not key:
        return False
    if key in _SAFE_ENV_ALLOWLIST:
        return False
    upper = key.upper()
    return any(marker in upper for marker in _SENSITIVE_ENV_SUBSTRINGS)


def _scrubbed_subprocess_env() -> dict[str, str]:
    """Copy of ``os.environ`` with credentials stripped.

    Preserves :data:`_SAFE_ENV_ALLOWLIST` keys and drops anything that
    :func:`_is_sensitive_env_key` flags. Never mutates ``os.environ``.
    """
    return {
        k: v for k, v in os.environ.items() if not _is_sensitive_env_key(k)
    }

# Conservative max output tokens assumed for the budget pre-check.
_BUDGET_PRECHECK_MAX_OUTPUT_TOKENS = 64000

# ---------------------------------------------------------------------------
# Model pricing ($/M tokens: input, output)
# ---------------------------------------------------------------------------
_MODEL_PRICING: dict[str, tuple[float, float]] = {
    "claude-opus-4-6": (5.00, 25.00),
    "claude-sonnet-4-6": (3.00, 15.00),
    "claude-haiku-4-5": (1.00, 5.00),
    "claude-haiku-4-5-20251001": (1.00, 5.00),
    "claude-3-haiku-20240307": (0.25, 1.25),
}
_DEFAULT_PRICING = (5.00, 25.00)  # assume Opus pricing if unknown


def _compute_turn_cost(usage: Any, model: str) -> float:
    """Compute USD cost for a single API turn from response.usage."""
    input_rate, output_rate = _MODEL_PRICING.get(model, _DEFAULT_PRICING)
    input_tokens = getattr(usage, "input_tokens", 0) or 0
    output_tokens = getattr(usage, "output_tokens", 0) or 0
    cache_read = getattr(usage, "cache_read_input_tokens", 0) or 0
    cache_create = getattr(usage, "cache_creation_input_tokens", 0) or 0
    return (
        (input_tokens * input_rate / 1_000_000)
        + (output_tokens * output_rate / 1_000_000)
        + (cache_read * input_rate * 0.1 / 1_000_000)
        + (cache_create * input_rate * 1.25 / 1_000_000)
    )


def _estimate_turn_upper_bound_cost(model: str, max_output_tokens: int) -> float:
    """Conservative USD cost ceiling for a turn using `max_output_tokens`.

    This assumes the model emits the maximum possible output. Input tokens are
    excluded from the pre-check because they are already counted once the
    turn lands, and overestimating too aggressively would make any non-trivial
    budget reject every turn on the first try. The output cap is the dominant
    runaway vector; that is what we gate on.
    """
    _input_rate, output_rate = _MODEL_PRICING.get(model, _DEFAULT_PRICING)
    return max(0, max_output_tokens) * output_rate / 1_000_000


# ---------------------------------------------------------------------------
# Permission hooks
# ---------------------------------------------------------------------------


# v0.15: ToolPermission migrated to carl_studio.tool_dispatcher so the
# dispatcher and the agent share one enum type. Re-exported here for
# back-compat — existing callers that ``from carl_studio.chat_agent
# import ToolPermission`` continue to work unchanged.
from carl_studio.tool_dispatcher import ToolPermission


# Callback types
PreToolHook = Callable[[str, dict[str, Any]], ToolPermission]
PostToolHook = Callable[[str, dict[str, Any], str], None]


# ---------------------------------------------------------------------------
# Session persistence — extracted to carl_studio.sessions in v0.12.0.
# Re-imported here so existing `from carl_studio.chat_agent import SessionStore`
# callers keep working. Schema version, directory constants, and helpers
# come from the same module.
# ---------------------------------------------------------------------------

from carl_studio.sessions import (
    SessionStore,
    _QUARANTINE_SUBDIR,
    _SESSIONS_DIR,
    _now_iso,
    _quarantine_stamp,
)

# ---------------------------------------------------------------------------
# Tool schemas for Claude API
# ---------------------------------------------------------------------------

TOOLS: list[dict[str, Any]] = [
    {
        "name": "ingest_source",
        "description": "Ingest files from a path, URL, or directory into the knowledge base for later querying.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path, directory, URL, or HF dataset ID"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "query_knowledge",
        "description": "Search the ingested knowledge base. Returns the most relevant chunks.",
        "input_schema": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "What to search for"},
            },
            "required": ["question"],
        },
    },
    {
        "name": "run_analysis",
        "description": "Execute Python code for data analysis. Use pandas, csv, json, math — standard lib + common packages. Print results to stdout.",
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute"},
            },
            "required": ["code"],
        },
    },
    {
        "name": "create_file",
        "description": "Create or overwrite a file with the given content.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to create"},
                "content": {"type": "string", "description": "File content"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "read_file",
        "description": "Read a file and return its contents (up to 8K chars).",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to read"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "set_frame",
        "description": "Set the analytical WorkFrame lens that shapes how you approach the problem. Call this when the user describes their domain, function, or goals.",
        "input_schema": {
            "type": "object",
            "properties": {
                "domain": {"type": "string", "description": "Subject matter (e.g. saas_sales, pharma)"},
                "function": {"type": "string", "description": "Analytical function (e.g. territory_planning)"},
                "role": {"type": "string", "description": "User role (e.g. analyst, manager)"},
                "objectives": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Measurable goals",
                },
            },
            "required": ["domain"],
        },
    },
    {
        "name": "list_files",
        "description": "List files in a directory. Returns file names and sizes.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory path (default: current dir)"},
                "pattern": {"type": "string", "description": "Glob pattern (default: *)"},
            },
            "required": [],
        },
    },
    {
        "name": "dispatch_cli",
        "description": (
            "Run a carl CLI subcommand (e.g. 'doctor', 'train', 'eval'). "
            "Only commands registered in the ops registry are allowed. "
            "Returns stdout/stderr + exit code."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Top-level ops name (doctor, train, eval, ...)",
                },
                "args": {
                    "type": "array",
                    "items": {"type": "string"},
                    "default": [],
                },
                "timeout_s": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 600,
                    "default": 60,
                },
            },
            "required": ["command"],
        },
    },
]


# ---------------------------------------------------------------------------
# Event model
# ---------------------------------------------------------------------------


class AgentEvent(BaseModel):
    """Event emitted by the agent loop for the caller to render.

    ``code`` carries a stable programmatic tag (e.g. ``carl.stream_error``,
    ``carl.budget``) for error events and empty for everything else.
    """

    kind: str  # "text", "tool_call", "tool_result", "done", "error"
    content: str = ""
    tool_name: str = ""
    tool_args: dict[str, Any] = Field(default_factory=dict)
    code: str = ""


# ---------------------------------------------------------------------------
# Arg schema validation
# ---------------------------------------------------------------------------


def _validate_tool_args(
    tool_name: str,
    tool_args: dict[str, Any],
) -> str | None:
    """Return None if args look valid; else a human-readable error string.

    Uses jsonschema when available for a thorough check. Falls back to a
    manual required-fields-and-type check when jsonschema is not installed.
    """
    schema = None
    for tool in TOOLS:
        if tool.get("name") == tool_name:
            schema = tool.get("input_schema")
            break
    if schema is None:
        return None  # unknown tool falls through to the dispatch fallback

    try:
        import jsonschema  # type: ignore[import-untyped]
    except ImportError:
        logger.debug("jsonschema not available; using manual validation for %s", tool_name)
        return _manual_schema_check(tool_name, schema, tool_args)

    try:
        jsonschema.validate(instance=tool_args, schema=schema)
    except jsonschema.ValidationError as exc:
        # Path points to the offending field; keep the message model-friendly.
        field_path = ".".join(str(p) for p in exc.absolute_path) or "<root>"
        return (
            f"Invalid arguments for '{tool_name}': at '{field_path}': {exc.message}. "
            f"Re-send with corrected arguments."
        )
    except Exception as exc:  # pragma: no cover — defensive
        return f"Schema validation error for '{tool_name}': {exc}"
    return None


def _manual_schema_check(
    tool_name: str,
    schema: dict[str, Any],
    tool_args: dict[str, Any],
) -> str | None:
    """Minimal required-field + type validation when jsonschema is unavailable."""
    if not isinstance(tool_args, dict):
        return f"Invalid arguments for '{tool_name}': expected object, got {type(tool_args).__name__}."

    required = schema.get("required", []) or []
    missing = [f for f in required if f not in tool_args]
    if missing:
        return (
            f"Invalid arguments for '{tool_name}': missing required fields "
            f"{missing}. Re-send with all required fields."
        )

    properties: dict[str, Any] = schema.get("properties") or {}
    type_map: dict[str, tuple[type, ...]] = {
        "string": (str,),
        "integer": (int,),
        "number": (int, float),
        "boolean": (bool,),
        "array": (list, tuple),
        "object": (dict,),
    }
    bad: list[str] = []
    for fname, spec in properties.items():
        if fname not in tool_args:
            continue
        expected = spec.get("type") if isinstance(spec, dict) else None
        if expected is None:
            continue
        allowed = type_map.get(expected)
        if allowed is None:
            continue
        value = tool_args[fname]
        # bool is a subclass of int — keep the distinction.
        if expected == "integer" and isinstance(value, bool):
            bad.append(f"{fname}: expected integer, got boolean")
        elif expected == "boolean" and not isinstance(value, bool):
            bad.append(f"{fname}: expected boolean, got {type(value).__name__}")
        elif not isinstance(value, allowed):
            bad.append(f"{fname}: expected {expected}, got {type(value).__name__}")
    if bad:
        return (
            f"Invalid arguments for '{tool_name}': "
            + "; ".join(bad)
            + ". Re-send with corrected types."
        )
    return None


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


class CARLAgent:
    """Agentic chat loop with tool use, frame awareness, and proactive guidance.

    Features beyond raw API relay:
      - **Session persistence**: save/resume via SessionStore
      - **Permission hooks**: pre_tool_use callback can deny tool calls
      - **Cost tracking**: per-turn cost from response.usage, max_budget_usd cap
      - **Streaming resilience**: partial state preserved on mid-stream errors
      - **Tool timeouts**: per-tool deadlines; hook exceptions never kill loop
      - **Arg validation**: malformed tool args become typed error results
      - **Knowledge bound**: LRU cap on the in-memory knowledge list
      - **DENY terminal**: all-tools-denied turns fail fast after a few rounds
    """

    # Class defaults — overridable via constructor kwargs. The canonical
    # values live on the extracted collaborators (``knowledge_store`` and
    # ``tool_dispatcher``); these class attributes are kept because legacy
    # tests read ``CARLAgent._KNOWLEDGE_MAX_CHUNKS`` / ``_MAX_CONSECUTIVE_ALL_DENIED``
    # as class-level constants.
    _KNOWLEDGE_MAX_CHUNKS: int = _KNOWLEDGE_MAX_CHUNKS
    _MAX_CONSECUTIVE_ALL_DENIED: int = _TD_MAX_CONSECUTIVE_ALL_DENIED

    def __init__(
        self,
        api_key: str = "",
        model: str = "",
        frame: Any | None = None,
        workdir: str = ".",
        *,
        max_budget_usd: float = 0.0,
        pre_tool_use: PreToolHook | None = None,
        post_tool_use: PostToolHook | None = None,
        session_id: str = "",
        memory_store: MemoryStore | None = None,
        constitution: Constitution | None = None,
        max_knowledge_chunks: int | None = None,
        _client: Any | None = None,
    ) -> None:
        # -- Resolve model from settings when not explicitly passed ----------
        if not model:
            try:
                from carl_studio.settings import CARLSettings

                settings = CARLSettings.load()
                model = settings.default_chat_model or "claude-sonnet-4-6"
            except Exception:
                model = "claude-sonnet-4-6"

        # -- Resolve api_key from settings when not explicitly passed --------
        api_key_source = "default"
        if api_key:
            api_key_source = "explicit"
        elif _client is None:
            try:
                from carl_studio.settings import CARLSettings

                settings = CARLSettings.load()
                resolved_key = settings.anthropic_api_key or ""
                if resolved_key:
                    api_key = resolved_key
                    api_key_source = "settings"
            except Exception:
                pass

        if _client is not None:
            self._client = _client
            api_key_source = "injected"
        else:
            try:
                import anthropic
            except ImportError as exc:
                raise ImportError(
                    "Anthropic SDK required: pip install carl-studio[observe]"
                ) from exc
            # J2 — rate-limit retry. ``max_retries=4`` covers 429, 503,
            # and connection errors; the SDK applies exponential backoff
            # between attempts. The ``httpx.Timeout`` caps total wall-clock
            # at 60s with a 10s connect budget so a single wedged TCP
            # handshake can't block the agent indefinitely.
            try:
                import httpx

                self._client = anthropic.Anthropic(
                    api_key=api_key or None,
                    max_retries=4,
                    timeout=httpx.Timeout(60.0, connect=10.0),
                )
            except ImportError:  # pragma: no cover — httpx ships with anthropic
                # Fallback: if httpx is somehow absent, still get the retry
                # behaviour but accept the SDK default timeout.
                self._client = anthropic.Anthropic(
                    api_key=api_key or None,
                    max_retries=4,
                )
        self._model = model
        self._api_key_source = api_key_source
        self._frame = frame
        self._workdir = str(Path(workdir).resolve())
        # Composed collaborators (Phase-1 extraction — see agent_state.py).
        # Message history + turn counter + session theme live on SessionState.
        # Cost / token accumulation lives on CostLedger. Legacy attribute
        # access (``self._messages`` / ``self._turn_count`` / ``self._total_*``)
        # is preserved via ``@property`` shims further down in this class.
        self._session = SessionState()
        self._cost = CostLedger()
        self._token_count = 0

        # Knowledge chunk cap — overridable per-instance, falls back to class.
        # Validation must precede store construction so a bad value raises
        # cleanly instead of poisoning the store.
        if max_knowledge_chunks is not None:
            if max_knowledge_chunks < 1:
                raise ValueError(
                    "max_knowledge_chunks must be >= 1 when provided",
                )
            resolved_cap = int(max_knowledge_chunks)
        else:
            resolved_cap = int(self._KNOWLEDGE_MAX_CHUNKS)
        # Composed collaborator: owns the bounded knowledge list, the LRU
        # eviction policy, and the single-warning-per-session guard. Legacy
        # access via ``self._knowledge`` / ``self._max_knowledge_chunks`` /
        # ``self._knowledge_evicted_warned`` / ``self._enforce_knowledge_cap``
        # is preserved via ``@property`` shims further down in this class.
        self._knowledge_store = KnowledgeStore(max_chunks=resolved_cap)

        # Composed collaborator: tool registry + timeouts + dispatch loop
        # + terminal-denial counter. The ``_tool_*`` methods below bind
        # themselves into the registry so the dispatcher stays agnostic
        # of domain-specific behavior. Legacy ``self._dispatch_tool`` /
        # ``self._dispatch_tool_safe`` / ``self._consecutive_all_denied``
        # are preserved via ``@property`` shims.
        # ``timeout_resolver`` reads the module-level ``_TOOL_TIMEOUTS_S``
        # at dispatch time so tests that monkeypatch the constant AFTER
        # agent construction see their value flow through to the live
        # dispatcher without rebuilding it. The resolver falls back to
        # the module's ``_DEFAULT_TOOL_TIMEOUT_S`` for unregistered tools.
        self._dispatcher = ToolDispatcher(
            default_timeout_s=_DEFAULT_TOOL_TIMEOUT_S,
            max_consecutive_all_denied=int(self._MAX_CONSECUTIVE_ALL_DENIED),
            timeout_resolver=lambda name: _TOOL_TIMEOUTS_S.get(
                name, _DEFAULT_TOOL_TIMEOUT_S,
            ),
        )
        self._register_tools(self._dispatcher)

        # Surfaced by load_session when the underlying file was corrupt and
        # was rolled into the quarantine directory. Callers (CLI) read this
        # flag to print a visible warning instead of silently starting fresh.
        self._last_load_quarantined: bool = False

        # Cost tracking — budget cap lives here; totals on self._cost.
        self._max_budget_usd = max_budget_usd  # 0 = unlimited

        # Permission hooks
        self._pre_tool_use = pre_tool_use
        self._post_tool_use = post_tool_use

        # One-shot system prompt extension — consumed on the next
        # ``_build_system_prompt()`` call. Set by CLI bootstrap (intro JIT
        # context) and any caller that wants to inject a turn-scoped
        # primer without persistently mutating the base prompt.
        self._system_prompt_extension: str = ""

        # Session theme persists via ``SessionState.session_theme``. Default
        # ``""`` means "not yet classified"; CLI sets on the first bootstrap
        # turn, programmatic callers can set it explicitly.

        # Session
        self._session_id = session_id

        # Interaction chain — lazily constructed by dispatch_cli.
        self._chain: Any | None = None

        # Tier — resolved lazily from settings; FREE by default for safety.
        # Use a distinct sentinel so a failed resolution doesn't re-run each call.
        self._tier: Any | None = None
        self._tier_resolved: bool = False

        # Project context (cached at construction)
        self._project_line = ""
        try:
            from carl_studio.project import load_project

            proj = load_project("carl.yaml")
            self._project_line = f"PROJECT: {proj.name} | Model: {proj.base_model} | Method: {proj.method}"
        except Exception:
            pass

        # -- Constitution (CRYSTAL layer) --------------------------------
        # Attempt to resolve a Constitution instance. If the caller passed
        # one, trust it verbatim; otherwise try the default loader. Failures
        # must never break agent construction — the agent degrades to the
        # legacy behaviour (no constitutional rules injected).
        self._constitution: Constitution | None = constitution
        if self._constitution is None:
            try:
                from carl_studio.constitution import Constitution as _Constitution

                self._constitution = _Constitution.load()
            except Exception as exc:
                logger.debug("Constitution.load() failed; continuing without: %s", exc)
                self._constitution = None

        # Compiled system-prompt block — cached per-instance so a noisy
        # large ruleset doesn't re-serialize on every turn.
        self._constitution_prompt: str | None = None

        # -- Memory store (WORKING + LONG + SHORT/CRYSTAL) ---------------
        self._memory: MemoryStore | None = memory_store
        if self._memory is None:
            try:
                from carl_core.memory import MemoryStore as _MemoryStore

                self._memory = _MemoryStore(Path.home() / ".carl" / "memory")
            except Exception as exc:
                logger.debug("MemoryStore bootstrap failed; continuing without: %s", exc)
                self._memory = None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_chain(self) -> Any:
        """Return the InteractionChain for this agent session, creating if needed."""
        if self._chain is not None:
            return self._chain
        try:
            from carl_core.interaction import InteractionChain

            self._chain = InteractionChain()
        except Exception:  # pragma: no cover — optional
            self._chain = None
        return self._chain

    def _record_tool_call(
        self,
        *,
        name: str,
        tool_input: dict[str, Any],
        output: Any,
        success: bool,
        duration_ms: float,
        outcome: str,
    ) -> None:
        """Emit an ``ActionType.TOOL_CALL`` step on the active InteractionChain.

        v0.10 witness-completeness fix. Covers allowed, denied, schema-error,
        and error outcomes so every tool-use turn is represented in the chain.
        Fire-and-forget: any failure to record is swallowed (the loop must
        never die because of an observability path).
        """
        chain = self._get_chain()
        if chain is None:
            return
        try:
            from carl_core.interaction import ActionType

            chain.record(
                ActionType.TOOL_CALL,
                f"agent.chat:tool:{name}",
                input={"tool_name": name, "args": tool_input},
                output={"outcome": outcome, "result": output},
                success=success,
                duration_ms=duration_ms,
            )
        except Exception as exc:  # pragma: no cover — observability-only
            logger.debug("chain.record TOOL_CALL failed: %s", exc)

    def _resolve_tier(self) -> Any:
        """Resolve effective tier once, cached on the instance."""
        if self._tier_resolved:
            return self._tier
        try:
            from carl_core.tier import Tier

            try:
                from carl_studio.tier import detect_effective_tier
                from carl_studio.settings import CARLSettings

                settings = CARLSettings.load()
                configured = getattr(settings, "tier", None)
                if isinstance(configured, Tier):
                    self._tier = detect_effective_tier(configured)
                elif isinstance(configured, str):
                    try:
                        self._tier = detect_effective_tier(Tier(configured))
                    except Exception:
                        self._tier = Tier.FREE
                else:
                    self._tier = Tier.FREE
            except Exception:
                self._tier = Tier.FREE
        except Exception:
            self._tier = None
        self._tier_resolved = True
        return self._tier

    @property
    def provider_info(self) -> dict[str, str]:
        """Return provider resolution info for display."""
        return {
            "model": self._model,
            "provider": "anthropic",
            "api_key_source": self._api_key_source,
        }

    # ------------------------------------------------------------------
    # Backward-compat shims — legacy tests + downstream code reach into
    # these private attributes directly. They now delegate to the composed
    # SessionState / CostLedger collaborators. Setters keep test snippets
    # like ``agent._turn_count = 7`` and ``agent._messages = [...]`` working
    # without churn. In-place list mutation (``agent._messages.append(...)``)
    # works via the getter because it returns the underlying list.
    # ------------------------------------------------------------------

    @property
    def _messages(self) -> list[dict[str, Any]]:
        return self._session.messages

    @_messages.setter
    def _messages(self, value: list[dict[str, Any]]) -> None:
        self._session.messages = list(value)

    @property
    def _turn_count(self) -> int:
        return self._session.turn_count

    @_turn_count.setter
    def _turn_count(self, value: int) -> None:
        self._session.turn_count = int(value)

    @property
    def _session_theme(self) -> str:
        return self._session.session_theme

    @_session_theme.setter
    def _session_theme(self, value: str) -> None:
        self._session.session_theme = str(value or "")

    @property
    def _total_cost_usd(self) -> float:
        return self._cost.total_cost_usd

    @_total_cost_usd.setter
    def _total_cost_usd(self, value: float) -> None:
        self._cost.total_cost_usd = float(value)

    @property
    def _total_input_tokens(self) -> int:
        return self._cost.total_input_tokens

    @_total_input_tokens.setter
    def _total_input_tokens(self, value: int) -> None:
        self._cost.total_input_tokens = int(value)

    @property
    def _total_output_tokens(self) -> int:
        return self._cost.total_output_tokens

    @_total_output_tokens.setter
    def _total_output_tokens(self, value: int) -> None:
        self._cost.total_output_tokens = int(value)

    # -- KnowledgeStore shims ------------------------------------------
    # Tests (``tests/test_chat_agent_robustness.py``, ``tests/test_agent.py``,
    # ``tests/test_uat_e2e.py``) mutate ``_knowledge`` in place via append
    # and by wholesale assignment. Returning the backing list from the
    # getter preserves the in-place path; the setter replaces the store's
    # ``chunks`` list so ``agent._knowledge = [...]`` still routes through
    # the collaborator.

    @property
    def _knowledge(self) -> list[dict[str, Any]]:
        return self._knowledge_store.chunks

    @_knowledge.setter
    def _knowledge(self, value: list[dict[str, Any]]) -> None:
        self._knowledge_store.chunks = list(value)

    @property
    def _max_knowledge_chunks(self) -> int:
        return self._knowledge_store.max_chunks

    @_max_knowledge_chunks.setter
    def _max_knowledge_chunks(self, value: int) -> None:
        self._knowledge_store.max_chunks = int(value)

    @property
    def _knowledge_evicted_warned(self) -> bool:
        return self._knowledge_store.evicted_warned

    @_knowledge_evicted_warned.setter
    def _knowledge_evicted_warned(self, value: bool) -> None:
        self._knowledge_store.evicted_warned = bool(value)

    # -- ToolDispatcher shims ------------------------------------------
    # ``_dispatch_tool`` / ``_dispatch_tool_safe`` delegate to the
    # collaborator. ``_consecutive_all_denied`` mirrors the counter so
    # tests that set it directly (``agent._consecutive_all_denied = 3``)
    # keep working.

    def _dispatch_tool(self, name: str, args: dict[str, Any]) -> str:
        """Public dispatch (back-compat). Returns only the content string."""
        return self._dispatcher.dispatch(name, args)

    def _dispatch_tool_safe(
        self, name: str, args: dict[str, Any],
    ) -> tuple[str, bool]:
        """Dispatch with timeout + error handling. Returns ``(content, is_error)``."""
        return self._dispatcher.dispatch_safe(name, args)

    @property
    def _consecutive_all_denied(self) -> int:
        return self._dispatcher.consecutive_all_denied

    @_consecutive_all_denied.setter
    def _consecutive_all_denied(self, value: int) -> None:
        self._dispatcher.consecutive_all_denied = int(value)

    # ------------------------------------------------------------------
    # Chat loop
    # ------------------------------------------------------------------

    def chat(self, user_input: str) -> Iterator[AgentEvent]:
        """Send message, handle tool calls, yield events.

        Uses streaming to prevent HTTP timeouts on long responses.
        Yields text_delta events for real-time token display.

        Resilience contract:
          * Streaming exceptions never propagate out — the generator always
            completes. Mid-stream errors yield an ``error`` event with a
            stable ``code`` attribute (e.g. ``carl.stream_error``), attribute
            partial cost for consumed tokens, and persist emitted text so
            session save captures what the user saw.
          * A budget pre-check runs before every API call. When the upper-bound
            estimate would push total cost above ``max_budget_usd``, a
            ``BudgetError`` event is yielded and the API is not called.
          * Hook exceptions (pre/post tool use) yield a ``carl.hook_failed``
            error event and the loop continues.
        """
        # Memory recall — prepend relevant past learnings to the user turn,
        # and emit MEMORY_READ steps into the InteractionChain. Recall is
        # best-effort: any failure leaves the original prompt unchanged.
        recalled_items = self._recall_memories(user_input)
        augmented_input = self._augment_prompt_with_recall(user_input, recalled_items)

        # Auto-remember strong signals ("always", "never", "remember", "note:")
        # BEFORE the API call so the new SHORT memory is visible to the next
        # recall pass — this is the crystallize-in-place pattern.
        self._maybe_auto_remember(user_input)

        self._session.append_message({"role": "user", "content": augmented_input})
        self._session.increment_turn()

        while True:
            # ------- Budget pre-check (upper-bound ceiling) -----------------
            if self._max_budget_usd > 0:
                est = _estimate_turn_upper_bound_cost(
                    self._model, _BUDGET_PRECHECK_MAX_OUTPUT_TOKENS,
                )
                current_cost = self._cost.total_cost_usd
                projected = current_cost + est
                if projected > self._max_budget_usd:
                    msg = (
                        f"Budget pre-check blocked turn: projected "
                        f"${projected:.4f} (current ${current_cost:.4f} + "
                        f"estimated ${est:.4f}) exceeds cap ${self._max_budget_usd:.4f}"
                    )
                    code = "carl.budget"
                    # Best-effort carl_core.errors.BudgetError marker in logs.
                    try:
                        from carl_core.errors import BudgetError

                        logger.warning(
                            "BudgetError: %s",
                            BudgetError(msg, context={
                                "current": current_cost,
                                "estimated": est,
                                "cap": self._max_budget_usd,
                            }),
                        )
                    except Exception:  # pragma: no cover — carl_core optional
                        pass
                    yield AgentEvent(kind="error", content=msg, code=code)
                    return
                if current_cost >= self._max_budget_usd:
                    # Hard floor — we already spent the whole budget.
                    yield AgentEvent(
                        kind="error",
                        content=(
                            f"Budget exceeded: ${current_cost:.4f} "
                            f">= ${self._max_budget_usd:.2f}"
                        ),
                        code="carl.budget",
                    )
                    return

            system = self._build_system_prompt()

            response: Any = None
            partial_text_parts: list[str] = []
            stream: Any = None
            try:
                kwargs: dict[str, Any] = {
                    "model": self._model,
                    "max_tokens": _BUDGET_PRECHECK_MAX_OUTPUT_TOKENS,
                    "system": system,
                    "messages": self._messages,
                    "tools": TOOLS,
                    "cache_control": {"type": "ephemeral"},
                }
                if any(fam in self._model for fam in ("opus-4-6", "sonnet-4-6")):
                    kwargs["thinking"] = {"type": "adaptive"}

                try:
                    stream_cm = self._client.messages.stream(**kwargs)
                except Exception as exc:
                    # J2 — rate-limit is a distinct, retriable failure mode
                    # with a stable ``carl.rate_limit`` code so CLI/UI can
                    # present a tailored message instead of a generic API
                    # error. The Anthropic SDK's own ``max_retries=4`` has
                    # already been exhausted by the time this lands here,
                    # so it's a *persistent* 429 — the caller should back
                    # off on the outer loop rather than retry immediately.
                    try:
                        import anthropic as _anthropic
                        is_rate_limit = isinstance(exc, _anthropic.RateLimitError)
                    except Exception:  # pragma: no cover — SDK absent
                        is_rate_limit = False
                    if is_rate_limit:
                        yield AgentEvent(
                            kind="error",
                            content=(
                                f"rate limited — backoff exhausted after "
                                f"retries: {exc}"
                            ),
                            code="carl.rate_limit",
                        )
                        return
                    # API call could not even be issued (other failure).
                    yield AgentEvent(
                        kind="error",
                        content=f"API error: {exc}",
                        code="carl.api_error",
                    )
                    return

                with stream_cm as stream:
                    try:
                        for event in stream:
                            if event.type == "content_block_delta":
                                if event.delta.type == "text_delta":
                                    partial_text_parts.append(event.delta.text)
                                    yield AgentEvent(
                                        kind="text_delta",
                                        content=event.delta.text,
                                    )
                    except (KeyboardInterrupt, BaseException) as exc:
                        # Baseexception catches KeyboardInterrupt/SystemExit.
                        # We still want to best-effort finalize + persist state.
                        code = (
                            "carl.interrupted"
                            if isinstance(exc, KeyboardInterrupt)
                            else "carl.stream_error"
                        )
                        response = self._safe_finalize_stream(stream)
                        self._attribute_partial_cost(response, partial_text_parts)
                        self._persist_partial_turn(response, partial_text_parts)
                        yield AgentEvent(
                            kind="error",
                            content=f"Stream interrupted: {exc}",
                            code=code,
                        )
                        return

                    # Clean exit — collect the final message.
                    try:
                        response = stream.get_final_message()
                    except Exception as exc:
                        self._attribute_partial_cost(None, partial_text_parts)
                        self._persist_partial_turn(None, partial_text_parts)
                        yield AgentEvent(
                            kind="error",
                            content=f"Failed to finalize stream: {exc}",
                            code="carl.stream_error",
                        )
                        return
            except BaseException as exc:
                # Catchall for exceptions while entering/exiting the ctx-mgr.
                try:
                    response = self._safe_finalize_stream(stream)
                except Exception:
                    response = None
                self._attribute_partial_cost(response, partial_text_parts)
                self._persist_partial_turn(response, partial_text_parts)
                # J2 — surface RateLimitError that escaped the inner
                # ``stream(**kwargs)`` try-block (e.g. raised during
                # context-manager entry) with the stable rate-limit code.
                is_rate_limit = False
                try:
                    import anthropic as _anthropic
                    is_rate_limit = isinstance(exc, _anthropic.RateLimitError)
                except Exception:  # pragma: no cover — SDK absent
                    pass
                if is_rate_limit:
                    code = "carl.rate_limit"
                    content = (
                        f"rate limited — backoff exhausted after retries: {exc}"
                    )
                else:
                    code = (
                        "carl.interrupted"
                        if isinstance(exc, KeyboardInterrupt)
                        else "carl.stream_error"
                    )
                    content = f"Stream error: {exc}"
                yield AgentEvent(
                    kind="error",
                    content=content,
                    code=code,
                )
                return

            # Track cost (full accounting path on clean turns).
            usage = getattr(response, "usage", None)
            if usage is not None:
                turn_cost = _compute_turn_cost(usage, self._model)
                self._cost.add_turn(
                    turn_cost,
                    getattr(usage, "input_tokens", 0) or 0,
                    getattr(usage, "output_tokens", 0) or 0,
                )

            self._token_count = (
                getattr(usage, "input_tokens", self._token_count)
                if usage else self._token_count
            )

            # Context pressure
            if self._token_count > _COMPACT_THRESHOLD:
                self._compact()

            # pause_turn: server-side tool iteration limit
            if getattr(response, "stop_reason", None) == "pause_turn":
                self._session.messages = [
                    {"role": "user", "content": user_input},
                    {"role": "assistant", "content": self._content_to_dicts(response.content)},
                ]
                continue

            # Collect blocks
            assistant_content: list[dict[str, Any]] = []
            tool_use_blocks: list[Any] = []

            for block in getattr(response, "content", []) or []:
                btype = getattr(block, "type", None)
                if btype == "text":
                    assistant_content.append({"type": "text", "text": block.text})
                elif btype == "thinking":
                    pass
                elif btype == "tool_use":
                    tool_input: dict[str, Any] = block.input if isinstance(block.input, dict) else {}
                    assistant_content.append({
                        "type": "tool_use",
                        "id": block.id,
                        "name": block.name,
                        "input": block.input,
                    })
                    tool_use_blocks.append(block)
                    yield AgentEvent(
                        kind="tool_call",
                        tool_name=block.name,
                        tool_args=tool_input,
                    )

            if not tool_use_blocks:
                self._session.append_message({"role": "assistant", "content": assistant_content})
                # A turn that made no tool calls resets the all-denied counter:
                # the model exited the reflexive retry loop on its own.
                self._consecutive_all_denied = 0
                yield AgentEvent(kind="done", content=f"${self._cost.total_cost_usd:.4f}")
                return

            # Execute ALL tool calls with permission hooks
            self._session.append_message({"role": "assistant", "content": assistant_content})

            tool_results: list[dict[str, Any]] = []
            # Track whether this turn's tool calls were all denied. When 100%
            # of tool_use blocks hit DENY for enough turns in a row, terminate
            # so a misbehaving model + restrictive policy cannot loop forever.
            turn_denied = 0
            turn_attempted = 0
            # v0.15 — the per-block lifecycle (pre-hook → validate → dispatch
            # → post-hook) now lives on ToolDispatcher.execute_block.
            # This loop body shrinks to: delegate, yield events, record on
            # chain, update counters. All outcome semantics unchanged;
            # events still arrive in the same order as pre-v0.15 so any
            # test inspecting the AgentEvent stream is unaffected.
            for block in tool_use_blocks:
                tool_input = block.input if isinstance(block.input, dict) else {}
                turn_attempted += 1

                outcome, events = self._dispatcher.execute_block(
                    tool_name=block.name,
                    tool_input=tool_input,
                    tool_use_id=block.id,
                    pre_hook=self._pre_tool_use,
                    post_hook=self._post_tool_use,
                    validator=_validate_tool_args,
                )

                for ev in events:
                    yield AgentEvent(
                        kind=ev.kind,
                        tool_name=ev.name,
                        content=ev.content,
                        code=ev.code or "",
                    )

                tool_result_entry: dict[str, Any] = {
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": outcome.result,
                }
                if outcome.is_error:
                    tool_result_entry["is_error"] = True
                tool_results.append(tool_result_entry)

                self._record_tool_call(
                    name=block.name,
                    tool_input=tool_input,
                    output=outcome.result,
                    success=(not outcome.is_error),
                    duration_ms=outcome.duration_ms,
                    outcome=outcome.outcome,
                )

                if outcome.outcome == "denied":
                    turn_denied += 1

            self._session.append_message({"role": "user", "content": tool_results})

            # ------- Terminal all-denied guard ------------------------------
            # When every tool in this turn was blocked by the permission hook,
            # bump the counter. Any allowed tool resets it. After N consecutive
            # all-denied turns, terminate with a typed error so a misbehaving
            # model + restrictive hook cannot retry forever.
            if turn_attempted > 0 and turn_denied == turn_attempted:
                self._consecutive_all_denied += 1
            elif turn_attempted > 0:
                self._consecutive_all_denied = 0

            if self._consecutive_all_denied >= self._MAX_CONSECUTIVE_ALL_DENIED:
                msg = (
                    f"Terminating: permission policy denied every tool call "
                    f"for {self._consecutive_all_denied} consecutive turns. "
                    f"The model cannot make progress under the current hook."
                )
                try:
                    from carl_core.errors import CARLError

                    logger.warning(
                        "all_tools_denied: %s",
                        CARLError(msg, code="carl.all_tools_denied", context={
                            "consecutive_turns": self._consecutive_all_denied,
                            "limit": self._MAX_CONSECUTIVE_ALL_DENIED,
                        }),
                    )
                except Exception:  # pragma: no cover — carl_core optional
                    pass

                # Record an InteractionChain step so the session trace shows
                # the termination even when no downstream observer listens.
                chain = self._get_chain()
                if chain is not None:
                    try:
                        from carl_core.interaction import ActionType

                        chain.record(
                            ActionType.CLI_CMD,
                            "agent.chat:all_tools_denied",
                            input={
                                "consecutive_turns": self._consecutive_all_denied,
                                "limit": self._MAX_CONSECUTIVE_ALL_DENIED,
                            },
                            output={"terminated": True},
                            success=False,
                        )
                    except Exception:
                        pass

                yield AgentEvent(
                    kind="error",
                    content=msg,
                    code="carl.all_tools_denied",
                )
                return

            if getattr(response, "stop_reason", None) == "end_turn":
                yield AgentEvent(kind="done", content=f"${self._cost.total_cost_usd:.4f}")
                return

    # ------------------------------------------------------------------
    # Memory: recall, remember, auto-remember, suggest_learnings
    # ------------------------------------------------------------------

    def _recall_memories(self, prompt: str) -> list[MemoryItem]:
        """Return recalled WORKING+LONG memory items or []; never raises.

        Emits a MEMORY_READ step into the InteractionChain for each item
        surfaced. Items below ``_MEMORY_RECALL_MIN_SCORE`` are dropped by the
        MemoryStore before they reach us.
        """
        if self._memory is None:
            return []
        try:
            from carl_core.memory import MemoryLayer as _MemoryLayer

            recalled = self._memory.recall(
                prompt,
                layers={_MemoryLayer.WORKING, _MemoryLayer.LONG},
                top_k=_MEMORY_RECALL_TOP_K,
                min_score=_MEMORY_RECALL_MIN_SCORE,
            )
        except Exception as exc:
            logger.debug("memory.recall failed: %s", exc)
            return []

        if not recalled:
            return []

        # Emit MEMORY_READ steps — failure to record must not kill the turn.
        chain = self._get_chain()
        if chain is not None:
            try:
                from carl_core.interaction import ActionType

                for item in recalled:
                    chain.record(
                        ActionType.MEMORY_READ,
                        name=item.id,
                        input=prompt,
                        output=item.content[:_MEMORY_ITEM_OUTPUT_CAP],
                    )
            except Exception as exc:
                logger.debug("chain.record MEMORY_READ failed: %s", exc)
        return recalled

    @staticmethod
    def _augment_prompt_with_recall(
        prompt: str, recalled: list[MemoryItem],
    ) -> str:
        """Prepend a visible recall block to the user's turn, or passthrough."""
        if not recalled:
            return prompt
        note_lines = ["# Recalled context (from past sessions):"]
        for item in recalled:
            preview = item.content[:_MEMORY_CONTENT_PREVIEW]
            note_lines.append(f"- [{item.id}] {preview}")
        note = "\n".join(note_lines)
        return f"{note}\n\n---\n\n{prompt}"

    def remember(
        self,
        content: str,
        *,
        layer: MemoryLayer | None = None,
        tags: set[str] | None = None,
    ) -> MemoryItem | None:
        """Write ``content`` to memory and record a MEMORY_WRITE step.

        ``layer`` defaults to ``MemoryLayer.SHORT`` when None. Returns the
        freshly written ``MemoryItem`` or ``None`` when the store is absent.
        """
        if self._memory is None:
            return None
        try:
            from carl_core.memory import MemoryLayer as _MemoryLayer
        except Exception as exc:
            logger.debug("memory import failed in remember(): %s", exc)
            return None

        target_layer = layer if layer is not None else _MemoryLayer.SHORT
        try:
            item = self._memory.write(
                content, layer=target_layer, tags=tags or set(),
            )
        except Exception as exc:
            logger.warning("memory.write failed: %s", exc)
            return None

        chain = self._get_chain()
        if chain is not None:
            try:
                from carl_core.interaction import ActionType

                chain.record(
                    ActionType.MEMORY_WRITE,
                    name=item.id,
                    input={"layer": target_layer.name, "tags": sorted(tags or set())},
                    output=content[:_MEMORY_ITEM_OUTPUT_CAP],
                )
            except Exception as exc:
                logger.debug("chain.record MEMORY_WRITE failed: %s", exc)
        return item

    def _maybe_auto_remember(self, user_input: str) -> None:
        """If the user's utterance contains a learn-signal, persist it.

        Looks for: ``remember``, ``note:``, ``always``, ``never``. Tags come
        from the active frame's domain/function/role so recall surfaces them
        under relevant topics.
        """
        if self._memory is None:
            return
        if not any(pat.search(user_input) for pat in _AUTO_REMEMBER_PATTERNS):
            return
        tags = self._derive_topics_from_frame()
        tags.add("auto_remember")
        self.remember(user_input, tags=tags)

    def suggest_learnings(self) -> list[ConstitutionalRule]:
        """Ask the agent to propose 1-3 durable rules from recent turns.

        Zero-tool sub-invocation. Reuses the same model with a reduced
        output budget. Returns [] on malformed output so callers can always
        treat the result as a list.
        """
        try:
            from carl_studio.constitution import ConstitutionalRule
        except Exception as exc:
            logger.debug("ConstitutionalRule import failed: %s", exc)
            return []

        # Gather the last few user+assistant exchanges as a digest. Tool
        # results and auto-injected recall blocks are de-emphasized.
        digest = self._recent_turns_digest(max_turns=6)
        if not digest:
            return []

        suggest_prompt = (
            "Review the recent conversation turns below. Propose 1-3 durable "
            "rules to codify as learnings for future sessions. Respond with "
            "ONLY a JSON array. Each element must be an object with keys: "
            "id (dot-separated string), text (natural-language rule), "
            "priority (integer 0-100), tags (array of strings).\n\n"
            f"Recent turns:\n{digest}"
        )

        raw_json = self._one_shot_text(
            suggest_prompt, max_tokens=1024,
        )
        if not raw_json:
            return []

        return self._parse_learnings_json(raw_json, ConstitutionalRule)

    def _recent_turns_digest(self, *, max_turns: int) -> str:
        """Compact textual digest of the last ``max_turns`` messages."""
        messages = self._session.messages
        if not messages:
            return ""
        window = messages[-max_turns:]
        lines: list[str] = []
        for msg in window:
            role = str(msg.get("role", "?"))
            content = msg.get("content", "")
            if isinstance(content, list):
                bits: list[str] = []
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    if block.get("type") == "text":
                        bits.append(str(block.get("text", "")))
                    elif block.get("type") == "tool_use":
                        bits.append(f"[tool_use:{block.get('name','?')}]")
                text = " ".join(b for b in bits if b).strip()
            else:
                text = str(content).strip()
            if text:
                lines.append(f"{role}: {text[:500]}")
        return "\n".join(lines)

    def _one_shot_text(self, prompt: str, *, max_tokens: int) -> str:
        """Zero-tool synchronous call — returns the assistant text or ""."""
        try:
            kwargs: dict[str, Any] = {
                "model": self._model,
                "max_tokens": max(1, int(max_tokens)),
                "messages": [{"role": "user", "content": prompt}],
            }
            response = self._client.messages.create(**kwargs)
        except Exception as exc:
            logger.debug("one-shot suggest_learnings call failed: %s", exc)
            return ""

        # Attribute cost/tokens so auxiliary calls (suggest_learnings etc.)
        # count against the budget guard. Without this, the max_budget_usd
        # cap is bypassable via any non-streaming path that invokes
        # _one_shot_text.
        usage = getattr(response, "usage", None)
        if usage is not None:
            try:
                self._cost.add_turn(
                    _compute_turn_cost(usage, self._model),
                    getattr(usage, "input_tokens", 0) or 0,
                    getattr(usage, "output_tokens", 0) or 0,
                )
            except Exception as exc:
                logger.debug("one-shot cost attribution failed: %s", exc)

        # Best-effort text extraction across SDK shapes.
        content = getattr(response, "content", None) or []
        texts: list[str] = []
        for block in content:
            btype = getattr(block, "type", None)
            if btype == "text":
                text_val = getattr(block, "text", "") or ""
                if text_val:
                    texts.append(str(text_val))
            elif isinstance(block, dict) and block.get("type") == "text":
                texts.append(str(block.get("text", "")))
        return "".join(texts).strip()

    @staticmethod
    def _parse_learnings_json(
        raw: str,
        rule_cls: type[ConstitutionalRule],
    ) -> list[ConstitutionalRule]:
        """Parse a JSON array of learnings, skipping malformed entries."""
        text = raw.strip()
        # Try to extract the first JSON array if there's surrounding prose.
        if not text.startswith("["):
            start = text.find("[")
            end = text.rfind("]")
            if start != -1 and end != -1 and end > start:
                text = text[start:end + 1]
            else:
                return []
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return []
        if not isinstance(data, list):
            return []

        out: list[ConstitutionalRule] = []
        for entry in data:
            if not isinstance(entry, dict):
                continue
            # ConstitutionalRule requires id + text; tolerate soft fields.
            try:
                rule = rule_cls(
                    id=str(entry.get("id", "")).strip(),
                    text=str(entry.get("text", "")).strip(),
                    priority=int(entry.get("priority", 50)),
                    tags=[str(t) for t in (entry.get("tags") or []) if t],
                    source="user",
                )
            except Exception:
                continue
            if not rule.id or not rule.text:
                continue
            out.append(rule)
        return out

    # ------------------------------------------------------------------
    # Streaming helpers
    # ------------------------------------------------------------------

    def _safe_finalize_stream(self, stream: Any) -> Any:
        """Best-effort ``get_final_message()`` on a stream that raised mid-iter."""
        if stream is None:
            return None
        try:
            return stream.get_final_message()
        except Exception as exc:  # pragma: no cover — rare SDK path
            logger.debug("get_final_message failed: %s", exc)
            return None

    def _attribute_partial_cost(self, response: Any, partial_text_parts: list[str]) -> None:
        """Attribute whatever cost we can for the partial/failed turn."""
        usage = getattr(response, "usage", None)
        if usage is not None:
            try:
                cost = _compute_turn_cost(usage, self._model)
                self._cost.add_turn(
                    cost,
                    getattr(usage, "input_tokens", 0) or 0,
                    getattr(usage, "output_tokens", 0) or 0,
                )
            except Exception as exc:
                logger.debug("cost attribution failed: %s", exc)
            return

        # No usage from the SDK — charge for what we emitted to keep budget honest.
        if partial_text_parts:
            output_tokens_est = max(1, sum(len(p) for p in partial_text_parts) // 4)
            _input_rate, output_rate = _MODEL_PRICING.get(self._model, _DEFAULT_PRICING)
            self._cost.add_turn(
                output_tokens_est * output_rate / 1_000_000,
                0,
                output_tokens_est,
            )

    def _persist_partial_turn(self, response: Any, partial_text_parts: list[str]) -> None:
        """Append whatever the assistant emitted so session.save captures it."""
        # Prefer the full SDK response if available.
        if response is not None and getattr(response, "content", None):
            try:
                dicts = self._content_to_dicts(response.content)
                if dicts:
                    self._session.append_message({"role": "assistant", "content": dicts})
                    return
            except Exception as exc:
                logger.debug("persist partial: content_to_dicts failed: %s", exc)

        # Fall back to reconstructed text from the delta stream.
        text = "".join(partial_text_parts).strip()
        if text:
            self._session.append_message({
                "role": "assistant",
                "content": [{"type": "text", "text": text}],
            })

    # ------------------------------------------------------------------
    # System prompt
    # ------------------------------------------------------------------

    _GREETING_INSTRUCTIONS = (
        "On the FIRST message of a new session (when you have no prior conversation history), begin by:\n"
        "1. Briefly introduce yourself as CARL — a coherence-aware training assistant.\n"
        "2. Ask 2-3 focused questions to understand what the user is working on:\n"
        "   - What model are they training or want to train?\n"
        "   - What is their training objective (task-specific, general, alignment)?\n"
        "   - Do they have a dataset ready, or need help generating one?\n"
        "3. If a WorkFrame is active, reference it to show you already have context.\n"
        "\n"
        "After each response, suggest 1-2 concrete next steps the user could take.\n"
        "Keep responses concise — no walls of text."
    )

    def _build_system_prompt(self) -> str:
        parts: list[str] = [
            "You are CARL, a coherence-aware training assistant from terminals.tech (Intuition Labs LLC).",
            "",
        ]

        # Frame context
        if self._frame and getattr(self._frame, "active", False):
            parts.append("ACTIVE FRAME:")
            parts.append(self._frame.attention_query())
            parts.append("")
        else:
            parts.append("No frame set. When the user describes their goal, call set_frame immediately.")
            parts.append("")

        # Session theme only surfaces in the prompt when the user picked a
        # keyed move; free-form and unset sessions are driven by the primer
        # extension instead.
        theme = self._session.session_theme
        if theme and theme.startswith("move:"):
            parts.append(f"SESSION THEME: {theme}")
            parts.append("")

        # Project context (cached at construction time)
        if self._project_line:
            parts.append(self._project_line)
            parts.append("")

        # Knowledge base
        if not self._knowledge_store.is_empty():
            sources = len(self._knowledge_store.sources())
            parts.append(
                f"KNOWLEDGE BASE: {len(self._knowledge_store)} chunks "
                f"from {sources} sources.",
            )
            parts.append("")

        # Greeting / proactive agency for new sessions
        # REV-004: gate on turn_count, not message history length.
        # ``messages`` is repopulated on resume, but ``turn_count`` is also
        # restored from the saved session. We're inside the chat() loop
        # AFTER ``self._session.increment_turn()``, so:
        #   * fresh session, first call   -> turn_count == 1  (greet)
        #   * fresh session, second call  -> turn_count == 2  (no greet)
        #   * resumed session, first call -> turn_count >= 2  (no greet)
        is_new_session = self._session.is_fresh()
        if is_new_session:
            parts.append("SESSION START BEHAVIOR:")
            parts.append(self._GREETING_INSTRUCTIONS)
            parts.append("")

        # Behavioral instructions
        parts.extend([
            "YOUR APPROACH:",
            "1. DRIVE the workflow. Recommend the next step proactively.",
            "2. When the user describes their goal, call set_frame immediately.",
            "3. When files or directories are mentioned, call ingest_source immediately.",
            "4. For analytical tasks, write and run Python code via run_analysis. Show results.",
            "5. Create deliverable files (CSV, reports, models) via create_file proactively.",
            "6. Keep responses concise. Lead with action, not explanation.",
            "7. When asked about ingested data, use query_knowledge first.",
        ])

        # One-shot extension (CLI bootstrap / JIT primer). We consume the
        # extension after emitting it so it applies only to the turn it was
        # set for — callers that want persistent priming should mutate the
        # frame or constitution instead.
        if self._system_prompt_extension:
            parts.append("")
            parts.append(self._system_prompt_extension)
            self._system_prompt_extension = ""

        base = "\n".join(parts)

        # Constitutional rules (CRYSTAL layer) — injected at most once per
        # agent instance. A failure here must never block the turn: log and
        # return the base prompt unchanged.
        rules_block = self._get_constitution_prompt()
        if rules_block:
            return base + "\n\n" + rules_block
        return base

    def _get_constitution_prompt(self) -> str:
        """Return the cached constitutional block, compiling on first use."""
        if self._constitution is None:
            return ""
        if self._constitution_prompt is not None:
            return self._constitution_prompt
        try:
            topics = self._derive_topics_from_frame() or None
            compiled = self._constitution.compile_system_prompt(
                topics=topics, max_rules=20,
            )
        except Exception as exc:
            logger.debug("Constitution.compile_system_prompt failed: %s", exc)
            compiled = ""
        self._constitution_prompt = compiled
        return compiled

    def _derive_topics_from_frame(self) -> set[str]:
        """Extract topic tags from the active WorkFrame for rule selection.

        Returns a set built from domain/function/role. Empty set when no
        frame is set (callers treat an empty set as "all topics").
        """
        frame = self._frame
        if frame is None:
            return set()
        topics: set[str] = set()
        for attr in ("domain", "function", "role"):
            value = getattr(frame, attr, "")
            if isinstance(value, str) and value:
                topics.add(value.lower())
        return topics

    @staticmethod
    def _content_to_dicts(content: Any) -> list[dict[str, Any]]:
        """Convert SDK content blocks to dicts for message history."""
        result: list[dict[str, Any]] = []
        for block in content:
            btype = getattr(block, "type", None)
            if btype == "text":
                result.append({"type": "text", "text": block.text})
            elif btype == "tool_use":
                result.append({
                    "type": "tool_use",
                    "id": block.id,
                    "name": block.name,
                    "input": block.input,
                })
        return result

    # ------------------------------------------------------------------
    # Tool registry wiring (dispatch lives on ``self._dispatcher``)
    # ------------------------------------------------------------------

    def _register_tools(self, dispatcher: ToolDispatcher) -> None:
        """Bind this agent's ``_tool_*`` methods into the dispatcher registry.

        Called once from ``__init__`` after the dispatcher is constructed.
        Each entry takes the raw ``args`` dict the Claude API emitted and
        returns whatever shape the underlying handler produces — the
        simple string tools route through ``register_simple`` so they
        auto-wrap as ``(output, False)``; tools that already return
        ``(output, is_error)`` (``dispatch_cli``) use :meth:`register`.
        """
        dispatcher.register_simple(
            "ingest_source",
            lambda a: self._tool_ingest(a.get("path", "")),
        )
        dispatcher.register_simple(
            "query_knowledge",
            lambda a: self._tool_query(a.get("question", "")),
        )
        dispatcher.register_simple(
            "run_analysis",
            lambda a: self._tool_run(a.get("code", "")),
        )
        dispatcher.register_simple(
            "create_file",
            lambda a: self._tool_create(a.get("path", ""), a.get("content", "")),
        )
        dispatcher.register_simple(
            "read_file",
            lambda a: self._tool_read(a.get("path", "")),
        )
        dispatcher.register_simple(
            "set_frame",
            lambda a: self._tool_frame(a),
        )
        dispatcher.register_simple(
            "list_files",
            lambda a: self._tool_list(a.get("path", "."), a.get("pattern", "*")),
        )
        dispatcher.register(
            "dispatch_cli",
            lambda a: self._tool_dispatch_cli(a),
        )

    # ------------------------------------------------------------------
    # Tool handlers
    # ------------------------------------------------------------------

    def _tool_ingest(self, path: str) -> str:
        from carl_studio.learn.ingest import SourceIngester

        ingester = SourceIngester()
        chunks = ingester.ingest(path)
        modalities: dict[str, int] = {}
        for c in chunks:
            self._knowledge_store.append_dict({
                "text": c.text,
                "source": c.source,
                "words": set(c.text.lower().split()),
            })
            mod = getattr(c, "modality", "text")
            modalities[mod] = modalities.get(mod, 0) + 1
        evicted = self._knowledge_store.enforce_cap()
        summary = ", ".join(f"{v} {k}" for k, v in sorted(modalities.items()))
        cap = self._knowledge_store.max_chunks
        trailer = f" (evicted {evicted} oldest to cap {cap})" if evicted else ""
        return f"Ingested {len(chunks)} chunks from {path} ({summary}){trailer}"

    def _enforce_knowledge_cap(self) -> int:
        """Back-compat wrapper — delegates to :meth:`KnowledgeStore.enforce_cap`.

        Retained because tests call it directly. The real eviction policy
        lives on the store collaborator; this shim only routes the call.
        """
        return self._knowledge_store.enforce_cap()

    def _tool_query(self, question: str) -> str:
        if self._knowledge_store.is_empty():
            return "Knowledge base is empty. Ingest files first with ingest_source."
        results = self._knowledge_store.recall(question, limit=5)
        if not results:
            return "No relevant chunks found for that query."
        parts: list[str] = []
        for score, chunk in results:
            text = str(chunk.get("text", ""))[:1500]
            parts.append(f"[{chunk.get('source', '?')}] (relevance: {score})\n{text}")
        return "\n\n---\n\n".join(parts)

    def _tool_run(self, code: str) -> str:
        # TimeoutExpired here bubbles up to _dispatch_tool_safe which maps it
        # to a model-recoverable is_error tool_result. Do not swallow here.
        #
        # Use sys.executable so the subprocess matches the interpreter running
        # CARL (the ``python`` binary on PATH may not exist, or may resolve to
        # a different venv in CI sandboxes). Strip credential env vars so the
        # model's code has no backchannel to exfiltrate ANTHROPIC_API_KEY,
        # CARL_WALLET_PASSPHRASE, OPENAI_API_KEY, HF_TOKEN, etc.
        env = _scrubbed_subprocess_env()
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        result = subprocess.run(
            [sys.executable, "-c", code],
            capture_output=True,
            timeout=_TOOL_TIMEOUTS_S["run_analysis"],
            cwd=self._workdir,
            env=env,
        )
        stdout = result.stdout.decode(errors="replace")[:6000]
        stderr = result.stderr.decode(errors="replace")[:2000]
        if result.returncode == 0:
            return stdout or "(no output)"
        return f"Exit code {result.returncode}\nstdout:\n{stdout}\nstderr:\n{stderr}"

    def _resolve_safe_path(self, path: str) -> Path | None:
        """Resolve path against workdir and reject traversal attempts.

        Symlinks are rejected (``follow_symlinks=False``). The sandbox does
        not model-own every inode in the workdir — users can drop a symlink
        that points at ``/`` between resolve and open (TOCTOU). The model has
        create_file capability, so it could plant such a link itself.
        """
        try:
            from carl_core.safepath import PathEscape, safe_resolve

            try:
                return safe_resolve(path, self._workdir, follow_symlinks=False)
            except PathEscape:
                return None
        except Exception:
            # Fallback if carl_core is unavailable — keep legacy behavior.
            resolved = Path(path).resolve()
            workdir = Path(self._workdir).resolve()
            if resolved == workdir or str(resolved).startswith(str(workdir) + os.sep):
                return resolved
            return None

    def _tool_create(self, path: str, content: str) -> str:
        p = self._resolve_safe_path(path)
        if p is None:
            return f"Blocked: path '{path}' is outside the working directory."
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
        return f"Created {p} ({len(content)} chars)"

    def _tool_read(self, path: str) -> str:
        p = self._resolve_safe_path(path)
        if p is None:
            return f"Blocked: path '{path}' is outside the working directory."
        if not p.is_file():
            return f"File not found: {path}"
        text = p.read_text(encoding="utf-8", errors="replace")
        if len(text) > _TOOL_RESULT_MAX:
            return text[:_TOOL_RESULT_MAX] + f"\n... [truncated, {len(text) - _TOOL_RESULT_MAX} chars omitted]"
        return text

    def _tool_frame(self, args: dict[str, Any]) -> str:
        from carl_studio.frame import WorkFrame

        frame = WorkFrame(
            domain=args.get("domain", ""),
            function=args.get("function", ""),
            role=args.get("role", ""),
            objectives=args.get("objectives", []),
        )
        frame.save()
        self._frame = frame
        # REV-010: invalidate the cached constitution prompt. Frame topics
        # (domain/function/role) feed rule selection in
        # ``_get_constitution_prompt``; without this reset, the next turn
        # would keep applying the pre-frame topic set.
        self._constitution_prompt = None
        return f"Frame set: {frame.domain}/{frame.function}/{frame.role}"

    def _tool_list(self, path: str, pattern: str) -> str:
        # Route through the same sandbox guard as every other file tool.
        # Without this, the model could enumerate arbitrary directories on
        # the host (e.g. '/' or '/etc') outside the working directory.
        resolved = self._resolve_safe_path(path or ".")
        if resolved is None:
            return f"Blocked: path '{path}' is outside the working directory."
        if not resolved.is_dir():
            return f"Not a directory: {path}"
        # Reject absolute globs / glob expressions that would escape the
        # sandbox. Path.glob accepts a relative pattern; absolute patterns
        # raise or ignore the anchor — forbid them upfront to be safe.
        if pattern.startswith(("/", os.sep)) or ".." in pattern.split(os.sep):
            return f"Blocked: pattern '{pattern}' is not a relative glob."
        try:
            files = sorted(resolved.glob(pattern))[:50]
        except (OSError, ValueError) as exc:
            return f"Blocked: invalid glob pattern '{pattern}': {exc}"
        # Secondary defense: drop any match that somehow escaped the sandbox
        # (symlinks resolved through safe_resolve cannot appear here, but
        # glob may surface paths that contain them).
        workdir = Path(self._workdir)
        safe_files: list[Path] = []
        for f in files:
            try:
                f_abs = f.resolve()
            except OSError:
                continue
            if f_abs == workdir or str(f_abs).startswith(str(workdir) + os.sep):
                safe_files.append(f)
        files = safe_files
        if not files:
            return f"No files matching '{pattern}' in {path}"
        lines = []
        for f in files:
            if f.is_file():
                size = f.stat().st_size
                if size > 1_000_000:
                    size_str = f"{size / 1_000_000:.1f}MB"
                elif size > 1000:
                    size_str = f"{size / 1000:.1f}KB"
                else:
                    size_str = f"{size}B"
                lines.append(f"  {f.name}  ({size_str})")
            else:
                lines.append(f"  {f.name}/")
        return "\n".join(lines)

    def _tool_dispatch_cli(self, args: dict[str, Any]) -> tuple[str, bool]:
        """Run a registered ``carl <command>`` subprocess.

        Returns ``(serialized_output, is_error)``. Records a CLI_CMD step in
        the agent's InteractionChain with the (redacted) args + exit code.
        """
        command = args.get("command", "")
        subcommand_args = args.get("args", []) or []
        timeout_s = int(args.get("timeout_s", 60) or 60)
        if not isinstance(command, str) or not command.strip():
            return self._cli_error("missing 'command' argument"), True
        if not isinstance(subcommand_args, list):
            return self._cli_error("'args' must be a list"), True
        timeout_s = max(1, min(timeout_s, 600))

        # Whitelist lookup.
        try:
            from carl_studio.cli.operations import OPERATIONS
        except Exception as exc:
            return self._cli_error(f"Ops registry unavailable: {exc}"), True

        if command not in OPERATIONS:
            allowed = ", ".join(sorted(OPERATIONS.keys()))
            return self._cli_error(
                f"Unknown carl command '{command}'. Allowed: {allowed}"
            ), True

        # Shell-metachar scan (pure string values only).
        stringified: list[str] = []
        for idx, value in enumerate(subcommand_args):
            if not isinstance(value, str):
                return self._cli_error(
                    f"args[{idx}] is not a string (got {type(value).__name__})"
                ), True
            for meta in _FORBIDDEN_SHELL_METAS:
                if meta in value:
                    return self._cli_error(
                        f"args[{idx}] contains forbidden metacharacter "
                        f"{meta!r}"
                    ), True
            stringified.append(value)

        # Tier gate — check whether the current tier permits this feature.
        tier = self._resolve_tier()
        if tier is not None:
            try:
                from carl_core.tier import feature_tier, tier_allows

                required = feature_tier(command)
                if not tier_allows(tier, command):
                    msg = (
                        f"Command '{command}' requires tier "
                        f"{required.value!r}; current tier is {tier.value!r}."
                    )
                    chain = self._get_chain()
                    if chain is not None:
                        try:
                            from carl_core.interaction import ActionType

                            chain.record(
                                ActionType.CLI_CMD,
                                f"dispatch_cli:{command}",
                                input={
                                    "command": command,
                                    "args": stringified,
                                },
                                output={"tier_block": tier.value, "required": required.value},
                                success=False,
                            )
                        except Exception:
                            pass
                    return self._cli_error(msg, code="carl.permission"), True
            except Exception:
                # Tier module not available — do not gate.
                pass

        cmd = ["carl", command, *stringified]
        # Scrub the subprocess environment to prevent credential exfiltration
        # by a model-invoked `carl` subcommand. The `carl` binary only needs
        # PATH/HOME/LANG/USER/SHELL/LC_ALL (all in _SAFE_ENV_ALLOWLIST); it
        # must NOT inherit ANTHROPIC_API_KEY, HF_TOKEN, OPENAI_API_KEY,
        # OPENROUTER_API_KEY, CARL_WALLET_PASSPHRASE, etc. Parity with
        # _tool_run (line ~1775) which already scrubs for run_analysis.
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout_s,
                cwd=self._workdir,
                env=_scrubbed_subprocess_env(),
            )
        except subprocess.TimeoutExpired:
            chain = self._get_chain()
            if chain is not None:
                try:
                    from carl_core.interaction import ActionType

                    chain.record(
                        ActionType.CLI_CMD,
                        f"dispatch_cli:{command}",
                        input={"command": command, "args": stringified},
                        output={"error": "timeout", "timeout_s": timeout_s},
                        success=False,
                    )
                except Exception:
                    pass
            return self._cli_error(
                f"carl {command} timed out after {timeout_s}s"
            ), True
        except FileNotFoundError:
            return self._cli_error(
                "'carl' binary not found on PATH — is carl-studio installed?"
            ), True
        except Exception as exc:
            return self._cli_error(f"subprocess failed: {exc}"), True

        stdout = (proc.stdout or "")[:6000]
        stderr = (proc.stderr or "")[:2000]
        exit_code = int(proc.returncode)
        payload = {"stdout": stdout, "stderr": stderr, "exit_code": exit_code}

        chain = self._get_chain()
        if chain is not None:
            try:
                from carl_core.interaction import ActionType

                chain.record(
                    ActionType.CLI_CMD,
                    f"dispatch_cli:{command}",
                    input={"command": command, "args": stringified, "timeout_s": timeout_s},
                    output={"exit_code": exit_code, "stdout_len": len(stdout), "stderr_len": len(stderr)},
                    success=(exit_code == 0),
                )
            except Exception:
                pass

        return json.dumps(payload), exit_code != 0

    def _cli_error(self, message: str, *, code: str = "carl.validation") -> str:
        """Serialize a dispatch_cli error as JSON the model can parse."""
        return json.dumps({"error": message, "code": code})

    # ------------------------------------------------------------------
    # Context compaction
    # ------------------------------------------------------------------

    def _compact(self) -> None:
        """Summarize older messages to stay within context bounds."""
        messages = self._session.messages
        if len(messages) <= _KEEP_RECENT:
            return

        old = messages[:-_KEEP_RECENT]
        recent = messages[-_KEEP_RECENT:]

        summary_parts: list[str] = []
        for msg in old:
            role = msg.get("role", "?")
            content = msg.get("content", "")
            if isinstance(content, list):
                text_bits = [
                    b.get("text", b.get("content", ""))
                    for b in content
                    if isinstance(b, dict)
                ]
                content = " ".join(str(t) for t in text_bits)
            if isinstance(content, str) and content.strip():
                summary_parts.append(f"{role}: {content[:200]}")

        summary = "Session summary (compacted):\n" + "\n".join(summary_parts[-20:])

        self._session.messages = [
            {"role": "user", "content": summary},
            {"role": "assistant", "content": "Understood. Continuing from the session summary."},
            *recent,
        ]
        self._token_count = 0
        logger.info("Compacted %d messages into summary + %d recent", len(old), len(recent))

    # ------------------------------------------------------------------
    # Session persistence
    # ------------------------------------------------------------------

    def save_session(
        self, title: str = "", store: SessionStore | None = None
    ) -> str:
        """Save current state to a session file. Returns session ID."""
        from uuid import uuid4

        if not self._session_id:
            self._session_id = str(uuid4())[:8]

        state: dict[str, Any] = {
            "id": self._session_id,
            "title": title,
            "model": self._model,
            "workdir": self._workdir,
            "messages": self._session.messages,
            # KnowledgeStore owns the wire-format conversion (sets -> sorted
            # lists); SessionStore.save keeps a compatibility pass over the
            # same structure for legacy callers that wrote the dict shape
            # inline.
            "knowledge": self._knowledge_store.to_list(),
            "frame": self._frame.model_dump() if self._frame and hasattr(self._frame, "model_dump") else None,
            # Cost ledger — persist unrounded so resume is exact. ``as_dict``
            # rounds for human-readable surfacing (see ``cost_summary``).
            "total_cost_usd": self._cost.total_cost_usd,
            "total_input_tokens": self._cost.total_input_tokens,
            "total_output_tokens": self._cost.total_output_tokens,
            "turn_count": self._session.turn_count,
            "session_theme": self._session.session_theme,
        }

        s = store or SessionStore()
        s.save(self._session_id, state)
        return self._session_id

    def load_session(
        self, session_id: str, store: SessionStore | None = None
    ) -> bool:
        """Load a saved session.

        Returns ``True`` when the session loaded successfully. Returns
        ``False`` when it was missing, unreadable, or corrupt. When the
        underlying file was corrupt and got quarantined, sets
        ``self._last_load_quarantined = True`` so the caller can surface a
        visible warning to the user.
        """
        # Reset the quarantine flag on every attempt so stale state from a
        # previous load cannot leak through.
        self._last_load_quarantined = False

        s = store or SessionStore()
        state = s.load(session_id)
        # Whenever SessionStore quarantined during this load, capture the
        # destination so the CLI can print a visible "corrupted, quarantined
        # to ..., starting fresh" message. The store resets this flag at the
        # top of every .load() call, so it reflects the current attempt only.
        if getattr(s, "_last_quarantine_dest", None) is not None:
            self._last_load_quarantined = True

        if state is None:
            return False

        self._session_id = state.get("id", session_id)
        # Rehydrate composed collaborators from persisted state.
        self._session.messages = list(state.get("messages", []))
        self._session.turn_count = int(state.get("turn_count", 0) or 0)
        # Restore session theme; default to "" for legacy sessions.
        self._session.session_theme = state.get("session_theme", "") or ""
        self._cost.total_cost_usd = float(state.get("total_cost_usd", 0.0) or 0.0)
        self._cost.total_input_tokens = int(state.get("total_input_tokens", 0) or 0)
        self._cost.total_output_tokens = int(state.get("total_output_tokens", 0) or 0)
        # Rebuild the knowledge store from persisted state. ``from_list``
        # handles set-vs-list deserialization for ``words`` and enforces
        # the current cap so a downsized ``max_knowledge_chunks`` trims
        # rather than overflowing on the next ingest.
        raw_knowledge_any: Any = state.get("knowledge", [])
        raw_knowledge: list[dict[str, Any]] = []
        if isinstance(raw_knowledge_any, list):
            for entry_any in cast(list[Any], raw_knowledge_any):
                if isinstance(entry_any, dict):
                    raw_knowledge.append(cast(dict[str, Any], entry_any))
        self._knowledge_store = KnowledgeStore.from_list(
            raw_knowledge,
            max_chunks=self._knowledge_store.max_chunks,
        )

        frame_data = state.get("frame")
        if frame_data:
            try:
                from carl_studio.frame import WorkFrame

                self._frame = WorkFrame.model_validate(frame_data)
            except Exception as exc:
                logger.warning("Could not rebuild WorkFrame from session: %s", exc)

        return True

    # ------------------------------------------------------------------
    # Session theme
    # ------------------------------------------------------------------

    _VALID_SESSION_THEMES: tuple[str, ...] = (
        "",  # unset
        "move:explore",
        "move:train",
        "move:eval",
        "move:sticky",
        "free-form",
    )

    def set_session_theme(self, theme: str) -> None:
        """Record the lane the user started this session in.

        Accepts the canonical ``move:<verb>`` labels, ``"free-form"``, or
        ``""`` to reset. Unknown labels are accepted but logged at debug
        level — the CLI should gate this with a validated map, but
        downstream callers may legitimately experiment with new themes.
        """
        theme_str = str(theme or "").strip()
        if theme_str and theme_str not in self._VALID_SESSION_THEMES:
            logger.debug("Unrecognized session_theme=%r (accepted anyway)", theme_str)
        self._session.session_theme = theme_str

    @property
    def session_theme(self) -> str:
        """Return the currently recorded session theme (or ``""``)."""
        return self._session.session_theme

    @property
    def cost_summary(self) -> dict[str, Any]:
        """Current cost and token usage."""
        summary: dict[str, Any] = dict(self._cost.as_dict())
        summary["turn_count"] = self._session.turn_count
        summary["model"] = self._model
        summary["budget_remaining_usd"] = (
            round(self._max_budget_usd - self._cost.total_cost_usd, 6)
            if self._max_budget_usd > 0
            else None
        )
        return summary
