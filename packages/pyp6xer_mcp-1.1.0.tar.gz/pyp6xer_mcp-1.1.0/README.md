# PyP6Xer MCP Server

Primavera P6 schedule analysis for AI assistants. Load an XER file, ask questions about critical path, float, schedule quality, earned value — get answers in seconds.

Works with Claude Desktop, ChatGPT, Claude.ai, or self-hosted with the included web UI.

**Live server:** `https://pyp6xer-mcp.fly.dev/mcp` (open, no key needed)
**PyPI:** `pip install pyp6xer-mcp`
[Loading your own files](#loading-your-own-xer-files) | [Authentication](#authentication) | [Development](#development)

---

## Try it now

The server has five sample projects pre-loaded. Connect and start asking questions — no upload needed.

| Cache Key | Sector | Activities |
|-----------|--------|------------|
| `cairo-alex-road` | Roads | 57 |
| `hilal-oil-gas` | Oil & Gas | 31 |
| `terminal-building-airport` | Infrastructure | 66 |
| `pharma-pack` | Industrial | 289 |
| `expressway-project` | Roads/Bridges | 823 |

Example prompts:
- *"List projects in cache key expressway-project"*
- *"Run a schedule health check on pharma-pack"*
- *"Show the critical path for cairo-alex-road"*
- *"Analyze float distribution for terminal-building-airport"*

---

## Setup

### Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "pyp6xer": {
      "command": "uvx",
      "args": ["pyp6xer-mcp"]
    }
  }
}
```

Runs locally via stdio. Load your own XER files by path: *"Load /path/to/project.xer and analyze the critical path"*

### ChatGPT or Claude.ai

Add the remote server in your MCP settings:

```
https://pyp6xer-mcp.fly.dev/mcp
```

No API key needed. The sample projects above are ready to query. To analyze your own file, say *"I need to upload a P6 schedule"* — the AI will generate an upload link you can open in your browser.

### Self-hosted (full stack with web UI)

```bash
git clone https://gitlab.com/articat1066/pyp6xer-mcp.git
cd pyp6xer-mcp
echo "OPENAI_API_KEY=sk-xxx" > .env
docker compose up
```

Open `http://localhost:3000` — upload an XER file and start asking questions. The MCP server runs at `http://localhost:5000` with sample projects auto-loaded.

Uses gpt-4o-mini by default. To change model or to use Claude, set `ANTHROPIC_API_KEY` and `AI_MODEL=claude-sonnet-xxx` in your `.env`.

### MCP server only (no UI)

```bash
docker compose up pyp6xer-mcp
```

MCP endpoint at `http://localhost:5000/mcp`.

---

## Loading your own XER files

**Local file** (Claude Desktop — file stays on your machine):
```
"Load /Users/me/Desktop/project.xer and show the critical path"
```

**URL** (any client):
```
"Load the XER file at https://example.com/project.xer"
```

**Upload link** (ChatGPT, Claude.ai — when you can't give a file path):

Ask the AI *"I need to upload a schedule file."* It calls the `pyp6xer_get_upload_url` tool, which returns a one-time upload link (valid 15 minutes). Open the link in your browser, upload your XER file, then come back to the chat. The file goes from your browser to the MCP server endpoint, not through the AI. It's held in memory for the session and lost on restart.

**Direct HTTP upload** (scripts, CI/CD):
```bash
curl -X POST -F "file=@project.xer" https://pyp6xer-mcp.fly.dev/upload
# Returns: {"cache_key": "upload_abc123", "activity_count": 250, ...}
# Use the cache_key with any analysis tool.
```

---

## What it does

23 tools, 5 prompts, 3 resources. All tools are prefixed `pyp6xer_`.

| Category | Tools |
|----------|-------|
| **File Operations** (5) | `load_file`, `write_file`, `clear_cache`, `export_csv`, `get_upload_url` |
| **Project/Activity** (5) | `list_projects`, `list_activities`, `get_activity`, `search_activities`, `update_activity` |
| **Schedule Analysis** (6) | `critical_path`, `float_analysis`, `schedule_quality`, `relationship_analysis`, `slipping_activities`, `schedule_health_check` |
| **Resource Management** (2) | `list_resources`, `resource_utilization` |
| **Progress/Performance** (4) | `progress_summary`, `earned_value`, `work_package_summary`, `wbs_analysis` |
| **Structure** (1) | `list_calendars` |

See [TOOLS.md](TOOLS.md) for full parameter documentation.

---

## Authentication

The hosted server at `pyp6xer-mcp.fly.dev` is open — no API key needed.

For self-hosted deployments, set `API_KEY` to enable authentication:

```bash
API_KEY=your_secret_key docker compose up
```

Clients then pass the key via query param, Bearer header, or x-api-key header:

```json
{
  "mcpServers": {
    "pyp6xer": {
      "url": "https://your-server.com/mcp?api_key=YOUR_KEY"
    }
  }
}
```

---

## Development

```bash
git clone https://gitlab.com/articat1066/pyp6xer-mcp.git
cd pyp6xer_mcp
uv pip install -e ".[dev]"

pytest                                      # 27 tests
python -m pyp6xer_mcp.cli                   # Run stdio (Claude Desktop)
python -m pyp6xer_mcp.cli streamable-http   # Run HTTP server on port 5000

black --line-length 100 .                   # Format
ruff check .                                # Lint
```

---

## Architecture

```
pyp6xer_mcp/          # Python MCP server
├── server.py          # FastMCP instance
├── cli.py             # Entry point + sample auto-load
├── core/parser.py     # Shared XER parsing
├── tools/             # 23 MCP tools
├── prompts/           # 5 workflow prompts
├── resources/         # 3 MCP resources
└── http/              # Auth, upload, landing page

frontend/              # Next.js web UI (for self-hosted)
├── app/               # Pages + API routes (chat, tools)
├── components/        # Canvas, P6 upload, AI chat elements
└── Dockerfile

samples/               # Pre-loaded XER files (auto-load on startup)
```

Built on [PyP6XER](https://github.com/HassanEmam/PyP6Xer) by Hassan Emam.

---

## Built by

Paul Boucherat — [portfolio](https://bouch.pages.dev) · [LinkedIn](https://www.linkedin.com/in/paulbouch/) · [GitLab](https://gitlab.com/articat1066) · [Buy me a coffee](https://buymeacoffee.com/articat)

If you're using this or have questions about P6 tooling, I'd like to hear from you.

## License

MIT — free for commercial and personal use.
