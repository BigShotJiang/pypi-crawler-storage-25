# Sample XER Files

These files auto-load when the server starts in HTTP mode. Cache keys are the filenames without extension.

| File | Cache Key | Sector | Activities |
|------|-----------|--------|------------|
| cairo-alex-road.xer | `cairo-alex-road` | Roads | 57 |
| hilal-oil-gas.xer | `hilal-oil-gas` | Oil & Gas | 31 |
| terminal-building-airport.xer | `terminal-building-airport` | Infrastructure | 66 |
| pharma-pack.xer | `pharma-pack` | Industrial | 289 |
| expressway-project.xer | `expressway-project` | Roads/Bridges | 823 |

## Usage

Once the server is running, query any project by cache key:

```
"List projects in cache key expressway-project"
"Run a schedule health check on pharma-pack"
"Show the critical path for cairo-alex-road"
```

## Adding samples

Place `.xer` files in this directory. They'll auto-load on next server start. Cache key = filename without extension (use hyphens, no spaces).

The `.gitignore` has `!samples/*.xer` so sample files are tracked in git.
