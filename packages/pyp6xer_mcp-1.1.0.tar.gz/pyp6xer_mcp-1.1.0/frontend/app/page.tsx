"use client";

import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import { nanoid } from "nanoid";
import {
  SparklesIcon,
  MessageSquareIcon,
  Mail,
  FileText,
  Database,
  BarChart3,
  Users,
  LogOutIcon,
  SettingsIcon,
  LoaderIcon,
} from "lucide-react";
import { useAuth } from "@/components/providers/AuthProvider";
import { useUserConnection } from "@/hooks/useUserConnection";
import { XerUpload } from "@/components/operators/p6/XerUpload";
import RootsupPage from "./rootsup/page";

import {
  Conversation,
  ConversationContent,
  ConversationEmptyState,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageContent,
  MessageResponse,
  MessageLabel,
} from "@/components/ai-elements/message";
import { PromptInputSubmit } from "@/components/ai-elements/prompt-input";
import {
  Reasoning,
  ReasoningTrigger,
  ReasoningContent,
} from "@/components/ai-elements/reasoning";
import { Tool, ToolInput, ToolOutput } from "@/components/ai-elements/tool";
import { Suggestions, Suggestion } from "@/components/ai-elements/suggestion";
import { LoaderText } from "@/components/ai-elements/loader";
import { CanvasPanel } from "@/components/canvas";
import {
  type CanvasItem,
  createCanvasItem,
  extractTitle,
  getCanvasType,
} from "@/lib/canvas-types";

// Default suggestions - can be overridden via env
const DEFAULT_SUGGESTIONS = [
  "Triage my inbox",
  "Create an invoice",
  "Clean this data",
  "Draft a weekly report",
];

// Get config from window (set by layout)
interface ClientConfig {
  siteTitle: string;
  siteTagline: string;
  suggestions: string[];
  uploadEnabled?: boolean;
  uploadLabel?: string;
  uploadFileTypes?: string[];
  mode?: string;
  platformOperator?: string;
}

function getClientConfig(): ClientConfig {
  if (typeof window !== "undefined" && (window as unknown as { __CONFIG__?: ClientConfig }).__CONFIG__) {
    return (window as unknown as { __CONFIG__: ClientConfig }).__CONFIG__;
  }
  return {
    siteTitle: "AI Assistant",
    siteTagline: "",
    suggestions: DEFAULT_SUGGESTIONS,
    uploadEnabled: false,
  };
}

// Check if this is an operator-specific deployment
function getOperatorMode(): string | null {
  if (typeof window !== "undefined") {
    const config = (window as unknown as { __CONFIG__?: ClientConfig }).__CONFIG__;
    // Check platformOperator for operator-specific UI (e.g., "rootsup", "p6")
    return config?.platformOperator || null;
  }
  return null;
}

// XER upload metadata type
interface XerMetadata {
  cache_key: string;
  projects: Array<{ id: string; short_name: string }>;
  activity_count: number;
  message: string;
}

export default function ChatPage() {
  // Check for operator-specific UI mode
  const operatorMode = getOperatorMode();

  // Render operator-specific UI if configured
  if (operatorMode === "rootsup") {
    return <RootsupPage />;
  }

  const [conversationId] = useState(() => `conv_${nanoid(12)}`);
  const [input, setInput] = useState("");
  const [canvasItems, setCanvasItems] = useState<CanvasItem[]>([]);
  const [canvasCollapsed, setCanvasCollapsed] = useState(false);
  const [config, setConfig] = useState(getClientConfig());

  // XER file upload state
  const [xerCacheKey, setXerCacheKey] = useState<string | null>(null);
  const [xerMetadata, setXerMetadata] = useState<XerMetadata | null>(null);

  // Auth state (only used in dynamic mode)
  const { user, loading: authLoading, signOut } = useAuth();
  const { connection, loading: connectionLoading, error: connectionError } = useUserConnection();

  // Check if we're in dynamic mode (mcp-bridge)
  const isDynamicMode = typeof window !== "undefined" &&
    (window as unknown as { __CONFIG__?: { mode?: string } }).__CONFIG__?.mode === "dynamic";

  // Load config on mount
  useEffect(() => {
    // Fetch suggestions from env if available
    fetch("/api/tools")
      .then((res) => res.json())
      .then((data) => {
        if (data.count > 0) {
          console.log(`Connected to MCP server with ${data.count} tools`);
        }
      })
      .catch(() => {
        console.log("Could not verify MCP connection");
      });
    setConfig(getClientConfig());
  }, []);

  // Memoize transport to prevent recreation on every render
  const transport = useMemo(
    () => new DefaultChatTransport({ api: "/api/chat" }),
    []
  );

  const { messages, sendMessage, status, stop } = useChat({ transport });

  // Track processed tool calls to avoid duplicate canvas items
  const processedToolCalls = useRef<Set<string>>(new Set());

  // Extract canvas items from tool results
  const extractCanvasItems = useCallback(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (parts: any[]) => {
      parts.forEach((part) => {
        if (part.type?.startsWith("tool-") && part.state === "output-available") {
          const toolCallId = part.toolCallId as string | undefined;

          // Skip if already processed
          if (toolCallId && processedToolCalls.current.has(toolCallId)) {
            return;
          }

          const output = part.output;
          const toolName = part.type.replace("tool-", "");

          if (output?.canvasItem) {
            // Tool returned an explicit canvas item
            if (toolCallId) processedToolCalls.current.add(toolCallId);
            setCanvasItems((prev) => {
              if (prev.find((item) => item.id === output.canvasItem.id)) {
                return prev;
              }
              return [...prev, output.canvasItem];
            });
          } else if (output && typeof output === "object") {
            // Check for result property or use output directly
            const result = (output.result && typeof output.result === "object")
              ? output.result as Record<string, unknown>
              : output as Record<string, unknown>;

            // Skip if result is just an error or empty
            if (!result || Object.keys(result).length === 0) return;
            if (result.error || result.status === "error") return;

            const title = extractTitle(toolName, result);
            const canvasType = getCanvasType(toolName);

            // Create canvas item for schedule tools or rich data
            if (canvasType !== "markdown" || Object.keys(result).length > 2) {
              if (toolCallId) processedToolCalls.current.add(toolCallId);
              console.log("Creating canvas item:", { toolName, canvasType, title, resultKeys: Object.keys(result) });
              const item = createCanvasItem(toolName, title, result, toolCallId);
              setCanvasItems((prev) => {
                if (prev.find((i) => i.id === item.id)) return prev;
                return [...prev, item];
              });
            }
          }
        }
      });
    },
    []
  );

  // Watch for new tool outputs
  useEffect(() => {
    messages.forEach((message) => {
      if (message.role === "assistant" && message.parts) {
        extractCanvasItems(message.parts);
      }
    });
  }, [messages, extractCanvasItems]);

  const handleSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (input.trim() && status !== "streaming") {
      const text = input;
      setInput("");
      try {
        await sendMessage(
          { text },
          {
            body: { conversationId, xerCacheKey },
          }
        );
      } catch (error) {
        console.error("Send error:", error);
      }
    }
  };

  const handleSuggestionClick = async (suggestion: string) => {
    if (status !== "streaming") {
      setInput("");
      try {
        await sendMessage(
          { text: suggestion },
          {
            body: { conversationId, xerCacheKey },
          }
        );
      } catch (error) {
        console.error("Suggestion send error:", error);
      }
    }
  };

  // Handle XER file upload completion
  const handleXerUploadComplete = useCallback((cacheKey: string, metadata: XerMetadata) => {
    setXerCacheKey(cacheKey);
    setXerMetadata(metadata);
    console.log("XER file uploaded:", { cacheKey, metadata });
  }, []);

  const suggestions = Array.isArray(config.suggestions)
    ? config.suggestions
    : DEFAULT_SUGGESTIONS;

  // Loading state for dynamic mode
  if (isDynamicMode && (authLoading || connectionLoading)) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <LoaderIcon className="size-8 animate-spin text-muted-foreground" />
          <p className="text-muted-foreground">Loading your workspace...</p>
        </div>
      </div>
    );
  }

  // Error state for dynamic mode - no integrations configured
  if (isDynamicMode && !connection?.strata_url) {
    const dashboardUrl = process.env.NEXT_PUBLIC_DASHBOARD_URL || "https://mcp-bridge.xyz/app";
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-4 max-w-md text-center">
          <SettingsIcon className="size-12 text-muted-foreground" />
          <h2 className="text-xl font-semibold">No Integrations Configured</h2>
          <p className="text-muted-foreground">
            {connectionError || "Please enable at least one integration in the dashboard to start chatting."}
          </p>
          <a
            href={dashboardUrl}
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            <SettingsIcon className="size-4" />
            Go to Dashboard
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col">
      {/* Header */}
      <header className="flex items-center justify-between border-b px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <SparklesIcon className="size-5" />
          </div>
          <div>
            <h1 className="font-semibold">{config.siteTitle || "AI Assistant"}</h1>
            {config.siteTagline && (
              <p className="text-xs text-muted-foreground">{config.siteTagline}</p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <span className="size-2 rounded-full bg-green-500" />
            Connected
          </span>
          {/* User info in dynamic mode */}
          {isDynamicMode && user && (
            <>
              <span className="text-foreground">{user.email}</span>
              <button
                onClick={() => signOut()}
                className="flex items-center gap-1 rounded px-2 py-1 hover:bg-muted"
                title="Sign out"
              >
                <LogOutIcon className="size-3" />
              </button>
            </>
          )}
        </div>
      </header>

      {/* Capabilities Bar */}
      <div className="flex items-center gap-4 border-b px-6 py-2 text-xs text-muted-foreground">
        <span className="flex items-center gap-1">
          <Mail className="size-3" /> Email
        </span>
        <span className="flex items-center gap-1">
          <FileText className="size-3" /> Invoicing
        </span>
        <span className="flex items-center gap-1">
          <Database className="size-3" /> Data
        </span>
        <span className="flex items-center gap-1">
          <BarChart3 className="size-3" /> Reports
        </span>
        <span className="flex items-center gap-1">
          <Users className="size-3" /> Clients
        </span>
        {/* Show uploaded file indicator */}
        {xerMetadata && (
          <span className="ml-auto flex items-center gap-1 text-green-600">
            <FileText className="size-3" />
            {xerMetadata.projects[0]?.short_name || "Schedule"} ({xerMetadata.activity_count} activities)
          </span>
        )}
      </div>

      {/* XER File Upload - shown when enabled and no file uploaded */}
      {config.uploadEnabled && !xerCacheKey && messages.length === 0 && (
        <div className="border-b bg-muted/30 px-6 py-6">
          <XerUpload
            onUploadComplete={handleXerUploadComplete}
            onError={(error) => console.error("Upload error:", error)}
          />
        </div>
      )}

      {/* Main Content - Split Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Chat Panel */}
        <div className="flex flex-1 flex-col">
          <Conversation className="flex-1">
            <ConversationContent className="max-w-3xl mx-auto">
              {messages.length === 0 ? (
                <ConversationEmptyState
                  icon={<MessageSquareIcon className="size-12" />}
                  title="How can I help you today?"
                  description="I can help with email, invoicing, data cleanup, reports, and client management."
                />
              ) : (
                messages.map((message) => (
                  <Message key={message.id} from={message.role}>
                    {message.role === "assistant" && (
                      <MessageLabel>Assistant</MessageLabel>
                    )}
                    <MessageContent>
                      {message.parts.map((part, index) => {
                        switch (part.type) {
                          case "text":
                            return (
                              <MessageResponse key={`${message.id}-${index}`}>
                                {part.text}
                              </MessageResponse>
                            );

                          case "reasoning":
                            return (
                              <Reasoning key={`${message.id}-${index}`}>
                                <ReasoningTrigger />
                                <ReasoningContent>{part.text}</ReasoningContent>
                              </Reasoning>
                            );

                          default:
                            // Handle tool parts
                            if (part.type.startsWith("tool-")) {
                              const toolPart = part as {
                                type: string;
                                toolCallId: string;
                                state: string;
                                input?: unknown;
                                output?: unknown;
                              };
                              const toolName = part.type.replace("tool-", "");
                              const toolState = toolPart.state;

                              return (
                                <Tool
                                  key={`${message.id}-${index}`}
                                  name={toolName}
                                  status={
                                    toolState === "output-available"
                                      ? "completed"
                                      : toolState === "input-available"
                                      ? "running"
                                      : "pending"
                                  }
                                >
                                  <ToolInput
                                    parameters={
                                      toolPart.input as Record<string, unknown> | undefined
                                    }
                                  />
                                  {toolState === "output-available" && (
                                    <ToolOutput result={toolPart.output} />
                                  )}
                                </Tool>
                              );
                            }
                            return null;
                        }
                      })}
                    </MessageContent>
                  </Message>
                ))
              )}

              {/* Loading indicator */}
              {status === "streaming" && (
                <Message from="assistant">
                  <MessageContent>
                    <LoaderText text="Thinking..." />
                  </MessageContent>
                </Message>
              )}
            </ConversationContent>
            <ConversationScrollButton />
          </Conversation>

          {/* Input Area */}
          <div className="border-t bg-background">
            <div className="max-w-3xl mx-auto p-4 space-y-4">
              {/* Suggestions */}
              {messages.length === 0 && (
                <Suggestions className="justify-center">
                  {suggestions.map((suggestion: string) => (
                    <Suggestion
                      key={suggestion}
                      suggestion={suggestion}
                      onClick={() => handleSuggestionClick(suggestion)}
                    />
                  ))}
                </Suggestions>
              )}

              {/* Input */}
              <form
                onSubmit={handleSubmit}
                className="relative flex items-end gap-2 rounded-2xl border bg-background p-2 shadow-sm"
              >
                <textarea
                  name="prompt"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSubmit();
                    }
                  }}
                  className="flex-1 resize-none bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none disabled:cursor-not-allowed disabled:opacity-50 min-h-[44px] max-h-[200px]"
                  placeholder="Ask anything..."
                  rows={1}
                  disabled={status === "streaming"}
                />
                <PromptInputSubmit
                  status={status === "streaming" ? "streaming" : "ready"}
                  onStop={stop}
                />
              </form>
            </div>
          </div>
        </div>

        {/* Canvas Panel */}
        <CanvasPanel
          items={canvasItems}
          collapsed={canvasCollapsed}
          onToggleCollapse={() => setCanvasCollapsed(!canvasCollapsed)}
        />
      </div>
    </div>
  );
}
