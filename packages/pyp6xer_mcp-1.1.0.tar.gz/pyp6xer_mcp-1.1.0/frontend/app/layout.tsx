import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/components/providers/AuthProvider";
import { getPublicConfig } from "@/lib/config";

const inter = Inter({ subsets: ["latin"] });

// Force dynamic rendering so env vars are read at runtime, not build time
export const dynamic = "force-dynamic";

// Get config for metadata (will be read at request time due to dynamic)
const config = getPublicConfig();

export const metadata: Metadata = {
  title: config.siteTitle || "AI Assistant",
  description: config.siteTagline || "AI-powered assistant",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Inject config for client components */}
        <script
          dangerouslySetInnerHTML={{
            __html: `window.__CONFIG__ = ${JSON.stringify(config)};`,
          }}
        />
      </head>
      <body className={inter.className}>
        <AuthProvider>
          <div className="flex min-h-screen flex-col">
            {children}
          </div>
        </AuthProvider>
      </body>
    </html>
  );
}
