'use client';

import { useChat } from '@ai-sdk/react';
import { DefaultChatTransport } from 'ai';
import { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import { nanoid } from 'nanoid';
import { RootsupLayout } from '@/components/operators/rootsup';
import { CanvasPanel } from '@/components/canvas';
import {
  type CanvasItem,
  createCanvasItem,
  extractTitle,
  getCanvasType,
} from '@/lib/canvas-types';

// Types for inbox data
interface Email {
  id: string;
  subject: string;
  sender: string;
  snippet: string;
  date?: string;
  category?: string;
  urgency?: 'high' | 'medium' | 'low';
}

interface InboxData {
  urgent: Email[];
  normal: Email[];
  low: Email[];
}

interface DashboardMetrics {
  activeClients: number;
  pendingInvoices: { count: number; total: number };
  unbilledHours: number;
  monthlyRevenue?: number;
}

export default function RootsupPage() {
  const [conversationId] = useState(() => `conv_${nanoid(12)}`);
  const [canvasItems, setCanvasItems] = useState<CanvasItem[]>([]);
  const [canvasCollapsed, setCanvasCollapsed] = useState(false);

  // State populated from tool calls
  const [inboxData, setInboxData] = useState<InboxData | null>(null);
  const [dashboardMetrics, setDashboardMetrics] = useState<DashboardMetrics | null>(null);
  const [recentActivity, setRecentActivity] = useState<Array<{
    id: string;
    type: 'invoice' | 'email' | 'task' | 'client';
    description: string;
    timestamp: string;
  }>>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Memoize transport
  const transport = useMemo(
    () => new DefaultChatTransport({ api: '/api/chat' }),
    []
  );

  const { messages, sendMessage, status } = useChat({ transport });

  // Track processed tool calls
  const processedToolCalls = useRef<Set<string>>(new Set());

  // Process tool outputs to extract data for UI components and canvas
  const processTool = useCallback(
    (toolName: string, output: Record<string, unknown>, toolCallId?: string) => {
      // Skip if already processed
      if (toolCallId && processedToolCalls.current.has(toolCallId)) {
        return;
      }
      if (toolCallId) processedToolCalls.current.add(toolCallId);

      console.log('Processing tool:', toolName, output);

      // Extract data for specific tools
      if (toolName === 'rootsup_triage_inbox' || toolName.includes('triage')) {
        const inbox: InboxData = {
          urgent: (output.urgent || output.high || []) as Email[],
          normal: (output.normal || output.pending || output.medium || []) as Email[],
          low: (output.low || []) as Email[],
        };
        setInboxData(inbox);
      }

      if (toolName === 'rootsup_billable_summary' || toolName.includes('billable')) {
        const summary = output as Record<string, unknown>;
        setDashboardMetrics((prev) => ({
          ...prev,
          activeClients: prev?.activeClients ?? 0,
          pendingInvoices: prev?.pendingInvoices ?? { count: 0, total: 0 },
          unbilledHours: (summary.total_hours as number) || 0,
          monthlyRevenue: prev?.monthlyRevenue,
        }));
      }

      // Create canvas item for rich outputs
      const canvasType = getCanvasType(toolName);
      if (canvasType !== 'markdown' || Object.keys(output).length > 2) {
        const title = extractTitle(toolName, output);
        const item = createCanvasItem(toolName, title, output, toolCallId);
        setCanvasItems((prev) => {
          if (prev.find((i) => i.id === item.id)) return prev;
          return [...prev, item];
        });
      }
    },
    []
  );

  // Watch for tool outputs in messages
  useEffect(() => {
    messages.forEach((message) => {
      if (message.role === 'assistant' && message.parts) {
        message.parts.forEach((part) => {
          if (
            part.type?.startsWith('tool-') &&
            (part as { state?: string }).state === 'output-available'
          ) {
            const toolPart = part as {
              type: string;
              toolCallId?: string;
              output?: Record<string, unknown>;
            };
            const toolName = part.type.replace('tool-', '');
            if (toolPart.output) {
              processTool(toolName, toolPart.output, toolPart.toolCallId);
            }
          }
        });
      }
    });
  }, [messages, processTool]);

  // Track loading state
  useEffect(() => {
    setIsLoading(status === 'streaming');
  }, [status]);

  // Handler for sending messages from UI components
  const handleSendMessage = useCallback(
    async (text: string) => {
      try {
        await sendMessage(
          { text },
          { body: { conversationId } }
        );
      } catch (error) {
        console.error('Send error:', error);
      }
    },
    [sendMessage, conversationId]
  );

  return (
    <RootsupLayout
      onSendMessage={handleSendMessage}
      inboxData={inboxData || undefined}
      dashboardMetrics={dashboardMetrics || undefined}
      recentActivity={recentActivity}
      isLoading={isLoading}
      canvasPanel={
        <CanvasPanel
          items={canvasItems}
          collapsed={canvasCollapsed}
          onToggleCollapse={() => setCanvasCollapsed(!canvasCollapsed)}
        />
      }
    />
  );
}
