import { NextResponse } from "next/server";
import { getConfig } from "@/lib/config";
import { discoverTools } from "@/lib/mcp-client";
import { listPlatformAgents } from "@/lib/platform-client";

/**
 * GET /api/tools - Discover available tools/agents
 *
 * In platform mode: Returns available agents from the platform
 * In standalone mode: Returns tools from MCP server
 */
export async function GET() {
  const config = getConfig();

  // Platform mode: return agents from platform API
  if (config.mode === "platform") {
    if (!config.platformUrl || !config.platformApiKey) {
      return NextResponse.json(
        { error: "Platform not configured" },
        { status: 500 }
      );
    }

    try {
      const agents = await listPlatformAgents(
        config.platformUrl,
        config.platformApiKey
      );

      return NextResponse.json({
        mode: "platform",
        agents: agents,
        count: agents.length,
        platformUrl: config.platformUrl,
      });
    } catch (error) {
      console.error("Failed to list platform agents:", error);
      return NextResponse.json(
        { error: "Failed to list agents from platform" },
        { status: 500 }
      );
    }
  }

  // Standalone/dynamic mode: discover tools from MCP server
  if (!config.mcpServerUrl) {
    return NextResponse.json(
      { error: "MCP server not configured" },
      { status: 500 }
    );
  }

  try {
    const tools = await discoverTools(config.mcpServerUrl, config.mcpApiKey);

    return NextResponse.json({
      mode: "standalone",
      tools: tools.map((t) => ({
        name: t.name,
        description: t.description,
        parameters: t.inputSchema?.properties
          ? Object.keys(t.inputSchema.properties)
          : [],
      })),
      count: tools.length,
      mcpServer: config.mcpServerUrl,
    });
  } catch (error) {
    console.error("Failed to discover tools:", error);
    return NextResponse.json(
      { error: "Failed to discover tools from MCP server" },
      { status: 500 }
    );
  }
}
