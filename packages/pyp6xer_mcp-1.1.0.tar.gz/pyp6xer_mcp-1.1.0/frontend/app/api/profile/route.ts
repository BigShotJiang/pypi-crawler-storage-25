/**
 * API Route: GET /api/profile
 *
 * Proxies the platform /me endpoint server-side.
 * This keeps API keys secure (not exposed to client).
 */

import { NextResponse } from "next/server";
import { getConfig } from "@/lib/config";
import { getUserProfile, type UserProfile } from "@/lib/platform-client";

export async function GET(): Promise<NextResponse<UserProfile | { error: string }>> {
  const config = getConfig();

  // Only available in platform mode
  if (config.mode !== "platform") {
    return NextResponse.json(
      { error: "Profile only available in platform mode" },
      { status: 400 }
    );
  }

  if (!config.platformUrl || !config.platformApiKey) {
    return NextResponse.json(
      { error: "Platform not configured" },
      { status: 500 }
    );
  }

  try {
    const profile = await getUserProfile(
      config.platformUrl,
      config.platformApiKey,
      true // Force refresh
    );

    return NextResponse.json(profile);
  } catch (error) {
    console.error("Failed to fetch profile:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch profile" },
      { status: 500 }
    );
  }
}
