/**
 * API Route: POST /api/browse
 *
 * Proxies Browse calls to Strata server-side.
 * This solves CORS issues (browsers can't call Strata directly).
 *
 * Body: { toolName: string, args: Record<string, unknown> }
 *
 * Supports shorthand tool names that get translated to Strata execute_action:
 * - gmail_search_emails -> execute_action(gmail, GMAIL_EMAIL, gmail_search_emails)
 * - gmail_read_email -> execute_action(gmail, GMAIL_EMAIL, gmail_read_email)
 */

import { NextRequest, NextResponse } from "next/server";
import { getConfig } from "@/lib/config";
import { getUserProfile } from "@/lib/platform-client";
import { callMcpTool } from "@/lib/mcp-client";

interface BrowseRequest {
  toolName: string;
  args: Record<string, unknown>;
}

// Map shorthand tool names to Strata execute_action params
const TOOL_MAPPINGS: Record<string, { server: string; category: string; action: string }> = {
  // Gmail
  gmail_search_emails: { server: "gmail", category: "GMAIL_EMAIL", action: "gmail_search_emails" },
  gmail_read_email: { server: "gmail", category: "GMAIL_EMAIL", action: "gmail_read_email" },
  gmail_send_email: { server: "gmail", category: "GMAIL_EMAIL", action: "gmail_send_email" },
  gmail_draft_email: { server: "gmail", category: "GMAIL_EMAIL", action: "gmail_draft_email" },
  // Calendar
  calendar_list_events: { server: "google calendar", category: "CALENDAR_EVENTS", action: "calendar_list_events" },
  calendar_create_event: { server: "google calendar", category: "CALENDAR_EVENTS", action: "calendar_create_event" },
  // Drive
  drive_list_files: { server: "google drive", category: "DRIVE_FILES", action: "drive_list_files" },
  drive_search_files: { server: "google drive", category: "DRIVE_FILES", action: "drive_search_files" },
};

export async function POST(request: NextRequest): Promise<NextResponse> {
  const config = getConfig();

  // Only available in platform mode
  if (config.mode !== "platform") {
    return NextResponse.json(
      { error: "Browse only available in platform mode" },
      { status: 400 }
    );
  }

  if (!config.platformUrl || !config.platformApiKey) {
    return NextResponse.json(
      { error: "Platform not configured" },
      { status: 500 }
    );
  }

  // Get user's strata_url from their profile
  let strataUrl: string | null = null;
  try {
    const profile = await getUserProfile(
      config.platformUrl,
      config.platformApiKey
    );
    strataUrl = profile.strata_url;
  } catch (error) {
    console.error("Failed to get profile for browse:", error);
    return NextResponse.json(
      { error: "Failed to get user profile" },
      { status: 500 }
    );
  }

  if (!strataUrl) {
    return NextResponse.json(
      { error: "No Strata URL configured. Please connect your apps first." },
      { status: 400 }
    );
  }

  // Parse request body
  let body: BrowseRequest;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: "Invalid JSON body" },
      { status: 400 }
    );
  }

  const { toolName, args } = body;

  if (!toolName) {
    return NextResponse.json(
      { error: "toolName is required" },
      { status: 400 }
    );
  }

  try {
    // Check if this is a shorthand tool name that needs translation
    const mapping = TOOL_MAPPINGS[toolName];

    if (mapping) {
      // Translate to Strata execute_action format
      const executeArgs = {
        server_name: mapping.server,
        category_name: mapping.category,
        action_name: mapping.action,
        body_schema: JSON.stringify(args || {}),
      };

      console.log(`Browse: Translating ${toolName} to execute_action`, executeArgs);
      const result = await callMcpTool(strataUrl, "", "execute_action", executeArgs);
      return NextResponse.json(result);
    }

    // Otherwise, call the tool directly (for native Strata tools like discover_server_categories)
    const result = await callMcpTool(strataUrl, "", toolName, args || {});
    return NextResponse.json(result);
  } catch (error) {
    console.error(`Browse call failed (${toolName}):`, error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Browse call failed" },
      { status: 500 }
    );
  }
}
