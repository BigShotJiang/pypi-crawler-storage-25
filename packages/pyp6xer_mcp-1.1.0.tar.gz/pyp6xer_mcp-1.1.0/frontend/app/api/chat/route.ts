import { anthropic } from "@ai-sdk/anthropic";
import { openai } from "@ai-sdk/openai";
import { streamText, tool, type UIMessage, convertToModelMessages, stepCountIs } from "ai";
import { z } from "zod";
import { getConfig } from "@/lib/config";
import { discoverTools, callMcpTool, type McpTool } from "@/lib/mcp-client";
import {
  getCanvasType,
  extractTitle,
  createCanvasItem,
} from "@/lib/canvas-types";
import { getSession } from "@/lib/supabase/server";
import { fetchUserConnection } from "@/lib/user-connection";

// Allow streaming responses up to 60 seconds
export const maxDuration = 60;

// Cache discovered tools per MCP server URL
const toolsCache = new Map<string, { tools: McpTool[]; time: number }>();
const TOOLS_CACHE_TTL = 5 * 60 * 1000; // 5 minutes

async function getTools(mcpServerUrl?: string, mcpApiKey?: string): Promise<McpTool[]> {
  const config = getConfig();
  const serverUrl = mcpServerUrl || config.mcpServerUrl;
  const apiKey = mcpApiKey || config.mcpApiKey;

  if (!serverUrl) {
    console.warn("No MCP server URL provided");
    return [];
  }

  // Check cache for this server
  const cached = toolsCache.get(serverUrl);
  if (cached && Date.now() - cached.time < TOOLS_CACHE_TTL) {
    return cached.tools;
  }

  // Discover tools from MCP server
  try {
    const tools = await discoverTools(serverUrl, apiKey);
    toolsCache.set(serverUrl, { tools, time: Date.now() });
    console.log(`Discovered ${tools.length} tools from MCP server: ${serverUrl}`);
    return tools;
  } catch (error) {
    console.error("Failed to discover tools:", error);
    return [];
  }
}

// Convert JSON schema to Zod schema (simplified)
function jsonSchemaToZod(schema: Record<string, unknown>): z.ZodTypeAny {
  const properties = schema.properties as Record<string, unknown> | undefined;
  const required = (schema.required as string[]) || [];

  if (properties) {
    const shape: Record<string, z.ZodTypeAny> = {};

    for (const [key, propSchema] of Object.entries(properties)) {
      const prop = propSchema as Record<string, unknown>;
      let zodType: z.ZodTypeAny;

      switch (prop.type) {
        case "string":
          zodType = z.string();
          break;
        case "number":
        case "integer":
          zodType = z.number();
          break;
        case "boolean":
          zodType = z.boolean();
          break;
        case "array":
          zodType = z.array(z.unknown());
          break;
        case "object":
          zodType = z.record(z.unknown());
          break;
        default:
          zodType = z.unknown();
      }

      // Add description if present
      if (prop.description) {
        zodType = zodType.describe(prop.description as string);
      }

      // Make optional if not required
      if (!required.includes(key)) {
        zodType = zodType.optional();
      }

      shape[key] = zodType;
    }

    return z.object(shape);
  }

  return z.object({});
}

// Build AI SDK tools from MCP tools
async function buildAiTools(mcpServerUrl?: string, mcpApiKey?: string) {
  const config = getConfig();
  const serverUrl = mcpServerUrl || config.mcpServerUrl;
  const apiKey = mcpApiKey || config.mcpApiKey;
  const mcpTools = await getTools(serverUrl, apiKey);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const aiTools: Record<string, any> = {};

  for (const mcpTool of mcpTools) {
    const toolName = mcpTool.name;

    aiTools[toolName] = tool({
      description: mcpTool.description || `Tool: ${toolName}`,
      inputSchema: jsonSchemaToZod(mcpTool.inputSchema),
      execute: async (args: Record<string, unknown>) => {
        console.log(`Executing tool: ${toolName}`, args);

        try {
          const result = await callMcpTool(
            serverUrl,
            apiKey,
            toolName,
            args
          );

          // Create canvas item for rich display
          const canvasType = getCanvasType(toolName);
          const title = extractTitle(toolName, result);
          const canvasItem = createCanvasItem(toolName, title, result);

          // Return both text and canvas item
          return {
            success: true,
            result,
            canvasItem,
            summary: `${title} - ${canvasType}`,
          };
        } catch (error) {
          console.error(`Tool ${toolName} failed:`, error);
          return {
            success: false,
            error: error instanceof Error ? error.message : "Tool execution failed",
          };
        }
      },
    });
  }

  return aiTools;
}

// System prompt for the assistant
function getSystemPrompt(enabledServers?: string[], xerCacheKey?: string | null): string {
  const config = getConfig();

  // Base identity
  let prompt = `You are ${config.siteTitle}${
    config.siteTagline ? ` - ${config.siteTagline}` : ""
  }.

You have access to specialized tools to help users with their tasks. When a user asks for something, use the appropriate tool to complete the request.`;

  // Add P6 context if XER file is uploaded
  if (xerCacheKey) {
    prompt += `

## CRITICAL - Primavera P6 Schedule Context
The user has uploaded a P6 schedule file that is ALREADY LOADED.

**YOU MUST include this parameter in EVERY pyp6xer tool call:**
cache_key: "${xerCacheKey}"

Examples of correct tool calls:
- pyp6xer_list_projects: { "cache_key": "${xerCacheKey}" }
- pyp6xer_critical_path: { "cache_key": "${xerCacheKey}" }
- pyp6xer_schedule_quality: { "cache_key": "${xerCacheKey}" }
- pyp6xer_float_analysis: { "cache_key": "${xerCacheKey}" }

**DO NOT call pyp6xer_load_file** - the file is already loaded.
**ALWAYS include cache_key="${xerCacheKey}"** in your tool parameters.`;
  }

  // Add Klavis-specific instructions when servers are available
  if (enabledServers && enabledServers.length > 0) {
    const serverList = enabledServers.map(s => `"${s}"`).join(", ");

    // Identify custom operators vs standard integrations
    // Custom operators can be identified by:
    // - Name contains "rootsup" or "roots up" (case insensitive)
    // - Name contains "pyp6xer" or "p6" (case insensitive)
    // - Name contains "directory" (case insensitive)
    // - Name ends with "assistant" or "_assistant" (case insensitive)
    const customOperators = enabledServers.filter(s => {
      const lower = s.toLowerCase();
      return (
        lower.includes("rootsup") ||
        lower.includes("roots up") ||
        lower.includes("pyp6xer") ||
        lower.includes("directory") ||
        lower.endsWith("assistant") ||
        lower.endsWith("_assistant")
      );
    });
    const standardServers = enabledServers.filter(s => !customOperators.includes(s));

    prompt += `

## Available Integrations
You have access to these servers: ${serverList}`;

    // Custom operators can be called directly
    if (customOperators.length > 0) {
      const operatorList = customOperators.map(s => `"${s}"`).join(", ");
      prompt += `

## Custom Operators (Direct Tools) - IMPORTANT
For ${operatorList}: These have dedicated tools you can call DIRECTLY.

**DO NOT use discover_server_categories_or_actions for these operators!**
**DO NOT use execute_action for these operators!**

Instead, call their tools directly by name:
- Roots Up: mcp__rootsup__rootsup_triage_inbox, mcp__rootsup__rootsup_create_invoice, mcp__rootsup__rootsup_draft_reply, etc.
- PyP6Xer: mcp__pyp6xer__pyp6xer_load_file, mcp__pyp6xer__pyp6xer_critical_path, etc.
- Directory: mcp__sample_directory__search_employees, etc.

These tools are ready to use - just call them with the required parameters.`;
    }

    // Standard integrations need Klavis discovery
    if (standardServers.length > 0) {
      prompt += `

## Standard Integrations (Klavis Discovery)
For standard servers, use the discover_server_categories_or_actions workflow:

1. **Use EXACT server names** - lowercase, must match exactly:
   - Use "hacker news" NOT "Hacker News" or "Hacker News API"
   - Use "google drive" NOT "Google Drive" or "GoogleDrive"
   - Use "gmail" NOT "Gmail" or "Gmail API"

2. **Follow the discovery workflow**:
   - First: discover_server_categories_or_actions to see what's available
   - Then: get_category_actions or get_action_details if needed
   - Finally: execute_action with the correct category and action names

3. **Parameters are JSON strings**:
   - body_schema='{"key": "value"}' (string, not object)
   - query_params='{"limit": 10}' (string, not object)`;
    }
  }

  prompt += `

## Guidelines
1. Choose the most appropriate tool for the task
2. Provide clear parameters based on user input
3. Present results clearly with context
4. Offer follow-up suggestions when helpful

Be helpful, professional, and efficient. Focus on completing tasks rather than lengthy explanations.

IMPORTANT: After using a tool, always summarize the results for the user. Never end your response with just a tool result.`;

  return prompt;
}

export async function POST(req: Request) {
  const config = getConfig();

  // Platform mode: route through PydanticAI Platform API
  if (config.mode === "platform") {
    return handlePlatformChat(req, config);
  }

  // Dynamic mode: fetch user's strata_url and use it as MCP server
  if (config.mode === "dynamic") {
    return handleDynamicChat(req, config);
  }

  // Standalone mode: direct MCP + LLM calls
  return handleStandaloneChat(req, config);
}

/**
 * Platform mode: Chat via PydanticAI Platform API
 *
 * The platform now accepts standard AI SDK format directly.
 * We simply proxy the request and response - no transformation needed.
 */
async function handlePlatformChat(req: Request, config: ReturnType<typeof getConfig>) {
  // Validate platform configuration
  if (!config.platformUrl || !config.platformApiKey) {
    return new Response(
      JSON.stringify({ error: "Platform not configured. Set PLATFORM_URL and PLATFORM_API_KEY." }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  try {
    // Forward the AI SDK format request directly to platform
    const body = await req.text();
    const parsed = JSON.parse(body) as {
      messages?: Array<{
        role: string;
        content?: string;
        parts?: Array<{ type: string; text?: string }>;
        id?: string;
      }>;
      conversationId?: string;
      xerCacheKey?: string | null;
    };

    // Transform AI SDK v5 messages (parts) to simple format (content)
    // AI SDK v5 sends: {role, parts: [{type: "text", text: "..."}]}
    // Platform expects: {role, content: "..."}
    const transformedMessages = parsed.messages?.map((msg) => {
      if (msg.parts && !msg.content) {
        // Extract text from parts array
        const textContent = msg.parts
          .filter((p) => p.type === "text" && p.text)
          .map((p) => p.text)
          .join("\n");
        return { role: msg.role, content: textContent };
      }
      return { role: msg.role, content: msg.content || "" };
    });

    console.log("Platform chat request:", {
      operator: config.platformOperator || "default",
      conversationId: parsed.conversationId,
      xerCacheKey: parsed.xerCacheKey || null,
      messageCount: transformedMessages?.length || 0,
    });

    // Platform now accepts AI SDK format natively
    const platformUrl = `${config.platformUrl}/api/v2/chat/stream`;

    // Build transformed request body
    const transformedBody = JSON.stringify({
      messages: transformedMessages,
      conversationId: parsed.conversationId,
      xerCacheKey: parsed.xerCacheKey,
      operator: config.platformOperator,
    });

    const platformResponse = await fetch(platformUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
        "Authorization": `Bearer ${config.platformApiKey}`,
      },
      body: transformedBody,
    });

    if (!platformResponse.ok) {
      const error = await platformResponse.text();
      console.error("Platform error:", platformResponse.status, error);
      return new Response(
        JSON.stringify({ error: `Platform error: ${platformResponse.status}` }),
        { status: platformResponse.status, headers: { "Content-Type": "application/json" } }
      );
    }

    // Return the platform's AI SDK response directly
    // This preserves the tool call structure needed for canvas
    return new Response(platformResponse.body, {
      headers: {
        "Content-Type": platformResponse.headers.get("Content-Type") || "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        // Critical: Forward the UI Message Stream header for useChat to parse correctly
        "x-vercel-ai-ui-message-stream": platformResponse.headers.get("x-vercel-ai-ui-message-stream") || "v1",
        // Pass through conversation ID from platform
        ...(platformResponse.headers.get("X-Conversation-Id") && {
          "X-Conversation-Id": platformResponse.headers.get("X-Conversation-Id")!,
        }),
      },
    });
  } catch (error) {
    console.error("Platform chat error:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "Internal server error",
      }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
}

/**
 * Standalone mode: Direct MCP + LLM calls
 * Used when not routing through the platform (development/testing)
 */
async function handleStandaloneChat(req: Request, config: ReturnType<typeof getConfig>) {
  // Validate standalone configuration
  if (!config.mcpServerUrl || !config.mcpApiKey) {
    return new Response(
      JSON.stringify({ error: "MCP server not configured. Set MCP_SERVER_URL and MCP_API_KEY." }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  // Check for appropriate API key based on model
  const isOpenAI = config.aiModel.startsWith("gpt-");
  if (isOpenAI && !process.env.OPENAI_API_KEY) {
    return new Response(
      JSON.stringify({ error: "OpenAI API key not configured. Set OPENAI_API_KEY." }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
  if (!isOpenAI && !config.anthropicApiKey) {
    return new Response(
      JSON.stringify({ error: "Anthropic API key not configured. Set ANTHROPIC_API_KEY." }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  try {
    const { messages, xerCacheKey }: { messages: UIMessage[]; xerCacheKey?: string | null } = await req.json();

    // Build tools dynamically from MCP server
    const tools = await buildAiTools();
    const toolCount = Object.keys(tools).length;

    if (toolCount === 0) {
      console.warn("No tools discovered from MCP server");
    }

    console.log("Standalone chat request:", {
      messageCount: messages?.length || 0,
      model: config.aiModel,
      toolCount,
      xerCacheKey: xerCacheKey || null,
    });

    const model = isOpenAI ? openai(config.aiModel) : anthropic(config.aiModel);

    const result = streamText({
      model,
      system: getSystemPrompt(undefined, xerCacheKey),
      messages: convertToModelMessages(messages),
      tools,
      stopWhen: stepCountIs(5), // Allow up to 5 steps for multi-step tool use
      onFinish: async ({ usage }) => {
        console.log("Chat completed:", {
          inputTokens: usage.inputTokens,
          outputTokens: usage.outputTokens,
        });
      },
    });

    return result.toUIMessageStreamResponse();
  } catch (error) {
    console.error("Standalone chat error:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "Internal server error",
      }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
}

/**
 * Dynamic mode: Fetch user's strata_url and use it as MCP server
 * Used for mcp-bridge.xyz multi-tenant deployment
 */
async function handleDynamicChat(req: Request, config: ReturnType<typeof getConfig>) {
  try {
    // Get user session
    const session = await getSession();
    if (!session?.access_token) {
      return new Response(
        JSON.stringify({ error: "Unauthorized - please log in" }),
        { status: 401, headers: { "Content-Type": "application/json" } }
      );
    }

    // Fetch user's MCP connection (strata_url)
    const connection = await fetchUserConnection(session.access_token);
    if (!connection.strata_url) {
      return new Response(
        JSON.stringify({
          error: "No integrations configured. Please enable integrations in the dashboard.",
        }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    // Parse request
    const { messages, xerCacheKey }: { messages: UIMessage[]; xerCacheKey?: string | null } = await req.json();

    console.log("Dynamic chat request:", {
      userId: session.user?.id,
      strataUrl: connection.strata_url.slice(0, 50) + "...",
      enabledServers: connection.enabled_servers?.length || 0,
      xerCacheKey: xerCacheKey || null,
    });

    // Build tools from user's strata_url (no additional auth needed - strata_id is embedded)
    const tools = await buildAiTools(connection.strata_url, "");
    const toolCount = Object.keys(tools).length;

    if (toolCount === 0) {
      console.warn("No tools discovered from user's strata");
    }

    // Check for appropriate API key based on model
    const isOpenAI = config.aiModel.startsWith("gpt-");
    if (isOpenAI && !process.env.OPENAI_API_KEY) {
      return new Response(
        JSON.stringify({ error: "OpenAI API key not configured." }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }
    if (!isOpenAI && !config.anthropicApiKey) {
      return new Response(
        JSON.stringify({ error: "Anthropic API key not configured." }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }

    const model = isOpenAI ? openai(config.aiModel) : anthropic(config.aiModel);

    const result = streamText({
      model,
      system: getSystemPrompt(connection.enabled_servers, xerCacheKey),
      messages: convertToModelMessages(messages),
      tools,
      stopWhen: stepCountIs(5),
      onFinish: async ({ usage }) => {
        console.log("Dynamic chat completed:", {
          userId: session.user?.id,
          inputTokens: usage.inputTokens,
          outputTokens: usage.outputTokens,
        });
      },
    });

    return result.toUIMessageStreamResponse();
  } catch (error) {
    console.error("Dynamic chat error:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "Internal server error",
      }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
}
