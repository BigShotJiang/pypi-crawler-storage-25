import { NextResponse } from "next/server";
import { getSession } from "@/lib/supabase/server";
import { fetchUserConnection } from "@/lib/user-connection";

/**
 * GET /api/user-connection
 * Fetches the current user's MCP connection (strata_url) from mcp-bridge API
 */
export async function GET() {
  try {
    const session = await getSession();

    if (!session?.access_token) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const connection = await fetchUserConnection(session.access_token);
    return NextResponse.json(connection);
  } catch (error) {
    console.error("Error fetching user connection:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Internal error" },
      { status: 500 }
    );
  }
}
