"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/components/providers/AuthProvider";
import type { UserConnection } from "@/lib/user-connection";

interface UseUserConnectionResult {
  connection: UserConnection | null;
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

/**
 * Hook to fetch the current user's MCP connection (strata_url)
 * Only fetches when MCP_BRIDGE_MODE is enabled and user is authenticated
 */
export function useUserConnection(): UseUserConnectionResult {
  const { session, loading: authLoading } = useAuth();
  const [connection, setConnection] = useState<UserConnection | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchConnection = async () => {
    if (!session?.access_token) {
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Fetch via our API route (handles server-side auth)
      const res = await fetch("/api/user-connection");
      if (!res.ok) {
        throw new Error(`Failed to fetch connection: ${res.status}`);
      }
      const data = await res.json();
      setConnection(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch connection");
      setConnection(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!authLoading && session) {
      fetchConnection();
    } else if (!authLoading && !session) {
      setLoading(false);
    }
  }, [authLoading, session?.access_token]);

  return {
    connection,
    loading: authLoading || loading,
    error,
    refetch: fetchConnection,
  };
}
