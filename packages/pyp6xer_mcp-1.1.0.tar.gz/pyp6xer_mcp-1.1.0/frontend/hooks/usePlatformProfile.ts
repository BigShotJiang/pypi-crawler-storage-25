/**
 * Hook for managing user profile and Browse/Act pattern
 *
 * Option C (Hybrid):
 * - Browse: Direct calls to user's strata_url (fast, no LLM)
 * - Act: Platform chat endpoint (LLM-mediated)
 */

import { useState, useEffect, useCallback } from "react";
import { type UserProfile } from "@/lib/platform-client";

export interface UsePlatformProfileResult {
  // Profile state
  profile: UserProfile | null;
  isLoading: boolean;
  error: string | null;

  // Strata state
  hasStrata: boolean;
  strataUrl: string | null;
  enabledServers: string[];

  // Actions
  refreshProfile: () => Promise<void>;
  browseCall: <T = Record<string, unknown>>(
    toolName: string,
    args: Record<string, unknown>
  ) => Promise<T>;
}

export function usePlatformProfile(): UsePlatformProfileResult {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load profile on mount via local API route (keeps API keys server-side)
  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Call our server-side API route (not platform directly)
      const response = await fetch("/api/profile");

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || `HTTP ${response.status}`);
      }

      const userProfile: UserProfile = await response.json();
      setProfile(userProfile);
    } catch (err) {
      console.error("Failed to load profile:", err);
      setError(err instanceof Error ? err.message : "Failed to load profile");
    } finally {
      setIsLoading(false);
    }
  }, []);

  const refreshProfile = useCallback(async () => {
    await loadProfile();
  }, [loadProfile]);

  /**
   * Browse call - proxied through /api/browse (server-side, no CORS issues!)
   *
   * Use for read operations:
   * - browseCall("gmail_search_emails", { query: "is:unread" })
   * - browseCall("calendar_list_events", { date: "today" })
   */
  const browseCall = useCallback(
    async <T = Record<string, unknown>>(
      toolName: string,
      args: Record<string, unknown>
    ): Promise<T> => {
      // Proxy through our server-side route (avoids CORS)
      const response = await fetch("/api/browse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ toolName, args }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || `HTTP ${response.status}`);
      }

      return response.json();
    },
    []
  );

  return {
    profile,
    isLoading,
    error,
    hasStrata: profile?.has_strata || false,
    strataUrl: profile?.strata_url || null,
    enabledServers: profile?.enabled_servers || [],
    refreshProfile,
    browseCall,
  };
}
