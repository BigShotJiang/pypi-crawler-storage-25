/**
 * Prompt shown when user hasn't connected their OAuth apps
 * Redirects to mcp-bridge.xyz for OAuth setup
 */

import { ExternalLink, Mail, Calendar, MessageSquare, HardDrive, X } from "lucide-react";

export interface ConnectAppsPromptProps {
  /** Custom message to display */
  message?: string;
  /** Redirect URL for OAuth setup */
  connectUrl?: string;
  /** Callback when user clicks connect */
  onConnect?: () => void;
  /** Callback to close the modal (if used as modal) */
  onClose?: () => void;
  /** Whether to show as a modal overlay */
  asModal?: boolean;
}

export function ConnectAppsPrompt({
  message = "Connect your apps to get started",
  connectUrl = "https://mcp-bridge.xyz/app",
  onConnect,
  onClose,
  asModal = true,
}: ConnectAppsPromptProps) {
  const handleConnect = () => {
    if (onConnect) {
      onConnect();
    }
    // Open in new tab for OAuth flow
    window.open(connectUrl, "_blank");
  };

  const content = (
    <div className="relative flex flex-col items-center justify-center p-8 text-center bg-white rounded-xl shadow-xl max-w-md w-full">
      {/* Close button */}
      {onClose && (
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X className="h-5 w-5" />
        </button>
      )}
      <div className="rounded-full bg-blue-100 p-4 mb-4">
        <ExternalLink className="h-8 w-8 text-blue-600" />
      </div>

      <h2 className="text-xl font-semibold text-gray-900 mb-2">
        {message}
      </h2>

      <p className="text-gray-600 mb-6 max-w-md">
        Connect your Gmail, Calendar, Slack, and other apps to enable
        AI-powered workflows. Your data stays secure with OAuth.
      </p>

      {/* App icons */}
      <div className="flex gap-4 mb-6">
        <div className="flex flex-col items-center">
          <div className="rounded-lg bg-red-100 p-2">
            <Mail className="h-6 w-6 text-red-600" />
          </div>
          <span className="text-xs text-gray-500 mt-1">Gmail</span>
        </div>
        <div className="flex flex-col items-center">
          <div className="rounded-lg bg-blue-100 p-2">
            <Calendar className="h-6 w-6 text-blue-600" />
          </div>
          <span className="text-xs text-gray-500 mt-1">Calendar</span>
        </div>
        <div className="flex flex-col items-center">
          <div className="rounded-lg bg-purple-100 p-2">
            <MessageSquare className="h-6 w-6 text-purple-600" />
          </div>
          <span className="text-xs text-gray-500 mt-1">Slack</span>
        </div>
        <div className="flex flex-col items-center">
          <div className="rounded-lg bg-green-100 p-2">
            <HardDrive className="h-6 w-6 text-green-600" />
          </div>
          <span className="text-xs text-gray-500 mt-1">Drive</span>
        </div>
      </div>

      <button
        onClick={handleConnect}
        className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-6 py-3 text-white font-medium hover:bg-blue-700 transition-colors"
      >
        <ExternalLink className="h-4 w-4" />
        Connect Apps
      </button>

      <p className="text-xs text-gray-400 mt-4">
        You&apos;ll be redirected to complete OAuth authorization
      </p>
    </div>
  );

  // Render as modal overlay or inline content
  if (asModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-black/50"
          onClick={onClose}
        />
        {/* Content */}
        {content}
      </div>
    );
  }

  return content;
}
