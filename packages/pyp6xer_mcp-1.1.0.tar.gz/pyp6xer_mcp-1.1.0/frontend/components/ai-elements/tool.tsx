"use client";

import { cn } from "@/lib/utils";
import * as Collapsible from "@radix-ui/react-collapsible";
import {
  CheckCircleIcon,
  ChevronDownIcon,
  LoaderIcon,
  WrenchIcon,
  XCircleIcon,
} from "lucide-react";
import type { ComponentProps } from "react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export type ToolStatus = "pending" | "running" | "completed" | "failed";

export type ToolProps = ComponentProps<typeof Collapsible.Root> & {
  name: string;
  status?: ToolStatus;
  description?: string;
};

export const Tool = ({
  className,
  children,
  name,
  status = "pending",
  description,
  ...props
}: ToolProps) => {
  const [open, setOpen] = useState(false);

  const statusIcon = {
    pending: <WrenchIcon className="size-4 text-muted-foreground" />,
    running: <LoaderIcon className="size-4 text-blue-500 animate-spin" />,
    completed: <CheckCircleIcon className="size-4 text-green-500" />,
    failed: <XCircleIcon className="size-4 text-destructive" />,
  };

  return (
    <Collapsible.Root
      className={cn(
        "rounded-lg border bg-muted/30",
        status === "running" && "border-blue-500/50",
        status === "completed" && "border-green-500/50",
        status === "failed" && "border-destructive/50",
        className
      )}
      open={open}
      onOpenChange={setOpen}
      {...props}
    >
      <Collapsible.Trigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-between px-3 py-2 h-auto font-normal"
        >
          <span className="flex items-center gap-2 text-sm">
            {statusIcon[status]}
            <span className="font-medium">{name}</span>
            {description && (
              <span className="text-muted-foreground">— {description}</span>
            )}
          </span>
          <ChevronDownIcon className="size-4 transition-transform duration-200 [[data-state=open]>&]:rotate-180" />
        </Button>
      </Collapsible.Trigger>
      <Collapsible.Content className="overflow-hidden">
        <div className="px-3 pb-3 pt-1">{children}</div>
      </Collapsible.Content>
    </Collapsible.Root>
  );
};

export type ToolInputProps = ComponentProps<"div"> & {
  parameters?: Record<string, unknown>;
};

export const ToolInput = ({ className, parameters, ...props }: ToolInputProps) => (
  <div className={cn("space-y-1", className)} {...props}>
    <p className="text-xs font-medium text-muted-foreground">Input</p>
    <pre className="text-xs bg-muted rounded p-2 overflow-x-auto">
      {JSON.stringify(parameters, null, 2)}
    </pre>
  </div>
);

export type ToolOutputProps = ComponentProps<"div"> & {
  result?: unknown;
  error?: string;
};

export const ToolOutput = ({
  className,
  result,
  error,
  ...props
}: ToolOutputProps) => (
  <div className={cn("space-y-1 mt-2", className)} {...props}>
    <p className="text-xs font-medium text-muted-foreground">
      {error ? "Error" : "Output"}
    </p>
    <pre
      className={cn(
        "text-xs rounded p-2 overflow-x-auto",
        error ? "bg-destructive/10 text-destructive" : "bg-muted"
      )}
    >
      {error || JSON.stringify(result, null, 2)}
    </pre>
  </div>
);
