"use client";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { SendIcon, StopCircleIcon } from "lucide-react";
import type { ComponentProps, FormEvent } from "react";
import { createContext, useContext, useState } from "react";

// Context for form state
type PromptInputContextType = {
  isSubmitting: boolean;
  setIsSubmitting: (value: boolean) => void;
};

const PromptInputContext = createContext<PromptInputContextType | null>(null);

const usePromptInput = () => {
  const context = useContext(PromptInputContext);
  if (!context) {
    throw new Error("PromptInput components must be used within PromptInput");
  }
  return context;
};

export type PromptInputProps = ComponentProps<"form"> & {
  onSubmit?: (message: { text: string }) => void;
};

export const PromptInput = ({
  className,
  children,
  onSubmit,
  ...props
}: PromptInputProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const text = formData.get("prompt") as string;
    if (text?.trim() && onSubmit) {
      onSubmit({ text: text.trim() });
      e.currentTarget.reset();
    }
  };

  return (
    <PromptInputContext.Provider value={{ isSubmitting, setIsSubmitting }}>
      <form
        className={cn(
          "relative flex items-end gap-2 rounded-2xl border bg-background p-2 shadow-sm",
          className
        )}
        onSubmit={handleSubmit}
        {...props}
      >
        {children}
      </form>
    </PromptInputContext.Provider>
  );
};

export type PromptInputTextareaProps = ComponentProps<"textarea">;

export const PromptInputTextarea = ({
  className,
  ...props
}: PromptInputTextareaProps) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      const form = e.currentTarget.form;
      if (form) {
        form.requestSubmit();
      }
    }
  };

  return (
    <textarea
      name="prompt"
      className={cn(
        "flex-1 resize-none bg-transparent px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none disabled:cursor-not-allowed disabled:opacity-50",
        "min-h-[44px] max-h-[200px]",
        className
      )}
      placeholder="Ask anything..."
      rows={1}
      onKeyDown={handleKeyDown}
      {...props}
    />
  );
};

export type PromptInputSubmitProps = ComponentProps<typeof Button> & {
  status?: "ready" | "streaming" | "submitted";
  onStop?: () => void;
};

export const PromptInputSubmit = ({
  className,
  status = "ready",
  onStop,
  ...props
}: PromptInputSubmitProps) => {
  if (status === "streaming") {
    return (
      <Button
        type="button"
        size="icon"
        variant="ghost"
        className={cn("shrink-0", className)}
        onClick={onStop}
        {...props}
      >
        <StopCircleIcon className="size-5" />
        <span className="sr-only">Stop generating</span>
      </Button>
    );
  }

  return (
    <Button
      type="submit"
      size="icon"
      className={cn("shrink-0", className)}
      disabled={status === "submitted"}
      {...props}
    >
      <SendIcon className="size-4" />
      <span className="sr-only">Send message</span>
    </Button>
  );
};
