"use client";

import { cn } from "@/lib/utils";
import type { ComponentProps } from "react";

export type LoaderProps = ComponentProps<"div">;

export const Loader = ({ className, ...props }: LoaderProps) => (
  <div
    className={cn("flex items-center gap-1", className)}
    {...props}
  >
    <span className="size-2 rounded-full bg-muted-foreground/50 animate-bounce [animation-delay:-0.3s]" />
    <span className="size-2 rounded-full bg-muted-foreground/50 animate-bounce [animation-delay:-0.15s]" />
    <span className="size-2 rounded-full bg-muted-foreground/50 animate-bounce" />
  </div>
);

export type LoaderTextProps = ComponentProps<"div"> & {
  text?: string;
};

export const LoaderText = ({
  className,
  text = "Thinking...",
  ...props
}: LoaderTextProps) => (
  <div
    className={cn("flex items-center gap-3 text-sm text-muted-foreground", className)}
    {...props}
  >
    <Loader />
    <span>{text}</span>
  </div>
);
