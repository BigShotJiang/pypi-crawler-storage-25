"use client";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import * as Collapsible from "@radix-ui/react-collapsible";
import { ChevronDownIcon, ExternalLinkIcon, FileTextIcon } from "lucide-react";
import type { ComponentProps } from "react";
import { useState } from "react";

export type SourcesProps = ComponentProps<typeof Collapsible.Root>;

export const Sources = ({ className, children, ...props }: SourcesProps) => {
  const [open, setOpen] = useState(false);

  return (
    <Collapsible.Root
      className={cn("rounded-lg border bg-muted/50", className)}
      open={open}
      onOpenChange={setOpen}
      {...props}
    >
      {children}
    </Collapsible.Root>
  );
};

export type SourcesTriggerProps = ComponentProps<typeof Collapsible.Trigger> & {
  count?: number;
};

export const SourcesTrigger = ({
  className,
  count,
  ...props
}: SourcesTriggerProps) => (
  <Collapsible.Trigger asChild>
    <Button
      variant="ghost"
      size="sm"
      className={cn(
        "w-full justify-between px-3 py-2 h-auto font-normal",
        className
      )}
      {...props}
    >
      <span className="flex items-center gap-2 text-sm">
        <FileTextIcon className="size-4" />
        {count ? `${count} sources` : "Sources"}
      </span>
      <ChevronDownIcon className="size-4 transition-transform duration-200 [[data-state=open]>&]:rotate-180" />
    </Button>
  </Collapsible.Trigger>
);

export type SourcesContentProps = ComponentProps<typeof Collapsible.Content>;

export const SourcesContent = ({
  className,
  children,
  ...props
}: SourcesContentProps) => (
  <Collapsible.Content
    className={cn(
      "overflow-hidden data-[state=closed]:animate-collapse-up data-[state=open]:animate-collapse-down",
      className
    )}
    {...props}
  >
    <div className="px-3 pb-3 pt-1 space-y-2">{children}</div>
  </Collapsible.Content>
);

export type SourceProps = ComponentProps<"a"> & {
  title: string;
  href: string;
  description?: string;
};

export const Source = ({
  className,
  title,
  href,
  description,
  ...props
}: SourceProps) => (
  <a
    href={href}
    target="_blank"
    rel="noopener noreferrer"
    className={cn(
      "flex items-start gap-3 rounded-md p-2 text-sm hover:bg-muted transition-colors",
      className
    )}
    {...props}
  >
    <ExternalLinkIcon className="size-4 mt-0.5 shrink-0 text-muted-foreground" />
    <div className="flex-1 min-w-0">
      <p className="font-medium truncate">{title}</p>
      {description && (
        <p className="text-xs text-muted-foreground line-clamp-2">{description}</p>
      )}
    </div>
  </a>
);
