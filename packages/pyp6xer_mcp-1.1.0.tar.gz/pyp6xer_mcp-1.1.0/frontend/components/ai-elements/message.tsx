"use client";

import { cn } from "@/lib/utils";
import type { UIMessage } from "ai";
import type { ComponentProps, HTMLAttributes } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

export type MessageProps = HTMLAttributes<HTMLDivElement> & {
  from: UIMessage["role"];
};

export const Message = ({ className, from, ...props }: MessageProps) => (
  <div
    className={cn(
      "group flex w-full max-w-3xl flex-col gap-2",
      from === "user" ? "is-user ml-auto items-end" : "is-assistant",
      className
    )}
    {...props}
  />
);

export type MessageContentProps = HTMLAttributes<HTMLDivElement>;

export const MessageContent = ({
  children,
  className,
  ...props
}: MessageContentProps) => (
  <div
    className={cn(
      "flex w-fit flex-col gap-2 overflow-hidden text-sm",
      "group-[.is-user]:ml-auto group-[.is-user]:rounded-2xl group-[.is-user]:bg-primary group-[.is-user]:px-4 group-[.is-user]:py-3 group-[.is-user]:text-primary-foreground",
      "group-[.is-assistant]:text-foreground",
      className
    )}
    {...props}
  >
    {children}
  </div>
);

export type MessageResponseProps = ComponentProps<"div"> & {
  children: string;
};

export const MessageResponse = ({
  children,
  className,
  ...props
}: MessageResponseProps) => (
  <div className={cn("prose-chat", className)} {...props}>
    <ReactMarkdown remarkPlugins={[remarkGfm]}>{children}</ReactMarkdown>
  </div>
);

export type MessageLabelProps = HTMLAttributes<HTMLDivElement>;

export const MessageLabel = ({ className, children, ...props }: MessageLabelProps) => (
  <div
    className={cn(
      "text-xs font-medium text-muted-foreground uppercase tracking-wide",
      className
    )}
    {...props}
  >
    {children}
  </div>
);
