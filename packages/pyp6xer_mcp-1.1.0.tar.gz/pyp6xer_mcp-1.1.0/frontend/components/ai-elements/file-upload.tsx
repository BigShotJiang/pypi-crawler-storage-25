"use client";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { FileIcon, UploadCloudIcon, XIcon, CheckCircleIcon, AlertCircleIcon, Loader2Icon } from "lucide-react";
import type { ComponentProps, DragEvent, ChangeEvent } from "react";
import { useState, useRef, useCallback } from "react";

export type UploadedFile = {
  cache_key: string;
  filename: string;
  size: number;
};

export type FileUploadStatus = "idle" | "uploading" | "success" | "error";

export type FileUploadProps = ComponentProps<"div"> & {
  onUploadComplete?: (file: UploadedFile) => void;
  onUploadError?: (error: string) => void;
  onRemove?: () => void;
  uploadUrl?: string;
  accept?: string;
  maxSize?: number; // in MB
};

export const FileUpload = ({
  className,
  onUploadComplete,
  onUploadError,
  onRemove,
  uploadUrl = "/api/upload",
  accept = ".xer",
  maxSize = 50,
  ...props
}: FileUploadProps) => {
  const [status, setStatus] = useState<FileUploadStatus>("idle");
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): string | null => {
    const extension = file.name.toLowerCase().split(".").pop();
    const acceptedTypes = accept.split(",").map((t) => t.trim().replace(".", ""));

    if (!acceptedTypes.includes(extension || "")) {
      return `Invalid file type. Please upload ${accept} files.`;
    }

    if (file.size > maxSize * 1024 * 1024) {
      return `File too large. Maximum size is ${maxSize}MB.`;
    }

    return null;
  };

  const uploadFile = async (file: File) => {
    const validationError = validateFile(file);
    if (validationError) {
      setError(validationError);
      setStatus("error");
      onUploadError?.(validationError);
      return;
    }

    setStatus("uploading");
    setError(null);
    setProgress(0);

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch(uploadUrl, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Upload failed: ${response.statusText}`);
      }

      const data = await response.json();
      const uploaded: UploadedFile = {
        cache_key: data.cache_key,
        filename: file.name,
        size: file.size,
      };

      setUploadedFile(uploaded);
      setStatus("success");
      setProgress(100);
      onUploadComplete?.(uploaded);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Upload failed";
      setError(message);
      setStatus("error");
      onUploadError?.(message);
    }
  };

  const handleDrag = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      uploadFile(e.dataTransfer.files[0]);
    }
  }, []);

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      uploadFile(e.target.files[0]);
    }
  };

  const handleRemove = () => {
    setUploadedFile(null);
    setStatus("idle");
    setError(null);
    setProgress(0);
    if (inputRef.current) {
      inputRef.current.value = "";
    }
    onRemove?.();
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // Show uploaded file state
  if (status === "success" && uploadedFile) {
    return (
      <div
        className={cn(
          "flex items-center gap-3 rounded-lg border bg-green-50 dark:bg-green-950/20 p-3",
          className
        )}
        {...props}
      >
        <CheckCircleIcon className="size-5 text-green-600 shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{uploadedFile.filename}</p>
          <p className="text-xs text-muted-foreground">
            {formatFileSize(uploadedFile.size)} • Ready for analysis
          </p>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="shrink-0 size-8"
          onClick={handleRemove}
        >
          <XIcon className="size-4" />
          <span className="sr-only">Remove file</span>
        </Button>
      </div>
    );
  }

  // Show uploading state
  if (status === "uploading") {
    return (
      <div
        className={cn(
          "flex items-center gap-3 rounded-lg border bg-blue-50 dark:bg-blue-950/20 p-3",
          className
        )}
        {...props}
      >
        <Loader2Icon className="size-5 text-blue-600 animate-spin shrink-0" />
        <div className="flex-1">
          <p className="text-sm font-medium">Uploading...</p>
          <div className="mt-1 h-1.5 w-full rounded-full bg-blue-200 dark:bg-blue-900">
            <div
              className="h-full rounded-full bg-blue-600 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>
    );
  }

  // Show error state
  if (status === "error" && error) {
    return (
      <div
        className={cn(
          "flex items-center gap-3 rounded-lg border border-red-200 bg-red-50 dark:bg-red-950/20 p-3",
          className
        )}
        {...props}
      >
        <AlertCircleIcon className="size-5 text-red-600 shrink-0" />
        <div className="flex-1">
          <p className="text-sm font-medium text-red-800 dark:text-red-200">{error}</p>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={handleRemove}
        >
          Try again
        </Button>
      </div>
    );
  }

  // Default idle/drag state
  return (
    <div
      className={cn(
        "relative rounded-lg border-2 border-dashed p-4 transition-colors",
        dragActive
          ? "border-primary bg-primary/5"
          : "border-muted-foreground/25 hover:border-muted-foreground/50",
        className
      )}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
      {...props}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        onChange={handleChange}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
      />
      <div className="flex flex-col items-center gap-2 text-center pointer-events-none">
        <div className="rounded-full bg-muted p-3">
          <UploadCloudIcon className="size-6 text-muted-foreground" />
        </div>
        <div>
          <p className="text-sm font-medium">
            {dragActive ? "Drop your file here" : "Upload P6 Schedule"}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Drag & drop or click to browse • XER files up to {maxSize}MB
          </p>
        </div>
      </div>
    </div>
  );
};

// Compact version for inline use
export type FileUploadCompactProps = Omit<FileUploadProps, "className"> & {
  className?: string;
};

export const FileUploadCompact = ({
  className,
  ...props
}: FileUploadCompactProps) => {
  return (
    <FileUpload
      className={cn("p-2", className)}
      {...props}
    />
  );
};
