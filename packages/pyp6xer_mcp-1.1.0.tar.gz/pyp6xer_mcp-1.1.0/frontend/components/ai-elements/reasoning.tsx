"use client";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import * as Collapsible from "@radix-ui/react-collapsible";
import { BrainIcon, ChevronDownIcon } from "lucide-react";
import type { ComponentProps } from "react";
import { useState } from "react";

export type ReasoningProps = ComponentProps<typeof Collapsible.Root> & {
  duration?: number;
  isStreaming?: boolean;
};

export const Reasoning = ({
  className,
  children,
  duration,
  isStreaming,
  ...props
}: ReasoningProps) => {
  const [open, setOpen] = useState(false);

  return (
    <Collapsible.Root
      className={cn(
        "rounded-lg border border-dashed bg-muted/30",
        isStreaming && "animate-pulse",
        className
      )}
      open={open}
      onOpenChange={setOpen}
      {...props}
    >
      {children}
    </Collapsible.Root>
  );
};

export type ReasoningTriggerProps = ComponentProps<typeof Collapsible.Trigger> & {
  duration?: number;
};

export const ReasoningTrigger = ({
  className,
  duration,
  ...props
}: ReasoningTriggerProps) => (
  <Collapsible.Trigger asChild>
    <Button
      variant="ghost"
      size="sm"
      className={cn(
        "w-full justify-between px-3 py-2 h-auto font-normal",
        className
      )}
      {...props}
    >
      <span className="flex items-center gap-2 text-sm text-muted-foreground">
        <BrainIcon className="size-4" />
        Reasoning
        {duration && (
          <span className="text-xs">({(duration / 1000).toFixed(1)}s)</span>
        )}
      </span>
      <ChevronDownIcon className="size-4 transition-transform duration-200 [[data-state=open]>&]:rotate-180" />
    </Button>
  </Collapsible.Trigger>
);

export type ReasoningContentProps = ComponentProps<typeof Collapsible.Content>;

export const ReasoningContent = ({
  className,
  children,
  ...props
}: ReasoningContentProps) => (
  <Collapsible.Content
    className={cn(
      "overflow-hidden data-[state=closed]:animate-collapse-up data-[state=open]:animate-collapse-down",
      className
    )}
    {...props}
  >
    <div className="px-3 pb-3 pt-1">
      <pre className="text-xs text-muted-foreground whitespace-pre-wrap font-mono">
        {children}
      </pre>
    </div>
  </Collapsible.Content>
);
