"use client";

import { cn } from "@/lib/utils";
import { ArrowRightIcon } from "lucide-react";
import type { ComponentProps } from "react";

export type SuggestionsProps = ComponentProps<"div">;

export const Suggestions = ({ className, children, ...props }: SuggestionsProps) => (
  <div
    className={cn("flex flex-wrap gap-2", className)}
    {...props}
  >
    {children}
  </div>
);

export type SuggestionProps = ComponentProps<"button"> & {
  suggestion: string;
};

export const Suggestion = ({
  className,
  suggestion,
  ...props
}: SuggestionProps) => (
  <button
    type="button"
    className={cn(
      "inline-flex items-center gap-2 rounded-full border bg-background px-4 py-2 text-sm",
      "hover:bg-muted hover:border-primary/50 transition-colors",
      "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
      className
    )}
    {...props}
  >
    {suggestion}
    <ArrowRightIcon className="size-3 text-muted-foreground" />
  </button>
);
