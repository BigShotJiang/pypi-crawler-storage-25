'use client';

import { useState, useCallback } from 'react';
import { Upload, FileText, CheckCircle, XCircle, Loader2 } from 'lucide-react';

interface XerUploadProps {
  onUploadComplete: (cacheKey: string, metadata: XerMetadata) => void;
  onError?: (error: string) => void;
}

interface XerMetadata {
  cache_key: string;
  projects: Array<{ id: string; short_name: string }>;
  activity_count: number;
  message: string;
}

type UploadStatus = 'idle' | 'uploading' | 'success' | 'error';

export function XerUpload({ onUploadComplete, onError }: XerUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<UploadStatus>('idle');
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [metadata, setMetadata] = useState<XerMetadata | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleUpload = useCallback(async (selectedFile: File) => {
    if (!selectedFile) return;

    // Validate file type
    if (!selectedFile.name.toLowerCase().endsWith('.xer')) {
      const errorMsg = 'Please upload a valid .xer file';
      setError(errorMsg);
      setStatus('error');
      onError?.(errorMsg);
      return;
    }

    // Validate file size (max 50MB)
    const maxSize = 50 * 1024 * 1024; // 50MB
    if (selectedFile.size > maxSize) {
      const errorMsg = 'File size exceeds 50MB limit';
      setError(errorMsg);
      setStatus('error');
      onError?.(errorMsg);
      return;
    }

    setFile(selectedFile);
    setStatus('uploading');
    setProgress(0);
    setError(null);

    try {
      // Create FormData
      const formData = new FormData();
      formData.append('file', selectedFile);

      // Simulate progress (upload happens quickly, but gives user feedback)
      const progressInterval = setInterval(() => {
        setProgress((prev) => Math.min(prev + 10, 90));
      }, 100);

      // Upload to PyP6Xer MCP server (URL from config, falls back to relative /upload)
      const config = typeof window !== 'undefined' ? (window as any).__CONFIG__ : {};
      const uploadUrl = config?.uploadEndpoint || '/upload';
      const response = await fetch(uploadUrl, {
        method: 'POST',
        body: formData,
      });

      clearInterval(progressInterval);
      setProgress(100);

      if (!response.ok) {
        throw new Error(`Upload failed: ${response.statusText}`);
      }

      const data: XerMetadata = await response.json();

      if (data.cache_key) {
        setMetadata(data);
        setStatus('success');
        onUploadComplete(data.cache_key, data);
      } else {
        throw new Error('No cache_key returned from server');
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Upload failed';
      setError(errorMsg);
      setStatus('error');
      onError?.(errorMsg);
    }
  }, [onUploadComplete, onError]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      handleUpload(selectedFile);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      handleUpload(droppedFile);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const resetUpload = () => {
    setFile(null);
    setStatus('idle');
    setProgress(0);
    setError(null);
    setMetadata(null);
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4">
      {/* Upload Zone */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`
          relative border-2 border-dashed rounded-lg p-8 text-center transition-all
          ${isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}
          ${status === 'uploading' ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
        `}
      >
        <input
          type="file"
          accept=".xer"
          onChange={handleFileSelect}
          disabled={status === 'uploading'}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          id="xer-upload"
        />

        <div className="space-y-4">
          {/* Icon */}
          <div className="flex justify-center">
            {status === 'idle' && (
              <Upload className="w-12 h-12 text-gray-400" />
            )}
            {status === 'uploading' && (
              <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
            )}
            {status === 'success' && (
              <CheckCircle className="w-12 h-12 text-green-500" />
            )}
            {status === 'error' && (
              <XCircle className="w-12 h-12 text-red-500" />
            )}
          </div>

          {/* Text */}
          <div>
            {status === 'idle' && (
              <>
                <p className="text-lg font-semibold text-gray-700">
                  Upload Primavera P6 Schedule
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  Drag & drop your .xer file here, or click to browse
                </p>
                <p className="text-xs text-gray-400 mt-2">
                  Maximum file size: 50MB
                </p>
              </>
            )}

            {status === 'uploading' && (
              <>
                <p className="text-lg font-semibold text-gray-700">
                  Uploading {file?.name}
                </p>
                <div className="mt-4 max-w-xs mx-auto">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-sm text-gray-500 mt-2">{progress}%</p>
                </div>
              </>
            )}

            {status === 'success' && metadata && (
              <>
                <p className="text-lg font-semibold text-green-700">
                  Upload Successful!
                </p>
                <div className="mt-4 text-sm text-left bg-green-50 border border-green-200 rounded p-4 max-w-md mx-auto">
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <FileText className="w-4 h-4 text-green-600 mt-0.5" />
                      <div>
                        <p className="font-medium text-gray-700">{file?.name}</p>
                        <p className="text-xs text-gray-500">
                          {metadata.activity_count.toLocaleString()} activities
                        </p>
                      </div>
                    </div>
                    {metadata.projects.length > 0 && (
                      <div className="text-xs text-gray-600">
                        <span className="font-medium">Projects:</span>{' '}
                        {metadata.projects.map(p => p.short_name).join(', ')}
                      </div>
                    )}
                    <div className="text-xs text-gray-500 font-mono bg-white px-2 py-1 rounded">
                      Cache: {metadata.cache_key}
                    </div>
                  </div>
                </div>
                <button
                  onClick={resetUpload}
                  className="mt-4 text-sm text-blue-600 hover:text-blue-700 underline"
                >
                  Upload another file
                </button>
              </>
            )}

            {status === 'error' && (
              <>
                <p className="text-lg font-semibold text-red-700">
                  Upload Failed
                </p>
                <p className="text-sm text-red-600 mt-2">{error}</p>
                <button
                  onClick={resetUpload}
                  className="mt-4 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                >
                  Try Again
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Helper Text */}
      {status === 'idle' && (
        <div className="text-xs text-gray-500 space-y-1">
          <p>• Supports Primavera P6 XER format (R8.1 and later)</p>
          <p>• Files are processed securely and cached for analysis</p>
          <p>• Your schedule data remains private</p>
        </div>
      )}
    </div>
  );
}
