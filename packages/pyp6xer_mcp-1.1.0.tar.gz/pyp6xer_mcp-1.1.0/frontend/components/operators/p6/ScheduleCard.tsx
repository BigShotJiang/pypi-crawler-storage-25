'use client';

import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import {
  Activity,
  AlertTriangle,
  CheckCircle,
  ChevronDown,
  ChevronUp,
  Copy,
} from 'lucide-react';

interface MetricCardProps {
  label: string;
  value: number | string;
  total?: number;
  status?: 'good' | 'warning' | 'danger' | 'neutral';
  suffix?: string;
}

function MetricCard({ label, value, total, status = 'neutral', suffix }: MetricCardProps) {
  const statusColors = {
    good: 'bg-green-50 border-green-200 text-green-700',
    warning: 'bg-yellow-50 border-yellow-200 text-yellow-700',
    danger: 'bg-red-50 border-red-200 text-red-700',
    neutral: 'bg-gray-50 border-gray-200 text-gray-700',
  };

  const statusIcons = {
    good: <CheckCircle className="size-4 text-green-500" />,
    warning: <AlertTriangle className="size-4 text-yellow-500" />,
    danger: <AlertTriangle className="size-4 text-red-500" />,
    neutral: <Activity className="size-4 text-gray-500" />,
  };

  return (
    <div className={`rounded-lg border p-3 ${statusColors[status]}`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium opacity-75">{label}</span>
        {statusIcons[status]}
      </div>
      <div className="mt-1 flex items-baseline gap-1">
        <span className="text-2xl font-bold">{value}</span>
        {total !== undefined && (
          <span className="text-sm opacity-60">/ {total}</span>
        )}
        {suffix && <span className="text-sm opacity-60">{suffix}</span>}
      </div>
    </div>
  );
}

interface ActivityRowProps {
  code: string;
  name: string;
  duration?: number | string;
  status?: string;
  float?: number;
}

function ActivityRow({ code, name, duration, status, float }: ActivityRowProps) {
  const getStatusBadge = (status?: string) => {
    if (!status) return null;
    const statusMap: Record<string, { bg: string; text: string }> = {
      'TK_Complete': { bg: 'bg-green-100', text: 'text-green-700' },
      'TK_Active': { bg: 'bg-blue-100', text: 'text-blue-700' },
      'TK_NotStart': { bg: 'bg-gray-100', text: 'text-gray-700' },
      'Not Started': { bg: 'bg-gray-100', text: 'text-gray-700' },
      'In Progress': { bg: 'bg-blue-100', text: 'text-blue-700' },
      'Complete': { bg: 'bg-green-100', text: 'text-green-700' },
    };
    const style = statusMap[status] || statusMap['TK_NotStart'];
    const label = status.replace('TK_', '').replace(/([A-Z])/g, ' $1').trim();
    return (
      <span className={`rounded px-1.5 py-0.5 text-xs ${style.bg} ${style.text}`}>
        {label}
      </span>
    );
  };

  return (
    <div className="flex items-center gap-3 border-b border-gray-100 py-2 text-sm last:border-0">
      <code className="w-32 shrink-0 truncate font-mono text-xs text-gray-500">
        {code}
      </code>
      <span className="flex-1 truncate" title={name}>
        {name}
      </span>
      {duration !== undefined && (
        <span className="w-16 shrink-0 text-right text-gray-500">
          {duration}d
        </span>
      )}
      {float !== undefined && (
        <span className={`w-16 shrink-0 text-right ${float <= 0 ? 'font-medium text-red-600' : 'text-gray-500'}`}>
          {float}h
        </span>
      )}
      {getStatusBadge(status)}
    </div>
  );
}

interface FloatDistributionBarProps {
  label: string;
  count: number;
  total: number;
  color: string;
}

function FloatDistributionBar({ label, count, total, color }: FloatDistributionBarProps) {
  const percentage = total > 0 ? (count / total) * 100 : 0;
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span>{label}</span>
        <span className="text-gray-500">{count} ({percentage.toFixed(1)}%)</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-gray-100">
        <div
          className={`h-full rounded-full ${color}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}

interface ScheduleCardProps {
  data: Record<string, unknown>;
  title: string;
  toolName?: string;
}

export function ScheduleCard({ data, title, toolName }: ScheduleCardProps) {
  const [expanded, setExpanded] = useState(true);
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(JSON.stringify(data, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Determine card type based on toolName or data structure
  const isCriticalPath = toolName?.includes('critical_path') ||
    (data.critical_activities !== undefined || data.activities !== undefined);
  const isSlipping = toolName?.includes('slipping') ||
    data.slipping_activities !== undefined;

  // Extract common metrics
  const totalActivities = (data.total_activities || data.activity_count || data.total_count || 0) as number;
  const criticalCount = (data.critical_count || data.critical_activities_count ||
    (Array.isArray(data.critical_activities) ? data.critical_activities.length : 0) ||
    (Array.isArray(data.activities) ? data.activities.length : 0)) as number;
  const healthScore = data.health_score as number | undefined;

  // Get activities list
  const activities = (data.critical_activities || data.activities || data.slipping_activities || []) as Array<{
    task_code?: string;
    code?: string;
    task_name?: string;
    name?: string;
    target_drtn_hr_cnt?: number;
    duration?: number;
    duration_days?: number;
    status_code?: string;
    status?: string;
    total_float_hr_cnt?: number;
    total_float?: number;
    float?: number;
    slip_days?: number;
  }>;

  // Get float distribution
  const floatDistribution = data.float_distribution as Record<string, number> | undefined;

  // Get quality issues
  const qualityIssues = data.quality_issues as Record<string, unknown[]> | undefined;

  // Check if we have structured data or just markdown result
  const markdownContent = typeof data.result === 'string' ? data.result : null;
  const hasStructuredData = healthScore !== undefined ||
    totalActivities > 0 ||
    activities.length > 0 ||
    floatDistribution !== undefined ||
    qualityIssues !== undefined;

  return (
    <div className="overflow-hidden rounded-lg border bg-white shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between border-b bg-gray-50 px-4 py-3">
        <div className="flex items-center gap-2">
          <Activity className="size-4 text-blue-600" />
          <h3 className="font-medium">{title}</h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="rounded p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
            title="Copy JSON"
          >
            {copied ? <CheckCircle className="size-4 text-green-500" /> : <Copy className="size-4" />}
          </button>
          <button
            onClick={() => setExpanded(!expanded)}
            className="rounded p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
          >
            {expanded ? <ChevronUp className="size-4" /> : <ChevronDown className="size-4" />}
          </button>
        </div>
      </div>

      {expanded && (
        <div className="p-4 space-y-4">
          {/* Markdown fallback when no structured data */}
          {!hasStructuredData && markdownContent && (
            <div className="prose prose-sm max-w-none prose-headings:text-gray-900 prose-p:text-gray-700 prose-strong:text-gray-900 prose-code:text-blue-600 prose-code:bg-blue-50 prose-code:px-1 prose-code:rounded">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                {markdownContent}
              </ReactMarkdown>
            </div>
          )}

          {/* Structured data sections - only show when we have structured data */}
          {hasStructuredData && (
            <>
              {/* Metrics Row */}
              <div className="grid grid-cols-3 gap-3">
                {healthScore !== undefined && (
                  <MetricCard
                    label="Health Score"
                    value={healthScore}
                    suffix="%"
                    status={healthScore >= 80 ? 'good' : healthScore >= 60 ? 'warning' : 'danger'}
                  />
                )}
                {totalActivities > 0 && (
                  <MetricCard
                    label="Total Activities"
                    value={totalActivities}
                    status="neutral"
                  />
                )}
                {criticalCount > 0 && (
                  <MetricCard
                    label="Critical"
                    value={criticalCount}
                    total={totalActivities || undefined}
                    status={criticalCount > totalActivities * 0.1 ? 'warning' : 'neutral'}
                  />
                )}
                {isSlipping && (
                  <MetricCard
                    label="Slipping"
                    value={activities.length}
                    status="danger"
                  />
                )}
              </div>

              {/* Float Distribution */}
              {floatDistribution && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-gray-700">Float Distribution</h4>
                  <div className="space-y-2">
                    {Object.entries(floatDistribution).map(([range, count]) => (
                      <FloatDistributionBar
                        key={range}
                        label={range}
                        count={count as number}
                        total={totalActivities}
                        color={
                          range.includes('0') || range.includes('Critical')
                            ? 'bg-red-500'
                            : range.includes('1-5') || range.includes('Low')
                            ? 'bg-yellow-500'
                            : range.includes('5-10') || range.includes('Medium')
                            ? 'bg-blue-500'
                            : 'bg-green-500'
                        }
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Quality Issues */}
              {qualityIssues && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-gray-700">Quality Issues</h4>
                  <div className="space-y-1 text-sm">
                    {Object.entries(qualityIssues).map(([issue, items]) => (
                      <div key={issue} className="flex items-center justify-between rounded bg-gray-50 px-2 py-1">
                        <span className="capitalize">{issue.replace(/_/g, ' ')}</span>
                        <span className={`font-medium ${(items as unknown[]).length > 0 ? 'text-yellow-600' : 'text-green-600'}`}>
                          {(items as unknown[]).length}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Activities List */}
              {activities.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-medium text-gray-700">
                      {isSlipping ? 'Slipping Activities' : isCriticalPath ? 'Critical Activities' : 'Activities'}
                    </h4>
                    <span className="text-xs text-gray-500">
                      Showing {Math.min(activities.length, 10)} of {activities.length}
                    </span>
                  </div>
                  <div className="rounded border">
                    <div className="flex items-center gap-3 border-b bg-gray-50 px-3 py-2 text-xs font-medium text-gray-500">
                      <span className="w-32">Code</span>
                      <span className="flex-1">Name</span>
                      <span className="w-16 text-right">Duration</span>
                      <span className="w-16 text-right">Float</span>
                      <span className="w-20">Status</span>
                    </div>
                    <div className="max-h-64 overflow-y-auto px-3">
                      {activities.slice(0, 10).map((activity, idx) => (
                        <ActivityRow
                          key={activity.task_code || activity.code || idx}
                          code={activity.task_code || activity.code || `ACT-${idx}`}
                          name={activity.task_name || activity.name || 'Unknown'}
                          duration={activity.target_drtn_hr_cnt
                            ? Math.round(activity.target_drtn_hr_cnt / 8)
                            : activity.duration_days || activity.duration}
                          status={activity.status_code || activity.status}
                          float={activity.total_float_hr_cnt || activity.total_float || activity.float}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}
