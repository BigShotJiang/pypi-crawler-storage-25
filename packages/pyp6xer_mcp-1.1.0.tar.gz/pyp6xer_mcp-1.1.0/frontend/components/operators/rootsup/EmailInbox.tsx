'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  Mail,
  AlertCircle,
  Clock,
  CheckCircle,
  RefreshCw,
  Send,
  ChevronDown,
  ChevronRight,
  Zap,
  Link2Off,
} from 'lucide-react';

interface Email {
  id: string;
  subject: string;
  sender: string;
  snippet: string;
  date?: string;
  category?: string;
  urgency?: 'high' | 'medium' | 'low';
}

interface InboxData {
  urgent: Email[];
  normal: Email[];
  low: Email[];
}

interface EmailInboxProps {
  /** Initial inbox data (from triage_inbox tool) */
  initialData?: InboxData;
  /** Callback when user wants to draft a reply */
  onDraftReply?: (email: Email) => void;
  /** Callback to refresh inbox (Act mode - uses AI) */
  onRefresh?: () => void;
  /** Loading state */
  isLoading?: boolean;
  /** Browse function for direct Strata calls (no LLM!) */
  browseCall?: <T = Record<string, unknown>>(
    toolName: string,
    args: Record<string, unknown>
  ) => Promise<T>;
  /** Whether user has Strata connected */
  hasStrata?: boolean;
  /** Callback when user needs to connect apps */
  onConnectApps?: () => void;
}

// Gmail email structure from Strata
interface GmailEmail {
  id: string;
  threadId?: string;
  subject?: string;
  from?: string;
  to?: string;
  date?: string;
  snippet?: string;
  labelIds?: string[];
}

export function EmailInbox({
  initialData,
  onDraftReply,
  onRefresh,
  isLoading: externalLoading = false,
  browseCall,
  hasStrata = false,
  onConnectApps,
}: EmailInboxProps) {
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    urgent: true,
    normal: true,
    low: false,
  });

  // Browse mode: Direct Gmail fetching (no LLM!)
  const [browseEmails, setBrowseEmails] = useState<Email[]>([]);
  const [isBrowseLoading, setIsBrowseLoading] = useState(false);
  const [browseError, setBrowseError] = useState<string | null>(null);

  // Fetch emails directly via Strata (Browse mode - zero LLM tokens!)
  const fetchEmailsDirect = useCallback(async () => {
    if (!browseCall) return;

    setIsBrowseLoading(true);
    setBrowseError(null);

    try {
      // Direct Strata call - no LLM involved!
      const result = await browseCall<{ emails?: GmailEmail[]; messages?: GmailEmail[] }>(
        'gmail_search_emails',
        { query: 'is:unread', maxResults: 20 }
      );

      // Transform Gmail format to our Email format
      const emails = (result.emails || result.messages || []).map((e: GmailEmail): Email => ({
        id: e.id,
        subject: e.subject || '(no subject)',
        sender: e.from || 'Unknown',
        snippet: e.snippet || '',
        date: e.date,
        // Default to normal urgency - AI triage will categorize properly
        urgency: 'medium',
      }));

      setBrowseEmails(emails);
    } catch (err) {
      console.error('Browse fetch failed:', err);
      setBrowseError(err instanceof Error ? err.message : 'Failed to fetch emails');
    } finally {
      setIsBrowseLoading(false);
    }
  }, [browseCall]);

  // Auto-fetch on mount if hasStrata and no initial data
  useEffect(() => {
    if (hasStrata && browseCall && !initialData && browseEmails.length === 0) {
      fetchEmailsDirect();
    }
  }, [hasStrata, browseCall, initialData, browseEmails.length, fetchEmailsDirect]);

  const isLoading = externalLoading || isBrowseLoading;

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  // Use triaged data if available, otherwise show browse emails as "pending"
  const hasTriagedData = initialData && (
    initialData.urgent.length > 0 ||
    initialData.normal.length > 0 ||
    initialData.low.length > 0
  );

  const sections = hasTriagedData
    ? [
        {
          key: 'urgent',
          title: 'Urgent',
          emails: initialData.urgent,
          icon: <AlertCircle className="size-4 text-red-500" />,
          badgeColor: 'bg-red-100 text-red-700',
        },
        {
          key: 'normal',
          title: 'Pending',
          emails: initialData.normal,
          icon: <Clock className="size-4 text-yellow-500" />,
          badgeColor: 'bg-yellow-100 text-yellow-700',
        },
        {
          key: 'low',
          title: 'Low Priority',
          emails: initialData.low,
          icon: <CheckCircle className="size-4 text-green-500" />,
          badgeColor: 'bg-green-100 text-green-700',
        },
      ]
    : [
        {
          key: 'unread',
          title: 'Unread',
          emails: browseEmails,
          icon: <Mail className="size-4 text-blue-500" />,
          badgeColor: 'bg-blue-100 text-blue-700',
        },
      ];

  const totalEmails = sections.reduce((sum, s) => sum + s.emails.length, 0);

  // Empty state: No Strata connection
  if (!hasStrata && !initialData && !isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Link2Off className="mb-4 size-12 text-gray-300" />
        <h3 className="text-lg font-medium text-gray-900">Connect Your Email</h3>
        <p className="mt-1 text-sm text-gray-500">
          Connect Gmail to see your emails here
        </p>
        {onConnectApps && (
          <button
            onClick={onConnectApps}
            className="mt-4 inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
          >
            <Zap className="size-4" />
            Connect Apps
          </button>
        )}
      </div>
    );
  }

  // Empty state: Has Strata but no emails yet
  if (hasStrata && browseEmails.length === 0 && !initialData && !isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Mail className="mb-4 size-12 text-gray-300" />
        <h3 className="text-lg font-medium text-gray-900">No emails loaded</h3>
        <p className="mt-1 text-sm text-gray-500">
          {browseError || 'Click below to fetch your emails'}
        </p>
        <div className="mt-4 flex gap-2">
          {browseCall && (
            <button
              onClick={fetchEmailsDirect}
              className="inline-flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              <Zap className="size-4" />
              Quick Fetch
            </button>
          )}
          {onRefresh && (
            <button
              onClick={onRefresh}
              className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
            >
              <RefreshCw className="size-4" />
              AI Triage
            </button>
          )}
        </div>
      </div>
    );
  }

  // Empty state: No Strata, waiting for AI triage
  if (!initialData && !browseEmails.length && !isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Mail className="mb-4 size-12 text-gray-300" />
        <h3 className="text-lg font-medium text-gray-900">No emails loaded</h3>
        <p className="mt-1 text-sm text-gray-500">
          Ask the AI to &quot;triage my inbox&quot; to see your emails
        </p>
        {onRefresh && (
          <button
            onClick={onRefresh}
            className="mt-4 inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
          >
            <RefreshCw className="size-4" />
            Load Inbox
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Mail className="size-5 text-gray-500" />
          <h2 className="text-lg font-semibold text-gray-900">Email Inbox</h2>
          <span className="rounded-full bg-gray-100 px-2.5 py-0.5 text-sm text-gray-600">
            {totalEmails} emails
          </span>
        </div>
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="inline-flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-50 disabled:opacity-50"
          >
            <RefreshCw className={`size-4 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        )}
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="flex items-center justify-center py-8">
          <RefreshCw className="size-6 animate-spin text-blue-500" />
          <span className="ml-2 text-gray-500">Loading inbox...</span>
        </div>
      )}

      {/* Email Sections */}
      {!isLoading && (
        <div className="space-y-3">
          {sections.map((section) => (
            <div key={section.key} className="overflow-hidden rounded-lg border bg-white">
              {/* Section Header */}
              <button
                onClick={() => toggleSection(section.key)}
                className="flex w-full items-center justify-between px-4 py-3 hover:bg-gray-50"
              >
                <div className="flex items-center gap-2">
                  {section.icon}
                  <span className="font-medium text-gray-900">{section.title}</span>
                  <span className={`rounded-full px-2 py-0.5 text-xs ${section.badgeColor}`}>
                    {section.emails.length}
                  </span>
                </div>
                {expandedSections[section.key] ? (
                  <ChevronDown className="size-4 text-gray-400" />
                ) : (
                  <ChevronRight className="size-4 text-gray-400" />
                )}
              </button>

              {/* Email List */}
              {expandedSections[section.key] && section.emails.length > 0 && (
                <div className="border-t">
                  {section.emails.map((email, index) => (
                    <EmailRow
                      key={email.id || index}
                      email={email}
                      onDraftReply={onDraftReply}
                    />
                  ))}
                </div>
              )}

              {/* Empty State */}
              {expandedSections[section.key] && section.emails.length === 0 && (
                <div className="border-t px-4 py-6 text-center text-sm text-gray-500">
                  No {section.title.toLowerCase()} emails
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

interface EmailRowProps {
  email: Email;
  onDraftReply?: (email: Email) => void;
}

function EmailRow({ email, onDraftReply }: EmailRowProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={`flex items-start gap-3 border-b p-4 last:border-b-0 ${
        isHovered ? 'bg-gray-50' : ''
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Email Content */}
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="truncate font-medium text-gray-900">{email.subject}</span>
        </div>
        <p className="mt-0.5 truncate text-sm text-gray-600">{email.sender}</p>
        {email.snippet && (
          <p className="mt-1 line-clamp-2 text-sm text-gray-500">{email.snippet}</p>
        )}
        {email.date && <p className="mt-1 text-xs text-gray-400">{email.date}</p>}
      </div>

      {/* Actions */}
      <div className={`flex shrink-0 gap-2 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
        {onDraftReply && (
          <button
            onClick={() => onDraftReply(email)}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-blue-700"
          >
            <Send className="size-3.5" />
            Draft Reply
          </button>
        )}
      </div>
    </div>
  );
}

export default EmailInbox;
