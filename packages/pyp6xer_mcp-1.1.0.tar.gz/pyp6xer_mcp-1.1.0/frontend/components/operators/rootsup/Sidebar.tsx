'use client';

import { useState } from 'react';
import {
  LayoutDashboard,
  Mail,
  Clock,
  Users,
  FileText,
  Settings,
  ChevronLeft,
  ChevronRight,
  MessageSquare,
} from 'lucide-react';

export type RootsupView = 'dashboard' | 'inbox' | 'time' | 'clients' | 'invoices' | 'chat';

interface SidebarProps {
  /** Current active view */
  activeView: RootsupView;
  /** Callback when view changes */
  onViewChange: (view: RootsupView) => void;
  /** Whether sidebar is collapsed */
  collapsed?: boolean;
  /** Callback when collapse state changes */
  onCollapsedChange?: (collapsed: boolean) => void;
  /** Unread counts for badges */
  badges?: {
    inbox?: number;
    invoices?: number;
  };
}

export function Sidebar({
  activeView,
  onViewChange,
  collapsed = false,
  onCollapsedChange,
  badges = {},
}: SidebarProps) {
  const navItems = [
    {
      id: 'dashboard' as RootsupView,
      label: 'Dashboard',
      icon: <LayoutDashboard className="size-5" />,
    },
    {
      id: 'inbox' as RootsupView,
      label: 'Email Inbox',
      icon: <Mail className="size-5" />,
      badge: badges.inbox,
    },
    {
      id: 'time' as RootsupView,
      label: 'Time Tracker',
      icon: <Clock className="size-5" />,
    },
    {
      id: 'clients' as RootsupView,
      label: 'Clients',
      icon: <Users className="size-5" />,
    },
    {
      id: 'invoices' as RootsupView,
      label: 'Invoices',
      icon: <FileText className="size-5" />,
      badge: badges.invoices,
    },
  ];

  const bottomItems = [
    {
      id: 'chat' as RootsupView,
      label: 'AI Chat',
      icon: <MessageSquare className="size-5" />,
    },
  ];

  return (
    <div
      className={`flex h-full flex-col border-r bg-white transition-all ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Logo/Brand */}
      <div className="flex h-16 items-center justify-between border-b px-4">
        {!collapsed && (
          <div>
            <h1 className="font-bold text-gray-900">Roots Up</h1>
            <p className="text-xs text-gray-500">Business Support</p>
          </div>
        )}
        {onCollapsedChange && (
          <button
            onClick={() => onCollapsedChange(!collapsed)}
            className="rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
          >
            {collapsed ? (
              <ChevronRight className="size-5" />
            ) : (
              <ChevronLeft className="size-5" />
            )}
          </button>
        )}
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 space-y-1 p-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors ${
              activeView === item.id
                ? 'bg-blue-50 text-blue-700'
                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
            }`}
            title={collapsed ? item.label : undefined}
          >
            <span
              className={activeView === item.id ? 'text-blue-600' : 'text-gray-400'}
            >
              {item.icon}
            </span>
            {!collapsed && (
              <>
                <span className="flex-1 font-medium">{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-600">
                    {item.badge}
                  </span>
                )}
              </>
            )}
            {collapsed && item.badge !== undefined && item.badge > 0 && (
              <span className="absolute right-1 top-0 size-2 rounded-full bg-red-500" />
            )}
          </button>
        ))}
      </nav>

      {/* Bottom Section */}
      <div className="border-t p-2">
        {bottomItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors ${
              activeView === item.id
                ? 'bg-blue-50 text-blue-700'
                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
            }`}
            title={collapsed ? item.label : undefined}
          >
            <span
              className={activeView === item.id ? 'text-blue-600' : 'text-gray-400'}
            >
              {item.icon}
            </span>
            {!collapsed && <span className="font-medium">{item.label}</span>}
          </button>
        ))}
      </div>
    </div>
  );
}

export default Sidebar;
