'use client';

import { useState } from 'react';
import {
  Users,
  FileText,
  Clock,
  TrendingUp,
  Mail,
  PlusCircle,
  RefreshCw,
  ArrowRight,
} from 'lucide-react';

interface DashboardMetrics {
  activeClients: number;
  pendingInvoices: { count: number; total: number };
  unbilledHours: number;
  monthlyRevenue?: number;
}

interface RecentActivity {
  id: string;
  type: 'invoice' | 'email' | 'task' | 'client';
  description: string;
  timestamp: string;
}

interface DashboardProps {
  /** Dashboard metrics data */
  metrics?: DashboardMetrics;
  /** Recent activity items */
  recentActivity?: RecentActivity[];
  /** Loading state */
  isLoading?: boolean;
  /** Quick action callbacks */
  onTriageEmails?: () => void;
  onLogTime?: () => void;
  onCreateInvoice?: () => void;
  onRefresh?: () => void;
}

export function Dashboard({
  metrics,
  recentActivity = [],
  isLoading = false,
  onTriageEmails,
  onLogTime,
  onCreateInvoice,
  onRefresh,
}: DashboardProps) {
  const currency = '£';

  const metricCards = [
    {
      label: 'Active Clients',
      value: metrics?.activeClients ?? '-',
      icon: <Users className="size-5 text-blue-500" />,
      color: 'bg-blue-50 border-blue-200',
    },
    {
      label: 'Pending Invoices',
      value: metrics?.pendingInvoices
        ? `${currency}${metrics.pendingInvoices.total.toLocaleString()}`
        : '-',
      subtext: metrics?.pendingInvoices ? `${metrics.pendingInvoices.count} invoices` : undefined,
      icon: <FileText className="size-5 text-yellow-500" />,
      color: 'bg-yellow-50 border-yellow-200',
    },
    {
      label: 'Unbilled Hours',
      value: metrics?.unbilledHours ? `${metrics.unbilledHours}h` : '-',
      subtext: metrics?.unbilledHours
        ? `${currency}${(metrics.unbilledHours * 33).toLocaleString()}`
        : undefined,
      icon: <Clock className="size-5 text-purple-500" />,
      color: 'bg-purple-50 border-purple-200',
    },
    {
      label: 'This Month',
      value: metrics?.monthlyRevenue
        ? `${currency}${metrics.monthlyRevenue.toLocaleString()}`
        : '-',
      icon: <TrendingUp className="size-5 text-green-500" />,
      color: 'bg-green-50 border-green-200',
    },
  ];

  const quickActions = [
    {
      label: 'Triage Emails',
      description: 'Check inbox for urgent messages',
      icon: <Mail className="size-5" />,
      onClick: onTriageEmails,
      color: 'text-blue-600 bg-blue-50 hover:bg-blue-100',
    },
    {
      label: 'Log Time',
      description: 'Record billable hours',
      icon: <Clock className="size-5" />,
      onClick: onLogTime,
      color: 'text-purple-600 bg-purple-50 hover:bg-purple-100',
    },
    {
      label: 'Create Invoice',
      description: 'Bill for unbilled work',
      icon: <PlusCircle className="size-5" />,
      onClick: onCreateInvoice,
      color: 'text-green-600 bg-green-50 hover:bg-green-100',
    },
  ];

  const activityIcons: Record<string, React.ReactNode> = {
    invoice: <FileText className="size-4 text-yellow-500" />,
    email: <Mail className="size-4 text-blue-500" />,
    task: <Clock className="size-4 text-purple-500" />,
    client: <Users className="size-4 text-green-500" />,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Business Overview</h1>
          <p className="mt-1 text-sm text-gray-500">
            Roots Up Business Support Dashboard
          </p>
        </div>
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="inline-flex items-center gap-2 rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 disabled:opacity-50"
          >
            <RefreshCw className={`size-4 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        )}
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {metricCards.map((metric) => (
          <div
            key={metric.label}
            className={`rounded-xl border p-4 ${metric.color}`}
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">{metric.label}</span>
              {metric.icon}
            </div>
            <p className="mt-2 text-2xl font-bold text-gray-900">{metric.value}</p>
            {metric.subtext && (
              <p className="mt-0.5 text-sm text-gray-500">{metric.subtext}</p>
            )}
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="mb-3 text-lg font-semibold text-gray-900">Quick Actions</h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          {quickActions.map((action) => (
            <button
              key={action.label}
              onClick={action.onClick}
              disabled={!action.onClick}
              className={`flex items-center gap-3 rounded-xl p-4 text-left transition-colors ${action.color} disabled:opacity-50`}
            >
              <div className="rounded-lg bg-white p-2 shadow-sm">{action.icon}</div>
              <div className="flex-1">
                <p className="font-medium">{action.label}</p>
                <p className="text-sm opacity-75">{action.description}</p>
              </div>
              <ArrowRight className="size-4 opacity-50" />
            </button>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div>
        <h2 className="mb-3 text-lg font-semibold text-gray-900">Recent Activity</h2>
        {recentActivity.length > 0 ? (
          <div className="overflow-hidden rounded-xl border bg-white">
            {recentActivity.map((activity, index) => (
              <div
                key={activity.id || index}
                className="flex items-center gap-3 border-b p-4 last:border-b-0"
              >
                <div className="rounded-lg bg-gray-100 p-2">
                  {activityIcons[activity.type] || activityIcons.task}
                </div>
                <div className="flex-1">
                  <p className="text-sm text-gray-900">{activity.description}</p>
                  <p className="text-xs text-gray-500">{activity.timestamp}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-xl border border-dashed border-gray-200 bg-gray-50 p-8 text-center">
            <p className="text-sm text-gray-500">
              No recent activity. Use quick actions to get started!
            </p>
          </div>
        )}
      </div>

      {/* Loading Overlay */}
      {isLoading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-white/50">
          <div className="flex items-center gap-2 rounded-lg bg-white px-4 py-3 shadow-lg">
            <RefreshCw className="size-5 animate-spin text-blue-500" />
            <span className="text-gray-600">Loading dashboard...</span>
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;
