/**
 * Rootsup Business Support Components
 *
 * These components provide a "Browse & Act" UI layer on top of
 * the Rootsup MCP tools. Users can initiate actions from the UI,
 * and results render in the canvas system.
 */

export { Dashboard } from './Dashboard';
export { EmailInbox } from './EmailInbox';
export { Sidebar, type RootsupView } from './Sidebar';
export { RootsupLayout } from './RootsupLayout';
