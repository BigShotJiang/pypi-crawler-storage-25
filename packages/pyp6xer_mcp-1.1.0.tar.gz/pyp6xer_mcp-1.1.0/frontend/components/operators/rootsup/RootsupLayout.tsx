'use client';

import { useState, useCallback } from 'react';
import { Sidebar, RootsupView } from './Sidebar';
import { Dashboard } from './Dashboard';
import { EmailInbox } from './EmailInbox';
import { usePlatformProfile } from '@/hooks/usePlatformProfile';
import { ConnectAppsPrompt } from '@/components/ConnectAppsPrompt';

interface Email {
  id: string;
  subject: string;
  sender: string;
  snippet: string;
  date?: string;
  category?: string;
  urgency?: 'high' | 'medium' | 'low';
}

interface InboxData {
  urgent: Email[];
  normal: Email[];
  low: Email[];
}

interface RootsupLayoutProps {
  /** Callback to send message to AI */
  onSendMessage?: (message: string) => void;
  /** Current inbox data from triage */
  inboxData?: InboxData;
  /** Dashboard metrics */
  dashboardMetrics?: {
    activeClients: number;
    pendingInvoices: { count: number; total: number };
    unbilledHours: number;
    monthlyRevenue?: number;
  };
  /** Recent activity for dashboard */
  recentActivity?: Array<{
    id: string;
    type: 'invoice' | 'email' | 'task' | 'client';
    description: string;
    timestamp: string;
  }>;
  /** Loading state */
  isLoading?: boolean;
  /** Slot for the chat panel */
  chatPanel?: React.ReactNode;
  /** Slot for the canvas panel */
  canvasPanel?: React.ReactNode;
}

export function RootsupLayout({
  onSendMessage,
  inboxData,
  dashboardMetrics,
  recentActivity = [],
  isLoading = false,
  chatPanel,
  canvasPanel,
}: RootsupLayoutProps) {
  const [activeView, setActiveView] = useState<RootsupView>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showConnectPrompt, setShowConnectPrompt] = useState(false);

  // Load user profile for Browse/Act pattern (Option C)
  const { hasStrata, browseCall, isLoading: profileLoading } = usePlatformProfile();

  // Handler to show connect apps prompt
  const handleConnectApps = useCallback(() => {
    setShowConnectPrompt(true);
  }, []);

  // Quick action handlers - these send messages to the AI
  const handleTriageEmails = useCallback(() => {
    onSendMessage?.('Triage my inbox and show me urgent emails');
    setActiveView('inbox');
  }, [onSendMessage]);

  const handleLogTime = useCallback(() => {
    onSendMessage?.('Help me log time for today');
  }, [onSendMessage]);

  const handleCreateInvoice = useCallback(() => {
    onSendMessage?.('Create an invoice for unbilled hours');
  }, [onSendMessage]);

  const handleRefreshDashboard = useCallback(() => {
    onSendMessage?.('Show me my business overview with client count, pending invoices, and unbilled hours');
  }, [onSendMessage]);

  const handleRefreshInbox = useCallback(() => {
    onSendMessage?.('Triage my inbox');
  }, [onSendMessage]);

  const handleDraftReply = useCallback(
    (email: Email) => {
      onSendMessage?.(
        `Draft a reply to the email "${email.subject}" from ${email.sender}`
      );
    },
    [onSendMessage]
  );

  // Calculate badges
  const urgentCount = inboxData?.urgent?.length || 0;

  // Render the active view
  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return (
          <Dashboard
            metrics={dashboardMetrics}
            recentActivity={recentActivity}
            isLoading={isLoading}
            onTriageEmails={handleTriageEmails}
            onLogTime={handleLogTime}
            onCreateInvoice={handleCreateInvoice}
            onRefresh={handleRefreshDashboard}
          />
        );

      case 'inbox':
        return (
          <EmailInbox
            initialData={inboxData}
            isLoading={isLoading || profileLoading}
            onDraftReply={handleDraftReply}
            onRefresh={handleRefreshInbox}
            browseCall={browseCall}
            hasStrata={hasStrata}
            onConnectApps={handleConnectApps}
          />
        );

      case 'chat':
        return chatPanel || (
          <div className="flex h-full items-center justify-center text-gray-500">
            Chat panel will appear here
          </div>
        );

      case 'time':
        return (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="text-6xl mb-4">⏱️</div>
            <h2 className="text-xl font-semibold text-gray-900">Time Tracker</h2>
            <p className="mt-2 text-gray-500">Coming soon - log hours and track billable time</p>
            <button
              onClick={handleLogTime}
              className="mt-4 rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              Ask AI to log time
            </button>
          </div>
        );

      case 'clients':
        return (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="text-6xl mb-4">👥</div>
            <h2 className="text-xl font-semibold text-gray-900">Clients</h2>
            <p className="mt-2 text-gray-500">Coming soon - manage client profiles</p>
            <button
              onClick={() => onSendMessage?.('Show me my client list')}
              className="mt-4 rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              Ask AI about clients
            </button>
          </div>
        );

      case 'invoices':
        return (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="text-6xl mb-4">📄</div>
            <h2 className="text-xl font-semibold text-gray-900">Invoices</h2>
            <p className="mt-2 text-gray-500">Coming soon - view and manage invoices</p>
            <button
              onClick={handleCreateInvoice}
              className="mt-4 rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              Create Invoice
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <div className="flex h-screen bg-gray-50">
        {/* Sidebar Navigation */}
        <Sidebar
          activeView={activeView}
          onViewChange={setActiveView}
          collapsed={sidebarCollapsed}
          onCollapsedChange={setSidebarCollapsed}
          badges={{
            inbox: urgentCount > 0 ? urgentCount : undefined,
          }}
        />

        {/* Main Content Area */}
        <div className="flex flex-1 overflow-hidden">
          {/* Content Panel */}
          <main className="flex-1 overflow-auto p-6">
            {renderContent()}
          </main>

          {/* Canvas Panel (right side) */}
          {canvasPanel && activeView !== 'chat' && (
            <aside className="w-96 border-l bg-white overflow-auto">
              {canvasPanel}
            </aside>
          )}
        </div>
      </div>

      {/* Connect Apps Modal */}
      {showConnectPrompt && (
        <ConnectAppsPrompt onClose={() => setShowConnectPrompt(false)} />
      )}
    </>
  );
}

export default RootsupLayout;
