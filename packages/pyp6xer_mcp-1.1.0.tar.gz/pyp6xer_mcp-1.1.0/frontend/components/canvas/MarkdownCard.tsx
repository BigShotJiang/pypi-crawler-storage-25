"use client";

import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

interface MarkdownCardProps {
  data: Record<string, unknown>;
}

export function MarkdownCard({ data }: MarkdownCardProps) {
  // Try to extract text content
  let content: string;

  if (typeof data === "string") {
    content = data;
  } else if (data.text && typeof data.text === "string") {
    content = data.text;
  } else if (data.content && typeof data.content === "string") {
    content = data.content;
  } else if (data.summary && typeof data.summary === "string") {
    content = data.summary;
  } else if (data.result && typeof data.result === "string") {
    content = data.result;
  } else if (data.output && typeof data.output === "string") {
    content = data.output;
  } else if (data.raw) {
    // Raw non-JSON response
    content =
      typeof data.text === "string"
        ? data.text
        : JSON.stringify(data, null, 2);
  } else {
    // Fallback to JSON display
    content = "```json\n" + JSON.stringify(data, null, 2) + "\n```";
  }

  return (
    <div className="prose prose-sm max-w-none prose-gray">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          // Custom styling for different elements
          h1: ({ children }) => (
            <h1 className="text-lg font-bold text-gray-900 mt-4 mb-2 first:mt-0">
              {children}
            </h1>
          ),
          h2: ({ children }) => (
            <h2 className="text-base font-semibold text-gray-900 mt-3 mb-2">
              {children}
            </h2>
          ),
          h3: ({ children }) => (
            <h3 className="text-sm font-medium text-gray-900 mt-2 mb-1">
              {children}
            </h3>
          ),
          p: ({ children }) => (
            <p className="text-sm text-gray-700 mb-2">{children}</p>
          ),
          ul: ({ children }) => (
            <ul className="list-disc list-inside space-y-1 text-sm text-gray-700 mb-2">
              {children}
            </ul>
          ),
          ol: ({ children }) => (
            <ol className="list-decimal list-inside space-y-1 text-sm text-gray-700 mb-2">
              {children}
            </ol>
          ),
          li: ({ children }) => <li className="text-gray-700">{children}</li>,
          code: ({ className, children }) => {
            const isInline = !className;
            if (isInline) {
              return (
                <code className="bg-gray-100 text-gray-800 px-1 py-0.5 rounded text-xs font-mono">
                  {children}
                </code>
              );
            }
            return (
              <code className="block bg-gray-900 text-gray-100 p-3 rounded-lg text-xs font-mono overflow-auto">
                {children}
              </code>
            );
          },
          pre: ({ children }) => (
            <pre className="bg-gray-900 text-gray-100 p-3 rounded-lg text-xs font-mono overflow-auto my-2">
              {children}
            </pre>
          ),
          blockquote: ({ children }) => (
            <blockquote className="border-l-4 border-gray-300 pl-3 italic text-gray-600 my-2">
              {children}
            </blockquote>
          ),
          table: ({ children }) => (
            <div className="overflow-auto my-2">
              <table className="min-w-full divide-y divide-gray-200 text-sm">
                {children}
              </table>
            </div>
          ),
          th: ({ children }) => (
            <th className="px-3 py-2 bg-gray-50 text-left font-medium text-gray-700">
              {children}
            </th>
          ),
          td: ({ children }) => (
            <td className="px-3 py-2 text-gray-700 border-t">{children}</td>
          ),
          a: ({ href, children }) => (
            <a
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline"
            >
              {children}
            </a>
          ),
          hr: () => <hr className="my-4 border-gray-200" />,
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
