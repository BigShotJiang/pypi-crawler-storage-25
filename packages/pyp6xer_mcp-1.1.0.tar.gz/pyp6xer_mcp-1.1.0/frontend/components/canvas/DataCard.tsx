"use client";

import { CheckCircle, XCircle, AlertCircle } from "lucide-react";

interface DataHealthData {
  issues?: Array<{
    type: string;
    description: string;
    severity?: "error" | "warning" | "info";
    column?: string;
    count?: number;
  }>;
  summary?: {
    total_rows?: number;
    total_columns?: number;
    issues_found?: number;
    data_quality_score?: number;
  };
  recommendations?: string[];
  [key: string]: unknown;
}

interface CleanDataData {
  cleaned_rows?: number;
  changes_made?: Array<{
    type: string;
    count: number;
    description?: string;
  }>;
  preview?: Array<Record<string, unknown>>;
  [key: string]: unknown;
}

interface DataCardProps {
  data: Record<string, unknown>;
}

export function DataCard({ data }: DataCardProps) {
  // Handle data health report
  if (data.issues || data.summary) {
    const healthData = data as DataHealthData;
    return <DataHealthContent data={healthData} />;
  }

  // Handle cleaned data result
  if (data.cleaned_rows !== undefined || data.changes_made) {
    const cleanData = data as CleanDataData;
    return <CleanedDataContent data={cleanData} />;
  }

  // Fallback: show raw data
  return (
    <pre className="text-xs bg-gray-50 p-3 rounded overflow-auto max-h-64">
      {JSON.stringify(data, null, 2)}
    </pre>
  );
}

function DataHealthContent({ data }: { data: DataHealthData }) {
  const severityIcons = {
    error: <XCircle className="w-4 h-4 text-red-500" />,
    warning: <AlertCircle className="w-4 h-4 text-yellow-500" />,
    info: <CheckCircle className="w-4 h-4 text-blue-500" />,
  };

  return (
    <div className="space-y-4">
      {/* Summary */}
      {data.summary && (
        <div className="grid grid-cols-2 gap-3">
          {data.summary.total_rows !== undefined && (
            <div className="bg-gray-50 rounded-lg p-3 text-center">
              <p className="text-2xl font-bold text-gray-900">
                {data.summary.total_rows}
              </p>
              <p className="text-xs text-gray-500">Total Rows</p>
            </div>
          )}
          {data.summary.issues_found !== undefined && (
            <div
              className={`rounded-lg p-3 text-center ${
                data.summary.issues_found > 0
                  ? "bg-red-50"
                  : "bg-green-50"
              }`}
            >
              <p
                className={`text-2xl font-bold ${
                  data.summary.issues_found > 0
                    ? "text-red-600"
                    : "text-green-600"
                }`}
              >
                {data.summary.issues_found}
              </p>
              <p className="text-xs text-gray-500">Issues Found</p>
            </div>
          )}
          {data.summary.data_quality_score !== undefined && (
            <div className="bg-blue-50 rounded-lg p-3 text-center col-span-2">
              <p className="text-2xl font-bold text-blue-600">
                {data.summary.data_quality_score}%
              </p>
              <p className="text-xs text-gray-500">Data Quality Score</p>
            </div>
          )}
        </div>
      )}

      {/* Issues */}
      {data.issues && data.issues.length > 0 && (
        <div>
          <h4 className="font-medium text-gray-900 mb-2">Issues</h4>
          <ul className="space-y-2">
            {data.issues.map((issue, index) => (
              <li
                key={index}
                className="flex items-start gap-2 text-sm p-2 bg-gray-50 rounded"
              >
                {severityIcons[issue.severity || "warning"]}
                <div className="flex-1">
                  <p className="text-gray-900">{issue.description}</p>
                  {issue.column && (
                    <p className="text-xs text-gray-500">
                      Column: {issue.column}
                    </p>
                  )}
                </div>
                {issue.count !== undefined && (
                  <span className="text-xs bg-gray-200 px-2 py-0.5 rounded">
                    {issue.count}
                  </span>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Recommendations */}
      {data.recommendations && data.recommendations.length > 0 && (
        <div>
          <h4 className="font-medium text-gray-900 mb-2">Recommendations</h4>
          <ul className="space-y-1 text-sm text-gray-600">
            {data.recommendations.map((rec, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-blue-500">-</span>
                {rec}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function CleanedDataContent({ data }: { data: CleanDataData }) {
  return (
    <div className="space-y-4">
      {/* Summary */}
      {data.cleaned_rows !== undefined && (
        <div className="bg-green-50 rounded-lg p-4 text-center">
          <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
          <p className="text-2xl font-bold text-green-600">
            {data.cleaned_rows}
          </p>
          <p className="text-sm text-gray-500">Rows Cleaned</p>
        </div>
      )}

      {/* Changes Made */}
      {data.changes_made && data.changes_made.length > 0 && (
        <div>
          <h4 className="font-medium text-gray-900 mb-2">Changes Made</h4>
          <ul className="space-y-2">
            {data.changes_made.map((change, index) => (
              <li
                key={index}
                className="flex justify-between items-center text-sm p-2 bg-gray-50 rounded"
              >
                <span className="text-gray-700">
                  {change.description || change.type}
                </span>
                <span className="font-medium text-gray-900">{change.count}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Preview */}
      {data.preview && data.preview.length > 0 && (
        <div>
          <h4 className="font-medium text-gray-900 mb-2">Preview</h4>
          <div className="overflow-auto max-h-48 border rounded">
            <table className="w-full text-xs">
              <thead className="bg-gray-50 sticky top-0">
                <tr>
                  {Object.keys(data.preview[0]).map((key) => (
                    <th
                      key={key}
                      className="text-left px-2 py-1 font-medium text-gray-600"
                    >
                      {key}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.preview.slice(0, 5).map((row, index) => (
                  <tr key={index} className="border-t">
                    {Object.values(row).map((value, i) => (
                      <td key={i} className="px-2 py-1 text-gray-900">
                        {String(value)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
