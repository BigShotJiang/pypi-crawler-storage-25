"use client";

import ReactMarkdown from "react-markdown";

interface ReportData {
  title?: string;
  client_name?: string;
  period?: string;
  period_start?: string;
  period_end?: string;
  summary?: string;
  report?: string;
  sections?: Array<{
    title: string;
    content: string;
  }>;
  metrics?: Record<string, number | string>;
  work_items?: Array<{
    description: string;
    hours?: number;
    service_type?: string;
  }>;
  [key: string]: unknown;
}

interface ReportCardProps {
  data: Record<string, unknown>;
}

export function ReportCard({ data }: ReportCardProps) {
  const report = data as ReportData;

  // If there's a formatted report string, use that
  if (report.report && typeof report.report === "string") {
    return (
      <div className="prose prose-sm max-w-none">
        <ReactMarkdown>{report.report}</ReactMarkdown>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      {(report.client_name || report.period || report.period_start) && (
        <div className="pb-3 border-b">
          {report.client_name && (
            <p className="font-semibold text-gray-900">{report.client_name}</p>
          )}
          {(report.period || (report.period_start && report.period_end)) && (
            <p className="text-sm text-gray-500">
              {report.period ||
                `${report.period_start} - ${report.period_end}`}
            </p>
          )}
        </div>
      )}

      {/* Summary */}
      {report.summary && (
        <div className="prose prose-sm max-w-none">
          <ReactMarkdown>{report.summary}</ReactMarkdown>
        </div>
      )}

      {/* Metrics */}
      {report.metrics && Object.keys(report.metrics).length > 0 && (
        <div className="grid grid-cols-2 gap-3">
          {Object.entries(report.metrics).map(([key, value]) => (
            <div
              key={key}
              className="bg-gray-50 rounded-lg p-3 text-center"
            >
              <p className="text-2xl font-bold text-gray-900">{value}</p>
              <p className="text-xs text-gray-500 capitalize">
                {key.replace(/_/g, " ")}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* Sections */}
      {report.sections && report.sections.length > 0 && (
        <div className="space-y-3">
          {report.sections.map((section, index) => (
            <div key={index}>
              <h4 className="font-medium text-gray-900 mb-1">{section.title}</h4>
              <div className="prose prose-sm max-w-none text-gray-600">
                <ReactMarkdown>{section.content}</ReactMarkdown>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Work Items */}
      {report.work_items && report.work_items.length > 0 && (
        <div>
          <h4 className="font-medium text-gray-900 mb-2">Work Completed</h4>
          <ul className="space-y-2">
            {report.work_items.map((item, index) => (
              <li
                key={index}
                className="flex justify-between items-start text-sm"
              >
                <span className="text-gray-700">{item.description}</span>
                {item.hours && (
                  <span className="text-gray-500 ml-2 whitespace-nowrap">
                    {item.hours}h
                  </span>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
