"use client";

import { CheckSquare, Square, AlertCircle, Calendar } from "lucide-react";

interface Task {
  id?: string;
  description?: string;
  title?: string;
  status?: string;
  priority?: "high" | "medium" | "low";
  due_date?: string;
  deadline?: string;
  owner?: string;
  completed?: boolean;
}

interface TasksData {
  tasks?: Task[];
  items?: Task[];
  checklist?: Task[];
  total?: number;
  completed_count?: number;
  [key: string]: unknown;
}

interface TasksCardProps {
  data: Record<string, unknown>;
}

export function TasksCard({ data }: TasksCardProps) {
  const tasksData = data as TasksData;
  const tasks = tasksData.tasks || tasksData.items || tasksData.checklist || [];

  // Handle array of tasks
  if (Array.isArray(tasks) && tasks.length > 0) {
    return <TaskList tasks={tasks} summary={tasksData} />;
  }

  // Handle raw text or other formats
  if (data.text && typeof data.text === "string") {
    return (
      <div className="prose prose-sm max-w-none">
        <pre className="whitespace-pre-wrap text-sm">{data.text}</pre>
      </div>
    );
  }

  return (
    <pre className="text-xs bg-gray-50 p-3 rounded overflow-auto max-h-64">
      {JSON.stringify(data, null, 2)}
    </pre>
  );
}

function TaskList({ tasks, summary }: { tasks: Task[]; summary: TasksData }) {
  const completedCount =
    summary.completed_count ||
    tasks.filter((t) => t.completed || t.status === "completed").length;
  const totalCount = summary.total || tasks.length;

  const priorityColors: Record<string, string> = {
    high: "text-red-600 bg-red-50",
    medium: "text-yellow-600 bg-yellow-50",
    low: "text-green-600 bg-green-50",
  };

  return (
    <div className="space-y-4">
      {/* Progress Summary */}
      <div className="p-3 bg-gray-50 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-900">Progress</span>
          <span className="text-sm text-gray-600">
            {completedCount} / {totalCount}
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-green-500 h-2 rounded-full transition-all"
            style={{
              width: `${(completedCount / totalCount) * 100}%`,
            }}
          />
        </div>
      </div>

      {/* Task List */}
      <ul className="space-y-2">
        {tasks.map((task, index) => {
          const isCompleted = task.completed || task.status === "completed";
          const title = task.title || task.description || `Task ${index + 1}`;

          return (
            <li
              key={task.id || index}
              className={`flex items-start gap-3 p-3 rounded-lg border ${
                isCompleted ? "bg-gray-50 border-gray-200" : "bg-white border-gray-200"
              }`}
            >
              {/* Checkbox */}
              <div className="mt-0.5">
                {isCompleted ? (
                  <CheckSquare className="w-5 h-5 text-green-500" />
                ) : (
                  <Square className="w-5 h-5 text-gray-400" />
                )}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <p
                  className={`text-sm ${
                    isCompleted
                      ? "text-gray-500 line-through"
                      : "text-gray-900"
                  }`}
                >
                  {title}
                </p>

                {/* Metadata */}
                <div className="flex items-center gap-3 mt-1">
                  {task.priority && (
                    <span
                      className={`text-xs px-2 py-0.5 rounded ${
                        priorityColors[task.priority] || "bg-gray-100"
                      }`}
                    >
                      {task.priority}
                    </span>
                  )}
                  {(task.due_date || task.deadline) && (
                    <span className="flex items-center gap-1 text-xs text-gray-500">
                      <Calendar className="w-3 h-3" />
                      {task.due_date || task.deadline}
                    </span>
                  )}
                  {task.owner && (
                    <span className="text-xs text-gray-500">{task.owner}</span>
                  )}
                </div>
              </div>

              {/* High Priority Indicator */}
              {task.priority === "high" && !isCompleted && (
                <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
