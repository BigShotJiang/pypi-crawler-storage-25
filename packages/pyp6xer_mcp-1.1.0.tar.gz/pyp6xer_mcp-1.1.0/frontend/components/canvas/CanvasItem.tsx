"use client";

import { useState, useEffect } from "react";
import { Copy, Download, Send, MoreHorizontal } from "lucide-react";
import { CanvasItem as CanvasItemType, CanvasAction } from "@/lib/canvas-types";
import { InvoiceCard } from "./InvoiceCard";
import { ReportCard } from "./ReportCard";
import { DataCard } from "./DataCard";
import { EmailCard } from "./EmailCard";
import { TasksCard } from "./TasksCard";
import { MarkdownCard } from "./MarkdownCard";
import { ScheduleCard } from "@/components/operators/p6/ScheduleCard";

interface CanvasItemProps {
  item: CanvasItemType;
}

const ACTION_ICONS: Record<string, React.ReactNode> = {
  copy: <Copy className="w-4 h-4" />,
  download: <Download className="w-4 h-4" />,
  send: <Send className="w-4 h-4" />,
  custom: <MoreHorizontal className="w-4 h-4" />,
};

export function CanvasItem({ item }: CanvasItemProps) {
  const [formattedTime, setFormattedTime] = useState<string | null>(null);

  // Format timestamp on client-side only to avoid hydration mismatch
  useEffect(() => {
    if (item.timestamp) {
      setFormattedTime(new Date(item.timestamp).toLocaleTimeString());
    }
  }, [item.timestamp]);

  const handleAction = async (action: CanvasAction) => {
    switch (action.action) {
      case "copy":
        const text = JSON.stringify(item.data, null, 2);
        await navigator.clipboard.writeText(text);
        break;
      case "download":
        const blob = new Blob([JSON.stringify(item.data, null, 2)], {
          type: "application/json",
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${item.title.toLowerCase().replace(/\s+/g, "-")}.json`;
        a.click();
        URL.revokeObjectURL(url);
        break;
      case "send":
        // Future: implement send functionality
        console.log("Send action not implemented yet");
        break;
    }
  };

  const renderContent = () => {
    switch (item.type) {
      case "invoice":
        return <InvoiceCard data={item.data} />;
      case "report":
        return <ReportCard data={item.data} />;
      case "data":
        return <DataCard data={item.data} />;
      case "email":
        return <EmailCard data={item.data} />;
      case "tasks":
        return <TasksCard data={item.data} />;
      case "schedule":
        return <ScheduleCard data={item.data} title={item.title} toolName={item.toolName} />;
      case "markdown":
      default:
        return <MarkdownCard data={item.data} />;
    }
  };

  const typeColors: Record<string, string> = {
    invoice: "bg-green-100 text-green-700",
    report: "bg-blue-100 text-blue-700",
    data: "bg-purple-100 text-purple-700",
    email: "bg-yellow-100 text-yellow-700",
    tasks: "bg-orange-100 text-orange-700",
    schedule: "bg-indigo-100 text-indigo-700",
    markdown: "bg-gray-100 text-gray-700",
  };

  return (
    <div className="bg-white rounded-lg border shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b bg-gray-50">
        <div className="flex items-center gap-2">
          <span
            className={`text-xs font-medium px-2 py-0.5 rounded ${
              typeColors[item.type] || typeColors.markdown
            }`}
          >
            {item.type}
          </span>
          <h3 className="font-medium text-gray-900 text-sm">{item.title}</h3>
        </div>
        <div className="flex items-center gap-1">
          {item.actions.map((action, index) => (
            <button
              key={index}
              onClick={() => handleAction(action)}
              className="p-1.5 hover:bg-gray-200 rounded transition-colors text-gray-500 hover:text-gray-700"
              title={action.label}
            >
              {ACTION_ICONS[action.action] || ACTION_ICONS.custom}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">{renderContent()}</div>

      {/* Footer */}
      <div className="px-4 py-2 border-t bg-gray-50 text-xs text-gray-500">
        {item.toolName && (
          <span className="font-mono">{item.toolName}</span>
        )}
        {formattedTime && (
          <span className="ml-2">{formattedTime}</span>
        )}
      </div>
    </div>
  );
}
