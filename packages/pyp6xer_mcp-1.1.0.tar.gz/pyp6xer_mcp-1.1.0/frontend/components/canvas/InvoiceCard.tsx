"use client";

interface InvoiceData {
  invoice_number?: string;
  client_name?: string;
  client_email?: string;
  hours?: number;
  hourly_rate?: number;
  total?: number;
  amount?: number;
  description?: string;
  due_date?: string;
  payment_terms?: string;
  footer?: string;
  line_items?: Array<{
    description: string;
    hours?: number;
    rate?: number;
    amount?: number;
  }>;
  [key: string]: unknown;
}

interface InvoiceCardProps {
  data: Record<string, unknown>;
}

export function InvoiceCard({ data }: InvoiceCardProps) {
  const invoice = data as InvoiceData;

  const total = invoice.total || invoice.amount || 0;
  const currency = "£"; // Could be made configurable

  return (
    <div className="space-y-4">
      {/* Invoice Header */}
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm text-gray-500">Invoice To</p>
          <p className="font-semibold text-gray-900">
            {invoice.client_name || "Client"}
          </p>
          {invoice.client_email && (
            <p className="text-sm text-gray-600">{invoice.client_email}</p>
          )}
        </div>
        <div className="text-right">
          {invoice.invoice_number && (
            <p className="text-sm font-mono text-gray-500">
              #{invoice.invoice_number}
            </p>
          )}
          {invoice.due_date && (
            <p className="text-sm text-gray-600">Due: {invoice.due_date}</p>
          )}
        </div>
      </div>

      {/* Line Items or Description */}
      <div className="border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left px-3 py-2 font-medium text-gray-600">
                Description
              </th>
              <th className="text-right px-3 py-2 font-medium text-gray-600">
                Hours
              </th>
              <th className="text-right px-3 py-2 font-medium text-gray-600">
                Rate
              </th>
              <th className="text-right px-3 py-2 font-medium text-gray-600">
                Amount
              </th>
            </tr>
          </thead>
          <tbody>
            {invoice.line_items && invoice.line_items.length > 0 ? (
              invoice.line_items.map((item, index) => (
                <tr key={index} className="border-t">
                  <td className="px-3 py-2 text-gray-900">{item.description}</td>
                  <td className="px-3 py-2 text-right text-gray-600">
                    {item.hours || "-"}
                  </td>
                  <td className="px-3 py-2 text-right text-gray-600">
                    {item.rate ? `${currency}${item.rate}` : "-"}
                  </td>
                  <td className="px-3 py-2 text-right font-medium text-gray-900">
                    {item.amount ? `${currency}${item.amount}` : "-"}
                  </td>
                </tr>
              ))
            ) : (
              <tr className="border-t">
                <td className="px-3 py-2 text-gray-900">
                  {invoice.description || "Professional services"}
                </td>
                <td className="px-3 py-2 text-right text-gray-600">
                  {invoice.hours || "-"}
                </td>
                <td className="px-3 py-2 text-right text-gray-600">
                  {invoice.hourly_rate
                    ? `${currency}${invoice.hourly_rate}`
                    : "-"}
                </td>
                <td className="px-3 py-2 text-right font-medium text-gray-900">
                  {total ? `${currency}${total}` : "-"}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Total */}
      <div className="flex justify-end">
        <div className="text-right">
          <p className="text-sm text-gray-500">Total Due</p>
          <p className="text-2xl font-bold text-gray-900">
            {currency}
            {total.toLocaleString()}
          </p>
        </div>
      </div>

      {/* Payment Terms / Footer */}
      {(invoice.payment_terms || invoice.footer) && (
        <div className="pt-3 border-t text-xs text-gray-500">
          {invoice.payment_terms && <p>{invoice.payment_terms}</p>}
          {invoice.footer && <p className="mt-1">{invoice.footer}</p>}
        </div>
      )}
    </div>
  );
}
