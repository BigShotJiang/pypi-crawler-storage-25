"use client";

import { Mail, AlertCircle, Clock, CheckCircle } from "lucide-react";
import ReactMarkdown from "react-markdown";

interface TriagedEmail {
  id?: string;
  subject: string;
  sender?: string;
  snippet?: string;
  category?: string;
  urgency?: string;
}

interface TriageResult {
  urgent?: TriagedEmail[];
  normal?: TriagedEmail[];
  low?: TriagedEmail[];
  categories?: Record<string, TriagedEmail[]>;
  [key: string]: unknown;
}

interface DraftReply {
  subject?: string;
  body?: string;
  to?: string;
  notes?: string;
  [key: string]: unknown;
}

interface EmailCardProps {
  data: Record<string, unknown>;
}

export function EmailCard({ data }: EmailCardProps) {
  // Handle triaged inbox
  if (data.urgent || data.normal || data.low || data.categories) {
    return <TriageContent data={data as TriageResult} />;
  }

  // Handle draft reply
  if (data.body || data.subject) {
    return <DraftContent data={data as DraftReply} />;
  }

  // Fallback
  return (
    <pre className="text-xs bg-gray-50 p-3 rounded overflow-auto max-h-64">
      {JSON.stringify(data, null, 2)}
    </pre>
  );
}

function TriageContent({ data }: { data: TriageResult }) {
  const categoryIcons: Record<string, React.ReactNode> = {
    urgent: <AlertCircle className="w-4 h-4 text-red-500" />,
    normal: <Clock className="w-4 h-4 text-yellow-500" />,
    low: <CheckCircle className="w-4 h-4 text-green-500" />,
  };

  const categoryColors: Record<string, string> = {
    urgent: "border-red-200 bg-red-50",
    normal: "border-yellow-200 bg-yellow-50",
    low: "border-green-200 bg-green-50",
  };

  // Collect all categories
  const categories: Record<string, TriagedEmail[]> = data.categories || {
    ...(data.urgent && { urgent: data.urgent }),
    ...(data.normal && { normal: data.normal }),
    ...(data.low && { low: data.low }),
  };

  const totalEmails = Object.values(categories).reduce(
    (sum, emails) => sum + emails.length,
    0
  );

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
        <div className="flex items-center gap-2">
          <Mail className="w-5 h-5 text-gray-500" />
          <span className="font-medium text-gray-900">{totalEmails} emails</span>
        </div>
        <div className="flex gap-2">
          {Object.entries(categories).map(([category, emails]) => (
            <span
              key={category}
              className={`text-xs px-2 py-0.5 rounded ${
                categoryColors[category] || "bg-gray-100"
              }`}
            >
              {emails.length} {category}
            </span>
          ))}
        </div>
      </div>

      {/* Categories */}
      {Object.entries(categories).map(([category, emails]) => (
        <div key={category}>
          <div className="flex items-center gap-2 mb-2">
            {categoryIcons[category] || <Mail className="w-4 h-4 text-gray-500" />}
            <h4 className="font-medium text-gray-900 capitalize">{category}</h4>
            <span className="text-xs text-gray-500">({emails.length})</span>
          </div>
          <ul className="space-y-2">
            {emails.map((email, index) => (
              <li
                key={email.id || index}
                className={`p-3 rounded border ${
                  categoryColors[category] || "border-gray-200"
                }`}
              >
                <p className="font-medium text-gray-900 text-sm">
                  {email.subject}
                </p>
                {email.sender && (
                  <p className="text-xs text-gray-500">{email.sender}</p>
                )}
                {email.snippet && (
                  <p className="text-xs text-gray-600 mt-1 line-clamp-2">
                    {email.snippet}
                  </p>
                )}
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}

function DraftContent({ data }: { data: DraftReply }) {
  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="p-3 bg-gray-50 rounded-lg space-y-2">
        {data.to && (
          <div className="flex items-center gap-2 text-sm">
            <span className="text-gray-500 w-16">To:</span>
            <span className="text-gray-900">{data.to}</span>
          </div>
        )}
        {data.subject && (
          <div className="flex items-center gap-2 text-sm">
            <span className="text-gray-500 w-16">Subject:</span>
            <span className="font-medium text-gray-900">{data.subject}</span>
          </div>
        )}
      </div>

      {/* Body */}
      {data.body && (
        <div className="prose prose-sm max-w-none p-3 border rounded-lg">
          <ReactMarkdown>{data.body}</ReactMarkdown>
        </div>
      )}

      {/* Notes */}
      {data.notes && (
        <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-xs font-medium text-yellow-800 mb-1">Notes</p>
          <p className="text-sm text-yellow-700">{data.notes}</p>
        </div>
      )}
    </div>
  );
}
