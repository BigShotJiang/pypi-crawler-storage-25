"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight, History } from "lucide-react";
import { CanvasItem as CanvasItemType } from "@/lib/canvas-types";
import { CanvasItem } from "./CanvasItem";

interface CanvasPanelProps {
  items: CanvasItemType[];
  collapsed?: boolean;
  onToggleCollapse?: () => void;
}

export function CanvasPanel({
  items,
  collapsed = false,
  onToggleCollapse,
}: CanvasPanelProps) {
  const [showHistory, setShowHistory] = useState(false);

  // Show most recent item by default, or all if history is open
  const visibleItems = showHistory ? items : items.slice(-1);
  const hasHistory = items.length > 1;

  if (collapsed) {
    return (
      <div className="w-12 border-l bg-gray-50 flex flex-col items-center py-4">
        <button
          onClick={onToggleCollapse}
          className="p-2 hover:bg-gray-200 rounded-lg transition-colors"
          title="Expand canvas"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        {items.length > 0 && (
          <div className="mt-4 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
            <span className="text-xs font-medium text-blue-600">
              {items.length}
            </span>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="w-[400px] lg:w-[500px] border-l bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b bg-white">
        <div className="flex items-center gap-2">
          <h2 className="font-semibold text-gray-900">Canvas</h2>
          {items.length > 0 && (
            <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">
              {items.length}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {hasHistory && (
            <button
              onClick={() => setShowHistory(!showHistory)}
              className={`p-2 rounded-lg transition-colors ${
                showHistory
                  ? "bg-blue-100 text-blue-600"
                  : "hover:bg-gray-100 text-gray-600"
              }`}
              title={showHistory ? "Show latest" : "Show history"}
            >
              <History className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onToggleCollapse}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            title="Collapse canvas"
          >
            <ChevronRight className="w-5 h-5 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <svg
                className="w-8 h-8 text-gray-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </div>
            <p className="text-gray-500 text-sm">
              Tool outputs will appear here
            </p>
            <p className="text-gray-400 text-xs mt-1">
              Try asking to create an invoice or generate a report
            </p>
          </div>
        ) : (
          visibleItems.map((item) => <CanvasItem key={item.id} item={item} />)
        )}
      </div>
    </div>
  );
}
