# CLAUDE.md

Guidance for Claude Code when working in this repository.

See @README.md for user-facing docs, @TOOLS.md for full tool reference, @pyproject.toml for package config.

## Project Overview

MCP server for Primavera P6 XER file analysis. 23 tools, 5 prompts, 3 resources. Wraps the [PyP6XER](https://github.com/HassanEmam/PyP6Xer) library with MCP tooling, HTTP upload, and in-memory caching.

Uses uv and a .venv for dependency management.

**Live:** https://pyp6xer-mcp.fly.dev/mcp
**PyPI:** https://pypi.org/project/pyp6xer-mcp/
**Source:** https://gitlab.com/articat1066/pyp6xer-mcp

## Commands

```bash
# Dev setup
uv pip install -e ".[dev]"

# Run
python -m pyp6xer_mcp.cli                  # stdio (Claude Desktop)
python -m pyp6xer_mcp.cli streamable-http  # HTTP on port 5000

# Test
pytest                                      # 27 tests
pytest -x                                   # Stop on first failure

# Lint
black --line-length 100 .
ruff check .

# Deploy
fly deploy
fly logs
```

## Architecture

```
pyp6xer_mcp/
├── server.py             # FastMCP instance, tool/prompt/resource registration
├── cli.py                # Entry point (stdio/http), sample auto-load on HTTP startup
├── core/
│   ├── cache.py          # XerCache + PendingUploadStore (in-memory)
│   ├── parser.py         # Shared parse_and_cache_xer() — single source of truth
│   ├── formatters.py     # Output formatting (safe_getattr, to_markdown_table)
│   └── helpers.py        # get_project, get_project_from_dict
├── models/               # Pydantic input/output models (strict validation)
│   ├── common.py         # ResponseFormat, ExportType
│   ├── file_ops.py       # LoadXerInput, WriteXerInput, CsvExportInput
│   ├── activities.py     # Activity-related models
│   ├── analysis.py       # Analysis tool models
│   ├── resources.py      # Resource/calendar models
│   └── outputs.py        # Structured output models
├── tools/                # 23 MCP tools
│   ├── file_ops.py       # load_file, write_file, clear_cache, export_csv, get_upload_url
│   ├── projects.py       # list_projects
│   ├── activities.py     # list/get/search/update activities
│   ├── analysis.py       # critical_path, float, schedule_quality, etc.
│   ├── resources.py      # list_resources, resource_utilization
│   ├── progress.py       # progress_summary, earned_value, work_package, wbs_analysis
│   └── calendars.py      # list_calendars
├── prompts/              # 5 workflow prompts
│   └── analysis.py
├── resources/            # 3 MCP resources (schedule://...)
│   └── schedule.py
├── context/              # Context helpers
│   └── xer_context.py
└── http/
    ├── middleware.py      # APIKeyAuthMiddleware (Bearer, x-api-key, query param)
    ├── routes.py          # Landing page, health, upload, presigned upload
    └── static/            # HTML UI (index.html, demo.html)
```

### Key patterns

**XER parsing:** All XER loading (tool, upload, presigned upload, auto-load) goes through `core/parser.py::parse_and_cache_xer()`. Don't duplicate this logic.

**Cache:** In-memory `XerCache` singleton in `core/cache.py`. Data is lost on restart. HTTP mode auto-loads 5 sample files from `samples/` on startup.

**Tool registration:** Explicit imports in `server.py` via `@mcp.tool()` decorators. Adding a tool requires importing its module in `server.py`.

**Auth:** `middleware.py` supports three methods: `Authorization: Bearer`, `x-api-key` header, `?api_key=` query param. Exempt paths: `/`, `/demo`, `/health`, `/upload`, `/upload/{id}`.

**HTTP startup:** `cli.py::_lifespan()` wraps `mcp.session_manager.run()` with `_auto_load_samples()` which scans `samples/*.xer` and caches each with filename stem as key.

## Sample Projects (auto-loaded in HTTP mode)

| Cache Key | File | Activities |
|-----------|------|------------|
| `cairo-alex-road` | cairo-alex-road.xer | 57 |
| `hilal-oil-gas` | hilal-oil-gas.xer | 31 |
| `terminal-building-airport` | terminal-building-airport.xer | 66 |
| `pharma-pack` | pharma-pack.xer | 289 |
| `expressway-project` | expressway-project.xer | 823 |

## Dependencies

- `mcp>=1.0.0` — MCP protocol (NOTE: pinned low, FastMCP v3+ available — upgrade planned)
- `pydantic>=2.0.0` — Input validation
- `PyP6XER>=0.1.0` — XER parsing (`xerparser.reader.Reader`)
- `httpx>=0.24.0` — HTTP client
- `uvicorn>=0.23.0` — ASGI server

## Deployment

See @fly.toml for Fly.io config, @Dockerfile for image build, @docker-compose.yml for local dev.

- **Fly.io:** `pyp6xer-mcp` app, LHR region, 256MB shared-cpu, `min_machines_running=1`
- **Docker:** `python:3.11-slim`, copies `pyp6xer_mcp/` and `samples/`
- **Auth:** `API_KEY` env var set via `fly secrets`
- **Frontend:** Separate repo at `/home/bch/company/internal/pydanticai/pydanticAI-agents-tools/build-frontend/`, deploys to `p6-analyzer-demo.fly.dev` (standalone mode, gpt-4o-mini)
