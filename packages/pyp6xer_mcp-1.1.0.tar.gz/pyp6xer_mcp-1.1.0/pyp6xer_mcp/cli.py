"""CLI entry point for PyP6Xer MCP Server.

Usage:
    python -m pyp6xer_mcp.cli [stdio|sse|streamable-http]
    pyp6xer-mcp [stdio|sse|streamable-http]
"""

import glob
import logging
import os
import sys
from contextlib import asynccontextmanager


def main():
    """Main entry point for PyP6Xer MCP Server."""
    from pyp6xer_mcp.server import mcp, API_KEY

    # Default to stdio for backward compatibility
    transport = sys.argv[1] if len(sys.argv) > 1 else "stdio"

    if transport not in ("stdio", "sse", "streamable-http"):
        print(f"Unknown transport: {transport}")
        print("Usage: pyp6xer-mcp [stdio|sse|streamable-http]")
        sys.exit(1)

    if transport == "streamable-http":
        _run_http_server(mcp, API_KEY)
    else:
        mcp.run(transport=transport)


def _run_http_server(mcp, api_key: str | None):
    """Run HTTP server with optional authentication."""
    import uvicorn
    from starlette.applications import Starlette
    from starlette.middleware import Middleware
    from starlette.middleware.cors import CORSMiddleware
    from starlette.routing import Mount, Route

    from pyp6xer_mcp.http.routes import index, demo, health_check, upload_file, presigned_upload
    from pyp6xer_mcp.http.middleware import APIKeyAuthMiddleware

    fastmcp_app = mcp.streamable_http_app()

    # Enable CORS for demo web UI
    middlewares = [
        Middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    ]

    if api_key:
        middlewares.append(Middleware(APIKeyAuthMiddleware))
        print(f"Starting PyP6Xer MCP Server with API key authentication on port {mcp.settings.port}")
    else:
        print(f"Warning: Running without API key authentication (API_KEY not set)")
        print(f"Starting PyP6Xer MCP Server on port {mcp.settings.port}")

    app = Starlette(
        debug=False,
        routes=[
            Route("/", index),  # Landing page at root
            Route("/demo", demo),  # Demo file upload UI
            Route("/health", health_check),
            Route("/upload", upload_file, methods=["POST"]),
            Route("/upload/{upload_id}", presigned_upload, methods=["GET", "POST"]),
            Mount("", app=fastmcp_app),  # MCP server at /mcp (fastmcp_app has /mcp route)
        ],
        middleware=middlewares,
        lifespan=_lifespan(mcp),
    )

    uvicorn.run(app, host="0.0.0.0", port=mcp.settings.port)


def _lifespan(mcp):
    """Create Starlette lifespan that starts MCP and auto-loads samples."""

    @asynccontextmanager
    async def lifespan(app):
        async with mcp.session_manager.run():
            _auto_load_samples()
            yield

    return lifespan


def _auto_load_samples():
    """Scan for sample XER files and pre-load them into the cache."""
    from pyp6xer_mcp.core.parser import parse_and_cache_xer

    logger = logging.getLogger(__name__)

    # Docker: /app/samples  |  Local dev: ./samples
    for search_dir in [os.path.join(os.getcwd(), "samples"), "/app/samples"]:
        if os.path.isdir(search_dir):
            samples_dir = search_dir
            break
    else:
        return

    xer_files = sorted(glob.glob(os.path.join(samples_dir, "*.xer")))
    if not xer_files:
        return

    loaded = 0
    for xer_path in xer_files:
        filename = os.path.basename(xer_path)
        cache_key = os.path.splitext(filename)[0]
        try:
            parse_and_cache_xer(xer_path, cache_key, label=f"sample:{filename}")
            loaded += 1
        except Exception as e:
            logger.warning("Failed to auto-load %s: %s", filename, e)

    logger.info("Auto-loaded %d/%d sample XER files", loaded, len(xer_files))


if __name__ == "__main__":
    main()
