"""Pydantic models for PyP6Xer MCP Server.

This package contains input validation and output models organized by category:
- common: Base types, enums, and shared models
- file_ops: File loading, writing, and export models
- activities: Activity listing, searching, and updating models
- analysis: Schedule analysis input models
- resources: Resource, calendar, and structure-related models
- outputs: Structured output models for rich UI rendering
"""

from .common import (
    ExportType,
    ProjectInput,
    ResponseFormat,
    XerCacheKeyInput,
)
from .file_ops import (
    CsvExportInput,
    LoadXerInput,
    WriteXerInput,
)
from .activities import (
    ActivityDetailInput,
    ListActivitiesInput,
    SearchActivitiesInput,
    UpdateActivityInput,
)
from .analysis import (
    CriticalPathInput,
    FloatAnalysisInput,
    RelationshipAnalysisInput,
    ScheduleHealthCheckInput,
    ScheduleQualityInput,
    SlippingActivitiesInput,
    WorkPackageSummaryInput,
)
from .resources import (
    CalendarInput,
    EarnedValueInput,
    ProgressSummaryInput,
    ResourceUtilizationInput,
    WbsInput,
)
from .outputs import (
    ActivityInfo,
    ActivitiesListResult,
    CompletionMetrics,
    ComponentScores,
    CriticalPathResult,
    FloatAnalysisResult,
    FloatCategory,
    FloatMetrics,
    LogicMetrics,
    ScheduleHealthResult,
    SlippageMetrics,
    SlippingActivitiesResult,
)

__all__ = [
    # Common
    "ResponseFormat",
    "ExportType",
    "XerCacheKeyInput",
    "ProjectInput",
    # File operations
    "LoadXerInput",
    "WriteXerInput",
    "CsvExportInput",
    # Activities
    "ListActivitiesInput",
    "ActivityDetailInput",
    "SearchActivitiesInput",
    "UpdateActivityInput",
    # Analysis
    "CriticalPathInput",
    "ScheduleQualityInput",
    "FloatAnalysisInput",
    "RelationshipAnalysisInput",
    "SlippingActivitiesInput",
    "ScheduleHealthCheckInput",
    "WorkPackageSummaryInput",
    # Resources
    "ResourceUtilizationInput",
    "CalendarInput",
    "ProgressSummaryInput",
    "EarnedValueInput",
    "WbsInput",
    # Output models (for rich UI rendering)
    "ActivityInfo",
    "ActivitiesListResult",
    "CompletionMetrics",
    "ComponentScores",
    "CriticalPathResult",
    "FloatAnalysisResult",
    "FloatCategory",
    "FloatMetrics",
    "LogicMetrics",
    "ScheduleHealthResult",
    "SlippageMetrics",
    "SlippingActivitiesResult",
]
