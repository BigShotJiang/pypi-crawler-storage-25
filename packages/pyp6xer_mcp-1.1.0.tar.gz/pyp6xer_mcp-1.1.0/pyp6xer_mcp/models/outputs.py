"""Structured output models for PyP6Xer MCP tools.

These models enable rich UI rendering in canvas-based frontends.
MCP automatically serializes Pydantic models to JSON.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ActivityInfo(BaseModel):
    """Activity information for list displays."""

    task_code: str = Field(description="Activity code")
    task_name: Optional[str] = Field(default=None, description="Activity name")
    target_drtn_hr_cnt: Optional[float] = Field(default=None, description="Duration in hours")
    status_code: Optional[str] = Field(default=None, description="Status: TK_Complete, TK_Active, TK_NotStarted")
    total_float_hr_cnt: Optional[float] = Field(default=None, description="Total float in hours")
    early_start_date: Optional[str] = Field(default=None, description="Early start date")
    early_end_date: Optional[str] = Field(default=None, description="Early end date")
    target_end_date: Optional[str] = Field(default=None, description="Target end date")
    slip_days: Optional[float] = Field(default=None, description="Days slipping beyond baseline")


class CompletionMetrics(BaseModel):
    """Completion status breakdown."""

    completed: int = Field(description="Completed activities")
    in_progress: int = Field(description="In-progress activities")
    not_started: int = Field(description="Not started activities")
    completion_pct: float = Field(description="Completion percentage")
    weighted_completion_pct: float = Field(description="Duration-weighted completion %")


class FloatMetrics(BaseModel):
    """Float distribution metrics."""

    critical_count: int = Field(description="Activities with ≤0 float")
    critical_pct: float = Field(description="Critical percentage")
    negative_float_count: int = Field(description="Activities with negative float")
    near_critical_count: int = Field(description="Activities with 1-5 days float")
    avg_float_hours: float = Field(description="Average float in hours")
    min_float_hours: float = Field(description="Minimum float in hours")
    max_float_hours: float = Field(description="Maximum float in hours")


class LogicMetrics(BaseModel):
    """Logic quality metrics."""

    no_predecessors: int = Field(description="Activities without predecessors")
    no_successors: int = Field(description="Activities without successors")
    logic_quality_pct: float = Field(description="Logic quality percentage")


class SlippageMetrics(BaseModel):
    """Schedule slippage metrics."""

    slipping_count: int = Field(description="Number of slipping activities")
    slipping_pct: float = Field(description="Slipping percentage")
    total_slip_days: int = Field(description="Total slip days")
    avg_slip_days: float = Field(description="Average slip days")


class ComponentScores(BaseModel):
    """Individual component scores for health calculation."""

    completion_score: float
    float_score: float
    logic_score: float
    slippage_score: float


class ScheduleHealthResult(BaseModel):
    """Comprehensive schedule health check result.

    Used by: pyp6xer_schedule_health_check
    Canvas: ScheduleCard with health gauge, metrics grid, quality issues
    """

    project: str = Field(description="Project name")
    health_score: float = Field(description="Overall health score 0-100")
    health_rating: str = Field(description="Health rating with emoji")
    total_activities: int = Field(description="Total activity count")

    # Nested metrics
    completion: CompletionMetrics
    float_metrics: FloatMetrics = Field(alias="float")
    logic: LogicMetrics
    slippage: SlippageMetrics
    component_scores: ComponentScores

    # For canvas compatibility - flattened fields
    critical_count: int = Field(description="Critical activities count")

    # Float distribution for bar charts
    float_distribution: Dict[str, int] = Field(
        default_factory=dict,
        description="Float distribution by category"
    )

    # Quality issues for issue list
    quality_issues: Dict[str, List[str]] = Field(
        default_factory=dict,
        description="Quality issues by category"
    )

    class Config:
        populate_by_name = True


class CriticalPathResult(BaseModel):
    """Critical path analysis result.

    Used by: pyp6xer_critical_path
    Canvas: ScheduleCard with critical activities table
    """

    total_activities: int = Field(description="Total activities analyzed")
    critical_count: int = Field(description="Number of critical activities")
    critical_pct: float = Field(description="Critical percentage")
    float_threshold_hours: int = Field(description="Float threshold used")

    # Activity list for table display
    activities: List[ActivityInfo] = Field(
        default_factory=list,
        description="Critical activities sorted by float"
    )

    # Alias for canvas compatibility
    critical_activities: List[ActivityInfo] = Field(
        default_factory=list,
        description="Alias for activities"
    )


class FloatCategory(BaseModel):
    """Float category with count and activities."""

    label: str = Field(description="Category label (e.g., '0 days', '1-5 days')")
    count: int = Field(description="Number of activities in category")
    percentage: float = Field(description="Percentage of total")
    activities: List[ActivityInfo] = Field(
        default_factory=list,
        description="Activities in this category (limited)"
    )


class FloatAnalysisResult(BaseModel):
    """Float distribution analysis result.

    Used by: pyp6xer_float_analysis
    Canvas: ScheduleCard with float distribution bars
    """

    total_activities: int = Field(description="Total activities analyzed")
    activities_with_float: int = Field(description="Activities with float data")

    # Summary stats
    avg_float_days: float = Field(description="Average float in days")
    min_float_days: float = Field(description="Minimum float in days")
    max_float_days: float = Field(description="Maximum float in days")

    # Distribution for bar charts
    float_distribution: Dict[str, int] = Field(
        description="Count by category: {'0 days': 5, '1-5 days': 20, ...}"
    )

    # Detailed categories with sample activities
    categories: List[FloatCategory] = Field(
        default_factory=list,
        description="Detailed breakdown by category"
    )


class SlippingActivitiesResult(BaseModel):
    """Slipping activities analysis result.

    Used by: pyp6xer_slipping_activities
    Canvas: ScheduleCard with slipping activities table
    """

    total_activities: int = Field(description="Total activities analyzed")
    slipping_count: int = Field(description="Number of slipping activities")
    slipping_pct: float = Field(description="Slipping percentage")
    threshold_days: float = Field(description="Threshold used")
    total_slip_days: float = Field(description="Total cumulative slip")
    avg_slip_days: float = Field(description="Average slip per activity")

    # Activity list for table
    slipping_activities: List[ActivityInfo] = Field(
        default_factory=list,
        description="Slipping activities sorted by slip amount"
    )


class ActivitiesListResult(BaseModel):
    """Activities list result.

    Used by: pyp6xer_list_activities
    Canvas: ScheduleCard with activities table
    """

    total_count: int = Field(description="Total matching activities")
    returned_count: int = Field(description="Number returned (may be limited)")
    offset: int = Field(description="Pagination offset")
    limit: int = Field(description="Pagination limit")

    # Filters applied
    project_id: Optional[str] = Field(default=None)
    status_filter: Optional[str] = Field(default=None)
    wbs_id: Optional[str] = Field(default=None)

    # Activity list
    activities: List[ActivityInfo] = Field(
        default_factory=list,
        description="Activities matching filters"
    )
