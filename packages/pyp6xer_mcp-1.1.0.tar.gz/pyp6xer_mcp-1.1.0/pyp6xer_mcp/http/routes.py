"""HTTP route handlers for PyP6Xer MCP Server."""

import os
import tempfile
import uuid

from starlette.responses import JSONResponse, HTMLResponse, RedirectResponse

from pyp6xer_mcp.core import pending_uploads
from pyp6xer_mcp.core.parser import parse_and_cache_xer


async def index(request):
    """Serve landing page."""
    static_dir = os.path.join(os.path.dirname(__file__), "static")
    index_path = os.path.join(static_dir, "index.html")

    if os.path.exists(index_path):
        with open(index_path, "r", encoding="utf-8") as f:
            return HTMLResponse(f.read())

    # Fallback if static file not found
    return HTMLResponse(
        """
        <h1>PyP6Xer MCP Server</h1>
        <p>Server is running.</p>
        <ul>
            <li><a href="/demo">Demo Upload</a></li>
            <li><a href="/health">Health Check</a></li>
            <li><a href="https://pypi.org/project/pyp6xer-mcp/">Install</a></li>
            <li><a href="https://gitlab.com/articat1066/pyp6xer-mcp">Repository</a></li>
        </ul>
        """
    )


async def demo(request):
    """Redirect to the P6 Analyzer frontend."""
    demo_url = os.getenv("DEMO_URL", "https://p6-analyzer-demo.fly.dev/")
    return RedirectResponse(url=demo_url, status_code=302)


async def health_check(request):
    """Health check endpoint."""
    return JSONResponse({"status": "ok", "server": "pyp6xer_mcp"})


async def upload_file(request):
    """Upload XER file directly via HTTP POST.

    This endpoint allows users to upload XER files directly via HTTP,
    which is useful for Claude.ai web users who can't use local file paths.
    """
    try:
        form = await request.form()
        uploaded_file = form.get("file")

        if not uploaded_file:
            return JSONResponse(
                {"error": "No file uploaded. Use form field 'file'."}, status_code=400
            )

        content = await uploaded_file.read()
        cache_key = form.get("cache_key") or f"upload_{uuid.uuid4().hex[:8]}"

        # Write raw bytes — don't decode, Reader handles encoding
        with tempfile.NamedTemporaryFile(mode="wb", suffix=".xer", delete=False) as tmp:
            tmp.write(content if isinstance(content, bytes) else content.encode("utf-8"))
            tmp_path = tmp.name

        try:
            data = parse_and_cache_xer(
                tmp_path, cache_key, label=f"upload:{uploaded_file.filename}"
            )
        finally:
            os.unlink(tmp_path)

        projects_response = [
            {"id": getattr(p, "proj_id", None), "short_name": getattr(p, "proj_short_name", None)}
            for p in data["projects"]
        ]

        return JSONResponse(
            {
                "cache_key": cache_key,
                "projects": projects_response,
                "activity_count": len(data["activities"]),
                "message": f"XER loaded. Use cache_key '{cache_key}' with MCP tools.",
            }
        )
    except Exception as e:
        return JSONResponse({"error": f"Failed to parse XER: {str(e)}"}, status_code=400)


async def presigned_upload(request):
    """Handle presigned URL uploads.

    This endpoint accepts uploads at /upload/{upload_id} where upload_id
    is a valid token from pyp6xer_get_upload_url().

    Supports both GET (for browser upload form) and POST (for actual upload).
    """
    upload_id = request.path_params.get("upload_id")

    if not upload_id:
        return JSONResponse({"error": "Missing upload_id"}, status_code=400)

    # GET request - show upload form
    if request.method == "GET":
        if not pending_uploads.validate(upload_id):
            return HTMLResponse(
                """
                <h1>Upload Link Expired</h1>
                <p>This upload link has expired or already been used.</p>
                <p>Please request a new upload URL.</p>
                """,
                status_code=410,
            )

        return HTMLResponse(f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Upload XER File</title>
            <style>
                body {{ font-family: -apple-system, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }}
                .upload-box {{ border: 2px dashed #ccc; padding: 40px; text-align: center; border-radius: 8px; }}
                .upload-box.dragover {{ border-color: #007bff; background: #f0f7ff; }}
                input[type="file"] {{ margin: 20px 0; }}
                button {{ background: #007bff; color: white; border: none; padding: 12px 24px; border-radius: 4px; cursor: pointer; font-size: 16px; }}
                button:hover {{ background: #0056b3; }}
                .result {{ margin-top: 20px; padding: 15px; background: #d4edda; border-radius: 4px; display: none; }}
                .error {{ background: #f8d7da; }}
            </style>
        </head>
        <body>
            <h1>Upload XER File</h1>
            <p>Upload ID: <code>{upload_id}</code></p>
            <div class="upload-box" id="dropzone">
                <form id="uploadForm" enctype="multipart/form-data">
                    <p>Drag & drop your XER file here, or click to select</p>
                    <input type="file" name="file" id="fileInput" accept=".xer" required>
                    <br>
                    <button type="submit">Upload</button>
                </form>
            </div>
            <div class="result" id="result"></div>
            <script>
                const dropzone = document.getElementById('dropzone');
                const form = document.getElementById('uploadForm');
                const fileInput = document.getElementById('fileInput');
                const result = document.getElementById('result');

                dropzone.addEventListener('dragover', (e) => {{
                    e.preventDefault();
                    dropzone.classList.add('dragover');
                }});
                dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
                dropzone.addEventListener('drop', (e) => {{
                    e.preventDefault();
                    dropzone.classList.remove('dragover');
                    fileInput.files = e.dataTransfer.files;
                }});

                form.addEventListener('submit', async (e) => {{
                    e.preventDefault();
                    const formData = new FormData();
                    formData.append('file', fileInput.files[0]);

                    try {{
                        const response = await fetch(window.location.href, {{
                            method: 'POST',
                            body: formData
                        }});
                        const data = await response.json();
                        result.style.display = 'block';
                        if (response.ok) {{
                            result.className = 'result';
                            result.innerHTML = '<strong>Success!</strong><br>Cache key: <code>' + data.cache_key + '</code><br>' +
                                'Projects: ' + data.projects.length + '<br>Activities: ' + data.activity_count +
                                '<br><br>Use this cache_key with PyP6Xer analysis tools.';
                        }} else {{
                            result.className = 'result error';
                            result.innerHTML = '<strong>Error:</strong> ' + data.error;
                        }}
                    }} catch (err) {{
                        result.style.display = 'block';
                        result.className = 'result error';
                        result.innerHTML = '<strong>Error:</strong> ' + err.message;
                    }}
                }});
            </script>
        </body>
        </html>
        """)

    # POST request - handle file upload
    if not pending_uploads.consume(upload_id):
        return JSONResponse(
            {"error": "Invalid or expired upload URL. Please request a new one."},
            status_code=410,
        )

    try:
        form = await request.form()
        uploaded_file = form.get("file")

        if not uploaded_file:
            return JSONResponse(
                {"error": "No file uploaded. Use form field 'file'."}, status_code=400
            )

        content = await uploaded_file.read()
        cache_key = upload_id

        # Write raw bytes — don't decode, Reader handles encoding
        with tempfile.NamedTemporaryFile(mode="wb", suffix=".xer", delete=False) as tmp:
            tmp.write(content if isinstance(content, bytes) else content.encode("utf-8"))
            tmp_path = tmp.name

        try:
            data = parse_and_cache_xer(
                tmp_path, cache_key, label=f"presigned:{uploaded_file.filename}"
            )
        finally:
            os.unlink(tmp_path)

        projects_response = [
            {"id": getattr(p, "proj_id", None), "short_name": getattr(p, "proj_short_name", None)}
            for p in data["projects"]
        ]

        return JSONResponse(
            {
                "cache_key": cache_key,
                "projects": projects_response,
                "activity_count": len(data["activities"]),
                "message": f"XER loaded. Use cache_key '{cache_key}' with MCP tools.",
            }
        )
    except Exception as e:
        return JSONResponse({"error": f"Failed to parse XER: {str(e)}"}, status_code=400)
