"""Shared XER parsing and caching logic."""

import logging
from typing import Optional

from pyp6xer_mcp.core.cache import xer_cache

logger = logging.getLogger(__name__)


def parse_and_cache_xer(file_path: str, cache_key: str, label: Optional[str] = None) -> dict:
    """Parse an XER file and store results in xer_cache.

    Args:
        file_path: Path to the .xer file on disk.
        cache_key: Key to store the parsed data under.
        label: Optional display label for file_path in the cache.
               If None, file_path is used.

    Returns:
        Dict with projects, activities, resources, calendars, activityresources, relations.

    Raises:
        Exception: If Reader fails to parse the file.
    """
    from xerparser.reader import Reader

    xer = Reader(file_path)

    projects = list(xer.projects)
    activities = list(xer.activities) if hasattr(xer, "activities") else []
    resources = list(xer.resources) if hasattr(xer, "resources") else []
    calendars = list(xer.calendars) if hasattr(xer, "calendars") else []

    try:
        activityresources = (
            list(xer.activityresources) if hasattr(xer, "activityresources") else []
        )
    except (AttributeError, Exception):
        activityresources = []

    try:
        relations = list(xer.relations) if hasattr(xer, "relations") else []
    except (AttributeError, Exception):
        relations = []

    data = {
        "reader": xer,
        "projects": projects,
        "activities": activities,
        "resources": resources,
        "calendars": calendars,
        "activityresources": activityresources,
        "relations": relations,
        "file_path": label or file_path,
    }
    xer_cache.set_from_dict(cache_key, data)

    logger.info(
        "Cached '%s': %d projects, %d activities",
        cache_key,
        len(projects),
        len(activities),
    )
    return data
