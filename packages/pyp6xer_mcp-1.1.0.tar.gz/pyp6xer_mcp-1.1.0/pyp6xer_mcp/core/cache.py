"""XER file cache management for PyP6Xer MCP Server.

This module provides an encapsulated cache for loaded XER files,
replacing the global dictionary with a structured class.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class CachedXer:
    """Structured container for cached XER data."""

    reader: Any
    projects: List[Any] = field(default_factory=list)
    activities: List[Any] = field(default_factory=list)
    resources: List[Any] = field(default_factory=list)
    calendars: List[Any] = field(default_factory=list)
    activityresources: List[Any] = field(default_factory=list)
    relations: List[Any] = field(default_factory=list)
    file_path: str = ""


class XerCache:
    """Encapsulated cache for loaded XER files.

    Provides a clean interface for storing and retrieving parsed XER data.
    All tools reference cached data via cache keys.
    """

    def __init__(self) -> None:
        self._cache: Dict[str, CachedXer] = {}

    def get(self, cache_key: str) -> CachedXer:
        """Get cached XER data by key.

        Args:
            cache_key: The key used when loading the XER file.

        Returns:
            CachedXer containing the parsed data.

        Raises:
            ValueError: If no data exists for the given key.
        """
        if cache_key not in self._cache:
            raise ValueError(
                f"No XER file loaded with key '{cache_key}'. Use pyp6xer_load_file first."
            )
        return self._cache[cache_key]

    def get_raw(self, cache_key: str) -> Dict[str, Any]:
        """Get cached XER data as a dictionary (backward compatibility).

        Args:
            cache_key: The key used when loading the XER file.

        Returns:
            Dictionary with reader, projects, activities, etc.

        Raises:
            ValueError: If no data exists for the given key.
        """
        cached = self.get(cache_key)
        return {
            "reader": cached.reader,
            "projects": cached.projects,
            "activities": cached.activities,
            "resources": cached.resources,
            "calendars": cached.calendars,
            "activityresources": cached.activityresources,
            "relations": cached.relations,
            "file_path": cached.file_path,
        }

    def set(self, cache_key: str, data: CachedXer) -> None:
        """Store XER data in the cache.

        Args:
            cache_key: Key to reference this data.
            data: CachedXer containing the parsed data.
        """
        self._cache[cache_key] = data

    def set_from_dict(self, cache_key: str, data: Dict[str, Any]) -> None:
        """Store XER data from a dictionary (backward compatibility).

        Args:
            cache_key: Key to reference this data.
            data: Dictionary with reader, projects, activities, etc.
        """
        cached = CachedXer(
            reader=data.get("reader"),
            projects=data.get("projects", []),
            activities=data.get("activities", []),
            resources=data.get("resources", []),
            calendars=data.get("calendars", []),
            activityresources=data.get("activityresources", []),
            relations=data.get("relations", []),
            file_path=data.get("file_path", ""),
        )
        self._cache[cache_key] = cached

    def delete(self, cache_key: str) -> bool:
        """Remove a cached XER file.

        Args:
            cache_key: Key of the data to remove.

        Returns:
            True if the key existed and was removed, False otherwise.
        """
        if cache_key in self._cache:
            del self._cache[cache_key]
            return True
        return False

    def clear(self) -> int:
        """Clear all cached data.

        Returns:
            Number of entries that were cleared.
        """
        count = len(self._cache)
        self._cache.clear()
        return count

    def keys(self) -> List[str]:
        """Get all cache keys.

        Returns:
            List of cache keys.
        """
        return list(self._cache.keys())

    def __contains__(self, key: str) -> bool:
        """Check if a key exists in the cache."""
        return key in self._cache

    def __len__(self) -> int:
        """Return the number of cached entries."""
        return len(self._cache)

    def __bool__(self) -> bool:
        """Return True if cache has entries."""
        return len(self._cache) > 0


# Global cache instance
xer_cache = XerCache()


@dataclass
class PendingUpload:
    """A pending upload waiting for file data."""

    upload_id: str
    created_at: float
    expires_at: float


class PendingUploadStore:
    """Store for pending upload tokens.

    Manages presigned upload URLs that expire after a set time.
    """

    def __init__(self, expiry_seconds: int = 900) -> None:  # 15 minutes default
        self._pending: Dict[str, PendingUpload] = {}
        self._expiry_seconds = expiry_seconds

    def create(self) -> PendingUpload:
        """Create a new pending upload token.

        Returns:
            PendingUpload with unique upload_id and expiry time.
        """
        import secrets
        import time

        upload_id = secrets.token_urlsafe(16)
        now = time.time()
        pending = PendingUpload(
            upload_id=upload_id,
            created_at=now,
            expires_at=now + self._expiry_seconds,
        )
        self._pending[upload_id] = pending
        self._cleanup_expired()
        return pending

    def validate(self, upload_id: str) -> bool:
        """Check if an upload_id is valid and not expired.

        Args:
            upload_id: The upload token to validate.

        Returns:
            True if valid and not expired, False otherwise.
        """
        import time

        self._cleanup_expired()
        if upload_id not in self._pending:
            return False
        return self._pending[upload_id].expires_at > time.time()

    def consume(self, upload_id: str) -> bool:
        """Use an upload token (one-time use).

        Args:
            upload_id: The upload token to consume.

        Returns:
            True if token was valid and consumed, False otherwise.
        """
        if self.validate(upload_id):
            del self._pending[upload_id]
            return True
        return False

    def _cleanup_expired(self) -> None:
        """Remove expired pending uploads."""
        import time

        now = time.time()
        expired = [k for k, v in self._pending.items() if v.expires_at <= now]
        for k in expired:
            del self._pending[k]


# Global pending upload store
pending_uploads = PendingUploadStore()
