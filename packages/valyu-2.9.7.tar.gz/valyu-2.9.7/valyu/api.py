import json
import os
import platform
import time

import requests
from requests.adapters import HTTPAdapter
from valyu import __version__
from typing import Optional, List, Union, Dict, Any, Callable
from valyu.types.response import SearchResponse, SearchType, ResultsBySource
from valyu.types.contents import (
    ContentsResponse,
    ContentsJobCreateResponse,
    ContentsJobStatus,
    ExtractEffort,
    ContentsResponseLength,
)
from valyu.types.datasources import (
    Datasource,
    DatasourcesResponse,
    DatasourceCategory,
    DatasourceCategoriesResponse,
    DatasourceCategoryType,
)
from valyu.types.answer import (
    AnswerResponse,
    AnswerSuccessResponse,
    AnswerErrorResponse,
    AnswerStreamChunk,
    AnswerStreamGenerator,
    SearchMetadata,
    SearchResult,
    AIUsage,
    CostBreakdown,
    ExtractionMetadata,
    SUPPORTED_COUNTRY_CODES,
)
from valyu.validation import validate_sources, format_validation_error
from valyu.deepresearch_client import DeepResearchClient
from valyu.batch_client import BatchClient


class Valyu:
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://api.valyu.ai/v1",
        max_connections: int = 100,
        timeout: Optional[float] = 600.0,
        session: Optional[requests.Session] = None,
    ):
        """
        Initialize the Valyu client.

        Args:
            api_key (Optional[str]): The API key to use for the client. If not
                provided, will attempt to read from ``VALYU_API_KEY`` environment
                variable.
            base_url (str): The base URL for the Valyu API.
            max_connections (int): Maximum number of simultaneous HTTP
                connections the underlying session will pool. Raise this when
                calling the client from many threads; lower it if you want to be
                gentle on a constrained environment. Defaults to 100. Ignored
                when ``session`` is provided.
            timeout (Optional[float]): Per-request timeout in seconds. Applied
                to every outbound request unless overridden on the call. Pass
                ``None`` to disable the timeout. Defaults to 600 seconds.
            session (Optional[requests.Session]): Pre-configured
                ``requests.Session`` to use. When provided, the client is used
                as-is (no adapters mounted) and is NOT closed by ``close()`` —
                lifecycle stays with the caller. Useful for injecting proxies,
                custom TLS config, or a shared pool across clients.

        The client may be used as a context manager::

            with Valyu() as valyu:
                response = valyu.search("...")
        """
        if api_key is None:
            api_key = os.getenv("VALYU_API_KEY")
            if not api_key:
                raise ValueError("VALYU_API_KEY is not set")

        self.base_url = base_url
        self._timeout = timeout
        self.headers = {
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "User-Agent": f"valyu-py/{__version__} python/{platform.python_version()}",
            "X-Valyu-SDK": "valyu-py",
            "X-Valyu-SDK-Version": __version__,
        }

        if session is not None:
            self._session = session
            self._owns_session = False
            # Ensure required headers are present without clobbering caller's.
            for key, value in self.headers.items():
                self._session.headers.setdefault(key, value)
        else:
            self._session = requests.Session()
            self._session.headers.update(self.headers)
            adapter = HTTPAdapter(
                pool_connections=max_connections,
                pool_maxsize=max_connections,
                max_retries=0,
            )
            self._session.mount("https://", adapter)
            self._session.mount("http://", adapter)
            self._owns_session = True

        # Initialize DeepResearch client
        self.deepresearch = DeepResearchClient(self)

        # Initialize Batch client
        self.batch = BatchClient(self)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Release the underlying HTTP session if this client owns it."""
        if self._owns_session:
            self._session.close()

    def __enter__(self) -> "Valyu":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def search(
        self,
        query: str,
        search_type: SearchType = "all",
        max_num_results: int = 10,
        is_tool_call: Optional[bool] = True,
        relevance_threshold: Optional[float] = 0.5,
        max_price: Optional[int] = None,
        included_sources: Optional[List[str]] = None,
        excluded_sources: Optional[List[str]] = None,
        country_code: Optional[str] = None,
        response_length: Optional[ContentsResponseLength] = None,
        category: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fast_mode: bool = False,
        url_only: bool = False,
        source_biases: Optional[Dict[str, int]] = None,
        instructions: Optional[str] = None,
    ) -> Optional[SearchResponse]:
        """
        Query the Valyu DeepSearch API to give your AI relevant context.

        Args:
            query (str): The query string.
            search_type (SearchType): The type of search to perform - "all", "web", "proprietary", or "news".
            max_num_results (int): The maximum number of search results to return (max 100).
            is_tool_call (Optional[bool]): Whether this is a tool call.
            relevance_threshold (Optional[float]): The relevance threshold to not return results below.
            max_price (int): The maximum price (per thousand queries) to spend on the search.
            included_sources (Optional[List[str]]): The data sources to use for the search.
                Sources must be formatted as one of:
                • Domain: 'example.com', 'news.ycombinator.com'
                • URL with path: 'https://arxiv.org/abs/1706.03762'
                • Dataset name: 'valyu/valyu-arxiv', 'wiley/wiley-finance-books'
            excluded_sources (Optional[List[str]]): The data sources to exclude from the search.
                Sources must be formatted as one of:
                • Domain: 'paperswithcode.com', 'wikipedia.org'
                • URL with path: 'https://example.com/path/to/page'
                • Dataset name: 'provider/dataset-name'
            country_code (Optional[str]): Country code filter for search results.
            response_length (Optional[ContentsResponseLength]): Length of response content - "short", "medium", "large", "max", or integer for character count.
            category (Optional[str]): Category filter for search results.
            start_date (Optional[str]): Start date filter in YYYY-MM-DD format.
            end_date (Optional[str]): End date filter in YYYY-MM-DD format.
            fast_mode (bool): Enable fast mode for faster but shorter results. Good for general purpose queries. Defaults to False.
            url_only (bool): Return shortened snippets only. Defaults to False.
            source_biases (Optional[Dict[str, int]]): Bias values for specific sources to influence ranking.
                Keys are domains (e.g., "nasa.gov") or URL paths (e.g., "nytimes.com/science").
                Values are integers from -5 (strong demotion) to +5 (strong boost).
                Unlike included/excluded_sources, biases adjust ranking without hard filtering.
            instructions (Optional[str]): Natural language instructions to help rank results by relevance
                to user intent. Acts as a system prompt for the search — e.g.
                "Focus on oncology clinical trials from 2023 onwards". Max 500 characters.
                Ignored when fast_mode=True.

        Returns:
            Optional[SearchResponse]: The search response.
        """
        try:
            # Validate included_sources if provided
            if included_sources is not None:
                is_valid, invalid_sources = validate_sources(included_sources)
                if not is_valid:
                    return SearchResponse(
                        success=False,
                        error=format_validation_error(invalid_sources),
                        tx_id="validation-error-included",
                        query=query,
                        results=[],
                        results_by_source=ResultsBySource(web=0, proprietary=0),
                        total_deduction_dollars=0.0,
                        total_characters=0,
                    )

            # Validate excluded_sources if provided
            if excluded_sources is not None:
                is_valid, invalid_sources = validate_sources(excluded_sources)
                if not is_valid:
                    return SearchResponse(
                        success=False,
                        error=format_validation_error(invalid_sources),
                        tx_id="validation-error-excluded",
                        query=query,
                        results=[],
                        results_by_source=ResultsBySource(web=0, proprietary=0),
                        total_deduction_dollars=0.0,
                        total_characters=0,
                    )

            # Validate country_code if provided
            if (
                country_code is not None
                and country_code.upper() not in SUPPORTED_COUNTRY_CODES
            ):
                return SearchResponse(
                    success=False,
                    error=f"Invalid country_code. Must be one of: {', '.join(sorted(SUPPORTED_COUNTRY_CODES))}",
                    tx_id="validation-error-country",
                    query=query,
                    results=[],
                    results_by_source=ResultsBySource(web=0, proprietary=0),
                    total_deduction_dollars=0.0,
                    total_characters=0,
                )

            payload = {
                "query": query,
                "search_type": search_type,
                "max_num_results": max_num_results,
                "is_tool_call": is_tool_call,
                "relevance_threshold": relevance_threshold,
                "fast_mode": fast_mode,
                "url_only": url_only,
            }

            if max_price is not None:
                payload["max_price"] = max_price

            if included_sources is not None:
                payload["included_sources"] = included_sources

            if excluded_sources is not None:
                payload["excluded_sources"] = excluded_sources

            if country_code is not None:
                payload["country_code"] = country_code.upper()

            if response_length is not None:
                payload["response_length"] = response_length

            if category is not None:
                payload["category"] = category

            if start_date is not None:
                payload["start_date"] = start_date

            if end_date is not None:
                payload["end_date"] = end_date

            if source_biases is not None:
                payload["source_biases"] = source_biases

            if instructions is not None:
                payload["instructions"] = instructions

            response = self._session.post(
                f"{self.base_url}/search",
                json=payload,
                timeout=self._timeout,
            )

            data = response.json()

            if not response.ok:
                return SearchResponse(
                    success=False,
                    error=data.get("error", f"HTTP Error: {response.status_code}"),
                    tx_id=data.get("tx_id", f"error-{response.status_code}"),
                    query=query,
                    results=[],
                    results_by_source=ResultsBySource(web=0, proprietary=0),
                    total_deduction_dollars=0.0,
                    total_characters=0,
                )

            if not data.get("results") and data.get("error"):
                return SearchResponse(
                    success=True,
                    error=data.get("error"),
                    tx_id=data.get("tx_id", "0x0"),
                    query=data.get("query", query),
                    results=[],
                    results_by_source=data.get(
                        "results_by_source", ResultsBySource(web=0, proprietary=0)
                    ),
                    total_deduction_dollars=data.get("total_deduction_dollars", 0.0),
                    total_characters=data.get("total_characters", 0),
                )

            return SearchResponse(**data)
        except Exception as e:
            return SearchResponse(
                success=False,
                error=str(e),
                tx_id="exception-" + str(hash(str(e)))[:8],
                query=query,
                results=[],
                results_by_source=ResultsBySource(web=0, proprietary=0),
                total_deduction_dollars=0.0,
                total_characters=0,
            )

    def contents(
        self,
        urls: List[str],
        summary: Optional[Union[bool, str, Dict[str, Any]]] = None,
        extract_effort: Optional[ExtractEffort] = None,
        response_length: Optional[ContentsResponseLength] = None,
        max_price_dollars: Optional[float] = None,
        screenshot: bool = False,
        async_mode: bool = False,
        webhook_url: Optional[str] = None,
        wait: bool = False,
        poll_interval: int = 5,
        max_wait_time: int = 3600,
    ) -> Optional[
        Union[ContentsResponse, ContentsJobCreateResponse, ContentsJobStatus]
    ]:
        """
        Extract clean, structured content from web pages with optional AI-powered data extraction and summarization.

        Args:
            urls (List[str]): List of URLs to process (1-10 for sync, 1-50 for async).
            summary (Optional[Union[bool, str, Dict[str, Any]]]): AI summary configuration:
                - False/None: No AI processing (raw content)
                - True: Basic automatic summarization
                - str: Custom instructions (max 500 chars)
                - dict: JSON schema for structured extraction
            extract_effort (Optional[ExtractEffort]): Extraction thoroughness:
                - "normal": Fast extraction (default)
                - "high": More thorough but slower
                - "auto": Automatically determine extraction effort but slowest
            response_length (Optional[ContentsResponseLength]): Content length per URL:
                - "short": 25,000 characters (default)
                - "medium": 50,000 characters
                - "large": 100,000 characters
                - "max": No limit
                - int: Custom character limit
            max_price_dollars (Optional[float]): Maximum cost limit in USD.
            screenshot (bool): Request page screenshots (default: False).
                When True, each result will include a screenshot_url field
                with a pre-signed URL to a screenshot image of the page.
            async_mode (bool): Use async processing (required for >10 URLs). Default: False.
            webhook_url (Optional[str]): HTTPS URL for completion notification (async only).
            wait (bool): When async_mode=True, poll until complete and return final results. Default: False.
            poll_interval (int): Seconds between polls when wait=True. Default: 5.
            max_wait_time (int): Max seconds to wait when wait=True. Default: 3600.

        Returns:
            ContentsResponse (sync), ContentsJobCreateResponse (async, wait=False),
            or ContentsJobStatus (async, wait=True with terminal results).
        """
        try:
            if len(urls) > 50:
                return ContentsResponse(
                    success=False,
                    error="Maximum 50 URLs allowed per request",
                    tx_id="error-max-urls",
                    urls_requested=len(urls),
                    urls_processed=0,
                    urls_failed=len(urls),
                    results=[],
                    total_cost_dollars=0.0,
                    total_characters=0,
                )

            if len(urls) > 10 and not async_mode:
                return ContentsResponse(
                    success=False,
                    error="Requests with more than 10 URLs require async_mode=True",
                    tx_id="error-async-required",
                    urls_requested=len(urls),
                    urls_processed=0,
                    urls_failed=len(urls),
                    results=[],
                    total_cost_dollars=0.0,
                    total_characters=0,
                )

            use_async = len(urls) > 10 or async_mode

            payload: Dict[str, Any] = {
                "urls": urls,
            }
            if use_async:
                payload["async"] = True

            if summary is not None:
                payload["summary"] = summary

            if extract_effort is not None:
                payload["extract_effort"] = extract_effort

            if response_length is not None:
                payload["response_length"] = response_length

            if max_price_dollars is not None:
                payload["max_price_dollars"] = max_price_dollars

            if screenshot:
                payload["screenshot"] = screenshot

            if webhook_url:
                payload["webhook_url"] = webhook_url

            response = self._session.post(
                f"{self.base_url}/contents",
                json=payload,
                timeout=self._timeout,
            )

            data = response.json()

            if not response.ok:
                return ContentsResponse(
                    success=False,
                    error=data.get("error", f"HTTP Error: {response.status_code}"),
                    tx_id=data.get("tx_id", f"error-{response.status_code}"),
                    urls_requested=len(urls),
                    urls_processed=0,
                    urls_failed=len(urls),
                    results=[],
                    total_cost_dollars=0.0,
                    total_characters=0,
                )

            if response.status_code == 202:
                job = ContentsJobCreateResponse(**data)
                if wait and job.success:
                    return self.wait_for_contents_job(
                        job.job_id,
                        poll_interval=poll_interval,
                        max_wait_time=max_wait_time,
                    )
                return job

            return ContentsResponse(**data)
        except Exception as e:
            return ContentsResponse(
                success=False,
                error=str(e),
                tx_id="exception-" + str(hash(str(e)))[:8],
                urls_requested=len(urls),
                urls_processed=0,
                urls_failed=len(urls),
                results=[],
                total_cost_dollars=0.0,
                total_characters=0,
            )

    def get_contents_job(self, job_id: str) -> ContentsJobStatus:
        """
        Get the status of an async contents job.

        Args:
            job_id: Job ID from async contents response.

        Returns:
            ContentsJobStatus with current status and results when terminal.
        """
        try:
            response = self._session.get(
                f"{self.base_url}/contents/jobs/{job_id}",
                timeout=self._timeout,
            )
            data = response.json()

            if not response.ok:
                return ContentsJobStatus(
                    success=False,
                    job_id=job_id,
                    status="failed",
                    urls_total=0,
                    urls_processed=0,
                    urls_failed=0,
                    error=data.get("error", f"HTTP Error: {response.status_code}"),
                )

            return ContentsJobStatus(**data)
        except Exception as e:
            return ContentsJobStatus(
                success=False,
                job_id=job_id,
                status="failed",
                urls_total=0,
                urls_processed=0,
                urls_failed=0,
                error=str(e) or type(e).__name__,
            )

    def wait_for_contents_job(
        self,
        job_id: str,
        poll_interval: int = 5,
        max_wait_time: int = 3600,
        on_progress: Optional[Callable[[ContentsJobStatus], None]] = None,
    ) -> ContentsJobStatus:
        """
        Poll until an async contents job reaches a terminal state.

        Args:
            job_id: Job ID to wait for.
            poll_interval: Seconds between polls. Default: 5.
            max_wait_time: Max seconds to wait. Default: 3600.
            on_progress: Optional callback for progress updates.

        Returns:
            Final ContentsJobStatus with results when terminal.

        Raises:
            TimeoutError: If max_wait_time exceeded.
            ValueError: If job fails.
        """
        start_time = time.time()
        terminal_statuses = ("completed", "partial", "failed")

        while True:
            status = self.get_contents_job(job_id)

            if not status.success:
                raise ValueError(f"Failed to get job status: {status.error}")

            if on_progress:
                on_progress(status)

            if status.status in terminal_statuses:
                return status

            elapsed = time.time() - start_time
            if elapsed > max_wait_time:
                raise TimeoutError(
                    f"Job did not complete within {max_wait_time} seconds"
                )

            time.sleep(poll_interval)

    def answer(
        self,
        query: str,
        structured_output: Optional[Dict[str, Any]] = None,
        system_instructions: Optional[str] = None,
        search_type: SearchType = "all",
        data_max_price: Optional[float] = None,
        country_code: Optional[str] = None,
        included_sources: Optional[List[str]] = None,
        excluded_sources: Optional[List[str]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        fast_mode: bool = False,
        streaming: bool = False,
    ) -> Union[AnswerResponse, AnswerStreamGenerator]:
        """
        Query the Valyu Answer API to get AI-processed answers to your questions.

        Args:
            query (str): The query string.
            structured_output (Optional[Dict[str, Any]]): JSON Schema object. When provided,
                the response 'contents' is structured to this schema.
            system_instructions (Optional[str]): Custom system-level instructions (<= 2000 chars).
            search_type (SearchType): The type of search to perform - "all", "web", "proprietary", or "news".
            data_max_price (float): Maximum spend (USD) for data retrieval. Separate from AI costs.
            country_code (Optional[str]): 2-letter ISO code or 'ALL'.
            included_sources (Optional[List[str]]): The data sources to use for the search.
                Sources must be formatted as one of:
                • Domain: 'example.com', 'news.ycombinator.com'
                • URL with path: 'https://arxiv.org/abs/1706.03762'
                • Dataset name: 'valyu/valyu-arxiv', 'wiley/wiley-finance-books'
            excluded_sources (Optional[List[str]]): The data sources to exclude from the search.
                Sources must be formatted as one of:
                • Domain: 'paperswithcode.com', 'wikipedia.org'
                • URL with path: 'https://example.com/path/to/page'
                • Dataset name: 'provider/dataset-name'
            start_date (Optional[str]): Start date filter in YYYY-MM-DD format.
            end_date (Optional[str]): End date filter in YYYY-MM-DD format.
            fast_mode (bool): Enable fast mode for faster but shorter results. Defaults to False.
            streaming (bool): Enable streaming mode to receive chunks as they're generated.
                When False (default), waits for the complete response.
                When True, returns a generator that yields AnswerStreamChunk objects.

        Returns:
            Union[AnswerResponse, AnswerStreamGenerator]:
                - If streaming=False: Returns AnswerSuccessResponse or AnswerErrorResponse
                - If streaming=True: Returns a generator yielding AnswerStreamChunk objects
        """
        # Validate inputs first
        validation_error = self._validate_answer_params(
            included_sources=included_sources,
            excluded_sources=excluded_sources,
            country_code=country_code,
            system_instructions=system_instructions,
        )
        if validation_error:
            if streaming:

                def error_generator():
                    yield AnswerStreamChunk(type="error", error=validation_error)

                return error_generator()
            return AnswerErrorResponse(error=validation_error)

        payload = self._build_answer_payload(
            query=query,
            structured_output=structured_output,
            system_instructions=system_instructions,
            search_type=search_type,
            data_max_price=data_max_price,
            country_code=country_code,
            included_sources=included_sources,
            excluded_sources=excluded_sources,
            start_date=start_date,
            end_date=end_date,
            fast_mode=fast_mode,
        )

        if streaming:
            return self._stream_answer(payload)
        else:
            return self._fetch_answer(payload)

    def _validate_answer_params(
        self,
        included_sources: Optional[List[str]],
        excluded_sources: Optional[List[str]],
        country_code: Optional[str],
        system_instructions: Optional[str],
    ) -> Optional[str]:
        """Validate answer parameters and return error message if invalid."""
        # Validate included_sources if provided
        if included_sources is not None:
            is_valid, invalid_sources = validate_sources(included_sources)
            if not is_valid:
                return format_validation_error(invalid_sources)

        # Validate excluded_sources if provided
        if excluded_sources is not None:
            is_valid, invalid_sources = validate_sources(excluded_sources)
            if not is_valid:
                return format_validation_error(invalid_sources)

        # Validate country_code if provided
        if (
            country_code is not None
            and country_code.upper() not in SUPPORTED_COUNTRY_CODES
        ):
            return f"Invalid country_code. Must be one of: {', '.join(sorted(SUPPORTED_COUNTRY_CODES))}"

        # Validate system_instructions length
        if system_instructions is not None and len(system_instructions.strip()) > 2000:
            return "system_instructions cannot exceed 2000 characters"

        return None

    def _build_answer_payload(
        self,
        query: str,
        structured_output: Optional[Dict[str, Any]],
        system_instructions: Optional[str],
        search_type: SearchType,
        data_max_price: Optional[float],
        country_code: Optional[str],
        included_sources: Optional[List[str]],
        excluded_sources: Optional[List[str]],
        start_date: Optional[str],
        end_date: Optional[str],
        fast_mode: bool,
    ) -> Dict[str, Any]:
        """Build the request payload for the answer API."""
        payload: Dict[str, Any] = {
            "query": query,
            "search_type": search_type,
            "fast_mode": fast_mode,
        }

        if data_max_price is not None:
            payload["data_max_price"] = data_max_price

        if structured_output is not None:
            payload["structured_output"] = structured_output

        if system_instructions is not None:
            payload["system_instructions"] = system_instructions.strip()

        if country_code is not None:
            payload["country_code"] = country_code.upper()

        if included_sources is not None:
            payload["included_sources"] = included_sources

        if excluded_sources is not None:
            payload["excluded_sources"] = excluded_sources

        if start_date is not None:
            payload["start_date"] = start_date

        if end_date is not None:
            payload["end_date"] = end_date

        return payload

    def _fetch_answer(self, payload: Dict[str, Any]) -> AnswerResponse:
        """Fetch the complete answer (non-streaming mode)."""
        try:
            # Use streaming internally but collect into final response
            response = self._session.post(
                f"{self.base_url}/answer",
                json=payload,
                headers={"Accept": "text/event-stream"},
                stream=True,
            )

            if not response.ok:
                try:
                    data = response.json()
                    return AnswerErrorResponse(
                        error=data.get("error", f"HTTP Error: {response.status_code}")
                    )
                except Exception:
                    return AnswerErrorResponse(
                        error=f"HTTP Error: {response.status_code}"
                    )

            # Collect streamed data into final response
            full_content = ""
            search_results: List[Dict[str, Any]] = []
            final_metadata: Dict[str, Any] = {}

            for line in response.iter_lines(decode_unicode=True):
                if not line or not line.startswith("data: "):
                    continue

                data_str = line[6:]  # Remove "data: " prefix

                if data_str == "[DONE]":
                    break

                try:
                    parsed = json.loads(data_str)

                    # Handle search results (streamed first)
                    if "search_results" in parsed and "success" not in parsed:
                        search_results.extend(parsed["search_results"])

                    # Handle content chunks
                    elif "choices" in parsed:
                        choices = parsed.get("choices", [])
                        if choices:
                            delta = choices[0].get("delta", {})
                            content = delta.get("content", "")
                            if content:
                                full_content += content

                    # Handle final metadata
                    elif "success" in parsed:
                        final_metadata = parsed

                except json.JSONDecodeError:
                    continue

            # Build the final response
            if final_metadata.get("success"):
                # Use search_results from final metadata if available, otherwise use collected ones
                final_search_results = final_metadata.get(
                    "search_results", search_results
                )

                # Handle extraction_metadata if present
                extraction_meta = None
                if final_metadata.get("extraction_metadata"):
                    extraction_meta = ExtractionMetadata(
                        **final_metadata["extraction_metadata"]
                    )

                return AnswerSuccessResponse(
                    success=True,
                    tx_id=final_metadata.get("tx_id", ""),
                    original_query=final_metadata.get(
                        "original_query", payload.get("query", "")
                    ),
                    contents=final_metadata.get("contents", full_content) or full_content,
                    search_results=(
                        [SearchResult(**r) for r in final_search_results]
                        if final_search_results
                        else []
                    ),
                    search_metadata=SearchMetadata(
                        **final_metadata.get(
                            "search_metadata",
                            {
                                "tx_ids": [],
                                "number_of_results": 0,
                                "total_characters": 0,
                            },
                        )
                    ),
                    ai_usage=AIUsage(
                        **final_metadata.get(
                            "ai_usage", {"input_tokens": 0, "output_tokens": 0}
                        )
                    ),
                    cost=CostBreakdown(
                        **final_metadata.get(
                            "cost",
                            {
                                "total_deduction_dollars": 0,
                                "search_deduction_dollars": 0,
                                "ai_deduction_dollars": 0,
                            },
                        )
                    ),
                    extraction_metadata=extraction_meta,
                )
            else:
                return AnswerErrorResponse(
                    error=final_metadata.get("error", "Unknown error occurred")
                )

        except Exception as e:
            return AnswerErrorResponse(error=str(e))

    def _stream_answer(self, payload: Dict[str, Any]) -> AnswerStreamGenerator:
        """Stream the answer response as chunks."""
        try:
            response = self._session.post(
                f"{self.base_url}/answer",
                json=payload,
                headers={"Accept": "text/event-stream"},
                stream=True,
            )

            if not response.ok:
                try:
                    data = response.json()
                    yield AnswerStreamChunk(
                        type="error",
                        error=data.get("error", f"HTTP Error: {response.status_code}"),
                    )
                except Exception:
                    yield AnswerStreamChunk(
                        type="error", error=f"HTTP Error: {response.status_code}"
                    )
                return

            for line in response.iter_lines(decode_unicode=True):
                if not line or not line.startswith("data: "):
                    continue

                data_str = line[6:]  # Remove "data: " prefix

                if data_str == "[DONE]":
                    yield AnswerStreamChunk(type="done")
                    break

                try:
                    parsed = json.loads(data_str)

                    # Handle search results (streamed first)
                    if "search_results" in parsed and "success" not in parsed:
                        yield AnswerStreamChunk(
                            type="search_results",
                            search_results=[
                                SearchResult(**r) for r in parsed["search_results"]
                            ],
                        )

                    # Handle content chunks
                    elif "choices" in parsed:
                        choices = parsed.get("choices", [])
                        if choices:
                            delta = choices[0].get("delta", {})
                            content = delta.get("content", "")
                            finish_reason = choices[0].get("finish_reason")

                            if content or finish_reason:
                                yield AnswerStreamChunk(
                                    type="content",
                                    content=content,
                                    finish_reason=finish_reason,
                                )

                    # Handle final metadata
                    elif "success" in parsed:
                        yield AnswerStreamChunk(
                            type="metadata",
                            tx_id=parsed.get("tx_id"),
                            original_query=parsed.get("original_query"),
                            contents=parsed.get("contents"),
                            search_results=(
                                [
                                    SearchResult(**r)
                                    for r in parsed.get("search_results", [])
                                ]
                                if parsed.get("search_results")
                                else None
                            ),
                            search_metadata=(
                                SearchMetadata(**parsed.get("search_metadata", {}))
                                if parsed.get("search_metadata")
                                else None
                            ),
                            ai_usage=(
                                AIUsage(**parsed.get("ai_usage", {}))
                                if parsed.get("ai_usage")
                                else None
                            ),
                            cost=(
                                CostBreakdown(**parsed.get("cost", {}))
                                if parsed.get("cost")
                                else None
                            ),
                            extraction_metadata=(
                                ExtractionMetadata(
                                    **parsed.get("extraction_metadata", {})
                                )
                                if parsed.get("extraction_metadata")
                                else None
                            ),
                        )

                except json.JSONDecodeError:
                    continue

        except Exception as e:
            yield AnswerStreamChunk(type="error", error=str(e))

    def datasources(
        self,
        category: Optional[DatasourceCategoryType] = None,
    ) -> DatasourcesResponse:
        """
        List all available datasources.

        This API provides a tool manifest for AI agents to discover available
        data sources. Use this to understand what datasources are available
        before making search requests with included_sources or excluded_sources.

        Args:
            category (Optional[DatasourceCategoryType]): Filter by category.
                Valid values: "research", "healthcare", "markets", "company",
                "economic", "predictions", "transportation", "legal",
                "politics", "patents"

        Returns:
            DatasourcesResponse: List of available datasources with their
                metadata including id, name, description, pricing, and
                example_queries for few-shot prompting.
        """
        try:
            params = {}
            if category is not None:
                params["category"] = category

            response = self._session.get(
                f"{self.base_url}/datasources",
                params=params if params else None,
            )

            data = response.json()

            if not response.ok:
                return DatasourcesResponse(
                    success=False,
                    error=data.get("error", f"HTTP Error: {response.status_code}"),
                    datasources=[],
                )

            # Parse datasources from response
            datasources = []
            for ds in data.get("datasources", []):
                datasources.append(Datasource(**ds))

            return DatasourcesResponse(
                success=True,
                datasources=datasources,
            )
        except Exception as e:
            return DatasourcesResponse(
                success=False,
                error=str(e),
                datasources=[],
            )

    def datasources_categories(self) -> DatasourceCategoriesResponse:
        """
        List all available datasource categories.

        Use this to understand the landscape of available data before
        filtering with the datasources() method.

        Returns:
            DatasourceCategoriesResponse: List of categories with their
                names and dataset counts.
        """
        try:
            response = self._session.get(
                f"{self.base_url}/datasources/categories",
            )

            data = response.json()

            if not response.ok:
                return DatasourceCategoriesResponse(
                    success=False,
                    error=data.get("error", f"HTTP Error: {response.status_code}"),
                    categories=[],
                )

            # Parse categories from response
            categories = []
            for cat in data.get("categories", []):
                categories.append(DatasourceCategory(**cat))

            return DatasourceCategoriesResponse(
                success=True,
                categories=categories,
            )
        except Exception as e:
            return DatasourceCategoriesResponse(
                success=False,
                error=str(e),
                categories=[],
            )
