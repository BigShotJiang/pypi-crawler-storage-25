from __future__ import annotations

import asyncio
from typing import Any

import grpc.aio

from wool import protocol
from wool.runtime.worker.auth import WorkerCredentials
from wool.runtime.worker.base import Worker
from wool.runtime.worker.base import WorkerOptions
from wool.runtime.worker.process import WorkerProcess


# public
class LocalWorker(Worker):
    """Worker running in a local subprocess.

    Spawns a dedicated process hosting a gRPC server for task execution.
    Handles multiple concurrent tasks in an isolated asyncio event loop.

    **Basic usage:**

    .. code-block:: python

        worker = LocalWorker("gpu-capable")
        await worker.start()
        # Worker is now accepting tasks
        await worker.stop()

    **Custom configuration:**

    .. code-block:: python

        worker = LocalWorker(
            "production",
            "high-memory",
            host="0.0.0.0",  # Listen on all interfaces
            port=50051,  # Fixed port
            shutdown_grace_period=30.0,
        )

    :param tags:
        Capability tags for filtering and selection.
    :param host:
        Host address to bind. Defaults to localhost.
    :param port:
        Port to bind. 0 for random available port.
    :param shutdown_grace_period:
        Graceful shutdown timeout in seconds.
    :param proxy_pool_ttl:
        Proxy pool TTL in seconds.
    :param credentials:
        Optional credentials for TLS/mTLS authentication:

        - :class:`WorkerCredentials`: Provides both server and client
          credentials for mutual TLS. Enables secure worker-to-worker
          communication.
        - ``None``: Worker uses insecure connections.
    :param options:
        gRPC message size options. Defaults to
        :class:`WorkerOptions` with 100 MB limits.
    :param extra:
        Additional metadata as key-value pairs.
    """

    _worker_process: WorkerProcess
    _credentials: WorkerCredentials | None

    def __init__(
        self,
        *tags: str,
        host: str = "127.0.0.1",
        port: int = 0,
        shutdown_grace_period: float = 60.0,
        proxy_pool_ttl: float = 60.0,
        credentials: WorkerCredentials | None = None,
        options: WorkerOptions | None = None,
        **extra: Any,
    ):
        super().__init__(*tags, **extra)
        self._credentials = credentials
        self._worker_process = WorkerProcess(
            uid=self._uid,
            host=host,
            port=port,
            shutdown_grace_period=shutdown_grace_period,
            proxy_pool_ttl=proxy_pool_ttl,
            credentials=credentials,
            options=options,
            tags=frozenset(self._tags),
            extra=self._extra,
        )

    @property
    def address(self) -> str | None:
        """The network address where the worker is listening.

        :returns:
            The address in "host:port" format, or None if not started.
        """
        return self._worker_process.address

    async def _start(self, timeout: float | None):
        """Start the worker process and register it with the pool.

        Initializes the registrar service, starts the worker process
        with its gRPC server, and registers the worker's network
        address with the registrar for discovery by client sessions.

        :param timeout:
            Maximum time in seconds to wait for worker process startup.
        """
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(
            None, lambda t: self._worker_process.start(timeout=t), timeout
        )
        self._info = self._worker_process.metadata
        if self._info is None:
            raise RuntimeError("Worker process failed to start - no metadata")

    async def _stop(self, timeout: float | None):
        """Stop the worker process and unregister it from the pool.

        Unregisters the worker from the registrar service, gracefully
        shuts down the worker process using a gRPC stop request, and cleans
        up the registrar service. If graceful shutdown fails, the process
        is forcefully terminated.

        For workers configured with :class:`WorkerCredentials`, uses
        the client credentials to establish a secure connection for the
        stop operation. For insecure workers, uses an insecure channel.
        """
        if self._worker_process.is_alive():
            assert self.address

            # Create appropriate channel based on available credentials
            if self._credentials is not None:
                credentials = self._credentials.client_credentials()
                channel = grpc.aio.secure_channel(self.address, credentials)
            else:
                channel = grpc.aio.insecure_channel(self.address)

            try:
                stub = protocol.WorkerStub(channel)
                await stub.stop(protocol.StopRequest(timeout=timeout))
            finally:
                await channel.close()
