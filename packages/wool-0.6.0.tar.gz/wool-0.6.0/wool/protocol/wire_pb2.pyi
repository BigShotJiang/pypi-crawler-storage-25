from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RuntimeContext(_message.Message):
    __slots__ = ("dispatch_timeout",)
    DISPATCH_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    dispatch_timeout: float
    def __init__(self, dispatch_timeout: _Optional[float] = ...) -> None: ...

class Task(_message.Message):
    __slots__ = ("version", "id", "caller", "tag", "proxy_id", "proxy", "callable", "args", "kwargs", "timeout", "context", "serializer")
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    CALLER_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    PROXY_ID_FIELD_NUMBER: _ClassVar[int]
    PROXY_FIELD_NUMBER: _ClassVar[int]
    CALLABLE_FIELD_NUMBER: _ClassVar[int]
    ARGS_FIELD_NUMBER: _ClassVar[int]
    KWARGS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    SERIALIZER_FIELD_NUMBER: _ClassVar[int]
    version: str
    id: str
    caller: str
    tag: str
    proxy_id: str
    proxy: bytes
    callable: bytes
    args: bytes
    kwargs: bytes
    timeout: int
    context: RuntimeContext
    serializer: bytes
    def __init__(self, version: _Optional[str] = ..., id: _Optional[str] = ..., caller: _Optional[str] = ..., tag: _Optional[str] = ..., proxy_id: _Optional[str] = ..., proxy: _Optional[bytes] = ..., callable: _Optional[bytes] = ..., args: _Optional[bytes] = ..., kwargs: _Optional[bytes] = ..., timeout: _Optional[int] = ..., context: _Optional[_Union[RuntimeContext, _Mapping]] = ..., serializer: _Optional[bytes] = ...) -> None: ...

class TaskEnvelope(_message.Message):
    __slots__ = ("version", "id", "caller", "tag")
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    CALLER_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    version: str
    id: str
    caller: str
    tag: str
    def __init__(self, version: _Optional[str] = ..., id: _Optional[str] = ..., caller: _Optional[str] = ..., tag: _Optional[str] = ...) -> None: ...

class Message(_message.Message):
    __slots__ = ("dump",)
    DUMP_FIELD_NUMBER: _ClassVar[int]
    dump: bytes
    def __init__(self, dump: _Optional[bytes] = ...) -> None: ...

class Ack(_message.Message):
    __slots__ = ("version",)
    VERSION_FIELD_NUMBER: _ClassVar[int]
    version: str
    def __init__(self, version: _Optional[str] = ...) -> None: ...

class Nack(_message.Message):
    __slots__ = ("reason",)
    REASON_FIELD_NUMBER: _ClassVar[int]
    reason: str
    def __init__(self, reason: _Optional[str] = ...) -> None: ...

class Request(_message.Message):
    __slots__ = ("task", "next", "send", "throw")
    TASK_FIELD_NUMBER: _ClassVar[int]
    NEXT_FIELD_NUMBER: _ClassVar[int]
    SEND_FIELD_NUMBER: _ClassVar[int]
    THROW_FIELD_NUMBER: _ClassVar[int]
    task: Task
    next: Void
    send: Message
    throw: Message
    def __init__(self, task: _Optional[_Union[Task, _Mapping]] = ..., next: _Optional[_Union[Void, _Mapping]] = ..., send: _Optional[_Union[Message, _Mapping]] = ..., throw: _Optional[_Union[Message, _Mapping]] = ...) -> None: ...

class Response(_message.Message):
    __slots__ = ("ack", "nack", "result", "exception")
    ACK_FIELD_NUMBER: _ClassVar[int]
    NACK_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    EXCEPTION_FIELD_NUMBER: _ClassVar[int]
    ack: Ack
    nack: Nack
    result: Message
    exception: Message
    def __init__(self, ack: _Optional[_Union[Ack, _Mapping]] = ..., nack: _Optional[_Union[Nack, _Mapping]] = ..., result: _Optional[_Union[Message, _Mapping]] = ..., exception: _Optional[_Union[Message, _Mapping]] = ...) -> None: ...

class StopRequest(_message.Message):
    __slots__ = ("timeout",)
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    timeout: float
    def __init__(self, timeout: _Optional[float] = ...) -> None: ...

class WorkerMetadata(_message.Message):
    __slots__ = ("uid", "address", "pid", "version", "tags", "extra", "secure", "connection")
    class ExtraEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    UID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    EXTRA_FIELD_NUMBER: _ClassVar[int]
    SECURE_FIELD_NUMBER: _ClassVar[int]
    CONNECTION_FIELD_NUMBER: _ClassVar[int]
    uid: str
    address: str
    pid: int
    version: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    extra: _containers.ScalarMap[str, str]
    secure: bool
    connection: ChannelOptions
    def __init__(self, uid: _Optional[str] = ..., address: _Optional[str] = ..., pid: _Optional[int] = ..., version: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., extra: _Optional[_Mapping[str, str]] = ..., secure: bool = ..., connection: _Optional[_Union[ChannelOptions, _Mapping]] = ...) -> None: ...

class ChannelOptions(_message.Message):
    __slots__ = ("max_receive_message_length", "max_send_message_length", "keepalive_time_ms", "keepalive_timeout_ms", "keepalive_permit_without_calls", "max_pings_without_data", "max_concurrent_streams", "compression")
    MAX_RECEIVE_MESSAGE_LENGTH_FIELD_NUMBER: _ClassVar[int]
    MAX_SEND_MESSAGE_LENGTH_FIELD_NUMBER: _ClassVar[int]
    KEEPALIVE_TIME_MS_FIELD_NUMBER: _ClassVar[int]
    KEEPALIVE_TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    KEEPALIVE_PERMIT_WITHOUT_CALLS_FIELD_NUMBER: _ClassVar[int]
    MAX_PINGS_WITHOUT_DATA_FIELD_NUMBER: _ClassVar[int]
    MAX_CONCURRENT_STREAMS_FIELD_NUMBER: _ClassVar[int]
    COMPRESSION_FIELD_NUMBER: _ClassVar[int]
    max_receive_message_length: int
    max_send_message_length: int
    keepalive_time_ms: int
    keepalive_timeout_ms: int
    keepalive_permit_without_calls: bool
    max_pings_without_data: int
    max_concurrent_streams: int
    compression: int
    def __init__(self, max_receive_message_length: _Optional[int] = ..., max_send_message_length: _Optional[int] = ..., keepalive_time_ms: _Optional[int] = ..., keepalive_timeout_ms: _Optional[int] = ..., keepalive_permit_without_calls: bool = ..., max_pings_without_data: _Optional[int] = ..., max_concurrent_streams: _Optional[int] = ..., compression: _Optional[int] = ...) -> None: ...

class Void(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
