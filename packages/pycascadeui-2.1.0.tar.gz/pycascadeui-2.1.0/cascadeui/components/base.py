# // ========================================( Modules )======================================== // #


from typing import Any, Callable, Dict, List, Optional, Union

import discord
from discord.ui import Item

from ..state.actions import ActionCreators
from ..utils.logging import AsyncLogger

logger = AsyncLogger(name=__name__, level="DEBUG", path="logs", mode="a", prefix="cascadeui")


# // ========================================( Classes )======================================== // #


class StatefulComponent:
    """Base mixin for components that interact with state."""

    def create_stateful_callback(self, component, original_callback=None):
        """Create a callback that updates state."""
        component_id = getattr(component, "custom_id", None) or str(id(component))

        async def stateful_callback(interaction):
            # Get view from the component itself
            view = component.view

            if not view:
                logger.error(f"Could not find view for component {component_id}")

                # Call original callback if provided
                if original_callback:
                    return await original_callback(interaction)
                return

            # Get component value
            value = None
            if hasattr(component, "value"):
                value = component.value
            elif hasattr(component, "values"):
                value = component.values
            elif isinstance(component, discord.ui.Button):
                value = True

            # Call original callback FIRST so it can respond to the interaction
            # before state dispatch triggers update_from_state notifications
            if original_callback:
                await original_callback(interaction)

            # Skip dispatch if the callback destroyed the view (exit, push, etc.)
            if view.is_finished():
                return

            # Then dispatch state update (may trigger update_from_state on views)
            payload = ActionCreators.component_interaction(
                component_id=component_id, view_id=view.id, user_id=interaction.user.id, value=value
            )
            await view.dispatch("COMPONENT_INTERACTION", payload)

        return stateful_callback


class StatefulButton(discord.ui.Button, StatefulComponent):
    """A button that interacts with state."""

    def __init__(self, *args, callback=None, **kwargs):
        super().__init__(*args, **kwargs)

        # Store original callback
        self.original_callback = callback

        # Create stateful callback
        if callback:
            self.callback = self.create_stateful_callback(self, callback)


class StatefulSelect(discord.ui.Select, StatefulComponent):
    """A select menu that interacts with state."""

    def __init__(self, *args, callback=None, **kwargs):
        super().__init__(*args, **kwargs)

        # Store original callback
        self.original_callback = callback

        # Create stateful callback
        if callback:
            self.callback = self.create_stateful_callback(self, callback)
