"""Shared Deepy type definitions."""

