import requests
import pandas as pd


class Client:
    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: int = 60,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _get(self, endpoint: str):
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        response = requests.get(
            url,
            headers=self.headers,
            timeout=self.timeout,
        )

        try:
            response.raise_for_status()
        except requests.HTTPError as exc:
            raise RuntimeError(
                f"Annapurna API error {response.status_code}: {response.text}"
            ) from exc

        return response.json()

    def whoami(self):
        return self._get("whoami/")

    def get_projects(self):
        return self._get("projects/")

    def get_project_objects(self, project_name: str):
        return self._get(f"projects/{project_name}/objects/")

    def get_metadata(self, project_name: str, dataset_type: str, object_name: str):
        return self._get(
            f"projects/{project_name}/{dataset_type}/{object_name}/metadata/"
        )

    def get_download_url(self, project_name: str, dataset_type: str, object_name: str):
        return self._get(
            f"projects/{project_name}/{dataset_type}/{object_name}/download/"
        )

    def read_parquet(self, project_name: str, dataset_type: str, object_name: str):
        download_data = self.get_download_url(project_name, dataset_type, object_name)
        download_url = download_data.get("download_url")

        if not download_url:
            raise RuntimeError("No download_url returned by Annapurna API.")

        return pd.read_parquet(download_url)