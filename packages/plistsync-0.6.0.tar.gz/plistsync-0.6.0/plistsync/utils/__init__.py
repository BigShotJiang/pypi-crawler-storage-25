import dataclasses
import json
import os
import pathlib
import re
import urllib.parse
from collections.abc import Iterable
from typing import TypeVar


class EnhancedJSONEncoder(json.JSONEncoder):
    def default(self, o):
        if dataclasses.is_dataclass(o):
            return dataclasses.asdict(o)  # type: ignore
        return super().default(o)


def build_url(base_url: str, params: dict) -> str:
    """Construct a URL with a base hostname and a dictionary of parameters.

    Parameters
    ----------
    base_url (str): The base URL to which the parameters will be appended.
    params (dict): A dictionary of parameters to append to the URL.

    Returns
    -------
    str: The constructed URL.
    """
    if not params:
        return base_url

    url = base_url
    i = 0
    for key, value in params.items():
        # Encode the values for URLs
        if i == 0:
            url += f"?{key}={urllib.parse.quote(value)}"
            i += 1
        else:
            url += f"&{key}={urllib.parse.quote(value)}"
    return url


def get_config_dir() -> pathlib.Path:
    """Get the configuration directory.

    Returns
    -------
    str: The configuration directory.
    """
    o = os.getenv("PSYNC_CONFIG_DIR", "./config")
    pathlib.Path(o).mkdir(parents=True)
    return pathlib.Path(o).resolve()


def camel_to_snake(text: str) -> str:
    """Convert camelCase to snake_case."""
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", text)
    s2 = re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()
    return re.sub("_+", "_", s2)


A = TypeVar("A")


def chunk_list(lst: list[A], chunk_size: int) -> Iterable[list[A]]:
    """
    Chunk a list into smaller lists of the specified size.

    Parameters
    ----------
    lst: list[A]
        List to be chunked
    chunk_size: int
        Maximum size of each chunk

    Yields
    ------
    list[A]
        Chunks of the original list

    """
    for i in range(0, len(lst), chunk_size):
        yield lst[i : i + chunk_size]


def safe_webbrowser_open(url: str) -> bool:
    """Open URL in the default browser, silencing browser stderr/stdout."""
    import subprocess
    import webbrowser

    controller = webbrowser.get()  # default browser controller

    # If it's a BackgroundBrowser, override Popen behavior
    if isinstance(controller, webbrowser.BackgroundBrowser):

        def quiet_open(url, new=0, autoraise=True):
            try:
                subprocess.Popen(
                    [controller.name, url],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    close_fds=True,
                )
                return True
            except Exception:
                return False

        return quiet_open(url)

    # Fallback: just use normal open()
    return controller.open(url)
