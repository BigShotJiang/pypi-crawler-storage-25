from pathlib import Path
from collections.abc import Iterable

import pytest
from plistsync.services.plex.playlist import PlexPlaylist
from plistsync.services.plex.track import PlexTrack
from tests.abc.collection import CollectionTestBase, LibraryCollectionTestBase

from plistsync.services.plex import PlexLibrary


class TestPlexPlaylist(CollectionTestBase):
    collection_class = PlexPlaylist

    library_collection: PlexLibrary

    @pytest.fixture(autouse=True)
    def setup(self, plex_library_collection_mock, playlist_data):
        self.library_collection = plex_library_collection_mock
        self.playlist_data = playlist_data

    def create_collection(self) -> Iterable[PlexPlaylist]:
        """Create a PlexLibrary for testing.

        This method should create a collection with some dummy data. It must be implemented by the subclass.
        """
        pl = PlexPlaylist(
            library=self.library_collection,
            data=self.playlist_data,
        )
        pl.tracks = [
            PlexTrack({"ratingKey": "10637"}),
        ]
        yield pl

    def create_sample_track(self):
        """Create a sample track for testing matches within collections.

        This has to be implemented by the subclass and be a valid Track in the
        collection!
        """
        for collection in self.create_collection():
            for track in collection.tracks:
                return track
        raise RuntimeError("No track found in created collection")


class TestPlexLibrary(LibraryCollectionTestBase):
    collection_class = PlexLibrary

    @pytest.fixture(autouse=True)
    def setup(self, plex_library_collection_mock):
        self.collection = plex_library_collection_mock

    def create_collection(self, *args, **kwargs):
        """Create a PlexLibrary for testing.

        This method should create a collection with some dummy data. It must be implemented by the subclass.
        """
        yield self.collection

    def create_sample_track(self):
        """Create a sample track for testing matches within collections.

        This has to be implemented by the subclass and be a valid Track in the
        collection!
        """
        for library_collection in self.create_collection():
            for track in library_collection.tracks:
                return track
        raise RuntimeError("No track found in created collection")

    @property
    def known_playlists(self) -> list[tuple[str, str]]:
        return [
            ("name", "Test Playlist"),
        ]

    @property
    def unknown_playlists(self) -> list[tuple[str, str]]:
        return [
            ("name", "Unknown Playlist"),
            ("name", "Another Unknown Playlist"),
        ]

    def test_preload(self):
        """Test that preloading the library collection works."""
        library_collection = next(iter(self.create_collection()))
        assert isinstance(library_collection, PlexLibrary)
        library_collection.preload()
        assert library_collection._fetched is True, (
            "Library collection should be marked as fetched after preload()"
        )
        assert library_collection._tracks is not None, (
            "Library collection should have tracks loaded after preload()"
        )

        tracks = list(library_collection.tracks)
        assert len(tracks) > 0, "Library collection should yield tracks after preload()"

    def test_locations_property(self):
        """Test that the locations property returns the expected results."""
        for library_collection in self.create_collection():
            locations = library_collection.locations
            assert isinstance(locations, Iterable), "Locations should be iterable"
            assert len(list(locations)) > 0, "Locations should not be empty"
            assert all(isinstance(loc, Path) for loc in locations), (
                "All locations should be Path instances"
            )

    def test_get_playlist_raise(self):
        """Get playlist via path not allowed."""
        with pytest.raises(ValueError):
            for library_collection in self.create_collection():
                library_collection.get_playlist(name="foo", id=121)
