"""Algorithm detection: query DB signals to find suboptimal patterns.

Each detector has signature ``(conn) -> list[dict]`` and returns findings
with fields: task_id, detected_way, suggested_way, symbol_id, symbol_name,
kind, location, confidence, reason.

Design principles (informed by research):
- Structural AST patterns (loop depth, accumulator, subscript) are more
  reliable than function-name matching alone.
- Name matching is a confidence booster, not a gate.
- Idiom-only improvements (same Big-O) get ``low`` confidence.
- Genuine complexity-class improvements get ``medium`` or ``high``.
- Suppress known false-positive patterns (grid traversal, intentional polling).
"""

from __future__ import annotations

import functools
import json
import os
import re
import sqlite3

from roam.catalog.tasks import best_way


def _is_test_path(path: str) -> bool:
    # X14 (2026-05-06) — when --include-tests was set on the CLI, force
    # this to return False so every detector stops filtering test paths.
    if _INCLUDE_TESTS_OVERRIDE:
        return False
    p = path.replace("\\", "/").lower()
    base = os.path.basename(p)
    if base.startswith("test_") or base.endswith("_test.py"):
        return True
    if "tests/" in p or "test/" in p or "__tests__/" in p or "spec/" in p:
        return True
    return False


def _loc(path: str, line) -> str:
    if line is not None:
        return f"{path}:{line}"
    return path


def _finding(
    task_id,
    detected_way,
    sym,
    reason,
    confidence="medium",
    *,
    evidence=None,
    fix=None,
    match_line=None,
    snippet=None,
    matched_patterns=None,
):
    """Build a finding dict.

    M1 (2026-05-06): when ``match_line`` is supplied, the finding's
    ``location`` field points at the exact AST node where the pattern
    matched (e.g. the line containing the .sort() call) — not the
    enclosing function declaration. The function-start line is
    preserved as ``symbol_line`` so callers needing both have access.

    D1 (2026-05-06): when ``snippet`` is also supplied alongside
    ``match_line``, evidence gets a ``context_lines`` block — ±2 lines
    around the match site, with the matching line flagged. Cuts FP
    triage time from "open the file" to "skim the JSON".

    T6 (2026-05-06): ``matched_patterns`` lists the named sub-patterns
    that contributed to the verdict (e.g. ``["nested-loop", "sort+slice"]``
    for sort-to-select). Surfaces in evidence so users can see WHY a
    finding fired without grepping the detector source.
    """
    bw = best_way(task_id)
    sym_line = sym["line_start"]
    actual_line = match_line if match_line is not None else sym_line
    finding = {
        "task_id": task_id,
        "detected_way": detected_way,
        "suggested_way": bw["id"] if bw else "",
        "symbol_id": sym["id"],
        "symbol_name": sym["qualified_name"] or sym["name"],
        "kind": sym["kind"],
        "location": _loc(sym["file_path"], actual_line),
        "symbol_line": sym_line,
        "confidence": confidence,
        "reason": reason,
    }
    # D1 — context lines (cheap to compute, optional based on snippet availability)
    context_lines: list[dict] = []
    if snippet is not None and match_line is not None:
        context_lines = _extract_context_lines(snippet, match_line, sym_line)

    if evidence is None:
        evidence = {}
    elif not isinstance(evidence, dict):
        evidence = {"raw_evidence": evidence}
    if context_lines:
        evidence = dict(evidence)
        evidence["context_lines"] = context_lines
    # T6 — matched_patterns is the explainability hook. Always copy the
    # input list so detector mutations don't leak into shared state.
    if matched_patterns:
        evidence = dict(evidence) if not context_lines else evidence
        evidence["matched_patterns"] = list(matched_patterns)

    if evidence:
        finding["evidence"] = evidence
    if fix:
        finding["fix"] = fix
    return finding


def _extract_context_lines(
    snippet: str,
    match_line: int | None,
    sym_line_start: int | None,
    *,
    radius: int = 2,
) -> list[dict]:
    """D1 — Pull ±radius lines around the match site as evidence.

    User feedback (3.b): "Each finding should show the exact lines that
    triggered the detector (5-line context, not just the function name).
    Makes 'is this a FP?' a 10-second skim instead of a 5-minute investigation."

    Returns a list of {"line": absolute_line_no, "text": line} dicts.
    Empty list when snippet/lines unavailable. Truncates to 80 chars per
    line so big function bodies don't bloat the JSON envelope.
    """
    if not snippet or sym_line_start is None or match_line is None:
        return []
    lines = snippet.splitlines()
    if not lines:
        return []
    # Convert match_line back to a 0-based offset within the snippet.
    match_offset = match_line - sym_line_start
    if match_offset < 0 or match_offset >= len(lines):
        return []
    start = max(0, match_offset - radius)
    end = min(len(lines), match_offset + radius + 1)
    out: list[dict] = []
    for i in range(start, end):
        out.append(
            {
                "line": sym_line_start + i,
                "text": lines[i].rstrip()[:80],
                "is_match": i == match_offset,
            }
        )
    return out


def _find_match_line(snippet: str, pattern, sym_line_start: int | None) -> int | None:
    """Walk the snippet line by line to find the first line matching ``pattern``.

    Returns the absolute line number (sym_line_start + offset). When
    snippet doesn't contain the match, returns sym_line_start unchanged
    so callers can blindly substitute.

    Used by sort-to-select / IO-in-loop / regex-in-loop detectors to
    pin findings at the exact match site.
    """
    if not snippet or sym_line_start is None:
        return sym_line_start
    for offset, line in enumerate(snippet.splitlines()):
        if pattern.search(line):
            return sym_line_start + offset
    return sym_line_start


# M4 — recognise DEV-only / DEBUG-only gates so production-impact
# detectors don't fire on code that's stripped from production builds.
# Real-world examples (from the prior round of FPs):
#   - if (import.meta.env.DEV) { ... heavy diagnostics ... }
#   - if (process.env.NODE_ENV !== 'production') { ... }
#   - if (__DEV__) { ... }
#   - if (DEBUG) { ... }
#   - console.assert(...)  — short-circuits in production
_DEV_GATE_RE = re.compile(
    # No trailing \b — alternatives ending in `'production'` or `__DEV__` have
    # non-word chars after them, so the global `\b` would never fire there.
    r"\bif\s*\([^)]*?\b(?:"
    r"import\.meta\.env\.(?:DEV\b|MODE\s*[!=]==?\s*['\"]production['\"])|"
    r"process\.env\.NODE_ENV\s*[!=]==?\s*['\"]production['\"]|"
    r"__DEV__|"
    r"DEBUG\b"
    r")",
    re.IGNORECASE,
)
_CONSOLE_ASSERT_RE = re.compile(r"\bconsole\.assert\s*\(")


def _is_dev_only_block(snippet: str, match_line_offset: int | None = None) -> bool:
    """Heuristic: does the snippet (or the lines around the match) sit inside
    a DEV-only conditional?

    Conservative matcher: returns True only when an obvious DEV gate is
    visible *before* the match line in the snippet. Won't catch every
    case (e.g. a flag set in a parent function), but catches the common
    Vue 3 / React / Next.js / Vite patterns where heavy diagnostics live
    behind import.meta.env.DEV.
    """
    if not snippet:
        return False
    if _DEV_GATE_RE.search(snippet) or _CONSOLE_ASSERT_RE.search(snippet):
        return True
    return False


def _find_first_keyword_line(snippet: str, keywords: tuple[str, ...], sym_line_start: int | None) -> int | None:
    """First line containing any of the keywords (case-insensitive substring).

    Cheaper than regex; used for self-call detection in branching recursion.
    """
    if not snippet or sym_line_start is None:
        return sym_line_start
    lows = [k.lower() for k in keywords]
    for offset, line in enumerate(snippet.splitlines()):
        ll = line.lower()
        if any(k in ll for k in lows):
            return sym_line_start + offset
    return sym_line_start


def _row_value(row, key, default=None):
    """Safely read a sqlite row key with a fallback."""
    try:
        return row[key]
    except Exception:
        return default


def _json_list(value) -> list[str]:
    """Parse a JSON-encoded list of strings; return [] on malformed input."""
    if not value:
        return []
    try:
        data = json.loads(value)
    except Exception:
        return []
    if not isinstance(data, list):
        return []
    out: list[str] = []
    for item in data:
        if isinstance(item, str):
            out.append(item)
    return out


@functools.lru_cache(maxsize=4096)
def _call_leaf(name: str) -> str:
    """Return the final method/function token from a qualified call name."""
    if not name:
        return ""
    return name.rsplit(".", 1)[-1]


def _dedupe(seq: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for s in seq:
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return out


# S2 (2026-05-06) — single-process file-line cache. The 23 algorithm
# detectors each call `_read_symbol_source` for every loop-bearing
# symbol. On roam-code itself that's 4989 reads and ~1.7s of wall
# time; many are exact-duplicate (path, line_start, line_end) tuples
# from sibling detectors over the same row. Caching the file content
# once per path (not per slice) lets repeat slices hit memory.
#
# T4 (2026-05-06) — bounded with FIFO eviction. Without a cap a single
# `roam math` on a 50K-file monorepo would hold every loop-bearing file's
# full source in memory simultaneously. Eviction by insertion order
# (Python dict invariant) keeps the cap honest with O(1) overhead.
_FILE_LINES_CACHE: dict[tuple[str, float], list[str]] = {}
_FILE_LINES_CACHE_MAX = 4096  # entries; ~10MB at a typical 2.5KB/file avg


def _file_lines_cached(path: str) -> list[str]:
    # X11 (2026-05-06) — key by (path, mtime). Without the mtime guard,
    # a relative path like "svc.py" could collide across test fixtures
    # that monkeypatch.chdir into different temp dirs but write the same
    # filename. Cache survives within one process but never returns stale
    # bytes after the file has been rewritten.
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        mtime = 0.0
    cache_key = (path, mtime)
    cached = _FILE_LINES_CACHE.get(cache_key)
    if cached is not None:
        return cached
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()
    except OSError:
        lines = []
    if len(_FILE_LINES_CACHE) >= _FILE_LINES_CACHE_MAX:
        # Evict oldest insertion — Python 3.7+ dicts preserve insertion
        # order, so popitem(last=False)-equivalent is `del first key`.
        first_key = next(iter(_FILE_LINES_CACHE))
        del _FILE_LINES_CACHE[first_key]
    _FILE_LINES_CACHE[cache_key] = lines
    return lines


def _read_symbol_source(path: str, line_start: int | None, line_end: int | None) -> str:
    """Best-effort source slice for a symbol location.

    Reuses an in-memory line cache so sibling detectors don't re-read
    the same file. Cache lives for the duration of the process; safe
    because `roam math` runs detectors against a snapshotted index.
    """
    lines = _file_lines_cached(path)
    if not lines:
        return ""
    if line_start is None or line_end is None:
        return "\n".join(lines)
    ls = max(1, int(line_start))
    le = max(ls, int(line_end))
    return "\n".join(lines[ls - 1 : le])


def _iter_loop_calls(row) -> list[str]:
    """Return combined loop call names (leaf + qualified)."""
    calls = _json_list(_row_value(row, "calls_in_loops", ""))
    qcalls = _json_list(_row_value(row, "calls_in_loops_qualified", ""))
    return _dedupe(calls + qcalls)


def _call_in(calls: list[str], targets: set[str]) -> list[str]:
    """Match calls against targets by exact qualified name or leaf token."""
    hits: list[str] = []
    for c in calls:
        if c in targets or _call_leaf(c) in targets:
            hits.append(c)
    return _dedupe(hits)


_FRAMEWORK_IO_PACKS = {
    "python": [
        {
            "framework": "django-orm",
            "receiver_hints": {"objects", "queryset"},
            "leaves": {"get", "filter", "exclude", "all", "count", "exists"},
            "confidence": "high",
            "fix": ("Batch ORM fetches with `id__in` and add `select_related()/prefetch_related()`."),
        },
        {
            "framework": "sqlalchemy",
            "receiver_hints": {"session"},
            "leaves": {"execute", "query", "scalars", "get"},
            "confidence": "high",
            "fix": ("Use one `IN` query and eager loading (`selectinload`/`joinedload`) before the loop."),
        },
        {
            "framework": "python-http-client",
            "receiver_hints": {"requests", "httpx", "aiohttp", "client", "session"},
            "leaves": {"get", "post", "put", "delete", "patch", "request"},
            "confidence": "medium",
            "fix": "Use a bulk endpoint or bounded async batches (e.g., gather + semaphore).",
        },
    ],
    "ruby": [
        {
            "framework": "rails-active-record",
            "receiver_hints": {"activerecord", "relation", "model"},
            "leaves": {"find", "find_by", "where", "pluck"},
            "confidence": "high",
            "fix": "Preload associations with `.includes`/`.preload` and fetch in bulk.",
        },
    ],
    "php": [
        {
            "framework": "laravel-eloquent",
            "receiver_hints": {"db", "model", "eloquent", "query"},
            "leaves": {"find", "where", "first", "get", "value"},
            "confidence": "high",
            "fix": "Use `Model::whereIn(...)` or eager load with `with(...)`.",
        },
    ],
    "javascript": [
        {
            "framework": "node-orm",
            "receiver_hints": {"prisma", "sequelize", "knex", "db"},
            "leaves": {"findmany", "findunique", "findone", "query"},
            "confidence": "high",
            "fix": "Replace per-item ORM calls with one batched query.",
        },
        {
            "framework": "http-client",
            "receiver_hints": {"axios", "fetch", "http", "client"},
            "leaves": {"get", "post", "request"},
            "confidence": "medium",
            "fix": "Use a bulk endpoint or bounded parallel batch requests.",
        },
        {
            "framework": "graphql-client",
            "receiver_hints": {"graphql", "apollo", "urql", "client"},
            "leaves": {"query", "mutate", "request"},
            "confidence": "medium",
            "fix": "Batch GraphQL operations or use persisted/bulk queries.",
        },
    ],
    "typescript": [
        {
            "framework": "node-orm",
            "receiver_hints": {"prisma", "sequelize", "knex", "db"},
            "leaves": {"findmany", "findunique", "findone", "query"},
            "confidence": "high",
            "fix": "Replace per-item ORM calls with one batched query.",
        },
        {
            "framework": "http-client",
            "receiver_hints": {"axios", "fetch", "http", "client"},
            "leaves": {"get", "post", "request"},
            "confidence": "medium",
            "fix": "Use a bulk endpoint or bounded parallel batch requests.",
        },
        {
            "framework": "graphql-client",
            "receiver_hints": {"graphql", "apollo", "urql", "client"},
            "leaves": {"query", "mutate", "request"},
            "confidence": "medium",
            "fix": "Batch GraphQL operations or use persisted/bulk queries.",
        },
    ],
    "java": [
        {
            "framework": "jpa-hibernate",
            "receiver_hints": {"repository", "entitymanager", "jdbc", "template"},
            "leaves": {"findbyid", "findall", "query", "execute", "select"},
            "confidence": "high",
            "fix": ("Preload rows with one repository/JPA query (`IN (...)` + fetch join)."),
        },
    ],
}


def _framework_packs(language: str | None) -> list[dict]:
    if not language:
        return []
    return _FRAMEWORK_IO_PACKS.get(language.lower(), [])


_IO_GUARD_HINTS = {
    "python": {
        "select_related(",
        "prefetch_related(",
        "joinedload(",
        "selectinload(",
        "in_(",
        "__in",
        "executemany(",
    },
    "ruby": {
        ".includes(",
        ".preload(",
        ".eager_load(",
    },
    "php": {
        "->with(",
        "wherein(",
        "loadmissing(",
    },
    "javascript": {
        "findmany(",
        "include:",
        " in: ",
    },
    "typescript": {
        "findmany(",
        "include:",
        " in: ",
    },
    "java": {
        "join fetch",
        "findallbyid(",
        " in (",
    },
}


def _guard_hints_from_source(language: str | None, snippet: str) -> list[str]:
    if not language or not snippet:
        return []
    tokens = _IO_GUARD_HINTS.get((language or "").lower(), set())
    if not tokens:
        return []
    lower = snippet.lower()
    hits: list[str] = []
    for tok in tokens:
        if tok in lower:
            hits.append(tok)
    return _dedupe(hits)


# ---------------------------------------------------------------------------
# Individual detectors
# ---------------------------------------------------------------------------


def detect_manual_sort(conn: sqlite3.Connection) -> list[dict]:
    """Symbols named *sort* with nested loops, comparisons, and subscript
    access (swap pattern).  No call to built-in sort."""
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.has_nested_loops, ms.calls_in_loops, "
        "ms.loop_with_compare, ms.subscript_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%sort%' OR s.name LIKE '%Sort%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.has_nested_loops = 1 "
        "AND ms.loop_with_compare = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"sort", "sorted", "Arrays.sort", "Collections.sort", "qsort", "std::sort"}):
            continue
        # Subscript access in loops strengthens the signal (swap pattern)
        conf = "high" if r["subscript_in_loops"] else "medium"
        results.append(
            _finding(
                "sorting",
                "manual-sort",
                r,
                "Nested loops with comparisons in sort-named function",
                conf,
            )
        )
    return results


def detect_linear_search(conn: sqlite3.Connection) -> list[dict]:
    """Functions explicitly named *sorted*/*search_sorted* that loop with
    comparisons but don't call bisect/binarySearch.

    Downgraded to low confidence because we cannot verify from AST alone
    that the data being searched is actually sorted.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.loop_with_compare, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%search_sorted%' OR s.name LIKE '%searchSorted%' "
        "  OR s.name LIKE '%find_sorted%' OR s.name LIKE '%findSorted%' "
        "  OR s.name LIKE '%find_in_sorted%' OR s.name LIKE '%in_sorted%' "
        "  OR s.name LIKE '%linear_search%' OR s.name LIKE '%linearSearch%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1 "
        "AND ms.loop_with_compare = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(
            calls,
            {
                "bisect",
                "bisect_left",
                "bisect_right",
                "binarySearch",
                "binary_search",
                "lower_bound",
                "upper_bound",
            },
        ):
            continue
        results.append(
            _finding(
                "search-sorted",
                "linear-scan",
                r,
                "Linear scan in function that implies sorted data",
                "low",
            )
        )
    return results


def detect_list_membership(conn: sqlite3.Connection) -> list[dict]:
    """Nested loops with equality comparisons β€” structural pattern for
    O(n^2) membership testing regardless of function name."""
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_with_compare, ms.subscript_in_loops, "
        "ms.has_nested_loops, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.has_nested_loops = 1 "
        "AND ms.loop_with_compare = 1 "
        "AND ms.subscript_in_loops = 1 "
        "AND (s.name LIKE '%contain%' OR s.name LIKE '%member%' "
        "  OR s.name LIKE '%exist%' OR s.name LIKE '%has_%' "
        "  OR s.name LIKE '%in_%' OR s.name LIKE '%check%' "
        "  OR s.name LIKE '%includes%' OR s.name LIKE '%Includes%')"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        results.append(
            _finding(
                "membership",
                "list-scan",
                r,
                "Nested loops with comparisons for membership check",
                "medium",
            )
        )
    return results


def detect_string_concat_loop(conn: sqlite3.Connection) -> list[dict]:
    """Loops with accumulation patterns and string-related call hints.

    Relies primarily on the structural pattern (loop + accumulator) combined
    with calls to string methods (append/concat) or string-building name hints.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.calls_in_loops, ms.loop_with_accumulator "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1 "
        "AND ms.loop_with_accumulator = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        # Structural signal: calls to string concat/append methods
        has_concat_call = bool(_call_in(calls, {"concat", "strcat", "append", "push"}))
        # Name signal: function name suggests string building
        name_lower = (r["name"] or "").lower()
        has_name_hint = any(
            kw in name_lower
            for kw in (
                "concat",
                "build_str",
                "build_string",
                "format",
                "render",
                "serialize",
                "to_string",
                "tostring",
                "stringify",
                "to_csv",
                "to_html",
                "to_xml",
                "generate_report",
                "join",
            )
        )
        if has_concat_call or has_name_hint:
            results.append(
                _finding(
                    "string-concat",
                    "loop-concat",
                    r,
                    "Loop accumulation in string-building function",
                    "medium",
                )
            )
    return results


def detect_manual_dedup(conn: sqlite3.Connection) -> list[dict]:
    """Nested loops in dedup/unique-named functions without set usage."""
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.has_nested_loops, ms.loop_with_compare, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%dedup%' OR s.name LIKE '%unique%' "
        "  OR s.name LIKE '%Dedup%' OR s.name LIKE '%Unique%' "
        "  OR s.name LIKE '%distinct%' OR s.name LIKE '%Distinct%' "
        "  OR s.name LIKE '%remove_dup%' OR s.name LIKE '%removeDup%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.has_nested_loops = 1 "
        "AND ms.loop_with_compare = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        # Negative check: skip if they already use set/hash
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"set", "Set", "HashSet"}):
            continue
        results.append(
            _finding(
                "unique",
                "nested-dedup",
                r,
                "Nested loops with comparisons in dedup function",
                "high",
            )
        )
    return results


def detect_manual_maxmin(conn: sqlite3.Connection) -> list[dict]:
    """Loops with comparisons in max/min-named functions.

    Same Big-O (both O(n)) β€” this is an idiom improvement, flagged at low
    confidence.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.loop_with_compare, "
        "ms.loop_with_accumulator, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%find_max%' OR s.name LIKE '%find_min%' "
        "  OR s.name LIKE '%findMax%' OR s.name LIKE '%findMin%' "
        "  OR s.name LIKE '%get_max%' OR s.name LIKE '%get_min%' "
        "  OR s.name LIKE '%getMax%' OR s.name LIKE '%getMin%' "
        "  OR s.name LIKE '%find_largest%' OR s.name LIKE '%find_smallest%' "
        "  OR s.name LIKE '%findLargest%' OR s.name LIKE '%findSmallest%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1 "
        "AND ms.loop_with_compare = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"max", "min", "Math.max", "Math.min", "Collections.max", "Collections.min"}):
            continue
        results.append(
            _finding(
                "max-min",
                "manual-loop",
                r,
                "Manual loop with comparisons in max/min function (idiomatic improvement)",
                "low",
            )
        )
    return results


def detect_manual_accumulation(conn: sqlite3.Connection) -> list[dict]:
    """Loops with accumulator in sum/total-named functions.

    Same Big-O (both O(n)) β€” idiom improvement, flagged at low confidence.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.loop_with_accumulator, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%_sum%' OR s.name LIKE '%_total%' "
        "  OR s.name LIKE '%Sum%' OR s.name LIKE '%Total%' "
        "  OR s.name LIKE '%accumulate%' OR s.name LIKE '%Accumulate%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1 "
        "AND ms.loop_with_accumulator = 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"sum", "reduce", "aggregate", "prod"}):
            continue
        results.append(
            _finding(
                "accumulation",
                "manual-sum",
                r,
                "Loop with accumulator in sum/total function (idiomatic improvement)",
                "low",
            )
        )
    return results


def detect_manual_power(conn: sqlite3.Connection) -> list[dict]:
    """Loop-based exponentiation in power/exponent-named functions."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.loop_with_multiplication, "
            "ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%pow%' OR s.name LIKE '%Pow%' "
            "  OR s.name LIKE '%power%' OR s.name LIKE '%Power%' "
            "  OR s.name LIKE '%exp%' OR s.name LIKE '%Exponent%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1 "
            "AND ms.loop_with_multiplication = 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, 0 as loop_with_multiplication, "
            "ms.calls_in_loops, '' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%pow%' OR s.name LIKE '%Pow%' "
            "  OR s.name LIKE '%power%' OR s.name LIKE '%Power%' "
            "  OR s.name LIKE '%exp%' OR s.name LIKE '%Exponent%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1 "
            "AND ms.loop_with_accumulator = 1"
        ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"pow", "Math.pow", "std::pow", "math.pow", "BigInteger.modPow"}):
            continue
        conf = "high" if _row_value(r, "loop_with_multiplication", 0) else "medium"
        results.append(
            _finding(
                "manual-power",
                "loop-multiply",
                r,
                "Loop multiplication used for exponentiation",
                conf,
            )
        )
    return results


def detect_manual_gcd(conn: sqlite3.Connection) -> list[dict]:
    """Manual GCD loops where built-in/standard helpers are available."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.loop_with_modulo, "
            "ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%gcd%' OR s.name LIKE '%GCD%' "
            "  OR s.name LIKE '%hcf%' OR s.name LIKE '%gcf%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, 0 as loop_with_modulo, "
            "ms.calls_in_loops, '' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%gcd%' OR s.name LIKE '%GCD%' "
            "  OR s.name LIKE '%hcf%' OR s.name LIKE '%gcf%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"gcd", "math.gcd", "std::gcd", "BigInteger.gcd"}):
            continue
        conf = "medium"
        if _row_value(r, "loop_with_modulo", 0):
            conf = "high"
        results.append(
            _finding(
                "manual-gcd",
                "manual-gcd",
                r,
                "Manual GCD loop can be replaced with standard gcd helper",
                conf,
            )
        )
    return results


def detect_string_reverse(conn: sqlite3.Connection) -> list[dict]:
    """Manual reversal loops in reverse-named functions."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.loop_with_accumulator, "
            "ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%reverse%' OR s.name LIKE '%Reverse%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.loop_with_accumulator, "
            "ms.calls_in_loops, '' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%reverse%' OR s.name LIKE '%Reverse%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"reverse", "reversed", "std::reverse", "StringBuilder.reverse", "strrev"}):
            continue
        results.append(
            _finding(
                "string-reverse",
                "manual-reverse",
                r,
                "Manual character-loop reversal in reverse-named function",
                "low",
            )
        )
    return results


def detect_matrix_mult(conn: sqlite3.Connection) -> list[dict]:
    """Naive triple-loop matrix multiplication patterns."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.subscript_in_loops, "
            "ms.loop_with_multiplication, ms.loop_with_accumulator, "
            "ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%matrix%' OR s.name LIKE '%matmul%' "
            "  OR s.name LIKE '%multiply_matrix%' OR s.name LIKE '%dot%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 3 "
            "AND ms.subscript_in_loops = 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_depth, ms.subscript_in_loops, "
            "0 as loop_with_multiplication, ms.loop_with_accumulator, "
            "ms.calls_in_loops, '' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE (s.name LIKE '%matrix%' OR s.name LIKE '%matmul%' "
            "  OR s.name LIKE '%multiply_matrix%' OR s.name LIKE '%dot%') "
            "AND s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 3 "
            "AND ms.subscript_in_loops = 1"
        ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"dot", "matmul", "gemm", "dgemm", "numpy.dot", "np.matmul"}):
            continue
        conf = (
            "high"
            if (_row_value(r, "loop_with_multiplication", 0) and _row_value(r, "loop_with_accumulator", 0))
            else "medium"
        )
        results.append(
            _finding(
                "matrix-mult",
                "naive-triple",
                r,
                "Naive matrix multiplication via nested loops",
                conf,
            )
        )
    return results


def detect_naive_fibonacci(conn: sqlite3.Connection) -> list[dict]:
    """Recursive functions named *fib* without memoization.

    O(2^n) -> O(n) β€” one of the strongest algorithmic improvements.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.has_self_call "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%fib%' OR s.name LIKE '%Fib%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.has_self_call >= 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        # Check if there's a memoization decorator (edge to lru_cache/cache)
        memo_edge = conn.execute(
            "SELECT 1 FROM edges e "
            "JOIN symbols t ON e.target_id = t.id "
            "WHERE e.source_id = ? "
            "AND t.name IN ('lru_cache', 'cache', 'memoize', 'memo', "
            "               'functools.lru_cache', 'functools.cache') "
            "LIMIT 1",
            (r["id"],),
        ).fetchone()
        if memo_edge:
            continue
        results.append(
            _finding(
                "fibonacci",
                "naive-recursive",
                r,
                "Recursive fibonacci without memoization (exponential blowup)",
                "high",
            )
        )
    return results


def detect_nested_lookup(conn: sqlite3.Connection) -> list[dict]:
    """Nested loops with subscript access and comparisons β€” O(n*m) lookup.

    Suppresses known false positives: grid/matrix traversal (name hints),
    and requires both nested loops AND comparisons (not just nested loops
    with subscript access, which could be matrix operations).
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.has_nested_loops, ms.subscript_in_loops, "
        "ms.loop_with_compare "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "JOIN symbol_metrics sm ON sm.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.has_nested_loops = 1 "
        "AND ms.subscript_in_loops = 1 "
        "AND ms.loop_with_compare = 1 "
        "AND sm.cognitive_complexity >= 8"
    ).fetchall()

    # Names that suggest grid/matrix traversal (suppress these)
    _GRID_NAMES = {
        "matrix",
        "grid",
        "board",
        "pixel",
        "cell",
        "permut",
        "combin",
        "cartesian",
        "product",
        "transpose",
        "rotate",
        "convolv",
    }

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        # Suppress grid/matrix traversal patterns
        name_lower = (r["name"] or "").lower()
        if any(kw in name_lower for kw in _GRID_NAMES):
            continue
        results.append(
            _finding(
                "nested-lookup",
                "nested-iteration",
                r,
                "Nested loops with subscript access and comparisons (potential O(n*m))",
                "medium",
            )
        )
    return results


def detect_manual_groupby(conn: sqlite3.Connection) -> list[dict]:
    """Loops in group/categorize-named functions without defaultdict/groupby.

    Same Big-O (both O(n)) β€” idiom improvement.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.loop_with_accumulator, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE (s.name LIKE '%group%' OR s.name LIKE '%Group%' "
        "  OR s.name LIKE '%bucket%' OR s.name LIKE '%Bucket%' "
        "  OR s.name LIKE '%partition%' OR s.name LIKE '%Partition%' "
        "  OR s.name LIKE '%categorize%' OR s.name LIKE '%Categorize%' "
        "  OR s.name LIKE '%classify%' OR s.name LIKE '%Classify%' "
        "  OR s.name LIKE '%bin_by%' OR s.name LIKE '%key_by%' "
        "  OR s.name LIKE '%index_by%') "
        "AND s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if _call_in(calls, {"groupby", "group_by", "defaultdict", "setdefault", "groupingBy", "Collectors"}):
            continue
        results.append(
            _finding(
                "groupby",
                "manual-check",
                r,
                "Manual loop in group-by function (idiomatic improvement)",
                "low",
            )
        )
    return results


def detect_busy_wait(conn: sqlite3.Connection) -> list[dict]:
    """Loops that call sleep β€” polling / busy-wait pattern.

    Suppresses intentional polling: functions named *poll*, *retry*,
    *health_check*, *monitor*, *wait_for* β€” these are legitimate patterns.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1"
    ).fetchall()

    # Intentional polling patterns β€” suppress these
    _POLL_NAMES = {
        "poll",
        "retry",
        "health_check",
        "healthcheck",
        "monitor",
        "wait_for",
        "wait_until",
        "watchdog",
        "ping",
        "heartbeat",
        "keepalive",
        "backoff",
        # T2 (2026-05-06): also suppress *_loop and watch_* — found
        # `_run_watch_loop` flagged on roam itself; the loop is a CLI
        # poll loop with seconds-scale sleep, not a tight spin.
        "_loop",
        "watch_",
        "watcher",
    }

    # T2 — sleep arg less than this many seconds counts as a "spin" in spirit;
    # >= 1 second sleeps are operator-paced poll loops, not busy waits.
    _SPIN_THRESHOLD_SECONDS = 1.0
    _RE_SLEEP_ARG = re.compile(
        r"\b(?:time\.sleep|asyncio\.sleep|Thread\.sleep|usleep|Sleep)\s*\(\s*"
        r"(?:[A-Z][A-Z_]*|(?P<num>\d+(?:\.\d+)?))",
    )

    def _max_sleep_arg_seconds(snippet: str) -> float | None:
        """Return the LARGEST literal sleep argument in seconds, or None.

        Snippet sleeps with named-constant args (POLL_INTERVAL etc.) yield
        None — we can't tell. usleep/Sleep are millisecond/microsecond on
        their respective platforms, but for our threshold check we treat
        the literal as seconds since a literal `usleep(1)` is unambiguous.
        """
        max_seen: float | None = None
        for m in _RE_SLEEP_ARG.finditer(snippet or ""):
            num = m.group("num")
            if num is None:
                # Named constant — bail. Can't classify safely.
                return None
            val = float(num)
            if max_seen is None or val > max_seen:
                max_seen = val
        return max_seen

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        if not _call_in(calls, {"sleep", "time.sleep", "Thread.sleep", "usleep", "nanosleep", "Sleep"}):
            continue
        # Suppress intentional polling by name.
        name_lower = (r["name"] or "").lower()
        if any(kw in name_lower for kw in _POLL_NAMES):
            continue
        # T2 — peek at the snippet: if every literal sleep argument is
        # >= 1 second, this is operator-paced polling, not a busy wait.
        snippet = _read_symbol_source(
            r["file_path"],
            _row_value(r, "line_start", None),
            _row_value(r, "line_end", None),
        )
        max_sleep = _max_sleep_arg_seconds(snippet)
        if max_sleep is not None and max_sleep >= _SPIN_THRESHOLD_SECONDS:
            continue
        results.append(
            _finding(
                "busy-wait",
                "sleep-loop",
                r,
                "sleep() called inside a loop (busy-wait pattern)",
                "high",
            )
        )
    return results


# ---------------------------------------------------------------------------
# New detectors: patterns identified by research
# ---------------------------------------------------------------------------


def detect_regex_in_loop(conn: sqlite3.Connection) -> list[dict]:
    """Regex compilation inside a loop β€” recompiles on every iteration.

    O(n*p) wasted compilation when O(p + n*m) is achievable by compiling
    once outside the loop.  Applies to all languages with regex engines.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, ms.loop_depth, ms.calls_in_loops "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1"
    ).fetchall()

    # Note: call target names are extracted as the last identifier in
    # member expressions (e.g. re.compile -> "compile", re.match -> "match")
    _REGEX_COMPILE_CALLS = {"compile", "Compile", "MustCompile"}
    _REGEX_CONVENIENCE_CALLS = {
        "match",
        "search",
        "findall",
        "sub",
        "split",
        "fullmatch",
        "finditer",
        "matches",
        "Replace",
        "ReplaceAll",
        "Find",
        "FindAll",
        "MatchString",
    }

    # Module-level regex prefixes β€” calls like `re.match()` recompile each time,
    # but `compiled_pattern.match()` does not.  Only flag the former.
    _REGEX_MODULE_PREFIXES = {"re.", "regexp.", "regex.", "Pattern."}

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        # Direct compile in loop is always bad
        compile_calls = _call_in(calls, _REGEX_COMPILE_CALLS)
        # Convenience regex calls β€” only flag when called via the regex module
        # (e.g. `re.findall`), NOT when called on a pre-compiled pattern object
        # (e.g. `_MY_RE.findall`).  Check qualified names for module prefix.
        qcalls = _json_list(_row_value(r, "calls_in_loops_qualified", ""))
        module_convenience = [
            c
            for c in qcalls
            if any(c.startswith(prefix) for prefix in _REGEX_MODULE_PREFIXES)
            and _call_leaf(c) in _REGEX_CONVENIENCE_CALLS
        ]
        if compile_calls:
            results.append(
                _finding(
                    "regex-in-loop",
                    "compile-per-iter",
                    r,
                    f"Regex compile ({', '.join(compile_calls[:2])}) inside loop",
                    "high",
                )
            )
        elif module_convenience:
            results.append(
                _finding(
                    "regex-in-loop",
                    "compile-per-iter",
                    r,
                    f"Regex call ({', '.join(module_convenience[:2])}) inside loop (recompiles per iteration)",
                    "high",
                )
            )
    return results


_IO_HIGH_EXACT = {
    "requests.get",
    "requests.post",
    "requests.put",
    "requests.delete",
    "requests.patch",
    "urllib.request.urlopen",
    "session.execute",
    "session.query",
    "cursor.execute",
    "http.Get",
    "http.Post",
    # U3 (2026-05-06): Node.js sync FS calls — these block the event loop
    # AND are dramatically slower than the async equivalents when iterated
    # in a loop. Each one is a syscall round-trip per iteration.
    "fs.readFileSync",
    "fs.writeFileSync",
    "fs.appendFileSync",
    "fs.existsSync",
    "fs.statSync",
    "fs.lstatSync",
    "fs.readdirSync",
    "fs.unlinkSync",
    "fs.mkdirSync",
    "fs.rmSync",
    "fs.copyFileSync",
}
_IO_HIGH_EXACT_LOWER = {c.lower() for c in _IO_HIGH_EXACT}
_IO_HIGH_LEAF = {
    "execute",
    "executemany",
    "query",
    "urlopen",
    # U3 — leaf-only matching catches `readFileSync(...)` even when the
    # `fs.` receiver is aliased (`const { readFileSync } = require('fs')`).
    "readfilesync",
    "writefilesync",
    "existssync",
    "statsync",
    "readdirsync",
}
_IO_AMBIGUOUS_BARE = {"query", "find", "get"}
_IO_MEDIUM_LEAF = {"fetchone", "fetchall", "fetchmany", "fetch", "find", "get", "open"}
_IO_RECEIVER_HINTS = {
    "session",
    "cursor",
    "db",
    "conn",
    "connection",
    "repo",
    "repository",
    "queryset",
    "client",
    "api",
    "http",
    "requests",
    "urllib",
    # U3 (2026-05-06): Node.js fs receivers + popular wrappers.
    "fs",
    "fspromises",
    "fsasync",
    "fsextra",
    "fileutil",
}
# M3 expansion: when a call is IN this set OR matches one of the IN_MEMORY_LEAVES
# attached to a recognised receiver, treat as an in-memory cache read NOT I/O.
# Real-world FP that drove the expansion: roam math flagged
# `queryClient.getQueryData` inside a TanStack Query factory as N+1
# round-trips when those are sync cache reads.
_IN_MEMORY_EXACT = {
    "queryclient.setquerydata",
    "queryclient.getquerydata",
    "queryclient.getqueriesdata",
    "queryclient.setqueriesdata",
    "queryclient.invalidatequeries",
    "queryclient.removequeries",
    "queryclient.cancelqueries",
    "queryclient.refetchqueries",
    "qc.setquerydata",
    "qc.getquerydata",
    "qc.getqueriesdata",
    "qc.setqueriesdata",
    "qc.invalidatequeries",
    "redux.dispatch",
    "store.dispatch",
    # SWR + RTK Query + Apollo cache equivalents
    "mutate",  # SWR's mutate() (cache-only)
    "cache.read",
    "cache.write",
    "cache.evict",
    "cache.modify",  # Apollo
    "client.readquery",  # Apollo
    "client.writequery",  # Apollo
    "client.cache.evict",  # Apollo
}
_IN_MEMORY_LEAVES = {
    "setquerydata",
    "getquerydata",
    "setqueriesdata",
    "getqueriesdata",
    "invalidatequeries",
    "removequeries",
    "cancelqueries",
    "refetchqueries",
    "dispatch",
    "setstate",
    # M3 — generic Map/Set/WeakMap operations are NOT I/O even in loops.
    # Without these, `mapInst.get(k)` inside a loop falsely fires as N+1.
    "has",
    "set",
    "delete",
    "clear",
    "peek",
    # SWR + Apollo
    "readquery",
    "writequery",
    "writefragment",
    "readfragment",
    "evict",
    "modify",
}
_IN_MEMORY_RECEIVER_HINTS = {
    "queryclient",
    "qc",
    "store",
    "redux",
    "cache",
    "state",
    "router",
    # M3 expansion: more cache-library + native-collection receivers
    "map",
    "set",
    "weakmap",
    "weakset",
    "dict",
    "lookup",
    "registry",
    "client",  # Apollo client.cache.evict
    "session",
    "pinia",  # Vue 3 store
}
_IO_WRAPPER_NAMES = {
    "batch",
    "bulk",
    "migrate",
    "seed",
    "import",
    "export",
    "sync_all",
    "backfill",
}

# DF2 (2026-05-06) — body-level signals that the loop iterates CHUNKS, not
# individual items. When any of these patterns appear in the function body,
# the inner I/O calls operate on a batch (WHERE IN (...) form), not per-item,
# so it's not N+1. Caught a self-FP on roam's own `_symbol_context` which
# uses `for chunk in _chunked(symbol_ids):` then `WHERE symbol_id IN (...)`.
_BATCH_ITERATION_PATTERNS = re.compile(
    r"\bfor\s+\w+\s+in\s+(?:_?chunked|_?batched|chunks_of|batched_in|batch_iter|grouper)\b"
    r"|\bfor\s+\w+\s+in\s+range\s*\(\s*\d*\s*,\s*[^,]+,\s*(?:chunk|batch|page)_?size\b"
    r"|\bIN\s*\(\s*\{[^}]*\}\s*\)"  # f"WHERE id IN ({ph})" style
)


def _has_batch_iteration(snippet: str) -> bool:
    """Return True if the loop iterates chunks/batches rather than items."""
    if not snippet:
        return False
    return bool(_BATCH_ITERATION_PATTERNS.search(snippet))


@functools.lru_cache(maxsize=4096)
def _io_receiver_hint(call: str) -> str:
    if "." not in call:
        return ""
    return call.rsplit(".", 1)[0].lower()


def _io_receiver_is_ioish(call: str) -> bool:
    recv = _io_receiver_hint(call)
    if not recv:
        return False
    return any(h in recv for h in _IO_RECEIVER_HINTS)


# ---- D3: Framework profiles -----------------------------------------------
# Opt-in extras layered on top of the built-in cache allowlists when the user
# passes ``--framework FRAMEWORK`` to a detector command. Keeps defaults safe
# for arbitrary repos while letting users self-classify framework-specific
# helpers without forking the codebase.
_FRAMEWORK_PROFILES: dict[str, dict[str, set[str]]] = {
    # X6 (2026-05-06) — Django ORM-aware allowlist. `prefetch_related`,
    # `select_related`, `annotate`, `values_list`, `iterator` all belong
    # to QuerySet but are CHEAP cache/dispatch operations, not new I/O
    # per call. Without this, naive scans flag idiomatic Django code
    # (e.g. `for q in QuerySet.iterator(): ...`) as N+1.
    "django": {
        "in_memory_exact": {
            "queryset.iterator",
            "queryset.values_list",
            "queryset.values",
            "queryset.annotate",
            "queryset.prefetch_related",
            "queryset.select_related",
            "manager.iterator",
            "cache.get",
            "cache.set",
            "cache.delete",
        },
        "in_memory_leaves": {
            "iterator",
            "values_list",
            "annotate",
            "prefetch_related",
            "select_related",
            "only",
            "defer",
            "exists",
            "count",  # count is ONE query, not per-item
        },
        "in_memory_receivers": {
            "queryset",
            "qs",
            "manager",
            "cache",
            "objects",
        },
    },
    # X7 (2026-05-06) — Rails / ActiveRecord allowlist. Same shape:
    # `includes`, `joins`, `pluck`, `find_each`, `scope` are framework
    # primitives that don't trigger per-call I/O.
    "rails": {
        "in_memory_exact": {
            "rails.cache.read",
            "rails.cache.write",
            "rails.cache.delete",
        },
        "in_memory_leaves": {
            "includes",
            "joins",
            "preload",
            "eager_load",
            "pluck",
            "find_each",
            "in_batches",
            "scope",
            "where_values_hash",
        },
        "in_memory_receivers": {
            "scope",
            "relation",
            "association",
            "rails.cache",
            "active_support",
        },
    },
    # X8 (2026-05-06) — NestJS DI cache helpers (CacheModule, ConfigService
    # decorators) and TypeORM repository helpers that are not per-item I/O.
    "nestjs": {
        "in_memory_exact": {
            "configservice.get",
            "cachemanager.get",
            "cachemanager.set",
            "cachemanager.del",
        },
        "in_memory_leaves": {
            "createquerybuilder",
            "leftjoinandselect",
            "innerjoinandselect",
            "addselect",
            "addorderby",
            "addgroupby",
        },
        "in_memory_receivers": {
            "configservice",
            "cachemanager",
            "querybuilder",
            "qb",
            "repository",
        },
    },
    "vue3-tanstack": {
        # Vue 3 + TanStack Vue Query patterns observed in union-web FP batch.
        "in_memory_exact": {
            "queryclient.fetchquery",
            "queryclient.ensurequerydata",
            "queryclient.prefetchquery",
        },
        "in_memory_leaves": {
            "fetchquery",
            "ensurequerydata",
            "prefetchquery",
            "$reset",
            "$patch",
        },
        "in_memory_receivers": {
            "$query",
            "usequery",
            "usemutation",
            "useinfinitequery",
            "vuequery",
        },
    },
    "laravel-multitenant": {
        # stancl/tenancy + Laravel multi-DB patterns.
        "in_memory_exact": {
            "tenant.context",
            "tenancy.initialize",
        },
        "in_memory_leaves": {
            "throughtenant",
            "scopetenant",
            "viausertenant",
            "fortenant",
        },
        "in_memory_receivers": {
            "tenantmanager",
            "tenantservice",
            "tenantscoped",
            "tenancy",
        },
    },
}

_ACTIVE_FRAMEWORK_PROFILE: dict[str, set[str]] | None = None

# X14 (2026-05-06) — module-level flag for --include-tests. When True,
# `_is_test_path` returns False so detectors stop filtering out tests.
# Reset alongside the framework profile in run_detectors finally-block.
_INCLUDE_TESTS_OVERRIDE: bool = False


def list_framework_profiles() -> list[str]:
    """Return the names of bundled framework profiles."""
    return sorted(_FRAMEWORK_PROFILES.keys())


def autodetect_framework_profile() -> str | None:
    """T7 (2026-05-06) — sniff package.json / composer.json for known stacks.

    Inspects ``package.json`` and ``composer.json`` from the project root
    (current working directory) for the dependency signals that map onto
    a bundled profile:

    * ``vue3-tanstack`` — package.json depends on ``vue@3.x`` AND on
      ``@tanstack/vue-query`` (or ``@tanstack/query-core``).
    * ``laravel-multitenant`` — composer.json depends on ``laravel/framework``
      AND on ``stancl/tenancy`` or ``spatie/laravel-multitenancy``.

    Returns the profile name or None when no signal matches. Designed so
    a missing/unreadable manifest is silently None — never raises.
    """
    import json as _json
    import os as _os

    cwd = _os.getcwd()

    def _read_json(path):
        try:
            with open(path, encoding="utf-8") as f:
                return _json.load(f)
        except (OSError, _json.JSONDecodeError):
            return None

    def _read_text(path):
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                return f.read()
        except OSError:
            return ""

    pkg = _read_json(_os.path.join(cwd, "package.json"))
    if pkg:
        deps = {**(pkg.get("dependencies") or {}), **(pkg.get("devDependencies") or {})}
        # X9 (2026-05-06) — NestJS check before generic vue3.
        if "@nestjs/core" in deps or "@nestjs/common" in deps:
            return "nestjs"
        vue_ver = str(deps.get("vue", ""))
        tanstack = "@tanstack/vue-query" in deps or "@tanstack/query-core" in deps
        if tanstack and (vue_ver.startswith("^3") or vue_ver.startswith("3") or vue_ver.startswith("~3")):
            return "vue3-tanstack"
        # Z6 (2026-05-06) — Express/Koa/Fastify don't have framework
        # profiles yet (they're light frameworks; the I/O patterns are
        # generic Node fs / http). Return None for now but flag in meta
        # so future versions can add a profile when one becomes useful.

    composer = _read_json(_os.path.join(cwd, "composer.json"))
    if composer:
        require = composer.get("require") or {}
        if "laravel/framework" in require and ("stancl/tenancy" in require or "spatie/laravel-multitenancy" in require):
            return "laravel-multitenant"

    # X9 — Python/Django: check requirements.txt OR pyproject.toml.
    req_text = _read_text(_os.path.join(cwd, "requirements.txt")).lower()
    pyp_text = _read_text(_os.path.join(cwd, "pyproject.toml")).lower()
    if "django" in req_text or '"django' in pyp_text or "'django" in pyp_text:
        return "django"

    # X9 — Ruby/Rails: Gemfile lists `gem 'rails'`.
    gemfile = _read_text(_os.path.join(cwd, "Gemfile"))
    if "gem 'rails'" in gemfile or 'gem "rails"' in gemfile:
        return "rails"

    return None


def set_active_framework_profile(name: str | None) -> dict[str, set[str]] | None:
    """Activate a framework profile for the current process.

    Returns the resolved profile dict, or ``None`` if the name is unknown.
    Callers wrap in try/finally to restore the previous profile.
    """
    global _ACTIVE_FRAMEWORK_PROFILE
    if not name:
        _ACTIVE_FRAMEWORK_PROFILE = None
        return None
    profile = _FRAMEWORK_PROFILES.get(name.lower())
    _ACTIVE_FRAMEWORK_PROFILE = profile
    return profile


def _framework_extras(key: str) -> set[str]:
    if not _ACTIVE_FRAMEWORK_PROFILE:
        return set()
    return _ACTIVE_FRAMEWORK_PROFILE.get(key) or set()


# S3 (2026-05-06) — `_io_is_known_in_memory_call` is hot: 12,226 calls
# during a single `roam math` on roam-code. The merged-set construction
# (`_IN_MEMORY_EXACT | _framework_extras(...)`) was running per-call.
# Cache results per (call, framework_id) so repeat call names short-
# circuit. The framework_id changes when the active profile changes,
# so cache keys naturally invalidate via the profile-state tuple.
_IN_MEMORY_CALL_CACHE: dict[tuple[str, int], bool] = {}


def _active_framework_id() -> int:
    return id(_ACTIVE_FRAMEWORK_PROFILE)


def _io_is_known_in_memory_call(call: str) -> bool:
    cache_key = (call, _active_framework_id())
    cached = _IN_MEMORY_CALL_CACHE.get(cache_key)
    if cached is not None:
        return cached
    lower_c = call.lower()
    leaf = _call_leaf(lower_c)
    recv = _io_receiver_hint(lower_c)
    exact = _IN_MEMORY_EXACT | _framework_extras("in_memory_exact")
    leaves = _IN_MEMORY_LEAVES | _framework_extras("in_memory_leaves")
    receivers = _IN_MEMORY_RECEIVER_HINTS | _framework_extras("in_memory_receivers")
    if lower_c in exact:
        result = True
    elif leaf in leaves and any(h in recv for h in receivers):
        result = True
    else:
        result = False
    _IN_MEMORY_CALL_CACHE[cache_key] = result
    return result


def _is_call_awaited_in_snippet(call: str, snippet: str) -> bool:
    """D2 — cheap proxy for "Promise<T> vs T" return type.

    User suggested checking the call's actual return type to distinguish
    cache reads (sync, T) from I/O (async, Promise<T>). Without full type
    resolution, the next-best signal is: is the call preceded by ``await``
    in the function body? If yes, the call returns a Promise — meaningful
    I/O. If no, it's likely a sync cache read even when the leaf name
    overlaps a cache library identifier.

    Conservative match: looks for ``await <maybe-receiver>.leaf(`` on
    any snippet line. Misses cases where the awaited call is named via
    a variable; catches the common ``await fetchUser(id)`` pattern.
    """
    if not snippet or not call:
        return False
    leaf = _call_leaf(call) or call
    if not leaf:
        return False
    pattern = re.compile(rf"\bawait\s+(?:[\w$.]+\.)?{re.escape(leaf)}\s*\(")
    return bool(pattern.search(snippet))


# S4 (2026-05-06) — `_io_match_framework_pack` is invoked per-call inside
# `detect_io_in_loop` (12,226× on roam-code). The pack-set lookup is
# deterministic in (call, language) so cache by that tuple. The cache
# is reset alongside the file/in-memory caches at run_detectors entry.
_FRAMEWORK_PACK_CACHE: dict[tuple[str, str], dict | None] = {}


def _io_match_framework_pack(call: str, language: str | None) -> dict | None:
    cache_key = (call, language or "")
    if cache_key in _FRAMEWORK_PACK_CACHE:
        return _FRAMEWORK_PACK_CACHE[cache_key]
    leaf = _call_leaf(call).lower()
    recv = _io_receiver_hint(call)
    lower_c = call.lower()
    result: dict | None = None
    for pack in _framework_packs(language):
        leaves = {str(v).lower() for v in pack.get("leaves", set())}
        recv_hints = {str(v).lower() for v in pack.get("receiver_hints", set())}
        if lower_c in {c.lower() for c in pack.get("exact", set())}:
            result = pack
            break
        if leaf not in leaves:
            continue
        if not recv_hints:
            result = pack
            break
        if any(h in recv for h in recv_hints):
            result = pack
            break
    _FRAMEWORK_PACK_CACHE[cache_key] = result
    return result


def _io_classify_call(
    c: str,
    language: str | None,
    conn,
    r,
    *,
    snippet: str | None = None,
) -> tuple[str | None, dict | None]:
    """Classify a single call inside a loop.

    Returns ``(level, framework_pack)`` where level is ``"high"``,
    ``"medium"``, ``"ambiguous"``, or None for in-memory / local-helper /
    non-I/O calls.

    D2 (2026-05-06): when ``snippet`` is supplied, the cache allowlist
    is OVERRIDDEN if the call appears with ``await`` in the snippet.
    Reason: ``await cache.fetch(k)`` is a real I/O round trip even
    though the leaf matches a cache identifier; user feedback called
    out the Promise<T> vs T distinction explicitly.
    """
    # D2: if call name matches cache allowlist BUT is awaited in the body,
    # the await says it really IS asynchronous I/O — escalate to medium.
    in_memory = _io_is_known_in_memory_call(c)
    if in_memory:
        if snippet and _is_call_awaited_in_snippet(c, snippet):
            return "medium", None  # await proves it's async I/O, not cache
        return None, None
    pack = _io_match_framework_pack(c, language)
    if pack:
        if pack.get("confidence") == "high":
            return "high", pack
        return "medium", pack

    lower_c = c.lower()
    leaf = _call_leaf(c).lower()
    if lower_c in _IO_HIGH_EXACT_LOWER:
        return "high", None
    if leaf in _IO_HIGH_LEAF and _io_receiver_is_ioish(c):
        return "high", None
    if leaf in {"get", "post", "put", "delete", "patch", "request"}:
        recv = _io_receiver_hint(c)
        if "requests" in recv or recv.endswith("http"):
            return "high", None
    if leaf in _IO_MEDIUM_LEAF and _io_receiver_is_ioish(c):
        return "medium", None
    if "." not in c and leaf in _IO_AMBIGUOUS_BARE:
        local_helper = conn.execute(
            "SELECT 1 FROM edges e "
            "JOIN symbols t ON e.target_id = t.id "
            "WHERE e.source_id = ? "
            "AND lower(t.name) = ? "
            "AND t.file_id = ? "
            "LIMIT 1",
            (r["id"], leaf, r["file_id"]),
        ).fetchone()
        if local_helper:
            return None, None
        return "ambiguous", None
    if leaf == "open":
        return "medium", None
    return None, None


def _io_emit_finding(
    level: str,
    high_calls: list[str],
    medium_calls: list[str],
    ambiguous_calls: list[str],
    frameworks: set[str],
    fixes: set[str],
    guard_hints: list[str],
    guard_applies: bool,
    evidence_io_calls: list[str],
    r,
    *,
    dev_gated: bool = False,
    match_line: int | None = None,
    snippet: str | None = None,
) -> dict:
    """Build the finding dict for one of high/medium/ambiguous result branches.

    M1 (match_line): pin location at the first I/O call site in the snippet
    rather than the function declaration.
    M4 (dev_gated): note when the body sits inside a DEV gate.
    M6 (suppress hint): every emitted finding carries `to_suppress` evidence.
    """
    fix_text = "; ".join(sorted(fixes)) if fixes else None
    # M1: try to find the line of the first I/O call inside the snippet.
    derived_match_line = match_line
    if derived_match_line is None and snippet and (high_calls or medium_calls or ambiguous_calls):
        first_call = (high_calls + medium_calls + ambiguous_calls)[0]
        leaf = _call_leaf(first_call) or first_call
        # Use a loose substring match — call shapes vary across extractors.
        if leaf:
            for offset, line in enumerate(snippet.splitlines()):
                if leaf in line:
                    derived_match_line = (r["line_start"] or 0) + offset
                    break
    common_evidence_extras = {}
    if dev_gated:
        common_evidence_extras["dev_gated"] = True
        common_evidence_extras["dev_gated_note"] = (
            "loop body sits inside a DEV-only conditional (import.meta.env.DEV / __DEV__ / "
            "process.env.NODE_ENV); production-stripped, so the N+1 cost is not paid in prod"
        )
    suppress_hint = (
        "wrap the loop in a batch/eager guard (e.g. `with()` or `map()`+`Promise.all`), OR "
        "add `# roam: ignore-math[io-in-loop]` on the function line if the call is intentional"
    )
    # T9 (2026-05-06) — assemble matched_patterns once for all branches.
    # Surfaces in `evidence.matched_patterns` so users see which classifier
    # branches contributed (high-leaf / framework-pack / ambiguous-bare /
    # dev-gated / batch-iteration). Quiet (empty list) when no signal.
    matched_patterns: list[str] = []
    if high_calls:
        matched_patterns.append(f"high-confidence I/O leaves ({len(high_calls)})")
    if medium_calls:
        matched_patterns.append(f"medium-confidence I/O leaves ({len(medium_calls)})")
    if ambiguous_calls:
        matched_patterns.append(f"ambiguous bare calls ({len(ambiguous_calls)})")
    if frameworks:
        matched_patterns.append(f"framework pack: {', '.join(sorted(frameworks))}")
    if guard_applies:
        matched_patterns.append("eager/batch guard nearby (confidence demoted)")
    if dev_gated:
        matched_patterns.append("DEV-only gate (confidence demoted)")

    if level == "high":
        reason_calls = _dedupe(high_calls)[:2]
        reason_suffix = f"; frameworks: {', '.join(sorted(frameworks))}" if frameworks else ""
        confidence = "high"
        if guard_applies:
            confidence = _lower_confidence(confidence)
            reason_suffix += f"; eager/batch guards: {', '.join(guard_hints[:2])}"
        return _finding(
            "io-in-loop",
            "loop-query",
            r,
            f"I/O call ({', '.join(reason_calls)}) inside loop (N+1 pattern){reason_suffix}",
            confidence,
            evidence={
                "io_calls": evidence_io_calls,
                "frameworks": sorted(frameworks),
                "guard_hints": guard_hints,
                "to_suppress": suppress_hint,
                **common_evidence_extras,
            },
            fix=fix_text,
            match_line=derived_match_line,
            snippet=snippet,
            matched_patterns=matched_patterns,
        )
    if level == "medium":
        reason_calls = _dedupe(medium_calls)[:2]
        reason_suffix = f"; frameworks: {', '.join(sorted(frameworks))}" if frameworks else ""
        confidence = "medium"
        if guard_applies:
            confidence = _lower_confidence(confidence)
            reason_suffix += f"; eager/batch guards: {', '.join(guard_hints[:2])}"
        return _finding(
            "io-in-loop",
            "loop-query",
            r,
            f"I/O-like call ({', '.join(reason_calls)}) inside loop (may be N+1){reason_suffix}",
            confidence,
            evidence={
                "io_calls": evidence_io_calls,
                "frameworks": sorted(frameworks),
                "guard_hints": guard_hints,
                "to_suppress": suppress_hint,
                **common_evidence_extras,
            },
            fix=fix_text,
            match_line=derived_match_line,
            snippet=snippet,
            matched_patterns=matched_patterns,
        )
    # Ambiguous bare calls (get/find/query) — weak evidence, low confidence.
    reason_calls = _dedupe(ambiguous_calls)[:2]
    finding = _finding(
        "io-in-loop",
        "loop-query",
        r,
        f"Ambiguous bare call ({', '.join(reason_calls)}) inside loop (possible I/O, review manually)",
        "low",
        evidence={
            "io_calls": evidence_io_calls,
            "ambiguous_io_calls": _dedupe(ambiguous_calls)[:4],
            "ambiguous_io_only": True,
            "frameworks": sorted(frameworks),
            "guard_hints": guard_hints,
            "to_suppress": suppress_hint,
            **common_evidence_extras,
        },
        fix=fix_text,
        match_line=derived_match_line,
        snippet=snippet,
        matched_patterns=matched_patterns,
    )
    finding["precision"] = "low"
    return finding


def detect_io_in_loop(conn: sqlite3.Connection) -> list[dict]:
    """Database query, HTTP request, or file I/O inside a loop β€” N+1 pattern.

    One of the most impactful performance anti-patterns in web applications.
    Each iteration incurs a full I/O round trip.
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.file_id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "f.language as language, s.line_start, s.line_end, ms.loop_depth, ms.calls_in_loops, "
            "ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.file_id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "f.language as language, s.line_start, s.line_end, ms.loop_depth, ms.calls_in_loops, "
            "'' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        language = _row_value(r, "language", "")
        snippet = _read_symbol_source(
            r["file_path"],
            _row_value(r, "line_start", None),
            _row_value(r, "line_end", None),
        )
        guard_hints = _guard_hints_from_source(language, snippet)
        calls = _iter_loop_calls(r)
        if not calls:
            continue

        high_calls: list[str] = []
        medium_calls: list[str] = []
        ambiguous_calls: list[str] = []
        frameworks: set[str] = set()
        fixes: set[str] = set()
        for c in calls:
            level, pack = _io_classify_call(c, language, conn, r, snippet=snippet)
            if pack:
                frameworks.add(pack["framework"])
                if pack.get("fix"):
                    fixes.add(pack["fix"])
            if level == "high":
                high_calls.append(c)
            elif level == "medium":
                medium_calls.append(c)
            elif level == "ambiguous":
                ambiguous_calls.append(c)

        if not high_calls and not medium_calls and not ambiguous_calls:
            continue

        name_lower = (r["name"] or "").lower()
        if any(kw in name_lower for kw in _IO_WRAPPER_NAMES):
            continue

        # DF2 (2026-05-06) — body-level: skip if the loop iterates chunks
        # / batches rather than items. Catches the canonical `for chunk in
        # _chunked(ids):` pattern where the inner query is WHERE IN (...).
        if _has_batch_iteration(snippet):
            continue

        # M4: skip DEV-gated bodies — production stripped, so loop overhead
        # is irrelevant. (Conservative: only skip when the gate is *literally*
        # in this function's body.)
        dev_gated = _is_dev_only_block(snippet)
        guard_applies = bool(frameworks and guard_hints)
        evidence_io_calls = _dedupe(high_calls + medium_calls + ambiguous_calls)[:6]
        if high_calls:
            level = "high"
        elif medium_calls:
            level = "medium"
        else:
            level = "ambiguous"
        if dev_gated:
            # Don't drop entirely — a real production-bound issue could still
            # exist outside the gate. But demote two tiers so it sinks to the
            # bottom of the verdict list.
            if level == "high":
                level = "medium"
            elif level == "medium":
                level = "ambiguous"
        results.append(
            _io_emit_finding(
                level,
                high_calls,
                medium_calls,
                ambiguous_calls,
                frameworks,
                fixes,
                guard_hints,
                guard_applies,
                evidence_io_calls,
                r,
                dev_gated=dev_gated,
                snippet=snippet,
            )
        )
    return results


def detect_list_prepend(conn: sqlite3.Connection) -> list[dict]:
    """insert(0, x), unshift(), or pop(0) inside a loop β€” O(n) per op
    due to array shifting, O(n^2) total."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.front_ops_in_loop, "
            "ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.front_ops_in_loop = 1"
        ).fetchall()
    except Exception:
        # Fallback for older indexes without front_ops_in_loop.
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.calls_in_loops, '' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()

    # deque operations are O(1) β€” suppress when popleft/appendleft are the ops
    _DEQUE_OPS = {"popleft", "appendleft", "extendleft"}

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        calls = _iter_loop_calls(r)
        # If the only front-ops are deque methods, this is already optimal
        front_calls = _call_in(calls, {"insert", "unshift", "shift", "popleft", "appendleft", "extendleft"})
        if front_calls and all(_call_leaf(c) in _DEQUE_OPS for c in front_calls):
            continue  # Already using deque β€” no issue
        # New indexes precompute the exact front-op signal.
        if _row_value(r, "front_ops_in_loop", None) == 1:
            results.append(
                _finding(
                    "list-prepend",
                    "insert-front",
                    r,
                    "Front insert/remove inside loop (O(n) shift per operation)",
                    "high",
                )
            )
            continue
        # Fallback heuristic (conservative): only list front APIs.
        # Note: appendleft/popleft are deque O(1) ops β€” do NOT flag those.
        if _call_in(calls, {"insert", "unshift", "shift"}):
            results.append(
                _finding(
                    "list-prepend",
                    "insert-front",
                    r,
                    "Potential front insert/remove inside loop",
                    "medium",
                )
            )
    return results


def detect_sort_to_select(conn: sqlite3.Connection) -> list[dict]:
    """Calling sort on a collection and then only using the first/last element.

    O(n log n) sort when min()/max() is O(n), or heapq.nsmallest is O(n log k).
    Detection: function calls sort AND has subscript access, but does NOT
    iterate the full sorted result.
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
        "s.line_start, s.line_end "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "WHERE s.kind IN ('function', 'method')"
    ).fetchall()

    sorted_index_re = re.compile(r"\bsorted\s*\([^)]*\)\s*\[\s*(?:-?\d+|:\s*[^]\n]+)\s*\]")
    inplace_sort_index_re = re.compile(
        r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\.\s*sort\s*\([^)]*\).*?"
        r"\b\1\s*\[\s*(?:-?\d+|:\s*[^]\n]+)\s*\]",
        re.DOTALL,
    )
    generic_sort_index_re = re.compile(
        r"\bsort(?:ed)?\s*\([^)]*\).*?\[\s*(?:-?\d+|:\s*[^]\n]+)\s*\]",
        re.DOTALL,
    )
    # M1: per-line sort detector for pinpointing the match line
    sort_call_line_re = re.compile(r"\bsort(?:ed)?\s*\(")

    # M5 — fallback false-positive guard. Skip when the sort result is also
    # iterated/returned in full (sorted then map/forEach/return — display order,
    # not a min/max selection).
    # The check is conservative: if we see ANY iteration of the sort target
    # alongside the index access, demote the finding rather than skip outright.
    iteration_after_sort_re = re.compile(r"\bsort(?:ed)?\s*\(.*?\b(map|forEach|filter|reduce|return)\b", re.DOTALL)

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"])
        if not snippet:
            continue

        match_line = _find_match_line(snippet, sort_call_line_re, r["line_start"])
        sort_iterated = bool(iteration_after_sort_re.search(snippet))

        # Strong patterns: sorted(...)[0], sorted(... )[:k], arr.sort(); arr[0]
        if sorted_index_re.search(snippet) or inplace_sort_index_re.search(snippet):
            # M5: when the sort result is also iterated, downgrade — the
            # subscript may be incidental (e.g. logging the first item of a
            # display-ordered list).
            confidence = "medium" if sort_iterated else "high"
            reason = "Sort used only for first/last/top-k selection"
            if sort_iterated:
                reason += " (note: result is also iterated — may be incidental subscript)"
            results.append(
                _finding(
                    "sort-to-select",
                    "full-sort",
                    r,
                    reason,
                    confidence,
                    match_line=match_line,
                    snippet=snippet,
                )
            )
            continue

        # Fallback pattern for other languages (sort(...) then index/slice).
        if generic_sort_index_re.search(snippet):
            confidence = "low" if sort_iterated else "medium"
            reason = "Potential full sort followed by index/slice selection"
            if sort_iterated:
                reason += " (note: result is also iterated — may be incidental subscript)"
            results.append(
                _finding(
                    "sort-to-select",
                    "full-sort",
                    r,
                    reason,
                    confidence,
                    match_line=match_line,
                    snippet=snippet,
                )
            )
    return results


# T3 (2026-05-06) — JS/TS-specific: serial-await inside a for-of loop is a
# Promise.all opportunity. Each `await` round-trips before the next call
# starts, so 100 awaits = 100x the latency of one. The fix is
# `await Promise.all(items.map(item => fetch(item)))`. Distinct from
# io-in-loop because the per-item call may not match a known I/O leaf
# (custom async helpers); the `await` itself is the signal.
_RE_FOR_OF = re.compile(
    r"\bfor\s*(?:await\s*)?\s*\(\s*(?:const|let|var)\s+\w+\s+of\s+",
)
_RE_AWAIT_IN_BODY = re.compile(r"\bawait\s+[\w$.]+\s*\(")


def detect_serial_await_loop(conn: sqlite3.Connection) -> list[dict]:
    """`for (... of ...) { await x() }` — serial-await N+1 (Promise.all opportunity).

    Only fires for JS/TS. Two signals:
    1. The function body contains a `for ... of ...` (or `for await ... of`) header.
    2. The body has at least one `await call()` line.
    Skips when body uses `Promise.all`/`Promise.allSettled` (already batched).
    """
    rows = conn.execute(
        "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
        "f.language AS language, s.line_start, s.line_end, ms.loop_depth "
        "FROM symbols s "
        "JOIN files f ON s.file_id = f.id "
        "JOIN math_signals ms ON ms.symbol_id = s.id "
        "WHERE s.kind IN ('function', 'method') "
        "AND ms.loop_depth >= 1 "
        "AND f.language IN ('javascript', 'typescript', 'tsx', 'jsx')"
    ).fetchall()

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        snippet = _read_symbol_source(
            r["file_path"],
            _row_value(r, "line_start", None),
            _row_value(r, "line_end", None),
        )
        if not snippet:
            continue
        if not _RE_FOR_OF.search(snippet):
            continue
        if not _RE_AWAIT_IN_BODY.search(snippet):
            continue
        # Already-batched: Promise.all / Promise.allSettled in the body.
        if "Promise.all" in snippet:
            continue
        # Skip benign awaited identifiers that aren't I/O (await timeout(0),
        # await Promise.resolve, await new Promise(...)). Conservative: only
        # fire when the awaited callee is a method/function name on a value,
        # not a literal Promise constructor call.
        if not re.search(r"\bawait\s+(?!new\s+Promise|Promise\.|setTimeout|setImmediate)[\w$.]+\s*\(", snippet):
            continue
        results.append(
            _finding(
                "serial-await-loop",
                "for-of-await",
                r,
                "for-of loop with serial `await` — each iteration waits for the previous "
                "(use Promise.all for parallel I/O)",
                "high",
                snippet=snippet,
                matched_patterns=["for-of header", "await-call in body", "no Promise.all batch"],
            )
        )
    return results


# X1 (2026-05-06) — Python-specific: `time.sleep()` inside an async function
# blocks the event loop. The async cousin is `asyncio.sleep` (or trio.sleep).
# This is one of the most common asyncio bugs and dramatically degrades
# request throughput in async web servers (FastAPI, aiohttp, Sanic).
def detect_async_blocking_sleep(conn: sqlite3.Connection) -> list[dict]:
    """`time.sleep()` (or other blocking calls) inside an async function.

    Async functions must use ``await asyncio.sleep(n)`` instead — otherwise
    the entire event loop stalls. Same applies to other blocking I/O calls
    (``requests.get``, ``urllib.urlopen``, sync DB drivers).

    Conservative: only fires for Python (the bug shape is language-specific)
    and only when ``is_async`` is set on the symbol row.
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
            "s.line_start, s.line_end, ms.calls_in_loops, ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND s.is_async = 1 "
            "AND f.language = 'python'"
        ).fetchall()
    except Exception:
        return []

    _BLOCKING_CALLS = {
        "time.sleep",
        "sleep",
        "requests.get",
        "requests.post",
        "requests.put",
        "requests.delete",
        "requests.patch",
        "urllib.request.urlopen",
        "urlopen",
        "subprocess.run",
        "subprocess.call",
        "subprocess.check_output",
    }
    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        # Combine loop calls with body scan: blocking calls anywhere in the
        # async body (not just inside loops) are still bugs.
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"]) or ""
        loop_calls = _iter_loop_calls(r)
        body_blocking: list[str] = []
        for call in loop_calls:
            if call.lower() in _BLOCKING_CALLS or _call_leaf(call).lower() in {"sleep", "urlopen"}:
                body_blocking.append(call)
        # Cheap snippet sweep to catch out-of-loop occurrences.
        if not body_blocking:
            for needle in ("time.sleep(", "requests.get(", "requests.post(", "urlopen(", "subprocess.run("):
                if needle in snippet:
                    body_blocking.append(needle.rstrip("("))
                    break
        if not body_blocking:
            continue
        # The await heuristic — if the snippet already awaits the same leaf,
        # it's the async cousin (await asyncio.sleep), so skip.
        if "await asyncio.sleep" in snippet or "await trio.sleep" in snippet:
            # Could still have a stray `time.sleep` on another line; only
            # skip when no blocking-call needles remained after that filter.
            if not any(c.startswith("time.sleep") or c == "time.sleep" for c in body_blocking):
                continue
        results.append(
            _finding(
                "async-blocking-sleep",
                "blocking-call-in-async",
                r,
                f"Blocking call ({', '.join(body_blocking[:2])}) inside async function — blocks the event loop",
                "high",
                snippet=snippet,
                matched_patterns=[
                    "is_async = 1",
                    f"blocking calls: {', '.join(body_blocking[:3])}",
                ],
            )
        )
    return results


# R5 (2026-05-07) — `asyncio.create_task(coro())` whose return value is
# discarded. The task is gc-collected before it runs to completion. The
# fix is to either store the task in a long-lived collection or `await`
# it. PEP 649 / Python 3.11+ docs explicitly call this a footgun.
_RE_FIRE_AND_FORGET_TASK = re.compile(
    r"^\s*(?:asyncio\.)?create_task\s*\(",
    re.MULTILINE,
)
_RE_STORED_TASK = re.compile(
    r"^\s*(?:\w+\s*[+\-*/]?=\s*|\w+\s*\.\s*append\s*\(\s*|\w+\s*\.\s*add\s*\(\s*|return\s+|await\s+)"
    r"(?:asyncio\.)?create_task\s*\(",
    re.MULTILINE,
)


def detect_async_fire_and_forget(conn: sqlite3.Connection) -> list[dict]:
    """``asyncio.create_task(...)`` whose return value is discarded.

    Background tasks that aren't held in a long-lived reference get
    garbage-collected before they finish. Python 3.11+ explicitly warns
    about this footgun. The fix is to store the task somewhere that
    survives until ``await`` time, or just ``await`` it directly.

    Conservative: Python only, only fires when the line clearly creates
    a task without storing it.
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
            "s.line_start, s.line_end "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND f.language = 'python'"
        ).fetchall()
    except Exception:
        return []
    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"]) or ""
        if "create_task" not in snippet:
            continue
        # Subtract stored-task lines from total create_task occurrences
        total = len(_RE_FIRE_AND_FORGET_TASK.findall(snippet))
        stored = len(_RE_STORED_TASK.findall(snippet))
        leaked = total - stored
        if leaked <= 0:
            continue
        results.append(
            _finding(
                "async-fire-and-forget-task",
                "leaked-asyncio-task",
                r,
                f"{leaked} asyncio.create_task call(s) whose return value isn't stored — gc may discard the task before it completes",
                "high",
                snippet=snippet,
                matched_patterns=[
                    f"create_task occurrences: {total}",
                    f"stored: {stored}, leaked: {leaked}",
                ],
            )
        )
        results[-1]["fix"] = (
            "Store the task: `tasks.append(asyncio.create_task(coro()))` and await it later, or `await asyncio.create_task(coro())` directly."
        )
    return results


# R5 (2026-05-07) — `asyncio.run(...)` inside an async function. This
# raises RuntimeError because the event loop is already running. The
# fix is to call the coroutine directly with `await` instead.
_RE_NESTED_ASYNCIO_RUN = re.compile(
    r"^\s*(?:asyncio\.)?run\s*\(",
    re.MULTILINE,
)


def detect_async_nested_run(conn: sqlite3.Connection) -> list[dict]:
    """``asyncio.run()`` invoked inside another async function.

    ``asyncio.run`` creates a new event loop. If one is already running
    (which it is, inside an async function), this raises ``RuntimeError:
    asyncio.run() cannot be called from a running event loop``. The fix
    is to ``await`` the coroutine directly.

    Python only, fires only when the host is async.
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
            "s.line_start, s.line_end "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND s.is_async = 1 "
            "AND f.language = 'python'"
        ).fetchall()
    except Exception:
        return []
    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"]) or ""
        if "asyncio.run(" not in snippet:
            continue
        # Heuristic: must be `asyncio.run(` (not `await asyncio.run(`); the
        # latter is also wrong but caught by other linters more reliably.
        match_count = snippet.count("asyncio.run(")
        if match_count == 0:
            continue
        results.append(
            _finding(
                "async-nested-run",
                "asyncio-run-in-async",
                r,
                "asyncio.run() invoked inside an async function — raises RuntimeError at runtime (loop already running)",
                "high",
                snippet=snippet,
                matched_patterns=[
                    "is_async = 1",
                    f"asyncio.run( occurrences: {match_count}",
                ],
            )
        )
        results[-1]["fix"] = "Replace `asyncio.run(coro())` with `await coro()` — you're already inside an event loop."
    return results


# X2 (2026-05-06) — Python: `except Exception:` / `except BaseException:`
# without `raise` is the canonical "swallowing bug" pattern. Catches
# KeyboardInterrupt, MemoryError, SystemExit silently. The fix is to
# narrow the exception type or always re-raise after logging.
_RE_BROAD_EXCEPT = re.compile(
    r"^\s*except\s+(?:Exception|BaseException)\s*(?:as\s+\w+\s*)?:",
    re.MULTILINE,
)
_RE_RERAISE = re.compile(r"^\s*raise(?:\s|$)", re.MULTILINE)


def detect_broad_except_swallow(conn: sqlite3.Connection) -> list[dict]:
    """Python: `except Exception:` block that silently swallows the error.

    Fires when the body has NO `raise` statement — meaning the error is
    caught, possibly logged, and the program continues as if nothing
    happened. That hides real bugs and masks operational failures.

    Skip cases:
    - Re-raise present (intentional log-and-rethrow)
    - Function name suggests it's an error-recovery wrapper
      (`safe_*`, `_try_*`, `with_default`, `silent_*`).
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
            "s.line_start, s.line_end "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND f.language = 'python'"
        ).fetchall()
    except Exception:
        return []

    _RECOVERY_PREFIXES = (
        "safe_",
        "_safe_",
        "try_",
        "_try_",
        "with_default_",
        "silent_",
        "_silent_",
        "noexcept_",
    )
    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        name_lower = (r["name"] or "").lower()
        if any(name_lower.startswith(p) for p in _RECOVERY_PREFIXES):
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"])
        if not snippet:
            continue
        broad_match = _RE_BROAD_EXCEPT.search(snippet)
        if not broad_match:
            continue
        # If the function body re-raises somewhere AFTER the broad except,
        # treat it as intentional log-and-rethrow.
        post = snippet[broad_match.end() :]
        if _RE_RERAISE.search(post):
            continue
        # Find the matched line number for precise location reporting.
        line_offset = snippet[: broad_match.start()].count("\n")
        match_line = (r["line_start"] or 1) + line_offset
        results.append(
            _finding(
                "broad-except-swallow",
                "swallow-exception",
                r,
                "`except Exception:` without re-raise — silently swallows bugs",
                "medium",
                match_line=match_line,
                snippet=snippet,
                matched_patterns=[
                    "broad except clause",
                    "no re-raise in body",
                    "function name not in recovery prefix list",
                ],
            )
        )
    return results


# X3 (2026-05-06) — JS/TS: `acc = [...acc, x]` (or `.reduce((acc, x) => [...acc, x])`)
# allocates a fresh O(n) array per iteration → O(n²) total. The fix is
# `acc.push(x)` (or `flat()` for nested arrays). Same shape applies to
# `obj = {...obj, k: v}` in loops, and to `acc + [x]`.
_RE_SPREAD_ACC = re.compile(
    r"\b(\w+)\s*=\s*\[\s*\.\.\.\s*\1\s*,",  # name = [...name,
)
_RE_SPREAD_OBJ_ACC = re.compile(
    r"\b(\w+)\s*=\s*\{\s*\.\.\.\s*\1\s*[,}]",  # name = {...name,
)
_RE_REDUCE_SPREAD = re.compile(
    r"\.\s*reduce\s*\(\s*\(\s*(\w+)[^)]*\)\s*=>\s*\[\s*\.\.\.\s*\1\s*,",
)
_RE_REDUCE_SPREAD_OBJ = re.compile(
    r"\.\s*reduce\s*\(\s*\(\s*(\w+)[^)]*\)\s*=>\s*\{\s*\.\.\.\s*\1\s*[,}]",
)


def detect_spread_accumulator(conn: sqlite3.Connection) -> list[dict]:
    """JS/TS: `acc = [...acc, x]` or `.reduce((acc, x) => [...acc, x])` is O(n²)."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
            "f.language AS language, s.line_start, s.line_end "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND f.language IN ('javascript', 'typescript', 'tsx', 'jsx')"
        ).fetchall()
    except Exception:
        return []
    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"])
        if not snippet:
            continue
        matched: list[str] = []
        first_pos: int | None = None
        for pat, label in (
            (_RE_REDUCE_SPREAD, "reduce array spread accumulator"),
            (_RE_REDUCE_SPREAD_OBJ, "reduce object spread accumulator"),
            (_RE_SPREAD_ACC, "in-place array spread re-bind"),
            (_RE_SPREAD_OBJ_ACC, "in-place object spread re-bind"),
        ):
            m = pat.search(snippet)
            if m is None:
                continue
            matched.append(label)
            if first_pos is None or m.start() < first_pos:
                first_pos = m.start()
        if not matched:
            continue
        if first_pos is None:
            first_pos = 0
        line_offset = snippet[:first_pos].count("\n")
        match_line = (r["line_start"] or 1) + line_offset
        results.append(
            _finding(
                "spread-accumulator",
                "spread-rebind",
                r,
                f"Spread accumulator ({matched[0]}) is O(n^2) — use .push() / Object.assign()",
                "high",
                match_line=match_line,
                snippet=snippet,
                matched_patterns=matched,
            )
        )
    return results


# X5 (2026-05-06) — Go: `defer` inside a loop accumulates the deferred
# call stack until the FUNCTION returns, not the loop iteration. Common
# bug: `for _, f := range files { fh, _ := os.Open(f); defer fh.Close() }`
# — none of the file handles close until the function returns, exhausting
# fds on big input. Fix: extract the loop body to a helper function so
# defer fires per call, OR use an explicit `fh.Close()` at the end.
_RE_DEFER_IN_LOOP_BODY = re.compile(
    r"\b(?:for|range)\b[^{]*\{[^}]*\bdefer\b\s+[\w$.]+",
    re.DOTALL,
)


def detect_defer_in_loop(conn: sqlite3.Connection) -> list[dict]:
    """Go: `defer` inside a `for`/`range` loop accumulates instead of firing per-iteration."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
            "f.language AS language, s.line_start, s.line_end "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND f.language = 'go'"
        ).fetchall()
    except Exception:
        return []
    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"])
        if not snippet:
            continue
        m = _RE_DEFER_IN_LOOP_BODY.search(snippet)
        if not m:
            continue
        # Find the line of the defer keyword (not the for keyword) for precise location.
        defer_pos = snippet.find("defer ", m.start())
        if defer_pos == -1:
            defer_pos = m.start()
        line_offset = snippet[:defer_pos].count("\n")
        match_line = (r["line_start"] or 1) + line_offset
        results.append(
            _finding(
                "defer-in-loop",
                "loop-defer",
                r,
                "`defer` inside loop — fires when function returns, not when iteration ends "
                "(extract loop body to a helper, or close explicitly)",
                "high",
                match_line=match_line,
                snippet=snippet,
                matched_patterns=["for/range loop", "defer inside loop body"],
            )
        )
    return results


# X13 (2026-05-06) — JS/TS: `.filter(predA).find(predB)` walks the array
# fully then searches the filtered subset. Equivalent to a single pass
# `.find(x => predA(x) && predB(x))`. Other equivalent patterns:
# `.map().find()` (could be `.find()` then `.map()`), `.filter().length`
# (use `.some()` or `.every()`), `.reduce()` to a boolean (use `.some()`).
_RE_FILTER_FIND = re.compile(
    r"\.\s*filter\s*\([^)]*\)\s*\.\s*find\s*\(",
)
_RE_FILTER_LENGTH_BOOL = re.compile(
    r"\.\s*filter\s*\([^)]*\)\s*\.\s*length\s*(?:>\s*0|>=\s*1|!==?\s*0)",
)
_RE_MAP_FIND = re.compile(
    r"\.\s*map\s*\([^)]*\)\s*\.\s*find\s*\(",
)


def detect_chained_collection_walks(conn: sqlite3.Connection) -> list[dict]:
    """JS/TS: `.filter().find()` and friends are 2-pass; one-pass equivalents exist."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
            "s.line_start, s.line_end "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND f.language IN ('javascript', 'typescript', 'tsx', 'jsx')"
        ).fetchall()
    except Exception:
        return []
    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"])
        if not snippet:
            continue
        matched: list[str] = []
        first_pos: int | None = None
        for pat, label, fix_hint in (
            (_RE_FILTER_FIND, "filter().find() — two passes", ".find(x => predA(x) && predB(x))"),
            (_RE_FILTER_LENGTH_BOOL, "filter().length — full walk for boolean", ".some(x => predA(x))"),
            (_RE_MAP_FIND, "map().find() — full transform before search", ".find() then .map() of one item"),
        ):
            m = pat.search(snippet)
            if m is None:
                continue
            matched.append(f"{label} → {fix_hint}")
            if first_pos is None or m.start() < first_pos:
                first_pos = m.start()
        if not matched:
            continue
        if first_pos is None:
            first_pos = 0
        line_offset = snippet[:first_pos].count("\n")
        match_line = (r["line_start"] or 1) + line_offset
        results.append(
            _finding(
                "chained-collection-walk",
                "two-pass-walk",
                r,
                f"Chained collection walk ({matched[0].split(' →')[0]}) — single-pass form available",
                "medium",
                match_line=match_line,
                snippet=snippet,
                matched_patterns=matched,
            )
        )
    return results


# Z1 (2026-05-06) — React: `useEffect(() => { ... })` without a dependency
# array runs on EVERY render. Almost always a bug — the dev forgot the
# second argument. The fix is `useEffect(() => { ... }, [deps])` or
# `useEffect(() => { ... }, [])` for mount-only.
_RE_USEEFFECT_NO_DEPS = re.compile(
    r"\buseEffect\s*\(\s*(?:async\s+)?(?:\(\s*\)|function\s*\(\s*\))\s*=>\s*\{[^}]*?\}\s*\)",
    re.DOTALL,
)
_RE_USEEFFECT_WITH_DEPS = re.compile(
    r"\buseEffect\s*\(\s*[^,]+,\s*\[",
)


def detect_useeffect_missing_deps(conn: sqlite3.Connection) -> list[dict]:
    """React: `useEffect(() => {...})` without a dependency array."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
            "s.line_start, s.line_end "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND f.language IN ('javascript', 'typescript', 'tsx', 'jsx')"
        ).fetchall()
    except Exception:
        return []
    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"])
        if not snippet or "useEffect" not in snippet:
            continue
        # Skip if every useEffect call also has a deps array.
        no_deps = _RE_USEEFFECT_NO_DEPS.search(snippet)
        if not no_deps:
            continue
        # Verify the SAME call doesn't have a deps array (regex catches the
        # no-deps shape but a more elaborate body could trick it).
        # Conservative: only fire when there's NO useEffect-with-deps in body.
        if _RE_USEEFFECT_WITH_DEPS.search(snippet):
            # Mixed bag — at least one useEffect has deps, can't reliably
            # tell which one is the problem without a real parser. Skip.
            continue
        line_offset = snippet[: no_deps.start()].count("\n")
        match_line = (r["line_start"] or 1) + line_offset
        results.append(
            _finding(
                "useeffect-missing-deps",
                "no-deps-array",
                r,
                "useEffect without dependency array — runs on every render",
                "high",
                match_line=match_line,
                snippet=snippet,
                matched_patterns=["useEffect call", "no second-arg dep array"],
            )
        )
    return results


# Z2 (2026-05-06) — `eval()` / `exec()` / `new Function()` / `setTimeout(string)`
# in production source. These are arbitrary code execution sinks if the
# input is user-derived. Even when "safe" (literal string), they trip
# CSP rules and bundler optimisations. Suppress when test path.
_RE_EVAL_CALLS = re.compile(
    r"\b(?:eval|exec|execfile|compile)\s*\("
    r"|\bnew\s+Function\s*\("
    r"|\bsetTimeout\s*\(\s*['\"]"
    r"|\bsetInterval\s*\(\s*['\"]",
)


def detect_dangerous_eval(conn: sqlite3.Connection) -> list[dict]:
    """Detect `eval`, `exec`, `new Function(...)`, `setTimeout(string)` — code-injection sinks."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
            "f.language AS language, s.line_start, s.line_end "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "WHERE s.kind IN ('function', 'method')"
        ).fetchall()
    except Exception:
        return []
    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        # Skip non-source roles when we can tell.
        path = (r["file_path"] or "").replace("\\", "/").lower()
        if "/migration" in path or "/script" in path or "/cli" in path:
            # CLI / migration scripts often legitimately use exec/eval.
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"])
        if not snippet:
            continue
        m = _RE_EVAL_CALLS.search(snippet)
        if not m:
            continue
        # Skip ast.literal_eval (safe), regex.compile (different "compile"
        # — won't actually match because it ends in `.compile(` with a dot
        # before, so prefix isn't word-boundary — but be defensive).
        if "literal_eval" in snippet[max(0, m.start() - 20) : m.end()]:
            continue
        if ".compile(" in snippet[max(0, m.start() - 5) : m.end() + 1]:
            continue
        line_offset = snippet[: m.start()].count("\n")
        match_line = (r["line_start"] or 1) + line_offset
        called = m.group(0).rstrip("(")
        results.append(
            _finding(
                "dangerous-eval",
                "eval-or-exec",
                r,
                f"Dangerous dynamic execution sink ({called}) — code-injection risk if input is user-derived",
                "high",
                match_line=match_line,
                snippet=snippet,
                matched_patterns=[f"call: {called}", "not in test/migration/script path"],
            )
        )
    return results


# Z5 (2026-05-06) — JS/TS DOM listener leak: `addEventListener` without
# a paired `removeEventListener` keeps references alive after the
# component unmounts. Detect ONLY when the function looks like a
# component lifecycle (useEffect / componentDidMount / connectedCallback /
# constructor) and addEventListener appears without remove.
_RE_ADD_LISTENER = re.compile(r"\baddEventListener\s*\(")
_RE_REMOVE_LISTENER = re.compile(r"\bremoveEventListener\s*\(")
_RE_LIFECYCLE = re.compile(
    r"\b(?:useEffect|componentDidMount|componentWillMount|connectedCallback|constructor)\b",
)


def detect_unremoved_event_listener(conn: sqlite3.Connection) -> list[dict]:
    """JS/TS: `addEventListener` in a lifecycle without paired `removeEventListener`."""
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path AS file_path, "
            "s.line_start, s.line_end "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND f.language IN ('javascript', 'typescript', 'tsx', 'jsx')"
        ).fetchall()
    except Exception:
        return []
    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        snippet = _read_symbol_source(r["file_path"], r["line_start"], r["line_end"])
        if not snippet:
            continue
        if not _RE_ADD_LISTENER.search(snippet):
            continue
        # Only fire for lifecycle-ish bodies — outside of components,
        # listeners are often global and intentionally never removed.
        if not _RE_LIFECYCLE.search(snippet):
            continue
        # Already paired: presence of removeEventListener anywhere in body.
        if _RE_REMOVE_LISTENER.search(snippet):
            continue
        # `useEffect` should also return a cleanup function. Check for one.
        if "useEffect" in snippet and re.search(r"return\s+(?:\(\s*\)|function)", snippet):
            continue
        m = _RE_ADD_LISTENER.search(snippet)
        line_offset = snippet[: m.start()].count("\n")
        match_line = (r["line_start"] or 1) + line_offset
        results.append(
            _finding(
                "unremoved-event-listener",
                "no-cleanup",
                r,
                "addEventListener in component lifecycle without removeEventListener — memory leak",
                "high",
                match_line=match_line,
                snippet=snippet,
                matched_patterns=[
                    "addEventListener call",
                    "lifecycle context (useEffect / componentDidMount / etc.)",
                    "no paired removeEventListener",
                ],
            )
        )
    return results


def detect_loop_lookup(conn: sqlite3.Connection) -> list[dict]:
    """.index(), .indexOf(), .contains(), .includes() called inside a loop.

    Each call is O(m) linear scan on the lookup collection, total O(n*m).
    Pre-building a set gives O(1) per lookup, O(n+m) total.
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_lookup_calls, ms.calls_in_loops, "
            "ms.calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()
    except Exception:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, '' as loop_lookup_calls, ms.calls_in_loops, "
            "'' as calls_in_loops_qualified "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_depth >= 1"
        ).fetchall()

    _LOOKUP_CALLS = {
        "index",
        "indexOf",
        "lastIndexOf",
        "contains",
        "includes",
        "Contains",
        "IndexOf",
    }

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        lookup_calls = _json_list(_row_value(r, "loop_lookup_calls", ""))
        if lookup_calls:
            results.append(
                _finding(
                    "loop-lookup",
                    "method-scan",
                    r,
                    f"Linear lookup ({', '.join(lookup_calls[:2])}) called on invariant collection",
                    "high",
                )
            )
            continue
        # Fallback for older indexes: conservative matching only.
        calls = _iter_loop_calls(r)
        fallback_hits = _call_in(calls, _LOOKUP_CALLS)
        if fallback_hits:
            results.append(
                _finding(
                    "loop-lookup",
                    "method-scan",
                    r,
                    f"Linear lookup ({', '.join(fallback_hits[:2])}) called inside loop",
                    "low",
                )
            )
    return results


# ---------------------------------------------------------------------------
# Tier 2 detectors: enhanced signals
# ---------------------------------------------------------------------------


def detect_branching_recursion(conn: sqlite3.Connection) -> list[dict]:
    """Functions with 2+ self-call sites and no memoization.

    Generalizes fibonacci to any branching recursion: tree traversals,
    divide-and-conquer, DP problems.  O(2^n) -> O(n) with memoization.
    """
    # self_call_count column may not exist in older DBs β€” fall back safely
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "f.language as language, s.line_start, s.line_end, ms.self_call_count "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.self_call_count >= 2"
        ).fetchall()
    except Exception:
        return []

    results = []

    # M2 fix: detect the SECOND form of depth guard — early-return when
    # depth EXCEEDS limit ("if depth > 10 return"). The original regex only
    # recognised "depth < limit ⇒ continue" patterns; the negation form was
    # silently mis-flagged as O(2^n). Real-world FP: deepEqual flagged
    # despite line+2 having `if (depth > 10) return false`.
    # S9 (2026-05-06) — pre-compile the depth-guard / memo-collection
    # regexes once. Previously each `re.search(literal, snippet)` call
    # rebuilt the pattern object via the implicit re._cache (capped at
    # 512 entries), which can evict on a busy run. Hoisting them keeps
    # the patterns hot.
    _SPLIT_LENGTH_GUARD = re.compile(r"\.split\s*\([^)]*\)\s*\.\s*length\s*(?:<|<=)\s*\d+")
    _LEN_SPLIT_GUARD = re.compile(r"len\s*\(\s*[^)]*\.split\s*\([^)]*\)\s*\)\s*(?:<|<=)\s*\d+")
    _DEPTH_BELOW_GUARD = re.compile(
        r"\b(?:depth|level|budget|remaining|hops|currentDepth|current_depth|max_depth|maxDepth)\b"
        r"\s*(?:<|<=)\s*(?:\d+|maxDepth|max_depth|MAX_DEPTH|max_recursion|MAX_RECURSION)",
    )
    _DEPTH_EXCEEDS_GUARD = re.compile(
        r"\b(?:depth|level|budget|remaining|hops|recursion_count|recursionDepth)\b"
        r"\s*(?:>|>=|<|<=)\s*(?:\d+|maxDepth|max_depth|MAX_DEPTH|max_recursion|MAX_RECURSION|0)\s*\)?\s*"
        r"\s*[:{]?\s*(?:return|raise|throw|break)",
    )
    _DEC_THEN_CHECK_GUARD = re.compile(
        r"--?\s*\b(?:depth|budget|remaining|hops)\b\s*[<>]=?\s*\d+\s*\)?\s*[:{]?\s*"
        r"(?:return|raise|throw|break)",
    )
    _MAXDEPTH_VAR_GUARD = re.compile(
        r"\b(?:maxDepth|max_depth)\b\s*(?:>|>=)\s*\b(?:depth|level|currentDepth|current_depth)\b",
    )
    _MEMO_COLLECTION_GENERIC = re.compile(r"\b(?:Set|Map|WeakSet|WeakMap)\s*<")
    _MEMO_COLLECTION_LITERAL = re.compile(r"\bnew\s+(?:Set|Map|WeakSet|WeakMap)\b")
    _MEMO_VAR_NAME = re.compile(r"\b(?:visited|seen|memo|cache|memoised|memoized)\b\s*[:=]")
    _MEMO_DECORATOR = re.compile(r"@(?:lru_cache|cache|memoize|memoise|functools\.lru_cache)\b")

    def _has_explicit_depth_guard(language: str | None, snippet: str) -> bool:
        """Return True for bounded-recursion guards that cap traversal depth."""
        if not snippet:
            return False
        if _SPLIT_LENGTH_GUARD.search(snippet):  # JS/TS: path.split('.').length < 5
            return True
        if _LEN_SPLIT_GUARD.search(snippet):  # Python: len(path.split(".")) < 5
            return True
        if _DEPTH_BELOW_GUARD.search(snippet):  # Form 1: depth < limit
            return True
        # M2 — Form 2: early-return if depth/level/budget EXCEEDS limit.
        if _DEPTH_EXCEEDS_GUARD.search(snippet):
            return True
        if _DEC_THEN_CHECK_GUARD.search(snippet):  # `if (--budget <= 0) return`
            return True
        if language and language.lower() in {"javascript", "typescript"} and _MAXDEPTH_VAR_GUARD.search(snippet):
            return True
        return False

    # M2 — Set/Map/WeakSet/WeakMap parameter or local: signals the function
    # already implements its own memoization / cycle-tracking, so the
    # branching-recursion warning would be a FP.
    def _has_memo_collection(snippet: str) -> bool:
        if not snippet:
            return False
        if _MEMO_COLLECTION_GENERIC.search(snippet):  # TS generic
            return True
        if _MEMO_COLLECTION_LITERAL.search(snippet):  # JS literal
            return True
        if _MEMO_VAR_NAME.search(snippet):
            return True
        if _MEMO_DECORATOR.search(snippet):
            return True
        return False

    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        # Skip fibonacci β€” already covered by detect_naive_fibonacci
        name_lower = (r["name"] or "").lower()
        if "fib" in name_lower:
            continue
        # Skip tree/AST walkers β€” recursive traversal of children is
        # intentional and doesn't have overlapping subproblems
        _WALKER_NAMES = {
            "walk",
            "visit",
            "traverse",
            "search",
            "scan",
            "crawl",
            "descend",
            "recurse",
            "dfs",
            "bfs",
        }
        if any(kw in name_lower for kw in _WALKER_NAMES):
            continue
        # Check for memoization edge
        memo_edge = conn.execute(
            "SELECT 1 FROM edges e "
            "JOIN symbols t ON e.target_id = t.id "
            "WHERE e.source_id = ? "
            "AND t.name IN ('lru_cache', 'cache', 'memoize', 'memo', "
            "               'functools.lru_cache', 'functools.cache') "
            "LIMIT 1",
            (r["id"],),
        ).fetchone()
        if memo_edge:
            continue
        snippet = _read_symbol_source(
            r["file_path"],
            _row_value(r, "line_start", None),
            _row_value(r, "line_end", None),
        )
        if _has_explicit_depth_guard(_row_value(r, "language", ""), snippet):
            continue
        if _has_memo_collection(snippet):
            # M2: function carries its own Set/Map/WeakSet — already memoised.
            continue
        # M1: pin the location at the first self-call line if we can find it,
        # not the function declaration. The detector flagged because
        # self_call_count >= 2; the first occurrence of `name(` (or shorthand
        # `name(`) inside the body is the most informative anchor.
        match_line = _find_first_keyword_line(snippet, (r["name"] + "(",), r["line_start"])
        results.append(
            _finding(
                "branching-recursion",
                "naive-branching",
                r,
                f"Branching recursion ({r['self_call_count']} self-calls) without memoization",
                "high",
                evidence={
                    "self_call_count": r["self_call_count"],
                    "guard_check": "no depth/budget guard found in body, no memo Set/Map detected",
                    "to_suppress": (
                        "add `if (depth > N) return` early-return guard, OR pass a "
                        "Set/Map/WeakSet for memoisation/cycle-tracking, OR add "
                        "`# roam: ignore-math[branching-recursion]` to the function line"
                    ),
                },
                match_line=match_line,
                snippet=snippet,
            )
        )
    return results


def detect_quadratic_string(conn: sqlite3.Connection) -> list[dict]:
    """String concatenation via += inside a loop β€” O(n^2) due to
    immutable string reallocation in Python/Java/Go.
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.str_concat_in_loop "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.str_concat_in_loop = 1"
        ).fetchall()
    except Exception:
        return []

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        results.append(
            _finding(
                "quadratic-string",
                "augment-concat",
                r,
                "String += in loop (O(n^2) due to immutable reallocation)",
                "high",
            )
        )
    return results


def detect_loop_invariant_call(conn: sqlite3.Connection) -> list[dict]:
    """Calls inside loops whose arguments don't reference the loop variable.

    These can be hoisted before the loop to avoid repeated computation.
    Suppresses common intentional per-iteration calls (logging, metrics, etc.).
    """
    try:
        rows = conn.execute(
            "SELECT s.id, s.name, s.qualified_name, s.kind, f.path as file_path, "
            "s.line_start, ms.loop_invariant_calls "
            "FROM symbols s "
            "JOIN files f ON s.file_id = f.id "
            "JOIN math_signals ms ON ms.symbol_id = s.id "
            "WHERE s.kind IN ('function', 'method') "
            "AND ms.loop_invariant_calls IS NOT NULL "
            "AND ms.loop_invariant_calls != '[]'"
        ).fetchall()
    except Exception:
        return []

    # Calls that are intentionally per-iteration (suppress)
    _INTENTIONAL_CALLS = {
        # Logging / output
        "print",
        "log",
        "debug",
        "info",
        "warn",
        "warning",
        "error",
        # Collection mutation
        "append",
        "add",
        "push",
        "extend",
        "write",
        "send",
        "get",
        "values",
        "items",
        "keys",
        "update",
        "pop",
        "remove",
        "insert",
        "setdefault",
        "discard",
        # String methods (inherently per-item)
        "startswith",
        "endswith",
        "replace",
        "format",
        "strip",
        "split",
        "join",
        "lower",
        "upper",
        "lstrip",
        "rstrip",
        "encode",
        "decode",
        "ljust",
        "rjust",
        "center",
        "zfill",
        # Event / tracking
        "emit",
        "track",
        "record",
        "increment",
        "decrement",
        # Iteration helpers / builtins
        "enumerate",
        "zip",
        "range",
        "sorted",
        "reversed",
        "list",
        "dict",
        "set",
        "tuple",
        "len",
        "str",
        "int",
        "float",
        "bool",
        "bytes",
        "type",
        # Math / comparison builtins (per-item reductions)
        "max",
        "min",
        "sum",
        "abs",
        "round",
        "pow",
        "isinstance",
        "issubclass",
        "hasattr",
        "getattr",
        "setattr",
        # File / IO
        "resolve",
        "execute",
        "fetchone",
        "fetchall",
        "read_text",
        "read_bytes",
        "open",
        # Control flow
        "sleep",
        "yield",
    }

    # V3 (2026-05-06) — heavyweight calls that are especially worth
    # hoisting (parsing serialised data is O(n^2) over loop iterations
    # when the input doesn't change). When ANY of these fire, escalate
    # confidence to "high".
    _HEAVYWEIGHT_PARSE_LEAVES = {
        "loads",  # json.loads, yaml.load (sometimes), pickle.loads
        "load",  # yaml.load, pickle.load
        "parse",  # JSON.parse, dateutil.parser.parse
        "parsestring",  # JSON.parseString
        "fromstring",  # ET.fromstring (XML)
        "deserialize",
        "decode",
        "compile",  # re.compile inside loop
    }
    _HEAVYWEIGHT_PARSE_RECEIVERS = {
        "json",
        "yaml",
        "pickle",
        "toml",
        "xml",
        "msgpack",
        "cbor",
        "dateutil",
    }

    results = []
    for r in rows:
        if _is_test_path(r["file_path"]):
            continue
        inv_calls = json.loads(r["loop_invariant_calls"]) if r["loop_invariant_calls"] else []
        # Filter out intentional per-iteration calls
        flagged = []
        heavyweight_hits = []
        for c in inv_calls:
            call_full = (c or "").lower()
            call_leaf = _call_leaf(c).lower()
            if call_full in _INTENTIONAL_CALLS or call_leaf in _INTENTIONAL_CALLS:
                continue
            flagged.append(c)
            # V3 — escalate when the call is a parse/deserialize on a
            # known serialisation receiver (json.loads, JSON.parse, etc.).
            recv = _io_receiver_hint(c)
            if call_leaf in _HEAVYWEIGHT_PARSE_LEAVES and any(h in recv for h in _HEAVYWEIGHT_PARSE_RECEIVERS):
                heavyweight_hits.append(c)
        flagged = _dedupe(flagged)
        if not flagged:
            continue
        confidence = "high" if heavyweight_hits else "medium"
        matched_patterns = ["hoistable call(s) detected"]
        if heavyweight_hits:
            matched_patterns.append(f"heavyweight parse: {', '.join(heavyweight_hits[:2])}")
        results.append(
            _finding(
                "loop-invariant-call",
                "repeated-call",
                r,
                f"Loop-invariant call ({', '.join(flagged[:3])}) can be hoisted before loop"
                + (f" — heavyweight parse ({', '.join(heavyweight_hits[:2])})" if heavyweight_hits else ""),
                confidence,
                matched_patterns=matched_patterns,
            )
        )
    return results


# ---------------------------------------------------------------------------
# Confidence calibration
# ---------------------------------------------------------------------------

_CONFIDENCE_ORDER = ["low", "medium", "high"]

_DETECTOR_METADATA = {
    "sorting": {"precision": "high", "impact": "medium", "tags": ["ordering", "nested-loop"]},
    "search-sorted": {"precision": "low", "impact": "medium", "tags": ["search", "sorted-data"]},
    "membership": {"precision": "medium", "impact": "high", "tags": ["collections", "n2"]},
    "string-concat": {"precision": "medium", "impact": "medium", "tags": ["string", "quadratic"]},
    "unique": {"precision": "medium", "impact": "high", "tags": ["dedup", "n2"]},
    "max-min": {"precision": "medium", "impact": "low", "tags": ["idiom"]},
    "accumulation": {"precision": "medium", "impact": "low", "tags": ["idiom"]},
    "manual-power": {"precision": "high", "impact": "medium", "tags": ["math"]},
    "manual-gcd": {"precision": "high", "impact": "low", "tags": ["math"]},
    "fibonacci": {"precision": "high", "impact": "high", "tags": ["recursion", "exponential"]},
    "nested-lookup": {"precision": "medium", "impact": "high", "tags": ["join", "nxm"]},
    "groupby": {"precision": "medium", "impact": "low", "tags": ["idiom"]},
    "string-reverse": {"precision": "low", "impact": "low", "tags": ["idiom"]},
    "matrix-mult": {"precision": "high", "impact": "high", "tags": ["math", "triple-loop"]},
    "busy-wait": {"precision": "high", "impact": "high", "tags": ["concurrency"]},
    "regex-in-loop": {"precision": "high", "impact": "high", "tags": ["string", "regex"]},
    "io-in-loop": {"precision": "high", "impact": "high", "tags": ["io", "n+1"]},
    "list-prepend": {"precision": "high", "impact": "high", "tags": ["collections", "front-shift"]},
    "sort-to-select": {"precision": "high", "impact": "medium", "tags": ["ordering"]},
    "loop-lookup": {"precision": "high", "impact": "high", "tags": ["collections", "lookup"]},
    "branching-recursion": {"precision": "high", "impact": "high", "tags": ["recursion", "dp"]},
    "quadratic-string": {"precision": "high", "impact": "high", "tags": ["string", "quadratic"]},
    "loop-invariant-call": {"precision": "medium", "impact": "medium", "tags": ["hoisting"]},
}


def _detector_meta(task_id: str) -> dict:
    return _DETECTOR_METADATA.get(
        task_id,
        {"precision": "medium", "impact": "medium", "tags": []},
    )


def _boost_confidence(confidence: str) -> str:
    """Raise confidence by one level."""
    idx = _CONFIDENCE_ORDER.index(confidence) if confidence in _CONFIDENCE_ORDER else 1
    return _CONFIDENCE_ORDER[min(idx + 1, len(_CONFIDENCE_ORDER) - 1)]


def _lower_confidence(confidence: str) -> str:
    """Lower confidence by one level."""
    idx = _CONFIDENCE_ORDER.index(confidence) if confidence in _CONFIDENCE_ORDER else 1
    return _CONFIDENCE_ORDER[max(idx - 1, 0)]


_SIGNAL_COLUMNS = [
    ("has_nested_loops", "nested_loops"),
    ("subscript_in_loops", "subscript_in_loops"),
    ("loop_with_compare", "loop_compare"),
    ("loop_with_accumulator", "loop_accumulator"),
    ("loop_with_multiplication", "loop_multiplication"),
    ("loop_with_modulo", "loop_modulo"),
    ("str_concat_in_loop", "string_concat"),
    ("front_ops_in_loop", "front_ops"),
]

_PROFILE_BALANCED = "balanced"
_PROFILE_STRICT = "strict"
_PROFILE_AGGRESSIVE = "aggressive"
_VALID_PROFILES = {
    _PROFILE_BALANCED,
    _PROFILE_STRICT,
    _PROFILE_AGGRESSIVE,
}


def _chunked(values: list[int], size: int = 500):
    for i in range(0, len(values), size):
        yield values[i : i + size]


def _symbol_context(conn, symbol_ids: list[int]) -> dict[int, dict]:
    """Load calibration + evidence context for findings in bulk."""
    context: dict[int, dict] = {
        sid: {
            "signals": [],
            "loop_depth": 0,
            "loop_bound_small": 0,
            "caller_count": 0,
            "cognitive_complexity": 0.0,
            "cyclomatic_density": 0.0,
            "line_count": 0,
            "complexity_zscore": 0.0,
            "runtime_call_count": 0,
            "runtime_p99_latency_ms": None,
            "runtime_error_rate": 0.0,
            "runtime_otel_db_system": None,
            "runtime_otel_db_operation": None,
            "runtime_otel_db_statement_type": None,
        }
        for sid in symbol_ids
    }
    if not symbol_ids:
        return context

    # Repo-relative complexity baseline (differential scoring signal).
    complexity_mean = 0.0
    complexity_std = 0.0
    try:
        row = conn.execute(
            "SELECT AVG(COALESCE(cognitive_complexity, 0)) AS avg_cc, "
            "AVG(COALESCE(cognitive_complexity, 0) * COALESCE(cognitive_complexity, 0)) AS avg_sq_cc "
            "FROM symbol_metrics"
        ).fetchone()
        if row and row["avg_cc"] is not None:
            complexity_mean = float(row["avg_cc"] or 0.0)
            avg_sq = float(row["avg_sq_cc"] or 0.0)
            variance = max(0.0, avg_sq - (complexity_mean * complexity_mean))
            complexity_std = variance**0.5
    except Exception:
        complexity_mean = 0.0
        complexity_std = 0.0

    # Static AST signals
    for chunk in _chunked(symbol_ids):
        ph = ",".join("?" for _ in chunk)
        rows = conn.execute(
            f"SELECT symbol_id, loop_depth, loop_bound_small, "
            f"has_nested_loops, subscript_in_loops, loop_with_compare, "
            f"loop_with_accumulator, loop_with_multiplication, loop_with_modulo, "
            f"str_concat_in_loop, front_ops_in_loop "
            f"FROM math_signals WHERE symbol_id IN ({ph})",
            chunk,
        ).fetchall()
        for r in rows:
            sid = r["symbol_id"]
            if sid not in context:
                continue
            ctx = context[sid]
            ctx["loop_depth"] = int(r["loop_depth"] or 0)
            ctx["loop_bound_small"] = int(r["loop_bound_small"] or 0)
            signals: list[str] = []
            for col, label in _SIGNAL_COLUMNS:
                if r[col]:
                    signals.append(label)
            ctx["signals"] = signals

    # Complexity metrics
    for chunk in _chunked(symbol_ids):
        ph = ",".join("?" for _ in chunk)
        rows = conn.execute(
            f"SELECT symbol_id, cognitive_complexity, cyclomatic_density, line_count "
            f"FROM symbol_metrics WHERE symbol_id IN ({ph})",
            chunk,
        ).fetchall()
        for r in rows:
            sid = r["symbol_id"]
            if sid not in context:
                continue
            cc = float(r["cognitive_complexity"] or 0.0)
            density = float(r["cyclomatic_density"] or 0.0)
            line_count = int(r["line_count"] or 0)
            ctx = context[sid]
            ctx["cognitive_complexity"] = cc
            ctx["cyclomatic_density"] = density
            ctx["line_count"] = line_count
            if complexity_std > 0:
                ctx["complexity_zscore"] = (cc - complexity_mean) / complexity_std

    # Caller counts
    for chunk in _chunked(symbol_ids):
        ph = ",".join("?" for _ in chunk)
        rows = conn.execute(
            f"SELECT target_id, COUNT(*) AS cnt "
            f"FROM edges WHERE kind = 'call' AND target_id IN ({ph}) "
            f"GROUP BY target_id",
            chunk,
        ).fetchall()
        for r in rows:
            sid = r["target_id"]
            if sid in context:
                context[sid]["caller_count"] = int(r["cnt"] or 0)

    # Runtime traces (optional table for legacy DB compatibility)
    try:
        for chunk in _chunked(symbol_ids):
            ph = ",".join("?" for _ in chunk)
            rows = conn.execute(
                f"SELECT symbol_id, SUM(call_count) AS total_calls, "
                f"MAX(p99_latency_ms) AS p99_ms, MAX(error_rate) AS max_err, "
                f"MAX(otel_db_system) AS db_system, "
                f"MAX(otel_db_operation) AS db_operation, "
                f"MAX(otel_db_statement_type) AS db_statement_type "
                f"FROM runtime_stats "
                f"WHERE symbol_id IN ({ph}) "
                f"GROUP BY symbol_id",
                chunk,
            ).fetchall()
            for r in rows:
                sid = r["symbol_id"]
                if sid not in context:
                    continue
                context[sid]["runtime_call_count"] = int(r["total_calls"] or 0)
                context[sid]["runtime_p99_latency_ms"] = r["p99_ms"]
                context[sid]["runtime_error_rate"] = float(r["max_err"] or 0.0)
                context[sid]["runtime_otel_db_system"] = r["db_system"]
                context[sid]["runtime_otel_db_operation"] = r["db_operation"]
                context[sid]["runtime_otel_db_statement_type"] = r["db_statement_type"]
    except Exception:
        pass

    return context


def _merge_evidence(existing: dict | None, enriched: dict) -> dict:
    if not existing:
        return enriched
    merged = dict(existing)
    for k, v in enriched.items():
        if k not in merged:
            merged[k] = v
            continue
        current = merged[k]
        if isinstance(current, list) and isinstance(v, list):
            merged[k] = _dedupe([*current, *v])
        elif isinstance(current, dict) and isinstance(v, dict):
            tmp = dict(current)
            tmp.update(v)
            merged[k] = tmp
        else:
            merged[k] = v
    return merged


def _build_evidence(context: dict) -> dict:
    evidence = {
        "signal_count": len(context.get("signals", [])),
        "signals": context.get("signals", []),
        "loop_depth": int(context.get("loop_depth", 0) or 0),
        "loop_bound_small": bool(context.get("loop_bound_small", 0)),
        "caller_count": int(context.get("caller_count", 0) or 0),
    }
    cognitive = float(context.get("cognitive_complexity", 0.0) or 0.0)
    density = float(context.get("cyclomatic_density", 0.0) or 0.0)
    line_count = int(context.get("line_count", 0) or 0)
    zscore = float(context.get("complexity_zscore", 0.0) or 0.0)
    if cognitive > 0 or density > 0 or line_count > 0:
        evidence["complexity"] = {
            "cognitive": cognitive,
            "cyclomatic_density": density,
            "line_count": line_count,
            "zscore": round(zscore, 3),
        }
    runtime_calls = int(context.get("runtime_call_count", 0) or 0)
    runtime_p99 = context.get("runtime_p99_latency_ms")
    runtime_error = float(context.get("runtime_error_rate", 0.0) or 0.0)
    runtime_db_system = context.get("runtime_otel_db_system")
    runtime_db_operation = context.get("runtime_otel_db_operation")
    runtime_db_statement_type = context.get("runtime_otel_db_statement_type")
    if runtime_calls > 0 or runtime_p99 is not None:
        evidence["runtime"] = {
            "call_count": runtime_calls,
            "p99_latency_ms": runtime_p99,
            "error_rate": runtime_error,
            "db_system": runtime_db_system,
            "db_operation": runtime_db_operation,
            "db_statement_type": runtime_db_statement_type,
        }
    return evidence


def _build_evidence_path(finding: dict, context: dict) -> list[str]:
    path = [f"Observed pattern: {finding['reason']}"]
    signals = context.get("signals", [])
    if signals:
        path.append(f"Static evidence: {', '.join(signals[:4])}")
    cognitive = float(context.get("cognitive_complexity", 0.0) or 0.0)
    zscore = float(context.get("complexity_zscore", 0.0) or 0.0)
    if cognitive >= 12 or zscore >= 1.0:
        path.append(
            "Complexity pressure: cognitive={:.1f}, zscore={:.2f}".format(
                cognitive,
                zscore,
            )
        )
    runtime_calls = int(context.get("runtime_call_count", 0) or 0)
    runtime_p99 = context.get("runtime_p99_latency_ms")
    runtime_db_system = context.get("runtime_otel_db_system")
    runtime_db_operation = context.get("runtime_otel_db_operation") or context.get("runtime_otel_db_statement_type")
    if runtime_calls > 0:
        if runtime_p99 is not None:
            path.append(f"Runtime impact: {runtime_calls} calls, p99 {runtime_p99:.0f}ms")
        else:
            path.append(f"Runtime impact: {runtime_calls} calls")
        if runtime_db_system or runtime_db_operation:
            path.append(
                "Runtime semantics: db_system={} db_operation={}".format(
                    runtime_db_system or "n/a",
                    runtime_db_operation or "n/a",
                )
            )
    path.append(f"Recommendation: replace `{finding['detected_way']}` with `{finding['suggested_way']}`.")
    return path


def _impact_score(finding: dict, context: dict) -> float:
    """Rank finding urgency using static + runtime evidence."""
    confidence_base = {"high": 60.0, "medium": 35.0, "low": 15.0}
    impact_weight = {"high": 12.0, "medium": 6.0, "low": 2.0}

    score = confidence_base.get(finding.get("confidence", "medium"), 30.0)
    score += impact_weight.get(finding.get("impact", "medium"), 5.0)

    loop_depth = int(context.get("loop_depth", 0) or 0)
    score += min(12.0, loop_depth * 2.0)

    caller_count = int(context.get("caller_count", 0) or 0)
    score += min(10.0, caller_count * 1.5)

    # Differential complexity pressure (relative to repository baseline).
    cognitive = float(context.get("cognitive_complexity", 0.0) or 0.0)
    density = float(context.get("cyclomatic_density", 0.0) or 0.0)
    zscore = float(context.get("complexity_zscore", 0.0) or 0.0)
    if cognitive > 0:
        score += min(7.0, cognitive / 6.0)
    if density > 0:
        score += min(4.0, density * 8.0)
    if zscore > 0:
        score += min(8.0, zscore * 2.5)

    runtime_calls = int(context.get("runtime_call_count", 0) or 0)
    runtime_p99 = context.get("runtime_p99_latency_ms")
    runtime_error = float(context.get("runtime_error_rate", 0.0) or 0.0)
    runtime_db_system = context.get("runtime_otel_db_system")
    runtime_db_operation = (
        context.get("runtime_otel_db_operation") or context.get("runtime_otel_db_statement_type") or ""
    )
    runtime_db_operation = str(runtime_db_operation).upper()
    runtime_multiplier = 0.65
    if runtime_db_system:
        runtime_multiplier = 1.0
        if runtime_db_operation in {"INSERT", "UPDATE", "DELETE", "UPSERT", "MERGE", "REPLACE"}:
            runtime_multiplier = 1.25
        elif runtime_db_operation in {"SELECT", "READ", "QUERY", "GET"}:
            runtime_multiplier = 1.0
        else:
            runtime_multiplier = 0.9
    if runtime_calls:
        score += min(20.0, (len(str(max(1, runtime_calls))) - 1) * 5.0) * runtime_multiplier
    if runtime_p99 is not None:
        latency_mult = 1.1 if runtime_db_system else 0.9
        score += min(15.0, float(runtime_p99) / 40.0) * latency_mult
    if runtime_error > 0:
        score += min(8.0, runtime_error * 100.0)
    if runtime_db_system:
        score += 2.5
    if runtime_db_operation in {"INSERT", "UPDATE", "DELETE", "UPSERT", "MERGE", "REPLACE"}:
        score += 3.5

    if context.get("loop_bound_small", 0):
        score -= 8.0

    return round(max(0.0, score), 2)


def _impact_band(score: float) -> str:
    if score >= 80:
        return "high"
    if score >= 45:
        return "medium"
    return "low"


def _calibrate_finding(finding: dict, context: dict | None) -> dict:
    """Adjust confidence using static and runtime context."""
    ctx = context or {}
    caller_count = int(ctx.get("caller_count", 0) or 0)
    loop_bound_small = bool(ctx.get("loop_bound_small", 0))
    signal_count = len(ctx.get("signals", []))
    runtime_calls = int(ctx.get("runtime_call_count", 0) or 0)
    runtime_p99 = ctx.get("runtime_p99_latency_ms")
    runtime_error = float(ctx.get("runtime_error_rate", 0.0) or 0.0)
    runtime_db_system = ctx.get("runtime_otel_db_system")
    runtime_db_operation = ctx.get("runtime_otel_db_operation") or ctx.get("runtime_otel_db_statement_type") or ""
    runtime_db_operation = str(runtime_db_operation).upper()
    precision = (finding.get("precision") or "medium").lower()
    evidence = finding.get("evidence", {}) if isinstance(finding.get("evidence"), dict) else {}
    ambiguous_io_only = bool(finding.get("task_id") == "io-in-loop" and evidence.get("ambiguous_io_only"))
    caller_threshold = 5
    if precision == "medium":
        caller_threshold = 8
    elif precision == "low":
        caller_threshold = 12

    if (not ambiguous_io_only) and caller_count >= caller_threshold and (precision == "high" or signal_count >= 2):
        finding["confidence"] = _boost_confidence(finding["confidence"])
        finding["reason"] += f" (hot: {caller_count} callers)"
    elif caller_count == 0 and runtime_calls == 0:
        finding["confidence"] = _lower_confidence(finding["confidence"])

    runtime_call_threshold = 1500 if not runtime_db_system else 700
    runtime_hot = (
        runtime_calls >= runtime_call_threshold
        or (runtime_p99 is not None and runtime_p99 >= 300)
        or runtime_error >= 0.02
    )
    if runtime_hot:
        finding["confidence"] = _boost_confidence(finding["confidence"])
        runtime_very_hot = (
            runtime_calls >= 5000 or (runtime_p99 is not None and runtime_p99 >= 800) or runtime_error >= 0.05
        )
        if runtime_very_hot:
            finding["confidence"] = _boost_confidence(finding["confidence"])
        rt_bits = []
        if runtime_calls:
            rt_bits.append(f"{runtime_calls} calls")
        if runtime_p99 is not None:
            rt_bits.append(f"p99 {runtime_p99:.0f}ms")
        if runtime_error > 0:
            rt_bits.append(f"err {runtime_error * 100:.1f}%")
        if runtime_db_system:
            rt_bits.append(
                "db {}{}".format(
                    runtime_db_system,
                    f" {runtime_db_operation}" if runtime_db_operation else "",
                )
            )
        if rt_bits:
            finding["reason"] += f" (runtime: {', '.join(rt_bits)})"

    if loop_bound_small:
        finding["confidence"] = _lower_confidence(finding["confidence"])
        finding["reason"] += " (bounded loop)"

    # M8 — confidence calibration floor.
    # Categories where the FP-fix is heuristic-only (no AST-level proof)
    # cap at 'medium' regardless of caller-count or runtime boost. Real-world
    # calibration on union-web showed "high confidence" branching-recursion
    # was 0/1 true positive; same pattern likely on sort-then-subscript when
    # the result is also iterated.
    _MEDIUM_FLOOR_TASKS = {"branching-recursion", "sort-to-select"}
    if finding.get("task_id") in _MEDIUM_FLOOR_TASKS and finding.get("confidence") == "high":
        # Only floor when there's no strong runtime signal — runtime-hot code
        # earns the high-confidence boost.
        if not runtime_hot:
            finding["confidence"] = "medium"
            evidence_dict = finding.setdefault("evidence", {}) if isinstance(finding.get("evidence"), dict) else {}
            if isinstance(evidence_dict, dict):
                evidence_dict["calibration_floor"] = (
                    "category capped at 'medium' — heuristic-only detection has high FP rate; "
                    "use --confidence high to skip these"
                )

    return finding


def _has_strong_runtime(evidence: dict) -> bool:
    runtime = evidence.get("runtime") if isinstance(evidence, dict) else None
    if not isinstance(runtime, dict):
        return False
    calls = int(runtime.get("call_count", 0) or 0)
    p99 = runtime.get("p99_latency_ms")
    return calls >= 200 or (p99 is not None and p99 >= 200)


def _apply_profile(findings: list[dict], profile: str) -> list[dict]:
    if profile == _PROFILE_AGGRESSIVE:
        for f in findings:
            evidence = f.get("evidence", {})
            if f.get("confidence") == "low" and (
                int(evidence.get("signal_count", 0) or 0) >= 2 or _has_strong_runtime(evidence)
            ):
                f["confidence"] = "medium"
        return findings

    if profile == _PROFILE_STRICT:
        strict_findings: list[dict] = []
        for f in findings:
            if f.get("confidence") == "low":
                continue
            precision = (f.get("precision") or "medium").lower()
            evidence = f.get("evidence", {})
            runtime_strong = _has_strong_runtime(evidence)
            if precision == "low" and not runtime_strong and f.get("confidence") != "high":
                continue
            if f.get("confidence") == "high":
                strict_findings.append(f)
                continue
            if int(evidence.get("signal_count", 0) or 0) >= 2 or runtime_strong:
                strict_findings.append(f)
        return strict_findings

    return findings


# ---------------------------------------------------------------------------
# Detector registry
# ---------------------------------------------------------------------------

_MATH_DETECTORS = [
    ("sorting", "manual-sort", detect_manual_sort),
    ("search-sorted", "linear-scan", detect_linear_search),
    ("membership", "list-scan", detect_list_membership),
    ("string-concat", "loop-concat", detect_string_concat_loop),
    ("unique", "nested-dedup", detect_manual_dedup),
    ("max-min", "manual-loop", detect_manual_maxmin),
    ("accumulation", "manual-sum", detect_manual_accumulation),
    ("manual-power", "loop-multiply", detect_manual_power),
    ("manual-gcd", "manual-gcd", detect_manual_gcd),
    ("fibonacci", "naive-recursive", detect_naive_fibonacci),
    ("nested-lookup", "nested-iteration", detect_nested_lookup),
    ("groupby", "manual-check", detect_manual_groupby),
    ("string-reverse", "manual-reverse", detect_string_reverse),
    ("matrix-mult", "naive-triple", detect_matrix_mult),
    ("busy-wait", "sleep-loop", detect_busy_wait),
    ("regex-in-loop", "compile-per-iter", detect_regex_in_loop),
    ("io-in-loop", "loop-query", detect_io_in_loop),
    ("serial-await-loop", "for-of-await", detect_serial_await_loop),
    ("async-blocking-sleep", "blocking-call-in-async", detect_async_blocking_sleep),
    ("async-fire-and-forget-task", "leaked-asyncio-task", detect_async_fire_and_forget),
    ("async-nested-run", "asyncio-run-in-async", detect_async_nested_run),
    ("broad-except-swallow", "swallow-exception", detect_broad_except_swallow),
    ("spread-accumulator", "spread-rebind", detect_spread_accumulator),
    ("defer-in-loop", "loop-defer", detect_defer_in_loop),
    ("chained-collection-walk", "two-pass-walk", detect_chained_collection_walks),
    ("useeffect-missing-deps", "no-deps-array", detect_useeffect_missing_deps),
    ("dangerous-eval", "eval-or-exec", detect_dangerous_eval),
    ("unremoved-event-listener", "no-cleanup", detect_unremoved_event_listener),
    ("list-prepend", "insert-front", detect_list_prepend),
    ("sort-to-select", "full-sort", detect_sort_to_select),
    ("loop-lookup", "method-scan", detect_loop_lookup),
    ("branching-recursion", "naive-branching", detect_branching_recursion),
    ("quadratic-string", "augment-concat", detect_quadratic_string),
    ("loop-invariant-call", "repeated-call", detect_loop_invariant_call),
]


def _iter_registered_detectors():
    """Yield built-in detectors plus plugin-contributed detectors."""
    for det in _MATH_DETECTORS:
        yield det

    # Python pivot v12.4 β€” language-specific idiom detectors. Wrapped
    # in try/except so a regex bug in one detector can't block the
    # algorithm pass.
    try:
        from roam.catalog.python_idioms import PYTHON_IDIOM_DETECTORS

        for det in PYTHON_IDIOM_DETECTORS:
            yield det
    except Exception:
        pass

    try:
        from roam.plugins import get_plugin_detectors

        for task_id, way_id, detect_fn in get_plugin_detectors():
            if callable(detect_fn):
                yield (task_id, way_id, detect_fn)
    except Exception:
        # Plugin loading errors should not impact built-in detection.
        return


def run_detectors(
    conn,
    task_filter=None,
    confidence_filter=None,
    *,
    profile="balanced",
    return_meta=False,
    framework=None,
    include_tests=False,
):
    """Run all detectors and return combined findings.

    Parameters
    ----------
    conn : sqlite3.Connection
    task_filter : str or None
        If set, only run the detector for this task_id.
    confidence_filter : str or None
        If set, keep only findings with this confidence level.
    profile : str
        Precision profile: ``balanced`` (default), ``strict``, ``aggressive``.
    return_meta : bool
        When True, returns ``(findings, meta)`` where ``meta`` contains
        detector execution diagnostics (totals + failures).
    framework : str or None
        D3 — opt-in framework profile name (e.g. ``vue3-tanstack``,
        ``laravel-multitenant``). Layers extra cache-allowlist entries on
        top of the defaults for the duration of this call. Unknown names
        are tolerated (defaults apply, and ``meta['framework_unknown']``
        flags the miss).

    Returns list of finding dicts, or ``(findings, meta)`` when
    ``return_meta=True``.
    """
    global _ACTIVE_FRAMEWORK_PROFILE, _INCLUDE_TESTS_OVERRIDE
    # S2/S3/S4 (2026-05-06) — caches scoped to a single `run_detectors`
    # invocation. Without this reset, fixture tests that rewrite the
    # same path between runs would see stale content.
    _FILE_LINES_CACHE.clear()
    _IN_MEMORY_CALL_CACHE.clear()
    _FRAMEWORK_PACK_CACHE.clear()
    # X14 — toggle test-path inclusion for the duration of this call.
    previous_include_tests = _INCLUDE_TESTS_OVERRIDE
    _INCLUDE_TESTS_OVERRIDE = bool(include_tests)
    framework_unknown: str | None = None
    previous_profile = _ACTIVE_FRAMEWORK_PROFILE
    framework_active: str | None = None
    if framework:
        resolved = set_active_framework_profile(framework)
        if resolved is None:
            framework_unknown = framework
            set_active_framework_profile(None)
        else:
            framework_active = framework.lower()
    try:
        findings = []
        failed_detectors = []
        executed = 0
        executed_tasks: list[str] = []
        for task_id, _way_id, detect_fn in _iter_registered_detectors():
            if task_filter and task_id != task_filter:
                continue
            executed += 1
            executed_tasks.append(task_id)
            try:
                hits = detect_fn(conn)
            except Exception as exc:
                failed_detectors.append(
                    {
                        "task_id": task_id,
                        "detector": detect_fn.__name__,
                        "error": str(exc),
                    }
                )
                continue
            dmeta = _detector_meta(task_id)
            for h in hits:
                h.setdefault("precision", dmeta["precision"])
                h.setdefault("impact", dmeta["impact"])
                h.setdefault("tags", list(dmeta["tags"]))
            findings.extend(hits)

        profile_key = (profile or _PROFILE_BALANCED).lower()
        if profile_key not in _VALID_PROFILES:
            profile_key = _PROFILE_BALANCED

        symbol_ids = _dedupe([f["symbol_id"] for f in findings if f.get("symbol_id")])
        context_map = _symbol_context(conn, symbol_ids)

        # Apply calibration and enrich findings with semantic evidence.
        for f in findings:
            ctx = context_map.get(f["symbol_id"], {})
            _calibrate_finding(f, ctx)
            enriched_evidence = _build_evidence(ctx)
            f["evidence"] = _merge_evidence(f.get("evidence"), enriched_evidence)
            f["evidence_path"] = _build_evidence_path(f, ctx)
            score = _impact_score(f, ctx)
            f["impact_score"] = score
            f["impact_band"] = _impact_band(score)

        pre_profile_count = len(findings)
        findings = _apply_profile(findings, profile_key)
        profile_filtered = pre_profile_count - len(findings)

        if confidence_filter:
            findings = [f for f in findings if f["confidence"] == confidence_filter]

        if return_meta:
            meta = {
                "detectors_executed": executed,
                "detectors_failed": len(failed_detectors),
                "failed_detectors": failed_detectors,
                "profile": profile_key,
                "profile_filtered": profile_filtered,
                "detector_metadata": {task_id: _detector_meta(task_id) for task_id in executed_tasks},
                "framework": framework_active,
                "framework_unknown": framework_unknown,
            }
            return findings, meta

        return findings
    finally:
        # Always restore the prior active profile so a single run can't leak
        # into subsequent invocations or other commands sharing the process.
        _ACTIVE_FRAMEWORK_PROFILE = previous_profile
        _INCLUDE_TESTS_OVERRIDE = previous_include_tests
