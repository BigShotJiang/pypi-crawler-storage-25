"""Kiwi CLI - command-line interface and shared infrastructure modules."""

__version__ = "0.1.0"
