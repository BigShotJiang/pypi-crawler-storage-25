"""Pydantic models for Autobots TUI."""

from datetime import datetime, timedelta
from enum import Enum
from typing import Optional, Any
from pydantic import BaseModel, Field


class ActionStatus(str, Enum):
    """Status of an action execution."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AutobotType(str, Enum):
    """Type of autobot."""
    CHAT = "chat"
    SEARCH = "search"
    AUTOMATION = "automation"
    ANALYSIS = "analysis"


class Autobot(BaseModel):
    """Represents an autobot instance."""
    id: str
    name: str
    type: AutobotType
    description: str
    enabled: bool = True
    created_at: datetime = Field(default_factory=datetime.now)
    last_run: Optional[datetime] = None
    run_count: int = 0


class Action(BaseModel):
    """Represents an action that can be executed."""
    id: str
    name: str
    description: str
    autobot_id: str
    parameters: dict[str, Any] = Field(default_factory=dict)


class ActionExecution(BaseModel):
    """Represents an action execution instance."""
    id: str
    action_id: str
    status: ActionStatus
    started_at: datetime = Field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    result: Optional[dict[str, Any]] = None
    error: Optional[str] = None


class AuthTokens(BaseModel):
    """Authentication tokens."""
    access_token: str
    refresh_token: str
    token_type: str = "Bearer"
    expires_at: Optional[datetime] = None

    def is_expired(self) -> bool:
        """Check if access token is expired."""
        if not self.expires_at:
            return False
        # Add 60 second buffer before expiry
        return datetime.now() >= (self.expires_at - timedelta(seconds=60))


class LoginCredentials(BaseModel):
    """Login credentials."""
    username: str
    password: str


class AppConfig(BaseModel):
    """Application configuration."""
    backend_url: str = "https://api.meetkiwi.ai"
    api_key: Optional[str] = None
    log_level: str = "INFO"
    theme: str = "dark"
    refresh_interval: int = 5
