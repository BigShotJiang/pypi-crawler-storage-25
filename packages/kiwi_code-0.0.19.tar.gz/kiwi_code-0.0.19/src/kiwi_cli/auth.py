"""Authentication and token management."""

import json
import sys
from pathlib import Path
from typing import Optional
from loguru import logger

from .models import AuthTokens


class TokenManager:
    """Manages authentication tokens with secure storage."""

    def __init__(self, token_path: Optional[Path] = None):
        """Initialize token manager.

        Args:
            token_path: Path to token file, defaults to ~/.kiwi/tokens.json
        """
        if token_path is None:
            token_path = Path.home() / ".kiwi" / "tokens.json"

        self.token_path = token_path
        self._tokens: Optional[AuthTokens] = None

    def save_tokens(self, tokens: AuthTokens) -> None:
        """Save tokens to secure storage.

        Args:
            tokens: Authentication tokens to save
        """
        self._tokens = tokens
        self.token_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            with open(self.token_path, "w") as f:
                json.dump(tokens.model_dump(mode="json"), f, indent=2, default=str)

            # Set file permissions to user read/write only (0600)
            if sys.platform != "win32":
                self.token_path.chmod(0o600)

            logger.info("Authentication tokens saved securely")
        except Exception as e:
            logger.error(f"Failed to save tokens: {e}")
            raise

    def load_tokens(self) -> Optional[AuthTokens]:
        """Load tokens from storage.

        Returns:
            AuthTokens if found and valid, None otherwise
        """
        if not self.token_path.exists():
            logger.debug("No saved tokens found")
            return None

        try:
            with open(self.token_path, "r") as f:
                data = json.load(f)

            self._tokens = AuthTokens(**data)
            logger.info("Authentication tokens loaded")
            return self._tokens
        except Exception as e:
            logger.error(f"Failed to load tokens: {e}")
            return None

    def clear_tokens(self) -> None:
        """Clear stored tokens."""
        self._tokens = None

        if self.token_path.exists():
            try:
                self.token_path.unlink()
                logger.info("Authentication tokens cleared")
            except Exception as e:
                logger.error(f"Failed to clear tokens: {e}")

    @property
    def tokens(self) -> Optional[AuthTokens]:
        """Get current tokens.

        Returns:
            Current AuthTokens or None
        """
        if self._tokens is None:
            self._tokens = self.load_tokens()
        return self._tokens

    def is_authenticated(self) -> bool:
        """Check if user is authenticated with valid tokens.

        Returns:
            True if authenticated with non-expired tokens
        """
        tokens = self.tokens
        if not tokens:
            return False

        # Check if token is expired
        if tokens.is_expired():
            logger.warning("Access token is expired")
            return False

        return True

    def get_access_token(self) -> Optional[str]:
        """Get the current access token.

        Returns:
            Access token string or None
        """
        tokens = self.tokens
        if tokens and not tokens.is_expired():
            return tokens.access_token
        return None

    def get_refresh_token(self) -> Optional[str]:
        """Get the current refresh token.

        Returns:
            Refresh token string or None
        """
        tokens = self.tokens
        return tokens.refresh_token if tokens else None
