"""Allow running as: python -m kiwi_runtime"""

from .main import main

main()
