"""Autobots TUI - A textual-based terminal user interface."""

__version__ = "0.1.0"
