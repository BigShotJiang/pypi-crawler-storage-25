"""File browser modal screen for selecting files to upload."""

import os
from pathlib import Path

from textual.app import ComposeResult
from textual.screen import ModalScreen
from textual.widgets import Header, Footer, Static, Button, DirectoryTree, Input
from textual.containers import Vertical, Horizontal, VerticalScroll
from textual.binding import Binding


class FileBrowserScreen(ModalScreen[list[str]]):
    """Modal screen with a DirectoryTree for browsing and selecting files to upload.

    Returns a list of selected file paths (as strings) when dismissed,
    or an empty list if cancelled.
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=True),
    ]

    CSS = """
    FileBrowserScreen {
        align: center middle;
    }

    #file-browser-container {
        width: 96%;
        height: 95%;
        background: $surface;
        border: solid $accent;
        padding: 0 1;
    }

    #browser-title {
        width: 100%;
        text-align: center;
        text-style: bold;
        color: $primary;
        height: 1;
    }

    #nav-row {
        height: 3;
        width: 100%;
    }

    #path-input {
        width: 1fr;
        border: solid $accent;
    }

    #path-input:focus {
        border: solid $primary;
    }

    #go-home-btn, #go-up-btn {
        width: 5;
        min-width: 5;
        height: 3;
        margin: 0 0 0 1;
        background: $boost;
        color: $primary;
        border: solid $accent;
    }

    #go-home-btn:hover, #go-up-btn:hover {
        background: $accent;
    }

    #dir-tree {
        height: 1fr;
        width: 100%;
        border: solid $panel;
        scrollbar-size: 1 1;
    }

    #selected-files {
        height: auto;
        max-height: 3;
        width: 100%;
        padding: 0 1;
        color: $secondary;
    }

    #browser-buttons {
        height: 4;
        width: 100%;
        align: right middle;
        padding: 0 0 1 0;
    }

    #upload-selected-btn {
        margin: 0 1 0 0;
        background: $boost;
        color: $primary;
        border: solid $accent;
    }

    #upload-selected-btn:hover {
        background: $accent;
    }

    #cancel-btn {
        background: $surface;
        color: $text;
        border: solid $panel;
    }

    #cancel-btn:hover {
        background: $panel;
    }
    """

    def __init__(self, start_path: str | None = None, **kwargs):
        super().__init__(**kwargs)
        self._start_path = start_path or os.getcwd()
        self._selected_files: list[str] = []

    def compose(self) -> ComposeResult:
        with Vertical(id="file-browser-container"):
            yield Static("Select files to upload", id="browser-title")
            with Horizontal(id="nav-row"):
                yield Input(self._start_path, id="path-input", placeholder="Enter path...")
                yield Button("..", id="go-up-btn", variant="default")
                yield Button("~", id="go-home-btn", variant="default")
            yield DirectoryTree(self._start_path, id="dir-tree")
            yield Static("", id="selected-files")
            with Horizontal(id="browser-buttons"):
                yield Button("Upload", id="upload-selected-btn", variant="primary")
                yield Button("Cancel", id="cancel-btn", variant="default")

    def _navigate_to(self, path_str: str) -> None:
        """Change the directory tree root to a new path."""
        target = Path(path_str).expanduser().resolve()
        if not target.is_dir():
            return
        tree = self.query_one("#dir-tree", DirectoryTree)
        tree.path = target
        tree.reload()
        self.query_one("#path-input", Input).value = str(target)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Navigate to the path typed in the input."""
        if event.input.id == "path-input":
            self._navigate_to(event.value.strip())
            self.query_one("#dir-tree", DirectoryTree).focus()

    def on_directory_tree_file_selected(self, event: DirectoryTree.FileSelected) -> None:
        """Toggle file selection when a file is clicked."""
        path_str = str(event.path)
        if path_str in self._selected_files:
            self._selected_files.remove(path_str)
        else:
            self._selected_files.append(path_str)
        self._update_selected_display()

    def _update_selected_display(self) -> None:
        """Update the selected files display."""
        bar = self.query_one("#selected-files", Static)
        if self._selected_files:
            names = [Path(p).name for p in self._selected_files]
            bar.update(f"Selected ({len(names)}): {', '.join(names)}")
        else:
            bar.update("")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "upload-selected-btn":
            self.dismiss(self._selected_files)
        elif btn_id == "cancel-btn":
            self.dismiss([])
        elif btn_id == "go-up-btn":
            tree = self.query_one("#dir-tree", DirectoryTree)
            self._navigate_to(str(Path(tree.path).parent))
        elif btn_id == "go-home-btn":
            self._navigate_to(str(Path.home()))

    def action_cancel(self) -> None:
        self.dismiss([])
