"""Login screen for Autobots TUI."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Center, Horizontal
from textual.widgets import Header, Footer, Static, Input, Button
from textual.validation import Length
from textual.message import Message
from loguru import logger

from pathlib import Path

from kiwi_cli.models import LoginCredentials
from kiwi_tui.runtime_agent import server_from_backend_url
from kiwi_tui.widgets import ActionButton


class LoginScreen(Screen):
    """Screen for user authentication."""

    AUTO_FOCUS = None  # Prevent automatic focus changes

    CSS = """
    LoginScreen {
        background: $surface;
        layout: vertical;
    }

    #login-container {
        width: 100%;
        height: 1fr;
        min-height: 20;
        border: none;
        background: transparent;
        padding: 4 8;
        overflow-y: auto;
    }

    #logo-container {
        width: 100%;
        height: auto;
        margin-bottom: 2;
        content-align: left top;
    }

    #logo {
        /* Brand color — intentionally hardcoded so the logo stays
           consistent regardless of the active Textual theme. */
        color: $brand-cyan;
        width: auto;
    }


    .divider {
        width: 100%;
        height: 1;
        border-bottom: solid $panel;
        margin-bottom: 2;
    }

    .info-row {
        height: auto;
        margin-bottom: 0;
    }

    /* Brand-color labels — hardcoded so the login screen's blue accents
       stay on-brand regardless of the active Textual theme. */
    .info-label {
        color: $brand-cyan;
        width: auto;
        margin-right: 1;
    }

    .info-value {
        color: $text;
    }

    .section-header {
        color: $brand-cyan;
        text-style: bold;
        margin-top: 2;
        margin-bottom: 1;
        border-bottom: solid $panel;
        width: 40;
    }

    .input-prompt {
        color: $brand-cyan;
        width: auto;
        margin-right: 1;
    }

    .form-group {
        layout: horizontal;
        height: 1;
        margin: 0;
    }

    Input {
        width: 40;
        background: transparent;
        border: none;
        padding: 0;
        height: 1;
        color: $text;
    }

    Input:focus {
        border: none;
    }

    #status-message {
        margin-top: 1;
        height: auto;
    }

    #status-message.-loading {
        color: $primary;
    }

    #status-message.-success {
        color: $success;
    }

    #status-message.-error {
        color: $error;
    }

    .status-line {
        height: auto;
    }

    .status-symbol-success {
        color: $success;
        margin-right: 1;
    }

    .status-symbol-pending {
        color: $primary;
        margin-right: 1;
    }

    .status-symbol-error {
        color: $error;
        margin-right: 1;
    }

    #button-container {
        display: none; /* Hide button to match sleek look */
    }
    """

    BINDINGS = [
        ("escape", "quit", "Quit"),
        ("ctrl+c", "quit", "Quit"),
    ]

    def compose(self) -> ComposeResult:
        """Compose login screen widgets."""
        yield Header(icon="❊")

        with Container(id="login-container"):
            # Logo Section
            with Vertical(id="logo-container"):
                logo_lines = [
                    "              ▄██▄              ",
                    "              ████              ",
                    "    ▄██▄▄     ████     ▄▄██▄    ",
                    "    ▀█████▄   █▀▀█   ▄█████▀   ",
                    "     ▀███▀▀█  ████  █▀▀███▀    ",
                    "       ▀█▄  █ ████ █  ▄█▀      ",
                    "          ▀▀▄██████▄▀▀         ",
                    "▄██████▀▀█▄██████████▄█▀▀██████▄",
                    "▀██████▄▄█▀██████████▀█▄▄██████▀",
                    "          ▄▄▀██████▀▄▄         ",
                    "       ▄█▀  █ ████ █  ▀█▄      ",
                    "     ▄███▄▄█  ████  █▄▄███▄    ",
                    "    ▄█████▀   █▄▄█   ▀█████▄   ",
                    "    ▀██▀▀     ████     ▀▀██▀   ",
                    "              ████              ",
                    "              ▀██▀              ",
                ]
                text_lines = [
                    "██╗  ██╗██╗██╗    ██╗██╗     █████╗ ██╗",
                    "██║ ██╔╝██║██║    ██║██║    ██╔══██╗██║",
                    "█████╔╝ ██║██║ █╗ ██║██║    ███████║██║",
                    "██╔═██╗ ██║██║███╗██║██║    ██╔══██║██║",
                    "██║  ██╗██║╚███╔███╔╝██║    ██║  ██║██║",
                    "╚═╝  ╚═╝╚═╝ ╚══╝╚══╝ ╚═╝    ╚═╝  ╚═╝╚═╝",
                ]
                tagline = "Think fast. Code smarter. Automate everything."
                gap = "  "
                logo_w = 33
                text_start = 5
                banner_rows = []
                for i, logo_line in enumerate(logo_lines):
                    padded_logo = logo_line.ljust(logo_w)
                    text_idx = i - text_start
                    if 0 <= text_idx < len(text_lines):
                        row = f"{padded_logo}{gap}{text_lines[text_idx]}"
                    elif text_idx == len(text_lines) + 1:
                        row = f"{padded_logo}{gap}{tagline}"
                    else:
                        row = padded_logo
                    banner_rows.append(row)
                yield Static("\n".join(banner_rows), id="logo")

            yield Static("", classes="divider")

            # Environment Info
            runtime_server = self.app.runtime_args.server or server_from_backend_url(self.app.config.backend_url)
            with Horizontal(classes="info-row"):
                yield Static("> Server:", classes="info-label")
                yield Static(f"{runtime_server} ({self.app.config.backend_url})", classes="info-value")
            
            with Horizontal(classes="info-row"):
                yield Static("> Mode:", classes="info-label")
                yield Static(getattr(self.app.runtime_args, "scope", "restricted"), classes="info-value")

            cwd = Path.cwd()
            try:
                display_path = "~" / cwd.relative_to(Path.home())
            except ValueError:
                display_path = cwd
            with Horizontal(classes="info-row"):
                yield Static("> Working Dir:", classes="info-label")
                yield Static(str(display_path), classes="info-value")

            yield Static("Authentication", classes="section-header")

            with Horizontal(classes="form-group"):
                yield Static("> Email:", classes="input-prompt")
                yield Input(
                    placeholder="email@example.com",
                    id="username-input",
                )

            with Horizontal(classes="form-group"):
                yield Static("> Password:", classes="input-prompt")
                yield Input(
                    placeholder="••••••••",
                    password=True,
                    id="password-input",
                )

            yield Static("", id="status-message")

            with Center(id="button-container"):
                yield ActionButton("Sign In", variant="success", id="btn-login")

        yield Footer()

    def on_mount(self) -> None:
        """Called when screen is mounted."""
        logger.info("Login screen mounted")
        # Focus on username input after a brief delay to ensure DOM is ready
        try:
            username_input = self.query_one("#username-input", Input)
            self.set_timer(0.1, lambda: username_input.focus())
        except Exception as e:
            logger.error(f"Error focusing username input: {e}")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "btn-login":
            self.action_login()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission (Enter key)."""
        if event.input.id == "username-input":
            # Move to password field
            self.query_one("#password-input", Input).focus()
        elif event.input.id == "password-input":
            # Submit login
            self.action_login()

    def _set_status(self, status_widget: Static, text: str, state: str) -> None:
        """Update the status widget text and swap its state class.

        state: one of "loading", "success", "error".
        """
        for cls in ("-loading", "-success", "-error"):
            status_widget.remove_class(cls)
        status_widget.add_class(f"-{state}")
        status_widget.update(text)

    def action_login(self) -> None:
        """Attempt to login with provided credentials."""
        username_input = self.query_one("#username-input", Input)
        password_input = self.query_one("#password-input", Input)
        status_widget = self.query_one("#status-message", Static)

        username = username_input.value.strip()
        password = password_input.value

        # Validate inputs
        if not username:
            self._set_status(status_widget, "~ Please enter your email", "error")
            username_input.focus()
            return

        if not password:
            self._set_status(status_widget, "~ Please enter your password", "error")
            password_input.focus()
            return

        # Show loading state
        self._set_status(
            status_widget,
            f"~ Authenticating with {self.app.config.backend_url}...",
            "loading",
        )

        logger.info(f"Login attempt for user: {username}")

        # Create credentials
        credentials = LoginCredentials(username=username, password=password)

        # Call login through app
        if hasattr(self.app, 'autobots_client'):
            success, tokens, message = self.app.autobots_client.login(credentials)

            if success and tokens:
                self._set_status(status_widget, "> Login successful!", "success")
                logger.info(f"Login successful for user: {username}")

                # Save tokens
                if hasattr(self.app, 'token_manager'):
                    self.app.token_manager.save_tokens(tokens)

                # Share token with kiwi CLI session
                self.app._kiwi_token = tokens.access_token
                self.app._start_token_refresh()

                # Notify app of successful login
                self.app.post_message(LoginSuccess(tokens))

                # Switch to dashboard
                self.app.switch_screen("dashboard")
            else:
                self._set_status(status_widget, f"~ {message}", "error")
                logger.error(f"Login failed for user {username}: {message}")
                password_input.value = ""
                password_input.focus()
        else:
            self._set_status(status_widget, "~ Client not initialized", "error")
            logger.error("Autobots client not found in app")

    def action_quit(self) -> None:
        """Quit the application."""
        logger.info("Quitting application from login screen")
        try:
            self.app.request_quit()
        except Exception:
            self.app.exit()


class LoginSuccess(Message):
    """Message sent when login is successful."""

    bubbles = True

    def __init__(self, tokens):
        """Initialize login success message.

        Args:
            tokens: Authentication tokens
        """
        super().__init__()
        self.tokens = tokens
