"""Runtime logs screen.

Shows the stdout/stderr of a local ``kiwi-runtime connect`` process.

The runtime is launched by kiwi-code and its logs are written to a file under
``~/.kiwi/runtimes``.
"""

from __future__ import annotations

from pathlib import Path

from loguru import logger
from rich.text import Text
from textual.binding import Binding
from textual.screen import Screen
from textual.widgets import Footer, Header, RichLog, Static


def _tail_lines(path: Path, max_lines: int = 3000) -> list[str]:
    """Read the last N lines of a file without loading the whole file."""
    try:
        data = path.read_bytes()
    except OSError:
        return []
    lines = data.splitlines()[-max_lines:]
    out: list[str] = []
    for b in lines:
        try:
            out.append(b.decode("utf-8", errors="replace"))
        except Exception:
            out.append(str(b))
    return out


class RuntimeLogsScreen(Screen):
    """Viewer for a kiwi-runtime log file."""

    BINDINGS = [
        Binding("escape", "go_back", "Back", show=True),
    ]

    CSS = """
    RuntimeLogsScreen {
        background: $background;
    }

    #runtime-log {
        height: 1fr;
        width: 100%;
        scrollbar-size: 1 1;
    }

    #runtime-log-missing {
        padding: 2 4;
        color: $error;
    }
    """

    def __init__(self, log_path: str | Path | None, title: str = "CLI logs") -> None:
        super().__init__()
        self._title = title
        self._log_path: Path | None = Path(log_path) if log_path else None
        self._fp = None

    def compose(self):
        yield Header(icon="❊")

        if not self._log_path:
            yield Static(
                "No runtime log available for this context.\n\n"
                "Use /connect-cli to start a runtime.",
                id="runtime-log-missing",
            )
        elif not self._log_path.exists():
            yield Static(
                f"Runtime log file not found:\n{self._log_path}",
                id="runtime-log-missing",
            )
        else:
            yield RichLog(id="runtime-log", wrap=True, markup=False)

        yield Footer()

    def on_mount(self) -> None:
        if not self._log_path or not self._log_path.exists():
            return

        try:
            log = self.query_one("#runtime-log", RichLog)
        except Exception:
            return

        for line in _tail_lines(self._log_path, max_lines=2000):
            log.write(Text.from_ansi(line))

        try:
            self._fp = open(self._log_path, "r", encoding="utf-8", errors="replace")
            self._fp.seek(0, 2)
        except OSError as e:
            logger.warning(f"Could not open runtime log for streaming: {e}")
            return

        self.set_interval(0.25, self._poll)

    def action_go_back(self) -> None:
        try:
            if self._fp:
                self._fp.close()
        except Exception:
            pass
        self._fp = None
        self.app.pop_screen()

    def _poll(self) -> None:
        if not self._fp:
            return
        try:
            chunk = self._fp.read()
        except Exception:
            return
        if not chunk:
            return

        try:
            log = self.query_one("#runtime-log", RichLog)
        except Exception:
            return

        for line in chunk.splitlines():
            log.write(Text.from_ansi(line))
