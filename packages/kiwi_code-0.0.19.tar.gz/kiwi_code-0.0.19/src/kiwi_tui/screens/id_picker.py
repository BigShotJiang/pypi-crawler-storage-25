"""Generic modal picker for selecting an item by ID.

Used for slash-command list views (e.g. /actions list, /runs list) so the
list UI is separate from the main chat timeline.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import OptionList, Static
from textual.widgets.option_list import Option


class IdPickerScreen(ModalScreen[str]):
    """Modal that lets the user pick an item (returns its ID).

    - Returns the selected ID.
    - Returns an empty string if cancelled.
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=True),
    ]

    CSS = """
    IdPickerScreen {
        align: center middle;
    }

    #idpicker-container {
        width: 90;
        height: 80%;
        background: $surface;
        border: solid $accent;
        padding: 1 2;
    }

    #idpicker-title {
        width: 100%;
        text-align: center;
        text-style: bold;
        color: $primary;
        height: auto;
        margin-bottom: 1;
    }

    #idpicker-list {
        height: 1fr;
        width: 100%;
        border: solid $panel;
    }
    """

    def __init__(self, title: str, options: list[tuple[str, str]]):
        super().__init__()
        self._title = title
        self._options = options

    def compose(self) -> ComposeResult:
        with Vertical(id="idpicker-container"):
            yield Static(self._title, id="idpicker-title")
            option_list = OptionList(id="idpicker-list")
            for item_id, label in self._options:
                # Option.id is independent of widget IDs; it only needs to be unique in this list.
                option_list.add_option(Option(label, id=item_id))
            yield option_list

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        self.dismiss(event.option.id or "")

    def action_cancel(self) -> None:
        self.dismiss("")
