"""Exit-time runtime cleanup prompt.

When the user quits Kiwi Code, we optionally offer to terminate any local
``kiwi-runtime`` processes that are still running.

Runtimes are tracked on disk by kiwi-code under ``~/.kiwi/runtimes``.

Implementation note:
Textual's DataTable can consume common keys (notably Space) in some terminals,
which made toggling unreliable in practice. This screen uses OptionList
instead, which has much more predictable keyboard behavior.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
import json
from typing import Any

from loguru import logger
from textual import events
from textual.binding import Binding
from textual.screen import ModalScreen
from textual.widgets import Footer, Header, OptionList, Static
from textual.widgets.option_list import Option

from kiwi_tui.runtime_agent import meta_path_for_run


@dataclass
class RuntimeRow:
    kind: str
    runtime_id: str
    pid: int
    alive: bool
    log_path: str
    name: str | None = None
    kill: bool = False


class RuntimeCleanupList(OptionList):
    """OptionList with explicit key handling so toggling always works."""

    BINDINGS = [
        Binding("escape", "cancel_exit", "Exit (keep all)", show=True),
        Binding("ctrl+c", "cancel_exit", "Exit (keep all)", show=False),
        Binding("enter", "confirm_exit", "Confirm & exit", show=True),
        Binding("ctrl+s", "confirm_exit", "Confirm & exit", show=False),
        Binding("space", "toggle_kill", "Toggle kill", show=True),
        Binding("t", "toggle_kill", "Toggle kill", show=False),
        Binding("y", "mark_kill", "Mark kill", show=False),
        Binding("n", "unmark_kill", "Unmark kill", show=False),
    ]

    def _cleanup_screen(self) -> "RuntimeCleanupScreen | None":
        try:
            screen = self.app.screen
            if isinstance(screen, RuntimeCleanupScreen):
                return screen
        except Exception:
            pass
        return None

    def action_toggle_kill(self) -> None:
        screen = self._cleanup_screen()
        if screen:
            screen.action_toggle()

    def action_mark_kill(self) -> None:
        screen = self._cleanup_screen()
        if screen:
            screen.action_yes()

    def action_unmark_kill(self) -> None:
        screen = self._cleanup_screen()
        if screen:
            screen.action_no()

    def action_confirm_exit(self) -> None:
        screen = self._cleanup_screen()
        if screen:
            screen.action_confirm()

    def action_cancel_exit(self) -> None:
        screen = self._cleanup_screen()
        if screen:
            screen.action_cancel()

    def on_key(self, event: events.Key) -> None:
        """Normalize some terminal key variants (notably space)."""
        key = (event.key or "").lower()
        char = (event.character or "")

        # Some terminals send printable space without mapping to "space".
        if char == " ":
            self.action_toggle_kill()
            event.prevent_default()
            event.stop()
            return

        # Let bindings / OptionList handle everything else (arrows, page up/down, etc).
        # We intentionally do not call super().on_key because OptionList doesn't
        # implement it in our Textual version, and we don't want to break default
        # key binding handling.
        return

class RuntimeCleanupScreen(ModalScreen[list[int]]):
    """Prompt the user to select which runtimes to terminate."""

    # Fallback bindings if focus leaves the list.
    BINDINGS = [
        Binding("escape", "cancel", "Exit (keep all)", show=False),
        Binding("ctrl+s", "confirm", "Exit (kill selected)", show=False),
    ]

    CSS = """
    RuntimeCleanupScreen {
        background: $background;
    }

    #runtime-cleanup-help {
        padding: 1 2;
        color: $text;
        opacity: 0.9;
    }

    #runtime-list {
        height: 1fr;
        width: 100%;
    }
    """

    def __init__(self, rows: list[RuntimeRow]):
        super().__init__()
        self._rows = rows
        self._row_by_id: dict[str, RuntimeRow] = {}

    def compose(self):
        yield Header(icon="❊")
        yield Static(
            "Select runtimes to kill before exiting.\n"
            "Space = toggle kill, Enter = confirm & exit, Esc = keep all.",
            id="runtime-cleanup-help",
        )
        yield RuntimeCleanupList(id="runtime-list")
        yield Footer()

    def on_mount(self) -> None:
        lst = self.query_one("#runtime-list", RuntimeCleanupList)
        try:
            lst.focus()
        except Exception:
            pass

        for r in self._rows:
            opt_id = self._option_id_for_row(r)
            self._row_by_id[opt_id] = r
            lst.add_option(Option(self._format_row(r), id=opt_id))

        # Best-effort: fetch missing run names in background (doesn't block exit).
        self.run_worker(self._fetch_missing_names(), exclusive=True)

    def _option_id_for_row(self, r: RuntimeRow) -> str:
        return f"{r.kind}:{r.runtime_id}:{r.pid}"

    def _format_row(self, r: RuntimeRow) -> str:
        kill = "YES" if r.kill else "NO"
        # Note: kinds come from runtime_agent.list_known_runtimes(): "by-run" or "pending".
        name = r.name or ("(pending)" if r.kind == "pending" else "(unknown)")
        # Avoid Rich markup confusion ("[...]") by not using square brackets.
        return f"Kill={kill}  {name}  |  {r.runtime_id}  |  pid {r.pid}  |  {r.kind}"

    def _selected_id(self) -> str | None:
        lst = self.query_one("#runtime-list", RuntimeCleanupList)
        opt = lst.highlighted_option
        if not opt:
            return None
        return opt.id

    def _refresh_option(self, opt_id: str) -> None:
        r = self._row_by_id.get(opt_id)
        if not r:
            return
        lst = self.query_one("#runtime-list", RuntimeCleanupList)
        try:
            lst.replace_option_prompt(opt_id, self._format_row(r))
        except Exception:
            try:
                idx = lst.get_option_index(opt_id)
                lst.replace_option_prompt_at_index(idx, self._format_row(r))
            except Exception:
                pass

    def action_toggle(self) -> None:
        opt_id = self._selected_id()
        if not opt_id or opt_id not in self._row_by_id:
            return
        r = self._row_by_id[opt_id]
        r.kill = not r.kill
        self._refresh_option(opt_id)

    def action_yes(self) -> None:
        opt_id = self._selected_id()
        if not opt_id or opt_id not in self._row_by_id:
            return
        self._row_by_id[opt_id].kill = True
        self._refresh_option(opt_id)

    def action_no(self) -> None:
        opt_id = self._selected_id()
        if not opt_id or opt_id not in self._row_by_id:
            return
        self._row_by_id[opt_id].kill = False
        self._refresh_option(opt_id)

    async def _fetch_missing_names(self) -> None:
        try:
            by_run = [r for r in self._rows if r.kind == "by-run" and not r.name]
            if not by_run:
                return

            wrapper = getattr(self.app, "autobots_client", None)
            if not wrapper:
                return

            # Use the typed client directly so we can reliably read ActionResultDoc.name.
            from autobots_client import AuthenticatedClient
            from autobots_client.api.action_results import (
                get_action_result_v1_action_results_id_get,
            )

            api_client = getattr(wrapper, "client", None)
            if not isinstance(api_client, AuthenticatedClient):
                return

            for r in by_run:
                await asyncio.sleep(0)
                opt_id = self._option_id_for_row(r)
                try:
                    resp = await asyncio.to_thread(
                        lambda: get_action_result_v1_action_results_id_get.sync_detailed(
                            id=r.runtime_id,
                            client=api_client,
                        )
                    )
                    if resp.status_code == 200 and resp.parsed:
                        name = getattr(resp.parsed, "name", None)
                        if name and str(name).strip():
                            r.name = str(name).strip()
                            # Cache for next quit prompt.
                            try:
                                mp = meta_path_for_run(r.runtime_id)
                                meta: dict[str, Any] = {}
                                if mp.exists():
                                    meta = json.loads(mp.read_text(encoding="utf-8") or "{}")
                                meta["run_name"] = r.name
                                mp.write_text(
                                    json.dumps(meta, indent=2, default=str), encoding="utf-8"
                                )
                            except Exception:
                                pass
                except Exception:
                    pass

                if not r.name:
                    r.name = "(unknown)"
                self._refresh_option(opt_id)
        except Exception as e:
            logger.debug(f"Runtime cleanup name fetch failed: {e}")

    def action_confirm(self) -> None:
        pids = [r.pid for r in self._rows if r.kill and r.pid]
        self.dismiss(pids)

    def action_cancel(self) -> None:
        # Exit without killing anything.
        self.dismiss([])
