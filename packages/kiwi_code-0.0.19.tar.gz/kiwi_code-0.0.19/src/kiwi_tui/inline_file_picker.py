"""Inline file picker dropdown that appears when user types @ in chat input."""

import os
from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widget import Widget
from textual.widgets import OptionList, Static
from textual.widgets.option_list import Option
from rich.text import Text


class InlineFilePicker(Widget):
    """Dropdown file picker that shows above the input bar when @ is typed.

    Displays files/dirs in CWD with '+' prefix, filterable by typing after @.
    """

    DEFAULT_CSS = """
    InlineFilePicker {
        dock: bottom;
        height: auto;
        max-height: 14;
        width: 100%;
        background: $surface;
        border-top: solid $panel;
        padding-bottom: 2;
        display: none;
    }

    InlineFilePicker.visible {
        display: block;
    }

    InlineFilePicker #file-option-list {
        height: auto;
        max-height: 12;
        width: 100%;
        background: $surface;
        scrollbar-size: 1 1;
        border: none;
    }

    InlineFilePicker #file-option-list > .option-list--option-highlighted {
        background: $primary-background;
        color: $primary;
        text-style: bold;
    }

    InlineFilePicker #file-picker-header {
        height: 1;
        width: 100%;
        padding: 0 1;
        color: $text-muted;
        text-style: italic;
    }
    """

    class FileSelected(Message):
        """Posted when a file is selected from the picker."""
        def __init__(self, path: str) -> None:
            super().__init__()
            self.path = path

    class Cancelled(Message):
        """Posted when the picker is dismissed without selection."""
        pass

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._base_path = os.getcwd()
        self._all_entries: list[tuple[str, str]] = []  # (display_name, full_path)

    def compose(self) -> ComposeResult:
        yield Static("", id="file-picker-header")
        yield OptionList(id="file-option-list")

    def show_picker(self, filter_text: str = "") -> None:
        """Show the picker with files from CWD, optionally filtered."""
        self._base_path = os.getcwd()
        self._refresh_entries(filter_text)
        self.add_class("visible")

    def hide_picker(self) -> None:
        """Hide the picker."""
        self.remove_class("visible")

    @property
    def is_visible(self) -> bool:
        return self.has_class("visible")

    def _refresh_entries(self, filter_text: str = "") -> None:
        """Refresh the file list, optionally filtered."""
        option_list = self.query_one("#file-option-list", OptionList)
        header = self.query_one("#file-picker-header", Static)
        option_list.clear_options()
        self._all_entries = []

        try:
            entries = sorted(Path(self._base_path).iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except PermissionError:
            header.update("  Permission denied")
            return

        filter_lower = filter_text.lower()

        for entry in entries:
            name = entry.name
            if filter_lower and filter_lower not in name.lower():
                continue

            if entry.is_dir():
                display = f"+ {name}/"
            else:
                display = f"+ {name}"

            self._all_entries.append((display, str(entry)))
            option_list.add_option(Option(Text(display, style=""), id=str(entry)))

        if self._all_entries:
            header.update(f"  Files in {self._base_path}")
            option_list.highlighted = 0
        else:
            header.update(f"  No matches in {self._base_path}")

    def filter(self, text: str) -> None:
        """Filter entries by text."""
        self._refresh_entries(text)

    def _handle_selection(self, full_path: str) -> None:
        """Handle selection: navigate into directories, select files."""
        p = Path(full_path)
        if p.is_dir():
            self._base_path = str(p)
            self._refresh_entries("")
        else:
            self.post_message(self.FileSelected(full_path))

    def select_highlighted(self) -> None:
        """Select the currently highlighted entry."""
        option_list = self.query_one("#file-option-list", OptionList)
        if option_list.highlighted is not None and self._all_entries:
            idx = option_list.highlighted
            if 0 <= idx < len(self._all_entries):
                _, full_path = self._all_entries[idx]
                self._handle_selection(full_path)

    def move_highlight(self, delta: int) -> None:
        """Move the highlight up or down."""
        option_list = self.query_one("#file-option-list", OptionList)
        if option_list.highlighted is None:
            option_list.highlighted = 0
        else:
            new_idx = option_list.highlighted + delta
            if 0 <= new_idx < len(self._all_entries):
                option_list.highlighted = new_idx

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Handle click on an option."""
        if event.option.id:
            self._handle_selection(event.option.id)
