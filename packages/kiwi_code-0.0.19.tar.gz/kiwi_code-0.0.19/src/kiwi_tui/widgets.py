"""Reusable widgets for Autobots TUI."""

from textual.app import ComposeResult
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Static, Button, Label, DataTable, Input
from textual.reactive import reactive
from textual.suggester import SuggestFromList
from textual.message import Message
from rich.text import Text


# Slash commands for autocomplete
_SLASH_COMMANDS = [
    "/help",
    "/actions list",
    "/actions get ",
    "/runs list",
    "/runs get ",
    "/graphs list",
    "/graphs get ",
    "/graph-runs list",
    "/graph-runs get ",
    "/use ",
    "/continue ",
    "/new",
    "/status",
    "/cancel",
    "/upload ",
    "/files",
    "/clear-files",
    "/login",
    "/logout",
    "/metadata",
    "/metadata set ",
    "/metadata remove ",
    "/metadata clear",
    "/connect-cli",
    "/show-logs",
]


class ChatInput(Input):
    """Input with command history (up/down arrows), slash command autocomplete, and @ file picker."""

    _MAX_HISTORY = 200

    class AtTriggered(Message):
        """Posted when user types @ to open inline file picker."""
        pass

    class AtFilterChanged(Message):
        """Posted when the filter text after @ changes."""
        def __init__(self, filter_text: str) -> None:
            super().__init__()
            self.filter_text = filter_text

    class AtPickerNavigate(Message):
        """Posted when user presses up/down while picker is open."""
        def __init__(self, delta: int) -> None:
            super().__init__()
            self.delta = delta

    class AtPickerSelect(Message):
        """Posted when user presses Enter while picker is open."""
        pass

    class AtPickerCancel(Message):
        """Posted when user presses Escape while picker is open."""
        pass

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("suggester", SuggestFromList(_SLASH_COMMANDS, case_sensitive=False))
        super().__init__(*args, **kwargs)
        self._history: list[str] = []
        self._history_index: int = -1
        self._draft: str = ""  # saves current text when browsing history
        self.picker_active: bool = False  # True when inline file picker is showing

    def record(self, value: str) -> None:
        """Add a submitted value to history."""
        value = value.strip()
        if not value:
            return
        # Deduplicate consecutive
        if self._history and self._history[-1] == value:
            return
        self._history.append(value)
        if len(self._history) > self._MAX_HISTORY:
            self._history.pop(0)
        self._history_index = -1
        self._draft = ""

    def _get_at_filter(self) -> str | None:
        """Extract filter text after the last '@' if picker is active."""
        if not self.picker_active:
            return None
        val = self.value
        at_pos = val.rfind("@")
        if at_pos == -1:
            return None
        return val[at_pos + 1:]

    async def _on_key(self, event) -> None:
        if self.picker_active:
            # While picker is open, intercept navigation keys
            if event.key == "up":
                event.prevent_default()
                event.stop()
                self.post_message(self.AtPickerNavigate(-1))
                return
            elif event.key == "down":
                event.prevent_default()
                event.stop()
                self.post_message(self.AtPickerNavigate(1))
                return
            elif event.key == "enter":
                event.prevent_default()
                event.stop()
                self.post_message(self.AtPickerSelect())
                return
            elif event.key == "escape":
                event.prevent_default()
                event.stop()
                self.post_message(self.AtPickerCancel())
                return
            elif event.key == "tab":
                event.prevent_default()
                event.stop()
                self.post_message(self.AtPickerSelect())
                return
            # For other keys (typing), let them through and we'll update filter via on_changed
            await super()._on_key(event)
            return

        if event.key == "at_sign" or event.character == "@":
            # Let @ be typed into the input, then trigger the picker
            await super()._on_key(event)
            self.post_message(self.AtTriggered())
            return
        elif event.key == "up":
            if not self._history:
                return
            event.prevent_default()
            event.stop()
            if self._history_index == -1:
                # Entering history — save current draft
                self._draft = self.value
                self._history_index = len(self._history) - 1
            elif self._history_index > 0:
                self._history_index -= 1
            self.value = self._history[self._history_index]
            self.cursor_position = len(self.value)
        elif event.key == "down":
            if self._history_index == -1:
                return
            event.prevent_default()
            event.stop()
            if self._history_index < len(self._history) - 1:
                self._history_index += 1
                self.value = self._history[self._history_index]
            else:
                # Past end — restore draft
                self._history_index = -1
                self.value = self._draft
            self.cursor_position = len(self.value)
        elif event.key == "escape":
            # UX: allow exiting a partially-typed slash command without triggering it.
            # If the user has started typing a /command, Esc clears the input and does nothing.
            if self.value.lstrip().startswith("/"):
                event.prevent_default()
                event.stop()
                self.value = ""
                self.cursor_position = 0
                self._history_index = -1
                self._draft = ""
                return
            await super()._on_key(event)
        else:
            await super()._on_key(event)


class StatusBadge(Static):
    """A colored status badge widget."""

    DEFAULT_CSS = """
    StatusBadge {
        width: auto;
        height: 1;
        padding: 0 1;
        margin: 0 1;
    }

    StatusBadge.success {
        background: $success;
        color: $text;
    }

    StatusBadge.error {
        background: $error;
        color: $text;
    }

    StatusBadge.warning {
        background: $warning;
        color: $text;
    }

    StatusBadge.info {
        background: $accent;
        color: $text;
    }
    """

    def __init__(self, label: str, variant: str = "info", **kwargs):
        """Initialize status badge.

        Args:
            label: Text to display
            variant: Color variant (success, error, warning, info)
        """
        super().__init__(label, **kwargs)
        self.add_class(variant)


class StatCard(Container):
    """A card displaying a statistic."""

    DEFAULT_CSS = """
    StatCard {
        width: 1fr;
        height: auto;
        border: none;
        padding: 0;
        margin: 0 2;
    }

    StatCard > .stat-value {
        text-align: left;
        text-style: bold;
        color: $primary;
    }

    StatCard > .stat-label {
        text-align: left;
        color: $text-muted;
    }
    """

    value: reactive[str] = reactive("", init=False)
    label: reactive[str] = reactive("", init=False)

    def __init__(self, label: str, value: str = "0", **kwargs):
        """Initialize stat card.

        Args:
            label: Description of the stat
            value: Current value
        """
        super().__init__(**kwargs)
        self._initial_label = label
        self._initial_value = value

    def compose(self) -> ComposeResult:
        """Compose stat card widgets."""
        yield Static(self._initial_value, classes="stat-value")
        yield Static(self._initial_label, classes="stat-label")

    def on_mount(self) -> None:
        """Called when widget is mounted."""
        self.label = self._initial_label
        self.value = self._initial_value

    def watch_value(self, value: str) -> None:
        """Update displayed value."""
        if self.is_mounted:
            self.query_one(".stat-value", Static).update(value)

    def watch_label(self, label: str) -> None:
        """Update displayed label."""
        if self.is_mounted:
            self.query_one(".stat-label", Static).update(label)


class ActionButton(Button):
    """A styled action button."""

    DEFAULT_CSS = """
    ActionButton {
        min-width: 16;
        margin: 0 1;
        border: none;
        background: $surface;
        color: $text;
    }

    ActionButton:focus {
        background: $primary;
        color: black;
    }

    ActionButton.primary {
        color: $primary;
    }

    ActionButton.success {
        color: $success;
    }

    ActionButton.danger {
        color: $error;
    }
    """

    def __init__(self, label: str, variant: str = "primary", **kwargs):
        """Initialize action button.

        Args:
            label: Button text
            variant: Style variant (primary, success, danger)
        """
        super().__init__(label, **kwargs)
        self.add_class(variant)


class InfoPanel(Container):
    """An information panel with title and content."""

    DEFAULT_CSS = """
    InfoPanel {
        height: auto;
        border: none;
        padding: 0;
        margin: 1 0;
    }

    InfoPanel > .panel-title {
        text-style: bold;
        color: $primary;
        margin-bottom: 0;
    }

    InfoPanel > .panel-content {
        color: $text;
    }
    """

    def __init__(self, title: str, content: str = "", **kwargs):
        """Initialize info panel.

        Args:
            title: Panel title
            content: Panel content
        """
        super().__init__(**kwargs)
        self._title = title
        self._content = content

    def compose(self) -> ComposeResult:
        """Compose info panel widgets."""
        yield Static(self._title, classes="panel-title")
        yield Static(self._content, classes="panel-content")

    def update_content(self, content: str) -> None:
        """Update panel content.

        Args:
            content: New content to display
        """
        self.query_one(".panel-content", Static).update(content)
