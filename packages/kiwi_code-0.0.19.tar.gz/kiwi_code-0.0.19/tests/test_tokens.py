"""TokenManager tests."""
from __future__ import annotations

from pathlib import Path


def test_no_tokens_when_fresh(isolated_home: Path) -> None:
    from kiwi_cli.auth import TokenManager

    tm = TokenManager()
    assert tm.load_tokens() is None
    assert tm.is_authenticated() is False


def test_clear_tokens_is_idempotent(isolated_home: Path) -> None:
    from kiwi_cli.auth import TokenManager

    tm = TokenManager()
    tm.clear_tokens()  # should not raise even when nothing exists
    tm.clear_tokens()
    assert tm.load_tokens() is None
