"""Shared pytest fixtures.

Every test that touches the filesystem through Kiwi's managers goes
through the ``isolated_home`` fixture so that ``~/.kiwi/`` writes land in
a tmp dir instead of polluting the developer's real home.
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest


@pytest.fixture
def isolated_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ``$HOME`` (and ``USERPROFILE`` on Windows) to a tmp dir.

    Kiwi's ``ConfigManager`` / ``TokenManager`` / ``runtime_manager`` all
    default their paths to ``Path.home() / ".kiwi"``. Pointing HOME at a
    tmp dir sandboxes the whole test.
    """
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    # Defensive: make sure no leftover XDG redirects still point elsewhere.
    for var in ("XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME"):
        monkeypatch.delenv(var, raising=False)
    # Prevent the re-exec trick in kiwi_tui.main from firing during tests.
    monkeypatch.setenv("_KIWI_PROC_RENAMED", "1")
    return tmp_path
