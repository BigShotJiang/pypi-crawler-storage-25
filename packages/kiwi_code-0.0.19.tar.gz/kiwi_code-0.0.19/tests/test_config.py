"""ConfigManager round-trip tests."""
from __future__ import annotations

from pathlib import Path


def test_config_creates_default(isolated_home: Path) -> None:
    from kiwi_cli.config import ConfigManager

    mgr = ConfigManager()
    cfg = mgr.load()
    # Default config must at minimum expose a backend URL.
    assert cfg.backend_url
    assert cfg.backend_url.startswith(("http://", "https://"))


def test_config_update_persists(isolated_home: Path) -> None:
    from kiwi_cli.config import ConfigManager

    mgr = ConfigManager()
    mgr.load()
    mgr.update(theme="light")

    # Re-read with a fresh manager to prove the change hit disk.
    mgr2 = ConfigManager()
    cfg2 = mgr2.load()
    assert cfg2.theme == "light"
