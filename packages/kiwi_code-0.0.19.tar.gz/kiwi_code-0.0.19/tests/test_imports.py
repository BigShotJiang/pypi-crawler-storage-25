"""Import smoke tests.

Walks every submodule of the three shipped packages and imports it.
This is the cheapest way to catch syntax errors, circular imports and
stale references before they reach end users via ``pipx install``.
"""
from __future__ import annotations

import importlib
import pkgutil

import pytest

PACKAGES = ["kiwi_cli", "kiwi_tui", "kiwi_runtime"]


def _iter_submodules(pkg_name: str):
    pkg = importlib.import_module(pkg_name)
    yield pkg_name
    if hasattr(pkg, "__path__"):
        for mod in pkgutil.walk_packages(pkg.__path__, prefix=pkg_name + "."):
            # Skip ``__main__`` modules — importing them runs the script
            # body (including argparse on sys.argv), which fights with
            # pytest's own argv.
            if mod.name.endswith(".__main__"):
                continue
            yield mod.name


@pytest.mark.parametrize("pkg", PACKAGES)
def test_package_imports_cleanly(pkg: str) -> None:
    for mod_name in _iter_submodules(pkg):
        importlib.import_module(mod_name)
