"""End-to-end CLI smoke tests.

These spawn real subprocesses against the installed entry points to
mirror what ``pipx install kiwi-code`` users experience. They are the
first line of defense against regressions in argument parsing,
imports, and packaging.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def _run(module: str, *args: str) -> subprocess.CompletedProcess[str]:
    env = {
        **_base_env(),
        "_KIWI_PROC_RENAMED": "1",  # short-circuit kiwi's re-exec trick
    }
    return subprocess.run(
        [sys.executable, "-m", module, *args],
        capture_output=True,
        text=True,
        timeout=60,
        env=env,
    )


def _base_env() -> dict[str, str]:
    import os

    return {k: v for k, v in os.environ.items()}


def test_kiwicli_help_exits_zero() -> None:
    r = _run("kiwi_cli.cli", "--help")
    assert r.returncode == 0, r.stderr
    assert "kiwi" in (r.stdout + r.stderr).lower()


def test_kiwi_runtime_help_exits_zero() -> None:
    r = _run("kiwi_runtime", "--help")
    assert r.returncode == 0, r.stderr
    combined = (r.stdout + r.stderr).lower()
    assert "connect" in combined or "usage" in combined


def test_kiwi_tui_help_exits_zero(isolated_home: Path) -> None:
    # `kiwi --help` should print argparse help and exit without launching
    # the TUI. Runs through the ``main()`` entry point via ``-m``.
    r = _run("kiwi_tui.main", "--help")
    assert r.returncode == 0, r.stderr
    assert "kiwi" in (r.stdout + r.stderr).lower()
