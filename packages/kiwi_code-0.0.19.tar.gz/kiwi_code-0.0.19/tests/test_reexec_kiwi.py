"""Validate the ``_reexec_as_kiwi`` symlink trick.

The goal of the re-exec is to make the kernel-reported process name
(``/proc/self/comm`` on Linux, ``ps -co comm=`` on macOS) become
``kiwi`` so terminal emulators like VS Code label the tab correctly.
We verify that by spawning a child that exec's through the symlink and
prints its own ``comm``.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.skipif(
    sys.platform == "win32",
    reason="Windows uses native kiwi.exe launcher; no re-exec needed",
)


def _read_comm(pid: int) -> str:
    if sys.platform == "linux":
        return Path(f"/proc/{pid}/comm").read_text().strip()
    # macOS: ``-c`` asks ps for the short accounting name (max 15 chars),
    # which is exactly what VS Code reads for ${process}.
    out = subprocess.check_output(
        ["ps", "-co", "comm=", "-p", str(pid)], text=True
    )
    return out.strip()


def test_reexec_symlink_sets_comm_to_kiwi(isolated_home: Path) -> None:
    bin_dir = isolated_home / ".kiwi" / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    link = bin_dir / "kiwi"
    if link.exists() or link.is_symlink():
        link.unlink()
    link.symlink_to(sys.executable)

    # Run a tiny child through the symlink and have it print its own comm.
    child = (
        "import os, sys, subprocess; "
        "pid = os.getpid(); "
    )
    if sys.platform == "linux":
        child += "print(open(f'/proc/{pid}/comm').read().strip())"
    else:
        child += (
            "print(subprocess.check_output("
            "['ps', '-co', 'comm=', '-p', str(pid)], text=True).strip())"
        )

    env = os.environ.copy()
    env["__PYVENV_LAUNCHER__"] = sys.executable
    # The spawned interpreter must be able to import stdlib normally.
    result = subprocess.run(
        [str(link), "-c", child],
        capture_output=True,
        text=True,
        env=env,
        timeout=30,
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "kiwi", (
        f"expected comm=kiwi, got {result.stdout!r}\nstderr={result.stderr!r}"
    )
