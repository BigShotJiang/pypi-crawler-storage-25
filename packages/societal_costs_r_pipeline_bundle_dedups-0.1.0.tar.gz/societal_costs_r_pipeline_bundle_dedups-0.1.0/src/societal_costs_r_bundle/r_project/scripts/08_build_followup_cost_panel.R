project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "price_harmonization.R"))
source(file.path(project_root, "R", "followup_cost_panel.R"))

config <- default_project_config(project_root = project_root)
matched_cohort_path <- file.path(config$output_dir, "matched_cohort.parquet")
harmonized_cost_path <- file.path(config$output_dir, "direct_cost_person_year_harmonized.parquet")

if (!file.exists(matched_cohort_path)) {
  stop(sprintf("Matched cohort not found at %s. Run scripts/03_run_matching.R first.", matched_cohort_path))
}
if (!file.exists(harmonized_cost_path)) {
  stop(sprintf("Harmonized direct-cost parquet not found at %s. Run scripts/07_build_harmonized_cost_artifacts.R first.", harmonized_cost_path))
}

matched_df_full <- arrow::read_parquet(matched_cohort_path)

# For the primary 10-year cumulative endpoint the protocol restricts cohort
# entry to 2001-2014 so that complete 10-year follow-up is observable by 2024.
# For annual endpoints, all cohort entry years (through 2023) are used.
matched_df_primary <- matched_df_full[
  !is.na(matched_df_full$index_date) &
    as.integer(format(as.Date(matched_df_full$index_date), "%Y")) >= 2001L &
    as.integer(format(as.Date(matched_df_full$index_date), "%Y")) <= 2014L,
  ,
  drop = FALSE
]
harmonized_cost_primary_df <- load_relevant_harmonized_costs(harmonized_cost_path, matched_df_primary, max_followup_years = 10L)
harmonized_cost_all_df <- load_relevant_harmonized_costs(harmonized_cost_path, matched_df_full, max_followup_years = 10L)

message(sprintf(
  "Cohort: %d total, %d in 2001-2014 primary window",
  nrow(matched_df_full),
  nrow(matched_df_primary)
))

# Primary panel: all post-index costs from day 0
followup_outputs <- build_followup_cost_panel(
  matched_df_primary,
  harmonized_cost_primary_df,
  max_followup_years = 10L,
  exclude_first_n_days = 0L
)
annual_summary_df <- build_followup_annual_summary(followup_outputs$followup_cost_panel)
cumulative_summary_df <- build_followup_cumulative_summary(followup_outputs$followup_cost_panel)
discounted_cumulative_summary_df <- build_followup_discounted_cumulative_summary(followup_outputs$discounted_followup_cost_panel)
annual_difference_df <- build_followup_difference_summary(
  annual_summary_df,
  value_column = "annual_cost_ppy_reference_dkk",
  group_columns = c("component", "followup_year")
)
cumulative_difference_df <- build_followup_difference_summary(
  cumulative_summary_df,
  value_column = "mean_cumulative_cost_reference_dkk",
  group_columns = c("component")
)
discounted_cumulative_difference_df <- build_followup_difference_summary(
  discounted_cumulative_summary_df,
  value_column = "mean_cumulative_discounted_cost_reference_dkk",
  group_columns = c("component", "discount_rate")
)
output_paths <- write_followup_cost_outputs(
  followup_cost_panel_df = followup_outputs$followup_cost_panel,
  discounted_followup_cost_panel_df = followup_outputs$discounted_followup_cost_panel,
  annual_summary_df = annual_summary_df,
  cumulative_summary_df = cumulative_summary_df,
  discounted_cumulative_summary_df = discounted_cumulative_summary_df,
  annual_difference_df = annual_difference_df,
  cumulative_difference_df = cumulative_difference_df,
  discounted_cumulative_difference_df = discounted_cumulative_difference_df,
  config = config
)
message("Follow-up cost-panel rows (primary): ", nrow(followup_outputs$followup_cost_panel))
message("Follow-up cost-panel parquet written to ", output_paths$followup_cost_panel_path)

# Survivor-only secondary panel: exclude person-years truncated by death
survivor_panel <- filter_survivor_only_panel(
  followup_outputs$followup_cost_panel,
  matched_df_primary
)
survivor_panel_path <- file.path(config$output_dir, "followup_cost_panel_survivors.parquet")
arrow::write_parquet(survivor_panel, survivor_panel_path)
message("Survivor-only panel rows: ", nrow(survivor_panel), " (", survivor_panel_path, ")")

# Sensitivity panel: exclude first 90 days (diagnostic-workup costs)
followup_outputs_90d <- build_followup_cost_panel(
  matched_df_primary,
  harmonized_cost_primary_df,
  max_followup_years = 10L,
  exclude_first_n_days = 90L
)

sensitivity_paths <- list(
  panel_path = file.path(config$output_dir, "followup_cost_panel_excl90d.parquet"),
  discounted_path = file.path(config$output_dir, "followup_cost_panel_discounted_excl90d.parquet"),
  summary_path = file.path(config$output_dir, "followup_annual_cost_summary_excl90d.csv")
)
arrow::write_parquet(followup_outputs_90d$followup_cost_panel, sensitivity_paths$panel_path)
arrow::write_parquet(followup_outputs_90d$discounted_followup_cost_panel, sensitivity_paths$discounted_path)
utils::write.csv(
  build_followup_annual_summary(followup_outputs_90d$followup_cost_panel),
  sensitivity_paths$summary_path,
  row.names = FALSE
)
message("Follow-up cost-panel rows (90-day exclusion sensitivity): ", nrow(followup_outputs_90d$followup_cost_panel))
message("Sensitivity panel written to ", sensitivity_paths$panel_path)

# Annual panel: full cohort (all entry years) for annual cost trajectories
followup_outputs_annual <- build_followup_cost_panel(
  matched_df_full,
  harmonized_cost_all_df,
  max_followup_years = 10L,
  exclude_first_n_days = 0L
)
arrow::write_parquet(
  followup_outputs_annual$followup_cost_panel,
  file.path(config$output_dir, "followup_cost_panel_all_entry_years.parquet")
)
message("Follow-up cost-panel rows (all entry years, annual): ", nrow(followup_outputs_annual$followup_cost_panel))
