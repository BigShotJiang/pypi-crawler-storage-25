project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "cost_panel.R"))

config <- default_project_config(project_root = project_root)
matched_cohort_path <- file.path(config$output_dir, "matched_cohort.parquet")
direct_cost_path <- file.path(config$output_dir, "direct_cost_person_year.parquet")
component_year_availability_path <- file.path(config$output_dir, "direct_cost_component_year_availability.parquet")

if (!file.exists(matched_cohort_path)) {
  stop(sprintf("Matched cohort not found at %s. Run scripts/03_run_matching.R first.", matched_cohort_path))
}
if (!file.exists(direct_cost_path)) {
  stop(sprintf("Direct-cost person-year parquet not found at %s. Run scripts/05_build_direct_cost_artifacts.R first.", direct_cost_path))
}

matched_df <- arrow::read_parquet(matched_cohort_path)
direct_cost_df <- arrow::read_parquet(direct_cost_path)
component_year_availability_df <- if (file.exists(component_year_availability_path)) {
  arrow::read_parquet(component_year_availability_path)
} else {
  data.frame()
}

cost_panel_df <- build_cost_panel(
  matched_df,
  direct_cost_df,
  component_year_availability = component_year_availability_df,
  followup_years = 5L
)
panel_summary <- build_cost_panel_summary(cost_panel_df)
data_availability_summary <- build_cost_panel_data_availability_summary(cost_panel_df)
output_paths <- write_cost_panel_outputs(cost_panel_df, config, panel_summary, data_availability_summary)

message("Matched cost-panel rows: ", nrow(cost_panel_df))
message("Matched cost-panel parquet written to ", output_paths$cost_panel_path)
message("Matched cost-panel data availability summary written to ", output_paths$cost_panel_data_availability_summary_path)
