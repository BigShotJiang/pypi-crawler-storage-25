project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "matching.R"))

config <- default_project_config(project_root = project_root)
baseline_path <- file.path(config$output_dir, "baseline_dataset.parquet")

if (!file.exists(baseline_path)) {
  stop(sprintf("Baseline dataset not found at %s. Run scripts/01_build_baseline_dataset.R first.", baseline_path))
}

baseline_df <- arrow::read_parquet(baseline_path)
outputs <- write_matching_outputs(
  baseline_df,
  config,
  match_ratios = default_match_ratios(),
  seed = 42L
)

message("Matched pairs written to ", outputs$matched_pairs_path)
message("Matched cohort written to ", outputs$matched_cohort_path)
