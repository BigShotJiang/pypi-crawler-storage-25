project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "raw_parent_covariates.R"))

config <- default_project_config(project_root = project_root)
baseline_dataset_path <- file.path(config$output_dir, "baseline_dataset.parquet")

if (!file.exists(baseline_dataset_path)) {
  stop(sprintf("Baseline dataset not found at %s. Run scripts/01_build_baseline_dataset.R first.", baseline_dataset_path))
}

baseline_df <- arrow::read_parquet(baseline_dataset_path)
diagnostics <- build_parental_education_diagnostics(baseline_df, config)
output_paths <- write_parental_education_diagnostics(diagnostics, config)

message("Parental education diagnostic rows: ", nrow(diagnostics$row_level))
message("Parental education diagnostic parquet written to ", output_paths$row_level_path)
