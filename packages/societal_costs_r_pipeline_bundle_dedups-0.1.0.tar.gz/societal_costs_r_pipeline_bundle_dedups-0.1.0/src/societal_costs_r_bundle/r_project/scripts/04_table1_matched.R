project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "table1_matched.R"))

config <- default_project_config(project_root = project_root)
matched_cohort_path <- file.path(config$output_dir, "matched_cohort.parquet")

if (!file.exists(matched_cohort_path)) {
  stop(sprintf("Matched cohort not found at %s. Run scripts/03_run_matching.R first.", matched_cohort_path))
}

matched_df <- arrow::read_parquet(matched_cohort_path)
outputs <- write_matched_table1_outputs(matched_df, config$output_dir)

message("Matched Table 1 HTML written to ", outputs$html_path)
message("Matched Table 1 CSV written to ", outputs$csv_path)
