project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "cohort_inputs.R"))
source(file.path(project_root, "R", "register_metrics.R"))
source(file.path(project_root, "R", "raw_parent_covariates.R"))
source(file.path(project_root, "R", "baseline_dataset.R"))
source(file.path(project_root, "R", "matching.R"))
source(file.path(project_root, "R", "table1_matched.R"))
source(file.path(project_root, "R", "direct_cost_artifacts.R"))
source(file.path(project_root, "R", "cost_panel.R"))
source(file.path(project_root, "R", "price_harmonization.R"))
source(file.path(project_root, "R", "followup_cost_panel.R"))
source(file.path(project_root, "R", "cost_analysis.R"))

detected_repo_root <- detect_repo_root(project_root)

# Edit this block before running.
# In local repo development, leaving most paths as NULL will auto-resolve from `repo_root`.
# On the server, set either:
# - `repo_root` and optionally `test_out_root` / `raw_data_dir`, or
# - the individual directories directly.
pipeline_settings <- list(
  repo_root = detected_repo_root,
  test_out_root = NULL,
  cohort_dir = NULL,
  core_dir = NULL,
  registers_dir = NULL,
  raw_data_dir = NULL,
  raw_popc_dir = NULL,
  raw_lmdb_dir = NULL,
  raw_primary_dir = NULL,
  raw_drg_dir = NULL,
  raw_indberetningmedpris_path = NULL,
  output_dir = file.path(project_root, "output"),
  reference_price_year = 2023L,
  use_hospital_drugs = FALSE,
  hospital_drugs_usage_path = NULL,
  n_bootstrap = 1000L,
  n_cores = 1L,
  max_followup_years = 10L,
  skip_subgroups = FALSE,
  skip_discounts = FALSE,
  skip_survivors = FALSE,
  skip_proxies = FALSE
)

# Choose which stages to run.
# Available:
# inventory, baseline, parental_education_diagnostics, matching_inputs,
# matching, table1, direct_cost, cost_panel, harmonize, followup, analyse
stages_to_run <- c(
  "inventory",
  "baseline",
  "parental_education_diagnostics",
  "matching_inputs",
  "matching",
  "table1",
  "direct_cost",
  "cost_panel",
  "harmonize",
  "followup",
  "analyse"
)

make_interactive_config <- function(project_root, settings) {
  default_project_config(project_root = project_root, args = settings)
}

run_stage <- function(label, fn) {
  started <- Sys.time()
  message(sprintf("\n=== %s ===", label))
  result <- fn()
  elapsed <- difftime(Sys.time(), started, units = "secs")
  message(sprintf("Completed %s in %.1f seconds", label, as.numeric(elapsed)))
  result
}

read_if_exists <- function(path) {
  if (!file.exists(path)) {
    return(NULL)
  }
  arrow::read_parquet(path)
}

run_societal_costs_pipeline_interactive <- function(settings = pipeline_settings, stages = stages_to_run) {
  config <- make_interactive_config(project_root, settings)
  ensure_output_dir(config)

  message("Using paths:")
  message(sprintf("  repo_root: %s", config$repo_root))
  message(sprintf("  cohort_dir: %s", config$cohort_dir))
  message(sprintf("  core_dir: %s", config$core_dir))
  message(sprintf("  registers_dir: %s", config$registers_dir))
  message(sprintf("  raw_popc_dir: %s", config$raw_popc_dir))
  message(sprintf("  raw_lmdb_dir: %s", config$raw_lmdb_dir))
  message(sprintf("  raw_primary_dir: %s", config$raw_primary_dir))
  message(sprintf("  raw_drg_dir: %s", config$raw_drg_dir))
  message(sprintf("  raw_indberetningmedpris_path: %s", config$raw_indberetningmedpris_path))
  message(sprintf("  output_dir: %s", config$output_dir))

  valid_stages <- c(
    "inventory",
    "baseline",
    "parental_education_diagnostics",
    "matching_inputs",
    "matching",
    "table1",
    "direct_cost",
    "cost_panel",
    "harmonize",
    "followup",
    "analyse"
  )
  unknown_stages <- setdiff(stages, valid_stages)
  if (length(unknown_stages)) {
    stop(sprintf("Unknown stages: %s", paste(unknown_stages, collapse = ", ")))
  }

  results <- list(config = config)

  if ("inventory" %in% stages) {
    results$inventory <- run_stage("inventory", function() {
      manifest <- inventory_input_artifacts(config)
      write_inventory_outputs(manifest, config)
      manifest
    })
  }

  if ("baseline" %in% stages) {
    results$baseline <- run_stage("baseline", function() {
      baseline_df <- build_baseline_dataset(config)
      write_baseline_dataset(config, baseline_df)
      baseline_df
    })
  }

  if ("parental_education_diagnostics" %in% stages) {
    results$parental_education_diagnostics <- run_stage("parental_education_diagnostics", function() {
      baseline_df <- results$baseline %||% read_if_exists(file.path(config$output_dir, "baseline_dataset.parquet"))
      if (is.null(baseline_df)) {
        stop("Baseline dataset not found. Run the baseline stage first.")
      }
      diagnostics <- build_parental_education_diagnostics(baseline_df, config)
      write_parental_education_diagnostics(diagnostics, config)
      diagnostics
    })
  }

  if ("matching_inputs" %in% stages) {
    results$matching_inputs <- run_stage("matching_inputs", function() {
      baseline_df <- results$baseline %||% read_if_exists(file.path(config$output_dir, "baseline_dataset.parquet"))
      if (is.null(baseline_df)) {
        stop("Baseline dataset not found. Run the baseline stage first.")
      }
      write_matching_inputs(config, baseline_df)
    })
  }

  if ("matching" %in% stages) {
    results$matching <- run_stage("matching", function() {
      baseline_df <- results$baseline %||% read_if_exists(file.path(config$output_dir, "baseline_dataset.parquet"))
      if (is.null(baseline_df)) {
        stop("Baseline dataset not found. Run the baseline stage first.")
      }
      write_matching_outputs(
        baseline_df,
        config,
        match_ratios = default_match_ratios(),
        seed = 42L
      )
    })
  }

  if ("table1" %in% stages) {
    results$table1 <- run_stage("table1", function() {
      matched_df <- read_if_exists(file.path(config$output_dir, "matched_cohort.parquet"))
      if (is.null(matched_df)) {
        stop("Matched cohort not found. Run the matching stage first.")
      }
      write_matched_table1_outputs(matched_df, config$output_dir)
    })
  }

  if ("direct_cost" %in% stages) {
    results$direct_cost <- run_stage("direct_cost", function() {
      artifacts <- build_direct_cost_artifacts(config)
      write_direct_cost_artifacts(artifacts, config)
      artifacts
    })
  }

  if ("cost_panel" %in% stages) {
    results$cost_panel <- run_stage("cost_panel", function() {
      matched_df <- read_if_exists(file.path(config$output_dir, "matched_cohort.parquet"))
      direct_cost_df <- read_if_exists(file.path(config$output_dir, "direct_cost_person_year.parquet"))
      component_year_availability_df <- read_if_exists(file.path(config$output_dir, "direct_cost_component_year_availability.parquet"))
      if (is.null(matched_df)) {
        stop("Matched cohort not found. Run the matching stage first.")
      }
      if (is.null(direct_cost_df)) {
        stop("Direct-cost parquet not found. Run the direct_cost stage first.")
      }
      if (is.null(component_year_availability_df)) {
        component_year_availability_df <- data.frame()
      }

      cost_panel_df <- build_cost_panel(
        matched_df,
        direct_cost_df,
        component_year_availability = component_year_availability_df,
        followup_years = 5L
      )
      panel_summary <- build_cost_panel_summary(cost_panel_df)
      data_availability_summary <- build_cost_panel_data_availability_summary(cost_panel_df)
      write_cost_panel_outputs(cost_panel_df, config, panel_summary, data_availability_summary)
    })
  }

  if ("harmonize" %in% stages) {
    results$harmonize <- run_stage("harmonize", function() {
      direct_cost_df <- (results$direct_cost$combined_cost) %||%
        read_if_exists(file.path(config$output_dir, "direct_cost_person_year.parquet"))
      if (is.null(direct_cost_df)) {
        stop("Direct-cost parquet not found. Run the direct_cost stage first.")
      }
      harmonized_cost_df    <- harmonize_direct_cost_person_year(direct_cost_df, config)
      harmonized_summary_df <- build_harmonized_cost_summary(harmonized_cost_df)
      write_harmonized_cost_outputs(harmonized_cost_df, harmonized_summary_df, config)
      harmonized_cost_df
    })
  }

  if ("followup" %in% stages) {
    results$followup <- run_stage("followup", function() {
      matched_df_full    <- read_if_exists(file.path(config$output_dir, "matched_cohort.parquet"))
      if (is.null(matched_df_full)) {
        stop("Matched cohort not found. Run the matching stage first.")
      }
      harmonized_cost_path <- file.path(config$output_dir, "direct_cost_person_year_harmonized.parquet")
      if (!file.exists(harmonized_cost_path)) {
        stop("Harmonized cost parquet not found. Run the harmonize stage first.")
      }

      max_fy <- settings$max_followup_years %||% 10L

      # Compute index_year once to avoid repeated as.Date + format calls
      index_year_vec <- as.integer(format(as.Date(matched_df_full$index_date), "%Y"))
      matched_df_primary <- matched_df_full[
        !is.na(matched_df_full$index_date) &
          index_year_vec >= 2001L &
          index_year_vec <= 2014L,
        , drop = FALSE
      ]
      harmonized_cost_primary_df <- load_relevant_harmonized_costs(harmonized_cost_path, matched_df_primary, max_fy)
      harmonized_cost_all_df <- load_relevant_harmonized_costs(harmonized_cost_path, matched_df_full, max_fy)

      # Build primary segments once; reuse for both the standard and 90-day-exclusion variants.
      primary_segments <- build_followup_segments_vectorized(matched_df_primary, max_fy)

      followup_outputs <- build_followup_cost_panel_from_segments(
        primary_segments, harmonized_cost_primary_df,
        max_followup_years   = max_fy,
        exclude_first_n_days = 0L
      )
      annual_summary_df <- build_followup_annual_summary(followup_outputs$followup_cost_panel)
      cumulative_summary_df <- build_followup_cumulative_summary(
        followup_outputs$followup_cost_panel,
        max_followup_years = max_fy
      )
      discounted_cumulative_summary_df <- build_followup_discounted_cumulative_summary(
        followup_outputs$discounted_followup_cost_panel,
        max_followup_years = max_fy
      )
      annual_difference_df <- build_followup_difference_summary(
        annual_summary_df,
        value_column  = "annual_cost_ppy_reference_dkk",
        group_columns = c("component", "followup_year")
      )
      cumulative_difference_df <- build_followup_difference_summary(
        cumulative_summary_df,
        value_column  = "mean_cumulative_cost_reference_dkk",
        group_columns = c("component")
      )
      discounted_cumulative_difference_df <- build_followup_difference_summary(
        discounted_cumulative_summary_df,
        value_column  = "mean_cumulative_discounted_cost_reference_dkk",
        group_columns = c("component", "discount_rate")
      )

      write_followup_cost_outputs(
        followup_cost_panel_df            = followup_outputs$followup_cost_panel,
        discounted_followup_cost_panel_df = followup_outputs$discounted_followup_cost_panel,
        annual_summary_df                 = annual_summary_df,
        cumulative_summary_df             = cumulative_summary_df,
        discounted_cumulative_summary_df  = discounted_cumulative_summary_df,
        annual_difference_df              = annual_difference_df,
        cumulative_difference_df          = cumulative_difference_df,
        discounted_cumulative_difference_df = discounted_cumulative_difference_df,
        config = config
      )

      survivor_panel <- filter_survivor_only_panel(
        followup_outputs$followup_cost_panel,
        matched_df_primary
      )
      arrow::write_parquet(
        survivor_panel,
        file.path(config$output_dir, "followup_cost_panel_survivors.parquet")
      )

      # Reuse pre-built primary segments; only the allocation differs for the 90d variant.
      followup_outputs_90d <- build_followup_cost_panel_from_segments(
        primary_segments, harmonized_cost_primary_df,
        max_followup_years   = max_fy,
        exclude_first_n_days = 90L
      )
      arrow::write_parquet(
        followup_outputs_90d$followup_cost_panel,
        file.path(config$output_dir, "followup_cost_panel_excl90d.parquet")
      )
      arrow::write_parquet(
        followup_outputs_90d$discounted_followup_cost_panel,
        file.path(config$output_dir, "followup_cost_panel_discounted_excl90d.parquet")
      )
      utils::write.csv(
        build_followup_annual_summary(followup_outputs_90d$followup_cost_panel),
        file.path(config$output_dir, "followup_annual_cost_summary_excl90d.csv"),
        row.names = FALSE
      )

      # All-entry-years variant uses matched_df_full — different persons, built separately.
      followup_outputs_annual <- build_followup_cost_panel(
        matched_df_full, harmonized_cost_all_df,
        max_followup_years   = max_fy,
        exclude_first_n_days = 0L
      )
      arrow::write_parquet(
        followup_outputs_annual$followup_cost_panel,
        file.path(config$output_dir, "followup_cost_panel_all_entry_years.parquet")
      )

      followup_outputs
    })
  }

  if ("analyse" %in% stages) {
    results$analyse <- run_stage("analyse", function() {
      panel_df <- read_if_exists(file.path(config$output_dir, "followup_cost_panel.parquet"))
      matched_df <- read_if_exists(file.path(config$output_dir, "matched_cohort.parquet"))
      discounted_df <- read_if_exists(file.path(config$output_dir, "followup_cost_panel_discounted.parquet"))
      if (is.null(panel_df)) {
        stop("Follow-up cost panel not found. Run the followup stage first.")
      }
      if (is.null(matched_df)) {
        stop("Matched cohort not found. Run the matching stage first.")
      }

      results_primary <- run_cost_analysis(
        panel_df = panel_df,
        matched_df = matched_df,
        max_followup_years = settings$max_followup_years %||% 10L,
        n_bootstrap = settings$n_bootstrap %||% 1000L,
        n_cores = settings$n_cores %||% 1L
      )

      results_discount <- if (!isTRUE(settings$skip_discounts) && !is.null(discounted_df) && nrow(discounted_df)) {
        run_discount_scenarios(
          discounted_panel_df = discounted_df,
          matched_df = matched_df,
          discount_rates = c(0.03, 0.05),
          max_followup_years = settings$max_followup_years %||% 10L,
          n_bootstrap = settings$n_bootstrap %||% 1000L,
          n_cores = settings$n_cores %||% 1L
        )
      } else {
        data.frame()
      }

      results_subgroup <- if (!isTRUE(settings$skip_subgroups)) {
        run_subgroup_analyses(
          panel_df = panel_df,
          matched_df = matched_df,
          max_followup_years = settings$max_followup_years %||% 10L,
          n_bootstrap = settings$n_bootstrap %||% 1000L,
          n_cores = settings$n_cores %||% 1L
        )
      } else {
        data.frame()
      }

      results_df <- dplyr::bind_rows(results_primary, results_discount, results_subgroup)
      write_cost_analysis_outputs(results_df, config)

      if (!isTRUE(settings$skip_survivors)) {
        survivor_df <- read_if_exists(file.path(config$output_dir, "followup_cost_panel_survivors.parquet"))
        if (!is.null(survivor_df) && nrow(survivor_df)) {
          results_survivors <- run_cost_analysis(
            panel_df = survivor_df,
            matched_df = matched_df,
            max_followup_years = settings$max_followup_years %||% 10L,
            n_bootstrap = settings$n_bootstrap %||% 1000L,
            n_cores = settings$n_cores %||% 1L
          )
          utils::write.csv(
            results_survivors,
            file.path(config$output_dir, "cost_analysis_results_survivors.csv"),
            row.names = FALSE
          )
        }
      }

      if (!isTRUE(settings$skip_proxies)) {
        proxy_summary <- run_utilization_proxy_analysis(panel_df, config)
        if (nrow(proxy_summary)) {
          utils::write.csv(
            proxy_summary,
            file.path(config$output_dir, "utilization_proxy_summary.csv"),
            row.names = FALSE
          )
        }
      }

      results_df
    })
  }

  invisible(results)
}

pipeline_results <- run_societal_costs_pipeline_interactive()
