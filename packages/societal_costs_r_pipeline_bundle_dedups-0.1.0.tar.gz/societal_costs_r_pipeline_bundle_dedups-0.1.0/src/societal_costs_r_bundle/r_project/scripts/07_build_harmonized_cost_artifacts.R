project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "price_harmonization.R"))

config <- default_project_config(project_root = project_root)
direct_cost_path <- file.path(config$output_dir, "direct_cost_person_year.parquet")

if (!file.exists(direct_cost_path)) {
  stop(sprintf("Direct-cost person-year parquet not found at %s. Run scripts/05_build_direct_cost_artifacts.R first.", direct_cost_path))
}

direct_cost_df <- arrow::read_parquet(direct_cost_path)
harmonized_cost_df <- harmonize_direct_cost_person_year(direct_cost_df, config)
harmonized_summary_df <- build_harmonized_cost_summary(harmonized_cost_df)
output_paths <- write_harmonized_cost_outputs(harmonized_cost_df, harmonized_summary_df, config)

message("Harmonized direct-cost rows: ", nrow(harmonized_cost_df))
message("Harmonized direct-cost parquet written to ", output_paths$harmonized_cost_path)
