project_root <- local({
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE)))
  } else if (requireNamespace("rstudioapi", quietly = TRUE) &&
             rstudioapi::isAvailable() &&
             nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/")))
  } else {
    normalizePath(getwd(), winslash = "/")
  }
})

source(file.path(project_root, "R", "config.R"))
source(file.path(project_root, "R", "utils.R"))
source(file.path(project_root, "R", "io_arrow.R"))
source(file.path(project_root, "R", "validation.R"))
source(file.path(project_root, "R", "cohort_inputs.R"))
source(file.path(project_root, "R", "register_metrics.R"))
source(file.path(project_root, "R", "raw_parent_covariates.R"))
source(file.path(project_root, "R", "baseline_dataset.R"))

config <- default_project_config(project_root = project_root)
baseline_path <- file.path(config$output_dir, "baseline_dataset.parquet")

baseline_df <- if (file.exists(baseline_path)) {
  arrow::read_parquet(baseline_path)
} else {
  build_baseline_dataset(config)
}

output_path <- write_matching_inputs(config, baseline_df)
message("Matching-input dataset written to ", output_path)
