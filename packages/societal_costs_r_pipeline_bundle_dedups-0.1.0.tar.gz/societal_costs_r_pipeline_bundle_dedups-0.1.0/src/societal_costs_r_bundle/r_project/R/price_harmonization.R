suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

CPI_BASE_YEAR <- 2015L

# CPI series: Statistics Denmark, PRIS6 (consumer price index, base year 2015 = 100).
# Values below are annual averages of the monthly PRIS6 series.
# Verify against the current PRIS6 extract from statistikbanken.dk before publication.
ANNUAL_CPI_INDEX <- data.frame(
  year = c(
    2000L, 2001L, 2002L, 2003L, 2004L, 2005L, 2006L, 2007L, 2008L, 2009L,
    2010L, 2011L, 2012L, 2013L, 2014L, 2015L, 2016L, 2017L, 2018L, 2019L,
    2020L, 2021L, 2022L, 2023L, 2024L, 2025L
  ),
  cpi_index = c(
    76.2167, 78.0250, 79.9167, 81.5750, 82.5167, 84.0167, 85.6333, 87.0833, 90.0583, 91.2333,
    93.3417, 95.9167, 98.2167, 98.9917, 99.5500, 100.0000, 100.2500, 101.4000, 102.2250, 103.0000,
    103.4333, 105.3500, 113.4583, 117.2083, 118.8167, 120.9900
  ),
  stringsAsFactors = FALSE
)

default_discount_rates <- function() {
  c(0, 0.03, 0.05)
}

resolve_cpi_table <- function(config) {
  reference_year <- as.integer(config$reference_price_year)
  if (!(reference_year %in% ANNUAL_CPI_INDEX$year)) {
    stop(sprintf("Reference price year %s is missing from the CPI table.", reference_year))
  }

  reference_cpi <- ANNUAL_CPI_INDEX$cpi_index[ANNUAL_CPI_INDEX$year == reference_year][[1]]
  ANNUAL_CPI_INDEX |>
    mutate(
      reference_price_year = reference_year,
      reference_cpi_index = reference_cpi,
      cpi_adjustment_factor = reference_cpi_index / cpi_index
    ) |>
    as.data.frame(stringsAsFactors = FALSE)
}

harmonize_direct_cost_person_year <- function(direct_cost_df, config) {
  cpi_table <- resolve_cpi_table(config)

  if (!nrow(direct_cost_df)) {
    return(
      direct_cost_df |>
        mutate(
          nominal_cost = numeric(),
          cpi_index = numeric(),
          reference_price_year = integer(),
          cpi_adjustment_factor = numeric(),
          cost_reference_dkk = numeric()
        )
    )
  }

  harmonized <- direct_cost_df |>
    rename(nominal_cost = cost) |>
    left_join(cpi_table[, c("year", "cpi_index", "reference_price_year", "cpi_adjustment_factor")], by = "year")

  if (anyNA(harmonized$cpi_adjustment_factor)) {
    missing_years <- sort(unique(harmonized$year[is.na(harmonized$cpi_adjustment_factor)]))
    stop(sprintf("Missing CPI adjustment factors for years: %s", paste(missing_years, collapse = ", ")))
  }

  harmonized |>
    mutate(cost_reference_dkk = nominal_cost * cpi_adjustment_factor) |>
    arrange(component, person_id, year) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_harmonized_cost_summary <- function(harmonized_cost_df) {
  if (!nrow(harmonized_cost_df)) {
    return(data.frame())
  }

  harmonized_cost_df |>
    group_by(component, year, reference_price_year, coverage_status) |>
    summarise(
      person_year_rows = n(),
      unique_people = n_distinct(person_id),
      nominal_cost_sum = sum(nominal_cost, na.rm = TRUE),
      cost_reference_dkk_sum = sum(cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(component, year, coverage_status) |>
    as.data.frame(stringsAsFactors = FALSE)
}

discount_cost_reference_dkk <- function(cost_reference_dkk, service_year, index_year, discount_rate) {
  exponent <- pmax(0, as.numeric(service_year - index_year))
  if (length(discount_rate) != 1L) {
    stop("discount_rate must be a scalar.")
  }
  if (discount_rate <= 0) {
    return(cost_reference_dkk)
  }
  cost_reference_dkk / ((1 + discount_rate) ^ exponent)
}

write_harmonized_cost_outputs <- function(harmonized_cost_df, harmonized_summary_df, config) {
  ensure_output_dir(config)

  paths <- list(
    harmonized_cost_path = file.path(config$output_dir, "direct_cost_person_year_harmonized.parquet"),
    harmonized_summary_path = file.path(config$output_dir, "direct_cost_person_year_harmonized_summary.csv")
  )

  arrow::write_parquet(harmonized_cost_df, paths$harmonized_cost_path)
  utils::write.csv(harmonized_summary_df, paths$harmonized_summary_path, row.names = FALSE)

  paths
}
