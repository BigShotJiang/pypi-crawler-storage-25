suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

default_match_ratios <- function() {
  c(4L, 3L, 2L, 1L)
}

default_birth_date_caliper_days <- function() {
  31L
}

default_preindex_lag_days <- function() {
  91L
}

resolve_target_ratio <- function(match_ratios) {
  ratios <- as.integer(match_ratios)
  ratios <- ratios[!is.na(ratios) & ratios > 0L]
  if (!length(ratios)) {
    return(1L)
  }
  max(ratios)
}

as_safe_date_distance <- function(left, right) {
  if (is.na(left) || is.na(right)) {
    return(.Machine$integer.max)
  }
  abs(as.integer(left - right))
}

matched_baseline_window <- function(index_date, baseline_years_target, preindex_lag_days = default_preindex_lag_days()) {
  baseline_start <- subtract_year_days(index_date, baseline_years_target)
  baseline_end <- index_date - 1
  preindex_end <- index_date - preindex_lag_days

  list(
    baseline_start = baseline_start,
    baseline_end = baseline_end,
    preindex_end = preindex_end
  )
}

observed_person_years <- function(birth_date, baseline_start, preindex_end) {
  if (is.na(preindex_end) || is.na(baseline_start)) {
    return(NA_real_)
  }

  observed_start <- baseline_start
  if (!is.na(birth_date) && birth_date > observed_start) {
    observed_start <- birth_date
  }

  if (preindex_end < observed_start) {
    return(0)
  }

  as.numeric(preindex_end - observed_start + 1) / 365.25
}

sex_region_key <- function(sex_value, region_value) {
  paste0(ifelse(is.na(sex_value), "NA", as.character(sex_value)), "::", ifelse(is.na(region_value), "", region_value))
}

evaluate_control_for_case <- function(control_row, case_row, birth_date_caliper_days) {
  if (!isTRUE(control_row$unexposed)) {
    return("not_unexposed")
  }
  if (!isTRUE(control_row$is_resident_eligible)) {
    return("not_resident_eligible")
  }
  if (!is.na(control_row$censor_date) && control_row$censor_date < case_row$index_date) {
    return("censored_before_index")
  }
  if (!is.na(control_row$birth_date) && !is.na(case_row$index_date) && control_row$birth_date > case_row$index_date) {
    return("birth_after_index")
  }
  if (!is.na(birth_date_caliper_days) &&
      !is.na(control_row$birth_date) &&
      !is.na(case_row$birth_date) &&
      as_safe_date_distance(control_row$birth_date, case_row$birth_date) > birth_date_caliper_days) {
    return("birth_date_caliper")
  }
  "eligible"
}

evaluate_control_pool_for_case <- function(control_pool, case_row, birth_date_caliper_days) {
  if (!nrow(control_pool)) {
    return(character())
  }

  reasons <- rep("eligible", nrow(control_pool))

  reasons[!control_pool$unexposed] <- "not_unexposed"
  reasons[reasons == "eligible" & !control_pool$is_resident_eligible] <- "not_resident_eligible"
  reasons[reasons == "eligible" & !is.na(control_pool$censor_date) & control_pool$censor_date < case_row$index_date[[1]]] <- "censored_before_index"
  reasons[reasons == "eligible" & !is.na(control_pool$birth_date) & !is.na(case_row$index_date[[1]]) & control_pool$birth_date > case_row$index_date[[1]]] <- "birth_after_index"

  case_birth_date_int <- case_row$birth_date_int[[1]] %||% as.integer(case_row$birth_date[[1]])
  if (!is.na(birth_date_caliper_days) && !is.na(case_birth_date_int)) {
    birth_distance <- abs(control_pool$birth_date_int - case_birth_date_int)
    birth_distance[is.na(birth_distance)] <- .Machine$integer.max
    reasons[reasons == "eligible" & birth_distance > birth_date_caliper_days] <- "birth_date_caliper"
  }

  reasons
}

rank_controls_for_case <- function(control_pool, case_row) {
  if (!nrow(control_pool)) {
    return(control_pool)
  }

  case_birth_date_int <- case_row$birth_date_int[[1]] %||% as.integer(case_row$birth_date[[1]])
  control_pool$birth_date_distance_days <- abs(control_pool$birth_date_int - case_birth_date_int)
  control_pool$birth_date_distance_days[is.na(control_pool$birth_date_distance_days)] <- .Machine$integer.max

  control_pool$util_distance <- abs(dplyr::coalesce(control_pool$preindex_util_total_rate, 0) - dplyr::coalesce(case_row$preindex_util_total_rate, 0))
  control_pool$hosp_distance <- abs(dplyr::coalesce(control_pool$preindex_hosp_days_rate, 0) - dplyr::coalesce(case_row$preindex_hosp_days_rate, 0))

  control_pool[order(
    control_pool$birth_date_distance_days,
    control_pool$util_distance,
    control_pool$hosp_distance,
    control_pool$person_id
  ), , drop = FALSE]
}

select_controls_from_pool <- function(control_pool, case_row, n_needed) {
  if (n_needed <= 0L || !nrow(control_pool)) {
    return(control_pool[0, , drop = FALSE])
  }
  ranked_pool <- rank_controls_for_case(control_pool, case_row)
  ranked_pool[seq_len(min(n_needed, nrow(ranked_pool))), , drop = FALSE]
}

materialize_control_episode <- function(control_row, case_row) {
  adjusted <- control_row
  baseline_years_target <- adjusted$baseline_years_target[[1]] %||% case_row$baseline_years_target[[1]] %||% 5L
  window <- matched_baseline_window(case_row$index_date[[1]], baseline_years_target)
  observed_years <- observed_person_years(
    birth_date = adjusted$birth_date[[1]],
    baseline_start = window$baseline_start,
    preindex_end = window$preindex_end
  )

  adjusted$index_date <- case_row$index_date
  adjusted$baseline_start <- window$baseline_start
  adjusted$baseline_end <- window$baseline_end
  adjusted$baseline_observed_person_years <- observed_years
  adjusted$baseline_years_target <- baseline_years_target
  adjusted$baseline_years_observed <- floor(observed_years)
  adjusted$baseline_years_effective_required <- baseline_years_target
  adjusted$baseline_truncated_by_source_window <- ifelse(
    is.na(adjusted$birth_date[[1]]),
    TRUE,
    adjusted$birth_date[[1]] > window$baseline_start
  )
  adjusted$truncated_lookback_flag <- adjusted$baseline_truncated_by_source_window
  adjusted$exposure_date <- as.Date(NA)
  adjusted$exposed <- FALSE
  adjusted$unexposed <- TRUE
  adjusted$diagnosis_group <- "Unexposed"
  adjusted$severity <- "Unexposed"
  adjusted$scd_is_case <- FALSE
  adjusted$scd_first_date <- as.Date(NA)
  adjusted$scd_first_chapter <- NA_character_
  adjusted
}

build_matched_pairs <- function(case_row, selected_controls, tier_label) {
  if (!nrow(selected_controls)) {
    return(data.frame())
  }

  data.frame(
    case_id = rep(case_row$person_id, nrow(selected_controls)),
    control_id = selected_controls$person_id,
    tier = rep(tier_label, nrow(selected_controls)),
    case_index_date = rep(case_row$index_date, nrow(selected_controls)),
    matched_index_date = rep(case_row$index_date, nrow(selected_controls)),
    case_birth_date = rep(case_row$birth_date, nrow(selected_controls)),
    control_birth_date = selected_controls$birth_date,
    birth_date_distance_days = vapply(
      selected_controls$birth_date,
      function(control_birth_date) as_safe_date_distance(control_birth_date, case_row$birth_date),
      integer(1)
    ),
    municipality = rep(case_row$municipality, nrow(selected_controls)),
    region = rep(case_row$region, nrow(selected_controls)),
    stringsAsFactors = FALSE
  )
}

run_risk_set_matching <- function(
  baseline_df,
  match_ratios = default_match_ratios(),
  seed = 42L,
  birth_date_caliper_days = default_birth_date_caliper_days()
) {
  assert_required_columns(
    baseline_df,
    c("person_id", "exposed", "unexposed", "scd_is_case", "sex", "region",
      "birth_date", "index_date", "censor_date", "is_resident_eligible",
      "preindex_util_total_rate", "preindex_hosp_days_rate"),
    "baseline_df for matching"
  )
  set.seed(as.integer(seed))

  target_ratio <- resolve_target_ratio(match_ratios)
  working_df <- baseline_df
  working_df$municipality[is.na(working_df$municipality)] <- ""
  working_df$region[is.na(working_df$region)] <- ""
  working_df$birth_date_int <- as.integer(working_df$birth_date)

  cases <- working_df |>
    filter(exposed, scd_is_case) |>
    arrange(index_date, person_id)

  controls <- working_df |>
    filter(unexposed) |>
    arrange(person_id)
  control_groups <- split(controls, sex_region_key(controls$sex, controls$region))

  used_controls_env <- new.env(parent = emptyenv(), hash = TRUE)
  matched_pairs_list <- vector("list", nrow(cases))
  matched_case_rows <- vector("list", nrow(cases))
  diagnostics_rows <- vector("list", nrow(cases))
  control_episode_rows <- list()
  exclusion_summary_rows <- list()

  for (i in seq_len(nrow(cases))) {
    case_row <- cases[i, , drop = FALSE]
    case_id <- case_row$person_id[[1]]
    group_key <- sex_region_key(case_row$sex[[1]], case_row$region[[1]])
    control_group <- control_groups[[group_key]]
    if (is.null(control_group)) {
      control_group <- controls[0, , drop = FALSE]
    }

    total_unused_controls <- nrow(controls) - length(ls(envir = used_controls_env, all.names = TRUE))
    if (nrow(control_group)) {
      is_used <- vapply(
        control_group$person_id,
        function(control_id) exists(control_id, envir = used_controls_env, inherits = FALSE),
        logical(1)
      )
      sex_region_pool <- control_group[!is_used, , drop = FALSE]
    } else {
      sex_region_pool <- control_group
    }

    if (nrow(sex_region_pool)) {
      eligibility_reason <- evaluate_control_pool_for_case(
        sex_region_pool,
        case_row,
        birth_date_caliper_days = birth_date_caliper_days
      )
      eligible_controls <- sex_region_pool[eligibility_reason == "eligible", , drop = FALSE]
    } else {
      eligibility_reason <- character()
      eligible_controls <- sex_region_pool
    }

    municipality_pool <- eligible_controls[eligible_controls$municipality == case_row$municipality[[1]], , drop = FALSE]
    municipality_controls <- select_controls_from_pool(municipality_pool, case_row, target_ratio)

    remaining_needed <- target_ratio - nrow(municipality_controls)
    selected_control_ids <- municipality_controls$person_id

    region_pool <- eligible_controls[!(eligible_controls$person_id %in% selected_control_ids), , drop = FALSE]
    region_controls <- select_controls_from_pool(region_pool, case_row, remaining_needed)

    selected_controls <- bind_rows(municipality_controls, region_controls)
    if (nrow(selected_controls)) {
      for (control_id in selected_controls$person_id) {
        assign(control_id, TRUE, envir = used_controls_env)
      }
    }

    municipality_pairs <- build_matched_pairs(case_row, municipality_controls, "municipality")
    region_pairs <- build_matched_pairs(case_row, region_controls, "region_fallback")
    matched_pairs <- bind_rows(municipality_pairs, region_pairs)
    matched_pairs_list[[i]] <- matched_pairs

    if (nrow(selected_controls)) {
      matched_case_rows[[i]] <- case_row
      control_episode_rows[[i]] <- bind_rows(lapply(seq_len(nrow(selected_controls)), function(j) {
        materialize_control_episode(selected_controls[j, , drop = FALSE], case_row)
      }))
    } else {
      matched_case_rows[[i]] <- case_row[0, , drop = FALSE]
      control_episode_rows[[i]] <- selected_controls[0, , drop = FALSE]
    }

    diagnostics_rows[[i]] <- data.frame(
      case_id = case_id,
      case_index_date = case_row$index_date[[1]],
      unused_controls = total_unused_controls,
      same_sex_region_candidates = nrow(sex_region_pool),
      eligible_candidates = nrow(eligible_controls),
      municipality_candidates = nrow(municipality_pool),
      region_fallback_candidates = nrow(region_pool),
      municipality_matches = nrow(municipality_controls),
      region_fallback_matches = nrow(region_controls),
      achieved_controls = nrow(selected_controls),
      target_controls = target_ratio,
      fully_matched = nrow(selected_controls) >= target_ratio,
      stringsAsFactors = FALSE
    )

    exclusion_counts <- table(factor(
      eligibility_reason,
      levels = c(
        "eligible",
        "not_unexposed",
        "not_resident_eligible",
        "censored_before_index",
        "birth_after_index",
        "birth_date_caliper"
      )
    ))
    exclusion_summary_rows[[i]] <- data.frame(
      case_id = case_id,
      reason = names(exclusion_counts),
      count = as.integer(exclusion_counts),
      stringsAsFactors = FALSE
    )
  }

  matched_pairs_df <- bind_rows(matched_pairs_list)
  matched_case_df <- bind_rows(matched_case_rows)
  matched_control_df <- bind_rows(control_episode_rows)
  matched_cohort_df <- bind_rows(matched_case_df, matched_control_df) |>
    arrange(index_date, desc(exposed), person_id) |>
    distinct(person_id, index_date, exposed, .keep_all = TRUE)

  if (nrow(matched_pairs_df)) {
    set_sizes <- matched_pairs_df |>
      group_by(case_id) |>
      summarise(n_controls = n(), .groups = "drop")
    control_set_info <- matched_pairs_df[, c("control_id", "case_id"), drop = FALSE]
    control_set_info <- control_set_info[!duplicated(control_set_info$control_id), , drop = FALSE]
    names(control_set_info) <- c("person_id", "matched_set_id")
    matched_cohort_df <- matched_cohort_df |>
      left_join(control_set_info, by = "person_id") |>
      mutate(matched_set_id = ifelse(exposed, person_id, matched_set_id)) |>
      left_join(set_sizes, by = c("matched_set_id" = "case_id")) |>
      mutate(
        n_controls = dplyr::coalesce(n_controls, 0L),
        match_weight = ifelse(exposed, 1, ifelse(n_controls > 0L, 1 / n_controls, NA_real_))
      )
  } else {
    matched_cohort_df$matched_set_id <- NA_character_
    matched_cohort_df$n_controls <- 0L
    matched_cohort_df$match_weight <- NA_real_
  }

  diagnostics_df <- bind_rows(diagnostics_rows)
  exclusion_summary_df <- bind_rows(exclusion_summary_rows) |>
    group_by(reason) |>
    summarise(count = sum(count), .groups = "drop")
  summary_df <- data.frame(
    metric = c(
      "eligible_cases",
      "matched_cases",
      "unmatched_cases",
      "matched_pairs",
      "municipality_pairs",
      "region_fallback_pairs",
      "target_ratio",
      "birth_date_caliper_days"
    ),
    value = c(
      nrow(cases),
      sum(diagnostics_df$achieved_controls > 0),
      sum(diagnostics_df$achieved_controls == 0),
      nrow(matched_pairs_df),
      sum(matched_pairs_df$tier == "municipality"),
      sum(matched_pairs_df$tier == "region_fallback"),
      target_ratio,
      birth_date_caliper_days
    ),
    stringsAsFactors = FALSE
  )

  list(
    matched_pairs = matched_pairs_df,
    matched_cohort = matched_cohort_df,
    diagnostics = diagnostics_df,
    summary = summary_df,
    matching_exclusion_summary = exclusion_summary_df
  )
}

write_matching_outputs <- function(
  baseline_df,
  config,
  match_ratios = default_match_ratios(),
  seed = 42L,
  birth_date_caliper_days = default_birth_date_caliper_days()
) {
  ensure_output_dir(config)
  result <- run_risk_set_matching(
    baseline_df,
    match_ratios = match_ratios,
    seed = seed,
    birth_date_caliper_days = birth_date_caliper_days
  )

  matched_pairs_path <- file.path(config$output_dir, "matched_pairs.parquet")
  matched_cohort_path <- file.path(config$output_dir, "matched_cohort.parquet")
  diagnostics_path <- file.path(config$output_dir, "matching_diagnostics.csv")
  summary_path <- file.path(config$output_dir, "matching_summary.csv")
  exclusion_summary_path <- file.path(config$output_dir, "matching_exclusion_summary.csv")

  arrow::write_parquet(result$matched_pairs, matched_pairs_path)
  arrow::write_parquet(result$matched_cohort, matched_cohort_path)
  utils::write.csv(result$diagnostics, diagnostics_path, row.names = FALSE)
  utils::write.csv(result$summary, summary_path, row.names = FALSE)
  utils::write.csv(result$matching_exclusion_summary, exclusion_summary_path, row.names = FALSE)

  list(
    matched_pairs_path = matched_pairs_path,
    matched_cohort_path = matched_cohort_path,
    diagnostics_path = diagnostics_path,
    summary_path = summary_path,
    exclusion_summary_path = exclusion_summary_path
  )
}
