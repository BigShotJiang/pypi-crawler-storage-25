suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

safe_numeric <- function(x) {
  value <- suppressWarnings(as.numeric(x))
  ifelse(is.na(value), 0, value)
}

load_register_usage_tables <- function(config, person_ids = NULL) {
  registers_root <- config$registers_dir
  lpr_proxy_path <- file.path(registers_root, "lpr", "lpr_proxy_usage.parquet")
  lmdb_usage_path <- file.path(registers_root, "prescriptions", "lmdb_usage.parquet")
  lmdb_atc_path <- file.path(registers_root, "prescriptions", "lmdb_atc_level3.parquet")
  primary_sector_path <- file.path(registers_root, "primary_sector", "primary_sector_usage.parquet")

  required_paths <- c(lpr_proxy_path, lmdb_usage_path, lmdb_atc_path, primary_sector_path)
  missing_required <- required_paths[!file.exists(required_paths)]
  if (length(missing_required)) {
    stop(sprintf("Missing required register usage artifacts: %s", paste(missing_required, collapse = ", ")))
  }

  hospital_drugs_path <- normalizePath(config$hospital_drugs_usage_path, winslash = "/", mustWork = FALSE)
  hospital_drugs_enabled <- isTRUE(config$use_hospital_drugs)
  hospital_drugs_available <- hospital_drugs_enabled && file.exists(hospital_drugs_path)

  filter_ids <- if (length(person_ids)) as.character(person_ids) else NULL

  read_register <- function(path) {
    ds <- arrow::open_dataset(path, format = "parquet")
    if (!is.null(filter_ids)) {
      ds <- ds |> filter(as.character(person_id) %in% filter_ids)
    }
    ds |> collect() |> as.data.frame(stringsAsFactors = FALSE)
  }

  list(
    lpr_proxy = read_register(lpr_proxy_path),
    lmdb_usage = read_register(lmdb_usage_path),
    lmdb_atc = read_register(lmdb_atc_path),
    primary_sector = read_register(primary_sector_path),
    hospital_drugs = if (hospital_drugs_available) read_register(hospital_drugs_path) else NULL,
    hospital_drugs_enabled = hospital_drugs_enabled,
    hospital_drugs_available = hospital_drugs_available,
    hospital_drugs_path = hospital_drugs_path
  )
}

build_preindex_component_years <- function(registers) {
  lpr_df <- registers$lpr_proxy |>
    transmute(
      person_id,
      year = as.integer(year),
      proxy_total = as.numeric(proxy_index),
      raw_total = as.numeric(contacts) + as.numeric(episodes),
      hosp_days_total = as.numeric(bed_days),
      proxy_seen = TRUE,
      raw_seen = TRUE,
      hosp_days_seen = TRUE
    )

  lmdb_atc_distinct <- registers$lmdb_atc |>
    distinct(person_id, year, atc_code) |>
    count(person_id, year, name = "atc_distinct")

  lmdb_df <- registers$lmdb_usage |>
    left_join(lmdb_atc_distinct, by = c("person_id", "year")) |>
    mutate(
      atc_distinct = dplyr::coalesce(as.numeric(atc_distinct), 0),
      proxy_total = as.numeric(dispenses) + 0.25 * atc_distinct,
      raw_total = as.numeric(dispenses),
      hosp_days_total = 0,
      proxy_seen = TRUE,
      raw_seen = TRUE,
      hosp_days_seen = FALSE
    ) |>
    transmute(
      person_id,
      year = as.integer(year),
      proxy_total,
      raw_total,
      hosp_days_total,
      proxy_seen,
      raw_seen,
      hosp_days_seen
    )

  primary_df <- registers$primary_sector |>
    mutate(
      contacts = pmax(safe_numeric(contacts), 0),
      services = pmax(safe_numeric(services), 0),
      proxy_total = contacts + 0.5 * services,
      raw_total = contacts + services,
      hosp_days_total = 0,
      proxy_seen = TRUE,
      raw_seen = TRUE,
      hosp_days_seen = FALSE
    ) |>
    transmute(
      person_id,
      year = as.integer(year),
      proxy_total,
      raw_total,
      hosp_days_total,
      proxy_seen,
      raw_seen,
      hosp_days_seen
    )

  component_df <- bind_rows(lpr_df, lmdb_df, primary_df)

  if (!is.null(registers$hospital_drugs)) {
    hospital_df <- registers$hospital_drugs
    dispenses_col <- intersect(c("dispenses", "packages", "volume"), names(hospital_df))
    if (!length(dispenses_col)) {
      stop(
        sprintf(
          "Hospital-drugs parquet at %s is missing a usable count column.",
          registers$hospital_drugs_path
        )
      )
    }

    hospital_component_df <- hospital_df |>
      transmute(
        person_id,
        year = as.integer(year),
        proxy_total = 0,
        raw_total = as.numeric(.data[[dispenses_col[[1]]]]),
        hosp_days_total = 0,
        proxy_seen = FALSE,
        raw_seen = TRUE,
        hosp_days_seen = FALSE
      )

    component_df <- bind_rows(component_df, hospital_component_df)
  }

  component_df |>
    group_by(person_id, year) |>
    summarise(
      proxy_total = sum(proxy_total, na.rm = TRUE),
      raw_total = sum(raw_total, na.rm = TRUE),
      hosp_days_total = sum(hosp_days_total, na.rm = TRUE),
      proxy_seen = any(proxy_seen),
      raw_seen = any(raw_seen),
      hosp_days_seen = any(hosp_days_seen),
      .groups = "drop"
    )
}

compute_preindex_metrics <- function(baseline_df, config) {
  person_ids <- unique(as.character(baseline_df$person_id))
  person_ids <- person_ids[!is.na(person_ids) & nzchar(person_ids)]
  registers <- load_register_usage_tables(config, person_ids = person_ids)
  component_years <- build_preindex_component_years(registers)

  # Compute per-person observation windows (fully vectorized)
  index_dates_v  <- as.Date(baseline_df$index_date)
  fixed_start    <- index_dates_v - config$baseline_years_target * 365L
  fixed_end      <- index_dates_v - config$preindex_lag_days
  baseline_start <- as.Date(baseline_df$baseline_start)
  baseline_end   <- as.Date(baseline_df$baseline_end)
  birth_date     <- as.Date(baseline_df$birth_date)

  obs_start_raw <- pmax(fixed_start, baseline_start, na.rm = TRUE)
  birth_adj     <- !is.na(birth_date) & birth_date > obs_start_raw
  obs_start     <- as.Date(
    ifelse(birth_adj, as.numeric(birth_date), as.numeric(obs_start_raw)),
    origin = "1970-01-01"
  )
  obs_end <- pmin(fixed_end, baseline_end, na.rm = TRUE)

  windows_df <- data.frame(
    person_id = baseline_df$person_id,
    obs_start = obs_start,
    obs_end   = obs_end,
    stringsAsFactors = FALSE
  )

  # Join component-years with person windows, compute year-overlap fractions
  aggregated <- component_years |>
    inner_join(windows_df, by = "person_id") |>
    filter(obs_end >= obs_start) |>
    mutate(
      yr_start = as.Date(paste0(year, "-01-01")),
      yr_end   = as.Date(paste0(year, "-12-31")),
      yr_days  = as.numeric(yr_end - yr_start) + 1,
      ol_start = pmax(obs_start, yr_start),
      ol_end   = pmin(obs_end,   yr_end),
      fraction = ifelse(ol_end >= ol_start, (as.numeric(ol_end - ol_start) + 1) / yr_days, 0)
    ) |>
    filter(fraction > 0) |>
    mutate(
      proxy_contrib     = ifelse(proxy_seen,     proxy_total     * fraction, 0),
      raw_contrib       = ifelse(raw_seen,       raw_total       * fraction, 0),
      hosp_days_contrib = ifelse(hosp_days_seen, hosp_days_total * fraction, 0)
    ) |>
    group_by(person_id) |>
    summarise(
      proxy_total_w      = sum(proxy_contrib,     na.rm = TRUE),
      raw_total_w        = sum(raw_contrib,       na.rm = TRUE),
      hosp_days_total_w  = sum(hosp_days_contrib, na.rm = TRUE),
      proxy_seen_any     = any(proxy_seen),
      raw_seen_any       = any(raw_seen),
      hosp_days_seen_any = any(hosp_days_seen),
      .groups = "drop"
    )

  result <- data.frame(person_id = baseline_df$person_id, stringsAsFactors = FALSE) |>
    left_join(aggregated, by = "person_id") |>
    mutate(
      preindex_util_total_numerator = dplyr::case_when(
        !is.na(proxy_seen_any) & proxy_seen_any ~ proxy_total_w,
        !is.na(raw_seen_any)   & raw_seen_any   ~ raw_total_w,
        TRUE ~ NA_real_
      ),
      preindex_hosp_days_numerator = ifelse(
        !is.na(hosp_days_seen_any) & hosp_days_seen_any,
        hosp_days_total_w,
        NA_real_
      )
    )

  data.frame(
    preindex_util_total_numerator        = result$preindex_util_total_numerator,
    preindex_hosp_days_numerator         = result$preindex_hosp_days_numerator,
    preindex_util_missing_hospital_drugs = !registers$hospital_drugs_available,
    stringsAsFactors = FALSE
  )
}
