suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

empty_component_year_availability <- function() {
  data.frame(
    component = character(),
    year = integer(),
    coverage_status = character(),
    source_tables = character(),
    source_files = character(),
    data_available = logical(),
    stringsAsFactors = FALSE
  )
}

# Vectorized segment builder: loops over persons (O(N_persons)) but vectorizes the
# inner year work, reducing data.frame() calls from O(N_persons × N_years) to
# O(N_persons × 2) — one per segment type per person.
build_cost_panel_segments_vectorized <- function(matched_df, followup_years = 5L) {
  valid <- !is.na(matched_df$index_date) & !is.na(matched_df$baseline_start)
  if (!any(valid)) return(data.frame())
  df <- matched_df[valid, , drop = FALSE]
  n  <- nrow(df)

  index_date     <- as.Date(df$index_date)
  baseline_start <- as.Date(df$baseline_start)
  censor_date    <- df$censor_date

  study_end_unc <- add_years_vec(index_date, followup_years) - 1L
  study_end     <- study_end_unc
  has_censor    <- !is.na(censor_date)
  if (any(has_censor)) {
    study_end[has_censor] <- pmin(as.Date(censor_date[has_censor]), study_end_unc[has_censor])
  }

  index_year <- as.integer(format(index_date, "%Y"))
  start_year <- as.integer(format(baseline_start, "%Y"))
  end_year   <- as.integer(format(study_end, "%Y"))

  all_rows <- vector("list", n)

  for (i in seq_len(n)) {
    yrs <- start_year[i]:end_year[i]
    if (!length(yrs)) next

    yr_start <- as.Date(paste0(yrs, "-01-01"))
    yr_end   <- as.Date(paste0(yrs, "-12-31"))
    yr_days  <- as.numeric(yr_end - yr_start) + 1

    ps     <- pmax(yr_start, baseline_start[i])
    pe     <- pmin(yr_end,   index_date[i] - 1L)
    pre_ok <- pe >= ps

    qs      <- pmax(yr_start, index_date[i])
    qe      <- pmin(yr_end,   study_end[i])
    post_ok <- qe >= qs

    parts <- list()
    if (any(pre_ok)) {
      parts[[1]] <- data.frame(
        person_id         = df$person_id[i],
        exposed           = as.logical(df$exposed[i]),
        diagnosis_group   = df$diagnosis_group[i],
        severity          = df$severity[i],
        index_date        = index_date[i],
        calendar_year     = yrs[pre_ok],
        segment           = "pre_index",
        relative_year     = as.integer(yrs[pre_ok] - index_year[i]),
        segment_start     = ps[pre_ok],
        segment_end       = pe[pre_ok],
        observed_fraction = as.numeric(pe[pre_ok] - ps[pre_ok] + 1) / yr_days[pre_ok],
        stringsAsFactors  = FALSE
      )
    }
    if (any(post_ok)) {
      parts[[2]] <- data.frame(
        person_id         = df$person_id[i],
        exposed           = as.logical(df$exposed[i]),
        diagnosis_group   = df$diagnosis_group[i],
        severity          = df$severity[i],
        index_date        = index_date[i],
        calendar_year     = yrs[post_ok],
        segment           = "post_index",
        relative_year     = as.integer(yrs[post_ok] - index_year[i]),
        segment_start     = qs[post_ok],
        segment_end       = qe[post_ok],
        observed_fraction = as.numeric(qe[post_ok] - qs[post_ok] + 1) / yr_days[post_ok],
        stringsAsFactors  = FALSE
      )
    }
    all_rows[[i]] <- bind_rows(parts)
  }

  bind_rows(all_rows)
}

reshape_direct_cost_wide <- function(direct_cost_df) {
  if (!nrow(direct_cost_df)) {
    return(data.frame(
      person_id = character(),
      calendar_year = integer(),
      lmdb_cost = numeric(),
      hospital_drugs_cost = numeric(),
      lpr_sghforlob_cost = numeric(),
      lpr_kontakt_cost = numeric(),
      primary_sector_cost = numeric(),
      total_direct_cost = numeric(),
      stringsAsFactors = FALSE
    ))
  }

  cost_by_component <- direct_cost_df |>
    group_by(person_id, year, component) |>
    summarise(cost = sum(cost, na.rm = TRUE), .groups = "drop")

  component_levels <- c("lmdb", "hospital_drugs", "lpr_sghforlob", "lpr_kontakt", "primary_sector")
  split_rows <- split(cost_by_component, cost_by_component$component)

  merged <- Reduce(
    function(lhs, rhs) full_join(lhs, rhs, by = c("person_id", "year")),
    Filter(
      Negate(is.null),
      lapply(component_levels, function(component_name) {
        component_df <- split_rows[[component_name]]
        if (is.null(component_df)) {
          return(NULL)
        }
        col_name <- paste0(component_name, "_cost")
        names(component_df)[names(component_df) == "cost"] <- col_name
        component_df[, c("person_id", "year", col_name), drop = FALSE]
      })
    )
  )

  if (is.null(merged) || !nrow(merged)) {
    merged <- data.frame(person_id = character(), year = integer(), stringsAsFactors = FALSE)
  }

  for (component_name in component_levels) {
    col_name <- paste0(component_name, "_cost")
    if (!(col_name %in% names(merged))) {
      merged[[col_name]] <- numeric(nrow(merged))
    }
    merged[[col_name]][is.na(merged[[col_name]])] <- 0
  }

  merged$total_direct_cost <- merged$lmdb_cost + merged$hospital_drugs_cost + merged$lpr_sghforlob_cost +
    merged$lpr_kontakt_cost + merged$primary_sector_cost
  merged$calendar_year <- merged$year
  merged$year <- NULL
  merged
}

reshape_component_year_availability_wide <- function(component_year_availability) {
  if (is.null(component_year_availability) || !nrow(component_year_availability)) {
    return(data.frame(
      calendar_year = integer(),
      lmdb_data_available = logical(),
      hospital_drugs_data_available = logical(),
      lpr_sghforlob_data_available = logical(),
      lpr_kontakt_data_available = logical(),
      primary_sector_data_available = logical(),
      lmdb_coverage_status = character(),
      hospital_drugs_coverage_status = character(),
      lpr_sghforlob_coverage_status = character(),
      lpr_kontakt_coverage_status = character(),
      primary_sector_coverage_status = character(),
      stringsAsFactors = FALSE
    ))
  }

  availability <- component_year_availability |>
    select(component, year, data_available, coverage_status)

  component_levels <- c("lmdb", "hospital_drugs", "lpr_sghforlob", "lpr_kontakt", "primary_sector")
  split_rows <- split(availability, availability$component)

  merged <- Reduce(
    function(lhs, rhs) full_join(lhs, rhs, by = "year"),
    Filter(
      Negate(is.null),
      lapply(component_levels, function(component_name) {
        component_df <- split_rows[[component_name]]
        if (is.null(component_df)) {
          return(NULL)
        }
        names(component_df)[names(component_df) == "data_available"] <- paste0(component_name, "_data_available")
        names(component_df)[names(component_df) == "coverage_status"] <- paste0(component_name, "_coverage_status")
        component_df[, c("year", paste0(component_name, "_data_available"), paste0(component_name, "_coverage_status")), drop = FALSE]
      })
    )
  )

  if (is.null(merged) || !nrow(merged)) {
    merged <- data.frame(year = integer(), stringsAsFactors = FALSE)
  }

  for (component_name in component_levels) {
    available_col <- paste0(component_name, "_data_available")
    coverage_col <- paste0(component_name, "_coverage_status")
    if (!(available_col %in% names(merged))) {
      merged[[available_col]] <- FALSE
    }
    if (!(coverage_col %in% names(merged))) {
      merged[[coverage_col]] <- "missing"
    }
    merged[[available_col]][is.na(merged[[available_col]])] <- FALSE
    merged[[coverage_col]][is.na(merged[[coverage_col]])] <- "missing"
  }

  merged$calendar_year <- merged$year
  merged$year <- NULL
  merged
}

build_cost_panel <- function(matched_df, direct_cost_df, component_year_availability = NULL, followup_years = 5L) {
  segment_rows <- build_cost_panel_segments_vectorized(matched_df, followup_years = followup_years)

  if (!nrow(segment_rows)) {
    return(segment_rows)
  }

  direct_cost_wide <- reshape_direct_cost_wide(direct_cost_df)
  if (is.null(component_year_availability)) {
    component_year_availability <- empty_component_year_availability()
  }
  availability_wide <- reshape_component_year_availability_wide(component_year_availability)

  panel <- segment_rows |>
    left_join(direct_cost_wide, by = c("person_id", "calendar_year")) |>
    left_join(availability_wide, by = "calendar_year") |>
    mutate(
      lmdb_cost = dplyr::coalesce(lmdb_cost, 0),
      hospital_drugs_cost = dplyr::coalesce(hospital_drugs_cost, 0),
      lpr_sghforlob_cost = dplyr::coalesce(lpr_sghforlob_cost, 0),
      lpr_kontakt_cost = dplyr::coalesce(lpr_kontakt_cost, 0),
      primary_sector_cost = dplyr::coalesce(primary_sector_cost, 0),
      total_direct_cost = dplyr::coalesce(total_direct_cost, 0),
      lmdb_data_available = dplyr::coalesce(lmdb_data_available, FALSE),
      hospital_drugs_data_available = dplyr::coalesce(hospital_drugs_data_available, FALSE),
      lpr_sghforlob_data_available = dplyr::coalesce(lpr_sghforlob_data_available, FALSE),
      lpr_kontakt_data_available = dplyr::coalesce(lpr_kontakt_data_available, FALSE),
      primary_sector_data_available = dplyr::coalesce(primary_sector_data_available, FALSE),
      lmdb_coverage_status = dplyr::coalesce(lmdb_coverage_status, "missing"),
      hospital_drugs_coverage_status = dplyr::coalesce(hospital_drugs_coverage_status, "missing"),
      lpr_sghforlob_coverage_status = dplyr::coalesce(lpr_sghforlob_coverage_status, "missing"),
      lpr_kontakt_coverage_status = dplyr::coalesce(lpr_kontakt_coverage_status, "missing"),
      primary_sector_coverage_status = dplyr::coalesce(primary_sector_coverage_status, "missing"),
      lmdb_cost_weighted = lmdb_cost * observed_fraction,
      hospital_drugs_cost_weighted = hospital_drugs_cost * observed_fraction,
      lpr_sghforlob_cost_weighted = lpr_sghforlob_cost * observed_fraction,
      lpr_kontakt_cost_weighted = lpr_kontakt_cost * observed_fraction,
      primary_sector_cost_weighted = primary_sector_cost * observed_fraction,
      total_direct_cost_weighted = total_direct_cost * observed_fraction
    ) |>
    arrange(person_id, calendar_year, segment)

  as.data.frame(panel, stringsAsFactors = FALSE)
}

build_cost_panel_summary <- function(cost_panel_df) {
  if (!nrow(cost_panel_df)) {
    return(data.frame())
  }

  cost_panel_df |>
    group_by(segment, relative_year, exposed) |>
    summarise(
      rows = n(),
      people = n_distinct(person_id),
      observed_fraction_mean = mean(observed_fraction, na.rm = TRUE),
      total_direct_cost_weighted_sum = sum(total_direct_cost_weighted, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(segment, relative_year, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_cost_panel_data_availability_summary <- function(cost_panel_df) {
  if (!nrow(cost_panel_df)) {
    return(data.frame())
  }

  cost_panel_df |>
    group_by(segment, relative_year, exposed) |>
    summarise(
      rows = n(),
      people = n_distinct(person_id),
      lmdb_year_available_share = mean(lmdb_data_available, na.rm = TRUE),
      hospital_drugs_year_available_share = mean(hospital_drugs_data_available, na.rm = TRUE),
      lpr_sghforlob_year_available_share = mean(lpr_sghforlob_data_available, na.rm = TRUE),
      lpr_kontakt_year_available_share = mean(lpr_kontakt_data_available, na.rm = TRUE),
      primary_sector_year_available_share = mean(primary_sector_data_available, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(segment, relative_year, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

write_cost_panel_outputs <- function(cost_panel_df, config, panel_summary = NULL, data_availability_summary = NULL) {
  ensure_output_dir(config)

  if (is.null(panel_summary)) {
    panel_summary <- build_cost_panel_summary(cost_panel_df)
  }
  if (is.null(data_availability_summary)) {
    data_availability_summary <- build_cost_panel_data_availability_summary(cost_panel_df)
  }

  paths <- list(
    cost_panel_path = file.path(config$output_dir, "matched_cost_panel.parquet"),
    cost_panel_summary_path = file.path(config$output_dir, "matched_cost_panel_summary.csv"),
    cost_panel_data_availability_summary_path = file.path(config$output_dir, "matched_cost_panel_data_availability_summary.csv")
  )

  arrow::write_parquet(cost_panel_df, paths$cost_panel_path)
  utils::write.csv(panel_summary, paths$cost_panel_summary_path, row.names = FALSE)
  utils::write.csv(data_availability_summary, paths$cost_panel_data_availability_summary_path, row.names = FALSE)

  paths
}
