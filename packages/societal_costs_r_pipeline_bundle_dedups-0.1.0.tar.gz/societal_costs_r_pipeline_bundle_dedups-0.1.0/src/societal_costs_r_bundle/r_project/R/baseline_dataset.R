suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

# ---- Vectorized category helpers ------------------------------------------

cohabitation_group_vec <- function(family_type, civil_status) {
  result <- rep("unknown", length(family_type))
  by_family <- !is.na(family_type) & family_type %in% c(1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L)
  status <- toupper(trimws(ifelse(is.na(civil_status), "", as.character(civil_status))))
  by_civil_coh  <- !by_family & !is.na(civil_status) & status %in% c("G", "M")
  by_civil_sing <- !by_family & !by_civil_coh & !is.na(civil_status) & status %in% c("U", "S", "F", "E")
  result[by_family | by_civil_coh] <- "cohabiting"
  result[by_civil_sing] <- "single_or_noncohabiting"
  result
}

ethnicity_group_vec <- function(origin_country, ie_type) {
  result <- rep("unknown", length(origin_country))
  known  <- !is.na(origin_country)
  dk     <- known & origin_country == 5100L
  non_dk <- known & !dk
  result[non_dk & (is.na(ie_type) | !ie_type %in% c(1L, 2L))] <- "other_non_danish"
  result[non_dk & !is.na(ie_type) & ie_type %in% c(1L, 2L)]   <- "immigrant_or_descendant"
  result[dk] <- "danish"
  result
}

gest_age_category_vec <- function(gestational_age_days) {
  result <- rep(NA_character_, length(gestational_age_days))
  valid  <- !is.na(gestational_age_days) & gestational_age_days > 0L
  if (any(valid)) {
    result[valid] <- as.character(cut(
      gestational_age_days[valid],
      breaks = c(0L, 224L, 259L, 294L, Inf),
      labels = c("lt_32w", "32_36w", "37_41w", "42w_plus"),
      right  = FALSE
    ))
  }
  result
}

birth_weight_category_vec <- function(birth_weight_grams) {
  result <- rep(NA_character_, length(birth_weight_grams))
  valid  <- !is.na(birth_weight_grams) & birth_weight_grams > 0L
  if (any(valid)) {
    result[valid] <- as.character(cut(
      birth_weight_grams[valid],
      breaks = c(0L, 1500L, 2500L, 4000L, Inf),
      labels = c("lt_1500g", "1500_2499g", "2500_3999g", "4000_plus_g"),
      right  = FALSE
    ))
  }
  result
}

parity_category_vec <- function(parity) {
  result <- rep(NA_character_, length(parity))
  valid  <- !is.na(parity) & parity >= 0L
  result[valid & parity >= 4L] <- "4_plus"
  result[valid & parity < 4L]  <- as.character(as.integer(parity[valid & parity < 4L]))
  result
}

multiple_birth_category_vec <- function(multiple_birth_flag, births_count) {
  result     <- rep(NA_character_, length(multiple_birth_flag))
  flag_known <- !is.na(multiple_birth_flag)
  result[flag_known] <- ifelse(multiple_birth_flag[flag_known] > 0L, "yes", "no")
  count_only <- !flag_known & !is.na(births_count)
  result[count_only] <- ifelse(births_count[count_only] > 1L, "yes", "no")
  result
}

maternal_age_group_vec <- function(age) {
  result <- rep(NA_character_, length(age))
  valid  <- !is.na(age) & age > 0L
  if (any(valid)) {
    result[valid] <- as.character(cut(
      age[valid],
      breaks = c(0L, 25L, 30L, 35L, Inf),
      labels = c("lt_25", "25_29", "30_34", "35_plus"),
      right  = FALSE
    ))
  }
  result
}

apgar_category_vec <- function(score) {
  result <- rep(NA_character_, length(score))
  valid  <- !is.na(score) & !score %in% c(-1L, 99L) & score >= 0L & score <= 10L
  if (any(valid)) {
    result[valid] <- as.character(cut(
      score[valid],
      breaks = c(-1L, 3L, 6L, 10L),
      labels = c("0_3", "4_6", "7_10"),
      right  = TRUE
    ))
  }
  result
}

observed_person_years_vec <- function(birth_date, baseline_start, preindex_end) {
  result    <- rep(NA_real_, length(birth_date))
  valid     <- !is.na(preindex_end) & !is.na(baseline_start)
  obs_start <- as.Date(baseline_start)
  birth_later <- valid & !is.na(birth_date) & as.Date(birth_date) > obs_start
  obs_start[birth_later] <- as.Date(birth_date)[birth_later]
  degenerate <- valid & as.Date(preindex_end) < obs_start
  result[degenerate] <- 0
  good <- valid & !degenerate
  result[good] <- as.numeric(as.Date(preindex_end)[good] - obs_start[good] + 1L) / 365.25
  result
}

first_preferred_value <- function(x) {
  if (!length(x)) {
    return(x)
  }

  if (inherits(x, "Date")) {
    idx <- which(!is.na(x))
    if (!length(idx)) return(as.Date(NA))
    return(x[[idx[[1L]]]])
  }

  if (is.character(x)) {
    normalized <- trimws(x)
    idx <- which(!is.na(normalized) & nzchar(normalized))
    if (!length(idx)) return(NA_character_)
    return(x[[idx[[1L]]]])
  }

  if (is.factor(x)) {
    idx <- which(!is.na(x))
    if (!length(idx)) return(factor(NA, levels = levels(x)))
    return(x[[idx[[1L]]]])
  }

  idx <- which(!is.na(x))
  if (!length(idx)) {
    return(x[[1L]])
  }
  x[[idx[[1L]]]]
}

collapse_person_level_rows <- function(df, source_name, key = "person_id") {
  if (!nrow(df)) {
    return(df)
  }

  df <- distinct(df)
  dup_counts <- df |>
    count(.data[[key]], name = "n") |>
    filter(.data$n > 1L)

  if (!nrow(dup_counts)) {
    return(df)
  }

  message(
    sprintf(
      "Collapsing duplicated `%s` rows in %s for %s persons.",
      key,
      source_name,
      nrow(dup_counts)
    )
  )

  by_person <- split(df, df[[key]])
  collapsed <- lapply(by_person, function(person_rows) {
    if (nrow(person_rows) == 1L) {
      return(person_rows)
    }

    out <- person_rows[1, , drop = FALSE]
    for (col in setdiff(names(person_rows), key)) {
      out[[col]] <- first_preferred_value(person_rows[[col]])
    }
    out
  })

  bind_rows(collapsed)
}

select_cohort_base_snapshots <- function(index_rows, cohort_base_rows) {
  if (!nrow(index_rows)) {
    return(cohort_base_rows[0, , drop = FALSE])
  }

  cb <- rename(cohort_base_rows, cb_index_date = index_date)

  # Latest snapshot at or before index_date
  matched <- index_rows |>
    left_join(cb, by = "person_id") |>
    filter(cb_index_date <= index_date) |>
    group_by(person_id, index_date) |>
    slice_max(cb_index_date, n = 1, with_ties = FALSE) |>
    ungroup() |>
    select(-cb_index_date)

  # Fallback: no at-or-before snapshot → use the latest snapshot overall
  needs_fallback <- anti_join(index_rows, matched, by = c("person_id", "index_date"))
  if (nrow(needs_fallback)) {
    fallback_rate <- nrow(needs_fallback) / nrow(index_rows)
    if (fallback_rate > 0.1) {
      warning(sprintf(
        "select_cohort_base_snapshots: %d of %d index rows (%.0f%%) have no at-or-before cohort_base snapshot — using latest available. Check cohort_base coverage dates.",
        nrow(needs_fallback), nrow(index_rows), fallback_rate * 100
      ), call. = FALSE)
    }
    cb_last <- cb |>
      group_by(person_id) |>
      slice_max(cb_index_date, n = 1, with_ties = FALSE) |>
      ungroup() |>
      select(-cb_index_date)
    fallback <- needs_fallback |> left_join(cb_last, by = "person_id")
    matched  <- bind_rows(matched, fallback)
  }

  as.data.frame(matched, stringsAsFactors = FALSE)
}

build_baseline_dataset <- function(config) {
  ensure_output_dir(config)
  inventory_input_artifacts(config)
  sources <- load_baseline_source_datasets(config)

  cohort_censoring_df <- sources$cohort_censoring |>
    collect() |>
    as.data.frame(stringsAsFactors = FALSE)
  cohort_censoring_df$person_id <- as.character(cohort_censoring_df$person_id)
  cohort_person_ids <- unique(cohort_censoring_df$person_id)
  cohort_base_df <- sources$cohort_base |>
    filter(person_id %in% cohort_person_ids) |>
    collect() |>
    as.data.frame(stringsAsFactors = FALSE)
  cohort_base_df$person_id <- as.character(cohort_base_df$person_id)
  scd_results_df <- sources$scd_results |>
    filter(person_id %in% cohort_person_ids) |>
    collect() |>
    as.data.frame(stringsAsFactors = FALSE)
  scd_results_df$person_id <- as.character(scd_results_df$person_id)
  mfr_child_birth_fact_df <- sources$mfr_child_birth_fact |>
    rename(
      mother_id_mfr = mother_id,
      father_id_mfr = father_id,
      maternal_age_birth = maternal_age
    ) |>
    filter(person_id %in% cohort_person_ids) |>
    collect() |>
    as.data.frame(stringsAsFactors = FALSE)
  mfr_child_birth_fact_df$person_id <- as.character(mfr_child_birth_fact_df$person_id)
  relations_index_df <- sources$relations_index |>
    rename(
      mother_id_rel = mother_id,
      father_id_rel = father_id
    ) |>
    filter(person_id %in% cohort_person_ids) |>
    collect() |>
    as.data.frame(stringsAsFactors = FALSE)
  relations_index_df$person_id <- as.character(relations_index_df$person_id)

  cohort_base_snapshot_df <- select_cohort_base_snapshots(
    cohort_censoring_df[, c("person_id", "index_date"), drop = FALSE],
    cohort_base_df
  )
  scd_results_df <- collapse_person_level_rows(scd_results_df, "scd_results")
  mfr_child_birth_fact_df <- collapse_person_level_rows(mfr_child_birth_fact_df, "mfr_child_birth_fact")
  relations_index_df <- collapse_person_level_rows(relations_index_df, "relations_index")

  assert_unique_join_key(cohort_base_snapshot_df, c("person_id", "index_date"), "cohort_base_snapshot_df")
  assert_unique_join_key(scd_results_df,          "person_id",                  "scd_results_df")
  assert_unique_join_key(mfr_child_birth_fact_df, "person_id",                  "mfr_child_birth_fact_df")
  assert_unique_join_key(relations_index_df,       "person_id",                  "relations_index_df")

  baseline_df <- cohort_censoring_df |>
    left_join(cohort_base_snapshot_df, by = c("person_id", "index_date")) |>
    left_join(scd_results_df, by = "person_id") |>
    left_join(mfr_child_birth_fact_df, by = "person_id") |>
    left_join(relations_index_df, by = "person_id") |>
    as.data.frame(stringsAsFactors = FALSE)

  assert_required_columns(
    baseline_df,
    c("person_id", "index_date", "censor_date", "censor_reason"),
    "baseline_df"
  )
  assert_unique_key(baseline_df, "person_id", "baseline_df")

  warn_high_na_rate(baseline_df, "scd_is_case",  threshold = 0.5, object_name = "baseline_df after join")
  warn_high_na_rate(baseline_df, "sex",           threshold = 0.5, object_name = "baseline_df after join")
  warn_high_na_rate(baseline_df, "birth_date",    threshold = 0.5, object_name = "baseline_df after join")

  baseline_df$scd_is_case[is.na(baseline_df$scd_is_case)] <- FALSE
  baseline_df$exposed <- baseline_df$scd_is_case
  baseline_df$unexposed <- !baseline_df$exposed
  baseline_df$exposure_date <- baseline_df$scd_first_date
  baseline_df$diagnosis_group <- ifelse(
    baseline_df$scd_is_case,
    baseline_df$scd_first_chapter,
    "Unexposed"
  )
  baseline_df$severity <- ifelse(baseline_df$scd_is_case, "Case", "Unexposed")

  # Vectorized window computation
  index_dates_v <- as.Date(baseline_df$index_date)
  baseline_df$baseline_start <- index_dates_v - config$baseline_years_target * 365L
  baseline_df$baseline_end   <- index_dates_v - 1L
  preindex_end               <- index_dates_v - config$preindex_lag_days

  # Coalesce parent IDs across sources
  baseline_df$mother_id <- dplyr::coalesce(
    na_if(trimws(as.character(baseline_df$mother_id)), ""),
    na_if(trimws(as.character(baseline_df$mother_id_mfr)), ""),
    na_if(trimws(as.character(baseline_df$mother_id_rel)), "")
  )
  baseline_df$father_id <- dplyr::coalesce(
    na_if(trimws(as.character(baseline_df$father_id)), ""),
    na_if(trimws(as.character(baseline_df$father_id_mfr)), ""),
    na_if(trimws(as.character(baseline_df$father_id_rel)), "")
  )

  baseline_df$cohabitation_group <- cohabitation_group_vec(
    baseline_df$family_type, baseline_df$civil_status
  )
  baseline_df$ethnicity_group <- ethnicity_group_vec(
    baseline_df$origin_country, baseline_df$ie_type
  )
  baseline_df$gest_age_cat <- gest_age_category_vec(baseline_df$gestational_age_days)
  baseline_df$birth_weight_cat <- birth_weight_category_vec(baseline_df$birth_weight_grams)
  baseline_df$parity_cat <- parity_category_vec(baseline_df$parity)
  baseline_df$multiple_birth <- multiple_birth_category_vec(
    baseline_df$multiple_birth_flag, baseline_df$births_count
  )
  baseline_df$maternal_age_birth_group <- maternal_age_group_vec(baseline_df$maternal_age_birth)
  baseline_df$apgar_cat <- apgar_category_vec(baseline_df$apgar_score_5min)

  baseline_df$baseline_observed_person_years <- observed_person_years_vec(
    baseline_df$birth_date,
    baseline_df$baseline_start,
    preindex_end
  )
  baseline_df$baseline_years_target <- config$baseline_years_target
  baseline_df$baseline_years_observed <- floor(baseline_df$baseline_observed_person_years)
  baseline_df$baseline_years_effective_required <- config$baseline_years_target
  baseline_df$baseline_truncated_by_source_window <- ifelse(
    is.na(baseline_df$birth_date),
    TRUE,
    baseline_df$birth_date > baseline_df$baseline_start
  )
  baseline_df$truncated_lookback_flag <- baseline_df$baseline_truncated_by_source_window

  parental_covariates <- compute_parental_covariates(baseline_df, config)
  baseline_df$parent_education_group <- parental_covariates$parent_education_group
  baseline_df$parent_socio_group <- parental_covariates$parent_socio_group

  preindex_metrics <- compute_preindex_metrics(baseline_df, config)
  baseline_df$preindex_util_total_numerator <- preindex_metrics$preindex_util_total_numerator
  baseline_df$preindex_hosp_days_numerator <- preindex_metrics$preindex_hosp_days_numerator
  baseline_df$preindex_util_missing_hospital_drugs <- preindex_metrics$preindex_util_missing_hospital_drugs
  baseline_df$preindex_util_total_rate <- ifelse(
    baseline_df$baseline_observed_person_years > 0,
    baseline_df$preindex_util_total_numerator / baseline_df$baseline_observed_person_years,
    NA_real_
  )
  baseline_df$preindex_hosp_days_rate <- ifelse(
    baseline_df$baseline_observed_person_years > 0,
    baseline_df$preindex_hosp_days_numerator / baseline_df$baseline_observed_person_years,
    NA_real_
  )

  baseline_df <- baseline_df |>
    transmute(
      person_id,
      index_date,
      exposure_date,
      exposed,
      unexposed,
      diagnosis_group,
      severity,
      baseline_start,
      baseline_end,
      sex,
      birth_date,
      municipality,
      region,
      family_id,
      mother_id,
      father_id,
      cohabitation_group,
      ethnicity_group,
      parent_education_group,
      parent_socio_group,
      gest_age_cat,
      birth_weight_cat,
      parity_cat,
      multiple_birth,
      maternal_age_birth,
      maternal_age_birth_group,
      apgar_cat,
      preindex_util_total_numerator,
      preindex_hosp_days_numerator,
      baseline_observed_person_years,
      baseline_years_target,
      baseline_years_observed,
      baseline_years_effective_required,
      baseline_truncated_by_source_window,
      preindex_util_total_rate,
      preindex_hosp_days_rate,
      preindex_util_missing_hospital_drugs,
      truncated_lookback_flag,
      scd_first_date,
      scd_first_chapter,
      scd_is_case,
      censor_date,
      censor_reason,
      death_date,
      emigration_date,
      is_resident_eligible
    )

  baseline_df
}

write_baseline_dataset <- function(config, baseline_df = build_baseline_dataset(config)) {
  ensure_output_dir(config)
  output_path <- file.path(config$output_dir, "baseline_dataset.parquet")
  arrow::write_parquet(baseline_df, output_path)

  note_lines <- c(
    sprintf("rows=%s", nrow(baseline_df)),
    sprintf("cols=%s", ncol(baseline_df)),
    sprintf(
      "preindex_util_missing_hospital_drugs=%s",
      if (all(baseline_df$preindex_util_missing_hospital_drugs)) "true" else "false"
    )
  )
  write_validation_note(note_lines, config, file_name = "baseline_dataset_notes.txt")

  invisible(output_path)
}

prepare_matching_inputs <- function(baseline_df) {
  age_at_index_months <- ifelse(
    is.na(baseline_df$birth_date),
    NA_real_,
    as.numeric(baseline_df$index_date - baseline_df$birth_date) / 30.4375
  )

  baseline_df |>
    mutate(
      index_year = as.integer(format(index_date, "%Y")),
      age_at_index_months = age_at_index_months,
      resident_eligible = is_resident_eligible
    ) |>
    select(
      person_id,
      index_date,
      index_year,
      exposed,
      unexposed,
      diagnosis_group,
      severity,
      sex,
      birth_date,
      municipality,
      region,
      censor_date,
      age_at_index_months,
      maternal_age_birth,
      maternal_age_birth_group,
      gest_age_cat,
      birth_weight_cat,
      parity_cat,
      multiple_birth,
      apgar_cat,
      parent_education_group,
      parent_socio_group,
      cohabitation_group,
      ethnicity_group,
      baseline_observed_person_years,
      preindex_util_total_rate,
      preindex_hosp_days_rate,
      truncated_lookback_flag,
      resident_eligible,
      scd_is_case
    )
}

write_matching_inputs <- function(config, baseline_df = build_baseline_dataset(config)) {
  ensure_output_dir(config)
  matching_df <- prepare_matching_inputs(baseline_df)
  output_path <- file.path(config$output_dir, "matching_inputs.parquet")
  arrow::write_parquet(matching_df, output_path)
  invisible(output_path)
}
