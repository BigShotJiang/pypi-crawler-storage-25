suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

expected_artifact_manifest <- function(config) {
  data.frame(
    artifact_name = c(
      "cohort_base",
      "cohort_censoring",
      "dod_deaths",
      "mfr_child_birth_fact",
      "mfr_parent_fact",
      "mfr_parent_links",
      "scd_results",
      "vnds_person_summary",
      "relations_index"
    ),
    stage = c(
      rep("cohort", 8),
      "core"
    ),
    file_name = c(
      "cohort_base.parquet",
      "cohort_censoring.parquet",
      "dod_deaths.parquet",
      "mfr_child_birth_fact.parquet",
      "mfr_parent_fact.parquet",
      "mfr_parent_links.parquet",
      "scd_results.parquet",
      "vnds_person_summary.parquet",
      "relations_index.parquet"
    ),
    stringsAsFactors = FALSE
  ) |>
    transform(
      artifact_path = ifelse(
        stage == "cohort",
        file.path(config$cohort_dir, file_name),
        file.path(config$core_dir, file_name)
      )
    )
}

ensure_output_dir <- function(config) {
  dir.create(config$output_dir, recursive = TRUE, showWarnings = FALSE)
  invisible(config)
}

open_parquet_dataset <- function(path) {
  arrow::open_dataset(sources = path, format = "parquet")
}

parquet_row_count <- function(path) {
  ds <- open_parquet_dataset(path)
  count_tbl <- ds |>
    summarise(row_count = dplyr::n()) |>
    collect()

  as.integer(count_tbl$row_count[[1]])
}

parquet_schema_string <- function(path) {
  ds <- open_parquet_dataset(path)
  field_names <- ds$schema$names
  field_types <- vapply(
    field_names,
    function(field_name) ds$schema$GetFieldByName(field_name)$type$ToString(),
    character(1)
  )
  paste(sprintf("%s:%s", field_names, field_types), collapse = "; ")
}

inventory_input_artifacts <- function(config) {
  ensure_output_dir(config)
  manifest <- expected_artifact_manifest(config)

  manifest$file_exists <- file.exists(manifest$artifact_path)
  if (!all(manifest$file_exists)) {
    missing_paths <- manifest$artifact_path[!manifest$file_exists]
    stop(
      sprintf(
        "Missing required parquet artifacts: %s",
        paste(missing_paths, collapse = ", ")
      )
    )
  }

  manifest$row_count <- vapply(manifest$artifact_path, parquet_row_count, integer(1))
  manifest$schema <- vapply(manifest$artifact_path, parquet_schema_string, character(1))
  manifest
}

write_inventory_outputs <- function(manifest, config) {
  ensure_output_dir(config)
  manifest_path <- file.path(config$output_dir, "input_artifact_manifest.parquet")
  csv_path <- file.path(config$output_dir, "input_artifact_manifest.csv")

  arrow::write_parquet(manifest, manifest_path)
  utils::write.csv(manifest, csv_path, row.names = FALSE)

  invisible(list(
    manifest_path = manifest_path,
    csv_path = csv_path
  ))
}
