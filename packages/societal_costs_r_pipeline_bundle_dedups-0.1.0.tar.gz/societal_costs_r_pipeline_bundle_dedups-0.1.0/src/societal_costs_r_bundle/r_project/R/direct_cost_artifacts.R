suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

load_study_population_ids <- function(config) {
  baseline_path <- file.path(config$output_dir, "baseline_dataset.parquet")
  if (!file.exists(baseline_path)) {
    stop(sprintf(
      "Baseline dataset not found at %s. Run scripts/01_build_baseline_dataset.R before building direct-cost artifacts.",
      baseline_path
    ))
  }

  baseline_df <- arrow::read_parquet(baseline_path, col_select = "person_id")
  ids <- unique(as.character(baseline_df$person_id))
  ids <- ids[!is.na(ids) & nzchar(ids)]
  if (!length(ids)) {
    stop(sprintf("No study population IDs found in %s.", baseline_path))
  }
  ids
}

list_raw_parquet_files <- function(directory, pattern) {
  if (!dir.exists(directory)) {
    return(character(0))
  }

  list.files(
    directory,
    pattern = pattern,
    full.names = TRUE,
    recursive = FALSE
  ) |>
    sort()
}

extract_year_from_filename <- function(path, prefix) {
  file_name <- basename(path)
  year_text <- sub(sprintf("^%s([0-9]{4}).*$", prefix), "\\1", file_name)
  suppressWarnings(as.integer(year_text))
}

is_partial_year_file <- function(path, prefix) {
  grepl(sprintf("^%s[0-9]{6}.*\\.parquet$", prefix), basename(path))
}

normalize_upper_names <- function(df) {
  names(df) <- toupper(names(df))
  df
}

first_matching_column <- function(df, patterns, object_name) {
  matched <- names(df)[vapply(
    names(df),
    function(name) any(grepl(patterns, name, ignore.case = TRUE)),
    logical(1)
  )]
  if (!length(matched)) {
    stop(
      sprintf(
        "%s is missing any column matching patterns: %s",
        object_name,
        paste(patterns, collapse = ", ")
      )
    )
  }
  matched[[1]]
}

first_present_column <- function(df, candidates, object_name) {
  matched <- intersect(candidates, names(df))
  if (!length(matched)) {
    stop(
      sprintf(
        "%s is missing all candidate columns: %s",
        object_name,
        paste(candidates, collapse = ", ")
      )
    )
  }
  matched[[1]]
}

safe_cost_numeric <- function(x) {
  value <- suppressWarnings(as.numeric(x))
  value[is.na(value)] <- 0
  value
}

standardize_person_id <- function(x) {
  as.character(x)
}

read_filtered_parquet_df <- function(path, requested_columns, cohort_ids) {
  if (!length(cohort_ids)) {
    return(data.frame())
  }
  filter_ids <- as.character(cohort_ids)

  dataset <- arrow::open_dataset(path, format = "parquet")
  available_columns <- names(dataset$schema)
  selected_columns <- intersect(unique(c("PNR", requested_columns)), available_columns)
  if (!("PNR" %in% selected_columns)) {
    stop(sprintf("%s does not contain PNR.", basename(path)))
  }

  dataset |>
    select(dplyr::all_of(selected_columns)) |>
    filter(as.character(PNR) %in% filter_ids) |>
    collect() |>
    as.data.frame(stringsAsFactors = FALSE)
}

read_grouped_cost_with_arrow <- function(dataset, path_label, available_columns, requested_columns, cohort_ids, source_year, cost_expr_fn) {
  if (!length(cohort_ids)) {
    return(data.frame())
  }
  filter_ids <- as.character(cohort_ids)

  selected_columns <- intersect(unique(c("PNR", requested_columns)), available_columns)
  if (!("PNR" %in% selected_columns)) {
    stop(sprintf("%s does not contain PNR.", basename(path_label)))
  }

  filtered <- dataset |>
    select(dplyr::all_of(selected_columns)) |>
    filter(as.character(PNR) %in% filter_ids)

  filtered_df <- filtered |> collect() |> as.data.frame(stringsAsFactors = FALSE)
  if (!nrow(filtered_df)) {
    return(filtered_df)
  }
  filtered_df <- normalize_upper_names(filtered_df)
  filtered_df$YEAR__ <- source_year
  filtered_df$COST_TOTAL__ <- cost_expr_fn(filtered_df)

  filtered_df |>
    transmute(
      person_id = standardize_person_id(PNR),
      year = YEAR__,
      cost_total = COST_TOTAL__
    ) |>
    filter(!is.na(person_id), nzchar(person_id), !is.na(year)) |>
    group_by(person_id, year) |>
    summarise(cost_total = sum(cost_total, na.rm = TRUE), .groups = "drop") |>
    as.data.frame(stringsAsFactors = FALSE)
}

derive_year_value <- function(df, object_name, exact_year_candidates = character(), exact_date_candidates = character()) {
  year_col <- intersect(exact_year_candidates, names(df))
  if (length(year_col)) {
    year_vec <- df[[year_col[[1]]]]
    if (inherits(year_vec, "Date") || inherits(year_vec, "POSIXt")) {
      return(as.integer(format(as.Date(year_vec), "%Y")))
    }
    year_value <- suppressWarnings(as.integer(substr(as.character(year_vec), 1L, 4L)))
    return(year_value)
  }

  date_col <- intersect(exact_date_candidates, names(df))
  if (length(date_col)) {
    date_vec <- df[[date_col[[1]]]]
    if (inherits(date_vec, "Date") || inherits(date_vec, "POSIXt")) {
      return(as.integer(format(as.Date(date_vec), "%Y")))
    }
    return(suppressWarnings(as.integer(substr(gsub("[^0-9]", "", as.character(date_vec)), 1L, 4L))))
  }

  pattern_col <- names(df)[grepl("AAR|YEAR|DATO|DATE", names(df), ignore.case = TRUE)][1]
  if (!is.na(pattern_col) && nzchar(pattern_col)) {
    pattern_vec <- df[[pattern_col]]
    if (inherits(pattern_vec, "Date") || inherits(pattern_vec, "POSIXt")) {
      return(as.integer(format(as.Date(pattern_vec), "%Y")))
    }
    return(suppressWarnings(as.integer(substr(gsub("[^0-9]", "", as.character(pattern_vec)), 1L, 4L))))
  }

  stop(sprintf("%s is missing a usable year/date column.", object_name))
}

approx_equal_cost <- function(lhs, rhs, tolerance = 1e-6) {
  abs(lhs - rhs) <= tolerance
}

collect_cost_rows <- function(paths, reader, ...) {
  rows <- vector("list", length(paths))
  issues <- character(0)

  if (!length(paths)) {
    return(list(rows = data.frame(), issues = issues))
  }

  for (i in seq_along(paths)) {
    path <- paths[[i]]
    result <- tryCatch(
      reader(path, ...),
      error = function(err) err
    )
    if (inherits(result, "error")) {
      issues <- c(issues, sprintf("%s: %s", basename(path), conditionMessage(result)))
    } else {
      rows[[i]] <- result
    }
  }

  list(
    rows = bind_rows(rows),
    issues = issues
  )
}

derive_lmdb_cost_column <- function(df, object_name) {
  if ("AUP" %in% names(df)) {
    return(list(
      cost_value = safe_cost_numeric(df$AUP),
      price_source = "aup_sum",
      derivation_note = NA_character_
    ))
  }

  if (all(c("PTP", "TSKA", "TSK1", "TSK2", "TSK3") %in% names(df))) {
    return(list(
      cost_value = safe_cost_numeric(df$PTP) +
        safe_cost_numeric(df$TSKA) +
        safe_cost_numeric(df$TSK1) +
        safe_cost_numeric(df$TSK2) +
        safe_cost_numeric(df$TSK3),
      price_source = "ptp_plus_subsidy_sum",
      derivation_note = NA_character_
    ))
  }

  if ("TILPRIS" %in% names(df)) {
    return(list(
      cost_value = safe_cost_numeric(df$TILPRIS),
      price_source = "tilpris_sum_proxy",
      derivation_note = sprintf(
        "%s used TILPRIS fallback because AUP and full subsidy decomposition were unavailable.",
        object_name
      )
    ))
  }

  stop(
    sprintf(
      "%s does not contain AUP, a full patient-payment plus subsidy decomposition, or TILPRIS.",
      object_name
    )
  )
}

read_lmdb_direct_cost <- function(path, config, cohort_ids) {
  source_year <- extract_year_from_filename(path, "lmdb")
  if (!is.na(source_year)) {
    object_name <- sprintf("LMDB file %s", basename(path))
    dataset <- arrow::open_dataset(path, format = "parquet")
    available_columns <- toupper(names(dataset$schema))
    price_source <- if ("AUP" %in% available_columns) {
      "aup_sum"
    } else if (all(c("PTP", "TSKA", "TSK1", "TSK2", "TSK3") %in% available_columns)) {
      "ptp_plus_subsidy_sum"
    } else if ("TILPRIS" %in% available_columns) {
      "tilpris_sum_proxy"
    } else {
      NULL
    }
    derivation_note <- if (identical(price_source, "tilpris_sum_proxy")) {
      sprintf(
        "%s used TILPRIS fallback because AUP and full subsidy decomposition were unavailable.",
        object_name
      )
    } else {
      NA_character_
    }
    grouped <- read_grouped_cost_with_arrow(
      dataset = dataset,
      path_label = path,
      available_columns = available_columns,
      requested_columns = c("PNR", "AUP", "PTP", "TSKA", "TSK1", "TSK2", "TSK3", "TILPRIS"),
      cohort_ids = cohort_ids,
      source_year = source_year,
      cost_expr_fn = function(df) derive_lmdb_cost_column(df, object_name)$cost_value
    )
    if (nrow(grouped)) {
      grouped$source_year <- source_year
      grouped$source_file <- basename(path)
      grouped$price_source <- price_source
      grouped$derivation_note <- derivation_note
      grouped$coverage_status <- if (is_partial_year_file(path, "lmdb")) "partial" else "full"
      return(grouped)
    }
  }

  raw_df <- read_filtered_parquet_df(path, c("PNR", "EKSD", "AUP", "PTP", "TSKA", "TSK1", "TSK2", "TSK3", "TILPRIS"), cohort_ids) |>
    normalize_upper_names()

  object_name <- sprintf("LMDB file %s", basename(path))
  person_col <- first_present_column(raw_df, c("PNR"), object_name)
  date_col <- first_present_column(raw_df, c("EKSD"), object_name)
  cost_meta <- derive_lmdb_cost_column(raw_df, object_name)

  date_value <- as.character(raw_df[[date_col]])
  year_value <- suppressWarnings(as.integer(substr(gsub("[^0-9]", "", date_value), 1L, 4L)))
  source_year <- extract_year_from_filename(path, "lmdb")
  if (!is.na(source_year)) {
    missing_year <- is.na(year_value)
    year_value[missing_year] <- source_year
  }

  data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = year_value,
    cost_total = cost_meta$cost_value,
    source_year = source_year,
    source_file = basename(path),
    price_source = cost_meta$price_source,
    derivation_note = cost_meta$derivation_note,
    coverage_status = if (is_partial_year_file(path, "lmdb")) "partial" else "full",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year))
}

build_lmdb_direct_cost_artifact <- function(config, cohort_ids = NULL) {
  lmdb_files <- list_raw_parquet_files(config$raw_lmdb_dir, "^lmdb[0-9]{4}.*\\.parquet$")
  if (!length(lmdb_files)) {
    return(list(data = data.frame(), issues = character(0)))
  }

  cohort_ids <- cohort_ids %||% load_study_population_ids(config)
  collected <- collect_cost_rows(lmdb_files, read_lmdb_direct_cost, config = config, cohort_ids = cohort_ids)
  if (!nrow(collected$rows)) {
    return(list(data = data.frame(), issues = collected$issues))
  }
  data <- collected$rows |>
    group_by(person_id, year, price_source, coverage_status) |>
    summarise(
      cost_total = sum(cost_total, na.rm = TRUE),
      source_year = min(source_year, na.rm = TRUE),
      source_file = paste(sort(unique(source_file)), collapse = ";"),
      derivation_note = {
        notes <- sort(unique(stats::na.omit(derivation_note)))
        if (length(notes)) paste(notes, collapse = ";") else NA_character_
      },
      .groups = "drop"
    ) |>
    arrange(person_id, year) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(data = data, issues = collected$issues)
}

read_primary_direct_cost <- function(path, source_system, cohort_ids) {
  source_year <- extract_year_from_filename(path, source_system)
  if (!is.na(source_year)) {
    amount_candidates <- c("BRUHON", "HONUGE")
    dataset <- arrow::open_dataset(path, format = "parquet")
    available_columns <- toupper(names(dataset$schema))
    amount_col <- first_present_column(
      setNames(as.list(rep(NA, length(available_columns))), available_columns),
      amount_candidates,
      sprintf("%s file %s", toupper(source_system), basename(path))
    )
    grouped <- read_grouped_cost_with_arrow(
      dataset = dataset,
      path_label = path,
      available_columns = available_columns,
      requested_columns = c("PNR", amount_candidates),
      cohort_ids = cohort_ids,
      source_year = source_year,
      cost_expr_fn = function(df) {
        object_name <- sprintf("%s file %s", toupper(source_system), basename(path))
        amount_col <- first_present_column(df, amount_candidates, object_name)
        value <- safe_cost_numeric(df[[amount_col]])
        if (identical(source_system, "sysi")) value <- value / 100
        value
      }
    )
    if (nrow(grouped)) {
      grouped$source_system <- source_system
      grouped$source_file <- basename(path)
      grouped$price_source <- sprintf("%s_%s_sum", source_system, tolower(amount_col))
      grouped$coverage_status <- "full"
      return(grouped)
    }
  }

  raw_df <- read_filtered_parquet_df(path, c("PNR", "AFRPER", "BRUHON", "HONUGE"), cohort_ids) |>
    normalize_upper_names()

  object_name <- sprintf("%s file %s", toupper(source_system), basename(path))
  person_col <- first_present_column(raw_df, c("PNR"), object_name)
  period_col <- first_present_column(raw_df, c("AFRPER"), object_name)
  amount_col <- first_present_column(raw_df, c("BRUHON", "HONUGE"), object_name)

  year_value <- suppressWarnings(as.integer(substr(as.character(raw_df[[period_col]]), 1L, 4L)))
  cost_value <- safe_cost_numeric(raw_df[[amount_col]])
  if (identical(source_system, "sysi")) {
    cost_value <- cost_value / 100
  }

  data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = year_value,
    cost_total = cost_value,
    source_system = source_system,
    source_file = basename(path),
    price_source = sprintf("%s_%s_sum", source_system, tolower(amount_col)),
    coverage_status = "full",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year))
}

build_primary_direct_cost_artifact <- function(config, cohort_ids = NULL) {
  sysi_files <- list_raw_parquet_files(config$raw_primary_dir, "^sysi[0-9]{4}.*\\.parquet$")
  sssy_files <- list_raw_parquet_files(config$raw_primary_dir, "^sssy[0-9]{4}.*\\.parquet$")
  cohort_ids <- cohort_ids %||% load_study_population_ids(config)

  sysi_collected <- collect_cost_rows(sysi_files, read_primary_direct_cost, source_system = "sysi", cohort_ids = cohort_ids)
  sssy_collected <- collect_cost_rows(sssy_files, read_primary_direct_cost, source_system = "sssy", cohort_ids = cohort_ids)
  primary_rows <- bind_rows(sysi_collected$rows, sssy_collected$rows)

  if (!nrow(primary_rows)) {
    return(list(data = primary_rows, issues = c(sysi_collected$issues, sssy_collected$issues)))
  }

  data <- primary_rows |>
    filter((source_system == "sysi" & year <= 2004L) | (source_system == "sssy" & year >= 2005L)) |>
    group_by(person_id, year, source_system, price_source, coverage_status) |>
    summarise(
      cost_total = sum(cost_total, na.rm = TRUE),
      source_file = paste(sort(unique(source_file)), collapse = ";"),
      .groups = "drop"
    ) |>
    arrange(person_id, year, source_system) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(data = data, issues = c(sysi_collected$issues, sssy_collected$issues))
}

build_direct_cost_source_inventory <- function(config) {
  lmdb_files <- list_raw_parquet_files(config$raw_lmdb_dir, "^lmdb[0-9]{4}.*\\.parquet$")
  sysi_files <- list_raw_parquet_files(config$raw_primary_dir, "^sysi[0-9]{4}.*\\.parquet$")
  sssy_files <- list_raw_parquet_files(config$raw_primary_dir, "^sssy[0-9]{4}.*\\.parquet$")
  amb_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_amb[0-9]{4}.*\\.parquet$")
  hel_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_hel[0-9]{4}.*\\.parquet$")
  kontakt_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_kontakt2018.*\\.parquet$")
  sghforlob_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_sghforlob2018.*\\.parquet$")
  indberetning_file <- if (file.exists(config$raw_indberetningmedpris_path)) config$raw_indberetningmedpris_path else character(0)

  bind_rows(
    if (length(lmdb_files)) {
      data.frame(
        component = "lmdb",
        source_system = "lmdb",
        source_table = "lmdb",
        year = vapply(lmdb_files, extract_year_from_filename, integer(1), prefix = "lmdb"),
        source_file = basename(lmdb_files),
        source_path = lmdb_files,
        coverage_status = ifelse(vapply(lmdb_files, is_partial_year_file, logical(1), prefix = "lmdb"), "partial", "full"),
        selected_for_build = TRUE,
        note = ifelse(vapply(lmdb_files, is_partial_year_file, logical(1), prefix = "lmdb"), "Partial-year LMDB delivery", "Included"),
        stringsAsFactors = FALSE
      )
    },
    if (length(sysi_files)) {
      year_value <- vapply(sysi_files, extract_year_from_filename, integer(1), prefix = "sysi")
      data.frame(
        component = "primary_sector",
        source_system = "sysi",
        source_table = "sysi",
        year = year_value,
        source_file = basename(sysi_files),
        source_path = sysi_files,
        coverage_status = "full",
        selected_for_build = year_value <= 2004L,
        note = ifelse(year_value <= 2004L, "Included", "Excluded because SYSI overlaps with SSSY from 2005 onward"),
        stringsAsFactors = FALSE
      )
    },
    if (length(sssy_files)) {
      year_value <- vapply(sssy_files, extract_year_from_filename, integer(1), prefix = "sssy")
      data.frame(
        component = "primary_sector",
        source_system = "sssy",
        source_table = "sssy",
        year = year_value,
        source_file = basename(sssy_files),
        source_path = sssy_files,
        coverage_status = "full",
        selected_for_build = year_value >= 2005L,
        note = ifelse(year_value >= 2005L, "Included", "Excluded because SSSY is canonical from 2005 onward"),
        stringsAsFactors = FALSE
      )
    },
    if (length(amb_files)) {
      data.frame(
        component = "lpr_kontakt",
        source_system = "lpr",
        source_table = "drgsoma_amb",
        year = vapply(amb_files, extract_year_from_filename, integer(1), prefix = "drgsoma_amb"),
        source_file = basename(amb_files),
        source_path = amb_files,
        coverage_status = "full",
        selected_for_build = TRUE,
        note = "Included",
        stringsAsFactors = FALSE
      )
    },
    if (length(hel_files)) {
      data.frame(
        component = "lpr_sghforlob",
        source_system = "lpr",
        source_table = "drgsoma_hel",
        year = vapply(hel_files, extract_year_from_filename, integer(1), prefix = "drgsoma_hel"),
        source_file = basename(hel_files),
        source_path = hel_files,
        coverage_status = "full",
        selected_for_build = TRUE,
        note = "Included",
        stringsAsFactors = FALSE
      )
    },
    if (length(kontakt_files)) {
      data.frame(
        component = "lpr_kontakt",
        source_system = "lpr",
        source_table = "drgsoma_kontakt2018",
        year = 2018L,
        source_file = basename(kontakt_files),
        source_path = kontakt_files,
        coverage_status = if (length(sghforlob_files)) "supplementary" else "partial",
        selected_for_build = TRUE,
        note = if (length(sghforlob_files)) {
          "Included only for kontakt rows without linked DRGSGHFORLOB_ID"
        } else {
          "Used as 2018 fallback because drgsoma_sghforlob2018 is absent"
        },
        stringsAsFactors = FALSE
      )
    },
    if (length(sghforlob_files)) {
      data.frame(
        component = "lpr_sghforlob",
        source_system = "lpr",
        source_table = "drgsoma_sghforlob2018",
        year = 2018L,
        source_file = basename(sghforlob_files),
        source_path = sghforlob_files,
        coverage_status = "full",
        selected_for_build = TRUE,
        note = "Included as canonical 2018 LPR pathway source",
        stringsAsFactors = FALSE
      )
    },
    if (length(indberetning_file)) {
      data.frame(
        component = "hospital_drugs",
        source_system = "hospital_drugs",
        source_table = "indberetningmedpris",
        year = NA_integer_,
        source_file = basename(indberetning_file),
        source_path = indberetning_file,
        coverage_status = "restricted",
        selected_for_build = TRUE,
        note = "Multi-year hospital-drug cost file with restricted coverage",
        stringsAsFactors = FALSE
      )
    }
  ) |>
    arrange(component, year, source_table, source_file) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_component_year_availability <- function(source_inventory) {
  if (!nrow(source_inventory)) {
    return(data.frame())
  }

  source_inventory |>
    filter(!is.na(year)) |>
    filter(selected_for_build) |>
    group_by(component, year) |>
    summarise(
      coverage_status = case_when(
        any(coverage_status == "full") ~ "full",
        any(coverage_status == "partial") ~ "partial",
        any(coverage_status == "supplementary") ~ "supplementary",
        any(coverage_status == "restricted") ~ "restricted",
        TRUE ~ "unknown"
      ),
      source_tables = paste(sort(unique(source_table)), collapse = ";"),
      source_files = paste(sort(unique(source_file)), collapse = ";"),
      .groups = "drop"
    ) |>
    mutate(data_available = TRUE) |>
    arrange(component, year) |>
    as.data.frame(stringsAsFactors = FALSE)
}

canonical_legacy_drg_cost <- function(df) {
  total_col <- intersect(c("V_TOTPRIS"), names(df))
  base_col <- intersect(c("V_PRIS"), names(df))
  long_col <- intersect(c("V_LANGPRIS"), names(df))

  total_cost <- if (length(total_col)) safe_cost_numeric(df[[total_col[[1]]]]) else rep(NA_real_, nrow(df))
  base_cost <- if (length(base_col)) safe_cost_numeric(df[[base_col[[1]]]]) else rep(NA_real_, nrow(df))
  long_cost <- if (length(long_col)) safe_cost_numeric(df[[long_col[[1]]]]) else rep(0, nrow(df))
  decomposition_cost <- base_cost + long_cost

  # V_TOTPRIS, V_PRIS, V_LANGPRIS are stored in 1,000 DKK units in pre-2018 DRG files
  # (eSundhed: "Prisen angives i 1.000 kr"). Multiply by 1000 to convert to whole DKK.
  1000 * ifelse(!is.na(total_cost) & total_cost > 0, total_cost, decomposition_cost)
}

read_legacy_drg_cost <- function(path, table_type, cohort_ids) {
  raw_df <- read_filtered_parquet_df(path, c("PNR", "V_AAR", "V_PRIS", "V_LANGPRIS", "V_TOTPRIS"), cohort_ids) |>
    normalize_upper_names()

  object_name <- sprintf("legacy DRG file %s", basename(path))
  person_col <- first_present_column(raw_df, c("PNR"), object_name)
  year_col <- first_present_column(raw_df, c("V_AAR"), object_name)
  cost_value <- canonical_legacy_drg_cost(raw_df)

  data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = suppressWarnings(as.integer(raw_df[[year_col]])),
    ambulatory_cost = if (identical(table_type, "amb")) cost_value else 0,
    inpatient_cost = if (identical(table_type, "hel")) cost_value else 0,
    cost_total = cost_value,
    source_era = "legacy_amb_hel",
    source_file = basename(path),
    price_source = "v_totpris_preferred",
    coverage_status = "full",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year), !is.na(cost_total))
}

read_drg2018_sghforlob <- function(path, cohort_ids) {
  raw_df <- read_filtered_parquet_df(path, c("PNR", "AKTIVITETSAAR", "TOTALPRIS_DRGSGHF"), cohort_ids) |>
    normalize_upper_names()

  person_col <- first_present_column(raw_df, c("PNR"), basename(path))
  year_col <- first_present_column(raw_df, c("AKTIVITETSAAR"), basename(path))
  cost_col <- first_present_column(raw_df, c("TOTALPRIS_DRGSGHF"), basename(path))

  data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = suppressWarnings(as.integer(raw_df[[year_col]])),
    ambulatory_cost = 0,
    inpatient_cost = safe_cost_numeric(raw_df[[cost_col]]),
    cost_total = safe_cost_numeric(raw_df[[cost_col]]),
    source_era = "drg2018_sghforlob",
    source_file = basename(path),
    price_source = "totalpris_drgsghf_sum",
    coverage_status = "full",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year))
}

read_drg2018_kontakt <- function(path, cohort_ids) {
  raw_df <- read_filtered_parquet_df(path, c("PNR", "AKTIVITETSAAR", "DRGSGHFORLOB_ID", "TOTALPRIS_DRG"), cohort_ids) |>
    normalize_upper_names()

  person_col <- first_present_column(raw_df, c("PNR"), basename(path))
  year_col <- first_present_column(raw_df, c("AKTIVITETSAAR"), basename(path))
  cost_col <- first_present_column(raw_df, c("TOTALPRIS_DRG"), basename(path))
  linked_forlob_col <- intersect(c("DRGSGHFORLOB_ID"), names(raw_df))
  include_row <- rep(TRUE, nrow(raw_df))
  if (length(linked_forlob_col)) {
    linked_value <- trimws(as.character(raw_df[[linked_forlob_col[[1]]]]))
    include_row <- is.na(linked_value) | linked_value == ""
  }

  data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = suppressWarnings(as.integer(raw_df[[year_col]])),
    ambulatory_cost = safe_cost_numeric(raw_df[[cost_col]]),
    inpatient_cost = 0,
    cost_total = safe_cost_numeric(raw_df[[cost_col]]),
    source_era = "drg2018_kontakt_fallback",
    source_file = basename(path),
    price_source = "totalpris_drg_sum",
    coverage_status = if (length(linked_forlob_col)) "supplementary" else "partial",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(include_row) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year))
}

build_lpr_direct_cost_artifact <- function(config, cohort_ids = NULL) {
  amb_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_amb[0-9]{4}.*\\.parquet$")
  hel_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_hel[0-9]{4}.*\\.parquet$")
  kontakt_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_kontakt2018.*\\.parquet$")
  sghforlob_files <- list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_sghforlob2018.*\\.parquet$")
  cohort_ids <- cohort_ids %||% load_study_population_ids(config)

  amb_collected <- collect_cost_rows(amb_files, read_legacy_drg_cost, table_type = "amb", cohort_ids = cohort_ids)
  hel_collected <- collect_cost_rows(hel_files, read_legacy_drg_cost, table_type = "hel", cohort_ids = cohort_ids)
  sgh_collected <- collect_cost_rows(sghforlob_files, read_drg2018_sghforlob, cohort_ids = cohort_ids)
  kontakt_collected <- if (length(kontakt_files)) {
    collect_cost_rows(kontakt_files, read_drg2018_kontakt, cohort_ids = cohort_ids)
  } else {
    list(rows = data.frame(), issues = character(0))
  }

  lpr_rows <- bind_rows(
    amb_collected$rows,
    hel_collected$rows,
    sgh_collected$rows,
    kontakt_collected$rows
  )

  if (!nrow(lpr_rows)) {
    return(list(
      data = lpr_rows,
      issues = c(amb_collected$issues, hel_collected$issues, sgh_collected$issues, kontakt_collected$issues)
    ))
  }

  data <- lpr_rows |>
    group_by(person_id, year, source_era, price_source, coverage_status) |>
    summarise(
      ambulatory_cost = sum(ambulatory_cost, na.rm = TRUE),
      inpatient_cost = sum(inpatient_cost, na.rm = TRUE),
      cost_total = sum(cost_total, na.rm = TRUE),
      source_file = paste(sort(unique(source_file)), collapse = ";"),
      .groups = "drop"
    ) |>
    arrange(person_id, year, source_era) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(
    data = data,
    issues = c(amb_collected$issues, hel_collected$issues, sgh_collected$issues, kontakt_collected$issues)
  )
}

read_hospital_drugs_direct_cost <- function(path, cohort_ids) {
  raw_df <- read_filtered_parquet_df(
    path,
    c("PNR", "AAR", "YEAR", "AKTIVITETSAAR", "V_AAR", "AFRPER", "DATO", "DATE", "EKSD",
      "PRIS", "TOTALPRIS", "BELOEB", "BELOB", "AFREGNINGSPRIS", "COST"),
    cohort_ids
  ) |>
    normalize_upper_names()

  object_name <- sprintf("hospital-drugs file %s", basename(path))
  person_col <- first_present_column(raw_df, c("PNR"), object_name)
  year_value <- derive_year_value(
    raw_df,
    object_name,
    exact_year_candidates = c("AAR", "YEAR", "AKTIVITETSAAR", "V_AAR", "AFRPER"),
    exact_date_candidates = c("DATO", "DATE", "EKSD")
  )
  amount_col <- intersect(c("PRIS", "TOTALPRIS", "BELOEB", "BELOB", "AFREGNINGSPRIS", "COST"), names(raw_df))
  if (!length(amount_col)) {
    amount_col <- first_matching_column(raw_df, c("PRIS", "BELOE?B", "COST"), object_name)
  } else {
    amount_col <- amount_col[[1]]
  }

  data.frame(
    person_id = standardize_person_id(raw_df[[person_col]]),
    year = year_value,
    cost_total = safe_cost_numeric(raw_df[[amount_col]]),
    source_file = basename(path),
    price_source = sprintf("hospital_drugs_%s_sum", tolower(amount_col)),
    coverage_status = "restricted",
    stringsAsFactors = FALSE
  ) |>
    dplyr::filter(!is.na(person_id), nzchar(person_id), !is.na(year))
}

build_hospital_drugs_direct_cost_artifact <- function(config, cohort_ids = NULL) {
  path <- config$raw_indberetningmedpris_path
  if (!file.exists(path)) {
    return(list(data = data.frame(), issues = character(0)))
  }

  cohort_ids <- cohort_ids %||% load_study_population_ids(config)
  collected <- collect_cost_rows(path, read_hospital_drugs_direct_cost, cohort_ids = cohort_ids)
  if (!nrow(collected$rows)) {
    return(list(data = data.frame(), issues = collected$issues))
  }

  data <- collected$rows |>
    group_by(person_id, year, price_source, coverage_status) |>
    summarise(
      cost_total = sum(cost_total, na.rm = TRUE),
      source_file = paste(sort(unique(source_file)), collapse = ";"),
      .groups = "drop"
    ) |>
    arrange(person_id, year) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(data = data, issues = collected$issues)
}

build_lpr_legacy_validation_summary <- function(config, cohort_ids = NULL) {
  legacy_files <- c(
    list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_amb[0-9]{4}.*\\.parquet$"),
    list_raw_parquet_files(config$raw_drg_dir, "^drgsoma_hel[0-9]{4}.*\\.parquet$")
  )

  if (!length(legacy_files)) {
    return(data.frame())
  }
  cohort_ids <- cohort_ids %||% load_study_population_ids(config)

  bind_rows(lapply(legacy_files, function(path) {
    raw_df <- read_filtered_parquet_df(path, c("PNR", "V_AAR", "V_PRIS", "V_LANGPRIS", "V_TOTPRIS"), cohort_ids) |>
      normalize_upper_names()

    year_value <- if ("V_AAR" %in% names(raw_df) && nrow(raw_df)) {
      suppressWarnings(as.integer(raw_df$V_AAR[[1]]))
    } else {
      suppressWarnings(as.integer(sub(".*([0-9]{4}).*", "\\1", basename(path))))
    }
    base_cost <- if ("V_PRIS" %in% names(raw_df)) safe_cost_numeric(raw_df$V_PRIS) else rep(NA_real_, nrow(raw_df))
    long_cost <- if ("V_LANGPRIS" %in% names(raw_df)) safe_cost_numeric(raw_df$V_LANGPRIS) else rep(NA_real_, nrow(raw_df))
    total_cost <- if ("V_TOTPRIS" %in% names(raw_df)) safe_cost_numeric(raw_df$V_TOTPRIS) else rep(NA_real_, nrow(raw_df))
    decomposition_cost <- base_cost + long_cost
    has_total <- !is.na(total_cost) & total_cost > 0
    comparable <- has_total & !is.na(decomposition_cost)
    matches <- comparable & approx_equal_cost(total_cost, decomposition_cost)

    data.frame(
      source_file = basename(path),
      source_table = if (grepl("^drgsoma_amb", basename(path))) "drgsoma_amb" else "drgsoma_hel",
      year = year_value,
      rows = nrow(raw_df),
      rows_with_totpris = sum(has_total, na.rm = TRUE),
      rows_comparable = sum(comparable, na.rm = TRUE),
      rows_matching_decomposition = sum(matches, na.rm = TRUE),
      share_matching_decomposition = if (sum(comparable, na.rm = TRUE) > 0) {
        sum(matches, na.rm = TRUE) / sum(comparable, na.rm = TRUE)
      } else {
        NA_real_
      },
      rows_missing_totpris = sum(!has_total, na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  })) |>
    arrange(year, source_table, source_file) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_direct_cost_person_year <- function(lmdb_cost, lpr_cost, primary_cost, hospital_drugs_cost) {
  bind_rows(
    if (nrow(lmdb_cost)) {
      lmdb_cost |>
        transmute(
          person_id,
          year,
          component = "lmdb",
          cost = cost_total,
          source_system = "lmdb",
          source_era = "lmdb",
          price_source,
          coverage_status
        )
    },
    if (nrow(lpr_cost)) {
      bind_rows(
        lpr_cost |>
          transmute(
            person_id,
            year,
            component = "lpr_sghforlob",
            cost = inpatient_cost,
            source_system = "lpr",
            source_era,
            price_source,
            coverage_status
          ),
        lpr_cost |>
          transmute(
            person_id,
            year,
            component = "lpr_kontakt",
            cost = ambulatory_cost,
            source_system = "lpr",
            source_era,
            price_source,
            coverage_status
          )
      )
    },
    if (nrow(primary_cost)) {
      primary_cost |>
        transmute(
          person_id,
          year,
          component = "primary_sector",
          cost = cost_total,
          source_system = source_system,
          source_era = source_system,
          price_source,
          coverage_status
        )
    },
    if (nrow(hospital_drugs_cost)) {
      hospital_drugs_cost |>
        transmute(
          person_id,
          year,
          component = "hospital_drugs",
          cost = cost_total,
          source_system = "hospital_drugs",
          source_era = "hospital_drugs",
          price_source,
          coverage_status
        )
    }
  ) |>
    arrange(component, person_id, year) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_direct_cost_coverage_summary <- function(lmdb_cost, lpr_cost, primary_cost, hospital_drugs_cost) {
  bind_rows(
    if (nrow(lmdb_cost)) lmdb_cost |> transmute(component = "lmdb", year, coverage_status),
    if (nrow(lpr_cost)) bind_rows(
      lpr_cost |> transmute(component = "lpr_sghforlob", year, coverage_status),
      lpr_cost |> transmute(component = "lpr_kontakt", year, coverage_status)
    ),
    if (nrow(primary_cost)) primary_cost |> transmute(component = "primary_sector", year, coverage_status),
    if (nrow(hospital_drugs_cost)) hospital_drugs_cost |> transmute(component = "hospital_drugs", year, coverage_status)
  ) |>
    group_by(component, year, coverage_status) |>
    summarise(person_year_rows = n(), .groups = "drop") |>
    arrange(component, year, coverage_status) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_direct_cost_component_year_summary <- function(combined_cost, component_year_availability) {
  if (!nrow(component_year_availability)) {
    return(data.frame())
  }

  aggregated_cost <- if (nrow(combined_cost)) {
    combined_cost |>
      group_by(component, year) |>
      summarise(
        person_year_rows = n(),
        unique_people = n_distinct(person_id),
        total_cost = sum(cost, na.rm = TRUE),
        .groups = "drop"
      )
  } else {
    data.frame(
      component = character(),
      year = integer(),
      person_year_rows = integer(),
      unique_people = integer(),
      total_cost = numeric(),
      stringsAsFactors = FALSE
    )
  }

  component_year_availability |>
    left_join(aggregated_cost, by = c("component", "year")) |>
    mutate(
      person_year_rows = dplyr::coalesce(person_year_rows, 0L),
      unique_people = dplyr::coalesce(unique_people, 0L),
      total_cost = dplyr::coalesce(total_cost, 0)
    ) |>
    arrange(component, year) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_primary_transition_summary <- function(source_inventory) {
  primary_inventory <- source_inventory[source_inventory$component == "primary_sector", , drop = FALSE]
  if (!nrow(primary_inventory)) {
    return(data.frame())
  }

  primary_inventory |>
    group_by(source_system, year, selected_for_build) |>
    summarise(
      files = n(),
      coverage_status = paste(sort(unique(coverage_status)), collapse = ";"),
      notes = paste(sort(unique(note)), collapse = ";"),
      .groups = "drop"
    ) |>
    arrange(year, source_system, desc(selected_for_build)) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_direct_cost_artifacts <- function(config) {
  ensure_output_dir(config)

  # Load cohort IDs once; pass to all five builders to avoid repeated parquet reads.
  cohort_ids <- load_study_population_ids(config)

  source_inventory      <- build_direct_cost_source_inventory(config)
  lmdb_result           <- build_lmdb_direct_cost_artifact(config, cohort_ids = cohort_ids)
  lpr_result            <- build_lpr_direct_cost_artifact(config, cohort_ids = cohort_ids)
  primary_result        <- build_primary_direct_cost_artifact(config, cohort_ids = cohort_ids)
  hospital_drugs_result <- build_hospital_drugs_direct_cost_artifact(config, cohort_ids = cohort_ids)
  lmdb_cost <- lmdb_result$data
  lpr_cost <- lpr_result$data
  primary_cost <- primary_result$data
  hospital_drugs_cost <- hospital_drugs_result$data
  combined_cost <- build_direct_cost_person_year(lmdb_cost, lpr_cost, primary_cost, hospital_drugs_cost)
  coverage_summary <- build_direct_cost_coverage_summary(lmdb_cost, lpr_cost, primary_cost, hospital_drugs_cost)
  component_year_availability <- build_component_year_availability(source_inventory)
  if (nrow(hospital_drugs_cost)) {
    hospital_drugs_availability <- hospital_drugs_cost |>
      group_by(year) |>
      summarise(
        component = "hospital_drugs",
        coverage_status = "restricted",
        source_tables = "indberetningmedpris",
        source_files = paste(sort(unique(source_file)), collapse = ";"),
        data_available = TRUE,
        .groups = "drop"
      ) |>
      select(component, year, coverage_status, source_tables, source_files, data_available) |>
      as.data.frame(stringsAsFactors = FALSE)
    component_year_availability <- bind_rows(component_year_availability, hospital_drugs_availability) |>
      arrange(component, year) |>
      as.data.frame(stringsAsFactors = FALSE)
  }
  component_year_summary <- build_direct_cost_component_year_summary(combined_cost, component_year_availability)
  lpr_legacy_validation <- build_lpr_legacy_validation_summary(config, cohort_ids = cohort_ids)
  primary_transition_summary <- build_primary_transition_summary(source_inventory)

  list(
    source_inventory = source_inventory,
    lmdb_cost = lmdb_cost,
    lpr_cost = lpr_cost,
    primary_cost = primary_cost,
    hospital_drugs_cost = hospital_drugs_cost,
    combined_cost = combined_cost,
    coverage_summary = coverage_summary,
    component_year_availability = component_year_availability,
    component_year_summary = component_year_summary,
    lpr_legacy_validation = lpr_legacy_validation,
    primary_transition_summary = primary_transition_summary,
    issues = c(lmdb_result$issues, lpr_result$issues, primary_result$issues, hospital_drugs_result$issues)
  )
}

write_direct_cost_artifacts <- function(artifacts, config) {
  ensure_output_dir(config)

  output_paths <- list(
    lmdb_cost_path = file.path(config$output_dir, "lmdb_direct_cost.parquet"),
    lpr_cost_path = file.path(config$output_dir, "lpr_direct_cost.parquet"),
    primary_cost_path = file.path(config$output_dir, "primary_sector_direct_cost.parquet"),
    hospital_drugs_cost_path = file.path(config$output_dir, "hospital_drugs_direct_cost.parquet"),
    combined_cost_path = file.path(config$output_dir, "direct_cost_person_year.parquet"),
    coverage_summary_path = file.path(config$output_dir, "direct_cost_coverage_summary.csv"),
    source_inventory_path = file.path(config$output_dir, "direct_cost_source_inventory.csv"),
    component_year_availability_path = file.path(config$output_dir, "direct_cost_component_year_availability.parquet"),
    component_year_summary_path = file.path(config$output_dir, "direct_cost_component_year_summary.csv"),
    lpr_legacy_validation_path = file.path(config$output_dir, "lpr_legacy_validation_summary.csv"),
    primary_transition_summary_path = file.path(config$output_dir, "primary_transition_summary.csv"),
    issues_note_path = file.path(config$output_dir, "direct_cost_build_notes.txt")
  )

  arrow::write_parquet(artifacts$lmdb_cost, output_paths$lmdb_cost_path)
  arrow::write_parquet(artifacts$lpr_cost, output_paths$lpr_cost_path)
  arrow::write_parquet(artifacts$primary_cost, output_paths$primary_cost_path)
  arrow::write_parquet(artifacts$hospital_drugs_cost, output_paths$hospital_drugs_cost_path)
  arrow::write_parquet(artifacts$combined_cost, output_paths$combined_cost_path)
  utils::write.csv(artifacts$coverage_summary, output_paths$coverage_summary_path, row.names = FALSE)
  utils::write.csv(artifacts$source_inventory, output_paths$source_inventory_path, row.names = FALSE)
  arrow::write_parquet(artifacts$component_year_availability, output_paths$component_year_availability_path)
  utils::write.csv(artifacts$component_year_summary, output_paths$component_year_summary_path, row.names = FALSE)
  utils::write.csv(artifacts$lpr_legacy_validation, output_paths$lpr_legacy_validation_path, row.names = FALSE)
  utils::write.csv(artifacts$primary_transition_summary, output_paths$primary_transition_summary_path, row.names = FALSE)
  writeLines(
    if (length(artifacts$issues)) artifacts$issues else "No build issues recorded.",
    output_paths$issues_note_path
  )

  output_paths
}
