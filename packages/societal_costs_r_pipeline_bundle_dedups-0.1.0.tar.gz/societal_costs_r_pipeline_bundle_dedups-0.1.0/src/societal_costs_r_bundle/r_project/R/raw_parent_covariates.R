suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
  library(jsonlite)
})

parse_year_from_path <- function(path, prefix) {
  stem <- sub("\\.parquet$", "", basename(path))
  nested_dir <- basename(dirname(path))

  if (identical(nested_dir, prefix)) {
    digits <- gsub("[^0-9]", "", stem)
    if (nchar(digits) >= 4L) {
      return(suppressWarnings(as.integer(substr(digits, 1, 4))))
    }
    return(NA_integer_)
  }

  suffix <- sub(sprintf("^%s", prefix), "", stem)
  suppressWarnings(as.integer(substr(suffix, 1, 4)))
}

find_popc_files <- function(raw_popc_dir, prefix) {
  patterns <- c(
    file.path(raw_popc_dir, sprintf("%s*.parquet", prefix)),
    file.path(raw_popc_dir, prefix, "*.parquet")
  )
  unique(unlist(lapply(patterns, Sys.glob), use.names = FALSE))
}

normalize_hfaudd_code <- function(code) {
  if (is.null(code) || is.na(code)) {
    return(NA_character_)
  }
  safe_code <- suppressWarnings(iconv(as.character(code), from = "", to = "ASCII//TRANSLIT", sub = ""))
  if (is.na(safe_code) || !nzchar(safe_code)) {
    return(NA_character_)
  }
  digits <- gsub("[^0-9]", "", trimws(safe_code))
  if (!nzchar(digits)) {
    return(NA_character_)
  }
  digits
}

normalize_ascii_text <- function(value) {
  if (is.null(value) || is.na(value)) {
    return(NA_character_)
  }
  safe_value <- suppressWarnings(iconv(as.character(value), from = "", to = "ASCII//TRANSLIT", sub = ""))
  if (is.na(safe_value)) {
    return(NA_character_)
  }
  trimws(safe_value)
}

parse_uddf_validity_date <- function(value, default = as.Date(NA)) {
  if (is.null(value) || is.na(value)) {
    return(default)
  }
  if (inherits(value, "Date")) {
    return(value)
  }

  text_value <- trimws(as.character(value))
  if (!nzchar(text_value)) {
    return(default)
  }

  parsed <- suppressWarnings(as.Date(text_value))
  if (!is.na(parsed)) {
    return(parsed)
  }

  digits <- gsub("[^0-9]", "", text_value)
  if (nchar(digits) >= 8) {
    parsed <- suppressWarnings(as.Date(substr(digits, 1, 8), format = "%Y%m%d"))
    if (!is.na(parsed)) {
      return(parsed)
    }
  }

  default
}

hfaudd_isced_map <- local({
  cache <- NULL

  function(json_path) {
    if (!is.null(cache)) {
      return(cache)
    }
    if (!file.exists(json_path)) {
      cache <<- setNames(character(), character())
      return(cache)
    }

    parsed <- jsonlite::read_json(json_path, simplifyVector = TRUE)
    mapping <- unlist(parsed, use.names = TRUE)
    names(mapping) <- vapply(names(mapping), normalize_hfaudd_code, character(1))
    mapping <- mapping[!is.na(names(mapping)) & nzchar(names(mapping))]
    cache <<- mapping
    cache
  }
})

resolve_isced_code <- function(code, hfaudd_json_path) {
  normalized <- normalize_hfaudd_code(code)
  if (is.na(normalized)) {
    return(NA_character_)
  }

  mapping <- hfaudd_isced_map(hfaudd_json_path)
  candidate_codes <- c(
    normalized,
    if (nchar(normalized) >= 4) substr(normalized, 1, 3),
    if (nchar(normalized) >= 3) substr(normalized, 1, 2)
  )
  candidate_codes <- unique(candidate_codes[!is.na(candidate_codes) & nzchar(candidate_codes)])

  for (candidate in candidate_codes) {
    value <- unname(mapping[candidate])
    if (length(value) && !is.na(value)) {
      return(as.character(value[[1]]))
    }
  }

  NA_character_
}

isced_rank <- function(isced_code) {
  value <- suppressWarnings(as.integer(isced_code))
  if (is.na(value)) {
    return(-1L)
  }
  value
}

classify_education_level_label <- function(hfaudd, hf_kilde, hfaudd_json_path, education_asset_path = NULL) {
  no_education_sources <- c("9", "10", "18")
  no_education_codes <- c("90", "9000", "9999")
  middle_school_codes <- c("1021", "1022", "1023", "1121", "1122", "1123", "1423", "1522", "1523", "1721", "1722", "1723")
  aggregate_short_codes <- c("10", "15")
  aggregate_medium_codes <- c("20", "30", "35")
  aggregate_long_codes <- c("40", "50", "60", "70", "80")

  source_code <- normalize_ascii_text(hf_kilde %||% "")
  if (nzchar(source_code) && source_code %in% no_education_sources) {
    return("no_completed_or_missing")
  }

  code <- normalize_hfaudd_code(hfaudd)
  if (is.na(code) || code %in% no_education_codes) {
    return("no_completed_or_missing")
  }

  if (code %in% middle_school_codes) {
    return("medium")
  }
  if (code %in% aggregate_medium_codes) {
    return("medium")
  }
  if (code %in% aggregate_short_codes) {
    return("short")
  }
  if (code %in% aggregate_long_codes) {
    return("long")
  }

  isced_code <- resolve_isced_code(code, hfaudd_json_path)
  if (is.na(isced_code) || isced_code == "9") {
    return("no_completed_or_missing")
  }
  if (isced_code %in% c("5", "6", "7", "8")) {
    return("long")
  }
  if (isced_code == "4") {
    return("medium")
  }
  if (isced_code %in% c("0", "1", "2", "3")) {
    return("short")
  }

  "no_completed_or_missing"
}

education_rank <- function(label) {
  match(label, c("no_completed_or_missing", "short", "medium", "long")) - 1L
}

combine_parent_education_label <- function(mother, father) {
  values <- c(mother, father)
  values <- values[!is.na(values)]
  if (!length(values)) {
    return("no_completed_or_missing")
  }
  values[[which.max(education_rank(values))]]
}

map_akm_socio_status_to_group_vec <- function(codes) {
  value  <- suppressWarnings(as.integer(trimws(as.character(codes))))
  result <- rep("missing_other", length(codes))
  result[!is.na(value) & ((value >= 110L & value <= 114L) | value == 120L |
    (value >= 131L & value <= 135L) | value == 139L | value == 310L)] <- "working_studying"
  result[!is.na(value) & (value == 210L | value == 410L)]             <- "temporarily_out"
  result[!is.na(value) & (value == 330L | value == 220L | value == 321L)] <- "outside_workforce"
  result[!is.na(value) & (value == 322L | value == 323L)]             <- "retired"
  result
}

combine_parent_socio_label <- function(mother, father) {
  values <- c(mother, father)
  values <- values[!is.na(values)]
  if (!length(values)) {
    return("missing_other")
  }
  if ("working_studying" %in% values) return("working_studying")
  if ("temporarily_out" %in% values) return("temporarily_out")
  if ("outside_workforce" %in% values) return("outside_workforce")
  if ("retired" %in% values) return("retired")
  "missing_other"
}

load_akm_lookup <- function(config, person_ids, min_year, max_year) {
  paths <- find_popc_files(config$raw_popc_dir, "akm")
  if (!length(paths)) {
    return(data.frame(person_id = character(), year = integer(), socio_group = character()))
  }

  years <- vapply(paths, parse_year_from_path, integer(1), prefix = "akm")
  keep <- !is.na(years) & years >= min_year & years <= max_year
  paths <- paths[keep]
  years <- years[keep]
  if (!length(paths)) {
    return(data.frame(person_id = character(), year = integer(), socio_group = character()))
  }

  rows <- vector("list", length(paths))
  for (i in seq_along(paths)) {
    df <- arrow::read_parquet(paths[[i]]) |>
      transmute(
        person_id = PNR,
        socio_code = dplyr::coalesce(SOCIO13, SOCIO02, SOCIO)
      ) |>
      filter(person_id %in% person_ids) |>
      mutate(
        year = years[[i]],
        socio_group = map_akm_socio_status_to_group_vec(socio_code)
      ) |>
      select(person_id, year, socio_group)
    rows[[i]] <- df
  }

  bind_rows(rows)
}

load_uddf_lookup <- function(config, person_ids, min_year, max_year) {
  paths <- find_popc_files(config$raw_popc_dir, "uddf")
  if (!length(paths)) {
    return(data.frame(
      person_id = character(),
      valid_from = as.Date(character()),
      valid_to = as.Date(character()),
      education_group = character(),
      isced_code = character(),
      stringsAsFactors = FALSE
    ))
  }

  rows <- vector("list", length(paths))
  for (i in seq_along(paths)) {
    df <- arrow::read_parquet(paths[[i]]) |>
      transmute(
        person_id = PNR,
        hfaudd = HFAUDD,
        hf_kilde = HF_KILDE,
        hf_vfra = HF_VFRA,
        hf_vtil = HF_VTIL
      ) |>
      filter(person_id %in% person_ids)

    if (!nrow(df)) {
      rows[[i]] <- data.frame(
        person_id = character(),
        valid_from = as.Date(character()),
        valid_to = as.Date(character()),
        education_group = character(),
        isced_code = character(),
        stringsAsFactors = FALSE
      )
      next
    }

    education_group <- vapply(
      seq_len(nrow(df)),
      function(j) classify_education_level_label(
        df$hfaudd[[j]],
        df$hf_kilde[[j]],
        hfaudd_json_path = config$hfaudd_json_path,
        education_asset_path = config$education_asset_path
      ),
      character(1)
    )

    df <- df |>
      transmute(
        person_id,
        valid_from = as.Date(vapply(hf_vfra, parse_uddf_validity_date, as.Date(NA))),
        valid_to = as.Date(vapply(hf_vtil, parse_uddf_validity_date, as.Date(NA))),
        education_group = education_group,
        isced_code = vapply(hfaudd, resolve_isced_code, character(1), hfaudd_json_path = config$hfaudd_json_path)
      ) |>
      distinct(person_id, valid_from, valid_to, education_group, isced_code)
    rows[[i]] <- df
  }

  bind_rows(rows) |>
    distinct(person_id, valid_from, valid_to, education_group, isced_code)
}

latest_group_for_parent <- function(parent_id, baseline_year, lookup_df, value_col) {
  if (is.na(parent_id) || !nzchar(parent_id)) {
    return(NA_character_)
  }
  rows <- lookup_df[lookup_df$person_id == parent_id & lookup_df$year <= baseline_year, , drop = FALSE]
  if (!nrow(rows)) {
    return(NA_character_)
  }
  rows[[value_col]][[which.max(rows$year)]]
}

highest_attained_group_for_parent <- function(parent_id, index_date, lookup_df, value_col = "education_group") {
  if (is.na(parent_id) || !nzchar(parent_id)) {
    return(NA_character_)
  }
  index_date <- as.Date(index_date)
  if (is.na(index_date)) {
    return(NA_character_)
  }
  rows <- lookup_df[
    lookup_df$person_id == parent_id &
      !is.na(lookup_df$valid_from) &
      lookup_df$valid_from <= index_date &
      (is.na(lookup_df$valid_to) | lookup_df$valid_to >= index_date),
    ,
    drop = FALSE
  ]
  if (!nrow(rows)) {
    rows <- lookup_df[
      lookup_df$person_id == parent_id &
        !is.na(lookup_df$valid_from) &
        lookup_df$valid_from <= index_date,
      ,
      drop = FALSE
    ]
  }
  if (!nrow(rows)) {
    return(NA_character_)
  }
  if (!("isced_code" %in% names(rows))) {
    rows <- rows[order(rows$valid_from), , drop = FALSE]
    return(rows[[value_col]][[nrow(rows)]])
  }

  score <- vapply(rows$isced_code, isced_rank, integer(1))
  valid_from_ord <- as.numeric(rows$valid_from)
  valid_from_ord[is.na(valid_from_ord)] <- -Inf
  order_idx <- order(score, valid_from_ord, na.last = TRUE)
  rows[[value_col]][[order_idx[[length(order_idx)]]]]
}

# Pre-indexed variants: accept already-subsetted rows for a single parent (or NULL).
latest_group_for_parent_rows <- function(rows, baseline_year, value_col) {
  if (is.null(rows) || !nrow(rows)) return(NA_character_)
  rows <- rows[rows$year <= baseline_year, , drop = FALSE]
  if (!nrow(rows)) return(NA_character_)
  rows[[value_col]][[which.max(rows$year)]]
}

highest_attained_group_for_parent_rows <- function(rows, index_date, value_col = "education_group") {
  if (is.null(rows) || !nrow(rows)) return(NA_character_)
  index_date <- as.Date(index_date)
  if (is.na(index_date)) return(NA_character_)
  active <- rows[
    !is.na(rows$valid_from) &
      rows$valid_from <= index_date &
      (is.na(rows$valid_to) | rows$valid_to >= index_date),
    ,
    drop = FALSE
  ]
  if (!nrow(active)) {
    active <- rows[!is.na(rows$valid_from) & rows$valid_from <= index_date, , drop = FALSE]
  }
  if (!nrow(active)) return(NA_character_)
  if (!("isced_code" %in% names(active))) {
    return(active[[value_col]][[which.max(as.numeric(active$valid_from))]])
  }
  score          <- vapply(active$isced_code, isced_rank, integer(1))
  valid_from_ord <- as.numeric(active$valid_from)
  valid_from_ord[is.na(valid_from_ord)] <- -Inf
  order_idx      <- order(score, valid_from_ord, na.last = TRUE)
  active[[value_col]][[order_idx[[length(order_idx)]]]]
}

build_parent_role_rows <- function(baseline_df, index_dates, baseline_years) {
  base_rows <- data.frame(
    row_id = seq_len(nrow(baseline_df)),
    index_date = as.Date(index_dates),
    baseline_year = baseline_years,
    mother_id = as.character(baseline_df$mother_id),
    father_id = as.character(baseline_df$father_id),
    stringsAsFactors = FALSE
  )

  bind_rows(
    data.frame(
      row_id = base_rows$row_id,
      role = "mother",
      parent_id = base_rows$mother_id,
      index_date = base_rows$index_date,
      baseline_year = base_rows$baseline_year,
      stringsAsFactors = FALSE
    ),
    data.frame(
      row_id = base_rows$row_id,
      role = "father",
      parent_id = base_rows$father_id,
      index_date = base_rows$index_date,
      baseline_year = base_rows$baseline_year,
      stringsAsFactors = FALSE
    )
  ) |>
    filter(!is.na(parent_id), nzchar(parent_id))
}

select_latest_parent_socio <- function(parent_role_rows, akm_lookup) {
  if (!nrow(parent_role_rows) || !nrow(akm_lookup)) {
    return(data.frame(
      row_id = integer(),
      role = character(),
      socio_group = character(),
      stringsAsFactors = FALSE
    ))
  }

  parent_role_rows |>
    inner_join(akm_lookup, by = c("parent_id" = "person_id"), relationship = "many-to-many") |>
    filter(!is.na(year), !is.na(baseline_year), year <= baseline_year) |>
    group_by(row_id, role) |>
    slice_max(year, n = 1, with_ties = FALSE) |>
    ungroup() |>
    transmute(row_id, role, socio_group) |>
    as.data.frame(stringsAsFactors = FALSE)
}

select_highest_parent_education <- function(parent_role_rows, uddf_lookup) {
  if (!nrow(parent_role_rows) || !nrow(uddf_lookup)) {
    return(data.frame(
      row_id = integer(),
      role = character(),
      education_group = character(),
      stringsAsFactors = FALSE
    ))
  }

  joined <- parent_role_rows |>
    inner_join(uddf_lookup, by = c("parent_id" = "person_id"), relationship = "many-to-many") |>
    mutate(
      valid_from_num = as.numeric(valid_from),
      active_now = !is.na(valid_from) & valid_from <= index_date & (is.na(valid_to) | valid_to >= index_date),
      historical_ok = !is.na(valid_from) & valid_from <= index_date
    ) |>
    filter(active_now | historical_ok)

  if (!nrow(joined)) {
    return(data.frame(
      row_id = integer(),
      role = character(),
      education_group = character(),
      stringsAsFactors = FALSE
    ))
  }

  joined |>
    group_by(row_id, role) |>
    mutate(
      has_active_now = any(active_now),
      use_row = if_else(has_active_now, active_now, historical_ok),
      isced_score = vapply(isced_code, isced_rank, integer(1))
    ) |>
    filter(use_row) |>
    arrange(isced_score, valid_from_num, .by_group = TRUE) |>
    slice_tail(n = 1L) |>
    ungroup() |>
    transmute(row_id, role, education_group) |>
    as.data.frame(stringsAsFactors = FALSE)
}

compute_parental_covariates <- function(baseline_df, config) {
  parent_ids <- unique(c(baseline_df$mother_id, baseline_df$father_id))
  parent_ids <- parent_ids[!is.na(parent_ids) & nzchar(parent_ids)]
  if (!length(parent_ids) || !nrow(baseline_df)) {
    return(data.frame(
      parent_education_group = rep("no_completed_or_missing", nrow(baseline_df)),
      parent_socio_group = rep("missing_other", nrow(baseline_df)),
      stringsAsFactors = FALSE
    ))
  }

  index_dates <- as.Date(baseline_df$index_date)
  index_years <- as.integer(format(index_dates, "%Y"))
  baseline_years <- as.integer(format(dplyr::coalesce(baseline_df$baseline_end, baseline_df$index_date - 1), "%Y"))
  min_year <- min(index_years, na.rm = TRUE)
  max_year <- max(index_years, na.rm = TRUE)

  akm_lookup  <- load_akm_lookup(config, parent_ids, min_year, max_year)
  uddf_lookup <- load_uddf_lookup(config, parent_ids, min_year, max_year)
  parent_role_rows <- build_parent_role_rows(baseline_df, index_dates, baseline_years)

  socio_selected <- select_latest_parent_socio(parent_role_rows, akm_lookup) |>
    tidyr::pivot_wider(
      id_cols = row_id,
      names_from = role,
      values_from = socio_group,
      names_glue = "{role}_socio"
    ) |>
    as.data.frame(stringsAsFactors = FALSE)

  edu_selected <- select_highest_parent_education(parent_role_rows, uddf_lookup) |>
    tidyr::pivot_wider(
      id_cols = row_id,
      names_from = role,
      values_from = education_group,
      names_glue = "{role}_education"
    ) |>
    as.data.frame(stringsAsFactors = FALSE)

  combined <- data.frame(
    row_id = seq_len(nrow(baseline_df)),
    stringsAsFactors = FALSE
  ) |>
    left_join(socio_selected, by = "row_id") |>
    left_join(edu_selected, by = "row_id") |>
    as.data.frame(stringsAsFactors = FALSE)

  for (col in c("mother_socio", "father_socio", "mother_education", "father_education")) {
    if (!(col %in% names(combined))) {
      combined[[col]] <- NA_character_
    }
  }

  parent_education_group <- mapply(
    combine_parent_education_label,
    combined$mother_education,
    combined$father_education,
    USE.NAMES = FALSE
  )
  parent_socio_group <- mapply(
    combine_parent_socio_label,
    combined$mother_socio,
    combined$father_socio,
    USE.NAMES = FALSE
  )

  data.frame(
    parent_education_group = parent_education_group,
    parent_socio_group     = parent_socio_group,
    stringsAsFactors = FALSE
  )
}

build_parental_education_diagnostics <- function(baseline_df, config) {
  parent_ids <- unique(c(baseline_df$mother_id, baseline_df$father_id))
  parent_ids <- parent_ids[!is.na(parent_ids) & nzchar(parent_ids)]
  index_dates <- as.Date(baseline_df$index_date)
  index_years <- as.integer(format(index_dates, "%Y"))

  if (!length(parent_ids) || !length(index_years)) {
    empty_row <- data.frame(
      person_id = character(),
      index_year = integer(),
      mother_id = character(),
      father_id = character(),
      mother_has_id = logical(),
      father_has_id = logical(),
      any_parent_id = logical(),
      mother_has_uddf_by_index = logical(),
      father_has_uddf_by_index = logical(),
      any_parent_uddf_by_index = logical(),
      mother_education_group = character(),
      father_education_group = character(),
      combined_parent_education_group = character(),
      stringsAsFactors = FALSE
    )
    return(list(
      row_level = empty_row,
      summary = data.frame(),
      lookup_summary = data.frame()
    ))
  }

  min_year <- min(index_years, na.rm = TRUE)
  max_year <- max(index_years, na.rm = TRUE)
  uddf_lookup <- load_uddf_lookup(config, parent_ids, min_year, max_year)
  uddf_by_parent <- split(uddf_lookup, uddf_lookup$person_id)

  row_level <- vector("list", nrow(baseline_df))
  for (i in seq_len(nrow(baseline_df))) {
    index_date <- index_dates[[i]]
    index_year <- index_years[[i]]
    mother_id <- baseline_df$mother_id[[i]]
    father_id <- baseline_df$father_id[[i]]

    mother_has_id <- !is.na(mother_id) && nzchar(mother_id)
    father_has_id <- !is.na(father_id) && nzchar(father_id)
    mother_lookup_rows <- if (mother_has_id) uddf_by_parent[[mother_id]] else NULL
    father_lookup_rows <- if (father_has_id) uddf_by_parent[[father_id]] else NULL
    mother_rows <- if (!is.null(mother_lookup_rows) && nrow(mother_lookup_rows)) {
      mother_lookup_rows[
        !is.na(mother_lookup_rows$valid_from) &
          mother_lookup_rows$valid_from <= index_date,
        ,
        drop = FALSE
      ]
    } else {
      uddf_lookup[0, , drop = FALSE]
    }
    father_rows <- if (!is.null(father_lookup_rows) && nrow(father_lookup_rows)) {
      father_lookup_rows[
        !is.na(father_lookup_rows$valid_from) &
          father_lookup_rows$valid_from <= index_date,
        ,
        drop = FALSE
      ]
    } else {
      uddf_lookup[0, , drop = FALSE]
    }
    mother_group <- highest_attained_group_for_parent_rows(mother_lookup_rows, index_date, "education_group")
    father_group <- highest_attained_group_for_parent_rows(father_lookup_rows, index_date, "education_group")

    row_level[[i]] <- data.frame(
      person_id = baseline_df$person_id[[i]],
      index_year = index_year,
      mother_id = if (mother_has_id) mother_id else NA_character_,
      father_id = if (father_has_id) father_id else NA_character_,
      mother_has_id = mother_has_id,
      father_has_id = father_has_id,
      any_parent_id = mother_has_id || father_has_id,
      mother_has_uddf_by_index = nrow(mother_rows) > 0,
      father_has_uddf_by_index = nrow(father_rows) > 0,
      any_parent_uddf_by_index = nrow(mother_rows) > 0 || nrow(father_rows) > 0,
      mother_education_group = mother_group,
      father_education_group = father_group,
      combined_parent_education_group = combine_parent_education_label(mother_group, father_group),
      stringsAsFactors = FALSE
    )
  }

  row_level_df <- bind_rows(row_level)
  summary_df <- row_level_df |>
    mutate(
      linkage_state = case_when(
        !any_parent_id ~ "no_parent_ids",
        any_parent_id & !any_parent_uddf_by_index ~ "parent_ids_but_no_uddf_by_index",
        TRUE ~ "has_uddf_by_index"
      )
    ) |>
    group_by(linkage_state, combined_parent_education_group) |>
    summarise(rows = n(), .groups = "drop") |>
    arrange(linkage_state, desc(rows)) |>
    as.data.frame(stringsAsFactors = FALSE)

  lookup_summary_df <- uddf_lookup |>
    group_by(education_group) |>
    summarise(rows = n(), unique_parents = n_distinct(person_id), .groups = "drop") |>
    arrange(desc(rows)) |>
    as.data.frame(stringsAsFactors = FALSE)

  list(
    row_level = row_level_df,
    summary = summary_df,
    lookup_summary = lookup_summary_df
  )
}

write_parental_education_diagnostics <- function(diagnostics, config) {
  ensure_output_dir(config)

  paths <- list(
    row_level_path = file.path(config$output_dir, "parental_education_diagnostics.parquet"),
    summary_path = file.path(config$output_dir, "parental_education_diagnostics_summary.csv"),
    lookup_summary_path = file.path(config$output_dir, "parental_education_lookup_summary.csv")
  )

  arrow::write_parquet(diagnostics$row_level, paths$row_level_path)
  utils::write.csv(diagnostics$summary, paths$summary_path, row.names = FALSE)
  utils::write.csv(diagnostics$lookup_summary, paths$lookup_summary_path, row.names = FALSE)

  paths
}
