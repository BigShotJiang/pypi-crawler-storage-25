suppressPackageStartupMessages({
  library(dplyr)
})

matched_table1_variable_label_map <- function() {
  c(
    age_at_index_months = "Age at index, months",
    maternal_age_birth = "Maternal age at birth, years",
    baseline_observed_person_years = "Observed pre-index follow-up, person-years",
    preindex_util_total_rate = "Pre-index utilization per person-year",
    preindex_hosp_days_rate = "Pre-index hospital days per person-year",
    sex = "Sex",
    region = "Region",
    gest_age_cat = "Gestational age",
    birth_weight_cat = "Birth weight",
    parity_cat = "Parity",
    multiple_birth = "Multiple birth",
    maternal_age_birth_group = "Maternal age at birth group",
    apgar_cat = "Apgar score at 5 min",
    parent_education_group = "Parental education",
    parent_socio_group = "Parental socioeconomic position",
    cohabitation_group = "Parental cohabitation",
    ethnicity_group = "Ethnicity",
    truncated_lookback_flag = "Truncated lookback"
  )
}

matched_table1_source_note <- function() {
  "Continuous variables are reported as median (IQR); categorical variables are reported as n (%)."
}

matched_table1_variable_labels <- function() {
  label_map <- matched_table1_variable_label_map()
  stats::setNames(as.list(unname(label_map)), names(label_map))
}

matched_table1_continuous_vars <- function() {
  c(
    "age_at_index_months",
    "maternal_age_birth",
    "baseline_observed_person_years",
    "preindex_util_total_rate",
    "preindex_hosp_days_rate"
  )
}

matched_table1_categorical_vars <- function() {
  c(
    "sex",
    "region",
    "gest_age_cat",
    "birth_weight_cat",
    "parity_cat",
    "multiple_birth",
    "maternal_age_birth_group",
    "apgar_cat",
    "parent_education_group",
    "parent_socio_group",
    "cohabitation_group",
    "ethnicity_group",
    "truncated_lookback_flag"
  )
}

matched_table1_variable_order <- function() {
  c(
    "age_at_index_months",
    "baseline_observed_person_years",
    "gest_age_cat",
    "birth_weight_cat",
    "parity_cat",
    "multiple_birth",
    "maternal_age_birth",
    "maternal_age_birth_group",
    "apgar_cat",
    "sex",
    "region",
    "parent_education_group",
    "parent_socio_group",
    "cohabitation_group",
    "ethnicity_group",
    "preindex_util_total_rate",
    "preindex_hosp_days_rate"
  )
}

matched_table1_diagnostic_vars <- function() {
  c(
    "truncated_lookback_flag"
  )
}

matched_table1_section_map <- function() {
  list(
    "Cohort timing and baseline window" = c(
      "Age at index, months",
      "Observed pre-index follow-up, person-years",
      "Truncated lookback"
    ),
    "Perinatal and early-life factors" = c(
      "Gestational age",
      "Birth weight",
      "Parity",
      "Multiple birth",
      "Maternal age at birth, years",
      "Maternal age at birth group",
      "Apgar score at 5 min",
      "Sex",
      "Region"
    ),
    "Family socioeconomic baseline" = c(
      "Parental education",
      "Parental socioeconomic position",
      "Parental cohabitation",
      "Ethnicity"
    ),
    "Baseline morbidity and utilization" = c(
      "Pre-index utilization per person-year",
      "Pre-index hospital days per person-year"
    )
  )
}

matched_table1_variable_sections <- function() {
  section_map <- matched_table1_section_map()
  variable_labels <- matched_table1_variable_label_map()
  section_lookup <- character(0)
  for (section_name in names(section_map)) {
    labels_in_section <- section_map[[section_name]]
    matching_vars <- vapply(
      variable_labels,
      function(label_text) label_text %in% labels_in_section,
      logical(1)
    )
    section_lookup <- c(section_lookup, stats::setNames(
      rep(section_name, sum(matching_vars)),
      names(variable_labels)[matching_vars]
    ))
  }
  section_lookup
}

prepare_matched_table1_data <- function(matched_df) {
  age_at_index_months <- ifelse(
    is.na(matched_df$birth_date),
    NA_real_,
    as.numeric(matched_df$index_date - matched_df$birth_date) / 30.4375
  )

  matched_df |>
    mutate(
      exposure_group = factor(
        ifelse(exposed, "Exposed", "Unexposed"),
        levels = c("Exposed", "Unexposed")
      ),
      sex = factor(sex, levels = c(2L, 1L), labels = c("Female", "Male")),
      region = factor(dplyr::recode(
        as.character(region),
        "81" = "Capital",
        "82" = "Zealand",
        "83" = "South Denmark",
        "84" = "Central Jutland",
        "85" = "North Jutland",
        .default = as.character(region)
      ), levels = c("Capital", "Zealand", "South Denmark", "Central Jutland", "North Jutland")),
      gest_age_cat = factor(dplyr::recode(
        as.character(gest_age_cat),
        "lt_32w" = "<32 weeks",
        "32_36w" = "32-36 weeks",
        "37_41w" = "37-41 weeks",
        "42w_plus" = "42+ weeks",
        .default = as.character(gest_age_cat)
      ), levels = c("<32 weeks", "32-36 weeks", "37-41 weeks", "42+ weeks")),
      birth_weight_cat = factor(dplyr::recode(
        as.character(birth_weight_cat),
        "lt_1500g" = "<1500 g",
        "1500_2499g" = "1500-2499 g",
        "2500_3999g" = "2500-3999 g",
        "4000_plus_g" = "4000+ g",
        .default = as.character(birth_weight_cat)
      ), levels = c("<1500 g", "1500-2499 g", "2500-3999 g", "4000+ g")),
      parity_cat = factor(
        dplyr::recode(as.character(parity_cat), "4_plus" = "4+", .default = as.character(parity_cat)),
        levels = c("0", "1", "2", "3", "4+")
      ),
      multiple_birth = factor(
        dplyr::recode(as.character(multiple_birth), "yes" = "Yes", "no" = "No", .default = as.character(multiple_birth)),
        levels = c("No", "Yes")
      ),
      maternal_age_birth_group = factor(dplyr::recode(
        as.character(maternal_age_birth_group),
        "lt_25" = "<25",
        "25_29" = "25-29",
        "30_34" = "30-34",
        "35_plus" = "35+",
        .default = as.character(maternal_age_birth_group)
      ), levels = c("<25", "25-29", "30-34", "35+")),
      apgar_cat = factor(dplyr::recode(
        as.character(apgar_cat),
        "0_3" = "0-3",
        "4_6" = "4-6",
        "7_10" = "7-10",
        .default = as.character(apgar_cat)
      ), levels = c("0-3", "4-6", "7-10")),
      parent_education_group = factor(dplyr::recode(
        as.character(parent_education_group),
        "no_completed_or_missing" = "No completed / missing",
        "short" = "Short",
        "medium" = "Medium",
        "long" = "Long",
        .default = as.character(parent_education_group)
      ), levels = c("No completed / missing", "Short", "Medium", "Long")),
      parent_socio_group = factor(dplyr::recode(
        as.character(parent_socio_group),
        "working_studying" = "Working / studying",
        "temporarily_out" = "Temporarily out",
        "outside_workforce" = "Outside workforce",
        "retired" = "Retired",
        "missing_other" = "Missing / other",
        .default = as.character(parent_socio_group)
      ), levels = c("Working / studying", "Temporarily out", "Outside workforce", "Retired", "Missing / other")),
      cohabitation_group = factor(dplyr::recode(
        as.character(cohabitation_group),
        "cohabiting" = "Cohabiting",
        "single_or_noncohabiting" = "Single / non-cohabiting",
        .default = as.character(cohabitation_group)
      ), levels = c("Cohabiting", "Single / non-cohabiting")),
      ethnicity_group = factor(dplyr::recode(
        as.character(ethnicity_group),
        "danish" = "Danish",
        "immigrant_or_descendant" = "Immigrant / descendant",
        "other_non_danish" = "Other non-Danish",
        .default = as.character(ethnicity_group)
      ), levels = c("Danish", "Immigrant / descendant", "Other non-Danish")),
      truncated_lookback_flag = factor(
        ifelse(truncated_lookback_flag, "Yes", "No"),
        levels = c("No", "Yes")
      ),
      age_at_index_months = age_at_index_months
    )
}

build_matched_table1_gtsummary <- function(matched_df) {
  if (!requireNamespace("gtsummary", quietly = TRUE)) {
    stop("Package `gtsummary` is required to build the matched Table 1.")
  }
  if (!requireNamespace("gt", quietly = TRUE)) {
    stop("Package `gt` is required to export the matched Table 1.")
  }

  table1_df <- prepare_matched_table1_data(matched_df)
  include_vars <- intersect(matched_table1_variable_order(), names(table1_df))
  continuous_vars <- intersect(matched_table1_continuous_vars(), names(table1_df))
  exposed_n <- sum(table1_df$exposure_group == "Exposed", na.rm = TRUE)
  unexposed_n <- sum(table1_df$exposure_group == "Unexposed", na.rm = TRUE)

  table1_tbl <- gtsummary::tbl_summary(
    data = table1_df,
    by = exposure_group,
    include = dplyr::all_of(include_vars),
    type = list(dplyr::all_of(continuous_vars) ~ "continuous"),
    label = matched_table1_variable_labels(),
    statistic = list(
      gtsummary::all_continuous() ~ "{median} ({p25}, {p75})",
      gtsummary::all_categorical() ~ "{n} ({p}%)"
    ),
    digits = list(
      gtsummary::all_continuous() ~ 2,
      gtsummary::all_categorical() ~ c(0, 1)
    ),
    missing = "no"
  ) |>
    gtsummary::modify_header(
      stat_1 = sprintf("**Exposed**  \nN = %s", format(exposed_n, big.mark = ",")),
      stat_2 = sprintf("**Unexposed**  \nN = %s", format(unexposed_n, big.mark = ","))
    ) |>
    gtsummary::bold_labels()

  table1_tbl
}

matched_table1_display_body <- function(table1_tbl) {
  body <- table1_tbl$table_body
  stat_cols <- grep("^stat_", names(body), value = TRUE)
  body$label <- gsub("^__|__$", "", body$label)
  body$row_sequence <- seq_len(nrow(body))

  if ("row_type" %in% names(body)) {
    zero_only_level <- apply(
      body[, stat_cols, drop = FALSE],
      1,
      function(row_stats) {
        all(grepl("^0 \\(0(?:\\.0)?%\\)$", row_stats) | is.na(row_stats))
      }
    )
    body <- body |>
      dplyr::filter(!(row_type == "level" & zero_only_level))
  }

  section_map <- matched_table1_section_map()
  variable_to_section <- matched_table1_variable_sections()

  body$section <- dplyr::coalesce(
    unname(variable_to_section[body$variable]),
    NA_character_
  )
  label_positions <- stats::setNames(
    seq_along(matched_table1_variable_order()),
    matched_table1_variable_order()
  )
  body$section_order <- match(body$section, names(section_map))
  body$label_order <- dplyr::coalesce(label_positions[body$variable], Inf)

  body <- body |>
    dplyr::mutate(
      row_type_order = dplyr::case_when(
        row_type == "label" ~ 1L,
        row_type == "level" ~ 2L,
        TRUE ~ 3L
      )
    ) |>
    dplyr::arrange(section_order, label_order, row_sequence)

  stat_missing <- if (length(stat_cols)) {
    rowSums(is.na(body[, stat_cols, drop = FALSE])) == length(stat_cols)
  } else {
    rep(TRUE, nrow(body))
  }
  body <- body[!(is.na(body$label) & is.na(body$variable) & stat_missing), , drop = FALSE]

  body <- body[body$label != "Unknown" | is.na(body$label), , drop = FALSE]

  section_blocks <- lapply(names(section_map), function(section_name) {
    section_body <- body[!is.na(body$section) & body$section == section_name, , drop = FALSE]
    if (!nrow(section_body)) {
      return(NULL)
    }

    section_row <- as.data.frame(lapply(section_body[1, , drop = FALSE], function(x) {
      if (inherits(x, "Date")) {
        as.Date(NA)
      } else if (is.factor(x)) {
        factor(NA, levels = levels(x))
      } else if (is.numeric(x)) {
        NA_real_
      } else if (is.integer(x)) {
        NA_integer_
      } else {
        NA
      }
    }), stringsAsFactors = FALSE)
    section_row <- tibble::as_tibble(section_row)
    section_row$label <- section_name
    section_row$row_type <- "label"
    section_row$variable <- NA_character_

    dplyr::bind_rows(section_row, section_body)
  })

  dplyr::bind_rows(section_blocks) |>
    dplyr::select(dplyr::any_of(c("variable", "row_type", "label", "stat_1", "stat_2")))
}

matched_table1_diagnostic_body <- function(matched_df) {
  table1_df <- prepare_matched_table1_data(matched_df)
  diag_vars <- intersect(
    c("baseline_observed_person_years", matched_table1_diagnostic_vars()),
    names(table1_df)
  )
  if (!length(diag_vars)) {
    return(tibble::tibble(label = character(), stat_1 = character(), stat_2 = character()))
  }

  diag_tbl <- gtsummary::tbl_summary(
    data = table1_df,
    by = exposure_group,
    include = dplyr::all_of(diag_vars),
    type = list(
      baseline_observed_person_years ~ "continuous"
    ),
    label = matched_table1_variable_labels(),
    statistic = list(
      gtsummary::all_continuous() ~ "{median} ({p25}, {p75})",
      gtsummary::all_categorical() ~ "{n} ({p}%)"
    ),
    digits = list(
      gtsummary::all_continuous() ~ 2,
      gtsummary::all_categorical() ~ c(0, 1)
    ),
    missing = "no"
  )

  diag_tbl$table_body |>
    dplyr::transmute(
      label = gsub("^__|__$", "", label),
      stat_1 = stat_1,
      stat_2 = stat_2
    ) |>
    dplyr::filter(!is.na(label), nzchar(label), label != "Unknown")
}

write_matched_table1_outputs <- function(matched_df, output_dir) {
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  cache_dir <- file.path(output_dir, ".cache")
  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)

  old_cache_dir <- Sys.getenv("R_USER_CACHE_DIR", unset = NA_character_)
  Sys.setenv(R_USER_CACHE_DIR = cache_dir)
  on.exit({
    if (is.na(old_cache_dir)) {
      Sys.unsetenv("R_USER_CACHE_DIR")
    } else {
      Sys.setenv(R_USER_CACHE_DIR = old_cache_dir)
    }
  }, add = TRUE)

  table1_tbl <- build_matched_table1_gtsummary(matched_df)
  table1_df <- prepare_matched_table1_data(matched_df)
  exposed_n <- sum(table1_df$exposure_group == "Exposed", na.rm = TRUE)
  unexposed_n <- sum(table1_df$exposure_group == "Unexposed", na.rm = TRUE)
  exposed_header <- sprintf("Exposed (N = %s)", format(exposed_n, big.mark = ","))
  unexposed_header <- sprintf("Unexposed (N = %s)", format(unexposed_n, big.mark = ","))
  display_body <- matched_table1_display_body(table1_tbl) |>
    dplyr::transmute(
      variable = variable,
      row_type = row_type,
      label = label,
      stat_1 = stat_1,
      stat_2 = stat_2,
      is_section = is.na(variable) & row_type == "label"
    ) |>
    dplyr::filter(!is.na(label), nzchar(label))
  diagnostic_body <- matched_table1_diagnostic_body(matched_df)
  html_path <- file.path(output_dir, "table1_matched.html")
  csv_path <- file.path(output_dir, "table1_matched.csv")
  diagnostics_html_path <- file.path(output_dir, "table1_baseline_window.html")
  diagnostics_csv_path <- file.path(output_dir, "table1_baseline_window.csv")

  blank_missing_cells <- function(df) {
    df[] <- lapply(df, function(col) {
      if (is.character(col)) {
        col[is.na(col)] <- ""
      }
      col
    })
    df
  }
  html_display_body <- blank_missing_cells(display_body)
  html_diagnostic_body <- blank_missing_cells(diagnostic_body)

  writeLines(
    gt::as_raw_html(
      gt::gt(html_display_body) |>
        gt::cols_label(
          label = "Characteristic",
          stat_1 = exposed_header,
          stat_2 = unexposed_header
        ) |>
        gt::cols_hide(columns = c(variable, row_type, is_section)) |>
        gt::tab_options(
          table.font.size = 13,
          data_row.padding = gt::px(4),
          table_body.hlines.style = "solid",
          table.width = gt::pct(100),
          column_labels.border.bottom.width = gt::px(2)
        ) |>
        gt::opt_row_striping() |>
        gt::tab_style(
          style = list(
            gt::cell_fill(color = "#eef3f8"),
            gt::cell_text(weight = "bold")
          ),
          locations = gt::cells_body(rows = html_display_body$is_section)
        ) |>
        gt::tab_style(
          style = gt::cell_text(weight = "bold"),
          locations = gt::cells_body(rows = !html_display_body$is_section & html_display_body$row_type == "label")
        ) |>
        gt::tab_style(
          style = gt::cell_text(indent = gt::px(20)),
          locations = gt::cells_body(rows = html_display_body$row_type == "level", columns = label)
        ) |>
        gt::tab_source_note(source_note = matched_table1_source_note())
    ),
    con = html_path,
    useBytes = TRUE
  )
  utils::write.csv(
    display_body |>
      dplyr::transmute(
        Characteristic = label,
        !!exposed_header := stat_1,
        !!unexposed_header := stat_2
      ) |>
      dplyr::bind_rows(
        tibble::tibble(
          Characteristic = paste0("Note: ", matched_table1_source_note()),
          !!exposed_header := NA_character_,
          !!unexposed_header := NA_character_
        )
      ) |>
      blank_missing_cells(),
    csv_path,
    row.names = FALSE
  )
  writeLines(
    gt::as_raw_html(
      gt::gt(html_diagnostic_body) |>
        gt::cols_label(
          label = "Baseline window diagnostic",
          stat_1 = exposed_header,
          stat_2 = unexposed_header
        ) |>
        gt::tab_options(
          table.font.size = 13,
          data_row.padding = gt::px(4),
          table.width = gt::pct(100),
          column_labels.border.bottom.width = gt::px(2)
        ) |>
        gt::tab_header(title = "Baseline Window Diagnostics for Matched Cohort") |>
        gt::tab_source_note(source_note = matched_table1_source_note())
    ),
    con = diagnostics_html_path,
    useBytes = TRUE
  )
  utils::write.csv(
    diagnostic_body |>
      dplyr::transmute(
        `Baseline window diagnostic` = label,
        !!exposed_header := stat_1,
        !!unexposed_header := stat_2
      ) |>
      dplyr::bind_rows(
        tibble::tibble(
          `Baseline window diagnostic` = paste0("Note: ", matched_table1_source_note()),
          !!exposed_header := NA_character_,
          !!unexposed_header := NA_character_
        )
      ) |>
      blank_missing_cells(),
    diagnostics_csv_path,
    row.names = FALSE
  )

  list(
    html_path = html_path,
    csv_path = csv_path,
    diagnostics_html_path = diagnostics_html_path,
    diagnostics_csv_path = diagnostics_csv_path
  )
}
