suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
})

# Build all follow-up segments in one vectorized pass over matched_df.
# Returns the same schema as the old per-person lapply approach.
build_followup_segments_vectorized <- function(matched_df, max_followup_years = 10L) {
  valid <- !is.na(matched_df$index_date)
  if (!any(valid)) return(data.frame())
  df <- matched_df[valid, , drop = FALSE]
  n  <- nrow(df)

  # Study end per person: end of follow-up year max, clamped to censor_date
  study_end_unc <- add_years_vec(df$index_date, max_followup_years) - 1L
  study_end     <- study_end_unc
  has_censor    <- !is.na(df$censor_date)
  if (any(has_censor)) {
    study_end[has_censor] <- pmin(
      as.Date(df$censor_date[has_censor]),
      study_end_unc[has_censor]
    )
  }

  # Expand to person × followup_year grid (rectangular: all persons get max_followup_years slots)
  idx <- rep(seq_len(n),            each  = max_followup_years)
  fy  <- rep(seq_len(max_followup_years), times = n)

  index_date_r <- df$index_date[idx]
  study_end_r  <- study_end[idx]

  seg_start    <- add_years_vec(index_date_r, fy - 1L)
  seg_end_full <- add_years_vec(index_date_r, fy) - 1L
  seg_end      <- pmin(seg_end_full, study_end_r)

  valid_rows <- seg_end >= seg_start
  if (!any(valid_rows)) return(data.frame())

  i   <- idx[valid_rows]
  fyv <- fy[valid_rows]
  ss  <- seg_start[valid_rows]
  se  <- seg_end[valid_rows]
  sef <- seg_end_full[valid_rows]

  obs_days  <- as.numeric(se - ss) + 1
  full_days <- as.numeric(sef - ss) + 1

  data.frame(
    person_id             = df$person_id[i],
    family_id             = if ("family_id"      %in% names(df)) df$family_id[i]      else NA_character_,
    matched_set_id        = if ("matched_set_id" %in% names(df)) df$matched_set_id[i] else NA_character_,
    match_weight          = if ("match_weight"   %in% names(df)) df$match_weight[i]   else NA_real_,
    exposed               = as.logical(df$exposed[i]),
    diagnosis_group       = df$diagnosis_group[i],
    severity              = df$severity[i],
    index_date            = df$index_date[i],
    index_year            = as.integer(format(df$index_date[i], "%Y")),
    followup_year         = fyv,
    segment_start         = ss,
    segment_end           = se,
    observed_days         = obs_days,
    observed_person_years = obs_days / 365.25,
    observed_fraction     = ifelse(full_days > 0, obs_days / full_days, 0),
    stringsAsFactors      = FALSE
  )
}

load_relevant_harmonized_costs <- function(harmonized_cost_path, matched_df, max_followup_years = 10L) {
  if (!file.exists(harmonized_cost_path) || !nrow(matched_df)) {
    return(data.frame())
  }

  valid <- !is.na(matched_df$index_date)
  if (!any(valid)) {
    return(data.frame())
  }

  matched_df <- matched_df[valid, , drop = FALSE]
  person_ids <- unique(as.character(matched_df$person_id))
  person_ids <- person_ids[!is.na(person_ids) & nzchar(person_ids)]
  min_year <- min(as.integer(format(as.Date(matched_df$index_date), "%Y")), na.rm = TRUE)
  max_year <- max(as.integer(format(add_years_vec(as.Date(matched_df$index_date), max_followup_years) - 1L, "%Y")), na.rm = TRUE)

  ds <- arrow::open_dataset(harmonized_cost_path, format = "parquet")
  selected_columns <- intersect(
    c(
      "person_id", "year", "component", "source_system", "source_era", "coverage_status",
      "nominal_cost", "cost_reference_dkk", "cpi_index", "reference_price_year",
      "cpi_adjustment_factor"
    ),
    names(ds$schema)
  )

  ds |>
    select(dplyr::all_of(selected_columns)) |>
    filter(person_id %in% person_ids, year >= min_year, year <= max_year) |>
    group_by(
      person_id, year, component, source_system, source_era, coverage_status,
      cpi_index, reference_price_year, cpi_adjustment_factor
    ) |>
    summarise(
      nominal_cost = sum(nominal_cost, na.rm = TRUE),
      cost_reference_dkk = sum(cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    collect() |>
    as.data.frame(stringsAsFactors = FALSE)
}

allocate_person_year_cost_to_followup <- function(segment_df, cost_df, max_followup_years = 10L, exclude_first_n_days = 0L) {
  if (!nrow(segment_df) || !nrow(cost_df)) {
    return(data.frame())
  }

  merged <- dplyr::inner_join(segment_df, cost_df, by = "person_id")

  if (!nrow(merged)) {
    return(data.frame())
  }

  merged$calendar_year  <- merged$year
  merged$calendar_start <- as.Date(sprintf("%04d-01-01", merged$calendar_year))
  merged$calendar_end   <- as.Date(sprintf("%04d-12-31", merged$calendar_year))
  overlap_start <- pmax(merged$segment_start, merged$calendar_start)
  overlap_end   <- pmin(merged$segment_end,   merged$calendar_end)

  if (exclude_first_n_days > 0L) {
    exclusion_end <- merged$index_date + as.difftime(as.integer(exclude_first_n_days) - 1L, units = "days")
    overlap_start <- pmax(overlap_start, exclusion_end + 1L)
  }

  merged$allocation_overlap_days <- as.numeric(overlap_end - overlap_start) + 1
  merged$allocation_overlap_days[is.na(merged$allocation_overlap_days) | merged$allocation_overlap_days < 0] <- 0
  merged <- merged[merged$allocation_overlap_days > 0, , drop = FALSE]

  if (!nrow(merged)) {
    return(data.frame())
  }

  calendar_days <- as.numeric(merged$calendar_end - merged$calendar_start) + 1
  merged$allocation_fraction               <- merged$allocation_overlap_days / calendar_days
  merged$nominal_cost_allocated            <- merged$nominal_cost * merged$allocation_fraction
  merged$cost_reference_dkk_allocated      <- merged$cost_reference_dkk * merged$allocation_fraction
  merged$service_year_cpi_index            <- merged$cpi_index

  merged[, c(
    "person_id", "exposed", "diagnosis_group", "severity", "index_date", "index_year",
    "followup_year", "segment_start", "segment_end", "observed_days", "observed_person_years",
    "observed_fraction", "calendar_year", "component", "source_system", "source_era",
    "coverage_status", "service_year_cpi_index", "reference_price_year",
    "cpi_adjustment_factor", "allocation_overlap_days", "allocation_fraction",
    "nominal_cost_allocated", "cost_reference_dkk_allocated"
  ), drop = FALSE]
}

complete_followup_component_grid <- function(segment_rows, allocated_cost_rows) {
  base_components <- c("lmdb", "hospital_drugs", "lpr_sghforlob", "lpr_kontakt", "primary_sector")
  if (!nrow(segment_rows)) {
    return(data.frame())
  }

  segment_grid <- merge(
    segment_rows,
    data.frame(component = base_components, stringsAsFactors = FALSE),
    by = NULL
  )

  if (!nrow(allocated_cost_rows)) {
    segment_grid$nominal_cost_allocated         <- 0
    segment_grid$cost_reference_dkk_allocated   <- 0
    segment_grid$allocation_fraction_sum        <- 0
    segment_grid$source_system                  <- segment_grid$component
    segment_grid$source_era                     <- segment_grid$component
    segment_grid$coverage_status                <- "missing"
    return(segment_grid)
  }

  aggregated_allocations <- allocated_cost_rows |>
    group_by(
      person_id, exposed, diagnosis_group, severity, index_date, index_year, followup_year,
      segment_start, segment_end, observed_days, observed_person_years, observed_fraction, component
    ) |>
    summarise(
      nominal_cost_allocated        = sum(nominal_cost_allocated, na.rm = TRUE),
      cost_reference_dkk_allocated  = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      allocation_fraction_sum       = sum(allocation_fraction, na.rm = TRUE),
      source_system = paste(sort(unique(source_system)), collapse = ";"),
      source_era    = paste(sort(unique(source_era)),    collapse = ";"),
      coverage_status = case_when(
        any(coverage_status == "full")          ~ "full",
        any(coverage_status == "partial")       ~ "partial",
        any(coverage_status == "supplementary") ~ "supplementary",
        any(coverage_status == "restricted")    ~ "restricted",
        TRUE                                    ~ "missing"
      ),
      .groups = "drop"
    )

  merged <- segment_grid |>
    left_join(
      aggregated_allocations,
      by = c(
        "person_id", "exposed", "diagnosis_group", "severity", "index_date", "index_year",
        "followup_year", "segment_start", "segment_end", "observed_days", "observed_person_years",
        "observed_fraction", "component"
      )
    ) |>
    mutate(
      nominal_cost_allocated       = dplyr::coalesce(nominal_cost_allocated, 0),
      cost_reference_dkk_allocated = dplyr::coalesce(cost_reference_dkk_allocated, 0),
      allocation_fraction_sum      = dplyr::coalesce(allocation_fraction_sum, 0),
      source_system    = dplyr::coalesce(source_system, component),
      source_era       = dplyr::coalesce(source_era,    component),
      coverage_status  = dplyr::coalesce(coverage_status, "missing")
    )

  # Compute totals from the already-aggregated component rows (cheaper than re-aggregating allocated_cost_rows)
  total_rows <- merged |>
    group_by(
      person_id, exposed, diagnosis_group, severity, index_date, index_year, followup_year,
      segment_start, segment_end, observed_days, observed_person_years, observed_fraction
    ) |>
    summarise(
      nominal_cost_allocated       = sum(nominal_cost_allocated, na.rm = TRUE),
      cost_reference_dkk_allocated = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      allocation_fraction_sum      = sum(allocation_fraction_sum, na.rm = TRUE),
      source_system   = "combined",
      source_era      = "combined",
      coverage_status = case_when(
        any(coverage_status == "full")          ~ "full",
        any(coverage_status == "partial")       ~ "partial",
        any(coverage_status == "supplementary") ~ "supplementary",
        any(coverage_status == "restricted")    ~ "restricted",
        TRUE                                    ~ "missing"
      ),
      component = "total",
      .groups = "drop"
    )

  bind_rows(merged, total_rows) |>
    arrange(person_id, followup_year, component) |>
    as.data.frame(stringsAsFactors = FALSE)
}

apply_discount_scenarios <- function(followup_cost_panel_df, discount_rates = default_discount_rates()) {
  if (!nrow(followup_cost_panel_df)) {
    return(data.frame())
  }

  # Precompute vectors shared across all rates
  svc_year   <- followup_cost_panel_df$index_year + followup_cost_panel_df$followup_year - 1L
  idx_year   <- followup_cost_panel_df$index_year
  base_costs <- followup_cost_panel_df$cost_reference_dkk_allocated

  bind_rows(lapply(discount_rates, function(discount_rate) {
    followup_cost_panel_df$discount_rate                  <- discount_rate
    followup_cost_panel_df$discounted_cost_reference_dkk  <- discount_cost_reference_dkk(
      base_costs, service_year = svc_year, index_year = idx_year, discount_rate = discount_rate
    )
    followup_cost_panel_df
  })) |>
    as.data.frame(stringsAsFactors = FALSE)
}

# Core allocation + grid logic, accepting pre-built segments.
# Used by build_followup_cost_panel and by the runner when reusing segments.
build_followup_cost_panel_from_segments <- function(
  segment_rows, harmonized_cost_df,
  max_followup_years = 10L, exclude_first_n_days = 0L
) {
  if (!nrow(segment_rows)) {
    return(list(
      followup_cost_panel = data.frame(),
      discounted_followup_cost_panel = data.frame()
    ))
  }

  # Narrow harmonized_cost_df to the calendar years the segments actually span
  if (nrow(harmonized_cost_df)) {
    min_year <- min(as.integer(format(segment_rows$segment_start, "%Y")))
    max_year <- max(as.integer(format(segment_rows$segment_end,   "%Y")))
    harmonized_cost_df <- harmonized_cost_df[
      harmonized_cost_df$year >= min_year & harmonized_cost_df$year <= max_year,
      , drop = FALSE
    ]
  }

  allocated_cost_rows <- allocate_person_year_cost_to_followup(
    segment_df = segment_rows,
    cost_df    = harmonized_cost_df,
    max_followup_years     = max_followup_years,
    exclude_first_n_days   = exclude_first_n_days
  )

  followup_cost_panel <- complete_followup_component_grid(segment_rows, allocated_cost_rows) |>
    mutate(
      annual_cost_ppy_nominal          = ifelse(observed_person_years > 0, nominal_cost_allocated / observed_person_years, NA_real_),
      annual_cost_ppy_reference_dkk    = ifelse(observed_person_years > 0, cost_reference_dkk_allocated / observed_person_years, NA_real_)
    ) |>
    as.data.frame(stringsAsFactors = FALSE)

  discounted_followup_cost_panel <- apply_discount_scenarios(followup_cost_panel)

  list(
    followup_cost_panel            = followup_cost_panel,
    discounted_followup_cost_panel = discounted_followup_cost_panel
  )
}

build_followup_cost_panel <- function(matched_df, harmonized_cost_df, max_followup_years = 10L, exclude_first_n_days = 0L) {
  segment_rows <- build_followup_segments_vectorized(matched_df, max_followup_years)
  build_followup_cost_panel_from_segments(
    segment_rows, harmonized_cost_df,
    max_followup_years   = max_followup_years,
    exclude_first_n_days = exclude_first_n_days
  )
}

build_followup_annual_summary <- function(followup_cost_panel_df) {
  if (!nrow(followup_cost_panel_df)) {
    return(data.frame())
  }

  followup_cost_panel_df |>
    group_by(component, followup_year, exposed) |>
    summarise(
      rows                             = n(),
      people                           = n_distinct(person_id),
      observed_person_years_sum        = sum(observed_person_years, na.rm = TRUE),
      nominal_cost_sum                 = sum(nominal_cost_allocated, na.rm = TRUE),
      cost_reference_dkk_sum           = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      annual_cost_ppy_reference_dkk    = ifelse(
        observed_person_years_sum > 0,
        cost_reference_dkk_sum / observed_person_years_sum,
        NA_real_
      ),
      .groups = "drop"
    ) |>
    arrange(component, followup_year, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_followup_cumulative_summary <- function(followup_cost_panel_df, max_followup_years = 10L) {
  if (!nrow(followup_cost_panel_df)) {
    return(data.frame())
  }

  followup_cost_panel_df |>
    filter(followup_year <= max_followup_years) |>
    group_by(component, exposed, person_id) |>
    summarise(
      cumulative_nominal_cost          = sum(nominal_cost_allocated, na.rm = TRUE),
      cumulative_cost_reference_dkk    = sum(cost_reference_dkk_allocated, na.rm = TRUE),
      .groups = "drop"
    ) |>
    group_by(component, exposed) |>
    summarise(
      people                                = n(),
      mean_cumulative_nominal_cost          = mean(cumulative_nominal_cost, na.rm = TRUE),
      mean_cumulative_cost_reference_dkk    = mean(cumulative_cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(component, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

build_followup_discounted_cumulative_summary <- function(discounted_followup_cost_panel_df, max_followup_years = 10L) {
  if (!nrow(discounted_followup_cost_panel_df)) {
    return(data.frame())
  }

  discounted_followup_cost_panel_df |>
    filter(followup_year <= max_followup_years) |>
    group_by(component, discount_rate, exposed, person_id) |>
    summarise(
      cumulative_discounted_cost_reference_dkk = sum(discounted_cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    group_by(component, discount_rate, exposed) |>
    summarise(
      people                                        = n(),
      mean_cumulative_discounted_cost_reference_dkk = mean(cumulative_discounted_cost_reference_dkk, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(component, discount_rate, exposed) |>
    as.data.frame(stringsAsFactors = FALSE)
}

filter_survivor_only_panel <- function(panel_df, matched_df, baseline_df = NULL) {
  if (!nrow(panel_df)) return(panel_df)

  if ("censor_reason" %in% names(matched_df)) {
    censor_lookup <- unique(matched_df[, c("person_id", "censor_reason"), drop = FALSE])
  } else if (!is.null(baseline_df) && "censor_reason" %in% names(baseline_df)) {
    censor_lookup <- unique(baseline_df[, c("person_id", "censor_reason"), drop = FALSE])
    message("Note: censor_reason joined from baseline_df (not present in matched_df).")
  } else {
    message("Warning: censor_reason unavailable — survivor-only filter not applied.")
    return(panel_df)
  }

  censor_lookup <- censor_lookup[!duplicated(censor_lookup$person_id), , drop = FALSE]
  panel_aug     <- merge(panel_df, censor_lookup, by = "person_id", all.x = TRUE)

  is_death_censored <- !is.na(panel_aug$censor_reason) &
    panel_aug$censor_reason == "death" &
    panel_aug$observed_fraction < 1.0

  panel_aug[!is_death_censored, , drop = FALSE]
}

build_followup_difference_summary <- function(summary_df, value_column, group_columns) {
  if (!nrow(summary_df)) {
    return(data.frame())
  }

  assert_required_columns(summary_df, c(group_columns, value_column, "exposed"),
    "summary_df for difference computation")

  exposed_rows   <- summary_df[summary_df$exposed, , drop = FALSE]
  unexposed_rows <- summary_df[!summary_df$exposed, , drop = FALSE]

  if (!nrow(exposed_rows) || !nrow(unexposed_rows)) {
    return(data.frame())
  }

  merged <- dplyr::inner_join(
    exposed_rows, unexposed_rows,
    by = group_columns,
    suffix = c("_exposed", "_unexposed")
  )
  merged$difference_exposed_minus_unexposed <- merged[[paste0(value_column, "_exposed")]] -
    merged[[paste0(value_column, "_unexposed")]]
  merged
}

write_followup_cost_outputs <- function(
  followup_cost_panel_df,
  discounted_followup_cost_panel_df,
  annual_summary_df,
  cumulative_summary_df,
  discounted_cumulative_summary_df,
  annual_difference_df,
  cumulative_difference_df,
  discounted_cumulative_difference_df,
  config
) {
  ensure_output_dir(config)

  paths <- list(
    followup_cost_panel_path                 = file.path(config$output_dir, "followup_cost_panel.parquet"),
    discounted_followup_cost_panel_path      = file.path(config$output_dir, "followup_cost_panel_discounted.parquet"),
    annual_summary_path                      = file.path(config$output_dir, "followup_annual_cost_summary.csv"),
    cumulative_summary_path                  = file.path(config$output_dir, "followup_cumulative_cost_summary.csv"),
    discounted_cumulative_summary_path       = file.path(config$output_dir, "followup_discounted_cumulative_cost_summary.csv"),
    annual_difference_path                   = file.path(config$output_dir, "followup_annual_cost_difference_summary.csv"),
    cumulative_difference_path               = file.path(config$output_dir, "followup_cumulative_cost_difference_summary.csv"),
    discounted_cumulative_difference_path    = file.path(config$output_dir, "followup_discounted_cumulative_cost_difference_summary.csv")
  )

  arrow::write_parquet(followup_cost_panel_df,           paths$followup_cost_panel_path)
  arrow::write_parquet(discounted_followup_cost_panel_df, paths$discounted_followup_cost_panel_path)
  utils::write.csv(annual_summary_df,                  paths$annual_summary_path,                   row.names = FALSE)
  utils::write.csv(cumulative_summary_df,              paths$cumulative_summary_path,                row.names = FALSE)
  utils::write.csv(discounted_cumulative_summary_df,   paths$discounted_cumulative_summary_path,     row.names = FALSE)
  utils::write.csv(annual_difference_df,               paths$annual_difference_path,                 row.names = FALSE)
  utils::write.csv(cumulative_difference_df,           paths$cumulative_difference_path,             row.names = FALSE)
  utils::write.csv(discounted_cumulative_difference_df, paths$discounted_cumulative_difference_path, row.names = FALSE)

  paths
}
