detect_project_root <- function() {
  if (!interactive()) {
    f <- grep("^--file=", commandArgs(FALSE), value = TRUE)[1]
    return(dirname(dirname(normalizePath(sub("^--file=", "", f), winslash = "/", mustWork = TRUE))))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE) &&
      rstudioapi::isAvailable() &&
      nzchar(rstudioapi::getActiveDocumentContext()$path)) {
    return(dirname(dirname(normalizePath(rstudioapi::getActiveDocumentContext()$path, winslash = "/"))))
  }
  normalizePath(getwd(), winslash = "/")
}

detect_repo_root <- function(project_root, explicit = NULL) {
  if (!is.null(explicit) && length(explicit) == 1L && !is.na(explicit) && nzchar(explicit)) {
    return(normalizePath(explicit, winslash = "/", mustWork = FALSE))
  }

  current <- normalizePath(project_root, winslash = "/", mustWork = FALSE)
  visited <- character(0)

  repeat {
    if (current %in% visited) {
      break
    }
    visited <- c(visited, current)

    has_repo_markers <- dir.exists(file.path(current, "crates")) &&
      (dir.exists(file.path(current, "tmp", "test_out")) || dir.exists(file.path(current, "tmp", "test_data")))
    if (has_repo_markers) {
      return(current)
    }

    parent <- dirname(current)
    if (identical(parent, current)) {
      break
    }
    current <- parent
  }

  dirname(normalizePath(project_root, winslash = "/", mustWork = FALSE))
}

get_script_path <- function() {
  file_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  if (!length(file_arg)) {
    stop("This script must be run with Rscript.")
  }

  normalizePath(sub("^--file=", "", file_arg[[1]]), winslash = "/", mustWork = TRUE)
}

parse_cli_args <- function(args = commandArgs(trailingOnly = TRUE)) {
  parsed <- list()

  for (arg in args) {
    if (!startsWith(arg, "--")) {
      next
    }

    parts <- strsplit(sub("^--", "", arg), "=", fixed = TRUE)[[1]]
    key <- gsub("-", "_", parts[[1]], fixed = TRUE)
    value <- if (length(parts) > 1L) {
      paste(parts[-1L], collapse = "=")
    } else {
      TRUE
    }
    parsed[[key]] <- value
  }

  parsed
}

parse_bool_flag <- function(value, default = FALSE) {
  if (is.null(value) || is.na(value) || identical(value, "")) {
    return(default)
  }
  if (is.logical(value)) {
    return(isTRUE(value))
  }

  normalized <- tolower(as.character(value))
  normalized %in% c("1", "true", "t", "yes", "y", "on")
}

`%||%` <- function(lhs, rhs) {
  if (is.null(lhs) || (length(lhs) == 1L && (is.na(lhs) || identical(lhs, "")))) {
    rhs
  } else {
    lhs
  }
}

default_project_config <- function(project_root = getwd(), args = parse_cli_args()) {
  project_root <- normalizePath(project_root, winslash = "/", mustWork = FALSE)
  repo_root <- detect_repo_root(
    project_root,
    args$repo_root %||% Sys.getenv("SOCIETAL_COSTS_REPO_ROOT", unset = "")
  )
  test_out_root <- normalizePath(
    args$test_out_root %||% file.path(repo_root, "tmp", "test_out"),
    winslash = "/",
    mustWork = FALSE
  )
  raw_data_dir <- normalizePath(
    args$raw_data_dir %||% file.path(repo_root, "tmp", "test_data"),
    winslash = "/",
    mustWork = FALSE
  )

  list(
    project_root = project_root,
    repo_root = repo_root,
    cohort_dir = normalizePath(
      args$cohort_dir %||% file.path(test_out_root, "cohort"),
      winslash = "/",
      mustWork = FALSE
    ),
    core_dir = normalizePath(
      args$core_dir %||% file.path(test_out_root, "core"),
      winslash = "/",
      mustWork = FALSE
    ),
    registers_dir = normalizePath(
      args$registers_dir %||% file.path(test_out_root, "registers"),
      winslash = "/",
      mustWork = FALSE
    ),
    raw_data_dir = raw_data_dir,
    raw_popc_dir = normalizePath(
      args$raw_popc_dir %||% file.path(raw_data_dir, "popc"),
      winslash = "/",
      mustWork = FALSE
    ),
    raw_lmdb_dir = normalizePath(
      args$raw_lmdb_dir %||% file.path(raw_data_dir, "lmdb"),
      winslash = "/",
      mustWork = FALSE
    ),
    raw_primary_dir = normalizePath(
      args$raw_primary_dir %||% file.path(raw_data_dir, "primary_sector"),
      winslash = "/",
      mustWork = FALSE
    ),
    raw_drg_dir = normalizePath(
      args$raw_drg_dir %||% file.path(raw_data_dir, "drg"),
      winslash = "/",
      mustWork = FALSE
    ),
    raw_indberetningmedpris_path = normalizePath(
      args$raw_indberetningmedpris_path %||%
        file.path(raw_data_dir, "hospital_drugs", "indberetningmedpris.parquet"),
      winslash = "/",
      mustWork = FALSE
    ),
    output_dir = normalizePath(
      args$output_dir %||% file.path(project_root, "output"),
      winslash = "/",
      mustWork = FALSE
    ),
    baseline_years_target = 5L,
    preindex_lag_days = 91L,
    reference_price_year = as.integer(args$reference_price_year %||% 2023L),
    use_hospital_drugs = parse_bool_flag(args$use_hospital_drugs, default = FALSE),
    hospital_drugs_usage_path = args$hospital_drugs_usage_path %||%
      file.path(test_out_root, "registers", "hospital_drugs", "hospital_drugs_usage.parquet"),
    education_asset_path = normalizePath(
      file.path(
        repo_root,
        "crates",
        "pipeline",
        "cohort_builder_domain",
        "assets",
        "DISCED",
        "AUDD2026_HOVED_L1L5_KT.sas.txt"
      ),
      winslash = "/",
      mustWork = FALSE
    ),
    hfaudd_json_path = normalizePath(
      file.path(project_root, "HFAUDD.json"),
      winslash = "/",
      mustWork = FALSE
    )
  )
}
