# societal_costs_r

This is a minimal bundled copy of the `societal_costs_r` project.

## Included Files

- `R/`
- `scripts/`
- `HFAUDD.json`

## Expected Usage

1. Unpack the project with:

   ```bash
   unpack /target/path
   ```

2. Set the working directory to the unpacked project.
3. Configure input and output paths in `scripts/99_run_all_interactive.R` or run the stage scripts individually.
