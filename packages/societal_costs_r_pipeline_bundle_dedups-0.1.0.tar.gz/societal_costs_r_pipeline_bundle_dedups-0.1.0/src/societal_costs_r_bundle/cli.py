import argparse
import shutil
from importlib.resources import as_file, files
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="unpack",
        description="Copy the bundled societal_costs_r project into the target path.",
    )
    parser.add_argument("target", help="Exact destination path for the unpacked project")
    return parser.parse_args()


def copy_bundle(target: Path) -> Path:
    source = files("societal_costs_r_bundle").joinpath("r_project")
    resolved_target = target.expanduser().resolve()

    if resolved_target.exists():
        raise SystemExit(f"Target already exists: {resolved_target}")

    resolved_target.parent.mkdir(parents=True, exist_ok=True)
    with as_file(source) as source_path:
        shutil.copytree(source_path, resolved_target)
    return resolved_target


def main() -> None:
    args = parse_args()
    target = copy_bundle(Path(args.target))
    print(f"Copied bundled project to {target}")


if __name__ == "__main__":
    main()
