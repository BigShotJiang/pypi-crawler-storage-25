# Societal Costs R Bundle

This package bundles a minimal copy of the `societal_costs_r` project and exposes an `unpack` command.

## Included Files

- `R/`
- `scripts/`
- `HFAUDD.json`
- `README.md`

## Usage

```bash
unpack /target/path
```

The command copies the bundled project files into the exact path you provide and fails if that path already exists.
