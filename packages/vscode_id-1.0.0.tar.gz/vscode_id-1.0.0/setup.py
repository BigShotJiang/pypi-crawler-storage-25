from setuptools import setup, find_packages
setup(name='vscode-id', version='1.0.0', packages=find_packages(), package_data={'vscode_id': ['*.so']}, include_package_data=True)
