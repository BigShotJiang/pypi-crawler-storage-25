import ctypes
import os
_lib = ctypes.CDLL(os.path.join(os.path.dirname(__file__), 'vscode-id.so'))
_lib.get.argtypes = []
_lib.get.restype = ctypes.c_char_p
def id():
    return _lib.get().decode()
__all__ = ['id']
