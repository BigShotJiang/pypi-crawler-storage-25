"""
qlens-pytest-reporter — posts pytest run summaries to QualityPilot CI ingest.

Install:
    pip install qlens-pytest-reporter

Configure via env (CI-friendly, no config file needed):
    QLENS_API_KEY            required; qlens_* key from /dashboard/keys
    QLENS_REPO               owner/name, defaults to GITHUB_REPOSITORY
    QLENS_ENDPOINT           default: https://www.qlens.dev/api/v1/test-runs
    QLENS_SEND_CASES         "1" to include per-case data (default: off)
    QLENS_MAX_CASES          default: 5000

Auto-detected:
    GITHUB_REPOSITORY / GITHUB_SHA / GITHUB_REF_NAME
    GITLAB_CI, CIRCLECI, JENKINS_URL, CI

On any error, the plugin logs and continues — it never fails the test run.
"""

from __future__ import annotations

import json
import os
import time
from typing import Any
from urllib import error, request

from . import __version__

_DEFAULT_ENDPOINT = "https://www.qlens.dev/api/v1/test-runs"


def _detect_ci_provider() -> str | None:
    if os.environ.get("GITHUB_ACTIONS"):
        return "github_actions"
    if os.environ.get("GITLAB_CI"):
        return "gitlab_ci"
    if os.environ.get("CIRCLECI"):
        return "circle"
    if os.environ.get("JENKINS_URL"):
        return "jenkins"
    if os.environ.get("CI"):
        return "other"
    return None


def _detect_commit() -> str | None:
    return (
        os.environ.get("GITHUB_SHA")
        or os.environ.get("CI_COMMIT_SHA")
        or os.environ.get("CIRCLE_SHA1")
        or None
    )


def _detect_branch() -> str | None:
    return (
        os.environ.get("GITHUB_REF_NAME")
        or os.environ.get("CI_COMMIT_REF_NAME")
        or os.environ.get("CIRCLE_BRANCH")
        or None
    )


def _bool_env(name: str) -> bool:
    value = os.environ.get(name, "").strip().lower()
    return value in ("1", "true", "yes", "on")


def _int_env(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _log(msg: str) -> None:
    # pytest reporters often write to stdout; use plain print so it shows in CI logs.
    print(f"[qlens] {msg}")


class QlensReporter:
    """pytest plugin — collects per-test outcomes and posts once at session end."""

    def __init__(self) -> None:
        self._start = time.monotonic()
        self._passed = 0
        self._failed = 0
        self._skipped = 0
        self._flaky = 0
        self._cases: list[dict[str, Any]] = []
        self._max_cases = _int_env("QLENS_MAX_CASES", 5000)
        self._send_cases = _bool_env("QLENS_SEND_CASES")

    def pytest_runtest_logreport(self, report: Any) -> None:
        # We only care about the "call" phase for pass/fail counting. setup/teardown
        # errors are treated as failures to match what users expect from CI dashboards.
        if report.when not in ("call", "setup"):
            return

        status: str
        if report.when == "setup" and report.outcome == "failed":
            status = "failed"
        elif report.when != "call":
            return
        elif report.outcome == "passed":
            status = "passed"
        elif report.outcome == "failed":
            status = "failed"
        elif report.outcome == "skipped":
            status = "skipped"
        else:
            status = "skipped"

        # Flakiness: pytest-rerunfailures adds `report.rerun` (int) when a rerun
        # occurred. If final status is "passed" with rerun > 0 → flaky.
        rerun_attempts = getattr(report, "rerun", 0) or 0
        attempts = 1 + rerun_attempts
        if status == "passed" and attempts > 1:
            self._flaky += 1
        elif status == "passed":
            self._passed += 1
        elif status == "failed":
            self._failed += 1
        else:
            self._skipped += 1

        if self._send_cases and len(self._cases) < self._max_cases:
            nodeid = getattr(report, "nodeid", "")
            suite, _, name = nodeid.rpartition("::")
            # nodeid example: "tests/test_auth.py::TestLogin::test_rejects_invalid"
            longrepr = getattr(report, "longreprtext", "") or str(
                getattr(report, "longrepr", "") or ""
            )
            mapped = (
                "flaky" if status == "passed" and attempts > 1 else status
            )
            self._cases.append(
                {
                    "suite": suite or "",
                    "name": name or nodeid,
                    "status": mapped,
                    "durationMs": int((getattr(report, "duration", 0.0) or 0.0) * 1000),
                    "errorMessage": longrepr[:2000] if longrepr else None,
                    "attempts": attempts,
                }
            )

    def pytest_sessionfinish(self, session: Any, exitstatus: int) -> None:  # noqa: ARG002
        api_key = os.environ.get("QLENS_API_KEY")
        if not api_key:
            _log("QLENS_API_KEY not set — skipping upload")
            return
        repo = os.environ.get("QLENS_REPO") or os.environ.get("GITHUB_REPOSITORY")
        if not repo:
            _log("no repo detected (set QLENS_REPO or GITHUB_REPOSITORY)")
            return

        endpoint = os.environ.get("QLENS_ENDPOINT") or _DEFAULT_ENDPOINT
        total = self._passed + self._failed + self._skipped + self._flaky
        duration_ms = int((time.monotonic() - self._start) * 1000)

        payload: dict[str, Any] = {
            "repo": repo,
            "commit": _detect_commit(),
            "branch": _detect_branch(),
            "framework": "pytest",
            "ciProvider": _detect_ci_provider(),
            "summary": {
                "total": total,
                "passed": self._passed,
                "failed": self._failed,
                "skipped": self._skipped,
                "flaky": self._flaky,
                "durationMs": duration_ms,
            },
        }
        if self._send_cases:
            payload["cases"] = self._cases

        body = json.dumps(payload).encode("utf-8")
        req = request.Request(
            endpoint,
            data=body,
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_key,
                "User-Agent": f"qlens-pytest-reporter/{__version__}",
            },
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=10) as resp:
                if resp.status >= 300:
                    _log(f"ingest responded {resp.status}")
                    return
        except error.HTTPError as err:  # 4xx/5xx
            _log(f"ingest responded {err.code}")
            return
        except error.URLError as err:
            _log(f"upload failed: {err.reason}")
            return
        except Exception as err:  # any other network/runtime error
            _log(f"upload failed: {err}")
            return

        _log(
            f"uploaded {total} tests ({self._passed} passed / {self._failed} failed / {self._flaky} flaky) to {endpoint}"
        )


def pytest_configure(config: Any) -> None:
    """Register the reporter plugin if an API key is set (or always, in CI)."""
    # Register regardless — individual hooks are cheap, and we want visibility
    # into the "QLENS_API_KEY not set" log line.
    config.pluginmanager.register(QlensReporter(), "qlens-reporter")
