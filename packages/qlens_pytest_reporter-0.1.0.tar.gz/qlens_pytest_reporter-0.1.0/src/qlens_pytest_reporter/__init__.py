"""QualityPilot pytest reporter. See plugin.py for the pytest hook entry points."""

__version__ = "0.1.0"
