# qlens-pytest-reporter

pytest plugin that posts run summaries to [QualityPilot](https://qlens.dev) CI ingest.

## Install

```bash
pip install qlens-pytest-reporter
```

The plugin auto-registers via the `pytest11` entry point — no `conftest.py` changes.

## Configure (env-only, CI-friendly)

Create an API key at [qlens.dev/dashboard/keys](https://qlens.dev/dashboard/keys), then set:

```bash
export QLENS_API_KEY=qlens_...
export GITHUB_REPOSITORY=owner/name   # auto-set in GitHub Actions
# optional
export QLENS_SEND_CASES=1             # include per-case data
export QLENS_MAX_CASES=5000
export QLENS_REPO=owner/name          # override if not on GitHub Actions
export QLENS_ENDPOINT=https://www.qlens.dev/api/v1/test-runs
```

Run pytest as usual — the plugin posts once at session end.

## Flakiness

Tests that pass after reruns (via [`pytest-rerunfailures`](https://github.com/pytest-dev/pytest-rerunfailures)) are counted as **flaky**, not passed. The `attempts` field on each case captures the retry count.

## Fail-safe

Never fails the test run. Missing API key, network errors, 4xx/5xx from the ingest — all logged (`[qlens]`) and ignored. Your CI green stays green.

## Docs

Full API schema: [qlens.dev/docs/ci-ingest](https://qlens.dev/docs/ci-ingest).

## License

MIT — built by [IK Lab](https://iklab.dev).
