"""
Integration tests for ORCA orchestrator.

These tests perform live execution with real model configurations
and scenario operations. They test the complete workflow end-to-end
without mocking.
"""

import unittest
import tempfile
import shutil
import os
import json
import yaml
import sys
import time
from pathlib import Path

# Import from the new namespace structure
from tlpytools.orca.orchestrator import OrcaOrchestrator, check_scenario_exists


class TestOrcaIntegration(unittest.TestCase):
    """Integration tests for complete ORCA workflows."""

    @classmethod
    def setUpClass(cls):
        """Set up class-level test fixtures."""
        cls.test_dir = tempfile.mkdtemp(prefix="orca_integration_test_")
        cls.original_cwd = os.getcwd()

        # Create a simplified test config based on default but with minimal steps
        cls.test_config = {
            "model_steps": ["b1_activitysim"],
            "iterations": {
                "total": 1,
                "start_at": 1,
            },
            "input_data": {
                "test_data": [
                    {"source": "test/input/data1.txt"},
                    {"source": "test/input/data2.txt"},
                ]
            },
            "sub_components": {
                "b1_activitysim": {
                    "iterations": "all",  # Sub-component level
                    "environment": {
                        "env_var": "ORCA_ACTIVITYSIM_ENV",
                        "default": "python",
                    },
                    "commands": [
                        {
                            "command": "python -c \"print('ActivitySim simulation complete'); import os; os.makedirs('output', exist_ok=True); open('output/test_result.txt', 'w').write('test output')\"",
                            "description": "Simulate ActivitySim model run",
                        }
                    ],
                    "source_template": [],
                    "cleanup_patterns": ["*.tmp"],
                    "output_archives": [
                        {"archive_name": "main", "patterns": ["output/**"]}
                    ],
                }
            },
            "operational_mode": {
                "type": "local_testing",
                "cloud": {
                    "adls_url": f"https://{os.getenv('ORCA_ADLS_URL', 'yourstorageaccount.dfs.core.windows.net')}",
                    "adls_container": "raw",
                    "adls_folder": "orca_cloud_scenarios",
                },
            },
        }

        print(f"\nIntegration test directory: {cls.test_dir}")

    @classmethod
    def tearDownClass(cls):
        """Clean up class-level test fixtures."""
        os.chdir(cls.original_cwd)
        # Keep test directory for inspection - comment out the next line to preserve
        shutil.rmtree(cls.test_dir, ignore_errors=True)

    def setUp(self):
        """Set up test fixtures for each test."""
        # Change to test directory
        os.chdir(self.test_dir)

    def tearDown(self):
        """Clean up after each test."""
        os.chdir(self.original_cwd)

    def _create_test_config_file(self, scenario_path, config_data):
        """Helper to create test config file."""
        os.makedirs(scenario_path, exist_ok=True)
        config_file = os.path.join(scenario_path, "orca_model_config.yaml")
        with open(config_file, "w") as f:
            yaml.dump(config_data, f, default_flow_style=False)
        return config_file

    def test_01_local_testing_full_run(self):
        """
        Test 1: Local testing mode - initialize and run model from start to finish.

        This test simulates:
        python -m tlpytools.orca --action run_model --scenario db_test_local
        """
        print("\n=== Test 1: Local Testing Full Run ===")

        scenario_name = "db_test_local"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Ensure clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create test config
        self._create_test_config_file(scenario_path, self.test_config)

        print(f"Creating orchestrator for scenario: {scenario_name}")
        print(f"Scenario path: {scenario_path}")

        # Initialize and run orchestrator
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )

        # Verify initial state
        self.assertEqual(orchestrator.state.get("status"), "initialized")
        self.assertEqual(orchestrator.state.get("steps"), ["b1_activitysim"])
        self.assertEqual(orchestrator.state.get("total_iterations"), 1)

        print("Starting model run...")
        start_time = time.time()

        # Run the model
        success = orchestrator.run_local_testing()

        end_time = time.time()
        duration = end_time - start_time

        print(f"Model run completed in {duration:.2f} seconds")
        print(f"Run success: {success}")

        # Verify success
        self.assertTrue(success, "Model run should complete successfully")

        # Verify final state
        final_state = orchestrator.state.get("status")
        print(f"Final state: {final_state}")
        self.assertEqual(final_state, "completed")

        # Verify all iterations completed
        self.assertTrue(orchestrator.state.is_all_iterations_complete())

        # Verify output files were created
        output_dir = os.path.join(scenario_path, "outputs")
        self.assertTrue(os.path.exists(output_dir), "Outputs directory should exist")

        # Check for archived outputs
        archive_files = [f for f in os.listdir(output_dir) if f.endswith(".zip")]
        print(f"Archive files created: {archive_files}")
        self.assertGreater(
            len(archive_files), 0, "At least one archive file should be created"
        )

        # Verify new naming convention: {step_name}_{archive_name}_iter{iteration}.zip
        expected_archive = "b1_activitysim_main_iter1.zip"
        self.assertIn(
            expected_archive,
            archive_files,
            f"Expected archive {expected_archive} not found",
        )

        # Verify state file exists and contains expected data
        state_file = os.path.join(scenario_path, "orca_model_state.json")
        self.assertTrue(os.path.exists(state_file), "State file should exist")

        with open(state_file, "r") as f:
            state_data = json.load(f)

        self.assertEqual(state_data["status"], "completed")
        self.assertEqual(state_data["total_steps_completed"], 1)

        print("[OK] Local testing full run completed successfully")

    def test_02_cloud_initialization_only(self):
        """
        Test 2: Cloud production mode - initialize scenario and upload to ADLS.

        This test simulates:
        python -m tlpytools.orca --action init_model --scenario db_test_integration_init --mode cloud_production
        """
        print("\n=== Test 2: Cloud Production Initialization ===")

        scenario_name = "db_test_integration_init"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Ensure clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create test config with cloud mode
        cloud_config = self.test_config.copy()
        cloud_config["operational_mode"]["type"] = "cloud_production"

        self._create_test_config_file(scenario_path, cloud_config)

        print(f"Creating orchestrator for cloud scenario: {scenario_name}")
        print(f"Scenario path: {scenario_path}")

        # Initialize orchestrator in cloud mode
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="cloud_production"
        )

        # Verify initialization
        self.assertEqual(orchestrator.mode, "cloud_production")
        self.assertEqual(orchestrator.state.get("status"), "initialized")

        print("Initializing scenario...")
        start_time = time.time()

        # Validate scenario (initialization happens in __init__)
        success = orchestrator.validate_scenario()

        end_time = time.time()
        duration = end_time - start_time

        print(f"Scenario initialization completed in {duration:.2f} seconds")
        print(f"Initialization success: {success}")

        # Verify success
        self.assertTrue(success, "Scenario initialization should succeed")

        # Verify scenario structure was created
        self.assertTrue(
            os.path.exists(scenario_path), "Scenario directory should exist"
        )
        self.assertTrue(
            os.path.exists(orchestrator.config_file), "Config file should exist"
        )
        self.assertTrue(
            os.path.exists(orchestrator.state_file), "State file should exist"
        )

        # Verify outputs directory was created
        outputs_dir = os.path.join(scenario_path, "outputs")
        self.assertTrue(os.path.exists(outputs_dir), "Outputs directory should exist")

        # Test cloud sync upload (Note: This will attempt real ADLS upload)
        print("Testing cloud upload...")
        try:
            upload_success = orchestrator._sync_with_cloud(direction="upload")
            print(f"Cloud upload success: {upload_success}")
            # Note: upload might fail due to authentication or network issues in test environment
            # This is expected and acceptable for integration testing
        except Exception as e:
            print(f"Cloud upload failed (expected in test environment): {e}")
            upload_success = False

        # The initialization itself should still be successful regardless of upload
        print("[OK] Cloud production initialization completed successfully")

    def test_03_cloud_download_and_run(self):
        """
        Test 3: Cloud production mode - download existing scenario and complete run.

        This test simulates:
        python -m tlpytools.orca --action run_model --scenario db_test_integration_init --mode cloud_production

        Note: This test assumes a cloud scenario exists or creates a local one to simulate download.
        """
        print("\n=== Test 3: Cloud Production Download and Run ===")

        scenario_name = "db_test_integration_run"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Ensure clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create test config with cloud mode
        cloud_config = self.test_config.copy()
        cloud_config["operational_mode"]["type"] = "cloud_production"

        # First, simulate having an existing cloud scenario by creating local structure
        # (In real scenario, this would be downloaded from ADLS)
        print("Simulating existing cloud scenario...")
        os.makedirs(scenario_path, exist_ok=True)

        # Create config file
        config_file = self._create_test_config_file(scenario_path, cloud_config)

        # Create a state file to simulate partial progress
        state_file = os.path.join(scenario_path, "orca_model_state.json")
        initial_state = {
            "start_at": 1,
            "total_iterations": 1,
            "current_iteration": 1,
            "steps": ["b1_activitysim"],
            "completed_steps": [],
            "total_steps_completed": 0,
            "current_step_index": 0,
            "status": "initialized",
            "start_time": None,
            "last_updated": time.strftime("%Y-%m-%d %H:%M:%S"),
            "error": None,
        }
        with open(state_file, "w") as f:
            json.dump(initial_state, f, indent=2)

        # Create sub-component directory structure
        component_dir = os.path.join(scenario_path, "b1_activitysim")
        os.makedirs(component_dir, exist_ok=True)

        print(f"Creating orchestrator for cloud scenario: {scenario_name}")
        print(f"Scenario path: {scenario_path}")

        # Initialize orchestrator - it should detect existing scenario
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="cloud_production"
        )

        # Verify it detected existing state
        self.assertEqual(orchestrator.state.get("status"), "initialized")
        self.assertEqual(orchestrator.state.get("steps"), ["b1_activitysim"])

        # Test cloud sync download (Note: This will attempt real ADLS download)
        print("Testing cloud download...")
        try:
            download_success = orchestrator._sync_with_cloud(direction="download")
            print(f"Cloud download success: {download_success}")
        except Exception as e:
            print(f"Cloud download failed (expected in test environment): {e}")
            download_success = False

        print("Starting cloud production run...")
        start_time = time.time()

        # Run the model in cloud production mode
        success = orchestrator.run_cloud_production()

        end_time = time.time()
        duration = end_time - start_time

        print(f"Cloud production run completed in {duration:.2f} seconds")
        print(f"Run success: {success}")

        # Verify success
        self.assertTrue(success, "Cloud production run should complete successfully")

        # Verify final state
        final_state = orchestrator.state.get("status")
        print(f"Final state: {final_state}")
        self.assertEqual(final_state, "completed")

        # Verify all iterations completed
        self.assertTrue(orchestrator.state.is_all_iterations_complete())

        # Verify output files were created
        output_dir = os.path.join(scenario_path, "outputs")
        self.assertTrue(os.path.exists(output_dir), "Outputs directory should exist")

        # Check for archived outputs
        archive_files = [f for f in os.listdir(output_dir) if f.endswith(".zip")]
        print(f"Archive files created: {archive_files}")
        self.assertGreater(
            len(archive_files), 0, "At least one archive file should be created"
        )

        # Verify new naming convention: {step_name}_{archive_name}_iter{iteration}.zip
        expected_archive = "b1_activitysim_main_iter1.zip"
        self.assertIn(
            expected_archive,
            archive_files,
            f"Expected archive {expected_archive} not found",
        )

        # Test final cloud sync upload
        print("Testing final cloud upload...")
        try:
            upload_success = orchestrator._sync_with_cloud(direction="upload")
            print(f"Final cloud upload success: {upload_success}")
        except Exception as e:
            print(f"Final cloud upload failed (expected in test environment): {e}")
            upload_success = False

        print("[OK] Cloud production download and run completed successfully")

    def test_04_scenario_detection(self):
        """Test scenario existence detection functionality."""
        print("\n=== Test 4: Scenario Detection ===")

        # Test non-existent scenario
        nonexistent_path = os.path.join(self.test_dir, "nonexistent")
        result = check_scenario_exists(nonexistent_path)
        self.assertFalse(result["exists"])

        # Test existing scenario
        existing_path = os.path.join(self.test_dir, "existing_scenario")
        os.makedirs(existing_path, exist_ok=True)

        # Create state file
        state_file = os.path.join(existing_path, "orca_model_state.json")
        with open(state_file, "w") as f:
            json.dump({"status": "initialized"}, f)

        result = check_scenario_exists(existing_path)
        self.assertTrue(result["exists"])
        self.assertIn("orca_model_state.json", result["files"])

        print("[OK] Scenario detection working correctly")

    def test_05_error_handling(self):
        """Test error handling in orchestrator."""
        print("\n=== Test 5: Error Handling ===")

        scenario_name = "db_test_error"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Create config with a command that will fail
        error_config = self.test_config.copy()
        error_config["sub_components"]["b1_activitysim"]["iterations"] = "all"
        error_config["sub_components"]["b1_activitysim"]["commands"] = [
            {
                "command": 'python -c "import sys; sys.exit(1)"',  # This will fail
                "description": "Failing command",
            }
        ]
        # Ensure output_archives is present even for failing commands
        error_config["sub_components"]["b1_activitysim"]["output_archives"] = [
            {"archive_name": "error", "patterns": ["*.log", "*.txt"]}
        ]

        self._create_test_config_file(scenario_path, error_config)

        print(f"Creating orchestrator with failing command...")

        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )

        # Run the model - it should handle the error gracefully
        success = orchestrator.run_local_testing()

        # Should return False due to command failure
        self.assertFalse(success, "Run should fail due to failing command")

        # State should reflect the error
        final_state = orchestrator.state.get("status")
        print(f"Final state after error: {final_state}")
        # The status might be "error" or still "running" depending on implementation

        print("[OK] Error handling test completed")


class TestRealConfigIntegration(unittest.TestCase):
    """Integration tests using the real default configuration."""

    @classmethod
    def setUpClass(cls):
        """Set up class-level test fixtures."""
        cls.test_dir = tempfile.mkdtemp(prefix="orca_real_config_test_")
        cls.original_cwd = os.getcwd()

        # Load the real default config
        default_config_path = os.path.join(
            Path(__file__).parent.parent,
            "src",
            "tlpytools",
            "orca",
            "orca_model_config_example.yaml",
        )
        with open(default_config_path, "r") as f:
            cls.real_config = yaml.safe_load(f)

        print(f"\nReal config integration test directory: {cls.test_dir}")

    @classmethod
    def tearDownClass(cls):
        """Clean up class-level test fixtures."""
        os.chdir(cls.original_cwd)
        # Keep test directory for inspection - comment out the next line to preserve
        shutil.rmtree(cls.test_dir, ignore_errors=True)

    def setUp(self):
        """Set up test fixtures for each test."""
        os.chdir(self.test_dir)

    def tearDown(self):
        """Clean up after each test."""
        os.chdir(self.original_cwd)

    def test_real_config_initialization(self):
        """Test initialization with real default config."""
        print("\n=== Real Config Initialization Test ===")

        scenario_name = "db_test_real_config"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Create config file with real config
        os.makedirs(scenario_path, exist_ok=True)
        config_file = os.path.join(scenario_path, "orca_model_config.yaml")
        with open(config_file, "w") as f:
            yaml.dump(self.real_config, f, default_flow_style=False)

        print(f"Creating orchestrator with real config...")
        print(f"Model steps: {self.real_config.get('model_steps', [])}")

        # Initialize orchestrator
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )

        # Verify initialization
        self.assertEqual(orchestrator.state.get("status"), "initialized")

        # Verify configuration was loaded correctly
        expected_steps = self.real_config.get("model_steps", [])
        actual_steps = orchestrator.state.get("steps", [])
        self.assertEqual(actual_steps, expected_steps)

        # Verify sub-components are properly configured
        config = orchestrator._load_configuration()
        sub_components = config.get("sub_components", {})

        for step_name in expected_steps:
            self.assertIn(
                step_name,
                sub_components,
                f"Step {step_name} should be in sub_components",
            )

            step_config = sub_components[step_name]
            self.assertIn(
                "environment",
                step_config,
                f"Step {step_name} should have environment config",
            )
            self.assertIn(
                "commands", step_config, f"Step {step_name} should have commands"
            )

        # Test input_data configuration if present
        if "input_data" in config:
            input_data = config["input_data"]
            self.assertIsInstance(input_data, dict, "input_data should be a dictionary")

            for category, sources in input_data.items():
                self.assertIsInstance(
                    sources, list, f"input_data.{category} should be a list"
                )
                for source in sources:
                    if isinstance(source, dict):
                        self.assertIn(
                            "source",
                            source,
                            f"input_data source should have 'source' key",
                        )
                    else:
                        self.assertIsInstance(
                            source, str, f"input_data source should be string or dict"
                        )

        # Test output_archives configuration
        for step_name in expected_steps:
            step_config = sub_components[step_name]
            if "output_archives" in step_config:
                archives = step_config["output_archives"]
                self.assertIsInstance(
                    archives, list, f"output_archives for {step_name} should be a list"
                )

                for archive in archives:
                    self.assertIsInstance(
                        archive, dict, f"Each output archive should be a dictionary"
                    )
                    self.assertIn(
                        "archive_name", archive, f"Archive should have archive_name"
                    )
                    self.assertIn("patterns", archive, f"Archive should have patterns")
                    self.assertIsInstance(
                        archive["patterns"], list, f"Archive patterns should be a list"
                    )

        print("[OK] Real config initialization successful")


class TestAdvancedExecution(unittest.TestCase):
    """Integration tests for advanced execution features."""

    @classmethod
    def setUpClass(cls):
        """Set up class-level test fixtures."""
        cls.test_dir = tempfile.mkdtemp(prefix="orca_advanced_test_")
        cls.original_cwd = os.getcwd()

        # Create a test config with multiple steps and iterations
        cls.test_config = {
            "model_steps": ["step1", "step2", "step3"],
            "iterations": {
                "total": 2,
                "start_at": 1,
            },
            "input_data": {},
            "sub_components": {
                "step1": {
                    "iterations": "all",  # Sub-component level
                    "environment": {
                        "env_var": "ORCA_TEST_ENV",
                        "default": "python",
                    },
                    "commands": [
                        {
                            "command": "python -c \"print('Step 1 complete'); import os; os.makedirs('output', exist_ok=True); open('output/step1.txt', 'w').write('step1 output')\"",
                            "description": "Execute step 1",
                        }
                    ],
                    "source_template": [],
                    "cleanup_patterns": [],
                    "output_archives": [
                        {"archive_name": "results", "patterns": ["output/**"]}
                    ],
                },
                "step2": {
                    "iterations": "all",  # Sub-component level
                    "environment": {
                        "env_var": "ORCA_TEST_ENV",
                        "default": "python",
                    },
                    "commands": [
                        {
                            "command": "python -c \"print('Step 2 complete'); import os; os.makedirs('output', exist_ok=True); open('output/step2.txt', 'w').write('step2 output')\"",
                            "description": "Execute step 2",
                        }
                    ],
                    "source_template": [],
                    "cleanup_patterns": [],
                    "output_archives": [
                        {"archive_name": "results", "patterns": ["output/**"]}
                    ],
                },
                "step3": {
                    "iterations": "all",  # Sub-component level
                    "environment": {
                        "env_var": "ORCA_TEST_ENV",
                        "default": "python",
                    },
                    "commands": [
                        {
                            "command": "python -c \"print('Step 3 complete'); import os; os.makedirs('output', exist_ok=True); open('output/step3.txt', 'w').write('step3 output')\"",
                            "description": "Execute step 3",
                        }
                    ],
                    "source_template": [],
                    "cleanup_patterns": [],
                    "output_archives": [
                        {"archive_name": "results", "patterns": ["output/**"]}
                    ],
                },
            },
            "operational_mode": {
                "type": "local_testing",
            },
        }

        print(f"\nAdvanced execution test directory: {cls.test_dir}")

    @classmethod
    def tearDownClass(cls):
        """Clean up class-level test fixtures."""
        os.chdir(cls.original_cwd)
        # Keep test directory for inspection
        shutil.rmtree(cls.test_dir, ignore_errors=True)

    def setUp(self):
        """Set up test fixtures for each test."""
        os.chdir(self.test_dir)

    def tearDown(self):
        """Clean up after each test."""
        os.chdir(self.original_cwd)

    def _create_test_config_file(self, scenario_path, config_data):
        """Helper to create test config file."""
        os.makedirs(scenario_path, exist_ok=True)
        config_file = os.path.join(scenario_path, "orca_model_config.yaml")
        with open(config_file, "w") as f:
            yaml.dump(config_data, f, default_flow_style=False)
        return config_file

    def test_06_run_one_step(self):
        """Test run_one_step - execute just one step at a time."""
        print("\n=== Test 6: Run One Step ===")

        scenario_name = "db_test_one_step"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create config
        self._create_test_config_file(scenario_path, self.test_config)

        # Initialize orchestrator
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )

        # Verify initial state
        self.assertEqual(orchestrator.state.get("current_iteration"), 1)
        self.assertEqual(orchestrator.state.get("current_step_index"), 0)
        self.assertEqual(orchestrator.state.get("total_steps_completed"), 0)

        # Run first step
        print("Running step 1...")
        success = orchestrator.run_one_step()
        self.assertTrue(success, "First step should succeed")

        # Verify state after first step
        self.assertEqual(orchestrator.state.get("current_iteration"), 1)
        self.assertEqual(orchestrator.state.get("current_step_index"), 1)
        self.assertEqual(orchestrator.state.get("total_steps_completed"), 1)
        self.assertIn("step1", orchestrator.state.get("completed_steps", []))

        # Verify output was created
        outputs_dir = os.path.join(scenario_path, "outputs")
        self.assertTrue(os.path.exists(outputs_dir))
        archives = [f for f in os.listdir(outputs_dir) if f.endswith(".zip")]
        self.assertEqual(len(archives), 1, "Should have one archive after step 1")
        self.assertIn("step1_results_iter1.zip", archives)

        # Run second step
        print("Running step 2...")
        success = orchestrator.run_one_step()
        self.assertTrue(success, "Second step should succeed")

        # Verify state after second step
        self.assertEqual(orchestrator.state.get("current_step_index"), 2)
        self.assertEqual(orchestrator.state.get("total_steps_completed"), 2)

        # Run third step (last in iteration 1)
        print("Running step 3...")
        success = orchestrator.run_one_step()
        self.assertTrue(success, "Third step should succeed")

        # Verify we're now ready for iteration 2
        self.assertEqual(orchestrator.state.get("current_iteration"), 2)
        self.assertEqual(orchestrator.state.get("current_step_index"), 0)
        self.assertEqual(orchestrator.state.get("total_steps_completed"), 3)
        self.assertEqual(len(orchestrator.state.get("completed_steps", [])), 0)

        # Run first step of iteration 2
        print("Running step 1 of iteration 2...")
        success = orchestrator.run_one_step()
        self.assertTrue(success, "First step of iteration 2 should succeed")

        # Verify archives for both iterations
        archives = [f for f in os.listdir(outputs_dir) if f.endswith(".zip")]
        self.assertEqual(
            len(archives), 4, "Should have 4 archives (3 from iter1, 1 from iter2)"
        )

        print("[OK] Run one step test completed successfully")

    def test_07_run_one_iteration(self):
        """Test run_one_iteration - execute all steps in one iteration."""
        print("\n=== Test 7: Run One Iteration ===")

        scenario_name = "db_test_one_iteration"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create config
        self._create_test_config_file(scenario_path, self.test_config)

        # Initialize orchestrator
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )

        # Run first iteration
        print("Running iteration 1...")
        success = orchestrator.run_one_iteration()
        self.assertTrue(success, "First iteration should succeed")

        # Verify state after first iteration
        self.assertEqual(orchestrator.state.get("current_iteration"), 2)
        self.assertEqual(orchestrator.state.get("current_step_index"), 0)
        self.assertEqual(orchestrator.state.get("total_steps_completed"), 3)

        # Verify all step1, step2, step3 archives were created for iter1
        outputs_dir = os.path.join(scenario_path, "outputs")
        archives = [f for f in os.listdir(outputs_dir) if f.endswith(".zip")]
        self.assertEqual(len(archives), 3, "Should have 3 archives from iteration 1")
        self.assertIn("step1_results_iter1.zip", archives)
        self.assertIn("step2_results_iter1.zip", archives)
        self.assertIn("step3_results_iter1.zip", archives)

        # Run second iteration
        print("Running iteration 2...")
        success = orchestrator.run_one_iteration()
        self.assertTrue(success, "Second iteration should succeed")

        # Verify final state
        self.assertEqual(orchestrator.state.get("status"), "completed")
        self.assertEqual(orchestrator.state.get("total_steps_completed"), 6)
        self.assertTrue(orchestrator.state.is_all_iterations_complete())

        # Verify all archives
        archives = [f for f in os.listdir(outputs_dir) if f.endswith(".zip")]
        self.assertEqual(
            len(archives), 6, "Should have 6 archives total (3 per iteration)"
        )

        print("[OK] Run one iteration test completed successfully")

    def test_08_resume_from_step_same_iteration(self):
        """Test resume_from_step within the same iteration."""
        print("\n=== Test 8: Resume From Step (Same Iteration) ===")

        scenario_name = "db_test_resume_same_iter"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create config
        self._create_test_config_file(scenario_path, self.test_config)

        # Initialize and run first iteration
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )

        print("Running iteration 1 completely...")
        orchestrator.run_one_iteration()

        # Verify iteration 1 completed
        self.assertEqual(orchestrator.state.get("current_iteration"), 2)
        outputs_dir = os.path.join(scenario_path, "outputs")
        archives = [f for f in os.listdir(outputs_dir) if f.endswith(".zip")]
        self.assertEqual(len(archives), 3)

        # Resume from step2 of iteration 1
        print("Resuming from step2 of iteration 1...")
        success = orchestrator.resume_from_step(iteration=1, step_name="step2")
        self.assertTrue(success, "Resume should succeed")

        # Verify state was reset correctly
        self.assertEqual(orchestrator.state.get("current_iteration"), 1)
        self.assertEqual(orchestrator.state.get("current_step_index"), 1)
        self.assertEqual(orchestrator.state.get("total_steps_completed"), 1)

        # Verify backups were created (files renamed with _bak suffix)
        backup_files = [f for f in os.listdir(outputs_dir) if "_bak" in f]
        self.assertEqual(
            len(backup_files), 2, "Should have renamed step2 and step3 from iter1"
        )

        # Verify original files no longer exist (they were renamed, not copied)
        remaining_archives = [
            f for f in os.listdir(outputs_dir) if f.endswith(".zip") and "_bak" not in f
        ]
        self.assertEqual(
            len(remaining_archives), 1, "Should only have step1 archive remaining"
        )

        # Run one step (should be step2)
        print("Running resumed step2...")
        success = orchestrator.run_one_step()
        self.assertTrue(success)

        # Verify new archive was created
        archives = [
            f for f in os.listdir(outputs_dir) if f.endswith(".zip") and "_bak" not in f
        ]
        step2_archives = [f for f in archives if f.startswith("step2")]
        self.assertEqual(len(step2_archives), 1, "Should have new step2 archive")

        print("[OK] Resume from step (same iteration) test completed successfully")

    def test_09_resume_from_earlier_iteration(self):
        """Test resume_from_step from an earlier iteration."""
        print("\n=== Test 9: Resume From Earlier Iteration ===")

        scenario_name = "db_test_resume_earlier"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create config
        self._create_test_config_file(scenario_path, self.test_config)

        # Initialize and run complete model
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )

        print("Running complete model (2 iterations)...")
        orchestrator.run()

        # Verify completed
        self.assertEqual(orchestrator.state.get("status"), "completed")
        outputs_dir = os.path.join(scenario_path, "outputs")
        archives = [f for f in os.listdir(outputs_dir) if f.endswith(".zip")]
        self.assertEqual(
            len(archives), 6, "Should have 6 archives (3 steps x 2 iterations)"
        )

        # Resume from start of iteration 1
        print("Resuming from start of iteration 1...")
        success = orchestrator.resume_from_step(iteration=1, step_name=None)
        self.assertTrue(success, "Resume should succeed")

        # Verify state was reset
        self.assertEqual(orchestrator.state.get("current_iteration"), 1)
        self.assertEqual(orchestrator.state.get("current_step_index"), 0)
        self.assertEqual(orchestrator.state.get("total_steps_completed"), 0)

        # Verify all outputs were renamed (backed up)
        backup_files = [f for f in os.listdir(outputs_dir) if "_bak" in f]
        self.assertEqual(len(backup_files), 6, "Should have renamed all 6 archives")

        # Verify original files no longer exist (they were renamed, not copied)
        remaining_archives = [
            f for f in os.listdir(outputs_dir) if f.endswith(".zip") and "_bak" not in f
        ]
        self.assertEqual(
            len(remaining_archives), 0, "Should have no original archives remaining"
        )

        print("[OK] Resume from earlier iteration test completed successfully")

    def test_10_resume_from_step_edge_cases(self):
        """Test edge cases for resume_from_step."""
        print("\n=== Test 10: Resume From Step Edge Cases ===")

        scenario_name = "db_test_resume_edge"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create config
        self._create_test_config_file(scenario_path, self.test_config)

        # Initialize orchestrator
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )

        # Test 1: Invalid iteration number
        print("Testing invalid iteration number...")
        success = orchestrator.resume_from_step(iteration=999)
        self.assertFalse(success, "Should fail with invalid iteration")

        # Test 2: Invalid step name
        print("Testing invalid step name...")
        success = orchestrator.resume_from_step(iteration=1, step_name="nonexistent")
        self.assertFalse(success, "Should fail with invalid step name")

        # Test 3: Resume from current iteration without step (should behave like run_one_iteration)
        print("Testing resume from current iteration without step...")
        current_iter = orchestrator.state.get("current_iteration")
        success = orchestrator.resume_from_step(iteration=current_iter, step_name=None)
        self.assertTrue(success, "Should succeed and behave like run_one_iteration")

        # Should have completed iteration 1
        self.assertEqual(orchestrator.state.get("current_iteration"), 2)
        self.assertEqual(orchestrator.state.get("total_steps_completed"), 3)

        print("[OK] Resume from step edge cases test completed successfully")

    def test_11_run_one_step_at_completion(self):
        """Test run_one_step when model is already completed."""
        print("\n=== Test 11: Run One Step at Completion ===")

        scenario_name = "db_test_completed"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create config
        self._create_test_config_file(scenario_path, self.test_config)

        # Initialize and run complete model
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )
        orchestrator.run()

        # Verify completed
        self.assertTrue(orchestrator.state.is_all_iterations_complete())
        self.assertEqual(orchestrator.state.get("status"), "completed")

        # Try to run one more step
        print("Attempting to run step after completion...")
        success = orchestrator.run_one_step()
        self.assertTrue(success, "Should return True but not execute anything")

        # Verify nothing changed
        self.assertEqual(orchestrator.state.get("status"), "completed")

        print("[OK] Run one step at completion test completed successfully")

    def test_12_run_one_iteration_at_completion(self):
        """Test run_one_iteration when model is already completed."""
        print("\n=== Test 12: Run One Iteration at Completion ===")

        scenario_name = "db_test_iter_completed"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create config
        self._create_test_config_file(scenario_path, self.test_config)

        # Initialize and run complete model
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )
        orchestrator.run()

        # Verify completed
        self.assertTrue(orchestrator.state.is_all_iterations_complete())
        initial_total_completed = orchestrator.state.get("total_steps_completed")

        # Try to run one more iteration
        print("Attempting to run iteration after completion...")
        success = orchestrator.run_one_iteration()
        self.assertTrue(success, "Should return True but not execute anything")

        # Verify nothing changed
        self.assertEqual(
            orchestrator.state.get("total_steps_completed"),
            initial_total_completed,
            "Step count should not increase",
        )

        print("[OK] Run one iteration at completion test completed successfully")

    def test_13_exceeded_iteration_handling(self):
        """Test handling when current_iteration exceeds total_iterations."""
        print("\n=== Test 13: Exceeded Iteration Handling ===")

        scenario_name = "db_test_exceeded_iter"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create config
        self._create_test_config_file(scenario_path, self.test_config)

        # Initialize orchestrator
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )

        # Manually corrupt the state to simulate exceeded iteration
        orchestrator.state.update(
            current_iteration=3,  # Beyond total_iterations=2
            current_step_index=0,
            total_steps_completed=6,  # All steps completed
        )

        print("Testing with current_iteration (3) > total_iterations (2)...")

        # Try to run one step - should detect completion
        success = orchestrator.run_one_step()
        self.assertTrue(success, "Should handle exceeded iteration gracefully")

        # Verify it recognized completion
        self.assertTrue(orchestrator.state.is_all_iterations_complete())

        print("[OK] Exceeded iteration handling test completed successfully")

    def test_14_corrupted_status_handling(self):
        """Test handling when status field is misleading but counts are correct."""
        print("\n=== Test 14: Corrupted Status Handling ===")

        scenario_name = "db_test_corrupted_status"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create config
        self._create_test_config_file(scenario_path, self.test_config)

        # Initialize and run complete model
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )
        orchestrator.run()

        # Simulate corrupted state: status says "error" but counts show completion
        orchestrator.state.update(status="error", error="Some fake error")

        print("Testing with status='error' but all iterations actually completed...")

        # Verify is_all_iterations_complete relies on counts, not status
        self.assertTrue(
            orchestrator.state.is_all_iterations_complete(),
            "Should detect completion from counts, not status",
        )

        # Try to run one step - should detect completion despite error status
        success = orchestrator.run_one_step()
        self.assertTrue(success, "Should detect completion from counts")

        # Try to run one iteration - should also detect completion
        success = orchestrator.run_one_iteration()
        self.assertTrue(success, "Should detect completion from counts")

        # Status should be corrected to "completed"
        self.assertEqual(
            orchestrator.state.get("status"), "completed", "Status should be corrected"
        )

        print("[OK] Corrupted status handling test completed successfully")

    def test_15_yaml_changes_picked_up(self):
        """Test that YAML configuration changes are picked up by run methods."""
        print("\n=== Test 15: YAML Changes Picked Up ===")

        scenario_name = "db_test_yaml_changes"
        scenario_path = os.path.join(self.test_dir, scenario_name)

        # Clean start
        if os.path.exists(scenario_path):
            shutil.rmtree(scenario_path)

        # Create initial config with all steps running on all iterations
        initial_config = self.test_config.copy()
        initial_config["sub_components"]["step1"]["iterations"] = "all"
        self._create_test_config_file(scenario_path, initial_config)

        # Initialize orchestrator
        orchestrator = OrcaOrchestrator(
            scenario_name=scenario_name, mode="local_testing"
        )

        # Run first step
        print("Running step 1 with iterations='all'...")
        success = orchestrator.run_one_step()
        self.assertTrue(success)

        # Modify YAML to change step1 to only run on first iteration
        print("Modifying YAML to set step1 iterations='first'...")
        modified_config = initial_config.copy()
        modified_config["sub_components"]["step1"]["iterations"] = "first"
        config_file = os.path.join(scenario_path, "orca_model_config.yaml")
        with open(config_file, "w") as f:
            yaml.dump(modified_config, f, default_flow_style=False)

        # Complete iteration 1
        while orchestrator.state.get("current_iteration") == 1:
            if orchestrator.state.get_next_step() is None:
                break
            orchestrator.run_one_step()

        # Start iteration 2
        if not orchestrator.state.is_all_iterations_complete():
            orchestrator.run_one_step()  # This should move to iteration 2

        # Verify we're in iteration 2
        current_iter = orchestrator.state.get("current_iteration")
        print(f"Current iteration: {current_iter}")

        # The next step should be step1, but since we changed it to "first",
        # it should be skipped in iteration 2
        # Let's check if step1 gets executed or skipped
        step1_executed_iter2 = False

        # Run iteration 2 and check if step1 was executed
        starting_steps = orchestrator.state.get("total_steps_completed")

        # Get the current step
        next_step = orchestrator.state.get_next_step()
        print(f"Next step to execute in iteration 2: {next_step}")

        # The configuration should have been reloaded, so step1 should respect
        # the new "first" condition
        if current_iter == 2 and next_step == "step1":
            # Execute the step - it should skip the command
            success = orchestrator.run_one_step()
            self.assertTrue(success)

            # Check if step was truly skipped (no new archives created for this iteration)
            outputs_dir = os.path.join(scenario_path, "outputs")
            step1_iter2_archives = [
                f
                for f in os.listdir(outputs_dir)
                if f.startswith("step1") and "iter2" in f and "_bak" not in f
            ]
            print(f"Step1 iter2 archives: {step1_iter2_archives}")

            # Step should be marked complete even if command was skipped
            self.assertIn("step1", orchestrator.state.get("completed_steps", []))

        print("[OK] YAML changes picked up test completed successfully")


if __name__ == "__main__":
    # Configure test discovery and execution
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Add integration tests in order
    suite.addTest(loader.loadTestsFromTestCase(TestOrcaIntegration))
    suite.addTest(loader.loadTestsFromTestCase(TestRealConfigIntegration))
    suite.addTest(loader.loadTestsFromTestCase(TestAdvancedExecution))

    # Run tests with detailed output
    runner = unittest.TextTestRunner(verbosity=2, stream=sys.stdout)
    result = runner.run(suite)

    # Exit with error code if tests failed
    sys.exit(0 if result.wasSuccessful() else 1)
