"""
Azure Credential Manager

This module provides a centralized, reusable Azure credential manager for all
tlpytools modules that need to authenticate with Azure services (ADLS, Batch, etc.).

Key Features:
- Singleton pattern for credential reuse across modules
- Configurable DefaultAzureCredential with environment variable support
- Token caching with automatic refresh for Azure Batch API
- Support for multiple Azure service scopes
- Thread-safe credential and token management
"""

from .env_config import get_env_var

import logging
import threading
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import inspect
from azure.identity import DefaultAzureCredential
from azure.core.credentials import AccessToken


class AzureCredentialManager:
    """
    Centralized Azure credential manager with singleton pattern.

    This class provides a thread-safe, singleton instance for managing Azure credentials
    across all tlpytools modules. It handles:
    - DefaultAzureCredential creation with configurable options
    - Token caching and automatic refresh for various Azure services
    - Support for multiple service scopes (Batch, Storage, etc.)

    Environment Variables:
        OPTION_EXCLUDE_ENVIRONMENT_CREDENTIAL: Exclude EnvironmentCredential (tlpytools default: True; Microsoft default: False)
        OPTION_EXCLUDE_WORKLOAD_IDENTITY_CREDENTIAL: Exclude WorkloadIdentityCredential (tlpytools default: True; Microsoft default: False)
        OPTION_EXCLUDE_MANAGED_IDENTITY_CREDENTIAL: Exclude ManagedIdentityCredential (tlpytools default: True; Microsoft default: False)
        OPTION_EXCLUDE_SHARED_TOKEN_CACHE_CREDENTIAL: Exclude SharedTokenCacheCredential (tlpytools default: True; Microsoft default: False)
        OPTION_EXCLUDE_VISUAL_STUDIO_CODE_CREDENTIAL: Exclude VisualStudioCodeCredential (tlpytools default: True; Microsoft default: False)
        OPTION_EXCLUDE_AZURE_CLI_CREDENTIAL: Exclude AzureCliCredential (tlpytools default: False; Microsoft default: False)
        OPTION_EXCLUDE_AZURE_POWERSHELL_CREDENTIAL: Exclude AzurePowerShellCredential (tlpytools default: True; Microsoft default: False)
        OPTION_EXCLUDE_DEVELOPER_CLI_CREDENTIAL: Exclude AzureDeveloperCliCredential (tlpytools default: True; Microsoft default: False)
        OPTION_EXCLUDE_INTERACTIVE_BROWSER_CREDENTIAL: Exclude InteractiveBrowserCredential (tlpytools default: True; Microsoft default: True)
        OPTION_EXCLUDE_BROKER_CREDENTIAL: Exclude brokered/WAM authentication (tlpytools default: True; Microsoft default: False)

    Usage:
        # Get the credential manager instance
        credential_manager = AzureCredentialManager.get_instance()

        # Get the Azure credential for use with Azure SDK clients
        credential = credential_manager.get_credential()

        # Get an access token for a specific Azure service
        token = credential_manager.get_access_token("https://batch.core.windows.net/")

        # Use with Azure Storage clients
        file_system_client = FileSystemClient(
            account_url=account_url,
            file_system_name=container_name,
            credential=credential_manager.get_credential()
        )
    """

    _instance: Optional["AzureCredentialManager"] = None
    _lock = threading.Lock()

    def __new__(cls):
        """Implement singleton pattern with thread safety."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        """Initialize the credential manager (only runs once due to singleton)."""
        # Only initialize once
        if hasattr(self, "_initialized") and self._initialized:
            return

        self._logger = logging.getLogger("AzureCredentialManager")
        self._credential: Optional[DefaultAzureCredential] = None
        self._token_cache: Dict[str, Dict[str, Any]] = {}
        self._token_cache_lock = threading.Lock()
        self._initialized = True

        self._logger.debug("AzureCredentialManager initialized")

    @classmethod
    def get_instance(cls) -> "AzureCredentialManager":
        """
        Get the singleton instance of AzureCredentialManager.

        Returns:
            AzureCredentialManager: The singleton instance
        """
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def get_credential(self, force_refresh: bool = False) -> DefaultAzureCredential:
        """
        Get the Azure credential, creating it if necessary.

        Args:
            force_refresh: Force creation of a new credential instance

        Returns:
            DefaultAzureCredential: The Azure credential instance
        """
        if self._credential is None or force_refresh:
            with self._lock:
                if self._credential is None or force_refresh:
                    if force_refresh and self._credential is not None:
                        self._logger.info(
                            "Forcing credential refresh due to authentication issues"
                        )
                        # Clear token cache when forcing refresh
                        self.clear_token_cache()
                    self._credential = self._create_credential()

        return self._credential

    def _create_credential(self) -> DefaultAzureCredential:
        """
        Create a new DefaultAzureCredential with configuration from environment variables.

        For more info, see https://learn.microsoft.com/en-us/python/api/azure-identity/azure.identity.defaultazurecredential?view=azure-python

        Returns:
            DefaultAzureCredential: Configured credential instance
        """
        self._logger.debug("Creating new DefaultAzureCredential...")

        # Get configuration from environment variables.
        # NOTE: tlpytools defaults intentionally differ from the DefaultAzureCredential
        # constructor defaults documented by Microsoft.
        exclude_environment_credential = get_env_var(
            "OPTION_EXCLUDE_ENVIRONMENT_CREDENTIAL", default=True
        )
        exclude_workload_identity_credential = get_env_var(
            "OPTION_EXCLUDE_WORKLOAD_IDENTITY_CREDENTIAL", default=True
        )
        exclude_managed_identity_credential = get_env_var(
            "OPTION_EXCLUDE_MANAGED_IDENTITY_CREDENTIAL", default=True
        )
        exclude_shared_token_cache_credential = get_env_var(
            "OPTION_EXCLUDE_SHARED_TOKEN_CACHE_CREDENTIAL", default=True
        )
        exclude_visual_studio_code_credential = get_env_var(
            "OPTION_EXCLUDE_VISUAL_STUDIO_CODE_CREDENTIAL", default=True
        )
        exclude_cli_credential = get_env_var(
            "OPTION_EXCLUDE_AZURE_CLI_CREDENTIAL", default=False
        )
        exclude_powershell_credential = get_env_var(
            "OPTION_EXCLUDE_AZURE_POWERSHELL_CREDENTIAL", default=True
        )
        exclude_developer_cli_credential = get_env_var(
            "OPTION_EXCLUDE_DEVELOPER_CLI_CREDENTIAL", default=True
        )
        exclude_interactive_browser_credential = get_env_var(
            "OPTION_EXCLUDE_INTERACTIVE_BROWSER_CREDENTIAL", default=True
        )
        # Newer azure-identity versions may include a Windows broker/WAM credential in
        # DefaultAzureCredential. In some enterprise environments it can fail with
        # Status_IncorrectConfiguration (and then the whole chain fails if no other
        # credential is usable). Allow opting out via env var.
        exclude_broker_credential = get_env_var(
            "OPTION_EXCLUDE_BROKER_CREDENTIAL", default=True
        )

        # Log the configuration
        self._logger.debug("Azure Credential Configuration:")
        self._logger.debug(
            "  Exclude Environment Credential: %s", exclude_environment_credential
        )
        self._logger.debug(
            "  Exclude Workload Identity Credential: %s",
            exclude_workload_identity_credential,
        )
        self._logger.debug(
            "  Exclude Managed Identity Credential: %s",
            exclude_managed_identity_credential,
        )
        self._logger.debug(
            "  Exclude Interactive Browser Credential: %s",
            exclude_interactive_browser_credential,
        )
        self._logger.debug(
            "  Exclude Shared Token Cache Credential: %s",
            exclude_shared_token_cache_credential,
        )
        self._logger.debug(
            "  Exclude Visual Studio Code Credential: %s",
            exclude_visual_studio_code_credential,
        )
        self._logger.debug("  Exclude Azure CLI Credential: %s", exclude_cli_credential)
        self._logger.debug(
            "  Exclude Azure PowerShell Credential: %s", exclude_powershell_credential
        )
        self._logger.debug(
            "  Exclude Developer CLI Credential: %s", exclude_developer_cli_credential
        )
        self._logger.debug("  Exclude Broker Credential: %s", exclude_broker_credential)

        kwargs: Dict[str, Any] = {
            "exclude_environment_credential": exclude_environment_credential,
            "exclude_workload_identity_credential": exclude_workload_identity_credential,
            "exclude_managed_identity_credential": exclude_managed_identity_credential,
            "exclude_interactive_browser_credential": exclude_interactive_browser_credential,
            "exclude_shared_token_cache_credential": exclude_shared_token_cache_credential,
            "exclude_visual_studio_code_credential": exclude_visual_studio_code_credential,
            "exclude_cli_credential": exclude_cli_credential,
            "exclude_powershell_credential": exclude_powershell_credential,
            "exclude_developer_cli_credential": exclude_developer_cli_credential,
            "exclude_broker_credential": exclude_broker_credential,
        }

        # Maintain compatibility across azure-identity versions by only passing
        # supported keyword arguments.
        try:
            sig = inspect.signature(DefaultAzureCredential)
            accepts_var_kwargs = any(
                p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()
            )
            if not accepts_var_kwargs:
                kwargs = {k: v for k, v in kwargs.items() if k in sig.parameters}
        except (TypeError, ValueError):
            # If we can't introspect, fall back to passing all kwargs.
            pass

        credential = DefaultAzureCredential(**kwargs)

        self._logger.info("DefaultAzureCredential created successfully")
        return credential

    def get_access_token(self, scope: str, force_refresh: bool = False) -> AccessToken:
        """
        Get an access token for a specific Azure service scope.

        This method implements token caching with automatic refresh. Tokens are
        cached per scope and automatically refreshed when they expire or are about
        to expire (5 minute buffer).

        """
        current_time = datetime.now(timezone.utc)

        # Check if we have a cached token that's still valid
        with self._token_cache_lock:
            if scope in self._token_cache and not force_refresh:
                cached = self._token_cache[scope]
                token_expires_on = cached.get("expires_on", 0)

                # Refresh if token is expired or about to expire (5 minute buffer)
                if current_time.timestamp() < (token_expires_on - 300):
                    self._logger.debug("Using cached access token for scope: %s", scope)
                    return AccessToken(
                        token=cached["token"], expires_on=token_expires_on
                    )

        # Need to get a new token
        self._logger.debug("Retrieving new access token for scope: %s", scope)
        credential = self.get_credential()
        token = credential.get_token(scope)

        # Cache the token
        with self._token_cache_lock:
            self._token_cache[scope] = {
                "token": token.token,
                "expires_on": token.expires_on,
                "retrieved_at": current_time.timestamp(),
            }

        self._logger.debug(
            "Access token retrieved successfully for scope: %s (expires: %s)",
            scope,
            datetime.fromtimestamp(token.expires_on, tz=timezone.utc).isoformat(),
        )

        return token

    def get_batch_access_token(self, force_refresh: bool = False) -> str:
        """
        Get an access token for Azure Batch API.

        This is a convenience method for getting Batch API tokens.

        Args:
            force_refresh: Force retrieval of a new token

        Returns:
            str: The access token string
        """
        token = self.get_access_token("https://batch.core.windows.net/", force_refresh)
        return token.token

    def get_storage_access_token(self, force_refresh: bool = False) -> str:
        """
        Get an access token for Azure Storage.

        This is a convenience method for getting Storage API tokens.

        Args:
            force_refresh: Force retrieval of a new token

        Returns:
            str: The access token string
        """
        token = self.get_access_token("https://storage.azure.com/", force_refresh)
        return token.token

    def clear_token_cache(self, scope: Optional[str] = None) -> None:
        """
        Clear the token cache.

        Args:
            scope: If provided, clear only the token for this scope.
                   If None, clear all cached tokens.
        """
        with self._token_cache_lock:
            if scope is not None:
                if scope in self._token_cache:
                    del self._token_cache[scope]
                    self._logger.debug("Cleared token cache for scope: %s", scope)
            else:
                self._token_cache.clear()
                self._logger.debug("Cleared all token caches")

    def reset(self) -> None:
        """
        Reset the credential manager, clearing all cached credentials and tokens.

        This is useful for testing or when credential configuration changes.
        """
        with self._lock:
            self._credential = None
            self.clear_token_cache()
            self._logger.debug("AzureCredentialManager reset complete")


# Convenience functions for backward compatibility and ease of use
def get_azure_credential(force_refresh: bool = False) -> DefaultAzureCredential:
    """
    Get the Azure credential from the singleton credential manager.

    Args:
        force_refresh: Force creation of a new credential instance

    Returns:
        DefaultAzureCredential: The Azure credential instance
    """
    return AzureCredentialManager.get_instance().get_credential(force_refresh)


def get_batch_access_token(force_refresh: bool = False) -> str:
    """
    Get an access token for Azure Batch API.

    Args:
        force_refresh: Force retrieval of a new token

    Returns:
        str: The access token string
    """
    return AzureCredentialManager.get_instance().get_batch_access_token(force_refresh)


def get_storage_access_token(force_refresh: bool = False) -> str:
    """
    Get an access token for Azure Storage.

    Args:
        force_refresh: Force retrieval of a new token

    Returns:
        str: The access token string
    """
    return AzureCredentialManager.get_instance().get_storage_access_token(force_refresh)


__all__ = [
    "AzureCredentialManager",
    "get_azure_credential",
    "get_batch_access_token",
    "get_storage_access_token",
]
