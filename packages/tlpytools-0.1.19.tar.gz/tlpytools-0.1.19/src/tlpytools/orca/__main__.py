"""
Entry point for running the ORCA orchestrator as a module.

This allows the module to be executed with:
    python -m tlpytools.orca

This command will execute the CLI interface with argument parsing.
"""

if __name__ == "__main__":
    from .cli import main

    main()
