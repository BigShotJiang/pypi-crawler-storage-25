# ORCA Transportation Model Orchestrator

The ORCA Orchestrator is a comprehensive Python tool for managing and executing the ORCA transportation model. It provides a unified interface for model initialization, execution, state management, and cloud synchronization.

## Overview

The orchestrator manages complex transportation modeling workflows by:
- Coordinating multiple sub-component models (ActivitySim, Quetzal, PopulationSim, etc.)
- Managing scenario lifecycle (initialization, execution, archiving)
- Handling cloud synchronization with Azure Data Lake Storage (ADLS)
- Providing performance monitoring and error handling
- Maintaining execution state across iterations and steps

## Architecture

The orchestrator consists of several key components:

### Core Classes

1. **`OrcaOrchestrator`** - Main orchestrator class that manages model execution
2. **`OrcaLogger`** - Centralized logging with singleton behavior
3. **`OrcaState`** - State management for tracking iterations and steps
4. **`OrcaScenario`** - Local file operations and scenario management
5. **`OrcaFileSync`** - Cloud synchronization with Azure Data Lake Storage
6. **`OrcaPerformanceMonitor`** - Runtime and system resource monitoring

### Key Features

- **Multi-mode execution**: Local testing and cloud production modes
- **Iterative modeling**: Support for multiple model iterations with state persistence
- **Cloud integration**: Seamless synchronization with Azure Data Lake Storage
- **Error handling**: Comprehensive error dumps and recovery mechanisms
- **Performance monitoring**: Real-time tracking of system resources and execution time
- **Template management**: Automated copying and setup of model templates

## Usage

### Command Line Interface

The orchestrator provides an action-based command line interface:

```bash
python -m tlpytools.orca.cli [options]
```

The cli can also be access through the orca module, as it will be automatically redirected to cli:

```bash
python -m tlpytools.orca [options]
```

For information on how to use the cli commands, call for help:

```bash
python -m tlpytools.orca --help
```


### Actions

#### 1. Run Models (`run_model`)
Initialize and run the complete model workflow.

```bash
# Basic model run
python -m tlpytools.orca --action run_model --scenario db_example

# Advanced options
python -m tlpytools.orca --action run_model \
    --scenario db_example \
    --mode cloud_production \
    --project custom_project
```

#### 2. Initialize Scenario (`init_model`)
Create and set up a new scenario without running models.

```bash
# Initialize new scenario
python -m tlpytools.orca --action init_model --scenario db_example
```

#### 3. Cloud Synchronization (`adls_sync`)
Synchronize scenario with Azure Data Lake Storage.

```bash
# Upload to cloud
python -m tlpytools.orca --action adls_sync --project my_project_folder --scenario db_example --sync-action upload

# Download from cloud (automatically skips local initialization if scenario doesn't exist)
python -m tlpytools.orca --action adls_sync --project my_project_folder --scenario db_example --sync-action download

# List cloud contents
python -m tlpytools.orca --action adls_sync --project my_project_folder --scenario db_example --sync-action list
```

**Download Behavior:**
- If local scenario doesn't exist: Creates minimal barebone config, downloads entire scenario from cloud
- If local scenario exists: Downloads only state and new outputs (preserves local sub-components)
- Skips local initialization to prevent template conflicts with cloud files

### Options

| Option | Description | Default |
|--------|-------------|---------|  
| `--scenario` | Name of the scenario | `db_test` |
| `--mode` | Execution mode (`local_testing`, `cloud_production`) | `local_testing` |
| `--project` | Override ADLS project folder path | From config file |
| `--verbose` | Enable verbose logging | `False` |

## Configuration Files

### File Locations and Naming

The orchestrator uses **fixed file names** that cannot be changed:

- **Configuration file**: Always named `orca_model_config.yaml` (located in scenario folder)
- **State file**: Always named `orca_model_state.json` (located in scenario folder, auto-generated)

**Where to place your configuration template:**

Before initializing a scenario, place your configuration template in one of these locations (searched in this order):
1. `./orca_model_config_default.yaml` (project root - **recommended**)
2. `./orca/orca_model_config_default.yaml`
3. `./src/orca/orca_model_config_default.yaml`

If no template is found, a minimal barebone configuration will be created automatically.

### State File Behavior

**Important:** The state file (`orca_model_state.json`) is automatically managed by the orchestrator:

- ✅ **Auto-generated**: Created automatically during scenario initialization
- ✅ **Runtime tracking**: Updated automatically as the model executes
- ✅ **YAML takes precedence**: Configuration file is the single source of truth
- ❌ **Never edit manually**: Manual edits will be overwritten by configuration values

**Configuration vs. State:**
- **To change iterations or steps**: Edit `orca_model_config.yaml` in your scenario folder
- **State automatically syncs**: The orchestrator reads the config and updates state on every run
- **Example**: If config specifies 6 iterations but state shows 4, the config value (6) will be used

**Why this design?**
- Prevents confusion from conflicting values in config vs. state
- Makes it clear that YAML is where you control execution
- State file is purely for tracking progress, not for user input

## Configuration

The orchestrator uses a YAML configuration file system with the following behavior:

### Configuration File Loading Hierarchy

1. **Active Configuration**: The orchestrator always uses `orca_model_config.yaml` located in the scenario directory for all operations.

2. **Template Configuration**: When creating a new scenario, the orchestrator searches for `orca_model_config_default.yaml` in the following order:
   - Current working directory (project root): `./orca_model_config_default.yaml`
   - Orca subfolder of working directory: `./orca/orca_model_config_default.yaml`
   - Src/orca subfolder of working directory: `./src/orca/orca_model_config_default.yaml`
   - If not found, a barebone config is created programmatically (see `orca_model_config_barebone.yaml` for reference)

### Configuration File Behavior

- **Automatic Template Creation**: If no template is found, the orchestrator will create a minimal barebone configuration programmatically for cloud initialization.

- **Barebone Configuration Reference**: The package includes `orca_model_config_barebone.yaml` which shows the minimal configuration structure used for cloud initialization. This file is provided for reference only and is not used directly.

### Setup Example

```bash
# 1. Place your configuration template in project root (recommended)
cp my_config.yaml ./orca_model_config_default.yaml

# 2. Initialize scenario (uses template, creates orca_model_config.yaml in scenario)
python -m tlpytools.orca --action init_model --scenario db_example

# 3. Run the model (always uses orca_model_config.yaml from scenario directory)
python -m tlpytools.orca --action run_model --scenario db_example
```

The configuration file defines:

### Model Configuration Structure

```yaml
# Model execution settings
model_steps:
  - activitysim
  - quetzal
  - populationsim

iterations:
  total: 3
  start_at: 1

# Sub-component configurations
sub_components:
  activitysim:
    template_dir: "/path/to/activitysim/template"
    commands:
      - description: "Run ActivitySim"
        command: "python run_activitysim.py"
    output_archives:
      - pattern: "outputs/*.csv"
        archive_name: "activitysim_outputs"
    cleanup_patterns:
      - "*.tmp"
      - "temp_*"

# Input data sources
input_data:
  landuse:
    - source: "/shared/landuse/"
      target: "inputs/landuse/"
  networks:
    - source: "/shared/networks/"
      target: "inputs/networks/"

# Cloud operations
operational_mode:
  cloud:
    adls_url: "https://account.dfs.core.windows.net"
    adls_container: "raw"
    adls_folder: "orca_scenarios"

# Logging configuration
logging:
  level: INFO  # Options: DEBUG, INFO, WARNING, ERROR, CRITICAL

# Performance monitoring
performance_monitoring:
  enabled: true
  poll_interval: 1.0
  track_memory: true
  track_cpu: true
```

## Logging Configuration

The orchestrator supports configurable logging levels to control the verbosity of output:

### Logging Levels

Configure the logging level in your `orca_model_config.yaml`:

```yaml
logging:
  level: INFO  # Options: DEBUG, INFO, WARNING, ERROR, CRITICAL
```

Available levels (from most to least verbose):
- **DEBUG**: Detailed information for diagnosing problems. Shows all internal operations, file operations, and step-by-step execution details.
- **INFO** (default, recommended): General informational messages about model progress. Shows one summary message per step/action.
- **WARNING**: Warning messages for potentially harmful situations
- **ERROR**: Error messages for serious problems
- **CRITICAL**: Critical messages for very serious errors

### Logging Behavior

- **INFO level** (default): Provides a clean, high-level view of model execution with approximately one log message per step or major action
- **DEBUG level**: Provides detailed diagnostic information useful for troubleshooting, including:
  - Detailed file operations
  - Environment setup information
  - Performance monitoring details
  - System information
  - Step-by-step execution details

### Example Usage

```bash
# Run with default INFO logging
python -m tlpytools.orca --action run_model --scenario db_example

# For detailed troubleshooting, set level to DEBUG in config file
# Then run the model
python -m tlpytools.orca --action run_model --scenario db_example
```

Logs are written to `orca_YYYYMMDD_HHMMSS.log` in the scenario directory.

## Execution Modes

### Local Testing Mode
- Executes models locally without cloud integration
- Suitable for development and testing
- All data remains on local filesystem
- Can create new scenarios and upload to cloud

### Cloud Production Mode
- **Requires existing cloud scenario** - downloads complete scenario from Azure Data Lake Storage
- Fresh VM starts with barebone config, downloads all files from cloud
- **Will not create new scenarios** - use local_testing mode first to create and upload
- Suitable for production modeling workflows on cloud infrastructure
- Supports distributed execution via Azure Batch
- Error if cloud scenario doesn't exist (prevents accidental empty runs)

## Model Execution and Resume Behavior

The orchestrator uses the configuration file and state file to determine what to run. **All execution parameters (iterations, steps) come from the config file** - there are no CLI overrides for these.

### First Run
When you run a model for the first time (no state file exists):
- Reads `iterations.total` and `model_steps` from `orca_model_config.yaml`
- Creates state file to track progress
- Executes all iterations and steps defined in config

### Resuming Execution
When you run a model that has existing state:
- Automatically resumes from the last completed step
- Compares config file against state file
- If config changed (e.g., increased iterations from 4 to 6), continues from where it left off
- Example: If 4 iterations were completed and config now specifies 6, runs 2 additional iterations

### Modifying Execution
To change what the model runs:
1. **Edit the config file** (`orca_model_config.yaml` in the scenario directory)
2. Run `--action run_model` - it will automatically detect and apply changes
3. Model will resume and complete the updated requirements

### Starting Fresh
To restart a model from the beginning:
1. Delete or rename the state file (`orca_model_state.json`)
2. Or delete the entire scenario and reinitialize with `--action init_model`

This design ensures:
- **Predictable behavior**: Config file is the single source of truth
- **Easy resumption**: Just run the same command - it figures out what's needed
- **Change flexibility**: Update config file to run more iterations or different steps
- **No confusion**: No CLI parameters that might conflict with saved state

## File Management

### Configuration File Management

The orchestrator implements a sophisticated configuration file management system:

#### File Naming Convention
- **Active Configuration**: Always named `orca_model_config.yaml` in the scenario directory
- **Template Configuration**: Named `orca_model_config_default.yaml` for automatic template creation
- **Barebone Configuration**: `orca_model_config_barebone.yaml` in the package provides a minimal reference for cloud initialization

#### Configuration Resolution Process
1. **Scenario Initialization**: 
   - Search for `orca_model_config_default.yaml` template in project directories
   - If found, copy to scenario as `orca_model_config.yaml`
   - If not found, create barebone config programmatically

2. **Existing Scenario Operations**:
   - Always load `orca_model_config.yaml` from scenario directory
   - If missing, attempt to recreate from template
   - Log configuration source for troubleshooting

#### Best Practices
- **Template Setup**: Place `orca_model_config_default.yaml` in your project root for consistent initialization
- **Custom Configurations**: Use descriptive names for project-specific configs (e.g., `production_config.yaml`)
- **Version Control**: Include template configurations in version control, exclude scenario-specific configs
- **Barebone Reference**: Use `orca_model_config_barebone.yaml` as a minimal example for cloud deployments

### Scenario Structure
```
scenario_folder/                 # Scenario name usually starts with db_
├── orca_model_config.yaml       # Configuration file
├── orca_model_state.json        # Execution state (includes project/scenario identity)
├── logs/                        # Scenario-specific log files
│   └── orca_20251030_172324.log # Orchestrator logs
├── inputs/                      # Shared input data
├── outputs/                     # Model outputs
├── activitysim/                 # Sub-component folder
├── quetzal/                     # Sub-component folder
└── .cloud_sync_conflict/        # Conflict resolution

# Non-scenario specific logs
./logs/                          # Working folder logs
├── run_model.log                # Action-specific logs
├── init_model.log
└── adls_data_sync.log
```

### Cloud Synchronization Behavior

The orchestrator implements intelligent, state-aware synchronization with Azure Data Lake Storage:

#### Scenario Identity and Name Management
- Each scenario is identified by its `project_name` and `scenario_name` stored in the state file
- **Folder name is authoritative**: The `scenario_name` is always derived from the local folder basename
- **Project override is authoritative**: When using `--project`, that value becomes the `project_name`
- Before any sync operation, the orchestrator validates and syncs names as needed:
  - If metadata `scenario_name` differs from folder name → folder name wins, metadata updated with warning
  - If metadata `project_name` differs from config/override → config/override wins, metadata updated with warning
  - On download from cloud → cloud `project_name` syncs to local, but folder name remains authoritative for `scenario_name`
- This ensures consistent naming between local and cloud while allowing for folder renaming

#### State-Based Synchronization
The orchestrator compares state files to determine sync eligibility:

**State Comparison Logic:**
- Compares `total_steps_completed`, `current_iteration`, and `current_step_index`
- Returns: `state1_ahead`, `state2_ahead`, `equal`, or `incomparable`

**Upload Rules:**
- ❌ Barebone configs are never uploaded (used to download model run from cloud)
- ✅ Upload only if local state is ahead of or equal to remote state
- ❌ Upload blocked if remote state is ahead (prevents overwriting newer data)
- If remote doesn't exist: Upload everything (inputs, components, outputs, config, state)
- If remote exists: Upload only state and new outputs files

**Download Rules:**
- ✅ Barebone configs always allow download (will be overwritten completely)
- ✅ Download only if remote state is ahead of or equal to local state
- ❌ Download blocked if local state is ahead (prevents overwriting local progress)
- If local is barebone or empty: Download everything from remote
- If local exists: Download only state and new outputs files

#### Selective File Synchronization

**When Remote Doesn't Exist (Initial Upload):**
- Sub-component folders (zipped before upload)
- Inputs directory (zipped before upload)
- All outputs files
- Configuration and state files

**When Both Local and Remote Exist:**
- Only state files (to synchronize progress tracking)
- Only new outputs files (model results from completed steps)
- Sub-component folders are NOT re-uploaded (assumed to be consistent across iterations)
- This design assumes sub-components can run iterations using files from inputs/outputs

**Download Behavior:**
- Component zip files are extracted after download
- Config files are downloaded individually with conflict handling
- Conflict files are moved to `.cloud_sync_conflict/` folder
- Files in `.cloud_sync_conflict/` are always skipped during sync

#### Barebone Scenario Handling
Barebone configs are minimal configurations created when default templates are unavailable:
- **Never uploaded** to cloud (prevents incomplete setups from being shared)
- **Always overwritten** when downloading (no conflict resolution)
- Identified by description containing "barebone" and "cloud initialization"
- Or by having empty `model_steps` and `sub_components` sections

## State Management

The orchestrator maintains execution state in `orca_model_state.json`:

```json
{
  "project_name": "my_project",
  "scenario_name": "scenario_2030",
  "start_at": 1,
  "total_iterations": 3,
  "current_iteration": 1,
  "steps": ["activitysim", "quetzal"],
  "completed_steps": ["activitysim"],
  "total_steps_completed": 1,
  "current_step_index": 1,
  "status": "running",
  "start_time": "2025-01-15 10:30:00",
  "last_updated": "2025-01-15 11:45:00"
}
```

### State Fields

- `project_name`: Project identifier for cloud synchronization (from config or --project override)
- `scenario_name`: Model run identifier (always derived from local folder basename)
- `total_steps_completed`: Cumulative steps across all iterations (used for state comparison)
- `current_iteration`: Current iteration number (1-based)
- `current_step_index`: Index of current step within iteration (0-based)
- `completed_steps`: Steps completed in current iteration (resets each iteration)

### State Comparison

The `OrcaState.compare_states()` method determines which state is further ahead:
1. First checks project/scenario name compatibility
2. Compares `total_steps_completed` (primary metric)
3. If equal, compares `current_iteration`
4. If equal, compares `current_step_index`
5. Returns: `state1_ahead`, `state2_ahead`, `equal`, or `incomparable`

## Performance Monitoring

When enabled, the orchestrator tracks:
- Runtime duration for each step
- System memory usage (GB)
- CPU utilization (%)
- Process-specific metrics

Monitoring data is exported to CSV files for analysis.

## Error Handling

### Error Dumps
When a model execution fails, the orchestrator creates comprehensive error dumps containing:
- All data from the failed step directory
- Configuration files
- Log files
- System state information
- Optionally, entire scenario content

### Recovery
The state file enables resuming execution from the last successful step.

## Dependencies

### Required:
- Python 3.7+
- PyYAML
- Standard library modules (json, logging, argparse, etc.)

### Optional:
- `psutil` - For system monitoring
- `tlpytools.adls_server` - For Azure Data Lake Storage integration
- `tlpytools.azure_credential` - For centralized Azure authentication (recommended)

### Azure-related:
- `azure-identity` - Required for Azure authentication
- `azure-storage-filedatalake` - Required for ADLS operations
- `requests` - Required for Azure Batch API calls

## Environment Variables

### ORCA-specific Variables
- `UPLOAD_OUTPUTS_ONLY` - If set to True, only uploads outputs and config files to cloud
- Performance monitoring can be controlled via config file

### Azure Authentication Variables
The orchestrator and batch task runner use centralized Azure authentication via `AzureCredentialManager`. 
Configure authentication behavior with these environment variables:

Note: Defaults shown here are the tlpytools defaults (CLI-first), and differ from Microsoft `DefaultAzureCredential` defaults.

- `OPTION_EXCLUDE_ENVIRONMENT_CREDENTIAL` (default: `true`)
- `OPTION_EXCLUDE_WORKLOAD_IDENTITY_CREDENTIAL` (default: `true`)
- `OPTION_EXCLUDE_MANAGED_IDENTITY_CREDENTIAL` (default: `true`)
- `OPTION_EXCLUDE_SHARED_TOKEN_CACHE_CREDENTIAL` (default: `true`)
- `OPTION_EXCLUDE_VISUAL_STUDIO_CODE_CREDENTIAL` (default: `true`)
- `OPTION_EXCLUDE_AZURE_CLI_CREDENTIAL` (default: `false`)
- `OPTION_EXCLUDE_AZURE_POWERSHELL_CREDENTIAL` (default: `true`)
- `OPTION_EXCLUDE_DEVELOPER_CLI_CREDENTIAL` (default: `true`)
- `OPTION_EXCLUDE_INTERACTIVE_BROWSER_CREDENTIAL` (default: `true`)
- `OPTION_EXCLUDE_BROKER_CREDENTIAL` (default: `true`)

### Required Azure Service Variables
See [ENVIRONMENT_VARIABLES.md](../../../ENVIRONMENT_VARIABLES.md) for complete list of required and optional environment variables, including:

- `ORCA_ADLS_URL` - Azure Data Lake Storage endpoint
- `BATCH_ACCOUNT_ENDPOINT` - Azure Batch account endpoint
- `IMAGE_REGISTRY_ENDPOINT` - Container registry endpoint
- `AZURE_SUBSCRIPTION_ID` - Azure subscription ID
- `AZURE_RESOURCE_GROUP` - Azure resource group name
- `MANAGED_IDENTITY_NAME` - Managed identity name

For detailed authentication configuration, see [docs/azure_credential_manager.md](../../../docs/azure_credential_manager.md).

## Logging

The orchestrator provides comprehensive logging with a hierarchical organization:

### Log File Organization

**Scenario-Specific Logs** (stored in `{scenario_folder}/logs/`):
- `orca_YYYYMMDD_HHMMSS.log` - Orchestrator execution logs for the scenario
- Model step execution logs
- Performance monitoring data
- Error dumps and detailed diagnostics

**Non-Scenario Logs** (stored in `{working_folder}/logs/`):
- `run_model.log` - CLI run_model action logs
- `init_model.log` - CLI init_model action logs
- `adls_data_sync.log` - CLI adls_sync action logs

### Logging Features
- Isolated logger instances per scenario (no singleton conflicts)
- File and console output
- Configurable log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- System information capture
- Azure SDK logging suppression
- Thread-safe logging for concurrent operations

## Examples

### Local Workflow Example
```bash
# 1. Initialize a new scenario
python -m tlpytools.orca --action init_model --scenario scenario_2030

# 2. Run the complete model workflow
python -m tlpytools.orca --action run_model --scenario scenario_2030

# 3. Upload results to cloud
python -m tlpytools.orca --action adls_sync --project my_project_folder --scenario scenario_2030 --sync-action upload
```

### Cloud Production Example
```bash
# Step 1: Create and upload scenario in local_testing mode first
python -m tlpytools.orca --action init_model --scenario production_scenario
python -m tlpytools.orca --action adls_sync \
    --scenario production_scenario \
    --project production_runs \
    --sync-action upload

# Step 2: Run in cloud_production mode (downloads from cloud, requires existing scenario)
python -m tlpytools.orca --action run_model \
    --scenario production_scenario \
    --mode cloud_production \
    --project production_runs
```

**Important:** Cloud production mode requires an existing cloud scenario. If no cloud scenario exists, you'll receive an error message instructing you to use local_testing mode first.

### Debugging Example
```bash
# Run with verbose logging
python -m tlpytools.orca --action init_model \
    --scenario debug_scenario \
    --verbose
```

## Troubleshooting

### Common Issues

1. **Configuration not found**: 
   - **Error**: `FileNotFoundError: Default configuration template not found`
   - **Solution**: Place `orca_model_config_default.yaml` in your project root (or in `orca/` or `src/orca/` subdirectory)
   - **Debug**: Check log messages for exact search paths

2. **Invalid YAML syntax**:
   - **Error**: `yaml.YAMLError` during configuration loading
   - **Solution**: Validate YAML syntax using online validators or `python -c "import yaml; yaml.safe_load(open('config.yaml'))"`
   - **Debug**: Check line numbers in error messages for specific syntax issues

3. **Configuration search path issues**:
   - **Problem**: Template not found despite existing
   - **Solution**: Ensure file is in one of these locations:
     - Current working directory (project root): `./orca_model_config_default.yaml`
     - Orca subfolder: `./orca/orca_model_config_default.yaml`  
     - Src/orca subfolder: `./src/orca/orca_model_config_default.yaml`
   - **Note**: If no template is found, a barebone config will be created automatically

4. **Cloud authentication**: 
   - Verify Azure credentials are configured correctly
   - Check that required environment variables are set (see [ENVIRONMENT_VARIABLES.md](../../../ENVIRONMENT_VARIABLES.md))
   - Test authentication with: `az login` (for Azure CLI method)
   - Review authentication configuration in [docs/azure_credential_manager.md](../../../docs/azure_credential_manager.md)
   - Check credential manager logs for authentication method being used
   - Try different authentication methods by adjusting `OPTION_EXCLUDE_*` environment variables

5. **Scenario identity mismatch**:
   - **Error**: `Scenario identity mismatch detected!`
   - **Cause**: Local and remote scenarios have different project or scenario names
   - **Solution**: Verify you're syncing with the correct cloud location
   - **Prevention**: Always use consistent project and scenario names
   - **Debug**: Check state files for `project_name` and `scenario_name` fields

6. **Upload/Download blocked**:
   - **Error**: `Upload not allowed - remote state is ahead` or `Download not allowed - local state is ahead`
   - **Cause**: State comparison indicates syncing would overwrite newer data
   - **Solution**: 
     - For upload block: Download from cloud first to get latest state
     - For download block: Upload to cloud first to preserve local progress
     - Or manually resolve by backing up and choosing which state to keep
   - **Debug**: Check `total_steps_completed` in both local and remote state files

7. **Barebone config upload blocked**:
   - **Error**: `Barebone config detected - upload not allowed`
   - **Cause**: Attempting to upload incomplete/minimal configuration
   - **Solution**: Either run the model to generate complete scenario, or download from cloud
   - **Prevention**: Initialize scenario properly before attempting uploads

8. **Cloud production mode with no cloud scenario**:
   - **Error**: `No scenario found in cloud` or `Cloud production mode requires an existing cloud scenario`
   - **Cause**: Attempting to run in cloud_production mode when no cloud scenario exists
   - **Solution**: Use local_testing mode to create and upload scenario first
   - **Prevention**: Always upload scenario to cloud before running in cloud_production mode

9. **Permission errors**: Check file system permissions for scenario directory

10. **Memory issues**: Monitor system resources during large model runs

### Debug Tips

1. **Configuration Issues**:
   - Use `--verbose` flag to see detailed configuration loading messages
   - Check logs in `{scenario}/logs/` folder for configuration file search paths and resolution
   - Verify YAML syntax with: `python -c "import yaml; print(yaml.safe_load(open('your_config.yaml')))"`
   - List search locations for default config in log messages

2. **Cloud Sync Issues**:
   - Check logs in `./logs/adls_data_sync.log` for sync operation details
   - Verify state file contents: `cat {scenario}/orca_model_state.json | python -m json.tool`
   - Compare local and remote states manually to understand sync decisions
   - Use `--sync-action list` to see what files exist in cloud without downloading

3. **General Debugging**:
   - Use `--verbose` flag for detailed logging
   - Check scenario logs in `{scenario}/logs/` for execution details
   - Check working folder logs in `./logs/` for action-level issues
   - Monitor state file for execution progress

## Integration

The orchestrator is designed to integrate with:
- ActivitySim transportation modeling framework
- Quetzal strategic modeling platform
- PopulationSim population synthesis tool
- Azure Data Lake Storage for cloud workflows
- Azure Batch for distributed cloud computing
- Various transportation modeling tools and utilities

### Azure Services Integration

The orchestrator uses the centralized `AzureCredentialManager` for all Azure service authentication:

- **Azure Data Lake Storage (ADLS)**: File storage and scenario synchronization
- **Azure Batch**: Distributed task execution and job management
- **Azure Identity**: Centralized authentication with token caching

This integration provides:
- Consistent authentication across all Azure services
- Automatic token refresh and caching for better performance
- Thread-safe credential management
- Configurable authentication methods

For specific integration details, refer to:
- Sub-component documentation and configuration examples
- [docs/azure_credential_manager.md](../../../docs/azure_credential_manager.md) for Azure authentication
- [ENVIRONMENT_VARIABLES.md](../../../ENVIRONMENT_VARIABLES.md) for environment configuration


## Azure Batch Task Runner

The `batch_task_runner.py` script provides basic task add functionality for Modelers to interact with a Azure Batch Account REST API to send new tasks to perform computing tasks on Azure Cloud.

### Features

- Submits tasks to Azure Batch using the REST API
- Monitors task status with configurable polling
- Uses Azure managed identity for authentication
- Configurable through command-line arguments and environment variables
- Mirrors the functionality of the original Synapse pipeline

### Installation

1. Install the required dependencies:
```bash
pip install -r requirements.txt
```

2. Set up environment variables (see `.env.example` for reference):
```bash
# Copy and modify the example file
cp .env.example .env
# Edit .env with your specific values
```

### Environment Variables

The following environment variables are used by the script:

#### Required
- `BATCH_ACCOUNT_ENDPOINT`: Azure Batch account endpoint
- `IMAGE_REGISTRY_ENDPOINT`: Container registry endpoint
- `AZURE_SUBSCRIPTION_ID`: Azure subscription ID
- `AZURE_RESOURCE_GROUP`: Azure resource group name
- `MANAGED_IDENTITY_NAME`: Managed identity name for authentication

#### Optional (with defaults)
- `BATCH_API_VERSION`: Batch API version (default: 2024-07-01.20.0)

### Authentication

The script uses the centralized `AzureCredentialManager` from `tlpytools.azure_credential`, which provides consistent authentication across all tlpytools Azure services. The credential manager uses Azure's `DefaultAzureCredential` which supports multiple authentication methods:

1. **Environment Variables**: Service Principal credentials (AZURE_CLIENT_ID, AZURE_TENANT_ID, AZURE_CLIENT_SECRET)
2. **Managed Identity**: When running on Azure resources
3. **Azure CLI**: `az login` 
4. **Azure PowerShell**: PowerShell Azure authentication
5. **Visual Studio Code**: VS Code Azure extension
6. **Interactive Browser**: For development

#### Authentication Configuration

Control which authentication methods are enabled via environment variables:

Note: tlpytools defaults are more restrictive than Microsoft's `DefaultAzureCredential` defaults.

- `OPTION_EXCLUDE_ENVIRONMENT_CREDENTIAL` (default: `true`) - Exclude service principal via env vars
- `OPTION_EXCLUDE_WORKLOAD_IDENTITY_CREDENTIAL` (default: `true`) - Exclude workload identity
- `OPTION_EXCLUDE_MANAGED_IDENTITY_CREDENTIAL` (default: `true`) - Exclude managed identity
- `OPTION_EXCLUDE_SHARED_TOKEN_CACHE_CREDENTIAL` (default: `true`) - Exclude shared token cache
- `OPTION_EXCLUDE_VISUAL_STUDIO_CODE_CREDENTIAL` (default: `true`) - Exclude VS Code
- `OPTION_EXCLUDE_AZURE_CLI_CREDENTIAL` (default: `false`) - Exclude Azure CLI
- `OPTION_EXCLUDE_AZURE_POWERSHELL_CREDENTIAL` (default: `true`) - Exclude Azure PowerShell
- `OPTION_EXCLUDE_DEVELOPER_CLI_CREDENTIAL` (default: `true`) - Exclude Azure Developer CLI
- `OPTION_EXCLUDE_INTERACTIVE_BROWSER_CREDENTIAL` (default: `true`) - Exclude interactive browser
- `OPTION_EXCLUDE_BROKER_CREDENTIAL` (default: `true`) - Exclude broker/WAM authentication

See [ENVIRONMENT_VARIABLES.md](../../../ENVIRONMENT_VARIABLES.md) for complete configuration details.

#### Benefits of Centralized Authentication

- **Token Caching**: Automatic caching and refresh of access tokens for better performance
- **Consistency**: Same authentication behavior across ADLS and Batch operations
- **Thread Safety**: Safe for use in multi-threaded applications
- **Easy Configuration**: Single set of environment variables controls all authentication

For more details about the Azure credential manager, see [docs/azure_credential_manager.md](../../../docs/azure_credential_manager.md).

### Usage

#### Basic Usage
```bash
python batch_task_runner.py --job-id job_large --project my_project --scenario my_scenario
```

#### Full Example with All Options
```bash
python batch_task_runner.py \
    --job-id job_large \
    --project orca_optimization \
    --scenario db_test \
    --python-command orca/orchestrator.py \
    --python-env orca \
    --docker-image orca/orca:develop \
    --max-retry-count 2 \
    --max-wall-clock-time PT8H \
    --poll-interval 45 \
    --max-polls 15
```

### Command Line Arguments

| Argument | Required | Default | Description |
|----------|----------|---------|-------------|
| `--job-id` | Yes | - | Batch job ID where the task will be submitted |
| `--project` | Yes | - | Project name (used in task ID generation) |
| `--scenario` | Yes | - | Scenario name for the ORCA task |
| `--python-command` | No | `orca/orchestrator.py` | Python script to execute |
| `--python-env` | No | `orca` | Conda environment name |
| `--docker-image` | No | `orca/orca:develop` | Docker image to use |
| `--max-retry-count` | No | `0` | Maximum number of task retries |
| `--max-wall-clock-time` | No | `PT6H` | Maximum wall clock time (ISO 8601) |
| `--poll-interval` | No | `30` | Polling interval in seconds |
| `--max-polls` | No | `10` | Maximum number of polling attempts |

### How It Works

1. **Task Submission**: Creates a unique task ID and submits it to the specified Azure Batch job
2. **Status Monitoring**: Polls the task status at regular intervals
3. **Early Exit**: Stops polling when the task reaches 'running' or 'completed' state
4. **Timeout Handling**: Fails if the task doesn't start within the specified timeout

### Task ID Format

Task IDs are generated using the format: `YYYYMMDD-HHMMSS-{project}-{7-char-guid}`

Example: `20250904-143022-orca_optimization-a1b2c3d`

