"""
Command Line Interface for ORCA Orchestrator

This module provides the command-line interface for the ORCA orchestrator,
separating argument parsing and CLI handling from the core orchestrator logic.
"""

import os
import sys
import argparse
import logging

from .orchestrator import (
    OrcaOrchestrator,
    get_orca_logger,
    check_scenario_exists,
)


def main():
    """Main entry point for the ORCA orchestrator with action-based interface."""
    parser = argparse.ArgumentParser(
        description="ORCA Transportation Model Orchestrator - Unified interface for all ORCA operations",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Actions:
  run_model             Initialize and run complete model workflow
  init_model            Initialize scenario without running models  
  adls_sync            Synchronize scenario with Azure Data Lake Storage

Examples:
  # Run complete model workflow (most common use case)
  python -m tlpytools.orca.cli --action run_model --scenario db_test

  # Initialize scenario only
  python -m tlpytools.orca.cli --action init_model --scenario db_test

  # Cloud synchronization
  python -m tlpytools.orca.cli --action adls_sync --scenario db_test --sync-action upload
  python -m tlpytools.orca.cli --action adls_sync --scenario db_test --sync-action download
  python -m tlpytools.orca.cli --action adls_sync --scenario db_test --sync-action list

  # Cloud synchronization with custom project folder
  python -m tlpytools.orca.cli --action adls_sync --scenario db_test --sync-action upload --project my_custom_project

  # Advanced model running with options
  python -m tlpytools.orca.cli --action run_model --scenario db_test --mode cloud_production --project my_custom_project
        """,
    )

    parser.add_argument(
        "--action",
        choices=["run_model", "init_model", "adls_sync"],
        default="run_model",
        help="Action to perform",
    )

    parser.add_argument(
        "--scenario", default="db_test", help="Name of the scenario (scenario)"
    )

    parser.add_argument(
        "--mode",
        choices=["local_testing", "cloud_production"],
        default="local_testing",
        help="Execution mode (default: local_testing)",
    )

    # Arguments for adls_sync action
    parser.add_argument(
        "--sync-action",
        choices=["upload", "download", "list"],
        help="ADLS synchronization action: upload to ADLS, download from ADLS, or list ADLS contents",
    )

    parser.add_argument(
        "--project",
        help="Override the ADLS project folder path (adls_folder) from config file",
    )

    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")

    args = parser.parse_args()

    # Set verbose logging if requested
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Action-specific validation and execution
    if args.action == "run_model":
        # Validate required arguments for run_model
        if not args.scenario:
            parser.error("--scenario is required for run_model action")

        # Set up logging in working folder's logs directory (non-scenario specific)
        os.makedirs("logs", exist_ok=True)
        action_logger = get_orca_logger("run_model", log_file_path="logs/run_model.log")

        action_logger.info("=" * 60)
        action_logger.info("ORCA Model Runner Starting")
        action_logger.info("=" * 60)
        action_logger.info("Scenario: %s", args.scenario)
        action_logger.info("Mode: %s", args.mode)
        if args.project:
            action_logger.info("Project (override): %s", args.project)

        try:
            # Create the orchestrator instance
            orchestrator = OrcaOrchestrator(
                scenario_name=args.scenario,
                mode=args.mode,
                project_folder=args.project,
            )

            # Run the model
            action_logger.info("Starting model execution...")
            success = orchestrator.run()

            # Report results
            action_logger.info("=" * 60)
            if success:
                action_logger.info("[SUCCESS] Model execution completed successfully!")

                # Print summary information
                total_iterations = orchestrator.state.get("total_iterations", 0)
                total_steps_completed = orchestrator.state.get(
                    "total_steps_completed", 0
                )

                action_logger.info("Summary:")
                action_logger.info("  - Total iterations: %d", total_iterations)
                action_logger.info(
                    "  - Total steps completed: %d", total_steps_completed
                )
                action_logger.info(
                    "  - Scenario location: %s", orchestrator.scenario_path
                )

                if args.mode == "cloud_production":
                    action_logger.info("  - Cloud sync: enabled")
                    action_logger.info("  - Model outputs backed up to ADLS")

                # Check for outputs directory
                outputs_dir = os.path.join(orchestrator.scenario_path, "outputs")
                if os.path.exists(outputs_dir):
                    output_files = []
                    for _, _, files in os.walk(outputs_dir):
                        output_files.extend(files)
                    action_logger.info(
                        "  - Output files generated: %d", len(output_files)
                    )

                action_logger.info("=" * 60)
                action_logger.info(
                    "Model run completed. Check the scenario directory for results:"
                )
                action_logger.info("  %s", orchestrator.scenario_path)

            else:
                action_logger.error("[FAILED] Model execution failed!")

                # Print error information if available
                error_msg = orchestrator.state.get("error")
                if error_msg:
                    action_logger.error("Error details: %s", error_msg)

                # Print current state for debugging
                current_step = orchestrator.state.get_next_step()
                current_iteration = orchestrator.state.get_display_iteration()
                action_logger.error(
                    "Failed at iteration %d, step: %s", current_iteration, current_step
                )

                action_logger.info("=" * 60)
                action_logger.info("Check the logs for detailed error information.")
                action_logger.info(
                    "Model state saved to: %s", orchestrator.state.state_file_path
                )

            sys.exit(0 if success else 1)

        except KeyboardInterrupt:
            action_logger.warning("Model execution interrupted by user")
            action_logger.info(
                "Model state has been saved and can resume from last successfully completed step."
            )
            sys.exit(1)

        except (OSError, IOError, RuntimeError) as e:
            action_logger.error("Unexpected error during model execution: %s", str(e))
            action_logger.error("Check the logs for detailed error information")
            sys.exit(1)

    elif args.action == "init_model":
        # Validate required arguments for init_model
        if not args.scenario:
            parser.error("--scenario is required for init_model action")

        # Set up logging in working folder's logs directory (non-scenario specific)
        os.makedirs("logs", exist_ok=True)
        action_logger = get_orca_logger(
            "init_model", log_file_path="logs/init_model.log"
        )

        action_logger.info("=" * 60)
        action_logger.info("ORCA Scenario Initializer")
        action_logger.info("=" * 60)
        action_logger.info("Scenario: %s", args.scenario)
        if args.project:
            action_logger.info("Project (override): %s", args.project)

        try:
            # Check if scenario already exists
            scenario_path = os.path.abspath(args.scenario)
            existing_info = check_scenario_exists(scenario_path)

            if existing_info["exists"]:
                action_logger.warning("Scenario already exists at: %s", scenario_path)

                # Show what's in the existing scenario
                if existing_info.get("error"):
                    action_logger.error(
                        "Error checking scenario: %s", existing_info["error"]
                    )
                    sys.exit(1)

                if existing_info["directories"]:
                    action_logger.info(
                        "Existing directories: %s",
                        ", ".join(existing_info["directories"]),
                    )
                if existing_info["files"]:
                    action_logger.info(
                        "Existing files: %s", ", ".join(existing_info["files"])
                    )

                action_logger.error(
                    "Scenario already exists. Please remove it manually or choose a different scenario name."
                )
                action_logger.error(
                    "To remove: rm -rf %s (Linux/Mac) or rmdir /s %s (Windows)",
                    scenario_path,
                    scenario_path,
                )
                sys.exit(1)

            # Create the orchestrator instance (this will initialize the scenario)
            action_logger.info("Creating scenario structure...")
            orchestrator = OrcaOrchestrator(
                scenario_name=args.scenario,
                mode=args.mode,
                project_folder=args.project,
            )

            # Use the validate_scenario method to validate and report
            success = orchestrator.validate_scenario()

            if success:
                action_logger.info("[SUCCESS] Scenario initialization completed!")
                action_logger.info("=" * 60)
                action_logger.info("Scenario is ready for model execution!")
                action_logger.info("To run the model, use:")
                action_logger.info(
                    "  python -m tlpytools.orca.cli --action run_model --scenario %s",
                    args.scenario,
                )
            else:
                action_logger.error("[FAILED] Scenario initialization failed!")
                sys.exit(1)

        except KeyboardInterrupt:
            action_logger.warning("Initialization interrupted by user")
            sys.exit(1)

        except (OSError, IOError) as e:
            action_logger.error("File system error during initialization: %s", str(e))
            sys.exit(1)

        except ImportError as e:
            action_logger.error("Required module not found: %s", str(e))
            action_logger.error("Make sure all dependencies are installed")
            sys.exit(1)

    elif args.action == "adls_sync":
        # Validate required arguments for adls_sync
        if not args.scenario:
            parser.error("--scenario is required for adls_sync action")
        if not args.sync_action:
            parser.error("--sync-action is required for adls_sync action")

        # Set up logging in working folder's logs directory (non-scenario specific)
        os.makedirs("logs", exist_ok=True)
        action_logger = get_orca_logger(
            "adls_data_sync", log_file_path="logs/adls_data_sync.log"
        )

        action_logger.info("=" * 60)
        action_logger.info("ORCA ADLS Data Synchronization")
        action_logger.info("=" * 60)
        action_logger.info("Scenario: %s", args.scenario)
        action_logger.info("Action: %s", args.sync_action)
        if args.project:
            action_logger.info("Project (override): %s", args.project)

        try:
            # For download operations, we may need to create the orchestrator even if scenario doesn't exist locally
            skip_init = False
            if args.sync_action == "download" and not os.path.exists(args.scenario):
                # Create minimal structure for download
                os.makedirs(args.scenario, exist_ok=True)
                # Skip initialization to avoid creating local templates before cloud download
                skip_init = True
                action_logger.info(
                    "Local scenario does not exist - will download entire scenario from cloud"
                )

            orchestrator = OrcaOrchestrator(
                scenario_name=args.scenario,
                mode="local_testing",  # Assume local testing when triggering sync action manually to avoid triggering additional sync commands
                project_folder=args.project,
                skip_initialization=skip_init,
            )

            # Log ADLS settings
            adls_url, adls_container, adls_folder = orchestrator.get_adls_config()
            action_logger.info("ADLS Account URL: %s", adls_url)
            action_logger.info("ADLS Container: %s", adls_container)
            action_logger.info("ADLS Folder: %s", adls_folder)

            # Perform synchronization
            success = orchestrator.sync_with_adls(
                direction=args.sync_action,
            )

            # Report results
            action_logger.info("=" * 60)
            if success:
                action_logger.info("[SUCCESS] Synchronization completed successfully!")

                if args.sync_action == "upload":
                    action_logger.info(
                        "Scenario '%s' has been uploaded to ADLS", args.scenario
                    )
                    action_logger.info(
                        "Cloud location: %s/%s/%s/%s",
                        adls_url,
                        adls_container,
                        adls_folder,
                        args.scenario,
                    )

                elif args.sync_action == "download":
                    action_logger.info(
                        "Scenario '%s' has been downloaded from ADLS", args.scenario
                    )
                    action_logger.info(
                        "Local location: %s", os.path.abspath(args.scenario)
                    )

                elif args.sync_action == "list":
                    action_logger.info(
                        "ADLS contents listed for scenario '%s'", args.scenario
                    )

            else:
                action_logger.error("[FAILED] Synchronization failed!")
                action_logger.error("Check the logs for detailed error information")

            # Exit with appropriate code
            sys.exit(0 if success else 1)

        except KeyboardInterrupt:
            action_logger.warning("Synchronization interrupted by user")
            sys.exit(1)

        except (OSError, IOError) as e:
            action_logger.error("File system error during synchronization: %s", str(e))
            sys.exit(1)

        except ImportError as e:
            action_logger.error("Required module not found: %s", str(e))
            action_logger.error(
                "Make sure tlpytools and other dependencies are installed"
            )
            sys.exit(1)

    else:
        parser.error(f"Unknown action: {args.action}")


if __name__ == "__main__":
    main()
