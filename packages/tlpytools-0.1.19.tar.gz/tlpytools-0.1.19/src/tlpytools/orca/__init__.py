"""
ORCA Model Orchestration Module

This module provides tools for orchestrating ORCA model runs, including
initialization, execution, and data synchronization.

This module is optional and requires additional dependencies.
Install with: pip install tlpytools[orca]
"""

__all__ = ["OrcaOrchestrator", "OrcaUtil"]

# Import classes and add them to module namespace for proper lazy loading
# This ensures that 'from tlpytools.orca import OrcaUtil' works correctly
try:
    from .orchestrator import OrcaOrchestrator, OrcaUtil
except ImportError:
    # Create placeholder classes if dependencies are not installed
    class _MissingOrcaPlaceholder:
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "ORCA orchestrator functionality requires additional dependencies. "
                "Install with: pip install tlpytools[orca]"
            )

    OrcaOrchestrator = _MissingOrcaPlaceholder
    OrcaUtil = _MissingOrcaPlaceholder


def __getattr__(name):
    """Implement lazy importing to avoid loading orchestrator on package import."""
    if name == "OrcaOrchestrator":
        return OrcaOrchestrator
    elif name == "OrcaUtil":
        return OrcaUtil
    else:
        raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
