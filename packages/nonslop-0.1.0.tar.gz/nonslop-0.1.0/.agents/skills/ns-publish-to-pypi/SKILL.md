---
name: ns-publish-to-pypi
description: "Publish the package to PyPI. Use when the user wants to publish, release to PyPI, or push a new version. Handles build validation, artifact creation, and upload."
allowed-tools:
  - "Bash(git *)"
  - "Bash(uv build*)"
  - "Bash(uvx uv-publish*)"
  - "Bash(ls dist/*)"
---

# ns-publish-to-pypi

Publish the current package version to PyPI. Assumes version bumping and
changelog updates have already been done.

## Workflow

### Step 1: Validate preconditions

1. Confirm `pyproject.toml` exists in the repo root.
2. Check the git working directory is clean:

   ```bash
   git status --porcelain
   ```

   If there is any output, **stop** and tell the user to commit or stash
   their changes first.

3. Read the version from `pyproject.toml` (the `version = "..."` line).

4. **Ask the user to confirm** before proceeding:
   > Publishing **{package-name} {version}** to PyPI. Continue?

### Step 2: Build

1. Build the package:

   ```bash
   uv build
   ```

2. Verify artifacts were created:

   ```bash
   ls dist/
   ```

   Expect both a `.whl` and a `.tar.gz` file for the current version.
   If either is missing, **stop** and report the error.

### Step 3: Publish

1. Upload to PyPI:

   ```bash
   uvx uv-publish
   ```

2. Report success:
   > Published **{package-name} {version}** to PyPI.
