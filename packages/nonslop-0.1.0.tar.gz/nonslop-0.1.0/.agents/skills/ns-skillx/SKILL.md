---
name: ns-skillx
description: "Run any skill from a GitHub repo without installing it. Like npx for skills -- fetches into a temp dir, reads the SKILL.md, follows its instructions, then discards. No project pollution. Accepts: owner/repo@skill, GitHub URLs, --skill syntax, or natural language."
allowed-tools:
  - "Bash(gh api repos/*)"
  - "Bash(mktemp *)"
  - "Bash(cd /tmp/skillx.* && npx skills *)"
  - "Bash(ls /tmp/skillx.*)"
  - "Bash(rm -rf /tmp/skillx.*)"
---

# skillx

Run any skill from a GitHub repo without installing it into your project.
Like `npx` for packages -- fetch, use, discard. Zero project pollution.

## When to use

Use skillx when the user wants to **use** a skill from a GitHub repo
without permanently adding it to this project. Typical triggers:

- `skillx owner/repo@skill-name`
- `skillx https://github.com/owner/repo/blob/master/skills/skill-name`
- `skillx owner/repo --skill skill-name`
- "use the X skill from owner/repo without installing it"

Do NOT use skillx when the user wants to permanently install a skill --
use `ns-skill-management` for that.

## Step 1: Parse the request

Extract **repo** (`owner/repo`) and **skill name** from the user's input.
All of these forms are equivalent:

| Input format     | Example                                                                              | Extraction                                                                                                                                        |
| ---------------- | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| GitHub URL       | `https://github.com/nseng-ai/nonslop/blob/master/skills/ns-create-pypackage-project` | Strip `https://github.com/`, repo = first two path segments (`nseng-ai/nonslop`), skill = segment after `skills/` (`ns-create-pypackage-project`) |
| `@` syntax       | `nseng-ai/nonslop@ns-create-pypackage-project`                                       | Split on `@`: repo = left, skill = right                                                                                                          |
| `--skill` syntax | `nseng-ai/nonslop --skill ns-create-pypackage-project`                               | repo = first arg, skill = value after `--skill`                                                                                                   |
| Natural language | `skill ns-create-pypackage-project in nseng-ai/nonslop`                              | Extract the `owner/repo` pattern and the skill name from context                                                                                  |

All forms normalize to two values:

- **repo**: `owner/repo` (required)
- **skill**: skill name (optional -- omit if not specified)

Also extract the **task**: whatever the user actually wants done with the
skill (the rest of their message beyond the skillx invocation).

## Step 2: Preview the skill

Use `gh api` to read the SKILL.md and list the skill directory before
fetching anything. This works for private repos (uses `gh` auth), is
read-only, and catches bad paths early.

**Read the SKILL.md:**

```bash
gh api repos/<owner>/<repo>/contents/skills/<skill-name>/SKILL.md --jq '.content' | base64 -d
```

**List the skill directory contents:**

```bash
gh api repos/<owner>/<repo>/contents/skills/<skill-name> --jq '.[].name'
```

If the skill name was NOT specified, list available skills instead:

```bash
gh api repos/<owner>/<repo>/contents/skills --jq '.[].name'
```

- If the API returns 404, report "skill not found" and stop
- If the API returns an auth error, report "cannot access repo --
  check `gh auth status`" and stop
- Use the previewed SKILL.md to understand what the skill does, what
  templates/references it has, and what preconditions it requires
- This enables planning and precondition-checking before any write
  operations

## Step 3: Create a temp directory

```bash
SKILLX_TMP=$(mktemp -d /tmp/skillx.XXXXXX) && echo "$SKILLX_TMP"
```

Save the returned path for all subsequent steps.

## Step 4: Fetch the skill

**If skill name was specified:**

```bash
cd <SKILLX_TMP> && npx skills add <repo> --skill <skill-name> --agent codex -y
```

**If skill name was NOT specified:**

Install all skills from the repo:

```bash
cd <SKILLX_TMP> && npx skills add <repo> --agent codex -y
```

Then check what got installed:

```bash
ls <SKILLX_TMP>/.agents/skills/
```

- **One skill**: proceed with it.
- **Multiple skills**: list them to the user and ask which one to use.
- **Zero skills**: report the error, clean up, stop.

If `npx skills add` fails (bad repo, network error, etc.): report
the error, clean up the temp dir, stop.

## Step 5: Read the SKILL.md

Read the fetched skill:

```
<SKILLX_TMP>/.agents/skills/<skill-name>/SKILL.md
```

Use the Read tool with the absolute path.

## Step 6: Follow the fetched skill's instructions

Act as if the fetched SKILL.md is your active skill for this turn.
Follow its instructions to accomplish the user's task.

**Relative path resolution.** If the fetched SKILL.md references
relative paths (like `references/patterns.md` or `scripts/setup.sh`),
resolve them relative to:

```
<SKILLX_TMP>/.agents/skills/<skill-name>/
```

These files were downloaded alongside the SKILL.md.

**Work in the real project.** The skill's instructions apply to the
user's actual project (the current working directory), NOT to the temp
directory. The temp directory is only for reading the skill's definition
and reference files.

**Tool permissions.** The fetched skill's `allowed-tools` are NOT
automatically granted. The user will see normal permission prompts for
any commands the fetched skill asks you to run. This is correct --
you should not auto-approve tools from a remote skill.

## Step 7: Clean up

After the skill's work is complete (or if any step fails):

```bash
rm -rf <SKILLX_TMP>
```

## Error handling

| Situation                         | Action                                                      |
| --------------------------------- | ----------------------------------------------------------- |
| `gh api` 404 on skill path        | Report "skill not found at `skills/<name>` in repo", stop   |
| `gh api` auth failure             | Report "cannot access repo -- check `gh auth status`", stop |
| Bad repo (404, typo)              | Report error, clean up, stop                                |
| Network failure                   | Report error, clean up, stop                                |
| Repo has no skills                | Report "no skills found in repo", clean up, stop            |
| Multiple skills, none specified   | List available skills, ask user to pick                     |
| SKILL.md unreadable               | Report error, clean up, stop                                |
| Fetched skill fails mid-execution | Complete what you can, then clean up                        |

## What skillx does NOT do

- Does NOT modify `skills-lock.json` in the real project
- Does NOT create symlinks in `.agents/skills/` or `.claude/skills/`
- Does NOT add entries to `AGENTS.md`
- Does NOT cache anything -- every invocation is a fresh fetch
