#!/usr/bin/env python3
"""Sync the dignified-python skill from dagster-io/skills into this repo.

After running this script, run the LLM cleanup step to strip Dagster-specific references:
    cat scripts/clean_dagster_refs.md | claude -p
"""

import shutil
import subprocess
import tempfile
from pathlib import Path

UPSTREAM_REPO = "https://github.com/dagster-io/skills.git"
UPSTREAM_SKILL_PATH = "skills/dignified-python/skills/dignified-python"
LOCAL_SKILL_PATH = "skills/ns-dignified-python"


def main() -> None:
    repo_root = Path(__file__).resolve().parent.parent
    dest = repo_root / LOCAL_SKILL_PATH

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        print(f"Shallow-cloning {UPSTREAM_REPO} ...")
        subprocess.run(
            ["git", "clone", "--depth=1", UPSTREAM_REPO, str(tmp_path / "repo")],
            check=True,
        )

        source = tmp_path / "repo" / UPSTREAM_SKILL_PATH
        if not source.exists():
            raise SystemExit(f"Upstream path not found: {source}")

        # Wipe existing skill dir and copy fresh
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(source, dest)

    print(f"\nSynced {LOCAL_SKILL_PATH}/ from upstream.")
    print("\nNext step — run the LLM cleanup to strip Dagster references:")
    print("    cat scripts/clean_dagster_refs.md | claude -p")


if __name__ == "__main__":
    main()
