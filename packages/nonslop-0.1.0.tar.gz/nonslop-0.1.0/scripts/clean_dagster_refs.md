Scan every `.md` file under `skills/dignified-python/` for any mention of "dagster" (case-insensitive). For each match, remove the Dagster-specific content while preserving all general Python guidance. Specifically:

- **Cross-references** to other dagster skills (`/dagster-best-practices`, `/dg`, `/dagster-expert`) — remove the entire row, bullet, paragraph, or section that exists only to route users to those skills.
- **Scope disclaimers** like "not Dagster-specific" or "general Python standards, not Dagster-specific" — remove. These are redundant outside the dagster-io repo.
- **Attribution** like "production-tested patterns from Dagster Labs" — remove.
- **Routing/comparison tables** that compare this skill to dagster-specific skills — remove the dagster rows. If removing rows leaves a table with only one row or makes it pointless, remove the entire table.
- **Sections** that exist solely to distinguish this skill from dagster-specific ones (e.g., "Related Skills" sections listing only dagster skills, "Cross-Skill Usage" sections) — remove the entire section.

Rules:

- Do NOT remove general Python content. Only remove content that is specifically about Dagster, references Dagster skills, or exists to position this skill relative to Dagster.
- If a sentence mixes general content with a Dagster reference, rewrite the sentence to keep the general part and drop the Dagster part.
- After all edits, verify with `grep -ri dagster skills/dignified-python/` that zero matches remain.
