# nonslop

AI-native project scaffolding.

## The idea

The new way to bootstrap projects is **skills**. Instead of language-specific scaffolding tools, you start with a skills-ready project and compose what you need. Skills are universal -- they work across any project, any language, and any AI coding agent.

## Quick start

```bash
uvx nonslop create-project my-project
```

This creates an empty project with skill infrastructure pre-wired. It also preinstalls two skills:

- **nonslop-skill-management** -- manage persistent skills with `npx skills`
- **skillx** -- invoke any skill ephemerally from a GitHub repo, like `npx` for skills

## Example: creating a Python project

From your new project, invoke `skillx` to scaffold a Python package:

In **Claude Code**:

```
/skillx nseng-ai/nonslop-python@create-pypackage-project
```

In **Codex**:

```
$skillx nseng-ai/nonslop-python@create-pypackage-project
```

The skill is fetched, executed, and discarded -- your project gets the Python scaffolding without permanently installing anything.

## What you get

After `create-project`, your project has:

```
my-project/
├── skills/                 # local skills (first-party code)
├── .agents/skills/         # universal agent skill directory
├── .claude/                # Claude Code configuration
├── AGENTS.md               # skill registry for agents
├── CLAUDE.md               # project instructions
└── skills-lock.json        # installed skill metadata
```

## Development

```bash
uv sync
just check
```
