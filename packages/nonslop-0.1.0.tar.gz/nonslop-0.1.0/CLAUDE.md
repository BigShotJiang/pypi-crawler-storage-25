# nonslop

Skills management framework for AI coding agents.

## Agents

@AGENTS.md
