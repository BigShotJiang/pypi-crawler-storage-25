from __future__ import annotations

import click

from nonslop.check import check_cmd
from nonslop.create_project import create_project


@click.group()
def main() -> None:
    """nonslop CLI."""


main.add_command(create_project)
main.add_command(check_cmd)

if __name__ == "__main__":
    main()
