# Skills

A skill is a set of local instructions to follow that is stored in a `SKILL.md` file. Below is the list of skills that can be used. Each entry includes a name, description, and file path so you can open the source for full instructions when using a specific skill.

### Skill Directory Layout

- **`skills/`** contains all locally-authored skills as real directories. This is first-party code -- apply normal linting, typechecking, and code-review standards here. Edit files under `skills/<name>/` directly.
- **`.agents/skills/`** is the universal agent directory. It contains:
  - Symlinks to `../../skills/<name>` for each local skill
  - Real directories of vendored third-party code for GitHub-sourced skills
- **`.claude/skills/`** contains symlinks into `.agents/skills/` for Claude Code. Do not modify these directly.
- For vendored (GitHub-sourced) skills, do not apply first-party coding standards or refactoring to files under `.agents/skills/<name>/` unless the user explicitly asks to modify the vendored dependency itself. Exclude `.agents/skills/` from normal linting, typechecking, and code-review expectations.

### Available skills

- ns-skill-management: Manage nonslop skills with `npx skills`. Use whenever you need to add a new skill (local or from GitHub), edit an existing skill, remove one, update GitHub-sourced skills, inspect what's installed, or publish skills. Documents the canonical `--agent codex claude-code -y` install flag and the convention of `skills/<name>/` as the canonical source for local skills. (file: .agents/skills/ns-skill-management/SKILL.md)
- ns-skillx: Run any skill from a GitHub repo without installing it. Like npx for skills -- fetch, use, discard. Accepts GitHub URLs, owner/repo@skill, or natural language. (file: .agents/skills/ns-skillx/SKILL.md)

### How to use skills

- Discovery: The list above is the skills available in this repo for Codex sessions. Skill bodies live on disk at the listed paths.
- Trigger rules: If the user names a skill (with `$SkillName` or plain text) OR the task clearly matches a skill's description shown above, you must use that skill for that turn. Multiple mentions mean use them all. Do not carry skills across turns unless re-mentioned.
- Missing/blocked: If a named skill isn't in the list or the path can't be read, say so briefly and continue with the best fallback.
- How to use a skill (progressive disclosure):
  1. After deciding to use a skill, open its `SKILL.md`. Read only enough to follow the workflow.
  2. When `SKILL.md` references relative paths, resolve them relative to the skill directory first.
  3. If `SKILL.md` points to extra folders such as `references/`, load only the specific files needed for the request; don't bulk-load everything.
  4. If `scripts/` exist, prefer running or patching them instead of retyping large code blocks.
  5. If `assets/` or templates exist, reuse them instead of recreating from scratch.
- Coordination and sequencing:
  - If multiple skills apply, choose the minimal set that covers the request and state the order you'll use them.
  - Announce which skill(s) you're using and why in one short line.
  - If you skip an obvious skill, say why.
- Context hygiene:
  - Keep context small: summarize long sections instead of pasting them; only load extra files when needed.
  - Avoid deep reference-chasing: prefer opening only files directly linked from `SKILL.md` unless you're blocked.
  - When variants exist, pick only the relevant reference file(s) and note that choice.
- Safety and fallback: If a skill can't be applied cleanly, state the issue, pick the next-best approach, and continue.

### Managing Skills With `npx skills`

All skill-management procedures -- adding, editing, removing, updating, listing, and publishing skills -- are documented in the `ns-skill-management` skill at `.agents/skills/ns-skill-management/SKILL.md`. Use that skill whenever you need to install or modify skills rather than running `npx skills` commands freehand. The canonical nonslop install flag is `--agent codex claude-code -y`. Local skills live as real directories under `skills/<name>/`; `.agents/skills/<name>` is a symlink to them for universal agent discovery.
