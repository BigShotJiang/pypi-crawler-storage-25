from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import click

_SKILL_NAME_RE = re.compile(r"^- ([a-zA-Z0-9][a-zA-Z0-9._-]*):")


class IssueKind(Enum):
    # Local skill checks
    MISSING_SKILLS_DIR = "missing_skills_dir"
    SKILLS_DIR_IS_SYMLINK = "skills_dir_is_symlink"
    AGENTS_NOT_SYMLINK = "agents_not_symlink"
    AGENTS_WRONG_TARGET = "agents_wrong_target"
    AGENTS_MISSING = "agents_missing"
    CLAUDE_NOT_SYMLINK = "claude_not_symlink"
    CLAUDE_WRONG_TARGET = "claude_wrong_target"
    CLAUDE_MISSING = "claude_missing"
    NOT_IN_AGENTS_MD = "not_in_agents_md"

    # GitHub skill checks
    AGENTS_NOT_REAL_DIR = "agents_not_real_dir"
    UNEXPECTED_SKILLS_DIR = "unexpected_skills_dir"

    # Cross-cutting
    ORPHAN_IN_SKILLS = "orphan_in_skills"
    ORPHAN_IN_AGENTS = "orphan_in_agents"
    DANGLING_LOCKFILE = "dangling_lockfile"


@dataclass(frozen=True)
class SkillIssue:
    skill_name: str
    kind: IssueKind
    message: str


@dataclass
class CheckResult:
    issues: list[SkillIssue] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return len(self.issues) == 0


def _read_lockfile(project_dir: Path) -> dict[str, dict]:
    lockfile = project_dir / "skills-lock.json"
    if not lockfile.is_file():
        raise click.ClickException(
            f"skills-lock.json not found in {project_dir}. Is this a nonslop project?"
        )
    try:
        data = json.loads(lockfile.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Invalid JSON in skills-lock.json: {e}") from e
    return data.get("skills", {})


def _read_agents_md_skills(project_dir: Path) -> set[str]:
    agents_md = project_dir / "AGENTS.md"
    if not agents_md.is_file():
        return set()

    text = agents_md.read_text(encoding="utf-8")
    in_section = False
    names: set[str] = set()
    for line in text.splitlines():
        if line.strip().startswith("### Available skills"):
            in_section = True
            continue
        if in_section and line.strip().startswith("###"):
            break
        if in_section:
            m = _SKILL_NAME_RE.match(line)
            if m:
                names.add(m.group(1))
    return names


def _check_local_skill(
    name: str, project_dir: Path, agents_md_skills: set[str]
) -> list[SkillIssue]:
    issues: list[SkillIssue] = []
    skills_path = project_dir / "skills" / name
    agents_path = project_dir / ".agents" / "skills" / name
    claude_path = project_dir / ".claude" / "skills" / name

    # 1. skills/<name>/ must be a real directory (not a symlink)
    if not skills_path.exists():
        issues.append(
            SkillIssue(
                name,
                IssueKind.MISSING_SKILLS_DIR,
                f"Local skill missing canonical source: skills/{name}/ does not exist",
            )
        )
    elif skills_path.is_symlink():
        issues.append(
            SkillIssue(
                name,
                IssueKind.SKILLS_DIR_IS_SYMLINK,
                f"skills/{name} is a symlink but should be a real directory (canonical source)",
            )
        )

    # 2. .agents/skills/<name> must be a symlink to ../../skills/<name>
    expected_agents_target = f"../../skills/{name}"
    if not agents_path.exists() and not agents_path.is_symlink():
        issues.append(
            SkillIssue(
                name,
                IssueKind.AGENTS_MISSING,
                f".agents/skills/{name} does not exist",
            )
        )
    elif not agents_path.is_symlink():
        issues.append(
            SkillIssue(
                name,
                IssueKind.AGENTS_NOT_SYMLINK,
                f".agents/skills/{name} is a real directory,"
                f" expected symlink to {expected_agents_target}",
            )
        )
    else:
        actual_target = os.readlink(agents_path)
        if actual_target != expected_agents_target:
            issues.append(
                SkillIssue(
                    name,
                    IssueKind.AGENTS_WRONG_TARGET,
                    f".agents/skills/{name} symlink points to {actual_target}, "
                    f"expected {expected_agents_target}",
                )
            )

    # 3. .claude/skills/<name> must be a symlink to ../../.agents/skills/<name>
    expected_claude_target = f"../../.agents/skills/{name}"
    if not claude_path.exists() and not claude_path.is_symlink():
        issues.append(
            SkillIssue(
                name,
                IssueKind.CLAUDE_MISSING,
                f".claude/skills/{name} does not exist",
            )
        )
    elif not claude_path.is_symlink():
        issues.append(
            SkillIssue(
                name,
                IssueKind.CLAUDE_NOT_SYMLINK,
                f".claude/skills/{name} is a real directory,"
                f" expected symlink to {expected_claude_target}",
            )
        )
    else:
        actual_target = os.readlink(claude_path)
        if actual_target != expected_claude_target:
            issues.append(
                SkillIssue(
                    name,
                    IssueKind.CLAUDE_WRONG_TARGET,
                    f".claude/skills/{name} symlink points to {actual_target}, "
                    f"expected {expected_claude_target}",
                )
            )

    # 4. Must be registered in AGENTS.md
    if name not in agents_md_skills:
        issues.append(
            SkillIssue(
                name,
                IssueKind.NOT_IN_AGENTS_MD,
                f"{name} is not registered in AGENTS.md Available skills section",
            )
        )

    return issues


def _check_github_skill(
    name: str, project_dir: Path, agents_md_skills: set[str]
) -> list[SkillIssue]:
    issues: list[SkillIssue] = []
    skills_path = project_dir / "skills" / name
    agents_path = project_dir / ".agents" / "skills" / name
    claude_path = project_dir / ".claude" / "skills" / name

    # 1. .agents/skills/<name>/ must be a real directory
    if not agents_path.exists():
        issues.append(
            SkillIssue(
                name,
                IssueKind.AGENTS_NOT_REAL_DIR,
                f".agents/skills/{name}/ does not exist",
            )
        )
    elif agents_path.is_symlink():
        issues.append(
            SkillIssue(
                name,
                IssueKind.AGENTS_NOT_REAL_DIR,
                f".agents/skills/{name} is a symlink but should be a real directory (vendored)",
            )
        )

    # 2. .claude/skills/<name> must be a symlink to ../../.agents/skills/<name>
    expected_claude_target = f"../../.agents/skills/{name}"
    if not claude_path.exists() and not claude_path.is_symlink():
        issues.append(
            SkillIssue(
                name,
                IssueKind.CLAUDE_MISSING,
                f".claude/skills/{name} does not exist",
            )
        )
    elif not claude_path.is_symlink():
        issues.append(
            SkillIssue(
                name,
                IssueKind.CLAUDE_NOT_SYMLINK,
                f".claude/skills/{name} is a real directory,"
                f" expected symlink to {expected_claude_target}",
            )
        )
    else:
        actual_target = os.readlink(claude_path)
        if actual_target != expected_claude_target:
            issues.append(
                SkillIssue(
                    name,
                    IssueKind.CLAUDE_WRONG_TARGET,
                    f".claude/skills/{name} symlink points to {actual_target}, "
                    f"expected {expected_claude_target}",
                )
            )

    # 3. Should NOT have a skills/<name> entry
    if skills_path.exists() or skills_path.is_symlink():
        issues.append(
            SkillIssue(
                name,
                IssueKind.UNEXPECTED_SKILLS_DIR,
                f"GitHub-sourced skill should not have skills/{name}/ entry",
            )
        )

    # 4. Must be registered in AGENTS.md
    if name not in agents_md_skills:
        issues.append(
            SkillIssue(
                name,
                IssueKind.NOT_IN_AGENTS_MD,
                f"{name} is not registered in AGENTS.md Available skills section",
            )
        )

    return issues


def _list_subdirs(path: Path) -> set[str]:
    if not path.is_dir():
        return set()
    return {p.name for p in path.iterdir() if p.name != ".DS_Store"}


def _check_orphans(lockfile_skills: dict[str, dict], project_dir: Path) -> list[SkillIssue]:
    issues: list[SkillIssue] = []
    lock_names = set(lockfile_skills.keys())

    # Orphaned dirs in skills/
    for name in sorted(_list_subdirs(project_dir / "skills") - lock_names):
        issues.append(
            SkillIssue(
                name,
                IssueKind.ORPHAN_IN_SKILLS,
                f"Orphaned directory skills/{name}/ has no entry in skills-lock.json",
            )
        )

    # Orphaned dirs in .agents/skills/
    for name in sorted(_list_subdirs(project_dir / ".agents" / "skills") - lock_names):
        issues.append(
            SkillIssue(
                name,
                IssueKind.ORPHAN_IN_AGENTS,
                f"Orphaned directory .agents/skills/{name}/ has no entry in skills-lock.json",
            )
        )

    # Dangling lockfile entries (no presence on disk at all)
    for name in sorted(lock_names):
        skills_exists = (project_dir / "skills" / name).exists() or (
            project_dir / "skills" / name
        ).is_symlink()
        agents_exists = (project_dir / ".agents" / "skills" / name).exists() or (
            project_dir / ".agents" / "skills" / name
        ).is_symlink()
        claude_exists = (project_dir / ".claude" / "skills" / name).exists() or (
            project_dir / ".claude" / "skills" / name
        ).is_symlink()
        if not skills_exists and not agents_exists and not claude_exists:
            issues.append(
                SkillIssue(
                    name,
                    IssueKind.DANGLING_LOCKFILE,
                    f"Dangling lockfile entry: no directories found on disk for {name}",
                )
            )

    return issues


def check_project(project_dir: Path) -> CheckResult:
    lockfile_skills = _read_lockfile(project_dir)
    agents_md_skills = _read_agents_md_skills(project_dir)
    result = CheckResult()

    for name, meta in sorted(lockfile_skills.items()):
        source_type = meta.get("sourceType", "")
        if source_type == "local":
            result.issues.extend(_check_local_skill(name, project_dir, agents_md_skills))
        elif source_type in ("github", "git", "gitlab"):
            result.issues.extend(_check_github_skill(name, project_dir, agents_md_skills))

    result.issues.extend(_check_orphans(lockfile_skills, project_dir))
    return result


def _format_result(result: CheckResult) -> None:
    if result.ok:
        click.echo("All skills OK.")
        return

    by_skill: dict[str, list[SkillIssue]] = {}
    for issue in result.issues:
        by_skill.setdefault(issue.skill_name, []).append(issue)

    for skill_name, issues in sorted(by_skill.items()):
        click.echo(f"\n{skill_name}:")
        for issue in issues:
            click.echo(f"  {issue.message}")

    click.echo(f"\n{len(result.issues)} error(s)")


@click.command("check")
@click.option(
    "--path",
    type=click.Path(exists=True, file_okay=False, resolve_path=True),
    default=".",
    help="Project directory to check (default: current directory).",
)
def check_cmd(path: str) -> None:
    """Check that skills follow nonslop conventions."""
    project_dir = Path(path)
    result = check_project(project_dir)
    _format_result(result)
    if not result.ok:
        raise SystemExit(1)
