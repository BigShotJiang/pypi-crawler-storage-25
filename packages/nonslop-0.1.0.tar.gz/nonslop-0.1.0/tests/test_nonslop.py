from __future__ import annotations

import importlib.metadata

from click.testing import CliRunner

from nonslop.cli import main


def test_version_exists() -> None:
    """The package is importable and has a version in its metadata."""
    metadata = importlib.metadata.metadata("nonslop")
    assert metadata["Name"] == "nonslop"
    assert metadata["Version"] is not None


def test_cli_help() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
