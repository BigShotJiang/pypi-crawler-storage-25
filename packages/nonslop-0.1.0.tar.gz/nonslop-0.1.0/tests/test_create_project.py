from __future__ import annotations

import json
import subprocess
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from nonslop.cli import main


@pytest.fixture
def runner():
    return CliRunner()


@contextmanager
def fake_npx():
    """Patch shutil.which and subprocess.run to simulate `npx skills add`."""

    def side_effect(cmd, *, cwd, check):
        cwd = Path(cwd)
        for name in ("ns-skill-management", "ns-skillx"):
            skill_dir = cwd / ".agents" / "skills" / name
            skill_dir.mkdir(parents=True)
            (skill_dir / "SKILL.md").write_text(f"---\nname: {name}\n---\n")

        claude_skills = cwd / ".claude" / "skills"
        claude_skills.mkdir(parents=True)
        for name in ("ns-skill-management", "ns-skillx"):
            (claude_skills / name).symlink_to(Path("../../.agents/skills") / name)

        lock = {
            "version": 1,
            "skills": {
                "ns-skill-management": {
                    "source": "nseng-ai/nonslop",
                    "sourceType": "github",
                    "computedHash": "abc123",
                },
                "ns-skillx": {
                    "source": "nseng-ai/nonslop",
                    "sourceType": "github",
                    "computedHash": "def456",
                },
            },
        }
        (cwd / "skills-lock.json").write_text(json.dumps(lock, indent=2))
        return subprocess.CompletedProcess(cmd, 0)

    with (
        patch("nonslop.create_project.shutil.which", return_value="/usr/bin/npx"),
        patch("nonslop.create_project.subprocess.run", side_effect=side_effect) as mock_run,
    ):
        yield mock_run


class TestCreateProjectHappyPath:
    def test_creates_expected_structure(self, runner, tmp_path):
        with fake_npx():
            result = runner.invoke(main, ["create-project", "myapp", "--path", str(tmp_path)])

        assert result.exit_code == 0, result.output
        project = tmp_path / "myapp"

        # Directories exist
        assert (project / ".agents" / "skills" / "ns-skill-management").is_dir()
        assert (project / ".agents" / "skills" / "ns-skillx").is_dir()

        # Claude symlinks exist and resolve
        assert (project / ".claude" / "skills" / "ns-skill-management").is_symlink()
        assert (project / ".claude" / "skills" / "ns-skillx").is_symlink()

        # Generated files
        assert (project / "AGENTS.md").is_file()
        assert (project / "CLAUDE.md").is_file()
        assert (project / ".gitignore").is_file()
        assert (project / ".claude" / "settings.local.json").is_file()
        assert (project / "skills-lock.json").is_file()
        assert (project / "nonslop.json").is_file()

    def test_agents_md_content(self, runner, tmp_path):
        with fake_npx():
            runner.invoke(main, ["create-project", "myapp", "--path", str(tmp_path)])

        content = (tmp_path / "myapp" / "AGENTS.md").read_text()
        assert "ns-skill-management" in content
        assert "ns-skillx" in content
        assert "Skill Directory Layout" in content
        assert "Available skills" in content

    def test_claude_md_has_project_name(self, runner, tmp_path):
        with fake_npx():
            runner.invoke(main, ["create-project", "myapp", "--path", str(tmp_path)])

        content = (tmp_path / "myapp" / "CLAUDE.md").read_text()
        assert "# myapp" in content
        assert "@AGENTS.md" in content

    def test_nonslop_json_default_agents(self, runner, tmp_path):
        with fake_npx():
            runner.invoke(main, ["create-project", "myapp", "--path", str(tmp_path)])

        config = json.loads((tmp_path / "myapp" / "nonslop.json").read_text())
        assert config["agents"] == ["codex", "claude-code"]

    def test_nonslop_json_custom_agents(self, runner, tmp_path):
        with fake_npx():
            runner.invoke(
                main,
                [
                    "create-project",
                    "myapp",
                    "--path",
                    str(tmp_path),
                    "--agent",
                    "codex",
                    "--agent",
                    "windsurf",
                ],
            )

        config = json.loads((tmp_path / "myapp" / "nonslop.json").read_text())
        assert config["agents"] == ["codex", "windsurf"]

    def test_settings_local_json(self, runner, tmp_path):
        with fake_npx():
            runner.invoke(main, ["create-project", "myapp", "--path", str(tmp_path)])

        settings = json.loads((tmp_path / "myapp" / ".claude" / "settings.local.json").read_text())
        assert "Bash(npx skills:*)" in settings["permissions"]["allow"]


class TestNpxInvocation:
    def test_default_agents(self, runner, tmp_path):
        with fake_npx() as mock_run:
            runner.invoke(main, ["create-project", "myapp", "--path", str(tmp_path)])

        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert cmd == [
            "npx",
            "skills",
            "add",
            "nseng-ai/nonslop",
            "--skill",
            "ns-skill-management",
            "ns-skillx",
            "--agent",
            "codex",
            "claude-code",
            "-y",
        ]

    def test_custom_agents(self, runner, tmp_path):
        with fake_npx() as mock_run:
            runner.invoke(
                main,
                [
                    "create-project",
                    "myapp",
                    "--path",
                    str(tmp_path),
                    "--agent",
                    "codex",
                    "--agent",
                    "windsurf",
                ],
            )

        cmd = mock_run.call_args[0][0]
        agent_idx = cmd.index("--agent")
        y_idx = cmd.index("-y")
        assert cmd[agent_idx + 1 : y_idx] == ["codex", "windsurf"]


class TestPathOption:
    def test_creates_in_specified_parent(self, runner, tmp_path):
        parent = tmp_path / "subdir"
        parent.mkdir()
        with fake_npx():
            result = runner.invoke(main, ["create-project", "myapp", "--path", str(parent)])

        assert result.exit_code == 0
        assert (parent / "myapp" / "AGENTS.md").is_file()


class TestValidation:
    def test_already_exists(self, runner, tmp_path):
        (tmp_path / "myapp").mkdir()
        with patch("nonslop.create_project.shutil.which", return_value="/usr/bin/npx"):
            result = runner.invoke(main, ["create-project", "myapp", "--path", str(tmp_path)])

        assert result.exit_code != 0
        assert "already exists" in result.output

    @pytest.mark.parametrize("name", ["../foo", ".hidden", "has space", "a/b"])
    def test_invalid_name(self, runner, tmp_path, name):
        with patch("nonslop.create_project.shutil.which", return_value="/usr/bin/npx"):
            result = runner.invoke(main, ["create-project", name, "--path", str(tmp_path)])

        assert result.exit_code != 0
        assert "Invalid project name" in result.output

    def test_npx_not_found(self, runner, tmp_path):
        with patch("nonslop.create_project.shutil.which", return_value=None):
            result = runner.invoke(main, ["create-project", "myapp", "--path", str(tmp_path)])

        assert result.exit_code != 0
        assert "npx" in result.output

    def test_nonexistent_parent(self, runner, tmp_path):
        with patch("nonslop.create_project.shutil.which", return_value="/usr/bin/npx"):
            result = runner.invoke(
                main, ["create-project", "myapp", "--path", str(tmp_path / "nope")]
            )

        assert result.exit_code != 0
        assert "does not exist" in result.output


class TestCleanupOnFailure:
    def test_removes_dir_on_npx_failure(self, runner, tmp_path):
        def failing_npx(cmd, *, cwd, check):
            raise subprocess.CalledProcessError(1, cmd)

        with (
            patch("nonslop.create_project.shutil.which", return_value="/usr/bin/npx"),
            patch("nonslop.create_project.subprocess.run", side_effect=failing_npx),
        ):
            result = runner.invoke(main, ["create-project", "myapp", "--path", str(tmp_path)])

        assert result.exit_code != 0
        assert not (tmp_path / "myapp").exists()
