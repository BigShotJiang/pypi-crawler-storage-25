from __future__ import annotations

import json
from pathlib import Path

from click.testing import CliRunner

from nonslop.cli import main

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_lockfile(project: Path, skills: dict) -> None:
    (project / "skills-lock.json").write_text(
        json.dumps({"version": 1, "skills": skills}, indent=2)
    )


def _make_agents_md(project: Path, skill_names: list[str]) -> None:
    lines = [
        "# Skills\n",
        "### Available skills\n",
    ]
    for name in skill_names:
        lines.append(f"- {name}: Description (file: .agents/skills/{name}/SKILL.md)\n")
    lines.append("\n### How to use skills\n")
    (project / "AGENTS.md").write_text("\n".join(lines))


def _make_local_skill(project: Path, name: str) -> None:
    """Create a properly-structured local skill with correct symlink chain."""
    skill_dir = project / "skills" / name
    skill_dir.mkdir(parents=True, exist_ok=True)
    (skill_dir / "SKILL.md").write_text(f"---\nname: {name}\n---\n")

    agents_dir = project / ".agents" / "skills"
    agents_dir.mkdir(parents=True, exist_ok=True)
    (agents_dir / name).symlink_to(Path("../../skills") / name)

    claude_dir = project / ".claude" / "skills"
    claude_dir.mkdir(parents=True, exist_ok=True)
    (claude_dir / name).symlink_to(Path("../../.agents/skills") / name)


def _make_github_skill(project: Path, name: str) -> None:
    """Create a properly-structured GitHub-sourced skill."""
    agents_dir = project / ".agents" / "skills" / name
    agents_dir.mkdir(parents=True, exist_ok=True)
    (agents_dir / "SKILL.md").write_text(f"---\nname: {name}\n---\n")

    claude_dir = project / ".claude" / "skills"
    claude_dir.mkdir(parents=True, exist_ok=True)
    (claude_dir / name).symlink_to(Path("../../.agents/skills") / name)


def _local_lock_entry(name: str) -> dict:
    return {"source": f"skills/{name}", "sourceType": "local", "computedHash": "abc123"}


def _github_lock_entry(owner_repo: str) -> dict:
    return {"source": owner_repo, "sourceType": "github", "computedHash": "def456"}


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


def test_check_happy_local_skill(tmp_path: Path) -> None:
    _make_local_skill(tmp_path, "my-skill")
    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(tmp_path, ["my-skill"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 0
    assert "All skills OK" in result.output


def test_check_happy_github_skill(tmp_path: Path) -> None:
    _make_github_skill(tmp_path, "dignified-python")
    _make_lockfile(tmp_path, {"dignified-python": _github_lock_entry("nseng-ai/nonslop")})
    _make_agents_md(tmp_path, ["dignified-python"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 0
    assert "All skills OK" in result.output


def test_check_happy_mixed(tmp_path: Path) -> None:
    _make_local_skill(tmp_path, "my-local")
    _make_github_skill(tmp_path, "my-remote")
    _make_lockfile(
        tmp_path,
        {
            "my-local": _local_lock_entry("my-local"),
            "my-remote": _github_lock_entry("org/repo"),
        },
    )
    _make_agents_md(tmp_path, ["my-local", "my-remote"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 0


def test_check_happy_empty_lockfile(tmp_path: Path) -> None:
    _make_lockfile(tmp_path, {})
    _make_agents_md(tmp_path, [])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 0
    assert "All skills OK" in result.output


# ---------------------------------------------------------------------------
# Local skill issues
# ---------------------------------------------------------------------------


def test_check_local_missing_skills_dir(tmp_path: Path) -> None:
    # Set up .agents and .claude but no skills/<name>
    agents_dir = tmp_path / ".agents" / "skills"
    agents_dir.mkdir(parents=True)
    # Can't make a valid symlink without the target, so make a real dir
    (agents_dir / "my-skill").mkdir()
    (agents_dir / "my-skill" / "SKILL.md").write_text("---\nname: my-skill\n---\n")
    claude_dir = tmp_path / ".claude" / "skills"
    claude_dir.mkdir(parents=True)
    (claude_dir / "my-skill").symlink_to(Path("../../.agents/skills/my-skill"))

    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(tmp_path, ["my-skill"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "skills/my-skill/ does not exist" in result.output


def test_check_local_skills_dir_is_symlink(tmp_path: Path) -> None:
    """The backwards case: skills/<name> is a symlink into .agents/skills/."""
    agents_dir = tmp_path / ".agents" / "skills" / "my-skill"
    agents_dir.mkdir(parents=True)
    (agents_dir / "SKILL.md").write_text("---\nname: my-skill\n---\n")

    skills_dir = tmp_path / "skills"
    skills_dir.mkdir(parents=True)
    (skills_dir / "my-skill").symlink_to(Path("../.agents/skills/my-skill"))

    claude_dir = tmp_path / ".claude" / "skills"
    claude_dir.mkdir(parents=True)
    (claude_dir / "my-skill").symlink_to(Path("../../.agents/skills/my-skill"))

    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(tmp_path, ["my-skill"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "symlink but should be a real directory" in result.output


def test_check_local_agents_not_symlink(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "my-skill"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("---\nname: my-skill\n---\n")

    # .agents/skills/<name> is a real dir instead of symlink
    agents_dir = tmp_path / ".agents" / "skills" / "my-skill"
    agents_dir.mkdir(parents=True)
    (agents_dir / "SKILL.md").write_text("---\nname: my-skill\n---\n")

    claude_dir = tmp_path / ".claude" / "skills"
    claude_dir.mkdir(parents=True)
    (claude_dir / "my-skill").symlink_to(Path("../../.agents/skills/my-skill"))

    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(tmp_path, ["my-skill"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "is a real directory, expected symlink" in result.output


def test_check_local_agents_wrong_target(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "my-skill"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("---\nname: my-skill\n---\n")

    agents_dir = tmp_path / ".agents" / "skills"
    agents_dir.mkdir(parents=True)
    # Symlink points to wrong target
    (agents_dir / "my-skill").symlink_to(Path("../../wrong/my-skill"))

    claude_dir = tmp_path / ".claude" / "skills"
    claude_dir.mkdir(parents=True)
    (claude_dir / "my-skill").symlink_to(Path("../../.agents/skills/my-skill"))

    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(tmp_path, ["my-skill"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "symlink points to ../../wrong/my-skill" in result.output


def test_check_local_claude_not_symlink(tmp_path: Path) -> None:
    _make_local_skill(tmp_path, "my-skill")
    # Replace claude symlink with a real dir
    claude_path = tmp_path / ".claude" / "skills" / "my-skill"
    claude_path.unlink()
    claude_path.mkdir()
    (claude_path / "SKILL.md").write_text("---\nname: my-skill\n---\n")

    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(tmp_path, ["my-skill"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert ".claude/skills/my-skill is a real directory" in result.output


def test_check_local_claude_wrong_target(tmp_path: Path) -> None:
    _make_local_skill(tmp_path, "my-skill")
    # Replace claude symlink with wrong target
    claude_path = tmp_path / ".claude" / "skills" / "my-skill"
    claude_path.unlink()
    (claude_path).symlink_to(Path("../../skills/my-skill"))

    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(tmp_path, ["my-skill"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "symlink points to ../../skills/my-skill" in result.output
    assert "expected ../../.agents/skills/my-skill" in result.output


def test_check_local_not_in_agents_md(tmp_path: Path) -> None:
    _make_local_skill(tmp_path, "my-skill")
    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(tmp_path, [])  # Empty agents md

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "not registered in AGENTS.md" in result.output


def test_check_local_agents_missing(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "my-skill"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("---\nname: my-skill\n---\n")
    # No .agents/skills/my-skill at all

    claude_dir = tmp_path / ".claude" / "skills"
    claude_dir.mkdir(parents=True)

    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(tmp_path, ["my-skill"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert ".agents/skills/my-skill does not exist" in result.output


def test_check_local_claude_missing(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "my-skill"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("---\nname: my-skill\n---\n")

    agents_dir = tmp_path / ".agents" / "skills"
    agents_dir.mkdir(parents=True)
    (agents_dir / "my-skill").symlink_to(Path("../../skills/my-skill"))
    # No .claude/skills/my-skill

    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(tmp_path, ["my-skill"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert ".claude/skills/my-skill does not exist" in result.output


# ---------------------------------------------------------------------------
# GitHub skill issues
# ---------------------------------------------------------------------------


def test_check_github_agents_missing(tmp_path: Path) -> None:
    # No .agents/skills/<name> at all
    claude_dir = tmp_path / ".claude" / "skills"
    claude_dir.mkdir(parents=True)

    _make_lockfile(tmp_path, {"my-remote": _github_lock_entry("org/repo")})
    _make_agents_md(tmp_path, ["my-remote"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert ".agents/skills/my-remote/ does not exist" in result.output


def test_check_github_agents_is_symlink(tmp_path: Path) -> None:
    """GitHub skill's .agents/skills/<name> should be a real dir, not a symlink."""
    real_dir = tmp_path / "somewhere" / "my-remote"
    real_dir.mkdir(parents=True)
    (real_dir / "SKILL.md").write_text("---\nname: my-remote\n---\n")

    agents_dir = tmp_path / ".agents" / "skills"
    agents_dir.mkdir(parents=True)
    (agents_dir / "my-remote").symlink_to(real_dir)

    claude_dir = tmp_path / ".claude" / "skills"
    claude_dir.mkdir(parents=True)
    (claude_dir / "my-remote").symlink_to(Path("../../.agents/skills/my-remote"))

    _make_lockfile(tmp_path, {"my-remote": _github_lock_entry("org/repo")})
    _make_agents_md(tmp_path, ["my-remote"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "symlink but should be a real directory" in result.output


def test_check_github_unexpected_skills_dir(tmp_path: Path) -> None:
    _make_github_skill(tmp_path, "my-remote")
    # Also create an unexpected skills/<name> entry
    (tmp_path / "skills" / "my-remote").mkdir(parents=True)

    _make_lockfile(tmp_path, {"my-remote": _github_lock_entry("org/repo")})
    _make_agents_md(tmp_path, ["my-remote"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "should not have skills/my-remote/ entry" in result.output


def test_check_github_claude_missing(tmp_path: Path) -> None:
    agents_dir = tmp_path / ".agents" / "skills" / "my-remote"
    agents_dir.mkdir(parents=True)
    (agents_dir / "SKILL.md").write_text("---\nname: my-remote\n---\n")
    # No .claude/skills/my-remote

    _make_lockfile(tmp_path, {"my-remote": _github_lock_entry("org/repo")})
    _make_agents_md(tmp_path, ["my-remote"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert ".claude/skills/my-remote does not exist" in result.output


def test_check_github_not_in_agents_md(tmp_path: Path) -> None:
    _make_github_skill(tmp_path, "my-remote")
    _make_lockfile(tmp_path, {"my-remote": _github_lock_entry("org/repo")})
    _make_agents_md(tmp_path, [])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "not registered in AGENTS.md" in result.output


# ---------------------------------------------------------------------------
# Cross-cutting / orphan checks
# ---------------------------------------------------------------------------


def test_check_orphan_in_skills_dir(tmp_path: Path) -> None:
    _make_local_skill(tmp_path, "tracked")
    # Add an untracked dir in skills/
    (tmp_path / "skills" / "orphan-skill").mkdir(parents=True)

    _make_lockfile(tmp_path, {"tracked": _local_lock_entry("tracked")})
    _make_agents_md(tmp_path, ["tracked"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "Orphaned directory skills/orphan-skill/" in result.output


def test_check_orphan_in_agents_dir(tmp_path: Path) -> None:
    _make_local_skill(tmp_path, "tracked")
    # Add an untracked dir in .agents/skills/
    (tmp_path / ".agents" / "skills" / "orphan-skill").mkdir(parents=True)

    _make_lockfile(tmp_path, {"tracked": _local_lock_entry("tracked")})
    _make_agents_md(tmp_path, ["tracked"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "Orphaned directory .agents/skills/orphan-skill/" in result.output


def test_check_orphan_dangling_lockfile(tmp_path: Path) -> None:
    _make_lockfile(tmp_path, {"ghost": _github_lock_entry("org/repo")})
    _make_agents_md(tmp_path, [])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "no directories found on disk for ghost" in result.output


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


def test_check_edge_no_lockfile(tmp_path: Path) -> None:
    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code != 0
    assert "skills-lock.json not found" in result.output


def test_check_edge_invalid_json(tmp_path: Path) -> None:
    (tmp_path / "skills-lock.json").write_text("not valid json{{{")

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code != 0
    assert "Invalid JSON" in result.output


def test_check_edge_no_agents_md(tmp_path: Path) -> None:
    """Missing AGENTS.md reports per-skill registration errors."""
    _make_local_skill(tmp_path, "my-skill")
    _make_lockfile(tmp_path, {"my-skill": _local_lock_entry("my-skill")})
    # No AGENTS.md

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    assert "not registered in AGENTS.md" in result.output


def test_check_edge_no_skills_dir(tmp_path: Path) -> None:
    """Project with only GitHub skills, no skills/ directory at all."""
    _make_github_skill(tmp_path, "my-remote")
    _make_lockfile(tmp_path, {"my-remote": _github_lock_entry("org/repo")})
    _make_agents_md(tmp_path, ["my-remote"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 0


def test_check_edge_multiple_issues_per_skill(tmp_path: Path) -> None:
    """A single local skill with no skills/ dir, real dir in .agents, and no AGENTS.md entry."""
    agents_dir = tmp_path / ".agents" / "skills" / "bad-skill"
    agents_dir.mkdir(parents=True)
    (agents_dir / "SKILL.md").write_text("---\nname: bad-skill\n---\n")

    claude_dir = tmp_path / ".claude" / "skills"
    claude_dir.mkdir(parents=True)
    (claude_dir / "bad-skill").symlink_to(Path("../../.agents/skills/bad-skill"))

    _make_lockfile(tmp_path, {"bad-skill": _local_lock_entry("bad-skill")})
    _make_agents_md(tmp_path, [])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1
    # Should have at least 3 issues: missing skills dir, agents not symlink, not in AGENTS.md
    output = result.output
    assert "skills/bad-skill/ does not exist" in output
    assert "is a real directory, expected symlink" in output
    assert "not registered in AGENTS.md" in output


# ---------------------------------------------------------------------------
# Exit codes
# ---------------------------------------------------------------------------


def test_check_exit_zero_when_ok(tmp_path: Path) -> None:
    _make_local_skill(tmp_path, "good")
    _make_lockfile(tmp_path, {"good": _local_lock_entry("good")})
    _make_agents_md(tmp_path, ["good"])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 0


def test_check_exit_one_when_errors(tmp_path: Path) -> None:
    _make_lockfile(tmp_path, {"missing": _local_lock_entry("missing")})
    _make_agents_md(tmp_path, [])

    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path)])
    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# --path option
# ---------------------------------------------------------------------------


def test_check_path_explicit(tmp_path: Path) -> None:
    project = tmp_path / "myproject"
    project.mkdir()
    _make_local_skill(project, "my-skill")
    _make_lockfile(project, {"my-skill": _local_lock_entry("my-skill")})
    _make_agents_md(project, ["my-skill"])

    result = CliRunner().invoke(main, ["check", "--path", str(project)])
    assert result.exit_code == 0


def test_check_path_nonexistent(tmp_path: Path) -> None:
    result = CliRunner().invoke(main, ["check", "--path", str(tmp_path / "nope")])
    assert result.exit_code != 0
