from datetime import UTC, date, datetime

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.domain import ImportRecord, Trade
from net_alpha.models.preferences import AccountPreference
from net_alpha.web.app import create_app


def _seed(tmp_path, profile_label):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    a = repo.get_or_create_account("Schwab", "Tax")
    repo.upsert_user_preference(
        AccountPreference(
            account_id=a.id,
            profile=profile_label,
            density="comfortable",
            updated_at=datetime(2026, 4, 27, tzinfo=UTC),
        )
    )
    # Seed a no-violation import so the page-level empty hero on /tax does
    # not suppress the wash-sales tab body these tests assert on.
    repo.add_import(
        a,
        ImportRecord(
            account_id=a.id,
            csv_filename="seed.csv",
            csv_sha256="sha-seed",
            imported_at=datetime.now(),
            trade_count=1,
        ),
        [
            Trade(
                account=a.display(),
                date=date(2024, 5, 1),
                ticker="AAPL",
                action="Buy",
                quantity=10.0,
                proceeds=None,
                cost_basis=1700.0,
            )
        ],
    )
    app = create_app(settings)
    return TestClient(app)


def test_wash_watch_open_for_active(tmp_path):
    """Wash-sale watch lives on the Tax page wash-sales tab — open by default
    for the Active profile."""
    client = _seed(tmp_path, "active")
    html = client.get("/tax", params={"view": "wash-sales", "account": "Schwab/Tax"}).text
    # <details ... open> when active
    assert "<details open" in html


def test_wash_watch_collapsed_for_conservative_when_no_violation(tmp_path):
    client = _seed(tmp_path, "conservative")
    html = client.get("/tax", params={"view": "wash-sales", "account": "Schwab/Tax"}).text
    # <details> without "open" attribute
    assert "<details>" in html or "<details \n" in html
    assert "<details open" not in html
