"""Phase 1 positions tabs (§3.3 of UI/UX redesign spec)."""

from __future__ import annotations

from fastapi.testclient import TestClient


def test_positions_page_has_five_tab_links(client: TestClient):
    resp = client.get("/positions")
    html = resp.text
    for label in ("All", "Stocks", "Options", "At a loss", "Closed"):
        assert f">{label}<" in html, f"missing tab: {label}"


def test_default_tab_is_all_when_no_view_param(client: TestClient):
    resp = client.get("/positions")
    html = resp.text
    all_idx = html.find(">All<")
    assert all_idx > 0
    anchor_start = html.rfind("<a", 0, all_idx)
    anchor_html = html[anchor_start:all_idx]
    assert "tab--active" in anchor_html


def test_at_loss_tab_links_to_view_at_loss(client: TestClient):
    resp = client.get("/positions")
    # href includes view=at-loss; may also carry &period= state
    assert 'href="/positions?view=at-loss' in resp.text


def test_view_at_loss_marks_at_loss_tab_active(client: TestClient):
    resp = client.get("/positions?view=at-loss")
    html = resp.text
    at_loss_idx = html.find(">At a loss<")
    assert at_loss_idx > 0
    anchor_start = html.rfind("<a", 0, at_loss_idx)
    anchor_html = html[anchor_start:at_loss_idx]
    assert "tab--active" in anchor_html


def test_at_loss_view_renders_harvest_queue_content(client: TestClient):
    """`/positions?view=at-loss` renders a loading shell that lazy-loads
    `/tax/harvest/plan` via HTMX (as of B4).  The plan fragment has the
    harvest plan-builder and the Lockout-clear column."""
    # The at-loss page now renders an HTMX loading shell; the column headers
    # live in the /tax/harvest/plan fragment that is fetched client-side.
    resp = client.get("/positions?view=at-loss")
    assert resp.status_code == 200
    html = resp.text
    # The loading shell must reference the plan endpoint
    assert "/tax/harvest/plan" in html or "harvest-queue-region" in html
    # The plan fragment is served correctly (200 + region id)
    plan_resp = client.get("/tax/harvest/plan")
    assert plan_resp.status_code == 200
    assert 'id="harvest-queue-region"' in plan_resp.text


def test_view_all_renders_existing_positions_table(client: TestClient):
    """`/positions?view=all` renders the same positions panel that users had
    on /holdings pre-rename (HTMX-loaded; server side emits the trigger div)."""
    resp = client.get("/positions?view=all")
    html = resp.text
    assert resp.status_code == 200
    # The positions content is loaded via HTMX; the server renders either the
    # trigger div (when imports exist) or the empty-state partial (no data).
    assert "/portfolio/positions" in html or "no data" in html.lower() or "import" in html.lower()


def test_tax_page_no_longer_has_harvest_tab(client: TestClient, repo, builders):
    from datetime import date

    # Seed a no-violation import so the page-level empty hero on /tax does
    # not suppress the tab nav we're asserting on.
    builders.seed_import(
        repo,
        "schwab",
        "personal",
        [builders.make_buy("schwab/personal", "AAPL", date(2024, 5, 1))],
    )
    resp = client.get("/tax")
    html = resp.text
    assert ">Harvest<" not in html, "Tax page still has Harvest tab"
    assert "Wash sales" in html
    assert "Projection" in html


def test_at_loss_harvestable_toggle_uses_positions_url(client: TestClient):
    """The 'currently harvestable only' checkbox on /positions?view=at-loss
    must POST to /positions, not /tax (which would 301-redirect and lose
    the only_harvestable param)."""
    resp = client.get("/positions?view=at-loss")
    html = resp.text
    # The form's hx-get should target the positions URL
    assert 'hx-get="/positions?view=at-loss"' in html
    # And NOT the legacy tax URL
    assert 'hx-get="/tax?view=harvest"' not in html


def test_at_loss_hx_request_returns_panel_only(client: TestClient):
    """An HX-Request to /positions?view=at-loss returns just the at-loss
    panel content, not the full positions page chrome."""
    resp = client.get(
        "/positions?view=at-loss&only_harvestable=1",
        headers={"HX-Request": "true"},
    )
    assert resp.status_code == 200
    # The full positions.html sets the page H1; the panel partial doesn't.
    # The harvest queue is present in both, so we look for the absence of
    # the page chrome.
    assert "<h1" not in resp.text or ">Positions<" not in resp.text
    # The panel itself is present
    assert 'id="positions-tab-content"' in resp.text or "harvest" in resp.text.lower()
