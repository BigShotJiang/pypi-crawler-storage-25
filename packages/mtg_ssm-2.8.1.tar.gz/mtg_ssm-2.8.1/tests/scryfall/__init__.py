"""Establish tests.scryfall package."""
