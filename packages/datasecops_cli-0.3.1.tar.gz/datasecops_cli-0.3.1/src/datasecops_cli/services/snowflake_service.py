import json
from typing import Any, Optional
import snowflake.connector

from datasecops_cli.models.project_config import DatasecopsConfig


class SnowflakeService:
    """Connects to Snowflake and calls native app API procedures."""
    
    def __init__(self, config: DatasecopsConfig):
        self.config = config
        self._conn: Optional[snowflake.connector.SnowflakeConnection] = None
    
    def connect(self) -> None:
        self._conn = snowflake.connector.connect(
            connection_name=self.config.connection_name,
        )
    
    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None
    
    @property
    def conn(self) -> snowflake.connector.SnowflakeConnection:
        if self._conn is None:
            self.connect()
        return self._conn
    
    def execute_query(self, sql: str, params: list = None) -> list[dict]:
        cur = self.conn.cursor(snowflake.connector.DictCursor)
        try:
            cur.execute(sql, params or [])
            return cur.fetchall()
        finally:
            cur.close()
    
    def call_procedure(self, proc_name: str, *args) -> Any:
        db = self.config.app_database
        arg_placeholders = ", ".join(["%s"] * len(args))
        sql = f"CALL {db}.api.{proc_name}({arg_placeholders})"
        rows = self.execute_query(sql, list(args))
        if rows:
            first_val = list(rows[0].values())[0]
            if isinstance(first_val, str):
                try:
                    return json.loads(first_val)
                except (json.JSONDecodeError, TypeError):
                    return first_val
            return first_val
        return None
    
    def get_framework_config(self, config_code: str) -> Optional[dict]:
        return self.call_procedure("get_framework_config", config_code)
    
    def get_macros_for_profile(self, profile_name: str) -> Optional[dict]:
        return self.call_procedure("get_macros_for_profile", profile_name)
    
    def get_project_profiles(self) -> Optional[list[dict]]:
        return self.call_procedure("get_project_profiles")

    def get_pipelines_for_profile(self, profile_name: str) -> Optional[dict]:
        return self.call_procedure("get_pipelines_for_profile", profile_name)

    def get_account_info(self) -> dict:
        rows = self.execute_query("SELECT CURRENT_ACCOUNT_NAME() as account, CURRENT_USER() as user_name")
        return rows[0] if rows else {}
