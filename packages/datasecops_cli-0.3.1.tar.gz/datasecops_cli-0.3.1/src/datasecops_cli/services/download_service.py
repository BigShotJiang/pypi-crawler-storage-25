import json
import subprocess
import yaml
from pathlib import Path
from typing import Optional

from datasecops_cli.models.project_config import ProjectProfile, ProjectSettings
from datasecops_cli.services.snowflake_service import SnowflakeService
from datasecops_cli.utilities.display import info_line, success_line, error_line
from datasecops_cli.utilities.file_utils import write_file, ensure_dir


class DownloadService:
    """Downloads configurations from the native app."""

    # Maps rule codes to their sqlfluff INI section names.
    RULE_SECTION_MAP: dict[str, str] = {
        # Aliasing
        "AL01": "aliasing.table", "AL02": "aliasing.column", "AL03": "aliasing.expression",
        "AL04": "aliasing.unique.table", "AL05": "aliasing.unused", "AL06": "aliasing.length",
        "AL07": "aliasing.forbid", "AL08": "aliasing.unique.column", "AL09": "aliasing.self_alias",
        # Ambiguous
        "AM01": "ambiguous.distinct", "AM02": "ambiguous.union", "AM03": "ambiguous.order_by",
        "AM04": "ambiguous.column_count", "AM05": "ambiguous.join",
        "AM06": "ambiguous.column_references", "AM07": "ambiguous.set_columns",
        "AM08": "ambiguous.union_type",
        # Capitalisation
        "CP01": "capitalisation.keywords", "CP02": "capitalisation.identifiers",
        "CP03": "capitalisation.functions", "CP04": "capitalisation.literals",
        "CP05": "capitalisation.types",
        # Convention
        "CV01": "convention.not_equal", "CV02": "convention.coalesce",
        "CV03": "convention.select_trailing_comma", "CV04": "convention.count_rows",
        "CV05": "convention.is_null", "CV06": "convention.terminator",
        "CV07": "convention.statement_brackets", "CV08": "convention.left_join",
        "CV09": "convention.blocked_words", "CV10": "convention.quoted_literals",
        "CV11": "convention.casting_style", "CV12": "convention.semicolon",
        # Jinja
        "JJ01": "jinja.padding",
        # Layout
        "LT01": "layout.spacing", "LT02": "layout.indent", "LT03": "layout.operators",
        "LT04": "layout.commas", "LT05": "layout.long_lines", "LT06": "layout.functions",
        "LT07": "layout.cte_bracket", "LT08": "layout.cte_newline",
        "LT09": "layout.select_targets", "LT10": "layout.select_modifiers",
        "LT11": "layout.set_operators", "LT12": "layout.end-of-file",
        "LT13": "layout.start_of_file", "LT14": "layout.one_line", "LT15": "layout.newlines",
        # References
        "RF01": "references.from", "RF02": "references.qualification",
        "RF03": "references.consistent", "RF04": "references.keywords",
        "RF05": "references.special_chars", "RF06": "references.quoting",
        # Structure
        "ST01": "structure.else_null", "ST02": "structure.simple_case",
        "ST03": "structure.unused_cte", "ST04": "structure.nested_case",
        "ST05": "structure.subquery", "ST06": "structure.column_order",
        "ST07": "structure.using", "ST08": "structure.distinct",
        "ST09": "structure.join_condition_order", "ST10": "structure.cte_definition_order",
        "ST11": "structure.test_query",
    }

    # Core sub-keys that map to specific INI sections.
    CORE_SECTION_MAP: dict[str, str] = {
        "sqlfluff": "sqlfluff",
        "dbt": "sqlfluff:templater:dbt",
        "jinja": "sqlfluff:templater:jinja",
        "templater": "sqlfluff:templater",
    }
    
    def __init__(self, snowflake_service: SnowflakeService, project_dir: Path):
        self.sf = snowflake_service
        self.project_dir = project_dir

    # Options to strip from specific core sections (not valid sqlfluff config keys).
    CORE_STRIP_OPTIONS: dict[str, set[str]] = {
        "dbt": {"dbt_skip_compilation_error"},
    }

    @staticmethod
    def _format_value(val) -> str:
        """Format a JSON value for sqlfluff INI output."""
        if isinstance(val, bool):
            return str(val)
        if isinstance(val, list):
            if not val:
                return "None"
            return ", ".join(str(v) for v in val)
        if val is None or val == "":
            return "None"
        return str(val)

    @staticmethod
    def _emit_section(lines: list[str], header: str, options: dict) -> None:
        """Append an INI section with its options to lines."""
        lines.append(f"[{header}]")
        for key, val in options.items():
            lines.append(f"{key} = {DownloadService._format_value(val)}")
        lines.append("")
    
    def download_sqlfluff_config(self, profiles_dir: str = None, dbt_project_dir: Path = None) -> bool:
        info_line("Downloading SQLFluff configuration...")
        raw = self.sf.get_framework_config("SQLFLUFF_RULES")
        if not raw:
            error_line("No SQLFluff configuration found in native app")
            return False
        
        lines: list[str] = []

        # --- Core sections ([sqlfluff], [sqlfluff:templater:dbt], etc.) ---
        core = raw.get("core", {})
        for key, section_header in self.CORE_SECTION_MAP.items():
            entry = core.get(key)
            if not isinstance(entry, dict) or not entry.get("enabled", True):
                continue
            opts = dict(entry.get("options", {}))
            # Strip options that are not valid sqlfluff config keys
            for strip_key in self.CORE_STRIP_OPTIONS.get(key, set()):
                opts.pop(strip_key, None)
            if key == "dbt":
                # Override profiles_dir / project_dir with local values
                opts["project_dir"] = "."
                if profiles_dir:
                    opts["profiles_dir"] = profiles_dir
                else:
                    opts.pop("profiles_dir", None)
            if opts:
                self._emit_section(lines, section_header, opts)

        # --- Indentation ---
        indentation = raw.get("indentation", {})
        for _code, entry in indentation.items():
            if isinstance(entry, dict) and entry.get("enabled", True):
                opts = entry.get("options", {})
                if opts:
                    self._emit_section(lines, "sqlfluff:indentation", opts)

        # --- Layout sections ([sqlfluff:layout:type:<code>]) ---
        layout = raw.get("layout", {})
        for code, entry in layout.items():
            if not isinstance(entry, dict) or not entry.get("enabled", True):
                continue
            opts = entry.get("options", {})
            if opts:
                self._emit_section(lines, f"sqlfluff:layout:type:{code}", opts)

        # --- Global rules ([sqlfluff:rules]) ---
        rules = raw.get("rules", {})
        for _code, entry in rules.items():
            if isinstance(entry, dict) and entry.get("enabled", True):
                opts = entry.get("options", {})
                if opts:
                    self._emit_section(lines, "sqlfluff:rules", opts)

        # --- Rule bundle sections (rules_aliasing, rules_capitalisation, etc.) ---
        for section_key, entries in raw.items():
            if not section_key.startswith("rules_") or not isinstance(entries, dict):
                continue
            for code, entry in entries.items():
                if not isinstance(entry, dict) or not entry.get("enabled", True):
                    continue
                section_name = self.RULE_SECTION_MAP.get(code)
                if not section_name:
                    continue
                opts = dict(entry.get("options", {}))
                # For aliasing.length, 0 means "no limit" which sqlfluff expects as None
                if section_name == "aliasing.length":
                    for len_key in ("min_alias_length", "max_alias_length"):
                        if len_key in opts and opts[len_key] == 0:
                            opts[len_key] = None
                self._emit_section(lines, f"sqlfluff:rules:{section_name}", opts)

        content = "\n".join(lines)
        dest = (dbt_project_dir or self.project_dir) / ".sqlfluff"
        write_file(dest, content)
        success_line(f"SQLFluff config written to {dest}")
        return True
    
    def _fetch_framework_versions(self) -> dict[str, str]:
        """Fetch all active package versions from the framework's DBT_VERSIONS config.
        
        Returns a dict mapping pip package name to pinned spec, e.g. {"dbt-core": "dbt-core==1.9.0", ...}.
        """
        raw = self.sf.get_framework_config("DBT_VERSIONS")
        if not raw:
            error_line("No DBT_VERSIONS configuration found in native app")
            return {}
        
        version_keys = {
            "sqlfluff_versions": "sqlfluff",
            "sqlfluff_templater_versions": "sqlfluff-templater-dbt",
            "dbt_core_versions": "dbt-core",
            "dbt_snowflake_versions": "dbt-snowflake",
        }
        
        result: dict[str, str] = {}
        for config_key, pkg_name in version_keys.items():
            for entry in raw.get(config_key, []):
                if entry.get("active"):
                    result[pkg_name] = f"{pkg_name}=={entry['version']}"
                    break
        
        if not result:
            error_line("No active versions found in framework configuration")
        
        return result

    def get_sqlfluff_requirements(self) -> list[str]:
        """Fetch active sqlfluff and sqlfluff-templater-dbt versions from the framework."""
        info_line("Fetching SQLFluff requirements from framework...")
        versions = self._fetch_framework_versions()
        sqlfluff_packages = [versions[k] for k in ("sqlfluff", "sqlfluff-templater-dbt") if k in versions]
        if not sqlfluff_packages:
            error_line("No active SQLFluff versions found in framework configuration")
        return sqlfluff_packages

    def get_dbt_requirements(self) -> list[str]:
        """Fetch active dbt-core and dbt-snowflake versions from the framework."""
        info_line("Fetching dbt requirements from framework...")
        versions = self._fetch_framework_versions()
        dbt_packages = [versions[k] for k in ("dbt-core", "dbt-snowflake") if k in versions]
        if not dbt_packages:
            error_line("No active dbt versions found in framework configuration")
        return dbt_packages
    
    def download_pipelines(self, platform: str = "github", profile_name: str = "") -> bool:
        info_line(f"Downloading {platform} pipeline configurations...")
        if profile_name:
            info_line(f"Filtering pipelines for profile: {profile_name}")
            raw = self.sf.get_pipelines_for_profile(profile_name)
        else:
            raw = self.sf.get_framework_config("PIPELINES")
        if not raw:
            error_line("No pipeline configuration found in native app")
            return False
        
        pipelines = raw.get("pipelines", [])
        count = 0
        for pipe in pipelines:
            if pipe.get("platform", "github").lower() != platform.lower() or not pipe.get("enabled", True):
                continue
            filename = pipe.get("filename", "")
            yaml_content = pipe.get("yaml_content", "")
            if filename and yaml_content:
                if platform.lower() == "github":
                    dest = self.project_dir / ".github" / "workflows" / filename
                else:
                    dest = self.project_dir / filename
                write_file(dest, yaml_content)
                info_line(f"  Written: {dest}")
                count += 1
        
        success_line(f"Downloaded {count} pipeline file(s)")
        return True
    
    def download_dbt_packages(self, dbt_project_dir: Path) -> bool:
        info_line("Downloading dbt package versions...")
        raw = self.sf.get_framework_config("DBT_PACKAGES")
        if not raw:
            error_line("No dbt packages configuration found in native app")
            return False
        
        packages = raw.get("packages", [])
        pkg_list = []
        for pkg in packages:
            source = pkg.get("source", "git")
            url = pkg.get("url", "")
            version = pkg.get("latest_version", "")
            if source == "git" and url:
                entry = {"git": url}
                if version:
                    entry["revision"] = version
                pkg_list.append(entry)
            elif source == "package" and url:
                entry = {"package": url}
                if version:
                    entry["version"] = version
                pkg_list.append(entry)
        
        dest = dbt_project_dir / "packages.yml"
        content = yaml.dump({"packages": pkg_list}, default_flow_style=False, sort_keys=False)
        write_file(dest, content)
        success_line(f"packages.yml written to {dest}")
        return True
    
    def download_macros(self, profile_name: str, dbt_project_dir: Path) -> bool:
        """Download default macros for the project profile from the native app."""
        info_line(f"Downloading macros for profile '{profile_name}'...")
        raw = self.sf.get_macros_for_profile(profile_name)
        if not raw:
            error_line("No macros found for this profile in native app")
            return False
        
        macros = raw.get("macros", [])
        if not macros:
            info_line("No default macros configured for this profile")
            return True
        
        macros_dir = dbt_project_dir / "macros"
        ensure_dir(macros_dir)
        
        count = 0
        for macro in macros:
            macro_name = macro.get("macro_name", "")
            sql = macro.get("sql", "")
            if macro_name and sql:
                dest = macros_dir / f"{macro_name}.sql"
                write_file(dest, sql)
                info_line(f"  Written: {dest}")
                count += 1
        
        success_line(f"Downloaded {count} macro(s) to {macros_dir}")
        return True
    
    def init_dbt_project(self, project_settings: ProjectSettings, profile: ProjectProfile) -> bool:
        """Run dbtf init and generate profiles.yml from framework targets."""
        info_line("Running dbtf init...")
        result = subprocess.run(["dbtf", "init"], capture_output=False)
        if result.returncode != 0:
            error_line(f"dbtf init failed with exit code {result.returncode}")
            return False
        success_line("dbtf init completed successfully")
        
        # Generate profiles.yml in the project directory
        info_line("Generating profiles.yml from framework configuration...")
        
        account_info = self.sf.get_account_info()
        account = account_info.get("ACCOUNT", account_info.get("account", ""))
        
        outputs = {}
        
        # Add local-dev target
        outputs["local-dev"] = {
            "type": "snowflake",
            "account": account,
            "authenticator": "externalbrowser",
            "role": project_settings.targets[0].target_role if project_settings.targets else "DEVELOPERS",
            "warehouse": project_settings.targets[0].target_warehouse if project_settings.targets else "DEV_WH",
            "database": profile.target_database,
            "schema": project_settings.targets[0].target_schema if project_settings.targets else "PUBLIC",
            "threads": 4,
        }
        
        # Add all framework targets
        for target in project_settings.targets:
            outputs[target.target_name] = {
                "type": "snowflake",
                "account": account,
                "authenticator": "externalbrowser",
                "role": target.target_role,
                "warehouse": target.target_warehouse,
                "database": profile.target_database,
                "schema": target.target_schema,
                "threads": 4,
            }
        
        profiles_data = {
            profile.profile_name: {
                "target": "local-dev",
                "outputs": outputs,
            }
        }
        
        dest = self.project_dir / "profiles.yml"
        content = yaml.dump(profiles_data, default_flow_style=False, sort_keys=False)
        write_file(dest, content)
        success_line(f"profiles.yml written to {dest}")
        return True
