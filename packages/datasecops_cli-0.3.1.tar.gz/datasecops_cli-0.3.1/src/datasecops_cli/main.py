import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

from datasecops_cli.config import Config
from datasecops_cli.services.snowflake_service import SnowflakeService
from datasecops_cli.services.dbt_runner import DbtRunner
from datasecops_cli.services.git_service import GitService
from datasecops_cli.services.linting_service import LintingService
from datasecops_cli.services.download_service import DownloadService
from datasecops_cli.services.skill_service import SkillService
from datasecops_cli.services.bootstrap_service import BootstrapService
from datasecops_cli.menus.development import DevelopmentMenu
from datasecops_cli.menus.git_operations import GitOperationsMenu
from datasecops_cli.menus.downloads import DownloadsMenu
from datasecops_cli.utilities.display import (
    clear, section_header, menu_option, get_input_number,
    info_line, error_line, success_line
)
from datasecops_cli.utilities.yaml_utils import write_datasecops_config


DOWNLOAD_ITEMS = [
    "sqlfluff", "pipelines", "packages", "macros",
    "install-sqlfluff", "install-dbt", "all",
]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="datasecops",
        description="DataSecOps Framework CLI for Snowflake Native App",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("setup", help="Configure .datasecops.yml for this project")
    sub.add_parser("bootstrap", help="Set up a new dbt project with all framework config")

    dl = sub.add_parser("download", help="Download framework config non-interactively (for CI/CD)")
    dl.add_argument(
        "items",
        nargs="+",
        choices=DOWNLOAD_ITEMS,
        help="Item(s) to download/install: sqlfluff, pipelines, packages, macros, install-sqlfluff, install-dbt, or all",
    )
    dl.add_argument(
        "--connection", "-c",
        help="Snowflake connection name (overrides .datasecops.yml)",
    )
    dl.add_argument(
        "--app-database", "-d",
        help="Native app database name (overrides .datasecops.yml)",
    )
    dl.add_argument(
        "--profile", "-p",
        help="Project profile name (overrides .datasecops.yml)",
    )

    return parser


def main():
    """Main entry point for the datasecops CLI."""
    parser = _build_parser()
    args = parser.parse_args()

    config = Config()

    if args.command == "setup":
        _run_setup(config.project_dir)
    elif args.command == "bootstrap":
        _run_bootstrap(config)
    elif args.command == "download":
        _run_download(config, args.items,
                      connection=args.connection, app_database=args.app_database,
                      profile=args.profile)
    else:
        _run_interactive(config)


def _run_setup(project_dir: Path):
    """Interactive setup: create .datasecops.yml by prompting for connection and app database."""
    from datasecops_cli.utilities.display import (
        get_input_string, get_input_string_or_default, select_from_list, warning_line
    )

    section_header("DataSecOps Setup")

    # --- Check prerequisites ---
    info_line("Checking prerequisites...")

    if shutil.which("dbtf"):
        success_line("dbt Fusion (dbtf) found")
    else:
        warning_line("dbt Fusion (dbtf) not found — dbt commands will not work")
        warning_line("  Install: https://docs.getdbt.com/docs/core/installation")

    if shutil.which("gh"):
        result = subprocess.run(["gh", "auth", "status"], capture_output=True, text=True)
        if result.returncode == 0:
            success_line("GitHub CLI (gh) found and authenticated")
        else:
            warning_line("GitHub CLI (gh) found but not logged in — run: gh auth login")
    else:
        warning_line("GitHub CLI (gh) not found — install from https://cli.github.com if using GitHub")

    if shutil.which("az"):
        result = subprocess.run(["az", "account", "show"], capture_output=True, text=True)
        if result.returncode == 0:
            success_line("Azure CLI (az) found and authenticated")
        else:
            warning_line("Azure CLI (az) found but not logged in — run: az login")
    else:
        warning_line("Azure CLI (az) not found — install from https://aka.ms/installazurecli if using Azure DevOps")

    info_line("")

    # --- Discover Snowflake connections ---
    connections_file = Path.home() / ".snowflake" / "connections.toml"
    connection_names = []
    if connections_file.exists():
        import re
        for line in connections_file.read_text(encoding="utf-8").splitlines():
            m = re.match(r"^\[([^\]]+)\]", line)
            if m:
                connection_names.append(m.group(1))

    if connection_names:
        connection_name = select_from_list(connection_names, "Snowflake connection", add_back=False)
    else:
        info_line("No connections found in ~/.snowflake/connections.toml")
        connection_name = get_input_string("Enter Snowflake connection name: ")

    if not connection_name:
        error_line("Connection name is required")
        sys.exit(1)

    # --- App database ---
    app_database = get_input_string_or_default(
        "Enter native app database name",
        "DATA_ENGINEERS_DATASECOPS_FRAMEWORK"
    )

    # --- Write config ---
    config_data = {
        "connection_name": connection_name,
        "app_database": app_database,
        "profile_name": "",
    }
    write_datasecops_config(project_dir, config_data)
    success_line(f".datasecops.yml written to {project_dir / '.datasecops.yml'}")


def _offer_setup(project_dir: Path):
    """Offer to run setup when .datasecops.yml is missing."""
    from datasecops_cli.utilities.display import get_input_true_false

    info_line("No .datasecops.yml found in this project.")
    if not get_input_true_false("Run setup now?"):
        sys.exit(1)

    _run_setup(project_dir)


def _connect_and_load(config: Config, interactive: bool = True) -> SnowflakeService:
    """Load config, connect to Snowflake, and load native app settings.
    
    Returns the connected SnowflakeService, or calls sys.exit on failure.
    If .datasecops.yml is missing and interactive is True, offers to run setup.
    """
    if not config.load():
        # Check if the failure is due to missing .datasecops.yml
        if not (config.project_dir / ".datasecops.yml").exists() and interactive:
            _offer_setup(config.project_dir)
            # Retry after setup
            if not config.load():
                sys.exit(1)
        else:
            sys.exit(1)

    sf_config = config.datasecops
    sf_service = SnowflakeService(sf_config)
    profile_was_set = bool(config.profile_name)

    try:
        info_line(f"Connecting to Snowflake ({sf_config.connection_name})...")
        sf_service.connect()
        success_line("Connected")
    except Exception as e:
        error_line(f"Failed to connect to Snowflake: {e}")
        sys.exit(1)

    info_line("Loading framework configuration...")
    config.load_from_native_app(sf_service)

    # If profile_name was not explicitly set and there are multiple profiles, ask the user
    if not profile_was_set and len(config.all_profiles) > 1:
        if interactive:
            from datasecops_cli.utilities.display import select_from_list
            names = [p.profile_name for p in config.all_profiles]
            info_line(f"Found {len(names)} project profiles:")
            selected = select_from_list(names, "profile", add_back=False)
            config.profile = None
            for p in config.all_profiles:
                if p.profile_name == selected:
                    config.profile = p
                    config.profile_name = selected
                    break
            # Save the selected profile back to .datasecops.yml
            if config.profile:
                config_data = {
                    "connection_name": config.datasecops.connection_name,
                    "app_database": config.datasecops.app_database,
                    "profile_name": config.profile_name,
                }
                write_datasecops_config(config.project_dir, config_data)
                success_line(f"Saved profile_name '{config.profile_name}' to .datasecops.yml")
        else:
            # Non-interactive: use the auto-selected first profile
            info_line(f"Using default profile: {config.profile_name}")

    # Re-resolve dbt_project_dir using framework project_dir setting
    framework_dbt_dir = config.project_dir / config.project_settings.project_dir
    if (framework_dbt_dir / "dbt_project.yml").exists():
        config.dbt_project_dir = framework_dbt_dir

    if not config.profile:
        error_line(f"Profile '{config.profile_name}' not found in native app")
        sf_service.close()
        sys.exit(1)

    success_line(f"Profile: {config.profile.project_name} ({config.profile_name})")
    return sf_service


def _run_interactive(config: Config):
    """Run the interactive menu-driven CLI."""
    sf_service = _connect_and_load(config)

    try:
        # Check for dbt Fusion (dbtf) on PATH
        if not shutil.which("dbtf"):
            from datasecops_cli.utilities.display import warning_line
            warning_line("dbt Fusion (dbtf) not found on PATH — dbt commands will not work.")
            warning_line("Install dbt Fusion: https://docs.getdbt.com/docs/core/installation")

        # Initialize services
        dbt_runner = DbtRunner(
            project_dir=config.dbt_project_dir,
            profiles_dir=config.get_dbt_profiles_dir(),
            target=config.project_settings.get_default_target().target_name if config.get_default_target() else "dev"
        )

        try:
            git_service = GitService(config.project_dir)
        except Exception:
            git_service = None

        linting_service = LintingService(config.dbt_project_dir)
        download_service = DownloadService(sf_service, config.project_dir)
        skill_service = SkillService(sf_service)

        # Main menu loop
        _main_menu(config, dbt_runner, git_service, linting_service,
                    download_service, skill_service, sf_service)
    finally:
        sf_service.close()


def _run_download(config: Config, items: list[str],
                   connection: str = None, app_database: str = None,
                   profile: str = None):
    """Run non-interactive downloads for CI/CD pipelines."""
    # If CLI flags provided, write/override .datasecops.yml on the fly
    if connection or app_database:
        from datasecops_cli.utilities.yaml_utils import read_datasecops_config
        existing = read_datasecops_config(config.project_dir) or {}
        config_data = {
            "connection_name": connection or existing.get("connection_name", ""),
            "app_database": app_database or existing.get("app_database", ""),
            "profile_name": profile or existing.get("profile_name", ""),
        }
        write_datasecops_config(config.project_dir, config_data)
        info_line(f"Wrote .datasecops.yml (connection={config_data['connection_name']}, app_database={config_data['app_database']})")
    elif profile:
        from datasecops_cli.utilities.yaml_utils import read_datasecops_config
        existing = read_datasecops_config(config.project_dir) or {}
        existing["profile_name"] = profile
        write_datasecops_config(config.project_dir, existing)

    sf_service = _connect_and_load(config, interactive=False)

    try:
        download_service = DownloadService(sf_service, config.project_dir)
        linting_service = LintingService(config.dbt_project_dir)
        profiles_dir = str(config.get_dbt_profiles_dir())

        if "all" in items:
            items = ["sqlfluff", "pipelines", "packages", "macros",
                     "install-sqlfluff", "install-dbt"]

        failed = False
        for item in items:
            info_line("")
            if item == "sqlfluff":
                if not download_service.download_sqlfluff_config(
                    profiles_dir=profiles_dir, dbt_project_dir=config.dbt_project_dir
                ):
                    failed = True
            elif item == "pipelines":
                platform = config.source_control.source_control_platform.lower()
                info_line(f"Platform: {platform}")
                if not download_service.download_pipelines(platform=platform, profile_name=config.profile_name):
                    failed = True
            elif item == "packages":
                if not download_service.download_dbt_packages(config.dbt_project_dir):
                    failed = True
            elif item == "macros":
                if not download_service.download_macros(config.profile_name, config.dbt_project_dir):
                    failed = True
            elif item == "install-sqlfluff":
                packages = download_service.get_sqlfluff_requirements()
                if packages:
                    if not linting_service.install_requirements(packages):
                        failed = True
                else:
                    failed = True
            elif item == "install-dbt":
                packages = download_service.get_dbt_requirements()
                if packages:
                    if not linting_service.install_requirements(packages):
                        failed = True
                else:
                    failed = True

        sys.exit(1 if failed else 0)
    finally:
        sf_service.close()


def _main_menu(config: Config, dbt_runner: DbtRunner, git_service: GitService,
               linting_service: LintingService, download_service: DownloadService,
               skill_service: SkillService, sf_service: SnowflakeService):
    """Main menu loop."""
    profile_name = config.profile_name
    
    _show_main_menu(profile_name, git_service)
    option = get_input_number("Choose an option: ")
    
    while option != 0:
        if option == 1:
            profiles_dir = str(config.get_dbt_profiles_dir())
            if git_service:
                dev_menu = DevelopmentMenu(dbt_runner, linting_service, git_service, profile_name,
                                          download_service=download_service, profiles_dir=profiles_dir)
            else:
                dev_menu = DevelopmentMenu(dbt_runner, linting_service, None, profile_name,
                                          download_service=download_service, profiles_dir=profiles_dir)
            dev_menu.show()
        
        elif option == 2 and git_service:
            git_menu = GitOperationsMenu(
                git_service, config.source_control,
                config.get_deployment_branches(), profile_name
            )
            git_menu.show()
        
        elif option == 3:
            dl_menu = DownloadsMenu(
                download_service, skill_service, dbt_runner,
                profile_name, config.dbt_project_dir,
                project_settings=config.project_settings,
                profile=config.profile,
                source_control=config.source_control,
            )
            dl_menu.show()
        
        elif option == 4:
            from datasecops_cli.utilities.display import get_input_true_false
            platform = config.source_control.source_control_platform.lower()
            info_line(f"Platform: {platform}")
            install_skills = get_input_true_false("Install Cortex Code skills?")
            run_deps = get_input_true_false("Run dbt deps after downloading packages?")
            bootstrap = BootstrapService(
                snowflake_service=sf_service,
                project_dir=config.project_dir,
                project_settings=config.project_settings,
                profile=config.profile,
            )
            bootstrap.run(platform=platform, install_skills=install_skills, run_deps=run_deps)
        
        _show_main_menu(profile_name, git_service)
        option = get_input_number("Choose an option: ")
    
    info_line("Exiting DataSecOps Framework CLI")


def _show_main_menu(profile_name: str, git_service: GitService = None):
    clear()
    branch = git_service.get_current_branch() if git_service else None
    section_header("DataSecOps Framework CLI", profile_name, branch)
    menu_option(1, "development   - dbt Development Commands")
    menu_option(2, "git           - Source Control Operations")
    menu_option(3, "downloads     - Download Configs & Skills")
    menu_option(4, "bootstrap     - Set up a new dbt project with all framework config")
    menu_option(0, "exit          - Exit")


def _run_bootstrap(config: Config):
    """Run the bootstrap command to initialise a new project."""
    from datasecops_cli.utilities.display import get_input_true_false

    sf_service = _connect_and_load(config)

    try:
        info_line("")

        # Use platform from framework config
        platform = config.source_control.source_control_platform.lower()
        info_line(f"Platform: {platform}")

        # Ask about optional steps
        install_skills = get_input_true_false("Install Cortex Code skills?")
        run_deps = get_input_true_false("Run dbt deps after downloading packages?")

        bootstrap = BootstrapService(
            snowflake_service=sf_service,
            project_dir=config.project_dir,
            project_settings=config.project_settings,
            profile=config.profile,
        )
        success = bootstrap.run(platform=platform, install_skills=install_skills, run_deps=run_deps)
        sys.exit(0 if success else 1)

    finally:
        sf_service.close()


if __name__ == "__main__":
    main()
