"""Tests for datasecops_cli.main argument parsing and download dispatch."""
import pytest
from unittest.mock import MagicMock, patch, call
from pathlib import Path

from datasecops_cli.main import _build_parser, _run_download, DOWNLOAD_ITEMS
from datasecops_cli.config import Config


class TestBuildParser:
    """Tests for the argparse configuration."""

    def test_no_args_gives_no_command(self):
        parser = _build_parser()
        args = parser.parse_args([])
        assert args.command is None

    def test_bootstrap_command(self):
        parser = _build_parser()
        args = parser.parse_args(["bootstrap"])
        assert args.command == "bootstrap"

    def test_download_single_item(self):
        parser = _build_parser()
        args = parser.parse_args(["download", "sqlfluff"])
        assert args.command == "download"
        assert args.items == ["sqlfluff"]

    def test_download_multiple_items(self):
        parser = _build_parser()
        args = parser.parse_args(["download", "sqlfluff", "packages", "macros"])
        assert args.command == "download"
        assert args.items == ["sqlfluff", "packages", "macros"]

    def test_download_all(self):
        parser = _build_parser()
        args = parser.parse_args(["download", "all"])
        assert args.command == "download"
        assert args.items == ["all"]

    def test_download_invalid_item_exits(self):
        parser = _build_parser()
        with pytest.raises(SystemExit):
            parser.parse_args(["download", "invalid"])

    def test_download_no_items_exits(self):
        parser = _build_parser()
        with pytest.raises(SystemExit):
            parser.parse_args(["download"])

    def test_all_download_items_accepted(self):
        parser = _build_parser()
        for item in DOWNLOAD_ITEMS:
            args = parser.parse_args(["download", item])
            assert args.items == [item]


class TestRunDownload:
    """Tests for _run_download dispatch logic using mocked services."""

    def _make_config(self, tmp_path):
        """Create a Config with minimal valid state."""
        config = Config()
        config.project_dir = tmp_path
        config.dbt_project_dir = tmp_path
        config.profile_name = "test_profile"
        # source_control defaults to GitHub
        return config

    @patch("datasecops_cli.main._connect_and_load")
    def test_download_sqlfluff(self, mock_connect, tmp_path):
        config = self._make_config(tmp_path)
        mock_sf = MagicMock()
        mock_connect.return_value = mock_sf

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService"):
            mock_ds = MockDS.return_value
            mock_ds.download_sqlfluff_config.return_value = True

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["sqlfluff"])

            assert exc.value.code == 0
            mock_ds.download_sqlfluff_config.assert_called_once()
            mock_ds.download_pipelines.assert_not_called()
            mock_ds.download_dbt_packages.assert_not_called()
            mock_ds.download_macros.assert_not_called()

    @patch("datasecops_cli.main._connect_and_load")
    def test_download_pipelines(self, mock_connect, tmp_path):
        config = self._make_config(tmp_path)
        mock_sf = MagicMock()
        mock_connect.return_value = mock_sf

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService"):
            mock_ds = MockDS.return_value
            mock_ds.download_pipelines.return_value = True

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["pipelines"])

            assert exc.value.code == 0
            mock_ds.download_pipelines.assert_called_once_with(platform="github", profile_name="test_profile")

    @patch("datasecops_cli.main._connect_and_load")
    def test_download_packages(self, mock_connect, tmp_path):
        config = self._make_config(tmp_path)
        mock_sf = MagicMock()
        mock_connect.return_value = mock_sf

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService"):
            mock_ds = MockDS.return_value
            mock_ds.download_dbt_packages.return_value = True

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["packages"])

            assert exc.value.code == 0
            mock_ds.download_dbt_packages.assert_called_once_with(tmp_path)

    @patch("datasecops_cli.main._connect_and_load")
    def test_download_macros(self, mock_connect, tmp_path):
        config = self._make_config(tmp_path)
        mock_sf = MagicMock()
        mock_connect.return_value = mock_sf

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService"):
            mock_ds = MockDS.return_value
            mock_ds.download_macros.return_value = True

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["macros"])

            assert exc.value.code == 0
            mock_ds.download_macros.assert_called_once_with("test_profile", tmp_path)

    @patch("datasecops_cli.main._connect_and_load")
    def test_download_all_expands_to_all_items(self, mock_connect, tmp_path):
        config = self._make_config(tmp_path)
        mock_sf = MagicMock()
        mock_connect.return_value = mock_sf

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService") as MockLS:
            mock_ds = MockDS.return_value
            mock_ls = MockLS.return_value
            mock_ds.download_sqlfluff_config.return_value = True
            mock_ds.download_pipelines.return_value = True
            mock_ds.download_dbt_packages.return_value = True
            mock_ds.download_macros.return_value = True
            mock_ds.get_sqlfluff_requirements.return_value = ["sqlfluff==3.4.0"]
            mock_ds.get_dbt_requirements.return_value = ["dbt-core==1.9.0"]
            mock_ls.install_requirements.return_value = True

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["all"])

            assert exc.value.code == 0
            mock_ds.download_sqlfluff_config.assert_called_once()
            mock_ds.download_pipelines.assert_called_once()
            mock_ds.download_dbt_packages.assert_called_once()
            mock_ds.download_macros.assert_called_once()
            mock_ds.get_sqlfluff_requirements.assert_called_once()
            mock_ds.get_dbt_requirements.assert_called_once()
            assert mock_ls.install_requirements.call_count == 2

    @patch("datasecops_cli.main._connect_and_load")
    def test_download_failure_exits_1(self, mock_connect, tmp_path):
        config = self._make_config(tmp_path)
        mock_sf = MagicMock()
        mock_connect.return_value = mock_sf

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService"):
            mock_ds = MockDS.return_value
            mock_ds.download_sqlfluff_config.return_value = False  # failure

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["sqlfluff"])

            assert exc.value.code == 1

    @patch("datasecops_cli.main._connect_and_load")
    def test_download_partial_failure_exits_1(self, mock_connect, tmp_path):
        """If one item fails but another succeeds, exit code is still 1."""
        config = self._make_config(tmp_path)
        mock_sf = MagicMock()
        mock_connect.return_value = mock_sf

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService"):
            mock_ds = MockDS.return_value
            mock_ds.download_sqlfluff_config.return_value = True
            mock_ds.download_dbt_packages.return_value = False

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["sqlfluff", "packages"])

            assert exc.value.code == 1

    @patch("datasecops_cli.main._connect_and_load")
    def test_download_pipelines_uses_configured_platform(self, mock_connect, tmp_path):
        """Pipeline download reads platform from source_control config."""
        config = self._make_config(tmp_path)
        config.source_control.source_control_platform = "AzureDevOps"
        mock_sf = MagicMock()
        mock_connect.return_value = mock_sf

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService"):
            mock_ds = MockDS.return_value
            mock_ds.download_pipelines.return_value = True

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["pipelines"])

            assert exc.value.code == 0
            mock_ds.download_pipelines.assert_called_once_with(platform="azuredevops", profile_name="test_profile")

    @patch("datasecops_cli.main._connect_and_load")
    def test_install_sqlfluff(self, mock_connect, tmp_path):
        """install-sqlfluff fetches pinned versions and installs them."""
        config = self._make_config(tmp_path)
        mock_connect.return_value = MagicMock()

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService") as MockLS:
            mock_ds = MockDS.return_value
            mock_ls = MockLS.return_value
            mock_ds.get_sqlfluff_requirements.return_value = ["sqlfluff==3.4.0", "sqlfluff-templater-dbt==3.4.0"]
            mock_ls.install_requirements.return_value = True

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["install-sqlfluff"])

            assert exc.value.code == 0
            mock_ds.get_sqlfluff_requirements.assert_called_once()
            mock_ls.install_requirements.assert_called_once_with(
                ["sqlfluff==3.4.0", "sqlfluff-templater-dbt==3.4.0"]
            )

    @patch("datasecops_cli.main._connect_and_load")
    def test_install_dbt(self, mock_connect, tmp_path):
        """install-dbt fetches pinned versions and installs them."""
        config = self._make_config(tmp_path)
        mock_connect.return_value = MagicMock()

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService") as MockLS:
            mock_ds = MockDS.return_value
            mock_ls = MockLS.return_value
            mock_ds.get_dbt_requirements.return_value = ["dbt-core==1.9.0", "dbt-snowflake==1.9.0"]
            mock_ls.install_requirements.return_value = True

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["install-dbt"])

            assert exc.value.code == 0
            mock_ds.get_dbt_requirements.assert_called_once()
            mock_ls.install_requirements.assert_called_once_with(
                ["dbt-core==1.9.0", "dbt-snowflake==1.9.0"]
            )

    @patch("datasecops_cli.main._connect_and_load")
    def test_install_sqlfluff_no_versions_exits_1(self, mock_connect, tmp_path):
        """install-sqlfluff fails if no versions returned from framework."""
        config = self._make_config(tmp_path)
        mock_connect.return_value = MagicMock()

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService") as MockLS:
            mock_ds = MockDS.return_value
            mock_ls = MockLS.return_value
            mock_ds.get_sqlfluff_requirements.return_value = []

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["install-sqlfluff"])

            assert exc.value.code == 1
            mock_ls.install_requirements.assert_not_called()

    @patch("datasecops_cli.main._connect_and_load")
    def test_install_dbt_pip_failure_exits_1(self, mock_connect, tmp_path):
        """install-dbt exits 1 if uv pip install fails."""
        config = self._make_config(tmp_path)
        mock_connect.return_value = MagicMock()

        with patch("datasecops_cli.main.DownloadService") as MockDS, \
             patch("datasecops_cli.main.LintingService") as MockLS:
            mock_ds = MockDS.return_value
            mock_ls = MockLS.return_value
            mock_ds.get_dbt_requirements.return_value = ["dbt-core==1.9.0"]
            mock_ls.install_requirements.return_value = False  # pip failure

            with pytest.raises(SystemExit) as exc:
                _run_download(config, ["install-dbt"])

            assert exc.value.code == 1
