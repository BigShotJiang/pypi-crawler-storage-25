import os
import re
from typing import Optional

import pydantic
import yaml
from pydantic import ConfigDict, Field, ValidationError, field_validator, model_validator

from cli.utils import logger
from cli.utils.time import now_2_hash


class BaseModel(pydantic.BaseModel):
    model_config = ConfigDict(extra="forbid", coerce_numbers_to_str=True)


class ResourceConfig(BaseModel):
    cpu: str = Field(
        default="1",
        description="The CPU resource request for the sandbox. Default to '1'.",
    )
    memory: str = Field(
        default="2Gi", description="The memory resource limit for the sandbox. Default to '2Gi'."
    )
    accelerators: Optional[str] = Field(
        default=None,
        description="The accelerator resource limit for the sandbox, e.g., 'a100-80gb:8'.",
    )
    shmsize: Optional[str] = Field(
        default=None, description="The size of /dev/shm for the sandbox container, e.g., '1Gi'."
    )
    extended_resources: Optional[dict] = None


class KeyValueSet(BaseModel):
    name: str
    value: str


class PortConfig(BaseModel):
    port: int = Field(
        description="The port number inside the container.",
    )
    protocol: Optional[str] = Field(
        default="TCP",
        description="The protocol for the port. Default to 'TCP'.",
    )


class ServiceConfig(BaseModel):
    name: str
    image: str
    ports: Optional[list[PortConfig]] = None
    envs: Optional[list[KeyValueSet]] = None
    command: Optional[list[str]] = None
    args: Optional[list[str]] = None
    resources: ResourceConfig = Field(
        default_factory=ResourceConfig,
        description="Resource configuration for the service.",
    )


class SandboxConfig(BaseModel):
    base_image: str = Field(
        description="The base Docker image to use for the sandbox.",
    )
    workdir: str = Field(
        default="/app",
        description="The directory to the codebases. Default to /app.",
    )
    setup_script: Optional[str] = Field(
        description="The setup script to run before the experiment starts. This can be used to install dependencies or do any other setup work. Set to null if no installation steps are required.",
    )
    envs: Optional[list[KeyValueSet]] = Field(
        default=None,
        description="Environment variables to set in the sandbox container.",
    )
    evaluation_timeout: int = 60
    resources: ResourceConfig = Field(
        default_factory=ResourceConfig,
        description="Resource configuration for the sandbox.",
    )
    services: Optional[list[ServiceConfig]] = Field(
        default=None,
        description="Additional services to run alongside the sandbox.",
    )


class PromptConfig(BaseModel):
    enable_evolution: bool = Field(
        default=False,
        description="Whether to enable evolution for the experiment. Default to False.",
    )
    context: Optional[str] = Field(
        default=None,
        description="Some useful experiment-specific context to provide to the Hive.",
    )
    ideas: Optional[list[str]] = Field(
        default=None,
        description="A list of ideas which will be randomly sampled to inject into the Hive.",
    )


class RepoConfig(BaseModel):
    github_token: Optional[str] = Field(
        default=None,
        description="GitHub token with access to the repository. This is required if the source is a private GitHub repository.",
    )
    github_token_variable: Optional[str] = Field(
        default=None,
        description="Name of an environment variable containing the GitHub token.",
    )
    source: str
    branch: str = Field(
        default="main",
        description="The branch to use for the experiment. Default to 'main'.",
    )
    evaluation_script: str = Field(
        default="evaluation.py",
        description="The evaluation script to run for the experiment. Default to 'evaluation.py'.",
    )
    target_code: str = Field(
        description="The target code to evolve. A YAML list of files with optional ranges, e.g. ['file.py', 'file.py:1-10'].",
    )
    additional_context: str = Field(
        default_factory=list,
        validate_default=True,
        description="Additional content to include as context. A YAML list of files with optional ranges.",
    )

    @model_validator(mode="before")
    @classmethod
    def resolve_github_token_variable(cls, values):
        var_name = values.get("github_token_variable")
        if not var_name:
            return values
        token = os.environ.get(var_name)
        if not token:
            raise ValueError(
                f"github_token_variable='{var_name}' but ${var_name} is empty or not set."
            )
        if values.get("github_token"):
            raise ValueError("Cannot specify both github_token and github_token_variable.")
        values["github_token"] = token
        del values["github_token_variable"]
        return values

    @field_validator("source")
    @classmethod
    def source_should_not_be_git(cls, v):
        if v.startswith("git@"):
            raise ValueError("Only HTTPS URLs are allowed; git@ SSH URLs are not supported.")
        return v

    @field_validator("target_code", "additional_context", mode="before")
    @classmethod
    def normalize_file_list(cls, v):
        if isinstance(v, str):
            raise ValueError(
                "Must be a YAML list, not a plain string. "
                "Example:\n  target_code:\n    - file.py\n    - file.py:1-10"
            )
        if not isinstance(v, list):
            return v
        for entry in v:
            if not isinstance(entry, str):
                raise ValueError(f"Each entry must be a string, got: {type(entry).__name__}")
            if not re.fullmatch(r"[^:]+(?::\d+-\d+(?:&\d+-\d+)*)?", entry):
                raise ValueError(
                    f"Invalid file entry: '{entry}'. "
                    "Expected format: `file.py` or `file.py:1-10` or `file.py:1-10&21-30`."
                )
        return ",".join(v)


class RuntimeConfig(BaseModel):
    num_agents: int = Field(
        default=1,
        description="Number of agents to use in the experiment. Default to 1.",
    )
    max_runtime_seconds: int = Field(
        default=-1,
        description="Maximum runtime for the experiment in seconds. -1 means no limit.",
    )
    max_iterations: int = Field(
        default=-1,
        description="Maximum number of iterations for the experiment. -1 means no limit.",
    )


class HiveConfig(BaseModel):
    apiversion: str = Field(
        default="v1alpha1",
        description="Version for the configuration schema. Default to 'v1alpha1'.",
    )
    experiment_name: str = Field(
        description="The name of the experiment. If it ends with '-', a random suffix will be added for uniqueness.",
    )

    @field_validator("experiment_name")
    @classmethod
    def validate_experiment_name(cls, v):
        if v.endswith("-"):
            v = f"{v}{now_2_hash()}"
        if not re.fullmatch(r"[a-z0-9]([a-z0-9-]*[a-z0-9])?", v):
            raise ValueError(
                f"Experiment name must be a valid DNS label (RFC 1123): [a-z0-9] separated by '-', got: '{v}'"
            )
        if len(v) > 63:
            raise ValueError(
                f"Experiment name must be no more than 63 characters, got {len(v)}: '{v}'"
            )
        return v

    coordinator_config_name: str = Field(
        default="default-coordinator-config",
        description="The name of the coordinator config to use for the experiment. Default to 'default-coordinator-config'.",
    )
    runtime: RuntimeConfig = Field(
        default_factory=RuntimeConfig, description="Runtime configuration for the experiment."
    )
    repo: RepoConfig = Field(
        default_factory=RepoConfig,
        description="Repository configuration for the experiment.",
    )
    sandbox: SandboxConfig = Field(
        default_factory=SandboxConfig,
        description="Sandbox configuration for the experiment.",
    )
    prompt: Optional[PromptConfig] = None
    log_level: str = Field(
        default="INFO",
        enumerated=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        description="The logging level to use for the experiment. Default to 'INFO'.",
    )


def _lookup_description(schema: dict, loc: tuple) -> str | None:
    """Walk the JSON schema to find the description for a field at the given location."""
    defs = schema.get("$defs", {})
    current = schema
    for i, part in enumerate(loc):
        if isinstance(part, int):
            continue
        props = current.get("properties", {})
        if part not in props:
            return None
        field = props[part]
        if i == len(loc) - 1:
            return field.get("description")
        ref = field.get("$ref")
        if not ref:
            for option in field.get("anyOf", []):
                if "$ref" in option:
                    ref = option["$ref"]
                    break
        if ref:
            current = defs.get(ref.split("/")[-1], {})
        else:
            return None
    return None


def apply_overrides(cfg: dict, overrides: list[str]) -> dict:
    """Apply dot-notation overrides to a raw config dict before Pydantic validation.

    Supports two forms:
        foo.bar=value   Override an existing key (error if key doesn't exist).
        ~foo.bar        Delete a key (restores the Pydantic field default).

    Values are coerced via yaml.safe_load, so 4 -> int, true -> bool, etc.
    Type correctness and field existence within typed models are enforced by
    Pydantic at construction time.
    """
    for raw in overrides:
        if raw.startswith("~"):
            parts = raw[1:].split(".")
            d = cfg
            for p in parts[:-1]:
                d = d[p]
            del d[parts[-1]]
            continue
        key, _, val = raw.partition("=")
        parts, value = key.strip().split("."), yaml.safe_load(val)
        d = cfg
        for p in parts[:-1]:
            d = d.setdefault(p, {})
        d[parts[-1]] = value
    return cfg


def load_config(
    file_path: str,
    overrides: list[str] | None = None,
) -> HiveConfig:
    """Load configuration from a YAML file."""
    with open(file_path, "r") as file:
        config_data = yaml.safe_load(file)

    if overrides:
        apply_overrides(config_data, overrides)

    try:
        config = HiveConfig(**config_data)
    except ValidationError as e:
        schema = HiveConfig.model_json_schema()
        blocks = []
        for err in e.errors():
            loc = ".".join(str(p) for p in err["loc"])
            block = f"[bold]{loc}[/bold]: {err['msg']}"
            desc = _lookup_description(schema, err["loc"])
            if desc:
                block += f"\n  {desc}"
            blocks.append(block)
        msg = "\n\n".join(blocks)
        raise ValueError(msg) from None

    logger.set_log_level(config.log_level)
    return config
