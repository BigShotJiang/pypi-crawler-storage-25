import argparse
import logging
import os
import sys
import webbrowser
from importlib.metadata import PackageNotFoundError, version

import argcomplete
import yaml
from rich.console import Console
from rich.table import Table
from rich.text import Text

from cli import experiment
from cli.auth.auth_utils import get_machine_id
from cli.auth.credential_store import create_credential_store
from cli.auth.session_manager import create_session_manager
from cli.completers import config_file_completer, experiment_completer
from cli.config import load_config
from cli.http_client import HttpClient, create_http_client
from cli.utils.config_paths import get_config_dir, get_config_path, load_organization_id
from cli.utils.time import humanize_time
from cli.utils.url_utils import get_api_endpoint, get_dashboard_url

logger = logging.getLogger("hivekit")

try:
    __version__ = version("hivekit")
except PackageNotFoundError:
    __version__ = "unknown"


def _reject_overrides(overrides: list[str]) -> None:
    """Exit with error if overrides were passed to a command that doesn't support them."""
    if overrides:
        console = Console()
        console.print(f"[bold red]Error:[/bold red] Unexpected arguments: {' '.join(overrides)}")
        raise SystemExit(1)


def init(args) -> None:
    """Initialize a default Hive configuration."""
    console = Console()

    BLUE = "\033[94m"
    RESET = "\033[0m"

    ascii_art = r"""
 ███          █████   █████  ███                       █████   ████  ███   █████
░░░███       ░░███   ░░███  ░░░                       ░░███   ███░  ░░░   ░░███
  ░░░███      ░███    ░███  ████  █████ █████  ██████  ░███  ███    ████  ███████
    ░░░███    ░███████████ ░░███ ░░███ ░░███  ███░░███ ░███████    ░░███ ░░░███░
     ███░     ░███░░░░░███  ░███  ░███  ░███ ░███████  ░███░░███    ░███   ░███
   ███░       ░███    ░███  ░███  ░░███ ███  ░███░░░   ░███ ░░███   ░███   ░███ ███
 ███░         █████   █████ █████  ░░█████   ░░██████  █████ ░░████ █████  ░░█████
░░░          ░░░░░   ░░░░░ ░░░░░    ░░░░░     ░░░░░░  ░░░░░   ░░░░ ░░░░░    ░░░░░
    """

    print(f"{BLUE}{ascii_art}{RESET}")

    # Default config path
    config_dir = get_config_dir()
    config_path = get_config_path()

    # Check if config already exists
    if os.path.exists(config_path):
        msg = Text("Configuration file already exists at ", style="yellow")
        msg.append(config_path, style="bold yellow")
        console.print(msg)

        # Ask user if they want to overwrite
        response = input("Do you want to overwrite it? (y/N): ").strip().lower()
        if response not in ["y", "yes"]:
            console.print("Initialization cancelled.", style="bold red")
            return

    # Create config directory if it doesn't exist
    os.makedirs(config_dir, exist_ok=True)

    # Prompt for organization ID
    organization_id = input("Enter your organization ID: ").strip()
    if not organization_id:
        console.print("[bold red]Error:[/bold red] Organization ID is required.")
        return

    default_config = yaml.safe_dump({"organization_id": organization_id}, default_flow_style=False)

    # Write the default configuration
    with open(config_path, "w") as f:
        f.write(default_config)

    msg = Text("✓ Initialized Hive configuration at ", style="bold green")
    msg.append(config_path, style="bold magenta")
    console.print(msg)


def login(args) -> None:
    """Log in to the Hive platform via OIDC."""
    console = Console()

    try:
        organization_id = load_organization_id()
        insecure = getattr(args, "insecure", False)
        _run_login(console=console, organization_id=organization_id, insecure=insecure)
    except Exception as e:
        console.print(f"[bold red]✗ Login failed:[/bold red] {e}")


def logout(args) -> None:
    """
    Log out by clearing stored credentials for the currently configured organization.
    """
    console = Console()

    try:
        organization_id = load_organization_id()
        credential_store = create_credential_store(
            clients_dir=os.path.join(get_config_dir(), "clients"),
            machine_id_func=get_machine_id,
        )
        credential_store.delete_token(organization_id=organization_id)
        console.print(
            f"[bold green]✓ Cleared credentials for organization '{organization_id}'.[/bold green]"
        )
    except Exception as e:
        console.print(f"[bold red]✗ Logout failed:[/bold red] {e}")


def dashboard(args) -> None:
    """Open the Hive dashboard in the browser."""
    console = Console()

    organization_id = load_organization_id()
    url = get_dashboard_url(organization_id=organization_id)

    if args.no_browser:
        print(url)
    else:
        console.print(f"[bold green]Opening dashboard:[/bold green] {url}")
        webbrowser.open(url)


def create_experiment(args, overrides) -> None:
    """Create an experiment based on the config."""
    console = Console()

    try:
        config = load_config(args.config, overrides=overrides)
    except Exception as e:
        console.print(
            f"[bold red]Error:[/bold red] invalid config '{args.config}'.\n{e}", highlight=False
        )
        sys.exit(1)

    try:
        experiment_crd = experiment.build_experiment_crd(config)
    except Exception as e:
        console.print(f"Error building experiment CRD: {e}")
        return

    try:
        client = _get_http_client(args)
        _ = client.create_experiment(experiment_crd)
        console.print(f'experiment "[cyan]{config.experiment_name}[/cyan]" created')

    except Exception as e:
        console.print(f"[red]Error: Failed to create experiment: {e}[/red]")
        return


def delete_experiments(args) -> None:
    """Delete one or more experiments."""
    console = Console()

    experiment_names = args.name if isinstance(args.name, list) else [args.name]

    # Confirm deletion for batch operations unless -y flag is set
    # Single experiment deletions don't require confirmation
    if len(experiment_names) > 1 and not args.yes:
        prompt = (
            f"Are you sure you want to delete these {len(experiment_names)} experiments? (y/N): "
        )
        response = input(prompt).strip().lower()
        if response not in ["y", "yes"]:
            console.print("Deletion cancelled.")
            return

    try:
        client = _get_http_client(args)

        if len(experiment_names) == 1:
            # Single experiment deletion
            _ = client.delete_experiment(experiment_names[0])
            console.print(f'experiment "[cyan]{experiment_names[0]}[/cyan]" deleted')
        else:
            # Batch deletion
            results = client.delete_experiments_batch(experiment_names)

            # Display results
            success_count = 0
            for name, result in results.items():
                if result["success"]:
                    success_count += 1
                else:
                    console.print(
                        f'[red]Error deleting experiment "{name}": {result["error"]}[/red]'
                    )

            # Show total count
            total = len(experiment_names)
            if success_count == total:
                console.print(f"Total: {total} deleted")
            else:
                console.print(f"Total: {success_count}/{total} deleted")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        return


def list_experiments(args) -> None:
    """List all experiments."""
    console = Console()

    try:
        client = _get_http_client(args)
        result = client.list_experiments()
        experiments = result.get("experiments", [])

        if not experiments:
            console.print("No resources found.")
            return

        # Create a table to display experiments (Kubernetes style)
        table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
        table.add_column("NAME", no_wrap=True)
        table.add_column("AGENTS")
        table.add_column("STATUS")
        table.add_column("AGE")

        for exp in experiments:
            metadata = exp.get("metadata", {})
            spec = exp.get("spec", {})
            status = exp.get("status", {})

            name = metadata.get("name", "N/A")
            total_agents = spec.get("runtime", {}).get("numAgents", 0)

            # Calculate ready agents from sandboxReplicas - sandboxUnavailableReplicas
            sandbox_replicas = status.get("sandboxReplicas", 0)
            sandbox_unavailable = status.get("sandboxUnavailableReplicas", 0)
            ready_agents = sandbox_replicas - sandbox_unavailable

            phase = status.get("phase", "Unknown")
            created = metadata.get("creationTimestamp", "N/A")
            age = humanize_time(created)

            # Format agents as "ready/total"
            agents_display = f"{ready_agents}/{total_agents}"

            table.add_row(name, agents_display, phase, age)

        console.print(table)

    except Exception as e:
        console.print(f"[red]Error: Failed to list experiments: {e}[/red]")
        return


def get_experiment(args) -> None:
    """Get details of a specific experiment."""
    console = Console()

    experiment_name = args.name

    try:
        client = _get_http_client(args)
        exp = client.get_experiment(experiment_name)

        metadata = exp.get("metadata", {})
        spec = exp.get("spec", {})
        status = exp.get("status", {})

        # API Version section
        api_version = exp.get("apiVersion", "core.hiverge.io/v1alpha1")
        version = api_version.split("/")[-1]
        console.print(f"[bold]apiversion:[/bold] {version}")
        # Name section
        console.print(f"[bold]name:[/bold] {metadata.get('name', 'N/A')}", highlight=False)
        # Spec section
        console.print("[bold]spec[/bold]")
        # Repo subsection
        repo = spec.get("repo", {})
        console.print("  [bold]repo[/bold]")
        console.print(f"    source:             {repo.get('source', 'N/A')}")
        console.print(f"    branch:             {repo.get('branch', 'N/A')}")
        console.print(f"    evaluation_script:  {repo.get('evaluationScript', 'N/A')}")
        console.print(f"    target_code:        {repo.get('targetCode', 'N/A')}")
        # Runtime subsection
        runtime = spec.get("runtime", {})
        total_agents = runtime.get("numAgents", 0)
        sandbox_replicas = status.get("sandboxReplicas", 0)
        sandbox_unavailable = status.get("sandboxUnavailableReplicas", 0)
        ready_agents = sandbox_replicas - sandbox_unavailable

        # Format max runtime and iterations
        max_runtime = runtime.get("maxRuntimeSeconds", -1)
        max_runtime_display = f"{max_runtime}s" if max_runtime != -1 else "-1"

        max_iterations = runtime.get("maxIterations", -1)

        console.print("  [bold]runtime[/bold]")
        console.print(f"    agents:          {ready_agents}/{total_agents}")
        console.print(f"    max_runtime:     {max_runtime_display}")
        console.print(f"    max_iterations:  {max_iterations}")
        # Sandbox subsection
        sandbox = spec.get("sandbox", {})
        console.print("  [bold]sandbox[/bold]")
        console.print(
            f"    base_image:          {sandbox.get('baseImage', 'N/A')}", highlight=False
        )
        console.print(f"    evaluation_timeout:  {sandbox.get('evaluationTimeout', 'N/A')}s")
        setup_script = sandbox.get("setupScript")
        if setup_script:
            console.print("    setup_script:")
            for line in setup_script.rstrip("\n").split("\n"):
                console.print(f"      {line}")
        resources = sandbox.get("resources", {})
        if resources:
            limits = resources.get("limits", {})
            if limits:
                console.print("    resources:")
                console.print(f"      cpu:    {limits.get('cpu', 'N/A')}", highlight=False)
                console.print(f"      memory: {limits.get('memory', 'N/A')}")
        # Status section
        created = metadata.get("creationTimestamp", "N/A")
        age = humanize_time(created)
        phase = status.get("phase", "Unknown")

        console.print("[bold]status[/bold]")
        console.print(f"  created: {created} ({age} ago)", highlight=False)
        console.print(f"  phase:   {phase}")

        # Display condition message if available
        conditions = status.get("conditions", [])
        if conditions:
            # Look for condition with type matching the phase
            matching_condition = next(
                (cond for cond in conditions if cond.get("type") == phase), None
            )
            if matching_condition and matching_condition.get("message"):
                console.print(f"  message: {matching_condition.get('message')}")

    except Exception as e:
        console.print(f"[red]Error: Failed to get experiment: {e}[/red]")
        return


def _get_http_client(args: argparse.Namespace) -> HttpClient:
    """
    Build an HttpClient from the parsed command-line arguments.

    Reads the organization ID from the config file when authentication is
    enabled.
    """
    return create_http_client(
        organization_id=load_organization_id(),
        no_auth=getattr(args, "no_auth", False),
        insecure=getattr(args, "insecure", False),
    )


def _run_login(console: Console, organization_id: str, insecure: bool = False) -> None:
    """
    Run the OIDC login flow for the given organization.
    """
    session_manager = create_session_manager(
        organization_id=organization_id,
        base_url=get_api_endpoint(),
        insecure=insecure,
    )
    console.print("[yellow]Opening browser for login...[/yellow]")
    try:
        session_manager.login()
        console.print("[bold green]✓ Login successful![/bold green]")
    except Exception as e:
        console.print(f"[bold red]✗ Login failed:[/bold red] {e}")


def main():
    parser = argparse.ArgumentParser(description="Hive CLI")
    parser.add_argument(
        "--no_auth",
        action="store_true",
        default=False,
        help="Disable authentication",
    )
    parser.add_argument(
        "--insecure",
        action="store_true",
        default=False,
        help="Disable SSL certificate verification",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # init command
    parser_init = subparsers.add_parser("init", help="Initialize the Hive configuration")
    parser_init.set_defaults(func=init)

    # login command
    parser_login = subparsers.add_parser("login", help="Log in to the Hive platform")
    parser_login.set_defaults(func=login)

    # logout command
    parser_logout = subparsers.add_parser("logout", help="Log out and clear stored credentials")
    parser_logout.set_defaults(func=logout)

    # dashboard command
    parser_dashboard = subparsers.add_parser("dashboard", help="Open the Hive dashboard")
    parser_dashboard.add_argument(
        "--no-browser",
        action="store_true",
        default=False,
        dest="no_browser",
        help="Print the URL without opening a browser",
    )
    parser_dashboard.set_defaults(func=dashboard)

    # create command
    parser_create = subparsers.add_parser("create", help="Create resources")
    create_subparsers = parser_create.add_subparsers(dest="create_target")

    parser_create_exp = create_subparsers.add_parser(
        "experiment", aliases=["exp"], help="Create a new experiment"
    )
    parser_create_exp.add_argument(
        "-f",
        "--config",
        required=True,
        help="Path to the experiment config file",
    ).completer = config_file_completer
    parser_create_exp.set_defaults(func=create_experiment)

    # delete command
    parser_delete = subparsers.add_parser("delete", help="Delete resources")
    delete_subparsers = parser_delete.add_subparsers(dest="delete_target")
    parser_delete_exp = delete_subparsers.add_parser(
        "experiment", aliases=["exp", "exp"], help="Delete one or more experiments"
    )
    parser_delete_exp.add_argument(
        "name", nargs="+", help="Name(s) of the experiment(s) to delete"
    ).completer = experiment_completer
    parser_delete_exp.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip confirmation prompt",
    )
    parser_delete_exp.set_defaults(func=delete_experiments)

    # list command
    parser_list = subparsers.add_parser("list", help="List resources")
    list_subparsers = parser_list.add_subparsers(dest="list_target")

    # list experiments
    parser_list_exp = list_subparsers.add_parser(
        "experiments", aliases=["exp", "exps"], help="List all experiments"
    )
    parser_list_exp.set_defaults(func=list_experiments)

    # get command
    parser_get = subparsers.add_parser("get", help="Get resource details")
    get_subparsers = parser_get.add_subparsers(dest="get_target")

    # get experiment
    parser_get_exp = get_subparsers.add_parser(
        "experiment", aliases=["exp"], help="Get experiment details"
    )
    parser_get_exp.add_argument(
        "name", help="Name of the experiment"
    ).completer = experiment_completer
    parser_get_exp.set_defaults(func=get_experiment)

    argcomplete.autocomplete(parser)
    args, overrides = parser.parse_known_args()
    if hasattr(args, "func"):
        if args.func == create_experiment:
            args.func(args, overrides)
        else:
            _reject_overrides(overrides)
            args.func(args)
    else:
        parser.print_help()
