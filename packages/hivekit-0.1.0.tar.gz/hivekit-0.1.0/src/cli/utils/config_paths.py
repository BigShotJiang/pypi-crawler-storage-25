"""
Common configuration paths for the Hive CLI.
"""

import os

import yaml

_CONFIG_DIR = os.path.expandvars("$HOME/.hive")
_CONFIG_PATH = os.path.join(_CONFIG_DIR, "config.yaml")


def get_config_dir() -> str:
    """
    Return the path to the Hive configuration directory.
    """
    return _CONFIG_DIR


def get_config_path() -> str:
    """
    Return the path to the Hive configuration file.
    """
    return _CONFIG_PATH


def load_organization_id() -> str:
    """Load the organization ID from ~/.hive/config.yaml."""
    config_path = get_config_path()
    if not os.path.exists(config_path):
        raise FileNotFoundError("No configuration found. Please run 'hive init' first.")

    with open(config_path, "r") as f:
        data = yaml.safe_load(f)

    org_id = data.get("organization_id") if data else None
    if not org_id:
        raise ValueError("No organization_id found in config. Please run 'hive init' to set it.")

    return org_id
