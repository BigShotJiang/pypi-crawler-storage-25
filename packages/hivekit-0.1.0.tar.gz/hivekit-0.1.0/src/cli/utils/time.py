import hashlib
from datetime import datetime, timezone


def humanize_time(timestamp: str) -> str:
    """
    Format a timestamp as a Kubernetes-style age string (e.g., 5m, 2h, 3d).

    Supports multiple timestamp formats:
    - ISO 8601 with 'Z' suffix: "2023-04-20T10:30:00Z"
    - ISO 8601 with timezone: "2023-04-20T10:30:00+00:00"
    - ISO 8601 without timezone (assumes UTC): "2023-04-20T10:30:00"

    Args:
        timestamp: ISO 8601 timestamp string

    Returns:
        Formatted age string (e.g., "5s", "3m", "2h", "7d")
    """
    try:
        # Parse the timestamp (handle multiple formats)
        if timestamp.endswith("Z"):
            creation_time = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        elif "+" in timestamp or timestamp.count("-") > 2:
            # Has timezone info
            creation_time = datetime.fromisoformat(timestamp)
        else:
            # Assume UTC if no timezone
            creation_time = datetime.fromisoformat(timestamp).replace(tzinfo=timezone.utc)

        # Calculate age
        t = datetime.now(timezone.utc) - creation_time
        seconds = int(t.total_seconds())

        # Handle negative time (clock skew)
        if seconds < 0:
            return "0s"

        # Format like Kubernetes
        if seconds < 60:
            return f"{seconds}s"
        elif seconds < 3600:
            return f"{seconds // 60}m"
        elif seconds < 86400:
            return f"{seconds // 3600}h"
        else:
            return f"{seconds // 86400}d"
    except Exception:
        # If parsing fails, return the original timestamp
        return timestamp


def now_2_hash() -> str:
    timestamp = str(int(datetime.now(timezone.utc).timestamp()))
    unique_hash = hashlib.sha1(timestamp.encode()).hexdigest()[:7]

    return unique_hash
