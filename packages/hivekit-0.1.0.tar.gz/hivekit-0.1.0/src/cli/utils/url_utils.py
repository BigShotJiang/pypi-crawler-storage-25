"""
Utility functions for deriving OIDC-related URLs and the API endpoint.
"""

import os
from urllib.parse import urlparse

_DEFAULT_API_BASE_URL = "https://app.platform.live.hiverge.ai"
_MONOLITH_API_PATH = "monolith/api/v1"


def get_api_endpoint() -> str:
    """
    Return the API endpoint for the Hiverge monolith API.

    The base URL is taken from the HIVE_API_ENDPOINT environment variable,
    or a default if not set (an empty value is treated as unset). Users only
    need to configure the base URL of the Hiverge deployment: the monolith
    API path (`monolith/api/v1`) is appended automatically. If the configured
    value already ends with that path it is returned unchanged, so legacy
    configurations that include it continue to work.
    """
    configured = os.getenv("HIVE_API_ENDPOINT") or _DEFAULT_API_BASE_URL
    normalized = configured.rstrip("/")
    if normalized.endswith(f"/{_MONOLITH_API_PATH}"):
        return normalized
    return f"{normalized}/{_MONOLITH_API_PATH}"


def derive_identity_base_url(api_endpoint: str) -> str:
    """
    Derive the identity provider base URL from the API endpoint.

    Strips the entire path from the URL and appends `/identity`.
    For example, `https://app.platform.live.hiverge.ai/monolith/api/v1`
    becomes `https://app.platform.live.hiverge.ai/identity`.
    """
    parsed = urlparse(api_endpoint)
    return f"{parsed.scheme}://{parsed.netloc}/identity"


def get_dashboard_url(organization_id: str) -> str:
    """
    Derive the Alphatrion dashboard URL from the configured API endpoint.

    Strips the path and appends ``/static/``. The organization ID is included
    as a query parameter so the dashboard pre-selects the org.
    """
    api_endpoint = get_api_endpoint()
    parsed = urlparse(api_endpoint)
    return f"{parsed.scheme}://{parsed.netloc}/static/?organization_id={organization_id}"


def build_oidc_endpoints(identity_base_url: str, organization_id: str) -> dict[str, str]:
    """
    Build the OIDC endpoint URLs for a given organization.

    Returns a dict with `authorization_endpoint`, `token_endpoint`, and
    `userinfo_endpoint` keys.
    """
    base = identity_base_url.rstrip("/")
    realm_base = f"{base}/realms/{organization_id}/protocol/openid-connect"
    return {
        "authorization_endpoint": f"{realm_base}/auth",
        "token_endpoint": f"{realm_base}/token",
        "userinfo_endpoint": f"{realm_base}/userinfo",
    }
