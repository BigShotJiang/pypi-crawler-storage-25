from typing import Any, Dict

from cli.config import HiveConfig


def build_experiment_crd(config: HiveConfig) -> Dict[str, Any]:
    """Build a Kubernetes Experiment CRD from HiveConfig."""
    experiment = {
        "apiVersion": "core.hiverge.io/v1alpha1",
        "kind": "Experiment",
        "metadata": {
            "name": config.experiment_name,
        },
        "spec": {
            "runtime": {
                "numAgents": config.runtime.num_agents,
                "maxRuntimeSeconds": config.runtime.max_runtime_seconds,
                "maxIterations": config.runtime.max_iterations,
            },
            "repo": {
                "source": config.repo.source,
                "branch": config.repo.branch,
                "evaluationScript": config.repo.evaluation_script,
                "targetCode": config.repo.target_code,
            },
            "sandbox": {
                "baseImage": config.sandbox.base_image,
                "workdir": config.sandbox.workdir,
                "evaluationTimeout": config.sandbox.evaluation_timeout,
                "resources": {
                    "limits": {
                        "cpu": config.sandbox.resources.cpu,
                        "memory": config.sandbox.resources.memory,
                    },
                },
            },
        },
    }

    # Add optional repo fields
    if config.repo.additional_context:
        experiment["spec"]["repo"]["additionalContext"] = config.repo.additional_context

    # Add optional sandbox fields
    if config.sandbox.base_image:
        experiment["spec"]["sandbox"]["baseImage"] = config.sandbox.base_image

    if config.sandbox.resources.accelerators:
        experiment["spec"]["sandbox"]["resources"]["accelerators"] = (
            config.sandbox.resources.accelerators
        )

    if config.sandbox.resources.shmsize:
        experiment["spec"]["sandbox"]["resources"]["shmsize"] = config.sandbox.resources.shmsize

    if config.sandbox.resources.extended_resources:
        experiment["spec"]["sandbox"]["resources"]["limits"].update(
            config.sandbox.resources.extended_resources
        )

    if config.sandbox.envs:
        experiment["spec"]["sandbox"]["envs"] = [
            {"name": env.name, "value": env.value} for env in config.sandbox.envs
        ]

    if config.sandbox.setup_script:
        experiment["spec"]["sandbox"]["setupScript"] = config.sandbox.setup_script

    if config.sandbox.services:
        experiment["spec"]["sandbox"]["services"] = [
            {
                "name": svc.name,
                "image": svc.image,
                **(
                    {"ports": [{"port": p.port, "protocol": p.protocol} for p in svc.ports]}
                    if svc.ports
                    else {}
                ),
                **(
                    {"envs": [{"name": e.name, "value": e.value} for e in svc.envs]}
                    if svc.envs
                    else {}
                ),
                **({"command": svc.command} if svc.command else {}),
                **({"args": svc.args} if svc.args else {}),
                "resources": {
                    "cpu": svc.resources.cpu,
                    "memory": svc.resources.memory,
                },
            }
            for svc in config.sandbox.services
        ]

    # Add optional prompt configuration
    if config.prompt:
        experiment["spec"]["prompt"] = {}
        if config.prompt.context:
            experiment["spec"]["prompt"]["context"] = config.prompt.context
        if config.prompt.ideas:
            experiment["spec"]["prompt"]["ideas"] = config.prompt.ideas
        if config.prompt.enable_evolution:
            experiment["spec"]["prompt"]["enableEvolution"] = config.prompt.enable_evolution

    # Add coordinator config
    if config.coordinator_config_name:
        experiment["spec"]["coordinatorConfigName"] = config.coordinator_config_name

    # TODO: quick hack to support private github repo, will be replaced by github app in the future.
    if config.repo.github_token:
        experiment["metadata"]["annotations"] = {
            "github.com/token": config.repo.github_token,
        }

    return experiment
