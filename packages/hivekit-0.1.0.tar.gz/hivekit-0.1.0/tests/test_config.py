"""Tests for config validation."""

import pytest
import yaml

from cli.config import RepoConfig, load_config

VALID_SOURCE = "https://github.com/org/repo.git"


def _repo(**kwargs):
    defaults = {"target_code": ["main.py"]}
    defaults.update(kwargs)
    return RepoConfig(source=VALID_SOURCE, **defaults)


MINIMAL_CONFIG = {
    "experiment_name": "test-exp",
    "repo": {
        "source": "https://github.com/test/repo.git",
        "branch": "main",
        "evaluation_script": "evaluation.py",
        "target_code": ["main.py"],
    },
    "runtime": {
        "num_agents": 1,
        "max_runtime_seconds": -1,
        "max_iterations": -1,
    },
    "sandbox": {
        "base_image": "python:3.12-slim",
        "setup_script": "setup.sh",
        "evaluation_timeout": 60,
        "resources": {"cpu": "1", "memory": "2Gi"},
    },
}


@pytest.fixture
def base_config(tmp_path):
    cfg = tmp_path / "config.yaml"
    cfg.write_text(yaml.safe_dump(MINIMAL_CONFIG))
    return str(cfg)


class TestGithubTokenVar:
    """Tests for github_token_variable resolution."""

    def test_resolves_from_env(self, monkeypatch):
        monkeypatch.setenv("MY_GH_TOKEN", "ghp_abc123")
        r = _repo(github_token_variable="MY_GH_TOKEN")
        assert r.github_token == "ghp_abc123"

    def test_rejects_missing_env_var(self, monkeypatch):
        monkeypatch.delenv("MISSING_VAR", raising=False)
        with pytest.raises(Exception, match="empty or not set"):
            _repo(github_token_variable="MISSING_VAR")

    def test_rejects_empty_env_var(self, monkeypatch):
        monkeypatch.setenv("EMPTY_VAR", "")
        with pytest.raises(Exception, match="empty or not set"):
            _repo(github_token_variable="EMPTY_VAR")

    def test_rejects_both_token_and_var(self, monkeypatch):
        monkeypatch.setenv("MY_GH_TOKEN", "ghp_abc123")
        with pytest.raises(Exception, match="Cannot specify both"):
            _repo(github_token="direct_token", github_token_variable="MY_GH_TOKEN")

    def test_neither_specified(self):
        r = _repo()
        assert r.github_token is None

    def test_direct_token_still_works(self):
        r = _repo(github_token="ghp_direct")
        assert r.github_token == "ghp_direct"


class TestTargetCodeValidation:
    """target_code must be a YAML list; entries are validated then joined."""

    @pytest.mark.parametrize(
        "value",
        [
            ["file.py"],
            ["main.cpp"],
            ["src/deep/path/file.rs"],
            ["file.py:1-10"],
            ["file.py:1-10&21-30"],
            ["file.py:1-10&21-30&100-200"],
            ["foo.cpp", "bar.hpp"],
            ["foo.cpp", "bar.hpp:1-10"],
            ["foo.cpp:1-5", "bar.hpp:10-20&30-40"],
            ["../relative/path.py"],
            ["./local.py"],
            ["file-with-dashes.py"],
            ["file_with_underscores.py"],
            ["file.test.spec.ts"],
            ["my file.cpp", "other.py"],
        ],
    )
    def test_valid_list(self, value):
        r = _repo(target_code=value)
        assert r.target_code == ",".join(value)

    @pytest.mark.parametrize(
        "value,match",
        [
            (["foo:.cpp"], "Invalid file entry"),
            (["foo.cpp:abc"], "Invalid file entry"),
            (["foo.cpp:a-b"], "Invalid file entry"),
            (["foo.cpp:1-"], "Invalid file entry"),
            (["foo.cpp:-10"], "Invalid file entry"),
            (["foo.cpp:1-3|4-9"], "Invalid file entry"),
            (["foo.cpp:1-10&"], "Invalid file entry"),
            (["foo.cpp:1-10&abc"], "Invalid file entry"),
        ],
    )
    def test_invalid_entries(self, value, match):
        with pytest.raises(Exception, match=match):
            _repo(target_code=value)

    def test_rejects_plain_string(self):
        with pytest.raises(Exception, match="Must be a YAML list"):
            _repo(target_code="foo.cpp")

    def test_rejects_comma_separated_string(self):
        with pytest.raises(Exception, match="Must be a YAML list"):
            _repo(target_code="foo.cpp,bar.hpp")

    def test_single_element(self):
        r = _repo(target_code=["main.py"])
        assert r.target_code == "main.py"

    def test_joined_with_commas(self):
        r = _repo(target_code=["a.py", "b.py", "c.py"])
        assert r.target_code == "a.py,b.py,c.py"


class TestAdditionalContextValidation:
    """Same validator applies to additional_context."""

    def test_valid_list(self):
        r = _repo(additional_context=["utils.py:1-10", "helpers.py"])
        assert r.additional_context == "utils.py:1-10,helpers.py"

    def test_rejects_string(self):
        with pytest.raises(Exception, match="Must be a YAML list"):
            _repo(additional_context="utils.py:1-10,helpers.py")

    def test_default_is_empty(self):
        r = _repo()
        assert r.additional_context == ""

    def test_empty_list(self):
        r = _repo(additional_context=[])
        assert r.additional_context == ""


class TestExperimentNameValidation:
    """RFC 1123 DNS label validation: [a-z0-9], separated by '-', max 63 chars."""

    def test_valid_name(self, base_config):
        config = load_config(base_config, overrides=["experiment_name=my-exp-1"])
        assert config.experiment_name == "my-exp-1"

    def test_rejects_uppercase(self, base_config):
        with pytest.raises(Exception, match="DNS label"):
            load_config(base_config, overrides=["experiment_name=My-Exp"])

    def test_rejects_underscore(self, base_config):
        with pytest.raises(Exception, match="DNS label"):
            load_config(base_config, overrides=["experiment_name=my_exp"])

    def test_rejects_leading_hyphen(self, base_config):
        with pytest.raises(Exception, match="DNS label"):
            load_config(base_config, overrides=["experiment_name=-leading"])

    def test_rejects_trailing_hyphen_without_suffix(self, base_config):
        config = load_config(base_config, overrides=["experiment_name=exp-"])
        assert not config.experiment_name.endswith("-")

    def test_rejects_dot(self, base_config):
        with pytest.raises(Exception, match="DNS label"):
            load_config(base_config, overrides=["experiment_name=my.exp"])

    def test_rejects_too_long(self, base_config):
        with pytest.raises(Exception, match="63 characters"):
            load_config(base_config, overrides=["experiment_name=" + "a" * 64])
