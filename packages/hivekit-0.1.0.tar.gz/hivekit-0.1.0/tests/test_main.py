"""
Unit tests for CLI command functions in main.py.
"""

from unittest.mock import MagicMock, patch

import pytest
from rich.console import Console

from cli.main import get_experiment


@pytest.fixture(name="mock_args")
def _mock_args() -> MagicMock:
    """Mock command-line arguments."""
    args = MagicMock()
    args.name = "test-experiment"
    args.no_auth = False
    args.insecure = False
    return args


@pytest.fixture(name="sample_experiment")
def _sample_experiment() -> dict:
    """Sample experiment response from API."""
    return {
        "apiVersion": "core.hiverge.io/v1alpha1",
        "metadata": {
            "name": "test-experiment",
            "creationTimestamp": "2024-01-15T10:30:00Z",
        },
        "spec": {
            "repo": {
                "source": "https://github.com/example/repo.git",
                "branch": "main",
                "evaluationScript": "evaluation.py",
                "targetCode": "main.py",
            },
            "runtime": {
                "numAgents": 3,
                "maxRuntimeSeconds": 3600,
                "maxIterations": 100,
            },
            "sandbox": {
                "baseImage": "python:3.9-slim",
                "evaluationTimeout": 60,
                "setupScript": "pip install -r requirements.txt\npip install pytest",
                "resources": {
                    "limits": {
                        "cpu": "2",
                        "memory": "4Gi",
                    }
                },
            },
        },
        "status": {
            "phase": "Running",
            "sandboxReplicas": 2,
            "sandboxUnavailableReplicas": 1,
            "conditions": [
                {
                    "type": "Running",
                    "status": "True",
                    "message": "Experiment is running successfully",
                }
            ],
        },
    }


class TestGetExperiment:
    """Tests for the get_experiment CLI command."""

    @patch("cli.main._get_http_client")
    @patch("cli.main.Console")
    def test_get_experiment_full_display(
        self,
        mock_console_class: MagicMock,
        mock_get_http_client: MagicMock,
        mock_args: MagicMock,
        sample_experiment: dict,
    ) -> None:
        """Test that get_experiment displays all fields correctly."""
        # Setup
        mock_client = MagicMock()
        mock_client.get_experiment.return_value = sample_experiment
        mock_get_http_client.return_value = mock_client

        mock_console = MagicMock(spec=Console)
        mock_console_class.return_value = mock_console

        # Execute
        get_experiment(mock_args)

        # Verify client was called
        mock_client.get_experiment.assert_called_once_with("test-experiment")

        # Verify output contains key information
        calls = mock_console.print.call_args_list
        output = "\n".join(str(call[0][0]) if call[0] else "" for call in calls)

        # Check that all major sections are present
        assert "name:" in output.lower()
        assert "test-experiment" in output
        assert "apiversion:" in output.lower()
        assert "v1alpha1" in output
        assert "spec" in output.lower()
        assert "repo" in output.lower()
        assert "runtime" in output.lower()
        assert "sandbox" in output.lower()
        assert "status" in output.lower()

        # Check repo fields
        assert "https://github.com/example/repo.git" in output
        assert "main" in output
        assert "evaluation.py" in output
        assert "main.py" in output

        # Check runtime fields
        assert "1/3" in output  # ready/total agents (sandboxReplicas=2, unavailable=1, so ready=1)
        assert "3600s" in output  # max runtime
        assert "100" in output  # max iterations

        # Check sandbox fields
        assert "python:3.9-slim" in output
        assert "60s" in output  # evaluation timeout

    @patch("cli.main._get_http_client")
    @patch("cli.main.Console")
    def test_get_experiment_with_setup_script(
        self,
        mock_console_class: MagicMock,
        mock_get_http_client: MagicMock,
        mock_args: MagicMock,
        sample_experiment: dict,
    ) -> None:
        """Test that setup script is displayed with proper formatting."""
        # Setup
        mock_client = MagicMock()
        mock_client.get_experiment.return_value = sample_experiment
        mock_get_http_client.return_value = mock_client

        mock_console = MagicMock(spec=Console)
        mock_console_class.return_value = mock_console

        # Execute
        get_experiment(mock_args)

        # Verify setup script is displayed
        calls = mock_console.print.call_args_list
        output = "\n".join(str(call[0][0]) if call[0] else "" for call in calls)

        assert "setup_script:" in output.lower()
        assert "pip install -r requirements.txt" in output
        assert "pip install pytest" in output

    @patch("cli.main._get_http_client")
    @patch("cli.main.Console")
    def test_get_experiment_with_condition_message(
        self,
        mock_console_class: MagicMock,
        mock_get_http_client: MagicMock,
        mock_args: MagicMock,
        sample_experiment: dict,
    ) -> None:
        """Test that condition message matching phase is displayed."""
        # Setup
        mock_client = MagicMock()
        mock_client.get_experiment.return_value = sample_experiment
        mock_get_http_client.return_value = mock_client

        mock_console = MagicMock(spec=Console)
        mock_console_class.return_value = mock_console

        # Execute
        get_experiment(mock_args)

        # Verify condition message is displayed
        calls = mock_console.print.call_args_list
        output = "\n".join(str(call[0][0]) if call[0] else "" for call in calls)

        assert "message:" in output.lower()
        assert "Experiment is running successfully" in output

    @patch("cli.main._get_http_client")
    @patch("cli.main.Console")
    def test_get_experiment_without_setup_script(
        self,
        mock_console_class: MagicMock,
        mock_get_http_client: MagicMock,
        mock_args: MagicMock,
        sample_experiment: dict,
    ) -> None:
        """Test that setup script section is omitted when not present."""
        # Setup - remove setup script
        sample_experiment["spec"]["sandbox"].pop("setupScript")

        mock_client = MagicMock()
        mock_client.get_experiment.return_value = sample_experiment
        mock_get_http_client.return_value = mock_client

        mock_console = MagicMock(spec=Console)
        mock_console_class.return_value = mock_console

        # Execute
        get_experiment(mock_args)

        # Verify setup script is not displayed
        calls = mock_console.print.call_args_list
        output = "\n".join(str(call[0][0]) if call[0] else "" for call in calls)

        assert "setup_script:" not in output.lower()

    @patch("cli.main._get_http_client")
    @patch("cli.main.Console")
    def test_get_experiment_without_condition_message(
        self,
        mock_console_class: MagicMock,
        mock_get_http_client: MagicMock,
        mock_args: MagicMock,
        sample_experiment: dict,
    ) -> None:
        """Test that message is omitted when no matching condition exists."""
        # Setup - remove conditions
        sample_experiment["status"]["conditions"] = []

        mock_client = MagicMock()
        mock_client.get_experiment.return_value = sample_experiment
        mock_get_http_client.return_value = mock_client

        mock_console = MagicMock(spec=Console)
        mock_console_class.return_value = mock_console

        # Execute
        get_experiment(mock_args)

        # Verify message is not displayed
        calls = mock_console.print.call_args_list
        output = "\n".join(str(call[0][0]) if call[0] else "" for call in calls)

        # Message label should not appear
        assert output.count("message:") == 0

    @patch("cli.main._get_http_client")
    @patch("cli.main.Console")
    def test_get_experiment_max_runtime_na(
        self,
        mock_console_class: MagicMock,
        mock_get_http_client: MagicMock,
        mock_args: MagicMock,
        sample_experiment: dict,
    ) -> None:
        """Test that -1 values are displayed as -1."""
        # Setup - set -1 for max runtime and iterations
        sample_experiment["spec"]["runtime"]["maxRuntimeSeconds"] = -1
        sample_experiment["spec"]["runtime"]["maxIterations"] = -1

        mock_client = MagicMock()
        mock_client.get_experiment.return_value = sample_experiment
        mock_get_http_client.return_value = mock_client

        mock_console = MagicMock(spec=Console)
        mock_console_class.return_value = mock_console

        # Execute
        get_experiment(mock_args)

        # Verify -1 is displayed
        calls = mock_console.print.call_args_list
        output = "\n".join(str(call[0][0]) if call[0] else "" for call in calls)

        # Should have -1 for max runtime and max iterations
        assert "max_runtime:     -1" in output
        assert "max_iterations:  -1" in output

    @patch("cli.main._get_http_client")
    @patch("cli.main.Console")
    def test_get_experiment_error_handling(
        self,
        mock_console_class: MagicMock,
        mock_get_http_client: MagicMock,
        mock_args: MagicMock,
    ) -> None:
        """Test that errors are handled gracefully."""
        # Setup
        mock_client = MagicMock()
        mock_client.get_experiment.side_effect = Exception("API error")
        mock_get_http_client.return_value = mock_client

        mock_console = MagicMock(spec=Console)
        mock_console_class.return_value = mock_console

        # Execute
        get_experiment(mock_args)

        # Verify error message is displayed
        calls = mock_console.print.call_args_list
        output = "\n".join(str(call[0][0]) if call[0] else "" for call in calls)

        assert "Error" in output or "error" in output
        assert "API error" in output
