"""
Tests for the `logout` command in main.py.
"""

import os
from unittest.mock import MagicMock

import pytest
from pytest_mock import MockerFixture

from cli.main import logout


@pytest.fixture(name="mock_args")
def _mock_args() -> MagicMock:
    """
    A mock argparse namespace.
    """
    return MagicMock()


class TestLogout:
    """
    Tests for the `logout` function.
    """

    def test_clears_credentials_for_configured_organization(
        self,
        mocker: MockerFixture,
        tmp_path: str,
        mock_args: MagicMock,
    ) -> None:
        """
        Test that logout deletes the token for the organization found in the config file.
        """
        # given
        config_dir = str(tmp_path)
        clients_dir = os.path.join(config_dir, "clients")

        mocker.patch("cli.main.load_organization_id", return_value="my-org")

        mock_create_store = mocker.patch("cli.main.create_credential_store")
        mock_store = MagicMock()
        mock_create_store.return_value = mock_store

        mocker.patch("cli.main.get_config_dir", return_value=config_dir)

        # when
        logout(mock_args)

        # then
        mock_create_store.assert_called_once_with(
            clients_dir=clients_dir,
            machine_id_func=pytest.importorskip("cli.auth.auth_utils").get_machine_id,
        )
        mock_store.delete_token.assert_called_once_with(organization_id="my-org")

    def test_prints_error_when_no_config_file(
        self,
        mocker: MockerFixture,
        tmp_path: str,
        mock_args: MagicMock,
    ) -> None:
        """
        Test that logout prints an error when no config file exists.
        """
        # given
        config_path = os.path.join(str(tmp_path), "nonexistent_config.yaml")
        mocker.patch("cli.main.get_config_path", return_value=config_path)

        # when
        logout(mock_args)

        # then — no exception raised, error message printed to console

    def test_prints_error_when_no_organization_id_in_config(
        self,
        mocker: MockerFixture,
        tmp_path: str,
        mock_args: MagicMock,
    ) -> None:
        """
        Test that logout prints an error when the config has no organization_id.
        """
        # given
        mocker.patch(
            "cli.main.load_organization_id",
            side_effect=ValueError("No organization_id found in config."),
        )

        mock_create_store = mocker.patch("cli.main.create_credential_store")

        # when
        logout(mock_args)

        # then
        mock_create_store.assert_not_called()

    def test_handles_delete_token_failure_gracefully(
        self,
        mocker: MockerFixture,
        tmp_path: str,
        mock_args: MagicMock,
    ) -> None:
        """
        Test that logout handles delete_token exceptions gracefully.
        """
        # given
        config_dir = str(tmp_path)

        mocker.patch("cli.main.load_organization_id", return_value="my-org")

        mock_create_store = mocker.patch("cli.main.create_credential_store")
        mock_store = MagicMock()
        mock_store.delete_token.side_effect = Exception("Keyring error")
        mock_create_store.return_value = mock_store

        mocker.patch("cli.main.get_config_dir", return_value=config_dir)

        # when
        logout(mock_args)

        # then
        mock_store.delete_token.assert_called_once_with(organization_id="my-org")
