"""
Unit tests for the time utility functions.
"""

from datetime import datetime, timedelta, timezone

from cli.utils.time import humanize_time


class TestHumanizeTime:
    """
    Tests for the `humanize_time` function.
    """

    def test_humanize_time_seconds(self) -> None:
        """
        Test that times less than a minute are formatted as seconds.
        """
        now = datetime.now(timezone.utc)
        timestamp = (now - timedelta(seconds=45)).strftime("%Y-%m-%dT%H:%M:%SZ")
        result = humanize_time(timestamp)
        assert result.endswith("s")
        assert int(result[:-1]) >= 44  # Allow for 1 second variance
        assert int(result[:-1]) <= 46

    def test_humanize_time_minutes(self) -> None:
        """
        Test that times less than an hour are formatted as minutes.
        """
        now = datetime.now(timezone.utc)
        timestamp = (now - timedelta(minutes=15)).strftime("%Y-%m-%dT%H:%M:%SZ")
        result = humanize_time(timestamp)
        assert result.endswith("m")
        assert int(result[:-1]) >= 14  # Allow for variance
        assert int(result[:-1]) <= 16

    def test_humanize_time_hours(self) -> None:
        """
        Test that times less than a day are formatted as hours.
        """
        now = datetime.now(timezone.utc)
        timestamp = (now - timedelta(hours=5)).strftime("%Y-%m-%dT%H:%M:%SZ")
        result = humanize_time(timestamp)
        assert result.endswith("h")
        assert int(result[:-1]) >= 4  # Allow for variance
        assert int(result[:-1]) <= 6

    def test_humanize_time_days(self) -> None:
        """
        Test that times of a day or more are formatted as days.
        """
        now = datetime.now(timezone.utc)
        timestamp = (now - timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%SZ")
        result = humanize_time(timestamp)
        assert result.endswith("d")
        assert int(result[:-1]) >= 6  # Allow for variance
        assert int(result[:-1]) <= 8

    def test_humanize_time_with_z_suffix(self) -> None:
        """
        Test timestamp with 'Z' suffix (Zulu/UTC time).
        """
        now = datetime.now(timezone.utc)
        timestamp = (now - timedelta(minutes=10)).isoformat().replace("+00:00", "Z")
        result = humanize_time(timestamp)
        assert result.endswith("m")
        assert int(result[:-1]) >= 9
        assert int(result[:-1]) <= 11

    def test_humanize_time_with_timezone_offset(self) -> None:
        """
        Test timestamp with timezone offset.
        """
        now = datetime.now(timezone.utc)
        timestamp = (now - timedelta(minutes=20)).isoformat()
        result = humanize_time(timestamp)
        assert result.endswith("m")
        assert int(result[:-1]) >= 19
        assert int(result[:-1]) <= 21

    def test_humanize_time_without_timezone(self) -> None:
        """
        Test timestamp without timezone (assumes UTC).
        """
        now = datetime.now(timezone.utc)
        timestamp = (now - timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M:%S")
        result = humanize_time(timestamp)
        assert result.endswith("h")
        assert int(result[:-1]) >= 1
        assert int(result[:-1]) <= 3

    def test_humanize_time_zero_seconds(self) -> None:
        """
        Test that very recent times show as seconds.
        """
        now = datetime.now(timezone.utc)
        timestamp = now.strftime("%Y-%m-%dT%H:%M:%SZ")
        result = humanize_time(timestamp)
        assert result.endswith("s")

    def test_humanize_time_negative_time(self) -> None:
        """
        Test that future times (negative age) return "0s".
        """
        now = datetime.now(timezone.utc)
        timestamp = (now + timedelta(minutes=5)).strftime("%Y-%m-%dT%H:%M:%SZ")
        result = humanize_time(timestamp)
        assert result == "0s"

    def test_humanize_time_invalid_format(self) -> None:
        """
        Test that invalid timestamp formats return the original string.
        """
        invalid_timestamp = "not-a-timestamp"
        result = humanize_time(invalid_timestamp)
        assert result == invalid_timestamp

    def test_humanize_time_boundary_60_seconds(self) -> None:
        """
        Test boundary at exactly 60 seconds (should show as 1m).
        """
        now = datetime.now(timezone.utc)
        timestamp = (now - timedelta(seconds=60)).strftime("%Y-%m-%dT%H:%M:%SZ")
        result = humanize_time(timestamp)
        # Should be 1m, not 60s
        assert result.endswith("m")
        assert result == "1m"

    def test_humanize_time_boundary_3600_seconds(self) -> None:
        """
        Test boundary at exactly 3600 seconds (should show as 1h).
        """
        now = datetime.now(timezone.utc)
        timestamp = (now - timedelta(seconds=3600)).strftime("%Y-%m-%dT%H:%M:%SZ")
        result = humanize_time(timestamp)
        # Should be 1h, not 60m
        assert result.endswith("h")
        assert result == "1h"

    def test_humanize_time_boundary_86400_seconds(self) -> None:
        """
        Test boundary at exactly 86400 seconds (should show as 1d).
        """
        now = datetime.now(timezone.utc)
        timestamp = (now - timedelta(seconds=86400)).strftime("%Y-%m-%dT%H:%M:%SZ")
        result = humanize_time(timestamp)
        # Should be 1d, not 24h
        assert result.endswith("d")
        assert result == "1d"
