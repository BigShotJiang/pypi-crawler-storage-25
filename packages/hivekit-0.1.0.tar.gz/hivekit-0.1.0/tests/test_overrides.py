import pytest
import yaml

from cli.config import load_config

MINIMAL_CONFIG = {
    "experiment_name": "test-exp",
    "repo": {
        "source": "https://github.com/test/repo.git",
        "branch": "main",
        "evaluation_script": "evaluation.py",
        "target_code": ["main.py"],
    },
    "runtime": {
        "num_agents": 1,
        "max_runtime_seconds": -1,
        "max_iterations": -1,
    },
    "sandbox": {
        "base_image": "python:3.12-slim",
        "setup_script": "setup.sh",
        "evaluation_timeout": 60,
        "resources": {"cpu": "1", "memory": "2Gi"},
    },
}


@pytest.fixture
def base_config(tmp_path):
    cfg = tmp_path / "config.yaml"
    cfg.write_text(yaml.safe_dump(MINIMAL_CONFIG))
    return str(cfg)


def _write_config(tmp_path, extra: dict) -> str:
    cfg = tmp_path / "config.yaml"
    cfg.write_text(yaml.safe_dump({**MINIMAL_CONFIG, **extra}))
    return str(cfg)


class TestApplyOverrides:
    def test_override_top_level(self, base_config):
        config = load_config(base_config, overrides=["log_level=DEBUG"])
        assert config.log_level == "DEBUG"

    def test_override_nested(self, base_config):
        config = load_config(base_config, overrides=["runtime.num_agents=8"])
        assert config.runtime.num_agents == 8

    def test_override_deeply_nested(self, base_config):
        config = load_config(base_config, overrides=["sandbox.resources.cpu=4"])
        assert config.sandbox.resources.cpu == "4"

    def test_override_multiple(self, base_config):
        config = load_config(
            base_config,
            overrides=["runtime.num_agents=4", "runtime.max_iterations=100"],
        )
        assert config.runtime.num_agents == 4
        assert config.runtime.max_iterations == 100

    def test_override_coerces_int_to_str(self, base_config):
        config = load_config(base_config, overrides=["sandbox.resources.cpu=4"])
        assert config.sandbox.resources.cpu == "4"

    def test_delete_restores_default(self, base_config):
        config = load_config(base_config, overrides=["~runtime.max_runtime_seconds"])
        assert config.runtime.max_runtime_seconds == -1

    def test_delete_nested(self, base_config):
        config = load_config(base_config, overrides=["~sandbox.resources.cpu"])
        assert config.sandbox.resources.cpu == "1"

    def test_unknown_key_raises(self, base_config):
        with pytest.raises(Exception):
            load_config(base_config, overrides=["runtime.nonexistent=5"])

    def test_override_experiment_name(self, tmp_path):
        cfg = _write_config(tmp_path, {"experiment_name": "original-name"})
        config = load_config(cfg, overrides=["experiment_name=new-name"])
        assert config.experiment_name == "new-name"

    def test_experiment_name_suffix_generated(self, base_config):
        config = load_config(base_config, overrides=["experiment_name=my-exp-"])
        assert config.experiment_name.startswith("my-exp-")
        assert len(config.experiment_name) > len("my-exp-")
