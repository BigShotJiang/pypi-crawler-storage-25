from __future__ import annotations

import importlib
from pathlib import Path
import sys


SRC_DIR = Path(__file__).resolve().parents[1] / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))


def test_package_import_and_public_exports() -> None:
    module = importlib.import_module("kotharcomputing")

    expected_exports = {
        # Aleph Language Server
        "AlephLanguageServerClient",
        "AlephLanguageServerClientOptions",
        "AnalyzeResult",
        "AnalyzeResultWithAst",
        "AnalyzeResultWithAstAndFormat",
        "AnalyzeResultWithFormat",
        "AstFilter",
        "AstFilterClause",
        "AstNode",
        "AstNodeLocation",
        "AstNodeType",
        "AstTextFilter",
        "Diagnostic",
        "DiagnosticSeverity",
        "Position",
        "Range",
        # Agents
        "Activity",
        "ActivityExecution",
        "ActivityJob",
        "Agent",
        "AgentCapabilities",
        "AgentCloud",
        "AgentKind",
        "AgentPersonal",
        "AgentStatus",
        "CreateAgentArgs",
        "CreateAgentResult",
        "DeleteAgentResult",
        "ResetAgentTokenResult",
        "WithAgent",
        # AI
        "AbbreviatedAIChat",
        "AIChat",
        "AIChatContentEditorContext",
        "AIChatContentEditorContextFile",
        "AIChatContentText",
        "AIChatFileLocation",
        "AIChatMessage",
        "AIChatMessageApi",
        "AIChatMessageAssistant",
        "AIChatMessageAssistantContent",
        "AIChatMessageAssistantDelta",
        "AIChatMessageError",
        "AIChatMessageTool",
        "AIChatMessageToolResult",
        "AIChatMessageUser",
        "AIChatMessageUserAppend",
        "AIChatMessageUserContent",
        "AIChatMessageUserContentEdition",
        "AIChatMessageUserCreate",
        "AIChatMessageWithStreaming",
        "AIChatToolCall",
        "AIChatToolCallFunction",
        "AIChatToolDescription",
        "AIChatToolDescriptionFunction",
        # API Tokens
        "ApiToken",
        "ApiTokenPermissionAction",
        "ApiTokenPermissions",
        "ApiTokenPermissionSubject",
        "CreateApiTokenArgs",
        "CreateApiTokenResult",
        # Client
        "KotharClient",
        "KotharClientOptions",
        "RawResponse",
        # Credits
        "CreditBalance",
        "CreditTransaction",
        # Errors
        "KOTHAR_ERROR_TYPE_BASE_URL",
        "KotharApiError",
        # Executions
        "ExecuteArgs",
        "ExecuteCommonArgs",
        "ExecuteResult",
        "ExecuteScriptArgs",
        "ExecuteTestArgs",
        "Execution",
        "ExecutionCommon",
        "ExecutionControl",
        "ExecutionEnded",
        "ExecutionError",
        "ExecutionMessage",
        "ExecutionOutput",
        "ExecutionScriptArgs",
        "ExecutionScript",
        "ExecutionStarted",
        "ExecutionTest",
        "ExecutionTestResults",
        "SystemMetrics",
        "SystemMetricSample",
        "SystemMetricSeries",
        # Files
        "FileContent",
        "FileHistoryEntry",
        "FileListItem",
        "FileSearchResultItem",
        # Jobs
        "CreateJobArgs",
        "Job",
        "JobStatus",
        "UpdateJobArgs",
        # Service Prices
        "ServicePrice",
        # Subscribe User
        "KotharApiUserEvent",
        "KotharApiUserEventCreditBalancesUpdated",
        # Subscribe Workspace
        "KotharApiWorkspaceEvent",
        "KotharApiWorkspaceFileCreatedEvent",
        "KotharApiWorkspaceFileDeletedEvent",
        "KotharApiWorkspaceFileMovedEvent",
        "KotharApiWorkspaceFileUpdatedEvent",
        "KotharApiWorkspaceJobUpdatedEvent",
        # Subscriptions
        "Subscription",
        "SubscriptionInterval",
        "SubscriptionOption",
        "SubscriptionStatus",
        # Users
        "UserProfile",
        "WithUser",
        # Workspaces
        "Workspace",
        "WorkspaceStorageStats",
    }

    assert set(module.__all__) == expected_exports
    for name in expected_exports:
        assert hasattr(module, name)


def test_kothar_client_uses_default_base_url() -> None:
    module = importlib.import_module("kotharcomputing")

    client = module.KotharClient()

    assert client._transport.base_url == "https://api.kotharcomputing.com/"
