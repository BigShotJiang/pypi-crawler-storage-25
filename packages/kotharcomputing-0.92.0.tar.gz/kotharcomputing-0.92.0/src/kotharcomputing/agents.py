from __future__ import annotations

from typing import Literal, NotRequired, TypeAlias, TypedDict, cast

from .fetch import ApiTransport
from .users import WithUser


class ActivityExecution(TypedDict):
    type: Literal["execution"]
    id: str


class ActivityJob(TypedDict):
    type: Literal["job"]
    id: str


Activity: TypeAlias = ActivityExecution | ActivityJob

AgentKind: TypeAlias = Literal["personal", "cloud"]
AgentStatus: TypeAlias = Literal["offline", "online"]
AgentCapabilities: TypeAlias = Literal["direct-execution", "job"]


class AgentSystemInfoCPU(TypedDict):
    arch: str
    parallelism: int
    flags: list[str]
    vendor: NotRequired[str]
    model: NotRequired[str]


class AgentSystemInfoMemory(TypedDict):
    totalMB: int


class AgentSystemInfo(TypedDict):
    cpu: AgentSystemInfoCPU
    memory: AgentSystemInfoMemory


class AgentData(TypedDict):
    systemInfo: AgentSystemInfo


class AgentPersonal(WithUser):
    id: str
    name: str
    status: AgentStatus
    kind: Literal["personal"]
    capabilities: list[AgentCapabilities]
    activities: list[Activity]
    ownerId: str
    createdAt: str
    ip: NotRequired[str]
    version: NotRequired[str]
    imageVersion: NotRequired[str]
    lastSeen: NotRequired[str]
    data: NotRequired[AgentData]


class AgentCloudCPU(TypedDict):
    parallelism: int


class AgentCloudSystemInfo(TypedDict):
    cpu: AgentCloudCPU
    memory: AgentSystemInfoMemory


class AgentCloudData(TypedDict):
    systemInfo: AgentCloudSystemInfo


class AgentCloud(WithUser):
    id: str
    name: str
    status: AgentStatus
    kind: Literal["cloud"]
    capabilities: list[AgentCapabilities]
    activities: list[Activity]
    ownerId: str
    tooltip: NotRequired[str]
    timeout: NotRequired[str]
    data: NotRequired[AgentCloudData]


Agent: TypeAlias = AgentPersonal | AgentCloud


class WithAgent(TypedDict):
    agentId: str
    agentName: NotRequired[str]


class CreateAgentArgs(TypedDict):
    name: str
    kind: AgentKind
    ownerId: str


class CreateAgentResult(TypedDict):
    agent: Agent
    token: str
    cmdLine: str


class ResetAgentTokenResult(TypedDict):
    agent: Agent
    token: str
    cmdLine: str


class DeleteAgentResult(TypedDict, total=False):
    cmdLine: str


class AgentsPage(TypedDict):
    items: list[Agent]
    next: NotRequired[str]


class AgentsClient:
    def __init__(self, transport: ApiTransport) -> None:
        self._transport = transport

    def list(
        self,
        *,
        for_user_id: str,
        next: str | None = None,
        with_usernames: bool | None = None,
    ) -> AgentsPage:
        return cast(
            AgentsPage,
            self._transport.get_json(
                "v1/agents",
                search_params={
                    "forUserId": for_user_id,
                    "next": next,
                    "withUsernames": with_usernames,
                },
            ),
        )

    def create(self, args: CreateAgentArgs) -> CreateAgentResult:
        return cast(
            CreateAgentResult, self._transport.post_json("v1/agents", json_data=args)
        )

    def id(self, agent_id: str) -> "AgentByIdClient":
        return AgentByIdClient(self._transport, agent_id)


class AgentByIdClient:
    def __init__(self, transport: ApiTransport, agent_id: str) -> None:
        self._transport = transport
        self._agent_id = agent_id

    def get(self, *, with_usernames: bool | None = None) -> Agent:
        return cast(
            Agent,
            self._transport.get_json(
                "v1/agents/:agentId",
                path_params={"agentId": self._agent_id},
                search_params={"withUsernames": with_usernames},
            ),
        )

    def reset_token(self) -> ResetAgentTokenResult:
        return cast(
            ResetAgentTokenResult,
            self._transport.post_json(
                "v1/agents/:agentId/$resetToken",
                path_params={"agentId": self._agent_id},
            ),
        )

    def delete(self) -> DeleteAgentResult:
        return cast(
            DeleteAgentResult,
            self._transport.delete_json(
                "v1/agents/:agentId", path_params={"agentId": self._agent_id}
            ),
        )
