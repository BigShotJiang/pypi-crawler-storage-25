from __future__ import annotations

import threading
from typing import Any, Callable, Literal, NotRequired, TypeAlias, TypedDict, cast

from .errors import KOTHAR_ERROR_TYPE_BASE_URL, KotharApiError
from .fetch import ApiTransport


SystemMetricSample: TypeAlias = tuple[float, float]
ExecutionScriptArgs: TypeAlias = dict[str, str | int | float | bool]


class SystemMetricAggregates(TypedDict, total=False):
    peak: float
    average: float
    total: float
    latest: float


class SystemMetricSeries(TypedDict):
    id: str
    samples: list[SystemMetricSample]
    aggregates: SystemMetricAggregates


class SystemMetrics(TypedDict):
    metrics: list[SystemMetricSeries]


class ExecutionCommon(TypedDict):
    id: str
    userId: str
    agentId: str
    runtimeId: str
    workspaceId: str
    timestamp: float
    timeout: NotRequired[str]
    maxThreads: NotRequired[int]
    maxMemoryMb: NotRequired[int]
    executionArgs: NotRequired[ExecutionScriptArgs]


class ExecutionScript(ExecutionCommon):
    mode: Literal["script"]
    path: NotRequired[str]


class ExecutionTest(ExecutionCommon):
    mode: Literal["test"]
    paths: list[str]
    filters: NotRequired[list[str]]


Execution: TypeAlias = ExecutionScript | ExecutionTest


class ExecuteCommonArgs(TypedDict):
    agentId: str
    runtimeId: NotRequired[str]
    dependencies: NotRequired[list[str]]
    timeout: NotRequired[str]
    maxThreads: NotRequired[int]
    maxMemoryMb: NotRequired[int]
    executionArgs: NotRequired[ExecutionScriptArgs]


class ExecuteScriptArgs(ExecuteCommonArgs):
    content: str
    mode: NotRequired[Literal["script"]]
    path: NotRequired[str]


class ExecuteTestArgs(ExecuteCommonArgs):
    mode: Literal["test"]
    paths: list[str]
    filters: NotRequired[list[str]]


ExecuteArgs: TypeAlias = ExecuteScriptArgs | ExecuteTestArgs


class ExecutionStarted(TypedDict):
    type: Literal["agent:execution:started"]
    executionId: str
    timestamp: float


class ExecutionOutput(TypedDict):
    type: Literal["agent:execution:output"]
    executionId: str
    timestamp: float
    channel: Literal["stdout", "stderr"]
    lines: list[str]


class ExecutionTestResults(TypedDict):
    type: Literal["agent:execution:test-results"]
    executionId: str
    timestamp: float
    ctrf: dict[str, object]


class ExecutionEnded(TypedDict):
    type: Literal["agent:execution:ended"]
    executionId: str
    timestamp: float
    exitCode: int
    duration: str
    scriptDuration: str
    signal: NotRequired[str]
    systemMetrics: NotRequired[SystemMetrics]


class ExecutionError(TypedDict):
    type: Literal["agent:execution:error"]
    executionId: str
    timestamp: float
    message: str


class ExecutionControl(TypedDict):
    type: Literal["agent:execution:control"]
    executionId: str
    timestamp: float
    message: str


ExecutionMessage: TypeAlias = (
    ExecutionStarted
    | ExecutionOutput
    | ExecutionTestResults
    | ExecutionEnded
    | ExecutionError
    | ExecutionControl
)


class ExecuteResult:
    _MAX_CONSECUTIVE_RECONNECT_FAILURES = 10

    def __init__(
        self,
        execution: Execution,
        transport: ApiTransport,
        events_url: str,
        callback: Callable[[ExecutionMessage], None],
    ) -> None:
        self.execution = execution
        self._transport = transport
        self._events_url = events_url
        self._callback = callback
        self._done = threading.Event()
        self._stop = threading.Event()
        self._error: str | None = None
        self._response_lock = threading.Lock()
        self._current_response: Any | None = None
        self._thread = threading.Thread(
            target=self._run, name=f"kothar-execution-{execution['id']}", daemon=True
        )
        self._thread.start()

    @property
    def done(self) -> bool:
        return self._done.is_set()

    @property
    def awaitable(self) -> Callable[[float | None], None]:
        return self.wait

    def close(self) -> None:
        self._stop.set()
        self._close_current_response()

    def wait(self, timeout: float | None = None) -> None:
        finished = self._done.wait(timeout)
        if not finished:
            raise TimeoutError(
                "Timed out while waiting for execution stream completion"
            )
        if self._error:
            raise RuntimeError(self._error)

    def _set_current_response(self, response: Any | None) -> None:
        with self._response_lock:
            self._current_response = response

    def _close_current_response(self) -> None:
        with self._response_lock:
            response = self._current_response
            self._current_response = None
        if response is not None:
            try:
                response.close()
            except Exception:
                pass

    def _run(self) -> None:
        reconnect_attempts = 0
        try:
            while not self._stop.is_set() and not self._done.is_set():
                try:
                    with self._transport.open_sse_stream(
                        "get", self._events_url, absolute_url=True
                    ) as response:
                        self._set_current_response(response)
                        received_event = False
                        for payload in self._transport.iter_sse_payloads(response):
                            if self._stop.is_set() or self._done.is_set():
                                return

                            received_event = True
                            reconnect_attempts = 0
                            message = cast(ExecutionMessage, payload)
                            try:
                                self._callback(message)
                            except Exception:
                                pass

                            message_type = str(payload.get("type", ""))
                            if message_type == "agent:execution:ended":
                                self._done.set()
                                return
                            if message_type == "agent:execution:error":
                                self._error = str(
                                    payload.get("message", "Unknown execution error")
                                )
                                self._done.set()
                                return

                        if not received_event:
                            reconnect_attempts += 1
                            if (
                                reconnect_attempts
                                > self._MAX_CONSECUTIVE_RECONNECT_FAILURES
                            ):
                                self._error = (
                                    "Execution stream closed before completion"
                                )
                                self._done.set()
                                return
                            delay = min(2 ** (reconnect_attempts - 1), 10)
                            self._stop.wait(delay)
                except KotharApiError as error:
                    if self._stop.is_set() or self._done.is_set():
                        return

                    status = error.status or 0
                    if 400 <= status < 500 and status != 429:
                        self._error = (
                            error.title or "Execution stream connection failed"
                        )
                        self._done.set()
                        return

                    reconnect_attempts += 1
                    if reconnect_attempts > self._MAX_CONSECUTIVE_RECONNECT_FAILURES:
                        self._error = "Execution stream reconnection limit exceeded"
                        self._done.set()
                        return
                    delay = min(2 ** (reconnect_attempts - 1), 10)
                    self._stop.wait(delay)
                except Exception:
                    if self._stop.is_set() or self._done.is_set():
                        return

                    reconnect_attempts += 1
                    if reconnect_attempts > self._MAX_CONSECUTIVE_RECONNECT_FAILURES:
                        self._error = "Execution stream reconnection limit exceeded"
                        self._done.set()
                        return
                    delay = min(2 ** (reconnect_attempts - 1), 10)
                    self._stop.wait(delay)
                finally:
                    self._set_current_response(None)

            if self._stop.is_set() and not self._done.is_set():
                self._error = "Execution stream closed"
                self._done.set()
        finally:
            self._close_current_response()


class ExecutionByIdClient:
    def __init__(
        self, transport: ApiTransport, workspace_id: str, execution_id: str
    ) -> None:
        self._transport = transport
        self._workspace_id = workspace_id
        self._execution_id = execution_id

    def get(self) -> Execution:
        return cast(
            Execution,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/executions/:executionId",
                path_params={
                    "workspaceId": self._workspace_id,
                    "executionId": self._execution_id,
                },
            ),
        )

    def cancel(self) -> None:
        self._transport.raw(
            "delete",
            "v1/workspaces/:workspaceId/executions/:executionId",
            path_params={
                "workspaceId": self._workspace_id,
                "executionId": self._execution_id,
            },
        )


class ExecutionsClient:
    def __init__(self, transport: ApiTransport, workspace_id: str) -> None:
        self._transport = transport
        self._workspace_id = workspace_id

    def execute(
        self, args: ExecuteArgs, *, on: Callable[[ExecutionMessage], None]
    ) -> ExecuteResult:
        create_response = self._transport.raw(
            "post",
            "v1/workspaces/:workspaceId/executions",
            path_params={"workspaceId": self._workspace_id},
            json_data=args,
        )
        execution = cast(Execution, create_response.json())

        location = create_response.headers.get("location")
        if not location:
            raise KotharApiError(
                {
                    "type": f"{KOTHAR_ERROR_TYPE_BASE_URL}/unexpected-response",
                    "title": "Missing Location header from execution creation response",
                    "status": create_response.status,
                }
            )

        return ExecuteResult(
            execution=execution,
            transport=self._transport,
            events_url=location,
            callback=on,
        )

    def id(self, execution_id: str) -> ExecutionByIdClient:
        return ExecutionByIdClient(self._transport, self._workspace_id, execution_id)
