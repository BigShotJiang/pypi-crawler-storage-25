from __future__ import annotations

from typing import TypedDict, cast

from .fetch import ApiTransport


class ServicePrice(TypedDict):
    category: str
    description: str
    effectiveFrom: str
    kreditsPerUnit: float
    sku: str
    unitDescription: str


class ServicePricesClient:
    def __init__(self, transport: ApiTransport) -> None:
        self._transport = transport

    def list(self, *, effective_at: str | None = None) -> list[ServicePrice]:
        return cast(
            list[ServicePrice],
            self._transport.get_json(
                "v1/services-prices",
                search_params={"effectiveAt": effective_at},
            ),
        )
