from __future__ import annotations

from typing import Literal, TypeAlias, TypedDict

from .agents import Activity, AgentStatus


class KotharApiUserEventCreditBalancesUpdated(TypedDict):
    type: Literal["credit-balance:updated"]
    ownerId: str
    balance: float


class KotharApiUserEventAgentUpdated(TypedDict):
    type: Literal["agent:updated"]
    agentId: str
    ownerId: str
    status: AgentStatus
    activities: list[Activity]


class KotharApiUserEventAgentDeleted(TypedDict):
    type: Literal["agent:deleted"]
    agentId: str
    ownerId: str


KotharApiUserEvent: TypeAlias = (
    KotharApiUserEventCreditBalancesUpdated
    | KotharApiUserEventAgentUpdated
    | KotharApiUserEventAgentDeleted
)


__all__ = [
    "KotharApiUserEvent",
    "KotharApiUserEventAgentDeleted",
    "KotharApiUserEventAgentUpdated",
    "KotharApiUserEventCreditBalancesUpdated",
]
