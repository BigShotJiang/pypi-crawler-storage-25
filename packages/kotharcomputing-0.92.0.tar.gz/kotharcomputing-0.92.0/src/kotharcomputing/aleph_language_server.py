from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
import json
from typing import Literal, NotRequired, Required, TypedDict, cast, overload

from .fetch import ApiTransport

DEFAULT_BASE_URL = "https://aleph.kotharcomputing.com"


@dataclass(slots=True)
class AlephLanguageServerClientOptions:
    base_url: str = DEFAULT_BASE_URL
    timeout: float = 30.0


class AlephLanguageServerClient:
    def __init__(
        self,
        options: AlephLanguageServerClientOptions | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        if options is None:
            options = AlephLanguageServerClientOptions(
                base_url=base_url,
                timeout=timeout,
            )

        self._transport = ApiTransport(
            base_url=options.base_url,
            access_token=None,
            timeout=options.timeout,
        )

    def version(self) -> dict[str, str]:
        return self._transport.get_json("version")

    def format(
        self,
        code: str,
        *,
        tab_size: int | None = None,
        insert_spaces: bool | None = None,
        trim_trailing_whitespace: bool | None = None,
        insert_final_newline: bool | None = None,
        trim_final_newlines: bool | None = None,
    ) -> str:
        response = self._transport.raw(
            "post",
            "format",
            headers={"Content-Type": "application/x-aleph"},
            search_params={
                "tab_size": tab_size,
                "insert_spaces": insert_spaces,
                "trim_trailing_whitespace": trim_trailing_whitespace,
                "insert_final_newline": insert_final_newline,
                "trim_final_newlines": trim_final_newlines,
            },
            body=code,
        )
        return response.text()

    @overload
    def analyze(
        self,
        code: str,
        *,
        include_ast: Literal[True],
        filter_ast: AstFilter | None = ...,
        format: Literal[True],
    ) -> AnalyzeResultWithAstAndFormat: ...
    @overload
    def analyze(
        self,
        code: str,
        *,
        include_ast: Literal[True],
        filter_ast: AstFilter | None = ...,
        format: bool = ...,
    ) -> AnalyzeResultWithAst: ...
    @overload
    def analyze(
        self,
        code: str,
        *,
        include_ast: bool = ...,
        filter_ast: AstFilter,
        format: Literal[True],
    ) -> AnalyzeResultWithAstAndFormat: ...
    @overload
    def analyze(
        self,
        code: str,
        *,
        include_ast: bool = ...,
        filter_ast: AstFilter,
        format: bool = ...,
    ) -> AnalyzeResultWithAst: ...
    @overload
    def analyze(
        self,
        code: str,
        *,
        include_ast: bool = ...,
        filter_ast: None = ...,
        format: Literal[True],
    ) -> AnalyzeResultWithFormat: ...
    @overload
    def analyze(
        self,
        code: str,
        *,
        include_ast: bool = ...,
        filter_ast: AstFilter | None = ...,
        format: bool = ...,
    ) -> AnalyzeResult: ...

    def analyze(
        self,
        code: str,
        *,
        include_ast: bool = False,
        filter_ast: AstFilter | None = None,
        format: bool = False,
    ) -> (
        AnalyzeResult
        | AnalyzeResultWithAst
        | AnalyzeResultWithFormat
        | AnalyzeResultWithAstAndFormat
    ):
        response = self._transport.raw(
            "post",
            "analyze",
            headers={"Content-Type": "application/x-aleph"},
            search_params={
                "include_ast": include_ast or None,
                "filter_ast": json.dumps(filter_ast, separators=(",", ":"))
                if filter_ast is not None
                else None,
                "format": format or None,
            },
            body=code,
        )
        return cast(AnalyzeResult, response.json())


# -- Aleph Diagnostic types (based on LSP 3.17 specification) --


class DiagnosticSeverity(IntEnum):
    Error = 1
    Warning = 2
    Information = 3
    Hint = 4


class Position(TypedDict):
    line: int
    character: int


class Range(TypedDict):
    start: Position
    end: Position


class Diagnostic(TypedDict):
    range: Range
    message: str
    severity: NotRequired[DiagnosticSeverity]
    code: NotRequired[str | int]
    source: NotRequired[str]


class AnalyzeResult(TypedDict):
    diagnostics: list[Diagnostic]
    ast: NotRequired[list[AstNode]]
    format: NotRequired[list[str]]
    error: NotRequired[str]


class AnalyzeResultWithAst(AnalyzeResult):
    ast: list[AstNode]


class AnalyzeResultWithFormat(AnalyzeResult):
    format: list[str]


class AnalyzeResultWithAstAndFormat(AnalyzeResultWithAst, AnalyzeResultWithFormat):
    pass


class AstFilter(TypedDict):
    any: list[AstFilterClause]


class _AstFilterClauseBase(TypedDict, total=False):
    descendants: int


class _AstFilterClauseWithTypes(_AstFilterClauseBase, total=False):
    types: Required[list[AstNodeType]]
    text: AstTextFilter
    children: AstFilter


class _AstFilterClauseWithText(_AstFilterClauseBase, total=False):
    types: list[AstNodeType]
    text: Required[AstTextFilter]
    children: AstFilter


class _AstFilterClauseWithChildren(_AstFilterClauseBase, total=False):
    types: list[AstNodeType]
    text: AstTextFilter
    children: Required[AstFilter]


AstFilterClause = (
    _AstFilterClauseWithTypes | _AstFilterClauseWithText | _AstFilterClauseWithChildren
)


class AstTextFilter(TypedDict):
    pattern: str
    mode: NotRequired[Literal["regex"]]


class AstNode(TypedDict):
    type: AstNodeType
    text: NotRequired[str]
    isSynthetic: NotRequired[Literal[True]]
    location: AstNodeLocation
    children: NotRequired[list[AstNode]]


class AstNodeLocation(TypedDict):
    uri: NotRequired[str]
    range: Range


AstNodeType = Literal[
    "Id",
    "Fun_Call",
    "Unused_Return_Fun_Call",
    "Arg_List",
    "Slice_List",
    "Slice",
    "Equation",
    "Var_Decl",
    "Assign_Decl",
    "Array_Call",
    "Dot_Access",
    "Lambda",
    "Block",
    "Scopeless_Block",
    "Include",
    "Def",
    "While",
    "If",
    "For",
    "Ranged_For",
    "Inline_Array",
    "Inline_Map",
    "Return",
    "File",
    "Prefix",
    "Break",
    "Continue",
    "Map_Pair",
    "Value_Range",
    "Inline_Range",
    "Try",
    "Catch",
    "Finally",
    "Method",
    "Attr_Decl",
    "Logical_And",
    "Logical_Or",
    "Reference",
    "Switch",
    "Case",
    "Default",
    "Noop",
    "Class",
    "Binary",
    "Arg",
    "Global_Decl",
    "Constant",
    "Compiled",
    "Error",
]
