from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, TypedDict, cast

from .ai import WorkspaceAIClient
from .api_tokens import ApiTokensClient
from .errors import KotharApiError
from .executions import ExecutionsClient
from .fetch import ApiTransport, SSESubscription
from .files import FilesClient
from .jobs import JobsClient

if TYPE_CHECKING:
    from .subscribe_workspace import KotharApiWorkspaceEvent


class Workspace(TypedDict):
    id: str


class WorkspaceStorageStats(TypedDict):
    workspaceId: str
    files: int
    jobOutput: int


class WorkspaceByIdClient:
    def __init__(self, transport: ApiTransport, workspace_id: str) -> None:
        self._transport = transport
        self._workspace_id = workspace_id
        self.ai = WorkspaceAIClient(transport, workspace_id)
        self.api_tokens = ApiTokensClient(transport, workspace_id)
        self.executions = ExecutionsClient(transport, workspace_id)
        self.files = FilesClient(transport, workspace_id)
        self.jobs = JobsClient(transport, workspace_id)
        self.apiTokens = self.api_tokens

    def find(self) -> Workspace | None:
        try:
            return cast(
                Workspace,
                self._transport.get_json(
                    "v1/workspaces/:workspaceId",
                    path_params={"workspaceId": self._workspace_id},
                ),
            )
        except KotharApiError as error:
            if (error.status or 0) in (403, 404):
                return None
            raise

    def get_storage_stats(self) -> WorkspaceStorageStats:
        return cast(
            WorkspaceStorageStats,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/storage-stats",
                path_params={"workspaceId": self._workspace_id},
            ),
        )

    def subscribe(
        self, callback: Callable[[KotharApiWorkspaceEvent], None]
    ) -> Callable[[], None]:
        subscription = SSESubscription(
            self._transport,
            "v1/workspaces/:workspaceId/events",
            {"workspaceId": self._workspace_id},
            cast(Callable[[Any], None], callback),
        )
        return subscription.close


class WorkspacesClient:
    def __init__(self, transport: ApiTransport) -> None:
        self._transport = transport
        self.personal = WorkspaceByIdClient(transport, "personal")

    def id(self, workspace_id: str) -> WorkspaceByIdClient:
        return WorkspaceByIdClient(self._transport, workspace_id)
