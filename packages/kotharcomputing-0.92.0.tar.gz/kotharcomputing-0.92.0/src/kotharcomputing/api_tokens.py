from __future__ import annotations

from datetime import date, datetime
from typing import Literal, NotRequired, TypeAlias, TypedDict, cast

from .fetch import ApiTransport, to_optional_iso
from .users import WithUser


class ApiToken(WithUser):
    createdAt: str
    id: str
    name: str
    permissions: "ApiTokenPermissions"
    workspaceId: str
    description: NotRequired[str]
    expiresAt: NotRequired[str]


ApiTokenPermissionSubject: TypeAlias = Literal["agent", "execution", "file", "job"]
ApiTokenPermissionAction: TypeAlias = Literal[
    "create", "read", "update", "delete", "manage"
]
ApiTokenPermissions: TypeAlias = list[
    tuple[ApiTokenPermissionAction, ApiTokenPermissionSubject]
]


class CreateApiTokenArgs(TypedDict):
    name: str
    permissions: ApiTokenPermissions
    description: NotRequired[str]
    expiresAt: NotRequired[str | date | datetime]


class CreateApiTokenResult(TypedDict):
    apiToken: ApiToken
    token: str


class ApiTokensPage(TypedDict):
    items: list[ApiToken]
    next: NotRequired[str]


class ApiTokensByIdClient:
    def __init__(
        self, transport: ApiTransport, workspace_id: str, api_token_id: str
    ) -> None:
        self._transport = transport
        self._workspace_id = workspace_id
        self._api_token_id = api_token_id

    def get(self, *, with_usernames: bool | None = None) -> ApiToken:
        return cast(
            ApiToken,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/api-tokens/:apiTokenId",
                path_params={
                    "workspaceId": self._workspace_id,
                    "apiTokenId": self._api_token_id,
                },
                search_params={"withUsernames": with_usernames},
            ),
        )

    def delete(self) -> None:
        self._transport.raw(
            "delete",
            "v1/workspaces/:workspaceId/api-tokens/:apiTokenId",
            path_params={
                "workspaceId": self._workspace_id,
                "apiTokenId": self._api_token_id,
            },
        )


class ApiTokensClient:
    def __init__(self, transport: ApiTransport, workspace_id: str) -> None:
        self._transport = transport
        self._workspace_id = workspace_id

    def list(
        self, *, next: str | None = None, with_usernames: bool | None = None
    ) -> ApiTokensPage:
        return cast(
            ApiTokensPage,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/api-tokens",
                path_params={"workspaceId": self._workspace_id},
                search_params={"next": next, "withUsernames": with_usernames},
            ),
        )

    def create(self, args: CreateApiTokenArgs) -> CreateApiTokenResult:
        payload = dict(args)
        expires_at = payload.get("expiresAt")
        if isinstance(expires_at, (date, datetime)):
            payload["expiresAt"] = to_optional_iso(expires_at)

        return cast(
            CreateApiTokenResult,
            self._transport.post_json(
                "v1/workspaces/:workspaceId/api-tokens",
                path_params={"workspaceId": self._workspace_id},
                json_data=payload,
            ),
        )

    def id(self, api_token_id: str) -> ApiTokensByIdClient:
        return ApiTokensByIdClient(self._transport, self._workspace_id, api_token_id)
