from __future__ import annotations

from typing import Callable, Literal, NotRequired, TypeAlias, TypedDict, cast

from .common import JSONValue
from .errors import ProblemDetails
from .fetch import ApiTransport
from .users import WithUser


class AIChatContentText(TypedDict):
    type: Literal["text"]
    text: str


class AIChatFileLocation(TypedDict):
    line: int
    column: int


class AIChatSelection(TypedDict):
    start: AIChatFileLocation
    end: AIChatFileLocation


class AIChatContentEditorContextFile(TypedDict):
    path: str
    content: str
    is_truncated: bool
    language: NotRequired[str]
    is_primary: NotRequired[bool]
    cursor: NotRequired[AIChatFileLocation]
    selection: NotRequired[AIChatSelection]


class AIChatContentEditorContext(TypedDict):
    type: Literal["editor_context"]
    files: list[AIChatContentEditorContextFile]


AIChatMessageAssistantContent: TypeAlias = AIChatContentText
AIChatMessageUserContent: TypeAlias = AIChatContentText
AIChatMessageUserContentEdition: TypeAlias = (
    AIChatContentText | AIChatContentEditorContext
)


class AIChatToolDescriptionFunctionData(TypedDict):
    name: str
    description: NotRequired[str]
    systemPromptDescription: NotRequired[str]
    parameters: NotRequired[JSONValue]


class AIChatToolDescriptionFunction(TypedDict):
    type: Literal["function"]
    function: AIChatToolDescriptionFunctionData


AIChatToolDescription: TypeAlias = AIChatToolDescriptionFunction


class AIChatToolCallFunctionData(TypedDict):
    name: str
    arguments: str


class AIChatToolCallFunction(TypedDict):
    id: str
    type: Literal["function"]
    function: AIChatToolCallFunctionData


AIChatToolCall: TypeAlias = AIChatToolCallFunction


class AbbreviatedAIChat(TypedDict):
    id: str
    createdAt: str
    updatedAt: str
    summary: NotRequired[str]
    readOnly: NotRequired[bool]


class AIChatMessageApi(TypedDict):
    role: Literal["api"]
    aiChat: AbbreviatedAIChat


class AIChatMessageUser(TypedDict):
    role: Literal["user"]
    content: list[AIChatMessageUserContent]


class AIChatMessageAssistant(TypedDict):
    role: Literal["assistant"]
    content: NotRequired[list[AIChatMessageAssistantContent]]
    toolCalls: NotRequired[list[AIChatToolCall]]
    refusal: NotRequired[str]
    reasoning: NotRequired[str]


class AIChatMessageAssistantDelta(TypedDict):
    role: Literal["assistant_delta"]
    content: NotRequired[str]
    refusal: NotRequired[str]
    reasoning: NotRequired[str]


class AIChatMessageError(TypedDict):
    role: Literal["error"]
    error: ProblemDetails


class AIChatMessageToolResult(TypedDict):
    toolCallId: str
    content: str
    status: NotRequired[Literal["success", "error"]]


class AIChatMessageTool(TypedDict):
    role: Literal["tool"]
    results: list[AIChatMessageToolResult]


AIChatMessage: TypeAlias = AIChatMessageApi | AIChatMessageUser | AIChatMessageAssistant
AIChatMessageWithStreaming: TypeAlias = (
    AIChatMessage | AIChatMessageAssistantDelta | AIChatMessageError
)


class AIChat(WithUser):
    id: str
    createdAt: str
    updatedAt: str
    messages: list[AIChatMessage]
    summary: NotRequired[str]
    readOnly: NotRequired[bool]


class AIChatsPage(TypedDict):
    items: list[AbbreviatedAIChat]
    next: NotRequired[str]


class AIChatMessageUserCreate(TypedDict):
    role: Literal["user"]
    content: list[AIChatMessageUserContentEdition]


AIChatMessageUserAppend: TypeAlias = AIChatMessageUserCreate | AIChatMessageTool


class AIChatByIdClient:
    def __init__(
        self, transport: ApiTransport, workspace_id: str, chat_id: str
    ) -> None:
        self._transport = transport
        self._workspace_id = workspace_id
        self._chat_id = chat_id

    def get(self, *, with_usernames: bool | None = None) -> AIChat:
        return cast(
            AIChat,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/ai/chats/:chatId",
                path_params={
                    "workspaceId": self._workspace_id,
                    "chatId": self._chat_id,
                },
                search_params={"withUsernames": with_usernames},
            ),
        )

    def append(
        self,
        *,
        message: AIChatMessageUserAppend,
        on: Callable[[AIChatMessage | AIChatMessageWithStreaming], None],
        tools: list[AIChatToolDescription] | None = None,
        stream: bool | None = None,
    ) -> None:
        self._transport.sse(
            "put",
            "v1/workspaces/:workspaceId/ai/chats/:chatId",
            path_params={"workspaceId": self._workspace_id, "chatId": self._chat_id},
            json_data={
                "message": message,
                "tools": tools,
                "stream": stream,
            },
            callback=on,
        )

    def delete(self) -> None:
        self._transport.raw(
            "delete",
            "v1/workspaces/:workspaceId/ai/chats/:chatId",
            path_params={"workspaceId": self._workspace_id, "chatId": self._chat_id},
        )


class AIChatsClient:
    def __init__(self, transport: ApiTransport, workspace_id: str) -> None:
        self._transport = transport
        self._workspace_id = workspace_id

    def list(self, *, next: str | None = None) -> AIChatsPage:
        return cast(
            AIChatsPage,
            self._transport.get_json(
                "v1/workspaces/:workspaceId/ai/chats",
                path_params={"workspaceId": self._workspace_id},
                search_params={"next": next},
            ),
        )

    def create(
        self,
        *,
        message: AIChatMessageUserCreate,
        on: Callable[[AIChatMessage | AIChatMessageWithStreaming], None],
        tools: list[AIChatToolDescription] | None = None,
        stream: bool | None = None,
    ) -> None:
        self._transport.sse(
            "post",
            "v1/workspaces/:workspaceId/ai/chats",
            path_params={"workspaceId": self._workspace_id},
            json_data={
                "message": message,
                "tools": tools,
                "stream": stream,
            },
            callback=on,
        )

    def id(self, chat_id: str) -> AIChatByIdClient:
        return AIChatByIdClient(self._transport, self._workspace_id, chat_id)


class WorkspaceAIClient:
    def __init__(self, transport: ApiTransport, workspace_id: str) -> None:
        self.chats = AIChatsClient(transport, workspace_id)
