# kotharcomputing

Python SDK for the Kothar API.

- No runtime dependencies (Python standard library only)
- Fully typed public API

## Install

```bash
pip install kotharcomputing
```

## Documentation

- Kothar Computing docs: https://docs.kotharcomputing.com/
- API docs: https://docs.kotharcomputing.com/docs/the-forge/API
- Changelog: https://docs.kotharcomputing.com/changelog/tags/platform

## Usage

```python
from kotharcomputing import KotharClient

client = KotharClient(
    access_token="<api_token>",
)

files = client.workspaces.id("<workspace_id>").files.list()
print(files)
```
