# Security Policy

## Supported versions

`noetive` follows [Semantic Versioning](https://semver.org/). Security fixes
are issued for the current minor release and the one immediately preceding it.

| Version | Supported |
|---|---|
| 0.3.x | :white_check_mark: |
| < 0.3 | :x: |

## Reporting a vulnerability

**Please do not open a public GitHub issue for security vulnerabilities.**

Report suspected vulnerabilities privately to **security@noetive.eu**. Include:

- A description of the issue and its impact.
- The smallest reproducing example or proof-of-concept.
- The SDK version (`noetive.__version__`) and Python version.
- Any known mitigations.

You can expect:

- An acknowledgement within **2 business days**.
- A triage + severity assessment within **5 business days**.
- A fix timeline proportional to the severity (critical issues aim for
  a patched release within 14 days of confirmation).

We credit reporters in the release notes unless you prefer to remain
anonymous.

## Scope

This policy covers vulnerabilities in the `noetive` Python SDK itself,
including:

- Credential mishandling (logging, leaking, or echoing API keys).
- Request/response parsing bugs that lead to memory corruption, resource
  exhaustion, or remote code execution.
- TLS / transport-layer misconfigurations.
- Dependency confusion, typosquatting, or supply-chain concerns on the
  published package.

Vulnerabilities in the Noetive Semantik service itself (the backing API at
`https://semantik.noetive.io`) should be reported to the same address;
they will be forwarded to the service team.

## Hardening guidance for SDK users

- **Never commit API keys.** Set `NOETIVE_KEY_SECRET` in environment variables,
  secret managers, or CI secret stores — not source code.
- **Rotate keys regularly.** Revoke and reissue any key that leaks into
  logs, screenshots, or version control.
- **Scope keys narrowly** when the dashboard supports it (e.g. separate
  keys for dev / staging / prod, or per-service identities).
- **Keep the SDK up to date.** `pip install -U noetive` pulls the latest
  patched release.
- **Validate TLS.** The SDK requires HTTPS and verifies certificates via
  `httpx`'s defaults (`certifi`). Do not disable verification in production.
- **Redact keys in error handling.** `NoetiveError` never echoes the API
  key itself. If you log request payloads, redact the `Authorization`
  header before writing.

## Cryptography

The SDK itself performs no cryptography beyond what `httpx` / OpenSSL
provides for TLS. API keys are opaque bearer tokens; the client never
inspects or decodes them.
