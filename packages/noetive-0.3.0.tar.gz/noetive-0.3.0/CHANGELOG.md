# Changelog

All notable changes to this SDK are documented in this file. The format is
based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the
project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] - 2026-05-07

Initial public release. Tracks Semantik public API spec **v0.4.0**.

### Added

- `Client` and `AsyncClient` covering all public endpoints:
  `health`, `lint`, `publish`, `search`, `subscribe`.
- Pydantic v2 request / response models with client-side enforcement of
  server-documented limits (vector length ≤ 4096, metadata ≤ 16 keys,
  publish item text/vector XOR, etc.).
- Structured exception hierarchy rooted at `NoetiveError` with per-code
  subclasses; exceptions carry `code`, `status_code`, `retry_after_ms`,
  and `request_id`. Coverage includes the spec v0.4.0 codes
  `namespace_disabled`, `model_not_provisioned`, and `index_building`,
  surfaced as dedicated `NamespaceDisabledError`, `ModelNotProvisionedError`,
  and `IndexBuildingError` classes.
- `BillingError` maps to the `not_billable` code (HTTP 402). Raised when
  the account has no active or trialing subscription. Not automatically
  retried — resolve billing on the dashboard first.
- `publish(ack=...)` accepts `"stored"` (default — write survives a
  single server restart) or `"durable"` (write survives power loss),
  matching Semantik spec v0.4.0.
- Retry policy that honors `retry_after_ms` from the body and
  RFC 9110 `Retry-After` from headers for 429 and 503 responses, and
  retries `index_building` until the index is ready.
- `metering_unavailable` (HTTP 503) maps to `ServiceUnavailableError`.
  When it arrives without a `retry_after_ms` hint the retry policy falls
  back to exponential backoff.
- `RetryPolicy` and `DEFAULT_RETRY_POLICY` are part of the public surface:
  `from noetive import RetryPolicy`. The `noetive._retry` path remains
  importable but is no longer the recommended form.
- Server-Sent Events parser with Hypothesis-based chunk-split invariance
  tests; `SubscribeStream` / `AsyncSubscribeStream` context managers.
- Pluggable transport: inject a custom `httpx.Client` / `httpx.AsyncClient`
  to customize TLS, proxies, or mocks. Construction rejects an injected
  client with TLS certificate verification disabled (`verify=False`),
  raising `ValueError`.
- `User-Agent: noetive-sdk-python/<ver> (<runtime>; <os>/<arch>)` on every
  request, e.g. `noetive-sdk-python/0.3.0 (cpython3.12.1; darwin/arm64)`,
  so server logs can attribute traffic to specific SDK versions.
- Full type hints + `py.typed` marker for downstream type checkers.
- Automated PyPI release workflow (`.github/workflows/publish.yml`) that
  triggers on `v*.*.*` tags, verifies the tag matches `_version.py`, and
  publishes via OIDC trusted publishing.

[Unreleased]: https://github.com/noetive/noetive-sdk-python/compare/v0.3.0...HEAD
[0.3.0]: https://github.com/noetive/noetive-sdk-python/releases/tag/v0.3.0
