"""Synchronous client for the Noetive Semantik public API."""

from __future__ import annotations

import os
from types import TracebackType
from typing import Any

import httpx

from ._retry import RetryPolicy
from ._transport import (
    API_KEY_ENV,
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
    assert_tls_verification,
    request_json_sync,
    require_api_key,
)
from .models import (
    DEFAULT_DIMENSIONS,
    DEFAULT_MODEL,
    DEFAULT_NAMESPACE,
    Ack,
    LintRequest,
    LintResponse,
    PublishItem,
    PublishRequest,
    PublishResponse,
    SearchRequest,
    SearchResponse,
    SubscribeRequest,
)
from .streaming import SubscribeStream


class Client:
    """Synchronous Noetive Semantik client.

    Usage::

        with Client() as noetive:  # reads NOETIVE_KEY_SECRET from env
            noetive.health()

    :param api_key: API key in the ``keyu_...`` form from the Noetive
        dashboard. When omitted, ``NOETIVE_KEY_SECRET`` is used. Endpoints that
        require auth raise :class:`AuthenticationError` when no key is found.
    :param base_url: Override the API endpoint. Defaults to the production
        URL ``https://semantik.noetive.io``.
    :param timeout: A float (seconds, applied to all phases) or
        :class:`httpx.Timeout` instance. The default is
        ``httpx.Timeout(30.0, connect=5.0)`` — 30 s read/write/pool, 5 s
        connect.
    :param max_retries: Maximum retry attempts for transient failures.
        ``1`` (the default) means a single retry — two total attempts per
        request. Same policy is applied to one-shot JSON calls and to
        ``subscribe()`` open.
    :param http2: Whether to negotiate HTTP/2 (bundled via ``httpx[http2]``).
    :param http_client: Inject a pre-configured :class:`httpx.Client` (e.g.
        for mock transports or a corporate proxy). The injected client **must**
        have TLS certificate verification enabled (``verify=True``, the
        httpx default); the SDK rejects clients with ``verify=False`` at
        construction time. When provided, ``base_url``, ``timeout`` and
        ``http2`` are ignored — configure them on the supplied client.
    :param retry_policy: Override the default :class:`RetryPolicy`. Takes
        precedence over ``max_retries`` when both are supplied.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float | httpx.Timeout = DEFAULT_TIMEOUT,
        max_retries: int = 1,
        http2: bool = True,
        http_client: httpx.Client | None = None,
        retry_policy: RetryPolicy | None = None,
    ) -> None:
        self._api_key = api_key if api_key is not None else os.environ.get(API_KEY_ENV)
        if retry_policy is not None:
            self._retry_policy = retry_policy
        else:
            self._retry_policy = RetryPolicy(max_attempts=max_retries + 1)
        if http_client is None:
            self._http = httpx.Client(base_url=base_url, timeout=timeout, http2=http2)
            self._owns_http = True
        else:
            assert_tls_verification(http_client)
            self._http = http_client
            self._owns_http = False

    @property
    def base_url(self) -> str:
        return str(self._http.base_url)

    # --- endpoints ---------------------------------------------------------

    def health(self) -> None:
        """Liveness probe. Raises on non-2xx; returns ``None`` on success.

        Does not require an API key. Useful in container readiness probes and
        as a smoke test after configuration changes.
        """
        self._post("/v1/health", body=None, auth=False)

    def lint(self, *, query: str, cursor: int | None = None) -> LintResponse:
        """Validate a SemQL query and compute auto-complete suggestions.

        Does not require an API key. ``cursor`` is a byte offset into
        ``query``; when ``None`` the server treats it as the end of the text.
        Returns diagnostics and completions in a single response.
        """
        request = LintRequest(query=query, cursor=cursor)
        raw = self._post("/v1/lint", body=request, auth=False)
        return LintResponse.model_validate(raw or {})

    def publish(
        self,
        *,
        items: list[PublishItem],
        namespace: str = DEFAULT_NAMESPACE,
        model: str = DEFAULT_MODEL,
        dimensions: int = DEFAULT_DIMENSIONS,
        metadata: dict[str, str] | None = None,
        idempotency_key: str | None = None,
        ack: Ack = "stored",
    ) -> PublishResponse:
        """Publish a single message into ``namespace``.

        ``namespace`` defaults to ``"global"`` — the shared, ready-to-use
        namespace backed by ``Qwen3-Embedding-4B`` at 1024 dimensions. Pass
        ``namespace=`` to target a private namespace you've provisioned on
        the Noetive dashboard.

        Each ``PublishItem`` carries either ``text`` (server computes the
        embedding) or a pre-computed ``vector``.

        ``ack`` controls the durability / latency tradeoff:

        * ``"stored"`` (default) — return once the write survives a single
          server restart.
        * ``"durable"`` — return once the write survives power loss.

        ``idempotency_key`` collapses retries: within the server-side retention
        window, the same key yields the same ``message_id`` and ``seq``.
        """
        request = PublishRequest(
            namespace=namespace,
            model=model,
            dimensions=dimensions,
            items=items,
            metadata=metadata,
            idempotency_key=idempotency_key,
            ack=ack,
        )
        raw = self._post("/v1/publish", body=request, auth=True)
        return PublishResponse.model_validate(raw or {})

    def search(
        self,
        *,
        query: str,
        namespace: str = DEFAULT_NAMESPACE,
        model: str = DEFAULT_MODEL,
        dimensions: int = DEFAULT_DIMENSIONS,
        limit: int | None = None,
    ) -> SearchResponse:
        """Execute a SemQL semantic search query.

        Requires an API key. ``namespace`` defaults to ``"global"`` (backed by
        ``Qwen3-Embedding-4B`` at 1024 dimensions). When ``limit`` is omitted,
        the server honors the ``LIMIT n`` clause of the SemQL query if present.
        """
        request = SearchRequest(
            query=query,
            namespace=namespace,
            model=model,
            dimensions=dimensions,
            limit=limit,
        )
        raw = self._post("/v1/search", body=request, auth=True)
        return SearchResponse.model_validate(raw or {})

    def subscribe(
        self,
        *,
        query: str,
        namespace: str = DEFAULT_NAMESPACE,
        model: str = DEFAULT_MODEL,
        dimensions: int = DEFAULT_DIMENSIONS,
    ) -> SubscribeStream:
        """Open a Server-Sent Events stream of matches for a SemQL query.

        ``namespace`` defaults to ``"global"`` (backed by ``Qwen3-Embedding-4B``
        at 1024 dimensions). Use it as a context manager to open and close
        the underlying HTTP connection::

            with client.subscribe(...) as stream:
                print(stream.subscription_id)
                for match in stream:
                    handle(match)

        The opening ``event: subscribed`` frame is consumed eagerly, so
        ``stream.subscription_id`` is populated before the first ``match``
        is yielded.
        """
        api_key = require_api_key(self._api_key)
        request = SubscribeRequest(
            query=query, namespace=namespace, model=model, dimensions=dimensions
        )
        return SubscribeStream(
            self._http, request, api_key=api_key, retry_policy=self._retry_policy
        )

    # --- internals ---------------------------------------------------------

    def _post(self, path: str, *, body: Any, auth: bool) -> Any:
        api_key = require_api_key(self._api_key) if auth else None
        return request_json_sync(
            self._http,
            "POST",
            path,
            body=body,
            api_key=api_key,
            retry_policy=self._retry_policy,
        )

    # --- lifecycle ---------------------------------------------------------

    def close(self) -> None:
        if self._owns_http:
            self._http.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()


__all__ = ["Client"]
