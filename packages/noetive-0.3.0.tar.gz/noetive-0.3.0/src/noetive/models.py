"""Pydantic v2 models for the Noetive Semantik public API.

Models mirror the schemas in ``public-api.yaml``. Request models enforce the
validation rules the server publishes so invalid input fails before the HTTP
round-trip. Response models use ``extra='allow'`` so new server-side fields
do not break existing clients.
"""

from __future__ import annotations

from typing import Final, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

Ack = Literal["stored", "durable"]
"""Publish acknowledgement durability. See ``PublishRequest.ack``.

* ``stored`` (default) — return once the write survives a single server
  restart.
* ``durable`` — return once the write survives power loss.
"""

_MAX_VECTOR_DIMENSIONS: Final = 4096
_MAX_METADATA_KEYS: Final = 16
_MAX_METADATA_VALUE: Final = 256
_MAX_IDEMPOTENCY_KEY_LEN: Final = 256

DEFAULT_NAMESPACE: Final = "global"
"""The shared default namespace. Use a different namespace name to target a
private namespace you've provisioned on the Noetive dashboard."""

DEFAULT_MODEL: Final = "Qwen3-Embedding-4B"
"""Embedding model used by the ``global`` namespace."""

DEFAULT_DIMENSIONS: Final = 1024
"""Vector dimensionality for the ``global`` namespace's embedding model."""


# --- shared base classes ------------------------------------------------------


class _Request(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=False)


class _Response(BaseModel):
    model_config = ConfigDict(extra="allow")


# --- search -------------------------------------------------------------------


class SearchRequest(_Request):
    """Request body for ``POST /v1/search``."""

    query: str
    namespace: str = DEFAULT_NAMESPACE
    model: str = DEFAULT_MODEL
    dimensions: int = Field(default=DEFAULT_DIMENSIONS, gt=0, le=_MAX_VECTOR_DIMENSIONS)
    limit: int | None = Field(default=None, gt=0)


class ResultItem(_Response):
    """One matched document returned by :class:`SearchResponse`."""

    content: str | None = None
    message_id: str | None = None
    namespace: str | None = None
    score: float | None = None
    metadata: dict[str, str] | None = None


class SearchResponse(_Response):
    """Response body for ``POST /v1/search``."""

    results: list[ResultItem] = Field(default_factory=list)


# --- publish ------------------------------------------------------------------


class PublishItem(BaseModel):
    """A message to publish. Exactly one of ``text`` or ``vector`` is set."""

    model_config = ConfigDict(extra="forbid")

    text: str | None = None
    vector: list[float] | None = None

    @model_validator(mode="after")
    def _exactly_one(self) -> PublishItem:
        has_text = self.text is not None
        has_vector = self.vector is not None
        if has_text == has_vector:
            raise ValueError(
                "PublishItem requires exactly one of 'text' or 'vector'"
            )
        if has_vector and self.vector is not None and len(self.vector) > _MAX_VECTOR_DIMENSIONS:
            raise ValueError(
                f"vector length {len(self.vector)} exceeds the {_MAX_VECTOR_DIMENSIONS}-dim limit"
            )
        return self


class PublishRequest(_Request):
    """Request body for ``POST /v1/publish``."""

    namespace: str = DEFAULT_NAMESPACE
    model: str = DEFAULT_MODEL
    dimensions: int = Field(default=DEFAULT_DIMENSIONS, gt=0, le=_MAX_VECTOR_DIMENSIONS)
    items: list[PublishItem] = Field(min_length=1, max_length=1)
    metadata: dict[str, str] | None = Field(default=None)
    idempotency_key: str | None = Field(default=None, max_length=_MAX_IDEMPOTENCY_KEY_LEN)
    ack: Ack | None = None

    @model_validator(mode="after")
    def _check_metadata(self) -> PublishRequest:
        if self.metadata is None:
            return self
        if len(self.metadata) > _MAX_METADATA_KEYS:
            raise ValueError(
                f"metadata has {len(self.metadata)} keys; max {_MAX_METADATA_KEYS}"
            )
        for key, value in self.metadata.items():
            if len(value) > _MAX_METADATA_VALUE:
                raise ValueError(
                    f"metadata[{key!r}] value length {len(value)} exceeds "
                    f"{_MAX_METADATA_VALUE} chars"
                )
        return self


class PublishResponse(_Response):
    """Response body for ``POST /v1/publish``.

    ``epoch`` is an opaque server-configuration token; ``seq`` is a
    per-namespace monotonic ordering token. Neither is a position usable
    with :meth:`Client.search`.
    """

    message_id: str
    epoch: int
    seq: int


# --- lint ---------------------------------------------------------------------


class LintRequest(_Request):
    """Request body for ``POST /v1/lint``."""

    query: str
    cursor: int | None = Field(default=None, ge=0)


class LintDiagnostic(_Response):
    """One parse/validation diagnostic emitted by the lint endpoint."""

    severity: str | None = None
    message: str | None = None
    line: int | None = None
    col: int | None = None
    end_line: int | None = None
    end_col: int | None = None


class LintCompletion(_Response):
    """One auto-complete suggestion at the requested cursor position."""

    label: str | None = None
    kind: str | None = None
    detail: str | None = None


class LintResponse(_Response):
    """Response body for ``POST /v1/lint``.

    ``valid`` is ``True`` only when there are no error-severity diagnostics.
    ``normalized`` is the canonical SemQL form (empty when the query is
    invalid).
    """

    valid: bool = False
    normalized: str = ""
    diagnostics: list[LintDiagnostic] = Field(default_factory=list)
    completions: list[LintCompletion] = Field(default_factory=list)


# --- subscribe ----------------------------------------------------------------


class SubscribeRequest(_Request):
    """Request body for ``POST /v1/subscribe``."""

    query: str
    namespace: str = DEFAULT_NAMESPACE
    model: str = DEFAULT_MODEL
    dimensions: int = Field(default=DEFAULT_DIMENSIONS, gt=0, le=_MAX_VECTOR_DIMENSIONS)


class SubscribedEvent(_Response):
    """Payload of the opening ``event: subscribed`` SSE frame."""

    subscription_id: str


class MatchEvent(_Response):
    """Payload of each ``event: match`` SSE frame."""

    message_id: str
    score: float


__all__ = [
    "DEFAULT_DIMENSIONS",
    "DEFAULT_MODEL",
    "DEFAULT_NAMESPACE",
    "Ack",
    "LintCompletion",
    "LintDiagnostic",
    "LintResponse",
    "MatchEvent",
    "PublishItem",
    "PublishResponse",
    "ResultItem",
    "SearchResponse",
]
