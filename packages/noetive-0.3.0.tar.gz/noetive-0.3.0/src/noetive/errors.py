"""Exception hierarchy for the Noetive SDK.

The Noetive Semantik API returns a stable JSON error envelope:

    {"error": "<code>", "message": "<human>", "retry_after_ms": <uint>?}

``raise_for_response`` maps HTTP status + ``error`` code to one of the
exceptions defined here. Unknown codes degrade gracefully to :class:`APIError`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar

if TYPE_CHECKING:
    import httpx


class NoetiveError(Exception):
    """Base class for every error raised by the SDK."""

    default_code: ClassVar[str | None] = None

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        status_code: int | None = None,
        retry_after_ms: int | None = None,
        request_id: str | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code: str | None = code or self.__class__.default_code
        self.status_code = status_code
        self.retry_after_ms = retry_after_ms
        self.request_id = request_id
        self.response_body = response_body

    def __str__(self) -> str:
        if self.request_id:
            return f"{self.message} [request_id={self.request_id}]"
        return self.message

    def __repr__(self) -> str:
        parts = [f"message={self.message!r}"]
        if self.code:
            parts.append(f"code={self.code!r}")
        if self.status_code is not None:
            parts.append(f"status_code={self.status_code}")
        if self.retry_after_ms is not None:
            parts.append(f"retry_after_ms={self.retry_after_ms}")
        if self.request_id is not None:
            parts.append(f"request_id={self.request_id!r}")
        return f"{type(self).__name__}({', '.join(parts)})"


class TransportError(NoetiveError):
    """Network-layer failure: DNS, connect, read, write, or protocol error."""


class AuthenticationError(NoetiveError):
    """Missing or invalid API key. Maps to HTTP 401 ``unauthorized``."""

    default_code = "unauthorized"


class InvalidRequestError(NoetiveError):
    """Request body failed server-side validation. Maps to HTTP 400."""

    default_code = "invalid_request"


class BillingError(NoetiveError):
    """Billing blocks the call. Maps to HTTP 402 ``not_billable``.

    The request is authenticated but the account has no active or trialing
    subscription. Retrying will keep failing until billing is resolved on
    the Noetive dashboard.
    """

    default_code = "not_billable"


class RequestTooLargeError(NoetiveError):
    """Request body exceeds the endpoint size limit. Maps to HTTP 413."""

    default_code = "request_too_large"


class UnsupportedMediaTypeError(NoetiveError):
    """Content-Type was not ``application/json``. Maps to HTTP 415."""

    default_code = "unsupported_media_type"


class RateLimitError(NoetiveError):
    """Per-client burst or sustained rate limit exhausted. Maps to HTTP 429."""

    default_code = "rate_limited"


class TooManyRequestsError(RateLimitError):
    """Concurrency limit exhausted. Maps to HTTP 429 ``too_many_requests``."""

    default_code = "too_many_requests"


class BackpressureError(RateLimitError):
    """Service is applying backpressure. ``retry_after_ms`` is always set."""

    default_code = "backpressure"


class ServiceUnavailableError(NoetiveError):
    """Service temporarily unavailable. Maps to HTTP 503.

    The ``error`` code identifies which subsystem is degraded so reports
    to support pivot to the right log surface; the recovery action is the
    same for all of them — wait and retry. Carries ``retry_after_ms``
    (with the RFC 9110 ``Retry-After`` header as a fallback); the default
    :class:`~noetive.RetryPolicy` already honors it.

    Codes: ``unavailable``, ``embedder_unavailable``, ``routing_unavailable``,
    ``chain_unavailable``, ``namespace_unavailable``, ``metering_unavailable``.
    Quote the code and ``request_id`` when contacting support.
    """

    default_code = "unavailable"


class NamespaceDisabledError(NoetiveError):
    """Namespace alias exists but has been administratively disabled.

    Maps to ``namespace_disabled``. Not retryable — contact the namespace
    administrator on the Noetive dashboard to re-enable it.
    """

    default_code = "namespace_disabled"


class ModelNotProvisionedError(NoetiveError):
    """Namespace alias has no entry for the requested ``(model, dimensions)``.

    Maps to ``model_not_provisioned``. The namespace exists but isn't
    configured for the model + dimensions you sent. Either pass the
    ``(model, dimensions)`` the namespace was provisioned with, or
    provision a new entry on the Noetive dashboard.
    """

    default_code = "model_not_provisioned"


class IndexBuildingError(NoetiveError):
    """Search index is not yet built; publish more vectors and retry.

    Maps to ``index_building``. Transient — retried by the default
    :class:`~noetive.RetryPolicy`. Carries ``retry_after_ms`` when the
    server provides a hint.
    """

    default_code = "index_building"


class APIError(NoetiveError):
    """Unexpected server error. Maps to HTTP 500 ``internal_error``."""

    default_code = "internal_error"


_CODE_MAP: dict[str, type[NoetiveError]] = {
    "unauthorized": AuthenticationError,
    "invalid_request": InvalidRequestError,
    "not_billable": BillingError,
    "request_too_large": RequestTooLargeError,
    "unsupported_media_type": UnsupportedMediaTypeError,
    "rate_limited": RateLimitError,
    "too_many_requests": TooManyRequestsError,
    "backpressure": BackpressureError,
    # Transient service state. All of these carry ``retry_after_ms`` and
    # are mapped to the same exception class so callers can branch on
    # ``err.code`` when the recovery action differs.
    "unavailable": ServiceUnavailableError,
    "embedder_unavailable": ServiceUnavailableError,
    "routing_unavailable": ServiceUnavailableError,
    "chain_unavailable": ServiceUnavailableError,
    "namespace_unavailable": ServiceUnavailableError,
    "metering_unavailable": ServiceUnavailableError,
    "namespace_disabled": NamespaceDisabledError,
    "model_not_provisioned": ModelNotProvisionedError,
    "index_building": IndexBuildingError,
    "internal_error": APIError,
}

_STATUS_FALLBACK: dict[int, type[NoetiveError]] = {
    400: InvalidRequestError,
    401: AuthenticationError,
    402: BillingError,
    413: RequestTooLargeError,
    415: UnsupportedMediaTypeError,
    429: RateLimitError,
    500: APIError,
    503: ServiceUnavailableError,
}


def raise_for_response(response: httpx.Response, body: Any) -> None:
    """Raise the exception that matches ``response``.

    ``body`` is the decoded JSON envelope if the server returned one, else
    ``None``. Exceptions are constructed with structured fields (code, status,
    retry_after_ms, request_id) so callers can branch on them programmatically.

    ``retry_after_ms`` is sourced from (in order): the body's ``retry_after_ms``
    field, then the RFC 9110 ``Retry-After`` response header (interpreted as
    integer seconds; HTTP-date form is ignored).
    """
    status = response.status_code
    code: str | None = None
    message = ""
    retry_after_ms: int | None = None

    body_request_id: str | None = None
    if isinstance(body, dict):
        raw_code = body.get("error")
        if isinstance(raw_code, str):
            code = raw_code
        raw_msg = body.get("message")
        if isinstance(raw_msg, str):
            message = raw_msg
        raw_retry = body.get("retry_after_ms")
        if isinstance(raw_retry, int) and raw_retry > 0:
            retry_after_ms = raw_retry
        raw_rid = body.get("request_id")
        if isinstance(raw_rid, str) and raw_rid:
            body_request_id = raw_rid

    if retry_after_ms is None:
        retry_after_ms = _parse_retry_after_header(response.headers.get("retry-after"))

    if not message:
        message = f"HTTP {status}" + (f" ({code})" if code else "")

    exc_cls: type[NoetiveError]
    if code and code in _CODE_MAP:
        exc_cls = _CODE_MAP[code]
    elif status in _STATUS_FALLBACK:
        exc_cls = _STATUS_FALLBACK[status]
    else:
        exc_cls = APIError

    request_id = response.headers.get("x-request-id") or body_request_id

    raise exc_cls(
        message,
        code=code,
        status_code=status,
        retry_after_ms=retry_after_ms,
        request_id=request_id,
        response_body=body,
    )


def _parse_retry_after_header(value: str | None) -> int | None:
    """Parse an RFC 9110 ``Retry-After`` header value.

    Only the integer-seconds form is parsed; any other value — HTTP-date
    form, floating-point, garbage — returns ``None`` and lets the retry
    policy fall back to its own backoff. The service only emits seconds.
    Returns milliseconds, or ``None`` if the header is absent, non-numeric,
    zero, or negative.
    """
    if not value:
        return None
    try:
        seconds = int(value.strip())
    except ValueError:
        return None
    if seconds <= 0:
        return None
    return seconds * 1000


__all__ = [
    "APIError",
    "AuthenticationError",
    "BackpressureError",
    "BillingError",
    "IndexBuildingError",
    "InvalidRequestError",
    "ModelNotProvisionedError",
    "NamespaceDisabledError",
    "NoetiveError",
    "RateLimitError",
    "RequestTooLargeError",
    "ServiceUnavailableError",
    "TooManyRequestsError",
    "TransportError",
    "UnsupportedMediaTypeError",
    "raise_for_response",
]
