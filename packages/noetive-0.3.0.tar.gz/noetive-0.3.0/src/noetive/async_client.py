"""Asynchronous client for the Noetive Semantik public API.

Mirrors the sync :class:`noetive.Client` surface with ``async def`` methods
and :class:`AsyncSubscribeStream` for SSE subscriptions. Share an httpx
``AsyncClient`` between calls via the context-manager idiom::

    async with AsyncClient() as noetive:
        await noetive.health()
"""

from __future__ import annotations

import os
from types import TracebackType
from typing import Any

import httpx

from ._retry import RetryPolicy
from ._transport import (
    API_KEY_ENV,
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
    assert_tls_verification,
    request_json_async,
    require_api_key,
)
from .models import (
    DEFAULT_DIMENSIONS,
    DEFAULT_MODEL,
    DEFAULT_NAMESPACE,
    Ack,
    LintRequest,
    LintResponse,
    PublishItem,
    PublishRequest,
    PublishResponse,
    SearchRequest,
    SearchResponse,
    SubscribeRequest,
)
from .streaming import AsyncSubscribeStream


class AsyncClient:
    """Asynchronous Noetive Semantik client.

    The async surface mirrors :class:`noetive.Client` method-for-method.
    Use ``async with`` for automatic cleanup of the underlying
    :class:`httpx.AsyncClient`.

    Usage::

        async with AsyncClient() as noetive:   # reads NOETIVE_KEY_SECRET
            await noetive.health()

    :param api_key: API key in the ``keyu_...`` form from the Noetive
        dashboard. When omitted, ``NOETIVE_KEY_SECRET`` is used. Endpoints that
        require auth raise :class:`AuthenticationError` when no key is found.
    :param base_url: Override the API endpoint. Defaults to the production
        URL ``https://semantik.noetive.io``.
    :param timeout: A float (seconds, applied to all phases) or
        :class:`httpx.Timeout` instance. The default is
        ``httpx.Timeout(30.0, connect=5.0)`` — 30 s read/write/pool, 5 s
        connect.
    :param max_retries: Maximum retry attempts for transient failures.
        ``1`` (the default) means a single retry — two total attempts per
        request. Same policy is applied to one-shot JSON calls and to
        ``subscribe()`` open.
    :param http2: Whether to negotiate HTTP/2 (bundled via ``httpx[http2]``).
    :param http_client: Inject a pre-configured :class:`httpx.AsyncClient`
        (e.g. for mock transports or a corporate proxy). The injected client
        **must** have TLS certificate verification enabled (``verify=True``,
        the httpx default); the SDK rejects clients with ``verify=False`` at
        construction time. When provided, ``base_url``, ``timeout`` and
        ``http2`` are ignored — configure them on the supplied client.
    :param retry_policy: Override the default :class:`RetryPolicy`. Takes
        precedence over ``max_retries`` when both are supplied.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float | httpx.Timeout = DEFAULT_TIMEOUT,
        max_retries: int = 1,
        http2: bool = True,
        http_client: httpx.AsyncClient | None = None,
        retry_policy: RetryPolicy | None = None,
    ) -> None:
        self._api_key = api_key if api_key is not None else os.environ.get(API_KEY_ENV)
        if retry_policy is not None:
            self._retry_policy = retry_policy
        else:
            self._retry_policy = RetryPolicy(max_attempts=max_retries + 1)
        if http_client is None:
            self._http = httpx.AsyncClient(base_url=base_url, timeout=timeout, http2=http2)
            self._owns_http = True
        else:
            assert_tls_verification(http_client)
            self._http = http_client
            self._owns_http = False

    @property
    def base_url(self) -> str:
        return str(self._http.base_url)

    # --- endpoints ---------------------------------------------------------

    async def health(self) -> None:
        """Liveness probe. Raises on non-2xx; returns ``None`` on success.

        Does not require an API key.
        """
        await self._post("/v1/health", body=None, auth=False)

    async def lint(self, *, query: str, cursor: int | None = None) -> LintResponse:
        """Validate a SemQL query and compute auto-complete suggestions.

        Does not require an API key. ``cursor`` is a byte offset into
        ``query``; when ``None`` the server treats it as the end of the text.
        """
        request = LintRequest(query=query, cursor=cursor)
        raw = await self._post("/v1/lint", body=request, auth=False)
        return LintResponse.model_validate(raw or {})

    async def publish(
        self,
        *,
        items: list[PublishItem],
        namespace: str = DEFAULT_NAMESPACE,
        model: str = DEFAULT_MODEL,
        dimensions: int = DEFAULT_DIMENSIONS,
        metadata: dict[str, str] | None = None,
        idempotency_key: str | None = None,
        ack: Ack = "stored",
    ) -> PublishResponse:
        """Publish a single message. See :meth:`Client.publish`.

        Defaults target the ``"global"`` namespace (``Qwen3-Embedding-4B``,
        1024 dimensions).
        """
        request = PublishRequest(
            namespace=namespace,
            model=model,
            dimensions=dimensions,
            items=items,
            metadata=metadata,
            idempotency_key=idempotency_key,
            ack=ack,
        )
        raw = await self._post("/v1/publish", body=request, auth=True)
        return PublishResponse.model_validate(raw or {})

    async def search(
        self,
        *,
        query: str,
        namespace: str = DEFAULT_NAMESPACE,
        model: str = DEFAULT_MODEL,
        dimensions: int = DEFAULT_DIMENSIONS,
        limit: int | None = None,
    ) -> SearchResponse:
        """Execute a SemQL semantic search query. See :meth:`Client.search`.

        Defaults target the ``"global"`` namespace.
        """
        request = SearchRequest(
            query=query,
            namespace=namespace,
            model=model,
            dimensions=dimensions,
            limit=limit,
        )
        raw = await self._post("/v1/search", body=request, auth=True)
        return SearchResponse.model_validate(raw or {})

    def subscribe(
        self,
        *,
        query: str,
        namespace: str = DEFAULT_NAMESPACE,
        model: str = DEFAULT_MODEL,
        dimensions: int = DEFAULT_DIMENSIONS,
    ) -> AsyncSubscribeStream:
        """Open a Server-Sent Events stream of matches for a SemQL query.

        Returns an unopened :class:`AsyncSubscribeStream`. Defaults target
        the ``"global"`` namespace. Use ``async with`` to open the HTTP
        connection and close it cleanly on exit.
        """
        api_key = require_api_key(self._api_key)
        request = SubscribeRequest(
            query=query, namespace=namespace, model=model, dimensions=dimensions
        )
        return AsyncSubscribeStream(
            self._http, request, api_key=api_key, retry_policy=self._retry_policy
        )

    # --- internals ---------------------------------------------------------

    async def _post(self, path: str, *, body: Any, auth: bool) -> Any:
        api_key = require_api_key(self._api_key) if auth else None
        return await request_json_async(
            self._http,
            "POST",
            path,
            body=body,
            api_key=api_key,
            retry_policy=self._retry_policy,
        )

    # --- lifecycle ---------------------------------------------------------

    async def close(self) -> None:
        if self._owns_http:
            await self._http.aclose()

    async def __aenter__(self) -> AsyncClient:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.close()


__all__ = ["AsyncClient"]
