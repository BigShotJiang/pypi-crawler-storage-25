"""Noetive Semantik Python SDK.

Top-level re-exports provide the public surface::

    from noetive import Client, NoetiveError

Submodules (``noetive.errors``, ``noetive.models``) remain importable for
users who want fine-grained access.
"""

from ._retry import DEFAULT_RETRY_POLICY, RetryPolicy
from ._version import __version__
from .async_client import AsyncClient
from .client import Client
from .errors import (
    APIError,
    AuthenticationError,
    BackpressureError,
    BillingError,
    IndexBuildingError,
    InvalidRequestError,
    ModelNotProvisionedError,
    NamespaceDisabledError,
    NoetiveError,
    RateLimitError,
    RequestTooLargeError,
    ServiceUnavailableError,
    TooManyRequestsError,
    TransportError,
    UnsupportedMediaTypeError,
)
from .models import (
    DEFAULT_DIMENSIONS,
    DEFAULT_MODEL,
    DEFAULT_NAMESPACE,
    Ack,
    LintCompletion,
    LintDiagnostic,
    LintResponse,
    MatchEvent,
    PublishItem,
    PublishResponse,
    ResultItem,
    SearchResponse,
)
from .streaming import AsyncSubscribeStream, SubscribeStream

__all__ = [
    "DEFAULT_DIMENSIONS",
    "DEFAULT_MODEL",
    "DEFAULT_NAMESPACE",
    "DEFAULT_RETRY_POLICY",
    "APIError",
    "Ack",
    "AsyncClient",
    "AsyncSubscribeStream",
    "AuthenticationError",
    "BackpressureError",
    "BillingError",
    "Client",
    "IndexBuildingError",
    "InvalidRequestError",
    "LintCompletion",
    "LintDiagnostic",
    "LintResponse",
    "MatchEvent",
    "ModelNotProvisionedError",
    "NamespaceDisabledError",
    "NoetiveError",
    "PublishItem",
    "PublishResponse",
    "RateLimitError",
    "RequestTooLargeError",
    "ResultItem",
    "RetryPolicy",
    "SearchResponse",
    "ServiceUnavailableError",
    "SubscribeStream",
    "TooManyRequestsError",
    "TransportError",
    "UnsupportedMediaTypeError",
    "__version__",
]
