"""Server-Sent Events subscription streams.

``Client.subscribe()`` returns a :class:`SubscribeStream`; the async client's
equivalent returns :class:`AsyncSubscribeStream`. Both open an HTTP POST to
``/v1/subscribe`` and hold the connection open while the server pushes
``match`` events.

Usage::

    with noetive.subscribe(query=..., namespace=..., model=..., dimensions=...) as stream:
        print("subscription:", stream.subscription_id)
        for match in stream:
            print(match.message_id, match.score)

The ``subscription_id`` attribute is populated before the first ``match``
event is yielded — the stream eagerly consumes the opening ``event:
subscribed`` frame so callers can access it without iterating.

Consumer contract
-----------------

The stream has **no application-level buffer**. Each iteration step reads
directly from the underlying HTTP chunk stream, so a slow consumer exerts
TCP-level backpressure on the service: the server pauses emission when the
receive window fills. That is usually what you want — it keeps memory flat
— but it means the server stops pushing events for your subscription while
your consumer is blocked.

If your consumer work is slow (disk, another network call, etc.), decouple
it from iteration using a bounded queue drained by a separate task. See
``examples/async_subscribe.py`` for the pattern.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import time
from types import TracebackType
from typing import TYPE_CHECKING, Any

from ._retry import DEFAULT_RETRY_POLICY, RetryPolicy
from ._sse import SSEEvent, SSEParser
from ._transport import SUBSCRIBE_TIMEOUT, default_headers
from .errors import APIError, NoetiveError, TransportError, raise_for_response
from .models import MatchEvent, SubscribedEvent, SubscribeRequest

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Awaitable, Callable, Iterator

    import httpx

    _SyncSleeper = Callable[[float], None]
    _AsyncSleeper = Callable[[float], Awaitable[None]]


_SSE_ACCEPT = "text/event-stream"


def _build_subscribe_headers(api_key: str) -> dict[str, str]:
    headers = default_headers(api_key=api_key)
    headers["Accept"] = _SSE_ACCEPT
    headers["Content-Type"] = "application/json"
    # Per the SSE spec, clients should not cache and should not compress.
    # httpx defaults to ``Accept-Encoding: gzip, deflate`` on every request;
    # leaving that in place lets the server gzip the SSE body, which buffers
    # match frames behind the compressor's flush boundary and delays delivery.
    # ``identity`` forces the server to emit each frame verbatim.
    headers["Accept-Encoding"] = "identity"
    headers["Cache-Control"] = "no-cache"
    return headers


def _payload(request: SubscribeRequest) -> bytes:
    return request.model_dump_json(exclude_none=True).encode("utf-8")


def _parse_match_data(data: str) -> MatchEvent:
    try:
        payload = json.loads(data)
    except ValueError as exc:
        raise APIError(f"malformed match event: {exc}") from exc
    return MatchEvent.model_validate(payload)


def _parse_subscribed_data(data: str) -> SubscribedEvent:
    try:
        payload = json.loads(data)
    except ValueError as exc:
        raise APIError(f"malformed subscribed event: {exc}") from exc
    return SubscribedEvent.model_validate(payload)


def _read_error_body(body_bytes: bytes, content_type: str) -> Any:
    if "application/json" not in content_type or not body_bytes:
        return None
    try:
        return json.loads(body_bytes)
    except ValueError:
        return None


class SubscribeStream:
    """Synchronous SSE stream of match events.

    Use as a context manager; iteration yields :class:`MatchEvent`. The
    opening ``subscribed`` frame is consumed eagerly, so ``subscription_id``
    is available before iteration starts.
    """

    def __init__(
        self,
        http: httpx.Client,
        request: SubscribeRequest,
        *,
        api_key: str,
        retry_policy: RetryPolicy | None = None,
        sleeper: _SyncSleeper | None = None,
    ) -> None:
        self._http = http
        self._request = request
        self._api_key = api_key
        self._retry_policy = retry_policy if retry_policy is not None else DEFAULT_RETRY_POLICY
        self._sleep = sleeper if sleeper is not None else time.sleep
        self._stream_ctx: Any = None
        self._response: httpx.Response | None = None
        self._parser = SSEParser()
        self._events: Iterator[SSEEvent] | None = None
        self._subscription_id: str | None = None
        self._closed = False

    @property
    def subscription_id(self) -> str:
        """Server-assigned subscription identifier.

        Available once the stream has been opened (after ``__enter__`` or
        explicit :meth:`open`).
        """
        if self._subscription_id is None:
            raise RuntimeError(
                "subscription_id is only available after the stream is opened "
                "(enter its context manager or call open() / await open())"
            )
        return self._subscription_id

    def open(self) -> SubscribeStream:
        """Start the HTTP request and consume the opening ``subscribed`` event.

        Retries the open phase per the configured :class:`RetryPolicy` —
        503-style transient failures and connect/read errors during
        handshake. Once the ``subscribed`` frame has been delivered,
        errors during iteration propagate unmodified: replaying mid-stream
        would dupe or skip events.
        """
        if self._response is not None:
            return self
        attempt = 0
        while True:
            attempt += 1
            try:
                return self._open_once()
            except NoetiveError as err:
                delay = self._retry_policy.delay_for(err, attempt=attempt)
                if delay is None:
                    raise
                self._sleep(delay)

    def _open_once(self) -> SubscribeStream:
        headers = _build_subscribe_headers(self._api_key)
        body = _payload(self._request)
        # Subscribe is a long-lived SSE stream; the client-default 30 s
        # read timeout would fire whenever the gap between matches exceeds
        # 30 s. SUBSCRIBE_TIMEOUT keeps the connect budget so a hung
        # handshake still surfaces fast, and disables the read deadline
        # so an idle stream does not abort.
        self._stream_ctx = self._http.stream(
            "POST",
            "/v1/subscribe",
            content=body,
            headers=headers,
            timeout=SUBSCRIBE_TIMEOUT,
        )
        try:
            response = self._stream_ctx.__enter__()
        except Exception as exc:
            self._reset_stream_ctx()
            raise TransportError(f"POST /v1/subscribe: {exc}") from exc
        self._response = response
        if response.status_code != 200:
            try:
                error_bytes = response.read()
            except Exception:  # pragma: no cover
                error_bytes = b""
            body_obj = _read_error_body(error_bytes, response.headers.get("content-type", ""))
            try:
                raise_for_response(response, body_obj)
            finally:
                self._reset_stream_ctx()
            raise AssertionError("unreachable")  # pragma: no cover

        self._events = self._iter_events()
        self._subscription_id = self._consume_subscribed()
        return self

    def _reset_stream_ctx(self) -> None:
        """Tear down the current stream context without marking the stream closed.

        Called between failed open attempts so retries can build a fresh
        context. ``_cleanup`` is the terminal version that flips
        ``_closed`` and refuses further work.
        """
        if self._stream_ctx is not None:
            with contextlib.suppress(Exception):  # pragma: no cover - best-effort teardown
                self._stream_ctx.__exit__(None, None, None)
            self._stream_ctx = None
        self._response = None

    def _iter_events(self) -> Iterator[SSEEvent]:
        assert self._response is not None
        for chunk in self._response.iter_bytes():
            yield from self._parser.feed(chunk)
        yield from self._parser.close()

    def _consume_subscribed(self) -> str:
        assert self._events is not None
        for event in self._events:
            if event.event == "subscribed":
                sub = _parse_subscribed_data(event.data)
                return sub.subscription_id
            if event.event == "match":
                raise APIError(
                    "received 'match' event before 'subscribed'; "
                    "protocol violation"
                )
            # Ignore unknown event types per the SSE spec.
        raise APIError("stream closed before 'subscribed' event arrived")

    def __iter__(self) -> Iterator[MatchEvent]:
        if self._response is None:
            self.open()
        assert self._events is not None
        for event in self._events:
            if event.event == "match":
                yield _parse_match_data(event.data)

    def close(self) -> None:
        self._cleanup()

    def _cleanup(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._stream_ctx is not None:
            try:
                with contextlib.suppress(Exception):  # pragma: no cover - best-effort cleanup
                    self._stream_ctx.__exit__(None, None, None)
            finally:
                self._stream_ctx = None
                self._response = None

    def __enter__(self) -> SubscribeStream:
        self.open()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self._cleanup()


class AsyncSubscribeStream:
    """Async SSE stream of match events. Iteration yields :class:`MatchEvent`."""

    def __init__(
        self,
        http: httpx.AsyncClient,
        request: SubscribeRequest,
        *,
        api_key: str,
        retry_policy: RetryPolicy | None = None,
        sleeper: _AsyncSleeper | None = None,
    ) -> None:
        self._http = http
        self._request = request
        self._api_key = api_key
        self._retry_policy = retry_policy if retry_policy is not None else DEFAULT_RETRY_POLICY
        self._sleep = sleeper if sleeper is not None else asyncio.sleep
        self._stream_ctx: Any = None
        self._response: httpx.Response | None = None
        self._parser = SSEParser()
        self._events: AsyncIterator[SSEEvent] | None = None
        self._subscription_id: str | None = None
        self._closed = False

    @property
    def subscription_id(self) -> str:
        if self._subscription_id is None:
            raise RuntimeError(
                "subscription_id is only available after the stream is opened "
                "(enter its context manager or call open() / await open())"
            )
        return self._subscription_id

    async def open(self) -> AsyncSubscribeStream:
        """Start the HTTP request and consume the opening ``subscribed`` event.

        Retries the open phase per the configured :class:`RetryPolicy`.
        Mid-stream errors propagate unmodified — replaying after a
        delivered ``subscribed`` would dupe or skip events.
        """
        if self._response is not None:
            return self
        attempt = 0
        while True:
            attempt += 1
            try:
                return await self._open_once()
            except NoetiveError as err:
                delay = self._retry_policy.delay_for(err, attempt=attempt)
                if delay is None:
                    raise
                await self._sleep(delay)

    async def _open_once(self) -> AsyncSubscribeStream:
        headers = _build_subscribe_headers(self._api_key)
        body = _payload(self._request)
        # See SubscribeStream._open_once for why subscribe overrides the
        # client-default read timeout: long-lived SSE streams have
        # indefinite gaps between events.
        self._stream_ctx = self._http.stream(
            "POST",
            "/v1/subscribe",
            content=body,
            headers=headers,
            timeout=SUBSCRIBE_TIMEOUT,
        )
        try:
            response = await self._stream_ctx.__aenter__()
        except Exception as exc:
            await self._reset_stream_ctx()
            raise TransportError(f"POST /v1/subscribe: {exc}") from exc
        self._response = response
        if response.status_code != 200:
            try:
                error_bytes = await response.aread()
            except Exception:  # pragma: no cover
                error_bytes = b""
            body_obj = _read_error_body(error_bytes, response.headers.get("content-type", ""))
            try:
                raise_for_response(response, body_obj)
            finally:
                await self._reset_stream_ctx()
            raise AssertionError("unreachable")  # pragma: no cover

        self._events = self._iter_events()
        self._subscription_id = await self._consume_subscribed()
        return self

    async def _reset_stream_ctx(self) -> None:
        """Async twin of :meth:`SubscribeStream._reset_stream_ctx`."""
        if self._stream_ctx is not None:
            with contextlib.suppress(Exception):  # pragma: no cover - best-effort teardown
                await self._stream_ctx.__aexit__(None, None, None)
            self._stream_ctx = None
        self._response = None

    async def _iter_events(self) -> AsyncIterator[SSEEvent]:
        assert self._response is not None
        async for chunk in self._response.aiter_bytes():
            for event in self._parser.feed(chunk):
                yield event
        for event in self._parser.close():
            yield event

    async def _consume_subscribed(self) -> str:
        assert self._events is not None
        async for event in self._events:
            if event.event == "subscribed":
                sub = _parse_subscribed_data(event.data)
                return sub.subscription_id
            if event.event == "match":
                raise APIError(
                    "received 'match' event before 'subscribed'; protocol violation"
                )
        raise APIError("stream closed before 'subscribed' event arrived")

    def __aiter__(self) -> AsyncIterator[MatchEvent]:
        return self._aiter_matches()

    async def _aiter_matches(self) -> AsyncIterator[MatchEvent]:
        if self._response is None:
            await self.open()
        assert self._events is not None
        async for event in self._events:
            if event.event == "match":
                yield _parse_match_data(event.data)

    async def aclose(self) -> None:
        await self._cleanup()

    async def _cleanup(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._stream_ctx is not None:
            try:
                with contextlib.suppress(Exception):  # pragma: no cover - best-effort cleanup
                    await self._stream_ctx.__aexit__(None, None, None)
            finally:
                self._stream_ctx = None
                self._response = None

    async def __aenter__(self) -> AsyncSubscribeStream:
        await self.open()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self._cleanup()


__all__ = ["AsyncSubscribeStream", "SubscribeStream"]
