"""Retry policy for transient HTTP failures.

Policy overview:

* **Any retriable error carrying ``retry_after_ms``** — honor that delay
  exactly. The server knows best; our jitter is only a fallback.
  ``retry_after_ms`` is populated from the response body and from the
  RFC 9110 ``Retry-After`` header (see :func:`errors.raise_for_response`).
* **429 (rate_limited / too_many_requests / backpressure)** — retriable.
* **503 ``unavailable``** — retriable. Transient service state is surfaced
  here with ``retry_after_ms`` in the body and the RFC 9110 ``Retry-After``
  header set.
* **Transport errors (connect/read timeouts)** — exponential backoff.
* **All other 4xx** — never retry; these indicate client bugs.

The default policy is a single retry: two attempts total with a computed
delay cap of 10 seconds. One retry is enough to ride through the brief
transient conditions documented in the public API while keeping the
caller's tail latency bounded; tighter loops amplify load on a service
that's already returning ``retry_after_ms``.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from .errors import (
    IndexBuildingError,
    NoetiveError,
    RateLimitError,
    ServiceUnavailableError,
    TransportError,
)

_JITTER = random.SystemRandom()
"""System-random jitter so concurrent clients don't retry in lockstep."""


@dataclass(frozen=True)
class RetryPolicy:
    """Controls whether and how long to wait before retrying a failed request.

    Attributes
    ----------
    max_attempts:
        Total attempts including the first. ``2`` (the default) means a
        single retry; raise it for callers willing to accept higher tail
        latency in exchange for more retry budget.
    base_delay_s:
        Seed for exponential backoff. Actual delay for attempt *n* is
        ``base_delay_s * 2**(n-1)`` with full jitter, capped at
        :attr:`max_delay_s`.
    max_delay_s:
        Upper bound on computed backoff. ``retry_after_ms`` from the server
        bypasses this cap — we honor what the server says.
    """

    max_attempts: int = 2
    base_delay_s: float = 0.1
    max_delay_s: float = 10.0

    def compute_backoff(self, attempt: int) -> float:
        """Full-jitter exponential backoff for retry number ``attempt``.

        ``attempt`` is 1-based: the *first* retry is ``attempt=1``. Returned
        value is in seconds, capped at :attr:`max_delay_s`. With full jitter,
        the actual delay is uniformly distributed in ``[0, computed]``.
        """
        if attempt < 1:
            return 0.0
        computed = self.base_delay_s * (2 ** (attempt - 1))
        capped = min(computed, self.max_delay_s)
        return _JITTER.uniform(0.0, capped)

    def delay_for(self, error: NoetiveError, *, attempt: int) -> float | None:
        """Return the seconds to sleep before the next retry, or ``None``.

        ``None`` means: do not retry.
        ``attempt`` is the number of attempts already made (>= 1).
        """
        retriable = (
            RateLimitError,
            ServiceUnavailableError,
            IndexBuildingError,
            TransportError,
        )
        if not isinstance(error, retriable):
            return None
        if attempt >= self.max_attempts:
            return None

        # Server-supplied hint always wins — it knows the real recovery time.
        if error.retry_after_ms:
            return error.retry_after_ms / 1000.0
        return self.compute_backoff(attempt)


DEFAULT_RETRY_POLICY = RetryPolicy()
"""Process-wide default. Override per-client via ``Client(max_retries=...)``."""


__all__ = ["DEFAULT_RETRY_POLICY", "RetryPolicy"]
