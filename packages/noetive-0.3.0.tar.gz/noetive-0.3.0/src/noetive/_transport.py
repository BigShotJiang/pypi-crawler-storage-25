"""Shared HTTP transport primitives for the sync and async clients.

Responsibilities:

* Build the ``User-Agent``, ``Authorization``, ``Content-Type`` and ``Accept``
  headers for every request.
* Serialize Pydantic models to JSON with ``exclude_none=True`` so optional
  fields don't wire ``null`` to the server.
* Decode 2xx JSON responses into ``dict``.
* Decode non-2xx responses, map to exceptions, apply the retry policy.
* Wrap transport-level exceptions in :class:`TransportError`.
"""

from __future__ import annotations

import asyncio
import json
import platform
import ssl
import sys
import time
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any

import httpx
from pydantic import BaseModel

from ._retry import DEFAULT_RETRY_POLICY, RetryPolicy
from ._version import __version__
from .errors import AuthenticationError, NoetiveError, TransportError, raise_for_response

if TYPE_CHECKING:
    from collections.abc import Mapping

_SyncSleeper = Callable[[float], None]
_AsyncSleeper = Callable[[float], Awaitable[None]]


DEFAULT_BASE_URL = "https://semantik.noetive.io"
"""Default Semantik endpoint. Override via ``base_url`` only for testing
(mock transports, recording proxies, or staging environments)."""

DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=5.0)
"""Conservative default: 30 s read/write/pool, 5 s connect.

Applied to one-shot RPCs (Health, Lint, Publish, Search). Subscribe
overrides the read timeout per request via :data:`SUBSCRIBE_TIMEOUT`
because long-lived SSE streams have indefinite gaps between events;
inheriting the 30 s read timeout would kill any subscription whose first
match arrives more than 30 s after the handshake.
"""

SUBSCRIBE_TIMEOUT = httpx.Timeout(connect=5.0, read=None, write=30.0, pool=30.0)
"""Per-request timeout override for ``POST /v1/subscribe``.

``read=None`` disables the read deadline so an idle SSE stream (gap
between matches) does not raise :class:`httpx.ReadTimeout`. The connect
budget stays small to fail fast on unreachable hosts; the write/pool
budgets stay finite because the request body and connection-pool wait
are bounded operations.

Distinguishing setup-time failure from in-flight failure is a deliberate
design decision: a hung handshake is a different problem from a stream
that drops mid-flight. Callers wanting an upper bound on stream duration
should cancel their context, not shorten the read timeout."""

_JSON_CONTENT_TYPE = "application/json"


def build_user_agent() -> str:
    """Return ``noetive-sdk-python/<ver> (<runtime>; <os>/<arch>)``.

    Emitted on every request so server-side logs can attribute traffic to
    specific SDK versions. Example output:
    ``noetive-sdk-python/0.3.0 (cpython3.12.1; darwin/arm64)``.
    """
    py_ver = ".".join(str(p) for p in sys.version_info[:3])
    impl = platform.python_implementation().lower()
    os_name = (platform.system() or "unknown").lower()
    arch = (platform.machine() or "unknown").lower()
    return f"noetive-sdk-python/{__version__} ({impl}{py_ver}; {os_name}/{arch})"


USER_AGENT = build_user_agent()
"""Process-wide User-Agent. Computed once at import; cheap to reuse."""


def assert_tls_verification(http_client: httpx.Client | httpx.AsyncClient) -> None:
    """Reject an injected httpx client that has TLS verification disabled.

    Best-effort introspection of the transport's SSL context. When the
    attribute isn't reachable (custom transport, test fixture, mock), we
    trust the caller rather than second-guess — the public docstring on
    ``Client`` / ``AsyncClient`` already mandates ``verify=True``. The
    only case we explicitly reject is a detectably-disabled verify mode,
    which is the silent TLS-downgrade vector we want to block.
    """
    transport = getattr(http_client, "_transport", None)
    pool = getattr(transport, "_pool", None)
    ctx = getattr(pool, "_ssl_context", None)
    if ctx is None:
        return
    if getattr(ctx, "verify_mode", None) == ssl.CERT_NONE:
        raise ValueError(
            "Injected http_client has TLS certificate verification disabled "
            "(verify_mode=CERT_NONE). Pass a client configured with verify=True."
        )


API_KEY_ENV = "NOETIVE_KEY_SECRET"
"""Environment variable consulted when no ``api_key=`` is passed to the client."""


def require_api_key(api_key: str | None) -> str:
    """Return ``api_key`` or raise :class:`AuthenticationError`.

    Used by endpoints that require auth (publish, search, subscribe). The
    caller has already resolved the key from constructor argument →
    ``API_KEY_ENV`` env var; this helper just enforces non-empty.
    """
    if not api_key:
        raise AuthenticationError(
            "No API key provided. Pass api_key=... or set the "
            f"{API_KEY_ENV} environment variable.",
            status_code=None,
        )
    return api_key


def default_headers(*, api_key: str | None) -> dict[str, str]:
    """Default headers for every JSON request.

    The ``Authorization`` header is added only when ``api_key`` is provided;
    for unauthenticated endpoints (``/v1/lint``, ``/v1/health``) the caller
    passes ``api_key=None``.
    """
    headers: dict[str, str] = {
        "Accept": _JSON_CONTENT_TYPE,
        "User-Agent": USER_AGENT,
    }
    if api_key is not None:
        headers["Authorization"] = f"Bearer {api_key}"
    return headers


def _serialize_body(body: BaseModel | Mapping[str, Any] | None) -> bytes | None:
    if body is None:
        return None
    if isinstance(body, BaseModel):
        return body.model_dump_json(exclude_none=True).encode("utf-8")
    return json.dumps(body, separators=(",", ":")).encode("utf-8")


def _decode_response(response: httpx.Response) -> Any:
    if not response.content:
        return None
    ctype = response.headers.get("content-type", "")
    if "application/json" not in ctype:
        return None
    try:
        return response.json()
    except ValueError:
        return None


def _finalize(response: httpx.Response) -> Any:
    decoded = _decode_response(response)
    if 200 <= response.status_code < 300:
        return decoded
    raise_for_response(response, decoded)
    raise AssertionError("unreachable")  # pragma: no cover


def _build_request(
    body: BaseModel | Mapping[str, Any] | None,
    api_key: str | None,
) -> tuple[bytes | None, dict[str, str]]:
    payload = _serialize_body(body)
    headers = default_headers(api_key=api_key)
    if payload is not None:
        headers["Content-Type"] = _JSON_CONTENT_TYPE
    return payload, headers


def request_json_sync(
    client: httpx.Client,
    method: str,
    path: str,
    *,
    body: BaseModel | Mapping[str, Any] | None,
    api_key: str | None,
    retry_policy: RetryPolicy | None = None,
    sleeper: _SyncSleeper | None = None,
) -> Any:
    """One-shot JSON request with retry. Returns decoded body on 2xx, else raises.

    ``sleeper`` is an injection seam for tests; defaults to :func:`time.sleep`.
    """
    policy = retry_policy if retry_policy is not None else DEFAULT_RETRY_POLICY
    sleep = sleeper if sleeper is not None else time.sleep
    payload, headers = _build_request(body, api_key)

    attempt = 0
    while True:
        attempt += 1
        try:
            response = client.request(method, path, content=payload, headers=headers)
        except httpx.HTTPError as exc:
            error: NoetiveError = TransportError(f"{method} {path}: {exc}")
            delay = policy.delay_for(error, attempt=attempt)
            if delay is None:
                raise error from exc
            sleep(delay)
            continue

        try:
            return _finalize(response)
        except NoetiveError as err:
            delay = policy.delay_for(err, attempt=attempt)
            if delay is None:
                raise
            sleep(delay)


async def request_json_async(
    client: httpx.AsyncClient,
    method: str,
    path: str,
    *,
    body: BaseModel | Mapping[str, Any] | None,
    api_key: str | None,
    retry_policy: RetryPolicy | None = None,
    sleeper: _AsyncSleeper | None = None,
) -> Any:
    """Async twin of :func:`request_json_sync`.

    ``sleeper`` is an injection seam for tests; defaults to :func:`asyncio.sleep`.
    """
    policy = retry_policy if retry_policy is not None else DEFAULT_RETRY_POLICY
    sleep = sleeper if sleeper is not None else asyncio.sleep
    payload, headers = _build_request(body, api_key)

    attempt = 0
    while True:
        attempt += 1
        try:
            response = await client.request(method, path, content=payload, headers=headers)
        except httpx.HTTPError as exc:
            error: NoetiveError = TransportError(f"{method} {path}: {exc}")
            delay = policy.delay_for(error, attempt=attempt)
            if delay is None:
                raise error from exc
            await sleep(delay)
            continue

        try:
            return _finalize(response)
        except NoetiveError as err:
            delay = policy.delay_for(err, attempt=attempt)
            if delay is None:
                raise
            await sleep(delay)


__all__ = [
    "API_KEY_ENV",
    "DEFAULT_BASE_URL",
    "DEFAULT_TIMEOUT",
    "SUBSCRIBE_TIMEOUT",
    "USER_AGENT",
    "assert_tls_verification",
    "build_user_agent",
    "default_headers",
    "request_json_async",
    "request_json_sync",
    "require_api_key",
]
