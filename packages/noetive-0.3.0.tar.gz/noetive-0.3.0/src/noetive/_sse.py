"""Server-Sent Events parser.

Implements the subset of the HTML5 EventSource wire format needed by the
Noetive Semantik ``/v1/subscribe`` endpoint:

* Line terminators: ``\\n``, ``\\r``, or ``\\r\\n``.
* Field syntax: ``field:value``. One optional leading space after the colon
  is stripped. A line with no colon is treated as a field with empty value.
* Lines starting with ``:`` are comments and are ignored.
* An empty line dispatches the accumulated event.
* ``data`` lines concatenate with ``\\n`` between them.
* ``event``, ``id``, ``retry`` are recognized; unknown field names are
  ignored per the spec.
* Events with no ``data`` field are not dispatched (per spec).

The parser is chunk-safe: feeding arbitrary byte slices and then the same
data sliced differently produces the same sequence of events. A trailing
carriage-return byte is held back across ``feed()`` calls because it may
yet become part of a ``\\r\\n`` pair; callers should invoke :meth:`close`
on stream termination to flush anything that's still pending.
"""

from __future__ import annotations

import contextlib
from collections.abc import Iterator
from dataclasses import dataclass, field


@dataclass
class SSEEvent:
    """A fully-received SSE event.

    The ``event`` attribute defaults to ``"message"`` per the SSE spec when
    the server omits an explicit ``event:`` field. ``data`` is the joined
    payload (lines concatenated with ``\\n``).
    """

    event: str = "message"
    data: str = ""
    id: str | None = None
    retry: int | None = None


@dataclass
class _State:
    data_lines: list[str] = field(default_factory=list)
    event: str | None = None
    id: str | None = None
    retry: int | None = None
    saw_data: bool = False


class SSEParser:
    """Incremental SSE parser.

    Usage::

        parser = SSEParser()
        for event in parser.feed(chunk):
            handle(event)
        for event in parser.close():
            handle(event)
    """

    def __init__(self) -> None:
        self._pending = b""
        self._state = _State()

    def feed(self, chunk: bytes) -> Iterator[SSEEvent]:
        """Consume a chunk of bytes and yield any complete events."""
        if not chunk:
            return
        combined = self._pending + chunk
        normalized, remainder = _normalize_newlines(combined)
        parts = normalized.split(b"\n")
        incomplete = parts[-1]
        self._pending = incomplete + remainder
        for raw_line in parts[:-1]:
            yield from self._handle_line(raw_line)

    def close(self) -> Iterator[SSEEvent]:
        """Flush any buffered bytes as a final line and dispatch if ready.

        Invoke this when the upstream stream has ended. A partial event with
        no terminating blank line is *not* dispatched (per the SSE spec), but
        any complete lines sitting in the pending buffer are processed.
        """
        pending = self._pending
        self._pending = b""
        if not pending:
            return
        # Strip any trailing CR leftovers that were held back in case of CRLF.
        normalized = pending.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        parts = normalized.split(b"\n")
        # All parts are complete at close time; no trailing incomplete line.
        for raw_line in parts:
            yield from self._handle_line(raw_line)

    def _handle_line(self, raw_line: bytes) -> Iterator[SSEEvent]:
        if not raw_line:
            event = self._dispatch()
            if event is not None:
                yield event
            return
        if raw_line.startswith(b":"):
            return  # comment
        self._process_line(raw_line)

    def _process_line(self, raw_line: bytes) -> None:
        try:
            line = raw_line.decode("utf-8")
        except UnicodeDecodeError:
            line = raw_line.decode("utf-8", errors="replace")
        if ":" in line:
            name, _, value = line.partition(":")
            if value.startswith(" "):
                value = value[1:]
        else:
            name, value = line, ""
        self._set_field(name, value)

    def _set_field(self, name: str, value: str) -> None:
        state = self._state
        if name == "data":
            state.data_lines.append(value)
            state.saw_data = True
        elif name == "event":
            state.event = value
        elif name == "id":
            if "\x00" not in value:
                state.id = value
        elif name == "retry":
            with contextlib.suppress(ValueError):
                state.retry = int(value)
        # unknown fields are ignored per spec

    def _dispatch(self) -> SSEEvent | None:
        state = self._state
        self._state = _State()
        if not state.saw_data:
            return None
        data = "\n".join(state.data_lines)
        return SSEEvent(
            event=state.event or "message",
            data=data,
            id=state.id,
            retry=state.retry,
        )


def _normalize_newlines(buf: bytes) -> tuple[bytes, bytes]:
    """Replace ``\\r\\n`` and bare ``\\r`` with ``\\n``.

    Returns ``(normalized, remainder)``: ``remainder`` is a trailing ``\\r``
    that must be held until the next chunk arrives (it could still turn
    into ``\\r\\n``). When no trailing ``\\r`` exists, ``remainder`` is empty.
    """
    if not buf:
        return b"", b""
    remainder = b""
    if buf.endswith(b"\r"):
        buf = buf[:-1]
        remainder = b"\r"
    # order matters: replace CRLF first so we don't double-count the CR
    buf = buf.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    return buf, remainder


__all__ = ["SSEEvent", "SSEParser"]
