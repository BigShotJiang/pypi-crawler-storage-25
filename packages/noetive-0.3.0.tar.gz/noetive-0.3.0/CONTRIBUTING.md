# Contributing

Thanks for contributing to `noetive`. This document explains how to set up a
development environment, run the test suite, and ship a release.

## Development setup

Python 3.10 or newer. Create a virtual environment and install the package in
editable mode with dev dependencies:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
```

## Run the tests

Unit tests are hermetic — they mock the transport with `respx` and do not
touch the network:

```bash
pytest tests/unit -q -p no:cacheprovider
```

Integration tests hit the real `https://semantik.noetive.io` endpoint and
require a dashboard API key. They are skipped when `NOETIVE_KEY_SECRET` is
unset:

```bash
export NOETIVE_KEY_SECRET=keyu_...
pytest tests/integration -q -p no:cacheprovider
```

Integration tests publish to the `global` namespace using the
`Qwen3-Embedding-4B` model (1024 dimensions). Each test uses a unique
`idempotency_key` so re-runs are safe.

## Lint + type check

```bash
ruff check src tests
mypy --strict src/noetive
```

CI enforces both; PRs will fail if either reports an issue. Run
`ruff check --fix src tests` to auto-fix simple problems.

## Coding conventions

- **Public API surface** lives in `src/noetive/{client,async_client,models,errors,streaming}.py`.
  Everything exported via `noetive/__init__.py` is considered stable.
- **Private modules** use a leading underscore (`_transport.py`, `_retry.py`,
  `_sse.py`). Their interfaces may change between minor versions.
- **Docstrings** use reStructuredText per PEP 287 (what the Python standard
  library uses), not Google or NumPy style — this matches `httpx` and the
  rest of the modern ecosystem.
- **Type hints** are mandatory on every public callable. `disallow_untyped_defs`
  is enabled in `mypy`. Tests are exempt for ergonomics.
- **No `utils.py` / `common.py` / `helpers.py`.** Every module name should
  describe the domain concept it owns.

## Adding tests

- Prefer behavioural tests: pin the contract, not the call graph.
- Use Hypothesis for parsers, validators, retry-policy arithmetic — anywhere
  there's an algebraic property worth expressing.
- For HTTP behaviour, use `respx` to mock the transport layer. Inject
  `http_client=httpx.Client(base_url=...)` into the SDK client so respx can
  intercept requests.

## Releasing

1. Bump `__version__` in `src/noetive/_version.py`.
2. Move unreleased notes under a new version heading in `CHANGELOG.md`.
3. Commit, tag (`git tag v<version>`), and push both commit and tag.
4. The **Publish** GitHub Actions workflow is triggered on any `v*.*.*`
   tag. It verifies the tag matches `src/noetive/_version.py`, builds the
   wheel + sdist, and uploads to PyPI via OIDC trusted publishing (the
   `pypi` environment must be configured in repo settings). No local
   `twine` credentials are required.

## Reporting issues

Open an issue at <https://github.com/noetive/noetive-sdk-python/issues>.
Please include:

- `noetive.__version__` and Python version.
- The smallest reproducible snippet that triggers the problem.
- The full traceback and, when relevant, the request/response bodies (with
  any secrets redacted).
