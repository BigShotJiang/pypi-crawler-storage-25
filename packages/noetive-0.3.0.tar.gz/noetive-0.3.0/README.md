# Noetive Python SDK

Official Python client for the [Noetive](https://noetive.io) platform.
Today it exposes **Semantik** — a managed semantic broker where you publish
messages tagged with embedding vectors, query them with SemQL, and subscribe
to live match streams over Server-Sent Events. Additional services will land
on this same client as the platform grows.

- **Sync + async**: `Client` and `AsyncClient` share the same surface.
- **High performance**: connection pooling and HTTP/2 via `httpx`.
- **Typed**: Pydantic v2 request/response models and a `py.typed` marker.
- **Retries built-in**: honors `retry_after_ms` (body) and RFC 9110
  `Retry-After` (header) on 429 and 503.
- **SSE subscriptions**: chunk-safe parser and clean context-manager lifecycle.

## Install

```bash
pip install noetive
```

## Authenticate

[Create an API key](https://www.noetive.io/settings/developer-keys) on the
Noetive dashboard (format: `keyu_…`). Pass it explicitly or export it as
an environment variable:

```bash
export NOETIVE_KEY_SECRET=keyu_...
```

`health` and `lint` work without a key; `publish`, `search`, and `subscribe`
require an authenticated account with an active subscription.

Publish, search, and subscribe default to the **`global` namespace** —
the shared, ready-to-use namespace backed by `Qwen3-Embedding-4B` (1024
dimensions). Pass `namespace=` to write into a private namespace you've
provisioned on the dashboard.

## Quickstart (sync)

```python
from noetive import Client, PublishItem

with Client() as noetive:  # reads NOETIVE_KEY_SECRET from env
    noetive.publish(
        namespace="global",
        items=[PublishItem(text="Transformer models reshaped NLP benchmarks.")],
        metadata={"source": "arxiv"},
        ack="durable",
    )
    results = noetive.search(
        namespace="global",
        query='MATCH DISTANCE("machine learning") WITHIN 0.4 LIMIT 10',
    )
    for hit in results.results:
        print(hit.score, hit.content)
```

## Quickstart (async + SSE)

```python
import asyncio
from noetive import AsyncClient

async def consume_matches() -> None:
    async with AsyncClient() as noetive:
        async with noetive.subscribe(
            namespace="global",
            query='MATCH DISTANCE("open-source model releases") WITHIN 0.5',
        ) as stream:
            print("subscribed:", stream.subscription_id)
            async for match in stream:
                print(match.message_id, match.score)

asyncio.run(consume_matches())
```

### Targeting a private namespace

```python
noetive.publish(
    namespace="research-papers",
    items=[PublishItem(text="...")],
)
```

## Endpoints

| Method | Purpose | Auth |
|---|---|---|
| `client.health()` | Liveness probe | No |
| `client.lint(query=, cursor=)` | Validate a SemQL query; get diagnostics + completions | No |
| `client.publish(namespace=, model=, dimensions=, items=, metadata=, idempotency_key=, ack=)` | Publish a single message | Yes |
| `client.search(query=, namespace=, model=, dimensions=, limit=)` | SemQL semantic search | Yes |
| `client.subscribe(query=, namespace=, model=, dimensions=)` | SSE stream of match events | Yes |

### Publish items

A `PublishItem` carries **exactly one** of:

- `text=...` — the server computes the embedding (≤ 32 KB).
- `vector=[...]` — a pre-computed embedding (≤ 4096 dimensions).

### `ack` durability

| Value | Semantics |
|---|---|
| `"stored"` (default) | Return once the write survives a single server restart. |
| `"durable"` | Return once the write survives power loss. |

### Idempotency

Pass `idempotency_key="..."` to `publish()` so client retries collapse to a
single stored message within the server's retention window. Duplicates return
the same `message_id` and `seq`.

## Error handling

Every error inherits from `NoetiveError`:

```
NoetiveError
├── AuthenticationError       # 401 unauthorized
├── InvalidRequestError       # 400 invalid_request
├── BillingError              # 402 not_billable (no active subscription)
├── RequestTooLargeError      # 413 request_too_large
├── UnsupportedMediaTypeError # 415 unsupported_media_type
├── RateLimitError            # 429 rate_limited
│   ├── TooManyRequestsError  # 429 too_many_requests
│   └── BackpressureError     # 429 backpressure (retry_after_ms set)
├── ServiceUnavailableError   # 503 unavailable | *_unavailable | metering_unavailable
├── NamespaceDisabledError    # namespace_disabled (alias administratively disabled)
├── ModelNotProvisionedError  # model_not_provisioned ((model, dimensions) mismatch)
├── IndexBuildingError        # index_building (transient — retried automatically)
├── APIError                  # 500 internal_error
└── TransportError            # network / connect / read failures
```

Every exception carries `code`, `status_code`, `retry_after_ms`, and
`request_id` fields.

## Retries

The default `RetryPolicy` makes a single retry — `max_retries=1`, two total
attempts — on 429, 503, transport errors, and `index_building`. It honors
`retry_after_ms` from the response body and the RFC 9110 `Retry-After`
header (integer seconds).

**A single retry is the optimum** for this API. Transient conditions that
warrant retrying typically resolve within one server-supplied
`retry_after_ms` window, and tighter loops amplify load on a service
that's already returning a wait hint. Increase the budget only when your
tail-latency SLO can absorb the additional wait — `ack="durable"` writes
that a downstream job can't lose are the usual reason.

```python
from noetive import Client, RetryPolicy

# Default — recommended:
client = Client()                           # max_retries=1 → 2 attempts

# Override only when you have a specific reason:
client = Client(max_retries=5)              # 5 retries → 6 total attempts
client = Client(retry_policy=RetryPolicy(max_attempts=10, max_delay_s=30))
```

### Retry-safe publishes

The retry loop replays the request as-is, so a `publish()` call without an
`idempotency_key` can produce duplicate stored messages if the first attempt
actually reached the service before surfacing as 429/503/transport error.
**Always pass `idempotency_key=` when retries matter** — within the server's
retention window, the same key yields the same `message_id` and `seq`, so
retried writes collapse to one stored message. `search`, `lint`, `health`,
and `subscribe` are side-effect-free and safe to retry unconditionally.

## Configuration

```python
Client(
    api_key=None,                                 # or NOETIVE_KEY_SECRET env var
    base_url="https://semantik.noetive.io",
    timeout=30.0,                                  # float or httpx.Timeout
    max_retries=1,
    http2=True,
    http_client=None,                              # inject a custom httpx.Client
    retry_policy=None,                             # inject a RetryPolicy
)
```

## Examples

Runnable scripts in [`examples/`](examples/):

- [`health_and_lint.py`](examples/health_and_lint.py) — no-auth endpoints
- [`publish_and_search.py`](examples/publish_and_search.py) — publish then search
- [`publish_vector.py`](examples/publish_vector.py) — pre-computed embedding vector
- [`subscribe_live.py`](examples/subscribe_live.py) — sync SSE subscription
- [`async_subscribe.py`](examples/async_subscribe.py) — async subscribe + concurrent publish
- [`custom_retry.py`](examples/custom_retry.py) — custom timeout and retry policy

## Development

See [`CONTRIBUTING.md`](CONTRIBUTING.md) for the full developer guide.

```bash
python3 -m venv .venv
.venv/bin/pip install -e '.[dev]'
.venv/bin/python -m pytest tests/unit -q             # unit tests (no network)
.venv/bin/python -m ruff check src tests
.venv/bin/python -m mypy --strict src/noetive

# Integration tests hit the live https://semantik.noetive.io endpoint.
# Skipped when NOETIVE_KEY_SECRET is not set.
NOETIVE_KEY_SECRET=keyu_... .venv/bin/python -m pytest tests/integration -q
```

## Security

To report a vulnerability, see [`SECURITY.md`](SECURITY.md). Do not open a
public GitHub issue for security bugs — email **security@noetive.eu** instead.

## License

See [`LICENSE`](LICENSE).
