"""Async subscribe plus concurrent publishes, coordinated with asyncio.

Run:
    export NOETIVE_KEY_SECRET=keyu_...
    python examples/async_subscribe.py

Demonstrates pairing :class:`AsyncClient.subscribe` with a second task that
publishes matching messages. The consumer exits after receiving the
configured number of matches or when the overall deadline expires.

Backpressure
------------

Iterating the stream directly (as below) is the simplest pattern: a slow
consumer pauses the server via TCP backpressure, which keeps memory flat
but stops event delivery. When consumer work is slow and you want to keep
events flowing, drain the stream into an :class:`asyncio.Queue` from a
dedicated task and do the slow work in the consumer::

    queue: asyncio.Queue[MatchEvent] = asyncio.Queue(maxsize=64)

    async def drain() -> None:
        async for match in stream:
            await queue.put(match)  # blocks on full queue -> TCP backpressure

    async def work() -> None:
        while True:
            match = await queue.get()
            await slow_side_effect(match)

    await asyncio.gather(drain(), work())
"""

from __future__ import annotations

import asyncio
import os
import sys
import uuid

from noetive import AsyncClient, PublishItem

PUBLISH_COUNT = 3
OVERALL_DEADLINE_S = 30.0


async def publish_burst(client: AsyncClient, marker: str) -> list[str]:
    """Publish PUBLISH_COUNT messages that the subscription should match."""
    # Small head-start so the subscription is live before we publish.
    await asyncio.sleep(0.5)
    published: list[str] = []
    for i in range(PUBLISH_COUNT):
        response = await client.publish(
            items=[
                PublishItem(
                    text=f"async demo {marker} token #{i}: "
                    "transformer inference on modern GPUs"
                )
            ],
            ack="stored",
        )
        published.append(response.message_id)
        print(f"  published {response.message_id}")
    return published


async def main() -> None:
    if not os.environ.get("NOETIVE_KEY_SECRET"):
        sys.exit("Set NOETIVE_KEY_SECRET first.")

    marker = uuid.uuid4().hex[:8]
    async with AsyncClient() as noetive:
        async with noetive.subscribe(
            query=f'MATCH DISTANCE("async demo {marker} transformer") WITHIN 0.9',
        ) as stream:
            print(f"subscribed: {stream.subscription_id}")

            publisher = asyncio.create_task(publish_burst(noetive, marker))

            async def consume() -> list[str]:
                seen: list[str] = []
                async for match in stream:
                    print(f"  match {match.message_id} score={match.score:.3f}")
                    seen.append(match.message_id)
                    if len(seen) >= PUBLISH_COUNT:
                        return seen
                return seen

            try:
                seen = await asyncio.wait_for(consume(), timeout=OVERALL_DEADLINE_S)
            except asyncio.TimeoutError:
                seen = []
                print(f"timed out after {OVERALL_DEADLINE_S:.0f}s")

            await publisher
            print(f"consumed {len(seen)} match(es)")


if __name__ == "__main__":
    asyncio.run(main())
