"""Open a Server-Sent Events subscription and print match events as they arrive.

Run:
    export NOETIVE_KEY_SECRET=keyu_...
    python examples/subscribe_live.py

The stream stays open until you interrupt with Ctrl-C or the server closes
the connection. Matches published to the ``global`` namespace that satisfy
the SemQL query are pushed to the client in real time.
"""

from __future__ import annotations

import os
import sys

from noetive import Client


def main() -> None:
    if not os.environ.get("NOETIVE_KEY_SECRET"):
        sys.exit("Set NOETIVE_KEY_SECRET first.")

    with Client() as noetive, noetive.subscribe(
        query='MATCH DISTANCE("llm training") WITHIN 0.5',
    ) as stream:
        print(f"subscribed: {stream.subscription_id}")
        try:
            for match in stream:
                print(f"  match {match.message_id} score={match.score:.3f}")
        except KeyboardInterrupt:
            print("\nclosed by user")


if __name__ == "__main__":
    main()
