"""Override the default timeout and retry policy.

Run:
    export NOETIVE_KEY_SECRET=keyu_...
    python examples/custom_retry.py

The defaults (3 attempts, 10 s computed-backoff cap, 30 s read timeout) are
reasonable for most workloads. When you need something different — e.g. a
long-running batch job that should retry aggressively, or a latency-sensitive
UI that should fail fast — swap the transport or the retry policy.
"""

from __future__ import annotations

import os
import sys

import httpx

from noetive import Client, RetryPolicy


def main() -> None:
    if not os.environ.get("NOETIVE_KEY_SECRET"):
        sys.exit("Set NOETIVE_KEY_SECRET first.")

    aggressive_retry = RetryPolicy(
        max_attempts=8,
        base_delay_s=0.2,
        max_delay_s=30.0,
    )

    tight_timeouts = httpx.Timeout(
        connect=2.0,
        read=5.0,
        write=5.0,
        pool=5.0,
    )

    with Client(
        timeout=tight_timeouts,
        retry_policy=aggressive_retry,
    ) as noetive:
        noetive.health()
        print("health ok with custom timeout + retry policy")


if __name__ == "__main__":
    main()
