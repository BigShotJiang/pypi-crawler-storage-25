"""Publish a pre-computed embedding vector.

Run:
    export NOETIVE_KEY_SECRET=keyu_...
    python examples/publish_vector.py

Use this mode when embeddings are computed upstream (e.g. by an inference
service you already operate) — it skips the server-side embedding step.
The vector length must match the namespace's configured model dimensions
(1024 for the ``global`` namespace's ``Qwen3-Embedding-4B``).
"""

from __future__ import annotations

import os
import random
import sys

from noetive import DEFAULT_DIMENSIONS, Client, PublishItem


def random_unit_vector(dims: int) -> list[float]:
    """A toy unit-normalised vector. Replace with a real embedding model."""
    rng = random.Random(42)
    raw = [rng.gauss(0.0, 1.0) for _ in range(dims)]
    norm = sum(x * x for x in raw) ** 0.5 or 1.0
    return [x / norm for x in raw]


def main() -> None:
    if not os.environ.get("NOETIVE_KEY_SECRET"):
        sys.exit("Set NOETIVE_KEY_SECRET first.")

    vector = random_unit_vector(DEFAULT_DIMENSIONS)

    with Client() as noetive:
        response = noetive.publish(
            items=[PublishItem(vector=vector)],
            metadata={"source": "publish_vector.py"},
            ack="stored",
        )
        print(
            "published pre-computed vector: "
            f"message_id={response.message_id} epoch={response.epoch} seq={response.seq}"
        )


if __name__ == "__main__":
    main()
