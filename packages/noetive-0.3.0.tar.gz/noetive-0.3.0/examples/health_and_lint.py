"""No-auth example: probe the service liveness and lint a SemQL query.

Run:
    python examples/health_and_lint.py

The ``health`` and ``lint`` endpoints do not require an API key, so this
example works out of the box without any credentials.
"""

from __future__ import annotations

from noetive import Client


def main() -> None:
    with Client() as noetive:
        noetive.health()
        print("health: ok")

        result = noetive.lint(
            query='MATCH DISTANCE("machine learning") WITHIN 0.4 LIMIT 10'
        )
        print(f"lint: valid={result.valid} normalized={result.normalized!r}")
        for diag in result.diagnostics:
            print(f"  [{diag.severity}] L{diag.line}:{diag.col} {diag.message}")
        for completion in result.completions[:5]:
            print(f"  + {completion.label} ({completion.kind}): {completion.detail}")


if __name__ == "__main__":
    main()
