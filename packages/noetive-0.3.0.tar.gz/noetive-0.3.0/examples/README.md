# Examples

Runnable scripts exercising the `noetive` SDK. Each file is self-contained:

```bash
export NOETIVE_KEY_SECRET=keyu_...
python examples/<script>.py
```

All examples publish to the `global` namespace using the
`Qwen3-Embedding-4B` model (1024 dimensions).

| Script | What it shows |
|---|---|
| [`health_and_lint.py`](health_and_lint.py) | No-auth endpoints: liveness probe and SemQL lint |
| [`publish_and_search.py`](publish_and_search.py) | Publish a text message, then search for it |
| [`publish_vector.py`](publish_vector.py) | Publish a pre-computed embedding vector |
| [`subscribe_live.py`](subscribe_live.py) | Consume a Server-Sent Events subscription stream |
| [`async_subscribe.py`](async_subscribe.py) | Async subscribe + concurrent publish from a single task group |
| [`custom_retry.py`](custom_retry.py) | Override the default timeout + retry policy |

## Shared helpers

Examples that need an API key read `NOETIVE_KEY_SECRET` from the environment and
exit with a clear message if it's missing. The no-auth examples
(`health_and_lint.py`) work without any credentials.

## A note on SemQL

The example queries follow the grammar documented in the public API spec
(`MATCH DISTANCE("...") WITHIN n LIMIT m`). If the server rejects a query with
a syntax error, run `Client.lint(query=...)` first — diagnostics and
completions reveal what the currently-deployed server expects.
