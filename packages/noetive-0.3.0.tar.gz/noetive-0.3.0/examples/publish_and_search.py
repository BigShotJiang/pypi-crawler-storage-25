"""Publish a text message then search for it semantically.

Run:
    export NOETIVE_KEY_SECRET=keyu_...
    python examples/publish_and_search.py

Defaults target the ``global`` namespace (Qwen3-Embedding-4B, 1024d), so
``namespace``, ``model`` and ``dimensions`` can be omitted. The server
computes the embedding from the ``text`` field.

We use ``ack="durable"`` so the message is persisted before :meth:`Client.search`
runs — minimizing the chance of a read-your-writes race. We still wait
briefly and retry in case the search index has not yet caught up.
"""

from __future__ import annotations

import os
import sys
import time
import uuid

from noetive import Client, PublishItem


def main() -> None:
    if not os.environ.get("NOETIVE_KEY_SECRET"):
        sys.exit("Set NOETIVE_KEY_SECRET first.")

    marker = f"sdk-demo-{uuid.uuid4().hex[:8]}"
    text = f"Python SDK demo message: {marker} — quantum computing on GPUs."

    with Client() as noetive:
        published = noetive.publish(
            items=[PublishItem(text=text)],
            metadata={"source": "publish_and_search.py", "marker": marker},
            idempotency_key=marker,
            ack="durable",
        )
        print(f"published message_id={published.message_id} seq={published.seq}")

        deadline = time.monotonic() + 10.0
        while time.monotonic() < deadline:
            results = noetive.search(
                query=f'MATCH DISTANCE("{marker} quantum") WITHIN 0.8 LIMIT 20'
            )
            hit = next(
                (r for r in results.results if r.message_id == published.message_id),
                None,
            )
            if hit is not None:
                print(f"search hit: score={hit.score:.3f} content={hit.content!r}")
                return
            time.sleep(0.5)

        sys.exit(f"search did not surface {published.message_id} within 10s")


if __name__ == "__main__":
    main()
