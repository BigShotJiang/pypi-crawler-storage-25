# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.12.0] — 2026-04-23

Tracks engine 1.16.0 (governance waveplan). New `ComplianceOutput` + `RetentionStatusOutput` Pydantic models, extended `RockyOutput` union, regenerated bindings for classification / masking / role-graph / retention config surfaces.

### Added

- **`ComplianceOutput` and its subtypes** (`ComplianceSummary`, `ColumnClassificationStatus`, `EnvMaskingStatus`, `ComplianceException`) re-exported from the generated barrel (engine [#242](https://github.com/rocky-data/rocky/pull/242)). `parse_rocky_output()` dispatches `"compliance"` → `ComplianceOutput`; the output joins the `RockyOutput` union.
- **`RetentionStatusOutput` + `ModelRetentionStatus`** re-exported from the generated barrel (engine [#244](https://github.com/rocky-data/rocky/pull/244)). `parse_rocky_output()` dispatches `"retention-status"` → `RetentionStatusOutput`; the output joins the `RockyOutput` union. `ModelRetentionStatus.warehouse_days` is `Optional[int]` and always `None` in v1 — the engine's `--drift` warehouse probe is a v2 follow-up; the schema is stable.

### Changed

- **Generated types refreshed** for engine 1.16.0:
  - `RunRecord` (history output) gains the 8-field governance audit trail: `triggering_identity` / `session_source` (`Cli` / `Dagster` / `Lsp` / `HttpApi`) / `git_commit` / `git_branch` / `idempotency_key` / `target_catalog` / `hostname` / `rocky_version` (engine [#240](https://github.com/rocky-data/rocky/pull/240)).
  - `rocky-project.schema.json` regenerated — `ModelConfig` now surfaces `classification: dict[str, str]` + `retention: RetentionPolicy | None`; `RockyConfig` surfaces `mask: dict[str, MaskEntry]`, `classifications: ClassificationsConfig`, `roles: dict[str, RoleConfig]`.
  - `MaskStrategy` enum surfaced in the project schema (`hash` / `redact` / `partial` / `none`).

## [1.11.0] — 2026-04-23

Tracks engine 1.15.0. Adds the `idempotency_key` kwarg to every `RockyResource` run method (wraps FR-004). One PR since v1.10.0.

### Added

- **`idempotency_key: str | None = None` kwarg** on `RockyResource.run()`, `run_streaming()`, and `run_pipes()` (engine [#235](https://github.com/rocky-data/rocky/pull/235), FR-004). Forwards to the CLI as `--idempotency-key <KEY>`. Defence-in-depth below Dagster's `run_key` — catches pod retries, Kafka re-delivery, webhook duplicates, and any duplicate sensor-tick that slipped past `run_key`.

  When the key dedups, the returned `RunResult` surfaces `status = "SkippedIdempotent"` (or `"SkippedInFlight"`) and `skipped_by_run_id` carrying the prior or in-flight `run_id`. Downstream Dagster handlers can key off `result.status.startswith("Skipped")` to emit `AssetObservation` events instead of `MaterializeResult`s for the skip cases.

  ⚠️ Keys are stored **verbatim** in the state store — do not put secrets in idempotency keys.

### Changed

- **Generated types refreshed** for engine 1.15.0: new `status: RunStatus` / `skipped_by_run_id: str | None` / `idempotency_key: str | None` fields on `RunResult`; `RunStatus` enum now includes `SkippedIdempotent` + `SkippedInFlight` variants alongside `Success` / `PartialFailure` / `Failure`. New `IdempotencyConfig` / `DedupPolicy` types surfacing the `[state.idempotency]` TOML block in the project schema.
- **Regenerated fixtures** for all `run.json` / `run_*.json` test fixtures — every captured output now carries `"status": "Success"` (13 fixtures updated).

## [1.10.0] — 2026-04-23

Tracks engine 1.14.0. Ships four GOLD-origin feature requests (Pipes execution mode, strict doctor on startup, `state_health()` accessor, `cost()` wiring) plus a sub-second `state_health()` follow-up. Four PRs since v1.9.0.

### Added

- **`RockyResource.cost()` method** (#218) — wraps `rocky cost <run_id|latest>` and returns a typed `CostOutput`. Closes the Dagster wiring follow-up deferred by engine PR #202. Dispatch-table entry, `regen_fixtures.sh` capture step, and `test_generated_fixtures.py` parse-guard shipped together. No `--model` filter yet (CLI flag exists; follow-up).
- **`RockyComponent` Pipes execution mode** (FR-001, #224) — opt-in `execution_mode="pipes"` wraps `run_pipes` as the execution backend. Custom `RockyPipesMessageReader` subclass catches events at source with `asset_key_fn` + `include_keys` support. 30 new tests. **Spec deviation worth flagging:** `asset_key_fn` signature is `Callable[[list[str]], dg.AssetKey | None]` (not the FR's `Callable[[SourceInfo | ModelInfo], AssetKey]`) because Pipes carries slash-joined paths on the wire, not model objects.
- **Strict `rocky doctor` on `RockyResource` startup** (FR-006, #224) — `setup_for_execution` runs `rocky doctor` when `strict_doctor: bool = False` / `strict_doctor_checks: list[str]` opts in. **Spec deviation:** strictness surface flipped from `fail_on_doctor_critical: list[str] | Literal["none", "all"]` to two fields because Dagster's Pydantic config serializer rejects the `Union` with `DagsterInvalidPythonicConfigDefinitionError`; same semantic space.
- **`RockyResource.state_health()` accessor** (FR-003, #227) — returns a typed `StateHealthResult` Pydantic model. Parses `rocky.toml` backend via `tomllib`, fetches `rocky history` for last-run info, optionally runs a doctor probe; sensor-tick safe (doctor/history failures degrade to typed `None` / error fields rather than propagating `dg.Failure`). 24 new tests.

### Changed

- **`RockyResource.doctor(check=...)` filter** (#229) — optional `check: str | None = None` kwarg forwards to `rocky doctor --check <id>`. `state_health()` now calls `doctor(check="state_rw")` instead of the full doctor suite, cutting probe cost from full-doctor (~1 s) to sub-100 ms. Closes the known follow-up from #227.
- **`SourceInfo.metadata` now carries adapter-namespaced keys** forwarded by the translator (engine #225). Fivetran connectors surface `fivetran.service` / `fivetran.connector_id` / `fivetran.schema_prefix` / `fivetran.custom_tables` / `fivetran.custom_reports` as Dagster asset metadata.
- **Generated types refreshed** for engine 1.14.0: new `ClearSchemaCacheOutput`, new `schemas_cached` field on `DiscoverOutput`, new `metadata` field on `SourceOutput`, new `bytes_scanned` / `bytes_written` on `MaterializationOutput`.

## [1.9.0] — 2026-04-22

Tracks engine 1.13.0 (state-backend reliability hardening + `state_rw` doctor check).

### Changed

- **`types_generated/rocky_project_schema.py` picks up the new `StateConfig.retry` + `StateConfig.on_upload_failure` fields** and the new `StateUploadFailureMode` Pydantic enum from engine 1.13.0. Fully additive — existing code consuming `StateConfig` continues to validate; new fields default to the engine's defaults. IDE hover / Pyright on `StateConfig` now shows the new fields.
- **`tests/fixtures_generated/doctor.json` + `doctor_ci/doctor.json` regenerated** for the new `state_rw` doctor check row in engine 1.13.0. Test-only; no wheel surface change.

## [1.8.0] — 2026-04-21

Tracks engine 1.12.0 (Arc 1 wave 2 + cleanup cascade).

### Fixed

- **`RockyResource.run_streaming` two-readers race on `proc.stderr` (#208)** — the previous implementation spawned a daemon stderr forwarder thread that read `proc.stderr` via `TextIOWrapper` iteration **while** the main thread called `proc.communicate(timeout=…)`, which reads the same pipe FD via raw `os.read`. This violated CPython's documented `subprocess` contract ("the process must have been started with the stream set to `PIPE` and the stream must not be read from otherwise") and under production stderr traffic the `TimeoutExpired` path intermittently failed to fire. Observed twice in production (2026-04-18 and 2026-04-19) where the subprocess ran for hours against a 30-minute configured timeout, triggering a 58-run Dagster queue backlog on the second incident. The race is now eliminated by making the stderr forwarder and a new stdout accumulator the **sole readers** of their pipes, and enforcing the wall-clock timeout externally via a watchdog thread that kills the process group (see Added). Audit of `run_pipes` against upstream `dagster.PipesSubprocessClient` confirmed no analogous bug (upstream inherits stdio by default — no PIPE FDs, no reader threads — and calls `process.wait()` without a timeout); pipes does have a separate gap (no wall-clock timeout at all, only SIGINT on Dagster cancel) that is out of scope for this release.

### Added

- **Watchdog-based subprocess timeout enforcement in `run_streaming` (#208)** — `_run_rocky_streaming` now uses a `threading.Event`-driven watchdog daemon thread that calls `os.killpg(os.getpgid(proc.pid), signal.SIGKILL)` (POSIX) or `proc.kill()` (Windows) when `timeout_seconds` elapses. The main thread calls `proc.wait()` with no timeout; enforcement is pipe-FD-independent so traffic patterns on stderr no longer affect timeout semantics. `Popen` is launched with `start_new_session=True` on POSIX so rocky gets its own process group and any child processes (adapter subprocesses, hook scripts) are reaped alongside the parent. Watchdog-fire is detected via `proc.returncode == -signal.SIGKILL` and surfaces a `dg.Failure` with `description` matching `"timed out after Ns (watchdog-killed)"` and `stderr_tail` / `duration_ms` / `pid` metadata — distinguishable from a native non-zero exit.
- **Separate single-reader threads for stdout and stderr in `run_streaming` (#208)** — the dedicated stdout accumulator (`_accumulate_stdout`) and the existing stderr forwarder (`_forward_stderr_to_context`) each own their pipe end-to-end, restoring conformance with CPython's subprocess contract. Live stderr streaming to `context.log.info` is preserved (the feature that motivated `run_streaming` in the first place).
- **Structured start/end subprocess logging in `run_streaming` (#208)** — one `INFO` line on `Popen` success (`pid`, `timeout_s`, `cmd`) and one on process exit with `pid`, `returncode`, `duration_ms`, `outcome` (`"success"` / `"failure"` / `"partial-success"` / `"timeout-killed"`). Emitted via the module logger `dagster_rocky.resource._log`. Closes the observability gap that made post-mortems on the 2026-04-18 / 2026-04-19 hangs harder than they needed to be.
- **`CostOutput` + `PerModelCostHistorical` Pydantic bindings** (#202) — generated from the new `rocky cost <run_id|latest>` engine schema. Reachable today via `dagster_rocky.types_generated.cost_schema.CostOutput`; `RockyResource.cost(...)` + `parse_rocky_output` dispatch + fixture are a small follow-up (explicitly deferred in #202).
- **`OptimizeRecommendation.compute_cost_per_run` / `storage_cost_per_month` / `downstream_references`** (#203) — regenerated Pydantic bindings now expose the three fields `checks.py:54-59` reads on each recommendation. Previously hand-written drift caused `AttributeError` once `rocky optimize` started producing non-empty recommendations.
- **`MaterializationOutput.started_at: datetime`** (#206) — real per-model wall-clock timestamp captured at execution time, propagated through the regenerated `run_schema.py`. Makes parallel-run ordering honest on the persisted `RunRecord` consumers read via `RockyResource.history()` / `.replay()` / `.cost()`.

### Changed

- **`HistoryResult` soft-swapped to `HistoryOutput`** (#203). Completes the Phase 2 generated-types migration that had been silent because `rocky history` always returned empty. `HistoryResult` / `ModelHistoryResult` are now aliases of the generated CLI-shape classes; hand-written `RunRecord`-shape versions had `finished_at`, `config_hash`, and `models_executed` as a list — none of which the CLI actually emits. `tests/scenarios.py::HISTORY` + the parse assertion were retrofitted to the CLI shape. No external API break: same class names, same import paths.

### Internal

- **`scripts/_normalize_fixture.py`** (#203) gained `WALL_CLOCK_ID_FIELDS = {"run_id"}` and `DERIVED_FROM_WALL_CLOCK_FIELDS = {"compute_cost_per_run", "estimated_monthly_savings"}` so the test-fixture corpus stays byte-stable across regens now that `run_id` and wall-clock-derived cost numbers appear in non-empty arrays.

## [1.7.0] — 2026-04-20

Tracks engine 1.11.0. Regenerated Pydantic bindings for the trust-system arcs (Arcs 1–7 first waves + Arc 6 wave 2 + Arc 7 wave 2 wave-1).

### Added — Trust-system Arc 1 bindings

Pydantic models for the four new engine schemas:

- `BranchOutput` / `BranchEntry` (from `rocky branch create|show`)
- `BranchListOutput` (from `rocky branch list`)
- `BranchDeleteOutput` (from `rocky branch delete`)
- `ReplayOutput` / `ReplayModelOutput` (from `rocky replay <run_id|latest>`)

`ColumnLineageOutput` picks up a new `direction` field (`"upstream"` / `"downstream"`) — additive, no parsing changes for existing consumers.

### Added — Trust-system Arc 2 bindings

- `RunOutput.cost_summary` and per-materialization `cost_usd` flow through the regenerated `RunOutput` model.
- `BudgetConfig` (from `rocky.toml [budget]`) and the `budget_breach` PipelineEvent shape are now typed.

### Added — Trust-system Arc 3 bindings

- `circuit_breaker_tripped` / `_recovered` PipelineEvent variants in the regenerated event union.

### Added — Trust-system Arc 4 bindings

- `TraceOutput` / `TraceLane` / `TraceMaterialization` typed shape for `rocky trace <run_id|latest>` JSON consumers.

### Added — Trust-system Arc 5 bindings

- `AiGenerateOutput.models` field for scoped AI prompt context.

### Added — Trust-system Arc 6 wave 2 bindings

- `PortabilityConfig` (from `[portability]` block) added to the `RockyProject` schema. Lowercase `Dialect` enum (`databricks` / `snowflake` / `bigquery` / `duckdb`) round-trips through the `target_dialect` field.

### Added — Trust-system Arc 7 wave 2 wave-1 bindings

- No new schemas; `--with-seed` is a CLI-only flag that doesn't change any output struct shape. Bindings unchanged for this PR.

### Note

Arc 6 wave 1 (P001) and Arc 7 wave 1 (P002) emit diagnostics that flow through the existing `Diagnostic` shape — no new Pydantic models needed. Codes `P001` (error) and `P002` (warning) appear in the `code` field as plain strings.

## [1.6.0] — 2026-04-20

### Added — Regenerated Pydantic bindings for engine 1.10.0

Engine 1.10.0 closes the perf-resilience roadmap's active arc. The regenerated bindings in `types_generated/` surface the additive schema changes from that push:

- **`PipelineEvent` retry fields** — every adapter retry loop now emits events with `attempt`, `max_attempts`, and `error_class` fields so Dagster subscribers can distinguish "retry 3/5" from "final failure" without string-matching error messages.
- **Hook context schemas** — 15 lifecycle events (`pipeline_start`, `discover_complete`, `compile_complete`, `before_model_run` / `after_model_run` / `model_error`, `before_materialize` / `after_materialize` / `materialize_error`, `before_checks` / `check_result` / `after_checks`, `drift_detected`, `anomaly_detected`, `state_synced`, `pipeline_complete`, `pipeline_error`) wired into `rocky run`. Schemas are exported for subscribers that want to type hook-context JSON.
- **Top-level `[retry]` config** — cross-adapter shared `RetryBudget`. Pydantic parser picks up the new config key; unset = per-adapter budgets (prior behaviour).
- **Additive `CompileOutput` timing fields** from §P3.1's incremental path.

No source code changes in `dagster_rocky` itself — `RockyResource` + `RockyComponent` + the Pipes path all continue to work unchanged against engine 1.10.0. Regenerated models in `types_generated/` pick up the new fields automatically.

Fixture refresh via `just regen-fixtures` against the 1.10.0 binary — committed as part of the engine-v1.10.0 release PR (not re-committed here).

### Upgrading

Pin `rocky >= 1.10.0` in orchestrator environments when upgrading to `dagster-rocky 1.6.0`. Old Rocky binaries (< 1.10.0) that don't emit the new fields may surface Pydantic validation errors on `PipelineEvent` — the retry-event fields are non-optional in the regenerated schema because the engine always serialises them when the adapter is on a retry path.

## [1.5.0] — 2026-04-17

### Added — `RunOutput.interrupted` and regenerated Pydantic bindings for engine 1.8.0

Engine 1.8.0 shipped graceful SIGINT / SIGTERM handling for `rocky run` and a silent-wrong-result fix for BigQuery async polling. On the dagster side, the regenerated bindings surface a new required field on the run payload:

- **`RunOutput.interrupted: bool`** — `true` when the run was cancelled by a shutdown signal. Paired with the engine-side `TableStatus.INTERRUPTED` enum value on the corresponding `TableProgress` rows, so orchestrators can distinguish "user interrupted / pod evicted" from "run failed" and from "run succeeded".

`interrupted` is always serialised by the engine (no skip-if-false), so existing consumers pick it up without code changes — but old Rocky binaries that don't emit the field will now produce a Pydantic validation error. Pin \`rocky >= 1.8.0\` in orchestrator environments when upgrading.

No source code changes in `dagster_rocky` itself — \`RockyResource\` + \`RockyComponent\` + the Pipes path all continue to work unchanged against engine 1.8.0. The regenerated model in \`types_generated/run_schema.py\` picks up the field automatically.

Fixture refresh via \`just regen-fixtures\` against the 1.8.0 binary.

### Upgrading

\`dagster-rocky\` ships independently from the engine. To consume engine 1.8.0 features, either install \`engine-v1.8.0\` on the orchestrator's \`$PATH\` or re-vendor the binary via \`scripts/vendor_rocky.sh\` before updating your pipeline code. Pair updates are recommended: the engine's interrupt-handling and BigQuery polling fixes are silently beneficial on the runtime side even if you don't read \`RunOutput.interrupted\` yet.

## [1.4.0] — 2026-04-17

### Added — Pydantic models for the `rocky_project` schema

Engine 1.7.0 closed the `rocky-project.schema.json` autogen arc — the VS Code-facing project config schema is now fully generated from Rust types. The regenerated bindings ship a new `dagster_rocky.types_generated.rocky_project_schema` module with typed models covering every `RockyConfig` field: `RockyConfig`, `StateConfig`, `CostSection`, `HooksConfig`, `SchemaEvolutionConfig`, `AdapterConfig`, `RetryConfig`, plus the full pipeline surface (`ReplicationPipelineConfig`, `TransformationPipelineConfig`, `QualityPipelineConfig`, `SnapshotPipelineConfig`, `LoadPipelineConfig`) and every assertion / quarantine / governance / load subtype.

No source code changes in `dagster_rocky` itself — the models are published for parity with the CLI-output bindings and as the typed foundation for future orchestrator-side config introspection. Existing consumers are unaffected; `RockyResource` continues to invoke `rocky` as a subprocess.

Fixture refresh via `just regen-fixtures` under the 1.7.0 binary.

### Upgrading

`dagster-rocky` ships independently from the engine. To consume engine 1.7.0 features, either install `engine-v1.7.0` on the orchestrator's `$PATH` or re-vendor the binary via `scripts/vendor_rocky.sh` before updating your pipeline code.

## [1.3.0] — 2026-04-17

### Added — Regenerated Pydantic bindings for engine 1.5.0 + 1.6.0

Engine-side DQX parity work (Phases 1–4) and the `AdapterConfig` JsonSchema derive landed a large crop of new fields in the typed output surface. The regenerated bindings (via `just codegen`) now include:

- **`RunOutput.quarantine: list[QuarantineOutput]`** — row-quarantine outcomes per table (mode, valid/quarantine table names, row counts, ok/error state).
- **`CheckResult.severity: Literal["error", "warning"]`** — per-check severity on every quality check.
- **`CheckDetails.Assertion { kind, column, failing_rows }`** — new variant covering row-level assertions (`not_null`, `unique`, `accepted_values`, `relationships`, `expression`, `row_count_range`, `in_range`, `regex_match`, `aggregate`, `composite`, `not_in_future`, `older_than_n_days`).
- **`AdapterConfig`, `AdapterKind`, `RetryConfig`** — new `adapter_config_schema.py` module with typed models for the adapter-config section.
- Refreshed test fixtures in `tests/fixtures_generated/` with the 1.6.0 version stamp.

No source code changes in `dagster_rocky` itself — pure binding regeneration plus the version bump. Consumers upgrading to engine 1.5.0+ get typed access to every new field; older configs continue to parse because the new fields are all optional / default-empty.

### Upgrading the vendored binary

`dagster-rocky` ships independently from the engine. To consume engine 1.6.0 features, either install `engine-v1.6.0` on the orchestrator's `$PATH` or re-vendor the binary via `scripts/vendor_rocky.sh` before updating your pipeline code.

## [1.2.6] — 2026-04-16

### Added — `DagRunOutput` Pydantic model

Regenerated bindings (via `just codegen`) include the new
`dagster_rocky.types_generated.dag_run_schema.DagRunOutput` and
`DagRunNodeOutput` Pydantic models, picked up from engine 1.2.0's
`rocky run --dag` output. Dagster consumers can now `model_validate_json`
on the output of `rocky run --dag --output json` to get typed per-node
execution results (id, kind, label, layer, status, duration_ms, error).

No source code changes in `dagster_rocky` itself — pure binding
regeneration to keep the typed surface in sync with the engine.

## [Unreleased pre-1.2.6]

### v0.4 — First-class Dagster integration

dagster-rocky 0.4 closes most of the meaningful gaps between dagster-rocky and a "first-class
Dagster integration" — freshness policies, sensors, schedules, drift/anomaly events, partition
support, project scaffold, dg CLI integration, automation conditions, and health probes.

#### Added — Core asset wiring

- **Source `[checks.freshness]` → `FreshnessPolicy`** (T1.1). `RockyComponent` and
  `load_rocky_assets()` automatically attach `dg.FreshnessPolicy.time_window(fail_window=...)` to
  every source-replication asset when `[checks.freshness]` is configured in `rocky.toml`. Uses the
  modern Dagster 1.12+ API, not the deprecated `FreshnessPolicy(maximum_lag_minutes=...)` ctor.
  See `docs/dagster/freshness.md`.
- **Per-model freshness from model TOML frontmatter** (T1.2). Models with `[freshness] max_lag_seconds`
  declared in their TOML get a per-model `FreshnessPolicy` that overrides the pipeline-level default
  for matching tables. Reads from the new `compile.models_detail` field on the engine side.

#### Added — Helpers (standalone, importable from package root)

- **`rocky_source_sensor()`** (T1.3) — Dagster sensor that polls `rocky discover`, tracks
  `last_sync_at` per source in a JSON cursor, and emits `RunRequest` events when sources advance.
  Two granularities: `per_source` (one RunRequest per source) and `per_group` (one per Dagster
  group). Uses datetime parsing for cursor comparison so mixed timezone offsets work correctly.
- **`build_rocky_schedule()`** (T1.5) — thin factory wrapping `dg.ScheduleDefinition` with sensible
  defaults and a `rocky/schedule` namespace tag.
- **`drift_observations(run_result, key_resolver=...)`** (T4.1) — yields one `dg.AssetObservation`
  per drift action. Drift is a structural change, not pass/fail, so observation is the right
  primitive.
- **`anomaly_check_results(run_result, key_resolver=...)`** (T4.2) — yields one `dg.AssetCheckResult`
  per row-count anomaly with severity `WARN`. Check name is the new module constant
  `ANOMALY_CHECK_NAME` (`"row_count_anomaly"`).
- **`optimize_metadata_for_keys(optimize_result, model_to_key=...)`** (T4.4) — builds a
  `{AssetKey: metadata}` dict from a `rocky optimize` result for merging into `AssetSpec.metadata`
  at load time.
- **Contract checks: `discover_contract_rules` + `contract_check_specs_for_model` +
  `contract_check_results_from_diagnostics`** (T4.3) — purely Python translation of Rocky's
  `.contract.toml` validation (compile-time codes E010, E011, E012, E013, W010) into native
  Dagster `AssetCheckSpec` and `AssetCheckResult` events. Three check kinds:
  `contract_required_columns`, `contract_protected_columns`, `contract_column_constraints`.
  Pre-declared per matching model when `RockyComponent` is configured with a `contracts_dir`.
- **Derived-model surfacing: `build_model_specs` + `split_model_specs_by_partition_shape`
  + `ModelGroup`** — translate `compile.models_detail` into per-model `AssetSpec`
  instances and bucket them by partitioning shape so each multi-asset has a single
  consistent `PartitionsDefinition`. Pure-function builders for users with
  hand-rolled multi-assets; `RockyComponent` wires them automatically when the new
  `surface_derived_models=True` config flag is enabled. See
  `docs/dagster/derived-models.md`.
- **Branch deployment detection: `BranchDeploymentInfo` + `is_branch_deployment` +
  `branch_deployment_info` + `branch_deploy_shadow_suffix`** (T5.3, descoped) — read the
  standard Dagster+ env vars (`DAGSTER_CLOUD_IS_BRANCH_DEPLOYMENT`, `_DEPLOYMENT_NAME`,
  `_PULL_REQUEST_ID`, `_GIT_SHA`) and derive a stable shadow suffix
  (`_dagster_pr_<n>` / `_dagster_<name>`) for `rocky run --shadow`. The original T5.3
  plan also called for GitHub PR comment posting; that was dropped per the v0.4 review.
  See `docs/dagster/branch-deployments.md`.
- **Partition surface in types/resource (Phase 3 cascade)** — `MaterializationInfo` and
  `RunResult` mirror the engine-side `PartitionInfo` and `PartitionSummary` types.
  `RockyResource.run()` accepts seven new keyword-only partition flags:
  `partition`, `partition_from`, `partition_to`, `latest`, `missing`, `lookback`,
  `parallel`. The flags are defensive — `partition_from` without `partition_to`
  emits neither `--from` nor `--to` rather than an engine error.
- **`RockyResource.run_streaming(context, ...)`** (T2, Pipes-style) — Pipes-style
  alternative to `run()` that spawns rocky via `subprocess.Popen`, forwards rocky's
  stderr (where the engine's `tracing` layer writes `info!()` / `warn!()` macros) to
  `context.log.info` line-by-line as the run progresses, and parses the final stdout
  JSON into a `RunResult` after the subprocess exits. Accepts the same kwargs as
  `run()` (governance override + all 7 partition flags). On failure, captures the
  last 20 stderr lines into the `dg.Failure` metadata as `stderr_tail`. See
  `docs/dagster/pipes.md`.
- **`RockyResource.run_pipes(context, ...)`** (T2, full Dagster Pipes) — full Dagster
  Pipes integration via `dg.PipesSubprocessClient`. The rocky engine (v0.4+) detects
  the `DAGSTER_PIPES_CONTEXT` and `DAGSTER_PIPES_MESSAGES` env vars that the client
  sets, and emits structured Pipes messages on the messages channel:
  `report_asset_materialization` per copied table (with strategy / duration_ms /
  rows_copied / target_table_full_name / sql_hash / partition_key metadata),
  `report_asset_check` per check, and `log` events for run start, completion, and
  drift actions. Returns a `PipesClientCompletedInvocation`; users chain
  `.get_results()` to extract the materialization events Dagster constructed from
  the Pipes messages. This is the canonical Dagster Pipes integration pattern.
- **Richer `MaterializationMetadata` fields** (T1.4) — `target_table_full_name` (always
  set when targeting a known table), `sql_hash` (16-char hex fingerprint of the SQL
  the engine sent to the warehouse, populated for `time_interval` materializations).
  `column_count` and `compile_time_ms` are scaffolded but require derived-model
  output threading; deferred to a follow-up.
- **`build_column_lineage(lineage, model_to_key=...)`** (T4.6) — translates a Rocky
  `ModelLineageResult` into a Dagster `dg.TableColumnLineage` ready to attach to
  `MaterializeResult.metadata`.
- **`partitions_def_for_time_interval()`** + **`partitions_def_for_model_detail()`** (T3) — convert
  Rocky `time_interval` strategies into Dagster's `Hourly|Daily|Monthly|TimeWindow` partitions
  definitions. Hour/month grain key formats convert via `rocky_to_dagster_partition_key()` and
  `dagster_to_rocky_partition_key()` (round-trip idempotent for all grains).
- **`partition_key_arg()`** + **`partition_range_args()`** — CLI argument builders for
  `rocky run --partition` / `--from` / `--to`.
- **`rocky_eager_automation()`** + **`rocky_cron_automation(cron, tz)`** (T5.2) — modern
  `dg.AutomationCondition.eager()` and `on_cron()` for Rocky-managed assets. Replaces the
  deprecated `AutoMaterializePolicy.eager()` API.
- **`rocky_healthcheck(rocky)`** (T5.5) — wrapper around `RockyResource.doctor()` that returns a
  `HealthcheckResult(healthy, doctor_result, error)` dataclass. Suitable for Dagster+ code-location
  health probes, custom asset checks, and ops.
- **`init_rocky_project(target_dir)`** (T5.1) — bootstraps a complete Rocky + Dagster project
  skeleton (defs.yaml + DuckDB-backed rocky.toml + models/ + README.md). Refuses to overwrite
  existing files unless `overwrite=True`.

#### Added — Wired into `RockyComponent` automatically

- **Drift events as `dg.AssetObservation`** — replaces `context.log.warning` for drift detection.
  Asset timeline shows discrete events with `rocky/drift_action`, `rocky/drift_reason`,
  `rocky/drift_table`, and drift count metadata.
- **Anomalies as `dg.AssetCheckResult` with severity `WARN`** — replaces `context.log.warning` for
  row-count anomalies. The `row_count_anomaly` check is pre-declared via
  `DEFAULT_CHECK_NAMES` so the spec is visible in the UI before any run; placeholder check results
  cover the no-anomaly case.
- **Contract checks pre-declared from `contracts_dir`** (T4.3). When `RockyComponent` is
  configured with `contracts_dir`, the component walks `*.contract.toml` files at load time and
  pre-declares one `AssetCheckSpec` per declared rule kind on every asset whose table name
  matches a contract file. At materialization time, contract diagnostics from the cached compile
  state are translated into `AssetCheckResult` events (E010 → required columns; E013 → protected
  columns; E011/E012 → column constraints; W010 → column constraints with severity WARN).
- **Derived-model surfacing in `RockyComponent`** (opt-in via `surface_derived_models=True`).
  When enabled, `build_defs_from_state` additionally builds one `AssetSpec` per entry in
  `compile.models_detail`, splits them by partitioning shape, and creates one multi-asset per
  shape (`rocky_models_daily`, `rocky_models_unpartitioned`, etc.). Each multi-asset uses
  `can_subset=False` until `rocky run --model <name>` lands on the engine side; per-asset
  freshness, optimize metadata, contract specs, and `PartitionsDefinition` all flow through
  automatically.
- **Live log streaming via `_run_filters` (T2)**. The component's standard execution path
  (`_run_filters` inside `_make_rocky_asset`) now calls `RockyResource.run_streaming(context, ...)`
  by default instead of the buffered `run()`. Users get live `rocky: ...` log lines in the
  Dagster run viewer for the duration of every materialization, instead of waiting for the
  subprocess to exit. The behavior is automatic — no config flag, no opt-in. To fall back to
  the buffered path (e.g. in tests that don't want to mock `subprocess.Popen`), call
  `_run_filters(..., streaming=False)`.
- **Per-model freshness override in `_build_group_contexts`** — uses `per_model_freshness_policies()`
  to look up per-table policies, falling back to the pipeline-level default.

#### Added — `dg` CLI integration (T5.1)

- New `[project.entry-points."dagster_dg_cli.registry_modules"]` entry in `pyproject.toml` so
  `dg list components` and `dg scaffold defs dagster_rocky.RockyComponent <name>` discover
  `RockyComponent` automatically without manual configuration.

#### Engine-side changes (consumed by dagster-rocky)

These shipped in the engine to support dagster-rocky's v0.4 features:

- `[checks.freshness]` is now projected into `rocky discover --output json` as the new `checks`
  field on `DiscoverOutput`.
- New `ModelFreshnessConfig` struct + `freshness: Option<ModelFreshnessConfig>` field on `ModelConfig`.
- New `ModelDetail` struct + `models_detail: Vec<ModelDetail>` field on `CompileOutput`.
- `time_interval` materialization strategy fully wired through `rocky-core` (separate engine work).

#### Changed

- `DEFAULT_CHECK_NAMES` is now a 4-tuple (was 3): `("row_count", "column_match", "freshness",
  "row_count_anomaly")`. Existing tests asserting check counts must update from `× 3` to `× 4`.
- `_log_run_diagnostics` no longer logs drift or anomaly warnings — those flow through structured
  events. Contract violations are still logged. Removed `ANOMALY_LOG_THRESHOLD_PCT` constant.
- `_build_group_contexts` now accepts an optional `model_policies: dict[str, FreshnessPolicy]`
  argument. Backwards compatible — defaults to no overrides.

#### Documentation

Seven new doc pages under `docs/src/content/docs/dagster/`:

- `freshness.md` (order 9)
- `sensors.md` (order 10)
- `schedules.md` (order 11)
- `observability.md` (order 12)
- `partitions.md` (order 13)
- `automation.md` (order 14)
- `health.md` (order 15)
- `scaffold.md` (order 16)

#### Tests

- 9 new test modules (sensor, schedules, observability, column_lineage, automation, health,
  scaffold, partitions, freshness extension).
- 91+ new tests; total suite now 155+ tests, all passing.

#### Migration from v0.3.0

No breaking API changes. The default `RockyComponent` behavior is additive:

- Drift and anomaly events now appear in the asset timeline. Users with existing alerting on
  `context.log.warning` should migrate to alerts on `AssetObservation` and `AssetCheckResult`.
- The `row_count_anomaly` check is added to every Rocky asset. Tests that count check specs need
  to update from `× 3` to `× 4`.

See [GitHub Releases (filtered to dagster-rocky)](https://github.com/rocky-data/rocky/releases?q=dagster) for detailed release notes. dagster-rocky is released from the `rocky-data/rocky` monorepo under the `dagster-v*` tag prefix.
