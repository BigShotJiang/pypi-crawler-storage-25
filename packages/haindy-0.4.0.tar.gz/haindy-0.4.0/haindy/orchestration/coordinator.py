"""
Workflow coordinator for managing multi-agent test execution.
"""

import asyncio
from enum import Enum
from typing import Any
from uuid import UUID

from haindy.agents import ActionAgent, TestRunner
from haindy.core.interfaces import AutomationDriver
from haindy.core.types import ScopeTriageResult, TestPlan, TestState
from haindy.monitoring.logger import get_logger
from haindy.orchestration.communication import CoordinatorDiagnostics, MessageType
from haindy.orchestration.scope_pipeline import run_scope_triage_and_plan
from haindy.orchestration.state_manager import StateManager, StateTransition
from haindy.runtime.agent_factory import AgentFactory

logger = get_logger(__name__)


class CoordinatorState(str, Enum):
    """States of the workflow coordinator."""

    IDLE = "idle"
    PLANNING = "planning"
    EXECUTING = "executing"
    PAUSED = "paused"
    COMPLETED = "completed"
    ERROR = "error"


class WorkflowCoordinator:
    """
    Central coordinator for multi-agent test execution workflows.

    Manages the overall test execution lifecycle, coordinates agents,
    and ensures smooth workflow progression.
    """

    def __init__(
        self,
        diagnostics: CoordinatorDiagnostics | None = None,
        state_manager: StateManager | None = None,
        automation_driver: AutomationDriver | None = None,
        agent_factory: AgentFactory | None = None,
        max_steps: int = 50,
    ):
        """
        Initialize the workflow coordinator.

        Args:
            diagnostics: In-memory coordinator diagnostics recorder
            state_manager: State manager for test execution
            automation_driver: Browser driver for web automation
        """
        self.diagnostics = diagnostics or CoordinatorDiagnostics()
        self.state_manager = state_manager or StateManager()
        self.automation_driver = automation_driver
        self._agent_factory = agent_factory or AgentFactory()

        # Agent instances
        self._agents: dict[str, Any] = {}

        # Coordinator state
        self._state = CoordinatorState.IDLE
        self._active_tests: dict[UUID, asyncio.Task] = {}
        self._plan_triage_results: dict[UUID, ScopeTriageResult] = {}

        # Configuration
        self._max_concurrent_tests = 5
        self.max_steps = max_steps

        logger.info("Workflow coordinator initialized")

    async def initialize(self) -> None:
        """Initialize the coordinator and create agent instances."""
        logger.info("Initializing workflow coordinator")
        self._agents = self._agent_factory.create_runtime_agents(
            automation_driver=self.automation_driver
        ).as_dict()

        # Register state callbacks
        self.state_manager.register_state_callback(self._on_state_change)

        self._state = CoordinatorState.IDLE
        logger.info("Workflow coordinator initialized successfully")

    async def execute_test_from_requirements(
        self,
        requirements: str,
        initial_url: str | None = None,
        context: dict[str, Any] | None = None,
        precomputed_plan: TestPlan | None = None,
        triage_result: ScopeTriageResult | None = None,
    ) -> TestState:
        """
        Execute a test from high-level requirements.

        Args:
            requirements: Natural language test requirements
            initial_url: Optional starting URL
            context: Optional execution context
            precomputed_plan: Optional pre-generated test plan to execute
            triage_result: Optional triage outcome associated with the plan

        Returns:
            Final test state
        """
        logger.info("Starting test execution from requirements")

        # Check concurrent test limit
        if len(self._active_tests) >= self._max_concurrent_tests:
            raise RuntimeError(
                f"Maximum concurrent tests ({self._max_concurrent_tests}) reached"
            )

        try:
            # Phase 1: Generate test plan
            self._state = CoordinatorState.PLANNING
            if precomputed_plan is not None:
                test_plan = precomputed_plan
                triage_outcome = triage_result or ScopeTriageResult()
                self._plan_triage_results[test_plan.plan_id] = triage_outcome

                await self._publish_event(
                    from_agent="test_planner",
                    message_type=MessageType.PLAN_CREATED,
                    content={"test_plan": test_plan.model_dump()},
                )
            else:
                test_plan, triage_outcome = await self._generate_test_plan(
                    requirements,
                    context,
                )

            # Phase 2: Initialize test state
            test_state = await self.state_manager.create_test_state(test_plan, context)

            # Phase 3: Execute test
            self._state = CoordinatorState.EXECUTING
            final_state = await self._execute_test_plan(test_state, initial_url)

            self._state = CoordinatorState.COMPLETED
            return final_state

        except Exception as e:
            logger.error(f"Test execution failed: {e}")
            self._state = CoordinatorState.ERROR
            raise

    async def _generate_test_plan(
        self,
        requirements: str,
        context: dict[str, Any] | None = None,
    ) -> tuple[TestPlan, ScopeTriageResult]:
        """Generate test plan using Test Planner agent."""
        logger.info("Generating test plan from requirements")

        triage_agent = self._agents.get("scope_triage")
        planner = self._agents.get("test_planner")
        if not triage_agent:
            raise RuntimeError("Scope Triage agent not available")
        if not planner:
            raise RuntimeError("Test Planner agent not available")

        # Create test plan via two-pass flow
        test_plan, triage_result = await run_scope_triage_and_plan(
            requirements=requirements,
            planner=planner,
            triage_agent=triage_agent,
            context=context,
        )

        # Store triage result for downstream consumption
        self._plan_triage_results[test_plan.plan_id] = triage_result

        # Notify plan created for diagnostics.
        await self._publish_event(
            from_agent="test_planner",
            message_type=MessageType.PLAN_CREATED,
            content={"test_plan": test_plan.model_dump()},
        )

        return test_plan, triage_result

    async def _execute_test_plan(
        self, test_state: TestState, initial_url: str | None = None
    ) -> TestState:
        """Execute test plan using Test Runner agent."""
        logger.info(f"Executing test plan: {test_state.test_plan.name}")

        runner = self._agents.get("test_runner")
        if not runner:
            raise RuntimeError("Test Runner agent not available")
        if not isinstance(runner, TestRunner):
            raise RuntimeError("Configured test_runner agent has unexpected type")

        # Create execution task
        test_task = asyncio.create_task(
            runner.execute_test_plan(test_state, initial_url)
        )

        # Track active test
        self._active_tests[test_state.test_plan.plan_id] = test_task

        try:
            # Wait for completion
            final_state = await test_task

            return final_state

        except asyncio.TimeoutError:
            logger.error("Test execution timed out")
            test_task.cancel()

            # Update state to failed
            await self.state_manager.update_test_state(
                test_state.test_plan.plan_id,
                StateTransition.ABORT,
                {"reason": "timeout"},
            )

            raise

        finally:
            # Remove from active tests
            self._active_tests.pop(test_state.test_plan.plan_id, None)

    async def pause_test(self, test_id: UUID) -> None:
        """Pause an executing test."""
        logger.info(f"Pausing test: {test_id}")

        # Update state
        await self.state_manager.update_test_state(test_id, StateTransition.PAUSE)

        await self._publish_event(
            message_type=MessageType.PAUSE_TEST,
            content={"test_id": str(test_id)},
        )

    async def resume_test(self, test_id: UUID) -> None:
        """Resume a paused test."""
        logger.info(f"Resuming test: {test_id}")

        # Update state
        await self.state_manager.update_test_state(test_id, StateTransition.RESUME)

        await self._publish_event(
            message_type=MessageType.RESUME_TEST,
            content={"test_id": str(test_id)},
        )

    async def stop_test(self, test_id: UUID) -> None:
        """Stop an executing test."""
        logger.info(f"Stopping test: {test_id}")

        # Cancel test task if running
        test_task = self._active_tests.get(test_id)
        if test_task and not test_task.done():
            test_task.cancel()

        # Remove from active tests
        self._active_tests.pop(test_id, None)

        # Update state
        await self.state_manager.update_test_state(
            test_id, StateTransition.ABORT, {"reason": "user_requested"}
        )

        await self._publish_event(
            message_type=MessageType.STOP_TEST,
            content={"test_id": str(test_id)},
        )

    async def _on_state_change(
        self, test_id: UUID, test_state: TestState, transition: StateTransition
    ) -> None:
        """Handle test state changes."""
        logger.info(
            f"Test state changed: {test_id} - {transition}",
            extra={"status": test_state.status},
        )

        await self._publish_event(
            message_type=MessageType.STATUS_UPDATE,
            content={
                "test_id": str(test_id),
                "status": test_state.status,
                "transition": transition,
            },
        )

    async def _publish_event(
        self,
        *,
        message_type: MessageType,
        content: dict[str, Any],
        from_agent: str = "coordinator",
    ) -> None:
        """Record a diagnostics event without implying bus-driven control flow."""
        self.diagnostics.record_event(
            message_type=message_type,
            content=content,
            source=from_agent,
        )

    def get_active_tests(self) -> list[UUID]:
        """Get list of active test IDs."""
        return list(self._active_tests.keys())

    def get_action_agent(self) -> ActionAgent | None:
        """Get the initialized ActionAgent instance, if available."""
        agent = self._agents.get("action_agent")
        if isinstance(agent, ActionAgent):
            return agent
        return None

    def get_scope_triage_result(self, plan_id: UUID) -> ScopeTriageResult | None:
        """Retrieve the stored scope triage result for a generated plan."""
        return self._plan_triage_results.get(plan_id)

    async def get_test_progress(self, test_id: UUID) -> dict[str, Any]:
        """Get progress for a specific test."""
        return await self.state_manager.get_test_progress(test_id)

    def get_coordinator_state(self) -> dict[str, Any]:
        """Get current coordinator state."""
        return {
            "state": self._state,
            "active_tests": len(self._active_tests),
            "agents": list(self._agents.keys()),
            "diagnostics": self.diagnostics.get_statistics(),
        }

    async def generate_test_plan(self, requirements: str) -> TestPlan:
        """
        Generate a test plan from requirements without executing.

        Args:
            requirements: Natural language test requirements

        Returns:
            Generated test plan
        """
        logger.info("Generating test plan from requirements")
        self._state = CoordinatorState.PLANNING

        try:
            # Generate test plan using the planner agent
            test_plan, _ = await self._generate_test_plan(requirements)
            self._state = CoordinatorState.IDLE
            return test_plan
        except Exception as e:
            self._state = CoordinatorState.ERROR
            logger.error(f"Failed to generate test plan: {e}")
            raise

    async def cleanup(self) -> None:
        """Alias for shutdown for compatibility."""
        await self.shutdown()

    async def shutdown(self) -> None:
        """Shutdown the coordinator and cleanup resources."""
        logger.info("Shutting down workflow coordinator")

        # Cancel all active tests
        for test_id, task in self._active_tests.items():
            if not task.done():
                logger.warning(f"Cancelling active test: {test_id}")
                task.cancel()

        # Wait for tasks to complete
        if self._active_tests:
            await asyncio.gather(*self._active_tests.values(), return_exceptions=True)

        # Clear active tests
        self._active_tests.clear()

        # Shutdown components
        await self.diagnostics.shutdown()
        await self.state_manager.shutdown()
        self._plan_triage_results.clear()

        self._state = CoordinatorState.IDLE
        logger.info("Workflow coordinator shutdown complete")
