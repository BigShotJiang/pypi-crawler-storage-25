---
name: Bug report
about: Report a problem with colony-probe
title: "[bug] "
labels: bug
---

**What went wrong**

**How to reproduce**

```bash
python -m colony_probe --dry-run ...
```

**What you expected**

**What happened**

**Environment**
- `colony-probe` version:
- Python version:
- OS:
- Anthropic SDK installed? Y/N + version if yes
