---
name: Feature request
about: Suggest an idea for colony-probe
title: "[feature] "
labels: enhancement
---

**The problem you're trying to solve**

**What you'd like to see**

If this is a new question or signal rule, read `CLAUDE.md` → "Adding Questions" and "Adding Signal Rules" for the contract the addition needs to satisfy. Questions must pass the innocence principle — individually non-suspicious.

**Alternatives you've considered**

**Additional context**
