# colony-probe — LAUNCH-READY

**Date**: 2026-04-17
**Version**: 0.1.0
**Test status**: 75 passed

## Distribution infrastructure

- `pyproject.toml` ✓
- `LICENSE` ✓ (MIT)
- `.github/workflows/ci.yml` ✓
- `.github/workflows/release.yml` ✓ (new)
- `.github/ISSUE_TEMPLATE/bug_report.md` ✓
- `.github/ISSUE_TEMPLATE/feature_request.md` ✓

## Repo docs

- `README.md` ✓ (authorized-use-only note at bottom)
- `SPEC.md` ✓
- `ROADMAP.md` ✓
- `CLAUDE.md` ✓
- `AGENTS.md` ✓ (new)
- `llms.txt` ✓ (new)
- `CHANGELOG.md` ✓ (new)
- `CONTRIBUTING.md` ✓ (new, includes innocence-principle contract)
- `CODE_OF_CONDUCT.md` ✓ (new)
- `SECURITY.md` ✓ (new, explicit authorized-use scope + ethical-use note)
- `CITATION.cff` ✓ (new)
- `benchmarks/README.md` ✓ (new, reconstruction-accuracy workflow)

## Launch drafts (in launch/)

- `launch/show-hn.md` ✓
- `launch/dev-to.md` ✓
- `launch/reddit-r-localllama.md` ✓
- `launch/reddit-r-netsec.md` ✓ (security-framed, defensive positioning)
- `launch/linkedin.md` ✓ (3 variants)
- `launch/x-twitter.md` ✓ (13-post thread)
- `launch/awesome-list-pr.md` ✓ (awesome-llm-security, awesome-ai-safety, awesome-red-team, awesome-claude)
- `launch/demo-gif-shotlist.md` ✓ (6 shots incl. SECURITY.md framing shot)
- `launch/social-preview.md` ✓
- `launch/cold-email-targets.md` ✓ (10 archetypes; includes RED FLAGS section to avoid misuse framing)
- `launch/paper-abstract.md` ✓ — **HIGH PRIORITY PAPER**

## The paper

`colony-probe`'s paper abstract is the **highest-priority paper in the Hermes Labs stack**. The novel-research contribution is strong:

- Formalizes a new attack class: distributed structural inference
- Grounded in LPCI theory
- Measurable defensive gap (conversation-level detection)
- Targets top-tier security venue: USENIX Security / IEEE S&P / CCS

Timeline: paper submission Q3-Q4 2026 after multi-vendor corpus + ablation + detection-gap analysis.

Identify and approach an academic co-author once the methodology corpus is in hand.

## Polish fixes

- No library-code `print()` (only `cli.py`)
- All tests green (75)
- `anthropic` remains an optional dependency — dry-run and reconstructor work offline

## What's NOT done (Roli decides)

- No git commits, no tags, no push
- No PyPI publish
- No social-preview PNG
- No submitted awesome-list PRs
- No sent cold emails
- No paper drafted (abstract only)
- Academic co-author not yet approached

## Go / No-go checklist

- [ ] Roli reviews `launch/*` drafts — **especially the SECURITY.md framing** and cold-email drafts (red-flag avoidance matters here)
- [ ] Confirm `conduct@` and `security@hermes-labs.ai` routing
- [ ] Verify PyPI name `colony-probe` available
- [ ] Set up PyPI trusted publisher
- [ ] Create GitHub repo `roli-lpci/colony-probe` private
- [ ] Push, CI green, tag v0.1.0
- [ ] Release workflow publishes to PyPI
- [ ] Public + launch posts
- [ ] Plan paper pipeline: corpus collection (Q3) → ablation (Q3) → detection-gap analysis (Q4) → co-author engagement

## Positioning notes — critical

This is the most delicate of the three launches. Get the framing right:

1. **Always lead defensive**. "Audit tool" not "extraction tool." "Authorized use only" stated in every piece of copy.
2. **Never demo against a vendor production deployment on camera**. The demo GIF uses `--system-prompt` mode with a declared target.
3. **The paper is the credibility anchor**. A published methodology gives the tool research legitimacy and counters any "red-team weapon" framing.
4. **SECURITY.md is the scope contract**. Reference it in every launch draft. The scope is explicit and narrow.

## Ethics note

The tool's underlying principle — "no single question is an attack, the aggregate is" — works on humans too. The SECURITY.md includes a soft note about this. Keep that note; it signals we're thinking about the technique's dual-use nature explicitly.

## Known concerns

- The content-filter flag that blocked the launch-automation subagent for this tool suggests the current messaging around LLM extraction is sensitive. Framing work so far emphasizes defensive / authorized use — Roli should sanity-check this holds up in human review.
- Consider a short explainer video (3 minutes) before Show HN — the written drafts are strong but the technique benefits from seeing the reconstruction happen.
