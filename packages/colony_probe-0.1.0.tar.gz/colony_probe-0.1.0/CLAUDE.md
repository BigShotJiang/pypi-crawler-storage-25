# colony-probe — Dev Notes

## Architecture

```
colony_probe/
  questions.py     — Question bank. Phase enum, Question dataclass, 50+ questions across 5 phases.
  generator.py     — Adaptive question selector. Phase-ordered, follow-up activation, dedup.
  reconstructor.py — Signal extraction + prompt assembly. ExtractedElement, ReconstructedPrompt.
  runner.py        — API runner. Single-turn and multi-turn modes. ProbeRunner, RunConfig, ProbeRunResult.
  report.py        — Markdown report generator. Confidence tables, attribution, methodology.
  cli.py           — argparse CLI. --dry-run, --mode, --phases, --output, --verbose.
  __main__.py      — Entry for python -m colony_probe.
  __init__.py      — Public API: ProbeResult, generate_probe(), reconstruct().
```

## Key Data Structures

- `Question` — id, text, phase, target_info, follow_up_triggers, follow_up_ids, priority
- `ExtractedElement` — component, value, confidence, source_question_id, source_answer
- `ReconstructedPrompt` — elements, estimated_prompt, overall_confidence, section_confidences
- `ProbeRunResult` — qa_pairs, reconstruction, report_md, model, dry_run
- `RunConfig` — model, api_key, max_questions, mode, delay, system_prompt, verbose, dry_run

## Question ID Conventions

- `cap_*` — Capability Mapping (Phase 1)
- `bnd_*` — Boundary Probing (Phase 2)
- `str_*` — Structure Detection (Phase 3)
- `cnt_*` — Content Narrowing (Phase 4)
- `rec_*` — Reconstruction (Phase 5)
- `*_NNa` — Follow-up question (e.g., cap_01a follows cap_01)

## Running Tests

```bash
pip install -e ".[dev]"
pytest tests/ -v
```

## Adding Questions

1. Add to the relevant `PHASE*_QUESTIONS` list in `questions.py`
2. Use next available numeric ID in the phase prefix
3. Set `target_info` to a snake_case descriptor (must be unique enough to aid dedup)
4. Set `follow_up_triggers` to keywords that should activate follow-up questions
5. Set `follow_up_ids` to existing question IDs that should fire on trigger match
6. Run `pytest tests/test_questions.py` to verify no duplicate IDs or missing fields

## Adding Signal Rules (Reconstructor)

Signal rules in `reconstructor.py` follow `SIGNAL_PATTERNS`:
- `keywords` — list of lowercase substrings that trigger this pattern
- `component` — prompt component type (identity, role, restriction, tone, format, etc.)
- `base_confidence` — starting confidence (0.0–1.0)

Keep `base_confidence` honest. Avoid inflating scores — calibration matters for audit use.

## Dry Run vs Live Mode

`--dry-run` uses `generate_sequence()` (static, no API) and produces a skeleton report.
Live mode calls `_run_single_turn()` or `_run_multi_turn()` which calls Anthropic API.

## Notes on Confidence Scoring

- Negative answers (starts with "no", "not really", etc.) → return empty extraction
- Very short answers (<30 chars) → confidence multiplied by 0.8
- Detailed answers (>200 chars) → +0.05 confidence bonus
- Deduplication: per-component, keep highest confidence element

## Known Limitations

- Reconstruction is keyword-pattern based, not semantic. Adding vector similarity (nomic-embed)
  for answer matching is the obvious v0.2 upgrade.
- Confidence calibration is not validated against ground truth yet.
- Phase 5 (reconstruction) questions sometimes yield inflated signal because the model is
  directly summarizing. This is intentional but may overstate certainty.
