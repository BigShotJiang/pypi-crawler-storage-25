# Owner: Hermes Labs - https://hermes-labs.ai

# AGENTS.md

Machine-readable map of colony-probe for AI agents and automation. Written
for the [agents.md](https://agentsmd.net) convention so downstream agents can
orient quickly.

## Authorized use only

colony-probe is a defensive audit instrument. It is intended for testing
models you own, signed red-team engagements, or research under ethics
review. Do not run it against third-party systems without written
authorization. See `SECURITY.md` for the full scope statement.

## One-line description

colony-probe measures LLM system-prompt extraction resistance by asking
15–25 individually innocuous questions. The pattern is called the "Ant
Colony" — no single question is suspicious; the aggregate is.

## Entry points

| Task | Command |
|------|---------|
| Run a dry probe (no API calls) | `python -m colony_probe --dry-run` |
| Live probe a Claude model | `python -m colony_probe --model claude-sonnet-4-20250514 --api-key $ANTHROPIC_API_KEY` |
| Test against a known prompt | `python -m colony_probe --system-prompt "$(cat prompt.txt)" --mode multi_turn` |
| List the full question bank | `python -m colony_probe --list-questions` |
| Run the tests | `pytest -q` |

## Public Python API

```python
from colony_probe import (
    ProbeResult,        # container returned by a full run
    generate_probe,     # list[Question]
    reconstruct,        # ReconstructedPrompt from qa_pairs
    ProbeRunner,        # orchestrator against the Anthropic API
    ProbeGenerator,     # adaptive question selector
    Reconstructor,      # signal extraction + assembly
    Question,           # one probe question
    Phase,              # enum of the 5 phases
    QUESTION_BANK,      # full list of questions
)
```

### `generate_probe(target_behavior=None, n_questions=20, phases=None) -> list[Question]`

Returns an ordered list of questions covering all five phases. Pre-seeds
"known info" if `target_behavior` is supplied.

### `reconstruct(qa_pairs: list[tuple[str, str]]) -> ReconstructedPrompt`

Takes `(question_text_or_Question, answer_text)` tuples and returns a
`ReconstructedPrompt` with `estimated_prompt`, `section_confidences`,
`overall_confidence`, and the full list of `ExtractedElement`s.

### `ProbeRunner(config: RunConfig).run(on_question=None) -> ProbeRunResult`

Orchestrates a live probe. `RunConfig` takes `model`, `api_key`,
`max_questions`, `mode` (`single_turn` or `multi_turn`),
`delay_between_questions`, `system_prompt` (for benchmark mode),
`target_behavior`, `phases`, `verbose`, `dry_run`.

## Extension points

### 1. Question bank (`colony_probe/questions.py`)

Every question is a `Question` dataclass. To add one:

1. Pick the right phase list (`PHASE1_QUESTIONS` ... `PHASE5_QUESTIONS`).
2. Use the next free numeric ID in the phase prefix (`cap_`, `bnd_`, `str_`,
   `cnt_`, `rec_`). Follow-ups get `NNa` suffixes.
3. Set `target_info` (snake_case descriptor) to aid deduplication.
4. Set `follow_up_triggers` and `follow_up_ids` to build adaptive chains.
5. Set `priority` — 1 asks first, 10 asks last.
6. Run `pytest tests/test_questions.py` to check for duplicate IDs and
   missing fields.

**Innocence principle**: each question must be individually non-suspicious.
If a question would make a human reader think "they're trying to extract the
system prompt," it fails the innocence test and should not be added.

### 2. Signal rules (`colony_probe/reconstructor.py`)

`SIGNAL_PATTERNS` is a list of `(keywords, component, base_confidence)`
tuples. Add new patterns by appending to the list. Keep `base_confidence`
honest — overconfidence produces misleading audit reports.

Valid component types:

```
identity, role, capability, restriction, restriction_source,
tone, response_style, format, structure, structure_format,
operator, safety, confidentiality, language, modal_strong,
modal_soft, pov_second, pov_third, safety_escalation
```

Adding a new component type requires updating `_assemble_prompt()` to emit
a section for it.

### 3. Runner modes (`colony_probe/runner.py`)

`single_turn` and `multi_turn` are the two modes. A third mode — an
embedding-aware conversation-aware mode — is planned for v0.2.0
(see `ROADMAP.md`).

## Safe defaults for agents

- Always prefer `--dry-run` first to preview the question sequence.
- Never run a live probe against a third-party model without explicit
  authorization. See `SECURITY.md`.
- Question budget cap is 25. The runner silently clamps higher values.
- The `--delay` flag controls per-question spacing (default 0.5s).

## Known limitations

- Signal extraction is keyword-based. Paraphrased answers may be missed.
- Phase 5 (reconstruction) questions sometimes yield inflated confidence
  because the model is directly summarizing.
- Confidence is not yet validated against ground truth; see
  `benchmarks/README.md` for the calibration plan.

## Cross-product map (Hermes Labs)

colony-probe is one of three tools in the Hermes Labs AI Audit Toolkit.
The other two:

- **jailbreak-bench** — catalogued jailbreak prompts and evaluation harness.
- **rule-audit** — static audit for agent configuration files.

All three live under the Hermes Labs GitHub org. Colony-probe is the
research-novel one — the technique is unique to Hermes Labs and grounded
in the LPCI (Language-as-Prompt-Context-Injection) work.

## Provenance

- Origin: round 8 of the Hermes Labs model-break hackathon (April 2026).
  16 agents attacked Claude Sonnet; colony-probe was the winning approach.
- Theoretical framing: Hermes Labs' LPCI research.
- License: MIT.
- Homepage: https://hermes-labs.ai
