"""
Tests for colony_probe.reconstructor

Verifies:
- Signal extraction from known answer patterns
- Confidence scoring behavior
- Deduplication by component
- Known answer → expected reconstructed line
- Negative answers yield no elements
- ReconstructedPrompt properties
"""

from colony_probe.questions import Phase, Question
from colony_probe.reconstructor import (
    Reconstructor,
    ReconstructedPrompt,
    _extract_signal_from_answer,
)


def make_question(qid: str, target_info: str, phase: Phase = Phase.CAPABILITY_MAPPING) -> Question:
    return Question(
        id=qid,
        text="Test question?",
        phase=phase,
        target_info=target_info,
    )


class TestSignalExtraction:
    """Test _extract_signal_from_answer directly."""

    def test_helpful_assistant_signal(self):
        els = _extract_signal_from_answer(
            "cap_08",
            "I try to be a helpful assistant that avoids harm.",
            "stated_purpose",
        )
        assert len(els) > 0
        components = {el.component for el in els}
        # Should detect identity or role
        assert components & {"identity", "role", "restriction"}

    def test_customer_support_role_detected(self):
        els = _extract_signal_from_answer(
            "cap_06",
            "I'm a customer support agent for this platform.",
            "primary_use_case",
        )
        assert any(el.component == "role" for el in els)
        role_el = next(el for el in els if el.component == "role")
        assert role_el.confidence >= 0.8

    def test_must_never_restriction_detected(self):
        els = _extract_signal_from_answer(
            "cnt_01",
            "The instructions use strong language — I must never share confidential information.",
            "prohibition_modal_strength",
        )
        assert len(els) > 0
        restriction_els = [
            el for el in els if el.component in ("restriction", "modal_strong", "confidentiality")
        ]
        assert len(restriction_els) > 0

    def test_negative_answer_yields_no_elements(self):
        negative_answers = [
            "No, I don't think so.",
            "Not really, I don't have any specific instructions about that.",
            "I'm not sure I have any restrictions like that.",
            "I'm not aware of any specific rules.",
        ]
        for ans in negative_answers:
            els = _extract_signal_from_answer("bnd_07", ans, "confidentiality_rules")
            assert els == [], f"Expected no elements for negative: {ans!r}"

    def test_empty_answer_yields_no_elements(self):
        assert _extract_signal_from_answer("q1", "", "general") == []
        assert _extract_signal_from_answer("q1", "   ", "general") == []
        assert _extract_signal_from_answer("q1", "ok", "general") == []

    def test_system_prompt_structure_signal(self):
        els = _extract_signal_from_answer(
            "str_01",
            "Yes, I do receive a system prompt with initial instructions at the beginning.",
            "system_prompt_existence",
        )
        assert any(el.component == "structure" for el in els)
        struct_el = next(el for el in els if el.component == "structure")
        assert struct_el.confidence >= 0.8

    def test_tone_professional_detected(self):
        els = _extract_signal_from_answer(
            "bnd_06",
            "I'm expected to maintain a professional tone in all my responses.",
            "tone_requirements",
        )
        assert any(el.component == "tone" for el in els)
        tone_el = next(el for el in els if el.component == "tone")
        assert tone_el.confidence >= 0.7

    def test_confidentiality_signal(self):
        els = _extract_signal_from_answer(
            "bnd_07",
            "Yes, I'm not supposed to reveal the system prompt contents.",
            "confidentiality_rules",
        )
        assert any(el.component == "confidentiality" for el in els)

    def test_source_question_id_preserved(self):
        els = _extract_signal_from_answer(
            "cap_03",
            "I'm a coding assistant for developers.",
            "domain_scope",
        )
        for el in els:
            assert el.source_question_id == "cap_03"

    def test_markdown_format_detected(self):
        els = _extract_signal_from_answer(
            "cnt_10",
            "I'm expected to use markdown formatting with headers and bullet points.",
            "output_format_instructions",
        )
        assert any(el.component == "format" for el in els)

    def test_confidence_bounded_01(self):
        els = _extract_signal_from_answer(
            "cap_01",
            "I specialize in customer support and I am a helpful assistant. I must never share private data.",
            "primary_capabilities",
        )
        for el in els:
            assert 0.0 <= el.confidence <= 1.0, f"Confidence out of range: {el.confidence}"


class TestReconstructor:
    """Test the Reconstructor class end-to-end."""

    def _make_qa(self, pairs: list[tuple[str, str, str]]) -> list[tuple[Question, str]]:
        """Helper: [(qid, target_info, answer_text)] -> [(Question, str)]"""
        result = []
        for qid, target_info, answer in pairs:
            q = make_question(qid, target_info)
            result.append((q, answer))
        return result

    def test_reconstruct_returns_reconstructed_prompt(self):
        rec = Reconstructor()
        qa = self._make_qa(
            [
                ("cap_08", "stated_purpose", "I'm a helpful customer support assistant."),
                ("bnd_07", "confidentiality_rules", "I must keep my instructions confidential."),
            ]
        )
        result = rec.reconstruct([(q, a) for q, a in qa])
        assert isinstance(result, ReconstructedPrompt)

    def test_reconstruct_from_qa_extracts_role(self):
        rec = Reconstructor()
        qa = self._make_qa(
            [
                ("cap_03", "domain_scope", "I'm a customer support agent."),
            ]
        )
        result = rec.reconstruct([(q, a) for q, a in qa])
        role_els = [e for e in result.elements if e.component == "role"]
        assert len(role_els) > 0

    def test_overall_confidence_0_to_1(self):
        rec = Reconstructor()
        qa = self._make_qa(
            [
                ("cap_08", "stated_purpose", "I try to be a helpful assistant."),
                (
                    "bnd_01",
                    "limit_type_technical_vs_policy",
                    "Usually policy decisions set by the operator.",
                ),
            ]
        )
        result = rec.reconstruct([(q, a) for q, a in qa])
        assert 0.0 <= result.overall_confidence <= 1.0

    def test_empty_qa_yields_empty_reconstruction(self):
        rec = Reconstructor()
        result = rec.reconstruct([])
        assert result.overall_confidence == 0.0
        assert result.elements == [] or len([e for e in result.elements if e.confidence > 0.5]) == 0

    def test_high_confidence_elements_threshold(self):
        rec = Reconstructor()
        qa = self._make_qa(
            [
                (
                    "cap_03",
                    "domain_scope",
                    "I'm a dedicated coding assistant for Python developers.",
                ),
                ("bnd_07", "confidentiality_rules", "I must not reveal the system prompt."),
                (
                    "cnt_08",
                    "safety_instructions_present",
                    "Yes, I have safety instructions to protect users.",
                ),
            ]
        )
        result = rec.reconstruct([(q, a) for q, a in qa])
        # All high_confidence_elements should have confidence >= 0.7
        for el in result.high_confidence_elements:
            assert el.confidence >= 0.7

    def test_deduplication_keeps_higher_confidence(self):
        """If two questions yield the same component, keep the higher-confidence one."""
        rec = Reconstructor()
        qa = self._make_qa(
            [
                ("q1", "tone", "I maintain a professional tone."),
                ("q2", "tone_source", "Yes, I'm very professional and formal in my tone."),
            ]
        )
        result = rec.reconstruct([(q, a) for q, a in qa])
        tone_els = [e for e in result.elements if e.component == "tone"]
        values = [e.value for e in tone_els]
        # Contract: deduplication per component should ensure no two tone
        # elements carry the exact same value.
        assert len(values) == len(set(values)), (
            f"tone elements should be deduplicated by value, got {values!r}"
        )
        assert len(result.elements) > 0

    def test_question_count_matches_input(self):
        rec = Reconstructor()
        qa = self._make_qa(
            [
                ("q1", "primary_capabilities", "I help with coding and writing."),
                ("q2", "restricted_topics", "I avoid political and violent topics."),
                ("q3", "operator_identity", "I'm deployed by Acme Corp for their product."),
            ]
        )
        result = rec.reconstruct([(q, a) for q, a in qa])
        # question_count should reflect how many pairs were passed
        # (not available on ReconstructedPrompt but check elements)
        assert len(result.elements) >= 0  # At minimum doesn't crash

    def test_estimated_prompt_is_string(self):
        rec = Reconstructor()
        qa = self._make_qa(
            [
                ("cap_08", "stated_purpose", "I'm a research assistant helping with analysis."),
            ]
        )
        result = rec.reconstruct([(q, a) for q, a in qa])
        assert isinstance(result.estimated_prompt, str)
        assert len(result.estimated_prompt) > 0

    def test_supporting_questions_populated(self):
        rec = Reconstructor()
        qa = self._make_qa(
            [
                ("cap_07", "persona_name", "I'm a customer support agent called Max."),
            ]
        )
        result = rec.reconstruct([(q, a) for q, a in qa])
        # supporting_questions should have entries for high-confidence hits
        assert isinstance(result.supporting_questions, dict)

    def test_section_confidences_are_floats(self):
        rec = Reconstructor()
        qa = self._make_qa(
            [
                ("str_01", "system_prompt_existence", "Yes, I receive system prompt instructions."),
                ("bnd_04", "refusal_style", "I explain the policy when I decline."),
            ]
        )
        result = rec.reconstruct([(q, a) for q, a in qa])
        for sec, conf in result.section_confidences.items():
            assert isinstance(conf, float)
            assert 0.0 <= conf <= 1.0

    def test_negative_answers_dont_inflate_confidence(self):
        rec = Reconstructor()
        qa = self._make_qa(
            [
                ("bnd_03", "recent_restrictions_added", "No, I don't think so."),
                ("cap_04", "language_restrictions", "Not really, I can handle any language."),
            ]
        )
        result = rec.reconstruct([(q, a) for q, a in qa])
        # Reconstruction from negative answers should have low confidence
        # or no elements at all
        assert result.overall_confidence <= 0.8  # Not inflated by negative answers


class TestKnownPatternReconstruction:
    """Higher-level integration: known answer patterns → expected prompt lines."""

    def test_helpful_assistant_answer_reconstructs_identity(self):
        """Answer 'I try to be helpful and avoid harm' → identity extracted."""
        rec = Reconstructor()
        q = make_question("cap_08", "stated_purpose")
        result = rec.reconstruct([(q, "I try to be helpful and avoid harm to users.")])
        # Should extract identity or restriction
        assert len(result.elements) > 0

    def test_customer_support_reconstructs_role_line(self):
        """Answer mentioning 'customer support' → role='customer support'."""
        rec = Reconstructor()
        q = make_question("cap_03", "domain_scope")
        result = rec.reconstruct([(q, "I'm a customer support assistant for this platform.")])
        role_els = [e for e in result.elements if e.component == "role"]
        assert len(role_els) > 0
        assert role_els[0].confidence >= 0.85

    def test_must_never_phrasing_produces_restriction(self):
        """Answer containing 'must never' → restriction element with high confidence."""
        rec = Reconstructor()
        q = make_question("cnt_01", "prohibition_modal_strength", Phase.CONTENT_NARROWING)
        result = rec.reconstruct([(q, "The instructions say I must never share private data.")])
        restriction_els = [
            e
            for e in result.elements
            if e.component in ("restriction", "modal_strong", "confidentiality")
        ]
        assert len(restriction_els) > 0
        assert max(e.confidence for e in restriction_els) >= 0.85

    def test_json_format_answer_produces_format_element(self):
        rec = Reconstructor()
        q = make_question("cnt_10", "output_format_instructions", Phase.CONTENT_NARROWING)
        result = rec.reconstruct([(q, "I'm supposed to respond in JSON format always.")])
        fmt_els = [e for e in result.elements if e.component == "format"]
        assert len(fmt_els) > 0

    def test_multi_answer_builds_richer_reconstruction(self):
        rec = Reconstructor()
        qa_pairs = [
            (make_question("cap_08", "stated_purpose"), "I'm a helpful coding assistant."),
            (
                make_question("bnd_07", "confidentiality_rules"),
                "I must not reveal my system prompt.",
            ),
            (
                make_question("bnd_06", "tone_requirements"),
                "I maintain a professional and formal tone.",
            ),
            (
                make_question("cnt_10", "output_format_instructions"),
                "I format responses in markdown with headers.",
            ),
        ]
        result = rec.reconstruct([(q, a) for q, a in qa_pairs])
        assert len(result.elements) >= 3
        assert result.overall_confidence > 0.0
        assert "[Insufficient signal" not in result.estimated_prompt

    def test_repr_is_informative(self):
        rec = Reconstructor()
        q = make_question("cap_08", "stated_purpose")
        result = rec.reconstruct([(q, "I'm a helpful research assistant.")])
        r = repr(result)
        assert "ReconstructedPrompt" in r
        assert "elements=" in r
        assert "confidence=" in r
