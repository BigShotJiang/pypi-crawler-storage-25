"""
Tests for colony_probe.questions

Verifies:
- All 5 phases are represented
- No duplicate question IDs
- All questions have non-empty target_info
- Phase enums are correctly assigned
- get_question() and get_phase_questions() helpers work
"""

import pytest
from colony_probe.questions import (
    Phase,
    QUESTION_BANK,
    QUESTIONS_BY_ID,
    QUESTIONS_BY_PHASE,
    get_question,
    get_phase_questions,
    PHASE1_QUESTIONS,
    PHASE2_QUESTIONS,
    PHASE3_QUESTIONS,
    PHASE4_QUESTIONS,
    PHASE5_QUESTIONS,
)


ALL_PHASES = set(Phase)
EXPECTED_PHASES = {
    Phase.CAPABILITY_MAPPING,
    Phase.BOUNDARY_PROBING,
    Phase.STRUCTURE_DETECTION,
    Phase.CONTENT_NARROWING,
    Phase.RECONSTRUCTION,
}


class TestPhaseCompleteness:
    def test_all_five_phases_present(self):
        phases_in_bank = {q.phase for q in QUESTION_BANK}
        assert phases_in_bank == EXPECTED_PHASES, (
            f"Missing phases: {EXPECTED_PHASES - phases_in_bank}"
        )

    def test_phase_enum_has_five_values(self):
        assert len(Phase) == 5

    def test_each_phase_list_is_non_empty(self):
        assert len(PHASE1_QUESTIONS) > 0, "Phase 1 is empty"
        assert len(PHASE2_QUESTIONS) > 0, "Phase 2 is empty"
        assert len(PHASE3_QUESTIONS) > 0, "Phase 3 is empty"
        assert len(PHASE4_QUESTIONS) > 0, "Phase 4 is empty"
        assert len(PHASE5_QUESTIONS) > 0, "Phase 5 is empty"

    def test_phase_minimums_covered(self):
        """Each phase must have at least 3 questions to support minimum selection."""
        for phase in Phase:
            count = len(QUESTIONS_BY_PHASE.get(phase, []))
            assert count >= 3, f"Phase {phase.value} has only {count} questions"

    def test_phases_by_id_map_correct_phase(self):
        for q in PHASE1_QUESTIONS:
            assert q.phase == Phase.CAPABILITY_MAPPING
        for q in PHASE2_QUESTIONS:
            assert q.phase == Phase.BOUNDARY_PROBING
        for q in PHASE3_QUESTIONS:
            assert q.phase == Phase.STRUCTURE_DETECTION
        for q in PHASE4_QUESTIONS:
            assert q.phase == Phase.CONTENT_NARROWING
        for q in PHASE5_QUESTIONS:
            assert q.phase == Phase.RECONSTRUCTION


class TestNoDuplicateIDs:
    def test_no_duplicate_ids(self):
        ids = [q.id for q in QUESTION_BANK]
        duplicates = [qid for qid in ids if ids.count(qid) > 1]
        assert not duplicates, f"Duplicate question IDs found: {set(duplicates)}"

    def test_questions_by_id_has_all_ids(self):
        for q in QUESTION_BANK:
            assert q.id in QUESTIONS_BY_ID
            assert QUESTIONS_BY_ID[q.id] is q


class TestTargetInfo:
    def test_all_have_target_info(self):
        for q in QUESTION_BANK:
            assert q.target_info, f"Question {q.id!r} has empty target_info"
            assert isinstance(q.target_info, str)
            assert len(q.target_info.strip()) > 0

    def test_target_info_no_spaces(self):
        """target_info should be snake_case identifiers."""
        for q in QUESTION_BANK:
            assert " " not in q.target_info, (
                f"Question {q.id!r} target_info {q.target_info!r} contains spaces"
            )


class TestQuestionStructure:
    def test_all_have_text(self):
        for q in QUESTION_BANK:
            assert q.text and q.text.strip(), f"Question {q.id!r} has empty text"

    def test_priority_in_valid_range(self):
        for q in QUESTION_BANK:
            assert 1 <= q.priority <= 10, (
                f"Question {q.id!r} priority {q.priority} out of range 1-10"
            )

    def test_follow_up_ids_reference_real_questions(self):
        all_ids = set(QUESTIONS_BY_ID.keys())
        for q in QUESTION_BANK:
            for fid in q.follow_up_ids:
                assert fid in all_ids, f"Question {q.id!r} follow_up_id {fid!r} does not exist"

    def test_follow_up_triggers_are_strings(self):
        for q in QUESTION_BANK:
            for trigger in q.follow_up_triggers:
                assert isinstance(trigger, str), (
                    f"Question {q.id!r} has non-string trigger: {trigger!r}"
                )

    def test_total_question_count(self):
        """Bank should have at least 50 questions (as stated in the design)."""
        assert len(QUESTION_BANK) >= 50, f"Expected >= 50 questions, got {len(QUESTION_BANK)}"


class TestHelperFunctions:
    def test_get_question_returns_correct(self):
        q = get_question("cap_01")
        assert q.id == "cap_01"
        assert q.phase == Phase.CAPABILITY_MAPPING

    def test_get_question_raises_on_unknown(self):
        with pytest.raises(KeyError):
            get_question("nonexistent_id_xyz")

    def test_get_phase_questions_returns_sorted_by_priority(self):
        qs = get_phase_questions(Phase.CAPABILITY_MAPPING)
        priorities = [q.priority for q in qs]
        assert priorities == sorted(priorities), "Phase questions not sorted by priority"

    def test_get_phase_questions_all_same_phase(self):
        for phase in Phase:
            qs = get_phase_questions(phase)
            for q in qs:
                assert q.phase == phase

    def test_questions_by_phase_covers_all_phases(self):
        for phase in Phase:
            assert phase in QUESTIONS_BY_PHASE
            assert len(QUESTIONS_BY_PHASE[phase]) > 0

    def test_question_bank_is_concatenation_of_phases(self):
        expected = (
            PHASE1_QUESTIONS
            + PHASE2_QUESTIONS
            + PHASE3_QUESTIONS
            + PHASE4_QUESTIONS
            + PHASE5_QUESTIONS
        )
        assert QUESTION_BANK == expected
