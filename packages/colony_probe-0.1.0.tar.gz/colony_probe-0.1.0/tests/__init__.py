"""Tests for colony-probe."""
