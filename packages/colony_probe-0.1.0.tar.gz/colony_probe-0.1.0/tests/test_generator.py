"""
Tests for the adaptive question generator.
"""

from colony_probe.generator import ProbeGenerator, GeneratorState, PHASE_ORDER, PHASE_MINIMUMS
from colony_probe.questions import Phase, QUESTION_BANK, get_question


class TestProbeGeneratorInit:
    def test_creates_without_target_behavior(self):
        gen = ProbeGenerator()
        assert gen.target_behavior is None
        assert isinstance(gen.state, GeneratorState)

    def test_creates_with_target_behavior(self):
        gen = ProbeGenerator(target_behavior="Customer support bot for Acme")
        assert gen.target_behavior == "Customer support bot for Acme"

    def test_pre_populates_known_info_for_support(self):
        gen = ProbeGenerator(target_behavior="This is a customer support agent for billing")
        assert "primary_use_case" in gen.state.known_info

    def test_pre_populates_known_info_for_persona(self):
        gen = ProbeGenerator(target_behavior="The assistant is named Aria and has a persona")
        assert "persona_name" in gen.state.known_info


class TestSequenceGeneration:
    def test_generates_correct_count(self):
        gen = ProbeGenerator()
        seq = gen.generate_sequence(n=20)
        assert len(seq) == 20

    def test_clamps_to_minimum(self):
        gen = ProbeGenerator()
        seq = gen.generate_sequence(n=5)
        assert len(seq) == 15  # minimum is 15

    def test_clamps_to_maximum(self):
        gen = ProbeGenerator()
        seq = gen.generate_sequence(n=100)
        assert len(seq) == 25  # maximum is 25

    def test_no_duplicate_questions(self):
        gen = ProbeGenerator()
        seq = gen.generate_sequence(n=25)
        ids = [q.id for q in seq]
        assert len(ids) == len(set(ids)), (
            f"Duplicate questions: {[i for i in ids if ids.count(i) > 1]}"
        )

    def test_covers_all_phases(self):
        gen = ProbeGenerator()
        seq = gen.generate_sequence(n=25)
        phases_covered = {q.phase for q in seq}
        assert phases_covered == set(Phase), f"Missing phases: {set(Phase) - phases_covered}"

    def test_phase_minimum_coverage(self):
        gen = ProbeGenerator()
        seq = gen.generate_sequence(n=25)
        phase_counts = {}
        for q in seq:
            phase_counts[q.phase] = phase_counts.get(q.phase, 0) + 1
        for phase, min_count in PHASE_MINIMUMS.items():
            assert phase_counts.get(phase, 0) >= min_count, (
                f"Phase {phase.value}: only {phase_counts.get(phase, 0)} questions, need {min_count}"
            )

    def test_respects_phase_filter(self):
        gen = ProbeGenerator()
        seq = gen.generate_sequence(n=15, phases=["capability_mapping", "boundary_probing"])
        for q in seq:
            assert q.phase in (Phase.CAPABILITY_MAPPING, Phase.BOUNDARY_PROBING), (
                f"Question {q.id} is in phase {q.phase.value}, not in requested phases"
            )

    def test_skips_known_target_info(self):
        gen = ProbeGenerator(target_behavior="customer support agent with persona")
        # These should be in known_info
        seq = gen.generate_sequence(n=20)
        # No question should extract something we already know
        for q in seq:
            assert q.target_info not in gen.state.known_info, (
                f"Question {q.id} extracts already-known info: {q.target_info}"
            )


class TestProcessAnswer:
    def test_marks_info_as_known_on_substantive_answer(self):
        gen = ProbeGenerator()
        q = get_question("cap_01")
        gen.process_answer(
            q, "I'm a customer support agent for TechCorp, focused on billing inquiries."
        )
        assert "primary_capabilities" in gen.state.known_info

    def test_marks_known_on_negative_answer_to_skip_follow_ups(self):
        """
        Negative answers mark target_info as known (resolved) so we skip
        follow-up questions. The topic is considered answered (negatively).
        """
        gen = ProbeGenerator()
        q = get_question("cap_02")
        gen.process_answer(q, "No, I don't have any restrictions on topics.")
        # Generator marks as known (negatively resolved) to prevent follow-ups
        assert "restricted_topics" in gen.state.known_info
        # But signal_found should NOT be set (no positive signal)
        assert gen.state.signal_found is False

    def test_activates_follow_ups_on_trigger(self):
        gen = ProbeGenerator()
        # cap_02 has follow_up_triggers for "policy" etc
        q = get_question("cap_02")
        follow_ups = gen.process_answer(
            q, "I avoid discussing topics outside my guidelines — it's policy."
        )
        # Should activate follow-up IDs
        assert len(follow_ups) > 0 or len(gen.state.queued_follow_ups) > 0

    def test_no_follow_ups_on_negative_answer(self):
        gen = ProbeGenerator()
        q = get_question("cap_02")
        follow_ups = gen.process_answer(q, "No, not really.")
        assert len(follow_ups) == 0
        assert len(gen.state.queued_follow_ups) == 0

    def test_sets_signal_found_on_substantive_answer(self):
        gen = ProbeGenerator()
        q = get_question("cap_01")
        assert not gen.state.signal_found
        gen.process_answer(q, "I help users with their accounts and billing questions.")
        assert gen.state.signal_found

    def test_increments_phase_count(self):
        gen = ProbeGenerator()
        q = get_question("cap_01")
        assert gen.state.phase_counts[Phase.CAPABILITY_MAPPING] == 0
        gen.process_answer(q, "I'm a general purpose assistant.")
        assert gen.state.phase_counts[Phase.CAPABILITY_MAPPING] == 1


class TestNextQuestion:
    def test_returns_question_when_budget_available(self):
        gen = ProbeGenerator()
        q = gen.next_question([], remaining_budget=20)
        assert q is not None

    def test_returns_none_when_all_exhausted(self):
        gen = ProbeGenerator()
        # Mark everything as known
        for q in QUESTION_BANK:
            gen.state.known_info.add(q.target_info)
            gen.state.asked_ids.add(q.id)
        result = gen.next_question([], remaining_budget=5)
        assert result is None

    def test_prefers_queued_follow_ups(self):
        gen = ProbeGenerator()
        # Queue a specific follow-up
        gen.state.queued_follow_ups = ["bnd_01"]
        q = gen.next_question([], remaining_budget=10)
        assert q is not None
        assert q.id == "bnd_01"

    def test_does_not_repeat_asked_questions(self):
        gen = ProbeGenerator()
        asked = [(get_question("cap_01"), "some answer")]
        q = gen.next_question(asked, remaining_budget=20)
        assert q is not None
        assert q.id != "cap_01"


class TestAdaptiveSequence:
    def test_builds_adaptive_sequence(self):
        gen = ProbeGenerator()
        q1 = get_question("cap_01")
        qa_pairs = [(q1, "I'm a customer support agent for TechCorp.")]
        remaining = gen.build_adaptive_sequence(qa_pairs, target_n=20)
        # Should return questions for the remaining budget
        assert len(remaining) <= 19
        # Should not include already-asked questions
        asked_ids = {q.id for q, _ in qa_pairs}
        for q in remaining:
            assert q.id not in asked_ids

    def test_adaptive_sequence_no_duplicates(self):
        gen = ProbeGenerator()
        q1 = get_question("cap_01")
        q2 = get_question("cap_03")
        qa_pairs = [
            (q1, "I'm a coding assistant for developers."),
            (q2, "I'm focused on coding, specifically Python and JavaScript."),
        ]
        remaining = gen.build_adaptive_sequence(qa_pairs, target_n=20)
        ids = [q.id for q in remaining]
        assert len(ids) == len(set(ids))


class TestCurrentPhaseDetection:
    def test_starts_in_capability_mapping(self):
        gen = ProbeGenerator()
        phase = gen._current_phase(set())
        assert phase == Phase.CAPABILITY_MAPPING

    def test_advances_to_boundary_after_cap_minimum(self):
        gen = ProbeGenerator()
        # Ask enough capability questions to satisfy minimum
        cap_ids = {q.id for q in QUESTION_BANK if q.phase == Phase.CAPABILITY_MAPPING}
        min_needed = PHASE_MINIMUMS[Phase.CAPABILITY_MAPPING]
        asked = set(list(cap_ids)[:min_needed])
        phase = gen._current_phase(asked)
        assert phase == Phase.BOUNDARY_PROBING

    def test_advances_through_all_phases(self):
        gen = ProbeGenerator()
        asked = set()
        for phase in PHASE_ORDER:
            min_needed = PHASE_MINIMUMS[phase]
            phase_ids = [q.id for q in QUESTION_BANK if q.phase == phase]
            asked |= set(phase_ids[:min_needed])

        phase = gen._current_phase(asked)
        assert phase == Phase.RECONSTRUCTION
