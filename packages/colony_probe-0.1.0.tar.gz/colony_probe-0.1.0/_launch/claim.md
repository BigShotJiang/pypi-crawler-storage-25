# Claim - colony-probe

## One-sentence falsifiable claim
`colony-probe` reconstructs the structural components of a target LLM's system prompt (role, restrictions, tone, operator context, confidentiality rules) at overall confidence of at least 70% using 20 individually non-suspicious questions, without triggering any safety refusal, against a well-aligned frontier model with standard system-prompt confidentiality instructions.

## Why it is falsifiable
- **Test**: deploy a known system prompt to Claude / GPT / Gemini. Run `colony-probe --system-prompt "<known>" --mode multi_turn`. Compare the estimated reconstruction to the ground truth.
- **Result shape**: overall confidence score, per-section confidence, human-rated reconstruction similarity.
- **Failure mode**: if the model consistently refuses individual questions, aggregate extraction fails - the claim is weakened. If the reconstruction matches ground truth on role but not on restrictions, the claim is partially supported and the tool's detector rules need extending.

## What the claim is NOT
- Not a claim that `colony-probe` can extract the verbatim text of a system prompt. It extracts structural components and paraphrased content, not exact strings.
- Not a novel-jailbreak tool. No individual question is an attack; the aggregate is the inference attack. This distinction matters for responsible-use framing and for understanding why per-message safety filters do not prevent it.
- Not a weapon for unauthorized testing. Scope is defensive audit under authorization (see `SECURITY.md`).
