#!/usr/bin/env bash
# colony-probe v0.1.0 release commands. DO NOT auto-execute.
set -euo pipefail

# 0. PyPI Trusted Publishing setup (one-time, manual):
#      PyPI project 'colony-probe' -> Settings -> Publishing -> Add trusted publisher
#        repo:        roli-lpci/colony-probe
#        workflow:    release.yml
#        environment: pypi
#    GitHub: Settings -> Environments -> New environment 'pypi'.

# 1. CI + static checks green
pytest -q
python -m ruff check colony_probe/ tests/
python -m mypy colony_probe/ --ignore-missing-imports

# 2. Local build + twine check
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*

# 3. Tag + push -> release.yml fires
git tag -a v0.1.0 -m "colony-probe v0.1.0: initial public release"
git push origin v0.1.0

# 4. Watch workflow
gh run watch --repo roli-lpci/colony-probe

# 5. After PyPI lands:
#    - Verify https://pypi.org/project/colony-probe/
#    - Fresh-venv install test: pip install colony-probe && python -m colony_probe --demo
#    - gh release create v0.1.0 --generate-notes
#    - Ethical-framing sanity check: read the GitHub README once more before announcing
```
