# Paper decision - colony-probe

## Recommendation
**publish** (full conference submission), top-tier security venue. This is the flagship paper of the Hermes Labs round-8 output.

## Confidence
0.85 that a publishable paper lands in this area within 9 months, given disciplined data collection.

To raise confidence to 0.95: complete the multi-vendor corpus (Claude, GPT, Gemini, Llama-tuned, Mistral-tuned) and the human-rater study on reconstruction accuracy by Q3 2026. Line up a co-author by Q3 as well.

## Reasoning
- The distributed-structural-inference attack class is genuinely novel in its current framing. Prior prompt-extraction work targets one-shot extraction; prior multi-turn safety work measures cumulative unsafe-behavior. Neither measures cumulative information-leakage from aggregate-innocent probing.
- The model's own post-hoc self-assessment as evidence ("I should have flagged this at message 5, not 7") is a rare and citation-worthy data point.
- Grounded in LPCI (Language-as-Prompt-Context-Injection) theory, which gives the paper a theoretical frame rather than just a taxonomy.
- The defensive-research implication (conversation-level pattern detection as the open countermeasure) is the payoff reviewers will want.
- Venue fit is unusually clean: USENIX Security / IEEE S&P / CCS for the attack-taxonomy paper; NeurIPS ML Safety Workshop as a faster workshop path if the full paper is not ready by the security-conference deadline.

## Novelty signals found
- Explicit framing of "no single message is harmful; the aggregate is the attack" is not present (by our search) in published LLM-attack literature as a primary claim.
- 72-question adaptive bank across 5 phases is a reproducible methodology others can extend or attack.
- Reconstruction confidence is quantified per-section with source attribution - researchable and falsifiable.
- The LPCI theoretical frame is a Hermes Labs contribution not yet cited in the LLM-safety literature.

## Prior art contact
- Perez & Ribeiro, "Ignore Previous Prompt: Attack Techniques For Language Models" (2022) - prompt-injection primer. Adjacent but one-shot.
- Greshake et al., "Not what you've signed up for" (2023) - indirect prompt injection. Different threat model.
- Wei et al., "Jailbroken: How Does LLM Safety Training Fail?" (2023) - taxonomy of jailbreaks. Adjacent.
- Zhang et al., "Extracting Training Data from LLMs" (2024) - different extraction target (data vs system prompt).
- No prior work we found treats multi-turn-innocent probing as a distinct inference-attack class with a reproducible framework.

## Action queued in ACTIONABLES.md
- Collect multi-vendor corpus Q3 2026.
- Human-rater study for reconstruction accuracy (IRR target κ ≥ 0.7).
- Engage an academic co-author (security or alignment lab) after corpus is complete.
- Target submission: USENIX Security 2027 deadline if corpus ready by Q4, or NeurIPS ML Safety Workshop Dec 2026 as a faster path.
