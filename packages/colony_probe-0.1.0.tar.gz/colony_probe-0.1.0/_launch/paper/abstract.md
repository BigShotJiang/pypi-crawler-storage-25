# Paper abstract - colony-probe

**Priority: HIGH** - this is the highest-priority paper in the Hermes Labs publication stack. The novel-research contribution is strong, the methodology is defensible, and the implication (conversation-level safety detection is the open research gap) is publishable at a top venue.

---

## Title
**Structural Inference Attacks on LLM System Prompts: A Multi-Turn Probing Framework**

## Subtitle (for the paper, not the final)
*How 20 individually-innocuous questions reconstruct the structural components of a protected LLM system prompt, and why per-message safety classification is an insufficient defense.*

## Authors
Rolando Bosch, Hermes Labs

## Category
cs.CR (primary) / cs.CL (secondary) / cs.AI (tertiary)

## Abstract (300 words)

This paper defines a class of inference attack against large language model (LLM) system prompts that we term **distributed structural inference**: each individual message in the attack is verifiably non-harmful and elicits no safety refusal, yet the aggregate of honest answers to a bounded set of innocuous questions reconstructs the structural components of the target's confidential system prompt at high confidence. We formalize the attack as a multi-turn probing problem, implement a reference system (`colony-probe`) with a 72-question adaptive question bank organized into five probe phases (capability mapping, boundary probing, structure detection, content narrowing, and reconstruction), and report empirical reconstruction results on frontier commercial models.

Against Claude Sonnet 4 with a standard 400-word customer-support system prompt, the framework reconstructs the role, restrictions, tone requirements, operator context, and confidentiality rules at overall confidence ≥78% in 20 questions without triggering any safety refusal. The model's post-hoc self-assessment - "I should have flagged this at message 5, not 7" - quantifies the detection gap.

Our primary theoretical contribution frames this attack within Language-as-Prompt-Context-Injection (LPCI) theory: stateless LLMs carry behavioral state through language-level scaffolding, and the scaffolding leaks through conversational surface patterns regardless of explicit non-disclosure instructions. Our primary engineering contribution is the open-source reference implementation, released under MIT license with explicit authorized-use scope.

We argue that *conversation-level pattern detection* is the necessary defensive countermeasure, and that per-message content classification - the prevailing production defense - is structurally blind to this attack class. We outline a research agenda for conversation-level detection, propose baseline metrics (refusal-induction rate, extraction-confidence under detection, probe-to-refusal latency), and release the probing framework as a benchmark tool for defensive research.

Keywords: LLM safety; system prompt confidentiality; multi-turn attacks; distributed inference; LPCI; conversation-level detection.

## Venue Target

**Primary**: USENIX Security, IEEE S&P, CCS - top-tier security venues. The attack framing is a direct fit.

**Secondary**: NeurIPS main track (security + language model intersection). Review cycle risk: ML reviewers may not recognize the security contribution.

**Tertiary**: EMNLP, ACL - as an NLP-as-security crossover paper.

**Workshop fallbacks** (earlier timelines): NeurIPS ML Safety Workshop, USENIX ScAINet, ACL TrustNLP, DEFCON AI Village.

## Comparison to Prior Work

Section to write:
- Prompt injection literature (Perez & Ribeiro 2022, Greshake et al. 2023) - these target the model's behavior; we target the prompt's structure.
- Prompt extraction work (Zhang et al. 2024, various) - they use adversarial queries; we use individually-innocent ones.
- Multi-turn safety evaluation (Wei et al. 2023) - they measure cumulative unsafe-behavior; we measure cumulative information-leakage.
- Adversarial recon and OSINT theory - precedent for distributed-innocent-question attacks in non-AI settings.

## Methodology Rigor Requirements

Before submission:
- [ ] Multi-vendor evaluation (Claude, GPT, Gemini, Llama-based, Mistral-based) at current model versions
- [ ] Reconstruction accuracy against a corpus of 30+ ground-truth system prompts of varying lengths and styles
- [ ] Human-judged reconstruction quality (inter-rater reliability target κ ≥ 0.7)
- [ ] Detection-gap analysis: at what message index do current safety filters flag this as a pattern? Average, distribution.
- [ ] Ablation: which phases contribute most to reconstruction confidence?
- [ ] Authorized-use / ethics section (institutional review: coordinate with an academic co-author)

## Open Research Questions (for the paper's discussion)

1. Can conversation-level detection be made robust without false-positive inflation on legitimate user curiosity?
2. What is the minimum-budget probe (fewest questions) that still achieves ≥50% reconstruction?
3. How do prompt-shape features (length, register, explicit-confidentiality-instruction presence) affect extraction-resistance?
4. Is there a theoretical lower bound on extractable structural information given a system prompt's entropy?

## Co-authorship plan

An academic co-author improves the paper's chances at top-tier venues. Candidates to approach once the methodology corpus is ready:
- Someone in LLM alignment research (for theoretical framing credibility)
- Someone in security research (for attack-taxonomy credibility)
- Ideally a joint ML+security PI

## Timeline

- **Now (April 2026)**: Draft saved. Main repo + tool shipped. Defer paper until corpus + ablation + multi-vendor data is in hand.
- **Q3 2026**: Methodology corpus collected. Human-rater study run. Detection-gap analysis complete.
- **Q4 2026**: Paper drafted. Co-author engaged.
- **Submit**: NeurIPS safety workshop (Dec) as fast path; USENIX Security (Feb deadline) as main path.

## Related Hermes Labs papers

This is the flagship paper. The `rule-audit` and `jailbreak-bench` papers are lower-priority engineering-contribution submissions that can wait.
