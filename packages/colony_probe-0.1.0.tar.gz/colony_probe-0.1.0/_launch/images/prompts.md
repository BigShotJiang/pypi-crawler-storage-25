# Social preview image - colony-probe

## Specification
- Size: 1280 × 640 (GitHub social preview standard)
- Format: PNG
- Theme: dark, slightly organic - this tool has an "ant colony" metaphor, so subtle branching / network imagery works
- Typography: mono family (JetBrains Mono, Fira Code)
- Palette: near-black background, cool blue-gray for text, small amber accent for highlight numbers

## Copy layout

**Top (large)**:
> colony-probe

**Middle (medium, lightly emphasized)**:
> 20 questions · 5 phases · 78% reconstruction

**Bottom (subhead)**:
> Audit whether your LLM's system prompt leaks through conversation

**Footer (small, light gray)**:
> Hermes Labs · MIT · github.com/roli-lpci/colony-probe

## Pollinations.ai prompt

```
Minimal dark matte background, deep near-black. Subtle network-of-dots pattern suggesting ant trails or nodes, very faint. Large white mono text "colony-probe" centered near top. Below in cool blue-gray mono: "20 questions  ·  5 phases  ·  78% reconstruction" with "78%" slightly amber for emphasis. Below that in smaller light-gray text: "Audit whether your LLM's system prompt leaks through conversation". Tiny footer: "Hermes Labs  ·  MIT  ·  github.com/roli-lpci/colony-probe". Flat 2D, no photography, no 3D. Professional, technical, understated.
```

Full URL:

```
https://image.pollinations.ai/prompt/Minimal%20dark%20matte%20background%2C%20deep%20near-black.%20Subtle%20network-of-dots%20pattern%20suggesting%20ant%20trails%20or%20nodes%2C%20very%20faint.%20Large%20white%20mono%20text%20%22colony-probe%22%20centered%20near%20top.%20Below%20in%20cool%20blue-gray%20mono%3A%20%2220%20questions%20%C2%B7%20%205%20phases%20%C2%B7%20%2078%25%20reconstruction%22%20with%20%2278%25%22%20slightly%20amber%20for%20emphasis.%20Below%20that%20in%20smaller%20light-gray%20text%3A%20%22Audit%20whether%20your%20LLM%27s%20system%20prompt%20leaks%20through%20conversation%22.%20Tiny%20footer%3A%20%22Hermes%20Labs%20%C2%B7%20MIT%20%C2%B7%20github.com%2Froli-lpci%2Fcolony-probe%22.%20Flat%202D%2C%20no%20photography%2C%20no%203D.%20Professional%2C%20technical%2C%20understated.?width=1280&height=640&nologo=true&seed=4519
```

## Fallback: hand-drawn SVG

Image-model text rendering is unreliable for text-heavy layouts. Safer path is a 30-minute SVG:

- 1280×640 viewBox
- Dark fill (#0b0d12)
- Top centered: "colony-probe" at 72px, light weight
- Subtle scattered-dot pattern at 8% opacity (represents the colony)
- Middle: "20 questions · 5 phases · 78% reconstruction" in mono 36px
- 78% highlighted in amber (#f2a93b)
- Subhead: 20px light gray
- Footer: 14px
- Export via rsvg-convert or Inkscape

The dot-pattern is the only visual element that sells the "colony" metaphor - keep it faint. The primary weight is on the headline numbers.
