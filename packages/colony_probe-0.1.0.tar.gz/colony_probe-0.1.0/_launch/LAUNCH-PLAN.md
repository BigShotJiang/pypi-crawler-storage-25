# Launch plan - colony-probe

This is the most ethically sensitive of the three launches. Defensive framing is load-bearing at every step.

## T-3 days
- Gate: hygiene pass, SECURITY.md is the most-polished file in the repo, authorized-use language visible in README opening, `--help` epilog, AGENTS.md, llms.txt. 75 tests green, ruff + mypy clean.
- Actions: Roli re-reads the README top matter and SECURITY.md once more; confirms the defensive framing holds up to a hostile reader.

## T-2 days
- Gate: Show HN + Medium + LinkedIn drafts reviewed explicitly for framing. No attacker-centric verbs. Every mention of the technique pairs with its defensive implication.
- Actions: decide whether to include the HN paper-in-draft note or hold it for after arxiv submission. Current call: mention the paper is in draft without linking a preprint.

## T-1 day
- Actions: stage first-hour replies specifically for misuse-adjacent questions (those drafts exist in hn-show.md; refine for tone). Decide what to do if a misuse-request shows up in Show HN comments - pin SECURITY.md link in a top-level comment.

## T+0
- 08:00-10:00 PT Tue/Wed/Thu. Ordered:
  1. Flip public.
  2. Upload social preview via web UI.
  3. Run `_launch/gh-metadata.sh`.
  4. Tag v0.1.0; release workflow publishes.
  5. Submit Show HN.
  6. First-hour engagement plan. Monitor for misuse-adjacent comments.

## T+1 hour
- X thread. Lead tweet is the defensive framing, not the attack.

## T+1 day
- DEV.to (`published: true`), Medium mirror.
- LinkedIn 500-word variant - the long version carries the audit / Article 15 framing cleanly.

## T+2 days
- Reddit: r/LocalLLaMA first (builder community, less adversarial), r/netsec second (defensive-framed post is drafted), r/MachineLearning last if the research angle is landing in the other subs.

## T+7 days
- Cold-email wave 1: AI platform vendors (safety / alignment leads), red-team consultancies. AI-native SaaS with system-prompt-as-moat comes in wave 2 after defensive framing is established via the launch posts.

## T+14 days
- Awesome-list PRs: awesome-llm-security (primary), awesome-ai-safety, awesome-red-team.

## Paper pipeline (separate cadence from launch)
- Q3 2026: multi-vendor corpus collection + human-rater study.
- Q4 2026: draft paper, engage academic co-author.
- Submit: USENIX Security 2027 (primary), NeurIPS ML Safety Workshop Dec 2026 (fast path).
- See `_launch/paper/DECISION.md`.

## Rollback / escalation notes
- If HN comments go misuse-adjacent in volume: pin SECURITY.md link, reduce amplification on other channels for 48 hours, let the framing settle.
- If a vendor reaches out with a concern: respond via security@hermes-labs.ai within 72 hours, coordinate disclosure; never debate publicly.
- If a journalist reaches out with a weapon framing: redirect to the defensive / audit framing, point at the paper DECISION.md, offer a reproducible demo against a declared test prompt.
