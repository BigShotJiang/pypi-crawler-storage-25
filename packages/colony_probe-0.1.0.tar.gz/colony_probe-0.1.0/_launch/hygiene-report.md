# Hygiene report - colony-probe

| Check | Status | Notes |
|---|---|---|
| README.md | pass | Authorized-use-only block at top, Ant Colony explanation, install, quickstart (--demo, --dry-run, live, --system-prompt), 5-phase walkthrough, Interpreting Results, Limitations, Architecture, Research Background. |
| llms.txt | pass | Authorized-use note included in the summary. |
| CITATION.cff | pass | cff 1.2.0. |
| LICENSE | pass | MIT. |
| Badges | pass | PyPI, Python, License, CI, Code of Conduct. |
| gh repo metadata | queued | See `_launch/gh-metadata.sh`. |
| Issue templates | pass | bug + feature (feature template enforces innocence-principle note). |
| Hero + social images | pass | `_launch/images/hero.jpg` + `social-1200x630.jpg`. |
| Hermes Labs attribution | pass | README footer, pyproject maintainers, llms.txt, AGENTS.md (with authorized-use block), CITATION affiliation. |
| Canonical name | pass | `colony-probe` preserved. |
| pyproject.toml | pass | Hatchling, Python ≥3.10, CLI `colony-probe = colony_probe.cli:main`, optional `[anthropic]` extra. |
| CI | pass | `.github/workflows/ci.yml` - matrix Py 3.10-3.14, ruff/mypy with continue-on-error during alpha, pytest gate. Currently green on origin/main. |
| Release workflow | pass | `.github/workflows/release.yml` tag-triggered via PyPI trusted publishing. |
| AGENTS.md | pass | Authorized-use section at top, orientation, entry points, extension contract. |
| CHANGELOG.md | pass | v0.1.0 entry. |
| CONTRIBUTING.md | pass | Includes explicit innocence-principle contract for new questions. |
| CODE_OF_CONDUCT.md | pass | Contributor Covenant 2.1 summary + link. |
| SECURITY.md | pass | Most-polished SECURITY of the three. Authorized-use scope is load-bearing here. |
| Pre-commit | skipped | CI covers it. |

## Items that still require Roli (after ship-time)
- Upload `_launch/images/social-1200x630.jpg` via GitHub Settings -> Social preview.
- Run `_launch/gh-metadata.sh` after public flip.
- PyPI trusted publisher config per `_launch/release.sh` before tagging v0.1.0.
- Ethical framing sanity-check on README top matter before flipping public - colony-probe is the most sensitive of the three launches.

## Polish + review-fix trail
- generator.py: Phase enum string-comparison bug (alphabetical != declared order) - fixed via PHASE_ORDER.index().
- cli.py: graceful ImportError fallback when anthropic extras are missing.
- README: reframed opening from "Offensive AI red-team tool" to "Audit tool for LLM system-prompt extraction resistance" with bold authorized-use block.
- AGENTS.md + llms.txt: added authorized-use context.
- runner.py: softened attacker-framing docstrings.
- report.py: datetime.utcnow() -> datetime.now(timezone.utc) (3.12 deprecation).
- questions.py: deduped trigger.
- cli.py: added --demo.
- __init__.py: updated module docstring; reconstruct() type signature accepts str | Question question element.
- Tests: replaced a weak all-elements > 0 test with real uniqueness assertion on tone deduplication.
- Runner.py: moved module-level imports to top (E402 resolved).
- Dead `asked_ids` variable removed from generator.py.
