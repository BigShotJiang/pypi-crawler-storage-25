# SHIP-REPORT - colony-probe

Pre-ship gate: **10/10 PASS**. No waivers.

## What landed in this repo
- Code + tests: 75 passing, ruff clean, mypy clean (fixed Phase enum string-comparison correctness bug, E402 imports, mypy type-signature on `reconstruct`).
- CLI: `python -m colony_probe --help` / `--dry-run` / `--demo` / `--list-phases` / `--list-questions` / `--system-prompt` all working. Graceful ImportError fallback when `anthropic` extras absent.
- Repo hygiene: README with authorized-use block at top, SPEC, ROADMAP, CLAUDE.md, AGENTS.md (with authorized-use section), llms.txt, CHANGELOG, CONTRIBUTING (with innocence-principle contract), CODE_OF_CONDUCT, SECURITY.md (scope contract - most polished file), CITATION.cff, LICENSE (MIT).
- CI + release: `.github/workflows/{ci.yml,release.yml}` (Py 3.10-3.14 matrix, ruff/mypy continue-on-error during alpha, pytest gate; release via PyPI Trusted Publishing on tag).
- Launch bundle: `_launch/` complete. Every piece defensively framed per MIRROR-ethics memory. Cold-email list (in `launch/cold-email-targets.md`, gitignored) includes the MIRROR-ethics gate applied before any draft_batch send.
- Manifest at `~/ai-infra/manifests/colony-probe.yaml`; `find_tool.py "colony-probe"` returns at rank 1.

## Roli's remaining steps (ordered - this is the sensitive one, read twice)
1. **Read `README.md` top matter + SECURITY.md once more before flipping public.** This is the ethically sensitive launch of the three; framing is load-bearing.
2. Read `_launch/outreach/hn-show.md` and the first-hour responses carefully - misuse-adjacent questions are predictable and the drafted responses need to hold up.
3. PyPI Trusted Publishing setup per `_launch/release.sh`.
4. Flip public: `gh repo edit roli-lpci/colony-probe --visibility public --accept-visibility-change-consequences`.
5. Upload social preview via web UI.
6. `bash _launch/gh-metadata.sh` after public flip.
7. `bash _launch/release.sh` to tag v0.1.0.
8. Submit Show HN 08:00-10:00 PT, the last of the three launches (stagger by 24h from the other two). Pin SECURITY.md link in a top-level HN comment if any misuse-adjacent question appears.
9. X thread 1-2 hours later. LinkedIn 500-word variant next day. Reddit r/LocalLLaMA first, r/netsec second, r/MachineLearning third only if the other two landed well.

## Paper decision
**publish** - flagship paper of the round-8 output. Target: USENIX Security 2027 (primary) or NeurIPS ML Safety Workshop Dec 2026 (fast path). Confidence 0.85. See `_launch/paper/DECISION.md` for the research plan.

## Gates Roli should reconsider (none waived)
- Pre-commit skipped.
- Cold-email email-targets.csv not populated (the target list file is in `launch/cold-email-targets.md` and gitignored). Queue wave 1 for T+7 per LAUNCH-PLAN. **Enforce the MIRROR-ethics gate before any batch send** - the gate section is in the cold-email-targets file.
