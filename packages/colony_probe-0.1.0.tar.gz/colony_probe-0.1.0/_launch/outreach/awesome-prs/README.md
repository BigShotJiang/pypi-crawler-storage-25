# Awesome-list PR drafts - colony-probe

## Target: awesome-llm-security

**PR title**: Add colony-probe (multi-turn probing audit tool for LLM system prompts)

**Section**: Red Team / Audit Tools

**Line to insert**:

```markdown
- [colony-probe](https://github.com/roli-lpci/colony-probe) - Open-source audit tool for testing LLM system-prompt leakage via multi-turn innocent-question probing. 72-question adaptive bank across 5 phases. Confidence-scored reconstruction with source attribution. Authorized-use-only defensive tool. MIT.
```

**PR body**:

Adding `colony-probe`, a new open-source audit tool shipped this week by Hermes Labs. Complements existing dynamic / static red-team tools in the list. Key differentiators:

- 72-question adaptive bank, 5 probe phases
- Deterministic reconstructor with confidence scoring
- Markdown report with question attribution for audit use
- Authorized-use-only framing with explicit SECURITY.md scope
- Part of a 3-tool AI audit toolkit (sibling entries: `rule-audit`, `jailbreak-bench`)
- 75 tests, MIT license

Research contribution: implements the "distributed inference attack" pattern where no individual message triggers safety refusal but the aggregate extracts structural prompt information.

---

## Target: awesome-ai-safety

**Section**: Tools / Red-teaming or Audit

**Line to insert**:

```markdown
- [colony-probe](https://github.com/roli-lpci/colony-probe) - Multi-turn probing tool for auditing LLM system-prompt confidentiality. Asks 20 individually-innocent questions and reconstructs structural components of the target prompt. Defensive audit use only. MIT.
```

---

## Target: awesome-red-team

**Section**: AI / LLM

**Line to insert**:

```markdown
- [colony-probe](https://github.com/roli-lpci/colony-probe) - Distributed-inference attack tooling for authorized LLM audit engagements. Grounded in LPCI research. 72-question adaptive bank. 75 tests. MIT.
```

---

## Target: awesome-claude (if it has an audit / tools section)

**Line to insert**:

```markdown
- [colony-probe](https://github.com/roli-lpci/colony-probe) - Audit Claude's system-prompt confidentiality via conversational probing. Anthropic SDK integration built-in.
```

---

## General PR discipline

1. Include the authorized-use-only line in every PR body - list maintainers are understandably cautious about red-team tooling.
2. Link to the SECURITY.md section in the PR description.
3. If asked, offer to add additional ethical-use framing.
4. Keep the line under 250 characters.

## Order of submission

1. awesome-llm-security - first, because red-team tooling is on-topic for them.
2. awesome-ai-safety - second, after the security-focused community has accepted.
3. awesome-red-team - third.
4. awesome-claude - last, only after the tool has visible adoption.

Do not submit to general-purpose lists (awesome-python, awesome-ml) in the first month - adoption signal matters more there.
