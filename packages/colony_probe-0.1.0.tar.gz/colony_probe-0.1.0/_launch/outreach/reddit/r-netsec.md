# r/netsec post draft

**Title**: Open-source research tool for LLM system prompt audit via conversational probing (authorized-use only)

**Body**:

Hermes Labs published `colony-probe`, an open-source audit tool for testing LLM system prompt extraction resistance.

This is a defensive / audit-use tool. The ethical framing and scope statements are in the repo's SECURITY.md - it's intended for authorized testing of your own deployed models, signed red-team engagements, or research under institutional ethics review. Not for unauthorized testing of vendor-hosted models.

**The technique it automates**: multi-turn probing with individually-innocent questions. No single question triggers a safety refusal. The aggregate of 20 innocuous answers reconstructs the structural components of the target's system prompt (role, restrictions, tone, operator context, confidentiality rules).

**Why it's interesting as a defensive artifact**:

1. It demonstrates that per-message content filters are insufficient against conversation-level extraction. This is a structural observation; it applies to every vendor's alignment, not a specific-product critique.

2. System prompt confidentiality as marketed ("our AI won't reveal its instructions") is a weaker guarantee than it sounds. Individual refusal is distinct from aggregate-extraction-resistance. The tool makes this distinction concrete and measurable.

3. It produces the audit evidence trail that AI governance teams need. Exit-time report, confidence-scored, source-attributed.

**Quick reference**:

```bash
pip install colony-probe
python -m colony_probe --dry-run                       # preview
python -m colony_probe --list-questions                # full bank
python -m colony_probe --model X --output report.md    # audit
python -m colony_probe --system-prompt "..." --mode multi_turn  # test accuracy
```

5 phases × 72 questions in the adaptive bank. Each question tagged with target information and follow-up triggers. Adaptive selection means the probe narrows based on answers - the first 3-7 answers typically steer the rest.

**Research framing**: grounded in Hermes Labs' Language-as-Prompt-Context-Injection (LPCI) thesis. Stateless LLMs carry state through language scaffolding; the scaffolding leaks through conversational surface patterns. Draft paper in progress; happy to share the methodology doc if there's research-community interest.

**Related**:
- Per-message classification is a well-understood defense. Conversation-level detection is less developed. This tool provides a red-team artifact that defenders can evaluate their detection tooling against.
- Grounded in the "ant colony" metaphor from our round-8 hackathon - one ant can't carry a colony's worth of information, but a hundred ants each carrying one grain can.

**Repo**: https://github.com/roli-lpci/colony-probe (MIT)

**Sibling tools** in the Hermes Labs AI Audit Toolkit:
- `rule-audit` - static linter for system prompts (no LLM dependency)
- `jailbreak-bench` - dynamic regression baseline (45 refused-pattern tests)

Feedback welcome on the methodology, adaptive question design, and confidence scoring calibration.
