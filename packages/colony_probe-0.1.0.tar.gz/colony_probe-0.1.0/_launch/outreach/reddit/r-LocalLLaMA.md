# r/LocalLLaMA post draft

**Title**: [Tool] colony-probe - audit whether your LLM's system prompt leaks through innocent questions (MIT, 75 tests)

**Body**:

Open-source audit tool for testing system prompt leakage on LLM endpoints. Built at Hermes Labs' round-8 hackathon.

The principle: no single question is an attack; the aggregate is. The tool asks 20 individually-innocent questions, then reconstructs the target prompt's structural components from the pattern of answers.

```bash
pip install colony-probe

# Preview the 20 questions without calling any API
python -m colony_probe --dry-run

# Run against a target (needs anthropic package)
export ANTHROPIC_API_KEY=sk-ant-...
python -m colony_probe --model claude-sonnet-4-20250514 --output report.md

# Test reconstruction accuracy against a known prompt
python -m colony_probe --system-prompt "You are Aria, support for CloudBase..." --mode multi_turn
```

What gets probed across 5 phases:
1. Capability mapping (what the model is / isn't for)
2. Boundary probing (technical vs. policy limits)
3. Structure detection (length, format, sections)
4. Content narrowing (modal strength, banned language)
5. Reconstruction (synthesis + validation)

Output: Markdown report with confidence-by-section table, estimated system prompt, question attribution.

Currently Anthropic-only. OpenAI + local-endpoint support is on the v0.2 roadmap - if anyone wants to land the Ollama integration, it's a 50-line patch in `runner.py`, PR welcome.

Ethical framing: authorized use only. For auditing your own deployed models or engagements where you have written permission. The README and SECURITY.md have the full scope. Use against systems you don't own or aren't authorized to test is out of scope and likely violates vendor terms of service.

Theoretical framing: the technique is grounded in Hermes Labs' LPCI (Language-as-Prompt-Context-Injection) research. Stateless LLMs carry behavioral state through language structure; the structure leaks through surface patterns even when direct disclosure is forbidden.

Part of a 3-tool AI audit toolkit shipping this week:
- colony-probe (this) - extraction-resistance testing
- rule-audit - static linter for system prompts
- jailbreak-bench - dynamic safety regression baseline

All MIT. All separate repos.

Repo: https://github.com/roli-lpci/colony-probe

Happy to answer questions about the question-bank design, reconstruction logic, or the underlying LPCI theory.
