#!/usr/bin/env bash
# Set colony-probe GitHub repo metadata. Run ONCE after the repo is public.

gh repo edit roli-lpci/colony-probe \
  --description "Audit LLM system-prompt extraction resistance via 20 innocent questions. Ant Colony attack. Authorized-use only. Hermes Labs." \
  --homepage "https://hermes-labs.ai" \
  --add-topic llm \
  --add-topic llm-security \
  --add-topic red-team \
  --add-topic system-prompt \
  --add-topic audit \
  --add-topic extraction-resistance \
  --add-topic anthropic \
  --add-topic hermes-labs \
  --add-topic lpci \
  --add-topic ant-colony
