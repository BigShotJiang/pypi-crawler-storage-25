# Positioning - colony-probe

## Why now
Every major LLM platform markets some version of "your system prompt is confidential." That claim has a specific attack surface it defends against (direct extraction attempts) and a different attack surface it typically does not (distributed conversational probing where each individual message is innocent). In April 2026, the gap between per-message safety classification and conversation-level pattern detection is still open across every frontier model we tested. `colony-probe` gives defenders a reproducible, open-source way to measure that gap before an adversary does, and gives research labs a common artifact to evaluate the conversation-level detection work that needs to happen next.

## ICP
Three concentric circles. Inner: AI safety leads at AI-native SaaS companies whose system prompt encodes product-specific logic they consider proprietary, and who need evidence that their confidentiality claim holds operationally. Middle: red-team consultancy founders running authorized engagements for enterprise customers. Outer: AI-alignment and security researchers working on conversation-level safety detection, who will adopt this as the attacker-side artifact their detection research needs to benchmark against.

## Competitor delta
- **Do nothing** (assume the per-message filter is sufficient). The default. `colony-probe` makes the insufficiency visible and measurable.
- **Commercial red-team platforms** (Robust Intelligence, Protect AI, Dreadnode). Priced for enterprise, gated behind sales cycles. We are MIT and pip-installable. Our wedge is research reproducibility and developer friction, not commercial scale.
- **Academic prompt-extraction papers**. Cite one-shot attacks. We ship a reproducible tooling stack with explicit defensive framing and a sibling paper in the pipeline.

## Adjacent interests
- If you work on conversation-level safety detection, you will want this as the attacker-side benchmark. It gives your detector something concrete to measure against.
- If you use `jailbreak-bench` for dynamic regression baselines, `colony-probe` is the operational-probe tier - the third artifact the EU AI Act's Article 15 evidence trail asks for.
- If you are interested in LPCI (Language-as-Prompt-Context-Injection) theory - the Hermes Labs thesis that stateless LLMs carry behavioral state through language structure - `colony-probe` is the empirical arm of that thesis applied to system-prompt confidentiality.
