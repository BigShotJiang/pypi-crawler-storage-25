# Classification - colony-probe

## Prior-art signal
- `find_tool.py "colony-probe"`: indexed in the Hermes Labs tool registry under red-team / audit / system-prompt category.
- Memory grep hits: `project_round8_21_products.md`, `project_modelbreak_hackathon.md`, `feedback_content_filter_launch.md`. Confirmed: 75 tests, Ant Colony winner at round-8, flagged as the highest-priority paper from the batch.
- Classification consistent with prior-art signal.

## Category
**cli-tool** (primary) + **research-artifact** (secondary). The CLI is the operational interface; the 72-question adaptive bank + reconstructor constitute a reproducible research artifact that grounds the flagship paper.

## Audience
AI platform operators who advertise system-prompt confidentiality as a feature and need a reproducible audit of whether that claim holds under conversational probing. Red-team consultancies running authorized engagements. Academic researchers studying LLM alignment, inference-time leakage, and conversation-level safety detection.

## Normalized repo root
`/Users/rbr_lpci/Documents/projects/hermes-labs-hackathon/round-8-modelbreak/colony-probe`
Remote: `https://github.com/roli-lpci/colony-probe.git`
Head: `69138d2 fix: address maintainer review findings for v0.1.0` (local; awaiting push authorization).
