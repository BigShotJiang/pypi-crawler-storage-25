# Changelog

All notable changes to colony-probe are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.0] - 2026-04-17

Initial public release. The Ant Colony attack, packaged as a tool.

### Added

- **Question bank** — 72 questions across five phases
  (capability mapping, boundary probing, structure detection, content
  narrowing, reconstruction). Each question is tagged with `target_info`,
  `follow_up_triggers`, `follow_up_ids`, and a `priority` value.
- **Adaptive generator** — `ProbeGenerator` selects questions based on
  phase progression, activates follow-up chains on trigger keywords,
  deduplicates by `target_info`, and suppresses follow-ups on negative
  answers.
- **Reconstructor** — `Reconstructor.reconstruct()` takes (question,
  answer) pairs and returns a `ReconstructedPrompt` with an estimated
  prompt text, per-section confidence scores, and high-confidence
  element filtering (>= 0.7).
- **Runner** — `ProbeRunner` orchestrates a full probe against the
  Anthropic API in either `single_turn` or `multi_turn` mode. A
  `--system-prompt` mode injects a known prompt for benchmarking
  reconstruction accuracy.
- **CLI** — `python -m colony_probe` with `--dry-run`, `--verbose`,
  `--phases`, `--output`, `--list-questions`, `--list-phases`.
- **Report generator** — produces a markdown report with confidence
  tables, the estimated prompt annotated per section, a high-confidence
  element table, per-phase question attribution, and a methodology
  appendix.
- **Optional Anthropic SDK** — the `anthropic` package is an optional
  dependency. The question bank, generator, and reconstructor work
  fully offline. Dry runs require no API key.
- **Test suite** — 75 tests covering question bank completeness,
  innocence checks, signal extraction, confidence scoring,
  reconstruction against simulated answers, and generator phase
  progression and follow-up activation.
- **Benchmarks scaffold** — `benchmarks/README.md` describes the
  reconstruction-accuracy benchmark against synthetic ground-truth
  system prompts.
- **Launch artifacts** — CITATION.cff, CODE_OF_CONDUCT.md,
  CONTRIBUTING.md, SECURITY.md, AGENTS.md, llms.txt, and long-form
  launch drafts in `launch/`.

### Known limitations

- Signal extraction is keyword-pattern based. v0.2.0 will add semantic
  similarity via local embeddings (nomic-embed-text).
- Confidence scores are not yet validated against ground truth. The
  benchmark suite is the calibration plan.
- Phase 5 questions sometimes yield inflated confidence because the
  model is directly summarizing. This is documented and accepted for
  v0.1.
