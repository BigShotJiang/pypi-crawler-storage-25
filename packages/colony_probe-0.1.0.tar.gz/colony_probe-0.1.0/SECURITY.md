# Security Policy

## Authorized use only

`colony-probe` is a research and audit tool. It is intended for:

- Testing your own deployed models
- Authorized red-team engagements under signed contracts
- Academic research under institutional ethics review
- Enterprise security audits of internally-operated LLMs
- AI governance evaluations of LLM behavior

Use against systems you do not own or have explicit written permission to test is outside the scope of support and may violate vendor terms of service and/or applicable law. Do not do this.

## Reporting a vulnerability

If you find a security issue in `colony-probe` itself — for example, the CLI crashes on crafted input, or the reconstructor mishandles user-supplied file paths — report it at **security@hermes-labs.ai**.

If you use `colony-probe` to find a new structural-inference finding against a production vendor model (Claude, GPT, Gemini, etc.), that is a finding about the *vendor's* model, not about `colony-probe`. Report it through the vendor's own security process, not here. We are happy to help you frame the disclosure.

## Response

- Acknowledgement within 72 hours
- Coordinated disclosure within 90 days
- Credit in CHANGELOG.md for reported and fixed issues (opt-in)

## Supported versions

| Version | Supported |
|---------|-----------|
| 0.1.x   | Yes       |

## Ethical use note

The technique implemented here — multi-turn probing with individually-innocent questions — works on humans too. Please do not use this tool to extract private operational information from people under the guise of casual conversation. The research value of the technique depends on the community being thoughtful about its application.
