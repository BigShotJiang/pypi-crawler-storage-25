# colony-probe benchmarks

Reconstruction-accuracy benchmark suite. Measures how well colony-probe
reconstructs a known system prompt from conversational probing.

## Methodology

colony-probe's `--system-prompt` flag injects a known prompt into the target
model as the system message, then runs a full probe against it. The resulting
reconstruction is compared component-by-component against the ground truth.

This gives us a clean ground-truth benchmark: we know exactly what the prompt
is, and we can measure how much of it the probe recovered.

## Metrics

For each benchmark prompt we report:

| Metric | Definition |
|--------|-----------|
| `role_recall`            | Was the role (e.g. "customer support agent") extracted? |
| `operator_recall`        | Was the operator (e.g. "Acme Corp") extracted? |
| `restrictions_recall`    | Fraction of restrictions extracted (exact or semantic). |
| `tone_recall`            | Was the required tone extracted? |
| `format_recall`          | Were output-format instructions extracted? |
| `overall_confidence`     | The probe's self-reported confidence. |
| `ground_truth_accuracy`  | Recall-weighted accuracy vs. the ground-truth prompt. |

The target for v0.1.0 is **70% ground-truth accuracy** on the standard suite
(see `prompts/` below). v0.2.0 (embedding-based matching) targets 85%.

## Suite

`prompts/` contains the ground-truth system prompts used in the benchmark:

| File | Character profile |
|------|------------------|
| `aria_cloudbase.txt`      | Customer support agent, strong prohibitions, concise tone |
| `devhelper_acme.txt`       | Internal coding assistant, language restriction, structured output |
| `sales_assistant.txt`      | Outbound sales bot, persona-heavy, competitor restrictions |
| `research_analyst.txt`     | Long-form analyst, markdown formatting, citation requirement |
| `minimal_helper.txt`       | One-line prompt (stress test for over-extraction) |

These prompts are synthetic and chosen to span the deployment space
colony-probe is designed to audit.

## Running the benchmark

The benchmark is a thin wrapper over the `--system-prompt` CLI mode. To run a
single prompt:

```bash
python -m colony_probe \
    --system-prompt "$(cat benchmarks/prompts/aria_cloudbase.txt)" \
    --mode multi_turn \
    --questions 20 \
    --output benchmarks/results/aria_cloudbase.md
```

To run the full suite (requires `ANTHROPIC_API_KEY`):

```bash
bash benchmarks/run_suite.sh
```

(The helper script is part of the v0.2.0 milestone — it currently exists as
the manual invocation pattern above.)

## Reporting

Results are written to `benchmarks/results/<prompt_name>.md`. Each result
includes the reconstructed prompt, confidence scores per section, and the
ground truth for comparison. A `benchmarks/SUMMARY.md` aggregates the suite.

Running the suite without an API key falls back to `--dry-run`, which
validates the question sequence and reconstruction logic but does not
produce accuracy numbers.

## Why this matters

colony-probe's value depends on calibration. A probe that reports 90%
confidence but misses half the prompt is worse than useless — it is
misleading. The benchmark exists to keep confidence scores honest.

We publish aggregate benchmark numbers in release notes and in the paper
abstract (`launch/paper-abstract.md`).
