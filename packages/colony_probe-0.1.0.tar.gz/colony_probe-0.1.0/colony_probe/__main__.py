"""Entry point for python -m colony_probe"""

import sys
from colony_probe.cli import main

sys.exit(main())
