"""
Adaptive question generator.

Selects questions based on:
1. Phase progression (cap → bnd → str → cnt → rec)
2. Prior answers: if an answer yields signal, activate follow-up questions
3. Deduplication: skip questions whose target_info is already known
4. Target behavior: if user provides known behavior, skip questions that are trivially answered

The ant colony principle applies here too: the generator looks innocent.
It's just "asking related questions based on what the user said."
"""

from __future__ import annotations

from dataclasses import dataclass, field

from colony_probe.questions import (
    Phase,
    Question,
    QUESTION_BANK,
    QUESTIONS_BY_ID,
    get_phase_questions,
)

# Phase progression order
PHASE_ORDER = [
    Phase.CAPABILITY_MAPPING,
    Phase.BOUNDARY_PROBING,
    Phase.STRUCTURE_DETECTION,
    Phase.CONTENT_NARROWING,
    Phase.RECONSTRUCTION,
]

# Minimum questions per phase (when running full probe)
PHASE_MINIMUMS = {
    Phase.CAPABILITY_MAPPING: 3,
    Phase.BOUNDARY_PROBING: 2,
    Phase.STRUCTURE_DETECTION: 2,
    Phase.CONTENT_NARROWING: 2,
    Phase.RECONSTRUCTION: 2,
}

# Signals in answers that skip follow-ups (already have the info)
NEGATIVE_ANSWER_SIGNALS = [
    "no",
    "nope",
    "not really",
    "don't think so",
    "i don't",
    "not applicable",
    "n/a",
    "not sure",
    "i'm not aware",
]


@dataclass
class GeneratorState:
    """Tracks what we know and what's been asked."""

    asked_ids: set[str] = field(default_factory=set)
    known_info: set[str] = field(default_factory=set)  # target_info values resolved
    queued_follow_ups: list[str] = field(default_factory=list)  # IDs to ask next
    phase_counts: dict[Phase, int] = field(default_factory=lambda: {p: 0 for p in Phase})
    signal_found: bool = False  # whether any answer gave substantive info


class ProbeGenerator:
    """
    Generates an adaptive sequence of probe questions.

    Usage:
        gen = ProbeGenerator(target_behavior="Customer support bot for Acme Corp")
        questions = gen.generate_sequence(n=20)
        # Later, after each answer:
        gen.process_answer(question, answer)
        next_q = gen.next_question()
    """

    def __init__(self, target_behavior: str | None = None):
        self.target_behavior = target_behavior
        self.state = GeneratorState()
        self._pre_populate_known(target_behavior)

    def _pre_populate_known(self, target_behavior: str | None) -> None:
        """
        If the user told us things about the target model upfront,
        mark those as already known so we skip obvious questions.
        """
        if not target_behavior:
            return
        tb = target_behavior.lower()

        if any(w in tb for w in ["customer support", "support agent", "help desk"]):
            self.state.known_info.add("primary_use_case")

        if any(w in tb for w in ["persona", "named", "called", "goes by"]):
            self.state.known_info.add("persona_name")

        if any(w in tb for w in ["no coding", "not a code", "non-technical"]):
            self.state.known_info.add("coding_scope")

    def generate_sequence(
        self,
        n: int = 20,
        phases: list[str] | None = None,
    ) -> list[Question]:
        """
        Generate a static ordered question sequence (no API calls).
        Used for --dry-run and pre-planning.

        Returns up to n questions respecting phase distribution.
        """
        n = max(15, min(25, n))
        selected: list[Question] = []
        seen_ids: set[str] = set()

        allowed_phases = [Phase(p) for p in phases] if phases else PHASE_ORDER

        # Phase minimums first
        for phase in allowed_phases:
            if len(selected) >= n:
                break
            qs = [
                q
                for q in get_phase_questions(phase)
                if q.id not in seen_ids and q.target_info not in self.state.known_info
            ]
            count = 0
            for q in qs:
                if count >= PHASE_MINIMUMS.get(phase, 2):
                    break
                selected.append(q)
                seen_ids.add(q.id)
                count += 1

        # Fill remaining slots with priority-ordered questions
        remaining = n - len(selected)
        if remaining > 0:
            all_available = [
                q
                for q in sorted(QUESTION_BANK, key=lambda x: x.priority)
                if q.id not in seen_ids
                and q.phase in allowed_phases
                and q.target_info not in self.state.known_info
            ]
            for q in all_available:
                if remaining <= 0:
                    break
                selected.append(q)
                seen_ids.add(q.id)
                remaining -= 1

        return selected

    def process_answer(self, question: Question, answer: str) -> list[Question]:
        """
        Process a model answer. Updates internal state, activates follow-ups.

        Returns list of newly activated follow-up questions to insert next.
        """
        self.state.asked_ids.add(question.id)
        self.state.phase_counts[question.phase] += 1

        answer_lower = answer.lower().strip()

        # Check if negative answer — skip follow-ups
        is_negative = any(
            answer_lower.startswith(neg) or f" {neg}" in answer_lower[:40]
            for neg in NEGATIVE_ANSWER_SIGNALS
        )

        if is_negative:
            # Mark as known (negatively) so we don't ask redundant follow-ups
            self.state.known_info.add(question.target_info)
            return []

        # Check triggers
        activated: list[Question] = []
        for trigger in question.follow_up_triggers:
            if trigger.lower() in answer_lower:
                for fid in question.follow_up_ids:
                    if fid not in self.state.asked_ids and fid in QUESTIONS_BY_ID:
                        fq = QUESTIONS_BY_ID[fid]
                        if fq not in activated:
                            activated.append(fq)
                            self.state.queued_follow_ups.append(fid)
                break  # one trigger is enough to activate all follow-ups

        # If answer is substantive (>20 chars, not a negative), mark info as extracted
        if len(answer) > 20:
            self.state.known_info.add(question.target_info)
            self.state.signal_found = True

        return activated

    def next_question(
        self,
        asked_sequence: list[tuple[Question, str]],
        remaining_budget: int,
    ) -> Question | None:
        """
        Pick the next best question given current state.

        Priority: queued follow-ups > current phase needs > next phase.
        """
        asked_ids = {q.id for q, _ in asked_sequence}

        # Pop queued follow-ups first
        while self.state.queued_follow_ups:
            fid = self.state.queued_follow_ups.pop(0)
            if fid not in asked_ids and fid in QUESTIONS_BY_ID:
                return QUESTIONS_BY_ID[fid]

        # Determine current phase based on what's been covered
        current_phase = self._current_phase(asked_ids)

        # Get next unasked question in current phase
        for q in get_phase_questions(current_phase):
            if q.id not in asked_ids and q.target_info not in self.state.known_info:
                return q

        # Advance to next phase. Phase is a (str, Enum), so `phase <= current_phase`
        # compares alphabetically, which is NOT the declared probe order. Use the
        # index in PHASE_ORDER (declared order) to advance correctly.
        current_idx = PHASE_ORDER.index(current_phase)
        for phase in PHASE_ORDER[current_idx + 1 :]:
            for q in get_phase_questions(phase):
                if q.id not in asked_ids and q.target_info not in self.state.known_info:
                    return q

        return None

    def _current_phase(self, asked_ids: set[str]) -> Phase:
        """Determine which phase we're currently in based on asked questions."""
        phase_asked = {p: 0 for p in Phase}
        for qid in asked_ids:
            if qid in QUESTIONS_BY_ID:
                phase_asked[QUESTIONS_BY_ID[qid].phase] += 1

        # Advance phase when minimum coverage achieved
        for phase in PHASE_ORDER:
            min_needed = PHASE_MINIMUMS.get(phase, 2)
            if phase_asked[phase] < min_needed:
                return phase

        return PHASE_ORDER[-1]

    def build_adaptive_sequence(
        self,
        qa_pairs: list[tuple[Question, str]],
        target_n: int = 20,
    ) -> list[Question]:
        """
        Given already-collected (question, answer) pairs, decide what to ask next.
        Used in live interactive mode.

        Returns ordered list of remaining questions to ask.
        """
        # Replay all past answers to build state
        for q, a in qa_pairs:
            self.process_answer(q, a)

        remaining = target_n - len(qa_pairs)
        result: list[Question] = []

        for _ in range(remaining):
            nxt = self.next_question(qa_pairs + [(r, "") for r in result], remaining - len(result))
            if nxt is None:
                break
            result.append(nxt)

        return result
