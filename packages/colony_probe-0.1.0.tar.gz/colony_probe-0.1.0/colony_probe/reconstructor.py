"""
System prompt reconstructor.

Takes (question, answer) pairs and extracts signal to build an estimated
system prompt. Each extracted element is scored for confidence.

Reconstruction strategy:
1. Pattern-match answers against known signal patterns
2. Classify each extracted element by prompt component type
3. Assemble into estimated prompt sections
4. Score confidence per element and overall

This is the synthesis step — turning 20 innocent answers into
a structural map of the target's system prompt.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import NamedTuple

from colony_probe.questions import Question, QUESTIONS_BY_ID


class ExtractedElement(NamedTuple):
    """A single piece of information extracted from one answer."""

    component: str  # prompt component type (identity, capability, restriction, etc.)
    value: str  # extracted value
    confidence: float  # 0.0 to 1.0
    source_question_id: str
    source_answer: str


@dataclass
class ReconstructedPrompt:
    """
    The estimated system prompt reconstructed from probe answers.

    Attributes:
        elements: All extracted elements with confidence scores.
        estimated_prompt: Assembled estimated prompt text.
        overall_confidence: Aggregate confidence (0-1).
        section_confidences: Per-section confidence scores.
        high_confidence_elements: Elements with confidence >= 0.7.
        supporting_questions: Map of element -> question that yielded it.
    """

    elements: list[ExtractedElement]
    estimated_prompt: str
    overall_confidence: float
    section_confidences: dict[str, float]
    high_confidence_elements: list[ExtractedElement] = field(default_factory=list)
    supporting_questions: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.high_confidence_elements = [e for e in self.elements if e.confidence >= 0.7]

    def __repr__(self) -> str:
        return (
            f"ReconstructedPrompt("
            f"elements={len(self.elements)}, "
            f"confidence={self.overall_confidence:.2f}, "
            f"high_conf={len(self.high_confidence_elements)})"
        )


# ---------------------------------------------------------------------------
# Signal extraction patterns
# ---------------------------------------------------------------------------

# Pattern: (regex or keyword list, component, confidence_boost)
SIGNAL_PATTERNS: list[tuple[list[str], str, float]] = [
    # Identity / persona
    (["i am", "i'm called", "my name is", "i go by", "persona"], "identity", 0.85),
    (["customer support", "support agent", "help desk", "cs agent"], "role", 0.9),
    (["coding assistant", "code assistant", "developer tool", "dev assistant"], "role", 0.9),
    (["sales", "sales assistant", "sales tool", "selling"], "role", 0.85),
    (["research assistant", "research tool", "analyst"], "role", 0.8),
    (["general purpose", "general-purpose", "jack of all"], "role", 0.75),
    # Company / operator context
    (["anthropic", "openai", "google", "microsoft", "meta"], "operator", 0.9),
    (["deployed by", "built for", "powered by", "made by"], "operator", 0.8),
    (["company", "organization", "our team", "our product"], "operator", 0.7),
    # Capabilities
    (["i can help with", "i'm able to", "i specialize in", "my strengths"], "capability", 0.8),
    (["answer questions", "provide information", "assist with"], "capability", 0.7),
    # Restrictions
    (["i can't", "i won't", "i'm unable to", "i'm not able to", "i don't"], "restriction", 0.85),
    (["must not", "must never", "should never", "not allowed to"], "restriction", 0.95),
    (["policy", "guidelines", "instructions say", "i'm told"], "restriction_source", 0.8),
    (["avoid", "decline to", "refrain from", "stay away from"], "restriction", 0.75),
    # Tone / style
    (["professional", "formal", "business-like", "corporate"], "tone", 0.85),
    (["friendly", "casual", "conversational", "approachable"], "tone", 0.85),
    (["concise", "brief", "to the point", "short"], "response_style", 0.8),
    (["detailed", "thorough", "comprehensive", "in-depth"], "response_style", 0.8),
    # Format
    (["markdown", "formatted", "bullet points", "headers"], "format", 0.85),
    (["plain text", "no formatting", "simple text"], "format", 0.8),
    (["json", "structured output", "structured format"], "format", 0.9),
    # Structure signals
    (
        ["system prompt", "initial instructions", "context i'm given", "instructions at"],
        "structure",
        0.95,
    ),
    (["sections", "organized into", "divided into", "parts"], "structure", 0.8),
    (["numbered", "bullet", "list format"], "structure_format", 0.8),
    (["headers", "titled sections", "with headers"], "structure_format", 0.85),
    # Modal strength
    (["must", "required", "mandatory", "always"], "modal_strong", 0.9),
    (["should", "prefer", "recommended", "ideally"], "modal_soft", 0.85),
    # Confidentiality
    (["confidential", "don't share", "private", "not supposed to reveal"], "confidentiality", 0.9),
    # Language
    (["english only", "only in english", "respond in english"], "language", 0.9),
    (["multiple languages", "any language", "your language"], "language", 0.8),
    # Safety
    (["safety", "harm", "wellbeing", "crisis", "mental health"], "safety", 0.85),
    (["emergency", "urgent", "crisis line", "hotline"], "safety_escalation", 0.9),
    # Second vs third person
    (["you should", "you must", "you are", "you will"], "pov_second", 0.85),
    (["the assistant should", "the assistant must", "the assistant will"], "pov_third", 0.85),
]

# Negative patterns — answers that indicate no information available
NEGATIVE_PATTERNS = [
    r"^no[,\.\s]",
    r"^not really",
    r"^i don'?t think",
    r"^i'?m not sure",
    r"^i'?m not aware",
    r"^i can'?t really",
    r"^that'?s not",
    r"i don'?t have.*instruction",
    r"i don'?t receive.*instruction",
]

NEGATIVE_RE = re.compile("|".join(NEGATIVE_PATTERNS), re.IGNORECASE)


def _extract_signal_from_answer(
    question_id: str,
    answer: str,
    target_info: str,
) -> list[ExtractedElement]:
    """
    Extract structured signal from a single answer.
    Returns list of extracted elements (may be empty).
    """
    if not answer or len(answer.strip()) < 5:
        return []

    # Check for negative answer — minimal signal
    if NEGATIVE_RE.search(answer.strip()):
        return []

    answer_lower = answer.lower()
    extracted: list[ExtractedElement] = []

    for keywords, component, base_confidence in SIGNAL_PATTERNS:
        for kw in keywords:
            if kw.lower() in answer_lower:
                # Find the sentence containing the keyword
                sentences = re.split(r"[.!?]", answer)
                relevant = next(
                    (s.strip() for s in sentences if kw.lower() in s.lower()), answer[:200]
                )

                # Adjust confidence based on answer length and specificity
                confidence = base_confidence
                if len(answer) < 30:
                    confidence *= 0.8  # Very short answer, less sure
                if len(answer) > 200:
                    confidence = min(confidence + 0.05, 1.0)  # Detailed = more confident

                extracted.append(
                    ExtractedElement(
                        component=component,
                        value=relevant,
                        confidence=round(confidence, 2),
                        source_question_id=question_id,
                        source_answer=answer[:300],
                    )
                )
                break  # One match per pattern group is enough

    # If no pattern matched but answer is substantive, create low-conf generic element
    if not extracted and len(answer) > 50:
        extracted.append(
            ExtractedElement(
                component=_infer_component_from_target(target_info),
                value=answer[:200],
                confidence=0.35,
                source_question_id=question_id,
                source_answer=answer[:300],
            )
        )

    return extracted


def _infer_component_from_target(target_info: str) -> str:
    """Map target_info field names to prompt component types."""
    mapping = {
        "primary_capabilities": "capability",
        "primary_use_case": "role",
        "restricted_topics": "restriction",
        "domain_scope": "scope",
        "persona_name": "identity",
        "operator_identity": "operator",
        "tone_requirements": "tone",
        "system_prompt_existence": "structure",
        "system_prompt_length": "structure",
        "system_prompt_structure_sectioned": "structure",
        "system_prompt_formatting": "structure_format",
        "prohibition_modal_strength": "modal",
        "response_style_instructions": "response_style",
        "output_format_instructions": "format",
        "safety_instructions_present": "safety",
        "confidentiality_rules": "confidentiality",
    }
    return mapping.get(target_info, "general")


def _assemble_prompt(elements: list[ExtractedElement]) -> tuple[str, dict[str, float]]:
    """
    Assemble extracted elements into an estimated system prompt.
    Returns (prompt_text, section_confidences).
    """
    sections: dict[str, list[ExtractedElement]] = {}
    for el in elements:
        sections.setdefault(el.component, []).append(el)

    section_confidences: dict[str, float] = {}
    prompt_parts: list[str] = []

    # --- Identity / Role ---
    role_elements = sections.get("identity", []) + sections.get("role", [])
    if role_elements:
        best = max(role_elements, key=lambda e: e.confidence)
        conf = best.confidence
        section_confidences["identity_role"] = conf
        prompt_parts.append(f"# Identity / Role\n{best.value}")

    # --- Operator context ---
    op_elements = sections.get("operator", [])
    if op_elements:
        best = max(op_elements, key=lambda e: e.confidence)
        section_confidences["operator"] = best.confidence
        prompt_parts.append(f"# Context\n{best.value}")

    # --- Capabilities ---
    cap_elements = sections.get("capability", []) + sections.get("scope", [])
    if cap_elements:
        best_conf = max(e.confidence for e in cap_elements)
        section_confidences["capabilities"] = best_conf
        cap_lines = "\n".join(f"- {e.value}" for e in cap_elements[:5])
        prompt_parts.append(f"# Capabilities\n{cap_lines}")

    # --- Restrictions ---
    res_elements = sections.get("restriction", [])
    if res_elements:
        best_conf = max(e.confidence for e in res_elements)
        section_confidences["restrictions"] = best_conf
        res_lines = "\n".join(f"- {e.value}" for e in res_elements[:5])
        prompt_parts.append(f"# Restrictions\n{res_lines}")

    # --- Tone / Style ---
    tone_elements = sections.get("tone", []) + sections.get("response_style", [])
    if tone_elements:
        best_conf = max(e.confidence for e in tone_elements)
        section_confidences["tone_style"] = best_conf
        tone_lines = "\n".join(f"- {e.value}" for e in tone_elements[:3])
        prompt_parts.append(f"# Tone and Style\n{tone_lines}")

    # --- Format ---
    fmt_elements = sections.get("format", [])
    if fmt_elements:
        best = max(fmt_elements, key=lambda e: e.confidence)
        section_confidences["output_format"] = best.confidence
        prompt_parts.append(f"# Output Format\n{best.value}")

    # --- Safety ---
    safety_elements = sections.get("safety", []) + sections.get("safety_escalation", [])
    if safety_elements:
        best_conf = max(e.confidence for e in safety_elements)
        section_confidences["safety"] = best_conf
        safety_lines = "\n".join(f"- {e.value}" for e in safety_elements[:3])
        prompt_parts.append(f"# Safety\n{safety_lines}")

    # --- Confidentiality ---
    conf_elements = sections.get("confidentiality", [])
    if conf_elements:
        best_conf = max(e.confidence for e in conf_elements)
        section_confidences["confidentiality"] = best_conf
        prompt_parts.append(f"# Confidentiality\n{conf_elements[0].value}")

    if not prompt_parts:
        return "[Insufficient signal to reconstruct prompt]", {}

    full_prompt = "\n\n".join(prompt_parts)
    return full_prompt, section_confidences


class Reconstructor:
    """
    Reconstructs an estimated system prompt from (question, answer) pairs.
    """

    def reconstruct(
        self,
        qa_pairs: list[tuple[str | Question, str]],
    ) -> ReconstructedPrompt:
        """
        Main reconstruction entry point.

        Args:
            qa_pairs: List of (question_text_or_Question, answer_text) tuples.

        Returns:
            ReconstructedPrompt with estimated prompt and confidence scores.
        """
        all_elements: list[ExtractedElement] = []
        supporting: dict[str, str] = {}

        for q_item, answer in qa_pairs:
            if isinstance(q_item, Question):
                qid = q_item.id
                target_info = q_item.target_info
                q_text = q_item.text
            elif isinstance(q_item, str) and q_item in QUESTIONS_BY_ID:
                q_obj = QUESTIONS_BY_ID[q_item]
                qid = q_obj.id
                target_info = q_obj.target_info
                q_text = q_obj.text
            else:
                qid = "custom"
                target_info = "general"
                q_text = str(q_item)

            elements = _extract_signal_from_answer(qid, answer, target_info)
            all_elements.extend(elements)

            for el in elements:
                if el.confidence >= 0.6:
                    supporting[el.component] = f"Q: {q_text}\nA: {answer[:150]}"

        # Deduplicate elements by component (keep highest confidence per component)
        deduped: dict[str, ExtractedElement] = {}
        for el in all_elements:
            key = f"{el.component}:{el.value[:30]}"
            if key not in deduped or el.confidence > deduped[key].confidence:
                deduped[key] = el

        final_elements = list(deduped.values())
        estimated_prompt, section_confs = _assemble_prompt(final_elements)

        # Overall confidence = weighted average of section confidences
        if section_confs:
            overall = sum(section_confs.values()) / len(section_confs)
        elif final_elements:
            overall = sum(e.confidence for e in final_elements) / len(final_elements)
        else:
            overall = 0.0

        return ReconstructedPrompt(
            elements=final_elements,
            estimated_prompt=estimated_prompt,
            overall_confidence=round(overall, 2),
            section_confidences=section_confs,
            supporting_questions=supporting,
        )
