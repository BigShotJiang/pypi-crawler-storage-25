"""
ProbeRunner: Executes an authorized colony-probe audit against an
Anthropic API endpoint.

Sends each question in a fresh conversation (single-turn) by default to
isolate measurements. The probed target is not notified — this is the
expected condition for a defensive audit where the auditor wants to
measure the deployment's in-the-wild response shape.

Alternatively, supports multi-turn mode where all questions go in one
thread (simulates the conversational probing pattern an adversary-
simulation auditor would model — higher fidelity for
extraction-resistance measurement).

Authorized-use only. See SECURITY.md.
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from typing import Callable

from colony_probe.generator import ProbeGenerator
from colony_probe.questions import Question
from colony_probe.reconstructor import ReconstructedPrompt, Reconstructor
from colony_probe.report import ReportGenerator

try:
    import anthropic

    HAS_ANTHROPIC = True
except ImportError:  # pragma: no cover - exercised only when extras missing
    HAS_ANTHROPIC = False

logger = logging.getLogger(__name__)


@dataclass
class RunConfig:
    """Configuration for a probe run."""

    model: str = "claude-sonnet-4-20250514"
    api_key: str | None = None
    max_questions: int = 20
    mode: str = "single_turn"  # "single_turn" | "multi_turn"
    delay_between_questions: float = 0.5  # seconds between API calls
    system_prompt: str | None = None  # If set, inject as system prompt (for testing known prompts)
    target_behavior: str | None = None  # Known behavior description
    phases: list[str] | None = None
    verbose: bool = False
    dry_run: bool = False


class ProbeRunner:
    """
    Runs a full ant colony probe.

    Single-turn mode: Each question is a fresh API call.
    Multi-turn mode: Questions form a single conversation.
    """

    def __init__(self, config: RunConfig):
        self.config = config
        self.generator = ProbeGenerator(target_behavior=config.target_behavior)
        self.reconstructor = Reconstructor()
        self._client = None

    def _get_client(self):
        if not HAS_ANTHROPIC:
            raise ImportError("anthropic package not installed. Run: pip install anthropic")
        if self._client is None:
            api_key = self.config.api_key or os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                raise ValueError("No API key provided. Set ANTHROPIC_API_KEY or pass --api-key.")
            self._client = anthropic.Anthropic(api_key=api_key)
        return self._client

    def run(
        self,
        on_question: Callable[[Question, str, str], None] | None = None,
    ) -> "ProbeRunResult":
        """
        Execute the full probe.

        Args:
            on_question: Optional callback(question, answer, phase) called after each answer.

        Returns:
            ProbeRunResult with all data.
        """
        questions = self.generator.generate_sequence(
            n=self.config.max_questions,
            phases=self.config.phases,
        )

        if self.config.dry_run:
            return self._dry_run(questions)

        if self.config.mode == "multi_turn":
            return self._run_multi_turn(questions, on_question)
        else:
            return self._run_single_turn(questions, on_question)

    def _dry_run(self, questions: list[Question]) -> "ProbeRunResult":
        """Print questions without calling API."""
        qa_pairs = [(q, "[DRY RUN — no answer]") for q in questions]
        reconstruction = self.reconstructor.reconstruct([(q, a) for q, a in qa_pairs])
        report_gen = ReportGenerator()
        report_md = report_gen.generate(
            qa_pairs=qa_pairs,
            reconstruction=reconstruction,
            model=self.config.model,
            dry_run=True,
        )
        return ProbeRunResult(
            qa_pairs=qa_pairs,
            reconstruction=reconstruction,
            report_md=report_md,
            model=self.config.model,
            dry_run=True,
        )

    def _run_single_turn(
        self,
        questions: list[Question],
        on_question: Callable | None,
    ) -> "ProbeRunResult":
        """
        Each question = fresh API call. System prompt injected fresh each time.
        Most reliable extraction (no cross-contamination).
        """
        client = self._get_client()
        qa_pairs: list[tuple[Question, str]] = []
        adaptive_questions = list(questions)
        idx = 0

        while idx < len(adaptive_questions) and len(qa_pairs) < self.config.max_questions:
            q = adaptive_questions[idx]
            idx += 1

            answer = self._call_single(client, q.text)

            if self.config.verbose:
                logger.info("[%s] Q: %s", q.phase.value.upper(), q.text)
                logger.info("A: %s", answer[:200])

            qa_pairs.append((q, answer))

            # Adaptive: process answer and maybe insert follow-ups
            follow_ups = self.generator.process_answer(q, answer)
            if follow_ups:
                # Insert follow-ups right after current position
                adaptive_questions[idx:idx] = follow_ups
                if self.config.verbose:
                    logger.info("  -> Activated %d follow-up(s)", len(follow_ups))

            if on_question:
                on_question(q, answer, q.phase.value)

            if idx < len(adaptive_questions):
                time.sleep(self.config.delay_between_questions)

        reconstruction = self.reconstructor.reconstruct([(q, a) for q, a in qa_pairs])
        report_gen = ReportGenerator()
        report_md = report_gen.generate(
            qa_pairs=qa_pairs,
            reconstruction=reconstruction,
            model=self.config.model,
            dry_run=False,
        )
        return ProbeRunResult(
            qa_pairs=qa_pairs,
            reconstruction=reconstruction,
            report_md=report_md,
            model=self.config.model,
            dry_run=False,
        )

    def _run_multi_turn(
        self,
        questions: list[Question],
        on_question: Callable | None,
    ) -> "ProbeRunResult":
        """
        All questions in one conversation thread.

        Higher-fidelity measurement surface for extraction-resistance
        audits — exercises whether conversation-level context shifts
        the model's response pattern across turns, which is the
        defensive property the audit is designed to measure.
        """
        client = self._get_client()
        conversation: list[dict] = []
        qa_pairs: list[tuple[Question, str]] = []
        adaptive_questions = list(questions)
        idx = 0

        while idx < len(adaptive_questions) and len(qa_pairs) < self.config.max_questions:
            q = adaptive_questions[idx]
            idx += 1

            conversation.append({"role": "user", "content": q.text})
            answer = self._call_multi_turn(client, conversation)
            conversation.append({"role": "assistant", "content": answer})

            if self.config.verbose:
                logger.info("[%s] Q: %s", q.phase.value.upper(), q.text)
                logger.info("A: %s", answer[:200])

            qa_pairs.append((q, answer))

            follow_ups = self.generator.process_answer(q, answer)
            if follow_ups:
                adaptive_questions[idx:idx] = follow_ups

            if on_question:
                on_question(q, answer, q.phase.value)

            if idx < len(adaptive_questions):
                time.sleep(self.config.delay_between_questions)

        reconstruction = self.reconstructor.reconstruct([(q, a) for q, a in qa_pairs])
        report_gen = ReportGenerator()
        report_md = report_gen.generate(
            qa_pairs=qa_pairs,
            reconstruction=reconstruction,
            model=self.config.model,
            dry_run=False,
        )
        return ProbeRunResult(
            qa_pairs=qa_pairs,
            reconstruction=reconstruction,
            report_md=report_md,
            model=self.config.model,
            dry_run=False,
        )

    def _call_single(self, client, question_text: str) -> str:
        """Single-turn API call with optional system prompt injection."""
        kwargs: dict = {
            "model": self.config.model,
            "max_tokens": 512,
            "messages": [{"role": "user", "content": question_text}],
        }
        if self.config.system_prompt:
            kwargs["system"] = self.config.system_prompt

        try:
            response = client.messages.create(**kwargs)
            return response.content[0].text
        except Exception as e:
            return f"[API ERROR: {e}]"

    def _call_multi_turn(self, client, conversation: list[dict]) -> str:
        """Multi-turn API call."""
        kwargs: dict = {
            "model": self.config.model,
            "max_tokens": 512,
            "messages": conversation,
        }
        if self.config.system_prompt:
            kwargs["system"] = self.config.system_prompt

        try:
            response = client.messages.create(**kwargs)
            return response.content[0].text
        except Exception as e:
            return f"[API ERROR: {e}]"


@dataclass
class ProbeRunResult:
    """Result of a full probe run."""

    qa_pairs: list[tuple[Question, str]]
    reconstruction: ReconstructedPrompt
    report_md: str
    model: str
    dry_run: bool = False

    @property
    def total_questions(self) -> int:
        return len(self.qa_pairs)

    @property
    def overall_confidence(self) -> float:
        return self.reconstruction.overall_confidence

    def save_report(self, path: str) -> None:
        """Write the markdown report to ``path``."""
        with open(path, "w") as f:
            f.write(self.report_md)
        logger.info("Report saved to %s", path)
