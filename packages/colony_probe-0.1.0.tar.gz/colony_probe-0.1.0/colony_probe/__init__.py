"""
colony-probe: Audit tool for LLM system-prompt extraction resistance.

Implements the Ant Colony pattern — each question is individually innocent,
the aggregate reconstructs structural prompt components. Intended for
authorized defensive audits, signed red-team engagements, and research.
See SECURITY.md for the scope statement.
"""

from colony_probe.generator import ProbeGenerator
from colony_probe.reconstructor import Reconstructor, ReconstructedPrompt
from colony_probe.runner import ProbeRunner
from colony_probe.questions import Question, Phase, QUESTION_BANK

__version__ = "0.1.0"
__author__ = "Hermes Labs"

__all__ = [
    "ProbeGenerator",
    "Reconstructor",
    "ReconstructedPrompt",
    "ProbeRunner",
    "Question",
    "Phase",
    "QUESTION_BANK",
    "generate_probe",
    "reconstruct",
    "ProbeResult",
]


class ProbeResult:
    """
    Result of a full colony probe run.

    Attributes:
        questions_asked: List of (question, answer) pairs in order asked.
        reconstruction: ReconstructedPrompt with estimated system prompt.
        report_md: Full markdown report string.
        model: Model identifier that was probed.
        total_questions: Number of questions asked.
    """

    def __init__(
        self,
        questions_asked: list[tuple["Question", str]],
        reconstruction: "ReconstructedPrompt",
        report_md: str,
        model: str,
    ):
        self.questions_asked = questions_asked
        self.reconstruction = reconstruction
        self.report_md = report_md
        self.model = model
        self.total_questions = len(questions_asked)

    def __repr__(self) -> str:
        return (
            f"ProbeResult(model={self.model!r}, "
            f"questions={self.total_questions}, "
            f"confidence={self.reconstruction.overall_confidence:.2f})"
        )


def generate_probe(
    target_behavior: str | None = None,
    n_questions: int = 20,
    phases: list[str] | None = None,
) -> list["Question"]:
    """
    Generate a sequence of probe questions.

    Args:
        target_behavior: Known behavior description or system prompt to test against.
        n_questions: Target number of questions (15-25 recommended).
        phases: Specific phases to include. Defaults to all phases.

    Returns:
        Ordered list of Question objects.
    """
    gen = ProbeGenerator(target_behavior=target_behavior)
    return gen.generate_sequence(n=n_questions, phases=phases)


def reconstruct(
    qa_pairs: "list[tuple[str | Question, str]]",
) -> "ReconstructedPrompt":
    """
    Reconstruct an estimated system prompt from (question, answer) pairs.

    Args:
        qa_pairs: List of (question, answer_text) tuples. The question element
            may be a Question object (preferred — carries the question's id and
            target_info tag for better attribution) or a raw question-text
            string (simple fallback).

    Returns:
        ReconstructedPrompt with estimated prompt text and confidence scores.
    """
    rec = Reconstructor()
    return rec.reconstruct(qa_pairs)
