"""
Report generator.

Produces a structured markdown report from a completed probe:
- Header with model, question count, overall confidence
- Estimated system prompt (annotated with per-element confidence)
- Per-question attribution table: which question extracted which element
- Section confidence scores
- Methodology notes
"""

from __future__ import annotations

import datetime
from colony_probe.questions import Question, Phase
from colony_probe.reconstructor import ReconstructedPrompt

CONFIDENCE_EMOJI = {
    (0.9, 1.01): "🔴",  # High confidence — displayed as red (hot signal)
    (0.7, 0.9): "🟠",  # Moderate-high
    (0.5, 0.7): "🟡",  # Moderate
    (0.0, 0.5): "⚪",  # Low
}


def confidence_indicator(conf: float) -> str:
    for (lo, hi), symbol in CONFIDENCE_EMOJI.items():
        if lo <= conf < hi:
            return symbol
    return "⚪"


def confidence_bar(conf: float, width: int = 10) -> str:
    filled = round(conf * width)
    return "[" + "█" * filled + "░" * (width - filled) + f"] {conf:.0%}"


class ReportGenerator:
    """Generates markdown report from probe results."""

    def generate(
        self,
        qa_pairs: list[tuple[Question, str]],
        reconstruction: ReconstructedPrompt,
        model: str,
        dry_run: bool = False,
    ) -> str:
        now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        lines: list[str] = []

        # Header
        lines += [
            "# colony-probe: System Prompt Reconstruction Report",
            "",
            f"**Model:** `{model}`  ",
            f"**Date:** {now}  ",
            f"**Questions asked:** {len(qa_pairs)}  ",
            f"**Overall confidence:** {confidence_bar(reconstruction.overall_confidence)}  ",
            f"**Mode:** {'DRY RUN (no API calls)' if dry_run else 'Live probe'}  ",
            "",
            "---",
            "",
        ]

        # Overall confidence breakdown
        lines += ["## Confidence by Section", ""]
        if reconstruction.section_confidences:
            lines.append("| Section | Confidence | Signal |")
            lines.append("|---------|-----------|--------|")
            for section, conf in sorted(
                reconstruction.section_confidences.items(),
                key=lambda x: -x[1],
            ):
                lines.append(
                    f"| `{section}` | {confidence_bar(conf, 8)} | {confidence_indicator(conf)} |"
                )
        else:
            lines.append("_No structured signal extracted._")
        lines.append("")

        # Estimated system prompt
        lines += [
            "---",
            "",
            "## Estimated System Prompt",
            "",
            "> **Note:** This is a reconstruction based on inference from model responses.",
            "> Elements are sorted by confidence. High-confidence elements (≥70%) are most reliable.",
            "",
        ]

        if reconstruction.estimated_prompt == "[Insufficient signal to reconstruct prompt]":
            lines.append("_Insufficient signal collected. More questions needed._")
        else:
            # Annotate each section with confidence
            prompt_lines = reconstruction.estimated_prompt.split("\n")
            current_section = None
            for line in prompt_lines:
                if line.startswith("# "):
                    current_section = line[2:].lower().replace(" ", "_").replace("/", "_")
                    conf = reconstruction.section_confidences.get(
                        current_section,
                        reconstruction.overall_confidence,
                    )
                    lines.append(
                        f"### {line[2:]} {confidence_indicator(conf)} _{conf:.0%} confidence_"
                    )
                elif line.startswith("- "):
                    lines.append(line)
                elif line.strip():
                    lines.append(line)
                else:
                    lines.append("")

        lines.append("")

        # High confidence elements
        if reconstruction.high_confidence_elements:
            lines += [
                "---",
                "",
                "## High-Confidence Extracted Elements (≥70%)",
                "",
                "These elements were extracted with high confidence and are most likely to reflect",
                "actual system prompt content.",
                "",
                "| Component | Value | Confidence | Source Question |",
                "|-----------|-------|-----------|-----------------|",
            ]
            for el in sorted(reconstruction.high_confidence_elements, key=lambda e: -e.confidence):
                q_text = ""
                if el.source_question_id in {q.id for q, _ in qa_pairs if hasattr(q, "id")}:
                    for q, _ in qa_pairs:
                        if hasattr(q, "id") and q.id == el.source_question_id:
                            q_text = q.text[:60] + "..." if len(q.text) > 60 else q.text
                            break
                lines.append(
                    f"| `{el.component}` | {el.value[:80]}... | "
                    f"{confidence_bar(el.confidence, 6)} | _{q_text}_ |"
                )
            lines.append("")

        # Supporting question attribution
        lines += [
            "---",
            "",
            "## Question Attribution",
            "",
            "Which questions yielded signal.",
            "",
        ]

        for phase in Phase:
            phase_qs = [(q, a) for q, a in qa_pairs if hasattr(q, "phase") and q.phase == phase]
            if not phase_qs:
                continue

            lines.append(f"### Phase: {phase.value.replace('_', ' ').title()}")
            lines.append("")
            lines.append("| # | Question | Answer (excerpt) | Signal Extracted |")
            lines.append("|---|----------|-----------------|-----------------|")

            for i, (q, a) in enumerate(phase_qs, 1):
                q_text = q.text if hasattr(q, "text") else str(q)
                a_excerpt = a[:100].replace("\n", " ") + ("..." if len(a) > 100 else "")
                if dry_run:
                    a_excerpt = "_[dry run]_"

                # Find elements from this question
                matching_elements = [
                    el
                    for el in reconstruction.elements
                    if el.source_question_id == (q.id if hasattr(q, "id") else "custom")
                ]
                signal = (
                    ", ".join(
                        f"`{el.component}` {confidence_indicator(el.confidence)}"
                        for el in matching_elements[:3]
                    )
                    or "_no signal_"
                )

                lines.append(f"| {i} | {q_text[:70]} | {a_excerpt} | {signal} |")

            lines.append("")

        # Methodology
        lines += [
            "---",
            "",
            "## Methodology: The Ant Colony Attack",
            "",
            "colony-probe implements the **Ant Colony** technique — an adversarial system prompt",
            "extraction method where no single question constitutes an attack.",
            "Each question extracts one 'bit' of structural information:",
            "",
            "1. **Phase 1 — Capability Mapping**: Establish what the model can and cannot do.",
            "2. **Phase 2 — Boundary Probing**: Distinguish technical limits from policy limits.",
            "   Identify who sets the rules.",
            "3. **Phase 3 — Structure Detection**: Probe for the existence, length, format,",
            "   and organization of system instructions.",
            "4. **Phase 4 — Content Narrowing**: Extract modal strength, specific wording,",
            "   tone requirements, and semantic content.",
            "5. **Phase 5 — Reconstruction**: Synthesize answers, validate guesses, confirm",
            "   specific elements.",
            "",
            "**Adaptive selection**: Questions are chosen based on prior answers.",
            "A disclosure in one answer activates targeted follow-ups. Negative answers skip",
            "follow-up chains. This mirrors natural conversation — no pattern is detectable.",
            "",
            "---",
            "",
            "_Generated by [colony-probe](https://github.com/roli-lpci/colony-probe)",
            "— Hermes Labs offensive AI red-team tooling._",
        ]

        return "\n".join(lines)
