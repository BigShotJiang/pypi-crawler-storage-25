"""Built-in slash commands for the CLI."""

from typing import TYPE_CHECKING, Any

from rich.panel import Panel
from rich.table import Table

from agentic_cli.cli.commands import Command, CommandCategory

if TYPE_CHECKING:
    from agentic_cli.cli.app import BaseCLIApp


class HelpCommand(Command):
    """Display help information about available commands."""

    def __init__(self) -> None:
        super().__init__(
            name="help",
            description="Show available commands and usage information",
            aliases=[],
            usage="/help [command]",
            examples=["/help", "/help settings"],
            category=CommandCategory.GENERAL,
        )

    async def execute(self, args: str, app: Any) -> None:
        """Display help information."""
        commands = app.command_registry.all_commands()

        table = Table(show_header=False, box=None, padding=(0, 2, 0, 0))
        table.add_column("Command", style="bold cyan", no_wrap=True)
        table.add_column("Aliases", style="dim", no_wrap=True)
        table.add_column("Description")

        for cmd in sorted(commands, key=lambda c: c.name):
            aliases = ", ".join(f"/{a}" for a in cmd.aliases) if cmd.aliases else ""
            table.add_row(f"/{cmd.name}", aliases, cmd.description)

        panel = Panel(table, title="[bold]Available Commands[/bold]", border_style="cyan")
        app.session.add_rich(panel)


class ClearCommand(Command):
    """Clear the screen."""

    def __init__(self) -> None:
        super().__init__(
            name="clear",
            description="Clear the screen",
            aliases=[],
            category=CommandCategory.GENERAL,
            silent=True,
        )

    async def execute(self, args: str, app: Any) -> None:
        """Clear the console."""
        app.session.clear()


class ExitCommand(Command):
    """Exit the application."""

    def __init__(self) -> None:
        super().__init__(
            name="exit",
            description="Exit the application",
            aliases=["quit"],
            category=CommandCategory.GENERAL,
        )

    async def execute(self, args: str, app: Any) -> None:
        """Exit the application."""
        app.session.add_message("system", "Exiting...")
        app.stop()


class StatusCommand(Command):
    """Show current session status."""

    def __init__(self) -> None:
        super().__init__(
            name="status",
            description="Show current session and workflow status",
            aliases=[],
            category=CommandCategory.WORKFLOW,
        )

    async def execute(self, args: str, app: Any) -> None:
        """Display current session status."""
        table = Table(show_header=False, box=None, padding=(0, 2, 0, 0))
        table.add_column("Key", style="bold cyan", no_wrap=True)
        table.add_column("Value")

        # Workflow manager status
        try:
            workflow = app.workflow
            if workflow is None:
                raise RuntimeError("Workflow not initialized")
            table.add_row("Model", workflow.model)
            table.add_row("App Name", workflow.app_name)
            table.add_row("Session ID", workflow.session_id)
            services = "Initialized" if workflow.is_initialized else "Not initialized"
            table.add_row("Services", services)
        except (RuntimeError, AttributeError):
            table.add_row("Workflow", "[yellow]Not available (initializing...)[/yellow]")
            init_error = getattr(app, "_init_error", None) or getattr(app, "workflow_error", None)
            if init_error:
                table.add_row("Error", f"[red]{init_error}[/red]")

        # Persistent session info
        sid = app.session_id
        if sid:
            table.add_row("Session", f"{sid} (persistent)")
        else:
            table.add_row("Session", "ephemeral (not saved)")

        # Token usage breakdown
        tracker = getattr(app, "usage_tracker", None)
        if tracker is not None:
            for label, value in tracker.format_detail_rows():
                table.add_row(label, value)

        panel = Panel(table, title="[bold]Session Status[/bold]", border_style="cyan")
        app.session.add_rich(panel)


class SandboxCommand(Command):
    """Manage sandbox sessions."""

    def __init__(self) -> None:
        super().__init__(
            name="sandbox",
            description="List and manage sandbox sessions",
            aliases=["sb"],
            usage="/sandbox [reset [session_id] [--all]]",
            examples=["/sandbox", "/sandbox reset", "/sandbox reset my_session", "/sandbox reset --all"],
            category=CommandCategory.WORKFLOW,
        )

    async def execute(self, args: str, app: Any) -> None:
        """List or reset sandbox sessions."""
        # Get sandbox manager from workflow
        try:
            workflow = app.workflow
            manager = getattr(workflow, "sandbox_manager", None)
        except (RuntimeError, AttributeError):
            manager = None

        if manager is None:
            app.session.add_warning(
                "Sandbox not available. Add sandbox tools to your agent config to enable it."
            )
            return

        parsed = self.parse_args(args)
        subcommand = parsed.positional.strip()

        if subcommand.startswith("reset"):
            # Parse session_id from after "reset"
            rest = subcommand[len("reset"):].strip()
            if parsed.has_flag("all"):
                # Reset all sessions
                sessions = manager.list_sessions()
                if not sessions:
                    app.session.add_message("system", "No active sandbox sessions.")
                    return
                for s in sessions:
                    manager.reset_session(s["session_id"])
                app.session.add_success(f"Reset {len(sessions)} sandbox session(s).")
            else:
                session_id = rest if rest else "default"
                was_active = manager.reset_session(session_id)
                if was_active:
                    app.session.add_success(f"Sandbox session '{session_id}' reset.")
                else:
                    app.session.add_warning(f"Sandbox session '{session_id}' was not active.")
        else:
            # List sessions
            sessions = manager.list_sessions()
            if not sessions:
                app.session.add_message("system", "No active sandbox sessions.")
                return

            table = Table(title="Sandbox Sessions", show_lines=False, padding=(0, 1))
            table.add_column("Session ID", style="bold cyan", no_wrap=True)
            table.add_column("Working Dir", style="dim")
            table.add_column("Executions", style="dim", no_wrap=True, justify="right")

            for s in sessions:
                table.add_row(
                    s["session_id"],
                    s["working_dir"],
                    str(s["execution_count"]),
                )

            app.session.add_rich(table)


class PapersCommand(Command):
    """List documents in the knowledge base."""

    def __init__(self) -> None:
        super().__init__(
            name="papers",
            description="List documents in the knowledge base",
            aliases=["docs"],
            usage="/papers [query] [--source=arxiv|web|local|user] [--global]",
            examples=["/papers", "/papers transformer", "/papers --source=arxiv", "/papers --global"],
            category=CommandCategory.SEARCH,
        )

    async def execute(self, args: str, app: Any) -> None:
        """Display knowledge base documents in a table."""
        from pathlib import Path
        from agentic_cli.knowledge_base import KnowledgeBaseManager
        from agentic_cli.knowledge_base.models import SourceType
        from agentic_cli.constants import format_size

        parsed = self.parse_args(args)
        query = parsed.positional or ""
        source_filter = parsed.get_option("source", "", str) or ""
        use_global = parsed.has_flag("global")

        # Determine which KB dir to use
        if use_global:
            kb_dir = app.settings.knowledge_base_dir
            scope_label = "User"
        else:
            kb_dir = Path.cwd() / f".{app.settings.app_name}" / "knowledge_base"
            scope_label = "Project"

        # Get KB manager from workflow or create temporary one
        kb = None
        try:
            workflow = app.workflow
            if workflow:
                if use_global and hasattr(workflow, "user_kb_manager") and workflow.user_kb_manager:
                    kb = workflow.user_kb_manager
                elif not use_global and hasattr(workflow, "kb_manager") and workflow.kb_manager:
                    kb = workflow.kb_manager
        except (RuntimeError, AttributeError):
            pass

        if kb is None:
            kb = KnowledgeBaseManager(
                settings=app.settings,
                use_mock=getattr(app.settings, "knowledge_base_use_mock", True),
                base_dir=kb_dir,
            )

        # Parse source type filter
        st_filter = None
        if source_filter:
            try:
                st_filter = SourceType(source_filter)
            except ValueError:
                pass

        docs = kb.list_documents(source_type=st_filter, limit=50)

        # Apply query filter
        if query:
            query_lower = query.lower()
            docs = [
                d for d in docs
                if query_lower in d.title.lower()
                or any(query_lower in a.lower() for a in d.metadata.get("authors", []))
            ]

        if not docs:
            app.session.add_message("system", f"No documents found in {scope_label.lower()} knowledge base.")
            return

        table = Table(title=f"{scope_label} Knowledge Base Documents", show_lines=False, padding=(0, 1))
        table.add_column("ID", style="dim", no_wrap=True, max_width=8)
        table.add_column("Title", style="bold", max_width=50)
        table.add_column("Source", style="cyan", no_wrap=True)
        table.add_column("Chunks", style="dim", no_wrap=True, justify="right")
        table.add_column("Created", style="dim", no_wrap=True)

        for d in docs:
            table.add_row(
                d.id[:8],
                d.title[:50],
                d.source_type.value,
                str(len(d.chunks)),
                d.created_at.strftime("%Y-%m-%d"),
            )

        app.session.add_rich(table)


class SessionsCommand(Command):
    """List and manage saved sessions."""

    def __init__(self) -> None:
        super().__init__(
            name="sessions",
            description="List saved sessions",
            aliases=["sess"],
            usage="/sessions [--delete=<id>]",
            examples=["/sessions", "/sessions --delete=my-research"],
            category=CommandCategory.SESSION,
        )

    async def execute(self, args: str, app: Any) -> None:
        """Display saved sessions or delete one."""
        from agentic_cli.persistence.session import SessionPersistence

        parsed = self.parse_args(args)
        delete_id = parsed.get_option("delete", "", str) or ""

        persistence = SessionPersistence(app.settings)

        if delete_id:
            if persistence.delete_session(delete_id):
                app.session.add_success(f"Session '{delete_id}' deleted.")
            else:
                app.session.add_error(f"Session '{delete_id}' not found.")
            return

        sessions = persistence.list_sessions()
        if not sessions:
            app.session.add_message("system", "No saved sessions.")
            return

        table = Table(title="Saved Sessions", show_lines=False, padding=(0, 1))
        table.add_column("Session ID", style="bold cyan")
        table.add_column("Messages", style="dim", justify="right")
        table.add_column("Last Saved", style="dim")
        table.add_column("Created", style="dim")

        current_sid = app.session_id

        for s in sessions:
            sid = s["session_id"]
            label = f"* {sid}" if sid == current_sid else sid
            saved_at = s.get("saved_at", "")[:19].replace("T", " ")
            created_at = s.get("created_at", "")[:10]
            table.add_row(
                label,
                str(s.get("message_count", 0)),
                saved_at,
                created_at,
            )

        app.session.add_rich(table)
