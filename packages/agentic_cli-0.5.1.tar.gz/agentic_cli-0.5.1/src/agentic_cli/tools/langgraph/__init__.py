"""LangGraph-specific tool implementations."""
