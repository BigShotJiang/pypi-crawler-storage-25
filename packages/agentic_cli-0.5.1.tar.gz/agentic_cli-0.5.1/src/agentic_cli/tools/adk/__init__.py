"""ADK-specific tool implementations."""
