#!/usr/bin/env sh
set -eu

MACMINI_HOST="${MACMINI_HOST:-macmini}"
MACMINI_USER="${MACMINI_USER:-odt}"
REMOTE_HOME="/Users/${MACMINI_USER}"
LOCAL_MESHCLAW_BIN="${MESHCLAW_BIN:-/Users/dragon/bin/meshclaw}"
LOCAL_VSSH_BIN="${VSSH_BIN:-/Users/dragon/bin/vssh}"
LOCAL_INVENTORY="${MESHCLAW_INVENTORY:-/Users/dragon/.meshclaw/inventory.json}"
LOCAL_NODES="${MESHCLAW_NODES:-/Users/dragon/.meshclaw/nodes.json}"
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

if [ ! -f "$LOCAL_INVENTORY" ]; then
  echo "missing inventory: $LOCAL_INVENTORY" >&2
  exit 1
fi

VSSH_SECRET="${VSSH_SECRET:-}"
if [ -z "$VSSH_SECRET" ] && command -v python3 >/dev/null 2>&1; then
  VSSH_SECRET="$(python3 - <<'PY'
import json, pathlib
for path in (
    pathlib.Path.home() / ".cursor/mcp.json",
    pathlib.Path.home() / "Library/Application Support/Claude/claude_desktop_config.json",
):
    if not path.exists():
        continue
    data = json.loads(path.read_text())
    for block in (data.get("mcpServers") or {}).values():
        env = block.get("env") or {}
        if env.get("VSSH_SECRET"):
            print(env["VSSH_SECRET"])
            raise SystemExit(0)
raise SystemExit(1)
PY
)" || true
fi
if [ -z "$VSSH_SECRET" ]; then
  echo "set VSSH_SECRET or configure it in ~/.cursor/mcp.json" >&2
  exit 1
fi

echo "deploy binaries and inventory to ${MACMINI_HOST}..."
scp "$LOCAL_MESHCLAW_BIN" "${MACMINI_HOST}:${REMOTE_HOME}/bin/meshclaw"
scp "$LOCAL_VSSH_BIN" "${MACMINI_HOST}:${REMOTE_HOME}/bin/vssh"
scp "$LOCAL_INVENTORY" "${MACMINI_HOST}:${REMOTE_HOME}/.meshclaw/inventory.json"
if [ -f "$LOCAL_NODES" ]; then
  scp "$LOCAL_NODES" "${MACMINI_HOST}:${REMOTE_HOME}/.meshclaw/nodes.json"
fi

echo "install LaunchAgents..."
ssh "${MACMINI_HOST}" "mkdir -p '${REMOTE_HOME}/.meshclaw/logs' '${REMOTE_HOME}/Library/LaunchAgents'"

for label in monitor-agent ops-control; do
  scp "${REPO_ROOT}/deploy/launchd/ai.meshclaw.${label}.plist" \
    "${MACMINI_HOST}:${REMOTE_HOME}/Library/LaunchAgents/ai.meshclaw.${label}.plist"
done

ssh "${MACMINI_HOST}" "VSSH_SECRET='${VSSH_SECRET}' python3 - <<'PY'
import plistlib, pathlib, os
home = pathlib.Path('${REMOTE_HOME}')
secret = os.environ['VSSH_SECRET']
path_entries = [
    str(home / 'bin'),
    '/usr/local/bin',
    '/usr/bin',
    '/bin',
    '/Applications/Tailscale.app/Contents/MacOS',
]
env = {
    'VSSH_SECRET': secret,
    'MESHCLAW_VSSH_BINARY': str(home / 'bin' / 'vssh'),
    'MESHCLAW_VSSH_FACTS_TIMEOUT': '60s',
    'PATH': ':'.join(path_entries),
}
for label in ('monitor-agent', 'ops-control'):
    plist_path = home / 'Library' / 'LaunchAgents' / f'ai.meshclaw.{label}.plist'
    data = plistlib.loads(plist_path.read_bytes())
    data['EnvironmentVariables'] = env
    plist_path.write_bytes(plistlib.dumps(data))
PY"

ssh "${MACMINI_HOST}" "chmod +x '${REMOTE_HOME}/bin/meshclaw' '${REMOTE_HOME}/bin/vssh'"

echo "stop stray foreground monitor-agent if any..."
ssh "${MACMINI_HOST}" "pkill -f '[m]eshclaw monitor-agent' || true"

echo "reload LaunchAgents..."
ssh "${MACMINI_HOST}" "UID=\$(id -u); \
  launchctl bootout \"gui/\${UID}/ai.meshclaw.monitor-agent\" 2>/dev/null || true; \
  launchctl bootout \"gui/\${UID}/ai.meshclaw.ops-control\" 2>/dev/null || true; \
  launchctl bootstrap \"gui/\${UID}\" '${REMOTE_HOME}/Library/LaunchAgents/ai.meshclaw.monitor-agent.plist'; \
  launchctl bootstrap \"gui/\${UID}\" '${REMOTE_HOME}/Library/LaunchAgents/ai.meshclaw.ops-control.plist'; \
  launchctl enable \"gui/\${UID}/ai.meshclaw.monitor-agent\"; \
  launchctl enable \"gui/\${UID}/ai.meshclaw.ops-control\"; \
  launchctl kickstart -k \"gui/\${UID}/ai.meshclaw.monitor-agent\"; \
  launchctl kickstart -k \"gui/\${UID}/ai.meshclaw.ops-control\""

echo "verify..."
ssh "${MACMINI_HOST}" "'${REMOTE_HOME}/bin/meshclaw' list | head -6"
ssh "${MACMINI_HOST}" "sleep 3; tail -5 '${REMOTE_HOME}/.meshclaw/logs/monitor-agent.log' 2>/dev/null || true"
ssh "${MACMINI_HOST}" "ls -lt '${REMOTE_HOME}/.meshclaw/evidence/$(date +%Y-%m-%d)' 2>/dev/null | head -5"
echo "done"
