#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HOST="${1:-v1}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"

deploy_domain() {
  local domain="$1"
  local src="$ROOT/web/domains/$domain"
  local dst="/var/www/$domain"
  local archive="/var/www/archive/$domain-$STAMP"

  if [[ ! -d "$src" ]]; then
    echo "missing source: $src" >&2
    exit 1
  fi

  ssh "$HOST" "mkdir -p /var/www/archive && if [ -d '$dst' ]; then cp -a '$dst' '$archive'; fi; mkdir -p '$dst'"
  rsync -az --delete "$src"/ "$HOST:$dst"/
}

deploy_domain mpop.dev
deploy_domain meshclaw.run
deploy_domain meshclaw.sh

scp "$ROOT/web/nginx/mpop.dev.conf" "$HOST:/etc/nginx/sites-available/mpop.dev"
scp "$ROOT/web/nginx/meshclaw.run.conf" "$HOST:/etc/nginx/sites-available/meshclaw.run"
scp "$ROOT/web/nginx/meshclaw.sh.conf" "$HOST:/etc/nginx/sites-available/meshclaw.sh"

ssh "$HOST" "ln -sf /etc/nginx/sites-available/mpop.dev /etc/nginx/sites-enabled/mpop.dev && ln -sf /etc/nginx/sites-available/meshclaw.run /etc/nginx/sites-enabled/meshclaw.run && ln -sf /etc/nginx/sites-available/meshclaw.sh /etc/nginx/sites-enabled/meshclaw.sh && nginx -t && systemctl reload nginx"

echo "deployed web domains to $HOST"
