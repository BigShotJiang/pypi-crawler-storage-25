#!/usr/bin/env sh
set -eu

echo "Installing MeshClaw Runtime..."

if command -v python3 >/dev/null 2>&1; then
  PY=python3
elif command -v python >/dev/null 2>&1; then
  PY=python
else
  echo "python3 is required" >&2
  exit 1
fi

$PY -m pip install -U meshclaw vssh

echo
echo "MeshClaw installed."
echo "Next:"
echo "  meshclaw init"
echo "  meshclaw doctor"
echo "  meshclaw run fleet-health-demo --dry-run"
