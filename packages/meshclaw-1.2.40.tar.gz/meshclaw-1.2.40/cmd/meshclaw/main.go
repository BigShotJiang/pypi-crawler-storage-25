package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/meshclaw/meshclaw/internal/aichat"
	"github.com/meshclaw/meshclaw/internal/capability"
	"github.com/meshclaw/meshclaw/internal/doctor"
	"github.com/meshclaw/meshclaw/internal/evidence"
	"github.com/meshclaw/meshclaw/internal/fleet"
	"github.com/meshclaw/meshclaw/internal/guard"
	"github.com/meshclaw/meshclaw/internal/guardvault"
	"github.com/meshclaw/meshclaw/internal/hygiene"
	"github.com/meshclaw/meshclaw/internal/inventory"
	"github.com/meshclaw/meshclaw/internal/matrixops"
	"github.com/meshclaw/meshclaw/internal/monitor"
	"github.com/meshclaw/meshclaw/internal/openwebui"
	"github.com/meshclaw/meshclaw/internal/policy"
	"github.com/meshclaw/meshclaw/internal/provision"
	"github.com/meshclaw/meshclaw/internal/runtime"
	"github.com/meshclaw/meshclaw/internal/runtimeflow"
	"github.com/meshclaw/meshclaw/internal/workers"
	"github.com/meshclaw/meshclaw/internal/workflow"
	"github.com/meshclaw/meshclaw/internal/workspace"
)

const meshclawVersion = "1.2.40"

func main() {
	if len(os.Args) < 2 {
		usage()
		return
	}

	var err error
	switch os.Args[1] {
	case "help", "--help", "-h":
		usage()
	case "version", "--version":
		fmt.Println(meshclawVersion)
	case "init":
		err = initRuntime(os.Args[2:])
	case "quickstart", "first-run":
		err = quickstart(os.Args[2:])
	case "list":
		err = list(os.Args[2:])
	case "nodes":
		err = nodes(os.Args[2:])
	case "inventory-init":
		err = inventoryInit(os.Args[2:])
	case "inventory-discover":
		err = inventoryDiscover(os.Args[2:])
	case "inventory-diff":
		err = inventoryDiff(os.Args[2:])
	case "inventory-override":
		err = inventoryOverride(os.Args[2:])
	case "direction":
		err = direction(os.Args[2:])
	case "capabilities":
		err = capabilities(os.Args[2:])
	case "adapters":
		err = adapters(os.Args[2:])
	case "status":
		err = status()
	case "monitor-check":
		err = monitorCheck(os.Args[2:])
	case "monitor-agent":
		err = monitorAgent(os.Args[2:])
	case "ops-brief":
		err = opsBrief(os.Args[2:])
	case "ops-control":
		err = opsControl(os.Args[2:])
	case "fleet-scan":
		err = fleetScan(os.Args[2:])
	case "fleet-service-audit":
		err = fleetServiceAudit(os.Args[2:])
	case "vssh-daemon-audit":
		err = vsshDaemonAudit(os.Args[2:])
	case "vssh-auth-fix-plan":
		err = vsshAuthFixPlan(os.Args[2:])
	case "vssh-auth-paths":
		err = vsshAuthPaths(os.Args[2:])
	case "node-repair-plan":
		err = nodeRepairPlan(os.Args[2:])
	case "service-triage":
		err = serviceTriage(os.Args[2:])
	case "node-inventory":
		err = nodeInventory(os.Args[2:])
	case "fleet-inventory":
		err = fleetInventory(os.Args[2:])
	case "placement-plan":
		err = placementPlan(os.Args[2:])
	case "orchestration-plan":
		err = orchestrationPlan(os.Args[2:])
	case "autoheal-plan":
		err = autohealPlan(os.Args[2:])
	case "autoheal-apply-safe":
		err = autohealApplySafe()
	case "disk-investigate":
		err = diskInvestigate(os.Args[2:])
	case "process-top":
		err = processTop(os.Args[2:])
	case "data-clean-plan":
		err = dataCleanPlan(os.Args[2:])
	case "data-clean-apply":
		err = dataCleanApply(os.Args[2:])
	case "evidence-list":
		err = evidenceList(os.Args[2:])
	case "evidence":
		err = evidenceCommand(os.Args[2:])
	case "policy-check":
		err = policyCheck(os.Args[2:])
	case "policy-show":
		err = policyShow(os.Args[2:])
	case "policy-init":
		err = policyInit(os.Args[2:])
	case "policy-presets":
		err = policyPresets(os.Args[2:])
	case "matrix-plan":
		err = matrixBridgePlan(os.Args[2:])
	case "matrix-config-init":
		err = matrixConfigInit(os.Args[2:])
	case "matrix-post":
		err = matrixPost(os.Args[2:])
	case "matrix-sync-once":
		err = matrixSyncOnce(os.Args[2:])
	case "matrix-bridge":
		err = matrixBridge(os.Args[2:])
	case "matrix-doctor":
		err = matrixDoctor(os.Args[2:])
	case "matrix-ai-config-init":
		err = matrixAIConfigInit(os.Args[2:])
	case "matrix-ai-chat":
		err = matrixAIChat(os.Args[2:])
	case "matrix-ai-bridge":
		err = matrixAIBridge(os.Args[2:])
	case "workers":
		err = workersList(os.Args[2:])
	case "ai-guide":
		err = aiGuide(os.Args[2:])
	case "tool-recommend":
		err = toolRecommend(os.Args[2:])
	case "openwebui-scan":
		err = openwebuiScan(os.Args[2:])
	case "workspace-list":
		err = workspaceList(os.Args[2:])
	case "workspace-add":
		err = workspaceAdd(os.Args[2:])
	case "workspace-activity":
		err = workspaceActivity(os.Args[2:])
	case "ops-chat":
		err = opsChat(os.Args[2:])
	case "ops-dispatch":
		err = opsDispatch(os.Args[2:])
	case "provision-plan":
		err = provisionPlan(os.Args[2:])
	case "workflows":
		err = workflows(os.Args[2:])
	case "approvals":
		err = approvals(os.Args[2:])
	case "run":
		err = run(os.Args[2:])
	case "run-evidence":
		err = runEvidence(os.Args[2:])
	case "job-start":
		err = jobStart(os.Args[2:])
	case "job-status":
		err = jobStatus(os.Args[2:])
	case "job-logs":
		err = jobLogs(os.Args[2:])
	case "job-cancel":
		err = jobCancel(os.Args[2:])
	case "artifact-collect":
		err = artifactCollect(os.Args[2:])
	case "doctor":
		err = runDoctor(os.Args[2:])
	case "setup", "setup-check", "install-check":
		err = runSetupCheck(os.Args[2:])
	case "analyze-logs":
		err = analyzeLogs(os.Args[2:])
	case "service-check":
		err = serviceCheck(os.Args[2:])
	case "service-audit":
		err = serviceAudit(os.Args[2:])
	case "service-quarantine":
		err = serviceQuarantine(os.Args[2:])
	case "service-remove":
		err = serviceRemove(os.Args[2:])
	case "security-check":
		err = securityCheck(os.Args[2:])
	case "guard-modes":
		err = guardModes(os.Args[2:])
	case "guard-model":
		err = guardModel(os.Args[2:])
	case "guard-clients":
		err = guardClients(os.Args[2:])
	case "guard-vault":
		err = guardVault(os.Args[2:])
	case "guard-vault-backends":
		err = guardVaultBackends(os.Args[2:])
	case "guard-vault-init":
		err = guardVaultInit(os.Args[2:])
	case "guard-vault-put":
		err = guardVaultPut(os.Args[2:])
	case "guard-vault-list":
		err = guardVaultList(os.Args[2:])
	case "guard-vault-metadata":
		err = guardVaultMetadata(os.Args[2:])
	case "guard-vault-delete":
		err = guardVaultDelete(os.Args[2:])
	case "guard-vault-use":
		err = guardVaultUse(os.Args[2:])
	case "guard-detect":
		err = guardDetect(os.Args[2:])
	case "guard-redact":
		err = guardRedact(os.Args[2:])
	case "guard-posture":
		err = guardPosture(os.Args[2:])
	case "guard-clean-plan":
		err = guardCleanPlan(os.Args[2:])
	case "guard-vuln":
		err = guardVuln(os.Args[2:])
	case "guard-intent":
		err = guardIntent(os.Args[2:])
	case "guard-local-server":
		err = guardLocalServer(os.Args[2:])
	case "hygiene-plan":
		err = hygienePlan(os.Args[2:])
	case "hygiene-scan-host":
		err = hygieneScanHost(os.Args[2:])
	case "hygiene-scan-text":
		err = hygieneScanText(os.Args[2:])
	case "mcp":
		err = mcp()
	default:
		err = fmt.Errorf("unknown command: %s", os.Args[1])
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "meshclaw:", err)
		os.Exit(1)
	}
}

func usage() {
	fmt.Println(`meshclaw - AI-native operations runtime for real infrastructure

Core path:
  meshclaw init [--force] [--json]
  meshclaw quickstart [--json]
  meshclaw doctor [host] [--json]
  meshclaw setup-check [--json]
  meshclaw nodes list [--json]
  meshclaw nodes inspect <host> [--json]
  meshclaw workflows [--json]
  meshclaw workflows scaffold <name> [--output path] [--force] [--json]
  meshclaw workflows inspect <workflow> [--json]
  meshclaw workflows validate <workflow|file.json> [--json]
  meshclaw run <workflow> --dry-run|--execute [--approvals latest|bundle|execution.json] [--step id[,id]] [--json]
  meshclaw workflows resume [latest|bundle|execution.json] [--json]
  meshclaw workflows plan-execute [latest|bundle|execution.json] [--json]
  meshclaw evidence open latest
  meshclaw mcp

Fleet and state:
  meshclaw list
  meshclaw inventory-init [--force] [--json]
  meshclaw inventory-discover [--json]
  meshclaw inventory-diff [--json]
  meshclaw inventory-override <list|set|remove> [...]
  meshclaw status
  meshclaw monitor-check
  meshclaw monitor-agent [interval] [--hygiene]
  meshclaw ops-brief [--json]
  meshclaw ops-control [--apply-safe] [--json]
  meshclaw fleet-scan [--hosts a,b] [--security] [--hygiene] [--logs] [--parallel n] [--json]
  meshclaw fleet-service-audit [--hosts a,b] [--parallel n] [--json]
  meshclaw service-triage [--hosts a,b] [--limit n] [--parallel n] [--json]
  meshclaw node-inventory <host> [--json]
  meshclaw fleet-inventory [--hosts a,b] [--parallel n] [--json]

Policy, approval, and evidence:
  meshclaw policy-check <subject> <action> <resource> [context]
  meshclaw policy-show
  meshclaw policy-init [--preset devops|strict] [--force]
  meshclaw policy-presets
  meshclaw approvals list [latest|bundle|execution.json] [--json]
  meshclaw approvals grant <latest|bundle|execution.json> <step> --actor <actor> [--reason text] [--source cli] [--json]
  meshclaw evidence-list [limit]
  meshclaw run-evidence <host> <command>

Planning and repair:
  meshclaw direction [--json]
  meshclaw capabilities [init --force|validate [file]|recommend <intent>] [--json]
  meshclaw adapters [--json]
  meshclaw placement-plan <workload description> [--json]
  meshclaw orchestration-plan <scenario> [--json]
  meshclaw autoheal-plan
  meshclaw autoheal-apply-safe
  meshclaw vssh-daemon-audit [--hosts a,b] [--json]
  meshclaw vssh-auth-fix-plan [--hosts a,b] [--json]
  meshclaw vssh-auth-paths [--hosts a,b] [--json]
  meshclaw node-repair-plan [--hosts a,b] [--json]

Diagnostics and hygiene:
  meshclaw disk-investigate <host> [path]
  meshclaw process-top <host>
  meshclaw analyze-logs <host> <source>
  meshclaw service-check <host> <service>
  meshclaw service-audit <host>
  meshclaw service-quarantine <host> <service>
  meshclaw service-remove <host> <service> [working-directory]
  meshclaw security-check <host>
  meshclaw guard-modes [--json]
  meshclaw guard-model [--json]
  meshclaw guard-clients [--json]
  meshclaw guard-vault [--json]
  meshclaw guard-vault-backends [--json]
  meshclaw guard-vault-init [--json]
  meshclaw guard-vault-put <scope> <name> [kind] [description] [--backend local|keychain|pass] < secret.txt [--json]
  meshclaw guard-vault-list [--json]
  meshclaw guard-vault-metadata <vault://meshclaw/scope/name|scope name> [--json]
  meshclaw guard-vault-delete <scope> <name> [--json]
  meshclaw guard-vault-use <handle> <ENV_NAME> --approve [--actor name] [--reason text] [--json] -- <command> [args...]
  meshclaw guard-detect <target> <text> [--json]
  meshclaw guard-redact <target> <text> [--json]
  meshclaw guard-posture [home] [--json]
  meshclaw guard-clean-plan [home] [--json]
  meshclaw guard-vuln <path> [--json]
  meshclaw guard-intent <message> [--json]
  meshclaw guard-local-server [127.0.0.1:18765]
  meshclaw hygiene-plan <host>
  meshclaw hygiene-scan-host <host>
  meshclaw hygiene-scan-text <target> <text>
  meshclaw data-clean-plan <host> <path>
  meshclaw data-clean-apply <host> <manifest>

Integrations and operators:
  meshclaw workers [--json]
  meshclaw ai-guide [--json]
  meshclaw tool-recommend <intent> [--subject subject] [--json]
  meshclaw openwebui-scan [--hosts a,b] [--parallel n] [--json]
  meshclaw workspace-list [--json]
  meshclaw workspace-add <id> <host> <path> [owner] [purpose]
  meshclaw workspace-activity <id> <actor> <action> <summary>
  meshclaw ops-chat [message]
  meshclaw ops-dispatch <matrix|openwebui|codex|claude> <message>
  meshclaw provision-plan <purpose> [budget-usd]
  meshclaw matrix-plan
  meshclaw matrix-config-init [--force]
  meshclaw matrix-post <message>
  meshclaw matrix-sync-once [since]
  meshclaw matrix-bridge
  meshclaw matrix-doctor [--json]
  meshclaw matrix-ai-config-init [--force]
  meshclaw matrix-ai-chat <message>
  meshclaw matrix-ai-bridge

Low-level execution:
  meshclaw run <host> <command>
  meshclaw job-start <host> <command>
  meshclaw job-status <host> <id>
  meshclaw job-logs <host> <id> [tail-bytes]
  meshclaw job-cancel <host> <id>
  meshclaw artifact-collect <host> <path> [max-bytes]`)
}

func monitorAgent(args []string) error {
	interval := 5 * time.Minute
	hygieneEnabled := false
	filteredArgs := make([]string, 0, len(args))
	for _, arg := range args {
		if arg == "--hygiene" {
			hygieneEnabled = true
			continue
		}
		filteredArgs = append(filteredArgs, arg)
	}
	if len(filteredArgs) > 1 {
		return fmt.Errorf("usage: meshclaw monitor-agent [interval] [--hygiene]")
	}
	if len(filteredArgs) == 1 {
		parsed, err := time.ParseDuration(filteredArgs[0])
		if err != nil {
			return fmt.Errorf("invalid interval: %s", filteredArgs[0])
		}
		if parsed < 10*time.Second {
			return fmt.Errorf("interval must be at least 10s")
		}
		interval = parsed
	}

	cfg := monitor.DefaultConfig()
	cfg.CheckInterval = interval
	m, err := monitor.New(cfg)
	if err != nil {
		return err
	}

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	fmt.Printf("meshclaw monitor-agent interval=%s hygiene=%t\n", interval, hygieneEnabled)

	runOnce := func() {
		states := m.CheckAll()
		alerts := m.DetectAlerts()
		var hygieneReports []hygiene.Report
		if hygieneEnabled {
			for name, state := range states {
				if state == nil || !state.Online {
					continue
				}
				report := hygiene.ScanHost(name)
				if report.Status == "findings" || report.Status == "failed" {
					hygieneReports = append(hygieneReports, report)
				}
			}
		}
		record, storeErr := evidence.Store("monitor-agent", "fleet", fmt.Sprintf("alerts=%d hygiene_findings=%d", len(alerts), len(hygieneReports)), monitorAgentOutput{States: states, Alerts: alerts, Hygiene: hygieneReports})
		fmt.Printf("monitor-agent check nodes=%d alerts=%d", len(states), len(alerts))
		if hygieneEnabled {
			fmt.Printf(" hygiene_findings=%d", len(hygieneReports))
		}
		if storeErr != nil {
			fmt.Printf(" evidence_error=%v", storeErr)
		} else {
			fmt.Printf(" evidence=%s", record.StoredAt)
		}
		fmt.Println()
		for _, alert := range alerts {
			fmt.Printf("- [%s] %s %s: %s\n", alert.Level, alert.Node, alert.Type, alert.Message)
		}
	}

	runOnce()
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			runOnce()
		case <-stop:
			fmt.Println("meshclaw monitor-agent stopped")
			return nil
		}
	}
}

func list(args []string) error {
	if wantsJSON(args) {
		return printJSON(inventory.DefaultNodes())
	}
	fmt.Printf("%-10s %-16s %-14s %-15s %-15s %s\n", "NODE", "ROLE", "LOCATION", "TAILSCALE", "WIRE", "USER")
	for _, node := range inventory.DefaultNodes() {
		fmt.Printf("%-10s %-16s %-14s %-15s %-15s %s\n", node.Name, node.Role, node.Location, node.Tailscale, node.WireIP, node.User)
	}
	return nil
}

type initReport struct {
	Kind        string     `json:"kind"`
	Status      string     `json:"status"`
	Steps       []initStep `json:"steps"`
	NextActions []string   `json:"next_actions"`
}

type initStep struct {
	Name   string `json:"name"`
	Status string `json:"status"`
	Path   string `json:"path,omitempty"`
	Detail string `json:"detail,omitempty"`
	Error  string `json:"error,omitempty"`
}

func initRuntime(args []string) error {
	jsonOut := wantsJSON(args)
	filtered := withoutJSONFlag(args)
	force := false
	for _, arg := range filtered {
		switch arg {
		case "--force":
			force = true
		default:
			return fmt.Errorf("usage: meshclaw init [--force] [--json]")
		}
	}
	report := initReport{Kind: "meshclaw_init", Status: "ok"}
	add := func(name, status, path, detail string, err error) {
		step := initStep{Name: name, Status: status, Path: path, Detail: detail}
		if err != nil {
			step.Error = err.Error()
		}
		report.Steps = append(report.Steps, step)
		if status == "fail" {
			report.Status = "fail"
		} else if status == "warn" && report.Status == "ok" {
			report.Status = "warn"
		}
	}
	home, err := os.UserHomeDir()
	if err != nil {
		add("home", "fail", "", "", err)
		return printInitReport(report, jsonOut)
	}
	root := filepath.Join(home, ".meshclaw")
	if err := os.MkdirAll(root, 0700); err != nil {
		add("config_dir", "fail", root, "", err)
	} else {
		add("config_dir", "ok", root, "", nil)
	}
	evidenceDir := filepath.Join(root, "evidence")
	if err := os.MkdirAll(evidenceDir, 0700); err != nil {
		add("evidence_dir", "fail", evidenceDir, "", err)
	} else {
		add("evidence_dir", "ok", evidenceDir, "", nil)
	}
	workflowsDir := filepath.Join(root, "workflows")
	if err := os.MkdirAll(workflowsDir, 0700); err != nil {
		add("workflows_dir", "fail", workflowsDir, "", err)
	} else {
		add("workflows_dir", "ok", workflowsDir, "", nil)
	}
	policyPath := filepath.Join(root, "policy.json")
	if _, err := os.Stat(policyPath); err == nil && !force {
		add("policy", "ok", policyPath, "already exists", nil)
	} else {
		data, err := json.MarshalIndent(policy.PresetConfig("devops"), "", "  ")
		if err != nil {
			add("policy", "fail", policyPath, "", err)
		} else if err := os.WriteFile(policyPath, append(data, '\n'), 0600); err != nil {
			add("policy", "fail", policyPath, "", err)
		} else {
			add("policy", "ok", policyPath, "preset=devops", nil)
		}
	}
	if nodes, err := inventory.InitFromDiscovery(force); err != nil {
		add("inventory", "warn", inventory.Path(), "no inventory initialized; discovery may be unavailable on this machine", err)
	} else {
		add("inventory", "ok", inventory.Path(), fmt.Sprintf("nodes=%d", len(nodes)), nil)
	}
	if root, err := guardvault.Init(); err != nil {
		add("guard_vault", "warn", guardvault.Root(), "", err)
	} else {
		add("guard_vault", "ok", root, "raw_reveal=false", nil)
	}
	if copied, err := copyExampleWorkflows(workflowsDir, force); err != nil {
		add("example_workflows", "warn", workflowsDir, "examples not copied", err)
	} else {
		add("example_workflows", "ok", workflowsDir, fmt.Sprintf("copied=%d", copied), nil)
	}
	report.NextActions = []string{
		"Run meshclaw doctor --json.",
		"Run meshclaw workflows validate fleet-health-demo --json.",
		"Run meshclaw run fleet-health-demo --dry-run.",
		"Connect Codex/Claude/Cursor to: meshclaw mcp.",
	}
	return printInitReport(report, jsonOut)
}

type quickstartReport struct {
	Kind           string                         `json:"kind"`
	Status         string                         `json:"status"`
	Workflow       string                         `json:"workflow"`
	Setup          doctor.SelfReport              `json:"setup"`
	Inspection     runtimeflow.WorkflowInspection `json:"inspection"`
	DryRun         runtimeflow.Result             `json:"dry_run"`
	Commands       []string                       `json:"commands"`
	NextActions    []string                       `json:"next_actions"`
	Warnings       []string                       `json:"warnings,omitempty"`
	EvidenceBundle string                         `json:"evidence_bundle"`
}

func quickstart(args []string) error {
	jsonOut := wantsJSON(args)
	filtered := withoutJSONFlag(args)
	if len(filtered) != 0 {
		return fmt.Errorf("usage: meshclaw quickstart [--json]")
	}
	report, err := buildQuickstartReport()
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(report)
	}
	fmt.Printf("meshclaw quickstart status=%s workflow=%s\n", report.Status, report.Workflow)
	fmt.Printf("setup=%s steps=%d dry_run_success=%t\n", report.Setup.Status, report.Inspection.Info.StepCount, report.DryRun.Success)
	fmt.Printf("evidence=%s\n", report.EvidenceBundle)
	if len(report.Warnings) > 0 {
		fmt.Println("warnings:")
		for _, warning := range report.Warnings {
			fmt.Println("- " + warning)
		}
	}
	fmt.Println("next_actions:")
	for _, action := range report.NextActions {
		fmt.Println("- " + action)
	}
	return nil
}

func buildQuickstartReport() (quickstartReport, error) {
	workflowName := "fleet-health-demo"
	setup := doctor.Self()
	inspection, err := runtimeflow.Inspect(workflowName)
	if err != nil {
		return quickstartReport{}, err
	}
	dryRun, err := runtimeflow.RunSelectedWithApprovals(workflowName, runtimeflow.DryRun, "", nil)
	if err != nil {
		return quickstartReport{}, err
	}
	report := quickstartReport{
		Kind:           "meshclaw_quickstart",
		Status:         "ok",
		Workflow:       workflowName,
		Setup:          setup,
		Inspection:     inspection,
		DryRun:         dryRun,
		EvidenceBundle: dryRun.EvidenceBundle,
		Commands: []string{
			"meshclaw setup-check --json",
			"meshclaw workflows inspect fleet-health-demo --json",
			"meshclaw run fleet-health-demo --dry-run --json",
			"meshclaw evidence open latest",
			"meshclaw mcp",
		},
		NextActions: []string{
			"Open the evidence bundle and inspect plan.md, execution.json, steps.jsonl, meshclaw-actions.md, and report.html.",
			"Connect Codex, Claude, or Cursor to meshclaw mcp and ask it to call meshclaw_ai_guide, meshclaw_doctor, and meshclaw_workflow_run.",
			"Use execute mode only after approval-required steps and vault preflight are understood.",
		},
	}
	if setup.Status != "ok" {
		report.Status = "warn"
		for _, check := range setup.Checks {
			if check.Status == "warn" || check.Status == "fail" {
				report.Warnings = append(report.Warnings, fmt.Sprintf("%s: %s", check.Name, firstNonEmpty(check.Detail, check.Next)))
			}
		}
	}
	if !dryRun.Success {
		report.Status = "fail"
	}
	return report, nil
}

func copyExampleWorkflows(targetDir string, force bool) (int, error) {
	sourceDir, err := findExampleWorkflowsDir()
	if err != nil {
		return 0, err
	}
	entries, err := os.ReadDir(sourceDir)
	if err != nil {
		return 0, err
	}
	copied := 0
	for _, entry := range entries {
		if entry.IsDir() || filepath.Ext(entry.Name()) != ".json" {
			continue
		}
		src := filepath.Join(sourceDir, entry.Name())
		dst := filepath.Join(targetDir, entry.Name())
		if !force {
			if _, err := os.Stat(dst); err == nil {
				continue
			}
		}
		data, err := os.ReadFile(src)
		if err != nil {
			return copied, err
		}
		if err := os.WriteFile(dst, data, 0600); err != nil {
			return copied, err
		}
		copied++
	}
	return copied, nil
}

func findExampleWorkflowsDir() (string, error) {
	if raw := strings.TrimSpace(os.Getenv("MESHCLAW_EXAMPLE_WORKFLOW_DIR")); raw != "" {
		return raw, nil
	}
	dir, err := os.Getwd()
	if err != nil {
		return "", err
	}
	for {
		candidate := filepath.Join(dir, "examples", "workflows")
		if stat, err := os.Stat(candidate); err == nil && stat.IsDir() {
			return candidate, nil
		}
		next := filepath.Dir(dir)
		if next == dir {
			break
		}
		dir = next
	}
	return "", fmt.Errorf("examples/workflows not found; set MESHCLAW_EXAMPLE_WORKFLOW_DIR or run from the MeshClaw repository")
}

func printInitReport(report initReport, jsonOut bool) error {
	if jsonOut {
		return printJSON(report)
	}
	fmt.Printf("meshclaw init status=%s\n", report.Status)
	for _, step := range report.Steps {
		fmt.Printf("- %s: %s", step.Name, step.Status)
		if step.Path != "" {
			fmt.Printf(" | %s", step.Path)
		}
		if step.Detail != "" {
			fmt.Printf(" | %s", step.Detail)
		}
		if step.Error != "" {
			fmt.Printf(" | error: %s", step.Error)
		}
		fmt.Println()
	}
	if len(report.NextActions) > 0 {
		fmt.Println("next_actions:")
		for _, action := range report.NextActions {
			fmt.Println("- " + action)
		}
	}
	if report.Status == "fail" {
		return fmt.Errorf("init failed")
	}
	return nil
}

func inventoryInit(args []string) error {
	jsonOut := wantsJSON(args)
	filtered := withoutJSONFlag(args)
	force := false
	for _, arg := range filtered {
		switch arg {
		case "--force":
			force = true
		default:
			return fmt.Errorf("usage: meshclaw inventory-init [--force] [--json]")
		}
	}
	nodes, err := inventory.InitFromDiscovery(force)
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{
			"path":  inventory.Path(),
			"nodes": nodes,
		})
	}
	fmt.Printf("inventory initialized path=%s nodes=%d\n", inventory.Path(), len(nodes))
	return nil
}

func inventoryDiscover(args []string) error {
	if len(withoutJSONFlag(args)) > 0 {
		return fmt.Errorf("usage: meshclaw inventory-discover [--json]")
	}
	nodes, err := inventory.Discover()
	if err != nil {
		return err
	}
	if wantsJSON(args) {
		return printJSON(nodes)
	}
	printInventoryNodes(nodes)
	return nil
}

func inventoryDiff(args []string) error {
	if len(withoutJSONFlag(args)) > 0 {
		return fmt.Errorf("usage: meshclaw inventory-diff [--json]")
	}
	diff, err := inventory.ComputeDiff()
	if err != nil {
		return err
	}
	if wantsJSON(args) {
		return printJSON(diff)
	}
	fmt.Printf("inventory path=%s current=%d discovered=%d missing=%d changed=%d unchanged=%d\n",
		diff.InventoryPath, len(diff.Current), len(diff.Discovered), len(diff.Missing), len(diff.Changed), len(diff.Unchanged))
	if len(diff.Missing) > 0 {
		fmt.Println("Missing discovered nodes:")
		printInventoryNodes(diff.Missing)
	}
	if len(diff.Changed) > 0 {
		fmt.Println("Changed discovered nodes:")
		printInventoryNodes(diff.Changed)
	}
	return nil
}

func inventoryOverride(args []string) error {
	if len(args) == 0 {
		return fmt.Errorf("usage: meshclaw inventory-override <list|set|remove> [...]")
	}
	switch args[0] {
	case "list":
		jsonOut := wantsJSON(args[1:])
		if len(withoutJSONFlag(args[1:])) != 0 {
			return fmt.Errorf("usage: meshclaw inventory-override list [--json]")
		}
		nodes, err := inventory.LoadOverrides()
		if err != nil {
			if os.IsNotExist(err) {
				nodes = []inventory.Node{}
			} else {
				return err
			}
		}
		if jsonOut {
			return printJSON(map[string]interface{}{"path": inventory.OverridesPath(), "nodes": nodes})
		}
		fmt.Printf("inventory overrides path=%s nodes=%d\n", inventory.OverridesPath(), len(nodes))
		printInventoryNodes(nodes)
		return nil
	case "set":
		return inventoryOverrideSet(args[1:])
	case "remove":
		return inventoryOverrideRemove(args[1:])
	default:
		return fmt.Errorf("usage: meshclaw inventory-override <list|set|remove> [...]")
	}
}

func inventoryOverrideSet(args []string) error {
	jsonOut := wantsJSON(args)
	filtered := withoutJSONFlag(args)
	if len(filtered) < 1 {
		return fmt.Errorf("usage: meshclaw inventory-override set <node> [--role role] [--location location] [--user user] [--tag tag]... [--json]")
	}
	node := inventory.Node{Name: filtered[0]}
	for i := 1; i < len(filtered); i++ {
		arg := filtered[i]
		next := func() (string, error) {
			i++
			if i >= len(filtered) || strings.HasPrefix(filtered[i], "--") {
				return "", fmt.Errorf("%s requires a value", arg)
			}
			return filtered[i], nil
		}
		switch arg {
		case "--role":
			value, err := next()
			if err != nil {
				return err
			}
			node.Role = value
		case "--location":
			value, err := next()
			if err != nil {
				return err
			}
			node.Location = value
		case "--user":
			value, err := next()
			if err != nil {
				return err
			}
			node.User = value
		case "--tag":
			value, err := next()
			if err != nil {
				return err
			}
			node.Tags = append(node.Tags, value)
		default:
			return fmt.Errorf("usage: meshclaw inventory-override set <node> [--role role] [--location location] [--user user] [--tag tag]... [--json]")
		}
	}
	nodes, err := inventory.SetOverride(node)
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"path": inventory.OverridesPath(), "nodes": nodes})
	}
	fmt.Printf("inventory override updated path=%s node=%s\n", inventory.OverridesPath(), node.Name)
	printInventoryNodes(nodes)
	return nil
}

func inventoryOverrideRemove(args []string) error {
	jsonOut := wantsJSON(args)
	filtered := withoutJSONFlag(args)
	if len(filtered) != 1 {
		return fmt.Errorf("usage: meshclaw inventory-override remove <node> [--json]")
	}
	nodes, removed, err := inventory.RemoveOverride(filtered[0])
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"path": inventory.OverridesPath(), "removed": removed, "nodes": nodes})
	}
	fmt.Printf("inventory override removed=%t path=%s node=%s\n", removed, inventory.OverridesPath(), strings.ToLower(filtered[0]))
	printInventoryNodes(nodes)
	return nil
}

func printInventoryNodes(nodes []inventory.Node) {
	fmt.Printf("%-10s %-16s %-14s %-15s %-15s %-12s %s\n", "NODE", "ROLE", "LOCATION", "TAILSCALE", "LAN", "USER", "TAGS")
	for _, node := range nodes {
		fmt.Printf("%-10s %-16s %-14s %-15s %-15s %-12s %s\n", node.Name, node.Role, node.Location, node.Tailscale, node.LAN, node.User, strings.Join(node.Tags, ","))
	}
}

func nodes(args []string) error {
	if len(args) == 0 {
		return fmt.Errorf("usage: meshclaw nodes <list|inspect>")
	}
	switch args[0] {
	case "list":
		jsonOut := wantsJSON(args[1:])
		if len(withoutJSONFlag(args[1:])) != 0 {
			return fmt.Errorf("usage: meshclaw nodes list [--json]")
		}
		if jsonOut {
			return printJSON(inventory.DefaultNodes())
		}
		printInventoryNodes(inventory.DefaultNodes())
		return nil
	case "inspect":
		jsonOut := wantsJSON(args[1:])
		filtered := withoutJSONFlag(args[1:])
		if len(filtered) != 1 {
			return fmt.Errorf("usage: meshclaw nodes inspect <host> [--json]")
		}
		report := workflow.SoftwareInventory(filtered[0])
		record, storeErr := evidence.Store("nodes-inspect", filtered[0], report.Status, report)
		if jsonOut {
			return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
		}
		printSoftwareInventory(report)
		printEvidenceStoreStatus(record, storeErr)
		return nil
	default:
		return fmt.Errorf("usage: meshclaw nodes <list|inspect>")
	}
}

func fleetScan(args []string) error {
	jsonOut := wantsJSON(args)
	opts, err := parseFleetScanOptions(withoutJSONFlag(args))
	if err != nil {
		return err
	}
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "fleet_scan", Resource: "server"})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	report, err := fleet.Scan(opts)
	if err != nil {
		return err
	}
	runtimeReport := buildFleetScanRuntimeReport(report)
	record, storeErr := evidence.Store("fleet-scan", "fleet", fleetScanSummary(report), runtimeReport)
	if jsonOut {
		return printJSON(map[string]interface{}{"policy": decision, "report": report, "recommended_mcp": runtimeReport.RecommendedMCP, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("fleet-scan hosts=%d alerts=%d security=%t hygiene=%t logs=%t\n", len(report.Hosts), len(report.Alerts), report.Options.Security, report.Options.Hygiene, report.Options.Logs)
	for _, host := range report.Hosts {
		status := "offline"
		if host.Online {
			status = "online"
		}
		fmt.Printf("- %s %s", host.Host, status)
		if host.Error != "" {
			fmt.Printf(" error=%s", truncate(host.Error, 80))
		}
		if host.Security != nil {
			fmt.Printf(" security=%s", host.Security.Status)
		}
		if host.Logs != nil {
			fmt.Printf(" logs=%s", host.Logs.Status)
		}
		if host.Hygiene != nil {
			fmt.Printf(" hygiene=%s", host.Hygiene.Status)
		}
		fmt.Println()
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func parseFleetScanOptions(args []string) (fleet.Options, error) {
	var opts fleet.Options
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--security":
			opts.Security = true
		case "--hygiene":
			opts.Hygiene = true
		case "--logs":
			opts.Logs = true
		case "--hosts":
			i++
			if i >= len(args) {
				return opts, fmt.Errorf("--hosts requires a comma-separated value")
			}
			opts.Hosts = splitCSV(args[i])
		case "--parallel":
			i++
			if i >= len(args) {
				return opts, fmt.Errorf("--parallel requires a number")
			}
			if _, err := fmt.Sscanf(args[i], "%d", &opts.MaxParallel); err != nil {
				return opts, fmt.Errorf("invalid --parallel value: %s", args[i])
			}
		default:
			return opts, fmt.Errorf("unknown fleet-scan option: %s", args[i])
		}
	}
	return opts, nil
}

type fleetServiceAuditReport struct {
	Hosts       []workflow.Report `json:"hosts"`
	Findings    int               `json:"findings"`
	MaxParallel int               `json:"max_parallel"`
	Time        time.Time         `json:"time"`
}

type vsshDaemonAuditReport struct {
	Items     []vsshDaemonAuditItem  `json:"items"`
	Summary   vsshDaemonAuditSummary `json:"summary"`
	Evidence  evidence.Record        `json:"evidence,omitempty"`
	StoreErr  string                 `json:"store_error,omitempty"`
	Command   string                 `json:"command"`
	Generated time.Time              `json:"generated_at"`
}

type vsshDaemonAuditSummary struct {
	HostsTotal        int `json:"hosts_total"`
	OK                int `json:"ok"`
	AuthFailed        int `json:"auth_failed"`
	Unreachable       int `json:"unreachable"`
	ProtocolMismatch  int `json:"protocol_mismatch"`
	UpgradeRequired   int `json:"upgrade_required"`
	DaemonNotReported int `json:"daemon_not_reported"`
	Failed            int `json:"failed"`
}

type vsshDaemonAuditItem struct {
	Host      string `json:"host"`
	Endpoint  string `json:"endpoint,omitempty"`
	Status    string `json:"status"`
	Version   string `json:"version,omitempty"`
	Daemon    string `json:"daemon,omitempty"`
	Error     string `json:"error,omitempty"`
	Next      string `json:"next"`
	Transport string `json:"transport,omitempty"`
}

type serviceTriageReport struct {
	Items           []serviceTriageItem  `json:"items"`
	Counts          map[string]int       `json:"counts"`
	ServiceFindings int                  `json:"service_findings"`
	RecommendedMCP  []recommendedMCPCall `json:"recommended_mcp"`
	Limit           int                  `json:"limit"`
	MaxParallel     int                  `json:"max_parallel"`
	Time            time.Time            `json:"time"`
}

type serviceTriageItem struct {
	Host      string `json:"host"`
	Service   string `json:"service"`
	Class     string `json:"class"`
	Mode      string `json:"mode"`
	Severity  string `json:"severity"`
	Judgement string `json:"judgement"`
	Next      string `json:"next"`
	Evidence  string `json:"evidence"`
}

type fleetInventoryReport struct {
	Hosts       []workflow.SoftwareInventoryReport `json:"hosts"`
	Failures    int                                `json:"failures"`
	MaxParallel int                                `json:"max_parallel"`
	Time        time.Time                          `json:"time"`
}

type placementReport struct {
	Workload     string                  `json:"workload"`
	Class        string                  `json:"class"`
	Candidates   []placementCandidate    `json:"candidates"`
	Rejected     []placementRejection    `json:"rejected"`
	Capabilities []capability.Capability `json:"capabilities"`
	Inventory    fleetInventoryReport    `json:"inventory"`
	Monitor      monitorCheckOutput      `json:"monitor"`
	GeneratedAt  time.Time               `json:"generated_at"`
}

type placementCandidate struct {
	Host         string   `json:"host"`
	Score        int      `json:"score"`
	Reasons      []string `json:"reasons"`
	Capabilities []string `json:"capabilities"`
	Actions      []string `json:"actions"`
}

type placementRejection struct {
	Host   string `json:"host"`
	Reason string `json:"reason"`
}

type orchestrationPlanReport struct {
	Scenario       string                    `json:"scenario"`
	Thesis         string                    `json:"thesis"`
	Plan           []orchestrationPlanStep   `json:"plan"`
	Workers        []orchestrationWorker     `json:"workers"`
	ToolDecisions  []orchestrationToolChoice `json:"tool_decisions"`
	DocumentChecks []orchestrationDocCheck   `json:"document_checks"`
	SecretAccess   []orchestrationSecretRule `json:"secret_access"`
	MeshClawRole   []string                  `json:"meshclaw_role"`
	Evidence       []string                  `json:"evidence"`
	Next           []string                  `json:"next"`
	GeneratedAt    time.Time                 `json:"generated_at"`
}

type orchestrationPlanStep struct {
	ID               string   `json:"id"`
	Goal             string   `json:"goal"`
	Why              string   `json:"why"`
	Nodes            []string `json:"nodes,omitempty"`
	ApprovalRequired bool     `json:"approval_required,omitempty"`
	Evidence         []string `json:"evidence,omitempty"`
}

type orchestrationWorker struct {
	Host         string   `json:"host"`
	Role         string   `json:"role"`
	Model        string   `json:"model,omitempty"`
	WhySelected  []string `json:"why_selected"`
	Instructions []string `json:"instructions"`
	Fallback     string   `json:"fallback,omitempty"`
}

type orchestrationToolChoice struct {
	Tool     string   `json:"tool"`
	Decision string   `json:"decision"`
	Reasons  []string `json:"reasons"`
}

type orchestrationDocCheck struct {
	Subject string   `json:"subject"`
	URL     string   `json:"url"`
	Why     string   `json:"why"`
	Use     []string `json:"use"`
}

type orchestrationSecretRule struct {
	Name      string `json:"name"`
	Access    string `json:"access"`
	Policy    string `json:"policy"`
	Redaction string `json:"redaction"`
}

type opsBriefReport struct {
	Monitor      monitorCheckOutput      `json:"monitor"`
	ServiceAudit fleetServiceAuditReport `json:"service_audit"`
	TopRisks     []string                `json:"top_risks"`
	NextActions  []string                `json:"next_actions"`
	Time         time.Time               `json:"time"`
}

type opsControlReport struct {
	Monitor           monitorCheckOutput       `json:"monitor"`
	ServiceAudit      fleetServiceAuditReport  `json:"service_audit"`
	ServiceTriage     serviceTriageReport      `json:"service_triage"`
	AutohealPlan      []monitor.HealPlanAction `json:"autoheal_plan"`
	AppliedSafe       []monitor.HealAction     `json:"applied_safe,omitempty"`
	PolicyPosture     []opsPolicyPosture       `json:"policy_posture"`
	TopRisks          []string                 `json:"top_risks"`
	NextActions       []string                 `json:"next_actions"`
	RecommendedMCP    []recommendedMCPCall     `json:"recommended_mcp"`
	ManagementSummary opsManagementSummary     `json:"management_summary"`
	ApplySafe         bool                     `json:"apply_safe"`
	Time              time.Time                `json:"time"`
}

type recommendedMCPCall struct {
	Tool      string                 `json:"tool"`
	Arguments map[string]interface{} `json:"arguments,omitempty"`
	Reason    string                 `json:"reason"`
	Priority  string                 `json:"priority,omitempty"`
}

type opsManagementSummary struct {
	NodesTotal         int `json:"nodes_total"`
	NodesOnline        int `json:"nodes_online"`
	NodesOffline       int `json:"nodes_offline"`
	ResourceAlerts     int `json:"resource_alerts"`
	ServiceFindings    int `json:"service_findings"`
	ServiceTriageItems int `json:"service_triage_items"`
	RealIncidents      int `json:"real_incidents"`
	AutoSafeCandidates int `json:"auto_safe_candidates"`
	ApprovalRequired   int `json:"approval_required"`
	PolicyAllows       int `json:"policy_allows"`
	PolicyApproval     int `json:"policy_approval"`
	PolicyDenies       int `json:"policy_denies"`
}

type autohealPlanReport struct {
	Actions        []monitor.HealPlanAction `json:"actions"`
	RecommendedMCP []recommendedMCPCall     `json:"recommended_mcp"`
	Counts         map[string]int           `json:"counts"`
}

type fleetScanRuntimeReport struct {
	Report         fleet.Report         `json:"report"`
	RecommendedMCP []recommendedMCPCall `json:"recommended_mcp"`
}

type opsPolicyPosture struct {
	Subject  string `json:"subject"`
	Action   string `json:"action"`
	Resource string `json:"resource"`
	Decision string `json:"decision"`
	Reason   string `json:"reason"`
}

func opsBrief(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw ops-brief [--json]")
	}
	report, record, storeErr, err := buildOpsBrief()
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("ops-brief risks=%d next=%d nodes=%d service_findings=%d\n", len(report.TopRisks), len(report.NextActions), len(report.Monitor.States), report.ServiceAudit.Findings)
	if len(report.TopRisks) > 0 {
		fmt.Println("top risks:")
		for _, risk := range report.TopRisks {
			fmt.Println("- " + risk)
		}
	} else {
		fmt.Println("top risks: none")
	}
	if len(report.NextActions) > 0 {
		fmt.Println("next actions:")
		for _, action := range report.NextActions {
			fmt.Println("- " + action)
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func buildOpsBrief() (opsBriefReport, evidence.Record, error, error) {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return opsBriefReport{}, evidence.Record{}, nil, err
	}
	states := m.CheckAll()
	monitorOut := monitorCheckOutput{States: states, Alerts: m.DetectAlerts()}
	serviceAudit, _, serviceStoreErr := runFleetServiceAudit(nil, 4)
	report := opsBriefReport{
		Monitor:      monitorOut,
		ServiceAudit: serviceAudit,
		Time:         time.Now().UTC(),
	}
	report.TopRisks, report.NextActions = briefRisksAndActions(monitorOut, serviceAudit)
	record, storeErr := evidence.Store("ops-brief", "fleet", fmt.Sprintf("risks=%d next=%d", len(report.TopRisks), len(report.NextActions)), report)
	if storeErr == nil {
		storeErr = serviceStoreErr
	}
	return report, record, storeErr, nil
}

func opsControl(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	applySafe := false
	for _, arg := range args {
		switch arg {
		case "--apply-safe":
			applySafe = true
		default:
			return fmt.Errorf("usage: meshclaw ops-control [--apply-safe] [--json]")
		}
	}
	report, record, storeErr, err := buildOpsControl(applySafe)
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Println(matrixops.FormatExplainedResult(map[string]interface{}{
		"route": "ops_control",
		"result": map[string]interface{}{
			"report": report,
		},
	}))
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func buildOpsControl(applySafe bool) (opsControlReport, evidence.Record, error, error) {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return opsControlReport{}, evidence.Record{}, nil, err
	}
	states := m.CheckAll()
	monitorOut := monitorCheckOutput{States: states, Alerts: m.DetectAlerts()}
	serviceAudit, _, serviceStoreErr := runFleetServiceAudit(nil, 4)
	serviceTriage := buildServiceTriageFromAudit(serviceAudit, 5, 4)
	healer := monitor.NewAutoHealer(m)
	plan := buildAutohealPlan(m, serviceTriage)
	report := opsControlReport{
		Monitor:       monitorOut,
		ServiceAudit:  serviceAudit,
		ServiceTriage: serviceTriage,
		AutohealPlan:  plan,
		PolicyPosture: opsPolicyPostureSummary(),
		ApplySafe:     applySafe,
		Time:          time.Now().UTC(),
	}
	report.TopRisks, report.NextActions = controlRisksAndActions(monitorOut, serviceAudit, serviceTriage, plan)
	report.ManagementSummary = summarizeOpsManagement(monitorOut, serviceAudit, serviceTriage, plan, report.PolicyPosture)
	report.RecommendedMCP = recommendedOpsControlMCP(report)
	if applySafe {
		report.AppliedSafe = healer.CheckAndHeal()
	}
	summary := fmt.Sprintf("nodes=%d alerts=%d service_findings=%d triage=%d auto_safe=%d applied=%d",
		report.ManagementSummary.NodesTotal,
		report.ManagementSummary.ResourceAlerts,
		report.ManagementSummary.ServiceFindings,
		report.ManagementSummary.ServiceTriageItems,
		report.ManagementSummary.AutoSafeCandidates,
		len(report.AppliedSafe),
	)
	record, storeErr := evidence.Store("ops-control", "fleet", summary, report)
	if storeErr == nil {
		storeErr = serviceStoreErr
	}
	return report, record, storeErr, nil
}

func summarizeOpsManagement(monitorOut monitorCheckOutput, serviceAudit fleetServiceAuditReport, serviceTriage serviceTriageReport, plan []monitor.HealPlanAction, posture []opsPolicyPosture) opsManagementSummary {
	summary := opsManagementSummary{
		NodesTotal:         len(monitorOut.States),
		ResourceAlerts:     len(monitorOut.Alerts),
		ServiceFindings:    serviceAudit.Findings,
		ServiceTriageItems: len(serviceTriage.Items),
		RealIncidents:      serviceTriage.Counts["real_incident"],
	}
	for _, state := range monitorOut.States {
		if state != nil && state.Online {
			summary.NodesOnline++
		}
	}
	summary.NodesOffline = summary.NodesTotal - summary.NodesOnline
	for _, action := range plan {
		switch action.Mode {
		case "auto_safe":
			summary.AutoSafeCandidates++
		case "requires_approval":
			summary.ApprovalRequired++
		}
	}
	summary.ApprovalRequired += serviceTriage.Counts["approval_required"]
	for _, item := range posture {
		switch item.Decision {
		case string(policy.Allow):
			summary.PolicyAllows++
		case string(policy.RequireApproval):
			summary.PolicyApproval++
		case string(policy.Deny):
			summary.PolicyDenies++
		}
	}
	return summary
}

func controlRisksAndActions(monitorOut monitorCheckOutput, serviceAudit fleetServiceAuditReport, serviceTriage serviceTriageReport, plan []monitor.HealPlanAction) ([]string, []string) {
	risks, actions := briefRisksAndActions(monitorOut, serviceAudit)
	for _, item := range serviceTriage.Items {
		if item.Class == "real_incident" {
			risks = append(risks, fmt.Sprintf("%s/service: %s real incident candidate", item.Host, item.Service))
			actions = append(actions, item.Next)
		}
		if item.Mode == "approval_required" || item.Mode == "requires_approval" {
			actions = append(actions, fmt.Sprintf("meshclaw policy-check codex service_quarantine server %s/%s", item.Host, item.Service))
		}
	}
	for _, action := range plan {
		risks = append(risks, fmt.Sprintf("%s/%s: %s %.1f mode=%s", action.Node, action.Severity, action.Metric, action.Value, action.Mode))
		if action.Mode == "auto_safe" {
			actions = append(actions, "meshclaw autoheal-apply-safe")
			continue
		}
		actions = append(actions, action.Command)
	}
	return limitStrings(uniqueStrings(risks), 8), limitStrings(uniqueStrings(actions), 8)
}

func recommendedOpsControlMCP(report opsControlReport) []recommendedMCPCall {
	calls := []recommendedMCPCall{}
	add := func(tool, reason, priority string, args map[string]interface{}) {
		if tool == "" {
			return
		}
		for _, existing := range calls {
			if existing.Tool == tool && sameMCPArguments(existing.Arguments, args) {
				return
			}
		}
		calls = append(calls, recommendedMCPCall{Tool: tool, Arguments: args, Reason: reason, Priority: priority})
	}

	for _, item := range report.ServiceTriage.Items {
		if item.Class == "real_incident" {
			add("meshclaw_service_check", "real service incident candidate needs focused service evidence", "high", map[string]interface{}{"host": item.Host, "service": item.Service})
			add("meshclaw_analyze_logs", "real service incident should be paired with recent logs before any remediation", "high", map[string]interface{}{"host": item.Host, "source": "system"})
			break
		}
	}
	if report.ManagementSummary.ServiceFindings > 0 {
		add("meshclaw_service_triage", "service findings should be classified before restart, quarantine, or cleanup decisions", "high", map[string]interface{}{"limit": 5, "max_parallel": 4})
	}
	for _, alert := range report.Monitor.Alerts {
		switch alert.Type {
		case "disk":
			add("meshclaw_disk_investigate", "disk alerts need read-only evidence before cleanup planning", "high", map[string]interface{}{"host": alert.Node, "path": "/"})
		case "memory":
			add("meshclaw_process_top", "memory alerts need top process evidence before remediation", "medium", map[string]interface{}{"host": alert.Node})
		case "offline":
			add("meshclaw_node_repair_plan", "offline nodes need a repair plan before direct intervention", "high", map[string]interface{}{"hosts": alert.Node})
		}
	}
	if report.ManagementSummary.AutoSafeCandidates > 0 {
		add("meshclaw_autoheal_plan", "safe remediation candidates should be reviewed as a plan before apply-safe", "medium", map[string]interface{}{})
	}
	if report.ManagementSummary.ApprovalRequired > 0 {
		add("meshclaw_policy_check", "approval-required actions need an explicit policy decision before execution", "high", map[string]interface{}{"subject": "codex", "action": "autoheal_apply_safe", "resource": "server", "context": "ops-control approval-required follow-up"})
	}
	if len(calls) == 0 {
		add("meshclaw_monitor_check", "fleet is healthy; refresh monitor state before taking new action", "low", map[string]interface{}{})
	}
	add("meshclaw_evidence_latest", "inspect the latest evidence bundle before continuing or reporting to a human", "low", map[string]interface{}{"actions_preview_bytes": 4000})
	return limitRecommendedMCPCalls(calls, 8)
}

func recommendedServiceTriageMCP(report serviceTriageReport) []recommendedMCPCall {
	calls := []recommendedMCPCall{}
	add := func(tool, reason, priority string, args map[string]interface{}) {
		if tool == "" {
			return
		}
		for _, existing := range calls {
			if existing.Tool == tool && sameMCPArguments(existing.Arguments, args) {
				return
			}
		}
		calls = append(calls, recommendedMCPCall{Tool: tool, Arguments: args, Reason: reason, Priority: priority})
	}

	for _, item := range report.Items {
		switch item.Class {
		case "real_incident":
			add("meshclaw_service_check", "real incident candidate needs focused unit state before remediation", "high", map[string]interface{}{"host": item.Host, "service": item.Service})
			add("meshclaw_analyze_logs", "real incident candidate needs recent logs before restart or rollback", "high", map[string]interface{}{"host": item.Host, "source": "system"})
		case "stale_or_missing_target":
			add("meshclaw_service_check", "stale service candidate needs one focused confirmation before quarantine approval", "high", map[string]interface{}{"host": item.Host, "service": item.Service})
			add("meshclaw_policy_check", "service quarantine is approval-required and must pass policy before apply", "high", map[string]interface{}{"subject": "codex", "action": "service_quarantine", "resource": "server", "context": item.Host + "/" + item.Service})
		case "approval_required":
			add("meshclaw_node_repair_plan", "service status lookup failed; repair node execution health before service remediation", "high", map[string]interface{}{"hosts": item.Host})
		case "needs_manual_audit":
			add("meshclaw_service_audit", "service name could not be extracted; collect host service audit evidence", "medium", map[string]interface{}{"host": item.Host})
		}
		if len(calls) >= 7 {
			break
		}
	}
	if len(calls) == 0 && report.ServiceFindings > 0 {
		add("meshclaw_fleet_service_audit", "refresh service audit evidence before changing service state", "medium", map[string]interface{}{"max_parallel": report.MaxParallel})
	}
	if len(calls) == 0 {
		add("meshclaw_monitor_check", "no actionable service items remain; refresh fleet monitor state", "low", map[string]interface{}{})
	}
	add("meshclaw_evidence_latest", "inspect service triage evidence before continuing or reporting to a human", "low", map[string]interface{}{"actions_preview_bytes": 4000})
	return limitRecommendedMCPCalls(calls, 8)
}

func recommendedAutohealPlanMCP(actions []monitor.HealPlanAction) []recommendedMCPCall {
	calls := []recommendedMCPCall{}
	add := func(tool, reason, priority string, args map[string]interface{}) {
		if tool == "" {
			return
		}
		for _, existing := range calls {
			if existing.Tool == tool && sameMCPArguments(existing.Arguments, args) {
				return
			}
		}
		calls = append(calls, recommendedMCPCall{Tool: tool, Arguments: args, Reason: reason, Priority: priority})
	}

	autoSafeAllowed := false
	for _, action := range actions {
		if action.Mode == "auto_safe" && action.PolicyDecision == string(policy.Allow) && !action.ApprovalRequired {
			autoSafeAllowed = true
		}
		if action.ApprovalRequired || action.PolicyDecision == string(policy.RequireApproval) {
			add("meshclaw_policy_check", "plan action requires explicit approval before execution", "high", map[string]interface{}{"subject": "codex", "action": action.PolicyAction, "resource": "server", "context": action.Command})
		}
		switch action.Type {
		case "disk_investigate":
			add("meshclaw_disk_investigate", "disk plan action is read-only evidence collection before cleanup", "high", map[string]interface{}{"host": action.Node, "path": "/"})
		case "connectivity":
			add("meshclaw_node_repair_plan", "connectivity plan action needs node execution repair planning", "high", map[string]interface{}{"hosts": action.Node})
		case "service_triage":
			service := strings.TrimPrefix(action.Metric, "service:")
			add("meshclaw_service_check", "service triage plan action needs focused service evidence", "high", map[string]interface{}{"host": action.Node, "service": service})
		case "service_quarantine_candidate":
			service := strings.TrimPrefix(action.Metric, "service:")
			add("meshclaw_service_check", "quarantine candidate needs focused confirmation before approval", "high", map[string]interface{}{"host": action.Node, "service": service})
		}
		if len(calls) >= 7 {
			break
		}
	}
	if autoSafeAllowed {
		add("meshclaw_autoheal_apply_safe", "auto-safe actions are policy-allowed and can be applied through the bounded safe executor", "medium", map[string]interface{}{})
	}
	if len(calls) == 0 {
		add("meshclaw_monitor_check", "no autoheal actions remain; refresh fleet state before new remediation", "low", map[string]interface{}{})
	}
	add("meshclaw_evidence_latest", "inspect autoheal plan evidence before applying or reporting", "low", map[string]interface{}{"actions_preview_bytes": 4000})
	return limitRecommendedMCPCalls(calls, 8)
}

func buildFleetScanRuntimeReport(report fleet.Report) fleetScanRuntimeReport {
	return fleetScanRuntimeReport{
		Report:         report,
		RecommendedMCP: recommendedFleetScanMCP(report),
	}
}

func recommendedFleetScanMCP(report fleet.Report) []recommendedMCPCall {
	calls := []recommendedMCPCall{}
	add := func(tool, reason, priority string, args map[string]interface{}) {
		if tool == "" {
			return
		}
		for _, existing := range calls {
			if existing.Tool == tool && sameMCPArguments(existing.Arguments, args) {
				return
			}
		}
		calls = append(calls, recommendedMCPCall{Tool: tool, Arguments: args, Reason: reason, Priority: priority})
	}

	for _, alert := range report.Alerts {
		if !fleetScanIncludesHost(report, alert.Node) {
			continue
		}
		switch alert.Type {
		case "disk":
			add("meshclaw_disk_investigate", "fleet scan detected disk pressure; collect read-only disk evidence before cleanup", "high", map[string]interface{}{"host": alert.Node, "path": "/"})
		case "memory":
			add("meshclaw_process_top", "fleet scan detected memory pressure; collect top process evidence before remediation", "medium", map[string]interface{}{"host": alert.Node})
		case "offline":
			add("meshclaw_node_repair_plan", "fleet scan detected an offline node; classify execution health before intervention", "high", map[string]interface{}{"hosts": alert.Node})
		}
	}
	for _, host := range report.Hosts {
		if !host.Online {
			add("meshclaw_node_repair_plan", "host is offline or missing monitor state; repair planning should precede remote execution", "high", map[string]interface{}{"hosts": host.Host})
			continue
		}
		if workflowHasActionableFindings(host.Security) {
			add("meshclaw_security_check", "security scan has warning/error findings; refresh focused security evidence for this host", "high", map[string]interface{}{"host": host.Host})
		}
		if workflowHasActionableFindings(host.Logs) {
			add("meshclaw_analyze_logs", "log scan has warning/error findings; collect focused redacted log evidence", "medium", map[string]interface{}{"host": host.Host, "source": "system"})
		}
		if hygieneHasActionableFindings(host.Hygiene) {
			add("meshclaw_hygiene_scan_host", "hygiene scan found possible secret/PII exposure; collect redacted host hygiene evidence", "high", map[string]interface{}{"host": host.Host})
		}
		if len(calls) >= 7 {
			break
		}
	}
	if len(calls) == 0 {
		add("meshclaw_monitor_check", "fleet scan has no actionable follow-up; refresh monitor state before new action", "low", map[string]interface{}{})
	}
	add("meshclaw_evidence_latest", "inspect fleet-scan evidence before reporting or taking action", "low", map[string]interface{}{"actions_preview_bytes": 4000})
	return limitRecommendedMCPCalls(calls, 8)
}

func recommendedNodeRepairPlanMCP(report nodeRepairPlanReport) []recommendedMCPCall {
	calls := []recommendedMCPCall{}
	add := func(tool, reason, priority string, args map[string]interface{}) {
		if tool == "" {
			return
		}
		for _, existing := range calls {
			if existing.Tool == tool && sameMCPArguments(existing.Arguments, args) {
				return
			}
		}
		calls = append(calls, recommendedMCPCall{Tool: tool, Arguments: args, Reason: reason, Priority: priority})
	}

	for _, host := range report.Hosts {
		switch {
		case host.DaemonStatus == "auth_failed":
			add("meshclaw_vssh_auth_paths", "daemon rejected authentication; compare client binary, secret source, run-many, and facts paths", "high", map[string]interface{}{"hosts": host.Host})
			add("meshclaw_policy_check", "secret alignment or daemon restart is root-owned and must be approval-gated", "high", map[string]interface{}{"subject": "codex", "action": "run_command", "resource": "server", "context": "align vssh secret and restart vsshd on " + host.Host})
		case host.DaemonStatus == "protocol_mismatch" || host.DaemonStatus == "upgrade_required" || host.AuthDecision == "partial":
			add("meshclaw_vssh_auth_paths", "protocol mismatch or partial native path needs binary/secret path comparison", "high", map[string]interface{}{"hosts": host.Host})
			add("meshclaw_vssh_daemon_audit", "daemon protocol status should be rechecked after any upgrade or restart", "high", map[string]interface{}{"hosts": host.Host})
			add("meshclaw_policy_check", "daemon binary replacement is root-owned and must be approval-gated", "high", map[string]interface{}{"subject": "codex", "action": "run_command", "resource": "server", "context": "upgrade vsshd on " + host.Host})
		case host.DaemonStatus == "unreachable":
			add("meshclaw_node_inventory", "unreachable daemon needs read-only software and listener inventory before repair", "high", map[string]interface{}{"host": host.Host})
			add("meshclaw_vssh_daemon_audit", "recheck daemon reachability with a focused host audit", "high", map[string]interface{}{"hosts": host.Host})
		case host.Severity == "inspect" || host.DaemonStatus == "failed" || host.DaemonStatus == "unknown":
			add("meshclaw_node_inventory", "unclassified node repair state needs inventory before mutation", "medium", map[string]interface{}{"host": host.Host})
			add("meshclaw_vssh_auth_paths", "unclassified node repair state needs native path comparison", "medium", map[string]interface{}{"hosts": host.Host})
		}
		if len(calls) >= 7 {
			break
		}
	}
	if len(calls) == 0 {
		add("meshclaw_monitor_check", "node repair plan is healthy; refresh monitor state before new action", "low", map[string]interface{}{})
	}
	add("meshclaw_evidence_latest", "inspect node repair plan evidence before applying root-owned changes", "low", map[string]interface{}{"actions_preview_bytes": 4000})
	return limitRecommendedMCPCalls(calls, 8)
}

func workflowHasActionableFindings(report *workflow.Report) bool {
	if report == nil {
		return false
	}
	if report.Status == "failed" || report.Status == "unknown_node" {
		return true
	}
	for _, finding := range report.Findings {
		if finding.Severity == "warning" || finding.Severity == "error" || finding.Severity == "critical" {
			return true
		}
	}
	return false
}

func fleetScanIncludesHost(report fleet.Report, host string) bool {
	if len(report.Options.Hosts) == 0 {
		return true
	}
	for _, selected := range report.Options.Hosts {
		if selected == host {
			return true
		}
	}
	return false
}

func hygieneHasActionableFindings(report *hygiene.Report) bool {
	if report == nil {
		return false
	}
	if report.Status == "failed" || report.Status == "unknown_node" || report.Status == "findings" {
		return len(report.Findings) > 0
	}
	for _, finding := range report.Findings {
		if finding.Severity == "medium" || finding.Severity == "high" || finding.Severity == "critical" || finding.Severity == "error" {
			return true
		}
	}
	return false
}

func sameMCPArguments(a, b map[string]interface{}) bool {
	if len(a) != len(b) {
		return false
	}
	for key, av := range a {
		if fmt.Sprint(av) != fmt.Sprint(b[key]) {
			return false
		}
	}
	return true
}

func limitRecommendedMCPCalls(calls []recommendedMCPCall, limit int) []recommendedMCPCall {
	if len(calls) <= limit {
		return calls
	}
	if limit <= 0 {
		return nil
	}
	last := calls[len(calls)-1]
	if last.Tool == "meshclaw_evidence_latest" && limit > 1 {
		out := make([]recommendedMCPCall, 0, limit)
		out = append(out, calls[:limit-1]...)
		out = append(out, last)
		return out
	}
	return calls[:limit]
}

func opsPolicyPostureSummary() []opsPolicyPosture {
	checks := []policy.Request{
		{Subject: "codex", Action: "read_state", Resource: "server"},
		{Subject: "claude", Action: "read_state", Resource: "server"},
		{Subject: "local-llm", Action: "run_command", Resource: "server", Context: "systemctl restart"},
		{Subject: "automation", Action: "autoheal_apply_safe", Resource: "server"},
		{Subject: "codex", Action: "provision_server", Resource: "provider"},
		{Subject: "local-llm", Action: "run_command", Resource: "server", Context: "cat /etc/shadow"},
	}
	out := make([]opsPolicyPosture, 0, len(checks))
	for _, req := range checks {
		decision := policy.Evaluate(req)
		out = append(out, opsPolicyPosture{
			Subject:  req.Subject,
			Action:   req.Action,
			Resource: req.Resource,
			Decision: string(decision.Decision),
			Reason:   decision.Reason,
		})
	}
	return out
}

func briefRisksAndActions(monitorOut monitorCheckOutput, serviceAudit fleetServiceAuditReport) ([]string, []string) {
	risks := []string{}
	actions := []string{}
	for _, alert := range monitorOut.Alerts {
		risks = append(risks, fmt.Sprintf("%s/%s: %s", alert.Node, alert.Level, alert.Message))
		switch alert.Type {
		case "disk":
			actions = append(actions, fmt.Sprintf("meshclaw disk-investigate %s /", alert.Node))
		case "memory":
			actions = append(actions, fmt.Sprintf("meshclaw process-top %s", alert.Node))
		case "offline":
			actions = append(actions, fmt.Sprintf("meshclaw doctor %s", alert.Node))
		}
	}
	for _, host := range serviceAudit.Hosts {
		if host.Status == "ok" {
			continue
		}
		service := serviceFromAuditReport(host)
		if service == "" {
			risks = append(risks, fmt.Sprintf("%s/service: failed or restarting service evidence", host.Host))
			actions = append(actions, fmt.Sprintf("meshclaw service-audit %s", host.Host))
			continue
		}
		risks = append(risks, fmt.Sprintf("%s/service: %s needs review", host.Host, service))
		actions = append(actions, fmt.Sprintf("meshclaw service-check %s %s", host.Host, service))
	}
	return limitStrings(uniqueStrings(risks), 5), limitStrings(uniqueStrings(actions), 5)
}

func serviceFromAuditReport(report workflow.Report) string {
	for _, finding := range report.Findings {
		text := finding.Evidence + "\n" + finding.Next
		for _, token := range strings.Fields(text) {
			token = strings.Trim(token, "`'\".,:;()[]{}")
			if strings.HasSuffix(token, ".service") {
				return strings.TrimSuffix(token, ".service")
			}
		}
	}
	return ""
}

func uniqueStrings(values []string) []string {
	seen := map[string]bool{}
	out := make([]string, 0, len(values))
	for _, value := range values {
		if value == "" || seen[value] {
			continue
		}
		seen[value] = true
		out = append(out, value)
	}
	return out
}

func limitStrings(values []string, limit int) []string {
	if len(values) <= limit {
		return values
	}
	return values[:limit]
}

func fleetServiceAudit(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	hosts, parallel, err := parseFleetServiceAuditOptions(args)
	if err != nil {
		return err
	}
	if len(hosts) == 0 {
		for _, node := range inventory.DefaultNodes() {
			if nodeHasTag(node, "linux") {
				hosts = append(hosts, node.Name)
			}
		}
	}
	if parallel <= 0 {
		parallel = 4
	}
	report, record, storeErr := runFleetServiceAudit(hosts, parallel)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("fleet-service-audit hosts=%d findings=%d parallel=%d\n", len(report.Hosts), report.Findings, parallel)
	for _, hostReport := range report.Hosts {
		fmt.Printf("- %s status=%s issues=%d\n", hostReport.Host, hostReport.Status, workflowIssueCount(hostReport))
		for _, finding := range hostReport.Findings {
			if finding.Severity == "info" && hostReport.Status == "ok" {
				continue
			}
			fmt.Printf("  [%s] %s\n  next: %s\n", finding.Severity, finding.Title, finding.Next)
			break
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func runFleetServiceAudit(hosts []string, parallel int) (fleetServiceAuditReport, evidence.Record, error) {
	if len(hosts) == 0 {
		for _, node := range inventory.DefaultNodes() {
			if nodeHasTag(node, "linux") {
				hosts = append(hosts, node.Name)
			}
		}
	}
	if parallel <= 0 {
		parallel = 4
	}
	report := fleetServiceAuditReport{MaxParallel: parallel, Time: time.Now().UTC()}
	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, parallel)
	for _, host := range hosts {
		host := host
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			hostReport := workflow.ServiceAudit(host)
			mu.Lock()
			report.Hosts = append(report.Hosts, hostReport)
			if hostReport.Status == "findings" || hostReport.Status == "failed" || hostReport.Status == "unknown_node" {
				report.Findings++
			}
			mu.Unlock()
		}()
	}
	wg.Wait()
	sort.Slice(report.Hosts, func(i, j int) bool { return report.Hosts[i].Host < report.Hosts[j].Host })
	record, storeErr := evidence.Store("fleet-service-audit", "fleet", fmt.Sprintf("hosts=%d findings=%d", len(report.Hosts), report.Findings), report)
	return report, record, storeErr
}

func vsshDaemonAudit(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	hosts, err := parseHostsOnlyOptions(args, "vssh-daemon-audit")
	if err != nil {
		return err
	}
	report, storeErr, err := buildVSSHDaemonAudit(hosts)
	if err != nil {
		return err
	}
	report.StoreErr = errString(storeErr)
	if jsonOut {
		return printJSON(report)
	}
	fmt.Printf("vssh-daemon-audit hosts=%d ok=%d auth_failed=%d unreachable=%d upgrade_required=%d failed=%d\n",
		report.Summary.HostsTotal,
		report.Summary.OK,
		report.Summary.AuthFailed,
		report.Summary.Unreachable,
		report.Summary.UpgradeRequired,
		report.Summary.Failed,
	)
	for _, item := range report.Items {
		fmt.Printf("- %s status=%s version=%s daemon=%s\n", item.Host, item.Status, item.Version, item.Daemon)
		if item.Error != "" {
			fmt.Println("  error: " + item.Error)
		}
		if item.Next != "" {
			fmt.Println("  next: " + item.Next)
		}
	}
	printEvidenceStoreStatus(report.Evidence, storeErr)
	return nil
}

type vsshAuthFixPlanReport struct {
	Generated time.Time               `json:"generated"`
	Summary   vsshDaemonAuditSummary  `json:"summary"`
	Decision  string                  `json:"decision"`
	Actions   []vsshAuthFixPlanAction `json:"actions"`
	Evidence  evidence.Record         `json:"evidence"`
	StoreErr  string                  `json:"store_error,omitempty"`
}

type vsshAuthFixPlanAction struct {
	Host      string `json:"host"`
	Status    string `json:"status"`
	Risk      string `json:"risk"`
	Mode      string `json:"mode"`
	Command   string `json:"command"`
	Reason    string `json:"reason"`
	Aftercare string `json:"aftercare"`
}

func vsshAuthFixPlan(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	hosts, err := parseHostsOnlyOptions(args, "vssh-auth-fix-plan")
	if err != nil {
		return err
	}
	report, storeErr, err := buildVSSHAuthFixPlan(hosts)
	if err != nil {
		return err
	}
	report.StoreErr = errString(storeErr)
	if jsonOut {
		return printJSON(report)
	}
	fmt.Printf("vssh-auth-fix-plan decision=%s auth_failed=%d unreachable=%d actions=%d\n", report.Decision, report.Summary.AuthFailed, report.Summary.Unreachable, len(report.Actions))
	for _, action := range report.Actions {
		fmt.Printf("- %s status=%s mode=%s risk=%s\n  reason: %s\n  command: %s\n  after: %s\n", action.Host, action.Status, action.Mode, action.Risk, action.Reason, action.Command, action.Aftercare)
	}
	printEvidenceStoreStatus(report.Evidence, storeErr)
	return nil
}

type vsshAuthPathsReport struct {
	Generated     time.Time          `json:"generated"`
	Binary        string             `json:"binary"`
	BinaryVersion string             `json:"binary_version"`
	PathBinary    string             `json:"path_binary,omitempty"`
	PathVersion   string             `json:"path_version,omitempty"`
	Secret        vsshSecretSummary  `json:"secret"`
	Hosts         []vsshAuthPathHost `json:"hosts"`
	Summary       map[string]int     `json:"summary"`
}

type vsshSecretSummary struct {
	EnvSet      bool   `json:"env_set"`
	UserFile    bool   `json:"user_file"`
	SystemFile  bool   `json:"system_file"`
	Effective   string `json:"effective"`
	Description string `json:"description"`
}

type vsshAuthPathHost struct {
	Host       string `json:"host"`
	RunManyOK  bool   `json:"run_many_ok"`
	RunManyErr string `json:"run_many_error,omitempty"`
	FactsOK    bool   `json:"facts_ok"`
	FactsErr   string `json:"facts_error,omitempty"`
	Decision   string `json:"decision"`
	Next       string `json:"next,omitempty"`
}

type nodeRepairPlanReport struct {
	Generated      time.Time            `json:"generated"`
	Decision       string               `json:"decision"`
	Summary        map[string]int       `json:"summary"`
	Hosts          []nodeRepairPlanHost `json:"hosts"`
	RecommendedMCP []recommendedMCPCall `json:"recommended_mcp"`
	Evidence       evidence.Record      `json:"evidence,omitempty"`
	StoreErr       string               `json:"store_error,omitempty"`
}

type nodeRepairPlanHost struct {
	Host            string                 `json:"host"`
	Endpoint        string                 `json:"endpoint,omitempty"`
	User            string                 `json:"user,omitempty"`
	Role            string                 `json:"role,omitempty"`
	Tags            []string               `json:"tags,omitempty"`
	DaemonStatus    string                 `json:"daemon_status"`
	AuthDecision    string                 `json:"auth_decision"`
	Diagnosis       string                 `json:"diagnosis"`
	Severity        string                 `json:"severity"`
	RequiresRoot    bool                   `json:"requires_root"`
	Actions         []nodeRepairPlanAction `json:"actions"`
	OperatorSummary string                 `json:"operator_summary"`
}

type nodeRepairPlanAction struct {
	ID        string `json:"id"`
	Mode      string `json:"mode"`
	Risk      string `json:"risk"`
	Command   string `json:"command"`
	Reason    string `json:"reason"`
	Aftercare string `json:"aftercare"`
}

func nodeRepairPlan(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	hosts, err := parseHostsOnlyOptions(args, "node-repair-plan")
	if err != nil {
		return err
	}
	report, storeErr, err := buildNodeRepairPlan(hosts)
	if err != nil {
		return err
	}
	report.StoreErr = errString(storeErr)
	if jsonOut {
		return printJSON(report)
	}
	fmt.Printf("node-repair-plan decision=%s hosts=%d healthy=%d repair=%d blocked=%d\n",
		report.Decision,
		len(report.Hosts),
		report.Summary["healthy"],
		report.Summary["repair"],
		report.Summary["blocked"],
	)
	for _, host := range report.Hosts {
		fmt.Printf("- %s severity=%s daemon=%s auth=%s root=%t\n  %s\n",
			host.Host, host.Severity, host.DaemonStatus, host.AuthDecision, host.RequiresRoot, host.OperatorSummary)
		for _, action := range host.Actions {
			fmt.Printf("  [%s] mode=%s risk=%s\n    command: %s\n    after: %s\n", action.ID, action.Mode, action.Risk, action.Command, action.Aftercare)
		}
	}
	printEvidenceStoreStatus(report.Evidence, storeErr)
	return nil
}

func buildNodeRepairPlan(hosts []string) (nodeRepairPlanReport, error, error) {
	if len(hosts) == 0 {
		for _, node := range inventory.DefaultNodes() {
			if nodeHasTag(node, "client") {
				continue
			}
			hosts = append(hosts, node.Name)
		}
	}
	audit := buildQuickVSSHDaemonAudit(hosts, 3*time.Second)
	auth := buildVSSHAuthPathsWithTimeout(hosts, 3*time.Second)
	auditByHost := map[string]vsshDaemonAuditItem{}
	for _, item := range audit.Items {
		auditByHost[item.Host] = item
	}
	authByHost := map[string]vsshAuthPathHost{}
	for _, item := range auth.Hosts {
		authByHost[item.Host] = item
	}
	report := nodeRepairPlanReport{
		Generated: time.Now().UTC(),
		Decision:  "healthy",
		Summary:   map[string]int{"healthy": 0, "repair": 0, "blocked": 0, "inspect": 0},
	}
	for _, host := range hosts {
		node, _ := inventory.Find(host)
		item := buildNodeRepairHost(node, auditByHost[host], authByHost[host])
		report.Hosts = append(report.Hosts, item)
		switch item.Severity {
		case "healthy":
			report.Summary["healthy"]++
		case "blocked":
			report.Summary["blocked"]++
			report.Decision = decisionWithPriority(report.Decision, "requires_operator_root_action")
		case "repair":
			report.Summary["repair"]++
			if report.Decision == "healthy" {
				report.Decision = "repair_available"
			}
		default:
			report.Summary["inspect"]++
			if report.Decision == "healthy" {
				report.Decision = "inspect_required"
			}
		}
	}
	report.RecommendedMCP = recommendedNodeRepairPlanMCP(report)
	record, storeErr := evidence.Store("node-repair-plan", "fleet", fmt.Sprintf("decision=%s hosts=%d", report.Decision, len(report.Hosts)), report)
	report.Evidence = record
	return report, storeErr, nil
}

func buildQuickVSSHDaemonAudit(hosts []string, timeout time.Duration) vsshDaemonAuditReport {
	if len(hosts) == 0 {
		for _, node := range inventory.DefaultNodes() {
			if nodeHasTag(node, "client") {
				continue
			}
			hosts = append(hosts, node.Name)
		}
	}
	command := vsshDaemonAuditCommand()
	report := vsshDaemonAuditReport{Command: command, Generated: time.Now().UTC()}
	for _, host := range hosts {
		target := vsshNativeTargetForHost(host)
		results, err := runVSSHMany([]string{target}, command, timeout)
		if err != nil {
			item := vsshDaemonAuditItem{
				Host:      host,
				Status:    classifyVSSHConnectionError(err.Error()),
				Error:     err.Error(),
				Next:      nextForVSSHStatus(host, classifyVSSHConnectionError(err.Error())),
				Transport: "vssh-native",
			}
			if node, ok := inventory.Find(host); ok {
				item.Endpoint = node.Tailscale
			}
			report.Items = append(report.Items, item)
			updateVSSHDaemonSummary(&report.Summary, item)
			continue
		}
		if len(results) == 0 {
			item := vsshDaemonAuditItem{
				Host:      host,
				Status:    "failed",
				Error:     "empty vssh run-many result",
				Next:      nextForVSSHStatus(host, "failed"),
				Transport: "vssh-native",
			}
			report.Items = append(report.Items, item)
			updateVSSHDaemonSummary(&report.Summary, item)
			continue
		}
		item := classifyVSSHDaemonAudit(results[0])
		item.Host = host
		item.Next = nextForVSSHStatus(item.Host, item.Status)
		report.Items = append(report.Items, item)
		updateVSSHDaemonSummary(&report.Summary, item)
	}
	sort.Slice(report.Items, func(i, j int) bool { return report.Items[i].Host < report.Items[j].Host })
	report.Summary.HostsTotal = len(report.Items)
	return report
}

func buildNodeRepairHost(node inventory.Node, daemon vsshDaemonAuditItem, auth vsshAuthPathHost) nodeRepairPlanHost {
	host := node.Name
	if host == "" {
		host = daemon.Host
	}
	if host == "" {
		host = auth.Host
	}
	item := nodeRepairPlanHost{
		Host:         host,
		Endpoint:     firstNonEmpty(node.Tailscale, node.WireIP, daemon.Endpoint),
		User:         node.User,
		Role:         node.Role,
		Tags:         node.Tags,
		DaemonStatus: firstNonEmpty(daemon.Status, "unknown"),
		AuthDecision: firstNonEmpty(auth.Decision, "unknown"),
		Severity:     "inspect",
	}
	target := sshTargetForNode(host)
	artifact := vsshArtifactForNode(node)
	switch {
	case daemon.Status == "ok" && auth.Decision == "ok":
		item.Severity = "healthy"
		item.Diagnosis = "vssh daemon, facts, and run-many paths are aligned."
		item.OperatorSummary = "Healthy. No action is required."
	case daemon.Status == "protocol_mismatch" || daemon.Status == "upgrade_required" || auth.Decision == "partial":
		item.Severity = "blocked"
		item.RequiresRoot = true
		item.Diagnosis = "The user-level vssh path works partially, but the daemon protocol or root-owned daemon binary is stale."
		item.OperatorSummary = "Upgrade the daemon binary and restart vsshd. This usually needs sudo/root on the target."
		item.Actions = append(item.Actions,
			nodeRepairPlanAction{
				ID:        "inspect_versions",
				Mode:      "read_only",
				Risk:      "low",
				Command:   fmt.Sprintf("ssh %s 'command -v vssh || true; vssh version 2>/dev/null || true; /usr/local/bin/vssh version 2>/dev/null || true; ~/.local/bin/vssh version 2>/dev/null || true; pgrep -af \"vssh .*server|vsshd\" || true'", target),
				Reason:    "Show which binary the daemon and shell paths are using.",
				Aftercare: fmt.Sprintf("meshclaw vssh-auth-paths --hosts %s", host),
			},
			nodeRepairPlanAction{
				ID:        "upload_user_binary",
				Mode:      "safe_apply",
				Risk:      "low",
				Command:   fmt.Sprintf("%s && scp -O %s %s:/tmp/vssh && ssh %s 'mkdir -p ~/.local/bin && install -m 0755 /tmp/vssh ~/.local/bin/vssh && ~/.local/bin/vssh version'", artifact.Prepare, artifact.Path, target, target),
				Reason:    "Install the current vssh binary in the user path without touching root-owned files.",
				Aftercare: fmt.Sprintf("meshclaw vssh-auth-paths --hosts %s", host),
			},
			nodeRepairPlanAction{
				ID:        "replace_root_daemon",
				Mode:      "requires_root",
				Risk:      "medium",
				Command:   fmt.Sprintf("%s && scp -O %s %s:/tmp/vssh && ssh %s 'sudo install -m 0755 /tmp/vssh /usr/local/bin/vssh && (sudo systemctl restart vsshd || sudo systemctl restart vssh)'", artifact.Prepare, artifact.Path, target, target),
				Reason:    "The running daemon must use the same protocol version as the MCP client.",
				Aftercare: fmt.Sprintf("meshclaw vssh-daemon-audit --hosts %s && meshclaw vssh-auth-paths --hosts %s", host, host),
			},
		)
	case daemon.Status == "unreachable":
		item.Severity = "blocked"
		item.RequiresRoot = true
		item.Diagnosis = "The node is in inventory but the current vssh-native client cannot complete the daemon probe. The daemon may be stopped, firewalled, or too old to speak the current protocol."
		item.OperatorSummary = "Inspect the listener first. If SSH works and an old vssh is present, upload the target OS artifact and replace/restart the root daemon."
		item.Actions = append(item.Actions,
			nodeRepairPlanAction{
				ID:        "inspect_listener",
				Mode:      "read_only",
				Risk:      "low",
				Command:   fmt.Sprintf("ssh %s 'hostname; command -v vssh || true; pgrep -af \"vssh .*server|vsshd\" || true; (ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | grep 48291 || true'", target),
				Reason:    "Check whether vssh is installed and listening on the native RPC port.",
				Aftercare: fmt.Sprintf("meshclaw node-inventory %s", host),
			},
			nodeRepairPlanAction{
				ID:        "upload_user_binary",
				Mode:      "safe_apply",
				Risk:      "low",
				Command:   fmt.Sprintf("%s && scp -O %s %s:/tmp/vssh && ssh %s 'mkdir -p ~/.local/bin && install -m 0755 /tmp/vssh ~/.local/bin/vssh && ~/.local/bin/vssh version'", artifact.Prepare, artifact.Path, target, target),
				Reason:    "Stage the correct OS/architecture vssh binary without touching root-owned daemon files.",
				Aftercare: fmt.Sprintf("meshclaw vssh-auth-paths --hosts %s", host),
			},
			nodeRepairPlanAction{
				ID:        "bootstrap_vsshd",
				Mode:      "requires_root",
				Risk:      "medium",
				Command:   fmt.Sprintf("%s && scp -O %s %s:/tmp/vssh && ssh %s 'sudo install -m 0755 /tmp/vssh /usr/local/bin/vssh && sudo test -s /etc/vssh/secret && sudo systemctl restart vsshd'", artifact.Prepare, artifact.Path, target, target),
				Reason:    "Install the daemon binary and ensure a managed service is running. The secret must be supplied from the local vault, not printed in logs.",
				Aftercare: fmt.Sprintf("meshclaw vssh-daemon-audit --hosts %s", host),
			},
		)
	case daemon.Status == "auth_failed":
		item.Severity = "repair"
		item.RequiresRoot = true
		item.Diagnosis = "The daemon is reachable but rejected the client authentication token."
		item.OperatorSummary = "Align the daemon secret with the control-plane secret, then restart vsshd."
		item.Actions = append(item.Actions, nodeRepairPlanAction{
			ID:        "align_secret",
			Mode:      "requires_root",
			Risk:      "medium",
			Command:   fmt.Sprintf("ssh %s 'sudo test -s /etc/vssh/secret && sudo systemctl restart vsshd # if missing, install the secret from the local vault before restarting'", target),
			Reason:    "Native vssh authentication must use the same secret on client and daemon.",
			Aftercare: fmt.Sprintf("meshclaw vssh-auth-paths --hosts %s", host),
		})
	default:
		item.Severity = "inspect"
		item.Diagnosis = "MeshClaw could not classify this node into a safe repair path."
		item.OperatorSummary = "Run read-only inspection first; do not apply mutation until the daemon state is clear."
		item.Actions = append(item.Actions, nodeRepairPlanAction{
			ID:        "inspect_node",
			Mode:      "read_only",
			Risk:      "low",
			Command:   fmt.Sprintf("meshclaw node-inventory %s && meshclaw vssh-auth-paths --hosts %s", host, host),
			Reason:    "Collect software inventory and native path status before choosing a repair.",
			Aftercare: fmt.Sprintf("meshclaw node-repair-plan --hosts %s", host),
		})
	}
	return item
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return value
		}
	}
	return ""
}

type vsshArtifactSpec struct {
	Path    string
	Prepare string
}

func vsshArtifactForNode(node inventory.Node) vsshArtifactSpec {
	if strings.EqualFold(node.OS, "linux") || nodeHasTag(node, "linux") {
		home, _ := os.UserHomeDir()
		if home == "" {
			home = "/Users/dragon"
		}
		path := filepath.Join(home, ".meshclaw", "artifacts", "vssh", "linux-amd64", "vssh")
		dir := filepath.Dir(path)
		source := filepath.Join(home, "meshpop-repos", "vssh")
		return vsshArtifactSpec{
			Path: path,
			Prepare: fmt.Sprintf("mkdir -p %s && (test -x %s || (cd %s && GOOS=linux GOARCH=amd64 go build -o %s ./cmd/vssh))",
				shellQuote(dir), shellQuote(path), shellQuote(source), shellQuote(path)),
		}
	}
	path := runtime.DefaultVSSHBinary()
	return vsshArtifactSpec{
		Path:    path,
		Prepare: fmt.Sprintf("test -x %s", shellQuote(path)),
	}
}

func vsshAuthPaths(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	hosts, err := parseHostsOnlyOptions(args, "vssh-auth-paths")
	if err != nil {
		return err
	}
	report := buildVSSHAuthPaths(hosts)
	if jsonOut {
		return printJSON(report)
	}
	fmt.Printf("vssh-auth-paths binary=%s version=%s effective_secret=%s hosts=%d\n", report.Binary, report.BinaryVersion, report.Secret.Effective, len(report.Hosts))
	if report.PathBinary != "" && report.PathBinary != report.Binary {
		fmt.Printf("path_binary=%s version=%s\n", report.PathBinary, report.PathVersion)
	}
	for _, host := range report.Hosts {
		fmt.Printf("- %s run_many=%t facts=%t decision=%s\n", host.Host, host.RunManyOK, host.FactsOK, host.Decision)
		if host.RunManyErr != "" {
			fmt.Println("  run_many_error: " + host.RunManyErr)
		}
		if host.FactsErr != "" {
			fmt.Println("  facts_error: " + host.FactsErr)
		}
		if host.Next != "" {
			fmt.Println("  next: " + host.Next)
		}
	}
	return nil
}

func buildVSSHAuthPaths(hosts []string) vsshAuthPathsReport {
	return buildVSSHAuthPathsWithTimeout(hosts, 10*time.Second)
}

func buildVSSHAuthPathsWithTimeout(hosts []string, timeout time.Duration) vsshAuthPathsReport {
	if len(hosts) == 0 {
		for _, node := range inventory.DefaultNodes() {
			if nodeHasTag(node, "client") {
				continue
			}
			hosts = append(hosts, node.Name)
			if len(hosts) >= 4 {
				break
			}
		}
	}
	binary := runtime.DefaultVSSHBinary()
	report := vsshAuthPathsReport{
		Generated:     time.Now().UTC(),
		Binary:        binary,
		BinaryVersion: commandOutputTrim(3*time.Second, binary, "version"),
		PathBinary:    commandOutputTrim(3*time.Second, "sh", "-lc", "command -v vssh || true"),
		Secret:        summarizeVSSHSecret(),
		Summary:       map[string]int{"ok": 0, "partial": 0, "failed": 0},
	}
	if report.PathBinary != "" {
		report.PathVersion = commandOutputTrim(3*time.Second, report.PathBinary, "version")
	}
	for _, host := range hosts {
		item := checkVSSHAuthPath(binary, host, timeout)
		report.Hosts = append(report.Hosts, item)
		report.Summary[item.Decision]++
	}
	return report
}

func checkVSSHAuthPath(binary, host string, timeout time.Duration) vsshAuthPathHost {
	item := vsshAuthPathHost{Host: host}
	target := vsshNativeTargetForHost(host)
	if err := runVSSHRunManyProbe(timeout, binary, target); err != nil {
		item.RunManyErr = err.Error()
	} else {
		item.RunManyOK = true
	}
	if err := runQuiet(timeout, binary, "facts", target); err != nil {
		item.FactsErr = err.Error()
	} else {
		item.FactsOK = true
	}
	switch {
	case item.RunManyOK && item.FactsOK:
		item.Decision = "ok"
	case item.RunManyOK || item.FactsOK:
		item.Decision = "partial"
		item.Next = "one native path works and another fails; check MCP process binary/env and daemon protocol version"
	default:
		item.Decision = "failed"
		item.Next = "native auth or daemon protocol is failing; run meshclaw vssh-daemon-audit and vssh-auth-fix-plan"
	}
	return item
}

func runVSSHRunManyProbe(timeout time.Duration, binary, host string) error {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, binary, "run-many", host, ":")
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = err.Error()
		}
		return fmt.Errorf("%s", msg)
	}
	var results []vsshManyResult
	if err := json.Unmarshal(stdout.Bytes(), &results); err != nil {
		return fmt.Errorf("invalid run-many JSON: %w", err)
	}
	if len(results) == 0 {
		return fmt.Errorf("empty run-many result")
	}
	if results[0].Error != "" {
		return fmt.Errorf(results[0].Error)
	}
	if results[0].Result == nil {
		return fmt.Errorf("missing run-many result")
	}
	if !results[0].Result.Success {
		msg := strings.TrimSpace(results[0].Result.Error + "\n" + results[0].Result.Stderr)
		if msg == "" {
			msg = fmt.Sprintf("remote command exited with %d", results[0].Result.ExitCode)
		}
		return fmt.Errorf("%s", msg)
	}
	return nil
}

func nativeTargetsForHosts(hosts []string) ([]string, map[string]string) {
	targets := make([]string, 0, len(hosts))
	targetToHost := map[string]string{}
	for _, host := range hosts {
		target := vsshNativeTargetForHost(host)
		targets = append(targets, target)
		targetToHost[target] = host
	}
	return targets, targetToHost
}

func vsshNativeTargetForHost(host string) string {
	if net.ParseIP(host) != nil {
		return host
	}
	if node, ok := inventory.Find(host); ok {
		if node.Tailscale != "" {
			return node.Tailscale
		}
		if node.WireIP != "" {
			return node.WireIP
		}
	}
	return host
}

func summarizeVSSHSecret() vsshSecretSummary {
	home, _ := os.UserHomeDir()
	userFile := fileExists(filepath.Join(home, ".vssh", "secret"))
	systemFile := fileExists("/etc/vssh/secret")
	envSet := strings.TrimSpace(os.Getenv("VSSH_SECRET")) != ""
	effective := "derived_or_missing"
	switch {
	case envSet:
		effective = "env"
	case userFile:
		effective = "user_file"
	case systemFile:
		effective = "system_file"
	}
	return vsshSecretSummary{
		EnvSet:      envSet,
		UserFile:    userFile,
		SystemFile:  systemFile,
		Effective:   effective,
		Description: "secret value is intentionally not returned",
	}
}

func fileExists(path string) bool {
	st, err := os.Stat(path)
	return err == nil && !st.IsDir()
}

func commandOutputTrim(timeout time.Duration, name string, args ...string) string {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	out, err := exec.CommandContext(ctx, name, args...).CombinedOutput()
	if ctx.Err() == context.DeadlineExceeded {
		return "timeout"
	}
	if err != nil && len(out) == 0 {
		return err.Error()
	}
	return strings.TrimSpace(string(out))
}

func runQuiet(timeout time.Duration, name string, args ...string) error {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, name, args...)
	var stderr bytes.Buffer
	cmd.Stdout = io.Discard
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = err.Error()
		}
		return fmt.Errorf("%s", msg)
	}
	return nil
}

func buildVSSHAuthFixPlan(hosts []string) (vsshAuthFixPlanReport, error, error) {
	audit, storeErr, auditErr := buildVSSHDaemonAudit(hosts)
	report := vsshAuthFixPlanReport{
		Generated: time.Now().UTC(),
		Summary:   audit.Summary,
		Decision:  "no_action",
	}
	for _, item := range audit.Items {
		switch item.Status {
		case "auth_failed":
			report.Decision = "rotate_or_align_vssh_secret"
			report.Actions = append(report.Actions, vsshAuthFixPlanAction{
				Host:      item.Host,
				Status:    item.Status,
				Risk:      "medium",
				Mode:      "plan_only",
				Command:   fmt.Sprintf("ssh %s 'sudo systemctl edit vsshd --force # set Environment=VSSH_SECRET from vault, then sudo systemctl restart vsshd'", sshTargetForNode(item.Host)),
				Reason:    "vsshd is reachable but rejected the client authentication token",
				Aftercare: fmt.Sprintf("meshclaw vssh-daemon-audit --hosts %s", item.Host),
			})
		case "unreachable":
			if item.Host == "macmini" {
				report.Decision = decisionWithPriority(report.Decision, "fix_unreachable_vsshd")
			}
			report.Actions = append(report.Actions, vsshAuthFixPlanAction{
				Host:      item.Host,
				Status:    item.Status,
				Risk:      "low",
				Mode:      "inspect",
				Command:   fmt.Sprintf("ssh %s 'command -v vssh; pgrep -af \"vssh .*server|vsshd\"; ss -ltn 2>/dev/null | grep 48291 || true'", sshTargetForNode(item.Host)),
				Reason:    "daemon endpoint is not reachable; this is not a token mismatch",
				Aftercare: fmt.Sprintf("meshclaw doctor %s", item.Host),
			})
		case "protocol_mismatch", "upgrade_required":
			report.Decision = decisionWithPriority(report.Decision, "upgrade_vsshd")
			node, _ := inventory.Find(item.Host)
			artifact := vsshArtifactForNode(node)
			report.Actions = append(report.Actions, vsshAuthFixPlanAction{
				Host:      item.Host,
				Status:    item.Status,
				Risk:      "low",
				Mode:      "upgrade",
				Command:   fmt.Sprintf("%s && scp -O %s %s:/tmp/vssh && ssh %s 'install -m 0755 /tmp/vssh ~/.local/bin/vssh || sudo install -m 0755 /tmp/vssh /usr/local/bin/vssh; (systemctl --user restart vsshd 2>/dev/null || sudo systemctl restart vsshd 2>/dev/null || true)'", artifact.Prepare, artifact.Path, sshTargetForNode(item.Host), sshTargetForNode(item.Host)),
				Reason:    "client and daemon protocol versions differ",
				Aftercare: fmt.Sprintf("meshclaw vssh-daemon-audit --hosts %s", item.Host),
			})
		}
	}
	if len(report.Actions) == 0 && audit.Summary.OK == audit.Summary.HostsTotal {
		report.Decision = "healthy"
	}
	record, planStoreErr := evidence.Store("vssh-auth-fix-plan", "fleet", fmt.Sprintf("decision=%s actions=%d", report.Decision, len(report.Actions)), report)
	report.Evidence = record
	if planStoreErr != nil {
		storeErr = planStoreErr
	}
	return report, storeErr, auditErr
}

func sshTargetForNode(name string) string {
	node, ok := inventory.Find(name)
	if !ok {
		return name
	}
	target := node.Tailscale
	if target == "" {
		target = node.WireIP
	}
	if target == "" {
		target = name
	}
	if node.User != "" {
		return node.User + "@" + target
	}
	return target
}

func decisionWithPriority(current, next string) string {
	if current == "" || current == "no_action" || current == "healthy" {
		return next
	}
	return current
}

func parseHostsOnlyOptions(args []string, command string) ([]string, error) {
	var hosts []string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--hosts":
			i++
			if i >= len(args) {
				return nil, fmt.Errorf("--hosts requires a comma-separated value")
			}
			hosts = splitCSV(args[i])
		default:
			return nil, fmt.Errorf("usage: meshclaw %s [--hosts a,b] [--json]", command)
		}
	}
	return hosts, nil
}

func buildVSSHDaemonAudit(hosts []string) (vsshDaemonAuditReport, error, error) {
	return buildVSSHDaemonAuditWithTimeout(hosts, 45*time.Second)
}

func buildVSSHDaemonAuditWithTimeout(hosts []string, timeout time.Duration) (vsshDaemonAuditReport, error, error) {
	if len(hosts) == 0 {
		for _, node := range inventory.DefaultNodes() {
			if nodeHasTag(node, "client") {
				continue
			}
			hosts = append(hosts, node.Name)
		}
	}
	command := vsshDaemonAuditCommand()
	report := vsshDaemonAuditReport{
		Command:   command,
		Generated: time.Now().UTC(),
	}
	targets, targetToHost := nativeTargetsForHosts(hosts)
	results, runErr := runVSSHMany(targets, command, timeout)
	for _, result := range results {
		item := classifyVSSHDaemonAudit(result)
		if host := targetToHost[result.Target]; host != "" {
			item.Host = host
			item.Next = nextForVSSHStatus(item.Host, item.Status)
		}
		report.Items = append(report.Items, item)
		updateVSSHDaemonSummary(&report.Summary, item)
	}
	sort.Slice(report.Items, func(i, j int) bool { return report.Items[i].Host < report.Items[j].Host })
	report.Summary.HostsTotal = len(report.Items)
	record, storeErr := evidence.Store("vssh-daemon-audit", "fleet", fmt.Sprintf("hosts=%d ok=%d failed=%d", report.Summary.HostsTotal, report.Summary.OK, report.Summary.Failed), report)
	report.Evidence = record
	return report, storeErr, runErr
}

func vsshDaemonAuditCommand() string {
	return `printf 'version='; (command -v vssh >/dev/null 2>&1 && vssh --version 2>/dev/null) || (/usr/local/bin/vssh --version 2>/dev/null) || true; printf 'daemon='; if command -v systemctl >/dev/null 2>&1; then systemctl is-active vsshd 2>/dev/null || systemctl is-active vssh 2>/dev/null || true; else pgrep -af "vssh .*server|vsshd" >/dev/null 2>&1 && echo active || echo unknown; fi`
}

type vsshManyResult struct {
	Target string `json:"target"`
	Result *struct {
		Success  bool   `json:"success"`
		Stdout   string `json:"stdout"`
		Stderr   string `json:"stderr"`
		ExitCode int    `json:"exit_code"`
		Error    string `json:"error"`
	} `json:"result"`
	Error string `json:"error"`
}

func runVSSHMany(hosts []string, command string, timeout time.Duration) ([]vsshManyResult, error) {
	binary := runtime.DefaultVSSHBinary()
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, binary, "run-many", strings.Join(hosts, ","), command)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	if ctx.Err() == context.DeadlineExceeded {
		return nil, fmt.Errorf("vssh run-many timed out after %s", timeout)
	}
	if err != nil {
		return nil, fmt.Errorf("vssh run-many failed: %s", strings.TrimSpace(stderr.String()))
	}
	var results []vsshManyResult
	if err := json.Unmarshal(stdout.Bytes(), &results); err != nil {
		return nil, fmt.Errorf("invalid vssh run-many JSON: %w", err)
	}
	return results, nil
}

func classifyVSSHDaemonAudit(result vsshManyResult) vsshDaemonAuditItem {
	item := vsshDaemonAuditItem{Host: result.Target, Transport: "vssh-native"}
	if node, ok := inventory.Find(result.Target); ok {
		item.Endpoint = node.Tailscale
	}
	if result.Error != "" {
		item.Error = result.Error
		item.Status = classifyVSSHConnectionError(result.Error)
		item.Next = nextForVSSHStatus(item.Host, item.Status)
		return item
	}
	if result.Result == nil {
		item.Status = "failed"
		item.Error = "missing vssh result"
		item.Next = nextForVSSHStatus(item.Host, item.Status)
		return item
	}
	item.Version, item.Daemon = parseVSSHDaemonOutput(result.Result.Stdout)
	if !result.Result.Success {
		item.Status = "failed"
		item.Error = strings.TrimSpace(result.Result.Error + "\n" + result.Result.Stderr)
		item.Next = nextForVSSHStatus(item.Host, item.Status)
		return item
	}
	switch {
	case !strings.Contains(item.Version, "0.7.4"):
		item.Status = "upgrade_required"
		item.Next = fmt.Sprintf("install vssh 0.7.4 on %s and restart vsshd", item.Host)
	case item.Daemon == "" || item.Daemon == "inactive" || item.Daemon == "failed" || item.Daemon == "unknown":
		item.Status = "daemon_not_reported"
		item.Next = fmt.Sprintf("verify vsshd service/process on %s", item.Host)
	default:
		item.Status = "ok"
		item.Next = "no action"
	}
	return item
}

func parseVSSHDaemonOutput(output string) (string, string) {
	version := ""
	daemon := ""
	for _, line := range strings.Split(output, "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "version=") {
			version = strings.TrimSpace(strings.TrimPrefix(line, "version="))
			continue
		}
		if strings.HasPrefix(line, "daemon=") {
			daemon = strings.TrimSpace(strings.TrimPrefix(line, "daemon="))
		}
	}
	return version, daemon
}

func classifyVSSHConnectionError(message string) string {
	lower := strings.ToLower(message)
	switch {
	case strings.Contains(lower, "auth failed"):
		return "auth_failed"
	case strings.Contains(lower, "invalid character"):
		return "protocol_mismatch"
	case strings.Contains(lower, "timeout"), strings.Contains(lower, "timed out"), strings.Contains(lower, "no route"), strings.Contains(lower, "connection refused"), strings.Contains(lower, "i/o timeout"):
		return "unreachable"
	default:
		return "failed"
	}
}

func nextForVSSHStatus(host, status string) string {
	switch status {
	case "auth_failed":
		return fmt.Sprintf("align VSSH_SECRET between MCP client and %s vsshd service", host)
	case "unreachable":
		return fmt.Sprintf("check Tailscale reachability and vsshd listener on %s", host)
	case "protocol_mismatch":
		return fmt.Sprintf("upgrade %s vsshd to the same vssh version as the MCP client", host)
	case "upgrade_required":
		return fmt.Sprintf("install latest vssh daemon on %s and restart vsshd", host)
	case "daemon_not_reported":
		return fmt.Sprintf("verify systemd service vsshd/vssh on %s", host)
	default:
		return fmt.Sprintf("run meshclaw doctor %s", host)
	}
}

func updateVSSHDaemonSummary(summary *vsshDaemonAuditSummary, item vsshDaemonAuditItem) {
	switch item.Status {
	case "ok":
		summary.OK++
	case "auth_failed":
		summary.AuthFailed++
		summary.Failed++
	case "unreachable":
		summary.Unreachable++
		summary.Failed++
	case "protocol_mismatch":
		summary.ProtocolMismatch++
		summary.Failed++
	case "upgrade_required":
		summary.UpgradeRequired++
		summary.Failed++
	case "daemon_not_reported":
		summary.DaemonNotReported++
		summary.Failed++
	default:
		summary.Failed++
	}
}

func serviceTriage(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	hosts, limit, parallel, err := parseServiceTriageOptions(args)
	if err != nil {
		return err
	}
	report, record, storeErr := buildServiceTriage(hosts, limit, parallel)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Println(matrixops.FormatExplainedResult(map[string]interface{}{
		"route": "service_triage",
		"result": map[string]interface{}{
			"report": report,
		},
	}))
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func parseServiceTriageOptions(args []string) ([]string, int, int, error) {
	var hosts []string
	limit := 5
	parallel := 4
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--hosts":
			i++
			if i >= len(args) {
				return nil, 0, 0, fmt.Errorf("--hosts requires a comma-separated value")
			}
			hosts = splitCSV(args[i])
		case "--limit":
			i++
			if i >= len(args) {
				return nil, 0, 0, fmt.Errorf("--limit requires a number")
			}
			if _, err := fmt.Sscanf(args[i], "%d", &limit); err != nil {
				return nil, 0, 0, fmt.Errorf("invalid --limit value: %s", args[i])
			}
		case "--parallel":
			i++
			if i >= len(args) {
				return nil, 0, 0, fmt.Errorf("--parallel requires a number")
			}
			if _, err := fmt.Sscanf(args[i], "%d", &parallel); err != nil {
				return nil, 0, 0, fmt.Errorf("invalid --parallel value: %s", args[i])
			}
		default:
			return nil, 0, 0, fmt.Errorf("unknown service-triage option: %s", args[i])
		}
	}
	if limit <= 0 {
		limit = 5
	}
	if parallel <= 0 {
		parallel = 4
	}
	return hosts, limit, parallel, nil
}

func buildServiceTriage(hosts []string, limit, parallel int) (serviceTriageReport, evidence.Record, error) {
	audit, _, auditStoreErr := runFleetServiceAudit(hosts, parallel)
	report := buildServiceTriageFromAudit(audit, limit, parallel)
	record, storeErr := evidence.Store("service-triage", "fleet", fmt.Sprintf("items=%d", len(report.Items)), report)
	if storeErr == nil {
		storeErr = auditStoreErr
	}
	return report, record, storeErr
}

func buildServiceTriageFromAudit(audit fleetServiceAuditReport, limit, parallel int) serviceTriageReport {
	report := serviceTriageReport{
		Counts:          map[string]int{},
		ServiceFindings: audit.Findings,
		Limit:           limit,
		MaxParallel:     parallel,
		Time:            time.Now().UTC(),
	}
	var candidates []workflow.Report
	for _, hostReport := range audit.Hosts {
		if hostReport.Status == "ok" {
			continue
		}
		if serviceFromAuditReport(hostReport) == "" {
			report.Items = append(report.Items, serviceTriageItem{
				Host:      hostReport.Host,
				Class:     "needs_manual_audit",
				Mode:      "inspect",
				Severity:  "warning",
				Judgement: "Could not extract a service name automatically. 서비스 이름을 자동 추출하지 못했습니다.",
				Next:      fmt.Sprintf("meshclaw service-audit %s", hostReport.Host),
			})
			report.Counts["needs_manual_audit"]++
			continue
		}
		candidates = append(candidates, hostReport)
	}
	if limit > 0 && len(candidates) > limit {
		candidates = candidates[:limit]
	}
	for _, hostReport := range candidates {
		service := serviceFromAuditReport(hostReport)
		check := workflow.ServiceCheck(hostReport.Host, service)
		item := classifyServiceTriage(hostReport, check, service)
		report.Items = append(report.Items, item)
		report.Counts[item.Class]++
		if item.Mode == "approval_required" || item.Mode == "requires_approval" {
			report.Counts["approval_required"]++
		}
	}
	report.RecommendedMCP = recommendedServiceTriageMCP(report)
	return report
}

func classifyServiceTriage(audit workflow.Report, check workflow.Report, service string) serviceTriageItem {
	evidenceText := ""
	if len(check.Findings) > 0 {
		evidenceText = check.Findings[0].Evidence
	}
	lower := strings.ToLower(service + "\n" + evidenceText)
	item := serviceTriageItem{
		Host:     audit.Host,
		Service:  service,
		Class:    "real_incident",
		Mode:     "inspect",
		Severity: "warning",
		Evidence: truncateForTriage(evidenceText),
	}
	switch {
	case check.Status == "failed" || check.Status == "unknown_node":
		item.Class = "approval_required"
		item.Mode = "requires_approval"
		item.Severity = "error"
		item.Judgement = "Service status lookup failed. Check connectivity, permissions, and node health first. 서비스 상태 조회 자체가 실패했습니다."
		item.Next = fmt.Sprintf("meshclaw doctor %s", audit.Host)
	case strings.Contains(lower, "systemd-networkd-wait-online") || strings.Contains(lower, "cloud-init") || strings.Contains(lower, "colord") || strings.Contains(lower, "unbound-resolvconf"):
		item.Class = "stale_or_boot_only"
		item.Mode = "ignore_candidate"
		item.Severity = "info"
		item.Judgement = "Looks like a boot, desktop, or network helper residue with low current operational impact. 부팅/보조 서비스 흔적으로 보입니다."
		item.Next = fmt.Sprintf("meshclaw service-check %s %s", audit.Host, service)
	case strings.Contains(lower, "status=203/exec") || strings.Contains(lower, "no such file") || strings.Contains(lower, "cannot open file") || strings.Contains(lower, "can't open file"):
		item.Class = "stale_or_missing_target"
		item.Mode = "approval_required"
		item.Severity = "warning"
		item.Judgement = "Likely stale service: ExecStart target is missing or not executable. ExecStart 대상 파일이 없거나 실행 불가능한 잔재 서비스일 가능성이 큽니다."
		item.Next = fmt.Sprintf("meshclaw service-quarantine %s %s", audit.Host, service)
	case strings.Contains(lower, "active: active (running)") && !strings.Contains(lower, "failed"):
		item.Class = "ignore_candidate"
		item.Mode = "read_only"
		item.Severity = "info"
		item.Judgement = "The service is currently running; this may be historical log noise. 현재 실행 중인 서비스입니다."
		item.Next = "keep monitoring"
	case strings.Contains(lower, "inactive (dead)") && strings.Contains(lower, "disabled"):
		item.Class = "stale_or_boot_only"
		item.Mode = "ignore_candidate"
		item.Severity = "info"
		item.Judgement = "Inactive and disabled; treat as residue before treating it as an active incident. 비활성/비활성화 상태라 잔재 후보입니다."
		item.Next = fmt.Sprintf("meshclaw service-check %s %s", audit.Host, service)
	default:
		item.Class = "real_incident"
		item.Mode = "inspect"
		item.Severity = "warning"
		item.Judgement = "Possible real service incident. Inspect unit configuration and recent logs before restart. 실제 서비스 장애일 수 있습니다."
		item.Next = fmt.Sprintf("meshclaw service-check %s %s", audit.Host, service)
	}
	return item
}

func truncateForTriage(text string) string {
	text = strings.TrimSpace(text)
	if len(text) <= 1200 {
		return text
	}
	return text[:1200] + "..."
}

func workflowIssueCount(report workflow.Report) int {
	count := 0
	for _, finding := range report.Findings {
		if finding.Severity != "info" || report.Status != "ok" {
			count++
		}
	}
	return count
}

func nodeInventory(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw node-inventory <host> [--json]")
	}
	report := workflow.SoftwareInventory(args[0])
	record, storeErr := evidence.Store("node-inventory", args[0], report.Status, report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	printSoftwareInventory(report)
	printEvidenceStoreStatus(record, storeErr)
	if report.Status == "failed" || report.Status == "unknown_node" {
		return fmt.Errorf("node-inventory failed on %s", args[0])
	}
	return nil
}

func fleetInventory(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	hosts, parallel, err := parseFleetServiceAuditOptions(args)
	if err != nil {
		return err
	}
	report, record, storeErr := runFleetInventory(hosts, parallel)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("fleet-inventory hosts=%d failures=%d parallel=%d\n", len(report.Hosts), report.Failures, report.MaxParallel)
	for _, host := range report.Hosts {
		fmt.Printf("- %s status=%s os=%s tools=%s services=%d containers=%d gpu=%d\n", host.Host, host.Status, host.OS, compactTools(host.Tools), len(host.Services), len(host.Containers), len(host.GPU))
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func placementPlan(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) == 0 {
		return fmt.Errorf("usage: meshclaw placement-plan <workload description> [--json]")
	}
	workload := strings.Join(args, " ")
	report, record, storeErr, err := buildPlacementPlan(workload)
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("placement-plan class=%s workload=%q candidates=%d\n", report.Class, report.Workload, len(report.Candidates))
	for i, candidate := range report.Candidates {
		fmt.Printf("%d. %s score=%d\n", i+1, candidate.Host, candidate.Score)
		for _, reason := range candidate.Reasons {
			fmt.Println("   - " + reason)
		}
		if len(candidate.Actions) > 0 {
			fmt.Println("   next: " + strings.Join(candidate.Actions, "; "))
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func orchestrationPlan(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) == 0 {
		return fmt.Errorf("usage: meshclaw orchestration-plan <scenario> [--json]")
	}
	scenario := strings.Join(args, " ")
	report := buildOrchestrationPlan(scenario)
	record, storeErr := evidence.Store("orchestration-plan", "workflow", scenario, report)
	if jsonOut {
		return printJSON(map[string]interface{}{
			"scenario":       report.Scenario,
			"thesis":         report.Thesis,
			"plan":           report.Plan,
			"workers":        report.Workers,
			"tool_decisions": report.ToolDecisions,
			"doc_checks":     report.DocumentChecks,
			"secret_access":  report.SecretAccess,
			"meshclaw_role":  report.MeshClawRole,
			"evidence_files": report.Evidence,
			"next":           report.Next,
			"generated_at":   report.GeneratedAt,
			"report":         report,
			"evidence":       record,
			"store_error":    errString(storeErr),
		})
	}
	fmt.Printf("orchestration-plan scenario=%q workers=%d steps=%d\n", scenario, len(report.Workers), len(report.Plan))
	fmt.Println(report.Thesis)
	fmt.Println("workers:")
	for _, worker := range report.Workers {
		fmt.Printf("- %s role=%s model=%s\n", worker.Host, worker.Role, worker.Model)
		for _, reason := range worker.WhySelected {
			fmt.Println("  why: " + reason)
		}
		for _, instruction := range worker.Instructions {
			fmt.Println("  instruction: " + instruction)
		}
		if worker.Fallback != "" {
			fmt.Println("  fallback: " + worker.Fallback)
		}
	}
	fmt.Println("tool decisions:")
	for _, decision := range report.ToolDecisions {
		fmt.Printf("- %s: %s\n", decision.Tool, decision.Decision)
		for _, reason := range decision.Reasons {
			fmt.Println("  - " + reason)
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func buildOrchestrationPlan(scenario string) orchestrationPlanReport {
	return orchestrationPlanReport{
		Scenario: scenario,
		Thesis:   "Orchestration is goal decomposition plus placement, worker instructions, policy gates, evidence capture, failure learning, and repeatable rerun.",
		Plan: []orchestrationPlanStep{
			{ID: "scope", Goal: "Define the real end-to-end operation.", Why: "Mail is not proven by one service check; it requires server, DNS, account, client, send, receive, and reply verification.", Evidence: []string{"plan.md", "workflow inspection"}},
			{ID: "state", Goal: "Read current server and capability state.", Why: "Placement needs live facts: which nodes are online, which have Ollama, GPU, n8n, mail services, browser/client access, and vssh health.", Nodes: []string{"c1", "g1", "g2", "g3", "g4", "macbook", "macmini"}, Evidence: []string{"capabilities.json", "node inventory", "monitor state"}},
			{ID: "docs", Goal: "Check current vendor documentation before provider-sensitive steps.", Why: "Mox and Cloudflare behavior can change; DNS and account work must rely on current official docs.", Evidence: []string{"doc check records", "source URLs"}},
			{ID: "policy", Goal: "Classify approval gates before execution.", Why: "DNS changes, account creation, token use, and real email sending are mutating or secret-adjacent.", ApprovalRequired: true, Evidence: []string{"policy decision", "approvals.jsonl"}},
			{ID: "workers", Goal: "Assign different workers to different reasoning lanes.", Why: "Planning, reliability review, evidence schema, and automation have different failure modes and should not be collapsed into one prompt.", Nodes: []string{"g1", "g2", "g3", "g4"}},
			{ID: "execute", Goal: "Run allowed checks and collect structured results.", Why: "The AI should not parse screenshots or terminal prose when typed execution results are available.", Evidence: []string{"execution.json", "steps.jsonl"}},
			{ID: "visual-proof", Goal: "Capture MacBook and Mac mini client screenshots.", Why: "End-to-end mail success needs user-visible proof: inbox, sent mail, reply, and browser/webmail state.", Evidence: []string{"screenshots/macbook-inbox-redacted.png", "screenshots/macmini-sent-mail-redacted.png"}},
			{ID: "learn", Goal: "Treat failures as data for the next run.", Why: "A failed model load or missing service should update placement and autoheal planning instead of disappearing into chat history.", Evidence: []string{"retryable flag", "autoheal plan", "resume-plan.json"}},
		},
		Workers: []orchestrationWorker{
			{
				Host: "g1", Role: "planning worker", Model: "qwen2.5:7b",
				WhySelected:  []string{"Ollama model is available", "good fit for fast task decomposition", "keeps planning load off the controller"},
				Instructions: []string{"Return a structured plan", "Split the operation into server, DNS, account, client, and proof steps", "Mark required evidence for each step"},
				Fallback:     "Use another available Ollama worker or external Codex/Claude planning if g1 is unavailable.",
			},
			{
				Host: "g2", Role: "reliability reviewer", Model: "qwen2.5:7b",
				WhySelected:  []string{"Independent model lane reduces single-plan bias", "reviews retry and failure conditions", "can compare against g1 plan"},
				Instructions: []string{"Find likely failure points", "Classify retryable versus approval-required failures", "Suggest safe fallback paths"},
				Fallback:     "Fold review into Codex or run review on g3 when g2 is unavailable.",
			},
			{
				Host: "g3", Role: "evidence schema worker", Model: "llama3.2",
				WhySelected:  []string{"Separate evidence design from execution", "keeps result schema explicit", "useful for resume and audit trail"},
				Instructions: []string{"Define execution_result fields", "Define screenshot and artifact expectations", "Ensure the next agent can resume from files"},
				Fallback:     "Use built-in MeshClaw execution schema when local model output is unavailable.",
			},
			{
				Host: "g4", Role: "automation lane", Model: "Ollama plus n8n candidate",
				WhySelected:  []string{"n8n and Ollama are available", "good fit for future repeatable automation", "captures automation failures as evidence"},
				Instructions: []string{"Check n8n/Ollama service state", "Attempt model/automation lane only when healthy", "Record failures without hiding them"},
				Fallback:     "Do not block the workflow; record failure and route to another worker next time.",
			},
			{
				Host: "c1", Role: "mail server lane", Model: "",
				WhySelected:  []string{"Mox mail server lives here", "SMTP/IMAP/HTTPS ports and accounts must be verified on the source of truth"},
				Instructions: []string{"Check mox active state", "Check mail ports", "Verify account presence without exposing secrets"},
			},
			{
				Host: "macbook", Role: "controller and verifier", Model: "Codex app",
				WhySelected:  []string{"Human-facing controller", "can run Codex, browser, mail client, and video rendering", "captures local verification artifacts"},
				Instructions: []string{"Drive orchestration", "Record evidence bundle", "Capture MacBook client/browser screenshots"},
			},
			{
				Host: "macmini", Role: "separate client/reply lane", Model: "Claude or local app lane",
				WhySelected:  []string{"Separate desktop/client identity", "validates real round trip instead of local-only success", "can capture reply-side screenshots"},
				Instructions: []string{"Receive mail through another account", "Send a reply", "Capture redacted client evidence"},
			},
		},
		ToolDecisions: []orchestrationToolChoice{
			{Tool: "LangChain on g1", Decision: "not used for this demo", Reasons: []string{"The task required real infrastructure operations, not an in-process prompt chain", "Codex already supplied planning and tool-use orchestration", "Adding LangChain would obscure evidence and approval boundaries"}},
			{Tool: "n8n on g4", Decision: "checked but not made the primary orchestrator", Reasons: []string{"n8n is useful for repeatable automation after the workflow stabilizes", "this demo needed adaptive reasoning, policy checks, and evidence capture first", "g4 model/service failure should not block the whole operation"}},
			{Tool: "Codex", Decision: "primary human-facing orchestrator", Reasons: []string{"User naturally talks to Codex", "Codex can call MCP tools and inspect local artifacts", "Codex can coordinate remote execution and verification"}},
			{Tool: "MeshClaw", Decision: "runtime of record", Reasons: []string{"Provides inventory, capability, policy, workflow, approval, and evidence", "Does not replace Codex or Claude", "Makes the operation repeatable and auditable"}},
			{Tool: "vssh", Decision: "execution substrate", Reasons: []string{"Better than raw SSH for AI: structured results, fleet facts, parallel execution, and evidence-friendly output", "Raw SSH remains a fallback, not the product value"}},
		},
		DocumentChecks: []orchestrationDocCheck{
			{Subject: "Mox mail server", URL: "https://www.xmox.nl/", Why: "Confirm current mail server operation, account, DNS, TLS, and administration expectations before mutating mail setup.", Use: []string{"service/account verification", "DNS checklist", "client configuration"}},
			{Subject: "Cloudflare DNS API tokens", URL: "https://developers.cloudflare.com/fundamentals/api/get-started/create-token/", Why: "Confirm scoped token and DNS edit requirements before any provider change.", Use: []string{"use-only token access", "approval-gated DNS mutations", "redacted audit evidence"}},
			{Subject: "Cloudflare DNS records", URL: "https://developers.cloudflare.com/dns/manage-dns-records/how-to/create-dns-records/", Why: "Confirm current record management flow before MX/SPF/DKIM/DMARC changes.", Use: []string{"dry-run checklist", "manual or adapter-backed DNS update plan"}},
		},
		SecretAccess: []orchestrationSecretRule{
			{Name: "Cloudflare API token", Access: "use-only via vault/capability", Policy: "DNS mutation requires approval", Redaction: "token value never appears in model output or evidence"},
			{Name: "mail account password", Access: "use-only client setup", Policy: "account create/configure requires approval", Redaction: "password, app password, and login secrets are redacted"},
			{Name: "DKIM/private keys", Access: "read blocked unless explicitly approved", Policy: "secret reveal is denied by default", Redaction: "private keys are never copied into chat"},
		},
		MeshClawRole: []string{
			"Expose current node and capability state",
			"Explain placement rationale for servers, models, and tools",
			"Gate risky steps through policy and approvals",
			"Record execution results as structured JSON",
			"Attach screenshots and artifacts as evidence",
			"Turn failures into retry, fallback, and autoheal input",
		},
		Evidence: []string{"plan.md", "execution.json", "steps.jsonl", "approvals.jsonl", "capabilities.json", "report.html", "screenshots/*.png"},
		Next: []string{
			"Implement concrete browser/mail screenshot capture adapters",
			"Connect use-only vault access for provider tokens",
			"Promote orchestration-plan into workflow_inspect output for complex workflows",
			"Use placement rationale to improve next-run worker selection",
		},
		GeneratedAt: time.Now().UTC(),
	}
}

func buildPlacementPlan(workload string) (placementReport, evidence.Record, error, error) {
	inventoryReport, _, inventoryStoreErr := runFleetInventory(nil, 4)
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return placementReport{}, evidence.Record{}, inventoryStoreErr, err
	}
	states := m.CheckAll()
	monitorOut := monitorCheckOutput{States: states, Alerts: m.DetectAlerts()}
	report := scorePlacement(workload, inventoryReport, monitorOut, capability.List())
	record, storeErr := evidence.Store("placement-plan", "fleet", fmt.Sprintf("class=%s candidates=%d", report.Class, len(report.Candidates)), report)
	if storeErr == nil {
		storeErr = inventoryStoreErr
	}
	return report, record, storeErr, nil
}

func scorePlacement(workload string, inventoryReport fleetInventoryReport, monitorOut monitorCheckOutput, caps []capability.Capability) placementReport {
	class := classifyWorkload(workload)
	byHost := capabilitiesByHost(caps)
	report := placementReport{
		Workload:     workload,
		Class:        class,
		Candidates:   []placementCandidate{},
		Rejected:     []placementRejection{},
		Capabilities: caps,
		Inventory:    inventoryReport,
		Monitor:      monitorOut,
		GeneratedAt:  time.Now().UTC(),
	}
	for _, host := range inventoryReport.Hosts {
		capScore, capReasons, capIDs := scoreCapabilitiesForWorkload(class, byHost[host.Host])
		if host.Status != "ok" {
			if capScore > 0 {
				report.Candidates = append(report.Candidates, placementCandidate{
					Host:         host.Host,
					Score:        capScore,
					Reasons:      append(capReasons, "software inventory failed; capability registry makes this a fallback candidate"),
					Capabilities: capIDs,
					Actions: []string{
						fmt.Sprintf("meshclaw node-inventory %s", host.Host),
						fmt.Sprintf("meshclaw vssh-daemon-audit --hosts %s", host.Host),
					},
				})
				continue
			}
			report.Rejected = append(report.Rejected, placementRejection{Host: host.Host, Reason: "inventory collection failed"})
			continue
		}
		state := monitorOut.States[host.Host]
		if state == nil || !state.Online {
			report.Rejected = append(report.Rejected, placementRejection{Host: host.Host, Reason: "offline or missing monitor state"})
			continue
		}
		score, reasons, rejected := scoreHostForWorkload(class, host, state)
		score += capScore
		reasons = append(reasons, capReasons...)
		if rejected != "" {
			if len(capIDs) == 0 {
				report.Rejected = append(report.Rejected, placementRejection{Host: host.Host, Reason: rejected})
				continue
			}
			reasons = append(reasons, "inventory rejected but capability registry still marks this host as a fallback candidate")
			score = capScore
		}
		if score <= 0 {
			report.Rejected = append(report.Rejected, placementRejection{Host: host.Host, Reason: firstNonEmpty(rejected, "score was not positive")})
			continue
		}
		candidate := placementCandidate{Host: host.Host, Score: score, Reasons: reasons, Capabilities: capIDs}
		candidate.Actions = []string{
			fmt.Sprintf("meshclaw node-inventory %s", host.Host),
			fmt.Sprintf("meshclaw service-audit %s", host.Host),
		}
		report.Candidates = append(report.Candidates, candidate)
	}
	sort.Slice(report.Candidates, func(i, j int) bool {
		if report.Candidates[i].Score == report.Candidates[j].Score {
			return report.Candidates[i].Host < report.Candidates[j].Host
		}
		return report.Candidates[i].Score > report.Candidates[j].Score
	})
	if len(report.Candidates) > 5 {
		report.Candidates = report.Candidates[:5]
	}
	return report
}

func classifyWorkload(workload string) string {
	lower := strings.ToLower(workload)
	switch {
	case containsAny(lower, "local llm", "ollama", "로컬모델", "로컬 모델"):
		return "local-llm"
	case containsAny(lower, "gpu", "cuda", "nvidia", "llm", "모델", "학습", "추론"):
		return "gpu"
	case containsAny(lower, "docker", "도커", "container", "컨테이너", "compose"):
		return "docker"
	case containsAny(lower, "storage", "nas", "backup", "백업", "저장"):
		return "storage"
	case containsAny(lower, "vps", "relay", "public", "외부", "릴레이"):
		return "vps"
	default:
		return "general"
	}
}

func scoreHostForWorkload(class string, host workflow.SoftwareInventoryReport, state *monitor.NodeState) (int, []string, string) {
	score := 50
	reasons := []string{fmt.Sprintf("online, disk %.1f%%, memory %.1f%%", state.Disk, state.Memory)}
	if state.Disk >= 90 {
		return 0, nil, fmt.Sprintf("disk %.1f%% is too high", state.Disk)
	}
	if state.Memory >= 90 {
		return 0, nil, fmt.Sprintf("memory %.1f%% is too high", state.Memory)
	}
	if state.Disk < 70 {
		score += 12
	} else if state.Disk >= 75 {
		score -= 12
	}
	if state.Memory < 50 {
		score += 12
	}
	switch class {
	case "gpu":
		if len(host.GPU) == 0 {
			return 0, nil, "GPU workload but no GPU was found in software inventory"
		}
		score += 50 + len(host.GPU)*10
		reasons = append(reasons, fmt.Sprintf("%d GPU entries found", len(host.GPU)))
		if hasTool(host.Tools, "docker") {
			score += 8
			reasons = append(reasons, "docker is available")
		}
	case "local-llm":
		if hasTool(host.Tools, "ollama") {
			score += 50
			reasons = append(reasons, "ollama is available")
			if host.Host == "macmini" {
				score += 25
				reasons = append(reasons, "macmini local model worker")
			}
			if len(host.GPU) > 0 {
				score += 10
				reasons = append(reasons, fmt.Sprintf("%d GPU entries found", len(host.GPU)))
			}
		} else if len(host.GPU) > 0 {
			score += 20
			reasons = append(reasons, "GPU makes this host a local model candidate")
		} else {
			return 0, nil, "no local model runtime or GPU found"
		}
	case "docker":
		if !hasTool(host.Tools, "docker") {
			return 0, nil, "docker is not available"
		}
		score += 35 + len(host.Containers)*2
		reasons = append(reasons, fmt.Sprintf("docker is available with %d running containers", len(host.Containers)))
	case "storage":
		if host.Host == "s2" || strings.Contains(strings.ToLower(host.OS), "synology") {
			score += 60
			reasons = append(reasons, "NAS/storage node")
		} else if strings.Contains(host.Host, "v") {
			score += 10
			reasons = append(reasons, "VPS storage candidate")
		}
	case "vps":
		if strings.HasPrefix(host.Host, "v") || strings.HasPrefix(host.Host, "c") {
			score += 35
			reasons = append(reasons, "VPS/public node")
		} else {
			score -= 10
		}
	default:
		if hasTool(host.Tools, "meshclaw") && hasTool(host.Tools, "vssh") {
			score += 15
			reasons = append(reasons, "meshclaw/vssh are available")
		}
	}
	return score, reasons, ""
}

func capabilitiesByHost(caps []capability.Capability) map[string][]capability.Capability {
	out := map[string][]capability.Capability{}
	for _, cap := range caps {
		if cap.Host == "" {
			continue
		}
		out[cap.Host] = append(out[cap.Host], cap)
	}
	return out
}

func scoreCapabilitiesForWorkload(class string, caps []capability.Capability) (int, []string, []string) {
	score := 0
	reasons := []string{}
	ids := []string{}
	for _, cap := range caps {
		ids = append(ids, cap.ID)
		switch class {
		case "gpu", "local-llm":
			if capabilityHasAny(cap, "gpu", "model_worker", "batch_inference", "ollama_candidate") {
				score += availableCapabilityScore(cap, 20)
				reasons = append(reasons, "capability registry marks "+cap.ID+" as model/GPU capable")
			}
		case "docker":
			if capabilityHasAny(cap, "workflow_worker", "n8n", "role:docker-host") {
				score += availableCapabilityScore(cap, 14)
				reasons = append(reasons, "capability registry marks "+cap.ID+" as an automation/docker candidate")
			}
		case "storage":
			if capabilityHasAny(cap, "storage", "artifact_archive", "backup_candidate") {
				score += availableCapabilityScore(cap, 24)
				reasons = append(reasons, "capability registry marks "+cap.ID+" as storage capable")
			}
		case "vps":
			if capabilityHasAny(cap, "tag:vps", "role:server", "role:relay") {
				score += availableCapabilityScore(cap, 14)
				reasons = append(reasons, "capability registry marks "+cap.ID+" as VPS/public infrastructure")
			}
		default:
			if capabilityHasAny(cap, "run_evidence", "facts", "inventory") {
				score += availableCapabilityScore(cap, 6)
			}
		}
	}
	return score, uniqueStrings(reasons), uniqueStrings(ids)
}

func availableCapabilityScore(cap capability.Capability, base int) int {
	if cap.Status == "available" {
		return base + 4
	}
	return base
}

func capabilityHasAny(cap capability.Capability, values ...string) bool {
	for _, existing := range cap.Capabilities {
		for _, value := range values {
			if strings.EqualFold(existing, value) {
				return true
			}
		}
	}
	return false
}

func hasTool(tools map[string]string, name string) bool {
	_, ok := tools[name]
	return ok
}

func runFleetInventory(hosts []string, parallel int) (fleetInventoryReport, evidence.Record, error) {
	if len(hosts) == 0 {
		for _, node := range inventory.DefaultNodes() {
			if nodeHasTag(node, "linux") || nodeHasTag(node, "macos") || nodeHasTag(node, "synology") {
				hosts = append(hosts, node.Name)
			}
		}
	}
	if parallel <= 0 {
		parallel = 4
	}
	report := fleetInventoryReport{MaxParallel: parallel, Time: time.Now().UTC()}
	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, parallel)
	for _, host := range hosts {
		host := host
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			hostReport := workflow.SoftwareInventory(host)
			mu.Lock()
			report.Hosts = append(report.Hosts, hostReport)
			if hostReport.Status != "ok" {
				report.Failures++
			}
			mu.Unlock()
		}()
	}
	wg.Wait()
	sort.Slice(report.Hosts, func(i, j int) bool { return report.Hosts[i].Host < report.Hosts[j].Host })
	record, storeErr := evidence.Store("fleet-inventory", "fleet", fmt.Sprintf("hosts=%d failures=%d", len(report.Hosts), report.Failures), report)
	return report, record, storeErr
}

func printSoftwareInventory(report workflow.SoftwareInventoryReport) {
	fmt.Printf("node-inventory host=%s status=%s os=%s kernel=%s arch=%s\n", report.Host, report.Status, report.OS, report.Kernel, report.Arch)
	if len(report.Tools) > 0 {
		fmt.Println("tools: " + compactTools(report.Tools))
	}
	if len(report.GPU) > 0 {
		fmt.Println("gpu:")
		for _, gpu := range report.GPU {
			fmt.Println("- " + gpu)
		}
	}
	if len(report.Containers) > 0 {
		fmt.Println("containers:")
		for _, container := range firstN(report.Containers, 20) {
			fmt.Println("- " + container)
		}
	}
	if len(report.Services) > 0 {
		fmt.Println("running services:")
		for _, service := range firstN(report.Services, 20) {
			fmt.Println("- " + service)
		}
	}
	if report.Error != "" {
		fmt.Println("error: " + report.Error)
	}
}

func compactTools(tools map[string]string) string {
	if len(tools) == 0 {
		return "-"
	}
	names := make([]string, 0, len(tools))
	for name := range tools {
		names = append(names, name)
	}
	sort.Strings(names)
	return strings.Join(names, ", ")
}

func firstN(values []string, n int) []string {
	if len(values) <= n {
		return values
	}
	return values[:n]
}

func parseFleetServiceAuditOptions(args []string) ([]string, int, error) {
	var hosts []string
	parallel := 4
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--hosts":
			i++
			if i >= len(args) {
				return nil, 0, fmt.Errorf("--hosts requires a comma-separated value")
			}
			hosts = splitCSV(args[i])
		case "--parallel":
			i++
			if i >= len(args) {
				return nil, 0, fmt.Errorf("--parallel requires a number")
			}
			if _, err := fmt.Sscanf(args[i], "%d", &parallel); err != nil {
				return nil, 0, fmt.Errorf("invalid --parallel value: %s", args[i])
			}
		default:
			return nil, 0, fmt.Errorf("unknown fleet-service-audit option: %s", args[i])
		}
	}
	return hosts, parallel, nil
}

func nodeHasTag(node inventory.Node, tag string) bool {
	for _, candidate := range node.Tags {
		if candidate == tag {
			return true
		}
	}
	return false
}

func splitCSV(value string) []string {
	parts := strings.Split(value, ",")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if part != "" {
			out = append(out, part)
		}
	}
	return out
}

func fleetScanSummary(report fleet.Report) string {
	offline := 0
	findings := 0
	for _, host := range report.Hosts {
		if !host.Online {
			offline++
		}
		if host.Security != nil && host.Security.Status == "findings" {
			findings++
		}
		if host.Logs != nil && host.Logs.Status == "findings" {
			findings++
		}
		if host.Hygiene != nil && host.Hygiene.Status == "findings" {
			findings++
		}
	}
	return fmt.Sprintf("hosts=%d alerts=%d offline=%d findings=%d", len(report.Hosts), len(report.Alerts), offline, findings)
}

func capabilities(args []string) error {
	jsonOut := wantsJSON(args)
	filtered := withoutJSONFlag(args)
	if len(filtered) > 0 {
		switch filtered[0] {
		case "init":
			force := false
			for _, arg := range filtered[1:] {
				switch arg {
				case "--force":
					force = true
				default:
					return fmt.Errorf("usage: meshclaw capabilities init [--force] [--json]")
				}
			}
			caps, err := capability.Init(force)
			if err != nil {
				return err
			}
			if jsonOut {
				return printJSON(map[string]interface{}{"path": capability.Path(), "capabilities": caps})
			}
			fmt.Printf("capability registry written: %s\n", capability.Path())
			printCapabilities(caps)
			return nil
		case "validate":
			path := ""
			if len(filtered) > 2 {
				return fmt.Errorf("usage: meshclaw capabilities validate [file] [--json]")
			}
			if len(filtered) == 2 {
				path = filtered[1]
			}
			report := capability.Validate(path)
			if jsonOut {
				if err := printJSON(report); err != nil {
					return err
				}
			} else {
				printCapabilityValidation(report)
			}
			if !report.Valid {
				return fmt.Errorf("capability registry validation failed")
			}
			return nil
		case "recommend":
			if len(filtered) < 2 {
				return fmt.Errorf("usage: meshclaw capabilities recommend <intent> [--json]")
			}
			report := capability.Recommend(strings.Join(filtered[1:], " "))
			if jsonOut {
				return printJSON(report)
			}
			printCapabilityRecommendation(report)
			if !report.Registry.Valid {
				return fmt.Errorf("capability registry validation failed")
			}
			return nil
		default:
			return fmt.Errorf("usage: meshclaw capabilities [init --force|validate [file]|recommend <intent>] [--json]")
		}
	}
	caps := capability.List()
	if wantsJSON(args) {
		return printJSON(map[string]interface{}{"path": capability.Path(), "capabilities": caps})
	}
	printCapabilities(caps)
	return nil
}

func adapters(args []string) error {
	jsonOut := wantsJSON(args)
	filtered := withoutJSONFlag(args)
	if len(filtered) != 0 {
		return fmt.Errorf("usage: meshclaw adapters [--json]")
	}
	items := runtimeflow.AdapterRegistry()
	if jsonOut {
		return printJSON(map[string]interface{}{"adapters": items})
	}
	fmt.Printf("%-10s %-28s %-10s %s\n", "NAME", "KIND", "EXECUTES", "DESCRIPTION")
	for _, adapter := range items {
		fmt.Printf("%-10s %-28s %-10t %s\n", adapter.Name, adapter.Kind, adapter.Executable, adapter.Description)
	}
	return nil
}

func printCapabilities(caps []capability.Capability) {
	fmt.Printf("%-18s %-13s %-14s %-18s %s\n", "ID", "KIND", "PROVIDER", "STATUS", "POLICY")
	for _, cap := range caps {
		fmt.Printf("%-18s %-13s %-14s %-18s %s\n", cap.ID, cap.Kind, cap.Provider, cap.Status, cap.Policy)
	}
}

func printCapabilityValidation(report capability.ValidationReport) {
	status := "valid"
	if !report.Valid {
		status = "invalid"
	}
	fmt.Printf("capability registry: %s\n", report.Path)
	fmt.Printf("status=%s capabilities=%d errors=%d warnings=%d\n", status, report.Count, len(report.Errors), len(report.Warnings))
	for _, issue := range report.Errors {
		if issue.Capability != "" {
			fmt.Printf("error %s.%s: %s\n", issue.Capability, issue.Field, issue.Message)
		} else {
			fmt.Printf("error %s: %s\n", issue.Field, issue.Message)
		}
	}
	for _, issue := range report.Warnings {
		if issue.Capability != "" {
			fmt.Printf("warning %s.%s: %s\n", issue.Capability, issue.Field, issue.Message)
		} else {
			fmt.Printf("warning %s: %s\n", issue.Field, issue.Message)
		}
	}
}

func printCapabilityRecommendation(report capability.RecommendationReport) {
	fmt.Printf("capability recommendation class=%s intent=%q candidates=%d\n", report.Class, report.Intent, len(report.Candidates))
	fmt.Printf("registry valid=%t count=%d errors=%d warnings=%d path=%s\n", report.Registry.Valid, report.Registry.Count, len(report.Registry.Errors), len(report.Registry.Warnings), report.Registry.Path)
	for i, candidate := range report.Candidates {
		if i >= 5 {
			break
		}
		approval := "no"
		if candidate.ApprovalRequired {
			approval = "yes"
		}
		fmt.Printf("- %s score=%d host=%s provider=%s status=%s approval_required=%s\n", candidate.Capability.ID, candidate.Score, candidate.Capability.Host, candidate.Capability.Provider, candidate.Capability.Status, approval)
		for _, reason := range candidate.Reasons {
			fmt.Printf("  reason: %s\n", reason)
		}
		for _, caution := range candidate.Cautions {
			fmt.Printf("  caution: %s\n", caution)
		}
	}
	fmt.Printf("next: %s\n", report.RecommendedNextCall)
}

func direction(args []string) error {
	payload := map[string]interface{}{
		"one_sentence": "MeshClaw is the AI-native server operations judgement and control layer for mixed private infrastructure.",
		"survives_by": []string{
			"shared fleet truth for Codex, Claude, local LLMs, Matrix, and humans",
			"policy-gated server actions",
			"evidence-backed diagnostics and execution",
			"vssh-native structured remote execution over Tailscale/private routes",
			"safe remediation and approval-gated risky actions",
		},
		"does_not_do": []string{
			"general assistant chat",
			"assistant personality",
			"coding-agent replacement",
			"email/calendar/lifestyle automation",
			"Matrix-first personal assistant UX",
		},
		"core_loop": []string{
			"model asks MeshClaw MCP for truth",
			"MeshClaw reads inventory, policy, facts, logs, and evidence",
			"MeshClaw returns a plan or executes allowed safe action",
			"risky actions require explicit approval",
			"MeshClaw stores evidence",
		},
		"mvp_tools": []string{
			"ops-control",
			"placement-plan",
			"service-triage",
			"fleet-service-audit",
			"service-check",
			"hygiene-scan-host",
			"workspace-list",
			"policy-check",
			"run-evidence",
			"provision-plan",
		},
		"doc": "docs/SURVIVAL_DIRECTION.md",
	}
	if wantsJSON(args) {
		return printJSON(payload)
	}
	fmt.Println(payload["one_sentence"])
	fmt.Println()
	fmt.Println("Survives by:")
	for _, item := range payload["survives_by"].([]string) {
		fmt.Println("- " + item)
	}
	fmt.Println()
	fmt.Println("Does not do:")
	for _, item := range payload["does_not_do"].([]string) {
		fmt.Println("- " + item)
	}
	fmt.Println()
	fmt.Println("MVP tools:")
	for _, item := range payload["mvp_tools"].([]string) {
		fmt.Println("- " + item)
	}
	fmt.Println()
	fmt.Println("See: docs/SURVIVAL_DIRECTION.md")
	return nil
}

func status() error {
	out, err := runtime.NewRunner().Status()
	fmt.Print(out)
	return err
}

type monitorCheckOutput struct {
	States map[string]*monitor.NodeState `json:"states"`
	Alerts []monitor.Alert               `json:"alerts"`
}

type monitorAgentOutput struct {
	States  map[string]*monitor.NodeState `json:"states"`
	Alerts  []monitor.Alert               `json:"alerts"`
	Hygiene []hygiene.Report              `json:"hygiene,omitempty"`
}

func monitorCheck(args []string) error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	states := m.CheckAll()
	alerts := m.DetectAlerts()
	record, storeErr := evidence.Store("monitor-check", "fleet", fmt.Sprintf("alerts=%d", len(alerts)), monitorCheckOutput{States: states, Alerts: alerts})
	if wantsJSON(args) {
		return printJSON(map[string]interface{}{"states": states, "alerts": alerts, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("%-10s %-7s %-15s %6s %6s %s\n", "NODE", "ONLINE", "IP", "DISK", "MEM", "ERROR")
	for _, node := range inventory.DefaultNodes() {
		state := states[node.Name]
		if state == nil {
			continue
		}
		fmt.Printf("%-10s %-7t %-15s %5.1f%% %5.1f%% %s\n", state.Name, state.Online, state.IP, state.Disk, state.Memory, state.Error)
	}
	if len(alerts) > 0 {
		fmt.Println("alerts:")
		for _, alert := range alerts {
			fmt.Printf("- [%s] %s %s: %s\n", alert.Level, alert.Node, alert.Type, alert.Message)
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func autohealPlan(args []string) error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	m.CheckAll()
	serviceTriage, _, serviceStoreErr := buildServiceTriage(nil, 5, 4)
	actions := buildAutohealPlan(m, serviceTriage)
	report := buildAutohealPlanReport(actions)
	record, storeErr := evidence.Store("autoheal-plan", "fleet", fmt.Sprintf("actions=%d", len(actions)), report)
	if storeErr == nil {
		storeErr = serviceStoreErr
	}
	if wantsJSON(args) {
		return printJSON(map[string]interface{}{"actions": actions, "recommended_mcp": report.RecommendedMCP, "report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	if len(actions) == 0 {
		fmt.Println("autoheal status=ok actions=0")
		printEvidenceStoreStatus(record, storeErr)
		return nil
	}
	fmt.Println("autoheal status=actions")
	for _, action := range actions {
		fmt.Printf("- [%s/%s] %s %s=%.1f mode=%s\n  command: %s\n  reason: %s\n  verify: %s\n",
			action.Severity, action.Type, action.Node, action.Metric, action.Value, action.Mode, action.Command, action.Reason, action.Verify)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func buildAutohealPlan(m *monitor.Monitor, serviceTriage serviceTriageReport) []monitor.HealPlanAction {
	actions := monitor.NewAutoHealer(m).Plan()
	actions = append(actions, serviceTriagePlanActions(serviceTriage)...)
	annotateHealPlanPolicies(actions)
	return actions
}

func buildAutohealPlanReport(actions []monitor.HealPlanAction) autohealPlanReport {
	report := autohealPlanReport{
		Actions:        actions,
		RecommendedMCP: recommendedAutohealPlanMCP(actions),
		Counts:         map[string]int{},
	}
	for _, action := range actions {
		report.Counts["total"]++
		if action.Mode != "" {
			report.Counts["mode_"+action.Mode]++
		}
		if action.ApprovalRequired {
			report.Counts["approval_required"]++
		}
		if action.PolicyDecision != "" {
			report.Counts["policy_"+action.PolicyDecision]++
		}
	}
	return report
}

func annotateHealPlanPolicies(actions []monitor.HealPlanAction) {
	for i := range actions {
		policyAction := policyActionForHealPlan(actions[i])
		result := policy.Evaluate(policy.Request{
			Subject:  "codex",
			Action:   policyAction,
			Resource: "server",
			Context:  actions[i].Command,
		})
		actions[i].PolicyAction = policyAction
		actions[i].PolicyDecision = string(result.Decision)
		actions[i].PolicyReason = result.Reason
		actions[i].ApprovalRequired = result.Decision == policy.RequireApproval || actions[i].Mode == "approval_required" || actions[i].Mode == "requires_approval"
	}
}

func policyActionForHealPlan(action monitor.HealPlanAction) string {
	switch action.Type {
	case "disk_investigate":
		return "disk_investigate"
	case "disk_cleanup", "memory_cleanup":
		return "autoheal_apply_safe"
	case "connectivity":
		return "doctor"
	case "service_triage":
		return "service_check"
	case "service_quarantine_candidate":
		return "service_quarantine"
	default:
		return "run_command"
	}
}

func serviceTriagePlanActions(report serviceTriageReport) []monitor.HealPlanAction {
	actions := make([]monitor.HealPlanAction, 0, len(report.Items))
	for _, item := range report.Items {
		if item.Class == "ignore_candidate" || item.Mode == "ignore_candidate" {
			continue
		}
		mode := item.Mode
		if mode == "" {
			mode = "read_only"
		}
		command := item.Next
		if command == "" && item.Service != "" {
			command = fmt.Sprintf("meshclaw service-check %s %s", item.Host, item.Service)
		}
		if command == "" {
			command = fmt.Sprintf("meshclaw service-audit %s", item.Host)
		}
		service := item.Service
		if service == "" {
			service = "unknown"
		}
		severity := item.Severity
		if severity == "" {
			severity = "warning"
		}
		actionType := "service_triage"
		if item.Class == "stale_or_missing_target" {
			actionType = "service_quarantine_candidate"
		}
		actions = append(actions, monitor.HealPlanAction{
			Node:     item.Host,
			Type:     actionType,
			Severity: severity,
			Metric:   "service:" + service,
			Value:    1,
			Mode:     mode,
			Command:  command,
			Reason:   item.Judgement,
			Verify:   fmt.Sprintf("meshclaw service-check %s %s", item.Host, service),
		})
	}
	return actions
}

func autohealApplySafe() error {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		return err
	}
	m.CheckAll()
	serviceTriage, _, serviceStoreErr := buildServiceTriage(nil, 5, 4)
	plan := buildAutohealPlan(m, serviceTriage)
	actions := applyAutohealPlanSafe(plan)
	record, storeErr := evidence.Store("autoheal-apply-safe", "fleet", fmt.Sprintf("actions=%d", len(actions)), actions)
	if storeErr == nil {
		storeErr = serviceStoreErr
	}
	if len(actions) == 0 {
		fmt.Println("autoheal apply status=ok actions=0")
		printEvidenceStoreStatus(record, storeErr)
		return nil
	}
	fmt.Println("autoheal apply status=done")
	for _, action := range actions {
		fmt.Printf("- [%t] %s %s policy=%s approval_required=%t\n  command: %s\n  result: %s\n", action.Success, action.Node, action.Type, action.PolicyDecision, action.ApprovalRequired, action.Command, action.Result)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func applyAutohealPlanSafe(plan []monitor.HealPlanAction) []monitor.HealAction {
	actions := make([]monitor.HealAction, 0, len(plan))
	for _, item := range plan {
		action := healActionFromPlan(item)
		if item.PolicyDecision != string(policy.Allow) || item.ApprovalRequired {
			action.Skipped = true
			action.SkipReason = "policy does not allow unattended execution"
			action.Result = action.SkipReason
			actions = append(actions, action)
			continue
		}
		if item.Mode != "auto_safe" {
			action.Skipped = true
			action.SkipReason = "plan action is not auto_safe"
			action.Result = action.SkipReason
			actions = append(actions, action)
			continue
		}
		result := runtime.NewRunner().RunEvidence(item.Node, item.Command)
		applyRuntimeResultToHealAction(&action, result)
		actions = append(actions, action)
	}
	return actions
}

func healActionFromPlan(item monitor.HealPlanAction) monitor.HealAction {
	return monitor.HealAction{
		Node:             item.Node,
		Type:             item.Type,
		Command:          item.Command,
		PolicyAction:     item.PolicyAction,
		PolicyDecision:   item.PolicyDecision,
		PolicyReason:     item.PolicyReason,
		ApprovalRequired: item.ApprovalRequired,
		Time:             time.Now().UTC(),
	}
}

func applyRuntimeResultToHealAction(action *monitor.HealAction, result runtime.Evidence) {
	action.Success = result.Success
	action.Transport = result.Transport
	action.ExitCode = result.ExitCode
	output := strings.TrimSpace(result.Stdout + result.Stderr)
	if result.Success {
		if output == "" {
			action.Result = fmt.Sprintf("completed via %s", result.Transport)
			return
		}
		action.Result = output
		return
	}
	if output == "" {
		action.Result = fmt.Sprintf("failed via %s exit=%d", result.Transport, result.ExitCode)
		return
	}
	action.Result = fmt.Sprintf("failed via %s exit=%d\n%s", result.Transport, result.ExitCode, output)
}

func annotateHealActionsPolicies(actions []monitor.HealAction) {
	for i := range actions {
		policyAction := policyActionForHealType(actions[i].Type)
		result := policy.Evaluate(policy.Request{
			Subject:  "automation",
			Action:   policyAction,
			Resource: "server",
			Context:  actions[i].Command,
		})
		actions[i].PolicyAction = policyAction
		actions[i].PolicyDecision = string(result.Decision)
		actions[i].PolicyReason = result.Reason
		actions[i].ApprovalRequired = result.Decision == policy.RequireApproval
	}
}

func policyActionForHealType(actionType string) string {
	switch actionType {
	case "disk_cleanup", "memory_cleanup":
		return "autoheal_apply_safe"
	case "restart_service":
		return "restart_service"
	default:
		return "run_command"
	}
}

func diskInvestigate(args []string) error {
	if len(args) < 1 || len(args) > 2 {
		return fmt.Errorf("usage: meshclaw disk-investigate <host> [path]")
	}
	host := args[0]
	path := "/"
	if len(args) == 2 {
		path = args[1]
	}
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if !strings.HasPrefix(path, "/") {
		return fmt.Errorf("path must be absolute: %s", path)
	}
	quoted := shellQuote(path)
	command := fmt.Sprintf("df -h %s && sudo du -xhd1 %s 2>/dev/null | sort -h | tail -40", quoted, quoted)
	result := runtime.NewRunner().RunEvidence(host, command)
	record, storeErr := evidence.Store("disk-investigate", host, path, result)
	fmt.Printf("disk-investigate host=%s path=%s success=%t transport=%s\n", host, path, result.Success, result.Transport)
	if result.Stdout != "" {
		fmt.Print(result.Stdout)
	}
	if result.Stderr != "" {
		fmt.Fprint(os.Stderr, result.Stderr)
	}
	if storeErr != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", storeErr)
	} else {
		fmt.Printf("evidence=%s\n", record.StoredAt)
	}
	if !result.Success {
		return fmt.Errorf("disk investigation failed on %s", host)
	}
	return nil
}

func processTop(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw process-top <host>")
	}
	report := workflow.ProcessTop(args[0])
	printReport(report)
	record, storeErr := evidence.Store("process-top", args[0], "top memory/cpu processes", report)
	printEvidenceStoreStatus(record, storeErr)
	if report.Status == "failed" || report.Status == "unknown_node" {
		return fmt.Errorf("process-top failed on %s", args[0])
	}
	return nil
}

func dataCleanPlan(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw data-clean-plan <host> <path>")
	}
	report := workflow.DataCleanPlan(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("data-clean-plan", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func dataCleanApply(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw data-clean-apply <host> <manifest>")
	}
	report := workflow.DataCleanApply(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("data-clean-apply", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func shellQuote(value string) string {
	return "'" + strings.ReplaceAll(value, "'", "'\\''") + "'"
}

func evidenceList(args []string) error {
	limit := 20
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) > 1 {
		return fmt.Errorf("usage: meshclaw evidence-list [limit]")
	}
	if len(args) == 1 {
		if _, err := fmt.Sscanf(args[0], "%d", &limit); err != nil {
			return fmt.Errorf("invalid limit: %s", args[0])
		}
	}
	records, err := evidence.List(limit)
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(records)
	}
	if len(records) == 0 {
		fmt.Println("evidence records=0")
		return nil
	}
	fmt.Printf("%-20s %-18s %-10s %-22s %s\n", "TIME", "KIND", "HOST", "SUMMARY", "PATH")
	for _, record := range records {
		fmt.Printf("%-20s %-18s %-10s %-22s %s\n",
			record.Time.Local().Format("2006-01-02 15:04:05"),
			record.Kind,
			record.Host,
			truncate(record.Summary, 22),
			record.StoredAt,
		)
	}
	return nil
}

func evidenceCommand(args []string) error {
	if len(args) == 2 && args[0] == "open" && args[1] == "latest" {
		path, err := runtimeflow.LatestBundle()
		if err != nil {
			return err
		}
		fmt.Println(path)
		return nil
	}
	return fmt.Errorf("usage: meshclaw evidence open latest")
}

func truncate(value string, max int) string {
	if len(value) <= max {
		return value
	}
	if max <= 3 {
		return value[:max]
	}
	return value[:max-3] + "..."
}

func policyCheck(args []string) error {
	if len(args) < 3 {
		return fmt.Errorf("usage: meshclaw policy-check <subject> <action> <resource> [context]")
	}
	request := policy.Request{
		Subject:  args[0],
		Action:   args[1],
		Resource: args[2],
	}
	if len(args) > 3 {
		request.Context = strings.Join(args[3:], " ")
	}
	result := policy.Evaluate(request)
	return printJSON(result)
}

func policyShow(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw policy-show")
	}
	cfg, path, err := policy.LoadConfig()
	if err != nil {
		return err
	}
	return printJSON(map[string]interface{}{"path": path, "policy": cfg})
}

func policyInit(args []string) error {
	force := false
	preset := "devops"
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "--force" {
			force = true
			continue
		}
		if arg == "--preset" {
			i++
			if i >= len(args) {
				return fmt.Errorf("--preset requires a value")
			}
			preset = args[i]
			continue
		}
		return fmt.Errorf("usage: meshclaw policy-init [--preset devops|strict] [--force]")
	}
	_, path, err := policy.LoadConfig()
	if err != nil {
		return err
	}
	if !force {
		if _, err := os.Stat(path); err == nil {
			return fmt.Errorf("policy file already exists: %s", path)
		} else if !os.IsNotExist(err) {
			return err
		}
	}
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	data, err := json.MarshalIndent(policy.PresetConfig(preset), "", "  ")
	if err != nil {
		return err
	}
	if err := os.WriteFile(path, append(data, '\n'), 0600); err != nil {
		return err
	}
	fmt.Printf("policy=%s preset=%s\n", path, preset)
	return nil
}

func policyPresets(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw policy-presets")
	}
	return printJSON(policy.PresetNames())
}

func matrixBridgePlan(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw matrix-plan")
	}
	return printJSON(map[string]interface{}{
		"role": "Matrix is an operations room, approval channel, notification channel, and optional MCP command surface. It is not the assistant brain.",
		"flow": []string{
			"human or AI operator posts an ops request in Matrix",
			"Matrix bridge normalizes the request into a MeshClaw MCP/CLI tool call",
			"MeshClaw policy decides allow, require_approval, or deny",
			"MeshClaw executes only allowed tools through vssh/runtime",
			"Matrix bridge posts concise results and evidence links back to the room",
		},
		"allowed_by_default": []string{
			"server_list",
			"capability_list",
			"monitor_check",
			"fleet_scan",
			"evidence_list",
			"policy_check",
			"policy_show",
			"analyze_logs",
			"security_check",
			"hygiene_scan_host",
		},
		"approval_gated": []string{
			"run_command",
			"autoheal_apply_safe",
			"service_remove",
			"provision_server",
			"deprovision_server",
			"rotate_secret",
		},
	})
}

func matrixConfigInit(args []string) error {
	force := false
	for _, arg := range args {
		if arg == "--force" {
			force = true
			continue
		}
		return fmt.Errorf("usage: meshclaw matrix-config-init [--force]")
	}
	target, err := matrixops.DefaultConfigPath()
	if err != nil {
		return err
	}
	if !force {
		if _, err := os.Stat(target); err == nil {
			return fmt.Errorf("matrix config already exists: %s", target)
		}
	}
	cfg, source, err := matrixops.LoadConfig()
	if err != nil {
		return err
	}
	if source == target && !force {
		return fmt.Errorf("matrix config already exists: %s", target)
	}
	if err := matrixops.SaveConfig(target, cfg); err != nil {
		return err
	}
	fmt.Printf("matrix_config=%s copied_from=%s\n", target, source)
	return nil
}

func matrixPost(args []string) error {
	if len(args) == 0 {
		return fmt.Errorf("usage: meshclaw matrix-post <message>")
	}
	cfg, path, err := matrixops.LoadConfig()
	if err != nil {
		return err
	}
	ctx, cancel := contextWithSignal()
	defer cancel()
	if err := matrixops.NewClient(cfg).SendText(ctx, strings.Join(args, " ")); err != nil {
		return err
	}
	fmt.Printf("posted matrix_room=%s config=%s\n", cfg.RoomID, path)
	return nil
}

func matrixSyncOnce(args []string) error {
	if len(args) > 1 {
		return fmt.Errorf("usage: meshclaw matrix-sync-once [since]")
	}
	since := ""
	if len(args) == 1 {
		since = args[0]
	}
	cfg, path, err := matrixops.LoadConfig()
	if err != nil {
		return err
	}
	ctx, cancel := contextWithSignal()
	defer cancel()
	result, err := matrixops.NewClient(cfg).SyncOnce(ctx, since, dispatchOpsMessage)
	if err != nil {
		return err
	}
	return printJSON(map[string]interface{}{"config": path, "room_id": cfg.RoomID, "result": result})
}

func matrixBridge(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw matrix-bridge")
	}
	cfg, path, err := matrixops.LoadConfig()
	if err != nil {
		return err
	}
	fmt.Printf("matrix_bridge=running room=%s config=%s prefix=%s\n", cfg.RoomID, path, cfg.CommandPrefix)
	ctx, cancel := contextWithSignal()
	defer cancel()
	return matrixops.NewClient(cfg).Bridge(ctx, dispatchOpsMessage)
}

func matrixDoctor(args []string) error {
	jsonOut := false
	for _, arg := range args {
		switch arg {
		case "--json":
			jsonOut = true
		default:
			return fmt.Errorf("usage: meshclaw matrix-doctor [--json]")
		}
	}
	report := buildMatrixDoctorReport()
	if jsonOut {
		return printJSON(report)
	}
	fmt.Println(matrixops.FormatExplainedResult(map[string]interface{}{
		"route":  "matrix_doctor",
		"result": report,
	}))
	return nil
}

func buildMatrixDoctorReport() map[string]interface{} {
	cfg, path, err := matrixops.LoadConfig()
	report := map[string]interface{}{
		"config_path": path,
	}
	if err != nil {
		report["status"] = "failed"
		report["error"] = err.Error()
		return report
	}
	report["status"] = "ok"
	report["homeserver"] = cfg.Homeserver
	report["room_id"] = cfg.RoomID
	report["user_id"] = cfg.UserID
	report["command_prefix"] = cfg.CommandPrefix
	report["ambient_chat"] = cfg.AmbientChat
	report["private_tailscale"] = isPrivateTailscaleHomeserver(cfg.Homeserver)
	report["server_reachable"] = matrixEndpointReachable(cfg.Homeserver + "/_matrix/client/versions")
	report["client_endpoints"] = matrixClientEndpointChecks(cfg)
	report["room_alias"] = "#meshclaw-ops:matrix.hunmin.ai"
	report["rooms"] = []map[string]interface{}{
		matrixRoomDoctor(cfg, "configured", cfg.RoomID),
		matrixRoomDoctor(cfg, "legacy", legacyMatrixRoomID()),
	}
	report["expected_members"] = expectedMatrixMembers()
	report["client_steps"] = []string{
		"Matrix 클라이언트의 홈서버 주소를 현재 설정된 homeserver와 맞춘다.",
		"https://matrix.hunmin.ai 로 접속하도록 되어 있으면 443 프록시 상태를 먼저 확인한다.",
		"방 목록에서 MeshClaw Ops 또는 #meshclaw-ops:matrix.hunmin.ai 를 연다.",
		"MeshClaw Fresh Unencrypted 같은 옛 Brain 방은 서버 운영 봇이 더 이상 듣지 않는 레거시 방이다.",
	}
	report["safe_defaults"] = map[string]interface{}{
		"message_limit": os.Getenv("MESHCLAW_MATRIX_MESSAGE_LIMIT"),
		"chunk_limit":   os.Getenv("MESHCLAW_MATRIX_CHUNK_LIMIT"),
	}
	return report
}

func legacyMatrixRoomID() string {
	if value := strings.TrimSpace(os.Getenv("MESHCLAW_MATRIX_LEGACY_ROOM_ID")); value != "" {
		return value
	}
	return "!RMIqfQPNWFKJsGb0:matrix.hunmin.ai"
}

func expectedMatrixMembers() []string {
	if value := strings.TrimSpace(os.Getenv("MESHCLAW_MATRIX_EXPECTED_MEMBERS")); value != "" {
		parts := strings.Split(value, ",")
		out := make([]string, 0, len(parts))
		for _, part := range parts {
			if item := strings.TrimSpace(part); item != "" {
				out = append(out, item)
			}
		}
		if len(out) > 0 {
			return out
		}
	}
	return []string{
		"@dragon:matrix.hunmin.ai",
		"@yoon:matrix.hunmin.ai",
		"@dev:matrix.hunmin.ai",
		"@ops-ai:matrix.hunmin.ai",
		"@meshclaw:matrix.hunmin.ai",
	}
}

func matrixRoomDoctor(cfg matrixops.Config, label, roomID string) map[string]interface{} {
	room := map[string]interface{}{
		"label":   label,
		"room_id": roomID,
	}
	if roomID == "" {
		room["status"] = "skipped"
		return room
	}
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	var name map[string]interface{}
	if err := matrixAuthedGET(ctx, cfg, "/_matrix/client/v3/rooms/"+url.PathEscape(roomID)+"/state/m.room.name", &name); err == nil {
		room["name"] = name["name"]
	}
	var topic map[string]interface{}
	if err := matrixAuthedGET(ctx, cfg, "/_matrix/client/v3/rooms/"+url.PathEscape(roomID)+"/state/m.room.topic", &topic); err == nil {
		room["topic"] = topic["topic"]
	}
	var joined struct {
		Joined map[string]interface{} `json:"joined"`
	}
	if err := matrixAuthedGET(ctx, cfg, "/_matrix/client/v3/rooms/"+url.PathEscape(roomID)+"/joined_members", &joined); err != nil {
		room["joined_error"] = err.Error()
	} else {
		room["joined_count"] = len(joined.Joined)
		room["joined"] = sortedMapKeys(joined.Joined)
	}
	var members struct {
		Chunk []struct {
			StateKey string `json:"state_key"`
			Content  struct {
				Membership string `json:"membership"`
			} `json:"content"`
		} `json:"chunk"`
	}
	if err := matrixAuthedGET(ctx, cfg, "/_matrix/client/v3/rooms/"+url.PathEscape(roomID)+"/members", &members); err != nil {
		room["members_error"] = err.Error()
	} else {
		membership := map[string]string{}
		counts := map[string]int{}
		for _, event := range members.Chunk {
			state := strings.TrimSpace(event.Content.Membership)
			if state == "" {
				continue
			}
			membership[event.StateKey] = state
			counts[state]++
		}
		room["membership"] = membership
		room["membership_counts"] = counts
	}
	return room
}

func matrixAuthedGET(ctx context.Context, cfg matrixops.Config, path string, out interface{}) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, cfg.Homeserver+path, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+cfg.AccessToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("%s", resp.Status)
	}
	return json.NewDecoder(resp.Body).Decode(out)
}

func sortedMapKeys[V any](m map[string]V) []string {
	keys := make([]string, 0, len(m))
	for key := range m {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	return keys
}

func isPrivateTailscaleHomeserver(raw string) bool {
	u, err := url.Parse(raw)
	if err != nil {
		return false
	}
	host := u.Hostname()
	return strings.HasPrefix(host, "100.")
}

func matrixClientEndpointChecks(cfg matrixops.Config) map[string]interface{} {
	out := map[string]interface{}{}
	serverName := matrixServerName(cfg)
	if serverName != "" {
		out["https_default"] = matrixEndpointReachable("https://" + serverName + "/_matrix/client/versions")
		out["http_8008"] = matrixEndpointReachable("http://" + serverName + ":8008/_matrix/client/versions")
		out["well_known"] = matrixEndpointReachable("https://" + serverName + "/.well-known/matrix/client")
	}
	if cfg.Homeserver != "" {
		out["configured"] = matrixEndpointReachable(strings.TrimRight(cfg.Homeserver, "/") + "/_matrix/client/versions")
	}
	return out
}

func matrixServerName(cfg matrixops.Config) string {
	for _, value := range []string{cfg.UserID, cfg.RoomID} {
		if idx := strings.LastIndex(value, ":"); idx >= 0 && idx+1 < len(value) {
			return value[idx+1:]
		}
	}
	if u, err := url.Parse(cfg.Homeserver); err == nil {
		return u.Hostname()
	}
	return ""
}

func matrixEndpointReachable(endpoint string) map[string]interface{} {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint, nil)
	if err != nil {
		return map[string]interface{}{"ok": false, "error": err.Error()}
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return map[string]interface{}{"ok": false, "error": err.Error()}
	}
	defer resp.Body.Close()
	return map[string]interface{}{"ok": resp.StatusCode >= 200 && resp.StatusCode < 300, "status": resp.Status}
}

func matrixAIConfigInit(args []string) error {
	force := false
	for _, arg := range args {
		if arg == "--force" {
			force = true
			continue
		}
		return fmt.Errorf("usage: meshclaw matrix-ai-config-init [--force]")
	}
	path, err := aichat.DefaultConfigPath()
	if err != nil {
		return err
	}
	if !force {
		if _, err := os.Stat(path); err == nil {
			return fmt.Errorf("matrix AI config already exists: %s", path)
		}
	}
	if err := aichat.SaveConfig(path, aichat.DefaultConfig()); err != nil {
		return err
	}
	fmt.Printf("matrix_ai_config=%s\n", path)
	return nil
}

func matrixAIChat(args []string) error {
	if len(args) == 0 {
		return fmt.Errorf("usage: meshclaw matrix-ai-chat <message>")
	}
	cfg, path, err := aichat.LoadConfig()
	if err != nil {
		return err
	}
	ctx, cancel := contextWithSignal()
	defer cancel()
	message := strings.Join(args, " ")
	reply, err := matrixAIReply(ctx, aichat.NewClient(cfg), nil, message)
	if err != nil {
		return err
	}
	fmt.Printf("ai_config=%s model=%s\n\n%s\n", path, cfg.Model, reply)
	return nil
}

func matrixAIBridge(args []string) error {
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw matrix-ai-bridge")
	}
	matrixCfg, matrixPath, err := matrixops.LoadConfig()
	if err != nil {
		return err
	}
	aiCfg, aiPath, err := aichat.LoadConfig()
	if err != nil {
		return err
	}
	client := aichat.NewClient(aiCfg)
	history := make([]aichat.Message, 0, 24)
	reply := func(message string) (string, error) {
		out, err := matrixAIReply(context.Background(), client, history, message)
		if err != nil {
			return "", err
		}
		history = append(history, aichat.Message{Role: "user", Content: message}, aichat.Message{Role: "assistant", Content: out})
		if len(history) > 24 {
			history = history[len(history)-24:]
		}
		return out, nil
	}
	fmt.Printf("matrix_ai_bridge=running room=%s matrix_config=%s ai_config=%s model=%s\n", matrixCfg.RoomID, matrixPath, aiPath, aiCfg.Model)
	ctx, cancel := contextWithSignal()
	defer cancel()
	return matrixops.NewClient(matrixCfg).BridgeReply(ctx, reply)
}

func matrixAIReply(ctx context.Context, client *aichat.Client, history []aichat.Message, message string) (string, error) {
	if shouldRouteMatrixAIToTool(message) {
		result, err := dispatchOpsMessage("matrix-ai", message)
		if err != nil {
			return "", err
		}
		return matrixops.FormatExplainedResultForQuery(result, message), nil
	}
	if isDangerousMatrixAIAction(message) {
		return dangerousMatrixAIActionResponse(message), nil
	}
	return client.Chat(ctx, history, message)
}

func isDangerousMatrixAIAction(message string) bool {
	lower := strings.ToLower(strings.TrimSpace(message))
	if lower == "" {
		return false
	}
	hasAction := containsAny(lower,
		"실행", "해줘", "삭제", "지워", "제거", "초기화", "재시작", "중지", "종료", "배포", "적용", "수정", "변경", "임대", "구매", "생성",
		"run", "execute", "delete", "remove", "wipe", "reset", "restart", "stop", "shutdown", "deploy", "apply", "modify", "change", "provision", "create",
	)
	if !hasAction {
		return false
	}
	return containsAny(lower,
		"rm -rf", "sudo", "systemctl", "docker", "kubectl", "iptables", "ufw", "chmod", "chown", "mkfs", "dd ",
		"서버", "노드", "서비스", "디스크", "파일", "폴더", "권한", "방화벽", "vps", "provider", "api key", "secret",
		"nginx", "postgres", "mysql", "redis", "docker", "ollama",
	) || mentionsKnownNode(lower)
}

func dangerousMatrixAIActionResponse(message string) string {
	return strings.Join([]string{
		"Decision: this request may change or damage real systems, so the chat model must not execute it directly.",
		"판단: 이 요청은 실제 시스템 변경 또는 파괴적 실행으로 이어질 수 있어서 대화 모델이 직접 수행하면 안 됩니다.",
		"",
		"Request / 요청:",
		message,
		"",
		"Reason / 근거:",
		"- Server commands, deletion, permission changes, service restarts, deployments, VPS rental, and external API calls can change production state.",
		"- 서버 명령 실행, 삭제, 권한 변경, 서비스 재시작, 배포, VPS 임대, 외부 API 호출은 운영 상태를 바꿀 수 있습니다.",
		"- @ops-ai should summarize intent; real execution must go through @dev/MeshClaw policy gates and evidence logging.",
		"- @ops-ai는 대화와 판단 정리를 맡고, 실제 실행은 @dev/MeshClaw 정책 게이트와 evidence 기록을 거쳐야 합니다.",
		"- Do not proceed when target, scope, rollback, and approving actor are unclear.",
		"- 실행 범위, 대상 서버, 경로, 롤백 방법, 승인 주체가 명확하지 않으면 진행하면 안 됩니다.",
		"",
		"Next actions / 다음 행동:",
		"1. Specify the exact target server, service, or path.",
		"1. 대상 서버/서비스/경로를 정확히 지정합니다.",
		"2. State the desired result and rollback method.",
		"2. 원하는 결과와 롤백 방법을 적습니다.",
		"3. Start with read-only state checks, e.g. `show server status`, `show workspaces`, `show recent evidence`.",
		"3. 먼저 조회 명령으로 현재 상태를 확인합니다. 예: `서버 상태 보여줘`, `워크스페이스 보여줘`, `최근 기록 보여줘`.",
		"4. If execution is required, run it through MeshClaw policy-check and evidence capture.",
		"4. 실제 실행이 필요하면 @dev/MeshClaw policy-check와 evidence 기록을 거쳐 실행해야 합니다.",
	}, "\n")
}

func shouldRouteMatrixAIToTool(message string) bool {
	lower := strings.ToLower(strings.TrimSpace(message))
	if lower == "" {
		return false
	}
	hasQueryIntent := containsAny(lower,
		"보여줘", "보여 줘", "조회", "목록", "리스트", "확인", "체크", "상태", "최근", "현재",
		"어때", "왜", "높아", "문제", "이상", "알려줘", "요약", "분류", "해야", "깔려", "좋아", "돌리면", "로딩", "안돌아", "안 돌아", "기다",
		"show", "list", "check", "status", "current", "recent",
		"why", "problem", "issue",
	)
	if !hasQueryIntent {
		return false
	}
	return containsAny(lower,
		"workers", "worker", "작업자", "워커",
		"workspaces", "workspace", "워크스페이스", "작업공간",
		"ops-brief", "ops brief", "운영 브리핑", "운영 요약", "전체 요약", "뭐 해야", "무엇을 해야", "상태 요약",
		"ops-control", "ops control", "서버 관리", "서버관리", "상태 관리", "상태관리", "관리해", "자동 관리", "자동관리", "조치 후보", "복구 후보",
		"vssh-daemon-audit", "vssh daemon", "vsshd", "vssh 인증", "vssh 연결", "vssh 데몬",
		"node-inventory", "fleet-inventory", "software inventory", "설치", "깔려", "깔린", "인벤토리", "뭐뭐",
		"placement-plan", "workload", "배치", "어디서", "어디에", "어느 노드", "어디 노드", "돌려", "돌리면", "맡겨",
		"process-top", "process top", "top process", "프로세스", "상위 프로세스",
		"service-check", "service check", "서비스 체크", "서비스 확인",
		"service-triage", "service triage", "서비스 triage", "서비스 트리아지", "서비스 분류", "장애 분류",
		"service-audit", "service audit", "서비스 감사", "서비스 장애", "실패 서비스",
		"analyze-logs", "analyze logs", "로그 분석", "로그 확인",
		"security-check", "security check", "보안 점검", "보안 확인",
		"hygiene-scan-host", "hygiene scan", "민감정보", "개인정보", "시크릿", "secret scan",
		"matrix-doctor", "matrix doctor", "매트릭스 진단", "matrix client", "클라이언트 로딩", "서버를 기다", "로딩이 안", "안돌아", "안 돌아",
		"fleet", "monitor", "서버", "모니터", "메모리", "디스크", "gpu", "cpu", "load",
		"evidence", "기록", "증거",
		"policy", "권한", "정책",
	) || mentionsKnownNode(lower)
}

func mentionsKnownNode(lower string) bool {
	return extractKnownNode(lower) != ""
}

func extractKnownNode(lower string) string {
	lower = strings.ToLower(strings.TrimSpace(lower))
	nodes := inventory.DefaultNodes()
	names := make([]string, 0, len(nodes))
	for _, node := range nodes {
		if name := strings.ToLower(strings.TrimSpace(node.Name)); name != "" {
			names = append(names, name)
		}
	}
	sort.Slice(names, func(i, j int) bool { return len(names[i]) > len(names[j]) })
	for _, name := range names {
		if strings.Contains(lower, name+" ") ||
			strings.Contains(lower, name+"에서") ||
			strings.Contains(lower, name+"에 ") ||
			strings.Contains(lower, name+"의") ||
			strings.Contains(lower, name+"가") ||
			strings.Contains(lower, name+"는") ||
			lower == name {
			return name
		}
	}
	return ""
}

func firstNonCommandToken(lower string) string {
	for _, token := range strings.Fields(lower) {
		token = strings.Trim(token, "`'\".,:;()[]{}")
		if token == "" || strings.HasPrefix(token, "!") {
			continue
		}
		if containsAny(token, "process-top", "process", "top", "프로세스", "상위") {
			continue
		}
		return token
	}
	return ""
}

func extractServiceName(lower, host string) string {
	for _, token := range strings.Fields(lower) {
		token = strings.Trim(token, "`'\".,:;()[]{}")
		if token == "" || strings.HasPrefix(token, "!") || token == host {
			continue
		}
		if containsAny(token, "service-check", "service", "check", "서비스", "체크", "확인", "상태", "보여줘") {
			continue
		}
		return token
	}
	return ""
}

func extractLogSource(lower, host string) string {
	for _, token := range strings.Fields(lower) {
		token = strings.Trim(token, "`'\".,:;()[]{}")
		if token == "" || strings.HasPrefix(token, "!") || token == host {
			continue
		}
		if containsAny(token, "analyze-logs", "analyze", "logs", "로그", "분석", "확인", "상태", "보여줘") {
			continue
		}
		return token
	}
	return "system"
}

func contextWithSignal() (context.Context, context.CancelFunc) {
	ctx, cancel := context.WithCancel(context.Background())
	signals := make(chan os.Signal, 1)
	signal.Notify(signals, os.Interrupt, syscall.SIGTERM)
	go func() {
		select {
		case <-signals:
			cancel()
		case <-ctx.Done():
		}
		signal.Stop(signals)
	}()
	return ctx, cancel
}

func workersList(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw workers [--json]")
	}
	list := workers.DefaultWorkers()
	if jsonOut {
		return printJSON(list)
	}
	fmt.Printf("%-16s %-18s %-14s %-13s %s\n", "ID", "KIND", "SUBJECT", "STATUS", "SURFACE")
	for _, worker := range list {
		fmt.Printf("%-16s %-18s %-14s %-13s %s\n", worker.ID, worker.Kind, worker.Subject, worker.Status, worker.Surface)
	}
	return nil
}

type aiGuideEntry struct {
	Intent      string   `json:"intent"`
	Prefer      string   `json:"prefer"`
	Avoid       []string `json:"avoid,omitempty"`
	Reason      string   `json:"reason"`
	Examples    []string `json:"examples"`
	NeedsReview bool     `json:"needs_review,omitempty"`
}

func aiGuide(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw ai-guide [--json]")
	}
	guide := aiGuideEntries()
	if jsonOut {
		return printJSON(guide)
	}
	fmt.Println("AI operator guide")
	for _, entry := range guide {
		fmt.Printf("- %s\n  prefer: %s\n  reason: %s\n", entry.Intent, entry.Prefer, entry.Reason)
		if len(entry.Avoid) > 0 {
			fmt.Printf("  avoid: %s\n", strings.Join(entry.Avoid, ", "))
		}
		if entry.NeedsReview {
			fmt.Println("  review: human/policy review required before apply")
		}
		fmt.Printf("  example: %s\n", entry.Examples[0])
	}
	return nil
}

func toolRecommend(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	subject := "codex"
	intentArgs := make([]string, 0, len(args))
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch {
		case arg == "--subject":
			i++
			if i >= len(args) {
				return fmt.Errorf("--subject requires a value")
			}
			subject = args[i]
		case strings.HasPrefix(arg, "--subject="):
			subject = strings.TrimPrefix(arg, "--subject=")
		default:
			intentArgs = append(intentArgs, arg)
		}
	}
	if len(intentArgs) == 0 {
		return fmt.Errorf("usage: meshclaw tool-recommend <intent> [--subject subject] [--json]")
	}

	rec := recommendToolMCP(strings.Join(intentArgs, " "), subject)
	if jsonOut {
		return printJSON(rec)
	}
	fmt.Printf("recommended: %s\n", stringMapValue(rec, "recommended_tool"))
	fmt.Printf("reason: %s\n", stringMapValue(rec, "reason"))
	fmt.Printf("approval_expected: %v\n", rec["approval_expected"])
	if alternatives, ok := rec["alternatives"].([]string); ok && len(alternatives) > 0 {
		fmt.Printf("alternatives: %s\n", strings.Join(alternatives, ", "))
	}
	if avoid, ok := rec["avoid"].([]string); ok && len(avoid) > 0 {
		fmt.Printf("avoid: %s\n", strings.Join(avoid, ", "))
	}
	if argsValue, ok := rec["arguments"]; ok {
		data, err := json.Marshal(argsValue)
		if err != nil {
			return err
		}
		fmt.Printf("arguments: %s\n", string(data))
	}
	return nil
}

func stringMapValue(values map[string]interface{}, key string) string {
	if value, ok := values[key].(string); ok {
		return value
	}
	return ""
}

func aiGuideEntries() []aiGuideEntry {
	return []aiGuideEntry{
		{
			Intent:   "canonical MeshClaw operating loop",
			Prefer:   "inventory -> inventory overrides -> capability validate/recommend -> workflow dry-run -> evidence -> approval/repair -> targeted execute/resume",
			Avoid:    []string{"jumping straight to raw shell", "choosing nodes from memory when inventory/capability state exists", "treating chat history as the source of truth"},
			Reason:   "MeshClaw exists to make AI operations repeatable, auditable, policy-aware, and grounded in current infrastructure state.",
			Examples: []string{"MCP: meshclaw_server_list -> meshclaw_capability_recommend -> meshclaw_workflow_run", "meshclaw workflows inspect email-orchestration-demo --json"},
		},
		{
			Intent:   "decide which tool layer to use",
			Prefer:   "MeshClaw for policy/state/evidence/workflows; vssh for low-level structured remote execution",
			Avoid:    []string{"treating vssh as a general ops control plane", "using raw SSH when structured facts/evidence are needed"},
			Reason:   "MeshClaw is the AI-native operations runtime; vssh is the execution substrate behind it.",
			Examples: []string{"meshclaw ai-guide --json", "MCP: meshclaw_workflow_run", "vssh facts-many for low-level transport debugging"},
		},
		{
			Intent:   "run a repeatable operational workflow",
			Prefer:   "MCP meshclaw_workflow_run or CLI meshclaw run <workflow> --dry-run/--execute",
			Avoid:    []string{"reconstructing workflow state from chat history", "running every step manually without evidence"},
			Reason:   "Workflow runs create plan.md, execution.json, steps.jsonl, meshclaw-actions.md, and report.html.",
			Examples: []string{"meshclaw run fleet-health-demo --dry-run", "meshclaw run meshclaw-ops-orchestration-demo --dry-run", "meshclaw workflows resume latest --json"},
		},
		{
			Intent:   "the user clarifies node roles or private fleet meaning",
			Prefer:   "MCP meshclaw_inventory_override_set/list or CLI meshclaw inventory-override set/list",
			Avoid:    []string{"hardcoding private node meaning into source code", "ignoring user corrections about which server does what"},
			Reason:   "Inventory discovery supplies network facts; operator-owned overrides supply private role/tag meaning that capability selection needs.",
			Examples: []string{"meshclaw inventory-override set c1 --role mail-server --tag mail --tag mox", "MCP: meshclaw_inventory_override_set"},
		},
		{
			Intent:   "choose a node, model, API, storage lane, mail server, or provisioner",
			Prefer:   "meshclaw capabilities recommend <intent> or MCP meshclaw_capability_recommend",
			Avoid:    []string{"guessing from hostname alone", "using stale placement from chat history"},
			Reason:   "Capability recommendation returns scored candidates with reasons, approval flags, and secret-handling cautions.",
			Examples: []string{"meshclaw capabilities recommend 'run local ollama inference on a gpu node' --json", "MCP: meshclaw_capability_recommend"},
		},
		{
			Intent:   "fleet health or status",
			Prefer:   "meshclaw monitor-check, meshclaw ops-brief, or meshclaw ops-control",
			Avoid:    []string{"raw vssh facts-many as first choice"},
			Reason:   "MeshClaw adds partial-result fallback, policy context, service classification, and evidence.",
			Examples: []string{"meshclaw ops-brief", "meshclaw ops-control --json", "meshclaw monitor-check --json"},
		},
		{
			Intent:   "run a diagnostic command",
			Prefer:   "meshclaw run-evidence <host> <command>",
			Avoid:    []string{"vssh_exec for autonomous AI operation", "ssh for commands that need audit trail"},
			Reason:   "run-evidence keeps audit trail and can fall back when native vssh auth is broken.",
			Examples: []string{"meshclaw run-evidence d1 'df -h'", "meshclaw run-evidence c1 'systemctl is-active mox'"},
		},
		{
			Intent:   "service incident",
			Prefer:   "meshclaw service-triage then meshclaw service-check",
			Reason:   "triage removes stale systemd noise before deep inspection.",
			Examples: []string{"meshclaw service-triage", "meshclaw service-check d1 open-webui"},
		},
		{
			Intent:      "destructive or mutating change",
			Prefer:      "plan command first, then apply-safe only when policy allows",
			Avoid:       []string{"direct rm/systemctl restart/kubectl delete", "provider create/delete without policy approval"},
			Reason:      "plan/apply-safe is the product safety boundary.",
			Examples:    []string{"meshclaw autoheal-plan", "meshclaw autoheal-apply-safe", "meshclaw data-clean-plan <host> <path>"},
			NeedsReview: true,
		},
		{
			Intent:   "vssh auth or daemon failure",
			Prefer:   "meshclaw vssh-daemon-audit, meshclaw vssh-auth-paths, then meshclaw node-repair-plan",
			Reason:   "MeshClaw classifies auth_failed vs unreachable vs version mismatch and returns safe repair steps.",
			Examples: []string{"meshclaw vssh-daemon-audit", "meshclaw vssh-auth-paths --hosts d1,g1", "meshclaw node-repair-plan --hosts s2"},
		},
		{
			Intent:   "use vssh directly",
			Prefer:   "Use direct vssh only for transport-level facts, parallel exec primitives, daemon RPC, or debugging MeshClaw adapters",
			Avoid:    []string{"using direct vssh when policy/evidence/approval are required"},
			Reason:   "Direct vssh is faster and lower-level, but it does not own MeshClaw policy, workflow, or evidence semantics by itself.",
			Examples: []string{"vssh facts-many c1,d1,g1", "vssh exec-many g1,g2,g3 'uptime'"},
		},
		{
			Intent:   "Open WebUI or local model integration",
			Prefer:   "meshclaw openwebui-scan and MeshClaw MCP tools with narrower policy",
			Reason:   "Local/private models can use the same runtime facts while policy controls mutating actions.",
			Examples: []string{"meshclaw openwebui-scan --hosts d1,g2,g3,g4", "meshclaw policy-check local-llm run_command server 'systemctl restart nginx'"},
		},
	}
}

func openwebuiScan(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	var hosts []string
	parallel := 6
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--hosts":
			i++
			if i >= len(args) {
				return fmt.Errorf("--hosts requires a comma-separated value")
			}
			hosts = splitCSV(args[i])
		case "--parallel":
			i++
			if i >= len(args) {
				return fmt.Errorf("--parallel requires a number")
			}
			n, err := parsePositiveInt(args[i], "--parallel")
			if err != nil {
				return err
			}
			parallel = n
		default:
			return fmt.Errorf("usage: meshclaw openwebui-scan [--hosts a,b] [--parallel n] [--json]")
		}
	}
	report, err := openwebui.Scan(hosts, parallel)
	if err != nil {
		return err
	}
	record, storeErr := evidence.Store("openwebui-scan", "fleet", fmt.Sprintf("installed=%d pipe=%d gateway=%d failures=%d", report.Installed, report.WithPipe, report.WithGateway, report.Failures), report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("Open WebUI scan: installed=%d pipe=%d gateway=%d failures=%d\n", report.Installed, report.WithPipe, report.WithGateway, report.Failures)
	for _, host := range report.Hosts {
		switch host.Status {
		case "ok":
			auth := "unknown"
			if host.Auth != nil {
				auth = fmt.Sprintf("%t", *host.Auth)
			}
			fmt.Printf("- %s: ok | %s %s | auth=%s | runtime=%s | gateway=%s\n", host.Host, host.Name, host.Version, auth, host.Runtime, host.Gateway)
		case "not_installed":
			fmt.Printf("- %s: not installed\n", host.Host)
		case "missing_pipe", "missing_gateway":
			fmt.Printf("- %s: %s | version=%s | runtime=%s | gateway=%s | functions=%s\n", host.Host, host.Status, host.Version, host.Runtime, host.Gateway, strings.Join(host.Functions, ","))
		default:
			fmt.Printf("- %s: %s | %s\n", host.Host, host.Status, host.Error)
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func workspaceList(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw workspace-list [--json]")
	}
	list, path, err := workspace.List()
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"path": path, "workspaces": list})
	}
	if len(list) == 0 {
		fmt.Printf("workspaces=0 path=%s\n", path)
		return nil
	}
	fmt.Printf("%-18s %-10s %-32s %-12s %-14s %s\n", "ID", "HOST", "PATH", "OWNER", "BRANCH", "PURPOSE")
	for _, ws := range list {
		fmt.Printf("%-18s %-10s %-32s %-12s %-14s %s\n", ws.ID, ws.Host, truncate(ws.Path, 32), ws.Owner, ws.Branch, ws.Purpose)
	}
	return nil
}

func workspaceAdd(args []string) error {
	if len(args) < 3 || len(args) > 5 {
		return fmt.Errorf("usage: meshclaw workspace-add <id> <host> <path> [owner] [purpose]")
	}
	ws := workspace.Workspace{ID: args[0], Host: args[1], Path: args[2]}
	if len(args) >= 4 {
		ws.Owner = args[3]
	}
	if len(args) >= 5 {
		ws.Purpose = args[4]
	}
	saved, path, err := workspace.Upsert(ws)
	if err != nil {
		return err
	}
	return printJSON(map[string]interface{}{"path": path, "workspace": saved})
}

func workspaceActivity(args []string) error {
	if len(args) < 4 {
		return fmt.Errorf("usage: meshclaw workspace-activity <id> <actor> <action> <summary>")
	}
	activity := workspace.Activity{
		WorkspaceID: args[0],
		Actor:       args[1],
		Action:      args[2],
		Summary:     strings.Join(args[3:], " "),
	}
	record, err := workspace.RecordActivity(activity)
	if err != nil {
		return err
	}
	return printJSON(record)
}

func opsChat(args []string) error {
	if len(args) > 0 {
		return handleOpsChatMessage(strings.Join(args, " "))
	}
	fmt.Println("meshclaw ops-chat")
	fmt.Println("Try: workers, workspaces, fleet, evidence, policy, matrix, help, quit")
	scanner := bufio.NewScanner(os.Stdin)
	for {
		fmt.Print("you> ")
		if !scanner.Scan() {
			break
		}
		message := strings.TrimSpace(scanner.Text())
		if message == "" {
			continue
		}
		if message == "quit" || message == "exit" || message == "종료" {
			break
		}
		if err := handleOpsChatMessage(message); err != nil {
			fmt.Fprintf(os.Stderr, "meshclaw: %v\n", err)
		}
	}
	return scanner.Err()
}

func opsDispatch(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw ops-dispatch <matrix|openwebui|codex|claude> <message>")
	}
	result, err := dispatchOpsMessage(args[0], strings.Join(args[1:], " "))
	if err != nil {
		return err
	}
	return printJSON(result)
}

func dispatchRouteOnly(result map[string]interface{}, route string) bool {
	if os.Getenv("MESHCLAW_DISPATCH_ROUTE_ONLY") != "1" {
		return false
	}
	result["route"] = route
	result["result"] = map[string]interface{}{"mode": "route-only"}
	return true
}

func dispatchOpsMessage(source, message string) (map[string]interface{}, error) {
	source = strings.ToLower(strings.TrimSpace(source))
	if source == "" {
		source = "unknown"
	}
	lower := strings.ToLower(strings.TrimSpace(message))
	result := map[string]interface{}{
		"source":  source,
		"message": message,
	}
	switch {
	case isIntroMessage(lower):
		result["route"] = "intro"
		result["result"] = introResult()
	case containsAny(lower, "workers", "worker", "!workers", "작업자", "워커"):
		result["route"] = "workers"
		result["result"] = workers.DefaultWorkers()
	case containsAny(lower, "add current workspace", "현재 워크스페이스 등록", "현재 작업공간 등록"):
		ws, path, err := workspace.Upsert(workspace.Workspace{ID: "meshclaw-local", Host: "local", Path: "/Users/dragon/meshclaw", Owner: source, Purpose: "serverops", Source: source})
		if err != nil {
			return nil, err
		}
		result["route"] = "workspace_add"
		result["result"] = map[string]interface{}{"path": path, "workspace": ws}
	case containsAny(lower, "workspaces", "workspace", "!workspaces", "워크스페이스", "작업공간"):
		list, path, err := workspace.List()
		if err != nil {
			return nil, err
		}
		result["route"] = "workspace_list"
		result["result"] = map[string]interface{}{"path": path, "workspaces": list}
	case containsAny(lower, "ops-brief", "ops brief", "운영 브리핑", "운영 요약", "전체 요약", "뭐 해야", "무엇을 해야", "상태 요약"):
		brief, record, storeErr, err := buildOpsBrief()
		if err != nil {
			return nil, err
		}
		result["route"] = "ops_brief"
		result["result"] = map[string]interface{}{"report": brief, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "ops-control", "ops control", "서버 관리", "서버관리", "상태 관리", "상태관리", "관리해", "자동 관리", "자동관리", "조치 후보", "복구 후보"):
		if dispatchRouteOnly(result, "ops_control") {
			break
		}
		report, record, storeErr, err := buildOpsControl(false)
		if err != nil {
			return nil, err
		}
		result["route"] = "ops_control"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "vssh-auth-fix-plan", "vssh auth fix", "vssh 인증 복구", "vssh 시크릿", "vssh secret"):
		report, storeErr, err := buildVSSHAuthFixPlan(nil)
		if err != nil {
			return nil, err
		}
		report.StoreErr = errString(storeErr)
		result["route"] = "vssh_auth_fix_plan"
		result["result"] = report
	case containsAny(lower, "vssh-daemon-audit", "vssh daemon", "vsshd", "vssh 인증", "vssh 연결", "vssh 데몬"):
		report, storeErr, err := buildVSSHDaemonAudit(nil)
		if err != nil {
			return nil, err
		}
		report.StoreErr = errString(storeErr)
		result["route"] = "vssh_daemon_audit"
		result["result"] = report
	case containsAny(lower, "ai-guide", "canonical", "권장 경로", "어떤 도구", "도구 가이드"):
		result["route"] = "ai_guide"
		result["result"] = []aiGuideEntry{
			{Intent: "fleet health or status", Prefer: "meshclaw monitor-check or meshclaw ops-brief", Reason: "MeshClaw adds partial-result fallback, policy context, and evidence.", Examples: []string{"meshclaw ops-brief"}},
			{Intent: "run a diagnostic command", Prefer: "meshclaw run-evidence <host> <command>", Reason: "run-evidence keeps audit trail and fallback.", Examples: []string{"meshclaw run-evidence d1 'df -h'"}},
			{Intent: "service incident", Prefer: "meshclaw service-triage then meshclaw service-check", Reason: "triage removes stale service noise.", Examples: []string{"meshclaw service-triage"}},
		}
	case containsAny(lower, "node-inventory", "fleet-inventory", "software inventory", "설치", "깔려", "깔린", "인벤토리", "뭐뭐"):
		host := extractKnownNode(lower)
		if host == "" || containsAny(lower, "전체", "모든", "fleet", "서버들", "노드별") {
			report, record, storeErr := runFleetInventory(nil, 4)
			result["route"] = "fleet_inventory"
			result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
		} else {
			report := workflow.SoftwareInventory(host)
			record, storeErr := evidence.Store("node-inventory", host, report.Status, report)
			result["route"] = "node_inventory"
			result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
		}
	case containsAny(lower, "placement-plan", "workload", "배치", "어디서", "어디에", "어느 노드", "어디 노드", "돌려", "돌리면", "맡겨"):
		report, record, storeErr, err := buildPlacementPlan(message)
		if err != nil {
			return nil, err
		}
		result["route"] = "placement_plan"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "process-top", "process top", "top process", "프로세스", "상위 프로세스"):
		if dispatchRouteOnly(result, "process_top") {
			break
		}
		host := extractKnownNode(lower)
		if host == "" {
			host = firstNonCommandToken(lower)
		}
		report := workflow.ProcessTop(host)
		record, storeErr := evidence.Store("process-top", host, "top memory/cpu processes", report)
		result["route"] = "process_top"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "service-check", "service check", "서비스 체크", "서비스 확인"):
		if dispatchRouteOnly(result, "service_check") {
			break
		}
		host := extractKnownNode(lower)
		service := extractServiceName(lower, host)
		report := workflow.ServiceCheck(host, service)
		record, storeErr := evidence.Store("service-check", host, service, report)
		result["route"] = "service_check"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "service-triage", "service triage", "서비스 triage", "서비스 트리아지", "서비스 분류", "장애 분류"):
		if dispatchRouteOnly(result, "service_triage") {
			break
		}
		report, record, storeErr := buildServiceTriage(nil, 5, 4)
		result["route"] = "service_triage"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "service-audit", "service audit", "서비스 감사", "서비스 장애", "실패 서비스"):
		host := extractKnownNode(lower)
		if containsAny(lower, "전체", "모든", "all", "fleet") || host == "" {
			report, record, storeErr := runFleetServiceAudit(nil, 4)
			result["route"] = "fleet_service_audit"
			result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
		} else {
			report := workflow.ServiceAudit(host)
			record, storeErr := evidence.Store("service-audit", host, "failed/restarting services", report)
			result["route"] = "service_audit"
			result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
		}
	case containsAny(lower, "analyze-logs", "analyze logs", "로그 분석", "로그 확인"):
		if dispatchRouteOnly(result, "analyze_logs") {
			break
		}
		host := extractKnownNode(lower)
		sourceName := extractLogSource(lower, host)
		report := workflow.AnalyzeLogs(host, sourceName)
		record, storeErr := evidence.Store("analyze-logs", host, sourceName, report)
		result["route"] = "analyze_logs"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "security-check", "security check", "보안 점검", "보안 확인"):
		if dispatchRouteOnly(result, "security_check") {
			break
		}
		host := extractKnownNode(lower)
		report := workflow.SecurityCheck(host)
		record, storeErr := evidence.Store("security-check", host, "read-only snapshot", report)
		result["route"] = "security_check"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "hygiene-scan-host", "hygiene scan", "민감정보", "개인정보", "시크릿", "secret scan"):
		if dispatchRouteOnly(result, "hygiene_scan_host") {
			break
		}
		host := extractKnownNode(lower)
		report := hygiene.ScanHost(host)
		record, storeErr := evidence.Store("hygiene-scan-host", host, report.Status, report)
		result["route"] = "hygiene_scan_host"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "matrix-doctor", "matrix doctor", "매트릭스 진단", "matrix client", "클라이언트 로딩", "서버를 기다", "로딩이 안", "안돌아", "안 돌아"):
		if dispatchRouteOnly(result, "matrix_doctor") {
			break
		}
		result["route"] = "matrix_doctor"
		result["result"] = buildMatrixDoctorReport()
	case containsAny(lower, "openwebui", "open webui", "오픈웹유아이", "웹유아이"):
		report, err := openwebui.Scan(nil, 6)
		if err != nil {
			return nil, err
		}
		record, storeErr := evidence.Store("openwebui-scan", "fleet", fmt.Sprintf("installed=%d pipe=%d gateway=%d failures=%d", report.Installed, report.WithPipe, report.WithGateway, report.Failures), report)
		result["route"] = "openwebui_scan"
		result["result"] = map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}
	case containsAny(lower, "fleet", "monitor", "!fleet", "서버 상태", "상태", "모니터", "메모리", "디스크", "cpu", "gpu", "load") || mentionsKnownNode(lower):
		if dispatchRouteOnly(result, "monitor_check") {
			break
		}
		m, err := monitor.New(monitor.DefaultConfig())
		if err != nil {
			return nil, err
		}
		states := m.CheckAll()
		result["route"] = "monitor_check"
		result["result"] = monitorCheckOutput{States: states, Alerts: m.DetectAlerts()}
	case containsAny(lower, "evidence", "!evidence", "기록", "증거"):
		records, err := evidence.List(10)
		if err != nil {
			return nil, err
		}
		result["route"] = "evidence_list"
		result["result"] = records
	case containsAny(lower, "policy", "!policy", "권한", "정책"):
		cfg, path, err := policy.LoadConfig()
		if err != nil {
			return nil, err
		}
		result["route"] = "policy_summary"
		result["result"] = policySummary(path, cfg)
	case containsAny(lower, "matrix", "매트릭스"):
		if containsAny(lower, "doctor", "진단", "client", "클라이언트", "로딩", "서버를 기다", "안돌아", "안 돌아") {
			result["route"] = "matrix_doctor"
			result["result"] = buildMatrixDoctorReport()
			break
		}
		result["route"] = "matrix_plan"
		result["result"] = integrationDifference("matrix")
	default:
		result["route"] = "chat"
		result["result"] = relaxedChatResult(source, message)
	}
	return result, nil
}

func isIntroMessage(lower string) bool {
	lower = strings.TrimSpace(lower)
	switch lower {
	case "hi", "hello", "hey", "안녕", "안녕하세요", "넌 누구지?", "너 누구야?", "누구야?", "who are you?", "대화는 불가능한거야?", "대화 가능해?", "뭐 할 수 있어?", "사용법", "!help", "help", "도움말":
		return true
	default:
		return containsAny(lower, "대화 가능", "대화는 불가능", "뭐 할 수", "무엇을 할 수", "사용법", "도움말")
	}
}

func introResult() map[string]interface{} {
	return map[string]interface{}{
		"name":         "MeshClaw Matrix bridge",
		"role":         "ServerOps control-plane bridge. I can have short operations-focused dialogue in Matrix, but I am not the general assistant brain. Codex, Claude, ChatGPT, or local LLMs should do broad reasoning; I provide policy, workspace, evidence, monitoring, and vssh-backed operations.",
		"conversation": "You can talk casually in this Matrix room. I will answer lightly and route server/workspace/policy/evidence requests into MeshClaw tools.",
		"commands": []string{
			"!workers",
			"!workspaces",
			"!fleet",
			"!policy",
			"!evidence",
		},
	}
}

func relaxedChatResult(source, message string) map[string]interface{} {
	reply := "You can talk casually here. I am a MeshClaw server-ops bridge, not the general assistant brain. I can help with server status, workspaces, policy, evidence, and vssh-backed operations. 응, 편하게 말해도 돼."
	return map[string]interface{}{
		"reply":  reply,
		"source": source,
		"heard":  message,
		"try": []string{
			"show server status",
			"show workspaces",
			"show policy",
			"show recent evidence",
			"서버 상태 보여줘",
			"워크스페이스 보여줘",
			"정책 보여줘",
			"최근 기록 보여줘",
			"!workers",
		},
	}
}

func handleOpsChatMessage(message string) error {
	lower := strings.ToLower(strings.TrimSpace(message))
	fmt.Println("meshclaw>")
	switch {
	case containsAny(lower, "help", "도움", "?"):
		fmt.Println(`Available conversation checks:
- workers / 작업자: show model/operator workers
- workspaces / 워크스페이스: show server/folder ownership
- fleet / 서버 상태: run monitor-check
- evidence / 기록: show recent evidence
- policy / 권한: show current policy
- matrix / 매트릭스: show Matrix ops-room plan
- add current workspace / 현재 워크스페이스 등록: register /Users/dragon/meshclaw`)
		return nil
	case containsAny(lower, "workers", "worker", "작업자", "워커"):
		return workersList(nil)
	case containsAny(lower, "add current workspace", "현재 워크스페이스 등록", "현재 작업공간 등록"):
		return workspaceAdd([]string{"meshclaw-local", "local", "/Users/dragon/meshclaw", "human", "serverops"})
	case containsAny(lower, "workspaces", "workspace", "워크스페이스", "작업공간"):
		return workspaceList(nil)
	case containsAny(lower, "fleet", "monitor", "서버 상태", "상태", "모니터"):
		return monitorCheck(nil)
	case containsAny(lower, "evidence", "기록", "증거"):
		return evidenceList([]string{"10"})
	case containsAny(lower, "policy", "권한", "정책"):
		return opsPolicySummary()
	case containsAny(lower, "matrix", "매트릭스"):
		return matrixBridgePlan(nil)
	default:
		fmt.Println("I can route ops-room phrases to MeshClaw tools. Type help for examples.")
		return nil
	}
}

func opsPolicySummary() error {
	cfg, path, err := policy.LoadConfig()
	if err != nil {
		return err
	}
	summary := policySummary(path, cfg)
	fmt.Printf("policy path=%s rules=%d allow=%d require_approval=%d deny=%d\n", summary["path"], summary["rules"], summary["allow"], summary["require_approval"], summary["deny"])
	fmt.Println("Use `meshclaw policy-show` for the full policy JSON.")
	return nil
}

func policySummary(path string, cfg policy.Config) map[string]interface{} {
	allow, gate, deny := 0, 0, 0
	for _, rule := range cfg.Rules {
		switch rule.Decision {
		case policy.Allow:
			allow++
		case policy.RequireApproval:
			gate++
		case policy.Deny:
			deny++
		}
	}
	return map[string]interface{}{"path": path, "rules": len(cfg.Rules), "allow": allow, "require_approval": gate, "deny": deny}
}

func integrationDifference(name string) map[string]interface{} {
	switch name {
	case "openwebui":
		return map[string]interface{}{
			"role":        "Open WebUI is a local/private model chat frontend. It should call MeshClaw through MCP/tool bridge for server facts, workspace state, and evidence.",
			"best_for":    []string{"local model chat", "private log analysis", "single-user model experiments", "redacted summaries"},
			"not_for":     []string{"shared approvals", "team timeline", "persistent operations room"},
			"entrypoints": []string{"meshclaw mcp", "meshclaw ops-dispatch openwebui <message>", "meshclaw workspace_* tools"},
		}
	default:
		return map[string]interface{}{
			"role":        "Matrix is a shared operations room for humans, friends, Codex, Claude, local LLMs, approvals, notifications, screenshots, and evidence links.",
			"best_for":    []string{"shared timeline", "approval workflow", "multi-model handoff", "screenshots and evidence posting"},
			"not_for":     []string{"replacing Codex/Claude apps", "being the assistant brain"},
			"entrypoints": []string{"!workers", "!workspaces", "!fleet", "meshclaw ops-dispatch matrix <message>"},
		}
	}
}

func containsAny(value string, needles ...string) bool {
	for _, needle := range needles {
		if strings.Contains(value, strings.ToLower(needle)) {
			return true
		}
	}
	return false
}

func wantsJSON(args []string) bool {
	for _, arg := range args {
		if arg == "--json" || arg == "-json" {
			return true
		}
	}
	return false
}

func withoutJSONFlag(args []string) []string {
	filtered := make([]string, 0, len(args))
	for _, arg := range args {
		if arg == "--json" || arg == "-json" {
			continue
		}
		filtered = append(filtered, arg)
	}
	return filtered
}

func printJSON(value interface{}) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	fmt.Println(string(data))
	return nil
}

func parsePositiveInt(value, flag string) (int, error) {
	n, err := strconv.Atoi(strings.TrimSpace(value))
	if err != nil || n <= 0 {
		return 0, fmt.Errorf("%s requires a positive integer", flag)
	}
	return n, nil
}

func printEvidenceStoreStatus(record evidence.Record, err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", err)
		return
	}
	fmt.Printf("evidence=%s\n", record.StoredAt)
}

func provisionPlan(args []string) error {
	if len(args) < 1 || len(args) > 2 {
		return fmt.Errorf("usage: meshclaw provision-plan <purpose> [budget-usd]")
	}
	req := provision.Request{Purpose: args[0], TTLHours: 6, RequiredClass: "small-vps"}
	if len(args) == 2 {
		if _, err := fmt.Sscanf(args[1], "%f", &req.BudgetUSD); err != nil {
			return fmt.Errorf("invalid budget-usd: %s", args[1])
		}
	}
	plan := provision.NewPlan(req)
	record, storeErr := evidence.Store("provision-plan", "provider", req.Purpose, plan)
	if err := printJSON(map[string]interface{}{"plan": plan, "evidence": record, "store_error": errString(storeErr)}); err != nil {
		return err
	}
	return nil
}

func run(args []string) error {
	if len(args) >= 1 && isRuntimeWorkflow(args[0]) {
		return runWorkflow(args)
	}
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw run <workflow> [--dry-run|--execute] [--approvals latest|bundle|execution.json] [--step id[,id]] [--json] OR meshclaw run <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	out, err := runtime.NewRunner().Run(host, command)
	fmt.Print(out)
	return err
}

func workflows(args []string) error {
	jsonOut := wantsJSON(args)
	filtered := withoutJSONFlag(args)
	if len(filtered) > 0 {
		if len(filtered) == 2 && filtered[0] == "inspect" {
			inspection, err := runtimeflow.Inspect(filtered[1])
			if err != nil {
				return err
			}
			if jsonOut {
				return printJSON(inspection)
			}
			printWorkflowInspection(inspection)
			return nil
		}
		if len(filtered) == 2 && filtered[0] == "validate" {
			validation, err := runtimeflow.Validate(filtered[1])
			if err != nil {
				return err
			}
			if jsonOut {
				if err := printJSON(validation); err != nil {
					return err
				}
				if !validation.Valid {
					return fmt.Errorf("workflow validation failed")
				}
				return nil
			}
			printWorkflowValidation(validation)
			if !validation.Valid {
				return fmt.Errorf("workflow validation failed")
			}
			return nil
		}
		if len(filtered) >= 1 && filtered[0] == "resume" {
			ref := "latest"
			if len(filtered) == 2 {
				ref = filtered[1]
			} else if len(filtered) > 2 {
				return fmt.Errorf("usage: meshclaw workflows resume [latest|bundle|execution.json] [--json]")
			}
			plan, err := runtimeflow.Resume(ref)
			if err != nil {
				return err
			}
			if jsonOut {
				return printJSON(plan)
			}
			printWorkflowResume(plan)
			return nil
		}
		if len(filtered) >= 1 && filtered[0] == "plan-execute" {
			ref := "latest"
			if len(filtered) == 2 {
				ref = filtered[1]
			} else if len(filtered) > 2 {
				return fmt.Errorf("usage: meshclaw workflows plan-execute [latest|bundle|execution.json] [--json]")
			}
			plan, err := runtimeflow.PlanExecute(ref)
			if err != nil {
				return err
			}
			if jsonOut {
				return printJSON(plan)
			}
			printWorkflowExecutePlan(plan)
			return nil
		}
		if len(filtered) >= 2 && filtered[0] == "scaffold" {
			result, err := scaffoldWorkflow(filtered[1:], jsonOut)
			if err != nil {
				return err
			}
			if jsonOut {
				return printJSON(result)
			}
			fmt.Printf("workflow=%s\n", result.Workflow)
			fmt.Printf("path=%s\n", result.Path)
			fmt.Printf("valid=%t\n", result.Validation.Valid)
			for _, action := range result.NextActions {
				fmt.Println("- " + action)
			}
			return nil
		}
		return fmt.Errorf("usage: meshclaw workflows [--json] OR meshclaw workflows scaffold <name> [--output path] [--force] [--json] OR meshclaw workflows inspect <workflow> [--json] OR meshclaw workflows validate <workflow|file.json> [--json] OR meshclaw workflows resume [latest|bundle|execution.json] [--json] OR meshclaw workflows plan-execute [latest|bundle|execution.json] [--json]")
	}
	infos := runtimeflow.WorkflowInfos()
	if jsonOut {
		return printJSON(map[string]interface{}{
			"workflows":           infos,
			"default_workflow":    "fleet-health-demo",
			"advanced_workflow":   "meshclaw-ops-orchestration-demo",
			"mcp_entrypoint":      "meshclaw_workflow_run",
			"evidence_entrypoint": "meshclaw_evidence_latest",
			"guidance":            "Start with fleet-health-demo in dry-run mode. Use meshclaw-ops-orchestration-demo for the full private fleet/email/model orchestration demo. Execute only after approval-required actions are understood.",
			"guidance_ko":         "처음에는 fleet-health-demo dry-run으로 시작하세요. 전체 개인 플릿/메일/모델 오케스트레이션 데모는 meshclaw-ops-orchestration-demo를 사용하세요. execute는 승인 필요 액션을 확인한 뒤에만 사용합니다.",
		})
	}
	fmt.Println("Recommended start: meshclaw run fleet-health-demo --dry-run")
	fmt.Println("Advanced demo:      meshclaw run meshclaw-ops-orchestration-demo --dry-run")
	fmt.Println()
	fmt.Printf("%-32s %-5s %-18s %s\n", "NAME", "STEPS", "ADAPTERS", "APPROVAL ACTIONS")
	for _, info := range infos {
		fmt.Printf("%-32s %-5d %-18s %s\n", info.Name, info.StepCount, strings.Join(info.ExecutableAdapters, ","), strings.Join(info.ApprovalActions, ","))
		fmt.Printf("  %s\n", info.Description)
	}
	return nil
}

type workflowScaffoldResult struct {
	Kind        string                             `json:"kind"`
	Workflow    string                             `json:"workflow"`
	Path        string                             `json:"path"`
	Created     bool                               `json:"created"`
	Validation  runtimeflow.WorkflowValidation     `json:"validation"`
	NextActions []string                           `json:"next_actions"`
	Examples    []workflowScaffoldExampleReference `json:"examples"`
}

type workflowScaffoldExampleReference struct {
	Name    string `json:"name"`
	Command string `json:"command"`
}

func scaffoldWorkflow(args []string, jsonOut bool) (workflowScaffoldResult, error) {
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" || args[0] == "help" {
		return workflowScaffoldResult{}, fmt.Errorf("usage: meshclaw workflows scaffold <name> [--output path] [--force] [--json]")
	}
	name := sanitizeWorkflowName(args[0])
	if name == "" {
		return workflowScaffoldResult{}, fmt.Errorf("workflow name must contain at least one alphanumeric character")
	}
	output := ""
	force := false
	for i := 1; i < len(args); i++ {
		switch args[i] {
		case "--force":
			force = true
		case "--output":
			if i+1 >= len(args) {
				return workflowScaffoldResult{}, fmt.Errorf("--output requires a path")
			}
			output = args[i+1]
			i++
		default:
			return workflowScaffoldResult{}, fmt.Errorf("unknown scaffold argument: %s", args[i])
		}
	}
	if output == "" {
		home, err := os.UserHomeDir()
		if err != nil {
			return workflowScaffoldResult{}, err
		}
		output = filepath.Join(home, ".meshclaw", "workflows", name+".json")
	}
	output = filepath.Clean(output)
	if !force {
		if _, err := os.Stat(output); err == nil {
			return workflowScaffoldResult{}, fmt.Errorf("workflow already exists: %s (use --force to overwrite)", output)
		}
	}
	def := scaffoldWorkflowDefinition(name)
	data, err := json.MarshalIndent(def, "", "  ")
	if err != nil {
		return workflowScaffoldResult{}, err
	}
	if err := os.MkdirAll(filepath.Dir(output), 0700); err != nil {
		return workflowScaffoldResult{}, err
	}
	if err := os.WriteFile(output, append(data, '\n'), 0600); err != nil {
		return workflowScaffoldResult{}, err
	}
	validation, err := runtimeflow.Validate(output)
	if err != nil {
		return workflowScaffoldResult{}, err
	}
	result := workflowScaffoldResult{
		Kind:       "meshclaw_workflow_scaffold",
		Workflow:   name,
		Path:       output,
		Created:    true,
		Validation: validation,
		NextActions: []string{
			"Edit the scaffolded JSON and replace placeholder node names, commands, and approval gates.",
			"Run meshclaw workflows validate " + shellQuote(output) + " --json.",
			"Run meshclaw run " + shellQuote(output) + " --dry-run --json.",
			"Execute only after approval-required steps are understood and granted.",
		},
		Examples: []workflowScaffoldExampleReference{
			{Name: "fleet-health-demo", Command: "meshclaw workflows inspect fleet-health-demo --json"},
			{Name: "model-worker-orchestration", Command: "meshclaw workflows validate examples/workflows/model-worker-orchestration.json --json"},
		},
	}
	if jsonOut {
		result.NextActions = append(result.NextActions, "Use this JSON result as the handoff object for Codex, Claude, Cursor, or another MCP client.")
	}
	return result, nil
}

func scaffoldWorkflowDefinition(name string) runtimeflow.WorkflowDefinition {
	return runtimeflow.WorkflowDefinition{
		Name:        name,
		Description: "Generic MeshClaw Runtime workflow scaffold. Replace placeholders with your infrastructure-specific steps.",
		Steps: []runtimeflow.StepSpec{
			{
				ID:         "plan",
				Title:      "Define operator intent and success criteria",
				Transport:  "manual",
				Action:     "read_state",
				Resource:   "workflow",
				DryRunNote: "State the target, success criteria, risks, and rollback expectations before execution.",
			},
			{
				ID:         "preflight",
				Title:      "Collect local runtime preflight",
				Node:       "controller",
				Transport:  "local",
				Command:    "meshclaw doctor --json",
				Action:     "read_state",
				Resource:   "runtime",
				DependsOn:  []string{"plan"},
				DryRunNote: "Would verify MeshClaw, vssh, inventory, policy, evidence, and workflow setup.",
			},
			{
				ID:         "inspect-target",
				Title:      "Inspect target node without mutation",
				Node:       "replace-with-node",
				Transport:  "vssh",
				Command:    "hostname; uptime; df -h",
				Action:     "read_state",
				Resource:   "server",
				DependsOn:  []string{"preflight"},
				DryRunNote: "Would collect read-only target state through vssh-backed structured execution.",
			},
			{
				ID:               "approval-gate",
				Title:            "Require approval before any mutating operation",
				Transport:        "policy",
				Action:           "restart_service",
				Resource:         "service",
				DependsOn:        []string{"inspect-target"},
				ApprovalRequired: true,
				DryRunNote:       "Replace action/resource with the real mutating operation and keep approval evidence.",
			},
			{
				ID:               "apply-approved-change",
				Title:            "Apply the approved change",
				Node:             "replace-with-node",
				Transport:        "vssh",
				Command:          "systemctl status replace-with-service --no-pager",
				Action:           "restart_service",
				Resource:         "service",
				DependsOn:        []string{"approval-gate"},
				ApprovalRequired: true,
				Retry: runtimeflow.RetrySpec{
					MaxAttempts:        2,
					DelaySeconds:       2,
					RetryOnErrorSubstr: []string{"timeout", "connection reset"},
				},
				DryRunNote: "Replace with the approved command. MeshClaw records attempts, output, policy, and evidence.",
			},
			{
				ID:         "verify",
				Title:      "Verify result and capture evidence",
				Node:       "replace-with-node",
				Transport:  "vssh",
				Command:    "systemctl is-active replace-with-service; journalctl -u replace-with-service -n 30 --no-pager",
				Action:     "read_state",
				Resource:   "service",
				DependsOn:  []string{"apply-approved-change"},
				DryRunNote: "Would verify post-change service state and logs.",
			},
		},
	}
}

func sanitizeWorkflowName(raw string) string {
	raw = strings.ToLower(strings.TrimSpace(raw))
	var b strings.Builder
	lastDash := false
	for _, r := range raw {
		ok := (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9')
		if ok {
			b.WriteRune(r)
			lastDash = false
			continue
		}
		if !lastDash {
			b.WriteByte('-')
			lastDash = true
		}
	}
	return strings.Trim(b.String(), "-")
}

func approvals(args []string) error {
	jsonOut := wantsJSON(args)
	filtered := withoutJSONFlag(args)
	if len(filtered) == 0 {
		return fmt.Errorf("usage: meshclaw approvals <list|grant>")
	}
	switch filtered[0] {
	case "list":
		ref := "latest"
		if len(filtered) == 2 {
			ref = filtered[1]
		} else if len(filtered) > 2 {
			return fmt.Errorf("usage: meshclaw approvals list [latest|bundle|execution.json] [--json]")
		}
		records, err := runtimeflow.ListApprovals(ref)
		if err != nil {
			return err
		}
		if jsonOut {
			return printJSON(map[string]interface{}{"approvals": records})
		}
		fmt.Printf("approvals=%d\n", len(records))
		for _, record := range records {
			fmt.Printf("- %s actor=%s workflow=%s step=%s action=%s resource=%s\n", record.Time.Format(time.RFC3339), record.Actor, record.Workflow, record.Step, record.Action, record.Resource)
			if record.Reason != "" {
				fmt.Printf("  reason: %s\n", record.Reason)
			}
		}
		return nil
	case "grant":
		req, err := parseApprovalGrant(filtered[1:])
		if err != nil {
			return err
		}
		record, err := runtimeflow.GrantApproval(req.ref, req.step, req.actor, req.reason, req.source)
		if err != nil {
			return err
		}
		if jsonOut {
			return printJSON(record)
		}
		fmt.Printf("approval_granted workflow=%s step=%s actor=%s action=%s resource=%s\n", record.Workflow, record.Step, record.Actor, record.Action, record.Resource)
		fmt.Printf("bundle=%s\n", record.Bundle)
		return nil
	default:
		return fmt.Errorf("usage: meshclaw approvals <list|grant>")
	}
}

type approvalGrantRequest struct {
	ref    string
	step   string
	actor  string
	reason string
	source string
}

func parseApprovalGrant(args []string) (approvalGrantRequest, error) {
	if len(args) < 2 {
		return approvalGrantRequest{}, fmt.Errorf("usage: meshclaw approvals grant <latest|bundle|execution.json> <step> --actor <actor> [--reason text] [--source cli] [--json]")
	}
	req := approvalGrantRequest{ref: args[0], step: args[1], source: "cli"}
	for i := 2; i < len(args); i++ {
		switch args[i] {
		case "--actor":
			i++
			if i >= len(args) {
				return req, fmt.Errorf("--actor requires a value")
			}
			req.actor = args[i]
		case "--reason":
			i++
			if i >= len(args) {
				return req, fmt.Errorf("--reason requires a value")
			}
			req.reason = args[i]
		case "--source":
			i++
			if i >= len(args) {
				return req, fmt.Errorf("--source requires a value")
			}
			req.source = args[i]
		default:
			return req, fmt.Errorf("unknown approvals grant option: %s", args[i])
		}
	}
	if req.actor == "" {
		return req, fmt.Errorf("--actor is required")
	}
	return req, nil
}

func printWorkflowResume(plan runtimeflow.ResumePlan) {
	fmt.Printf("resume workflow=%s previous_mode=%s previous_success=%t\n", plan.Workflow, plan.PreviousMode, plan.PreviousSuccess)
	fmt.Printf("bundle=%s\n", plan.BundleDir)
	fmt.Printf("resume_plan=%s\n", plan.ResumePath)
	fmt.Printf("approvals=%s count=%d\n", plan.ApprovalsPath, len(plan.Approvals))
	fmt.Printf("items=%d\n", len(plan.Items))
	for _, item := range plan.Items {
		fmt.Printf("%02d. %s status=%s node=%s transport=%s approval=%t retryable=%t\n", item.Index, item.Step, item.Status, item.Node, item.Transport, item.ApprovalRequired, item.Retryable)
		if item.Reason != "" {
			fmt.Printf("    reason: %s\n", truncate(item.Reason, 180))
		}
		if item.NextAction != "" {
			fmt.Printf("    next: %s\n", item.NextAction)
		}
		if item.ApprovalCLI != "" {
			fmt.Printf("    approve: %s\n", item.ApprovalCLI)
		}
		if item.ExecuteCLI != "" {
			fmt.Printf("    execute: %s\n", item.ExecuteCLI)
		}
	}
	if len(plan.Next) > 0 {
		fmt.Println("next_actions:")
		for _, action := range plan.Next {
			fmt.Println("- " + action)
		}
	}
}

func printWorkflowExecutePlan(plan runtimeflow.ExecutePlan) {
	fmt.Printf("execute_plan workflow=%s ready=%t decision=%s\n", plan.Workflow, plan.Ready, plan.Decision)
	fmt.Printf("bundle=%s\n", plan.BundleDir)
	if plan.Reason != "" {
		fmt.Printf("reason=%s\n", plan.Reason)
	}
	fmt.Printf("counts ready=%d approval_pending=%d vault_missing=%d retryable_failed=%d failed=%d repair_needed=%d\n",
		plan.Counts.Ready, plan.Counts.ApprovalPending, plan.Counts.VaultMissing, plan.Counts.RetryableFailed, plan.Counts.Failed, plan.Counts.RepairNeeded)
	fmt.Printf("capability_registry valid=%t count=%d errors=%d warnings=%d path=%s\n",
		plan.CapabilityRegistry.Valid, plan.CapabilityRegistry.Count, len(plan.CapabilityRegistry.Errors), len(plan.CapabilityRegistry.Warnings), plan.CapabilityRegistry.Path)
	if plan.ExecuteCLI != "" {
		fmt.Printf("execute=%s\n", plan.ExecuteCLI)
	}
	if len(plan.Next) > 0 {
		fmt.Println("next_actions:")
		for _, action := range plan.Next {
			fmt.Println("- " + action)
		}
	}
}

func printWorkflowValidation(validation runtimeflow.WorkflowValidation) {
	status := "ok"
	if !validation.Valid {
		status = "failed"
	}
	fmt.Printf("validation=%s workflow=%s steps=%d\n", status, validation.Workflow, validation.StepCount)
	if validation.Source != "" {
		fmt.Printf("source=%s\n", validation.Source)
	}
	if len(validation.Errors) > 0 {
		fmt.Println("errors:")
		for _, issue := range validation.Errors {
			fmt.Printf("- step=%s field=%s message=%s\n", issue.Step, issue.Field, issue.Message)
		}
	}
	if len(validation.Warnings) > 0 {
		fmt.Println("warnings:")
		for _, issue := range validation.Warnings {
			fmt.Printf("- step=%s field=%s message=%s\n", issue.Step, issue.Field, issue.Message)
		}
	}
	if len(validation.NextActions) > 0 {
		fmt.Println("next_actions:")
		for _, action := range validation.NextActions {
			fmt.Println("- " + action)
		}
	}
}

func printWorkflowInspection(inspection runtimeflow.WorkflowInspection) {
	fmt.Printf("workflow=%s steps=%d recommended=%s\n", inspection.Info.Name, inspection.Info.StepCount, inspection.Info.RecommendedMode)
	fmt.Printf("description=%s\n", inspection.Info.Description)
	fmt.Printf("adapters=%s\n", strings.Join(inspection.RequiredAdapters, ","))
	fmt.Printf("nodes=%s\n", strings.Join(inspection.RequiredNodes, ","))
	fmt.Printf("capabilities=%d\n", len(inspection.CapabilitySnapshot))
	if len(inspection.CapabilityHints) > 0 {
		fmt.Println("capability_hints:")
		keys := make([]string, 0, len(inspection.CapabilityHints))
		for step := range inspection.CapabilityHints {
			keys = append(keys, step)
		}
		sort.Strings(keys)
		for _, step := range keys {
			fmt.Printf("- %s: %s\n", step, strings.Join(inspection.CapabilityHints[step], ","))
		}
	}
	if len(inspection.ApprovalGates) > 0 {
		fmt.Println("approval_gates:")
		for _, gate := range inspection.ApprovalGates {
			strong := ""
			if gate.Strong {
				strong = " strong=true"
			}
			fmt.Printf("- %s action=%s resource=%s%s\n  reason: %s\n", gate.Step, gate.Action, gate.Resource, strong, gate.Reason)
		}
	}
	fmt.Println("steps:")
	for _, step := range inspection.Steps {
		exec := "no"
		if step.WillExecuteInExecute {
			exec = "yes"
		}
		fmt.Printf("%02d. %s transport=%s node=%s execute=%s policy=%s\n", step.Index, step.Step.ID, step.Step.Transport, step.Step.Node, exec, step.Policy.Decision)
		if step.Step.Command != "" {
			fmt.Printf("    command: %s\n", truncate(step.Step.Command, 160))
		}
	}
}

func isRuntimeWorkflow(name string) bool {
	return runtimeflow.IsKnown(name)
}

func runWorkflow(args []string) error {
	name := args[0]
	mode := runtimeflow.DryRun
	jsonOut := false
	approvalsRef := ""
	selectedSteps := []string{}
	for i := 1; i < len(args); i++ {
		switch args[i] {
		case "--dry-run":
			mode = runtimeflow.DryRun
		case "--execute":
			mode = runtimeflow.Execute
		case "--json":
			jsonOut = true
		case "--approvals":
			i++
			if i >= len(args) {
				return fmt.Errorf("--approvals requires latest, a bundle directory, or execution.json")
			}
			approvalsRef = args[i]
		case "--step":
			i++
			if i >= len(args) {
				return fmt.Errorf("--step requires a workflow step id")
			}
			selectedSteps = append(selectedSteps, args[i])
		default:
			return fmt.Errorf("usage: meshclaw run <workflow> [--dry-run|--execute] [--approvals latest|bundle|execution.json] [--step id[,id]] [--json]")
		}
	}
	result, err := runtimeflow.RunSelectedWithApprovals(name, mode, approvalsRef, selectedSteps)
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(result)
	}
	fmt.Printf("workflow=%s mode=%s success=%t\n", result.Workflow, result.Mode, result.Success)
	fmt.Printf("bundle=%s\n", result.BundleDir)
	fmt.Printf("plan=%s\n", result.PlanPath)
	fmt.Printf("execution=%s\n", result.ExecutionPath)
	fmt.Printf("steps=%s\n", result.StepsPath)
	fmt.Printf("capabilities=%s\n", result.CapabilitiesPath)
	fmt.Printf("adapters=%s\n", result.AdaptersPath)
	fmt.Printf("approvals=%s\n", result.ApprovalsPath)
	fmt.Printf("report=%s\n", result.ReportPath)
	fmt.Printf("summary total=%d skipped=%d approval_required=%d failed=%d retryable=%d\n",
		result.Summary.Total, result.Summary.Skipped, result.Summary.ApprovalRequired, result.Summary.Failed, result.Summary.Retryable)
	for _, step := range result.Steps {
		status := "ok"
		if !step.Success {
			status = "failed"
		} else if step.Skipped {
			status = "skipped"
		}
		fmt.Printf("- %s status=%s approval=%t node=%s\n", step.Step, status, step.ApprovalRequired, step.Node)
		if step.SkipReason != "" {
			fmt.Printf("  reason: %s\n", step.SkipReason)
		}
	}
	return nil
}

func runEvidence(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw run-evidence <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	result := runtime.NewRunner().RunEvidence(host, command)
	record, storeErr := evidence.Store("run-evidence", host, command, result)
	data, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return err
	}
	fmt.Println(string(data))
	if storeErr != nil {
		fmt.Fprintf(os.Stderr, "evidence_store_error=%v\n", storeErr)
	} else {
		fmt.Printf("evidence=%s\n", record.StoredAt)
	}
	if !result.Success {
		return fmt.Errorf("execution failed on %s", host)
	}
	return nil
}

func jobStart(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw job-start <host> <command>")
	}
	host := args[0]
	command := strings.Join(args[1:], " ")
	if _, ok := inventory.Find(host); !ok {
		return fmt.Errorf("unknown node: %s", host)
	}
	if err := policy.CheckCommand(command); err != nil {
		return err
	}
	result, err := runtime.NewRunner().VSSHJSON("job-start", host, command)
	record, storeErr := evidence.Store("job-start", host, command, result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func jobStatus(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw job-status <host> <id>")
	}
	return jobRead(args[0], args[1], "job-status")
}

func jobLogs(args []string) error {
	if len(args) < 2 || len(args) > 3 {
		return fmt.Errorf("usage: meshclaw job-logs <host> <id> [tail-bytes]")
	}
	params := []string{"job-logs", args[0], args[1]}
	if len(args) == 3 {
		params = append(params, args[2])
	}
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "job_logs", Resource: "server", Context: args[1]})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	result, err := runtime.NewRunner().VSSHJSON(params...)
	record, storeErr := evidence.Store("job-logs", args[0], args[1], result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func jobCancel(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw job-cancel <host> <id>")
	}
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "job_cancel", Resource: "server", Context: args[1]})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	result, err := runtime.NewRunner().VSSHJSON("job-cancel", args[0], args[1])
	record, storeErr := evidence.Store("job-cancel", args[0], args[1], result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func jobRead(host, id, command string) error {
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "job_status", Resource: "server", Context: id})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	result, err := runtime.NewRunner().VSSHJSON(command, host, id)
	record, storeErr := evidence.Store(command, host, id, result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func artifactCollect(args []string) error {
	if len(args) < 2 || len(args) > 3 {
		return fmt.Errorf("usage: meshclaw artifact-collect <host> <path> [max-bytes]")
	}
	host, path := args[0], args[1]
	decision := policy.Evaluate(policy.Request{Subject: "operator", Action: "artifact_collect", Resource: "server", Context: path})
	if decision.Decision != policy.Allow {
		return fmt.Errorf("policy blocked: %s", decision.Reason)
	}
	params := []string{"artifact-collect", host, path}
	if len(args) == 3 {
		params = append(params, args[2])
	}
	result, err := runtime.NewRunner().VSSHJSON(params...)
	record, storeErr := evidence.Store("artifact-collect", host, path, result)
	return printResultWithEvidence(result, record, storeErr, err)
}

func printResultWithEvidence(result interface{}, record evidence.Record, storeErr error, err error) error {
	if printErr := printJSON(map[string]interface{}{"result": result, "evidence": record, "store_error": errString(storeErr)}); printErr != nil {
		return printErr
	}
	return err
}

func runDoctor(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) == 0 {
		report := doctor.Self()
		if jsonOut {
			return printJSON(report)
		}
		fmt.Print(doctor.FormatSelf(report))
		if report.Status == "fail" {
			return fmt.Errorf("doctor failed")
		}
		return nil
	}
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw doctor [host] [--json]")
	}
	fmt.Print(doctor.Check(args[0]))
	return nil
}

func runSetupCheck(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 0 {
		return fmt.Errorf("usage: meshclaw setup-check [--json]")
	}
	report := doctor.Self()
	if jsonOut {
		return printJSON(report)
	}
	fmt.Print(doctor.FormatSelf(report))
	if report.Status == "fail" {
		return fmt.Errorf("setup check failed")
	}
	return nil
}

func analyzeLogs(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw analyze-logs <host> <source>")
	}
	report := workflow.AnalyzeLogs(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("analyze-logs", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceCheck(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw service-check <host> <service>")
	}
	report := workflow.ServiceCheck(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("service-check", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceAudit(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw service-audit <host> [--json]")
	}
	report := workflow.ServiceAudit(args[0])
	record, storeErr := evidence.Store("service-audit", args[0], "failed/restarting services", report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	printReport(report)
	printEvidenceStoreStatus(record, storeErr)
	if report.Status == "failed" || report.Status == "unknown_node" {
		return fmt.Errorf("service-audit failed on %s", args[0])
	}
	return nil
}

func serviceQuarantine(args []string) error {
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw service-quarantine <host> <service>")
	}
	report := workflow.ServiceQuarantine(args[0], args[1])
	printReport(report)
	record, storeErr := evidence.Store("service-quarantine", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func serviceRemove(args []string) error {
	if len(args) < 2 || len(args) > 3 {
		return fmt.Errorf("usage: meshclaw service-remove <host> <service> [working-directory]")
	}
	path := ""
	if len(args) == 3 {
		path = args[2]
	}
	report := workflow.ServiceRemove(args[0], args[1], path)
	printReport(report)
	record, storeErr := evidence.Store("service-remove", args[0], args[1], report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func securityCheck(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw security-check <host>")
	}
	report := workflow.SecurityCheck(args[0])
	printReport(report)
	record, storeErr := evidence.Store("security-check", args[0], "read-only snapshot", report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func hygienePlan(args []string) error {
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw hygiene-plan <host>")
	}
	printHygieneReport(hygiene.Plan(args[0]))
	return nil
}

func guardModes(args []string) error {
	jsonOut := wantsJSON(args)
	if jsonOut {
		return printJSON(map[string]interface{}{"modes": guard.Modes()})
	}
	for _, mode := range guard.Modes() {
		fmt.Printf("%s: %s\n", mode.Mode, mode.Purpose)
		for _, item := range mode.WhatItDoes {
			fmt.Printf("- %s\n", item)
		}
	}
	return nil
}

func guardModel(args []string) error {
	jsonOut := wantsJSON(args)
	plan := guard.LocalModel()
	if jsonOut {
		return printJSON(map[string]interface{}{"local_model": plan})
	}
	fmt.Printf("%s\n%s\n\n", plan.Name, plan.Purpose)
	fmt.Printf("recommended_size: %s\n", plan.RecommendedSize)
	fmt.Println("required_settings:")
	for _, item := range plan.RequiredSettings {
		fmt.Printf("- %s\n", item)
	}
	fmt.Println("model_may_do:")
	for _, item := range plan.ModelMayDo {
		fmt.Printf("- %s\n", item)
	}
	fmt.Println("model_must_not_do:")
	for _, item := range plan.ModelMustNotDo {
		fmt.Printf("- %s\n", item)
	}
	fmt.Println("guard_authority:")
	for _, item := range plan.GuardAuthority {
		fmt.Printf("- %s\n", item)
	}
	fmt.Printf("startup_prompt:\n%s\n", plan.StartupPrompt)
	return nil
}

func guardClients(args []string) error {
	jsonOut := wantsJSON(args)
	guides := guard.ClientGuides()
	if jsonOut {
		return printJSON(map[string]interface{}{"clients": guides})
	}
	for _, guide := range guides {
		fmt.Printf("%s (%s) risk=%s\n", guide.Name, guide.ID, guide.Risk)
		fmt.Printf("verdict: %s\n", guide.Verdict)
		fmt.Printf("use: %s\n", guide.RecommendedUse)
		if len(guide.RequiredSettings) > 0 {
			fmt.Println("required_settings:")
			for _, item := range guide.RequiredSettings {
				fmt.Printf("- %s\n", item)
			}
		}
		if len(guide.LocalStores) > 0 {
			fmt.Println("local_stores:")
			for _, item := range guide.LocalStores {
				fmt.Printf("- %s\n", item)
			}
		}
		fmt.Println()
	}
	return nil
}

func guardVault(args []string) error {
	jsonOut := wantsJSON(args)
	plan := guard.VaultConversationPlan()
	if jsonOut {
		return printJSON(map[string]interface{}{"vault": plan})
	}
	fmt.Printf("vault_conversation local_only=%t handle_scheme=%s\n%s\n\n", plan.LocalOnly, plan.HandleScheme, plan.Purpose)
	fmt.Printf("conversation_ui: %s\n", plan.ConversationUI)
	fmt.Println("operations:")
	for _, op := range plan.Operations {
		fmt.Printf("- %s mode=%s approval_required=%t\n  next: %s\n", op.ID, op.Mode, op.Approval, op.Next)
	}
	fmt.Println("model_rules:")
	for _, item := range plan.ModelRules {
		fmt.Printf("- %s\n", item)
	}
	fmt.Println("storage_rules:")
	for _, item := range plan.StorageRules {
		fmt.Printf("- %s\n", item)
	}
	return nil
}

func guardVaultBackends(args []string) error {
	jsonOut := wantsJSON(args)
	backends := guardvault.Backends()
	if jsonOut {
		return printJSON(map[string]interface{}{"backends": backends})
	}
	for _, backend := range backends {
		fmt.Printf("%s available=%t read_write=%t status=%s", backend.ID, backend.Available, backend.ReadWrite, backend.Status)
		if backend.Executable != "" {
			fmt.Printf(" executable=%s", backend.Executable)
		}
		if backend.Reason != "" {
			fmt.Printf(" reason=%s", backend.Reason)
		}
		fmt.Println()
	}
	return nil
}

func guardVaultInit(args []string) error {
	jsonOut := wantsJSON(args)
	root, err := guardvault.Init()
	if err != nil {
		return err
	}
	result := map[string]interface{}{
		"root":          root,
		"handle_scheme": "vault://meshclaw/<scope>/<name>",
		"raw_reveal":    false,
		"policy":        "local-only; MCP exposes metadata and handles only",
	}
	if jsonOut {
		return printJSON(result)
	}
	fmt.Printf("guard vault initialized: %s\n", root)
	fmt.Println("raw_reveal=false")
	return nil
}

func guardVaultPut(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw guard-vault-put <scope> <name> [kind] [description] [--backend local|keychain|pass] < secret.txt [--json]")
	}
	backend := ""
	clean := make([]string, 0, len(args))
	for i := 0; i < len(args); i++ {
		if args[i] == "--backend" {
			i++
			if i >= len(args) {
				return fmt.Errorf("--backend requires a value")
			}
			backend = args[i]
			continue
		}
		clean = append(clean, args[i])
	}
	args = clean
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw guard-vault-put <scope> <name> [kind] [description] [--backend local|keychain|pass] < secret.txt [--json]")
	}
	value, err := io.ReadAll(os.Stdin)
	if err != nil {
		return err
	}
	kind := ""
	description := ""
	if len(args) >= 3 {
		kind = args[2]
	}
	if len(args) >= 4 {
		description = strings.Join(args[3:], " ")
	}
	entry, err := guardvault.Put(guardvault.PutOptions{
		Scope:       args[0],
		Name:        args[1],
		Kind:        kind,
		Description: description,
		Backend:     backend,
		Value:       value,
	})
	if err != nil {
		return err
	}
	record, storeErr := evidence.Store("guard-vault-put", entry.Scope, "stored "+entry.Handle, entry)
	if jsonOut {
		return printJSON(map[string]interface{}{"entry": entry, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("stored %s fingerprint=%s\n", entry.Handle, entry.Fingerprint)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func guardVaultList(args []string) error {
	jsonOut := wantsJSON(args)
	entries, err := guardvault.List()
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"entries": entries})
	}
	for _, entry := range entries {
		fmt.Printf("%s kind=%s fingerprint=%s updated=%s\n", entry.Handle, entry.Kind, entry.Fingerprint, entry.UpdatedAt.Format(time.RFC3339))
	}
	return nil
}

func guardVaultMetadata(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	var (
		entry guardvault.Entry
		err   error
	)
	switch len(args) {
	case 1:
		entry, err = guardvault.MetadataByHandle(args[0])
	case 2:
		entry, err = guardvault.Metadata(args[0], args[1])
	default:
		return fmt.Errorf("usage: meshclaw guard-vault-metadata <vault://meshclaw/scope/name|scope name> [--json]")
	}
	if err != nil {
		return err
	}
	if jsonOut {
		return printJSON(map[string]interface{}{"entry": entry})
	}
	fmt.Printf("%s kind=%s fingerprint=%s raw_available=%t policy=%s\n", entry.Handle, entry.Kind, entry.Fingerprint, entry.RawAvailable, entry.Policy)
	return nil
}

func guardVaultDelete(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 2 {
		return fmt.Errorf("usage: meshclaw guard-vault-delete <scope> <name> [--json]")
	}
	entry, err := guardvault.Delete(args[0], args[1])
	if err != nil {
		return err
	}
	record, storeErr := evidence.Store("guard-vault-delete", entry.Scope, "deleted "+entry.Handle, entry)
	if jsonOut {
		return printJSON(map[string]interface{}{"deleted": entry, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("deleted %s\n", entry.Handle)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func guardVaultUse(args []string) error {
	req, err := parseGuardVaultUse(args)
	if err != nil {
		return err
	}
	policyResult := policy.Evaluate(policy.Request{Subject: "local-guard", Action: "guard_vault_use", Resource: "secret", Context: req.handle})
	if !req.approved {
		plan := map[string]interface{}{
			"approval_required": true,
			"policy":            policyResult,
			"handle":            req.handle,
			"env_name":          req.envName,
			"command":           req.command,
			"next":              "Rerun with --approve --actor <name> --reason <reason> before the -- command separator.",
		}
		if req.jsonOut {
			return printJSON(plan)
		}
		return fmt.Errorf("approval required: rerun with --approve --actor <name> --reason <reason>")
	}
	result, err := guardvault.UseEnv(req.handle, req.envName, req.command)
	if err != nil {
		return err
	}
	approval := map[string]interface{}{
		"approved": true,
		"actor":    req.actor,
		"source":   req.source,
		"reason":   req.reason,
		"policy":   policyResult,
	}
	payload := map[string]interface{}{"result": result, "approval": approval}
	record, storeErr := evidence.Store("guard-vault-use", result.Handle, fmt.Sprintf("exit=%d approved_by=%s", result.ExitCode, req.actor), payload)
	if req.jsonOut {
		return printJSON(map[string]interface{}{"result": result, "approval": approval, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("guard vault use handle=%s env=%s exit=%d duration_ms=%d approved_by=%s\n", result.Handle, result.EnvName, result.ExitCode, result.DurationMs, req.actor)
	if strings.TrimSpace(result.Stdout) != "" {
		fmt.Println("stdout:")
		fmt.Print(result.Stdout)
		if !strings.HasSuffix(result.Stdout, "\n") {
			fmt.Println()
		}
	}
	if strings.TrimSpace(result.Stderr) != "" {
		fmt.Println("stderr:")
		fmt.Print(result.Stderr)
		if !strings.HasSuffix(result.Stderr, "\n") {
			fmt.Println()
		}
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

type guardVaultUseRequest struct {
	handle   string
	envName  string
	approved bool
	actor    string
	reason   string
	source   string
	jsonOut  bool
	command  []string
}

func parseGuardVaultUse(args []string) (guardVaultUseRequest, error) {
	sep := -1
	for i, arg := range args {
		if arg == "--" {
			sep = i
			break
		}
	}
	if sep < 0 || sep+1 >= len(args) {
		return guardVaultUseRequest{}, fmt.Errorf("usage: meshclaw guard-vault-use <handle> <ENV_NAME> --approve [--actor name] [--reason text] [--json] -- <command> [args...]")
	}
	pre := args[:sep]
	if len(pre) < 2 {
		return guardVaultUseRequest{}, fmt.Errorf("usage: meshclaw guard-vault-use <handle> <ENV_NAME> --approve [--actor name] [--reason text] [--json] -- <command> [args...]")
	}
	req := guardVaultUseRequest{
		handle:  pre[0],
		envName: pre[1],
		actor:   "local-operator",
		source:  "cli",
		command: args[sep+1:],
	}
	for i := 2; i < len(pre); i++ {
		switch pre[i] {
		case "--approve":
			req.approved = true
		case "--json":
			req.jsonOut = true
		case "--actor":
			i++
			if i >= len(pre) || strings.TrimSpace(pre[i]) == "" {
				return guardVaultUseRequest{}, fmt.Errorf("--actor requires a value")
			}
			req.actor = pre[i]
		case "--reason":
			i++
			if i >= len(pre) || strings.TrimSpace(pre[i]) == "" {
				return guardVaultUseRequest{}, fmt.Errorf("--reason requires a value")
			}
			req.reason = pre[i]
		case "--source":
			i++
			if i >= len(pre) || strings.TrimSpace(pre[i]) == "" {
				return guardVaultUseRequest{}, fmt.Errorf("--source requires a value")
			}
			req.source = pre[i]
		default:
			return guardVaultUseRequest{}, fmt.Errorf("unknown guard-vault-use option before --: %s", pre[i])
		}
	}
	if req.reason == "" && req.approved {
		req.reason = "local explicit approval"
	}
	return req, nil
}

func guardDetect(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw guard-detect <target> <text> [--json]")
	}
	report := guard.Detect(args[0], strings.Join(args[1:], " "))
	record, storeErr := evidence.Store("guard-detect", args[0], report.Status, report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	printGuardReport(report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func guardRedact(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw guard-redact <target> <text> [--json]")
	}
	report := guard.Redact(args[0], strings.Join(args[1:], " "))
	record, storeErr := evidence.Store("guard-redact", args[0], report.Status, report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	printGuardReport(report)
	if strings.TrimSpace(report.Redacted) != "" {
		fmt.Println("redacted:")
		fmt.Println(report.Redacted)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func guardPosture(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) > 1 {
		return fmt.Errorf("usage: meshclaw guard-posture [home] [--json]")
	}
	home := ""
	if len(args) == 1 {
		home = args[0]
	}
	report := guard.Posture(home)
	record, storeErr := evidence.Store("guard-posture", "local", report.Status, report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("guard posture target=%s status=%s\n", report.Target, report.Status)
	for _, check := range report.Checks {
		fmt.Printf("- [%s] %s status=%s evidence=%s\n  next: %s\n", check.Severity, check.ID, check.Status, check.Evidence, check.Next)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func guardVuln(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw guard-vuln <path> [--json]")
	}
	report := guard.VulnScanPath(args[0])
	record, storeErr := evidence.Store("guard-vuln", args[0], report.Status, report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	printGuardReport(report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func guardCleanPlan(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) > 1 {
		return fmt.Errorf("usage: meshclaw guard-clean-plan [home] [--json]")
	}
	home := ""
	if len(args) == 1 {
		home = args[0]
	}
	plan := guard.Cleanup(home)
	record, storeErr := evidence.Store("guard-clean-plan", "local", plan.Status, plan)
	if jsonOut {
		return printJSON(map[string]interface{}{"plan": plan, "evidence": record, "store_error": errString(storeErr)})
	}
	fmt.Printf("guard clean plan target=%s status=%s\n", plan.Target, plan.Status)
	for _, candidate := range plan.Candidates {
		if !candidate.Exists {
			continue
		}
		fmt.Printf("- %s %s risk=%s approval=%s\n  next: %s\n", candidate.ClientID, candidate.Path, candidate.Risk, candidate.Approval, candidate.RecommendedNext)
	}
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func guardIntent(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) == 0 {
		return fmt.Errorf("usage: meshclaw guard-intent <message> [--json]")
	}
	intent := guard.ParseIntent(strings.Join(args, " "))
	if jsonOut {
		return printJSON(map[string]interface{}{"intent": intent})
	}
	fmt.Printf("intent=%s mode=%s confidence=%s local_only=%t approval_required=%t\n", intent.Intent, intent.Mode, intent.Confidence, intent.RequiresLocalOnly, intent.ApprovalRequired)
	if intent.RecommendedCommand != "" {
		fmt.Printf("next: %s\n", intent.RecommendedCommand)
	}
	for _, warning := range intent.Warnings {
		fmt.Printf("warning: %s\n", warning)
	}
	return nil
}

func guardLocalServer(args []string) error {
	addr := "127.0.0.1:18765"
	if len(args) > 1 {
		return fmt.Errorf("usage: meshclaw guard-local-server [127.0.0.1:18765]")
	}
	if len(args) == 1 && strings.TrimSpace(args[0]) != "" {
		addr = strings.TrimSpace(args[0])
	}
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return err
	}
	if host != "127.0.0.1" && host != "localhost" && host != "::1" {
		return fmt.Errorf("guard local server refuses non-local bind address: %s", addr)
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		writeGuardLocalJSON(w, map[string]interface{}{"ok": true, "service": "meshclaw-guard-local", "raw_secret_boundary": "local-only"})
	})
	mux.HandleFunc("/api/guard/intent", func(w http.ResponseWriter, r *http.Request) {
		if !guardLocalMethod(w, r, http.MethodPost) {
			return
		}
		var req struct {
			Text string `json:"text"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			guardLocalError(w, http.StatusBadRequest, err)
			return
		}
		writeGuardLocalJSON(w, map[string]interface{}{"intent": guard.ParseIntent(req.Text)})
	})
	mux.HandleFunc("/api/guard/vault/import", func(w http.ResponseWriter, r *http.Request) {
		if !guardLocalMethod(w, r, http.MethodPost) {
			return
		}
		var req struct {
			Scope       string `json:"scope"`
			Name        string `json:"name"`
			Kind        string `json:"kind"`
			Description string `json:"description"`
			Backend     string `json:"backend"`
			Value       string `json:"value"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			guardLocalError(w, http.StatusBadRequest, err)
			return
		}
		entry, err := guardvault.Put(guardvault.PutOptions{
			Scope:       req.Scope,
			Name:        req.Name,
			Kind:        req.Kind,
			Description: req.Description,
			Backend:     req.Backend,
			Value:       []byte(req.Value),
		})
		if err != nil {
			guardLocalError(w, http.StatusBadRequest, err)
			return
		}
		record, storeErr := evidence.Store("guard-local-vault-import", entry.Scope, "stored "+entry.Handle, entry)
		writeGuardLocalJSON(w, map[string]interface{}{"entry": entry, "evidence": record, "store_error": errString(storeErr), "raw_secret_returned": false})
	})
	mux.HandleFunc("/api/guard/vault/list", func(w http.ResponseWriter, r *http.Request) {
		if !guardLocalMethod(w, r, http.MethodGet) {
			return
		}
		entries, err := guardvault.List()
		if err != nil {
			guardLocalError(w, http.StatusInternalServerError, err)
			return
		}
		writeGuardLocalJSON(w, map[string]interface{}{"entries": entries, "raw_secret_returned": false})
	})
	mux.HandleFunc("/api/guard/vault/backends", func(w http.ResponseWriter, r *http.Request) {
		if !guardLocalMethod(w, r, http.MethodGet) {
			return
		}
		writeGuardLocalJSON(w, map[string]interface{}{"backends": guardvault.Backends()})
	})
	mux.HandleFunc("/api/guard/posture", func(w http.ResponseWriter, r *http.Request) {
		if !guardLocalMethod(w, r, http.MethodGet) {
			return
		}
		report := guard.Posture("")
		writeGuardLocalJSON(w, map[string]interface{}{"report": report})
	})
	mux.HandleFunc("/api/guard/clean-plan", func(w http.ResponseWriter, r *http.Request) {
		if !guardLocalMethod(w, r, http.MethodGet) {
			return
		}
		plan := guard.Cleanup("")
		writeGuardLocalJSON(w, map[string]interface{}{"plan": plan})
	})
	server := &http.Server{Addr: addr, Handler: guardLocalOnly(mux), ReadHeaderTimeout: 5 * time.Second}
	fmt.Printf("meshclaw guard local server listening on http://%s\n", addr)
	fmt.Println("raw secret boundary: local-only; do not expose this port outside localhost")
	return server.ListenAndServe()
}

func guardLocalOnly(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		host, _, err := net.SplitHostPort(r.RemoteAddr)
		if err != nil || host != "127.0.0.1" && host != "::1" {
			guardLocalError(w, http.StatusForbidden, fmt.Errorf("local requests only"))
			return
		}
		next.ServeHTTP(w, r)
	})
}

func guardLocalMethod(w http.ResponseWriter, r *http.Request, method string) bool {
	if r.Method != method {
		guardLocalError(w, http.StatusMethodNotAllowed, fmt.Errorf("method must be %s", method))
		return false
	}
	return true
}

func writeGuardLocalJSON(w http.ResponseWriter, value interface{}) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(value)
}

func guardLocalError(w http.ResponseWriter, status int, err error) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(map[string]interface{}{"ok": false, "error": err.Error()})
}

func hygieneScanHost(args []string) error {
	jsonOut := wantsJSON(args)
	args = withoutJSONFlag(args)
	if len(args) != 1 {
		return fmt.Errorf("usage: meshclaw hygiene-scan-host <host>")
	}
	report := hygiene.ScanHost(args[0])
	record, storeErr := evidence.Store("hygiene-scan-host", args[0], report.Status, report)
	if jsonOut {
		return printJSON(map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)})
	}
	printHygieneReport(report)
	printEvidenceStoreStatus(record, storeErr)
	return nil
}

func hygieneScanText(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("usage: meshclaw hygiene-scan-text <target> <text>")
	}
	printHygieneReport(hygiene.ScanText(args[0], strings.Join(args[1:], " ")))
	return nil
}

func printReport(report workflow.Report) {
	fmt.Printf("%s host=%s status=%s\n", report.Name, report.Host, report.Status)
	for _, finding := range report.Findings {
		fmt.Printf("- [%s] %s\n  evidence: %s\n  next: %s\n", finding.Severity, finding.Title, finding.Evidence, finding.Next)
	}
}

func printHygieneReport(report hygiene.Report) {
	fmt.Printf("hygiene host=%s status=%s\n", report.Host, report.Status)
	for _, finding := range report.Findings {
		fmt.Printf("- finding [%s] %s target=%s evidence=%s\n", finding.Severity, finding.Type, finding.Target, finding.Evidence)
	}
	for _, action := range report.Actions {
		fmt.Printf("- action [%s] %s target=%s\n  command: %s\n  reason: %s\n  verify: %s\n", action.Mode, action.ID, action.Target, action.Command, action.Reason, action.Verify)
	}
}

func printGuardReport(report guard.Report) {
	fmt.Printf("guard mode=%s target=%s status=%s\n", report.Mode, report.Target, report.Status)
	for _, finding := range report.Findings {
		fmt.Printf("- finding [%s] %s target=%s evidence=%s replacement=%s\n", finding.Severity, finding.Kind, finding.Target, finding.Evidence, finding.Replacement)
	}
	for _, action := range report.Actions {
		fmt.Printf("- action [%s] %s approval=%t\n  target: %s\n  next: %s\n", action.Mode, action.ID, action.Approval, action.Target, action.Next)
	}
}

func mcp() error {
	return cmdMCP()
}
