package main

import (
	"testing"

	"github.com/meshclaw/meshclaw/internal/fleet"
	"github.com/meshclaw/meshclaw/internal/hygiene"
	"github.com/meshclaw/meshclaw/internal/monitor"
	"github.com/meshclaw/meshclaw/internal/workflow"
)

func TestServiceTriagePlanActionsSkipsIgnoreCandidates(t *testing.T) {
	report := serviceTriageReport{
		Items: []serviceTriageItem{
			{
				Host:      "d1",
				Service:   "open-webui",
				Class:     "real_incident",
				Mode:      "inspect",
				Severity:  "warning",
				Judgement: "User service is flapping.",
				Next:      "meshclaw service-check d1 open-webui",
			},
			{
				Host:     "c1",
				Service:  "cloud-init",
				Class:    "ignore_candidate",
				Mode:     "ignore_candidate",
				Severity: "info",
			},
		},
	}

	actions := serviceTriagePlanActions(report)
	if len(actions) != 1 {
		t.Fatalf("actions=%d, want 1", len(actions))
	}
	action := actions[0]
	if action.Type != "service_triage" {
		t.Fatalf("type=%q", action.Type)
	}
	if action.Metric != "service:open-webui" {
		t.Fatalf("metric=%q", action.Metric)
	}
	if action.Command != "meshclaw service-check d1 open-webui" {
		t.Fatalf("command=%q", action.Command)
	}
	if action.Verify != "meshclaw service-check d1 open-webui" {
		t.Fatalf("verify=%q", action.Verify)
	}
}

func TestServiceTriagePlanActionsMarksQuarantineCandidate(t *testing.T) {
	report := serviceTriageReport{
		Items: []serviceTriageItem{{
			Host:      "v1",
			Service:   "old-worker",
			Class:     "stale_or_missing_target",
			Mode:      "approval_required",
			Severity:  "warning",
			Judgement: "ExecStart target is missing.",
			Next:      "meshclaw service-quarantine v1 old-worker",
		}},
	}

	actions := serviceTriagePlanActions(report)
	if len(actions) != 1 {
		t.Fatalf("actions=%d, want 1", len(actions))
	}
	if actions[0].Type != "service_quarantine_candidate" {
		t.Fatalf("type=%q", actions[0].Type)
	}
	if actions[0].Mode != "approval_required" {
		t.Fatalf("mode=%q", actions[0].Mode)
	}
}

func TestClassifyServiceTriageKeepsBootOnlyServicesOutOfQuarantine(t *testing.T) {
	audit := serviceAuditReportForTest("c1", "systemd-networkd-wait-online")
	check := workflowReportForTest("c1", "findings", "ExecStart=/lib/systemd/systemd-networkd-wait-online\nstatus=failed")

	item := classifyServiceTriage(audit, check, "systemd-networkd-wait-online")
	if item.Class != "stale_or_boot_only" {
		t.Fatalf("class=%q", item.Class)
	}
	if item.Mode != "ignore_candidate" {
		t.Fatalf("mode=%q", item.Mode)
	}
}

func TestClassifyServiceTriageMarksExecFailureAsApprovalRequired(t *testing.T) {
	audit := serviceAuditReportForTest("d1", "open-webui")
	check := workflowReportForTest("d1", "findings", "open-webui.service\nActive: activating (auto-restart)\nMain PID: 1 (code=exited, status=203/EXEC)")

	item := classifyServiceTriage(audit, check, "open-webui")
	if item.Class != "stale_or_missing_target" {
		t.Fatalf("class=%q", item.Class)
	}
	if item.Mode != "approval_required" {
		t.Fatalf("mode=%q", item.Mode)
	}
}

func TestAnnotateHealPlanPoliciesAddsDecisionMetadata(t *testing.T) {
	actions := []monitor.HealPlanAction{
		{
			Node:    "d1",
			Type:    "disk_investigate",
			Mode:    "read_only",
			Command: "meshclaw disk-investigate d1 /",
		},
		{
			Node:    "d1",
			Type:    "service_quarantine_candidate",
			Mode:    "approval_required",
			Command: "meshclaw service-quarantine d1 open-webui",
		},
	}

	annotateHealPlanPolicies(actions)

	if actions[0].PolicyAction != "disk_investigate" || actions[0].PolicyDecision != "allow" || actions[0].ApprovalRequired {
		t.Fatalf("disk action policy = %#v", actions[0])
	}
	if actions[1].PolicyAction != "service_quarantine" || actions[1].PolicyDecision != "require_approval" || !actions[1].ApprovalRequired {
		t.Fatalf("service action policy = %#v", actions[1])
	}
}

func TestBuildAutohealPlanIncludesServiceTriageAndPolicy(t *testing.T) {
	m, err := monitor.New(monitor.DefaultConfig())
	if err != nil {
		t.Fatal(err)
	}
	serviceTriage := serviceTriageReport{
		Items: []serviceTriageItem{{
			Host:      "d1",
			Service:   "open-webui",
			Class:     "stale_or_missing_target",
			Mode:      "approval_required",
			Severity:  "warning",
			Judgement: "ExecStart target is missing.",
			Next:      "meshclaw service-quarantine d1 open-webui",
		}},
	}

	actions := buildAutohealPlan(m, serviceTriage)
	var found bool
	for _, action := range actions {
		if action.Type == "service_quarantine_candidate" && action.Node == "d1" {
			found = true
			if action.PolicyDecision != "require_approval" || !action.ApprovalRequired {
				t.Fatalf("service action missing approval policy metadata: %#v", action)
			}
		}
	}
	if !found {
		t.Fatalf("service triage action not included: %#v", actions)
	}
}

func TestPolicyActionForHealPlan(t *testing.T) {
	cases := map[string]string{
		"disk_investigate":             "disk_investigate",
		"disk_cleanup":                 "autoheal_apply_safe",
		"memory_cleanup":               "autoheal_apply_safe",
		"connectivity":                 "doctor",
		"service_triage":               "service_check",
		"service_quarantine_candidate": "service_quarantine",
	}
	for actionType, want := range cases {
		got := policyActionForHealPlan(monitor.HealPlanAction{Type: actionType})
		if got != want {
			t.Fatalf("%s policy action = %q, want %q", actionType, got, want)
		}
	}
}

func TestRecommendedOpsControlMCPPrioritizesStructuredFollowUps(t *testing.T) {
	report := opsControlReport{
		Monitor: monitorCheckOutput{Alerts: []monitor.Alert{
			{Node: "d1", Type: "disk", Level: "warning", Message: "Disk usage high"},
			{Node: "g1", Type: "memory", Level: "warning", Message: "Memory usage high"},
		}},
		ServiceTriage: serviceTriageReport{
			Items: []serviceTriageItem{{
				Host:    "d1",
				Service: "open-webui",
				Class:   "real_incident",
			}},
		},
		ManagementSummary: opsManagementSummary{
			ResourceAlerts:  2,
			ServiceFindings: 1,
			RealIncidents:   1,
		},
	}

	calls := recommendedOpsControlMCP(report)
	if len(calls) == 0 {
		t.Fatal("expected recommended MCP calls")
	}
	if calls[0].Tool != "meshclaw_service_check" {
		t.Fatalf("first tool=%q, want meshclaw_service_check", calls[0].Tool)
	}
	if calls[0].Arguments["host"] != "d1" || calls[0].Arguments["service"] != "open-webui" {
		t.Fatalf("unexpected service_check args: %#v", calls[0].Arguments)
	}
	if !hasRecommendedMCPTool(calls, "meshclaw_disk_investigate") {
		t.Fatalf("missing disk follow-up: %#v", calls)
	}
	if !hasRecommendedMCPTool(calls, "meshclaw_process_top") {
		t.Fatalf("missing memory follow-up: %#v", calls)
	}
	if calls[len(calls)-1].Tool != "meshclaw_evidence_latest" {
		t.Fatalf("last tool=%q, want meshclaw_evidence_latest", calls[len(calls)-1].Tool)
	}
}

func TestRecommendedServiceTriageMCPReturnsActionableCalls(t *testing.T) {
	report := serviceTriageReport{
		ServiceFindings: 2,
		MaxParallel:     4,
		Items: []serviceTriageItem{
			{Host: "d1", Service: "open-webui", Class: "real_incident"},
			{Host: "v1", Service: "old-worker", Class: "stale_or_missing_target"},
		},
	}

	calls := recommendedServiceTriageMCP(report)
	if len(calls) == 0 {
		t.Fatal("expected recommended MCP calls")
	}
	if calls[0].Tool != "meshclaw_service_check" {
		t.Fatalf("first tool=%q, want meshclaw_service_check", calls[0].Tool)
	}
	if !hasRecommendedMCPTool(calls, "meshclaw_analyze_logs") {
		t.Fatalf("missing log analysis follow-up: %#v", calls)
	}
	if !hasRecommendedMCPTool(calls, "meshclaw_policy_check") {
		t.Fatalf("missing policy follow-up: %#v", calls)
	}
	if calls[len(calls)-1].Tool != "meshclaw_evidence_latest" {
		t.Fatalf("last tool=%q, want meshclaw_evidence_latest", calls[len(calls)-1].Tool)
	}
}

func TestRecommendedAutohealPlanMCPSeparatesSafeAndApprovalActions(t *testing.T) {
	actions := []monitor.HealPlanAction{
		{
			Node:             "d1",
			Type:             "disk_investigate",
			Mode:             "read_only",
			Metric:           "disk",
			Command:          "meshclaw disk-investigate d1 /",
			PolicyAction:     "disk_investigate",
			PolicyDecision:   "allow",
			ApprovalRequired: false,
		},
		{
			Node:             "v1",
			Type:             "service_quarantine_candidate",
			Mode:             "approval_required",
			Metric:           "service:old-worker",
			Command:          "meshclaw service-quarantine v1 old-worker",
			PolicyAction:     "service_quarantine",
			PolicyDecision:   "require_approval",
			ApprovalRequired: true,
		},
		{
			Node:             "g1",
			Type:             "memory_cleanup",
			Mode:             "auto_safe",
			Command:          "sudo sync",
			PolicyAction:     "autoheal_apply_safe",
			PolicyDecision:   "allow",
			ApprovalRequired: false,
		},
	}

	calls := recommendedAutohealPlanMCP(actions)
	if !hasRecommendedMCPTool(calls, "meshclaw_disk_investigate") {
		t.Fatalf("missing disk evidence call: %#v", calls)
	}
	if !hasRecommendedMCPTool(calls, "meshclaw_policy_check") {
		t.Fatalf("missing policy check call: %#v", calls)
	}
	if !hasRecommendedMCPTool(calls, "meshclaw_autoheal_apply_safe") {
		t.Fatalf("missing apply-safe call: %#v", calls)
	}
	if calls[len(calls)-1].Tool != "meshclaw_evidence_latest" {
		t.Fatalf("last tool=%q, want meshclaw_evidence_latest", calls[len(calls)-1].Tool)
	}
}

func TestRecommendedFleetScanMCPMapsFindingsToFocusedTools(t *testing.T) {
	report := fleet.Report{
		Alerts: []monitor.Alert{{Node: "d1", Type: "disk", Level: "warning"}},
		Hosts: []fleet.HostReport{
			{
				Host:   "c1",
				Online: true,
				Security: &workflow.Report{Status: "findings", Findings: []workflow.Finding{{
					Severity: "warning",
					Title:    "Open listeners",
				}}},
				Logs: &workflow.Report{Status: "findings", Findings: []workflow.Finding{{
					Severity: "warning",
					Title:    "Recent warning/error log evidence found",
				}}},
			},
			{
				Host:   "v1",
				Online: true,
				Hygiene: &hygiene.Report{Status: "findings", Findings: []hygiene.Finding{{
					Severity: "high",
					Type:     hygiene.FindingSecretPattern,
				}}},
			},
		},
	}

	calls := recommendedFleetScanMCP(report)
	for _, tool := range []string{"meshclaw_disk_investigate", "meshclaw_security_check", "meshclaw_analyze_logs", "meshclaw_hygiene_scan_host"} {
		if !hasRecommendedMCPTool(calls, tool) {
			t.Fatalf("missing %s in %#v", tool, calls)
		}
	}
	if calls[len(calls)-1].Tool != "meshclaw_evidence_latest" {
		t.Fatalf("last tool=%q, want meshclaw_evidence_latest", calls[len(calls)-1].Tool)
	}
}

func TestRecommendedFleetScanMCPFiltersAlertsToSelectedHosts(t *testing.T) {
	report := fleet.Report{
		Options: fleet.Options{Hosts: []string{"d1"}},
		Alerts: []monitor.Alert{
			{Node: "d1", Type: "disk", Level: "warning"},
			{Node: "v3", Type: "offline", Level: "critical"},
		},
		Hosts: []fleet.HostReport{{Host: "d1", Online: true}},
	}

	calls := recommendedFleetScanMCP(report)
	if !hasRecommendedMCPTool(calls, "meshclaw_disk_investigate") {
		t.Fatalf("missing selected host disk call: %#v", calls)
	}
	for _, call := range calls {
		if call.Tool == "meshclaw_node_repair_plan" && call.Arguments["hosts"] == "v3" {
			t.Fatalf("unexpected unselected host repair call: %#v", calls)
		}
	}
	if calls[len(calls)-1].Tool != "meshclaw_evidence_latest" {
		t.Fatalf("last tool=%q, want meshclaw_evidence_latest", calls[len(calls)-1].Tool)
	}
}

func TestLimitRecommendedMCPCallsKeepsEvidenceLatest(t *testing.T) {
	calls := []recommendedMCPCall{}
	for i := 0; i < 10; i++ {
		calls = append(calls, recommendedMCPCall{Tool: "tool"})
	}
	calls = append(calls, recommendedMCPCall{Tool: "meshclaw_evidence_latest"})

	limited := limitRecommendedMCPCalls(calls, 8)
	if len(limited) != 8 {
		t.Fatalf("len=%d, want 8", len(limited))
	}
	if limited[len(limited)-1].Tool != "meshclaw_evidence_latest" {
		t.Fatalf("last tool=%q, want meshclaw_evidence_latest", limited[len(limited)-1].Tool)
	}
}

func TestRecommendedNodeRepairPlanMCPClassifiesRepairPaths(t *testing.T) {
	report := nodeRepairPlanReport{
		Hosts: []nodeRepairPlanHost{
			{Host: "c1", DaemonStatus: "auth_failed", Severity: "repair"},
			{Host: "s2", DaemonStatus: "protocol_mismatch", AuthDecision: "partial", Severity: "blocked"},
			{Host: "v3", DaemonStatus: "unreachable", Severity: "blocked"},
		},
	}

	calls := recommendedNodeRepairPlanMCP(report)
	for _, tool := range []string{"meshclaw_vssh_auth_paths", "meshclaw_policy_check", "meshclaw_vssh_daemon_audit", "meshclaw_node_inventory"} {
		if !hasRecommendedMCPTool(calls, tool) {
			t.Fatalf("missing %s in %#v", tool, calls)
		}
	}
	if calls[len(calls)-1].Tool != "meshclaw_evidence_latest" {
		t.Fatalf("last tool=%q, want meshclaw_evidence_latest", calls[len(calls)-1].Tool)
	}
}

func hasRecommendedMCPTool(calls []recommendedMCPCall, tool string) bool {
	for _, call := range calls {
		if call.Tool == tool {
			return true
		}
	}
	return false
}

func TestAnnotateHealActionsPoliciesAddsDecisionMetadata(t *testing.T) {
	actions := []monitor.HealAction{
		{
			Node:    "d1",
			Type:    "disk_cleanup",
			Command: "sudo apt-get clean",
		},
		{
			Node:    "d1",
			Type:    "restart_service",
			Command: "sudo systemctl restart nginx",
		},
	}

	annotateHealActionsPolicies(actions)

	if actions[0].PolicyAction != "autoheal_apply_safe" || actions[0].PolicyDecision != "allow" || actions[0].ApprovalRequired {
		t.Fatalf("disk cleanup policy = %#v", actions[0])
	}
	if actions[1].PolicyAction != "restart_service" || actions[1].PolicyDecision != "require_approval" || !actions[1].ApprovalRequired {
		t.Fatalf("restart policy = %#v", actions[1])
	}
}

func TestApplyAutohealPlanSafeSkipsReadOnlyAndApprovalRequired(t *testing.T) {
	plan := []monitor.HealPlanAction{
		{
			Node:             "d1",
			Type:             "disk_investigate",
			Mode:             "read_only",
			Command:          "meshclaw disk-investigate d1 /",
			PolicyAction:     "disk_investigate",
			PolicyDecision:   "allow",
			ApprovalRequired: false,
		},
		{
			Node:             "d1",
			Type:             "service_quarantine_candidate",
			Mode:             "approval_required",
			Command:          "meshclaw service-quarantine d1 open-webui",
			PolicyAction:     "service_quarantine",
			PolicyDecision:   "require_approval",
			ApprovalRequired: true,
		},
	}

	actions := applyAutohealPlanSafe(plan)
	if len(actions) != 2 {
		t.Fatalf("actions=%d, want 2", len(actions))
	}
	if !actions[0].Skipped || actions[0].SkipReason != "plan action is not auto_safe" {
		t.Fatalf("unexpected read-only action: %#v", actions[0])
	}
	if !actions[1].Skipped || actions[1].SkipReason != "policy does not allow unattended execution" {
		t.Fatalf("unexpected approval action: %#v", actions[1])
	}
}

func TestApplyAutohealPlanSafeSkipsAutoSafeWhenPolicyRequiresApproval(t *testing.T) {
	plan := []monitor.HealPlanAction{{
		Node:             "d1",
		Type:             "disk_cleanup",
		Mode:             "auto_safe",
		Command:          "sudo apt-get clean",
		PolicyAction:     "delete_data",
		PolicyDecision:   "require_approval",
		ApprovalRequired: true,
	}}

	actions := applyAutohealPlanSafe(plan)
	if len(actions) != 1 {
		t.Fatalf("actions=%d, want 1", len(actions))
	}
	if !actions[0].Skipped || actions[0].SkipReason != "policy does not allow unattended execution" {
		t.Fatalf("unexpected action: %#v", actions[0])
	}
}

func TestPolicyActionForHealType(t *testing.T) {
	cases := map[string]string{
		"disk_cleanup":    "autoheal_apply_safe",
		"memory_cleanup":  "autoheal_apply_safe",
		"restart_service": "restart_service",
		"unknown":         "run_command",
	}
	for actionType, want := range cases {
		got := policyActionForHealType(actionType)
		if got != want {
			t.Fatalf("%s policy action = %q, want %q", actionType, got, want)
		}
	}
}

func serviceAuditReportForTest(host, service string) workflow.Report {
	return workflowReportForTest(host, "findings", service+".service failed")
}

func workflowReportForTest(host, status, evidence string) workflow.Report {
	return workflow.Report{
		Name:   "service-check",
		Host:   host,
		Status: status,
		Findings: []workflow.Finding{{
			Severity: "warning",
			Title:    "test",
			Evidence: evidence,
		}},
	}
}
