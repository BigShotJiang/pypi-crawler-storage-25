package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/meshclaw/meshclaw/internal/capability"
	"github.com/meshclaw/meshclaw/internal/inventory"
)

func TestRecommendToolMCP(t *testing.T) {
	tests := []struct {
		name             string
		intent           string
		wantTool         string
		wantApproval     bool
		wantReasonSubstr string
	}{
		{
			name:             "cleanup plans before deletion",
			intent:           "d1 디스크 정리하고 중복 체크포인트 지워",
			wantTool:         "meshclaw_data_clean_plan",
			wantApproval:     true,
			wantReasonSubstr: "Cleanup should start with a plan",
		},
		{
			name:             "direct vssh transport question",
			intent:           "그냥 ssh 말고 vssh를 직접 써야 하는 경우가 뭐야",
			wantTool:         "direct vssh MCP",
			wantApproval:     false,
			wantReasonSubstr: "low-level transport primitives",
		},
		{
			name:             "service incident",
			intent:           "open-webui 서비스가 d1에서 죽는 것 같아 로그랑 상태 봐줘",
			wantTool:         "meshclaw_service_triage",
			wantApproval:     false,
			wantReasonSubstr: "Service incidents should be triaged first",
		},
		{
			name:             "server status management",
			intent:           "전체 서버 상태 보고 뭐 조치해야 하는지 알려줘",
			wantTool:         "meshclaw_ops_control",
			wantApproval:     false,
			wantReasonSubstr: "Broad server management",
		},
		{
			name:             "sensitive data leak check",
			intent:           "서버 전체에서 개인정보 민감정보가 새는지 확인해",
			wantTool:         "meshclaw_security_check",
			wantApproval:     false,
			wantReasonSubstr: "Security and sensitive-data work",
		},
		{
			name:             "combined ops orchestration workflow",
			intent:           "메일과 올라마 워커를 합친 오케스트레이션 데모를 policy and evidence로 실행해",
			wantTool:         "meshclaw_workflow_run",
			wantApproval:     false,
			wantReasonSubstr: "Combined mail/model/server orchestration",
		},
		{
			name:             "inventory override before placement",
			intent:           "c1을 mail-server 역할로 등록하고 태그 mail,mox 붙여",
			wantTool:         "meshclaw_inventory_override_set",
			wantApproval:     false,
			wantReasonSubstr: "private fleet meaning",
		},
		{
			name:             "capability selection before action",
			intent:           "GPU 추론 작업은 어느 노드에서 돌리면 좋아?",
			wantTool:         "meshclaw_capability_recommend",
			wantApproval:     false,
			wantReasonSubstr: "placement or capability selection",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := recommendToolMCP(tt.intent, "codex")
			if gotTool := stringMapValue(got, "recommended_tool"); gotTool != tt.wantTool {
				t.Fatalf("recommended_tool=%q want %q, got=%v", gotTool, tt.wantTool, got)
			}
			if gotApproval, _ := got["approval_expected"].(bool); gotApproval != tt.wantApproval {
				t.Fatalf("approval_expected=%v want %v, got=%v", gotApproval, tt.wantApproval, got)
			}
			if reason := stringMapValue(got, "reason"); !strings.Contains(reason, tt.wantReasonSubstr) {
				t.Fatalf("reason=%q does not contain %q", reason, tt.wantReasonSubstr)
			}
			if tt.name == "combined ops orchestration workflow" {
				args, _ := got["arguments"].(map[string]interface{})
				if args["name"] != "meshclaw-ops-orchestration-demo" {
					t.Fatalf("workflow name=%v, got=%v", args["name"], got)
				}
			}
		})
	}
}

func TestMCPSurfaceIncludesWorkflowValidate(t *testing.T) {
	surface := mcpSurfaceGuide()
	defaultTools, ok := surface["default_tools"].([]string)
	if !ok {
		t.Fatalf("default_tools missing: %#v", surface)
	}
	if !containsString(defaultTools, "meshclaw_workflow_validate") {
		t.Fatalf("default tools missing workflow validate: %#v", defaultTools)
	}
	if !containsString(defaultTools, "meshclaw_workflow_scaffold") {
		t.Fatalf("default tools missing workflow scaffold: %#v", defaultTools)
	}
	if !containsString(defaultTools, "meshclaw_workflow_run") {
		t.Fatalf("default tools missing workflow run: %#v", defaultTools)
	}
	if !containsString(defaultTools, "meshclaw_workflow_plan_execute") {
		t.Fatalf("default tools missing workflow plan execute: %#v", defaultTools)
	}
	if !containsString(defaultTools, "meshclaw_inventory_override_list") {
		t.Fatalf("default tools missing inventory override list: %#v", defaultTools)
	}
	if !containsString(defaultTools, "meshclaw_quickstart") {
		t.Fatalf("default tools missing quickstart: %#v", defaultTools)
	}
	if !containsString(defaultTools, "meshclaw_doctor") {
		t.Fatalf("default tools missing doctor: %#v", defaultTools)
	}
	if !containsString(defaultTools, "meshclaw_capability_recommend") {
		t.Fatalf("default tools missing capability recommend: %#v", defaultTools)
	}
	path, ok := surface["default_path"].([]map[string]interface{})
	if !ok || len(path) < 6 {
		t.Fatalf("default_path missing: %#v", surface["default_path"])
	}
	if path[1]["tool"] != "meshclaw_quickstart" || path[2]["tool"] != "meshclaw_doctor" || path[3]["tool"] != "meshclaw_server_list" || path[7]["tool"] != "meshclaw_capability_recommend" {
		t.Fatalf("default path should start with inventory and capability recommendation: %#v", path)
	}
	loop, ok := surface["canonical_loop"].([]string)
	if !ok || !containsString(loop, "workflow dry-run") {
		t.Fatalf("canonical loop missing workflow dry-run: %#v", surface["canonical_loop"])
	}

	result, err := callMCPTool("meshclaw_workflow_list", map[string]interface{}{})
	if err != nil {
		t.Fatal(err)
	}
	payload, ok := result.(map[string]interface{})
	if !ok {
		t.Fatalf("payload=%#v", result)
	}
	if payload["validate_tool"] != "meshclaw_workflow_validate" {
		t.Fatalf("validate_tool=%v", payload["validate_tool"])
	}
	if payload["scaffold_tool"] != "meshclaw_workflow_scaffold" {
		t.Fatalf("scaffold_tool=%v", payload["scaffold_tool"])
	}
	if payload["plan_execute_tool"] != "meshclaw_workflow_plan_execute" {
		t.Fatalf("plan_execute_tool=%v", payload["plan_execute_tool"])
	}
}

func TestMCPToolNamesUsePortableCharacters(t *testing.T) {
	for _, tool := range mcpTools() {
		if !validMCPToolNameForClients(tool.Name) {
			t.Fatalf("invalid MCP tool name for client compatibility: %q", tool.Name)
		}
	}
}

func TestCapabilityValidateMCP(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "capabilities.json")
	payload := map[string]interface{}{
		"version": 1,
		"capabilities": []map[string]interface{}{
			{
				"id":            "local-model",
				"kind":          "model",
				"provider":      "ollama",
				"host":          "macmini",
				"capabilities":  []string{"chat", "local"},
				"status":        "available",
				"secret_policy": "none",
			},
		},
	}
	data, err := json.Marshal(payload)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, data, 0600); err != nil {
		t.Fatal(err)
	}

	result, err := callMCPTool("meshclaw_capability_validate", map[string]interface{}{"path": path})
	if err != nil {
		t.Fatal(err)
	}
	switch report := result.(type) {
	case map[string]interface{}:
		if valid, _ := report["valid"].(bool); !valid {
			t.Fatalf("expected valid capability report: %#v", report)
		}
	case capability.ValidationReport:
		if !report.Valid {
			t.Fatalf("expected valid capability report: %#v", report)
		}
	default:
		t.Fatalf("report=%#v", result)
	}
}

func TestCapabilityRecommendMCP(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("MESHCLAW_CAPABILITY_FILE", filepath.Join(dir, "missing-capabilities.json"))
	t.Setenv("MESHCLAW_INVENTORY_FILE", filepath.Join(dir, "inventory.json"))
	payload := map[string]interface{}{
		"version": 1,
		"nodes": []map[string]interface{}{
			{"name": "g1", "role": "ollama-worker", "tags": []string{"linux", "gpu"}, "online": true},
		},
	}
	data, err := json.Marshal(payload)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "inventory.json"), data, 0600); err != nil {
		t.Fatal(err)
	}

	result, err := callMCPTool("meshclaw_capability_recommend", map[string]interface{}{"intent": "choose a gpu ollama model worker"})
	if err != nil {
		t.Fatal(err)
	}
	report, ok := result.(capability.RecommendationReport)
	if !ok {
		t.Fatalf("report=%#v", result)
	}
	if report.Class != "model" {
		t.Fatalf("class=%q want model", report.Class)
	}
	if len(report.Candidates) == 0 || report.Candidates[0].Capability.ID != "g1-gpu-compute" {
		t.Fatalf("expected g1-gpu-compute first: %#v", report.Candidates)
	}
}

func TestInventoryOverrideMCP(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("HOME", dir)
	t.Setenv("MESHCLAW_INVENTORY_OVERRIDES_FILE", filepath.Join(dir, "overrides.json"))

	result, err := callMCPTool("meshclaw_inventory_override_set", map[string]interface{}{
		"node": "c1",
		"role": "mail-server",
		"tags": "mail,mox",
	})
	if err != nil {
		t.Fatal(err)
	}
	payload, ok := result.(map[string]interface{})
	if !ok {
		t.Fatalf("payload=%#v", result)
	}
	nodes, ok := payload["nodes"].([]inventory.Node)
	if !ok || len(nodes) != 1 {
		t.Fatalf("nodes=%#v", payload["nodes"])
	}
	if nodes[0].Name != "c1" || nodes[0].Role != "mail-server" {
		t.Fatalf("unexpected override node: %#v", nodes[0])
	}
	listed, err := callMCPTool("meshclaw_inventory_override_list", map[string]interface{}{})
	if err != nil {
		t.Fatal(err)
	}
	if listed.(map[string]interface{})["path"] == "" {
		t.Fatalf("expected override path: %#v", listed)
	}
	removed, err := callMCPTool("meshclaw_inventory_override_remove", map[string]interface{}{"node": "c1"})
	if err != nil {
		t.Fatal(err)
	}
	if ok, _ := removed.(map[string]interface{})["removed"].(bool); !ok {
		t.Fatalf("expected removed=true: %#v", removed)
	}
}

func validMCPToolNameForClients(name string) bool {
	if name == "" {
		return false
	}
	for _, r := range name {
		if r >= 'a' && r <= 'z' || r >= 'A' && r <= 'Z' || r >= '0' && r <= '9' || r == '_' {
			continue
		}
		return false
	}
	return true
}

func containsString(values []string, needle string) bool {
	for _, value := range values {
		if value == needle {
			return true
		}
	}
	return false
}
