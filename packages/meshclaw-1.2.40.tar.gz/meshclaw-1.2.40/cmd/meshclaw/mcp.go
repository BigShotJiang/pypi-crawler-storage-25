package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/meshclaw/meshclaw/internal/capability"
	"github.com/meshclaw/meshclaw/internal/doctor"
	"github.com/meshclaw/meshclaw/internal/evidence"
	"github.com/meshclaw/meshclaw/internal/fleet"
	"github.com/meshclaw/meshclaw/internal/guard"
	"github.com/meshclaw/meshclaw/internal/guardvault"
	"github.com/meshclaw/meshclaw/internal/hygiene"
	"github.com/meshclaw/meshclaw/internal/inventory"
	"github.com/meshclaw/meshclaw/internal/monitor"
	"github.com/meshclaw/meshclaw/internal/policy"
	"github.com/meshclaw/meshclaw/internal/provision"
	"github.com/meshclaw/meshclaw/internal/runtime"
	"github.com/meshclaw/meshclaw/internal/runtimeflow"
	"github.com/meshclaw/meshclaw/internal/workers"
	"github.com/meshclaw/meshclaw/internal/workflow"
	"github.com/meshclaw/meshclaw/internal/workspace"
)

type mcpRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params,omitempty"`
	ID      interface{}     `json:"id,omitempty"`
}

type mcpResponse struct {
	JSONRPC string      `json:"jsonrpc"`
	Result  interface{} `json:"result,omitempty"`
	Error   *mcpError   `json:"error,omitempty"`
	ID      interface{} `json:"id,omitempty"`
}

type mcpError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

type mcpTool struct {
	Name        string         `json:"name"`
	Description string         `json:"description"`
	InputSchema mcpInputSchema `json:"inputSchema"`
}

type mcpInputSchema struct {
	Type       string                 `json:"type"`
	Properties map[string]mcpProperty `json:"properties"`
	Required   []string               `json:"required,omitempty"`
}

type mcpProperty struct {
	Type        string      `json:"type"`
	Description string      `json:"description"`
	Default     interface{} `json:"default,omitempty"`
}

func cmdMCP() error {
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		line := scanner.Text()
		if line == "" {
			continue
		}
		var req mcpRequest
		if err := json.Unmarshal([]byte(line), &req); err != nil {
			continue
		}
		if req.ID == nil {
			continue
		}
		resp := handleMCP(req)
		out, _ := json.Marshal(resp)
		fmt.Println(string(out))
	}
	return scanner.Err()
}

func handleMCP(req mcpRequest) mcpResponse {
	switch req.Method {
	case "initialize":
		return mcpResponse{
			JSONRPC: "2.0",
			Result: map[string]interface{}{
				"protocolVersion": "2024-11-05",
				"capabilities":    map[string]interface{}{"tools": map[string]interface{}{}},
				"serverInfo":      map[string]string{"name": "meshclaw-mcp", "version": meshclawVersion},
			},
			ID: req.ID,
		}
	case "tools/list":
		return mcpResponse{JSONRPC: "2.0", Result: map[string]interface{}{"tools": mcpTools()}, ID: req.ID}
	case "tools/call":
		var params struct {
			Name      string                 `json:"name"`
			Arguments map[string]interface{} `json:"arguments"`
		}
		if err := json.Unmarshal(req.Params, &params); err != nil {
			return mcpResponse{JSONRPC: "2.0", Error: &mcpError{Code: -32602, Message: err.Error()}, ID: req.ID}
		}
		result, err := callMCPTool(params.Name, params.Arguments)
		if err != nil {
			return mcpResponse{JSONRPC: "2.0", Error: &mcpError{Code: -32000, Message: err.Error()}, ID: req.ID}
		}
		data, _ := json.MarshalIndent(result, "", "  ")
		return mcpResponse{
			JSONRPC: "2.0",
			Result: map[string]interface{}{
				"content": []map[string]string{{"type": "text", "text": string(data)}},
			},
			ID: req.ID,
		}
	default:
		return mcpResponse{JSONRPC: "2.0", Error: &mcpError{Code: -32601, Message: "unknown method: " + req.Method}, ID: req.ID}
	}
}

func mcpTools() []mcpTool {
	return []mcpTool{
		{Name: "meshclaw_ai_guide", Description: "Canonical guide for Codex, Claude, Cursor, Open WebUI, and local LLMs. Explains when to use MeshClaw workflows/policy/evidence vs direct vssh transport tools.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_quickstart", Description: "Run the first 5 minutes path in one safe call: setup doctor, fleet-health workflow inspection, dry-run evidence bundle, and next actions. Creates dry-run evidence only.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_doctor", Description: "Check local MeshClaw/VSSH/MCP setup before fleet operations. Use this first when tools appear installed but monitor, vssh, or client setup looks inconsistent.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_mcp_surface", Description: "Return the recommended MeshClaw MCP tool surface for AI operators: default tools, advanced tools, and when to use direct vssh instead.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_tool_recommend", Description: "Recommend the safest MeshClaw/vssh tool path for a natural-language operator intent without executing anything.", InputSchema: objectSchema(map[string]mcpProperty{
			"intent":  {Type: "string", Description: "Natural-language operator intent or task"},
			"subject": {Type: "string", Description: "Optional caller/model subject, e.g. codex, claude, local-llm", Default: "codex"},
		}, []string{"intent"})},
		{Name: "meshclaw_server_list", Description: "List known servers and Tailscale-first connection facts. For AI operators, use this for inventory truth before choosing execution targets.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_inventory_discover", Description: "Discover managed nodes from Tailscale, vssh, and local user mappings without changing the saved inventory.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_inventory_diff", Description: "Compare saved inventory with current discovery and report missing or changed nodes.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_inventory_override_list", Description: "List operator-owned inventory role/tag overrides. Use before changing private fleet meaning.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_inventory_override_set", Description: "Set an operator-owned inventory role/tag override for one node. This updates local MeshClaw state only, not the remote server.", InputSchema: objectSchema(map[string]mcpProperty{
			"node":     {Type: "string", Description: "Node name, e.g. c1, g4, s2"},
			"role":     {Type: "string", Description: "Optional role, e.g. mail-server, automation-worker, ollama-worker"},
			"location": {Type: "string", Description: "Optional location label, e.g. vps, home, lab"},
			"user":     {Type: "string", Description: "Optional default SSH/vssh user"},
			"tags":     {Type: "string", Description: "Optional comma-separated tags, e.g. linux,mail,mox"},
		}, []string{"node"})},
		{Name: "meshclaw_inventory_override_remove", Description: "Remove one operator-owned inventory override entry by node name.", InputSchema: objectSchema(map[string]mcpProperty{
			"node": {Type: "string", Description: "Node name to remove from inventory overrides"},
		}, []string{"node"})},
		{Name: "meshclaw_workers", Description: "List model operators, Matrix room surfaces, MeshClaw MCP, and vssh execution workers.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_workspace_list", Description: "List known workspaces: server, folder, owner/model, branch, purpose, and recent activity.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_workspace_add", Description: "Register or update a workspace location used by a model or human operator.", InputSchema: objectSchema(map[string]mcpProperty{
			"id":      {Type: "string", Description: "Stable workspace id"},
			"host":    {Type: "string", Description: "Host name, or local"},
			"path":    {Type: "string", Description: "Absolute workspace path"},
			"owner":   {Type: "string", Description: "Current owner/model/operator"},
			"purpose": {Type: "string", Description: "Why this workspace exists"},
			"branch":  {Type: "string", Description: "Git branch or working lane"},
			"source":  {Type: "string", Description: "Frontend/source, e.g. codex-app, claude-web, matrix"},
		}, []string{"id", "host", "path"})},
		{Name: "meshclaw_workspace_activity", Description: "Record what an operator/model did in a workspace and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"id":       {Type: "string", Description: "Workspace id"},
			"actor":    {Type: "string", Description: "Actor, e.g. codex, claude, local-llm, human"},
			"action":   {Type: "string", Description: "Action name, e.g. edit, review, deploy, scan"},
			"summary":  {Type: "string", Description: "Short activity summary"},
			"evidence": {Type: "string", Description: "Optional evidence URL/path/id"},
		}, []string{"id", "actor", "action", "summary"})},
		{Name: "meshclaw_capability_list", Description: "List models, APIs, services, and provisioner capabilities without revealing secrets.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_capability_validate", Description: "Validate the MeshClaw capability registry before AI placement or execute mode. Returns structured errors and warnings without revealing secrets.", InputSchema: objectSchema(map[string]mcpProperty{
			"path": {Type: "string", Description: "Optional capability registry path. Defaults to ~/.meshclaw/capabilities.json or MESHCLAW_CAPABILITY_FILE."},
		}, nil)},
		{Name: "meshclaw_capability_recommend", Description: "Recommend capability IDs for an AI operator intent before placement, workflow execution, API use, or model selection. Returns scores, reasons, approval flags, and secret-handling cautions.", InputSchema: objectSchema(map[string]mcpProperty{
			"intent": {Type: "string", Description: "Natural-language intent, e.g. choose a GPU model worker, inspect mail server, archive artifacts, or provision a VPS"},
		}, []string{"intent"})},
		{Name: "meshclaw_adapter_list", Description: "List MeshClaw Runtime adapters and whether each adapter can execute, needs a command, or only records structured evidence.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_monitor_check", Description: "Check fleet health through MeshClaw's monitored state and vssh-backed facts. Prefer this over raw vssh facts for fleet status.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_ops_brief", Description: "Return an operations brief: fleet health, top risks, next actions, and evidence context. Good first tool for broad 'what is wrong?' prompts.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_ops_control", Description: "Canonical AI operator entry point for server management: health, service findings, autoheal candidates, policy posture, and evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"apply_safe": {Type: "boolean", Description: "Apply bounded non-destructive autoheal actions", Default: false},
		}, nil)},
		{Name: "meshclaw_node_inventory", Description: "Collect read-only software inventory for one node: OS, tools, services, containers, GPU.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
		}, []string{"host"})},
		{Name: "meshclaw_fleet_inventory", Description: "Collect read-only software inventory across fleet nodes.", InputSchema: objectSchema(map[string]mcpProperty{
			"hosts":        {Type: "string", Description: "Optional comma-separated inventory hosts"},
			"max_parallel": {Type: "number", Description: "Maximum hosts scanned in parallel", Default: 4},
		}, nil)},
		{Name: "meshclaw_placement_plan", Description: "Recommend nodes for a workload using inventory, monitor facts, and tool availability.", InputSchema: objectSchema(map[string]mcpProperty{
			"workload": {Type: "string", Description: "Natural workload description, e.g. GPU inference, Docker service, local LLM"},
		}, []string{"workload"})},
		{Name: "meshclaw_orchestration_plan", Description: "Explain a complex orchestration scenario: plan decomposition, worker/model placement, why tools like LangChain/n8n are or are not used, documentation checks, secret policy, and evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"scenario": {Type: "string", Description: "Natural-language orchestration scenario"},
		}, []string{"scenario"})},
		{Name: "meshclaw_fleet_scan", Description: "Run a policy-checked fleet diagnostic scan and store one evidence bundle.", InputSchema: objectSchema(map[string]mcpProperty{
			"hosts":        {Type: "string", Description: "Optional comma-separated inventory hosts"},
			"security":     {Type: "boolean", Description: "Run security snapshots", Default: true},
			"hygiene":      {Type: "boolean", Description: "Run redacted hygiene scans", Default: true},
			"logs":         {Type: "boolean", Description: "Run warning/error log scans", Default: true},
			"max_parallel": {Type: "number", Description: "Maximum hosts scanned in parallel", Default: 3},
		}, nil)},
		{Name: "meshclaw_fleet_service_audit", Description: "Run read-only failed/restarting service audit across Linux fleet nodes.", InputSchema: objectSchema(map[string]mcpProperty{
			"hosts":        {Type: "string", Description: "Optional comma-separated inventory hosts"},
			"max_parallel": {Type: "number", Description: "Maximum hosts scanned in parallel", Default: 4},
		}, nil)},
		{Name: "meshclaw_vssh_daemon_audit", Description: "Check vssh native daemon reachability, auth, version, and service state across fleet nodes.", InputSchema: objectSchema(map[string]mcpProperty{
			"hosts": {Type: "string", Description: "Optional comma-separated inventory hosts"},
		}, nil)},
		{Name: "meshclaw_vssh_auth_paths", Description: "Compare vssh binary, secret source, run-many, and facts paths without revealing the secret.", InputSchema: objectSchema(map[string]mcpProperty{
			"hosts": {Type: "string", Description: "Optional comma-separated inventory hosts"},
		}, nil)},
		{Name: "meshclaw_node_repair_plan", Description: "Canonical AI operator entry point for node execution health: classify daemon/auth/version issues and return safe repair steps.", InputSchema: objectSchema(map[string]mcpProperty{
			"hosts": {Type: "string", Description: "Optional comma-separated inventory hosts"},
		}, nil)},
		{Name: "meshclaw_service_triage", Description: "Audit and classify service failure candidates as real incidents, stale boot-only findings, ignore candidates, or approval-required actions.", InputSchema: objectSchema(map[string]mcpProperty{
			"hosts":        {Type: "string", Description: "Optional comma-separated inventory hosts"},
			"limit":        {Type: "number", Description: "Maximum service candidates to inspect with service-check", Default: 5},
			"max_parallel": {Type: "number", Description: "Maximum hosts audited in parallel", Default: 4},
		}, nil)},
		{Name: "meshclaw_autoheal_plan", Description: "Convert current fleet alerts into read-only or auto-safe actions.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_autoheal_apply_safe", Description: "Apply bounded non-destructive autoheal actions and store evidence.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_workflow_list", Description: "Default workflow discovery tool. Lists repeatable MeshClaw workflows and tells AI operators the recommended next call. Start with fleet-health-demo or examples/workflows/fleet-health.json.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_workflow_scaffold", Description: "Create a validated generic MeshClaw workflow JSON scaffold for user-authored operations. Use when no existing workflow fits the operator intent.", InputSchema: objectSchema(map[string]mcpProperty{
			"name":   {Type: "string", Description: "New workflow name"},
			"output": {Type: "string", Description: "Optional output JSON path. Defaults to ~/.meshclaw/workflows/<name>.json"},
			"force":  {Type: "boolean", Description: "Overwrite an existing scaffold", Default: false},
		}, []string{"name"})},
		{Name: "meshclaw_workflow_validate", Description: "Validate a workflow name or file before running it. Use before meshclaw_workflow_run for user-authored workflows and examples/workflows/*.json.", InputSchema: objectSchema(map[string]mcpProperty{
			"name": {Type: "string", Description: "Workflow name or JSON file path"},
		}, []string{"name"})},
		{Name: "meshclaw_workflow_inspect", Description: "Inspect a workflow before running it: steps, approval gates, adapters, required nodes, policy decisions, and matching capability IDs. Use after validation and before execute mode.", InputSchema: objectSchema(map[string]mcpProperty{
			"name": {Type: "string", Description: "Workflow name or JSON file path"},
		}, []string{"name"})},
		{Name: "meshclaw_workflow_resume", Description: "Read a previous workflow evidence bundle and produce a resume plan: failed steps, retryable failures, approval-pending steps, degraded worker repair hints, and dry-run steps ready for execute mode. Does not execute anything.", InputSchema: objectSchema(map[string]mcpProperty{
			"ref": {Type: "string", Description: "latest, a bundle directory, or an execution.json path", Default: "latest"},
		}, nil)},
		{Name: "meshclaw_workflow_plan_execute", Description: "Preflight an evidence bundle before execute mode. Returns ready/blocking decision, approval/vault/repair blockers, and exact execute call when ready. Does not execute anything.", InputSchema: objectSchema(map[string]mcpProperty{
			"ref": {Type: "string", Description: "latest, a bundle directory, or an execution.json path", Default: "latest"},
		}, nil)},
		{Name: "meshclaw_approvals_list", Description: "List approval records stored in a workflow evidence bundle.", InputSchema: objectSchema(map[string]mcpProperty{
			"ref": {Type: "string", Description: "latest, a bundle directory, or an execution.json path", Default: "latest"},
		}, nil)},
		{Name: "meshclaw_approvals_grant", Description: "Record an approval for one approval-required workflow step. This only records approval evidence; it does not execute the step.", InputSchema: objectSchema(map[string]mcpProperty{
			"ref":    {Type: "string", Description: "latest, a bundle directory, or an execution.json path", Default: "latest"},
			"step":   {Type: "string", Description: "Workflow step id to approve"},
			"actor":  {Type: "string", Description: "Human or operator granting approval"},
			"reason": {Type: "string", Description: "Approval reason"},
			"source": {Type: "string", Description: "Approval source, e.g. cli, matrix, codex, claude", Default: "mcp"},
		}, []string{"step", "actor"})},
		{Name: "meshclaw_workflow_run", Description: "Canonical orchestration tool for AI operators. Runs a MeshClaw workflow with policy checks, structured step results, approvals, and an evidence bundle. Use dry-run first unless the user explicitly asked to execute.", InputSchema: objectSchema(map[string]mcpProperty{
			"name":          {Type: "string", Description: "Workflow name"},
			"mode":          {Type: "string", Description: "dry-run or execute", Default: "dry-run"},
			"approvals_ref": {Type: "string", Description: "Optional approval bundle ref for execute mode: latest, bundle directory, or execution.json"},
			"steps":         {Type: "string", Description: "Optional comma-separated workflow step IDs to run instead of the whole workflow"},
		}, []string{"name"})},
		{Name: "meshclaw_evidence_latest", Description: "Return the latest MeshClaw Runtime evidence bundle paths and summary, including execution.json, steps.jsonl, report.html, and meshclaw-actions.md preview. Use after meshclaw_workflow_run or meshclaw_run_evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"actions_preview_bytes": {Type: "number", Description: "Maximum bytes of meshclaw-actions.md to include", Default: 4000},
		}, nil)},
		{Name: "meshclaw_evidence_list", Description: "List recent stored evidence records.", InputSchema: objectSchema(map[string]mcpProperty{"limit": {Type: "number", Description: "Maximum records to return", Default: 20}}, nil)},
		{Name: "meshclaw_policy_check", Description: "Decide whether a subject can perform an action on a resource.", InputSchema: objectSchema(map[string]mcpProperty{
			"subject":  {Type: "string", Description: "Operator subject, e.g. codex, claude, local-llm, automation"},
			"action":   {Type: "string", Description: "Action name, e.g. read_state, run_command, provision_server"},
			"resource": {Type: "string", Description: "Resource name, e.g. server, secret, provider"},
			"context":  {Type: "string", Description: "Optional command or extra context"},
		}, []string{"subject", "action", "resource"})},
		{Name: "meshclaw_policy_show", Description: "Return the active MeshClaw policy config without revealing secrets.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_matrix_plan", Description: "Return the supported Matrix bridge role: ops room, approval channel, notification channel, and optional MCP surface.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_ops_dispatch", Description: "Route a Matrix/Open WebUI/Codex/Claude-style message to a MeshClaw ops result.", InputSchema: objectSchema(map[string]mcpProperty{
			"source":  {Type: "string", Description: "Source surface, e.g. matrix, openwebui, codex, claude"},
			"message": {Type: "string", Description: "Natural-language or command-like message"},
		}, []string{"source", "message"})},
		{Name: "meshclaw_provision_plan", Description: "Plan temporary VPS/server capacity without creating resources.", InputSchema: objectSchema(map[string]mcpProperty{
			"purpose":        {Type: "string", Description: "Why temporary capacity is needed"},
			"budget_usd":     {Type: "number", Description: "Maximum budget cap in USD", Default: 0},
			"ttl_hours":      {Type: "number", Description: "Time-to-live for temporary capacity", Default: 6},
			"required_class": {Type: "string", Description: "Capacity class, e.g. small-vps, gpu, storage", Default: "small-vps"},
			"provider":       {Type: "string", Description: "Provider capability id", Default: "provider-api"},
			"region":         {Type: "string", Description: "Preferred region", Default: "nearest-available"},
		}, []string{"purpose"})},
		{Name: "meshclaw_run_evidence", Description: "Run one policy-checked diagnostic command and store evidence. Prefer this over direct vssh/SSH when an AI operator needs audit trail, fallback, and policy context.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":    {Type: "string", Description: "Inventory host name"},
			"command": {Type: "string", Description: "Command to execute"},
		}, []string{"host", "command"})},
		{Name: "meshclaw_job_start", Description: "Start a long-running vssh daemon job and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":    {Type: "string", Description: "Inventory host name"},
			"command": {Type: "string", Description: "Command to run asynchronously"},
		}, []string{"host", "command"})},
		{Name: "meshclaw_job_status", Description: "Return vssh daemon job status and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
			"id":   {Type: "string", Description: "Job id"},
		}, []string{"host", "id"})},
		{Name: "meshclaw_job_logs", Description: "Return vssh daemon job logs and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":       {Type: "string", Description: "Inventory host name"},
			"id":         {Type: "string", Description: "Job id"},
			"tail_bytes": {Type: "number", Description: "Return only the last N bytes", Default: 0},
		}, []string{"host", "id"})},
		{Name: "meshclaw_job_cancel", Description: "Cancel a running vssh daemon job and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
			"id":   {Type: "string", Description: "Job id"},
		}, []string{"host", "id"})},
		{Name: "meshclaw_artifact_collect", Description: "Collect remote artifact metadata/content through vssh and store evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":      {Type: "string", Description: "Inventory host name"},
			"path":      {Type: "string", Description: "Remote file or directory path"},
			"max_bytes": {Type: "number", Description: "Maximum file bytes to return before base64 encoding", Default: 1048576},
		}, []string{"host", "path"})},
		{Name: "meshclaw_disk_investigate", Description: "Collect read-only disk evidence for a host/path.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
			"path": {Type: "string", Description: "Absolute path to inspect", Default: "/"},
		}, []string{"host"})},
		{Name: "meshclaw_process_top", Description: "Collect read-only top memory and CPU process evidence for a host.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
		}, []string{"host"})},
		{Name: "meshclaw_data_clean_plan", Description: "Find raw/intermediate/checkpoint cleanup candidates while preserving clean/final outputs.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
			"path": {Type: "string", Description: "Absolute project path to inspect"},
		}, []string{"host", "path"})},
		{Name: "meshclaw_data_clean_apply", Description: "Apply a manifest generated by data_clean_plan.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":     {Type: "string", Description: "Inventory host name"},
			"manifest": {Type: "string", Description: "Manifest path produced by data_clean_plan"},
		}, []string{"host", "manifest"})},
		{Name: "meshclaw_analyze_logs", Description: "Collect warning/error log evidence from system journal or a log file.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":   {Type: "string", Description: "Inventory host name"},
			"source": {Type: "string", Description: "system, journal, syslog, or an absolute log path", Default: "system"},
		}, []string{"host"})},
		{Name: "meshclaw_security_check", Description: "Collect a read-only security snapshot: users, listeners, failed logins, sudoers, updates.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
		}, []string{"host"})},
		{Name: "meshclaw_guard_modes", Description: "List MeshClaw Guard modes: credential, posture, and vuln. Use this to understand the secret/posture/vulnerability safety layer.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_guard_model", Description: "Return the recommended optional local Guard Chat boundary for password/token conversations. MeshClaw core remains model-less.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_guard_clients", Description: "Return local and cloud AI client safety guidance for Guard Chat: memory, RAG, history, local stores, and when to use handles instead of raw secrets.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_guard_vault", Description: "Return the local-only vault conversation plan: handles, approval gates, model rules, and storage rules for password/token work.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_guard_vault_backends", Description: "List available local Guard vault storage backends: MeshClaw local AES-GCM, Apple Keychain, Ubuntu pass, 1Password, and Bitwarden.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_guard_vault_list", Description: "List local Guard vault handles and metadata. Raw secret values are never returned.", InputSchema: objectSchema(nil, nil)},
		{Name: "meshclaw_guard_vault_metadata", Description: "Return local Guard vault metadata for a handle. Raw secret values are never returned.", InputSchema: objectSchema(map[string]mcpProperty{
			"handle": {Type: "string", Description: "vault://meshclaw/<scope>/<name> handle"},
		}, []string{"handle"})},
		{Name: "meshclaw_guard_detect", Description: "Detect pasted credentials or sensitive tokens in text. Returns redacted evidence and replacement markers, never raw values.", InputSchema: objectSchema(map[string]mcpProperty{
			"target": {Type: "string", Description: "Source label, e.g. chat, openwebui, file path", Default: "input"},
			"text":   {Type: "string", Description: "Text to inspect before it reaches an AI model"},
		}, []string{"text"})},
		{Name: "meshclaw_guard_redact", Description: "Redact pasted credentials or sensitive tokens from text and store redacted evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"target": {Type: "string", Description: "Source label, e.g. chat, openwebui, file path", Default: "input"},
			"text":   {Type: "string", Description: "Text to redact before passing onward"},
		}, []string{"text"})},
		{Name: "meshclaw_guard_posture", Description: "Run read-only local posture checks for MeshClaw Guard state, evidence, and local-model chat stores.", InputSchema: objectSchema(map[string]mcpProperty{
			"home": {Type: "string", Description: "Optional home directory to inspect", Default: ""},
		}, nil)},
		{Name: "meshclaw_guard_clean_plan", Description: "Plan local cleanup for AI chat history, memory, and RAG stores. Read-only; deletion requires explicit future local approval.", InputSchema: objectSchema(map[string]mcpProperty{
			"home": {Type: "string", Description: "Optional home directory to inspect", Default: ""},
		}, nil)},
		{Name: "meshclaw_guard_vuln", Description: "Scan a local file or directory for redacted secret/code hygiene findings. Does not return raw values.", InputSchema: objectSchema(map[string]mcpProperty{
			"path": {Type: "string", Description: "Local file or directory path to scan"},
		}, []string{"path"})},
		{Name: "meshclaw_guard_intent", Description: "Classify a local Guard Chat message into safe structured intents such as vault_import, vault_list, vault_delete, guard_posture, or guard_vuln.", InputSchema: objectSchema(map[string]mcpProperty{
			"text": {Type: "string", Description: "Natural-language local Guard Chat message"},
		}, []string{"text"})},
		{Name: "meshclaw_hygiene_scan_host", Description: "Scan likely remote logs/config files for redacted secret and PII leak evidence.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
		}, []string{"host"})},
		{Name: "meshclaw_service_check", Description: "Collect read-only systemd status, unit config, and recent logs for a service.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":    {Type: "string", Description: "Inventory host name"},
			"service": {Type: "string", Description: "Systemd service name"},
		}, []string{"host", "service"})},
		{Name: "meshclaw_service_audit", Description: "Collect read-only failed/restarting systemd service evidence for a host.", InputSchema: objectSchema(map[string]mcpProperty{
			"host": {Type: "string", Description: "Inventory host name"},
		}, []string{"host"})},
		{Name: "meshclaw_service_quarantine", Description: "Disable a flapping service only when its ExecStart target is missing.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":    {Type: "string", Description: "Inventory host name"},
			"service": {Type: "string", Description: "Systemd service name"},
		}, []string{"host", "service"})},
		{Name: "meshclaw_service_remove", Description: "Stop/disable a local systemd service, remove its unit, and optionally remove its matching WorkingDirectory.", InputSchema: objectSchema(map[string]mcpProperty{
			"host":    {Type: "string", Description: "Inventory host name"},
			"service": {Type: "string", Description: "Systemd service name"},
			"path":    {Type: "string", Description: "Optional absolute WorkingDirectory to remove when it matches the unit"},
		}, []string{"host", "service"})},
	}
}

func objectSchema(properties map[string]mcpProperty, required []string) mcpInputSchema {
	if properties == nil {
		properties = map[string]mcpProperty{}
	}
	return mcpInputSchema{Type: "object", Properties: properties, Required: required}
}

type mcpEvidenceRef struct {
	ID       string    `json:"id,omitempty"`
	Kind     string    `json:"kind,omitempty"`
	Summary  string    `json:"summary,omitempty"`
	StoredAt string    `json:"stored_at,omitempty"`
	Time     time.Time `json:"time,omitempty"`
}

type mcpOpsControlResult struct {
	Kind             string               `json:"kind"`
	Decision         string               `json:"decision"`
	Summary          opsManagementSummary `json:"summary"`
	TopRisks         []string             `json:"top_risks"`
	NextActions      []string             `json:"next_actions"`
	RecommendedMCP   []recommendedMCPCall `json:"recommended_mcp"`
	ServiceItems     []mcpServiceItem     `json:"service_items,omitempty"`
	PolicyPosture    []opsPolicyPosture   `json:"policy_posture"`
	ApplySafe        bool                 `json:"apply_safe"`
	AppliedSafeCount int                  `json:"applied_safe_count"`
	Evidence         mcpEvidenceRef       `json:"evidence"`
	StoreError       string               `json:"store_error,omitempty"`
	FullReportHint   string               `json:"full_report_hint"`
}

type mcpServiceTriageResult struct {
	Kind            string               `json:"kind"`
	Decision        string               `json:"decision"`
	Counts          map[string]int       `json:"counts"`
	ServiceFindings int                  `json:"service_findings"`
	Items           []mcpServiceItem     `json:"items"`
	NextActions     []string             `json:"next_actions"`
	RecommendedMCP  []recommendedMCPCall `json:"recommended_mcp"`
	Evidence        mcpEvidenceRef       `json:"evidence"`
	StoreError      string               `json:"store_error,omitempty"`
	FullReportHint  string               `json:"full_report_hint"`
}

type mcpVSSHDaemonAuditResult struct {
	Kind           string                 `json:"kind"`
	Decision       string                 `json:"decision"`
	Summary        vsshDaemonAuditSummary `json:"summary"`
	Items          []vsshDaemonAuditItem  `json:"items"`
	Evidence       mcpEvidenceRef         `json:"evidence"`
	StoreError     string                 `json:"store_error,omitempty"`
	FullReportHint string                 `json:"full_report_hint"`
}

type mcpServiceItem struct {
	Host      string `json:"host"`
	Service   string `json:"service,omitempty"`
	Class     string `json:"class"`
	Mode      string `json:"mode"`
	Severity  string `json:"severity"`
	Judgement string `json:"judgement"`
	Next      string `json:"next"`
}

func slimOpsControlMCP(report opsControlReport, record evidence.Record, storeErr error) mcpOpsControlResult {
	decision := "healthy"
	if report.ManagementSummary.RealIncidents > 0 {
		decision = "investigate_real_incidents"
	} else if report.ManagementSummary.ApprovalRequired > 0 {
		decision = "approval_required"
	} else if report.ManagementSummary.ResourceAlerts > 0 || report.ManagementSummary.ServiceFindings > 0 {
		decision = "review_warnings"
	}
	return mcpOpsControlResult{
		Kind:             "ops_control_summary",
		Decision:         decision,
		Summary:          report.ManagementSummary,
		TopRisks:         limitStrings(report.TopRisks, 8),
		NextActions:      limitStrings(report.NextActions, 8),
		RecommendedMCP:   limitRecommendedMCPCalls(report.RecommendedMCP, 8),
		ServiceItems:     slimServiceItems(report.ServiceTriage.Items, 8),
		PolicyPosture:    report.PolicyPosture,
		ApplySafe:        report.ApplySafe,
		AppliedSafeCount: len(report.AppliedSafe),
		Evidence:         evidenceRef(record),
		StoreError:       errString(storeErr),
		FullReportHint:   "Full monitor, service audit, triage evidence, and raw command output are stored in the evidence file.",
	}
}

func slimServiceTriageMCP(report serviceTriageReport, record evidence.Record, storeErr error) mcpServiceTriageResult {
	decision := "no_service_findings"
	if report.Counts["real_incident"] > 0 {
		decision = "investigate_real_incidents"
	} else if report.Counts["approval_required"] > 0 {
		decision = "approval_required"
	} else if len(report.Items) > 0 {
		decision = "monitor_or_ignore_candidates"
	}
	next := make([]string, 0, len(report.Items))
	for _, item := range report.Items {
		if item.Next != "" {
			next = append(next, item.Next)
		}
	}
	return mcpServiceTriageResult{
		Kind:            "service_triage_summary",
		Decision:        decision,
		Counts:          report.Counts,
		ServiceFindings: report.ServiceFindings,
		Items:           slimServiceItems(report.Items, 10),
		NextActions:     limitStrings(uniqueStrings(next), 10),
		RecommendedMCP:  limitRecommendedMCPCalls(report.RecommendedMCP, 8),
		Evidence:        evidenceRef(record),
		StoreError:      errString(storeErr),
		FullReportHint:  "Full service-check evidence and raw systemd output are stored in the evidence file.",
	}
}

func slimVSSHDaemonAuditMCP(report vsshDaemonAuditReport) mcpVSSHDaemonAuditResult {
	decision := "ready"
	if report.Summary.AuthFailed > 0 {
		decision = "fix_auth"
	} else if report.Summary.UpgradeRequired > 0 {
		decision = "upgrade_daemons"
	} else if report.Summary.Unreachable > 0 {
		decision = "check_network"
	} else if report.Summary.Failed > 0 {
		decision = "investigate_daemons"
	}
	return mcpVSSHDaemonAuditResult{
		Kind:           "vssh_daemon_audit_summary",
		Decision:       decision,
		Summary:        report.Summary,
		Items:          report.Items,
		Evidence:       evidenceRef(report.Evidence),
		StoreError:     report.StoreErr,
		FullReportHint: "Full vssh daemon audit payload is stored in the evidence file.",
	}
}

func slimWorkflowMCP(result runtimeflow.Result, decision policy.Result) map[string]interface{} {
	failed := []map[string]interface{}{}
	for _, step := range result.Steps {
		if step.Success {
			continue
		}
		failed = append(failed, map[string]interface{}{
			"step":      step.Step,
			"title":     step.Title,
			"node":      step.Node,
			"transport": step.Transport,
			"retryable": step.Retryable,
			"error":     step.Error,
			"stderr":    truncate(step.Stderr, 1200),
		})
	}
	return map[string]interface{}{
		"kind":              "meshclaw_runtime_workflow_result",
		"success":           result.Success,
		"workflow":          result.Workflow,
		"mode":              result.Mode,
		"generated_at":      result.GeneratedAt,
		"summary":           result.Summary,
		"policy":            decision,
		"bundle_dir":        result.BundleDir,
		"plan_path":         result.PlanPath,
		"execution_path":    result.ExecutionPath,
		"steps_path":        result.StepsPath,
		"actions_path":      result.ActionsPath,
		"capabilities_path": result.CapabilitiesPath,
		"capability_count":  len(result.Capabilities),
		"report_path":       result.ReportPath,
		"failed":            failed,
		"next":              "Read execution_path or call meshclaw_evidence_latest for the action log preview.",
	}
}

func latestRuntimeEvidenceMCP(previewBytes int) (map[string]interface{}, error) {
	if previewBytes <= 0 {
		previewBytes = 4000
	}
	if previewBytes > 20000 {
		previewBytes = 20000
	}
	bundle, err := runtimeflow.LatestBundle()
	if err != nil {
		return nil, err
	}
	executionPath := filepath.Join(bundle, "execution.json")
	actionsPath := filepath.Join(bundle, "meshclaw-actions.md")
	reportPath := filepath.Join(bundle, "report.html")
	planPath := filepath.Join(bundle, "plan.md")
	stepsPath := filepath.Join(bundle, "steps.jsonl")
	capabilitiesPath := filepath.Join(bundle, "capabilities.json")

	var parsedSummary struct {
		Success     bool                `json:"success"`
		Workflow    string              `json:"workflow"`
		Mode        runtimeflow.Mode    `json:"mode"`
		GeneratedAt time.Time           `json:"generated_at"`
		Summary     runtimeflow.Summary `json:"summary"`
	}
	var summary interface{}
	if data, err := os.ReadFile(executionPath); err == nil {
		if json.Unmarshal(data, &parsedSummary) == nil {
			summary = parsedSummary
		}
	}
	preview := ""
	if data, err := os.ReadFile(actionsPath); err == nil {
		preview = string(data)
		if len(preview) > previewBytes {
			preview = preview[:previewBytes] + "\n..."
		}
	}
	return map[string]interface{}{
		"kind":              "meshclaw_runtime_latest_evidence",
		"success":           parsedSummary.Success,
		"workflow":          parsedSummary.Workflow,
		"mode":              parsedSummary.Mode,
		"generated_at":      parsedSummary.GeneratedAt,
		"status_summary":    parsedSummary.Summary,
		"bundle_dir":        bundle,
		"plan_path":         planPath,
		"execution_path":    executionPath,
		"steps_path":        stepsPath,
		"actions_path":      actionsPath,
		"capabilities_path": capabilitiesPath,
		"report_path":       reportPath,
		"summary":           summary,
		"actions_preview":   actionsPreviewOrHint(preview, actionsPath),
	}, nil
}

func actionsPreviewOrHint(preview, path string) string {
	if preview != "" {
		return preview
	}
	return "No meshclaw-actions.md preview available at " + path
}

func recommendToolMCP(intent, subject string) map[string]interface{} {
	normalized := strings.ToLower(strings.TrimSpace(intent))
	if strings.TrimSpace(subject) == "" {
		subject = "codex"
	}
	rec := map[string]interface{}{
		"kind":       "meshclaw_tool_recommendation",
		"intent":     intent,
		"subject":    subject,
		"layer_rule": "Use MeshClaw for policy/state/evidence/workflows. Use direct vssh only for low-level structured transport primitives or debugging.",
	}
	set := func(tool, reason string, arguments map[string]interface{}, alternatives []string, avoid []string, approval bool) map[string]interface{} {
		rec["recommended_tool"] = tool
		rec["reason"] = reason
		rec["arguments"] = arguments
		rec["alternatives"] = alternatives
		rec["avoid"] = avoid
		rec["approval_expected"] = approval
		return rec
	}

	switch {
	case normalized == "":
		return set("meshclaw_ai_guide", "No intent was supplied; ask for the canonical guide first.", map[string]interface{}{}, nil, nil, false)
	case containsAny(normalized, "inventory override", "role override", "tag override", "mail-server", "automation-worker", "ollama-worker", "is mail-server", "is automation-worker", "is ollama-worker", "set role", "set tag", "node role", "node tag", "노드 역할", "역할 등록", "역할 수정", "역할로", "태그 등록", "태그 수정", "메일서버로", "자동화 노드", "자동화 서버"):
		return set("meshclaw_inventory_override_set", "User is clarifying private fleet meaning. Persist it as an operator-owned inventory override before capability selection.", map[string]interface{}{"node": "<node>", "role": "<role>", "tags": "<comma-separated-tags>"}, []string{"meshclaw_inventory_override_list", "meshclaw_capability_recommend"}, []string{"hardcoding private node meaning in source", "choosing placement from memory"}, false)
	case containsAny(normalized, "which node", "which model", "which api", "which capability", "where should", "where to run", "placement", "choose node", "choose model", "choose api", "capability", "어느 노드", "어떤 노드", "어디서", "어디에", "어떤 모델", "무슨 모델", "어떤 api", "배치", "추천해"):
		return set("meshclaw_capability_recommend", "The user is asking for placement or capability selection. Score capabilities before running a workflow or raw command.", map[string]interface{}{"intent": intent}, []string{"meshclaw_server_list", "meshclaw_inventory_override_list", "meshclaw_placement_plan"}, []string{"guessing from hostname alone", "using stale chat history as placement state"}, false)
	case containsAny(normalized, "combined", "mail and ollama", "email and ollama", "mail ops", "ops orchestration", "policy and evidence", "통합", "메일", "올라마", "오케스트레이션"):
		return set("meshclaw_workflow_run", "Combined mail/model/server orchestration should use the product workflow so inventory, policy gates, vssh execution, failure capture, and evidence are recorded together.", map[string]interface{}{"name": "meshclaw-ops-orchestration-demo", "mode": "dry-run"}, []string{"meshclaw_workflow_inspect", "meshclaw_evidence_latest"}, []string{"manual replay from chat history", "raw SSH/vssh as the top-level orchestrator"}, false)
	case containsAny(normalized, "workflow", "run demo", "demo", "재현", "데모", "워크플로", "반복 실행"):
		return set("meshclaw_workflow_run", "Multi-step repeatable operations should be run as MeshClaw workflows so plan, policy, steps, and evidence are captured.", map[string]interface{}{"name": "meshclaw-ops-orchestration-demo", "mode": "dry-run"}, []string{"meshclaw_workflow_list", "meshclaw_evidence_latest"}, []string{"manual replay from chat history"}, false)
	case containsAny(normalized, "what should i use", "which tool", "어떤 도구", "뭘 써", "권장", "가이드", "meshclaw vs vssh"):
		return set("meshclaw_ai_guide", "The user is asking which layer/tool to use.", map[string]interface{}{}, []string{"meshclaw_tool_recommend"}, nil, false)
	case containsAny(normalized, "cleanup", "delete", "remove", "checkpoint", "중복", "삭제", "정리", "지워", "지우", "클린"):
		return set("meshclaw_data_clean_plan", "Cleanup should start with a plan that preserves clean/final outputs and marks risky deletions.", map[string]interface{}{"host": "<host>", "path": "<absolute-path>"}, []string{"meshclaw_disk_investigate", "meshclaw_data_clean_apply"}, []string{"direct rm", "manual deletion without manifest"}, true)
	case containsAny(normalized, "server management", "ops control", "전체 상태", "서버 관리", "서버관리", "상태 관리", "조치", "조치 후보", "복구 후보"):
		return set("meshclaw_ops_control", "Broad server management needs MeshClaw's combined health, service triage, policy, autoheal, and evidence summary.", map[string]interface{}{"apply_safe": false}, []string{"meshclaw_ops_brief", "meshclaw_monitor_check"}, []string{"raw vssh facts-many as first choice"}, false)
	case containsAny(normalized, "service", "systemd", "failed", "restarting", "서비스", "장애", "실패", "죽는", "죽어", "죽음"):
		return set("meshclaw_service_triage", "Service incidents should be triaged first to separate real incidents from stale boot-only noise.", map[string]interface{}{"limit": 5, "max_parallel": 4}, []string{"meshclaw_service_check", "meshclaw_fleet_service_audit", "meshclaw_analyze_logs"}, []string{"direct systemctl restart before evidence"}, false)
	case containsAny(normalized, "log", "journal", "로그"):
		return set("meshclaw_analyze_logs", "Log investigation should store warning/error evidence with redaction and next actions.", map[string]interface{}{"host": "<host>", "source": "system"}, []string{"meshclaw_service_check", "meshclaw_security_check"}, []string{"raw SSH log scraping without evidence"}, false)
	case containsAny(normalized, "security", "보안", "secret", "pii", "개인정보", "민감정보", "시크릿"):
		return set("meshclaw_security_check", "Security and sensitive-data work should use MeshClaw read-only checks and redacted hygiene scans.", map[string]interface{}{"host": "<host>"}, []string{"meshclaw_hygiene_scan_host", "meshclaw_fleet_scan"}, []string{"cat secret files", "copy raw credentials into chat"}, false)
	case containsAny(normalized, "fleet", "health", "status", "monitor", "서버 상태", "상태", "모니터", "디스크", "메모리", "gpu", "cpu"):
		return set("meshclaw_monitor_check", "Fleet status should use MeshClaw monitoring/facts aggregation rather than raw transport output.", map[string]interface{}{}, []string{"meshclaw_ops_brief", "meshclaw_ops_control"}, []string{"raw vssh facts-many as first choice"}, false)
	case containsAny(normalized, "disk", "du", "df", "storage", "용량", "디스크", "저장공간"):
		return set("meshclaw_disk_investigate", "Disk investigation needs read-only evidence before any cleanup plan.", map[string]interface{}{"host": "<host>", "path": "/"}, []string{"meshclaw_data_clean_plan", "meshclaw_process_top"}, []string{"rm before data_clean_plan"}, false)
	case containsAny(normalized, "run command", "diagnostic command", "명령", "실행", "uptime", "df -h"):
		return set("meshclaw_run_evidence", "Single diagnostic commands should go through MeshClaw for policy, fallback, and evidence.", map[string]interface{}{"host": "<host>", "command": "<command>"}, []string{"direct vssh for transport debugging only"}, []string{"raw SSH when audit trail is needed"}, false)
	case containsAny(normalized, "vssh auth", "vsshd", "vssh daemon", "auth failed", "인증", "데몬"):
		return set("meshclaw_vssh_daemon_audit", "vssh execution health should be diagnosed through MeshClaw's daemon/auth/version classifiers.", map[string]interface{}{"hosts": ""}, []string{"meshclaw_vssh_auth_paths", "meshclaw_node_repair_plan"}, []string{"rotating secrets before audit"}, false)
	case containsAny(normalized, "vssh direct", "direct vssh", "ssh 말고", "그냥 ssh", "vssh를 직접", "vssh 직접", "직접 써", "exec many", "facts many", "rpc", "parallel exec", "transport", "병렬 실행", "전송"):
		return set("direct vssh MCP", "Direct vssh is appropriate for low-level transport primitives, parallel exec, typed facts, daemon RPC, or debugging MeshClaw adapters.", map[string]interface{}{"note": "Use vssh tools directly only when policy/evidence/workflow semantics are not required."}, []string{"meshclaw_run_evidence", "meshclaw_vssh_auth_paths"}, []string{"direct vssh for mutating ops without evidence"}, false)
	case containsAny(normalized, "rent", "vps", "provision", "server capacity", "서버 임대", "임대", "프로비전"):
		return set("meshclaw_provision_plan", "Provider/cost-changing work must start as a plan; real create/delete needs approval.", map[string]interface{}{"purpose": intent, "budget_usd": 0, "ttl_hours": 6}, []string{"meshclaw_placement_plan"}, []string{"provider create without policy approval"}, true)
	default:
		return set("meshclaw_ops_control", "Default to MeshClaw's server-management control report when the intent is ambiguous.", map[string]interface{}{"apply_safe": false}, []string{"meshclaw_ai_guide", "meshclaw_ops_dispatch"}, []string{"guessing raw vssh/SSH commands"}, false)
	}
}

func mcpSurfaceGuide() map[string]interface{} {
	return map[string]interface{}{
		"kind": "meshclaw_mcp_surface",
		"default_path": []map[string]interface{}{
			{"step": 1, "tool": "meshclaw_ai_guide", "when": "first contact or when the model is unsure which layer to use"},
			{"step": 2, "tool": "meshclaw_quickstart", "when": "first 5 minutes path: setup check, workflow inspection, dry-run evidence"},
			{"step": 3, "tool": "meshclaw_doctor", "when": "verify local MeshClaw/VSSH/MCP setup before blaming the fleet"},
			{"step": 4, "tool": "meshclaw_server_list", "when": "read current inventory truth before choosing nodes"},
			{"step": 5, "tool": "meshclaw_inventory_override_list", "when": "check operator-owned role/tag refinements"},
			{"step": 6, "tool": "meshclaw_inventory_override_set", "when": "the user clarifies private fleet meaning, such as c1 is mail-server"},
			{"step": 7, "tool": "meshclaw_capability_validate", "when": "before placement, model/API selection, or execute mode"},
			{"step": 8, "tool": "meshclaw_capability_recommend", "when": "choose a node/model/API/storage/provisioner capability for the intent"},
			{"step": 9, "tool": "meshclaw_workflow_list", "when": "discover repeatable workflows"},
			{"step": 10, "tool": "meshclaw_workflow_validate", "when": "before running user-authored or example workflow files"},
			{"step": 11, "tool": "meshclaw_workflow_run", "when": "run dry-run first; execute only after approval gates are resolved"},
			{"step": 12, "tool": "meshclaw_evidence_latest", "when": "read evidence bundle paths and AI handoff after a run"},
			{"step": 13, "tool": "meshclaw_workflow_plan_execute", "when": "check if the latest evidence bundle is ready for execute mode"},
			{"step": 14, "tool": "meshclaw_workflow_resume", "when": "continue from failed, approval-pending, retryable, or targeted steps"},
		},
		"canonical_loop": []string{
			"inventory",
			"operator overrides",
			"capability validation",
			"capability recommendation",
			"workflow dry-run",
			"evidence review",
			"approval or repair",
			"targeted execute/resume",
		},
		"default_tools": []string{
			"meshclaw_ai_guide",
			"meshclaw_quickstart",
			"meshclaw_doctor",
			"meshclaw_mcp_surface",
			"meshclaw_tool_recommend",
			"meshclaw_workflow_list",
			"meshclaw_workflow_scaffold",
			"meshclaw_workflow_validate",
			"meshclaw_workflow_inspect",
			"meshclaw_workflow_run",
			"meshclaw_workflow_plan_execute",
			"meshclaw_workflow_resume",
			"meshclaw_evidence_latest",
			"meshclaw_server_list",
			"meshclaw_inventory_override_list",
			"meshclaw_capability_list",
			"meshclaw_capability_validate",
			"meshclaw_capability_recommend",
			"meshclaw_monitor_check",
			"meshclaw_ops_control",
			"meshclaw_policy_check",
			"meshclaw_guard_detect",
			"meshclaw_guard_redact",
			"meshclaw_guard_vault_list",
			"meshclaw_guard_vault_metadata",
		},
		"advanced_tools": []string{
			"meshclaw_fleet_scan",
			"meshclaw_fleet_service_audit",
			"meshclaw_service_triage",
			"meshclaw_service_check",
			"meshclaw_vssh_daemon_audit",
			"meshclaw_vssh_auth_paths",
			"meshclaw_node_repair_plan",
			"meshclaw_inventory_override_set",
			"meshclaw_inventory_override_remove",
			"meshclaw_run_evidence",
			"meshclaw_job_start",
			"meshclaw_job_status",
			"meshclaw_job_logs",
			"meshclaw_artifact_collect",
			"meshclaw_disk_investigate",
			"meshclaw_data_clean_plan",
			"meshclaw_provision_plan",
			"meshclaw_hygiene_scan_host",
			"meshclaw_security_check",
		},
		"use_direct_vssh_when": []string{
			"debugging low-level transport, daemon RPC, or routing",
			"running typed facts/exec primitives where MeshClaw policy, workflow, and evidence are not required",
			"building or testing the vssh substrate itself",
		},
		"avoid": []string{
			"using raw SSH/vssh as the top-level orchestrator when policy or evidence is needed",
			"asking the model to parse long terminal prose when MeshClaw returns typed JSON",
			"pasting raw secrets into Codex, Claude, Cursor, or workflow evidence",
		},
	}
}

func evidenceRef(record evidence.Record) mcpEvidenceRef {
	return mcpEvidenceRef{
		ID:       record.ID,
		Kind:     record.Kind,
		Summary:  record.Summary,
		StoredAt: record.StoredAt,
		Time:     record.Time,
	}
}

func slimServiceItems(items []serviceTriageItem, limit int) []mcpServiceItem {
	if len(items) <= limit {
		limit = len(items)
	}
	out := make([]mcpServiceItem, 0, limit)
	for _, item := range items[:limit] {
		out = append(out, mcpServiceItem{
			Host:      item.Host,
			Service:   item.Service,
			Class:     item.Class,
			Mode:      item.Mode,
			Severity:  item.Severity,
			Judgement: item.Judgement,
			Next:      item.Next,
		})
	}
	return out
}

func callMCPTool(name string, args map[string]interface{}) (interface{}, error) {
	switch name {
	case "meshclaw_ai_guide":
		return map[string]interface{}{
			"role_split": map[string]interface{}{
				"meshclaw": []string{"policy", "state", "capability registry", "workflow runner", "evidence", "approval boundaries"},
				"vssh":     []string{"low-level structured remote execution", "parallel exec", "typed facts", "daemon RPC", "transport debugging"},
			},
			"mcp_surface": mcpSurfaceGuide(),
			"guidance":    aiGuideEntries(),
		}, nil
	case "meshclaw_quickstart":
		return buildQuickstartReport()
	case "meshclaw_doctor":
		return doctor.Self(), nil
	case "meshclaw_mcp_surface":
		return mcpSurfaceGuide(), nil
	case "meshclaw_tool_recommend":
		return recommendToolMCP(stringArg(args, "intent"), stringArg(args, "subject")), nil
	case "meshclaw_server_list":
		return inventory.DefaultNodes(), nil
	case "meshclaw_inventory_discover":
		return inventory.Discover()
	case "meshclaw_inventory_diff":
		return inventory.ComputeDiff()
	case "meshclaw_inventory_override_list":
		nodes, err := inventory.LoadOverrides()
		if err != nil {
			if os.IsNotExist(err) {
				nodes = []inventory.Node{}
			} else {
				return nil, err
			}
		}
		return map[string]interface{}{"path": inventory.OverridesPath(), "nodes": nodes}, nil
	case "meshclaw_inventory_override_set":
		node := inventory.Node{
			Name:     stringArg(args, "node"),
			Role:     stringArg(args, "role"),
			Location: stringArg(args, "location"),
			User:     stringArg(args, "user"),
			Tags:     splitCSV(stringArg(args, "tags")),
		}
		nodes, err := inventory.SetOverride(node)
		if err != nil {
			return nil, err
		}
		record, storeErr := evidence.Store("inventory-override-set", node.Name, strings.Join(node.Tags, ","), map[string]interface{}{"path": inventory.OverridesPath(), "nodes": nodes})
		return map[string]interface{}{"path": inventory.OverridesPath(), "nodes": nodes, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw_inventory_override_remove":
		node := stringArg(args, "node")
		nodes, removed, err := inventory.RemoveOverride(node)
		if err != nil {
			return nil, err
		}
		record, storeErr := evidence.Store("inventory-override-remove", node, fmt.Sprintf("removed=%t", removed), map[string]interface{}{"path": inventory.OverridesPath(), "removed": removed, "nodes": nodes})
		return map[string]interface{}{"path": inventory.OverridesPath(), "removed": removed, "nodes": nodes, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw_workers":
		return workers.DefaultWorkers(), nil
	case "meshclaw_workspace_list":
		list, path, err := workspace.List()
		if err != nil {
			return nil, err
		}
		return map[string]interface{}{"path": path, "workspaces": list}, nil
	case "meshclaw_workspace_add":
		ws := workspace.Workspace{
			ID:      stringArg(args, "id"),
			Host:    stringArg(args, "host"),
			Path:    stringArg(args, "path"),
			Owner:   stringArg(args, "owner"),
			Purpose: stringArg(args, "purpose"),
			Branch:  stringArg(args, "branch"),
			Source:  stringArg(args, "source"),
		}
		saved, path, err := workspace.Upsert(ws)
		if err != nil {
			return nil, err
		}
		return map[string]interface{}{"path": path, "workspace": saved}, nil
	case "meshclaw_workspace_activity":
		record, err := workspace.RecordActivity(workspace.Activity{
			WorkspaceID: stringArg(args, "id"),
			Actor:       stringArg(args, "actor"),
			Action:      stringArg(args, "action"),
			Summary:     stringArg(args, "summary"),
			Evidence:    stringArg(args, "evidence"),
		})
		return map[string]interface{}{"evidence": record}, err
	case "meshclaw_capability_list":
		return map[string]interface{}{"path": capability.Path(), "capabilities": capability.List()}, nil
	case "meshclaw_capability_validate":
		return capability.Validate(stringArg(args, "path")), nil
	case "meshclaw_capability_recommend":
		return capability.Recommend(stringArg(args, "intent")), nil
	case "meshclaw_adapter_list":
		return map[string]interface{}{"adapters": runtimeflow.AdapterRegistry()}, nil
	case "meshclaw_monitor_check":
		m, err := monitor.New(monitor.DefaultConfig())
		if err != nil {
			return nil, err
		}
		states := m.CheckAll()
		return monitorCheckOutput{States: states, Alerts: m.DetectAlerts()}, nil
	case "meshclaw_ops_brief":
		report, record, storeErr, briefErr := buildOpsBrief()
		if briefErr != nil {
			return nil, briefErr
		}
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw_ops_control":
		report, record, storeErr, controlErr := buildOpsControl(boolArg(args, "apply_safe", false))
		if controlErr != nil {
			return nil, controlErr
		}
		return slimOpsControlMCP(report, record, storeErr), nil
	case "meshclaw_node_inventory":
		host := stringArg(args, "host")
		report := workflow.SoftwareInventory(host)
		record, err := evidence.Store("node-inventory", host, report.Status, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_fleet_inventory":
		report, record, storeErr := runFleetInventory(splitCSV(stringArg(args, "hosts")), intArg(args, "max_parallel", 4))
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw_placement_plan":
		report, record, storeErr, planErr := buildPlacementPlan(stringArg(args, "workload"))
		if planErr != nil {
			return nil, planErr
		}
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw_orchestration_plan":
		scenario := stringArg(args, "scenario")
		report := buildOrchestrationPlan(scenario)
		record, storeErr := evidence.Store("orchestration-plan", "workflow", scenario, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw_fleet_scan":
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "fleet_scan", Resource: "server"})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		opts := fleet.Options{
			Hosts:       splitCSV(stringArg(args, "hosts")),
			Security:    boolArg(args, "security", true),
			Hygiene:     boolArg(args, "hygiene", true),
			Logs:        boolArg(args, "logs", true),
			MaxParallel: intArg(args, "max_parallel", 3),
		}
		report, scanErr := fleet.Scan(opts)
		if scanErr != nil {
			return nil, scanErr
		}
		runtimeReport := buildFleetScanRuntimeReport(report)
		record, storeErr := evidence.Store("fleet-scan", "fleet", fleetScanSummary(report), runtimeReport)
		return map[string]interface{}{"policy": decision, "report": report, "recommended_mcp": runtimeReport.RecommendedMCP, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw_fleet_service_audit":
		report, record, storeErr := runFleetServiceAudit(splitCSV(stringArg(args, "hosts")), intArg(args, "max_parallel", 4))
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw_vssh_daemon_audit":
		report, storeErr, auditErr := buildVSSHDaemonAudit(splitCSV(stringArg(args, "hosts")))
		if auditErr != nil {
			return nil, auditErr
		}
		report.StoreErr = errString(storeErr)
		return slimVSSHDaemonAuditMCP(report), nil
	case "meshclaw_vssh_auth_paths":
		return buildVSSHAuthPaths(splitCSV(stringArg(args, "hosts"))), nil
	case "meshclaw_node_repair_plan":
		report, storeErr, planErr := buildNodeRepairPlan(splitCSV(stringArg(args, "hosts")))
		if planErr != nil {
			return nil, planErr
		}
		report.StoreErr = errString(storeErr)
		return report, nil
	case "meshclaw_service_triage":
		report, record, storeErr := buildServiceTriage(splitCSV(stringArg(args, "hosts")), intArg(args, "limit", 5), intArg(args, "max_parallel", 4))
		return slimServiceTriageMCP(report, record, storeErr), nil
	case "meshclaw_autoheal_plan":
		m, err := monitor.New(monitor.DefaultConfig())
		if err != nil {
			return nil, err
		}
		m.CheckAll()
		serviceTriage, _, serviceStoreErr := buildServiceTriage(nil, 5, 4)
		actions := buildAutohealPlan(m, serviceTriage)
		report := buildAutohealPlanReport(actions)
		record, storeErr := evidence.Store("autoheal-plan", "fleet", fmt.Sprintf("actions=%d", len(actions)), report)
		if storeErr == nil {
			storeErr = serviceStoreErr
		}
		return map[string]interface{}{"actions": actions, "recommended_mcp": report.RecommendedMCP, "report": report, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw_autoheal_apply_safe":
		m, err := monitor.New(monitor.DefaultConfig())
		if err != nil {
			return nil, err
		}
		m.CheckAll()
		serviceTriage, _, serviceStoreErr := buildServiceTriage(nil, 5, 4)
		plan := buildAutohealPlan(m, serviceTriage)
		actions := applyAutohealPlanSafe(plan)
		record, storeErr := evidence.Store("autoheal-apply-safe", "fleet", fmt.Sprintf("actions=%d", len(actions)), actions)
		if storeErr == nil {
			storeErr = serviceStoreErr
		}
		return map[string]interface{}{"actions": actions, "evidence": record, "store_error": errString(storeErr)}, nil
	case "meshclaw_workflow_list":
		return map[string]interface{}{
			"workflows":            runtimeflow.WorkflowInfos(),
			"default_workflow":     "fleet-health-demo",
			"default_example":      "examples/workflows/fleet-health.json",
			"advanced_workflow":    "meshclaw-ops-orchestration-demo",
			"run_tool":             "meshclaw_workflow_run",
			"scaffold_tool":        "meshclaw_workflow_scaffold",
			"validate_tool":        "meshclaw_workflow_validate",
			"inspect_tool":         "meshclaw_workflow_inspect",
			"plan_execute_tool":    "meshclaw_workflow_plan_execute",
			"evidence_tool":        "meshclaw_evidence_latest",
			"recommended_start":    []map[string]interface{}{{"tool": "meshclaw_workflow_validate", "arguments": map[string]interface{}{"name": "fleet-health-demo"}}, {"tool": "meshclaw_workflow_run", "arguments": map[string]interface{}{"name": "fleet-health-demo", "mode": "dry-run"}}},
			"new_workflow_start":   map[string]interface{}{"tool": "meshclaw_workflow_scaffold", "arguments": map[string]interface{}{"name": "my-ops-workflow"}},
			"advanced_private_run": map[string]interface{}{"tool": "meshclaw_workflow_run", "arguments": map[string]interface{}{"name": "meshclaw-ops-orchestration-demo", "mode": "dry-run"}},
			"guidance":             "For user-authored workflows, call meshclaw_workflow_validate first, then meshclaw_workflow_run with mode=dry-run, then execute only after approval gates are resolved.",
			"guidance_ko":          "사용자 workflow는 먼저 meshclaw_workflow_validate, 그 다음 dry-run, 승인 게이트 확인 후 execute 순서로 실행하세요.",
		}, nil
	case "meshclaw_workflow_scaffold":
		mcpArgs := []string{stringArg(args, "name")}
		if output := stringArg(args, "output"); output != "" {
			mcpArgs = append(mcpArgs, "--output", output)
		}
		if boolArg(args, "force", false) {
			mcpArgs = append(mcpArgs, "--force")
		}
		return scaffoldWorkflow(mcpArgs, true)
	case "meshclaw_workflow_validate":
		return runtimeflow.Validate(stringArg(args, "name"))
	case "meshclaw_workflow_inspect":
		name := stringArg(args, "name")
		if !runtimeflow.IsKnown(name) {
			return nil, fmt.Errorf("unknown workflow: %s", name)
		}
		return runtimeflow.Inspect(name)
	case "meshclaw_workflow_resume":
		ref := stringArg(args, "ref")
		if ref == "" {
			ref = "latest"
		}
		return runtimeflow.Resume(ref)
	case "meshclaw_workflow_plan_execute":
		ref := stringArg(args, "ref")
		if ref == "" {
			ref = "latest"
		}
		return runtimeflow.PlanExecute(ref)
	case "meshclaw_approvals_list":
		ref := stringArg(args, "ref")
		if ref == "" {
			ref = "latest"
		}
		records, err := runtimeflow.ListApprovals(ref)
		return map[string]interface{}{"approvals": records}, err
	case "meshclaw_approvals_grant":
		ref := stringArg(args, "ref")
		if ref == "" {
			ref = "latest"
		}
		source := stringArg(args, "source")
		if source == "" {
			source = "mcp"
		}
		record, err := runtimeflow.GrantApproval(ref, stringArg(args, "step"), stringArg(args, "actor"), stringArg(args, "reason"), source)
		if err != nil {
			return nil, err
		}
		return map[string]interface{}{
			"kind":    "meshclaw_approval_granted",
			"record":  record,
			"next":    "Run meshclaw_workflow_resume to confirm the step is approved_ready, then run meshclaw_workflow_run with mode=execute and approvals_ref=latest.",
			"execute": map[string]interface{}{"tool": "meshclaw_workflow_run", "arguments": map[string]interface{}{"name": record.Workflow, "mode": string(runtimeflow.Execute), "approvals_ref": "latest", "steps": record.Step}},
		}, nil
	case "meshclaw_workflow_run":
		name := stringArg(args, "name")
		mode := runtimeflow.Mode(stringArg(args, "mode"))
		if mode == "" {
			mode = runtimeflow.DryRun
		}
		if mode != runtimeflow.DryRun && mode != runtimeflow.Execute {
			return nil, fmt.Errorf("mode must be dry-run or execute")
		}
		if !runtimeflow.IsKnown(name) {
			return nil, fmt.Errorf("unknown workflow: %s", name)
		}
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "workflow_run", Resource: "workflow", Context: name + " " + string(mode)})
		if decision.Decision == policy.Deny {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		result, err := runtimeflow.RunSelectedWithApprovals(name, mode, stringArg(args, "approvals_ref"), []string{stringArg(args, "steps")})
		if err != nil {
			return nil, err
		}
		return slimWorkflowMCP(result, decision), nil
	case "meshclaw_evidence_latest":
		return latestRuntimeEvidenceMCP(intArg(args, "actions_preview_bytes", 4000))
	case "meshclaw_evidence_list":
		return evidence.List(intArg(args, "limit", 20))
	case "meshclaw_policy_check":
		return policy.Evaluate(policy.Request{
			Subject:  stringArg(args, "subject"),
			Action:   stringArg(args, "action"),
			Resource: stringArg(args, "resource"),
			Context:  stringArg(args, "context"),
		}), nil
	case "meshclaw_policy_show":
		cfg, path, err := policy.LoadConfig()
		if err != nil {
			return nil, err
		}
		return map[string]interface{}{"path": path, "policy": cfg}, nil
	case "meshclaw_matrix_plan":
		return map[string]interface{}{
			"role": "Matrix is an operations room, approval channel, notification channel, and optional MCP command surface. It is not the assistant brain.",
			"flow": []string{
				"human or AI operator posts an ops request in Matrix",
				"Matrix bridge normalizes the request into a MeshClaw MCP/CLI tool call",
				"MeshClaw policy decides allow, require_approval, or deny",
				"MeshClaw executes only allowed tools through vssh/runtime",
				"Matrix bridge posts concise results and evidence links back to the room",
			},
		}, nil
	case "meshclaw_ops_dispatch":
		return dispatchOpsMessage(stringArg(args, "source"), stringArg(args, "message"))
	case "meshclaw_provision_plan":
		req := provision.Request{
			Purpose:       stringArg(args, "purpose"),
			Provider:      stringArg(args, "provider"),
			Region:        stringArg(args, "region"),
			BudgetUSD:     floatArg(args, "budget_usd", 0),
			TTLHours:      intArg(args, "ttl_hours", 6),
			RequiredClass: stringArg(args, "required_class"),
		}
		plan := provision.NewPlan(req)
		record, err := evidence.Store("provision-plan", "provider", req.Purpose, plan)
		return map[string]interface{}{"plan": plan, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_run_evidence":
		host := stringArg(args, "host")
		command := stringArg(args, "command")
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "run_command", Resource: "server", Context: command})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		result := runtime.NewRunner().RunEvidence(host, command)
		record, err := evidence.Store("run-evidence", host, command, result)
		return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_job_start":
		host := stringArg(args, "host")
		command := stringArg(args, "command")
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "run_command", Resource: "server", Context: command})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		result, runErr := runtime.NewRunner().VSSHJSON("job-start", host, command)
		record, storeErr := evidence.Store("job-start", host, command, result)
		return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(storeErr), "run_error": errString(runErr)}, nil
	case "meshclaw_job_status":
		return mcpVSSHJobRead("job-status", "job_status", args)
	case "meshclaw_job_logs":
		host := stringArg(args, "host")
		id := stringArg(args, "id")
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "job_logs", Resource: "server", Context: id})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		params := []string{"job-logs", host, id}
		if tail := intArg(args, "tail_bytes", 0); tail > 0 {
			params = append(params, fmt.Sprintf("%d", tail))
		}
		result, runErr := runtime.NewRunner().VSSHJSON(params...)
		record, storeErr := evidence.Store("job-logs", host, id, result)
		return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(storeErr), "run_error": errString(runErr)}, nil
	case "meshclaw_job_cancel":
		host := stringArg(args, "host")
		id := stringArg(args, "id")
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "job_cancel", Resource: "server", Context: id})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		result, runErr := runtime.NewRunner().VSSHJSON("job-cancel", host, id)
		record, storeErr := evidence.Store("job-cancel", host, id, result)
		return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(storeErr), "run_error": errString(runErr)}, nil
	case "meshclaw_artifact_collect":
		host := stringArg(args, "host")
		path := stringArg(args, "path")
		decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: "artifact_collect", Resource: "server", Context: path})
		if decision.Decision != policy.Allow {
			return map[string]interface{}{"policy": decision, "success": false}, nil
		}
		params := []string{"artifact-collect", host, path}
		if maxBytes := intArg(args, "max_bytes", 0); maxBytes > 0 {
			params = append(params, fmt.Sprintf("%d", maxBytes))
		}
		result, runErr := runtime.NewRunner().VSSHJSON(params...)
		record, storeErr := evidence.Store("artifact-collect", host, path, result)
		return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(storeErr), "run_error": errString(runErr)}, nil
	case "meshclaw_disk_investigate":
		host := stringArg(args, "host")
		path := stringArg(args, "path")
		if path == "" {
			path = "/"
		}
		command := fmt.Sprintf("df -h %s && sudo du -xhd1 %s 2>/dev/null | sort -h | tail -40", shellQuote(path), shellQuote(path))
		result := runtime.NewRunner().RunEvidence(host, command)
		record, err := evidence.Store("disk-investigate", host, path, result)
		return map[string]interface{}{"result": result, "evidence": record, "store_error": errString(err), "time": time.Now().UTC()}, nil
	case "meshclaw_process_top":
		host := stringArg(args, "host")
		report := workflow.ProcessTop(host)
		record, err := evidence.Store("process-top", host, "top memory/cpu processes", report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_data_clean_plan":
		host := stringArg(args, "host")
		path := stringArg(args, "path")
		report := workflow.DataCleanPlan(host, path)
		record, err := evidence.Store("data-clean-plan", host, path, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_data_clean_apply":
		host := stringArg(args, "host")
		manifest := stringArg(args, "manifest")
		report := workflow.DataCleanApply(host, manifest)
		record, err := evidence.Store("data-clean-apply", host, manifest, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_analyze_logs":
		host := stringArg(args, "host")
		source := stringArg(args, "source")
		if source == "" {
			source = "system"
		}
		report := workflow.AnalyzeLogs(host, source)
		record, err := evidence.Store("analyze-logs", host, source, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_security_check":
		host := stringArg(args, "host")
		report := workflow.SecurityCheck(host)
		record, err := evidence.Store("security-check", host, "read-only snapshot", report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_guard_modes":
		return map[string]interface{}{"modes": guard.Modes()}, nil
	case "meshclaw_guard_model":
		return map[string]interface{}{"local_model": guard.LocalModel()}, nil
	case "meshclaw_guard_clients":
		return map[string]interface{}{"clients": guard.ClientGuides()}, nil
	case "meshclaw_guard_vault":
		return map[string]interface{}{"vault": guard.VaultConversationPlan()}, nil
	case "meshclaw_guard_vault_backends":
		return map[string]interface{}{"backends": guardvault.Backends()}, nil
	case "meshclaw_guard_vault_list":
		entries, err := guardvault.List()
		if err != nil {
			return nil, err
		}
		return map[string]interface{}{"entries": entries}, nil
	case "meshclaw_guard_vault_metadata":
		entry, err := guardvault.MetadataByHandle(stringArg(args, "handle"))
		if err != nil {
			return nil, err
		}
		return map[string]interface{}{"entry": entry}, nil
	case "meshclaw_guard_detect":
		target := stringArg(args, "target")
		report := guard.Detect(target, stringArg(args, "text"))
		record, err := evidence.Store("guard-detect", target, report.Status, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_guard_redact":
		target := stringArg(args, "target")
		report := guard.Redact(target, stringArg(args, "text"))
		record, err := evidence.Store("guard-redact", target, report.Status, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_guard_posture":
		report := guard.Posture(stringArg(args, "home"))
		record, err := evidence.Store("guard-posture", "local", report.Status, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_guard_clean_plan":
		plan := guard.Cleanup(stringArg(args, "home"))
		record, err := evidence.Store("guard-clean-plan", "local", plan.Status, plan)
		return map[string]interface{}{"plan": plan, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_guard_vuln":
		path := stringArg(args, "path")
		report := guard.VulnScanPath(path)
		record, err := evidence.Store("guard-vuln", path, report.Status, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_guard_intent":
		return map[string]interface{}{"intent": guard.ParseIntent(stringArg(args, "text"))}, nil
	case "meshclaw_hygiene_scan_host":
		host := stringArg(args, "host")
		report := hygiene.ScanHost(host)
		record, err := evidence.Store("hygiene-scan-host", host, report.Status, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_service_check":
		host := stringArg(args, "host")
		service := stringArg(args, "service")
		report := workflow.ServiceCheck(host, service)
		record, err := evidence.Store("service-check", host, service, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_service_audit":
		host := stringArg(args, "host")
		report := workflow.ServiceAudit(host)
		record, err := evidence.Store("service-audit", host, "failed/restarting services", report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_service_quarantine":
		host := stringArg(args, "host")
		service := stringArg(args, "service")
		report := workflow.ServiceQuarantine(host, service)
		record, err := evidence.Store("service-quarantine", host, service, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	case "meshclaw_service_remove":
		host := stringArg(args, "host")
		service := stringArg(args, "service")
		path := stringArg(args, "path")
		report := workflow.ServiceRemove(host, service, path)
		record, err := evidence.Store("service-remove", host, service, report)
		return map[string]interface{}{"report": report, "evidence": record, "store_error": errString(err)}, nil
	default:
		return nil, fmt.Errorf("unknown tool: %s", name)
	}
}

func mcpVSSHJobRead(command, action string, args map[string]interface{}) (interface{}, error) {
	host := stringArg(args, "host")
	id := stringArg(args, "id")
	decision := policy.Evaluate(policy.Request{Subject: "mcp", Action: action, Resource: "server", Context: id})
	if decision.Decision != policy.Allow {
		return map[string]interface{}{"policy": decision, "success": false}, nil
	}
	result, runErr := runtime.NewRunner().VSSHJSON(command, host, id)
	record, storeErr := evidence.Store(command, host, id, result)
	return map[string]interface{}{"policy": decision, "result": result, "evidence": record, "store_error": errString(storeErr), "run_error": errString(runErr)}, nil
}

func stringArg(args map[string]interface{}, key string) string {
	if value, ok := args[key].(string); ok {
		return value
	}
	return ""
}

func intArg(args map[string]interface{}, key string, fallback int) int {
	switch value := args[key].(type) {
	case float64:
		return int(value)
	case int:
		return value
	default:
		return fallback
	}
}

func boolArg(args map[string]interface{}, key string, fallback bool) bool {
	if value, ok := args[key].(bool); ok {
		return value
	}
	return fallback
}

func floatArg(args map[string]interface{}, key string, fallback float64) float64 {
	switch value := args[key].(type) {
	case float64:
		return value
	case int:
		return float64(value)
	default:
		return fallback
	}
}

func errString(err error) string {
	if err == nil {
		return ""
	}
	return err.Error()
}
