import os
import stat
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from meshclaw import __version__
from meshclaw import cli


class MeshClawPythonWrapperTest(unittest.TestCase):
    def test_auto_install_enabled_defaults_on(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            self.assertTrue(cli.auto_install_enabled())

    def test_auto_install_can_be_disabled(self):
        for value in ("0", "false", "no", "off"):
            with self.subTest(value=value):
                with mock.patch.dict(os.environ, {"MESHCLAW_AUTO_INSTALL": value}, clear=True):
                    self.assertFalse(cli.auto_install_enabled())

    def test_candidate_binary_paths_respect_install_dir(self):
        with tempfile.TemporaryDirectory() as tmp:
            with mock.patch.dict(os.environ, {"MESHCLAW_INSTALL_DIR": tmp}, clear=True):
                paths = cli.candidate_binary_paths()
        self.assertEqual(paths[0], Path(tmp) / "meshclaw")

    def test_find_meshclaw_binary_uses_configured_binary(self):
        with tempfile.TemporaryDirectory() as tmp:
            binary = Path(tmp) / "meshclaw"
            binary.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
            binary.chmod(binary.stat().st_mode | stat.S_IXUSR)
            env = {"MESHCLAW_BIN": str(binary), "PATH": ""}
            with mock.patch.dict(os.environ, env, clear=True):
                self.assertEqual(cli.find_meshclaw_binary(), str(binary))

    def test_find_meshclaw_binary_skips_wrapper_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            wrapper = Path(tmp) / "meshclaw"
            wrapper.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
            wrapper.chmod(wrapper.stat().st_mode | stat.S_IXUSR)
            with mock.patch.dict(os.environ, {"PATH": tmp}, clear=True):
                with mock.patch.object(sys, "argv", [str(wrapper)]):
                    with mock.patch.object(cli, "candidate_binary_paths", return_value=[]):
                        with mock.patch.object(cli.shutil, "which", return_value=None):
                            self.assertIsNone(cli.find_meshclaw_binary())

    def test_missing_message_is_actionable_and_versioned(self):
        message = cli.binary_missing_message()
        self.assertIn("meshclaw --install-binary", message)
        self.assertIn("meshclaw init", message)
        self.assertIn("MESHCLAW_BIN=/path/to/meshclaw", message)
        self.assertIn(f"wrapper_version={__version__}", message)


if __name__ == "__main__":
    unittest.main()
