"""
title: MeshClaw Ops
author: dragon
version: 0.1.0
description: Open WebUI pipe for MeshClaw server operations, logs, security, policy, evidence, and Matrix notifications.
"""

import json
import os
import urllib.error
import urllib.request
from typing import Any, Dict, List


class Pipe:
    def __init__(self):
        self.name = "MeshClaw Ops"
        urls = os.getenv(
            "MESHCLAW_OPS_GATEWAY_URLS",
            os.getenv(
                "MESHCLAW_OPS_GATEWAY_URL",
                "http://host.docker.internal:8765,http://host.docker.internal:8766,http://host.docker.internal:8767,http://172.17.0.1:8765,http://172.17.0.1:8766,http://172.17.0.1:8767,http://127.0.0.1:8765,http://127.0.0.1:8766,http://127.0.0.1:8767",
            ),
        )
        self.gateway_urls = [url.strip().rstrip("/") for url in urls.split(",") if url.strip()]
        self.timeout = int(os.getenv("MESHCLAW_OPENWEBUI_TIMEOUT", "180"))

    def pipe(self, body: dict) -> str:
        messages = body.get("messages", [])
        if not messages:
            return "메시지가 없습니다."

        user_msg = self._last_user_message(messages)
        if not user_msg:
            return "사용자 메시지를 찾지 못했습니다."

        route = self._route(user_msg)
        if route:
            return route

        return self._meshclaw_dispatch(user_msg)

    def _last_user_message(self, messages: List[Dict[str, Any]]) -> str:
        for message in reversed(messages):
            if message.get("role") == "user":
                content = message.get("content", "")
                if isinstance(content, str):
                    return content.strip()
                if isinstance(content, list):
                    texts = []
                    for item in content:
                        if isinstance(item, dict) and item.get("type") == "text":
                            texts.append(str(item.get("text", "")))
                    return "\n".join(texts).strip()
        return ""

    def _route(self, text: str) -> str:
        value = text.strip()
        lower = value.lower()
        if lower in {"help", "도움말", "?"}:
            return self._help()

        aliases = {
            "!fleet": "monitor-check",
            "fleet": "monitor-check",
            "서버상태": "ops-control",
            "서버 상태": "ops-control",
            "!workers": "workers",
            "workers": "workers",
            "ai-guide": "ai-guide",
            "도구 가이드": "ai-guide",
            "!policy": "policy-show",
            "policy": "policy-show",
            "!evidence": "evidence-list",
            "evidence": "evidence-list",
            "matrix": "matrix-doctor",
            "매트릭스": "matrix-doctor",
            "vssh-auth-fix-plan": "vssh-auth-fix-plan",
            "vssh 인증 복구": "vssh-auth-fix-plan",
            "vssh 시크릿": "vssh-auth-fix-plan",
            "openwebui": "openwebui-scan",
            "open webui": "openwebui-scan",
            "오픈웹유아이": "openwebui-scan",
            "웹유아이": "openwebui-scan",
        }
        command = aliases.get(lower)
        if command:
            return self._meshclaw(command)
        return ""

    def _meshclaw_dispatch(self, message: str) -> str:
        return self._request("/dispatch", {"message": message, "source": "openwebui"})

    def _meshclaw(self, *args: str) -> str:
        return self._request("/command", {"args": list(args), "source": "openwebui"})

    def _request(self, path: str, payload: Dict[str, Any]) -> str:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        errors = []
        body = ""
        for base_url in self.gateway_urls:
            url = base_url + path
            request = urllib.request.Request(
                url,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    body = response.read().decode("utf-8", errors="replace")
                break
            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                if exc.code == 404:
                    errors.append(f"{base_url}: HTTP 404")
                    continue
                return f"MeshClaw 게이트웨이 요청이 실패했습니다. HTTP {exc.code}\n\n```text\n{body[:6000]}\n```"
            except Exception as exc:
                errors.append(f"{base_url}: {exc}")
        else:
            return "MeshClaw 게이트웨이 연결 실패:\n\n```text\n" + "\n".join(errors)[:6000] + "\n```"

        try:
            result = json.loads(body)
        except json.JSONDecodeError:
            return self._trim(body.strip() or "MeshClaw 게이트웨이가 빈 응답을 반환했습니다.")

        output = str(result.get("stdout") or "").strip()
        error = str(result.get("stderr") or "").strip()
        if not result.get("ok"):
            detail = error or output or result.get("error") or "unknown error"
            return f"MeshClaw 명령이 실패했습니다.\n\n```text\n{str(detail)[:6000]}\n```"

        if not output:
            output = "완료됐지만 출력은 없습니다."
        output = self._humanize_meshclaw_output(output)
        return self._trim(output)

    def _humanize_meshclaw_output(self, output: str) -> str:
        try:
            payload = json.loads(output)
        except Exception:
            return output
        if not isinstance(payload, dict):
            return output

        route = payload.get("route") or self._infer_route(payload)
        result = payload.get("result")
        if route == "fleet_inventory":
            return self._format_fleet_inventory(result)
        if route == "monitor_check":
            return self._format_monitor_check(result)
        if route == "workers":
            return self._format_workers(result)
        if route == "openwebui_scan":
            return self._format_openwebui_scan(result)
        if route == "vssh_auth_fix_plan":
            return self._format_vssh_auth_fix_plan(result)
        if route in {"chat", "intro"} and isinstance(result, dict):
            return str(result.get("reply") or result.get("conversation") or json.dumps(result, ensure_ascii=False, indent=2))
        return json.dumps(payload, ensure_ascii=False, indent=2)

    def _infer_route(self, payload: Dict[str, Any]) -> str:
        result = payload.get("result")
        report = self._nested(result, "report")
        if isinstance(report, dict) and isinstance(report.get("hosts"), list):
            if any(isinstance(h, dict) and h.get("name") == "software-inventory" for h in report.get("hosts", [])):
                return "fleet_inventory"
        if isinstance(result, dict) and "states" in result and "alerts" in result:
            return "monitor_check"
        if isinstance(result, list) and result and isinstance(result[0], dict) and "surface" in result[0]:
            return "workers"
        report = self._nested(result, "report")
        if isinstance(report, dict) and "with_pipe" in report and "with_gateway" in report:
            return "openwebui_scan"
        return ""

    def _format_fleet_inventory(self, result: Any) -> str:
        report = self._nested(result, "report") or result or {}
        hosts = report.get("hosts", []) if isinstance(report, dict) else []
        ok = [h for h in hosts if isinstance(h, dict) and h.get("status") == "ok"]
        failed = [h for h in hosts if isinstance(h, dict) and h.get("status") != "ok"]
        lines = [
            "노드별 설치 상태를 확인했습니다.",
            "",
            f"요약: 확인 {len(hosts)}개, 정상 {len(ok)}개, 실패 {len(failed)}개",
        ]
        if failed:
            lines.append("")
            lines.append("먼저 볼 문제:")
            for h in failed[:6]:
                lines.append(f"- {h.get('host')}: {h.get('error') or h.get('status')}")
        if ok:
            lines.append("")
            lines.append("노드별 요약:")
            for h in ok:
                tools = h.get("tools") or {}
                tool_names = ",".join(sorted(tools.keys())[:10]) if isinstance(tools, dict) else ""
                gpu = h.get("gpu") or []
                gpu_text = f" | gpu={len(gpu)}" if gpu else ""
                lines.append(f"- {h.get('host')}: {h.get('os', 'unknown')} | tools={tool_names}{gpu_text}")
        evidence_id = self._nested(result, "evidence", "id")
        if evidence_id:
            lines.extend(["", f"evidence: `{evidence_id}`"])
        return "\n".join(lines)

    def _format_vssh_auth_fix_plan(self, result: Any) -> str:
        if not isinstance(result, dict):
            return json.dumps(result, ensure_ascii=False, indent=2)
        summary = result.get("summary") or {}
        actions = result.get("actions") or []
        lines = [
            "vssh 인증/데몬 복구 계획입니다.",
            "",
            f"판단: {result.get('decision', 'unknown')}",
            f"요약: 전체 {summary.get('hosts_total', 0)}개, 정상 {summary.get('ok', 0)}개, auth_failed {summary.get('auth_failed', 0)}개, unreachable {summary.get('unreachable', 0)}개",
        ]
        if actions:
            lines.extend(["", "조치 후보:"])
            for action in actions[:10]:
                if isinstance(action, dict):
                    lines.append(f"- {action.get('host')}: {action.get('status')} | {action.get('mode')} | {action.get('reason')}")
                    lines.append(f"  next: `{action.get('aftercare')}`")
        evidence_id = self._nested(result, "evidence", "id")
        if evidence_id:
            lines.extend(["", f"evidence: `{evidence_id}`"])
        return "\n".join(lines)

    def _format_monitor_check(self, result: Any) -> str:
        states = result.get("states", []) if isinstance(result, dict) else []
        alerts = result.get("alerts", []) if isinstance(result, dict) else []
        lines = [
            "서버 상태를 확인했습니다.",
            "",
            f"요약: 노드 {len(states)}개, 알림 {len(alerts)}개",
        ]
        if alerts:
            lines.append("")
            lines.append("우선 조치 후보:")
            for alert in alerts[:8]:
                if isinstance(alert, dict):
                    lines.append(f"- {alert.get('host')}: {alert.get('message') or alert.get('kind') or alert}")
                else:
                    lines.append(f"- {alert}")
        return "\n".join(lines)

    def _format_workers(self, result: Any) -> str:
        if not isinstance(result, list):
            return json.dumps(result, ensure_ascii=False, indent=2)
        lines = ["현재 사용할 수 있는 작업 표면입니다.", ""]
        for item in result:
            if isinstance(item, dict):
                lines.append(f"- {item.get('id')}: {item.get('status')} | {item.get('surface')}")
        return "\n".join(lines)

    def _format_openwebui_scan(self, result: Any) -> str:
        report = self._nested(result, "report") or result or {}
        hosts = report.get("hosts", []) if isinstance(report, dict) else []
        lines = [
            "Open WebUI 연결 상태를 확인했습니다.",
            "",
            f"요약: 설치 {report.get('installed', 0)}개, Pipe {report.get('with_pipe', 0)}개, Gateway {report.get('with_gateway', 0)}개, 실패 {report.get('failures', 0)}개",
            "",
            "서버별 상태:",
        ]
        for h in hosts:
            if not isinstance(h, dict):
                continue
            status = h.get("status")
            if status == "ok":
                lines.append(f"- {h.get('host')}: ok | {h.get('name', 'Open WebUI')} {h.get('version', '')} | runtime={h.get('runtime') or 'unknown'} | gateway={h.get('gateway')}")
            elif status == "not_installed":
                lines.append(f"- {h.get('host')}: Open WebUI 없음")
            else:
                lines.append(f"- {h.get('host')}: {status} | {h.get('error') or h.get('gateway') or ''}")
        evidence_id = self._nested(result, "evidence", "id")
        if evidence_id:
            lines.extend(["", f"evidence: `{evidence_id}`"])
        return "\n".join(lines)

    def _nested(self, value: Any, *keys: str) -> Any:
        current = value
        for key in keys:
            if not isinstance(current, dict):
                return None
            current = current.get(key)
        return current

    def _trim(self, text: str) -> str:
        limit = int(os.getenv("MESHCLAW_OPENWEBUI_OUTPUT_LIMIT", "12000"))
        if len(text) <= limit:
            return text
        return text[:limit] + "\n\n...출력이 길어서 잘랐습니다. 자세한 내용은 MeshClaw evidence/CLI에서 확인하세요."

    def _help(self) -> str:
        return """MeshClaw Ops pipe입니다.

예시:
- 서버 상태 관리해줘
- d1 open-webui 상태 확인해줘
- d1 로그 분석해줘
- 전체 서버 보안 점검 요약해줘
- 개인정보/시크릿 새는지 점검해줘
- !fleet
- !workers
- !policy
- !evidence

Open WebUI는 대화 UI이고, MeshClaw는 상태/권한/보안/실행/evidence 레이어입니다. 위험한 조치는 정책에 따라 승인 필요로 분리됩니다."""
