#!/usr/bin/env python3
"""
Small host-side gateway for Open WebUI.

Open WebUI runs in Docker, while MeshClaw needs the host's SSH, Tailscale,
vssh, policy, and evidence environment. This gateway keeps that boundary clear:
Open WebUI talks HTTP to the host, and the host executes MeshClaw.
"""

from __future__ import annotations

import json
import os
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


MESHCLAW_BIN = os.environ.get("MESHCLAW_BIN", "/usr/local/bin/meshclaw")
VSSH_BIN = os.environ.get("MESHCLAW_VSSH_BINARY", "/usr/local/bin/vssh")
HOST = os.environ.get("MESHCLAW_OPS_GATEWAY_HOST", "0.0.0.0")
PORT = int(os.environ.get("MESHCLAW_OPS_GATEWAY_PORT", "8765"))
TIMEOUT = int(os.environ.get("MESHCLAW_OPS_GATEWAY_TIMEOUT", "240"))
OUTPUT_LIMIT = int(os.environ.get("MESHCLAW_OPS_GATEWAY_OUTPUT_LIMIT", "20000"))

ALLOWED_COMMANDS = {
    "monitor-check",
    "ops-brief",
    "ops-control",
    "fleet-scan",
    "fleet-service-audit",
    "vssh-daemon-audit",
    "vssh-auth-fix-plan",
    "service-triage",
    "node-inventory",
    "fleet-inventory",
    "placement-plan",
    "autoheal-plan",
    "evidence-list",
    "policy-check",
    "policy-show",
    "matrix-doctor",
    "workers",
    "ai-guide",
    "openwebui-scan",
    "workspace-list",
    "ops-dispatch",
    "provision-plan",
    "doctor",
    "analyze-logs",
    "service-check",
    "service-audit",
    "security-check",
    "hygiene-plan",
    "hygiene-scan-host",
    "hygiene-scan-text",
}


class Handler(BaseHTTPRequestHandler):
    server_version = "meshclaw-openwebui-gateway/0.1"

    def do_GET(self) -> None:
        if self.path == "/health":
            self._json(200, {"ok": True, "meshclaw": MESHCLAW_BIN})
            return
        self._json(404, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:
        try:
            payload = self._read_json()
            if self.path == "/dispatch":
                message = str(payload.get("message") or "").strip()
                if not message:
                    self._json(400, {"ok": False, "error": "message is required"})
                    return
                self._run(["ops-dispatch", str(payload.get("source") or "openwebui"), message])
                return
            if self.path == "/command":
                args = payload.get("args")
                if not isinstance(args, list) or not args:
                    self._json(400, {"ok": False, "error": "args must be a non-empty list"})
                    return
                clean_args = [str(arg) for arg in args]
                if clean_args[0] not in ALLOWED_COMMANDS:
                    self._json(403, {"ok": False, "error": f"command not allowed: {clean_args[0]}"})
                    return
                self._run(clean_args)
                return
            self._json(404, {"ok": False, "error": "not found"})
        except Exception as exc:
            self._json(500, {"ok": False, "error": str(exc)})

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"{self.address_string()} - {fmt % args}", flush=True)

    def _run(self, args: list[str]) -> None:
        env = {
            **os.environ,
            "MESHCLAW_VSSH_BINARY": VSSH_BIN,
            "PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"),
        }
        try:
            proc = subprocess.run(
                [MESHCLAW_BIN, *args],
                text=True,
                capture_output=True,
                timeout=TIMEOUT,
                env=env,
            )
            self._json(
                200 if proc.returncode == 0 else 500,
                {
                    "ok": proc.returncode == 0,
                    "returncode": proc.returncode,
                    "stdout": trim(proc.stdout),
                    "stderr": trim(proc.stderr),
                },
            )
        except subprocess.TimeoutExpired as exc:
            self._json(
                504,
                {
                    "ok": False,
                    "error": "timeout",
                    "stdout": trim(exc.stdout or ""),
                    "stderr": trim(exc.stderr or ""),
                },
            )

    def _read_json(self) -> dict[str, Any]:
        size = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(size).decode("utf-8", errors="replace")
        return json.loads(raw or "{}")

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


def trim(value: str) -> str:
    if len(value) <= OUTPUT_LIMIT:
        return value
    return value[:OUTPUT_LIMIT] + "\n\n...trimmed by meshclaw gateway..."


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"meshclaw openwebui gateway listening on {HOST}:{PORT}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
