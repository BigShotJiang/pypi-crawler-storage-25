package openwebui

import (
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/meshclaw/meshclaw/internal/inventory"
	"github.com/meshclaw/meshclaw/internal/runtime"
)

type ScanReport struct {
	Time        time.Time  `json:"time"`
	Hosts       []HostInfo `json:"hosts"`
	OK          int        `json:"ok"`
	Installed   int        `json:"installed"`
	WithPipe    int        `json:"with_pipe"`
	WithGateway int        `json:"with_gateway"`
	Failures    int        `json:"failures"`
}

type HostInfo struct {
	Host          string   `json:"host"`
	Status        string   `json:"status"`
	Version       string   `json:"version,omitempty"`
	Name          string   `json:"name,omitempty"`
	Auth          *bool    `json:"auth,omitempty"`
	Runtime       string   `json:"runtime,omitempty"`
	URL           string   `json:"url,omitempty"`
	Gateway       string   `json:"gateway,omitempty"`
	PipeInstalled bool     `json:"pipe_installed"`
	Functions     []string `json:"functions,omitempty"`
	Error         string   `json:"error,omitempty"`
}

type remoteScanPayload struct {
	Config struct {
		Status   bool   `json:"status"`
		Name     string `json:"name"`
		Version  string `json:"version"`
		Features struct {
			Auth bool `json:"auth"`
		} `json:"features"`
	} `json:"config"`
	Runtime   string   `json:"runtime"`
	Gateway   string   `json:"gateway"`
	Functions []string `json:"functions"`
}

func Scan(hosts []string, parallel int) (ScanReport, error) {
	selected, err := selectHosts(hosts)
	if err != nil {
		return ScanReport{}, err
	}
	if parallel <= 0 {
		parallel = 6
	}
	report := ScanReport{Time: time.Now().UTC(), Hosts: make([]HostInfo, len(selected))}
	runner := runtime.NewRunner()
	runner.Timeout = 25 * time.Second
	sem := make(chan struct{}, parallel)
	var wg sync.WaitGroup
	for i, host := range selected {
		i, host := i, host
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			report.Hosts[i] = scanHost(runner, host)
		}()
	}
	wg.Wait()
	sort.Slice(report.Hosts, func(i, j int) bool { return report.Hosts[i].Host < report.Hosts[j].Host })
	for _, host := range report.Hosts {
		if host.Status == "ok" {
			report.OK++
		}
		if host.Status == "ok" || host.Status == "missing_pipe" || host.Status == "missing_gateway" {
			report.Installed++
		}
		if host.PipeInstalled {
			report.WithPipe++
		}
		if host.Gateway != "" {
			report.WithGateway++
		}
		if host.Status == "failed" {
			report.Failures++
		}
	}
	return report, nil
}

func scanHost(runner runtime.Runner, host string) HostInfo {
	result := runner.RunEvidence(host, remoteScanScript())
	info := HostInfo{Host: host}
	if !result.Success {
		info.Status = "failed"
		info.Error = trim(result.Stderr+result.Stdout, 1200)
		return info
	}
	var payload remoteScanPayload
	if err := json.Unmarshal([]byte(strings.TrimSpace(result.Stdout)), &payload); err != nil {
		info.Status = "failed"
		info.Error = "invalid scan JSON: " + trim(result.Stdout, 1200)
		return info
	}
	if !payload.Config.Status || payload.Config.Version == "" {
		info.Status = "not_installed"
		return info
	}
	auth := payload.Config.Features.Auth
	info.Status = "ok"
	info.Version = payload.Config.Version
	info.Name = payload.Config.Name
	info.Auth = &auth
	info.Runtime = payload.Runtime
	info.URL = "http://" + host + ":8080"
	info.Gateway = payload.Gateway
	info.Functions = payload.Functions
	for _, fn := range payload.Functions {
		if fn == "meshclaw_ops" {
			info.PipeInstalled = true
			break
		}
	}
	if !info.PipeInstalled {
		info.Status = "missing_pipe"
	}
	if info.Gateway == "" {
		info.Status = "missing_gateway"
	}
	return info
}

func selectHosts(hosts []string) ([]string, error) {
	if len(hosts) == 0 {
		nodes := inventory.DefaultNodes()
		out := make([]string, 0, len(nodes))
		for _, node := range nodes {
			out = append(out, node.Name)
		}
		return out, nil
	}
	var out []string
	seen := map[string]bool{}
	for _, host := range hosts {
		for _, part := range strings.Split(host, ",") {
			part = strings.TrimSpace(part)
			if part == "" || seen[part] {
				continue
			}
			if _, ok := inventory.Find(part); !ok {
				return nil, fmt.Errorf("unknown node: %s", part)
			}
			seen[part] = true
			out = append(out, part)
		}
	}
	return out, nil
}

func remoteScanScript() string {
	return `python3 - <<'PY'
import json, os, sqlite3, subprocess, urllib.request

out = {"config": {}, "runtime": "", "gateway": "", "functions": []}
for url in ["http://127.0.0.1:8080/api/config", "http://127.0.0.1:8081/api/config"]:
    try:
        out["config"] = json.loads(urllib.request.urlopen(url, timeout=3).read().decode())
        break
    except Exception:
        pass

def sh(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL, text=True, timeout=3).strip()
    except Exception:
        return ""

if sh("systemctl is-active open-webui.service") == "active":
    out["runtime"] = "systemd"
elif sh("docker ps --format '{{.Names}} {{.Image}}' | grep -i 'open-webui'"):
    out["runtime"] = "docker"

for url in ["http://127.0.0.1:8765/health", "http://127.0.0.1:8766/health", "http://127.0.0.1:8767/health"]:
    try:
        data = json.loads(urllib.request.urlopen(url, timeout=2).read().decode())
        if data.get("ok"):
            out["gateway"] = url
            break
    except Exception:
        pass

dbs = [
    "/app/backend/data/webui.db",
    "/home/dragon/.local/share/open-webui/webui.db",
    "/home/dell/.local/share/open-webui/webui.db",
    "/var/lib/docker/volumes/open-webui/_data/webui.db",
    "/var/lib/docker/volumes/meshclaw-guard-webui/_data/webui.db",
]
for db in dbs:
    if not os.path.exists(db):
        continue
    try:
        con = sqlite3.connect(db)
        out["functions"] = [row[0] for row in con.execute("select id from function")]
        break
    except Exception:
        pass
if not out["functions"]:
    docker_names = sh("sudo -n docker ps --format '{{.Names}}' 2>/dev/null | grep -E '(^open-webui$|webui)'")
    for name in docker_names.splitlines():
        try:
            code = "import sqlite3, json; con=sqlite3.connect('/app/backend/data/webui.db'); print(json.dumps([r[0] for r in con.execute('select id from function')]))"
            raw = sh("sudo -n docker exec %s python -c %s" % (name, json.dumps(code)))
            if raw:
                out["functions"] = json.loads(raw)
                break
        except Exception:
            pass
print(json.dumps(out, ensure_ascii=False))
PY`
}

func trim(value string, limit int) string {
	value = strings.TrimSpace(value)
	if len(value) <= limit {
		return value
	}
	return value[:limit] + "...trimmed..."
}
