package workflow

import (
	"strings"
	"testing"
)

func TestDataCleanPlanCommandPrunesDependencyPaths(t *testing.T) {
	command := dataCleanPlanCommand("/home")

	required := []string{
		`*/site-packages/*`,
		`*/dist-packages/*`,
		`*/.local/lib/python*/*`,
		`*/go/pkg/mod/*`,
		`*/node_modules/*`,
		`min_kb=10240`,
		`jsonl=${manifest%.txt}.jsonl`,
		`"category": category`,
		`"risk": risk`,
		`estimated_reclaim_kb`,
		`sort -hr | head -200`,
	}
	for _, pattern := range required {
		if !strings.Contains(command, pattern) {
			t.Fatalf("cleanup plan command does not prune %q:\n%s", pattern, command)
		}
	}

	forbidden := []string{
		`-name "*checkpoint*"`,
		`-name "*ckpt*"`,
	}
	for _, pattern := range forbidden {
		if strings.Contains(command, pattern) {
			t.Fatalf("cleanup plan command still uses broad file matcher %q:\n%s", pattern, command)
		}
	}
}

func TestDataCleanApplyCommandHasDefenseInDepth(t *testing.T) {
	command := dataCleanApplyCommand("/tmp/meshclaw-data-clean-plan-test.txt")

	required := []string{
		"refuse_dependency_path",
		"refuse_unrecognized_dir",
		"refuse_unrecognized_file",
		`*/site-packages/*`,
		`*.ckpt|*checkpoint*.pt`,
		`structured_plan=`,
		`categories=`,
		`risks=`,
	}
	for _, pattern := range required {
		if !strings.Contains(command, pattern) {
			t.Fatalf("cleanup apply command is missing safety guard %q:\n%s", pattern, command)
		}
	}
}

func TestSummarizeServiceAuditOutputCollapsesRepeatedJournalLines(t *testing.T) {
	output := summarizeServiceAuditOutput(`---failed---
---activating---
---recent-service-errors---
5월 18 18:49:01 d1 systemd[2172]: open-webui.service: Failed with result 'exit-code'.
5월 18 18:49:05 d1 systemd[2172]: open-webui.service: Failed with result 'exit-code'.
5월 18 18:49:08 d1 systemd[2172]: open-webui.service: Failed with result 'exit-code'.
5월 18 18:50:01 d1 systemd[2172]: other.service: Main process exited.`)

	if !strings.Contains(output, "open-webui.service: Failed with result 'exit-code'. (repeated 3 times)") {
		t.Fatalf("repeated service failures were not collapsed:\n%s", output)
	}
	if strings.Count(output, "open-webui.service") != 1 {
		t.Fatalf("collapsed output still repeats open-webui lines:\n%s", output)
	}
	if !strings.Contains(output, "other.service: Main process exited.") {
		t.Fatalf("unique journal line was lost:\n%s", output)
	}
}

func TestServiceCheckCommandCollectsSystemAndUserScopes(t *testing.T) {
	command := serviceCheckCommand("open-webui")

	required := []string{
		"---system-status---",
		"systemctl status",
		"---user-status---",
		"systemctl --user status",
		"journalctl --user -u",
	}
	for _, pattern := range required {
		if !strings.Contains(command, pattern) {
			t.Fatalf("service check command is missing %q:\n%s", pattern, command)
		}
	}
}

func TestSummarizeServiceCheckOutputCollapsesUserLogs(t *testing.T) {
	output := summarizeServiceCheckOutput(`---user-status---
● open-webui.service - Open WebUI Service
     Active: activating (auto-restart) (Result: exit-code)
---user-logs---
5월 18 18:58:17 d1 systemd[2172]: open-webui.service: Main process exited, code=exited, status=203/EXEC
5월 18 18:58:20 d1 systemd[2172]: open-webui.service: Main process exited, code=exited, status=203/EXEC
5월 18 18:58:20 d1 systemd[2172]: open-webui.service: Failed with result 'exit-code'.`)

	if !strings.Contains(output, "status=203/EXEC (repeated 2 times)") {
		t.Fatalf("service-check user logs were not collapsed:\n%s", output)
	}
	if !strings.Contains(output, "Active: activating (auto-restart)") {
		t.Fatalf("service status section was lost:\n%s", output)
	}
}

func TestServiceJournalMessageNormalizesRestartCounters(t *testing.T) {
	first := serviceJournalMessage("5월 18 18:58:17 d1 systemd[2172]: open-webui.service: Scheduled restart job, restart counter is at 41041.")
	second := serviceJournalMessage("5월 18 18:58:20 d1 systemd[2172]: open-webui.service: Scheduled restart job, restart counter is at 41042.")

	if first != second {
		t.Fatalf("restart counter normalization differs:\n%s\n%s", first, second)
	}
	if !strings.Contains(first, "restart counter is at <n>") {
		t.Fatalf("restart counter was not normalized: %s", first)
	}
}

func TestServiceQuarantineCommandSupportsUserScope(t *testing.T) {
	command := serviceQuarantineCommand("open-webui")

	required := []string{
		"systemctl --user show",
		"scope=user",
		"systemctl --user disable --now",
		"ExecStart exists and is executable; refusing quarantine",
	}
	for _, pattern := range required {
		if !strings.Contains(command, pattern) {
			t.Fatalf("service quarantine command is missing %q:\n%s", pattern, command)
		}
	}
}
