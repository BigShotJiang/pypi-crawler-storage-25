# MeshClaw Guard

MeshClaw Guard is the local safety layer for AI-assisted operations. It is not
a chatbot and it does not need a model for its core work. It gives Codex,
Claude, Cursor, Open WebUI, and local models a safer way to handle secret-
adjacent work.

Guard owns three modes:

- `credential`: detect and redact pasted secrets, then turn raw values into
  capability-handle workflow.
- `posture`: check whether the local operator environment is safe for sensitive
  AI work, including local model memory and chat-history stores.
- `vuln`: scan local files for leaked credentials or hygiene risks without
  returning raw values.

The first rule is simple: models may receive redacted context and handles, never
raw secret values.

## Why Guard Exists

AI clients are good at reasoning, planning, and coding, but they should not be
trusted as a raw credential store. A user can still accidentally paste a
password, API key, DKIM key, or provider token into a conversation. Guard gives
the runtime a deterministic layer that can:

- detect sensitive values before they enter evidence or model context
- redact text while preserving useful structure
- mark rotation and cleanup as approval-gated actions
- write audit evidence without leaking the value
- check local model memory, RAG, and chat-history risk

This logic is intentionally model-less. Regex, entropy checks, policy, and
evidence are deterministic and testable.

## Optional Local Guard Chat

Most operations should stay with Codex, Claude, Cursor, or another strong AI
operator. They can explain plans, inspect evidence, run MCP tools, and continue
orchestration. Passwords, private keys, recovery codes, raw API tokens, and
vault work are the exception.

For those moments MeshClaw should provide a local-only Guard Chat: a small local
model and UI that helps the user talk through credential work without sending
raw values to a cloud model. This local chat is not the main MeshClaw brain. It
is the private credential conversation window.

The local model may explain findings, guide the user through cleanup, or ask
natural follow-up questions. It must not become the authority for whether a
value is safe.

Recommended division:

- Guard core: detection, redaction, posture, policy, evidence
- Optional local model: Korean/English explanation, operator coaching, cleanup
  checklist narration, vault conversation
- MeshClaw policy: approval requirements and deny rules
- Vault/provider adapters: actual secret storage and short-lived secret use

Sensitive-mode conversations should start by disabling persistent memory,
history sync, and RAG ingestion in the chosen local UI. Guard can check for
known local stores, but it cannot guarantee every third-party UI is clean.

Guard Chat should eventually support local vault operations through handles:

- create or import a secret into a local vault through local-only input
- show metadata, not raw values, to cloud AI operators
- produce `vault://...` handles for Codex/Claude workflows
- approve use-only injection into adapters without revealing the value
- plan rotation when a secret may have leaked
- delete sensitive local chat history after the session

This keeps the product boundary clear:

- Codex/Claude/Cursor: general reasoning and orchestration
- MeshClaw Runtime: state, policy, execution, evidence, workflows
- MeshClaw Guard: secret detection, redaction, posture, vault handles
- Local Guard Chat: password/vault conversation only

## CLI

```sh
meshclaw guard-modes --json
meshclaw guard-model --json
meshclaw guard-clients --json
meshclaw guard-vault --json
meshclaw guard-vault-backends --json
meshclaw guard-vault-init --json
printf '%s' "$TOKEN" | meshclaw guard-vault-put cloudflare dns-token api-token "Cloudflare DNS token" --backend keychain --json
meshclaw guard-vault-list --json
meshclaw guard-vault-metadata vault://meshclaw/cloudflare/dns-token --json
meshclaw guard-vault-use vault://meshclaw/cloudflare/dns-token CLOUDFLARE_TOKEN --approve --actor dragon --reason "read DNS zones" -- provider-cli zones list --json
meshclaw guard-detect chat "token=..." --json
meshclaw guard-redact chat "password=..." --json
meshclaw guard-posture --json
meshclaw guard-clean-plan --json
meshclaw guard-vuln /path/to/project --json
meshclaw guard-intent "Cloudflare 토큰 저장해줘" --json
meshclaw guard-local-server 127.0.0.1:18765
```

Every command returns structured JSON with status, findings, recommended
actions, and evidence paths where applicable.

## MCP Tools

AI clients should call these tools instead of parsing prose:

- `meshclaw_guard_modes`
- `meshclaw_guard_model`
- `meshclaw_guard_clients`
- `meshclaw_guard_vault`
- `meshclaw_guard_vault_backends`
- `meshclaw_guard_vault_list`
- `meshclaw_guard_vault_metadata`
- `meshclaw_guard_detect`
- `meshclaw_guard_redact`
- `meshclaw_guard_posture`
- `meshclaw_guard_clean_plan`
- `meshclaw_guard_vuln`
- `meshclaw_guard_intent`

The tools use underscore-only names for Codex, Claude, and Cursor MCP
compatibility.

`meshclaw_guard_clients` is the productized local-client safety guide. It tells
AI operators how to treat Ollama CLI, Open WebUI, LM Studio, Enchanted,
Cursor/Continue/VS Code extensions, and cloud AI clients. The output is
structured, not prose-only: each client has `risk`, `required_settings`,
`local_stores`, and recommended use. `meshclaw_guard_posture` uses the same
known local stores to flag chat-history, memory, and RAG locations that need
cleanup after credential work.

`guard-vault-put` can store secrets in MeshClaw's local AES-GCM fallback, Apple
Keychain, or Ubuntu `pass`:

- `--backend local`: encrypted fallback under `~/.meshclaw/guard-vault`
- `--backend keychain`: macOS Apple Keychain via `security`
- `--backend pass`: Linux/Ubuntu `pass` store under `meshclaw/<scope>/<name>`

1Password and Bitwarden are exposed in `guard-vault-backends` as adapter status
targets first. They should be integrated as metadata/CLI-backed managers without
ever returning raw values through MCP.

`meshclaw_guard_intent` is for local Guard Chat. It classifies Korean/English
messages such as "토큰 저장해줘", "목록 보여줘", "삭제해줘", "점검해줘", or
"이 repo 스캔해줘" into structured actions. It does not execute the action by
itself; MeshClaw policy, local-only boundaries, and approval gates still decide
what can run.

`meshclaw_guard_clean_plan` is deliberately read-only. It lists local chat,
memory, RAG, and IDE-context stores that may need cleanup after secret work.
Deletion is destructive and should stay local-only with strong approval.

## Local Guard Chat Bridge

`meshclaw guard-local-server` exposes a localhost-only HTTP bridge for local
models and local chat UIs. This is the missing piece between "talk to a local
model" and "store the secret in Keychain/pass":

```sh
meshclaw guard-local-server 127.0.0.1:18765
```

Endpoints:

- `GET /health`
- `POST /api/guard/intent`
- `POST /api/guard/vault/import`
- `GET /api/guard/vault/list`
- `GET /api/guard/vault/backends`
- `GET /api/guard/posture`
- `GET /api/guard/clean-plan`

Example local-only import:

```sh
curl -sS http://127.0.0.1:18765/api/guard/vault/import \
  -H 'Content-Type: application/json' \
  -d '{"scope":"cloudflare","name":"dns-token","kind":"api-token","backend":"keychain","value":"..."}'
```

The response returns a `vault://meshclaw/...` handle and metadata. It does not
return the raw value. This server refuses non-local bind addresses and non-local
clients. Do not expose it through tunnels, reverse proxies, Tailscale serve, or
public ports.

MCP intentionally does not expose raw secret reveal. Cloud AI operators can list
handles and read metadata, but they cannot retrieve password/token values.
Secret import and deletion stay local-only until a dedicated Guard Chat UI is
implemented.

`guard-vault-use` is also local-only. It requires explicit `--approve` before
execution, injects the secret into one child process environment variable,
redacts the value from stdout/stderr, records approval evidence, and updates
`last_used_at`. It is not exposed through MCP. MeshClaw options must appear
before the `--` separator; options after `--` belong to the child command.

## Workflow Integration

MeshClaw workflows reference credentials by `vault_handles`, not by raw values.
For example, `email-orchestration-demo` declares:

- `vault://meshclaw/cloudflare/dns-token` for Cloudflare DNS/token steps
- `vault://meshclaw/mail/codex-app-password` for mail client setup
- `vault://meshclaw/mail/macmini-sender-password` for test-mail sending

These handles appear in workflow inspection, approval gates, `steps.jsonl`,
`plan.md`, and `meshclaw-actions.md`. They tell Codex/Claude what local secret
capability is required without revealing the value.

Workflows can also declare adapter-local environment injection with
`secret_env`. This is generic runtime behavior, not an email-specific feature:

```json
{
  "id": "provider-dry-check",
  "title": "Read provider state with a local token",
  "transport": "local",
  "command": "provider-cli zones list --json",
  "action": "read_state",
  "resource": "dns",
  "secret_env": {
    "PROVIDER_TOKEN": "vault://meshclaw/provider/api-token"
  }
}
```

The workflow result records only `PROVIDER_TOKEN` and the vault handle. During
execute mode the local adapter resolves the handle, injects the raw value into
the child process environment, redacts stdout/stderr, and writes evidence with
the handle rather than the secret. Remote adapters should use provider-native
secret stores or explicit future adapters; raw values are not copied into vssh
commands by this schema.

Execute-mode workflow steps run a vault preflight before action execution. If a
required handle is missing, the step fails with `vault handle preflight failed`
and records the missing handle in structured evidence. Missing-handle checks
include an `import_cli` hint so the operator can add the value locally without
pasting raw secrets into Codex, Claude, or workflow evidence.

Every workflow step result also carries a typed continuation classification:
`status`, optional `failure_kind`, and `next_action`. This keeps AI operators
from parsing prose to decide what to do next. For example, a missing secret
handle records `status: vault_missing`, `failure_kind: vault_missing`, and a
next action telling the operator to import the handle locally before rerunning
the targeted step.

Workflow steps can use common orchestration fields across domains:

- `depends_on`: block a step in execute mode unless prior steps completed with
  `status: ok`.
- `fallback_for`: execute a fallback step only when one of the referenced
  source steps failed.
- `timeout_seconds`: override the adapter default timeout for a specific local
  or vssh step.
- `retry`: retry transient local/vssh execution failures with structured
  attempt evidence.

Dependency blocks are recorded as typed outcomes (`dependency_missing` or
`dependency_blocked`) so Codex, Claude, and Cursor can rerun only the correct
upstream repair step instead of replaying the whole workflow blindly.

Retry evidence is deterministic: each attempt records `attempt`, `success`,
`exit_code`, `duration_ms`, optional error text, and whether another retry was
allowed. Retry policy can match exit codes or error substrings, and defaults to
retrying non-zero exits when `max_attempts` is greater than one.

Fallback evidence never hides the original failure. A failed source step remains
failed in `execution.json`; the fallback step records `fallback_for` and gets
`status: fallback_ok` if it succeeds. If the source step succeeded, the fallback
step is skipped with `status: fallback_not_needed`.

`meshclaw workflows resume` classifies these failures as `vault_missing` and
keeps the same `vault_checks` repair hints, so an AI operator can guide the user
to local import without ever asking for the raw secret.

## Product Boundary

Guard is part of MeshClaw Runtime. It is not a personal assistant and it is not
a replacement for password managers, provider secret stores, or operating system
keychains. It wraps those systems with AI-friendly policy, handles, evidence,
and approval semantics.
