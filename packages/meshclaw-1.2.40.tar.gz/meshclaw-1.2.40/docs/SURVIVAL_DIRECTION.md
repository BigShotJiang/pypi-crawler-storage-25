# MeshClaw Survival Direction

MeshClaw survives only if it stops competing with Codex, Claude, ChatGPT, and
Open WebUI.

Those products own conversation, reasoning, coding, screenshots, browsing, and
general assistant behavior. MeshClaw must not try to become another assistant.

MeshClaw should become the server operations judgement layer that AI operators
call when they need real infrastructure facts, permissions, security posture,
safe actions, policy decisions, and evidence.

## One Sentence

MeshClaw is the AI-native server operations judgement and control layer for
mixed private infrastructure.

## Product Boundary

MeshClaw owns:

- fleet inventory
- live server facts
- software inventory
- model/API/provider capability catalog
- workspace registry
- policy decisions
- permission management
- security posture
- evidence records
- service diagnostics
- log analysis
- security checks
- sensitive-data hygiene checks
- workload placement recommendations
- bounded auto-safe remediation
- approval-gated risky actions
- vssh-backed structured execution
- provisioning plans and later approval-gated provisioning

MeshClaw does not own:

- general chat
- assistant personality
- long-form reasoning
- coding agent behavior
- browser automation
- email/calendar/lifestyle automation
- skill marketplace behavior
- Matrix-first personal assistant UX

## Why It Is Still Needed

Codex and Claude can execute tools directly, but they do not automatically share
one operational source of truth. Without MeshClaw, each assistant sees a
different slice of servers, permissions, credentials, evidence, and workspace
state.

MeshClaw is valuable when multiple AI operators and humans need the same:

- current server state
- allowed actions
- safe execution path
- audit trail
- rollback evidence
- capacity and placement facts
- secret-safe capability access

The product value is not that MeshClaw can talk. The value is that every model
can ask MeshClaw, "What is true, what am I allowed to do, is it secure, what
should happen next, and what happened?"

## Competitive Shape

Kubernetes assumes workloads are shaped for a cluster.

MeshClaw assumes the user already has a messy real fleet:

- VPS nodes
- GPU boxes
- home servers
- Mac mini / MacBook nodes
- NAS devices
- Docker hosts
- local LLM machines
- provider APIs
- temporary rented capacity

MeshClaw should be closer to an AI-operated SRE console than to a chat app.

## Core Loop

```text
AI operator or human
  -> asks Codex / Claude / Open WebUI / Matrix
  -> model calls MeshClaw MCP
  -> MeshClaw reads inventory, policy, permissions, facts, logs, capabilities
  -> MeshClaw returns an evidence-backed plan
  -> model explains the plan
  -> MeshClaw executes only allowed safe actions
  -> risky actions require explicit approval
  -> MeshClaw stores evidence
```

## MVP That Matters

The product should become excellent at these workflows before adding anything
else:

1. `ops-control`
   - one command that tells the operator fleet health, risks, safe actions, and
     next commands.

2. `placement-plan`
   - choose where a workload should run using GPU, Docker, disk, memory,
     Ollama, vssh, and service facts.

3. `service-audit` and `service-check`
   - detect broken services and separate stale units from real incidents.

4. `service-triage`
   - inspect service failure candidates and classify them into real incidents,
     stale boot-only findings, ignore candidates, and approval-required actions.

5. `hygiene-scan-host`
   - find secrets/PII leaks in logs and configs without revealing raw values.

6. `workspace-list` and `workspace-activity`
   - track which model or human is working in which server/folder/branch.

7. `policy-check`
   - answer whether Codex, Claude, local LLM, Matrix, or automation may perform
     a given action.

8. `run-evidence` and vssh jobs
   - execute remote actions with structured output and evidence.

9. `provision-plan`
   - decide when existing capacity is not enough and propose temporary servers
     under budget policy.

## Non-Negotiable Rules

- No assistant persona.
- No "I am your helpful assistant" copy.
- No Matrix-first product direction.
- No raw secret values in model outputs.
- No destructive actions without explicit policy and evidence.
- No SSH-wrapper positioning for vssh.
- vssh must mean structured, parallel, daemon/RPC, evidence-friendly execution.
- Tailscale is the default network; vssh is the execution substrate.
- SSH is only compatibility fallback.
- Matrix is an operations room, not the brain.
- Codex/Claude/OpenWebUI/local models are the brains.

## Packaging Claim

The install story should stay simple:

```sh
pip install meshclaw
pip install vssh
```

`meshclaw` provides the operations control plane and MCP tools.

`vssh` provides the remote execution substrate.

## Next Product Milestone

MeshClaw is product-ready when a model can connect through MCP and reliably do:

```text
show fleet state
explain risks
choose the right node
inspect service/log/security evidence
classify service incidents
decide permissions and policy
run safe remediation
record evidence
ask for approval before risky actions
track which workspace changed
```

That is the lane. Anything outside this lane should be deleted, archived, or
kept as optional legacy compatibility.
