# Public Domains

MeshClaw uses separate public domains so the product message stays clear.

## meshclaw.run

Main product site for MeshClaw Runtime.

Positioning:

- AI-native operations runtime for real infrastructure
- MCP/CLI runtime used by Codex, Claude, Cursor, Open WebUI, and local LLMs
- Owns inventory, capability registry, policy, approval, workflows, evidence,
  vault handles, monitoring, and server operations decisions
- Does not present MeshClaw as a chatbot or generic assistant

Source artifact:

- `web/domains/meshclaw.run/index.html`

## meshclaw.sh

Install-focused domain.

Positioning:

- Short install page
- Optional shell installer at `/install.sh`
- Points operators back to `meshclaw.run`, GitHub, and PyPI

Source artifacts:

- `web/domains/meshclaw.sh/index.html`
- `web/domains/meshclaw.sh/install.sh`
- `web/domains/meshclaw.sh/_headers`

## mpop.dev

mpop-owned site. mpop should be described as fleet status and monitoring, not
as the MeshClaw runtime and not as an AI assistant.

Canonical deploy source now lives here with the other public web artifacts:

- `web/domains/mpop.dev/index.html`
- `web/domains/mpop.dev/install`

The mpop repository may keep a copy for project-local docs, but deployment
should use the consolidated source under this repository.

## Deployment Notes

`mpop.dev` is served from `v1` by nginx:

- nginx config: `/etc/nginx/sites-enabled/mpop.dev`
- web root: `/var/www/mpop.dev`
- local source: `web/domains/mpop.dev`

`meshclaw.run` and `meshclaw.sh` have matching nginx configs under
`web/nginx/`. They will serve correctly from `v1` once the domains point to the
same origin.

Deploy all three domains to `v1`:

```sh
scripts/deploy-web-v1.sh
```

The deploy script archives any existing `/var/www/<domain>` directory under
`/var/www/archive/` before replacing it from the local source.

Cleanup completed on May 19, 2026:

- `https://mpop.dev` was replaced from `web/domains/mpop.dev`
- previous `/var/www/mpop.dev` was archived on `v1` under `/var/www/archive/`
- local legacy site files were moved to
  `/Users/dragon/meshclaw-website-legacy-archive-20260519T105223Z`

`meshclaw.run` and `meshclaw.sh` are ready on `v1` nginx, but their public
Cloudflare routes still return 404 until the DNS/route is pointed at the v1
origin.
