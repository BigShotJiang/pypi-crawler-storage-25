# Current System Overview

Last updated: 2026-05-21

This is the handoff entry point for a new Codex, Claude, Cursor, or local LLM
operator joining the MeshClaw workspace.

MeshClaw is not a chatbot, a generic assistant, or a replacement for Codex,
Claude, SSH, Docker, or Kubernetes. MeshClaw is the AI-native operations
runtime that gives those AI operators shared infrastructure truth, policy,
safe execution, repeatable workflows, and evidence.

## Current Repository State

- Workspace: `/Users/dragon/meshclaw`
- Main development branch: `codex/serverops-runtime`
- GitHub remote: `git@github.com:meshclaw/meshclaw.git`
- Recent runtime checkpoint before this handoff document:
  `283d776 feat: recommend autoheal plan mcp followups`
- Check the latest local head with `git log -1 --oneline`.
- GitHub `codex/serverops-runtime` has the current work.
- GitHub `main` may lag behind the development branch.
- PyPI is not guaranteed to include the newest runtime work yet.
  - `meshclaw` latest observed on PyPI: `1.2.36`
  - `vssh` latest observed on PyPI: `4.2.0`

Before publishing a new package, run the release checklist in
`docs/RELEASE_CHECKLIST.md`.

## Product Position

AI operators:

```text
Codex / Claude / Cursor / Open WebUI / local LLM / Matrix room
  -> MeshClaw MCP or CLI
  -> inventory + capabilities + policy + workflows + vault handles + evidence
  -> vssh / local adapters / provider adapters / monitor agents
  -> servers / models / APIs / devices
```

MeshClaw owns:

- fleet inventory and operator-owned inventory overrides
- capability registry and capability recommendation
- policy and approval gates
- structured workflow execution
- evidence bundles
- workflow resume and execute preflight
- safe remediation planning
- guard/vault handle flows
- monitoring, service triage, log analysis, security and hygiene checks
- MCP and CLI surfaces for AI operators

MeshClaw does not own:

- general chat
- assistant personality
- coding-agent replacement behavior
- Matrix-first personal assistant UX
- lifestyle automation

## vssh Role

vssh is the remote execution substrate. It should not be positioned as a thin
SSH wrapper.

vssh should provide:

- daemon/RPC execution
- typed facts
- parallel multi-host execution
- structured results
- job start/status/log/cancel
- artifact collection
- policy-aware or evidence-friendly execution paths
- Tailscale/private-route operation without requiring public exposure

MeshClaw sits above vssh. MeshClaw decides what should happen, checks policy,
stores evidence, recommends next tools, and invokes vssh or other adapters.

## Canonical AI Operator Loop

AI clients should follow this loop:

1. Call `meshclaw_ai_guide` or read this document.
2. Call `meshclaw_server_list`.
3. Call `meshclaw_inventory_override_list`.
4. If the user clarifies private node meaning, call
   `meshclaw_inventory_override_set`.
5. Call `meshclaw_capability_validate` when capability selection matters.
6. Call `meshclaw_capability_recommend` for node/model/API/provider selection.
7. Call `meshclaw_workflow_list`.
8. Inspect or validate the target workflow.
9. Run dry-run first.
10. Read `meshclaw_evidence_latest`.
11. Use `meshclaw_workflow_plan_execute` before execute mode.
12. Grant explicit approvals only when needed.
13. Resume or execute targeted steps instead of replaying full workflows.

For live server operations, the shorter loop is:

```text
meshclaw_ops_control
  -> read recommended_mcp
  -> call the recommended next tool
  -> inspect evidence
  -> approve, repair, or execute only bounded safe actions
```

## Recent Runtime Capabilities

### Workflows

- `meshclaw run <workflow> --dry-run` writes:
  - `plan.md`
  - `execution.json`
  - `steps.jsonl`
  - `meshclaw-actions.md`
  - `report.html`
  - `capabilities.json`
  - `approvals.jsonl` when approval evidence is reused
- `meshclaw workflows inspect <workflow> --json` shows steps, adapters,
  policy decisions, approval gates, required nodes, required capabilities, and
  per-step `capability_hints`.
- `meshclaw workflows validate <workflow|file.json> --json` validates workflow
  structure before execution.
- `meshclaw workflows resume latest --json` reads evidence and creates a
  resume plan.
- `meshclaw workflows plan-execute latest --json` checks whether execute mode
  is ready or blocked.
- `meshclaw run <workflow> --execute --approvals latest --step id[,id] --json`
  can execute targeted approved steps.

### Capability Registry

- `meshclaw capabilities validate --json`
- `meshclaw capabilities recommend "<intent>" --json`
- MCP:
  - `meshclaw_capability_list`
  - `meshclaw_capability_validate`
  - `meshclaw_capability_recommend`

Capability recommendation now distinguishes:

- provider/API work, such as `cloudflare-api`
- browser/client/screenshot work, such as `macbook-controller`
- first-run mail planning, such as `mail-ops`
- concrete mail-server work, such as `c1-mail`
- model, automation, storage, provision, and general ops work

### Inventory Overrides

Operator-owned fleet meaning should not be hardcoded in source.

Local override file:

```text
~/.meshclaw/inventory_overrides.json
```

CLI:

```sh
meshclaw inventory-override list --json
meshclaw inventory-override set c1 --role mail-server --tag mail --tag mox --json
meshclaw inventory-override remove c1 --json
```

MCP:

- `meshclaw_inventory_override_list`
- `meshclaw_inventory_override_set`
- `meshclaw_inventory_override_remove`

### Recommended MCP Follow-ups

The server-ops tools now return `recommended_mcp` so AI clients do not need to
guess the next tool from prose.

Implemented:

- `meshclaw_ops_control`
- `meshclaw_service_triage`
- `meshclaw_autoheal_plan`
- `meshclaw_fleet_scan`
- `meshclaw_node_repair_plan`
- `meshclaw_workflow_plan_execute`

Current behavior:

- service real incident candidate:
  - `meshclaw_service_check`
  - `meshclaw_analyze_logs`
- stale or missing service target:
  - `meshclaw_service_check`
  - `meshclaw_policy_check`
- disk alert:
  - `meshclaw_disk_investigate`
- memory alert:
  - `meshclaw_process_top`
- offline or execution-health issue:
  - `meshclaw_node_repair_plan`
- fleet scan security finding:
  - `meshclaw_security_check`
- fleet scan log finding:
  - `meshclaw_analyze_logs`
- fleet scan hygiene finding:
  - `meshclaw_hygiene_scan_host`
- vssh auth/protocol/node repair blocker:
  - `meshclaw_vssh_auth_paths`
  - `meshclaw_vssh_daemon_audit`
  - `meshclaw_node_inventory`
- workflow execute approval blocker:
  - `meshclaw_approvals_grant`
- workflow execute vault blocker:
  - `meshclaw_guard_vault`
- workflow execute capability blocker:
  - `meshclaw_capability_validate`
- workflow execute ready state:
  - `meshclaw_workflow_run`
- auto-safe policy-allowed action:
  - `meshclaw_autoheal_apply_safe`
- all operational loops:
  - `meshclaw_evidence_latest`

### Autoheal and Service Triage

- `meshclaw service-triage --json` audits failed/restarting services, filters
  boot-only noise, and recommends structured follow-up MCP calls.
- `meshclaw autoheal-plan --json` returns:
  - `actions`
  - `recommended_mcp`
  - `report`
  - evidence reference
- `meshclaw autoheal-apply-safe` only executes actions where:
  - `mode=auto_safe`
  - `policy_decision=allow`
  - `approval_required=false`

Approval-required and read-only actions are skipped or routed to evidence and
policy tools.

### Guard and Vault Direction

Guard is model-less by default. It detects, redacts, and routes sensitive values
without relying on a tuned LLM.

The local-model idea remains useful as an optional local conversation surface
for secret handling, but MeshClaw core should stay deterministic:

- detect secrets
- redact outputs
- store vault handles
- inject secrets through `secret_env`
- never expose raw secret values through MCP

See `docs/GUARD.md`.

## Important Commands

Basic local verification:

```sh
go test ./...
PYTHONPATH=src python3 -m pytest tests/test_python_cli.py -q
go build -o /Users/dragon/bin/meshclaw ./cmd/meshclaw
```

Server-ops loop:

```sh
/Users/dragon/bin/meshclaw ops-control --json
/Users/dragon/bin/meshclaw service-triage --limit 5 --json
/Users/dragon/bin/meshclaw autoheal-plan --json
/Users/dragon/bin/meshclaw evidence open latest
```

Workflow loop:

```sh
/Users/dragon/bin/meshclaw workflows --json
/Users/dragon/bin/meshclaw workflows inspect fleet-health-demo --json
/Users/dragon/bin/meshclaw run fleet-health-demo --dry-run --json
/Users/dragon/bin/meshclaw workflows plan-execute latest --json
/Users/dragon/bin/meshclaw evidence open latest
```

MCP smoke test:

```sh
printf '{"jsonrpc":"2.0","id":1,"method":"tools/list"}\n' \
  | /Users/dragon/bin/meshclaw mcp \
  | jq -r '.result.tools[].name' \
  | awk '/[^A-Za-z0-9_]/ {print}'
```

The smoke test should print nothing. MCP tool names must use underscores, not
dots.

## Evidence Location

Evidence is stored under:

```text
/Users/dragon/.meshclaw/evidence
```

Latest workflow/runtime bundles usually include:

- `plan.md`
- `execution.json`
- `steps.jsonl`
- `meshclaw-actions.md`
- `report.html`
- workflow-specific artifacts

AI operators should treat `execution.json` as the source of truth and
`steps.jsonl` as the timeline.

## Known State and Gaps

Known current state:

- The latest development work is on `codex/serverops-runtime`.
- PyPI packages may lag behind the branch.
- `main` may lag behind the branch.
- Tailscale is the default network assumption.
- vssh-native is the preferred execution path.
- SSH fallback remains compatibility-only.

Gaps to close next:

1. Merge or PR `codex/serverops-runtime` into the intended public branch.
2. Decide the next PyPI release version for `meshclaw`.
3. Run `docs/RELEASE_CHECKLIST.md`.
4. Publish PyPI only after intentional operator approval.
5. Extend `recommended_mcp` to more tools where useful:
   - `fleet-service-audit`
   - `placement-plan`
   - `provision-plan`
6. Continue productizing Guard and vault handle flows.
7. Keep Matrix/Open WebUI as frontends, not the core product.
8. Keep docs English-first and update this overview after each major runtime
   milestone.

## Files to Read First

For a new operator:

1. `docs/CURRENT_SYSTEM_OVERVIEW.md`
2. `README.md`
3. `docs/PRODUCTIZATION.md`
4. `docs/MCP_SETUP.md`
5. `docs/GUARD.md`
6. `docs/INVENTORY.md`
7. `docs/RELEASE_CHECKLIST.md`

For implementation details:

- `cmd/meshclaw/main.go`
- `cmd/meshclaw/mcp.go`
- `internal/runtimeflow/`
- `internal/capability/`
- `internal/inventory/`
- `internal/policy/`
- `internal/guardvault/`
- `internal/workflow/`

## Rule for Future Operators

Do not restart the project from scratch.

Use MeshClaw as a runtime/control-plane project. Keep the conversation in
Codex, Claude, Cursor, Open WebUI, local LLMs, or Matrix. Make MeshClaw better
at shared facts, policy, evidence, execution, workflows, remediation,
capability selection, and secret-safe operations.
