# Productization Plan

For current handoff state, active branch, latest runtime capabilities, and the
next development path, read `docs/CURRENT_SYSTEM_OVERVIEW.md` first.

MeshClaw should productize the existing MeshPOP pieces instead of rebuilding
them.

## Product Stack

```text
AI operators
  Codex / Claude / Cursor / Open WebUI local models
    -> MeshClaw MCP
       -> inventory
       -> capability vault
       -> policy
       -> capacity and budget
       -> doctor
       -> audit/evidence
       -> provisioners
       -> vssh-native / monitor-agent / vault / meshdb
```

## Existing Components To Reuse

| Component | Path | Product Role |
| --- | --- | --- |
| vssh runtime | `/Users/dragon/meshpop-repos/vssh` | sshd-free structured execution, RPC, facts, and evidence |
| MeshClaw runtime adapter | this repo | vssh-native first, SSH fallback for legacy nodes |
| mpop | `/Users/dragon/meshpop-repos/mpop-go` | agentless fleet status and metrics |
| meshpop-mcp | `/Users/dragon/meshpop-repos/meshpop-mcp` | legacy MCP bridge reference |
| vault-go | `/Users/dragon/meshpop-repos/vault-go` | future use-only secret and API capability layer |
| meshdb-go | `/Users/dragon/meshpop-repos/meshdb-go` | optional evidence/history/search backend |
| mesh-event | `/Users/dragon/meshpop-repos/mesh-event` | append-only event/evidence model |
| wire | `/Users/dragon/meshpop-repos/wire` | optional advanced Wire backend; not the default first product |

## Packaging

The public install story should be:

```sh
pip install meshclaw
pip install vssh
meshclaw quickstart
meshclaw setup-check
```

`meshclaw` should execute through vssh-native first and use SSH only as a
legacy fallback.

`quickstart` is the first product-quality value path: it runs setup diagnostics,
preflights the default workflow, and writes a dry-run evidence bundle.
`setup-check` is the narrower health gate. It should make binary conflicts,
missing VSSH secrets, missing MCP client config, policy problems, and evidence
directory problems explicit before an AI operator starts executing fleet
workflows.

Default networking should be Tailscale-first:

```text
1. Tailscale / MagicDNS / 100.x IP + vssh server
2. OpenSSH over reachable addresses as fallback
3. monitor-agent for continuous fleet evidence
4. optional custom Wire backend
```

## MeshClaw Product Boundary

MeshClaw is not a skill marketplace and not a personal assistant. It exposes
infrastructure facts and safe actions:

- nodes
- services
- model endpoints
- API capabilities
- policy checks
- budget/cost gates
- provision plans
- safe execution
- evidence and audit

AI operators own planning and conversation.

## Provisioning Direction

VPS/GPU rental can become an agent-facing capability:

```text
capacity_list
provision_plan
provision_server      approval-gated
bootstrap_server
attach_to_mesh
run_workload
collect_results
deprovision_server    approval-gated or automatic on TTL
```

Rules:

- planning is allowed without approval
- cost-incurring actions require explicit approval
- secrets are use-only and never revealed by default
- temporary servers must get TTL, owner, purpose, and teardown policy
- every provision/deprovision action emits evidence

## First Product Milestone

1. Keep `meshclaw mcp` as the AI-facing control plane for Codex, Claude, and
   local LLM frontends.
2. Promote capability vault schema to `~/.meshclaw/capabilities.json`, merged
   with inventory-discovered node capabilities.
3. Add policy checks for command risk, external API use, mail operations, DNS
   changes, account operations, and provisioning cost.
4. Add `provision_plan` as a dry-run tool.
5. Keep actual server rental, DNS changes, account creation, and email sends
   behind an approval gate.
6. Add PyPI packaging after the CLI/MCP shape stabilizes.

Current runtime milestone:

- `meshclaw run <workflow> --dry-run` writes `plan.md`, `execution.json`,
  `steps.jsonl`, `capabilities.json`, `approvals.jsonl` when approval evidence
  is reused, `meshclaw-actions.md`, and `report.html`.
- `meshclaw_workflow_list` returns workflow metadata, approval actions, and
  executable adapters so AI operators do not need to infer semantics from prose.
- `meshclaw_adapter_list` and `meshclaw adapters --json` expose the runtime
  adapter registry. The runtime core can distinguish executable adapters
  (`local`, `vssh`) from evidence-only placeholders (`manual`, `policy`,
  `mail`, `dns`, `browser`, `cloud`).
- `meshclaw_workflow_inspect` returns workflow preflight details: steps,
  approval gates, policy decisions, required nodes/adapters, and matching
  capability IDs before execution.
- `meshclaw_workflow_resume` reads `execution.json` from a prior evidence
  bundle and writes `resume-plan.json`, classifying failed, retryable,
  approval-pending, and ready-for-execute steps. Resume items include action,
  resource, approval actor/time/source, and the next recommended action.
- `meshclaw_workflow_plan_execute` turns the latest evidence bundle into an
  execute-mode preflight: `ready`, approval blockers, vault blockers, retryable
  failures, repair needs, capability-registry validation, and the exact execute
  CLI/MCP call when safe.
- `meshclaw_approvals_grant` and `meshclaw approvals grant` append approval
  records to `approvals.jsonl`; resume plans then mark those steps as
  `approved_ready`.
- `meshclaw run <workflow> --execute --approvals latest` loads prior approval
  evidence and attaches approval actor/time/reason/source to matching
  `execution.json` step results. Executable `local` and `vssh` adapters can run
  after approval; non-executable adapters remain structured skipped results.
- `meshclaw run <workflow> --step id[,id]` runs only selected workflow steps,
  which lets an AI operator follow a resume plan without replaying the full
  workflow.
- `meshclaw workflows validate <workflow|file.json>` validates workflow
  structure before a run. It catches duplicate IDs, unknown adapters, missing
  commands, broken dependencies/fallbacks, invalid vault handles and
  `secret_env` mappings, and policy-denied steps. Invalid workflows exit
  non-zero even with `--json`, so the command can be used in CI and by AI
  operators before execute mode.
- Workflow execution has bounded step timeouts. Defaults are `local=90s` and
  `remote=15s`; use `MESHCLAW_WORKFLOW_LOCAL_TIMEOUT_SECONDS` and
  `MESHCLAW_WORKFLOW_REMOTE_TIMEOUT_SECONDS` for heavier diagnostics. Timeout
  kills the whole subprocess group so stuck `ssh`, `vssh`, or model processes
  do not leak after the workflow moves on.
- `meshclaw-actions.md` and `report.html` include an AI handoff section:
  `execution.json` is the source of truth, `steps.jsonl` is the timeline, and
  approval-required skips are intentional gates rather than failures.
- JSON workflow files are loaded from `./workflows`, `~/.meshclaw/workflows`,
  or `MESHCLAW_WORKFLOW_DIR`, so domain demos can live outside the runtime
  engine. `examples/workflows/` contains OSS-facing workflow templates:
  `fleet-health.json`, `service-triage-autoheal.json`, and
  `model-worker-orchestration.json`. These are generic starting points for
  users to copy and adapt before execute mode. `fleet-health-demo` remains the
  built-in generic sample workflow.
  `meshclaw-ops-orchestration-demo` is the current product narrative workflow:
  it combines inventory, capability placement, mail/DNS approval gates, local
  model lanes, service triage, autoheal planning, cleanup planning, screenshot
  evidence placeholders, and a human-readable report.
- `meshclaw_capability_list` returns configured capabilities plus dynamic
  inventory-derived node capabilities.
- `meshclaw_capability_validate` and `meshclaw capabilities validate [file]`
  validate capability registries before AI placement or execute mode, returning
  structured errors and warnings for bad kind, provider, duplicate id,
  secret-policy, and missing capability tags.
- `meshclaw_capability_recommend` and `meshclaw capabilities recommend <intent>`
  turn natural operator intent into scored capability candidates with reasons,
  approval flags, and secret-handling cautions. This gives Codex, Claude,
  Cursor, and local models a stable path for model/API/node selection before
  workflow execution.
- Workflow inspection now includes `capability_hints`, a per-step list of
  recommended capability IDs, so AI operators can see the intended runtime
  surface before executing or resuming a workflow.
- Workflow execution results now carry `capability_class` and
  `capability_hints` per step in `execution.json`, `steps.jsonl`, and
  `meshclaw-actions.md`. Evidence bundles therefore preserve why an agent saw a
  step as mail, model, automation, storage, provisioning, API, or general ops
  work.
- `meshclaw_inventory_override_list`, `meshclaw_inventory_override_set`, and
  `meshclaw_inventory_override_remove` expose operator-owned role/tag
  refinements through MCP, so Codex, Claude, and Cursor can persist private
  fleet meaning without hardcoding it into MeshClaw.
- `meshclaw_ai_guide` and `meshclaw_mcp_surface` now describe the canonical
  operating loop for AI clients: inventory, operator overrides, capability
  validation, capability recommendation, workflow dry-run, evidence review,
  approval or repair, then targeted execute/resume.
- `meshclaw workflows inspect` and generated `meshclaw-actions.md` now surface
  the same operating loop and per-step capability hints, making the runtime
  rationale visible in both preflight and evidence handoff.
- Capability recommendation scoring distinguishes provider/API work
  (`cloudflare-api`), client/browser work (`macbook-controller`), first-run mail
  planning (`mail-ops`), and concrete mail-server work (`c1-mail`) so workflow
  hints are less noisy.
- `meshclaw_tool_recommend` now routes role/tag clarification to
  `meshclaw_inventory_override_set` and placement/model/API questions to
  `meshclaw_capability_recommend`, nudging AI clients into the canonical loop
  before workflow execution.
- `meshclaw_autoheal_plan` returns one policy-annotated action list across CLI,
  MCP, and `ops-control`; each action includes `policy_decision` and
  `approval_required`.
- `meshclaw_ops_control`, `meshclaw_fleet_scan`,
  `meshclaw_service_triage`, `meshclaw_autoheal_plan`,
  `meshclaw_node_repair_plan`, and `meshclaw_workflow_plan_execute` now return
  `recommended_mcp`, giving AI operators structured follow-up tool calls
  instead of requiring them to infer the next action from prose.
- `meshclaw_autoheal_apply_safe` is plan-based and only executes actions where
  `mode=auto_safe`, `policy_decision=allow`, and `approval_required=false`.
  Non-safe or approval-required actions are stored as skipped evidence.
- `meshclaw_data_clean_plan` writes a deletion manifest plus a structured JSONL
  sidecar containing `category`, `risk`, `size_kb`, and `reason` for AI review.
- `meshclaw placement-plan` now scores candidates with both live inventory and
  capability registry facts, while avoiding irrelevant fallback candidates.
