# Frontends

MeshClaw does not force one UI.

The frontend rule is simple: the frontend talks; MeshClaw proves and acts.

## Matrix

Matrix is the shared operations room.

Use it for:

- people and friends watching the same timeline
- Codex, Claude, and local model handoff
- approvals
- screenshots
- evidence links
- shared incident context

Test locally:

```sh
meshclaw ops-dispatch matrix "!workers"
meshclaw ops-dispatch matrix "!workspaces"
meshclaw ops-dispatch matrix "서버 상태 보여줘"
```

Run the real bridge:

```sh
meshclaw matrix-config-init --force
meshclaw matrix-post "MeshClaw Matrix bridge connected"
meshclaw matrix-bridge
```

In the room:

```text
!workers
!workspaces
!fleet
!policy
!evidence
```

## Open WebUI

Open WebUI is the local/private model frontend.

Use it for:

- local model chat
- private log analysis
- redacted summaries
- trying local agents against MeshClaw MCP

Test locally:

```sh
meshclaw ops-dispatch openwebui "workers"
meshclaw ops-dispatch openwebui "workspaces"
meshclaw ops-dispatch openwebui "현재 워크스페이스 등록"
```

## Codex / Claude Apps

Codex and Claude remain strong primary work surfaces. They can use MeshClaw MCP
for DevOps facts and execution while keeping their own native tools, skills,
screenshots, and coding workflows.

Use MeshClaw from Codex/Claude when the request needs:

- fleet truth shared across tools
- evidence
- policy-gated execution
- safe remediation
- workspace tracking
- placement/capacity decisions

## Difference

```text
Matrix     = shared room, approvals, evidence timeline
Open WebUI = local/private model chat frontend
Codex      = coding/tool/workspace operator
Claude     = reasoning/review/planning operator
MeshClaw   = common policy, workspace, evidence, DevOps runtime
vssh       = remote execution substrate
```
