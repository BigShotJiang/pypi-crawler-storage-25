# MCP Setup

MeshClaw is not a chat assistant. Codex, Claude, Cursor, Open WebUI, or a local
LLM talks to the user. MeshClaw exposes server state, policy decisions, safe
execution, cleanup plans, workflow runs, and evidence as tools.

## Binary

Install from PyPI:

```sh
pip install -U meshclaw vssh
meshclaw --install-binary
meshclaw --print-binary
```

Build locally:

```sh
cd /Users/dragon/meshclaw
go build -o /Users/dragon/bin/meshclaw ./cmd/meshclaw
```

Run the MCP server:

```sh
/Users/dragon/bin/meshclaw mcp
```

Verify the local setup before connecting or debugging an AI client:

```sh
meshclaw quickstart --json
meshclaw setup-check --json
meshclaw doctor --json
```

`quickstart` runs the first 5 minutes path in one safe command: setup doctor,
workflow inspection, dry-run evidence bundle, and next actions. `setup-check`
and `doctor` report the effective MeshClaw binary, the effective VSSH binary,
stale VSSH binaries elsewhere on PATH, whether a VSSH secret source is
configured, and which Codex/Claude/Cursor MCP config files mention MeshClaw.

## Codex/Claude/Cursor MCP Command

Use this command for the MCP server:

```text
meshclaw mcp
```

For a pinned local binary, use `/Users/dragon/bin/meshclaw mcp` or set
`MESHCLAW_BIN=/Users/dragon/bin/meshclaw` before launching the PyPI wrapper.

Recommended environment when vssh-native is enabled:

```text
MESHCLAW_VSSH_BINARY=/Users/dragon/bin/vssh
VSSH_SECRET=<same secret used by vsshd on the fleet>
```

Codex config example:

```toml
[mcp_servers.meshclaw]
command = "/Users/dragon/bin/meshclaw"
args = ["mcp"]

[mcp_servers.meshclaw.env]
MESHCLAW_VSSH_BINARY = "/Users/dragon/bin/vssh"
VSSH_SECRET = "..."
```

Claude Desktop / Cursor JSON shape:

```json
{
  "mcpServers": {
    "meshclaw": {
      "command": "/Users/dragon/bin/meshclaw",
      "args": ["mcp"],
      "env": {
        "MESHCLAW_VSSH_BINARY": "/Users/dragon/bin/vssh",
        "VSSH_SECRET": "..."
      }
    }
  }
}
```

Without these variables MeshClaw can still start, but native remote execution
may fall back or fail depending on node configuration. MeshClaw uses:

- vssh-native first execution over Tailscale/private routes
- `/Users/dragon/.meshclaw/evidence` for local evidence records
- policy from `~/.meshclaw/policy.json` or `MESHCLAW_POLICY_FILE`
- capabilities from `~/.meshclaw/capabilities.json` or
  `MESHCLAW_CAPABILITY_FILE`

Default execution requires `Tailscale/private route + vssh server + VSSH_SECRET`.
SSH remains a compatibility fallback for nodes without vssh daemon coverage.

## Canonical Tools

- `meshclaw_ai_guide`
- `meshclaw_quickstart`
- `meshclaw_doctor`
- `meshclaw_tool_recommend`
- `meshclaw_workflow_list`
- `meshclaw_workflow_inspect`
- `meshclaw_workflow_run`
- `meshclaw_workflow_plan_execute`
- `meshclaw_workflow_resume`
- `meshclaw_evidence_latest`
- `meshclaw_ops_control`
- `meshclaw_inventory_override_list`
- `meshclaw_inventory_override_set`
- `meshclaw_inventory_override_remove`
- `meshclaw_capability_list`
- `meshclaw_capability_validate`
- `meshclaw_capability_recommend`
- `meshclaw_autoheal_plan`
- `meshclaw_autoheal_apply_safe`
- `meshclaw_service_triage`
- `meshclaw_service_check`
- `meshclaw_disk_investigate`
- `meshclaw_data_clean_plan`
- `meshclaw_guard_modes`
- `meshclaw_guard_model`
- `meshclaw_guard_vault`
- `meshclaw_guard_vault_list`
- `meshclaw_guard_vault_metadata`
- `meshclaw_guard_detect`
- `meshclaw_guard_redact`
- `meshclaw_guard_posture`
- `meshclaw_guard_vuln`
- `meshclaw_policy_check`
- `meshclaw_run_evidence`

Tool names must use alphanumeric characters and underscores only. Do not use
legacy dotted names such as `meshclaw.autoheal_plan`.

## First MCP Workflow

When an AI client has just connected, use this sequence before any mutating
operation:

1. Call `meshclaw_ai_guide` or `meshclaw_mcp_surface`.
2. Call `meshclaw_server_list` to read current inventory truth.
3. Call `meshclaw_inventory_override_list`; if the user clarifies private fleet
   meaning, call `meshclaw_inventory_override_set`.
4. Call `meshclaw_capability_validate` if placement, model/API selection, or
   execute mode depends on local capabilities.
5. Call `meshclaw_capability_recommend` when the model needs to choose a
   node, model, API, storage lane, mail server, or provisioner for an intent.
6. Call `meshclaw_workflow_list`.
7. For user-authored workflows or files under `examples/workflows`, call
   `meshclaw_workflow_validate` first.
8. Start with `meshclaw_workflow_run` using
   `{"name":"fleet-health-demo","mode":"dry-run"}`.
9. Call `meshclaw_evidence_latest` and read `execution.json`,
   `steps.jsonl`, and `meshclaw-actions.md`.
10. Call `meshclaw_workflow_plan_execute` before execute mode; it returns
   `ready`, approval blockers, vault blockers, repair blockers,
   capability-registry validity, and the exact execute call when safe to
   continue. It also returns `recommended_mcp`; follow those structured tool
   calls before guessing from prose.
11. Use `meshclaw_workflow_resume` if any step is failed, retryable,
   degraded, or approval-pending.

When the model is unsure which tool to use, call `meshclaw_mcp_surface` or
`meshclaw_tool_recommend` before running low-level tools. The default product
path is workflow/policy/evidence first; direct vssh is for transport debugging
or low-level primitives.

Use `meshclaw-ops-orchestration-demo` only when the operator wants the full
private fleet/email/model orchestration narrative. It is the advanced demo, not
the default OSS smoke test.

## Operating Rule

Read-only and evidence-producing tools are allowed by default. Mutating actions
must be represented as plan/apply flows:

- `meshclaw_ops_control`, `meshclaw_fleet_scan`,
  `meshclaw_service_triage`, `meshclaw_autoheal_plan`,
  `meshclaw_node_repair_plan`, and `meshclaw_workflow_plan_execute` return
  `recommended_mcp`. AI clients should follow those structured calls instead
  of inferring the next action from human prose.
- `meshclaw_autoheal_plan` returns `policy_decision` and `approval_required`
  for every action.
- `meshclaw_autoheal_apply_safe` executes only `mode=auto_safe`,
  `policy_decision=allow`, `approval_required=false` actions.
- `meshclaw_data_clean_plan` creates a path manifest plus structured JSONL
  sidecar with category, risk, size, and reason.
- `meshclaw_data_clean_apply` applies only a generated manifest and remains
  approval-gated by policy.
- service quarantine/remove actions require approval and post-action evidence.

Policy is loaded from `~/.meshclaw/policy.json`, or `MESHCLAW_POLICY_FILE`.
Configured rules are evaluated before built-in defaults.

## Claude/Codex Use

Claude and Codex should use MeshClaw MCP when they need shared operational
truth:

- current fleet state
- service/log/security evidence
- workload placement
- safe remediation candidates
- policy decisions
- evidence-backed remote execution

They should not use MeshClaw as a conversation model. The model talks to the
user; MeshClaw answers tool calls.
