# Release Checklist

MeshClaw releases should prove the CLI and MCP surface before publishing
packages.

## Preflight

```sh
go test ./...
go build -o /Users/dragon/bin/meshclaw ./cmd/meshclaw
/Users/dragon/bin/meshclaw help
/Users/dragon/bin/meshclaw ai-guide --json
/Users/dragon/bin/meshclaw workflows --json
/Users/dragon/bin/meshclaw run fleet-health-demo --dry-run --json
printf '{"jsonrpc":"2.0","id":1,"method":"tools/list"}\n' | /Users/dragon/bin/meshclaw mcp
```

The MCP tool-name smoke test must return no dotted names:

```sh
printf '{"jsonrpc":"2.0","id":1,"method":"tools/list"}\n' \
  | /Users/dragon/bin/meshclaw mcp \
  | jq -r '.result.tools[].name' \
  | awk '/[^A-Za-z0-9_]/ {print}'
```

## Python Package

The PyPI package is a Python entrypoint wrapper around the Go binary. Keep
`pyproject.toml` and `src/meshclaw/__init__.py` versions aligned.

Build locally:

```sh
rm -rf dist/*
python3 -m build
python3 -m twine check dist/*
```

Install-test from the generated wheel:

```sh
python3 -m venv /tmp/meshclaw-release-venv
/tmp/meshclaw-release-venv/bin/python -m pip install dist/meshclaw-*.whl
/tmp/meshclaw-release-venv/bin/meshclaw --print-binary
MESHCLAW_BIN=/Users/dragon/bin/meshclaw /tmp/meshclaw-release-venv/bin/meshclaw help
```

Wrapper-specific smoke tests:

```sh
meshclaw init --json
meshclaw doctor --json
meshclaw --install-binary
meshclaw --print-binary
MESHCLAW_AUTO_INSTALL=0 meshclaw --no-auto-install help
```

## Publish Gates

- `fleet-health-demo` dry-run creates an evidence bundle with `plan.md`,
  `execution.json`, `steps.jsonl`, `meshclaw-actions.md`, and `report.html`.
- `meshclaw_workflow_list` identifies `fleet-health-demo` as the default
  workflow and `meshclaw-ops-orchestration-demo` as the advanced private demo.
- `meshclaw_evidence_latest` returns bundle paths without leaking secrets.
- Mutating operations remain policy-gated.
- No secrets, tokens, DKIM keys, account passwords, or provider credentials are
  present in generated evidence or docs.

Publish only after the operator intentionally authorizes PyPI upload:

```sh
python3 -m twine upload dist/*
```
