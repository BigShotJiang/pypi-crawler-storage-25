"""Data models for the Zededa Edge Intelligence Platform client."""

__all__ = []
