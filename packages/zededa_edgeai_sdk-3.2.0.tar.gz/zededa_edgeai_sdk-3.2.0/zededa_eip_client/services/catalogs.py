"""Catalog management service for user access and token scoping.

Provides functionality to discover available organizations and obtain
organization-specific authentication tokens.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import requests

from .http import HTTPService

__all__ = ["CatalogService"]


class CatalogService:
    """Service for managing organization discovery and authentication token scoping.
    
    Handles retrieving available organizations for authenticated users and
    obtaining organization-specific authentication tokens with appropriate
    permissions for accessing organization resources.
    """

    def __init__(self, backend_url: str, http: HTTPService) -> None:
        """Initialize catalog service with backend URL and HTTP client.
        
        Sets up the service to communicate with the catalog management
        endpoints using the provided HTTP service for consistent
        request handling and debug logging.
        """
        self.backend_url = backend_url.rstrip("/")
        self.http = http

    def get_catalogs(self, backend_jwt: str) -> Dict[str, Any]:
        """Retrieve organization information for the authenticated user.
        
        Queries the user-info endpoint to get organization access information,
        returning both available_catalogs (what user has access to) and
        all_catalogs (complete list for selection UI) in a structured format.
        
        Also extracts user information including system role and permissions.
        
        Returns
        -------
        Dict[str, Any]
            Dictionary containing:
            - available_catalogs: List of organizations user has access to
            - all_catalogs: Complete list of organizations for selection UI
            - user_info: User information including role and permissions
        """
        url = f"{self.backend_url}/api/v1/user-info"
        headers = {"Authorization": f"Bearer {backend_jwt}"}
        try:
            response = self.http.request("GET", url, headers=headers)
        except requests.RequestException as exc:
            print(f"[ERROR] Unable to fetch catalogs: {exc}")
            return {"available_catalogs": [], "all_catalogs": [], "user_info": {}}

        if response.status_code != 200:
            print(f"[ERROR] Failed to fetch catalogs: {response.status_code} {response.text}")
            return {"available_catalogs": [], "all_catalogs": [], "user_info": {}}

        try:
            data = response.json() or {}
        except ValueError:
            return {"available_catalogs": [], "all_catalogs": [], "user_info": {}}

        if not isinstance(data, dict):
            return {"available_catalogs": [], "all_catalogs": [], "user_info": {}}

        # Process available_catalogs (what user has access to)
        available_catalogs_list: List[Dict[str, Any]] = []
        available_catalogs = data.get("available_catalogs")
        if isinstance(available_catalogs, list):
            for catalog in available_catalogs:
                if isinstance(catalog, str):
                    available_catalogs_list.append({"organization_id": catalog})
                elif isinstance(catalog, dict):
                    organization_id = catalog.get("organization_id")
                    if organization_id:
                        normalized = dict(catalog)
                        normalized.pop("catalog_id", None)
                        normalized.pop("org_id", None)
                        normalized.setdefault("organization_id", organization_id)
                        available_catalogs_list.append(normalized)

        # Process all_catalogs (complete list for selection UI)
        all_catalogs_list: List[Dict[str, Any]] = []
        all_catalogs = data.get("all_catalogs")
        if isinstance(all_catalogs, list):
            for catalog in all_catalogs:
                if isinstance(catalog, str):
                    all_catalogs_list.append({"organization_id": catalog})
                elif isinstance(catalog, dict):
                    organization_id = catalog.get("organization_id")
                    if organization_id:
                        normalized = dict(catalog)
                        normalized.pop("catalog_id", None)
                        normalized.pop("org_id", None)
                        normalized.setdefault("organization_id", organization_id)
                        all_catalogs_list.append(normalized)

        # Extract enhanced user information including role
        user_info: Dict[str, Any] = {
            "user_id": data.get("sub"),
            "email": data.get("email"),
            "name": data.get("name"),
            "organization_role": data.get("organization_role"),  # superadmin, super_observer, or None
            "permissions": data.get("permissions", {}),
            "catalog_assignments": data.get("catalog_assignments", []),
        }

        return {
            "available_catalogs": available_catalogs_list,
            "all_catalogs": all_catalogs_list,
            "user_info": user_info,
        }

    def get_catalog_scoped_token(self, backend_jwt: str, organization_id: str) -> Optional[Dict]:
        """Request an organization-specific authentication token.
        
        Exchanges a general authentication token for an organization-scoped token
        with permissions limited to the specified organization, enabling secure
        access to organization-specific resources and operations.
        """
        url = f"{self.backend_url}/api/v1/auth/catalog-scoped-token"
        headers = {
            "Authorization": f"Bearer {backend_jwt}",
            "Content-Type": "application/json",
        }
        payload = {
            "catalog_id": organization_id,
        }
        try:
            response = self.http.request("POST", url, headers=headers, json=payload)
        except requests.RequestException as exc:
            print(f"[ERROR] Catalog scoped token request failed: {exc}")
            return None

        if response.status_code != 200:
            print(f"[ERROR] Catalog scoped token request failed: {response.status_code} {response.text}")
            return None

        try:
            return response.json()
        except ValueError:
            print("[ERROR] Catalog scoped token response is not valid JSON")
            return None

