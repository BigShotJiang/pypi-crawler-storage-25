"""HTTP service providing debug-aware request handling.

Wraps the requests library with automatic logging of request/response
data while masking sensitive information for security.
"""

from __future__ import annotations

import os
from typing import Any, Dict, Optional

import requests

__all__ = ["HTTPService"]


class HTTPService:
    """HTTP client with debug logging and sensitive data masking.
    
    Wraps the requests library to provide consistent HTTP functionality
    with optional debug output that safely masks sensitive information
    like tokens, passwords, and keys in request/response logs.
    
    Supports automatic injection of X-Catalog-ID header for catalog-scoped
    API requests when catalog context is set.
    """

    _SENSITIVE_TERMS = {
        "password",
        "secret",
        "token",
        "authorization",
        "access_key",
        "jwt",
    }

    def __init__(self, *, debug: bool = False) -> None:
        """Initialize HTTP service with optional debug logging enabled.
        
        When debug is True, all HTTP requests and responses will be
        logged to the console with sensitive data automatically masked.
        """
        self.debug = debug
        # Store catalog context for X-Catalog-ID header injection
        self._organization_id: Optional[str] = None

    def set_catalog_context(self, organization_id: Optional[str]) -> None:
        """Set the current catalog context for X-Catalog-ID header injection.
        
        When set, the X-Catalog-ID header will be automatically included
        in all HTTP requests. The instance-level context takes precedence
        over the EDGEAI_CURRENT_ORG environment variable, which is only used
        as a fallback when no instance context is set.
        """
        self._organization_id = organization_id

    def get_catalog_context(self) -> Optional[str]:
        """Get the current catalog context.

        Returns the org ID from the instance context if set; otherwise,
        falls back to the EDGEAI_CURRENT_ORG environment variable.
        """
        return self._organization_id or os.environ.get("EDGEAI_CURRENT_ORG")

    def _get_default_headers(self) -> Dict[str, str]:
        """Get default headers including X-Catalog-ID if set.
        
        Returns headers that should be included in all requests,
        particularly the X-Catalog-ID header for catalog-scoped operations.
        """
        headers: Dict[str, str] = {}
        organization_id = self.get_catalog_context()
        if organization_id:
            headers["X-Catalog-ID"] = organization_id
        return headers

    def request(
        self,
        method: str,
        url: str,
        *,
        headers: Dict[str, str] | None = None,
        json: Dict[str, Any] | None = None,
        params: Dict[str, Any] | None = None,
        timeout: int = 30,
    ):
        """Execute HTTP request with automatic debug logging and error handling.
        
        Sends HTTP requests using the requests library while providing
        debug output when enabled. All sensitive data in requests and
        responses is automatically masked for security.
        
        Automatically includes X-Catalog-ID header when catalog context is set.
        """
        # Merge caller headers with default headers (caller headers take precedence)
        final_headers = self._get_default_headers()
        if headers:
            final_headers.update(headers)

        self._print_debug(method, url, payload=json, headers=final_headers, params=params)
        try:
            response = requests.request(
                method,
                url,
                headers=final_headers,
                json=json,
                params=params,
                timeout=timeout,
            )
        except requests.RequestException as exc:  # pragma: no cover - passthrough
            if self.debug:
                print(f"[DEBUG] Request failed: {exc}")
            raise

        self._log_response(response)
        return response

    def get(
        self,
        url: str,
        *,
        headers: Dict[str, str] | None = None,
        params: Dict[str, Any] | None = None,
        timeout: int = 30,
    ) -> Dict[str, Any]:
        """Execute GET request and return JSON response.
        
        Convenience method that wraps request() and automatically parses
        the JSON response. Raises exception if response is not JSON.
        """
        response = self.request("GET", url, headers=headers, params=params, timeout=timeout)
        try:
            response.raise_for_status()
        except requests.HTTPError as e:
            # Try to extract detail from JSON response for better error messages
            try:
                error_detail = response.json().get('detail', str(e))
                raise requests.HTTPError(f"{e}. Detail: {error_detail}", response=response) from e
            except (ValueError, AttributeError):
                raise
        return response.json()

    def post(
        self,
        url: str,
        *,
        headers: Dict[str, str] | None = None,
        json: Dict[str, Any] | None = None,
        timeout: int = 30,
    ) -> Dict[str, Any]:
        """Execute POST request and return JSON response.
        
        Convenience method that wraps request() and automatically parses
        the JSON response. Raises exception if response is not JSON.
        """
        response = self.request("POST", url, headers=headers, json=json, timeout=timeout)
        try:
            response.raise_for_status()
        except requests.HTTPError as e:
            # Try to extract detail from JSON response for better error messages
            try:
                error_detail = response.json().get('detail', str(e))
                raise requests.HTTPError(f"{e}. Detail: {error_detail}", response=response) from e
            except (ValueError, AttributeError):
                raise
        return response.json()

    def put(
        self,
        url: str,
        *,
        headers: Dict[str, str] | None = None,
        json: Dict[str, Any] | None = None,
        timeout: int = 30,
    ) -> Dict[str, Any]:
        """Execute PUT request and return JSON response.
        
        Convenience method that wraps request() and automatically parses
        the JSON response. Raises exception if response is not JSON.
        """
        response = self.request("PUT", url, headers=headers, json=json, timeout=timeout)
        try:
            response.raise_for_status()
        except requests.HTTPError as e:
            # Try to extract detail from JSON response for better error messages
            try:
                error_detail = response.json().get('detail', str(e))
                raise requests.HTTPError(f"{e}. Detail: {error_detail}", response=response) from e
            except (ValueError, AttributeError):
                raise
        return response.json()

    def delete(
        self,
        url: str,
        *,
        headers: Dict[str, str] | None = None,
        timeout: int = 30,
    ) -> Dict[str, Any]:
        """Execute DELETE request and return JSON response.
        
        Convenience method that wraps request() and automatically parses
        the JSON response. Raises exception if response is not JSON.
        """
        response = self.request("DELETE", url, headers=headers, timeout=timeout)
        try:
            response.raise_for_status()
        except requests.HTTPError as e:
            # Try to extract detail from JSON response for better error messages
            try:
                error_detail = response.json().get('detail', str(e))
                raise requests.HTTPError(f"{e}. Detail: {error_detail}", response=response) from e
            except (ValueError, AttributeError):
                raise
        
        if response.status_code == 204:
            return {}
            
        return response.json()

    # Internal helper methods
    def _print_debug(
        self,
        method: str,
        url: str,
        *,
        payload: Dict[str, Any] | None = None,
        headers: Dict[str, Any] | None = None,
        params: Dict[str, Any] | None = None,
    ) -> None:
        """Output debug information for HTTP requests when debug mode is active.
        
        Logs the HTTP method, URL, and request details including headers,
        parameters, and payload while automatically masking sensitive values
        to prevent credential exposure in logs.
        """
        if not self.debug:
            return

        print(f"[DEBUG] {method.upper()} {url}")

        if params:
            print(f"[DEBUG] Params: {self._sanitize_for_debug(params)}")
        if payload:
            print(f"[DEBUG] Payload: {self._sanitize_for_debug(payload)}")
        if headers:
            print(f"[DEBUG] Headers: {self._sanitize_for_debug(headers)}")

    def _sanitize_for_debug(self, data: Any, *, key_hint: str = "") -> Any:
        """Recursively sanitize data structures by masking sensitive values.
        
        Walks through dictionaries, lists, and tuples to identify and mask
        sensitive information based on key names, ensuring debug output
        doesn't expose credentials or other sensitive data.
        """
        if isinstance(data, dict):
            return {
                key: self._sanitize_for_debug(value, key_hint=key)
                for key, value in data.items()
            }
        if isinstance(data, list):
            return [self._sanitize_for_debug(item, key_hint=key_hint) for item in data]
        if isinstance(data, tuple):
            return tuple(self._sanitize_for_debug(item, key_hint=key_hint) for item in data)
        return self._mask_sensitive_value(key_hint, data)

    def _mask_sensitive_value(self, key: str, value: Any) -> Any:
        """Determine if a value should be masked based on its key name.
        
        Checks if the key contains sensitive terms like 'password', 'token',
        'secret', etc., and returns a masked version of the value to prevent
        sensitive data from appearing in debug logs.
        """
        if value is None:
            return value
        key_lower = (key or "").lower()
        if any(term in key_lower for term in self._SENSITIVE_TERMS):
            value_str = str(value)
            if len(value_str) > 10:
                return f"{value_str[:4]}...{value_str[-4:]}"
            return "***"
        return value

    def _log_response(self, response) -> None:  # pragma: no cover - console logging
        """Log HTTP response details with sensitive data masking.
        
        Outputs response status, headers, and body content when debug mode
        is enabled, with automatic sanitization of sensitive values in
        JSON responses to prevent credential leakage.
        """
        if not self.debug:
            return

        status_reason = getattr(response, "reason", "")
        print(f"[DEBUG] Response: {response.status_code} {status_reason}")

        content_type = ""
        try:
            content_type = response.headers.get("Content-Type", "")
        except AttributeError:
            pass

        if "json" in content_type:
            try:
                sanitized = self._sanitize_for_debug(response.json())
                print(f"[DEBUG] Response Body: {sanitized}")
                return
            except ValueError:
                pass

        try:
            text = response.text
        except AttributeError:
            text = None

        if text:
            preview = text if len(text) <= 500 else f"{text[:500]}..."
            print(f"[DEBUG] Response Body: {preview}")
