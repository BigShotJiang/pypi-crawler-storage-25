"""Unit tests for ExternalProviderService."""

import unittest
from unittest.mock import Mock, patch

from zededa_eip_client.services.external_providers import ExternalProviderService
from zededa_eip_client.services.http import HTTPService


class TestExternalProviderService(unittest.TestCase):
    """Test cases for ExternalProviderService."""

    def setUp(self):
        """Set up test fixtures."""
        self.backend_url = "https://api.example.com"
        self.http = HTTPService(debug=False)
        self.service = ExternalProviderService(self.backend_url, self.http)
        self.jwt = "test-jwt-token"

    @patch.object(HTTPService, "request")
    def test_list_external_providers(self, mock_request):
        """Test listing external providers with pagination."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "providers": [
                {"id": "provider-1", "name": "HuggingFace", "type": "huggingface"},
                {"id": "provider-2", "name": "Azure", "type": "azure"},
            ],
            "total": 2,
            "page": 1,
            "limit": 50,
        }
        mock_request.return_value = mock_response

        result = self.service.list_external_providers(
            self.jwt, limit=50, page=1, search="hugging"
        )

        self.assertEqual(len(result["providers"]), 2)
        self.assertEqual(result["total"], 2)
        mock_request.assert_called_once()

    @patch.object(HTTPService, "request")
    def test_create_external_provider(self, mock_request):
        """Test creating a new external provider."""
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "id": "provider-123",
            "name": "My HuggingFace",
            "type": "huggingface",
            "url": "https://huggingface.co",
        }
        mock_request.return_value = mock_response

        payload = {
            "name": "My HuggingFace",
            "type": "huggingface",
            "url": "https://huggingface.co",
        }
        result = self.service.create_external_provider(self.jwt, payload)

        self.assertEqual(result["id"], "provider-123")
        self.assertEqual(result["name"], "My HuggingFace")
        mock_request.assert_called_once()

    @patch.object(HTTPService, "request")
    def test_get_external_provider(self, mock_request):
        """Test getting a specific external provider."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "provider-123",
            "name": "My Provider",
            "type": "azure",
        }
        mock_request.return_value = mock_response

        result = self.service.get_external_provider(self.jwt, "provider-123")

        self.assertEqual(result["id"], "provider-123")
        self.assertEqual(result["name"], "My Provider")
        mock_request.assert_called_once()

    @patch.object(HTTPService, "request")
    def test_get_external_provider_not_found(self, mock_request):
        """Test getting a non-existent external provider."""
        mock_response = Mock()
        mock_response.status_code = 404
        mock_request.return_value = mock_response

        result = self.service.get_external_provider(self.jwt, "nonexistent")

        self.assertEqual(result, {})
        mock_request.assert_called_once()

    @patch.object(HTTPService, "request")
    def test_update_external_provider(self, mock_request):
        """Test updating an external provider by name."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "id": "provider-123",
            "name": "Updated Name",
            "type": "azure",
        }
        mock_request.return_value = mock_response

        payload = {"name": "Updated Name"}
        result = self.service.update_external_provider(
            self.jwt, "My Provider", payload
        )

        self.assertEqual(result["name"], "Updated Name")
        mock_request.assert_called_once()

    @patch.object(HTTPService, "request")
    def test_delete_external_provider(self, mock_request):
        """Test deleting an external provider by name."""
        mock_response = Mock()
        mock_response.status_code = 204
        mock_request.return_value = mock_response

        result = self.service.delete_external_provider(self.jwt, "My Provider")

        self.assertTrue(result)
        mock_request.assert_called_once()

    @patch.object(HTTPService, "request")
    def test_delete_external_provider_not_found(self, mock_request):
        """Test deleting a non-existent external provider by name."""
        mock_response = Mock()
        mock_response.status_code = 404
        mock_request.return_value = mock_response

        result = self.service.delete_external_provider(self.jwt, "nonexistent")

        self.assertFalse(result)
        mock_request.assert_called_once()

    @patch.object(HTTPService, "request")
    def test_test_connection(self, mock_request):
        """Test testing provider connection by name."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "success": True,
            "message": "Connection successful",
        }
        mock_request.return_value = mock_response

        result = self.service.test_connection(self.jwt, "My Provider")

        self.assertTrue(result["success"])
        self.assertEqual(result["message"], "Connection successful")
        mock_request.assert_called_once()

    @patch.object(HTTPService, "request")
    def test_browse_provider(self, mock_request):
        """Test browsing provider contents by name."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "items": [
                {"name": "model1", "type": "model"},
                {"name": "model2", "type": "model"},
            ],
            "cursor": "next-page-token",
        }
        mock_request.return_value = mock_response

        result = self.service.browse_provider(
            self.jwt, "My Provider", path="/models", search="yolo"
        )

        self.assertEqual(len(result["items"]), 2)
        self.assertEqual(result["cursor"], "next-page-token")
        mock_request.assert_called_once()


    @patch.object(HTTPService, "request")
    def test_list_model_versions(self, mock_request):
        """Test listing model versions/variants for a provider model.

        The service resolves provider name to ID first, then calls the
        ID-based model-versions endpoint with model_path as a query param.
        """
        # First call: resolve provider name -> ID
        provider_response = Mock()
        provider_response.status_code = 200
        provider_response.json.return_value = {
            "id": "provider-qualcomm-123",
            "provider_name": "qualcomm-aihub",
            "provider_type": "qualcomm_aihub",
        }

        # Second call: list model versions by ID
        versions_response = Mock()
        versions_response.status_code = 200
        versions_response.json.return_value = {
            "model_path": "yolov8_det",
            "versions": [
                "runtime=onnx;precision=fp16;device=*",
                "runtime=onnx;precision=fp16;device=QCS9075",
            ],
            "latest_version": "runtime=onnx;precision=fp16;device=*",
        }

        mock_request.side_effect = [provider_response, versions_response]

        result = self.service.list_model_versions(
            self.jwt, "qualcomm-aihub", "yolov8_det"
        )

        self.assertEqual(len(result["versions"]), 2)
        self.assertEqual(result["latest_version"], "runtime=onnx;precision=fp16;device=*")
        self.assertEqual(mock_request.call_count, 2)

        # Verify the second call hits the ID-based endpoint with model_path as query param
        versions_call_args = mock_request.call_args_list[1]
        self.assertIn("/id/provider-qualcomm-123/model-versions", versions_call_args[0][1])
        self.assertEqual(versions_call_args[1]["params"]["model_path"], "yolov8_det")

    @patch.object(HTTPService, "request")
    def test_browse_qualcomm_aihub_provider(self, mock_request):
        """Test browsing Qualcomm AI Hub provider contents."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "path": "",
            "items": [
                {
                    "name": "YOLOv8-Detection",
                    "path": "yolov8_det",
                    "type": "model",
                    "metadata": {
                        "model_identifier": "yolov8_det",
                        "domain": "Computer Vision",
                        "use_case": "Object Detection",
                        "default_runtime": "onnx",
                        "available_precisions": ["fp16", "int8"],
                        "catalog_url": "https://aihub.qualcomm.com/models/yolov8_det",
                    },
                }
            ],
            "next_cursor": None,
        }
        mock_request.return_value = mock_response

        result = self.service.browse_provider(
            self.jwt, "qualcomm-aihub", search="yolo"
        )

        self.assertEqual(len(result["items"]), 1)
        item = result["items"][0]
        self.assertEqual(item["path"], "yolov8_det")
        self.assertEqual(item["metadata"]["default_runtime"], "onnx")
        mock_request.assert_called_once()


if __name__ == "__main__":
    unittest.main()
