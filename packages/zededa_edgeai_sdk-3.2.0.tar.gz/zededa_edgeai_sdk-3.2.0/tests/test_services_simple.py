"""Test cases for the service layer components."""

import os
import unittest
from unittest.mock import MagicMock, Mock, patch

from zededa_eip_client.services.auth import AuthService
from zededa_eip_client.services.benchmarks import BenchmarkService
from zededa_eip_client.services.catalogs import CatalogService
from zededa_eip_client.services.http import HTTPService
from zededa_eip_client.services.storage import StorageService


class TestHTTPService(unittest.TestCase):
    """Test HTTP service functionality."""

    def setUp(self):
        """Set up HTTP service for testing."""
        self.http_service = HTTPService(debug=False)

    def test_init(self):
        """Test HTTPService initialization."""
        service = HTTPService(debug=True)
        self.assertTrue(service.debug)
        
        service = HTTPService(debug=False)
        self.assertFalse(service.debug)

    def test_mask_sensitive_value_with_sensitive_key(self):
        """Test masking of sensitive values."""
        result = self.http_service._mask_sensitive_value("token", "secret123456789")
        self.assertEqual(result, "secr...6789")

    def test_mask_sensitive_value_with_non_sensitive_key(self):
        """Test that non-sensitive keys are not masked."""
        result = self.http_service._mask_sensitive_value("username", "john_doe")
        self.assertEqual(result, "john_doe")

    def test_mask_sensitive_value_with_none(self):
        """Test masking with None value."""
        result = self.http_service._mask_sensitive_value("token", None)
        self.assertIsNone(result)

    def test_mask_sensitive_value_with_short_sensitive_value(self):
        """Test masking of short sensitive values."""
        result = self.http_service._mask_sensitive_value("password", "abc")
        self.assertEqual(result, "***")

    @patch.dict(os.environ, {"EDGEAI_CURRENT_ORG": "env-catalog"})
    def test_get_catalog_context_from_environment(self):
        """Test catalog context falls back to environment variable."""
        self.assertEqual(self.http_service.get_catalog_context(), "env-catalog")

    @patch.dict(os.environ, {"EDGEAI_CURRENT_ORG": "env-catalog"})
    def test_get_catalog_context_prefers_instance_context(self):
        """Test explicit instance catalog context overrides environment context."""
        self.http_service.set_catalog_context("instance-catalog")
        self.assertEqual(self.http_service.get_catalog_context(), "instance-catalog")

    @patch.dict(os.environ, {"EDGEAI_CURRENT_ORG": "env-catalog"})
    @patch("zededa_eip_client.services.http.requests.request")
    def test_request_injects_catalog_header(self, mock_request):
        """Test request includes X-Catalog-ID header when catalog context is set."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.reason = "OK"
        mock_response.headers = {"Content-Type": "application/json"}
        mock_response.json.return_value = {}
        mock_request.return_value = mock_response

        self.http_service.request(
            "GET",
            "https://example.com/api/v1/resource",
            headers={"Authorization": "Bearer token"},
        )

        headers = mock_request.call_args.kwargs["headers"]
        self.assertEqual(headers["X-Catalog-ID"], "env-catalog")
        self.assertEqual(headers["Authorization"], "Bearer token")

    @patch.dict(os.environ, {"EDGEAI_CURRENT_CATALOG": "env-catalog"})
    @patch("zededa_eip_client.services.http.requests.request")
    def test_request_explicit_catalog_header_takes_precedence(self, mock_request):
        """Test explicit X-Catalog-ID header overrides default context header."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.reason = "OK"
        mock_response.headers = {"Content-Type": "application/json"}
        mock_response.json.return_value = {}
        mock_request.return_value = mock_response

        self.http_service.request(
            "GET",
            "https://example.com/api/v1/resource",
            headers={"X-Catalog-ID": "explicit-catalog"},
        )

        headers = mock_request.call_args.kwargs["headers"]
        self.assertEqual(headers["X-Catalog-ID"], "explicit-catalog")


class TestAuthService(unittest.TestCase):
    """Test authentication service functionality."""

    def setUp(self):
        """Set up AuthService for testing."""
        self.auth_service = AuthService("https://example.com", "https://ui.example.com", debug=False)

    def test_init(self):
        """Test AuthService initialization."""
        self.assertEqual(self.auth_service.backend_url, "https://example.com")
        # AuthService has these basic attributes
        self.assertTrue(hasattr(self.auth_service, 'backend_url'))
        self.assertTrue(hasattr(self.auth_service, 'debug'))

    @patch("zededa_eip_client.services.auth.socket.socket")
    def test_find_available_port_success(self, mock_socket):
        """Test finding available port."""
        socket_ctx = MagicMock()
        socket_instance = MagicMock()
        socket_ctx.__enter__.return_value = socket_instance
        mock_socket.return_value = socket_ctx

        port = self.auth_service._find_available_port()

        socket_instance.bind.assert_called_once_with(("localhost", 8765))
        self.assertIsInstance(port, int)
        self.assertEqual(port, 8765)

    def test_render_error_message_fallback(self):
        """Test error message rendering fallback."""
        result = self.auth_service._render_error_message({})
        expected = "Authentication failed. Please check your credentials and try again."
        self.assertEqual(result, expected)

    def test_render_error_message_with_error_param(self):
        """Test error message rendering with error parameter."""
        params = {"error": ["invalid_request"]}
        result = self.auth_service._render_error_message(params)
        # The actual implementation returns the error param directly for unrecognized errors
        self.assertEqual(result, "invalid_request")


class TestCatalogService(unittest.TestCase):
    """Test catalog service functionality."""

    def setUp(self):
        """Set up CatalogService for testing."""
        mock_http = Mock()
        self.catalog_service = CatalogService("https://example.com", mock_http)

    def test_init(self):
        """Test CatalogService initialization."""
        self.assertEqual(self.catalog_service.backend_url, "https://example.com")
        self.assertIsNotNone(self.catalog_service.http)


class TestStorageService(unittest.TestCase):
    """Test storage service functionality."""

    def setUp(self):
        """Set up StorageService for testing."""
        mock_http = Mock()
        self.storage_service = StorageService("https://example.com", mock_http)

    def test_init(self):
        """Test StorageService initialization."""
        self.assertEqual(self.storage_service.backend_url, "https://example.com")
        self.assertIsNotNone(self.storage_service.http)


class TestBenchmarkService(unittest.TestCase):
    """Test benchmark service functionality."""

    def setUp(self):
        """Set up BenchmarkService for testing."""
        mock_http = Mock()
        self.benchmark_service = BenchmarkService("https://example.com", mock_http)

    def test_init(self):
        """Test BenchmarkService initialization."""
        self.assertEqual(self.benchmark_service.backend_url, "https://example.com")
        self.assertIsNotNone(self.benchmark_service._http)


if __name__ == "__main__":
    unittest.main()
