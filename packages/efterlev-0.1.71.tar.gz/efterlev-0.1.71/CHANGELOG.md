# Changelog

All notable changes to Efterlev will be tracked here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) loosely.

## [0.1.71] — 2026-05-12

**Single-PR README tagline rephrase.** Per maintainer feedback,
the lead tagline reframes from "Compliance scanning for SaaS
teams pursuing FedRAMP 20x — that lives in your repo, not a SaaS
dashboard." to "Open source. Runs locally. Compliance evidence
lives in your repo alongside the code it describes." The new
tagline leads with the open-source + local positioning that
distinguishes Efterlev from the SaaS GRC competitive landscape;
the FedRAMP 20x framework specificity moves to the body sentence
where it's still surfaced.

### Changed

- `README.md` lead tagline + body sentence.

### Internal (count deltas)

- All counts unchanged (README copy edit only).

## [0.1.70] — 2026-05-12

**Single-PR docs-only release: CFN/CDK synth-mode DECISIONS entry
+ docs/index.md feature-list refresh.** Two doc-only deliverables
bundled into one release. Strategic-arc next step (CFN synth-mode
design) is now locked in DECISIONS.md per the established
DECISIONS-entry-then-PR convention; the docs-site status bullet
that had stopped at v0.1.59 features is now caught up to v0.1.69
state.

### Added

- **DECISIONS.md "2026-05-12 — Tier 5 #1 design: CloudFormation/CDK
  synth-mode support"** — locks the architectural shape of the
  CFN/CDK support work + the 3-PR rollout sequence (α this release;
  β = parser + adapter + 3 sample detector adaptations + 1 CFN
  fixture; γ = bulk detector sweep + scan integration + design-
  partner outreach). Decisions: (1) v1 scope = scan CFN JSON
  whether hand-authored or `cdk synth`-generated, (2) thin adapter
  shim over IaC-agnostic IR refactor for v1, (3) auto-detect input
  by extension + `Resources` content sniff, (4) source-level
  citation = file-level only at v1 (matches plan-JSON mode),
  (5) behind `--allow-cfn` flag at v0 then default-on after
  partner validation, (6) design-partner recruitment kicks off
  WITH PR β shipping (not as a blocker), (7) 3-PR α/β/γ sequence.

### Changed

- **`docs/index.md`** status bullet refreshed: feature list had
  stopped at v0.1.59 work (was missing the v0.1.60-v0.1.69 SHA-
  pinning, `[dev]`-extra security tools, Phase 2 lite eval harness
  + 67 validated labels, CFN-design lock). Now lists everything
  shipped through v0.1.70.

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1528 unchanged.
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

This release is doc-only; no source/test/CI code touched.

## [0.1.69] — 2026-05-12

**Single-PR Phase 2 lite maintainer validation pass: 67/67 labels
validated, 100% precision + 100% recall, 0 overrides.** The "what
the maintainer review pass should do" follow-on documented in
`evals/PHASE_2_LITE_LABEL_REVIEW.md` (v0.1.67) has now been
executed end-to-end with the v0.1.69 release. The strategic-arc
gate to start CFN synth-mode design (per the 2026-05-11 strategic-
arc memory) is now genuinely open: Phase 2 lite is operational as
a regression instrument.

### Added

- `evals/PHASE_2_LITE_MAINTAINER_VALIDATION.md` — side-by-side
  validation doc. Per-fixture, per-KSI: drafted label, agent
  verdict, alternation resolution, match indicator. Plus an
  aggregate table, "what this validation does NOT prove"
  honesty section, and "suggested next steps" outlining the
  Phase 3 promotion path + new-fixture vendoring options + CFN
  DECISIONS-entry kickoff.

### Validation results

Ran `python -m evals run --fixture <fixture-id> --llm-backend
anthropic --llm-model claude-haiku-4-5` against each Phase 2 lite
fixture, captured the agent's per-KSI verdicts from the gap
report, and compared to the post-v0.1.67 labels:

| Fixture | Labels | Precision | Recall |
|---|---|---|---|
| aws-vpc-tfm | 21 | 100% | 100% |
| aws-s3-bucket-tfm | 25 | 100% | 100% |
| aws-lambda-tfm | 21 | 100% | 100% |

**Zero label overrides needed.** All v0.1.67 second-pass revisions
were correct — particularly the Lambda-fixture tightenings
(KSI-CNA-MAT `not_implemented|partial` → `not_implemented`,
KSI-MLA-LET `not_implemented|partial` → `partial`) that nailed the
agent's exact verdict on the trickiest cases.

POAM scope discipline (M5) also scored 100% on every fixture.

### Strategic-arc state

Updated `project_efterlev_strategic_arc_2026-05.md` (memory): the
"awaits maintainer validation" gating is **resolved**. Phase 2
lite is operational as the regression instrument the CFN/CDK
expansion was structurally gated on. CFN synth-mode design can
proceed (still wants a DECISIONS entry first per the original
strategic-arc framing).

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1528 unchanged.
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Phase 2 lite labels: 67 (validated; 0 overrides).

## [0.1.68] — 2026-05-12

**Single-PR documentation audit: stale-claim sweep across the
docs.** During v0.1.55-v0.1.67's rapid release cadence (13 releases
on 2026-05-11 alone), several long-form docs accumulated count
references and capability claims that fell out of sync with the
current state. This pass swept them.

### Changed

- **`docs/quickstart.md`**: "we ship 45 detectors" → "we ship 66
  detectors" (in the troubleshooting block).
- **`docs/ai-quickstart-prompt.md`**: GitHub-workflow detector
  count "4 detectors" → "5 detectors".
- **`LIMITATIONS.md`**: "It does not cover the full FedRAMP 20x
  Moderate KSI set via detectors alone" section rewritten:
  "At v0.1.17, **45 detectors ship** (38 KSI-mapped + 7
  supplementary 800-53-only), covering 31 of 60 KSIs across 8 of
  11 themes" → "At v0.1.67, **66 detectors ship** (62 KSI-mapped
  + 4 supplementary 800-53-only), covering 37 of 60 KSIs across
  10 of 11 themes." Plus the trailing sentence about manifest
  starter pack being "v0.1.18+ work" rewritten to credit the
  v0.1.21 ship + v0.1.36 expansion (both already shipped).
- **`docs/aws-coexistence.md`**:
  - Detector breakdown updated: "Of Efterlev's 38 KSI-mapped
    detectors, 34 read AWS-resource-shaped Terraform; 4 read
    .github/workflows/" → "Of Efterlev's 62 KSI-mapped detectors,
    56 read AWS-resource-shaped Terraform; 5 read
    .github/workflows/; 1 reads `github_branch_protection`
    Terraform" (the v0.1.55 first-of-kind).
  - KSI coverage: "31 of 60 thematic KSIs" → "37 of 60 thematic
    KSIs" (in three places).
  - Threshold-vs-coverage math: "Union ≈ 30 + 14 − 11 = ~33 of
    63 KSIs (~52%)" → "Union ≈ 37 + 14 − 11 = ~40 of 60 KSIs
    (~67%)" (closes the gap to FedRAMP 20x Phase 2's 70%
    automated-validation threshold).
- **`docs/v0.2-eval-harness-plan.md`**: "Phase 2 (during v0.2.x):
  add 2-3 sanitized real fixtures as customer relationships
  permit. Solicit ground-truth labeling help" → annotated with
  "Shipped as 'Phase 2 lite' v0.1.63-v0.1.67" + the 3 vendored
  real-shape fixtures + 67 conservative claude-drafted labels.
  Phase 1 + Phase 3 lines also annotated to reflect current state.

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1528 unchanged (no source/test code touched).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

## [0.1.67] — 2026-05-12

**Single-PR Phase 2 lite second pass: label review + 6 revisions
across the three real-shape fixtures.** v0.1.64-v0.1.66 shipped 67
conservative claude-drafted labels authored by reading scan output
directly (no LLM agent verdict consulted). v0.1.67 is the second-
look review against the canonical FRMR statements: each label
re-examined, 6 revised (3 tightenings + 3 loosenings), 61 confirmed
unchanged.

### Added

- `evals/PHASE_2_LITE_LABEL_REVIEW.md` — consolidated review doc.
  Per-fixture, per-KSI section with FRMR statement, evidence
  summary, drafted label, second-pass reasoning, confidence, and
  decision (confirm/revise/flag). Plus a revisions table and a
  "what the maintainer review pass should do" section that walks
  through the API-key-required follow-on.

### Changed

- `evals/fixtures/aws-vpc-tfm/GROUND_TRUTH.yaml` (revision 2 → 3):
  - **KSI-CNA-MAT** `partial` → `partial|not_implemented` (loosen
    — the missing-explicit-deny gap could honestly be weighted to
    not_implemented; alternation now matches how CNA-MAT is
    handled in fixture #2)
  - **KSI-CNA-RNT** `partial` → `partial|not_implemented` (same)
- `evals/fixtures/aws-s3-bucket-tfm/GROUND_TRUTH.yaml` (revision 1 → 2):
  - **KSI-AFR-UCM** `partial|not_implemented` → `partial` (tighten
    — the split-resource SSE pattern IS the post-2022 AWS best
    practice; calling it `not_implemented` would miss real
    encryption infrastructure)
  - **KSI-SVC-RUD** `not_implemented` → `not_implemented|partial`
    (loosen — lifecycle resource exists, just empty; agent could
    honestly call either)
- `evals/fixtures/aws-lambda-tfm/GROUND_TRUTH.yaml` (revision 1 → 2):
  - **KSI-CNA-MAT** `not_implemented|partial` → `not_implemented`
    (tighten — Lambda-no-vpc_config is unambiguously default-VPC
    internet-facing; the partial alternation was reading-into-the-
    future)
  - **KSI-MLA-LET** `not_implemented|partial` → `partial` (tighten
    — the fixture HAS 2 `aws_cloudwatch_log_group` resources, so
    logging IS configured; `not_implemented` would be wrong)

Phase 2 lite labeled-KSI count unchanged at 67 across 3 fixtures
(this release adjusts label content, not count).

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1528 unchanged (no test changes; `test_eval_fixtures_parse`
  parametrization still covers all 8 fixtures).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Eval fixtures: 8 unchanged.
- Phase 2 lite labels: 67 (revisions: 6/67 = 9%).

## [0.1.66] — 2026-05-11

**Single-PR Phase 2 lite expansion: third real-shape fixture
(`aws-lambda-tfm`) + 21 conservative draft labels.** Rounds out
the initial three-fixture corpus covering the most-common AWS
workload patterns:
- `aws-vpc-tfm` (v0.1.63) — network/segmentation
- `aws-s3-bucket-tfm` (v0.1.65) — storage/encryption
- `aws-lambda-tfm` (v0.1.66) — serverless compute

### Added

- `evals/fixtures/aws-lambda-tfm/` — third Phase 2 lite fixture.
  `infra/` vendored verbatim from
  [`terraform-aws-modules/terraform-aws-lambda`](https://github.com/terraform-aws-modules/terraform-aws-lambda)
  v8.8.0 (commit `b8423741`). Apache 2.0 license preserved
  under `infra/LICENSE`; vendoring provenance + update procedure
  under `SOURCE.md`. ~15 raw `aws_lambda_*` + `aws_cloudwatch_*`
  resource types + null_resource layer mechanics.
- 21 conservative draft labels in
  `evals/fixtures/aws-lambda-tfm/GROUND_TRUTH.yaml`:
  - 4 KSIs WITH detector evidence: KSI-CNA-MAT (Lambda
    `internet_facing` — no vpc_config), KSI-MLA-LET (logging
    `unverifiable` — function_name var-driven), KSI-MLA-OSM
    (`producers_only` — log groups exist but no centralization
    primitive), KSI-PIY-GIV (terraform_inventory tracked).
  - 17 procedural-only KSIs (same set as the prior two
    fixtures; AFR-UCM left unlabeled because no encryption
    resources to evidence cryptographic-module use).

  Phase 2 lite labeled-KSI count: 46 → 67 (across 3 fixtures).
  (PR #264)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1526 → 1528 (+2 — `test_eval_fixtures_parse`
  parametrization now covers 8 fixtures).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Eval fixtures: 7 → 8 (5 synthetic + 3 real-shape).

## [0.1.65] — 2026-05-11

**Single-PR Phase 2 lite expansion: second real-shape fixture
(`aws-s3-bucket-tfm`) + 25 conservative draft labels.** Companion
to v0.1.63's `aws-vpc-tfm`. Where VPC exercises the
network/segmentation detector dimensions, this exercises the
**storage + encryption** dimensions — same vendor (terraform-aws-
modules), same labeling discipline (claude-drafted from scan
output, no LLM agent verdict consulted, awaits maintainer review).

### Added

- `evals/fixtures/aws-s3-bucket-tfm/` — second Phase 2 lite
  fixture. `infra/` vendored verbatim from
  [`terraform-aws-modules/terraform-aws-s3-bucket`](https://github.com/terraform-aws-modules/terraform-aws-s3-bucket)
  v5.13.0 (commit `af0286ff`). Apache 2.0 license preserved
  under `infra/LICENSE`; vendoring provenance + update procedure
  under `SOURCE.md`. ~20 raw `aws_s3_*` resource types focused on
  bucket lifecycle: encryption, public-access-block, ACL,
  lifecycle, replication, ownership controls, versioning, logging,
  object lock, intelligent tiering, inventory.
- 25 conservative draft labels in
  `evals/fixtures/aws-s3-bucket-tfm/GROUND_TRUTH.yaml`:
  - 8 KSIs WITH detector evidence: KSI-AFR-UCM (split-resource
    encryption pattern), KSI-CNA-MAT/RNT (`s3_bucket_public_acl`
    unparseable from jsonencode), KSI-CNA-OFA (replication
    configured), KSI-IAM-AAM (13 policy documents tracked),
    KSI-PIY-GIV (terraform_inventory tracked), KSI-RPL-ABO
    (versioning unresolvable), KSI-SVC-RUD (lifecycle is a
    placeholder, 0 enabled rules → `not_implemented`).
  - 17 procedural-only KSIs (same set as `aws-vpc-tfm`):
    9 AFR-* (excl AFR-UCM), 4 CED-*, 3 INR-*, plus PIY-RSD.
  Phase 2 lite labeled-KSI count: 21 → 46 (across both
  fixtures). (PR #263)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1524 → 1526 (+2 — 1 new `test_fixture_terraform_parses
  [aws-s3-bucket-tfm]` + 1 new `test_fixture_ground_truth_yaml_
  well_formed[aws-s3-bucket-tfm]`).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Eval fixtures: 6 → 7 (5 synthetic + 2 real-shape).

## [0.1.64] — 2026-05-11

**Single-PR Phase 2 lite first-pass: harness scan-fix +
aws-vpc-tfm draft labels (claude-drafted, awaits maintainer
review).** v0.1.63 shipped the scaffolding; v0.1.64 turns the
empty `expected_classifications: {}` into a working baseline of
21 conservative evidence-based labels, plus a v0.1.59 follow-on
bug fix the v0.1.63 invocation surfaced.

### Fixed

- `evals/harness.py` now passes `--allow-subdir-target` on its
  internal `efterlev scan` invocation. v0.1.59 hard-errored on
  scans below a `.github/workflows/` ancestor; the eval-harness
  workspaces live at `evals/results/<fixture>/<ts>/workspace/`,
  which is exactly that pattern. v0.1.59's CI-compat sweep got
  `e2e_smoke.py` + `release-smoke.yml` but missed this; the
  harness was unable to run end-to-end on any fixture between
  v0.1.59 and this release.

### Added

- `evals/fixtures/aws-vpc-tfm/GROUND_TRUTH.yaml`:
  `expected_classifications` filled in with 21 conservative
  draft labels authored by reading the deterministic
  `efterlev scan` output (NO LLM agent verdict consulted —
  avoids the confirmation-bias risk of "label whatever the
  agent said as honest"):
  - 4 KSIs WITH detector evidence: KSI-CNA-MAT, KSI-CNA-RNT
    (`partial`; 7 NACLs `partially_restrictive`), KSI-CNA-ULN
    (`partial|not_implemented`; var-driven cidr blocked subnet
    linkage), KSI-PIY-GIV (`partial`; aws.terraform_inventory
    `tracked`).
  - 17 procedural-only KSIs: 9 AFR-* (excl AFR-UCM), 4 CED-*,
    3 INR-*, plus KSI-PIY-RSD (workflow surface skipped via
    --allow-subdir-target). All `evidence_layer_inapplicable
    |not_applicable` per Phase 1 alternation discipline.
  Labels marked `# claude-drafted, awaits maintainer review`
  for spot-check + override during evening grading sessions.

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1524 unchanged.
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Eval-harness Phase 2 lite labeled-KSI count: 0 → 21
  (12 procedural-only `evidence_layer_inapplicable|...` +
  4 `partial` from detector evidence + 4 alternations).

## [0.1.63] — 2026-05-11

**Single-PR strategic-arc kickoff: eval-harness Phase 2 lite
scaffolding — first real-shape fixture vendored.** Per the
2026-05-11 strategic-arc decision (memory:
`project_efterlev_strategic_arc_2026-05.md`), Phase 2 lite was
the gating prerequisite before CFN/CDK market-expansion work.
The user's chosen fixture-sourcing path: public open-source
Terraform corpora (vs design-partner real-customer boundaries),
hand-graded by the maintainer in evening sessions.

The 5 Phase 1 in-repo eval fixtures (`govnotes-v1`,
`encryption-mixed`, `iam-dynamic-policy`, `runtime-monitoring`,
`serverless-mixed`) all hit 1.000 / 0.000 on the agent-quality
metrics — textbook overfit risk because the prompts were tuned
against them. Real-shape fixtures from third-party Terraform are
the regression instrument that catches that overfit.

### Added

- `evals/fixtures/aws-vpc-tfm/` — first Phase 2 lite fixture.
  `infra/` is verbatim vendored from
  [`terraform-aws-modules/terraform-aws-vpc`](https://github.com/terraform-aws-modules/terraform-aws-vpc)
  v6.6.1 (commit `3ffbd46f`); the most-downloaded VPC module in
  the Terraform Registry. Apache 2.0 license preserved under
  `infra/LICENSE`; vendoring provenance + update procedure under
  `SOURCE.md`; labeling-review workflow documented in
  `GROUND_TRUTH.yaml` (which ships with empty
  `expected_classifications` per the Phase 1 "skip unlabeled"
  discipline — labels accumulate over evening grading sessions).
- `tests/test_eval_fixtures_parse.py` — smoke test parametrized
  over every `evals/fixtures/<id>/`. Confirms `infra/` parses
  cleanly via efterlev's HCL parser AND that `GROUND_TRUTH.yaml`
  carries the required scaffolding fields. No LLM cost — guards
  against a vendored-upstream re-vendor breaking the fixture
  shape at PR time. (PR #261)

### Changed

- `evals/README.md` — header bumped to "Phase 1 + Phase 2 lite".
  New "Phase 2 lite — labeling real-shape vendored fixtures"
  section walks the 4-step workflow (run snapshot → review
  verdicts → fill in `GROUND_TRUTH.yaml` → re-run with metrics).

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1512 → 1524 (+12 — `tests/test_eval_fixtures_parse.py`
  parametrizes over 6 fixtures × 2 contracts = 12 new test cases).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.
- Eval fixtures: 5 → 6 (`aws-vpc-tfm` is the first real-shape).

### Pending (user follow-up)

- Run `python -m evals run --fixture evals/fixtures/aws-vpc-tfm`
  once to capture the first snapshot. Then walk the per-KSI
  verdicts in evening sessions and accumulate labels in
  `GROUND_TRUTH.yaml`. Once ~15 KSIs are labeled, M1 + M2 against
  this fixture become a real regression-detection signal.

## [0.1.62] — 2026-05-11

**Single-PR closure: `pypa/gh-action-pypi-publish` SHA-pinned to
v1.14.0.** Closes the v0.1.60 SHA-pinning gap — that release left
`pypa/gh-action-pypi-publish@release/v1` (a moving branch ref
documented as the canonical install) on a tag-pin, deferred for a
follow-on. v0.1.62 lands the follow-on: pin to the latest stable
release tag's SHA so all third-party Action references across all
workflows are now SHA-pinned with no exceptions.

### Changed

- `.github/workflows/release-pypi.yml`: both
  `uses: pypa/gh-action-pypi-publish@release/v1` (test-pypi publish
  + real-pypi publish) rewritten to
  `uses: pypa/gh-action-pypi-publish@cef221092ed1bacb1cc03d23a2d87d1d172e277b # v1.14.0`.
  Dependabot's wildcard github-actions group (v0.1.60) will pick up
  future v1.x releases automatically. (PR #260)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1512 unchanged.
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

## [0.1.61] — 2026-05-11

**Single-PR supply-chain reproducibility fix: `pip-audit` + `bandit`
baked into the `[dev]` extra.** Closes `docs/security-review-2026-04.md`
§7 + the "Bake security tools into [dev] extra" followup held since
the v0.1.0 launch security review. CI was using `uv run --with
pip-audit` (pip-audit) and `pip install --upgrade 'bandit[toml]
>=1.7,<2'` (bandit), both of which fetch whatever PyPI happens to
have on every CI run — defeats reproducibility AND means a Bandit
release with a regression could turn green PRs red overnight without
any code change here.

### Changed

- `pyproject.toml`: `pip-audit>=2.7,<3` and `bandit[toml]>=1.7,<2`
  added to `[project.optional-dependencies].dev`. Both tools now
  pin into `uv.lock` and update via Dependabot's grouped Python PRs.
- `.github/workflows/ci-security.yml`: pip-audit job switched from
  `uv run --with pip-audit pip-audit ...` to `uv run pip-audit ...`
  (lockfile-pinned). Bandit job switched from `actions/setup-python`
  + `pip install --upgrade ...` to `astral-sh/setup-uv` + `uv sync
  --extra dev` + `uv run bandit ...` (same lockfile). Local-dev
  parity with CI is the bonus. (PR #258)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1512 unchanged (no Python source touched).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

## [0.1.60] — 2026-05-11

**Single-PR supply-chain hardening: third-party GitHub Actions
SHA-pinned across all workflows + Dependabot grouping wildcarded.**
Closes the `docs/security-review-2026-04.md` §5 + §7 expectation
held in `docs/followups.md` since the v0.1.0 launch security
review. OpenSSF Scorecard / SLSA L3 expects every external Action
reference to be pinned to an immutable commit SHA rather than a
movable tag — protects against a compromised maintainer force-
moving a tag to inject malicious code into our build pipeline.

### Changed

- `.github/workflows/*.yml`: every `uses: <org>/<repo>@<tag>` for a
  third-party Action rewritten to `uses: <org>/<repo>@<full-sha> #
  <tag>` (tag preserved as comment for human readability and for
  Dependabot's version-bump detection). Pinned: `astral-sh/setup-uv`,
  `sigstore/cosign-installer`, `anchore/sbom-action`,
  `returntocorp/semgrep-action`, `docker/setup-qemu-action`,
  `docker/setup-buildx-action`, `docker/login-action`,
  `docker/build-push-action`. Skipped: `pypa/gh-action-pypi-publish
  @release/v1` (moving branch ref documented as the canonical
  install — different pinning strategy needed; deferred to a future
  PR). First-party `actions/*` and `github/*` left tag-pinned per
  common GitHub convention.
- `.github/dependabot.yml`: github-actions group rewritten from
  `update-types: [minor, patch]` to `patterns: ["*"]`. With SHA
  pins, every Dependabot detection (whether semver-major / minor /
  patch / re-tag-of-same-version-to-new-SHA) emits a separate PR by
  default — would generate ~10 PRs per weekly cycle even when only
  one Action moved. Wildcard collapses that into a review-friendly
  single grouped PR per cycle. (PR #257)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1512 unchanged (CI-only change; no Python source touched).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

## [0.1.59] — 2026-05-11

**First-run UX fix: `efterlev scan` hard-errors when `--target` sits
below a `.github/workflows/` ancestor.** Bridge release before the
next strategic arc (DECISIONS 2026-05-11 "Strategic arc post-v0.1.58
— quality scaffolding before market expansion"). Closes a
documented funnel-killer: a first-run user pointing `--target` at
`infra/terraform/` (the dominant real-customer layout) used to get
a `20 evidence records` success line and conclude the tool covered
their repo, when actually github-source detectors had silently
contributed zero. The pre-v0.1.59 post-scan warning was easy to
miss in CI logs.

### Changed

- `efterlev scan` now refuses to run by default when `--target`
  resolves to a directory below a `.github/workflows/` ancestor.
  Exit code 2 with a two-paths error message: (1) re-run from the
  detected repo root, or (2) pass the new `--allow-subdir-target`
  flag to acknowledge the trade-off and proceed with Terraform-only
  scope (the legitimate monorepo-with-multiple-Terraform-roots
  case). The post-scan warning still fires when
  `--allow-subdir-target` is passed, so the under-coverage is
  visible in the output. (PR #255)

### Fixed (CI compatibility)

- `scripts/e2e_smoke.py` and `.github/workflows/release-smoke.yml`
  pass `--allow-subdir-target` to acknowledge their deliberately-
  Terraform-only scope (e2e workspace at `.e2e-results/<ts>/`,
  smoke fixture at `tests/smoke/`). Both sit below the repo's
  `.github/workflows/` and would otherwise hard-error.

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1511 → 1512 (+1 — replaced the
  `test_scan_warns_when_target_sits_below_*` test with
  `test_scan_hard_errors_*` + a new
  `test_scan_proceeds_with_warning_when_allow_subdir_target_passed`).
- Source files: 222 unchanged.
- CLI commands: 31 unchanged.

## [0.1.58] — 2026-05-11

**Single-PR feature: `efterlev manifests validate <path>` — offline
schema validation for Evidence Manifests.** Pre-commit / pre-PR
gate that catches the high-leverage authoring mistakes a contributor
makes while drafting a manifest: typo'd field names (`extra="forbid"`
rejects them — the canonical `attester:` vs `attested_by:` swallowed-
typo), malformed dates, missing required fields, top-level not-a-mapping.
Pure schema check; no FRMR / baseline load required.

Fourth small focused single-PR feature in the post-Tier-4 cadence
(after v0.1.53 detectors-new + v0.1.54 boundary --interactive +
v0.1.56 detectors-show).

### Added

- `efterlev manifests validate <path>` CLI command. Path argument
  accepts a single file OR a directory (walked via the same glob as
  scan-time manifest discovery: `*.yml` + `*.yaml`, with
  `*.template.yml` skipped to match loader behavior). Per-file ✓
  or ✗ output with the pydantic validation error inline; summary
  line shows valid/total. Exit codes: 0 if every manifest validates,
  1 if any fail, 2 if the path doesn't exist or no manifests
  discoverable in a directory. Does NOT cross-check `ksi:` against
  the FRMR baseline — that's the scan-time check; offline validate
  is the schema gate. (PR #254)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1500 → 1511 (+11 — `tests/test_manifests_validate.py`).
- Source files: 222 unchanged (the new command is a function inside
  `cli/main.py`).
- CLI commands: 30 → 31.

## [0.1.57] — 2026-05-11

**Single-PR supply-chain feature: wheel + sdist SBOMs attached to
GitHub Releases.** The container image already carries an embedded
SBOM via `buildx sbom: true`; this closes the parallel gap on the
PyPI artifacts. Held in `docs/followups.md` "v0.1.x patch follow-
ups" since the v0.1.0 launch security review.

### Added

- `release-pypi.yml` runs `anchore/sbom-action@v0` after
  `publish-pypi` to generate CycloneDX SBOMs for both the wheel
  and sdist, and attaches them to the GitHub Release as
  `efterlev-<VERSION>-wheel-sbom.cdx.json` +
  `efterlev-<VERSION>-sdist-sbom.cdx.json`. The job creates the
  Release if `post-release-triage.yml` hasn't yet (race-tolerant);
  triage's `gh release edit --notes-file` path correctly handles
  the "Release exists, replace notes" case. Final tags only — rc
  tags don't get a public Release page. (PR #253)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1500 unchanged (CI-only change; no Python source touched).
- Source files: 222 unchanged.
- CLI commands: 30 unchanged.

## [0.1.56] — 2026-05-11

**Single-PR feature: `efterlev detectors show <id>` — read/inspect
counterpart that completes the detectors-CLI symmetry.** Third
verb after `detectors list` (registry summary, existing) and
`detectors new` (write/scaffold, v0.1.53). Surfaces what
`detectors list` elides: mapping.yaml KSI/control coverage notes,
evidence.yaml shape (per-record `content` keys), README lead
paragraph, and fixture file counts.

Useful for contributors choosing what to extend (read the existing
detector's notes to see if a new gap fits the same KSI), and for
operators trying to understand what a scanned-evidence record
means without opening the source tree.

### Added

- `efterlev detectors show <detector_id>` CLI command. Each
  section degrades gracefully: missing `mapping.yaml` /
  `evidence.yaml` / `README.md` / `fixtures/` skips that section
  rather than erroring. Detectors registered from outside the
  source tree (e.g. third-party packages) print only the
  registry-level header. Unknown id exits 1 with helpful
  suggestions: substring overlaps first, then cloud-prefix
  fallback, then a pointer at `detectors list`. (PR #251)

### Internal (count deltas)

- Detector count: 66 unchanged.
- KSI-mapped detectors: 62 unchanged.
- Tests: 1490 → 1500 (+10 — `tests/test_detectors_show.py`).
- Source files: 222 unchanged (the new command is a function
  inside `cli/main.py`).
- CLI commands: 29 → 30.

## [0.1.55] — 2026-05-11

**Single-PR detector: `github.branch_protection` (KSI-PIY-RSD; SA-15
+ CM-2).** First detector under `detectors/github/` that reads
Terraform source rather than `.github/workflows/*.yml`. Joins
`github.piy_sdlc_security_gates` on the same KSI: workflow gates
run on PRs; branch protection enforces that PRs require those
gates to pass before merge. Together they cover the configured-
gate half of KSI-PIY-RSD's `partial` classification at both the
workflow layer and the merge-enforcement layer.

Two binary states: `protections_present` (any of
`required_status_checks` / `required_pull_request_reviews` /
`enforce_admins=true`) and `protections_absent` — the canonical
"branch protection rule declared but enforces nothing" gap where
the GitHub API accepts the resource and the boundary owner can
point at it during audit, but no actual merge-time gate is in
place.

### Added

- `github.branch_protection` detector. Walks `github_branch_protection`
  Terraform resources and emits one Evidence record per resource
  describing whether the rule actually enforces a meaningful merge-
  time gate. Coverage `partial` — presence of the blocks doesn't
  prove the values are appropriate (`required_approving_review_count=0`
  is meaningless; an empty `contexts` list is meaningless). The
  Gap Agent reasons about specific values from the `detail` field.
  (PR #249)

### Diagnostics

- `friendly_errors` for Anthropic HTTP 400 now includes the API
  response body in the hint (was hidden behind a canned "this is
  usually a code-level bug" message), and pattern-matches the
  account-level monthly-spend-cap body (`"API usage limit"` /
  `"regain access"`) to a quota classification with cap-bump and
  Bedrock-backend remediation hints. Forced surface during
  PR #249 e2e debugging when efterlev's `ANTHROPIC_API_KEY` hit
  its monthly cap and Anthropic returned 400 (not 429), making
  the failure look like a code regression for ~30 minutes before
  the diagnostic landed. (PR #249)

### Internal (count deltas)

- Detector count: 65 → 66 (`github.branch_protection`).
- KSI-mapped detectors: 61 → 62.
- Detector sources: 56 → 57 Terraform (KSI-mapped); GitHub-workflows
  count unchanged at 5; supplementary unchanged at 4.
- Tests: 1483 → 1490 (+7 — `tests/detectors/test_github_branch_protection.py`).
- Source files: 220 → 222 (the new detector folder adds
  `__init__.py` + `detector.py`).

## [0.1.54] — 2026-05-11

**Single-PR feature: `efterlev boundary set --interactive` —
contributor / first-time-user friction reducer for boundary glob
entry.** Held in `LIMITATIONS.md` "Future ideas" since v0.1.18+;
second small focused single-PR feature after v0.1.53's
detectors-new scaffolder. Walks the user through include +
exclude glob entry instead of requiring them to remember the
`--include`/`--exclude` flag syntax.

### Added

- `--interactive` / `-i` flag on `efterlev boundary set`. When
  passed, prompts repeatedly for include + exclude globs (empty
  input ends each section), shows a preview, and asks for
  confirmation before writing `[boundary]` to
  `.efterlev/config.toml`. Mutually exclusive with
  `--include`/`--exclude` (clear error + exit 2 if combined).
  Bail-fast: if no globs entered, returns early without
  prompting for confirmation, and the caller refuses with "no
  globs supplied" + exit 2 (avoids wiping existing config).
  The non-interactive `--include`/`--exclude` path is unchanged.
  (PR #247)

### Internal (count deltas)

- Detector count: 65 unchanged.
- KSI-mapped detectors: 61 unchanged.
- Tests: 1477 → 1483 (+6 — `tests/test_boundary_set_interactive.py`).
- Source files: 220 unchanged (the helper is a function inside
  `cli/main.py`).
- CLI commands: 29 unchanged (extending existing `boundary set`).

### Cross-references

- `LIMITATIONS.md` "Future ideas" — "Boundary-scoping interactive
  helper" deferral, removed in this release since it shipped.
- v0.1.53 release (PR #246) — the prior single-PR-feature release
  (detectors-new scaffolder).

## [0.1.53] — 2026-05-11

**Single-PR feature: `efterlev detectors new <id>` — contributor
scaffolder for the 5-file detector folder convention.** Held in
`LIMITATIONS.md` "Future ideas" since the v0.1.18+ planning surface;
ships as a small focused OSS-friction reducer after the multi-batch
ConMon Lite arc closed.

### Added

- New CLI command `efterlev detectors new <detector_id>` —
  generates the canonical 5-file detector folder skeleton plus
  fixture directories. Argument: `<cloud>.<snake_case_name>`
  (e.g. `aws.foo_bar`). Cloud must be one of `aws / github / gcp
  / azure`; name must be snake_case starting with a letter.
  Options: `--ksi KSI-X` (repeatable; default empty →
  supplementary 800-53-only detector), `--control X-NN[(N)]`
  (repeatable), `--source terraform | terraform-plan | github`
  (default `terraform`). Refuses to overwrite an existing folder.
  The generated `detector.py` is a registration-ready stub with
  the `@detector` decorator + an empty `detect()` function. The
  generated `mapping.yaml`, `evidence.yaml`, and `README.md`
  include TODO placeholders keyed off the requested KSIs +
  controls. The scaffolder writes into the `efterlev` package's
  source tree (located via `efterlev.detectors.__file__`), so it
  works from a checkout (the typical contributor workflow) AND
  from a site-packages install. (PR #245)

### Internal (count deltas)

- Detector count: 65 unchanged.
- KSI-mapped detectors: 61 unchanged.
- Tests: 1468 → 1477 (+9 — `tests/test_detectors_new_scaffolder.py`).
- Source files: 220 unchanged (the scaffolder lives in `cli/main.py`).
- CLI commands: 28 → 29 (+1 — `efterlev detectors new`).

### Cross-references

- `LIMITATIONS.md` "Future ideas" — "Detector contribution
  scaffolder" deferral, removed in this release since it shipped.
- v0.1.52 release (PR #244) — the prior release shipping ConMon
  Lite v1.

## [0.1.52] — 2026-05-11

**Tier 4 #2: ConMon Lite v1 — Gap-Agent KSI-verdict regression
diff with 2-of-3 majority voting.** Closes the verdict-stability
deferral from Tier 4 #1. Opt-in via `EFTERLEV_CONMON_LITE_V1` repo
variable (default OFF; per-PR cost ~$0.90 on Sonnet 4.6, lower on
Bedrock). When enabled, every PR gets a SECOND sticky comment
(distinct from the v0 scanner-only delta) listing KSIs whose
verdict regressed (implemented → partial / not_implemented).

### Added

- `--runs N` flag on `efterlev agent gap` (default 1; preserves
  existing single-run behavior). When N > 1, the multi-run path
  invokes the Gap Agent N times in a loop and reduces per-KSI to
  the majority verdict via `Counter` + `ceil(N/2)` threshold.
  Tie-break picks the most-conservative verdict from the tied set
  (precedence: `implemented < partial < not_implemented <
  not_applicable < evidence_layer_inapplicable`); KSIs whose top
  vote count is below the threshold are recorded as flickering.
  (PR #242)
- New module `src/efterlev/agents/multi_run.py`:
  `aggregate_gap_reports(reports) -> (synthesized_report,
  per_run_verdicts, flickering_ksis)`. Pure function; sources
  rationale + evidence_ids from the FIRST run that voted majority
  (deterministic + traceable); sources `claim_record_ids` +
  `unmapped_findings` from the LAST run (most-recently persisted
  to the provenance store). (PR #242)
- New gap-report JSON sidecar fields: `runs_aggregated: int`,
  `per_run_verdicts: dict[ksi_id, list[verdict]]`,
  `flickering_ksis: list[str]`. Always emitted for forward
  compatibility; defaults when single-run. (PR #242)
- `--print-markdown` + `--base-branch` flags on `efterlev report
  diff` (mirrors the `scan-diff` CLI's pattern). Captures the v1
  PR-comment body for the workflow's posting step. (PR #243)
- `render_gap_diff_markdown` function in
  `src/efterlev/reports/gap_diff.py`. Renders a `GapDiff` as the
  markdown PR-comment body with the distinct
  `<!-- efterlev-conmon-lite-v1 -->` marker. Per DECISIONS
  Decision #4, scope is REGRESSED KSIs only — improvements appear
  in the JSON sidecar / HTML report. Tail-truncate at `max_rows`.
  (PR #243)

### Changed

- `.github/workflows/pr-compliance-scan.yml` extended with the
  ConMon Lite v1 path, gated on the `EFTERLEV_CONMON_LITE_V1` GH
  Actions repo variable being `"true"`. When enabled: PR-branch
  Gap Agent runs with `--runs 3`; new step scans the base branch
  with `--runs 3` (reuses the `/tmp/efterlev-conmon-base/`
  worktree the v0 step set up); new step computes the KSI-verdict
  diff via `efterlev report diff --print-markdown`; new step
  posts the v1 sticky comment with `<!-- efterlev-conmon-lite-v1
  -->` marker. v0 + v1 comments coexist on the same PR (different
  audiences: v0 for code reviewers, v1 for compliance reviewers).
  (PR #243)

### Internal (count deltas)

- Detector count: 65 unchanged.
- KSI-mapped detectors: 61 unchanged.
- Tests: 1455 → 1468 (+13 — 10 in `tests/test_multi_run.py`,
  3 in `tests/test_gap_diff.py`).
- Source files: 219 → 220 (+1 — `multi_run.py`).
- CLI commands: 28 unchanged (extended existing commands rather
  than adding new ones).

### ConMon Lite v0 + v1 status (post-this-release)

| Layer | Marker | Audience | Default | Cost/PR |
|---|---|---|---|---|
| v0 (per-detector gap emissions) | `<!-- efterlev-conmon-lite -->` | Code reviewers | ON | free (deterministic) |
| v1 (KSI-verdict regressions) | `<!-- efterlev-conmon-lite-v1 -->` | Compliance reviewers | OFF (opt-in via `EFTERLEV_CONMON_LITE_V1`) | ~$0.90 (Sonnet 4.6) |

Both coexist on the same PR when v1 is enabled. Each surfaces a
different layer of the regression signal; reading either alone is
useful but the two together are the full picture.

### What's still deferred to future ConMon Lite work

- **Configurable severity thresholds** (which KSI verdict
  transitions warrant block vs warn).
- **Gating policy** (block-on-regress with skip label).
- **Drift detection over time** (not just PR-delta but
  base-vs-prior-base; would need a stored baseline rather than
  ephemeral CI artifacts).
- **Suppression annotations**
  (`# efterlev-ignore: KSI-CNA-RVP`).

### Cross-references

- DECISIONS 2026-05-11 "Tier 4 #2 design: ConMon Lite v1
  (Gap-Agent KSI-verdict diffs with 2-of-3 voting)" (PR #241) —
  the locking entry.
- DECISIONS 2026-05-11 "Tier 4 #1 design: ConMon Lite (PR-delta
  scan comparison)" (PR #237) — the v0 entry whose Decision #2
  deferred this work; this release closes that deferral.
- v0.1.51 release (PR #240) — the prior release shipping ConMon
  Lite v0.

## [0.1.51] — 2026-05-11

**Tier 4 #1: ConMon Lite v0 — the first non-detector strategic
batch since the Tier 3 WAF arc closure.** PR-delta scan
comparison: every PR now gets a sticky comment listing
newly-introduced gaps relative to the base branch. Scanner-only
at v0 (deterministic + free); KSI-verdict diffs deferred to
ConMon Lite v1 once a verdict-stability mechanism is in place.

### Added

- New CLI command `efterlev scan-diff <prior> <current>` —
  per-detector gap-emission diff between two scan-result JSON
  sidecars. Outputs `.efterlev/reports/scan-diff-<ts>.html`
  (full HTML report including resolved gaps for context),
  `.efterlev/reports/scan-diff-<ts>.json` (machine-readable
  structured diff), and optional `--print-markdown` for the
  PR-comment surface. Exit code 2 if any new or modified gaps
  (CI-friendly soft-fail signal). (PR #238)
- `efterlev scan` now emits a JSON sidecar at
  `.efterlev/reports/scan-<ts>.json` alongside the existing
  HTML output. Mirrors the gap/documentation/remediation
  sidecar pattern. Schema v1 fields: `schema_version`,
  `generated_at`, `scan_root`, `scan_mode` (hcl/plan),
  `summary`, `evidence` (per-record `detector_id`, resource
  info, `source_ref`, `content`). The provenance store remains
  the source of truth for within-workspace queries; the sidecar
  is the portable input format for cross-branch diffing. (PR #238)
- New module `src/efterlev/reports/scan_diff.py`:
  `compute_scan_diff` (pure function), `render_scan_diff_markdown`
  (PR-comment renderer), `render_scan_diff_html` (HTML report
  renderer), `ScanDiff` + `ScanDiffEntry` Pydantic models.
  Diff keying is `(detector_id, resource_name)`; three
  outcomes: `new_gap`, `resolved_gap`, `modified_gap`.
  Canonical gap predicate: an evidence record is a gap iff its
  content payload contains a string `gap` field. (PR #238)

### Changed

- `.github/workflows/pr-compliance-scan.yml` extended with
  base-branch scan + ConMon Lite delta-comment posting. Bumped
  checkout `fetch-depth: 1 → 0` so the workflow can
  `git worktree add` the base branch into a sibling directory.
  New steps: "Scan base branch (ConMon Lite v0)", "Compute
  ConMon Lite PR-delta", "Post / update ConMon Lite delta PR
  comment". The new sticky comment uses the
  `<!-- efterlev-conmon-lite -->` marker, distinct from the
  existing posture-comment marker so the two coexist on the
  same PR. Soft-fail at the workflow level: scan-diff exits 2
  on regressions, which IS the signal we want. (PR #239)

### Internal (count deltas)

- Detector count: 65 unchanged.
- KSI-mapped detectors: 61 unchanged.
- Tests: 1442 → 1455 (+13 — the new `tests/test_scan_diff.py`).
- Source files: 218 → 219 (+1 — the new `scan_diff.py`).
- CLI commands: 27 → 28 (+1 — `efterlev scan-diff`).

### ConMon Lite v0 vs v1 boundaries

**v0 ships (this release):**
- Per-detector gap-emission diff (deterministic, scanner-only).
- New + modified + resolved gap classification.
- Soft-fail PR-comment posting; no merge gating.

**v1 deferred:**
- Gap-Agent KSI-verdict regressions ("KSI X flipped from
  implemented to partial"). Requires a verdict-stability
  mechanism (probably 2-of-3 vote or fixed-RNG prompts) to
  dampen Haiku stochasticity. Tier 4 #2 candidate.
- Configurable severity thresholds.
- Gating policy (block-on-regress with skip label).
- Drift detection over time (not just PR-delta).
- Suppression annotations
  (`# efterlev-ignore: aws.security_group_open_ingress`).

### Cross-references

- DECISIONS 2026-05-11 "Tier 4 #1 design: ConMon Lite (PR-delta
  scan comparison)" (PR #237) — the locking entry.
- v0.1.50 release (PR #236) — the prior release; closes the
  Tier 3 WAF family arc that occupied v0.1.46–v0.1.50.
- `LIMITATIONS.md` "ConMon Lite" deferral since v0.1.18+ — now
  shipped at the v0 layer.

## [0.1.50] — 2026-05-10

**Tier 3 #5: `aws.waf_custom_rule_groups` — closing the `aws.waf_*`
family at 7 of 7 v0/v1 dimensions shipped.** The WAF family arc
spanning 5 batches across 5 releases (v0.1.46 #1, v0.1.47 #2
streaming refactor, v0.1.48 #3, v0.1.49 #4, v0.1.50 #5) is now
complete. Detector count rises 64 → 65; KSI-mapped 60 → 61.
KSI-CNA-RVP cross-coverage rises 8 → 9, the most
cross-resource-type-evidenced KSI in the library by a wide margin
(next-most: KSI-MLA-LET at 5). The 3-dimension SC-7 evidence base
(geo / IP / custom) + 2-dimension AC-3 evidence base (IP / geo) +
the bulk SI-3 coverage make the WAF family the most
cross-control-evidenced detector family.

### Added (Tier 3 #5)

- `aws.waf_custom_rule_groups` (KSI-CNA-RVP, controls SI-3/SC-7) —
  cross-resource detector that walks both `aws_wafv2_web_acl` AND
  `aws_wafv2_rule_group` resources. For each Web ACL, walks rules
  looking for `statement.rule_group_reference_statement.arn`
  references; emits per Web ACL whether any references exist. Two
  states (binary): `custom_rule_groups_present` (lists deduplicated
  referenced ARN strings, with a `defined_rule_groups` inventory
  field), `custom_rule_groups_absent` (gap message surfaces the
  `defined_rule_groups` inventory so the Gap Agent can flag the
  canonical "defined but unreferenced" anti-pattern explicitly —
  a customer paying for the rule-group plumbing without the
  protection). Per DECISIONS Decision #3 carry-forward, no
  cross-resource VALIDATION at the detector layer — ARN strings
  emitted as-is; Gap Agent handles cross-reference resolution.
  9th detector evidencing KSI-CNA-RVP. (PR #234)

### Changed

- `evals/fixtures/serverless-mixed/` rev 7 — extends rev 6 with
  one new rule on `api_protection` (rule_group_reference_statement
  pointing at the new top-level `aws_wafv2_rule_group` resource
  `api_specific_rules`). The bare `legacy_unprotected_waf` ACL now
  exercises both the negative path AND the "defined but
  unreferenced" inventory hint (the api_specific_rules group is
  defined in scope but the legacy ACL doesn't reference it).
  After rev 7, the fixture exercises ALL 7 WAF detectors at both
  posture extremes. (PR #235)

### Internal (count deltas)

- Detector count: 64 → 65 (+1).
- KSI-mapped detectors: 60 → 61 (+1, KSI-CNA-RVP already covered).
- KSI-CNA-RVP detector cross-coverage: 8 → 9.
- Eval-harness fixtures: 5 unchanged; serverless-mixed at rev 7.
- Test count: 1435 → 1442 (+7 unit tests).
- Source files: 216 → 218 (+2 for the new detector).
- `tests/test_cli.py` KSI-mapped narrative comment condensed (was
  ~35 lines tracking each tier bump; now a 4-line pointer to
  CHANGELOG history) — appropriate now that the WAF arc completes.

### WAF family closure summary

The `aws.waf_*` family v0/v1 arc is now complete. **5 batches
across 5 releases tonight** built up the family from 0 to 7
detectors:

| Release | Tier | Adds |
|---|---|---|
| v0.1.46 | Tier 3 #1 | `waf_rule_count`, `waf_managed_rule_groups`, `waf_rate_limiting` |
| v0.1.47 | Tier 3 #2 | (no new detectors — streaming refactor + cap lift to 32768 unblocking the family's growth) |
| v0.1.48 | Tier 3 #3 | `waf_action_types` (3-state), `waf_ip_set_blocking` (first WAF AC-3) |
| v0.1.49 | Tier 3 #4 | `waf_geo_blocking` (first WAF SC-7) |
| v0.1.50 | Tier 3 #5 | `waf_custom_rule_groups` (cross-resource) |

`serverless-mixed` rev 4 → rev 7 grew to exercise the full family.
KSI-CNA-RVP went from 2 detectors (cna_dos_protection +
api_gateway_waf_attached) to 9.

### Cross-references

- DECISIONS 2026-05-10 "Tier 3 #5 design: aws.waf_custom_rule_groups
  (closes the WAF family at 7/7)" (PR #233) — the locking entry.
- DECISIONS 2026-05-10 "Tier 3 #1 design" (PR #213) — Decision #7
  deferred this dimension; this release closes that deferral.
- v0.1.49 release (PR #232) — the prior release shipping Tier 3 #4.

### Tier 3 status

All Tier 3 batches complete:

- ✅ Tier 3 #1 (v0.1.46): `waf_rule_count`, `waf_managed_rule_groups`, `waf_rate_limiting`
- ✅ Tier 3 #2 (v0.1.47): streaming refactor + max_tokens cap lift 20480 → 32768
- ✅ Tier 3 #3 (v0.1.48): `waf_action_types`, `waf_ip_set_blocking`
- ✅ Tier 3 #4 (v0.1.49): `waf_geo_blocking`
- ✅ **Tier 3 #5 (this release): `waf_custom_rule_groups` — closes the WAF family at 7/7**

Future Tier 4 candidates (rule-group-version pinning, scope-down
breadth, custom-aggregation keys, action-type appropriateness
per managed-group) get separate scoping passes when there's
customer pull or specific findings.

## [0.1.49] — 2026-05-10

**Tier 3 #4 `aws.waf_geo_blocking`: 1 new detector closing the
geo-blocking dimension** deferred from Tier 3 #1 Decision #7.
Detector count rises 63 → 64; KSI-mapped 59 → 60. KSI-CNA-RVP
cross-coverage rises 7 → 8 (most cross-resource-type-evidenced
KSI in the library by a wide margin). New 800-53 mapping for the
WAF family: SC-7 (Boundary Protection) — first WAF detector to
evidence boundary protection at the IaC layer.

### Added (Tier 3 #4)

- `aws.waf_geo_blocking` (KSI-CNA-RVP, controls SC-7/AC-3) —
  per-`aws_wafv2_web_acl` evidence on whether at least one rule
  references a `statement.geo_match_statement`. Two states
  (binary): `geo_blocking_present` (lists deduplicated, sorted set
  of country codes covered across all geo rules — ISO 3166-1
  alpha-2), `geo_blocking_absent` (gap message that explicitly
  names "may be intentional for global-customer workloads" so the
  Gap Agent reasons about whether absence is appropriate, not the
  detector). For US-federal workloads the canonical posture
  blocks embargoed countries (KP, IR, CU, SY, plus sanctioned
  subsets of RU). **First WAF-family detector to evidence SC-7
  (Boundary Protection)** at the IaC layer — geo-blocking IS the
  canonical perimeter-side boundary control at the country level;
  the existing SC-7 evidence base is heavily VPC-internal, this
  widens it to the public-internet perimeter. AC-3 mapping
  generalizes the IP-layer mapping that `aws.waf_ip_set_blocking`
  earned in Tier 3 #3 up one layer of the network stack. 8th
  detector evidencing KSI-CNA-RVP. (PR #230)

### Changed

- `evals/fixtures/serverless-mixed/` rev 6 — extends rev 5 with
  one new rule on `api_protection`: a geo-match block rule
  blocking the canonical embargoed-country set (`KP`, `IR`, `CU`,
  `SY`). The bare `legacy_unprotected_waf` ACL exercises the
  negative path. After rev 6, all SIX WAF detectors fire
  positively on `api_protection` and (excluding `action_types`
  which goes vacuously enforcing on the empty rule set) negatively
  on `legacy_unprotected_waf`. (PR #231)

### Internal (count deltas)

- Detector count: 63 → 64 (+1 — see Added section above).
- KSI-mapped detectors: 59 → 60 (+1 — KSI-CNA-RVP already
  covered; widens the resource-type evidence base. Total
  covered-KSI count unchanged at 37/60).
- KSI-CNA-RVP detector cross-coverage: 7 → 8.
- Eval-harness fixtures: 5 unchanged; serverless-mixed at rev 6.
- Test count: 1428 → 1435 (+7 unit tests for the new detector).
- Source files: 214 → 216 (+2 for the new detector).

### Cross-references

- DECISIONS 2026-05-10 "Tier 3 #4 design: aws.waf_geo_blocking
  (single-detector batch)" (PR #229) — the locking entry. Seven
  governing design choices including "two states, NOT three
  (intentional-vs-unintentional axis belongs in the Gap Agent)"
  and "first WAF detector to evidence SC-7".
- DECISIONS 2026-05-10 "Tier 3 #1 design" (PR #213) — Decision #7
  deferred this dimension; this release closes it.
- DECISIONS 2026-05-10 "Tier 3 #3 design" (PR #223) — Decision #7
  carry-forward kept this dimension deferred for individual
  scoping; this release closes that scoping pass.
- v0.1.48 release (PR #227) — the prior release shipping Tier 3 #3.

### Tier 3 status

After this release, the WAF family is at **6 of 7 v0/v1 dimensions
shipped**:

- ✅ rule_count (v0.1.46)
- ✅ managed_rule_groups (v0.1.46)
- ✅ rate_limiting (v0.1.46)
- ✅ action_types (v0.1.48)
- ✅ ip_set_blocking (v0.1.48)
- ✅ geo_blocking (this release)
- ⏸ custom_rule_groups — deferred for Tier 3 #5; cross-resource
  matching pattern needs its own scoping pass

## [0.1.48] — 2026-05-10

**Tier 3 #3 `aws.waf_*` family v1: 2 new detectors closing the
action-type + IP-set-blocking dimensions** deferred from Tier 3 #1
Decision #7. Detector count rises 61 → 63; KSI-mapped 57 → 59.
KSI-CNA-RVP cross-coverage rises 5 → 7 (most cross-resource-type-
evidenced KSI in the library by a wide margin). New 800-53 mapping
for the WAF family: AC-3 (Access Enforcement) on
`aws.waf_ip_set_blocking`.

### Added (Tier 3 #3)

- `aws.waf_action_types` (KSI-CNA-RVP, controls SI-3/SC-5) —
  per-`aws_wafv2_web_acl` evidence classifying the rules' action
  posture as `enforcing` (every rule has block/allow/captcha or
  override_action.none), `observing_only` (every declared rule is
  count-action — the canonical "WAF that observes but does not
  enforce" gap), or `mixed` (both — informational, NOT a gap by
  itself; legitimate ramp-up tactic). The canonical gap this
  detector closes: a managed-group rule with `override_action {
  count {} }` looks like protection in the AWS console but blocks
  nothing. Three states (vs Tier 3 #1's binary detectors) per
  DECISIONS Decision #3 — the third state has real informational
  value the Gap Agent can reason about. 6th detector evidencing
  KSI-CNA-RVP. (PR #224)
- `aws.waf_ip_set_blocking` (KSI-CNA-RVP, controls SC-5/AC-3) —
  per-`aws_wafv2_web_acl` evidence on whether at least one rule
  references an IP-set blocklist via
  `statement.ip_set_reference_statement`. Two states (binary):
  `ip_set_blocking_present` (lists the referenced ARN strings),
  `ip_set_blocking_absent`. **First WAF-family detector to evidence
  AC-3 (Access Enforcement)** at the IaC layer — the mapping is
  honest: an IP-set reference with a block action is the AWS-native
  primitive that enforces access control by source IP, independent
  of any application-layer authentication or authorization. Per
  DECISIONS Decision #1 carry-forward, no cross-resource matching
  at the detector layer — the ARN strings (typically Terraform
  interpolations) are emitted as-is and the Gap Agent resolves
  them. 7th detector evidencing KSI-CNA-RVP. (PR #225)

### Changed

- `evals/fixtures/serverless-mixed/` rev 5 — extends rev 4 with two
  new rules on `api_protection`: a count-action managed-group rule
  (KnownBadInputsRuleSet, `override_action.count`) producing
  `waf_action_types` mixed state, and an IP-set blocking rule
  (`block-bad-actor-ips`, `ip_set_reference_statement`) producing
  `waf_ip_set_blocking` present. Plus a new top-level
  `aws_wafv2_ip_set.bad_actors_blocklist` resource so the
  cross-resource ARN reference resolves. The bare
  `legacy_unprotected_waf` ACL exercises the negative path of
  `waf_ip_set_blocking` (and emits vacuously enforcing on
  `waf_action_types` per its DECISIONS Decision #3 — the
  rules-absent gap is already flagged by `waf_rule_count`). After
  rev 5, the fixture exercises ALL FIVE WAF detectors at both
  posture extremes. (PR #226)

### Internal (count deltas)

- Detector count: 61 → 63 (+2 — see Added section above).
- KSI-mapped detectors: 57 → 59 (+2 — both new detectors map to
  KSI-CNA-RVP, which was already covered. Total covered-KSI count
  unchanged at 37/60).
- KSI-CNA-RVP detector cross-coverage: 5 → 7. KSI-CNA-RVP is now
  the most cross-resource-type-evidenced KSI in the library by a
  wide margin (next-most: KSI-MLA-LET at 5 detectors).
- Eval-harness fixtures: 5 unchanged; serverless-mixed at rev 5.
- Test count: 1413 → 1428 (+15 — 8 + 7 unit tests across the two
  new detector test files).
- Source files: 210 → 214 (+4 — 2 files per new detector × 2 = 4).

### Cross-references

- DECISIONS 2026-05-10 "Tier 3 #3 design: aws.waf_* family v1 —
  action types + IP-set blocking" (PR #223) — the locking entry.
  Seven governing design choices including "two-detector batch is
  the right size for the clean dimensions" and "first WAF detector
  to evidence AC-3 at the IaC layer".
- DECISIONS 2026-05-10 "Tier 3 #1 design" (PR #213) — Decision #7
  deferred this batch. After v0.1.48, two of the four originally-
  deferred WAF dimensions are shipped (action_types, ip_set_blocking);
  two remain deferred (geo_blocking, custom_rule_groups) per Tier 3
  #3 Decision #7 carry-forward, each pending its own scoping pass.
- v0.1.46 release (PR #218) — Tier 3 #1 v0 ship date.
- v0.1.47 release (PR #222) — Tier 3 #2 streaming refactor that
  gives this batch headroom past 20480 max_tokens.

### Tier 3 status

After this release, Tier 3 #1 (waf_* family v0), Tier 3 #2 (streaming
refactor + cap lift), and Tier 3 #3 (waf_* family v1) are all fully
shipped. Five of seven WAF dimensions shipped:

- ✅ rule_count (v0.1.46)
- ✅ managed_rule_groups (v0.1.46)
- ✅ rate_limiting (v0.1.46)
- ✅ action_types (this release)
- ✅ ip_set_blocking (this release)
- ⏸ geo_blocking — deferred per Tier 3 #1/#3 Decision #7; needs own
  scoping pass for the intentional-absence shape
- ⏸ custom_rule_groups — deferred; needs own scoping pass for the
  cross-resource matching pattern

## [0.1.47] — 2026-05-10

**Tier 3 #2 streaming refactor + cap lift to 32768.** Anthropic-direct
`max_tokens` ceiling moves 20480 → 32768, matching Bedrock; the
non-streaming "streaming required for operations that may take longer
than 10 minutes" pre-flight no longer applies. Unblocks fixture
growth and customer-codebase scans previously gated by the cap. No
new detectors, no new KSI mappings, no test count change — this is
an architectural fix to a recurring failure mode that bit twice in
the v0.1.46 patch arc (PR #215 and PR #217 both flaked at the
20480-cap boundary on first attempt and cleared on rerun).

### Changed

- `src/efterlev/llm/anthropic_client.py` — `_one_call` now uses the
  streaming API (`client.messages.stream(...)` context manager) in
  place of `client.messages.create(...)`. Streaming is unconditional
  per DECISIONS Decision #1 (one code path, not two). Public API at
  the agent layer is unchanged: `complete()` still returns the same
  `LLMResponse` shape; the SDK's `stream.get_final_message()` exposes
  `.content`, `.stop_reason`, `.model`, and `.usage` identical to the
  non-streaming response, so the response-validation block + the
  truncation-detection block + the token-usage telemetry are all
  unchanged from the pre-refactor implementation. The retry helper
  (PR #193 Haiku stochastic-rejection) keeps working untouched.
  (PR #220)
- `src/efterlev/agents/gap.py` — `_resolve_max_tokens(default_anthropic=20480, ...)`
  → `_resolve_max_tokens(default_anthropic=32768, ...)`. Replaced
  the obsolete 23-line "Backend-aware default" rationale comment
  (which walked through the v0.1.0/v0.1.1 16384/32768 failure
  history) with a 6-line note pointing at the DECISIONS entry +
  streaming refactor. Documentation Agent and Remediation Agent
  audited per the DECISIONS Decision #1 — neither passes a high
  `max_tokens` (Documentation uses the 4096 default; Remediation
  passes 8192) so neither needed a change. (PR #221)

### Internal

- Bedrock client untouched per DECISIONS Decision #6 — its cap is
  already where we want it; adding streaming to Bedrock is a
  separate change with a separate test surface and zero current
  motivating bug.
- Test surface unchanged at 1413 (the streaming refactor swapped
  the fake SDK shape from `_FakeMessages.create()` returning a
  response to `_FakeMessages.stream()` returning a `_FakeStream`
  context manager, but the assertions are unchanged).
- Source files unchanged at 210.
- Detector count unchanged at 61. KSI-mapped count unchanged at 57.

### Verified end-to-end

`tests/test_deep_smoke.py::test_s5_v0_1_38_quickstart_with_invalid_api_key_friendly_error`
passes against the real Anthropic API at `max_tokens=32768` with the
streaming refactor in place. Without the streaming refactor (cap
bump alone), the SDK rejects the request pre-flight with
"Streaming is required" — exactly the failure mode the refactor
removes.

### Cross-references

- DECISIONS 2026-05-10 "Tier 3 #2 design: stream the Anthropic
  client" (PR #219) — the locking entry. Six governing design
  choices including "streaming is unconditional", "no public API
  change at the agent layer", "Bedrock untouched".
- v0.1.46 release (PR #218) — the prior release. PRs #215 and #217
  both hit the 20480 cap on first attempt; PR #217's flake was
  the immediate motivating evidence cited in the DECISIONS entry.
- DECISIONS 2026-05-10 "Tier 3 #1 design: aws.waf_* detector family
  v0" (PR #213) — the batch whose fixture rev surfaced this as a
  recurring failure.

### Tier 3 status

After this release, Tier 3 #1 (aws.waf_* family v0) and Tier 3 #2
(streaming refactor + cap lift) are both fully shipped. Next
candidate: Tier 3 #3, scoped against the Tier 3 #1 Decision #7
deferred WAF dimensions (action types, geo-blocking, IP-set
blocking, custom rule groups) -- DECISIONS entry to follow.

## [0.1.46] — 2026-05-10

**Tier 3 #1 `aws.waf_*` detector family v0: 3 new detectors closing
the WAF-posture-quality dimension that the Tier 2 #3
`aws.api_gateway_waf_attached` left unaddressed. Rule presence,
managed-rule-group references, and rate-based statements are now
evidenced per Web ACL, with serverless-mixed fixture rev 4
exercising both posture extremes in one fixture. Detector count
rises 58 → 61; KSI-mapped 54 → 57. KSI-CNA-RVP detector
cross-coverage rises 2 → 5.**

### Added (Tier 3 #1)

- `aws.waf_rule_count` (KSI-CNA-RVP, controls SI-3/SC-5) — per-Web-ACL
  evidence on whether `aws_wafv2_web_acl` declares at least one `rule`
  block. Two states (binary): `rules_present` (count ≥ 1),
  `rules_absent` (count == 0 — the canonical "WAF attached but does
  nothing" gap). Closes the gap where a Web ACL with
  `default_action { allow {} }` and zero rules passes
  `aws.api_gateway_waf_attached` (it IS attached) but provides no L7
  protection beyond the default action. 3rd detector evidencing
  KSI-CNA-RVP. (PR #214)
- `aws.waf_managed_rule_groups` (KSI-CNA-RVP, controls SI-3/RA-5(11))
  — per-Web-ACL evidence on whether at least one rule references an
  AWS- or vendor-managed rule group via
  `statement.managed_rule_group_statement`. Two states (binary):
  `managed_groups_present` (lists the group names in the detail
  field — e.g. `AWSManagedRulesCommonRuleSet`,
  `AWSManagedRulesKnownBadInputsRuleSet`), `managed_groups_absent`.
  Captures the gap where a Web ACL has only hand-written custom rules
  and lacks the bulk OWASP Top 10 / known-bad-input coverage that
  managed groups provide. Maps to RA-5(11) as a thin proxy signal:
  AWS-managed rule sets track CVE-class disclosures. 4th detector
  evidencing KSI-CNA-RVP. (PR #215)
- `aws.waf_rate_limiting` (KSI-CNA-RVP, controls SC-5/SC-5(2)) —
  per-Web-ACL evidence on whether at least one rule declares a
  rate-based statement via `statement.rate_based_statement`. Two
  states (binary): `rate_limiting_present` (lists each
  `(limit, aggregate_key_type)` tuple in the detail field — e.g.
  `limit=2000 key=IP`), `rate_limiting_absent`. Captures the gap
  where a Web ACL has managed groups but no per-client request cap
  — managed groups catch known-bad patterns but not novel volumetric
  abuse. 5th detector evidencing KSI-CNA-RVP. (PR #216)

### Changed

- `evals/fixtures/serverless-mixed/` rev 4 — extends rev 3 to also
  exercise all three Tier 3 #1 detectors. The existing
  `api_protection` Web ACL gains a managed-rule-group rule
  (CommonRuleSet) and a rate-based rule (limit=2000, IP) — positive
  emission for all three new detectors. A second `aws_wafv2_web_acl`
  `legacy_unprotected_waf` is added with no rules at all — negative
  emission for all three. KSI-CNA-RVP posture is now evidenced
  across 3 stages (waf_attached, +/-) PLUS 2 Web ACLs (3 detectors ×
  2 ACLs = 6 emissions). M3 cross-resource-type signal widens at the
  same KSI without changing the `partial` verdict. (PR #217)

### Internal (count deltas)

- Detector count: 58 → 61 (+3 — see Added section above).
- KSI-mapped detectors: 54 → 57 (+3 — all three new detectors map to
  KSI-CNA-RVP, which was already covered by `aws.cna_dos_protection`
  and `aws.api_gateway_waf_attached`. The new detectors widen the
  resource-type evidence base for KSI-CNA-RVP without adding first-time
  coverage. Total KSI count is unchanged at 37/60).
- KSI-CNA-RVP detector cross-coverage: 2 → 5 (now spans Shield-side
  DOS posture, APIGW-stage WAF attachment, Web-ACL rule presence,
  Web-ACL managed-rule-group references, Web-ACL rate-based
  statements).
- Eval-harness fixtures: 5 unchanged; serverless-mixed at rev 4.
- Test count: 1392 → 1413 (+21 — 6 + 7 + 8 unit tests across the
  three new detector test files).
- Source files: 204 → 210 (+6 — 2 files per new detector × 3 = 6).

### Cross-references

- DECISIONS 2026-05-10 "Tier 3 #1 design: aws.waf_* detector family
  v0" (PR #213) — locked the v0 scope and the three governing design
  calls (per-Web-ACL emission, no `unverifiable` state, no new KSI
  mappings).
- DECISIONS 2026-05-10 Tier 2 #3 — the entry that explicitly deferred
  the broader `aws.waf_*` family to Tier 3 (Decision #2). This
  release closes that deferral.
- v0.1.45 release (PR #210) — the prior release shipping Tier 2 #3.

### Tier 3 status

After this release, the original `aws.waf_*` family Tier 3 #1 v0
scope is **fully closed**: rule presence, managed-rule-group
references, and rate-based statements are evidenced. Future
extensions (action types, version pinning, scope-down breadth,
custom-aggregation keys) remain candidates for later Tier 3
batches but were explicitly out of v0 scope per DECISIONS
Decision #1.

## [0.1.45] — 2026-05-10

**Tier 2 #3 serverless detector batch: 3 new detectors closing the
original 5-detector deferred backlog from PR #196. Lambda VPC
isolation, API Gateway route-level auth, API Gateway WAF attachment.
Detector count rises 55 → 58; KSI-mapped 51 → 54. The new detectors
widen the resource-type evidence base for already-covered KSIs
(CNA family especially) without changing the total covered-KSI
count of 37/60. (Note: the original release headline framed two
of the cited KSIs as previously uncovered; corrected 2026-05-10 —
see the DECISIONS correction entry of that date.)**

### Added (Tier 2 #3)

- `aws.lambda_vpc_isolation` (KSI-CNA-MAT, controls SC-7/SC-7(3)) —
  per-Lambda evidence on whether the function declares a `vpc_config`
  block (network-isolated execution) or runs in the AWS-managed
  default VPC pool (internet-facing). Three states: `vpc_isolated`,
  `internet_facing`, `unverifiable`. 7th detector evidencing
  KSI-CNA-MAT and the library's first Lambda-side network-isolation
  evidence. Per the DECISIONS Decision #1: emits per-resource posture
  and lets the Gap Agent reason about intentionality (webhook
  handlers, public health endpoints). (PR #206)
- `aws.api_gateway_auth_required` (KSI-CNA-EIS + KSI-CNA-DFP, controls
  AC-3/AC-6) — per-route evidence on whether the route declares
  non-NONE authorization. Covers `aws_api_gateway_method`
  (REST v1, `authorization` field) and `aws_apigatewayv2_route`
  (HTTP v2, `authorization_type` field). Three states: `auth_required`,
  `auth_none`, `unverifiable`. **Adds APIGW route-level evidence for
  both KSI-CNA-EIS and KSI-CNA-DFP** — KSI-CNA-EIS was already evidenced
  by `aws.access_analyzer_enabled` (assessment slice via CA-7 + AC-6),
  KSI-CNA-DFP by `aws.ec2_imdsv2_required` (CM-2 baseline-configuration
  slice). This detector contributes the routing-edge slice; the three
  detectors together cover the KSIs across distinct resource-type
  surfaces. (PR #207. Correction note: the original PR #205 / #207
  framing of those KSIs as previously uncovered was incorrect —
  see the 2026-05-10 DECISIONS correction entry.)
- `aws.api_gateway_waf_attached` (KSI-CNA-RVP, controls SI-3/SC-5) —
  per-stage evidence on whether an `aws_wafv2_web_acl_association`
  references the stage by Terraform name. Two states (binary, no
  `unverifiable` per Decision #3 — interpolation in `resource_arn` is
  the norm). 2nd detector evidencing KSI-CNA-RVP (joins
  `aws.cna_dos_protection` on the Shield-side DOS protection). Per
  Decision #2: ships as a single WAF-attachment detector; the broader
  `aws.waf_*` family (rule coverage, rate limiting, geo-blocking,
  managed groups) deferred to Tier 3. (PR #208)

### Changed

- `evals/fixtures/serverless-mixed/` rev 3 — extends rev 2 to also
  exercise all three Tier 2 #3 detectors. Lambda `api_handler` gains
  `vpc_config`; new APIGW methods (`get_users` IAM, `get_health`
  NONE) + v2 route (`post_orders` JWT); new `aws_wafv2_web_acl` +
  association protecting `public_api_v1_prod_stage`. KSI-CNA-MAT,
  KSI-CNA-EIS, KSI-CNA-DFP, KSI-CNA-RVP added to the labeled set.
  After rev 3, the fixture exercises ALL SEVEN Tier 2 detectors and
  the original 5-detector deferred backlog from PR #196 is fully
  closed at both the detector layer AND the eval-harness regression
  surface. (PR #209)

### Internal (count deltas)

- Detector count: 55 → 58 (+3 — see Added section above).
- KSI-mapped detectors: 51 → 54 (+3 — all three new detectors map to
  KSIs already in the FRMR catalog AND already covered by at least one
  pre-existing detector; the new detectors widen the resource-type
  evidence base on those KSIs without adding first-time coverage. Total
  KSI count is unchanged at 37/60).
- KSI-CNA-MAT detector cross-coverage: 6 → 7 (now spans security_group,
  NACL, S3 PAB, RDS, S3 ACL, plus Lambda VPC isolation).
- KSI-CNA-RVP detector cross-coverage: 1 → 2 (joins
  `aws.cna_dos_protection`).
- Eval-harness fixtures: 5 unchanged; serverless-mixed at rev 3.
- Test count: 1365 → 1385 (+20 — 6 + 7 + 7 unit tests across the
  three new detector test files).
- Source files: 198 → 204 (+6 — 2 files per new detector × 3 = 6).

### Cross-references

- DECISIONS 2026-05-10 "Tier 2 #3 design: VPC isolation, route auth,
  WAF attachment" (PR #205) — locked the v0 scope and the three
  governing design calls (emit-and-let-agent-reason, ship-WAF-now,
  no-unverifiable-on-WAF).
- DECISIONS 2026-05-09 "Tier 2 #1 design" (PR #196) — the original
  entry that deferred these three detectors; this release closes
  the entire deferred backlog.
- v0.1.44 release (PR #204) — the prior release shipping Tier 2
  #1 + #2.

### Tier 2 status

After this release, the original 5-detector Lambda + API Gateway
deferred backlog from PR #196 is **fully closed**:

- ✅ Tier 2 #1: `aws.lambda_logging_configured`,
  `aws.api_gateway_tls_min_version` (v0.1.44)
- ✅ Tier 2 #2: `aws.lambda_env_kms_encryption`,
  `aws.api_gateway_access_logging` (v0.1.44)
- ✅ Tier 2 #3: `aws.lambda_vpc_isolation`,
  `aws.api_gateway_auth_required`, `aws.api_gateway_waf_attached`
  (this release)

Remaining serverless follow-ups: an `aws.waf_*` family (per Tier 2
#3 Decision #2) is the natural next-tier candidate.

## [0.1.44] — 2026-05-10

**Tier 2 serverless detector batches: 4 new detectors covering Lambda
observability, Lambda env-var KMS, API Gateway TLS-floor, and API
Gateway access logging, plus a new `serverless-mixed` eval-harness
fixture. Detector count rises 51 → 55; KSI-mapped 47 → 51.**

### Added (Tier 2 #1)

- `aws.lambda_logging_configured` (KSI-MLA-LET, controls AU-2/AU-12) —
  reads `aws_lambda_function` resources and emits one Evidence record
  per function describing whether a corresponding
  `aws_cloudwatch_log_group` is declared in the same plan/repo
  (matched by the canonical `/aws/lambda/<function_name>` naming
  convention). Three states: `configured`, `absent`, `unverifiable`
  (function_name uses Terraform interpolation). Library's first
  `aws_lambda_function`-side detector. (PR #197)
- `aws.api_gateway_tls_min_version` (KSI-SVC-SNT, controls
  SC-8/SC-13/SC-23) — reads `aws_api_gateway_domain_name` (REST API
  v1) and `aws_apigatewayv2_domain_name` (HTTP/WebSocket API v2)
  resources and emits one Evidence record per custom domain
  describing whether `security_policy` enforces TLS 1.2 or higher.
  Surfaces the canonical legacy gap where v1 custom domains created
  without an explicit `security_policy` accept TLS 1.0. (PR #198)
- New eval-harness fixture `evals/fixtures/serverless-mixed/` (rev 1)
  exercising both new Tier 2 #1 detectors with mixed posture (2
  Lambdas, 3 APIGW custom domains). 5th eval-harness fixture. (PR #199)

### Added (Tier 2 #2)

- `aws.lambda_env_kms_encryption` (KSI-AFR-UCM, controls
  SC-28/SC-28(1)) — reads `aws_lambda_function` resources whose
  `environment.variables` block is non-empty and emits one Evidence
  record per such function describing whether `kms_key_arn` is set
  (customer-managed-key encryption-at-rest of env-var values).
  Functions with no env vars are skipped (no secrets to protect).
  8th detector evidencing KSI-AFR-UCM. (PR #201)
- `aws.api_gateway_access_logging` (KSI-MLA-LET, controls AU-2/AU-3)
  — reads `aws_api_gateway_stage` (REST v1) and `aws_apigatewayv2_stage`
  (HTTP v2) resources and emits one Evidence record per stage
  describing whether an `access_log_settings` block is declared.
  Stage-shaped evidence (per-stage granularity matters: a single API
  can have prod with logging on and staging without). 5th detector
  evidencing KSI-MLA-LET — KSI-MLA-LET is now the most
  cross-resource-type-evidenced KSI in the library. (PR #202)

### Changed

- `evals/fixtures/serverless-mixed/` rev 2 — extends rev 1 to also
  exercise the Tier 2 #2 detectors. New `aws_kms_key.lambda_env_secrets`,
  env-vars + kms_key_arn on api_handler (positive on Tier 2 #2 PR β),
  env-vars without kms_key_arn on background_worker (negative).
  Three new stage resources covering both REST v1 prod-with-logs +
  staging-without (the canonical mixed-prod-staging shape) and HTTP v2
  default-with-logs. KSI-AFR-UCM added to the labeled set. (PR #203)

### Internal (count deltas)

- Detector count: 51 → 55 (+4 — see Added sections above).
- KSI-mapped detectors: 47 → 51 (+4 — all four new detectors map to
  KSIs already in the corpus, widening resource-type coverage rather
  than introducing new KSI mappings).
- KSI-MLA-LET detector cross-coverage: 3 → 5 (now spans CloudTrail,
  CloudWatch alarms, CloudTrail log-file validation, Lambda log
  groups, and APIGW stage access logs).
- Eval-harness fixtures: 4 → 5 (govnotes-v1, encryption-mixed,
  iam-dynamic-policy, runtime-monitoring, serverless-mixed).
  Encryption-mixed at rev 3 unchanged this release; serverless-mixed
  rev 2 (extended in this release).
- Test count: 1329 → 1365 (+36 — roughly 6 unit tests per new
  detector × 4 = 24, plus 12 from the M3 + retry test additions
  shipped between v0.1.43 and v0.1.44).
- Source files: 190 → 198 (+8 — 2 files per new detector × 4 = 8).

### Cross-references

- DECISIONS 2026-05-09 "Tier 2 #1 design: Lambda + API Gateway
  detector batch v0" (PR #196) — locked the Tier 2 #1 v0 scope.
- DECISIONS 2026-05-10 "Tier 2 #2 design: Lambda env-var KMS +
  APIGW access logging" (PR #200) — locked the Tier 2 #2 v0 scope.
- v0.1.43's eval-harness `--runs N` flag and gap-stage retry helper
  saved real time during the Tier 2 work — the retry helper had
  three production saves across the Tier 2 baselines (PRs #195,
  #199, #203).

### Deferred to follow-on Tier 2 entries

Three detectors flagged in PR #196's deferred-items list remain on
the backlog, each gated on its own DECISIONS entry: `lambda_vpc_isolation`
(false-positive-discipline design needed); `api_gateway_auth_required`
(REST-vs-HTTP-API model design); `api_gateway_waf_attached` (likely
deserves its own `aws.waf_*` detector family).

## [0.1.43] — 2026-05-09

**Agent-quality maturity sprint: gap/doc/remediation prompts rewritten
against the current Anthropic best-practices guide. Eval-harness M1
status_precision lifted 0.818 → 1.0 on the most-exercised fixture.
v0.2 eval-harness gains a `--runs N` flag for multi-run noise-floor
calibration; per-metric noise floor calibrated to 0.0 stddev empirically
on the post-prompt-overhaul output.**

### Changed

- `src/efterlev/agents/gap_prompt.md` — rewritten against the 2026
  Anthropic prompting best-practices guide. Wrapped sections in
  semantic XML tags, added 5 few-shot `<example>` blocks (covering
  hard status calls including manifest-self-attestation and
  comprehensive-IaC-still-partial patterns), tightened classification
  rule 2 to require zero procedural layer for `implemented`, encoded
  the policy decision that manifest evidence never reaches
  `implemented` (operator self-attestation, not independently
  verified).
- `src/efterlev/agents/documentation_prompt.md` — same XML-tag pass,
  3 worked few-shot narratives, new `<evidence_categories>` section
  requiring verbatim manifest-substring quoting (codifies what M4
  measures so the prompt and metric agree).
- `src/efterlev/agents/remediation_prompt.md` — same XML-tag pass,
  1 worked diff example, expanded anti-overengineering breakdown
  (scope / docs / defensive coding / abstractions sub-bullets),
  concrete `git apply + terraform fmt -check + terraform validate`
  bar replacing the qualitative "produce valid Terraform" guidance.
- `evals/fixtures/govnotes-v1/` rev 4 — added `aws_security_group`
  (mixed: HTTPS-only + SSH-to-internet), `aws_network_acl` (mixed:
  restrictive private subnet + wide-open public), and the full AWS
  Backup orchestration stack (`aws_backup_plan` + `_vault` +
  `_selection` covering the RDS instance). KSI-CNA-MAT/CNA-RNT/RPL-ARP
  now classify against real evidence instead of falling through to
  `evidence_layer_inapplicable`.
- `evals/fixtures/encryption-mixed/` rev 2 — added ELI alternation
  for KSI-CNA-MAT/SVC-VRI/SVC-PRR (their detector mappings target
  surfaces this S3-only fixture doesn't exercise); moved M3 expected
  resources to KSI-AFR-UCM where S3 evidence actually attaches.

### Added

- `evals/aggregate.py` + `--runs N` flag on `python -m evals run` —
  multi-run aggregator that prints per-metric mean / stddev / min /
  max and writes `aggregate.json` for cross-aggregate comparison.
  Use `--runs 3` or `--runs 5` to get above the per-metric noise
  floor when evaluating a prompt or fixture change.
- `tests/test_evals_aggregate.py` — 7 cases covering aggregation
  formula, zero-denominator skip path, per-metric/global empty input,
  formatter shape.

### Internal (count deltas)

- Test count: 1322 → 1329 (+7 from `test_evals_aggregate.py`).
- Detector count: unchanged at 51.
- KSI coverage: unchanged at 37/60.
- Source-file count: unchanged at 190.

### Cross-references

- DECISIONS 2026-05-09 "Per-metric noise-floor calibration; pipeline-
  reliability ceiling on Haiku 4.5 surfaces" — empirical noise-floor
  data underlying this release's metric claims.
- DECISIONS 2026-05-08 "v0.2 agent-quality eval harness: lock Phase 1
  scope" — the harness this release matures.
- PR #189 — the prompt-overhaul + `--runs N` PR squash-merged into
  this release.

## [0.1.42] — 2026-05-08

**Tier 1 #4.1 implementation: KSI-AFR-UCM coverage via mapping updates
on 7 existing detectors. KSI coverage rises 36/60 → 37/60.**

### Root cause

DECISIONS 2026-05-08 "Tier 1 #4.1: re-classification audit of the 24
procedural-only KSIs" identified KSI-AFR-UCM (Using Cryptographic
Modules) as a re-classification candidate. The original 2026-05-07
analysis classified UCM as procedural-only on the read that "selection
and use" is a documentation activity. Re-read: the requirement also
names the *technical artifact* (actual cryptographic modules in use),
which IS in IaC.

Implementation discovery (during this PR's work): 7 existing detectors
already evidence UCM-relevant infrastructure (KMS keys, KMS rotation,
EBS/S3/RDS encryption, CloudFront viewer protocol, LB TLS policies)
but none were mapped to KSI-AFR-UCM. The right design pivot was
**mapping updates on existing detectors**, NOT a fresh detector folder.
This is a smaller, cleaner change than the DECISIONS entry's original
scope of "1 new detector + 1 manifest template" — the manifest
template already shipped in v0.1.21 as part of the 24-template
starter pack, so the only work needed was the mapping updates.

### Changed

- **`aws.kms_customer_managed_keys`** — added `KSI-AFR-UCM` (partial).
  CMKs evidence FIPS-validated cryptographic-module use (AWS KMS HSMs
  are FIPS 140-2 Level 3 validated).
- **`aws.kms_key_rotation`** — added `KSI-AFR-UCM` (reinforces).
  Automatic rotation evidences cryptographic-key lifecycle alignment
  with UCM expectations.
- **`aws.fips_ssl_policies_on_lb_listeners`** — added `KSI-AFR-UCM`
  (partial). TLS-policy choice on LB listeners evidences the FIPS-
  aligned cipher suite layer of UCM.
- **`aws.cloudfront_viewer_protocol_https`** — added `KSI-AFR-UCM`
  (reinforces). HTTPS-only viewer protocol + TLSv1.2+ minimum on
  CloudFront distributions evidence cryptographic transport for
  federal customer data in transit.
- **`aws.encryption_ebs`**, **`aws.encryption_s3_at_rest`**,
  **`aws.rds_encryption_at_rest`** — added `KSI-AFR-UCM` (partial).
  Pre-v0.1.42 these were `ksis=[]` per DECISIONS 2026-04-21 because
  SC-28 has no direct FRMR KSI mapping in 0.9.43-beta; the v0.1.42
  re-classification audit identified the IaC angle. At-rest encryption
  evidences cryptographic-module use on the storage tier
  (FIPS-validated AWS KMS by default in commercial regions).

### Internal

- Detector count: unchanged at 51.
- Test count: 1266 (no test count change — assertion updates only).
- KSI-mapped detectors: 44 → 47. Supplementary 800-53-only: 7 → 4.
- Both the `@detector(ksis=[...])` decorator AND the in-body
  `Evidence.create(ksis_evidenced=[...])` calls were updated. This
  is the existing pattern (decorator informs the registry; in-body
  list informs each emitted Evidence record); both are needed.
- `mapping.yaml` companion files updated for human-readable
  documentation of the new KSI relationship.

### Sibling fix

- **`pip-audit` ignores CVE-2026-44405 (paramiko 4.0.0).** The
  advisory dropped between v0.1.41's CI pass and v0.1.42's CI run
  with no fix version published. paramiko is transitive via
  compliance-trestle's OSCAL/FRMR pipeline; efterlev imports no SSH
  code, so the vulnerable surface is unreachable from any agent /
  detector / scan path. `.github/workflows/ci-security.yml` now
  carries an `--ignore-vuln CVE-2026-44405` exception with the
  rationale + revisit condition documented inline. Bundled into
  this release rather than a standalone PR to save GHA minutes.

### Cross-references

- DECISIONS 2026-05-08 "Tier 1 #4.1: re-classification audit of the
  24 procedural-only KSIs" (PR #177) — the design entry that approved
  this implementation.
- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis" —
  the parent classification this audit revisited.
- DECISIONS 2026-04-21 — the original `ksis=[]` posture for the SC-28
  trio that v0.1.42 supersedes.
- v0.1.21 manifest starter pack — `KSI-AFR-UCM.template.yml` already
  shipped; no manifest work needed in this release.

### Design refinement vs DECISIONS entry

The DECISIONS entry described the implementation as "1 new detector
(`aws.afr_cryptographic_modules_fips`) + 1 new manifest template +
LIMITATIONS update + EXPECTED_DETECTORS bump 51→52." During
implementation we discovered the existing-detector overlap and
pivoted to mapping updates. Cleaner outcome: smaller diff, no new
detector folder, no EXPECTED_DETECTORS bump, manifest template
already exists. Same KSI-coverage outcome (37/60).

The original "fresh detector" scope COULD still ship later if
ACM key-algorithm checks or GovCloud region detection prove worth
adding (neither was covered by existing detectors). Deferred — this
release achieves the UCM-coverage win at low cost.

## [0.1.41] — 2026-05-08

**Bedrock probe — test-call closure (catches every AWS misalignment
class, including ones we haven't enumerated yet).**

### Root cause

The v0.1.40 deep-test re-validation (S2 finding) hit a fourth distinct
AWS-state misalignment class on top of the three v0.1.36/39/40 caught
with enumerable filters:

  1. v0.1.36: lexical sort wrong → version-tuple parse.
  2. v0.1.39: `lifecycle=LEGACY` underlying foundation models →
     skip those profiles.
  3. v0.1.40: `inferenceTypesSupported` lacks `ON_DEMAND` →
     skip those foundation-model fallback candidates.
  4. **v0.1.41 (this finding):** an inference profile pointing at a
     foundation model AWS has EOL'd. The foundation model is
     **removed entirely** from `list_foundation_models`, but the
     cross-region profile lingers as `status=ACTIVE`. AWS only
     surfaces the EOL state at Converse time as
     `ResourceNotFoundException: This model version has reached
     the end of its life.`

Each iteration we've added another filter chasing AWS's published
signals. Each shipped, then the next deep-test surfaced a new class.
Test-call is the closure: invoke a 1-token Converse ping against
each candidate before settling. Catches every Bedrock misalignment
class, present and future.

### Fixed

- **`_probe_bedrock_for_family` walks candidates in version-priority
  order, performs a 1-token Converse test-call against each, returns
  the first that accepts the call.** Cost: ~$0.0001 per ping +
  ~200ms latency. Worst case is ~5 pings if the top candidates fail.
  Best case is 1 ping.
- **Graceful degradation if `bedrock-runtime` client construction
  fails** — falls back to v0.1.40 behavior (return highest-version
  candidate untested) rather than failing init outright.
- **Catches three categories without explicit handling:**
  - EOL'd foundation models lingering as ACTIVE profiles
    (the v0.1.40 S2 finding).
  - Invalid model IDs (typos, region mismatches — would produce
    `ValidationException: The provided model identifier is invalid.`).
  - Inference-profile-only models that slip past the `ON_DEMAND`
    filter for any reason.
  - Anything AWS invents next.
- **Validation-prompt skill — fixed the Sonnet ID typo.** The runbook
  was using `us.anthropic.claude-sonnet-4-6-v1:0` (which doesn't
  exist as a real Bedrock ID) — the actual ID drops the `-v1:0`
  suffix for `4-6` and `4-7` shapes. The dated `-YYYYMMDD-v1:0`
  shape is only used for older variants. Now the skill explicitly
  notes this naming convention so future validation prompts don't
  repeat the typo.

### Added

- 4 new probe tests:
  - `test_v0_1_41_skips_eol_profile_caught_only_by_test_call` —
    A/B lock; reproduces the user's exact account state where
    Claude 3 Opus is EOL but its cross-region profile is still
    ACTIVE.
  - `test_v0_1_41_returns_none_when_no_candidate_test_call_succeeds`
    — locks the "all candidates fail → return None → init surfaces
    actionable error" path.
  - `test_v0_1_41_test_call_walks_candidates_in_version_order` —
    locks priority ordering: 4-7 fails, 4-1 next; not Claude 3 Opus.
  - `test_v0_1_41_falls_back_to_first_candidate_when_runtime_client_construction_fails`
    — graceful degradation lock for credential edge cases.
- Test mock helper `_patch_boto` extended with an `invokable: set[str] |
  None` parameter. None preserves pre-v0.1.41 default ("everything
  invokable"); explicit set lets tests pin which candidates the
  Converse mock accepts vs rejects.
- `_is_invokable(runtime_client, model_id)` helper — extracted for
  testability and clarity. Catches all exceptions; the probe only
  cares about success-vs-not, not the exception class.

### Changed

- `.claude/commands/validation-prompt.md` — naming-convention note
  for newer Bedrock IDs (`-4-6` / `-4-7` drop the `-v1:0` suffix
  vs older `-YYYYMMDD-v1:0` shape).

### Internal

- Test count: 1262 → 1266 (+4).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.
- Init takes ~200ms–1s longer when --llm-backend=bedrock is used
  without --llm-model (the test-call latency). No-op for the
  Anthropic backend or when --llm-model is passed explicitly.

### Cross-references

- v0.1.40 deep-test re-validation S2 finding (the source).
- v0.1.36/39/40 enumerable-filter additions — v0.1.41 supersedes
  the iteration cycle by closing on Converse-time validation.
- AWS Bedrock `Converse` API contract — the same call agents will
  make at runtime, so probe-time success implies agent-time success
  (modulo throughput throttling differences).

## [0.1.40] — 2026-05-08

**Bedrock probe — on-demand-callability filter (closes the v0.1.39
deep-test S2 finding); init surfaces a clear actionable error when no
usable model is auto-discoverable instead of silently writing a doomed
config.**

### Root cause

v0.1.39's lifecycle-aware probe correctly skipped LEGACY-backed
inference profiles and fell back to the highest-version `ACTIVE`
foundation model — but the gap call died with
`ValidationException: Invocation of model ID anthropic.claude-opus-4-7
with on-demand throughput isn't supported. Retry your request with the
ID or ARN of an inference profile that contains this model.` AWS's
contract is that `lifecycle=ACTIVE` does NOT imply directly invokable;
newer Anthropic Opus 4.x foundation models are inference-profile-only,
and the documented signal is the `inferenceTypesSupported` field in
`list_foundation_models` — present-and-contains-`ON_DEMAND` is the
right test, lifecycle alone is insufficient. Surfaced by the v0.1.39
deep-test re-validation against a real account (S2 finding).

### Fixed

- **Foundation-model fallback in `_probe_bedrock_for_family` now
  filters on `inferenceTypesSupported` containing `ON_DEMAND`.** ACTIVE
  foundation models that AWS publishes as inference-profile-only get
  rejected. The filter applies ONLY to the foundation-model fallback
  path, NOT to inference profiles themselves — a profile is by
  definition the right way to invoke its underlying model regardless
  of the model's own inference-types listing.
- **Defensive: missing `inferenceTypesSupported` field treated as
  not-on-demand.** Edge cases / older API responses skip rather than
  optimistically pick something that might fail at runtime.
- **Init no longer silently falls back to `DEFAULT_BEDROCK_MODEL` when
  the probe returns None.** In the user's account state that triggered
  this finding, the hardcoded default was ALSO not invokable —
  silently writing it to config produced a "succeeds at init, fails
  at agent call" footgun. v0.1.40 surfaces a clear error at init
  time with three concrete remediation options:
  1. Opt into a `us.*` cross-region inference profile in the AWS
     Bedrock Model Access page.
  2. Override with `--llm-model global.anthropic.claude-opus-4-7-v1:0`
     (with explicit FedRAMP-boundary tradeoff acknowledgment).
  3. Override with `--llm-model us.anthropic.claude-sonnet-4-6-v1:0`
     or another directly-invokable family.

  Plus a diagnostic `aws bedrock list-foundation-models …` command
  the user can paste straight into their terminal to see what their
  account actually exposes.

### Added

- 4 new probe tests:
  - `test_v0_1_40_skips_foundation_model_without_on_demand_inference_type`
    — A/B lock against the documented contract.
  - `test_v0_1_40_returns_none_when_only_inference_profile_only_models_exist`
    — reproduces the user's exact account state.
  - `test_v0_1_40_treats_missing_inference_types_field_as_no_on_demand`
    — defensive lock.
  - `test_v0_1_40_inference_profile_kept_even_when_underlying_lacks_on_demand`
    — locks that the on-demand filter doesn't accidentally reject
    inference profiles whose underlying model is profile-only (which
    is the entire point of inference profiles).
- Test mock helper `_mock_foundation_models_response` extended to
  accept 3-tuples `(model_id, lifecycle, inference_types)` while
  preserving 2-tuple back-compat (defaults to `["ON_DEMAND"]`).

### Changed

- `.claude/commands/validation-prompt.md` — added the `set -o pipefail`
  / `${PIPESTATUS[0]}` guidance per the v0.1.39 deep-test session
  surprise: a `efterlev <verb> 2>&1 | tee /tmp/log; $?` pattern
  captures `tee`'s exit code (always 0), masking real failures. First
  S2 report falsely reported PASS for this reason.

### Internal

- Test count: 1258 → 1262 (+4).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.
- The init-path change (error vs silent fallback) is technically
  user-observable but only on accounts where probe couldn't find any
  usable model anyway — those users got a doomed config + agent-time
  failure pre-v0.1.40, now they get a clear init-time error. Strict
  improvement.

### Cross-references

- v0.1.39 deep-test re-validation S2 finding (the source).
- v0.1.39 (foundation-model fallback) — v0.1.40 narrows that fallback
  to actually-callable models.
- AWS Bedrock docs on `inferenceTypesSupported` — the documented
  signal we filter on.

## [0.1.39] — 2026-05-08

**Bedrock probe — lifecycle-aware + foundation-model fallback (resolves
the v0.1.38 deep-test S4-derivative finding); init no longer refuses on
manifests-only `.efterlev/` directories (S3b).**

### Root cause for the lifecycle issue

The v0.1.38 deep-test re-validation surfaced a real account-state where
the only `us.*` Anthropic Opus inference profile in `us-east-1` was
`us.anthropic.claude-opus-4-20250514-v1:0` — whose underlying foundation
model `anthropic.claude-opus-4-20250514-v1:0` is marked `lifecycle=LEGACY`.
Init's auto-pick succeeded against the profile, but the gap-agent call
died with AccessDenied because Bedrock rejects calls to LEGACY models.
Newer Opus models (4-1, 4-5, 4-6, 4-7) ARE present in the account as
ACTIVE foundation models — but AWS hasn't yet stood up corresponding
`us.*` cross-region inference profiles in this region, so the v0.1.36
probe never saw them.

### Fixed

- **`_probe_bedrock_for_family` now consults
  `bedrock:list_foundation_models(byProvider="anthropic")`** in addition
  to `list_inference_profiles`. It builds a lifecycle map and applies
  two new rules:
  1. Skip inference profiles whose underlying foundation model has
     `lifecycle=LEGACY`. The profile itself reports `status=ACTIVE` but
     the model behind it has been deprecated, so calls fail at agent
     runtime with AccessDenied.
  2. When no usable cross-region profile remains, fall back to the
     highest-version `lifecycle=ACTIVE` foundation model directly.
     Bedrock's Converse API accepts foundation-model IDs (e.g.
     `anthropic.claude-opus-4-7`), so this is a valid call path.
- **Cross-region profile preferred over direct foundation-model
  invocation when versions tie** — encoded as an explicit secondary
  sort key, not relying on lexical accident. Cross-region routing has
  better availability characteristics.
- **Graceful degradation if `ListFoundationModels` permission is
  denied** — probe falls back to the v0.1.36 profiles-only path. Better
  than hard-failing the auto-pick.
- **S3b: `init_workspace` no longer refuses on a `.efterlev/manifests/`-
  only directory.** The canonical git pattern is to commit
  `.efterlev/manifests/` while gitignoring `.efterlev/cache/`. Pre-v0.1.39
  a fresh clone of a repo that ships Evidence Manifests forced the user
  to pass `--force` just to bootstrap. Now refusal only fires when init's
  actual outputs (`cache/`, `config.toml`, `provenance.db`) already
  exist. Surfaced by the v0.1.35 deep-test S3b finding.

### Added

- 6 new probe tests in `tests/test_bedrock_probe.py`:
  - `test_v0_1_39_skips_legacy_backed_inference_profile` — A/B lock
  - `test_v0_1_39_falls_back_to_active_foundation_model` — reproduces
    the user's actual account state and verifies the right pick
  - `test_v0_1_39_prefers_profile_over_equal_version_foundation_model`
  - `test_v0_1_39_returns_none_when_only_legacy_candidates`
  - `test_v0_1_39_continues_when_list_foundation_models_denied`
  - `test_v0_1_39_foundation_model_fallback_filters_by_family`
- 2 new workspace tests in `tests/test_workspace.py`:
  - `test_v0_1_39_init_allows_manifests_only_directory`
  - `test_v0_1_39_init_still_refuses_when_cache_present` (lock against
    accidentally loosening the destructive-overwrite safety check)
- Test mock helpers extended: `_mock_foundation_models_response` and
  `_patch_boto(foundation_models=...)` parameter so existing tests
  continue to work unchanged while new tests can exercise the
  lifecycle path.

### Internal

- Test count: 1236 → 1244 (+8).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.
- AgentError-wrapping contract for `*Client.complete()` is unchanged.
- Probe behavior is backward-compatible when the lifecycle data is
  unavailable (e.g. older boto3 / restricted IAM): old profile-only
  selection is preserved.

### Cross-references

- v0.1.36 (lexical-sort fix) — v0.1.39 builds on v0.1.36's tuple-parse
  + `us.*` filter; the new lifecycle check sits on top.
- v0.1.38 deep-test re-validation session (the finding source).
- The diagnosis was a multi-hop investigation across CWD-shadow imports
  and reporting-vs-raw-output confusion — see CLAUDE.md "Known gotchas"
  for the import-path lessons.

## [0.1.38] — 2026-05-07

**HIGH-priority UX fixes from the v0.1.35 deep-test session.** Closes
S2 (quickstart raw 401 traceback) and S1 (uv-tool symlink silently
shadows pipx → user runs `pipx upgrade` and stays on the old version).

### Fixed

- **S2: Friendly handler unwraps chained SDK errors via `__cause__`.**
  Pre-v0.1.38 the `friendly_llm_error_handler` only matched
  `isinstance(e, anthropic.APIError)` against the OUTER exception. But
  `AnthropicClient.complete()` (and `AnthropicBedrockClient.complete()`)
  wrap non-retryable SDK errors as `AgentError(...)` for caller-uniform
  error typing — so by the time the handler ran, `e` was an
  `AgentError`, not an `APIError`, and the friendly path was bypassed.
  Result: a set-but-invalid `ANTHROPIC_API_KEY` gave the user a 600-line
  raw 401 traceback mid-quickstart (the exact thing this layer was
  built to prevent). v0.1.38 walks the `__cause__` chain looking for an
  `anthropic.APIError`; if found, the friendly message + hint surface
  as designed. Cycle-safe (tracked via `seen` set on `id()`).
- **S1: `efterlev --version` warns on parallel installs.** When the
  user has both pipx and uv-tool venvs of efterlev, only one of them
  owns the `~/.local/bin/efterlev` symlink — so the OTHER manager's
  `upgrade` command silently leaves the user on the older install.
  The deep-test tester hit this exactly: `pipx upgrade` to v0.1.35
  succeeded, but PATH still routed to v0.1.15 (uv-tool's symlink won
  the race). Pre-v0.1.38 this was only surfaced via `efterlev doctor`
  (which the tester didn't run before tripping over it). v0.1.38 prints
  the warning to stderr on every `--version` invocation so the user
  notices BEFORE running into mysterious old-version behavior. Single-
  install hosts get no warning (no false-positive noise).

### Added

- 5 new tests:
  - `test_v0_1_38_handler_unwraps_chained_sdk_error_via_cause` — A/B-style
    lock that fails the suite if the handler stops walking `__cause__`.
  - `test_v0_1_38_handler_unwraps_deeply_chained_sdk_error` — multi-level
    nesting (AgentError → AgentError → APIError).
  - `test_v0_1_38_handler_does_not_loop_on_self_referential_cause` —
    cycle-safety lock.
  - `test_v0_1_38_version_flag_warns_on_parallel_installs` — locks the
    shadow warning fires on the 2-manager case.
  - `test_v0_1_38_version_flag_silent_when_one_install` — locks no false
    positive on single-install hosts.

### Internal

- Test count: 1231 → 1236 (+5).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.
- AgentError-wrapping contract for `*Client.complete()` is unchanged —
  callers that catch `AgentError` keep working. Only the friendly handler
  was changed (additive: it ALSO catches anthropic.APIError when found
  via `__cause__`).

### Cross-references

- v0.1.35 deep-test session report (S1 + S2 findings).
- v0.1.37 (Bedrock silent-wedge fix, also from the same session report).
- S3b (init refuses on pre-existing manifests) and S4b (Opus 4.7 not in
  pricing registry) deferred — S3b needs scope decision (init UX is more
  involved than a one-line fix); S4b needs the actual runtime model_id
  the tester used (the static keys ARE in the registry; the runtime
  lookup must be a different ID shape).

## [0.1.37] — 2026-05-07

**CRITICAL: Bedrock silent-wedge fix.** Surfaced by the v0.1.35 deep-test
session — `efterlev report run` against a Bedrock backend hung 24 minutes
at 0% CPU on a `ReadTimeoutError` mid-retry. Only SIGINT broke it. This
release fixes the wedge and adds visible progress so the failure mode is
no longer silent.

### Root cause

The pre-v0.1.37 retry loop had three reinforcing problems that compounded
into the wedge:

1. **`ReadTimeoutError` consumed the full retry budget** (`_MAX_RETRIES=3`)
   despite each ReadTimeout burning ~600s of `read_timeout` wall time.
   Worst case: 3 × 600s = 30 min of stalled reads on a single agent call.
2. **No total wall-clock cap** on the retry+fallback sequence, so multiple
   ReadTimeouts could compound to 30+ min silently.
3. **Progress messages emitted only via `log.warning`** — invisible to
   the user when the project doesn't configure logging (it doesn't).

### Fixed

- **`_MAX_READ_TIMEOUT_RETRIES = 1`** — ReadTimeoutError now caps at
  1 retry (~20 min worst case for the ReadTimeout path; 1 retry rarely
  recovers a stuck connection but burns another 600s). Other retryable
  errors (Throttling, 5xx, ConnectTimeout) keep the full
  `_MAX_RETRIES=3` budget.
- **`_MAX_TOTAL_WALL_SECONDS = 1200`** — hard 20-min wall-clock ceiling
  on the entire `complete()` call sequence. Pre-flight check at each
  retry iteration; aborts with a clear `AgentError` when the deadline
  is exceeded.
- **`_emit_progress(message)`** — writes `[bedrock] …` lines directly
  to stderr with explicit flush, so the user sees retry attempts +
  wall-clock budget consumption + abort decisions even when logging
  is unconfigured.
- **`_is_read_timeout(error)`** — new classifier helper (alongside the
  existing `_is_retryable_bedrock`) so callers can apply distinct retry
  budgets per error class.
- The bottom-of-`complete()` `assert last_error is not None` is replaced
  with an explicit `AgentError` for the wall-clock-exhausted-at-entry
  case (where no converse call ever ran).

### Added

- 5 new tests in `tests/test_bedrock_client.py`:
  - `test_v0_1_37_read_timeout_capped_at_one_retry` — A/B-style lock
    that fails the suite if a future edit lets ReadTimeout consume the
    full retry budget.
  - `test_v0_1_37_progress_messages_visible_on_retry` — verifies
    stderr `[bedrock]` lines appear on retry.
  - `test_v0_1_37_wall_clock_budget_caps_total_time` — uses
    `monkeypatch.setattr(time, "monotonic", …)` to simulate a clock
    jump past the 1200s deadline; verifies the loop bails with no
    further converse calls.
  - `test_v0_1_37_is_read_timeout_classifier` — pins the
    ReadTimeoutError vs other-retryable distinction.
  - `test_v0_1_37_non_read_timeout_uses_full_retry_budget` — locks
    that the ReadTimeout cap is targeted, not a global retry-budget
    reduction.

### Internal

- Test count: 1226 → 1231 (+5).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.

### Cross-references

- v0.1.35 deep-test session report (S4a finding): the credibility-killer
  "give it to a compliance team unattended" failure mode this fixes.
- CLAUDE.md "Known gotchas" — Bedrock client retry behavior section.
  Pre-v0.1.37 the `read_timeout=600` + `retries={"max_attempts": 1}`
  config was correct, but the OUR retry loop on top of it was the
  amplifier. v0.1.37 keeps the boto config; tightens the OUR loop.

## [0.1.36] — 2026-05-07

**Bedrock inference-profile probe correctness fix** — surfaced by a real
fresh-install test session against an account with both Opus 4.0 and
Opus 4.1 enabled. v0.1.0–v0.1.35 picked Opus 4.0 (older) over Opus 4.1
(newer) at `efterlev init`, because the lexical sort treats
`claude-opus-4-20250514` as outranking `claude-opus-4-1-20250805`
(at position 14, `2` > `1`). Plus the probe didn't filter by region
prefix at all — meaning it could pick `eu.*` / `apac.*` / `global.*`
profiles over US ones in some accounts.

### Fixed

- **Version-aware sort.** The probe now parses
  `(major, minor, date_int, rev)` tuples from each candidate
  inference-profile ID and ranks by tuple compare. Both modern
  (`claude-opus-4-7-v1:0`, `claude-opus-4-1-20250805-v1:0`) and legacy
  (`claude-3-opus-…`, `claude-3-5-sonnet-…`, `claude-3-7-sonnet-…`)
  shapes parse correctly. The negative-lookahead `(?=-|$)` on the
  minor-version capture prevents the regex from greedy-matching the
  first 1–2 digits of an 8-digit date as `minor`.
- **`us.*` cross-region prefix filter.** The probe now excludes
  `eu.*` / `apac.*` / `global.*` inference profiles. Rationale: FedRAMP-
  bound deployments shouldn't egress federal customer data outside
  the US authorization boundary; `global.*` specifically forfeits the
  US-region geographic guarantee some FedRAMP boundary documentation
  depends on. Users who explicitly want a non-US profile can pass
  `--llm-model=<arn>` to override.
- **Belt-and-suspenders Anthropic check.** Where the inference-profile
  response includes the underlying model ARNs, the probe now confirms
  at least one is from Anthropic. Some accounts have third-party
  profiles whose IDs collide with Anthropic family names.

### Added

- `_probe_bedrock_for_family(region, family)` — a generic helper
  supporting `opus`, `sonnet`, and `haiku` families. Today only Opus
  is wired to the init probe; the helper is ready for the Tier 2
  per-agent Bedrock-default candidate (each agent picks its own
  US cross-region profile at runtime).
- `_parse_bedrock_anthropic_version` — parses a sortable version
  tuple from a Bedrock inference-profile ID. Handles 11+ shapes of
  Anthropic-on-Bedrock IDs in production today.
- `tests/test_bedrock_probe.py` — 24 tests covering parser correctness
  on every shipped Anthropic-on-Bedrock ID shape, ranking sanity (e.g.
  Opus 4.7 > 4.1 > 4.0 > 3), the v0.1.36 failure-mode lock (an
  account with both Opus 4.0 and 4.1 must pick 4.1), and the
  `us.*`-filter (eu/apac/global excluded).

### Internal

- Test count: 1202 → 1226 (+24).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.

### Cross-references

- CLAUDE.md "Known gotchas" — updated Bedrock-probe entry now
  documents the `us.*` filter + version-aware sort.
- The hardcoded `DEFAULT_BEDROCK_MODEL` fallback
  (`us.anthropic.claude-opus-4-7-v1:0`) is unchanged; the probe
  remains a best-effort discovery layer that picks whatever the
  user's account actually has access to right now.

## [0.1.35] — 2026-05-07

**Tier 1 follow-up: 2 manifest templates close the v0.1.34 design's
projected outcome.** Per DECISIONS 2026-05-07 "Tier 1 #4 design"
the gap analysis classified 24 KSIs `procedural-only`; 22 already
had v0.1.21 starter-pack templates, but 2 were missing
(`KSI-MLA-RVL` log review + `KSI-SVC-EIS` security improvement
program). This release adds those two templates, expanding the
starter pack from 24 → 26.

### Added

- **2 hand-authored templates** in `src/efterlev/manifest_templates/`:
  - `KSI-MLA-RVL.template.yml` — log review cadence, named
    reviewer / rotation, evidence-of-review artifacts, escalation
    rubric.
  - `KSI-SVC-EIS.template.yml` — security improvement program:
    evaluation surfaces, triage cadence, severity-based SLAs,
    metrics, program ownership.

  Each carries a hand-authored `_template_help` block with
  description + 5–6 questions + DRAFT example_statement matching
  the v0.1.21 starter-pack pattern. Generated by re-running
  `scripts/generate_starter_pack.py` after appending the two
  KSI entries to its `KSI_HELP` dict (the source of truth).

- `SELECTION.md` regenerated to document the 2 new entries
  alongside the original 24.

### Changed

- `tests/test_manifest_starter_pack.py`:
  - `test_starter_pack_has_24_templates` → renamed
    `test_starter_pack_has_26_templates`; assertion bumped to 26.
  - CLI-integration test stderr-message + count assertions
    bumped 24 → 26.
- `src/efterlev/cli/main.py`: `--starter-pack` help text
  "(24 KSIs covering ...)" → "(26 KSIs covering ...)".

### Internal

- Test count: 1202 → 1202 (no test-count delta — existing
  manifest tests just have updated expectations).
- Detector count: unchanged at 51.
- Source files: unchanged at 190.
- Manifest templates: 24 → 26.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — the design entry that promised these 2 templates as
  follow-ups. **With v0.1.35 the design entry's projected
  outcome is fully delivered.**
- DECISIONS 2026-05-06 "Tier 1 #3 design: Evidence Manifest
  starter pack" — the parent design that established the
  generator pattern + `_template_help` shape these new templates
  follow.

### Tier 1 fully complete after this release

- ~~#1 quickstart~~ (v0.1.18)
- ~~#2a cost summary~~ (v0.1.19)
- ~~#2b --dry-run / --dump-prompt~~ (v0.1.20)
- ~~#3 manifest starter pack~~ (v0.1.21, expanded v0.1.35)
- ~~#4 detector gap analysis~~ (v0.1.28–v0.1.34, manifest
  follow-ups v0.1.35)

Next: Tier 2 candidates per `CLAUDE.md` "Path forward" — each
gets its own DECISIONS entry when promoted.

## [0.1.34] — 2026-05-07

**Tier 1 #4 detector backlog complete (6/6).** Final detector ships
KSI-PIY-RSD "Reviewing Security in the SDLC" — the GitHub-workflow-
based SDLC security gates detector.

### Added

- **`github.piy_sdlc_security_gates` detector.** Reads
  `.github/workflows/*.yml` for the canonical SDLC security-gate
  patterns:
  - **CodeQL:** `uses: github/codeql-action/(init|analyze|autobuild)@...`
  - **Dependency review:** `uses: actions/dependency-review-action@...`
  - **Secret scanning:** TruffleHog or Gitleaks action

  Emits per-workflow Evidence: `gate_state="configured"` with
  `gates_present=[...]` listing which subset is found, or
  `gate_state="absent"` with a gap message.

  Maps to KSI-PIY-RSD + SA-3 (System Development Life Cycle) +
  SA-8 (Security and Privacy Engineering Principles). KSI-PIY-RSD
  classified `partial`; this detector covers the configured-gate
  half (the procedural review cadence is manifest territory).

- 6 fixtures (4 should_match including a combined-gates fixture +
  2 should_not_match) + 9 unit tests covering each gate, the
  combined-gates path, the absent path, and contract pins
  (mappings, source category, state lock, gate-label allowlist).

### Changed

- `tests/test_cli.py` expected count: 50 → 51, KSI-mapped: 43 → 44.
- `scripts/triage.sh` `EXPECTED_DETECTORS`: 50 → 51. The v0.1.29
  source-level pin caught the drift at PR time (fifth release in
  a row — the lock has now caught EVERY detector PR).

### Internal

- Test count: 1193 → 1202 (+9). Detector count: 50 → 51.
  Source files: 188 → 190. KSI-mapped: 43 → 44.
  KSIs covered: 35 → 36.

### Tier 1 #4 backlog summary

All 6 detectors from DECISIONS 2026-05-07 "Tier 1 #4 design"
shipped:

1. v0.1.28 — `aws.cna_optimizing_for_availability` → KSI-CNA-OFA
2. v0.1.30 — `aws.mla_log_access_least_privilege` → KSI-MLA-ALA
3. v0.1.31 — `aws.cna_dos_protection` → KSI-CNA-RVP
4. v0.1.32 — `aws.svc_at_rest_encryption_coverage` → KSI-SVC-PRR
5. v0.1.33 — `aws.rpl_backup_configured` → KSI-RPL-ARP
6. **v0.1.34** (this) — `github.piy_sdlc_security_gates` → KSI-PIY-RSD

Coverage moved from 30/60 KSIs at the design entry to 36/60 — exactly
matching the design's projected outcome. Per the design entry, 2
manifest templates (`KSI-MLA-RVL`, `KSI-SVC-EIS`) are still pending
when convenient.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — design entry; this is item #6 of 6 (FINAL).
- Tier 1 of the v0.1.18+ originally-planned UX sequence is now
  fully complete (#1 quickstart, #2a cost summary, #2b --dry-run,
  #3 starter pack, #4 detector gap analysis).

## [0.1.33] — 2026-05-07

Tier 1 #4 detector backlog item #5 of 6. Per DECISIONS 2026-05-07
"Tier 1 #4 design", ships KSI-RPL-ARP "Aligning Recovery Plan" —
AWS Backup orchestration + cross-region replication.

### Added

- **`aws.rpl_backup_configured` detector.** Reads Terraform for
  recovery-plan orchestration primitives:
  - `aws_backup_plan` — counts rules + cross-region copy_actions.
  - `aws_backup_vault` — emits `cmk=true` when `kms_key_arn` set.
  - `aws_backup_selection` — backup-coverage signal.
  - `aws_db_instance_automated_backups_replication` — RDS
    automated-backups cross-region replication.

  Distinct from `aws.backup_retention_configured` (KSI-RPL-ABO,
  CP-9, RDS retention + S3 versioning); this detector covers the
  orchestration + alternate-site half. Test
  `test_detector_does_not_overlap_with_backup_retention_configured`
  pins the no-overlap contract by running both detectors against
  the same fixture.

- 5 fixtures (4 should_match, 1 should_not_match) + 9 unit tests
  covering each pattern, the no-overlap pin, positive-only
  state lock, and contract pins.

### Changed

- `tests/test_cli.py` expected count: 49 → 50, KSI-mapped: 42 → 43.
- `scripts/triage.sh` `EXPECTED_DETECTORS`: 49 → 50. The v0.1.29
  source-level pin caught the drift at PR time (fourth release
  in a row).

### Internal

- Test count: 1184 → 1193 (+9). Detector count: 49 → 50.
  Source files: 186 → 188. KSI-mapped: 42 → 43.
  KSIs covered: 34 → 35.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — design entry; this is item #5 of 6.
- 1 detector remaining on the backlog: `github.piy_sdlc_security_gates`.

## [0.1.32] — 2026-05-07

Tier 1 #4 detector backlog item #4 of 6. Per DECISIONS 2026-05-07
"Tier 1 #4 design", ships KSI-SVC-PRR "Preventing Residual Risk" —
encryption-at-rest coverage on data stores not covered by the
existing per-service detectors.

### Added

- **`aws.svc_at_rest_encryption_coverage` detector.** Reads
  Terraform for at-rest encryption configuration on the data
  stores not in the existing detector inventory:
  - `aws_dynamodb_table` — `server_side_encryption.enabled`
    (AWS default is on; explicit-false is the negative case).
  - `aws_efs_file_system` — `encrypted`
  - `aws_elasticache_cluster` — `at_rest_encryption_enabled`
  - `aws_elasticache_replication_group` — same flag
  - `aws_rds_cluster` (Aurora) — `storage_encrypted`
  - `aws_neptune_cluster` — `storage_encrypted`
  - `aws_docdb_cluster` (DocumentDB) — `storage_encrypted`

  Emits positive (`configured`, with `cmk=true` detail when a
  customer-managed KMS key is referenced) or negative (`absent`
  with a gap message) per resource.

- 7 fixtures (4 should_match, 3 should_not_match) + 9 unit tests
  covering each resource type, both encryption states, the no-
  resource path, and contract pins.

### Changed

- `tests/test_cli.py` expected count: 48 → 49, KSI-mapped: 41 → 42.
- `scripts/triage.sh` `EXPECTED_DETECTORS`: 48 → 49. The v0.1.29
  source-level pin caught the drift at PR time (third release
  in a row).

### Internal

- Test count: 1175 → 1184 (+9). Detector count: 48 → 49.
  Source files: 184 → 186. KSI-mapped: 41 → 42.
  KSIs covered: 33 → 34.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — design entry; this is item #4 of 6.
- 2 detectors remain on the backlog: `rpl_backup_configured`,
  `github.piy_sdlc_security_gates`.

## [0.1.31] — 2026-05-07

Tier 1 #4 detector backlog item #3 of 6. Per DECISIONS 2026-05-07
"Tier 1 #4 design: detector gap analysis", ships KSI-CNA-RVP
"Reviewing Protections" — DoS-protection inventory.

### Added

- **`aws.cna_dos_protection` detector.** Reads Terraform for the
  IaC-declared DoS-protection primitives:
  - `aws_wafv2_web_acl` — modern WAF web ACL; counts rate-based
    statements in nested rule blocks.
  - `aws_wafv2_web_acl_association` — WAF attached to ALB /
    CloudFront / API Gateway (resource_arn target preserved).
  - `aws_waf_web_acl` — classic (v1) WAF, flagged distinctly so
    downstream agents can note the deprecated surface.
  - `aws_shield_protection` — Shield Advanced subscription.

  Only positive (configured) evidence is emitted — KSI-CNA-RVP is
  classified `partial`, where this detector covers the
  configured-state half and the procedural review cadence
  ("persistently review the effectiveness") is manifest territory.
  Absence of WAF/Shield isn't a gap per se; the Gap Agent reasons
  about exposure-justified gaps.

- 5 fixtures (4 should_match, 1 should_not_match) + 8 unit tests
  covering each pattern, the no-evidence case, and contract pins
  (mappings, evidence schema, positive-only state lock).

### Changed

- `tests/test_cli.py` expected count: 47 → 48, KSI-mapped: 40 → 41.
- `scripts/triage.sh` `EXPECTED_DETECTORS`: 47 → 48. The v0.1.29
  source-level pin caught the drift at PR time.

### Internal

- Test count: 1167 → 1175 (+8). Detector count: 47 → 48.
  Source files: 182 → 184. KSI-mapped: 40 → 41.
  KSIs covered: 32 → 33.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — design entry; this is item #3 of 6.
- 3 detectors remain on the Tier 1 #4 backlog:
  `svc_at_rest_encryption_coverage`, `rpl_backup_configured`,
  `github.piy_sdlc_security_gates`.

## [0.1.30] — 2026-05-07

Tier 1 #4 detector backlog item #2 of 6. Per DECISIONS 2026-05-07
"Tier 1 #4 design: detector gap analysis", ships the second
`evidenceable-via-iac` detector: KSI-MLA-ALA "Authorizing Log
Access" — least-privilege patterns on log data.

### Added

- **`aws.mla_log_access_least_privilege` detector.** Reads
  Terraform for two surfaces of log-data access control:
  - `aws_cloudwatch_log_resource_policy` — explicit log-group
    resource policies (positive: an admin has governed access).
  - IAM policies (`aws_iam_policy` + `aws_iam_role_policy` +
    `aws_iam_user_policy` + `aws_iam_group_policy`) with `logs:`
    actions: classified `scoped` (specific log group ARN) or
    `overly_permissive` (wildcard `logs:*` on `Resource: "*"`).
  - Resolves both literal-JSON policies AND
    `${data.aws_iam_policy_document.NAME.json}` references through
    the data-source registry (same pattern as
    `aws.mfa_required_on_iam_policies`).

- 6 fixtures (3 should_match, 3 should_not_match) + 9 unit tests
  covering the configured / scoped / overly_permissive paths,
  literal-JSON + data-source-reference resolution, the no-evidence
  case for IAM policies that don't touch log data, and contract
  pins (mappings, evidence schema, pattern enum).

### Changed

- `tests/test_cli.py::test_detectors_list_lists_all_thirty_detectors`
  expected count: 46 → 47, KSI-mapped: 39 → 40.
- `scripts/triage.sh` `EXPECTED_DETECTORS`: 46 → 47. The
  v0.1.29 source-level pin
  (`tests/test_triage_constant_alignment.py`) caught this drift
  at PR time — the new lock is doing its job.

### Internal

- Test count: 1158 → 1167 (+9). Detector count: 46 → 47.
  Source files: 180 → 182. KSI-mapped detectors: 39 → 40.
  KSIs covered by detectors: 31 → 32.

### Known duplication (will refactor when 3rd IAM-policy
content detector lands)

The IAM-policy-document parsing (literal JSON + data-source
reference resolution) is now duplicated between
`aws.mfa_required_on_iam_policies` and
`aws.mla_log_access_least_privilege`. Refactor candidate:
`efterlev.iam.policy_doc` shared helper. Looking at the Tier 1
#4 backlog, neither `cna_dos_protection` nor
`svc_at_rest_encryption_coverage` nor `rpl_backup_configured`
nor `github.piy_sdlc_security_gates` need IAM-policy-content
parsing — so the duplication ends here. If a future detector
needs this, refactor at that PR.

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — the design entry; this is item #2 of 6.
- 4 detectors remain on the Tier 1 #4 backlog: `cna_dos_protection`,
  `svc_at_rest_encryption_coverage`, `rpl_backup_configured`,
  `github.piy_sdlc_security_gates`.

## [0.1.29] — 2026-05-07

Hotfix for v0.1.28's auto-triage T3 FAIL. v0.1.28 added detector
#46 (`aws.cna_optimizing_for_availability`) but missed bumping
`EXPECTED_DETECTORS=45 → 46` in `scripts/triage.sh`. Auto-triage
ran against the published v0.1.28 wheel, found 46 detectors,
expected 45, and reported T3 FAIL on the v0.1.28 release page.

Fix is mechanical (one number); the structural lock makes the
mistake un-recurrable.

### Fixed

- `scripts/triage.sh`: `EXPECTED_DETECTORS=45 → 46`. Comment
  updated to reference the new test that locks this against
  drift.

### Added

- `tests/test_triage_constant_alignment.py`: scans
  `scripts/triage.sh` for the `EXPECTED_DETECTORS=N` line and
  asserts N equals `len(get_registry())`. **Future detector
  PRs that forget to bump the constant fail the suite at
  PR review** — no Windows runner needed, no release needed.
  Same source-level pin pattern as the v0.1.23-v0.1.27 cascade
  fixes.

### Internal

- Test count: 1157 → 1158 (+1).
- Detector count unchanged at 46.

### Cross-references

- v0.1.28's release page T3 FAIL: <https://github.com/efterlev/efterlev/releases/tag/v0.1.28>
- DECISIONS 2026-05-07 "Process improvements from v0.1.22-v0.1.27 cascade" — same source-level-pin pattern that drove this lock.

## [0.1.28] — 2026-05-07

Tier 1 #4 detector backlog item #1 of 6. Per DECISIONS 2026-05-07
"Tier 1 #4 design: detector gap analysis", ships the first
`evidenceable-via-iac` detector from the gap analysis: KSI-CNA-OFA
"Optimizing for Availability."

### Added

- **`aws.cna_optimizing_for_availability` detector.** Reads
  Terraform for the common availability primitives that contribute
  to KSI-CNA-OFA's "high availability and rapid recovery" outcome:
  - `aws_db_instance` with `multi_az = true` (positive) or read-
    replica via `replicate_source_db` (positive); else negative.
  - `aws_rds_cluster` with explicit `availability_zones` (≥2) or
    `global_cluster_identifier`.
  - `aws_autoscaling_group` with ≥2 subnets in
    `vpc_zone_identifier` (positive) or 1 subnet (negative).
  - `aws_s3_bucket_replication_configuration` (positive).
  - `aws_ecs_service` with `placement_constraints.type = "spread"`
    on `availability-zone`.

- 9 fixtures (6 should_match, 3 should_not_match) + 11 unit tests
  covering each pattern, the negative-evidence paths, and contract
  pins (`controls=[]` declared explicitly; `availability_state ∈
  {configured, absent}` schema lock).

### Changed

- **`@detector` decorator: relaxed `controls` non-empty
  requirement.** Pre-v0.1.28 the decorator required at least one
  800-53 control, which forbade detectors for KSIs FRMR doesn't map
  to any 800-53 control (KSI-CNA-OFA's `controls` field is `[]` in
  FRMR 0.9.43-beta). New rule: at least one of `ksis` OR `controls`
  must be non-empty (the detector must evidence SOMETHING). The
  symmetric inverse case (`ksis=[]` with non-empty `controls`)
  was already permitted per DECISIONS 2026-04-21 (e.g. SC-28 has no
  KSI mapping in FRMR). Tests in `test_detector_contract.py`
  updated to lock both directions.

### Internal

- Test count: 1145 → 1157 (+12). Detector count: 45 → 46. Source
  files: 178 → 180. KSI-mapped detectors: 38 → 39. KSIs covered
  by detectors: 30 → 31 (closing the gap surfaced in DECISIONS
  2026-05-07 doc-drift note).

### Cross-references

- DECISIONS 2026-05-07 "Tier 1 #4 design: detector gap analysis"
  — full classification of the 30 uncovered KSIs and the 6-detector
  backlog this is item #1 of.
- 5 detectors remain on the Tier 1 #4 backlog: `mla_log_access_least_privilege`
  (#2), `cna_dos_protection` (#3), `svc_at_rest_encryption_coverage`
  (#4), `rpl_backup_configured` (#5), `github.piy_sdlc_security_gates`
  (#6). Each lands as its own PR per the working agreement.

## [0.1.27] — 2026-05-07

Sixth Windows-cascade layer. v0.1.26's first release-smoke run on
Windows-2022 hit `UnicodeEncodeError: 'charmap' codec can't encode
character '⚠' in position 2`. Root cause: Windows console
default encoding is cp1252; cp1252 can't encode U+26A0 (WARNING
SIGN ⚠) which `efterlev scan` uses in 4 user-facing scan-result
warning lines. Any `efterlev scan` invocation that triggers a
warning path crashed on Windows with this error.

### Fixed

- `src/efterlev/cli/main.py`:
  - At CLI import time, on Windows, reconfigure `sys.stdout` and
    `sys.stderr` to UTF-8. POSIX is unaffected (default already
    utf-8). Uses `TextIOWrapper.reconfigure(encoding="utf-8")`
    (Python 3.7+); `hasattr` guard handles redirected stdio in
    subprocess capture cases.
  - In-file comment block explains the bug + fix shape.

### Added

- `tests/test_cli_windows_stdio.py` (2 tests):
  - `test_cli_main_reconfigures_stdio_to_utf8_on_windows` —
    source-level pin (platform-independent). Asserts
    `if sys.platform == "win32":` block + both
    `sys.stdout.reconfigure(encoding="utf-8")` and
    `sys.stderr.reconfigure(encoding="utf-8")` calls are present.
  - `test_warning_emoji_present_in_cli_output_paths` — sanity
    check that the U+26A0 character is still used; documents
    the use case for the reconfigure block.

### Internal

- Test count: 1143 → 1145 (+2).
- Source files unchanged at 178; detector count unchanged at 45.

### Cumulative cascade context (v0.1.22 → v0.1.27)

- v0.1.22: assertion script (matrix could finally measure)
- v0.1.23: Windows fcntl + docker-ghcr `?mode=ro`
- v0.1.24: WAL-mode for docker-ghcr (`&immutable=1`)
- v0.1.25: Windows charmap encoding (FRMR loader read)
- v0.1.26: Windows msvcrt.locking O_APPEND byte-range
- v0.1.27 (this): Windows charmap encoding (CLI stdout/stderr write)

The v0.1.25 fix handled READING UTF-8 from files; v0.1.27
handles WRITING UTF-8 to console. Two distinct categories of
encoding bug, both surfaced as the matrix progressed past
prior layers.

### Cross-references

- v0.1.26's Windows-2022 cell failure log:
  <https://github.com/efterlev/efterlev/actions/runs/25498326520/job/74824004090>
  — exact UnicodeEncodeError trace.
- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  v0.1.27 Windows stdio utf-8 follow-on" — root cause +
  cascade summary.

## [0.1.26] — 2026-05-07

Windows `msvcrt.locking` byte-range bug. v0.1.25's first
release-smoke run on Windows-2022 hit
`PermissionError: [Errno 13]` from `_flock_release(fd)` at
`receipts.py:116`. Root cause: `msvcrt.locking()` is BYTE-RANGE
based (unlike POSIX `fcntl.flock` which locks the whole file).
The `O_APPEND` open mode advances the file position after each
write, so by the time the unlock call runs, the position is at
NEW_EOF and the unlock targets a different byte range than the
original lock — `msvcrt.locking` raises PermissionError.

### Fixed

- `src/efterlev/provenance/receipts.py`:
  - `_flock_exclusive` and `_flock_release` (Windows branch) now
    `os.lseek(fd, 0, os.SEEK_SET)` before each `msvcrt.locking`
    call. Both lock and unlock target byte range `[0, 1)`. With
    `O_APPEND` set on the fd, actual writes still go to EOF
    regardless of file position; the byte-0 lock is purely
    advisory and no real data ever gets written at byte 0.
  - In-file comment block explains the bug + fix shape.

### Added

- `tests/test_receipts_locking.py::test_windows_lock_helpers_lseek_to_byte_zero_before_lock_and_unlock`
  — source-level pin (platform-independent): reads `receipts.py`,
  finds the Windows branch, asserts both helpers `lseek(fd, 0)`
  before their `msvcrt.locking` call. A regression that drops
  either lseek would re-break Windows; this test catches it
  on macOS / Linux dev laptops, no Windows runner needed.
  A/B-verified before commit: removing either lseek line fails
  this test immediately.

### Internal

- Test count: 1142 → 1143 (+1).
- Source files unchanged at 178; detector count unchanged at 45.

### Cumulative cascade context (v0.1.22 → v0.1.26)

The silent-matrix gap had been masking a *cascade* of platform-
specific bugs that surfaced one-by-one as each prior bug was
fixed. v0.1.26 closes the fifth and (we believe) last layer:

- v0.1.22: assertion script (couldn't measure anything)
- v0.1.23: Windows `import fcntl` (import-time crash) +
  docker-ghcr `?mode=ro` (sqlite default mode)
- v0.1.24: WAL-mode case for docker-ghcr
  (`?mode=ro&immutable=1`)
- v0.1.25: Windows charmap encoding in FRMR loader
- v0.1.26 (this): Windows `msvcrt.locking` O_APPEND byte-range
  semantics

Each layer was hidden by the prior one because Windows / docker-
ghcr cells crashed early. With v0.1.26, the cascade should be
exhausted and v0.1.26's release-smoke matrix should land fully
green for the first time since the silent-matrix was opened.

### Cross-references

- v0.1.25's Windows-2022 cell failure log:
  <https://github.com/efterlev/efterlev/actions/runs/25496572508/job/74817835258>
  — exact PermissionError trace.
- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  v0.1.26 Windows msvcrt.locking follow-on" — root-cause +
  cumulative cascade summary.

## [0.1.25] — 2026-05-07

Windows `UnicodeDecodeError` in the FRMR loader. v0.1.24's first
release-smoke run on Windows-2022 hit
`UnicodeDecodeError: 'charmap' codec can't decode byte 0x9d in
position 214643` because `Path.open()` defaults to the OS-default
encoding (cp1252 on Windows) and the FRMR catalog contains UTF-8
sequences (en-dashes, smart quotes, em-dashes in requirement
text). The bug was latent on every Windows install since the FRMR
catalog grew non-ASCII content but was masked by the prior
`import fcntl` ImportError (v0.1.23 fix) which crashed Windows at
import time before runtime could reach the loader.

### Fixed

- `src/efterlev/frmr/loader.py`:
  - Both `path.open()` calls (catalog + schema) now pass
    `encoding="utf-8"` explicitly. In-file comment block explains
    why the OS-default fallback isn't safe.

### Added

- `tests/test_frmr_loader.py::test_loader_passes_explicit_utf8_encoding`
  — synthesizes a minimal catalog with non-ASCII chars (en-dash,
  smart quote, em-dash matching the vendored content shape) and
  loads it. Behavioral lock against accidental reversion of the
  encoding parameter on POSIX (where the test would still pass
  by platform default but would fail on Windows in CI).
- `tests/test_frmr_loader.py::test_loader_source_explicitly_passes_utf8_to_open`
  — source-level pin: reads `frmr/loader.py` and asserts both
  `path.open(encoding="utf-8")` and `schema_path.open(encoding="utf-8")`
  are present. Fails the suite immediately if a future edit drops
  `encoding=` from either call.
- `tests/test_frmr_loader.py::test_vendored_frmr_loads_with_expected_shape`
  — extracted from the original
  `test_loads_vendored_frmr_without_schema` so the new
  encoding-tests can sit between smoke-load and shape-assertions
  without disturbing them.

### Internal

- Test count: 1139 → 1142 (+3 in `test_frmr_loader.py`).
- Source files unchanged at 178; detector count unchanged at 45.

### Cross-references

- v0.1.24's Windows-2022 cell failure log:
  <https://github.com/efterlev/efterlev/actions/runs/25495339151/job/74813517916>
  — exact `UnicodeDecodeError` trace.
- DECISIONS 2026-05-07 "release-smoke matrix visibility: v0.1.25
  Windows utf-8 follow-on" — root cause + lessons learned about
  the cascade of Windows bugs the silent-matrix had been masking.

## [0.1.24] — 2026-05-07

The actual fix for the docker-ghcr readonly-DB matrix cell.
v0.1.23 changed `tests/smoke/assert.py` to open the SQLite store
with `?mode=ro` — but that's not enough when the store is in WAL
mode (the prod schema enables WAL via
`PRAGMA journal_mode=WAL` at `src/efterlev/provenance/store.py:87`).
Even with `?mode=ro`, SQLite tries to open a journal file in the
DB's directory during a SELECT to handle hot-journal recovery; if
the directory is read-only (matches docker-ghcr's root-owned
mounted volume), this fails with "attempt to write a readonly
database". Caught by v0.1.23's own first release-smoke run on
docker-ghcr cells.

`&immutable=1` tells SQLite the DB is on read-only media and
skips ALL write-path operations including journal opens. v0.1.24
adds it; the docker-ghcr cells should now pass.

### Fixed

- `tests/smoke/assert.py` — open the store via
  `sqlite3.connect(f"file:{db_path}?mode=ro&immutable=1", uri=True)`.
  In-file comment block explains why `?mode=ro` alone wasn't
  enough.

### Added (test discipline)

- `tests/test_smoke_assert.py::test_assert_passes_against_wal_mode_readonly_dir`
  — strengthens the v0.1.23 test by reproducing the prod failure
  mode exactly: WAL-mode SQLite store + chmod readonly on BOTH
  the DB file and the directory. Without `&immutable=1` the test
  fails with the exact prod error message ("attempt to write a
  readonly database"). A/B-verified before commit. The v0.1.23
  test
  (`test_assert_passes_against_readonly_db`) used a non-WAL
  fixture and chmod on only the file, which passed under
  `?mode=ro` alone — the test's assumed scenario didn't match
  what prod actually was.
- `tests/test_smoke_assert.py::test_assert_uri_includes_immutable_flag`
  — source-level pin against accidental reversion to `?mode=ro`
  alone. If a future edit drops `immutable=1`, this test fails
  the suite immediately.

### Internal

- Test count: 1137 → 1139 (+2 in `test_smoke_assert.py`).
- The earlier v0.1.23 test
  `test_assert_passes_against_readonly_db` is kept (still useful
  as a sanity check on non-WAL fixtures).
- v0.1.23's `test_assert_passes_against_wal_mode_readonly_db`
  was renamed to `test_assert_passes_against_wal_mode_readonly_dir`
  with a strengthened body matching what actually reproduces the
  bug — chmod on the directory too, not just the file.

### Cross-references

- v0.1.23's docker-ghcr cell failure log:
  <https://github.com/efterlev/efterlev/actions/runs/25473754617/job/74742740327>
  — shows the exact prod error message that v0.1.23's
  insufficient `?mode=ro` produced.
- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  v0.1.23 follow-on" — v0.1.23 design context.
- `src/efterlev/provenance/store.py:87` — the
  `PRAGMA journal_mode=WAL` that drives the WAL-related half of
  this bug.

## [0.1.23] — 2026-05-07

CI follow-on + cross-platform repair. v0.1.22's matrix-assertion
fix to `release-smoke` made the matrix actually run far enough to
expose problems that were silently masked across every prior
release. Four bugs in one PR — all surfaced by v0.1.22's first
auto-triage + first matrix run that got past the assertion script:

1. **Workflow: T7 reported SKIP** ("no GH token in env") because
   `GITHUB_TOKEN` is not auto-injected into shell env in GH
   Actions — it has to be passed explicitly via `env:`.

2. **Workflow: triage fired against the wrong tag.** Within
   minutes of v0.1.22 landing, GitHub cancelled a 24h-old
   release-smoke run for v0.1.12; that cancellation fired the
   new `workflow_run` trigger with `head_branch=v0.1.12`,
   running triage against v0.1.12 (which fails current T-checks).
   v0.1.18–v0.1.21 still have queued release-smoke runs that
   would re-fire the same false trigger.

3. **Product: Windows-2022 cells failed `import fcntl`.**
   `src/efterlev/provenance/receipts.py:33` had an unconditional
   `import fcntl` (POSIX-only stdlib). Wheel was un-importable
   on Windows; every Windows install since fcntl was added to
   receipts.py was broken at import time. Masked by the silent
   matrix until v0.1.22's assertion fix let Windows cells run
   far enough to surface `ModuleNotFoundError: No module named
   'fcntl'`.

4. **Workflow: docker-ghcr cells failed "attempt to write a
   readonly database".** Container writes the SQLite store as
   root onto the mounted host volume; host's
   `sqlite3.connect()` defaults to read-write mode and tries to
   create a journal file, which fails on root-owned files.
   v0.1.22 surfaced the failure but didn't have the fix yet.

### Fixed

- `.github/workflows/post-release-triage.yml`:
  - Pass `GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}` into the
    "Run triage and capture report" step env. Without this, T7
    reports SKIP instead of querying the matrix conclusion API.
  - Tighten the trigger `if` gate to allowlist upstream
    conclusion `{success, failure}` only. Cancelled / skipped /
    timed_out events from stale runs no longer fire.
- `src/efterlev/provenance/receipts.py`:
  - Replace the unconditional `import fcntl` with platform-gated
    `_flock_exclusive` / `_flock_release` helpers. fcntl on
    POSIX, msvcrt on Windows. Both are stdlib; no new deps.
  - Wheel now imports cleanly on Windows.
- `tests/smoke/assert.py`:
  - Open the SQLite store in URI read-only mode
    (`file:<path>?mode=ro`). The assertion only counts rows; no
    writes needed. Bypasses the journal-file create path so
    docker-ghcr cells (root-owned DB on host) can pass.

### Added

- `tests/test_receipts_locking.py` (5 tests) — pin the cross-
  platform lock helpers + a regression test that fails the
  suite if `import fcntl` reappears at module top.
- `tests/test_smoke_assert.py::test_assert_passes_against_readonly_db`
  — chmod a fixture DB to 0o444 + verify the assertion still
  passes. Locks the URI-read-only fix against accidental
  reversion.

### Internal

- Test count: 1131 → 1137 (+6: 5 new in
  `test_receipts_locking.py` + 1 new in `test_smoke_assert.py`).
- Source files unchanged at 178; detector count unchanged at 45.

### Cross-references

- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  v0.1.23 follow-on" — root-cause + design discussion for all
  four bugs and the bundled-PR rationale.
- v0.1.22's CHANGELOG + DECISIONS entries — prior context.
- `release-smoke` matrix at
  <https://github.com/efterlev/efterlev/actions/workflows/release-smoke.yml>
  — should land green on v0.1.23 across mac/win/linux/arm + both
  install methods. **This is the first release whose Release
  page is expected to show T1-T7 all PASS** with T7 reporting
  the actual matrix conclusion (not SKIP).

## [0.1.22] — 2026-05-07

CI repair + observability lift. release-smoke had been silently
failing across every matrix cell on v0.1.20 + v0.1.21 (and probably
earlier — these are the two cycles I checked back) without anyone
noticing: the workflow_run row in `gh run list` collapsed to a
single "queued" status while individual matrix jobs failed on a
stale assertion script. v0.1.22 fixes the assertion AND adds T7 to
the post-release-triage report so silent matrix failures cannot
recur.

### Fixed

- **`tests/smoke/assert.py`** — the post-install matrix assertion
  had two bugs that made it impossible to pass against a real
  install:
  - Wrong table name: `FROM records` → `FROM provenance_records`
    (actual table per `src/efterlev/provenance/store.py:32`). The
    `OperationalError: no such table: records` was caught by the
    bare `sqlite3.Error` handler and surfaced one line down in
    the FAILED list as "sqlite error querying store: no such
    table: records".
  - Wrong expectation: the script asserted `<store>/reports/`
    exists, but the smoke workflow runs `efterlev init` +
    `efterlev scan` only — never `efterlev report run`, which is
    what generates HTML reports. The `reports/` requirement was a
    category error against the workflow's actual command sequence
    and would have failed every matrix cell on v0.1.20 + v0.1.21
    even without the SQLite bug.

### Added

- **`tests/test_smoke_assert.py`** (11 tests) — unit-tests the
  smoke assertion against an in-memory fixture store. Locks the
  contract so this can't silently break again: happy path with
  seeded evidence passes, missing DB / missing store dir fails,
  empty `provenance_records` table fails with a clear message,
  presence of a `records` table without `provenance_records`
  also fails (no false-positive PASS path), reports/ dir is NOT
  required (the test specifically asserts the script passes
  against a store with no reports/ dir at all).

- **T7 release-smoke matrix** in `scripts/triage.sh` — surfaces
  the release-smoke matrix conclusion on the GitHub Release
  page, alongside the existing T1-T6 deterministic checks.
  Queries the GH Actions API for the release-smoke workflow run
  matching the tag and reports per-cell failure detail when red.
  PENDING is a valid status when triage fires before smoke
  completes; the workflow now reruns triage on release-smoke
  completion to repopulate.

- **`.github/workflows/post-release-triage.yml`** — added
  `release-smoke` to the `workflow_run` trigger list so triage
  reruns when the matrix finishes (~10 min after tag), repopulating
  T7 with real data after the initial release-container-triggered
  run (~4 min after tag) showed T7 PENDING. Added
  `actions: read` permission so triage can query the GH Actions
  API for matrix conclusion. Dropped the prior
  `conclusion == 'success'` gate: triage now fires regardless of
  upstream success/failure so the Release page surfaces actual
  state instead of staying blank when something went wrong.

### Internal

- Test count: 1120 → 1131 (+11 from the new
  `tests/test_smoke_assert.py`). Source files: unchanged at 178.
  Detector count: unchanged at 45.
- `scripts/triage.sh` phase numbering documented in the file
  header. PENDING gets a ⏳ marker in the Release table.

### Cross-references

- DECISIONS 2026-05-07 "release-smoke matrix visibility:
  surfacing silent failures via T7" — full design rationale,
  alternatives considered (separate workflow vs. T7-in-triage),
  and the decision to make the GH Release page the single
  observable surface for release-quality data.
- LIMITATIONS.md "Lessons learned: silent matrix failures
  v0.1.20–v0.1.21" — a callout flagging the prior gap.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — Tier 1 #1–#3
  shipped; Tier 1 #4 (detector gap analysis) still on the
  roadmap. v0.1.22 is an unscheduled CI repair, not a Tier 1
  item.

## [0.1.21] — 2026-05-06

Tier 1 #3 of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 1 #3 design"). Ships the Evidence Manifest
starter pack — the biggest single coverage lift available per
LIMITATIONS' "scanner + manifests can approach 80%+" claim. Closes
the procedural-KSI gap that detectors structurally can't reach.

### Added

- **`efterlev manifests init --starter-pack`** — new subcommand tree
  (`efterlev manifests`) for Evidence Manifest content management.
  When `--starter-pack` is set, copies 24 bundled
  `<KSI-ID>.template.yml` files + a `README.md` workflow guide + a
  `SELECTION.md` audit trail into `.efterlev/manifests/starter-pack/`.
  Subdir lands OUTSIDE the manifest loader's pickup glob — templates
  are physically present (the user can read, copy from, version-
  control them) but invisible to the attestation pipeline until
  explicitly moved to the parent `.efterlev/manifests/` dir.
  `--force` required to overwrite an existing subdir.

- **24 hand-authored manifest templates** under
  `src/efterlev/manifest_templates/`. Bundled in the wheel via
  `importlib.resources`. Selection criteria locked in DECISIONS
  2026-05-06: hybrid theme + control-family check produces 17 KSIs
  from the 3 entirely-procedural FRMR themes (AFR/CED/INR) + 7 from
  detector-covered themes whose mapped 800-53 controls are
  procedural-only families (PIY/CMT/RPL/SVC). Each template:
  - `ksi: KSI-XXX-XXX` + `name: "..."`
  - `_template_help.description` (2-3 sentences from FRMR + audit framing)
  - `_template_help.questions` (3-7 hand-authored questions per KSI)
  - `evidence[0]` attestation skeleton with explicit `DRAFT —`
    placeholders for `statement`, `attested_by`, `attested_at`,
    `reviewed_at`, `next_review`, `supporting_docs`
  - Inline DRAFT example showing realistic attestation shape

- **`scripts/generate_starter_pack.py`** — source of truth for the 24
  templates. Re-run when FRMR adds a new KSI matching the selection
  criteria, or when maintainer-curated `_template_help` content changes.

### Changed

- `efterlev.manifests.loader.discover_manifest_files` now skips
  `*.template.yml` files. Defense-in-depth: even if a user
  accidentally copies `KSI-XXX.template.yml` directly to
  `.efterlev/manifests/` without dropping the suffix, the loader
  excludes it from the attestation pipeline. One-line filter
  addition; behavior preserved for all real `*.yml` / `*.yaml`
  manifests.

- `LIMITATIONS.md` adds a Tier 1 #3 shipped marker; updated
  `next_review` recommendation in templates is "6-month cadence".

### Internal

- `tests/test_manifest_starter_pack.py` (11 tests) covers: 24-template
  count lock, README + SELECTION presence, every KSI ID exists in
  FRMR catalog, every template has ≥3 hand-authored questions, every
  fillable field carries a `DRAFT` placeholder, loader skip filter
  excludes `*.template.yml`, CLI happy path copies all templates,
  CLI refuses overwrite without `--force`, CLI overwrites cleanly
  with `--force`, CLI refuses without `--starter-pack` flag, CLI
  refuses against an uninitialized workspace.
- Test count: 1109 → 1120 (+11). Source files: 177 → 178
  (`manifest_templates/` package marker). CLI commands: 25 → 27
  (added `manifests` subcommand tree + `manifests init`).
- Wheel build verified to include all 24 `*.template.yml` files +
  README.md + SELECTION.md under `efterlev/manifest_templates/`.

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #3 design: Evidence Manifest starter
  pack" — full design rationale, selection criteria, alternatives
  considered, locked-not-open decisions per "never lazy" directive.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — this is Tier 1 #3.
  Tier 1 progress: #1 (quickstart, v0.1.18), #2a (cost summary,
  v0.1.19), #2b (--dry-run, v0.1.20), #3 (this) shipped; #4
  (detector gap analysis) remains.
- LIMITATIONS.md "scanner + manifests can approach 80%+" — what the
  starter pack enables in practice.
- `src/efterlev/manifest_templates/SELECTION.md` — per-KSI selection
  audit trail.

## [0.1.20] — 2026-05-06

Tier 1 #2b of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 1 #2b design"). Adds `--dry-run` and
`--dump-prompt PATH` to every agent command — the audit-credibility
primitive a 3PAO needs to verify exactly what the LLM was sent.
Pairs with v0.1.19's end-of-run cost summary to complete the
"cost + prompt visibility" Tier 1 #2 work.

### Added

- **`--dry-run` and `--dump-prompt PATH` flags on `efterlev agent
  {gap, document, remediate}`.** When set, the command builds every
  assembled prompt the agent would send, surfaces them as a JSON array
  of literal Anthropic API request envelopes (model + system + messages
  + max_tokens), augmented with `_efterlev` metadata (per-prompt
  iteration index, label, token estimate, dollar cost estimate from
  v0.1.19's pricing table), and exits 0 without invoking the LLM. No
  network call, no Claim records written, no `receipts.log` lines —
  zero side effects on `.efterlev/`. Per-run nonced fences are present
  in every dumped prompt — exactly what Anthropic would have seen.
  Implementation via context-var pattern (matches `active_redaction_ledger`
  / `active_store`); `Agent._invoke_llm` checks
  `active_dry_run_session.get()` and short-circuits with a per-agent
  structurally-valid stub output. (DECISIONS 2026-05-06 "Tier 1 #2b
  design")

- **`--force` flag on `--dump-prompt PATH`.** Refuses to overwrite
  an existing PATH unless `--force` also passed. Standard CLI hygiene
  for the regulated context this command targets — clobbering an
  audit packet is a real harm. Initial design draft of this entry
  rejected `--force` as "friction without real benefit"; revised on
  re-reading per the maintainer's "never lazy" directive.

- **`scripts/triage.sh` T2 doctor-shape unchanged** but `efterlev
  agent {gap,document,remediate} --help` now lists the three new
  flags. Manual smoke after PR lands: `efterlev agent gap
  --target . --dry-run | jq '.[0]._efterlev'` shows the per-prompt
  metadata.

### Changed

- `Agent._invoke_llm` (in `efterlev.agents.base`) gained a
  `dry_run_label: str | None = None` parameter (used for the captured
  prompt's label field). Backwards-compatible default; existing
  callers unchanged.
- `ProvenanceStore.write_record` short-circuits early when a
  `DryRunSession` is active in the context var, returning a
  structurally-valid sentinel `ProvenanceRecord` without touching
  SQLite, the blob store, or `receipts.log`.
- Each agent class (`GapAgent`, `DocumentationAgent`,
  `RemediationAgent`) declares a `_dry_run_stub_output()` factory
  that returns an empty `output_model` instance. The base class's
  default raises if a subclass forgets to implement.
- LIMITATIONS.md adds Tier 1 #2b under "Aspirational / roadmap" as
  shipped at v0.1.20.

### Internal

- `tests/test_dry_run.py` (12 tests) covers session capture +
  serialization, context-var lifecycle, `_invoke_llm`
  short-circuit (asserted via a `FailIfCalledClient` stub),
  `ProvenanceStore.write_record` no-op contract (zero side effects
  on the workspace), CLI flag validation (`--force` requires
  `--dump-prompt`), end-to-end agent-gap dry-run via subprocess,
  `--dump-prompt` file-write semantics, overwrite refusal without
  `--force`, force-overwrite, and the "no new store rows" contract.
- Test count: 1097 → 1109 (+12). Source files: 176 → 177
  (`agents/dry_run.py`).
- The dry-run path is ready for v0.2's vendored Anthropic
  tokenizer follow-up: today the `_efterlev.token_estimate` is a
  4-chars-per-token approximation flagged honestly via the
  `token_estimate_method` field. When precision matters more than
  it does today (real customer feedback), swap in the official
  tokenizer; the surface is one function in `agents/dry_run.py`.

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #2b design" — full design rationale,
  alternatives considered, the "never lazy" revision note that drove
  the all-prompts / API-envelope / `--force` decisions.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — meta-decision; #2b
  closes the "cost + prompt visibility" pair.
- v0.1.19 cost summary (PR #144) — sister feature; together they
  give pre-run AND post-run cost visibility.

## [0.1.19] — 2026-05-06

Tier 1 #2a of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 1 #2a design: end-of-run cost summary on
agent commands"). Adds per-run cost visibility to every agent command
without changing the agent API or scanner output.

### Added

- **End-of-run cost summary on `efterlev agent {gap, document,
  remediate}`.** Each command prints one line at the end of its
  success path:
  ```
  LLM cost: 38,201 in / 8,455 out tokens on claude-sonnet-4-6 (~$0.24)
  ```
  Sums tokens by model from `.efterlev/receipts.log` (filtered to
  this invocation's window via `started_at`), looks up pricing in
  `src/efterlev/llm/pricing.py`, prints. Bedrock backend appends
  `(via bedrock; AWS region pricing may differ)`. Unregistered
  models surface tokens-only with a `pricing for <model> not
  registered` hint instead of crashing. Multi-model runs (e.g. Opus
  → Sonnet fallback fired mid-run) sum correctly and use a short-name
  comma-joined display. Reads from receipts.log rather than collecting
  per-agent — no agent API change, the data is already captured.
  (DECISIONS 2026-05-06 "Tier 1 #2a design"; agents/cost_summary.py
  + llm/pricing.py + 3-line CLI hook in each agent command)

### Changed

- `LIMITATIONS.md` adds a new "Cost estimates are best-effort" note
  documenting the snapshot-pricing posture, Bedrock proxy caveat, and
  the unregistered-model fallback. Tier 1 #2a flips from
  "aspirational" to "shipped at v0.1.19" in the Aspirational/roadmap
  section.

### Internal

- `tests/test_cost_summary.py` (8 tests) covers single-model run,
  multi-model run, Bedrock suffix, unregistered-model fallback,
  mixed priced+unpriced run, started_at timestamp filter excluding
  prior-run entries, no-receipts-file case, no-LLM-entries case
  (StubLLMClient). `tests/test_pricing.py` (6 tests) locks the
  pricing-table API behavior independent of dollar amounts (which
  drift over time as Anthropic adjusts rates).
- Test count: 1083 → 1097 (+14). Source file count: 174 → 176
  (`pricing.py` + `cost_summary.py`).
- 2b (`--dry-run` / `--dump-prompt` flags) gets its own DECISIONS
  entry next, then implementation. Tier 1 sequence:
  1 (quickstart, v0.1.18) ✓ → 2a (cost summary, this) ✓ → 2b →
  3 (manifest starter pack) → 4 (detector gap analysis).

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #2a design" — full design rationale,
  open questions, alternatives considered.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing" — meta-decision sequencing.
- v0.1.9 token-usage telemetry — the data layer this presentation reads.

## [0.1.18] — 2026-05-06

Tier 1 #1 of the v0.1.18+ path forward (CLAUDE.md "Path forward",
DECISIONS 2026-05-06 "Tier 0/1 sequencing"). Ships the first ICP-aligned
feature after the v0.1.16/17 auto-triage infrastructure landed:
**`efterlev quickstart`** — a one-command activation demo for the
ICP A day-one experience.

### Added

- **`efterlev quickstart`** lays down a bundled synthetic Terraform
  + Evidence Manifest fixture in a temp workspace under the
  platform-appropriate user cache dir (`~/Library/Caches/efterlev/`
  on macOS, `~/.cache/efterlev/` on Linux, `%LOCALAPPDATA%\efterlev\`
  on Windows via `platformdirs`), runs `init → scan → agent gap →
  agent document` end-to-end against it, and prints a 5-line summary
  with workspace path, scan stats, classification breakdown, and a
  next-steps line pointing at the user's own repo. Realistic wall
  time: 60–180s with `ANTHROPIC_API_KEY` set (~$0.30 on Sonnet);
  honors `EFTERLEV_E2E_MODEL` for backend/model override.
  (DECISIONS 2026-05-06 "Tier 1 #1 design"; cli/main.py +
  src/efterlev/quickstart/)

- **Graceful no-key degradation.** When `ANTHROPIC_API_KEY` is unset,
  the deterministic phases (init + scan) still run and produce real
  detector evidence; the agent stages skip with a clear "set the key
  and re-run for AI-driven KSI classification + draft attestation"
  hint. ICP A users without a Claude account yet get actionable output
  rather than a stack trace. The summary surfaces real scan stats
  (resources / evidence records / detectors fired) on this path.

- **`python -m efterlev` entry point** (`src/efterlev/__main__.py`).
  Lets `quickstart` shell out to the CLI without depending on the
  `efterlev` script being on PATH at the time the subprocess starts.
  No user-visible change for the standard pipx / uv-tool installs;
  the script-on-PATH invocation continues to work.

### Changed

- **Bundled fixture moved to `src/efterlev/quickstart/`** so
  `efterlev quickstart` and `scripts/e2e_smoke.py` share the same
  source of truth. Growing the fixture for new detector coverage
  in either consumer benefits both automatically. The CI E2E smoke
  gate continues to use the same fixture; no behavior change for
  the harness.

- **`platformdirs>=4.0,<5`** added to dependencies. Tiny dep with no
  transitives; same library pip / uv / ruff use for cross-platform
  cache-dir resolution.

### Internal

- 8 new regression tests in `tests/test_quickstart.py`: fixture
  shape lock; terraform-writer skips manifests; manifest-writer
  skips terraform; cache-root resolves under user HOME; scan-output
  parser extracts the right fields; gap-summary returns None on
  no-report path; e2e_smoke imports the same FIXTURE object as
  quickstart (asserts the shared-source refactor); end-to-end
  no-key path runs clean and produces the expected summary.
- Test count: 1075 → 1083. Source file count: 172 → 174 (added
  `__main__.py` + `quickstart/__init__.py`).

### Cross-references

- DECISIONS 2026-05-06 "Tier 1 #1 design: efterlev quickstart" —
  full design rationale, alternatives considered, scope of v0.1.18.
- DECISIONS 2026-05-06 "Tier 0/1 sequencing for v0.1.18+
  post-auto-triage-landing" — the meta-decision sequencing this
  as Tier 1 #1.
- `CLAUDE.md` "Path forward (v0.1.18+)" — Tier 1 #1 entry.
- `LIMITATIONS.md` "Aspirational / roadmap" — Tier 1 #1 flips from
  "aspirational" to "shipped at v0.1.18" in the same PR.

## [0.1.17] — 2026-05-06

Triage-driven patch from the v0.1.16 first-of-kind auto-triage. Two
findings, both in the v0.1.16 triage infrastructure itself (not in the
v0.1.16 release artifacts, which are 4/4 cryptographically clean):

1. The `post-release-triage.yml` workflow used the default
   `sigstore/cosign-installer@v3` (cosign 2.5.2), which doesn't
   auto-discover OCI 1.1 referrer attestations. Pinned to cosign **2.6.3**
   (the latest 2.x; cosign 3.0.x can't be installed by the action because
   it dropped legacy `.sig` files for `.sigstore.json` bundles). Landed in
   PRs #136 + #137 ahead of v0.1.17.
2. `scripts/triage.sh`'s T6 ("cosign tree visibility") was a redundant
   lightweight inventory check that produced false-negatives on cosign
   2.6.x — `cosign tree` doesn't enumerate OCI 1.1 referrer attestations
   even when they're present. T4 (`verify-release.sh`) already
   cryptographically verifies both attestation presence and validity via
   `cosign verify-attestation --type slsaprovenance1`. **v0.1.17 drops T6.**

The auto-triage methodology is working as designed: caught the issue in
the first auto-triage run for v0.1.16, surfaced both findings, and
v0.1.17 closes them via the standard release loop. v0.1.16's GitHub
Release page has been updated with a clarifying note explaining the
T6 false-negative and pointing at v0.1.17 as the structural fix.

### Changed

- **`scripts/triage.sh` drops T6** ("cosign tree visibility"). The 6
  remaining phases (T1 install + version sanity, T2 doctor shape, T3
  detector count, T4 verify-release.sh, T5 container manifest, T6
  check-docs against tagged source — renumbered from T7) cover the
  release-correctness surface that produced findings F1–H1. T4's
  `cosign verify-attestation` is now the single canonical check for
  "is the SLSA attestation attached and valid" — no separate inventory
  check needed.

### Internal

- `verify-release.sh` example version bumped from v0.1.16 to v0.1.17.
- The `post-release-triage.yml` cosign 2.6.3 pin (PR #137) carries
  forward unchanged.
- v0.1.17 will be the second release with an auto-generated GH Release
  page. Expected outcome: 6/6 PASS, no findings, no manual notes
  required.

## [0.1.16] — 2026-05-06

Infrastructure release. Adds `scripts/triage.sh <tag>` — a deterministic,
zero-LLM post-release validator — and a workflow that runs it after every
tag publish, attaching the triage report as the GitHub Release notes body.
This codifies the manual triage methodology that surfaced findings F1–H1
across v0.1.12–v0.1.15 (each cut catching paper cuts the prior cut's fix
introduced) into automation that runs without human prompting. Side
benefit: auto-creates the GitHub Release pages that have been missing
since v0.1.5 (the team never wrote release notes manually).

No scanner-output behavior change. v0.1.15's 4/4 cryptographic
verification carries forward unchanged.

### Added

- **`scripts/triage.sh <tag>`** runs T1–T7 deterministically:
  - T1: pipx-install the published wheel from PyPI, confirm `--version`
  - T2: confirm `efterlev doctor` returns the expected 7-check shape
  - T3: confirm `efterlev detectors list` reports the expected count
  - T4: invoke `scripts/verify-release.sh` (4/4 PEP 740 + cosign + SLSA v1)
  - T5: confirm container manifest has linux/amd64 + linux/arm64 via
        the OCI registry API (no Docker daemon needed)
  - T6: confirm `cosign tree` shows signature + SLSA v1 attestation
  - T7: run `scripts/check-docs.py` against the tagged source

  Output: GitHub-Flavored Markdown report. Exit 0 = clean; exit 1 =
  findings. Runnable locally for ad-hoc triage of any prior tag.

- **`.github/workflows/post-release-triage.yml`** triggers on
  `release-container.yml` completion (the longer of the two release
  workflows). On the first run for a tag, creates the GitHub Release
  for that tag with the triage report as the body. On reruns
  (`workflow_dispatch`), edits the existing notes. Job exits non-zero
  when triage reports findings, so the Actions UI flags release-quality
  regressions visibly.

- **DECISIONS 2026-05-06** documents the architectural choice — why
  triage runs decoupled from `release-container.yml`, why the report
  attaches to the GH Release rather than a `docs/triage/` directory,
  and which alternatives were considered (full backfill, daily cron,
  external validation framework).

### Internal

- Triage script smoke-tested against v0.1.15 → 7/7 PASS; fail-path
  verified by injecting a synthetic detector-count mismatch (exit 1,
  finding surfaced in the report's Findings section).
- v0.1.16 will be the first release with an auto-generated GH Release
  page. The page body becomes the per-version triage landing page,
  giving 3PAOs and external auditors a documented post-publish
  validation trail without per-release manual effort.

## [0.1.15] — 2026-05-06

Triage-driven patch from the v0.1.14 deterministic validation. Closes the
single finding (H1): the v0.1.14 `install_uniqueness` doctor check walked
PATH only, which missed the dominant parallel-install footgun. Real
repro this session: `pipx install efterlev` venv at
`~/.local/pipx/venvs/efterlev/`, `uv tool install efterlev` venv at
`~/.local/share/uv/tools/efterlev/`, single PATH symlink at
`~/.local/bin/efterlev` pointing into the uv-tool venv. The user runs
`pipx upgrade efterlev`, sees "upgraded", but `efterlev --version`
keeps returning the OLD version because the PATH symlink belongs to uv
tool. v0.1.14's check returned PASS on this state; v0.1.15's catches it.

### Changed

- **`efterlev doctor` install_uniqueness check now walks package-manager
  metadata dirs in addition to PATH.** The PATH walk (G2 in v0.1.14)
  catches the case of two custom installs both on PATH; the new
  manager-metadata walk catches the dominant case of two managers
  fighting over a single PATH symlink. Detected manager dirs:
  - `~/.local/pipx/venvs/efterlev/` → pipx
  - `~/.local/share/uv/tools/efterlev/` → uv tool
  - `~/Library/Python/<v>/lib/python/site-packages/efterlev/` (macOS user pip)
  - `~/.local/lib/python<v>/site-packages/efterlev/` (linux user pip)

  When ≥2 distinct installations are detected by either strategy, the
  warning names each path + the matching uninstall command. PATH
  binaries that resolve under a known manager dir aren't double-counted
  (otherwise a single pipx install + its `~/.local/bin` shim would
  false-positive). The green-case detail also names which manager
  owns the install — useful diagnostic for "where IS efterlev installed?"
  (H1 from v0.1.14 triage; cli/doctor.py)

### Internal

- Test count: 1073 → 1075 (+2: `detects_pipx_and_uv_tool_managers`
  asserts the dominant H1 footgun fires the warn; `does_not_double_
  count_path_under_manager` guards against the false-positive case
  where a single pipx install plus its PATH shim would otherwise
  read as two installs). The existing 3 install_uniqueness tests
  carry forward unchanged in semantics; one was renamed for clarity.

## [0.1.14] — 2026-05-06

Triage-driven patch from the deterministic, zero-LLM post-release validation
of v0.1.13 (the same methodology that produced the v0.1.12 patch). Two
paper-cut findings closed; no scanner-output behavior change. v0.1.13's
4/4 cryptographic verification carries forward unchanged.

### Fixed

- **`docs/index.md` carried two stale current-version references to
  v0.1.11** — one at line 67 (*"45 ship today (v0.1.11)"*) and one at
  line 77 (*"v0.1.11 ... thirteen patch releases..."*). The
  drift slipped through every prior release because the existing
  `check-docs.py` rules cover test/detector/indicator/source-file
  counts and CLI-verb references, but not "current version" prose.
  Both lines now read v0.1.14. (G1 from v0.1.13 triage)
- **`scripts/check-docs.py` gains a `current_version_claim` rule.**
  Scans every `.md` repo-wide for `vX.Y.Z is current` / `vX.Y.Z current`
  patterns and asserts the version matches `efterlev.__version__`.
  Past-tense references ("v0.1.11 closed five findings", "since v0.1.0")
  deliberately don't match — those are historical, not current-state
  claims. The rule caught three additional v0.1.13 stragglers in
  README + CLAUDE.md during the v0.1.14 cut, plus a stale 1070 → 1073
  test-count claim. The doc/code agreement now stays tight by
  construction. (G1 from v0.1.13 triage; scripts/check-docs.py)

### Added

- **`efterlev doctor` warns when multiple `efterlev` binaries sit on
  PATH.** When `pipx install efterlev` and `uv tool install efterlev`
  both exist, PATH ordering picks the winner silently — `pipx upgrade`
  / `uv tool upgrade` against the loser reports success but
  `efterlev --version` still returns the older install. Real repro
  from the v0.1.13 triage: pipx 0.1.13, uv tool 0.1.11, PATH found uv
  first, "upgraded but version unchanged" with no obvious cause. The
  new `install_uniqueness` check walks PATH (resolving symlinks so
  `/usr/local/bin → /opt/bin` doesn't false-positive), names every
  `efterlev` binary it finds, identifies the PATH winner, and points
  at the matching uninstall command. Pre-flight surfaces the
  parallel-install state before the user hits the version-mismatch
  confusion. (G2 from v0.1.13 triage; cli/doctor.py)

### Internal

- Test count: 1070 → 1073 (3 new per-fix regression tests for
  `install_uniqueness`: warns-on-multiple, passes-on-single, and
  dedups-symlinked-paths to prevent the false-positive case).
- `verify-release.sh` example version bumped from v0.1.13 to v0.1.14.

## [0.1.13] — 2026-05-06

Permissions-fix patch on top of v0.1.12. The v0.1.12
`actions/attest-build-provenance@v2` step added to `release-container.yml`
failed at runtime with `Resource not accessible by integration` because
the workflow's `permissions:` block was missing `attestations: write`.
Result: v0.1.12 published with a cosign-signed container but no SLSA
cosign-verifiable attestation, leaving `verify-release.sh v0.1.12` at
3/4 passed (the same posture as v0.1.10 + v0.1.11). v0.1.13 adds the
missing permission and re-fires the full sign + attest path, taking
`verify-release.sh v0.1.13` to 4/4.

### Fixed

- **`release-container.yml` carries `attestations: write`** so the v0.1.12
  `actions/attest-build-provenance@v2` step can call the GitHub
  attestations API. The step's docs list the required permissions but
  the workflow comment that named the related `id-token: write` permission
  obscured the omission. v0.1.13 ships nothing else; the v0.1.12 changes
  (PEP 740 verifier, F2/F3/F4 fixes) all carry forward.

### Internal

- `scripts/verify-release.sh` failure message updated: pre-v0.1.13
  releases are now disambiguated as either "buildx-only provenance"
  (v0.1.10 + v0.1.11) or "attest step misconfigured" (v0.1.12).

## [0.1.12] — 2026-05-06

Triage-driven patch from a deterministic, zero-LLM post-release validation
of v0.1.11 (the first such validation against published wheel + container
artifacts). Four findings closed; no scanner-output behavior change. The
biggest piece is `verify-release.sh` going from 0/4 passed to 4/4 passed
on v0.1.12+ — the script's PyPI check was hitting a 404 because PyPI
moved Trusted-Publishing attestations from `<url>.sigstore` sidecars to
the PEP 740 `/integrity` endpoint, and the container SLSA check was
failing because buildx's in-OCI-manifest provenance was never wrapped as
a cosign-verifiable attestation. Both are wired correctly now; the
project's "verify the release" claim is no longer aspirational.

### Fixed

- **`scripts/verify-release.sh` rewritten for PEP 740 + drops `docker
  buildx` hard-dep.** The PyPI check now fetches each artifact's
  Sigstore bundle from `https://pypi.org/integrity/{project}/{version}/{filename}/provenance`,
  reshapes the PEP 740 attestation into a Sigstore v0.3 bundle (snake_case
  → camelCase, certificate string → `{rawBytes:...}`, envelope DSSE
  reshape), and verifies with `python -m sigstore verify identity`. The
  cosign signature check uses `cosign verify <tag>` directly (cosign
  resolves tag→digest internally; the previous `docker buildx imagetools
  inspect` step was unneeded). The SLSA check (#3 below) now finds a
  cosign-verifiable attestation on v0.1.12+ container images. Pre-v0.1.12
  releases still fail check 3 by design — the script's failure message
  names the upgrade path so users aren't left guessing. (F1 from v0.1.11
  triage; DECISIONS 2026-05-05)
- **`actions/attest-build-provenance@v2` wired into `release-container.yml`.**
  Produces a cosign-verifiable SLSA v1 build-provenance attestation
  pushed to GHCR alongside the image. v0.1.10 + v0.1.11 had buildx-emitted
  SLSA v0.2 provenance attached to the OCI image manifest only
  (verifiable via `docker buildx imagetools inspect --format '{{ json
  .Provenance }}'`); the absence of a separate cosign attestation made
  `cosign verify-attestation --type slsaprovenance` fail. From v0.1.12
  onward, cosign discovers the attestation via the OCI 1.1 referrers
  API. (F1 from v0.1.11 triage)
- **`efterlev scan` warns when `--target` sits below a `.github/workflows/`
  ancestor.** Real customer repos with `infra/terraform/`-style layouts
  routinely run `efterlev scan --target infra/terraform/` and silently
  drop every GitHub-source detector (4 in v0.1.x — sbom-action, codeql,
  dependency-review, ci_validation_gates). The new warning surfaces the
  ancestor path and recommends scanning from the repo root. Walks parents
  of `--target` until it finds `.github/workflows/` or hits the git repo
  root. Documented v0.1.x footgun, no in-tool mitigation pre-v0.1.12.
  (F2 from v0.1.11 triage; cli/main.py)
- **`efterlev scan` surfaces a plan-JSON hint when ≥1 evidence record
  contains an `unparseable` attribute value.** The dominant case is
  `aws_iam_policy { policy = jsonencode({...}) }` — python-hcl2 doesn't
  evaluate Terraform function calls, so the policy comes through as
  `mfa_required="unparseable"` (or equivalents in other detectors).
  Pre-v0.1.12 the unparseable status was buried inside individual
  Evidence records; users who didn't grep the JSON sidecar never saw
  the recommendation to switch to `--plan plan.json` mode (which gives
  Terraform-resolved values). The hint is suppressed in plan-JSON mode
  itself. (F4 from v0.1.11 triage; cli/main.py)
- **Two doc-drift fixes for `.efterlev/reports/<subdir>/` paths, plus a
  `check-docs.py` rule that catches the pattern.** `docs/ai-quickstart-prompt.md:288`
  cited a non-existent gap-report subdir; the actual gap-report path is
  flat (`.efterlev/reports/gap-<ts>.json`). The opposite drift in
  `docs/reference/poam-markdown-shape.md:5` said POA&M lands flat; the
  actual path is `.efterlev/reports/poam/poam-<ts>.md`. The new
  check-docs rule scans every repo `.md` for the
  `.efterlev/reports/<subdir>/` shape and asserts the subdir is in the
  allowlist (currently `{"poam"}` — gap, scan, attestation, documentation
  are flat). When a new subdir is added in code, the check fails until
  the allowlist is bumped, forcing the doc/code agreement to stay tight.
  (F3 from v0.1.11 triage; scripts/check-docs.py)

### Internal

- Test count: 1066 → 1070 (4 new per-fix regression tests for F2/F4 — F3
  is covered by the new check-docs rule).

## [0.1.11] — 2026-05-06

3PAO-finding patch from the v0.1.10 blinded review. A FedRAMP-accredited
3PAO ran a paper review against a clean v0.1.10 govnotes-demo run and
returned an Accept-with-conditions disposition with five findings the
tool's own automation couldn't catch. This release closes the four
artifact-credibility findings and disambiguates the misleading walker
message that drove the highest-severity finding.

No behavior changes for scanner output or LLM-call costs — every fix
lands at the rendering / display / persistence layer.

### Fixed

- **Agent-drafted narratives carry an injected `DRAFT — requires human
  review.` marker** regardless of what the LLM returned. v0.1.10
  shipped the marker hardcoded into the `deterministic_template`
  branch but missing from `agent_drafted` entries when the model
  declined to emit it; the asymmetry made some attestations look
  finalized when they were not. The marker is now structural —
  injected post-response — and the persisted Claim payload, the
  rendered HTML narrative, and the FRMR artifact entry agree.
  Idempotent: a model that already produced the prefix doesn't get
  a doubled marker. (3PAO HIGH; agents/documentation.py)
- **`AttestationDraft` carries `controls_mapped`** so the doc HTML
  and JSON sidecar render the FRMR-mapped 800-53 control split
  alongside `controls_evidenced`. The HTML report now shows the
  mapping explicitly per attestation; the JSON schema bumps to v1.1
  with `controls_mapped` + `boundary_state` fields. Empty case is
  surfaced explicitly for the 9 procedural KSIs in the FRMR catalog
  (KSI-AFR-CCM, FSI, ICP, …) that ship without any `controls` field
  — the renderer now prints "this KSI is procedural in the FRMR
  catalog (no per-control 800-53 attribution)" rather than rendering
  an unexplained blank that read as a tool bug to the 3PAO.
  Uppercase-normalized to NIST canonical form to match
  `generate_frmr_attestation`. (3PAO MEDIUM)
- **Aggregate boundary state rendered per attestation in the doc HTML**
  alongside the existing mode pill. New `AggregateBoundaryState`
  type extends the per-evidence three-valued state with two
  draft-level cases: `mixed` (cited evidence spans in/out-of-
  boundary — variance signal worth flagging by design per DECISIONS
  2026-05-04, but reviewers should see the mix) and `no_evidence`
  (procedural / not_implemented KSIs with no citations). The
  `boundary_state` field is now part of the JSON sidecar schema and
  renders as a pill ("in boundary" / "out of boundary" / "boundary
  mixed" / "boundary undeclared" / "no evidence") with title-text
  explaining each case. (3PAO MEDIUM)
- **`provenance show <evidence_id>` surfaces both `record_id` and
  `evidence_id`** when the resolved record is an Evidence record.
  The dual-key reality (envelope hash on the SQLite row vs. content
  hash inside the payload) was previously hidden behind the prefix-
  resolution banner, which confused the 3PAO trying to verify that
  POA&M citations matched what the walker walked. New output shape
  prints both lines so reviewers can match either citation form
  against the walked record. (3PAO HIGH; cli/main.py)
- **Walker leaf message disambiguated by `record_type`.** A `Claim`
  record with empty `derived_from` is legitimate when the underlying
  classification was `not_implemented` or `evidence_layer_inapplicable`
  with no cited evidence — but the bare "(leaf — no derived_from)"
  message read as a traceability break to the v0.1.10 3PAO. The
  walker now prints `(scanner-emitted leaf — Evidence is derived
  directly from source files; no further derived_from edges by
  design)` for Evidence leaves and a parallel "claim with empty
  derived_from — typical for not_implemented…; not a traceability
  break" message for Claim leaves. No semantic change — only output
  text clarification. (3PAO HIGH; provenance/walker.py)

### Tests

- Ten new regression tests pinned to the v0.1.11 fixes (DRAFT marker
  injection idempotency, `controls_mapped` inheritance through both
  agent_drafted and deterministic_template paths, empty
  `controls_mapped` for procedural KSIs, mixed boundary aggregation,
  no_evidence aggregation, dual-key CLI display, claim-leaf
  disambiguated output, HTML pill rendering, HTML procedural empty
  surfacing). Total suite at 1066 tests; CI E2E smoke gate continues
  to run on every PR.

### Changed (internal)

- `AttestationDraft.controls_mapped: list[str]` (default `[]`).
- `AttestationDraft.boundary_state: AggregateBoundaryState`
  (default `"no_evidence"`).
- Documentation report JSON schema_version 1.0 → 1.1.
- New `aggregate_boundary_state(evidence)` helper in
  `primitives.generate.generate_frmr_skeleton`.

## [0.1.10] — 2026-05-05

Detector-coverage patch closing the v0.1.5–0.1.9 carry-forward Bug A:
`aws.mfa_required_on_iam_policies` now resolves the canonical
`aws_iam_policy_document` data-source pattern. Pre-v0.1.10 every
realistic Terraform repo (most policies in production codebases come
from data sources, not literal JSON) classified KSI-IAM-MFA as
`not_implemented` even when the policies DID enforce MFA. v0.1.10
walks the data source's HCL `statement {}` / `condition {}` blocks
and reports `present` / `absent` with the same fidelity as the
literal-JSON path.

### Fixed

- **`aws.mfa_required_on_iam_policies` resolves data-source policy
  references.** When an `aws_iam_policy` (or sibling) sets `policy =
  data.aws_iam_policy_document.NAME.json`, the detector now looks up
  the matching `data "aws_iam_policy_document" "NAME"` block and walks
  its statements + conditions. Detects the HCL `condition { variable =
  "aws:MultiFactorAuthPresent" values = ["true"] }` form (camelCase /
  list-shape — different from the JSON Condition dict). Emits a new
  `resolved_via_data_source` field on the evidence content so reviewers
  can navigate back to the source statement.
- **Terraform parser emits `data` blocks alongside `resource` blocks.**
  `TerraformResource` gains a `kind: Literal["resource", "data"]`
  field (default `"resource"` for backwards compat). The parser walks
  both `parsed["resource"]` and `parsed["data"]` lists, line-tracking
  via a 3-tuple key. Detectors that iterate `r.type in {...}` keep
  working unchanged (they just see additional resources whose types
  don't match their lists). Detectors that need cross-references
  (this one; potentially future ones) opt into reading data sources
  via `r.kind == "data"`.

### Notes

- Limitations carried into v0.2 prompt-tuning territory:
  `jsonencode(...)` policies and composed `source_policy_documents`
  remain unparseable. Real-world impact is small (most teams use
  `aws_iam_policy_document`); tracked in `docs/followups.md` for
  v0.2.
- This is the first v0.1.x patch shipped through the new CI E2E smoke
  gate (PR #125, v0.1.10). Required-check posture means this PR's CI
  exercises the full pipeline before merge.

## [0.1.9] — 2026-05-05

UX + audit-credibility patch from the v0.1.8 govnotes-demo Bedrock
shakedown. Five fixes: the manifest-out-of-boundary trap, missing
token telemetry on records, `boundary set` defaulting to append (the
verb-vs-behavior surprise), uv-vs-pipx install hint mis-targeting,
and two new DECISIONS entries codifying the boundary-rationale
behavior so 3PAOs can read it explicitly.

### Fixed

- **Evidence Manifests are always in-boundary.** Customer-authored
  Evidence Manifests at `.efterlev/manifests/*.yml` can't structurally
  be out-of-scope, but pre-v0.1.9 they got swept up by tight include
  patterns (`infra/terraform/**` / `.github/workflows/**`) that didn't
  cover the manifest path. The doc-agent drafted narratives but the
  POAM silently excluded them. v0.1.9 special-cases manifest paths
  in `compute_boundary_state` so they're unconditionally `in_boundary`,
  regardless of include/exclude config. Encoding the rule is more
  honest than relying on users to remember a third include pattern
  (see DECISIONS 2026-05-05).
- **Token usage telemetry on Claim records and `receipts.log`.** The
  Anthropic SDK and Bedrock Converse both return `usage.input_tokens`
  / `usage.output_tokens` on every completion. Pre-v0.1.9 these were
  dropped — only `model` and `prompt_hash` made it to the store, so
  post-hoc cost auditing required CloudWatch / Anthropic billing
  dashboards. v0.1.9 captures usage on `LLMResponse`, plumbs it
  through every agent's `metadata` dict, and surfaces both numbers as
  top-level fields on the receipt-log JSONL line. Operators can now
  sum a run's spend with one `jq` invocation.
- **`boundary set` defaults to replace.** v0.1.0 through v0.1.8
  `boundary set` appended by default — surprising because "set" reads
  as "set, replacing what was there." v0.1.9 flips the default:
  `set` replaces; new `--append` flag opts into the old accumulating
  behavior. `--replace` is kept as a deprecated no-op so pre-v0.1.9
  scripts continue to work; surfaces a one-line deprecation note on
  stderr. Surfaced 2026-05-04.
- **Doctor + runbook detect uv vs pipx installer.** The boto3-missing
  hint pointed at `pipx inject efterlev boto3`, but `uv tool install`
  users found pipx commands silently failed against the wrong venv.
  v0.1.9 reads `sys.executable` to detect the installer (uv / pipx /
  pip), then surfaces the right fix-up command:
  `uv tool install --reinstall 'efterlev[bedrock]'` for uv users,
  `pipx install 'efterlev[bedrock]'` for pipx, `pip install` for the
  rest. README runbook Step 2b.3 also splits the install instructions
  by installer.

### Decisions

- **Manifests are always in-boundary** (DECISIONS 2026-05-05). The
  rule is encoded as a pre-config short-circuit in
  `compute_boundary_state`. Other `.efterlev/`-internal paths
  (cache, store) still follow normal config — they're machine-
  generated runtime state, not customer intent.
- **Doc-agent narratives may carry variance-signal references to OOB
  resources** (DECISIONS 2026-05-05). Narratives inherit the gap-
  rationale freedom codified 2026-05-04. The POA&M output is still
  strictly scope-filtered (items with all-OOB evidence are dropped),
  but narratives that survive into in-boundary POA&M items may name
  OOB resources for variance-signal context. Documented explicitly
  so 3PAOs see this as intended, not a leak.

### Notes

- Carry-forward bugs still observed (deferred to v0.2 prompt-tuning):
  KSI-SVC-PRR over/under-classification of CMK posture, IAM
  `aws_iam_policy_document` data-source parsing, sha256-prefix-only
  citations in 30 of 60 narratives, F5 manifest cross-wiring (PagerDuty
  quoted in AFR-FSI narrative instead of INR-RIR's). These want
  prompt iteration + a real-customer corpus.
- v0.1.8's `max_tokens=32768` Bedrock default cleanly cured the
  Sonnet 4.6 truncation in the v0.1.8 verification run.

## [0.1.8] — 2026-05-04

Release-blocker patch from the v0.1.7 govnotes shakedown. Three new
HIGH-severity bugs surfaced; v0.1.8 closes all three plus three smaller
ergonomics fixes.

### Fixed

- **Doc agent dual-emission (60 KSIs → 120 attestations).** Append-only
  store + multi-run `agent gap` (e.g. retry after a max_tokens error,
  A/B-testing prompts) accumulates one Claim per KSI per run.
  `reconstruct_classifications_from_store` returned every Claim, so
  doc-agent processed each KSI N times and emitted N attestations
  with potentially contradictory status. v0.1.8 dedups latest-wins
  (timestamp ascending order from the store, last occurrence per
  ksi_id keeps). Affects `agent document`, `agent remediate`, and
  `efterlev poam`. Each command now prints a one-line stderr note
  when dedup fired (`note: deduped N duplicate classification(s)
  from prior agent gap runs`). Pass `keep_all=True` to
  `reconstruct_classifications_from_store` for run-diffing use cases.
- **Boundary state propagation evidence→KSI on stale-evidence.**
  When the boundary is set AFTER an initial scan (or after
  `agent gap` writes classifications referencing pre-boundary
  evidence), classifications cite a mix of newer (correctly
  out_of_boundary) and older (stale boundary_undeclared) evidence.
  Pre-v0.1.8 the resolver collapsed any non-uniform mix to
  `boundary_undeclared`, leaving the POA&M filter unable to drop
  out-of-scope items. v0.1.8 treats stale-undeclared + at-least-one-
  out_of_boundary (in a workspace with a declared boundary) as
  out_of_boundary, mirroring the user's intent.
- **Configurable max_tokens with backend-aware default.** Sonnet 4.6
  on Bedrock hard-blocked by `max_tokens=20480` (set in v0.1.2 to
  duck Anthropic's 10-min streaming threshold; doesn't apply on
  Bedrock). Adds `LLMConfig.max_tokens` field; default is 20480 on
  Anthropic API, 32768 on Bedrock. Each agent's `_resolve_max_tokens`
  helper picks the right value.
- **Doctor reads AWS config-file region.** v0.1.3 doctor only checked
  env vars; users with `aws configure set region us-east-1` (writes
  to `~/.aws/config`) got false-warned "no region configured" even
  though the runtime worked. v0.1.8 mirrors boto3's full chain —
  `Session.region_name` resolves the config file alongside env.
- **`efterlev poam` always prints out-of-boundary count.** Pre-v0.1.8
  the line was conditional on `count > 0`; users couldn't tell
  whether the boundary had been considered or not. Now prints
  unconditionally; `0` is a useful signal.

### Improved

- **Runbook reality-check on plan-JSON fallback.** `terraform
  -refresh=false` doesn't always bypass `terraform { backend "s3" {} }`
  blocks; the runbook now says "drop straight to HCL if you see
  'Backend initialization required.'"
- **Runbook boundary-pattern guidance.** When users declare
  `--include 'infra/terraform/**'`, all workflow evidence becomes
  out_of_boundary because workflows aren't under that path. The
  Step 5 brief now explicitly mentions the two-pattern fix:
  `--include 'infra/terraform/**' --include '.github/workflows/**'`.

### Notes

- Agent-quality misclassifications surfaced in the v0.1.7 shakedown
  (KSI-SVC-PRR over-classifying as `evidence_layer_inapplicable`,
  KSI-MLA-LET missing retention variance, KSI-SCR-MIT mapping
  "mixed" to `not_implemented`) are tracked as v0.2 prompt-tuning
  work in `docs/followups.md` — they want a real-customer corpus to
  validate against.
- Carry-forward bugs still observed (deferred): IAM
  `aws_iam_policy_document` data-source parsing (`docs/followups.md`),
  rationales citing by sha256 hash without resource name
  (`docs/followups.md`).

## [0.1.7] — 2026-05-04

Detector-coverage + UX patch release. Closes a false-negative finding
on KSI-SCR-MON surfaced by the v0.1.6 terraform-aws-vpc / govnotes-demo
shakedown (the supply-chain-monitoring detector didn't recognize the
canonical `anchore/sbom-action`), plus a POAM artifact gap, a runbook
overhaul to halve the friction on first-run, and an explicit decision
on out-of-boundary evidence visibility.

### Fixed

- **`github.supply_chain_monitoring` recognizes modern action ecosystem**
  (false-negative on KSI-SCR-MON). The detector's action registry was
  too narrow — `anchore/sbom-action` (the canonical post-2023 SBOM
  emitter, the modern replacement for the deprecated `anchore/syft-
  action`) wasn't in the map, so workflows using it surfaced
  `sbom_tools_detected: []` and got classified as `not_implemented`.
  v0.1.7 adds: `anchore/sbom-action`, `aquasecurity/tfsec-action`,
  `step-security/harden-runner`, `google/osv-scanner-action`,
  `anchore/grype-action`, the CycloneDX language-action family
  (`gh-node-module-cyclonedx`, `gh-gomod-generate-sbom`,
  `gh-dotnet-cyclonedx`, `gh-python-generate-sbom`), and per-language
  Snyk action variants. Run-command registry adds: `cdxgen`,
  `spdx-sbom-generator` (SBOM); `dependency-check` (OWASP),
  `bundle-audit`, `govulncheck`, `trivy config` (CVE/scan).
- **POA&M markdown header surfaces out-of-boundary excluded count.**
  v0.1.4's boundary filter drops POA&M items whose cited evidence is
  entirely out-of-boundary; v0.1.5+ surfaced the count to stdout but
  the markdown body was silent on disk. v0.1.7 adds an `Excluded as
  out-of-boundary: N item(s)` bullet to the POA&M header so reviewers
  see the scope drop when reading the artifact later. Header omits
  the bullet when zero items were excluded (avoids visual clutter for
  boundary-undeclared workspaces).

### Improved

- **README AI-quickstart prompt — major UX overhaul.** Six structural
  changes informed by three rounds of real first-run shakedown reports:
  - **Step 0 (new):** repo-root verification before any scan, with a
    heuristic check (`.git/` + at least one of `.tf` or
    `.github/workflows/`) and an explicit confirm-vs-subdir prompt.
    Closes the silent 20%-coverage-loss footgun where a Terraform-only
    subdir gets named instead of the repo root.
  - **Step 1:** backend decision tree. Each option carries an explicit
    "RECOMMEND if…" rationale (credit card → Anthropic API; AWS
    already → Bedrock). Default fallback is Anthropic API since
    first-run friction differential is real.
  - **Step 2b.0 (new):** model family question (Claude / OpenAI /
    other). Honest about Claude-only support today; OpenAI + others
    on the v0.3+ roadmap.
  - **Step 2b.2:** tier picker is a recommendation (Sonnet latest) with
    concrete cost ratios, not a multiple-choice question. Opus / Haiku
    presented as overrides with use-case framing.
  - **Step 3:** `--force` is the default (manifests preserved, cache
    regenerates fresh defaults). Skip-force is the exception.
  - **Step 4:** explicit `terraform init -backend=false` fallback for
    the very-common missing-remote-state case (S3 backend, Terraform
    Cloud) — plus the throwaway-`.tfvars` fallback for missing
    required variables.
  - **Step 5:** proactive brief after gap. Reads the gap-report JSON
    and surfaces the classification breakdown, workspace boundary
    state, top 3 KSIs to focus on (biased toward SVC + IAM hot spots),
    and 2 partial KSIs flagged as best `agent remediate` targets.
    After document/poam: mode breakdown + POA&M counts.

### Decisions

- **Out-of-boundary evidence visibility codified
  (DECISIONS 2026-05-04):** the boundary filter scopes the POA&M
  output, not the gap-report rationales. Agents may cite any evidence
  in the active store when reasoning; only the POA&M renderer drops
  items whose cited evidence is entirely out of scope. The v0.1.6
  shakedown surfaced this as ambiguous (KSI-RPL-ABO citing
  out-of-boundary `dev_scratch` instances) — codifying the variance-
  signal interpretation rather than the redaction interpretation.
  See DECISIONS 2026-05-04 for the full rationale.

### Notes

- Per-classification `confidence` field on `KsiClassification` (vs the
  current hardcoded `Claim.confidence="medium"`) is tracked in
  `docs/followups.md` as v0.2 work — needs prompt-template change +
  schema bump and wants real-customer corpus to calibrate against.
- `govnotes-demo` separately ships a doc-only fix for KSI naming drift
  in DELIBERATE_GAPS.md (v0.9.43-beta uses `KSI-SVC-PRR` /
  `KSI-CNA-MAT` / `KSI-MLA-LET`, not the `CMT-CKM` / `CNA-IAS` /
  `MLA-RTN` ids the Tier 1 doc cited).

## [0.1.6] — 2026-05-04

Provenance-integrity patch release. Closes the three issues surfaced by
the v0.1.5 terraform-aws-vpc shakedown plus a v0.1.5 messaging miss.
The headline finding ("Gap Agent fabricates evidence IDs") was a
false alarm — the IDs were real `Evidence.evidence_id` values that
v0.1.5's prefix-resolver couldn't reach because it only matched
`record_id`. Fixing the resolver makes the chain walkable from any
POAM-shown prefix.

### Fixed

- **`provenance show <prefix>` resolves evidence_ids, not just
  record_ids** — POA&Ms and rationales print 8-char prefixes of
  `Evidence.evidence_id` (the content hash the model sees in fences).
  v0.1.5's `resolve_record_id_prefix` only matched against
  `provenance_records.record_id` (the envelope hash). Pasting a
  POAM-shown prefix returned "no record matches" even though the full
  evidence_id walked correctly. Extends the resolver with a Step 2
  payload-scan that mirrors `resolve_to_record`'s dual-key lookup,
  with collision detection across both id spaces.
- **POA&M output lands under `.efterlev/reports/poam/`** — pre-v0.1.6
  wrote flat `.efterlev/reports/poam-<ts>.md`, but the runbook docs
  pointed at the subdir form. Aligns the writer with the docs and
  clusters per-report-type artifacts. Pass `--output` to override.
- **Plan-JSON trade-off note also fires when `--plan` IS used** —
  v0.1.5 added the line-numbers caveat but only in the
  recommend-plan-JSON branch. Users who were already in plan-JSON
  mode never saw the explanation for their `source_lines: null`
  citations. Now prints the trade-off any time plan-JSON is in use.
- **GitHub-workflow detectors emit file-level line ranges instead of
  null** — workflow files are conceptually single units (one Evidence
  per file), but v0.1.5 left `source_ref.line_start`/`line_end`
  as None, making the audit trail unnecessarily weak. v0.1.6 sets
  `line_start=1, line_end=<file_total_lines>`. Per-step line
  numbers (e.g. `uses:` step lines) are tracked as a v0.2 enhancement.
- **`provenance verify` adds derived_from referential-integrity
  check** — pre-v0.1.6 only verified blob hashes match content_refs.
  Now also walks every record's envelope `derived_from` and confirms
  each cited id resolves via the dual-key path. Catches anything
  that ever bypasses the write-time validator (future tooling, manual
  DB writes, migrations).

## [0.1.5] — 2026-05-03

Honesty-and-ergonomics patch release. Closes three issues surfaced by
the v0.1.4 fully-private-cluster shakedown: a CLI dead-end, a misleading
metadata field, and a marketing claim that didn't survive contact with
plan-JSON mode.

### Fixed

- **`provenance show` accepts truncated SHA prefixes** — POA&Ms,
  rationales, and attestation report tables print 8-char prefixes for
  readability, and users naturally pasted those into `provenance show`
  expecting them to resolve. Earlier versions matched only the full
  64-hex form, so the prefix was a dead end. Now the CLI prefix-resolves
  via `record_id LIKE 'sha256:<prefix>%'` and prints the resolution
  banner (`resolved sha256:81fffc53 → sha256:81fffc53...full`). Refuses
  prefixes shorter than 4 hex chars (collision risk) and raises
  `ProvenanceError` on prefix collisions instead of silently picking the
  first match.
- **Attestation `mode` field stops lying about deterministic
  narratives** — v0.1.4 introduced a no-LLM template path for
  `evidence_layer_inapplicable` KSIs, but kept stamping the resulting
  drafts as `mode="agent_drafted"`. That hid the cost-saving from
  reviewers AND broke the field's contract as a "what produced this
  prose?" signal — downstream tooling could no longer tell template-
  filled entries apart from LLM-drafted ones. Adds a third literal
  `deterministic_template` to `AttestationMode` and threads it through
  the artifact serializer, the JSON sidecar (`mode` field), and the
  HTML report (a new mode-pill badge alongside the status pill).
- **README + scan output drop the "cited source lines" claim on
  plan-JSON mode** — `terraform show -json` output doesn't preserve HCL
  line numbers, so plan-JSON Evidence records carry `source_lines:
  null` on every citation. The README, the AI-quickstart prompt, and
  the scan-mode-recommendation message now state the trade-off
  explicitly ("plan-JSON gives full module coverage but citations land
  at file-level only until line recovery lands in v0.2"). Line recovery
  is tracked in `docs/followups.md` as the leading v0.2.0 item.

## [0.1.4] — 2026-05-01

First-run UX patch release. Closes the friction items surfaced by a real
v0.1.3 Bedrock first-run report against govnotes-demo. Each fix maps to
a specific report number; bundled so the next first-run is dramatically
quieter and cheaper.

### Fixed

- **`agent document` runs deterministic narratives on
  `evidence_layer_inapplicable` KSIs by default** (report #5). On a
  typical 60-KSI baseline, 25-45 KSIs are procedural-only — earlier
  versions generated full Sonnet narratives for each that were
  essentially boilerplate ("scanner cannot evidence; reviewer must
  corroborate procedurally"). Now those entries get a deterministic
  narrative built from the Gap Agent's already-produced rationale + the
  KSI's underlying 800-53 controls, with no LLM call. The FRMR
  attestation completeness is preserved — all 60 KSIs still get an
  entry. Pass `--include-inapplicable-narratives` to opt back into
  LLM-drafted prose for these. **Saves ~70% of Sonnet spend on
  documentation runs.**
- **`doctor` warns when boundary scope is undeclared** (report #3).
  Earlier doctor runs reported "5 pass, 0 warn, 0 fail" while the gap
  report header showed `workspace_boundary_state: boundary_undeclared`.
  Now reads `[boundary]` from `.efterlev/config.toml` and surfaces a
  warn-level check with a remediation hint pointing at
  `efterlev boundary set --include 'boundary/**'`. The check is
  informational; running outside a formal authorization boundary stays
  permitted.
- **SHA256 record-ID dumps moved behind `--verbose`** (report #6) on
  `efterlev scan` and `efterlev agent gap`. Default output now prints
  a one-line summary ("N record(s) written to .efterlev/store.db; pass
  --verbose..."). Forensics still available; first-time users no longer
  get a flood of hashes.
- **Absolute paths for printed report files** (report #7). `efterlev
  scan`, `agent gap`, `agent document`, `agent remediate`, and
  `report diff` all now print fully-resolved paths for HTML/JSON
  outputs. Earlier mix of relative and absolute (within the same
  block on `agent document`) is fixed.
- **"Next steps" footers** on `agent gap` and `agent document` outputs
  (report #8). Each surfaces the right follow-on commands with their
  typical cost — `agent document`, `poam`, `agent remediate --ksi <id>`.
- **`init` creates `.efterlev/manifests/` with a README** (report #10)
  on first run. Earlier versions created the directory lazily (only
  when a manifest was loaded), leaving the gap between docs ("commit
  manifests under `.efterlev/manifests/`") and on-disk state unbridged.
  README inside the new dir explains the format with a worked example.
- **README AI-quickstart prompt clarifies "repo root" vs "Terraform
  path"** — silent root cause of the prior shakedown's two anomalies
  (3 manifests not loading, 4 GitHub-workflow detectors not firing,
  ~20% of detector coverage disappeared). Repo-root scoping is now
  explicit with a one-paragraph note on what subdir-scoping skips.

### Notes

- Cost-summary at end of agent runs (report #4) and `--llm-tier=opus|
  sonnet|haiku` shorthand for Bedrock (report #9) are tracked as
  v0.2.0 features in `docs/followups.md` — both want token-counting
  + price-model design that's bigger than a patch release.
- terraform-init-failure → cleaner scan-mode message (report #2)
  tracked in followups.

## [0.1.3] — 2026-04-30

Patch release closing the Bedrock-onboarding cliff surfaced in a real
first-run test against AWS Bedrock (`us-east-1`). Each fix matches a
reproducible failure mode the user hit; bundled to ship together so a
single `pipx install efterlev[bedrock]` works end-to-end.

### Fixed

- **Bedrock client used the boto3 default 60s read_timeout.** Gap Agent
  prompts (60 KSIs × ~75 evidence records) routinely take longer on
  Opus 4.7. Three retries multiplied 60s into ~3× wasted cost before
  surfacing failure. Now sets `read_timeout=600`, `connect_timeout=10`,
  and `retries={"max_attempts": 1}` on the boto client (Efterlev has
  its own retry loop; the boto layer's was redundant).
- **Agents crashed when LLMs wrapped output in ` ```json ` fences.**
  Opus 4.6 (and occasionally Sonnet 4.6 on Bedrock) wraps structured
  output in markdown fences despite system-prompt instructions to
  return raw JSON. Added defensive fence-stripping before
  `json.loads` in `agents/base.py._invoke_llm`.
- **`init --llm-backend=bedrock` defaulted to a model ID that doesn't
  exist in most accounts.** v0.1.x had `us.anthropic.claude-opus-4-7-v1:0`
  hardcoded. Now probes the user's account via
  `bedrock.list_inference_profiles(typeEquals="SYSTEM_DEFINED")` and
  picks the latest available Anthropic Opus profile when `--llm-model`
  isn't passed. Falls back to the hardcoded default with a clear warning
  when the probe fails (no perms, no boto, no profiles).
- **`doctor` only checked AWS credentials in env vars,** false-warning
  users whose creds came from `~/.aws/credentials`, `AWS_PROFILE`, IMDS,
  or SSO. Now uses `boto3.Session().get_credentials()` (the full
  credential chain) — matches what the runtime client actually consults.
- **`doctor` now pings `InvokeModel` end-to-end** when the workspace is
  configured for Bedrock. 1-token throwaway prompt validates that the
  configured model is reachable, the credentials work, and access is
  granted — catches stale defaults, missing inference-profile access,
  and expired SSO sessions before the user spends API budget on a
  doomed agent run.
- **`doctor`'s ANTHROPIC_API_KEY check skips when backend is bedrock.**
  Earlier versions warned about a missing key on workspaces where the
  key is irrelevant.

### Notes

- Streaming refactor of the Anthropic clients (deferred from v0.1.2)
  remains queued for v0.2.0. The Bedrock-side `read_timeout=600` makes
  long completions practical without it; the structural fix is still
  the right destination.

## [0.1.2] — 2026-04-30

Patch release closing two real-CI bugs surfaced by the govnotes-demo
deep-dive shakedown — the canonical Evidence Manifest pattern (commit
manifests, gitignore cache) didn't survive a fresh clone, and v0.1.1's
bumped `max_tokens=32768` tripped Anthropic's streaming-required
threshold and prevented the gap agent from running at all.

### Fixed

- **`report run` skipped init when `.efterlev/manifests/` was the only
  thing in the workspace dir.** The detection looked at the dir, not
  the FRMR cache file scan needs. Fresh clones with manifests
  committed but the cache gitignored hit "FRMR cache missing"
  immediately. `report run` now detects the cache (the actual
  artifact) and passes `--force` to its sub-init step when the dir
  exists but the cache is missing — regenerates cache + provenance
  store while preserving customer-authored manifests. Regression
  test added.
- **Gap Agent `max_tokens=32768` raised "streaming required" on real
  workloads.** Anthropic's `messages.create()` (non-streaming) path
  rejects requests whose `max_tokens` could plausibly take >10
  minutes. Reduced to **20480** — enough headroom over the v0.1.0
  truncation site (~16384) for the full 60-KSI baseline with
  substantive rationales, but well below the streaming threshold.
  If real workloads need more, the right move is the streaming
  refactor (`client.messages.stream()`), not chasing the cap.
- **README + CLAUDE.md test count drift** (1019 → 1020 after PR #104
  added a regression test for the half-init pattern).

### Notes

- Streaming refactor of the Anthropic client is queued as a
  v0.2.0-targeted item — the right structural fix when output budget
  needs to grow further. The fake-client surface in
  `tests/test_anthropic_retry_fallback.py` would need rewiring for a
  streaming context manager.

## [0.1.1] — 2026-04-29

Patch release closing three v0.1.0 bugs surfaced in a deep-dive shakedown
test against `terraform-aws-modules/terraform-aws-iam` and a synthetic
ground-truth target.

### Fixed

- **Gap Agent `max_tokens` truncation.** The cap was 16384, which truncated
  mid-JSON on real-world full-baseline runs (60 KSIs each with substantive
  rationales). Bumped to 32768 — Claude Opus 4.7's output ceiling. The
  agent's own error message ("increase the max_tokens argument") is now
  acted on; full-baseline runs complete without truncation.
- **Confusing LLM-invocation transcript record.** `agents.base._invoke_llm`
  used to write a per-run transcript record with `record_type="claim"`,
  payload `{user_message, response_text, parsed}`, and empty `derived_from`.
  It looked like a malformed Claim to anyone listing claim records or
  walking provenance — and triggered tester confusion about whether the
  retry path was corrupting state. Removed; per-claim records (per KSI for
  Gap, per narrative for Documentation, per remediation for Remediation)
  already carry `model`, `prompt_hash`, and properly-populated
  `derived_from`. No information loss.
- **`efterlev --version` reported stale `0.0.1` from the published 0.1.0
  wheel.** `pyproject.toml` had a version literal `"0.1.0"` while
  `src/efterlev/__init__.py` had `__version__ = "0.0.1"` — two sources of
  truth, drifted. Switched to hatch dynamic versioning
  (`[tool.hatch.version] path = "src/efterlev/__init__.py"`) so pyproject
  reads from the source file. Added a CI-time regression test
  (`test_in_source_version_matches_package_metadata`) so future drift is
  caught before release.

### Notes

- Bug #5 from the shakedown report (gap/remediate disagreement on
  KSI-AFR-UCM scope: gap classified `partial` citing FIPS-TLS evidence, but
  remediate refused with "no Terraform surface to remediate") deferred to
  `docs/followups.md`. Root cause is design-level: the Gap Agent has
  freedom to cite any prompt-visible Evidence in its rationale, while
  remediate's CLI gate strictly filters by `Evidence.ksis_evidenced`. The
  fix needs a design call between trusting the Gap Agent's citations vs.
  enforcing detector-level KSI mapping at remediate time. Not a regression;
  present in v0.1.0.
- Prompt-tuning concerns from the shakedown (systematic leniency, rationale
  reuse across thematically-adjacent KSIs) are v0.2.0 work — they want a
  real-customer evidence corpus to tune against rather than synthetic
  dogfood.

## [0.1.0] — 2026-04-29

First public release. The work in this section closes Priorities 1, 2,
and 3 of `docs/v1-readiness-plan.md` plus the post-launch-prep
walkback / audit / new-detector arc. 51 PRs landed 2026-04-27 →
2026-04-29 (#36 → #96).

### Priority 1 — Detector breadth (✅ complete; lifted post-floor)

Coverage moved from 14 → 31 KSIs / 5 → 8 themes / 38 → 45 detectors.
The plan's ≥30 KSI / ≥8 theme floor was reached at PR #51; post-walkback
work (PRs #88, #89, #92) lifted coverage to 31 / 8 / 45.

- **Added detectors:**
  - `aws.terraform_inventory` — KSI-PIY-GIV (PR #39)
  - `aws.s3_lifecycle_policies` — KSI-SVC-RUD (PR #40)
  - `aws.federated_identity_providers` — KSI-IAM-APM (PR #41)
  - `aws.iam_managed_via_terraform` — KSI-IAM-AAM (PR #42)
  - `aws.cloudfront_viewer_protocol_https` — KSI-SVC-VCM (PR #47)
  - `aws.ec2_imdsv2_required` — KSI-CNA-IBP (PR #48); cross-mapped to KSI-CNA-DFP via CM-2 (PR #51)
  - `aws.backup_restore_testing` — KSI-RPL-TRC (PR #49)
  - `aws.suspicious_activity_response` — KSI-IAM-SUS (PR #50)
  - `aws.vpc_logical_segmentation` — KSI-CNA-ULN (PR #36)
  - `github.ci_validation_gates` — KSI-CMT-VTD (PR #37)
  - `github.supply_chain_monitoring` — KSI-SCR-MON (PR #38)
  - `github.immutable_deploy_patterns` — KSI-CMT-RMV (PR #44)
  - `github.action_pinning` — KSI-SCR-MIT (PR #46)

- **Cross-mappings** (existing detectors gained additional KSI attributions
  via FRMR control overlap, not invented attribution):
  - `aws.cloudtrail_audit_logging` → +KSI-CMT-LMC via AU-2 (PR #43)
  - `aws.iam_admin_policy_usage`, `aws.iam_inline_policies_audit` → +KSI-IAM-JIT via AC-6 (PR #45)
  - `aws.ec2_imdsv2_required` → +KSI-CNA-DFP via CM-2 (PR #51)

### Priority 2 — HTML report overhaul (✅ complete)

All 9 acceptance items closed. 11 PRs (#52 → #62 + #63 doc).

- **JSON sidecars on all 3 reports** — `gap-{ts}.json`, `documentation-{ts}.json`,
  `remediation-{ksi}-{ts}.json`. Schema-versioned; suitable for tool integration.
  PRs #52, #53, #54.
- **Coverage matrix** — single-page heatmap of all 11 themes × 60 KSIs at the
  top of the gap report. KSIs the agent didn't classify render as `unclassified`.
  Click any cell to scroll to the per-KSI classification card. PR #55.
- **Filter by status** — single-click pills above the classification list.
  Inline vanilla JS, no framework. PR #56.
- **Free-text search** — debounced input, live match count, additive with
  the status filter. PR #57.
- **Print stylesheet** — interactive bits hide; cards don't split across
  pages; out-of-boundary `<details>` expand on paper. PR #58.
- **Sort controls** — by KSI / severity / evidence count. PR #59.
- **Drill-down** — per-classification `<details>` listing each cited
  evidence's `source_file:line_range`. JSON sidecar gains
  `cited_evidence_refs[]`. PR #60.
- **Diff view** — `efterlev report diff PRIOR CURRENT` writes both
  `gap-diff-{ts}.html` and `gap-diff-{ts}.json`. CI-gateable: exits 2 on
  regression. PRs #61 (compute), #62 (CLI + HTML).

All Priority-2 features are self-contained (no external CDN, no fonts beyond
system-default, no analytics) and degrade gracefully without JavaScript
(filter/sort show all results in input order).

### Post-launch-prep walkback + audit (✅ complete)

Triggered by AWS's 2026-04-27 FedRAMP 20x deep-dive blog and a
maintainer review pass. 12 PRs landed 2026-04-28 → 2026-04-29
(#80 → #92), plus the dependency unblock #93.

**Detector additions:**
- `aws.nacl_restrictiveness` — KSI-CNA-RNT (PR #88). Per-NACL
  posture summary (restrictive / partially_restrictive / permissive
  / empty); emits Evidence even on clean NACLs so positive evidence
  flows to the Gap Agent.
- `aws.centralized_log_aggregation` — KSI-MLA-OSM (PR #89). Workspace-
  scoped summary of log producers + aggregators; closes the
  "no SIEM aggregation primitives visible" agent narrative gap.

**Detector reclassifications:**
- `aws.iam_user_access_keys` (PR #92): primary mapping
  KSI-IAM-MFA → **KSI-IAM-SNU** (Securing Non-User Authentication);
  KSI-IAM-MFA preserved as cross-mapping. Adds KSI-IAM-SNU to the
  covered set (30 → 31 KSIs).

**Mapping audits + partial-coverage discipline:**
- PR #83: SVC-RUD and SVC-VCM downgraded to partial cross-mappings
  with explicit notes (scheduled-vs-on-request, viewer-edge-vs-S2S).
- PR #91: 6 detectors gained explicit `coverage: partial` notes
  (cloudtrail_log_file_validation, cloudwatch_alarms_critical,
  guardduty_enabled, elb_access_logs, vpc_flow_logs_enabled,
  access_analyzer_enabled).
- PR #90: systematic audit of all 34 remaining KSI-mapped detectors
  (`docs/detector-mapping-audit.md`). 23 direct fits, 9 partial
  cross-mappings, 2 reclassification candidates.

**Real bug fixes:**
- PR #82: FRMR loader now reads `varies_by_level.{level}.statement`
  with fallback to top-level. 5 KSIs (KSI-CNA-EIS, KSI-MLA-ALA,
  KSI-SVC-PRR, KSI-SVC-RUD, KSI-SVC-VCM) were silently statement-
  less; the Gap Agent had been classifying them blind.
- PR #81: report path display uses the user-supplied form (e.g.
  `/tmp/...`) instead of canonical (`/private/tmp/...`); macOS
  symlink paper-cut surfaced by a real local run.

**CSX-SUM / CSX-ORD gap closures:**
- PR #84: `validation_cadence` field added to documentation artifact
  (closes the CSX-SUM cadence-field-gap acknowledged in csx-mapping.md).
- PR #85: `efterlev poam --sort csx-ord` mode (closes the CSX-ORD
  prescribed-sequence-sort gap).

**Init-time UX:**
- PR #86: catalog freshness warning at `efterlev init` (180-day
  staleness + post-CR26-window heuristics).

**Framing walkback:**
- PR #80: walked back overclaims in csx-mapping.md / aws-coexistence.md
  / release-notes-v0.1.0-draft.md / README.md / aws-ksi-blog-analysis.md.
  "shaped to satisfy CSX-SUM" instead of "IS the artifact 3PAOs
  consume" (pending Priority 5 empirical validation).

**Documentation + upstream:**
- PR #87: drafts of two FRMR upstream feedback issues (file post-tag).
- PR #93: pathspec upper bound widened `<1` → `<2` to unblock
  Dependabot resolver.

**Dependabot bulk-merge:**
- 7 minor/major version bumps merged (#3, #4, #5, #6, #7, #9, #10).
  Python 3.14 (#2) and mypy 1.20 (#8) deferred to v0.1.x.

### Priority 3 — UX during install and usage (✅ complete)

All 6 acceptance items closed. 6 PRs (#64 → #69 + #70 doc).

- **`efterlev doctor`** — five pre-flight checks (Python, .efterlev workspace,
  FRMR cache freshness, ANTHROPIC_API_KEY shape, AWS Bedrock credentials)
  with per-check pass/warn/fail and remediation hints. No network calls.
  PR #64.
- **Friendly errors** — all 8 typed `anthropic.APIError` subclasses mapped to
  one-line messages + remediation hints at the agent CLI boundary. PR #65.
- **`efterlev report run`** — one-command pipeline (init → scan → agent gap
  → agent document → poam) with per-stage `--skip-*` flags. PR #66.
- **First-run wizard** — TTY-gated, credential-aware intro at `efterlev init`.
  Auto-skips on non-TTY (CI-safe); never modifies config silently. PR #67.
- **Progress indicators** — Documentation Agent emits
  `[idx/total] KSI-XXX ✓` per narrative to stderr. PR #68.
- **`--watch` mode** — `efterlev report run --watch` polls the target for
  `.tf`/`.tfvars`/`.yml`/`.yaml`/`.json` changes (debounced 2s) and re-runs
  the pipeline. Polling-based, no `watchdog` dependency. PR #69.

### Catalog stats (post-session)

- 1018 tests passing
- 172 source files
- 24 CLI commands
- 45 detectors (38 KSI-mapped + 7 supplementary 800-53-only)
- 31 KSIs covered across 8 themes
- mypy strict / ruff check / ruff format clean

### Documentation

- `docs/v1-readiness-plan.md` updated to mark Priorities 1, 2, 3 complete
  with PR pointers per acceptance item (PRs #51, #63, #70).

### Out of scope this session

- Priority 4 (boundary scoping): already shipped pre-session.
- Priority 5 (real customer dogfood + 3PAO touchpoint): calendar-time
  work outside the code surface — needs maintainer outreach.
- Priority 6 (honesty pass on `ksis=[]` detectors): already done
  pre-session.

The remaining gates to v0.1.0 are: maintainer security-review §8 sign-off,
24-hour fresh-eyes pause, optional GovCloud walkthrough, then `git push
origin v0.1.0`.
