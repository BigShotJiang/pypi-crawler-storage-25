"""TORC certificate and result types."""

from dataclasses import dataclass, field, asdict
from enum import Enum
import json


class Verdict(str, Enum):
    UNSAT = "UNSAT"
    UNKNOWN = "UNKNOWN"


@dataclass
class TORCCertificate:
    """Topological infeasibility certificate."""
    structure: str          # "php", "tseitin", "coloring"
    parameters: dict        # structure-specific params (e.g. n_pigeons, n_holes)
    h1_rank: int = 0
    obstruction_norm: float = 0.0
    winding_number: int = 0
    details: dict = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)


@dataclass
class TORCResult:
    """Result of torc-sat analysis."""
    verdict: Verdict
    certificate: TORCCertificate = None
    time_ms: float = 0.0
    detectors_tried: list = field(default_factory=list)

    @property
    def is_unsat(self):
        return self.verdict == Verdict.UNSAT

    def to_dict(self):
        d = {
            "verdict": self.verdict.value,
            "time_ms": round(self.time_ms, 3),
            "detectors_tried": self.detectors_tried,
        }
        if self.certificate:
            d["certificate"] = self.certificate.to_dict()
        return d

    def to_json(self, indent=2):
        return json.dumps(self.to_dict(), indent=indent)

    def __str__(self):
        if self.is_unsat:
            cert = self.certificate
            return (
                f"UNSAT (topological certificate)\n"
                f"  Structure: {cert.structure}\n"
                f"  Parameters: {cert.parameters}\n"
                f"  H1 rank: {cert.h1_rank}\n"
                f"  Obstruction norm: {cert.obstruction_norm:.6f}\n"
                f"  Winding number: {cert.winding_number}\n"
                f"  Time: {self.time_ms:.3f} ms"
            )
        return f"UNKNOWN ({self.time_ms:.3f} ms, tried: {', '.join(self.detectors_tried)})"
