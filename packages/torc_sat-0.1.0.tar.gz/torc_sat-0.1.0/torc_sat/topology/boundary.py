"""Boundary operators for simplicial/Cech complexes."""

import numpy as np
from itertools import combinations


def cech_boundary_operators(n_patches: int):
    """Build Cech boundary operators delta0, delta1 for n patches.

    delta0: C0 -> C1 (0-cochains to 1-cochains)
    delta1: C1 -> C2 (1-cochains to 2-cochains)

    Returns (delta0, delta1, overlaps, triples).
    """
    overlaps = list(combinations(range(n_patches), 2))
    triples = list(combinations(range(n_patches), 3))

    n_overlaps = len(overlaps)
    n_triples = len(triples)

    delta0 = np.zeros((n_overlaps, n_patches), dtype=np.int32)
    for idx, (i, j) in enumerate(overlaps):
        delta0[idx, i] = -1
        delta0[idx, j] = 1

    delta1 = np.zeros((n_triples, n_overlaps), dtype=np.int32)
    overlap_index = {pair: idx for idx, pair in enumerate(overlaps)}
    for idx, (i, j, k) in enumerate(triples):
        delta1[idx, overlap_index[(j, k)]] = 1
        delta1[idx, overlap_index[(i, k)]] = -1
        delta1[idx, overlap_index[(i, j)]] = 1

    return delta0, delta1, overlaps, triples


def graph_boundary_matrix(n_vertices: int, edges: list):
    """Build boundary matrix (incidence) for a graph over GF(2).

    boundary[v, e] = 1 iff vertex v is endpoint of edge e.

    Returns np.ndarray of shape (n_vertices, n_edges), dtype uint8.
    """
    ne = len(edges)
    boundary = np.zeros((n_vertices, ne), dtype=np.uint8)
    for i, (u, v) in enumerate(edges):
        boundary[u, i] = 1
        boundary[v, i] = 1
    return boundary
