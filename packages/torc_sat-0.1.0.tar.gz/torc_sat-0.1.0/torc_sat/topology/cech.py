"""Cech cohomology H1 for PHP-like structures.

Adapted from TORC complexity/php_torus.py.
Computes H1(cover, Z) via Cech complex: H1 = ker(d1) / im(d0).
"""

import numpy as np
from itertools import combinations


def compute_php_h1(n_pigeons: int, n_holes: int) -> dict:
    """Compute H1 for PHP(n_pigeons, n_holes).

    Cover: one patch per hole.
    H1 != 0 AND non-trivial cocycle => UNSAT.

    Returns dict with h1_rank, obstruction_detected, cocycle_norm, winding.
    """
    n = n_holes  # number of patches

    # Enumerate overlaps and triples
    overlaps = list(combinations(range(n), 2))
    triples = list(combinations(range(n), 3))
    n_overlaps = len(overlaps)
    n_triples = len(triples)

    # delta0: C0 -> C1, delta0(f)(Ui ∩ Uj) = f(Uj) - f(Ui)
    delta0 = np.zeros((n_overlaps, n), dtype=np.int32)
    for idx, (i, j) in enumerate(overlaps):
        delta0[idx, i] = -1
        delta0[idx, j] = 1

    # delta1: C1 -> C2
    delta1 = np.zeros((n_triples, n_overlaps), dtype=np.int32)
    overlap_index = {pair: idx for idx, pair in enumerate(overlaps)}
    for idx, (i, j, k) in enumerate(triples):
        delta1[idx, overlap_index[(j, k)]] = 1
        delta1[idx, overlap_index[(i, k)]] = -1
        delta1[idx, overlap_index[(i, j)]] = 1

    # Ranks
    rank_delta0 = int(np.linalg.matrix_rank(delta0.astype(np.float64)))
    if n_triples > 0 and n_overlaps > 0:
        rank_delta1 = int(np.linalg.matrix_rank(delta1.astype(np.float64)))
    else:
        rank_delta1 = 0

    dim_ker_delta1 = n_overlaps - rank_delta1
    h1_rank = max(dim_ker_delta1 - rank_delta0, 0)

    # Obstruction cocycle
    surplus = n_pigeons - n_holes
    cocycle = np.zeros(n_overlaps, dtype=np.float64)
    for idx, (j, k) in enumerate(overlaps):
        if k == j + 1 or (j == 0 and k == n - 1):
            cocycle[idx] = surplus / n
    cocycle_norm = float(np.linalg.norm(cocycle))

    obstruction_detected = surplus > 0 and cocycle_norm > 1e-10

    # Winding number
    winding = surplus if surplus > 0 else 0

    return {
        "h1_rank": h1_rank,
        "obstruction_detected": obstruction_detected,
        "cocycle_norm": cocycle_norm,
        "winding": winding,
        "rank_delta0": rank_delta0,
        "rank_delta1": rank_delta1,
        "dim_c1": n_overlaps,
        "pigeon_surplus": surplus,
    }
