"""GF(2) linear algebra for Tseitin obstructions.

Adapted from TORC complexity/tseitin/tseitin_graph.py.
Detects Tseitin infeasibility via rank check over GF(2):
  system insatisfacible iff c not in im(boundary_matrix).
"""

import numpy as np


def gf2_rank(M: np.ndarray) -> int:
    """Rank of matrix M over GF(2) via Gaussian elimination."""
    if M.size == 0:
        return 0
    m, n = M.shape
    A = M.astype(np.uint8) & 1
    rank = 0
    for col in range(n):
        nz = np.nonzero(A[rank:, col])[0]
        if len(nz) == 0:
            continue
        pabs = rank + nz[0]
        if pabs != rank:
            A[[rank, pabs]] = A[[pabs, rank]]
        rows_with = np.nonzero(A[:, col])[0]
        rte = rows_with[rows_with != rank]
        if len(rte):
            A[rte] ^= A[rank]
        rank += 1
    return rank


def detect_tseitin_obstruction(
    n_vertices: int,
    edges: list,
    charges: dict,
) -> dict:
    """Detect Tseitin obstruction via GF(2) rank.

    Args:
        n_vertices: number of graph vertices
        edges: list of (u, v) tuples
        charges: dict vertex -> {0, 1}

    Returns dict with obstruction_detected, parity_sum, rank info.
    """
    nodes = sorted(charges.keys())
    nv = len(nodes)
    ne = len(edges)
    node_idx = {v: i for i, v in enumerate(nodes)}

    # Boundary matrix: |V| x |E|, column e=(u,v) has 1 in rows u,v
    boundary = np.zeros((nv, ne), dtype=np.uint8)
    for i, (u, v) in enumerate(edges):
        boundary[node_idx[u], i] = 1
        boundary[node_idx[v], i] = 1

    # Charge vector
    c_vec = np.array([charges[v] % 2 for v in nodes], dtype=np.uint8)

    # Parity check (fast path for connected graphs)
    parity_sum = int(c_vec.sum() % 2)

    # Full check: rank([boundary | c]) vs rank(boundary)
    rank_b = gf2_rank(boundary)
    aug = np.column_stack([boundary, c_vec.reshape(-1, 1)])
    rank_aug = gf2_rank(aug)
    obstruction = rank_aug > rank_b

    return {
        "obstruction_detected": bool(obstruction),
        "parity_sum": parity_sum,
        "rank_boundary": rank_b,
        "rank_augmented": rank_aug,
        "n_vertices": nv,
        "n_edges": ne,
        "h1_dim": ne - nv + 1,  # for connected graph
    }
