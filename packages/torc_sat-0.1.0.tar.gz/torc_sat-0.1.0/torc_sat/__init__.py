"""torc-sat — Topological SAT preprocessor.

Detects UNSAT in CNF formulas via cohomological obstructions (TORC).
Recognizes combinatorial structures (PHP, Tseitin, graph coloring)
hidden in DIMACS CNF and applies topological infeasibility certificates.

Usage:
    from torc_sat import check
    result = check("instance.cnf")
    print(result.verdict, result.time_ms)
"""

from torc_sat.analyzer import check, check_cnf
from torc_sat.certificate import TORCResult

__version__ = "0.1.0"
__all__ = ["check", "check_cnf", "TORCResult"]
