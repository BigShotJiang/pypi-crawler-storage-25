"""CLI: torc-sat check instance.cnf"""

import argparse
import sys
import os
import time


def cmd_check(args):
    """Check a single CNF file."""
    from torc_sat.analyzer import check

    result = check(args.file)
    if args.json:
        print(result.to_json())
    else:
        print(result)


def cmd_bench(args):
    """Benchmark a directory of CNF files."""
    from torc_sat.analyzer import check
    import subprocess

    cnf_files = sorted(
        f for f in os.listdir(args.directory)
        if f.endswith(".cnf")
    )

    if not cnf_files:
        print(f"No .cnf files in {args.directory}")
        return

    results = []
    for fname in cnf_files:
        path = os.path.join(args.directory, fname)

        # torc-sat
        result = check(path)
        torc_ms = result.time_ms
        torc_verdict = result.verdict.value

        # minisat (if available)
        minisat_ms = None
        minisat_verdict = None
        try:
            t0 = time.perf_counter()
            proc = subprocess.run(
                ["minisat", path, "/dev/null"],
                capture_output=True, timeout=300,
            )
            minisat_ms = (time.perf_counter() - t0) * 1000.0
            minisat_verdict = "UNSAT" if proc.returncode == 20 else "SAT" if proc.returncode == 10 else "?"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            minisat_verdict = "N/A"

        speedup = ""
        if minisat_ms and torc_verdict == "UNSAT" and minisat_ms > 0:
            speedup = f"{minisat_ms / torc_ms:.0f}x"

        results.append((fname, torc_verdict, torc_ms, minisat_verdict, minisat_ms, speedup))

    # Print table
    print(f"{'File':<40} {'TORC':>8} {'ms':>10} {'minisat':>8} {'ms':>10} {'speedup':>8}")
    print("-" * 86)
    for fname, tv, tms, mv, mms, sp in results:
        mms_str = f"{mms:.1f}" if mms is not None else "N/A"
        print(f"{fname:<40} {tv:>8} {tms:>10.3f} {mv or 'N/A':>8} {mms_str:>10} {sp:>8}")


def main():
    parser = argparse.ArgumentParser(
        prog="torc-sat",
        description="Topological SAT preprocessor — detect UNSAT via cohomological obstructions",
    )
    sub = parser.add_subparsers(dest="command")

    # check
    p_check = sub.add_parser("check", help="Check a CNF file")
    p_check.add_argument("file", help="Path to DIMACS CNF file")
    p_check.add_argument("--json", action="store_true", help="Output JSON")
    p_check.set_defaults(func=cmd_check)

    # bench
    p_bench = sub.add_parser("bench", help="Benchmark a directory of CNF files")
    p_bench.add_argument("directory", help="Directory with .cnf files")
    p_bench.set_defaults(func=cmd_bench)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
