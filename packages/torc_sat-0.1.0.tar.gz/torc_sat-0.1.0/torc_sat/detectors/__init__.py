"""Structure detectors for CNF formulas."""

from torc_sat.detectors.php import PHPDetector
from torc_sat.detectors.tseitin import TseitinDetector
from torc_sat.detectors.coloring import ColoringDetector
from torc_sat.detectors.xor import XORDetector
from torc_sat.detectors.hall import HallDetector
from torc_sat.detectors.chessboard import ChessboardDetector
from torc_sat.detectors.ordering import OrderingDetector

ALL_DETECTORS = [
    PHPDetector,
    TseitinDetector,
    ColoringDetector,
    XORDetector,
    HallDetector,
    ChessboardDetector,
    OrderingDetector,
]
