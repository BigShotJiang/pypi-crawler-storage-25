"""Mutilated chessboard detector.

Detects domino tiling problems on grid-like structures and proves
infeasibility via black/white parity argument.

A standard chessboard has equal black and white squares. Removing
two squares of the same color makes tiling with dominoes impossible
because each domino covers one black and one white square.

This is a classic hard UNSAT problem that requires exponential-length
resolution proofs but has a trivial parity-based proof.
"""

from collections import defaultdict
from torc_sat.detectors.base import StructureDetector
from torc_sat.parser import CNFInstance
from torc_sat.certificate import TORCCertificate


class ChessboardDetector(StructureDetector):
    name = "chessboard"

    def detect(self, cnf: CNFInstance) -> dict | None:
        """Detect domino tiling / grid covering structure in CNF.

        Standard encoding:
          - Variable x_{i,e}: cell i is covered by domino placement e.
          - At-least-one per cell: each cell must be covered.
          - At-most-one per domino position: each domino covers exactly 2 cells.
          - Conflict: overlapping dominos can't both be placed.

        We detect by looking for:
          1. A set of "item" clauses (each item needs at least one cover)
          2. Binary negative clauses (conflicts between coverings)
          3. Grid-like adjacency structure
        """
        if not cnf.clauses:
            return None

        # Separate clause types
        pos_clauses = []  # all-positive (covering constraints)
        neg_binary = []   # binary negative (conflict/exclusion)

        for clause in cnf.clauses:
            if all(lit > 0 for lit in clause) and len(clause) >= 1:
                pos_clauses.append(clause)
            elif len(clause) == 2 and all(lit < 0 for lit in clause):
                neg_binary.append(clause)

        if len(pos_clauses) < 4 or not neg_binary:
            return None

        # Each positive clause represents a cell needing coverage
        n_cells = len(pos_clauses)

        # Build variable -> cells mapping
        var_to_cells = defaultdict(set)
        for i, clause in enumerate(pos_clauses):
            for var in clause:
                var_to_cells[var].add(i)

        # A "domino" variable covers exactly 2 cells
        domino_vars = {}
        for var, cells in var_to_cells.items():
            if len(cells) == 2:
                domino_vars[var] = tuple(sorted(cells))

        if len(domino_vars) < n_cells // 2:
            return None

        # Build adjacency from domino placements
        adj = defaultdict(set)
        for var, (c1, c2) in domino_vars.items():
            adj[c1].add(c2)
            adj[c2].add(c1)

        # Check for grid-like structure: try to find 2D grid coordinates
        coords = self._find_grid_coords(n_cells, adj)
        if coords is None:
            # Not a grid but might still be a bipartite covering problem
            coloring = self._bipartite_coloring(n_cells, adj)
            if coloring is None:
                return None
            n_black = sum(1 for c in coloring.values() if c == 0)
            n_white = sum(1 for c in coloring.values() if c == 1)
            return {
                "n_cells": n_cells,
                "n_dominos": len(domino_vars),
                "is_grid": False,
                "n_black": n_black,
                "n_white": n_white,
                "coloring": coloring,
            }

        # Grid found: compute black/white counts
        n_black = sum(1 for (r, c) in coords.values() if (r + c) % 2 == 0)
        n_white = n_cells - n_black

        return {
            "n_cells": n_cells,
            "n_dominos": len(domino_vars),
            "is_grid": True,
            "grid_coords": coords,
            "n_black": n_black,
            "n_white": n_white,
        }

    def prove_unsat(self, cnf: CNFInstance, structure: dict) -> TORCCertificate | None:
        """Prove domino tiling UNSAT via parity argument.

        Each domino covers one black and one white cell.
        If n_black != n_white, tiling is impossible.
        """
        n_black = structure["n_black"]
        n_white = structure["n_white"]
        n_cells = structure["n_cells"]

        if n_black == n_white:
            return None  # Equal counts, can't prove UNSAT by parity

        imbalance = abs(n_black - n_white)

        return TORCCertificate(
            structure="chessboard",
            parameters={
                "n_cells": n_cells,
                "n_black": n_black,
                "n_white": n_white,
                "imbalance": imbalance,
            },
            h1_rank=imbalance,
            obstruction_norm=float(imbalance),
            winding_number=imbalance,
            details={
                "method": "parity",
                "n_black": n_black,
                "n_white": n_white,
                "is_grid": structure.get("is_grid", False),
            },
        )

    def _find_grid_coords(self, n_cells, adj):
        """Try to assign 2D grid coordinates to cells.

        Uses BFS from a corner cell (degree <= 2).
        Returns dict cell -> (row, col) or None if not a grid.
        """
        if n_cells == 0:
            return None

        # Find a corner: cell with smallest degree
        degrees = {v: len(adj.get(v, set())) for v in range(n_cells)}
        if not degrees:
            return None

        # Grid cells have degree 2 (corners), 3 (edges), or 4 (interior)
        min_deg = min(degrees.values())
        if min_deg > 4:
            return None  # Not grid-like

        start = min(degrees, key=degrees.get)
        coords = {start: (0, 0)}
        queue = [start]
        visited = {start}

        while queue:
            current = queue.pop(0)
            r, c = coords[current]
            neighbors = sorted(adj.get(current, set()))

            for nb in neighbors:
                if nb in visited:
                    continue
                # Try to assign coordinates
                # Find an unused direction
                used = set()
                for v in visited:
                    if v in adj.get(current, set()):
                        vr, vc = coords.get(v, (None, None))
                        if vr is not None:
                            used.add((vr - r, vc - c))

                for dr, dc in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
                    if (dr, dc) not in used:
                        new_r, new_c = r + dr, c + dc
                        # Check no conflict
                        conflict = False
                        for v, (vr, vc) in coords.items():
                            if vr == new_r and vc == new_c:
                                conflict = True
                                break
                        if not conflict:
                            coords[nb] = (new_r, new_c)
                            visited.add(nb)
                            queue.append(nb)
                            break

        if len(coords) < n_cells * 0.8:
            return None

        return coords

    def _bipartite_coloring(self, n_cells, adj):
        """Try to 2-color the adjacency graph (bipartite check).

        Returns dict cell -> {0, 1} or None if not bipartite.
        """
        from collections import deque
        color = {}

        for start in range(n_cells):
            if start in color:
                continue
            if start not in adj:
                color[start] = 0
                continue

            color[start] = 0
            queue = deque([start])

            while queue:
                u = queue.popleft()
                for v in adj.get(u, set()):
                    if v not in color:
                        color[v] = 1 - color[u]
                        queue.append(v)
                    elif color[v] == color[u]:
                        return None  # Not bipartite

        return color
