"""PHP (Pigeonhole Principle) detector.

Recognizes PHP in CNF:
  - Long clauses (all positive, same length m) = pigeon clauses
    "each pigeon goes to some hole"
  - Binary clauses (both negative) = hole exclusion
    "no two pigeons in same hole"
  - n_pigeons > n_holes => UNSAT by topology
"""

from collections import Counter
from torc_sat.detectors.base import StructureDetector
from torc_sat.parser import CNFInstance
from torc_sat.certificate import TORCCertificate
from torc_sat.topology.cech import compute_php_h1


class PHPDetector(StructureDetector):
    name = "php"

    def detect(self, cnf: CNFInstance) -> dict | None:
        """Detect PHP structure in CNF.

        PHP(n+1, n) encoding:
          - (n+1) clauses of length n, all positive: pigeon clauses
          - n * C(n+1,2) binary clauses, all negative: hole exclusion

        We detect more generally: PHP(m, n) where m > n.
        """
        if not cnf.clauses:
            return None

        # Separate clauses by type
        all_pos_long = []  # all-positive clauses with len > 2
        all_neg_binary = []  # all-negative binary clauses

        for clause in cnf.clauses:
            if len(clause) > 2 and all(lit > 0 for lit in clause):
                all_pos_long.append(clause)
            elif len(clause) == 2 and all(lit < 0 for lit in clause):
                all_neg_binary.append(clause)

        if not all_pos_long or not all_neg_binary:
            return None

        # All positive long clauses should have the same length (= n_holes)
        lengths = Counter(len(c) for c in all_pos_long)
        if len(lengths) != 1:
            return None
        n_holes = list(lengths.keys())[0]
        n_pigeons = len(all_pos_long)

        if n_pigeons <= n_holes:
            return None  # Not a proper PHP (satisfiable)

        # Verify structure: each pigeon clause should use distinct variables
        # mapping to holes, and binary clauses should be hole exclusions.

        # Build pigeon -> set of variables mapping
        pigeon_vars = []
        for clause in all_pos_long:
            pigeon_vars.append(set(clause))

        # Each pigeon clause variables should represent assignments to holes.
        # In standard encoding: variable x_{i,j} = pigeon i in hole j.
        # All pigeon clauses for pigeon i share no variables with pigeon i'.
        # Check: pigeon clauses are pairwise disjoint in variables.
        all_vars_flat = []
        for pv in pigeon_vars:
            all_vars_flat.extend(pv)
        if len(all_vars_flat) != len(set(all_vars_flat)):
            # Variables overlap between pigeon clauses — might still be PHP
            # with a non-standard encoding, but we skip for soundness.
            # Actually, in standard PHP encoding, x_{i,j} is unique per (i,j),
            # so pigeon clauses ARE pairwise disjoint.
            return None

        # Verify binary clauses: each pair (-x_{i,j}, -x_{i',j}) for same hole j
        # We need to identify which variable corresponds to which hole.
        # In pigeon clause i, variable at position j maps to hole j.
        # So variable pigeon_vars[i][j] = x_{i,j}.

        # Build var -> (pigeon, hole_position)
        var_to_ph = {}
        for pigeon_idx, clause in enumerate(all_pos_long):
            for hole_pos, var in enumerate(sorted(clause)):
                var_to_ph[var] = (pigeon_idx, hole_pos)

        # Verify binary clauses: each should be (-x_{p1,h}, -x_{p2,h})
        expected_binary = set()
        for h in range(n_holes):
            for p1 in range(n_pigeons):
                for p2 in range(p1 + 1, n_pigeons):
                    v1 = sorted(list(pigeon_vars[p1]))[h]
                    v2 = sorted(list(pigeon_vars[p2]))[h]
                    expected_binary.add(frozenset([-v1, -v2]))

        actual_binary = set()
        for clause in all_neg_binary:
            actual_binary.add(frozenset(clause))

        # Check if actual binary clauses match expected (subset is ok if extra)
        if not expected_binary.issubset(actual_binary):
            # Might have extra clauses or different encoding
            # Accept if at least 80% match (for robustness)
            overlap = len(expected_binary & actual_binary)
            if overlap < 0.8 * len(expected_binary):
                return None

        return {
            "n_pigeons": n_pigeons,
            "n_holes": n_holes,
            "n_pigeon_clauses": len(all_pos_long),
            "n_hole_clauses": len(all_neg_binary),
        }

    def prove_unsat(self, cnf: CNFInstance, structure: dict) -> TORCCertificate | None:
        """Prove PHP UNSAT via Cech H1."""
        n_pigeons = structure["n_pigeons"]
        n_holes = structure["n_holes"]

        if n_pigeons <= n_holes:
            return None

        h1 = compute_php_h1(n_pigeons, n_holes)

        if not h1["obstruction_detected"]:
            return None

        return TORCCertificate(
            structure="php",
            parameters={"n_pigeons": n_pigeons, "n_holes": n_holes},
            h1_rank=h1["h1_rank"],
            obstruction_norm=h1["cocycle_norm"],
            winding_number=h1["winding"],
            details=h1,
        )
