"""Tseitin formula detector.

Recognizes Tseitin encoding in CNF:
  - Variables correspond to graph edges.
  - For each vertex v of degree d, there are 2^(d-1) clauses of length d
    encoding the XOR parity constraint: sum of edge variables incident to v = charge(v).
  - Infeasible iff sum of charges is odd (for connected graph).
"""

from collections import defaultdict
from torc_sat.detectors.base import StructureDetector
from torc_sat.parser import CNFInstance
from torc_sat.certificate import TORCCertificate
from torc_sat.topology.gf2 import detect_tseitin_obstruction


class TseitinDetector(StructureDetector):
    name = "tseitin"

    def detect(self, cnf: CNFInstance) -> dict | None:
        """Detect Tseitin structure in CNF.

        Strategy:
        1. Group clauses by their variable set (ignoring signs).
        2. For each group with variables V, check if it has exactly 2^(|V|-1) clauses.
        3. Check if the group encodes XOR or XNOR (all 2^(|V|-1) even/odd parity patterns).
        4. Reconstruct the graph (variables = edges) and charges.
        """
        if not cnf.clauses:
            return None

        # Group clauses by their variable set (abs of literals)
        groups = defaultdict(list)
        for clause in cnf.clauses:
            key = frozenset(abs(lit) for lit in clause)
            groups[key].append(clause)

        # Filter: keep only groups that look like XOR encoding
        # A XOR of d variables uses 2^(d-1) clauses of length d
        xor_groups = {}
        for varset, clauses in groups.items():
            d = len(varset)
            expected_count = 1 << (d - 1)  # 2^(d-1)
            if len(clauses) == expected_count and d >= 2:
                # Verify it's actually a XOR/XNOR encoding
                charge = self._decode_xor_group(varset, clauses)
                if charge is not None:
                    xor_groups[varset] = {
                        "variables": sorted(varset),
                        "charge": charge,
                        "n_clauses": len(clauses),
                    }

        if len(xor_groups) < 2:
            return None  # Need at least 2 XOR groups (vertices)

        # Reconstruct graph: each variable is an edge, each XOR group is a vertex.
        # Variable v appears in exactly the groups (vertices) it is incident to.
        var_to_groups = defaultdict(list)
        for gid, (varset, info) in enumerate(xor_groups.items()):
            for var in info["variables"]:
                var_to_groups[var].append(gid)

        # Each variable (edge) should appear in exactly 2 groups (vertices)
        edge_vars = {}
        for var, gids in var_to_groups.items():
            if len(gids) == 2:
                edge_vars[var] = tuple(sorted(gids))
            # Variables appearing in 1 or >2 groups break the graph structure

        if not edge_vars:
            return None

        # Build graph
        n_vertices = len(xor_groups)
        edges = list(set(edge_vars.values()))
        n_edges = len(edges)

        # Extract charges
        group_list = list(xor_groups.values())
        charges = {i: group_list[i]["charge"] for i in range(n_vertices)}

        # Verify: each group's variables should all be valid edge variables
        valid_edge_var_set = set(edge_vars.keys())
        all_group_vars = set()
        for info in group_list:
            all_group_vars.update(info["variables"])

        coverage = len(valid_edge_var_set) / max(len(all_group_vars), 1)
        if coverage < 0.7:
            return None  # Too many non-edge variables

        return {
            "n_vertices": n_vertices,
            "n_edges": n_edges,
            "edges": edges,
            "charges": charges,
            "n_xor_groups": len(xor_groups),
            "edge_coverage": coverage,
        }

    def _decode_xor_group(self, varset, clauses):
        """Decode a group of clauses to determine if it encodes XOR.

        For XOR(x1, ..., xd) = c:
          - c=1: clauses have odd number of positive literals
          - c=0: clauses have even number of positive literals

        Returns charge (0 or 1), or None if not a valid XOR encoding.
        """
        d = len(varset)
        expected = 1 << (d - 1)

        if len(clauses) != expected:
            return None

        # Count positive literals per clause
        parities = set()
        for clause in clauses:
            n_pos = sum(1 for lit in clause if lit > 0)
            parities.add(n_pos % 2)

        # All clauses should have same parity of positive literals
        if len(parities) != 1:
            return None

        parity = parities.pop()
        # parity=1 (odd positives) means charge=0 (even parity XOR)
        # parity=0 (even positives) means charge=1 (odd parity XOR)
        return 1 - parity

    def prove_unsat(self, cnf: CNFInstance, structure: dict) -> TORCCertificate | None:
        """Prove Tseitin UNSAT via GF(2) rank obstruction."""
        n_vertices = structure["n_vertices"]
        edges = structure["edges"]
        charges = structure["charges"]

        result = detect_tseitin_obstruction(n_vertices, edges, charges)

        if not result["obstruction_detected"]:
            return None

        return TORCCertificate(
            structure="tseitin",
            parameters={
                "n_vertices": n_vertices,
                "n_edges": len(edges),
                "parity_sum": result["parity_sum"],
            },
            h1_rank=result["h1_dim"],
            obstruction_norm=float(result["parity_sum"]),
            winding_number=result["parity_sum"],
            details=result,
        )
