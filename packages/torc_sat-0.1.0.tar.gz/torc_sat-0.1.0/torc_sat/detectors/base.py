"""Abstract base class for structure detectors."""

from abc import ABC, abstractmethod
from torc_sat.parser import CNFInstance
from torc_sat.certificate import TORCCertificate


class StructureDetector(ABC):
    """Detector that recognizes a combinatorial structure in CNF."""

    name: str = "base"

    @abstractmethod
    def detect(self, cnf: CNFInstance) -> dict | None:
        """Try to recognize the structure in the CNF.

        Returns:
            dict with structure parameters if recognized, None otherwise.
        """
        ...

    @abstractmethod
    def prove_unsat(self, cnf: CNFInstance, structure: dict) -> TORCCertificate | None:
        """Apply TORC to prove UNSAT given the detected structure.

        Returns:
            TORCCertificate if UNSAT proven, None otherwise.
        """
        ...
