"""Generalized XOR/parity detector.

Detects arbitrary systems of XOR (parity) constraints in CNF,
not just Tseitin graph-structured ones. A group of 2^(d-1) clauses
on the same d variables encodes XOR(x1,...,xd) = c.

Proves UNSAT via GF(2) rank: if the linear system Ax = b has no
solution over GF(2), the formula is infeasible.
"""

from collections import defaultdict
import numpy as np
from torc_sat.detectors.base import StructureDetector
from torc_sat.parser import CNFInstance
from torc_sat.certificate import TORCCertificate
from torc_sat.topology.gf2 import gf2_rank


class XORDetector(StructureDetector):
    name = "xor"

    def detect(self, cnf: CNFInstance) -> dict | None:
        """Detect XOR constraints in CNF.

        Groups clauses by variable set. Each group of 2^(d-1) clauses
        on d variables potentially encodes a XOR constraint.
        Does NOT require graph structure (unlike Tseitin).
        """
        if not cnf.clauses:
            return None

        # Group clauses by their variable set (abs of literals)
        groups = defaultdict(list)
        for clause in cnf.clauses:
            key = frozenset(abs(lit) for lit in clause)
            groups[key].append(clause)

        # Find XOR groups
        xor_constraints = []
        covered_clauses = 0

        for varset, clauses in groups.items():
            d = len(varset)
            if d < 2:
                continue
            expected = 1 << (d - 1)  # 2^(d-1)
            if len(clauses) != expected:
                continue

            charge = self._decode_xor(varset, clauses)
            if charge is not None:
                sorted_vars = sorted(varset)
                xor_constraints.append({
                    "variables": sorted_vars,
                    "charge": charge,
                    "degree": d,
                })
                covered_clauses += len(clauses)

        if len(xor_constraints) < 2:
            return None

        # Need significant coverage
        coverage = covered_clauses / max(len(cnf.clauses), 1)
        if coverage < 0.5:
            return None

        # Collect all variables involved
        all_vars = set()
        for xc in xor_constraints:
            all_vars.update(xc["variables"])

        return {
            "n_constraints": len(xor_constraints),
            "n_variables": len(all_vars),
            "constraints": xor_constraints,
            "coverage": coverage,
        }

    def _decode_xor(self, varset, clauses):
        """Decode a group of clauses to determine if it encodes XOR.

        Returns charge (0 or 1), or None if not valid XOR encoding.
        """
        d = len(varset)
        expected = 1 << (d - 1)
        if len(clauses) != expected:
            return None

        parities = set()
        for clause in clauses:
            n_pos = sum(1 for lit in clause if lit > 0)
            parities.add(n_pos % 2)

        if len(parities) != 1:
            return None

        parity = parities.pop()
        return 1 - parity

    def prove_unsat(self, cnf: CNFInstance, structure: dict) -> TORCCertificate | None:
        """Prove XOR system UNSAT via GF(2) rank obstruction.

        Build matrix A where row i has 1s at columns for variables in
        constraint i. Build vector b of charges. If rank([A|b]) > rank(A),
        the system has no solution over GF(2).
        """
        constraints = structure["constraints"]
        all_vars = set()
        for xc in constraints:
            all_vars.update(xc["variables"])
        var_list = sorted(all_vars)
        var_idx = {v: i for i, v in enumerate(var_list)}

        n_eq = len(constraints)
        n_var = len(var_list)

        # Build A and b
        A = np.zeros((n_eq, n_var), dtype=np.uint8)
        b = np.zeros(n_eq, dtype=np.uint8)

        for i, xc in enumerate(constraints):
            for v in xc["variables"]:
                A[i, var_idx[v]] = 1
            b[i] = xc["charge"] % 2

        rank_A = gf2_rank(A)
        aug = np.column_stack([A, b.reshape(-1, 1)])
        rank_aug = gf2_rank(aug)

        if rank_aug <= rank_A:
            return None

        return TORCCertificate(
            structure="xor",
            parameters={
                "n_constraints": n_eq,
                "n_variables": n_var,
                "parity_sum": int(b.sum() % 2),
            },
            h1_rank=rank_aug - rank_A,
            obstruction_norm=float(rank_aug - rank_A),
            winding_number=int(b.sum() % 2),
            details={
                "method": "gf2_rank",
                "rank_A": rank_A,
                "rank_augmented": rank_aug,
                "n_constraints": n_eq,
                "n_variables": n_var,
            },
        )
