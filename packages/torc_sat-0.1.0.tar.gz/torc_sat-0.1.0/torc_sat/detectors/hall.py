"""Hall's theorem detector.

Detects bipartite matching/covering problems in CNF and proves
infeasibility via Hall's condition violation.

Hall's Marriage Theorem: a bipartite graph G = (L, R, E) has a
complete matching from L to R iff for every S ⊆ L, |N(S)| >= |S|.

PHP is a special case where |L| > |R|, so N(L) = R and |R| < |L|.
This detector catches the general case where |L| = |R| but some
subset S has |N(S)| < |S| (deficiency).

Also detects at-most-one constraints (AMO) which encode
"each right vertex matched to at most one left vertex".
"""

from collections import defaultdict
from torc_sat.detectors.base import StructureDetector
from torc_sat.parser import CNFInstance
from torc_sat.certificate import TORCCertificate


class HallDetector(StructureDetector):
    name = "hall"

    def detect(self, cnf: CNFInstance) -> dict | None:
        """Detect bipartite matching structure in CNF.

        Looks for:
          - "At least one" clauses: positive clauses of uniform length
            (each left vertex connected to some right vertices)
          - "At most one" clauses: binary negative clauses
            (no two left vertices share a right vertex)

        This is the same pattern as PHP but we allow non-uniform
        neighborhoods (not every left vertex connected to every right vertex).
        """
        if not cnf.clauses:
            return None

        # Separate clause types
        pos_clauses = []  # all-positive (at-least-one)
        neg_binary = []   # all-negative binary (at-most-one)
        other = []

        for clause in cnf.clauses:
            if len(clause) >= 2 and all(lit > 0 for lit in clause):
                pos_clauses.append(clause)
            elif len(clause) == 2 and all(lit < 0 for lit in clause):
                neg_binary.append(clause)
            else:
                other.append(clause)

        if not pos_clauses or not neg_binary:
            return None

        # Too many "other" clauses means this isn't a pure matching problem
        total = len(cnf.clauses)
        matching_clauses = len(pos_clauses) + len(neg_binary)
        if matching_clauses / total < 0.8:
            return None

        # Build bipartite structure
        # Each positive clause represents a left vertex
        # Variables in the clause represent edges to right vertices
        n_left = len(pos_clauses)

        # Check variable disjointness across positive clauses
        left_vars = []
        all_used = set()
        for clause in pos_clauses:
            vs = set(clause)
            if vs & all_used:
                return None  # Variables shared between left vertices
            all_used.update(vs)
            left_vars.append(vs)

        # Build var -> left_vertex mapping
        var_to_left = {}
        for i, vs in enumerate(left_vars):
            for v in vs:
                var_to_left[v] = i

        # Parse negative binary clauses to find right-vertex conflicts
        # (-x, -y) means x and y can't both be true
        # If x belongs to left_i and y to left_j, they compete for same right vertex
        right_groups = defaultdict(set)  # right_vertex -> set of left vertices
        for clause in neg_binary:
            v1, v2 = -clause[0], -clause[1]
            if v1 not in var_to_left or v2 not in var_to_left:
                continue
            l1, l2 = var_to_left[v1], var_to_left[v2]
            if l1 == l2:
                continue
            # v1 and v2 correspond to same right vertex
            # Group by the right-vertex concept
            right_groups[(min(l1, l2), max(l1, l2))].add(v1)
            right_groups[(min(l1, l2), max(l1, l2))].add(v2)

        # Reconstruct neighborhoods: for each left vertex, which right vertices
        # can it be matched to?
        # A right vertex is identified by the set of left vertices competing for it
        # We use variable identity: vars in the same position across clauses

        # Simpler: each variable in a positive clause is a potential match.
        # Binary negative (-x, -y) means x and y can't both be 1.
        # This encodes that the "slot" they represent can hold at most one.

        # Build adjacency: left_vertex -> set of right "slots"
        # Two variables are in the same slot if they appear in a negative binary clause
        var_to_slot = {}
        next_slot = 0
        for clause in neg_binary:
            v1, v2 = -clause[0], -clause[1]
            if v1 not in var_to_left or v2 not in var_to_left:
                continue
            s1 = var_to_slot.get(v1)
            s2 = var_to_slot.get(v2)
            if s1 is not None and s2 is not None:
                # Merge: both already assigned, should be same slot
                if s1 != s2:
                    # Remap all s2 to s1
                    for var, slot in var_to_slot.items():
                        if slot == s2:
                            var_to_slot[var] = s1
            elif s1 is not None:
                var_to_slot[v2] = s1
            elif s2 is not None:
                var_to_slot[v1] = s2
            else:
                var_to_slot[v1] = next_slot
                var_to_slot[v2] = next_slot
                next_slot += 1

        # Assign remaining vars to unique slots
        for vs in left_vars:
            for v in vs:
                if v not in var_to_slot:
                    var_to_slot[v] = next_slot
                    next_slot += 1

        # Build neighborhoods
        neighborhoods = []
        for i, vs in enumerate(left_vars):
            slots = set(var_to_slot[v] for v in vs)
            neighborhoods.append(slots)

        n_right = len(set(var_to_slot.values()))

        return {
            "n_left": n_left,
            "n_right": n_right,
            "neighborhoods": neighborhoods,
        }

    def prove_unsat(self, cnf: CNFInstance, structure: dict) -> TORCCertificate | None:
        """Prove matching UNSAT via Hall's condition violation.

        Find a subset S of left vertices where |N(S)| < |S|.
        Uses greedy expansion from vertices with smallest neighborhoods.
        """
        n_left = structure["n_left"]
        neighborhoods = structure["neighborhoods"]

        # Quick check: if total right < total left, trivially violated
        all_right = set()
        for n in neighborhoods:
            all_right.update(n)
        n_right = len(all_right)

        if n_right < n_left:
            return TORCCertificate(
                structure="hall",
                parameters={
                    "n_left": n_left,
                    "n_right": n_right,
                    "deficiency": n_left - n_right,
                },
                h1_rank=n_left - n_right,
                obstruction_norm=float(n_left - n_right),
                winding_number=n_left - n_right,
                details={
                    "method": "pigeonhole",
                    "witness_set": list(range(n_left)),
                    "witness_size": n_left,
                    "neighborhood_size": n_right,
                },
            )

        # Search for Hall violation: S with |N(S)| < |S|
        witness = self._find_hall_violation(n_left, neighborhoods)
        if witness is None:
            return None

        S, NS = witness
        deficiency = len(S) - len(NS)

        return TORCCertificate(
            structure="hall",
            parameters={
                "n_left": n_left,
                "n_right": n_right,
                "deficiency": deficiency,
            },
            h1_rank=deficiency,
            obstruction_norm=float(deficiency),
            winding_number=deficiency,
            details={
                "method": "hall_violation",
                "witness_set": sorted(S),
                "witness_size": len(S),
                "neighborhood_size": len(NS),
            },
        )

    def _find_hall_violation(self, n_left, neighborhoods):
        """Find S ⊆ L with |N(S)| < |S|.

        Strategy: sort vertices by neighborhood size (ascending).
        Greedily add vertices that minimize |N(S)| growth.
        """
        # Sort by neighborhood size
        order = sorted(range(n_left), key=lambda i: len(neighborhoods[i]))

        # Try greedy expansion from each starting vertex
        for start_idx in range(n_left):
            start = order[start_idx]
            S = {start}
            NS = set(neighborhoods[start])

            if len(NS) < len(S):
                return (S, NS)

            # Try adding vertices whose neighborhoods overlap maximally with NS
            remaining = [v for v in order if v != start]
            for v in remaining:
                new_ns = NS | neighborhoods[v]
                new_s_size = len(S) + 1
                if len(new_ns) < new_s_size:
                    S.add(v)
                    return (S, new_ns)
                # Add if it doesn't grow NS much
                growth = len(new_ns) - len(NS)
                if growth <= 0:
                    S.add(v)
                    NS = new_ns
                    if len(NS) < len(S):
                        return (S, NS)

        # Try all pairs for small instances
        if n_left <= 50:
            for i in range(n_left):
                for j in range(i + 1, n_left):
                    ns = neighborhoods[i] | neighborhoods[j]
                    if len(ns) < 2:
                        return ({i, j}, ns)

            # Try all triples
            if n_left <= 20:
                for i in range(n_left):
                    for j in range(i + 1, n_left):
                        for k in range(j + 1, n_left):
                            ns = neighborhoods[i] | neighborhoods[j] | neighborhoods[k]
                            if len(ns) < 3:
                                return ({i, j, k}, ns)

        return None
