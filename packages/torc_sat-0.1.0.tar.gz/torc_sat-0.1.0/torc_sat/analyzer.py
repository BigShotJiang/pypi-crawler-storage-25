"""Orchestrator: tries detectors in order and returns result."""

import time
from torc_sat.parser import CNFInstance, parse_dimacs
from torc_sat.certificate import TORCResult, Verdict
from torc_sat.detectors import ALL_DETECTORS


def check_cnf(cnf: CNFInstance) -> TORCResult:
    """Run TORC analysis on a parsed CNF instance.

    Tries each detector in order. First one that recognizes structure
    and proves UNSAT wins. If none succeed, returns UNKNOWN.
    """
    t0 = time.perf_counter()
    detectors_tried = []

    for detector_cls in ALL_DETECTORS:
        detector = detector_cls()
        detectors_tried.append(detector.name)

        structure = detector.detect(cnf)
        if structure is None:
            continue

        certificate = detector.prove_unsat(cnf, structure)
        if certificate is not None:
            elapsed = (time.perf_counter() - t0) * 1000.0
            return TORCResult(
                verdict=Verdict.UNSAT,
                certificate=certificate,
                time_ms=elapsed,
                detectors_tried=detectors_tried,
            )

    elapsed = (time.perf_counter() - t0) * 1000.0
    return TORCResult(
        verdict=Verdict.UNKNOWN,
        time_ms=elapsed,
        detectors_tried=detectors_tried,
    )


def check(path: str) -> TORCResult:
    """Run TORC analysis on a DIMACS CNF file."""
    cnf = parse_dimacs(path)
    return check_cnf(cnf)
