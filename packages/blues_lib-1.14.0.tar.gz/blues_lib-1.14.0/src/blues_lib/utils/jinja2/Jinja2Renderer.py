from jinja2 import Environment,  Template
from blues_lib.types import VAR_LEVEL
import re
import json

class Jinja2Renderer:
  '''
  提供直接的Jinja2渲染功能，只处理直接字符串模板
  '''
  
  @classmethod
  def _render_str(cls, template:str, data:dict, env:Environment, level:VAR_LEVEL = 'global')->any:
    '''
    渲染Jinja2模板字符串
    Args:
      template {str} : Jinja2模板字符串
      data {dict} : 渲染数据
      env {any} : Jinja2环境实例
      level {VAR_LEVEL} : 变量替换级别
        - global : 初始化全局替换 - 占位符为 {{ var }}
        - task : 任务初始化替换 {( var )}
        - loop : 循环体内替换 {[ var ]}
    Returns:
      any: 渲染后的结果，如果模板只是一个占位符，返回原始类型；否则返回字符串
    '''
    if cls._is_single_placeholder(template, level):
      return cls._extract_raw_value(template, data, level)
    
    tpl = env.from_string(template)
    return tpl.render(data)
  
  @classmethod
  def render(cls, template:any, data:dict, level:VAR_LEVEL = 'global', excludes:list[str] = None)->any:
    '''
    渲染任意类型的模板数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      data {dict} : 渲染数据
      level {VAR_LEVEL} : 变量替换级别
        - global : 初始化全局替换 - 占位符为 {{ var }}
        - task : 任务初始化替换 {( var )}
        - loop : 循环体内替换 {[ var ]}
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    Note:
      当模板是字典或列表时，会返回一个新的字典或列表，而不会修改原始值
    '''
    # 创建环境实例，在一次render调用中只创建一次
    env = cls._get_environment(level)
    excludes = excludes or []
    
    def _render_recursive(item:any, key:str = None)->any:
      if key and key in excludes:
        return item
      if isinstance(item, str):
        return cls._render_str(item, data, env, level)
      elif isinstance(item, dict):
        return {k: _render_recursive(v, k) for k, v in item.items()}
      elif isinstance(item, list):
        return [_render_recursive(element) for element in item]
      else:
        return item
    
    return _render_recursive(template)
  
  @classmethod
  def render_global(cls, template:any, data:dict, excludes:list[str] = None)->any:
    '''
    渲染global level的模板数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      data {dict} : 渲染数据
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    '''
    return cls.render(template, data, level='global', excludes=excludes)
  
  @classmethod
  def render_task(cls, template:any, data:dict, excludes:list[str] = None)->any:
    '''
    渲染task level的模板数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      data {dict} : 渲染数据
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    '''
    return cls.render(template, data, level='task', excludes=excludes)
  
  @classmethod
  def render_loop(cls, template:any, data:dict, excludes:list[str] = None)->any:
    '''
    渲染loop level的模板数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      data {dict} : 渲染数据
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    '''
    default_excludes = ["tools", "type_tools"]
    if excludes:
      default_excludes.extend(excludes)
    return cls.render(template, data, level='loop', excludes=default_excludes)
  
  @classmethod
  def render_by_self(cls, template:any, level:VAR_LEVEL = 'global', excludes:list[str] = None)->any:
    '''
    渲染模板数据，使用模板本身作为数据
    Args:
      template {any} : 模板数据，可以是字符串、字典、列表或其他类型
      level {VAR_LEVEL} : 变量替换级别
        - global : 初始化全局替换 - 占位符为 {{ var }}
        - task : 任务初始化替换 {( var )}
        - loop : 循环体内替换 {[ var ]}
      excludes {list[str]} : 递归处理时需要直接跳过的属性节点
    Returns:
      any: 渲染后的结果
    Note:
      当模板是字典或列表时，会返回一个新的字典或列表，而不会修改原始值
    '''
    return cls.render(template, template, level, excludes)
  
  @classmethod
  def _is_single_placeholder(cls, template:str, level:VAR_LEVEL)->bool:
    '''
    判断模板是否只是一个占位符
    Args:
      template {str} : Jinja2模板字符串
      level {VAR_LEVEL} : 变量替换级别
    Returns:
      bool: 如果模板只是一个占位符，返回True；否则返回False
    '''
    if level == 'task':
      pattern = r'^\{\(\s*.+\s*\)\}$'
    elif level == 'loop':
      pattern = r'^\{\[\s*.+\s*\]\}$'
    else:
      pattern = r'^\{\{\s*.+\s*\}\}$'
    
    return bool(re.match(pattern, template.strip()))
  
  @classmethod
  def _extract_raw_value(cls, template:str, data:dict, level:VAR_LEVEL)->any:
    '''
    提取占位符中的原始值
    Args:
      template {str} : Jinja2模板字符串
      data {dict} : 渲染数据
      level {VAR_LEVEL} : 变量替换级别
    Returns:
      any: 提取的原始值
    '''
    # 移除占位符的开始和结束标记
    if level == 'task':
      expr = template.strip().strip('{( )}')
    elif level == 'loop':
      expr = template.strip().strip('{[ ]}')
    else:
      expr = template.strip().strip('{{ }}')
    
    expr = expr.strip()
    
    # 检查是否只有变量名（没有过滤器也不是表达式）
    # 匹配Python合法变量名和嵌套属性访问（如 var 或 var.attr 或 var.attr.attr）
    variable_pattern = r'^[a-zA-Z_][a-zA-Z0-9_]*(\.[a-zA-Z_][a-zA-Z0-9_]*)*$'
    if re.match(variable_pattern, expr):
      # 尝试直接获取原始值
      value = cls._get_raw_variable_value(expr, data)
      return value
    
    # 有默认值或表达式，先渲染
    tpl = Template(f'{{{{ {expr} }}}}')
    rendered_value = tpl.render(data)
    
    # 尝试转换为None，布尔值，数字
    return cls._convert_to_primitive(rendered_value)
  
  @classmethod
  def _get_raw_variable_value(cls, expr:str, data:dict)->any:
    '''
    获取变量的原始值
    Args:
      expr {str} : 变量表达式
      data {dict} : 渲染数据
    Returns:
      any: 变量的原始值，如果不存在返回None
    '''
    parts = expr.split('.')
    value = data
    for part in parts:
      if isinstance(value, dict) and part in value:
        value = value[part]
      else:
        return None
    return value
  
  @classmethod
  def _convert_to_primitive(cls, value:str)->any:
    '''
    将字符串转换为原始类型
    Args:
      value {str} : 要转换的字符串
    Returns:
      any: 转换后的原始类型
    '''
    # 尝试转换为None
    if value.lower() == 'none' or value.strip() == 'null':
      return None
    
    # 尝试转换为布尔值
    if value.lower() == 'true':
      return True
    if value.lower() == 'false':
      return False
    
    # 尝试转换为数字
    try:
      if '.' in value:
        return float(value)
      else:
        return int(value)
    except ValueError:
      pass
    
    # 尝试转换为JSON（列表或字典）
    stripped_value = value.strip()
    if ((stripped_value.startswith('[') and stripped_value.endswith(']'))) or \
       ((stripped_value.startswith('{') and stripped_value.endswith('}'))):
      # 尝试使用json.loads转换（支持双引号）
      try:
        return json.loads(value)
      except json.JSONDecodeError:
        # 尝试使用ast.literal_eval转换（支持单引号）
        try:
          import ast
          return ast.literal_eval(value)
        except (SyntaxError, ValueError):
          pass
    
    # 其他情况返回字符串
    return value
  
  @classmethod
  def _get_environment(cls, level:VAR_LEVEL)->Environment:
    '''
    根据level获取对应的Environment实例
    Args:
      level {VAR_LEVEL} : 变量替换级别
    Returns:
      Environment: 配置好的Environment实例
    '''
    if level == 'task':
      return Environment(
        variable_start_string='{(',
        variable_end_string=')}'
      )
    elif level == 'loop':
      return Environment(
        variable_start_string='{[',
        variable_end_string=']}'
      )
    else:
      return Environment()
  