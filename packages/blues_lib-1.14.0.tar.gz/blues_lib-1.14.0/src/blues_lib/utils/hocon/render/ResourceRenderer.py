from typing import Any
from blues_lib.resources.ResourceManager import ResourceManager
from blues_lib.utils.hocon.render.BaseRenderer import BaseRenderer
from blues_lib.utils.url.URIManager import URIManager

class ResourceRenderer(BaseRenderer):

  def __init__(self,resource:dict|str):
    super().__init__(resource)
    self._template = self._render_str_node(resource) if isinstance(resource, str) else resource

  def _render_str_node(self, value:str)->str:
    #  如果是字符串则必须是uri
    if URIManager.is_uri(value):
      node_data:Any= ResourceManager.read(value)
      return self._render_node(node_data)
    return value
