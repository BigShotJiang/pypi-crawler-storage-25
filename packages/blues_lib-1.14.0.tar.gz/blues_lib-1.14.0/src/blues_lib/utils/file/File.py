import os,time
from datetime import datetime,timedelta
from pathlib import Path

class File():

  @classmethod
  def get_home(cls)->str:
    return str(Path.home())
 
  @classmethod
  def get_blues_home(cls)->str:
    home:str = cls.get_home()
    dir_path:str = os.path.join(home,'.blues')
    return cls.makedirs(dir_path)
 
  @classmethod
  def get_blues_cft_home(cls)->str:
    # 此目录 存放chrome cft资源
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'cft')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_download_home(cls)->str:
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'download')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_cache_home(cls)->str:
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'cache')
    return cls.makedirs(dir_path)
 
  @classmethod
  def get_blues_temp_home(cls)->str:
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'temp')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_file_home(cls)->str:
    blues_home:str = cls.get_blues_home()
    dir_path:str = os.path.join(blues_home,'file')
    return cls.makedirs(dir_path)

  @classmethod
  def get_blues_dir_path(cls,subdir:str|list[str]=''):
    '''
    Get the blues lib's standard dir path
    Parameter:
      subdir {None|str|list} : the sub dirs
        None: return the root dir
        str: return the subdir
        list: return the multi subdir
    '''
    blues_home:str = cls.get_blues_home()
    if not subdir:
      dirs = []

    dirs = subdir if type(subdir)==list else [subdir]
    # support multi level dirs
    dir_path = os.path.join(blues_home,*dirs)

    # create dir
    cls.makedirs(dir_path)
    return dir_path 

  @classmethod
  def get_blues_file_path(cls,subdir,filename,extension='txt'):
    '''
    Get the file absolute path base the blues lib root dir
    Support add subdirs
    Parameter:
      subdir {str,list} : one or multi level dirs
      filename {str} : the filename
    '''
    dir_path = cls.get_blues_dir_path(subdir)
    filename = '%s.%s' % (filename,extension) if extension else filename
    return os.path.join(dir_path,filename)

  @classmethod
  def get_file_name(cls,prefix='',name='',suffix='',extension=''):
    file_name = name if name else int(time.time()*1000)
    if prefix:
      file_name='%s-%s' % (prefix,file_name)
    if suffix:
      file_name='%s-%s' % (file_name,suffix)
    if extension:
      file_name='%s.%s' % (file_name,extension)
    return file_name 

  @classmethod
  def get_abs_path(cls,root_dir:str,path:str)->str:
    cur_path = os.path.realpath(__file__)
    root_path = os.path.join(cur_path.split(root_dir)[0],root_dir)
    return os.path.join(root_path,path)

  @classmethod
  def exists(cls,path)->bool:
    '''
    @description : Does a dir or file exist
    @param {str} path
    @returns {bool} 
    '''
    return os.path.exists(path)

  @classmethod
  def is_dir_empty(cls,dir_path)->bool:
    return not bool(os.listdir(dir_path))

  @classmethod
  def filter_exists(cls,files)->list[str]:
    exists_files = []
    for file in files:
      if not cls.exists(file):
        continue
      exists_files.append(file)
    return exists_files

  @classmethod
  def makedirs(cls,dir_path)->str:
    '''
    @description : Create dirs (support multilevel directory) if they don't exist
    @param {str} dir_path : multilevel dir
    @returns {None}
    '''
    if not cls.exists(dir_path):
      os.makedirs(dir_path)
    return dir_path

  @classmethod
  def removedirs(cls,directory,retention_days=0):
    '''
    @description Remove all child dir and files
    @param {string} directory 
    '''
    threshold = datetime.now() - timedelta(days=retention_days)
    removed_count = 0
    if not cls.exists(directory):
      return removed_count

    for root, dirs, files in os.walk(directory):
      for file in files:
        file_path = os.path.join(root, file)
        file_modified_time = datetime.fromtimestamp(os.path.getmtime(file_path))
        if file_modified_time < threshold:
          os.remove(file_path)
          removed_count +=1
      for dire in dirs:
        dir_path = os.path.join(root, dire)
        file_modified_time = datetime.fromtimestamp(os.path.getmtime(dir_path))
        if file_modified_time < threshold:
          # recursion to remove the dir
          removed_count += cls.removedirs(dir_path,retention_days)
    # remove the base dir
    if cls.is_dir_empty(directory):
      os.rmdir(directory)
      removed_count +=1
    return removed_count

  @classmethod
  def removefiles(cls,dir_path:str,retention_days=0):
    '''
    @description : clear files before n days
    @param {str} directory
    @param {int} retention_days : default 7
    @returns {int} deleted files count
    '''
    # 转换天数到时间间隔
    threshold = datetime.now() - timedelta(days=retention_days)
    removed_count = 0
    # 遍历目录
    for item in os.scandir(dir_path):
      try:
        # 获取文件的最后修改时间
        file_modified_time = datetime.fromtimestamp(os.path.getmtime(item.path))
        # 如果文件的最后修改时间早于阈值，则删除文件
        if os.path.isfile(item.path) and file_modified_time < threshold:
          os.remove(item.path)
          removed_count +=1
      except OSError as e:
        pass

    return removed_count

  @classmethod
  def readfiles(cls,dir_path:str)->list[str]:
    '''
    Read the file list in a dir, don't support the next dirs
    @param {string} directory 
    '''
    file_list = []
    for root, dirs, files in os.walk(dir_path):
      for file in files:
        file_list.append(os.path.join(root, file))
    return file_list



