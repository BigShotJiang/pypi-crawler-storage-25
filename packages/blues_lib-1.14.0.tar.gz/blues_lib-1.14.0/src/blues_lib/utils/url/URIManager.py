from urllib.parse import urlparse, parse_qs, urlunparse, urlencode
import re

class URIManager:
  """
  URI utility class following RFC 3986 specification
  Provides URI validation, parsing and joining functionalities
  Adapted for MCP (Model Context Protocol) custom protocol scenarios
  """
  
  # RFC 3986 compliant scheme pattern: starts with letter, contains letters/numbers/+-_.
  _SCHEME_PATTERN = re.compile(r"^[a-zA-Z][a-zA-Z0-9\+\-\.]*$")
  _URI_PATTERN = re.compile(r"^[a-zA-Z][a-zA-Z0-9\+\-\.]*://.*$")
  _HTTP_PATTERN = re.compile(r"^http[s]?://.*$")

  @classmethod
  def is_uri(cls, uri: str) -> bool:
    if cls._HTTP_PATTERN.match(uri):
      return False

    return bool(cls._URI_PATTERN.match(uri))

  @classmethod
  def validate(cls, uri: str) -> bool:
    """
    Validate if URI format is legal (follows RFC 3986 core rules)
    :param uri: URI string to validate
    :return: True if valid, False otherwise
    """
    # Reject empty/non-string values
    if not isinstance(uri, str) or len(uri.strip()) == 0:
      return False

    # Parse URI to structured object
    parsed = urlparse(uri.strip())
    
    # Core rule 1: Must contain scheme with colon separator
    if not parsed.scheme or uri.find(f"{parsed.scheme}:") != 0:
      return False
    
    # Core rule 2: Scheme must comply with RFC 3986 format
    if not cls._SCHEME_PATTERN.match(parsed.scheme):
      return False
    
    # Optional rule: URI must have at least scheme + path/host (avoid empty "xxx:")
    if not parsed.netloc and not parsed.path:
      return False
    
    return True

  @classmethod
  def parse(cls, uri: str) -> dict:
    """
    Parse URI into structured dictionary with all core components
    :param uri: URI string to parse
    :return: Dictionary containing all URI components
    :raises ValueError: If URI format is invalid
    """
    # Validate before parsing
    if not cls.validate(uri):
      raise ValueError(f"Invalid URI format, cannot parse: {uri}")
    
    parsed = urlparse(uri.strip())
    
    # Build core parsing result (covers all RFC 3986 components)
    parse_result = {
      # Basic fields (native urlparse fields)
      "scheme": parsed.scheme,       # Protocol (e.g. calendar/file/trips)
      "netloc": parsed.netloc,       # Authority (user:pass@host:port)
      "path": parsed.path,           # Path (e.g. /events/2024)
      "params": parsed.params,       # Path parameters (rarely used)
      "query": parsed.query,         # Query string (e.g. year=2024&month=1)
      "fragment": parsed.fragment,   # Fragment/anchor (e.g. jan)
      # Split fields from netloc
      "username": parsed.username,   # Username (e.g. user)
      "password": parsed.password,   # Password (e.g. pass)
      "hostname": parsed.hostname,   # Hostname (e.g. example.com)
      "port": parsed.port,           # Port (e.g. 8080, int type)
      # Parsed query parameters (two formats: raw list/simplified single value)
      "query_dict": parse_qs(parsed.query),  # Raw format: {"year": ["2024"]}
      "query_simple": {k: v[0] for k, v in parse_qs(parsed.query).items()}  # Simplified: {"year": "2024"}
    }
    
    return parse_result

  @classmethod
  def join(cls, segments: dict) -> str:
    """
    Join dictionary components into a valid URI string
    :param segments: Dictionary containing URI components with supported keys:
                     scheme/netloc/path/params/query/query_simple/fragment
    :return: Joined URI string
    :raises ValueError: If required fields missing or invalid format
    """
    # Validate required scheme field
    scheme = segments.get("scheme", "").strip()
    if not scheme or not cls._SCHEME_PATTERN.match(scheme):
      raise ValueError(f"Invalid scheme value: {scheme} (must comply with RFC 3986)")
    
    # Handle query parameters (prioritize query_simple over raw query string)
    query = segments.get("query", "").strip()
    if "query_simple" in segments and isinstance(segments["query_simple"], dict):
      query = urlencode(segments["query_simple"])
    
    # Extract components (default to empty string)
    netloc = segments.get("netloc", "").strip()
    path = segments.get("path", "").strip()
    params = segments.get("params", "").strip()
    fragment = segments.get("fragment", "").strip()
    
    # Create tuple in urlunparse required order
    uri_tuple = (scheme, netloc, path, params, query, fragment)
    
    # Join into URI string
    uri = urlunparse(uri_tuple)
    
    # Final validation to ensure legal format
    if not cls.validate(uri):
      raise ValueError(f"Joined URI has invalid format: {uri}")
    
    return uri