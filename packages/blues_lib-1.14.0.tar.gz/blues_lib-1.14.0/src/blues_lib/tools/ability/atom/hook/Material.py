from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.supports.dp.output.STDOut import STDOut
from blues_lib.services.material.chain.MatPreprocessor import MatPreprocessor
from blues_lib.types import MatChainRule,MatChainRequest

class Material(BaseAbility): 

  def preprocess_mat(self,opts:dict)->list[dict]: 
    entities:list[dict] = opts.get('value',{})
    rule:MatChainRule = opts.get('extra',{})

    if not entities or not rule:
      self._logger.warning(f'{self.__class__.__name__} :  entities or rule is None')
      return entities

    request:MatChainRequest = {
      'entities':entities,
      'rule':rule,
    }
    handler = MatPreprocessor(request)
    output:STDOut = handler.handle()
    if output.code!=200:
      raise ValueError(f'{self.__class__.__name__} : material chain error {output.message}')
    return output.data
 