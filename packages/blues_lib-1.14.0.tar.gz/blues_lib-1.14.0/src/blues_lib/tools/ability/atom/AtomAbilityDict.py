from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility

from blues_lib.tools.ability.atom.webdriver.DriverAbilityDict import DriverAbilityDict
from blues_lib.tools.ability.atom.matcher.MatcherAbilityDict import MatcherAbilityDict
from blues_lib.tools.ability.atom.tool.ToolAbilityDict import ToolAbilityDict
from blues_lib.tools.ability.atom.llm.LLMAbilityDict import LLMAbilityDict
from blues_lib.tools.ability.atom.sql.SQLAbilityDict import SQLAbilityDict
from blues_lib.tools.ability.atom.cleanup.CleanupAbilityDict import CleanupAbilityDict
from blues_lib.tools.ability.atom.hook.HookAbilityDict import HookAbilityDict
from blues_lib.tools.ability.atom.script.ScriptAbilityDict import ScriptAbilityDict

class AtomAbilityDict:
  """
  All atom ability class's dict
  """

  @classmethod
  def get(cls,driver:WebDriver|None) -> dict[str,BaseAbility]:
    generic_insts = {
      **ToolAbilityDict.get(),
      **LLMAbilityDict.get(),
      **SQLAbilityDict.get(),
      **CleanupAbilityDict.get(),
      **HookAbilityDict.get(),
      **ScriptAbilityDict.get(),
    }
    driver_insts = {
      **DriverAbilityDict.get(driver),
      **MatcherAbilityDict.get(driver),
    }
    return {**generic_insts,**driver_insts}
