from typing import Any,Callable
from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.tools.ability.atom.DynamicFacade import DynamicFacade
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.ability.atom.AtomAbilityDict import AtomAbilityDict
from blues_lib.supports.decorator import AtomPrevHook,AtomPostHook

class AtomFacade(DynamicFacade):
  
  def __init__(self,driver:WebDriver|None = None) -> None:
    self._driver = driver
    super().__init__()
    
  def _get_class_instances(self) -> dict[str,BaseAbility]:
    return AtomAbilityDict.get(self._driver)
  
  @AtomPrevHook()
  @AtomPostHook()
  def _exec(self,method:Callable,*args,**kwargs)->Any:
    return method(*args,**kwargs)