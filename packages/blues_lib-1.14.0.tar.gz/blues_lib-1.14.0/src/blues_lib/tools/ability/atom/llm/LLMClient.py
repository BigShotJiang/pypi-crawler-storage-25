from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.services.llm.BaseLLMClient import BaseLLMClient
from blues_lib.services.llm.StandardLLMClient import StandardLLMClient
from blues_lib.services.llm.JSONLLMClient import JSONLLMClient
from blues_lib.types import LLMBaseReqOpts,LLMSTDReqOpts

class LLMClient(BaseAbility):

  def base_llm_request(self,options:LLMBaseReqOpts)->dict:
    client = BaseLLMClient(options)
    return client.request()

  def standard_llm_request(self,options:LLMSTDReqOpts)->str:
    client = StandardLLMClient(options)
    return client.request()
  
  def json_llm_request(self,options:LLMSTDReqOpts)->list|dict:
    client = JSONLLMClient(options)
    return client.request()