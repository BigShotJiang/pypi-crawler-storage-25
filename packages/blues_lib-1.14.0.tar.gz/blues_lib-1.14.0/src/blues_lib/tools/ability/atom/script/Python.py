from typing import Any
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.utils.script.PythonExecutor import PythonExecutor
from blues_lib.types import ToolDef

class Python(BaseAbility):
  
  def python_lambda(self,options:dict[str,Any]):
    ability_def:ToolDef = {
      'name':'lambda',
      'options':options
    }
    return PythonExecutor.execute(ability_def)

  def python_function(self,options:dict[str,Any]):
    ability_def:ToolDef = {
      'name':'function',
      'options':options
    }
    return PythonExecutor.execute(ability_def)

  def python_file(self,options:dict[str,Any]):
    ability_def:ToolDef = {
      'name':'file',
      'options':options
    }
    return PythonExecutor.execute(ability_def)
