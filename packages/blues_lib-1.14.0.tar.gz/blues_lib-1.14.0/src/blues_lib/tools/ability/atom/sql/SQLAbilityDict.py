from blues_lib.tools.ability.atom.sql.Querier import Querier
from blues_lib.tools.ability.atom.sql.Inserter import Inserter
from blues_lib.tools.ability.atom.sql.Updater import Updater
from blues_lib.tools.ability.atom.sql.Deleter import Deleter

class SQLAbilityDict():

  @classmethod
  def get(cls)->dict:
    return {
      Querier.__name__:Querier(),
      Inserter.__name__:Inserter(),
      Updater.__name__:Updater(),
      Deleter.__name__:Deleter(),
    }