import re
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.matcher.MatcherAbility import MatcherAbility


class ElementTextMatcher(MatcherAbility):

  def element_text_to_equal(self,options:dict)->bool:
    value:str = self._get_element_text(options)
    expected:str = str(options.get('expected')).strip()
    return value==expected

  def element_text_to_match(self,options:dict)->bool:
    value:str = self._get_element_text(options)
    expected:str = str(options.get('expected')).strip()
    return bool(re.search(expected,value))
  
  def _get_element_text(self,options:dict)->str:
    elem:WebElement|None = self._facade.execute('query_element',options)
    return elem.text.strip() if elem else ''
