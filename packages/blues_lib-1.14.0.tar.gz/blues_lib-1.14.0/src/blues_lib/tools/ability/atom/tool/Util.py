from blues_lib.tools.ability.atom.BaseAbility import BaseAbility

from blues_lib.utils.datetime.DateTimeManager import DateTimeManager

class Util(BaseAbility):
  
  def sleep(self,options:dict)->bool:
    value:float|int = float(options.get('value') or 0)
    title:str = options.get('title') or f'Sleep {value} seconds'
    if value>0:
      DateTimeManager.count_down({
        "duration":value,
        "title":title,
      })
    return True