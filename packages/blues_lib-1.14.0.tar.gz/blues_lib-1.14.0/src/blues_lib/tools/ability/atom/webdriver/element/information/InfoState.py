from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.webdriver.element.information.InfoBase import InfoBase


class InfoState(InfoBase):

  def is_present(self,options:dict)->bool:
    '''
    Check if connected Element is in document
    Args:
      options (dict) : element query options
    Returns:
      bool : return True if element is presence, otherwise False
    '''
    return True if self._querier.query_element(options) else False

  def is_displayed(self,options:dict)->bool:
    '''
    Check if connected Element is displayed on a webpage
      - not defined by w3c specification
      - relies on executing a large JavaScript function directly
    Args:
      options (dict) : element query options
    Returns:
      bool : return True if element is displayed, otherwise False
    '''
    elem:WebElement|None = self._querier.query_element(options)
    return elem.is_displayed() if elem else False

  def is_enabled(self,options:dict)->bool:
    '''
    If connected Element is enabled or disabled on a webpage
    Args:
      options (dict) : element query options
    Returns:
      bool : return True if element is enabled, otherwise False
    '''
    elem:WebElement|None = self._querier.query_element(options)
    return elem.is_enabled() if elem else False

  def is_selected(self,options:dict)->bool:
    '''
    Check if connected Element is selected or not, widely used on:
      1. check box
      2. radio box
      3. input element
      4. option element
    Args:
      options (dict) : element query options
    Returns:
      bool : return True if element is selected, otherwise False
    '''
    elem:WebElement|None = self._querier.query_element(options)
    return elem.is_selected() if elem else False
