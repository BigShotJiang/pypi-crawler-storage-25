from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.webdriver.element.information.InfoState import InfoState
from blues_lib.tools.ability.atom.webdriver.element.information.InfoRect import InfoRect
from blues_lib.tools.ability.atom.webdriver.element.information.InfoAttr import InfoAttr


class Information(InfoState,InfoRect,InfoAttr):
  """
  Information class to get element information.
  Reference : https://www.selenium.dev/documentation/webdriver/elements/information/
  """  
  def get_kind_mat(self,options:dict)->dict[str,list[str]]:
    texts:list[str] = self.get_texts(options)

    image_options = {
      **options,
      'target':'img',
      'root':options['target'],
    }
    images:list[str] = self.get_srcs(image_options) or []
    return {
      'text':texts,
      'image':images,
    }

  def get_type_mat(self,options:dict)->list[dict[str,str]]:
    result:dict = self.get_texts_and_images(options)
    paras:list[dict[str,str]] = []
    
    texts:list[str] = result['text']
    images:list[str] = result['image']
    
    if texts:
      for text in texts:
        paras.append({
          'type':'text',
          'value':text,
        })
    if images:
      for image in images:
        paras.append({
          'type':'image',
          'value':image,
        })
    return paras