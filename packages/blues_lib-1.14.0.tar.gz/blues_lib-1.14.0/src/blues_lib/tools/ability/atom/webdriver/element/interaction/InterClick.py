from typing import Any
import json
import pyperclip
import time
from selenium.webdriver.remote.webelement import WebElement

from blues_lib.tools.ability.atom.webdriver.element.interaction.InterBase import InterBase
from blues_lib.utils.file.FileWriter import FileWriter

class InterClick(InterBase):

  def click(self,options:dict)->bool:
    '''
    Click and release
    Args:
      options (dict, optional): The options for clicking element. Defaults to None.
    Returns:
      bool
    '''
    elem:WebElement|None = self._querier.query_element(options)     
    if not elem:
      return False
    
    # can't deal with elemen's parent's invisible
    self._javascript.display_and_scroll_into_view({**options,'target':elem})
    elem.click()
    return True

  
  def click_and_copy(self,options:dict)->str:
    '''
    Click a button and copy text to clipboard
    Args:
      options (dict): javascript options
    Returns:
      str : copied content
    '''
    text:str = self._get_text(options)
    if not text:
      return ''

    if max_length:= int(options.get('max_length') or -1):
      text_len:int = len(text)
      if max_length>0 and text_len > max_length:
        text = text[:max_length]+'...'

    if save_path:= options.get('save_path',''):
      return FileWriter.write_text(save_path,text)
    else:
      return text
  
  def click_and_copy_json(self,options:dict)->Any:
    '''
    Click a button and copy JSON text to clipboard
    Args:
      options (dict): javascript options
    Returns:
      Any : parsed JSON object or empty string if parsing fails
    '''
    text:str = self._get_text(options)
    if not text:
      return ''

    try:
      content = json.loads(text)
      if save_path:= options.get('save_path',''):
        return FileWriter.write_json(save_path,content)
      else:
        return content
    except json.JSONDecodeError:
      self._logger.error(f"Failed to parse JSON from clipboard text: {text}")
      return ''
    
  def _get_text(self,options:dict)->str:
    success:bool = self.click(options)
    if not success:
      return ''

    time.sleep(0.2)
    # get the text from the clipboard
    return pyperclip.paste()
