from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.matcher.MatcherAbility import MatcherAbility


class ElementCountMatcher(MatcherAbility):

  def element_count_to_be_equal(self,options:dict)->bool:
    value:int = self._get_element_count(options)
    expected:int = int(options.get('expected'))
    return value==expected

  def element_count_to_be_greater_than(self,options:dict)->bool:
    value:int = self._get_element_count(options)
    expected:int = int(options.get('expected'))
    return value>expected

  def element_count_to_be_less_than(self,options:dict)->bool:
    value:int = self._get_element_count(options)
    expected:int = int(options.get('expected'))
    return value<expected
  
  def _get_element_count(self,options:dict)->int:
    elems:list[WebElement]|None = self._facade.execute('query_elements',options)
    return len(elems) if elems else 0
