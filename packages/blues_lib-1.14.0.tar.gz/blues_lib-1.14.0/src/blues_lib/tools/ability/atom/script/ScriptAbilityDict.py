from blues_lib.tools.ability.atom.script.Python import Python

class ScriptAbilityDict():

  @classmethod
  def get(cls)->dict:
    return {
      Python.__name__:Python(),
    }