from typing import Any
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility


class Dummy(BaseAbility):
  
  def print_data(self,options:dict)->Any:
    value:Any = options.get("value")
    self._logger.info(f'{self.__class__.__name__}: {value}')
    return value

  def pass_data(self,options:dict)->Any:
    return options.get('value')
