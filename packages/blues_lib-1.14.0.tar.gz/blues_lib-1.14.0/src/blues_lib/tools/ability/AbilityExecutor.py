import logging
from typing import Any
from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.tools.ability.AbilityFacade import AbilityFacade
from blues_lib.types import SeqOpts,ToolDef,ToolDef

class AbilityExecutor:
  # execute a tool/seq ability list or dict
  
  def __init__(self,driver:WebDriver|None=None)->None:
    self._driver = driver
    self._facade = AbilityFacade(driver)
    self._logger = logging.getLogger('airflow.task')
  
  def execute(self,tools:list[ToolDef]|dict[str,ToolDef])->list[Any]|dict[str,Any]:
    # render by dynamic variables (in loop)
    results:list[Any]|dict[str,Any] = []    
    if isinstance(tools,dict):
      results = self._exec_by_dict(tools)
    elif isinstance(tools,list):
      results = self._exec_by_list(tools)
    return results
 
  def _exec_by_dict(self,tools:dict[str,ToolDef])->dict[str,Any]:
    results:dict[str,Any] = {}
    for key,tool in tools.items():
      results[key] = self._exec_once(tool)
    return results

  def _exec_by_list(self,tools:list[ToolDef])->list[Any]:
    results:list[Any] = []
    for tool in tools:
      results.append(self._exec_once(tool))
    return results
  
  def _exec_once(self,tool:ToolDef)->Any:
    name:str = tool.get('name') or 'undefined'
    options:dict|SeqOpts = tool.get('options')
    args:list[Any] = [name,options] if options else [name]
    return self._facade.execute(*args)
