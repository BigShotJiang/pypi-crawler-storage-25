from typing import Any
from selenium.webdriver.chrome.webdriver import WebDriver
from blues_lib.tools.ability.atom.AtomFacade import AtomFacade
from blues_lib.tools.ability.sequence.SeqFacade import SeqFacade

class AbilityFacade():
  
  def __init__(self,driver:WebDriver|None = None) -> None:
    self._atom_facade = AtomFacade(driver)
    self._seq_facade = SeqFacade(driver)
    
  def execute(self,method:str, *args, **kwargs) -> Any:
    """
    execute the method in the facade
    Args:
      method (str): the method name
      args (Any): the method args
      kwargs (Any): the method kwargs
    Returns:
      Any: the method return
    """
    if self._atom_facade.has(method):
      return self._atom_facade.execute(method, *args, **kwargs)
    if self._seq_facade.has(method):
      return self._seq_facade.execute(method, *args, **kwargs)
    raise ValueError(f'Unknown method: {method}')
