from typing import Any
from selenium.webdriver.chrome.webdriver import WebDriver 
from blues_lib.types import SeqOpts,AttemptBy
from blues_lib.tools.ability.sequence.cast.BaseSeq import BaseSeq
from blues_lib.tools.ability.sequence.cast.SingleSeq import SingleSeq
from blues_lib.tools.ability.sequence.cast.LoopSeq import LoopSeq

class PageSeq(BaseSeq):

  _SEQ_NAME = 'page'

  def __init__(self,driver:WebDriver):
    super().__init__(driver)
    self._loop_seq = LoopSeq(driver)
    self._single_seq = SingleSeq(driver)

  def cast_page(self,options:SeqOpts)->list[list|dict]:
    return self._execute(options)

  def _cast_tools(self)->list[list|dict]:
    
    attempts:int = int(self._tool_summary.get('attempts') or -1)
    attempt_by:AttemptBy = self._tool_summary.get('attempt_by') # ['number','loc'] or ['next','loc']

    # 至少执行一次
    totals:list[list|dict] = self._cast_single()
    idx:int = 1

    while True:

      # 因为默认已执行一次，在开始前delay
      self._iter_helper.delay(self._tool_summary)
      if attempts>0 and idx>=attempts:
        break

      has_next:bool = self._iter_helper.next_page(attempt_by,idx)
      if not has_next:
        break

      idx+=1
      totals += self._cast_single()
    return totals

  def _cast_single(self)->list[list|dict]:
    # loop and single seq cannot have page property
    child_seq_opts = {**self._seq_opts}
    del child_seq_opts['page']

    if child_seq_opts.get('loop'):
      return self._loop_seq.cast_loop(child_seq_opts)
    else:
      # single seq do not have loop property
      del child_seq_opts['loop']
      del child_seq_opts['type_tools']
      result:list|dict|None = self._single_seq.cast(child_seq_opts)
      return [result] if result else []
