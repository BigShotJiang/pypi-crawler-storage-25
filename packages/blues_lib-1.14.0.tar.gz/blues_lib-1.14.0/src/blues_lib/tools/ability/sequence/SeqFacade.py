from typing import Any,Callable
from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.tools.ability.atom.DynamicFacade import DynamicFacade
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.ability.sequence.SeqAbilityDict import SeqAbilityDict
from blues_lib.supports.decorator import SeqPrevHook,SeqPostHook

class SeqFacade(DynamicFacade):
  
  def __init__(self,driver:WebDriver|None = None) -> None:
    self._driver = driver
    super().__init__()
    
  def _get_class_instances(self) -> dict[str,BaseAbility]:
    return SeqAbilityDict.get(self._driver)

  @SeqPrevHook()
  @SeqPostHook()
  def _exec(self,method:Callable,*args,**kwargs)->Any:
    return method(*args,**kwargs)