from selenium.webdriver.remote.webdriver import WebDriver

from blues_lib.tools.ability.sequence.cast.SingleSeq import SingleSeq
from blues_lib.tools.ability.sequence.cast.LoopSeq import LoopSeq
from blues_lib.tools.ability.sequence.cast.PageSeq import PageSeq

class SeqAbilityDict():

  @classmethod
  def get(cls,driver:WebDriver)->dict:
    return {
      # single seq
      SingleSeq.__name__:SingleSeq(driver),
      # loop seq
      LoopSeq.__name__:LoopSeq(driver),
      # page seq
      PageSeq.__name__:PageSeq(driver),
    }