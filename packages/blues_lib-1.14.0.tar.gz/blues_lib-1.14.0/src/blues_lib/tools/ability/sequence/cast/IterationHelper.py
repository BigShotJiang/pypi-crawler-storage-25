import random
from typing import Any
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.utils.datetime.DateTimeManager import DateTimeManager
from blues_lib.tools.ability.atom.AtomFacade import AtomFacade
from blues_lib.types import AttemptBy, ToolSummary,AttemptDelay

class IterationHelper():
  
  def __init__(self,driver:WebDriver) -> None:
    self._facade = AtomFacade(driver)

  def get_loop_items(self,attempt_by:AttemptBy)->list[dict[str,Any]]:
    if isinstance(attempt_by,int):
      return self.get_items_by_count(attempt_by)
    elif isinstance(attempt_by,str):
      return self.get_items_by_element(attempt_by)
    elif isinstance(attempt_by,list):
      return self.get_items_by_item(attempt_by)

  def get_items_by_element(self,ele_loc:str)->list[dict[str,Any]]:
    elems:list[WebElement]|None = self.query_elems(ele_loc)
    if not elems:
      raise ValueError(f'loop options {ele_loc} query no elements')
    return self.get_items_by_count(len(elems))

  def get_items_by_count(self,count:int)->list[dict[str,Any]]:
    if count<=0:
      raise ValueError('for loop by count must be a positive number')
    return [{'_i':i} for i in range(count)]

  def get_items_by_item(self,items:list)->list[dict[str,Any]]:
    if not items:
      raise ValueError('for loop by items must be a non-empty list')
    return items

  def query_elem(self,elem_loc:str) -> WebElement|None:
    elem_opts = {'target':elem_loc}
    return self._facade.execute('query_element',elem_opts)

  def query_elems(self,elem_loc:str) -> list[WebElement]|None:
    elem_opts = {'target':elem_loc}
    return self._facade.execute('query_elements',elem_opts)

  def get_next_elem(self,attempt_by:list[str],idx:int)->WebElement|None:
    page_type:str = attempt_by[0]
    elem_loc:str = attempt_by[1]
    if page_type == 'next':
      return self.query_elem(elem_loc)
    else:
      elems:list[WebElement]|None = self.query_elems(elem_loc)
      if not elems:
        return None
      return elems[idx] if idx<len(elems) else None

  def next_page(self,attempt_by:list[str],idx:int)->bool:
    elem:WebElement|None = self.get_next_elem(attempt_by,idx)
    if not elem:
      return False
    self._facade.execute('click',{'target':elem})
    return True

  def delay(self,cast_opts:ToolSummary):
    interval:int|float = self._get_loop_interval(cast_opts)
    if interval>0:
      DateTimeManager.count_down({
        'duration':interval,
        'title':f'Wait {interval}s in seq loop '
      })

  def _get_loop_interval(self,cast_opts:ToolSummary)->int|float:
    interval:AttemptDelay = cast_opts.get('attempt_delay')
    if not interval:
      return 0

    value:float = 0
    try: 
      if isinstance(interval,list):
        value= round(random.uniform(*interval), 1)
      else:
        value= float(interval)
    except ValueError:
      value= 0
    return value
