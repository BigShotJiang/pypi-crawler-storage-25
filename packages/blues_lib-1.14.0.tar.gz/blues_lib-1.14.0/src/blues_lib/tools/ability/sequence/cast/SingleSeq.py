from typing import Any
from blues_lib.tools.ability.sequence.cast.BaseSeq import BaseSeq
from blues_lib.types import SeqOpts,ToolDef

class SingleSeq(BaseSeq):
  
  _SEQ_NAME = 'single'

  # Public API Alias
  def cast(self,options:SeqOpts)->list[Any]|dict[str,Any]|None:
    return self.cast_single(options)

  # Public API  
  def cast_single(self,options:SeqOpts)->list[Any]|dict[str,Any]|None:
    return self._execute(options)

  def _cast_tools(self)->list[Any]|dict[str,Any]:
    tool_defs:list[ToolDef] = self._seq_opts.get('tools',[])
    return self._seq_executor.execute(tool_defs)
  
