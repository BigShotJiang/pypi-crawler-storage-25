import logging
from abc import ABC,abstractmethod
from typing import Any
from selenium.webdriver.chrome.webdriver import WebDriver 
from blues_lib.tools.ability.sequence.SeqExecutor import SeqExecutor
from blues_lib.supports.dp.exception import SkipSeqException
from blues_lib.tools.hook.SeqHook import SeqHook
from blues_lib.tools.ability.sequence.cast.IterationHelper import IterationHelper
from blues_lib.types import SeqOpts,ToolSummary
from blues_lib.supports.dp.exception.SkipSeqException import SkipSeqException

class BaseSeq(ABC):
  
  _SEQ_NAME = ''
  
  def __init__(self,driver:WebDriver):
    self._driver = driver
    self._seq_executor = SeqExecutor(driver)
    self._iter_helper = IterationHelper(driver)
    self._logger = logging.getLogger('airflow.task')
    self._seq_opts:SeqOpts = {}
    self._tool_summary:ToolSummary = {}

  def _execute(self,options:SeqOpts)->list[Any]|dict[str,Any]|None:
    self._seq_opts = options 
    self._tool_summary = self._seq_opts.get(self._SEQ_NAME) or {}
    seq_hook:SeqHook = SeqHook(self._driver,self._tool_summary)  
    try:
      seq_hook.prev() 
    except SkipSeqException as e:
      self._logger.error(f'seq hook input error: {e}')
      return None

    result:list[Any]|dict[str,Any]|None = self._cast_tools()

    try:
      seq_hook.post(result)
    except SkipSeqException as e:
      self._logger.error(f'seq hook output error: {e}')
      return None

    return result
  
  @abstractmethod
  def _cast_tools(self)->list[Any]|dict[str,Any]:
    # 执行tools seq abilities
    pass