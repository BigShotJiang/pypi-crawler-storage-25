from typing import Any
from blues_lib.utils.jinja2.Jinja2Renderer import Jinja2Renderer
from blues_lib.types import SeqOpts,ToolDef,AttemptBy
from blues_lib.supports.dp.exception.SkipSeqException import SkipSeqException
from blues_lib.tools.ability.sequence.cast.BaseSeq import BaseSeq

class LoopSeq(BaseSeq):

  _SEQ_NAME = 'loop'

  # Public API
  def cast_loop(self,options:SeqOpts)->list[Any]|dict[str,Any]|None:
    return self._execute(options)

  def _cast_tools(self)->list[list|dict]:
    attempts:int = int(self._tool_summary.get('attempts') or -1)
    attempt_by:AttemptBy = self._tool_summary.get('attempt_by')
    if not attempt_by:
      raise ValueError(f'attempt_by is required')

    items:list[dict[str,Any]] = self._iter_helper.get_loop_items(attempt_by)
    results:list[list|dict] = []

    for idx,item in enumerate(items):
      if attempts>0 and idx>=attempts:
        break

      try:
        result:list[Any]|dict[str,Any] = self._cast_once(item,idx)
      except SkipSeqException as e:
        self._logger.info(f'seq skip error: {e}')
        continue

      results.append(result)
      self._iter_helper.delay(self._tool_summary)

    self._logger.info(f'cast loop by {len(items)} items (attempts={attempts}) and  get {len(results)} results')
    return results
  
  def _cast_once(self,item:dict[str,Any],idx:int)->list[Any]|dict[str,Any]:
    # support typed item,nest cast's bizdata is it's options
    self._set_type_tools(item)

    loop_biz:dict[str,Any] = {
      **(item or {}),
      '_index':idx,
      '_no':idx+1
    }
    tool_defs:list[ToolDef]|dict[str,ToolDef] = self._seq_opts.get('tools')
    tool_defs = Jinja2Renderer.render_loop(tool_defs,loop_biz)
    return self._seq_executor.execute(tool_defs)

  def _set_type_tools(self,item:dict[str,Any])->None:
    type_tools:dict = self._seq_opts.get('type_tools') or {}
    if not type_tools:
      return

    item_type:str = item.get('type') or ''
    if not item_type:
      raise ValueError(f'has type_tools but item type is empty')

    # such as: {"text":{"tools":[]}}
    sub_seq_opts:dict = type_tools.get(item_type) or {}
    if not sub_seq_opts:
      raise ValueError(f'has type_tools but no tools for item type {item_type}')

    # add tools to seq_opts
    self._seq_opts.update(sub_seq_opts)
