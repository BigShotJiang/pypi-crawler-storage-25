from blues_lib.tools.task.TaskBaseExecutor import TaskBaseExecutor
from blues_lib.resources.ResourceLoader import ResourceLoader
from blues_lib.types import ToolDef

class FlowExecutor(TaskBaseExecutor):
  
  def _load_meta(self,orig_biz:dict,items:list[dict]|None)->ToolDef:
    if not items:
      return ResourceLoader.load_flow(orig_biz)

    tools:list[dict] = orig_biz.get('tools',[])
    merged_tools:list[dict] = []

    for idx,tool in enumerate(tools):
      if len(items) > idx and items[idx]:
        item = items[idx]
      else:
        item = {}
      merged_sub_biz = {**tool,**item}
      merged_tools.append(merged_sub_biz)
      
    merged_biz = {**orig_biz,'tools':merged_tools}
    return ResourceLoader.load_flow(merged_biz)
