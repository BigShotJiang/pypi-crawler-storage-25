from heapq import merge
from blues_lib.tools.task.TaskBaseExecutor import TaskBaseExecutor
from blues_lib.resources.ResourceLoader import ResourceLoader
from blues_lib.types import ToolDef

class TaskExecutor(TaskBaseExecutor):
  
  def _load_meta(self,orig_biz:dict,item:dict|None)->ToolDef:
    if not item:
      return ResourceLoader.load_task(orig_biz)

    merged_biz = {**orig_biz,**item}
    return ResourceLoader.load_task(merged_biz)
