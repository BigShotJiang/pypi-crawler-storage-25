from typing import Callable,Any
from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.types import DriverMode,DriverStartupOpts,DriverLocOpts,DriverDef
from blues_lib.tools.ability.atom.webdriver.driver.DriverFactory import DriverFactory   

class TaskContext:
  _DEFAULT_CONTEXT:DriverDef = {
    "driver":{
      "mode":"cft",
      "startup":{
        "features" : ["imageless"],
      },
    },
  }

  def __init__(self,config:dict|None = None):
    self._config:DriverDef = config or self._DEFAULT_CONTEXT
    self._driver:WebDriver|None = None
    self._setup()

  @property
  def driver(self)->WebDriver|None:
    return self._driver
  
  def add(self,field:str,value:Any)->None:
    setattr(self,field,value)
      
  def extend(self,kvs:dict)->None:
    for field,value in kvs.items():
      setattr(self,field,value)
      
  def _setup(self)->None:
    driver_def:dict|False = self._config.get('driver')
    # if set as False, then not create driver
    if driver_def is False:
      return 

    self.add_driver(driver_def)
    
  def add_driver(self,driver_def:DriverDef)->None:
    self.clear_driver()

    mode:DriverMode = driver_def.get('mode') or 'cft'
    startup_opts:DriverStartupOpts = driver_def.get('startup') or {}
    location_opts:DriverLocOpts = driver_def.get('location') or {}

    factory =  DriverFactory(**startup_opts)
    method:Callable = getattr(factory,mode)
    self._driver = method(**location_opts)
    
  def has_driver(self)->bool:
    return self._driver is not None
  
  def clear_driver(self)->None:
    if self.has_driver():
      self._driver.quit()
      self._driver = None
      
  def clear(self)->None:
    self.clear_driver()
