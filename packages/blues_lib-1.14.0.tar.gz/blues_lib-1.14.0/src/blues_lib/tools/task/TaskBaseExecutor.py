from abc import ABC, abstractmethod
from blues_lib.tools.task.tool.TaskFactory import TaskFactory
from blues_lib.resources.ResourceLoader import ResourceLoader
from blues_lib.types import TaskResponse
from blues_lib.types import ToolDef

class TaskBaseExecutor(ABC):
  
  _LOOP_BY_KEY = 'attempt_by'
  
  def __init__(self,biz_resource:dict|str,loop_resource:dict|str=''):
    self._bizdata:dict = ResourceLoader.load(biz_resource) or {}
    loopdata:dict = ResourceLoader.load(loop_resource) or {}
    # AtomTask为一位数组，FlowTask为二维数组
    self._loop_items:list[dict|list[dict]|None] = loopdata.get(self._LOOP_BY_KEY) or [None]

  @abstractmethod
  def _load_meta(self,resource:str,item:dict)->ToolDef:
    pass

  def execute(self)->TaskResponse:
    results:list[TaskResponse] = []
    for item in self._loop_items:
      # 先混合数据再执行渲染
      task_meta:ToolDef = self._load_meta(self._bizdata,item)
      results.append(self._repeat(task_meta))
    return self._get_std_response(results)

  def _repeat(self,task_meta:ToolDef)->TaskResponse:
    results:list[TaskResponse] = []
    count:int = self._get_exec_count(task_meta)
    for _ in range(count):
      results.append(self._once(task_meta))
    return self._get_std_response(results)
    
  def _get_std_response(self,results:list[TaskResponse])->TaskResponse:
    if len(results) == 1:
      return results[0]
    else:
      return {
        'code': 200,
        'message': 'success',
        'data': results
      }

  def _once(self,task_meta:ToolDef)->TaskResponse:
    task = TaskFactory.create(task_meta)
    response: TaskResponse = task.execute()
    task.clear()
    return response

  def _get_exec_count(self,task_meta:ToolDef)->int:
    repeat:int = int(task_meta.get('options',{}).get('task',{}).get('repeat',0) or 0)
    count = repeat+1
    return count if count>0 else 1