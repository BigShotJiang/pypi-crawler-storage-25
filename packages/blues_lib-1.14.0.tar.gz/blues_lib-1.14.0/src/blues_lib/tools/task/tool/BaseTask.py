import logging
from abc import ABC,abstractmethod
from typing import Any
from blues_lib.types import ToolDef,ToolSummary,TaskResponse
from blues_lib.tools.hook.TaskHook import TaskHook
from blues_lib.supports.dp.exception import SkipTaskException,FailTaskException,BlockException
from blues_lib.tools.task.support.TaskContext import TaskContext
from blues_lib.tools.task.support.MockTI import MockTI
from blues_lib.utils.schema.SchemaValidator import SchemaValidator

class BaseTask(ABC):

  _TOOL_KEY = 'tools'

  def __init__(self,task_def:ToolDef,ti:Any|None=None,context:TaskContext|None=None)->None: 
    self._task_def = task_def
    self._task_opts = self._task_def.get('options')
    SchemaValidator.validate_tool_input(self._task_opts,'task')

    self._tool_summary:ToolSummary = self._task_opts.get('task',{})

    self._ti = self._get_ti(ti)
    self._context = self._get_context(context)
    self._xcom_biz = {}

    self._logger = logging.getLogger('airflow.task')
    self.prev_task:BaseTask|None = None
    self.next_task:BaseTask|None = None

  def _get_ti(self,ti:Any|None)->Any:
    if ti:
      return ti
    task_id:str = self.get_task_id()
    return MockTI(task_id)
    
  def _get_context(self,context:TaskContext|None)->TaskContext:
    if context:
      return context
    context_conf:dict|None = self._task_opts.get('context')
    return TaskContext(context_conf)
  
  def clear(self):
    self._context.clear()
  
  def get_task_id(self)->str:
    return self._tool_summary.get('id')

  def get_prev_task_id(self)->str:
    return self.prev_task.get_task_id() if self.prev_task else ''

  def get_next_task_id(self)->str:
    return self.next_task.get_task_id() if self.next_task else ''

  def execute(self)->TaskResponse:

    self._logger.info(f'--- Start to execute task : {self.get_task_id()} ---')
    extra = {
      'options':{
        'prev_task_id':self.get_prev_task_id(),
        'task_id':self.get_task_id(),
        'next_task_id':self.get_next_task_id(),
      },
      'xcom_biz':self._xcom_biz,
      'result':None,
      'ti':self._ti,
    } 
    self._context.extend(extra)

    task_hook:TaskHook = TaskHook(self._context._driver,self._tool_summary,self._context) 
    try:
      task_hook.prev()
      result:list[Any]|dict[str,Any] = self._process()
    except SkipTaskException as e:
      self._logger.info(f'Task {self.get_task_id()} skipped with result {e.result}')
      result:None = None
    except FailTaskException as e:
      self._logger.error(f'Task {self.get_task_id()} failed with exception {e}')
      result:dict = {'code':500,'message':str(e),'data':None}
    except BlockException as e:
      self._context.clear()
      raise e
    except Exception as e:
      self._context.clear()
      raise e

    response:TaskResponse = self._get_response(result)
    task_hook.post(response)
    return response

  def _get_response(self,result:list[Any]|dict[str,Any]|None)->TaskResponse:
      if not isinstance(result,dict):
        return {'code':200,'data':result,'message':'ok','detail':None}

      code:int = 200 if ('status' not in result or result.get('status')=='success') else 500
      data:list[Any]|dict[str,Any] = result if 'data' not in result else result.get('data')
      message:str = 'ok' if code==200 else 'error'
      return {'code':code,'data':data,'message':message,'detail':None}
 
  @abstractmethod   
  def _process(self)->list[Any]|dict[str,Any]:
    pass