from typing import Any
from blues_lib.types import ToolDef,TaskName
from blues_lib.supports.dp.factory.Factory import Factory

from blues_lib.tools.task.tool.BaseTask import BaseTask
from blues_lib.tools.task.tool.AtomTask import AtomTask
from blues_lib.tools.task.tool.FlowTask import FlowTask
from blues_lib.tools.task.support.TaskContext import TaskContext


class TaskFactory(Factory):
  
  _TASKS:dict[str,type[BaseTask]] = {
    AtomTask.__name__:AtomTask,
    FlowTask.__name__:FlowTask,
  }
  
  @classmethod
  def create(cls,tool_meta:ToolDef,ti:Any|None=None,context:TaskContext|None=None)->BaseTask:
    task_name:TaskName = (tool_meta or {}).get('name') or 'undefined'
    task_class:type[BaseTask]|None = cls._TASKS.get(task_name)
    if not task_class:
      error = f"The task '{task_name}' is not supported."
      raise ValueError(f"Failed to create task - {error}")
    return task_class(tool_meta,ti,context)
  