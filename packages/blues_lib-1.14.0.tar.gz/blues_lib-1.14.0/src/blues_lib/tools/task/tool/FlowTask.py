from typing import Any
from blues_lib.types import ToolDef,TaskResponse
from blues_lib.tools.task.tool.BaseTask import BaseTask
from blues_lib.supports.dp.exception import SkipFlowException
from blues_lib.tools.task.support.TaskContext import TaskContext
from blues_lib.tools.task.support.MockTI import MockTI

class FlowTask(BaseTask):

  def __init__(self,task_def:ToolDef,ti:Any|None=None,context:TaskContext|None=None)->None:
    super().__init__(task_def,ti,context)
    self._task_ids:list[str] = []

  def _process(self)->TaskResponse:
    
    executors:list[BaseTask] = self._get_executors()
    exec_count:int = len(executors)
    for idx,executor in enumerate(executors):
      self._logger.info(f'FlowTask {executor.get_task_id()} started')
      try:
        if idx>0:
          executor.prev_task = executors[idx-1]
        if idx<exec_count-1:
          executor.next_task = executors[idx+1]
        executor.execute()
      except SkipFlowException as e:
        self._logger.error(f'flow {executor.get_task_id()} skip: {e.message}')
        break
    
    self.clear()
    return self.get_last_task_output()
  
  def get_task_output(self,task_id:str)->TaskResponse:
    return MockTI.store.get(task_id) or {}

  def get_last_task_output(self)->TaskResponse:
    return self.get_task_output(self._task_ids[-1])
  
  def get_task_ids(self)->list[str]:
    return self._task_ids

  def _get_executors(self)->list[BaseTask]:
    task_defs:list[ToolDef] = self._task_opts.get(self._TOOL_KEY,[])
    executors:list[BaseTask] = []

    for task_def in task_defs:

      task_id:str = self._get_task_id(task_def)
      # check task_id
      if not task_id:
        raise ValueError(f"task_id is not defined in task_def {task_def}")
      if task_id in self._task_ids:
        raise ValueError(f"task_id {task_id} is not unique in the flow")

      self._task_ids.append(task_id)
      executor:BaseTask = self._get_executor(task_id,task_def)
      executors.append(executor)

    return executors
  
  def _get_executor(self,task_id:str,task_def:ToolDef)->BaseTask:
    ti:Any = MockTI(task_id)
    from blues_lib.tools.task.tool.TaskFactory import TaskFactory 
    return TaskFactory.create(task_def,ti,self._context)

  def _get_task_id(self,task_def:ToolDef|None)->str:
    if not task_def:
      return ''
    return task_def.get('options',{}).get('task',{}).get('id','')
  
    
