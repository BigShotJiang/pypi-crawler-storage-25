from typing import Any
from blues_lib.types import ToolDef
from blues_lib.tools.ability.AbilityExecutor import AbilityExecutor
from blues_lib.tools.task.tool.BaseTask import BaseTask
from blues_lib.utils.jinja2.Jinja2Renderer import Jinja2Renderer

class AtomTask(BaseTask):

  def _process(self)->list[Any]|dict[str,Any]:
    tools:list[ToolDef]|dict[str,ToolDef] = self._task_opts.get(self._TOOL_KEY)
    # render tools by xcom biz
    tools = Jinja2Renderer.render_task(tools,self._xcom_biz)
    executor = AbilityExecutor(self._context.driver)
    return executor.execute(tools)
  