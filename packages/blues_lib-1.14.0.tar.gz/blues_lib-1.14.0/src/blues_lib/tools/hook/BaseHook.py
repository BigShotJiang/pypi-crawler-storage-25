import logging
from typing import Any
from abc import ABC
from selenium.webdriver.chrome.webdriver import WebDriver
from blues_lib.types import ToolDef,ToolSummary
from blues_lib.tools.ability.sequence.SeqExecutor import SeqExecutor
from blues_lib.tools.hook.handler.SwitchHandler import SwitchHandler

class BaseHook(ABC):

  def __init__(self,driver:WebDriver,tool_summary:ToolSummary):
    self._logger = logging.getLogger('airflow.task')
    self._seq_executor = SeqExecutor(driver)
    self._tool_summary = tool_summary or {}
    self._init_hooks()
    
  def _init_hooks(self)->dict[str,list[ToolDef]]:
    prev_tools: list[ToolDef] = self._tool_summary.get('prev_tools') or []
    post_tools: list[ToolDef] = self._tool_summary.get('post_tools') or []
    self._tool_summary['prev_tools'] = prev_tools
    self._tool_summary['post_tools'] = post_tools

  def _add_prev_tools(self)->None:
    SwitchHandler(self._tool_summary).handle()
    
  def prev(self)->Any:
    self._add_prev_tools()
    hook_defs:list[ToolDef] = self._tool_summary.get('prev_tools')
    return self._seq_executor.execute(hook_defs)  if hook_defs else None

  def post(self,result:Any)->Any:
    self._add_post_tools(result)
    hook_defs:list[ToolDef] = self._tool_summary.get('post_tools')
    return self._seq_executor.execute(hook_defs)  if hook_defs else None
    
  def _add_post_tools(self,result:Any)->None:
    pass
