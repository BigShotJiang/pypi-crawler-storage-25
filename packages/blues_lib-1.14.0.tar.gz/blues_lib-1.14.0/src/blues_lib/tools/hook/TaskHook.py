from typing import Any
from blues_lib.types import ToolSummary
from selenium.webdriver.chrome.webdriver import WebDriver
from blues_lib.tools.hook.BaseHook import BaseHook
from blues_lib.tools.hook.handler.PreprocessHandler import PreprocessHandler
from blues_lib.tools.hook.handler.ShareHandler import ShareHandler
from blues_lib.tools.task.support.TaskContext import TaskContext
from blues_lib.tools.hook.handler.XcomHandler import XcomHandler
from blues_lib.utils.jinja2.Jinja2Renderer import Jinja2Renderer

class TaskHook(BaseHook):

  def __init__(self,driver:WebDriver,tool_summary:ToolSummary,context:TaskContext):
    self._context = context
    super().__init__(driver,tool_summary)

  def _add_prev_tools(self)->None:
    super()._add_prev_tools()
    XcomHandler(self._tool_summary,self._context).handle()

  def _add_post_tools(self,result:Any)->None:
    self._render_post_tools_by_xcom()
    super()._add_post_tools(result)
    # add task result to the context
    self._context.result = result
    # this handler relay the result
    PreprocessHandler(self._tool_summary,self._context).handle()
    ShareHandler(self._tool_summary,self._context).handle()
    
  def _render_post_tools_by_xcom(self)->None:
    post_tools:list[ToolDef] = self._tool_summary['post_tools']
    xcom_biz = self._context.xcom_biz
    if post_tools and xcom_biz:
      self._tool_summary['post_tools'] = Jinja2Renderer.render_task(post_tools,xcom_biz)
