from blues_lib.tools.hook.BaseHook import BaseHook

class SeqHook(BaseHook):
  pass