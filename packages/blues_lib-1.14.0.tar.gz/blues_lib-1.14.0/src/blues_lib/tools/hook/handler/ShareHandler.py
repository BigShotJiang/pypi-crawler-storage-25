from blues_lib.tools.hook.handler.HookHandler import HookHandler
from blues_lib.types import ToolDef

class ShareHandler(HookHandler):
  
  def handle(self)->None:
    self._add_opts_to_tool()
    self._add_tool()
    
  def _add_opts_to_tool(self)->None:
    for tool in self._post_tools:
      if 'xcom' in tool['name']:
        tool['options']['ti'] = self._context.ti
      if 'share_to' in tool['name']:
        tool['options']['value'] = self._context.result
    
  def _add_tool(self)->None:
    xcom_def:ToolDef = {
      'name':'share_to_xcom', 
      'options':{
        'value':self._context.result,
        'ti':self._context.ti,
      },
    }
    self._post_tools.append(xcom_def)
