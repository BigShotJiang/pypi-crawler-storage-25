from blues_lib.tools.hook.handler.HookHandler import HookHandler

class SwitchHandler(HookHandler):

  _SWITCH_NAME_HASH = {
    'switch_to_frame':'switch_to_default_content',
    'switch_to_new_tab':'switch_to_first_content',
    'switch_to_new_window':'switch_to_first_content',
  }

  def handle(self)->None:
    name:str = self._get_reset_name()
    if name:
      self._post_tools.append({
        'name':name,
      })
    
  def _get_reset_name(self)->str:
    for name in self._prev_tool_names:
      hash_name:str = self._SWITCH_NAME_HASH.get(name,'')
      if hash_name and hash_name not in self._post_tool_names:
        return hash_name
    return ''
