from blues_lib.tools.hook.handler.HookHandler import HookHandler
from blues_lib.types import ToolDef

class XcomHandler(HookHandler):

  def handle(self)->None:
    self._add_opts_to_tool()
    self._add_tool()

  def _add_opts_to_tool(self)->None:
    for tool in self._prev_tools:
      if 'xcom' in tool['name']:
        tool['options']['ti'] = self._context.ti
        tool['options']['xcom_biz'] = self._context.xcom_biz

  def _add_tool(self)->None:
    prev_task_id = self._get_prev_task_id()
    if not prev_task_id:
      return None
    
    mappings:list[list[str]] = [
      [f'{prev_task_id}/code','xcom_biz/prev_task_code'],
      [f'{prev_task_id}/data','xcom_biz/prev_task_data'],
      [f'{prev_task_id}/message','xcom_biz/prev_task_message'],
    ]
    ability_def:ToolDef = {
      'name':'xcom_map',
      'description':'map xcom from prev task to xcom_biz',
      'options':{
        'value':mappings,
        'ti':self._context.ti,
        'xcom_biz':self._context.xcom_biz,
      }
    }
    self._prev_tools.append(ability_def)

  def _get_prev_task_id(self)->str:
    task_opts:ToolDef = self._context.options
    return task_opts.get('prev_task_id','')
  