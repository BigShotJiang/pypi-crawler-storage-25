from abc import ABC,abstractmethod
from typing import Any
from blues_lib.types import ToolDef,ToolSummary
from blues_lib.tools.task.support.TaskContext import TaskContext

class HookHandler(ABC):
  def __init__(self,tool_summary:ToolSummary,context:TaskContext|None=None) -> None:
    self._tool_summary = tool_summary or {}
    self._context = context
    
    self._prev_tools:list[ToolDef] = self._tool_summary.get('prev_tools')
    self._post_tools:list[ToolDef] = self._tool_summary.get('post_tools')
    
    self._prev_tool_names:list[str] = [tool.get('name') for tool in self._prev_tools]
    self._post_tool_names:list[str] = [tool.get('name') for tool in self._post_tools]

  @abstractmethod
  def handle(self)->None:
    pass

  def _update_hooks(self)->None:
    self._update_hook(self._prev_tools)
    self._update_hook(self._post_tools)

  def _update_hook(self,tools:list[ToolDef])->None:
    for tool in tools:
      name:str = tool.get('name','')
      options:dict[str,Any] = tool.get('options',{})
      self._update_ability(name,options)

  def _update_ability(self,name:str,options:dict[str,Any])->None:
    pass