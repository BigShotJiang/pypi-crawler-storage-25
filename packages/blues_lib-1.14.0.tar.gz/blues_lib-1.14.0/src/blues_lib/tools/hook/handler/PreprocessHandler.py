from typing import Any
from blues_lib.tools.hook.handler.HookHandler import HookHandler

class PreprocessHandler(HookHandler):

  _ABILITY_NAMES = ['preprocess_mat']

  def handle(self)->None:
    self._update_hooks()
    
  def _update_ability(self,name:str,options:dict[str,Any])->None:
    value:list[dict]|None = options.get('value')
    if name in self._ABILITY_NAMES and not value:
      options['value'] = self._context.result
