from typing import Any

class SkipTaskException(Exception):
  def __init__(self, result:Any,message="task skip exception"):
    self.result = result
    self.message = message
    super().__init__(self.message)