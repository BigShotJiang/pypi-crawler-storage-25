from typing import Any

class SkipFlowException(Exception):
  def __init__(self, result:Any,message="flow skip exception"):
    self.result = result
    self.message = message
    super().__init__(self.message)