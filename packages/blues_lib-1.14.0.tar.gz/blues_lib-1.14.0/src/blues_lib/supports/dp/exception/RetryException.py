from typing import Any
class RetryException(Exception):
  def __init__(self, result:Any, message="ability retry exception"):
    self.result = result
    self.message = message
    super().__init__(self.message)