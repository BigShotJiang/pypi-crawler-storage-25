from typing import Any

class SkipAbilityException(Exception):
  def __init__(self, result:Any,message="ability skip exception"):
    self.result = result
    self.message = message
    super().__init__(self.message)