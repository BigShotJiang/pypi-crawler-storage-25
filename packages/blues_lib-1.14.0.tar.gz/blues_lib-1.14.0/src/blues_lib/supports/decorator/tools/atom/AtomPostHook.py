from typing import Any,Callable
from functools import wraps
from blues_lib.services.expecter.Matcher import Matcher
from blues_lib.supports.decorator.tools.atom.AtomBaseHook import AtomBaseHook
from blues_lib.utils.datetime.DateTimeManager import DateTimeManager

class AtomPostHook(AtomBaseHook):

  def __call__(self,func):
    @wraps(func) 
    def wrapper(instance,method:Callable,*args,**kwargs):
      result:Any = func(instance,method,*args,**kwargs)
      name:str = method.__name__
      opts:dict = args[0] if len(args)>0 else {}
      self._switch(instance,opts) 
      self._match(name,opts,result)
      self._delay(name,opts)
      return result
    return wrapper
  
  def _match(self,name:str,opts:dict,result:Any)->None:
    Matcher.match(name,opts,result)
    
  def _switch(self,instance,opts:dict):
    self._switch_out_frame(instance,opts)
    self._switch_out_new(instance,opts)
    
  def _switch_out_new(self,instance,opts:dict):
    window = self._get_window(instance,opts)
    if not window:
      return
    window.switch_to_first_content()

  def _switch_out_frame(self,instance,opts:dict):
    frame = self._get_frame(instance,opts)
    if not frame:
      return
    frame.switch_to_default_content()

  def _delay(self,name:str,opts:dict)->None:
    delay:int|float = opts.get('delay',0)
    if delay>0:
      DateTimeManager.count_down({
        'duration':delay,
        'title':f'Delay {delay} seconds after {name}'
      })