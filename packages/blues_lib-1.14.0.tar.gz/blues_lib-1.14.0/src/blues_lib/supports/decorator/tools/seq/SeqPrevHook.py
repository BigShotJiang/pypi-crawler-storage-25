from functools import wraps
from typing import Callable
from blues_lib.utils.schema.SchemaValidator import SchemaValidator
from blues_lib.supports.decorator.tools.ToolBaseHook import ToolBaseHook

class SeqPrevHook(ToolBaseHook):

  def __call__(self,func):
    @wraps(func) 
    def wrapper(instance,method:Callable,*args,**kwargs):
      uri_name:str = method.__name__
      opts:dict = args[0] if len(args)>0 else {}
      self._validate_input(uri_name,opts)
      return func(instance,method,*args,**kwargs)
    return wrapper
  
  def _validate_input(self,name:str,opts:dict):
    if opts:
      SchemaValidator.validate_tool_input(opts,name)