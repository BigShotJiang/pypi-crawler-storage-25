from functools import wraps
from typing import Callable
from blues_lib.utils.schema.SchemaValidator import SchemaValidator
from blues_lib.supports.decorator.tools.atom.AtomBaseHook import AtomBaseHook

class AtomPrevHook(AtomBaseHook):

  def __call__(self,func):
    @wraps(func) 
    def wrapper(instance,method:Callable,*args,**kwargs):
      uri_name:str = method.__name__
      opts:dict = args[0] if len(args)>0 else {}
      self._validate_input(uri_name,opts)
      self._switch(instance,opts) 
      return func(instance,method,*args,**kwargs)
    return wrapper
  
  def _validate_input(self,name:str,opts:dict):
    if opts:
      SchemaValidator.validate_tool_input(opts,name)

  def _switch(self,instance,opts:dict):
    self._switch_to_frame(instance,opts)
    self._switch_to_new(instance,opts)

  def _switch_to_new(self,instance,opts:dict):
    window = self._get_window(instance,opts)
    if not window:
      return
    should_new_window:bool = opts.get(self._NEW_WINDOW_KEY) or False 
    should_new_tab:bool = opts.get(self._NEW_TAB_KEY) or False
    if should_new_window:
      window.switch_to_new_window()
    if should_new_tab:
      window.switch_to_new_tab()

  def _switch_to_frame(self,instance,opts:dict):
    frame = self._get_frame(instance,opts)
    if not frame:
      return
    target:str = opts.get(self._FRAME_TARGET_KEY)
    ability_opts:dict = {
      'target':target,
      'timeout':opts.get('timeout',5)
    }
    frame.switch_to_frame(ability_opts)

