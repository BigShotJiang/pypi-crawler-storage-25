from selenium.webdriver.remote.webdriver import WebDriver
from blues_lib.supports.decorator.tools.ToolBaseHook import ToolBaseHook

class AtomBaseHook(ToolBaseHook):

  _FRAME_TARGET_KEY = 'frame_target'
  _NEW_TAB_KEY = 'new_tab'
  _NEW_WINDOW_KEY = 'new_window'
  
  def _get_frame(self,instance,opts:dict):
    target:str = opts.get(self._FRAME_TARGET_KEY) or ''
    if not target:
      return
    driver:WebDriver|None = self._get_driver(instance)
    if not driver:
      return
    from blues_lib.tools.ability.atom.webdriver.interaction.Frame import Frame
    return Frame(driver)
  
  def _get_window(self,instance,opts:dict):
    should_new_window:bool = opts.get(self._NEW_WINDOW_KEY) or False 
    should_new_tab:bool = opts.get(self._NEW_TAB_KEY) or False
    if not should_new_window and not should_new_tab:
      return

    driver:WebDriver|None = self._get_driver(instance)
    if not driver:
      return
    from blues_lib.tools.ability.atom.webdriver.interaction.Window import Window
    return Window(driver)

  def _get_driver(self,instance)->WebDriver|None:
    return getattr(instance,'_driver',None)
