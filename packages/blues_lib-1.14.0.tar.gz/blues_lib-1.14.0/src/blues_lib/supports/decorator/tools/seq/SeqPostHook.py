from typing import Any,Callable
from functools import wraps
from blues_lib.services.expecter.Matcher import Matcher
from blues_lib.supports.decorator.tools.ToolBaseHook import ToolBaseHook

class SeqPostHook(ToolBaseHook):

  def __call__(self,func):
    @wraps(func) 
    def wrapper(instance,method:Callable,*args,**kwargs):
      result:Any = func(instance,method,*args,**kwargs)
      name:str = method.__name__
      opts:dict = args[0] if len(args)>0 else {}
      self._match(name,opts,result)
      return result
    return wrapper
  
  def _match(self,name:str,opts:dict,result:Any)->None:
    Matcher.match(name,opts,result)
    