from typing import Any
from blues_lib.resources.ResourceManager import ResourceManager
from blues_lib.utils.hocon.render.ResourceRenderer import ResourceRenderer
from blues_lib.utils.jinja2.Jinja2Renderer import Jinja2Renderer
from blues_lib.resources.definition.ToolDefConverter import ToolDefConverter
from blues_lib.utils.url.URIManager import URIManager
from blues_lib.types import ToolDef,ToolSummary

class ResourceLoader:
  
  _TOOL_KEYS = ['tools','prev_tools','post_tools']
  _TASK_TOOL_KEY = 'tools'
  
  _TPLS = {
    'seq':{
      'key':'seq_tpl',
      'prefix':'template://seq/',
    },
    'task':{
      'key':'task_tpl',
      'prefix':'template://task/',
    },
    'flow':{
      'key':'task_tpl',
      'prefix':'template://flow/',
    },
  }

  @classmethod
  def read(cls,uri:str)->Any:
    return ResourceManager.read(uri)

  @classmethod
  def load(cls,resource:dict|str)->dict:
    '''
    Read hocon resources and include it's child hocon resources.
    Args:
      resource (dict|str): The resource, support three types:
        - dict: The resource is already loaded.
        - str of uri: The resource is a uri.
        - str of file path: The resource is a file path. support slash path or dot path.
    Returns:
      dict: The loaded resource.
    '''
    if not resource or not isinstance(resource,str):
      return resource

    if not URIManager.is_uri(resource):
      resource = cls.register(resource)

    if ResourceManager.is_property_uri(resource):
      return cls.read(resource)

    return ResourceRenderer(resource).render()

  @classmethod
  def load_and_interp_biz(cls,resource:dict|str)->dict:
    '''
    Load and interpolate by iteself.
    Args:
      resource (dict|str): The resource, support three types:
        - dict: The resource is already loaded.
        - str of uri: The resource is a uri.
        - str of file path: The resource is a file path. support slash path or dot path.
    Returns:
      dict: The interpolated resource.
    '''
    bizdata:dict = cls.load(resource)
    cls.convert_standard_tools(bizdata)
    return Jinja2Renderer.render_by_self(bizdata)

  @classmethod
  def register(cls,dot_or_path:str)->str:
    '''
    使用本地dot或文件path地址
    '''
    temp_uri = f'template://{dot_or_path}'
    ResourceManager.register(temp_uri,dot_or_path)
    return temp_uri

  @classmethod
  def load_task(cls,resource:dict|str)->ToolDef:
    task_biz:dict = cls.load_and_interp_biz(resource)
    cls.ensure_task_id(task_biz)

    task_tpl:str = cls.get_tpl(task_biz,'task')
    task_def:dict = cls.load(task_tpl)
    return Jinja2Renderer.render(task_def,task_biz)

  @classmethod
  def load_seq(cls,resource:dict|str)->ToolDef:
    '''
    Load the ability sequence's meta and bizdata
    - load the bizdata (includes all resources)
    - render the bizdata by self.
    - load the definition (includes all resources)
    - render the definition by bizdata to meta (keeps the iter and xcom replaceholders)
    '''
    seq_biz:dict = cls.load_and_interp_biz(resource)
    seq_tpl:str = cls.get_tpl(seq_biz,'seq')
    seq_def:dict = cls.load(seq_tpl)
    return Jinja2Renderer.render(seq_def,seq_biz)

  @classmethod
  def load_flow(cls,resource:dict|str)->ToolDef:
    # 此处不可render by self，否则所有子tools都被错误替换
    flow_biz:dict = cls.load(resource)
    task_defs:list[ToolDef] = []
    
    cls.ensure_task_id(flow_biz)
    
    # 递归的完成每个task的def与biz的渲染，然后替换tools字段
    task_bizs = flow_biz.get(cls._TASK_TOOL_KEY)
    for idx,task_biz in enumerate(task_bizs):
      # 提前补充带有idx的id，避免递归调用时id冲突
      cls.ensure_task_id(task_biz,idx+1)
      task_def = cls.load_task(task_biz)
      task_defs.append(task_def)
    flow_biz[cls._TASK_TOOL_KEY] = task_defs

    flow_tpl:str = cls.get_tpl(flow_biz,'flow')
    flow_def:dict = cls.load(flow_tpl)
    return Jinja2Renderer.render(flow_def,flow_biz)
  
  @classmethod
  def get_tpl(cls,task_biz:dict,level:str)->str:
    tpl_info:dict = cls._TPLS.get(level,{})
    if not tpl_info:
      raise ValueError(f'Level {level} is not supported')

    tpl_name:str = task_biz.get(tpl_info['key']) or ''
    if not tpl_name:
      if level == 'flow':
        tpl_name = 'default'
      else:
        raise ValueError(f'Task tool {task_biz} is missing {tpl_info["key"]}')
    return f'{tpl_info["prefix"]}{tpl_name}'

  @classmethod
  def ensure_task_id(cls,task_biz:ToolDef,no:int=0)->str:
    tpl_name:str = task_biz.get('task_tpl') or 'default'
    # 0表示独立一个task，没有上下游
    auto_id:str = f"task_{tpl_name}_{no}"
    task_summary:ToolSummary = task_biz.setdefault('task',{})
    task_id:str = task_summary.get('id')
    if not task_id:
      task_summary['id'] = auto_id
  
  @classmethod
  def convert_standard_tools(cls,task_biz:dict,excludes:list[str]=[])->None:
    '''
    将简写的工具定义转换为标准的工具定义元数据，使用 ToolDefConverter.convert(value) 实现转换，并直接修改数据节点的值。
    该方法不返回任何值，仅在原数据节点上进行修改。
    
    转换规则：
    1. 递归task_biz的所有dict和list节点。
    2. 如果属性名是 _TOOL_KEYS 中的任意一个，递归调用 ToolDefConverter.convert(value) 替换此节点的值。
    3. 注意替换值后，要继续递归处理子节点。
    Args:
      task_biz (dict): 任务业务数据元数据字典
    Returns:
      None
    '''
    if not isinstance(task_biz, dict):
      return

    for key, value in task_biz.items():
      if key in cls._TOOL_KEYS and value is not None and key not in excludes:
        task_biz[key] = ToolDefConverter.convert(value)
        cls._process_value(task_biz[key])
      else:
        cls._process_value(value)

  @classmethod
  def _process_value(cls, value: Any) -> None:
    if isinstance(value, dict):
      cls.convert_standard_tools(value)
    elif isinstance(value, list):
      for item in value:
        cls._process_value(item)
      