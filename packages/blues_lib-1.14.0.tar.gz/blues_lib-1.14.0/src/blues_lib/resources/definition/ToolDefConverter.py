from blues_lib.types import ToolDef
from blues_lib.resources.definition.StandardDefConverter import StandardDefConverter

class ToolDefConverter:
  '''
  ToolDefConverter is used to convert simple tool definitions to std tool definitions. A standard definition is like:
  {
    "name":"click",
    "options":{
      "target":".user-name",
    },
  }
  '''

  @classmethod
  def convert(cls,atoms:list[ToolDef|list]|dict[str,ToolDef|list])->list[ToolDef]|dict[str,ToolDef]:
    if isinstance(atoms,list):
      if cls._need_convert_to_dict(atoms):
        return cls._get_dict_from_list(atoms)
      else:
        return cls._get_from_list(atoms)
    if isinstance(atoms,dict):
      return cls._get_from_dict(atoms)
  
  @classmethod
  def _get_from_dict(cls,atoms:dict[str,ToolDef|list])->dict[str,ToolDef]:
    tool_defs:dict[str,ToolDef] = {}
    for key,atom in atoms.items():
      if not atom:
        continue

      if isinstance(atom,list):
        order_defs:list[ToolDef] = StandardDefConverter.convert(atom)
        if len(order_defs)==1:
          tool_defs[key] = order_defs[0]
        else:
          for idx,tool_def in enumerate(order_defs):
            tool_defs[f'{key}_{idx}'] = tool_def
      else:
        tool_defs[key] = atom
    return tool_defs

  @classmethod
  def _get_dict_from_list(cls,atoms:list[ToolDef|list])->dict[str,ToolDef]:
    tool_defs:dict[str,ToolDef] = {}
    for i,atom in enumerate(atoms):
      if not atom:
        continue
      if isinstance(atom,list):
        name:str = atom[0]
        seq_tool_defs:list[ToolDef]|dict[str,ToolDef] = StandardDefConverter.convert(atom)
        if isinstance(seq_tool_defs,list):
          for j,tool_def in enumerate(seq_tool_defs):
            tool_defs[f'_{name}_{i}_{j}'] = tool_def
        else:
          tool_defs.update(seq_tool_defs)
      else:
        # a std tool_def
        name:str = atom['name']
        tool_defs[f'_{name}_{i}'] = atom
    return tool_defs

  @classmethod
  def _get_from_list(cls,atoms:list[ToolDef|list])->list[ToolDef]:
    '''
    Convert a list of simple tool definitions to std tool definitions.
    Args:
      atoms: A list of simple tool definitions. like:
      [
        ["click", [".user-name", "123"]],
        ["get_attribute", [["a", "href"]]],
        {"name":"click","options":{"target":".user-name"}},
      ]
    Returns:
      A list of std tool definitions.
    '''
    tool_defs:list[ToolDef] = []
    for atom in atoms:
      if not atom:
        continue
      if isinstance(atom,list):
        seq_tool_defs:list[ToolDef] = StandardDefConverter.convert(atom)
        tool_defs.extend(seq_tool_defs)
      else:
        tool_defs.append(atom)
    return tool_defs
  
  @classmethod 
  def _need_convert_to_dict(cls,atoms:list[ToolDef|list])->bool:
    '''
    if one seq's first element(opts_conf) is a dict, then convert it to dict tools.
    '''
    for atom in atoms:
      if isinstance(atom,list) and len(atom)>1 and isinstance(atom[1],dict):
        return True
    return False
  