from typing import TypeAlias,TypedDict,Literal,Any
from blues_lib.types.ability import ToolDef
from blues_lib.types.sequence import ToolDef


TaskName: TypeAlias = Literal["AtomTask","FlowTask"]

class TaskResponse(TypedDict):
  code: int
  data: Any|None
  message: str
  detail: Any|None

TaskOpts: TypeAlias = TypedDict("TaskOpts", {
  "id": str,
  "description": str,
  "retries": int,
  "retry_delay": int,
  "prev_tools": list[ToolDef],
  "post_tools": list[ToolDef],
  "tools": list[ToolDef],
})

# --- flow level ---
FlowSummary: TypeAlias = TypedDict("FlowSummary", {
  "dag_id": str,
  "description": str,
  "start_date": list[int],
  "end_date": list[int],
  "schedule": str,
  "catchup": bool,
})