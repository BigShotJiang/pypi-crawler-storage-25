from typing import TypeAlias,TypedDict,Literal

# --- SQL ---
SQLPagination: TypeAlias = TypedDict("SQLPagination", {
  "no": int,
  "size": int,
})

SQLCondition: TypeAlias = TypedDict("SQLCondition", {
  "operator": str,
  "field": str,
  "comparator": str,
  "value": str|int|float|bool|None,
  "value_type": str, # function
})

SQLOrder: TypeAlias = TypedDict("SQLOrder", {
  "field": str,
  "sort": str,
})

SQLFilter: TypeAlias = TypedDict("SQLFilter", {
  "inc_fields": list[str],
  "inc_pattern": str,
  "dec_fields": list[str],
  "dec_pattern": str,
})

SQLOpts: TypeAlias = TypedDict("SQLOpts", {
  "table": str,
  "conditions": list[SQLCondition],
  
  # for update
  "entity": dict,
  
  # for insert
  "entities": list[dict],
  "filter": SQLFilter,
  "constants":dict,
  
  # for query
  "orders": list[SQLOrder],
  "fields": list[str],
  "page": SQLPagination,
})

# -- cleaner ---
CleanOpts: TypeAlias = TypedDict("CleanOpts", {
  "validity_days": int,
  "tables": list[str], # delete the db table
  "dirs": list[str], # delete the directory files
})

# -- message -- 
EmailPara: TypeAlias = TypedDict("EmailPara", {
  "type": Literal["text","image","link","remark"],
  "value": str,
})

EmailTpl: TypeAlias = Literal["default","publish"]

EmailOpts: TypeAlias = TypedDict("EmailOpts", {
  "template": EmailTpl,
  "addressee": list[str]|str,
  "addressee_name": str,
  "subject": str,
  "paras": list[EmailPara],
})

# --- Jinja2 ---
VAR_LEVEL: TypeAlias = Literal[
  "global", # 初始化全局替换
  "task", # 任务初始化替换
  "loop", # 循环体内替换
]
