from typing import TypeAlias,TypedDict,Any,Callable,Literal
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.shadowroot import ShadowRoot
from selenium.webdriver.remote.webelement import WebElement

# all kinds of root element
SearchContext: TypeAlias = WebDriver | WebElement | ShadowRoot
# as element query"s target element
ElementTarget: TypeAlias = str | list[str] | WebElement | list[WebElement]
# as element query"s root element
ElementRoot: TypeAlias = str | SearchContext
