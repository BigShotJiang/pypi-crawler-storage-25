from typing import TypeAlias,TypedDict
from blues_lib.types.ability import AttemptDelay,ToolDef

AttemptBy: TypeAlias = int | str | list[dict] | list[str]

ToolSummary: TypeAlias = TypedDict("ToolSummary", {
  "attempt_by":AttemptBy,
  "attempts": int, # for loop and pagination
  "attempt_delay": AttemptDelay,
  "prev_tools": list[ToolDef],
  "post_tools": list[ToolDef],
})

SeqOpts: TypeAlias = TypedDict("SeqOpts", {

  "single": ToolSummary, # for standard and order
  "loop": ToolSummary, # for each, element, item, count
  "page": ToolSummary, # for number and next
  "combo": ToolSummary, # for para
  
  "tools": list[ToolDef]|dict[str,ToolDef], 

})
