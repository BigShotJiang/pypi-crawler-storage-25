from typing import TypeAlias,TypedDict,Literal

MatFilterOpts: TypeAlias = TypedDict("MatFilterOpts", {
  "unique_field":str,
})

MatPersistorOpts: TypeAlias = TypedDict("MatPersistorOpts", {
  "method":Literal["insert","update","delete"], 
  "sources":list[Literal["entities","trash","all"]], 
  "inc_pattern":str,
})

MatPreparerOpts: TypeAlias = TypedDict("MatPreparerOpts", {
  "mat_chan":dict,
  "mat_url":dict,
  "mat_thumb":dict,
  "mat_title":dict,
  "mat_paras":dict,
})

MatChainRule: TypeAlias = TypedDict("MatChainRule", {
  "filter":MatFilterOpts,
  "persistor":MatPersistorOpts,
  "preparer":MatPreparerOpts,
})

MatChainRequest: TypeAlias = TypedDict("MatChainRequest", {
  "rule":MatChainRule,
  "entities": list[dict],
})