import re
from blues_lib.types.ability import ToolExpect

class Expecter:

  @classmethod
  def to_be(cls, expect: ToolExpect) -> bool:
    """Check if the result equals the expected value."""
    return cls.to_equal(expect)

  @classmethod
  def not_to_be(cls, expect: ToolExpect) -> bool:
    """Check if the result does not equal the expected value."""
    return cls.not_to_equal(expect)

  @classmethod
  def to_equal(cls, expect: ToolExpect) -> bool:
    """Check if the result deeply equals the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return result == value

  @classmethod
  def not_to_equal(cls, expect: ToolExpect) -> bool:
    """Check if the result does not deeply equal the expected value."""
    return not cls.to_equal(expect)

  @classmethod
  def to_be_null(cls, expect: ToolExpect) -> bool:
    """Check if the result is None."""
    result = expect.get("result")
    return result is None

  @classmethod
  def not_to_be_null(cls, expect: ToolExpect) -> bool:
    """Check if the result is not None."""
    return not cls.to_be_null(expect)

  @classmethod
  def to_be_truthy(cls, expect: ToolExpect) -> bool:
    """Check if the result is truthy."""
    result = expect.get("result")
    return bool(result) is True

  @classmethod
  def not_to_be_truthy(cls, expect: ToolExpect) -> bool:
    """Check if the result is not truthy."""
    return not cls.to_be_truthy(expect)

  @classmethod
  def to_be_falsy(cls, expect: ToolExpect) -> bool:
    """Check if the result is falsy."""
    result = expect.get("result")
    return bool(result) is False

  @classmethod
  def not_to_be_falsy(cls, expect: ToolExpect) -> bool:
    """Check if the result is not falsy."""
    return not cls.to_be_falsy(expect)

  @classmethod
  def to_be_greater_than(cls, expect: ToolExpect) -> bool:
    """Check if the result is greater than the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return float(result) > float(value)

  @classmethod
  def not_to_be_greater_than(cls, expect: ToolExpect) -> bool:
    """Check if the result is not greater than the expected value."""
    return not cls.to_be_greater_than(expect)

  @classmethod
  def to_be_less_than(cls, expect: ToolExpect) -> bool:
    """Check if the result is less than the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return float(result) < float(value)

  @classmethod
  def not_to_be_less_than(cls, expect: ToolExpect) -> bool:
    """Check if the result is not less than the expected value."""
    return not cls.to_be_less_than(expect)

  @classmethod
  def to_be_greater_than_or_equal(cls, expect: ToolExpect) -> bool:
    """Check if the result is greater than or equal to the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return float(result) >= float(value)

  @classmethod
  def not_to_be_greater_than_or_equal(cls, expect: ToolExpect) -> bool:
    """Check if the result is not greater than or equal to the expected value."""
    return not cls.to_be_greater_than_or_equal(expect)

  @classmethod
  def to_be_less_than_or_equal(cls, expect: ToolExpect) -> bool:
    """Check if the result is less than or equal to the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return float(result) <= float(value)

  @classmethod
  def not_to_be_less_than_or_equal(cls, expect: ToolExpect) -> bool:
    """Check if the result is not less than or equal to the expected value."""
    return not cls.to_be_less_than_or_equal(expect)

  @classmethod
  def to_contain(cls, expect: ToolExpect) -> bool:
    """Check if the result contains the expected value."""
    result = expect.get("result")
    value = expect.get("value")
    return value in result

  @classmethod
  def not_to_contain(cls, expect: ToolExpect) -> bool:
    """Check if the result does not contain the expected value."""
    return not cls.to_contain(expect)

  @classmethod
  def to_match(cls, expect: ToolExpect) -> bool:
    """Check if the result matches the expected regex pattern."""
    result = expect.get("result")
    value = expect.get("value")
    return bool(re.search(value, result))

  @classmethod
  def not_to_match(cls, expect: ToolExpect) -> bool:
    """Check if the result does not match the expected regex pattern."""
    return not cls.to_match(expect)

  @classmethod
  def to_have_length(cls, expect: ToolExpect) -> bool:
    """Check if the result has the expected length."""
    result = expect.get("result")
    value = int(expect.get("value"))
    return len(result) == value

  @classmethod
  def not_to_have_length(cls, expect: ToolExpect) -> bool:
    """Check if the result does not have the expected length."""
    return not cls.to_have_length(expect)

  @classmethod
  def to_have_length_greater_than(cls, expect: ToolExpect) -> bool:
    """Check if the result has a length greater than the expected value."""
    result = expect.get("result")
    value = int(expect.get("value"))
    return len(result) > value
  
  @classmethod
  def not_to_have_length_greater_than(cls, expect: ToolExpect) -> bool:
    """Check if the result does not have a length greater than the expected value."""
    return not cls.to_have_length_greater_than(expect)

  @classmethod
  def to_have_property(cls, expect: ToolExpect) -> bool:
    """Check if the result has the expected property."""
    result = expect.get("result")
    value = expect.get("value")
    return value in result

  @classmethod
  def not_to_have_property(cls, expect: ToolExpect) -> bool:
    """Check if the result does not have the expected property."""
    return not cls.to_have_property(expect)
