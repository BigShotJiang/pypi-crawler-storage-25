from typing import Any
from blues_lib.supports.dp.exception import (
  BlockException,
  SkipAbilityException,
  SkipSeqException,
  SkipTaskException,
  SkipFlowException,
  RetryException,
  FailTaskException,
)
from blues_lib.types import ToolExpect
from blues_lib.services.expecter.Expecter import Expecter

class Matcher:

  _EXCEPTIONS = {
    BlockException.__name__:BlockException,
    SkipAbilityException.__name__:SkipAbilityException,
    SkipSeqException.__name__:SkipSeqException,
    SkipTaskException.__name__:SkipTaskException,
    SkipFlowException.__name__:SkipFlowException,
    RetryException.__name__:RetryException,
    FailTaskException.__name__:FailTaskException,
  }

  @classmethod
  def match(cls,title:str,opts:dict,result:Any)->None:
    if not opts:
      return

    expect_opts:ToolExpect|list[Any] = opts.get('expect',{})
    if not expect_opts:
      return
    
    expect_opts = cls.get_std_except(expect_opts,result)
    method:str = expect_opts.get('method')
    value:Any = expect_opts.get('value')
    matcher = getattr(Expecter, method, None)
    if not matcher:
      message = f"Invalid expect method: {method}"
      raise ValueError(message)

    if not matcher(expect_opts):
      expect_exception:str = expect_opts.get('exception')
      if not expect_exception in cls._EXCEPTIONS.keys():
        raise ValueError(f"Invalid expect exception: {expect_exception}")

      exception_class = cls._EXCEPTIONS.get(expect_exception)
      message = f"{title or 'Expecter'} : expect {method} {value}, but got {result}"
      raise exception_class(result, message)
    
  @classmethod
  def get_std_except(cls,expect:list[Any]|ToolExpect,result:Any)->ToolExpect:
    if isinstance(expect,list):
      expect =  (expect + [None]*3)[:3]
      method:str = expect[0]
      value:Any = expect[1]
      exception:str = expect[2]
      expect:ToolExpect = {
        "method":method,
        "value":value,
        "exception":exception
      }
    
    if not expect.get('method'):
      expect['method'] = 'to_be'
    if not expect.get('exception'):
      expect['exception'] = 'SkipSeqException'
    expect['result'] = result
    return expect