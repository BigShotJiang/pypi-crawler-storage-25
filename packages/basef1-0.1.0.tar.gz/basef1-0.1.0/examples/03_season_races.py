"""Races for a single season."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        resp = client.query().season(2025).get_races(limit=30)
        _summary.print_pagination(resp, "2025 races")
        table = resp.get_data()
        races = table.get("Races") if isinstance(table, dict) else None
        if isinstance(races, list):
            for r in races:
                if isinstance(r, dict):
                    print(f"  Round {r.get('round')}: {r.get('raceName')} ({r.get('date')})")


if __name__ == "__main__":
    main()
