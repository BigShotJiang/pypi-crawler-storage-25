"""Races in which a constructor participated (path filter)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        resp = client.query().constructor("ferrari").get_races(limit=5)
        _summary.print_pagination(resp, "Ferrari races (sample)")


if __name__ == "__main__":
    main()
