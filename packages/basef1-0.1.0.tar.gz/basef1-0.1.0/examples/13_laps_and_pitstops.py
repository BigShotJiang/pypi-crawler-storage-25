"""Laps and pit stops for a specific season and round."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        q = client.query().season(2024).round(1)
        _summary.print_pagination(q.get_laps(limit=5), "2024 R1 laps (first page)")
        _summary.print_pagination(q.get_pitstops(limit=5), "2024 R1 pit stops (first page)")


if __name__ == "__main__":
    main()
