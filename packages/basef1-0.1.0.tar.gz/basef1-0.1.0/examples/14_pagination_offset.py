"""Pagination: ``limit`` and ``offset`` query parameters."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        first = client.query().get_races(limit=2, offset=0)
        second = client.query().get_races(limit=2, offset=2)
        _summary.print_pagination(first, "Races page 0")
        _summary.print_pagination(second, "Races page 1 (offset=2)")


if __name__ == "__main__":
    main()
