"""Global championship seasons (shorthand on the client)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        resp = client.get_seasons(limit=5)
        _summary.print_pagination(resp, "Seasons")
        table = resp.get_data()
        seasons = table.get("Seasons") if isinstance(table, dict) else None
        if isinstance(seasons, list) and seasons:
            first = seasons[0]
            if isinstance(first, dict):
                print("First season keys:", sorted(first.keys()))


if __name__ == "__main__":
    main()
