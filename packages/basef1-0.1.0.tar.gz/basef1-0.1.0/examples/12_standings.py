"""Driver and constructor standings (Jolpica requires a season year)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        q = client.query().season(2024)
        _summary.print_pagination(q.get_driver_standings(limit=5), "2024 driver standings")
        _summary.print_pagination(
            q.get_constructor_standings(limit=5),
            "2024 constructor standings",
        )


if __name__ == "__main__":
    main()
