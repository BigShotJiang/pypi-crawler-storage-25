"""Finishing status id catalogue (``get_statuses()`` terminal)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        resp = client.get_statuses(limit=10)
        _summary.print_pagination(resp, "Status catalogue")
        table = resp.get_data()
        rows = table.get("Status") if isinstance(table, dict) else None
        if isinstance(rows, list):
            for row in rows[:5]:
                if isinstance(row, dict):
                    print(f"  id={row.get('statusId')} — {row.get('status')}")


if __name__ == "__main__":
    main()
