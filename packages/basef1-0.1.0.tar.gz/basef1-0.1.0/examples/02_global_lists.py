"""Unfiltered global lists: races, drivers, constructors, circuits (small limit)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        q = client.query()
        _summary.print_pagination(q.get_races(limit=3), "Races (global)")
        _summary.print_pagination(q.get_drivers(limit=3), "Drivers (global)")
        _summary.print_pagination(q.get_constructors(limit=3), "Constructors (global)")
        _summary.print_pagination(q.get_circuits(limit=3), "Circuits (global)")


if __name__ == "__main__":
    main()
