"""Results for one driver in one season (path order: season, then driver)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        resp = client.query().season(2024).driver("hamilton").get_results(limit=5)
        _summary.print_pagination(resp, "Hamilton 2024 results (sample)")


if __name__ == "__main__":
    main()
