"""Races where someone started from a given grid slot (path filter)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        resp = client.query().grid(1).get_races(limit=5)
        _summary.print_pagination(resp, "Races with grid 1 (sample)")


if __name__ == "__main__":
    main()
