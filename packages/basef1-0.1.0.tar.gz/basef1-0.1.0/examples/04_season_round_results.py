"""Race results for a specific season and round."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        resp = client.query().season(2024).round(1).get_results(limit=10)
        _summary.print_pagination(resp, "2024 round 1 results")
        table = resp.get_data()
        races = table.get("Races") if isinstance(table, dict) else None
        if isinstance(races, list) and races:
            race = races[0]
            if isinstance(race, dict):
                results = race.get("Results")
                if isinstance(results, list):
                    for row in results[:5]:
                        if isinstance(row, dict):
                            pos = row.get("position")
                            no = row.get("number")
                            drv = row.get("Driver") or {}
                            code = drv.get("code") if isinstance(drv, dict) else None
                            print(f"  P{pos} #{no} {code}")


if __name__ == "__main__":
    main()
