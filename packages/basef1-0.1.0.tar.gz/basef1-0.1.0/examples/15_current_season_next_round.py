"""Season keyword ``current`` and round keyword ``next`` / ``last``."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        races_next = client.query().season("current").round("next").get_races(limit=1)
        _summary.print_pagination(races_next, "Current season — next race")
        races_last = client.query().season("current").round("last").get_results(limit=3)
        _summary.print_pagination(races_last, "Current season — last round results (sample)")


if __name__ == "__main__":
    main()
