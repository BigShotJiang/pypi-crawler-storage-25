"""Races held at a specific circuit (path filter)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        resp = client.query().circuit("monza").get_races(limit=5)
        _summary.print_pagination(resp, "Races at Monza")
        print(resp)


if __name__ == "__main__":
    main()
