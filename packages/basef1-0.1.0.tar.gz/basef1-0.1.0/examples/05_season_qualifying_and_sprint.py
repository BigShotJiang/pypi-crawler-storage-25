"""Qualifying and sprint data for a season (optionally narrow with round in your own calls)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        q = client.query().season(2024)
        _summary.print_pagination(q.get_qualifying(limit=5), "2024 qualifying (first page)")
        _summary.print_pagination(q.get_sprint(limit=5), "2024 sprint (first page)")


if __name__ == "__main__":
    main()
