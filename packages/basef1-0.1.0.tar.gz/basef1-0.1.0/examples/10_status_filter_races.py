"""Races featuring a given finishing status id (``with_status`` path segment)."""

from __future__ import annotations

import _summary
from basef1 import BaseF1Client


def main() -> None:
    with BaseF1Client() as client:
        resp = client.query().with_status(1).get_races(limit=5)
        _summary.print_pagination(resp, "Races with status id 1 (sample)")


if __name__ == "__main__":
    main()
