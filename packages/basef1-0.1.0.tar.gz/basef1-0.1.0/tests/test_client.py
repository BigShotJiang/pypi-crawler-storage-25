"""Unit tests with mocked HTTP."""

from __future__ import annotations

import httpx
import pytest

from basef1 import ApiResponse, BaseF1Client, JolpicaHTTPError
from basef1.domain.tables import RaceTable


def _ok_client() -> BaseF1Client:
    transport = httpx.MockTransport(lambda r: httpx.Response(200, json={}))
    return BaseF1Client(client=httpx.Client(transport=transport), cache=False)


def _mrdata_sample() -> dict:
    return {
        "MRData": {
            "xmlns": "",
            "series": "f1",
            "url": "http://api.jolpi.ca/ergast/f1/circuits/monza/races/",
            "limit": "30",
            "offset": "0",
            "total": "1",
            "RaceTable": {"Races": []},
        }
    }


def test_circuit_races_url_and_json() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["params"] = dict(request.url.params)
        return httpx.Response(200, json=_mrdata_sample())

    transport = httpx.MockTransport(handler)
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache=False)
        resp = client.query().circuit("monza").get_races(limit=50, offset=10)

    url = str(captured["url"])
    assert "/ergast/f1/circuits/monza/races.json" in url
    assert captured["params"] == {"limit": "50", "offset": "10"}
    assert resp.kind == "RaceTable"
    assert isinstance(resp.data, RaceTable)
    assert resp.pagination.total == "1"
    assert resp.pagination.total_int == 1


def test_season_round_get_results() -> None:
    captured: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        return httpx.Response(200, json=_mrdata_sample())

    transport = httpx.MockTransport(handler)
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache=False)
        client.query().season(2024).round(5).get_results()

    assert captured["url"].endswith("/ergast/f1/2024/5/results.json")


def test_round_requires_season() -> None:
    client = _ok_client()
    with pytest.raises(ValueError, match="season"):
        client.query().round(3)


def test_round_requires_season_not_circuit() -> None:
    client = _ok_client()
    with pytest.raises(ValueError, match="season"):
        client.query().circuit("monza").round(3)


def test_limit_validation() -> None:
    client = _ok_client()
    with pytest.raises(ValueError):
        client.query().get_seasons(limit=0)
    with pytest.raises(ValueError):
        client.query().get_seasons(limit=101)


def test_http_error_raises() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="nope")

    transport = httpx.MockTransport(handler)
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache=False)
        with pytest.raises(JolpicaHTTPError) as exc_info:
            client.query().get_seasons()
        assert exc_info.value.status_code == 500


def test_invalid_json_raises() -> None:
    transport = httpx.MockTransport(lambda r: httpx.Response(200, text="not-json"))
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache=False)
        with pytest.raises(JolpicaHTTPError, match="JSON"):
            client.query().get_seasons()


def test_client_seasons_shorthand() -> None:
    captured: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        return httpx.Response(200, json=_mrdata_sample())

    transport = httpx.MockTransport(handler)
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache=False)
        client.get_seasons()

    assert "seasons.json" in captured["url"]


def test_with_status_filter() -> None:
    captured: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        return httpx.Response(200, json=_mrdata_sample())

    transport = httpx.MockTransport(handler)
    with httpx.Client(transport=transport) as http_client:
        client = BaseF1Client(client=http_client, cache=False)
        client.query().with_status(2).get_races()

    assert captured["url"].endswith("/ergast/f1/status/2/races.json")


def test_get_data_race_table() -> None:
    resp = ApiResponse(raw=_mrdata_sample())
    assert resp.get_data() == {"Races": []}


def test_get_data_season_table() -> None:
    data = {
        "MRData": {
            "xmlns": "",
            "series": "f1",
            "url": "http://example/ergast/f1/seasons/",
            "limit": "30",
            "offset": "0",
            "total": "77",
            "SeasonTable": {"Seasons": [{"season": "2024"}]},
        }
    }
    resp = ApiResponse(raw=data)
    assert resp.get_data() == {"Seasons": [{"season": "2024"}]}


def test_get_data_empty_mrdata() -> None:
    resp = ApiResponse(raw={"MRData": {}})
    assert resp.get_data() == {}


def test_get_data_unknown_table_fallback() -> None:
    data = {
        "MRData": {
            "series": "f1",
            "url": "http://example/",
            "limit": "1",
            "offset": "0",
            "total": "1",
            "FutureThingTable": {"items": [1]},
        }
    }
    resp = ApiResponse(raw=data)
    assert resp.get_data() == {"items": [1]}


def test_get_data_missing_mrdata() -> None:
    resp = ApiResponse(raw={})
    assert resp.get_data() == {}
