"""Typed parsing and serialization."""

from __future__ import annotations

from basef1.domain import Circuit, Driver, Location, Race
from basef1.domain.parse import RawTable, parse_api_response
from basef1.domain.race_graph import RaceResult
from basef1.domain.tables import RaceTable, SeasonTable, StandingsTable
from basef1.models import ApiResponse


def _race_with_circuit_json() -> dict:
    return {
        "MRData": {
            "series": "f1",
            "limit": "30",
            "offset": "0",
            "total": "1",
            "RaceTable": {
                "season": "2024",
                "Races": [
                    {
                        "season": "2024",
                        "round": "1",
                        "raceName": "Bahrain Grand Prix",
                        "date": "2024-03-02",
                        "Circuit": {
                            "circuitId": "bahrain",
                            "circuitName": "Bahrain International Circuit",
                            "Location": {
                                "lat": "26.0325",
                                "long": "50.5106",
                                "locality": "Sakhir",
                                "country": "Bahrain",
                            },
                        },
                    }
                ],
            },
        }
    }


def test_parse_race_table_nested_location() -> None:
    resp = ApiResponse(raw=_race_with_circuit_json())
    parsed = parse_api_response(resp)
    assert parsed.kind == "RaceTable"
    assert isinstance(parsed.data, RaceTable)
    assert len(parsed.data.races) == 1
    race = parsed.data.races[0]
    assert race.race_name == "Bahrain Grand Prix"
    assert race.circuit is not None
    assert race.circuit.circuit_id == "bahrain"
    assert race.circuit.location is not None
    assert race.circuit.location.locality == "Sakhir"
    assert race.circuit.location.longitude == "50.5106"


def test_parse_race_nested_types_are_typed_objects() -> None:
    resp = ApiResponse(raw=_race_with_circuit_json())
    parsed = parse_api_response(resp)
    race = parsed.data.races[0]
    assert isinstance(race, Race)
    assert isinstance(race.circuit, Circuit)
    assert isinstance(race.circuit.location, Location)


def test_race_result_round_trip_dict() -> None:
    raw = {
        "number": "1",
        "position": "1",
        "Driver": {
            "driverId": "max_verstappen",
            "givenName": "Max",
            "familyName": "Verstappen",
        },
        "Constructor": {"constructorId": "red_bull", "name": "Red Bull"},
        "Time": {"millis": "9000000", "time": "1:30.000"},
    }
    rr = RaceResult.from_dict(raw)
    out = rr.to_dict()
    assert out["number"] == "1"
    assert out["Driver"]["driverId"] == "max_verstappen"
    assert out["Time"]["time"] == "1:30.000"


def test_parse_season_table() -> None:
    resp = ApiResponse(
        raw={
            "MRData": {
                "limit": "30",
                "offset": "0",
                "total": "2",
                "SeasonTable": {"Seasons": [{"season": "2024"}, {"season": "2023"}]},
            }
        }
    )
    p = parse_api_response(resp)
    assert p.kind == "SeasonTable"
    assert isinstance(p.data, SeasonTable)
    assert len(p.data.seasons) == 2


def test_parse_standings_driver_nested() -> None:
    resp = ApiResponse(
        raw={
            "MRData": {
                "limit": "30",
                "offset": "0",
                "total": "1",
                "StandingsTable": {
                    "season": "2024",
                    "StandingsLists": [
                        {
                            "season": "2024",
                            "round": "24",
                            "DriverStandings": [
                                {
                                    "position": "1",
                                    "points": "437",
                                    "wins": "9",
                                    "Driver": {
                                        "driverId": "norris",
                                        "givenName": "Lando",
                                        "familyName": "Norris",
                                    },
                                    "Constructors": [
                                        {"constructorId": "mclaren", "name": "McLaren"}
                                    ],
                                }
                            ],
                        }
                    ],
                },
            }
        }
    )
    p = parse_api_response(resp)
    assert isinstance(p.data, StandingsTable)
    sl = p.data.standings_lists[0]
    row = sl.driver_standings[0]
    assert row.driver is not None
    assert row.driver.family_name == "Norris"
    assert len(row.constructors) == 1
    assert row.constructors[0].name == "McLaren"


def test_unknown_table_raw_data() -> None:
    resp = ApiResponse(
        raw={
            "MRData": {
                "limit": "1",
                "offset": "0",
                "total": "1",
                "FutureThingTable": {"foo": [{"bar": 1}]},
            }
        }
    )
    p = parse_api_response(resp)
    assert p.kind == "FutureThingTable"
    assert isinstance(p.data, RawTable)
    assert p.data.data["foo"][0]["bar"] == 1


def test_parse_method() -> None:
    resp = ApiResponse(raw=_race_with_circuit_json())
    p = resp.parse()
    assert p.kind == "RaceTable"


def test_driver_from_dict_minimal() -> None:
    d = Driver.from_dict({"driverId": "pilot", "code": "PLT"})
    assert d.to_dict() == {"driverId": "pilot", "code": "PLT"}
