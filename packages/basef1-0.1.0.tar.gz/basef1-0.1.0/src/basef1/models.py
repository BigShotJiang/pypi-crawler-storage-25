"""Lightweight response wrappers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from basef1.domain.parse import ParsedApiResponse

from basef1.constants import MRDATA_METADATA_KEYS, MRDATA_TABLE_PRIORITY


@dataclass(frozen=True)
class Pagination:
    """Pagination fields from MRData (API returns string values)."""

    limit: str | None
    offset: str | None
    total: str | None

    @property
    def total_int(self) -> int | None:
        if self.total is None:
            return None
        try:
            return int(self.total)
        except ValueError:
            return None


@dataclass(frozen=True)
class ApiResponse:
    """Parsed JSON body with helpers for MRData and pagination."""

    raw: dict[str, Any]

    @property
    def mrdata(self) -> dict[str, Any]:
        data = self.raw.get("MRData")
        return data if isinstance(data, dict) else {}

    @property
    def pagination(self) -> Pagination:
        md = self.mrdata
        return Pagination(
            limit=_as_str(md.get("limit")),
            offset=_as_str(md.get("offset")),
            total=_as_str(md.get("total")),
        )

    def get_data(self) -> dict[str, Any]:
        """
        Return the primary data table under ``MRData`` (e.g. ``RaceTable``),
        without hard-coding the key.

        Tries keys in ``MRDATA_TABLE_PRIORITY`` first, then any other ``*Table``
        dict value (excluding metadata keys). Returns ``{}`` if none found.
        """
        md = self.mrdata
        for key in MRDATA_TABLE_PRIORITY:
            value = md.get(key)
            if isinstance(value, dict):
                return value
        for key, value in md.items():
            if key in MRDATA_METADATA_KEYS:
                continue
            if isinstance(value, dict) and key.endswith("Table"):
                return value
        return {}

    def parse(self) -> ParsedApiResponse:
        """Parse MRData into :class:`~basef1.domain.parse.ParsedApiResponse`."""
        from basef1.domain.parse import parse_api_response

        return parse_api_response(self)


def _as_str(value: Any) -> str | None:
    if value is None:
        return None
    return str(value)
