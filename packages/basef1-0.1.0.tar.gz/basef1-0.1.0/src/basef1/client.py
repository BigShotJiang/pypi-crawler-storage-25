"""HTTP client for the Jolpica F1 API."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

import httpx

if TYPE_CHECKING:
    from basef1.query import F1Query

from basef1.cache import TTLCache, cache_key_for_request
from basef1.exceptions import JolpicaHTTPError
from basef1.models import ApiResponse

DEFAULT_BASE_URL = "https://api.jolpi.ca/ergast/f1"
DEFAULT_CACHE_TTL_SECONDS = 300.0


def _validate_limit(limit: int | None) -> None:
    if limit is None:
        return
    if not isinstance(limit, int) or limit < 1 or limit > 100:
        raise ValueError("limit must be an integer between 1 and 100")


def _validate_offset(offset: int | None) -> None:
    if offset is None:
        return
    if not isinstance(offset, int) or offset < 0:
        raise ValueError("offset must be a non-negative integer")


class BaseF1Client:
    """
    Sync client for https://api.jolpi.ca/ergast/f1 (JSON).

    By default responses are cached in memory (``TTLCache``) to reduce duplicate
    GET traffic. Pass ``cache=False`` to disable caching, or pass ``cache=`` /
    ``cache_ttl=`` to customize.

    Pass a custom ``httpx.Client`` for tests or advanced configuration.
    If ``client`` is omitted, an internal client is created and closed when
    this instance is used as a context manager.
    """

    def __init__(
        self,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float | httpx.Timeout | None = 30.0,
        client: httpx.Client | None = None,
        cache: TTLCache | Literal[False] | None = None,
        cache_ttl: float | None = None,
        cache_max_entries: int = 256,
    ) -> None:
        if cache is not None and cache is not False and cache_ttl is not None:
            raise ValueError("Pass either cache= or cache_ttl=, not both.")
        if cache is False and cache_ttl is not None:
            raise ValueError("cache=False cannot be combined with cache_ttl=.")
        self._base_url = base_url.rstrip("/") + "/"
        self._owns_client = client is None
        self._client = client or httpx.Client(timeout=timeout)
        if cache is False:
            self._cache: TTLCache | None = None
        elif cache is not None:
            self._cache = cache
        elif cache_ttl is not None:
            self._cache = TTLCache(max_entries=cache_max_entries, ttl_seconds=cache_ttl)
        else:
            self._cache = TTLCache(
                max_entries=cache_max_entries,
                ttl_seconds=DEFAULT_CACHE_TTL_SECONDS,
            )

    @property
    def base_url(self) -> str:
        return self._base_url.rstrip("/")

    @property
    def http_client(self) -> httpx.Client:
        return self._client

    def __enter__(self) -> BaseF1Client:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def query(self) -> F1Query:
        from basef1.query import F1Query as F1QueryBuilder

        return F1QueryBuilder(self, [])

    def get_seasons(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ApiResponse:
        return self.query().get_seasons(limit=limit, offset=offset)

    def get_statuses(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ApiResponse:
        return self.query().get_statuses(limit=limit, offset=offset)

    def _request(
        self,
        path_segments: list[str],
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ApiResponse:
        _validate_limit(limit)
        _validate_offset(offset)
        base = self._base_url.rstrip("/")
        path = "/".join(s for s in path_segments if s).strip("/")
        if not path:
            raise ValueError("path_segments must not be empty")
        url = f"{base}/{path}.json"

        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        cache_key = cache_key_for_request("GET", url, params)
        if self._cache is not None:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return ApiResponse(raw=cached)        

        try:
            response = self._client.get(url, params=params or None)
        except httpx.HTTPError as exc:
            raise JolpicaHTTPError(
                f"HTTP transport error: {exc}",
                status_code=-1,
                body=None,
            ) from exc

        if response.status_code >= 400:
            text = response.text[:500] if response.text else None
            raise JolpicaHTTPError(
                f"HTTP {response.status_code} for {url}",
                status_code=response.status_code,
                body=text,
            )

        try:
            data = response.json()
        except ValueError as exc:
            raise JolpicaHTTPError(
                "Response body is not valid JSON",
                status_code=response.status_code,
                body=response.text[:500] if response.text else None,
            ) from exc

        if not isinstance(data, dict):
            raise JolpicaHTTPError(
                "Top-level JSON value must be an object",
                status_code=response.status_code,
                body=None,
            )

        if self._cache is not None:
            self._cache.set(cache_key, data)

        return ApiResponse(raw=data)
