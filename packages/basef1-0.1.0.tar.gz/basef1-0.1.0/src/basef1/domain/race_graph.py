"""Race-centric nested graphs: results, laps, qualifying rows."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from basef1.domain.base import JolpicaModel, ensure_list, optional_model
from basef1.domain.entities import (
    Circuit,
    Constructor,
    Driver,
    FastestLap,
    Session,
    TimeElement,
)


def _session(key: str, data: dict[str, Any]) -> Session | None:
    raw = data.get(key)
    return optional_model(Session, raw) if isinstance(raw, dict) else None


@dataclass(frozen=True)
class LapTimingEntry(JolpicaModel):
    driver_id: str | None = field(default=None, metadata={"key": "driverId"})
    position: str | None = None
    time: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LapTimingEntry:
        return cls(
            driver_id=data.get("driverId"),
            position=data.get("position"),
            time=data.get("time"),
        )


@dataclass(frozen=True)
class LapRow(JolpicaModel):
    number: str | None = None
    timings: list[LapTimingEntry] = field(default_factory=list, metadata={"key": "Timings"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LapRow:
        raw_timings = ensure_list(data.get("Timings"))
        timings = [LapTimingEntry.from_dict(x) for x in raw_timings if isinstance(x, dict)]
        return cls(number=data.get("number"), timings=timings)


@dataclass(frozen=True)
class PitStopRow(JolpicaModel):
    driver_id: str | None = field(default=None, metadata={"key": "driverId"})
    lap: str | None = None
    stop: str | None = None
    time: str | None = None
    duration: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PitStopRow:
        return cls(
            driver_id=data.get("driverId"),
            lap=data.get("lap"),
            stop=data.get("stop"),
            time=data.get("time"),
            duration=data.get("duration"),
        )


@dataclass(frozen=True)
class RaceResult(JolpicaModel):
    number: str | None = None
    position: str | None = None
    position_text: str | None = field(default=None, metadata={"key": "positionText"})
    points: str | None = None
    grid: str | None = None
    laps: str | None = None
    status: str | None = None
    driver: Driver | None = field(default=None, metadata={"key": "Driver"})
    constructor: Constructor | None = field(default=None, metadata={"key": "Constructor"})
    time: TimeElement | None = field(default=None, metadata={"key": "Time"})
    fastest_lap: FastestLap | None = field(default=None, metadata={"key": "FastestLap"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RaceResult:
        te = data.get("Time")
        time_el = optional_model(TimeElement, te) if isinstance(te, dict) else None
        return cls(
            number=data.get("number"),
            position=data.get("position"),
            position_text=data.get("positionText"),
            points=data.get("points"),
            grid=data.get("grid"),
            laps=data.get("laps"),
            status=data.get("status"),
            driver=optional_model(Driver, data.get("Driver")),
            constructor=optional_model(Constructor, data.get("Constructor")),
            time=time_el,
            fastest_lap=optional_model(FastestLap, data.get("FastestLap")),
        )


@dataclass(frozen=True)
class QualifyingResult(JolpicaModel):
    number: str | None = None
    position: str | None = None
    driver: Driver | None = field(default=None, metadata={"key": "Driver"})
    constructor: Constructor | None = field(default=None, metadata={"key": "Constructor"})
    q1: str | None = field(default=None, metadata={"key": "Q1"})
    q2: str | None = field(default=None, metadata={"key": "Q2"})
    q3: str | None = field(default=None, metadata={"key": "Q3"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> QualifyingResult:
        return cls(
            number=data.get("number"),
            position=data.get("position"),
            driver=optional_model(Driver, data.get("Driver")),
            constructor=optional_model(Constructor, data.get("Constructor")),
            q1=data.get("Q1"),
            q2=data.get("Q2"),
            q3=data.get("Q3"),
        )


@dataclass(frozen=True)
class Race(JolpicaModel):
    season: str | None = None
    round: str | None = None
    url: str | None = None
    race_name: str | None = field(default=None, metadata={"key": "raceName"})
    circuit: Circuit | None = field(default=None, metadata={"key": "Circuit"})
    date: str | None = None
    time: str | None = None
    first_practice: Session | None = field(default=None, metadata={"key": "FirstPractice"})
    second_practice: Session | None = field(default=None, metadata={"key": "SecondPractice"})
    third_practice: Session | None = field(default=None, metadata={"key": "ThirdPractice"})
    qualifying: Session | None = field(default=None, metadata={"key": "Qualifying"})
    sprint: Session | None = field(default=None, metadata={"key": "Sprint"})
    sprint_qualifying: Session | None = field(
        default=None,
        metadata={"key": "SprintQualifying"},
    )
    sprint_shootout: Session | None = field(default=None, metadata={"key": "SprintShootout"})
    results: list[RaceResult] = field(default_factory=list, metadata={"key": "Results"})
    qualifying_results: list[QualifyingResult] = field(
        default_factory=list,
        metadata={"key": "QualifyingResults"},
    )
    laps: list[LapRow] = field(default_factory=list, metadata={"key": "Laps"})
    pit_stops: list[PitStopRow] = field(default_factory=list, metadata={"key": "PitStops"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Race:
        raw_results = ensure_list(data.get("Results"))
        results = [RaceResult.from_dict(x) for x in raw_results if isinstance(x, dict)]
        raw_qual = ensure_list(data.get("QualifyingResults"))
        qual_results = [QualifyingResult.from_dict(x) for x in raw_qual if isinstance(x, dict)]
        raw_laps = ensure_list(data.get("Laps"))
        laps = [LapRow.from_dict(x) for x in raw_laps if isinstance(x, dict)]
        raw_pits = ensure_list(data.get("PitStops"))
        pits = [PitStopRow.from_dict(x) for x in raw_pits if isinstance(x, dict)]
        return cls(
            season=data.get("season"),
            round=data.get("round"),
            url=data.get("url"),
            race_name=data.get("raceName"),
            circuit=optional_model(Circuit, data.get("Circuit")),
            date=data.get("date"),
            time=data.get("time"),
            first_practice=_session("FirstPractice", data),
            second_practice=_session("SecondPractice", data),
            third_practice=_session("ThirdPractice", data),
            qualifying=_session("Qualifying", data),
            sprint=_session("Sprint", data),
            sprint_qualifying=_session("SprintQualifying", data),
            sprint_shootout=_session("SprintShootout", data),
            results=results,
            qualifying_results=qual_results,
            laps=laps,
            pit_stops=pits,
        )
