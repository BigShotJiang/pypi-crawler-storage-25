"""Table-level datas under MRData (*Table keys)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from basef1.domain.base import JolpicaModel, ensure_list, optional_model
from basef1.domain.entities import Circuit, Constructor, Driver, Season, StatusRow
from basef1.domain.race_graph import Race


@dataclass(frozen=True)
class RaceTable(JolpicaModel):
    season: str | None = None
    round: str | None = None
    circuit_id: str | None = field(default=None, metadata={"key": "circuitId"})
    driver_id: str | None = field(default=None, metadata={"key": "driverId"})
    constructor_id: str | None = field(default=None, metadata={"key": "constructorId"})
    races: list[Race] = field(default_factory=list, metadata={"key": "Races"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RaceTable:
        raw = ensure_list(data.get("Races"))
        races = [Race.from_dict(x) for x in raw if isinstance(x, dict)]
        return cls(
            season=data.get("season"),
            round=data.get("round"),
            circuit_id=data.get("circuitId"),
            driver_id=data.get("driverId"),
            constructor_id=data.get("constructorId"),
            races=races,
        )


@dataclass(frozen=True)
class SeasonTable(JolpicaModel):
    seasons: list[Season] = field(default_factory=list, metadata={"key": "Seasons"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SeasonTable:
        raw = ensure_list(data.get("Seasons"))
        seasons = [Season.from_dict(x) for x in raw if isinstance(x, dict)]
        return cls(seasons=seasons)


@dataclass(frozen=True)
class DriverTable(JolpicaModel):
    drivers: list[Driver] = field(default_factory=list, metadata={"key": "Drivers"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DriverTable:
        raw = ensure_list(data.get("Drivers"))
        drivers = [Driver.from_dict(x) for x in raw if isinstance(x, dict)]
        return cls(drivers=drivers)


@dataclass(frozen=True)
class ConstructorTable(JolpicaModel):
    constructors: list[Constructor] = field(default_factory=list, metadata={"key": "Constructors"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ConstructorTable:
        raw = ensure_list(data.get("Constructors"))
        constructors = [Constructor.from_dict(x) for x in raw if isinstance(x, dict)]
        return cls(constructors=constructors)


@dataclass(frozen=True)
class CircuitTable(JolpicaModel):
    circuits: list[Circuit] = field(default_factory=list, metadata={"key": "Circuits"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CircuitTable:
        raw = ensure_list(data.get("Circuits"))
        circuits = [Circuit.from_dict(x) for x in raw if isinstance(x, dict)]
        return cls(circuits=circuits)


@dataclass(frozen=True)
class StatusTable(JolpicaModel):
    statuses: list[StatusRow] = field(default_factory=list, metadata={"key": "Status"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StatusTable:
        raw = ensure_list(data.get("Status"))
        rows = [StatusRow.from_dict(x) for x in raw if isinstance(x, dict)]
        return cls(statuses=rows)


@dataclass(frozen=True)
class DriverStandingRow(JolpicaModel):
    position: str | None = None
    position_text: str | None = field(default=None, metadata={"key": "positionText"})
    points: str | None = None
    wins: str | None = None
    driver: Driver | None = field(default=None, metadata={"key": "Driver"})
    constructors: list[Constructor] = field(default_factory=list, metadata={"key": "Constructors"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DriverStandingRow:
        raw_cons = ensure_list(data.get("Constructors"))
        constructors = [Constructor.from_dict(x) for x in raw_cons if isinstance(x, dict)]
        return cls(
            position=data.get("position"),
            position_text=data.get("positionText"),
            points=data.get("points"),
            wins=data.get("wins"),
            driver=optional_model(Driver, data.get("Driver")),
            constructors=constructors,
        )


@dataclass(frozen=True)
class ConstructorStandingRow(JolpicaModel):
    position: str | None = None
    position_text: str | None = field(default=None, metadata={"key": "positionText"})
    points: str | None = None
    wins: str | None = None
    constructor: Constructor | None = field(default=None, metadata={"key": "Constructor"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ConstructorStandingRow:
        return cls(
            position=data.get("position"),
            position_text=data.get("positionText"),
            points=data.get("points"),
            wins=data.get("wins"),
            constructor=optional_model(Constructor, data.get("Constructor")),
        )


@dataclass(frozen=True)
class StandingsList(JolpicaModel):
    season: str | None = None
    round: str | None = None
    driver_standings: list[DriverStandingRow] = field(
        default_factory=list,
        metadata={"key": "DriverStandings"},
    )
    constructor_standings: list[ConstructorStandingRow] = field(
        default_factory=list,
        metadata={"key": "ConstructorStandings"},
    )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StandingsList:
        ds_raw = ensure_list(data.get("DriverStandings"))
        cs_raw = ensure_list(data.get("ConstructorStandings"))
        ds_rows = [DriverStandingRow.from_dict(x) for x in ds_raw if isinstance(x, dict)]
        cs_rows = [ConstructorStandingRow.from_dict(x) for x in cs_raw if isinstance(x, dict)]
        return cls(
            season=data.get("season"),
            round=data.get("round"),
            driver_standings=ds_rows,
            constructor_standings=cs_rows,
        )


@dataclass(frozen=True)
class StandingsTable(JolpicaModel):
    season: str | None = None
    round: str | None = None
    driver_id: str | None = field(default=None, metadata={"key": "driverId"})
    constructor_id: str | None = field(default=None, metadata={"key": "constructorId"})
    standings_lists: list[StandingsList] = field(
        default_factory=list,
        metadata={"key": "StandingsLists"},
    )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StandingsTable:
        raw = ensure_list(data.get("StandingsLists"))
        lists = [StandingsList.from_dict(x) for x in raw if isinstance(x, dict)]
        return cls(
            season=data.get("season"),
            round=data.get("round"),
            driver_id=data.get("driverId"),
            constructor_id=data.get("constructorId"),
            standings_lists=lists,
        )


Table = (
    RaceTable
    | SeasonTable
    | DriverTable
    | ConstructorTable
    | CircuitTable
    | StatusTable
    | StandingsTable
)
