"""Dispatch MRData table datas to typed models."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from basef1.constants import MRDATA_METADATA_KEYS, MRDATA_TABLE_PRIORITY
from basef1.domain.tables import (
    CircuitTable,
    ConstructorTable,
    DriverTable,
    RaceTable,
    SeasonTable,
    StandingsTable,
    StatusTable,
    Table,
)
from basef1.models import ApiResponse, Pagination


def mrdata_table_key_and_data(mrdata: dict[str, Any]) -> tuple[str | None, dict[str, Any]]:
    """Return ``(table_key, data_dict)`` for the primary *Table under MRData."""
    for key in MRDATA_TABLE_PRIORITY:
        val = mrdata.get(key)
        if isinstance(val, dict):
            return key, val
    for key, value in mrdata.items():
        if key in MRDATA_METADATA_KEYS:
            continue
        if isinstance(value, dict) and key.endswith("Table"):
            return key, value
    return None, {}


_TABLE_FACTORY: dict[str, Callable[[dict[str, Any]], Table]] = {
    "RaceTable": RaceTable.from_dict,
    "SeasonTable": SeasonTable.from_dict,
    "DriverTable": DriverTable.from_dict,
    "ConstructorTable": ConstructorTable.from_dict,
    "CircuitTable": CircuitTable.from_dict,
    "StatusTable": StatusTable.from_dict,
    "StandingsTable": StandingsTable.from_dict,
}


@dataclass(frozen=True)
class RawTable:
    """Fallback when MRData contains an unknown ``*Table`` key or no table."""

    kind: str | None
    data: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return dict(self.data)


@dataclass(frozen=True)
class ParsedApiResponse:
    """Typed view of an ``ApiResponse``."""

    kind: str | None
    pagination: Pagination
    data: Table | RawTable


def parse_api_response(resp: ApiResponse) -> ParsedApiResponse:
    """Parse ``resp`` into a ``ParsedApiResponse`` based on the MRData table key."""
    md = resp.mrdata
    pag = resp.pagination
    kind, data = mrdata_table_key_and_data(md)
    if not kind or not data:
        return ParsedApiResponse(kind=None, pagination=pag, data=RawTable(None, {}))

    factory = _TABLE_FACTORY.get(kind)
    if factory is None:
        return ParsedApiResponse(
            kind=kind,
            pagination=pag,
            data=RawTable(kind, dict(data)),
        )
    return ParsedApiResponse(kind=kind, pagination=pag, data=factory(data))
