"""Leaf entities shared across Ergast / Jolpica datas."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from basef1.domain.base import JolpicaModel, optional_model


@dataclass(frozen=True)
class Location(JolpicaModel):
    lat: str | None = None
    longitude: str | None = field(default=None, metadata={"key": "long"})
    locality: str | None = None
    country: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Location:
        return cls(
            lat=data.get("lat"),
            longitude=data.get("long"),
            locality=data.get("locality"),
            country=data.get("country"),
        )


@dataclass(frozen=True)
class Circuit(JolpicaModel):
    circuit_id: str | None = field(default=None, metadata={"key": "circuitId"})
    url: str | None = None
    circuit_name: str | None = field(default=None, metadata={"key": "circuitName"})
    location: Location | None = field(default=None, metadata={"key": "Location"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Circuit:
        loc = optional_model(Location, data.get("Location"))
        return cls(
            circuit_id=data.get("circuitId"),
            url=data.get("url"),
            circuit_name=data.get("circuitName"),
            location=loc,
        )


@dataclass(frozen=True)
class Driver(JolpicaModel):
    driver_id: str | None = field(default=None, metadata={"key": "driverId"})
    permanent_number: str | None = field(default=None, metadata={"key": "permanentNumber"})
    code: str | None = None
    url: str | None = None
    given_name: str | None = field(default=None, metadata={"key": "givenName"})
    family_name: str | None = field(default=None, metadata={"key": "familyName"})
    date_of_birth: str | None = field(default=None, metadata={"key": "dateOfBirth"})
    nationality: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Driver:
        return cls(
            driver_id=data.get("driverId"),
            permanent_number=data.get("permanentNumber"),
            code=data.get("code"),
            url=data.get("url"),
            given_name=data.get("givenName"),
            family_name=data.get("familyName"),
            date_of_birth=data.get("dateOfBirth"),
            nationality=data.get("nationality"),
        )


@dataclass(frozen=True)
class Constructor(JolpicaModel):
    constructor_id: str | None = field(default=None, metadata={"key": "constructorId"})
    url: str | None = None
    name: str | None = None
    nationality: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Constructor:
        return cls(
            constructor_id=data.get("constructorId"),
            url=data.get("url"),
            name=data.get("name"),
            nationality=data.get("nationality"),
        )


@dataclass(frozen=True)
class StatusRow(JolpicaModel):
    status_id: str | None = field(default=None, metadata={"key": "statusId"})
    status: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StatusRow:
        return cls(
            status_id=data.get("statusId"),
            status=data.get("status"),
        )


@dataclass(frozen=True)
class Session(JolpicaModel):
    """Practice / qualifying / sprint session slot with date and time."""

    date: str | None = None
    time: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Session:
        return cls(date=data.get("date"), time=data.get("time"))


@dataclass(frozen=True)
class TimeElement(JolpicaModel):
    millis: str | None = None
    time: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TimeElement:
        return cls(millis=data.get("millis"), time=data.get("time"))


@dataclass(frozen=True)
class AverageSpeed(JolpicaModel):
    units: str | None = None
    speed: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AverageSpeed:
        return cls(units=data.get("units"), speed=data.get("speed"))


@dataclass(frozen=True)
class FastestLap(JolpicaModel):
    rank: str | None = None
    lap: str | None = None
    time: TimeElement | None = field(default=None, metadata={"key": "Time"})
    average_speed: AverageSpeed | None = field(default=None, metadata={"key": "AverageSpeed"})

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FastestLap:
        te = data.get("Time")
        time_el = optional_model(TimeElement, te) if isinstance(te, dict) else None
        avg = optional_model(AverageSpeed, data.get("AverageSpeed"))
        return cls(
            rank=data.get("rank"),
            lap=data.get("lap"),
            time=time_el,
            average_speed=avg,
        )


@dataclass(frozen=True)
class Season(JolpicaModel):
    season: str | None = None
    url: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Season:
        return cls(season=data.get("season"), url=data.get("url"))
