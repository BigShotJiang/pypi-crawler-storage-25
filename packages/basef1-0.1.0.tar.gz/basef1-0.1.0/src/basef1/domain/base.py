"""Base model type and JSON serialization helpers."""

from __future__ import annotations

from dataclasses import fields, is_dataclass
from typing import Any


def ensure_list(value: Any) -> list[Any]:
    """Normalize Ergast single-object-or-list JSON to a list."""
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


class JolpicaModel:
    """Mixin-style base: subclasses must be ``@dataclass`` instances."""

    __slots__ = ()

    def to_dict(self) -> dict[str, Any]:
        """Serialize using field metadata ``key`` for JSON names (defaults to field name)."""
        cls = type(self)
        if not is_dataclass(cls):
            raise TypeError(f"{cls.__name__} must be a dataclass subclass of JolpicaModel")
        return dump_dataclass(self)


def _dump(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, list):
        return [_dump(v) for v in value]
    if isinstance(value, dict):
        return {k: _dump(v) for k, v in value.items()}
    if is_dataclass(value) and not isinstance(value, type):
        return dump_dataclass(value)
    if isinstance(value, JolpicaModel) and is_dataclass(value) and not isinstance(value, type):
        return value.to_dict()
    raise TypeError(f"Unsupported type for serialization: {type(value)!r}")


def dump_dataclass(obj: Any) -> dict[str, Any]:
    """Serialize a dataclass using field metadata ``key`` for JSON property names."""
    if not is_dataclass(obj) or isinstance(obj, type):
        raise TypeError("dump_dataclass expects a dataclass instance")
    out: dict[str, Any] = {}
    for f in fields(obj):
        val = getattr(obj, f.name)
        if val is None:
            continue
        json_key = f.metadata.get("key", f.name)
        out[json_key] = _dump(val)
    return out


def optional_model(factory: Any, data: Any) -> Any:
    """Parse dict through factory.from_dict if data is a non-empty dict."""
    if not isinstance(data, dict) or not data:
        return None
    return factory.from_dict(data)
