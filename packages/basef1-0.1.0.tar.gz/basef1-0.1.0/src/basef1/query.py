"""Chainable path builder for Jolpica / Ergast-style URLs."""

from __future__ import annotations

from typing import TYPE_CHECKING

from basef1.models import ApiResponse

if TYPE_CHECKING:
    from basef1.client import BaseF1Client


class F1Query:
    """
    Build filter path segments, then call a terminal resource method.

    Invalid segment ordering is possible if methods are chained incorrectly;
    that matches raw REST usage. ``round()`` requires ``season()`` to have
    been called immediately before (last segment is a season year or
    ``current``).
    """

    __slots__ = ("_client", "_segments")

    def __init__(self, client: BaseF1Client, segments: list[str]) -> None:
        self._client = client
        self._segments = segments

    def season(self, year: int | str) -> F1Query:
        self._segments.append(str(year))
        return self

    def round(self, round_number: int | str) -> F1Query:
        if not self._segments:
            raise ValueError("round() requires season() to be called first")
        last = self._segments[-1]
        if last != "current" and not (last.isdigit() and len(last) == 4):
            raise ValueError("round() must immediately follow season(...)")
        self._segments.append(str(round_number))
        return self

    def circuit(self, circuit_id: str) -> F1Query:
        self._segments.extend(["circuits", circuit_id])
        return self

    def constructor(self, constructor_id: str) -> F1Query:
        self._segments.extend(["constructors", constructor_id])
        return self

    def driver(self, driver_id: str) -> F1Query:
        self._segments.extend(["drivers", driver_id])
        return self

    def grid(self, position: int | str) -> F1Query:
        self._segments.extend(["grid", str(position)])
        return self

    def with_status(self, status_id: int | str) -> F1Query:
        """Filter by finishing status id (path ``/status/{statusId}/``)."""
        self._segments.extend(["status", str(status_id)])
        return self

    def _resource(
        self,
        name: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ApiResponse:
        segments = [*self._segments, name]
        return self._client._request(segments, limit=limit, offset=offset).parse()

    def get_seasons(self, *, limit: int | None = None, offset: int | None = None) -> ApiResponse:
        return self._resource("seasons", limit=limit, offset=offset)

    def get_races(self, *, limit: int | None = None, offset: int | None = None) -> ApiResponse:
        return self._resource("races", limit=limit, offset=offset)

    def get_results(self, *, limit: int | None = None, offset: int | None = None) -> ApiResponse:
        return self._resource("results", limit=limit, offset=offset)

    def get_qualifying(self, *, limit: int | None = None, offset: int | None = None) -> ApiResponse:
        return self._resource("qualifying", limit=limit, offset=offset)

    def get_sprint(self, *, limit: int | None = None, offset: int | None = None) -> ApiResponse:
        return self._resource("sprint", limit=limit, offset=offset)

    def get_drivers(self, *, limit: int | None = None, offset: int | None = None) -> ApiResponse:
        return self._resource("drivers", limit=limit, offset=offset)

    def get_constructors(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ApiResponse:
        return self._resource("constructors", limit=limit, offset=offset)

    def get_circuits(self, *, limit: int | None = None, offset: int | None = None) -> ApiResponse:
        return self._resource("circuits", limit=limit, offset=offset)

    def get_driver_standings(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ApiResponse:
        return self._resource("driverstandings", limit=limit, offset=offset)

    def get_constructor_standings(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> ApiResponse:
        return self._resource("constructorstandings", limit=limit, offset=offset)

    def get_laps(self, *, limit: int | None = None, offset: int | None = None) -> ApiResponse:
        return self._resource("laps", limit=limit, offset=offset)

    def get_pitstops(self, *, limit: int | None = None, offset: int | None = None) -> ApiResponse:
        return self._resource("pitstops", limit=limit, offset=offset)

    def get_statuses(self, *, limit: int | None = None, offset: int | None = None) -> ApiResponse:
        """Finishing status catalogue (GET ``.../status/``)."""
        return self._resource("status", limit=limit, offset=offset)
