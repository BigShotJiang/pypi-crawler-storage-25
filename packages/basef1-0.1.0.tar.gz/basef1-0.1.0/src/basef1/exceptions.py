"""Client errors."""


class JolpicaHTTPError(Exception):
    """Raised when the API returns a non-success HTTP status."""

    def __init__(self, message: str, *, status_code: int, body: str | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body
