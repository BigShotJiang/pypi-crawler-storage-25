"""MRData keys shared across Jolpica / Ergast-style JSON responses."""

from __future__ import annotations

from typing import Final

# Common MRData fields (not data tables); see Jolpica docs "Common Response Fields".
MRDATA_METADATA_KEYS: Final[frozenset[str]] = frozenset(
    {"xmlns", "series", "url", "limit", "offset", "total"},
)

# data table keys in preferred resolution order for ApiResponse.get_data().
MRDATA_TABLE_PRIORITY: Final[tuple[str, ...]] = (
    "RaceTable",
    "SeasonTable",
    "DriverTable",
    "ConstructorTable",
    "CircuitTable",
    "StatusTable",
    "StandingsTable",
)

MRDATA_TABLE_KEYS: Final[frozenset[str]] = frozenset(MRDATA_TABLE_PRIORITY)
