"""In-memory TTL cache for idempotent GET responses."""

from __future__ import annotations

import copy
import threading
import time
from collections import OrderedDict
from collections.abc import Callable
from typing import Any


def cache_key_for_request(method: str, url: str, params: dict[str, Any] | None) -> str:
    """Stable cache key for HTTP ``method``, ``url``, and query ``params``."""
    m = method.upper()
    items = sorted((params or {}).items())
    if not items:
        return f"{m} {url}"
    qs = "&".join(f"{k}={v}" for k, v in items)
    return f"{m} {url}?{qs}"


class TTLCache:
    """
    Thread-safe LRU-ish cache: entries expire after ``ttl_seconds``;
    when full, the oldest inserted entry is evicted.
    """

    __slots__ = ("_clock", "_data", "_lock", "_max_entries", "_ttl")

    def __init__(
        self,
        max_entries: int,
        ttl_seconds: float,
        *,
        clock: Callable[[], float] | None = None,
    ) -> None:
        if max_entries < 1:
            raise ValueError("max_entries must be >= 1")
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be > 0")
        self._max_entries = max_entries
        self._ttl = ttl_seconds
        self._clock = clock or time.monotonic
        self._data: OrderedDict[str, tuple[float, dict[str, Any]]] = OrderedDict()
        self._lock = threading.RLock()

    def get(self, key: str) -> dict[str, Any] | None:
        now = self._clock()
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                return None
            expires_at, data = entry
            if expires_at <= now:
                del self._data[key]
                return None
            self._data.move_to_end(key)
            return copy.deepcopy(data)

    def set(self, key: str, data: dict[str, Any]) -> None:
        now = self._clock()
        expires_at = now + self._ttl
        stored = copy.deepcopy(data)
        with self._lock:
            self._data[key] = (expires_at, stored)
            self._data.move_to_end(key)
            while len(self._data) > self._max_entries:
                self._data.popitem(last=False)
