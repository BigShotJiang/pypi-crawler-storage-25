"""HTTP client for KomAInu `/tools` endpoints (backend is the only DB layer)."""

from __future__ import annotations

import os
from urllib.parse import quote

import httpx

# ---------------------------------------------------------------------------
# Config — read once at module load so errors surface at startup, not mid-run.
# ---------------------------------------------------------------------------


def _require_env(name: str, hint: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"{name} is not set. {hint}")
    return value


# Validated eagerly; RuntimeError propagates to the MCP server entry-point which
# prints a clear message and exits before accepting any tool calls.
_BASE_URL: str = _require_env(
    "KOMAINU_API_BASE_URL",
    "Set it to your KomAInu API base URL (e.g. https://your-service.up.railway.app).",
).rstrip("/")

_ACCESS_TOKEN: str = _require_env(
    "KOMAINU_ACCESS_TOKEN",
    "Use a token from the KomAInu web app (MCP page → Add to Cursor) "
    "or POST /mcp/tokens with your session JWT.",
)

_HEADERS: dict[str, str] = {"Authorization": f"Bearer {_ACCESS_TOKEN}"}

# ---------------------------------------------------------------------------
# Shared async client — one connection pool for the lifetime of the process.
# ---------------------------------------------------------------------------

_client = httpx.AsyncClient(timeout=120.0)


async def get_list_all_requirements() -> str:
    r = await _client.get(f"{_BASE_URL}/tools/list-all-requirements", headers=_HEADERS)
    r.raise_for_status()
    return r.text


async def get_requirement_coverage(req_name: str) -> str:
    enc = quote(req_name, safe="")
    r = await _client.get(
        f"{_BASE_URL}/tools/requirements/{enc}/coverage", headers=_HEADERS
    )
    r.raise_for_status()
    return r.text


async def get_coverage_summary() -> str:
    r = await _client.get(f"{_BASE_URL}/tools/coverage-summary", headers=_HEADERS)
    r.raise_for_status()
    return r.text


async def get_requirement_coverage_for_correction(req_name: str) -> str:
    enc = quote(req_name, safe="")
    r = await _client.get(
        f"{_BASE_URL}/tools/requirements/{enc}/coverage-for-correction",
        headers=_HEADERS,
    )
    r.raise_for_status()
    return r.text


async def rerun_requirement_coverage(
    req_name: str, branch: str, sha1: str, confirm: bool
) -> str:
    """Re-run analyze_scenario + aggregate only; confirm=false returns an acknowledgement prompt."""
    r = await _client.post(
        f"{_BASE_URL}/tools/rerun-requirement-coverage",
        headers=_HEADERS,
        json={
            "req_name": req_name,
            "branch": branch,
            "sha1": sha1,
            "confirm": confirm,
        },
        timeout=600.0,
    )
    r.raise_for_status()
    return r.text
