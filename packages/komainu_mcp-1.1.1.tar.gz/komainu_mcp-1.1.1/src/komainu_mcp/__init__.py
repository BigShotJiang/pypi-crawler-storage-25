"""MCP stdio server: thin adapter to the remote KomAInu HTTP API."""
