"""Entry point for `python -m komainu_mcp`."""

from __future__ import annotations

import sys
from importlib.metadata import PackageNotFoundError, version

_HELP = """komainu-mcp — MCP stdio server for KomAInu (calls your HTTP API, not stdin for chat).

Environment:
  KOMAINU_API_BASE_URL   Required. e.g. https://your-app.up.railway.app or http://127.0.0.1:PORT
  KOMAINU_ACCESS_TOKEN   Required. KomAInu MCP token (kmcp_…) or Supabase access JWT (Bearer).

Usage:
  Cursor / Claude Code runs this process; it then waits on stdin for MCP protocol messages.
  Running `komainu-mcp` alone in a terminal will appear idle — that is expected.

  komainu-mcp --help     Show this message
  komainu-mcp --version  Show package version
"""


def main() -> None:
    """Run the KomAInu MCP server (stdio), or print help/version."""
    argv = sys.argv[1:]
    if "-h" in argv or "--help" in argv:
        print(_HELP, end="", flush=True)
        return
    if "--version" in argv:
        try:
            print(version("komainu-mcp"))
        except PackageNotFoundError:
            print("komainu-mcp (version unknown)")
        return

    # Import only when starting the server (heavy); avoids delay on --help / --version.
    # client.py validates env vars at import time — catch misconfiguration early.
    try:
        from komainu_mcp.server import run
    except RuntimeError as exc:
        print(f"Configuration error: {exc}", flush=True)
        sys.exit(1)

    run()


if __name__ == "__main__":
    main()
