"""FastMCP stdio server: tools call the KomAInu API over HTTP only."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from komainu_mcp import client

mcp = FastMCP("KomAInu")


@mcp.tool(
    description=(
        "Discover which requirements have been analyzed and when. "
        "Use when you need valid requirement IDs, to see what the pipeline has processed, "
        "or to pick a target before coverage calls. "
        "Do not use when you already have an ID and only need that requirement’s tests, "
        "coverage, or a global rollup—use get_requirement_coverage or get_coverage_summary. "
        "Output: plain text—either a “no data yet” message, or “Found N analyzed requirements:” "
        "with lines “- <ID>: last analyzed <timestamp>”."
    ),
)
async def list_all_requirements() -> str:
    return await client.get_list_all_requirements()


@mcp.tool(
    description=(
        "Per-requirement coverage: which generated test cases appear in the codebase, plus "
        "requirement text and optional SRS context. "
        "req_name: the requirement ID (e.g. 'REQ-001' or 'SKYRADAR-APW-01'). "
        "Use when you need present flags, covered_by scenario paths, priority per test, "
        "requirement_description, and srs_context. "
        "Do not use when you only need aggregate counts across all requirements "
        "(get_coverage_summary); the ID is unknown (list_all_requirements); or you need "
        "file paths and split missing/covered lists for editing tests "
        "(get_requirement_coverage_for_correction). "
        "Output: JSON with req_name, requirement_description, srs_context, an X/Y summary, "
        "and test_cases with id, description, present, priority, covered_by—or a message if "
        "there is no coverage data."
    ),
)
async def get_requirement_coverage(req_name: str) -> str:
    return await client.get_requirement_coverage(req_name)


@mcp.tool(
    description=(
        "Actionable brief to improve test coverage for one requirement. "
        "req_name: the requirement ID. "
        "Use when the user wants to edit tests so missing test IDs become covered; you need "
        "requirement text, optional SRS context, traceability test file paths, and split "
        "lists of tests_missing_coverage vs tests_with_coverage. "
        "Do not use when you only need a compact coverage table (get_requirement_coverage) "
        "without traceability paths and split lists. "
        "Output: JSON with branch, sha1, ran_at, requirement_description, srs_context, "
        "test_file_paths, tests_missing_coverage, tests_with_coverage, pipeline_errors, hints; "
        "optional notes if description/context were not stored—re-run analysis to capture them."
    ),
)
async def get_requirement_coverage_for_correction(req_name: str) -> str:
    return await client.get_requirement_coverage_for_correction(req_name)


@mcp.tool(
    description=(
        "Recompute per-scenario coverage after the user edits test or scenario files. "
        "Uses the same generated test cases as the last run; only analyze_scenario + "
        "aggregate_test_cases run again (LLM). "
        "req_name, branch, sha1: identify the stored run (same as in coverage-for-correction JSON). "
        "confirm: must be false first — you receive a short prompt asking the user to confirm; "
        "after the user agrees, call again with confirm=true. "
        "Do not use for a full regen of test cases (run the full pipeline from the app instead). "
        "Output: either the confirmation prompt (confirm=false), or JSON with ok, summary, "
        "pipeline_errors on success; HTTP error if the run or paths are missing."
    ),
)
async def rerun_requirement_coverage(
    req_name: str, branch: str, sha1: str, confirm: bool
) -> str:
    return await client.rerun_requirement_coverage(req_name, branch, sha1, confirm)


@mcp.tool(
    description=(
        "Rollup of coverage status across all analyzed requirements. "
        "Use when you want high-level counts (covered/partial/uncovered) and a short status "
        "line per requirement for prioritization. "
        "Do not use when you need per-test detail for one requirement (get_requirement_coverage); "
        "only IDs and last-run times (list_all_requirements). "
        "Output: plain text header with emoji-labelled counts, then a Details section with "
        "one line per requirement."
    ),
)
async def get_coverage_summary() -> str:
    return await client.get_coverage_summary()


def run() -> None:
    mcp.run(transport="stdio")
