"""Configuration management for codrninja."""

import json
import os
from dataclasses import dataclass, field
from typing import Literal, Optional, Dict, Any


@dataclass
class Config:
    """Configuration for codrninja."""
    
    # Provider settings
    default_provider: str = field(default_factory=lambda: os.environ.get("CODRNINJA_PROVIDER", "ollama"))
    default_model: str = field(default_factory=lambda: os.environ.get("CODRNINJA_MODEL", "codellama"))
    
    # Ollama
    ollama_url: str = field(default_factory=lambda: os.environ.get("OLLAMA_URL", "http://localhost:11434"))
    
    # OpenAI
    openai_api_key: str = field(default_factory=lambda: os.environ.get("OPENAI_API_KEY", ""))
    
    # Anthropic
    anthropic_api_key: str = field(default_factory=lambda: os.environ.get("ANTHROPIC_API_KEY", ""))
    
    # OpenRouter
    openrouter_api_key: str = field(default_factory=lambda: os.environ.get("OPENROUTER_API_KEY", ""))
    
    # Reasoning level
    reasoning_level: Literal["none", "low", "medium", "high"] = field(
        default_factory=lambda: os.environ.get("CODRNINJA_REASONING_LEVEL", "medium")
    )
    
    # Database
    db_path: str = field(default_factory=lambda: os.path.expanduser("~/.codrninja/sessions.db"))

    # OAuth / TUI
    oauth_callback_port: int = field(default_factory=lambda: int(os.environ.get("CODRNINJA_OAUTH_CALLBACK_PORT", "8765")))
    oauth_timeout_seconds: int = field(default_factory=lambda: int(os.environ.get("CODRNINJA_OAUTH_TIMEOUT_SECONDS", "300")))
    oauth_auto_refresh: bool = field(default_factory=lambda: os.environ.get("CODRNINJA_OAUTH_AUTO_REFRESH", "true").lower() not in {"0", "false", "no"})
    oauth_refresh_buffer_minutes: int = field(default_factory=lambda: int(os.environ.get("CODRNINJA_OAUTH_REFRESH_BUFFER_MINUTES", "5")))
    tui_colors: Dict[str, str] = field(default_factory=lambda: {
        "user": "blue",
        "assistant": "green",
        "system": "grey50",
    })

    # Permissions
    permissions_mode: Literal["none", "ask", "auto", "strict", "relaxed", "custom"] = field(
        default_factory=lambda: os.environ.get("CODRNINJA_PERMISSIONS_MODE", "ask")
    )
    
    # Prompt
    system_prompt: str = """You are an expert software engineer. You help write, review, and modify code.
When asked to create or modify files, respond with the file content in a code block.
Always specify the file path in the response.
Be concise and practical.
You can fetch web pages and search the internet for up-to-date information."""
    
    def get_provider_config(self, provider: Optional[str] = None) -> Dict[str, Any]:
        """Get configuration for a specific provider."""
        p = provider or self.default_provider
        
        configs = {
            "ollama": {
                "url": self.ollama_url,
                "model": self.default_model,
                "reasoning_level": self.reasoning_level
            },
            "openai": {
                "api_key": self.openai_api_key,
                "model": self.default_model,
                "reasoning_level": self.reasoning_level
            },
            "anthropic": {
                "api_key": self.anthropic_api_key,
                "model": self.default_model,
                "reasoning_level": self.reasoning_level
            },
            "openrouter": {
                "api_key": self.openrouter_api_key,
                "model": self.default_model,
                "reasoning_level": self.reasoning_level
            }
        }
        
        return configs.get(p, configs["ollama"])
    
    def update_provider_config(self):
        """Sync provider manager with current config."""
        from .providers import ProviderManager
        self.provider_manager = ProviderManager({
            "provider": self.default_provider,
            "providers": {
                "ollama": self.get_provider_config("ollama"),
                "openai": self.get_provider_config("openai"),
                "anthropic": self.get_provider_config("anthropic"),
                "openrouter": self.get_provider_config("openrouter")
            }
        })
    
    @classmethod
    def from_env(cls) -> "Config":
        """Create configuration from environment variables and config file."""
        config = cls()
        
        # Load from config file if it exists
        config_file = os.path.expanduser("~/.config/codrninja/config.json")
        if os.path.exists(config_file):
            try:
                import json
                with open(config_file, 'r') as f:
                    data = json.load(f)
                
                # Update config from file
                if data.get('provider'):
                    config.default_provider = data['provider']
                if data.get('model'):
                    config.default_model = data['model']
                if data.get('ollama_url'):
                    config.ollama_url = data['ollama_url']
                if data.get('api_key'):
                    # Store API key for the current provider
                    pass  # API keys are handled separately
                if data.get('reasoning_level'):
                    config.reasoning_level = data['reasoning_level']
                if data.get('permissions_mode'):
                    config.permissions_mode = data['permissions_mode']
                oauth = data.get('oauth', {}) or {}
                if 'callback_port' in oauth:
                    config.oauth_callback_port = int(oauth['callback_port'])
                if 'callback_timeout_seconds' in oauth:
                    config.oauth_timeout_seconds = int(oauth['callback_timeout_seconds'])
                if 'auto_refresh' in oauth:
                    config.oauth_auto_refresh = bool(oauth['auto_refresh'])
                if 'refresh_buffer_minutes' in oauth:
                    config.oauth_refresh_buffer_minutes = int(oauth['refresh_buffer_minutes'])
                tui = data.get('tui', {}) or {}
                colors = tui.get('colors')
                if isinstance(colors, dict):
                    config.tui_colors.update(colors)
            except Exception:
                pass  # Fall back to defaults

        return config

    def to_config_dict(self) -> Dict[str, Any]:
        return {
            'provider': self.default_provider,
            'model': self.default_model,
            'ollama_url': self.ollama_url,
            'reasoning_level': self.reasoning_level,
            'permissions_mode': self.permissions_mode,
            'oauth': {
                'callback_port': self.oauth_callback_port,
                'callback_timeout_seconds': self.oauth_timeout_seconds,
                'auto_refresh': self.oauth_auto_refresh,
                'refresh_buffer_minutes': self.oauth_refresh_buffer_minutes,
            },
            'tui': {
                'colors': self.tui_colors,
            },
        }

    def save(self, path: Optional[str] = None):
        config_file = os.path.expanduser(path or '~/.config/codrninja/config.json')
        os.makedirs(os.path.dirname(config_file), exist_ok=True)
        with open(config_file, 'w') as f:
            json.dump(self.to_config_dict(), f, indent=2)
    
    def ensure_db_dir(self):
        """Ensure database directory exists."""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
