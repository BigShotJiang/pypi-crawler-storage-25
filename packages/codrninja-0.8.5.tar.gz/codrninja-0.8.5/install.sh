#!/bin/bash
# Codrninja Installer Script
# Works on macOS, Linux, and WSL
# Usage: curl -fsSL https://raw.githubusercontent.com/20ZollCoder/codrninja/main/install.sh | bash

set -e

CODRNINJA_VERSION="0.1.1"
CONFIG_DIR="${HOME}/.config/codrninja"
REPO_URL="https://github.com/20ZollCoder/codrninja"

echo "🥷 Installing codrninja v${CODRNINJA_VERSION}..."

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed."
    echo "   macOS: brew install python3"
    echo "   Ubuntu/Debian: sudo apt install python3"
    echo "   Fedora: sudo dnf install python3"
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "✅ Found Python ${PYTHON_VERSION}"

# Check pip
if ! command -v pip3 &> /dev/null && ! command -v pip &> /dev/null; then
    echo "❌ pip is required but not installed."
    echo "   Install with: python3 -m ensurepip --upgrade"
    exit 1
fi

PIP_CMD=$(command -v pip3 || command -v pip)
echo "✅ Found pip"

# Detect the actual pip user install bin directory
# This is platform-specific and Python-version-specific
echo "🔍 Detecting pip install directory..."

# Method 1: Ask Python where user scripts go
USER_BIN_DIR=$(python3 -c "
import site
import os
import sys

# Try multiple methods to find the correct user bin directory
paths = [
    os.path.join(site.getuserbase(), 'bin'),  # Linux standard
    os.path.join(site.getuserbase(), 'Scripts'),  # Windows
]

# macOS framework Python uses a different location
if sys.platform == 'darwin':
    # Check Library/Python/X.Y/bin
    import sysconfig
    py_version = f'{sys.version_info.major}.{sys.version_info.minor}'
    paths.insert(0, os.path.expanduser(f'~/Library/Python/{py_version}/bin'))
    
    # Also check the framework path
    framework = os.path.join(os.path.expanduser('~'), 'Library', 'Python', py_version, 'bin')
    if os.path.exists(framework):
        paths.insert(0, framework)

# Find the first existing or create the most likely one
for p in paths:
    if os.path.exists(p):
        print(p)
        break
else:
    # Default to the first path
    print(paths[0])
" 2>/dev/null || echo "")

if [ -z "$USER_BIN_DIR" ] || [ "$USER_BIN_DIR" = "" ]; then
    # Fallback: try to infer from python location
    PYTHON_BIN=$(python3 -c "import sys; print(sys.executable)" 2>/dev/null)
    if [ -n "$PYTHON_BIN" ]; then
        PYTHON_PREFIX=$(dirname "$PYTHON_BIN")
        if [ -d "${PYTHON_PREFIX}/Scripts" ]; then
            USER_BIN_DIR="${PYTHON_PREFIX}/Scripts"
        else
            USER_BIN_DIR="${PYTHON_PREFIX}"
        fi
    else
        USER_BIN_DIR="${HOME}/.local/bin"
    fi
fi

# Ensure the directory exists
mkdir -p "$USER_BIN_DIR"
mkdir -p "$CONFIG_DIR"

echo "✅ Install location: $USER_BIN_DIR"

# Install codrninja
echo "📦 Installing codrninja..."
"${PIP_CMD}" install --user "codrninja==${CODRNINJA_VERSION}" 2>/dev/null || {
    echo "📦 PyPI install failed, installing from git..."
    "${PIP_CMD}" install --user "git+${REPO_URL}.git"
}

# Install rich for TUI (optional but recommended)
echo "🎨 Installing Rich for TUI (optional)..."
"${PIP_CMD}" install --user rich 2>/dev/null || echo "   (Rich installation skipped)"

# After installation, find where pip actually put the scripts
echo "🔍 Locating installed scripts..."

# Method 1: Ask pip where the scripts are
PIP_BIN_DIR=$(python3 -c "
import os
import sys
import site

# Try to find the scripts directory
paths = [
    os.path.join(site.getuserbase(), 'bin'),
    os.path.join(site.getuserbase(), 'Scripts'),
]

# macOS framework Python
if sys.platform == 'darwin':
    import sysconfig
    py_version = f'{sys.version_info.major}.{sys.version_info.minor}'
    paths.insert(0, os.path.expanduser(f'~/Library/Python/{py_version}/bin'))

for p in paths:
    if os.path.exists(p) and os.path.isdir(p):
        print(p)
        break
" 2>/dev/null || echo "")

if [ -n "$PIP_BIN_DIR" ] && [ -d "$PIP_BIN_DIR" ]; then
    USER_BIN_DIR="$PIP_BIN_DIR"
fi

# Method 2: Search for codrninja executable
if [ ! -f "$USER_BIN_DIR/codrninja" ]; then
    # Try to find it
    FOUND=$(find "$HOME" -name "codrninja" -type f 2>/dev/null | head -1)
    if [ -n "$FOUND" ]; then
        USER_BIN_DIR=$(dirname "$FOUND")
    fi
fi

echo "✅ Scripts located in: $USER_BIN_DIR"

# Verify scripts exist
if [ -f "$USER_BIN_DIR/codrninja" ]; then
    echo "✅ codrninja found"
else
    echo "⚠️  codrninja not found in $USER_BIN_DIR"
    echo "   Searching..."
    # Last resort: find anywhere in home
    FOUND=$(find "$HOME" -name "codrninja" -type f 2>/dev/null | head -1)
    if [ -n "$FOUND" ]; then
        USER_BIN_DIR=$(dirname "$FOUND")
        echo "✅ Found at: $USER_BIN_DIR"
    fi
fi

# Detect shell config file
SHELL_CONFIG=""
if [ -n "$ZSH_VERSION" ] || [ -f "${HOME}/.zshrc" ]; then
    SHELL_CONFIG="${HOME}/.zshrc"
    CURRENT_SHELL="zsh"
elif [ -n "$BASH_VERSION" ] || [ -f "${HOME}/.bashrc" ]; then
    SHELL_CONFIG="${HOME}/.bashrc"
    CURRENT_SHELL="bash"
elif [ -f "${HOME}/.config/fish/config.fish" ]; then
    SHELL_CONFIG="${HOME}/.config/fish/config.fish"
    CURRENT_SHELL="fish"
fi

# Add to PATH if not already there
PATH_UPDATED=false
if [ -n "${SHELL_CONFIG}" ]; then
    if ! grep -q "$USER_BIN_DIR" "${SHELL_CONFIG}" 2>/dev/null; then
        echo ""
        echo "🔧 Adding $USER_BIN_DIR to PATH in ${SHELL_CONFIG}..."
        echo '' >> "${SHELL_CONFIG}"
        echo '# Added by codrninja installer' >> "${SHELL_CONFIG}"
        echo "export PATH=\"${USER_BIN_DIR}:\${PATH}\"" >> "${SHELL_CONFIG}"
        PATH_UPDATED=true
    fi
else
    echo ""
    echo "⚠️  Could not detect shell config file."
    echo "   Add this line to your shell config:"
    echo "   export PATH=\"${USER_BIN_DIR}:\${PATH}\""
fi

# Also add to current session so user can use it immediately
if [[ ":$PATH:" != *":$USER_BIN_DIR:"* ]]; then
    export PATH="$USER_BIN_DIR:$PATH"
fi

# Create config file
if [ ! -f "${CONFIG_DIR}/config.json" ]; then
    echo "📝 Creating default config..."
    cat > "${CONFIG_DIR}/config.json" << 'EOF'
{
  "ollama_url": "http://localhost:11434",
  "default_model": "codellama",
  "theme": "dark"
}
EOF
fi

# Create helper script
HELPER_SCRIPT="${USER_BIN_DIR}/codrninja-setup"
cat > "$HELPER_SCRIPT" << 'EOF'
#!/bin/bash
# Codrninja quick setup

echo "🥷 Codrninja Quick Setup"
echo ""

# Check if Ollama is configured
if [ -z "${OLLAMA_URL}" ]; then
    echo "⚠️  OLLAMA_URL not set"
    echo ""
    read -p "Enter your Ollama URL [http://localhost:11434]: " ollama_url
    OLLAMA_URL="${ollama_url:-http://localhost:11434}"
    echo "export OLLAMA_URL=${OLLAMA_URL}" >> "${HOME}/.zshrc"
fi

if [ -z "${OLLAMA_MODEL}" ]; then
    echo "⚠️  OLLAMA_MODEL not set"
    echo ""
    read -p "Enter your default model [codellama]: " model
    OLLAMA_MODEL="${model:-codellama}"
    echo "export OLLAMA_MODEL=${OLLAMA_MODEL}" >> "${HOME}/.zshrc"
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "Usage:"
echo "  codrninja-tui my-session          # Start TUI"
echo "  codrninja agent my-session 'msg'  # Run agent"
echo ""
echo "Run 'source ~/.zshrc' or restart your terminal to apply changes."
EOF

chmod +x "$HELPER_SCRIPT"

# Final instructions
echo ""
echo "✅ Installation complete!"
echo ""
echo "🥷 codrninja is now installed!"
echo ""

if [ "$PATH_UPDATED" = true ]; then
    echo "Important: Restart your terminal or run:"
    echo "  source ${SHELL_CONFIG}"
    echo ""
fi

echo "Then start using:"
echo "  codrninja-tui my-session"
echo ""
echo "Or configure first:"
echo "  codrninja-setup"
echo ""
echo "Documentation: https://github.com/20ZollCoder/codrninja"
echo ""
