"""Tests for agentshive.commands.doctor."""

from __future__ import annotations

import pytest

from agentshive.commands.doctor import _check_websocket
from agentshive.config import Config


def test_check_websocket_redacts_token_on_error(monkeypatch, capsys):
    """An exception message containing the token must not leak to stdout."""
    token = "ahv_SECRETTOKEN_SHOULD_NEVER_APPEAR_IN_OUTPUT"
    config = Config(
        server_url="https://agentshive.agency/",
        token=token,
        backends={"claude_code": True},
    )

    import websockets

    def fake_connect(*_args, **_kwargs):
        # Mimic websockets.InvalidURI / similar: message echoes the full URL.
        raise ValueError(f"invalid URI wss://example/api/ws/backend?token={token}")

    monkeypatch.setattr(websockets, "connect", fake_connect)

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is False
    assert token not in out, "token leaked to stdout"
    assert "ahv_***" in out


@pytest.mark.parametrize(
    "exc",
    [
        RuntimeError("no URL in message"),
        ConnectionRefusedError("connection refused"),
    ],
)
def test_check_websocket_reports_error_without_token(monkeypatch, capsys, exc):
    """Errors without token in message still surface a useful detail."""
    config = Config(
        server_url="https://agentshive.agency/",
        token="ahv_irrelevant",
        backends={"claude_code": True},
    )

    import websockets

    def fake_connect(*_args, **_kwargs):
        raise exc

    monkeypatch.setattr(websockets, "connect", fake_connect)

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is False
    assert "WebSocket" in out


class _FakeConn:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *_args):
        return False


def _capture_connect(monkeypatch):
    """Stub websockets.connect and return a dict that captures call kwargs."""
    captured: dict = {}

    def fake_connect(*args, **kwargs):
        captured["args"] = args
        captured["kwargs"] = kwargs
        return _FakeConn()

    import websockets

    monkeypatch.setattr(websockets, "connect", fake_connect)
    return captured


def test_check_websocket_passes_no_ssl_for_http_server(monkeypatch, capsys):
    """http:// (→ ws://) must not receive an ssl context — websockets rejects it."""
    config = Config(
        server_url="http://localhost:8000",
        token="ahv_dev",
        backends={"claude_code": True},
    )
    captured = _capture_connect(monkeypatch)

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is True
    assert captured["kwargs"]["ssl"] is None
    assert "no TLS" in out


def test_check_websocket_passes_ssl_for_https_server(monkeypatch, capsys):
    """https:// (→ wss://) must receive a TLS context."""
    config = Config(
        server_url="https://agentshive.agency/",
        token="ahv_real",
        backends={"claude_code": True},
    )
    captured = _capture_connect(monkeypatch)

    ok = _check_websocket(config)
    out = capsys.readouterr().out

    assert ok is True
    assert captured["kwargs"]["ssl"] is not None
    assert "TLS + auth OK" in out


def test_doctor_prints_reinstall_vendor_url(tmp_path, monkeypatch, capsys):
    """sdk-cli-spec.md v1.2 (agenthive@226666f): doctor surfaces the vendor
    URL the CEO can re-curl from, derived from the configured server_url so
    there's no second config surface to drift. Token value stays the
    placeholder `<your-token>` — doctor must never print real tokens to
    stdout on the vendor-URL line (token output is gated by the Token row
    masking elsewhere)."""
    from agentshive.config import save_config
    from agentshive.cli import main

    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(
        "agentshive.commands.doctor.CONFIG_FILE", tmp_path / "config.json"
    )
    monkeypatch.setattr("agentshive.commands.doctor.PID_FILE", tmp_path / "daemon.pid")

    save_config(
        Config(
            server_url="https://agentshive.example.com/",
            token="ahv_vendor_url_token",
            backends={"claude_code": True},
        )
    )

    # Short-circuit the network probes — vendor-URL line renders
    # regardless of Server/WebSocket check outcomes.
    monkeypatch.setattr("agentshive.commands.doctor._check_websocket", lambda _c: True)

    class _FakeResp:
        status_code = 200

    monkeypatch.setattr("httpx.get", lambda *_a, **_k: _FakeResp())

    try:
        main(["doctor"])
    except SystemExit:
        # Backend binaries on PATH may cause _check() to return False
        # depending on the test runner host; vendor-URL line renders
        # either way.
        pass

    out = capsys.readouterr().out
    assert "Re-install:" in out
    assert "https://agentshive.example.com/api/install.sh" in out
    assert "?token=<your-token>" in out
    assert "ahv_vendor_url_token" not in out
