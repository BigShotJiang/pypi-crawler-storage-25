"""Tests for executable resolution before subprocess launch.

Pins the Windows ``.cmd``/``.bat`` shim handling that asyncio's
``create_subprocess_exec`` can't do on its own (CreateProcess won't launch
shims from a bare command name). Covers:

- shutil.which resolution feeds the resolved absolute path to the subprocess
- shutil.which miss falls through with original argv so cwd-aware launch
  search still applies (Win32 CreateProcess searches the passed cwd; POSIX
  execvp runs after chdir(cwd))
- subprocess FileNotFoundError translates to a backend-named RuntimeError
- Windows-only smoke: a real .cmd shim actually launches via the resolved path
"""

from __future__ import annotations

import asyncio
import sys
from unittest.mock import patch

import pytest

from agentshive.backends.base import LocalCliBackend, LocalInvocationResult


class _FakeBackend(LocalCliBackend):
    """Minimal concrete subclass for exercising _resolve_executable / invoke."""

    def __init__(self, cmd: list[str]) -> None:
        self._cmd = cmd

    @classmethod
    def is_available(cls) -> bool:
        return True

    def _base_command(self) -> list[str]:
        return list(self._cmd)

    def _build_args(self, session_id: str | None = None) -> list[str]:
        return list(self._cmd)

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        return LocalInvocationResult(text=stdout)


def test_resolve_executable_replaces_first_arg_with_which_result():
    """shutil.which result becomes cmd[0]; remaining args untouched."""
    backend = _FakeBackend(["codex", "exec", "--json"])
    with patch(
        "agentshive.backends.base.shutil.which",
        return_value="/fake/path/codex.cmd",
    ):
        resolved = backend._resolve_executable(["codex", "exec", "--json"])
    assert resolved == ["/fake/path/codex.cmd", "exec", "--json"]


def test_resolve_executable_returns_empty_for_empty_cmd():
    """Empty cmd list passes through — no shutil.which call needed."""
    backend = _FakeBackend([])
    assert backend._resolve_executable([]) == []


def test_resolve_executable_falls_through_when_which_misses():
    """which→None returns original argv so subprocess can apply cwd-aware search.

    Win32 CreateProcess searches the passed lpCurrentDirectory as part of its
    standard search order; POSIX subprocess chdir's to cwd before execvp. If
    _resolve_executable raised early on which→None, we'd narrow that
    pre-existing implicit launch contract. Falling through preserves it; the
    actionable error surfaces from the subprocess layer instead.
    """
    backend = _FakeBackend(["nonexistent-cli-tool-xyz", "--flag"])
    with patch("agentshive.backends.base.shutil.which", return_value=None):
        resolved = backend._resolve_executable(["nonexistent-cli-tool-xyz", "--flag"])
    assert resolved == ["nonexistent-cli-tool-xyz", "--flag"]


def test_invoke_translates_subprocess_filenotfound_to_runtime_error(monkeypatch):
    """FileNotFoundError from create_subprocess_exec → backend-named RuntimeError.

    Customer-facing actionable error (e.g. "Backend codex requires executable
    on PATH: codex") instead of bare ``[WinError 2]`` / ``[Errno 2]``. The
    translation lives at the subprocess boundary, not in _resolve_executable,
    so cwd-aware launch behavior is preserved up until the actual exec attempt.
    """

    async def _raises_not_found(*_args, **_kwargs):
        raise FileNotFoundError(2, "No such file or directory")

    monkeypatch.setattr(
        "agentshive.backends.base.asyncio.create_subprocess_exec",
        _raises_not_found,
    )
    monkeypatch.setattr(
        "agentshive.backends.base.shutil.which",
        lambda _name: None,  # which misses → fallthrough → subprocess raises
    )

    backend = _FakeBackend(["nonexistent-cli-tool-xyz", "--flag"])
    with pytest.raises(RuntimeError) as excinfo:
        asyncio.run(backend.invoke("hello"))
    msg = str(excinfo.value)
    assert "_FakeBackend" in msg
    assert "nonexistent-cli-tool-xyz" in msg
    assert "PATH" in msg
    # FileNotFoundError preserved as cause for log inspection.
    assert isinstance(excinfo.value.__cause__, FileNotFoundError)


def test_invoke_calls_resolve_executable_before_subprocess(monkeypatch):
    """End-to-end: invoke() resolves cmd[0] before create_subprocess_exec.

    Pins the actual call-order: build_args → resolve_executable → subprocess_exec.
    Regression for the WinError 2 customer report (codex backend on Windows).
    """
    captured_argv: list[str] = []

    class _FakeProc:
        returncode = 0

        async def communicate(self, _input):
            return (b"", b"")

    async def _fake_create_subprocess_exec(*args, **_kwargs):
        captured_argv.extend(args)
        return _FakeProc()

    monkeypatch.setattr(
        "agentshive.backends.base.asyncio.create_subprocess_exec",
        _fake_create_subprocess_exec,
    )
    monkeypatch.setattr(
        "agentshive.backends.base.shutil.which",
        lambda name: f"/resolved/{name}.cmd" if name == "codex" else None,
    )

    backend = _FakeBackend(["codex", "exec"])
    asyncio.run(backend.invoke("hello"))

    # First arg to create_subprocess_exec must be the resolved path,
    # not the bare command name. This is the bug-fix assertion.
    assert captured_argv[0] == "/resolved/codex.cmd"
    assert captured_argv[1] == "exec"


@pytest.mark.skipif(
    sys.platform != "win32",
    reason="Windows .cmd shim launch semantics — only meaningful on win32",
)
def test_resolved_cmd_shim_actually_launches_on_windows(tmp_path):
    """End-to-end Windows: write a .cmd shim, resolve it, launch it.

    Mock-only assertions prove we PASS the resolved path; this proves Windows
    can actually LAUNCH the resolved path. If this fails, shutil.which alone
    isn't sufficient and the Windows path needs an explicit cmd.exe wrapper.
    Per codex-eng's review constraint: discover at-test-time, not customer-time.
    """
    shim = tmp_path / "fakecli.cmd"
    shim.write_text("@echo off\necho ok\n", encoding="utf-8")

    async def _run() -> tuple[int, bytes]:
        proc = await asyncio.create_subprocess_exec(
            str(shim),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _stderr = await proc.communicate()
        return proc.returncode, stdout

    returncode, stdout = asyncio.run(_run())
    assert returncode == 0
    assert stdout.decode().strip() == "ok"
