from agentshive.local_runner import (
    build_artifact_review_prompt,
    _extract_artifact_update,
)


def test_build_artifact_review_prompt_basic():
    ctx = {
        "title": "Test Plan",
        "content_type": "markdown",
        "content": "# Plan\nDo stuff.",
        "version": 1,
        "author_handle": "pm",
        "comments": [],
        "space_name": "Backend",
        "space_description": "Backend project",
    }
    prompt = build_artifact_review_prompt("eng", "You are an engineer.", ctx)
    assert "@eng" in prompt
    assert "Test Plan" in prompt
    assert "Do stuff." in prompt
    assert "PASS" in prompt
    assert "ARTIFACT_UPDATE" in prompt


def test_build_artifact_review_with_comments():
    ctx = {
        "title": "Spec",
        "content_type": "markdown",
        "content": "Content",
        "version": 2,
        "author_handle": "pm",
        "comments": [
            {"author_handle": "alice", "text": "Looks good"},
            {"author_handle": "bob", "text": "Needs work"},
        ],
        "space_name": "Project",
        "space_description": "",
    }
    prompt = build_artifact_review_prompt("eng", "Review.", ctx)
    assert "@alice: Looks good" in prompt
    assert "@bob: Needs work" in prompt


def test_build_artifact_review_with_status_change():
    ctx = {
        "title": "Doc",
        "content_type": "markdown",
        "content": "X",
        "version": 1,
        "author_handle": "pm",
        "comments": [],
        "space_name": "X",
        "space_description": "",
        "status_context": {
            "verb": "submitted for review",
            "caller_display_name": "Alice",
            "new_status": "in_review",
        },
    }
    prompt = build_artifact_review_prompt("eng", "Review.", ctx)
    assert "Alice" in prompt
    assert "in_review" in prompt


def test_build_artifact_review_with_memory():
    ctx = {
        "title": "Doc",
        "content_type": "markdown",
        "content": "X",
        "version": 1,
        "author_handle": "pm",
        "comments": [],
        "space_name": "X",
        "space_description": "",
    }
    prompt = build_artifact_review_prompt(
        "eng", "Review.", ctx, memory_context="I know Python.", space_rules="Use tabs."
    )
    assert "I know Python." in prompt
    assert "Use tabs." in prompt


def test_extract_artifact_update_no_update():
    text = "Looks good, ship it."
    comment, content, summary = _extract_artifact_update(text)
    assert comment == "Looks good, ship it."
    assert content is None
    assert summary is None


def test_extract_artifact_update_with_summary():
    text = "Nice work.\n<<<ARTIFACT_UPDATE>>>\nSummary: Fixed typos\nNew content here\n<<<END_ARTIFACT_UPDATE>>>"
    comment, content, summary = _extract_artifact_update(text)
    assert "Nice work." in comment
    assert "New content here" in content
    assert summary == "Fixed typos"


def test_extract_artifact_update_lowercase_summary():
    text = "<<<ARTIFACT_UPDATE>>>\nsummary: fix typo\nUpdated text\n<<<END_ARTIFACT_UPDATE>>>"
    comment, content, summary = _extract_artifact_update(text)
    assert summary == "fix typo"
    assert "Updated text" in content


def test_extract_artifact_update_no_summary():
    text = "<<<ARTIFACT_UPDATE>>>\nJust new content\n<<<END_ARTIFACT_UPDATE>>>"
    comment, content, summary = _extract_artifact_update(text)
    assert "Just new content" in content
    assert summary is None
