"""AC-13 contract tests for `agentshive setup --check`.

Per `docs/sdk-cli-spec.md` v1.2 shell-installer amendment at
agenthive@226666f ("Required SDK-side tests (merge gate for Lane B)"),
this module encodes the five tests that lock the `--check` flag's
persistence-only semantics. Any change to these test names is a spec
amendment surface, not an internal refactor — the canonical shell body
and the backend golden-file test grep-reference the same AC-13 contract.
"""

from __future__ import annotations

import hashlib
import json
from unittest.mock import patch

import pytest

from agentshive.cli import main
from agentshive.config import Config, save_config


def _seed_valid_config(tmp_path, monkeypatch) -> None:
    """Write a valid config.json into tmp_path with a non-empty token."""
    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(
        "agentshive.commands.setup.CONFIG_FILE", tmp_path / "config.json"
    )
    save_config(
        Config(
            server_url="https://example.com",
            token="ahv_test_token_123",
            backends={"claude_code": True},
        )
    )


def _seed_config_with_token(tmp_path, monkeypatch, token: str) -> None:
    """Write a config with an arbitrary token value (may be empty)."""
    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(
        "agentshive.commands.setup.CONFIG_FILE", tmp_path / "config.json"
    )
    save_config(
        Config(
            server_url="https://example.com",
            token=token,
            backends={"claude_code": True},
        )
    )


def _point_config_at(tmp_path, monkeypatch) -> None:
    """Point config machinery at tmp_path without writing any file."""
    monkeypatch.setattr("agentshive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agentshive.config.CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr(
        "agentshive.commands.setup.CONFIG_FILE", tmp_path / "config.json"
    )


def test_check_exit_zero_on_valid_config(tmp_path, monkeypatch):
    """AC-13: seeded valid config + non-empty token → exit 0."""
    _seed_valid_config(tmp_path, monkeypatch)
    with pytest.raises(SystemExit) as exc_info:
        main(["setup", "--check"])
    assert exc_info.value.code == 0


def test_check_exit_nonzero_on_missing_config(tmp_path, monkeypatch):
    """AC-13: no config file → exit non-zero."""
    _point_config_at(tmp_path, monkeypatch)
    assert not (tmp_path / "config.json").exists()
    with pytest.raises(SystemExit) as exc_info:
        main(["setup", "--check"])
    assert exc_info.value.code != 0


def test_check_exit_nonzero_on_empty_token(tmp_path, monkeypatch):
    """AC-13: config persists, token="" → exit non-zero.

    Pins the "persistence AND non-empty token" conjunction. An empty-token
    config is still loadable (save/load round-trips empty strings), so the
    only thing separating exit 0 from exit 1 on this path is the token
    emptiness check itself.
    """
    _seed_config_with_token(tmp_path, monkeypatch, token="")
    # Sanity: config IS persisted, so the failure mode is specifically the
    # empty-token check — not a load failure masquerading as empty.
    assert (tmp_path / "config.json").exists()
    data = json.loads((tmp_path / "config.json").read_text())
    assert data["token"] == ""

    with pytest.raises(SystemExit) as exc_info:
        main(["setup", "--check"])
    assert exc_info.value.code != 0


def test_check_does_no_network_io(tmp_path, monkeypatch):
    """AC-13 load-bearing: `--check` never invokes the SDK HTTP client.

    This is the regression gate against the drift class of adding a
    server-reachability probe to `--check`. The canonical shell body runs
    `--check` on machines that may be offline, airgapped, or behind a
    firewall; a network hop on this path breaks offline re-curl.

    Strategy: patch `httpx` at every import site in the SDK + patch
    `websockets.connect`. Any call dispatched during `--check` fails the
    assertion — regardless of which module originates it.
    """
    _seed_valid_config(tmp_path, monkeypatch)

    # Any reachable HTTP surface in the SDK funnels through httpx. Patching
    # both the sync `Client` + the async `AsyncClient` catches all call sites
    # without needing to enumerate them.
    with (
        patch("httpx.Client") as http_sync,
        patch("httpx.AsyncClient") as http_async,
        patch("httpx.get") as http_get,
        patch("httpx.post") as http_post,
        patch("websockets.connect") as ws_connect,
    ):
        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--check"])
        assert exc_info.value.code == 0

        assert http_sync.call_count == 0, "httpx.Client instantiated during --check"
        assert http_async.call_count == 0, (
            "httpx.AsyncClient instantiated during --check"
        )
        assert http_get.call_count == 0, "httpx.get called during --check"
        assert http_post.call_count == 0, "httpx.post called during --check"
        assert ws_connect.call_count == 0, "websockets.connect called during --check"


def test_check_is_read_only(tmp_path, monkeypatch):
    """AC-13 §9 regression gate: config.json mtime + SHA256 unchanged across
    `--check`. Catches any future refactor that slips a `save_config()` call
    onto the --check path (the exact drift AC-6 exists to block at the
    installer level, re-asserted here at the SDK level)."""
    _seed_valid_config(tmp_path, monkeypatch)
    config_file = tmp_path / "config.json"

    mtime_before = config_file.stat().st_mtime_ns
    sha_before = hashlib.sha256(config_file.read_bytes()).hexdigest()

    with pytest.raises(SystemExit) as exc_info:
        main(["setup", "--check"])
    assert exc_info.value.code == 0

    mtime_after = config_file.stat().st_mtime_ns
    sha_after = hashlib.sha256(config_file.read_bytes()).hexdigest()

    assert mtime_before == mtime_after, "config mtime changed across --check"
    assert sha_before == sha_after, "config content hash changed across --check"
