"""Tests for the Kimi CLI backend (SDK side)."""

from __future__ import annotations

import json

from agentshive.backends import create_backend, list_all
from agentshive.backends.kimi_cli import LocalKimiCliBackend
from agentshive.commands.doctor import _get_binary_name


def test_kimi_cli_registered():
    assert "kimi_cli" in list_all()
    backend = create_backend("kimi_cli")
    assert isinstance(backend, LocalKimiCliBackend)


def test_doctor_binary_mapping():
    assert _get_binary_name("kimi_cli") == "kimi"


def test_base_command_has_stream_json_and_stdin_text():
    backend = LocalKimiCliBackend()
    cmd = backend._base_command()
    assert cmd[0] == "kimi"
    assert "--print" in cmd
    assert "stream-json" in cmd
    assert "--input-format" in cmd
    # no --session when no session_id
    assert "--session" not in backend._build_args(None)


def test_build_args_appends_session():
    backend = LocalKimiCliBackend()
    args = backend._build_args("sess-123")
    assert "--session" in args
    assert args[args.index("--session") + 1] == "sess-123"


def test_parse_output_list_content():
    """Assistant message with list-shape content (multiple text parts)."""
    backend = LocalKimiCliBackend()
    stdout = "\n".join(
        [
            json.dumps({"session_id": "abc123"}),
            json.dumps(
                {
                    "role": "assistant",
                    "content": [
                        {"type": "text", "text": "Hello "},
                        {"type": "text", "text": "world"},
                    ],
                }
            ),
            json.dumps({"token_usage": {"input_tokens": 10, "output_tokens": 5}}),
        ]
    )
    result = backend._parse_output(stdout)
    assert result.text == "Hello world"
    assert result.session_id == "abc123"
    assert result.input_tokens == 10
    assert result.output_tokens == 5


def test_parse_output_bare_string_content():
    """Kimi sometimes serializes single-TextPart content as a bare string."""
    backend = LocalKimiCliBackend()
    stdout = json.dumps({"role": "assistant", "content": "bare reply"})
    result = backend._parse_output(stdout)
    assert result.text == "bare reply"


def test_parse_output_skips_malformed_lines():
    backend = LocalKimiCliBackend()
    stdout = "\n".join(
        [
            "not-json",
            json.dumps({"role": "assistant", "content": "ok"}),
        ]
    )
    result = backend._parse_output(stdout)
    assert result.text == "ok"


def test_parse_output_empty_stdout():
    backend = LocalKimiCliBackend()
    result = backend._parse_output("")
    assert result.text == ""
    assert result.session_id is None
    assert result.input_tokens == 0
