"""Kimi CLI backend (stream-json event stream)."""

from __future__ import annotations

import json
import logging
import shutil

from .base import LocalCliBackend, LocalInvocationResult

logger = logging.getLogger(__name__)


class LocalKimiCliBackend(LocalCliBackend):
    """Wraps the ``kimi`` CLI."""

    supports_resume = True

    @classmethod
    def is_available(cls) -> bool:
        return shutil.which("kimi") is not None

    def _base_command(self) -> list[str]:
        # --print: non-interactive mode (implicitly adds --yolo)
        # --output-format stream-json: JSONL event stream on stdout
        # --input-format text: read prompt from stdin as plain text
        return [
            "kimi",
            "--print",
            "--output-format",
            "stream-json",
            "--input-format",
            "text",
        ]

    def _build_args(self, session_id: str | None = None) -> list[str]:
        args = list(self._base_command())
        if session_id:
            args.extend(["--session", session_id])
        return args

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        """Parse Kimi CLI stream-json (JSONL) output.

        Each line is a JSON object emitted by kimi_cli's JsonPrinter:
        - assistant Message objects (role=assistant, content=[...] or str)
        - tool_result Message objects
        - Notification objects (may carry session_id / token_usage)
        """
        result_text = ""
        session_id = None
        input_tokens = 0
        output_tokens = 0
        cache_read_tokens = 0

        for line in stdout.strip().split("\n"):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Skipping malformed JSONL line: %s", line[:100])
                continue

            if event.get("role") == "assistant":
                content = event.get("content")
                if isinstance(content, str):
                    result_text += content
                elif isinstance(content, list):
                    for part in content:
                        if isinstance(part, dict) and part.get("type") == "text":
                            result_text += part.get("text", "")

            if session_id is None and event.get("session_id"):
                session_id = event.get("session_id")

            usage = event.get("token_usage")
            if isinstance(usage, dict):
                input_tokens += (
                    usage.get("input_tokens", 0) or usage.get("prompt_tokens", 0) or 0
                )
                output_tokens += (
                    usage.get("output_tokens", 0)
                    or usage.get("completion_tokens", 0)
                    or 0
                )
                cache_read_tokens += (
                    usage.get("cache_read_tokens", 0)
                    or usage.get("cached_tokens", 0)
                    or 0
                )

        return LocalInvocationResult(
            text=result_text,
            session_id=session_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read_tokens,
        )
