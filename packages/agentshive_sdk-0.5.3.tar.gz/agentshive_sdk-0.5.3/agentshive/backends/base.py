"""Base class and result dataclass for local CLI backends."""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Image extensions we detect as generated files.
# SVG excluded — can contain <script> tags (XSS vector).
IMAGE_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".apng",
    ".avif",
    ".heic",
    ".heif",
}
VIDEO_EXTENSIONS = {".mp4", ".webm", ".mov", ".avi", ".mkv"}
MEDIA_EXTENSIONS = IMAGE_EXTENSIONS | VIDEO_EXTENSIONS

# Max depth for recursive image file scanning.
_MAX_SCAN_DEPTH = 3
# Max file size for upload (20 MB).
MAX_GENERATED_FILE_BYTES = 20 * 1024 * 1024


@dataclass
class LocalInvocationResult:
    """Structured result from a local CLI invocation."""

    text: str
    session_id: str | None = None
    stop_reason: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cost_usd: float = 0.0
    generated_files: list[str] = field(default_factory=list)
    media_urls: list[str] = field(default_factory=list)


class LocalCliBackend(ABC):
    """Abstract base for CLI-backed agents.

    Subclasses must implement :meth:`is_available`, :meth:`_base_command`,
    :meth:`_build_args`, and :meth:`_parse_output`.
    """

    supports_resume: bool = False

    @classmethod
    @abstractmethod
    def is_available(cls) -> bool:
        """Return True when the required CLI binary is on PATH."""
        ...

    @abstractmethod
    def _base_command(self) -> list[str]:
        """Return the base CLI command tokens (no resume flags)."""
        ...

    @abstractmethod
    def _build_args(self, session_id: str | None = None) -> list[str]:
        """Return the full command list, optionally with resume flags."""
        ...

    @abstractmethod
    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        """Parse CLI stdout into a structured result."""
        ...

    def _get_stdin_data(self, prompt: str) -> str | None:
        """Return data to pipe to stdin, or None."""
        return prompt

    def _resolve_executable(self, cmd: list[str]) -> list[str]:
        """Resolve cmd[0] to its absolute on-disk path via shutil.which.

        On Windows, asyncio.create_subprocess_exec calls CreateProcess directly
        without a shell, so it cannot launch .cmd/.bat shims (the form
        Node-installed CLIs like ``claude``, ``codex``, ``openclaw`` take on
        Windows) from a bare command name. shutil.which honors PATHEXT and
        finds them; passing the resolved absolute path works on every platform.

        When ``shutil.which`` misses, fall through with the original argv so
        ``create_subprocess_exec(..., cwd=cwd)`` can still apply the target
        cwd's standard search rules (Win32 ``CreateProcess`` searches the
        passed cwd; POSIX ``execvp`` runs after ``chdir(cwd)``). Truly missing
        executables surface as ``FileNotFoundError`` from the subprocess
        layer, which the caller translates into the actionable RuntimeError.
        """
        if not cmd:
            return cmd
        resolved = shutil.which(cmd[0])
        if resolved is None:
            return cmd
        return [resolved, *cmd[1:]]

    def _missing_executable_error(self, cmd: list[str]) -> RuntimeError:
        """Build the actionable RuntimeError for a subprocess FileNotFoundError."""
        exe = cmd[0] if cmd else "<empty>"
        return RuntimeError(
            f"Backend {self.__class__.__name__} requires executable on PATH: {exe}"
        )

    def _snapshot_image_files(self, cwd: str | None) -> dict[str, float]:
        """Return {resolved_path: mtime} for image files under cwd (bounded depth)."""
        if not cwd:
            return {}
        cwd_resolved = Path(cwd).resolve()
        result: dict[str, float] = {}
        self._scan_dir(cwd_resolved, cwd_resolved, 0, result)
        return result

    def _scan_dir(
        self, directory: Path, cwd_root: Path, depth: int, out: dict[str, float]
    ) -> None:
        """Recursively scan for image files up to _MAX_SCAN_DEPTH."""
        if depth > _MAX_SCAN_DEPTH:
            return
        try:
            for entry in os.scandir(directory):
                if entry.is_dir(follow_symlinks=False) and not entry.name.startswith(
                    "."
                ):
                    self._scan_dir(Path(entry.path), cwd_root, depth + 1, out)
                elif (
                    entry.is_file(follow_symlinks=False)
                    and Path(entry.name).suffix.lower() in IMAGE_EXTENSIONS
                ):
                    resolved = Path(entry.path).resolve()
                    # Guard against symlink exfiltration
                    if not str(resolved).startswith(str(cwd_root)):
                        logger.warning(
                            "Skipping file outside cwd: %s -> %s", entry.path, resolved
                        )
                        continue
                    try:
                        size = resolved.stat().st_size
                    except OSError:
                        continue
                    if size > MAX_GENERATED_FILE_BYTES:
                        logger.warning(
                            "Skipping oversized file: %s (%d bytes)", entry.path, size
                        )
                        continue
                    out[str(resolved)] = entry.stat().st_mtime
        except OSError:
            pass

    def _detect_new_files(self, before: dict[str, float], cwd: str | None) -> list[str]:
        """Return paths of image files created or modified since the snapshot."""
        if not cwd:
            return []
        after = self._snapshot_image_files(cwd)
        new_files = []
        for path, mtime in after.items():
            if path not in before or mtime > before[path]:
                new_files.append(path)
        return sorted(new_files)

    async def invoke(
        self,
        prompt: str,
        session_id: str | None = None,
        timeout: int = 300,
        cwd: str | None = None,
    ) -> LocalInvocationResult:
        """Run the CLI subprocess, parse output.

        Raises :class:`TimeoutError` on timeout, :class:`RuntimeError` on
        non-zero exit, and :class:`~agenthive.rate_limit.RateLimitError` when
        rate-limit patterns are detected.
        """
        cmd = self._build_args(session_id)
        cmd = self._resolve_executable(cmd)
        stdin_data = self._get_stdin_data(prompt)

        logger.info("Invoking %s: %s", self.__class__.__name__, " ".join(cmd))
        logger.debug("stdin (%d chars): %s", len(prompt), prompt[:200])

        # Snapshot image files before invocation to detect new ones
        before_files = self._snapshot_image_files(cwd)

        t0 = time.monotonic()
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE if stdin_data else None,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
            )
        except FileNotFoundError as exc:
            raise self._missing_executable_error(cmd) from exc
        try:
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(stdin_data.encode() if stdin_data else None),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            logger.error("Subprocess timed out after %ds", timeout)
            raise TimeoutError(f"Subprocess timed out after {timeout}s")

        duration = time.monotonic() - t0
        stdout_text = stdout_bytes.decode(errors="replace")
        stderr_text = stderr_bytes.decode(errors="replace")

        if proc.returncode != 0:
            logger.error(
                "Subprocess failed (exit %d) in %.1fs: %s",
                proc.returncode,
                duration,
                stderr_text[:300],
            )
            # Check for rate-limit signals
            from agentshive.rate_limit import classify_rate_limit, RateLimitError

            combined = f"{stdout_text}\n{stderr_text}"
            snippet = classify_rate_limit(combined)
            if snippet:
                logger.warning("Rate limit detected: %s", snippet[:100])
                raise RateLimitError("local_backend", snippet)
            raise RuntimeError(f"Subprocess exited with code {proc.returncode}")

        logger.info(
            "Subprocess completed in %.1fs (exit=%d, stdout=%d chars)",
            duration,
            proc.returncode,
            len(stdout_text),
        )
        logger.debug("stdout: %s", stdout_text[:500])
        if stderr_text:
            logger.debug("stderr: %s", stderr_text[:500])

        result = self._parse_output(stdout_text)

        # Detect image files created during invocation
        new_files = self._detect_new_files(before_files, cwd)
        if new_files:
            result.generated_files = new_files
            logger.info(
                "Detected %d generated image files: %s", len(new_files), new_files
            )

        logger.info(
            "Parsed: text=%d chars, session_id=%s, tokens=%d/%d",
            len(result.text),
            result.session_id[:8] if result.session_id else None,
            result.input_tokens,
            result.output_tokens,
        )
        return result
