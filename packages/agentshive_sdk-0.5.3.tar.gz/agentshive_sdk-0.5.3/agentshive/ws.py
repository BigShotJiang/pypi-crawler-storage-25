"""WebSocket connection manager with auto-reconnect and heartbeat."""

from __future__ import annotations
import asyncio
import json
import logging
import os
import ssl
from typing import Callable

import certifi
import websockets

logger = logging.getLogger(__name__)
HEARTBEAT_INTERVAL = 30
RECONNECT_BASE_DELAY = 1
RECONNECT_MAX_DELAY = 60


def _build_ssl_context() -> ssl.SSLContext:
    # Default to certifi's CA bundle for consistency with httpx and reliability
    # on Pythons that lack a system trust store (e.g. PlatformIO-embedded).
    # SSL_CERT_FILE overrides for users on corporate networks with custom CAs.
    cafile = os.environ.get("SSL_CERT_FILE") or certifi.where()
    return ssl.create_default_context(cafile=cafile)


class AgentWS:
    """WebSocket client with automatic reconnection and heartbeat.

    Maintains a persistent connection to the AgentsHive server, automatically
    reconnecting with exponential backoff on disconnection.
    """

    def __init__(
        self,
        server_url: str,
        token: str,
        on_message: Callable,
        on_connect: Callable | None = None,
    ):
        """Create a WebSocket client.

        Args:
            server_url: Base URL of the AgentsHive server (http/https).
            token: Backend machine token for authentication.
            on_message: Async callback invoked for each incoming message.
            on_connect: Optional async callback invoked on each (re)connection.
        """
        ws_url = (
            server_url.replace("https://", "wss://")
            .replace("http://", "ws://")
            .rstrip("/")
        )
        self._url = f"{ws_url}/api/ws/backend?token={token}"
        self._token = token
        # Masked URL for logging (hide token after first 10 chars)
        masked_token = token[:10] + "..." if len(token) > 10 else token
        self._log_url = f"{ws_url}/api/ws/backend?token={masked_token}"
        self._on_message = on_message
        self._on_connect = on_connect
        self._ws = None
        self._running = False
        self._heartbeat_task = None

    async def connect(self):
        """Connect to the server and listen for messages indefinitely.

        Automatically reconnects with exponential backoff on disconnection.
        Call :meth:`disconnect` to stop the loop.
        """
        self._running = True
        delay = RECONNECT_BASE_DELAY
        # websockets.connect() rejects ssl= on ws:// URIs, so only build a TLS
        # context for wss:// servers. Local dev servers over plain http://
        # produce ws:// and must pass ssl=None.
        ssl_ctx = _build_ssl_context() if self._url.startswith("wss://") else None
        while self._running:
            try:
                logger.info("WebSocket connecting to %s", self._log_url[:80])
                async with websockets.connect(self._url, ssl=ssl_ctx) as ws:
                    self._ws = ws
                    logger.info("WebSocket connected")
                    delay = RECONNECT_BASE_DELAY
                    # Notify caller that connection is established
                    if self._on_connect:
                        await self._on_connect(ws)
                    self._heartbeat_task = asyncio.create_task(self._heartbeat_loop(ws))
                    try:
                        async for raw in ws:
                            data = json.loads(raw)
                            logger.debug("WS recv: %s", data)
                            await self._on_message(data)
                    except websockets.ConnectionClosed:
                        pass
                    finally:
                        if self._heartbeat_task:
                            self._heartbeat_task.cancel()
            except Exception as e:
                # websockets exceptions (e.g. InvalidURI) echo the full URI,
                # which contains the token. Redact before it hits daemon.log.
                safe_msg = str(e).replace(self._token, "ahv_***")
                logger.warning(
                    "WebSocket error: %s. Reconnecting in %ds...", safe_msg, delay
                )
            if self._running:
                logger.info("WebSocket disconnected, reconnecting in %ds", delay)
                await asyncio.sleep(delay)
                delay = min(delay * 2, RECONNECT_MAX_DELAY)

    async def _heartbeat_loop(self, ws):
        try:
            while True:
                await asyncio.sleep(HEARTBEAT_INTERVAL)
                data = json.dumps({"type": "heartbeat"})
                logger.debug("WS send: %s", data)
                await ws.send(data)
        except (asyncio.CancelledError, Exception):
            pass

    async def send(self, data: dict):
        """Send a JSON message to the server."""
        if self._ws:
            await self._ws.send(json.dumps(data))

    async def disconnect(self):
        """Stop the connection loop and close the WebSocket."""
        self._running = False
        if self._ws:
            await self._ws.close()
        logger.info("WebSocket closed")
