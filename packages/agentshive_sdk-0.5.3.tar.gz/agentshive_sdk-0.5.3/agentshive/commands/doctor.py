"""agentshive doctor — diagnostic checks."""

from __future__ import annotations

import argparse
import shutil
import sys

from agentshive.config import (
    Config,
    ConfigError,
    CONFIG_FILE,
    PID_FILE,
    load_config,
)


def _check(label: str, ok: bool, detail: str = "") -> bool:
    mark = "\u2713" if ok else "\u2717"
    suffix = f" {detail}" if detail else ""
    print(f"  {label:20s} {mark}{suffix}")
    return ok


def run_doctor(_args: argparse.Namespace) -> None:
    """Run the doctor command."""
    print()
    all_ok = True

    # 1. Config file
    config: Config | None = None
    try:
        config = load_config()
        all_ok &= _check("Config", True, str(CONFIG_FILE))
    except ConfigError:
        all_ok &= _check("Config", False, f"not found ({CONFIG_FILE})")

    # 2. Token
    if config:
        has_token = bool(config.token) and config.token.startswith("ahv_")
        masked = (
            config.token[:4] + "****" + config.token[-4:]
            if len(config.token) > 8
            else "(not set)"
        )
        all_ok &= _check("Token", has_token, masked)
    else:
        all_ok &= _check("Token", False, "no config")

    # 3. Server reachable
    if config and config.server_url:
        try:
            import httpx
        except ImportError:
            all_ok &= _check("Server", False, "httpx not installed (pip install httpx)")
            httpx = None  # type: ignore[assignment]
        if httpx is not None:
            try:
                resp = httpx.get(config.server_url, timeout=5, follow_redirects=True)
                all_ok &= _check(
                    "Server", True, f"{config.server_url} (HTTP {resp.status_code})"
                )
            except Exception as exc:
                all_ok &= _check("Server", False, f"{config.server_url} ({exc})")
    else:
        all_ok &= _check("Server", False, "no server_url configured")

    # 4. WebSocket TLS (catches SSL cert issues proactively — the same class
    # of failure that leaves the daemon stuck in a reconnect loop).
    if config and config.server_url and config.token:
        all_ok &= _check_websocket(config)

    # 5. Backends
    print()
    print("  Backends:")
    from agentshive.backends import list_all

    for name in list_all():
        binary = _get_binary_name(name)
        path = shutil.which(binary)
        if path:
            all_ok &= _check(f"    {name}", True, f"{binary} found")
        else:
            _check(f"    {name}", False, f"{binary} not on PATH")
            # Not a hard failure — some backends being missing is fine

    # 6. Daemon
    print()
    import os

    pid = None
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            try:
                os.kill(pid, 0)
            except OSError:
                pid = None
        except (ValueError, OSError):
            pid = None
    if pid:
        _check("Daemon", True, f"running (PID {pid})")
    else:
        _check("Daemon", False, "not running")

    # Vendor-URL hint (sdk-cli-spec.md v1.2 shell-installer, agenthive@226666f
    # ownership table). When the installer is the vendor of record, the CEO's
    # recovery path on a failed doctor run is a re-curl against the workspace.
    # Deriving the URL from `server_url` avoids a second config surface.
    if config and config.server_url:
        vendor_url = config.server_url.rstrip("/") + "/api/install.sh"
        print(f"  Re-install:           {vendor_url}?token=<your-token>")
        print()

    if all_ok:
        print("  All checks passed.")
    else:
        print("  Some checks failed. Fix the issues above.")
    print()

    if not all_ok:
        sys.exit(1)


def _check_websocket(config: Config) -> bool:
    """Attempt a short-lived WebSocket handshake to verify TLS and auth."""
    import asyncio

    try:
        import websockets
    except ImportError:
        return _check("WebSocket", False, "websockets not installed")

    from agentshive.ws import _build_ssl_context

    ws_url = (
        config.server_url.replace("https://", "wss://")
        .replace("http://", "ws://")
        .rstrip("/")
    ) + f"/api/ws/backend?token={config.token}"
    # websockets.connect() rejects ssl= on ws:// URIs. Only build a TLS
    # context when the server is actually wss:// so local dev servers
    # (http://localhost:...) still work.
    ssl_ctx = _build_ssl_context() if ws_url.startswith("wss://") else None
    ok_label = "TLS + auth OK" if ssl_ctx else "auth OK (no TLS)"

    async def _probe():
        async with websockets.connect(
            ws_url, ssl=ssl_ctx, open_timeout=5, close_timeout=2
        ):
            return True

    try:
        asyncio.run(_probe())
        return _check("WebSocket", True, ok_label)
    except Exception as exc:
        # Some websockets exceptions (e.g. InvalidURI) include the full URL in
        # their message — which contains the token. Redact before displaying.
        detail = str(exc).replace(config.token, "ahv_***")
        if len(detail) > 80:
            detail = detail[:77] + "..."
        return _check("WebSocket", False, detail)


def _get_binary_name(backend_name: str) -> str:
    """Map backend registry name to expected CLI binary name."""
    mapping = {
        "claude_code": "claude",
        "gemini_cli": "gemini",
        "codex": "codex",
        "kimi_cli": "kimi",
        "openclaw": "openclaw",
        "opencode": "opencode",
    }
    return mapping.get(backend_name, backend_name)
