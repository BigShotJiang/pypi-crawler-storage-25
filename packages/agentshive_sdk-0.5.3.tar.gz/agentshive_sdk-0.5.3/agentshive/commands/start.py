"""agentshive start — start the daemon (foreground or background)."""

from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
import time

from agentshive.config import (
    Config,
    ConfigError,
    LOG_FILE,
    PID_FILE,
    load_config,
    validate_config,
)

logger = logging.getLogger(__name__)

LOG_ROTATE_SIZE = 10 * 1024 * 1024  # 10 MB


def _rotate_log_if_large(path) -> None:
    """Rotate the daemon log on startup if it exceeds the size limit.

    Daemon stdout/stderr is dup2'd to the log fd, which prevents in-process
    rotation. Rotation at startup keeps the most recent run plus one backup.
    """
    try:
        if path.exists() and path.stat().st_size > LOG_ROTATE_SIZE:
            backup = path.with_suffix(path.suffix + ".1")
            backup.unlink(missing_ok=True)
            path.rename(backup)
    except OSError:
        pass  # Non-fatal — daemon will still start, log just won't rotate.


def _is_running(pid: int) -> bool:
    """Check if a process with the given PID is alive."""
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _read_pid() -> int | None:
    """Read PID from file, return None if not found or stale."""
    if not PID_FILE.exists():
        return None
    try:
        pid = int(PID_FILE.read_text().strip())
    except (ValueError, OSError):
        return None
    if _is_running(pid):
        return pid
    # Stale PID file
    PID_FILE.unlink(missing_ok=True)
    return None


def _run_foreground(config: Config, *, test_mode: bool = False) -> None:
    """Run daemon in the foreground (blocking)."""
    from agentshive.local_runner import run_daemon

    enabled = [k for k, v in config.backends.items() if v]
    # In test mode real CLIs are bypassed, so advertise all registered backend
    # types when none are configured — ensures BackendClient sends the register
    # payload and the server can route tasks for any backend type to this daemon.
    if not enabled and test_mode:
        from agentshive.backends import list_all

        supported = list_all() or ["claude_code"]
    else:
        supported = enabled
    run_daemon(
        server_url=config.server_url,
        token=config.token,
        supported_backends=supported,
        timeout=config.timeout,
        log_level=config.log_level.upper(),
        test_mode=test_mode,
        repo_path=config.repo_path,
    )


def _daemonize(config: Config, *, test_mode: bool = False) -> None:
    """Fork to background and run the daemon."""
    # First fork
    try:
        pid = os.fork()
    except OSError as exc:
        print(f"Error: failed to fork: {exc}", file=sys.stderr)
        sys.exit(1)

    if pid > 0:
        # Parent — wait for grandchild to write PID file, then report
        print("  Starting AgentsHive daemon...")
        time.sleep(1)
        daemon_pid = _read_pid()
        if daemon_pid:
            print(f"  PID: {daemon_pid}")
            print(f"  Log: {LOG_FILE}")
            print()
            print("  Daemon is running. Use 'agentshive stop' to stop.")
        else:
            print(f"  Daemon may have failed to start. Check log: {LOG_FILE}")
        return

    # Child — detach from terminal
    os.setsid()

    # Second fork (prevent re-acquiring terminal)
    try:
        pid2 = os.fork()
    except OSError:
        os._exit(1)

    if pid2 > 0:
        os._exit(0)

    # Grandchild — the actual daemon
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))

    # Redirect stdio to log file
    try:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        _rotate_log_if_large(LOG_FILE)
        log_fd = os.open(str(LOG_FILE), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
        os.dup2(log_fd, sys.stdout.fileno())
        os.dup2(log_fd, sys.stderr.fileno())
        os.close(log_fd)
        devnull = os.open(os.devnull, os.O_RDONLY)
        os.dup2(devnull, sys.stdin.fileno())
        os.close(devnull)
    except OSError:
        PID_FILE.unlink(missing_ok=True)
        os._exit(1)

    # Clean up PID file on exit
    def _cleanup(*_):
        PID_FILE.unlink(missing_ok=True)
        sys.exit(0)

    signal.signal(signal.SIGTERM, _cleanup)
    signal.signal(signal.SIGINT, _cleanup)

    try:
        _run_foreground(config, test_mode=test_mode)
    finally:
        PID_FILE.unlink(missing_ok=True)


def run_start(args: argparse.Namespace) -> None:
    """Run the start command."""
    # Activate test mode from either the --test-mode flag or the env var, so
    # the two entry points behave the same (both must be checked *before*
    # validate_config so backend validation is filtered either way).
    env_test_mode = os.environ.get("AGENTSHIVE_SDK_TEST_MODE", "").lower() in (
        "1",
        "true",
        "yes",
    )
    test_mode = getattr(args, "test_mode", False) or env_test_mode

    try:
        config = load_config()
    except ConfigError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    errors = validate_config(config)
    if test_mode:
        # In test mode no real CLI is needed — backends are bypassed entirely.
        errors = [e for e in errors if "backend" not in e.lower()]
    if errors:
        print("Config errors:", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        sys.exit(1)

    # Check if already running
    existing_pid = _read_pid()
    if existing_pid:
        print(f"Daemon is already running (PID {existing_pid}).")
        print("Use 'agentshive stop' first, or 'agentshive status' to check.")
        sys.exit(0)

    if test_mode:
        print("  Test mode: real backends bypassed — deterministic responses only")

    enabled = [k for k, v in config.backends.items() if v]
    print()
    print(f"  Server:   {config.server_url}")
    print(f"  Backends: {', '.join(enabled) or '(none — test mode)'}")
    print()

    if args.foreground:
        _run_foreground(config, test_mode=test_mode)
    else:
        _daemonize(config, test_mode=test_mode)
