# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class CreatePhysicalConnectionSetupOrderResponseBody(DaraModel):
    def __init__(
        self,
        order_id: str = None,
        physical_connection_id: str = None,
        request_id: str = None,
    ):
        # The order ID.
        self.order_id = order_id
        # The ID of the Express Connect circuit.
        self.physical_connection_id = physical_connection_id
        # The request ID.
        self.request_id = request_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.order_id is not None:
            result['OrderId'] = self.order_id

        if self.physical_connection_id is not None:
            result['PhysicalConnectionId'] = self.physical_connection_id

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('OrderId') is not None:
            self.order_id = m.get('OrderId')

        if m.get('PhysicalConnectionId') is not None:
            self.physical_connection_id = m.get('PhysicalConnectionId')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        return self

