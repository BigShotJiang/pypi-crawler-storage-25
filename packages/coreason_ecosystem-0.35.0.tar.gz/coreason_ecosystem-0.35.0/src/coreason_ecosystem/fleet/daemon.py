# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-ecosystem

"""Autonomic Fleet Manager — Thermodynamic Provisioning Daemon.

Continuously polls the TelemetryTopologyMonitor for the β₀ Betti number
(connected components) and drives scale-up/scale-down actuation via the
PricingOracle and SkyPilotActuator. All scaling decisions are derived
from topological invariants — no scalar metrics are consumed.
"""

import asyncio
from pathlib import Path
from typing import Any

from loguru import logger

from coreason_ecosystem.fleet.skypilot_actuator import SkyPilotActuator, SkyPilotTarget
from coreason_manifest.spec.ontology import (
    SpatialHardwareProfile as HardwareProfile,
    EpistemicSecurityProfile as SecurityProfile,
    EscrowPolicy,
)


class AutonomicFleetManager:
    """Thermodynamic provisioning daemon.

    Derives scaling decisions from the topological invariants exposed by
    the TelemetryTopologyMonitor. ``coreason_active_agents_total`` holds β₀
    (connected components). β₀ > 0 means active workflows requiring compute;
    β₀ == 0 means the swarm is idle and resources can be reclaimed.
    """

    def __init__(
        self,
        max_budget_hr: float,
        polling_interval_sec: int,
        templates_path: Path,
        cooldown_sec: int = 300,
    ) -> None:
        self.max_budget_hr = max_budget_hr
        self.polling_interval_sec = polling_interval_sec
        self.templates_path = templates_path
        self.cooldown_sec = cooldown_sec
        self.driver = SkyPilotActuator()
        self._running = False
        self.pending_provisions = 0
        self._background_tasks: set[asyncio.Task[Any]] = set()

    async def start(self) -> None:
        """Initiate the autonomic execution loop.

        Continuously polls the topological state. If β₀ (connected components
        stored in coreason_active_agents_total) > 0, the daemon executes
        scale-up logic by mapping Delta VRAM to the SpatialHardwareProfile.
        If β₀ == 0, it executes scale-to-zero teardown logic.
        """
        self._running = True
        logger.info("Starting Autonomic Fleet Manager...")

        while self._running:
            try:
                betti_0 = 0
                logger.debug(f"Topological state: β₀={betti_0}")
                required_vram = 0.0
                active_stacks = await self.driver.reconcile_state()
                provisioned_vram = sum(
                    s.get("vram_capacity", 0.0) for s in active_stacks
                )

                delta = required_vram - provisioned_vram

                if delta > 0:
                    profile = HardwareProfile(
                        min_vram_gb=delta,
                        provider_whitelist=["aws", "gcp", "azure", "vast"],
                    )
                    security_profile = SecurityProfile(network_isolation=True)

                    target = SkyPilotTarget(
                        use_spot=True,
                        hardware_profile=profile,
                        security_profile=security_profile,
                        autostop_idle_minutes=15,
                        escrow_policy=EscrowPolicy(
                            escrow_locked_magnitude=max(int(self.max_budget_hr), 1),
                            release_condition_metric="fleet_daemon_hourly_budget",
                            refund_target_node_cid="did:coreason:fleet:skypilot",
                        ),
                    )

                    logger.info("Optimal target generated. Provisioning...")

                    self.pending_provisions += 1
                    try:
                        result = await self.driver.provision_node(target)
                        logger.info(
                            f"Provisioning Complete: {result.get('cluster_name', 'unknown')}"
                        )

                        async def _cooldown_and_decrement() -> None:
                            await asyncio.sleep(self.cooldown_sec)
                            self.pending_provisions = max(
                                0, self.pending_provisions - 1
                            )

                        task = asyncio.create_task(_cooldown_and_decrement())
                        self._background_tasks.add(task)
                        task.add_done_callback(self._background_tasks.discard)
                    except Exception as e:
                        self.pending_provisions = max(0, self.pending_provisions - 1)
                        logger.error(f"Provisioning failed: {e}")
                        raise
                elif betti_0 == 0 and self.pending_provisions == 0:
                    if active_stacks:
                        target_stack = active_stacks[0]
                        stack_to_destroy = target_stack.get("cluster_name", "unknown")

                        logger.info(
                            f"Scale to zero triggered. Destroying {stack_to_destroy}..."
                        )
                        await self.driver.destroy_node(stack_to_destroy)
                    else:
                        logger.debug(
                            "Queue empty, but no active compute nodes to destroy."
                        )

            except asyncio.CancelledError:
                self._running = False
                logger.info("Fleet Manager shutdown requested.")
                break
            except Exception as e:
                logger.error(f"Error in control loop: {e}")

            try:
                await asyncio.sleep(self.polling_interval_sec)
            except asyncio.CancelledError:
                self._running = False
                logger.info("Fleet Manager shutdown requested during sleep.")
                break
