# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: https://github.com/CoReason-AI/coreason-ecosystem

"""
The Master MCP Gateway.

This boundary governs federated capability discovery and routes the JSON-RPC
requests to sub-MCP backends based on Epistemic Intents.
"""

from .semantic_router import (
    SemanticRouter,
    IntentWeighting,
    HybridWeighting,
    ScoreCalibration,
)

__all__ = [
    "SemanticRouter",
    "IntentWeighting",
    "HybridWeighting",
    "ScoreCalibration",
]
