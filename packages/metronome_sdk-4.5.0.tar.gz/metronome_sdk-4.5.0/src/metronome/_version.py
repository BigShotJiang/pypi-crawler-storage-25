# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "metronome"
__version__ = "4.5.0"  # x-release-please-version
