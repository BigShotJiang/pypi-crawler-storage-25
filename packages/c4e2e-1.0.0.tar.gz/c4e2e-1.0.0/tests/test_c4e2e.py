"""
tests/test_c4e2e.py - Full test suite
"""

import json
import pytest
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from c4e2e import (
    keygen,
    load_config,
    create_node,
    pubkey_to_b64,
    export_ed25519_private,
    import_ed25519_private,
    sign,
    verify,
    pack_frame,
    unpack_frame,
    build_metadata,
    UntrustedSenderError,
    SignatureError,
    C4NodeError,
    ModeError,
)
from c4e2e.crypto import (
    encrypt_for_recipient,
    decrypt_from_sender,
    aes_gcm_encrypt,
    aes_gcm_decrypt,
    generate_identity_keypair,
)
from c4e2e.payload import (
    build_extra,
    encode_metadata,
    decode_metadata,
    validate_metadata,
)


# ─── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def keypair_a():
    return keygen()


@pytest.fixture
def keypair_b():
    return keygen()


@pytest.fixture
def tx_node(keypair_a):
    priv, _ = keypair_a
    cfg = load_config(mode="transmitter", private_key=priv, output_dir="/tmp/c4e2e_test")
    return create_node(cfg)


@pytest.fixture
def rx_node(keypair_b, keypair_a):
    rx_priv, _ = keypair_b
    _, tx_pub = keypair_a
    cfg = load_config(
        mode="receiver",
        private_key=rx_priv,
        trusted_keys=[pubkey_to_b64(tx_pub)],
        output_dir="/tmp/c4e2e_test",
    )
    return create_node(cfg)


# ─── Crypto primitives ────────────────────────────────────────────────────────

class TestCrypto:
    def test_keygen(self):
        priv, pub = keygen()
        assert priv is not None
        assert pub is not None

    def test_sign_verify(self, keypair_a):
        priv, pub = keypair_a
        data = b"hello world"
        sig = sign(priv, data)
        assert verify(pub, sig, data)

    def test_verify_bad_sig(self, keypair_a, keypair_b):
        priv_a, pub_a = keypair_a
        _, pub_b = keypair_b
        data = b"test"
        sig = sign(priv_a, data)
        assert not verify(pub_b, sig, data)

    def test_aes_gcm_roundtrip(self):
        import os
        key = os.urandom(32)
        plaintext = b"secret agent data"
        blob = aes_gcm_encrypt(key, plaintext)
        recovered = aes_gcm_decrypt(key, blob)
        assert recovered == plaintext

    def test_aes_gcm_wrong_key(self):
        import os
        key = os.urandom(32)
        wrong_key = os.urandom(32)
        blob = aes_gcm_encrypt(key, b"data")
        with pytest.raises(Exception):
            aes_gcm_decrypt(wrong_key, blob)

    def test_hybrid_encrypt_decrypt(self, keypair_a, keypair_b):
        sender_priv, sender_pub = keypair_a
        receiver_priv, receiver_pub = keypair_b

        plaintext = b'{"task": "recon", "target": "10.0.0.0/8"}'
        encrypted = encrypt_for_recipient(plaintext, receiver_pub, sender_priv)

        assert "eph_pub" in encrypted
        assert "ciphertext" in encrypted
        assert "signature" in encrypted

        recovered = decrypt_from_sender(encrypted, receiver_priv, sender_pub)
        assert recovered == plaintext

    def test_hybrid_wrong_sender(self, keypair_a, keypair_b):
        sender_priv, sender_pub = keypair_a
        receiver_priv, receiver_pub = keypair_b
        bad_priv, bad_pub = keygen()

        plaintext = b"payload"
        encrypted = encrypt_for_recipient(plaintext, receiver_pub, sender_priv)

        with pytest.raises(ValueError, match="Signature verification failed"):
            decrypt_from_sender(encrypted, receiver_priv, bad_pub)

    def test_pem_export_import(self, keypair_a):
        priv, _ = keypair_a
        pem = export_ed25519_private(priv)
        loaded = import_ed25519_private(pem)
        # Both should produce same public key
        orig_pub = pubkey_to_b64(priv.public_key())
        loaded_pub = pubkey_to_b64(loaded.public_key())
        assert orig_pub == loaded_pub

    def test_pem_with_password(self, keypair_a):
        priv, _ = keypair_a
        pem = export_ed25519_private(priv, password=b"s3cr3t")
        loaded = import_ed25519_private(pem, password=b"s3cr3t")
        assert pubkey_to_b64(loaded.public_key()) == pubkey_to_b64(priv.public_key())

        with pytest.raises(Exception):
            import_ed25519_private(pem, password=b"wrong")


# ─── Payload / Wire Format ────────────────────────────────────────────────────

class TestPayload:
    def test_metadata_roundtrip(self, keypair_a):
        _, pub = keypair_a
        meta = build_metadata("output.json", pubkey_to_b64(pub), {"job_id": "001"})
        encoded = encode_metadata(meta)
        recovered = decode_metadata(encoded)
        assert recovered == meta

    def test_metadata_wrong_keys(self):
        with pytest.raises(ValueError):
            validate_metadata({"name": "x"})  # missing pubkey and extra

        with pytest.raises(ValueError):
            validate_metadata({"name": "x", "pubkey": "y", "extra": {}, "evil": "z"})

    def test_pack_unpack_frame(self, keypair_a, keypair_b):
        sender_priv, sender_pub = keypair_a
        _, receiver_pub = keypair_b

        meta = build_metadata("test.json", pubkey_to_b64(sender_pub), {})
        job_bytes = b'{"task": "test"}'
        encrypted = encrypt_for_recipient(job_bytes, receiver_pub, sender_priv)
        frame = pack_frame(meta, encrypted)

        meta_out, body_out = unpack_frame(frame)
        assert meta_out["name"] == "test.json"
        assert "eph_pub" in body_out

    def test_frame_truncated(self):
        with pytest.raises(ValueError):
            unpack_frame(b"\x00\x00\x01\x00")  # claims 256 bytes of metadata, has none

    def test_build_extra_host_info(self):
        extra = build_extra(job_id="j1", tags=["a", "b"], include_host=True)
        assert "host_info" in extra
        assert extra["job_id"] == "j1"
        assert extra["tags"] == ["a", "b"]
        assert "hostname" in extra["host_info"]


# ─── Config ───────────────────────────────────────────────────────────────────

class TestConfig:
    def test_load_config_with_key_object(self, keypair_a):
        priv, _ = keypair_a
        cfg = load_config(mode="transmitter", private_key=priv)
        assert cfg.mode == "transmitter"
        assert cfg.private_key is priv

    def test_invalid_mode(self, keypair_a):
        priv, _ = keypair_a
        with pytest.raises(ValueError, match="Invalid mode"):
            load_config(mode="sneaky", private_key=priv)

    def test_config_from_json_file(self, keypair_a, tmp_path):
        priv, _ = keypair_a
        pem_path = tmp_path / "key.pem"
        pem_path.write_bytes(export_ed25519_private(priv))

        cfg_file = tmp_path / "config.json"
        cfg_file.write_text(json.dumps({
            "c4e2e": {
                "mode": "receiver",
                "output_dir": str(tmp_path),
                "private_key_path": str(pem_path),
            }
        }))

        cfg = load_config(config_file=str(cfg_file))
        assert cfg.mode == "receiver"


# ─── Node Integration ─────────────────────────────────────────────────────────

class TestNodes:
    def test_transmitter_encrypt(self, tx_node, keypair_b):
        _, rx_pub = keypair_b
        frame = tx_node.encrypt(
            name="job001.json",
            job={"task": "scan", "target": "10.0.0.1"},
            recipient_pubkey=pubkey_to_b64(rx_pub),
        )
        assert isinstance(frame, bytes)
        assert len(frame) > 0

    def test_receiver_decrypt(self, keypair_a, keypair_b, tmp_path):
        tx_priv, tx_pub = keypair_a
        rx_priv, rx_pub = keypair_b

        tx_cfg = load_config(mode="transmitter", private_key=tx_priv)
        tx = create_node(tx_cfg)

        rx_cfg = load_config(
            mode="receiver",
            private_key=rx_priv,
            trusted_keys=[pubkey_to_b64(tx_pub)],
            output_dir=str(tmp_path),
        )
        rx = create_node(rx_cfg)

        job = {"task": "heartbeat", "agent_id": "007"}
        frame = tx.encrypt("hb.json", job, pubkey_to_b64(rx_pub))

        result = rx.decrypt(frame)
        assert result["name"] == "hb.json"
        assert result["job"] == job
        assert result["output_path"] is not None
        assert Path(result["output_path"]).exists()

    def test_receiver_rejects_untrusted(self, keypair_a, keypair_b, tmp_path):
        _, rx_pub = keypair_b
        rx_priv, _ = keypair_b
        bad_priv, bad_pub = keygen()

        bad_tx_cfg = load_config(mode="transmitter", private_key=bad_priv)
        bad_tx = create_node(bad_tx_cfg)
        frame = bad_tx.encrypt("evil.json", {"task": "exfil"}, pubkey_to_b64(rx_pub))

        rx_cfg = load_config(
            mode="receiver",
            private_key=rx_priv,
            trusted_keys=["AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="],  # some other key
            output_dir=str(tmp_path),
        )
        rx = create_node(rx_cfg)

        with pytest.raises(UntrustedSenderError):
            rx.decrypt(frame)

    def test_hybrid_bidirectional(self, keypair_a, keypair_b, tmp_path):
        priv_a, pub_a = keypair_a
        priv_b, pub_b = keypair_b

        cfg_a = load_config(
            mode="hybrid", private_key=priv_a,
            trusted_keys=[pubkey_to_b64(pub_b)], output_dir=str(tmp_path),
        )
        cfg_b = load_config(
            mode="hybrid", private_key=priv_b,
            trusted_keys=[pubkey_to_b64(pub_a)], output_dir=str(tmp_path),
        )
        node_a = create_node(cfg_a)
        node_b = create_node(cfg_b)

        frame = node_a.encrypt("a_to_b.json", {"msg": "hello"}, pubkey_to_b64(pub_b))
        result = node_b.decrypt(frame)
        assert result["job"]["msg"] == "hello"

        frame2 = node_b.encrypt("b_to_a.json", {"msg": "ack"}, pubkey_to_b64(pub_a))
        result2 = node_a.decrypt(frame2)
        assert result2["job"]["msg"] == "ack"

    def test_mode_mismatch(self, keypair_a):
        priv, _ = keypair_a
        cfg = load_config(mode="transmitter", private_key=priv)
        with pytest.raises(ModeError):
            from c4e2e.node import Receiver
            Receiver(cfg)

    def test_output_filename_from_metadata(self, keypair_a, keypair_b, tmp_path):
        tx_priv, tx_pub = keypair_a
        rx_priv, rx_pub = keypair_b

        tx_cfg = load_config(mode="transmitter", private_key=tx_priv)
        tx = create_node(tx_cfg)
        rx_cfg = load_config(
            mode="receiver", private_key=rx_priv,
            trusted_keys=[pubkey_to_b64(tx_pub)], output_dir=str(tmp_path),
        )
        rx = create_node(rx_cfg)

        custom_name = "operation_nightfall_results.json"
        frame = tx.encrypt(custom_name, {"data": "findings"}, pubkey_to_b64(rx_pub))
        result = rx.decrypt(frame)

        assert result["output_path"].name == custom_name

    def test_directory_traversal_protection(self, keypair_a, keypair_b, tmp_path):
        tx_priv, tx_pub = keypair_a
        rx_priv, rx_pub = keypair_b

        tx_cfg = load_config(mode="transmitter", private_key=tx_priv)
        tx = create_node(tx_cfg)
        rx_cfg = load_config(
            mode="receiver", private_key=rx_priv,
            trusted_keys=[pubkey_to_b64(tx_pub)], output_dir=str(tmp_path),
        )
        rx = create_node(rx_cfg)

        # Attempt path traversal in name
        frame = tx.encrypt("../../etc/passwd", {"evil": True}, pubkey_to_b64(rx_pub))
        result = rx.decrypt(frame)
        # Should be sanitized to just the basename
        assert "/" not in str(result["output_path"].name)
        assert result["output_path"].parent == tmp_path
