"""
c4e2e.config - Configuration loading

Priority order (highest → lowest):
  1. Explicitly passed kwargs / CLI flags
  2. Environment variables
  3. Config file (TOML or JSON)
  4. Defaults

Environment variable names:
  C4E2E_PRIVATE_KEY_PATH   - path to PEM private key file
  C4E2E_PRIVATE_KEY_B64    - base64-encoded raw Ed25519 private key bytes (32 bytes)
  C4E2E_PUBLIC_KEY_B64     - base64-encoded raw Ed25519 public key (for receiver allowlist)
  C4E2E_TRUSTED_KEYS       - comma-separated list of base64 pubkeys to trust
  C4E2E_OUTPUT_DIR         - directory to write decrypted output files
  C4E2E_MODE               - transmitter | receiver | hybrid
  C4E2E_CONFIG_FILE        - path to config file

Config file format (TOML):
  [c4e2e]
  mode = "hybrid"
  output_dir = "/tmp/c4e2e_out"
  private_key_path = "/etc/c4e2e/identity.pem"
  trusted_keys = ["base64key1", "base64key2"]

Config file format (JSON):
  {
    "c4e2e": {
      "mode": "hybrid",
      "output_dir": "/tmp/c4e2e_out",
      "private_key_path": "/etc/c4e2e/identity.pem",
      "trusted_keys": ["base64key1"]
    }
  }
"""

import os
import json
import base64
from pathlib import Path
from typing import List, Optional

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

from .crypto import import_ed25519_private, import_ed25519_public, b64_to_pubkey


VALID_MODES = {"transmitter", "receiver", "hybrid"}


class C4Config:
    def __init__(
        self,
        mode: str = "hybrid",
        private_key: Optional[Ed25519PrivateKey] = None,
        trusted_keys: Optional[List[Ed25519PublicKey]] = None,
        output_dir: str = ".",
    ):
        if mode not in VALID_MODES:
            raise ValueError(f"Invalid mode '{mode}'. Must be one of: {VALID_MODES}")
        self.mode = mode
        self.private_key = private_key
        self.trusted_keys: List[Ed25519PublicKey] = trusted_keys or []
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    @property
    def public_key(self) -> Optional[Ed25519PublicKey]:
        if self.private_key:
            return self.private_key.public_key()
        return None


def load_config(
    mode: str = None,
    private_key=None,          # Ed25519PrivateKey object (highest priority)
    private_key_path: str = None,
    private_key_b64: str = None,
    trusted_keys=None,         # List of str (b64) or Ed25519PublicKey objects
    output_dir: str = None,
    config_file: str = None,
    key_password: bytes = None,
) -> C4Config:
    """
    Load configuration from all sources, merging by priority.
    All params are optional — falls back to env vars and config file.
    """
    cfg = {}

    # 1. Load config file first (lowest priority among explicit sources)
    cfg_file = config_file or os.environ.get("C4E2E_CONFIG_FILE")
    if cfg_file:
        cfg.update(_load_config_file(cfg_file))

    # 2. Environment variables
    env = _load_from_env()
    for k, v in env.items():
        if v is not None:
            cfg[k] = v

    # 3. Explicit kwargs (highest priority)
    if mode:
        cfg["mode"] = mode
    if private_key_path:
        cfg["private_key_path"] = private_key_path
    if private_key_b64:
        cfg["private_key_b64"] = private_key_b64
    if trusted_keys is not None:
        cfg["trusted_keys"] = trusted_keys
    if output_dir:
        cfg["output_dir"] = output_dir

    # Resolve private key — direct object takes highest priority
    if private_key is not None:
        priv = private_key
    else:
        priv = _resolve_private_key(
            cfg.get("private_key_path"),
            cfg.get("private_key_b64"),
            key_password,
        )

    # Resolve trusted keys — accept key objects or b64 strings
    raw_trusted = cfg.get("trusted_keys", [])
    tkeys = _resolve_trusted_keys(raw_trusted)

    return C4Config(
        mode=cfg.get("mode", "hybrid"),
        private_key=priv,
        trusted_keys=tkeys,
        output_dir=cfg.get("output_dir", "."),
    )


def _load_from_env() -> dict:
    result = {}
    if v := os.environ.get("C4E2E_MODE"):
        result["mode"] = v
    if v := os.environ.get("C4E2E_PRIVATE_KEY_PATH"):
        result["private_key_path"] = v
    if v := os.environ.get("C4E2E_PRIVATE_KEY_B64"):
        result["private_key_b64"] = v
    if v := os.environ.get("C4E2E_OUTPUT_DIR"):
        result["output_dir"] = v
    if v := os.environ.get("C4E2E_TRUSTED_KEYS"):
        result["trusted_keys"] = [k.strip() for k in v.split(",") if k.strip()]
    return result


def _load_config_file(path: str) -> dict:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    suffix = path.suffix.lower()
    raw = path.read_text()

    if suffix == ".json":
        data = json.loads(raw)
        return data.get("c4e2e", data)
    elif suffix == ".toml":
        try:
            import tomllib
        except ImportError:
            try:
                import tomli as tomllib
            except ImportError:
                raise ImportError("Install 'tomli' for TOML config support: pip install tomli")
        data = tomllib.loads(raw)
        return data.get("c4e2e", data)
    else:
        raise ValueError(f"Unsupported config file format: {suffix} (use .json or .toml)")


def _resolve_private_key(
    path: Optional[str],
    b64: Optional[str],
    password: Optional[bytes],
) -> Optional[Ed25519PrivateKey]:
    if b64:
        # Raw 32-byte Ed25519 private key, base64 encoded
        raw = base64.b64decode(b64)
        return Ed25519PrivateKey.from_private_bytes(raw)
    if path:
        pem = Path(path).read_bytes()
        return import_ed25519_private(pem, password=password)
    return None


def _resolve_trusted_keys(keys) -> List[Ed25519PublicKey]:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey as _Pub
    resolved = []
    for k in (keys or []):
        if isinstance(k, _Pub):
            resolved.append(k)
        else:
            try:
                resolved.append(b64_to_pubkey(k))
            except Exception as e:
                raise ValueError(f"Invalid trusted key '{str(k)[:16]}...': {e}")
    return resolved


# ─── CLI Argument Builder ─────────────────────────────────────────────────────

def add_cli_args(parser):
    """Add c4e2e arguments to an argparse.ArgumentParser."""
    g = parser.add_argument_group("c4e2e encryption")
    g.add_argument("--c4e2e-mode", choices=list(VALID_MODES), help="Operation mode")
    g.add_argument("--c4e2e-key", metavar="PATH", help="Path to Ed25519 private key PEM")
    g.add_argument("--c4e2e-key-b64", metavar="B64", help="Base64-encoded Ed25519 private key")
    g.add_argument("--c4e2e-trusted", metavar="KEY", action="append", help="Trust a pubkey (base64), repeatable")
    g.add_argument("--c4e2e-output", metavar="DIR", help="Output directory for decrypted files")
    g.add_argument("--c4e2e-config", metavar="FILE", help="Path to config file (.json or .toml)")
    return parser


def config_from_args(args) -> C4Config:
    """Build a C4Config from parsed argparse args."""
    return load_config(
        mode=getattr(args, "c4e2e_mode", None),
        private_key_path=getattr(args, "c4e2e_key", None),
        private_key_b64=getattr(args, "c4e2e_key_b64", None),
        trusted_keys=getattr(args, "c4e2e_trusted", None),
        output_dir=getattr(args, "c4e2e_output", None),
        config_file=getattr(args, "c4e2e_config", None),
    )
