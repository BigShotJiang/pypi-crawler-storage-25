"""
c4e2e - True end-to-end encryption for agent-to-agent traffic

No0B@ckSappi3 | Offensive Security Tooling

Modes:
  transmitter  - encrypt and sign outgoing payloads only
  receiver     - verify and decrypt incoming payloads only
  hybrid       - both

Quick start:
    from c4e2e import keygen, load_config, create_node

    # Generate keypair
    priv, pub = keygen()

    # Create a hybrid node
    cfg = load_config(mode="hybrid", private_key=priv, trusted_keys=[pub])
    node = create_node(cfg)

    # Encrypt
    frame = node.encrypt("output.json", {"task": "recon"}, recipient_pubkey=pub)

    # Decrypt
    result = node.decrypt(frame)
"""

from .crypto import (
    generate_identity_keypair as keygen,
    export_ed25519_private,
    export_ed25519_public,
    import_ed25519_private,
    import_ed25519_public,
    pubkey_to_b64,
    b64_to_pubkey,
    sign,
    encrypt_for_recipient,
    decrypt_from_sender,
    verify,
)

from .payload import (
    build_metadata,
    build_extra,
    collect_host_info,
    pack_frame,
    unpack_frame,
)

from .config import (
    C4Config,
    load_config,
    add_cli_args,
    config_from_args,
)

from .node import (
    Transmitter,
    Receiver,
    Hybrid,
    create_node,
    C4NodeError,
    ModeError,
    SignatureError,
    UntrustedSenderError,
)

from .crypto import encrypt_for_recipient
__all__ = [
    # Keygen
    "keygen",
    "export_ed25519_private",
    "export_ed25519_public",
    "import_ed25519_private",
    "import_ed25519_public",
    "pubkey_to_b64",
    "b64_to_pubkey",
    "sign",
    "verify",

    # Crypto (ADD THESE)
    "encrypt_for_recipient",
    "decrypt_from_sender",

    # Payload
    "build_metadata",
    "build_extra",
    "collect_host_info",
    "pack_frame",
    "unpack_frame",

    # Config
    "C4Config",
    "load_config",
    "add_cli_args",

    # Nodes
    "Transmitter",
    "Receiver",
    "Hybrid",
    "create_node",

    # Errors
    "C4NodeError",
    "ModeError",
    "SignatureError",
    "UntrustedSenderError",
]