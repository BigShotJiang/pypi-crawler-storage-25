#!/usr/bin/env python3
"""
c4e2e CLI - Standalone payload tool

Usage:
  # Generate a keypair
  c4e2e keygen --out-dir ./keys

  # Encrypt a payload
  c4e2e encrypt \
    --key ./keys/identity.pem \
    --recipient-key <base64_pubkey> \
    --name "job_001.json" \
    --job '{"task":"scan","target":"10.0.0.0/24"}' \
    --out ./payload.bin

  # Decrypt a payload
  c4e2e decrypt \
    --key ./keys/identity.pem \
    --trusted-key <base64_pubkey> \
    --output-dir ./decrypted \
    --payload ./payload.bin

  # Inspect a payload (metadata only, no decryption)
  c4e2e inspect --payload ./payload.bin

  # Run as a file-watcher daemon (decrypt incoming files)
  c4e2e watch \
    --key ./keys/identity.pem \
    --trusted-key <base64_pubkey> \
    --watch-dir ./inbox \
    --output-dir ./decrypted
"""

import argparse
import json
import sys
import os
import time
import logging
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger("c4e2e.cli")


def cmd_keygen(args):
    from c4e2e import keygen, export_ed25519_private, pubkey_to_b64
    from cryptography.hazmat.primitives import serialization

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    priv, pub = keygen()

    priv_path = out_dir / "identity.pem"
    pub_path = out_dir / "identity.pub"

    password = args.password.encode() if args.password else None
    priv_pem = export_ed25519_private(priv, password=password)
    priv_path.write_bytes(priv_pem)
    priv_path.chmod(0o600)

    pub_b64 = pubkey_to_b64(pub)
    pub_path.write_text(pub_b64 + "\n")

    print(f"[+] Private key → {priv_path}")
    print(f"[+] Public key  → {pub_path}")
    print(f"[+] Public key (base64):\n    {pub_b64}")


def cmd_encrypt(args):
    from c4e2e import load_config, create_node, b64_to_pubkey

    if not args.key and not os.environ.get("C4E2E_PRIVATE_KEY_PATH"):
        print("[-] Error: --key required (or set C4E2E_PRIVATE_KEY_PATH)", file=sys.stderr)
        sys.exit(1)

    cfg = load_config(
        mode="transmitter",
        private_key_path=args.key,
        output_dir=args.output_dir or ".",
        config_file=args.config,
    )
    node = create_node(cfg)

    recipient_key = args.recipient_key or os.environ.get("C4E2E_RECIPIENT_PUBKEY")
    if not recipient_key:
        print("[-] Error: --recipient-key required", file=sys.stderr)
        sys.exit(1)

    job = json.loads(args.job) if args.job else {}
    if args.job_file:
        job = json.loads(Path(args.job_file).read_text())

    tags = args.tags.split(",") if args.tags else None

    frame = node.encrypt(
        name=args.name,
        job=job,
        recipient_pubkey=recipient_key,
        job_id=args.job_id,
        tags=tags,
        include_host=not args.no_host_info,
    )

    if args.out:
        Path(args.out).write_bytes(frame)
        print(f"[+] Encrypted payload written → {args.out} ({len(frame)} bytes)")
    else:
        import base64
        sys.stdout.buffer.write(base64.b64encode(frame))
        print()


def cmd_decrypt(args):
    from c4e2e import load_config, create_node, UntrustedSenderError, SignatureError

    cfg = load_config(
        mode="receiver",
        private_key_path=args.key,
        trusted_keys=args.trusted_key or [],
        output_dir=args.output_dir or ".",
        config_file=args.config,
    )
    node = create_node(cfg)

    if args.payload:
        frame = Path(args.payload).read_bytes()
    else:
        import base64
        frame = base64.b64decode(sys.stdin.buffer.read().strip())

    try:
        result = node.decrypt(frame, write_output=True)
    except UntrustedSenderError as e:
        print(f"[-] Untrusted sender: {e}", file=sys.stderr)
        sys.exit(2)
    except SignatureError as e:
        print(f"[-] Signature invalid: {e}", file=sys.stderr)
        sys.exit(3)
    except Exception as e:
        print(f"[-] Decryption failed: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"[+] Decrypted '{result['name']}' → {result['output_path']}")
    if args.print_job:
        print(json.dumps(result["job"], indent=2))


def cmd_inspect(args):
    from c4e2e.payload import unpack_frame

    frame = Path(args.payload).read_bytes()
    metadata, encrypted_body = unpack_frame(frame)

    print("── Metadata (unencrypted) ──────────────────────")
    print(json.dumps(metadata, indent=2))
    print()
    print("── Encrypted Body Fields ───────────────────────")
    for k, v in encrypted_body.items():
        print(f"  {k}: {str(v)[:64]}{'...' if len(str(v)) > 64 else ''}")
    print()
    print(f"── Frame size: {len(frame)} bytes ────────────────")


def cmd_watch(args):
    from c4e2e import load_config, create_node, UntrustedSenderError, SignatureError

    cfg = load_config(
        mode="receiver",
        private_key_path=args.key,
        trusted_keys=args.trusted_key or [],
        output_dir=args.output_dir or ".",
        config_file=args.config,
    )
    node = create_node(cfg)

    watch_dir = Path(args.watch_dir)
    watch_dir.mkdir(parents=True, exist_ok=True)

    processed = set()
    print(f"[*] Watching {watch_dir} for encrypted payloads...")
    print(f"[*] Output → {cfg.output_dir}")
    print(f"[*] Trusted keys: {len(node.trusted_keys)}")
    print("[*] Press Ctrl+C to stop\n")

    try:
        while True:
            for f in watch_dir.glob("*.bin"):
                if f in processed:
                    continue
                processed.add(f)
                print(f"[>] Processing {f.name}...")
                try:
                    frame = f.read_bytes()
                    result = node.decrypt(frame, write_output=True)
                    print(f"[+] {f.name} → {result['output_path']}")
                    if args.delete_after:
                        f.unlink()
                except UntrustedSenderError as e:
                    print(f"[-] UNTRUSTED: {f.name} — {e}")
                except SignatureError as e:
                    print(f"[-] BAD SIG: {f.name} — {e}")
                except Exception as e:
                    print(f"[-] ERROR: {f.name} — {e}")
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\n[*] Stopped.")


def main():
    parser = argparse.ArgumentParser(
        prog="c4e2e",
        description="No0B@ckSappi3 - E2E Encryption Tool",
    )
    parser.add_argument("--config", metavar="FILE", help="Config file (.json or .toml)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    # keygen
    p = sub.add_parser("keygen", help="Generate Ed25519 identity keypair")
    p.add_argument("--out-dir", default="./c4e2e_keys", help="Output directory")
    p.add_argument("--password", help="Optional PEM encryption password")

    # encrypt
    p = sub.add_parser("encrypt", help="Encrypt a payload")
    p.add_argument("--key", metavar="PEM", help="Sender private key path")
    p.add_argument("--recipient-key", metavar="B64", help="Recipient public key (base64)")
    p.add_argument("--name", required=True, help="Output filename (written by receiver)")
    p.add_argument("--job", metavar="JSON", help="Job data as JSON string")
    p.add_argument("--job-file", metavar="FILE", help="Job data from JSON file")
    p.add_argument("--job-id", help="Job ID to embed in extra")
    p.add_argument("--tags", help="Comma-separated tags")
    p.add_argument("--no-host-info", action="store_true", help="Omit host info from extra")
    p.add_argument("--out", metavar="FILE", help="Output file (default: stdout base64)")
    p.add_argument("--output-dir", metavar="DIR", default=".")

    # decrypt
    p = sub.add_parser("decrypt", help="Decrypt a payload")
    p.add_argument("--key", metavar="PEM", help="Receiver private key path")
    p.add_argument("--trusted-key", metavar="B64", action="append", help="Trusted sender pubkey (repeatable)")
    p.add_argument("--payload", metavar="FILE", help="Payload file (default: stdin base64)")
    p.add_argument("--output-dir", metavar="DIR", default="./c4e2e_out")
    p.add_argument("--print-job", action="store_true", help="Print decrypted job to stdout")

    # inspect
    p = sub.add_parser("inspect", help="Inspect payload metadata (no decryption)")
    p.add_argument("--payload", required=True, metavar="FILE")

    # watch
    p = sub.add_parser("watch", help="Watch a directory for incoming payloads")
    p.add_argument("--key", metavar="PEM", required=True)
    p.add_argument("--trusted-key", metavar="B64", action="append")
    p.add_argument("--watch-dir", required=True, metavar="DIR")
    p.add_argument("--output-dir", default="./c4e2e_out", metavar="DIR")
    p.add_argument("--interval", type=float, default=1.0, help="Poll interval seconds (default: 1.0)")
    p.add_argument("--delete-after", action="store_true", help="Delete payload after successful decryption")

    args = parser.parse_args()

    dispatch = {
        "keygen": cmd_keygen,
        "encrypt": cmd_encrypt,
        "decrypt": cmd_decrypt,
        "inspect": cmd_inspect,
        "watch": cmd_watch,
    }
    dispatch[args.cmd](args)


if __name__ == "__main__":
    main()
