﻿braindecode.models.InterpolatedModel
====================================

.. currentmodule:: braindecode.models

.. autofunction:: InterpolatedModel

.. include:: braindecode.models.InterpolatedModel.examples

.. raw:: html

    <div style='clear:both'></div>