﻿braindecode.visualization.compute_metrics
=========================================

.. currentmodule:: braindecode.visualization

.. autofunction:: compute_metrics

.. include:: braindecode.visualization.compute_metrics.examples

.. raw:: html

    <div style='clear:both'></div>