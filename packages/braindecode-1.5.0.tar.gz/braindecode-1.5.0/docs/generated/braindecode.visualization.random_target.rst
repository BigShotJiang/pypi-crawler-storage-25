﻿braindecode.visualization.random_target
=======================================

.. currentmodule:: braindecode.visualization

.. autofunction:: random_target

.. include:: braindecode.visualization.random_target.examples

.. raw:: html

    <div style='clear:both'></div>