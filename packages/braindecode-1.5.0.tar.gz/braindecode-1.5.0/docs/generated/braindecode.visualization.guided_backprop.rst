﻿braindecode.visualization.guided_backprop
=========================================

.. currentmodule:: braindecode.visualization

.. autofunction:: guided_backprop

.. include:: braindecode.visualization.guided_backprop.examples

.. raw:: html

    <div style='clear:both'></div>