﻿braindecode.visualization.METRIC\_NAMES
=======================================

.. currentmodule:: braindecode.visualization

.. autodata:: METRIC_NAMES