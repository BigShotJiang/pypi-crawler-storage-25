﻿braindecode.visualization.amplitude_gradients
=============================================

.. currentmodule:: braindecode.visualization

.. autofunction:: amplitude_gradients

.. include:: braindecode.visualization.amplitude_gradients.examples

.. raw:: html

    <div style='clear:both'></div>