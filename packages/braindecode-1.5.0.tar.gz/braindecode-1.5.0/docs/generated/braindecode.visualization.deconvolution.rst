﻿braindecode.visualization.deconvolution
=======================================

.. currentmodule:: braindecode.visualization

.. autofunction:: deconvolution

.. include:: braindecode.visualization.deconvolution.examples

.. raw:: html

    <div style='clear:both'></div>