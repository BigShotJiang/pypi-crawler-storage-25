﻿braindecode.visualization.layer_grad_cam
========================================

.. currentmodule:: braindecode.visualization

.. autofunction:: layer_grad_cam

.. include:: braindecode.visualization.layer_grad_cam.examples

.. raw:: html

    <div style='clear:both'></div>