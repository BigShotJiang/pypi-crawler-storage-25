﻿braindecode.visualization.amplitude_gradients_per_trial
=======================================================

.. currentmodule:: braindecode.visualization

.. autofunction:: amplitude_gradients_per_trial

.. include:: braindecode.visualization.amplitude_gradients_per_trial.examples

.. raw:: html

    <div style='clear:both'></div>