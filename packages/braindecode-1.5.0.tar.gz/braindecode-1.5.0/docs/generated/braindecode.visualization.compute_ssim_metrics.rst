﻿braindecode.visualization.compute_ssim_metrics
==============================================

.. currentmodule:: braindecode.visualization

.. autofunction:: compute_ssim_metrics

.. include:: braindecode.visualization.compute_ssim_metrics.examples

.. raw:: html

    <div style='clear:both'></div>