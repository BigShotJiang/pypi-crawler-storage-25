﻿braindecode.visualization.saliency
==================================

.. currentmodule:: braindecode.visualization

.. autofunction:: saliency

.. include:: braindecode.visualization.saliency.examples

.. raw:: html

    <div style='clear:both'></div>