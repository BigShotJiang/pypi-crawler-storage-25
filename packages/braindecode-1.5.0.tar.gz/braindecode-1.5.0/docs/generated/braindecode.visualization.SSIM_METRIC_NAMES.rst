﻿braindecode.visualization.SSIM\_METRIC\_NAMES
=============================================

.. currentmodule:: braindecode.visualization

.. autodata:: SSIM_METRIC_NAMES