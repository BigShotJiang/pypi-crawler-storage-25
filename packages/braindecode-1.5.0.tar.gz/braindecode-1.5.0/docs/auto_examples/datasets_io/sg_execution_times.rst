
:orphan:

.. _sphx_glr_auto_examples_datasets_io_sg_execution_times:


Computation times
=================
**16:01.755** total execution time for 10 files **from auto_examples/datasets_io**:

.. container::

  .. raw:: html

    <style scoped>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
    </style>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script type="text/javascript" class="init">
    $(document).ready( function () {
        $('table.sg-datatable').DataTable({order: [[1, 'desc']]});
    } );
    </script>

  .. list-table::
   :header-rows: 1
   :class: table table-striped sg-datatable

   * - Example
     - Time
     - Mem (MB)
   * - :ref:`sphx_glr_auto_examples_datasets_io_plot_benchmark_preprocessing.py` (``plot_benchmark_preprocessing.py``)
     - 13:21.955
     - 806.5
   * - :ref:`sphx_glr_auto_examples_datasets_io_plot_hub_integration.py` (``plot_hub_integration.py``)
     - 00:31.560
     - 621.7
   * - :ref:`sphx_glr_auto_examples_datasets_io_plot_split_dataset.py` (``plot_split_dataset.py``)
     - 00:29.925
     - 621.6
   * - :ref:`sphx_glr_auto_examples_datasets_io_plot_tuh_discrete_multitarget.py` (``plot_tuh_discrete_multitarget.py``)
     - 00:28.786
     - 622.1
   * - :ref:`sphx_glr_auto_examples_datasets_io_plot_load_save_datasets.py` (``plot_load_save_datasets.py``)
     - 00:22.804
     - 621.6
   * - :ref:`sphx_glr_auto_examples_datasets_io_plot_moabb_dataset_example.py` (``plot_moabb_dataset_example.py``)
     - 00:18.692
     - 621.6
   * - :ref:`sphx_glr_auto_examples_datasets_io_plot_custom_dataset_example.py` (``plot_custom_dataset_example.py``)
     - 00:17.508
     - 621.8
   * - :ref:`sphx_glr_auto_examples_datasets_io_plot_mne_dataset_example.py` (``plot_mne_dataset_example.py``)
     - 00:10.524
     - 621.7
   * - :ref:`sphx_glr_auto_examples_datasets_io_benchmark_lazy_eager_loading.py` (``benchmark_lazy_eager_loading.py``)
     - 00:00.000
     - 0.0
   * - :ref:`sphx_glr_auto_examples_datasets_io_bids_dataset_example.py` (``bids_dataset_example.py``)
     - 00:00.000
     - 0.0
