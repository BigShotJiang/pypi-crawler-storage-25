# pyVHDLModelTreesitter
[![Version][shield-version]][pyVHDLModelTreesitter-pypi]
[![Releases][shield-releases]][pyVHDLModelTreesitter-releases]
[![Gitlab][shield-pipeline]][pyVHDLModelTreesitter-pipeline]
[![pre-commit][shield-precommit]][precommit-github]
[![Codecov][shield-codecov]][pyVHDLModelTreesitter-codecov]
[![Python Version][shield-python-version]][pyVHDLModelTreesitter-pypi]

`pyVHDLModelTreesitter` is an implementation of the
[`pyVHDLModel`][pyVHDLModel-github] API using `tree-sitter-vhdl`.

> Disclaimer: This project is in early development and only implements a
              fraction of the features of [`pyVHDLModel`][pyVHDLModel-github].

## Installation

### `pip`

You can install the latest release from [PyPI][pyVHDLModelTreesitter-pypi]:

```bash
pip install pyVHDLModelTreesitter
```

### Source tarball

You can download source releases from the
[Gitlab Releases page][pyVHDLModelTreesitter-releases].

## Documentation

In the simplest cases where you just want to parse a VHDL file:

```python3
import pyVHDLModelTreesitter

document = pyVHDLModelTreesitter.Document.from_file("path/to/file.vhd")
```

`pyVHDLModelTreesitter.Document` is a subclass of
[`pyVHDLModel.Document`][pyVHDLModel-Document].

Detailed documentation is currently unavailable.

## Setup for Development

### Dependencies

Developers aiming to contribute to this repository need the following tools:

- `make`
- `uv`

All other dependencies are automatically obtained.

### Initial setup

Simply:

```bash
source ./settings.sh
```

You can `make help` to see what actions are available.

---

[precommit-github]: https://github.com/pre-commit/pre-commit
[pyVHDLModel-Document]: https://vhdl.github.io/pyVHDLModel/pyVHDLModel/pyVHDLModel.html#pyVHDLModel.Document
[pyVHDLModel-github]: https://github.com/VHDL/pyVHDLModel
[pyVHDLModelTreesitter-codecov]: https://codecov.io/gitlab/dawalters/pyVHDLModelTreesitter
[pyVHDLModelTreesitter-pipeline]: https://gitlab.com/dawalters/pyVHDLModelTreesitter/-/pipelines?page=1&scope=all&ref=develop
[pyVHDLModelTreesitter-pypi]: https://pypi.org/project/pyVHDLModelTreesitter
[pyVHDLModelTreesitter-releases]: https://gitlab.com/dawalters/pyVHDLModelTreesitter/-/releases
[shield-codecov]: https://codecov.io/gitlab/dawalters/pyVHDLModelTreesitter/branch/develop/graph/badge.svg
[shield-pipeline]: https://gitlab.com/dawalters/pyVHDLModelTreesitter/badges/develop/pipeline.svg
[shield-precommit]: https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit
[shield-python-version]: https://img.shields.io/pypi/pyversions/pyVHDLModelTreesitter
[shield-releases]: https://gitlab.com/dawalters/pyVHDLModelTreesitter/-/badges/release.svg
[shield-version]: https://img.shields.io/pypi/v/pyVHDLModelTreesitter
