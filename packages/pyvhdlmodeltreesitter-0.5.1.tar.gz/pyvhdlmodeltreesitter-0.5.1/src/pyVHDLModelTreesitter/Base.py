"""Submodule mirroring modified aspects of pyVHDLModel.Base."""

from __future__ import annotations

__all__ = [
    "Range",
]

from typing import TYPE_CHECKING, Self

import pyVHDLModel

if TYPE_CHECKING:
    from tree_sitter import Node

from pyVHDLModelTreesitter._errors import (
    NodeExtraChildError,
    NodeMissingChildError,
    NodeTextIsInvalidError,
    NodeTextIsNoneError,
    NotImplementedWarning,
)
from pyVHDLModelTreesitter._parse import parse_simple_expression
from pyVHDLModelTreesitter.treesitter import TreesitterNodeMixin


def parse_as_direction(string: str) -> pyVHDLModel.Base.Direction | None:
    """
    Parse a string as a direction.

    This will accept any mix of the following:
        - Incorrect capitalisation
            - "tO"
            - "To"
        - Split words with whitespace
            - "down to"
    """
    # TODO: make a PR on pyVHDLModel to add this
    string = "".join(string.split()).lower().capitalize()
    if string == "Downto":
        string = "DownTo"
    try:
        return pyVHDLModel.Base.Direction[string]
    except IndexError:
        return None


def parse_as_mode(string: str) -> pyVHDLModel.Base.Mode | None:
    """
    Parse a string as a mode.

    This will accept any mix of the following:
        - Incorrect capitalisation
            - "IN"
            - "iN"
            - "in"
        - Split words with whitespace
            - "in out"
    """
    # TODO: make a PR on pyVHDLModel to add this
    string = "".join(string.split()).lower().capitalize()
    if string == "Inout":
        string = "InOut"
    try:
        return pyVHDLModel.Base.Mode[string]
    except IndexError:
        return None


class Range(TreesitterNodeMixin, pyVHDLModel.Base.Range):  # noqa: D101
    @classmethod
    def from_treesitter_node(  # noqa: C901, PLR0912
        cls,
        node: Node,
    ) -> Self | None:
        """
        Create a Range from a treesitter node.

        Raises
        ------
        NodeExtraChildError:
            If `node.children` does not have 2 elements.
        NodeMissingChildError:
            If `node.type` is not `simple_range`.
        NodeTextIsInvalidError:
            If the direction in `node` could not be parsed.
        NodeTextIsNoneError:
            If `node` or any relevant subnode doesn't define `text`.

        """
        if node.type != "simple_range":
            raise NodeMissingChildError(node, "simple_range")
        if node.text is None or len(node.text) == 0:
            raise NodeTextIsNoneError(node)
        if len(node.children) != 3:  # noqa: PLR2004
            raise NodeExtraChildError(node, "all children", 3)
        left = node.child(0)
        if left is None:
            raise NodeMissingChildError(node, "first-child")
        if left.type != "simple_expression":
            NotImplementedWarning.warn_child_type(left)
            return None
        if left.text is None or len(left.text) == 0:
            raise NodeTextIsNoneError(left)
        direction_node = node.child(1)
        if direction_node is None:
            raise NodeMissingChildError(node, "second-child")
        if len(direction_node.type) == 0:
            NotImplementedWarning.warn_child_type(direction_node)
            return None
        if direction_node.text is None or len(direction_node.text) == 0:
            raise NodeTextIsNoneError(direction_node)
        direction_str = direction_node.text.decode("utf-8")
        right = node.child(2)
        if right is None:
            raise NodeMissingChildError(node, "third-child")
        if right.type != "simple_expression":
            NotImplementedWarning.warn_child_type(right)
            return None
        if right.text is None or len(right.text) == 0:
            raise NodeTextIsNoneError(right)
        left_expr = parse_simple_expression(left)
        if left_expr is None:
            return None
        right_expr = parse_simple_expression(right)
        if right_expr is None:
            return None
        direction = parse_as_direction(direction_str)
        if direction is None:
            raise NodeTextIsInvalidError(
                node,
                f"'{direction_str}' is not a valid VHDL direction",
            )
        return cls(left_expr, right_expr, direction, _treesitter_node=node)

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return (
            self._leftBound == other._leftBound
            and self._rightBound == other._rightBound
            and self._direction == other._direction
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._leftBound,
                self._rightBound,
                self._direction,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_leftBound={self._leftBound!r}, "
            f"_rightBound={self._rightBound!r}, "
            f"_direction={self._direction!r}, "
            ")"
        )
