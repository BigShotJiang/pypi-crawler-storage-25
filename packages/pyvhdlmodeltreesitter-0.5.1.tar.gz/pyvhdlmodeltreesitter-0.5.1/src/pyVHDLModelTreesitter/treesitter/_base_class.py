"""Submodule defining the base class for all treesitter parses."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from tree_sitter import Node


class TreesitterNodeMixin:
    _treesitter_node: Node | None

    def __init__(
        self,
        *args: Any,  # noqa: ANN401
        _treesitter_node: Node | None = None,
        **kwargs: Any,  # noqa: ANN401
    ) -> None:
        """Create a TreesitterNodeMixin."""
        super().__init__(*args, **kwargs)
        self._treesitter_node = _treesitter_node

    # TODO: we'd like to abc the `from_treesitter_node` method but it has
    #       different type signatures in some classes atm
    # @classmethod
    # def from_treesitter_node(
    #     cls,
    #     node: Node,
    # ) -> Self | None:
