"""Submodule defining all treesitter queries used in the library."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, ClassVar, Protocol

import tree_sitter
import tree_sitter_vhdl

from pyVHDLModelTreesitter._errors import NodeExtraChildError, NodeMissingChildError

LANGUAGE = tree_sitter.Language(tree_sitter_vhdl.language())
PARSER = tree_sitter.Parser(LANGUAGE)

_FIND_END_OF_WORD = re.compile(r"(.)([A-Z][a-z]+)")
_FIND_START_OF_WORD = re.compile(r"([a-z])([0-9A-Z])")


def camel_case_to_lower_snake_case(name: str) -> str:
    """Convert camel case to lower snake case."""
    s1 = _FIND_END_OF_WORD.sub(r"\1_\2", name)
    return _FIND_START_OF_WORD.sub(r"\1_\2", s1).lower()


class Query(Protocol):
    """Base class for all queries."""

    FILE: ClassVar[Path]
    TEXT: ClassVar[str]
    QUERY: ClassVar[tree_sitter.Query]

    def __init_subclass__(cls, **kwargs: Any) -> None:  # noqa: ANN401
        """
        Initialise subclass.

        This requires `FILE` to be defined, and defines `TEXT` and `QUERY`.

        Raises
        ------
        TypeError:
            If `FILE` is not a defined `ClassVar` of the subclass.

        """
        super().__init_subclass__(**kwargs)
        class_lower_snake_case = camel_case_to_lower_snake_case(cls.__name__)
        cls.FILE = Path(__file__).parent / "queries" / f"{class_lower_snake_case}.scm"
        if not cls.FILE.exists():
            message = f"File '{cls.FILE}' does not exist"
            raise TypeError(message)
        cls.TEXT = cls.FILE.read_text()
        cls.QUERY = tree_sitter.Query(LANGUAGE, cls.TEXT)

    @classmethod
    def capture(
        cls,
        node: tree_sitter.Node,
        match_limit: int = 2**32 - 1,
    ) -> dict[str, list[tree_sitter.Node]]:
        """
        Perform a capture on a given node.

        WARNING: `match_limit` applies to the sum of all `@` references in a
        query. So one "total" match of a query with three `@` parts requires a
        `match_limit` of three or higher.
        """
        return tree_sitter.QueryCursor(cls.QUERY, match_limit=match_limit).captures(
            node,
        )

    @classmethod
    def capture_first_root(
        cls,
        node: tree_sitter.Node,
    ) -> dict[str, list[tree_sitter.Node]]:
        """
        Capture certain fields of a root nods of a query.

        Note: This has to be run on a `node` that has the same `type` as the
        root node of the query.

        Note: The `QUERY` **MUST** have its root node anchored as `@root`.

        See `function_call.scm` for an example.

        Raises
        ------
        NodeExtraChildError:
            If the `@root` anchor is captrued more than once in any match.
        NodeMissingChildError:
            If the `@root` anchor is not part of the capture in a match.

        """
        matches = tree_sitter.QueryCursor(cls.QUERY).matches(node)
        processed_matches: dict[str, list[tree_sitter.Node]] = {}
        for _, match in matches:
            root = match.get("root", [])
            if len(root) == 0:
                # TODO: this is actually a missing "anchor" error
                raise NodeMissingChildError(node, "root")
            if len(root) > 1:
                # TODO: this is actually an extra "anchor" error
                raise NodeExtraChildError(node, "root", 1)
            root_node = root[0]
            if root_node == node:
                if processed_matches.get("root") is None:
                    processed_matches["root"] = [root_node]
                for k, v in match.items():
                    if k == "root":
                        continue
                    if processed_matches.get(k) is None:
                        processed_matches[k] = v
                    else:
                        processed_matches[k].extend(v)
        return processed_matches


class AddingExpression(Query):
    """Class defining the query to expand an adding expression."""


class ArchitectureDefinition(Query):
    """Class defining the query to expand a single architecture definition."""


class AssociationElement(Query):
    """Class defining the query to expand an association element."""


class AssociationElements(Query):
    """Class defining the query to collect a set of association elements."""


class ComponentInstantiationStatement(Query):
    """Class defining the query to expand a component instantiation statement."""


class ConstantDeclaration(Query):
    """Class defining the query to expand a constant declaration."""


class Constrained1DArray(Query):
    """Class defining the query to expand a constrained 1D array symbol."""


class DesignUnits(Query):
    """Class defining the query to get all design units."""


class EntityDeclaration(Query):
    """Class defining the query to expand a single entity declaration."""


class FunctionCall(Query):
    """Class defining the query to expand a function call expression."""


class IgnorableParentheses(Query):
    """Class defining the query to expand an ignorable set of parentheses."""


class InterfaceDeclaration(Query):
    """Class defining the query to expand a single interface declaration."""


class InterfaceDeclarations(Query):
    """Class defining the query to get all interface declarations."""


class LibraryClauses(Query):
    """Class defining the query to get all library clauses."""


class LibraryNamespaces(Query):
    """Class defining the query to get all library namespaces."""


class MultiplyingExpression(Query):
    """Class defining the query to expand a multiplying expression."""


class PackageDeclaration(Query):
    """Class defining the query to expand a package declaration."""


class PackageDefinition(Query):
    """Class defining the query to expand a package definition."""


class SelectedNames(Query):
    """Class defining the query to get all selected names in a list."""


class SimpleSubtype(Query):
    """Class defining the query to expand a simple subtype symbol."""


class TypeConversion(Query):
    """Class defining the query to expand a type conversion expression."""


class UseClauses(Query):
    """Class defining the query to get all use clauses."""
