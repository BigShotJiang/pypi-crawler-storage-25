"""Submodule defining utilities surrounding treesitter."""

from __future__ import annotations

from functools import cmp_to_key
from typing import TYPE_CHECKING, Literal, overload

from pyVHDLModelTreesitter._errors import (
    NodeExtraChildError,
    NodeMissingChildError,
    NodeTextIsNoneError,
)

if TYPE_CHECKING:
    from collections.abc import Iterable

    from tree_sitter import Node

    from pyVHDLModelTreesitter.treesitter._base_class import TreesitterNodeMixin


def get_nodes(
    node: Node,
    captures: dict[str, list[Node]],
    name: str,
    *,
    optional: bool = False,
) -> list[Node]:
    """
    Get nodes with a given name from a capture.

    Raises
    ------
    NodeMissingChildError:
        If the given name does not exist in the capture.

    """
    nodes = captures.get(name, [])
    if len(nodes) == 0:
        if optional:
            return []
        raise NodeMissingChildError(node, name)
    return nodes


@overload
def get_node(
    node: Node,
    captures: dict[str, list[Node]],
    name: str,
    *,
    optional: Literal[False] = False,
) -> Node: ...


@overload
def get_node(
    node: Node,
    captures: dict[str, list[Node]],
    name: str,
    *,
    optional: Literal[True] = True,
) -> Node | None: ...


def get_node(
    node: Node,
    captures: dict[str, list[Node]],
    name: str,
    *,
    optional: bool = False,
) -> Node | None:
    """
    Get node with a given name from a capture.

    Raises
    ------
    NodeExtraChildError:
        If the given name exists more than once in the capture.
    NodeMissingChildError:
        If the given name doesn't exist and `optional == False`.

    """
    nodes = get_nodes(node, captures, name, optional=optional)
    if optional and len(nodes) == 0:
        return None
    if len(nodes) == 0:
        raise NodeMissingChildError(node, name)
    if len(nodes) != 1:
        raise NodeExtraChildError(node, name, 1)
    return nodes[0]


def compare_in_text_order(left: TreesitterNodeMixin, right: TreesitterNodeMixin) -> int:
    if left._treesitter_node is None or right._treesitter_node is None:  # noqa: SLF001
        return 0
    return left._treesitter_node.start_byte - right._treesitter_node.start_byte  # noqa: SLF001


def sort_into_text_order(
    nodes: Iterable[TreesitterNodeMixin],
) -> list[TreesitterNodeMixin]:
    return sorted(nodes, key=cmp_to_key(compare_in_text_order))


def get_node_text(node: Node) -> str:
    """
    Get the `text` from a node, raising an exception if there is none.

    Raises
    ------
    NodeTextIsNoneError:
        If `node.text is None`.

    """
    if node.text is None:
        raise NodeTextIsNoneError(node)
    return node.text.decode()
