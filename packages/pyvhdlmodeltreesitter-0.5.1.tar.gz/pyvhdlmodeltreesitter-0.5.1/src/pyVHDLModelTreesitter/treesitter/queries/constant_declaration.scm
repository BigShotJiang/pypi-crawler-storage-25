(constant_declaration
    (identifier_list
        (identifier) @name
    )
    (subtype_indication) @type
    (initialiser
        (variable_assignment)
        (conditional_expression) @value
    )
)
