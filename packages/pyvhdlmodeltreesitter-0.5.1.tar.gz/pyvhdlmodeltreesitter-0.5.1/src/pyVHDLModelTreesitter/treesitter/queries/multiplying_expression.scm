(simple_expression
    (simple_expression)     @left
    (multiplying_operator)  @operator
    (simple_expression)     @right
) @root
