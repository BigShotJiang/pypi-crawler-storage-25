(subtype_indication
    type: (name
        (identifier) @type_name
    )
) @root

(subtype_indication
    type: (name
        (library_type) @type_name
    )
) @root
