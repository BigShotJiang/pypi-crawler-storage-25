(package_declaration
    (identifier) @name
    (package_declaration_body) @content
    (end_package)
) @root
