; without `signal` before the name
(interface_declaration
    (identifier_list) @name     ; https://github.com/jpt13653903/tree-sitter-vhdl/issues/69
    (simple_mode_indication
        (mode)? @mode
        (subtype_indication) @type
        (initialiser
            (variable_assignment)
            (conditional_expression) @default
        )?
    )
)
; with signal before the name
(interface_signal_declaration
    (identifier_list) @name     ; https://github.com/jpt13653903/tree-sitter-vhdl/issues/69
    (simple_mode_indication
        (mode)? @mode
        (subtype_indication) @type
        (initialiser
            (variable_assignment)
            (conditional_expression) @default
        )?
    )
)
