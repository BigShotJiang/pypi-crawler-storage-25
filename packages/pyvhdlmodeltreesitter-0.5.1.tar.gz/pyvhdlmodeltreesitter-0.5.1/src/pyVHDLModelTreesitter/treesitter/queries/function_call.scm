(simple_expression
    (name
        (library_function)  @function
        (parenthesis_group
            (association_or_range_list
                (association_element)
            )   @arguments
        )
    )
) @root

(simple_expression
    (name
        (operator_symbol)   @function
        (parenthesis_group
            (association_or_range_list
                (association_element)
            )   @arguments
        )
    )
) @root

; Note: this is going to erroneously capture some type conversions
(simple_expression
    (name
        (identifier)    @function
        (parenthesis_group
            (association_or_range_list
                (association_element)
            )   @arguments
        )
    )
) @root
