(component_instantiation_statement
    (label_declaration (label) @label)
    (instantiated_unit
        (library_namespace)? @namespace
        (name (identifier) @entity)
        (identifier)? @architecture
    )
    (generic_map_aspect
        (association_list
            (association_element) @generics
        )
    )?
    (port_map_aspect
        (association_list
            (association_element) @ports
        )
    )?
) @instance
