(simple_expression
    (name
        (library_type)  @type
        (parenthesis_group
            (association_or_range_list
                (association_element
                    (conditional_expression
                        (simple_expression)     @expression
                    )
                )
            )
        )
    )
) @root

; Note: this clashes with the `function_call.scm` query
(simple_expression
    (name
        (identifier)    @type
        (parenthesis_group
            (association_or_range_list
                (association_element
                    (conditional_expression
                        (simple_expression)     @expression
                    )
                )
            )
        )
    )
) @root
