(architecture_definition
  (identifier) @name
  (name (identifier) @entity)
  (architecture_head) @declarations
  (concurrent_block) @statements
  (end_architecture)
) @architecture
