(association_or_range_list
    (association_element) @element
) @root

(association_list
    (association_element) @element
) @root
