(simple_expression
    (simple_expression) @left
    (adding_operator)   @operator
    (simple_expression) @right
) @root
