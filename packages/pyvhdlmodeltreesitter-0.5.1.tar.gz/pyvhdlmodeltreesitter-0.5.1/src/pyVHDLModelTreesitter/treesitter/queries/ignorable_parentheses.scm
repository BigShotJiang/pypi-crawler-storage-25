(simple_expression
    (parenthesis_expression
        (element_association_list
            (element_association
                (conditional_expression
                    (simple_expression)     @inner
                )
            )   @element
        )
    )
)   @root
