(entity_declaration
    (identifier) @name
    (entity_head
        (generic_clause)? @generics
        (port_clause)? @ports
    )
    (end_entity)
) @root
