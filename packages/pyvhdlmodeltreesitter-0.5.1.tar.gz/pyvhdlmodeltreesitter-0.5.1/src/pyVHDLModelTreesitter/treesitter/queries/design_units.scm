(design_file
    (design_unit) @design_unit
) @document
