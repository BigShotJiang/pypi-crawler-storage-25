(subtype_indication
    type: (name
        (identifier) @type_name
        (parenthesis_group
            (association_or_range_list
                (simple_range
                    (simple_expression) @range_left
                    (simple_expression) @range_right
                ) @range
            )
        ) @constraint
    )
) @root

(subtype_indication
    type: (name
        (library_type) @type_name
        (parenthesis_group
            (association_or_range_list
                (simple_range
                    (simple_expression) @range_left
                    (simple_expression) @range_right
                ) @range
            )
        ) @constraint
    )
) @root
