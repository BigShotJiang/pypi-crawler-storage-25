; without `signal` before the name
(interface_declaration) @interface
; with signal before the name
(interface_signal_declaration) @interface
