; custom libraries use this
(identifier) @library
; ieee, std, and work all use this
; TODO: this is probably actually a bug in `tree-sitter-vhdl`:
;       https://github.com/VHDL/pyVHDLModel/issues/106#issuecomment-4281822474
(library_namespace) @library
