(package_definition
    (identifier) @name
    (package_definition_body) @content
    (end_package_body)
) @root
