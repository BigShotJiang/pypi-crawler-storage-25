"""Submodule mirroring modified aspects of pyVHDLModel.Object."""

from __future__ import annotations

__all__ = [
    "Constant",
]

from typing import TYPE_CHECKING, Self

from pyVHDLModel.Object import Constant as VHDLModel_Constant

if TYPE_CHECKING:
    import tree_sitter

from pyVHDLModelTreesitter._parse import parse_conditional_expression
from pyVHDLModelTreesitter.Symbol import parse_subtype_indication
from pyVHDLModelTreesitter.treesitter import (
    TreesitterNodeMixin,
    get_node,
    get_node_text,
    get_nodes,
)
from pyVHDLModelTreesitter.treesitter.query import ConstantDeclaration


class Constant(TreesitterNodeMixin, VHDLModel_Constant):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
    ) -> list[Self]:
        """Create one or more Constant from a treesitter node."""
        captures = ConstantDeclaration.capture(node)
        name_nodes = get_nodes(node, captures, "name")
        identitfiers = [get_node_text(name_node) for name_node in name_nodes]
        subtype_node = get_node(node, captures, "type")
        subtype = parse_subtype_indication(subtype_node)
        if subtype is None:
            return []
        value_node = get_node(node, captures, "value")
        value = parse_conditional_expression(value_node)
        if value is None:
            return []
        return [
            cls(
                identitfiers,
                subtype,
                value,
                _treesitter_node=node,
            ),
        ]

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return (
            self._identifiers == other._identifiers
            and self._subtype == other._subtype
            and self._defaultExpression == other._defaultExpression
            and self._documentation == other._documentation
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._identifiers,
                self._subtype,
                self._defaultExpression,
                self._documentation,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_identifiers={self._identifiers!r}, "
            f"_subtype={self._subtype!r}, "
            f"_defaultExpression={self._defaultExpression!r}, "
            ")"
        )
