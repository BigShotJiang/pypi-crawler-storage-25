"""Submodule providing reusable parsing functions."""

# ruff: noqa: PLC0415

from __future__ import annotations

import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pyVHDLModel

from pyVHDLModelTreesitter._errors import (
    NodeExtraChildError,
    NodeTextIsInvalidError,
    NodeTypeIsInvalidError,
    NotImplementedWarning,
)
from pyVHDLModelTreesitter.Name import SimpleName
from pyVHDLModelTreesitter.Symbol import SimpleSubtypeSymbol
from pyVHDLModelTreesitter.treesitter import get_node, get_node_text, get_nodes
from pyVHDLModelTreesitter.treesitter.query import (
    AddingExpression as AddingExpressionQuery,
)
from pyVHDLModelTreesitter.treesitter.query import (
    AssociationElements,
    IgnorableParentheses,
)
from pyVHDLModelTreesitter.treesitter.query import (
    FunctionCall as FunctionCallQuery,
)
from pyVHDLModelTreesitter.treesitter.query import (
    MultiplyingExpression as MultiplyingExpressionQuery,
)
from pyVHDLModelTreesitter.treesitter.query import (
    TypeConversion as TypeConversionQuery,
)

if TYPE_CHECKING:
    from tree_sitter import Node


def parse_conditional_expression(
    node: Node,
) -> pyVHDLModel.Base.ExpressionUnion | None:
    """
    Parse a `conditional_expression` to a model object.

    Nodes that are not recognised issue a `NotImplementedWarning`.

    Raises
    ------
    NodeTypeIsInvalidError:
        If `node.type` is not `conditional_expression`.

    """
    if node.type != "conditional_expression":
        raise NodeTypeIsInvalidError(node, "Must be `conditional_expression`")
    if len(node.children) != 1:
        NotImplementedWarning.warn(
            "`conditional_expression`s are only supported with one child node",
            node,
        )
        return None
    node_first_child = node.children[0]
    if node_first_child.type != "simple_expression":
        NotImplementedWarning.warn_child_type(node_first_child)
        return None
    expression = parse_simple_expression(node_first_child)
    if expression is None:
        NotImplementedWarning.warn(
            "`conditional_expression`s only support 'simple_expression's as children",
            node_first_child,
        )
        return None
    return expression


def parse_simple_expression(  # noqa: C901, PLR0911, PLR0912, PLR0914, PLR0915
    node: Node,
) -> pyVHDLModel.Base.ExpressionUnion | None:
    """
    Parse a 'simple_expression' to a model object.

    Nodes that are not recognised issue a `NotImplementedWarning`.

    Raises
    ------
    NodeExtraChildError:
        If a `name` expression doesn't contain exactly one child.
    NodeTextIsInvalidError:
        If `node.text` for any examined node is incorrect.
    NodeTypeIsInvalidError:
        If a based literal has the wrong node structure.

    """
    captures = IgnorableParentheses.capture_first_root(node)
    if len(captures) != 0:
        element_nodes = captures.get("element", [])
        if len(element_nodes) == 1:
            inner_node = get_node(node, captures, "inner")
            inner = parse_simple_expression(inner_node)
            if inner is None:
                NotImplementedWarning.warn(
                    "Ignorable parentheses only support a 'simple_expression' "
                    "as its operand",
                    inner_node,
                )
                return None
            return inner
    captures = AddingExpressionQuery.capture_first_root(node)
    if len(captures) != 0:
        left_node = get_node(node, captures, "left")
        left = parse_simple_expression(left_node)
        if left is None:
            NotImplementedWarning.warn(
                "Adding expressions only support 'simple_expression's as operands",
                left_node,
            )
            return None
        operator_node = get_node(node, captures, "operator")
        operator_str = get_node_text(operator_node)
        if operator_str not in {"+", "-", "&"}:
            raise NodeTextIsInvalidError(
                operator_node,
                f"'{operator_str}' is not a valid adding operator",
            )
        right_node = get_node(node, captures, "right")
        right = parse_simple_expression(right_node)
        if right is None:
            NotImplementedWarning.warn(
                "Adding expressions only support 'simple_expression's as operands",
                right_node,
            )
            return None
        if operator_str == "+":
            from pyVHDLModelTreesitter.Expression import AdditionExpression

            return AdditionExpression(left, right)
        if operator_str == "-":
            from pyVHDLModelTreesitter.Expression import SubtractionExpression

            return SubtractionExpression(left, right)
        if operator_str == "&":
            from pyVHDLModelTreesitter.Expression import ConcatenationExpression

            return ConcatenationExpression(left, right)
    captures = MultiplyingExpressionQuery.capture_first_root(node)
    if len(captures) != 0:
        left_node = get_node(node, captures, "left")
        left = parse_simple_expression(left_node)
        if left is None:
            NotImplementedWarning.warn(
                "Multiplying expressions only support 'simple_expression's as operands",
                left_node,
            )
            return None
        operator_node = get_node(node, captures, "operator")
        operator_str = get_node_text(operator_node)
        if operator_str not in {"*", "/"}:
            NotImplementedWarning.warn(
                f"'{operator_str}' is not a supported multiplying operator",
                operator_node,
            )
            return None
        right_node = get_node(node, captures, "right")
        right = parse_simple_expression(right_node)
        if right is None:
            NotImplementedWarning.warn(
                "Multiplying expressions only support 'simple_expression's as operands",
                right_node,
            )
            return None
        if operator_str == "*":
            from pyVHDLModelTreesitter.Expression import MultiplyExpression

            return MultiplyExpression(left, right)
        if operator_str == "/":
            from pyVHDLModelTreesitter.Expression import DivisionExpression

            return DivisionExpression(left, right)
    captures = FunctionCallQuery.capture_first_root(node)
    if len(captures) != 0:
        function_node = get_node(node, captures, "function")
        function_str = get_node_text(function_node)
        if "." in function_str:
            NotImplementedWarning.warn(
                "Function call only supports 'SimpleName's as the 'name'",
                function_node,
            )
            return None
        function = SimpleName(function_str)
        arguments_node = get_node(node, captures, "arguments")
        arguments_captures = AssociationElements.capture_first_root(arguments_node)
        if len(arguments_captures) == 0:
            NotImplementedWarning.warn(
                "Function call doesn't support zero arguments",
                function_node,
            )
            return None
        element_nodes = get_nodes(arguments_node, arguments_captures, "element")
        arguments = []
        from pyVHDLModelTreesitter.Association import AssociationItem

        for element_node in element_nodes:
            arguments.extend(AssociationItem.from_treesitter_node(element_node))
        from pyVHDLModelTreesitter.Expression import FunctionCall

        return FunctionCall(function, arguments)
    captures = TypeConversionQuery.capture_first_root(node)
    if len(captures) != 0:
        type_mark_node = get_node(node, captures, "type")
        type_mark_str = get_node_text(type_mark_node)
        if "." in type_mark_str:
            NotImplementedWarning.warn(
                "Type conversions only support 'SimpleSubtypeSymbols's of "
                "'SimpleName's as the 'type_mark'",
                type_mark_node,
            )
            return None
        type_mark = SimpleSubtypeSymbol(SimpleName(type_mark_str))
        expression_node = get_node(node, captures, "expression")
        expression = parse_simple_expression(expression_node)
        if expression is None:
            NotImplementedWarning.warn(
                "Type conversions only support a 'simple_expression' as the operand",
                expression_node,
            )
            return None
        from pyVHDLModelTreesitter.Expression import TypeConversion

        return TypeConversion(type_mark, expression)
    if node.child_count == 1:
        expression_child_node = node.children[0]
        # TODO: support more simple expressions
        if expression_child_node.type == "bit_string_literal":
            assert expression_child_node.child_count == 2  # noqa: PLR2004, S101
            base = expression_child_node.child(0)
            assert base is not None  # noqa: S101
            assert base.text is not None  # noqa: S101
            base_str = base.text.decode("utf-8").lower()
            base_parts = re.split(r"(?<=\d)(?=[a-zA-Z])", base_str)
            if len(base_parts) == 1:
                base_length = None
                base_type = base_parts[0]
            else:
                base_length = int(base_parts[0])
                base_type = base_parts[1]
            valid_bases = {"b", "o", "x", "ub", "uo", "ux", "sb", "so", "sx", "d"}
            if base_type not in valid_bases:
                raise NodeTextIsInvalidError(
                    base,
                    f"'{base_str}' is not a valid bit string literal base",
                )
            value = expression_child_node.child(1)
            assert value is not None  # noqa: S101
            assert value.text is not None  # noqa: S101
            value_str = value.text.decode("utf-8")[1:-1]
            if base_type.endswith("b"):
                from pyVHDLModelTreesitter.Expression import BinaryBitStringLiteral

                return BinaryBitStringLiteral(
                    value_str,
                    base_length,
                    base_str.startswith("s"),
                )
            if base_type.endswith("o"):
                from pyVHDLModelTreesitter.Expression import OctalBitStringLiteral

                return OctalBitStringLiteral(
                    value_str,
                    base_length,
                    base_str.startswith("s"),
                )
            if base_type.endswith("d"):
                from pyVHDLModelTreesitter.Expression import DecimalBitStringLiteral

                return DecimalBitStringLiteral(
                    value_str,
                    base_length,
                    base_str.startswith("s"),
                )
            if base_type.endswith("x"):
                from pyVHDLModelTreesitter.Expression import HexadecimalBitStringLiteral

                return HexadecimalBitStringLiteral(
                    value_str,
                    base_length,
                    base_str.startswith("s"),
                )
            raise NodeTextIsInvalidError(
                base,
                f"Bit string base '{base_str}' not recognised",
            )
        if expression_child_node.type == "decimal_float":
            from pyVHDLModelTreesitter.Expression import FloatingPointLiteral

            return FloatingPointLiteral(
                float(get_node_text(expression_child_node).replace("_", "")),
            )
        if expression_child_node.type == "decimal_integer":
            from pyVHDLModelTreesitter.Expression import IntegerLiteral

            return IntegerLiteral(
                int(float(get_node_text(expression_child_node).replace("_", ""))),
            )
        if expression_child_node.type == "based_literal":
            # TODO: support real based literals
            if len(expression_child_node.children) != 2:  # noqa: PLR2004
                # TODO: a third node might actually be impossible here?
                NotImplementedWarning.warn(
                    "Based literals only support exactly 2 child nodes",
                    expression_child_node,
                )
                return None
            base_node = expression_child_node.children[0]
            if base_node.type != "based_base":
                raise NodeTypeIsInvalidError(
                    base_node,
                    "First child of a based_literal must be a based_base",
                )
            base_text = get_node_text(base_node)
            base_int = int(base_text)
            literal_node = expression_child_node.children[1]
            literal_text = get_node_text(literal_node)
            if literal_node.type != "based_integer" or "." in literal_text:
                NotImplementedWarning.warn(
                    "Based literals only support based integers",
                    expression_child_node,
                )
                return None
            literal_text_split = literal_text.split("#")
            if len(literal_text_split) != 3:  # noqa: PLR2004
                raise NodeTypeIsInvalidError(
                    literal_node,
                    "Expected literal part to start and end with '#'",
                )
            literal_text = literal_text_split[1].replace("_", "")
            exponent_text = literal_text_split[2][1:]
            if exponent_text.startswith("-"):
                exponent = -int(exponent_text[1:])
            elif exponent_text.startswith("+"):
                exponent = int(exponent_text[1:])
            elif len(exponent_text) == 0:
                exponent = 0
            else:
                exponent = int(exponent_text)
            literal = int(literal_text, base=base_int)
            value = literal * (base_int**exponent)
            from pyVHDLModelTreesitter.Expression import IntegerLiteral

            return IntegerLiteral(value)
        if expression_child_node.type == "library_constant_boolean":
            from pyVHDLModelTreesitter.Expression import EnumerationLiteral

            return EnumerationLiteral(get_node_text(expression_child_node))
        if expression_child_node.type == "name":
            if expression_child_node.child_count != 1:
                raise NodeExtraChildError(expression_child_node, "all", 1)
            name_node = expression_child_node.children[0]
            if name_node.type == "library_constant_std_logic":
                from pyVHDLModelTreesitter.Expression import EnumerationLiteral

                return EnumerationLiteral(get_node_text(name_node)[1:-1])
            if name_node.type in {"identifier", "library_type"}:
                return SimpleName(get_node_text(name_node))
        if expression_child_node.type == "string_literal":
            from pyVHDLModelTreesitter.Expression import StringLiteral

            return StringLiteral(get_node_text(expression_child_node)[1:-1])
    NotImplementedWarning.warn(
        "Simple expression does not match any supported type",
        node,
    )
    return None
