"""Submodule mirroring modified aspects of pyVHDLModel.Name."""

from __future__ import annotations

__all__ = [
    "Name",
    "SelectedName",
    "SimpleName",
    "SlicedName",
    "selected_or_simple_name",
]

from typing import cast

from pyVHDLModel.Name import (
    Name as VHDLModel_Name,
)
from pyVHDLModel.Name import (
    SelectedName as VHDLModel_SelectedName,
)
from pyVHDLModel.Name import (
    SimpleName as VHDLModel_SimpleName,
)
from pyVHDLModel.Name import (
    SlicedName as VHDLModel_SlicedName,
)


class Name(VHDLModel_Name):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        # Required for LSP completions
        other = cast("Name", other)  # type: ignore[redundant-cast]
        return (
            self._identifier == other._identifier
            # Note: this is fully based on `_identifier` so is not needed
            # and self._normalizedIdentifier == other._normalizedIdentifier
            and self._prefix == other._prefix
            # Note: this is unused (?) and potentially recursive
            # and self._root == other._root
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._identifier,
                # self._normalizedIdentifier
                self._prefix,
                # self._root
            ),
        )


class SelectedName(VHDLModel_SelectedName, Name):  # noqa: D101
    pass


class SimpleName(VHDLModel_SimpleName, Name):  # noqa: D101
    pass


class SlicedName(VHDLModel_SlicedName, Name):  # noqa: D101
    pass


def selected_or_simple_name(name: str | list[str]) -> SelectedName | SimpleName:
    """Parse a string as either a Selected or Simple name."""
    if isinstance(name, str):
        name = name.split(".")
    ret: SimpleName | SelectedName = SimpleName(name[0])
    for part in name[1:]:
        ret = SelectedName(part, ret)
    return ret
