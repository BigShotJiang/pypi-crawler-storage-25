"""Submodule mirroring modified aspects of pyVHDLModel.Association."""

from __future__ import annotations

__all__ = [
    "AssociationItem",
    "GenericAssociationItem",
    "ParameterAssociationItem",
    "PortAssociationItem",
]

from typing import TYPE_CHECKING, Self

from pyVHDLModel.Association import AssociationItem as pyVHDLModel_AssociationItem
from pyVHDLModel.Association import (
    GenericAssociationItem as pyVHDLModel_GenericAssociationItem,
)
from pyVHDLModel.Association import (
    ParameterAssociationItem as pyVHDLModel_ParameterAssociationItem,
)
from pyVHDLModel.Association import (
    PortAssociationItem as pyVHDLModel_PortAssociationItem,
)

from pyVHDLModelTreesitter._parse import parse_conditional_expression
from pyVHDLModelTreesitter.Name import selected_or_simple_name
from pyVHDLModelTreesitter.Symbol import SimpleObjectOrFunctionCallSymbol
from pyVHDLModelTreesitter.treesitter import (
    TreesitterNodeMixin,
    get_node,
    get_node_text,
)
from pyVHDLModelTreesitter.treesitter.query import AssociationElement

if TYPE_CHECKING:
    import tree_sitter


class AssociationItemMixin(TreesitterNodeMixin, pyVHDLModel_AssociationItem):
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
    ) -> list[Self]:
        """Create one or more AssociationItem from a treesitter node."""
        captures = AssociationElement.capture_first_root(node)
        formal_node = get_node(node, captures, "formal", optional=True)
        formal = None
        if formal_node is not None:
            formal = SimpleObjectOrFunctionCallSymbol(
                selected_or_simple_name(get_node_text(formal_node)),
            )
        actual_node = get_node(node, captures, "actual")
        actual = parse_conditional_expression(actual_node)
        if actual is None:
            return []
        return [cls(actual, formal, _treesitter_node=node)]

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, self.__class__):
            return False
        return self._formal == other._formal and self._actual == other._actual

    def __hash__(self) -> int:
        return hash(
            (
                self._formal,
                self._actual,
            ),
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"_formal={self._formal!r}, "
            f"_actual={self._actual!r}, "
            ")"
        )


class AssociationItem(AssociationItemMixin):  # noqa: D101
    pass


class GenericAssociationItem(AssociationItemMixin, pyVHDLModel_GenericAssociationItem):  # noqa: D101
    pass


class ParameterAssociationItem(  # noqa: D101
    AssociationItemMixin,
    pyVHDLModel_ParameterAssociationItem,
):
    pass


class PortAssociationItem(AssociationItemMixin, pyVHDLModel_PortAssociationItem):  # noqa: D101
    pass
