"""Submodule mirroring modified aspects of pyVHDLModel.DesignUnit."""

from __future__ import annotations

__all__ = [
    "Architecture",
    "Entity",
    "LibraryClause",
    "Package",
    "PackageBody",
    "UseClause",
]

from typing import TYPE_CHECKING, Self

from pyVHDLModel.DesignUnit import Architecture as VHDLModel_Architecture
from pyVHDLModel.DesignUnit import Entity as VHDLModel_Entity
from pyVHDLModel.DesignUnit import LibraryClause as VHDLModel_LibraryClause
from pyVHDLModel.DesignUnit import Package as VHDLModel_Package
from pyVHDLModel.DesignUnit import PackageBody as VHDLModel_PackageBody
from pyVHDLModel.DesignUnit import UseClause as VHDLModel_UseClause

from pyVHDLModelTreesitter._errors import (
    NodeExtraChildError,
    NotImplementedWarning,
)
from pyVHDLModelTreesitter.Concurrent import EntityInstantiation
from pyVHDLModelTreesitter.Interface import (
    GenericConstantInterfaceItem,
    PortSignalInterfaceItem,
)
from pyVHDLModelTreesitter.Name import SimpleName, selected_or_simple_name
from pyVHDLModelTreesitter.Object import Constant
from pyVHDLModelTreesitter.Symbol import (
    EntitySymbol,
    LibraryReferenceSymbol,
    PackageReferenceSymbol,
    PackageSymbol,
)
from pyVHDLModelTreesitter.treesitter import (
    TreesitterNodeMixin,
    get_node,
    get_node_text,
    get_nodes,
    sort_into_text_order,
)
from pyVHDLModelTreesitter.treesitter.query import (
    ArchitectureDefinition,
    EntityDeclaration,
    InterfaceDeclarations,
    LibraryClauses,
    LibraryNamespaces,
    PackageDeclaration,
    PackageDefinition,
    SelectedNames,
    UseClauses,
)

if TYPE_CHECKING:
    from collections.abc import Iterable

    import tree_sitter


class LibraryClause(TreesitterNodeMixin, VHDLModel_LibraryClause):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
    ) -> list[Self]:
        """Create one or more LibraryClauses from a treesitter node."""
        captures = LibraryClauses.capture(node)
        library_clause_nodes = get_nodes(node, captures, "library_clause")
        ret = []
        for library_clause_node in library_clause_nodes:
            captures = LibraryNamespaces.capture(library_clause_node)
            library_namespace_nodes = get_nodes(node, captures, "library")
            symbols = [
                LibraryReferenceSymbol(
                    SimpleName(get_node_text(library_namespace_node)),
                )
                for library_namespace_node in library_namespace_nodes
            ]
            ret.append(cls(symbols, _treesitter_node=library_clause_node))
        return ret

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return self._symbols == other._symbols

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._symbols,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_symbols={self._symbols!r}, )"


class UseClause(TreesitterNodeMixin, VHDLModel_UseClause):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
    ) -> list[Self]:
        """Create one or more UseClauses from a treesitter node."""
        captures = UseClauses.capture(node)
        use_clause_nodes = get_nodes(node, captures, "use_clause")
        ret = []
        for use_clause_node in use_clause_nodes:
            captures = SelectedNames.capture(use_clause_node)
            selected_name_nodes = get_nodes(node, captures, "selected_name")
            symbols = []
            for selected_name_node in selected_name_nodes:
                selected_name = get_node_text(selected_name_node)
                # TODO: should use:
                #   PackageMemberReferenceSymbol
                #   AllPackageMembersReferenceSymbol
                symbols.append(
                    PackageReferenceSymbol(selected_or_simple_name(selected_name)),
                )
            ret.append(cls(symbols, _treesitter_node=use_clause_node))
        return ret

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return self._symbols == other._symbols

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._symbols,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_symbols={self._symbols!r}, )"


Declarations = Constant


def parse_declarations(node: tree_sitter.Node) -> list[Declarations]:
    ret = []
    for child in node.children:
        if child.type == "constant_declaration":
            ret.extend(Constant.from_treesitter_node(child))
        elif child.type == "is":
            continue
        else:
            NotImplementedWarning.warn_child_type(child)
    return ret


class Architecture(TreesitterNodeMixin, VHDLModel_Architecture):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
        *,
        context_items: Iterable[LibraryClause | UseClause] = [],
    ) -> Self:
        """Create an Architecture from a treesitter node."""
        captures = ArchitectureDefinition.capture(node)
        name_node = get_node(node, captures, "name")
        name_text = get_node_text(name_node)
        entity_node = get_node(node, captures, "entity")
        entity_text = get_node_text(entity_node)
        declarations_node = get_node(node, captures, "declarations")
        declared_items = parse_declarations(declarations_node)
        statements_node = get_node(node, captures, "statements")
        statements = []
        for statement_node in statements_node.children:
            if statement_node.type == "component_instantiation_statement":
                statements.extend(
                    EntityInstantiation.from_treesitter_node(statement_node),
                )
            elif statement_node.type == "begin":
                continue
            else:
                NotImplementedWarning.warn_child_type(statement_node)
        return cls(
            _treesitter_node=node,
            identifier=name_text,
            entity=EntitySymbol(selected_or_simple_name(entity_text)),
            contextItems=context_items,
            declaredItems=declared_items,
            statements=statements,
            documentation=None,  # TODO: implement
            allowBlackbox=None,  # TODO: implement
        )

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return (
            self._identifier == other._identifier
            and self._entity == other._entity
            and self._contextItems == other._contextItems
            and self._declaredItems == other._declaredItems
            and self._statements == other._statements
            and self._documentation == other._documentation
            and self._allowBlackbox == other._allowBlackbox
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._identifier,
                self._entity,
                self._contextItems,
                self._declaredItems,
                self._statements,
                self._documentation,
                self._allowBlackbox,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_identifier={self._identifier!r}, "
            f"_entity={self._entity!r}, "
            f"_contextItems={self._contextItems!r}, "
            f"_declaredItems={self._declaredItems}, "
            f"_statements={self._statements}, "
            f"_documentation={self._documentation}, "
            f"_allowBlackbox={self._allowBlackbox}, "
            ")"
        )


class Entity(TreesitterNodeMixin, VHDLModel_Entity):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
        *,
        context_items: Iterable[LibraryClause | UseClause] = [],
    ) -> Self:
        """
        Create an Entity from a treesitter node.

        Raises
        ------
        NodeExtraChildError:
            If there is more than one `generics` or `ports` capture.

        """
        captures = EntityDeclaration.capture(node)
        name_node = get_node(node, captures, "name")
        name_text = get_node_text(name_node)
        generics_nodes = captures.get("generics", [])
        if len(generics_nodes) > 1:
            raise NodeExtraChildError(node, "generic_clause", 1)
        ports_nodes = captures.get("ports", [])
        if len(ports_nodes) > 1:
            raise NodeExtraChildError(node, "port_clause", 1)
        generic_items = None
        if len(generics_nodes) == 1:
            generics_node = generics_nodes[0]
            captures = InterfaceDeclarations.capture(generics_node)
            generic_items = sort_into_text_order(
                (
                    generic
                    for generic in (
                        GenericConstantInterfaceItem.from_treesitter_node(
                            interface_node,
                        )
                        for interface_node in captures.get("interface", [])
                    )
                    if generic is not None
                ),
            )
        port_items = None
        if len(ports_nodes) == 1:
            ports_node = ports_nodes[0]
            captures = InterfaceDeclarations.capture(ports_node)
            port_items = sort_into_text_order(
                (
                    port
                    for port in (
                        PortSignalInterfaceItem.from_treesitter_node(interface_node)
                        for interface_node in captures.get("interface", [])
                    )
                    if port is not None
                ),
            )
        return cls(
            _treesitter_node=node,
            identifier=name_text,
            contextItems=context_items,
            genericItems=generic_items,
            portItems=port_items,
            declaredItems=None,  # TODO: implement
            statements=None,  # TODO: implement
            documentation=None,  # TODO: implement
            allowBlackbox=None,  # TODO: implement
        )

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return (
            self._identifier == other._identifier
            and self._contextItems == other._contextItems
            and self._genericItems == other._genericItems
            and self._portItems == other._portItems
            and self._declaredItems == other._declaredItems
            and self._statements == other._statements
            and self._documentation == other._documentation
            and self._allowBlackbox == other._allowBlackbox
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._identifier,
                self._contextItems,
                self._genericItems,
                self._portItems,
                self._declaredItems,
                self._statements,
                self._documentation,
                self._allowBlackbox,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_identifier={self._identifier!r}, "
            f"_contextItems={self._contextItems!r}, "
            f"_genericItems={self._genericItems!r}, "
            f"_portItems={self._portItems!r}, "
            f"_declaredItems={self._declaredItems}, "
            f"_statements={self._statements}, "
            f"_documentation={self._documentation}, "
            f"_allowBlackbox={self._allowBlackbox}, "
            ")"
        )


class Package(TreesitterNodeMixin, VHDLModel_Package):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
        *,
        context_items: Iterable[LibraryClause | UseClause] = [],
    ) -> Self:
        """Create a Package from a treesitter node."""
        captures = PackageDeclaration.capture(node)
        name_node = get_node(node, captures, "name")
        name_text = get_node_text(name_node)
        content_node = get_node(node, captures, "content")
        declared_items = parse_declarations(content_node)
        return cls(
            _treesitter_node=node,
            identifier=name_text,
            contextItems=context_items,
            genericItems=None,  # TODO: implement
            declaredItems=declared_items,
            documentation=None,  # TODO: implement
            allowBlackbox=None,  # TODO: implement
        )

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return (
            self._identifier == other._identifier
            and self._contextItems == other._contextItems
            and self._genericItems == other._genericItems
            and self._declaredItems == other._declaredItems
            and self._documentation == other._documentation
            and self._allowBlackbox == other._allowBlackbox
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._identifier,
                self._contextItems,
                self._genericItems,
                self._declaredItems,
                self._documentation,
                self._allowBlackbox,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_identifier={self._identifier!r}, "
            f"_contextItems={self._contextItems!r}, "
            f"_genericItems={self._genericItems!r}, "
            f"_declaredItems={self._declaredItems}, "
            f"_documentation={self._documentation}, "
            f"_allowBlackbox={self._allowBlackbox}, "
            ")"
        )


def parse_package_body_declarations(node: tree_sitter.Node) -> list:  # type: ignore[type-arg]
    """
    Get the declarations from a `package_definition_body`.

    Note: Currently, this function will always return the empty list.
    """
    for child in node.children:
        if child.type == "is":
            continue
        NotImplementedWarning.warn_child_type(child)
    return []


class PackageBody(TreesitterNodeMixin, VHDLModel_PackageBody):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
        *,
        context_items: Iterable[LibraryClause | UseClause] = [],
    ) -> Self:
        """Create a PackageBody from a treesitter node."""
        captures = PackageDefinition.capture(node)
        name_node = get_node(node, captures, "name")
        name_text = get_node_text(name_node)
        content_node = get_node(node, captures, "content")
        declared_items = parse_package_body_declarations(content_node)
        return cls(
            _treesitter_node=node,
            packageSymbol=PackageSymbol(selected_or_simple_name(name_text)),
            contextItems=context_items,
            declaredItems=declared_items,
            documentation=None,  # TODO: implement
        )

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return (
            self._package == other._package
            and self._contextItems == other._contextItems
            and self._declaredItems == other._declaredItems
            and self._documentation == other._documentation
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._package,
                self._contextItems,
                self._declaredItems,
                self._documentation,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_package={self._package!r}, "
            f"_contextItems={self._contextItems!r}, "
            f"_declaredItems={self._declaredItems}, "
            f"_documentation={self._documentation}, "
            ")"
        )
