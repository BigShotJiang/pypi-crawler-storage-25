"""Classes related to `Design`."""

from __future__ import annotations

from typing import cast

from pyVHDLModel import Design as VHDLModel_Design

from pyVHDLModelTreesitter._Library import Library


class Design(VHDLModel_Design):
    def GetLibrary(  # noqa: N802
        self,
        libraryName: str,  # noqa: N803
    ) -> Library:
        library = self.Libraries.get(libraryName)
        if library is not None:
            return cast("Library", library)
        library = Library(
            libraryName,
            allowBlackbox=self._allowBlackbox,
        )
        self.AddLibrary(library)
        return library

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, self.__class__):
            return False
        return (
            self._name == other._name
            and self._allowBlackbox == other._allowBlackbox
            and self._libraries == other._libraries
            and self._documents == other._documents
        )

    def __hash__(self) -> int:
        return hash(
            (
                self._name,
                self._allowBlackbox,
                self._libraries,
                self._documents,
            ),
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"_name={self._name}, "
            f"_allowBlackbox={self._allowBlackbox}, "
            f"_libraries={list(self._libraries.values())!r}, "
            f"_documents={self._documents!r}, "
            ")"
        )
