"""Classes related to `Library`."""

from __future__ import annotations

from pyVHDLModel import Library as VHDLModel_Library


class Library(VHDLModel_Library):
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, self.__class__):
            return False
        return (
            self._allowBlackbox == other._allowBlackbox
            and self._contexts == other._contexts
            and self._configurations == other._configurations
            and self._entities == other._entities
            and self._architectures == other._architectures
            and self._packages == other._packages
            and self._packageBodies == other._packageBodies
        )

    def __hash__(self) -> int:
        return hash(
            (
                self._allowBlackbox,
                self._contexts,
                self._configurations,
                self._entities,
                self._architectures,
                self._packages,
                self._packageBodies,
            ),
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"_allowBlackbox={self._allowBlackbox}, "
            f"_contexts={self._contexts}, "
            f"_configurations={self._configurations}, "
            f"_entities={list(self._entities.values())!r}, "
            f"_architectures={self._architectures}, "
            f"_packages={self._packages}, "
            f"_packageBodies={self._packageBodies}, "
            ")"
        )
