"""Submodule mirroring modified aspects of pyVHDLModel.Expression."""

from __future__ import annotations

__all__ = [
    "AddingExpression",
    "AdditionExpression",
    "BinaryBitStringLiteral",
    "BinaryExpression",
    "BitStringLiteral",
    "ConcatenationExpression",
    "DecimalBitStringLiteral",
    "DivisionExpression",
    "EnumerationLiteral",
    "FloatingPointLiteral",
    "FunctionCall",
    "HexadecimalBitStringLiteral",
    "IntegerLiteral",
    "MultiplyExpression",
    "MultiplyingExpression",
    "OctalBitStringLiteral",
    "StringLiteral",
    "SubtractionExpression",
    "TypeConversion",
]

from typing import TYPE_CHECKING, ClassVar, Generic, TypeVar

import pyVHDLModel

if TYPE_CHECKING:
    from pyVHDLModelTreesitter.Association import AssociationItem
    from pyVHDLModelTreesitter.Name import Name
    from pyVHDLModelTreesitter.Symbol import Symbol


class BinaryExpression(pyVHDLModel.Expression.BinaryExpression):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return (
            self._leftOperand == other._leftOperand
            and self._rightOperand == other._rightOperand
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._leftOperand,
                self._rightOperand,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_leftOperand={self._leftOperand!r}, "
            f"_rightOperand={self._rightOperand!r}, "
            ")"
        )


class AddingExpression(pyVHDLModel.Expression.AddingExpression, BinaryExpression):  # noqa: D101
    pass


class MultiplyingExpression(  # noqa: D101
    pyVHDLModel.Expression.MultiplyingExpression,
    BinaryExpression,
):
    # TODO: rem, mod, **
    pass


class AdditionExpression(pyVHDLModel.Expression.AdditionExpression, AddingExpression):  # noqa: D101
    pass


class BitStringLiteral(pyVHDLModel.Expression.BitStringLiteral):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return (
            self._value == other._value
            and self._length == other._length
            and self._signed == other._signed
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._value,
                self._length,
                self._signed,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_value={self._value!r}, "
            f"_length={self._length!r}, "
            f"_signed={self._signed!r}, "
            ")"
        )


class BinaryBitStringLiteral(  # noqa: D101
    pyVHDLModel.Expression.BinaryBitStringLiteral,
    BitStringLiteral,
):
    pass


class ConcatenationExpression(  # noqa: D101
    pyVHDLModel.Expression.ConcatenationExpression,
    AddingExpression,
):
    pass


class DecimalBitStringLiteral(  # noqa: D101
    pyVHDLModel.Expression.DecimalBitStringLiteral,
    BitStringLiteral,
):
    pass


class DivisionExpression(  # noqa: D101
    pyVHDLModel.Expression.DivisionExpression,
    MultiplyingExpression,
):
    pass


T = TypeVar("T", str, int, float)


class LiteralEqHashReprMixin(Generic[T]):
    """
    A mixin class that defines __eq__, __hash__, and __repr__ for literals.

    Note: Any class that uses this must either itself define `_value`, or have
    a parent class that defines it.
    """

    CASE_SENSITIVE: ClassVar[bool] = True

    __slots__ = []

    _value: T

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, self.__class__):
            return False
        return self._transformed_value == other._transformed_value

    def __hash__(self) -> int:
        return hash(
            (self._transformed_value,),
        )

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(_value={self._transformed_value!r}, )"

    @property
    def _transformed_value(self) -> T:
        if not isinstance(self._value, str):
            return self._value
        if self.CASE_SENSITIVE:
            return self._value
        return self._value.lower()  # ty: ignore[invalid-return-type]


class EnumerationLiteral(  # noqa: D101
    pyVHDLModel.Expression.EnumerationLiteral,
    LiteralEqHashReprMixin[str],
):
    CASE_SENSITIVE = False


class FloatingPointLiteral(  # noqa: D101
    pyVHDLModel.Expression.FloatingPointLiteral,
    LiteralEqHashReprMixin[float],
):
    pass


class FunctionCall(pyVHDLModel.Expression.FunctionCall):  # noqa: D101
    # TODO: Report that function calls are currently undefined
    _name: Name
    _arguments: list[AssociationItem]

    def __init__(  # noqa: D107
        self,
        name: Name,
        arguments: list[AssociationItem],
        parent: pyVHDLModel.Base.ModelEntity | None = None,
    ) -> None:
        super().__init__(parent)
        self._name = name
        self._arguments = arguments

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return self._name == other._name and self._arguments == other._arguments

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._name,
                self._arguments,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_name={self._name!r}, "
            f"_arguments={self._arguments!r}, "
            ")"
        )

    def __str__(self) -> str:  # noqa: D105
        return f"{self._name}({', '.join(str(a) for a in self._arguments)})"


class HexadecimalBitStringLiteral(  # noqa: D101
    pyVHDLModel.Expression.HexadecimalBitStringLiteral,
    BitStringLiteral,
):
    pass


class IntegerLiteral(  # noqa: D101
    pyVHDLModel.Expression.IntegerLiteral,
    LiteralEqHashReprMixin[int],
):
    pass


class MultiplyExpression(  # noqa: D101
    pyVHDLModel.Expression.MultiplyExpression,
    MultiplyingExpression,
):
    pass


class OctalBitStringLiteral(  # noqa: D101
    pyVHDLModel.Expression.OctalBitStringLiteral,
    BitStringLiteral,
):
    pass


class StringLiteral(pyVHDLModel.Expression.StringLiteral, LiteralEqHashReprMixin[str]):  # noqa: D101
    pass


class SubtractionExpression(  # noqa: D101
    pyVHDLModel.Expression.SubtractionExpression,
    AddingExpression,
):
    pass


class TypeConversion(pyVHDLModel.Expression.TypeConversion):  # noqa: D101
    # TODO: Report that type conversions don't currently know what type they convert
    _type_mark: Symbol

    _FORMAT = ("", "")  # parent class requires that _FORMAT be defined

    def __init__(  # noqa: D107
        self,
        type_mark: Symbol,
        operand: pyVHDLModel.Base.ExpressionUnion,
        parent: pyVHDLModel.Base.ModelEntity | None = None,
    ) -> None:
        super().__init__(operand, parent)  # type: ignore[arg-type]  # ty: ignore[invalid-argument-type]
        self._type_mark = type_mark

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return self._operand == other._operand and self._type_mark == other._type_mark

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._operand,
                self._type_mark,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_operand={self._operand!r}, "
            f"_type_mark={self._type_mark!r}, "
            ")"
        )

    def __str__(self) -> str:  # noqa: D105
        return f"{self._type_mark}({self._operand})"

    @property
    def TypeMark(self) -> Symbol:  # noqa: D102, N802
        return self._type_mark
