"""Submodule defining errors."""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node


class ParseError(RuntimeError):
    """Error raised when parsing fails for some reason."""

    def __init__(self, node: Node, message: str) -> None:
        node_text = node.text.decode() if node.text is not None else ""
        parent_text = (
            node.parent.text.decode()
            if node.parent is not None and node.parent.text is not None
            else ""
        )
        super().__init__(
            f"{message}\nNode text: '{node_text}'\nNode parse: '{node}'",
            f"Parent text: '{parent_text}'\nParent parse: '{node.parent}'\n",
        )
        self._node = node


class NodeTextIsNoneError(ParseError):
    """Error raised when a node that is expected to have a `text` field doesn't."""

    def __init__(self, node: Node) -> None:
        """Construct."""
        super().__init__(node, "`text` attribute not found")


class NodeTextIsInvalidError(ParseError):
    """Error raised when the text in a node is invalid."""

    def __init__(self, node: Node, reason: str) -> None:
        """Construct."""
        super().__init__(node, f"`text` field invalid: {reason}")


class NodeTypeIsInvalidError(ParseError):
    """Error raised when the type of a node is invalid."""

    def __init__(self, node: Node, reason: str) -> None:
        """Construct."""
        super().__init__(node, f"`type` field invalid: {reason}")


class NodeMissingChildError(ParseError):
    """Error raised when a node is missing an expected child."""

    def __init__(self, node: Node, child_type: str) -> None:
        """Construct."""
        super().__init__(node, f"No child with type '{child_type}'")


class NodeExtraChildError(ParseError):
    """Error raised when a node has too many of a specific child."""

    def __init__(self, node: Node, child_type: str, expected: int) -> None:
        """Construct."""
        super().__init__(
            node,
            f"Too many children with type '{child_type}' (expected '{expected}')",
        )


class NotImplementedWarning(Warning):
    """Warning raised when encountering VHDL structures that aren't implemented."""

    @classmethod
    def warn(cls, message: str, node: Node) -> None:
        node_str = str(node)
        node_text = node.text.decode("utf-8") if node.text is not None else "NONE"
        node_parent = node.parent if node.parent is not None else "NONE"
        node_parent_str = str(node_parent)
        node_parent_text = (
            node.parent.text.decode("utf-8")
            if node.parent is not None and node.parent.text is not None
            else "NONE"
        )
        length_limit = 50
        if len(node_str) > length_limit:
            node_str = f"{node_str[:length_limit]} ..."
        if len(node_text) > length_limit:
            node_text = f"{node_text[:length_limit]} ..."
        node_text = node_text.replace("\n", " ")
        if len(node_parent_str) > length_limit:
            node_parent_str = f"{node_parent_str[:length_limit]} ..."
        if len(node_parent_text) > length_limit:
            node_parent_text = f"{node_parent_text[:length_limit]} ..."
        node_parent_text = node_parent_text.replace("\n", " ")
        warnings.warn(
            "\n"
            f"  {message}\n"
            f"  Node Parse : {node_str}\n"
            f"  Node Text  : {node_text}\n"
            f"  Parent Node Parse : {node_parent_str}\n"
            f"  Parent Node Text  : {node_parent_text}\n",
            NotImplementedWarning,
            stacklevel=1,
        )

    @classmethod
    def warn_child_type(cls, node: Node) -> None:
        message = (
            f"Node of type '{node.type}' is not supported as a child of "
            f"'{node.parent.type if node.parent is not None else 'NONE'}'"
        )
        cls.warn(message, node)
