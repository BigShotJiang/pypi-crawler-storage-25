"""Classes that are at the root of the pyVHDLModel library."""

from __future__ import annotations

from pathlib import Path
from typing import Self

from pyVHDLModel import Document as VHDLModel_Document

from pyVHDLModelTreesitter._errors import NodeMissingChildError, NotImplementedWarning
from pyVHDLModelTreesitter.DesignUnit import (
    Architecture,
    Entity,
    LibraryClause,
    Package,
    PackageBody,
    UseClause,
)
from pyVHDLModelTreesitter.treesitter.query import PARSER, DesignUnits


class Document(VHDLModel_Document):
    @classmethod
    def from_file(cls, path: str | Path) -> Self:
        """
        Create a Document, and all ModelEntities it contains.

        Nodes that are not recognised issue a `NotImplementedWarning`.
        """
        if isinstance(path, str):
            path = Path(path)
        path = path.resolve()
        return cls.from_text(path.read_bytes(), path)

    @classmethod
    def from_text(  # noqa: C901, PLR0912  # TODO: refactor
        cls,
        text: str | bytes,
        path: str | Path,
    ) -> Self:
        """
        Create a Document, and all ModelEntities it contains.

        Nodes that are not recognised issue a `NotImplementedWarning`.

        Raises
        ------
        NodeMissingChildError:
            - There are no `design_unit` nodes.
            - Any `design_unit` node has no children.

        """
        if isinstance(text, str):
            text = text.encode()
        if isinstance(path, str):
            path = Path(path)
        path = path.resolve()
        document = cls(path)

        tree = PARSER.parse(text)
        node = tree.root_node

        captures = DesignUnits.capture(node)
        design_unit_captures = captures.get("design_unit")
        if design_unit_captures is None:
            raise NodeMissingChildError(node, "design_unit")
        for design_unit_capture in design_unit_captures:
            if len(design_unit_capture.children) == 0:
                raise NodeMissingChildError(node, "design_unit")
            design_unit_child = design_unit_capture.children[-1]
            context_children = design_unit_capture.children[:-1]
            context_items: list[LibraryClause | UseClause] = []
            for context_child in context_children:
                if context_child.type == "library_clause":
                    context_items.extend(
                        LibraryClause.from_treesitter_node(context_child),
                    )
                elif context_child.type == "use_clause":
                    context_items.extend(
                        UseClause.from_treesitter_node(context_child),
                    )
                else:
                    NotImplementedWarning.warn_child_type(context_child)
            if design_unit_child.type == "architecture_definition":
                architecture = Architecture.from_treesitter_node(
                    node,
                    context_items=context_items,
                )
                document._AddArchitecture(architecture)
            elif design_unit_child.type == "entity_declaration":
                entity = Entity.from_treesitter_node(node, context_items=context_items)
                document._AddEntity(entity)
            elif design_unit_child.type == "package_declaration":
                package = Package.from_treesitter_node(
                    node,
                    context_items=context_items,
                )
                document._AddPackage(package)
            elif design_unit_child.type == "package_definition":
                package_body = PackageBody.from_treesitter_node(
                    node,
                    context_items=context_items,
                )
                document._AddPackageBody(package_body)
            else:
                NotImplementedWarning.warn_child_type(design_unit_child)
        return document

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, self.__class__):
            return False
        return (
            self._path == other._path
            and self._contexts == other._contexts
            and self._configurations == other._configurations
            and self._entities == other._entities
            and self._architectures == other._architectures
            and self._packages == other._packages
            and self._packageBodies == other._packageBodies
            and self._verificationUnits == other._verificationUnits
            and self._verificationProperties == other._verificationProperties
            and self._verificationModes == other._verificationModes
        )

    def __hash__(self) -> int:
        return hash(
            (
                self._path,
                self._contexts,
                self._configurations,
                self._entities,
                self._architectures,
                self._packages,
                self._packageBodies,
                self._verificationUnits,
                self._verificationProperties,
                self._verificationModes,
            ),
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"_path={self._path}, "
            f"_contexts={self._contexts}, "
            f"_configurations={self._configurations}, "
            f"_entities={list(self._entities.values())!r}, "
            f"_architectures={self._architectures}, "
            f"_packages={self._packages}, "
            f"_packageBodies={self._packageBodies}, "
            f"_verificationUnits={self._verificationUnits}, "
            f"_verificationProperties={self._verificationProperties}, "
            f"_verificationModes={self._verificationModes}, "
            ")"
        )
