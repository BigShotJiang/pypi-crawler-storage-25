"""Submodule mirroring modified aspects of pyVHDLModel.Symbol."""

from __future__ import annotations

__all__ = [
    "ArchitectureSymbol",
    "ConstrainedArraySubtypeSymbol",
    "EntityInstantiationSymbol",
    "EntitySymbol",
    "LibraryReferenceSymbol",
    "PackageReferenceSymbol",
    "PackageSymbol",
    "SimpleObjectOrFunctionCallSymbol",
    "SimpleSubtypeSymbol",
    "Symbol",
]

from typing import TYPE_CHECKING

import pyVHDLModel

from pyVHDLModelTreesitter._errors import (
    NodeTypeIsInvalidError,
    NotImplementedWarning,
)
from pyVHDLModelTreesitter.Name import SimpleName, SlicedName
from pyVHDLModelTreesitter.treesitter import get_node, get_node_text
from pyVHDLModelTreesitter.treesitter.query import Constrained1DArray, SimpleSubtype

if TYPE_CHECKING:
    import tree_sitter


class Symbol(pyVHDLModel.Symbol.Symbol):  # noqa: D101
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return self._name == other._name

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (self._name,),
        )

    def __repr__(self) -> str:  # noqa: D105
        return f"{self.__class__.__name__}(_name={self._name}, )"


class ArchitectureSymbol(pyVHDLModel.Symbol.ArchitectureSymbol, Symbol):  # noqa: D101
    pass


class ConstrainedArraySubtypeSymbol(  # noqa: D101
    pyVHDLModel.Symbol.ConstrainedArraySubtypeSymbol,
    Symbol,
):
    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return self._name == other._name and self._constraints == other._constraints

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._name,
                self._constraints,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_name={self._name!r}, "
            f"_constraints={self._constraints!r}, "
            ")"
        )


class EntityInstantiationSymbol(pyVHDLModel.Symbol.EntityInstantiationSymbol, Symbol):  # noqa: D101
    pass


class EntitySymbol(pyVHDLModel.Symbol.EntitySymbol, Symbol):  # noqa: D101
    pass


class LibraryReferenceSymbol(pyVHDLModel.Symbol.LibraryReferenceSymbol, Symbol):  # noqa: D101
    pass


class PackageReferenceSymbol(pyVHDLModel.Symbol.PackageReferenceSymbol, Symbol):  # noqa: D101
    pass


class PackageSymbol(pyVHDLModel.Symbol.PackageSymbol, Symbol):  # noqa: D101
    pass


class SimpleObjectOrFunctionCallSymbol(  # noqa: D101
    pyVHDLModel.Symbol.SimpleObjectOrFunctionCallSymbol,
    Symbol,
):
    pass


class SimpleSubtypeSymbol(pyVHDLModel.Symbol.SimpleSubtypeSymbol, Symbol):  # noqa: D101
    pass


def parse_subtype_indication(
    node: tree_sitter.Node,
) -> pyVHDLModel.Symbol.SubtypeSymbol | None:
    """
    Parse a node into a SubtypeSymbol.

    Supports:
        - 1 Dimensional constrained arrays
        - Simple subtypes

    Raises
    ------
    NodeTypeIsInvalidError:
        If `node.type` is not 'subtype_indication'.

    """
    # TODO: support more types
    if node.type != "subtype_indication":
        raise NodeTypeIsInvalidError(node, "expected 'subtype_indication'")
    captures = Constrained1DArray.capture_first_root(node)
    if len(captures) != 0:
        type_node = get_node(
            node,
            captures,
            "type_name",
        )
        type_name = SlicedName(get_node_text(type_node))
        range_node = get_node(node, captures, "range")
        # Import here to avoid circular dependency
        from pyVHDLModelTreesitter.Base import Range  # noqa: PLC0415

        range_obj = Range.from_treesitter_node(range_node)
        return ConstrainedArraySubtypeSymbol(type_name, [range_obj])
    captures = SimpleSubtype.capture_first_root(node)
    if len(captures) != 0:
        if len(node.children) != 1:
            NotImplementedWarning.warn(
                "Subtypes are assumed to just be a name and nothing else",
                node,
            )
            return None
        type_node = get_node(
            node,
            captures,
            "type_name",
        )
        return SimpleSubtypeSymbol(SimpleName(get_node_text(type_node)))
    NotImplementedWarning.warn("Unrecognised node type", node)
    return None
