"""Submodule mirroring modified aspects of pyVHDLModel.Concurrent."""

from __future__ import annotations

__all__ = [
    "EntityInstantiation",
]

from typing import TYPE_CHECKING, Self

from pyVHDLModel.Concurrent import (
    EntityInstantiation as pyVHDLModel_EntityInstantiation,
)

from pyVHDLModelTreesitter.Association import (
    GenericAssociationItem,
    PortAssociationItem,
)
from pyVHDLModelTreesitter.Name import selected_or_simple_name
from pyVHDLModelTreesitter.Symbol import ArchitectureSymbol, EntityInstantiationSymbol
from pyVHDLModelTreesitter.treesitter import (
    TreesitterNodeMixin,
    get_node,
    get_node_text,
    get_nodes,
)
from pyVHDLModelTreesitter.treesitter.query import ComponentInstantiationStatement

if TYPE_CHECKING:
    import tree_sitter


class EntityInstantiation(TreesitterNodeMixin, pyVHDLModel_EntityInstantiation):  # noqa: D101
    @classmethod
    def from_treesitter_node(
        cls,
        node: tree_sitter.Node,
    ) -> list[Self]:
        """Create one or more `EntityInstantiation`s from a treesitter node."""
        captures = ComponentInstantiationStatement.capture(node)
        label_node = get_node(node, captures, "label")
        label = get_node_text(label_node)
        entity_str = ""
        namespace_node = get_node(node, captures, "namespace", optional=True)
        if namespace_node is not None:
            entity_str = f"{get_node_text(namespace_node)}."
        entity_node = get_node(node, captures, "entity")
        entity_str += get_node_text(entity_node)
        entity_symbol = EntityInstantiationSymbol(
            selected_or_simple_name(entity_str),
        )
        architecture_node = get_node(node, captures, "architecture", optional=True)
        architecture_symbol = None
        if architecture_node is not None:
            architecture_symbol = ArchitectureSymbol(
                selected_or_simple_name(get_node_text(architecture_node)),
            )
        generic_associations = []
        for association_node in get_nodes(node, captures, "generics", optional=True):
            generic_associations.extend(
                GenericAssociationItem.from_treesitter_node(association_node),
            )
        port_associations = []
        for association_node in get_nodes(node, captures, "ports", optional=True):
            port_associations.extend(
                PortAssociationItem.from_treesitter_node(association_node),
            )
        return [
            cls(
                label=label,
                entitySymbol=entity_symbol,
                architectureSymbol=architecture_symbol,
                genericAssociations=generic_associations,
                portAssociations=port_associations,
                _treesitter_node=node,
            ),
        ]

    def __eq__(self, other: object) -> bool:  # noqa: D105
        if not isinstance(other, self.__class__):
            return False
        return (
            self._label == other._label
            and self._entity == other._entity
            and self._architecture == other._architecture
            and self._genericAssociations == other._genericAssociations
            and self._portAssociations == other._portAssociations
        )

    def __hash__(self) -> int:  # noqa: D105
        return hash(
            (
                self._label,
                self._entity,
                self._architecture,
                self._genericAssociations,
                self._portAssociations,
            ),
        )

    def __repr__(self) -> str:  # noqa: D105
        return (
            f"{self.__class__.__name__}("
            f"_label={self._label!r}, "
            f"_entity={self._entity!r}, "
            f"_architecture={self._architecture!r}, "
            f"_genericAssociations={self._genericAssociations!r}, "
            f"_portAssociations={self._portAssociations!r}, "
            ")"
        )
