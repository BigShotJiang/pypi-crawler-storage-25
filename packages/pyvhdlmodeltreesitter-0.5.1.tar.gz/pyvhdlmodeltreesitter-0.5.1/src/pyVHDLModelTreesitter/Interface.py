"""Submodule defining the various interfaces that are available."""

from __future__ import annotations

__all__ = [
    "GenericConstantInterfaceItem",
    "PortSignalInterfaceItem",
]

from typing import TYPE_CHECKING, Self

import pyVHDLModel
from pyVHDLModel.Interface import (
    GenericConstantInterfaceItem as pyVHDLModel_GenericConstantInterfaceItem,
)
from pyVHDLModel.Interface import (
    PortSignalInterfaceItem as pyVHDLModel_PortSignalInterfaceItem,
)

from pyVHDLModelTreesitter._errors import (
    NodeExtraChildError,
    NodeMissingChildError,
    NotImplementedWarning,
)
from pyVHDLModelTreesitter._parse import parse_simple_expression
from pyVHDLModelTreesitter.Base import parse_as_mode
from pyVHDLModelTreesitter.Symbol import parse_subtype_indication
from pyVHDLModelTreesitter.treesitter import (
    TreesitterNodeMixin,
    get_node,
    get_node_text,
)
from pyVHDLModelTreesitter.treesitter.query import InterfaceDeclaration

if TYPE_CHECKING:
    from tree_sitter import Node


class InterfaceItemEqHashReprMixin:
    """
    Common __eq__, __hash__, and __repr__ functions for PortSignal like classes.

    Users of this class (or a parent class of a user) must define the attributes:

        - _defaultExpression: pyVHDLModel.Base.ExpressionUnion | None
        - _identifiers: tuple[str]
        - _mode: pyVHDLModel.Base.Mode
        - _subtype: pyVHDLModel.Symbol.Symbol
    """

    # Provided for type checkers
    _defaultExpression: pyVHDLModel.Base.ExpressionUnion | None  # noqa: N815
    _identifiers: tuple[str]
    _mode: pyVHDLModel.Base.Mode
    # this is not strictly correct, but mypy is happy with it
    _subtype: pyVHDLModel.Symbol.Symbol

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, self.__class__):
            return False
        return (
            self._identifiers == other._identifiers
            and self._mode == other._mode
            and self._subtype == other._subtype
            and self._defaultExpression == other._defaultExpression
        )

    def __hash__(self) -> int:
        return hash(
            (
                self._identifiers,
                self._mode,
                self._subtype,
                self._defaultExpression,
            ),
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"_identifiers={self._identifiers}, "
            f"_mode={self._mode}, "
            f"_subtype={self._subtype!r}, "
            f"_defaultExpression={self._defaultExpression!r}, "
            ")"
        )


class GenericConstantInterfaceItem(  # noqa: D101
    TreesitterNodeMixin,
    pyVHDLModel_GenericConstantInterfaceItem,
    InterfaceItemEqHashReprMixin,
):
    @classmethod
    def from_treesitter_node(
        cls,
        node: Node,
    ) -> Self | None:
        """
        Create a GenericConstantInterfaceItem from a treesitter node.

        Raises
        ------
        NodeExtraChildError:
            If there is more than one `default`.

        """
        captures = InterfaceDeclaration.capture(node)
        name_node = get_node(node, captures, "name")
        type_node = get_node(node, captures, "type")
        default_nodes = captures.get("default")

        name_text = get_node_text(name_node)

        mode = pyVHDLModel.Base.Mode.In

        type_symbol = parse_subtype_indication(type_node)
        if type_symbol is None:
            return None

        default_expression: pyVHDLModel.Expression.BaseExpression | None = None
        if default_nodes is not None:
            if len(default_nodes) > 1:
                raise NodeExtraChildError(node, "default", 1)
            default_node = default_nodes[0]
            # TODO: support non simple expressions
            assert default_node.child_count == 1  # noqa: S101
            expression_node = default_node.children[0]
            default_expression = None
            if expression_node.type == "simple_expression":
                default_expression = parse_simple_expression(expression_node)
            if default_expression is None:
                NotImplementedWarning.warn_child_type(expression_node)
                return None

        return cls(
            _treesitter_node=node,
            # TODO: why is there a list of identifiers?
            identifiers=[name_text],
            mode=mode,
            subtype=type_symbol,
            defaultExpression=default_expression,
            documentation=None,
        )


class PortSignalInterfaceItem(  # noqa: D101
    TreesitterNodeMixin,
    pyVHDLModel_PortSignalInterfaceItem,
    InterfaceItemEqHashReprMixin,
):
    @classmethod
    def from_treesitter_node(
        cls,
        node: Node,
    ) -> Self | None:
        """
        Create a PortSignalInterfaceItem from a treesitter node.

        Raises
        ------
        NodeExtraChildError:
            If `default` is captured more than once.
        ValueError:
            If `mode` is not a valid mode.

        """
        captures = InterfaceDeclaration.capture(node)

        name_node = get_node(node, captures, "name")
        name_text = get_node_text(name_node)

        try:
            mode_node = get_node(node, captures, "mode")
            mode_text = get_node_text(mode_node)
        except NodeMissingChildError:
            mode_text = "in"

        type_node = get_node(node, captures, "type")
        type_symbol = parse_subtype_indication(type_node)
        if type_symbol is None:
            return None

        default_nodes = captures.get("default")
        default_expression: pyVHDLModel.Expression.BaseExpression | None = None
        if default_nodes is not None:
            if len(default_nodes) > 1:
                raise NodeExtraChildError(node, "default", 1)
            default_node = default_nodes[0]
            # TODO: support non simple expressions
            assert default_node.child_count == 1  # noqa: S101
            expression_node = default_node.children[0]
            default_expression = None
            if expression_node.type == "simple_expression":
                default_expression = parse_simple_expression(expression_node)
            if default_expression is None:
                NotImplementedWarning.warn_child_type(expression_node)
                return None

        mode = parse_as_mode(mode_text)
        if mode is None:
            message = f"'{mode_text}' is not a valid VHDL interface mode"
            raise ValueError(message)

        return cls(
            _treesitter_node=node,
            # TODO: why is there a list of identifiers?
            identifiers=[name_text],
            mode=mode,
            subtype=type_symbol,
            defaultExpression=default_expression,
            documentation=None,
        )
