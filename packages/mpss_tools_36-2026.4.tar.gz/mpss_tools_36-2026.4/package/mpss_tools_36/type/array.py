"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

from multiprocessing.shared_memory import SharedMemory as shared_memory_t
from typing import NamedTuple as named_tuple_t

import numpy as nmpy

array_t = nmpy.ndarray


class shared_t(named_tuple_t):
    name: str
    numpy: array_t
    handle: shared_memory_t
    is_original: bool

    def __str__(self) -> str:
        """"""
        return (
            f"{type(self).__name__}("
            f"name={self.name},"
            f"numpy={self.numpy.dtype}x{self.numpy.shape},"
            f"original={self.is_original})"
        )

    def __repr__(self) -> str:
        """"""
        return self.__str__()
