"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

import dataclasses as d
import functools as f
import time
import typing as h
from multiprocessing import Value as shared_value_t
from multiprocessing import current_process as CurrentProcess
from threading import Thread as thread_t

from extension_36.api.chronos import FormatedDuration
from extension_36.api.dataclass import NO_CHOICE
from extension_36.api.sequence import ShortRepresentation
from mpss_tools_36.constant.feedback import DONE, POLLING_PERIOD, TO_DO, UNKNOWN_VALUE
from mpss_tools_36.extension.multi_processing import InMainProcess
from mpss_tools_36.hint.feedback import send_feedback_h
from mpss_tools_36.hint.process import process_h

"""
Progress Bar Length (excluding boundaries)
----
"X"=DONE and "-"=TO_DO.

48 = 20_X_or_- (as in [:20])
   + 1_space
   + 2_percent (as in 2.0f)
   + 1_%
   + 1_space
   + 20_X_or_- (as in [-20:]).
"""
PROGRESS_BAR_LENGTH = 45
MESSAGE_TEMPLATE = "|{} {: >2.0f}% {}| +{} -{}:{} of {}"


@d.dataclass(slots=True, repr=False, eq=False)
class server_t:
    prefix: str = ""
    feedback_period: int | float = 3.0
    print_report: bool = False

    _message_template: str = d.field(init=False)
    _shared_completions: list[h.Any] = NO_CHOICE(list)
    _thread: thread_t | None = NO_CHOICE(None)

    def __post_init__(self) -> None:
        """"""
        assert InMainProcess()

        self._message_template = self.prefix + MESSAGE_TEMPLATE

    def NewFeedbackSendingFunction(self) -> send_feedback_h:
        """"""
        shared_completion = shared_value_t("f")
        self._shared_completions.append(shared_completion)

        return f.partial(_SendFeedback, shared_completion)

    def Start(self) -> None:
        """
        For sequential processing.
        """
        assert InMainProcess()
        assert self._thread is None

        self._thread = thread_t(
            target=self.RunUntilExhausted, args=((CurrentProcess(),),)
        )
        self._thread.start()

    def RunUntilExhausted(self, tasks: h.Sequence[process_h], /) -> None:
        """
        For parallel processing (when called directly).
        """
        start_time = reference = time.time()

        n_tasks = self._shared_completions.__len__()
        if n_tasks == 0:  # I.e., NewFeedbackSendingFunction has never been called.
            return

        assert n_tasks == tasks.__len__()

        # See below about format.
        half_bar = 20 * TO_DO
        message = self._message_template.format(
            half_bar,
            0.0,
            half_bar,
            "00",  # Elapsed time.
            UNKNOWN_VALUE,  # Remaining time.
            n_tasks,  # N active tasks.
            n_tasks,  # N tasks.
        )
        message_length = message.__len__()
        print(f"{message}\r", end="", flush=True)

        computation_times = n_tasks * [-1.0]
        while True:
            now = time.time()
            elapsed_time = now - start_time

            n_active_tasks = n_tasks
            total_completion = 0.0  # [0,n_tasks]-normalized.
            for t_idx, (task, shared_completion) in enumerate(
                zip(tasks, self._shared_completions, strict=True)
            ):
                if task.is_alive():
                    total_completion += shared_completion.value
                else:
                    if computation_times[t_idx] < 0.0:
                        computation_times[t_idx] = elapsed_time
                    total_completion += 1.0
                    n_active_tasks -= 1

            if (all_done := (n_active_tasks == 0)) or (total_completion == n_tasks):
                if not all_done:
                    # Some tasks have reported total completion and are "barely alive".
                    computation_times = tuple(
                        elapsed_time if _ < 0.0 else _ for _ in computation_times
                    )
                break

            if now - reference < self.feedback_period:
                time.sleep(POLLING_PERIOD)
                continue
            reference = now

            if total_completion > 0.0:
                total_completion /= n_tasks  # [0,1]-normalization.
                remaining_time = (elapsed_time / total_completion) - elapsed_time
                remaining_time = FormatedDuration(remaining_time)
            else:
                remaining_time = UNKNOWN_VALUE

            n_completed = int(round(PROGRESS_BAR_LENGTH * total_completion))
            bar = f"{n_completed * DONE}{(PROGRESS_BAR_LENGTH - n_completed) * TO_DO}"
            message = self._message_template.format(
                bar[:20],
                100.0 * total_completion,
                bar[-20:],
                FormatedDuration(elapsed_time),
                remaining_time,
                n_active_tasks,
                n_tasks,
            )
            message_length = max(message_length, message.__len__())
            print(f"{message: <{message_length}}\r", end="", flush=True)

        if self.print_report:
            elapsed_time = time.time() - start_time
            computation_times = ShortRepresentation(
                map(FormatedDuration, computation_times), "unique"
            )
            message = (
                f"{self.prefix}"
                f"Computation Time "
                f"of {n_tasks} tasks={FormatedDuration(elapsed_time)} : "
                f"{computation_times}"
            )
            print(f"{message: <{message_length}}", flush=True)
        else:
            space = " "
            print(f"{space: <{message_length}}\r", end="", flush=True)

    def Stop(self) -> None:
        """
        For sequential processing.
        Safe to call on an un-started server.
        """
        assert InMainProcess()

        if self._thread is not None:
            self._thread.join()
            self._thread = None

    def ReportTaskStarting(self, tasks: int | h.Sequence[process_h], /) -> None:
        """"""
        if isinstance(tasks, int):
            print(f"{self.prefix}Starting {tasks} tasks...", flush=True)
        else:
            pids = ShortRepresentation((_.pid for _ in tasks), "interval")
            print(f"{self.prefix}All tasks started: {pids}.", flush=True)


def _SendFeedback(shared_completion: h.Any, completion: float, /) -> None:
    """"""
    shared_completion.value = completion
