"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

import tempfile as te

from mpss_tools_36.extension.multi_processing import _MPSS_FOLDER, _Prefix

_MPSS_FOLDER.mkdir(exist_ok=True)  # tempfile.NamedTemporaryFile does not create it.
_ = te.NamedTemporaryFile(prefix=_Prefix(), dir=_MPSS_FOLDER, delete=False)
