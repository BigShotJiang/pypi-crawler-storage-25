"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

import os as o
import tempfile as te
import threading as tg
from pathlib import Path as path_t

_MPSS_FOLDER = path_t(te.gettempdir()) / "mpss-tools-36"


def InMainProcess() -> bool:
    """
    The process name is actually not a definitive marker for main process checking (for
    example, when using the "forkserver" process start method). Therefore, the
    following test is not valid:
        (m.current_process().name == MAIN_PROCESS_NAME) and (
            t.current_thread() is t.main_thread()
        )
    Unfortunately, there seems to be no standard, definitive, portable way to do better.
    An alternative could be: os.getpid() == os.getppid(). However, it does not work when
    the main script is launched from an IDE.
    """
    if _MPSS_FOLDER.is_dir():
        prefix = _Prefix()
        for path in _MPSS_FOLDER.glob("*"):
            if path.name.startswith(prefix):
                break
        else:
            return False
    # Else, assume this is the main process since mpss_tools_36.api.main_process_context
    # has not been imported.

    return tg.current_thread() is tg.main_thread()


def _Prefix() -> str:
    """"""
    return f"{o.getpid()}-"
