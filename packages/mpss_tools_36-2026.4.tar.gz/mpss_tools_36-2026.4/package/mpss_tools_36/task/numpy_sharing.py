"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

import typing as h
from multiprocessing.shared_memory import SharedMemory as shared_memory_t

import numpy as nmpy
from mpss_tools_36.type.array import shared_t

array_t = nmpy.ndarray
enumeration_order_h = h.Literal["C", "F"]

LENGTH_DTYPE = nmpy.uint64
HEADER_SIZE = 3


def NewSharedArray(
    array: array_t | tuple[array_t, ...],
    /,
    *,
    name: str | tuple[str, ...] | None = None,
) -> shared_t | tuple[shared_t, ...]:
    """
    Buffer:
        - dtype: 1 byte
        - order: 1 byte
        - dimension: 1 byte
        - shape: dimension * 8 bytes (nmpy.uint64)
        - array content
    When not needed anymore, call close then unlink on raw.
    """
    if isinstance(array, tuple):
        if name is None:
            name = array.__len__() * (None,)
        else:
            assert isinstance(name, tuple)
        return tuple(
            NewSharedArray(_, name=__) for _, __ in zip(array, name, strict=True)
        )

    assert array.ndim < 256  # Because it will be stored in a byte.

    shape = nmpy.array(array.shape, dtype=LENGTH_DTYPE)
    assert shape.shape == (array.ndim,)  # Just in case of API change.

    while True:
        try:
            raw = shared_memory_t(
                name=name, create=True, size=HEADER_SIZE + shape.nbytes + array.nbytes
            )
        except FileExistsError:
            name += chr(nmpy.random.randint(65, high=91))
        else:
            break

    enumeration_order: enumeration_order_h
    if array.flags["C_CONTIGUOUS"]:
        enumeration_order = "C"
    else:
        enumeration_order = "F"

    raw.buf[0] = ord(array.dtype.char)
    raw.buf[1] = ord(enumeration_order)
    raw.buf[2] = array.ndim

    shape_buffer_portion = nmpy.ndarray(
        (array.ndim,), dtype=LENGTH_DTYPE, buffer=raw.buf[HEADER_SIZE:]
    )
    shape_buffer_portion[...] = shape

    shaped = nmpy.ndarray(
        array.shape,
        dtype=array.dtype,
        order=enumeration_order,
        buffer=raw.buf[(HEADER_SIZE + shape.nbytes) :],
    )
    shaped[...] = array

    return shared_t(name=raw.name, numpy=shaped, handle=raw, is_original=True)


def AdditionalSharedCopy(
    name: str | tuple[str, ...], /
) -> shared_t | tuple[shared_t, ...]:
    """
    When not needed anymore, call close on raw.
    """
    if isinstance(name, tuple):
        return tuple(AdditionalSharedCopy(_) for _ in name)

    raw = shared_memory_t(name)

    dtype_code = chr(raw.buf[0])
    enumeration_order: enumeration_order_h = chr(raw.buf[1])
    dimension = raw.buf[2]
    shape = nmpy.ndarray((dimension,), dtype=LENGTH_DTYPE, buffer=raw.buf[HEADER_SIZE:])

    array = nmpy.ndarray(
        shape,
        dtype=dtype_code,
        order=enumeration_order,
        buffer=raw.buf[(HEADER_SIZE + shape.nbytes) :],
    )

    return shared_t(name=name, numpy=array, handle=raw, is_original=False)


def DisposeSharedArray(
    shared: shared_t
    | shared_memory_t
    | tuple[shared_t, ...]
    | tuple[shared_memory_t, ...],
    /,
    *,
    is_original: bool | tuple[bool, ...] | None = None,
) -> None:
    """"""
    # /!\\ Test below cannot be isinstance(shared, tuple) because shared_t is a tuple.
    if not (isinstance(shared, shared_t) or isinstance(shared, shared_memory_t)):
        if (is_original is None) or isinstance(is_original, bool):
            is_original = shared.__len__() * (is_original,)
        for shared_, is_original_ in zip(shared, is_original, strict=True):
            DisposeSharedArray(shared_, is_original=is_original_)
        return

    if isinstance(shared, shared_memory_t):
        raw = shared
        assert isinstance(is_original, bool)
    else:
        raw = shared.handle
        is_original = shared.is_original

    raw.close()
    if is_original:
        raw.unlink()
