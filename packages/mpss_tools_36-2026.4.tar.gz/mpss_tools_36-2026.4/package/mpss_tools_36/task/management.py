"""
SEE COPYRIGHT, LICENCE, and DOCUMENTATION NOTICES: files
README-COPYRIGHT-utf8.txt, README-LICENCE-utf8.txt, and README-DOCUMENTATION-utf8.txt
at project source root.
"""

import time
import typing as h
from multiprocessing import Process as process_t
from multiprocessing import get_all_start_methods, get_start_method, set_start_method

from mpss_tools_36.extension.multi_processing import InMainProcess
from mpss_tools_36.type.server.feedback import server_t


def SetStartMethod(name: str, /) -> bool:
    """"""
    assert InMainProcess()
    assert name in ("fork", "forkserver", "spawn"), name

    if name not in get_all_start_methods():
        return False

    if get_start_method() != name:
        set_start_method(name, force=True)

    return True


def StartAndTrackTasks(
    tasks: h.Sequence[process_t],
    /,
    *,
    should_return_elapsed_time: bool = False,
    prefix: str = "",
    feedback_server: server_t | None = None,
) -> float | None:
    """"""
    assert InMainProcess()

    feedback_server_exists = feedback_server is not None

    if feedback_server_exists:
        feedback_server.ReportTaskStarting(tasks.__len__())
        prefix = feedback_server.prefix

    if should_return_elapsed_time:
        reference = time.time()
    else:
        reference = None

    for task in tasks:
        task.start()

    if feedback_server_exists:
        feedback_server.ReportTaskStarting(tasks)
        feedback_server.RunUntilExhausted(tasks)

    for task_id, task in enumerate(tasks, start=1):
        if task.exitcode is None:
            task.join()
        if task.exitcode != 0:
            print(
                f"{prefix}Task {task_id}/{task.name} "
                f"exited with error code {task.exitcode}."
            )

    if should_return_elapsed_time:
        return time.time() - reference
    return None
