#!/bin/bash
echo "This is an example script for mytest"
echo "Created by xb"
