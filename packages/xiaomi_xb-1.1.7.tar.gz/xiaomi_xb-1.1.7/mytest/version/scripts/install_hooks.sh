#!/bin/bash
# Git Hooks 安装脚本
# 将 version/hooks/ 复制到 .git/hooks/，并自动安装所需系统依赖

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
HOOKS_SOURCE_DIR="$PROJECT_ROOT/version/hooks"
HOOKS_TARGET_DIR="$PROJECT_ROOT/.git/hooks"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

if [ ! -d "$PROJECT_ROOT/.git" ]; then
    echo -e "${RED}❌ 不是Git仓库${NC}"
    exit 1
fi

if [ ! -d "$HOOKS_SOURCE_DIR" ]; then
    echo -e "${RED}❌ hooks源目录不存在: $HOOKS_SOURCE_DIR${NC}"
    exit 1
fi

install_if_missing() {
    local cmd="$1"
    local pkg="$2"
    if command -v "$cmd" >/dev/null 2>&1; then
        return 0
    fi
    echo -e "${YELLOW}📦 安装 $pkg ...${NC}"
    if command -v apt-get >/dev/null 2>&1; then
        sudo apt-get install -y "$pkg" >/dev/null 2>&1 && echo -e "${GREEN}✓${NC} $pkg 已安装" && return 0
    elif command -v yum >/dev/null 2>&1; then
        sudo yum install -y "$pkg" >/dev/null 2>&1 && echo -e "${GREEN}✓${NC} $pkg 已安装" && return 0
    fi
    echo -e "${YELLOW}⚠️  无法自动安装 $pkg，请手动安装${NC}"
    return 1
}

check_python_module() {
    local module="$1"
    local pkg="$2"
    if python3 -c "import $module" 2>/dev/null; then
        return 0
    fi
    echo -e "${YELLOW}📦 安装 $pkg (提供 $module 模块) ...${NC}"
    if command -v apt-get >/dev/null 2>&1; then
        sudo apt-get install -y "$pkg" >/dev/null 2>&1 && echo -e "${GREEN}✓${NC} $pkg 已安装" && return 0
    elif command -v yum >/dev/null 2>&1; then
        sudo yum install -y "$pkg" >/dev/null 2>&1 && echo -e "${GREEN}✓${NC} $pkg 已安装" && return 0
    fi
    echo -e "${YELLOW}⚠️  无法自动安装 $pkg，本地GUI版本管理器可能无法使用${NC}"
    return 1
}

echo -e "${CYAN}🔍 检查依赖...${NC}"
install_if_missing sshpass sshpass
check_python_module tkinter python3-tk

mkdir -p "$HOOKS_TARGET_DIR"

INSTALLED_COUNT=0
for hook_file in "$HOOKS_SOURCE_DIR"/*; do
    [ -f "$hook_file" ] || continue
    hook_name=$(basename "$hook_file")
    target_file="$HOOKS_TARGET_DIR/$hook_name"

    rm -f "$target_file"
    rm -f "$HOOKS_TARGET_DIR/${hook_name}.backup."* 2>/dev/null

    cp "$hook_file" "$target_file"
    chmod +x "$target_file"
    echo -e "${GREEN}✓${NC} 安装 hook: $hook_name"
    INSTALLED_COUNT=$((INSTALLED_COUNT + 1))
done

if [ $INSTALLED_COUNT -gt 0 ]; then
    echo -e "${GREEN}✅ 已安装 $INSTALLED_COUNT 个 Git hooks${NC}"
else
    echo -e "${YELLOW}⚠️  没有找到可安装的 hooks${NC}"
fi
