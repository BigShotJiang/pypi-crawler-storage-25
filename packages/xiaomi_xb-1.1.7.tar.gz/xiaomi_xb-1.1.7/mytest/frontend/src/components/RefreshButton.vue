<script setup>
import { ref } from 'vue'

// Props
const props = defineProps({
  loading: {
    type: Boolean,
    default: false
  },
  disabled: {
    type: Boolean,
    default: false
  }
})

// Emits
const emit = defineEmits(['refresh'])

// Local state
const isRefreshing = ref(false)

// Methods
const handleRefresh = async () => {
  if (props.disabled || isRefreshing.value) return
  
  isRefreshing.value = true
  emit('refresh')
  
  // Reset animation after 1 second
  setTimeout(() => {
    isRefreshing.value = false
  }, 1000)
}
</script>

<template>
  <button 
    class="refresh-button"
    :class="{ 
      'is-refreshing': isRefreshing || loading,
      'is-disabled': disabled 
    }"
    :disabled="disabled || isRefreshing || loading"
    @click="handleRefresh"
    aria-label="刷新"
  >
    <svg 
      class="refresh-icon" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>
    </svg>
    <span class="refresh-text">刷新</span>
  </button>
</template>

<style>
/* 容器样式（非 scoped，应用到使用该组件的父容器） */
#refresh-bar {
  padding: 20px;
  border-bottom: 1px solid var(--border);
  display: flex;
  justify-content: flex-end;
  align-items: center;
  background: var(--bg);
}

@media (max-width: 1024px) {
  #refresh-bar {
    padding: 16px;
    justify-content: center;
  }
}
</style>

<style scoped>
.refresh-button {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border-radius: 6px;
  border: 2px solid var(--accent-border);
  background: var(--accent-bg);
  color: var(--accent);
  font-family: var(--sans);
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  user-select: none;
}

.refresh-button:hover:not(.is-disabled) {
  background: var(--accent);
  color: var(--bg);
  border-color: var(--accent);
  box-shadow: var(--shadow);
  transform: translateY(-1px);
}

.refresh-button:active:not(.is-disabled) {
  transform: translateY(0);
  box-shadow: none;
}

.refresh-button:focus-visible {
  outline: 2px solid var(--accent);
  outline-offset: 2px;
}

.refresh-button.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.refresh-icon {
  width: 18px;
  height: 18px;
  transition: transform 0.6s ease;
}

.refresh-button.is-refreshing .refresh-icon {
  animation: spin 1s linear infinite;
}

.refresh-text {
  line-height: 1;
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

/* 响应式设计 */
@media (max-width: 1024px) {
  .refresh-button {
    padding: 8px 16px;
    font-size: 14px;
  }
  
  .refresh-icon {
    width: 16px;
    height: 16px;
  }
}
</style>
