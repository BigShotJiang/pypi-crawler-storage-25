import shutil
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from managers import path_manager, get_logger


router = APIRouter()
logger = get_logger(__name__)


class FileContentRequest(BaseModel):
    filename: str
    content: str


@router.get("/files/list")
async def list_config_files():
    """获取所有配置文件列表"""
    try:
        config_dir = path_manager.get_config_dir()

        if not config_dir.exists():
            return {"files": []}

        yaml_files = []
        for file_path in config_dir.glob("*.yaml"):
            yaml_files.append(
                {
                    "name": file_path.name,
                    "path": str(file_path),
                    "size": file_path.stat().st_size,
                    "modified": file_path.stat().st_mtime,
                }
            )

        return {
            "files": sorted(yaml_files, key=lambda x: x["name"]),
            "config_dir": str(config_dir),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"获取配置文件列表失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"获取文件列表失败: {str(e)}")


@router.get("/files/read/{filename}")
async def read_config_file(filename: str):
    """读取配置文件内容"""
    try:
        if not filename.endswith(".yaml"):
            raise HTTPException(status_code=400, detail="只支持 .yaml 文件")

        file_path = path_manager.get_config_path(filename)

        if not file_path.exists():
            raise HTTPException(status_code=404, detail=f"文件不存在: {filename}")

        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        is_valid, error_msg = path_manager.validate_yaml(content)

        return {
            "filename": filename,
            "content": content,
            "path": str(file_path),
            "is_valid": is_valid,
            "error": error_msg,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"读取文件失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"读取文件失败: {str(e)}")


@router.post("/files/write")
async def write_config_file(req: FileContentRequest):
    """写入配置文件内容"""
    try:
        if not req.filename.endswith(".yaml"):
            raise HTTPException(status_code=400, detail="只支持 .yaml 文件")

        is_valid, error_msg = path_manager.validate_yaml(req.content)
        if not is_valid:
            raise HTTPException(status_code=400, detail=f"YAML 格式错误: {error_msg}")

        file_path = path_manager.get_config_path(req.filename)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        backup_path = file_path.with_suffix(".yaml.bak")
        if file_path.exists():
            shutil.copy2(file_path, backup_path)
            logger.info(f"已备份配置文件: {backup_path}")

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(req.content)

        path_manager.reload_config(req.filename)

        logger.info(f"配置文件已更新: {req.filename}")

        return {
            "success": True,
            "message": f"文件 {req.filename} 保存成功",
            "path": str(file_path),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"写入文件失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"写入文件失败: {str(e)}")
