const { app, BrowserWindow, Menu } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const os = require('os');

app.setPath('userData', path.join(os.homedir(), '.config', 'mytest-electron'));
app.setPath('sessionData', path.join(os.homedir(), '.config', 'mytest-electron', 'Session'));

let win;
let backend;

app.whenReady().then(() => {
    Menu.setApplicationMenu(null);

    const backendPath = app.isPackaged
        ? path.join(process.resourcesPath, 'server')
        : path.join(__dirname, '..', 'dist', 'server');

    backend = spawn(backendPath);

    backend.stdout.on('data', (data) => {
        const output = data.toString();
        console.log('[Backend]', output);

        if (output.includes('应用启动完成')) {
            win = new BrowserWindow({
                width: 1200,
                height: 800
            });

            // F12 / Ctrl+Shift+I 切换 DevTools(因为上面 setApplicationMenu(null) 把菜单和默认快捷键都清掉了)
            win.webContents.on('before-input-event', (event, input) => {
                if (input.type !== 'keyDown' || !input.key) return;
                const isF12 = input.key === 'F12';
                const isCtrlShiftI = input.control && input.shift && input.key.toLowerCase() === 'i';
                if (isF12 || isCtrlShiftI) {
                    win.webContents.toggleDevTools();
                    event.preventDefault();
                }
            });

            win.loadURL('http://localhost:8000');
        }
    });
});

app.on('quit', () => {
    if (backend) backend.kill();
});
