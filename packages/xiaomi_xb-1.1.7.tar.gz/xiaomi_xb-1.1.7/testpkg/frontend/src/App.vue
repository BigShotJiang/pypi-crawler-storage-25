<script setup>
import { ref } from 'vue'
import HelloWorld from './components/HelloWorld.vue'
import RefreshButton from './components/RefreshButton.vue'
import GitVersionBadge from './components/GitVersionBadge.vue'
import FileManager from './components/FileManager.vue'

const fileManager = ref(null)

const handleRefresh = () => {
  console.log('刷新页面')
  window.location.reload()
}

const openSettings = () => {
  fileManager.value?.open()
}
</script>

<template>
  <div class="app">
    <FileManager ref="fileManager" />
    <header class="header">
      <div class="header-left">
        <h1>🎯 Testpkg</h1>
        <GitVersionBadge />
      </div>
      <div class="header-right">
        <RefreshButton @refresh="handleRefresh" />
        <button class="settings-btn" @click="openSettings" title="配置文件管理">
          ⚙️
        </button>
      </div>
    </header>
    <HelloWorld />
  </div>
</template>
