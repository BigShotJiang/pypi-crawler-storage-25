#!/bin/bash
echo "This is an example script for testpkg"
echo "Created by xb"
