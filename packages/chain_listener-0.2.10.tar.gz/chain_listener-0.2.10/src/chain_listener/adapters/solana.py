"""Solana blockchain adapter implementation."""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Iterable, List, Optional, Union

from chain_listener.adapters.base import BaseAdapter
from chain_listener.exceptions import BlockchainAdapterError
from chain_listener.models.events import ChainType, DecodedEvent, RawEvent

from solders.pubkey import Pubkey
from solders.rpc.responses import RpcConfirmedTransactionStatusWithSignature
from solders.transaction_status import EncodedConfirmedTransactionWithStatusMeta
from solders.signature import Signature
from solana.rpc.async_api import AsyncClient  # type: ignore
from solana.rpc.api import GetSignaturesForAddressResp


from anchorpy import Idl  # type: ignore
from anchorpy import EventParser  # type: ignore

class SolanaAdapter(BaseAdapter):
    """Adapter implementation for the Solana blockchain."""

    DEFAULT_CONFIG = {
        "commitment": "confirmed",
        "signature_batch_size": 200,
        "max_signature_batches": 10,
        "transaction_batch_size": 20,
    }

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.logger = logging.getLogger(__name__)

        self.commitment = config.get("commitment", self.DEFAULT_CONFIG["commitment"])
        self.signature_batch_size = int(
            config.get(
                "signature_batch_size", self.DEFAULT_CONFIG["signature_batch_size"]
            )
        )
        self.max_signature_batches = int(
            config.get(
                "max_signature_batches", self.DEFAULT_CONFIG["max_signature_batches"]
            )
        )
        self.transaction_batch_size = int(
            config.get(
                "transaction_batch_size",
                self.DEFAULT_CONFIG["transaction_batch_size"],
            )
        )

        if self.chain_type is None:
            self.chain_type = ChainType.SOLANA

        self._clients: Dict[str, AsyncClient] = {}
        self._connected = False
        self._event_parsers: Dict[str, Any] = {}
        self._prepare_event_parsers()

    async def connect(self) -> None:
        endpoint = self._connection_pool.get_next_connection()
        self._get_or_create_client(endpoint).get_transaction
        self._connected = True

    async def disconnect(self) -> None:
        for client in self._clients.values():
            try:
                close = getattr(client, "close", None)
                if close:
                    await close()
            except Exception as exc:
                self.logger.warning("Failed to close Solana client cleanly: %s", exc)
        self._clients.clear()
        self._connected = False

    def is_connected(self) -> bool:
        return self._connected and bool(self._clients)

    async def get_latest_block_number(self) -> int:
        response = await self._execute_with_client(
            lambda client: client.get_block_height(commitment=self.commitment)
        )
        return response.value

    async def get_logs(
        self,
        address: Optional[Union[str, List[str]]] = None,
        from_block: Optional[Union[int, str]] = None,
        to_block: Optional[Union[int, str]] = None,
        event_filters: Optional[Dict[str, List[str]]] = None,
    ) -> List[Dict[str, Any]]:
        if address is None:
            raise BlockchainAdapterError(
                "SolanaAdapter requires a program address",
                blockchain=self.name,
                network=self.network,
            )

        program_ids = [address] if isinstance(address, str) else list(address)
        from_slot = self._normalize_slot(from_block)
        to_slot = self._normalize_slot(to_block)

        logs: List[Dict[str, Any]] = []
        for program_id in program_ids:
            signatures = await self._fetch_signatures_for_program(
                program_id, from_slot, to_slot
            )
            events = await self._build_events_from_signatures(
                program_id, signatures, event_filters[program_id]
            )
            if event_filters[program_id]:
                events = [
                    event for event in events if event.get("event_name") in event_filters[program_id]
                ]
            logs.extend(events)

        return logs

    def decode_event(self, event: RawEvent) -> DecodedEvent:
        raw = event.raw_data or {}
        event_name = raw.get("event_name") or "SolanaEvent"
        parameters = raw.get("event_data") or raw
        timestamp = raw.get("timestamp") or event.timestamp or 0

        return DecodedEvent(
            chain_type=self.chain_type or ChainType.SOLANA,
            contract_address=event.contract_address,
            event_name=event_name,
            parameters=parameters,
            block_number=event.block_number,
            transaction_hash=event.transaction_hash,
            log_index=event.log_index,
            timestamp=int(timestamp),
        )

    def _get_or_create_client(self, endpoint: str) -> AsyncClient:
        if endpoint in self._clients:
            return self._clients[endpoint]

        self._ensure_solana_sdk()
        timeout = self.rpc_config.get("timeout", 30)
        headers: Dict[str, str] = {}
        rpc_headers = self.rpc_config.get("headers") or {}
        headers.update(rpc_headers)
        if hasattr(self._connection_pool, "get_headers"):
            headers.update(self._connection_pool.get_headers(endpoint))

        client = AsyncClient(
            endpoint,
            commitment=self.commitment,
            timeout=timeout,
            extra_headers=headers or None,  # type: ignore[arg-type]
        )
        self._clients[endpoint] = client
        return client

    async def _fetch_signatures_for_program(
        self,
        program_id: str,
        from_slot: Optional[int],
        to_slot: Optional[int],
    ) -> List[Dict[str, Any]]:
        self._ensure_solana_sdk()
        pubkey = Pubkey.from_string(program_id)  # type: ignore[arg-type]

        before: Optional[str] = None
        signatures: List[Dict[str, Any]] = []
        batch = 0
        reached_start = False

        while batch < self.max_signature_batches and not reached_start:
            response: GetSignaturesForAddressResp = await self._execute_with_client(
                lambda client: client.get_signatures_for_address(
                    pubkey,
                    before=before,
                    commitment=self.commitment,
                    limit=self.signature_batch_size,
                )
            )
            entries = response.value
            if not isinstance(entries, list) or not entries:
                break

            batch += 1
            for entry in entries:
                slot = entry.slot
                if slot is None:
                    continue
                if to_slot is not None and slot > to_slot:
                    continue
                if from_slot is not None and slot < from_slot:
                    reached_start = True
                    continue
                signatures.append(entry.signature)

            before = entries[-1].signature
            if not before:
                break

        return signatures

    async def _build_events_from_signatures(
        self,
        program_id: str,
        signatures: List[Signature],
        topic_filter: set,
    ) -> List[Dict[str, Any]]:
        events: List[Dict[str, Any]] = []
        if not signatures:
            return events

        for chunk in self._chunk(signatures, self.transaction_batch_size):
            for signature_info in chunk:
                if not signature_info:
                    continue

                response = await self._execute_with_client(
                    lambda client, sig=signature: client.get_transaction(
                        sig,
                        commitment=self.commitment,
                        encoding="jsonParsed",
                        max_supported_transaction_version=0,
                    )
                )
                transaction = self._unwrap_rpc_result(response)
                if not transaction:
                    continue

                events.extend(
                    self._build_events_from_transaction(
                        program_id, signature_info, transaction, topic_filter
                    )
                )

        return events

    def _build_events_from_transaction(
        self,
        program_id: str,
        signature_info: Dict[str, Any],
        transaction: EncodedConfirmedTransactionWithStatusMeta,
        topic_filter: set,
    ) -> List[Dict[str, Any]]:
        # solders EncodedConfirmedTransactionWithStatusMeta exposes attributes, not dict access
        slot = transaction.slot or signature_info.get("slot") or 0
        block_time = transaction.block_time or signature_info.get("blockTime") or 0
        meta = transaction.transaction.meta or {}
        log_messages = meta.log_messages if hasattr(meta, "log_messages") else (meta.get("logMessages") if isinstance(meta, dict) else [])
        block_hash = ""
        if transaction.transaction and hasattr(transaction.transaction, "message"):
            msg = transaction.transaction.message
            block_hash = getattr(msg, "recent_blockhash", "") or getattr(msg, "recentBlockhash", "")

        parser = self._event_parsers.get(self._normalize_program_id(program_id))
        parsed_events: List[Dict[str, Any]] = []

        if parser and log_messages:
            try:
                parse_method = getattr(parser, "parse_logs", None) or getattr(
                    parser, "parse", None
                )
                if parse_method:
                    for evt in parse_method(log_messages):
                        name = getattr(evt, "name", None) or evt.get("name")  # type: ignore[union-attr]
                        data = getattr(evt, "data", None) or evt.get("data")  # type: ignore[union-attr]
                        parsed_events.append({"name": name or "SolanaEvent", "data": data})
            except Exception as exc:
                self.logger.warning(
                    "Failed to parse Anchor events for %s: %s", program_id, exc
                )

        if not parsed_events:
            parsed_events.append(
                {
                    "name": "SolanaLog",
                    "data": {"log_messages": log_messages},
                }
            )

        events: List[Dict[str, Any]] = []
        for index, event_info in enumerate(parsed_events):
            event_name = event_info.get("name") or "SolanaEvent"
            if topic_filter and event_name not in topic_filter:
                continue

            events.append(
                {
                    "block_number": slot,
                    "block_hash": block_hash,
                    "transaction_hash": signature_info.get("signature", ""),
                    "log_index": index,
                    "address": program_id,
                    "timestamp": block_time,
                    "event_name": event_name,
                    "event_data": event_info.get("data") or {},
                    "raw": {
                        "signature": signature_info,
                        "transaction": transaction,
                        "log_messages": log_messages,
                    },
                }
            )

        return events

    def _prepare_event_parsers(self) -> None:
        for contract in self._contract_configs:
            program_id = contract.get("address")
            abi_path = contract.get("abi_path")
            if not program_id or not abi_path:
                continue

            idl = self._load_contract_abi(abi_path)
            if not idl:
                continue

            parser = self._create_event_parser(program_id, idl)
            if parser:
                self._event_parsers[self._normalize_program_id(program_id)] = parser

    def _create_event_parser(self, program_id: str, idl: Any) -> Optional[Any]:
        try:
            if hasattr(Idl, "from_json"):
                idl_obj = Idl.from_json(idl)  
            elif callable(Idl):
                idl_obj = Idl(idl)  
            else:
                idl_obj = idl

            return EventParser(Pubkey.from_string(program_id), idl_obj)  
        except Exception as exc:
            self.logger.warning(
                "Unable to build Anchor parser for %s: %s", program_id, exc
            )
            return None

    def _normalize_slot(self, block_reference: Optional[Union[int, str]]) -> Optional[int]:
        if block_reference is None:
            return None
        if isinstance(block_reference, int):
            return block_reference
        if isinstance(block_reference, str) and block_reference.isdigit():
            return int(block_reference)
        return None

    def _normalize_program_id(self, program_id: str) -> str:
        return program_id.strip()

    def _ensure_solana_sdk(self) -> None:
        pass

    @staticmethod
    def _unwrap_rpc_result(response: Any, default: Any = None) -> Any:
        if isinstance(response, dict):
            if "result" in response:
                result = response["result"]
                if isinstance(result, dict) and "value" in result:
                    return result["value"]
                return result
            if "value" in response:
                return response["value"]
        if getattr(response, "value"):
            return response.value
        return response if response is not None else default

    @staticmethod
    def _chunk(items: Iterable[Dict[str, Any]], size: int) -> Iterable[List[Dict[str, Any]]]:
        batch: List[Dict[str, Any]] = []
        for item in items:
            batch.append(item)
            if len(batch) >= size:
                yield batch
                batch = []
        if batch:
            yield batch
    
    async def get_block_by_number(self, block_number: int) -> Dict[str, Any]:
        try:
            response = await self._execute_with_client(
                lambda client: client.get_block(
                    block_number,
                    commitment=self.commitment,
                    encoding="jsonParsed",
                    max_supported_transaction_version=0,
                )
            )
            block = self._unwrap_rpc_result(response)
            if not block:
                raise BlockchainAdapterError(
                    f"Block {block_number} not found",
                    blockchain=self.name,
                    network=self.network,
                    block_number=block_number
                )
            return block
        except BlockchainAdapterError:
            raise
        except Exception as e:
            self.logger.error(f"Error fetching block {block_number}: {e}")
            raise BlockchainAdapterError(
                f"Error fetching block {block_number}: {e}",
                blockchain=self.name,
                network=self.network,
                block_number=block_number
            )
