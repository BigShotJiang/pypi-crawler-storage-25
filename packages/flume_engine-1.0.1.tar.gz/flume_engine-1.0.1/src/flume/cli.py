"""CLI entry point for Flume."""

import logging

import click
import sys
from pathlib import Path

from flume import __version__
from flume.config import load_config, DEFAULT_CONFIG_PATH, create_default_config
from flume.engine import Engine
from flume.actions import list_actions
from flume.matcher import matches
from flume.log import set_console_level, setup_file_logging


class MutuallyExclusiveOption(click.Option):
    """Click option that is mutually exclusive with another option."""

    def __init__(self, *args, **kwargs):
        self.mutually_exclusive = set(kwargs.pop("mutually_exclusive", []))
        super().__init__(*args, **kwargs)

    def handle_parse_result(self, ctx, opts, args):
        current = self.name in opts and opts[self.name]
        for name in self.mutually_exclusive:
            if name in opts and opts[name]:
                if current:
                    raise click.UsageError(
                        f"--{self.name.replace('_', '-')} and "
                        f"--{name.replace('_', '-')} are mutually exclusive."
                    )
        return super().handle_parse_result(ctx, opts, args)


@click.group()
@click.version_option(__version__, prog_name="flume")
@click.option(
    "--verbose", "-v",
    is_flag=True,
    default=False,
    cls=MutuallyExclusiveOption,
    mutually_exclusive=["quiet"],
    help="Enable debug-level output.",
)
@click.option(
    "--quiet", "-q",
    is_flag=True,
    default=False,
    cls=MutuallyExclusiveOption,
    mutually_exclusive=["verbose"],
    help="Suppress all output except errors.",
)
@click.option(
    "--log-file",
    type=click.Path(),
    default=None,
    help="Write logs to this file (enables rotation by default).",
)
@click.pass_context
def main(ctx, verbose, quiet, log_file):
    """Flume -- rule-based file operations engine."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet
    ctx.obj["log_file"] = log_file

    if verbose:
        set_console_level(logging.DEBUG)
    elif quiet:
        set_console_level(logging.ERROR)

    if log_file:
        level = "DEBUG" if verbose else "INFO"
        setup_file_logging(log_file, level=level)


def _parse_tags(value: str | None) -> set[str] | None:
    """Parse a comma-separated tag string into a set."""
    if not value:
        return None
    return {t.strip() for t in value.split(",") if t.strip()}


@main.command()
@click.option(
    "--config", "-c",
    type=click.Path(),
    default=None,
    help="Path to config file (default: ~/.config/flume/rules.yaml)",
)
@click.option("--dry-run", "-n", is_flag=True, help="Preview actions without executing.")
@click.option("--confirm", is_flag=True, help="Ask before each action.")
@click.option("--enable-tags", default=None, help="Comma-separated tags to force-enable.")
@click.option("--disable-tags", default=None, help="Comma-separated tags to force-disable.")
@click.option(
    "--report",
    type=click.Choice(["text", "json", "csv"], case_sensitive=False),
    default=None,
    help="Print a summary report in the given format (implies --dry-run).",
)
@click.option(
    "--report-file",
    type=click.Path(),
    default=None,
    help="Write the report to a file instead of stdout.",
)
@click.pass_context
def run(ctx, config, dry_run, confirm, enable_tags, disable_tags, report, report_file):
    """Run rules once against existing files."""
    config_path = Path(config) if config else DEFAULT_CONFIG_PATH
    cfg = load_config(config_path)
    if cfg is None:
        click.echo(f"No config found at {config_path}. Run 'flume init' first.", err=True)
        sys.exit(1)

    # --report implies dry-run
    if report:
        dry_run = True

    engine = Engine(
        cfg,
        dry_run=dry_run,
        confirm=confirm,
        enable_tags=_parse_tags(enable_tags),
        disable_tags=_parse_tags(disable_tags),
    )
    run_report = engine.run_once()

    if report:
        output = run_report.format(report)
        if report_file:
            Path(report_file).write_text(output)
            if not ctx.obj.get("quiet"):
                click.echo(f"Report written to {report_file}")
        else:
            click.echo(output)
    elif not ctx.obj.get("quiet"):
        click.echo(
            f"Done. Matched {run_report.total_matched} files, "
            f"executed {run_report.total_actions} actions."
        )


@main.command()
@click.option(
    "--config", "-c",
    type=click.Path(),
    default=None,
    help="Path to config file.",
)
@click.option("--dry-run", "-n", is_flag=True, help="Preview actions without executing.")
@click.option("--confirm", is_flag=True, help="Ask before each action.")
@click.option("--enable-tags", default=None, help="Comma-separated tags to force-enable.")
@click.option("--disable-tags", default=None, help="Comma-separated tags to force-disable.")
@click.pass_context
def watch(ctx, config, dry_run, confirm, enable_tags, disable_tags):
    """Watch directories and apply rules on changes."""
    config_path = Path(config) if config else DEFAULT_CONFIG_PATH
    cfg = load_config(config_path)
    if cfg is None:
        click.echo(f"No config found at {config_path}. Run 'flume init' first.", err=True)
        sys.exit(1)

    engine = Engine(
        cfg,
        dry_run=dry_run,
        confirm=confirm,
        enable_tags=_parse_tags(enable_tags),
        disable_tags=_parse_tags(disable_tags),
    )
    if not ctx.obj.get("quiet"):
        click.echo("Watching directories... (Ctrl+C to stop)")
    try:
        engine.watch()
    except KeyboardInterrupt:
        if not ctx.obj.get("quiet"):
            click.echo("\nStopped.")


@main.command()
@click.option(
    "--config", "-c",
    type=click.Path(),
    default=None,
    help="Where to create the config file.",
)
@click.pass_context
def init(ctx, config):
    """Create a default config file."""
    config_path = Path(config) if config else DEFAULT_CONFIG_PATH
    if config_path.exists():
        click.echo(f"Config already exists at {config_path}")
        sys.exit(1)

    create_default_config(config_path)
    if not ctx.obj.get("quiet"):
        click.echo(f"Created default config at {config_path}")
        click.echo("Edit it to add your rules, then run 'flume run' or 'flume watch'.")


@main.command()
@click.option(
    "--config", "-c",
    type=click.Path(),
    default=None,
    help="Path to config file.",
)
def status(config):
    """Show loaded rules and watched directories."""
    config_path = Path(config) if config else DEFAULT_CONFIG_PATH
    cfg = load_config(config_path)
    if cfg is None:
        click.echo(f"No config found at {config_path}. Run 'flume init' first.", err=True)
        sys.exit(1)

    errors = cfg.validate()
    click.echo(f"Config: {config_path}")
    click.echo(f"Rules:  {len(cfg.rules)}")
    click.echo()

    for rule in cfg.rules:
        state = "enabled" if rule.enabled else "DISABLED"
        watch_exists = Path(rule.watch).exists()
        dir_status = "ok" if watch_exists else "MISSING"

        click.echo(f"  [{state}] {rule.name}")
        click.echo(f"    watch:   {rule.watch} ({dir_status})")
        click.echo(f"    match:   {rule.match.pattern} (type={rule.match.type})")
        click.echo(f"    on:      {rule.on}")
        click.echo(f"    actions: {', '.join(a.kind for a in rule.actions)}")
        click.echo()

    if errors:
        click.echo("Warnings:")
        for e in errors:
            click.echo(f"  - {e}")


@main.command()
@click.option(
    "--config", "-c",
    type=click.Path(),
    default=None,
    help="Path to config file.",
)
def validate(config):
    """Validate the config file."""
    config_path = Path(config) if config else DEFAULT_CONFIG_PATH
    cfg = load_config(config_path)
    if cfg is None:
        click.echo(f"No config found at {config_path}.", err=True)
        sys.exit(1)

    errors = cfg.validate(known_actions=set(list_actions()))
    if errors:
        click.echo("Config errors:", err=True)
        for e in errors:
            click.echo(f"  - {e}", err=True)
        sys.exit(1)
    else:
        click.echo(f"Config OK -- {len(cfg.rules)} rule(s) loaded.")


@main.command("test")
@click.argument("path", type=click.Path(exists=True))
@click.option(
    "--config", "-c",
    type=click.Path(),
    default=None,
    help="Path to config file.",
)
@click.option("--enable-tags", default=None, help="Comma-separated tags to force-enable.")
@click.option("--disable-tags", default=None, help="Comma-separated tags to force-disable.")
@click.pass_context
def test_path(ctx, path, config, enable_tags, disable_tags):
    """Test which rules match a given file or directory.

    Shows all matching rules and the actions that would be applied,
    without executing anything. Useful for debugging rule configurations.
    """
    config_path = Path(config) if config else DEFAULT_CONFIG_PATH
    cfg = load_config(config_path)
    if cfg is None:
        click.echo(f"No config found at {config_path}. Run 'flume init' first.", err=True)
        sys.exit(1)

    target = Path(path).resolve()
    effective = cfg.effective_rules(
        enable_tags=_parse_tags(enable_tags),
        disable_tags=_parse_tags(disable_tags),
    )

    matched_rules = []
    for rule in effective:
        watch_dir = Path(rule.watch).resolve()
        # Only consider rules whose watch directory is a parent of the target
        try:
            target.relative_to(watch_dir)
        except ValueError:
            continue

        if matches(target, rule.match):
            matched_rules.append(rule)

    click.echo(f"Target: {target}")
    click.echo(f"Rules checked: {len(effective)}")
    click.echo()

    if not matched_rules:
        click.echo("No rules match this path.")
        sys.exit(0)

    click.echo(f"Matching rules ({len(matched_rules)}):")
    click.echo()
    for rule in matched_rules:
        click.echo(f"  {rule.name} (priority={rule.priority})")
        click.echo(f"    watch:   {rule.watch}")
        click.echo(f"    pattern: {rule.match.pattern}")
        click.echo(f"    on:      {rule.on}")
        actions_str = ", ".join(a.kind for a in rule.actions)
        click.echo(f"    actions: {actions_str}")
        if rule.tags:
            click.echo(f"    tags:    {', '.join(rule.tags)}")
        click.echo()


@main.command("actions")
def list_actions_cmd():
    """List all available actions."""
    actions = list_actions()
    click.echo(f"Available actions ({len(actions)}):")
    for name in actions:
        click.echo(f"  - {name}")


if __name__ == "__main__":
    main()
