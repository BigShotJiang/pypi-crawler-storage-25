"""File matching engine for Flume rules."""

from __future__ import annotations

import fnmatch
import os
import re
import time
from pathlib import Path

from flume.config import MatchConfig
from flume.log import get_logger

_logger = get_logger()

_SECONDS_PER_DAY = 86400.0


def _file_age_days(path: Path) -> float | None:
    """Return age of a file in days based on mtime, or None on error."""
    try:
        mtime = path.stat().st_mtime
        return (time.time() - mtime) / _SECONDS_PER_DAY
    except OSError:
        return None


_MAX_CONTENT_BYTES = 10 * 1024 * 1024  # 10 MB limit for content scanning


def _content_matches(path: Path, pattern: str) -> bool:
    """Return True if *pattern* (regex) matches any line in the file.

    Silently returns False for binary files, unreadable files, or files
    exceeding the size limit.
    """
    try:
        if path.stat().st_size > _MAX_CONTENT_BYTES:
            return False
    except OSError:
        return False

    try:
        compiled = re.compile(pattern)
    except re.error:
        return False

    try:
        with open(path, "r", errors="replace") as fh:
            for line in fh:
                if compiled.search(line):
                    return True
    except (OSError, UnicodeDecodeError):
        return False

    return False


def _stat_cached(path: Path, cache: dict) -> os.stat_result | None:
    """Return cached stat result for *path*, or None on error.

    The *cache* dict is expected to be local to the calling ``matches()``
    invocation so it lives only for the duration of one file check.
    """
    key = "stat"
    if key not in cache:
        try:
            cache[key] = path.stat()
        except OSError:
            cache[key] = None
    return cache[key]


def matches(path: Path, config: MatchConfig) -> bool:
    """Check if a path matches the given criteria."""
    # Per-call stat cache -- avoids redundant syscalls when multiple
    # criteria (size, age, content) all need stat info for the same file.
    _cache: dict = {}

    # Symlink handling -- checked before everything else
    if path.is_symlink():
        if config.symlinks == "skip":
            return False
        if config.symlinks == "reject":
            _logger.warning(f"Rejecting symlink: {path}")
            return False
        # "follow" -- fall through, resolve normally

    # Type check
    if config.type == "file" and not path.is_file():
        return False
    if config.type == "directory" and not path.is_dir():
        return False

    # Glob pattern
    if config.pattern and config.pattern != "*":
        if not fnmatch.fnmatch(path.name, config.pattern):
            return False

    # Exclude glob pattern
    if config.exclude:
        if fnmatch.fnmatch(path.name, config.exclude):
            return False

    # Regex
    if config.regex:
        if not re.search(config.regex, str(path)):
            return False

    # Exclude regex
    if config.exclude_regex:
        if re.search(config.exclude_regex, str(path)):
            return False

    # Size checks (files only)
    if path.is_file():
        if config.min_size is not None or config.max_size is not None:
            st = _stat_cached(path, _cache)
            if st is None:
                return False
            if config.min_size is not None and st.st_size < config.min_size:
                return False
            if config.max_size is not None and st.st_size > config.max_size:
                return False

    # Age checks
    if config.older_than is not None or config.newer_than is not None:
        st = _stat_cached(path, _cache)
        if st is None:
            return False
        age = (time.time() - st.st_mtime) / _SECONDS_PER_DAY
        if config.older_than is not None and age < config.older_than:
            return False
        if config.newer_than is not None and age > config.newer_than:
            return False

    # Content matching (grep inside files)
    if config.content is not None:
        if not path.is_file():
            return False
        if not _content_matches(path, config.content):
            return False

    return True


def scan_directory(directory: Path, config: MatchConfig, recursive: bool = False) -> list[Path]:
    """Scan a directory and return all paths matching the config.

    When *recursive* is True, subdirectories are walked as well.

    Permission errors and other OS-level failures on individual entries
    are logged and skipped rather than aborting the entire scan.
    """
    results = []
    dir_path = Path(directory)

    if not dir_path.exists():
        return results

    try:
        if recursive:
            entries = dir_path.rglob("*")
        else:
            entries = dir_path.iterdir()

        for item in entries:
            try:
                if matches(item, config):
                    results.append(item)
            except PermissionError:
                _logger.warning(f"Permission denied, skipping: {item}")
            except OSError as exc:
                _logger.warning(f"OS error scanning {item}: {exc}")
    except PermissionError:
        _logger.warning(f"Permission denied reading directory: {dir_path}")
    except OSError as exc:
        _logger.warning(f"OS error reading directory {dir_path}: {exc}")

    return sorted(results)
