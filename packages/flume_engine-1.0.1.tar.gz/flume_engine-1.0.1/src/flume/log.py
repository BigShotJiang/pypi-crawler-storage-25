"""Logging setup for Flume."""

from __future__ import annotations

import logging
import logging.handlers
import os
import sys

_logger: logging.Logger | None = None
_console_handler: logging.StreamHandler | None = None
_file_handler: logging.Handler | None = None

LOG_FORMAT = "%(asctime)s [%(levelname)s] %(message)s"
LOG_DATEFMT = "%Y-%m-%d %H:%M:%S"

# Defaults for log rotation
DEFAULT_MAX_BYTES = 5 * 1024 * 1024  # 5 MB
DEFAULT_BACKUP_COUNT = 3


def get_logger() -> logging.Logger:
    """Get or create the Flume logger."""
    global _logger, _console_handler
    if _logger is None:
        _logger = logging.getLogger("flume")
        _logger.setLevel(logging.DEBUG)

        # Console handler
        _console_handler = logging.StreamHandler(sys.stderr)
        _console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter(LOG_FORMAT, datefmt=LOG_DATEFMT)
        _console_handler.setFormatter(formatter)
        _logger.addHandler(_console_handler)

    return _logger


def set_console_level(level: int) -> None:
    """Set the console handler log level. Initializes logger if needed."""
    get_logger()
    if _console_handler is not None:
        _console_handler.setLevel(level)


def setup_file_logging(
    path: str,
    level: str = "INFO",
    max_bytes: int = DEFAULT_MAX_BYTES,
    backup_count: int = DEFAULT_BACKUP_COUNT,
) -> None:
    """Add a rotating file handler to the logger.

    Args:
        path: Log file path. Parent directories are created if needed.
        level: Log level name (DEBUG, INFO, WARNING, ERROR, CRITICAL).
        max_bytes: Maximum size in bytes before rotation. 0 disables rotation.
        backup_count: Number of rotated backup files to keep.
    """
    global _file_handler
    logger = get_logger()

    # Remove previous file handler if reconfiguring
    if _file_handler is not None:
        logger.removeHandler(_file_handler)
        _file_handler.close()
        _file_handler = None

    # Ensure parent directory exists
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)

    if max_bytes > 0:
        handler = logging.handlers.RotatingFileHandler(
            path,
            maxBytes=max_bytes,
            backupCount=backup_count,
        )
    else:
        handler = logging.FileHandler(path)

    handler.setLevel(getattr(logging, level.upper(), logging.INFO))
    formatter = logging.Formatter(LOG_FORMAT, datefmt=LOG_DATEFMT)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    _file_handler = handler
