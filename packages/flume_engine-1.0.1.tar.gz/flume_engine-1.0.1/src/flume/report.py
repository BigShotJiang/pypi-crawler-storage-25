"""Dry-run summary report generation for Flume."""

from __future__ import annotations

import csv
import io
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class RuleReport:
    """Stats for a single rule execution."""

    name: str
    matched: int = 0
    actions_run: int = 0
    files: list[str] = field(default_factory=list)


@dataclass
class RunReport:
    """Aggregate report for a full run."""

    rules: list[RuleReport] = field(default_factory=list)
    total_matched: int = 0
    total_actions: int = 0

    def add(self, rule_report: RuleReport) -> None:
        self.rules.append(rule_report)
        self.total_matched += rule_report.matched
        self.total_actions += rule_report.actions_run

    def format_text(self) -> str:
        """Format as a human-readable text report."""
        lines = []
        lines.append("Dry-Run Summary Report")
        lines.append("=" * 40)
        lines.append("")

        for rr in self.rules:
            lines.append(f"Rule: {rr.name}")
            lines.append(f"  Matched: {rr.matched} file(s)")
            lines.append(f"  Actions: {rr.actions_run}")
            if rr.files:
                lines.append("  Files:")
                for f in rr.files:
                    lines.append(f"    - {f}")
            lines.append("")

        lines.append("-" * 40)
        lines.append(f"Total matched: {self.total_matched}")
        lines.append(f"Total actions: {self.total_actions}")
        return "\n".join(lines)

    def format_json(self) -> str:
        """Format as JSON."""
        data = {
            "total_matched": self.total_matched,
            "total_actions": self.total_actions,
            "rules": [asdict(r) for r in self.rules],
        }
        return json.dumps(data, indent=2)

    def format_csv(self) -> str:
        """Format as CSV with one row per rule."""
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["rule", "matched", "actions", "files"])
        for rr in self.rules:
            writer.writerow([rr.name, rr.matched, rr.actions_run, ";".join(rr.files)])
        return buf.getvalue()

    def format(self, fmt: str = "text") -> str:
        """Format report in the requested format."""
        formatters = {
            "text": self.format_text,
            "json": self.format_json,
            "csv": self.format_csv,
        }
        formatter = formatters.get(fmt)
        if formatter is None:
            raise ValueError(f"Unknown report format: {fmt!r} (expected text, json, or csv)")
        return formatter()
