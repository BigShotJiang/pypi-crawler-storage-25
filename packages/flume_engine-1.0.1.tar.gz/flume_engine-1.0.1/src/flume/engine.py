"""Rule execution engine for Flume."""

from __future__ import annotations

import threading
import time
from pathlib import Path

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent

from flume.config import FlumeConfig, RuleConfig
from flume.matcher import matches, scan_directory
from flume.actions import get_action
from flume.log import get_logger, setup_file_logging
from flume.report import RunReport, RuleReport

logger = get_logger()


class Engine:
    """Executes rules against files."""

    def __init__(
        self,
        config: FlumeConfig,
        dry_run: bool = False,
        confirm: bool = False,
        enable_tags: set[str] | None = None,
        disable_tags: set[str] | None = None,
    ):
        self.config = config
        self.dry_run = dry_run
        self.confirm = confirm
        self.rules = config.effective_rules(
            enable_tags=enable_tags,
            disable_tags=disable_tags,
        )

        if config.log_file:
            setup_file_logging(
                config.log_file,
                level=config.log_level,
                max_bytes=config.log_max_bytes,
                backup_count=config.log_backup_count,
            )

    def run_once(self) -> RunReport:
        """Scan all watched directories and apply matching rules.

        Returns a RunReport with per-rule stats and matched file paths.
        """
        report = RunReport()

        for rule in self.rules:
            rule_report = RuleReport(name=rule.name)

            watch_dir = Path(rule.watch)
            if not watch_dir.exists():
                logger.warning(f"Watch directory missing: {rule.watch} (rule: {rule.name})")
                report.add(rule_report)
                continue

            matched_files = scan_directory(watch_dir, rule.match, recursive=rule.recursive)
            for path in matched_files:
                rule_report.matched += 1
                rule_report.files.append(str(path))
                actions_run = self._execute_actions(rule, path)
                rule_report.actions_run += actions_run

            report.add(rule_report)

        return report

    def _execute_actions(self, rule: RuleConfig, path: Path) -> int:
        """Run all actions for a rule on a path. Returns count of actions executed."""
        count = 0
        current_path = path

        for action_cfg in rule.actions:
            handler = get_action(action_cfg.kind)
            if handler is None:
                logger.error(f"Unknown action '{action_cfg.kind}' in rule '{rule.name}'")
                continue

            if self.confirm and not self._prompt_confirm(rule, action_cfg, current_path):
                logger.info(f"Skipped (user declined): {action_cfg.kind} on {current_path}")
                continue

            result = handler(current_path, action_cfg, self.dry_run)
            count += 1

            if result is None:
                # Action signalled halt (e.g. dedup skip, trash, failed
                # extraction). Stop executing further actions in this chain.
                logger.debug(
                    f"Action '{action_cfg.kind}' returned None -- halting chain "
                    f"for rule '{rule.name}' on {current_path}"
                )
                break

            # Chain: action returned a (possibly new) path for subsequent actions
            current_path = result

        return count

    def _prompt_confirm(self, rule: RuleConfig, action_cfg, path: Path) -> bool:
        """Ask the user to confirm an action. Returns True to proceed."""
        params_str = ""
        if action_cfg.params:
            params_str = " " + " ".join(f"{k}={v}" for k, v in action_cfg.params.items())

        prompt = f"  [{rule.name}] {action_cfg.kind}{params_str} on {path}\n  Apply? [y/n/a] "
        try:
            answer = input(prompt).strip().lower()
        except (EOFError, KeyboardInterrupt):
            return False

        if answer == "a":
            # "all" -- disable confirm for the rest of the session
            self.confirm = False
            return True

        return answer in ("y", "yes")

    def watch(self) -> None:
        """Start watching directories for changes."""
        observer = Observer()

        for rule in self.rules:
            watch_dir = Path(rule.watch)
            if not watch_dir.exists():
                logger.warning(f"Watch directory missing: {rule.watch} (rule: {rule.name})")
                continue

            handler = _RuleEventHandler(self, rule)
            observer.schedule(handler, str(watch_dir), recursive=rule.recursive)
            logger.info(f"Watching: {watch_dir} (rule: {rule.name}, recursive={rule.recursive})")

        observer.start()
        try:
            observer.join()
        except KeyboardInterrupt:
            observer.stop()
            observer.join()


class _RuleEventHandler(FileSystemEventHandler):
    """Watchdog event handler that applies a rule to new/modified files.

    Includes debounce logic: when multiple events fire for the same path
    within the rule's debounce window, only the last event triggers actions.
    This avoids double-triggers from editors that write-then-rename, or from
    the OS firing both created and modified events in quick succession.
    """

    def __init__(self, engine: Engine, rule: RuleConfig):
        super().__init__()
        self.engine = engine
        self.rule = rule
        self._lock = threading.Lock()
        self._timers: dict[str, threading.Timer] = {}

    def on_created(self, event: FileSystemEvent) -> None:
        if self.rule.on not in ("created", "any"):
            return
        self._handle(event)

    def on_modified(self, event: FileSystemEvent) -> None:
        if self.rule.on not in ("modified", "any"):
            return
        self._handle(event)

    def _handle(self, event: FileSystemEvent) -> None:
        path = Path(event.src_path)
        if not matches(path, self.rule.match):
            return

        debounce = self.rule.debounce
        key = str(path)

        if debounce <= 0:
            # No debounce -- fire immediately
            logger.info(f"Rule '{self.rule.name}' triggered by: {path}")
            self.engine._execute_actions(self.rule, path)
            return

        with self._lock:
            existing = self._timers.get(key)
            if existing is not None:
                existing.cancel()
                logger.debug(
                    f"Rule '{self.rule.name}' debounced repeat event for: {path}"
                )

            timer = threading.Timer(debounce, self._fire, args=(path, key))
            timer.daemon = True
            self._timers[key] = timer
            timer.start()

    def _fire(self, path: Path, key: str) -> None:
        """Execute actions after debounce window expires."""
        with self._lock:
            self._timers.pop(key, None)

        if not path.exists():
            logger.warning(
                f"Rule '{self.rule.name}': path vanished before debounce "
                f"timer fired, skipping: {path}"
            )
            return

        logger.info(f"Rule '{self.rule.name}' triggered by: {path}")
        try:
            self.engine._execute_actions(self.rule, path)
        except Exception:
            logger.exception(
                f"Rule '{self.rule.name}': unhandled error executing "
                f"actions on {path}"
            )
