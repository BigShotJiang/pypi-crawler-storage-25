"""Configuration loading and validation for Flume."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


DEFAULT_CONFIG_PATH = Path.home() / ".config" / "flume" / "rules.yaml"

_FALSE_STRINGS = frozenset({"false", "no", "off", "0", "none", ""})


def _coerce_bool(value: Any, default: bool = False) -> bool:
    """Coerce a value to bool, handling YAML quoted-string edge cases.

    Strings like ``"false"``, ``"no"``, ``"off"``, ``"0"``, and ``""``
    are treated as ``False``.  Everything else follows normal Python
    truthiness.
    """
    if isinstance(value, str):
        return value.strip().lower() not in _FALSE_STRINGS
    if value is None:
        return default
    return bool(value)

_SIZE_UNITS: dict[str, int] = {
    "b": 1,
    "k": 1024,
    "kb": 1024,
    "m": 1024 ** 2,
    "mb": 1024 ** 2,
    "g": 1024 ** 3,
    "gb": 1024 ** 3,
    "t": 1024 ** 4,
    "tb": 1024 ** 4,
}


def parse_size(value: int | float | str | None) -> int | None:
    """Parse a human-readable size string into bytes.

    Accepts plain integers (already bytes), floats, or strings like
    "100MB", "2.5GB", "500K", "1024".  Returns None for None input.
    Raises ValueError for unparseable strings.
    """
    if value is None:
        return None
    if isinstance(value, (int, float)):
        if value < 0:
            raise ValueError(f"Negative sizes are not valid: {value!r}")
        return int(value)

    text = str(value).strip()
    if not text:
        return None

    # Try plain number first
    try:
        num = int(text)
        if num < 0:
            raise ValueError(f"Negative sizes are not valid: {value!r}")
        return num
    except ValueError:
        pass

    # Split numeric prefix from unit suffix
    import re
    m = re.match(r"^([0-9]*\.?[0-9]+)\s*([a-zA-Z]+)$", text)
    if not m:
        raise ValueError(f"Cannot parse size: {value!r}")

    number = float(m.group(1))
    unit = m.group(2).lower()

    if unit not in _SIZE_UNITS:
        raise ValueError(
            f"Unknown size unit '{m.group(2)}' in {value!r}. "
            f"Valid units: B, K, KB, M, MB, G, GB, T, TB"
        )

    return int(number * _SIZE_UNITS[unit])

DEFAULT_CONFIG_TEMPLATE = """\
# Flume rules configuration
# See: https://github.com/mattWoolly/Flume

rules:
  # Example: organize downloads
  # - name: sort-downloads
  #   watch: ~/Downloads
  #   match:
  #     pattern: "*.pdf"
  #   actions:
  #     - move: ~/Documents/PDFs/

  # Example: auto-unzip
  # - name: unzip-archives
  #   watch: ~/Downloads
  #   match:
  #     pattern: "*.zip"
  #   actions:
  #     - unzip:
  #         dest: ~/Downloads/extracted/
  #     - trash-original: true

  # Example: run a script on new directories
  # - name: process-new-album
  #   watch: /mnt/storage/incoming/
  #   match:
  #     pattern: "*"
  #     type: directory
  #   on: created
  #   actions:
  #     - shell: ~/scripts/process_album.py "{path}"

  # Exclude patterns: skip files matching a glob or regex.
  # - name: sort-but-skip-temp
  #   watch: ~/Downloads
  #   match:
  #     pattern: "*.pdf"
  #     exclude: "*.tmp"
  #     exclude_regex: "_backup_\\d+"
  #   actions:
  #     - move: ~/Documents/PDFs/

  # Rule priority: lower number runs first (default 0).
  # Rules with the same priority run in config-file order.
  # - name: high-priority-rule
  #   priority: -10
  #   watch: ~/Downloads
  #   ...

  # Debounce: wait N seconds after the last event before acting.
  # Prevents double-triggers from editors or rapid filesystem events.
  # Default is 1.0. Set to 0 to disable.
  # - name: quick-sort
  #   debounce: 0.5
  #   watch: ~/Downloads
  #   ...

  # Notify: send a desktop notification on match.
  # Requires notify-send (libnotify) or a custom notification command.
  # - name: notify-large-downloads
  #   watch: ~/Downloads
  #   match:
  #     pattern: "*"
  #     min_size: "100MB"  # supports B, KB, MB, GB, TB or plain bytes
  #   actions:
  #     - notify:
  #         title: "Large download"
  #         body: "File arrived: {name}"
  #         urgency: normal  # low, normal, or critical

  # Compress: create a zip archive from matched files.
  # - name: archive-logs
  #   watch: ~/logs
  #   match:
  #     pattern: "*.log"
  #     older_than: 7  # days
  #   actions:
  #     - compress:
  #         dest: ~/archives/
  #         level: 6  # 0=stored, 9=max compression
  #     - trash-original: true

  # Tags: assign rules to groups that can be enabled/disabled as a set.
  # Useful for switching between profiles (e.g., work vs personal).
  # - name: work-invoices
  #   tags: [work]
  #   watch: ~/Downloads
  #   match:
  #     pattern: "*.pdf"
  #   actions:
  #     - move: ~/Work/Invoices/
  #
  # - name: personal-photos
  #   tags: [personal]
  #   watch: ~/Downloads
  #   match:
  #     pattern: "*.jpg"
  #   actions:
  #     - move: ~/Photos/

# Tag groups: enable or disable tagged rules as a set.
# Rules with a disabled tag are skipped. Untagged rules always run.
# groups:
#   work: true
#   personal: false
"""


@dataclass
class MatchConfig:
    """Matching criteria for a rule."""
    pattern: str = "*"
    type: str = "file"  # file, directory, any
    regex: str | None = None
    min_size: int | None = None  # bytes
    max_size: int | None = None
    older_than: float | None = None  # days
    newer_than: float | None = None  # days
    content: str | None = None  # regex searched inside file content
    exclude: str | None = None  # glob pattern to exclude
    exclude_regex: str | None = None  # regex pattern to exclude
    symlinks: str = "follow"  # follow, skip, or reject

    @classmethod
    def from_dict(cls, data: dict | str) -> MatchConfig:
        if isinstance(data, str):
            return cls(pattern=data)
        return cls(
            pattern=data.get("pattern", "*"),
            type=data.get("type", "file"),
            regex=data.get("regex"),
            min_size=parse_size(data.get("min_size")),
            max_size=parse_size(data.get("max_size")),
            older_than=data.get("older_than"),
            newer_than=data.get("newer_than"),
            content=data.get("content"),
            exclude=data.get("exclude"),
            exclude_regex=data.get("exclude_regex"),
            symlinks=data.get("symlinks", "follow"),
        )


@dataclass
class ActionConfig:
    """A single action to execute."""
    kind: str  # move, copy, rename, trash, unzip, shell, trash-original
    params: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict | str) -> ActionConfig:
        if isinstance(data, str):
            # Simple string form like "trash-original: true"
            return cls(kind=data, params={})

        # Dict with one key
        if isinstance(data, dict):
            for key, val in data.items():
                if isinstance(val, dict):
                    return cls(kind=key, params=val)
                elif isinstance(val, bool):
                    return cls(kind=key, params={"enabled": val})
                elif isinstance(val, str):
                    return cls(kind=key, params={"dest": val})
                else:
                    return cls(kind=key, params={"value": val})

        raise ValueError(f"Cannot parse action: {data!r}")


@dataclass
class RuleConfig:
    """A single rule definition."""
    name: str
    watch: str
    match: MatchConfig
    actions: list[ActionConfig]
    on: str = "created"  # created, modified, any
    enabled: bool = True
    priority: int = 0  # lower number = higher priority; default 0
    recursive: bool = False  # watch subdirectories too
    debounce: float = 1.0  # seconds to wait before handling repeat events on same file
    tags: list[str] = field(default_factory=list)  # tag-based rule groups

    @classmethod
    def from_dict(cls, data: dict) -> RuleConfig:
        match_raw = data.get("match", "*")
        match = MatchConfig.from_dict(match_raw)

        actions_raw = data.get("actions", [])
        actions = [ActionConfig.from_dict(a) for a in actions_raw]

        watch_path = os.path.expanduser(data.get("watch", "."))

        raw_tags = data.get("tags", [])
        if isinstance(raw_tags, str):
            raw_tags = [raw_tags]

        return cls(
            name=data.get("name", "unnamed"),
            watch=watch_path,
            match=match,
            actions=actions,
            on=data.get("on", "created"),
            enabled=_coerce_bool(data.get("enabled"), default=True),
            priority=int(data.get("priority", 0)),
            recursive=_coerce_bool(data.get("recursive"), default=False),
            debounce=float(data.get("debounce", 1.0)),
            tags=[str(t) for t in raw_tags],
        )

    def validate(self, known_actions: set[str] | None = None) -> list[str]:
        """Return a list of validation errors (empty = valid).

        If *known_actions* is provided, each action's kind is checked
        against it and unknown actions are reported as errors.
        """
        errors = []
        if not self.name:
            errors.append("Rule missing 'name'")
        if not self.watch:
            errors.append(f"Rule '{self.name}' missing 'watch' directory")
        if not self.actions:
            errors.append(f"Rule '{self.name}' has no actions")
        watch_path = Path(self.watch)
        if not watch_path.exists():
            errors.append(f"Rule '{self.name}': watch directory does not exist: {self.watch}")
        if self.match.symlinks not in ("follow", "skip", "reject"):
            errors.append(
                f"Rule '{self.name}': invalid symlinks value '{self.match.symlinks}'"
                " (must be follow, skip, or reject)"
            )
        if known_actions is not None:
            for action in self.actions:
                if action.kind not in known_actions:
                    errors.append(
                        f"Rule '{self.name}': unknown action '{action.kind}'"
                    )
        return errors


@dataclass
class FlumeConfig:
    """Top-level Flume configuration."""
    rules: list[RuleConfig] = field(default_factory=list)
    groups: dict[str, bool] = field(default_factory=dict)  # tag -> enabled
    log_file: str | None = None
    log_level: str = "INFO"
    log_max_bytes: int = 5 * 1024 * 1024  # 5 MB default
    log_backup_count: int = 3

    @classmethod
    def from_dict(cls, data: dict) -> FlumeConfig:
        rules_raw = data.get("rules", [])
        rules = [RuleConfig.from_dict(r) for r in rules_raw if r is not None]

        # Sort by priority (lower = runs first). Stable sort preserves
        # config-file order for rules with the same priority.
        rules.sort(key=lambda r: r.priority)

        raw_groups = data.get("groups", {})
        groups = {str(k): _coerce_bool(v) for k, v in raw_groups.items()} if raw_groups else {}

        return cls(
            rules=rules,
            groups=groups,
            log_file=data.get("log_file"),
            log_level=data.get("log_level", "INFO"),
            log_max_bytes=data.get("log_max_bytes", 5 * 1024 * 1024),
            log_backup_count=data.get("log_backup_count", 3),
        )

    def effective_rules(
        self,
        enable_tags: set[str] | None = None,
        disable_tags: set[str] | None = None,
    ) -> list[RuleConfig]:
        """Return rules filtered by tag groups and CLI overrides.

        Filtering logic:
        - Disabled rules (enabled=False) are always excluded.
        - Untagged rules are always included.
        - A tagged rule is excluded if ANY of its tags is disabled, where
          "disabled" means: present in disable_tags, OR present in
          self.groups as False (and not overridden by enable_tags).
        - enable_tags overrides a group being disabled in config.
        - disable_tags takes precedence over enable_tags for the same tag.
        """
        enable_tags = enable_tags or set()
        disable_tags = disable_tags or set()
        result = []

        for rule in self.rules:
            if not rule.enabled:
                continue

            # Untagged rules are always included
            if not rule.tags:
                result.append(rule)
                continue

            skip = False
            for tag in rule.tags:
                # disable_tags CLI override takes highest precedence
                if tag in disable_tags:
                    skip = True
                    break
                # Check groups config, but allow enable_tags to override
                if tag in self.groups and not self.groups[tag]:
                    if tag not in enable_tags:
                        skip = True
                        break

            if not skip:
                result.append(rule)

        return result

    def validate(self, known_actions: set[str] | None = None) -> list[str]:
        errors = []
        if not self.rules:
            errors.append("No rules defined")
        for rule in self.rules:
            errors.extend(rule.validate(known_actions=known_actions))
        return errors


def _resolve_includes(data: dict, base_dir: Path, seen: set[Path] | None = None) -> dict:
    """Resolve 'include' directives, merging rules from included files.

    Included paths are relative to the directory of the file that
    contains the include directive.  Circular includes are detected
    and silently skipped.  Glob patterns (e.g. ``rules.d/*.yaml``)
    are expanded.
    """
    if seen is None:
        seen = set()

    includes = data.get("include", [])
    if isinstance(includes, str):
        includes = [includes]

    if not includes:
        return data

    merged_rules: list[dict] = []

    for pattern in includes:
        expanded = os.path.expanduser(pattern)
        if not os.path.isabs(expanded):
            expanded = str(base_dir / expanded)

        # Support glob patterns
        from glob import glob as _glob
        matches = sorted(_glob(expanded))
        if not matches:
            # Treat as literal path -- will be skipped if it doesn't exist
            matches = [expanded]

        for inc_path_str in matches:
            inc_path = Path(inc_path_str).resolve()
            if inc_path in seen or not inc_path.exists():
                continue
            seen.add(inc_path)

            with open(inc_path) as f:
                inc_data = yaml.safe_load(f)
            if inc_data is None:
                continue

            # Recursively resolve nested includes
            inc_data = _resolve_includes(inc_data, inc_path.parent, seen)

            inc_rules = inc_data.get("rules", [])
            if inc_rules:
                merged_rules.extend(inc_rules)

    # Included rules come before the main file's rules so users can
    # override or append in the primary config.
    existing_rules = data.get("rules", [])
    data = dict(data)
    data["rules"] = merged_rules + existing_rules
    data.pop("include", None)
    return data


def load_config(path: Path) -> FlumeConfig | None:
    """Load and parse config from YAML file.

    Supports an ``include`` key at the top level which accepts a list
    of file paths (or glob patterns) pointing to additional YAML rule
    files.  Paths are resolved relative to the directory containing the
    config file.  Circular includes are detected and skipped.
    """
    if not path.exists():
        return None

    resolved = path.resolve()

    with open(resolved) as f:
        data = yaml.safe_load(f)

    if data is None:
        return FlumeConfig()

    data = _resolve_includes(data, resolved.parent, seen={resolved})

    return FlumeConfig.from_dict(data)


def create_default_config(path: Path) -> None:
    """Write the default config template."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(DEFAULT_CONFIG_TEMPLATE)
