"""Flume — rule-based file operations engine."""

__version__ = "1.0.1"
