"""Desktop notification action via notify-send (or configurable command)."""

import subprocess
from pathlib import Path

from flume.config import ActionConfig
from flume.actions.registry import register_action
from flume.log import get_logger

logger = get_logger()

DEFAULT_COMMAND = "notify-send"


def action_notify(path: Path, config: ActionConfig, dry_run: bool) -> Path | None:
    """Send a desktop notification when a rule matches.

    Params:
        title   - notification title (default: "Flume")
        body    - notification body; supports {path}, {name}, {stem}, {dir}
                  substitution (default: "Matched: {name}")
        urgency - low, normal, or critical (default: normal)
        command - override the notification command (default: notify-send)
    """
    title = config.params.get("title", "Flume")
    body = config.params.get("body", config.params.get("dest", "Matched: {name}"))
    urgency = config.params.get("urgency", "normal")
    command = config.params.get("command", DEFAULT_COMMAND)

    # Template substitution
    body = body.replace("{path}", str(path))
    body = body.replace("{name}", path.name)
    body = body.replace("{stem}", path.stem)
    body = body.replace("{dir}", str(path.parent))

    title = title.replace("{path}", str(path))
    title = title.replace("{name}", path.name)
    title = title.replace("{stem}", path.stem)
    title = title.replace("{dir}", str(path.parent))

    if dry_run:
        logger.info(f"[dry-run] Would notify: {title} - {body}")
        return path

    cmd = [command, "--urgency", urgency, title, body]
    logger.info(f"Sending notification: {title} - {body}")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            logger.error(
                f"Notification failed (exit {result.returncode}): "
                f"{result.stderr.strip()}"
            )
        else:
            logger.debug("Notification sent successfully")
    except FileNotFoundError:
        logger.error(
            f"Notification command not found: {command}. "
            "Install libnotify (notify-send) or set a custom command."
        )
    except subprocess.TimeoutExpired:
        logger.error("Notification command timed out")
    except Exception as e:
        logger.error(f"Notification error: {e}")

    return path


register_action("notify", action_notify)
