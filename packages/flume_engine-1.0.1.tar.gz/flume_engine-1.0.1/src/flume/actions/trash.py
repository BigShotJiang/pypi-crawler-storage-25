"""Trash action (safe delete via send2trash)."""

from pathlib import Path

from flume.config import ActionConfig
from flume.actions.registry import register_action
from flume.log import get_logger

logger = get_logger()


def action_trash(path: Path, config: ActionConfig, dry_run: bool) -> Path | None:
    """Move a file or directory to the system trash."""
    enabled = config.params.get("enabled", True)
    if not enabled:
        return path

    if dry_run:
        logger.info(f"[dry-run] Would trash: {path}")
        return None

    try:
        from send2trash import send2trash
        send2trash(str(path))
        logger.info(f"Trashed: {path}")
    except Exception as e:
        logger.error(f"Failed to trash {path}: {e}")
        return path

    return None


def action_trash_original(path: Path, config: ActionConfig, dry_run: bool) -> Path | None:
    """Trash the original file (alias for trash)."""
    return action_trash(path, config, dry_run)


register_action("trash", action_trash)
register_action("trash-original", action_trash_original)
