"""Rename action."""

import hashlib
from datetime import datetime
from pathlib import Path

from flume.config import ActionConfig
from flume.actions.registry import register_action
from flume.actions.conflict import resolve_conflict, DEFAULT_STRATEGY
from flume.log import get_logger

logger = get_logger()


def _file_hash(path: Path, length: int = 8) -> str:
    """Return the first *length* hex chars of the file's SHA-256 digest."""
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
    except (OSError, IsADirectoryError):
        return "0" * length
    return h.hexdigest()[:length]


def _size_human(path: Path) -> str:
    """Return a human-readable file size (e.g. '1.2MB', '340B')."""
    try:
        size = path.stat().st_size
    except OSError:
        return "0B"

    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            if unit == "B":
                return f"{size}{unit}"
            return f"{size:.1f}{unit}"
        size /= 1024
    return f"{size:.1f}TB"  # unreachable, but keeps the type checker happy


def _next_counter(directory: Path, stem: str, suffix: str) -> int:
    """Find the next available counter value in *directory*.

    Scans for files matching ``<stem>_NNN<suffix>`` and returns one higher
    than the largest N found, or 1 if none exist.
    """
    highest = 0
    prefix = f"{stem}_"
    for child in directory.iterdir():
        if child.name.startswith(prefix) and child.suffix == suffix:
            middle = child.stem[len(prefix):]
            if middle.isdigit():
                highest = max(highest, int(middle))
    return highest + 1


def _expand_template(template: str, path: Path) -> str:
    """Expand rename template variables."""
    now = datetime.now()
    stem = path.stem
    suffix = path.suffix

    result = template
    result = result.replace("{original}", path.name)
    result = result.replace("{stem}", stem)
    result = result.replace("{ext}", suffix)
    result = result.replace("{date:%Y-%m-%d}", now.strftime("%Y-%m-%d"))
    result = result.replace("{date:%Y%m%d}", now.strftime("%Y%m%d"))
    result = result.replace("{datetime}", now.strftime("%Y-%m-%d_%H%M%S"))

    # New template variables
    if "{hash}" in result:
        result = result.replace("{hash}", _file_hash(path))
    if "{size_human}" in result:
        result = result.replace("{size_human}", _size_human(path))
    if "{counter}" in result:
        counter = _next_counter(path.parent, stem, suffix)
        result = result.replace("{counter}", str(counter))

    return result


def action_rename(path: Path, config: ActionConfig, dry_run: bool) -> Path | None:
    """Rename a file using a template."""
    template = config.params.get("dest", config.params.get("template", "{original}"))
    on_conflict = config.params.get("on_conflict", DEFAULT_STRATEGY)
    new_name = _expand_template(template, path)
    new_path = path.parent / new_name

    if new_path == path:
        return path

    if dry_run:
        logger.info(f"[dry-run] Would rename: {path.name} -> {new_name}")
        return new_path

    if new_path.exists():
        new_path = resolve_conflict(new_path, on_conflict)
        if new_path is None:
            return None

    path.rename(new_path)
    logger.info(f"Renamed: {path.name} -> {new_name}")
    return new_path


register_action("rename", action_rename)
