"""Compress action -- create a zip archive from a matched file or directory."""

import zipfile
from pathlib import Path

from flume.config import ActionConfig
from flume.actions.registry import register_action
from flume.log import get_logger

logger = get_logger()


def action_compress(path: Path, config: ActionConfig, dry_run: bool) -> Path | None:
    """Create a zip archive from a file or directory.

    Params:
        dest: Directory to write the archive into (default: same as source).
        level: Compression level 0-9 (default: 6). 0 = stored, 9 = max.
        suffix: Archive filename suffix (default: ".zip").

    The archive is named after the source: ``<name>.zip``.  If the source
    is a directory, its contents are added recursively.
    """
    dest = config.params.get("dest")
    suffix = config.params.get("suffix", ".zip")

    try:
        level = int(config.params.get("level", 6))
    except (ValueError, TypeError):
        logger.error(
            f"Invalid compression level for {path}: "
            f"expected an integer 0-9, got {config.params.get('level')!r}"
        )
        return None

    if not (0 <= level <= 9):
        logger.error(
            f"Invalid compression level for {path}: "
            f"expected 0-9, got {level}"
        )
        return None

    if dest:
        dest_dir = Path(dest).expanduser()
    else:
        dest_dir = path.parent

    archive_name = path.stem + suffix
    archive_path = dest_dir / archive_name

    if dry_run:
        logger.info(f"[DRY RUN] Would compress {path} -> {archive_path}")
        return archive_path

    dest_dir.mkdir(parents=True, exist_ok=True)

    # Map level 0-9 to zipfile constants
    if level == 0:
        compression = zipfile.ZIP_STORED
    else:
        compression = zipfile.ZIP_DEFLATED

    try:
        with zipfile.ZipFile(archive_path, "w", compression, compresslevel=level) as zf:
            if path.is_dir():
                for child in sorted(path.rglob("*")):
                    if child.is_file():
                        arcname = child.relative_to(path.parent)
                        zf.write(child, arcname)
            else:
                zf.write(path, path.name)

        logger.info(f"Compressed: {path} -> {archive_path}")
        return archive_path
    except (OSError, zipfile.BadZipFile) as exc:
        logger.error(f"Failed to compress {path}: {exc}")
        return None


register_action("compress", action_compress)
