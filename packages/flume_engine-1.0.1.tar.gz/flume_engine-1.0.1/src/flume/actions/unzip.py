"""Unzip action."""

import zipfile
from pathlib import Path

from flume.config import ActionConfig
from flume.actions.registry import register_action
from flume.log import get_logger

logger = get_logger()


def action_unzip(path: Path, config: ActionConfig, dry_run: bool) -> Path | None:
    """Extract a zip archive to a destination directory."""
    if not path.is_file() or path.suffix.lower() != ".zip":
        logger.warning(f"Not a zip file, skipping: {path}")
        return path

    dest_dir = Path(config.params.get("dest", path.parent)).expanduser()
    extract_to = dest_dir / path.stem

    if dry_run:
        logger.info(f"[dry-run] Would unzip: {path} -> {extract_to}")
        return extract_to

    try:
        extract_to.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(path, "r") as zf:
            zf.extractall(extract_to)
        logger.info(f"Unzipped: {path} -> {extract_to}")
        return extract_to
    except zipfile.BadZipFile:
        logger.error(f"Bad zip file: {path}")
        return None
    except Exception as e:
        logger.error(f"Unzip failed for {path}: {e}")
        return None


register_action("unzip", action_unzip)
