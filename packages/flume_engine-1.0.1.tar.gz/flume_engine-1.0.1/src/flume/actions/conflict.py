"""Conflict resolution strategies for file actions."""

from __future__ import annotations

import shutil
from pathlib import Path

from flume.log import get_logger

logger = get_logger()

STRATEGIES = ("skip", "overwrite", "rename-suffix")
DEFAULT_STRATEGY = "skip"


def resolve_conflict(dest: Path, strategy: str) -> Path | None:
    """Resolve a destination conflict.

    Returns the resolved destination path to use, or None to skip.

    Strategies:
        skip: Return None (caller should skip).
        overwrite: Remove existing and return the same dest.
        rename-suffix: Return a new path with numeric suffix (file_1.txt, etc.).
    """
    if not dest.exists():
        return dest

    if strategy not in STRATEGIES:
        logger.warning(f"Unknown conflict strategy '{strategy}', falling back to skip")
        strategy = "skip"

    if strategy == "skip":
        logger.warning(f"Destination exists, skipping: {dest}")
        return None

    if strategy == "overwrite":
        logger.info(f"Overwriting existing: {dest}")
        if dest.is_dir():
            shutil.rmtree(dest)
        else:
            dest.unlink()
        return dest

    if strategy == "rename-suffix":
        return _find_available_name(dest)

    return None  # unreachable


def _find_available_name(dest: Path) -> Path:
    """Find the next available name by appending _1, _2, etc."""
    parent = dest.parent
    stem = dest.stem
    suffix = dest.suffix

    counter = 1
    while True:
        candidate = parent / f"{stem}_{counter}{suffix}"
        if not candidate.exists():
            logger.info(f"Conflict resolved, using: {candidate}")
            return candidate
        counter += 1
