"""Dedup action -- detect and handle duplicate files by content hash."""

import hashlib
from pathlib import Path

from flume.config import ActionConfig
from flume.actions.registry import register_action
from flume.log import get_logger

logger = get_logger()

# Block size for hashing (64 KB)
_HASH_BLOCK_SIZE = 65536


def _file_hash(path: Path) -> str:
    """Compute SHA-256 hash of a file's contents."""
    hasher = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            block = f.read(_HASH_BLOCK_SIZE)
            if not block:
                break
            hasher.update(block)
    return hasher.hexdigest()


def _find_duplicates(path: Path, search_dirs: list[str]) -> list[Path]:
    """Find files in search_dirs with the same content hash as path."""
    target_hash = _file_hash(path)
    duplicates = []

    for dir_str in search_dirs:
        search_dir = Path(dir_str).expanduser()
        if not search_dir.is_dir():
            logger.warning(f"Dedup search directory missing: {search_dir}")
            continue

        for candidate in search_dir.iterdir():
            if not candidate.is_file():
                continue
            # Skip the file itself
            if candidate.resolve() == path.resolve():
                continue
            # Quick size check before hashing
            try:
                if candidate.stat().st_size != path.stat().st_size:
                    continue
                if _file_hash(candidate) == target_hash:
                    duplicates.append(candidate)
            except OSError:
                continue

    return duplicates


def action_dedup(path: Path, config: ActionConfig, dry_run: bool) -> Path | None:
    """Detect duplicates of a file across specified directories.

    Params:
        dirs: list of directories to search for duplicates
        on_duplicate: what to do when the incoming file is a duplicate
                      - "report" (default): log only
                      - "trash": send the incoming file to trash
                      - "skip": return None to halt the action chain
    """
    search_dirs = config.params.get("dirs", [])
    on_duplicate = config.params.get("on_duplicate", "report")

    if not search_dirs:
        logger.error("Dedup action requires 'dirs' parameter")
        return path

    if not path.is_file():
        return path

    duplicates = _find_duplicates(path, search_dirs)

    if not duplicates:
        logger.debug(f"No duplicates found for: {path}")
        return path

    dup_paths = ", ".join(str(d) for d in duplicates)

    if dry_run:
        logger.info(f"[dry-run] Duplicate detected: {path} matches {dup_paths}")
        if on_duplicate == "trash":
            logger.info(f"[dry-run] Would trash duplicate: {path}")
        return path if on_duplicate != "skip" else None

    logger.info(f"Duplicate detected: {path} matches {dup_paths}")

    if on_duplicate == "trash":
        try:
            from send2trash import send2trash
            send2trash(str(path))
            logger.info(f"Trashed duplicate: {path}")
        except Exception as e:
            logger.error(f"Failed to trash {path}: {e}")
            return path
        return None

    if on_duplicate == "skip":
        return None

    # Default: report only, continue chain
    return path


register_action("dedup", action_dedup)
