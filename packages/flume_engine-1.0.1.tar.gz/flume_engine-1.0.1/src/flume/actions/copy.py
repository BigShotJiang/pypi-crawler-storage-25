"""Copy action."""

import shutil
from pathlib import Path

from flume.config import ActionConfig
from flume.actions.registry import register_action
from flume.actions.conflict import resolve_conflict, DEFAULT_STRATEGY
from flume.log import get_logger

logger = get_logger()


def action_copy(path: Path, config: ActionConfig, dry_run: bool) -> Path | None:
    """Copy a file or directory to a destination."""
    dest_dir = Path(config.params.get("dest", ".")).expanduser()
    dest = dest_dir / path.name
    on_conflict = config.params.get("on_conflict", DEFAULT_STRATEGY)

    if dry_run:
        logger.info(f"[dry-run] Would copy: {path} -> {dest}")
        return dest

    dest_dir.mkdir(parents=True, exist_ok=True)

    if path.is_dir():
        if dest.exists():
            dest = resolve_conflict(dest, on_conflict)
            if dest is None:
                return None
        shutil.copytree(str(path), str(dest))
    else:
        if dest.exists():
            dest = resolve_conflict(dest, on_conflict)
            if dest is None:
                return None
        shutil.copy2(str(path), str(dest))

    logger.info(f"Copied: {path} -> {dest}")
    return dest


register_action("copy", action_copy)
