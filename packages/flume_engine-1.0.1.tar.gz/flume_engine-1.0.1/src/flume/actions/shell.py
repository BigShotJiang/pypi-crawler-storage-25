"""Shell command action."""

import subprocess
from pathlib import Path

from flume.config import ActionConfig
from flume.actions.registry import register_action
from flume.log import get_logger

logger = get_logger()


def action_shell(path: Path, config: ActionConfig, dry_run: bool) -> Path | None:
    """Run a shell command with path substitution."""
    command = config.params.get("dest", config.params.get("command", ""))
    if not command:
        logger.error("Shell action missing command")
        return path

    # Substitute {path}, {name}, {stem}, {dir}
    command = command.replace("{path}", str(path))
    command = command.replace("{name}", path.name)
    command = command.replace("{stem}", path.stem)
    command = command.replace("{dir}", str(path.parent))

    if dry_run:
        logger.info(f"[dry-run] Would run: {command}")
        return path

    logger.info(f"Running: {command}")
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=3600,  # 1 hour max
        )
        if result.returncode != 0:
            logger.error(f"Command failed (exit {result.returncode}): {result.stderr.strip()}")
        else:
            logger.info(f"Command succeeded: {command}")
            if result.stdout.strip():
                logger.debug(result.stdout.strip())
    except subprocess.TimeoutExpired:
        logger.error(f"Command timed out: {command}")
    except Exception as e:
        logger.error(f"Command error: {e}")

    return path


register_action("shell", action_shell)
