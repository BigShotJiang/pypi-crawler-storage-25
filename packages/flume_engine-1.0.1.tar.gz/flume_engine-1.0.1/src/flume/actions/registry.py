"""Action registry — maps action names to handler functions."""

from __future__ import annotations

from typing import Callable
from pathlib import Path

from flume.config import ActionConfig

# Type for action handlers: (path, action_config, dry_run) -> new_path or None
ActionHandler = Callable[[Path, ActionConfig, bool], Path | None]

_registry: dict[str, ActionHandler] = {}


def register_action(name: str, handler: ActionHandler) -> None:
    """Register an action handler."""
    _registry[name] = handler


def get_action(name: str) -> ActionHandler | None:
    """Look up an action handler by name."""
    return _registry.get(name)


def list_actions() -> list[str]:
    """Return all registered action names."""
    return sorted(_registry.keys())


def _register_builtins() -> None:
    """Register all built-in actions."""
    from flume.actions import move, copy, rename, trash, unzip, shell, dedup, notify, compress  # noqa: F401


_register_builtins()
