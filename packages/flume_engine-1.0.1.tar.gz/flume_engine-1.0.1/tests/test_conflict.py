"""Tests for conflict resolution strategies."""

import pytest
from pathlib import Path

from flume.actions.conflict import resolve_conflict, _find_available_name
from flume.actions.move import action_move
from flume.actions.copy import action_copy
from flume.actions.rename import action_rename
from flume.config import ActionConfig


def _write_file(path: Path, content: str = "test content") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return path


class TestResolveConflict:
    def test_no_conflict_returns_dest(self, tmp_path):
        dest = tmp_path / "file.txt"
        result = resolve_conflict(dest, "skip")
        assert result == dest

    def test_skip_returns_none(self, tmp_path):
        dest = _write_file(tmp_path / "file.txt")
        result = resolve_conflict(dest, "skip")
        assert result is None

    def test_overwrite_removes_file(self, tmp_path):
        dest = _write_file(tmp_path / "file.txt", "old")
        result = resolve_conflict(dest, "overwrite")
        assert result == dest
        assert not dest.exists()

    def test_overwrite_removes_directory(self, tmp_path):
        dest = tmp_path / "somedir"
        dest.mkdir()
        _write_file(dest / "child.txt")
        result = resolve_conflict(dest, "overwrite")
        assert result == dest
        assert not dest.exists()

    def test_rename_suffix_appends_1(self, tmp_path):
        dest = _write_file(tmp_path / "file.txt")
        result = resolve_conflict(dest, "rename-suffix")
        assert result == tmp_path / "file_1.txt"

    def test_rename_suffix_increments(self, tmp_path):
        _write_file(tmp_path / "file.txt")
        _write_file(tmp_path / "file_1.txt")
        _write_file(tmp_path / "file_2.txt")
        result = resolve_conflict(tmp_path / "file.txt", "rename-suffix")
        assert result == tmp_path / "file_3.txt"

    def test_unknown_strategy_falls_back_to_skip(self, tmp_path):
        dest = _write_file(tmp_path / "file.txt")
        result = resolve_conflict(dest, "bogus")
        assert result is None


class TestMoveConflictStrategies:
    def test_default_skips(self, tmp_path):
        src = _write_file(tmp_path / "src" / "file.txt", "new")
        dest_dir = tmp_path / "dest"
        _write_file(dest_dir / "file.txt", "existing")

        config = ActionConfig(kind="move", params={"dest": str(dest_dir)})
        result = action_move(src, config, dry_run=False)

        assert result is None
        assert src.exists()
        assert (dest_dir / "file.txt").read_text() == "existing"

    def test_overwrite(self, tmp_path):
        src = _write_file(tmp_path / "src" / "file.txt", "new")
        dest_dir = tmp_path / "dest"
        _write_file(dest_dir / "file.txt", "existing")

        config = ActionConfig(kind="move", params={
            "dest": str(dest_dir), "on_conflict": "overwrite"
        })
        result = action_move(src, config, dry_run=False)

        assert result == dest_dir / "file.txt"
        assert (dest_dir / "file.txt").read_text() == "new"
        assert not src.exists()

    def test_rename_suffix(self, tmp_path):
        src = _write_file(tmp_path / "src" / "file.txt", "new")
        dest_dir = tmp_path / "dest"
        _write_file(dest_dir / "file.txt", "existing")

        config = ActionConfig(kind="move", params={
            "dest": str(dest_dir), "on_conflict": "rename-suffix"
        })
        result = action_move(src, config, dry_run=False)

        assert result == dest_dir / "file_1.txt"
        assert (dest_dir / "file_1.txt").read_text() == "new"
        assert (dest_dir / "file.txt").read_text() == "existing"
        assert not src.exists()


class TestCopyConflictStrategies:
    def test_default_skips(self, tmp_path):
        src = _write_file(tmp_path / "src" / "file.txt", "content")
        dest_dir = tmp_path / "dest"
        _write_file(dest_dir / "file.txt", "existing")

        config = ActionConfig(kind="copy", params={"dest": str(dest_dir)})
        result = action_copy(src, config, dry_run=False)

        assert result is None
        assert (dest_dir / "file.txt").read_text() == "existing"

    def test_overwrite(self, tmp_path):
        src = _write_file(tmp_path / "src" / "file.txt", "new")
        dest_dir = tmp_path / "dest"
        _write_file(dest_dir / "file.txt", "existing")

        config = ActionConfig(kind="copy", params={
            "dest": str(dest_dir), "on_conflict": "overwrite"
        })
        result = action_copy(src, config, dry_run=False)

        assert result == dest_dir / "file.txt"
        assert (dest_dir / "file.txt").read_text() == "new"

    def test_rename_suffix(self, tmp_path):
        src = _write_file(tmp_path / "src" / "file.txt", "new")
        dest_dir = tmp_path / "dest"
        _write_file(dest_dir / "file.txt", "existing")

        config = ActionConfig(kind="copy", params={
            "dest": str(dest_dir), "on_conflict": "rename-suffix"
        })
        result = action_copy(src, config, dry_run=False)

        assert result == dest_dir / "file_1.txt"
        assert (dest_dir / "file_1.txt").read_text() == "new"
        assert (dest_dir / "file.txt").read_text() == "existing"


class TestCopyDirectoryConflictStrategies:
    """Tests for directory copy conflict resolution (MF-31)."""

    def _make_src_dir(self, tmp_path):
        src = tmp_path / "src" / "album"
        src.mkdir(parents=True)
        _write_file(src / "new.txt", "new content")
        return src

    def _make_existing_dest_dir(self, tmp_path):
        dest_dir = tmp_path / "dest"
        existing = dest_dir / "album"
        existing.mkdir(parents=True)
        _write_file(existing / "old.txt", "old content")
        return dest_dir

    def test_skip_does_not_merge(self, tmp_path):
        src = self._make_src_dir(tmp_path)
        dest_dir = self._make_existing_dest_dir(tmp_path)

        config = ActionConfig(kind="copy", params={
            "dest": str(dest_dir), "on_conflict": "skip"
        })
        result = action_copy(src, config, dry_run=False)

        assert result is None
        # Original directory untouched -- no merge happened
        assert (dest_dir / "album" / "old.txt").read_text() == "old content"
        assert not (dest_dir / "album" / "new.txt").exists()

    def test_default_skips(self, tmp_path):
        src = self._make_src_dir(tmp_path)
        dest_dir = self._make_existing_dest_dir(tmp_path)

        config = ActionConfig(kind="copy", params={"dest": str(dest_dir)})
        result = action_copy(src, config, dry_run=False)

        assert result is None
        assert not (dest_dir / "album" / "new.txt").exists()

    def test_overwrite_replaces_directory(self, tmp_path):
        src = self._make_src_dir(tmp_path)
        dest_dir = self._make_existing_dest_dir(tmp_path)

        config = ActionConfig(kind="copy", params={
            "dest": str(dest_dir), "on_conflict": "overwrite"
        })
        result = action_copy(src, config, dry_run=False)

        assert result == dest_dir / "album"
        # Old content removed, new content present
        assert not (dest_dir / "album" / "old.txt").exists()
        assert (dest_dir / "album" / "new.txt").read_text() == "new content"

    def test_rename_suffix(self, tmp_path):
        src = self._make_src_dir(tmp_path)
        dest_dir = self._make_existing_dest_dir(tmp_path)

        config = ActionConfig(kind="copy", params={
            "dest": str(dest_dir), "on_conflict": "rename-suffix"
        })
        result = action_copy(src, config, dry_run=False)

        assert result == dest_dir / "album_1"
        # Original directory untouched
        assert (dest_dir / "album" / "old.txt").read_text() == "old content"
        # New directory has the copied content
        assert (dest_dir / "album_1" / "new.txt").read_text() == "new content"

    def test_no_conflict_copies_normally(self, tmp_path):
        src = self._make_src_dir(tmp_path)
        dest_dir = tmp_path / "dest"
        dest_dir.mkdir(parents=True)

        config = ActionConfig(kind="copy", params={"dest": str(dest_dir)})
        result = action_copy(src, config, dry_run=False)

        assert result == dest_dir / "album"
        assert (dest_dir / "album" / "new.txt").read_text() == "new content"


class TestRenameConflictStrategies:
    def test_default_skips(self, tmp_path):
        src = _write_file(tmp_path / "original.txt", "content")
        _write_file(tmp_path / "renamed.txt", "blocker")

        config = ActionConfig(kind="rename", params={"template": "renamed.txt"})
        result = action_rename(src, config, dry_run=False)

        assert result is None
        assert src.exists()

    def test_overwrite(self, tmp_path):
        src = _write_file(tmp_path / "original.txt", "new")
        _write_file(tmp_path / "renamed.txt", "old")

        config = ActionConfig(kind="rename", params={
            "template": "renamed.txt", "on_conflict": "overwrite"
        })
        result = action_rename(src, config, dry_run=False)

        assert result == tmp_path / "renamed.txt"
        assert (tmp_path / "renamed.txt").read_text() == "new"
        assert not src.exists()

    def test_rename_suffix(self, tmp_path):
        src = _write_file(tmp_path / "original.txt", "new")
        _write_file(tmp_path / "renamed.txt", "blocker")

        config = ActionConfig(kind="rename", params={
            "template": "renamed.txt", "on_conflict": "rename-suffix"
        })
        result = action_rename(src, config, dry_run=False)

        assert result == tmp_path / "renamed_1.txt"
        assert (tmp_path / "renamed_1.txt").exists()
        assert (tmp_path / "renamed.txt").read_text() == "blocker"
