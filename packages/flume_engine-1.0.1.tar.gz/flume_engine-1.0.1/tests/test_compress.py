"""Tests for the compress action."""

import zipfile
from pathlib import Path

import pytest

from flume.actions.compress import action_compress
from flume.config import ActionConfig


@pytest.fixture
def sample_file(tmp_path):
    """Create a sample text file."""
    f = tmp_path / "readme.txt"
    f.write_text("Hello, Flume!")
    return f


@pytest.fixture
def sample_dir(tmp_path):
    """Create a sample directory with nested files."""
    d = tmp_path / "project"
    d.mkdir()
    (d / "file1.txt").write_text("alpha")
    sub = d / "sub"
    sub.mkdir()
    (sub / "file2.txt").write_text("beta")
    return d


class TestCompressFile:
    def test_compress_file_default_dest(self, sample_file, tmp_path):
        cfg = ActionConfig(kind="compress", params={})
        result = action_compress(sample_file, cfg, dry_run=False)

        assert result is not None
        assert result == tmp_path / "readme.zip"
        assert result.exists()

        with zipfile.ZipFile(result) as zf:
            names = zf.namelist()
            assert names == ["readme.txt"]
            assert zf.read("readme.txt") == b"Hello, Flume!"

    def test_compress_file_custom_dest(self, sample_file, tmp_path):
        out = tmp_path / "archives"
        cfg = ActionConfig(kind="compress", params={"dest": str(out)})
        result = action_compress(sample_file, cfg, dry_run=False)

        assert result == out / "readme.zip"
        assert result.exists()

    def test_compress_file_custom_suffix(self, sample_file, tmp_path):
        cfg = ActionConfig(kind="compress", params={"suffix": ".archive.zip"})
        result = action_compress(sample_file, cfg, dry_run=False)

        assert result is not None
        assert result.name == "readme.archive.zip"
        assert result.exists()

    def test_compress_file_stored(self, sample_file, tmp_path):
        cfg = ActionConfig(kind="compress", params={"level": 0})
        result = action_compress(sample_file, cfg, dry_run=False)

        assert result is not None
        with zipfile.ZipFile(result) as zf:
            info = zf.infolist()[0]
            assert info.compress_type == zipfile.ZIP_STORED

    def test_compress_file_deflated(self, sample_file, tmp_path):
        cfg = ActionConfig(kind="compress", params={"level": 9})
        result = action_compress(sample_file, cfg, dry_run=False)

        assert result is not None
        with zipfile.ZipFile(result) as zf:
            info = zf.infolist()[0]
            assert info.compress_type == zipfile.ZIP_DEFLATED


class TestCompressDirectory:
    def test_compress_dir(self, sample_dir, tmp_path):
        cfg = ActionConfig(kind="compress", params={})
        result = action_compress(sample_dir, cfg, dry_run=False)

        assert result is not None
        assert result == tmp_path / "project.zip"
        assert result.exists()

        with zipfile.ZipFile(result) as zf:
            names = sorted(zf.namelist())
            # Archive paths are relative to the parent directory
            assert "project/file1.txt" in names
            assert "project/sub/file2.txt" in names
            assert zf.read("project/file1.txt") == b"alpha"
            assert zf.read("project/sub/file2.txt") == b"beta"

    def test_compress_dir_custom_dest(self, sample_dir, tmp_path):
        out = tmp_path / "output"
        cfg = ActionConfig(kind="compress", params={"dest": str(out)})
        result = action_compress(sample_dir, cfg, dry_run=False)

        assert result == out / "project.zip"
        assert result.exists()


class TestCompressDryRun:
    def test_dry_run_does_not_create_file(self, sample_file, tmp_path):
        cfg = ActionConfig(kind="compress", params={})
        result = action_compress(sample_file, cfg, dry_run=True)

        assert result == tmp_path / "readme.zip"
        assert not result.exists()

    def test_dry_run_with_dest(self, sample_file, tmp_path):
        out = tmp_path / "dry"
        cfg = ActionConfig(kind="compress", params={"dest": str(out)})
        result = action_compress(sample_file, cfg, dry_run=True)

        assert result == out / "readme.zip"
        assert not out.exists()


class TestCompressInvalidLevel:
    def test_level_too_high(self, sample_file, tmp_path):
        cfg = ActionConfig(kind="compress", params={"level": 99})
        result = action_compress(sample_file, cfg, dry_run=False)
        assert result is None
        assert not (tmp_path / "readme.zip").exists()

    def test_level_negative(self, sample_file, tmp_path):
        cfg = ActionConfig(kind="compress", params={"level": -1})
        result = action_compress(sample_file, cfg, dry_run=False)
        assert result is None

    def test_level_non_numeric(self, sample_file, tmp_path):
        cfg = ActionConfig(kind="compress", params={"level": "banana"})
        result = action_compress(sample_file, cfg, dry_run=False)
        assert result is None

    def test_level_none(self, sample_file, tmp_path):
        """When level is explicitly None, should fall back to default via int()."""
        cfg = ActionConfig(kind="compress", params={"level": None})
        result = action_compress(sample_file, cfg, dry_run=False)
        # None can't be cast to int, so should return None
        assert result is None


class TestCompressRegistry:
    def test_registered(self):
        from flume.actions import get_action
        handler = get_action("compress")
        assert handler is action_compress
