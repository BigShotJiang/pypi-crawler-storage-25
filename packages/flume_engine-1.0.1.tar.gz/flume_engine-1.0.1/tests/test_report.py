"""Tests for dry-run summary report generation."""

import json

from flume.report import RuleReport, RunReport


class TestRuleReport:
    def test_defaults(self):
        rr = RuleReport(name="test-rule")
        assert rr.name == "test-rule"
        assert rr.matched == 0
        assert rr.actions_run == 0
        assert rr.files == []


class TestRunReport:
    def _sample_report(self):
        report = RunReport()
        r1 = RuleReport(name="sort-pdfs", matched=3, actions_run=3, files=[
            "/tmp/a.pdf", "/tmp/b.pdf", "/tmp/c.pdf",
        ])
        r2 = RuleReport(name="unzip-archives", matched=1, actions_run=2, files=[
            "/tmp/d.zip",
        ])
        r3 = RuleReport(name="empty-rule", matched=0, actions_run=0, files=[])
        report.add(r1)
        report.add(r2)
        report.add(r3)
        return report

    def test_totals(self):
        report = self._sample_report()
        assert report.total_matched == 4
        assert report.total_actions == 5
        assert len(report.rules) == 3

    def test_format_text(self):
        report = self._sample_report()
        text = report.format("text")
        assert "Dry-Run Summary Report" in text
        assert "sort-pdfs" in text
        assert "unzip-archives" in text
        assert "empty-rule" in text
        assert "Total matched: 4" in text
        assert "Total actions: 5" in text
        assert "/tmp/a.pdf" in text

    def test_format_json(self):
        report = self._sample_report()
        raw = report.format("json")
        data = json.loads(raw)
        assert data["total_matched"] == 4
        assert data["total_actions"] == 5
        assert len(data["rules"]) == 3
        assert data["rules"][0]["name"] == "sort-pdfs"
        assert data["rules"][0]["files"] == ["/tmp/a.pdf", "/tmp/b.pdf", "/tmp/c.pdf"]

    def test_format_csv(self):
        report = self._sample_report()
        csv_out = report.format("csv")
        lines = [l.strip() for l in csv_out.strip().split("\n")]
        assert len(lines) == 4  # header + 3 rules
        assert lines[0] == "rule,matched,actions,files"
        assert "sort-pdfs" in lines[1]
        assert "3" in lines[1]

    def test_format_invalid(self):
        report = RunReport()
        try:
            report.format("xml")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "xml" in str(e)

    def test_empty_report(self):
        report = RunReport()
        assert report.total_matched == 0
        assert report.total_actions == 0
        text = report.format("text")
        assert "Total matched: 0" in text


class TestEngineReport:
    """Test that Engine.run_once returns a RunReport with per-rule data."""

    def test_run_once_returns_report(self, tmp_path):
        from flume.config import FlumeConfig, RuleConfig, MatchConfig, ActionConfig

        # Create test files
        (tmp_path / "a.txt").write_text("hello")
        (tmp_path / "b.txt").write_text("world")
        (tmp_path / "c.pdf").write_text("pdf")

        cfg = FlumeConfig(rules=[
            RuleConfig(
                name="txt-rule",
                watch=str(tmp_path),
                match=MatchConfig(pattern="*.txt"),
                actions=[ActionConfig(kind="shell", params={"value": "echo {path}"})],
            ),
            RuleConfig(
                name="pdf-rule",
                watch=str(tmp_path),
                match=MatchConfig(pattern="*.pdf"),
                actions=[ActionConfig(kind="shell", params={"value": "echo {path}"})],
            ),
        ])

        from flume.engine import Engine
        engine = Engine(cfg, dry_run=True)
        report = engine.run_once()

        assert report.total_matched == 3
        assert len(report.rules) == 2

        txt_rule = report.rules[0]
        assert txt_rule.name == "txt-rule"
        assert txt_rule.matched == 2
        assert len(txt_rule.files) == 2

        pdf_rule = report.rules[1]
        assert pdf_rule.name == "pdf-rule"
        assert pdf_rule.matched == 1
        assert len(pdf_rule.files) == 1

    def test_report_exportable_json(self, tmp_path):
        """Verify the report from a real engine run can be exported to JSON."""
        from flume.config import FlumeConfig, RuleConfig, MatchConfig, ActionConfig
        from flume.engine import Engine

        (tmp_path / "file.log").write_text("log data")
        cfg = FlumeConfig(rules=[
            RuleConfig(
                name="log-rule",
                watch=str(tmp_path),
                match=MatchConfig(pattern="*.log"),
                actions=[ActionConfig(kind="shell", params={"value": "echo ok"})],
            ),
        ])

        engine = Engine(cfg, dry_run=True)
        report = engine.run_once()
        data = json.loads(report.format("json"))
        assert data["total_matched"] == 1
        assert data["rules"][0]["name"] == "log-rule"
