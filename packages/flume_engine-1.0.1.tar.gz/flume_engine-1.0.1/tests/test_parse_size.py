"""Tests for human-readable size parsing."""

import pytest

from flume.config import parse_size


class TestParseSize:
    """Test parse_size with various inputs."""

    def test_none_returns_none(self):
        assert parse_size(None) is None

    def test_int_passthrough(self):
        assert parse_size(1024) == 1024
        assert parse_size(0) == 0

    def test_float_truncates(self):
        assert parse_size(1024.7) == 1024

    def test_plain_string_number(self):
        assert parse_size("4096") == 4096

    def test_bytes_unit(self):
        assert parse_size("512B") == 512

    def test_kilobytes(self):
        assert parse_size("1K") == 1024
        assert parse_size("1KB") == 1024
        assert parse_size("1kb") == 1024

    def test_megabytes(self):
        assert parse_size("1M") == 1024 ** 2
        assert parse_size("1MB") == 1024 ** 2
        assert parse_size("100MB") == 100 * 1024 ** 2

    def test_gigabytes(self):
        assert parse_size("1G") == 1024 ** 3
        assert parse_size("1GB") == 1024 ** 3
        assert parse_size("2.5GB") == int(2.5 * 1024 ** 3)

    def test_terabytes(self):
        assert parse_size("1T") == 1024 ** 4
        assert parse_size("1TB") == 1024 ** 4

    def test_fractional(self):
        assert parse_size("0.5MB") == int(0.5 * 1024 ** 2)
        assert parse_size("2.5KB") == int(2.5 * 1024)

    def test_whitespace_between(self):
        assert parse_size("100 MB") == 100 * 1024 ** 2
        assert parse_size("  50 KB  ") == 50 * 1024

    def test_case_insensitive(self):
        assert parse_size("10mb") == parse_size("10MB")
        assert parse_size("10Mb") == parse_size("10MB")

    def test_empty_string_returns_none(self):
        assert parse_size("") is None
        assert parse_size("  ") is None

    def test_invalid_unit_raises(self):
        with pytest.raises(ValueError, match="Unknown size unit"):
            parse_size("100XB")

    def test_garbage_raises(self):
        with pytest.raises(ValueError, match="Cannot parse size"):
            parse_size("not-a-size")

    def test_negative_not_parsed(self):
        # Negative sizes are not valid input
        with pytest.raises(ValueError):
            parse_size("-100MB")

    def test_negative_int_rejected(self):
        with pytest.raises(ValueError, match="Negative sizes"):
            parse_size(-1)

    def test_negative_float_rejected(self):
        with pytest.raises(ValueError, match="Negative sizes"):
            parse_size(-1.5)

    def test_negative_numeric_string_rejected(self):
        with pytest.raises(ValueError):
            parse_size("-1024")


class TestMatchConfigSizeParsing:
    """Verify MatchConfig.from_dict uses parse_size for min/max_size."""

    def test_human_readable_min_size(self):
        from flume.config import MatchConfig
        cfg = MatchConfig.from_dict({"min_size": "10MB"})
        assert cfg.min_size == 10 * 1024 ** 2

    def test_human_readable_max_size(self):
        from flume.config import MatchConfig
        cfg = MatchConfig.from_dict({"max_size": "2.5GB"})
        assert cfg.max_size == int(2.5 * 1024 ** 3)

    def test_raw_int_still_works(self):
        from flume.config import MatchConfig
        cfg = MatchConfig.from_dict({"min_size": 4096, "max_size": 8192})
        assert cfg.min_size == 4096
        assert cfg.max_size == 8192
