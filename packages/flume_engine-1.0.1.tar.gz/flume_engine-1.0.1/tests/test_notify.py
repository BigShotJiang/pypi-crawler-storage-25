"""Tests for the notify action."""

from pathlib import Path
from unittest.mock import patch, MagicMock

from flume.actions.notify import action_notify
from flume.config import ActionConfig


def _write_file(path: Path, content: str = "test content") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return path


class TestNotifyAction:
    def test_dry_run_does_not_call_subprocess(self, tmp_path):
        target = _write_file(tmp_path / "file.txt")
        config = ActionConfig(kind="notify", params={})

        with patch("flume.actions.notify.subprocess") as mock_sub:
            result = action_notify(target, config, dry_run=True)

        assert result == target
        mock_sub.run.assert_not_called()

    def test_sends_notification_with_defaults(self, tmp_path):
        target = _write_file(tmp_path / "report.pdf")
        config = ActionConfig(kind="notify", params={})

        with patch("flume.actions.notify.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = action_notify(target, config, dry_run=False)

        assert result == target
        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert args[0] == "notify-send"
        assert args[1] == "--urgency"
        assert args[2] == "normal"
        assert args[3] == "Flume"
        assert args[4] == "Matched: report.pdf"

    def test_custom_title_and_body(self, tmp_path):
        target = _write_file(tmp_path / "subdir" / "image.png")
        config = ActionConfig(
            kind="notify",
            params={
                "title": "New file in {dir}",
                "body": "Got {name} ({stem})",
                "urgency": "critical",
            },
        )

        with patch("flume.actions.notify.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            result = action_notify(target, config, dry_run=False)

        assert result == target
        args = mock_run.call_args[0][0]
        assert args[2] == "critical"
        assert str(target.parent) in args[3]
        assert "image.png" in args[4]
        assert "image" in args[4]

    def test_template_substitution_in_body(self, tmp_path):
        target = _write_file(tmp_path / "docs" / "notes.md")
        config = ActionConfig(
            kind="notify",
            params={"body": "{path} | {name} | {stem} | {dir}"},
        )

        with patch("flume.actions.notify.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            action_notify(target, config, dry_run=False)

        body = mock_run.call_args[0][0][4]
        assert str(target) in body
        assert "notes.md" in body
        assert "notes" in body
        assert str(target.parent) in body

    def test_custom_command(self, tmp_path):
        target = _write_file(tmp_path / "file.txt")
        config = ActionConfig(
            kind="notify",
            params={"command": "my-notifier"},
        )

        with patch("flume.actions.notify.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            action_notify(target, config, dry_run=False)

        args = mock_run.call_args[0][0]
        assert args[0] == "my-notifier"

    def test_handles_command_not_found(self, tmp_path):
        target = _write_file(tmp_path / "file.txt")
        config = ActionConfig(kind="notify", params={})

        with patch("flume.actions.notify.subprocess.run") as mock_run:
            mock_run.side_effect = FileNotFoundError("not found")
            result = action_notify(target, config, dry_run=False)

        # Should not raise, just log the error and return path
        assert result == target

    def test_handles_failed_command(self, tmp_path):
        target = _write_file(tmp_path / "file.txt")
        config = ActionConfig(kind="notify", params={})

        with patch("flume.actions.notify.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=1, stderr="something went wrong"
            )
            result = action_notify(target, config, dry_run=False)

        assert result == target

    def test_handles_timeout(self, tmp_path):
        target = _write_file(tmp_path / "file.txt")
        config = ActionConfig(kind="notify", params={})

        with patch("flume.actions.notify.subprocess.run") as mock_run:
            mock_run.side_effect = __import__("subprocess").TimeoutExpired(
                "notify-send", 10
            )
            result = action_notify(target, config, dry_run=False)

        assert result == target

    def test_dest_param_used_as_body(self, tmp_path):
        """ActionConfig.from_dict({'notify': 'some text'} stores in dest."""
        target = _write_file(tmp_path / "file.txt")
        config = ActionConfig(kind="notify", params={"dest": "Custom: {name}"})

        with patch("flume.actions.notify.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            action_notify(target, config, dry_run=False)

        body = mock_run.call_args[0][0][4]
        assert body == "Custom: file.txt"

    def test_notify_registered(self):
        """Verify notify is in the action registry."""
        from flume.actions.registry import get_action
        assert get_action("notify") is not None
