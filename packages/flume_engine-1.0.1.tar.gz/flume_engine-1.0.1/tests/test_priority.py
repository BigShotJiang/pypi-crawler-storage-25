"""Tests for rule priority and ordering guarantees."""

from flume.config import FlumeConfig, RuleConfig


def _make_rules_config(rules_data: list[dict]) -> dict:
    """Wrap a list of rule dicts in a top-level config dict."""
    return {"rules": rules_data}


def _rule(name: str, priority: int = 0) -> dict:
    return {
        "name": name,
        "watch": "/tmp",
        "priority": priority,
        "match": "*",
        "actions": [{"shell": "echo test"}],
    }


class TestRulePriority:
    def test_default_priority_is_zero(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": "*",
            "actions": [{"shell": "echo test"}],
        })
        assert rule.priority == 0

    def test_explicit_priority_parsed(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "priority": 5,
            "match": "*",
            "actions": [{"shell": "echo test"}],
        })
        assert rule.priority == 5

    def test_negative_priority(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "priority": -10,
            "match": "*",
            "actions": [{"shell": "echo test"}],
        })
        assert rule.priority == -10

    def test_rules_sorted_by_priority(self):
        data = _make_rules_config([
            _rule("low", priority=10),
            _rule("high", priority=-5),
            _rule("medium", priority=0),
        ])
        config = FlumeConfig.from_dict(data)
        names = [r.name for r in config.rules]
        assert names == ["high", "medium", "low"]

    def test_same_priority_preserves_config_order(self):
        data = _make_rules_config([
            _rule("alpha", priority=0),
            _rule("beta", priority=0),
            _rule("gamma", priority=0),
        ])
        config = FlumeConfig.from_dict(data)
        names = [r.name for r in config.rules]
        assert names == ["alpha", "beta", "gamma"]

    def test_mixed_priorities_stable_within_tier(self):
        data = _make_rules_config([
            _rule("c-first", priority=1),
            _rule("a-urgent", priority=-1),
            _rule("c-second", priority=1),
            _rule("b-normal", priority=0),
            _rule("a-also-urgent", priority=-1),
        ])
        config = FlumeConfig.from_dict(data)
        names = [r.name for r in config.rules]
        assert names == [
            "a-urgent",
            "a-also-urgent",
            "b-normal",
            "c-first",
            "c-second",
        ]
