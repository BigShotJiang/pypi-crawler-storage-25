"""Tests for the ``flume test`` CLI command."""

import os
import textwrap

from click.testing import CliRunner

from flume.cli import main


def _write_config(tmp_path, content):
    cfg = tmp_path / "rules.yaml"
    cfg.write_text(textwrap.dedent(content))
    return str(cfg)


def test_test_matching_rule(tmp_path):
    """flume test shows rules that match the target file."""
    target = tmp_path / "report.pdf"
    target.write_text("dummy")

    cfg = _write_config(tmp_path, f"""\
        rules:
          - name: pdf-sort
            watch: {tmp_path}
            match:
              pattern: "*.pdf"
            actions:
              - move: /tmp/pdfs
    """)

    runner = CliRunner()
    result = runner.invoke(main, ["test", str(target), "-c", cfg])
    assert result.exit_code == 0
    assert "pdf-sort" in result.output
    assert "Matching rules (1)" in result.output


def test_test_no_match(tmp_path):
    """flume test reports no match when file does not fit any rule."""
    target = tmp_path / "photo.jpg"
    target.write_text("dummy")

    cfg = _write_config(tmp_path, f"""\
        rules:
          - name: pdf-sort
            watch: {tmp_path}
            match:
              pattern: "*.pdf"
            actions:
              - move: /tmp/pdfs
    """)

    runner = CliRunner()
    result = runner.invoke(main, ["test", str(target), "-c", cfg])
    assert result.exit_code == 0
    assert "No rules match" in result.output


def test_test_multiple_rules(tmp_path):
    """flume test lists all matching rules when multiple apply."""
    target = tmp_path / "data.csv"
    target.write_text("a,b,c")

    cfg = _write_config(tmp_path, f"""\
        rules:
          - name: csv-backup
            watch: {tmp_path}
            match:
              pattern: "*.csv"
            actions:
              - copy: /tmp/backup

          - name: csv-notify
            watch: {tmp_path}
            match:
              pattern: "*.csv"
            actions:
              - notify:
                  title: CSV arrived
    """)

    runner = CliRunner()
    result = runner.invoke(main, ["test", str(target), "-c", cfg])
    assert result.exit_code == 0
    assert "csv-backup" in result.output
    assert "csv-notify" in result.output
    assert "Matching rules (2)" in result.output


def test_test_outside_watch_dir(tmp_path):
    """Rules whose watch dir is not a parent of target are skipped."""
    watch_dir = tmp_path / "watched"
    watch_dir.mkdir()
    other_dir = tmp_path / "other"
    other_dir.mkdir()
    target = other_dir / "report.pdf"
    target.write_text("dummy")

    cfg = _write_config(tmp_path, f"""\
        rules:
          - name: pdf-sort
            watch: {watch_dir}
            match:
              pattern: "*.pdf"
            actions:
              - move: /tmp/pdfs
    """)

    runner = CliRunner()
    result = runner.invoke(main, ["test", str(target), "-c", cfg])
    assert result.exit_code == 0
    assert "No rules match" in result.output


def test_test_respects_tags(tmp_path):
    """flume test --disable-tags filters out tagged rules."""
    target = tmp_path / "report.pdf"
    target.write_text("dummy")

    cfg = _write_config(tmp_path, f"""\
        rules:
          - name: work-pdfs
            tags: [work]
            watch: {tmp_path}
            match:
              pattern: "*.pdf"
            actions:
              - move: /tmp/work
    """)

    runner = CliRunner()
    result = runner.invoke(main, [
        "test", str(target), "-c", cfg, "--disable-tags", "work",
    ])
    assert result.exit_code == 0
    assert "No rules match" in result.output
