"""Tests for move, copy, rename, unzip, and shell actions."""

import hashlib
import os
import zipfile
import pytest
from pathlib import Path
from unittest.mock import patch

from flume.actions.move import action_move
from flume.actions.copy import action_copy
from flume.actions.rename import action_rename, _expand_template, _file_hash, _size_human
from flume.actions.unzip import action_unzip
from flume.actions.shell import action_shell
from flume.config import ActionConfig


def _write_file(path: Path, content: str = "test content") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return path


def _make_zip(zip_path: Path, files: dict[str, str]) -> Path:
    """Create a zip file with the given {name: content} entries."""
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w") as zf:
        for name, content in files.items():
            zf.writestr(name, content)
    return zip_path


# -- Rename action (template variables) --


class TestRenameTemplates:
    def test_hash_template(self, tmp_path):
        f = _write_file(tmp_path / "data.txt", "hello world")
        expected_hash = hashlib.sha256(b"hello world").hexdigest()[:8]

        result = _expand_template("{stem}_{hash}{ext}", f)

        assert result == f"data_{expected_hash}.txt"

    def test_size_human_bytes(self, tmp_path):
        f = _write_file(tmp_path / "tiny.txt", "hi")
        result = _expand_template("{stem}_{size_human}{ext}", f)
        assert result == "tiny_2B.txt"

    def test_size_human_kilobytes(self, tmp_path):
        f = _write_file(tmp_path / "medium.bin", "x" * 2048)
        result = _expand_template("{stem}_{size_human}{ext}", f)
        assert result == "medium_2.0KB.bin"

    def test_size_human_megabytes(self, tmp_path):
        f = _write_file(tmp_path / "big.bin", "x" * (1024 * 1024 * 3))
        result = _expand_template("{stem}_{size_human}{ext}", f)
        assert result == "big_3.0MB.bin"

    def test_counter_starts_at_1(self, tmp_path):
        f = _write_file(tmp_path / "photo.jpg", "img")
        result = _expand_template("{stem}_{counter}{ext}", f)
        assert result == "photo_1.jpg"

    def test_counter_increments(self, tmp_path):
        _write_file(tmp_path / "photo_1.jpg", "a")
        _write_file(tmp_path / "photo_2.jpg", "b")
        f = _write_file(tmp_path / "photo.jpg", "c")

        result = _expand_template("{stem}_{counter}{ext}", f)
        assert result == "photo_3.jpg"

    def test_counter_finds_highest(self, tmp_path):
        _write_file(tmp_path / "doc_1.pdf", "a")
        _write_file(tmp_path / "doc_10.pdf", "b")
        _write_file(tmp_path / "doc_5.pdf", "c")
        f = _write_file(tmp_path / "doc.pdf", "d")

        result = _expand_template("{stem}_{counter}{ext}", f)
        assert result == "doc_11.pdf"

    def test_rename_action_with_hash(self, tmp_path):
        f = _write_file(tmp_path / "report.txt", "contents")
        expected_hash = hashlib.sha256(b"contents").hexdigest()[:8]

        config = ActionConfig(kind="rename", params={"template": "{stem}_{hash}{ext}"})
        result = action_rename(f, config, dry_run=False)

        assert result == tmp_path / f"report_{expected_hash}.txt"
        assert result.exists()
        assert not f.exists()

    def test_rename_action_dry_run(self, tmp_path):
        f = _write_file(tmp_path / "file.txt", "data")

        config = ActionConfig(kind="rename", params={"template": "{stem}_{counter}{ext}"})
        result = action_rename(f, config, dry_run=True)

        assert result == tmp_path / "file_1.txt"
        assert f.exists()  # original untouched

    def test_all_new_templates_combined(self, tmp_path):
        content = "test data"
        f = _write_file(tmp_path / "scan.pdf", content)
        expected_hash = hashlib.sha256(content.encode()).hexdigest()[:8]

        result = _expand_template("{stem}_{counter}_{hash}_{size_human}{ext}", f)
        assert result == f"scan_1_{expected_hash}_9B.pdf"


# -- Move action --


class TestMoveAction:
    def test_moves_file(self, tmp_path):
        src = _write_file(tmp_path / "source" / "data.txt")
        dest_dir = tmp_path / "dest"

        config = ActionConfig(kind="move", params={"dest": str(dest_dir)})
        result = action_move(src, config, dry_run=False)

        assert result == dest_dir / "data.txt"
        assert (dest_dir / "data.txt").exists()
        assert (dest_dir / "data.txt").read_text() == "test content"
        assert not src.exists()

    def test_creates_dest_dir(self, tmp_path):
        src = _write_file(tmp_path / "file.txt")
        dest_dir = tmp_path / "a" / "b" / "c"

        config = ActionConfig(kind="move", params={"dest": str(dest_dir)})
        result = action_move(src, config, dry_run=False)

        assert result is not None
        assert (dest_dir / "file.txt").exists()

    def test_skips_if_dest_exists(self, tmp_path):
        src = _write_file(tmp_path / "source" / "file.txt", "new")
        dest_dir = tmp_path / "dest"
        _write_file(dest_dir / "file.txt", "existing")

        config = ActionConfig(kind="move", params={"dest": str(dest_dir)})
        result = action_move(src, config, dry_run=False)

        assert result is None
        assert (dest_dir / "file.txt").read_text() == "existing"
        assert src.exists()

    def test_dry_run(self, tmp_path):
        src = _write_file(tmp_path / "file.txt")
        dest_dir = tmp_path / "dest"

        config = ActionConfig(kind="move", params={"dest": str(dest_dir)})
        result = action_move(src, config, dry_run=True)

        assert result == dest_dir / "file.txt"
        assert src.exists()
        assert not dest_dir.exists()


# -- Copy action --


class TestCopyAction:
    def test_copies_file(self, tmp_path):
        src = _write_file(tmp_path / "original.txt")
        dest_dir = tmp_path / "backup"

        config = ActionConfig(kind="copy", params={"dest": str(dest_dir)})
        result = action_copy(src, config, dry_run=False)

        assert result == dest_dir / "original.txt"
        assert (dest_dir / "original.txt").read_text() == "test content"
        assert src.exists()  # original preserved

    def test_copies_directory(self, tmp_path):
        src_dir = tmp_path / "source" / "album"
        _write_file(src_dir / "track1.mp3", "audio1")
        _write_file(src_dir / "track2.mp3", "audio2")

        dest_dir = tmp_path / "backup"

        config = ActionConfig(kind="copy", params={"dest": str(dest_dir)})
        result = action_copy(src_dir, config, dry_run=False)

        assert result == dest_dir / "album"
        assert (dest_dir / "album" / "track1.mp3").read_text() == "audio1"
        assert (dest_dir / "album" / "track2.mp3").read_text() == "audio2"

    def test_creates_dest_dir(self, tmp_path):
        src = _write_file(tmp_path / "file.txt")
        dest_dir = tmp_path / "x" / "y" / "z"

        config = ActionConfig(kind="copy", params={"dest": str(dest_dir)})
        result = action_copy(src, config, dry_run=False)

        assert result is not None
        assert (dest_dir / "file.txt").exists()

    def test_dry_run(self, tmp_path):
        src = _write_file(tmp_path / "file.txt")
        dest_dir = tmp_path / "dest"

        config = ActionConfig(kind="copy", params={"dest": str(dest_dir)})
        result = action_copy(src, config, dry_run=True)

        assert result == dest_dir / "file.txt"
        assert src.exists()
        assert not dest_dir.exists()

    def test_directory_copy_with_overwrite(self, tmp_path):
        """Directory copy with overwrite replaces existing destination."""
        src_dir = tmp_path / "source" / "data"
        _write_file(src_dir / "new.txt", "new")

        dest_dir = tmp_path / "dest"
        _write_file(dest_dir / "data" / "old.txt", "old")

        config = ActionConfig(kind="copy", params={
            "dest": str(dest_dir), "on_conflict": "overwrite"
        })
        action_copy(src_dir, config, dry_run=False)

        assert (dest_dir / "data" / "new.txt").read_text() == "new"
        assert not (dest_dir / "data" / "old.txt").exists()


# -- Unzip action --


class TestUnzipAction:
    def test_extracts_zip(self, tmp_path):
        zp = _make_zip(tmp_path / "archive.zip", {
            "readme.txt": "hello",
            "data/values.csv": "a,b,c",
        })

        config = ActionConfig(kind="unzip", params={"dest": str(tmp_path / "out")})
        result = action_unzip(zp, config, dry_run=False)

        assert result == tmp_path / "out" / "archive"
        assert (tmp_path / "out" / "archive" / "readme.txt").read_text() == "hello"
        assert (tmp_path / "out" / "archive" / "data" / "values.csv").read_text() == "a,b,c"

    def test_extracts_to_parent_by_default(self, tmp_path):
        zp = _make_zip(tmp_path / "stuff.zip", {"file.txt": "content"})

        config = ActionConfig(kind="unzip", params={})
        result = action_unzip(zp, config, dry_run=False)

        assert result == tmp_path / "stuff"
        assert (tmp_path / "stuff" / "file.txt").read_text() == "content"

    def test_skips_non_zip(self, tmp_path):
        txt = _write_file(tmp_path / "not_a_zip.txt")

        config = ActionConfig(kind="unzip", params={})
        result = action_unzip(txt, config, dry_run=False)

        assert result == txt

    def test_skips_directory(self, tmp_path):
        d = tmp_path / "somedir"
        d.mkdir()

        config = ActionConfig(kind="unzip", params={})
        result = action_unzip(d, config, dry_run=False)

        assert result == d

    def test_handles_bad_zip(self, tmp_path):
        bad = tmp_path / "bad.zip"
        bad.write_text("this is not a zip file")

        config = ActionConfig(kind="unzip", params={})
        result = action_unzip(bad, config, dry_run=False)

        assert result is None

    def test_dry_run(self, tmp_path):
        zp = _make_zip(tmp_path / "test.zip", {"a.txt": "data"})

        config = ActionConfig(kind="unzip", params={"dest": str(tmp_path / "out")})
        result = action_unzip(zp, config, dry_run=True)

        assert result == tmp_path / "out" / "test"
        assert not (tmp_path / "out").exists()


# -- Shell action --


class TestShellAction:
    def test_runs_command(self, tmp_path):
        target = tmp_path / "file.txt"
        output = tmp_path / "output.txt"
        _write_file(target)

        cmd = f"echo 'processed' > {output}"
        config = ActionConfig(kind="shell", params={"command": cmd})
        result = action_shell(target, config, dry_run=False)

        assert result == target
        assert output.read_text().strip() == "processed"

    def test_path_substitution(self, tmp_path):
        target = _write_file(tmp_path / "mydir" / "song.mp3", "audio")
        output = tmp_path / "result.txt"

        cmd = f'echo "{{path}} {{name}} {{stem}} {{dir}}" > {output}'
        config = ActionConfig(kind="shell", params={"command": cmd})
        action_shell(target, config, dry_run=False)

        parts = output.read_text().strip().split()
        assert parts[0] == str(target)
        assert parts[1] == "song.mp3"
        assert parts[2] == "song"
        assert parts[3] == str(target.parent)

    def test_dry_run(self, tmp_path):
        target = _write_file(tmp_path / "file.txt")
        marker = tmp_path / "marker.txt"

        cmd = f"touch {marker}"
        config = ActionConfig(kind="shell", params={"command": cmd})
        result = action_shell(target, config, dry_run=True)

        assert result == target
        assert not marker.exists()

    def test_missing_command(self, tmp_path):
        target = _write_file(tmp_path / "file.txt")

        config = ActionConfig(kind="shell", params={})
        result = action_shell(target, config, dry_run=False)

        assert result == target

    def test_failed_command(self, tmp_path):
        target = _write_file(tmp_path / "file.txt")

        config = ActionConfig(kind="shell", params={"command": "false"})
        result = action_shell(target, config, dry_run=False)

        # Should still return path even on failure
        assert result == target

    def test_uses_dest_as_command_fallback(self, tmp_path):
        """The shell action checks 'dest' key first, then 'command'."""
        target = _write_file(tmp_path / "file.txt")
        marker = tmp_path / "marker.txt"

        config = ActionConfig(kind="shell", params={"dest": f"touch {marker}"})
        action_shell(target, config, dry_run=False)

        assert marker.exists()
