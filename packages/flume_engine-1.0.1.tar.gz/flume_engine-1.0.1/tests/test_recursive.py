"""Tests for recursive watch/scan functionality."""

from pathlib import Path

from flume.config import FlumeConfig, RuleConfig, MatchConfig, ActionConfig
from flume.engine import Engine
from flume.matcher import scan_directory


class TestScanDirectoryRecursive:
    """Test scan_directory with recursive=True/False."""

    def test_non_recursive_skips_subdirs(self, tmp_path):
        """Non-recursive scan should only find top-level files."""
        (tmp_path / "top.txt").write_text("top")
        sub = tmp_path / "subdir"
        sub.mkdir()
        (sub / "nested.txt").write_text("nested")

        config = MatchConfig(pattern="*.txt", type="file")
        results = scan_directory(tmp_path, config, recursive=False)

        names = [p.name for p in results]
        assert "top.txt" in names
        assert "nested.txt" not in names

    def test_recursive_finds_nested_files(self, tmp_path):
        """Recursive scan should find files in subdirectories."""
        (tmp_path / "top.txt").write_text("top")
        sub = tmp_path / "subdir"
        sub.mkdir()
        (sub / "nested.txt").write_text("nested")
        deep = sub / "deep"
        deep.mkdir()
        (deep / "deep.txt").write_text("deep")

        config = MatchConfig(pattern="*.txt", type="file")
        results = scan_directory(tmp_path, config, recursive=True)

        names = [p.name for p in results]
        assert "top.txt" in names
        assert "nested.txt" in names
        assert "deep.txt" in names

    def test_recursive_default_is_false(self, tmp_path):
        """scan_directory defaults to non-recursive."""
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "hidden.txt").write_text("hidden")
        (tmp_path / "visible.txt").write_text("visible")

        config = MatchConfig(pattern="*.txt", type="file")
        results = scan_directory(tmp_path, config)

        names = [p.name for p in results]
        assert "visible.txt" in names
        assert "hidden.txt" not in names

    def test_recursive_respects_match_criteria(self, tmp_path):
        """Recursive scan still applies match filters."""
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "readme.md").write_text("markdown")
        (sub / "data.txt").write_text("text")

        config = MatchConfig(pattern="*.txt", type="file")
        results = scan_directory(tmp_path, config, recursive=True)

        names = [p.name for p in results]
        assert "data.txt" in names
        assert "readme.md" not in names


class TestRuleConfigRecursive:
    """Test that RuleConfig parses the recursive field."""

    def test_recursive_default_false(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": "*.txt",
            "actions": [{"move": "/tmp/out"}],
        })
        assert rule.recursive is False

    def test_recursive_true(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": "*.txt",
            "actions": [{"move": "/tmp/out"}],
            "recursive": True,
        })
        assert rule.recursive is True

    def test_recursive_false_explicit(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": "*.txt",
            "actions": [{"move": "/tmp/out"}],
            "recursive": False,
        })
        assert rule.recursive is False


class TestEngineRecursive:
    """Test that Engine.run_once respects recursive flag."""

    def test_run_once_recursive(self, tmp_path):
        """Engine should match files in subdirs when recursive is set."""
        dest = tmp_path / "dest"
        dest.mkdir()

        watch_dir = tmp_path / "watch"
        watch_dir.mkdir()
        sub = watch_dir / "sub"
        sub.mkdir()
        (sub / "file.txt").write_text("content")

        cfg = FlumeConfig.from_dict({
            "rules": [{
                "name": "recursive-copy",
                "watch": str(watch_dir),
                "match": {"pattern": "*.txt", "type": "file"},
                "actions": [{"copy": str(dest)}],
                "recursive": True,
            }]
        })
        engine = Engine(cfg, dry_run=True)
        stats = engine.run_once()
        assert stats.total_matched == 1

    def test_run_once_non_recursive(self, tmp_path):
        """Engine should skip subdirs when recursive is not set."""
        dest = tmp_path / "dest"
        dest.mkdir()

        watch_dir = tmp_path / "watch"
        watch_dir.mkdir()
        sub = watch_dir / "sub"
        sub.mkdir()
        (sub / "file.txt").write_text("content")

        cfg = FlumeConfig.from_dict({
            "rules": [{
                "name": "flat-copy",
                "watch": str(watch_dir),
                "match": {"pattern": "*.txt", "type": "file"},
                "actions": [{"copy": str(dest)}],
                "recursive": False,
            }]
        })
        engine = Engine(cfg, dry_run=True)
        stats = engine.run_once()
        assert stats.total_matched == 0
