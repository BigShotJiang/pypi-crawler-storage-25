"""Tests for log rotation and configurable log file path."""

import logging
import logging.handlers
import os

import pytest

from flume.log import (
    get_logger,
    setup_file_logging,
    DEFAULT_MAX_BYTES,
    DEFAULT_BACKUP_COUNT,
    _file_handler,
)
from flume.config import FlumeConfig


@pytest.fixture(autouse=True)
def _reset_logger():
    """Remove file handlers between tests."""
    import flume.log as log_mod
    yield
    logger = logging.getLogger("flume")
    if log_mod._file_handler is not None:
        logger.removeHandler(log_mod._file_handler)
        log_mod._file_handler.close()
        log_mod._file_handler = None


class TestSetupFileLogging:
    def test_creates_log_file(self, tmp_path):
        log_file = str(tmp_path / "flume.log")
        setup_file_logging(log_file)
        logger = get_logger()
        logger.info("test message")
        assert os.path.exists(log_file)
        with open(log_file) as f:
            content = f.read()
        assert "test message" in content

    def test_creates_parent_directories(self, tmp_path):
        log_file = str(tmp_path / "subdir" / "deep" / "flume.log")
        setup_file_logging(log_file)
        logger = get_logger()
        logger.info("nested log")
        assert os.path.exists(log_file)

    def test_uses_rotating_handler_by_default(self, tmp_path):
        import flume.log as log_mod
        log_file = str(tmp_path / "flume.log")
        setup_file_logging(log_file)
        assert isinstance(log_mod._file_handler, logging.handlers.RotatingFileHandler)
        assert log_mod._file_handler.maxBytes == DEFAULT_MAX_BYTES
        assert log_mod._file_handler.backupCount == DEFAULT_BACKUP_COUNT

    def test_rotation_disabled_when_max_bytes_zero(self, tmp_path):
        import flume.log as log_mod
        log_file = str(tmp_path / "flume.log")
        setup_file_logging(log_file, max_bytes=0)
        assert isinstance(log_mod._file_handler, logging.FileHandler)
        assert not isinstance(log_mod._file_handler, logging.handlers.RotatingFileHandler)

    def test_custom_rotation_params(self, tmp_path):
        import flume.log as log_mod
        log_file = str(tmp_path / "flume.log")
        setup_file_logging(log_file, max_bytes=1024, backup_count=5)
        handler = log_mod._file_handler
        assert isinstance(handler, logging.handlers.RotatingFileHandler)
        assert handler.maxBytes == 1024
        assert handler.backupCount == 5

    def test_reconfigure_replaces_handler(self, tmp_path):
        import flume.log as log_mod
        log_a = str(tmp_path / "a.log")
        log_b = str(tmp_path / "b.log")
        setup_file_logging(log_a)
        first_handler = log_mod._file_handler
        setup_file_logging(log_b)
        second_handler = log_mod._file_handler

        assert first_handler is not second_handler
        # First handler should no longer be in the logger
        logger = get_logger()
        assert first_handler not in logger.handlers
        assert second_handler in logger.handlers

    def test_log_level_respected(self, tmp_path):
        log_file = str(tmp_path / "flume.log")
        setup_file_logging(log_file, level="WARNING")
        logger = get_logger()
        logger.info("should not appear")
        logger.warning("should appear")
        with open(log_file) as f:
            content = f.read()
        assert "should not appear" not in content
        assert "should appear" in content

    def test_rotation_creates_backup_files(self, tmp_path):
        log_file = str(tmp_path / "flume.log")
        # Small max_bytes to force rotation quickly
        setup_file_logging(log_file, max_bytes=200, backup_count=2)
        logger = get_logger()
        for i in range(50):
            logger.info(f"line {i} - padding to force rotation over the limit")

        # Check that at least one backup was created
        files = os.listdir(tmp_path)
        log_files = [f for f in files if f.startswith("flume.log")]
        assert len(log_files) > 1, f"Expected backup files, got: {log_files}"


class TestFlumeConfigLogOptions:
    def test_defaults(self):
        cfg = FlumeConfig.from_dict({"rules": []})
        assert cfg.log_file is None
        assert cfg.log_level == "INFO"
        assert cfg.log_max_bytes == 5 * 1024 * 1024
        assert cfg.log_backup_count == 3

    def test_custom_values(self):
        cfg = FlumeConfig.from_dict({
            "rules": [],
            "log_file": "/var/log/flume.log",
            "log_level": "DEBUG",
            "log_max_bytes": 1048576,
            "log_backup_count": 5,
        })
        assert cfg.log_file == "/var/log/flume.log"
        assert cfg.log_level == "DEBUG"
        assert cfg.log_max_bytes == 1048576
        assert cfg.log_backup_count == 5

    def test_zero_max_bytes_disables_rotation(self):
        cfg = FlumeConfig.from_dict({
            "rules": [],
            "log_file": "flume.log",
            "log_max_bytes": 0,
        })
        assert cfg.log_max_bytes == 0
