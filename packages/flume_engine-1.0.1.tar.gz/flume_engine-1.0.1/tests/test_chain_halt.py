"""Tests for action chain halting when an action returns None."""

from pathlib import Path
from unittest.mock import MagicMock, call

import pytest

from flume.config import FlumeConfig, RuleConfig, MatchConfig, ActionConfig
from flume.engine import Engine


def _write_file(path: Path, content: str = "test content") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return path


class TestChainHalt:
    """Engine._execute_actions stops the chain when an action returns None."""

    def test_none_halts_chain(self, tmp_path, monkeypatch):
        """When an action returns None, subsequent actions must not run."""
        from flume import engine as engine_mod

        calls = []

        def action_first(path, config, dry_run):
            calls.append("first")
            return None  # signals halt

        def action_second(path, config, dry_run):
            calls.append("second")
            return path

        monkeypatch.setattr(
            engine_mod, "get_action",
            lambda kind: {"halt": action_first, "pass": action_second}.get(kind),
        )

        rule = RuleConfig(
            name="chain-test",
            watch=str(tmp_path),
            match=MatchConfig(pattern="*"),
            actions=[
                ActionConfig(kind="halt", params={}),
                ActionConfig(kind="pass", params={}),
            ],
        )
        cfg = FlumeConfig(rules=[rule])
        engine = Engine(cfg, dry_run=False)

        f = _write_file(tmp_path / "file.txt")
        count = engine._execute_actions(rule, f)

        assert count == 1
        assert calls == ["first"]

    def test_path_return_continues_chain(self, tmp_path, monkeypatch):
        """When an action returns a Path, subsequent actions run with that path."""
        from flume import engine as engine_mod

        received_paths = []
        new_path = tmp_path / "new.txt"

        def action_first(path, config, dry_run):
            return new_path

        def action_second(path, config, dry_run):
            received_paths.append(path)
            return path

        monkeypatch.setattr(
            engine_mod, "get_action",
            lambda kind: {"remap": action_first, "check": action_second}.get(kind),
        )

        rule = RuleConfig(
            name="chain-continue",
            watch=str(tmp_path),
            match=MatchConfig(pattern="*"),
            actions=[
                ActionConfig(kind="remap", params={}),
                ActionConfig(kind="check", params={}),
            ],
        )
        cfg = FlumeConfig(rules=[rule])
        engine = Engine(cfg, dry_run=False)

        f = _write_file(tmp_path / "file.txt")
        count = engine._execute_actions(rule, f)

        assert count == 2
        assert received_paths == [new_path]

    def test_none_mid_chain_stops_remaining(self, tmp_path, monkeypatch):
        """None returned from the second of three actions stops the third."""
        from flume import engine as engine_mod

        calls = []

        def action_a(path, config, dry_run):
            calls.append("a")
            return path

        def action_b(path, config, dry_run):
            calls.append("b")
            return None

        def action_c(path, config, dry_run):
            calls.append("c")
            return path

        monkeypatch.setattr(
            engine_mod, "get_action",
            lambda kind: {"a": action_a, "b": action_b, "c": action_c}.get(kind),
        )

        rule = RuleConfig(
            name="mid-halt",
            watch=str(tmp_path),
            match=MatchConfig(pattern="*"),
            actions=[
                ActionConfig(kind="a", params={}),
                ActionConfig(kind="b", params={}),
                ActionConfig(kind="c", params={}),
            ],
        )
        cfg = FlumeConfig(rules=[rule])
        engine = Engine(cfg, dry_run=False)

        f = _write_file(tmp_path / "file.txt")
        count = engine._execute_actions(rule, f)

        assert count == 2
        assert calls == ["a", "b"]

    def test_dedup_skip_halts_move(self, tmp_path):
        """Integration: dedup(on_duplicate=skip) prevents subsequent move."""
        # Set up a file and a duplicate in a search directory
        search_dir = tmp_path / "library"
        search_dir.mkdir()
        (search_dir / "existing.txt").write_text("duplicate content")

        watch_dir = tmp_path / "incoming"
        watch_dir.mkdir()
        incoming = watch_dir / "new.txt"
        incoming.write_text("duplicate content")

        dest_dir = tmp_path / "processed"

        rule = RuleConfig(
            name="dedup-then-move",
            watch=str(watch_dir),
            match=MatchConfig(pattern="*.txt"),
            actions=[
                ActionConfig(kind="dedup", params={
                    "dirs": [str(search_dir)],
                    "on_duplicate": "skip",
                }),
                ActionConfig(kind="move", params={"dest": str(dest_dir)}),
            ],
        )
        cfg = FlumeConfig(rules=[rule])
        engine = Engine(cfg, dry_run=False)
        report = engine.run_once()

        # The file should NOT have been moved
        assert incoming.exists(), "Duplicate file should remain in incoming (not moved)"
        assert not (dest_dir / "new.txt").exists(), "File should not appear in dest"

        # Only the dedup action ran, move was skipped
        rule_report = report.rules[0]
        assert rule_report.actions_run == 1
