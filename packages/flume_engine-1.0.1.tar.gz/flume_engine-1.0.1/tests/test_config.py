"""Tests for config loading."""

import tempfile
from pathlib import Path

from flume.config import load_config, FlumeConfig, RuleConfig, ActionConfig, MatchConfig, _coerce_bool
from flume.actions import list_actions


def test_load_basic_config():
    yaml_content = """\
rules:
  - name: test-rule
    watch: /tmp
    match:
      pattern: "*.txt"
    actions:
      - move: ~/Documents/
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write(yaml_content)
        f.flush()
        config = load_config(Path(f.name))

    assert config is not None
    assert len(config.rules) == 1
    assert config.rules[0].name == "test-rule"
    assert config.rules[0].match.pattern == "*.txt"
    assert len(config.rules[0].actions) == 1
    assert config.rules[0].actions[0].kind == "move"


def test_action_from_dict_string():
    action = ActionConfig.from_dict({"move": "/tmp/dest"})
    assert action.kind == "move"
    assert action.params["dest"] == "/tmp/dest"


def test_action_from_dict_nested():
    action = ActionConfig.from_dict({"unzip": {"dest": "/tmp/out"}})
    assert action.kind == "unzip"
    assert action.params["dest"] == "/tmp/out"


def test_action_from_dict_bool():
    action = ActionConfig.from_dict({"trash-original": True})
    assert action.kind == "trash-original"
    assert action.params["enabled"] is True


def test_match_from_string():
    match = MatchConfig.from_dict("*.zip")
    assert match.pattern == "*.zip"
    assert match.type == "file"


def test_match_from_dict():
    match = MatchConfig.from_dict({"pattern": "*.flac", "type": "file", "min_size": 1024})
    assert match.pattern == "*.flac"
    assert match.min_size == 1024


def test_empty_config():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("")
        f.flush()
        config = load_config(Path(f.name))

    assert config is not None
    assert len(config.rules) == 0


def test_missing_config():
    config = load_config(Path("/nonexistent/path/rules.yaml"))
    assert config is None


class TestConfigIncludes:
    """Tests for the include directive in config files."""

    def test_include_single_file(self, tmp_path):
        # Create an included file with one rule
        inc_file = tmp_path / "extra.yaml"
        inc_file.write_text(
            "rules:\n"
            "  - name: included-rule\n"
            "    watch: /tmp\n"
            "    match: '*.log'\n"
            "    actions:\n"
            "      - trash-original: true\n"
        )

        # Main config includes it
        main_file = tmp_path / "rules.yaml"
        main_file.write_text(
            "include:\n"
            "  - extra.yaml\n"
            "rules:\n"
            "  - name: main-rule\n"
            "    watch: /tmp\n"
            "    match: '*.txt'\n"
            "    actions:\n"
            "      - move: /tmp/dest\n"
        )

        config = load_config(main_file)
        assert config is not None
        assert len(config.rules) == 2
        names = [r.name for r in config.rules]
        assert "included-rule" in names
        assert "main-rule" in names

    def test_include_glob_pattern(self, tmp_path):
        rules_d = tmp_path / "rules.d"
        rules_d.mkdir()

        for i in range(3):
            (rules_d / f"rule{i}.yaml").write_text(
                f"rules:\n"
                f"  - name: glob-rule-{i}\n"
                f"    watch: /tmp\n"
                f"    match: '*.dat'\n"
                f"    actions:\n"
                f"      - trash-original: true\n"
            )

        main_file = tmp_path / "rules.yaml"
        main_file.write_text(
            "include:\n"
            "  - 'rules.d/*.yaml'\n"
            "rules: []\n"
        )

        config = load_config(main_file)
        assert config is not None
        assert len(config.rules) == 3

    def test_include_missing_file_ignored(self, tmp_path):
        main_file = tmp_path / "rules.yaml"
        main_file.write_text(
            "include:\n"
            "  - nonexistent.yaml\n"
            "rules:\n"
            "  - name: only-rule\n"
            "    watch: /tmp\n"
            "    match: '*.txt'\n"
            "    actions:\n"
            "      - move: /tmp/out\n"
        )

        config = load_config(main_file)
        assert config is not None
        assert len(config.rules) == 1
        assert config.rules[0].name == "only-rule"

    def test_include_circular_reference(self, tmp_path):
        file_a = tmp_path / "a.yaml"
        file_b = tmp_path / "b.yaml"

        file_a.write_text(
            "include:\n"
            "  - b.yaml\n"
            "rules:\n"
            "  - name: rule-a\n"
            "    watch: /tmp\n"
            "    match: '*.a'\n"
            "    actions:\n"
            "      - trash-original: true\n"
        )
        file_b.write_text(
            "include:\n"
            "  - a.yaml\n"
            "rules:\n"
            "  - name: rule-b\n"
            "    watch: /tmp\n"
            "    match: '*.b'\n"
            "    actions:\n"
            "      - trash-original: true\n"
        )

        config = load_config(file_a)
        assert config is not None
        names = [r.name for r in config.rules]
        assert "rule-a" in names
        assert "rule-b" in names
        # No infinite loop -- each file appears exactly once
        assert len(config.rules) == 2

    def test_include_nested(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()

        leaf = sub / "leaf.yaml"
        leaf.write_text(
            "rules:\n"
            "  - name: leaf-rule\n"
            "    watch: /tmp\n"
            "    match: '*.leaf'\n"
            "    actions:\n"
            "      - trash-original: true\n"
        )

        mid = tmp_path / "mid.yaml"
        mid.write_text(
            "include:\n"
            "  - sub/leaf.yaml\n"
            "rules:\n"
            "  - name: mid-rule\n"
            "    watch: /tmp\n"
            "    match: '*.mid'\n"
            "    actions:\n"
            "      - trash-original: true\n"
        )

        main = tmp_path / "main.yaml"
        main.write_text(
            "include:\n"
            "  - mid.yaml\n"
            "rules: []\n"
        )

        config = load_config(main)
        assert config is not None
        names = [r.name for r in config.rules]
        assert "leaf-rule" in names
        assert "mid-rule" in names
        assert len(config.rules) == 2

    def test_include_string_form(self, tmp_path):
        inc = tmp_path / "extra.yaml"
        inc.write_text(
            "rules:\n"
            "  - name: single-include\n"
            "    watch: /tmp\n"
            "    match: '*.x'\n"
            "    actions:\n"
            "      - trash-original: true\n"
        )

        main = tmp_path / "rules.yaml"
        main.write_text(
            "include: extra.yaml\n"
            "rules: []\n"
        )

        config = load_config(main)
        assert config is not None
        assert len(config.rules) == 1
        assert config.rules[0].name == "single-include"

    def test_include_empty_file(self, tmp_path):
        inc = tmp_path / "empty.yaml"
        inc.write_text("")

        main = tmp_path / "rules.yaml"
        main.write_text(
            "include:\n"
            "  - empty.yaml\n"
            "rules:\n"
            "  - name: main-only\n"
            "    watch: /tmp\n"
            "    match: '*.txt'\n"
            "    actions:\n"
            "      - move: /tmp/out\n"
        )

        config = load_config(main)
        assert config is not None
        assert len(config.rules) == 1


class TestActionValidation:
    """Tests for unknown action detection in config validation."""

    def test_valid_actions_pass(self, tmp_path):
        known = set(list_actions())
        rule = RuleConfig(
            name="good-rule",
            watch=str(tmp_path),
            match=MatchConfig(),
            actions=[ActionConfig(kind="move", params={"dest": "/tmp"})],
        )
        errors = rule.validate(known_actions=known)
        action_errors = [e for e in errors if "unknown action" in e]
        assert action_errors == []

    def test_unknown_action_detected(self, tmp_path):
        known = set(list_actions())
        rule = RuleConfig(
            name="bad-rule",
            watch=str(tmp_path),
            match=MatchConfig(),
            actions=[ActionConfig(kind="mve", params={"dest": "/tmp"})],
        )
        errors = rule.validate(known_actions=known)
        action_errors = [e for e in errors if "unknown action" in e]
        assert len(action_errors) == 1
        assert "'mve'" in action_errors[0]

    def test_multiple_unknown_actions(self, tmp_path):
        known = set(list_actions())
        rule = RuleConfig(
            name="multi-bad",
            watch=str(tmp_path),
            match=MatchConfig(),
            actions=[
                ActionConfig(kind="mve", params={}),
                ActionConfig(kind="move", params={"dest": "/tmp"}),
                ActionConfig(kind="yeet", params={}),
            ],
        )
        errors = rule.validate(known_actions=known)
        action_errors = [e for e in errors if "unknown action" in e]
        assert len(action_errors) == 2

    def test_validation_without_known_actions_skips_check(self, tmp_path):
        """When known_actions is None, no action name validation occurs."""
        rule = RuleConfig(
            name="no-check",
            watch=str(tmp_path),
            match=MatchConfig(),
            actions=[ActionConfig(kind="nonexistent", params={})],
        )
        errors = rule.validate(known_actions=None)
        action_errors = [e for e in errors if "unknown action" in e]
        assert action_errors == []

    def test_flume_config_validate_with_known_actions(self, tmp_path):
        known = set(list_actions())
        config = FlumeConfig(
            rules=[
                RuleConfig(
                    name="good",
                    watch=str(tmp_path),
                    match=MatchConfig(),
                    actions=[ActionConfig(kind="move", params={"dest": "/tmp"})],
                ),
                RuleConfig(
                    name="bad",
                    watch=str(tmp_path),
                    match=MatchConfig(),
                    actions=[ActionConfig(kind="fake-action", params={})],
                ),
            ]
        )
        errors = config.validate(known_actions=known)
        action_errors = [e for e in errors if "unknown action" in e]
        assert len(action_errors) == 1
        assert "'fake-action'" in action_errors[0]


# --- _coerce_bool and quoted-string YAML handling (MF-33) ---


class TestCoerceBool:
    """Verify _coerce_bool handles YAML quoted-string edge cases."""

    def test_true_values(self):
        assert _coerce_bool(True) is True
        assert _coerce_bool(1) is True
        assert _coerce_bool("true") is True
        assert _coerce_bool("True") is True
        assert _coerce_bool("yes") is True
        assert _coerce_bool("on") is True
        assert _coerce_bool("1") is True
        assert _coerce_bool("anything") is True

    def test_false_values(self):
        assert _coerce_bool(False) is False
        assert _coerce_bool(0) is False
        assert _coerce_bool("false") is False
        assert _coerce_bool("False") is False
        assert _coerce_bool("FALSE") is False
        assert _coerce_bool("no") is False
        assert _coerce_bool("off") is False
        assert _coerce_bool("0") is False
        assert _coerce_bool("none") is False
        assert _coerce_bool("") is False

    def test_none_uses_default(self):
        assert _coerce_bool(None, default=True) is True
        assert _coerce_bool(None, default=False) is False

    def test_whitespace_stripped(self):
        assert _coerce_bool(" false ") is False
        assert _coerce_bool(" true ") is True


class TestQuotedBoolYAML:
    """Ensure RuleConfig and FlumeConfig handle quoted booleans from YAML."""

    def test_rule_enabled_quoted_false(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": {"pattern": "*.txt"},
            "actions": [{"move": "/tmp/dest"}],
            "enabled": "false",
        })
        assert rule.enabled is False

    def test_rule_enabled_quoted_true(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": {"pattern": "*.txt"},
            "actions": [{"move": "/tmp/dest"}],
            "enabled": "true",
        })
        assert rule.enabled is True

    def test_rule_recursive_quoted_false(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": {"pattern": "*.txt"},
            "actions": [{"move": "/tmp/dest"}],
            "recursive": "false",
        })
        assert rule.recursive is False

    def test_rule_recursive_quoted_true(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": {"pattern": "*.txt"},
            "actions": [{"move": "/tmp/dest"}],
            "recursive": "true",
        })
        assert rule.recursive is True

    def test_groups_quoted_false(self):
        config = FlumeConfig.from_dict({
            "rules": [],
            "groups": {"work": "false", "personal": "true"},
        })
        assert config.groups["work"] is False
        assert config.groups["personal"] is True

    def test_rule_enabled_default_true_when_omitted(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": {"pattern": "*.txt"},
            "actions": [{"move": "/tmp/dest"}],
        })
        assert rule.enabled is True

    def test_rule_recursive_default_false_when_omitted(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": {"pattern": "*.txt"},
            "actions": [{"move": "/tmp/dest"}],
        })
        assert rule.recursive is False
