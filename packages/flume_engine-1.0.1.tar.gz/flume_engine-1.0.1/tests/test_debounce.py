"""Tests for watch event debounce/cooldown functionality."""

import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from flume.config import RuleConfig, MatchConfig, ActionConfig
from flume.engine import _RuleEventHandler, Engine


def _make_rule(debounce=1.0, on="created"):
    """Create a minimal RuleConfig for testing."""
    return RuleConfig(
        name="test-debounce",
        watch="/tmp",
        match=MatchConfig(pattern="*.txt", type="file"),
        actions=[ActionConfig(kind="move", params={"dest": "/tmp/out"})],
        on=on,
        debounce=debounce,
    )


def _make_event(src_path, is_directory=False):
    """Create a mock filesystem event."""
    event = MagicMock()
    event.src_path = str(src_path)
    event.is_directory = is_directory
    return event


@pytest.fixture(autouse=True)
def _patch_matches():
    """Patch matches() so it checks only the glob pattern, not the filesystem.

    Also patches Path.exists to return True by default so tests using fake
    paths (e.g. /tmp/test.txt) pass the debounce-fire existence check.
    Tests that need real filesystem behavior should use tmp_path and create
    actual files.
    """
    import fnmatch

    _real_exists = Path.exists

    def fake_matches(path, config):
        if config.pattern and config.pattern != "*":
            return fnmatch.fnmatch(path.name, config.pattern)
        return True

    def fake_exists(self):
        # Use real filesystem check first; only return True for synthetic
        # paths that were never created on disk (like /tmp/test.txt).
        real = _real_exists(self)
        if real:
            return True
        # Synthetic short paths used in most tests (e.g. /tmp/test.txt)
        # don't exist on disk -- pretend they do so debounce tests pass.
        parts = Path(self).parts
        if len(parts) == 3 and parts[0] == "/" and parts[1] == "tmp":
            return True
        return False

    with patch("flume.engine.matches", side_effect=fake_matches), \
         patch.object(Path, "exists", fake_exists):
        yield


class TestRuleConfigDebounce:
    """Test that RuleConfig parses the debounce field."""

    def test_debounce_default(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": "*.txt",
            "actions": [{"move": "/tmp/out"}],
        })
        assert rule.debounce == 1.0

    def test_debounce_custom(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": "*.txt",
            "actions": [{"move": "/tmp/out"}],
            "debounce": 2.5,
        })
        assert rule.debounce == 2.5

    def test_debounce_zero_disables(self):
        rule = RuleConfig.from_dict({
            "name": "test",
            "watch": "/tmp",
            "match": "*.txt",
            "actions": [{"move": "/tmp/out"}],
            "debounce": 0,
        })
        assert rule.debounce == 0.0


class TestDebounceHandler:
    """Test _RuleEventHandler debounce behavior."""

    def test_single_event_fires_after_delay(self):
        """A single event should fire after the debounce window."""
        rule = _make_rule(debounce=0.1)
        engine = MagicMock(spec=Engine)
        handler = _RuleEventHandler(engine, rule)

        event = _make_event("/tmp/test.txt")
        handler.on_created(event)

        # Should not have fired yet
        engine._execute_actions.assert_not_called()

        # Wait for debounce to expire
        time.sleep(0.25)
        engine._execute_actions.assert_called_once()
        call_args = engine._execute_actions.call_args
        assert call_args[0][0] is rule
        assert call_args[0][1] == Path("/tmp/test.txt")

    def test_rapid_events_coalesce(self):
        """Multiple rapid events for the same file should coalesce into one."""
        rule = _make_rule(debounce=0.2)
        engine = MagicMock(spec=Engine)
        handler = _RuleEventHandler(engine, rule)

        event = _make_event("/tmp/test.txt")

        # Fire 5 rapid events
        for _ in range(5):
            handler.on_created(event)
            time.sleep(0.03)

        # Wait for debounce to settle
        time.sleep(0.4)

        # Should only have fired once
        assert engine._execute_actions.call_count == 1

    def test_different_files_independent(self):
        """Events for different files should debounce independently."""
        rule = _make_rule(debounce=0.1)
        engine = MagicMock(spec=Engine)
        handler = _RuleEventHandler(engine, rule)

        handler.on_created(_make_event("/tmp/a.txt"))
        handler.on_created(_make_event("/tmp/b.txt"))

        time.sleep(0.25)

        assert engine._execute_actions.call_count == 2

    def test_zero_debounce_fires_immediately(self):
        """With debounce=0, events should fire immediately without delay."""
        rule = _make_rule(debounce=0)
        engine = MagicMock(spec=Engine)
        handler = _RuleEventHandler(engine, rule)

        handler.on_created(_make_event("/tmp/test.txt"))

        # Should fire immediately, no timer
        engine._execute_actions.assert_called_once()

    def test_zero_debounce_no_coalescing(self):
        """With debounce=0, each event fires independently."""
        rule = _make_rule(debounce=0)
        engine = MagicMock(spec=Engine)
        handler = _RuleEventHandler(engine, rule)

        for _ in range(3):
            handler.on_created(_make_event("/tmp/test.txt"))

        assert engine._execute_actions.call_count == 3

    def test_non_matching_file_ignored(self):
        """Events for non-matching files should not fire at all."""
        rule = _make_rule(debounce=0.1)
        engine = MagicMock(spec=Engine)
        handler = _RuleEventHandler(engine, rule)

        handler.on_created(_make_event("/tmp/test.jpg"))

        time.sleep(0.25)
        engine._execute_actions.assert_not_called()

    def test_wrong_event_type_ignored(self):
        """Events that don't match the rule's 'on' field are ignored."""
        rule = _make_rule(debounce=0.1, on="modified")
        engine = MagicMock(spec=Engine)
        handler = _RuleEventHandler(engine, rule)

        handler.on_created(_make_event("/tmp/test.txt"))

        time.sleep(0.25)
        engine._execute_actions.assert_not_called()

    def test_spaced_events_fire_separately(self):
        """Events spaced beyond the debounce window should each fire."""
        rule = _make_rule(debounce=0.1)
        engine = MagicMock(spec=Engine)
        handler = _RuleEventHandler(engine, rule)

        handler.on_created(_make_event("/tmp/test.txt"))
        time.sleep(0.25)  # First fires

        handler.on_created(_make_event("/tmp/test.txt"))
        time.sleep(0.25)  # Second fires

        assert engine._execute_actions.call_count == 2

    def test_vanished_file_skipped(self, tmp_path):
        """If a file disappears before the debounce timer fires, skip it."""
        rule = _make_rule(debounce=0.1)
        engine = MagicMock(spec=Engine)
        handler = _RuleEventHandler(engine, rule)

        # Create a real file, trigger the event, then delete it
        f = tmp_path / "gone.txt"
        f.write_text("temporary")
        handler.on_created(_make_event(str(f)))
        f.unlink()

        time.sleep(0.25)
        engine._execute_actions.assert_not_called()

    def test_action_exception_does_not_crash_timer(self):
        """An exception from _execute_actions should be caught, not crash."""
        rule = _make_rule(debounce=0.1)
        engine = MagicMock(spec=Engine)
        engine._execute_actions.side_effect = FileNotFoundError("vanished")
        handler = _RuleEventHandler(engine, rule)

        handler.on_created(_make_event("/tmp/test.txt"))
        time.sleep(0.25)

        # The action was called (path "exists" since matches is mocked)
        engine._execute_actions.assert_called_once()
        # No unhandled exception -- the test itself would fail if the
        # exception escaped the timer thread and was re-raised.
