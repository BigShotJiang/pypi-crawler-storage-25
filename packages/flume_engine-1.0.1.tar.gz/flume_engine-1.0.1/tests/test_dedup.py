"""Tests for the dedup action."""

import os
import pytest
from pathlib import Path

from flume.actions.dedup import action_dedup, _file_hash, _find_duplicates
from flume.config import ActionConfig


@pytest.fixture
def dedup_dirs(tmp_path):
    """Create a temp structure with source and search directories."""
    source = tmp_path / "incoming"
    search_a = tmp_path / "library_a"
    search_b = tmp_path / "library_b"
    source.mkdir()
    search_a.mkdir()
    search_b.mkdir()
    return source, search_a, search_b


def _write_file(path: Path, content: str) -> Path:
    path.write_text(content)
    return path


class TestFileHash:
    def test_identical_content_same_hash(self, tmp_path):
        f1 = _write_file(tmp_path / "a.txt", "hello world")
        f2 = _write_file(tmp_path / "b.txt", "hello world")
        assert _file_hash(f1) == _file_hash(f2)

    def test_different_content_different_hash(self, tmp_path):
        f1 = _write_file(tmp_path / "a.txt", "hello")
        f2 = _write_file(tmp_path / "b.txt", "world")
        assert _file_hash(f1) != _file_hash(f2)

    def test_empty_files_same_hash(self, tmp_path):
        f1 = _write_file(tmp_path / "a.txt", "")
        f2 = _write_file(tmp_path / "b.txt", "")
        assert _file_hash(f1) == _file_hash(f2)


class TestFindDuplicates:
    def test_finds_duplicate_in_search_dir(self, dedup_dirs):
        source, search_a, _ = dedup_dirs
        incoming = _write_file(source / "new.txt", "duplicate content")
        _write_file(search_a / "existing.txt", "duplicate content")

        dupes = _find_duplicates(incoming, [str(search_a)])
        assert len(dupes) == 1
        assert dupes[0].name == "existing.txt"

    def test_no_duplicates(self, dedup_dirs):
        source, search_a, _ = dedup_dirs
        incoming = _write_file(source / "new.txt", "unique content")
        _write_file(search_a / "other.txt", "different content")

        dupes = _find_duplicates(incoming, [str(search_a)])
        assert len(dupes) == 0

    def test_searches_multiple_dirs(self, dedup_dirs):
        source, search_a, search_b = dedup_dirs
        incoming = _write_file(source / "new.txt", "shared content")
        _write_file(search_a / "copy_a.txt", "shared content")
        _write_file(search_b / "copy_b.txt", "shared content")

        dupes = _find_duplicates(incoming, [str(search_a), str(search_b)])
        assert len(dupes) == 2

    def test_skips_self(self, dedup_dirs):
        source, _, _ = dedup_dirs
        incoming = _write_file(source / "file.txt", "content")

        # Search the same directory -- should not find itself
        dupes = _find_duplicates(incoming, [str(source)])
        assert len(dupes) == 0

    def test_skips_different_size(self, dedup_dirs):
        source, search_a, _ = dedup_dirs
        incoming = _write_file(source / "new.txt", "short")
        _write_file(search_a / "long.txt", "this is much longer content")

        dupes = _find_duplicates(incoming, [str(search_a)])
        assert len(dupes) == 0

    def test_missing_search_dir(self, dedup_dirs):
        source, _, _ = dedup_dirs
        incoming = _write_file(source / "new.txt", "content")

        # Non-existent dir should be skipped gracefully
        dupes = _find_duplicates(incoming, ["/tmp/nonexistent_flume_test_dir"])
        assert len(dupes) == 0


class TestDedupAction:
    def test_report_mode_returns_path(self, dedup_dirs):
        source, search_a, _ = dedup_dirs
        incoming = _write_file(source / "new.txt", "duplicate")
        _write_file(search_a / "existing.txt", "duplicate")

        config = ActionConfig(kind="dedup", params={
            "dirs": [str(search_a)],
            "on_duplicate": "report",
        })

        result = action_dedup(incoming, config, dry_run=False)
        assert result == incoming  # report mode continues the chain

    def test_skip_mode_returns_none(self, dedup_dirs):
        source, search_a, _ = dedup_dirs
        incoming = _write_file(source / "new.txt", "duplicate")
        _write_file(search_a / "existing.txt", "duplicate")

        config = ActionConfig(kind="dedup", params={
            "dirs": [str(search_a)],
            "on_duplicate": "skip",
        })

        result = action_dedup(incoming, config, dry_run=False)
        assert result is None

    def test_trash_mode_removes_file(self, dedup_dirs):
        source, search_a, _ = dedup_dirs
        incoming = _write_file(source / "new.txt", "duplicate")
        _write_file(search_a / "existing.txt", "duplicate")

        config = ActionConfig(kind="dedup", params={
            "dirs": [str(search_a)],
            "on_duplicate": "trash",
        })

        result = action_dedup(incoming, config, dry_run=False)
        # File should be trashed (removed from original location)
        assert result is None
        assert not incoming.exists()

    def test_no_duplicate_continues_chain(self, dedup_dirs):
        source, search_a, _ = dedup_dirs
        incoming = _write_file(source / "unique.txt", "unique content")
        _write_file(search_a / "other.txt", "different")

        config = ActionConfig(kind="dedup", params={
            "dirs": [str(search_a)],
            "on_duplicate": "trash",
        })

        result = action_dedup(incoming, config, dry_run=False)
        assert result == incoming
        assert incoming.exists()

    def test_dry_run_does_not_trash(self, dedup_dirs):
        source, search_a, _ = dedup_dirs
        incoming = _write_file(source / "new.txt", "duplicate")
        _write_file(search_a / "existing.txt", "duplicate")

        config = ActionConfig(kind="dedup", params={
            "dirs": [str(search_a)],
            "on_duplicate": "trash",
        })

        result = action_dedup(incoming, config, dry_run=True)
        assert result == incoming  # dry run preserves file
        assert incoming.exists()

    def test_no_dirs_returns_path(self, dedup_dirs):
        source, _, _ = dedup_dirs
        incoming = _write_file(source / "file.txt", "content")

        config = ActionConfig(kind="dedup", params={})
        result = action_dedup(incoming, config, dry_run=False)
        assert result == incoming

    def test_directory_is_skipped(self, dedup_dirs):
        source, search_a, _ = dedup_dirs
        subdir = source / "subdir"
        subdir.mkdir()

        config = ActionConfig(kind="dedup", params={
            "dirs": [str(search_a)],
        })

        result = action_dedup(subdir, config, dry_run=False)
        assert result == subdir
