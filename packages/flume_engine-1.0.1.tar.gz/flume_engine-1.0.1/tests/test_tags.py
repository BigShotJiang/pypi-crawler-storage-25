"""Tests for tag-based rule groups."""

import tempfile
from pathlib import Path

from flume.config import FlumeConfig, RuleConfig, MatchConfig, ActionConfig, load_config
from flume.engine import Engine


def _rule(name, tags=None, enabled=True):
    """Helper to build a minimal RuleConfig with a real watch directory."""
    return RuleConfig(
        name=name,
        watch=tempfile.mkdtemp(),
        match=MatchConfig(),
        actions=[ActionConfig(kind="move", params={"dest": "/tmp"})],
        tags=tags or [],
        enabled=enabled,
    )


# -- Config parsing --


def test_tags_parsed_from_config_dict():
    """Rule tags are correctly parsed from a config dict."""
    data = {
        "name": "tagged-rule",
        "watch": "/tmp",
        "match": "*.txt",
        "actions": [{"move": "/tmp/dest"}],
        "tags": ["work", "invoices"],
    }
    rule = RuleConfig.from_dict(data)
    assert rule.tags == ["work", "invoices"]


def test_tags_default_empty():
    """Rules without tags get an empty list."""
    data = {
        "name": "no-tags",
        "watch": "/tmp",
        "match": "*.txt",
        "actions": [{"move": "/tmp/dest"}],
    }
    rule = RuleConfig.from_dict(data)
    assert rule.tags == []


def test_single_tag_string_parsed():
    """A single tag as a string (not list) is accepted."""
    data = {
        "name": "single-tag",
        "watch": "/tmp",
        "match": "*.txt",
        "actions": [{"move": "/tmp/dest"}],
        "tags": "work",
    }
    rule = RuleConfig.from_dict(data)
    assert rule.tags == ["work"]


def test_groups_parsed_from_config():
    """Groups dict is parsed from top-level YAML config."""
    data = {
        "rules": [],
        "groups": {"work": True, "personal": False},
    }
    cfg = FlumeConfig.from_dict(data)
    assert cfg.groups == {"work": True, "personal": False}


def test_groups_default_empty():
    """Config without groups gets an empty dict."""
    data = {"rules": []}
    cfg = FlumeConfig.from_dict(data)
    assert cfg.groups == {}


def test_groups_from_yaml():
    """Full round-trip: groups parsed from YAML file."""
    yaml_content = """\
groups:
  work: true
  personal: false

rules:
  - name: work-rule
    watch: /tmp
    match: "*.txt"
    tags: [work]
    actions:
      - move: /tmp/dest

  - name: personal-rule
    watch: /tmp
    match: "*.jpg"
    tags: [personal]
    actions:
      - move: /tmp/photos
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write(yaml_content)
        f.flush()
        cfg = load_config(Path(f.name))

    assert cfg is not None
    assert cfg.groups == {"work": True, "personal": False}
    assert cfg.rules[0].tags == ["work"]
    assert cfg.rules[1].tags == ["personal"]


# -- effective_rules filtering --


def test_no_groups_returns_all_enabled():
    """With no groups configured, all enabled rules are returned."""
    cfg = FlumeConfig(rules=[
        _rule("a"),
        _rule("b", tags=["work"]),
        _rule("c", enabled=False),
    ])
    result = cfg.effective_rules()
    names = [r.name for r in result]
    assert names == ["a", "b"]


def test_disabled_group_skips_tagged_rules():
    """Rules with a disabled tag in groups are excluded."""
    cfg = FlumeConfig(
        rules=[
            _rule("work-rule", tags=["work"]),
            _rule("personal-rule", tags=["personal"]),
            _rule("untagged"),
        ],
        groups={"personal": False},
    )
    result = cfg.effective_rules()
    names = [r.name for r in result]
    assert "work-rule" in names
    assert "untagged" in names
    assert "personal-rule" not in names


def test_untagged_rules_always_included():
    """Rules with no tags are never affected by groups."""
    cfg = FlumeConfig(
        rules=[_rule("plain")],
        groups={"work": False, "personal": False},
    )
    result = cfg.effective_rules()
    assert len(result) == 1
    assert result[0].name == "plain"


def test_enable_tags_overrides_disabled_group():
    """CLI --enable-tags re-enables a group that config disabled."""
    cfg = FlumeConfig(
        rules=[
            _rule("personal-rule", tags=["personal"]),
            _rule("untagged"),
        ],
        groups={"personal": False},
    )
    result = cfg.effective_rules(enable_tags={"personal"})
    names = [r.name for r in result]
    assert "personal-rule" in names
    assert "untagged" in names


def test_disable_tags_overrides_enabled_group():
    """CLI --disable-tags disables a group even if config says enabled."""
    cfg = FlumeConfig(
        rules=[
            _rule("work-rule", tags=["work"]),
            _rule("untagged"),
        ],
        groups={"work": True},
    )
    result = cfg.effective_rules(disable_tags={"work"})
    names = [r.name for r in result]
    assert "work-rule" not in names
    assert "untagged" in names


def test_disable_tags_beats_enable_tags():
    """When the same tag is in both enable and disable, disable wins."""
    cfg = FlumeConfig(
        rules=[_rule("conflict-rule", tags=["both"])],
    )
    result = cfg.effective_rules(
        enable_tags={"both"},
        disable_tags={"both"},
    )
    assert len(result) == 0


def test_multiple_tags_disabled_if_any_disabled():
    """A rule with multiple tags is skipped if ANY tag is disabled."""
    cfg = FlumeConfig(
        rules=[_rule("multi", tags=["work", "urgent"])],
        groups={"work": True, "urgent": False},
    )
    result = cfg.effective_rules()
    assert len(result) == 0


def test_multiple_tags_all_enabled():
    """A rule with multiple tags is included when all tags are enabled."""
    cfg = FlumeConfig(
        rules=[_rule("multi", tags=["work", "urgent"])],
        groups={"work": True, "urgent": True},
    )
    result = cfg.effective_rules()
    assert len(result) == 1


def test_multiple_tags_enable_overrides_one_disabled():
    """enable_tags can rescue a rule even if one of its tags is disabled in groups."""
    cfg = FlumeConfig(
        rules=[_rule("multi", tags=["work", "urgent"])],
        groups={"work": True, "urgent": False},
    )
    result = cfg.effective_rules(enable_tags={"urgent"})
    assert len(result) == 1


def test_tags_with_unknown_group():
    """Tags not mentioned in groups are treated as enabled (no restriction)."""
    cfg = FlumeConfig(
        rules=[_rule("mystery", tags=["unknown-tag"])],
        groups={"work": True},
    )
    result = cfg.effective_rules()
    assert len(result) == 1


def test_disabled_rule_excluded_even_with_matching_enable_tags():
    """enabled=False always takes precedence, even with matching enable_tags."""
    cfg = FlumeConfig(
        rules=[_rule("off", tags=["work"], enabled=False)],
        groups={"work": True},
    )
    result = cfg.effective_rules(enable_tags={"work"})
    assert len(result) == 0


# -- Engine integration --


def test_engine_uses_effective_rules():
    """Engine stores only the effective (filtered) rules."""
    cfg = FlumeConfig(
        rules=[
            _rule("included", tags=["work"]),
            _rule("excluded", tags=["personal"]),
            _rule("untagged"),
        ],
        groups={"personal": False},
    )
    engine = Engine(cfg)
    names = [r.name for r in engine.rules]
    assert "included" in names
    assert "untagged" in names
    assert "excluded" not in names


def test_engine_with_enable_tags():
    """Engine passes enable_tags through to effective_rules."""
    cfg = FlumeConfig(
        rules=[_rule("restored", tags=["personal"])],
        groups={"personal": False},
    )
    engine = Engine(cfg, enable_tags={"personal"})
    assert len(engine.rules) == 1
    assert engine.rules[0].name == "restored"


def test_engine_with_disable_tags():
    """Engine passes disable_tags through to effective_rules."""
    cfg = FlumeConfig(
        rules=[_rule("blocked", tags=["work"])],
    )
    engine = Engine(cfg, disable_tags={"work"})
    assert len(engine.rules) == 0


def test_engine_run_once_respects_tags():
    """Engine.run_once only processes rules that pass tag filtering."""
    watch_dir = tempfile.mkdtemp()
    # Create a file that would match
    test_file = Path(watch_dir) / "test.txt"
    test_file.write_text("hello")

    cfg = FlumeConfig(
        rules=[
            RuleConfig(
                name="active",
                watch=watch_dir,
                match=MatchConfig(pattern="*.txt"),
                actions=[],
                tags=["work"],
            ),
            RuleConfig(
                name="inactive",
                watch=watch_dir,
                match=MatchConfig(pattern="*.txt"),
                actions=[],
                tags=["personal"],
            ),
        ],
        groups={"personal": False},
    )

    engine = Engine(cfg)
    # Only "active" should be in engine.rules
    assert len(engine.rules) == 1
    assert engine.rules[0].name == "active"

    stats = engine.run_once()
    # "active" has no actions but matches the file
    assert stats.total_matched == 1
    assert stats.total_actions == 0
