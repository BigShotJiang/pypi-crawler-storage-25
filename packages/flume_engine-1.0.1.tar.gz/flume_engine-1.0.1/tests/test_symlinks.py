"""Tests for symlink handling in matcher."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from flume.config import MatchConfig, RuleConfig, ActionConfig
from flume.matcher import matches, scan_directory


@pytest.fixture
def symlink_dir(tmp_path: Path) -> Path:
    """Create a temp directory with a regular file and a symlink to it."""
    real_file = tmp_path / "real.txt"
    real_file.write_text("hello")

    link = tmp_path / "link.txt"
    link.symlink_to(real_file)

    return tmp_path


class TestSymlinkFollow:
    """Default behavior: symlinks are followed normally."""

    def test_symlink_matches_with_follow(self, symlink_dir: Path):
        config = MatchConfig(pattern="*.txt", symlinks="follow")
        link = symlink_dir / "link.txt"
        assert matches(link, config) is True

    def test_real_file_matches_with_follow(self, symlink_dir: Path):
        config = MatchConfig(pattern="*.txt", symlinks="follow")
        real = symlink_dir / "real.txt"
        assert matches(real, config) is True

    def test_scan_includes_symlinks_with_follow(self, symlink_dir: Path):
        config = MatchConfig(pattern="*.txt", symlinks="follow")
        results = scan_directory(symlink_dir, config)
        names = {p.name for p in results}
        assert "link.txt" in names
        assert "real.txt" in names


class TestSymlinkSkip:
    """Skip mode: symlinks are silently excluded."""

    def test_symlink_skipped(self, symlink_dir: Path):
        config = MatchConfig(pattern="*.txt", symlinks="skip")
        link = symlink_dir / "link.txt"
        assert matches(link, config) is False

    def test_real_file_still_matches(self, symlink_dir: Path):
        config = MatchConfig(pattern="*.txt", symlinks="skip")
        real = symlink_dir / "real.txt"
        assert matches(real, config) is True

    def test_scan_excludes_symlinks(self, symlink_dir: Path):
        config = MatchConfig(pattern="*.txt", symlinks="skip")
        results = scan_directory(symlink_dir, config)
        names = {p.name for p in results}
        assert "link.txt" not in names
        assert "real.txt" in names


class TestSymlinkReject:
    """Reject mode: symlinks are excluded and a warning is logged."""

    def test_symlink_rejected(self, symlink_dir: Path):
        config = MatchConfig(pattern="*.txt", symlinks="reject")
        link = symlink_dir / "link.txt"
        assert matches(link, config) is False

    def test_real_file_still_matches(self, symlink_dir: Path):
        config = MatchConfig(pattern="*.txt", symlinks="reject")
        real = symlink_dir / "real.txt"
        assert matches(real, config) is True

    def test_reject_logs_warning(self, symlink_dir: Path, caplog):
        config = MatchConfig(pattern="*.txt", symlinks="reject")
        link = symlink_dir / "link.txt"
        with caplog.at_level("WARNING"):
            matches(link, config)
        assert any("Rejecting symlink" in msg for msg in caplog.messages)


class TestSymlinkConfig:
    """Config parsing and validation for symlinks field."""

    def test_default_is_follow(self):
        config = MatchConfig.from_dict({"pattern": "*.txt"})
        assert config.symlinks == "follow"

    def test_parses_skip(self):
        config = MatchConfig.from_dict({"pattern": "*.txt", "symlinks": "skip"})
        assert config.symlinks == "skip"

    def test_parses_reject(self):
        config = MatchConfig.from_dict({"pattern": "*.txt", "symlinks": "reject"})
        assert config.symlinks == "reject"

    def test_invalid_symlinks_value_fails_validation(self, tmp_path: Path):
        rule = RuleConfig(
            name="test",
            watch=str(tmp_path),
            match=MatchConfig(pattern="*", symlinks="bogus"),
            actions=[ActionConfig(kind="trash")],
        )
        errors = rule.validate()
        assert any("symlinks" in e for e in errors)


class TestSymlinkEdgeCases:
    """Edge cases: broken symlinks, directory symlinks."""

    def test_broken_symlink_skip(self, tmp_path: Path):
        broken = tmp_path / "broken.txt"
        broken.symlink_to(tmp_path / "nonexistent.txt")
        config = MatchConfig(pattern="*.txt", symlinks="skip")
        assert matches(broken, config) is False

    def test_broken_symlink_follow(self, tmp_path: Path):
        broken = tmp_path / "broken.txt"
        broken.symlink_to(tmp_path / "nonexistent.txt")
        config = MatchConfig(pattern="*.txt", type="file", symlinks="follow")
        # Broken symlink is not a file, so type check should fail
        assert matches(broken, config) is False

    def test_directory_symlink_skip(self, tmp_path: Path):
        real_dir = tmp_path / "real_dir"
        real_dir.mkdir()
        link_dir = tmp_path / "link_dir"
        link_dir.symlink_to(real_dir)
        config = MatchConfig(pattern="*", type="directory", symlinks="skip")
        assert matches(link_dir, config) is False

    def test_directory_symlink_follow(self, tmp_path: Path):
        real_dir = tmp_path / "real_dir"
        real_dir.mkdir()
        link_dir = tmp_path / "link_dir"
        link_dir.symlink_to(real_dir)
        config = MatchConfig(pattern="*", type="directory", symlinks="follow")
        assert matches(link_dir, config) is True
