"""Tests for confirm (interactive) mode."""

import shutil
from pathlib import Path

import pytest

from flume.config import FlumeConfig, RuleConfig, MatchConfig, ActionConfig
from flume.engine import Engine


@pytest.fixture
def workspace(tmp_path):
    """Create a workspace with a source dir, dest dir, and a test file."""
    src = tmp_path / "src"
    src.mkdir()
    dest = tmp_path / "dest"
    dest.mkdir()
    (src / "hello.txt").write_text("hello")
    return tmp_path


def _make_config(workspace):
    src = workspace / "src"
    dest = workspace / "dest"
    rule = RuleConfig(
        name="move-txt",
        watch=str(src),
        match=MatchConfig(pattern="*.txt"),
        actions=[ActionConfig(kind="move", params={"dest": str(dest)})],
    )
    return FlumeConfig(rules=[rule])


def test_confirm_yes_executes(workspace, monkeypatch):
    """When user answers 'y', the action runs."""
    monkeypatch.setattr("builtins.input", lambda _: "y")
    cfg = _make_config(workspace)
    engine = Engine(cfg, confirm=True)
    stats = engine.run_once()

    assert stats.total_actions == 1
    assert (workspace / "dest" / "hello.txt").exists()
    assert not (workspace / "src" / "hello.txt").exists()


def test_confirm_no_skips(workspace, monkeypatch):
    """When user answers 'n', the action is skipped."""
    monkeypatch.setattr("builtins.input", lambda _: "n")
    cfg = _make_config(workspace)
    engine = Engine(cfg, confirm=True)
    stats = engine.run_once()

    assert stats.total_actions == 0
    assert (workspace / "src" / "hello.txt").exists()
    assert not (workspace / "dest" / "hello.txt").exists()


def test_confirm_all_disables_further_prompts(workspace, monkeypatch):
    """When user answers 'a', confirm mode is disabled for the rest of the run."""
    # Create a second file so there are two matches
    (workspace / "src" / "second.txt").write_text("second")

    call_count = 0

    def fake_input(prompt):
        nonlocal call_count
        call_count += 1
        return "a"  # "all" on first prompt

    monkeypatch.setattr("builtins.input", fake_input)
    cfg = _make_config(workspace)
    engine = Engine(cfg, confirm=True)
    stats = engine.run_once()

    # 'a' should have been asked only once; second file processed without prompt
    assert call_count == 1
    assert stats.total_actions == 2
    assert (workspace / "dest" / "hello.txt").exists()
    assert (workspace / "dest" / "second.txt").exists()


def test_confirm_eof_skips(workspace, monkeypatch):
    """When input raises EOFError, the action is skipped."""
    def raise_eof(prompt):
        raise EOFError

    monkeypatch.setattr("builtins.input", raise_eof)
    cfg = _make_config(workspace)
    engine = Engine(cfg, confirm=True)
    stats = engine.run_once()

    assert stats.total_actions == 0
    assert (workspace / "src" / "hello.txt").exists()


def test_no_confirm_runs_normally(workspace):
    """Without confirm mode, actions run without prompting."""
    cfg = _make_config(workspace)
    engine = Engine(cfg, confirm=False)
    stats = engine.run_once()

    assert stats.total_actions == 1
    assert (workspace / "dest" / "hello.txt").exists()
