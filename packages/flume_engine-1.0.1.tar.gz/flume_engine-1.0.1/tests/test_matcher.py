"""Tests for the matcher module."""

import os
import tempfile
import time
from pathlib import Path

from flume.config import MatchConfig
from flume.matcher import matches, scan_directory


def test_glob_match():
    with tempfile.NamedTemporaryFile(suffix=".zip") as f:
        path = Path(f.name)
        config = MatchConfig(pattern="*.zip")
        assert matches(path, config)


def test_glob_no_match():
    with tempfile.NamedTemporaryFile(suffix=".txt") as f:
        path = Path(f.name)
        config = MatchConfig(pattern="*.zip")
        assert not matches(path, config)


def test_type_file():
    with tempfile.NamedTemporaryFile() as f:
        path = Path(f.name)
        assert matches(path, MatchConfig(type="file"))
        assert not matches(path, MatchConfig(type="directory"))


def test_type_directory():
    with tempfile.TemporaryDirectory() as d:
        path = Path(d)
        assert matches(path, MatchConfig(type="directory"))
        assert not matches(path, MatchConfig(type="file"))


def test_type_any():
    with tempfile.NamedTemporaryFile() as f:
        assert matches(Path(f.name), MatchConfig(type="any"))
    with tempfile.TemporaryDirectory() as d:
        assert matches(Path(d), MatchConfig(type="any"))


def test_scan_directory():
    with tempfile.TemporaryDirectory() as d:
        (Path(d) / "a.zip").touch()
        (Path(d) / "b.zip").touch()
        (Path(d) / "c.txt").touch()

        results = scan_directory(Path(d), MatchConfig(pattern="*.zip"))
        names = [r.name for r in results]
        assert names == ["a.zip", "b.zip"]


def test_regex_match():
    with tempfile.NamedTemporaryFile(suffix=".flac", prefix="track_01_") as f:
        path = Path(f.name)
        config = MatchConfig(regex=r"track_\d+_")
        assert matches(path, config)


def test_size_filter():
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"x" * 100)
        f.flush()
        path = Path(f.name)
        assert matches(path, MatchConfig(min_size=50))
        assert not matches(path, MatchConfig(min_size=200))
        assert matches(path, MatchConfig(max_size=200))
        assert not matches(path, MatchConfig(max_size=50))


def test_older_than():
    with tempfile.NamedTemporaryFile() as f:
        path = Path(f.name)
        # File just created -- should be newer than 1 day
        assert not matches(path, MatchConfig(older_than=1))
        # Backdate the file mtime by 3 days
        old_time = time.time() - (3 * 86400)
        os.utime(f.name, (old_time, old_time))
        assert matches(path, MatchConfig(older_than=2))
        assert not matches(path, MatchConfig(older_than=5))


def test_newer_than():
    with tempfile.NamedTemporaryFile() as f:
        path = Path(f.name)
        # File just created -- should be newer than 1 day
        assert matches(path, MatchConfig(newer_than=1))
        # Backdate the file mtime by 3 days
        old_time = time.time() - (3 * 86400)
        os.utime(f.name, (old_time, old_time))
        assert not matches(path, MatchConfig(newer_than=2))
        assert matches(path, MatchConfig(newer_than=5))


def test_older_and_newer_combined():
    """File between 2 and 5 days old should match both constraints."""
    with tempfile.NamedTemporaryFile() as f:
        path = Path(f.name)
        # Set mtime to 3 days ago
        t = time.time() - (3 * 86400)
        os.utime(f.name, (t, t))
        config = MatchConfig(older_than=2, newer_than=5)
        assert matches(path, config)
        # File 1 day old should fail older_than=2
        t2 = time.time() - (1 * 86400)
        os.utime(f.name, (t2, t2))
        assert not matches(path, config)


def test_age_with_directory():
    with tempfile.TemporaryDirectory() as d:
        path = Path(d)
        # Just created, should be newer than 1 day
        assert matches(path, MatchConfig(type="directory", newer_than=1))
        assert not matches(path, MatchConfig(type="directory", older_than=1))


def test_content_match():
    """Files matching a content regex should pass."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("hello world\nfoo bar\nTODO: fix this\n")
        f.flush()
        path = Path(f.name)
    try:
        assert matches(path, MatchConfig(content=r"TODO"))
        assert matches(path, MatchConfig(content=r"foo\s+bar"))
        assert not matches(path, MatchConfig(content=r"FIXME"))
    finally:
        path.unlink()


def test_content_no_match():
    """Content filter on a file without matching text."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("all clear\nnothing to see\n")
        f.flush()
        path = Path(f.name)
    try:
        assert not matches(path, MatchConfig(content=r"ERROR"))
    finally:
        path.unlink()


def test_content_skips_directories():
    """Content matching should reject directories."""
    with tempfile.TemporaryDirectory() as d:
        path = Path(d)
        assert not matches(path, MatchConfig(type="any", content=r"anything"))


def test_content_combined_with_glob():
    """Content + glob pattern work together."""
    with tempfile.TemporaryDirectory() as d:
        good = Path(d) / "notes.txt"
        good.write_text("TODO: finish feature\n")
        bad_name = Path(d) / "notes.log"
        bad_name.write_text("TODO: finish feature\n")
        bad_content = Path(d) / "readme.txt"
        bad_content.write_text("all done\n")

        config = MatchConfig(pattern="*.txt", content=r"TODO")
        results = scan_directory(Path(d), config)
        assert [r.name for r in results] == ["notes.txt"]


def test_exclude_glob():
    """Files matching the exclude glob should be rejected."""
    with tempfile.TemporaryDirectory() as d:
        keep = Path(d) / "report.pdf"
        keep.touch()
        skip = Path(d) / "report.tmp"
        skip.touch()

        config = MatchConfig(pattern="report.*", exclude="*.tmp")
        results = scan_directory(Path(d), config)
        assert [r.name for r in results] == ["report.pdf"]


def test_exclude_glob_no_false_positive():
    """Exclude should not affect files that do not match it."""
    with tempfile.NamedTemporaryFile(suffix=".txt") as f:
        path = Path(f.name)
        config = MatchConfig(exclude="*.log")
        assert matches(path, config)


def test_exclude_regex():
    """Files matching the exclude regex should be rejected."""
    with tempfile.TemporaryDirectory() as d:
        good = Path(d) / "data_final.csv"
        good.touch()
        bad = Path(d) / "data_backup_20240101.csv"
        bad.touch()

        config = MatchConfig(pattern="*.csv", exclude_regex=r"_backup_\d+")
        results = scan_directory(Path(d), config)
        assert [r.name for r in results] == ["data_final.csv"]


def test_exclude_regex_no_false_positive():
    """Exclude regex should not reject non-matching files."""
    with tempfile.NamedTemporaryFile(suffix=".txt", prefix="notes_") as f:
        path = Path(f.name)
        config = MatchConfig(exclude_regex=r"_backup_")
        assert matches(path, config)


def test_exclude_combined_with_content():
    """Exclude and content filters work together."""
    with tempfile.TemporaryDirectory() as d:
        wanted = Path(d) / "app.log"
        wanted.write_text("ERROR: something broke\n")
        excluded = Path(d) / "app.log.bak"
        excluded.write_text("ERROR: old issue\n")

        config = MatchConfig(pattern="*", exclude="*.bak", content=r"ERROR")
        results = scan_directory(Path(d), config)
        assert [r.name for r in results] == ["app.log"]


def test_content_binary_file_no_crash():
    """Binary files should not crash the content matcher."""
    with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as f:
        f.write(bytes(range(256)) * 100)
        f.flush()
        path = Path(f.name)
    try:
        # Should not raise, just return False (or True if pattern matches replacement chars)
        matches(path, MatchConfig(content=r"NEEDLE"))
    finally:
        path.unlink()


def test_scan_directory_permission_error(tmp_path):
    """scan_directory skips unreadable subdirectories instead of crashing."""
    readable = tmp_path / "ok"
    readable.mkdir()
    (readable / "data.txt").write_text("hello")

    forbidden = tmp_path / "nope"
    forbidden.mkdir()
    (forbidden / "secret.txt").write_text("hidden")
    forbidden.chmod(0o000)

    try:
        results = scan_directory(tmp_path, MatchConfig(pattern="*.txt"), recursive=True)
        names = [r.name for r in results]
        assert "data.txt" in names
        assert "secret.txt" not in names
    finally:
        # Restore permissions so cleanup can remove the dir
        forbidden.chmod(0o755)


def test_scan_directory_unreadable_root(tmp_path):
    """scan_directory handles an unreadable root directory gracefully."""
    target = tmp_path / "locked"
    target.mkdir()
    (target / "file.txt").touch()
    target.chmod(0o000)

    try:
        results = scan_directory(target, MatchConfig(pattern="*.txt"))
        assert results == []
    finally:
        target.chmod(0o755)
