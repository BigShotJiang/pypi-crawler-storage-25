"""Tests for --verbose and --quiet CLI flags."""

import logging

from click.testing import CliRunner

from flume.cli import main
from flume import log


def _get_console_level():
    """Get the current console handler level."""
    return log._console_handler.level if log._console_handler else None


def test_verbose_sets_debug_level(tmp_path):
    """--verbose should set console handler to DEBUG."""
    config = tmp_path / "rules.yaml"
    config.write_text("rules: []\n")
    runner = CliRunner()
    result = runner.invoke(main, ["--verbose", "run", "-c", str(config)])
    assert result.exit_code == 0
    assert _get_console_level() == logging.DEBUG


def test_quiet_sets_error_level(tmp_path):
    """--quiet should set console handler to ERROR."""
    config = tmp_path / "rules.yaml"
    config.write_text("rules: []\n")
    runner = CliRunner()
    result = runner.invoke(main, ["--quiet", "run", "-c", str(config)])
    assert result.exit_code == 0
    assert _get_console_level() == logging.ERROR


def test_verbose_and_quiet_mutually_exclusive():
    """--verbose and --quiet together should fail."""
    runner = CliRunner()
    result = runner.invoke(main, ["--verbose", "--quiet", "validate"])
    assert result.exit_code != 0
    output = result.output.lower()
    assert "mutually exclusive" in output


def test_quiet_suppresses_run_output(tmp_path):
    """--quiet should suppress the summary line from 'run'."""
    config = tmp_path / "rules.yaml"
    config.write_text("rules: []\n")
    runner = CliRunner()

    # Normal run should show output
    result = runner.invoke(main, ["run", "-c", str(config)])
    assert result.exit_code == 0
    assert "Done." in result.output

    # Quiet run should suppress it
    result = runner.invoke(main, ["--quiet", "run", "-c", str(config)])
    assert result.exit_code == 0
    assert "Done." not in result.output


def test_verbose_flag_in_help():
    """--verbose / -v should appear in help text."""
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert "--verbose" in result.output
    assert "-v" in result.output


def test_quiet_flag_in_help():
    """--quiet / -q should appear in help text."""
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert "--quiet" in result.output
    assert "-q" in result.output
