Constants
=========

.. automodule:: django_midtrans.constants
   :members:
   :undoc-members:
   :show-inheritance:

PaymentType
-----------

.. autoclass:: django_midtrans.constants.PaymentType
   :members:
   :undoc-members:

BankType
--------

.. autoclass:: django_midtrans.constants.BankType
   :members:
   :undoc-members:

TransactionStatus
-----------------

.. autoclass:: django_midtrans.constants.TransactionStatus
   :members:
   :undoc-members:

FraudStatus
-----------

.. autoclass:: django_midtrans.constants.FraudStatus
   :members:
   :undoc-members:

InvoiceStatus
-------------

.. autoclass:: django_midtrans.constants.InvoiceStatus
   :members:
   :undoc-members:

SubscriptionStatus
------------------

.. autoclass:: django_midtrans.constants.SubscriptionStatus
   :members:
   :undoc-members:

NotificationStatus
------------------

.. autoclass:: django_midtrans.constants.NotificationStatus
   :members:
   :undoc-members:
