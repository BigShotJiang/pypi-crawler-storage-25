Exceptions
==========

.. automodule:: django_midtrans.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

MidtransError
-------------

.. autoclass:: django_midtrans.exceptions.MidtransError
   :members:
   :undoc-members:

MidtransAPIError
----------------

.. autoclass:: django_midtrans.exceptions.MidtransAPIError
   :members:
   :undoc-members:
   :show-inheritance:

MidtransAuthenticationError
---------------------------

.. autoclass:: django_midtrans.exceptions.MidtransAuthenticationError
   :members:
   :undoc-members:
   :show-inheritance:

MidtransValidationError
-----------------------

.. autoclass:: django_midtrans.exceptions.MidtransValidationError
   :members:
   :undoc-members:
   :show-inheritance:

MidtransDuplicateOrderError
---------------------------

.. autoclass:: django_midtrans.exceptions.MidtransDuplicateOrderError
   :members:
   :undoc-members:
   :show-inheritance:

MidtransRateLimitError
----------------------

.. autoclass:: django_midtrans.exceptions.MidtransRateLimitError
   :members:
   :undoc-members:
   :show-inheritance:

MidtransSignatureError
----------------------

.. autoclass:: django_midtrans.exceptions.MidtransSignatureError
   :members:
   :undoc-members:
   :show-inheritance:
