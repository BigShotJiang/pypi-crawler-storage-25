"""Tests for the ClaimProcsClient resource."""

import json

import pytest
import responses
from pydantic import ValidationError

from opendental import OpenDentalClient
from opendental.resources.claim_procs import (
    ClaimProcsClient,
    InsAdjustRequest,
    InsAdjustResponse,
)

BASE_URL = "https://api.opendental.com/api/v1"
INS_ADJUST_URL = f"{BASE_URL}/claimprocs/InsAdjust"


class TestClaimProcsResource:
    """Test cases for ClaimProcsClient."""

    @pytest.fixture
    def client(self):
        return OpenDentalClient(
            developer_key="test_dev_key", customer_key="test_cust_key"
        )

    def test_client_registered(self, client):
        """ClaimProcsClient is reachable as client.claim_procs."""
        assert isinstance(client.claim_procs, ClaimProcsClient)

    @responses.activate
    def test_ins_adjust_success(self, client):
        """Happy-path PUT with alias-cased body and InsAdjustResponse return."""
        responses.add(responses.PUT, INS_ADJUST_URL, json={}, status=200)

        result = client.claim_procs.ins_adjust(
            pat_plan_num=12345,
            ins_used=500.00,
            deductible_used=50.00,
        )

        assert isinstance(result, InsAdjustResponse)
        assert len(responses.calls) == 1

        request = responses.calls[0].request
        assert request.method == "PUT"
        assert request.url == INS_ADJUST_URL

        body = json.loads(request.body)
        assert body == {
            "PatPlanNum": 12345,
            "insUsed": "500.00",
            "deductibleUsed": "50.00",
        }

    @responses.activate
    def test_ins_adjust_uses_api_alias_casing_only(self, client):
        """Wire body uses PascalCase aliases, not Python snake_case."""
        responses.add(responses.PUT, INS_ADJUST_URL, json={}, status=200)

        client.claim_procs.ins_adjust(
            pat_plan_num=1,
            ins_used=10.00,
            deductible_used=5.00,
        )

        body = json.loads(responses.calls[0].request.body)
        assert set(body.keys()) == {"PatPlanNum", "insUsed", "deductibleUsed"}
        assert "pat_plan_num" not in body
        assert "ins_used" not in body
        assert "deductible_used" not in body

    @responses.activate
    def test_ins_adjust_money_always_two_decimals(self, client):
        """Wire format is always .2f, regardless of caller-supplied precision.

        Guards against float-repr surprises (0.1 + 0.2 = 0.30000000000000004,
        scientific notation for very small amounts, bare integers dropped).
        """
        responses.add(responses.PUT, INS_ADJUST_URL, json={}, status=200)

        client.claim_procs.ins_adjust(
            pat_plan_num=1,
            ins_used=0.1 + 0.2,
            deductible_used=500,
        )

        body = json.loads(responses.calls[0].request.body)
        assert body["insUsed"] == "0.30"
        assert body["deductibleUsed"] == "500.00"

    @responses.activate
    def test_ins_adjust_empty_response_body(self, client):
        """Empty 200 body should return an InsAdjustResponse, not raise."""
        responses.add(responses.PUT, INS_ADJUST_URL, body="", status=200)

        result = client.claim_procs.ins_adjust(
            pat_plan_num=42,
            ins_used=0.00,
            deductible_used=0.00,
        )

        assert isinstance(result, InsAdjustResponse)

    def test_ins_adjust_rejects_positional_args(self, client):
        """Keyword-only signature: positional calls raise TypeError."""
        with pytest.raises(TypeError):
            client.claim_procs.ins_adjust(12345, 500.00, 50.00)

    def test_ins_adjust_requires_pat_plan_num(self, client):
        with pytest.raises(TypeError):
            client.claim_procs.ins_adjust(
                ins_used=500.00,
                deductible_used=50.00,
            )

    def test_ins_adjust_requires_ins_used(self, client):
        with pytest.raises(TypeError):
            client.claim_procs.ins_adjust(
                pat_plan_num=12345,
                deductible_used=50.00,
            )

    def test_ins_adjust_requires_deductible_used(self, client):
        with pytest.raises(TypeError):
            client.claim_procs.ins_adjust(
                pat_plan_num=12345,
                ins_used=500.00,
            )

    def test_ins_adjust_rejects_non_numeric(self, client):
        with pytest.raises(ValidationError):
            client.claim_procs.ins_adjust(
                pat_plan_num=12345,
                ins_used="not-a-number",
                deductible_used=50.00,
            )


class TestInsAdjustRequestModel:
    """Direct tests against the request model's serialization contract."""

    def test_serializes_with_api_aliases(self):
        request = InsAdjustRequest(
            pat_plan_num=12345,
            ins_used=500.00,
            deductible_used=50.00,
        )
        payload = request.model_dump(by_alias=True, exclude_none=True)
        assert payload == {
            "PatPlanNum": 12345,
            "insUsed": "500.00",
            "deductibleUsed": "50.00",
        }

    def test_accepts_input_by_alias(self):
        """populate_by_name=True lets callers pass PascalCase too."""
        request = InsAdjustRequest(
            PatPlanNum=12345,
            insUsed=500.00,
            deductibleUsed=50.00,
        )
        assert request.pat_plan_num == 12345
        assert request.ins_used == 500.00
        assert request.deductible_used == 50.00

    def test_all_fields_required(self):
        with pytest.raises(ValidationError):
            InsAdjustRequest(pat_plan_num=1, ins_used=1.00)
