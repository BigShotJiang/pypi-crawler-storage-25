"""Claim procedures client for Open Dental SDK."""

from ...base.resource import BaseResource
from ...exceptions import OpenDentalAPIError
from .models import InsAdjustRequest, InsAdjustResponse


class ClaimProcsClient(BaseResource):
    """Client for managing ClaimProcs in Open Dental."""

    def __init__(self, client):
        """Initialize the claim_procs client."""
        super().__init__(client, "claimprocs")

    def ins_adjust(
        self,
        *,
        pat_plan_num: int,
        ins_used: float,
        deductible_used: float,
    ) -> InsAdjustResponse:
        """Set target insurance/deductible used amounts on a patient-plan link.

        The server computes and writes the catch-up ClaimProc adjustment needed
        to reach these targets. Never construct manual Adjustment rows — this
        helper is the supported path.

        Keyword-only signature is intentional: the two dollar amounts are
        indistinguishable by type, so a positional call could silently swap
        insurance used and deductible used. Do not refactor to positional.
        """
        request = InsAdjustRequest(
            pat_plan_num=pat_plan_num,
            ins_used=ins_used,
            deductible_used=deductible_used,
        )
        endpoint = self._build_endpoint("InsAdjust")
        payload = request.model_dump(by_alias=True, exclude_none=True)
        response = self._put(endpoint, json_data=payload)
        if response is None:
            return InsAdjustResponse()
        if isinstance(response, dict):
            return InsAdjustResponse(**response)
        raise OpenDentalAPIError(
            f"Unexpected response from claimprocs/InsAdjust: {response!r}"
        )
