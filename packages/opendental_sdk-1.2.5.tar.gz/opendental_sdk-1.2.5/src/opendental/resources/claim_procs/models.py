"""Claim procedures models for Open Dental SDK."""

from pydantic import Field, field_serializer

from ...base.models import BaseModel


class InsAdjustRequest(BaseModel):
    """Request body for PUT /claimprocs/InsAdjust."""

    pat_plan_num: int = Field(
        ...,
        alias="PatPlanNum",
        description="Patient plan identifier; obtainable from FamilyModules GET Insurance.",
    )
    ins_used: float = Field(
        ...,
        alias="insUsed",
        description="Target total insurance used; server computes the catch-up adjustment.",
    )
    deductible_used: float = Field(
        ...,
        alias="deductibleUsed",
        description="Target total deductible used; server computes the catch-up adjustment.",
    )

    @field_serializer("ins_used", "deductible_used")
    def _serialize_money(self, value: float) -> str:
        """Format money as a 2-decimal string on the wire.

        The Open Dental API documents these fields as "String (decimal)" and
        its own examples show values like "500.00". Using :.2f avoids
        float-repr surprises like "0.30000000000000004" or "1e-05".
        """
        return f"{value:.2f}"


class InsAdjustResponse(BaseModel):
    """Response body for PUT /claimprocs/InsAdjust.

    The server does not document a response body for this endpoint, so extra
    fields are preserved verbatim if any are returned.
    """

    class Config:
        extra = "allow"
        populate_by_name = True
