"""CovSpan models for Open Dental SDK."""

from pydantic import Field

from ...base.models import BaseModel


class CovSpan(BaseModel):
    """CovSpan model representing a coverage category span for procedure codes."""

    cov_span_num: int = Field(..., alias="CovSpanNum", description="CovSpan ID (primary key)")
    cov_cat_num: int = Field(..., alias="CovCatNum", description="Foreign key to coverage category")
    from_code: str = Field(..., alias="FromCode", description="Starting procedure code")
    to_code: str = Field(..., alias="ToCode", description="Ending procedure code")

    class Config:
        populate_by_name = True
