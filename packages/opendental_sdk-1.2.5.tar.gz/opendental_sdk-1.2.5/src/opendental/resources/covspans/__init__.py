"""CovSpans resource module."""

from .client import CovSpansClient
from .models import CovSpan

__all__ = [
    "CovSpansClient",
    "CovSpan",
]
