"""CovSpans client for Open Dental SDK."""

from typing import Union, List, Optional, Dict, Any
from ...base.resource import BaseResource
from .models import CovSpan


class CovSpansClient(BaseResource):
    """Client for managing coverage spans in Open Dental."""

    def __init__(self, client):
        """Initialize the covspans client."""
        super().__init__(client, "covspans")

    def get(self, covspan_id: Union[int, str]) -> CovSpan:
        """
        Get a coverage span by ID.

        Args:
            covspan_id: The coverage span ID

        Returns:
            CovSpan: The coverage span object
        """
        covspan_id = self._validate_id(covspan_id)
        endpoint = self._build_endpoint(covspan_id)
        response = self._get(endpoint)
        return self._handle_response(response, CovSpan)

    def list(self, cov_cat_num: Optional[int] = None) -> List[CovSpan]:
        """
        List all coverage spans, optionally filtered by coverage category.

        Args:
            cov_cat_num: Optional coverage category number to filter by

        Returns:
            List[CovSpan]: List of coverage spans
        """
        params: Dict[str, Any] = {}
        if cov_cat_num is not None:
            params["CovCatNum"] = cov_cat_num

        endpoint = self._build_endpoint()
        response = self._get(endpoint, params=params)
        return self._handle_list_response(response, CovSpan)
