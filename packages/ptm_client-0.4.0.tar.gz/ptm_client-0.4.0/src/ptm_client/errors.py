"""PTM client error types."""

from __future__ import annotations


class PTMError(Exception):
    """Raised when a PTM API call fails."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class PTMTimeoutError(PTMError):
    """Raised when wait_for_run exceeds the timeout."""


class PTMResponseError(PTMError):
    """Raised when a PTM API call returns a non-JSON response unexpectedly.

    Typical causes: an upstream proxy (Cloudflare Access, a load balancer, a
    WAF) intercepted the request and replied with HTML instead of JSON.
    """


class CloudflareAccessError(PTMResponseError):
    """Raised when Cloudflare Access blocks a request and auto-recovery fails.

    The message always contains an actionable next step (install cloudflared /
    run `cloudflared access login <url>` / set service-token env vars).
    """


class PTMPermissionError(PTMError):
    """Raised on a 403 response from a PTM mutation endpoint.

    Typical causes: the caller is not the prompt owner, or (when Phase 15
    isolation is enabled on the org) the prompt is scoped to a group the
    caller is not a member of. Message names the action + path so callers
    can surface "You don't own prompt X" style errors to end users.
    """


class PTMNotFoundError(PTMError):
    """Raised on a 404 response. The resource id does not exist OR is outside
    the caller's visibility scope."""


class PTMConflictError(PTMError):
    """Raised on a 409 response. The write was rejected due to state conflict.

    Typical causes: the target prompt is repository-backed (edit the files in
    git, not via API), or another writer committed a version between this
    caller's read and write.
    """


class PTMValidationError(PTMError):
    """Raised on a 422 response. Input shape / sizes / types did not pass
    backend validation. Check field-level docs before retrying."""
