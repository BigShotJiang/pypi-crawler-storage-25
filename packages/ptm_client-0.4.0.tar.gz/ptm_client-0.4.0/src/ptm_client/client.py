"""
PTMClient - minimal PTM integration for external Python services.

Usage:
    from ptm_client import PTMClient

    client = PTMClient(base_url="http://localhost:8010", token="ptm_u_...")
    prompts = client.list_prompts(tag="my_team")
    run     = client.run_eval(prompt_ids=["my_team.summarizer"], provider_ids=["gpt-4o"])
    status  = client.wait_for_run(run["run_key"])
    html    = client.run_report(run["run_key"])
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import time
from typing import Any
from urllib.parse import quote

import requests

from ptm_client.errors import (
    CloudflareAccessError,
    PTMConflictError,
    PTMError,
    PTMNotFoundError,
    PTMPermissionError,
    PTMResponseError,
    PTMTimeoutError,
    PTMValidationError,
)


def _url_encode(value: str) -> str:
    """URL-encode a query-parameter value. Matches RFC 3986 unreserved only."""
    return quote(value, safe="")


TERMINAL_STATES = {"completed", "failed", "cancelled"}

logger = logging.getLogger("ptm_client")

_CLOUDFLARED_TIMEOUT_SECONDS = 3
_CF_UNABLE_PREFIX = "Unable to find"


def _is_cf_access_block(resp: requests.Response) -> bool:
    """Return True if the response is a Cloudflare Access challenge.

    Definitive signals only, to avoid false-positiving legitimate HTML bodies
    served from behind CF (e.g. the HTML run report endpoint):
    - ``WWW-Authenticate`` header starts with ``Cloudflare-Access``
    - ``Location`` redirect target contains ``cloudflareaccess.com``
    - status 401 / 403 with a ``cf-ray`` header AND an HTML body
    """
    headers = resp.headers
    wa = (headers.get("www-authenticate") or "").lower()
    if "cloudflare-access" in wa:
        return True
    loc = (headers.get("location") or "").lower()
    if "cloudflareaccess.com" in loc:
        return True
    if resp.status_code in (401, 403):
        ctype = (headers.get("content-type") or "").lower()
        has_cf_ray = "cf-ray" in {k.lower() for k in headers.keys()}
        if has_cf_ray and "text/html" in ctype:
            return True
    return False


def _cloudflared_access_token(base_url: str) -> str | None:
    """Invoke ``cloudflared access token -app=<base_url>`` with a short timeout.

    Returns the stripped token on success, or None if cloudflared is absent,
    cached session is missing, or the call exceeds the timeout. Never raises.
    """
    if not shutil.which("cloudflared"):
        return None
    try:
        result = subprocess.run(
            ["cloudflared", "access", "token", f"-app={base_url}"],
            capture_output=True,
            text=True,
            timeout=_CLOUDFLARED_TIMEOUT_SECONDS,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, PermissionError, OSError):
        return None
    token = (result.stdout or "").strip()
    if not token or token.startswith(_CF_UNABLE_PREFIX):
        return None
    return token


def _resolve_cf_access_headers(
    cf_access_client_id: str | None,
    cf_access_client_secret: str | None,
    cf_access_jwt: str | None,
) -> dict[str, str]:
    """Collect Cloudflare Access auth headers from args (precedence) or env.

    Constructor args win over env vars. Service-token pair (`CF_ACCESS_CLIENT_ID`
    + `CF_ACCESS_CLIENT_SECRET`) must be set together; a partial pair raises
    ``ValueError`` to fail fast rather than silently bypass the edge. A
    ``CF_ACCESS_JWT`` JWT assertion is independent and may be combined with
    the service-token pair; Cloudflare accepts whichever matches first.
    Returns an empty dict for direct-access deployments.
    """
    cid = (
        cf_access_client_id
        if cf_access_client_id is not None
        else os.environ.get("CF_ACCESS_CLIENT_ID")
    )
    csec = (
        cf_access_client_secret
        if cf_access_client_secret is not None
        else os.environ.get("CF_ACCESS_CLIENT_SECRET")
    )
    jwt = cf_access_jwt if cf_access_jwt is not None else os.environ.get("CF_ACCESS_JWT")

    cid = cid.strip() if cid else ""
    csec = csec.strip() if csec else ""
    jwt = jwt.strip() if jwt else ""

    if bool(cid) != bool(csec):
        raise ValueError(
            "CF_ACCESS_CLIENT_ID and CF_ACCESS_CLIENT_SECRET must both be set; "
            "setting only one bypasses Cloudflare Access half-configured."
        )

    headers: dict[str, str] = {}
    if cid and csec:
        headers["CF-Access-Client-Id"] = cid
        headers["CF-Access-Client-Secret"] = csec
    if jwt:
        headers["CF-Access-Jwt-Assertion"] = jwt
    return headers


class PTMClient:
    def __init__(
        self,
        base_url: str,
        token: str,
        timeout: int = 30,
        *,
        cf_access_client_id: str | None = None,
        cf_access_client_secret: str | None = None,
        cf_access_jwt: str | None = None,
    ) -> None:
        """Construct a PTMClient.

        Optional Cloudflare Access kwargs are injected as headers on every
        outbound request when set (or when the matching ``CF_ACCESS_*`` env
        vars are present). Unset and unenv'd: no CF headers are added.
        """
        self._base = base_url.rstrip("/")
        self._headers = {"Authorization": f"Bearer {token}"}
        # Track whether the caller supplied an explicit service-token or JWT.
        # If so, auto-discovery is skipped: explicit config always wins.
        _cid_raw = (
            cf_access_client_id
            if cf_access_client_id is not None
            else os.environ.get("CF_ACCESS_CLIENT_ID")
        )
        _jwt_raw = cf_access_jwt if cf_access_jwt is not None else os.environ.get("CF_ACCESS_JWT")
        self._cf_explicit = bool((_cid_raw or "").strip() or (_jwt_raw or "").strip())
        self._headers.update(
            _resolve_cf_access_headers(
                cf_access_client_id,
                cf_access_client_secret,
                cf_access_jwt,
            )
        )
        self._timeout = timeout
        self._cached_cf_jwt: str | None = None

    # ── internal helpers ──────────────────────────────────────────────────────

    def _auto_discover_enabled(self) -> bool:
        """Whether to auto-invoke cloudflared on a CF Access block.

        Off when the caller supplied explicit service-token / JWT config or
        when ``PTM_CF_AUTO_DISCOVER`` is set to a falsy value. On by default.
        """
        if self._cf_explicit:
            return False
        flag = os.environ.get("PTM_CF_AUTO_DISCOVER", "true").strip().lower()
        return flag not in ("false", "0", "no", "off")

    def _maybe_handle_cf_access(self, resp: requests.Response) -> bool:
        """Detect CF Access blocks; auto-discover a JWT if possible.

        Returns True when the caller should retry the request once with the
        freshly-injected JWT on ``self._headers``. Returns False for
        non-CF-Access responses. Raises :class:`CloudflareAccessError` with an
        actionable message when auto-discovery is disabled or cloudflared
        cannot produce a token.
        """
        if not _is_cf_access_block(resp):
            return False
        if not self._auto_discover_enabled():
            raise CloudflareAccessError(
                "Cloudflare Access blocked this request and auto-discovery is "
                "disabled. Set PTM_CF_AUTO_DISCOVER=true or supply "
                "CF_ACCESS_CLIENT_ID + CF_ACCESS_CLIENT_SECRET.",
                status_code=resp.status_code,
            )
        # Invalidate any stale cache; fetch fresh and retry once.
        self._cached_cf_jwt = None
        self._headers.pop("CF-Access-Jwt-Assertion", None)
        jwt = _cloudflared_access_token(self._base)
        if jwt:
            self._cached_cf_jwt = jwt
            self._headers["CF-Access-Jwt-Assertion"] = jwt
            logger.info("[ptm-client] cloudflared auto-discovery succeeded; retrying request")
            return True
        if shutil.which("cloudflared"):
            raise CloudflareAccessError(
                "Cloudflare Access blocked this request and cloudflared has "
                "no cached session for this host.\n"
                f"Run once: cloudflared access login {self._base}",
                status_code=resp.status_code,
            )
        raise CloudflareAccessError(
            "Cloudflare Access blocked this request and cloudflared is not "
            "installed.\n"
            "Install: brew install cloudflared (or the equivalent for your OS),\n"
            f"then run: cloudflared access login {self._base}",
            status_code=resp.status_code,
        )

    def _raise_for_status(self, resp: requests.Response, *, method: str, path: str) -> None:
        """Translate 4xx / 5xx responses into typed PTM exceptions.

        403 and 404 on mutation paths (and prompts/* reads) carry
        actionable semantics: the caller either lacks ownership / group
        membership (403) or is referring to an id that doesn't exist or is
        outside the caller's visibility scope (404). Both are common on MCP
        tool calls where the LLM has the wrong prompt_id or tries to mutate
        someone else's prompt.
        """
        if resp.status_code < 400:
            return
        preview = (resp.text or "")[:200]
        if resp.status_code == 403:
            raise PTMPermissionError(
                f"{method} {path} forbidden (403): you may not own this prompt, "
                "the prompt may be scoped to a group you're not a member of, or "
                "your PAT lacks the required scope. Contact an admin or the prompt "
                f"owner. Response: {preview!r}",
                status_code=403,
            )
        if resp.status_code == 404:
            raise PTMNotFoundError(
                f"{method} {path} not found (404): resource id does not exist or is "
                f"outside your visibility scope. Response: {preview!r}",
                status_code=404,
            )
        if resp.status_code == 409:
            raise PTMConflictError(
                f"{method} {path} conflict (409): the target prompt is "
                "repository-backed (edit the files in git, not via API), or "
                "another writer committed between your read and write. Re-fetch "
                f"and retry. Response: {preview!r}",
                status_code=409,
            )
        if resp.status_code == 422:
            raise PTMValidationError(
                f"{method} {path} validation failed (422): the request did not "
                "match the backend's expected shape. Common causes: prompt_text "
                "over 500,000 chars, malformed test / deepeval_metric dicts, "
                "unknown provider profile, or field type mismatch. "
                f"Response: {preview!r}",
                status_code=422,
            )
        raise PTMError(f"{method} {path} failed: {resp.status_code} {preview}", resp.status_code)

    def _parse_json(self, resp: requests.Response, *, path: str) -> Any:
        """Parse a JSON body. Wrap decode errors with actionable messages."""
        ctype = (resp.headers.get("content-type") or "").lower()
        if "text/html" in ctype:
            raise PTMResponseError(
                f"Expected JSON from {path}, got HTML (status {resp.status_code}). "
                "This usually means Cloudflare Access, a load balancer, or an "
                "auth proxy intercepted the request before it reached PTM.",
                status_code=resp.status_code,
            )
        try:
            return resp.json()
        except ValueError as exc:
            preview = (resp.text or "")[:120].replace("\n", " ")
            raise PTMResponseError(
                f"Non-JSON response from {path} (status {resp.status_code}): {preview!r}",
                status_code=resp.status_code,
            ) from exc

    def _get(self, path: str, **params: Any) -> Any:
        url = f"{self._base}{path}"
        try:
            resp = requests.get(
                url,
                headers=self._headers,
                params=params or None,
                timeout=self._timeout,
                allow_redirects=False,
            )
            if self._maybe_handle_cf_access(resp):
                resp = requests.get(
                    url,
                    headers=self._headers,
                    params=params or None,
                    timeout=self._timeout,
                    allow_redirects=False,
                )
                if _is_cf_access_block(resp):
                    raise CloudflareAccessError(
                        "Cloudflare Access still blocked the request after "
                        "injecting a cloudflared JWT. The JWT was valid but "
                        "the policy on this host likely requires a service "
                        "token, WARP-Gateway user session, or different role. "
                        "Ask an admin to grant your user a role on this Access "
                        "application, or set CF_ACCESS_CLIENT_ID + "
                        "CF_ACCESS_CLIENT_SECRET in the env.",
                        status_code=resp.status_code,
                    )
        except requests.Timeout as exc:
            raise PTMError(f"GET {path} timed out: {exc}", status_code=0) from exc
        except (requests.ConnectionError, ConnectionError) as exc:
            raise PTMError(f"GET {path} connection failed: {exc}", status_code=0) from exc
        self._raise_for_status(resp, method="GET", path=path)
        return self._parse_json(resp, path=path)

    def _post(self, path: str, body: dict[str, Any]) -> Any:
        url = f"{self._base}{path}"
        headers = {**self._headers, "Content-Type": "application/json"}
        try:
            resp = requests.post(
                url,
                headers=headers,
                json=body,
                timeout=self._timeout,
                allow_redirects=False,
            )
            if self._maybe_handle_cf_access(resp):
                headers = {**self._headers, "Content-Type": "application/json"}
                resp = requests.post(
                    url,
                    headers=headers,
                    json=body,
                    timeout=self._timeout,
                    allow_redirects=False,
                )
                if _is_cf_access_block(resp):
                    raise CloudflareAccessError(
                        "Cloudflare Access still blocked the request after "
                        "injecting a cloudflared JWT. The JWT was valid but "
                        "the policy on this host likely requires a service "
                        "token, WARP-Gateway user session, or different role. "
                        "Ask an admin to grant your user a role on this Access "
                        "application, or set CF_ACCESS_CLIENT_ID + "
                        "CF_ACCESS_CLIENT_SECRET in the env.",
                        status_code=resp.status_code,
                    )
        except requests.Timeout as exc:
            raise PTMError(f"POST {path} timed out: {exc}", status_code=0) from exc
        except (requests.ConnectionError, ConnectionError) as exc:
            raise PTMError(f"POST {path} connection failed: {exc}", status_code=0) from exc
        self._raise_for_status(resp, method="POST", path=path)
        return self._parse_json(resp, path=path)

    def _patch(self, path: str, body: dict[str, Any]) -> Any:
        url = f"{self._base}{path}"
        headers = {**self._headers, "Content-Type": "application/json"}
        try:
            resp = requests.patch(
                url,
                headers=headers,
                json=body,
                timeout=self._timeout,
                allow_redirects=False,
            )
            if self._maybe_handle_cf_access(resp):
                headers = {**self._headers, "Content-Type": "application/json"}
                resp = requests.patch(
                    url,
                    headers=headers,
                    json=body,
                    timeout=self._timeout,
                    allow_redirects=False,
                )
        except requests.Timeout as exc:
            raise PTMError(f"PATCH {path} timed out: {exc}", status_code=0) from exc
        except (requests.ConnectionError, ConnectionError) as exc:
            raise PTMError(f"PATCH {path} connection failed: {exc}", status_code=0) from exc
        self._raise_for_status(resp, method="PATCH", path=path)
        return self._parse_json(resp, path=path)

    def _put(self, path: str, body: dict[str, Any]) -> Any:
        url = f"{self._base}{path}"
        headers = {**self._headers, "Content-Type": "application/json"}
        try:
            resp = requests.put(
                url,
                headers=headers,
                json=body,
                timeout=self._timeout,
                allow_redirects=False,
            )
            if self._maybe_handle_cf_access(resp):
                headers = {**self._headers, "Content-Type": "application/json"}
                resp = requests.put(
                    url,
                    headers=headers,
                    json=body,
                    timeout=self._timeout,
                    allow_redirects=False,
                )
        except requests.Timeout as exc:
            raise PTMError(f"PUT {path} timed out: {exc}", status_code=0) from exc
        except (requests.ConnectionError, ConnectionError) as exc:
            raise PTMError(f"PUT {path} connection failed: {exc}", status_code=0) from exc
        self._raise_for_status(resp, method="PUT", path=path)
        return self._parse_json(resp, path=path)

    def _delete(self, path: str) -> None:
        url = f"{self._base}{path}"
        try:
            resp = requests.delete(
                url,
                headers=self._headers,
                timeout=self._timeout,
                allow_redirects=False,
            )
            if self._maybe_handle_cf_access(resp):
                resp = requests.delete(
                    url,
                    headers=self._headers,
                    timeout=self._timeout,
                    allow_redirects=False,
                )
        except requests.Timeout as exc:
            raise PTMError(f"DELETE {path} timed out: {exc}", status_code=0) from exc
        except (requests.ConnectionError, ConnectionError) as exc:
            raise PTMError(f"DELETE {path} connection failed: {exc}", status_code=0) from exc
        self._raise_for_status(resp, method="DELETE", path=path)

    # ── prompts ───────────────────────────────────────────────────────────────

    def list_prompts(
        self,
        tag: str | None = None,
        team: str | None = None,
        service: str | None = None,
        source: str | None = None,
        search: str | None = None,
        group: str | None = None,
    ) -> list[dict]:
        """Return prompts, optionally filtered by tag, team, service, source, search, or group."""
        filters = {
            "tag": tag,
            "team": team,
            "service": service,
            "source": source,
            "search": search,
            "group": group,
        }
        params = {k: v for k, v in filters.items() if v is not None}
        data = self._get("/api/v1/prompts", **params)
        return data.get("prompts", data) if isinstance(data, dict) else data

    def get_prompt(self, prompt_id: str) -> dict:
        """Return a single prompt by ID."""
        return self._get(f"/api/v1/prompts/{prompt_id}")

    def get_prompt_tests(self, prompt_id: str) -> dict:
        """Return test cases and deepeval metrics for a prompt."""
        return self._get(f"/api/v1/prompts/{prompt_id}/tests")

    def list_prompt_versions(self, prompt_id: str) -> list[dict]:
        """Return all versions of a prompt, newest first. Added in v0.3.0."""
        data = self._get(f"/api/v1/prompts/{prompt_id}/versions")
        return data.get("versions", data) if isinstance(data, dict) else data

    def get_prompt_version(self, prompt_id: str, version_number: int) -> dict:
        """Return a specific version of a prompt. Added in v0.3.0."""
        return self._get(f"/api/v1/prompts/{prompt_id}/versions/{int(version_number)}")

    # ── providers ─────────────────────────────────────────────────────────────

    def list_providers(self) -> list[dict]:
        """Return available provider profiles."""
        data = self._get("/api/v1/providers")
        return data.get("profiles", data) if isinstance(data, dict) else data

    # ── evaluations ───────────────────────────────────────────────────────────

    def run_eval(
        self,
        prompt_ids: list[str],
        provider_ids: list[str],
        **kwargs: Any,
    ) -> dict:
        """Submit a repository (library) evaluation and return the run metadata."""
        body = {"prompt_ids": prompt_ids, "provider_ids": provider_ids, **kwargs}
        return self._post("/api/v1/evaluations/repository", body)

    def run_manual_eval(self, payload: dict) -> dict:
        """Submit a manual (replay) evaluation payload and return the run metadata."""
        payload.setdefault("source", "api")
        return self._post("/api/v1/evaluations/manual", payload)

    def run_prompt_eval(
        self,
        prompt_id: str,
        provider_ids: list[str],
        *,
        inject_vars: dict[str, Any] | None = None,
        extra_tests: list[dict] | None = None,
        visibility_scope: str = "org_visible",
        label: str | None = None,
    ) -> dict:
        """Fetch a prompt's content and tests from PTM, then submit a manual eval.

        This is the recommended way for external services to evaluate a PTM prompt
        with live data - it fetches the prompt and its stored test cases, optionally
        injects runtime variables (e.g. a real transcript), and submits in one call.

        Args:
            prompt_id: PTM prompt ID (e.g. ``"my_team.summarizer"``).
            provider_ids: Provider profiles to evaluate against.
            inject_vars: Variables merged into every test case's ``vars`` dict.
            extra_tests: Additional test cases appended to the prompt's stored tests.
            visibility_scope: Run visibility (``org_visible``, ``private_only``,
                ``admins_can_view_all``).
            label: Optional label for the run (defaults to ``prompt_id``).
        """
        detail = self.get_prompt(prompt_id)
        test_data = self.get_prompt_tests(prompt_id)

        prompt_text = detail.get("prompt_text", "")
        tests = list(test_data.get("promptfoo_tests") or test_data.get("tests") or [])
        deepeval_metrics = test_data.get("deepeval_metrics", [])
        judge_profile = test_data.get("judge_profile") or ""

        if inject_vars:
            for tc in tests:
                vars_dict = tc.get("vars", {})
                vars_dict.update(inject_vars)
                tc["vars"] = vars_dict

        if extra_tests:
            tests.extend(extra_tests)

        if not tests:
            raise PTMError(f"Prompt {prompt_id} has no test cases and no extra_tests provided")

        payload: dict[str, Any] = {
            "label": label or prompt_id,
            "prompt_text": prompt_text,
            "tests": tests,
            "provider_profiles": provider_ids,
            "visibility_scope": visibility_scope,
            "include_security_preset": False,
            "cost_threshold": 1.0,
            "latency_threshold_ms": 30000,
        }
        if deepeval_metrics:
            payload["additional_metrics"] = deepeval_metrics
        if judge_profile:
            payload["judge_profile"] = judge_profile

        return self.run_manual_eval(payload)

    # ── runs ──────────────────────────────────────────────────────────────────

    def get_run(self, run_key: str) -> dict:
        """Return current status of a run."""
        data = self._get(f"/api/v1/runs/{run_key}")
        # Normalise score fields from providers array if not at root
        providers = data.get("providers") or []
        if providers and data.get("score") is None:
            pct = providers[0].get("final_success_percentage")
            data["score"] = round(pct / 100, 4) if pct is not None else None
            data["passed_tests"] = providers[0].get("passed_assertions")
            data["total_tests"] = providers[0].get("total_assertions")
        return data

    def list_runs(
        self,
        *,
        limit: int = 50,
        terminal_only: bool = False,
        mine_only: bool = False,
        source: str | None = None,
        prompt_id: str | None = None,
        since: str | None = None,
    ) -> dict:
        """List recent runs. Added in v0.3.0.

        Args:
            limit: Max runs to return (default 50).
            terminal_only: Only include terminal runs (completed/failed/canceled).
            mine_only: Only include runs owned by the authenticating principal.
            source: Filter by run source (e.g. ``"ptm-mcp"``, ``"manual"``,
                ``"repository"``, ``"optimization"``). Requires backend >= 1.9.0.
            prompt_id: Filter to a specific library prompt. Requires backend >= 1.9.0.
            since: ISO-8601 timestamp; only runs created at or after this time.
                Requires backend >= 1.9.0.

        Returns:
            Dict with ``runs`` list and ``total_active_count``.
        """
        params: dict[str, Any] = {"limit": int(limit)}
        if terminal_only:
            params["terminal_only"] = "true"
        if mine_only:
            params["mine_only"] = "true"
        if source is not None:
            params["source"] = source
        if prompt_id is not None:
            params["prompt_id"] = prompt_id
        if since is not None:
            params["since"] = since
        return self._get("/api/v1/runs", **params)

    def wait_for_run(
        self,
        run_key: str,
        timeout: int = 300,
        poll_interval: int = 5,
    ) -> dict:
        """Block until a run reaches a terminal state. Returns the final status dict."""
        elapsed = 0
        while True:
            status = self.get_run(run_key)
            if status.get("status") in TERMINAL_STATES:
                return status
            if elapsed >= timeout:
                raise PTMTimeoutError(
                    f"Run {run_key} did not complete within {timeout}s "
                    f"(last status: {status.get('status')})"
                )
            time.sleep(poll_interval)
            elapsed += poll_interval

    # ------------------------------------------------------------------
    # Optimization
    # ------------------------------------------------------------------

    def submit_optimization(
        self,
        prompt_id: str,
        provider_profiles: list[str] | None = None,
        judge_profile: str | None = None,
        max_cycles: int = 10,
        target_score: float = 90.0,
        min_improvement: float = 2.0,
        max_cost_usd: float = 20.0,
        comparison_strategy: str | None = None,
        visibility_scope: str | None = None,
    ) -> dict:
        """Submit an optimization run for a prompt.

        Added in v0.3.0. Previously named ``optimize_prompt`` (kept as a
        deprecation alias; will be removed in v1.0.0).

        Args:
            prompt_id: Library prompt ID to optimize.
            provider_profiles: Providers to evaluate against.
            judge_profile: DeepEval judge override.
            max_cycles: Max optimization cycles (default 10).
            target_score: Stop early if score reaches this percent (default 90).
            min_improvement: Cycles below this improvement trigger plateau
                detection (default 2.0, org setting applies).
            max_cost_usd: Hard cost cap for the entire optimization (default 20).
            comparison_strategy: ``avg_all_providers`` (default) or ``min_provider``.
            visibility_scope: Run visibility scope override.

        Returns:
            Job submission with ``run_key``, ``job_id``, ``status``, and
            ``estimated_total_cost_usd`` when available.
        """
        payload: dict[str, Any] = {
            "max_cycles": max_cycles,
            "target_score": target_score,
            "min_improvement": min_improvement,
            "max_cost_usd": max_cost_usd,
        }
        if provider_profiles:
            payload["provider_profiles"] = provider_profiles
        if judge_profile:
            payload["judge_profile"] = judge_profile
        if comparison_strategy:
            payload["comparison_strategy"] = comparison_strategy
        if visibility_scope:
            payload["visibility_scope"] = visibility_scope
        return self._post(f"/api/v1/prompts/{prompt_id}/optimize", payload)

    def optimize_prompt(self, *args, **kwargs) -> dict:
        """Deprecated alias for :meth:`submit_optimization`. Removed in v1.0.0."""
        import warnings

        warnings.warn(
            "optimize_prompt() is deprecated; use submit_optimization() instead. "
            "The alias will be removed in ptm-client v1.0.0.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.submit_optimization(*args, **kwargs)

    def get_optimization_detail(self, optimization_id: str) -> dict:
        """Return full optimization detail with per-cycle data. Added in v0.3.0."""
        return self._get(f"/api/v1/optimizations/{optimization_id}")

    def get_optimization_status(self, prompt_id: str) -> dict:
        """Get active optimization status for a prompt, or empty dict."""
        return self._get(f"/api/v1/prompts/{prompt_id}/optimization-status")

    def get_optimization_history(self, prompt_id: str) -> list:
        """Get optimization run history for a prompt."""
        return self._get(f"/api/v1/prompts/{prompt_id}/optimization-history")

    def cancel_optimization(self, optimization_id: str) -> dict:
        """Cancel a running optimization."""
        return self._post(f"/api/v1/optimizations/{optimization_id}/cancel", {})

    def wait_for_optimization(
        self,
        prompt_id: str,
        *,
        timeout: int = 600,
        poll_interval: int = 10,
    ) -> dict:
        """Block until the active optimization completes or times out.

        Returns the final optimization status dict.
        """
        elapsed = 0
        while elapsed < timeout:
            status = self.get_optimization_status(prompt_id)
            if not status or status.get("status") not in ("queued", "running"):
                return status
            time.sleep(poll_interval)
            elapsed += poll_interval
        raise PTMTimeoutError(f"Optimization for {prompt_id} did not complete within {timeout}s")

    # ------------------------------------------------------------------
    # Reports
    # ------------------------------------------------------------------

    def run_report(self, run_key: str, *, format: str = "html") -> str:
        """Return the eval report for a completed run (default: HTML)."""
        url = f"{self._base}/api/v1/runs/{run_key}/report"
        params = {"format": format}
        resp = requests.get(
            url,
            headers=self._headers,
            params=params,
            timeout=self._timeout,
            allow_redirects=False,
        )
        if self._maybe_handle_cf_access(resp):
            resp = requests.get(
                url,
                headers=self._headers,
                params=params,
                timeout=self._timeout,
                allow_redirects=False,
            )
        if resp.status_code >= 400:
            raise PTMError(f"run_report failed: {resp.status_code}", resp.status_code)
        # For JSON format, return the raw JSON text directly
        if format == "json":
            return resp.text
        ct = resp.headers.get("content-type", "")
        if "application/json" in ct:
            body = resp.json()
            return body.get("html") or body.get("content") or resp.text
        return resp.text

    # ------------------------------------------------------------------
    # Library mutation (v0.4.0)
    # ------------------------------------------------------------------

    def update_prompt(
        self,
        prompt_id: str,
        *,
        change_summary: str,
        name: str | None = None,
        team: str | None = None,
        service: str | None = None,
        description: str | None = None,
        tags: list[str] | None = None,
        prompt_text: str | None = None,
        tests: list[dict[str, Any]] | None = None,
        deepeval_metrics: list[dict[str, Any]] | None = None,
        kpis: list[dict[str, Any]] | None = None,
        provider_profiles: list[str] | None = None,
        judge_profile: str | None = None,
        set_active: bool = True,
    ) -> dict:
        """Atomically update a library prompt via ``PUT /api/v1/prompts/{id}``.

        Partial-update semantics:

        - ``None`` / omitted: leave the field unchanged.
        - ``[]`` on list fields: clear all values (replace with empty).
        - Populated list: replace the stored value.

        Content fields (``prompt_text``, ``tests``, ``deepeval_metrics``, ``kpis``,
        ``provider_profiles``, ``judge_profile``) auto-create a new version on the
        backend; metadata-only updates (``name``, ``team``, ``service``,
        ``description``, ``tags``) do not rev the version.

        ``change_summary`` is a mandatory one-line audit note. The backend accepts
        null but this client makes it required so every agent-driven write records
        a "why".

        RBAC: the PAT's user must be the prompt owner OR hold a PROMPT_OVERWRITE
        role (admin / privileged).
        """
        payload: dict[str, Any] = {"change_summary": change_summary}
        for field_name, value in (
            ("name", name),
            ("team", team),
            ("service", service),
            ("description", description),
            ("tags", tags),
            ("prompt_text", prompt_text),
            ("tests", tests),
            ("deepeval_metrics", deepeval_metrics),
            ("kpis", kpis),
            ("provider_profiles", provider_profiles),
            ("judge_profile", judge_profile),
        ):
            if value is not None:
                payload[field_name] = value
        path = f"/api/v1/prompts/{prompt_id}"
        if not set_active:
            path = f"{path}?set_active=false"
        return self._put(path, payload)

    def activate_prompt_version(self, prompt_id: str, version_number: int) -> dict:
        """Set a specific existing version as active.

        PUT ``/api/v1/prompts/{id}/versions/{version_number}/activate``. Owner
        or privileged role only. This is the rollback / roll-forward path; no
        content change, no new version row.
        """
        return self._put(
            f"/api/v1/prompts/{prompt_id}/versions/{int(version_number)}/activate",
            {},
        )

    def share_prompt(self, prompt_id: str) -> dict:
        """Move a prompt into the default org-visible group (org-wide share).

        POST ``/api/v1/prompts/{id}/share`` with no body. Organization-wide
        share semantics; there is no per-user sharing mode. Use
        :meth:`add_prompt_to_group` for fine-grained access.

        Requires admin OR a ``group_mgr:`` role on the default group.
        """
        return self._post(f"/api/v1/prompts/{prompt_id}/share", {})

    def unshare_prompt(self, prompt_id: str, group_id: str) -> dict:
        """Remove a prompt from a specific group.

        POST ``/api/v1/prompts/{id}/unshare?group_id=<gid>``. ``group_id`` is a
        QUERY PARAMETER, not a body field. Requires admin OR ``group_mgr:``.
        """
        return self._post(
            f"/api/v1/prompts/{prompt_id}/unshare?group_id={_url_encode(group_id)}",
            {},
        )

    def add_prompt_to_group(self, prompt_id: str, group_id: str, editable: bool = False) -> dict:
        """Grant a specific group access to a prompt.

        POST ``/api/v1/prompts/{id}/groups?group_id=<gid>&editable=<bool>``.
        Both are QUERY PARAMETERS. ``editable=True`` lets group members edit;
        default is read-only access. Requires admin OR ``group_mgr:`` of the
        target group.
        """
        editable_str = "true" if editable else "false"
        return self._post(
            f"/api/v1/prompts/{prompt_id}/groups"
            f"?group_id={_url_encode(group_id)}&editable={editable_str}",
            {},
        )

    def remove_prompt_from_group(self, prompt_id: str, group_id: str) -> None:
        """Revoke a group's access to a prompt.

        DELETE ``/api/v1/prompts/{id}/groups/{group_id}``. Requires admin OR
        ``group_mgr:`` role.
        """
        self._delete(f"/api/v1/prompts/{prompt_id}/groups/{group_id}")

    def transfer_prompt_ownership(self, prompt_id: str, new_owner_id: str) -> dict:
        """Transfer prompt ownership to another user. ADMIN ONLY.

        POST ``/api/v1/prompts/{id}/transfer?new_owner_id=<uid>``.
        ``new_owner_id`` is a QUERY PARAMETER (not a body field). The current
        owner CANNOT self-transfer; an admin must intervene. Target user must
        exist and be active.
        """
        return self._post(
            f"/api/v1/prompts/{prompt_id}/transfer?new_owner_id={_url_encode(new_owner_id)}",
            {},
        )
