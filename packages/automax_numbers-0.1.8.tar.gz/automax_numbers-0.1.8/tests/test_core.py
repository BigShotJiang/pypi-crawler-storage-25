# tests/test_core.py

from lottery_gen_pkg.core import generate_numbers  # <--- MAKE SURE THIS IS HERE

def test_multi_match_logic():
    multi_config = {
        "white_count": 6, 
        "white_min": 1,
        "white_max": 43, 
        "special_name": None
    }
    
    # This call should now work because of the import above
    white_balls, special = generate_numbers(multi_config)
    
    assert len(white_balls) == 6
    assert special is None