import random

# -----------------------------
# Game configuration dictionary
# -----------------------------
GAMES = {
    "1": {
        "name": "Powerball",
        "white_min": 1,
        "white_max": 69,
        "white_count": 5,
        "special_min": 1,
        "special_max": 26,
        "special_name": "Powerball",
    },
    "2": {
        "name": "Mega Millions",
        "white_min": 1,
        "white_max": 70,
        "white_count": 5,
        "special_min": 1,
        "special_max": 25,
        "special_name": "Mega Ball",
    },
    "3": {
        "name": "Multi Match",
        "white_min": 1,
        "white_max": 43,
        "white_count": 6,
        "special_min": None,
        "special_max": None,
        "special_name": None,
    }
}

# -----------------------------
# Core number generation logic
# -----------------------------
def generate_numbers(config):
    """Generates numbers based on the provided dictionary config."""
    w_min = config.get("white_min", 1)
    w_max = config.get("white_max", 49)
    w_count = config.get("white_count", 6)
    
    pool_size = (w_max - w_min) + 1
    
    # Logic for unique numbers vs repetitive (pick games)
    if w_count > pool_size:
        white_balls = sorted([random.randint(w_min, w_max) for _ in range(w_count)])
    else:
        white_balls = sorted(random.sample(range(w_min, w_max + 1), w_count))

    spec_name = config.get("special_name")
    spec_min = config.get("special_min")
    spec_max = config.get("special_max")

    if spec_name and spec_min is not None and spec_max is not None:
        special_ball = random.randint(spec_min, spec_max)
        return white_balls, special_ball

    return white_balls, None

def generate_multiple_tickets(config, count):
    return [generate_numbers(config) for _ in range(count)]

__all__ = ["GAMES", "generate_numbers", "generate_multiple_tickets"]