from lottery_gen_pkg.core import GAMES, generate_multiple_tickets

def choose_game():
    print("\nAvailable Games:")
    # Dynamically list games from your GAMES dictionary in core.py
    for key, cfg in GAMES.items():
        print(f"  {key:12} - {cfg['name']}")
    print()
    
    while True:
        choice = input("Select a game (or 'exit'): ").strip().lower()
        if choice == 'exit':
            return None
        if choice in GAMES:
            return GAMES[choice]
        print("Invalid choice. Try again.\n")

def main():
    print("\n=== Lottery Number Generator ===")
    config = choose_game()
    
    if not config:
        print("Exiting...")
        return

    while True:
        try:
            count_input = input("How many tickets? ").strip()
            count = int(count_input)
            if count > 0:
                break
            print("Enter a number greater than 0.")
        except ValueError:
            print("Invalid input. Please enter a number.")

    tickets = generate_multiple_tickets(config, count)
    
    print(f"\n--- {config['name']} Results ---")
    for i, (numbers, special) in enumerate(tickets, start=1):
        # Formats numbers with leading zeros (e.g., 05 09 12)
        formatted = " ".join(f"{n:02d}" for n in numbers)
        
        # Check if there's a special ball and a name for it (Powerball/Mega Ball)
        if special is not None and config.get("special_name"):
            print(f"Ticket {i:2}: {formatted} | {config['special_name']}: {special:02d}")
        else:
            print(f"Ticket {i:2}: {formatted}")
    print("-" * 40 + "\n")

if __name__ == "__main__":
    main()