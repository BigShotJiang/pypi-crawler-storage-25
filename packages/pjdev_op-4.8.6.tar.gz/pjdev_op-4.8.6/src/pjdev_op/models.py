from typing import Optional

from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import BaseModel, SecretStr


class Config(BaseSettings):
    service_token: Optional[SecretStr] = None

    model_config = SettingsConfigDict(
        env_prefix="OP_",
        case_sensitive=False,
        extra="ignore",
    )


class FieldUpdate(BaseModel):
    title: str
    new_value: str
