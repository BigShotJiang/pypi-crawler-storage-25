"""Charter sync orchestrator.

Provides the main sync() function that orchestrates:
1. Read charter.md
2. Check staleness (skip if unchanged, unless --force)
3. Parse and extract to YAML
4. Write governance/directives/metadata files
5. Update metadata with hash and timestamp
"""

import logging
from dataclasses import dataclass, replace
from pathlib import Path

from ruamel.yaml import YAML

from charter.bundle import CANONICAL_MANIFEST
from charter.extractor import Extractor, write_extraction_result
from charter.hasher import is_stale
from charter.resolution import resolve_canonical_repo_root
from charter.schemas import (
    DirectivesConfig,
    GovernanceConfig,
)

logger = logging.getLogger(__name__)

_KITTIFY_DIRNAME = ".kittify"
_CHARTER_DIRNAME = "charter"
_CHARTER_FILENAME = "charter.md"
_METADATA_FILENAME = "metadata.yaml"
_GOVERNANCE_FILENAME = "governance.yaml"
_DIRECTIVES_FILENAME = "directives.yaml"
_SYNC_OUTPUT_FILES = [
    _GOVERNANCE_FILENAME,
    _DIRECTIVES_FILENAME,
    _METADATA_FILENAME,
]


@dataclass
class SyncResult:
    """Result of a charter sync operation.

    ``files_written`` entries are file names relative to the canonical
    charter directory (``canonical_root / .kittify/charter/``). To
    reconstruct an absolute path for a written file, anchor against
    ``canonical_root``: ``canonical_root / .kittify/charter / files_written[i]``.

    ``canonical_root`` is the main-checkout project root resolved via
    ``charter.resolution.resolve_canonical_repo_root``. It is ``None`` only
    on transient ``SyncResult`` objects produced by direct ``sync()`` calls
    that haven't been routed through the chokepoint; the chokepoint
    (``ensure_charter_bundle_fresh``) always patches a real path in via
    ``dataclasses.replace`` before returning.
    """

    synced: bool  # True if extraction ran
    stale_before: bool  # True if charter was stale before sync
    files_written: list[str]  # File names; anchored at canonical_root / .kittify/charter
    extraction_mode: str  # "deterministic" | "hybrid"
    error: str | None = None  # Error message if sync failed
    canonical_root: Path | None = None  # NEW (WP02): main-checkout root


def ensure_charter_bundle_fresh(repo_root: Path) -> SyncResult | None:
    """Auto-refresh extracted charter artifacts when ``charter.md`` exists.

    Resolves ``repo_root`` to the canonical (main-checkout) root via
    ``resolve_canonical_repo_root`` and consults
    ``CharterBundleManifest.CANONICAL_MANIFEST`` for the set of files that
    must exist under the canonical root. If any required derived file is
    missing or the bundle is stale (``is_stale`` hash comparison), ``sync()``
    is invoked to regenerate the derivatives.

    The returned ``SyncResult`` always carries ``canonical_root`` (patched
    via ``dataclasses.replace`` onto whatever ``sync()`` returned).
    Exceptions from the resolver (``NotInsideRepositoryError``,
    ``GitCommonDirUnavailableError``) propagate unchanged per C-001.

    Returns ``None`` when ``charter.md`` is absent under the canonical
    root — there is no charter to refresh.
    """
    canonical_root = resolve_canonical_repo_root(repo_root)
    charter_dir = canonical_root / _KITTIFY_DIRNAME / _CHARTER_DIRNAME
    charter_path = charter_dir / _CHARTER_FILENAME
    if not charter_path.exists():
        return None

    metadata_path = charter_dir / _METADATA_FILENAME
    # Manifest is authoritative for "what files must exist" (FR-006).
    expected_paths = [canonical_root / p for p in CANONICAL_MANIFEST.derived_files]
    missing_files = [p.name for p in expected_paths if not p.exists()]
    should_force = bool(missing_files)
    stale = False

    if not should_force:
        try:
            stale, _, _ = is_stale(charter_path, metadata_path)
        except Exception as exc:
            logger.warning("Failed to evaluate charter bundle freshness: %s", exc)
            should_force = True

    if not should_force and not stale:
        return SyncResult(
            synced=False,
            stale_before=False,
            files_written=[],
            extraction_mode="",
            canonical_root=canonical_root,
        )

    if missing_files:
        logger.info("Charter bundle incomplete (%s). Attempting auto-sync.", ", ".join(missing_files))
    else:
        logger.info("Charter bundle stale. Attempting auto-sync.")

    result = sync(charter_path, charter_dir, force=should_force)
    # Patch canonical_root onto the SyncResult returned by sync(); sync()
    # itself doesn't know which checkout the caller invoked it from.
    result = replace(result, canonical_root=canonical_root)
    if result.error:
        logger.warning("Charter auto-sync failed while refreshing extracted artifacts: %s", result.error)
    return result


def sync(
    charter_path: Path,
    output_dir: Path | None = None,
    force: bool = False,
) -> SyncResult:
    """Sync charter.md to structured YAML config files.

    Args:
        charter_path: Path to charter.md
        output_dir: Directory for YAML output (default: same as charter_path.parent)
        force: If True, extract even if not stale

    Returns:
        SyncResult with status and file paths
    """
    # Default output directory to same location as charter
    if output_dir is None:
        output_dir = charter_path.parent

    # Metadata path
    metadata_path = output_dir / _METADATA_FILENAME

    try:
        # Read charter content once
        content = charter_path.read_text("utf-8")

        # Check staleness using the content (eliminates TOCTOU race)
        stale, _, _ = is_stale(None, metadata_path, content=content)

        # Skip if not stale and not forced
        if not stale and not force:
            logger.info("Charter unchanged, skipping sync")
            return SyncResult(
                synced=False,
                stale_before=False,
                files_written=[],
                extraction_mode="",
            )

        # Extract to structured configs (using same content)
        extractor = Extractor()
        result = extractor.extract(content)

        # Write YAML files
        write_extraction_result(result, output_dir)

        # List files written
        files_written = list(_SYNC_OUTPUT_FILES)

        logger.info(f"Charter synced successfully (mode: {result.metadata.extraction_mode})")

        return SyncResult(
            synced=True,
            stale_before=stale,
            files_written=files_written,
            extraction_mode=result.metadata.extraction_mode,
        )

    except Exception as e:
        logger.error(f"Sync failed: {e}")
        return SyncResult(
            synced=False,
            stale_before=False,
            files_written=[],
            extraction_mode="",
            error=str(e),
        )


def post_save_hook(charter_path: Path) -> None:
    """Auto-trigger sync after charter write.

    Called synchronously after CLI writes to charter.md.
    Failures are logged but don't propagate (FR-2.3).

    Args:
        charter_path: Path to charter.md
    """
    try:
        result = sync(charter_path, force=True)
        if result.synced:
            # Anchor log paths against canonical_root when available, falling
            # back to the charter directory when the caller invoked sync()
            # directly (no chokepoint patch). This is a logging convenience —
            # the sync result itself is unchanged.
            anchor = result.canonical_root if result.canonical_root else charter_path.parent
            logger.info(
                "Charter synced: %d YAML files updated under %s",
                len(result.files_written),
                anchor,
            )
        elif result.error:
            logger.warning("Charter sync warning: %s", result.error)
    except Exception:
        logger.warning(
            "Charter auto-sync failed. Run 'spec-kitty charter sync' manually.",
            exc_info=True,
        )


def _resolve_bundle_root(repo_root: Path, refresh_result: SyncResult | None) -> Path:
    """Return the canonical charter-bundle root for loader path construction.

    The chokepoint materializes the bundle under the main-checkout canonical
    root; loaders called from a worktree must anchor path construction on
    that same root so the just-materialized derivatives are visible (FR-010).
    Fall back to ``repo_root`` only when the chokepoint returned ``None``
    (no ``charter.md`` under the canonical root) — in that case there is
    nothing to read regardless of which root we use.
    """
    if refresh_result is not None and refresh_result.canonical_root is not None:
        return refresh_result.canonical_root
    return repo_root


def load_governance_config(repo_root: Path) -> GovernanceConfig:
    """Load governance config from .kittify/charter/governance.yaml.

    Falls back to empty GovernanceConfig if file missing (FR-4.4).
    Checks staleness and logs warning if stale (FR-4.2).

    Performance: YAML loading only, no AI invocation (FR-4.5).

    The loader routes through ``ensure_charter_bundle_fresh`` and anchors
    every subsequent path on the returned ``canonical_root``, so worktree
    callers read the main-checkout bundle that the chokepoint materialized
    (FR-010). Callers therefore do not need to pre-resolve the canonical
    root themselves.

    Args:
        repo_root: Repository root directory (may be a worktree path).

    Returns:
        GovernanceConfig instance (empty if file missing)
    """
    refresh_result = ensure_charter_bundle_fresh(repo_root)
    bundle_root = _resolve_bundle_root(repo_root, refresh_result)
    charter_dir = bundle_root / _KITTIFY_DIRNAME / _CHARTER_DIRNAME
    charter_path = charter_dir / _CHARTER_FILENAME
    governance_path = charter_dir / _GOVERNANCE_FILENAME

    if not governance_path.exists():
        if charter_path.exists():
            logger.warning("governance.yaml unavailable after charter auto-sync. Using empty governance config.")
        else:
            logger.warning("governance.yaml not found and charter.md is absent. Using empty governance config.")
        return GovernanceConfig()

    # Check staleness
    metadata_path = charter_dir / _METADATA_FILENAME
    if charter_path.exists() and metadata_path.exists():
        stale, _, _ = is_stale(charter_path, metadata_path)
        if stale:
            if refresh_result and refresh_result.error:
                logger.warning("Charter bundle is stale after auto-sync failure. Using last synced governance config.")
            else:
                logger.warning("Charter bundle remains stale. Using last synced governance config.")

    # Load and validate
    yaml = YAML()
    data = yaml.load(governance_path)
    return GovernanceConfig.model_validate(data)


def load_directives_config(repo_root: Path) -> DirectivesConfig:
    """Load directives config from .kittify/charter/directives.yaml.

    Falls back to empty DirectivesConfig if file missing.
    Checks staleness and logs warning if stale.

    The loader routes through ``ensure_charter_bundle_fresh`` and anchors
    every subsequent path on the returned ``canonical_root``, so worktree
    callers read the main-checkout bundle that the chokepoint materialized
    (FR-010).

    Args:
        repo_root: Repository root directory (may be a worktree path).

    Returns:
        DirectivesConfig instance (empty if file missing)
    """
    refresh_result = ensure_charter_bundle_fresh(repo_root)
    bundle_root = _resolve_bundle_root(repo_root, refresh_result)
    charter_dir = bundle_root / _KITTIFY_DIRNAME / _CHARTER_DIRNAME
    charter_path = charter_dir / _CHARTER_FILENAME
    directives_path = charter_dir / _DIRECTIVES_FILENAME

    if not directives_path.exists():
        if charter_path.exists():
            logger.warning("directives.yaml unavailable after charter auto-sync. Using empty directives config.")
        else:
            logger.warning("directives.yaml not found and charter.md is absent. Using empty directives config.")
        return DirectivesConfig()

    metadata_path = charter_dir / _METADATA_FILENAME
    if charter_path.exists() and metadata_path.exists():
        stale, _, _ = is_stale(charter_path, metadata_path)
        if stale:
            if refresh_result and refresh_result.error:
                logger.warning("Charter bundle is stale after auto-sync failure. Using last synced directives config.")
            else:
                logger.warning("Charter bundle remains stale. Using last synced directives config.")

    yaml = YAML()
    data = yaml.load(directives_path)
    return DirectivesConfig.model_validate(data)
