"""Shipped toolguide artifacts."""

