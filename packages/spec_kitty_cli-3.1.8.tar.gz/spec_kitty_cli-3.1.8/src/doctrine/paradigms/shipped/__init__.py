"""Shipped paradigm artifacts."""

