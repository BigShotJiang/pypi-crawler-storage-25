"""Import candidate module."""
