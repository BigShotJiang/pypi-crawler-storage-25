"""Shipped procedure artifacts."""
