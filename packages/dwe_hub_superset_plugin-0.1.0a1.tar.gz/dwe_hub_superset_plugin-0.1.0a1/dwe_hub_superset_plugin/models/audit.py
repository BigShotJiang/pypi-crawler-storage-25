"""
AuditLog model for comprehensive audit trail.
"""

from datetime import datetime

from sqlalchemy import Column, DateTime, ForeignKey, Index, Integer, String, Text, func
from sqlalchemy.orm import relationship

from dwe_hub_superset_plugin.models.base import Base


class AuditLog(Base):
    """
    Comprehensive audit trail for all migration activities.
    """

    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    migration_id = Column(
        Integer,
        ForeignKey("dashboard_migrations.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    action = Column(String(50), nullable=False, index=True)
    user_name = Column(String(255), nullable=False, index=True)
    details = Column(Text, nullable=True)  # JSON stored as text
    ip_address = Column(String(45), nullable=True)
    timestamp = Column(DateTime, default=func.now(), nullable=False, index=True)

    migration = relationship("DashboardMigration", back_populates="audit_logs")

    __table_args__ = (
        Index("idx_audit_user_action", "user_name", "action"),
    )

    def __repr__(self):
        return f"<AuditLog(id={self.id}, action='{self.action}', user='{self.user_name}')>"

    def to_dict(self):
        import json
        details_parsed = None
        if self.details:
            try:
                details_parsed = json.loads(self.details)
            except:
                details_parsed = self.details

        return {
            "id": self.id,
            "migration_id": self.migration_id,
            "action": self.action,
            "user_name": self.user_name,
            "details": details_parsed,
            "ip_address": self.ip_address,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }

    @classmethod
    def log_action(cls, session, action, user_name, migration_id=None, details=None, ip_address=None):
        import json
        details_str = json.dumps(details) if details else None

        log_entry = cls(
            action=action,
            user_name=user_name,
            migration_id=migration_id,
            details=details_str,
            ip_address=ip_address,
        )
        session.add(log_entry)
        return log_entry

    @classmethod
    def get_recent_activity(cls, session, limit=100, user_name=None, action=None):
        query = session.query(cls).order_by(cls.timestamp.desc())

        if user_name:
            query = query.filter(cls.user_name == user_name)

        if action:
            query = query.filter(cls.action == action)

        return query.limit(limit).all()

    @classmethod
    def get_migration_activity(cls, session, migration_id):
        return (
            session.query(cls)
            .filter(cls.migration_id == migration_id)
            .order_by(cls.timestamp.asc())
            .all()
        )


class AuditAction:
    """Constants for audit action types."""

    EXPORT = "export"
    IMPORT = "import"
    MIGRATE = "migrate"
    REVERT = "revert"
    APPROVE = "approve"
    REJECT = "reject"
    VIEW = "view"
    SCREENSHOT = "screenshot"
    LOGIN = "login"
    ERROR = "error"
