"""
ScreenshotLog model for storing visual screenshots.
"""

from datetime import datetime

from sqlalchemy import Column, DateTime, ForeignKey, Index, Integer, LargeBinary, String, func
from sqlalchemy.orm import relationship

from dwe_hub_superset_plugin.models.base import Base


class ScreenshotLog(Base):
    """
    Stores visual screenshots for migration comparisons.
    """

    __tablename__ = "screenshot_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    migration_id = Column(
        Integer,
        ForeignKey("dashboard_migrations.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    screenshot_type = Column(String(20), nullable=False, index=True)  # 'before', 'after', 'diff'
    image_data = Column(LargeBinary, nullable=False)
    environment = Column(String(50), nullable=False)
    captured_at = Column(DateTime, default=func.now(), nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    mime_type = Column(String(50), default="image/png", nullable=False)

    migration = relationship("DashboardMigration", back_populates="screenshots")

    __table_args__ = (
        Index("idx_screenshots_migration_type", "migration_id", "screenshot_type"),
    )

    def __repr__(self):
        return f"<ScreenshotLog(id={self.id}, migration_id={self.migration_id}, type='{self.screenshot_type}')>"

    def to_dict(self, include_data=False):
        import base64

        result = {
            "id": self.id,
            "migration_id": self.migration_id,
            "screenshot_type": self.screenshot_type,
            "environment": self.environment,
            "captured_at": self.captured_at.isoformat() if self.captured_at else None,
            "file_size_bytes": self.file_size_bytes,
            "mime_type": self.mime_type,
        }

        if include_data and self.image_data:
            result["image_data"] = base64.b64encode(self.image_data).decode("utf-8")

        return result

    @classmethod
    def create_from_bytes(cls, migration_id, screenshot_type, image_bytes, environment, mime_type="image/png"):
        if screenshot_type not in ("before", "after", "diff"):
            raise ValueError(f"Invalid screenshot_type: {screenshot_type}")

        return cls(
            migration_id=migration_id,
            screenshot_type=screenshot_type,
            image_data=image_bytes,
            environment=environment,
            file_size_bytes=len(image_bytes),
            mime_type=mime_type,
        )

    def get_image_as_base64(self):
        import base64
        return base64.b64encode(self.image_data).decode("utf-8")

    def get_data_url(self):
        return f"data:{self.mime_type};base64,{self.get_image_as_base64()}"
