"""
DashboardMigration model for tracking migrations between environments.
"""

import enum
from datetime import datetime

from sqlalchemy import Column, DateTime, Enum, Index, Integer, String, Text, func
from sqlalchemy.orm import relationship

from dwe_hub_superset_plugin.models.base import Base


class MigrationStatus(enum.Enum):
    """Status enum for dashboard migrations."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    REVERTED = "reverted"


class DashboardMigration(Base):
    """
    Tracks dashboard migrations between environments.
    """

    __tablename__ = "dashboard_migrations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    dashboard_uuid = Column(String(36), nullable=False, index=True)
    dashboard_name = Column(String(500), nullable=False)
    source_env = Column(String(50), nullable=False)
    target_env = Column(String(50), nullable=False)
    status = Column(
        Enum(
            MigrationStatus,
            name="migration_status",
            values_callable=lambda obj: [e.value for e in obj],
        ),
        default=MigrationStatus.PENDING,
        nullable=False,
        index=True,
    )
    git_commit_sha = Column(String(40), nullable=True)
    yaml_export = Column(Text, nullable=True)
    initiated_by = Column(String(255), nullable=False, index=True)
    initiated_at = Column(DateTime, default=func.now(), nullable=False, index=True)
    completed_at = Column(DateTime, nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)

    # Relationships
    screenshots = relationship(
        "ScreenshotLog",
        back_populates="migration",
        cascade="all, delete-orphan",
        lazy="dynamic",
    )
    audit_logs = relationship(
        "AuditLog",
        back_populates="migration",
        lazy="dynamic",
    )

    __table_args__ = (
        Index("idx_migrations_env", "source_env", "target_env"),
        Index("idx_migrations_dashboard_status", "dashboard_uuid", "status"),
    )

    def __repr__(self):
        return f"<DashboardMigration(id={self.id}, dashboard='{self.dashboard_name}', status={self.status.value})>"

    def to_dict(self):
        return {
            "id": self.id,
            "dashboard_uuid": self.dashboard_uuid,
            "dashboard_name": self.dashboard_name,
            "source_env": self.source_env,
            "target_env": self.target_env,
            "status": self.status.value,
            "git_commit_sha": self.git_commit_sha,
            "initiated_by": self.initiated_by,
            "initiated_at": self.initiated_at.isoformat() if self.initiated_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "error_message": self.error_message,
        }

    def mark_in_progress(self):
        self.status = MigrationStatus.IN_PROGRESS
        self.updated_at = datetime.utcnow()

    def mark_completed(self, commit_sha=None):
        self.status = MigrationStatus.COMPLETED
        self.completed_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
        if commit_sha:
            self.git_commit_sha = commit_sha

    def mark_failed(self, error_message):
        self.status = MigrationStatus.FAILED
        self.error_message = error_message
        self.completed_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()

    def mark_reverted(self):
        self.status = MigrationStatus.REVERTED
        self.updated_at = datetime.utcnow()
