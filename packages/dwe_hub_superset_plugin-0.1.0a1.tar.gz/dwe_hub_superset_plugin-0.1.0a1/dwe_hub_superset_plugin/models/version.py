"""
DashboardVersion model for storing versioned dashboard configurations.
"""

from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, Index, Integer, String, Text, UniqueConstraint, func

from dwe_hub_superset_plugin.models.base import Base


class DashboardVersion(Base):
    """
    Stores versioned snapshots of dashboard configurations.
    """

    __tablename__ = "dashboard_versions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    dashboard_uuid = Column(String(36), nullable=False, index=True)
    version_number = Column(Integer, nullable=False)
    git_commit_sha = Column(String(40), nullable=False, index=True)
    yaml_content = Column(Text, nullable=False)
    created_by = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    is_current = Column(Boolean, default=False, nullable=False)

    __table_args__ = (
        UniqueConstraint("dashboard_uuid", "version_number", name="uq_dashboard_version"),
        Index("idx_versions_current", "dashboard_uuid", "is_current"),
    )

    def __repr__(self):
        return f"<DashboardVersion(id={self.id}, dashboard_uuid='{self.dashboard_uuid}', version={self.version_number})>"

    def to_dict(self):
        return {
            "id": self.id,
            "dashboard_uuid": self.dashboard_uuid,
            "version_number": self.version_number,
            "git_commit_sha": self.git_commit_sha,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "is_current": self.is_current,
        }

    @classmethod
    def get_next_version_number(cls, session, dashboard_uuid):
        max_version = (
            session.query(func.max(cls.version_number))
            .filter(cls.dashboard_uuid == dashboard_uuid)
            .scalar()
        )
        return (max_version or 0) + 1

    @classmethod
    def get_current_version(cls, session, dashboard_uuid):
        return (
            session.query(cls)
            .filter(cls.dashboard_uuid == dashboard_uuid, cls.is_current == True)
            .first()
        )

    def set_as_current(self, session):
        session.query(DashboardVersion).filter(
            DashboardVersion.dashboard_uuid == self.dashboard_uuid,
            DashboardVersion.is_current == True,
            DashboardVersion.id != self.id,
        ).update({"is_current": False})
        self.is_current = True
