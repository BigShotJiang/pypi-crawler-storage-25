"""
Permission decorators and utilities for the Dashboard Migration tool.
"""

import functools
import logging
from typing import Callable, Optional

from flask import current_app, g, jsonify, request

logger = logging.getLogger(__name__)


def get_current_user() -> Optional[dict]:
    """
    Get the current authenticated user from Flask-AppBuilder.

    Returns:
        User dict with 'username', 'roles', etc. or None if not authenticated
    """
    try:
        # Try Flask-AppBuilder's security manager
        from flask_appbuilder import get_current_user as fab_get_current_user

        user = fab_get_current_user()
        if user and user.is_authenticated:
            return {
                "id": user.id,
                "username": user.username,
                "email": getattr(user, "email", None),
                "roles": [role.name for role in user.roles],
                "is_active": user.is_active,
            }
    except Exception as e:
        logger.debug(f"Could not get current user via FAB: {e}")

    # Fallback: Check Flask g object
    if hasattr(g, "user") and g.user:
        return {
            "id": getattr(g.user, "id", None),
            "username": getattr(g.user, "username", "unknown"),
            "roles": [],
        }

    return None


def has_permission(permission_name: str, view_name: str = "MigrationDashboardView") -> bool:
    """
    Check if the current user has a specific permission.

    Args:
        permission_name: Name of the permission (e.g., 'can_migrate_dashboards')
        view_name: Name of the view the permission is associated with

    Returns:
        True if user has the permission, False otherwise
    """
    try:
        from flask_appbuilder import get_current_user as fab_get_current_user

        user = fab_get_current_user()
        if not user or not user.is_authenticated:
            return False

        # Check if user is admin (has all permissions)
        for role in user.roles:
            if role.name in ("Admin", "admin"):
                return True

        # Check specific permission
        security_manager = current_app.extensions.get("appbuilder").sm
        return security_manager.has_access(permission_name, view_name)

    except Exception as e:
        logger.warning(f"Permission check failed: {e}")
        return False


def migration_admin_required(f: Callable) -> Callable:
    """
    Decorator to require 'can_migrate_dashboards' permission.

    Usage:
        @migration_admin_required
        def migrate_dashboard():
            ...
    """

    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        user = get_current_user()

        if not user:
            return jsonify({"error": "Authentication required"}), 401

        if not has_permission("can_migrate_dashboards"):
            logger.warning(
                f"User '{user.get('username')}' attempted unauthorized migration access"
            )
            return jsonify({"error": "Insufficient permissions to perform migrations"}), 403

        return f(*args, **kwargs)

    return decorated_function


def revert_permission_required(f: Callable) -> Callable:
    """
    Decorator to require 'can_revert_migrations' permission.

    Usage:
        @revert_permission_required
        def revert_migration():
            ...
    """

    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        user = get_current_user()

        if not user:
            return jsonify({"error": "Authentication required"}), 401

        if not has_permission("can_revert_migrations"):
            logger.warning(
                f"User '{user.get('username')}' attempted unauthorized revert access"
            )
            return jsonify({"error": "Insufficient permissions to revert migrations"}), 403

        return f(*args, **kwargs)

    return decorated_function


def audit_log_required(action: str) -> Callable:
    """
    Decorator to automatically log actions to the audit log.

    Args:
        action: Action name to log (e.g., 'export', 'import', 'revert')

    Usage:
        @audit_log_required('migrate')
        def migrate_dashboard():
            ...
    """

    def decorator(f: Callable) -> Callable:
        @functools.wraps(f)
        def decorated_function(*args, **kwargs):
            user = get_current_user()
            ip_address = request.remote_addr if request else None

            # Execute the function
            result = f(*args, **kwargs)

            # Log the action (async in production, sync here for simplicity)
            try:
                from dwe_hub_superset_plugin.database import session_scope
                from dwe_hub_superset_plugin.models import AuditLog

                with session_scope() as session:
                    log_entry = AuditLog(
                        action=action,
                        user_name=user.get("username", "unknown") if user else "anonymous",
                        details={
                            "args": str(args)[:500],
                            "kwargs": {k: str(v)[:100] for k, v in kwargs.items()},
                            "result_status": (
                                result[1] if isinstance(result, tuple) else "success"
                            ),
                        },
                        ip_address=ip_address,
                    )
                    session.add(log_entry)

            except Exception as e:
                logger.error(f"Failed to create audit log: {e}")

            return result

        return decorated_function

    return decorator


def get_client_ip() -> str:
    """
    Get the client IP address from the request.

    Returns:
        IP address string
    """
    if not request:
        return "unknown"

    # Check for forwarded headers (reverse proxy)
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()

    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip

    return request.remote_addr or "unknown"
