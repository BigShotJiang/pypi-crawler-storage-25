"""
Screenshot service for capturing dashboard visuals using Playwright.
"""

import asyncio
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class DashboardScreenshotService:
    """
    Service for capturing dashboard screenshots using Playwright.

    Uses headless Chromium to render dashboards and capture full-page screenshots.
    """

    def __init__(self, headless: bool = True, timeout: int = 60000):
        """
        Initialize the screenshot service.

        Args:
            headless: Whether to run browser in headless mode
            timeout: Page load timeout in milliseconds
        """
        self.headless = headless
        self.timeout = timeout
        self._browser = None
        self._playwright = None

    async def _ensure_browser(self):
        """Ensure the browser is initialized."""
        if self._browser is None:
            try:
                from playwright.async_api import async_playwright

                self._playwright = await async_playwright().start()
                self._browser = await self._playwright.chromium.launch(
                    headless=self.headless,
                    args=[
                        "--no-sandbox",
                        "--disable-setuid-sandbox",
                        "--disable-dev-shm-usage",
                        "--disable-gpu",
                    ],
                )
                logger.info("Browser initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize browser: {e}")
                raise

    async def capture_dashboard_async(
        self,
        superset_url: str,
        dashboard_id: int,
        username: str,
        password: str,
        viewport_width: int = 1920,
        viewport_height: int = 1080,
        full_page: bool = True,
        wait_for_charts: bool = True,
    ) -> bytes:
        """
        Capture a screenshot of a Superset dashboard asynchronously.

        Args:
            superset_url: Base URL of the Superset instance
            dashboard_id: Dashboard ID to capture
            username: Superset username for authentication
            password: Superset password
            viewport_width: Browser viewport width
            viewport_height: Browser viewport height
            full_page: Whether to capture full scrollable page
            wait_for_charts: Whether to wait for charts to load

        Returns:
            PNG image data as bytes
        """
        await self._ensure_browser()

        context = await self._browser.new_context(
            viewport={"width": viewport_width, "height": viewport_height},
            ignore_https_errors=True,
        )

        page = await context.new_page()

        try:
            # Login to Superset
            logger.info(f"Logging into Superset at {superset_url}")
            await page.goto(f"{superset_url}/login/", wait_until="networkidle")

            # Fill login form
            await page.fill('input[name="username"]', username)
            await page.fill('input[name="password"]', password)
            await page.click('input[type="submit"]')

            # Wait for login to complete
            await page.wait_for_load_state("networkidle", timeout=self.timeout)

            # Navigate to dashboard
            dashboard_url = f"{superset_url}/superset/dashboard/{dashboard_id}/"
            logger.info(f"Navigating to dashboard: {dashboard_url}")
            await page.goto(dashboard_url, wait_until="networkidle", timeout=self.timeout)

            # Wait for charts to load
            if wait_for_charts:
                logger.info("Waiting for charts to load...")
                try:
                    # Wait for loading indicators to disappear
                    await page.wait_for_selector(
                        ".loading, .chart-container .loading",
                        state="hidden",
                        timeout=30000,
                    )
                except Exception:
                    pass  # Continue if selector not found

                # Additional wait for dynamic content
                await page.wait_for_timeout(3000)

            # Capture screenshot
            logger.info("Capturing screenshot...")
            screenshot_bytes = await page.screenshot(
                full_page=full_page,
                type="png",
            )

            logger.info(f"Screenshot captured: {len(screenshot_bytes)} bytes")
            return screenshot_bytes

        except Exception as e:
            logger.error(f"Failed to capture dashboard screenshot: {e}")
            raise

        finally:
            await page.close()
            await context.close()

    def capture_dashboard(
        self,
        superset_url: str,
        dashboard_id: int,
        username: str,
        password: str,
        **kwargs,
    ) -> bytes:
        """
        Capture a screenshot of a Superset dashboard (sync wrapper).

        Args:
            superset_url: Base URL of the Superset instance
            dashboard_id: Dashboard ID to capture
            username: Superset username for authentication
            password: Superset password
            **kwargs: Additional arguments passed to capture_dashboard_async

        Returns:
            PNG image data as bytes
        """
        return asyncio.get_event_loop().run_until_complete(
            self.capture_dashboard_async(
                superset_url=superset_url,
                dashboard_id=dashboard_id,
                username=username,
                password=password,
                **kwargs,
            )
        )

    async def capture_multiple_dashboards_async(
        self,
        superset_url: str,
        dashboard_ids: list[int],
        username: str,
        password: str,
        **kwargs,
    ) -> dict[int, bytes]:
        """
        Capture screenshots of multiple dashboards concurrently.

        Args:
            superset_url: Base URL of the Superset instance
            dashboard_ids: List of dashboard IDs to capture
            username: Superset username
            password: Superset password
            **kwargs: Additional arguments for capture

        Returns:
            Dict mapping dashboard ID to screenshot bytes
        """
        results = {}

        for dashboard_id in dashboard_ids:
            try:
                screenshot = await self.capture_dashboard_async(
                    superset_url=superset_url,
                    dashboard_id=dashboard_id,
                    username=username,
                    password=password,
                    **kwargs,
                )
                results[dashboard_id] = screenshot
            except Exception as e:
                logger.error(f"Failed to capture dashboard {dashboard_id}: {e}")
                results[dashboard_id] = None

        return results

    async def close_async(self) -> None:
        """Close the browser asynchronously."""
        if self._browser:
            await self._browser.close()
            self._browser = None

        if self._playwright:
            await self._playwright.stop()
            self._playwright = None

        logger.info("Browser closed")

    def close(self) -> None:
        """Close the browser (sync wrapper)."""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(self.close_async())
            else:
                loop.run_until_complete(self.close_async())
        except Exception as e:
            logger.warning(f"Error closing browser: {e}")

    def __enter__(self) -> "DashboardScreenshotService":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()


def capture_dashboard_screenshot(
    superset_url: str,
    dashboard_id: int,
    username: str,
    password: str,
    headless: bool = True,
) -> Optional[bytes]:
    """
    Convenience function to capture a single dashboard screenshot.

    Args:
        superset_url: Base URL of the Superset instance
        dashboard_id: Dashboard ID to capture
        username: Superset username
        password: Superset password
        headless: Whether to run browser in headless mode

    Returns:
        PNG image data as bytes, or None if capture fails
    """
    try:
        with DashboardScreenshotService(headless=headless) as service:
            return service.capture_dashboard(
                superset_url=superset_url,
                dashboard_id=dashboard_id,
                username=username,
                password=password,
            )
    except Exception as e:
        logger.error(f"Screenshot capture failed: {e}")
        return None
