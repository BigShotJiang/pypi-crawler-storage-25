"""
Dataset metadata extractor for Superset export ZIPs.

Parses Superset dashboard export files and extracts dataset information
including columns and metrics for compatibility validation.
"""

import io
import logging
import zipfile
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)


class DatasetExtractor:
    """Extracts dataset metadata from Superset export ZIPs."""

    @staticmethod
    def extract_from_zip(zip_content: bytes) -> List[Dict[str, Any]]:
        """
        Parse Superset export ZIP and extract all dataset metadata.

        Args:
            zip_content: Raw bytes of the Superset export ZIP file

        Returns:
            List of dataset snapshots with columns and metrics.
            Each snapshot contains:
            - uuid: Dataset UUID
            - table_name: Physical table name
            - schema: Database schema
            - database_uuid: UUID of the database connection
            - database_name: Name of the database connection
            - columns: List of column definitions
            - metrics: List of metric definitions
            - sql: SQL for virtual datasets (if applicable)
        """
        datasets = []
        databases: Dict[str, str] = {}  # uuid -> name mapping

        try:
            with zipfile.ZipFile(io.BytesIO(zip_content)) as zf:
                # First pass: collect database names
                for name in zf.namelist():
                    if '/databases/' in name and name.endswith('.yaml'):
                        try:
                            content = zf.read(name).decode('utf-8')
                            db_data = yaml.safe_load(content)
                            if db_data and isinstance(db_data, dict) and 'uuid' in db_data:
                                databases[db_data['uuid']] = db_data.get('database_name', 'Unknown')
                        except Exception as e:
                            logger.warning(f"Failed to parse database file {name}: {e}")

                # Second pass: extract datasets
                for name in zf.namelist():
                    if '/datasets/' in name and name.endswith('.yaml'):
                        try:
                            content = zf.read(name).decode('utf-8')
                            ds_data = yaml.safe_load(content)

                            if not ds_data or not isinstance(ds_data, dict):
                                continue

                            dataset = DatasetExtractor._parse_dataset(ds_data, databases)
                            if dataset:
                                datasets.append(dataset)

                        except Exception as e:
                            logger.warning(f"Failed to parse dataset file {name}: {e}")

        except zipfile.BadZipFile as e:
            logger.error(f"Invalid ZIP file: {e}")
        except Exception as e:
            logger.error(f"Error extracting datasets from ZIP: {e}")

        logger.info(f"Extracted {len(datasets)} datasets from export")
        return datasets

    @staticmethod
    def _parse_dataset(ds_data: Dict[str, Any], databases: Dict[str, str]) -> Optional[Dict[str, Any]]:
        """
        Parse a single dataset YAML into a snapshot dict.

        Args:
            ds_data: Parsed YAML content of a dataset file
            databases: Mapping of database UUID to database name

        Returns:
            Dataset snapshot dict or None if parsing fails
        """
        if not ds_data.get('uuid'):
            return None

        database_uuid = ds_data.get('database_uuid')

        dataset = {
            'uuid': ds_data.get('uuid'),
            'table_name': ds_data.get('table_name'),
            'schema': ds_data.get('schema'),
            'database_uuid': database_uuid,
            'database_name': databases.get(database_uuid, 'Unknown'),
            'sql': ds_data.get('sql'),  # For virtual datasets
            'columns': [],
            'metrics': [],
        }

        # Extract columns
        for col in ds_data.get('columns', []):
            if isinstance(col, dict):
                dataset['columns'].append({
                    'column_name': col.get('column_name'),
                    'type': col.get('type'),
                    'is_dttm': col.get('is_dttm', False),
                    'description': col.get('description'),
                    'filterable': col.get('filterable', True),
                    'groupby': col.get('groupby', True),
                })

        # Extract metrics
        for metric in ds_data.get('metrics', []):
            if isinstance(metric, dict):
                dataset['metrics'].append({
                    'metric_name': metric.get('metric_name'),
                    'expression': metric.get('expression'),
                    'verbose_name': metric.get('verbose_name'),
                    'description': metric.get('description'),
                    'metric_type': metric.get('metric_type'),
                })

        return dataset

    @staticmethod
    def get_dataset_summary(datasets: List[Dict[str, Any]]) -> str:
        """
        Generate a human-readable summary of datasets.

        Args:
            datasets: List of dataset snapshots

        Returns:
            Formatted string summary
        """
        if not datasets:
            return "No datasets"

        parts = []
        for ds in datasets:
            name = ds.get('table_name', 'Unknown')
            schema = ds.get('schema')
            if schema:
                name = f"{schema}.{name}"

            col_count = len(ds.get('columns', []))
            metric_count = len(ds.get('metrics', []))

            parts.append(f"{name} ({col_count} cols, {metric_count} metrics)")

        return "; ".join(parts)
