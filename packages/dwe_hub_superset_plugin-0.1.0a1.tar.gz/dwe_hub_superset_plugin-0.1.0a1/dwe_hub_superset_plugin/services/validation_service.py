"""
Dataset validation service for import compatibility checking.

Validates that datasets required by a Hub dashboard exist and are compatible
with the local Superset environment before import.
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class ValidationIssue:
    """Represents a single validation issue."""

    severity: str  # "critical", "warning", "info"
    dataset_uuid: str
    dataset_name: str
    message: str
    column_name: Optional[str] = None
    expected: Optional[str] = None
    actual: Optional[str] = None
    details: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "severity": self.severity,
            "dataset_uuid": self.dataset_uuid,
            "dataset_name": self.dataset_name,
            "message": self.message,
        }
        if self.column_name:
            result["column_name"] = self.column_name
        if self.expected:
            result["expected"] = self.expected
        if self.actual:
            result["actual"] = self.actual
        if self.details:
            result["details"] = self.details
        return result


@dataclass
class ValidationResult:
    """Result of dataset validation."""

    valid: bool  # True if no critical issues
    can_override: bool  # True if admin can override
    issues: List[ValidationIssue] = field(default_factory=list)

    @property
    def critical_count(self) -> int:
        return len([i for i in self.issues if i.severity == "critical"])

    @property
    def warning_count(self) -> int:
        return len([i for i in self.issues if i.severity == "warning"])

    @property
    def info_count(self) -> int:
        return len([i for i in self.issues if i.severity == "info"])

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "valid": self.valid,
            "can_override": self.can_override,
            "issues": [i.to_dict() for i in self.issues],
            "critical_count": self.critical_count,
            "warning_count": self.warning_count,
            "info_count": self.info_count,
        }


class DatasetValidationService:
    """Validates dataset compatibility between Hub snapshots and local Superset."""

    def validate(
        self,
        hub_datasets: List[Dict[str, Any]],
        local_datasets: List[Dict[str, Any]],
        local_databases: Optional[List[Dict[str, Any]]] = None,
    ) -> ValidationResult:
        """
        Compare Hub snapshots against local datasets and databases.

        Validation checks:
        - CRITICAL: Dataset not found locally (by UUID or name/schema)
        - CRITICAL: Database connection not found locally
        - WARNING: Column missing locally
        - WARNING: Column type mismatch
        - WARNING: Metric missing locally
        - INFO: Extra column exists locally

        Args:
            hub_datasets: Dataset snapshots from the Hub version
            local_datasets: Dataset info from local Superset instance
            local_databases: Database connections from local Superset instance

        Returns:
            ValidationResult with issues and validity status
        """
        issues: List[ValidationIssue] = []
        has_critical = False

        if not hub_datasets:
            # No datasets to validate - always valid
            return ValidationResult(valid=True, can_override=False, issues=[])

        # Validate database connections first
        if local_databases is not None:
            db_issues, db_critical = self._validate_databases(hub_datasets, local_databases)
            issues.extend(db_issues)
            if db_critical:
                has_critical = True

        # Build local dataset lookup by UUID
        # Use matched_hub_uuid if available (from fallback matching by name/schema)
        # Otherwise use the dataset's own UUID
        local_by_uuid = {}
        for ds in local_datasets:
            # Prefer matched_hub_uuid (set when matched by name/schema fallback)
            lookup_key = ds.get("matched_hub_uuid") or ds.get("uuid")
            if lookup_key:
                local_by_uuid[lookup_key] = ds

        for hub_ds in hub_datasets:
            hub_uuid = hub_ds.get("uuid")
            if not hub_uuid:
                continue

            hub_name = hub_ds.get("table_name", "Unknown")
            hub_schema = hub_ds.get("schema")
            full_name = f"{hub_schema}.{hub_name}" if hub_schema else hub_name

            local_ds = local_by_uuid.get(hub_uuid)

            if not local_ds:
                # Critical: Dataset not found locally
                issues.append(ValidationIssue(
                    severity="critical",
                    dataset_uuid=hub_uuid,
                    dataset_name=full_name,
                    message=f"Dataset '{full_name}' not found in target environment",
                    details={
                        "database_name": hub_ds.get("database_name"),
                        "database_uuid": hub_ds.get("database_uuid"),
                    }
                ))
                has_critical = True
                continue

            # Validate columns
            column_issues = self._validate_columns(hub_ds, local_ds, hub_uuid, full_name)
            issues.extend(column_issues)

            # Validate metrics
            metric_issues = self._validate_metrics(hub_ds, local_ds, hub_uuid, full_name)
            issues.extend(metric_issues)

        return ValidationResult(
            valid=not has_critical,
            can_override=True,  # Admins can override warnings
            issues=issues,
        )

    def _validate_columns(
        self,
        hub_ds: Dict[str, Any],
        local_ds: Dict[str, Any],
        hub_uuid: str,
        full_name: str,
    ) -> List[ValidationIssue]:
        """Validate columns between hub and local datasets."""
        issues = []

        hub_columns = {c.get("column_name"): c for c in hub_ds.get("columns", [])}
        local_columns = {c.get("column_name"): c for c in local_ds.get("columns", [])}

        # Check for missing columns and type mismatches
        for col_name, hub_col in hub_columns.items():
            if not col_name:
                continue

            if col_name not in local_columns:
                issues.append(ValidationIssue(
                    severity="warning",
                    dataset_uuid=hub_uuid,
                    dataset_name=full_name,
                    message=f"Column '{col_name}' missing locally",
                    column_name=col_name,
                    expected=hub_col.get("type"),
                    actual=None,
                ))
            else:
                # Check type compatibility
                local_col = local_columns[col_name]
                type_issue = self._check_column_type(
                    hub_col, local_col, hub_uuid, full_name, col_name
                )
                if type_issue:
                    issues.append(type_issue)

        # Check for extra columns locally (informational)
        for col_name in local_columns:
            if col_name and col_name not in hub_columns:
                issues.append(ValidationIssue(
                    severity="info",
                    dataset_uuid=hub_uuid,
                    dataset_name=full_name,
                    message=f"Extra column '{col_name}' exists locally",
                    column_name=col_name,
                ))

        return issues

    def _check_column_type(
        self,
        hub_col: Dict[str, Any],
        local_col: Dict[str, Any],
        hub_uuid: str,
        full_name: str,
        col_name: str,
    ) -> Optional[ValidationIssue]:
        """Check if column types are compatible."""
        hub_type = (hub_col.get("type") or "").upper()
        local_type = (local_col.get("type") or "").upper()

        if not hub_type or not local_type:
            return None

        # Normalize types by stripping precision/length info
        hub_base = hub_type.split("(")[0].strip()
        local_base = local_type.split("(")[0].strip()

        # Type equivalence mapping for common compatible types
        type_equivalents = {
            "INT": {"INTEGER", "INT", "BIGINT", "SMALLINT"},
            "INTEGER": {"INTEGER", "INT", "BIGINT", "SMALLINT"},
            "BIGINT": {"INTEGER", "INT", "BIGINT"},
            "VARCHAR": {"VARCHAR", "TEXT", "STRING", "CHAR"},
            "TEXT": {"VARCHAR", "TEXT", "STRING"},
            "STRING": {"VARCHAR", "TEXT", "STRING"},
            "FLOAT": {"FLOAT", "DOUBLE", "REAL", "DECIMAL", "NUMERIC"},
            "DOUBLE": {"FLOAT", "DOUBLE", "REAL", "DECIMAL", "NUMERIC"},
            "DECIMAL": {"FLOAT", "DOUBLE", "DECIMAL", "NUMERIC"},
            "BOOL": {"BOOL", "BOOLEAN"},
            "BOOLEAN": {"BOOL", "BOOLEAN"},
            "DATE": {"DATE", "DATETIME", "TIMESTAMP"},
            "DATETIME": {"DATE", "DATETIME", "TIMESTAMP"},
            "TIMESTAMP": {"DATE", "DATETIME", "TIMESTAMP"},
        }

        # Check if types are equivalent
        hub_equivalents = type_equivalents.get(hub_base, {hub_base})
        if local_base not in hub_equivalents:
            return ValidationIssue(
                severity="warning",
                dataset_uuid=hub_uuid,
                dataset_name=full_name,
                message=f"Column '{col_name}' type mismatch",
                column_name=col_name,
                expected=hub_type,
                actual=local_type,
            )

        return None

    def _validate_metrics(
        self,
        hub_ds: Dict[str, Any],
        local_ds: Dict[str, Any],
        hub_uuid: str,
        full_name: str,
    ) -> List[ValidationIssue]:
        """Validate metrics between hub and local datasets."""
        issues = []

        hub_metrics = {m.get("metric_name"): m for m in hub_ds.get("metrics", [])}
        local_metrics = {m.get("metric_name"): m for m in local_ds.get("metrics", [])}

        for metric_name, hub_metric in hub_metrics.items():
            if not metric_name:
                continue

            if metric_name not in local_metrics:
                issues.append(ValidationIssue(
                    severity="warning",
                    dataset_uuid=hub_uuid,
                    dataset_name=full_name,
                    message=f"Metric '{metric_name}' missing locally",
                    details={
                        "expression": hub_metric.get("expression"),
                    }
                ))

        return issues

    def _validate_databases(
        self,
        hub_datasets: List[Dict[str, Any]],
        local_databases: List[Dict[str, Any]],
    ) -> Tuple[List[ValidationIssue], bool]:
        """
        Validate that required database connections exist locally.

        Args:
            hub_datasets: Dataset snapshots containing database_name
            local_databases: List of local database connections

        Returns:
            Tuple of (issues list, has_critical flag)
        """
        issues = []
        has_critical = False

        # Build lookup of local database names
        local_db_names = {db.get("database_name") for db in local_databases if db.get("database_name")}

        # Track which databases we've already checked to avoid duplicates
        checked_databases = set()

        for hub_ds in hub_datasets:
            db_name = hub_ds.get("database_name")
            if not db_name or db_name in checked_databases:
                continue

            checked_databases.add(db_name)

            if db_name not in local_db_names:
                issues.append(ValidationIssue(
                    severity="critical",
                    dataset_uuid="",
                    dataset_name=db_name,
                    message=f"Database connection '{db_name}' not found in target environment",
                    details={
                        "required_by": [
                            ds.get("table_name")
                            for ds in hub_datasets
                            if ds.get("database_name") == db_name
                        ]
                    }
                ))
                has_critical = True

        return issues, has_critical

    def format_issues_html(self, issues: List[ValidationIssue]) -> str:
        """
        Format validation issues as HTML for display in the UI.

        Args:
            issues: List of validation issues

        Returns:
            HTML string for display
        """
        if not issues:
            return ""

        critical = [i for i in issues if i.severity == "critical"]
        warnings = [i for i in issues if i.severity == "warning"]
        info = [i for i in issues if i.severity == "info"]

        html_parts = []

        if critical:
            html_parts.append('<div class="validation-critical">')
            html_parts.append('<h4 style="color: #c62828;">Critical Issues</h4>')
            html_parts.append('<ul>')
            for issue in critical:
                html_parts.append(f'<li><strong>{issue.dataset_name}</strong>: {issue.message}</li>')
            html_parts.append('</ul>')
            html_parts.append('</div>')

        if warnings:
            html_parts.append('<div class="validation-warnings">')
            html_parts.append('<h4 style="color: #f57c00;">Warnings</h4>')
            html_parts.append('<ul>')
            for issue in warnings:
                details = ""
                if issue.expected and issue.actual:
                    details = f" (expected: {issue.expected}, found: {issue.actual})"
                html_parts.append(f'<li><strong>{issue.dataset_name}</strong>: {issue.message}{details}</li>')
            html_parts.append('</ul>')
            html_parts.append('</div>')

        if info:
            html_parts.append('<div class="validation-info">')
            html_parts.append('<h4 style="color: #1565c0;">Info</h4>')
            html_parts.append('<ul>')
            for issue in info:
                html_parts.append(f'<li><strong>{issue.dataset_name}</strong>: {issue.message}</li>')
            html_parts.append('</ul>')
            html_parts.append('</div>')

        return "\n".join(html_parts)
