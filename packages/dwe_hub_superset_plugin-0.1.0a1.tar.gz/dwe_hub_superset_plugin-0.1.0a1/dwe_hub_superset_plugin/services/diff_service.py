"""
Visual diff service for comparing dashboard screenshots.
Uses Pillow for image processing.
"""

import io
import logging
from dataclasses import dataclass
from typing import Optional, Tuple

from PIL import Image, ImageChops, ImageDraw, ImageFilter

logger = logging.getLogger(__name__)


@dataclass
class DiffResult:
    """Result of image comparison."""

    are_identical: bool
    diff_percentage: float
    diff_pixels: int
    total_pixels: int
    diff_image: Optional[bytes]  # PNG bytes of diff image


class VisualDiffService:
    """
    Service for comparing dashboard screenshots and generating visual diffs.

    Uses Pillow for image processing with pixel-level comparison.
    """

    def __init__(
        self,
        highlight_color: Tuple[int, int, int] = (255, 0, 255),  # Magenta
        threshold: int = 30,  # Color difference threshold
    ):
        """
        Initialize the visual diff service.

        Args:
            highlight_color: RGB color for highlighting differences
            threshold: Color difference threshold (0-255)
        """
        self.highlight_color = highlight_color
        self.threshold = threshold

    def compare_images(
        self,
        before_bytes: bytes,
        after_bytes: bytes,
        generate_diff_image: bool = True,
    ) -> DiffResult:
        """
        Compare two images and optionally generate a diff image.

        Args:
            before_bytes: PNG bytes of the "before" image
            after_bytes: PNG bytes of the "after" image
            generate_diff_image: Whether to generate a visual diff

        Returns:
            DiffResult with comparison results
        """
        # Load images
        before_img = Image.open(io.BytesIO(before_bytes)).convert("RGB")
        after_img = Image.open(io.BytesIO(after_bytes)).convert("RGB")

        # Resize if dimensions don't match
        if before_img.size != after_img.size:
            logger.warning(
                f"Image sizes differ: {before_img.size} vs {after_img.size}. Resizing."
            )
            # Resize to the larger dimensions
            max_width = max(before_img.width, after_img.width)
            max_height = max(before_img.height, after_img.height)

            before_img = before_img.resize((max_width, max_height), Image.Resampling.LANCZOS)
            after_img = after_img.resize((max_width, max_height), Image.Resampling.LANCZOS)

        # Calculate difference
        diff = ImageChops.difference(before_img, after_img)

        # Convert to grayscale for threshold detection
        diff_gray = diff.convert("L")

        # Count different pixels
        total_pixels = diff_gray.width * diff_gray.height
        diff_pixels = 0

        for pixel in diff_gray.getdata():
            if pixel > self.threshold:
                diff_pixels += 1

        diff_percentage = (diff_pixels / total_pixels) * 100 if total_pixels > 0 else 0
        are_identical = diff_pixels == 0

        # Generate diff image if requested
        diff_image_bytes = None
        if generate_diff_image and not are_identical:
            diff_image_bytes = self._generate_diff_image(before_img, after_img, diff_gray)

        return DiffResult(
            are_identical=are_identical,
            diff_percentage=round(diff_percentage, 2),
            diff_pixels=diff_pixels,
            total_pixels=total_pixels,
            diff_image=diff_image_bytes,
        )

    def _generate_diff_image(
        self,
        before_img: Image.Image,
        after_img: Image.Image,
        diff_gray: Image.Image,
    ) -> bytes:
        """
        Generate a visual diff image highlighting changes.

        Creates a side-by-side comparison with differences highlighted.

        Args:
            before_img: The "before" image
            after_img: The "after" image
            diff_gray: Grayscale difference image

        Returns:
            PNG bytes of the diff image
        """
        width = before_img.width
        height = before_img.height

        # Create a composite diff image
        # Option 1: Overlay diff on after image
        diff_overlay = after_img.copy()
        draw = ImageDraw.Draw(diff_overlay)

        # Create highlight mask
        highlight_mask = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        mask_draw = ImageDraw.Draw(highlight_mask)

        # Highlight different pixels
        diff_data = list(diff_gray.getdata())
        for i, pixel in enumerate(diff_data):
            if pixel > self.threshold:
                x = i % width
                y = i // width
                mask_draw.point(
                    (x, y),
                    fill=(*self.highlight_color, 180),  # Semi-transparent
                )

        # Dilate the mask to make differences more visible
        highlight_mask = highlight_mask.filter(ImageFilter.MaxFilter(5))

        # Composite
        diff_overlay = Image.alpha_composite(
            diff_overlay.convert("RGBA"),
            highlight_mask,
        )

        # Create side-by-side comparison
        total_width = width * 3 + 20  # before + after + diff + gaps
        combined = Image.new("RGB", (total_width, height + 40), (255, 255, 255))

        # Add labels
        draw = ImageDraw.Draw(combined)

        # Paste images
        combined.paste(before_img, (0, 40))
        combined.paste(after_img, (width + 10, 40))
        combined.paste(diff_overlay.convert("RGB"), (width * 2 + 20, 40))

        # Add labels
        draw.text((width // 2 - 30, 10), "BEFORE", fill=(0, 0, 0))
        draw.text((width + 10 + width // 2 - 25, 10), "AFTER", fill=(0, 0, 0))
        draw.text((width * 2 + 20 + width // 2 - 20, 10), "DIFF", fill=(0, 0, 0))

        # Convert to bytes
        output = io.BytesIO()
        combined.save(output, format="PNG", optimize=True)
        return output.getvalue()

    def generate_diff_report(
        self,
        before_bytes: bytes,
        after_bytes: bytes,
        dashboard_name: str = "Dashboard",
    ) -> dict:
        """
        Generate a comprehensive diff report.

        Args:
            before_bytes: PNG bytes of the "before" image
            after_bytes: PNG bytes of the "after" image
            dashboard_name: Name of the dashboard for the report

        Returns:
            Dict with report data including images as base64
        """
        import base64

        result = self.compare_images(before_bytes, after_bytes)

        report = {
            "dashboard_name": dashboard_name,
            "are_identical": result.are_identical,
            "diff_percentage": result.diff_percentage,
            "diff_pixels": result.diff_pixels,
            "total_pixels": result.total_pixels,
            "before_image": base64.b64encode(before_bytes).decode("utf-8"),
            "after_image": base64.b64encode(after_bytes).decode("utf-8"),
            "diff_image": (
                base64.b64encode(result.diff_image).decode("utf-8")
                if result.diff_image
                else None
            ),
        }

        return report

    def create_comparison_gif(
        self,
        before_bytes: bytes,
        after_bytes: bytes,
        duration: int = 1000,
    ) -> bytes:
        """
        Create an animated GIF toggling between before and after.

        Args:
            before_bytes: PNG bytes of the "before" image
            after_bytes: PNG bytes of the "after" image
            duration: Frame duration in milliseconds

        Returns:
            GIF bytes
        """
        before_img = Image.open(io.BytesIO(before_bytes))
        after_img = Image.open(io.BytesIO(after_bytes))

        # Ensure same size
        if before_img.size != after_img.size:
            max_width = max(before_img.width, after_img.width)
            max_height = max(before_img.height, after_img.height)
            before_img = before_img.resize((max_width, max_height), Image.Resampling.LANCZOS)
            after_img = after_img.resize((max_width, max_height), Image.Resampling.LANCZOS)

        # Convert to P mode for GIF
        before_img = before_img.convert("P", palette=Image.Palette.ADAPTIVE)
        after_img = after_img.convert("P", palette=Image.Palette.ADAPTIVE)

        # Create GIF
        output = io.BytesIO()
        before_img.save(
            output,
            format="GIF",
            save_all=True,
            append_images=[after_img],
            duration=duration,
            loop=0,
        )

        return output.getvalue()


def compare_screenshots(before_bytes: bytes, after_bytes: bytes) -> DiffResult:
    """
    Convenience function to compare two screenshots.

    Args:
        before_bytes: PNG bytes of the "before" image
        after_bytes: PNG bytes of the "after" image

    Returns:
        DiffResult with comparison results
    """
    service = VisualDiffService()
    return service.compare_images(before_bytes, after_bytes)
