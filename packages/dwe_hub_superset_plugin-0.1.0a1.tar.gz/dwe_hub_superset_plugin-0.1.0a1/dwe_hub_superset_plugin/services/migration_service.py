"""
Migration service - orchestrates dashboard migrations between environments.
"""

import logging
from datetime import datetime
from typing import Optional

from dwe_hub_superset_plugin.config import MigrationConfig, get_config
from dwe_hub_superset_plugin.database import get_session, session_scope
from dwe_hub_superset_plugin.models import (
    AuditLog,
    DashboardMigration,
    DashboardVersion,
    MigrationStatus,
    ScreenshotLog,
)
from dwe_hub_superset_plugin.models.audit import AuditAction
from dwe_hub_superset_plugin.services.diff_service import VisualDiffService
from dwe_hub_superset_plugin.services.git_service import GitDashboardManager
from dwe_hub_superset_plugin.services.screenshot_service import DashboardScreenshotService
from dwe_hub_superset_plugin.services.superset_api import (
    DashboardInfo,
    SupersetAPIClient,
    SupersetAPIError,
)

logger = logging.getLogger(__name__)


class MigrationService:
    """
    Orchestrates dashboard migrations between Superset environments.

    Coordinates git versioning, screenshot capture, visual diffs,
    and audit logging during the migration process.
    """

    def __init__(
        self,
        config: Optional[MigrationConfig] = None,
        dev_client: Optional[SupersetAPIClient] = None,
        prod_client: Optional[SupersetAPIClient] = None,
        git_manager: Optional[GitDashboardManager] = None,
        screenshot_service: Optional[DashboardScreenshotService] = None,
        diff_service: Optional[VisualDiffService] = None,
    ):
        """
        Initialize the migration service.

        Args:
            config: Migration configuration (uses global config if None)
            dev_client: Superset API client for dev environment
            prod_client: Superset API client for prod environment
            git_manager: Git repository manager
            screenshot_service: Screenshot capture service
            diff_service: Visual diff service
        """
        self.config = config or get_config()

        # Initialize API clients
        self.dev_client = dev_client or SupersetAPIClient(
            base_url=self.config.dev_superset_url,
            username=self.config.superset_username,
            password=self.config.superset_password,
        )
        self.prod_client = prod_client or SupersetAPIClient(
            base_url=self.config.prod_superset_url,
            username=self.config.superset_username,
            password=self.config.superset_password,
        )

        # Initialize services
        self.git_manager = git_manager or GitDashboardManager(
            repo_path=self.config.git_repo_path
        )
        self.screenshot_service = screenshot_service or (
            DashboardScreenshotService(headless=self.config.headless_browser)
            if self.config.screenshot_enabled
            else None
        )
        self.diff_service = diff_service or VisualDiffService()

    def list_dashboards(self, environment: str = "dev") -> list[DashboardInfo]:
        """
        List dashboards in an environment.

        Args:
            environment: 'dev' or 'prod'

        Returns:
            List of DashboardInfo objects
        """
        client = self.dev_client if environment == "dev" else self.prod_client
        return client.list_dashboards()

    def get_dashboard(self, dashboard_id: int, environment: str = "dev") -> DashboardInfo:
        """
        Get a specific dashboard.

        Args:
            dashboard_id: Dashboard ID
            environment: 'dev' or 'prod'

        Returns:
            DashboardInfo object
        """
        client = self.dev_client if environment == "dev" else self.prod_client
        return client.get_dashboard(dashboard_id)

    def initiate_migration(
        self,
        dashboard_id: int,
        user: str,
        source_env: str = "dev",
        target_env: str = "prod",
        ip_address: Optional[str] = None,
    ) -> int:
        """
        Initiate a dashboard migration.

        Creates a migration record in the database.

        Args:
            dashboard_id: Dashboard ID to migrate
            user: Username initiating the migration
            source_env: Source environment ('dev')
            target_env: Target environment ('prod')
            ip_address: Client IP address for audit

        Returns:
            Migration ID
        """
        with session_scope() as session:
            # Get dashboard info from source
            client = self.dev_client if source_env == "dev" else self.prod_client
            dashboard = client.get_dashboard(dashboard_id)

            # Create migration record
            migration = DashboardMigration(
                dashboard_uuid=dashboard.uuid,
                dashboard_name=dashboard.dashboard_title,
                source_env=source_env,
                target_env=target_env,
                status=MigrationStatus.PENDING,
                initiated_by=user,
                initiated_at=datetime.utcnow(),
            )
            session.add(migration)
            session.flush()  # Get the ID

            # Create audit log
            AuditLog.log_action(
                session=session,
                action=AuditAction.MIGRATE,
                user_name=user,
                migration_id=migration.id,
                details={
                    "dashboard_id": dashboard_id,
                    "dashboard_name": dashboard.dashboard_title,
                    "source_env": source_env,
                    "target_env": target_env,
                    "action": "initiated",
                },
                ip_address=ip_address,
            )

            logger.info(
                f"Migration initiated: {dashboard.dashboard_title} "
                f"({source_env} -> {target_env}) by {user}"
            )

            return migration.id

    def execute_migration(
        self,
        migration_id: int,
        capture_screenshots: bool = True,
    ) -> bool:
        """
        Execute a pending migration.

        Args:
            migration_id: Migration ID to execute
            capture_screenshots: Whether to capture before/after screenshots

        Returns:
            True if migration was successful
        """
        with session_scope() as session:
            migration = session.get(DashboardMigration, migration_id)
            if not migration:
                raise ValueError(f"Migration {migration_id} not found")

            if migration.status != MigrationStatus.PENDING:
                raise ValueError(
                    f"Migration {migration_id} is not pending (status: {migration.status.value})"
                )

            # Mark as in progress
            migration.mark_in_progress()
            session.commit()

            try:
                # Get clients based on environments
                source_client = (
                    self.dev_client
                    if migration.source_env == "dev"
                    else self.prod_client
                )
                target_client = (
                    self.prod_client
                    if migration.target_env == "prod"
                    else self.dev_client
                )

                # Find dashboard ID from UUID in source
                dashboards = source_client.list_dashboards()
                source_dashboard = next(
                    (d for d in dashboards if d.uuid == migration.dashboard_uuid),
                    None,
                )
                if not source_dashboard:
                    raise ValueError(
                        f"Dashboard with UUID {migration.dashboard_uuid} not found in {migration.source_env}"
                    )

                # Capture before screenshot (from target if exists)
                before_screenshot = None
                if capture_screenshots and self.screenshot_service:
                    target_dashboards = target_client.list_dashboards()
                    target_dashboard = next(
                        (d for d in target_dashboards if d.uuid == migration.dashboard_uuid),
                        None,
                    )
                    if target_dashboard:
                        try:
                            target_url = (
                                self.config.prod_superset_url
                                if migration.target_env == "prod"
                                else self.config.dev_superset_url
                            )
                            before_screenshot = self.screenshot_service.capture_dashboard(
                                superset_url=target_url,
                                dashboard_id=target_dashboard.id,
                                username=self.config.superset_username,
                                password=self.config.superset_password,
                            )
                            # Store screenshot
                            screenshot_log = ScreenshotLog.create_from_bytes(
                                migration_id=migration_id,
                                screenshot_type="before",
                                image_bytes=before_screenshot,
                                environment=migration.target_env,
                            )
                            session.add(screenshot_log)
                        except Exception as e:
                            logger.warning(f"Failed to capture before screenshot: {e}")

                # Export dashboard from source
                logger.info(f"Exporting dashboard from {migration.source_env}...")
                yaml_content = source_client.export_dashboard_yaml(source_dashboard.id)
                zip_content = source_client.export_dashboard(source_dashboard.id)

                # Store YAML in migration record
                migration.yaml_export = yaml_content

                # Commit to git
                logger.info("Committing to git repository...")
                commit_sha = self.git_manager.commit_dashboard(
                    yaml_content=yaml_content,
                    dashboard_uuid=migration.dashboard_uuid,
                    dashboard_name=migration.dashboard_name,
                    user=migration.initiated_by,
                    message=f"Migration: {migration.dashboard_name} ({migration.source_env} -> {migration.target_env})",
                )
                migration.git_commit_sha = commit_sha

                # Create version record
                version_number = DashboardVersion.get_next_version_number(
                    session, migration.dashboard_uuid
                )
                version = DashboardVersion(
                    dashboard_uuid=migration.dashboard_uuid,
                    version_number=version_number,
                    git_commit_sha=commit_sha,
                    yaml_content=yaml_content,
                    created_by=migration.initiated_by,
                    is_current=True,
                )
                version.set_as_current(session)
                session.add(version)

                # Import to target
                logger.info(f"Importing dashboard to {migration.target_env}...")
                target_client.import_dashboard(zip_content, overwrite=True)

                # Capture after screenshot
                if capture_screenshots and self.screenshot_service:
                    try:
                        # Re-fetch to get the new dashboard ID in target
                        target_dashboards = target_client.list_dashboards()
                        target_dashboard = next(
                            (d for d in target_dashboards if d.uuid == migration.dashboard_uuid),
                            None,
                        )
                        if target_dashboard:
                            target_url = (
                                self.config.prod_superset_url
                                if migration.target_env == "prod"
                                else self.config.dev_superset_url
                            )
                            after_screenshot = self.screenshot_service.capture_dashboard(
                                superset_url=target_url,
                                dashboard_id=target_dashboard.id,
                                username=self.config.superset_username,
                                password=self.config.superset_password,
                            )
                            # Store screenshot
                            screenshot_log = ScreenshotLog.create_from_bytes(
                                migration_id=migration_id,
                                screenshot_type="after",
                                image_bytes=after_screenshot,
                                environment=migration.target_env,
                            )
                            session.add(screenshot_log)

                            # Generate diff if we have before screenshot
                            if before_screenshot:
                                diff_result = self.diff_service.compare_images(
                                    before_screenshot, after_screenshot
                                )
                                if diff_result.diff_image:
                                    diff_log = ScreenshotLog.create_from_bytes(
                                        migration_id=migration_id,
                                        screenshot_type="diff",
                                        image_bytes=diff_result.diff_image,
                                        environment=migration.target_env,
                                    )
                                    session.add(diff_log)
                    except Exception as e:
                        logger.warning(f"Failed to capture after screenshot: {e}")

                # Mark as completed
                migration.mark_completed(commit_sha)

                # Create audit log
                AuditLog.log_action(
                    session=session,
                    action=AuditAction.MIGRATE,
                    user_name=migration.initiated_by,
                    migration_id=migration_id,
                    details={
                        "action": "completed",
                        "commit_sha": commit_sha,
                        "version_number": version_number,
                    },
                )

                logger.info(
                    f"Migration completed: {migration.dashboard_name} "
                    f"(commit: {commit_sha[:8]})"
                )
                return True

            except Exception as e:
                # Mark as failed
                migration.mark_failed(str(e))

                # Create audit log for failure
                AuditLog.log_action(
                    session=session,
                    action=AuditAction.ERROR,
                    user_name=migration.initiated_by,
                    migration_id=migration_id,
                    details={
                        "action": "failed",
                        "error": str(e),
                    },
                )

                logger.error(f"Migration failed: {e}")
                raise

    def revert_migration(
        self,
        migration_id: int,
        target_version: Optional[int] = None,
        user: Optional[str] = None,
        ip_address: Optional[str] = None,
    ) -> bool:
        """
        Revert a migration to a previous version.

        Args:
            migration_id: Migration ID to revert
            target_version: Specific version number to revert to (or previous version if None)
            user: Username performing the revert
            ip_address: Client IP address for audit

        Returns:
            True if revert was successful
        """
        with session_scope() as session:
            migration = session.get(DashboardMigration, migration_id)
            if not migration:
                raise ValueError(f"Migration {migration_id} not found")

            if migration.status != MigrationStatus.COMPLETED:
                raise ValueError(
                    f"Can only revert completed migrations (status: {migration.status.value})"
                )

            user = user or migration.initiated_by

            # Find the version to revert to
            if target_version:
                version = (
                    session.query(DashboardVersion)
                    .filter(
                        DashboardVersion.dashboard_uuid == migration.dashboard_uuid,
                        DashboardVersion.version_number == target_version,
                    )
                    .first()
                )
            else:
                # Get previous version
                current_version = DashboardVersion.get_current_version(
                    session, migration.dashboard_uuid
                )
                if not current_version or current_version.version_number <= 1:
                    raise ValueError("No previous version to revert to")

                version = (
                    session.query(DashboardVersion)
                    .filter(
                        DashboardVersion.dashboard_uuid == migration.dashboard_uuid,
                        DashboardVersion.version_number == current_version.version_number - 1,
                    )
                    .first()
                )

            if not version:
                raise ValueError(f"Version not found for dashboard {migration.dashboard_uuid}")

            try:
                # Revert in git
                new_commit = self.git_manager.revert_to_commit(
                    commit_sha=version.git_commit_sha,
                    dashboard_uuid=migration.dashboard_uuid,
                    user=user,
                )

                # Get the YAML content for the version
                yaml_content = version.yaml_content

                # Import to target environment
                target_client = (
                    self.prod_client
                    if migration.target_env == "prod"
                    else self.dev_client
                )

                # We need to create a ZIP from the YAML
                # For now, we'll export fresh from git and import
                import io
                import zipfile
                import yaml

                # Create a simple ZIP with the YAML
                zip_buffer = io.BytesIO()
                with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
                    # Parse the stored YAML which contains file paths
                    yaml_data = yaml.safe_load(yaml_content)
                    for file_path, content in yaml_data.items():
                        zf.writestr(file_path, content)

                zip_buffer.seek(0)
                target_client.import_dashboard(zip_buffer.read(), overwrite=True)

                # Update migration status
                migration.mark_reverted()

                # Create new version record
                new_version_number = DashboardVersion.get_next_version_number(
                    session, migration.dashboard_uuid
                )
                new_version = DashboardVersion(
                    dashboard_uuid=migration.dashboard_uuid,
                    version_number=new_version_number,
                    git_commit_sha=new_commit,
                    yaml_content=yaml_content,
                    created_by=user,
                    is_current=True,
                )
                new_version.set_as_current(session)
                session.add(new_version)

                # Create audit log
                AuditLog.log_action(
                    session=session,
                    action=AuditAction.REVERT,
                    user_name=user,
                    migration_id=migration_id,
                    details={
                        "action": "reverted",
                        "from_version": version.version_number if target_version else "current",
                        "to_version": target_version or version.version_number,
                        "new_commit": new_commit,
                    },
                    ip_address=ip_address,
                )

                logger.info(
                    f"Reverted migration {migration_id} to version {version.version_number}"
                )
                return True

            except Exception as e:
                AuditLog.log_action(
                    session=session,
                    action=AuditAction.ERROR,
                    user_name=user,
                    migration_id=migration_id,
                    details={
                        "action": "revert_failed",
                        "error": str(e),
                    },
                    ip_address=ip_address,
                )
                logger.error(f"Revert failed: {e}")
                raise

    def get_migration_history(
        self,
        dashboard_uuid: Optional[str] = None,
        limit: int = 50,
    ) -> list[DashboardMigration]:
        """
        Get migration history.

        Args:
            dashboard_uuid: Optional filter by dashboard UUID
            limit: Maximum number of records

        Returns:
            List of DashboardMigration objects
        """
        session = get_session()
        try:
            query = session.query(DashboardMigration).order_by(
                DashboardMigration.initiated_at.desc()
            )

            if dashboard_uuid:
                query = query.filter(DashboardMigration.dashboard_uuid == dashboard_uuid)

            return query.limit(limit).all()
        finally:
            session.close()

    def get_available_versions(self, dashboard_uuid: str) -> list[DashboardVersion]:
        """
        Get all versions for a dashboard.

        Args:
            dashboard_uuid: Dashboard UUID

        Returns:
            List of DashboardVersion objects
        """
        session = get_session()
        try:
            return (
                session.query(DashboardVersion)
                .filter(DashboardVersion.dashboard_uuid == dashboard_uuid)
                .order_by(DashboardVersion.version_number.desc())
                .all()
            )
        finally:
            session.close()

    def get_migration(self, migration_id: int) -> Optional[DashboardMigration]:
        """
        Get a specific migration.

        Args:
            migration_id: Migration ID

        Returns:
            DashboardMigration or None
        """
        session = get_session()
        try:
            return session.get(DashboardMigration, migration_id)
        finally:
            session.close()

    def get_screenshots(self, migration_id: int) -> list[ScreenshotLog]:
        """
        Get screenshots for a migration.

        Args:
            migration_id: Migration ID

        Returns:
            List of ScreenshotLog objects
        """
        session = get_session()
        try:
            return (
                session.query(ScreenshotLog)
                .filter(ScreenshotLog.migration_id == migration_id)
                .order_by(ScreenshotLog.captured_at)
                .all()
            )
        finally:
            session.close()

    def close(self) -> None:
        """Close all clients and services."""
        self.dev_client.close()
        self.prod_client.close()
        if self.screenshot_service:
            self.screenshot_service.close()
