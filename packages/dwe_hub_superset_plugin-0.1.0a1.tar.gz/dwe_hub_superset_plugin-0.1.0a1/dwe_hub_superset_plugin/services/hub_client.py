"""
DWE Hub API client for Superset plugin.

This client communicates with the central DWE Hub service
for publishing and downloading dashboard assets.
"""

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import httpx

logger = logging.getLogger(__name__)


@dataclass
class HubAsset:
    """Represents an asset from the Hub."""
    uuid: str
    name: str
    description: Optional[str]
    category: str
    visibility: str
    owner: str
    source_uuid: Optional[str]
    source_environment: Optional[str]
    created_at: Optional[str]
    updated_at: Optional[str]
    versions: list
    preview_key: Optional[str] = None
    preview_thumbnail_key: Optional[str] = None


@dataclass
class HubMedia:
    """Represents a media file attached to a version or asset."""
    id: int
    filename: str
    mime_type: str
    title: Optional[str]
    description: Optional[str]
    file_size_bytes: Optional[int]
    created_at: Optional[str]


@dataclass
class HubVersion:
    """Represents a version of an asset."""
    version_number: int
    visibility: str
    file_size_bytes: Optional[int]
    commit_message: Optional[str]
    published_by: Optional[str]
    created_at: Optional[str]
    screenshot_key: Optional[str] = None
    thumbnail_key: Optional[str] = None
    media: list = None  # List of HubMedia

    def __post_init__(self):
        if self.media is None:
            self.media = []


@dataclass
class HubImportRecord:
    """Represents an import record."""
    id: int
    asset_uuid: str
    version_number: int
    environment_name: str
    environment_url: Optional[str]
    imported_by: Optional[str]
    imported_at: Optional[str]
    local_dashboard_uuid: Optional[str]


@dataclass
class DatasetSnapshot:
    """Represents a dataset snapshot captured at publish time."""
    uuid: str
    table_name: str
    schema: Optional[str]
    database_uuid: str
    database_name: str
    columns: List[Dict[str, Any]]
    metrics: List[Dict[str, Any]]
    sql: Optional[str] = None


@dataclass
class ValidationIssue:
    """Represents a validation issue from import validation."""
    severity: str  # "critical", "warning", "info"
    dataset_uuid: str
    dataset_name: str
    message: str
    column_name: Optional[str] = None
    expected: Optional[str] = None
    actual: Optional[str] = None
    details: Optional[Dict[str, Any]] = None


@dataclass
class ValidationResult:
    """Result of import validation."""
    valid: bool
    can_override: bool
    issues: List[ValidationIssue] = field(default_factory=list)
    critical_count: int = 0
    warning_count: int = 0
    info_count: int = 0


@dataclass
class DiffResult:
    """Result of comparing two dashboard versions."""
    asset_uuid: str
    asset_name: str
    version_from: int
    version_to: int
    summary: str  # LLM-generated or fallback summary
    structural_changes: Dict[str, Any]
    charts_added: List[str]
    charts_removed: List[str]
    charts_modified: List[str]
    filters_changed: bool
    layout_changed: bool
    llm_enabled: bool = False


class HubClientError(Exception):
    """Exception raised for Hub API errors."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class HubClient:
    """
    Client for interacting with the DWE Hub API.

    Usage with username/password:
        client = HubClient(
            hub_url="http://dwe-hub:5000",
            username="admin",
            password="secret"
        )
        client.login()  # Authenticates and caches token
        assets = client.list_assets()

    Usage with api_token (legacy):
        client = HubClient(
            hub_url="http://dwe-hub:5000",
            api_token="your-api-token"
        )
        assets = client.list_assets()
    """

    def __init__(
        self,
        hub_url: str,
        api_token: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        timeout: float = 60.0,
    ):
        """
        Initialize the Hub client.

        Args:
            hub_url: Base URL of the DWE Hub (e.g., http://dwe-hub:5000)
            api_token: API token for authentication (optional if using username/password)
            username: Username for authentication
            password: Password for authentication
            timeout: Request timeout in seconds
        """
        self.hub_url = hub_url.rstrip("/")
        self.api_token = api_token
        self.username = username
        self.password = password
        self.timeout = timeout
        self._client: Optional[httpx.Client] = None
        self._authenticated = False

    def _get_client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.hub_url,
                timeout=self.timeout,
                follow_redirects=True,
            )
        return self._client

    def _get_headers(self) -> dict:
        """Get headers with authentication."""
        if not self.api_token and not self._authenticated:
            self.login()
        return {
            "Authorization": f"Bearer {self.api_token}",
            "Content-Type": "application/json",
        }

    def _ensure_authenticated(self):
        """Ensure we have a valid API token."""
        if not self.api_token:
            if self.username and self.password:
                self.login()
            else:
                raise HubClientError(
                    "No API token or credentials provided. "
                    "Either provide api_token or username/password."
                )

    def login(self) -> dict:
        """
        Login with username/password to get API token.

        Returns:
            dict with user info and api_token

        Raises:
            HubClientError: If login fails
        """
        if not self.username or not self.password:
            raise HubClientError(
                "Cannot login: username and password are required"
            )

        client = self._get_client()

        try:
            response = client.post(
                "/api/v1/auth/login",
                json={
                    "username": self.username,
                    "password": self.password,
                }
            )

            if response.status_code == 401:
                raise HubClientError(
                    "Invalid username or password",
                    status_code=401,
                )

            if response.status_code != 200:
                raise HubClientError(
                    f"Login failed: {response.text}",
                    status_code=response.status_code,
                )

            data = response.json()
            self.api_token = data.get("api_token")
            self._authenticated = True

            logger.info(f"Successfully authenticated as {self.username}")
            return data

        except httpx.RequestError as e:
            raise HubClientError(f"Login request failed: {e}")

    def health_check(self) -> bool:
        """Check if Hub is available."""
        client = self._get_client()
        try:
            response = client.get("/api/v1/health")
            return response.status_code == 200
        except Exception as e:
            logger.warning(f"Hub health check failed: {e}")
            return False

    def list_assets(
        self,
        category: Optional[str] = "dashboard",
        visibility: Optional[str] = None,
        search: Optional[str] = None,
        page: int = 1,
        per_page: int = 20,
    ) -> tuple[list[HubAsset], int]:
        """
        List assets from the Hub.

        Args:
            category: Filter by category (dashboard, model, pipeline)
            visibility: Filter by visibility (public, private)
            search: Search term
            page: Page number
            per_page: Items per page

        Returns:
            Tuple of (list of assets, total count)
        """
        client = self._get_client()
        params = {
            "page": page,
            "per_page": per_page,
        }
        if category:
            params["category"] = category
        if visibility:
            params["visibility"] = visibility
        if search:
            params["search"] = search

        try:
            response = client.get(
                "/api/v1/assets",
                headers=self._get_headers(),
                params=params,
            )

            if response.status_code != 200:
                raise HubClientError(
                    f"Failed to list assets: {response.text}",
                    status_code=response.status_code,
                )

            data = response.json()
            assets = [
                HubAsset(
                    uuid=a["uuid"],
                    name=a["name"],
                    description=a.get("description"),
                    category=a["category"],
                    visibility=a["visibility"],
                    owner=a["owner"],
                    source_uuid=a.get("source_uuid"),
                    source_environment=a.get("source_environment"),
                    created_at=a.get("created_at"),
                    updated_at=a.get("updated_at"),
                    versions=[
                        HubVersion(
                            version_number=v["version_number"],
                            visibility=v.get("visibility", "private"),
                            file_size_bytes=v.get("file_size_bytes"),
                            commit_message=v.get("commit_message"),
                            published_by=v.get("published_by"),
                            created_at=v.get("created_at"),
                            screenshot_key=v.get("screenshot_key"),
                            thumbnail_key=v.get("thumbnail_key"),
                            media=[
                                HubMedia(
                                    id=m.get("id"),
                                    filename=m.get("filename"),
                                    mime_type=m.get("mime_type"),
                                    title=m.get("title"),
                                    description=m.get("description"),
                                    file_size_bytes=m.get("file_size_bytes"),
                                    created_at=m.get("created_at"),
                                )
                                for m in v.get("media", [])
                            ],
                        )
                        for v in a.get("versions", [])
                    ],
                    preview_key=a.get("preview_key"),
                    preview_thumbnail_key=a.get("preview_thumbnail_key"),
                )
                for a in data.get("assets", [])
            ]
            return assets, data.get("total", 0)

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def get_asset(self, asset_uuid: str) -> HubAsset:
        """Get a specific asset by UUID."""
        client = self._get_client()

        try:
            response = client.get(
                f"/api/v1/assets/{asset_uuid}",
                headers=self._get_headers(),
            )

            if response.status_code == 404:
                raise HubClientError("Asset not found", status_code=404)

            if response.status_code != 200:
                raise HubClientError(
                    f"Failed to get asset: {response.text}",
                    status_code=response.status_code,
                )

            a = response.json()
            return HubAsset(
                uuid=a["uuid"],
                name=a["name"],
                description=a.get("description"),
                category=a["category"],
                visibility=a["visibility"],
                owner=a["owner"],
                source_uuid=a.get("source_uuid"),
                source_environment=a.get("source_environment"),
                created_at=a.get("created_at"),
                updated_at=a.get("updated_at"),
                versions=[
                    HubVersion(
                        version_number=v["version_number"],
                        visibility=v.get("visibility", "private"),
                        file_size_bytes=v.get("file_size_bytes"),
                        commit_message=v.get("commit_message"),
                        published_by=v.get("published_by"),
                        created_at=v.get("created_at"),
                        screenshot_key=v.get("screenshot_key"),
                        thumbnail_key=v.get("thumbnail_key"),
                        media=[
                            HubMedia(
                                id=m.get("id"),
                                filename=m.get("filename"),
                                mime_type=m.get("mime_type"),
                                title=m.get("title"),
                                description=m.get("description"),
                                file_size_bytes=m.get("file_size_bytes"),
                                created_at=m.get("created_at"),
                            )
                            for m in v.get("media", [])
                        ],
                    )
                    for v in a.get("versions", [])
                ],
                preview_key=a.get("preview_key"),
                preview_thumbnail_key=a.get("preview_thumbnail_key"),
            )

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def publish_dashboard(
        self,
        name: str,
        zip_content: bytes,
        description: str = "",
        visibility: str = "private",
        source_uuid: Optional[str] = None,
        source_environment: Optional[str] = None,
        commit_message: str = "",
        published_by: Optional[str] = None,
        screenshot: Optional[bytes] = None,
        dataset_snapshots: Optional[List[Dict[str, Any]]] = None,
    ) -> dict:
        """
        Publish a dashboard to the Hub.

        Args:
            name: Dashboard name
            zip_content: ZIP file content
            description: Optional description
            visibility: "public" or "private" (applies to this version)
            source_uuid: Original Superset dashboard UUID
            source_environment: Source environment name
            commit_message: Version commit message
            published_by: Username of the Superset user who published
            screenshot: Optional PNG screenshot of the dashboard
            dataset_snapshots: Optional list of dataset metadata extracted from the ZIP

        Returns:
            Response data with asset and version info
        """
        # Ensure we're authenticated (auto-login if using username/password)
        if not self.api_token and not self._authenticated:
            self.login()

        client = self._get_client()
        headers = {"Authorization": f"Bearer {self.api_token}"}

        files = {"file": ("dashboard.zip", zip_content, "application/zip")}
        if screenshot:
            files["screenshot"] = ("screenshot.png", screenshot, "image/png")

        data = {
            "name": name,
            "description": description,
            "visibility": visibility,
            "commit_message": commit_message,
        }
        if source_uuid:
            data["source_uuid"] = source_uuid
        if source_environment:
            data["source_environment"] = source_environment
        if published_by:
            data["published_by"] = published_by
        if dataset_snapshots:
            data["dataset_snapshots"] = json.dumps(dataset_snapshots)

        logger.info(f"Publishing to {self.hub_url}/api/v1/publish")
        logger.info(f"Data: name={name}, visibility={visibility}, source_uuid={source_uuid}")
        logger.info(f"File size: {len(zip_content)} bytes, screenshot: {len(screenshot) if screenshot else 0} bytes")

        try:
            response = client.post(
                "/api/v1/publish",
                headers=headers,
                files=files,
                data=data,
            )

            logger.info(f"Hub response status: {response.status_code}")
            logger.info(f"Hub response body: {response.text[:500] if response.text else 'empty'}")

            if response.status_code not in (200, 201):
                raise HubClientError(
                    f"Failed to publish: {response.text}",
                    status_code=response.status_code,
                )

            return response.json()

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def download_dashboard(
        self,
        asset_uuid: str,
        version: Optional[int] = None,
    ) -> bytes:
        """
        Download a dashboard from the Hub.

        Args:
            asset_uuid: Asset UUID
            version: Version number (default: latest)

        Returns:
            ZIP file content
        """
        client = self._get_client()
        params = {}
        if version:
            params["version"] = version

        try:
            response = client.get(
                f"/api/v1/download/{asset_uuid}",
                headers=self._get_headers(),
                params=params,
            )

            if response.status_code == 404:
                raise HubClientError("Asset or version not found", status_code=404)

            if response.status_code != 200:
                raise HubClientError(
                    f"Failed to download: {response.text}",
                    status_code=response.status_code,
                )

            return response.content

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def delete_asset(self, asset_uuid: str) -> bool:
        """Delete an asset from the Hub."""
        client = self._get_client()

        try:
            response = client.delete(
                f"/api/v1/assets/{asset_uuid}",
                headers=self._get_headers(),
            )

            if response.status_code == 404:
                raise HubClientError("Asset not found", status_code=404)

            return response.status_code == 200

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def update_visibility(self, asset_uuid: str, visibility: str) -> dict:
        """Update asset visibility (legacy - updates all versions)."""
        client = self._get_client()

        try:
            response = client.patch(
                f"/api/v1/assets/{asset_uuid}/visibility",
                headers=self._get_headers(),
                json={"visibility": visibility},
            )

            if response.status_code != 200:
                raise HubClientError(
                    f"Failed to update visibility: {response.text}",
                    status_code=response.status_code,
                )

            return response.json()

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def update_version_visibility(
        self,
        asset_uuid: str,
        version_number: int,
        visibility: str,
    ) -> dict:
        """
        Update visibility for a specific version.

        Args:
            asset_uuid: Asset UUID
            version_number: Version number
            visibility: "public" or "private"

        Returns:
            Response data with updated version info
        """
        client = self._get_client()

        try:
            response = client.patch(
                f"/api/v1/assets/{asset_uuid}/versions/{version_number}/visibility",
                headers=self._get_headers(),
                json={"visibility": visibility},
            )

            if response.status_code != 200:
                raise HubClientError(
                    f"Failed to update version visibility: {response.text}",
                    status_code=response.status_code,
                )

            return response.json()

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def record_import(
        self,
        asset_uuid: str,
        version_number: int,
        environment_name: str,
        environment_url: Optional[str] = None,
        local_dashboard_uuid: Optional[str] = None,
    ) -> dict:
        """
        Record an import to the Hub.

        Args:
            asset_uuid: UUID of the imported asset
            version_number: Version that was imported
            environment_name: Name of the target environment (e.g., "prod")
            environment_url: URL of the Superset instance (optional)
            local_dashboard_uuid: UUID of the resulting dashboard in target (optional)

        Returns:
            Response data with import record info
        """
        client = self._get_client()

        payload = {
            "asset_uuid": asset_uuid,
            "version_number": version_number,
            "environment_name": environment_name,
        }
        if environment_url:
            payload["environment_url"] = environment_url
        if local_dashboard_uuid:
            payload["local_dashboard_uuid"] = local_dashboard_uuid

        try:
            response = client.post(
                "/api/v1/imports",
                headers=self._get_headers(),
                json=payload,
            )

            if response.status_code not in (200, 201):
                raise HubClientError(
                    f"Failed to record import: {response.text}",
                    status_code=response.status_code,
                )

            return response.json()

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def get_asset_imports(
        self,
        asset_uuid: str,
        environment: Optional[str] = None,
    ) -> list[HubImportRecord]:
        """
        Get import history for an asset.

        Args:
            asset_uuid: UUID of the asset
            environment: Filter by environment name (optional)

        Returns:
            List of import records
        """
        client = self._get_client()

        params = {}
        if environment:
            params["environment"] = environment

        try:
            response = client.get(
                f"/api/v1/assets/{asset_uuid}/imports",
                headers=self._get_headers(),
                params=params,
            )

            if response.status_code != 200:
                raise HubClientError(
                    f"Failed to get imports: {response.text}",
                    status_code=response.status_code,
                )

            data = response.json()
            return [
                HubImportRecord(
                    id=i.get("id"),
                    asset_uuid=asset_uuid,
                    version_number=i.get("version_number"),
                    environment_name=i.get("environment_name"),
                    environment_url=i.get("environment_url"),
                    imported_by=i.get("imported_by"),
                    imported_at=i.get("imported_at"),
                    local_dashboard_uuid=i.get("local_dashboard_uuid"),
                )
                for i in data.get("imports", [])
            ]

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def get_latest_import(
        self,
        asset_uuid: str,
        environment: str,
    ) -> Optional[HubImportRecord]:
        """
        Get the latest import record for an asset in a specific environment.

        Args:
            asset_uuid: UUID of the asset
            environment: Environment name

        Returns:
            Import record if found, None otherwise
        """
        client = self._get_client()

        try:
            response = client.get(
                f"/api/v1/assets/{asset_uuid}/imports/latest",
                headers=self._get_headers(),
                params={"environment": environment},
            )

            if response.status_code != 200:
                raise HubClientError(
                    f"Failed to get latest import: {response.text}",
                    status_code=response.status_code,
                )

            data = response.json()
            if not data.get("imported"):
                return None

            i = data.get("import", {})
            return HubImportRecord(
                id=i.get("id"),
                asset_uuid=asset_uuid,
                version_number=i.get("version_number"),
                environment_name=i.get("environment_name"),
                environment_url=i.get("environment_url"),
                imported_by=i.get("imported_by"),
                imported_at=i.get("imported_at"),
                local_dashboard_uuid=i.get("local_dashboard_uuid"),
            )

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def get_version_datasets(
        self,
        asset_uuid: str,
        version_number: int,
    ) -> List[DatasetSnapshot]:
        """
        Fetch dataset snapshots for a specific version.

        Args:
            asset_uuid: UUID of the asset
            version_number: Version number to fetch datasets for

        Returns:
            List of DatasetSnapshot objects
        """
        client = self._get_client()

        try:
            response = client.get(
                f"/api/v1/assets/{asset_uuid}/versions/{version_number}/datasets",
                headers=self._get_headers(),
            )

            if response.status_code != 200:
                raise HubClientError(
                    f"Failed to get datasets: {response.text}",
                    status_code=response.status_code,
                )

            data = response.json()
            return [
                DatasetSnapshot(
                    uuid=ds.get("uuid"),
                    table_name=ds.get("table_name"),
                    schema=ds.get("schema"),
                    database_uuid=ds.get("database_uuid"),
                    database_name=ds.get("database_name"),
                    columns=ds.get("columns", []),
                    metrics=ds.get("metrics", []),
                    sql=ds.get("sql"),
                )
                for ds in data.get("datasets", [])
            ]

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def validate_import(
        self,
        asset_uuid: str,
        version_number: int,
        local_datasets: List[Dict[str, Any]],
    ) -> ValidationResult:
        """
        Validate import compatibility against local datasets.

        Args:
            asset_uuid: UUID of the asset to import
            version_number: Version number to import
            local_datasets: List of local dataset info from Superset

        Returns:
            ValidationResult with issues and validity status
        """
        client = self._get_client()

        try:
            response = client.post(
                "/api/v1/validate-import",
                headers=self._get_headers(),
                json={
                    "asset_uuid": asset_uuid,
                    "version_number": version_number,
                    "local_datasets": local_datasets,
                },
            )

            if response.status_code != 200:
                raise HubClientError(
                    f"Failed to validate import: {response.text}",
                    status_code=response.status_code,
                )

            data = response.json()
            issues = [
                ValidationIssue(
                    severity=i.get("severity"),
                    dataset_uuid=i.get("dataset_uuid"),
                    dataset_name=i.get("dataset_name"),
                    message=i.get("message"),
                    column_name=i.get("column_name"),
                    expected=i.get("expected"),
                    actual=i.get("actual"),
                    details=i.get("details"),
                )
                for i in data.get("issues", [])
            ]

            return ValidationResult(
                valid=data.get("valid", True),
                can_override=data.get("can_override", True),
                issues=issues,
                critical_count=data.get("critical_count", 0),
                warning_count=data.get("warning_count", 0),
                info_count=data.get("info_count", 0),
            )

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def get_version_diff(
        self,
        asset_uuid: str,
        v1: Optional[int] = None,
        v2: Optional[int] = None,
    ) -> DiffResult:
        """
        Compare two versions of an asset using LLM-powered analysis.

        Args:
            asset_uuid: UUID of the asset
            v1: First version number (default: first version)
            v2: Second version number (default: latest version)

        Returns:
            DiffResult with LLM summary and structural changes
        """
        client = self._get_client()

        params = {}
        if v1 is not None:
            params["v1"] = v1
        if v2 is not None:
            params["v2"] = v2

        try:
            response = client.get(
                f"/api/v1/assets/{asset_uuid}/diff",
                headers=self._get_headers(),
                params=params,
            )

            if response.status_code != 200:
                raise HubClientError(
                    f"Failed to get diff: {response.text}",
                    status_code=response.status_code,
                )

            data = response.json()
            return DiffResult(
                asset_uuid=data.get("asset_uuid"),
                asset_name=data.get("asset_name"),
                version_from=data.get("version_from"),
                version_to=data.get("version_to"),
                summary=data.get("summary", ""),
                structural_changes=data.get("structural_changes", {}),
                charts_added=data.get("charts_added", []),
                charts_removed=data.get("charts_removed", []),
                charts_modified=data.get("charts_modified", []),
                filters_changed=data.get("filters_changed", False),
                layout_changed=data.get("layout_changed", False),
                llm_enabled=data.get("llm_enabled", False),
            )

        except httpx.RequestError as e:
            raise HubClientError(f"Request failed: {e}")

    def close(self):
        """Close the HTTP client."""
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
