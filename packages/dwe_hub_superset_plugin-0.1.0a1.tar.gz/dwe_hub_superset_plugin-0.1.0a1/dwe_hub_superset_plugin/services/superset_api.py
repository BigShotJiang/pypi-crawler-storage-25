"""
Superset API client for dashboard export/import operations.
"""

import io
import logging
import zipfile
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import httpx
import yaml

logger = logging.getLogger(__name__)


@dataclass
class DashboardInfo:
    """Information about a Superset dashboard."""

    id: int
    uuid: str
    dashboard_title: str
    slug: Optional[str]
    published: bool
    position_json: Optional[str]
    css: Optional[str]
    json_metadata: Optional[str]
    changed_on: Optional[str]
    changed_by_name: Optional[str]
    url: str


class SupersetAPIError(Exception):
    """Exception raised for Superset API errors."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class SupersetAPIClient:
    """
    Client for interacting with the Superset REST API.

    Handles authentication, dashboard export/import, and listing operations.
    """

    def __init__(
        self,
        base_url: str,
        username: str,
        password: str,
        timeout: float = 60.0,
    ):
        """
        Initialize the Superset API client.

        Args:
            base_url: Base URL of the Superset instance (e.g., http://localhost:8088)
            username: Superset username
            password: Superset password
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        self.timeout = timeout
        self._access_token: Optional[str] = None
        self._csrf_token: Optional[str] = None
        self._client: Optional[httpx.Client] = None

    def _get_client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.base_url,
                timeout=self.timeout,
                follow_redirects=True,
                cookies=httpx.Cookies(),  # Enable cookie persistence
            )
        return self._client

    def login(self) -> str:
        """
        Authenticate with Superset and get access token.

        Returns:
            Access token string

        Raises:
            SupersetAPIError: If authentication fails
        """
        client = self._get_client()

        # First, do a session-based login (for CSRF-protected endpoints like import)
        try:
            # Get the login page to get initial CSRF token
            login_page = client.get("/login/")

            # Extract CSRF token from cookies or page
            csrf_from_cookie = client.cookies.get("csrf_access_token")

            # Do form-based login for session
            login_form_data = {
                "username": self.username,
                "password": self.password,
            }

            headers = {}
            if csrf_from_cookie:
                headers["X-CSRFToken"] = csrf_from_cookie

            session_login = client.post(
                "/login/",
                data=login_form_data,
                headers=headers,
            )
            logger.debug(f"Session login status: {session_login.status_code}")

        except Exception as e:
            logger.warning(f"Session login failed (will try API login): {e}")

        # Get CSRF token for API calls
        try:
            csrf_response = client.get("/api/v1/security/csrf_token/")
            if csrf_response.status_code == 200:
                self._csrf_token = csrf_response.json().get("result")
        except Exception as e:
            logger.warning(f"Could not get CSRF token: {e}")

        # Login to get access token
        login_payload = {
            "username": self.username,
            "password": self.password,
            "provider": "db",
            "refresh": True,
        }

        headers = {}
        if self._csrf_token:
            headers["X-CSRFToken"] = self._csrf_token

        try:
            response = client.post(
                "/api/v1/security/login",
                json=login_payload,
                headers=headers,
            )

            if response.status_code != 200:
                raise SupersetAPIError(
                    f"Login failed: {response.text}",
                    status_code=response.status_code,
                )

            data = response.json()
            self._access_token = data.get("access_token")

            if not self._access_token:
                raise SupersetAPIError("No access token in response")

            # Get fresh CSRF token after login
            try:
                csrf_response = client.get(
                    "/api/v1/security/csrf_token/",
                    headers={"Authorization": f"Bearer {self._access_token}"}
                )
                if csrf_response.status_code == 200:
                    self._csrf_token = csrf_response.json().get("result")
            except Exception as e:
                logger.warning(f"Could not refresh CSRF token: {e}")

            logger.info(f"Successfully authenticated with Superset at {self.base_url}")
            return self._access_token

        except httpx.RequestError as e:
            raise SupersetAPIError(f"Request failed: {e}")

    def _get_headers(self) -> dict[str, str]:
        """Get headers with authentication token."""
        if not self._access_token:
            self.login()

        headers = {
            "Authorization": f"Bearer {self._access_token}",
            "Content-Type": "application/json",
        }

        if self._csrf_token:
            headers["X-CSRFToken"] = self._csrf_token

        return headers

    def list_dashboards(self) -> list[DashboardInfo]:
        """
        List all dashboards in Superset.

        Returns:
            List of DashboardInfo objects

        Raises:
            SupersetAPIError: If the request fails
        """
        client = self._get_client()
        headers = self._get_headers()

        # Request with Rison-encoded query including columns
        # Rison format: (columns:!(id,uuid,dashboard_title,...),page_size:1000)
        rison_query = "(columns:!(id,uuid,dashboard_title,slug,published,changed_on_utc,changed_by,url),page_size:1000)"

        try:
            response = client.get(
                "/api/v1/dashboard/",
                headers=headers,
                params={"q": rison_query},
            )

            if response.status_code == 401:
                # Token expired, re-authenticate
                self._access_token = None
                headers = self._get_headers()
                response = client.get(
                    "/api/v1/dashboard/",
                    headers=headers,
                    params={"q": rison_query},
                )

            if response.status_code != 200:
                raise SupersetAPIError(
                    f"Failed to list dashboards: {response.text}",
                    status_code=response.status_code,
                )

            data = response.json()
            dashboards = []

            for item in data.get("result", []):
                dashboards.append(
                    DashboardInfo(
                        id=item.get("id"),
                        uuid=item.get("uuid", ""),
                        dashboard_title=item.get("dashboard_title", ""),
                        slug=item.get("slug"),
                        published=item.get("published", False),
                        position_json=item.get("position_json"),
                        css=item.get("css"),
                        json_metadata=item.get("json_metadata"),
                        changed_on=item.get("changed_on_utc"),
                        changed_by_name=item.get("changed_by", {}).get("username") if item.get("changed_by") else None,
                        url=item.get("url", f"/superset/dashboard/{item.get('id')}/"),
                    )
                )

            return dashboards

        except httpx.RequestError as e:
            raise SupersetAPIError(f"Request failed: {e}")

    def get_dashboard(self, dashboard_id: int) -> DashboardInfo:
        """
        Get a specific dashboard by ID.

        Args:
            dashboard_id: Dashboard ID

        Returns:
            DashboardInfo object

        Raises:
            SupersetAPIError: If the request fails
        """
        client = self._get_client()
        headers = self._get_headers()

        try:
            response = client.get(
                f"/api/v1/dashboard/{dashboard_id}",
                headers=headers,
            )

            if response.status_code == 401:
                self._access_token = None
                headers = self._get_headers()
                response = client.get(
                    f"/api/v1/dashboard/{dashboard_id}",
                    headers=headers,
                )

            if response.status_code != 200:
                raise SupersetAPIError(
                    f"Failed to get dashboard: {response.text}",
                    status_code=response.status_code,
                )

            item = response.json().get("result", {})
            logger.info(f"Dashboard API response keys: {list(item.keys())}")
            logger.info(f"Dashboard uuid from API: {item.get('uuid')}")

            return DashboardInfo(
                id=item.get("id"),
                uuid=item.get("uuid", ""),
                dashboard_title=item.get("dashboard_title", ""),
                slug=item.get("slug"),
                published=item.get("published", False),
                position_json=item.get("position_json"),
                css=item.get("css"),
                json_metadata=item.get("json_metadata"),
                changed_on=item.get("changed_on_utc"),
                changed_by_name=item.get("changed_by", {}).get("username") if item.get("changed_by") else None,
                url=item.get("url", f"/superset/dashboard/{item.get('id')}/"),
            )

        except httpx.RequestError as e:
            raise SupersetAPIError(f"Request failed: {e}")

    def export_dashboard(self, dashboard_id: int) -> bytes:
        """
        Export a dashboard as a ZIP file.

        Args:
            dashboard_id: Dashboard ID to export

        Returns:
            ZIP file content as bytes

        Raises:
            SupersetAPIError: If export fails
        """
        client = self._get_client()
        headers = self._get_headers()
        # Remove Content-Type for file download
        headers.pop("Content-Type", None)

        try:
            response = client.get(
                f"/api/v1/dashboard/export/",
                headers=headers,
                params={"q": f"[{dashboard_id}]"},
            )

            if response.status_code == 401:
                self._access_token = None
                headers = self._get_headers()
                headers.pop("Content-Type", None)
                response = client.get(
                    f"/api/v1/dashboard/export/",
                    headers=headers,
                    params={"q": f"[{dashboard_id}]"},
                )

            if response.status_code != 200:
                raise SupersetAPIError(
                    f"Failed to export dashboard: {response.text}",
                    status_code=response.status_code,
                )

            return response.content

        except httpx.RequestError as e:
            raise SupersetAPIError(f"Request failed: {e}")

    def export_dashboard_yaml(self, dashboard_id: int) -> str:
        """
        Export a dashboard and extract its YAML content.

        Args:
            dashboard_id: Dashboard ID to export

        Returns:
            YAML content as string

        Raises:
            SupersetAPIError: If export fails
        """
        zip_content = self.export_dashboard(dashboard_id)

        # Extract YAML from ZIP
        try:
            with zipfile.ZipFile(io.BytesIO(zip_content)) as zf:
                yaml_files = [f for f in zf.namelist() if f.endswith(".yaml")]

                if not yaml_files:
                    raise SupersetAPIError("No YAML files found in export")

                # Combine all YAML files
                combined_yaml = {}
                for yaml_file in yaml_files:
                    content = zf.read(yaml_file).decode("utf-8")
                    combined_yaml[yaml_file] = content

                return yaml.dump(combined_yaml, default_flow_style=False, allow_unicode=True)

        except zipfile.BadZipFile:
            raise SupersetAPIError("Invalid ZIP file in export response")

    def import_dashboard(
        self,
        zip_content: bytes,
        overwrite: bool = True,
    ) -> bool:
        """
        Import a dashboard from a ZIP file.

        Args:
            zip_content: ZIP file content as bytes
            overwrite: Whether to overwrite existing dashboards

        Returns:
            True if import was successful

        Raises:
            SupersetAPIError: If import fails
        """
        client = self._get_client()

        # Ensure we're logged in
        if not self._access_token:
            self.login()

        # Get fresh CSRF token before import
        try:
            csrf_response = client.get(
                "/api/v1/security/csrf_token/",
                headers={"Authorization": f"Bearer {self._access_token}"}
            )
            if csrf_response.status_code == 200:
                self._csrf_token = csrf_response.json().get("result")
                logger.debug(f"Got CSRF token for import: {self._csrf_token[:20]}...")
        except Exception as e:
            logger.warning(f"Could not get CSRF token for import: {e}")

        headers = {
            "Authorization": f"Bearer {self._access_token}",
        }
        if self._csrf_token:
            headers["X-CSRFToken"] = self._csrf_token
            headers["Referer"] = self.base_url  # Some CSRF implementations need this

        try:
            files = {"formData": ("dashboard.zip", zip_content, "application/zip")}
            data = {"overwrite": "true" if overwrite else "false"}

            # Note: Use trailing slash to match Superset's route exactly
            import_url = "/api/v1/dashboard/import/"
            logger.info(f"Importing dashboard to {self.base_url}{import_url}")

            response = client.post(
                import_url,
                headers=headers,
                files=files,
                data=data,
            )

            logger.info(f"Import response status: {response.status_code}")
            if response.status_code >= 400:
                logger.error(f"Import failed: {response.text[:500]}")

            if response.status_code == 401:
                # Re-authenticate and retry
                self._access_token = None
                self.login()
                headers = {
                    "Authorization": f"Bearer {self._access_token}",
                }
                if self._csrf_token:
                    headers["X-CSRFToken"] = self._csrf_token
                    headers["Referer"] = self.base_url

                response = client.post(
                    "/api/v1/dashboard/import/",
                    headers=headers,
                    files=files,
                    data=data,
                )

            if response.status_code not in (200, 201):
                error_detail = response.text
                try:
                    error_json = response.json()
                    error_detail = error_json.get("message", error_json)
                except:
                    pass
                raise SupersetAPIError(
                    f"Failed to import dashboard (status {response.status_code}): {error_detail}",
                    status_code=response.status_code,
                )

            logger.info("Dashboard imported successfully")
            return True

        except httpx.RequestError as e:
            raise SupersetAPIError(f"Request failed: {e}")

    def get_dataset_by_uuid(
        self,
        dataset_uuid: str,
        fallback_table_name: Optional[str] = None,
        fallback_schema: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Get a dataset by UUID with columns and metrics.

        If UUID search fails and fallback_table_name is provided, will try
        to find the dataset by table name and schema instead. This handles
        the case where datasets exist in different environments with different
        UUIDs.

        Args:
            dataset_uuid: UUID of the dataset to fetch
            fallback_table_name: Table name to search for if UUID not found
            fallback_schema: Schema to use with fallback search

        Returns:
            Dataset info dict or None if not found
        """
        client = self._get_client()
        headers = self._get_headers()

        uuid_search_failed = False
        try:
            # First, try to find by UUID
            rison_query = f"(filters:!((col:uuid,opr:eq,value:'{dataset_uuid}')),page_size:1)"

            response = client.get(
                "/api/v1/dataset/",
                headers=headers,
                params={"q": rison_query},
            )

            if response.status_code == 401:
                self._access_token = None
                headers = self._get_headers()
                response = client.get(
                    "/api/v1/dataset/",
                    headers=headers,
                    params={"q": rison_query},
                )

            if response.status_code != 200:
                # UUID filter might not be supported - try fallback
                logger.warning(f"UUID search failed: {response.text}")
                uuid_search_failed = True
            else:
                data = response.json()
                results = data.get("result", [])

                if results:
                    dataset_id = results[0].get("id")
                    if dataset_id:
                        return self._get_dataset_details(dataset_id)

        except httpx.RequestError as e:
            logger.warning(f"Failed to get dataset by UUID: {e}")
            uuid_search_failed = True

        # UUID not found or search failed - try fallback by table name and schema
        if fallback_table_name:
            logger.info(
                f"Dataset UUID {dataset_uuid} not found, trying fallback by "
                f"table_name='{fallback_table_name}', schema='{fallback_schema}'"
            )
            return self._get_dataset_by_name_schema(fallback_table_name, fallback_schema)

        return None

    def _get_dataset_by_name_schema(
        self,
        table_name: str,
        schema: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Find a dataset by table name and schema.

        Args:
            table_name: Name of the table/dataset
            schema: Database schema (optional)

        Returns:
            Dataset info dict or None if not found
        """
        client = self._get_client()
        headers = self._get_headers()

        try:
            # Build filter query for table_name
            filters = [f"(col:table_name,opr:eq,value:'{table_name}')"]

            # Add schema filter if provided
            if schema:
                filters.append(f"(col:schema,opr:eq,value:'{schema}')")

            filters_str = ",".join(filters)
            rison_query = f"(filters:!({filters_str}),page_size:10)"

            response = client.get(
                "/api/v1/dataset/",
                headers=headers,
                params={"q": rison_query},
            )

            if response.status_code == 401:
                self._access_token = None
                headers = self._get_headers()
                response = client.get(
                    "/api/v1/dataset/",
                    headers=headers,
                    params={"q": rison_query},
                )

            if response.status_code != 200:
                logger.warning(f"Failed to search dataset by name: {response.text}")
                return None

            data = response.json()
            results = data.get("result", [])

            if not results:
                logger.warning(f"No dataset found with table_name='{table_name}', schema='{schema}'")
                return None

            # If multiple results, prefer exact schema match
            if len(results) > 1 and schema:
                for result in results:
                    if result.get("schema") == schema:
                        dataset_id = result.get("id")
                        if dataset_id:
                            logger.info(f"Found dataset by name/schema: {table_name} (id={dataset_id})")
                            return self._get_dataset_details(dataset_id)

            # Use first result
            dataset_id = results[0].get("id")
            if dataset_id:
                logger.info(f"Found dataset by name: {table_name} (id={dataset_id})")
                return self._get_dataset_details(dataset_id)

            return None

        except httpx.RequestError as e:
            logger.warning(f"Failed to get dataset by name/schema: {e}")
            return None

    def _get_dataset_details(self, dataset_id: int) -> Optional[Dict[str, Any]]:
        """
        Get full dataset details including columns and metrics.

        Args:
            dataset_id: Internal dataset ID

        Returns:
            Dataset info dict or None if not found
        """
        client = self._get_client()
        headers = self._get_headers()

        try:
            response = client.get(
                f"/api/v1/dataset/{dataset_id}",
                headers=headers,
            )

            if response.status_code != 200:
                logger.warning(f"Failed to get dataset details: {response.text}")
                return None

            item = response.json().get("result", {})

            # Extract columns
            columns = []
            for col in item.get("columns", []):
                columns.append({
                    "column_name": col.get("column_name"),
                    "type": col.get("type"),
                    "is_dttm": col.get("is_dttm", False),
                    "description": col.get("description"),
                    "filterable": col.get("filterable", True),
                    "groupby": col.get("groupby", True),
                })

            # Extract metrics
            metrics = []
            for metric in item.get("metrics", []):
                metrics.append({
                    "metric_name": metric.get("metric_name"),
                    "expression": metric.get("expression"),
                    "verbose_name": metric.get("verbose_name"),
                    "description": metric.get("description"),
                    "metric_type": metric.get("metric_type"),
                })

            # Get database info
            database = item.get("database", {})

            return {
                "uuid": item.get("uuid"),
                "table_name": item.get("table_name"),
                "schema": item.get("schema"),
                "database_uuid": database.get("uuid") if database else None,
                "database_name": database.get("database_name") if database else None,
                "sql": item.get("sql"),
                "columns": columns,
                "metrics": metrics,
            }

        except httpx.RequestError as e:
            logger.warning(f"Failed to get dataset details: {e}")
            return None

    def get_datasets_by_uuids(self, uuids: List[str]) -> List[Dict[str, Any]]:
        """
        Get multiple datasets by UUID.

        Args:
            uuids: List of dataset UUIDs to fetch

        Returns:
            List of dataset info dicts (excludes not-found datasets)
        """
        datasets = []
        for uuid in uuids:
            dataset = self.get_dataset_by_uuid(uuid)
            if dataset:
                datasets.append(dataset)
        return datasets

    def get_datasets_for_validation(
        self,
        hub_datasets: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Get local datasets for validation, matching Hub datasets.

        First tries to find by UUID. If not found, falls back to
        searching by table_name and schema. This handles the case
        where datasets exist in both environments but have different UUIDs.

        Args:
            hub_datasets: Dataset snapshots from Hub with uuid, table_name, schema

        Returns:
            List of local dataset info dicts with matched hub_uuid field
        """
        local_datasets = []

        for hub_ds in hub_datasets:
            hub_uuid = hub_ds.get("uuid")
            table_name = hub_ds.get("table_name")
            schema = hub_ds.get("schema")

            if not hub_uuid:
                continue

            # Try UUID first, then fallback to name/schema
            local_ds = self.get_dataset_by_uuid(
                dataset_uuid=hub_uuid,
                fallback_table_name=table_name,
                fallback_schema=schema,
            )

            if local_ds:
                # Tag with the Hub UUID so validation can match them
                local_ds["matched_hub_uuid"] = hub_uuid
                local_datasets.append(local_ds)

        return local_datasets

    def list_databases(self) -> List[Dict[str, Any]]:
        """
        List all database connections in Superset.

        Returns:
            List of database info dicts with id, uuid, database_name
        """
        client = self._get_client()
        headers = self._get_headers()

        try:
            response = client.get(
                "/api/v1/database/",
                headers=headers,
                params={"q": "(page_size:100)"},
            )

            if response.status_code == 401:
                self._access_token = None
                headers = self._get_headers()
                response = client.get(
                    "/api/v1/database/",
                    headers=headers,
                    params={"q": "(page_size:100)"},
                )

            if response.status_code != 200:
                logger.warning(f"Failed to list databases: {response.text}")
                return []

            data = response.json()
            databases = []
            for db in data.get("result", []):
                databases.append({
                    "id": db.get("id"),
                    "uuid": db.get("uuid"),
                    "database_name": db.get("database_name"),
                    "backend": db.get("backend"),
                })
            return databases

        except httpx.RequestError as e:
            logger.warning(f"Failed to list databases: {e}")
            return []

    def get_database_by_name(self, database_name: str) -> Optional[Dict[str, Any]]:
        """
        Find a database connection by name.

        Args:
            database_name: Name of the database connection

        Returns:
            Database info dict or None if not found
        """
        databases = self.list_databases()
        for db in databases:
            if db.get("database_name") == database_name:
                return db
        return None

    def find_dashboard_by_uuid(self, dashboard_uuid: str) -> Optional[DashboardInfo]:
        """
        Find a dashboard by UUID.

        Note: Superset's REST API doesn't expose the UUID field in list/detail endpoints.
        We need to export each dashboard and check the UUID in the exported YAML.

        Args:
            dashboard_uuid: Dashboard UUID

        Returns:
            DashboardInfo if found, None otherwise
        """
        logger.info(f"Searching for dashboard with UUID: {dashboard_uuid}")

        try:
            # Get all dashboards
            dashboards = self.list_dashboards()
            logger.info(f"Found {len(dashboards)} dashboards to check")

            for dashboard in dashboards:
                dashboard_id = dashboard.id
                logger.info(f"Checking dashboard ID {dashboard_id} ('{dashboard.dashboard_title}')")

                try:
                    # Export dashboard to get UUID from YAML
                    zip_content = self.export_dashboard(dashboard_id)
                    export_uuid = self._extract_uuid_from_export(zip_content)

                    logger.info(f"Dashboard ID {dashboard_id} has UUID: {export_uuid}")

                    if export_uuid == dashboard_uuid:
                        logger.info(f"MATCH FOUND: Dashboard ID {dashboard_id} matches UUID {dashboard_uuid}")
                        # Return dashboard with the UUID filled in
                        return DashboardInfo(
                            id=dashboard.id,
                            uuid=export_uuid,
                            dashboard_title=dashboard.dashboard_title,
                            slug=dashboard.slug,
                            published=dashboard.published,
                            position_json=dashboard.position_json,
                            css=dashboard.css,
                            json_metadata=dashboard.json_metadata,
                            changed_on=dashboard.changed_on,
                            changed_by_name=dashboard.changed_by_name,
                            url=dashboard.url,
                        )
                except Exception as e:
                    logger.warning(f"Failed to check dashboard ID {dashboard_id}: {e}")
                    continue

            logger.info(f"No dashboard found with UUID: {dashboard_uuid}")
            return None

        except Exception as e:
            logger.warning(f"Failed to find dashboard by UUID: {e}")
            return None

    def _extract_uuid_from_export(self, zip_content: bytes) -> Optional[str]:
        """
        Extract dashboard UUID from an export ZIP file.

        Args:
            zip_content: ZIP file bytes

        Returns:
            Dashboard UUID or None
        """
        try:
            with zipfile.ZipFile(io.BytesIO(zip_content)) as zf:
                for name in zf.namelist():
                    if "/dashboards/" in name and name.endswith(".yaml"):
                        content = zf.read(name).decode("utf-8")
                        data = yaml.safe_load(content)
                        if data and "uuid" in data:
                            return data["uuid"]
        except Exception as e:
            logger.warning(f"Failed to extract UUID from export: {e}")
        return None

    def delete_dashboard(self, dashboard_id: int) -> bool:
        """
        Delete a dashboard by ID.

        Args:
            dashboard_id: Dashboard ID to delete

        Returns:
            True if deleted successfully

        Raises:
            SupersetAPIError: If deletion fails
        """
        client = self._get_client()
        headers = self._get_headers()

        logger.info(f"Attempting to delete dashboard ID {dashboard_id}")
        logger.info(f"DELETE URL: {self.base_url}/api/v1/dashboard/{dashboard_id}")

        try:
            response = client.delete(
                f"/api/v1/dashboard/{dashboard_id}",
                headers=headers,
            )

            logger.info(f"Delete response status: {response.status_code}")

            if response.status_code == 401:
                logger.info("Got 401, re-authenticating...")
                self._access_token = None
                headers = self._get_headers()
                response = client.delete(
                    f"/api/v1/dashboard/{dashboard_id}",
                    headers=headers,
                )
                logger.info(f"Delete response after re-auth: {response.status_code}")

            if response.status_code not in (200, 204):
                logger.error(f"Delete failed with status {response.status_code}: {response.text}")
                raise SupersetAPIError(
                    f"Failed to delete dashboard: {response.text}",
                    status_code=response.status_code,
                )

            logger.info(f"Successfully deleted dashboard ID {dashboard_id}")
            return True

        except httpx.RequestError as e:
            logger.error(f"Delete request failed: {e}")
            raise SupersetAPIError(f"Request failed: {e}")

    def delete_chart(self, chart_id: int) -> bool:
        """
        Delete a chart by ID.

        Args:
            chart_id: Chart ID to delete

        Returns:
            True if deleted successfully
        """
        client = self._get_client()
        headers = self._get_headers()

        try:
            response = client.delete(
                f"/api/v1/chart/{chart_id}",
                headers=headers,
            )

            if response.status_code == 401:
                self._access_token = None
                headers = self._get_headers()
                response = client.delete(
                    f"/api/v1/chart/{chart_id}",
                    headers=headers,
                )

            if response.status_code not in (200, 204):
                logger.warning(f"Failed to delete chart {chart_id}: {response.text}")
                return False

            logger.info(f"Deleted chart ID {chart_id}")
            return True

        except httpx.RequestError as e:
            logger.warning(f"Failed to delete chart {chart_id}: {e}")
            return False

    def find_chart_by_uuid(self, chart_uuid: str) -> Optional[int]:
        """
        Find a chart ID by its UUID by exporting and checking.

        Args:
            chart_uuid: Chart UUID to find

        Returns:
            Chart ID if found, None otherwise
        """
        client = self._get_client()
        headers = self._get_headers()

        try:
            # Get all charts
            response = client.get("/api/v1/chart/", headers=headers)

            if response.status_code == 401:
                self._access_token = None
                headers = self._get_headers()
                response = client.get("/api/v1/chart/", headers=headers)

            if response.status_code != 200:
                return None

            charts = response.json().get("result", [])

            # For each chart, export to check UUID
            for chart in charts:
                chart_id = chart.get("id")
                try:
                    export_response = client.get(
                        f"/api/v1/chart/export/",
                        headers=headers,
                        params={"q": f"[{chart_id}]"},
                    )
                    if export_response.status_code == 200:
                        zip_bytes = export_response.content
                        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                            for name in zf.namelist():
                                if "/charts/" in name and name.endswith(".yaml"):
                                    content = zf.read(name).decode("utf-8")
                                    data = yaml.safe_load(content)
                                    if data and data.get("uuid") == chart_uuid:
                                        logger.info(f"Found chart ID {chart_id} for UUID {chart_uuid}")
                                        return chart_id
                except Exception as e:
                    logger.debug(f"Failed to check chart {chart_id}: {e}")
                    continue

            return None

        except Exception as e:
            logger.warning(f"Failed to find chart by UUID: {e}")
            return None

    def _extract_chart_uuids_from_zip(self, zip_content: bytes) -> List[str]:
        """
        Extract all chart UUIDs from an export ZIP file.

        Args:
            zip_content: ZIP file bytes

        Returns:
            List of chart UUIDs
        """
        uuids = []
        try:
            with zipfile.ZipFile(io.BytesIO(zip_content)) as zf:
                for name in zf.namelist():
                    if "/charts/" in name and name.endswith(".yaml"):
                        content = zf.read(name).decode("utf-8")
                        data = yaml.safe_load(content)
                        if data and "uuid" in data:
                            uuids.append(data["uuid"])
        except Exception as e:
            logger.warning(f"Failed to extract chart UUIDs: {e}")
        return uuids

    def import_dashboard_clean(
        self,
        zip_content: bytes,
        dashboard_uuid: Optional[str] = None,
    ) -> bool:
        """
        Import a dashboard, deleting existing dashboard AND its charts first.
        This ensures a truly clean import without any merge artifacts.

        Args:
            zip_content: ZIP file content as bytes
            dashboard_uuid: Optional UUID to look for existing dashboard to delete

        Returns:
            True if import was successful

        Raises:
            SupersetAPIError: If import fails
        """
        logger.info(f"=== CLEAN IMPORT START ===")
        logger.info(f"Dashboard UUID: {dashboard_uuid}")
        logger.info(f"ZIP content size: {len(zip_content)} bytes")

        # Extract and delete existing charts to ensure clean replacement
        chart_uuids = self._extract_chart_uuids_from_zip(zip_content)
        logger.info(f"Found {len(chart_uuids)} charts to import")

        for chart_uuid in chart_uuids:
            chart_id = self.find_chart_by_uuid(chart_uuid)
            if chart_id:
                logger.info(f"Deleting existing chart ID {chart_id} (UUID: {chart_uuid})")
                self.delete_chart(chart_id)

        # Check if dashboard exists (for logging)
        if dashboard_uuid:
            existing = self.find_dashboard_by_uuid(dashboard_uuid)
            if existing:
                logger.info(f"Updating existing dashboard: '{existing.dashboard_title}' (ID: {existing.id})")
            else:
                logger.info(f"Creating new dashboard")

        # Proceed with import (overwrite=True as fallback)
        logger.info(f"Proceeding with import (overwrite=True)...")
        result = self.import_dashboard(zip_content, overwrite=True)
        logger.info(f"=== CLEAN IMPORT END (success={result}) ===")
        return result

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self) -> "SupersetAPIClient":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()
