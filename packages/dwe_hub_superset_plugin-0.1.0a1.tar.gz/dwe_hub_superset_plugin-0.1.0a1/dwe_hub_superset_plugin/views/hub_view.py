"""
Flask-AppBuilder UI view for DWE Hub integration.

Provides Export to Hub and Import from Hub tabs.
"""

import logging
import os
from flask import current_app, request, jsonify, render_template_string, session
from flask_appbuilder import BaseView, expose
from flask_login import current_user
from flask_wtf.csrf import generate_csrf

logger = logging.getLogger(__name__)

# HTML Template for Hub UI
HUB_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DWE Hub - {{ title }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    .hub-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 20px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }
    .hub-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 2px solid #6c5ce7;
    }
    .hub-header h1 { color: #1a1a1a; margin: 0; font-size: 24px; }
    .hub-tabs {
        display: flex;
        gap: 0;
        margin-bottom: 24px;
        border-bottom: 2px solid #e0e0e0;
    }
    .hub-tab {
        padding: 12px 24px;
        background: none;
        border: none;
        font-size: 16px;
        font-weight: 500;
        color: #666;
        cursor: pointer;
        border-bottom: 3px solid transparent;
        margin-bottom: -2px;
        text-decoration: none;
    }
    .hub-tab:hover { color: #6c5ce7; }
    .hub-tab.active {
        color: #6c5ce7;
        border-bottom-color: #6c5ce7;
    }
    .section {
        background: white;
        border-radius: 8px;
        padding: 24px;
        margin-bottom: 24px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .section h2 { margin-top: 0; color: #333; border-bottom: 1px solid #eee; padding-bottom: 12px; font-size: 18px; }
    .asset-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 20px;
    }
    .asset-card {
        background: #fafafa;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        padding: 16px;
        transition: all 0.2s;
    }
    .asset-card:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        transform: translateY(-2px);
    }
    .asset-name { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 8px; }
    .asset-meta { color: #666; font-size: 13px; margin-bottom: 8px; }
    .asset-owner { font-size: 12px; color: #999; }
    .visibility-badge {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 500;
    }
    .visibility-public { background: #e8f5e9; color: #2e7d32; }
    .visibility-private { background: #fff3e0; color: #f57c00; }
    .btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 16px;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.2s;
    }
    .btn-primary { background: #6c5ce7; color: white; }
    .btn-primary:hover { background: #5b4cdb; color: white; }
    .btn-secondary { background: white; color: #333; border: 1px solid #ddd; }
    .btn-secondary:hover { background: #f5f5f5; }
    .btn-success { background: #00b894; color: white; }
    .btn-success:hover { background: #00a187; color: white; }
    .card-actions { display: flex; gap: 8px; margin-top: 12px; }
    .card-actions .btn { flex: 1; justify-content: center; }
    .form-group { margin-bottom: 16px; }
    .form-group label { display: block; margin-bottom: 6px; font-weight: 500; color: #333; }
    .form-control {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 14px;
    }
    .form-control:focus { outline: none; border-color: #6c5ce7; }
    select.form-control { background: white; }
    textarea.form-control { min-height: 100px; resize: vertical; }
    .result-box { padding: 20px; border-radius: 8px; margin-bottom: 20px; }
    .result-box.success { background: #e8f5e9; color: #2e7d32; }
    .result-box.error { background: #ffebee; color: #c62828; }
    .result-box h2 { margin-top: 0; border: none; padding: 0; }
    .navbar-hub { background: #6c5ce7; padding: 10px 20px; }
    .navbar-hub a { color: white; text-decoration: none; font-weight: 500; }
    .navbar-hub a:hover { text-decoration: underline; }
    .empty-state { text-align: center; padding: 40px; color: #999; }
    .search-bar {
        display: flex;
        gap: 12px;
        margin-bottom: 20px;
    }
    .search-bar input { flex: 1; }
    .asset-thumbnail {
        width: 100%;
        height: 120px;
        background: #f0f0f0;
        border-radius: 6px;
        margin-bottom: 12px;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .asset-thumbnail img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .asset-thumbnail .no-preview {
        color: #999;
        font-size: 32px;
    }
    .version-list { margin-top: 12px; }
    .version-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 12px;
        background: #f5f5f5;
        border-radius: 4px;
        margin-bottom: 6px;
        font-size: 13px;
    }
    .hub-status { padding: 8px 16px; background: #e8f5e9; color: #2e7d32; border-radius: 20px; font-size: 13px; }
    .hub-status.disconnected { background: #ffebee; color: #c62828; }
    </style>
</head>
<body style="background: #f5f5f5; margin: 0;">
    <nav class="navbar-hub">
        <a href="/superset/welcome/">← Back to Superset</a>
    </nav>
    <div class="hub-container">
        {{ content|safe }}
    </div>
</body>
</html>
"""


def get_current_username():
    """Get current user's username."""
    if current_user and current_user.is_authenticated:
        return getattr(current_user, 'username', 'admin')
    return 'anonymous'


class HubView(BaseView):
    """DWE Hub integration view."""

    route_base = "/hub"
    default_view = "gallery"

    def _get_hub_config(self):
        """Get Hub configuration."""
        return {
            'hub_url': current_app.config.get('DWE_HUB_URL'),
            'hub_user': current_app.config.get('DWE_HUB_USER'),
            'hub_password': current_app.config.get('DWE_HUB_PASSWORD'),
            'hub_token': current_app.config.get('DWE_HUB_TOKEN'),  # Legacy fallback
            'superset_env': current_app.config.get('SUPERSET_ENV', 'dev'),
            'superset_url': current_app.config.get('SUPERSET_BASE_URL', 'http://localhost:8088'),
        }

    def _get_hub_client(self):
        """Get Hub client if configured."""
        config = self._get_hub_config()
        if not config['hub_url']:
            return None

        from dwe_hub_superset_plugin.services.hub_client import HubClient

        # Prefer username/password authentication
        if config['hub_user'] and config['hub_password']:
            return HubClient(
                hub_url=config['hub_url'],
                username=config['hub_user'],
                password=config['hub_password'],
            )
        # Fallback to token auth (legacy)
        elif config['hub_token']:
            return HubClient(
                hub_url=config['hub_url'],
                api_token=config['hub_token'],
            )

        return None

    def _get_superset_client(self):
        """Get Superset API client for local instance."""
        from dwe_hub_superset_plugin.services.superset_api import SupersetAPIClient
        # Use configured base URL or fall back to localhost
        # Inside container, we use localhost:8088 directly
        superset_url = current_app.config.get('SUPERSET_BASE_URL', 'http://localhost:8088')
        logger.info(f"Using Superset URL: {superset_url}")
        return SupersetAPIClient(
            base_url=superset_url,
            username=current_app.config.get('SUPERSET_ADMIN_USER', 'admin'),
            password=current_app.config.get('SUPERSET_ADMIN_PASSWORD', 'admin'),
        )

    def _extract_dashboard_uuid_from_zip(self, zip_content: bytes) -> str:
        """
        Extract the dashboard UUID from a Superset export ZIP file.

        Args:
            zip_content: ZIP file content as bytes

        Returns:
            Dashboard UUID or None if not found
        """
        import io
        import zipfile
        import yaml

        try:
            with zipfile.ZipFile(io.BytesIO(zip_content)) as zf:
                for name in zf.namelist():
                    if '/dashboards/' in name and name.endswith('.yaml'):
                        content = zf.read(name).decode('utf-8')
                        data = yaml.safe_load(content)
                        if data and data.get('uuid'):
                            return data['uuid']
        except Exception as e:
            logger.warning(f"Failed to extract dashboard UUID from ZIP: {e}")

        return None

    def _render(self, title, content):
        """Render content using the hub template."""
        return render_template_string(HUB_TEMPLATE, title=title, content=content)

    def _render_tabs(self, active_tab):
        """Render the tab navigation."""
        tabs = [
            ('gallery', 'Import from Hub', '/hub/'),
            ('export', 'Export to Hub', '/hub/export'),
            ('my-assets', 'My Published Assets', '/hub/my-assets'),
        ]
        html = '<div class="hub-tabs">'
        for tab_id, label, url in tabs:
            active = 'active' if tab_id == active_tab else ''
            html += f'<a href="{url}" class="hub-tab {active}">{label}</a>'
        html += '</div>'
        return html

    @expose("/")
    def gallery(self):
        """Gallery view - browse and import dashboards from Hub."""
        config = self._get_hub_config()
        hub_client = self._get_hub_client()

        search = request.args.get('search', '')
        page = int(request.args.get('page', 1))

        # Check Hub connection
        hub_connected = False
        assets = []
        total = 0

        if hub_client:
            try:
                hub_connected = hub_client.health_check()
                if hub_connected:
                    assets, total = hub_client.list_assets(
                        category='dashboard',
                        visibility='public',
                        search=search if search else None,
                        page=page,
                        per_page=12,
                    )
            except Exception as e:
                logger.error(f"Hub error: {e}")

        # Build content
        content = f"""
            <div class="hub-header">
                <h1>DWE Hub</h1>
                <span class="hub-status {'disconnected' if not hub_connected else ''}">
                    {'Connected' if hub_connected else 'Not Connected'}
                </span>
            </div>

            {self._render_tabs('gallery')}

            <div class="section">
                <h2>Browse Public Dashboards</h2>
                <div class="search-bar">
                    <input type="text" class="form-control" placeholder="Search dashboards..."
                           value="{search}" id="search-input">
                    <button class="btn btn-primary" onclick="doSearch()">Search</button>
                </div>
        """

        if not hub_connected:
            content += """
                <div class="empty-state">
                    <p>DWE Hub is not configured or not reachable.</p>
                    <p>Set <code>DWE_HUB_URL</code>, <code>DWE_HUB_USER</code>, and <code>DWE_HUB_PASSWORD</code> in your configuration.</p>
                </div>
            """
        elif assets:
            content += '<div class="asset-grid">'
            for asset in assets:
                versions_html = ''
                if asset.versions:
                    latest = asset.versions[0]
                    versions_html = f'<span>v{latest.version_number}</span>'

                # Build thumbnail HTML - use proxy endpoint for browser access
                thumbnail_html = '<div class="no-preview">📊</div>'
                if asset.preview_thumbnail_key:
                    thumbnail_url = f"/hub/thumbnail/{asset.uuid}"
                    thumbnail_html = f'<img src="{thumbnail_url}" alt="{asset.name}" onerror="this.parentElement.innerHTML=\'<div class=no-preview>📊</div>\'">'

                content += f"""
                    <div class="asset-card">
                        <div class="asset-thumbnail">
                            {thumbnail_html}
                        </div>
                        <div class="asset-name">{asset.name}</div>
                        <div class="asset-meta">
                            {asset.description[:100] + '...' if asset.description and len(asset.description) > 100 else (asset.description or 'No description')}
                        </div>
                        <div class="asset-owner">
                            By {asset.owner} • {versions_html}
                            <span class="visibility-badge visibility-{asset.visibility}">{asset.visibility}</span>
                        </div>
                        <div class="card-actions">
                            <a href="/hub/preview/{asset.uuid}" class="btn btn-secondary">Preview</a>
                            <a href="/hub/import/{asset.uuid}" class="btn btn-success">Import</a>
                        </div>
                    </div>
                """
            content += '</div>'

            # Pagination
            if total > 12:
                pages = (total + 11) // 12
                content += '<div style="text-align: center; margin-top: 20px;">'
                for p in range(1, pages + 1):
                    active = 'btn-primary' if p == page else 'btn-secondary'
                    content += f'<a href="/hub/?page={p}&search={search}" class="btn {active}" style="margin: 0 4px;">{p}</a>'
                content += '</div>'
        else:
            content += '<div class="empty-state">No public dashboards found.</div>'

        content += """
            </div>
            <script>
            function doSearch() {
                const search = document.getElementById('search-input').value;
                window.location.href = '/hub/?search=' + encodeURIComponent(search);
            }
            document.getElementById('search-input').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') doSearch();
            });
            </script>
        """

        return self._render("Gallery", content)

    @expose("/export")
    def export_list(self):
        """List local dashboards for export."""
        config = self._get_hub_config()
        hub_client = self._get_hub_client()
        superset_client = self._get_superset_client()

        hub_connected = hub_client and hub_client.health_check() if hub_client else False

        # Get local dashboards
        dashboards = []
        try:
            dashboards = superset_client.list_dashboards()
        except Exception as e:
            logger.error(f"Error listing dashboards: {e}")

        content = f"""
            <div class="hub-header">
                <h1>DWE Hub</h1>
                <span class="hub-status {'disconnected' if not hub_connected else ''}">
                    {'Connected' if hub_connected else 'Not Connected'}
                </span>
            </div>

            {self._render_tabs('export')}

            <div class="section">
                <h2>Export Dashboard to Hub</h2>
                <p style="color: #666; margin-bottom: 20px;">
                    Select a dashboard to publish to the DWE Hub.
                    Published dashboards can be shared with others or kept private.
                </p>
        """

        if not hub_connected:
            content += """
                <div class="empty-state">
                    <p>DWE Hub is not configured or not reachable.</p>
                    <p>Set <code>DWE_HUB_URL</code>, <code>DWE_HUB_USER</code>, and <code>DWE_HUB_PASSWORD</code> in your configuration.</p>
                </div>
            """
        elif dashboards:
            content += '<div class="asset-grid">'
            for d in dashboards:
                content += f"""
                    <div class="asset-card">
                        <div class="asset-name">{d.dashboard_title}</div>
                        <div class="asset-meta">
                            {f"Modified: {d.changed_on}" if d.changed_on else ""}
                        </div>
                        <div style="font-family: monospace; font-size: 11px; color: #999; margin-top: 8px;">
                            UUID: {d.uuid}
                        </div>
                        <div class="card-actions">
                            <a href="/hub/export/{d.id}" class="btn btn-primary">Publish to Hub</a>
                        </div>
                    </div>
                """
            content += '</div>'
        else:
            content += '<div class="empty-state">No dashboards found. Create a dashboard first.</div>'

        content += "</div>"

        return self._render("Export", content)

    @expose("/export/<int:dashboard_id>", methods=["GET", "POST"])
    def export_dashboard(self, dashboard_id):
        """Export a specific dashboard to Hub."""
        logger.info(f"export_dashboard called: method={request.method}, dashboard_id={dashboard_id}")

        config = self._get_hub_config()
        hub_client = self._get_hub_client()
        superset_client = self._get_superset_client()

        if not hub_client:
            content = """
                <div class="result-box error">
                    <h2>Hub Not Configured</h2>
                    <p>Set DWE_HUB_URL, DWE_HUB_USER, and DWE_HUB_PASSWORD in your configuration.</p>
                </div>
                <a href="/hub/export" class="btn btn-primary">← Back</a>
            """
            return self._render("Export Error", content)

        # Get dashboard
        try:
            dashboard = superset_client.get_dashboard(dashboard_id)
            logger.info(f"Dashboard loaded: id={dashboard.id}, uuid={dashboard.uuid}, title={dashboard.dashboard_title}")
        except Exception as e:
            content = f"""
                <div class="result-box error">
                    <h2>Dashboard Not Found</h2>
                    <p>{str(e)}</p>
                </div>
                <a href="/hub/export" class="btn btn-primary">← Back</a>
            """
            return self._render("Export Error", content)

        if request.method == "POST":
            # Process export
            logger.info(f"POST request received for dashboard export: {dashboard_id}")
            name = request.form.get("name", dashboard.dashboard_title)
            description = request.form.get("description", "")
            visibility = request.form.get("visibility", "private")
            commit_message = request.form.get("commit_message", "")

            logger.info(f"Publishing dashboard '{name}' with visibility={visibility}")

            try:
                # Export dashboard as ZIP
                logger.info(f"Exporting dashboard {dashboard_id} from Superset...")
                zip_content = superset_client.export_dashboard(dashboard_id)
                logger.info(f"Export successful, got {len(zip_content)} bytes")

                # Extract dataset metadata from the ZIP
                from dwe_hub_superset_plugin.services.dataset_extractor import DatasetExtractor
                dataset_snapshots = DatasetExtractor.extract_from_zip(zip_content)
                logger.info(f"Extracted {len(dataset_snapshots)} dataset snapshots")

                # Publish to Hub with dataset snapshots
                logger.info(f"Publishing to Hub at {config['hub_url']}...")
                result = hub_client.publish_dashboard(
                    name=name,
                    zip_content=zip_content,
                    description=description,
                    visibility=visibility,
                    source_uuid=dashboard.uuid,
                    source_environment=config['superset_env'],
                    commit_message=commit_message,
                    published_by=get_current_username(),
                    dataset_snapshots=dataset_snapshots,
                )
                logger.info(f"Hub publish result: {result}")

                asset = result.get('asset', {})
                version = result.get('version', {})

                content = f"""
                    <div class="result-box success">
                        <h2>Published Successfully!</h2>
                        <p><strong>Dashboard:</strong> {name}</p>
                        <p><strong>Version:</strong> {version.get('version_number', 1)}</p>
                        <p><strong>Visibility:</strong> {visibility}</p>
                    </div>
                    <a href="/hub/export" class="btn btn-primary">← Back to Export</a>
                    <a href="/hub/my-assets" class="btn btn-secondary">View My Assets</a>
                """
                return self._render("Export Success", content)

            except Exception as e:
                logger.error(f"Export failed: {e}")
                content = f"""
                    <div class="result-box error">
                        <h2>Export Failed</h2>
                        <p>{str(e)}</p>
                    </div>
                    <a href="/hub/export/{dashboard_id}" class="btn btn-primary">← Try Again</a>
                """
                return self._render("Export Error", content)

        # Check if dashboard already exists in Hub (by name)
        existing_asset = None
        existing_description = ""
        existing_visibility = "private"
        current_version = 0
        try:
            # Search for existing asset with the same name
            assets, _ = hub_client.list_assets(
                category='dashboard',
                search=dashboard.dashboard_title,
                per_page=50,
            )
            # Find exact match by name
            for asset in assets:
                if asset.name == dashboard.dashboard_title:
                    existing_asset = asset
                    existing_description = asset.description or ""
                    existing_visibility = asset.visibility or "private"
                    if asset.versions:
                        current_version = asset.versions[0].version_number
                    break
        except Exception as e:
            logger.warning(f"Failed to check for existing asset: {e}")

        # Build the form with pre-filled values
        csrf_token = generate_csrf()

        # Show update notice if asset exists
        update_notice = ""
        if existing_asset:
            update_notice = f"""
                <div style="background: #e3f2fd; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;">
                    <strong style="color: #1565c0;">📦 Updating Existing Dashboard</strong>
                    <p style="margin: 8px 0 0 0; color: #666; font-size: 13px;">
                        This dashboard already exists in the Hub (v{current_version}).
                        Publishing will create version {current_version + 1}.
                    </p>
                </div>
            """
            commit_placeholder = f"e.g., Updated charts, Fixed filters..."
        else:
            commit_placeholder = "e.g., Initial publish"

        # Escape description for HTML
        import html
        escaped_description = html.escape(existing_description)

        content = f"""
            <div class="hub-header">
                <h1>Publish to Hub</h1>
            </div>

            <div class="section">
                <h2>{dashboard.dashboard_title}</h2>
                <p style="font-family: monospace; font-size: 12px; color: #999;">UUID: {dashboard.uuid}</p>

                {update_notice}

                <form method="POST" style="margin-top: 20px;">
                    <input type="hidden" name="csrf_token" value="{csrf_token}">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" class="form-control"
                               value="{dashboard.dashboard_title}" required>
                    </div>

                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" class="form-control"
                                  placeholder="Describe what this dashboard shows...">{escaped_description}</textarea>
                        {"<small style='color: #666;'>Description is managed in DWE Hub and won't be overwritten.</small>" if existing_asset else ""}
                    </div>

                    <div class="form-group">
                        <label>Visibility (for this version)</label>
                        <select name="visibility" class="form-control">
                            <option value="private" {"selected" if existing_visibility == "private" else ""}>Private (Only you can see)</option>
                            <option value="public" {"selected" if existing_visibility == "public" else ""}>Public (Anyone can discover)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Commit Message</label>
                        <input type="text" name="commit_message" class="form-control"
                               placeholder="{commit_placeholder}" required>
                    </div>

                    <div style="display: flex; gap: 12px; margin-top: 24px;">
                        <a href="/hub/export" class="btn btn-secondary">Cancel</a>
                        <button type="submit" class="btn btn-primary">
                            {"Update in Hub" if existing_asset else "Publish to Hub"}
                        </button>
                    </div>
                </form>
            </div>
        """

        return self._render("Publish Dashboard", content)

    @expose("/import/<asset_uuid>")
    def import_dashboard(self, asset_uuid):
        """Import a dashboard from Hub."""
        logger.info(f"Import requested for asset: {asset_uuid}")

        config = self._get_hub_config()
        hub_client = self._get_hub_client()
        superset_client = self._get_superset_client()

        if not hub_client:
            content = """
                <div class="result-box error">
                    <h2>Hub Not Configured</h2>
                    <p>Set DWE_HUB_URL, DWE_HUB_USER, and DWE_HUB_PASSWORD in your configuration.</p>
                </div>
                <a href="/hub/" class="btn btn-primary">← Back</a>
            """
            return self._render("Import Error", content)

        version = request.args.get('version', type=int)
        override = request.args.get('override') == 'true'

        try:
            # Get asset info
            logger.info(f"Getting asset info from Hub...")
            asset = hub_client.get_asset(asset_uuid)
            logger.info(f"Asset found: {asset.name}")

            # Determine version to import
            import_version = version
            if not import_version and asset.versions:
                import_version = asset.versions[0].version_number
            elif not import_version:
                import_version = 1

            # Validate datasets before import (unless override is requested)
            if not override:
                validation_result = self._validate_import_datasets(
                    hub_client, superset_client, asset_uuid, import_version
                )
                if validation_result:
                    # Validation returned HTML content - show validation errors
                    return self._render(f"Import Validation - {asset.name}", validation_result)

            # Download from Hub
            logger.info(f"Downloading from Hub (version={import_version})...")
            zip_content = hub_client.download_dashboard(asset_uuid, version=version)
            logger.info(f"Downloaded {len(zip_content)} bytes")

            # Extract dashboard UUID from the ZIP to enable clean import
            dashboard_uuid = self._extract_dashboard_uuid_from_zip(zip_content)
            logger.info(f"Dashboard UUID from ZIP: {dashboard_uuid}")

            # Import to Superset (clean import - deletes existing first)
            logger.info(f"Importing to local Superset (clean import)...")
            superset_client.import_dashboard_clean(zip_content, dashboard_uuid=dashboard_uuid)
            logger.info(f"Import successful!")

            # Record the import in Hub
            try:
                logger.info(f"Recording import in Hub...")
                hub_client.record_import(
                    asset_uuid=asset_uuid,
                    version_number=import_version,
                    environment_name=config['superset_env'],
                    environment_url=config['superset_url'],
                )
                logger.info(f"Import recorded successfully")
            except Exception as record_err:
                # Don't fail the import if recording fails
                logger.warning(f"Failed to record import: {record_err}")

            content = f"""
                <div class="result-box success">
                    <h2>Import Successful!</h2>
                    <p><strong>Dashboard:</strong> {asset.name}</p>
                    <p><strong>Version:</strong> v{import_version}</p>
                    <p><strong>Environment:</strong> {config['superset_env']}</p>
                    <p>The dashboard has been imported to your Superset instance.</p>
                </div>
                <a href="/hub/" class="btn btn-primary">← Back to Gallery</a>
                <a href="/superset/dashboard/list/" class="btn btn-secondary">View Dashboards</a>
            """
            return self._render("Import Success", content)

        except Exception as e:
            import traceback
            logger.error(f"Import failed: {e}")
            logger.error(traceback.format_exc())
            content = f"""
                <div class="result-box error">
                    <h2>Import Failed</h2>
                    <p>{str(e)}</p>
                </div>
                <a href="/hub/" class="btn btn-primary">← Back to Gallery</a>
            """
            return self._render("Import Error", content)

    def _validate_import_datasets(self, hub_client, superset_client, asset_uuid, version_number):
        """
        Validate dataset compatibility before import.

        Returns HTML content if validation fails with issues, or None if OK to proceed.
        """
        try:
            # Get Hub dataset snapshots
            hub_datasets = hub_client.get_version_datasets(asset_uuid, version_number)

            if not hub_datasets:
                # No datasets to validate - proceed with import
                logger.info("No dataset snapshots for this version - skipping validation")
                return None

            logger.info(f"Validating {len(hub_datasets)} datasets before import")

            # Convert hub datasets to dicts for the API call
            hub_datasets_dict = [
                {
                    "uuid": ds.uuid,
                    "table_name": ds.table_name,
                    "schema": ds.schema,
                    "database_uuid": ds.database_uuid,
                    "database_name": ds.database_name,
                    "columns": ds.columns,
                    "metrics": ds.metrics,
                }
                for ds in hub_datasets
            ]

            # Fetch local datasets with fallback to name/schema matching
            # This handles the case where datasets exist in prod with different UUIDs
            local_datasets = superset_client.get_datasets_for_validation(hub_datasets_dict)
            logger.info(f"Found {len(local_datasets)} matching local datasets")

            # Fetch local database connections
            local_databases = superset_client.list_databases()
            logger.info(f"Found {len(local_databases)} local database connections")

            # Perform validation
            from dwe_hub_superset_plugin.services.validation_service import DatasetValidationService
            validator = DatasetValidationService()

            result = validator.validate(hub_datasets_dict, local_datasets, local_databases)

            if result.valid and result.warning_count == 0:
                # No issues - proceed with import
                logger.info("Dataset validation passed - no issues")
                return None

            # Build validation error page
            return self._render_validation_errors(
                asset_uuid, version_number, result, hub_datasets
            )

        except Exception as e:
            logger.warning(f"Dataset validation failed: {e}")
            # On validation error, allow import to proceed
            return None

    def _render_validation_errors(self, asset_uuid, version_number, validation_result, hub_datasets):
        """Render the validation error page."""
        critical = [i for i in validation_result.issues if i.severity == "critical"]
        warnings = [i for i in validation_result.issues if i.severity == "warning"]
        info = [i for i in validation_result.issues if i.severity == "info"]

        # Build issues HTML
        issues_html = ""

        if critical:
            issues_html += """
                <div style="background: #ffebee; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                    <h3 style="color: #c62828; margin-top: 0;">Critical Issues</h3>
                    <p style="color: #c62828; margin-bottom: 12px;">
                        These issues must be resolved before import can proceed.
                    </p>
                    <ul style="margin: 0; padding-left: 20px;">
            """
            for issue in critical:
                issues_html += f"<li><strong>{issue.dataset_name}</strong>: {issue.message}</li>"
            issues_html += "</ul></div>"

        if warnings:
            issues_html += """
                <div style="background: #fff3e0; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                    <h3 style="color: #f57c00; margin-top: 0;">Warnings</h3>
                    <p style="color: #666; margin-bottom: 12px;">
                        These may cause issues with the imported dashboard.
                    </p>
                    <ul style="margin: 0; padding-left: 20px;">
            """
            for issue in warnings:
                details = ""
                if issue.expected and issue.actual:
                    details = f" (expected: {issue.expected}, found: {issue.actual})"
                issues_html += f"<li><strong>{issue.dataset_name}</strong>: {issue.message}{details}</li>"
            issues_html += "</ul></div>"

        if info:
            issues_html += """
                <div style="background: #e3f2fd; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                    <h3 style="color: #1565c0; margin-top: 0;">Info</h3>
                    <ul style="margin: 0; padding-left: 20px;">
            """
            for issue in info:
                issues_html += f"<li><strong>{issue.dataset_name}</strong>: {issue.message}</li>"
            issues_html += "</ul></div>"

        # Required databases info
        unique_databases = list({ds.database_name for ds in hub_datasets if ds.database_name})
        databases_html = '<div class="section"><h3>Required Database Connections</h3>'
        databases_html += '<div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 16px;">'
        for db_name in unique_databases:
            databases_html += f'''
                <span style="background: #e3f2fd; padding: 6px 12px; border-radius: 4px; font-size: 13px;">
                    <i style="margin-right: 4px;">🔌</i> {db_name}
                </span>
            '''
        databases_html += '</div></div>'

        # Required datasets info
        datasets_html = databases_html + '<div class="section"><h3>Required Datasets</h3>'
        for ds in hub_datasets:
            schema_prefix = f"{ds.schema}." if ds.schema else ""
            datasets_html += f"""
                <div style="background: #fafafa; padding: 12px; border-radius: 6px; margin-bottom: 8px;">
                    <strong>{schema_prefix}{ds.table_name}</strong>
                    <span style="color: #666; font-size: 12px; margin-left: 8px;">
                        ({len(ds.columns)} columns, {len(ds.metrics)} metrics)
                    </span>
                    <div style="color: #999; font-size: 12px;">
                        Database: {ds.database_name}
                    </div>
                </div>
            """
        datasets_html += '</div>'

        # Actions
        can_override = validation_result.can_override and not critical
        actions_html = '<div style="display: flex; gap: 12px; margin-top: 24px;">'
        actions_html += '<a href="/hub/" class="btn btn-secondary">← Cancel</a>'

        if can_override:
            actions_html += f'''
                <a href="/hub/import/{asset_uuid}?version={version_number}&override=true"
                   class="btn btn-primary"
                   onclick="return confirm('Are you sure you want to import despite the warnings?')">
                   Import Anyway
                </a>
            '''

        actions_html += '</div>'

        content = f"""
            <div class="hub-header">
                <h1>Dataset Validation</h1>
            </div>

            <div class="section">
                <h2>Import Validation Results</h2>
                <p style="color: #666; margin-bottom: 20px;">
                    Found compatibility issues with datasets required by this dashboard.
                </p>

                {issues_html}
                {datasets_html}
                {actions_html}
            </div>
        """

        return content

    @expose("/preview/<asset_uuid>")
    def preview_asset(self, asset_uuid):
        """Preview an asset before importing."""
        config = self._get_hub_config()
        hub_client = self._get_hub_client()

        if not hub_client:
            content = """
                <div class="result-box error">
                    <h2>Hub Not Configured</h2>
                    <p>Set DWE_HUB_URL, DWE_HUB_USER, and DWE_HUB_PASSWORD in your configuration.</p>
                </div>
                <a href="/hub/" class="btn btn-primary">← Back</a>
            """
            return self._render("Preview Error", content)

        try:
            asset = hub_client.get_asset(asset_uuid)

            # Check if already imported in this environment
            import_status_html = ''
            try:
                latest_import = hub_client.get_latest_import(
                    asset_uuid,
                    config['superset_env']
                )
                if latest_import:
                    import_status_html = f"""
                        <div style="background: #e3f2fd; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;">
                            <strong style="color: #1565c0;">Already imported to {config['superset_env']}</strong>
                            <p style="margin: 8px 0 0 0; color: #666; font-size: 13px;">
                                Version {latest_import.version_number} imported on {latest_import.imported_at[:10] if latest_import.imported_at else 'unknown'}
                                {f' by {latest_import.imported_by}' if latest_import.imported_by else ''}
                            </p>
                        </div>
                    """
            except Exception as import_err:
                logger.warning(f"Failed to get import status: {import_err}")

            # Build versions list with import indicators
            versions_html = ''
            import_records = []
            try:
                import_records = hub_client.get_asset_imports(asset_uuid, config['superset_env'])
            except Exception:
                pass

            # Find the latest imported version for this environment
            latest_imported_version = None
            if import_records:
                latest_imported_version = max(r.version_number for r in import_records)

            if asset.versions:
                versions_html = '<div class="version-list">'
                for v in asset.versions:
                    # Only show "Imported" badge on the latest imported version
                    is_latest_imported = v.version_number == latest_imported_version
                    imported_badge = '<span style="background: #c8e6c9; color: #2e7d32; padding: 2px 8px; border-radius: 4px; font-size: 11px; margin-left: 8px;">Imported</span>' if is_latest_imported else ''

                    # Build media list for this version
                    media_html = ''
                    if hasattr(v, 'media') and v.media:
                        media_html = '<div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #e0e0e0;">'
                        media_html += '<div style="font-size: 11px; color: #666; margin-bottom: 6px;">Attached files:</div>'
                        media_html += '<div style="display: flex; flex-wrap: wrap; gap: 6px;">'
                        for m in v.media:
                            # Determine icon based on mime type
                            if 'image' in m.mime_type:
                                icon = '🖼️'
                            elif 'video' in m.mime_type:
                                icon = '🎬'
                            elif 'pdf' in m.mime_type:
                                icon = '📄'
                            else:
                                icon = '📎'
                            media_html += f'''
                                <a href="/hub/media/{m.id}" target="_blank"
                                   style="display: inline-flex; align-items: center; gap: 4px; padding: 4px 8px; background: #e3f2fd; border-radius: 4px; font-size: 11px; color: #1565c0; text-decoration: none;">
                                    {icon} {m.title or m.filename}
                                </a>
                            '''
                        media_html += '</div></div>'

                    # Screenshot thumbnail if available - use proxy endpoint
                    screenshot_html = ''
                    if v.thumbnail_key:
                        screenshot_html = f'''
                            <a href="/hub/screenshot/{asset.uuid}?version={v.version_number}" target="_blank"
                               style="display: block; margin-top: 8px;">
                                <img src="/hub/screenshot/{asset.uuid}?version={v.version_number}&thumbnail=true"
                                     alt="Screenshot" style="max-width: 100%; max-height: 100px; border-radius: 4px; border: 1px solid #ddd;">
                            </a>
                        '''

                    # Build datasets list for this version
                    datasets_version_html = ''
                    try:
                        version_datasets = hub_client.get_version_datasets(asset.uuid, v.version_number)
                        if version_datasets:
                            datasets_version_html = '''
                                <details style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #e0e0e0;">
                                    <summary style="cursor: pointer; font-size: 11px; color: #666;">
                                        📊 Required Datasets (''' + str(len(version_datasets)) + ''')
                                    </summary>
                                    <div style="margin-top: 8px;">
                            '''
                            for ds in version_datasets:
                                schema_prefix = f"{ds.schema}." if ds.schema else ""
                                # Columns preview
                                columns_preview = ''
                                if ds.columns:
                                    col_names = [c.get('column_name', '') for c in ds.columns[:5]]
                                    columns_preview = ', '.join(col_names)
                                    if len(ds.columns) > 5:
                                        columns_preview += f' +{len(ds.columns) - 5} more'

                                datasets_version_html += f'''
                                    <div style="background: #f8f9fa; padding: 8px 12px; border-radius: 4px; margin-bottom: 6px; font-size: 12px;">
                                        <div style="font-weight: 500;">{schema_prefix}{ds.table_name}</div>
                                        <div style="color: #666; font-size: 11px;">
                                            🔌 {ds.database_name} • {len(ds.columns)} cols, {len(ds.metrics)} metrics
                                        </div>
                                        <div style="color: #999; font-size: 10px; margin-top: 4px;">
                                            {columns_preview}
                                        </div>
                                    </div>
                                '''
                            datasets_version_html += '</div></details>'
                    except Exception as ds_err:
                        logger.debug(f"Failed to get datasets for version {v.version_number}: {ds_err}")

                    versions_html += f"""
                        <div class="version-item" style="flex-direction: column; align-items: stretch;">
                            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                                <div>
                                    <span style="font-weight: 500;">v{v.version_number}</span>{imported_badge}
                                    <span style="margin-left: 8px; padding: 2px 6px; border-radius: 4px; font-size: 10px; background: {'#e8f5e9' if v.visibility == 'public' else '#fff3e0'}; color: {'#2e7d32' if v.visibility == 'public' else '#f57c00'};">
                                        {v.visibility}
                                    </span>
                                    <div style="color: #666; font-size: 12px; margin-top: 2px;">
                                        {v.commit_message or 'No commit message'}
                                    </div>
                                    <div style="color: #999; font-size: 11px;">
                                        {v.published_by or 'Unknown'} • {v.created_at[:10] if v.created_at else ''}
                                    </div>
                                </div>
                                <a href="/hub/import/{asset.uuid}?version={v.version_number}"
                                   class="btn btn-secondary" style="padding: 4px 12px;">
                                   {'Re-import' if is_latest_imported else 'Import'}
                                </a>
                            </div>
                            {screenshot_html}
                            {media_html}
                            {datasets_version_html}
                        </div>
                    """
                versions_html += '</div>'

            # Build preview image HTML - use proxy endpoint for browser access
            preview_image_html = ''
            if asset.preview_key:
                preview_image_html = f'''
                    <div style="margin-bottom: 20px; text-align: center;">
                        <a href="/hub/screenshot/{asset.uuid}" target="_blank">
                            <img src="/hub/screenshot/{asset.uuid}?thumbnail=true" alt="{asset.name}"
                                 style="max-width: 100%; max-height: 300px; border-radius: 8px; border: 1px solid #ddd; cursor: zoom-in;"
                                 onerror="this.parentElement.parentElement.style.display=\'none\'">
                        </a>
                        <div style="font-size: 12px; color: #999; margin-top: 8px;">Click to view full size</div>
                    </div>
                '''

            content = f"""
                <a href="/hub/" class="btn btn-secondary" style="margin-bottom: 20px;">← Back to Gallery</a>

                {import_status_html}

                <div class="section">
                    <h2>{asset.name}</h2>
                    {preview_image_html}
                    <p style="color: #666;">{asset.description or 'No description'}</p>

                    <div style="margin-top: 20px; display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px;">
                        <div>
                            <div style="color: #666; font-size: 12px;">Owner</div>
                            <div style="font-weight: 500;">{asset.owner}</div>
                        </div>
                        <div>
                            <div style="color: #666; font-size: 12px;">Visibility</div>
                            <div><span class="visibility-badge visibility-{asset.visibility}">{asset.visibility}</span></div>
                        </div>
                        <div>
                            <div style="color: #666; font-size: 12px;">Source Environment</div>
                            <div>{asset.source_environment or 'Unknown'}</div>
                        </div>
                        <div>
                            <div style="color: #666; font-size: 12px;">Created</div>
                            <div>{asset.created_at[:10] if asset.created_at else 'Unknown'}</div>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <h2>Version History ({len(asset.versions)} versions)</h2>
                    {versions_html or '<p>No versions available</p>'}
                    <div style="margin-top: 16px;">
                        <a href="/hub/diff/{asset.uuid}" class="btn btn-secondary">Compare Versions</a>
                    </div>
                </div>

                <a href="/hub/import/{asset.uuid}" class="btn btn-success">Import Latest Version</a>
            """
            return self._render(f"Preview - {asset.name}", content)

        except Exception as e:
            logger.error(f"Preview failed: {e}")
            content = f"""
                <div class="result-box error">
                    <h2>Preview Failed</h2>
                    <p>{str(e)}</p>
                </div>
                <a href="/hub/" class="btn btn-primary">← Back to Gallery</a>
            """
            return self._render("Preview Error", content)

    @expose("/my-assets")
    def my_assets(self):
        """View user's own published assets."""
        config = self._get_hub_config()
        hub_client = self._get_hub_client()

        hub_connected = hub_client and hub_client.health_check() if hub_client else False
        assets = []

        if hub_connected:
            try:
                # Get user's assets (both public and private)
                assets, _ = hub_client.list_assets(
                    category='dashboard',
                    per_page=50,
                )
            except Exception as e:
                logger.error(f"Error loading assets: {e}")

        content = f"""
            <div class="hub-header">
                <h1>DWE Hub</h1>
                <span class="hub-status {'disconnected' if not hub_connected else ''}">
                    {'Connected' if hub_connected else 'Not Connected'}
                </span>
            </div>

            {self._render_tabs('my-assets')}

            <div class="section">
                <h2>My Published Dashboards</h2>
        """

        if not hub_connected:
            content += """
                <div class="empty-state">
                    <p>DWE Hub is not configured or not reachable.</p>
                </div>
            """
        elif assets:
            content += '<div class="asset-grid">'
            for asset in assets:
                versions_html = f'v{asset.versions[0].version_number}' if asset.versions else 'v1'

                # Build thumbnail HTML - use proxy endpoint for browser access
                thumbnail_html = '<div class="no-preview">📊</div>'
                if asset.preview_thumbnail_key:
                    thumbnail_url = f"/hub/thumbnail/{asset.uuid}"
                    thumbnail_html = f'<img src="{thumbnail_url}" alt="{asset.name}" onerror="this.parentElement.innerHTML=\'<div class=no-preview>📊</div>\'">'

                content += f"""
                    <div class="asset-card">
                        <div class="asset-thumbnail">
                            {thumbnail_html}
                        </div>
                        <div class="asset-name">{asset.name}</div>
                        <div class="asset-meta">
                            {asset.description[:80] + '...' if asset.description and len(asset.description) > 80 else (asset.description or 'No description')}
                        </div>
                        <div class="asset-owner">
                            {versions_html}
                            <span class="visibility-badge visibility-{asset.visibility}">{asset.visibility}</span>
                        </div>
                        <div class="card-actions">
                            <a href="/hub/preview/{asset.uuid}" class="btn btn-secondary">View</a>
                        </div>
                    </div>
                """
            content += '</div>'
        else:
            content += '<div class="empty-state">You haven\'t published any dashboards yet.</div>'

        content += "</div>"

        return self._render("My Assets", content)

    @expose("/api/health")
    def api_health(self):
        """API health check."""
        hub_client = self._get_hub_client()
        hub_connected = hub_client and hub_client.health_check() if hub_client else False

        return jsonify({
            "status": "ok",
            "hub_connected": hub_connected,
        })

    @expose("/screenshot/<asset_uuid>")
    def get_screenshot(self, asset_uuid):
        """
        Proxy endpoint to serve asset screenshots from the Hub.
        This solves CORS issues since the browser can't access internal Docker hostnames.

        Query params:
            thumbnail: 'true' for thumbnail size
            version: version number for version-specific screenshot
        """
        from flask import Response
        import httpx

        config = self._get_hub_config()
        hub_client = self._get_hub_client()

        if not hub_client or not config['hub_url']:
            # Return a 1x1 transparent PNG as fallback
            return Response(
                b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82',
                mimetype='image/png',
                status=200
            )

        try:
            # Ensure authenticated
            if not hub_client.api_token:
                hub_client.login()

            # Build URL with query params
            thumbnail = request.args.get('thumbnail', 'false')
            version = request.args.get('version')

            url = f"{config['hub_url']}/api/v1/assets/{asset_uuid}/screenshot"
            params = []
            if thumbnail == 'true':
                params.append('thumbnail=true')
            if version:
                params.append(f'version={version}')
            if params:
                url += '?' + '&'.join(params)

            headers = {"Authorization": f"Bearer {hub_client.api_token}"}

            with httpx.Client(timeout=10.0) as client:
                response = client.get(url, headers=headers)

                if response.status_code == 200:
                    return Response(
                        response.content,
                        mimetype='image/png',
                        status=200
                    )
                else:
                    # Return transparent PNG on error
                    return Response(
                        b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82',
                        mimetype='image/png',
                        status=200
                    )
        except Exception as e:
            logger.error(f"Failed to fetch screenshot for {asset_uuid}: {e}")
            # Return transparent PNG on error
            return Response(
                b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82',
                mimetype='image/png',
                status=200
            )

    @expose("/thumbnail/<asset_uuid>")
    def get_thumbnail(self, asset_uuid):
        """Backward compatibility - redirects to /screenshot with thumbnail=true."""
        from flask import redirect
        return redirect(f"/hub/screenshot/{asset_uuid}?thumbnail=true")

    @expose("/media/<int:media_id>")
    def get_media(self, media_id):
        """
        Proxy endpoint to serve media files from the Hub.
        This solves CORS issues since the browser can't access internal Docker hostnames.
        """
        from flask import Response
        import httpx

        config = self._get_hub_config()
        hub_client = self._get_hub_client()

        if not hub_client or not config['hub_url']:
            return Response("Not found", status=404)

        try:
            # Ensure authenticated
            if not hub_client.api_token:
                hub_client.login()

            url = f"{config['hub_url']}/api/v1/media/{media_id}"
            headers = {"Authorization": f"Bearer {hub_client.api_token}"}

            with httpx.Client(timeout=30.0) as client:
                response = client.get(url, headers=headers)

                if response.status_code == 200:
                    # Get content type from response
                    content_type = response.headers.get('content-type', 'application/octet-stream')
                    return Response(
                        response.content,
                        mimetype=content_type,
                        status=200
                    )
                else:
                    return Response("Not found", status=404)
        except Exception as e:
            logger.error(f"Failed to fetch media {media_id}: {e}")
            return Response("Error", status=500)

    @expose("/diff/<asset_uuid>")
    def compare_versions(self, asset_uuid):
        """
        Compare two versions of an asset using LLM-powered analysis.

        Query params:
            v1: First version number (optional, defaults to first version)
            v2: Second version number (optional, defaults to latest version)
        """
        hub_client = self._get_hub_client()

        if not hub_client:
            content = """
                <div class="result-box error">
                    <h2>Hub Not Configured</h2>
                    <p>Set DWE_HUB_URL, DWE_HUB_USER, and DWE_HUB_PASSWORD in your configuration.</p>
                </div>
                <a href="/hub/" class="btn btn-primary">← Back</a>
            """
            return self._render("Compare Error", content)

        v1 = request.args.get('v1', type=int)
        v2 = request.args.get('v2', type=int)

        try:
            # Get asset info
            asset = hub_client.get_asset(asset_uuid)

            if len(asset.versions) < 2:
                content = f"""
                    <div class="result-box error">
                        <h2>Cannot Compare</h2>
                        <p>Need at least 2 versions to compare. This asset only has {len(asset.versions)} version(s).</p>
                    </div>
                    <a href="/hub/preview/{asset_uuid}" class="btn btn-primary">← Back to Preview</a>
                """
                return self._render("Compare Error", content)

            # Build version selector if no versions specified
            if v1 is None or v2 is None:
                return self._render_version_selector(asset)

            # Get the diff from Hub
            diff_result = hub_client.get_version_diff(asset_uuid, v1=v1, v2=v2)

            # Build the comparison view
            content = self._render_diff_result(asset, diff_result)

            return self._render(f"Compare {asset.name}", content)

        except Exception as e:
            import traceback
            logger.error(f"Diff failed: {e}")
            logger.error(traceback.format_exc())
            content = f"""
                <div class="result-box error">
                    <h2>Comparison Failed</h2>
                    <p>{str(e)}</p>
                </div>
                <a href="/hub/preview/{asset_uuid}" class="btn btn-primary">← Back to Preview</a>
            """
            return self._render("Compare Error", content)

    def _render_version_selector(self, asset):
        """Render version selection form for comparison."""
        versions = sorted(asset.versions, key=lambda v: v.version_number)

        # Default to comparing first and latest
        default_v1 = versions[0].version_number if versions else 1
        default_v2 = versions[-1].version_number if versions else 1

        options_v1 = ''
        options_v2 = ''
        for v in versions:
            selected_v1 = 'selected' if v.version_number == default_v1 else ''
            selected_v2 = 'selected' if v.version_number == default_v2 else ''
            label = f"v{v.version_number}"
            if v.commit_message:
                label += f" - {v.commit_message[:40]}..."
            options_v1 += f'<option value="{v.version_number}" {selected_v1}>{label}</option>'
            options_v2 += f'<option value="{v.version_number}" {selected_v2}>{label}</option>'

        content = f"""
            <a href="/hub/preview/{asset.uuid}" class="btn btn-secondary" style="margin-bottom: 20px;">← Back to Preview</a>

            <div class="section">
                <h2>Compare Versions: {asset.name}</h2>
                <p style="color: #666; margin-bottom: 20px;">
                    Select two versions to compare and see what changed between them.
                </p>

                <form method="GET" action="/hub/diff/{asset.uuid}" style="max-width: 500px;">
                    <div style="display: grid; grid-template-columns: 1fr 50px 1fr; gap: 12px; align-items: center;">
                        <div class="form-group" style="margin-bottom: 0;">
                            <label>From Version</label>
                            <select name="v1" class="form-control">
                                {options_v1}
                            </select>
                        </div>
                        <div style="text-align: center; font-size: 24px; color: #666; padding-top: 24px;">
                            →
                        </div>
                        <div class="form-group" style="margin-bottom: 0;">
                            <label>To Version</label>
                            <select name="v2" class="form-control">
                                {options_v2}
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="margin-top: 20px;">
                        Compare Versions
                    </button>
                </form>
            </div>
        """
        return self._render(f"Compare {asset.name}", content)

    def _markdown_to_html(self, text):
        """Convert basic markdown to HTML."""
        import re
        import html as html_module

        # Escape HTML first
        text = html_module.escape(text)

        # Headers
        text = re.sub(r'^### (.+)$', r'<h4 style="margin: 0.8em 0 0.4em 0; color: #555;">\1</h4>', text, flags=re.MULTILINE)
        text = re.sub(r'^## (.+)$', r'<h3 style="margin: 1em 0 0.5em 0; color: #333; border-bottom: 1px solid #eee; padding-bottom: 0.3em;">\1</h3>', text, flags=re.MULTILINE)
        text = re.sub(r'^# (.+)$', r'<h2 style="margin: 1em 0 0.5em 0; color: #222;">\1</h2>', text, flags=re.MULTILINE)

        # Bold
        text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)

        # Italic
        text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', text)

        # Code
        text = re.sub(r'`(.+?)`', r'<code style="background: #f5f5f5; padding: 0.2em 0.4em; border-radius: 3px;">\1</code>', text)

        # Bullet points (• or - or *)
        text = re.sub(r'^[•\-\*] (.+)$', r'<li style="margin: 0.3em 0;">\1</li>', text, flags=re.MULTILINE)

        # Wrap consecutive <li> in <ul>
        text = re.sub(r'((?:<li[^>]*>.*?</li>\n?)+)', r'<ul style="margin: 0.5em 0; padding-left: 1.5em;">\1</ul>', text)

        # Paragraphs (double newline)
        text = re.sub(r'\n\n+', '</p><p style="margin: 0.5em 0;">', text)

        # Single newlines to <br>
        text = text.replace('\n', '<br>')

        # Wrap in paragraph
        if not text.startswith('<'):
            text = f'<p style="margin: 0.5em 0;">{text}</p>'

        return text

    def _render_diff_result(self, asset, diff_result):
        """Render the diff comparison result."""
        # Build structural changes section
        structural_html = ''

        if diff_result.charts_added:
            structural_html += f"""
                <div style="background: #e8f5e9; padding: 12px; border-radius: 6px; margin-bottom: 12px;">
                    <strong style="color: #2e7d32;">+ Charts Added ({len(diff_result.charts_added)})</strong>
                    <ul style="margin: 8px 0 0 16px; padding: 0;">
                        {''.join(f'<li>{name}</li>' for name in diff_result.charts_added)}
                    </ul>
                </div>
            """

        if diff_result.charts_removed:
            structural_html += f"""
                <div style="background: #ffebee; padding: 12px; border-radius: 6px; margin-bottom: 12px;">
                    <strong style="color: #c62828;">- Charts Removed ({len(diff_result.charts_removed)})</strong>
                    <ul style="margin: 8px 0 0 16px; padding: 0;">
                        {''.join(f'<li>{name}</li>' for name in diff_result.charts_removed)}
                    </ul>
                </div>
            """

        if diff_result.charts_modified:
            structural_html += f"""
                <div style="background: #fff3e0; padding: 12px; border-radius: 6px; margin-bottom: 12px;">
                    <strong style="color: #f57c00;">~ Charts Modified ({len(diff_result.charts_modified)})</strong>
                    <ul style="margin: 8px 0 0 16px; padding: 0;">
                        {''.join(f'<li>{name}</li>' for name in diff_result.charts_modified)}
                    </ul>
                </div>
            """

        # Other changes
        other_changes = []
        sc = diff_result.structural_changes

        if sc.get('title_changed'):
            other_changes.append('Dashboard title was changed')
        if sc.get('description_changed'):
            other_changes.append('Dashboard description was updated')
        if diff_result.filters_changed:
            other_changes.append(f"Filters changed (v{diff_result.version_from}: {sc.get('filter_count_v1', 0)}, v{diff_result.version_to}: {sc.get('filter_count_v2', 0)})")
        if diff_result.layout_changed:
            other_changes.append('Dashboard layout was modified')
        if sc.get('css_changed'):
            other_changes.append('Custom CSS was modified')
        if sc.get('datasets_changed'):
            other_changes.append('Dataset references changed')

        if other_changes:
            structural_html += f"""
                <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 12px;">
                    <strong style="color: #666;">Other Changes</strong>
                    <ul style="margin: 8px 0 0 16px; padding: 0;">
                        {''.join(f'<li>{change}</li>' for change in other_changes)}
                    </ul>
                </div>
            """

        if not structural_html:
            structural_html = '<p style="color: #666;">No structural changes detected.</p>'

        # LLM indicator
        llm_badge = ''
        if diff_result.llm_enabled:
            llm_badge = '<span style="background: #e3f2fd; color: #1565c0; padding: 4px 8px; border-radius: 4px; font-size: 11px; margin-left: 8px;">AI-powered analysis</span>'
        else:
            llm_badge = '<span style="background: #f5f5f5; color: #666; padding: 4px 8px; border-radius: 4px; font-size: 11px; margin-left: 8px;">Structural analysis only</span>'

        # Convert markdown to HTML
        summary_html = self._markdown_to_html(diff_result.summary)

        content = f"""
            <a href="/hub/diff/{asset.uuid}" class="btn btn-secondary" style="margin-bottom: 20px;">← Change Versions</a>

            <div class="section">
                <h2>{asset.name}: v{diff_result.version_from} → v{diff_result.version_to} {llm_badge}</h2>

                <div style="background: #fafafa; padding: 20px; border-radius: 8px; margin-bottom: 24px; border-left: 4px solid #6c5ce7;">
                    <h3 style="margin-top: 0; color: #333;">Summary</h3>
                    <div style="color: #444; line-height: 1.6;">
                        {summary_html}
                    </div>
                </div>

                <h3>Structural Changes</h3>
                {structural_html}
            </div>

            <div style="display: flex; gap: 12px;">
                <a href="/hub/import/{asset.uuid}?version={diff_result.version_to}" class="btn btn-success">
                    Import v{diff_result.version_to}
                </a>
                <a href="/hub/preview/{asset.uuid}" class="btn btn-secondary">
                    Back to Preview
                </a>
            </div>
        """
        return content
